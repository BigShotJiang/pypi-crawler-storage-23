import functools
import inspect
from typing import Any, Callable, Optional, Dict, List, Union
from ..context import integration_context, current_context


class Ingress:
    """Namespace for ingress decorators."""

    def __init__(self):
        self._webhooks: List[Callable] = []
        self._store = None  # Lazily resolved from RuntimeConfig

    def _get_store(self):
        """
        Return the configured StateStore, lazily initialised from RuntimeConfig.

        Resolution order:
          1. Explicitly set via ``ingress.configure_store(store)``
          2. ``RuntimeConfig.state_store.build_store()`` if a config registry is present
          3. ``SQLiteStateStore`` with an in-memory DB as a no-op fallback (dev/test)
        """
        if self._store is not None:
            return self._store

        try:
            from ..config.runtime_config import StateStoreConfig
            # Attempt to get the global config registry if available
            from .. import _global_config_registry  # type: ignore[attr-defined]
            if _global_config_registry is not None:
                self._store = _global_config_registry._config.state_store.build_store()
                return self._store
        except (ImportError, AttributeError):
            pass

        # Fallback: SQLite in-memory (safe for tests / no-config use)
        from ..state.stores.sqlite_store import SQLiteStateStore
        self._store = SQLiteStateStore(db_path=":memory:")
        return self._store

    def configure_store(self, store) -> None:
        """Explicitly set the StateStore implementation (e.g. from app bootstrap)."""
        self._store = store

    def webhook(self, pipeline: str, integration: str, path: str, method: str = "POST"):
        """
        Metadata-only decorator for webhook handlers.
        Registers the handler in a shared registry for discovery.
        """
        def decorator(func: Callable):
            # Attach metadata to func
            metadata = {
                "kind": "webhook",
                "pipeline": pipeline,
                "integration": integration,
                "path": path,
                "method": method
            }
            setattr(func, "_ingress_metadata", metadata)
            self._webhooks.append(func)
            return func
        return decorator

    def get_webhooks(self) -> List[Callable]:
        """Return all registered webhook handlers."""
        return self._webhooks


    def poll(self, pipeline: str, integration: str, schedule: Union[str, "Schedule"], name: Optional[str] = None):
        """
        Scheduler entrypoint for polling.
        Behaves as a specialized integration_task that manages state.
        Injects 'state: dict' as the first argument.
        """
        from ..decorators import TaskWrapper
        from ..queue.backend import Schedule

        def decorator(func: Callable):
            ingress_name = name or func.__name__

            actual_schedule = Schedule(cron=schedule) if isinstance(schedule, str) else schedule

            @functools.wraps(func)
            async def state_wrapper(*args, **kwargs):
                ctx = current_context()
                if not ctx:
                    # Polling must run within an integration context (usually provided by worker)
                    raise RuntimeError("ingress.poll must run within an integration context")

                # 1. Load state
                state = self._load_state(pipeline, ingress_name)

                # 2. Inject as first arg and call
                try:
                    if inspect.iscoroutinefunction(func):
                        result = await func(state, *args, **kwargs)
                    else:
                        result = func(state, *args, **kwargs)
                except Exception:
                    # Do not save on exception
                    raise

                # 3. Save state on success
                self._save_state(pipeline, ingress_name, state)
                return result

            tw = TaskWrapper(state_wrapper, {
                "integration": integration,
                "pipeline": pipeline,
                "name": ingress_name,
                "default_schedule": actual_schedule
            })

            # Attach metadata for discovery
            setattr(tw, "_ingress_metadata", {
                "kind": "poll",
                "pipeline": pipeline,
                "integration": integration,
                "schedule": actual_schedule,
                "name": ingress_name
            })

            return tw
        return decorator


    def _load_state(self, pipeline: str, ingress_key: str) -> dict:
        """Load ingress state from the configured store.

        Namespace: ``pipeline:{pipeline_id}``
        """
        namespace = f"pipeline:{pipeline}"
        return self._get_store().get(namespace, ingress_key) or {}

    def _save_state(self, pipeline: str, ingress_key: str, state: dict):
        """Persist ingress state to the configured store."""
        namespace = f"pipeline:{pipeline}"
        self._get_store().set(namespace, ingress_key, state)

ingress = Ingress()
