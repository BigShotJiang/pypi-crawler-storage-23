The pretrained models will be downloaded later when the package is used for the first time.
