"""
Setup script for PyStator.

This script handles building the UI before packaging, similar to how Airflow
includes pre-built static files in its package.
"""

import os
import subprocess
from pathlib import Path

from setuptools import setup
from setuptools.command.build_py import build_py
from setuptools.command.sdist import sdist


class BuildUICommand(build_py):
    """Custom build command that builds the UI before packaging."""

    def initialize_options(self):
        super().initialize_options()
        if not hasattr(self.distribution, "packages") or self.distribution.packages is None:
            try:
                from setuptools import find_packages
                self.distribution.packages = find_packages(where="src")
            except Exception:
                self.distribution.packages = ["pystator"]

    def finalize_options(self):
        super().finalize_options()
        if not hasattr(self, "packages") or self.packages is None:
            self.packages = self.distribution.packages
        if not hasattr(self, "build_lib") or self.build_lib is None:
            build_base = getattr(self, "build_base", None)
            self.build_lib = os.path.join(build_base, "lib") if build_base else os.path.join("build", "lib")

    def run(self):
        ui_dir = Path(__file__).parent / "src" / "pystator" / "ui"
        static_dir = ui_dir / "static"
        out_dir = ui_dir / "out"

        needs_build = not static_dir.exists() or not (static_dir / "index.html").exists()
        needs_refresh = out_dir.exists() and static_dir.exists()

        if needs_build or needs_refresh:
            if needs_build:
                print("Building UI static files for package...")
            else:
                print("Refreshing UI static files from latest build...")

            if not (ui_dir / "package.json").exists():
                print("⚠ Warning: UI package.json not found. Skipping UI build.")
                super().run()
                return

            if not (ui_dir / "node_modules").exists():
                print("⚠ Warning: node_modules not found. Skipping UI build.")
                print("   Run 'cd src/pystator/ui && npm install' first to include UI in package.")
                super().run()
                return

            if needs_build:
                try:
                    env = os.environ.copy()
                    env["NODE_ENV"] = "production"
                    subprocess.run(
                        ["npm", "run", "build"],
                        cwd=str(ui_dir),
                        check=True,
                        env=env,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                    )
                except (subprocess.CalledProcessError, FileNotFoundError) as e:
                    print(f"⚠ Warning: UI build failed: {e}")
                    print("   Package will be built without UI static files.")
                    print("   Users can build UI manually: pystator ui build")
                    super().run()
                    return

            if out_dir.exists() and (out_dir / "index.html").exists():
                import shutil
                if static_dir.exists():
                    shutil.rmtree(static_dir)
                shutil.copytree(out_dir, static_dir)
                print("✓ UI static files updated successfully")
            elif not static_dir.exists():
                print("⚠ Warning: No UI build output found.")
                print("   Run 'pystator ui build' or 'cd src/pystator/ui && npm run build' first.")

        super().run()


class SDistCommand(sdist):
    """Custom sdist command that builds UI before creating source distribution."""

    def run(self):
        self.run_command("build_py")
        if hasattr(self, "filelist"):
            self.filelist = None
        super().run()


cmdclass = {
    "build_py": BuildUICommand,
    "sdist": SDistCommand,
}

if __name__ == "__main__":
    from setuptools import find_packages
    setup(
        package_dir={"": "src"},
        packages=find_packages(where="src"),
        cmdclass=cmdclass,
    )
