"""Parallel state (orthogonal regions) support.

Tracks active states across independent regions within a parallel state.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Mapping

if TYPE_CHECKING:
    from pystator._types import State


@dataclass(frozen=True, slots=True)
class ParallelStateConfig:
    """Active-state snapshot for all regions of a parallel state.

    Attributes:
        parallel_state: Name of the parallel state.
        region_states: Immutable mapping from region name to active state name.
    """

    parallel_state: str
    region_states: Mapping[str, str] = field(
        default_factory=lambda: MappingProxyType({})
    )

    def __post_init__(self) -> None:
        if not isinstance(self.region_states, MappingProxyType):
            object.__setattr__(
                self, "region_states", MappingProxyType(dict(self.region_states))
            )

    def get_region_state(self, region_name: str) -> str | None:
        """Get the active state for a specific region."""
        return self.region_states.get(region_name)

    def is_in_state(self, state_name: str) -> bool:
        """True if any region is in the given state."""
        return state_name in self.region_states.values()

    def get_all_active(self) -> list[str]:
        """All currently active states across all regions."""
        return list(self.region_states.values())

    def with_region_state(
        self, region_name: str, new_state: str
    ) -> ParallelStateConfig:
        """Create a new config with an updated region state."""
        new_region_states = dict(self.region_states)
        new_region_states[region_name] = new_state
        return ParallelStateConfig(
            parallel_state=self.parallel_state,
            region_states=new_region_states,
        )

    def contains(self, state_name: str) -> bool:
        """True if state_name is this parallel state or any active region state."""
        if state_name == self.parallel_state:
            return True
        return state_name in self.region_states.values()

    def to_string(self) -> str:
        """Serialize: ``parallel_state:region1=state1,region2=state2``."""
        if not self.region_states:
            return self.parallel_state
        region_parts = ",".join(
            f"{r}={s}" for r, s in sorted(self.region_states.items())
        )
        return f"{self.parallel_state}:{region_parts}"

    @classmethod
    def from_string(cls, value: str) -> ParallelStateConfig:
        """Parse from serialized string."""
        if ":" not in value:
            return cls(parallel_state=value, region_states={})
        parallel_state, region_part = value.split(":", 1)
        region_states = {}
        for pair in region_part.split(","):
            if "=" in pair:
                region, state = pair.split("=", 1)
                region_states[region.strip()] = state.strip()
        return cls(parallel_state=parallel_state, region_states=region_states)


class ParallelStateManager:
    """Manages parallel state configurations and transitions.

    Handles entering, exiting, and transitioning within parallel states.
    """

    def __init__(self, states: dict[str, State]) -> None:
        self._states = states
        self._parallel_states = {
            name: state for name, state in states.items() if state.is_parallel
        }

    def is_parallel_state(self, state_name: str) -> bool:
        return state_name in self._parallel_states

    def get_parallel_state(self, state_name: str) -> State | None:
        return self._parallel_states.get(state_name)

    def enter_parallel_state(self, parallel_state_name: str) -> ParallelStateConfig:
        """Create initial configuration when entering a parallel state."""
        state = self._parallel_states.get(parallel_state_name)
        if state is None:
            raise ValueError(f"'{parallel_state_name}' is not a parallel state")
        region_states = {region.name: region.initial for region in state.regions}
        return ParallelStateConfig(
            parallel_state=parallel_state_name,
            region_states=region_states,
        )

    def exit_parallel_state(self, config: ParallelStateConfig) -> list[str]:
        """States to exit in bottom-up order (region states first, then parallel)."""
        return [*config.get_all_active(), config.parallel_state]

    def process_region_transition(
        self,
        config: ParallelStateConfig,
        region_name: str,
        new_state: str,
    ) -> ParallelStateConfig:
        """Transition within a single region."""
        state = self._parallel_states.get(config.parallel_state)
        if state is None:
            raise ValueError(f"'{config.parallel_state}' is not a parallel state")
        region = state.get_region(region_name)
        if region is None:
            raise ValueError(
                f"Region '{region_name}' not found in '{config.parallel_state}'"
            )
        if region.states and new_state not in region.states:
            raise ValueError(
                f"State '{new_state}' not valid for region '{region_name}'"
            )
        return config.with_region_state(region_name, new_state)

    def find_region_for_state(
        self, parallel_state_name: str, state_name: str
    ) -> str | None:
        """Find which region contains a given state."""
        state = self._parallel_states.get(parallel_state_name)
        if state is None:
            return None
        for region in state.regions:
            if region.contains(state_name):
                return region.name
        return None

    def validate_config(self, config: ParallelStateConfig) -> list[str]:
        """Validate a parallel state configuration. Returns error strings."""
        errors: list[str] = []
        state = self._parallel_states.get(config.parallel_state)
        if state is None:
            errors.append(f"'{config.parallel_state}' is not a parallel state")
            return errors
        expected = {r.name for r in state.regions}
        actual = set(config.region_states.keys())
        missing = expected - actual
        if missing:
            errors.append(f"Missing regions: {missing}")
        extra = actual - expected
        if extra:
            errors.append(f"Unknown regions: {extra}")
        for region in state.regions:
            rs = config.region_states.get(region.name)
            if rs and region.states and rs not in region.states:
                errors.append(f"Invalid state '{rs}' for region '{region.name}'")
        return errors
