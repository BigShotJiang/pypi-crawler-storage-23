"""Transition lifecycle hooks for PyStator FSM.

Provides hooks for metrics, tracing, and logging integration.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Callable, Protocol, runtime_checkable

if TYPE_CHECKING:
    from pystator._types import TransitionResult

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Metrics dataclass
# ---------------------------------------------------------------------------


@dataclass
class TransitionMetrics:
    """Metrics for a single transition."""

    source_state: str
    target_state: str
    trigger: str
    success: bool
    duration_ms: float
    guards_evaluated: int = 0
    guards_passed: int = 0
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    machine_name: str = "unknown"
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Hook protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class TransitionHook(Protocol):
    """Protocol for transition lifecycle hooks.

    Hooks are called in the following order:

    1. ``on_before_process`` — before any processing (orchestrator level).
    2. ``on_transition_start`` — a candidate transition is about to fire.
    3. ``on_transition_complete`` — transition finished (success or fail).
    4. ``on_transition_error`` — an unhandled exception occurred.
    """

    def on_before_process(
        self,
        entity_id: str,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None: ...

    def on_transition_start(
        self, current_state: str, trigger: str, context: dict[str, Any]
    ) -> None: ...

    def on_transition_complete(
        self, result: "TransitionResult", duration_ms: float, context: dict[str, Any]
    ) -> None: ...

    def on_transition_error(
        self,
        error: Exception,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None: ...


# ---------------------------------------------------------------------------
# Built-in hooks
# ---------------------------------------------------------------------------


class LoggingHook:
    """Logs transition details."""

    def __init__(
        self,
        log_level: int = logging.DEBUG,
        logger_name: str = "pystator.transitions",
    ) -> None:
        self.log_level = log_level
        self.logger = logging.getLogger(logger_name)

    def on_before_process(
        self,
        entity_id: str,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        self.logger.log(
            self.log_level,
            "Processing: entity_id=%s state=%s trigger=%s",
            entity_id,
            current_state,
            trigger,
        )

    def on_transition_start(
        self, current_state: str, trigger: str, context: dict[str, Any]
    ) -> None:
        self.logger.log(
            self.log_level,
            "Transition starting: state=%s trigger=%s",
            current_state,
            trigger,
        )

    def on_transition_complete(
        self,
        result: "TransitionResult",
        duration_ms: float,
        context: dict[str, Any],
    ) -> None:
        if result.success:
            self.logger.log(
                self.log_level,
                "Transition completed: %s -> %s (trigger=%s, duration=%.2fms)",
                result.source_state,
                result.target_state,
                result.trigger,
                duration_ms,
            )
        else:
            self.logger.log(
                self.log_level,
                "Transition failed: state=%s trigger=%s error=%s (duration=%.2fms)",
                result.source_state,
                result.trigger,
                result.error,
                duration_ms,
            )

    def on_transition_error(
        self,
        error: Exception,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        self.logger.exception(
            "Transition error: state=%s trigger=%s error=%s",
            current_state,
            trigger,
            error,
        )


class MetricsCollector:
    """Collects and aggregates transition metrics."""

    def __init__(self) -> None:
        self._transitions: list[TransitionMetrics] = []
        self._counters: dict[str, int] = {
            "total": 0,
            "success": 0,
            "failure": 0,
            "errors": 0,
        }
        self._by_trigger: dict[str, int] = {}
        self._by_source_state: dict[str, int] = {}
        self._by_target_state: dict[str, int] = {}
        self._durations: list[float] = []

    def on_before_process(
        self,
        entity_id: str,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        pass

    def on_transition_start(
        self, current_state: str, trigger: str, context: dict[str, Any]
    ) -> None:
        pass

    def on_transition_complete(
        self,
        result: "TransitionResult",
        duration_ms: float,
        context: dict[str, Any],
    ) -> None:
        self._counters["total"] += 1
        if result.success:
            self._counters["success"] += 1
        else:
            self._counters["failure"] += 1
        self._by_trigger[result.trigger] = self._by_trigger.get(result.trigger, 0) + 1
        self._by_source_state[result.source_state] = (
            self._by_source_state.get(result.source_state, 0) + 1
        )
        if result.success and result.target_state:
            self._by_target_state[result.target_state] = (
                self._by_target_state.get(result.target_state, 0) + 1
            )
        self._durations.append(duration_ms)
        self._transitions.append(
            TransitionMetrics(
                source_state=result.source_state,
                target_state=result.target_state or "",
                trigger=result.trigger,
                success=result.success,
                duration_ms=duration_ms,
            )
        )

    def on_transition_error(
        self,
        error: Exception,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        self._counters["errors"] += 1

    def get_summary(self) -> dict[str, Any]:
        total = self._counters["total"]
        rate = self._counters["success"] / total if total else 0.0
        duration_stats: dict[str, float] = {}
        if self._durations:
            s = sorted(self._durations)
            duration_stats = {
                "min_ms": s[0],
                "max_ms": s[-1],
                "avg_ms": sum(s) / len(s),
                "p50_ms": s[len(s) // 2],
                "p95_ms": s[int(len(s) * 0.95)],
                "p99_ms": s[int(len(s) * 0.99)],
            }
        return {
            "total_transitions": total,
            "successful": self._counters["success"],
            "failed": self._counters["failure"],
            "errors": self._counters["errors"],
            "success_rate": rate,
            "by_trigger": dict(self._by_trigger),
            "by_source_state": dict(self._by_source_state),
            "by_target_state": dict(self._by_target_state),
            "duration": duration_stats,
        }

    def reset(self) -> None:
        self._transitions.clear()
        self._counters = {"total": 0, "success": 0, "failure": 0, "errors": 0}
        self._by_trigger.clear()
        self._by_source_state.clear()
        self._by_target_state.clear()
        self._durations.clear()


# ---------------------------------------------------------------------------
# Observer (manages multiple hooks)
# ---------------------------------------------------------------------------


class TransitionObserver:
    """Manages transition lifecycle hooks and provides timing."""

    def __init__(self) -> None:
        self._hooks: list[TransitionHook] = []
        self._start_time: float | None = None
        self._current_state: str | None = None
        self._current_trigger: str | None = None

    def add_hook(self, hook: TransitionHook) -> TransitionObserver:
        self._hooks.append(hook)
        return self

    def remove_hook(self, hook: TransitionHook) -> None:
        self._hooks.remove(hook)

    def before_process(
        self,
        entity_id: str,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        """Dispatch ``on_before_process`` to all hooks.

        Call this at the orchestrator level before any work begins.
        """
        for hook in self._hooks:
            try:
                hook.on_before_process(entity_id, current_state, trigger, context)
            except Exception as e:
                logger.warning("Hook on_before_process failed: %s", e)

    def before_transition(
        self, current_state: str, trigger: str, context: dict[str, Any]
    ) -> None:
        self._start_time = time.perf_counter()
        self._current_state = current_state
        self._current_trigger = trigger
        for hook in self._hooks:
            try:
                hook.on_transition_start(current_state, trigger, context)
            except Exception as e:
                logger.warning("Hook on_transition_start failed: %s", e)

    def after_transition(
        self, result: "TransitionResult", context: dict[str, Any]
    ) -> None:
        duration_ms = 0.0
        if self._start_time is not None:
            duration_ms = (time.perf_counter() - self._start_time) * 1000
            self._start_time = None
        for hook in self._hooks:
            try:
                hook.on_transition_complete(result, duration_ms, context)
            except Exception as e:
                logger.warning("Hook on_transition_complete failed: %s", e)

    def on_error(self, error: Exception, context: dict[str, Any]) -> None:
        state = self._current_state or "unknown"
        trigger = self._current_trigger or "unknown"
        for hook in self._hooks:
            try:
                hook.on_transition_error(error, state, trigger, context)
            except Exception as e:
                logger.warning("Hook on_transition_error failed: %s", e)
