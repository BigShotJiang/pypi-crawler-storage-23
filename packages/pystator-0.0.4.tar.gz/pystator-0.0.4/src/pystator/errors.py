"""Exception hierarchy for PyStator FSM.

All PyStator exceptions inherit from FSMError, making it easy
to catch any FSM-related error with a single except clause.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ErrorCode(str, Enum):
    """Machine-readable error codes for programmatic error handling."""

    GUARD_REJECTED = "guard_rejected"
    VALIDATION_FAILED = "validation_failed"
    INVALID_STATE = "invalid_state"
    INVALID_TRIGGER = "invalid_trigger"
    TERMINAL_STATE = "terminal_state"
    TIMEOUT = "timeout"
    CONFIG = "config"
    ACTION_FAILED = "action_failed"
    STALE_VERSION = "stale_version"
    GUARD_NOT_FOUND = "guard_not_found"
    ACTION_NOT_FOUND = "action_not_found"
    UNDEFINED_STATE = "undefined_state"


class FSMError(Exception):
    """Base exception for all PyStator errors.

    Attributes:
        message: Human-readable error description.
        context: Additional context about the error.
        code: Machine-readable error code for programmatic handling.
    """

    def __init__(
        self,
        message: str,
        context: dict[str, Any] | None = None,
        *,
        code: ErrorCode | None = None,
    ) -> None:
        self.message = message
        self.context = context or {}
        self.code = code
        super().__init__(message)

    def __str__(self) -> str:
        if self.context:
            ctx_str = ", ".join(f"{k}={v!r}" for k, v in self.context.items())
            return f"{self.message} ({ctx_str})"
        return self.message

    def to_dict(self) -> dict[str, Any]:
        """Serialize error to dictionary."""
        return {
            "type": self.__class__.__name__,
            "message": self.message,
            "code": self.code.value if self.code else None,
            "context": self.context,
        }


class ConfigurationError(FSMError):
    """Error in FSM configuration (YAML/JSON schema, invalid definition)."""

    def __init__(
        self,
        message: str,
        path: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if path:
            ctx["path"] = path
        super().__init__(message, ctx)
        self.path = path
        self.code = ErrorCode.CONFIG


class InvalidTransitionError(FSMError):
    """Transition is not allowed from the current state.

    Attributes:
        current_state: The state from which the transition was attempted.
        trigger: The event that triggered the attempted transition.
    """

    def __init__(
        self,
        message: str,
        current_state: str,
        trigger: str,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        ctx.update({"current_state": current_state, "trigger": trigger})
        super().__init__(message, ctx)
        self.current_state = current_state
        self.trigger = trigger
        self.code = ErrorCode.INVALID_TRIGGER


class GuardRejectedError(InvalidTransitionError):
    """Transition blocked by a guard condition.

    Attributes:
        guard_name: The name of the guard that rejected the transition.
        guard_result: Additional information about the guard evaluation.
    """

    def __init__(
        self,
        message: str,
        current_state: str,
        trigger: str,
        guard_name: str,
        guard_result: Any = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        ctx.update({"guard_name": guard_name, "guard_result": guard_result})
        super().__init__(message, current_state, trigger, ctx)
        self.guard_name = guard_name
        self.guard_result = guard_result
        self.code = ErrorCode.GUARD_REJECTED


class UndefinedStateError(FSMError):
    """Reference to a state that is not defined in the machine."""

    def __init__(
        self,
        message: str,
        state_name: str,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        ctx["state_name"] = state_name
        super().__init__(message, ctx)
        self.state_name = state_name
        self.code = ErrorCode.UNDEFINED_STATE


class UndefinedTriggerError(FSMError):
    """Event trigger not defined in the machine (strict mode only).

    Attributes:
        trigger: The undefined event trigger.
        available_triggers: List of valid triggers for reference.
    """

    def __init__(
        self,
        message: str,
        trigger: str,
        available_triggers: list[str] | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        ctx["trigger"] = trigger
        if available_triggers:
            ctx["available_triggers"] = available_triggers
        super().__init__(message, ctx)
        self.trigger = trigger
        self.available_triggers = available_triggers or []
        self.code = ErrorCode.INVALID_TRIGGER


class TerminalStateError(InvalidTransitionError):
    """Attempted to transition from a terminal state."""

    def __init__(
        self,
        current_state: str,
        trigger: str,
        context: dict[str, Any] | None = None,
    ) -> None:
        message = f"Cannot transition from terminal state '{current_state}'"
        super().__init__(message, current_state, trigger, context)
        self.code = ErrorCode.TERMINAL_STATE


class GuardNotFoundError(FSMError):
    """Guard function not registered."""

    def __init__(
        self,
        message: str,
        guard_name: str,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        ctx["guard_name"] = guard_name
        super().__init__(message, ctx)
        self.guard_name = guard_name
        self.code = ErrorCode.GUARD_NOT_FOUND


class ActionNotFoundError(FSMError):
    """Action function not registered."""

    def __init__(
        self,
        message: str,
        action_name: str,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        ctx["action_name"] = action_name
        super().__init__(message, ctx)
        self.action_name = action_name
        self.code = ErrorCode.ACTION_NOT_FOUND


class TimeoutExpiredError(FSMError):
    """State timeout has expired."""

    def __init__(
        self,
        message: str,
        state_name: str,
        timeout_seconds: float,
        elapsed_seconds: float,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        ctx.update(
            {
                "state_name": state_name,
                "timeout_seconds": timeout_seconds,
                "elapsed_seconds": elapsed_seconds,
            }
        )
        super().__init__(message, ctx)
        self.state_name = state_name
        self.timeout_seconds = timeout_seconds
        self.elapsed_seconds = elapsed_seconds
        self.code = ErrorCode.TIMEOUT


class StaleVersionError(FSMError):
    """Optimistic locking conflict -- entity was modified concurrently.

    Attributes:
        entity_id: The entity whose state was stale.
        expected_version: The version the caller expected.
        actual_version: The current version in the store.
    """

    def __init__(
        self,
        entity_id: str,
        expected_version: int,
        actual_version: int,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        ctx.update(
            {
                "entity_id": entity_id,
                "expected_version": expected_version,
                "actual_version": actual_version,
            }
        )
        message = (
            f"Stale version for entity '{entity_id}': "
            f"expected {expected_version}, got {actual_version}"
        )
        super().__init__(message, ctx)
        self.entity_id = entity_id
        self.expected_version = expected_version
        self.actual_version = actual_version
        self.code = ErrorCode.STALE_VERSION


@dataclass
class ErrorPolicy:
    """Configuration for error handling behavior.

    Attributes:
        default_fallback: State to transition to on unhandled errors.
        retry_attempts: Number of retries before falling back.
        strict_mode: If True, undefined triggers raise errors.
    """

    default_fallback: str | None = None
    retry_attempts: int = 0
    strict_mode: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)

    def should_fallback(self, error: FSMError) -> bool:
        """True if default_fallback is configured."""
        return self.default_fallback is not None
