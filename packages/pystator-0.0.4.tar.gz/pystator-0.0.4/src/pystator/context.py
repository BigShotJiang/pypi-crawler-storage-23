"""TransitionContext -- dict subclass with typed access to FSM metadata.

Fully backward-compatible: guards and actions still receive a plain dict.
TransitionContext **is** a dict, so all existing code continues to work.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pystator.event import Event


class TransitionContext(dict):  # type: ignore[type-arg]
    """Context dict with typed access to internal metadata.

    Internal keys (prefixed with ``_``) are set by the engine and
    orchestrator. User data lives alongside them in the same dict.

    Example::

        def my_guard(ctx: dict) -> bool:
            tc = TransitionContext(ctx)
            event = tc.event          # typed access
            entity = tc.entity_id     # typed access
            return ctx.get("valid")   # still works as a normal dict
    """

    @property
    def event(self) -> Event | None:
        """The Event object that triggered this transition."""
        return self.get("_event")

    @property
    def entity_id(self) -> str | None:
        """The entity ID (set by Orchestrator)."""
        return self.get("_entity_id")

    @property
    def action_params(self) -> dict[str, Any]:
        """Parameters injected for the current action."""
        return self.get("_action_params", {})

    def user_data(self) -> dict[str, Any]:
        """Return a copy of the context without internal (``_``-prefixed) keys."""
        return {k: v for k, v in self.items() if not k.startswith("_")}
