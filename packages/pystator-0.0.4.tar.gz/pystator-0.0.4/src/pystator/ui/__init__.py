"""PyStator UI - Next.js frontend for FSM builder and visualization."""
