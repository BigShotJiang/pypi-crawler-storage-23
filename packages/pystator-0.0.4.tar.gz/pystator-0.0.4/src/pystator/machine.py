"""StateMachine -- config-driven FSM definition and factory.

The config (YAML / dict) is the single source of truth for the FSM
structure. Python code provides implementations (guards, actions)
that are referenced by name in the config.

Example:
    >>> from pystator import StateMachine
    >>>
    >>> machine = StateMachine.from_yaml("order_fsm.yaml")
    >>>
    >>> @machine.guard("is_full_fill")
    ... def is_full_fill(ctx):
    ...     return ctx["fill_qty"] >= ctx["order_qty"]
    >>>
    >>> @machine.action("update_positions")
    ... def update_positions(ctx):
    ...     db.update(ctx["symbol"], ctx["fill_qty"])
    >>>
    >>> # Stateless processing
    >>> result = machine.process("OPEN", "execution_report", context)
    >>>
    >>> # Or create a stateful instance
    >>> order = machine.create(context={"order_id": "123"})
    >>> order.send("execution_report", fill_qty=100, order_qty=100)
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, TypeVar

from pystator._engine import Engine
from pystator._parallel import ParallelStateConfig
from pystator._types import State, Transition, TransitionResult
from pystator.actions import ActionRegistry, AnyActionFunc
from pystator.config.loader import ConfigLoader
from pystator.errors import ConfigurationError, ErrorPolicy
from pystator.event import Event
from pystator.guards import AnyGuardFunc, GuardEvaluator, GuardRegistry

F = TypeVar("F")


class StateMachine:
    """Config-driven finite state machine definition and factory.

    The StateMachine is **stateless** -- it holds the FSM definition
    (states, transitions, guards, actions) but no per-entity state.
    Use :meth:`create` to get a stateful :class:`MachineInstance`.

    Config is the single source of truth:
        - States, transitions, guards, and actions are declared in YAML/dict.
        - Python implementations are bound via ``@machine.guard("name")``
          and ``@machine.action("name")`` decorators.
    """

    def __init__(
        self,
        states: dict[str, State],
        transitions: list[Transition],
        meta: dict[str, Any] | None = None,
        error_policy: ErrorPolicy | None = None,
    ) -> None:
        self._states = states
        self._transitions = transitions
        self._meta = meta or {}
        self._error_policy = error_policy or ErrorPolicy(
            strict_mode=self._meta.get("strict_mode", True)
        )

        # Internal engine
        self._engine = Engine(states, transitions, self._meta, self._error_policy)

        # Registries (populated via decorators or bind methods)
        self._guard_registry = GuardRegistry()
        self._action_registry = ActionRegistry()

        # Bind guard checker to engine
        evaluator = GuardEvaluator(
            self._guard_registry, strict=self._error_policy.strict_mode
        )
        self._engine.guard_checker._registry = self._guard_registry
        self._engine.guard_checker._evaluator = evaluator
        self._engine.guard_checker.strict = self._error_policy.strict_mode

    # ------------------------------------------------------------------
    # Factory class methods
    # ------------------------------------------------------------------

    @classmethod
    def from_yaml(
        cls,
        path: str | Path,
        validate: bool = True,
        variables: dict[str, str] | None = None,
    ) -> StateMachine:
        """Create a StateMachine from a YAML configuration file.

        Args:
            path: Path to the YAML configuration file.
            validate: If True, validate config against schema.
            variables: Optional variables for ``${VAR}`` substitution.

        Returns:
            Configured StateMachine instance.
        """
        loader = ConfigLoader(validate=validate, variables=variables)
        config = loader.load(path)
        return cls.from_dict(config)

    @classmethod
    def from_dict(cls, config: dict[str, Any]) -> StateMachine:
        """Create a StateMachine from a configuration dictionary.

        Args:
            config: Configuration dictionary matching the schema.

        Returns:
            Configured StateMachine instance.
        """
        loader = ConfigLoader(validate=False)
        states, transitions, meta = loader.parse(config)

        ep_raw = config.get("error_policy")
        if ep_raw:
            error_policy = ErrorPolicy(
                default_fallback=ep_raw.get("default_fallback"),
                retry_attempts=ep_raw.get("retry_attempts", 0),
                strict_mode=meta.get("strict_mode", True),
            )
        else:
            error_policy = ErrorPolicy(strict_mode=meta.get("strict_mode", True))

        return cls(states, transitions, meta, error_policy)

    # ------------------------------------------------------------------
    # Decorator binding
    # ------------------------------------------------------------------

    def guard(self, name: str) -> Callable[[AnyGuardFunc], AnyGuardFunc]:
        """Decorator to bind a guard implementation to its config name.

        Example:
            >>> @machine.guard("is_valid")
            ... def is_valid(ctx):
            ...     return ctx.get("valid", False)
        """

        def decorator(func: AnyGuardFunc) -> AnyGuardFunc:
            self._guard_registry.register(name, func)
            return func

        return decorator

    def action(self, name: str) -> Callable[[AnyActionFunc], AnyActionFunc]:
        """Decorator to bind an action implementation to its config name.

        Example:
            >>> @machine.action("notify")
            ... def notify(ctx):
            ...     send_email(ctx["email"], "State changed")
        """

        def decorator(func: AnyActionFunc) -> AnyActionFunc:
            self._action_registry.register(name, func)
            return func

        return decorator

    # ------------------------------------------------------------------
    # Manual binding (alternative to decorators)
    # ------------------------------------------------------------------

    def bind_guards(self, registry: GuardRegistry) -> StateMachine:
        """Bind an external guard registry.

        Replaces the internal guard registry with the provided one.

        Returns:
            Self for method chaining.
        """
        self._guard_registry = registry
        evaluator = GuardEvaluator(registry, strict=self._error_policy.strict_mode)
        self._engine.guard_checker._registry = registry
        self._engine.guard_checker._evaluator = evaluator
        return self

    def bind_actions(self, registry: ActionRegistry) -> StateMachine:
        """Bind an external action registry.

        Returns:
            Self for method chaining.
        """
        self._action_registry = registry
        return self

    # ------------------------------------------------------------------
    # Stateless processing
    # ------------------------------------------------------------------

    def process(
        self,
        current_state: str,
        event: str | Event,
        context: dict[str, Any] | None = None,
    ) -> TransitionResult:
        """Process an event and compute the transition result.

        Pure computation -- no side effects, no state mutation.

        Args:
            current_state: The current state name.
            event: Event trigger string or Event object.
            context: Optional context dict for guards.

        Returns:
            TransitionResult describing the computed transition.
        """
        return self._engine.process(current_state, event, context)

    async def aprocess(
        self,
        current_state: str,
        event: str | Event,
        context: dict[str, Any] | None = None,
    ) -> TransitionResult:
        """Async version of :meth:`process` (supports async guards)."""
        return await self._engine.aprocess(current_state, event, context)

    # ------------------------------------------------------------------
    # Instance factory
    # ------------------------------------------------------------------

    def create(
        self,
        *,
        context: dict[str, Any] | None = None,
        initial_state: str | None = None,
    ) -> "MachineInstance":
        """Create a stateful instance of this machine.

        Args:
            context: Initial context dict for the instance.
            initial_state: Override the initial state (defaults to config initial).

        Returns:
            A new :class:`MachineInstance`.
        """
        # Lazy import to avoid circular dependency
        from pystator.instance import MachineInstance

        return MachineInstance(
            machine=self,
            context=context,
            initial_state=initial_state,
        )

    # ------------------------------------------------------------------
    # Query methods
    # ------------------------------------------------------------------

    def get_state(self, name: str) -> State:
        """Get a state definition by name."""
        from pystator.errors import UndefinedStateError

        if name not in self._states:
            raise UndefinedStateError(f"State '{name}' is not defined", state_name=name)
        return self._states[name]

    def get_initial_state(self) -> State:
        """Get the initial leaf state."""
        return self._states[self._engine.initial_leaf]

    def get_available_transitions(self, current_state: str) -> list[Transition]:
        """Get all transitions available from a state."""
        ancestors_set = set(self._engine.hierarchy.ancestors(current_state))
        return [t for t in self._transitions if t.source & ancestors_set]

    def get_available_triggers(self, current_state: str) -> list[str]:
        """Get all trigger names available from a state."""
        transitions = self.get_available_transitions(current_state)
        return sorted({t.trigger for t in transitions})

    def can_transition(
        self,
        current_state: str,
        trigger: str,
        context: dict[str, Any] | None = None,
    ) -> bool:
        """Check if a transition is possible (convenience method)."""
        try:
            result = self.process(current_state, trigger, context)
            return result.success
        except Exception:
            return False

    def validate_state(self, state: str) -> bool:
        """True if state is defined."""
        return state in self._states

    def is_terminal(self, state: str) -> bool:
        """True if state is terminal."""
        return self.get_state(state).is_terminal

    def is_initial(self, state: str) -> bool:
        """True if state is initial."""
        return self.get_state(state).is_initial

    # ------------------------------------------------------------------
    # Parallel state methods
    # ------------------------------------------------------------------

    def is_parallel_state(self, state_name: str) -> bool:
        return self._engine.parallel.is_parallel_state(state_name)

    def enter_parallel_state(self, parallel_state_name: str) -> ParallelStateConfig:
        return self._engine.parallel.enter_parallel_state(parallel_state_name)

    def process_parallel(
        self,
        config: ParallelStateConfig,
        event: str | Event,
        context: dict[str, Any] | None = None,
    ) -> tuple[ParallelStateConfig, list[TransitionResult]]:
        return self._engine.process_parallel(config, event, context)

    async def aprocess_parallel(
        self,
        config: ParallelStateConfig,
        event: str | Event,
        context: dict[str, Any] | None = None,
    ) -> tuple[ParallelStateConfig, list[TransitionResult]]:
        return await self._engine.aprocess_parallel(config, event, context)

    # ------------------------------------------------------------------
    # State variable validation
    # ------------------------------------------------------------------

    def get_state_variables(self) -> list[dict[str, Any]]:
        """Get state variable definitions from meta."""
        raw = self._meta.get("state_variables") or self._meta.get("context")
        if not raw or not isinstance(raw, list):
            return []
        return [item if isinstance(item, dict) else {"key": str(item)} for item in raw]

    def validate_context(self, context: dict[str, Any]) -> tuple[bool, list[str]]:
        """Validate context against state_variables.

        Returns (valid, error_messages).
        """
        if not self._meta.get("validate_context"):
            return True, []
        variables = self.get_state_variables()
        errors: list[str] = []
        for var in variables:
            key = var.get("key", "")
            if not key:
                continue
            required = var.get("required", False)
            type_hint = var.get("type")
            if key not in context:
                if required:
                    errors.append(f"Missing required state variable: {key!r}")
                continue
            value = context[key]
            if required and value is None:
                errors.append(f"Required state variable {key!r} must not be None")
                continue
            if type_hint and value is not None:
                _TYPE_CHECKS = {
                    "string": str,
                    "number": (int, float),
                    "boolean": bool,
                    "object": dict,
                }
                expected = _TYPE_CHECKS.get(type_hint)
                if expected and not isinstance(value, expected):
                    errors.append(
                        f"State variable {key!r} should be {type_hint}, "
                        f"got {type(value).__name__}"
                    )
        return len(errors) == 0, errors

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        """Machine name from metadata."""
        return self._meta.get("machine_name", "unnamed")

    @property
    def version(self) -> str:
        """Machine version from metadata."""
        return self._meta.get("version", "0.0.0")

    @property
    def strict_mode(self) -> bool:
        return self._error_policy.strict_mode

    @property
    def states(self) -> dict[str, State]:
        """All states (read-only copy)."""
        return dict(self._states)

    @property
    def transitions(self) -> list[Transition]:
        """All transitions (read-only copy)."""
        return list(self._transitions)

    @property
    def state_names(self) -> list[str]:
        return list(self._states.keys())

    @property
    def trigger_names(self) -> list[str]:
        return sorted({t.trigger for t in self._transitions})

    @property
    def terminal_states(self) -> list[str]:
        return [s.name for s in self._states.values() if s.is_terminal]

    @property
    def parallel_states(self) -> list[str]:
        return [s.name for s in self._states.values() if s.is_parallel]

    @property
    def meta(self) -> dict[str, Any]:
        return dict(self._meta)

    @property
    def guard_registry(self) -> GuardRegistry:
        return self._guard_registry

    @property
    def action_registry(self) -> ActionRegistry:
        return self._action_registry

    # ------------------------------------------------------------------
    # Visualization / export convenience methods
    # ------------------------------------------------------------------

    def to_mermaid(self, **kwargs: Any) -> str:
        """Generate Mermaid stateDiagram-v2. See :func:`visualization.to_mermaid`."""
        from pystator.visualization import to_mermaid

        return to_mermaid(self, **kwargs)

    def to_dot(self, **kwargs: Any) -> str:
        """Generate Graphviz DOT. See :func:`visualization.to_dot`."""
        from pystator.visualization import to_dot

        return to_dot(self, **kwargs)

    def to_scxml(self, **kwargs: Any) -> str:
        """Generate SCXML. See :func:`visualization.to_scxml`."""
        from pystator.visualization import to_scxml

        return to_scxml(self, **kwargs)

    def get_statistics(self) -> dict[str, Any]:
        """Get machine statistics. See :func:`visualization.get_statistics`."""
        from pystator.visualization import get_statistics

        return get_statistics(self)

    def lint(self) -> list[Any]:
        """Run static analysis checks. See :func:`lint.lint`."""
        from pystator.lint import lint

        return lint(self)

    def __repr__(self) -> str:
        return (
            f"StateMachine(name={self.name!r}, "
            f"states={len(self._states)}, "
            f"transitions={len(self._transitions)})"
        )


class StateMachineBuilder:
    """Fluent builder for StateMachine from Python code."""

    def __init__(self, machine_name: str) -> None:
        self._machine_name = machine_name
        self._states: list[dict[str, Any]] = []
        self._transitions: list[dict[str, Any]] = []
        self._state_variables: list[dict[str, Any]] = []

    def add_state(
        self,
        name: str,
        *,
        type: str = "stable",
        **kwargs: Any,
    ) -> "StateMachineBuilder":
        """Add a state. type: initial, stable, terminal, error."""
        self._states.append({"name": name, "type": type, **kwargs})
        return self

    def add_transition(
        self,
        trigger: str,
        source: str | list[str],
        dest: str,
        **kwargs: Any,
    ) -> "StateMachineBuilder":
        """Add a transition."""
        src = source if isinstance(source, list) else [source]
        self._transitions.append(
            {"trigger": trigger, "source": src, "dest": dest, **kwargs}
        )
        return self

    def add_state_variable(
        self,
        key: str,
        *,
        type: str | None = None,
        required: bool = False,
        default: Any = None,
        **kwargs: Any,
    ) -> "StateMachineBuilder":
        """Add a state variable (context key) definition."""
        v: dict[str, Any] = {"key": key, **kwargs}
        if type is not None:
            v["type"] = type
        if required:
            v["required"] = True
        if default is not None:
            v["default"] = default
        self._state_variables.append(v)
        return self

    def to_dict(self) -> dict[str, Any]:
        """Export to config dict."""
        d: dict[str, Any] = {
            "meta": {"machine_name": self._machine_name},
            "states": self._states,
            "transitions": self._transitions,
        }
        if self._state_variables:
            d["state_variables"] = self._state_variables
        return d

    @classmethod
    def from_dict(cls, config: dict[str, Any]) -> "StateMachineBuilder":
        """Create builder from config dict (loads state_variables or context)."""
        meta = config.get("meta", {})
        name = meta.get("machine_name", "unnamed")
        b = cls(name)
        b._states = list(config.get("states", []))
        b._transitions = list(config.get("transitions", []))
        sv = config.get("state_variables") or config.get("context")
        b._state_variables = list(sv) if sv else []
        return b

    def build(self) -> StateMachine:
        """Build the StateMachine."""
        return StateMachine.from_dict(self.to_dict())


def check_timeout(
    machine: StateMachine,
    current_state: str,
    entered_at: datetime,
    context: dict[str, Any] | None = None,
) -> TransitionResult | None:
    """Check if a state timeout has expired and return the transition result if so.

    If the current state has a timeout and the elapsed time since ``entered_at``
    exceeds the timeout, processes a "timeout" trigger and returns the result.
    Otherwise returns None.

    The machine must have a transition with trigger "timeout" from the current
    state to the timeout destination for this to succeed.
    """
    state = machine.get_state(current_state)
    if not state or not state.timeout:
        return None
    now = datetime.now(timezone.utc) if entered_at.tzinfo else datetime.now()
    elapsed = (now - entered_at).total_seconds()
    if elapsed >= state.timeout.seconds:
        return machine.process(current_state, "timeout", context or {})
    return None
