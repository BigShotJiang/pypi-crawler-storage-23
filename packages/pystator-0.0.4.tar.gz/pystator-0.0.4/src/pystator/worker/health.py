"""Health and readiness checks for the worker process.

Provides :class:`HealthChecker` which reports liveness (process is up),
readiness (DB reachable + machines loaded), and a detailed status dict.
"""

from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any

from pystator.worker.event_sources.base import EventSource
from pystator.worker.registry import MachineRegistry


class HealthChecker:
    """Aggregates health signals for the worker.

    Args:
        event_source: The event source (checked for DB connectivity).
        registry: The machine registry (checked for loaded machines).
    """

    def __init__(
        self,
        event_source: EventSource,
        registry: MachineRegistry,
    ) -> None:
        self._event_source = event_source
        self._registry = registry
        self._started_at = datetime.now(timezone.utc)

    async def liveness(self) -> bool:
        """Return ``True`` if the worker process is alive.

        Always ``True``; the fact that this method can execute means
        the process and event loop are running.
        """
        return True

    async def readiness(self) -> bool:
        """Return ``True`` when the worker can process events.

        Checks:
        - Event source backend is reachable.
        - At least one machine is loaded in the registry.
        """
        if self._registry.machine_count == 0:
            return False
        return await self._event_source.health_check()

    async def status(self) -> dict[str, Any]:
        """Return a detailed status dictionary.

        Useful for debugging and monitoring dashboards.
        """
        db_ok = await self._event_source.health_check()
        pending = await self._event_source.pending_count()

        return {
            "alive": True,
            "ready": db_ok and self._registry.machine_count > 0,
            "db_reachable": db_ok,
            "machines_loaded": self._registry.machine_count,
            "machine_names": self._registry.machine_names,
            "pending_events": pending,
            "started_at": self._started_at.isoformat(),
            "uptime_seconds": round(
                (datetime.now(timezone.utc) - self._started_at).total_seconds()
            ),
        }
