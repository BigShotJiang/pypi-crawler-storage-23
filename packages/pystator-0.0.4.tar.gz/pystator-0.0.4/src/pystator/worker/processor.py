"""Event processor: claims events, runs the Orchestrator, and handles outcomes.

This is the core "sandwich" executor for the worker.  Each claimed event
is fed to the appropriate :class:`~pystator.Orchestrator` (looked up via
:class:`MachineRegistry`).  After processing, the event is marked as
completed or failed in the event source, and any delayed transitions are
scheduled by inserting new events with a ``fires_at`` in the future.
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, timedelta, timezone
from typing import Any

from pystator.worker.event_sources.base import EventSource
from pystator.worker.models import ClaimedEvent, WorkerEvent
from pystator.worker.registry import MachineRegistry

logger = logging.getLogger(__name__)


class EventProcessor:
    """Processes a single claimed event through the Orchestrator.

    Args:
        registry: Machine registry for Orchestrator lookup.
        event_source: Event source for completing/failing events
            and scheduling delayed transitions.
    """

    def __init__(
        self,
        registry: MachineRegistry,
        event_source: EventSource,
    ) -> None:
        self._registry = registry
        self._event_source = event_source

    async def process_one(self, claimed: ClaimedEvent) -> None:
        """Run the full sandwich loop for a single claimed event.

        1. Look up the Orchestrator for ``claimed.machine_name``.
        2. Call ``orchestrator.process_event(entity_id, trigger, context)``.
        3. On success: mark completed, schedule any delayed transitions.
        4. On failure: mark failed (with retry if transient).
        """
        start = time.monotonic()
        machine_name = claimed.machine_name
        entity_id = claimed.entity_id
        trigger = claimed.trigger

        logger.info(
            "Processing event %s: %s/%s/%s (attempt %d/%d)",
            claimed.event_id,
            machine_name,
            entity_id,
            trigger,
            claimed.attempt,
            claimed.max_attempts,
        )

        try:
            orchestrator = self._registry.get_orchestrator(machine_name)
        except KeyError as exc:
            await self._event_source.fail(
                claimed.event_id,
                f"Unknown machine: {machine_name}",
                retry=False,
            )
            logger.error(
                "Event %s failed (permanent): %s",
                claimed.event_id,
                exc,
            )
            return

        try:
            result = orchestrator.process_event(
                entity_id=entity_id,
                event=trigger,
                context=claimed.context,
            )
        except Exception as exc:
            elapsed_ms = (time.monotonic() - start) * 1000
            await self._event_source.fail(
                claimed.event_id,
                f"{type(exc).__name__}: {exc}",
                retry=True,
            )
            logger.error(
                "Event %s failed (%.1fms): %s",
                claimed.event_id,
                elapsed_ms,
                exc,
                exc_info=True,
            )
            return

        elapsed_ms = (time.monotonic() - start) * 1000

        if result.success:
            result_payload = {
                "source_state": result.source_state,
                "target_state": result.target_state,
                "success": True,
            }
            await self._event_source.complete(claimed.event_id, result=result_payload)
            logger.info(
                "Event %s completed (%.1fms): %s -> %s",
                claimed.event_id,
                elapsed_ms,
                result.source_state,
                result.target_state,
            )

            # Schedule delayed transitions from the new state
            if result.target_state:
                await self._schedule_delayed_transitions(
                    machine_name=machine_name,
                    entity_id=entity_id,
                    target_state=result.target_state,
                    context=claimed.context,
                )
        else:
            error_msg = str(result.error) if result.error else "Transition failed"
            is_permanent = _is_permanent_failure(result)
            await self._event_source.fail(
                claimed.event_id,
                error_msg,
                retry=not is_permanent,
            )
            logger.warning(
                "Event %s transition rejected (%.1fms): %s",
                claimed.event_id,
                elapsed_ms,
                error_msg,
            )

    # ------------------------------------------------------------------
    # Delayed transitions
    # ------------------------------------------------------------------

    async def _schedule_delayed_transitions(
        self,
        machine_name: str,
        entity_id: str,
        target_state: str,
        context: dict[str, Any] | None,
    ) -> None:
        """Insert new events for any delayed transitions from *target_state*.

        Instead of in-memory callbacks, delayed transitions become new
        rows in the event source with ``fires_at = now + delay``.
        Any worker replica can pick them up when they come due.
        """
        try:
            machine = self._registry.get_machine(machine_name)
        except KeyError:
            return

        for trans in machine.transitions:
            if trans.is_delayed and trans.matches_source(target_state):
                fires_at = datetime.now(timezone.utc) + timedelta(
                    milliseconds=trans.after  # type: ignore[arg-type]
                )
                event = WorkerEvent(
                    machine_name=machine_name,
                    entity_id=entity_id,
                    trigger=trans.trigger,
                    context=context,
                    fires_at=fires_at,
                )
                event_id = await self._event_source.submit(event)
                logger.debug(
                    "Scheduled delayed transition %s for %s/%s/%s at %s",
                    event_id,
                    machine_name,
                    entity_id,
                    trans.trigger,
                    fires_at.isoformat(),
                )


def _is_permanent_failure(result: Any) -> bool:
    """Determine whether a failed transition should *not* be retried.

    Guard rejections and invalid-transition errors are permanent
    (re-processing won't change the outcome).
    """
    if result.error is None:
        return False

    from pystator.errors import (
        GuardRejectedError,
        InvalidTransitionError,
        TerminalStateError,
        UndefinedStateError,
        UndefinedTriggerError,
    )

    return isinstance(
        result.error,
        (
            GuardRejectedError,
            InvalidTransitionError,
            TerminalStateError,
            UndefinedStateError,
            UndefinedTriggerError,
        ),
    )
