"""PyStator Worker -- 24/7 stateful event-processing service.

The worker is a long-running process that consumes events from a durable
queue (database by default), routes them to the appropriate FSM
Orchestrator, and handles retries, delayed transitions, and graceful
shutdown.  Multiple replicas can run safely; the database-backed event
source uses atomic claims to prevent duplicate work.

Quick start::

    from pystator.worker import Worker

    worker = Worker()
    await worker.start()
    await worker.run()

Submitting events (from any process with DB access)::

    from pystator.worker import submit_event

    event_id = await submit_event(
        "order_management", "order-123", "fill",
        context={"fill_qty": 100, "order_qty": 100},
    )
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime, timezone
from typing import Any

from pystator.worker.config import WorkerConfig
from pystator.worker.models import ClaimedEvent, EventStatus, WorkerEvent
from pystator.worker.runner import Worker

__all__ = [
    "Worker",
    "WorkerConfig",
    "WorkerEvent",
    "ClaimedEvent",
    "EventStatus",
    "submit_event",
    "submit_event_sync",
]


async def submit_event(
    machine_name: str,
    entity_id: str,
    trigger: str,
    *,
    context: dict[str, Any] | None = None,
    fires_at: datetime | None = None,
    idempotency_key: str | None = None,
    max_attempts: int = 5,
    db_url: str | None = None,
) -> str:
    """Convenience function: submit one event to the worker queue.

    Writes directly to the ``worker_events`` table.  Can be called from
    any process that has database access.

    Args:
        machine_name: Target FSM machine name.
        entity_id: Entity identifier (e.g. ``"order-123"``).
        trigger: Event trigger name (e.g. ``"fill"``).
        context: Optional dict passed to guards and actions.
        fires_at: When the event becomes eligible.  ``None`` = now.
        idempotency_key: Optional dedup key.
        max_attempts: Maximum processing attempts.
        db_url: Database URL.  Falls back to the standard pystator
            config resolution chain.

    Returns:
        The ``event_id`` of the enqueued event.
    """
    from pystator.worker.event_sources.database import DatabaseEventSource

    resolved_url = db_url
    if resolved_url is None:
        from pystator.config.database import get_database_url

        resolved_url = get_database_url()
    if not resolved_url:
        raise ValueError(
            "No database URL configured.  Pass db_url or set " "PYSTATOR_DATABASE_URL."
        )

    source = DatabaseEventSource(resolved_url)
    try:
        event = WorkerEvent(
            machine_name=machine_name,
            entity_id=entity_id,
            trigger=trigger,
            context=context,
            fires_at=fires_at,
            idempotency_key=idempotency_key,
            max_attempts=max_attempts,
        )
        return await source.submit(event)
    finally:
        await source.close()


def submit_event_sync(
    machine_name: str,
    entity_id: str,
    trigger: str,
    *,
    context: dict[str, Any] | None = None,
    fires_at: datetime | None = None,
    idempotency_key: str | None = None,
    max_attempts: int = 5,
    db_url: str | None = None,
) -> str:
    """Synchronous wrapper around :func:`submit_event`.

    Suitable for calling from non-async code (scripts, Django views,
    Flask routes, etc.).
    """
    return asyncio.run(
        submit_event(
            machine_name,
            entity_id,
            trigger,
            context=context,
            fires_at=fires_at,
            idempotency_key=idempotency_key,
            max_attempts=max_attempts,
            db_url=db_url,
        )
    )
