"""Machine registry: maps machine names to Orchestrator instances.

At startup the registry loads machine definitions (from the database or
from YAML files on disk), builds a :class:`~pystator.StateMachine` and
a corresponding :class:`~pystator.Orchestrator` for each, and caches
them by ``machine_name``.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from pystator.actions import ActionExecutor, ActionRegistry
from pystator.guards import GuardRegistry
from pystator.machine import StateMachine
from pystator.orchestrator import Orchestrator
from pystator.stores.base import StateStore

logger = logging.getLogger(__name__)


class MachineRegistry:
    """Loads machines and provides Orchestrator lookup by name.

    Args:
        state_store: Shared state store used by all Orchestrators.
        guards: Guard registry bound to every loaded machine.
        actions: Action registry bound to every loaded machine.
        db_url: Database URL for loading machines from the
            ``machines`` table (used when *machine_source* is ``"db"``).
        machine_source: ``"db"`` or ``"yaml"``.
        machine_dir: Path to a directory of ``*.yaml`` machine configs
            (only when *machine_source* is ``"yaml"``).
    """

    def __init__(
        self,
        state_store: StateStore,
        guards: GuardRegistry | None = None,
        actions: ActionRegistry | None = None,
        *,
        db_url: str | None = None,
        machine_source: str = "db",
        machine_dir: str | None = None,
    ) -> None:
        self._store = state_store
        self._guards = guards or GuardRegistry()
        self._actions = actions or ActionRegistry()
        self._db_url = db_url
        self._machine_source = machine_source
        self._machine_dir = machine_dir

        self._orchestrators: dict[str, Orchestrator] = {}
        self._machines: dict[str, StateMachine] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def machine_names(self) -> list[str]:
        """Return the names of all loaded machines."""
        return sorted(self._orchestrators.keys())

    @property
    def machine_count(self) -> int:
        return len(self._orchestrators)

    def get_orchestrator(self, machine_name: str) -> Orchestrator:
        """Return the :class:`Orchestrator` for *machine_name*.

        Raises:
            KeyError: If no machine with that name is loaded.
        """
        try:
            return self._orchestrators[machine_name]
        except KeyError:
            available = ", ".join(self.machine_names) or "(none)"
            raise KeyError(
                f"Machine {machine_name!r} not found in registry.  "
                f"Available: {available}"
            ) from None

    def get_machine(self, machine_name: str) -> StateMachine:
        """Return the :class:`StateMachine` for *machine_name*."""
        try:
            return self._machines[machine_name]
        except KeyError:
            raise KeyError(f"Machine {machine_name!r} not found in registry.") from None

    def load(self) -> None:
        """Load machine definitions and build orchestrators.

        Reads from DB or YAML depending on ``machine_source``.
        """
        if self._machine_source == "yaml":
            self._load_from_yaml()
        else:
            self._load_from_db()

        logger.info(
            "MachineRegistry loaded %d machine(s): %s",
            self.machine_count,
            ", ".join(self.machine_names),
        )

    # ------------------------------------------------------------------
    # Internal: build an orchestrator for a config dict
    # ------------------------------------------------------------------

    def _register(self, config: dict[str, Any]) -> None:
        """Build StateMachine + Orchestrator from a config dict and cache."""
        machine = StateMachine.from_dict(config)
        name = machine.name

        if self._guards:
            machine.bind_guards(self._guards)
        if self._actions:
            machine.bind_actions(self._actions)

        executor = ActionExecutor(
            self._actions or machine.action_registry,
            log_execution=True,
        )

        orchestrator = Orchestrator(
            machine=machine,
            state_store=self._store,
            guards=self._guards,
            actions=self._actions,
            executor=executor,
        )

        self._machines[name] = machine
        self._orchestrators[name] = orchestrator
        logger.debug("Registered machine %r (v%s)", name, machine.version)

    # ------------------------------------------------------------------
    # Internal: load from database
    # ------------------------------------------------------------------

    def _load_from_db(self) -> None:
        """Load all machine definitions from the ``machines`` table."""
        if not self._db_url:
            raise ValueError(
                "db_url is required when machine_source='db'.  "
                "Set PYSTATOR_DATABASE_URL or pass db_url to WorkerConfig."
            )

        from pystator.db.base import get_session
        from pystator.db.models.machine import MachineModel

        session = get_session(self._db_url)
        try:
            rows = session.query(MachineModel).all()
            if not rows:
                logger.warning(
                    "No machines found in database.  "
                    "Use the API or 'pystator db seed' to add machines."
                )
                return

            # Group by name and take the latest version
            latest: dict[str, MachineModel] = {}
            for row in rows:
                existing = latest.get(row.name)
                if existing is None or (row.version > existing.version):
                    latest[row.name] = row

            for row in latest.values():
                try:
                    self._register(row.config_json)
                except Exception as exc:
                    logger.error(
                        "Failed to load machine %r v%s: %s",
                        row.name,
                        row.version,
                        exc,
                    )
        finally:
            session.close()

    # ------------------------------------------------------------------
    # Internal: load from YAML directory
    # ------------------------------------------------------------------

    def _load_from_yaml(self) -> None:
        """Load machine definitions from ``*.yaml`` files in *machine_dir*."""
        if not self._machine_dir:
            raise ValueError("machine_dir is required when machine_source='yaml'.")

        yaml_dir = Path(self._machine_dir)
        if not yaml_dir.is_dir():
            raise FileNotFoundError(f"machine_dir does not exist: {yaml_dir}")

        yaml_files = sorted(yaml_dir.glob("*.yaml")) + sorted(yaml_dir.glob("*.yml"))
        if not yaml_files:
            logger.warning("No YAML files found in %s", yaml_dir)
            return

        import yaml  # pyyaml is a base dependency

        for path in yaml_files:
            try:
                with open(path) as f:
                    config = yaml.safe_load(f)
                if config:
                    self._register(config)
            except Exception as exc:
                logger.error("Failed to load %s: %s", path, exc)
