"""Worker configuration.

Resolved in priority order:

    1. Constructor arguments (highest)
    2. Environment variables (``PYSTATOR_WORKER_*``)
    3. ``pystator.cfg`` ``[worker]`` section
    4. Built-in defaults (lowest)
"""

from __future__ import annotations

import os
import platform
import uuid
from configparser import ConfigParser
from dataclasses import dataclass, field
from typing import Any

from pystator.config.database import get_database_url
from pystator.config.paths import find_config_file


def _default_worker_id() -> str:
    """Generate a unique worker ID: ``hostname-pid-uuid8``."""
    host = platform.node() or "worker"
    pid = os.getpid()
    short_uuid = uuid.uuid4().hex[:8]
    return f"{host}-{pid}-{short_uuid}"


def _read_cfg_section() -> dict[str, str]:
    """Read ``[worker]`` section from ``pystator.cfg`` if it exists."""
    cfg_path = find_config_file("pystator.cfg")
    if cfg_path is None:
        return {}
    parser = ConfigParser()
    parser.read(cfg_path)
    if not parser.has_section("worker"):
        return {}
    return dict(parser.items("worker"))


def _env(key: str) -> str | None:
    """Read a ``PYSTATOR_WORKER_*`` environment variable."""
    return os.getenv(f"PYSTATOR_WORKER_{key}")


@dataclass
class WorkerConfig:
    """Configuration for the PyStator worker process.

    Every field has a sensible default so that ``WorkerConfig()`` works
    out of the box (reads ``db_url`` from the standard pystator config
    resolution chain).

    Attributes:
        db_url: SQLAlchemy database URL.  Falls back to
            :func:`pystator.config.database.get_database_url`.
        poll_interval_ms: Milliseconds between event-source polls.
        concurrency: Number of concurrent event-processor tasks.
        drain_timeout_s: Seconds to wait for in-flight events on
            graceful shutdown.
        max_attempts: Default max processing attempts per event.
        machine_source: Where to load machine definitions from.
            ``"db"`` reads from the ``machines`` table; ``"yaml"``
            reads YAML files from *machine_dir*.
        machine_dir: Directory of YAML machine configs (only when
            ``machine_source == "yaml"``).
        worker_id: Unique ID for this worker replica.
            Auto-generated if not provided.
        claim_lease_timeout_s: Seconds after which a claimed event is
            considered abandoned and released back to pending (stale-claim
            recovery). Default 300.
        retry_backoff_base_ms: Base delay in ms for retry backoff;
            actual delay is min(retry_backoff_max_ms, base * 2^attempt).
            Default 1000.
        retry_backoff_max_ms: Maximum retry backoff in ms. Default 300000.
    """

    db_url: str | None = None
    poll_interval_ms: int = 500
    concurrency: int = 5
    drain_timeout_s: int = 30
    max_attempts: int = 5
    machine_source: str = "db"
    machine_dir: str | None = None
    worker_id: str = field(default_factory=_default_worker_id)
    claim_lease_timeout_s: int = 300
    retry_backoff_base_ms: int = 1000
    retry_backoff_max_ms: int = 300000

    def __post_init__(self) -> None:
        cfg = _read_cfg_section()

        # Resolve db_url: constructor > env > cfg > global pystator resolution
        if self.db_url is None:
            self.db_url = _env("DB_URL") or cfg.get("db_url") or get_database_url()

        # Resolve numeric settings: constructor default > env > cfg
        self.poll_interval_ms = int(
            _env("POLL_INTERVAL_MS")
            or cfg.get("poll_interval_ms")
            or self.poll_interval_ms
        )
        self.concurrency = int(
            _env("CONCURRENCY") or cfg.get("concurrency") or self.concurrency
        )
        self.drain_timeout_s = int(
            _env("DRAIN_TIMEOUT_S")
            or cfg.get("drain_timeout_s")
            or self.drain_timeout_s
        )
        self.max_attempts = int(
            _env("MAX_ATTEMPTS") or cfg.get("max_attempts") or self.max_attempts
        )

        # Machine source
        self.machine_source = (
            _env("MACHINE_SOURCE") or cfg.get("machine_source") or self.machine_source
        )
        if self.machine_dir is None:
            self.machine_dir = _env("MACHINE_DIR") or cfg.get("machine_dir")

        # Worker ID (rarely overridden)
        env_wid = _env("ID")
        if env_wid:
            self.worker_id = env_wid

        # Stale-claim and retry backoff
        self.claim_lease_timeout_s = int(
            _env("CLAIM_LEASE_TIMEOUT_S")
            or cfg.get("claim_lease_timeout_s")
            or self.claim_lease_timeout_s
        )
        self.retry_backoff_base_ms = int(
            _env("RETRY_BACKOFF_BASE_MS")
            or cfg.get("retry_backoff_base_ms")
            or self.retry_backoff_base_ms
        )
        self.retry_backoff_max_ms = int(
            _env("RETRY_BACKOFF_MAX_MS")
            or cfg.get("retry_backoff_max_ms")
            or self.retry_backoff_max_ms
        )

    def resolve_db_url(self) -> str:
        """Return the database URL, raising if none can be resolved."""
        if self.db_url:
            return self.db_url
        raise ValueError(
            "No database URL configured for worker.  Provide db_url, "
            "set PYSTATOR_DATABASE_URL, or configure pystator.cfg [database]."
        )
