"""Database-backed event source (default, no extra infrastructure).

Uses the ``worker_events`` table for durable event storage and atomic
claim-based deduplication.

PostgreSQL:
    ``SELECT … FOR UPDATE SKIP LOCKED`` ensures that multiple worker
    replicas never claim the same event.

SQLite:
    A simpler ``UPDATE … WHERE`` is used, suitable for single-worker
    development/testing.
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timedelta, timezone
from functools import partial
from typing import Any

from sqlalchemy import func, text, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from pystator.db.base import get_engine, get_schema_prefix
from pystator.db.models.worker_event import WorkerEventModel
from pystator.worker.config import WorkerConfig
from pystator.worker.event_sources.base import EventSource
from pystator.worker.models import ClaimedEvent, EventStatus, WorkerEvent

logger = logging.getLogger(__name__)

# Defaults when config is not passed (e.g. custom event source)
_DEFAULT_CLAIM_LEASE_TIMEOUT_S = 300
_DEFAULT_RETRY_BACKOFF_BASE_MS = 1000
_DEFAULT_RETRY_BACKOFF_MAX_MS = 300000


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


class DatabaseEventSource(EventSource):
    """Event source backed by the ``worker_events`` database table.

    Works with PostgreSQL (multi-replica, ``SKIP LOCKED``) and SQLite
    (single-worker, simple ``UPDATE``).

    Args:
        db_url: SQLAlchemy database URL.
        config: Optional worker config for claim lease timeout and retry backoff.
    """

    def __init__(self, db_url: str, config: WorkerConfig | None = None) -> None:
        self._db_url = db_url
        self._config = config
        self._engine = get_engine(db_url)
        self._is_postgres = not db_url.startswith("sqlite://")
        self._prefix = get_schema_prefix(db_url)
        self._table = f"{self._prefix}worker_events"
        self._SessionFactory = __import__(
            "sqlalchemy.orm", fromlist=["sessionmaker"]
        ).sessionmaker(bind=self._engine)

        self._claim_lease_timeout_s = (
            config.claim_lease_timeout_s if config else _DEFAULT_CLAIM_LEASE_TIMEOUT_S
        )
        self._retry_backoff_base_ms = (
            config.retry_backoff_base_ms if config else _DEFAULT_RETRY_BACKOFF_BASE_MS
        )
        self._retry_backoff_max_ms = (
            config.retry_backoff_max_ms if config else _DEFAULT_RETRY_BACKOFF_MAX_MS
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _session(self) -> Session:
        return self._SessionFactory()

    async def _run_sync(self, fn: Any, *args: Any, **kwargs: Any) -> Any:
        """Run a synchronous DB function in the default executor."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, partial(fn, *args, **kwargs))

    # ------------------------------------------------------------------
    # EventSource interface
    # ------------------------------------------------------------------

    async def submit(self, event: WorkerEvent) -> str:
        """Insert a new event into the queue."""
        return await self._run_sync(self._submit_sync, event)

    async def claim_next(self, worker_id: str) -> ClaimedEvent | None:
        """Atomically claim the next eligible event."""
        return await self._run_sync(self._claim_next_sync, worker_id)

    async def complete(self, event_id: str, result: Any = None) -> None:
        """Mark event as completed, optionally storing a result payload."""
        await self._run_sync(self._complete_sync, event_id, result)

    async def fail(
        self,
        event_id: str,
        error: str,
        *,
        retry: bool = True,
    ) -> None:
        """Mark event as failed; re-queue if retries remain."""
        await self._run_sync(self._fail_sync, event_id, error, retry)

    async def health_check(self) -> bool:
        """Check that the database is reachable."""
        try:
            return await self._run_sync(self._health_check_sync)
        except Exception:
            return False

    async def pending_count(self) -> int:
        """Return approximate count of pending events."""
        try:
            return await self._run_sync(self._pending_count_sync)
        except Exception:
            return -1

    async def close(self) -> None:
        """Dispose of the engine connection pool."""
        if self._engine is not None:
            self._engine.dispose()

    # ------------------------------------------------------------------
    # Synchronous implementations
    # ------------------------------------------------------------------

    def _submit_sync(self, event: WorkerEvent) -> str:
        session = self._session()
        try:
            event_id = str(uuid.uuid4())
            now = _utc_now()
            fires_at = event.fires_at or now

            if event.idempotency_key and self._is_postgres:
                # Idempotent submit: return existing id on duplicate key
                result = session.execute(
                    text(f"""
                        INSERT INTO {self._table}
                        (id, machine_name, entity_id, trigger, context_json, status,
                         fires_at, attempt, max_attempts, idempotency_key, created_at)
                        VALUES
                        (:id, :machine_name, :entity_id, :trigger, :context_json, 'pending',
                         :fires_at, 0, :max_attempts, :idempotency_key, :created_at)
                        ON CONFLICT (idempotency_key) DO UPDATE SET id = {self._table}.id
                        RETURNING id
                    """),
                    {
                        "id": event_id,
                        "machine_name": event.machine_name,
                        "entity_id": event.entity_id,
                        "trigger": event.trigger,
                        "context_json": event.context,
                        "fires_at": fires_at,
                        "max_attempts": event.max_attempts,
                        "idempotency_key": event.idempotency_key,
                        "created_at": now,
                    },
                )
                row = result.mappings().first()
                session.commit()
                out_id = str(row["id"])
                logger.debug(
                    "Submitted event %s (idempotency_key=%s): %s/%s/%s",
                    out_id,
                    event.idempotency_key,
                    event.machine_name,
                    event.entity_id,
                    event.trigger,
                )
                return out_id

            if event.idempotency_key and not self._is_postgres:
                # SQLite: try insert; on conflict return existing id
                try:
                    row = WorkerEventModel(
                        id=event_id,
                        machine_name=event.machine_name,
                        entity_id=event.entity_id,
                        trigger=event.trigger,
                        context_json=event.context,
                        status=EventStatus.PENDING.value,
                        fires_at=fires_at,
                        attempt=0,
                        max_attempts=event.max_attempts,
                        idempotency_key=event.idempotency_key,
                        created_at=now,
                    )
                    session.add(row)
                    session.commit()
                    return event_id
                except IntegrityError:
                    session.rollback()
                    existing = (
                        session.query(WorkerEventModel.id)
                        .filter(
                            WorkerEventModel.idempotency_key == event.idempotency_key
                        )
                        .first()
                    )
                    if existing:
                        return str(existing[0])
                    raise
            # No idempotency key: plain insert
            row = WorkerEventModel(
                id=event_id,
                machine_name=event.machine_name,
                entity_id=event.entity_id,
                trigger=event.trigger,
                context_json=event.context,
                status=EventStatus.PENDING.value,
                fires_at=fires_at,
                attempt=0,
                max_attempts=event.max_attempts,
                idempotency_key=event.idempotency_key,
                created_at=now,
            )
            session.add(row)
            session.commit()
            logger.debug(
                "Submitted event %s: %s/%s/%s",
                event_id,
                event.machine_name,
                event.entity_id,
                event.trigger,
            )
            return event_id
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _release_stale_claims_sync(self) -> None:
        """Release events claimed longer than claim_lease_timeout_s (stale-claim recovery)."""
        session = self._session()
        try:
            # Use raw SQL so schema prefix is applied
            session.execute(
                text(f"""
                    UPDATE {self._table}
                    SET status = 'pending', claimed_by = NULL, claimed_at = NULL
                    WHERE status = 'claimed'
                      AND claimed_at < :cutoff
                """),
                {"cutoff": _utc_now() - timedelta(seconds=self._claim_lease_timeout_s)},
            )
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _claim_next_sync(self, worker_id: str) -> ClaimedEvent | None:
        self._release_stale_claims_sync()
        if self._is_postgres:
            return self._claim_next_postgres(worker_id)
        return self._claim_next_sqlite(worker_id)

    def _claim_next_postgres(self, worker_id: str) -> ClaimedEvent | None:
        """PostgreSQL: atomic claim via SELECT FOR UPDATE SKIP LOCKED."""
        session = self._session()
        now = _utc_now()
        table = self._table
        try:
            # Use raw SQL for the CTE + SKIP LOCKED claim pattern
            result = session.execute(
                text(f"""
                    WITH claimable AS (
                        SELECT we.id
                        FROM {table} we
                        WHERE we.status = 'pending'
                          AND we.fires_at <= :now
                          AND NOT EXISTS (
                              SELECT 1 FROM {table} we2
                              WHERE we2.entity_id = we.entity_id
                                AND we2.machine_name = we.machine_name
                                AND we2.status = 'claimed'
                          )
                        ORDER BY we.fires_at ASC
                        LIMIT 1
                        FOR UPDATE SKIP LOCKED
                    )
                    UPDATE {table}
                    SET status = 'claimed',
                        claimed_by = :worker_id,
                        claimed_at = :now,
                        attempt = attempt + 1
                    FROM claimable
                    WHERE {table}.id = claimable.id
                    RETURNING *
                """),
                {"now": now, "worker_id": worker_id},
            )
            row = result.mappings().first()
            session.commit()

            if row is None:
                return None

            return ClaimedEvent(
                event_id=str(row["id"]),
                machine_name=row["machine_name"],
                entity_id=row["entity_id"],
                trigger=row["trigger"],
                context=dict(row["context_json"]) if row["context_json"] else {},
                attempt=row["attempt"],
                max_attempts=row["max_attempts"],
                fires_at=row["fires_at"],
                claimed_at=now,
            )
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _claim_next_sqlite(self, worker_id: str) -> ClaimedEvent | None:
        """SQLite: simple UPDATE-based claim (single-worker safe)."""
        session = self._session()
        now = _utc_now()
        table = self._table
        try:
            # Use raw SQL to correctly reference the outer row in the
            # NOT EXISTS subquery (avoids ORM self-join pitfalls).
            result = session.execute(
                text(f"""
                    SELECT id, machine_name, entity_id, trigger, context_json,
                           attempt, max_attempts, fires_at
                    FROM {table} we
                    WHERE we.status = 'pending'
                      AND we.fires_at <= :now
                      AND NOT EXISTS (
                          SELECT 1 FROM {table} we2
                          WHERE we2.entity_id = we.entity_id
                            AND we2.machine_name = we.machine_name
                            AND we2.status = 'claimed'
                      )
                    ORDER BY we.fires_at ASC
                    LIMIT 1
                """),
                {"now": now},
            )
            candidate = result.mappings().first()

            if candidate is None:
                return None

            event_id = str(candidate["id"])
            new_attempt = (candidate["attempt"] or 0) + 1

            # Claim it (simple UPDATE; safe for single-worker)
            session.execute(
                text(f"""
                    UPDATE {table}
                    SET status = 'claimed',
                        claimed_by = :worker_id,
                        claimed_at = :now,
                        attempt = :attempt
                    WHERE id = :event_id
                """),
                {
                    "worker_id": worker_id,
                    "now": now,
                    "attempt": new_attempt,
                    "event_id": event_id,
                },
            )
            session.commit()

            ctx_json = candidate["context_json"]
            return ClaimedEvent(
                event_id=event_id,
                machine_name=candidate["machine_name"],
                entity_id=candidate["entity_id"],
                trigger=candidate["trigger"],
                context=dict(ctx_json) if ctx_json else {},
                attempt=new_attempt,
                max_attempts=candidate["max_attempts"],
                fires_at=candidate["fires_at"],
                claimed_at=now,
            )
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _complete_sync(self, event_id: str, result: Any = None) -> None:
        session = self._session()
        try:
            session.execute(
                update(WorkerEventModel)
                .where(WorkerEventModel.id == event_id)
                .values(
                    status=EventStatus.COMPLETED.value,
                    completed_at=_utc_now(),
                    result_json=result,
                )
            )
            session.commit()
            logger.debug("Completed event %s", event_id)
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _fail_sync(self, event_id: str, error: str, retry: bool) -> None:
        session = self._session()
        try:
            row = (
                session.query(WorkerEventModel)
                .filter(WorkerEventModel.id == event_id)
                .first()
            )
            if row is None:
                return

            can_retry = retry and row.attempt < row.max_attempts

            if can_retry:
                # Retry backoff: fires_at = now + min(max_ms, base_ms * 2^attempt)
                backoff_ms = min(
                    self._retry_backoff_max_ms,
                    self._retry_backoff_base_ms * (2**row.attempt),
                )
                row.status = EventStatus.PENDING.value
                row.claimed_by = None
                row.claimed_at = None
                row.error_message = error
                row.fires_at = _utc_now() + timedelta(milliseconds=backoff_ms)
                logger.info(
                    "Event %s failed (attempt %d/%d), re-queued in %dms: %s",
                    event_id,
                    row.attempt,
                    row.max_attempts,
                    backoff_ms,
                    error,
                )
            else:
                row.status = EventStatus.DEAD_LETTER.value
                row.error_message = error
                row.completed_at = _utc_now()
                logger.warning(
                    "Event %s moved to dead letter after %d attempts: %s",
                    event_id,
                    row.attempt,
                    error,
                )

            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _health_check_sync(self) -> bool:
        session = self._session()
        try:
            session.execute(text("SELECT 1"))
            return True
        finally:
            session.close()

    def _pending_count_sync(self) -> int:
        session = self._session()
        try:
            count = (
                session.query(func.count(WorkerEventModel.id))
                .filter(WorkerEventModel.status == EventStatus.PENDING.value)
                .scalar()
            )
            return count or 0
        finally:
            session.close()
