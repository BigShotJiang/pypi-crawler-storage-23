"""Abstract base class for event sources.

An event source is the durable queue that stores, claims, and tracks
worker events.  The default implementation uses a database table
(:class:`DatabaseEventSource`); alternative backends (e.g. Redis Streams)
can be added by implementing this interface.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from pystator.worker.models import ClaimedEvent, WorkerEvent


class EventSource(ABC):
    """Abstract interface for a durable, claimable event queue.

    Implementations must guarantee that :meth:`claim_next` is atomic:
    at most one worker can claim a given event, and at most one event
    per ``(entity_id, machine_name)`` is in-flight at a time.
    """

    @abstractmethod
    async def submit(self, event: WorkerEvent) -> str:
        """Insert an event into the queue.

        Args:
            event: The event to enqueue.

        Returns:
            The unique ``event_id`` assigned to the persisted event.
        """
        ...

    @abstractmethod
    async def claim_next(self, worker_id: str) -> ClaimedEvent | None:
        """Atomically claim the next eligible event.

        An event is eligible when:
        - ``status == 'pending'``
        - ``fires_at <= now``
        - No other event for the same ``(entity_id, machine_name)``
          is currently ``'claimed'``

        Args:
            worker_id: Identifier of the claiming worker replica.

        Returns:
            A :class:`ClaimedEvent` if one was claimed, or ``None``
            if the queue is empty or all eligible events are locked.
        """
        ...

    @abstractmethod
    async def complete(self, event_id: str, result: Any = None) -> None:
        """Mark a claimed event as successfully completed.

        Args:
            event_id: The ``event_id`` from the :class:`ClaimedEvent`.
            result: Optional result payload (JSON-serializable) to persist
                for API or callers to read later.
        """
        ...

    @abstractmethod
    async def fail(
        self,
        event_id: str,
        error: str,
        *,
        retry: bool = True,
    ) -> None:
        """Mark a claimed event as failed.

        If *retry* is ``True`` **and** ``attempt < max_attempts``, the
        event is returned to ``'pending'`` status so it will be retried.
        Otherwise it moves to ``'dead_letter'``.

        Args:
            event_id: The ``event_id`` from the :class:`ClaimedEvent`.
            error: Human-readable error description.
            retry: Whether to allow retry.
        """
        ...

    @abstractmethod
    async def health_check(self) -> bool:
        """Return ``True`` if the backend is reachable and operational."""
        ...

    async def pending_count(self) -> int:
        """Return the approximate number of pending events.

        Implementations may override for an efficient count.
        The default returns ``-1`` (unknown).
        """
        return -1

    async def close(self) -> None:
        """Release resources held by this event source.

        Override if the implementation holds connections or background
        tasks that need cleanup.
        """
        pass
