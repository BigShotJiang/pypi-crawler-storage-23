"""Pluggable event source adapters for the PyStator worker.

The default implementation is :class:`DatabaseEventSource` which uses the
``worker_events`` table and requires no extra infrastructure.

To add a custom event source, implement :class:`EventSource` and pass
an instance to :class:`~pystator.worker.Worker`.
"""

from pystator.worker.event_sources.base import EventSource
from pystator.worker.event_sources.database import DatabaseEventSource

__all__ = [
    "EventSource",
    "DatabaseEventSource",
]
