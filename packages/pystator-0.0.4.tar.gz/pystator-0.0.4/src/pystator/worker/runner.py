"""Worker runner: the main lifecycle for the PyStator worker service.

:class:`Worker` is the single entry-point that wires together the
event source, machine registry, processor, and health checker.  It
runs N concurrent poller tasks, handles graceful shutdown on
``SIGTERM``/``SIGINT``, and drains in-flight events before exiting.
"""

from __future__ import annotations

import asyncio
import logging
import signal
from typing import Any

from pystator.actions import ActionRegistry
from pystator.guards import GuardRegistry
from pystator.stores.base import InMemoryStateStore
from pystator.worker.config import WorkerConfig
from pystator.worker.event_sources.base import EventSource
from pystator.worker.event_sources.database import DatabaseEventSource
from pystator.worker.health import HealthChecker
from pystator.worker.processor import EventProcessor
from pystator.worker.registry import MachineRegistry

logger = logging.getLogger(__name__)


class Worker:
    """PyStator worker: a long-running event-processing service.

    Usage::

        from pystator.worker import Worker

        worker = Worker()
        await worker.start()
        await worker.run()   # blocks until shutdown signal

    With custom guards and actions::

        from pystator import GuardRegistry, ActionRegistry
        from pystator.worker import Worker

        guards = GuardRegistry()
        actions = ActionRegistry()

        @guards.register("is_full_fill")
        def is_full_fill(ctx):
            return ctx["fill_qty"] >= ctx["order_qty"]

        worker = Worker(guards=guards, actions=actions)
        await worker.start()
        await worker.run()

    Args:
        config: Worker configuration.  Defaults to :class:`WorkerConfig`
            which reads from ``pystator.cfg`` / environment.
        guards: Guard registry bound to all loaded machines.
        actions: Action registry bound to all loaded machines.
        event_source: Custom event source.  When ``None``, a
            :class:`DatabaseEventSource` is created from the config.
    """

    def __init__(
        self,
        config: WorkerConfig | None = None,
        guards: GuardRegistry | None = None,
        actions: ActionRegistry | None = None,
        *,
        event_source: EventSource | None = None,
    ) -> None:
        self._config = config or WorkerConfig()
        self._guards = guards or GuardRegistry()
        self._actions = actions or ActionRegistry()
        self._custom_event_source = event_source

        # Initialised in start()
        self._event_source: EventSource | None = None
        self._registry: MachineRegistry | None = None
        self._processor: EventProcessor | None = None
        self._health: HealthChecker | None = None

        # Shutdown coordination
        self._shutdown_event = asyncio.Event()
        self._in_flight: int = 0
        self._started = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Initialise connections, load machines, verify readiness.

        Must be called before :meth:`run`.
        """
        config = self._config
        db_url = config.resolve_db_url()

        # Event source
        if self._custom_event_source is not None:
            self._event_source = self._custom_event_source
        else:
            self._event_source = DatabaseEventSource(db_url, config=config)

        # State store for the Orchestrators (sync protocol).
        # Use SQLAlchemy store if available, otherwise in-memory.
        state_store = self._create_state_store(db_url)

        # Machine registry
        self._registry = MachineRegistry(
            state_store=state_store,
            guards=self._guards,
            actions=self._actions,
            db_url=db_url,
            machine_source=config.machine_source,
            machine_dir=config.machine_dir,
        )
        self._registry.load()

        # Processor
        self._processor = EventProcessor(
            registry=self._registry,
            event_source=self._event_source,
        )

        # Health checker
        self._health = HealthChecker(
            event_source=self._event_source,
            registry=self._registry,
        )

        self._started = True
        logger.info(
            "Worker %s started (concurrency=%d, poll=%dms, machines=%d)",
            config.worker_id,
            config.concurrency,
            config.poll_interval_ms,
            self._registry.machine_count,
        )

    async def run(self) -> None:
        """Block and process events until a shutdown signal is received.

        Spawns ``config.concurrency`` poller tasks.  Each poller claims
        events, processes them, then sleeps for ``poll_interval_ms``
        before the next claim.

        Handles ``SIGTERM`` and ``SIGINT`` for graceful shutdown.
        """
        if not self._started:
            raise RuntimeError("Worker.start() must be called before run()")

        # Install signal handlers
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            loop.add_signal_handler(sig, self._request_shutdown, sig)

        config = self._config
        tasks: list[asyncio.Task[None]] = []

        for idx in range(config.concurrency):
            task = asyncio.create_task(
                self._poll_loop(idx),
                name=f"worker-poller-{idx}",
            )
            tasks.append(task)

        logger.info(
            "Worker %s running with %d poller(s)",
            config.worker_id,
            config.concurrency,
        )

        # Wait for shutdown signal
        await self._shutdown_event.wait()

        logger.info("Shutdown requested, draining in-flight events...")

        # Cancel pollers (they will stop after their current iteration)
        for task in tasks:
            task.cancel()

        # Wait for in-flight events to complete (with timeout)
        await self._drain(config.drain_timeout_s)

        # Cleanup
        await self._cleanup()

        logger.info("Worker %s stopped", config.worker_id)

    async def shutdown(self) -> None:
        """Programmatically trigger a graceful shutdown."""
        self._shutdown_event.set()

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def health(self) -> HealthChecker | None:
        """Health checker (available after :meth:`start`)."""
        return self._health

    @property
    def config(self) -> WorkerConfig:
        return self._config

    # ------------------------------------------------------------------
    # Internal: poll loop
    # ------------------------------------------------------------------

    async def _poll_loop(self, idx: int) -> None:
        """Single poller task: claim -> process -> sleep -> repeat."""
        assert self._event_source is not None
        assert self._processor is not None

        config = self._config
        poll_interval = config.poll_interval_ms / 1000.0

        try:
            while not self._shutdown_event.is_set():
                claimed = await self._event_source.claim_next(
                    config.worker_id,
                )

                if claimed is not None:
                    self._in_flight += 1
                    try:
                        await self._processor.process_one(claimed)
                    except Exception as exc:
                        logger.exception(
                            "Poller-%d: unhandled error processing %s: %s",
                            idx,
                            claimed.event_id,
                            exc,
                        )
                        try:
                            await self._event_source.fail(
                                claimed.event_id,
                                f"Unhandled: {type(exc).__name__}: {exc}",
                                retry=True,
                            )
                        except Exception:
                            logger.exception(
                                "Failed to mark event %s as failed",
                                claimed.event_id,
                            )
                    finally:
                        self._in_flight -= 1
                else:
                    # No events available; sleep before polling again
                    await asyncio.sleep(poll_interval)
        except asyncio.CancelledError:
            logger.debug("Poller-%d cancelled", idx)

    # ------------------------------------------------------------------
    # Internal: shutdown helpers
    # ------------------------------------------------------------------

    def _request_shutdown(self, sig: signal.Signals) -> None:
        logger.info("Received %s, initiating shutdown", sig.name)
        self._shutdown_event.set()

    async def _drain(self, timeout_s: int) -> None:
        """Wait for in-flight events to finish, up to *timeout_s*."""
        if self._in_flight == 0:
            return

        logger.info("Waiting for %d in-flight event(s)...", self._in_flight)

        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout_s
        while self._in_flight > 0:
            remaining = deadline - loop.time()
            if remaining <= 0:
                logger.warning(
                    "Drain timeout (%ds): %d event(s) still in flight",
                    timeout_s,
                    self._in_flight,
                )
                break
            await asyncio.sleep(min(0.5, remaining))

    async def _cleanup(self) -> None:
        """Close event source and other resources."""
        if self._event_source is not None:
            try:
                await self._event_source.close()
            except Exception as exc:
                logger.warning("Error closing event source: %s", exc)

    # ------------------------------------------------------------------
    # Internal: state store factory
    # ------------------------------------------------------------------

    @staticmethod
    def _create_state_store(db_url: str) -> Any:
        """Create a sync state store from the database URL.

        Tries :class:`SQLAlchemyStateStore` first (for real persistence);
        falls back to :class:`InMemoryStateStore` if the schema is not
        initialised or the store module is unavailable.
        """
        try:
            from pystator.stores.sqlalchemy import SQLAlchemyStateStore

            store = SQLAlchemyStateStore(db_url)
            store.connect(validate_schema=True, auto_initialize=True)
            return store
        except Exception as exc:
            logger.warning(
                "Could not create SQLAlchemy state store (%s); "
                "falling back to InMemoryStateStore.  Entity state will "
                "not be persisted across worker restarts.",
                exc,
            )
            return InMemoryStateStore()
