"""Data models for the PyStator worker service.

Defines the event envelope (:class:`WorkerEvent`) that external callers
use to submit work, :class:`ClaimedEvent` that the processor receives
after a successful claim, and :class:`EventStatus` for the event
lifecycle.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class EventStatus(str, Enum):
    """Lifecycle status of a worker event."""

    PENDING = "pending"
    """Event is queued and waiting to be claimed."""

    CLAIMED = "claimed"
    """Event has been claimed by a worker and is being processed."""

    COMPLETED = "completed"
    """Event was processed successfully."""

    FAILED = "failed"
    """Processing failed but may be retried."""

    DEAD_LETTER = "dead_letter"
    """Processing failed and max attempts have been exhausted."""


@dataclass(frozen=True)
class WorkerEvent:
    """Immutable event envelope submitted by callers.

    Args:
        machine_name: Name of the FSM machine to route to.
        entity_id: Identifier for the entity (e.g. ``"order-123"``).
        trigger: The event trigger name (e.g. ``"fill"``).
        context: Optional dict passed to guards and actions.
        fires_at: When the event becomes eligible for processing.
            ``None`` means immediately.
        idempotency_key: Optional client-supplied dedup key.
            If a pending/claimed event with the same key already exists,
            the submission is silently skipped.
        max_attempts: Maximum number of processing attempts before the
            event moves to dead-letter.
    """

    machine_name: str
    entity_id: str
    trigger: str
    context: dict[str, Any] | None = None
    fires_at: datetime | None = None
    idempotency_key: str | None = None
    max_attempts: int = 5


@dataclass
class ClaimedEvent:
    """An event that has been atomically claimed by a worker.

    The :class:`EventProcessor` receives this after a successful claim
    from the event source.  ``event_id`` is used to complete or fail the
    event after processing.
    """

    event_id: str
    machine_name: str
    entity_id: str
    trigger: str
    context: dict[str, Any]
    attempt: int
    max_attempts: int
    fires_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    claimed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
