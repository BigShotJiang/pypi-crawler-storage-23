"""Reference guards and actions for core trading FSMs (portfolio, optimization, order, intraday).

Use with machines from data/seed/trading_machines.yaml:
  - machine.bind_guards(get_core_guard_registry())
  - ActionExecutor.execute(transition_result, context, get_core_action_registry())

These are stubs/reference implementations. Override individual guards or actions
in your own registries for real policy and side effects.
"""

from .guards import (
    acceptable_turnover,
    all_orders_filled_or_cancelled,
    auto_approval_enabled,
    can_safely_cancel,
    cooldown_elapsed,
    data_quality_sufficient,
    drift_exceeds_threshold,
    is_full_fill,
    is_partial_fill,
    is_within_trading_hours,
    order_list_empty,
    passes_risk_constraints,
    requires_approval,
    retry_optimization_allowed,
    risk_actually_cleared,
)
from .registry import get_core_action_registry, get_core_guard_registry

__all__ = [
    "get_core_guard_registry",
    "get_core_action_registry",
    "acceptable_turnover",
    "all_orders_filled_or_cancelled",
    "auto_approval_enabled",
    "can_safely_cancel",
    "cooldown_elapsed",
    "data_quality_sufficient",
    "drift_exceeds_threshold",
    "is_full_fill",
    "is_partial_fill",
    "is_within_trading_hours",
    "order_list_empty",
    "passes_risk_constraints",
    "requires_approval",
    "retry_optimization_allowed",
    "risk_actually_cleared",
]
