"""Build guard and action registries with all core trading FSM guards and actions.

Use get_core_guard_registry() and get_core_action_registry() to bind to
machines loaded from trading_machines.yaml. Apps can clone and override
individual entries for custom policy or side effects.
"""

from __future__ import annotations

from pystator.actions import ActionRegistry
from pystator.guards import GuardRegistry

from . import actions as actions_mod
from . import guards as guards_mod

_SKIP_NAMES = frozenset({"Any"})  # typing / builtins to avoid registering


def _collect_guards() -> dict[str, object]:
    """All guard names -> callable from guards module (no private, no typing)."""
    out: dict[str, object] = {}
    for name in dir(guards_mod):
        if name.startswith("_") or name in _SKIP_NAMES:
            continue
        obj = getattr(guards_mod, name)
        if callable(obj) and getattr(obj, "__module__", "").startswith(
            "pystator.contrib"
        ):
            out[name] = obj
    return out


def _collect_actions() -> dict[str, object]:
    """All action names -> callable from actions module (no private, no typing)."""
    out: dict[str, object] = {}
    for name in dir(actions_mod):
        if name.startswith("_") or name in _SKIP_NAMES:
            continue
        obj = getattr(actions_mod, name)
        if callable(obj) and getattr(obj, "__module__", "").startswith(
            "pystator.contrib"
        ):
            out[name] = obj
    return out


_guard_registry: GuardRegistry | None = None
_action_registry: ActionRegistry | None = None


def get_core_guard_registry() -> GuardRegistry:
    """Return a GuardRegistry with all contrib trading guards registered."""
    global _guard_registry
    if _guard_registry is None:
        _guard_registry = GuardRegistry()
        for name, func in _collect_guards().items():
            _guard_registry.register(name, func)  # type: ignore[arg-type]
    return _guard_registry


def get_core_action_registry() -> ActionRegistry:
    """Return an ActionRegistry with all contrib trading actions registered."""
    global _action_registry
    if _action_registry is None:
        _action_registry = ActionRegistry()
        for name, func in _collect_actions().items():
            _action_registry.register(name, func)  # type: ignore[arg-type]
    return _action_registry
