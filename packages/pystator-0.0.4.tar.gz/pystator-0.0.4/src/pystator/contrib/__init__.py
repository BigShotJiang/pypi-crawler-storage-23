"""Contrib packages: reference guards and actions for core FSM examples."""

from pystator.contrib.trading import get_core_action_registry, get_core_guard_registry

__all__ = ["get_core_guard_registry", "get_core_action_registry"]
