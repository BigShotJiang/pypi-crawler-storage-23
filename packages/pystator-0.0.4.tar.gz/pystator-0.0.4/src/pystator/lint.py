"""FSM linting -- static analysis of state machine definitions.

Detects common configuration issues like unreachable states,
dead-end states, nondeterministic transitions, and missing
guard/action registrations.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pystator.machine import StateMachine


class LintSeverity(str, Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass(frozen=True, slots=True)
class LintWarning:
    """A single lint finding.

    Attributes:
        code: Machine-readable code (e.g., ``"unreachable_state"``).
        severity: ERROR, WARNING, or INFO.
        message: Human-readable description.
        context: Extra structured data about the finding.
    """

    code: str
    severity: LintSeverity
    message: str
    context: dict[str, Any]


def lint(machine: "StateMachine") -> list[LintWarning]:
    """Run all lint checks on a state machine. Returns a list of warnings."""
    warnings: list[LintWarning] = []
    warnings.extend(_check_unreachable_states(machine))
    warnings.extend(_check_dead_end_states(machine))
    warnings.extend(_check_dead_transitions(machine))
    warnings.extend(_check_nondeterministic(machine))
    warnings.extend(_check_missing_guards(machine))
    warnings.extend(_check_missing_actions(machine))
    return warnings


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------


def _check_unreachable_states(machine: "StateMachine") -> list[LintWarning]:
    """States not reachable from the initial state via any transition path."""
    initial = machine.get_initial_state().name
    reachable: set[str] = set()
    queue: deque[str] = deque([initial])

    while queue:
        state = queue.popleft()
        if state in reachable:
            continue
        reachable.add(state)
        for trans in machine.transitions:
            if state in trans.source and trans.dest not in reachable:
                queue.append(trans.dest)

    unreachable = set(machine.state_names) - reachable
    return [
        LintWarning(
            code="unreachable_state",
            severity=LintSeverity.WARNING,
            message=f"State '{s}' is not reachable from the initial state",
            context={"state": s},
        )
        for s in sorted(unreachable)
    ]


def _check_dead_end_states(machine: "StateMachine") -> list[LintWarning]:
    """Non-terminal states with no outbound transitions."""
    states_with_outbound: set[str] = set()
    for trans in machine.transitions:
        states_with_outbound.update(trans.source)

    warnings: list[LintWarning] = []
    for name, state in machine.states.items():
        if not state.is_terminal and name not in states_with_outbound:
            warnings.append(
                LintWarning(
                    code="dead_end",
                    severity=LintSeverity.WARNING,
                    message=f"Non-terminal state '{name}' has no outbound transitions",
                    context={"state": name},
                )
            )
    return warnings


def _check_dead_transitions(machine: "StateMachine") -> list[LintWarning]:
    """Transitions from terminal states (can never fire)."""
    terminal = set(machine.terminal_states)
    warnings: list[LintWarning] = []
    for trans in machine.transitions:
        from_terminal = trans.source & terminal
        if from_terminal:
            warnings.append(
                LintWarning(
                    code="dead_transition",
                    severity=LintSeverity.WARNING,
                    message=(
                        f"Transition '{trans.trigger}' from terminal state(s) "
                        f"{sorted(from_terminal)} can never fire"
                    ),
                    context={
                        "trigger": trans.trigger,
                        "sources": sorted(from_terminal),
                    },
                )
            )
    return warnings


def _check_nondeterministic(machine: "StateMachine") -> list[LintWarning]:
    """Multiple transitions with the same (trigger, source) but no guards."""
    from collections import defaultdict

    index: dict[tuple[str, str], list[Any]] = defaultdict(list)
    for trans in machine.transitions:
        for source in trans.source:
            index[(trans.trigger, source)].append(trans)

    warnings: list[LintWarning] = []
    for (trigger, source), transitions in index.items():
        if len(transitions) > 1:
            unguarded = [t for t in transitions if not t.guards]
            if unguarded:
                warnings.append(
                    LintWarning(
                        code="nondeterministic",
                        severity=LintSeverity.ERROR,
                        message=(
                            f"Nondeterministic: {len(transitions)} transitions for "
                            f"trigger '{trigger}' from '{source}', "
                            f"{len(unguarded)} without guards"
                        ),
                        context={
                            "trigger": trigger,
                            "source": source,
                            "total": len(transitions),
                            "unguarded": len(unguarded),
                        },
                    )
                )
    return warnings


def _check_missing_guards(machine: "StateMachine") -> list[LintWarning]:
    """Named guards referenced in transitions but not registered."""
    warnings: list[LintWarning] = []
    registry = machine.guard_registry
    for trans in machine.transitions:
        for guard in trans.guards:
            if guard.name and not registry.has(guard.name):
                warnings.append(
                    LintWarning(
                        code="missing_guard",
                        severity=LintSeverity.INFO,
                        message=f"Guard '{guard.name}' is not registered",
                        context={"guard": guard.name, "trigger": trans.trigger},
                    )
                )
    return warnings


def _check_missing_actions(machine: "StateMachine") -> list[LintWarning]:
    """Actions referenced in transitions/states but not registered."""
    warnings: list[LintWarning] = []
    registry = machine.action_registry
    seen: set[str] = set()

    # Transition actions
    for trans in machine.transitions:
        for action in trans.actions:
            if action.name not in seen and not registry.has(action.name):
                warnings.append(
                    LintWarning(
                        code="missing_action",
                        severity=LintSeverity.INFO,
                        message=f"Action '{action.name}' is not registered",
                        context={"action": action.name, "location": "transition"},
                    )
                )
                seen.add(action.name)

    # State on_enter/on_exit actions
    for state in machine.states.values():
        for action in (*state.on_enter, *state.on_exit):
            if action.name not in seen and not registry.has(action.name):
                warnings.append(
                    LintWarning(
                        code="missing_action",
                        severity=LintSeverity.INFO,
                        message=f"Action '{action.name}' is not registered",
                        context={
                            "action": action.name,
                            "location": f"state:{state.name}",
                        },
                    )
                )
                seen.add(action.name)

    return warnings
