"""Lightweight config parser -- no Pydantic dependency.

Converts raw config dicts directly to core _types objects.
Used when Pydantic is not installed or when validation is disabled.
"""

from __future__ import annotations

from typing import Any

from pystator._types import (
    ActionSpec,
    GuardSpec,
    InvokeSpec,
    Region,
    State,
    StateType,
    Timeout,
    Transition,
    parse_delay,
)

# ---------------------------------------------------------------------------
# Normalization helpers (replicates Pydantic field validators)
# ---------------------------------------------------------------------------


def _normalize_to_list(raw: Any) -> list[Any]:
    """Normalize a value to a list (handles None, str, dict, list)."""
    if raw is None:
        return []
    if isinstance(raw, str):
        return [raw]
    if isinstance(raw, dict):
        return [raw]
    if isinstance(raw, list):
        return list(raw)
    return []


def _parse_guard_specs(raw: Any) -> tuple[GuardSpec, ...]:
    """Parse guards field to tuple of GuardSpec."""
    items = _normalize_to_list(raw)
    return tuple(
        GuardSpec.from_config(item) if isinstance(item, dict) else GuardSpec(name=item)
        for item in items
    )


def _parse_action_specs(raw: Any) -> tuple[ActionSpec, ...]:
    """Parse actions/on_enter/on_exit field to tuple of ActionSpec."""
    items = _normalize_to_list(raw)
    return tuple(
        (
            ActionSpec.from_config(item)
            if isinstance(item, dict)
            else ActionSpec(name=item)
        )
        for item in items
    )


# ---------------------------------------------------------------------------
# Synthetic trigger generation (mirrors config/converter.py)
# ---------------------------------------------------------------------------


def _implicit_trigger_for_after(source: str, after_ms: int) -> str:
    return f"_after_{source}_{after_ms}_ms"


def _auto_trigger(source: str) -> str:
    return f"_auto_{source}"


# ---------------------------------------------------------------------------
# State parsing
# ---------------------------------------------------------------------------


def _parse_state(raw: dict[str, Any]) -> State:
    """Convert a raw state dict to a State object."""
    name = raw["name"]
    state_type = StateType(raw.get("type", "stable"))

    timeout = None
    timeout_raw = raw.get("timeout")
    if timeout_raw and isinstance(timeout_raw, dict):
        timeout = Timeout(
            seconds=float(timeout_raw["seconds"]),
            destination=timeout_raw["destination"],
        )

    regions = tuple(
        Region(
            name=r["name"],
            initial=r["initial"],
            states=tuple(r.get("states", ())),
            description=r.get("description", ""),
        )
        for r in raw.get("regions", [])
    )

    invoke = tuple(
        InvokeSpec(
            id=inv["id"],
            src=inv["src"],
            on_done=inv.get("on_done"),
        )
        for inv in raw.get("invoke", [])
    )

    # Collect metadata: explicit metadata field + any extra keys
    known_keys = {
        "name",
        "type",
        "description",
        "parent",
        "initial_child",
        "regions",
        "on_enter",
        "on_exit",
        "invoke",
        "timeout",
        "metadata",
    }
    metadata = dict(raw.get("metadata", {}))
    for k, v in raw.items():
        if k not in known_keys:
            metadata[k] = v

    return State(
        name=name,
        type=state_type,
        description=raw.get("description", ""),
        parent=raw.get("parent"),
        initial_child=raw.get("initial_child"),
        regions=regions,
        on_enter=_parse_action_specs(raw.get("on_enter")),
        on_exit=_parse_action_specs(raw.get("on_exit")),
        invoke=invoke,
        timeout=timeout,
        metadata=metadata,
    )


# ---------------------------------------------------------------------------
# Transition parsing
# ---------------------------------------------------------------------------


def _parse_transition(raw: dict[str, Any]) -> Transition:
    """Convert a raw transition dict to a Transition object."""
    source_raw = raw["source"]
    if isinstance(source_raw, str):
        source_list = [source_raw]
    elif isinstance(source_raw, list):
        source_list = list(source_raw)
    else:
        source_list = [str(source_raw)]
    source_set = frozenset(source_list)

    after_ms: int | None = None
    if raw.get("after") is not None:
        after_ms = parse_delay(raw["after"])

    trigger = (raw.get("trigger") or "").strip()

    # Generate synthetic trigger when not provided
    if not trigger:
        if after_ms is not None:
            if len(source_set) != 1:
                raise ValueError(
                    "Delayed transition with implicit trigger must have exactly one source"
                )
            (single_source,) = source_set
            trigger = _implicit_trigger_for_after(single_source, after_ms)
        elif raw.get("auto"):
            if len(source_set) != 1:
                raise ValueError(
                    "Auto transition with implicit trigger must have exactly one source"
                )
            (single_source,) = source_set
            trigger = _auto_trigger(single_source)
        else:
            raise ValueError(
                "Transition must have either 'trigger', 'after', or 'auto: true'"
            )

    region = raw.get("region")
    if not isinstance(region, str):
        region = None

    # Collect metadata: explicit metadata field + any extra keys
    known_keys = {
        "trigger",
        "source",
        "dest",
        "region",
        "guards",
        "actions",
        "after",
        "internal",
        "auto",
        "description",
        "metadata",
    }
    metadata = dict(raw.get("metadata", {}))
    for k, v in raw.items():
        if k not in known_keys:
            metadata[k] = v

    return Transition(
        trigger=trigger,
        source=source_set,
        dest=raw["dest"],
        region=region,
        guards=_parse_guard_specs(raw.get("guards")),
        actions=_parse_action_specs(raw.get("actions")),
        after=after_ms,
        internal=bool(raw.get("internal", False)),
        auto=bool(raw.get("auto", False)),
        description=raw.get("description", ""),
        metadata=metadata,
    )


# ---------------------------------------------------------------------------
# Wildcard expansion (#6)
# ---------------------------------------------------------------------------


def _expand_wildcard_sources(
    states: dict[str, State],
    transitions: list[Transition],
) -> list[Transition]:
    """Expand wildcard source '*' to all non-terminal state names."""
    non_terminal = frozenset(
        name for name, state in states.items() if not state.is_terminal
    )
    if not non_terminal:
        return transitions

    expanded: list[Transition] = []
    for t in transitions:
        if t.source == frozenset({"*"}):
            expanded.append(
                Transition(
                    trigger=t.trigger,
                    source=non_terminal,
                    dest=t.dest,
                    region=t.region,
                    guards=t.guards,
                    actions=t.actions,
                    after=t.after,
                    internal=t.internal,
                    auto=t.auto,
                    description=t.description,
                    metadata=t.metadata,
                )
            )
        else:
            expanded.append(t)
    return expanded


# ---------------------------------------------------------------------------
# Meta parsing
# ---------------------------------------------------------------------------


def _parse_meta(raw: Any) -> dict[str, Any]:
    """Parse the meta section of a config dict."""
    if not raw or not isinstance(raw, dict):
        return {}

    meta: dict[str, Any] = {}
    if raw.get("version") is not None:
        meta["version"] = raw["version"]
    if raw.get("machine_name") is not None:
        meta["machine_name"] = raw["machine_name"]
    meta["strict_mode"] = raw.get("strict_mode", True)
    if raw.get("event_normalizer") is not None:
        meta["event_normalizer"] = raw["event_normalizer"]
    if raw.get("description") is not None:
        meta["description"] = raw["description"]
    meta["validate_context"] = raw.get("validate_context", False)

    # Extra keys in meta (forward compatibility)
    known_meta_keys = {
        "version",
        "machine_name",
        "strict_mode",
        "event_normalizer",
        "description",
        "validate_context",
    }
    for k, v in raw.items():
        if k not in known_meta_keys:
            meta[k] = v

    return meta


# ---------------------------------------------------------------------------
# Top-level conversion
# ---------------------------------------------------------------------------


def raw_config_to_core(
    config: dict[str, Any],
) -> tuple[dict[str, State], list[Transition], dict[str, Any]]:
    """Convert a raw config dict to (states, transitions, meta).

    No Pydantic required. Performs basic structural conversion but not
    schema validation. For full validation, install ``pystator[validation]``.
    """
    states_raw = config.get("states", [])
    transitions_raw = config.get("transitions", [])

    if not states_raw:
        raise ValueError("At least one state is required")

    states = {}
    for s in states_raw:
        state = _parse_state(s)
        states[state.name] = state

    transitions = [_parse_transition(t) for t in transitions_raw]

    # Expand wildcard sources
    transitions = _expand_wildcard_sources(states, transitions)

    meta = _parse_meta(config.get("meta"))

    # State variables / context (metadata)
    sv_raw = config.get("state_variables") or config.get("context")
    if sv_raw and isinstance(sv_raw, list):
        normalized = []
        for item in sv_raw:
            if isinstance(item, str):
                normalized.append({"key": item})
            elif isinstance(item, dict):
                normalized.append(item)
            else:
                normalized.append({"key": str(item)})
        meta["state_variables"] = normalized

    events_raw = config.get("events")
    if events_raw is not None:
        meta["events"] = events_raw

    return states, transitions, meta
