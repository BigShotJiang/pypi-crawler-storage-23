"""Auth configuration for PyStator API.

Reads initial credentials and JWT secret from environment variables
or the ``pystator.cfg`` ``[auth]`` section.
"""

from __future__ import annotations

import os
from configparser import ConfigParser

from pystator.config.paths import find_config_file


def _get_config_variable(var_name: str, section: str) -> str | None:
    """Read a single variable from ``pystator.cfg`` *[section]*."""
    config_file = find_config_file("pystator.cfg")
    if not config_file:
        return None
    try:
        cfg = ConfigParser()
        cfg.read(config_file)
        if cfg.has_section(section):
            return cfg.get(section, var_name, fallback=None)
    except Exception:
        pass
    return None


def get_auth_initial_credentials() -> tuple[str, str] | None:
    """Return ``(username, password)`` from env or ``[auth]``, or *None*."""
    username = os.getenv("PYSTATOR_AUTH_INITIAL_USERNAME")
    password = os.getenv("PYSTATOR_AUTH_INITIAL_PASSWORD")
    if username and password:
        return (username, password)

    config_file = find_config_file("pystator.cfg")
    if config_file:
        try:
            cfg = ConfigParser()
            cfg.read(config_file)
            if cfg.has_section("auth"):
                u = cfg.get("auth", "initial_username", fallback=None)
                p = cfg.get("auth", "initial_password", fallback=None)
                if u and p:
                    return (u.strip(), p.strip())
        except Exception:
            pass
    return None


def get_auth_jwt_secret() -> str | None:
    """JWT signing/verification secret (env or ``pystator.cfg`` ``[auth]``)."""
    secret = os.getenv("PYSTATOR_AUTH_JWT_SECRET")
    if secret:
        return secret
    return _get_config_variable("jwt_secret", "auth")


def get_auth_service_url() -> str | None:
    """Auth microservice base URL (env or pystator.cfg [auth])."""
    url = os.getenv("PYSTATOR_AUTH_SERVICE_URL")
    if url:
        return url.rstrip("/")
    v = _get_config_variable("auth_service_url", "auth")
    return v.strip() if v else None


def get_auth_service_introspect_path() -> str | None:
    """Auth service introspect path, e.g. /oauth/introspect (env or cfg)."""
    path = os.getenv("PYSTATOR_AUTH_SERVICE_INTROSPECT_PATH")
    if path:
        return path
    return _get_config_variable("auth_service_introspect_path", "auth")


def _is_auth_configured() -> bool:
    """True if there is a way to log in or verify tokens (initial creds + JWT secret, or auth service)."""
    if get_auth_service_url():
        return True
    if get_auth_initial_credentials() and get_auth_jwt_secret():
        return True
    return False


def is_auth_disabled() -> bool:
    """True when auth is explicitly disabled or not configured.

    When disabled, ``/auth/me`` returns 200 with an anonymous user so the
    UI does not block.
    """
    if os.getenv("PYSTATOR_AUTH_DISABLED", "").strip().lower() in ("1", "true", "yes"):
        return True
    return not _is_auth_configured()
