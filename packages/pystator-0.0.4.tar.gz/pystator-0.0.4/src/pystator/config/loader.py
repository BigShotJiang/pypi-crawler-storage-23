"""Configuration loading for PyStator FSM definitions.

Pydantic is lazy-loaded only when validation is enabled.
The core parse path uses ``_raw_parser`` which has no external dependencies.
"""

from __future__ import annotations

import json
import os
import re
import warnings
from pathlib import Path
from typing import Any

from pystator._types import State, Transition
from pystator.config._raw_parser import raw_config_to_core
from pystator.errors import ConfigurationError

# Variable substitution pattern: ${VAR}, ${VAR:-default}, ${VAR:?error}
VARIABLE_PATTERN = re.compile(r"\$\{([^}:]+)(?::([?-])([^}]*))?\}")


class ConfigLoader:
    """Loads and parses FSM configuration from YAML/JSON files.

    Handles YAML/JSON parsing, environment variable substitution,
    schema validation, and conversion to State/Transition objects.

    When ``validate=True`` and Pydantic is installed, full schema and
    semantic validation is performed. Without Pydantic, validation is
    skipped with a warning.

    Variable Substitution:
        - ``${VAR}`` -- replace with environment variable
        - ``${VAR:-default}`` -- use 'default' if VAR is not set
        - ``${VAR:?error}`` -- raise error if VAR is not set
    """

    def __init__(
        self,
        validate: bool = True,
        strict: bool = True,
        variables: dict[str, str] | None = None,
    ) -> None:
        self.validate = validate
        self.strict = strict
        self.variables = variables or {}
        self._validator: Any = None

        if validate:
            try:
                from pystator.config.validator import ConfigValidator

                self._validator = ConfigValidator()
            except ImportError:
                warnings.warn(
                    "Pydantic is not installed; config validation disabled. "
                    "Install with: pip install pystator[validation]",
                    stacklevel=2,
                )

    def load(self, path: str | Path) -> dict[str, Any]:
        """Load configuration from a YAML or JSON file."""
        path = Path(path)
        if not path.exists():
            raise ConfigurationError(
                f"Configuration file not found: {path}", path=str(path)
            )

        try:
            content = path.read_text(encoding="utf-8")
        except OSError as e:
            raise ConfigurationError(
                f"Failed to read configuration: {e}", path=str(path)
            ) from e

        content = self._substitute_variables(content, str(path))

        suffix = path.suffix.lower()
        if suffix in (".yaml", ".yml"):
            config = self._parse_yaml(content, str(path))
        elif suffix == ".json":
            config = self._parse_json(content, str(path))
        else:
            try:
                config = self._parse_yaml(content, str(path))
            except ConfigurationError:
                config = self._parse_json(content, str(path))

        if self._validator:
            errors = self._validator.validate(config)
            if errors and self.strict:
                raise ConfigurationError(
                    f"Configuration validation failed with {len(errors)} error(s)",
                    path=str(path),
                    context={"errors": errors},
                )

        return config

    def load_dict(self, config: dict[str, Any]) -> dict[str, Any]:
        """Load and validate a configuration dictionary."""
        if self._validator:
            errors = self._validator.validate(config)
            if errors and self.strict:
                raise ConfigurationError(
                    f"Configuration validation failed with {len(errors)} error(s)",
                    context={"errors": errors},
                )
        return config

    def _substitute_variables(self, content: str, path: str) -> str:
        def replacer(match: re.Match[str]) -> str:
            var_name = match.group(1)
            modifier = match.group(2)
            default_or_error = match.group(3)

            value = self.variables.get(var_name) or os.environ.get(var_name)
            if value is not None:
                return value

            if modifier == "-":
                return default_or_error or ""
            elif modifier == "?":
                error_msg = (
                    default_or_error or f"Required variable '{var_name}' not set"
                )
                raise ConfigurationError(
                    f"Variable substitution error: {error_msg}",
                    path=path,
                    context={"variable": var_name},
                )
            return ""

        return VARIABLE_PATTERN.sub(replacer, content)

    def _parse_yaml(self, content: str, path: str) -> dict[str, Any]:
        try:
            import yaml

            result = yaml.safe_load(content)
            if not isinstance(result, dict):
                raise ConfigurationError(
                    "Configuration must be a YAML mapping (dictionary)", path=path
                )
            return result
        except ImportError as e:
            raise ConfigurationError(
                "PyYAML is required for YAML configuration files. "
                "Install with: pip install pyyaml",
                path=path,
            ) from e
        except yaml.YAMLError as e:
            raise ConfigurationError(f"Invalid YAML syntax: {e}", path=path) from e

    def _parse_json(self, content: str, path: str) -> dict[str, Any]:
        try:
            result = json.loads(content)
            if not isinstance(result, dict):
                raise ConfigurationError(
                    "Configuration must be a JSON object (dictionary)", path=path
                )
            return result
        except json.JSONDecodeError as e:
            raise ConfigurationError(f"Invalid JSON syntax: {e}", path=path) from e

    def parse(
        self, config: dict[str, Any]
    ) -> tuple[dict[str, State], list[Transition], dict[str, Any]]:
        """Parse config dict into (states, transitions, meta).

        Uses Pydantic validation if available, otherwise falls back to
        the lightweight raw parser.
        """
        if self._validator:
            return self._parse_validated(config)
        try:
            return raw_config_to_core(config)
        except ValueError as e:
            raise ConfigurationError(str(e), context={"config": config}) from e

    def _parse_validated(
        self, config: dict[str, Any]
    ) -> tuple[dict[str, State], list[Transition], dict[str, Any]]:
        """Parse with full Pydantic validation (lazy-loaded)."""
        from pydantic import ValidationError

        from pystator.config.converter import machine_config_to_core
        from pystator.config.models import MachineConfig

        try:
            validated = MachineConfig.model_validate(config)
        except ValidationError as e:
            errors = [
                f"[{'.'.join(str(p) for p in err.get('loc', ()))}] "
                f"{err.get('msg', 'validation error')}"
                for err in e.errors()
            ]
            raise ConfigurationError(
                f"Configuration validation failed with {len(errors)} error(s)",
                context={"errors": errors},
            ) from e
        try:
            return machine_config_to_core(validated)
        except ValueError as e:
            raise ConfigurationError(str(e), context={"config": config}) from e


def load_config(
    path: str | Path,
    validate: bool = True,
    strict: bool = True,
    variables: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Convenience function: load configuration from file."""
    loader = ConfigLoader(validate=validate, strict=strict, variables=variables)
    return loader.load(path)
