"""Convert Pydantic config models to internal _types dataclasses."""

from __future__ import annotations

from typing import Any

from pystator._types import (
    ActionSpec,
    GuardSpec,
    InvokeSpec,
    Region,
    State,
    StateType,
    Timeout,
    Transition,
    parse_delay,
)
from pystator.config.models import MachineConfig, StateDef, TransitionDef


def _implicit_trigger_for_after(source: str, after_ms: int) -> str:
    """Generate synthetic trigger for delayed transition with no explicit trigger."""
    return f"_after_{source}_{after_ms}_ms"


def _auto_trigger(source: str) -> str:
    """Generate synthetic trigger for auto (eventless) transitions."""
    return f"_auto_{source}"


def _state_def_metadata(s: StateDef) -> dict[str, Any]:
    meta = dict(s.metadata)
    if s.model_extra:
        meta.update(s.model_extra)
    return meta


def _transition_def_metadata(t: TransitionDef) -> dict[str, Any]:
    meta = dict(t.metadata)
    if t.model_extra:
        meta.update(t.model_extra)
    return meta


def state_def_to_state(s: StateDef) -> State:
    """Convert StateDef to State."""
    timeout = None
    if s.timeout is not None:
        timeout = Timeout(seconds=s.timeout.seconds, destination=s.timeout.destination)

    regions = tuple(
        Region(
            name=r.name,
            initial=r.initial,
            states=tuple(r.states),
            description=r.description or "",
        )
        for r in s.regions
    )

    on_enter = tuple(
        (
            ActionSpec.from_config(item)
            if isinstance(item, dict)
            else ActionSpec(name=item)
        )
        for item in (s.on_enter if isinstance(s.on_enter, list) else [s.on_enter])
    )
    on_exit = tuple(
        (
            ActionSpec.from_config(item)
            if isinstance(item, dict)
            else ActionSpec(name=item)
        )
        for item in (s.on_exit if isinstance(s.on_exit, list) else [s.on_exit])
    )

    invoke = tuple(
        InvokeSpec(id=inv.id, src=inv.src, on_done=inv.on_done) for inv in s.invoke
    )

    return State(
        name=s.name,
        type=StateType(s.type),
        description=s.description or "",
        parent=s.parent,
        initial_child=s.initial_child,
        regions=regions,
        on_enter=on_enter,
        on_exit=on_exit,
        invoke=invoke,
        timeout=timeout,
        metadata=_state_def_metadata(s),
    )


def transition_def_to_transition(t: TransitionDef) -> Transition:
    """Convert TransitionDef to Transition.

    Resolves implicit triggers for ``after`` and ``auto`` transitions.
    """
    source = t.source if isinstance(t.source, list) else [t.source]
    source_set = frozenset(source)

    after_ms: int | None = None
    if t.after is not None:
        after_ms = parse_delay(t.after)

    trigger = (t.trigger or "").strip()

    # Generate synthetic trigger when not provided
    if not trigger:
        if after_ms is not None:
            if len(source_set) != 1:
                raise ValueError(
                    "Delayed transition with implicit trigger must have exactly one source"
                )
            (single_source,) = source_set
            trigger = _implicit_trigger_for_after(single_source, after_ms)
        elif t.auto:
            if len(source_set) != 1:
                raise ValueError(
                    "Auto transition with implicit trigger must have exactly one source"
                )
            (single_source,) = source_set
            trigger = _auto_trigger(single_source)
        else:
            raise ValueError(
                "Transition must have either 'trigger', 'after', or 'auto'"
            )

    guards = tuple(
        GuardSpec.from_config(item) if isinstance(item, dict) else GuardSpec(name=item)
        for item in t.guards
    )
    actions = tuple(
        (
            ActionSpec.from_config(item)
            if isinstance(item, dict)
            else ActionSpec(name=item)
        )
        for item in t.actions
    )

    region = t.region if isinstance(t.region, str) else None

    return Transition(
        trigger=trigger,
        source=source_set,
        dest=t.dest,
        region=region,
        guards=guards,
        actions=actions,
        after=after_ms,
        internal=t.internal,
        auto=t.auto,
        description=t.description or "",
        metadata=_transition_def_metadata(t),
    )


def _expand_wildcard_sources(
    states: dict[str, State],
    transitions: list[Transition],
) -> list[Transition]:
    """Expand wildcard source '*' to all non-terminal state names."""
    non_terminal = frozenset(
        name for name, state in states.items() if not state.is_terminal
    )
    if not non_terminal:
        return transitions

    expanded: list[Transition] = []
    for t in transitions:
        if t.source == frozenset({"*"}):
            expanded.append(
                Transition(
                    trigger=t.trigger,
                    source=non_terminal,
                    dest=t.dest,
                    region=t.region,
                    guards=t.guards,
                    actions=t.actions,
                    after=t.after,
                    internal=t.internal,
                    auto=t.auto,
                    description=t.description,
                    metadata=t.metadata,
                )
            )
        else:
            expanded.append(t)
    return expanded


def machine_config_to_core(
    config: MachineConfig,
) -> tuple[dict[str, State], list[Transition], dict[str, Any]]:
    """Convert validated MachineConfig to (states dict, transitions list, meta dict)."""
    states = {s.name: state_def_to_state(s) for s in config.states}
    transitions = [transition_def_to_transition(t) for t in config.transitions]

    # Expand wildcard sources
    transitions = _expand_wildcard_sources(states, transitions)

    meta: dict[str, Any] = {}
    if isinstance(config.meta, dict):
        meta = dict(config.meta)
    else:
        m = config.meta
        if m.version is not None:
            meta["version"] = m.version
        if m.machine_name is not None:
            meta["machine_name"] = m.machine_name
        meta["strict_mode"] = m.strict_mode
        if m.event_normalizer is not None:
            meta["event_normalizer"] = m.event_normalizer
        if m.description is not None:
            meta["description"] = m.description
        meta["validate_context"] = m.validate_context
        if getattr(m, "model_extra", None):
            meta.update(m.model_extra)

    if config.state_variables is not None:
        meta["state_variables"] = [
            sv.model_dump() if hasattr(sv, "model_dump") else dict(sv)
            for sv in config.state_variables
        ]
    elif config.context is not None:
        meta["context"] = config.context
    if config.events is not None:
        meta["events"] = config.events

    return states, transitions, meta
