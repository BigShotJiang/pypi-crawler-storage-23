"""Database URL configuration for PyStator.

Priority order:
    1. ``PYSTATOR__DATABASE__SQL_ALCHEMY_CONN`` (Airflow-style)
    2. ``PYSTATOR_DATABASE_URL``
    3. ``pystator.cfg`` ``[database]`` ``sql_alchemy_conn``
    4. ``alembic.ini`` ``sqlalchemy.url``
"""

from __future__ import annotations

import os
from configparser import ConfigParser

from pystator.config.paths import find_config_file


def get_database_url() -> str | None:
    """Return the database URL from env, config file, or ``alembic.ini``."""
    db_url = os.getenv("PYSTATOR__DATABASE__SQL_ALCHEMY_CONN")
    if db_url:
        return db_url

    db_url = os.getenv("PYSTATOR_DATABASE_URL")
    if db_url:
        return db_url

    config_file = find_config_file("pystator.cfg")
    if config_file:
        cfg = ConfigParser()
        cfg.read(config_file)
        if cfg.has_section("database"):
            db_url = cfg.get("database", "sql_alchemy_conn", fallback=None)
            if db_url:
                return db_url

    alembic_ini = find_config_file("alembic.ini")
    if alembic_ini:
        cfg = ConfigParser()
        cfg.read(alembic_ini)
        db_url = cfg.get("alembic", "sqlalchemy.url", fallback=None)
        if db_url and db_url != "driver://user:pass@localhost/dbname":
            return db_url

    return None


def set_database_url(database_url: str) -> None:
    """Store the database URL in the environment for the current process."""
    os.environ["PYSTATOR_DATABASE_URL"] = database_url
