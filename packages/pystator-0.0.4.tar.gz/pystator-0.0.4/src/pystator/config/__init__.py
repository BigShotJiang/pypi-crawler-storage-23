"""Configuration loading, validation, and path helpers for PyStator.

``ConfigValidator`` and ``validate_config`` are lazy-loaded so that
importing ``pystator.config`` does **not** require Pydantic.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from pystator.config.auth import (
    get_auth_initial_credentials,
    get_auth_jwt_secret,
    is_auth_disabled,
)
from pystator.config.database import get_database_url, set_database_url
from pystator.config.loader import ConfigLoader, load_config
from pystator.config.paths import find_config_file

if TYPE_CHECKING:
    from pystator.config.validator import ConfigValidator as ConfigValidator
    from pystator.config.validator import validate_config as validate_config

__all__ = [
    # Auth
    "get_auth_initial_credentials",
    "get_auth_jwt_secret",
    "is_auth_disabled",
    # Database
    "get_database_url",
    "set_database_url",
    # Config loading / validation
    "ConfigLoader",
    "ConfigValidator",
    "find_config_file",
    "load_config",
    "validate_config",
]

# Lazy imports for Pydantic-dependent symbols
_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "ConfigValidator": ("pystator.config.validator", "ConfigValidator"),
    "validate_config": ("pystator.config.validator", "validate_config"),
}


def __getattr__(name: str) -> Any:
    if name in _LAZY_IMPORTS:
        module_path, attr = _LAZY_IMPORTS[name]
        import importlib

        mod = importlib.import_module(module_path)
        return getattr(mod, attr)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
