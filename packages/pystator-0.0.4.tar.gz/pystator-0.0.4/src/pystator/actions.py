"""Action registry and executor for PyStator FSM.

Actions are functions executed AFTER a transition has been persisted.
They handle side effects like notifications, DB writes, etc.

This module merges the registry and executor into a single file.
"""

from __future__ import annotations

import asyncio
import logging
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Awaitable, Callable, Protocol, Union, runtime_checkable

from pystator._types import ActionSpec, TransitionResult
from pystator.errors import ActionNotFoundError

logger = logging.getLogger(__name__)

# Key used to inject action parameters into context
ACTION_PARAMS_KEY = "_action_params"


# ---------------------------------------------------------------------------
# Protocols
# ---------------------------------------------------------------------------


@runtime_checkable
class ActionFunc(Protocol):
    """Synchronous action function protocol."""

    def __call__(self, context: dict[str, Any]) -> Any: ...


@runtime_checkable
class AsyncActionFunc(Protocol):
    """Asynchronous action function protocol."""

    def __call__(self, context: dict[str, Any]) -> Awaitable[Any]: ...


AnyActionFunc = Union[
    ActionFunc,
    AsyncActionFunc,
    Callable[[dict[str, Any]], Union[Any, Awaitable[Any]]],
]


# ---------------------------------------------------------------------------
# ActionResult
# ---------------------------------------------------------------------------


class ActionStatus(str, Enum):
    OK = "ok"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class ActionResult:
    """Result of action execution.

    Attributes:
        success: Whether the action executed successfully.
        action_name: Name of the action.
        result: Return value from the action (if any).
        error: Exception if action failed.
        status: Detailed status (ok, failed, skipped).
    """

    success: bool
    action_name: str
    result: Any = None
    error: Exception | None = None
    status: ActionStatus = ActionStatus.OK

    @classmethod
    def ok(cls, action_name: str, result: Any = None) -> ActionResult:
        return cls(
            success=True, action_name=action_name, result=result, status=ActionStatus.OK
        )

    @classmethod
    def fail(cls, action_name: str, error: Exception) -> ActionResult:
        return cls(
            success=False,
            action_name=action_name,
            error=error,
            status=ActionStatus.FAILED,
        )

    @classmethod
    def skipped(cls, action_name: str, reason: str = "") -> ActionResult:
        return cls(
            success=True,
            action_name=action_name,
            result=reason or "not_registered",
            status=ActionStatus.SKIPPED,
        )

    @property
    def is_skipped(self) -> bool:
        return self.status == ActionStatus.SKIPPED


# ---------------------------------------------------------------------------
# ExecutionMode / ExecutionResult
# ---------------------------------------------------------------------------


class ExecutionMode(str, Enum):
    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
    PHASED = "phased"


@dataclass
class ExecutionResult:
    """Result of executing all actions from a transition."""

    transition_result: TransitionResult
    action_results: list[ActionResult] = field(default_factory=list)
    execution_mode: ExecutionMode = ExecutionMode.SEQUENTIAL
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: datetime | None = None

    @property
    def all_succeeded(self) -> bool:
        return all(r.success for r in self.action_results)

    @property
    def failed_actions(self) -> list[str]:
        return [r.action_name for r in self.action_results if not r.success]

    @property
    def succeeded_actions(self) -> list[str]:
        return [r.action_name for r in self.action_results if r.success]

    @property
    def action_count(self) -> int:
        return len(self.action_results)

    @property
    def duration_ms(self) -> float | None:
        if self.completed_at is None:
            return None
        return (self.completed_at - self.started_at).total_seconds() * 1000


# ---------------------------------------------------------------------------
# ActionRegistry
# ---------------------------------------------------------------------------


class ActionRegistry:
    """Registry for action functions (sync and async).

    Example:
        >>> registry = ActionRegistry()
        >>> registry.register("notify", lambda ctx: print("notified"))
        >>> registry.execute("notify", {"user": "alice"})
    """

    def __init__(self) -> None:
        self._actions: dict[str, AnyActionFunc] = {}
        self._metadata: dict[str, dict[str, Any]] = {}
        self._async_actions: set[str] = set()
        self._lock = threading.Lock()

    def register(
        self,
        name: str,
        func: AnyActionFunc,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Register an action function. Thread-safe."""
        if not name:
            raise ValueError("Action name cannot be empty")
        with self._lock:
            if name in self._actions:
                raise ValueError(f"Action '{name}' is already registered")
            self._actions[name] = func
            self._metadata[name] = metadata or {}
            if asyncio.iscoroutinefunction(func) or (
                hasattr(func, "__call__")
                and asyncio.iscoroutinefunction(getattr(func, "__call__", None))
            ):
                self._async_actions.add(name)

    def unregister(self, name: str) -> None:
        """Unregister an action function. Thread-safe."""
        with self._lock:
            if name not in self._actions:
                raise ActionNotFoundError(
                    f"Action '{name}' not found", action_name=name
                )
            del self._actions[name]
            del self._metadata[name]
            self._async_actions.discard(name)

    def get(self, name: str) -> AnyActionFunc:
        if name not in self._actions:
            raise ActionNotFoundError(f"Action '{name}' not found", action_name=name)
        return self._actions[name]

    def has(self, name: str) -> bool:
        return name in self._actions

    def get_metadata(self, name: str) -> dict[str, Any]:
        """Get metadata for a registered action."""
        return dict(self._metadata.get(name, {}))

    def is_async(self, name: str) -> bool:
        return name in self._async_actions

    def execute(
        self, name: str, context: dict[str, Any], raise_on_error: bool = False
    ) -> ActionResult:
        func = self.get(name)
        try:
            result = func(context)
            return ActionResult.ok(name, result)
        except Exception as e:
            if raise_on_error:
                raise
            return ActionResult.fail(name, e)

    def execute_all(
        self,
        actions: tuple[str, ...] | list[str],
        context: dict[str, Any],
        stop_on_error: bool = False,
    ) -> list[ActionResult]:
        results: list[ActionResult] = []
        for action_name in actions:
            try:
                result = self.execute(action_name, context)
                results.append(result)
                if not result.success and stop_on_error:
                    break
            except ActionNotFoundError as e:
                results.append(ActionResult.fail(action_name, e))
                if stop_on_error:
                    break
        return results

    async def async_execute(
        self, name: str, context: dict[str, Any], raise_on_error: bool = False
    ) -> ActionResult:
        func = self.get(name)
        try:
            if self.is_async(name):
                result = await func(context)  # type: ignore[misc]
            else:
                result = func(context)
            return ActionResult.ok(name, result)
        except Exception as e:
            if raise_on_error:
                raise
            return ActionResult.fail(name, e)

    async def async_execute_all(
        self,
        actions: tuple[str, ...] | list[str],
        context: dict[str, Any],
        stop_on_error: bool = False,
    ) -> list[ActionResult]:
        results: list[ActionResult] = []
        for action_name in actions:
            try:
                result = await self.async_execute(action_name, context)
                results.append(result)
                if not result.success and stop_on_error:
                    break
            except ActionNotFoundError as e:
                results.append(ActionResult.fail(action_name, e))
                if stop_on_error:
                    break
        return results

    def list_actions(self) -> list[str]:
        return list(self._actions.keys())

    def clear(self) -> None:
        self._actions.clear()
        self._metadata.clear()
        self._async_actions.clear()

    def __len__(self) -> int:
        return len(self._actions)

    def __contains__(self, name: str) -> bool:
        return name in self._actions

    def decorator(
        self,
        name: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Callable[[AnyActionFunc], AnyActionFunc]:
        """Decorator to register an action function.

        Example:
            >>> @registry.decorator()
            ... def notify_user(ctx: dict) -> None:
            ...     send_email(ctx["user_email"], "Order updated")
        """

        def inner(func: AnyActionFunc) -> AnyActionFunc:
            self.register(name or func.__name__, func, metadata)
            return func

        return inner


# ---------------------------------------------------------------------------
# ActionExecutor
# ---------------------------------------------------------------------------


class ActionExecutor:
    """Executes actions from transition results.

    Supports sequential, parallel, and phased execution modes.

    Example:
        >>> executor = ActionExecutor(action_registry)
        >>> execution = executor.execute(transition_result, context)
    """

    def __init__(
        self,
        registry: ActionRegistry,
        stop_on_error: bool = False,
        log_execution: bool = True,
        default_mode: ExecutionMode = ExecutionMode.SEQUENTIAL,
        strict: bool = False,
    ) -> None:
        self.registry = registry
        self.stop_on_error = stop_on_error
        self.log_execution = log_execution
        self.default_mode = default_mode
        self.strict = strict

    def execute(
        self,
        transition_result: TransitionResult,
        context: dict[str, Any],
    ) -> ExecutionResult:
        """Execute all actions from a transition result sequentially."""
        result = ExecutionResult(
            transition_result=transition_result,
            started_at=datetime.now(timezone.utc),
        )
        if not transition_result.success:
            result.completed_at = datetime.now(timezone.utc)
            return result

        for spec in transition_result.all_action_specs:
            action_result = self._execute_single(
                spec.name, context, spec.params if spec.has_params else None
            )
            result.action_results.append(action_result)
            if not action_result.success and self.stop_on_error:
                break

        result.completed_at = datetime.now(timezone.utc)
        return result

    def execute_specific(
        self,
        action_names: list[str] | tuple[str, ...],
        context: dict[str, Any],
    ) -> list[ActionResult]:
        """Execute specific actions by name sequentially."""
        results: list[ActionResult] = []
        for name in action_names:
            results.append(self._execute_single(name, context, None))
        return results

    def validate_actions_exist(self, transition_result: TransitionResult) -> list[str]:
        """Return list of action names that are not registered."""
        missing: list[str] = []
        for spec in transition_result.all_action_specs:
            if not self.registry.has(spec.name):
                missing.append(spec.name)
        return missing

    def execute_action_spec(
        self, action: ActionSpec, context: dict[str, Any]
    ) -> ActionResult:
        return self._execute_single(
            action.name, context, action.params if action.has_params else None
        )

    def execute_action_specs(
        self,
        actions: tuple[ActionSpec, ...] | list[ActionSpec],
        context: dict[str, Any],
    ) -> list[ActionResult]:
        results: list[ActionResult] = []
        for action in actions:
            result = self.execute_action_spec(action, context)
            results.append(result)
            if not result.success and self.stop_on_error:
                break
        return results

    def _execute_single(
        self,
        action_name: str,
        context: dict[str, Any],
        params: dict[str, Any] | None = None,
    ) -> ActionResult:
        if not self.registry.has(action_name):
            if self.strict:
                raise ActionNotFoundError(
                    f"Action '{action_name}' not registered (strict mode)",
                    action_name=action_name,
                )
            if self.log_execution:
                logger.warning(f"Action '{action_name}' not registered, skipping")
            return ActionResult.skipped(action_name, "not_registered")
        try:
            exec_ctx = context
            if params:
                exec_ctx = {**context, ACTION_PARAMS_KEY: params}
            return self.registry.execute(action_name, exec_ctx)
        except Exception as e:
            if self.log_execution:
                logger.exception(f"Action '{action_name}' raised exception: {e}")
            return ActionResult.fail(action_name, e)

    # ------------------------------------------------------------------
    # Async execution
    # ------------------------------------------------------------------

    async def async_execute(
        self,
        transition_result: TransitionResult,
        context: dict[str, Any],
    ) -> ExecutionResult:
        """Execute all actions asynchronously in sequential order."""
        result = ExecutionResult(
            transition_result=transition_result,
            started_at=datetime.now(timezone.utc),
        )
        if not transition_result.success:
            result.completed_at = datetime.now(timezone.utc)
            return result

        for spec in transition_result.all_action_specs:
            ar = await self._async_execute_single(
                spec.name, context, spec.params if spec.has_params else None
            )
            result.action_results.append(ar)
            if not ar.success and self.stop_on_error:
                break

        result.completed_at = datetime.now(timezone.utc)
        return result

    async def async_execute_parallel(
        self,
        transition_result: TransitionResult,
        context: dict[str, Any],
    ) -> ExecutionResult:
        """Execute all actions concurrently using asyncio.gather."""
        result = ExecutionResult(
            transition_result=transition_result,
            execution_mode=ExecutionMode.PARALLEL,
            started_at=datetime.now(timezone.utc),
        )
        if not transition_result.success:
            result.completed_at = datetime.now(timezone.utc)
            return result

        specs = transition_result.all_action_specs
        if specs:
            tasks = [
                self._async_execute_single(
                    s.name, context, s.params if s.has_params else None
                )
                for s in specs
            ]
            result.action_results = list(await asyncio.gather(*tasks))

        result.completed_at = datetime.now(timezone.utc)
        return result

    async def async_execute_phased(
        self,
        transition_result: TransitionResult,
        context: dict[str, Any],
    ) -> ExecutionResult:
        """Execute actions in phases: exit -> transition -> enter (each parallel)."""
        result = ExecutionResult(
            transition_result=transition_result,
            execution_mode=ExecutionMode.PHASED,
            started_at=datetime.now(timezone.utc),
        )
        if not transition_result.success:
            result.completed_at = datetime.now(timezone.utc)
            return result

        phases = [
            transition_result.on_exit_actions,
            transition_result.actions_to_execute,
            transition_result.on_enter_actions,
        ]
        all_results: list[ActionResult] = []
        for phase_specs in phases:
            if not phase_specs:
                continue
            tasks = [
                self._async_execute_single(
                    s.name, context, s.params if s.has_params else None
                )
                for s in phase_specs
            ]
            phase_results = await asyncio.gather(*tasks)
            all_results.extend(phase_results)
            if self.stop_on_error and any(not r.success for r in phase_results):
                break

        result.action_results = all_results
        result.completed_at = datetime.now(timezone.utc)
        return result

    async def async_execute_with_mode(
        self,
        transition_result: TransitionResult,
        context: dict[str, Any],
        mode: ExecutionMode = ExecutionMode.SEQUENTIAL,
    ) -> ExecutionResult:
        """Execute with explicit mode (sequential, parallel, or phased)."""
        if mode == ExecutionMode.PARALLEL:
            return await self.async_execute_parallel(transition_result, context)
        if mode == ExecutionMode.PHASED:
            return await self.async_execute_phased(transition_result, context)
        return await self.async_execute(transition_result, context)

    async def async_execute_specific_parallel(
        self,
        action_names: list[str] | tuple[str, ...],
        context: dict[str, Any],
    ) -> list[ActionResult]:
        """Execute specific actions in parallel by name."""
        if not action_names:
            return []
        tasks = [
            self._async_execute_single(name, context, None) for name in action_names
        ]
        return list(await asyncio.gather(*tasks))

    async def async_execute_action_spec(
        self,
        action: ActionSpec,
        context: dict[str, Any],
    ) -> ActionResult:
        """Async execute a single ActionSpec."""
        return await self._async_execute_single(
            action.name, context, action.params if action.has_params else None
        )

    async def async_execute_action_specs_parallel(
        self,
        actions: tuple[ActionSpec, ...] | list[ActionSpec],
        context: dict[str, Any],
    ) -> list[ActionResult]:
        """Async execute multiple ActionSpecs in parallel."""
        if not actions:
            return []
        tasks = [self.async_execute_action_spec(a, context) for a in actions]
        return list(await asyncio.gather(*tasks))

    async def _async_execute_single(
        self,
        action_name: str,
        context: dict[str, Any],
        params: dict[str, Any] | None = None,
    ) -> ActionResult:
        if not self.registry.has(action_name):
            if self.strict:
                raise ActionNotFoundError(
                    f"Action '{action_name}' not registered (strict mode)",
                    action_name=action_name,
                )
            if self.log_execution:
                logger.warning(f"Action '{action_name}' not registered, skipping")
            return ActionResult.skipped(action_name, "not_registered")
        try:
            exec_ctx = context
            if params:
                exec_ctx = {**context, ACTION_PARAMS_KEY: params}
            return await self.registry.async_execute(action_name, exec_ctx)
        except Exception as e:
            if self.log_execution:
                logger.exception(f"Action '{action_name}' raised exception: {e}")
            return ActionResult.fail(action_name, e)
