"""SQLAlchemy state store for SQLite and PostgreSQL.

Mirrors pycharter's SQLiteMetadataStore / PostgresMetadataStore patterns.
Uses ``EntityStateModel`` and ``TransitionHistoryModel`` from
``pystator.db.models`` and the shared ``get_engine`` / ``get_session``
helpers from ``pystator.db.base``.

A single class handles both SQLite and PostgreSQL because
``pystator.db.base.get_engine`` already takes care of the backend
differences (schema-prefix stripping for SQLite, PRAGMA foreign_keys,
check_same_thread, etc.).
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy import inspect
from sqlalchemy.orm import Session

from pystator.config.database import get_database_url
from pystator.db.base import Base, get_engine, get_session
from pystator.db.models.entity_state import EntityStateModel
from pystator.db.models.transition_history import TransitionHistoryModel
from pystator.stores.base import StateStoreClient


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


class SQLAlchemyStateStore(StateStoreClient):
    """SQLAlchemy-backed state store (SQLite + PostgreSQL).

    Satisfies the ``StateStore`` protocol so it can be passed directly to
    the ``Orchestrator``.

    Constructor signature mirrors pycharter's store constructors::

        store = SQLAlchemyStateStore("sqlite:///pystator.db")
        store.connect(auto_initialize=True)

    Or with a context manager::

        with SQLAlchemyStateStore("postgresql://...") as store:
            store.get_state("order-123")

    If *connection_string* is ``None``, the store falls back to
    ``get_database_url()`` (env vars / config files / ``alembic.ini``),
    mirroring pycharter's config-resolution chain.
    """

    def __init__(self, connection_string: str | None = None) -> None:
        resolved = connection_string or get_database_url()
        if not resolved:
            raise ValueError(
                "connection_string is required. Provide it directly, or configure via:\n"
                "  - Environment variable: PYSTATOR__DATABASE__SQL_ALCHEMY_CONN or PYSTATOR_DATABASE_URL\n"
                "  - Config file: pystator.cfg [database] sql_alchemy_conn\n"
                "  - Config file: alembic.ini sqlalchemy.url"
            )
        super().__init__(resolved)
        self._engine: Any = None
        self._session: Session | None = None

    # ------------------------------------------------------------------
    # Lifecycle  (mirrors pycharter's connect / disconnect)
    # ------------------------------------------------------------------

    def connect(
        self,
        validate_schema: bool = True,
        auto_initialize: bool = False,
    ) -> None:
        """Connect to the database and optionally validate / create tables.

        Args:
            validate_schema: Check that required tables exist after connecting.
            auto_initialize: Create tables automatically if they are missing
                (useful for SQLite in development; for PostgreSQL prefer
                ``pystator db init``).
        """
        self._engine = get_engine(self.connection_string)  # type: ignore[arg-type]
        SessionFactory = __import__(
            "sqlalchemy.orm", fromlist=["sessionmaker"]
        ).sessionmaker(bind=self._engine)
        self._session = SessionFactory()
        self._connection = self._session  # sentinel for _require_connection

        if validate_schema:
            if not self._is_schema_initialized():
                if auto_initialize:
                    self._initialize_schema()
                else:
                    raise RuntimeError(
                        "Database schema is not initialized. "
                        "Run 'pystator db init' first, or pass auto_initialize=True.\n"
                        f"Connection: {self.connection_string}"
                    )

    def disconnect(self) -> None:
        """Close session and engine."""
        if self._session is not None:
            self._session.close()
            self._session = None
        if self._engine is not None:
            self._engine.dispose()
            self._engine = None
        self._connection = None

    # ------------------------------------------------------------------
    # Schema helpers  (mirrors pycharter's _is_schema_initialized)
    # ------------------------------------------------------------------

    def _is_schema_initialized(self) -> bool:
        """Check whether the ``entity_states`` table exists."""
        if self._engine is None:
            return False
        try:
            insp = inspect(self._engine)
            # PostgreSQL uses the "pystator" schema; SQLite uses the default.
            schema = "pystator" if not self._is_sqlite() else None
            tables = insp.get_table_names(schema=schema)
            return "entity_states" in tables
        except Exception:
            return False

    def _initialize_schema(self) -> None:
        """Create all tables from SQLAlchemy models."""
        try:
            Base.metadata.create_all(self._engine)
        except Exception as exc:
            raise RuntimeError(f"Failed to initialize schema: {exc}") from exc

    def _is_sqlite(self) -> bool:
        return (self.connection_string or "").startswith("sqlite://")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_session(self) -> Session:
        self._require_connection()
        assert self._session is not None  # noqa: S101
        return self._session

    # ------------------------------------------------------------------
    # StateStore protocol  (sync)
    # ------------------------------------------------------------------

    def get_state(self, entity_id: str) -> str | None:
        """Return the current state for *entity_id*, or ``None``."""
        session = self._get_session()
        row = (
            session.query(EntityStateModel)
            .filter(EntityStateModel.entity_id == entity_id)
            .first()
        )
        return row.current_state if row else None

    def set_state(
        self,
        entity_id: str,
        state: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Persist state (upsert) for *entity_id*."""
        session = self._get_session()
        row = (
            session.query(EntityStateModel)
            .filter(EntityStateModel.entity_id == entity_id)
            .first()
        )
        meta = metadata or {}
        if row is None:
            row = EntityStateModel(
                entity_id=entity_id,
                current_state=state,
                is_terminal=meta.get("is_terminal"),
                machine_name=meta.get("machine_name"),
                context_json=meta.get("context"),
            )
            session.add(row)
        else:
            row.current_state = state
            row.is_terminal = meta.get("is_terminal", row.is_terminal)
            row.updated_at = _utc_now()
            if "machine_name" in meta:
                row.machine_name = meta["machine_name"]
            if "context" in meta:
                row.context_json = meta["context"]
        session.commit()

    def get_context(self, entity_id: str) -> dict[str, Any]:
        """Return persisted context for *entity_id* (empty dict if none)."""
        session = self._get_session()
        row = (
            session.query(EntityStateModel)
            .filter(EntityStateModel.entity_id == entity_id)
            .first()
        )
        if row is None or row.context_json is None:
            return {}
        return dict(row.context_json)

    # ------------------------------------------------------------------
    # Extended helpers (not part of the protocol, but useful)
    # ------------------------------------------------------------------

    def set_context(self, entity_id: str, context: dict[str, Any]) -> None:
        """Persist context for *entity_id* (entity must already exist)."""
        session = self._get_session()
        row = (
            session.query(EntityStateModel)
            .filter(EntityStateModel.entity_id == entity_id)
            .first()
        )
        if row is None:
            raise ValueError(f"Entity not found: {entity_id!r}")
        row.context_json = context
        row.updated_at = _utc_now()
        session.commit()

    def get_is_terminal(self, entity_id: str) -> bool | None:
        """Return the ``is_terminal`` flag for *entity_id*."""
        session = self._get_session()
        row = (
            session.query(EntityStateModel)
            .filter(EntityStateModel.entity_id == entity_id)
            .first()
        )
        if row is None:
            return None
        return row.is_terminal

    def list_entities(
        self,
        machine_name: str | None = None,
        is_terminal: bool | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """List entity states with optional filters."""
        session = self._get_session()
        query = session.query(EntityStateModel)
        if machine_name is not None:
            query = query.filter(EntityStateModel.machine_name == machine_name)
        if is_terminal is not None:
            query = query.filter(EntityStateModel.is_terminal == is_terminal)
        query = query.order_by(EntityStateModel.updated_at.desc())
        rows = query.offset(offset).limit(limit).all()
        return [
            {
                "entity_id": r.entity_id,
                "current_state": r.current_state,
                "machine_name": r.machine_name,
                "is_terminal": r.is_terminal,
                "context": r.context_json or {},
                "created_at": r.created_at,
                "updated_at": r.updated_at,
            }
            for r in rows
        ]

    def delete_entity(self, entity_id: str) -> bool:
        """Delete entity state. Returns ``True`` if a row was deleted."""
        session = self._get_session()
        count = (
            session.query(EntityStateModel)
            .filter(EntityStateModel.entity_id == entity_id)
            .delete()
        )
        session.commit()
        return count > 0

    # ------------------------------------------------------------------
    # Transition history (audit log)
    # ------------------------------------------------------------------

    def record_transition(
        self,
        entity_id: str,
        source_state: str,
        trigger: str,
        *,
        target_state: str | None = None,
        success: bool = True,
        machine_name: str | None = None,
        actions_executed: list[str] | None = None,
        error_type: str | None = None,
        error_message: str | None = None,
        context_snapshot: dict[str, Any] | None = None,
        duration_ms: str | None = None,
    ) -> str:
        """Write a row to ``transition_history``. Returns the record id."""
        session = self._get_session()
        record = TransitionHistoryModel(
            entity_id=entity_id,
            machine_name=machine_name,
            source_state=source_state,
            target_state=target_state,
            trigger=trigger,
            success=success,
            error_type=error_type,
            error_message=error_message,
            actions_executed=actions_executed,
            context_snapshot=context_snapshot,
            duration_ms=duration_ms,
        )
        session.add(record)
        session.commit()
        return str(record.id)

    def get_transition_history(
        self,
        entity_id: str,
        limit: int = 50,
    ) -> List[Dict[str, Any]]:
        """Return recent transition history for *entity_id*."""
        session = self._get_session()
        rows = (
            session.query(TransitionHistoryModel)
            .filter(TransitionHistoryModel.entity_id == entity_id)
            .order_by(TransitionHistoryModel.created_at.desc())
            .limit(limit)
            .all()
        )
        return [
            {
                "id": str(r.id),
                "entity_id": r.entity_id,
                "machine_name": r.machine_name,
                "source_state": r.source_state,
                "target_state": r.target_state,
                "trigger": r.trigger,
                "success": r.success,
                "error_type": r.error_type,
                "error_message": r.error_message,
                "actions_executed": r.actions_executed,
                "context_snapshot": r.context_snapshot,
                "created_at": r.created_at,
                "duration_ms": r.duration_ms,
            }
            for r in rows
        ]
