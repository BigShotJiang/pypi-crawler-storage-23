"""Redis state store implementation.

Entity-centric store keyed by ``entity_id``.  Mirrors the architecture of
pycharter's ``RedisMetadataStore``:
- Same ``key_prefix`` / ``_key()`` helper
- Same ``REDIS_AVAILABLE`` guard
- Same ``connect()`` with ``redis.from_url()`` + ``ping()``

Key patterns::

    {prefix}:entity:{entity_id}:state      -> str  (current state name)
    {prefix}:entity:{entity_id}:context    -> JSON  (context dict)
    {prefix}:entity:{entity_id}:metadata   -> JSON  (metadata dict)
    {prefix}:entities:index                -> SET   (all entity_ids)
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from pystator.stores.base import StateStoreClient

try:
    import redis as _redis_lib  # type: ignore[import-not-found,import-untyped]

    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    _redis_lib = None  # type: ignore[assignment]


class RedisStateStore(StateStoreClient):
    """Redis-backed state store.

    Satisfies the ``StateStore`` protocol so it can be passed directly to
    the ``Orchestrator``.

    Constructor and lifecycle mirror pycharter's ``RedisMetadataStore``::

        store = RedisStateStore("redis://localhost:6379/0")
        store.connect()
        store.set_state("order-1", "pending")

    Or with a context manager::

        with RedisStateStore("redis://localhost:6379/0") as store:
            state = store.get_state("order-1")
    """

    def __init__(
        self,
        connection_string: str | None = None,
        key_prefix: str = "pystator",
    ) -> None:
        if not REDIS_AVAILABLE:
            raise ImportError(
                "redis is required for RedisStateStore. "
                "Install with: pip install redis"
            )
        super().__init__(connection_string)
        self.key_prefix = key_prefix
        self._client: Optional[_redis_lib.Redis] = None  # type: ignore[union-attr]

    # ------------------------------------------------------------------
    # Lifecycle  (mirrors pycharter's RedisMetadataStore)
    # ------------------------------------------------------------------

    def connect(self) -> None:
        """Connect to Redis using ``redis.from_url()`` and verify with ``ping()``."""
        if not self.connection_string:
            raise ValueError("connection_string is required for Redis")
        self._client = _redis_lib.from_url(  # type: ignore[union-attr]
            self.connection_string, decode_responses=True
        )
        self._client.ping()
        self._connection = self._client  # sentinel for _require_connection

    def disconnect(self) -> None:
        """Close the Redis connection."""
        if self._client is not None:
            self._client.close()
            self._client = None
        self._connection = None

    # ------------------------------------------------------------------
    # Key helpers  (mirrors pycharter's _key / _contract_key)
    # ------------------------------------------------------------------

    def _key(self, *parts: str) -> str:
        """Build a namespaced Redis key."""
        return f"{self.key_prefix}:{':'.join(parts)}"

    def _entity_key(self, entity_id: str, artifact: str) -> str:
        """Key for an entity artifact (state, context, metadata)."""
        return self._key("entity", entity_id, artifact)

    def _index_key(self) -> str:
        """Key for the entities index set."""
        return self._key("entities", "index")

    def _add_to_index(self, entity_id: str) -> None:
        """Track *entity_id* in the index set."""
        self._require_connection()
        assert self._client is not None  # noqa: S101
        self._client.sadd(self._index_key(), entity_id)

    # ------------------------------------------------------------------
    # StateStore protocol  (sync)
    # ------------------------------------------------------------------

    def get_state(self, entity_id: str) -> str | None:
        """Return the current state for *entity_id*, or ``None``."""
        self._require_connection()
        assert self._client is not None  # noqa: S101
        return self._client.get(self._entity_key(entity_id, "state"))

    def set_state(
        self,
        entity_id: str,
        state: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Persist state for *entity_id*."""
        self._require_connection()
        assert self._client is not None  # noqa: S101
        self._client.set(self._entity_key(entity_id, "state"), state)
        if metadata is not None:
            self._client.set(
                self._entity_key(entity_id, "metadata"),
                json.dumps(metadata),
            )
        self._add_to_index(entity_id)

    def get_context(self, entity_id: str) -> dict[str, Any]:
        """Return persisted context for *entity_id* (empty dict if none)."""
        self._require_connection()
        assert self._client is not None  # noqa: S101
        data = self._client.get(self._entity_key(entity_id, "context"))
        if data is None:
            return {}
        return json.loads(data)

    # ------------------------------------------------------------------
    # Extended helpers (not part of the protocol, but useful)
    # ------------------------------------------------------------------

    def set_context(self, entity_id: str, context: dict[str, Any]) -> None:
        """Persist context for *entity_id*."""
        self._require_connection()
        assert self._client is not None  # noqa: S101
        self._client.set(
            self._entity_key(entity_id, "context"),
            json.dumps(context),
        )
        self._add_to_index(entity_id)

    def get_is_terminal(self, entity_id: str) -> bool | None:
        """Return the ``is_terminal`` flag from stored metadata."""
        self._require_connection()
        assert self._client is not None  # noqa: S101
        data = self._client.get(self._entity_key(entity_id, "metadata"))
        if data is None:
            return None
        meta = json.loads(data)
        val = meta.get("is_terminal")
        return val if isinstance(val, bool) else None

    def list_entities(self) -> List[str]:
        """Return all tracked entity IDs."""
        self._require_connection()
        assert self._client is not None  # noqa: S101
        members = self._client.smembers(self._index_key())
        return sorted(members)

    def delete_entity(self, entity_id: str) -> bool:
        """Remove all keys for *entity_id*. Returns ``True`` if anything was deleted."""
        self._require_connection()
        assert self._client is not None  # noqa: S101
        keys = [
            self._entity_key(entity_id, "state"),
            self._entity_key(entity_id, "context"),
            self._entity_key(entity_id, "metadata"),
        ]
        deleted = self._client.delete(*keys)
        self._client.srem(self._index_key(), entity_id)
        return deleted > 0
