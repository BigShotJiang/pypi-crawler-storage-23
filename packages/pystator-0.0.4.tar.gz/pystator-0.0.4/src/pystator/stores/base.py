"""State store protocols, base class, and in-memory implementation.

Protocols define the duck-typed interface consumed by the Orchestrator.
StateStoreClient provides the shared connect/disconnect lifecycle for
persistent backends (SQLAlchemy, Redis). Mirrors the architecture of
pycharter's MetadataStoreClient.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from pystator.errors import StaleVersionError

# ---------------------------------------------------------------------------
# Protocols
# ---------------------------------------------------------------------------


@runtime_checkable
class StateStore(Protocol):
    """Protocol for synchronous state persistence."""

    def get_state(self, entity_id: str) -> str | None: ...

    def set_state(
        self, entity_id: str, state: str, *, metadata: dict[str, Any] | None = None
    ) -> None: ...

    def get_context(self, entity_id: str) -> dict[str, Any]: ...


@runtime_checkable
class AsyncStateStore(Protocol):
    """Protocol for asynchronous state persistence."""

    async def aget_state(self, entity_id: str) -> str | None: ...

    async def aset_state(
        self, entity_id: str, state: str, *, metadata: dict[str, Any] | None = None
    ) -> None: ...

    async def aget_context(self, entity_id: str) -> dict[str, Any]: ...


@runtime_checkable
class VersionedStateStore(Protocol):
    """Protocol for state stores with optimistic locking.

    Implementations track a monotonically increasing version per entity.
    ``set_state_versioned`` raises ``StaleVersionError`` when the caller's
    expected version does not match the stored version.
    """

    def get_state_versioned(self, entity_id: str) -> tuple[str | None, int | None]:
        """Return ``(state, version)`` for the entity."""
        ...

    def set_state_versioned(
        self,
        entity_id: str,
        state: str,
        *,
        expected_version: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> int:
        """Set state with optimistic locking. Returns the new version."""
        ...


# ---------------------------------------------------------------------------
# Base class for persistent backends
# ---------------------------------------------------------------------------


class StateStoreClient:
    """Base class for persistent state store implementations.

    Provides connect/disconnect lifecycle, context manager support, and
    connection guards.  Mirrors pycharter's ``MetadataStoreClient``.

    Subclasses must override ``connect()`` and should call
    ``_require_connection()`` at the top of every method that touches the
    backend.
    """

    def __init__(self, connection_string: str | None = None) -> None:
        self.connection_string = connection_string
        self._connection: Any = None

    # -- lifecycle -----------------------------------------------------------

    def connect(self) -> None:
        """Establish backend connection.  Subclasses must implement."""
        raise NotImplementedError("Subclasses must implement connect()")

    def disconnect(self) -> None:
        """Close the backend connection."""
        if self._connection is not None:
            self._connection = None

    # -- guards --------------------------------------------------------------

    def _require_connection(self) -> None:
        """Raise ``RuntimeError`` if ``connect()`` has not been called."""
        if self._connection is None:
            raise RuntimeError("Not connected. Call connect() first.")

    # -- context manager -----------------------------------------------------

    def __enter__(self) -> "StateStoreClient":
        self.connect()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.disconnect()


# ---------------------------------------------------------------------------
# In-memory implementation
# ---------------------------------------------------------------------------


class InMemoryStateStore:
    """In-memory state store for testing and simple use cases.

    Implements sync, async, and versioned protocols. Not suitable for production.
    """

    def __init__(self) -> None:
        self._state: dict[str, str] = {}
        self._context: dict[str, dict[str, Any]] = {}
        self._metadata: dict[str, dict[str, Any]] = {}
        self._versions: dict[str, int] = {}

    # Sync API

    def get_state(self, entity_id: str) -> str | None:
        return self._state.get(entity_id)

    def set_state(
        self, entity_id: str, state: str, *, metadata: dict[str, Any] | None = None
    ) -> None:
        self._state[entity_id] = state
        self._versions[entity_id] = self._versions.get(entity_id, 0) + 1
        if metadata is not None:
            self._metadata[entity_id] = dict(metadata)

    def get_context(self, entity_id: str) -> dict[str, Any]:
        return dict(self._context.get(entity_id, {}))

    def set_context(self, entity_id: str, context: dict[str, Any]) -> None:
        self._context[entity_id] = dict(context)

    def get_is_terminal(self, entity_id: str) -> bool | None:
        meta = self._metadata.get(entity_id)
        if meta is None:
            return None
        val = meta.get("is_terminal")
        return val if isinstance(val, bool) else None

    # Versioned API (optimistic locking)

    def get_state_versioned(self, entity_id: str) -> tuple[str | None, int | None]:
        state = self._state.get(entity_id)
        version = self._versions.get(entity_id)
        return state, version

    def set_state_versioned(
        self,
        entity_id: str,
        state: str,
        *,
        expected_version: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> int:
        if expected_version is not None:
            current_version = self._versions.get(entity_id)
            if current_version != expected_version:
                raise StaleVersionError(
                    entity_id=entity_id,
                    expected_version=expected_version,
                    actual_version=current_version or 0,
                )
        self._state[entity_id] = state
        new_version = self._versions.get(entity_id, 0) + 1
        self._versions[entity_id] = new_version
        if metadata is not None:
            self._metadata[entity_id] = dict(metadata)
        return new_version

    # Async API

    async def aget_state(self, entity_id: str) -> str | None:
        return self.get_state(entity_id)

    async def aset_state(
        self, entity_id: str, state: str, *, metadata: dict[str, Any] | None = None
    ) -> None:
        self.set_state(entity_id, state, metadata=metadata)

    async def aget_context(self, entity_id: str) -> dict[str, Any]:
        return self.get_context(entity_id)
