"""Pluggable state store adapters for PyStator.

State stores handle persistence of entity FSM state.  Implement the
``StateStore`` (sync) or ``AsyncStateStore`` (async) protocol for your
backend, or extend ``StateStoreClient`` for the shared connect/disconnect
lifecycle.

Available implementations:

- ``InMemoryStateStore``  -- in-memory store for testing / development
- ``SQLAlchemyStateStore`` -- SQLite and PostgreSQL (requires ``sqlalchemy``)
- ``RedisStateStore``      -- Redis (requires ``redis``)
"""

from pystator.stores.base import (
    AsyncStateStore,
    InMemoryStateStore,
    StateStore,
    StateStoreClient,
    VersionedStateStore,
)

# Import implementations with optional-dependency guards
# (mirrors pycharter's metadata_store/__init__.py pattern)

try:
    from pystator.stores.sqlalchemy import SQLAlchemyStateStore
except ImportError:
    SQLAlchemyStateStore = None  # type: ignore[assignment,misc]

try:
    from pystator.stores.redis import RedisStateStore
except ImportError:
    RedisStateStore = None  # type: ignore[assignment,misc]

__all__ = [
    "AsyncStateStore",
    "InMemoryStateStore",
    "StateStore",
    "StateStoreClient",
    "SQLAlchemyStateStore",
    "RedisStateStore",
    "VersionedStateStore",
]
