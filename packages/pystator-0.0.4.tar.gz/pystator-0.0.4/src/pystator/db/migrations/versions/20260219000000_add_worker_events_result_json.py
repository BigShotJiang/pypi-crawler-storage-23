"""Add result_json to worker_events

Revision ID: 20260219000000
Revises: 20260216000000
Create Date: 2026-02-19

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSON

revision: str = "20260219000000"
down_revision: Union[str, None] = "20260216000000"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _schema() -> str | None:
    """Use pystator schema for PostgreSQL; None for SQLite (no schema support)."""
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()
    op.add_column(
        "worker_events",
        sa.Column("result_json", JSON(), nullable=True),
        schema=schema_name,
    )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_column("worker_events", "result_json", schema=schema_name)
