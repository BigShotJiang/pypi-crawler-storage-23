"""Add worker_events table

Revision ID: 20260216000000
Revises: 20260206000000
Create Date: 2026-02-16

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSON, UUID

revision: str = "20260216000000"
down_revision: Union[str, None] = "20260206000000"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _schema() -> str | None:
    """Use pystator schema for PostgreSQL; None for SQLite (no schema support)."""
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()

    op.create_table(
        "worker_events",
        sa.Column("id", UUID(as_uuid=True), nullable=False),
        sa.Column("machine_name", sa.String(255), nullable=False),
        sa.Column("entity_id", sa.String(255), nullable=False),
        sa.Column("trigger", sa.String(255), nullable=False),
        sa.Column("context_json", JSON(), nullable=True),
        sa.Column("status", sa.String(20), nullable=False, server_default="pending"),
        sa.Column(
            "fires_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column("claimed_by", sa.String(255), nullable=True),
        sa.Column("claimed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("attempt", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("max_attempts", sa.Integer(), nullable=False, server_default="5"),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("idempotency_key", sa.String(255), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("idempotency_key", name="uq_worker_events_idempotency_key"),
        schema=schema_name,
    )

    # Primary polling index: status + fires_at
    op.create_index(
        "ix_worker_events_poll",
        "worker_events",
        ["status", "fires_at"],
        schema=schema_name,
    )

    # Entity lookup (for serialization check and queries)
    op.create_index(
        "ix_worker_events_entity_id",
        "worker_events",
        ["entity_id"],
        schema=schema_name,
    )

    # Machine name lookup
    op.create_index(
        "ix_worker_events_machine_name",
        "worker_events",
        ["machine_name"],
        schema=schema_name,
    )


def downgrade() -> None:
    schema_name = _schema()

    op.drop_index(
        "ix_worker_events_machine_name",
        table_name="worker_events",
        schema=schema_name,
    )
    op.drop_index(
        "ix_worker_events_entity_id",
        table_name="worker_events",
        schema=schema_name,
    )
    op.drop_index(
        "ix_worker_events_poll",
        table_name="worker_events",
        schema=schema_name,
    )

    op.drop_table("worker_events", schema=schema_name)
