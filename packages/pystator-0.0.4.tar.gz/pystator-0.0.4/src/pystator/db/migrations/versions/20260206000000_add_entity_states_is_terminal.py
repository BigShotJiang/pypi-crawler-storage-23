"""Add is_terminal to entity_states

Revision ID: 20260206000000
Revises: 20260205000000
Create Date: 2026-02-06

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "20260206000000"
down_revision: Union[str, None] = "20260205000000"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _schema() -> str | None:
    """Use pystator schema for PostgreSQL; None for SQLite."""
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()
    op.add_column(
        "entity_states",
        sa.Column("is_terminal", sa.Boolean(), nullable=True),
        schema=schema_name,
    )
    op.create_index(
        "ix_entity_states_is_terminal",
        "entity_states",
        ["is_terminal"],
        schema=schema_name,
    )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_index(
        "ix_entity_states_is_terminal",
        table_name="entity_states",
        schema=schema_name,
    )
    op.drop_column("entity_states", "is_terminal", schema=schema_name)
