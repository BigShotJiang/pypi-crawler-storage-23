"""Add entity_states and transition_history tables

Revision ID: 20260205000000
Revises: 20260130000000
Create Date: 2026-02-05

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSON, UUID

revision: str = "20260205000000"
down_revision: Union[str, None] = "20260130000000"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _schema() -> str | None:
    """Use pystator schema for PostgreSQL; None for SQLite (no schema support)."""
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()
    machines_ref = f'{schema_name + "." if schema_name else ""}machines.id'

    # Create entity_states table
    op.create_table(
        "entity_states",
        sa.Column("id", UUID(as_uuid=True), nullable=False),
        sa.Column("entity_id", sa.String(255), nullable=False),
        sa.Column("machine_id", UUID(as_uuid=True), nullable=True),
        sa.Column("machine_name", sa.String(255), nullable=True),
        sa.Column("current_state", sa.String(255), nullable=False),
        sa.Column("context_json", JSON(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["machine_id"],
            [machines_ref],
            name="fk_entity_states_machine_id",
            ondelete="SET NULL",
        ),
        sa.UniqueConstraint("entity_id", name="uq_entity_states_entity_id"),
        schema=schema_name,
    )

    op.create_index(
        "ix_entity_states_entity_id",
        "entity_states",
        ["entity_id"],
        unique=True,
        schema=schema_name,
    )
    op.create_index(
        "ix_entity_states_machine_id",
        "entity_states",
        ["machine_id"],
        schema=schema_name,
    )
    op.create_index(
        "ix_entity_states_machine_name",
        "entity_states",
        ["machine_name"],
        schema=schema_name,
    )
    op.create_index(
        "ix_entity_states_current_state",
        "entity_states",
        ["current_state"],
        schema=schema_name,
    )

    # Create transition_history table
    op.create_table(
        "transition_history",
        sa.Column("id", UUID(as_uuid=True), nullable=False),
        sa.Column("entity_id", sa.String(255), nullable=False),
        sa.Column("machine_name", sa.String(255), nullable=True),
        sa.Column("source_state", sa.String(255), nullable=False),
        sa.Column("target_state", sa.String(255), nullable=True),
        sa.Column("trigger", sa.String(255), nullable=False),
        sa.Column("success", sa.Boolean(), nullable=False, default=False),
        sa.Column("error_type", sa.String(255), nullable=True),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("actions_executed", JSON(), nullable=True),
        sa.Column("context_snapshot", JSON(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("now()"),
            nullable=True,
        ),
        sa.Column("duration_ms", sa.String(50), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        schema=schema_name,
    )

    op.create_index(
        "ix_transition_history_entity_id",
        "transition_history",
        ["entity_id"],
        schema=schema_name,
    )
    op.create_index(
        "ix_transition_history_machine_name",
        "transition_history",
        ["machine_name"],
        schema=schema_name,
    )
    op.create_index(
        "ix_transition_history_created_at",
        "transition_history",
        ["created_at"],
        schema=schema_name,
    )
    op.create_index(
        "ix_transition_history_success",
        "transition_history",
        ["success"],
        schema=schema_name,
    )


def downgrade() -> None:
    schema_name = _schema()

    op.drop_index(
        "ix_transition_history_success",
        table_name="transition_history",
        schema=schema_name,
    )
    op.drop_index(
        "ix_transition_history_created_at",
        table_name="transition_history",
        schema=schema_name,
    )
    op.drop_index(
        "ix_transition_history_machine_name",
        table_name="transition_history",
        schema=schema_name,
    )
    op.drop_index(
        "ix_transition_history_entity_id",
        table_name="transition_history",
        schema=schema_name,
    )

    op.drop_index(
        "ix_entity_states_current_state", table_name="entity_states", schema=schema_name
    )
    op.drop_index(
        "ix_entity_states_machine_name", table_name="entity_states", schema=schema_name
    )
    op.drop_index(
        "ix_entity_states_machine_id", table_name="entity_states", schema=schema_name
    )
    op.drop_index(
        "ix_entity_states_entity_id", table_name="entity_states", schema=schema_name
    )

    op.drop_table("transition_history", schema=schema_name)
    op.drop_table("entity_states", schema=schema_name)
