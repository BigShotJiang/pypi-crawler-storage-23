"""
SQLAlchemy models for PyStator FSM persistence.

Mirrors PyCharter's data model pattern: versioned, audited records.
- MachineModel: FSM definition (meta, states, transitions, error_policy) stored as config_json
  for full round-trip; name + version unique.
- EntityStateModel: Runtime state for each entity (entity_id -> current_state, context).
- TransitionHistoryModel: Audit log of all transition attempts.
- WorkerEventModel: Durable event queue for the worker service.
"""

from pystator.db.models.entity_state import EntityStateModel
from pystator.db.models.machine import MachineModel
from pystator.db.models.transition_history import TransitionHistoryModel
from pystator.db.models.worker_event import WorkerEventModel

__all__ = [
    "EntityStateModel",
    "MachineModel",
    "TransitionHistoryModel",
    "WorkerEventModel",
]
