"""
SQLAlchemy model for transition history (audit log).

Records every transition attempt for an entity, including success/failure,
actions executed, and error messages. Useful for debugging and compliance.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, Column, DateTime, Index, String, Text
from sqlalchemy.dialects.postgresql import UUID

from pystator.db.base import Base


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


class TransitionHistoryModel(Base):
    """
    SQLAlchemy model for FSM transition history.

    Each row records a transition attempt: which entity, from what state,
    to what state, what trigger, whether it succeeded, and what actions ran.
    """

    __tablename__ = "transition_history"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Entity identifier
    entity_id = Column(String(255), nullable=False, index=True)

    # Machine name (denormalized)
    machine_name = Column(String(255), nullable=True)

    # Transition details
    source_state = Column(String(255), nullable=False)
    target_state = Column(String(255), nullable=True)  # Null if transition failed
    trigger = Column(String(255), nullable=False)

    # Outcome
    success = Column(Boolean, nullable=False, default=False)
    error_type = Column(String(255), nullable=True)
    error_message = Column(Text, nullable=True)

    # Actions that were executed (or would have been executed)
    actions_executed = Column(JSON, nullable=True)

    # Context snapshot (optional, for debugging)
    context_snapshot = Column(JSON, nullable=True)

    # Timing (Python default for SQLite/PostgreSQL compatibility)
    created_at = Column(DateTime(timezone=True), default=_utc_now)
    duration_ms = Column(String(50), nullable=True)  # Duration of transition processing

    __table_args__ = (
        Index("ix_transition_history_entity_id", "entity_id"),
        Index("ix_transition_history_machine_name", "machine_name"),
        Index("ix_transition_history_created_at", "created_at"),
        Index("ix_transition_history_success", "success"),
        {"schema": "pystator"},
    )
