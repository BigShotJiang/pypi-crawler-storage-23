"""
SQLAlchemy model for FSM machine definitions.

Stores full FSM configuration (meta, states, transitions, error_policy) as JSON
for round-trip fidelity, mirroring how PyCharter stores contract/schema data.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import JSON, Column, DateTime, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID

from pystator.db.base import Base


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


class MachineModel(Base):
    """
    SQLAlchemy model for FSM machines (state machine definitions).

    config_json holds the full FSM config dict (meta, states, transitions,
    error_policy) so it can be loaded with StateMachine.from_dict(config_json).
    """

    __tablename__ = "machines"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Core identifiers (also in meta)
    name = Column(String(255), nullable=False)  # machine_name from meta
    version = Column(String(50), nullable=False)
    description = Column(Text, nullable=True)
    strict_mode = Column(
        String(10), nullable=True
    )  # store as "true"/"false" or use Boolean

    # Full FSM config for round-trip (meta, states, transitions, error_policy)
    config_json = Column(JSON, nullable=False)

    # Audit fields (Python default for SQLite/PostgreSQL compatibility)
    created_at = Column(DateTime(timezone=True), default=_utc_now)
    updated_at = Column(DateTime(timezone=True), default=_utc_now, onupdate=_utc_now)
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    __table_args__ = (
        UniqueConstraint("name", "version", name="uq_machines_name_version"),
        {"schema": "pystator"},
    )
