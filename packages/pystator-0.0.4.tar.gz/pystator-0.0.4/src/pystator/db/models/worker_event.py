"""
SQLAlchemy model for worker event queue.

The ``worker_events`` table serves as a durable event queue for the
PyStator worker service.  External systems INSERT rows; worker replicas
atomically claim and process them.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import JSON, Column, DateTime, Index, Integer, String, Text
from sqlalchemy.dialects.postgresql import UUID

from pystator.db.base import Base


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


class WorkerEventModel(Base):
    """
    SQLAlchemy model for worker event queue entries.

    Each row represents an event (trigger for an entity) that the worker
    should process.  The ``status`` column drives the claim lifecycle:

        pending  ->  claimed  ->  completed | failed | dead_letter
    """

    __tablename__ = "worker_events"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Which machine and entity this event targets
    machine_name = Column(String(255), nullable=False)
    entity_id = Column(String(255), nullable=False)
    trigger = Column(String(255), nullable=False)

    # Optional context payload (JSON-serializable dict)
    context_json = Column(JSON, nullable=True)

    # Claim lifecycle
    status = Column(String(20), nullable=False, default="pending")
    fires_at = Column(DateTime(timezone=True), nullable=False, default=_utc_now)
    claimed_by = Column(String(255), nullable=True)
    claimed_at = Column(DateTime(timezone=True), nullable=True)

    # Retry tracking
    attempt = Column(Integer, nullable=False, default=0)
    max_attempts = Column(Integer, nullable=False, default=5)
    error_message = Column(Text, nullable=True)

    # Optional idempotency key (unique when non-null)
    idempotency_key = Column(String(255), nullable=True, unique=True)

    # Audit timestamps
    created_at = Column(DateTime(timezone=True), default=_utc_now)
    completed_at = Column(DateTime(timezone=True), nullable=True)

    # Optional result payload (e.g. transition outcome) when completed
    result_json = Column(JSON, nullable=True)

    __table_args__ = (
        # Primary polling index: pending events due now, ordered by fire time
        Index("ix_worker_events_poll", "status", "fires_at"),
        # Entity lookup (for serialization check and queries)
        Index("ix_worker_events_entity_id", "entity_id"),
        # Machine name lookup
        Index("ix_worker_events_machine_name", "machine_name"),
        {"schema": "pystator"},
    )
