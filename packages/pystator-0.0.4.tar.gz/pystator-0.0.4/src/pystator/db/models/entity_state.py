"""
SQLAlchemy model for entity state persistence.

Stores runtime FSM state for each entity (e.g., order_id, workflow_id),
allowing the Orchestrator to load/save state across requests and restarts.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, Column, DateTime, ForeignKey, Index, String, Text
from sqlalchemy.dialects.postgresql import UUID

from pystator.db.base import Base


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


class EntityStateModel(Base):
    """
    SQLAlchemy model for entity FSM state.

    Each entity (identified by entity_id) has a current state and optional
    context. The machine_id optionally links to the machine definition used.
    """

    __tablename__ = "entity_states"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Entity identifier (e.g., order_id, workflow_id, run_id)
    entity_id = Column(String(255), nullable=False, unique=True, index=True)

    # Optional reference to the machine definition
    machine_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pystator.machines.id", ondelete="SET NULL"),
        nullable=True,
    )

    # Machine name (denormalized for queries without join)
    machine_name = Column(String(255), nullable=True)

    # Current FSM state name
    current_state = Column(String(255), nullable=False)

    # True when current_state is a terminal state (set by Orchestrator on persist)
    is_terminal = Column(Boolean, nullable=True)

    # Optional stored context (for guards/actions that need persisted data)
    context_json = Column(JSON, nullable=True)

    # Audit fields (Python default for SQLite/PostgreSQL compatibility)
    created_at = Column(DateTime(timezone=True), default=_utc_now)
    updated_at = Column(DateTime(timezone=True), default=_utc_now, onupdate=_utc_now)

    __table_args__ = (
        Index("ix_entity_states_machine_id", "machine_id"),
        Index("ix_entity_states_machine_name", "machine_name"),
        Index("ix_entity_states_current_state", "current_state"),
        Index("ix_entity_states_is_terminal", "is_terminal"),
        {"schema": "pystator"},
    )
