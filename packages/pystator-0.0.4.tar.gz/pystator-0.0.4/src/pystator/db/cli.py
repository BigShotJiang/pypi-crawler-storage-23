"""
CLI commands for database management (pystator db init, pystator db upgrade)

Following Airflow/PyCharter's pattern: pystator db init, pystator db upgrade
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import Any, Optional

try:
    import yaml  # type: ignore[import-untyped]

    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

try:
    from alembic import command
    from alembic.config import Config
    from sqlalchemy import create_engine, inspect, text

    ALEMBIC_AVAILABLE = True
except ImportError:
    ALEMBIC_AVAILABLE = False

from pystator.config import get_database_url, set_database_url
from pystator.db.base import Base, get_engine, get_session
from pystator.db.paths import get_migrations_dir

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _require_alembic() -> None:
    """Raise error if Alembic is not available."""
    if not ALEMBIC_AVAILABLE:
        raise ImportError(
            "alembic and sqlalchemy are required. Install with: pip install alembic sqlalchemy"
        )


def _get_db_url(database_url: str | None = None, required: bool = True) -> str | None:
    """Resolve database URL from argument, config, or env; default to SQLite."""
    db_url = database_url or get_database_url() or os.getenv("PYSTATOR_DATABASE_URL")
    if not db_url:
        default_db_path = Path.cwd() / "pystator.db"
        db_url = f"sqlite:///{default_db_path}"
        if required:
            print(f"ℹ Using default SQLite database: {db_url}")
    return db_url


def get_alembic_config(database_url: Optional[str] = None) -> Config:
    """
    Get Alembic configuration programmatically (like Airflow).

    Defaults to SQLite (sqlite:///pystator.db) if no database URL is provided.
    """
    config = Config()
    config.set_main_option("script_location", str(get_migrations_dir()))
    config.set_main_option("prepend_sys_path", ".")
    config.set_main_option("version_path_separator", "os")
    config.set_main_option(
        "file_template",
        "%%(year)d%%(month).2d%%(day).2d%%(hour).2d%%(minute).2d%%(second).2d_%%(rev)s_%%(slug)s",
    )

    db_url = database_url or get_database_url() or os.getenv("PYSTATOR_DATABASE_URL")

    # Default to SQLite if no database URL is configured
    if not db_url:
        default_db_path = Path.cwd() / "pystator.db"
        db_url = f"sqlite:///{default_db_path}"

    config.set_main_option("sqlalchemy.url", db_url)
    set_database_url(db_url)

    return config


def _detect_db_type(database_url: str) -> str:
    """Auto-detect database type from connection string."""
    if database_url.startswith(("postgresql://", "postgres://")):
        return "postgresql"
    elif database_url.startswith("sqlite://"):
        return "sqlite"
    # Default to SQLite
    return "sqlite"


# Command functions
def cmd_init(
    database_url: Optional[str] = None,
    db_type: Optional[str] = None,
    force: bool = False,
) -> int:
    """Initialize the database schema from scratch."""
    try:
        db_url = _get_db_url(database_url)
        if not db_url:
            return 1

        db_type = db_type or _detect_db_type(db_url)
        if db_type == "sqlite":
            return _init_sqlite(db_url, force)
        else:
            return _init_postgresql(db_url, force)
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _init_sqlite(database_url: str, force: bool = False) -> int:
    """Initialize SQLite database."""
    _require_alembic()

    try:
        db_path = (
            database_url[10:] if database_url.startswith("sqlite:///") else database_url
        )
        if db_path != ":memory:":
            Path(db_path).parent.mkdir(parents=True, exist_ok=True)

        engine = get_engine(database_url)
        existing_tables = inspect(engine).get_table_names()

        if existing_tables and not force:
            print(
                f"⚠ Warning: Database already contains {len(existing_tables)} tables."
            )
            print(
                "   Use --force to reinitialize, or run 'pystator db upgrade' to apply migrations."
            )
            return 1

        if existing_tables and force:
            with engine.connect() as conn:
                conn.execute(text("PRAGMA foreign_keys=OFF"))
                for name in existing_tables:
                    conn.execute(text(f'DROP TABLE IF EXISTS "{name}"'))
                conn.execute(text("PRAGMA foreign_keys=ON"))
                conn.commit()
            print("✓ Dropped existing tables")

        versions_dir = get_migrations_dir() / "versions"
        if versions_dir.exists() and any(versions_dir.iterdir()):
            # Use migrations as single source of truth (do not create_all first)
            set_database_url(database_url)
            config = get_alembic_config(database_url)
            command.upgrade(config, "head")
            print("✓ Migrations complete")
        else:
            # No migration files: create tables from models
            from pystator.db.models import (  # noqa
                EntityStateModel,
                MachineModel,
                TransitionHistoryModel,
            )

            Base.metadata.create_all(engine)
            print("✓ Created tables using SQLAlchemy models")

        print("✓ SQLite initialization complete!")
        return 0
    except Exception as e:
        print(f"❌ Error initializing SQLite: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _init_postgresql(database_url: str, force: bool = False) -> int:
    """Initialize PostgreSQL database."""
    _require_alembic()

    try:
        set_database_url(database_url)
        config = get_alembic_config(database_url)
        engine = create_engine(database_url)

        # Create schema
        with engine.connect() as conn:
            conn.execute(text('CREATE SCHEMA IF NOT EXISTS "pystator"'))
            conn.commit()
        print("✓ Created 'pystator' schema (if it didn't exist)")

        # Run migrations
        print("Running migrations to initialize database...")
        command.upgrade(config, "head")
        print("✓ Database initialized successfully!")
        return 0
    except Exception as e:
        print(f"❌ Error initializing database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_upgrade(database_url: Optional[str] = None, revision: str = "head") -> int:
    """Upgrade database to the latest revision."""
    _require_alembic()

    try:
        db_url = _get_db_url(database_url)
        if not db_url:
            return 1

        if database_url:
            set_database_url(database_url)

        config = get_alembic_config(db_url)
        print(f"Upgrading database to revision: {revision}...")
        command.upgrade(config, revision)
        print("✓ Database upgraded successfully!")
        return 0
    except Exception as e:
        print(f"❌ Error upgrading database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_downgrade(database_url: Optional[str] = None, revision: str = "-1") -> int:
    """Downgrade database to a previous revision."""
    _require_alembic()

    try:
        db_url = _get_db_url(database_url)
        if not db_url:
            return 1

        if database_url:
            set_database_url(database_url)

        config = get_alembic_config(db_url)
        print(f"Downgrading database to revision: {revision}...")
        command.downgrade(config, revision)
        print("✓ Database downgraded successfully!")
        return 0
    except Exception as e:
        print(f"❌ Error downgrading database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_current(database_url: Optional[str] = None) -> int:
    """Show current database revision."""
    _require_alembic()

    try:
        db_url = _get_db_url(database_url)
        if not db_url:
            return 1

        if database_url:
            set_database_url(database_url)

        engine = create_engine(db_url)
        is_postgres = db_url.startswith(("postgresql://", "postgres://"))

        with engine.connect() as connection:
            try:
                if is_postgres:
                    result = connection.execute(
                        text(
                            'SELECT version_num FROM "pystator".alembic_version LIMIT 1'
                        )
                    )
                else:
                    result = connection.execute(
                        text("SELECT version_num FROM alembic_version LIMIT 1")
                    )
                version = result.fetchone()
                if version:
                    print(f"Current database revision: {version[0]}")
                    return 0
            except Exception:
                pass

            # Fallback: try MigrationContext
            from alembic.runtime.migration import MigrationContext

            context = MigrationContext.configure(connection)
            current_rev = context.get_current_revision()
            if current_rev:
                print(f"Current database revision: {current_rev}")
                return 0

        print("Database is not initialized. Run 'pystator db init' first.")
        return 1
    except Exception as e:
        print(f"❌ Error getting current revision: {e}")
        return 1


def cmd_history(database_url: Optional[str] = None) -> int:
    """Show migration history."""
    _require_alembic()

    try:
        if database_url:
            set_database_url(database_url)
        config = get_alembic_config()
        command.history(config)
        return 0
    except Exception as e:
        print(f"❌ Error showing history: {e}")
        return 1


def cmd_stamp(database_url: Optional[str] = None, revision: str = "head") -> int:
    """Stamp the database with a revision without running migrations."""
    _require_alembic()

    try:
        db_url = _get_db_url(database_url)
        if not db_url:
            return 1

        if database_url:
            set_database_url(database_url)

        config = get_alembic_config(db_url)
        print(f"Stamping database with revision: {revision}...")
        command.stamp(config, revision)
        print(f"✓ Database stamped at {revision}")
        return 0
    except Exception as e:
        print(f"❌ Error stamping database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_seed(seed_dir: Optional[str] = None, database_url: Optional[str] = None) -> int:
    """Seed the database with example FSM machine definitions."""
    if not YAML_AVAILABLE:
        print("❌ Error: PyYAML is required. Install with: pip install pyyaml")
        return 1

    try:
        # Handle swapped arguments
        if seed_dir and any(
            seed_dir.startswith(prefix)
            for prefix in ("postgresql://", "postgres://", "sqlite://")
        ):
            database_url, seed_dir = seed_dir, None

        db_url = _get_db_url(database_url)
        if not db_url:
            return 1

        # Determine seed directory
        if seed_dir:
            seed_path = Path(seed_dir)
        else:
            # Package-bundled seed: pystator/data/seed
            try:
                import pystator as _pkg

                seed_path = Path(_pkg.__file__).resolve().parent / "data" / "seed"
            except (ImportError, AttributeError):
                seed_path = Path(__file__).resolve().parent.parent / "data" / "seed"

        if not seed_path.exists():
            print(f"❌ Error: Seed directory not found: {seed_path}")
            return 1

        print(f"Loading seed data from: {seed_path}")
        return _seed_machines(seed_path, db_url)
    except Exception as e:
        print(f"❌ Error seeding database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _seed_machines(seed_path: Path, db_url: str) -> int:
    """Seed FSM machine definitions from all .yaml files in seed directory."""
    _require_alembic()

    from pystator.db.models import MachineModel

    yaml_files = sorted(seed_path.glob("*.yaml"))
    if not yaml_files:
        print(f"⚠ No .yaml files found in {seed_path}")
        return 0

    machines: list[Any] = []
    for p in yaml_files:
        with open(p, "r") as f:
            data = yaml.safe_load(f)
        if data is None:
            continue
        if isinstance(data, list):
            machines.extend(data)
        else:
            machines.append(data)

    if not machines:
        print("⚠ No machine definitions found in YAML files")
        return 0

    print("Loading FSM machines...")
    session = get_session(db_url)
    try:
        count_created = count_updated = 0

        for machine_data in machines:
            meta = machine_data.get("meta", {})
            # Prefer machine_name (FSMConfig standard) with fallback to name
            name = meta.get("machine_name") or meta.get("name")
            version = meta.get("version", "1.0.0")

            if not name:
                print("⚠ Skipping machine entry without meta.machine_name or meta.name")
                continue

            existing = (
                session.query(MachineModel)
                .filter(
                    MachineModel.name == name,
                    MachineModel.version == version,
                )
                .first()
            )

            if existing:
                # Update existing machine
                existing.config_json = machine_data
                existing.description = machine_data.get("meta", {}).get("description")
                existing.strict_mode = str(
                    machine_data.get("meta", {}).get("strict_mode", False)
                ).lower()
                print(f"  Updated: {name}@{version}")
                count_updated += 1
            else:
                # Create new machine
                machine = MachineModel(
                    name=name,
                    version=version,
                    description=machine_data.get("meta", {}).get("description"),
                    strict_mode=str(
                        machine_data.get("meta", {}).get("strict_mode", False)
                    ).lower(),
                    config_json=machine_data,
                )
                session.add(machine)
                print(f"  Created: {name}@{version}")
                count_created += 1

        session.commit()
        print(
            f"✓ Loaded {count_created + count_updated} machine(s) ({count_created} created, {count_updated} updated)"
        )
        print("\n✓ Seed data loaded successfully!")
        return 0
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()


def cmd_truncate(database_url: Optional[str] = None, force: bool = False) -> int:
    """Truncate all PyStator database tables."""
    _require_alembic()

    try:
        db_url = _get_db_url(database_url)
        if not db_url:
            return 1

        if database_url:
            set_database_url(database_url)

        engine = create_engine(db_url)
        is_postgres = db_url.startswith(("postgresql://", "postgres://"))

        if is_postgres:
            inspector = inspect(engine)
            existing_tables = set(inspector.get_table_names(schema="pystator"))
        else:
            existing_tables = set(inspect(engine).get_table_names())

        # Tables to truncate in order (respecting FK constraints)
        tables = ["transition_history", "entity_states", "machines"]
        existing_tables_to_truncate = [t for t in tables if t in existing_tables]

        if not existing_tables_to_truncate:
            print("⚠ No PyStator tables found to truncate.")
            return 0

        print(
            f"\n⚠ WARNING: This will truncate {len(existing_tables_to_truncate)} table(s):"
        )
        print(f"   {', '.join(existing_tables_to_truncate)}")
        print("\n⚠ ALL DATA IN THESE TABLES WILL BE PERMANENTLY DELETED!")

        if not force:
            try:
                confirmation = input("\nType 'yes' to confirm: ").strip().lower()
                if confirmation not in ["yes", "y"]:
                    print("❌ Truncate cancelled.")
                    return 1
            except (EOFError, KeyboardInterrupt):
                print("\n❌ Truncate cancelled.")
                return 1

        with engine.begin() as conn:
            if is_postgres:
                conn.execute(text("SET session_replication_role = 'replica'"))
                for table in existing_tables_to_truncate:
                    conn.execute(text(f'TRUNCATE TABLE pystator."{table}" CASCADE'))
                    print(f"  ✓ Truncated {table}")
                conn.execute(text("SET session_replication_role = 'origin'"))
            else:
                # SQLite
                conn.execute(text("PRAGMA foreign_keys=OFF"))
                for table in existing_tables_to_truncate:
                    conn.execute(text(f'DELETE FROM "{table}"'))
                    print(f"  ✓ Truncated {table}")
                conn.execute(text("PRAGMA foreign_keys=ON"))

        print("\n✓ Successfully truncated all PyStator tables!")
        return 0
    except Exception as e:
        print(f"❌ Error truncating database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def main():
    """Main CLI entry point for pystator db commands."""
    parser = argparse.ArgumentParser(
        description="PyStator database management commands",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # init
    init_parser = subparsers.add_parser(
        "init", help="Initialize database schema from scratch"
    )
    init_parser.add_argument(
        "database_url",
        nargs="?",
        help="Database connection string (defaults to sqlite:///pystator.db)",
    )
    init_parser.add_argument(
        "--db",
        "--database-type",
        dest="db_type",
        choices=["postgresql", "postgres", "sqlite"],
        default=None,
        help="Database type (auto-detected from URL if not provided)",
    )
    init_parser.add_argument(
        "--force", action="store_true", help="Proceed even if initialized"
    )

    # upgrade
    upgrade_parser = subparsers.add_parser(
        "upgrade", help="Upgrade database to latest revision"
    )
    upgrade_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )
    upgrade_parser.add_argument("--revision", default="head", help="Target revision")

    # downgrade
    downgrade_parser = subparsers.add_parser("downgrade", help="Downgrade database")
    downgrade_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )
    downgrade_parser.add_argument("--revision", default="-1", help="Target revision")

    # current
    current_parser = subparsers.add_parser(
        "current", help="Show current database revision"
    )
    current_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )

    # history
    history_parser = subparsers.add_parser("history", help="Show migration history")
    history_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )

    # stamp
    stamp_parser = subparsers.add_parser(
        "stamp", help="Stamp database with revision without running migrations"
    )
    stamp_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )
    stamp_parser.add_argument("--revision", default="head", help="Revision to stamp")

    # seed
    seed_parser = subparsers.add_parser(
        "seed", help="Seed database with example FSM machines"
    )
    seed_parser.add_argument(
        "seed_dir", nargs="?", help="Directory with seed YAML files"
    )
    seed_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )

    # truncate
    truncate_parser = subparsers.add_parser("truncate", help="Truncate all tables")
    truncate_parser.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )
    truncate_parser.add_argument(
        "--force", action="store_true", help="Skip confirmation"
    )

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    commands = {
        "init": lambda: cmd_init(
            args.database_url, db_type=args.db_type, force=args.force
        ),
        "upgrade": lambda: cmd_upgrade(args.database_url, args.revision),
        "downgrade": lambda: cmd_downgrade(args.database_url, args.revision),
        "current": lambda: cmd_current(args.database_url),
        "history": lambda: cmd_history(args.database_url),
        "stamp": lambda: cmd_stamp(args.database_url, args.revision),
        "seed": lambda: cmd_seed(args.seed_dir, args.database_url),
        "truncate": lambda: cmd_truncate(args.database_url, force=args.force),
    }

    return commands.get(args.command, lambda: (parser.print_help(), 1)[1])()


if __name__ == "__main__":
    sys.exit(main())
