"""Shared path helpers for the database layer."""

from __future__ import annotations

import os
from pathlib import Path


def get_migrations_dir() -> Path:
    """Locate the Alembic migrations directory shipped with the package.

    Resolution order:
        1. Installed package path (``pystator/db/migrations``)
        2. ``src/pystator/db/migrations`` relative to cwd (dev layout)

    Raises:
        FileNotFoundError: if neither location exists.
    """
    try:
        import pystator

        migrations_dir = Path(pystator.__file__).parent / "db" / "migrations"
    except (ImportError, AttributeError):
        migrations_dir = Path(__file__).resolve().parent / "migrations"

    if migrations_dir.exists():
        return migrations_dir

    cwd_migrations = Path(os.getcwd()) / "src" / "pystator" / "db" / "migrations"
    if cwd_migrations.exists():
        return cwd_migrations

    raise FileNotFoundError(
        f"Migrations directory not found. Tried:\n  - {migrations_dir}\n  - {cwd_migrations}"
    )
