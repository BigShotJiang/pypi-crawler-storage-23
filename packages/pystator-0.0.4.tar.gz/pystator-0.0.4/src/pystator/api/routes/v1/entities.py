"""
Route handlers for entity state management (full-service mode).

Unlike /process which is stateless compute-only, these endpoints
manage entity state in the database via SQLAlchemyStateStore.

Full service workflow:
1. Load state from DB (entity_states table)
2. Load machine config from DB or request
3. Process event (compute transition)
4. Persist new state to DB
5. Record transition history
6. Return result with actions to execute
"""

from __future__ import annotations

from datetime import datetime
from typing import Annotated, Any, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlalchemy.orm import Session

from pystator.api.dependencies.database import get_db_session
from pystator.api.services.fsm_service import FSMService
from pystator.db.models import EntityStateModel, MachineModel, TransitionHistoryModel
from pystator.event import Event

router = APIRouter(prefix="/entities", tags=["entities"])


# ============================================================
# Request/Response Models
# ============================================================


class ProcessEntityEventRequest(BaseModel):
    """Request body for processing an event for an entity."""

    trigger: str = Field(..., description="Event trigger name")
    context: dict[str, Any] = Field(
        default_factory=dict, description="Optional context for guards/actions"
    )
    machine_name: Optional[str] = Field(
        None, description="Machine name (required if entity doesn't exist yet)"
    )
    machine_version: Optional[str] = Field(
        None, description="Machine version (defaults to latest)"
    )


class EntityStateResponse(BaseModel):
    """Response for entity state queries."""

    entity_id: str
    current_state: str
    machine_name: Optional[str] = None
    context: dict[str, Any] = Field(default_factory=dict)
    updated_at: Optional[datetime] = None
    created_at: Optional[datetime] = None


class ProcessEntityEventResponse(BaseModel):
    """Response for processing an entity event."""

    success: bool
    entity_id: str
    source_state: str
    target_state: Optional[str] = None
    trigger: str
    actions: list[str] = Field(default_factory=list)
    error: Optional[str] = None
    transition_id: Optional[str] = None


class TransitionHistoryResponse(BaseModel):
    """Response for transition history queries."""

    id: str
    entity_id: str
    source_state: str
    target_state: Optional[str]
    trigger: str
    success: bool
    error_message: Optional[str] = None
    actions_executed: Optional[list[str]] = None
    created_at: datetime


class EntityListResponse(BaseModel):
    """Response for listing entities."""

    entities: list[EntityStateResponse]
    total: int
    limit: int
    offset: int


# ============================================================
# Helper Functions
# ============================================================


def _get_machine_config(
    session: Session,
    machine_name: str,
    machine_version: Optional[str] = None,
) -> dict[str, Any]:
    """Load machine config from database."""
    query = session.query(MachineModel).filter(MachineModel.name == machine_name)

    if machine_version:
        query = query.filter(MachineModel.version == machine_version)
    else:
        # Get latest version
        query = query.order_by(MachineModel.version.desc())

    machine = query.first()
    if not machine:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Machine not found: {machine_name}"
            + (f"@{machine_version}" if machine_version else ""),
        )

    return machine.config_json


def _record_transition(
    session: Session,
    entity_id: str,
    machine_name: Optional[str],
    source_state: str,
    target_state: Optional[str],
    trigger: str,
    success: bool,
    actions: list[str],
    error_message: Optional[str] = None,
    context: Optional[dict] = None,
    duration_ms: Optional[str] = None,
) -> TransitionHistoryModel:
    """Record a transition in the history table."""
    history = TransitionHistoryModel(
        entity_id=entity_id,
        machine_name=machine_name,
        source_state=source_state,
        target_state=target_state,
        trigger=trigger,
        success=success,
        actions_executed=actions if actions else None,
        error_message=error_message,
        context_snapshot=context,
        duration_ms=duration_ms,
    )
    session.add(history)
    session.flush()
    return history


# ============================================================
# Route Handlers
# ============================================================


@router.get(
    "/{entity_id}/state",
    response_model=EntityStateResponse,
    summary="Get entity state",
    description="Get the current state for an entity from the database.",
    responses={
        200: {"description": "Entity state returned"},
        404: {"description": "Entity not found"},
    },
)
async def get_entity_state(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> EntityStateResponse:
    """Get current state for an entity."""
    entity = (
        session.query(EntityStateModel)
        .filter(EntityStateModel.entity_id == entity_id)
        .first()
    )

    if not entity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        )

    return EntityStateResponse(
        entity_id=entity.entity_id,
        current_state=entity.current_state,
        machine_name=entity.machine_name,
        context=entity.context_json or {},
        updated_at=entity.updated_at,
        created_at=entity.created_at,
    )


@router.post(
    "/{entity_id}/events",
    response_model=ProcessEntityEventResponse,
    summary="Process event for entity",
    description=(
        "Full-service event processing: load state from DB, process event, "
        "persist new state, record history, return result. "
        "If entity doesn't exist, creates it with the machine's initial state."
    ),
    responses={
        200: {"description": "Event processed successfully"},
        400: {"description": "Invalid request or transition"},
        404: {"description": "Machine not found"},
    },
)
async def process_entity_event(
    entity_id: str,
    request: ProcessEntityEventRequest,
    session: Annotated[Session, Depends(get_db_session)],
) -> ProcessEntityEventResponse:
    """
    Process an event for an entity with full state persistence.

    This is the "full sandwich" loop:
    1. Load entity state from DB (or create with initial state)
    2. Load machine config from DB
    3. Process event (compute transition)
    4. Persist new state to DB
    5. Record transition in history
    6. Return result
    """
    import time

    start_time = time.time()

    # 1. Load entity state
    entity = (
        session.query(EntityStateModel)
        .filter(EntityStateModel.entity_id == entity_id)
        .first()
    )

    # Determine machine name
    machine_name = request.machine_name or (entity.machine_name if entity else None)
    if not machine_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="machine_name required for new entities",
        )

    # 2. Load machine config
    machine_config = _get_machine_config(session, machine_name, request.machine_version)

    # Get initial state from config
    initial_state = None
    for state in machine_config.get("states", []):
        if state.get("type") == "initial":
            initial_state = state.get("name")
            break

    if entity:
        current_state = entity.current_state
    else:
        if not initial_state:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Machine {machine_name} has no initial state",
            )
        current_state = initial_state

    # 3. Process event (stateless compute)
    service = FSMService()
    try:
        result = service.process(
            config=machine_config,
            current_state=current_state,
            trigger=request.trigger,
            context=request.context,
        )
    except Exception as e:
        # Record failed transition
        duration_ms = str(int((time.time() - start_time) * 1000))
        _record_transition(
            session=session,
            entity_id=entity_id,
            machine_name=machine_name,
            source_state=current_state,
            target_state=None,
            trigger=request.trigger,
            success=False,
            actions=[],
            error_message=str(e),
            context=request.context,
            duration_ms=duration_ms,
        )
        session.commit()

        return ProcessEntityEventResponse(
            success=False,
            entity_id=entity_id,
            source_state=current_state,
            target_state=None,
            trigger=request.trigger,
            actions=[],
            error=str(e),
        )

    # 4. Persist new state
    target_state = result.get("target_state", current_state)
    actions = result.get("actions_to_execute", [])

    if result.get("success", False):
        if entity:
            entity.current_state = target_state
        else:
            entity = EntityStateModel(
                entity_id=entity_id,
                machine_name=machine_name,
                current_state=target_state,
            )
            session.add(entity)

    # 5. Record transition
    duration_ms = str(int((time.time() - start_time) * 1000))
    history = _record_transition(
        session=session,
        entity_id=entity_id,
        machine_name=machine_name,
        source_state=current_state,
        target_state=target_state if result.get("success") else None,
        trigger=request.trigger,
        success=result.get("success", False),
        actions=actions,
        error_message=result.get("error"),
        context=request.context,
        duration_ms=duration_ms,
    )

    session.commit()

    # 6. Return result
    return ProcessEntityEventResponse(
        success=result.get("success", False),
        entity_id=entity_id,
        source_state=current_state,
        target_state=target_state if result.get("success") else None,
        trigger=request.trigger,
        actions=actions,
        error=result.get("error"),
        transition_id=str(history.id),
    )


@router.get(
    "/{entity_id}/history",
    response_model=list[TransitionHistoryResponse],
    summary="Get entity transition history",
    description="Get the transition history for an entity.",
    responses={
        200: {"description": "Transition history returned"},
    },
)
async def get_entity_history(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
    limit: int = Query(default=50, le=200, description="Max records to return"),
    offset: int = Query(default=0, ge=0, description="Records to skip"),
) -> list[TransitionHistoryResponse]:
    """Get transition history for an entity."""
    history = (
        session.query(TransitionHistoryModel)
        .filter(TransitionHistoryModel.entity_id == entity_id)
        .order_by(TransitionHistoryModel.created_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )

    return [
        TransitionHistoryResponse(
            id=str(h.id),
            entity_id=h.entity_id,
            source_state=h.source_state,
            target_state=h.target_state,
            trigger=h.trigger,
            success=h.success,
            error_message=h.error_message,
            actions_executed=h.actions_executed,
            created_at=h.created_at,
        )
        for h in history
    ]


@router.delete(
    "/{entity_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete entity state",
    description="Delete an entity's state record (does not delete history).",
    responses={
        204: {"description": "Entity deleted"},
        404: {"description": "Entity not found"},
    },
)
async def delete_entity(
    entity_id: str,
    session: Annotated[Session, Depends(get_db_session)],
) -> None:
    """Delete an entity's state record."""
    entity = (
        session.query(EntityStateModel)
        .filter(EntityStateModel.entity_id == entity_id)
        .first()
    )

    if not entity:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity not found: {entity_id}",
        )

    session.delete(entity)
    session.commit()


@router.get(
    "",
    response_model=EntityListResponse,
    summary="List entities",
    description="List all entities, optionally filtered by machine name.",
    responses={
        200: {"description": "Entity list returned"},
    },
)
async def list_entities(
    session: Annotated[Session, Depends(get_db_session)],
    machine_name: Optional[str] = Query(default=None, description="Filter by machine"),
    state: Optional[str] = Query(default=None, description="Filter by current state"),
    limit: int = Query(default=50, le=200, description="Max records to return"),
    offset: int = Query(default=0, ge=0, description="Records to skip"),
) -> EntityListResponse:
    """List entities with optional filtering."""
    query = session.query(EntityStateModel)

    if machine_name:
        query = query.filter(EntityStateModel.machine_name == machine_name)
    if state:
        query = query.filter(
            func.lower(EntityStateModel.current_state) == state.lower()
        )

    total = query.count()
    entities = (
        query.order_by(EntityStateModel.updated_at.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )

    return EntityListResponse(
        entities=[
            EntityStateResponse(
                entity_id=e.entity_id,
                current_state=e.current_state,
                machine_name=e.machine_name,
                context=e.context_json or {},
                updated_at=e.updated_at,
                created_at=e.created_at,
            )
            for e in entities
        ],
        total=total,
        limit=limit,
        offset=offset,
    )
