"""Orchestrator: sandwich loop (load state, process, persist, execute actions).

The app implements a state store adapter and calls
``orchestrator.process_event(entity_id, event)``.
"""

from __future__ import annotations

import inspect
import logging
from typing import TYPE_CHECKING, Any, Callable

from pystator._types import TransitionResult
from pystator.actions import ActionExecutor, ActionRegistry
from pystator.errors import FSMError
from pystator.event import Event
from pystator.guards import GuardRegistry
from pystator.machine import StateMachine
from pystator.stores.base import AsyncStateStore, StateStore

if TYPE_CHECKING:
    from pystator.scheduler.base import SchedulerAdapter

logger = logging.getLogger(__name__)

# Type alias for context validator functions.
# Signature: (entity_id, current_state, trigger, context) -> (ok, errors)
ContextValidatorFn = Callable[
    [str, str, str, dict[str, Any]],
    tuple[bool, list[str]],
]


class Orchestrator:
    """Runs the full FSM sandwich loop: load -> process -> persist -> execute.

    Args:
        machine: The StateMachine definition.
        state_store: Sync or async state store.
        guards: Guard registry (bound to machine automatically).
        actions: Action registry.
        context_validator: Optional callable for pre-transition context validation.
        executor: Optional ActionExecutor (created automatically if omitted).
        scheduler: Optional scheduler for delayed transitions.
        use_initial_state_when_missing: Use machine's initial state for new entities.

    Context validation options (choose one or combine):

        1. ``context_validator`` (recommended for external validation, e.g. PyCharter):
           Callable with signature ``(entity_id, state, trigger, context) -> (ok, errors)``.
           Runs BEFORE guards. Use for schema or contract validation.

        2. ``machine.meta["validate_context"]``: Config-driven, set in YAML/dict.
           Validates that required keys exist in context. Lightweight, no external deps.

        3. Guards: Use for business-rule validation that depends on state + context.
           Runs AFTER context_validator. Best for domain logic (e.g., "is_cancellable").
    """

    def __init__(
        self,
        machine: StateMachine,
        state_store: StateStore | AsyncStateStore,
        guards: GuardRegistry | None = None,
        actions: ActionRegistry | None = None,
        *,
        context_validator: ContextValidatorFn | None = None,
        executor: ActionExecutor | None = None,
        scheduler: "SchedulerAdapter | None" = None,
        use_initial_state_when_missing: bool = True,
    ) -> None:
        self._machine = machine
        self._store = state_store

        # Bind guards if provided
        if guards is not None:
            machine.bind_guards(guards)

        # Use machine's registries if not explicitly provided
        self._guards = guards or machine.guard_registry
        self._actions = actions or machine.action_registry
        self._executor = executor or ActionExecutor(self._actions, log_execution=True)
        self._context_validator = context_validator
        self._scheduler = scheduler
        self._use_initial = use_initial_state_when_missing

    # ------------------------------------------------------------------
    # Sync API
    # ------------------------------------------------------------------

    def process_event(
        self,
        entity_id: str,
        event: str | Event,
        context: dict[str, Any] | None = None,
    ) -> TransitionResult:
        """Run the sandwich loop synchronously."""
        store = self._store
        if not isinstance(store, StateStore):
            raise TypeError(
                "process_event requires a sync StateStore "
                "(get_state, set_state, get_context)"
            )

        current_state = store.get_state(entity_id)
        if current_state is None:
            if self._use_initial:
                current_state = self._machine.get_initial_state().name
            else:
                raise ValueError(
                    f"Entity {entity_id!r} has no state and "
                    "use_initial_state_when_missing is False"
                )

        ctx = dict(store.get_context(entity_id))
        if isinstance(event, Event):
            ctx.update(event.payload)
        else:
            event = Event(trigger=event)
        if context:
            ctx.update(context)
        ctx["_event"] = event
        ctx["_entity_id"] = entity_id

        # Validate context if configured (inline machine validation)
        if self._machine.meta.get("validate_context"):
            valid, errors = self._machine.validate_context(ctx)
            if not valid:
                return TransitionResult.failure_result(
                    source_state=current_state,
                    trigger=event.trigger,
                    error=FSMError(
                        "Context validation failed",
                        context={"validation_errors": errors},
                    ),
                    metadata={"reason": "context_validation"},
                )

        # External context validator (e.g. PyCharter data contract validation)
        if self._context_validator is not None:
            ok, val_errors = self._context_validator(
                entity_id, current_state, event.trigger, ctx
            )
            if not ok:
                return TransitionResult.failure_result(
                    source_state=current_state,
                    trigger=event.trigger,
                    error=FSMError(
                        f"Validation failed: {'; '.join(val_errors)}",
                        context={"validation_errors": val_errors},
                    ),
                    metadata={"reason": "context_validation"},
                )

        result = self._machine.process(current_state, event, ctx)

        if result.success and result.target_state is not None:
            self._machine._engine.apply_history(result)
            if result.target_state != current_state:
                metadata = {
                    "trigger": result.trigger,
                    "source_state": result.source_state,
                    "target_state": result.target_state,
                    "is_terminal": result.target_state in self._machine.terminal_states,
                }
                store.set_state(entity_id, result.target_state, metadata=metadata)

            if result.all_action_specs:
                ctx["new_status"] = result.target_state
                self._executor.execute(result, ctx)

        return result

    # ------------------------------------------------------------------
    # Async API
    # ------------------------------------------------------------------

    async def async_process_event(
        self,
        entity_id: str,
        event: str | Event,
        context: dict[str, Any] | None = None,
    ) -> TransitionResult:
        """Run the sandwich loop asynchronously."""
        store = self._store
        if not isinstance(store, AsyncStateStore):
            raise TypeError(
                "async_process_event requires an AsyncStateStore "
                "(aget_state, aset_state, aget_context)"
            )

        current_state = await store.aget_state(entity_id)
        if current_state is None:
            if self._use_initial:
                current_state = self._machine.get_initial_state().name
            else:
                raise ValueError(
                    f"Entity {entity_id!r} has no state and "
                    "use_initial_state_when_missing is False"
                )

        ctx = dict(await store.aget_context(entity_id))
        if isinstance(event, Event):
            ctx.update(event.payload)
        else:
            event = Event(trigger=event)
        if context:
            ctx.update(context)
        ctx["_event"] = event
        ctx["_entity_id"] = entity_id

        if self._machine.meta.get("validate_context"):
            valid, errors = self._machine.validate_context(ctx)
            if not valid:
                return TransitionResult.failure_result(
                    source_state=current_state,
                    trigger=event.trigger,
                    error=FSMError(
                        "Context validation failed",
                        context={"validation_errors": errors},
                    ),
                    metadata={"reason": "context_validation"},
                )

        # External context validator (e.g. PyCharter data contract validation)
        if self._context_validator is not None:
            if inspect.iscoroutinefunction(self._context_validator):
                ok, val_errors = await self._context_validator(
                    entity_id, current_state, event.trigger, ctx
                )
            else:
                ok, val_errors = self._context_validator(
                    entity_id, current_state, event.trigger, ctx
                )
            if not ok:
                return TransitionResult.failure_result(
                    source_state=current_state,
                    trigger=event.trigger,
                    error=FSMError(
                        f"Validation failed: {'; '.join(val_errors)}",
                        context={"validation_errors": val_errors},
                    ),
                    metadata={"reason": "context_validation"},
                )

        result = await self._machine.aprocess(current_state, event, ctx)

        if result.success and result.target_state is not None:
            self._machine._engine.apply_history(result)
            state_changed = result.target_state != current_state

            if state_changed:
                # Cancel pending delayed transitions
                if self._scheduler:
                    await self._scheduler.cancel_for_entity(entity_id)

                metadata = {
                    "trigger": result.trigger,
                    "source_state": result.source_state,
                    "target_state": result.target_state,
                    "is_terminal": result.target_state in self._machine.terminal_states,
                }
                await store.aset_state(
                    entity_id, result.target_state, metadata=metadata
                )

                # Schedule delayed transitions from new state
                if self._scheduler:
                    await self._schedule_delayed(entity_id, result.target_state, ctx)

            if result.all_action_specs:
                ctx["new_status"] = result.target_state
                await self._executor.async_execute(result, ctx)

        return result

    # ------------------------------------------------------------------
    # Delayed transition scheduling
    # ------------------------------------------------------------------

    async def _schedule_delayed(
        self, entity_id: str, state_name: str, context: dict[str, Any]
    ) -> None:
        if self._scheduler is None:
            return
        for trans in self._machine.transitions:
            if trans.is_delayed and trans.matches_source(state_name):
                ctx_copy = context.copy()

                async def _make_cb(evt: str, ctx: dict[str, Any]) -> Any:
                    async def cb() -> None:
                        await self.async_process_event(entity_id, evt, ctx)

                    return cb

                cb = await _make_cb(trans.trigger, ctx_copy)
                await self._scheduler.schedule(
                    delay_ms=trans.after,  # type: ignore[arg-type]
                    callback=cb,
                    entity_id=entity_id,
                    event=trans.trigger,
                    metadata={"state": state_name},
                )

    async def close(self) -> None:
        """Clean up resources (scheduler, etc.)."""
        if self._scheduler:
            await self._scheduler.close()
