"""Guard registry and evaluation for PyStator FSM.

Guards are pure functions that determine whether a transition should
be allowed. They receive a context dict and return a boolean.

This module merges the registry and evaluator into a single file.
"""

from __future__ import annotations

import asyncio
import threading
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Protocol, Union, runtime_checkable

from pystator._types import GuardSpec, Transition
from pystator.errors import GuardNotFoundError, GuardRejectedError

# ---------------------------------------------------------------------------
# Protocols
# ---------------------------------------------------------------------------


@runtime_checkable
class GuardFunc(Protocol):
    """Synchronous guard function protocol."""

    def __call__(self, context: dict[str, Any]) -> bool: ...


@runtime_checkable
class AsyncGuardFunc(Protocol):
    """Asynchronous guard function protocol."""

    def __call__(self, context: dict[str, Any]) -> Awaitable[bool]: ...


AnyGuardFunc = Union[
    GuardFunc,
    AsyncGuardFunc,
    Callable[[dict[str, Any]], Union[bool, Awaitable[bool]]],
]


# ---------------------------------------------------------------------------
# GuardResult
# ---------------------------------------------------------------------------


@dataclass
class GuardResult:
    """Result of guard evaluation.

    Attributes:
        passed: Whether all guards passed.
        guard_name: Name of the last evaluated guard (if failed).
        message: Explanation of the result.
        evaluated_guards: List of (guard_name, passed) tuples.
    """

    passed: bool
    guard_name: str | None = None
    message: str = ""
    evaluated_guards: list[tuple[str, bool]] = field(default_factory=list)

    def __bool__(self) -> bool:
        """Allow truthiness check: ``if guard_result:`` works naturally."""
        return self.passed

    @classmethod
    def success(cls, evaluated: list[tuple[str, bool]] | None = None) -> GuardResult:
        return cls(passed=True, evaluated_guards=evaluated or [])

    @classmethod
    def failure(
        cls,
        guard_name: str,
        message: str = "",
        evaluated: list[tuple[str, bool]] | None = None,
    ) -> GuardResult:
        return cls(
            passed=False,
            guard_name=guard_name,
            message=message or f"Guard '{guard_name}' rejected transition",
            evaluated_guards=evaluated or [],
        )


# ---------------------------------------------------------------------------
# Inline expression evaluation
# ---------------------------------------------------------------------------

_INLINE_GUARD_BUILTINS: dict[str, Any] = {
    "len": len,
    "min": min,
    "max": max,
    "abs": abs,
    "sum": sum,
}


def _eval_expression(expr: str, context: dict[str, Any]) -> bool:
    """Evaluate a boolean expression with context as namespace.

    Uses simpleeval for safe evaluation. Allowed builtins: len, min, max, abs, sum.
    """
    try:
        from simpleeval import SimpleEval
    except ImportError as e:
        raise ImportError(
            "Inline guard expressions require simpleeval. "
            "Install with: pip install pystator[recipes]"
        ) from e

    evaluator = SimpleEval(names=context)
    for name, func in _INLINE_GUARD_BUILTINS.items():
        evaluator.functions[name] = func
    return bool(evaluator.eval(expr))


# ---------------------------------------------------------------------------
# GuardRegistry
# ---------------------------------------------------------------------------


class GuardRegistry:
    """Registry for guard functions (sync and async).

    Example:
        >>> registry = GuardRegistry()
        >>> registry.register("is_valid", lambda ctx: ctx.get("valid", False))
        >>> registry.evaluate("is_valid", {"valid": True})
        True
    """

    def __init__(self) -> None:
        self._guards: dict[str, AnyGuardFunc] = {}
        self._async_guards: set[str] = set()
        self._lock = threading.Lock()

    def register(self, name: str, func: AnyGuardFunc) -> None:
        """Register a guard function. Thread-safe."""
        if not name:
            raise ValueError("Guard name cannot be empty")
        with self._lock:
            if name in self._guards:
                raise ValueError(f"Guard '{name}' is already registered")
            self._guards[name] = func
            if asyncio.iscoroutinefunction(func) or (
                hasattr(func, "__call__")
                and asyncio.iscoroutinefunction(getattr(func, "__call__", None))
            ):
                self._async_guards.add(name)

    def unregister(self, name: str) -> None:
        """Unregister a guard function. Thread-safe."""
        with self._lock:
            if name not in self._guards:
                raise GuardNotFoundError(f"Guard '{name}' not found", guard_name=name)
            del self._guards[name]
            self._async_guards.discard(name)

    def get(self, name: str) -> AnyGuardFunc:
        if name not in self._guards:
            raise GuardNotFoundError(f"Guard '{name}' not found", guard_name=name)
        return self._guards[name]

    def has(self, name: str) -> bool:
        return name in self._guards

    def is_async(self, name: str) -> bool:
        return name in self._async_guards

    def evaluate(self, name: str, context: dict[str, Any]) -> bool:
        """Evaluate a single guard synchronously."""
        return self.get(name)(context)  # type: ignore[return-value]

    def evaluate_all(
        self,
        guards: tuple[str, ...] | list[str],
        context: dict[str, Any],
        fail_fast: bool = True,
    ) -> GuardResult:
        """Evaluate multiple guards. Returns GuardResult."""
        if not guards:
            return GuardResult.success()
        evaluated: list[tuple[str, bool]] = []
        for name in guards:
            result = self.evaluate(name, context)
            evaluated.append((name, result))
            if not result and fail_fast:
                return GuardResult.failure(name, evaluated=evaluated)
        for name, passed in evaluated:
            if not passed:
                return GuardResult.failure(name, evaluated=evaluated)
        return GuardResult.success(evaluated)

    async def async_evaluate(self, name: str, context: dict[str, Any]) -> bool:
        func = self.get(name)
        if self.is_async(name):
            return await func(context)  # type: ignore[misc]
        return func(context)  # type: ignore[return-value]

    async def async_evaluate_all(
        self,
        guards: tuple[GuardSpec, ...] | tuple[str, ...] | list[str],
        context: dict[str, Any],
        fail_fast: bool = True,
    ) -> GuardResult:
        if not guards:
            return GuardResult.success()
        evaluated: list[tuple[str, bool]] = []
        for guard in guards:
            name = guard.name if isinstance(guard, GuardSpec) else guard
            if name is None:
                continue
            result = await self.async_evaluate(name, context)
            evaluated.append((name, result))
            if not result and fail_fast:
                return GuardResult.failure(name, evaluated=evaluated)
        for name, passed in evaluated:
            if not passed:
                return GuardResult.failure(name, evaluated=evaluated)
        return GuardResult.success(evaluated)

    def list_guards(self) -> list[str]:
        return list(self._guards.keys())

    def clear(self) -> None:
        self._guards.clear()
        self._async_guards.clear()

    def __len__(self) -> int:
        return len(self._guards)

    def __contains__(self, name: str) -> bool:
        return name in self._guards

    def decorator(
        self, name: str | None = None
    ) -> Callable[[AnyGuardFunc], AnyGuardFunc]:
        """Decorator to register a guard function.

        Example:
            >>> @registry.decorator()
            ... def is_valid(ctx: dict) -> bool:
            ...     return ctx.get("valid", False)
        """

        def inner(func: AnyGuardFunc) -> AnyGuardFunc:
            self.register(name or func.__name__, func)
            return func

        return inner


# ---------------------------------------------------------------------------
# GuardEvaluator
# ---------------------------------------------------------------------------


class GuardEvaluator:
    """Evaluates guard conditions for transitions.

    Supports named guards (from registry) and inline expressions.
    """

    def __init__(
        self,
        registry: GuardRegistry | None = None,
        strict: bool = True,
    ) -> None:
        self.registry = registry
        self.strict = strict

    def can_transition(
        self,
        transition: Transition,
        context: dict[str, Any],
    ) -> GuardResult:
        """Check if a transition is allowed based on its guards."""
        if not transition.guards:
            return GuardResult.success()
        return self._evaluate_guards(transition.guards, context)

    def _evaluate_guards(
        self,
        guards: tuple[GuardSpec, ...],
        context: dict[str, Any],
    ) -> GuardResult:
        evaluated: list[tuple[str, bool]] = []
        for guard in guards:
            guard_id = guard.expr if guard.is_expression else guard.name
            try:
                if guard.is_expression:
                    result = _eval_expression(guard.expr, context)  # type: ignore[arg-type]
                    evaluated.append((f"expr:{guard.expr}", result))
                else:
                    guard_name = guard.name  # type: ignore[assignment]
                    if self.registry is None or not self.registry.has(guard_name):
                        if self.strict:
                            raise GuardNotFoundError(
                                f"Guard '{guard_name}' not registered",
                                guard_name=guard_name,
                            )
                        evaluated.append((guard_name, True))
                        continue
                    result = self.registry.evaluate(guard_name, context)
                    evaluated.append((guard_name, result))
                if not result:
                    return GuardResult.failure(str(guard_id), evaluated=evaluated)
            except GuardNotFoundError:
                raise
            except Exception as e:
                evaluated.append((str(guard_id), False))
                return GuardResult.failure(
                    str(guard_id),
                    message=f"Guard '{guard_id}' raised exception: {e}",
                    evaluated=evaluated,
                )
        return GuardResult.success(evaluated)

    def get_required_guards(
        self,
        transitions: list[Transition] | tuple[Transition, ...],
    ) -> set[str]:
        """Return the set of named guard names required by the given transitions.

        Excludes inline expression guards (only returns guard names from registry).
        """
        names: set[str] = set()
        for trans in transitions:
            for guard in trans.guards:
                if guard.name is not None:
                    names.add(guard.name)
        return names

    def evaluate_and_raise(
        self,
        transition: Transition,
        current_state: str,
        context: dict[str, Any],
    ) -> None:
        """Evaluate guards and raise GuardRejectedError if blocked."""
        result = self.can_transition(transition, context)
        if not result.passed:
            raise GuardRejectedError(
                message=result.message,
                current_state=current_state,
                trigger=transition.trigger,
                guard_name=result.guard_name or "unknown",
                guard_result=result.evaluated_guards,
            )


# ---------------------------------------------------------------------------
# Builtin guard factories (for convenience)
# ---------------------------------------------------------------------------


def equals(key: str, value: Any) -> Callable[[dict[str, Any]], bool]:
    """Guard factory: context[key] == value."""

    def guard(ctx: dict[str, Any]) -> bool:
        return ctx.get(key) == value

    return guard


def greater_than(key: str, value: Any) -> Callable[[dict[str, Any]], bool]:
    """Guard factory: context[key] > value."""

    def guard(ctx: dict[str, Any]) -> bool:
        v = ctx.get(key)
        if v is None:
            return False
        try:
            return v > value
        except TypeError:
            return False

    return guard


def in_list(key: str, values: list[Any]) -> Callable[[dict[str, Any]], bool]:
    """Guard factory: context[key] in values."""

    def guard(ctx: dict[str, Any]) -> bool:
        return ctx.get(key) in values

    return guard


def all_of(
    *guards: Callable[[dict[str, Any]], bool]
) -> Callable[[dict[str, Any]], bool]:
    """Compound guard: all must pass."""

    def guard(ctx: dict[str, Any]) -> bool:
        return all(g(ctx) for g in guards)

    return guard


def any_of(
    *guards: Callable[[dict[str, Any]], bool]
) -> Callable[[dict[str, Any]], bool]:
    """Compound guard: at least one must pass."""

    def guard(ctx: dict[str, Any]) -> bool:
        return any(g(ctx) for g in guards)

    return guard


def negate(
    guard_fn: Callable[[dict[str, Any]], bool],
) -> Callable[[dict[str, Any]], bool]:
    """Guard that negates the result of another guard."""

    def guard(ctx: dict[str, Any]) -> bool:
        return not guard_fn(ctx)

    return guard
