"""Pure stateless transition engine.

Contains the core FSM processing logic: find transitions, evaluate
guards, compute exit/enter chains, and build TransitionResult.

New features beyond the original engine:
- Internal transitions (skip exit/enter actions)
- Automatic (eventless) transitions (fire on state entry when guards pass)
- History pseudo-state resolution (H(…) / H*(…))
"""

from __future__ import annotations

import itertools
import re
from typing import Any, Literal

from pystator._hierarchy import StateHierarchy
from pystator._parallel import ParallelStateConfig, ParallelStateManager
from pystator._types import ActionSpec, HistoryType, State, Transition, TransitionResult
from pystator.context import TransitionContext
from pystator.errors import (
    ConfigurationError,
    ErrorPolicy,
    InvalidTransitionError,
    TerminalStateError,
    UndefinedStateError,
    UndefinedTriggerError,
)
from pystator.event import Event

# Regex for history destination: H(StateName) or H*(StateName)
_HISTORY_RE = re.compile(r"^H(\*?)\((\w[\w.]*)\)$")

# Maximum depth for auto-transition chains (prevents infinite loops)
_MAX_AUTO_DEPTH = 20


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _normalize_event(event: str | Event) -> tuple[str, Event]:
    """Normalize to (trigger, Event)."""
    if isinstance(event, str):
        return event, Event(trigger=event)
    return event.trigger, event


def _build_context(
    context: dict[str, Any] | None, event_obj: Event
) -> TransitionContext:
    """Merge event payload into context."""
    ctx = TransitionContext(context or {})
    ctx.update(event_obj.payload)
    ctx["_event"] = event_obj
    return ctx


def _extract_guard_details(
    guard_result: Any, transition: Transition
) -> list[dict[str, Any]]:
    """Extract guard evaluation details from a guard result.

    If *guard_result* is ``True`` (no guards or trivial pass), returns
    an entry per guard spec marked as passed. If it carries
    ``evaluated_guards`` (a :class:`GuardResult`), builds the list from
    that attribute.
    """
    if guard_result is True:
        # No guards evaluated — build synthetic "all passed" list
        return [{"name": g.name or g.expr, "passed": True} for g in transition.guards]
    evaluated = getattr(guard_result, "evaluated_guards", None)
    if evaluated:
        return [{"name": name, "passed": passed} for name, passed in evaluated]
    # Fallback: just mark all guards with the overall result
    passed = bool(guard_result)
    return [{"name": g.name or g.expr, "passed": passed} for g in transition.guards]


def parse_history_dest(dest: str) -> tuple[str, HistoryType] | None:
    """Parse a history destination like ``H(Parent)`` or ``H*(Parent)``.

    Returns (parent_state_name, history_type) or None if not a history ref.
    """
    m = _HISTORY_RE.match(dest)
    if m is None:
        return None
    star = m.group(1)
    parent = m.group(2)
    ht = HistoryType.DEEP if star == "*" else HistoryType.SHALLOW
    return parent, ht


# ---------------------------------------------------------------------------
# Guard evaluator protocol (injected by StateMachine)
# ---------------------------------------------------------------------------


class _GuardChecker:
    """Thin wrapper around guard evaluation. Injected by StateMachine.

    Returns True (no guards) or a GuardResult object (guards evaluated).
    Callers can check truthiness: both ``True`` and a passing
    ``GuardResult`` are truthy.
    """

    def __init__(self) -> None:
        self._registry: Any = None
        self._evaluator: Any = None
        self.strict: bool = True

    def can_transition(self, transition: Transition, context: dict[str, Any]) -> Any:
        """Evaluate guards. Returns True (no guards) or GuardResult."""
        if not transition.guards:
            return True
        if self._evaluator is None:
            if self.strict:
                raise ConfigurationError(
                    "Guards referenced but no guard registry bound. "
                    "Call bind_guards() before processing events.",
                    context={"guards": [str(g) for g in transition.guards]},
                )
            return True
        return self._evaluator.can_transition(transition, context)

    async def async_can_transition(
        self, transition: Transition, context: dict[str, Any]
    ) -> Any:
        """Async guard evaluation. Returns True (no guards) or GuardResult."""
        if not transition.guards:
            return True
        if self._evaluator is None:
            if self.strict:
                raise ConfigurationError(
                    "Guards referenced but no guard registry bound.",
                    context={"guards": [str(g) for g in transition.guards]},
                )
            return True
        if self._registry is not None:
            return await self._registry.async_evaluate_all(transition.guards, context)
        return self.can_transition(transition, context)


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------


class Engine:
    """Pure stateless FSM engine.

    Owns the state/transition definitions, hierarchy, parallel manager,
    and transition index. Computes TransitionResults without side effects.
    """

    def __init__(
        self,
        states: dict[str, State],
        transitions: list[Transition],
        meta: dict[str, Any],
        error_policy: ErrorPolicy,
    ) -> None:
        self._states = states
        self._transitions = transitions
        self._meta = meta
        self._error_policy = error_policy
        self._event_normalizer: Literal["lower", "upper"] | None = meta.get(
            "event_normalizer"
        )

        # Hierarchy & parallel
        self._hierarchy = StateHierarchy(states)
        root_initial = next(n for n in self._hierarchy.roots if states[n].is_initial)
        self._initial_leaf: str = self._hierarchy.resolve_initial_leaf(root_initial)
        self._parallel = ParallelStateManager(states)

        # Guards (injected later)
        self.guard_checker = _GuardChecker()
        self.guard_checker.strict = error_policy.strict_mode

        # Transition indexes for O(ancestors) lookup
        self._build_indexes()

        # Validate
        self._validate()

    def _build_indexes(self) -> None:
        """Build transition indexes for efficient lookup."""
        # (normalized_trigger, source_state) → list of non-auto transitions
        self._trigger_index: dict[tuple[str, str], list[Transition]] = {}
        # source_state → list of auto transitions
        self._auto_index: dict[str, list[Transition]] = {}
        # (normalized_trigger, region, source_state) → list of region transitions
        self._region_index: dict[tuple[str, str, str], list[Transition]] = {}

        for trans in self._transitions:
            normalized = self._normalize_trigger(trans.trigger)
            for source in trans.source:
                if trans.region is not None:
                    key = (normalized, trans.region, source)
                    self._region_index.setdefault(key, []).append(trans)
                elif trans.auto:
                    self._auto_index.setdefault(source, []).append(trans)
                else:
                    key_t = (normalized, source)
                    self._trigger_index.setdefault(key_t, []).append(trans)

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def _validate(self) -> None:
        for trans in self._transitions:
            for source in trans.source:
                if source not in self._states:
                    raise ConfigurationError(
                        f"Transition references undefined source state: {source}",
                        context={"transition": trans.trigger, "source": source},
                    )
            # Skip validation for history destinations (they are resolved at runtime)
            if not trans.is_history_target and trans.dest not in self._states:
                raise ConfigurationError(
                    f"Transition references undefined destination state: {trans.dest}",
                    context={"transition": trans.trigger, "dest": trans.dest},
                )

        for state in self._states.values():
            if state.timeout and state.timeout.destination not in self._states:
                raise ConfigurationError(
                    f"State timeout references undefined destination: "
                    f"{state.timeout.destination}",
                    context={"state": state.name},
                )

    # ------------------------------------------------------------------
    # Trigger normalization
    # ------------------------------------------------------------------

    def _normalize_trigger(self, trigger: str) -> str:
        if self._event_normalizer == "lower":
            return trigger.lower()
        if self._event_normalizer == "upper":
            return trigger.upper()
        return trigger

    # ------------------------------------------------------------------
    # Transition lookup
    # ------------------------------------------------------------------

    def _find_transitions(self, current_state: str, trigger: str) -> list[Transition]:
        """Find transitions matching state + trigger, ordered by specificity."""
        normalized = self._normalize_trigger(trigger)
        ancestors = self._hierarchy.ancestors(current_state)

        seen: set[int] = set()
        candidates: list[Transition] = []
        for ancestor in ancestors:
            for trans in self._trigger_index.get((normalized, ancestor), ()):
                tid = id(trans)
                if tid not in seen:
                    seen.add(tid)
                    candidates.append(trans)

        # Already ordered by specificity (ancestors is leaf-first)
        return candidates

    def _find_auto_transitions(self, current_state: str) -> list[Transition]:
        """Find all auto transitions whose source matches current_state."""
        ancestors = self._hierarchy.ancestors(current_state)
        seen: set[int] = set()
        result: list[Transition] = []
        for ancestor in ancestors:
            for trans in self._auto_index.get(ancestor, ()):
                tid = id(trans)
                if tid not in seen:
                    seen.add(tid)
                    result.append(trans)
        return result

    # ------------------------------------------------------------------
    # History resolution
    # ------------------------------------------------------------------

    def _resolve_dest(self, dest: str) -> str:
        """Resolve transition destination, handling history pseudo-states."""
        parsed = parse_history_dest(dest)
        if parsed is not None:
            parent, ht = parsed
            return self._hierarchy.resolve_history(parent, ht)
        return self._hierarchy.effective_target_leaf(dest)

    # ------------------------------------------------------------------
    # Result construction
    # ------------------------------------------------------------------

    def _build_success(
        self,
        source_leaf: str,
        transition: Transition,
        trigger: str,
        guard_result: Any = True,
    ) -> TransitionResult:
        """Build a success TransitionResult for a normal (external) transition."""
        target_leaf = self._resolve_dest(transition.dest)

        # Guard evaluation details (empty list if no guards)
        guard_details = (
            _extract_guard_details(guard_result, transition)
            if transition.guards
            else []
        )

        if transition.internal:
            # Internal transition: no exit/enter, only transition actions
            metadata: dict[str, Any] = {"internal": True}
            if guard_details:
                metadata["guards"] = guard_details
            return TransitionResult.success_result(
                source_state=source_leaf,
                target_state=source_leaf,
                trigger=trigger,
                actions=transition.actions,
                on_exit=(),
                on_enter=(),
                metadata=metadata,
            )

        # External transition: compute exit/enter chains via LCA
        lca = self._hierarchy.lca(source_leaf, target_leaf)

        # Collect history updates (caller applies via apply_history)
        exit_chain = self._hierarchy.exit_chain(source_leaf, lca)
        history_updates: dict[str, str] = {}
        for state_name in exit_chain:
            parent = self._states.get(state_name)
            if parent and parent.parent:
                history_updates[parent.parent] = state_name

        enter_chain = self._hierarchy.enter_chain(lca, target_leaf)

        on_exit = tuple(
            itertools.chain.from_iterable(self._states[s].on_exit for s in exit_chain)
        )
        on_enter = tuple(
            itertools.chain.from_iterable(self._states[s].on_enter for s in enter_chain)
        )

        metadata = {"transition_description": transition.description}
        if guard_details:
            metadata["guards"] = guard_details
        if history_updates:
            metadata["_history_updates"] = history_updates

        return TransitionResult.success_result(
            source_state=source_leaf,
            target_state=target_leaf,
            trigger=trigger,
            actions=transition.actions,
            on_exit=on_exit,
            on_enter=on_enter,
            metadata=metadata,
        )

    def _handle_no_transition(
        self, current_state: str, trigger: str
    ) -> TransitionResult:
        if self._error_policy.strict_mode:
            normalized = self._normalize_trigger(trigger)
            all_triggers = {
                self._normalize_trigger(t.trigger) for t in self._transitions
            }
            if normalized not in all_triggers:
                error = UndefinedTriggerError(
                    f"Trigger '{trigger}' is not defined in this machine",
                    trigger=trigger,
                    available_triggers=sorted(all_triggers),
                )
            else:
                error = InvalidTransitionError(
                    f"No transition for trigger '{trigger}' from state "
                    f"'{current_state}'",
                    current_state=current_state,
                    trigger=trigger,
                )
            return TransitionResult.failure_result(
                source_state=current_state, trigger=trigger, error=error
            )
        return TransitionResult.no_op_result(current_state, trigger)

    def _handle_guard_failure(
        self,
        current_state: str,
        trigger: str,
        candidates: list[Transition],
        guard_details: list[dict[str, Any]] | None = None,
    ) -> TransitionResult:
        error = InvalidTransitionError(
            f"All guards failed for trigger '{trigger}' from state "
            f"'{current_state}'",
            current_state=current_state,
            trigger=trigger,
            context={"candidate_count": len(candidates), "reason": "guards_failed"},
        )
        metadata: dict[str, Any] = {"reason": "guards_failed"}
        if guard_details:
            metadata["guards"] = guard_details
        return TransitionResult.failure_result(
            source_state=current_state,
            trigger=trigger,
            error=error,
            metadata=metadata,
        )

    # ------------------------------------------------------------------
    # Core process: shared preparation
    # ------------------------------------------------------------------

    def _prepare_process(
        self,
        current_state: str,
        event: str | Event,
        context: dict[str, Any] | None,
    ) -> TransitionResult | tuple[str, dict[str, Any], list[Transition]]:
        """Shared validation, normalization, and candidate lookup.

        Returns a TransitionResult for early exits (terminal, no match),
        or a (trigger, ctx, candidates) tuple for the guard-check loop.
        """
        trigger, event_obj = _normalize_event(event)
        trigger = self._normalize_trigger(trigger)
        ctx = _build_context(context, event_obj)

        if current_state not in self._states:
            raise UndefinedStateError(
                f"State '{current_state}' is not defined",
                state_name=current_state,
            )

        state = self._states[current_state]
        if state.is_terminal:
            return TransitionResult.failure_result(
                source_state=current_state,
                trigger=trigger,
                error=TerminalStateError(current_state, trigger),
                metadata={"reason": "terminal_state"},
            )

        candidates = self._find_transitions(current_state, trigger)
        if not candidates:
            return self._handle_no_transition(current_state, trigger)

        return trigger, ctx, candidates

    # ------------------------------------------------------------------
    # Core process (sync)
    # ------------------------------------------------------------------

    def process(
        self,
        current_state: str,
        event: str | Event,
        context: dict[str, Any] | None = None,
    ) -> TransitionResult:
        """Compute transition result for the given state + event."""
        prep = self._prepare_process(current_state, event, context)
        if isinstance(prep, TransitionResult):
            return prep
        trigger, ctx, candidates = prep

        all_guard_details: list[dict[str, Any]] = []
        for transition in candidates:
            guard_result = self.guard_checker.can_transition(transition, ctx)
            if guard_result:
                return self._build_success(
                    current_state, transition, trigger, guard_result
                )
            # Collect failed guard details for the failure metadata
            if transition.guards:
                all_guard_details.extend(
                    _extract_guard_details(guard_result, transition)
                )

        return self._handle_guard_failure(
            current_state, trigger, candidates, all_guard_details or None
        )

    # ------------------------------------------------------------------
    # Core process (async)
    # ------------------------------------------------------------------

    async def aprocess(
        self,
        current_state: str,
        event: str | Event,
        context: dict[str, Any] | None = None,
    ) -> TransitionResult:
        """Async version of process() -- supports async guards."""
        prep = self._prepare_process(current_state, event, context)
        if isinstance(prep, TransitionResult):
            return prep
        trigger, ctx, candidates = prep

        all_guard_details: list[dict[str, Any]] = []
        for transition in candidates:
            guard_result = await self.guard_checker.async_can_transition(
                transition, ctx
            )
            if guard_result:
                return self._build_success(
                    current_state, transition, trigger, guard_result
                )
            if transition.guards:
                all_guard_details.extend(
                    _extract_guard_details(guard_result, transition)
                )

        return self._handle_guard_failure(
            current_state, trigger, candidates, all_guard_details or None
        )

    # ------------------------------------------------------------------
    # Auto (eventless) transitions
    # ------------------------------------------------------------------

    def _prepare_auto_step(self, state: str) -> list[Transition] | None:
        """Return auto candidates for one step, or None to stop."""
        candidates = self._find_auto_transitions(state)
        return candidates if candidates else None

    def evaluate_auto_transitions(
        self,
        current_state: str,
        context: dict[str, Any],
        *,
        max_depth: int = _MAX_AUTO_DEPTH,
    ) -> list[TransitionResult]:
        """Evaluate automatic transitions from current_state.

        Auto transitions fire immediately when their source state is
        entered and their guards pass. Chaining is supported up to
        ``max_depth`` to prevent infinite loops.

        Returns:
            List of auto-transition results (may be empty).
        """
        results: list[TransitionResult] = []
        state = current_state

        for _ in range(max_depth):
            auto_candidates = self._prepare_auto_step(state)
            if auto_candidates is None:
                break

            fired = False
            for trans in auto_candidates:
                guard_result = self.guard_checker.can_transition(trans, context)
                if guard_result:
                    result = self._build_success(
                        state, trans, trans.trigger, guard_result
                    )
                    results.append(result)
                    if result.success and result.target_state:
                        state = result.target_state
                    fired = True
                    break

            if not fired:
                break

        return results

    async def async_evaluate_auto_transitions(
        self,
        current_state: str,
        context: dict[str, Any],
        *,
        max_depth: int = _MAX_AUTO_DEPTH,
    ) -> list[TransitionResult]:
        """Async version of evaluate_auto_transitions."""
        results: list[TransitionResult] = []
        state = current_state

        for _ in range(max_depth):
            auto_candidates = self._prepare_auto_step(state)
            if auto_candidates is None:
                break

            fired = False
            for trans in auto_candidates:
                guard_result = await self.guard_checker.async_can_transition(
                    trans, context
                )
                if guard_result:
                    result = self._build_success(
                        state, trans, trans.trigger, guard_result
                    )
                    results.append(result)
                    if result.success and result.target_state:
                        state = result.target_state
                    fired = True
                    break

            if not fired:
                break

        return results

    # ------------------------------------------------------------------
    # Parallel state processing
    # ------------------------------------------------------------------

    def _prepare_parallel(
        self,
        config: ParallelStateConfig,
        event: str | Event,
        context: dict[str, Any] | None,
    ) -> tuple[str, dict[str, Any], dict[str, list[Transition]]]:
        """Shared preparation for parallel processing.

        Returns (trigger, ctx, region_candidates) where region_candidates
        maps region_name to its candidate transitions.
        """
        trigger, event_obj = _normalize_event(event)
        trigger = self._normalize_trigger(trigger)
        ctx = _build_context(context, event_obj)

        region_candidates: dict[str, list[Transition]] = {}
        for region_name, current in config.region_states.items():
            region_trans = self._find_region_transitions(
                config.parallel_state, region_name, current, trigger
            )
            if region_trans:
                region_candidates[region_name] = region_trans

        return trigger, ctx, region_candidates

    def process_parallel(
        self,
        config: ParallelStateConfig,
        event: str | Event,
        context: dict[str, Any] | None = None,
    ) -> tuple[ParallelStateConfig, list[TransitionResult]]:
        """Process an event for a parallel state configuration."""
        trigger, ctx, region_candidates = self._prepare_parallel(config, event, context)

        results: list[TransitionResult] = []
        updated = config

        for region_name, region_trans in region_candidates.items():
            current = config.region_states[region_name]
            for trans in region_trans:
                guard_result = self.guard_checker.can_transition(trans, ctx)
                if guard_result:
                    result = self._build_region_result(
                        config.parallel_state,
                        region_name,
                        current,
                        trans,
                        trigger,
                        guard_result=guard_result,
                    )
                    results.append(result)
                    if result.success and result.target_state:
                        updated = updated.with_region_state(
                            region_name, result.target_state
                        )
                    break

        return updated, results

    async def aprocess_parallel(
        self,
        config: ParallelStateConfig,
        event: str | Event,
        context: dict[str, Any] | None = None,
    ) -> tuple[ParallelStateConfig, list[TransitionResult]]:
        """Async version of process_parallel."""
        trigger, ctx, region_candidates = self._prepare_parallel(config, event, context)

        results: list[TransitionResult] = []
        updated = config

        for region_name, region_trans in region_candidates.items():
            current = config.region_states[region_name]
            for trans in region_trans:
                guard_result = await self.guard_checker.async_can_transition(trans, ctx)
                if guard_result:
                    result = self._build_region_result(
                        config.parallel_state,
                        region_name,
                        current,
                        trans,
                        trigger,
                        guard_result=guard_result,
                    )
                    results.append(result)
                    if result.success and result.target_state:
                        updated = updated.with_region_state(
                            region_name, result.target_state
                        )
                    break

        return updated, results

    def _find_region_transitions(
        self,
        parallel_state: str,
        region_name: str,
        current_state: str,
        trigger: str,
    ) -> list[Transition]:
        normalized = self._normalize_trigger(trigger)
        return self._region_index.get((normalized, region_name, current_state), [])

    def _build_region_result(
        self,
        parallel_state: str,
        region_name: str,
        source: str,
        transition: Transition,
        trigger: str,
        guard_result: Any = True,
    ) -> TransitionResult:
        target = transition.dest
        on_exit: tuple[ActionSpec, ...] = ()
        on_enter: tuple[ActionSpec, ...] = ()
        if source in self._states:
            on_exit = self._states[source].on_exit
        if target in self._states:
            on_enter = self._states[target].on_enter

        metadata: dict[str, Any] = {
            "parallel_state": parallel_state,
            "region": region_name,
            "transition_description": transition.description,
        }
        if transition.guards:
            metadata["guards"] = _extract_guard_details(guard_result, transition)

        return TransitionResult.success_result(
            source_state=source,
            target_state=target,
            trigger=trigger,
            actions=transition.actions,
            on_exit=on_exit,
            on_enter=on_enter,
            metadata=metadata,
        )

    # ------------------------------------------------------------------
    # History application
    # ------------------------------------------------------------------

    def apply_history(self, result: TransitionResult) -> None:
        """Apply history updates from a transition result.

        Call this after ``process()`` to record history for compound states.
        This keeps ``process()`` itself pure and stateless.
        """
        updates = result.metadata.get("_history_updates")
        if updates and isinstance(updates, dict):
            for compound_state, active_child in updates.items():
                self._hierarchy.record_history(compound_state, active_child)

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    @property
    def initial_leaf(self) -> str:
        return self._initial_leaf

    @property
    def hierarchy(self) -> StateHierarchy:
        return self._hierarchy

    @property
    def parallel(self) -> ParallelStateManager:
        return self._parallel
