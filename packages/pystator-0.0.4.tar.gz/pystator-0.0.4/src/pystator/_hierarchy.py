"""State hierarchy (statecharts) with history support.

Builds and owns the state tree. Exposes ancestors, LCA, exit/enter
chains, initial leaf resolution, and history state tracking.
"""

from __future__ import annotations

from pystator._types import HistoryType, State, StateType
from pystator.errors import ConfigurationError


class StateHierarchy:
    """Tree of states with parent/child relationships and history tracking.

    Validates structure (one root initial, no cycles) and provides
    hierarchy queries: ancestors, LCA, exit/enter chains, initial leaf
    resolution, and history resolution.
    """

    def __init__(self, states: dict[str, State]) -> None:
        self._states = states
        self._parent: dict[str, str] = {}
        self._children: dict[str, list[str]] = {name: [] for name in states}
        self._roots: list[str] = []

        for name, state in states.items():
            if state.parent is not None:
                self._parent[name] = state.parent
                self._children.setdefault(state.parent, []).append(name)
            else:
                self._roots.append(name)

        self._validate()

        # History tracking: compound_state -> last active child
        self._history: dict[str, str] = {}

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def _validate(self) -> None:
        """Ensure one root initial, no cycles, all parent/initial_child refs exist."""
        for child, parent in self._parent.items():
            if parent not in self._states:
                raise ConfigurationError(
                    f"State '{child}' references unknown parent '{parent}'",
                    context={"state": child, "parent": parent},
                )

        # No cycles
        for name in self._states:
            seen: set[str] = set()
            current: str | None = name
            while current is not None:
                if current in seen:
                    raise ConfigurationError(
                        f"Cycle in parent chain involving state '{name}'",
                        context={"state": name},
                    )
                seen.add(current)
                current = self._parent.get(current)

        # All initial_child refs exist
        for name, state in self._states.items():
            if state.initial_child is not None:
                if state.initial_child not in self._states:
                    raise ConfigurationError(
                        f"State '{name}' references unknown initial_child "
                        f"'{state.initial_child}'",
                        context={"state": name, "initial_child": state.initial_child},
                    )

        # Exactly one root initial state
        root_initial = [
            r for r in self._roots if self._states[r].type == StateType.INITIAL
        ]
        if len(root_initial) == 0:
            raise ConfigurationError(
                "No initial state defined (no root state with type 'initial')",
                context={"roots": self._roots},
            )
        if len(root_initial) > 1:
            raise ConfigurationError(
                "Multiple root initial states defined",
                context={"root_initial": root_initial},
            )

    # ------------------------------------------------------------------
    # Hierarchy queries
    # ------------------------------------------------------------------

    def ancestors(self, leaf: str) -> list[str]:
        """Path from leaf to root: [leaf, parent, grandparent, …]."""
        if leaf not in self._states:
            return []
        path = [leaf]
        current: str | None = leaf
        while current is not None:
            parent = self._parent.get(current)
            if parent is None:
                break
            path.append(parent)
            current = parent
        return path

    def resolve_initial_leaf(self, state_name: str) -> str:
        """Follow initial_child chain from compound state to leaf."""
        if state_name not in self._states:
            return state_name
        current = state_name
        while True:
            state = self._states[current]
            if state.initial_child is None:
                return current
            current = state.initial_child
            if current not in self._states:
                return state_name

    def effective_target_leaf(self, dest: str) -> str:
        """Resolve transition destination to a leaf state."""
        return self.resolve_initial_leaf(dest)

    def lca(self, leaf_a: str, leaf_b: str) -> str | None:
        """Lowest common ancestor. None if different trees."""
        if leaf_a not in self._states or leaf_b not in self._states:
            return None
        anc_a = set(self.ancestors(leaf_a))
        for node in self.ancestors(leaf_b):
            if node in anc_a:
                return node
        return None

    def exit_chain(self, from_leaf: str, to_lca: str | None) -> list[str]:
        """States from from_leaf up to (but not including) to_lca."""
        path = self.ancestors(from_leaf)
        if to_lca is None:
            return path
        result = []
        for s in path:
            if s == to_lca:
                break
            result.append(s)
        return result

    def enter_chain(self, from_lca: str | None, to_leaf: str) -> list[str]:
        """States from first child of from_lca down to to_leaf."""
        path_from_root = list(reversed(self.ancestors(to_leaf)))
        if from_lca is None:
            return path_from_root
        try:
            idx = path_from_root.index(from_lca)
            return path_from_root[idx + 1 :]
        except ValueError:
            return path_from_root

    def is_compound(self, state_name: str) -> bool:
        """True if state has initial_child."""
        if state_name not in self._states:
            return False
        return self._states[state_name].initial_child is not None

    def children(self, state_name: str) -> list[str]:
        """Direct children of the state."""
        return list(self._children.get(state_name, []))

    @property
    def roots(self) -> list[str]:
        """Root state names (no parent)."""
        return list(self._roots)

    # ------------------------------------------------------------------
    # History tracking
    # ------------------------------------------------------------------

    def record_history(self, compound_state: str, active_child: str) -> None:
        """Record the last active child for a compound state.

        Called by the engine when exiting a compound state so that
        future H(…) / H*(…) transitions can resolve correctly.
        """
        self._history[compound_state] = active_child

    def resolve_history(
        self,
        compound_state: str,
        history_type: HistoryType,
    ) -> str:
        """Resolve a history pseudo-state to the remembered child.

        Args:
            compound_state: The compound state whose history to resolve.
            history_type: SHALLOW (immediate child) or DEEP (nested leaf).

        Returns:
            Resolved state name. Falls back to initial_child if no history.
        """
        remembered = self._history.get(compound_state)

        if remembered is None:
            # No history recorded -- fall back to initial child / initial leaf
            return self.resolve_initial_leaf(compound_state)

        if history_type == HistoryType.SHALLOW:
            return remembered
        # DEEP: resolve to leaf from the remembered state
        return self.resolve_initial_leaf(remembered)

    def clear_history(self) -> None:
        """Clear all recorded history."""
        self._history.clear()
