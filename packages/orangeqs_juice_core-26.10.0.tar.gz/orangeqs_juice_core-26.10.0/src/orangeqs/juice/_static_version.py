# This file has been created by setup.py.
version = '26.10.0'
