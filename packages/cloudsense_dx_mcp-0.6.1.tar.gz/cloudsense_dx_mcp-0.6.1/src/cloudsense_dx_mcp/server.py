#!/usr/bin/env python3
"""
CloudSense DX MCP Server.

Provides MCP tools and prompts for CloudSense DX operations
(orchestration template management, etc.).

Run directly:     python -m cloudsense_dx_mcp.server
Via entry point:  cloudsense-dx-mcp
"""

import asyncio
import json
import logging
import subprocess
import sys
import time
from typing import Any, Dict, List

from .logging_config import (
    SESSION_ID,
    get_system_info,
    log_event,
    setup_logging,
)

_CURRENT_VERSION = "0.6.1"

setup_logging()

from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import (
    GetPromptResult,
    Prompt,
    PromptArgument,
    PromptMessage,
    PromptsCapability,
    ServerCapabilities,
    TextContent,
    Tool,
    ToolsCapability,
)

from .tools import list_templates, fetch_templates, run_apex, diagnostics

logger = logging.getLogger("cloudsense_dx_mcp.server")

# ---------------------------------------------------------------------------
# Server instructions (sent to MCP clients on initialization)
# ---------------------------------------------------------------------------

SERVER_INSTRUCTIONS = """\
You are connected to the CloudSense DX MCP server. Use the tools provided by \
this server for orchestration template operations and CloudSense-specific tasks.

TOOL ROUTING (follow these rules strictly):

1. list_orchestration_templates -- Use when the user wants to SEE or BROWSE templates.
   Trigger words: "show", "list", "what templates", "search", "find", "which templates", \
   "how many templates".
   This tool returns template names and IDs only. It does NOT download template content.

2. fetch_orchestration_templates -- Use when the user wants to GET or SAVE templates.
   Trigger words: "get", "fetch", "download", "export", "pull", "save", "retrieve".
   This tool downloads the full template JSON and saves files to disk.
   When the user says "get 10 templates" or "get all templates", use THIS tool, not list.
   IMPORTANT: You MUST provide either template_names OR set fetch_all to true.
   If the user wants ALL templates, set fetch_all: true (do NOT omit template_names).
   If the user wants specific templates, pass them in template_names.

3. run_apex -- Use ONLY when the user explicitly asks to run Apex code, execute Apex \
   statements, or when the request cannot be fulfilled by the two tools above.
   Do NOT use run_apex for orchestration template operations -- always prefer \
   list_orchestration_templates or fetch_orchestration_templates instead.

TEMPLATE NAME RESOLUTION:
- If the user specifies exact template names, pass them in template_names.
- If the user wants ALL templates (e.g. "get all templates"), set fetch_all: true.
- For ANY other case, use list_orchestration_templates FIRST to discover names, \
  then call fetch_orchestration_templates with the resolved template_names:
  - "get 10 templates" -> list all, pick 10, then fetch with template_names.
  - "get order templates" -> list with search_term="order", then fetch matches.
  - "get latest 2 templates" -> list all, pick 2, then fetch with template_names.
  - Partial or misspelled names -> list with search_term to find matches, \
    confirm with user, then fetch with confirmed template_names.
- NEVER omit both template_names and fetch_all -- the tool will reject it to \
  prevent accidentally downloading every template.

ORG RESOLUTION (IMPORTANT -- do NOT ask the user which org to use):
- If the user mentions an org (e.g. "from itxdevpro", "on p2dev"), pass it as org_alias.
- If the user gives a partial hint (e.g. "devpro"), pass it as-is -- the tool \
  will fuzzy-match it against authenticated orgs.
- If the user does NOT mention any org, simply OMIT the org_alias parameter. \
  The tool will automatically resolve the org from the session history or the \
  workspace default.
- After every tool call, tell the user which org was used (from the response's \
  "org" and "org_source" fields).

APEX OUTPUT CONVENTION (for run_apex):
- Use System.debug(LoggingLevel.ERROR, '###TAG###' + data) in Apex code for \
  structured output extraction. The server parses these tagged debug lines \
  from the execution log and returns them as structured output.

CLOUDSENSE APEX APIs (for use with run_apex):
When generating Apex code for CloudSense operations, use these global APIs:

  // Export orchestration templates
  List<CSPOFA.ProcessTemplateExportRequest> reqs = \
      new List<CSPOFA.ProcessTemplateExportRequest>{
          new CSPOFA.ProcessTemplateExportRequest()
              .templateName('Template Name')
              .format(CSPOFA.SerializationFormat.JSON)
      };
  List<CSPOFA.ApiResult> results = CSPOFA.API_V1.processTemplates.export(reqs);

DO NOT use Salesforce DX MCP or other tools for orchestration template operations \
or CloudSense-specific operations -- always use this server's tools.\
"""

# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------

app = Server("cloudsense-dx")

# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

_TOOLS = {
    list_templates.TOOL_NAME: list_templates,
    fetch_templates.TOOL_NAME: fetch_templates,
    run_apex.TOOL_NAME: run_apex,
    diagnostics.TOOL_NAME: diagnostics,
}

_call_counter = 0


@app.list_tools()
async def handle_list_tools() -> List[Tool]:
    return [Tool(**t.TOOL_DEFINITION) for t in _TOOLS.values()]


@app.call_tool()
async def handle_call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
    from uuid import uuid4

    global _call_counter
    _call_counter += 1
    call_number = _call_counter

    tool_module = _TOOLS.get(name)
    if not tool_module:
        return [TextContent(type="text", text=json.dumps({"error": f"Unknown tool: {name}"}))]

    request_id = uuid4().hex[:12]
    start = time.monotonic()

    try:
        result_text = await tool_module.execute(arguments or {})
        duration = round(time.monotonic() - start, 2)
        try:
            parsed = json.loads(result_text)
        except (json.JSONDecodeError, TypeError):
            parsed = {}
        log_event(
            logger, "INFO",
            event="tool_call",
            request_id=request_id,
            session_id=SESSION_ID,
            call_number=call_number,
            tool=name,
            version=_CURRENT_VERSION,
            duration_s=duration,
            success=parsed.get("success", True),
            org=parsed.get("org"),
            org_source=parsed.get("org_source"),
            **_tool_specific_fields(name, parsed),
        )
        return [TextContent(type="text", text=result_text)]
    except Exception as e:
        duration = round(time.monotonic() - start, 2)
        log_event(
            logger, "ERROR",
            event="tool_call",
            request_id=request_id,
            session_id=SESSION_ID,
            call_number=call_number,
            tool=name,
            version=_CURRENT_VERSION,
            duration_s=duration,
            success=False,
            error_type=type(e).__name__,
            error_message=str(e),
        )
        return [TextContent(
            type="text",
            text=json.dumps({"success": False, "error": str(e)}, indent=2),
        )]


def _tool_specific_fields(name: str, parsed: dict) -> dict:
    """Extract tool-specific metrics from the parsed result."""
    if name == "fetch_orchestration_templates":
        summary = parsed.get("summary", {})
        return {
            "templates_requested": summary.get("total_requested"),
            "templates_succeeded": summary.get("succeeded"),
            "templates_failed": summary.get("failed"),
            "fetch_all": parsed.get("fetch_all"),
            "max_workers": parsed.get("max_workers"),
            "elapsed_seconds": parsed.get("elapsed_seconds"),
        }
    if name == "list_orchestration_templates":
        return {
            "templates_found": parsed.get("total_count"),
            "search_term": parsed.get("search_term"),
        }
    if name == "run_apex":
        return {
            "log_lines": parsed.get("log_lines"),
            "allow_dml": parsed.get("allow_dml"),
        }
    return {}

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

@app.list_prompts()
async def handle_list_prompts() -> List[Prompt]:
    return [
        Prompt(
            name="fetch-orchestration",
            description=(
                "Guided workflow to fetch orchestration process templates from a "
                "Salesforce org. Walks through org selection, template discovery, "
                "user confirmation, and parallel fetching."
            ),
            arguments=[
                PromptArgument(
                    name="org_alias",
                    description=(
                        "Salesforce org alias (e.g. 'itxdevpro'). "
                        "Leave blank to use the default target-org from sf CLI."
                    ),
                    required=False,
                ),
                PromptArgument(
                    name="template_names",
                    description=(
                        "Comma-separated template names to fetch, or 'all' to fetch "
                        "every template. Leave blank to be guided through discovery."
                    ),
                    required=False,
                ),
            ],
        ),
    ]


@app.get_prompt()
async def handle_get_prompt(name: str, arguments: Dict[str, str] | None) -> GetPromptResult:
    if name != "fetch-orchestration":
        raise ValueError(f"Unknown prompt: {name}")

    args = arguments or {}
    org_alias = args.get("org_alias", "").strip()
    template_names = args.get("template_names", "").strip()

    workflow_text = _build_fetch_orchestration_prompt(org_alias, template_names)

    return GetPromptResult(
        description="Guided workflow for fetching orchestration process templates",
        messages=[
            PromptMessage(
                role="user",
                content=TextContent(type="text", text=workflow_text),
            )
        ],
    )


def _build_fetch_orchestration_prompt(org_alias: str, template_names: str) -> str:
    lines = [
        "You are helping the user fetch CloudSense orchestration process templates.",
        "Follow these steps carefully:",
        "",
    ]

    # Step 1: Org
    if org_alias:
        lines.append(f"1. TARGET ORG: Use org alias '{org_alias}'.")
    else:
        lines.append(
            "1. TARGET ORG: No org was specified. "
            "Omit the org_alias parameter so the tool uses the sf CLI default target-org. "
            "Mention to the user which org will be used."
        )

    # Step 2: Template discovery
    if template_names.lower() == "all":
        lines.append(
            "2. TEMPLATES: The user wants ALL templates. "
            "Call fetch_orchestration_templates with fetch_all: true to fetch everything."
        )
    elif template_names:
        names_list = [n.strip() for n in template_names.split(",") if n.strip()]
        lines.append(
            f"2. TEMPLATES: The user specified these templates: {names_list}. "
            "First, call list_orchestration_templates with a search_term for each name "
            "to verify they exist. If any don't match exactly, show the user the closest "
            "matches and ask for confirmation before proceeding."
        )
    else:
        lines.append(
            "2. TEMPLATES: No specific templates were requested. "
            "Ask the user: do they want ALL templates, specific ones, or a subset? "
            "If ALL, use fetch_orchestration_templates with fetch_all: true. "
            "Otherwise, use list_orchestration_templates to discover available templates, "
            "present the results, and confirm with the user. Then call "
            "fetch_orchestration_templates with the confirmed template_names."
        )

    # Step 3: Fetch
    lines.extend([
        "",
        "3. FETCH: Once templates are confirmed, call fetch_orchestration_templates "
        "with the confirmed template_names (and org_alias if specified). "
        "Use default max_workers (5) unless the user requests otherwise.",
        "",
        "4. RESULTS: After fetching, summarize the results clearly:",
        "   - How many templates succeeded vs failed",
        "   - The output directory where files were saved",
        "   - List any failures with their error messages",
        "   - If templates failed because they don't exist, suggest using "
        "list_orchestration_templates to find the correct names",
    ])

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def _get_sf_cli_version() -> str:
    try:
        r = subprocess.run(["sf", "--version"], capture_output=True, text=True, timeout=10)
        return r.stdout.strip().split("\n")[0] if r.returncode == 0 else "unknown"
    except Exception:
        return "not installed"


async def _run_server():
    log_event(
        logger, "INFO",
        event="server_start",
        version=_CURRENT_VERSION,
        session_id=SESSION_ID,
        sf_cli=_get_sf_cli_version(),
        **get_system_info(),
    )
    async with stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="cloudsense-dx",
                server_version=_CURRENT_VERSION,
                capabilities=ServerCapabilities(
                    tools=ToolsCapability(),
                    prompts=PromptsCapability(),
                ),
                instructions=SERVER_INSTRUCTIONS,
            ),
        )


def main():
    """CLI entry point for the CloudSense DX MCP server."""
    asyncio.run(_run_server())


if __name__ == "__main__":
    main()
