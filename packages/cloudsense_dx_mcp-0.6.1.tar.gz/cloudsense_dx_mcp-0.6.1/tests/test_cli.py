"""Tests for CLI layer: error handling, org resolution."""

from unittest.mock import patch, MagicMock

import pytest

from cloudsense_dx_mcp.sfdc.cli import SfCliError, get_default_org


class TestGetDefaultOrg:
    def test_returns_none_on_failure(self):
        with patch(
            "cloudsense_dx_mcp.sfdc.cli.subprocess.run",
            side_effect=Exception("any error"),
        ):
            assert get_default_org() is None

    def test_returns_alias_on_success(self):
        mock_result = MagicMock(
            returncode=0,
            stdout='{"result": [{"value": "my-org"}]}',
        )
        with patch("cloudsense_dx_mcp.sfdc.cli.subprocess.run", return_value=mock_result):
            assert get_default_org() == "my-org"
