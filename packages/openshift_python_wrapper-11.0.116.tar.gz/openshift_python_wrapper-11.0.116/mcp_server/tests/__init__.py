# Tests for MCP server
