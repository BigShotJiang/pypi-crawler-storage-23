#!/bin/bash

# Macer HPC Installation Helper (CUDA-safe version)
export CC=gcc
export CXX=g++
export FC=gfortran

# At first,install with torch cpu
pip install -e .

# Replace pytorch with gpu cuda version (cu118, cu121, or cu124) 
pip uninstall torch torchvision torchaudio -y
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu124
