import argparse
import json
from pathlib import Path

import numpy as np


def build_sscha_free_energy_replay_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(
            prog="macer util sscha free-energy-replay",
            description="Replay free-energy trend from saved SSCHA logs and check consistency.",
        )
    parser.add_argument("--dir", required=True, help="SSCHA output directory.")
    parser.add_argument("--json-out", default=None, help="Optional JSON output.")
    parser.add_argument("--csv-out", default=None, help="Optional CSV output.")
    return parser


def run_sscha_free_energy_replay(args):
    run_dir = Path(args.dir).expanduser().resolve()
    hist = _read_free_energy_history(run_dir / "qscaild_free_energy_history.log")
    fit = _read_out_fit(run_dir)
    if not hist and not fit:
        raise ValueError(f"No free-energy history found in {run_dir}")

    if hist and fit:
        merged = _merge_histories(hist, fit)
        max_abs_diff = float(np.max(np.abs([r["delta_eV"] for r in merged])))
    else:
        merged = [{"cycle": int(c), "free_energy_history_eV": float(f), "free_energy_out_fit_eV": None, "delta_eV": None} for c, f in (hist or fit)]
        max_abs_diff = float("nan")

    state = "consistent" if np.isfinite(max_abs_diff) and max_abs_diff < 1e-5 else ("single_source" if not np.isfinite(max_abs_diff) else "mismatch")
    report = {
        "run_dir": str(run_dir),
        "n_points": int(len(merged)),
        "max_abs_delta_eV": max_abs_diff,
        "consistency_state": state,
        "table": merged,
    }

    print("SSCHA Free-Energy Replay")
    print("-" * 72)
    print(f"Points           : {len(merged)}")
    if np.isfinite(max_abs_diff):
        print(f"Max |delta| (eV) : {max_abs_diff:.6e}")
    print(f"State            : {state}")
    if merged:
        last = merged[-1]
        print(f"Last cycle       : {last['cycle']}")
        print(f"Last F (history) : {last['free_energy_history_eV']}")
        print(f"Last F (out_fit) : {last['free_energy_out_fit_eV']}")

    if args.csv_out:
        import csv
        out = Path(args.csv_out).expanduser().resolve()
        with out.open("w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["cycle", "free_energy_history_eV", "free_energy_out_fit_eV", "delta_eV"])
            w.writeheader()
            w.writerows(merged)
        print(f"Wrote CSV: {out}")

    if args.json_out:
        out = Path(args.json_out).expanduser().resolve()
        out.write_text(json.dumps(report, indent=2))
        print(f"Wrote JSON: {out}")
    return report


def _read_free_energy_history(path: Path):
    if not path.exists():
        return []
    rows = []
    with path.open("r") as f:
        for ln in f:
            s = ln.strip()
            if (not s) or s.startswith("#"):
                continue
            p = s.split()
            if len(p) < 2:
                continue
            try:
                rows.append((int(float(p[0])), float(p[1])))
            except Exception:
                continue
    return rows


def _read_out_fit(run_dir: Path):
    for name in ("out_fit.txt", "out_fit"):
        p = run_dir / name
        if not p.exists():
            continue
        rows = []
        with p.open("r") as f:
            for ln in f:
                s = ln.strip()
                if (not s) or s.startswith("#"):
                    continue
                parts = s.split()
                if len(parts) < 7:
                    continue
                try:
                    cyc = int(float(parts[0]))
                    fe = float(parts[6])
                    rows.append((cyc, fe))
                except Exception:
                    continue
        if rows:
            return rows
    return []


def _merge_histories(hist, fit):
    d_hist = {int(c): float(v) for c, v in hist}
    d_fit = {int(c): float(v) for c, v in fit}
    cycles = sorted(set(d_hist.keys()) | set(d_fit.keys()))
    out = []
    for c in cycles:
        h = d_hist.get(c)
        f = d_fit.get(c)
        delta = (h - f) if (h is not None and f is not None) else None
        out.append(
            {
                "cycle": int(c),
                "free_energy_history_eV": h,
                "free_energy_out_fit_eV": f,
                "delta_eV": delta,
            }
        )
    return out
