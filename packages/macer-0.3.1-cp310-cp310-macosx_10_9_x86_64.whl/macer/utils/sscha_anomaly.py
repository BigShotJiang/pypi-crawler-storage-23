import argparse
import json
from pathlib import Path

import numpy as np


def build_sscha_anomaly_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(
            prog="macer util sscha anomaly",
            description="Detect SSCHA snapshot anomalies (axis asymmetry, outlier atoms, PBC jump suspicion).",
        )
    parser.add_argument("--dir", required=True, help="SSCHA output directory.")
    parser.add_argument("--cycle", type=int, required=True, help="Cycle index that provides U/logp_origin.")
    parser.add_argument("--target-cycle", type=int, default=None, help="Cycle index for logp_current (default: same as --cycle).")
    parser.add_argument("-p", "--poscar", default=None, help="Reference POSCAR (default: <dir>/POSCAR_qscaild_input).")
    parser.add_argument("--dim", nargs="+", type=int, required=True, help="Supercell dim (3 or 9 integers).")
    parser.add_argument("--z-axis-ratio-threshold", type=float, default=2.5, help="Threshold for z-variance asymmetry flag.")
    parser.add_argument("--outlier-zscore-threshold", type=float, default=5.0, help="Threshold for atom RMS outlier z-score.")
    parser.add_argument("--json-out", default=None, help="Optional JSON output path.")
    return parser


def run_sscha_anomaly(args):
    run_dir = Path(args.dir).expanduser().resolve()
    cyc = int(args.cycle)
    tgt = int(args.target_cycle if args.target_cycle is not None else args.cycle)
    cdir = run_dir / f"cycle_{cyc:03d}"
    if not cdir.exists():
        raise FileNotFoundError(f"Cycle directory not found: {cdir}")

    poscar = Path(args.poscar).expanduser().resolve() if args.poscar else (run_dir / "POSCAR_qscaild_input")
    if not poscar.exists():
        raise FileNotFoundError(f"POSCAR not found: {poscar}")

    from phonopy import Phonopy
    from phonopy.interface.vasp import read_vasp

    dim = _dim_to_matrix(args.dim)
    unitcell = read_vasp(str(poscar))
    ph = Phonopy(unitcell, supercell_matrix=dim, primitive_matrix="auto", symprec=5e-3)

    U = _load_saved_array(cdir / "U")
    w = _load_weights(cdir, tgt)
    if U.shape[0] != w.shape[0]:
        raise ValueError("U/logp snapshot count mismatch")
    if U.shape[1] != len(ph.supercell):
        raise ValueError("U atom count does not match POSCAR+dim supercell")

    cell = np.asarray(ph.supercell.cell, dtype=float)
    U_raw = np.asarray(U, dtype=float)
    U_wrap = _minimum_image_displacements(U_raw, cell)
    U_avg_raw = np.sum(w[:, None, None] * U_raw, axis=0)
    U_avg_wrap = np.sum(w[:, None, None] * U_wrap, axis=0)
    du_raw = U_raw - U_avg_raw[None, :, :]
    du_wrap = U_wrap - U_avg_wrap[None, :, :]

    var_raw = _axis_var(du_raw, w)
    var_wrap = _axis_var(du_wrap, w)
    jump_ratio = np.divide(var_raw, np.clip(var_wrap, 1e-20, None))
    z_ratio = var_wrap[2] / max(1e-20, 0.5 * (var_wrap[0] + var_wrap[1]))
    z_flag = bool(z_ratio > float(args.z_axis_ratio_threshold))

    frac = np.einsum("...j,jk->...k", U_raw, np.linalg.inv(cell))
    jump_frac_axis = np.sum(w[:, None] * np.mean(np.abs(frac) > 0.5, axis=1), axis=0)

    rms_atom = np.sqrt(np.sum(w[:, None] * np.sum(du_wrap**2, axis=2), axis=0))
    mu = float(np.mean(rms_atom))
    sig = float(np.std(rms_atom))
    if sig < 1e-20:
        zscores = np.zeros_like(rms_atom)
    else:
        zscores = (rms_atom - mu) / sig
    outlier_idx = np.where(zscores > float(args.outlier_zscore_threshold))[0]

    report = {
        "run_dir": str(run_dir),
        "cycle": cyc,
        "target_cycle": tgt,
        "axis_variance_raw": {"x": float(var_raw[0]), "y": float(var_raw[1]), "z": float(var_raw[2])},
        "axis_variance_wrapped": {"x": float(var_wrap[0]), "y": float(var_wrap[1]), "z": float(var_wrap[2])},
        "pbc_jump_suspicion_ratio_raw_over_wrapped": {"x": float(jump_ratio[0]), "y": float(jump_ratio[1]), "z": float(jump_ratio[2])},
        "jump_fraction_axis_raw_fractional_gt_0p5": {"x": float(jump_frac_axis[0]), "y": float(jump_frac_axis[1]), "z": float(jump_frac_axis[2])},
        "z_axis_asymmetry_ratio": float(z_ratio),
        "z_axis_flagged": z_flag,
        "outlier_atoms": [{"atom_index_1based": int(i + 1), "rms": float(rms_atom[i]), "zscore": float(zscores[i])} for i in outlier_idx],
    }

    print("SSCHA Anomaly Report")
    print("-" * 72)
    print(f"Cycle/Target       : {cyc} -> {tgt}")
    print(f"Var(raw) x/y/z     : {var_raw[0]:.6e} {var_raw[1]:.6e} {var_raw[2]:.6e}")
    print(f"Var(wrap) x/y/z    : {var_wrap[0]:.6e} {var_wrap[1]:.6e} {var_wrap[2]:.6e}")
    print(f"Jump ratio raw/wrap: {jump_ratio[0]:.3f} {jump_ratio[1]:.3f} {jump_ratio[2]:.3f}")
    print(f"Jump frac |frac|>.5: {jump_frac_axis[0]:.4f} {jump_frac_axis[1]:.4f} {jump_frac_axis[2]:.4f}")
    print(f"z asymmetry ratio  : {z_ratio:.3f} (flag={z_flag})")
    print(f"Outlier atoms      : {len(outlier_idx)}")
    for i in outlier_idx[:20]:
        print(f"  - atom={i+1:4d} rms={rms_atom[i]:.6e} z={zscores[i]:.3f}")

    if args.json_out:
        out = Path(args.json_out).expanduser().resolve()
        out.write_text(json.dumps(report, indent=2))
        print(f"Wrote JSON: {out}")
    return report


def _dim_to_matrix(dim_list):
    if len(dim_list) == 3:
        return np.diag(dim_list)
    if len(dim_list) == 9:
        return np.asarray(dim_list, dtype=int).reshape(3, 3)
    raise ValueError("--dim must have 3 or 9 integers.")


def _load_saved_array(stem: Path):
    npy = Path(f"{stem}.npy")
    if npy.exists():
        return np.load(npy)
    dat = Path(f"{stem}.dat")
    if not dat.exists():
        raise FileNotFoundError(f"missing both {npy} and {dat}")
    with dat.open("r") as f:
        first = f.readline().strip()
    if not first.startswith("# shape "):
        raise ValueError(f"Missing shape header in {dat}")
    shape = tuple(int(x) for x in first.replace("#", "").split()[1:])
    raw = np.loadtxt(dat, comments="#")
    if len(shape) == 1:
        if np.ndim(raw) == 1:
            return np.array([float(raw[-1])], dtype=float)
        return np.asarray(raw[:, -1], dtype=float)
    return np.atleast_2d(raw).reshape(shape)


def _load_weights(cycle_dir: Path, target_cycle: int):
    cur = _load_saved_array(cycle_dir / f"logp_current_cycle_{target_cycle:03d}").reshape(-1)
    ori = _load_saved_array(cycle_dir / "logp_origin").reshape(-1)
    if cur.shape != ori.shape:
        raise ValueError("logp shape mismatch")
    logw = cur - ori
    shift = float(np.max(logw))
    w = np.exp(logw - shift)
    w /= float(np.sum(w))
    return w


def _minimum_image_displacements(U: np.ndarray, cell: np.ndarray) -> np.ndarray:
    frac = np.einsum("...j,jk->...k", U, np.linalg.inv(cell))
    frac -= np.rint(frac)
    return np.einsum("...j,jk->...k", frac, cell)


def _axis_var(du: np.ndarray, w: np.ndarray):
    # du: (nconf, natom, 3), w: (nconf,)
    return np.sum(w[:, None, None] * du**2, axis=(0, 1)) / float(du.shape[1])
