from __future__ import annotations

import argparse
import itertools
import io
import re
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np

BOHR_TO_ANG = 0.529177249
AMU_TO_ELECTRON_MASS = 1822.888486209


@dataclass
class PIMDTrajectory:
    steps: np.ndarray
    coords: np.ndarray  # [nstep, nbead, natom, 3], Angstrom
    symbols: list[str]
    cell: np.ndarray | None = None  # [3, 3], Angstrom
    source_info: str = ""

    @property
    def nstep(self) -> int:
        return int(self.coords.shape[0])

    @property
    def nbead(self) -> int:
        return int(self.coords.shape[1])

    @property
    def natom(self) -> int:
        return int(self.coords.shape[2])


def _sorted_npz_files(run_dir: Path) -> list[Path]:
    history = run_dir / "pimd_state_history.npz"
    if history.exists():
        return [history]
    files = sorted(run_dir.glob("pimd_state_step*.npz"))
    if not files and (run_dir / "restart.npz").exists():
        files = [run_dir / "restart.npz"]
    return files


def _read_npy_from_bytes(raw: bytes, allow_partial: bool = False) -> np.ndarray | None:
    bio = io.BytesIO(raw)
    try:
        major, minor = np.lib.format.read_magic(bio)
    except Exception:
        return None
    if (major, minor) == (1, 0):
        shape, fortran_order, dtype = np.lib.format.read_array_header_1_0(bio)
    elif (major, minor) in ((2, 0), (3, 0)):
        shape, fortran_order, dtype = np.lib.format.read_array_header_2_0(bio)
    else:
        return None
    if dtype.hasobject:
        return None
    payload = bio.read()
    if len(shape) == 0:
        need = int(dtype.itemsize)
        if len(payload) < need:
            return None
        return np.frombuffer(payload[:need], dtype=dtype, count=1).reshape(shape)

    total_items = int(np.prod(shape))
    itemsize = int(dtype.itemsize)
    full_needed = total_items * itemsize
    if len(payload) >= full_needed:
        arr = np.frombuffer(payload[:full_needed], dtype=dtype, count=total_items)
        return arr.reshape(shape, order="F" if fortran_order else "C")
    if not allow_partial:
        return None

    if len(shape) < 1:
        return None
    per_step = int(np.prod(shape[1:])) if len(shape) > 1 else 1
    available_items = len(payload) // itemsize
    complete_steps = available_items // per_step
    if complete_steps <= 0:
        return None
    count = complete_steps * per_step
    arr = np.frombuffer(payload[: count * itemsize], dtype=dtype, count=count)
    trimmed_shape = (complete_steps,) + tuple(shape[1:])
    return arr.reshape(trimmed_shape, order="F" if fortran_order else "C")


def _parse_zip64_sizes(extra: bytes, need_usize: bool, need_csize: bool) -> tuple[int | None, int | None]:
    pos = 0
    usize = None
    csize = None
    while pos + 4 <= len(extra):
        header_id, size = struct.unpack_from("<HH", extra, pos)
        pos += 4
        data = extra[pos : pos + size]
        pos += size
        if header_id != 0x0001:
            continue
        cursor = 0
        if need_usize and cursor + 8 <= len(data):
            usize = int(struct.unpack_from("<Q", data, cursor)[0])
            cursor += 8
        if need_csize and cursor + 8 <= len(data):
            csize = int(struct.unpack_from("<Q", data, cursor)[0])
        break
    return usize, csize


def _load_npz_with_truncation_recovery(path: Path) -> dict[str, np.ndarray]:
    raw = path.read_bytes()
    recovered: dict[str, np.ndarray] = {}
    offset = 0
    while offset + 30 <= len(raw):
        signature = struct.unpack_from("<I", raw, offset)[0]
        if signature != 0x04034B50:
            break
        (
            _sig,
            _ver,
            flags,
            compression,
            _mt,
            _md,
            _crc,
            csize32,
            usize32,
            name_len,
            extra_len,
        ) = struct.unpack_from("<IHHHHHIIIHH", raw, offset)
        offset += 30
        if offset + name_len + extra_len > len(raw):
            break
        name = raw[offset : offset + name_len].decode("utf-8", errors="replace")
        offset += name_len
        extra = raw[offset : offset + extra_len]
        offset += extra_len
        if compression != 0:
            break
        csize = int(csize32)
        usize = int(usize32)
        need_usize = usize32 == 0xFFFFFFFF
        need_csize = csize32 == 0xFFFFFFFF
        if need_usize or need_csize:
            zu, zc = _parse_zip64_sizes(extra, need_usize=need_usize, need_csize=need_csize)
            if need_usize and zu is not None:
                usize = int(zu)
            if need_csize and zc is not None:
                csize = int(zc)
        data_end_nominal = offset + csize
        data_end_actual = min(data_end_nominal, len(raw))
        data = raw[offset:data_end_actual]
        is_truncated = data_end_actual < data_end_nominal
        key = name[:-4] if name.endswith(".npy") else name
        if name.endswith(".npy"):
            arr = _read_npy_from_bytes(data, allow_partial=is_truncated)
            if arr is not None:
                recovered[key] = arr
        if is_truncated:
            break
        offset = data_end_actual
        if usize <= 0 and csize <= 0:
            break
    return recovered


def _load_from_npz(run_dir_or_file: Path) -> PIMDTrajectory:
    if run_dir_or_file.is_file():
        # If a single step snapshot is provided, expand to the sibling history
        # so `-i pimd_state_step000100.npz` can analyze full trajectory (1..100).
        m = re.match(r"^pimd_state_step(\d+)\.npz$", run_dir_or_file.name)
        if m:
            max_step = int(m.group(1))
            all_paths = _sorted_npz_files(run_dir_or_file.parent)
            paths = []
            for p in all_paths:
                mm = re.match(r"^pimd_state_step(\d+)\.npz$", p.name)
                if mm and int(mm.group(1)) <= max_step:
                    paths.append(p)
            if not paths:
                paths = [run_dir_or_file]
        else:
            paths = [run_dir_or_file]
    else:
        paths = _sorted_npz_files(run_dir_or_file)
    if not paths:
        raise FileNotFoundError(
            "No pimd_state_step*.npz found. "
            f"Check -i/--input or --dir path: {run_dir_or_file}"
        )

    step_list: list[int] = []
    coord_list: list[np.ndarray] = []
    symbols: list[str] | None = None
    cell: np.ndarray | None = None
    for path in paths:
        try:
            with np.load(path, allow_pickle=True) as data:
                payload = {k: data[k] for k in data.files}
        except Exception:
            payload = _load_npz_with_truncation_recovery(path)
            if not payload:
                continue

        used_internal_r = False
        if "r_bead" in payload:
            coords_raw = np.array(payload["r_bead"], dtype=float)
            # legacy snapshot: [nbead, natom, 3]
            # cumulative snapshot: [nstep, nbead, natom, 3]
            if coords_raw.ndim == 3:
                coords_seq = [coords_raw]
            elif coords_raw.ndim == 4:
                coords_seq = [coords_raw[i] for i in range(coords_raw.shape[0])]
            else:
                continue
        elif "r" in payload:
            # pimd state snapshot uses bead coordinates as r[3, natom, nbead] in Bohr.
            r_internal = np.array(payload["r"], dtype=float)
            if r_internal.ndim != 3 or r_internal.shape[0] != 3:
                continue
            coords_seq = [np.transpose(r_internal, (2, 1, 0)) * BOHR_TO_ANG]
            used_internal_r = True
        else:
            continue
        if "steps" in payload:
            step_values = np.array(payload["steps"], dtype=int).reshape(-1).tolist()
        else:
            if "step" in payload:
                step_val = int(np.array(payload["step"]).reshape(()))
            elif "istepsv" in payload:
                step_val = int(np.array(payload["istepsv"]).reshape(()))
            else:
                step_val = len(step_list)
            step_values = [step_val]
        if len(step_values) != len(coords_seq):
            # Fallback: align lengths by truncation to robustly handle mixed files.
            n = min(len(step_values), len(coords_seq))
            step_values = step_values[:n]
            coords_seq = coords_seq[:n]
        coord_list.extend(coords_seq)
        step_list.extend(int(s) for s in step_values)
        if symbols is None and "symbols" in payload:
            symbols = [str(x) for x in np.array(payload["symbols"]).tolist()]
        elif symbols is None and ("species" in payload) and ("species_counts" in payload):
            species = [str(x) for x in np.array(payload["species"]).tolist()]
            counts = [int(v) for v in np.array(payload["species_counts"]).reshape(-1).tolist()]
            if len(species) == len(counts):
                expanded: list[str] = []
                for sym, cnt in zip(species, counts):
                    expanded.extend([sym] * int(cnt))
                if expanded:
                    symbols = expanded
        if cell is None and "cell" in payload:
            cell_raw = np.array(payload["cell"], dtype=float)
            if cell_raw.ndim == 3:
                cell_raw = cell_raw[0]
            cell = cell_raw * BOHR_TO_ANG if used_internal_r else cell_raw

    if cell is None:
        restart_probe = (
            run_dir_or_file.parent / "restart.npz"
            if run_dir_or_file.is_file()
            else run_dir_or_file / "restart.npz"
        )
        if restart_probe.exists():
            try:
                with np.load(restart_probe, allow_pickle=True) as restart_data:
                    if "cell" in restart_data:
                        cell_raw = np.array(restart_data["cell"], dtype=float)
                        if cell_raw.ndim == 3:
                            cell_raw = cell_raw[0]
                        cell = cell_raw * BOHR_TO_ANG
            except Exception:
                pass

    if (not coord_list) and (not run_dir_or_file.is_file()):
        restart_path = run_dir_or_file / "restart.npz"
        if restart_path.exists():
            return _load_from_npz(restart_path)

    if not coord_list:
        raise ValueError(f"NPZ files found but no 'r_bead'/'r' coordinate arrays in: {run_dir_or_file}")
    if symbols is None:
        natom = int(coord_list[0].shape[1])
        symbols = ["X"] * natom

    steps_arr = np.array(step_list, dtype=int)
    coords_arr = np.stack(coord_list, axis=0)

    finite_mask = np.isfinite(coords_arr).all(axis=(1, 2, 3))
    norm = np.linalg.norm(coords_arr, axis=-1)
    zero_mask_all = norm.max(axis=(1, 2)) < 1.0e-12
    zero_frac = (norm < 1.0e-12).mean(axis=(1, 2))
    # Corruption signature: unusually many exact-zero coordinates in one frame
    # (e.g., partially written NPZ blocks). Keep conservative threshold.
    zero_mask_heavy = zero_frac > 0.10
    bad_mask = ~(finite_mask) | zero_mask_all | zero_mask_heavy
    if np.any(bad_mask):
        n_bad = int(np.sum(bad_mask))
        print(f"[pimd] Warning: dropped {n_bad} corrupted NPZ frame(s) (non-finite/excessive-zero coordinates).")
        keep = ~bad_mask
        steps_arr = steps_arr[keep]
        coords_arr = coords_arr[keep]
    if coords_arr.shape[0] == 0:
        raise ValueError(f"NPZ trajectory contains no valid coordinate frames after filtering: {run_dir_or_file}")

    source_info = ", ".join(str(p) for p in paths)
    return PIMDTrajectory(
        steps=steps_arr,
        coords=coords_arr,
        symbols=symbols,
        cell=cell,
        source_info=source_info,
    )


def _load_from_coor_xyz(run_dir_or_file: Path, nbead: int | None = None, natom: int | None = None) -> PIMDTrajectory:
    xyz_path = run_dir_or_file if run_dir_or_file.is_file() else (run_dir_or_file / "coor.xyz")
    if not xyz_path.exists():
        raise FileNotFoundError(
            "No coor.xyz found. "
            f"Check -i/--input or --dir path: {run_dir_or_file}"
        )

    lines = xyz_path.read_text().splitlines()
    cursor = 0
    step_list: list[int] = []
    coord_list: list[np.ndarray] = []
    symbols: list[str] | None = None
    while cursor < len(lines):
        if not lines[cursor].strip():
            cursor += 1
            continue
        nline = int(lines[cursor].strip())
        frame_step = int(lines[cursor + 1].strip())
        body = lines[cursor + 2 : cursor + 2 + nline]
        cursor = cursor + 2 + nline
        frame_symbols: list[str] = []
        frame_coords: list[list[float]] = []
        for row in body:
            token = row.split()
            if len(token) < 4:
                continue
            frame_symbols.append(token[0])
            frame_coords.append([float(token[1]), float(token[2]), float(token[3])])
        if not frame_coords:
            continue
        array = np.array(frame_coords, dtype=float)
        if nbead is None and natom is not None:
            nbead = int(array.shape[0] // natom)
        if natom is None and nbead is not None:
            natom = int(array.shape[0] // nbead)
        if nbead is None or natom is None:
            raise ValueError("Cannot infer nbead/natom from coor.xyz; pass --nbead or provide NPZ snapshots.")
        coord_list.append(array.reshape((nbead, natom, 3)))
        step_list.append(frame_step)
        if symbols is None:
            symbols = frame_symbols[:natom]

    if not coord_list:
        raise ValueError(f"No coordinate frames parsed from: {xyz_path}")
    if symbols is None:
        symbols = ["X"] * int(coord_list[0].shape[1])

    return PIMDTrajectory(
        steps=np.array(step_list, dtype=int),
        coords=np.stack(coord_list, axis=0),
        symbols=symbols,
        cell=None,
        source_info=str(xyz_path),
    )


def load_pimd_trajectory(path: str, source: str = "auto", nbead: int | None = None, natom: int | None = None) -> PIMDTrajectory:
    root = Path(path).expanduser().resolve()
    if source in ("auto", "npz"):
        try:
            return _load_from_npz(root)
        except Exception:
            if source == "npz":
                raise
    return _load_from_coor_xyz(root, nbead=nbead, natom=natom)


def _bond(coords: np.ndarray, atom1: int, atom2: int) -> np.ndarray:
    return np.linalg.norm(coords[..., atom1, :] - coords[..., atom2, :], axis=-1)


def _bond_pbc(coords: np.ndarray, cell: np.ndarray, atom1: int, atom2: int) -> np.ndarray:
    if cell is None:
        raise ValueError("PBC analysis requires cell; NPZ snapshots with `cell` are recommended.")
    inv_cell = np.linalg.inv(cell)
    diff = coords[..., atom1, :] - coords[..., atom2, :]
    frac = diff @ inv_cell
    frac = frac - np.round(frac)
    cart = frac @ cell
    return np.linalg.norm(cart, axis=-1)


def _angle(coords: np.ndarray, atom1: int, atom2: int, atom3: int) -> np.ndarray:
    vec1 = coords[..., atom1, :] - coords[..., atom2, :]
    vec2 = coords[..., atom3, :] - coords[..., atom2, :]
    dot = np.sum(vec1 * vec2, axis=-1)
    norm = np.linalg.norm(vec1, axis=-1) * np.linalg.norm(vec2, axis=-1)
    cos_theta = np.clip(dot / np.maximum(norm, 1e-14), -1.0, 1.0)
    return np.degrees(np.arccos(cos_theta))


def _dihedral(coords: np.ndarray, atom1: int, atom2: int, atom3: int, atom4: int) -> np.ndarray:
    pos1 = coords[..., atom1, :]
    pos2 = coords[..., atom2, :]
    pos3 = coords[..., atom3, :]
    pos4 = coords[..., atom4, :]
    bond1 = pos2 - pos1
    bond2 = pos3 - pos2
    bond3 = pos4 - pos3
    normal1 = np.cross(bond1, bond2)
    normal2 = np.cross(bond2, bond3)
    normal1 /= np.maximum(np.linalg.norm(normal1, axis=-1, keepdims=True), 1e-14)
    normal2 /= np.maximum(np.linalg.norm(normal2, axis=-1, keepdims=True), 1e-14)
    bond2n = bond2 / np.maximum(np.linalg.norm(bond2, axis=-1, keepdims=True), 1e-14)
    aux = np.cross(normal1, bond2n)
    xval = np.sum(normal1 * normal2, axis=-1)
    yval = np.sum(aux * normal2, axis=-1)
    return np.degrees(np.arctan2(yval, xval))


def _step_mean(values: np.ndarray) -> np.ndarray:
    return np.mean(values, axis=1)


def _write_step_and_bead(out_prefix: Path, steps: np.ndarray, values: np.ndarray, label: str) -> None:
    step_path = out_prefix.with_name(out_prefix.name + "_step.dat")
    bead_path = out_prefix.with_name(out_prefix.name + "_beads.dat")
    with step_path.open("w") as fp:
        fp.write(f"# step {label}_mean\n")
        for step_val, value in zip(steps, _step_mean(values)):
            fp.write(f"{int(step_val):10d} {float(value): .12e}\n")
    with bead_path.open("w") as fp:
        fp.write(f"# step ibead {label}\n")
        for idx_step, step_val in enumerate(steps):
            for ibead, value in enumerate(values[idx_step], start=1):
                fp.write(f"{int(step_val):10d} {ibead:4d} {float(value): .12e}\n")


def _write_hist_pdf(
    values: np.ndarray,
    out_pdf: Path,
    title: str,
    x_label: str,
    nhist: int = 200,
    hist_min: float | None = None,
    hist_max: float | None = None,
) -> None:
    # values shape: [nstep, nbead] -> flatten all bead samples over all steps
    flat = np.asarray(values, dtype=float).reshape(-1)
    if flat.size == 0:
        return
    try:
        import matplotlib.pyplot as plt
    except Exception:
        print(f"[pimd] Warning: matplotlib unavailable; skip histogram PDF: {out_pdf}")
        return

    hist_range = None
    if hist_min is not None or hist_max is not None:
        if hist_min is None or hist_max is None:
            raise ValueError("Both --hist-min and --hist-max must be provided together.")
        if float(hist_min) >= float(hist_max):
            raise ValueError("--hist-min must be smaller than --hist-max.")
        hist_range = (float(hist_min), float(hist_max))

    bins = max(int(nhist), 10)
    counts, edges = np.histogram(flat, bins=bins, range=hist_range)
    total = float(np.sum(counts))
    probs = (counts.astype(float) / total) if total > 0.0 else np.zeros_like(counts, dtype=float)
    centers = 0.5 * (edges[:-1] + edges[1:])
    widths = np.diff(edges)

    fig, ax = plt.subplots(figsize=(7.0, 4.5))
    ax.bar(
        centers,
        probs,
        width=widths,
        align="center",
        color="#1f77b4",
        edgecolor="black",
        alpha=0.85,
    )
    ax.set_xlabel(x_label)
    ax.set_ylabel("Normalized probability")
    ax.set_title(title)
    ax.grid(alpha=0.25, linestyle="--", linewidth=0.5)
    fig.tight_layout()
    out_pdf.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_pdf)
    plt.close(fig)


def _write_hist_dat(
    values: np.ndarray,
    out_dat: Path,
    nhist: int = 200,
    descriptor: str | None = None,
    x_col_name: str = "bin_center",
    hist_min: float | None = None,
    hist_max: float | None = None,
) -> None:
    # values shape: [nstep, nbead] -> flatten all bead samples over all steps
    flat = np.asarray(values, dtype=float).reshape(-1)
    if flat.size == 0:
        return
    bins = max(int(nhist), 10)
    hist_range = None
    if hist_min is not None or hist_max is not None:
        if hist_min is None or hist_max is None:
            raise ValueError("Both --hist-min and --hist-max must be provided together.")
        if float(hist_min) >= float(hist_max):
            raise ValueError("--hist-min must be smaller than --hist-max.")
        hist_range = (float(hist_min), float(hist_max))
    counts, edges = np.histogram(flat, bins=bins, range=hist_range)
    centers = 0.5 * (edges[:-1] + edges[1:])
    out_dat.parent.mkdir(parents=True, exist_ok=True)
    with out_dat.open("w") as fp:
        if descriptor:
            fp.write(f"# {descriptor}\n")
        fp.write(
            f"# bins={bins} min={float(edges[0]):.12e} max={float(edges[-1]):.12e}\n"
        )
        total = float(np.sum(counts))
        probs = (counts.astype(float) / total) if total > 0.0 else np.zeros_like(counts, dtype=float)
        fp.write(f"# {x_col_name} count normalized\n")
        for center, count, prob in zip(centers, counts, probs):
            fp.write(f"{float(center):.8f} {int(count):d} {float(prob):.12e}\n")


def _resolve_hist_range(args) -> tuple[float | None, float | None]:
    hist_min = getattr(args, "hist_min", None)
    hist_max = getattr(args, "hist_max", None)
    if hist_min is None and hist_max is None:
        return None, None
    if hist_min is None or hist_max is None:
        raise ValueError("Both --hist-min and --hist-max must be provided together.")
    hist_min_f = float(hist_min)
    hist_max_f = float(hist_max)
    if hist_min_f >= hist_max_f:
        raise ValueError("--hist-min must be smaller than --hist-max.")
    return hist_min_f, hist_max_f


def _parse_pairs(raw_pairs: Iterable[str]) -> list[tuple[int, int]]:
    pairs: list[tuple[int, int]] = []
    for text in raw_pairs:
        if "-" in text:
            left, right = text.split("-", 1)
        elif ":" in text:
            left, right = text.split(":", 1)
        else:
            token = text.split()
            if len(token) != 2:
                raise ValueError(f"Invalid pair: {text}")
            left, right = token
        pairs.append((int(left) - 1, int(right) - 1))
    return pairs


def _resolve_output_dir(args) -> Path:
    output_dir = getattr(args, "output_dir", None)
    if output_dir:
        out_dir = Path(output_dir).expanduser().resolve()
    else:
        input_path = getattr(args, "input", None)
        if input_path:
            base = Path(input_path).expanduser().resolve()
            out_dir = (base.parent if base.is_file() else base)
        else:
            out_dir = Path(getattr(args, "dir", ".")).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir


def _idx(v: int | None, name: str) -> int:
    if v is None:
        raise ValueError(f"missing required argument: --{name}")
    return int(v) - 1


def _load_traj(args) -> PIMDTrajectory:
    target = getattr(args, "input", None) or getattr(args, "dir", ".")
    return load_pimd_trajectory(target, source=args.source, nbead=args.nbead, natom=args.natom)


def run_pimd2_summary(args) -> None:
    traj = _load_traj(args)
    print(f"PIMDanalysis2-summary: dir={Path(args.dir).resolve()}")
    print(f"  nstep={traj.nstep}, nbead={traj.nbead}, natom={traj.natom}")
    print(f"  step-range={int(traj.steps.min())}..{int(traj.steps.max())}")
    print(f"  cell={'available' if traj.cell is not None else 'missing'}")


def run_pimd2_bond(args) -> None:
    traj = _load_traj(args)
    out_dir = _resolve_output_dir(args)
    hist_min, hist_max = _resolve_hist_range(args)
    if traj.source_info:
        print(f"[pimd] bond: input={traj.source_info}")
    print(f"[pimd] bond: nstep={traj.nstep}, nbead={traj.nbead}, natom={traj.natom}")
    use_pbc = (traj.cell is not None) and (not bool(getattr(args, "no_pbc", False)))
    if use_pbc:
        print("[pimd] bond: using minimum-image PBC distance (cell detected in input).")
    elif traj.cell is None:
        print("[pimd] bond: cell not available; using direct Cartesian distance.")
    else:
        print("[pimd] bond: using direct Cartesian distance (--no-pbc).")

    atom_pairs: list[tuple[int, int]]
    if getattr(args, "atoms", None):
        # 1-based input indices -> 0-based internal, then all unique combinations
        atoms_1based = [int(x) for x in args.atoms]
        atoms_0based = [a - 1 for a in atoms_1based]
        if len(atoms_0based) < 2:
            raise ValueError("--atoms requires at least two atom indices.")
        for idx in atoms_0based:
            if idx < 0 or idx >= traj.natom:
                raise ValueError(f"--atoms contains out-of-range index: {idx+1} (natom={traj.natom})")
        atom_pairs = list(itertools.combinations(atoms_0based, 2))
    else:
        atom1 = _idx(args.atom1, "atom1")
        atom2 = _idx(args.atom2, "atom2")
        if atom1 < 0 or atom1 >= traj.natom or atom2 < 0 or atom2 >= traj.natom:
            raise ValueError(f"atom index out of range (natom={traj.natom})")
        atom_pairs = [(atom1, atom2)]

    written: list[str] = []
    single_pair_mode = len(atom_pairs) == 1
    for atom1, atom2 in atom_pairs:
        pair_tag = f"atom{atom1+1}-atom{atom2+1}"
        out_prefix = out_dir / f"pimd_bond_{pair_tag}"
        values = _bond_pbc(traj.coords, traj.cell, atom1, atom2) if use_pbc else _bond(traj.coords, atom1, atom2)
        _write_step_and_bead(out_prefix, traj.steps, values, "bond")
        written.append(f"{out_prefix}_step.dat")
        written.append(f"{out_prefix}_beads.dat")

        hist_pdf = out_dir / f"pimd_bond_{pair_tag}_hist.pdf"
        hist_dat = out_dir / f"pimd_bond_{pair_tag}_hist.dat"
        _write_hist_pdf(
            values=values,
            out_pdf=hist_pdf,
            title=f"Bond {pair_tag} distribution",
            x_label="Bond length (Angstrom)",
            nhist=int(getattr(args, "nhist", 200)),
            hist_min=hist_min,
            hist_max=hist_max,
        )
        _write_hist_dat(
            values=values,
            out_dat=hist_dat,
            nhist=int(getattr(args, "nhist", 200)),
            descriptor=f"bond_length(atom{atom1+1}-atom{atom2+1})",
            x_col_name="bin_center_A",
            hist_min=hist_min,
            hist_max=hist_max,
        )
        written.append(str(hist_pdf))
        written.append(str(hist_dat))
        if single_pair_mode:
            # Backward-compatible outputs for existing scripts.
            legacy_prefix = out_dir / "pimd_bond"
            _write_step_and_bead(legacy_prefix, traj.steps, values, "bond")
            written.append(f"{legacy_prefix}_step.dat")
            written.append(f"{legacy_prefix}_beads.dat")

    print("[pimd] Wrote:")
    for path in written:
        print(f"  - {path}")


def run_pimd2_angle(args) -> None:
    traj = _load_traj(args)
    out_dir = _resolve_output_dir(args)
    hist_min, hist_max = _resolve_hist_range(args)
    if traj.source_info:
        print(f"[pimd] angle: input={traj.source_info}")
    print(f"[pimd] angle: nstep={traj.nstep}, nbead={traj.nbead}, natom={traj.natom}")
    atom_triplets: list[tuple[int, int, int]]
    if getattr(args, "atoms", None):
        atoms_1based = [int(x) for x in args.atoms]
        atoms_0based = [a - 1 for a in atoms_1based]
        if len(atoms_0based) < 3:
            raise ValueError("--atoms requires at least three atom indices for angle analysis.")
        for idx in atoms_0based:
            if idx < 0 or idx >= traj.natom:
                raise ValueError(f"--atoms contains out-of-range index: {idx+1} (natom={traj.natom})")
        atom_triplets = list(itertools.combinations(atoms_0based, 3))
    else:
        atom1 = _idx(args.atom1, "atom1")
        atom2 = _idx(args.atom2, "atom2")
        atom3 = _idx(args.atom3, "atom3")
        if (
            atom1 < 0
            or atom1 >= traj.natom
            or atom2 < 0
            or atom2 >= traj.natom
            or atom3 < 0
            or atom3 >= traj.natom
        ):
            raise ValueError(f"atom index out of range (natom={traj.natom})")
        atom_triplets = [(atom1, atom2, atom3)]

    written: list[str] = []
    single_triplet_mode = len(atom_triplets) == 1
    for atom1, atom2, atom3 in atom_triplets:
        triplet_tag = f"atom{atom1+1}-atom{atom2+1}-atom{atom3+1}"
        out_prefix = out_dir / f"pimd_angle_{triplet_tag}"
        values = _angle(traj.coords, atom1, atom2, atom3)
        _write_step_and_bead(out_prefix, traj.steps, values, "angle_deg")
        written.append(f"{out_prefix}_step.dat")
        written.append(f"{out_prefix}_beads.dat")
        hist_pdf = out_prefix.with_name(out_prefix.name + "_hist.pdf")
        hist_dat = out_prefix.with_name(out_prefix.name + "_hist.dat")
        _write_hist_pdf(
            values=values,
            out_pdf=hist_pdf,
            title=f"Angle atom{atom1+1}-atom{atom2+1}-atom{atom3+1} distribution",
            x_label="Angle (degree)",
            nhist=int(getattr(args, "nhist", 200)),
            hist_min=hist_min,
            hist_max=hist_max,
        )
        _write_hist_dat(
            values=values,
            out_dat=hist_dat,
            nhist=int(getattr(args, "nhist", 200)),
            descriptor=f"angle(atom{atom1+1}-atom{atom2+1}-atom{atom3+1})",
            x_col_name="bin_center_deg",
            hist_min=hist_min,
            hist_max=hist_max,
        )
        written.append(str(hist_pdf))
        written.append(str(hist_dat))
        if single_triplet_mode:
            legacy_prefix = out_dir / "pimd_angle"
            _write_step_and_bead(legacy_prefix, traj.steps, values, "angle_deg")
            written.append(f"{legacy_prefix}_step.dat")
            written.append(f"{legacy_prefix}_beads.dat")

    print("[pimd] Wrote:")
    for path in written:
        print(f"  - {path}")


def run_pimd2_dihedral(args) -> None:
    traj = _load_traj(args)
    out_prefix = _resolve_output_dir(args) / "pimd_dihedral"
    hist_min, hist_max = _resolve_hist_range(args)
    atom1 = _idx(args.atom1, "atom1")
    atom2 = _idx(args.atom2, "atom2")
    atom3 = _idx(args.atom3, "atom3")
    atom4 = _idx(args.atom4, "atom4")
    values = _dihedral(
        traj.coords,
        atom1,
        atom2,
        atom3,
        atom4,
    )
    _write_step_and_bead(out_prefix, traj.steps, values, "dihedral_deg")
    hist_pdf = out_prefix.with_name(out_prefix.name + "_hist.pdf")
    hist_dat = out_prefix.with_name(out_prefix.name + "_hist.dat")
    _write_hist_pdf(
        values=values,
        out_pdf=hist_pdf,
        title=f"Dihedral atom{atom1+1}-atom{atom2+1}-atom{atom3+1}-atom{atom4+1} distribution",
        x_label="Dihedral (degree)",
        nhist=int(getattr(args, "nhist", 200)),
        hist_min=hist_min,
        hist_max=hist_max,
    )
    _write_hist_dat(
        values=values,
        out_dat=hist_dat,
        nhist=int(getattr(args, "nhist", 200)),
        descriptor=f"dihedral(atom{atom1+1}-atom{atom2+1}-atom{atom3+1}-atom{atom4+1})",
        x_col_name="bin_center_deg",
        hist_min=hist_min,
        hist_max=hist_max,
    )
    print(f"[pimd] Wrote: {out_prefix}_step.dat, {out_prefix}_beads.dat, {hist_pdf}, {hist_dat}")


def run_pimd2_bond_diff(args) -> None:
    traj = _load_traj(args)
    out_prefix = _resolve_output_dir(args) / "pimd_bond_diff"
    hist_min, hist_max = _resolve_hist_range(args)
    atom1 = _idx(args.atom1, "atom1")
    atom2 = _idx(args.atom2, "atom2")
    atom3 = _idx(args.atom3, "atom3")
    atom4 = _idx(args.atom4, "atom4")
    values = _bond(traj.coords, atom1, atom2) - _bond(traj.coords, atom3, atom4)
    _write_step_and_bead(out_prefix, traj.steps, values, "bond_diff")
    hist_pdf = out_prefix.with_name(out_prefix.name + "_hist.pdf")
    hist_dat = out_prefix.with_name(out_prefix.name + "_hist.dat")
    _write_hist_pdf(
        values=values,
        out_pdf=hist_pdf,
        title=f"Bond diff (atom{atom1+1}-atom{atom2+1})-(atom{atom3+1}-atom{atom4+1})",
        x_label="Bond difference (Angstrom)",
        nhist=int(getattr(args, "nhist", 200)),
        hist_min=hist_min,
        hist_max=hist_max,
    )
    _write_hist_dat(
        values=values,
        out_dat=hist_dat,
        nhist=int(getattr(args, "nhist", 200)),
        descriptor=f"bond_diff((atom{atom1+1}-atom{atom2+1})-(atom{atom3+1}-atom{atom4+1}))",
        x_col_name="bin_center_A",
        hist_min=hist_min,
        hist_max=hist_max,
    )
    print(f"[pimd] Wrote: {out_prefix}_step.dat, {out_prefix}_beads.dat, {hist_pdf}, {hist_dat}")


def run_pimd2_bond_add(args) -> None:
    traj = _load_traj(args)
    out_prefix = _resolve_output_dir(args) / "pimd_bond_add"
    hist_min, hist_max = _resolve_hist_range(args)
    atom1 = _idx(args.atom1, "atom1")
    atom2 = _idx(args.atom2, "atom2")
    atom3 = _idx(args.atom3, "atom3")
    atom4 = _idx(args.atom4, "atom4")
    values = _bond(traj.coords, atom1, atom2) + _bond(traj.coords, atom3, atom4)
    _write_step_and_bead(out_prefix, traj.steps, values, "bond_add")
    hist_pdf = out_prefix.with_name(out_prefix.name + "_hist.pdf")
    hist_dat = out_prefix.with_name(out_prefix.name + "_hist.dat")
    _write_hist_pdf(
        values=values,
        out_pdf=hist_pdf,
        title=f"Bond add (atom{atom1+1}-atom{atom2+1})+(atom{atom3+1}-atom{atom4+1})",
        x_label="Bond sum (Angstrom)",
        nhist=int(getattr(args, "nhist", 200)),
        hist_min=hist_min,
        hist_max=hist_max,
    )
    _write_hist_dat(
        values=values,
        out_dat=hist_dat,
        nhist=int(getattr(args, "nhist", 200)),
        descriptor=f"bond_add((atom{atom1+1}-atom{atom2+1})+(atom{atom3+1}-atom{atom4+1}))",
        x_col_name="bin_center_A",
        hist_min=hist_min,
        hist_max=hist_max,
    )
    print(f"[pimd] Wrote: {out_prefix}_step.dat, {out_prefix}_beads.dat, {hist_pdf}, {hist_dat}")


def run_pimd2_multi_bond(args) -> None:
    traj = _load_traj(args)
    out_dir = _resolve_output_dir(args)
    pairs = _parse_pairs(args.pairs or [])
    if not pairs:
        raise ValueError("`--pairs` is required, e.g. `--pairs 1-2 1-3 1-4`")
    hist_min, hist_max = _resolve_hist_range(args)
    if traj.source_info:
        print(f"[pimd] multi-bond: input={traj.source_info}")
    print(f"[pimd] multi-bond: nstep={traj.nstep}, nbead={traj.nbead}, natom={traj.natom}")
    use_pbc = (traj.cell is not None) and (not bool(getattr(args, "no_pbc", False)))
    if use_pbc:
        print("[pimd] multi-bond: using minimum-image PBC distance (cell detected in input).")
    elif traj.cell is None:
        print("[pimd] multi-bond: cell not available; using direct Cartesian distance.")
    else:
        print("[pimd] multi-bond: using direct Cartesian distance (--no-pbc).")
    pair_values_list = [
        _bond_pbc(traj.coords, traj.cell, pair_a, pair_b) if use_pbc else _bond(traj.coords, pair_a, pair_b)
        for pair_a, pair_b in pairs
    ]
    all_values = np.stack(pair_values_list, axis=-1)
    mode = str(getattr(args, "mode", "all")).lower()
    if mode == "all":
        out_prefix = out_dir / "pimd_multi_bond_all"
        reduced = np.mean(all_values, axis=-1)
        _write_step_and_bead(out_prefix, traj.steps, reduced, "multi_bond_mean")
        hist_pdf = out_prefix.with_name(out_prefix.name + "_hist.pdf")
        hist_dat = out_prefix.with_name(out_prefix.name + "_hist.dat")
        _write_hist_pdf(
            values=reduced,
            out_pdf=hist_pdf,
            title="Multi-bond (all mode: mean over pairs)",
            x_label="Mean bond length (Angstrom)",
            nhist=int(getattr(args, "nhist", 200)),
            hist_min=hist_min,
            hist_max=hist_max,
        )
        _write_hist_dat(
            values=reduced,
            out_dat=hist_dat,
            nhist=int(getattr(args, "nhist", 200)),
            descriptor="multi_bond_all(mean over listed pairs)",
            x_col_name="bin_center_A",
            hist_min=hist_min,
            hist_max=hist_max,
        )
        print(f"[pimd] Wrote: {out_prefix}_step.dat, {out_prefix}_beads.dat, {hist_pdf}, {hist_dat}")
        return
    if mode == "sum":
        out_prefix = out_dir / "pimd_multi_bond_sum"
        reduced = np.sum(all_values, axis=-1)
        _write_step_and_bead(out_prefix, traj.steps, reduced, "multi_bond_sum")
        hist_pdf = out_prefix.with_name(out_prefix.name + "_hist.pdf")
        hist_dat = out_prefix.with_name(out_prefix.name + "_hist.dat")
        _write_hist_pdf(
            values=reduced,
            out_pdf=hist_pdf,
            title="Multi-bond (sum mode: sum over pairs)",
            x_label="Summed bond length (Angstrom)",
            nhist=int(getattr(args, "nhist", 200)),
            hist_min=hist_min,
            hist_max=hist_max,
        )
        _write_hist_dat(
            values=reduced,
            out_dat=hist_dat,
            nhist=int(getattr(args, "nhist", 200)),
            descriptor="multi_bond_sum(sum over listed pairs)",
            x_col_name="bin_center_A",
            hist_min=hist_min,
            hist_max=hist_max,
        )
        print(f"[pimd] Wrote: {out_prefix}_step.dat, {out_prefix}_beads.dat, {hist_pdf}, {hist_dat}")
        return
    if mode == "sort":
        out_path = out_dir / "pimd_multi_bond_sort.dat"
        sorted_values = np.sort(all_values, axis=-1)
        with out_path.open("w") as fp:
            fp.write("# step ibead idx value\n")
            for idx_step, step_val in enumerate(traj.steps):
                for ibead in range(traj.nbead):
                    for index_pair in range(sorted_values.shape[-1]):
                        fp.write(
                            f"{int(step_val):10d} {ibead+1:4d} {index_pair+1:4d} "
                            f"{float(sorted_values[idx_step, ibead, index_pair]): .12e}\n"
                        )
        wrote = [str(out_path)]
        for (pair_a, pair_b), pair_values in zip(pairs, pair_values_list):
            pair_prefix = out_dir / f"pimd_bond_atom{pair_a+1}-atom{pair_b+1}"
            _write_step_and_bead(pair_prefix, traj.steps, pair_values, f"bond_atom{pair_a+1}-atom{pair_b+1}")
            pair_hist_pdf = pair_prefix.with_name(pair_prefix.name + "_hist.pdf")
            pair_hist_dat = pair_prefix.with_name(pair_prefix.name + "_hist.dat")
            _write_hist_pdf(
                values=pair_values,
                out_pdf=pair_hist_pdf,
                title=f"Bond atom{pair_a+1}-atom{pair_b+1}",
                x_label="Bond length (Angstrom)",
                nhist=int(getattr(args, "nhist", 200)),
                hist_min=hist_min,
                hist_max=hist_max,
            )
            _write_hist_dat(
                values=pair_values,
                out_dat=pair_hist_dat,
                nhist=int(getattr(args, "nhist", 200)),
                descriptor=f"bond(atom{pair_a+1}-atom{pair_b+1})",
                x_col_name="bin_center_A",
                hist_min=hist_min,
                hist_max=hist_max,
            )
            wrote.extend(
                [
                    str(pair_prefix.with_name(pair_prefix.name + "_step.dat")),
                    str(pair_prefix.with_name(pair_prefix.name + "_beads.dat")),
                    str(pair_hist_pdf),
                    str(pair_hist_dat),
                ]
            )
        print("[pimd] Wrote:")
        for path in wrote:
            print(f"  - {path}")
        return
    raise ValueError(f"unknown --mode: {mode} (allowed: all, sort, sum)")


def run_pimd2_hist2d_bond(args) -> None:
    traj = _load_traj(args)
    out_path = _resolve_output_dir(args) / "pimd_hist2d_bond.dat"
    val_x = _bond(traj.coords, _idx(args.atom1, "atom1"), _idx(args.atom2, "atom2")).reshape(-1)
    val_y = _bond(traj.coords, _idx(args.atom3, "atom3"), _idx(args.atom4, "atom4")).reshape(-1)
    hist2d, xedges, yedges = np.histogram2d(val_x, val_y, bins=int(args.nhist or 200))
    normalize = bool(getattr(args, "normalize", False))
    if normalize:
        total = float(np.sum(hist2d))
        if total > 0.0:
            hist2d = hist2d / total
    with out_path.open("w") as fp:
        fp.write(f"# normalized={str(normalize)}\n")
        fp.write("# ix iy x_center y_center density\n")
        for i in range(hist2d.shape[0]):
            xcenter = 0.5 * (xedges[i] + xedges[i + 1])
            for j in range(hist2d.shape[1]):
                ycenter = 0.5 * (yedges[j] + yedges[j + 1])
                fp.write(f"{i+1:5d} {j+1:5d} {xcenter: .12e} {ycenter: .12e} {hist2d[i, j]: .12e}\n")
    print(f"[pimd] Wrote: {out_path}")


def run_pimd2_beads(args) -> None:
    traj = _load_traj(args)
    out_path = _resolve_output_dir(args) / "pimd_beads_expansion.xyz"
    atom1 = getattr(args, "atom1", None)
    atom2 = getattr(args, "atom2", None)
    if atom1 is not None and atom2 is not None:
        selected = np.arange(int(atom1) - 1, int(atom2), dtype=int)
    else:
        selected = np.arange(traj.natom, dtype=int)
    symbols = np.array(traj.symbols, dtype=object)
    with out_path.open("w") as fp:
        for index_step, step_val in enumerate(traj.steps):
            count = int(len(selected) * traj.nbead)
            fp.write(f"{count}\n")
            fp.write(f"step={int(step_val)}\n")
            for bead_index in range(traj.nbead):
                for atom_index in selected:
                    xcoord, ycoord, zcoord = traj.coords[index_step, bead_index, atom_index]
                    fp.write(f"{symbols[atom_index]} {xcoord: .12f} {ycoord: .12f} {zcoord: .12f}\n")
    print(f"[pimd] Wrote: {out_path}")


def _symbol_counts(symbols: list[str]) -> tuple[list[str], list[int]]:
    uniq: list[str] = []
    counts: list[int] = []
    for sym in symbols:
        if sym not in uniq:
            uniq.append(sym)
            counts.append(1)
        else:
            counts[uniq.index(sym)] += 1
    return uniq, counts


def _tokens_are_ints(tokens: list[str]) -> bool:
    if not tokens:
        return False
    try:
        for token in tokens:
            int(token)
        return True
    except Exception:
        return False


def _load_symbols_from_poscar(poscar_path: Path, natom: int) -> list[str] | None:
    if not poscar_path.exists():
        return None
    lines = [ln.strip() for ln in poscar_path.read_text().splitlines() if ln.strip()]
    if len(lines) < 8:
        return None
    # VASP5: line6 symbols, line7 counts
    line6 = lines[5].split()
    line7 = lines[6].split() if len(lines) > 6 else []
    if line6 and line7 and (not _tokens_are_ints(line6)) and _tokens_are_ints(line7):
        counts = [int(v) for v in line7]
        syms = line6
        if len(syms) != len(counts):
            return None
        expanded: list[str] = []
        for sym, cnt in zip(syms, counts):
            expanded.extend([str(sym)] * int(cnt))
        return expanded if len(expanded) == int(natom) else None
    return None


def _infer_symbols_from_physmass(restart_path: Path, natom: int) -> list[str] | None:
    if not restart_path.exists():
        return None
    try:
        from ase.data import atomic_masses, chemical_symbols
    except Exception:
        return None
    try:
        with np.load(restart_path, allow_pickle=True) as restart:
            if "physmass" not in restart:
                return None
            physmass = np.array(restart["physmass"], dtype=float).reshape(-1)
    except Exception:
        return None
    if physmass.size < int(natom):
        return None
    physmass = physmass[: int(natom)]
    masses_amu = physmass / AMU_TO_ELECTRON_MASS
    ref_masses = np.asarray(atomic_masses, dtype=float)
    symbols: list[str] = []
    for mass in masses_amu:
        diffs = np.abs(ref_masses - float(mass))
        diffs[0] = np.inf
        z = int(np.nanargmin(diffs))
        symbols.append(str(chemical_symbols[z]))
    return symbols if len(symbols) == int(natom) else None


def _write_poscar_cart(path: Path, symbols: list[str], cell: np.ndarray, positions_cart: np.ndarray, comment: str) -> None:
    uniq, counts = _symbol_counts(symbols)
    inv_cell = np.linalg.inv(cell)
    scaled = np.dot(np.asarray(positions_cart, dtype=float), inv_cell)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as fp:
        fp.write(f"{comment}\n")
        fp.write("1.0\n")
        for vec in np.asarray(cell, dtype=float):
            fp.write(f"  {vec[0]: .16f}  {vec[1]: .16f}  {vec[2]: .16f}\n")
        fp.write("  " + "  ".join(uniq) + "\n")
        fp.write("  " + "  ".join(str(v) for v in counts) + "\n")
        fp.write("Direct\n")
        for row in scaled:
            fp.write(f"  {row[0]: .16f}  {row[1]: .16f}  {row[2]: .16f}\n")


def _expand_bead_structure(symbols: list[str], bead_positions_cart: np.ndarray) -> tuple[list[str], np.ndarray]:
    expanded_symbols: list[str] = []
    expanded_positions: list[np.ndarray] = []
    for bead_index in range(int(bead_positions_cart.shape[0])):
        for atom_index, sym in enumerate(symbols):
            expanded_symbols.append(sym)
            expanded_positions.append(bead_positions_cart[bead_index, atom_index])
    return expanded_symbols, np.asarray(expanded_positions, dtype=float)


def _write_xdatcar_direct(
    path: Path,
    symbols: list[str],
    cell: np.ndarray,
    frames_cart: np.ndarray,
    steps: np.ndarray,
    comment: str,
) -> None:
    uniq, counts = _symbol_counts(symbols)
    inv_cell = np.linalg.inv(cell)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as fp:
        fp.write(f"{comment}\n")
        fp.write("1.0\n")
        for vec in np.asarray(cell, dtype=float):
            fp.write(f"  {vec[0]: .16f}  {vec[1]: .16f}  {vec[2]: .16f}\n")
        fp.write("  " + "  ".join(uniq) + "\n")
        fp.write("  " + "  ".join(str(v) for v in counts) + "\n")
        for index_frame in range(int(frames_cart.shape[0])):
            fp.write(f"Direct configuration= {int(steps[index_frame])}\n")
            scaled = np.dot(np.asarray(frames_cart[index_frame], dtype=float), inv_cell)
            for row in scaled:
                fp.write(f"  {row[0]: .16f}  {row[1]: .16f}  {row[2]: .16f}\n")


def _select_step_indices(steps: np.ndarray, step_arg: str) -> np.ndarray:
    tag = str(step_arg).strip().lower()
    if tag == "all":
        return np.arange(len(steps), dtype=int)
    if tag == "latest":
        return np.array([len(steps) - 1], dtype=int)
    try:
        target_step = int(step_arg)
    except Exception as exc:
        raise ValueError("--step must be one of: latest, all, or an integer step value.") from exc
    indices = np.where(np.asarray(steps, dtype=int) == target_step)[0]
    if indices.size == 0:
        raise ValueError(f"Requested --step={target_step} not found in trajectory.")
    return indices.astype(int)


def run_pimd2_export_structure(args) -> None:
    traj = _load_traj(args)
    out_dir = _resolve_output_dir(args)
    target = Path(getattr(args, "input", None) or getattr(args, "dir", ".")).expanduser().resolve()
    restart_path = target if (target.is_file() and target.name == "restart.npz") else (target / "restart.npz")
    if traj.cell is None:
        if restart_path.exists():
            try:
                with np.load(restart_path, allow_pickle=True) as restart:
                    if "cell" in restart:
                        cell_raw = np.array(restart["cell"], dtype=float)
                        if cell_raw.ndim == 3:
                            cell_raw = cell_raw[0]
                        traj.cell = cell_raw * BOHR_TO_ANG
                    if (not traj.symbols or set(traj.symbols) == {"X"}) and "symbols" in restart:
                        traj.symbols = [str(x) for x in restart["symbols"].tolist()]
            except Exception:
                pass
    if not traj.symbols or set(traj.symbols) == {"X"}:
        poscar_ref = getattr(args, "poscar", None)
        poscar_candidates: list[Path] = []
        if poscar_ref:
            poscar_candidates.append(Path(poscar_ref).expanduser().resolve())
        if target.is_dir():
            poscar_candidates.extend([target / "POSCAR", target / "CONTCAR"])
        else:
            poscar_candidates.extend([target.parent / "POSCAR", target.parent / "CONTCAR"])
        used_poscar = None
        for cand in poscar_candidates:
            symbols_from_poscar = _load_symbols_from_poscar(cand, traj.natom)
            if symbols_from_poscar is not None:
                traj.symbols = symbols_from_poscar
                used_poscar = cand
                break
        if used_poscar is not None:
            print(f"[pimd] Info: inferred symbols from POSCAR reference: {used_poscar}")
        elif restart_path.exists():
            symbols_from_mass = _infer_symbols_from_physmass(restart_path, traj.natom)
            if symbols_from_mass is not None:
                traj.symbols = symbols_from_mass
                print(f"[pimd] Info: inferred symbols from restart physmass: {restart_path}")
    if traj.cell is None:
        raise ValueError("Structure export requires cell information. Use NPZ input with `cell` payload.")

    write_poscar = bool(getattr(args, "write_poscar", False))
    write_xdatcar = bool(getattr(args, "write_xdatcar", False))
    all_variants = bool(getattr(args, "all_variants", False))
    if not write_poscar and not write_xdatcar:
        write_poscar = True
        write_xdatcar = True

    selected_indices = _select_step_indices(traj.steps, getattr(args, "step", "latest"))
    selected_steps = np.asarray(traj.steps[selected_indices], dtype=int)
    selected_coords = np.asarray(traj.coords[selected_indices], dtype=float)
    poscar_mode = str(getattr(args, "poscar_mode", "mean")).lower()
    xdatcar_mode = str(getattr(args, "xdatcar_mode", "mean")).lower()
    poscar_modes = ["mean", "beads"] if all_variants else [poscar_mode]
    xdatcar_modes = ["mean", "beads"] if all_variants else [xdatcar_mode]
    output_poscar_name = str(getattr(args, "output_poscar", "POSCAR_pimd_export"))
    output_xdatcar_name = str(getattr(args, "output_xdatcar", "XDATCAR-PIMD-export"))

    written: list[str] = []

    if write_poscar:
        for mode in poscar_modes:
            if mode not in {"mean", "beads"}:
                raise ValueError("--poscar-mode must be `mean` or `beads`.")
            poscar_name = output_poscar_name if (not all_variants) else f"{output_poscar_name}_{mode}"
            if len(selected_indices) == 1:
                frame = selected_coords[0]
                step_val = int(selected_steps[0])
                if mode == "mean":
                    pos = np.mean(frame, axis=0)
                    symbols = list(traj.symbols)
                else:
                    symbols, pos = _expand_bead_structure(list(traj.symbols), frame)
                poscar_path = out_dir / poscar_name
                _write_poscar_cart(
                    poscar_path,
                    symbols=symbols,
                    cell=np.asarray(traj.cell, dtype=float),
                    positions_cart=pos,
                    comment=f"PIMD export (step={step_val}, mode={mode})",
                )
                written.append(str(poscar_path))
            else:
                stem = Path(poscar_name).name
                suffix = Path(poscar_name).suffix
                base = stem[: -len(suffix)] if suffix else stem
                for idx, step_val in enumerate(selected_steps):
                    frame = selected_coords[idx]
                    if mode == "mean":
                        pos = np.mean(frame, axis=0)
                        symbols = list(traj.symbols)
                    else:
                        symbols, pos = _expand_bead_structure(list(traj.symbols), frame)
                    name = f"{base}_step{int(step_val):06d}{suffix}" if suffix else f"{base}_step{int(step_val):06d}"
                    poscar_path = out_dir / name
                    _write_poscar_cart(
                        poscar_path,
                        symbols=symbols,
                        cell=np.asarray(traj.cell, dtype=float),
                        positions_cart=pos,
                        comment=f"PIMD export (step={int(step_val)}, mode={mode})",
                    )
                    written.append(str(poscar_path))

    if write_xdatcar:
        for mode in xdatcar_modes:
            if mode not in {"mean", "beads"}:
                raise ValueError("--xdatcar-mode must be `mean` or `beads`.")
            xdatcar_name = output_xdatcar_name if (not all_variants) else f"{output_xdatcar_name}_{mode}"
            xdatcar_path = out_dir / xdatcar_name
            if mode == "mean":
                frames = np.mean(selected_coords, axis=1)
                symbols = list(traj.symbols)
            else:
                expanded_symbols: list[str] | None = None
                expanded_frames: list[np.ndarray] = []
                for frame in selected_coords:
                    ex_symbols, ex_pos = _expand_bead_structure(list(traj.symbols), frame)
                    if expanded_symbols is None:
                        expanded_symbols = ex_symbols
                    expanded_frames.append(ex_pos)
                symbols = expanded_symbols or list(traj.symbols)
                frames = np.stack(expanded_frames, axis=0)
            _write_xdatcar_direct(
                xdatcar_path,
                symbols=symbols,
                cell=np.asarray(traj.cell, dtype=float),
                frames_cart=np.asarray(frames, dtype=float),
                steps=selected_steps,
                comment=f"PIMD export (mode={mode})",
            )
            written.append(str(xdatcar_path))

    print("[pimd] Wrote:")
    for path in written:
        print(f"  - {path}")


def run_pimd2_bond_pbc(args) -> None:
    traj = _load_traj(args)
    out_prefix = _resolve_output_dir(args) / "pimd_bond_pbc"
    hist_min, hist_max = _resolve_hist_range(args)
    atom1 = _idx(args.atom1, "atom1")
    atom2 = _idx(args.atom2, "atom2")
    values = _bond_pbc(traj.coords, traj.cell, atom1, atom2)
    _write_step_and_bead(out_prefix, traj.steps, values, "bond_pbc")
    hist_pdf = out_prefix.with_name(out_prefix.name + "_hist.pdf")
    hist_dat = out_prefix.with_name(out_prefix.name + "_hist.dat")
    _write_hist_pdf(
        values=values,
        out_pdf=hist_pdf,
        title=f"Bond PBC atom{atom1+1}-atom{atom2+1}",
        x_label="Bond length (Angstrom)",
        nhist=int(getattr(args, "nhist", 200)),
        hist_min=hist_min,
        hist_max=hist_max,
    )
    _write_hist_dat(
        values=values,
        out_dat=hist_dat,
        nhist=int(getattr(args, "nhist", 200)),
        descriptor=f"bond_pbc(atom{atom1+1}-atom{atom2+1})",
        x_col_name="bin_center_A",
        hist_min=hist_min,
        hist_max=hist_max,
    )
    print(f"[pimd] Wrote: {out_prefix}_step.dat, {out_prefix}_beads.dat, {hist_pdf}, {hist_dat}")


def run_pimd2_bond_diff_pbc(args) -> None:
    traj = _load_traj(args)
    out_prefix = _resolve_output_dir(args) / "pimd_bond_diff_pbc"
    hist_min, hist_max = _resolve_hist_range(args)
    atom1 = _idx(args.atom1, "atom1")
    atom2 = _idx(args.atom2, "atom2")
    atom3 = _idx(args.atom3, "atom3")
    atom4 = _idx(args.atom4, "atom4")
    values = _bond_pbc(traj.coords, traj.cell, atom1, atom2) - _bond_pbc(traj.coords, traj.cell, atom3, atom4)
    _write_step_and_bead(out_prefix, traj.steps, values, "bond_diff_pbc")
    hist_pdf = out_prefix.with_name(out_prefix.name + "_hist.pdf")
    hist_dat = out_prefix.with_name(out_prefix.name + "_hist.dat")
    _write_hist_pdf(
        values=values,
        out_pdf=hist_pdf,
        title=f"Bond diff PBC (atom{atom1+1}-atom{atom2+1})-(atom{atom3+1}-atom{atom4+1})",
        x_label="Bond difference (Angstrom)",
        nhist=int(getattr(args, "nhist", 200)),
        hist_min=hist_min,
        hist_max=hist_max,
    )
    _write_hist_dat(
        values=values,
        out_dat=hist_dat,
        nhist=int(getattr(args, "nhist", 200)),
        descriptor=f"bond_diff_pbc((atom{atom1+1}-atom{atom2+1})-(atom{atom3+1}-atom{atom4+1}))",
        x_col_name="bin_center_A",
        hist_min=hist_min,
        hist_max=hist_max,
    )
    print(f"[pimd] Wrote: {out_prefix}_step.dat, {out_prefix}_beads.dat, {hist_pdf}, {hist_dat}")


def _attach_common_io_args(parser: argparse.ArgumentParser, include_hist: bool = False) -> None:
    parser.add_argument("--dir", default=".", help="Run directory used when -i/--input is not provided (default: .).")
    parser.add_argument(
        "-i",
        "--input",
        default=None,
        help="Preferred trajectory input path: directory, coor.xyz, or .npz snapshot.",
    )
    parser.add_argument(
        "--source",
        choices=["auto", "npz", "coor"],
        default="auto",
        help="Trajectory source backend (`auto`: try NPZ first, then fall back to coor.xyz).",
    )
    parser.add_argument("--nbead", type=int, default=None, help="Needed only for coor.xyz when auto-inference fails.")
    parser.add_argument("--natom", type=int, default=None, help="Needed only for coor.xyz when auto-inference fails.")
    parser.add_argument("--output-dir", default=None, help="Directory for output files (default: input parent or --dir).")
    if include_hist:
        parser.add_argument("--nhist", type=int, default=200, help="Histogram bins.")


def _attach_hist_range_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--hist-min", type=float, default=None, help="Histogram lower bound.")
    parser.add_argument("--hist-max", type=float, default=None, help="Histogram upper bound.")


def build_pimd2_summary_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    parser = parser or argparse.ArgumentParser(description="Summarize PIMDanalysis2-compatible trajectory source.")
    _attach_common_io_args(parser)
    return parser


def build_pimd2_bond_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    parser = parser or argparse.ArgumentParser()
    parser.formatter_class = argparse.RawDescriptionHelpFormatter
    parser.description = "Bond-length analysis: computes d(atom1,atom2) for each bead/frame."
    parser.epilog = (
        "Outputs:\n"
        "  pimd_bond_step.dat   (step, bond_mean)\n"
        "  pimd_bond_beads.dat  (step, ibead, bond)\n"
        "  pimd_bond_hist.dat   (bin_center_A, count)\n"
        "  pimd_bond_hist.pdf   (histogram plot)\n"
        "\n"
        "Formula: bond = d(atom1,atom2)\n"
        "Note: uses minimum-image PBC distance when cell is available; use --no-pbc to disable.\n"
    )
    _attach_common_io_args(parser, include_hist=True)
    parser.add_argument("--atom1", type=int, default=None, help="1-based atom index for bond endpoint A in d(A,B).")
    parser.add_argument("--atom2", type=int, default=None, help="1-based atom index for bond endpoint B in d(A,B).")
    parser.add_argument(
        "--atoms",
        nargs="+",
        type=int,
        default=None,
        help="Optional atom list (1-based). If set, computes all pair combinations (e.g., --atoms 1 2 5 -> 1-2,1-5,2-5).",
    )
    parser.add_argument(
        "--no-pbc",
        action="store_true",
        default=False,
        help="Disable minimum-image PBC distance even when cell is available in NPZ.",
    )
    _attach_hist_range_args(parser)
    return parser


def build_pimd2_angle_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    parser = parser or argparse.ArgumentParser()
    parser.formatter_class = argparse.RawDescriptionHelpFormatter
    parser.description = "Angle analysis: computes angle(atom1-atom2-atom3) for each bead/frame."
    parser.epilog = (
        "Outputs:\n"
        "  pimd_angle_step.dat   (step, angle_deg_mean)\n"
        "  pimd_angle_beads.dat  (step, ibead, angle_deg)\n"
        "  pimd_angle_hist.dat   (bin_center_deg, count)\n"
        "  pimd_angle_hist.pdf   (histogram plot)\n"
        "\n"
        "Formula: angle = ∠(atom1-atom2-atom3)\n"
    )
    _attach_common_io_args(parser, include_hist=True)
    parser.add_argument("--atom1", type=int, default=None, help="1-based atom index for angle endpoint A in ∠(A-B-C).")
    parser.add_argument("--atom2", type=int, default=None, help="1-based atom index for angle vertex B in ∠(A-B-C).")
    parser.add_argument("--atom3", type=int, default=None, help="1-based atom index for angle endpoint C in ∠(A-B-C).")
    parser.add_argument(
        "--atoms",
        nargs="+",
        type=int,
        default=None,
        help="Optional atom list (1-based). If set, computes all angle triplets (e.g., --atoms 1 2 3 5).",
    )
    _attach_hist_range_args(parser)
    return parser


def build_pimd2_dihedral_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    parser = parser or argparse.ArgumentParser()
    parser.formatter_class = argparse.RawDescriptionHelpFormatter
    parser.description = "Dihedral analysis: computes dihedral(atom1-atom2-atom3-atom4) for each bead/frame."
    parser.epilog = (
        "Outputs:\n"
        "  pimd_dihedral_step.dat   (step, dihedral_deg_mean)\n"
        "  pimd_dihedral_beads.dat  (step, ibead, dihedral_deg)\n"
        "  pimd_dihedral_hist.dat   (bin_center_deg, count)\n"
        "  pimd_dihedral_hist.pdf   (histogram plot)\n"
        "\n"
        "Formula: dihedral = torsion(atom1-atom2-atom3-atom4)\n"
    )
    _attach_common_io_args(parser, include_hist=True)
    parser.add_argument("--atom1", type=int, required=True, help="1-based atom index 1 for torsion(1-2-3-4).")
    parser.add_argument("--atom2", type=int, required=True, help="1-based atom index 2 for torsion(1-2-3-4).")
    parser.add_argument("--atom3", type=int, required=True, help="1-based atom index 3 for torsion(1-2-3-4).")
    parser.add_argument("--atom4", type=int, required=True, help="1-based atom index 4 for torsion(1-2-3-4).")
    _attach_hist_range_args(parser)
    return parser


def build_pimd2_bond_diff_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    parser = parser or argparse.ArgumentParser()
    parser.formatter_class = argparse.RawDescriptionHelpFormatter
    parser.description = "Bond-difference analysis: computes d(atom1,atom2) - d(atom3,atom4) for each bead/frame."
    parser.epilog = (
        "Outputs:\n"
        "  pimd_bond_diff_step.dat   (step, bond_diff_mean)\n"
        "  pimd_bond_diff_beads.dat  (step, ibead, bond_diff)\n"
        "  pimd_bond_diff_hist.dat   (bin_center_A, count)\n"
        "  pimd_bond_diff_hist.pdf   (histogram plot)\n"
        "\n"
        "Formula: bond_diff = d(atom1,atom2) - d(atom3,atom4)\n"
    )
    _attach_common_io_args(parser, include_hist=True)
    parser.add_argument(
        "--atom1",
        type=int,
        required=True,
        help="1-based atom index for first bond endpoint A in d(A,B).",
    )
    parser.add_argument(
        "--atom2",
        type=int,
        required=True,
        help="1-based atom index for first bond endpoint B in d(A,B).",
    )
    parser.add_argument(
        "--atom3",
        type=int,
        required=True,
        help="1-based atom index for second bond endpoint C in d(C,D).",
    )
    parser.add_argument(
        "--atom4",
        type=int,
        required=True,
        help="1-based atom index for second bond endpoint D in d(C,D).",
    )
    _attach_hist_range_args(parser)
    return parser


def build_pimd2_bond_add_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    parser = parser or argparse.ArgumentParser()
    parser.formatter_class = argparse.RawDescriptionHelpFormatter
    parser.description = "Bond-add analysis: computes d(atom1,atom2) + d(atom3,atom4) for each bead/frame."
    parser.epilog = (
        "Outputs:\n"
        "  pimd_bond_add_step.dat   (step, bond_add_mean)\n"
        "  pimd_bond_add_beads.dat  (step, ibead, bond_add)\n"
        "  pimd_bond_add_hist.dat   (bin_center_A, count)\n"
        "  pimd_bond_add_hist.pdf   (histogram plot)\n"
        "\n"
        "Formula: bond_add = d(atom1,atom2) + d(atom3,atom4)\n"
    )
    _attach_common_io_args(parser, include_hist=True)
    parser.add_argument("--atom1", type=int, required=True, help="1-based atom index for first bond endpoint A in d(A,B).")
    parser.add_argument("--atom2", type=int, required=True, help="1-based atom index for first bond endpoint B in d(A,B).")
    parser.add_argument("--atom3", type=int, required=True, help="1-based atom index for second bond endpoint C in d(C,D).")
    parser.add_argument("--atom4", type=int, required=True, help="1-based atom index for second bond endpoint D in d(C,D).")
    _attach_hist_range_args(parser)
    return parser


def build_pimd2_multi_bond_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    parser = parser or argparse.ArgumentParser()
    parser.formatter_class = argparse.RawDescriptionHelpFormatter
    parser.description = "Multi-bond analysis: evaluates multiple bond pairs per bead/frame."
    parser.epilog = (
        "Outputs (depends on --mode):\n"
        "  --mode all  -> pimd_multi_bond_all_step.dat, pimd_multi_bond_all_beads.dat\n"
        "  --mode sum  -> pimd_multi_bond_sum_step.dat, pimd_multi_bond_sum_beads.dat\n"
        "  --mode sort -> pimd_multi_bond_sort.dat (step, ibead, idx, value)\n"
        "\n"
        "Formulas:\n"
        "  all: mean over pairs for each bead/frame\n"
        "  sum: sum over pairs for each bead/frame\n"
        "  sort: sort pair distances ascending for each bead/frame\n"
    )
    _attach_common_io_args(parser)
    parser.add_argument(
        "--pairs",
        nargs="+",
        required=True,
        help="1-based pair list, e.g. --pairs 1-2 1-3 1-4",
    )
    parser.add_argument(
        "--mode",
        choices=["all", "sort", "sum"],
        default="all",
        help=(
            "Aggregation mode across listed pairs: "
            "`all`=mean pair distance per bead/frame, "
            "`sort`=ascending pair distances per bead/frame (writes idx/value table), "
            "`sum`=sum of pair distances per bead/frame."
        ),
    )
    parser.add_argument("--nhist", type=int, default=200, help="Histogram bins.")
    _attach_hist_range_args(parser)
    return parser


def build_pimd2_hist2d_bond_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    parser = parser or argparse.ArgumentParser()
    parser.formatter_class = argparse.RawDescriptionHelpFormatter
    parser.description = "2D bond-bond histogram: joint distribution of d(atom1,atom2) vs d(atom3,atom4)."
    parser.epilog = (
        "Output:\n"
        "  pimd_hist2d_bond.dat (ix, iy, x_center_A, y_center_A, density)\n"
        "\n"
        "Formula:\n"
        "  x = d(atom1,atom2), y = d(atom3,atom4), then 2D histogram over (x,y)\n"
    )
    _attach_common_io_args(parser, include_hist=True)
    parser.add_argument("--atom1", type=int, required=True, help="1-based atom index for first bond endpoint A in d(A,B).")
    parser.add_argument("--atom2", type=int, required=True, help="1-based atom index for first bond endpoint B in d(A,B).")
    parser.add_argument("--atom3", type=int, required=True, help="1-based atom index for second bond endpoint C in d(C,D).")
    parser.add_argument("--atom4", type=int, required=True, help="1-based atom index for second bond endpoint D in d(C,D).")
    parser.add_argument(
        "--normalize",
        action="store_true",
        help="Normalize 2D histogram so the sum of all bins equals 1.",
    )
    return parser


def build_pimd2_beads_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    parser = parser or argparse.ArgumentParser(description="Beads expansion export.")
    _attach_common_io_args(parser)
    parser.add_argument("--atom1", type=int, default=None, help="Optional start atom index (1-based).")
    parser.add_argument("--atom2", type=int, default=None, help="Optional end atom index (1-based).")
    return parser


def build_pimd2_export_structure_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    parser = parser or argparse.ArgumentParser(description="Export POSCAR/XDATCAR from PIMD NPZ trajectory snapshots.")
    _attach_common_io_args(parser)
    parser.add_argument(
        "--step",
        default="latest",
        help="Step selector: latest, all, or exact integer step value.",
    )
    parser.add_argument("--poscar", default=None, help="Optional reference POSCAR for species labels when NPZ has no symbols.")
    parser.add_argument(
        "--write-poscar",
        action="store_true",
        help="Write POSCAR output. If neither --write-poscar nor --write-xdatcar is set, both are written.",
    )
    parser.add_argument(
        "--write-xdatcar",
        action="store_true",
        help="Write XDATCAR output. If neither --write-poscar nor --write-xdatcar is set, both are written.",
    )
    parser.add_argument(
        "--all-variants",
        action="store_true",
        help="Write all four variants in one run: POSCAR(mean/beads) + XDATCAR(mean/beads).",
    )
    parser.add_argument(
        "--poscar-mode",
        choices=["mean", "beads"],
        default="mean",
        help="POSCAR mode: `mean` uses centroid positions; `beads` expands all beads into one super-structure.",
    )
    parser.add_argument(
        "--xdatcar-mode",
        choices=["mean", "beads"],
        default="mean",
        help="XDATCAR mode: `mean` uses centroid frames; `beads` writes bead-expanded frames.",
    )
    parser.add_argument("--output-poscar", default="POSCAR_pimd_export", help="Output POSCAR filename or prefix.")
    parser.add_argument("--output-xdatcar", default="XDATCAR-PIMD-export", help="Output XDATCAR filename.")
    return parser


def build_pimd2_bond_pbc_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    parser = parser or argparse.ArgumentParser(description="PBC minimum-image bond analysis.")
    _attach_common_io_args(parser, include_hist=True)
    parser.add_argument("--atom1", type=int, required=True)
    parser.add_argument("--atom2", type=int, required=True)
    _attach_hist_range_args(parser)
    return parser


def build_pimd2_bond_diff_pbc_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    parser = parser or argparse.ArgumentParser(description="PBC minimum-image bond-diff analysis.")
    _attach_common_io_args(parser, include_hist=True)
    parser.add_argument("--atom1", type=int, required=True)
    parser.add_argument("--atom2", type=int, required=True)
    parser.add_argument("--atom3", type=int, required=True)
    parser.add_argument("--atom4", type=int, required=True)
    _attach_hist_range_args(parser)
    return parser
