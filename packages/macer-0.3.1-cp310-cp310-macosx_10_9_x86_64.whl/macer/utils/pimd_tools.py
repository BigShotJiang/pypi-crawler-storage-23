from __future__ import annotations

import argparse
import csv
import json
import hashlib
import re
from pathlib import Path

import numpy as np
from ase.io import read

DEFAULT_ELEMENT_COLORS = {
    "H": "#0000ff",
    "O": "#ff0000",
    "C": "#000000",
    "N": "#00aa00",
    "S": "#ff8800",
    "P": "#8000ff",
}
FALLBACK_COLORS = [
    "#ff0000",
    "#0000ff",
    "#00aa00",
    "#ff00ff",
    "#ff8800",
    "#00cccc",
    "#8000ff",
    "#000000",
]
DIR_FALLBACK_HELP = "Run directory used when -i/--input is not provided (default: .)."
INPUT_PATH_HELP = "Preferred input path (directory or file)."
INPUT_PATH_NPZ_HELP = "Preferred input path (directory or .npz snapshot)."


def _resolve_input_root(args, default_dir: str = ".") -> Path:
    raw_input = getattr(args, "input", None)
    if raw_input:
        p = Path(str(raw_input)).expanduser().resolve()
        return p.parent if p.is_file() else p
    raw_dir = getattr(args, "dir", default_dir)
    return Path(str(raw_dir)).expanduser().resolve()


def _resolve_input_path(args, default_dir: str = ".") -> Path:
    raw_input = getattr(args, "input", None)
    if raw_input:
        return Path(str(raw_input)).expanduser().resolve()
    return Path(str(getattr(args, "dir", default_dir))).expanduser().resolve()


def _collect_restart_files(input_path: Path) -> list[Path]:
    if input_path.is_file():
        if input_path.suffix.lower() == ".npz":
            return [input_path]
        raise ValueError(
            f"Unsupported input file for restart source: {input_path} "
            "(use -i/--input with a .npz file, or --dir with pimd_state_step*.npz)"
        )
    files = sorted(input_path.glob("pimd_state_step*.npz"))
    if files:
        return files
    restart = input_path / "restart.npz"
    if restart.exists():
        return [restart]
    history = input_path / "pimd_state_history.npz"
    if history.exists():
        return [history]
    return []


def _parse_element_colors(raw: str | None) -> dict[str, str] | None:
    if not raw:
        return None
    mapping: dict[str, str] = {}
    chunks = [c.strip() for c in str(raw).split(",") if c.strip()]
    for chunk in chunks:
        if ":" not in chunk:
            raise ValueError(f"Invalid --element-colors entry: {chunk}")
        symbol, color = [x.strip() for x in chunk.split(":", 1)]
        if not symbol or not color:
            raise ValueError(f"Invalid --element-colors entry: {chunk}")
        mapping[symbol] = color
    return mapping


def _color_for_element(symbol: str, overrides: dict[str, str] | None = None) -> str:
    if overrides and symbol in overrides:
        return str(overrides[symbol])
    if symbol in DEFAULT_ELEMENT_COLORS:
        return DEFAULT_ELEMENT_COLORS[symbol]
    idx = int(hashlib.md5(symbol.encode("utf-8")).hexdigest(), 16) % len(FALLBACK_COLORS)
    return FALLBACK_COLORS[idx]


def _safe_float(x: str | None) -> float | None:
    if x is None:
        return None
    try:
        return float(x)
    except Exception:
        return None


def _describe(values: np.ndarray) -> dict[str, float]:
    return {
        "mean": float(np.mean(values)),
        "std": float(np.std(values)),
        "min": float(np.min(values)),
        "max": float(np.max(values)),
    }


def _load_pimd_csv(csv_path: str) -> dict[str, np.ndarray]:
    path = Path(csv_path)
    if not path.exists():
        raise FileNotFoundError(f"CSV file not found: {csv_path}")

    rows = []
    with path.open("r", newline="") as fp:
        reader = csv.DictReader(fp)
        for row in reader:
            rows.append(row)
    if not rows:
        raise ValueError(f"CSV has no data rows: {csv_path}")

    out: dict[str, np.ndarray] = {}
    for key in rows[0].keys():
        arr = np.array([_safe_float(r.get(key)) for r in rows], dtype=object)
        vals = np.array([x for x in arr if x is not None], dtype=float)
        if vals.size > 0:
            out[key] = vals
    return out


def _fit_drift(cols: dict[str, np.ndarray], last_frac: float = 1.0) -> tuple[float, float, str, int]:
    h_key = "H_total_au" if "H_total_au" in cols else "H_total"
    if h_key not in cols or cols[h_key].size < 2:
        raise ValueError("Need at least 2 total-energy points to fit drift.")
    if not (0.0 < last_frac <= 1.0):
        raise ValueError("--last-frac must satisfy 0 < last_frac <= 1.")

    n = cols[h_key].size
    i0 = int(np.floor((1.0 - last_frac) * n))
    h = cols[h_key][i0:]
    if h.size < 2:
        raise ValueError("Selected window is too short for drift fit.")

    if "time_fs" in cols and cols["time_fs"].size >= i0 + h.size:
        x = cols["time_fs"][i0 : i0 + h.size] / 1000.0
        unit = "ps"
    else:
        x = np.arange(h.size, dtype=float)
        unit = "frame"
    slope, intercept = np.polyfit(x, h, 1)
    return float(slope), float(intercept), unit, int(h.size)


def _load_eavg_table(eavg_path: str) -> tuple[list[str], np.ndarray] | None:
    path = Path(eavg_path)
    if not path.exists():
        return None
    lines = path.read_text().splitlines()
    data = []
    for line in lines:
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        toks = s.split()
        try:
            data.append([float(t) for t in toks])
        except Exception:
            continue
    if not data:
        return None
    arr = np.array(data, dtype=float)
    headers = [
        "step",
        "epot",
        "ekinvir",
        "ekinpri",
        "etot",
        "epot_avg",
        "ekinvir_avg",
        "ekinpri_avg",
        "etot_avg",
        "specific_heat",
    ]
    if arr.shape[1] != len(headers):
        return None
    return headers, arr


def pimd_summary(csv_path: str = "pimd.csv", eavg_path: str = "pimd-eavg.out") -> None:
    try:
        cols = _load_pimd_csv(csv_path)
    except Exception as exc:
        print(f"Error: {exc}")
        return

    print(f"\nPIMD Summary: {csv_path}")
    print("-" * 60)
    if "step" in cols:
        print(f"Frames: {len(cols['step'])}")
        print(f"Step range: {int(cols['step'][0])} -> {int(cols['step'][-1])}")
    if "time_fs" in cols:
        print(f"Time span: {cols['time_fs'][0]:.3f} -> {cols['time_fs'][-1]:.3f} fs")

    stats_keys = [
        "H_total_au",
        "V_potential_au",
        "K_dynamic_au",
        "K_quantum_au",
        "Ebath_au",
        "Ebath_cent_au",
        "temperature_K",
    ]
    for key in stats_keys:
        if key not in cols:
            continue
        st = _describe(cols[key])
        print(
            f"{key:16s}: mean={st['mean']:.8f}, std={st['std']:.8f}, "
            f"min={st['min']:.8f}, max={st['max']:.8f}"
        )

    try:
        slope, intercept, unit, nfit = _fit_drift(cols, last_frac=1.0)
        print(f"Energy drift (all points): dH/dt = {slope:.6e} au/{unit} (N={nfit})")
        print(f"Linear-fit intercept: {intercept:.8f} au")
    except Exception:
        pass

    eavg = _load_eavg_table(eavg_path)
    if eavg is not None:
        headers, arr = eavg
        print(f"\nEAVG Summary: {eavg_path}")
        hidx = {h: i for i, h in enumerate(headers)}
        for k in ["epot", "ekinvir", "ekinpri", "etot", "specific_heat"]:
            st = _describe(arr[:, hidx[k]])
            print(
                f"{k:12s}: mean={st['mean']:.8f}, std={st['std']:.8f}, "
                f"min={st['min']:.8f}, max={st['max']:.8f}"
            )
        print(
            "final_avg      : "
            f"epot={arr[-1, hidx['epot_avg']]:.8f}, "
            f"ekinvir={arr[-1, hidx['ekinvir_avg']]:.8f}, "
            f"ekinpri={arr[-1, hidx['ekinpri_avg']]:.8f}, "
            f"etot={arr[-1, hidx['etot_avg']]:.8f}, "
            f"Cv={arr[-1, hidx['specific_heat']]:.6f}"
        )
    else:
        print(f"\nEAVG Summary: skipped (file missing or format mismatch): {eavg_path}")

    print("-" * 60)


def pimd_thermo_report(run_dirs: list[str], output_csv: str, last_frac: float = 0.5) -> None:
    rows: list[dict[str, float | str | int]] = []
    for d in run_dirs:
        run_dir = Path(d).expanduser().resolve()
        csv_path = run_dir / "pimd.csv"
        eavg_path = run_dir / "pimd-eavg.out"
        if not csv_path.exists():
            print(f"[skip] missing pimd.csv: {csv_path}")
            continue
        try:
            cols = _load_pimd_csv(str(csv_path))
            slope_all, _, unit_all, n_all = _fit_drift(cols, last_frac=1.0)
            slope_tail, _, unit_tail, n_tail = _fit_drift(cols, last_frac=last_frac)
            h_key = "H_total_au" if "H_total_au" in cols else "H_total"
            t_key = "temperature_K" if "temperature_K" in cols else "T_inst"
            eb_key = "Ebath_au" if "Ebath_au" in cols else "Ebath_total"
            n = cols[h_key].size
            i0 = int(np.floor((1.0 - last_frac) * n))
            t_tail = cols[t_key][i0:] if t_key in cols and cols[t_key].size == n else np.array([], dtype=float)
            h_tail = cols[h_key][i0:]
            eb_tail = cols[eb_key][i0:] if eb_key in cols and cols[eb_key].size == n else np.array([], dtype=float)
            cv_final = np.nan
            etot_avg_final = np.nan
            eavg = _load_eavg_table(str(eavg_path))
            if eavg is not None:
                headers, arr = eavg
                cv_final = float(arr[-1, headers.index("specific_heat")])
                etot_avg_final = float(arr[-1, headers.index("etot_avg")])
            rows.append(
                {
                    "run_dir": str(run_dir),
                    "n_frames": int(n),
                    "fit_points_all": int(n_all),
                    "fit_points_tail": int(n_tail),
                    f"dHdt_all_per_{unit_all}": float(slope_all),
                    f"dHdt_tail_per_{unit_tail}": float(slope_tail),
                    "T_tail_mean_K": float(np.mean(t_tail)) if t_tail.size > 0 else np.nan,
                    "T_tail_std_K": float(np.std(t_tail)) if t_tail.size > 0 else np.nan,
                    "H_tail_mean": float(np.mean(h_tail)),
                    "H_tail_std": float(np.std(h_tail)),
                    "Ebath_tail_mean": float(np.mean(eb_tail)) if eb_tail.size > 0 else np.nan,
                    "Cv_final": float(cv_final),
                    "Etot_avg_final": float(etot_avg_final),
                }
            )
        except Exception as exc:
            print(f"[skip] failed {run_dir}: {exc}")
            continue

    if not rows:
        print("No valid runs found for thermo report.")
        return

    out = Path(output_csv).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(rows[0].keys())
    with out.open("w", newline="") as fp:
        writer = csv.DictWriter(fp, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"\nPIMD thermo report saved: {out}")
    print("-" * 60)
    for r in rows:
        print(
            f"{Path(str(r['run_dir'])).name:28s} "
            f"T_tail={r['T_tail_mean_K']:.2f} K, "
            f"Cv_final={r['Cv_final']:.4f}"
        )
    print("-" * 60)


def pimd_adp_timeseries(run_dir: str, output_csv: str = "pimd-adp-timeseries.csv") -> None:
    root = Path(run_dir).expanduser().resolve()
    files = sorted(root.glob("adp_step_*.dat"))
    rows = []
    for f in files:
        step = _extract_step_from_name(f.name, "adp_step_")
        if step is None:
            continue
        try:
            adp_rows = _parse_adp_rows(f)
            if not adp_rows:
                continue
            uiso = np.array(
                [(float(r["Uxx"]) + float(r["Uyy"]) + float(r["Uzz"])) / 3.0 for r in adp_rows],
                dtype=float,
            )
            rows.append(
                {
                    "step": int(step),
                    "n_atoms": int(uiso.size),
                    "Uiso_mean_A2": float(np.mean(uiso)),
                    "Uiso_std_A2": float(np.std(uiso)),
                    "Uiso_min_A2": float(np.min(uiso)),
                    "Uiso_max_A2": float(np.max(uiso)),
                }
            )
        except Exception as exc:
            print(f"[skip] {f.name}: {exc}")

    if not rows:
        print(f"No ADP step files found in: {root}")
        return

    out = Path(output_csv).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="") as fp:
        w = csv.DictWriter(fp, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"\nPIMD ADP timeseries saved: {out}")
    print("-" * 60)
    print(
        f"steps={rows[0]['step']}..{rows[-1]['step']} (N={len(rows)}), "
        f"final Uiso_mean={rows[-1]['Uiso_mean_A2']:.6e} A^2"
    )
    print("-" * 60)


def _parse_step_arg(step: str, files: list[Path], prefix: str) -> int:
    if not files:
        raise ValueError("No restart files found.")
    steps = []
    for f in files:
        s = _extract_step_from_name(f.name, prefix)
        if s is not None:
            steps.append(s)
    if not steps:
        raise ValueError("Could not parse step from restart filenames.")
    if step == "latest":
        return int(max(steps))
    return int(step)


def _find_restart_file(run_dir: Path, step: int | None = None) -> Path:
    files = sorted(run_dir.glob("pimd_state_step*.npz"))
    if not files:
        raise FileNotFoundError(f"No restart files in: {run_dir}")
    if step is None:
        return files[-1]
    target = run_dir / f"pimd_state_step{step:06d}.npz"
    if not target.exists():
        raise FileNotFoundError(f"Restart file not found: {target}")
    return target


def _build_bead_expanded_structure(symbols: list[str], bead_positions_cart: np.ndarray) -> tuple[list[str], np.ndarray]:
    species = list(dict.fromkeys(symbols))
    idx_by_species = {sp: [i for i, sym in enumerate(symbols) if sym == sp] for sp in species}
    expanded_symbols: list[str] = []
    expanded_positions: list[np.ndarray] = []
    for sp in species:
        for atom_idx in idx_by_species[sp]:
            for bead_idx in range(bead_positions_cart.shape[0]):
                expanded_symbols.append(sp)
                expanded_positions.append(bead_positions_cart[bead_idx, atom_idx].copy())
    return expanded_symbols, np.array(expanded_positions, dtype=float)


def _write_poscar_cartesian(path: Path, symbols: list[str], cell: np.ndarray, positions_cart: np.ndarray, comment: str) -> None:
    species = list(dict.fromkeys(symbols))
    counts = [symbols.count(spec) for spec in species]
    inv_cell = np.linalg.inv(cell.T)
    scaled = positions_cart @ inv_cell
    scaled = scaled - np.floor(scaled)
    with path.open("w") as fp:
        fp.write(comment + "\n")
        fp.write("1.0\n")
        for vec in cell:
            fp.write(f" {vec[0]:20.16f} {vec[1]:20.16f} {vec[2]:20.16f}\n")
        fp.write(" " + " ".join(species) + "\n")
        fp.write(" " + " ".join(str(c) for c in counts) + "\n")
        fp.write("Direct\n")
        for s in scaled:
            fp.write(f" {s[0]:20.16f} {s[1]:20.16f} {s[2]:20.16f}\n")


def _append_xdatcar_frame(fp, symbols: list[str], cell: np.ndarray, positions: np.ndarray, step: int) -> None:
    species = list(dict.fromkeys(symbols))
    counts = [symbols.count(spec) for spec in species]
    inv_cell = np.linalg.inv(cell.T)
    scaled = positions @ inv_cell
    scaled = scaled - np.floor(scaled)
    fp.write("".join(species) + "\n")
    fp.write("    1.000000\n")
    for vec in cell:
        fp.write(f" {vec[0]:12.6f} {vec[1]:12.6f} {vec[2]:12.6f}\n")
    fp.write(" " + " ".join(species) + "\n")
    fp.write(" " + " ".join(str(c) for c in counts) + "\n")
    fp.write(f"Direct configuration= {step:5d}\n")
    for s in scaled:
        fp.write(f"   {s[0]:.8f}   {s[1]:.8f}   {s[2]:.8f}\n")


def build_pimd_summary_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(prog="macer util pimd summary")
    parser.add_argument("--dir", default=".", help=DIR_FALLBACK_HELP)
    parser.add_argument("-i", "--input", default=None, help=INPUT_PATH_HELP)
    parser.add_argument("--csv", default="pimd.csv", help="CSV filename (default: pimd.csv)")
    parser.add_argument("--eavg", default="pimd-eavg.out", help="EAVG filename (default: pimd-eavg.out)")
    return parser


def run_pimd_summary(args) -> None:
    run_dir = _resolve_input_root(args)
    pimd_summary(csv_path=str(run_dir / args.csv), eavg_path=str(run_dir / args.eavg))


def build_pimd_thermo_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(prog="macer util pimd thermo")
    parser.add_argument("--dirs", nargs="+", default=None, help="Run directories (used when -i/--input is not provided).")
    parser.add_argument(
        "-i",
        "--input",
        nargs="+",
        default=None,
        help="Preferred input run directories (alias of --dirs).",
    )
    parser.add_argument("--output-csv", default="pimd-thermo-report.csv", help="Output CSV path.")
    parser.add_argument("--last-frac", type=float, default=0.5, help="Tail fraction for drift/statistics.")
    return parser


def run_pimd_thermo(args) -> None:
    run_dirs = args.input if args.input else args.dirs
    if not run_dirs:
        raise ValueError("thermo requires --dirs or -i/--input.")
    pimd_thermo_report(run_dirs=run_dirs, output_csv=args.output_csv, last_frac=args.last_frac)


def build_pimd_beads_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(prog="macer util pimd beads")
    parser.add_argument("--dir", default=".", help=DIR_FALLBACK_HELP)
    parser.add_argument("-i", "--input", default=None, help=INPUT_PATH_NPZ_HELP)
    parser.add_argument("--step", default="latest", help="Step number or 'latest'.")
    parser.add_argument("--output-poscar", default="POSCAR_pimd_beads_from_restart", help="Output bead-expanded POSCAR.")
    parser.add_argument("--write-xdatcar-beads", action="store_true", help="Write XDATCAR from restart snapshots.")
    parser.add_argument("--output-xdatcar", default="XDATCAR-PIMD-BEADS-rebuilt", help="Output XDATCAR path.")
    return parser


def run_pimd_beads(args) -> None:
    in_path = _resolve_input_path(args)
    run_dir = in_path if in_path.is_dir() else in_path.parent
    restart_files = _collect_restart_files(in_path)
    if in_path.is_file():
        rst_path = in_path
        step = int(np.load(rst_path, allow_pickle=True).get("step", 0))
    else:
        step = _parse_step_arg(str(args.step), restart_files, "pimd_state_step")
        rst_path = _find_restart_file(run_dir, step=step)
    rst = np.load(rst_path, allow_pickle=True)
    symbols = [str(s) for s in rst["symbols"].tolist()]
    cell = np.array(rst["cell"], dtype=float)
    r_bead = np.array(rst["r_bead"], dtype=float)
    expanded_symbols, expanded_positions = _build_bead_expanded_structure(symbols=symbols, bead_positions_cart=r_bead)
    out_poscar = Path(args.output_poscar).expanduser().resolve()
    _write_poscar_cartesian(
        path=out_poscar,
        symbols=expanded_symbols,
        cell=cell,
        positions_cart=expanded_positions,
        comment=f"Bead-expanded structure rebuilt from step {step}",
    )
    print(f"Wrote bead-expanded POSCAR: {out_poscar}")

    if args.write_xdatcar_beads:
        out_xdat = Path(args.output_xdatcar).expanduser().resolve()
        with out_xdat.open("w") as fp:
            for rf in restart_files:
                rs = np.load(rf, allow_pickle=True)
                step_i = int(rs.get("step", 0))
                symbols_i = [str(s) for s in rs["symbols"].tolist()]
                cell_i = np.array(rs["cell"], dtype=float)
                r_bead_i = np.array(rs["r_bead"], dtype=float)
                ex_symbols, ex_pos = _build_bead_expanded_structure(symbols_i, r_bead_i)
                _append_xdatcar_frame(fp, ex_symbols, cell_i, ex_pos, step_i)
        print(f"Wrote rebuilt XDATCAR-beads: {out_xdat}")


def build_pimd_restart_export_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(prog="macer util pimd restart-export")
    parser.add_argument("--dir", default=".", help=DIR_FALLBACK_HELP)
    parser.add_argument("-i", "--input", default=None, help=INPUT_PATH_NPZ_HELP)
    parser.add_argument("--npz", default=None, help="Input NPZ snapshot path. If omitted, uses --dir + --step.")
    parser.add_argument("--step", default="latest", help="Step number or 'latest' (used when --npz is omitted).")
    parser.add_argument("--output", default="restart.dat", help="Output external restart.dat path.")
    return parser


def run_pimd_restart_export(args) -> None:
    if args.npz:
        npz_path = Path(args.npz).expanduser().resolve()
    else:
        in_path = _resolve_input_path(args)
        if in_path.is_file():
            npz_path = in_path
        else:
            run_dir = in_path
            restart_files = _collect_restart_files(in_path)
            step = _parse_step_arg(str(args.step), restart_files, "pimd_state_step")
            npz_path = _find_restart_file(run_dir, step=step)

    if not npz_path.exists():
        raise FileNotFoundError(f"NPZ snapshot not found: {npz_path}")
    arr = np.load(npz_path, allow_pickle=True)
    text = str(arr["external_restart_text"].item())
    out = Path(args.output).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text if text.endswith("\n") else text + "\n")
    print(f"Wrote external restart: {out}")


def build_pimd_adp_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(prog="macer util pimd adp")
    parser.add_argument("--dir", default=".", help=DIR_FALLBACK_HELP)
    parser.add_argument("-i", "--input", default=None, help=INPUT_PATH_HELP)
    parser.add_argument("--output-csv", default="pimd-adp-timeseries.csv", help="Output CSV for ADP time series.")
    return parser


def run_pimd_adp(args) -> None:
    pimd_adp_timeseries(run_dir=str(_resolve_input_root(args)), output_csv=args.output_csv)


def _dist_moments(disp: np.ndarray, pdf: np.ndarray) -> tuple[float, float]:
    z = np.trapz(pdf, disp)
    if abs(z) < 1.0e-30:
        return np.nan, np.nan
    p = pdf / z
    m = float(np.trapz(disp * p, disp))
    v = float(np.trapz((disp - m) ** 2 * p, disp))
    return m, float(np.sqrt(max(v, 0.0)))


def _extract_step_from_name(name: str, prefix: str) -> int | None:
    m = re.search(rf"{re.escape(prefix)}(\d+)", name)
    if not m:
        return None
    return int(m.group(1))


def _parse_distribution_element(name: str) -> str | None:
    m = re.search(r"_element_([^_]+)_avg\.dat$", name)
    if not m:
        return None
    return str(m.group(1))


def _parse_adp_rows(path: Path) -> list[dict]:
    rows: list[dict] = []
    with path.open("r") as fp:
        for line in fp:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            toks = s.split()
            if len(toks) < 12:
                continue
            rows.append(
                {
                    "index": int(toks[0]),
                    "symbol": str(toks[1]),
                    "mean_x": float(toks[2]),
                    "mean_y": float(toks[3]),
                    "mean_z": float(toks[4]),
                    "Uxx": float(toks[5]),
                    "Uyy": float(toks[6]),
                    "Uzz": float(toks[7]),
                    "Uxy": float(toks[8]),
                    "Uxz": float(toks[9]),
                    "Uyz": float(toks[10]),
                    "sigma_x": float(np.sqrt(max(float(toks[5]), 0.0))),
                    "sigma_y": float(np.sqrt(max(float(toks[6]), 0.0))),
                    "sigma_z": float(np.sqrt(max(float(toks[7]), 0.0))),
                }
            )
    return rows


def build_pimd_distribution_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(prog="macer util pimd distribution")
    parser.add_argument("--dir", default=".", help=DIR_FALLBACK_HELP)
    parser.add_argument("-i", "--input", default=None, help=INPUT_PATH_HELP)
    parser.add_argument(
        "--source",
        choices=["auto", "distribution", "adp"],
        default="auto",
        help="Input source: distribution_step*.dat or adp_step*.dat.",
    )
    parser.add_argument(
        "--direction",
        choices=["x", "y", "z", "xyz"],
        default="xyz",
        help="Direction(s) to analyze.",
    )
    parser.add_argument(
        "--direction-vector",
        nargs=3,
        type=float,
        default=None,
        metavar=("VX", "VY", "VZ"),
        help="Custom Cartesian direction vector; overrides --direction.",
    )
    parser.add_argument("--element", default=None, help="Filter by element symbol (e.g., H).")
    parser.add_argument(
        "--atom-indices",
        nargs="+",
        type=int,
        default=None,
        help="1-based atom indices filter (ADP source only).",
    )
    parser.add_argument(
        "--list-input-files",
        action="store_true",
        help="Print the input files used for this analysis.",
    )
    parser.add_argument("--output-csv", default="pimd-distribution-timeseries.csv", help="Output CSV.")
    return parser


def run_pimd_distribution(args) -> None:
    root = _resolve_input_root(args)
    source = str(args.source)
    if source == "auto":
        source = "adp" if args.atom_indices else "distribution"

    if source == "distribution" and args.atom_indices:
        raise ValueError("--atom-indices requires `--source adp` (or `--source auto` with atom indices).")

    axes = ["x", "y", "z"] if args.direction == "xyz" else [str(args.direction)]
    use_vec = args.direction_vector is not None
    vec = None
    if use_vec:
        vec = np.array(args.direction_vector, dtype=float)
        nrm = float(np.linalg.norm(vec))
        if nrm <= 1.0e-15:
            raise ValueError("--direction-vector must be non-zero.")
        vec = vec / nrm

    rows = []
    used_files: list[Path] = []

    if source == "distribution":
        files = sorted(root.glob("distribution_step_*_element_*_avg.dat"))
        by_step: dict[int, list[Path]] = {}
        for f in files:
            step = _extract_step_from_name(f.name, "distribution_step_")
            if step is None:
                continue
            by_step.setdefault(step, []).append(f)

        for step in sorted(by_step.keys()):
            means = {"x": [], "y": [], "z": []}
            sigmas = {"x": [], "y": [], "z": []}
            n_elem = 0
            for f in by_step[step]:
                elem = _parse_distribution_element(f.name)
                if args.element and elem != str(args.element):
                    continue
                arr = np.loadtxt(str(f), comments="#")
                if arr.ndim == 1:
                    arr = arr[None, :]
                if arr.shape[1] < 4:
                    continue
                disp = arr[:, 0]
                mx, sx = _dist_moments(disp, arr[:, 1])
                my, sy = _dist_moments(disp, arr[:, 2])
                mz, sz = _dist_moments(disp, arr[:, 3])
                means["x"].append(mx)
                means["y"].append(my)
                means["z"].append(mz)
                sigmas["x"].append(sx)
                sigmas["y"].append(sy)
                sigmas["z"].append(sz)
                n_elem += 1
                used_files.append(f)
            if n_elem < 1:
                continue
            row = {"step": int(step), "n_selected": int(n_elem)}
            if use_vec and vec is not None:
                means_xyz = np.array(
                    [np.nanmean(means["x"]), np.nanmean(means["y"]), np.nanmean(means["z"])], dtype=float
                )
                sig_xyz = np.array(
                    [np.nanmean(sigmas["x"]), np.nanmean(sigmas["y"]), np.nanmean(sigmas["z"])], dtype=float
                )
                row["mean_v_A"] = float(np.dot(vec, means_xyz))
                row["sigma_v_A"] = float(np.sqrt(np.sum((vec * sig_xyz) ** 2)))
            else:
                for ax in axes:
                    row[f"mean_{ax}_A"] = float(np.nanmean(means[ax]))
                    row[f"sigma_{ax}_A"] = float(np.nanmean(sigmas[ax]))
            rows.append(row)
    else:
        files = sorted(root.glob("adp_step_*.dat"))
        selected_idx = set(int(x) for x in (args.atom_indices or []))
        for f in files:
            step = _extract_step_from_name(f.name, "adp_step_")
            if step is None:
                continue
            adp_rows = _parse_adp_rows(f)
            filt = []
            for r in adp_rows:
                if args.element and str(r["symbol"]) != str(args.element):
                    continue
                if selected_idx and int(r["index"]) not in selected_idx:
                    continue
                filt.append(r)
            if not filt:
                continue
            row = {"step": int(step), "n_selected": int(len(filt))}
            if use_vec and vec is not None:
                mean_v = []
                sigma_v = []
                for r in filt:
                    m = np.array([r["mean_x"], r["mean_y"], r["mean_z"]], dtype=float)
                    u = np.array(
                        [
                            [r["Uxx"], r["Uxy"], r["Uxz"]],
                            [r["Uxy"], r["Uyy"], r["Uyz"]],
                            [r["Uxz"], r["Uyz"], r["Uzz"]],
                        ],
                        dtype=float,
                    )
                    mean_v.append(float(np.dot(vec, m)))
                    sigma_v.append(float(np.sqrt(max(float(vec @ u @ vec), 0.0))))
                row["mean_v_A"] = float(np.mean(mean_v))
                row["sigma_v_A"] = float(np.mean(sigma_v))
            else:
                for ax in axes:
                    row[f"mean_{ax}_A"] = float(np.mean([float(r[f"mean_{ax}"]) for r in filt]))
                    row[f"sigma_{ax}_A"] = float(np.mean([float(r[f"sigma_{ax}"]) for r in filt]))
            rows.append(row)
            used_files.append(f)

    if not rows:
        raise ValueError(f"No usable timeseries data found in: {root}")

    rows = sorted(rows, key=lambda x: int(x["step"]))
    out = Path(args.output_csv).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="") as fp:
        w = csv.DictWriter(fp, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    print(f"\nPIMD distribution timeseries saved: {out}")
    print("-" * 60)
    if use_vec and vec is not None:
        axes_str = f"v=({vec[0]:.4f},{vec[1]:.4f},{vec[2]:.4f})"
        final_sigma = float(rows[-1]["sigma_v_A"])
    else:
        axes_str = ",".join(axes)
        final_sigma = float(np.mean([rows[-1][f"sigma_{ax}_A"] for ax in axes]))
    print(
        f"source={source}, dirs={axes_str}, steps={rows[0]['step']}..{rows[-1]['step']} (N={len(rows)}), "
        f"final sigma(mean {axes_str})={final_sigma:.6e} A"
    )
    print(f"input files used: {len(used_files)}")
    if args.list_input_files:
        for p in sorted(set(used_files)):
            print(f"  - {p}")
    print("-" * 60)


def build_pimd_distribution_2d_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(prog="macer util pimd distribution-2d")
    parser.add_argument("--dir", default=".", help=DIR_FALLBACK_HELP)
    parser.add_argument("-i", "--input", default=None, help=INPUT_PATH_NPZ_HELP)
    parser.add_argument("--source", choices=["restart"], default="restart", help="Input source (currently restart only).")
    parser.add_argument("--step", default="latest", help="Step number or 'latest'.")
    parser.add_argument("--plane", choices=["xy", "xz", "yz"], default="xy", help="Projection plane.")
    parser.add_argument(
        "--plane-basis",
        nargs=6,
        type=float,
        metavar=("UX", "UY", "UZ", "VX", "VY", "VZ"),
        default=None,
        help="Custom projection basis vectors (u,v) in Cartesian. Overrides --plane.",
    )
    parser.add_argument("--element", default=None, help="Filter by element symbol.")
    parser.add_argument(
        "--atom-indices",
        nargs="+",
        type=int,
        default=None,
        help="1-based atom indices filter.",
    )
    parser.add_argument(
        "--list-input-files",
        action="store_true",
        help="Print the input restart file used for this analysis.",
    )
    parser.add_argument(
        "--element-colors",
        type=str,
        default=None,
        help="Comma-separated element-color map, e.g. 'H:#0000ff,O:#ff0000'.",
    )
    parser.add_argument("--bins", type=int, default=120, help="Histogram bins per axis.")
    parser.add_argument("--point-size", type=float, default=4.0, help="2D marker size.")
    parser.add_argument("--point-alpha", type=float, default=0.45, help="2D point transparency [0,1].")
    parser.add_argument("--xlim", nargs=2, type=float, default=None, metavar=("XMIN", "XMAX"), help="Manual x-axis range.")
    parser.add_argument("--ylim", nargs=2, type=float, default=None, metavar=("YMIN", "YMAX"), help="Manual y-axis range.")
    parser.add_argument(
        "--axis-range",
        type=float,
        default=None,
        help="Symmetric range for both axes: [-R, R].",
    )
    parser.add_argument("--output", default="pimd_distribution_2d.pdf", help="Output plot path.")
    return parser


def run_pimd_distribution_2d(args) -> None:
    import matplotlib.pyplot as plt

    in_path = _resolve_input_path(args)
    run_dir = in_path if in_path.is_dir() else in_path.parent
    if str(args.source) != "restart":
        raise ValueError("distribution-2d currently supports only `--source restart`.")
    restart_files = _collect_restart_files(in_path)
    if in_path.is_file():
        rst_file = in_path
        step = int(np.load(rst_file, allow_pickle=True).get("step", 0))
    else:
        step = _parse_step_arg(str(args.step), restart_files, "pimd_state_step")
        rst_file = _find_restart_file(run_dir, step=step)
    rst = np.load(rst_file, allow_pickle=True)
    if args.list_input_files:
        print(f"Using restart file: {rst_file}")
    symbols = np.array([str(s) for s in rst["symbols"].tolist()])
    r_bead = np.array(rst["r_bead"], dtype=float)  # (nbead,natom,3)
    pos = r_bead.reshape(-1, 3)
    labels = np.repeat(symbols[None, :], r_bead.shape[0], axis=0).reshape(-1)
    atom_ids = np.repeat((np.arange(symbols.size, dtype=int) + 1)[None, :], r_bead.shape[0], axis=0).reshape(-1)
    if args.element:
        mask = labels == str(args.element)
        if not np.any(mask):
            raise ValueError(f"No samples for element: {args.element}")
        pos = pos[mask]
        labels = labels[mask]
        atom_ids = atom_ids[mask]
    if args.atom_indices:
        idxset = set(int(i) for i in args.atom_indices)
        mask = np.isin(atom_ids, np.array(sorted(idxset), dtype=int))
        if not np.any(mask):
            raise ValueError(f"No samples for atom indices: {sorted(idxset)}")
        pos = pos[mask]
        labels = labels[mask]
    if args.plane_basis is not None:
        basis = np.array(args.plane_basis, dtype=float).reshape(2, 3)
        u = basis[0]
        v = basis[1]
        nu = float(np.linalg.norm(u))
        if nu <= 1.0e-15:
            raise ValueError("Invalid --plane-basis: first basis vector must be non-zero.")
        u = u / nu
        v = v - np.dot(v, u) * u
        nv = float(np.linalg.norm(v))
        if nv <= 1.0e-15:
            raise ValueError("Invalid --plane-basis: second vector must not be parallel to first.")
        v = v / nv
        x = pos @ u
        y = pos @ v
        xlabel = "u (A)"
        ylabel = "v (A)"
        plane_label = "custom"
    else:
        axis = {"xy": (0, 1), "xz": (0, 2), "yz": (1, 2)}[args.plane]
        x = pos[:, axis[0]]
        y = pos[:, axis[1]]
        xlabel = args.plane[0] + " (A)"
        ylabel = args.plane[1] + " (A)"
        plane_label = args.plane

    alpha = float(args.point_alpha)
    if alpha < 0.0 or alpha > 1.0:
        raise ValueError("--point-alpha must be in [0, 1].")
    overrides = _parse_element_colors(getattr(args, "element_colors", None))

    fig = plt.figure(figsize=(5.5, 4.8))
    ax = fig.add_subplot(111)
    species = list(dict.fromkeys(labels.tolist()))
    for sym in species:
        mask = labels == sym
        ax.scatter(
            x[mask],
            y[mask],
            s=float(args.point_size),
            alpha=alpha,
            linewidths=0.0,
            c=[_color_for_element(sym, overrides=overrides)],
            label=str(sym),
        )
    if args.axis_range is not None:
        r = float(args.axis_range)
        if r <= 0:
            raise ValueError("--axis-range must be > 0.")
        ax.set_xlim(-r, r)
        ax.set_ylim(-r, r)
    if args.xlim is not None:
        ax.set_xlim(float(args.xlim[0]), float(args.xlim[1]))
    if args.ylim is not None:
        ax.set_ylim(float(args.ylim[0]), float(args.ylim[1]))
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    title_elem = args.element if args.element else "all"
    ax.set_title(f"PIMD 2D distribution ({title_elem}, {plane_label}, step {step})")
    if len(species) > 1:
        ax.legend(loc="best", frameon=True)
    fig.tight_layout()
    out = Path(args.output).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out)
    plt.close(fig)
    print(f"Wrote 2D distribution plot: {out}")


def build_pimd_distribution_3d_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(prog="macer util pimd distribution-3d")
    parser.add_argument("--dir", default=".", help=DIR_FALLBACK_HELP)
    parser.add_argument("-i", "--input", default=None, help=INPUT_PATH_NPZ_HELP)
    parser.add_argument("--source", choices=["restart"], default="restart", help="Input source (currently restart only).")
    parser.add_argument("--step", default="latest", help="Step number or 'latest'.")
    parser.add_argument("--element", default=None, help="Filter by element symbol.")
    parser.add_argument(
        "--atom-indices",
        nargs="+",
        type=int,
        default=None,
        help="1-based atom indices filter.",
    )
    parser.add_argument(
        "--list-input-files",
        action="store_true",
        help="Print the input restart file used for this analysis.",
    )
    parser.add_argument(
        "--element-colors",
        type=str,
        default=None,
        help="Comma-separated element-color map, e.g. 'H:#0000ff,O:#ff0000'.",
    )
    parser.add_argument("--point-size", type=float, default=2.5, help="3D marker size.")
    parser.add_argument("--point-alpha", type=float, default=0.45, help="3D point transparency [0,1].")
    parser.add_argument("--axis-range", type=float, default=None, help="Symmetric axis range [-R, R].")
    parser.add_argument("--output", default="pimd_distribution_3d.html", help="Output HTML path.")
    return parser


def run_pimd_distribution_3d(args) -> None:
    import plotly.graph_objects as go

    in_path = _resolve_input_path(args)
    run_dir = in_path if in_path.is_dir() else in_path.parent
    if str(args.source) != "restart":
        raise ValueError("distribution-3d currently supports only `--source restart`.")
    restart_files = _collect_restart_files(in_path)
    if in_path.is_file():
        rst_file = in_path
        step = int(np.load(rst_file, allow_pickle=True).get("step", 0))
    else:
        step = _parse_step_arg(str(args.step), restart_files, "pimd_state_step")
        rst_file = _find_restart_file(run_dir, step=step)
    rst = np.load(rst_file, allow_pickle=True)
    if args.list_input_files:
        print(f"Using restart file: {rst_file}")
    symbols = np.array([str(s) for s in rst["symbols"].tolist()])
    cell = np.array(rst["cell"], dtype=float)
    r_bead = np.array(rst["r_bead"], dtype=float)

    inv_cell = np.linalg.inv(cell.T)
    frac = r_bead @ inv_cell
    frac_ref = (r_bead[0][None, :, :]) @ inv_cell
    dfrac = frac - frac_ref
    dfrac -= np.round(dfrac)
    disp = dfrac @ cell

    pts = disp.reshape(-1, 3)
    labels = np.repeat(symbols[None, :], r_bead.shape[0], axis=0).reshape(-1)
    atom_ids = np.repeat((np.arange(symbols.size, dtype=int) + 1)[None, :], r_bead.shape[0], axis=0).reshape(-1)
    if args.element:
        mask = labels == str(args.element)
        if not np.any(mask):
            raise ValueError(f"No samples for element: {args.element}")
        pts = pts[mask]
        labels = labels[mask]
        atom_ids = atom_ids[mask]
    if args.atom_indices:
        idxset = set(int(i) for i in args.atom_indices)
        mask = np.isin(atom_ids, np.array(sorted(idxset), dtype=int))
        if not np.any(mask):
            raise ValueError(f"No samples for atom indices: {sorted(idxset)}")
        pts = pts[mask]
        labels = labels[mask]

    overrides = _parse_element_colors(getattr(args, "element_colors", None))
    alpha = float(args.point_alpha)
    if alpha < 0.0 or alpha > 1.0:
        raise ValueError("--point-alpha must be in [0, 1].")
    fig = go.Figure()
    species = list(dict.fromkeys(labels.tolist()))
    for sym in species:
        mask = labels == sym
        color = _color_for_element(sym, overrides=overrides)
        fig.add_trace(
            go.Scatter3d(
                x=pts[mask, 0],
                y=pts[mask, 1],
                z=pts[mask, 2],
                mode="markers",
                name=str(sym),
                marker=dict(size=float(args.point_size), color=color, opacity=alpha),
            )
        )

    a, b, c = cell[0], cell[1], cell[2]
    corners = []
    for sx in (-0.5, 0.5):
        for sy in (-0.5, 0.5):
            for sz in (-0.5, 0.5):
                corners.append(sx * a + sy * b + sz * c)
    corners = np.array(corners, dtype=float)
    edges = []
    for i in range(8):
        for j in range(i + 1, 8):
            ib = np.array([(i >> k) & 1 for k in range(3)])
            jb = np.array([(j >> k) & 1 for k in range(3)])
            if int(np.sum(np.abs(ib - jb))) == 1:
                edges.append((i, j))
    for i, j in edges:
        fig.add_trace(
            go.Scatter3d(
                x=[corners[i, 0], corners[j, 0]],
                y=[corners[i, 1], corners[j, 1]],
                z=[corners[i, 2], corners[j, 2]],
                mode="lines",
                showlegend=False,
                line=dict(color="black", width=3),
            )
        )

    scene = dict(
        xaxis_title="dx (A)",
        yaxis_title="dy (A)",
        zaxis_title="dz (A)",
        aspectmode="cube",
    )
    if args.axis_range is not None:
        r = float(args.axis_range)
        if r <= 0:
            raise ValueError("--axis-range must be > 0.")
        scene["xaxis"] = dict(range=[-r, r], title="dx (A)")
        scene["yaxis"] = dict(range=[-r, r], title="dy (A)")
        scene["zaxis"] = dict(range=[-r, r], title="dz (A)")

    fig.update_layout(
        title=f"PIMD 3D distribution (step {step})",
        scene=scene,
        legend=dict(x=0.02, y=0.98),
    )
    out = Path(args.output).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.write_html(str(out), include_plotlyjs="cdn")
    print(f"Wrote 3D distribution HTML: {out}")


def build_pimd_anomaly_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(prog="macer util pimd anomaly")
    parser.add_argument("--dir", default=".", help=DIR_FALLBACK_HELP)
    parser.add_argument("-i", "--input", default=None, help=INPUT_PATH_HELP)
    parser.add_argument("--z-threshold", type=float, default=4.0, help="Z-score threshold.")
    parser.add_argument("--output-json", default="pimd-anomaly.json", help="Output JSON path.")
    return parser


def run_pimd_anomaly(args) -> None:
    run_dir = _resolve_input_root(args)
    cols = _load_pimd_csv(str(run_dir / "pimd.csv"))
    report: dict[str, object] = {"run_dir": str(run_dir), "flags": []}
    for key in ["temperature_K", "epot_mean_eV", "ekin_eV", "etot_eV", "fmax_eV_A"]:
        if key not in cols or cols[key].size < 4:
            continue
        arr = cols[key]
        mu = float(np.mean(arr))
        sd = float(np.std(arr))
        if sd <= 0:
            continue
        z = np.abs((arr - mu) / sd)
        idx = np.where(z > float(args.z_threshold))[0]
        if idx.size > 0:
            report["flags"].append(
                {
                    "metric": key,
                    "n_outliers": int(idx.size),
                    "indices": [int(i) for i in idx.tolist()[:20]],
                    "max_z": float(np.max(z)),
                }
            )
    out = Path(args.output_json).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2))
    print(f"Wrote anomaly report: {out}")
    if not report["flags"]:
        print("No anomaly flags above threshold.")


def build_pimd_fc2_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(prog="macer util pimd fc2")
    parser.add_argument("--dir", default=".", help=DIR_FALLBACK_HELP)
    parser.add_argument("-i", "--input", default=None, help=INPUT_PATH_NPZ_HELP)
    parser.add_argument("--poscar", default=None, help="Reference POSCAR. Default: POSCAR_pimd_mean_final in run dir.")
    parser.add_argument("--stride", type=int, default=1, help="Use every N-th restart snapshot.")
    parser.add_argument("--max-samples", type=int, default=None, help="Cap number of samples.")
    parser.add_argument("--nstep", type=int, default=None, help="Use only first N selected trajectories after stride/max-samples.")
    parser.add_argument(
        "--n-traj",
        type=int,
        default=None,
        help="Number of trajectories to extract for force-constant fitting (evenly distributed with random jitter).",
    )
    parser.add_argument(
        "--traj-select-seed",
        type=int,
        default=None,
        help="Random seed for trajectory extraction. Omit for non-deterministic selection.",
    )
    parser.add_argument("--centroid-only", action="store_true", help="Use centroid samples only.")
    parser.add_argument(
        "--fc3",
        action="store_true",
        help="Also fit 3rd-order force constants (FC3) via symfc (FC2 is always generated).",
    )
    parser.add_argument("--symprec", type=float, default=1e-5, help="Symmetry tolerance for phonopy.")
    parser.add_argument(
        "--min-samples",
        type=int,
        default=None,
        help="Minimum required sample count for FC2 fit. Default: max(3N, 100).",
    )
    parser.add_argument(
        "--max-cond",
        type=float,
        default=1e10,
        help="Maximum allowed condition number of displacement matrix U.",
    )
    parser.add_argument(
        "--asr",
        dest="asr",
        action="store_true",
        default=True,
        help="Enforce acoustic sum rule (translational invariance) on FC2 (default: on).",
    )
    parser.add_argument(
        "--no-asr",
        dest="asr",
        action="store_false",
        help="Disable acoustic sum rule enforcement on FC2.",
    )
    parser.add_argument("--output-force-constants", default="FORCE_CONSTANTS_PIMD", help="Output FORCE_CONSTANTS path.")
    parser.add_argument("--output-fc3-hdf5", default="fc3.hdf5", help="Output fc3.hdf5 path (used with --fc3).")
    parser.add_argument("--output-log", default="fc2_fit_metrics.log", help="Output force-constant diagnostic log path.")
    parser.add_argument("--output-metrics", dest="output_log", help=argparse.SUPPRESS)
    return parser


def build_pimd_force_constant_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    """Alias parser for `macer util pimd force-constant`."""
    return build_pimd_fc2_parser(parser)


def run_pimd_fc2(args) -> None:
    from phonopy import Phonopy
    from phonopy.file_IO import write_FORCE_CONSTANTS
    from phonopy.harmonic.force_constants import set_translational_invariance
    from phonopy.structure.atoms import PhonopyAtoms
    from ase import Atoms as AseAtoms

    BOHR_TO_ANG = 0.529177249
    FORCE_AU_TO_EV_ANG = 51.422067

    def _select_even_jitter_indices(
        n_total: int,
        n_target: int,
        seed: int | None = None,
    ) -> list[int]:
        if n_target >= n_total:
            return list(range(n_total))
        if n_target <= 0:
            return []
        rng = np.random.default_rng(seed)
        edges = np.linspace(0, n_total, n_target + 1, dtype=int)
        selected: list[int] = []
        used: set[int] = set()
        for i in range(n_target):
            lo = int(edges[i])
            hi = int(max(edges[i + 1], lo + 1))
            hi = min(hi, n_total)
            candidates = [k for k in range(lo, hi) if k not in used]
            if not candidates:
                candidates = [k for k in range(n_total) if k not in used]
            pick = int(rng.choice(candidates))
            selected.append(pick)
            used.add(pick)
        selected.sort()
        return selected

    def _symbols_from_coor_xyz(run_dir_local: Path, natom_local: int) -> list[str] | None:
        xyz_path = run_dir_local / "coor.xyz"
        if not xyz_path.exists():
            return None
        try:
            with xyz_path.open("r") as fp:
                first_line = fp.readline().strip()
                if not first_line:
                    return None
                nline = int(first_line)
                fp.readline()  # step/comment line
                if nline < natom_local:
                    return None
                syms: list[str] = []
                for _ in range(natom_local):
                    row = fp.readline().split()
                    if not row:
                        return None
                    syms.append(str(row[0]))
                return syms if len(syms) == natom_local else None
        except Exception:
            return None

    def _extract_bead_rf(npz_path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray | None, list[str] | None]:
        d = np.load(npz_path, allow_pickle=True)
        schema_local = None
        if "schema_version" in d:
            try:
                schema_local = str(np.array(d["schema_version"]).reshape(()).item())
            except Exception:
                schema_local = str(d["schema_version"])
        symbols_local: list[str] | None = None
        if "symbols" in d:
            symbols_local = [str(s) for s in np.array(d["symbols"]).tolist()]

        cell_local = None
        if "cell" in d:
            cell_raw = np.array(d["cell"], dtype=float)
            if cell_raw.ndim == 3:
                cell_raw = cell_raw[0]
            # restart.npz stores cell in Bohr; pimd_state_step*.npz typically Angstrom
            if "r" in d:
                cell_local = cell_raw * BOHR_TO_ANG
            else:
                cell_local = cell_raw

        if "r_bead" in d:
            r_bead = np.array(d["r_bead"], dtype=float)  # Angstrom
            if r_bead.ndim == 4:
                # history-like [nstep, nbead, natom, 3] -> take latest
                r_bead = r_bead[-1]
            if "f_bead" in d:
                f_bead = np.array(d["f_bead"], dtype=float)
                if f_bead.ndim == 4:
                    f_bead = f_bead[-1]
                return r_bead, f_bead, cell_local, symbols_local
            raise ValueError(
                f"{npz_path.name} has r_bead but no f_bead; cannot build FC2 from coordinates-only snapshots "
                f"(schema={schema_local})."
            )

        if "r" in d and "fr" in d:
            # restart.npz from pimd: [3, natom, nbead] in Bohr and Hartree/Bohr per bead/nbead
            r_internal = np.array(d["r"], dtype=float)
            fr_internal = np.array(d["fr"], dtype=float)
            if r_internal.ndim != 3 or fr_internal.ndim != 3 or r_internal.shape != fr_internal.shape:
                raise ValueError(
                    f"Unsupported r/fr shape in {npz_path} (schema={schema_local}). "
                    "Check restart.npz schema/shape integrity."
                )
            r_bead = np.transpose(r_internal, (2, 1, 0)) * BOHR_TO_ANG
            f_bead = np.transpose(fr_internal, (2, 1, 0)) * FORCE_AU_TO_EV_ANG
            # state.fr is stored with 1/nbead scaling in pimd integrator; recover physical per-bead forces.
            nbead_scale = float(r_internal.shape[2])
            f_bead = f_bead * nbead_scale
            if schema_local is not None:
                print(f"[pimd] Info: FC2 loader fallback via r/fr path ({npz_path.name}, schema={schema_local}).")
            return r_bead, f_bead, cell_local, symbols_local

        raise ValueError(
            f"Unsupported NPZ snapshot format: {npz_path} "
            f"(expected r_bead/f_bead or r/fr arrays; schema={schema_local})."
        )

    def _write_fc2_log(path: Path, payload: dict) -> None:
        lines = ["# FC2 fit diagnostics"]
        for key in sorted(payload.keys()):
            val = payload[key]
            lines.append(f"{key}: {val}")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("\n".join(lines) + "\n")

    def _gamma_acoustic_stats(ph_local: Phonopy) -> tuple[list[float], float]:
        ph_local.run_qpoints([[0.0, 0.0, 0.0]])
        qd = ph_local.get_qpoints_dict()
        freqs = np.array(qd["frequencies"][0], dtype=float)
        if freqs.size < 3:
            return [], float("nan")
        # Acoustic-like branches at Gamma are the three smallest |freq|.
        idx = np.argsort(np.abs(freqs))
        ac = [float(freqs[i]) for i in idx[:3]]
        max_abs = float(np.max(np.abs(np.array(ac, dtype=float))))
        return ac, max_abs

    if getattr(args, "input", None):
        in_path = _resolve_input_path(args)
    else:
        run_dir_default = Path(str(getattr(args, "dir", "."))).expanduser().resolve()
        default_history = run_dir_default / "pimd_state_history.npz"
        if not default_history.exists():
            raise FileNotFoundError(
                f"Default FC2 input not found: {default_history}\n"
                "Provide -i/--input explicitly or run PIMD first to generate pimd_state_history.npz."
            )
        in_path = default_history
    run_dir = in_path if in_path.is_dir() else in_path.parent

    history_payload = None
    history_frame_indices: list[int] | None = None
    history_total_frames: int | None = None
    ntraj_candidate: int | None = None

    if in_path.is_file() and in_path.name == "pimd_state_history.npz":
        d_hist = np.load(in_path, allow_pickle=True)
        if "r_bead" not in d_hist or "f_bead" not in d_hist:
            raise ValueError(f"{in_path} does not contain r_bead/f_bead arrays.")
        r_hist = np.array(d_hist["r_bead"], dtype=float)
        f_hist = np.array(d_hist["f_bead"], dtype=float)
        if r_hist.ndim != 4 or f_hist.ndim != 4:
            raise ValueError(
                f"{in_path} is expected to store history tensors with shape "
                "[ntraj, nbead, natom, 3], got r_bead={r_hist.shape}, f_bead={f_hist.shape}."
            )
        if r_hist.shape[0] != f_hist.shape[0]:
            raise ValueError(
                f"{in_path} r_bead/f_bead trajectory count mismatch: "
                f"{r_hist.shape[0]} vs {f_hist.shape[0]}."
            )
        history_total_frames = int(r_hist.shape[0])
        stride = max(int(args.stride), 1)
        frame_indices = list(range(0, history_total_frames, stride))
        if args.max_samples is not None:
            frame_indices = frame_indices[: int(args.max_samples)]
        if args.nstep is not None:
            nstep_int = int(args.nstep)
            if nstep_int < 1:
                raise ValueError("--nstep must be >= 1 when provided.")
            frame_indices = frame_indices[:nstep_int]
        n_traj_req = int(getattr(args, "n_traj", 0) or 0)
        candidate_count = int(len(frame_indices))
        ntraj_candidate = candidate_count
        if n_traj_req > 0 and candidate_count > 0:
            if candidate_count <= n_traj_req:
                print(
                    f"[pimd] Force-constant trajectory extraction requested n_traj={n_traj_req}, "
                    f"but only {candidate_count} candidate trajectories are available; using all."
                )
            else:
                rel_idx = _select_even_jitter_indices(
                    n_total=candidate_count,
                    n_target=n_traj_req,
                    seed=getattr(args, "traj_select_seed", None),
                )
                frame_indices = [frame_indices[i] for i in rel_idx]
        if not frame_indices:
            raise ValueError("No trajectories selected from pimd_state_history.npz after stride/max-samples filtering.")
        history_payload = d_hist
        history_frame_indices = frame_indices
        restart_files = [in_path]
        print(
            f"[pimd] Force-constant source: {in_path.name} trajectories(total)={history_total_frames}, "
            f"trajectories(candidates)={candidate_count}, trajectories(used)={len(frame_indices)} (stride={stride}"
            + (f", max_samples={int(args.max_samples)}" if args.max_samples is not None else "")
            + (f", nstep={int(args.nstep)}" if args.nstep is not None else "")
            + (f", n_traj={n_traj_req}" if n_traj_req > 0 else "")
            + (
                f", traj_select_seed={int(args.traj_select_seed)}"
                if (n_traj_req > 0 and getattr(args, "traj_select_seed", None) is not None)
                else ""
            )
            + ")."
        )
    else:
        restart_files = _collect_restart_files(in_path)
        if not restart_files:
            raise FileNotFoundError(f"No restart snapshots found in {run_dir}")
        restart_files = restart_files[:: max(int(args.stride), 1)]
        if args.max_samples is not None:
            restart_files = restart_files[: int(args.max_samples)]
        if args.nstep is not None:
            nstep_int = int(args.nstep)
            if nstep_int < 1:
                raise ValueError("--nstep must be >= 1 when provided.")
            restart_files = restart_files[:nstep_int]
        n_traj_req = int(getattr(args, "n_traj", 0) or 0)
        candidate_count = int(len(restart_files))
        ntraj_candidate = candidate_count
        if n_traj_req > 0 and candidate_count > 0:
            if candidate_count <= n_traj_req:
                print(
                    f"[pimd] Force-constant trajectory extraction requested n_traj={n_traj_req}, "
                    f"but only {candidate_count} candidate snapshots are available; using all."
                )
            else:
                rel_idx = _select_even_jitter_indices(
                    n_total=candidate_count,
                    n_target=n_traj_req,
                    seed=getattr(args, "traj_select_seed", None),
                )
                restart_files = [restart_files[i] for i in rel_idx]
        if not restart_files:
            raise ValueError("No restart files selected after stride/max-samples filtering.")
        print(
            f"[pimd] Force-constant source: restart snapshots candidates={candidate_count}, used={len(restart_files)}"
            + (f" (nstep={int(args.nstep)})" if args.nstep is not None else "")
            + (f" (n_traj={n_traj_req})" if n_traj_req > 0 else "")
            + (
                f", traj_select_seed={int(args.traj_select_seed)}"
                if (n_traj_req > 0 and getattr(args, "traj_select_seed", None) is not None)
                else ""
            )
            + "."
        )

    displacements = []
    forces = []
    ref = None
    ref_cell = None
    ref_symbols = None
    if history_payload is not None and history_frame_indices is not None:
        r_hist = np.array(history_payload["r_bead"], dtype=float)
        f_hist = np.array(history_payload["f_bead"], dtype=float)
        cell_hist = None
        if "cell" in history_payload:
            cell_hist = np.array(history_payload["cell"], dtype=float)
        symbols_hist = None
        if "symbols" in history_payload:
            symbols_hist = [str(s) for s in np.array(history_payload["symbols"]).tolist()]
        for iframe in history_frame_indices:
            r_bead = r_hist[iframe]
            f_bead = f_hist[iframe]
            cell_local = None
            if cell_hist is not None:
                if cell_hist.ndim == 3 and cell_hist.shape[0] == r_hist.shape[0]:
                    cell_local = cell_hist[iframe]
                elif cell_hist.ndim == 2:
                    cell_local = cell_hist
            if ref is None:
                ref = np.mean(r_bead, axis=0)
                ref_cell = cell_local
                ref_symbols = symbols_hist
            if args.centroid_only:
                displacements.append(np.mean(r_bead, axis=0) - ref)
                forces.append(np.mean(f_bead, axis=0))
            else:
                for b in range(r_bead.shape[0]):
                    displacements.append(r_bead[b] - ref)
                    forces.append(f_bead[b])
    else:
        for f in restart_files:
            r_bead, f_bead, cell_local, symbols_local = _extract_bead_rf(f)
            if ref is None:
                ref = np.mean(r_bead, axis=0)
                ref_cell = cell_local
                ref_symbols = symbols_local
            if args.centroid_only:
                displacements.append(np.mean(r_bead, axis=0) - ref)
                forces.append(np.mean(f_bead, axis=0))
            else:
                for b in range(r_bead.shape[0]):
                    displacements.append(r_bead[b] - ref)
                    forces.append(f_bead[b])

    if ref is None:
        raise ValueError("Failed to construct FC2 dataset from selected restart files.")

    poscar = Path(args.poscar).expanduser().resolve() if args.poscar else (run_dir / "POSCAR_pimd_mean_final")
    atoms = None
    if poscar.exists():
        atoms = read(str(poscar))
    else:
        if ref_cell is None:
            raise FileNotFoundError(
                f"Reference POSCAR not found: {poscar} and NPZ does not contain cell information."
            )
        if ref_symbols is None:
            ref_symbols = _symbols_from_coor_xyz(run_dir, int(ref.shape[0]))
        if ref_symbols is None or len(ref_symbols) != int(ref.shape[0]):
            ref_symbols = ["X"] * int(ref.shape[0])
        atoms = AseAtoms(symbols=ref_symbols, positions=ref, cell=ref_cell, pbc=True)
        print(f"[pimd] Info: POSCAR missing; using NPZ-derived reference structure (symbols from coor.xyz if available).")

    unit = PhonopyAtoms(
        symbols=atoms.get_chemical_symbols(),
        cell=np.array(atoms.cell, dtype=float),
        scaled_positions=atoms.get_scaled_positions(),
    )
    ph = Phonopy(unit, np.eye(3, dtype=int), symprec=float(args.symprec))

    U = np.array(displacements, dtype=float)
    F = np.array(forces, dtype=float)

    ndof = int(U.shape[1] * U.shape[2]) if U.ndim == 3 else int(U.shape[1])
    nsamples = int(U.shape[0])
    if history_payload is not None and history_frame_indices is not None:
        ntraj_used = int(len(history_frame_indices))
        ntraj_total = int(history_total_frames or ntraj_used)
    else:
        ntraj_used = int(len(restart_files))
        ntraj_total = int(len(restart_files))
    order_label = "FC3" if bool(getattr(args, "fc3", False)) else "FC2"
    print(
        f"[pimd] {order_label} dataset: trajectories(total)={ntraj_total}, trajectories(used)={ntraj_used}, "
        f"samples_used_by_symfc={nsamples} (centroid_only={bool(args.centroid_only)})."
    )
    Uflat = U.reshape(nsamples, ndof)
    rank_u = int(np.linalg.matrix_rank(Uflat))
    sv = np.linalg.svd(Uflat, compute_uv=False)
    positive_sv = sv[sv > max(np.finfo(float).eps * max(Uflat.shape), 1e-15)]
    cond_u = float(positive_sv[0] / positive_sv[-1]) if positive_sv.size >= 2 else float("inf")
    min_samples_required = int(args.min_samples) if getattr(args, "min_samples", None) else int(max(ndof, 100))
    rank_required = int(min(max(nsamples - 1, 1), max(ndof - 3, 1)))
    max_cond_allowed = float(getattr(args, "max_cond", 1e10))

    metrics = {
        "run_dir": str(run_dir),
        "poscar": str(poscar),
        "n_restart_files": int(len(restart_files)),
        "n_traj_total": ntraj_total,
        "n_traj_candidates": int(ntraj_candidate if ntraj_candidate is not None else ntraj_total),
        "n_traj_used": ntraj_used,
        "n_samples": nsamples,
        "fc_order": 3 if bool(getattr(args, "fc3", False)) else 2,
        "n_atoms": int(U.shape[1]),
        "n_dof": ndof,
        "centroid_only": bool(args.centroid_only),
        "symprec": float(args.symprec),
        "u_rank": rank_u,
        "u_rank_required": rank_required,
        "u_cond": cond_u,
        "max_cond_allowed": max_cond_allowed,
        "min_samples_required": min_samples_required,
        "force_rms_eV_A": float(np.sqrt(np.mean(F * F))),
        "disp_rms_A": float(np.sqrt(np.mean(U * U))),
        "asr_enabled": bool(getattr(args, "asr", True)),
    }
    out_log = Path(args.output_log).expanduser().resolve()
    guardrail_failures = []
    if nsamples < min_samples_required:
        guardrail_failures.append(
            f"n_samples={nsamples} < min_samples_required={min_samples_required}"
        )
    if rank_u < rank_required:
        guardrail_failures.append(
            f"u_rank={rank_u} < u_rank_required={rank_required}"
        )
    if not np.isfinite(cond_u) or cond_u > max_cond_allowed:
        guardrail_failures.append(
            f"u_cond={cond_u:.6e} > max_cond_allowed={max_cond_allowed:.6e}"
        )
    metrics["guardrail_failures"] = guardrail_failures
    if guardrail_failures:
        metrics["guardrail_status"] = "warn"
    else:
        metrics["guardrail_status"] = "passed"

    fc_solver = "symfc"
    fc_solver_log_level = 2

    ph.dataset = {"displacements": U, "forces": F}
    if hasattr(ph, "_log_level"):
        try:
            ph._log_level = fc_solver_log_level
        except Exception:
            pass
    print(f"FC solver selected: {fc_solver}")
    print(f"FC solver log level: {fc_solver_log_level}")
    ph.produce_force_constants(fc_calculator=fc_solver)
    if ph.force_constants is None:
        raise RuntimeError("symfc failed to produce force constants.")
    fc2_raw = np.array(ph.force_constants, dtype=float, copy=True)
    ph.force_constants = fc2_raw
    gamma_before, gamma_before_max_abs = _gamma_acoustic_stats(ph)
    metrics["gamma_acoustic_before_thz"] = gamma_before
    metrics["gamma_acoustic_before_max_abs_thz"] = gamma_before_max_abs

    if bool(getattr(args, "asr", True)):
        fc2_asr = np.array(fc2_raw, dtype=float, copy=True)
        set_translational_invariance(fc2_asr)
        ph.force_constants = fc2_asr
    gamma_after, gamma_after_max_abs = _gamma_acoustic_stats(ph)
    metrics["gamma_acoustic_after_thz"] = gamma_after
    metrics["gamma_acoustic_after_max_abs_thz"] = gamma_after_max_abs

    out_fc = Path(args.output_force_constants).expanduser().resolve()
    out_fc.parent.mkdir(parents=True, exist_ok=True)
    write_FORCE_CONSTANTS(ph.force_constants, filename=str(out_fc))

    metrics["output_force_constants"] = str(out_fc)
    if bool(getattr(args, "fc3", False)):
        try:
            from phono3py import Phono3py
            from phono3py.file_IO import write_fc3_to_hdf5
        except Exception as exc:
            raise RuntimeError("FC3 mode requires phono3py. Install phono3py and retry.") from exc
        ph3 = Phono3py(
            unitcell=unit,
            supercell_matrix=np.eye(3, dtype=int),
            primitive_matrix=np.eye(3, dtype=int),
            symprec=float(args.symprec),
        )
        ph3.dataset = {"displacements": U, "forces": F}
        if hasattr(ph3, "_log_level"):
            try:
                ph3._log_level = fc_solver_log_level
            except Exception:
                pass
        ph3.produce_fc3(fc_calculator=fc_solver, fc_calculator_options=None)
        if ph3.fc3 is None:
            raise RuntimeError("symfc failed to produce FC3.")
        out_fc3 = Path(args.output_fc3_hdf5).expanduser().resolve()
        out_fc3.parent.mkdir(parents=True, exist_ok=True)
        write_fc3_to_hdf5(ph3.fc3, filename=str(out_fc3))
        metrics["output_fc3_hdf5"] = str(out_fc3)
        print(f"Wrote FC3: {out_fc3}")

    _write_fc2_log(out_log, metrics)
    print(f"Wrote FC2: {out_fc}")
    print(f"Wrote log: {out_log}")


def run_pimd_force_constant(args) -> None:
    """Alias runner for `macer util pimd force-constant`."""
    return run_pimd_fc2(args)
