import argparse
import json
from pathlib import Path

import numpy as np


def build_sscha_export_dataset_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(
            prog="macer util sscha export-dataset",
            description="Export SSCHA cycle snapshots to analysis-friendly formats.",
        )
    parser.add_argument("--dir", required=True, help="SSCHA output directory.")
    parser.add_argument("--cycles", nargs="+", type=int, default=None, help="Cycle indices to export (default: all).")
    parser.add_argument("--format", choices=["npz", "csv"], default="npz", help="Export format (default: npz).")
    parser.add_argument("--output", default="sscha_export", help="Output prefix (default: sscha_export).")
    return parser


def run_sscha_export_dataset(args):
    run_dir = Path(args.dir).expanduser().resolve()
    cycles = _resolve_cycles(run_dir, args.cycles)
    out_prefix = Path(args.output).expanduser().resolve()

    exported = []
    for c in cycles:
        cdir = run_dir / f"cycle_{c:03d}"
        U = _load_saved_array(cdir / "U")
        F = _load_saved_array(cdir / "F")
        E = _load_saved_array(cdir / "E").reshape(-1)
        out_stem = Path(f"{out_prefix}_cycle_{c:03d}")
        if args.format == "npz":
            np.savez_compressed(f"{out_stem}.npz", U=U, F=F, E=E)
            exported.append(str(out_stem) + ".npz")
        else:
            # CSV export as per-snapshot summary table.
            import csv

            disp_rms = np.sqrt(np.mean(U**2, axis=(1, 2)))
            force_rms = np.sqrt(np.mean(F**2, axis=(1, 2)))
            with open(f"{out_stem}.csv", "w", newline="") as f:
                w = csv.writer(f)
                w.writerow(["snapshot_index", "energy_eV", "disp_rms_A", "force_rms_eV_per_A"])
                for i in range(len(E)):
                    w.writerow([i + 1, float(E[i]), float(disp_rms[i]), float(force_rms[i])])
            exported.append(str(out_stem) + ".csv")

    print("SSCHA Export Dataset")
    print("-" * 72)
    print(f"Cycles exported: {cycles}")
    for p in exported:
        print(f"  - {p}")

    return {"run_dir": str(run_dir), "cycles": cycles, "format": args.format, "outputs": exported}


def _resolve_cycles(run_dir: Path, cycles):
    if cycles:
        return sorted(set(int(c) for c in cycles))
    out = []
    for p in run_dir.glob("cycle_*"):
        if p.is_dir():
            try:
                out.append(int(p.name.split("_")[1]))
            except Exception:
                continue
    return sorted(out)


def _load_saved_array(stem: Path):
    npy = Path(f"{stem}.npy")
    if npy.exists():
        return np.load(npy)
    dat = Path(f"{stem}.dat")
    if not dat.exists():
        raise FileNotFoundError(f"missing both {npy} and {dat}")
    with dat.open("r") as f:
        first = f.readline().strip()
    if not first.startswith("# shape "):
        raise ValueError(f"Missing shape header in {dat}")
    shape = tuple(int(x) for x in first.replace("#", "").split()[1:])
    raw = np.loadtxt(dat, comments="#")
    if len(shape) == 1:
        if np.ndim(raw) == 1:
            return np.array([float(raw[-1])], dtype=float)
        return np.asarray(raw[:, -1], dtype=float)
    return np.atleast_2d(raw).reshape(shape)
