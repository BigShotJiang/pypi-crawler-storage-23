import argparse
import json
from pathlib import Path

import numpy as np


def build_sscha_weights_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(
            prog="macer util sscha weights",
            description="Rebuild and diagnose SSCHA reweighting weights from saved log-probability files.",
        )
    parser.add_argument("--dir", required=True, help="SSCHA output directory.")
    parser.add_argument("--cycle", type=int, required=True, help="Cycle index providing logp_origin.")
    parser.add_argument("--target-cycle", type=int, default=None, help="Cycle index for logp_current (default: same as --cycle).")
    parser.add_argument("--top-k", type=int, default=10, help="Show top-K highest weights (default: 10).")
    parser.add_argument("--save-dat", default=None, help="Optional output .dat path for rebuilt weights.")
    parser.add_argument("--json-out", default=None, help="Optional JSON output path.")
    return parser


def run_sscha_weights(args):
    run_dir = Path(args.dir).expanduser().resolve()
    cyc = int(args.cycle)
    tgt = int(args.target_cycle if args.target_cycle is not None else args.cycle)
    cdir = run_dir / f"cycle_{cyc:03d}"
    if not cdir.exists():
        raise FileNotFoundError(f"Cycle directory not found: {cdir}")

    logp_origin = _load_saved_array(cdir / "logp_origin").reshape(-1)
    logp_current = _load_saved_array(cdir / f"logp_current_cycle_{tgt:03d}").reshape(-1)
    if logp_origin.shape != logp_current.shape:
        raise ValueError(f"logp shape mismatch: origin={logp_origin.shape} current={logp_current.shape}")

    logw = logp_current - logp_origin
    if not np.all(np.isfinite(logw)):
        raise ValueError("non-finite log-weights encountered")
    shift = float(np.max(logw))
    w = np.exp(logw - shift)
    s = float(np.sum(w))
    if (not np.isfinite(s)) or s <= 0:
        raise ValueError("invalid weight sum")
    w /= s

    ess = 1.0 / float(np.sum(w**2))
    entropy = -float(np.sum(w * np.log(np.clip(w, 1e-300, None))))
    n = int(len(w))
    ess_ratio = ess / float(n)

    idx_top = np.argsort(-w)[: max(1, int(args.top_k))]
    top_entries = [{"index": int(i + 1), "weight": float(w[i])} for i in idx_top]
    max_w = float(np.max(w))
    min_w = float(np.min(w))
    collapse_level = "severe" if ess_ratio < 0.05 else ("moderate" if ess_ratio < 0.2 else "healthy")

    report = {
        "run_dir": str(run_dir),
        "cycle": cyc,
        "target_cycle": tgt,
        "n_snapshots": n,
        "ess": float(ess),
        "ess_ratio": float(ess_ratio),
        "entropy": float(entropy),
        "max_weight": max_w,
        "min_weight": min_w,
        "collapse_level": collapse_level,
        "top_weights": top_entries,
    }

    print("SSCHA Weights Report")
    print("-" * 72)
    print(f"Cycle/Target   : {cyc} -> {tgt}")
    print(f"Snapshots      : {n}")
    print(f"ESS            : {ess:.6f}")
    print(f"ESS ratio      : {ess_ratio:.6f}")
    print(f"Entropy        : {entropy:.6f}")
    print(f"Max/Min weight : {max_w:.6e} / {min_w:.6e}")
    print(f"Collapse level : {collapse_level}")
    print("Top weights:")
    for t in top_entries:
        print(f"  - idx={t['index']:5d}  w={t['weight']:.6e}")

    if args.save_dat:
        out = Path(args.save_dat).expanduser().resolve()
        arr = np.column_stack((np.arange(1, n + 1, dtype=int), w))
        np.savetxt(out, arr, fmt=["%d", "%.16e"], header="snapshot_index weight")
        print(f"Wrote weights dat: {out}")

    if args.json_out:
        out = Path(args.json_out).expanduser().resolve()
        out.write_text(json.dumps(report, indent=2))
        print(f"Wrote JSON: {out}")

    return report


def _load_saved_array(stem: Path):
    npy = Path(f"{stem}.npy")
    if npy.exists():
        return np.load(npy)
    dat = Path(f"{stem}.dat")
    if not dat.exists():
        raise FileNotFoundError(f"missing both {npy} and {dat}")
    with dat.open("r") as f:
        first = f.readline().strip()
    if not first.startswith("# shape "):
        raise ValueError(f"Missing shape header in {dat}")
    shape = tuple(int(x) for x in first.replace("#", "").split()[1:])
    raw = np.loadtxt(dat, comments="#")
    if len(shape) == 1:
        if np.ndim(raw) == 1:
            return np.array([float(raw[-1])], dtype=float)
        return np.asarray(raw[:, -1], dtype=float)
    return np.atleast_2d(raw).reshape(shape)
