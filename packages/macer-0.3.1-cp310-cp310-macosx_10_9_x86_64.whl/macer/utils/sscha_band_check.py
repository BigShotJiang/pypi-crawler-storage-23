import argparse
import json
from pathlib import Path

import numpy as np


def build_sscha_band_check_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(
            prog="macer util sscha band-check",
            description="Quick diagnostics for saved SSCHA band outputs (imaginary modes, min frequency).",
        )
    parser.add_argument("--dir", required=True, help="SSCHA output directory.")
    parser.add_argument("--tags", nargs="+", default=["harmonic", "final"], help="Band tags to check (default: harmonic final).")
    parser.add_argument("--json-out", default=None, help="Optional JSON output.")
    return parser


def run_sscha_band_check(args):
    run_dir = Path(args.dir).expanduser().resolve()
    tags = list(args.tags)
    results = []
    for tag in tags:
        dat = _resolve_band_dat(run_dir, tag)
        if dat is None:
            results.append({"tag": tag, "status": "missing"})
            continue
        freqs = _extract_freq_columns(dat)
        if freqs.size == 0:
            results.append({"tag": tag, "status": "unparsed", "path": str(dat)})
            continue
        min_f = float(np.min(freqs))
        n_imag = int(np.sum(freqs < 0.0))
        frac_imag = float(n_imag / freqs.size)
        results.append(
            {
                "tag": tag,
                "status": "ok",
                "path": str(dat),
                "min_freq_thz": min_f,
                "n_points": int(freqs.size),
                "n_imaginary": n_imag,
                "imaginary_fraction": frac_imag,
            }
        )

    print("SSCHA Band Check")
    print("-" * 72)
    for r in results:
        if r["status"] != "ok":
            print(f"{r['tag']:>10s}: {r['status']}")
            continue
        print(
            f"{r['tag']:>10s}: min_f={r['min_freq_thz']:.6f} THz, "
            f"imag={r['n_imaginary']}/{r['n_points']} ({100*r['imaginary_fraction']:.2f}%)"
        )

    report = {"run_dir": str(run_dir), "results": results}
    if args.json_out:
        out = Path(args.json_out).expanduser().resolve()
        out.write_text(json.dumps(report, indent=2))
        print(f"Wrote JSON: {out}")
    return report


def _resolve_band_dat(run_dir: Path, tag: str):
    if tag == "latest":
        p = run_dir / "band.dat"
        return p if p.exists() else None
    cands = list(run_dir.glob(f"band-*_{tag}.dat"))
    if cands:
        return sorted(cands)[-1]
    p = run_dir / f"band-{tag}.dat"
    if p.exists():
        return p
    return None


def _extract_freq_columns(path: Path):
    arr = np.loadtxt(path, comments="#")
    arr = np.atleast_2d(arr)
    if arr.shape[1] <= 1:
        return np.array([], dtype=float)
    # Heuristic: first col is path coordinate, rest are frequencies.
    return arr[:, 1:].reshape(-1)
