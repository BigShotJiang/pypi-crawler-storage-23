from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from ase.io import read, write, iread
from ase import Atoms
import yaml
try:
    from numba import njit
    _HAS_NUMBA = True
except Exception:
    njit = None
    _HAS_NUMBA = False

# Constants
KB_J = 1.380649e-23     # Boltzmann constant in J/K
E_CHARGE = 1.60217663e-19 # Elementary charge in C
ANGSTROM = 1e-10        # m


if _HAS_NUMBA:
    @njit(cache=True)
    def _unwrap_fractional_numba(frac_coords):
        n_steps, n_atoms, _ = frac_coords.shape
        out = np.zeros_like(frac_coords)
        out[0, :, :] = frac_coords[0, :, :]
        for i in range(1, n_steps):
            diff = frac_coords[i, :, :] - frac_coords[i - 1, :, :]
            diff -= np.round(diff)
            out[i, :, :] = out[i - 1, :, :] + diff
        return out

def traj2xdatcar(traj_path: str, out_path: str = "XDATCAR", interval: int = 1):
    """
    Convert an ASE .traj file to a VASP XDATCAR file, 
    supporting variable cell (NPT) with full header repetition for each frame.
    Configuration numbers reflect the actual MD steps based on the interval.
    """
    traj_file = Path(traj_path)
    if not traj_file.exists():
        print(f"Error: Trajectory file '{traj_path}' not found.")
        return False
    
    print(f"Reading trajectory: {traj_path} (Interval: {interval})...")
    try:
        configs = list(iread(str(traj_file)))
        if not configs:
            print("Warning: Trajectory is empty.")
            return False
        
        print(f"Loaded {len(configs)} frames.")
        
        # Determine species and counts once
        atoms0 = configs[0]
        symbols = atoms0.get_chemical_symbols()
        species = list(dict.fromkeys(symbols))
        counts = [symbols.count(s) for s in species]
        # Use simple species list for system name to avoid "Al4"
        system_name = "".join(species)

        # Manual XDATCAR writing to match standard VASP format
        with open(out_path, 'w') as f:
            # --- Global Header (Once) ---
            atoms0 = configs[0]
            symbols = atoms0.get_chemical_symbols()
            species = list(dict.fromkeys(symbols))
            counts = [symbols.count(s) for s in species]
            system_name = "".join(species)

            f.write(f"{system_name}\n")
            f.write("    1.000000\n")
            # Initial lattice (placeholder, required by format)
            for vec in atoms0.cell:
                f.write(f"     {vec[0]:11.6f} {vec[1]:11.6f} {vec[2]:11.6f}\n")
            f.write(" " + " ".join(f"{s:>2}" for s in species) + "\n")
            f.write(" " + " ".join(f"{c:16d}" for c in counts) + "\n")

            # --- Frames ---
            for i, atoms in enumerate(configs):
                current_step = i * interval + 1
                
                # Write Lattice for every frame (standard for variable cell MD)
                # But skip for step 1 as it's already in the header
                if current_step > 1:
                    f.write(f"{system_name}\n")
                    f.write("    1.000000\n")
                    for vec in atoms.cell:
                        f.write(f"     {vec[0]:11.6f} {vec[1]:11.6f} {vec[2]:11.6f}\n")
                    f.write(" " + " ".join(f"{s:>2}" for s in species) + "\n")
                    f.write(" " + " ".join(f"{c:16d}" for c in counts) + "\n")
                
                f.write(f"Direct configuration= {current_step:5d}\n")
                scaled_pos = atoms.get_scaled_positions(wrap=True)
                for pos in scaled_pos:
                    f.write(f"   {pos[0]:.8f}   {pos[1]:.8f}   {pos[2]:.8f}\n")
                    
        print(f"Successfully converted {traj_path} -> {out_path}")
        return True
    except Exception as e:
        print(f"Error during conversion: {e}")
        return False

def print_md_summary(csv_path: str):
    """Print a statistical summary of the md.csv file."""
    import pandas as pd
    csv_file = Path(csv_path)
    if not csv_file.exists():
        print(f"Error: CSV file '{csv_path}' not found.")
        return
    
    try:
        df = pd.read_csv(csv_path)
        print(f"\nMD Statistical Summary for: {csv_path}")
        print("-" * 50)
        # Check available columns
        available = df.columns.tolist()
        cols = ['T_K', 'P_GPa', 'Epot_eV', 'Etot_eV', 'Vol_A3']
        cols = [c for c in cols if c in available]
        
        summary = df[cols].describe().loc[['mean', 'std', 'min', 'max']]
        print(summary.to_string())
        print("-" * 50)
    except Exception as e:
        print(f"Error reading CSV for summary: {e}")

def plot_md_thermo(csv_path: str, output_path: str = "md_thermo.pdf"):
    """Plot T, Epot, and P from md.csv."""
    import pandas as pd
    try:
        df = pd.read_csv(csv_path)
        if 'time_fs' in df.columns:
            time = df['time_fs'] / 1000.0 # ps
            xlabel = "Time (ps)"
        else:
            time = df['step']
            xlabel = "Step"

        fig, axes = plt.subplots(3, 1, figsize=(8, 10), sharex=True)
        
        # 1. Temperature
        if 'T_K' in df.columns:
            axes[0].plot(time, df['T_K'], color='C0', label='Temperature')
            axes[0].set_ylabel("Temp (K)")
            axes[0].grid(True, alpha=0.3)
        
        # 2. Potential Energy
        if 'Epot_eV' in df.columns:
            axes[1].plot(time, df['Epot_eV'], color='C1', label='E_pot')
            axes[1].set_ylabel("E_pot (eV)")
            axes[1].grid(True, alpha=0.3)
            # Use relative energy if it's too large
            if np.max(df['Epot_eV']) - np.min(df['Epot_eV']) < 100:
                 axes[1].ticklabel_format(useOffset=False)

        # 3. Pressure
        if 'P_GPa' in df.columns:
            axes[2].plot(time, df['P_GPa'], color='C2', label='Pressure')
            axes[2].set_ylabel("Pressure (GPa)")
            axes[2].set_xlabel(xlabel)
            axes[2].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()
    except Exception as e:
        print(f"Error plotting thermodynamic properties: {e}")

def plot_cell_evolution(csv_path: str, output_path: str = "md_cell.pdf"):
    """Plot a, b, c and Vol from md.csv."""
    import pandas as pd
    try:
        df = pd.read_csv(csv_path)
        if 'time_fs' in df.columns:
            time = df['time_fs'] / 1000.0 # ps
            xlabel = "Time (ps)"
        else:
            time = df['step']
            xlabel = "Step"

        fig, axes = plt.subplots(2, 1, figsize=(8, 8), sharex=True)
        
        # 1. Lattice constants
        if all(c in df.columns for c in ['a_A', 'b_A', 'c_A']):
            axes[0].plot(time, df['a_A'], label='a')
            axes[0].plot(time, df['b_A'], label='b')
            axes[0].plot(time, df['c_A'], label='c')
            axes[0].set_ylabel("Lattice Constant (Å)")
            axes[0].legend()
            axes[0].grid(True, alpha=0.3)
        
        # 2. Volume
        if 'Vol_A3' in df.columns:
            axes[1].plot(time, df['Vol_A3'], color='C3')
            axes[1].set_ylabel("Volume (Å$^3$)")
            axes[1].set_xlabel(xlabel)
            axes[1].grid(True, alpha=0.3)
            
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()
    except Exception as e:
        print(f"Error plotting cell evolution: {e}")

def plot_rdf(traj_path: str, output_path: str = "md_rdf.pdf", rmax: float = 8.0, nbins: int = 100, skip_ratio: float = 0.2):
    """Plot Radial Distribution Function (RDF) from trajectory with auto-rmax adjustment."""
    try:
        from ase.geometry.analysis import Analysis
        
        # Read trajectory
        traj = list(iread(traj_path))
        if not traj:
            print("Warning: Trajectory is empty, skipping RDF.")
            return False
        
        # Skip initial equilibration frames
        start_idx = int(len(traj) * skip_ratio)
        subset = traj[start_idx:]
        if not subset:
            subset = [traj[-1]]

        # Auto-adjust rmax based on cell size (rmax < min_cell_dim / 2)
        cell_lengths = subset[0].cell.lengths()
        min_dim = np.min(cell_lengths)
        safe_rmax = min_dim / 2.0 - 0.1
        if rmax > safe_rmax:
            # print(f"  [RDF] Adjusting rmax from {rmax:.2f} to {safe_rmax:.2f} due to cell size ({min_dim:.2f} A)")
            rmax = safe_rmax
        
        # Use first frame symbols to get pairs
        symbols = subset[0].get_chemical_symbols()
        unique_elements = sorted(list(set(symbols)))
        
        ana = Analysis(subset)
        
        plt.figure(figsize=(8, 6))
        
        # 1. Total RDF (Average over all frames)
        rdf_total = ana.get_rdf(rmax=rmax, nbins=nbins)
        # Analysis.get_rdf returns a list of arrays (one for each frame)
        rdf_mean = np.mean(rdf_total, axis=0)
        r = np.linspace(0, rmax, nbins)
        plt.plot(r, rdf_mean, label="Total", color='black', linewidth=2)
        
        # 2. Pairwise RDF (if multiple elements)
        if len(unique_elements) > 1:
            for i in range(len(unique_elements)):
                for j in range(i, len(unique_elements)):
                    el1 = unique_elements[i]
                    el2 = unique_elements[j]
                    try:
                        rdf_pair = ana.get_rdf(rmax=rmax, nbins=nbins, elements=(el1, el2))
                        rdf_p_mean = np.mean(rdf_pair, axis=0)
                        plt.plot(r, rdf_p_mean, label=f"{el1}-{el2}", alpha=0.7)
                    except:
                        continue
        
        plt.xlabel("Distance (Å)")
        plt.ylabel("g(r)")
        plt.title(f"Radial Distribution Function (rmax={rmax:.2f} Å)")
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()
        return True
    except Exception as e:
        print(f"Error calculating RDF: {e}")
        return False

def md_summary(csv_path: str):
    """Alias for print_md_summary for backward compatibility."""
    print_md_summary(csv_path)

def load_default_charges():
    """Load default oxidation states from pydefect database if available."""
    try:
        import pydefect
        pydefect_path = Path(pydefect.__file__).parent
        yaml_path = pydefect_path / "database" / "oxidation_state.yaml"
        if yaml_path.exists():
            with open(yaml_path, "r") as f:
                return yaml.safe_load(f)
    except:
        pass
    return {}

def detect_interval(input_path):
    """Try to detect interval from XDATCAR or neighboring md.csv."""
    input_path = Path(input_path)
    
    # 1. Try to find an XDATCAR (either the input itself or in the same dir)
    xdatcar_path = None
    if 'XDATCAR' in input_path.name:
        xdatcar_path = input_path
    else:
        # Look for XDATCAR in the same directory
        candidate = input_path.parent / "XDATCAR"
        if candidate.exists():
            xdatcar_path = candidate

    if xdatcar_path:
        try:
            configs = []
            with open(xdatcar_path, 'r') as f:
                for line in f:
                    if "Direct configuration=" in line:
                        val = line.split('=')[1].strip().split()[0]
                        configs.append(int(val))
                    if len(configs) >= 2:
                        break
            if len(configs) >= 2:
                return configs[1] - configs[0]
        except:
            pass

    # 2. Try to find md.csv in the same directory
    csv_path = input_path.parent / "md.csv"
    if csv_path.exists():
        try:
            import pandas as pd
            df = pd.read_csv(csv_path)
            if 'Step' in df.columns and len(df) >= 2:
                return int(df['Step'].iloc[1] - df['Step'].iloc[0])
        except:
            pass

    return None


def detect_frame_dt_ps(input_path):
    """
    Try to detect frame spacing in ps from neighboring md.csv.
    Returns None if unavailable.
    """
    input_path = Path(input_path)
    csv_path = input_path.parent / "md.csv"
    if not csv_path.exists():
        return None
    try:
        import pandas as pd
        df = pd.read_csv(csv_path)
        if 'time_fs' in df.columns and len(df) >= 2:
            dt_fs = float(df['time_fs'].iloc[1] - df['time_fs'].iloc[0])
            if dt_fs > 0:
                return dt_fs * 1e-3
    except Exception:
        pass
    return None


def detect_temperature_k(input_path):
    """Try to detect average temperature from neighboring md.csv."""
    input_path = Path(input_path)
    csv_path = input_path.parent / "md.csv"
    if not csv_path.exists():
        return None
    try:
        import pandas as pd
        df = pd.read_csv(csv_path)
        if "T_K" in df.columns and len(df) > 0:
            return float(df["T_K"].mean())
    except Exception:
        pass
    return None


def _parse_xdatcar_header(lines, start_idx):
    i = start_idx
    if i + 5 >= len(lines):
        return None
    try:
        title = lines[i].strip()
        scale = float(lines[i + 1].split()[0])
        cell = []
        for j in range(3):
            vals = [float(x) for x in lines[i + 2 + j].split()[:3]]
            if len(vals) != 3:
                return None
            cell.append(vals)
        line5 = lines[i + 5].split()
        # VASP5 XDATCAR: line5=species, line6=counts
        # VASP4 XDATCAR: line5=counts (species absent)
        is_counts_line5 = False
        try:
            [int(x) for x in line5]
            is_counts_line5 = len(line5) > 0
        except Exception:
            is_counts_line5 = False

        if is_counts_line5:
            counts = [int(x) for x in line5]
            species_from_title = []
            for tok in title.replace(",", " ").split():
                t = tok.strip()
                if t.isalpha() and len(t) <= 2 and t[0].isalpha():
                    species_from_title.append(t[0].upper() + t[1:].lower())
            if len(species_from_title) == len(counts):
                species = species_from_title
            else:
                # VASP4 may omit species line; use valid placeholder symbols.
                fallback = [
                    "H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne",
                    "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K", "Ca",
                ]
                species = [fallback[k % len(fallback)] for k in range(len(counts))]
            next_idx = i + 6
        else:
            if i + 6 >= len(lines):
                return None
            species = line5
            counts = [int(x) for x in lines[i + 6].split()]
            if len(species) != len(counts):
                return None
            next_idx = i + 7

        symbols = []
        for sym, cnt in zip(species, counts):
            symbols.extend([sym] * cnt)
        return {
            "cell": np.array(cell, dtype=float) * scale,
            "symbols": symbols,
            "n_atoms": len(symbols),
            "next_idx": next_idx,
        }
    except Exception:
        return None


def _read_xdatcar_tolerant(path: Path):
    with open(path, "r") as f:
        lines = f.readlines()
    if not lines:
        return []
    header = _parse_xdatcar_header(lines, 0)
    if header is None:
        raise ValueError("Invalid XDATCAR header.")

    frames = []
    i = header["next_idx"]
    current = header
    dropped = 0
    while i < len(lines):
        s = lines[i].strip()
        if not s:
            i += 1
            continue

        h2 = _parse_xdatcar_header(lines, i)
        if h2 is not None:
            current = h2
            i = h2["next_idx"]
            continue

        if s.lower().startswith("direct configuration"):
            n = current["n_atoms"]
            if i + n >= len(lines):
                dropped += 1
                break
            coords = []
            ok = True
            for k in range(n):
                parts = lines[i + 1 + k].split()
                if len(parts) < 3:
                    ok = False
                    break
                try:
                    coords.append([float(parts[0]), float(parts[1]), float(parts[2])])
                except Exception:
                    ok = False
                    break
            if not ok:
                dropped += 1
                i += 1
                continue
            atoms = Atoms(symbols=current["symbols"], cell=current["cell"], pbc=True)
            atoms.set_scaled_positions(np.array(coords, dtype=float))
            frames.append(atoms)
            i += n + 1
            continue
        i += 1
    if dropped > 0:
        print(f"Warning: dropped {dropped} malformed trailing/partial XDATCAR frame(s).")
    return frames


def _read_trajectory_robust(traj_path: Path, format_hint: str = "auto"):
    if format_hint == "xdatcar":
        fmt = "vasp-xdatcar"
    else:
        fmt = 'vasp-xdatcar' if 'XDATCAR' in str(traj_path) else None
    try:
        traj = [atoms for atoms in iread(str(traj_path), format=fmt)]
        return traj
    except Exception as e:
        if fmt == 'vasp-xdatcar':
            print(f"Standard XDATCAR reading failed: {e}. Trying robust mode...")
            traj = _read_xdatcar_tolerant(traj_path)
            if traj:
                print(f"Successfully read {len(traj)} frames in tolerant XDATCAR mode.")
                return traj
        raise


def _scalar_stats(arr):
    arr = np.asarray(arr, dtype=float)
    return {
        "mean": float(np.mean(arr)),
        "std": float(np.std(arr)),
        "min": float(np.min(arr)),
        "max": float(np.max(arr)),
        "p05": float(np.percentile(arr, 5)),
        "p95": float(np.percentile(arr, 95)),
    }


def _linear_slope(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if len(x) < 2:
        return 0.0
    slope, _ = np.polyfit(x, y, 1)
    return float(slope)


def _block_stats(values, nblocks=10):
    values = np.asarray(values, dtype=float)
    n = len(values)
    if n == 0:
        return []
    nblocks = max(1, min(int(nblocks), n))
    out = []
    for b in range(nblocks):
        i0 = int(np.floor(b * n / nblocks))
        i1 = int(np.floor((b + 1) * n / nblocks))
        if i1 <= i0:
            continue
        chunk = values[i0:i1]
        out.append({
            "block": b + 1,
            "start_idx": i0,
            "end_idx": i1 - 1,
            "mean": float(np.mean(chunk)),
            "std": float(np.std(chunk)),
        })
    return out


def _detect_equilibration_start(v_arr, min_frac=0.5, tol_sigma=0.5):
    """
    Simple equilibration detection:
    find first index where |v_i - mean_tail| <= tol_sigma * std_tail.
    """
    v_arr = np.asarray(v_arr, dtype=float)
    n = len(v_arr)
    if n < 4:
        return 0
    tail_start = int(max(1, np.floor(n * min_frac)))
    tail = v_arr[tail_start:]
    mu = float(np.mean(tail))
    sig = float(np.std(tail))
    if sig <= 1e-12:
        return tail_start
    thresh = tol_sigma * sig
    for i in range(n):
        if abs(float(v_arr[i]) - mu) <= thresh:
            return i
    return tail_start

def calculate_conductivity(
    traj_path,
    temp,
    dt,
    interval=1,
    charges_str="",
    out_prefix="md_results",
    charge_msd=False,
    run_summary_text=None,
):
    """Calculate ionic conductivity from trajectory."""
    traj_path = Path(traj_path)
    if not traj_path.exists():
        print(f"Error: Trajectory file '{traj_path}' not found.")
        return

    # Auto-detect interval if not provided
    if interval == 1:
        detected = detect_interval(traj_path)
        if detected:
            interval = detected
            print(f"Auto-detected interval: {interval}")

    # Setup output path (same dir as input)
    out_dir = traj_path.parent
    out_prefix_path = out_dir / out_prefix
    log_file = out_prefix_path.with_suffix(".log")

    def log_print(msg):
        print(msg)
        with open(log_file, "a") as f:
            f.write(msg + "\n")

    with open(log_file, "w") as f:
        f.write("---" * 10 + " MD Conductivity Analysis ---" + "---" * 10 + "\n")
        if run_summary_text:
            f.write(run_summary_text + "\n")
        f.write(f"Input: {traj_path}\n")
        f.write(f"Temp: {temp} K\n")
        f.write(f"Time step: {dt} fs\n")
        f.write(f"Interval: {interval}\n")

    log_print(f"Reading trajectory: {traj_path}")
    try:
        traj = _read_trajectory_robust(traj_path)
    except Exception as e:
        print(f"Error reading trajectory: {e}")
        if 'XDATCAR' in str(traj_path):
            print("Tip: VASP XDATCAR reading can be strict. Try using 'md.traj' instead for better compatibility.")
        return

    if not traj or len(traj) < 2:
        print("Error: Trajectory is too short or empty. Need at least 2 frames.")
        return

    n_steps = len(traj)
    vol_A3 = traj[0].get_volume()
    vol_m3 = vol_A3 * (ANGSTROM ** 3)
    species = sorted(list(set(traj[0].get_chemical_symbols())))
    
    # Charges
    defaults = load_default_charges()
    charges = defaults.copy()
    if charges_str:
        for p in charges_str.split(','):
            if ':' in p:
                el, q = p.split(':')
                charges[el.strip()] = float(q)

    log_print(f"Steps: {n_steps}, Volume: {vol_A3:.2f} A^3")
    log_print("Using oxidation states:")
    for sp in species:
        q = charges.get(sp, None)
        if q is None:
            q = 0.0
            log_print(f"  {sp}: {q} (Warning: not found in defaults, using 0.0)")
        else:
            log_print(f"  {sp}: {q}")
        charges[sp] = q
    
    # Use stack instead of np.array for safer creation from list of arrays
    pos_list = [atoms.get_scaled_positions() for atoms in traj]
    scaled_pos = np.stack(pos_list)
    
    d_scaled = scaled_pos[1:] - scaled_pos[:-1]
    d_scaled -= np.round(d_scaled)
    cum_disp_scaled = np.zeros_like(scaled_pos)
    cum_disp_scaled[1:] = np.cumsum(d_scaled, axis=0)
    
    cell = traj[0].get_cell()
    unwrapped_real = np.dot(cum_disp_scaled + scaled_pos[0], cell)

    dt_eff = dt * interval
    time_ps = np.arange(n_steps) * dt_eff * 1e-3

    results = {}
    plt.figure(figsize=(8, 6))
    
    for sp in species:
        indices = [i for i, s in enumerate(traj[0].get_chemical_symbols()) if s == sp]
        pos_sp = unwrapped_real[:, indices, :]
        disp_from_0 = pos_sp - pos_sp[0]
        msd = np.mean(np.sum(disp_from_0**2, axis=2), axis=1)
        
        s, e = int(n_steps*0.1), int(n_steps*0.9)
        if e > s + 1:
            slope, intercept = np.polyfit(time_ps[s:e], msd[s:e], 1)
        else:
            slope = 0
            intercept = 0
        
        D_cm2_s = (slope / 6.0) * 1e-8 * 1e4
        q = charges.get(sp, 0.0) * E_CHARGE
        sigma = ((len(indices)/vol_m3) * (q**2) * (slope/6.0*1e-8)) / (KB_J * temp) if q != 0 else 0
        
        results[sp] = {'D': D_cm2_s, 'sigma': sigma}
        log_print(f"\n--- Species: {sp} ---")
        log_print(f"  Diff. Coeff (D): {D_cm2_s:.3e} cm^2/s")
        log_print(f"  Conductivity (sigma_NE): {sigma:.3e} S/m ({sigma*10:.2f} mS/cm)")
        
        plt.plot(time_ps, msd, label=f"{sp} ($D$={D_cm2_s:.1e})")
        if e > s + 1:
            plt.plot(time_ps[s:e], slope * time_ps[s:e] + intercept, '--', alpha=0.5, color='gray')

    total_sigma = sum(r['sigma'] for r in results.values())
    log_print(f"\nTotal Conductivity: {total_sigma*10:.2f} mS/cm")
    
    plt.xlabel("Time (ps)")
    plt.ylabel(r"MSD (\AA^2)")
    plt.title(rf"MSD @ {temp}K (Total $\sigma$ = {total_sigma*10:.2f} mS/cm)")
    plt.legend(); plt.grid(True, alpha=0.3)
    plt.tight_layout()
    
    plot_file = out_prefix_path.with_suffix(".pdf")
    plt.savefig(plot_file)
    log_print(f"Plot saved to {plot_file}")
    log_print(f"Log saved to {log_file}")

def _write_adp_cif(cif_path: Path, atoms, adp_tensors):
    cell = np.array(atoms.cell, dtype=float)
    a = float(np.linalg.norm(cell[0]))
    b = float(np.linalg.norm(cell[1]))
    c = float(np.linalg.norm(cell[2]))

    def _angle(v1, v2):
        x = float(np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2)))
        x = min(1.0, max(-1.0, x))
        return float(np.degrees(np.arccos(x)))

    alpha = _angle(cell[1], cell[2])
    beta = _angle(cell[0], cell[2])
    gamma = _angle(cell[0], cell[1])

    symbols = list(atoms.get_chemical_symbols())
    scaled_positions = np.asarray(atoms.get_scaled_positions(wrap=True), dtype=float)
    with open(cif_path, "w") as f:
        f.write("data_md_average_adp\n")
        f.write("_symmetry_space_group_name_H-M 'P 1'\n")
        f.write("_symmetry_Int_Tables_number 1\n")
        f.write(f"_cell_length_a {a:.10f}\n")
        f.write(f"_cell_length_b {b:.10f}\n")
        f.write(f"_cell_length_c {c:.10f}\n")
        f.write(f"_cell_angle_alpha {alpha:.10f}\n")
        f.write(f"_cell_angle_beta {beta:.10f}\n")
        f.write(f"_cell_angle_gamma {gamma:.10f}\n")
        f.write("\n")
        f.write("loop_\n")
        f.write("_symmetry_equiv_pos_as_xyz\n")
        f.write("'x, y, z'\n")
        f.write("\n")
        f.write("loop_\n")
        f.write("_atom_site_label\n")
        f.write("_atom_site_type_symbol\n")
        f.write("_atom_site_fract_x\n")
        f.write("_atom_site_fract_y\n")
        f.write("_atom_site_fract_z\n")
        f.write("_atom_site_U_iso_or_equiv\n")
        for i, (sym, spos) in enumerate(zip(symbols, scaled_positions), start=1):
            uiso = (adp_tensors[i - 1][0, 0] + adp_tensors[i - 1][1, 1] + adp_tensors[i - 1][2, 2]) / 3.0
            label = f"{sym}{i}"
            f.write(
                f"{label:<6s} {sym:<3s} "
                f"{spos[0]:12.8f} {spos[1]:12.8f} {spos[2]:12.8f} {uiso:12.8f}\n"
            )
        f.write("\n")
        f.write("loop_\n")
        f.write("_atom_site_aniso_label\n")
        f.write("_atom_site_aniso_U_11\n")
        f.write("_atom_site_aniso_U_22\n")
        f.write("_atom_site_aniso_U_33\n")
        f.write("_atom_site_aniso_U_23\n")
        f.write("_atom_site_aniso_U_13\n")
        f.write("_atom_site_aniso_U_12\n")
        for i, (sym, u) in enumerate(zip(symbols, adp_tensors), start=1):
            label = f"{sym}{i}"
            f.write(
                f"{label:<6s} "
                f"{u[0,0]:12.8f} {u[1,1]:12.8f} {u[2,2]:12.8f} "
                f"{u[1,2]:12.8f} {u[0,2]:12.8f} {u[0,1]:12.8f}\n"
            )


def analyze_cell_evolution(
    traj_path,
    dt=None,
    skip_ps=0.0,
    skip_frames=0,
    interval=1,
    out_prefix="cell_evolution",
    poscar_out=None,
    avg_poscar_out=None,
    write_adp=True,
    run_summary_text=None,
    auto_skip=False,
    outlier_z=None,
    block_count=10,
    window_last_percent=None,
    window_start_frame=None,
    window_end_frame=None,
    reference_poscar=None,
    symmetry_sample=0,
    displacement_vectors=True,
    report=True,
    temperature_k=None,
):
    """Analyze cell parameter evolution (a, b, c, Vol) and calculate averages after skip_ps."""
    traj_path = Path(traj_path)
    if not traj_path.exists():
        print(f"Error: Trajectory file '{traj_path}' not found.")
        return

    # Auto-detect interval if not provided
    if interval == 1:
        detected = detect_interval(traj_path)
        if detected:
            interval = detected
            print(f"Auto-detected interval (frame saving frequency): {interval}")

    # Setup output
    out_dir = traj_path.parent
    if out_prefix.endswith('.pdf'):
        out_prefix = out_prefix[:-4]
    
    # If out_prefix is just a name, put it in out_dir. If it's a path, use it as is.
    if "/" in out_prefix or "\\" in out_prefix:
        out_prefix_path = Path(out_prefix)
    else:
        out_prefix_path = out_dir / out_prefix
        
    log_file = out_prefix_path.with_suffix(".log")

    def log_print(msg):
        print(msg)
        with open(log_file, "a") as f:
            f.write(msg + "\n")

    def _resolve_output_path(name):
        if name is None:
            return None
        if "/" in name or "\\" in name:
            return Path(name)
        return out_dir / name

    def _default_average_path(base_path: Path) -> Path:
        suffix = "".join(base_path.suffixes)
        if suffix:
            name_root = base_path.name[: -len(suffix)]
        else:
            name_root = base_path.name
        avg_root = name_root if name_root.endswith("-average") else f"{name_root}-average"
        return base_path.with_name(f"{avg_root}{suffix}")

    with open(log_file, "w") as f:
        f.write("---" * 10 + " Cell Evolution Analysis ---" + "---" * 10 + "\n")
        if run_summary_text:
            f.write(run_summary_text + "\n")
        f.write(f"Input: {traj_path}\n")
        f.write(f"Time step (dt): {dt if dt is not None else 'auto/None'} fs\n")
        f.write(f"Interval (sampling step): {interval}\n")
        f.write(f"Skip first: {skip_ps} ps\n\n")

    adp_base_path = _resolve_output_path(poscar_out)
    if avg_poscar_out:
        avg_struct_path = _resolve_output_path(avg_poscar_out)
    elif adp_base_path:
        avg_struct_path = _default_average_path(adp_base_path)
    else:
        avg_struct_path = None

    log_print(f"Reading trajectory: {traj_path} ...")
    try:
        traj = _read_trajectory_robust(traj_path)
    except Exception as e:
        print(f"Error reading trajectory: {e}")
        return

    n_steps = len(traj)
    if n_steps == 0:
        print("Error: Empty trajectory.")
        return

    if _HAS_NUMBA:
        log_print("Acceleration: numba enabled for fractional unwrapping path.")
    else:
        log_print("Acceleration: numba not available (using numpy fallback).")

    # Extract Data
    cells = np.array([np.array(atoms.get_cell(), dtype=float) for atoms in traj], dtype=float)
    lengths = np.linalg.norm(cells, axis=2)
    a_arr = lengths[:, 0]
    b_arr = lengths[:, 1]
    c_arr = lengths[:, 2]
    v_arr = np.abs(np.einsum("ni,ni->n", np.cross(cells[:, 0, :], cells[:, 1, :]), cells[:, 2, :]))
    
    time_ps = None
    if dt is not None:
        dt_eff = float(dt) * interval
        time_ps = np.arange(n_steps) * dt_eff * 1e-3
    else:
        frame_dt_ps = detect_frame_dt_ps(traj_path)
        if frame_dt_ps is not None:
            time_ps = np.arange(n_steps) * frame_dt_ps
            log_print(f"Auto-detected frame spacing from md.csv: {frame_dt_ps:.6f} ps/frame")
        else:
            log_print("Warning: --dt not provided and md.csv time info not found. Using frame index axis.")
    
    # Select averaging window.
    mask = np.ones(n_steps, dtype=bool)
    selection_reason = "all_frames"
    if window_start_frame is not None or window_end_frame is not None:
        i0 = int(window_start_frame or 0)
        i1 = int(window_end_frame) if window_end_frame is not None else (n_steps - 1)
        i0 = max(0, min(i0, n_steps - 1))
        i1 = max(i0, min(i1, n_steps - 1))
        mask[:] = False
        mask[i0:i1 + 1] = True
        selection_reason = f"frame_window[{i0}:{i1}]"
    elif window_last_percent is not None:
        pct = max(1.0, min(100.0, float(window_last_percent)))
        n_last = max(1, int(np.ceil(n_steps * pct / 100.0)))
        mask[:] = False
        mask[n_steps - n_last:] = True
        selection_reason = f"last_{pct:.2f}%"
    elif skip_frames > 0:
        start_idx = min(int(skip_frames), n_steps - 1)
        mask[:] = False
        mask[start_idx:] = True
        selection_reason = f"skip_frames={skip_frames}"
    elif auto_skip:
        start_idx = _detect_equilibration_start(v_arr, min_frac=0.5, tol_sigma=0.5)
        mask[:] = False
        mask[start_idx:] = True
        selection_reason = f"auto_skip(start_idx={start_idx})"
    elif time_ps is not None:
        mask = time_ps >= skip_ps
        selection_reason = f"skip_ps={skip_ps}"
        if not np.any(mask):
            log_print(f"Warning: skip_ps ({skip_ps}) is larger than total time ({time_ps[-1]:.2f}). Using last frame only.")
            mask[-1] = True
    else:
        if skip_ps > 0:
            log_print("Warning: skip(ps) requested but time axis is unavailable without --dt/md.csv. Ignoring --skip.")
        selection_reason = "all_frames(no_time_axis)"

    # Outlier filtering.
    if outlier_z is not None and outlier_z > 0:
        z = float(outlier_z)
        keep = np.ones(n_steps, dtype=bool)
        for arr in (a_arr, b_arr, c_arr, v_arr):
            mu = float(np.mean(arr))
            sd = float(np.std(arr))
            if sd > 1e-12:
                keep &= np.abs((arr - mu) / sd) <= z
        before = int(np.sum(mask))
        mask &= keep
        after = int(np.sum(mask))
        log_print(f"Outlier filter (--outlier-z {z:g}): kept {after}/{before} selected frames.")
        if not np.any(mask):
            log_print("Warning: all selected frames were filtered as outliers. Falling back to last frame.")
            mask[-1] = True
        
    sel_idx = np.where(mask)[0]
    sel_a = a_arr[mask]
    sel_b = b_arr[mask]
    sel_c = c_arr[mask]
    sel_v = v_arr[mask]
    avg_a = float(np.mean(sel_a))
    std_a = float(np.std(sel_a))
    avg_b = float(np.mean(sel_b))
    std_b = float(np.std(sel_b))
    avg_c = float(np.mean(sel_c))
    std_c = float(np.std(sel_c))
    avg_v = float(np.mean(sel_v))
    std_v = float(np.std(sel_v))
    
    if time_ps is not None:
        t0 = float(time_ps[sel_idx[0]])
        log_print(f"Total time: {time_ps[-1]:.2f} ps")
        log_print(f"Averaging window: {selection_reason}")
        log_print(f"Averaging over: {time_ps[-1] - t0:.2f} ps ({np.sum(mask)} frames)")
    else:
        first_kept = int(sel_idx[0]) if np.any(mask) else 0
        log_print(f"Total frames: {n_steps}")
        log_print(f"Averaging window: {selection_reason} (start={first_kept})")
        log_print(f"Averaging over: {np.sum(mask)} frames")
    log_print("-" * 40)
    log_print(f"      Mean      Std      (Unit)")
    log_print(f" a:   {avg_a:.4f}    {std_a:.4f}    Ang")
    log_print(f" b:   {avg_b:.4f}    {std_b:.4f}    Ang")
    log_print(f" c:   {avg_c:.4f}    {std_c:.4f}    Ang")
    log_print(f" Vol: {avg_v:.4f}    {std_v:.4f}    Ang^3")
    log_print("-" * 40)

    # Rich stats.
    stats_a = _scalar_stats(sel_a)
    stats_b = _scalar_stats(sel_b)
    stats_c = _scalar_stats(sel_c)
    stats_v = _scalar_stats(sel_v)
    x_for_slope = (time_ps[mask] if time_ps is not None else sel_idx.astype(float))
    drift_a = _linear_slope(x_for_slope, sel_a)
    drift_b = _linear_slope(x_for_slope, sel_b)
    drift_c = _linear_slope(x_for_slope, sel_c)
    drift_v = _linear_slope(x_for_slope, sel_v)
    log_print("Detailed stats (selected window):")
    log_print(f"  a: min={stats_a['min']:.4f} max={stats_a['max']:.4f} p05={stats_a['p05']:.4f} p95={stats_a['p95']:.4f}")
    log_print(f"  b: min={stats_b['min']:.4f} max={stats_b['max']:.4f} p05={stats_b['p05']:.4f} p95={stats_b['p95']:.4f}")
    log_print(f"  c: min={stats_c['min']:.4f} max={stats_c['max']:.4f} p05={stats_c['p05']:.4f} p95={stats_c['p95']:.4f}")
    log_print(f"  V: min={stats_v['min']:.4f} max={stats_v['max']:.4f} p05={stats_v['p05']:.4f} p95={stats_v['p95']:.4f}")
    x_unit = "ps" if time_ps is not None else "frame"
    log_print(f"Drift slopes (per {x_unit}): da={drift_a:.6e}, db={drift_b:.6e}, dc={drift_c:.6e}, dV={drift_v:.6e}")

    # Block statistics (convergence diagnostic).
    block_stats = _block_stats(sel_v, nblocks=block_count)
    if block_stats:
        block_path = out_prefix_path.with_suffix(".blocks.dat")
        with open(block_path, "w") as f:
            f.write("# block start_idx end_idx mean_vol std_vol\n")
            for b in block_stats:
                f.write(
                    f"{b['block']:4d} {b['start_idx']:8d} {b['end_idx']:8d} "
                    f"{b['mean']:15.8e} {b['std']:15.8e}\n"
                )
        log_print(f"Block statistics saved to: {block_path}")

    # Strain analysis relative to reference cell.
    strain_summary = None
    try:
        if reference_poscar:
            ref_atoms = read(str(reference_poscar))
            ref_cell = np.array(ref_atoms.get_cell(), dtype=float)
        else:
            ref_cell = np.array(cells[0], dtype=float)
        ref_inv = np.linalg.inv(ref_cell)
        f_mat = np.einsum("nij,jk->nik", cells, ref_inv, optimize=True)
        e_mat = f_mat - np.eye(3, dtype=float)[None, :, :]
        eps = np.stack(
            [
                e_mat[:, 0, 0],
                e_mat[:, 1, 1],
                e_mat[:, 2, 2],
                e_mat[:, 1, 2],
                e_mat[:, 0, 2],
                e_mat[:, 0, 1],
                np.trace(e_mat, axis1=1, axis2=2),
            ],
            axis=1,
        )
        eps_sel = eps[mask]
        strain_summary = {
            "exx_mean": float(np.mean(eps_sel[:, 0])),
            "eyy_mean": float(np.mean(eps_sel[:, 1])),
            "ezz_mean": float(np.mean(eps_sel[:, 2])),
            "eyz_mean": float(np.mean(eps_sel[:, 3])),
            "exz_mean": float(np.mean(eps_sel[:, 4])),
            "exy_mean": float(np.mean(eps_sel[:, 5])),
            "dV_over_V_mean": float(np.mean(eps_sel[:, 6])),
        }
        strain_path = out_prefix_path.with_suffix(".strain.dat")
        with open(strain_path, "w") as f:
            f.write("# idx exx eyy ezz eyz exz exy dV_over_V\n")
            for i in range(n_steps):
                f.write(
                    f"{i:8d} {eps[i,0]:15.8e} {eps[i,1]:15.8e} {eps[i,2]:15.8e} "
                    f"{eps[i,3]:15.8e} {eps[i,4]:15.8e} {eps[i,5]:15.8e} {eps[i,6]:15.8e}\n"
                )
        log_print(f"Strain data saved to: {strain_path}")
    except Exception as e:
        log_print(f"Warning: strain analysis skipped: {e}")

    # Symmetry tracking (sampled).
    symmetry_counts = {}
    if symmetry_sample and symmetry_sample > 0:
        try:
            try:
                import spglib
            except Exception:
                import macer.externals.spglib_bundled as spglib
            sample_n = min(int(symmetry_sample), n_steps)
            sample_idx = np.unique(np.linspace(0, n_steps - 1, sample_n, dtype=int))
            sym_path = out_prefix_path.with_suffix(".symmetry.csv")
            with open(sym_path, "w") as f:
                f.write("frame,spacegroup\n")
                for i in sample_idx:
                    at = traj[int(i)]
                    cell_tuple = (at.get_cell(), at.get_scaled_positions(wrap=True), at.get_atomic_numbers())
                    sg = spglib.get_spacegroup(cell_tuple, symprec=1e-2)
                    sg = str(sg) if sg else "N/A"
                    f.write(f"{int(i)},{sg}\n")
                    symmetry_counts[sg] = symmetry_counts.get(sg, 0) + 1
            log_print(f"Symmetry tracking saved to: {sym_path}")
        except Exception as e:
            log_print(f"Warning: symmetry tracking skipped: {e}")

    # Cell fluctuation physics (bulk modulus from volume fluctuation).
    if temperature_k is None:
        temperature_k = detect_temperature_k(traj_path)
    bulk_modulus_gpa = None
    if temperature_k is not None and np.var(sel_v) > 1e-16:
        kb = 1.380649e-23  # J/K
        v_m3 = sel_v * 1e-30
        mean_v = float(np.mean(v_m3))
        var_v = float(np.var(v_m3))
        if var_v > 0:
            bulk_modulus_gpa = (kb * float(temperature_k) * mean_v / var_v) / 1e9
            log_print(f"Bulk modulus estimate from fluctuations: {bulk_modulus_gpa:.3f} GPa (T={temperature_k:.2f} K)")
    
    avg_atoms = None
    avg_frac = None
    unwrapped_frac = None
    do_average_structure = avg_struct_path is not None

    # --- Averaged Structure Calculation ---
    try:
        subset_indices = np.where(mask)[0]
        if do_average_structure and len(subset_indices) > 0:
            # 1. Average Cell (Matrix)
            cells = np.array([traj[i].get_cell() for i in subset_indices])
            avg_cell = np.mean(cells, axis=0)

            # 2. Average Positions (Unwrapped Fractional)
            # Use the first frame of the subset as the reference anchor
            # Then unwrap subsequent frames relative to the previous one
            
            # Collect wrapped fractional coordinates
            frac_coords = np.array([traj[i].get_scaled_positions(wrap=True) for i in subset_indices], dtype=float)
            
            # Unwrap
            if _HAS_NUMBA:
                unwrapped_frac = _unwrap_fractional_numba(frac_coords)
            else:
                unwrapped_frac = np.zeros_like(frac_coords)
                unwrapped_frac[0] = frac_coords[0]
                for i in range(1, len(frac_coords)):
                    diff = frac_coords[i] - frac_coords[i-1]
                    diff -= np.round(diff)
                    unwrapped_frac[i] = unwrapped_frac[i-1] + diff
                
            avg_frac = np.mean(unwrapped_frac, axis=0)
            # Wrap average positions back to [0, 1)
            avg_frac_wrapped = avg_frac % 1.0
            
            # Create Averaged Atoms
            avg_atoms = traj[subset_indices[0]].copy()
            avg_atoms.set_cell(avg_cell)
            avg_atoms.set_scaled_positions(avg_frac_wrapped)
            
            if avg_struct_path is None:
                log_print("Average-structure generation skipped (no target path provided).")
            else:
                write(str(avg_struct_path), avg_atoms, format='vasp')
                log_print(f"Averaged structure saved to: {avg_struct_path}")

        elif not do_average_structure:
            log_print("Average-structure generation skipped (set --poscar or --avg-poscar to enable).")
    except Exception as e:
        log_print(f"Error calculating averaged structure: {e}")

    # --- ADP from trajectory covariance around averaged structure ---
    adp_species_summary = {}
    adp_rank_top = []
    if (
        write_adp
        and avg_atoms is not None
        and avg_frac is not None
        and unwrapped_frac is not None
    ):
        try:
            if adp_base_path is None:
                log_print("ADP generation skipped (no base filename specified).")
            else:
                du_frac = unwrapped_frac - avg_frac[None, :, :]
                du_cart = np.einsum("tni,ij->tnj", du_frac, np.array(avg_atoms.get_cell(), dtype=float))
                symbols = avg_atoms.get_chemical_symbols()
                adp_tensors = []
                adp_dat = adp_base_path.with_suffix(".adp.dat")
                adp_cif = adp_base_path.with_suffix(".adp.cif")
                with open(adp_dat, "w") as f:
                    f.write("# atom_index symbol U11 U22 U33 U23 U13 U12 Uiso Biso(=8*pi^2*Uiso)\n")
                    uiso_vals = []
                    sym_vals = {}
                    for i, sym in enumerate(symbols):
                        x = du_cart[:, i, :]
                        cov = np.einsum("ni,nj->ij", x, x) / float(len(x))
                        u11, u22, u33 = cov[0, 0], cov[1, 1], cov[2, 2]
                        u23, u13, u12 = cov[1, 2], cov[0, 2], cov[0, 1]
                        uiso = (u11 + u22 + u33) / 3.0
                        biso = 8.0 * np.pi * np.pi * uiso
                        f.write(
                            f"{i+1:6d} {sym:>3s} "
                            f"{u11:15.8e} {u22:15.8e} {u33:15.8e} "
                            f"{u23:15.8e} {u13:15.8e} {u12:15.8e} {uiso:15.8e} {biso:15.8e}\n"
                        )
                        adp_tensors.append(cov)
                        uiso_vals.append((i + 1, sym, float(uiso)))
                        sym_vals.setdefault(sym, []).append(float(uiso))

                for sym, vals in sym_vals.items():
                    adp_species_summary[sym] = {
                        "n": len(vals),
                        "Uiso_mean": float(np.mean(vals)),
                        "Uiso_std": float(np.std(vals)),
                    }
                adp_rank_top = sorted(uiso_vals, key=lambda t: t[2], reverse=True)[:10]

                _write_adp_cif(adp_cif, avg_atoms, adp_tensors)
                log_print(f"ADP table saved to: {adp_dat}")
                log_print(f"ADP CIF saved to: {adp_cif}")

                adp_summary_path = adp_base_path.with_suffix(".adp.summary.dat")
                with open(adp_summary_path, "w") as f:
                    f.write("# species n Uiso_mean Uiso_std\n")
                    for sym in sorted(adp_species_summary.keys()):
                        info = adp_species_summary[sym]
                        f.write(f"{sym:>3s} {info['n']:6d} {info['Uiso_mean']:15.8e} {info['Uiso_std']:15.8e}\n")
                    f.write("\n# top_sites_by_Uiso atom_index symbol Uiso\n")
                    for i, sym, uiso in adp_rank_top:
                        f.write(f"{i:6d} {sym:>3s} {uiso:15.8e}\n")
                log_print(f"ADP summary saved to: {adp_summary_path}")

                if displacement_vectors:
                    disp_mean = np.mean(du_cart, axis=0)
                    disp_std = np.std(np.linalg.norm(du_cart, axis=2), axis=0)
                    disp_path = adp_base_path.with_suffix(".displacement.dat")
                    with open(disp_path, "w") as f:
                        f.write("# atom_index symbol dx dy dz norm_mean norm_std\n")
                        for i, sym in enumerate(symbols):
                            dv = disp_mean[i]
                            nrm = float(np.linalg.norm(dv))
                            f.write(
                                f"{i+1:6d} {sym:>3s} {dv[0]:15.8e} {dv[1]:15.8e} {dv[2]:15.8e} "
                                f"{nrm:15.8e} {float(disp_std[i]):15.8e}\n"
                            )
                    log_print(f"Displacement map saved to: {disp_path}")
        except Exception as e:
            log_print(f"Error calculating/saving ADP outputs: {e}")

    # Plotting
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(8, 8), sharex=True)
    x_axis = time_ps if time_ps is not None else np.arange(n_steps)
    x_label = "Time (ps)" if time_ps is not None else "Frame index"
    start_x = x_axis[np.where(mask)[0][0]] if np.any(mask) else x_axis[-1]
    
    # Plot Cell Lengths
    ax1.plot(x_axis, a_arr, label='a', alpha=0.8)
    ax1.plot(x_axis, b_arr, label='b', alpha=0.8)
    ax1.plot(x_axis, c_arr, label='c', alpha=0.8)
    
    # Add mean lines (dashed) for the averaged region
    if np.any(mask):
        ax1.axvline(x=start_x, color='k', linestyle=':', label='Start Avg')
        ax1.hlines(avg_a, start_x, x_axis[-1], colors='C0', linestyles='--')
        ax1.hlines(avg_b, start_x, x_axis[-1], colors='C1', linestyles='--')
        ax1.hlines(avg_c, start_x, x_axis[-1], colors='C2', linestyles='--')

    ax1.set_ylabel("Lattice Constant (Å)")
    ax1.legend(loc='upper right')
    ax1.grid(True, alpha=0.3)
    ax1.set_title(f"Cell Parameters Evolution (Skip {skip_ps} ps)")

    # Plot Volume
    ax2.plot(x_axis, v_arr, label='Volume', color='C3', alpha=0.9)
    if np.any(mask):
        ax2.axvline(x=start_x, color='k', linestyle=':')
        ax2.hlines(avg_v, start_x, x_axis[-1], colors='C3', linestyles='--')
        
    ax2.set_ylabel("Volume (Å$^3$)")
    ax2.set_xlabel(x_label)
    ax2.legend(loc='upper right')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plot_file = out_prefix_path.with_suffix(".pdf")
    plt.savefig(plot_file)
    log_print(f"Plot saved to {plot_file}")
    log_print(f"Log saved to {log_file}")

    summary = {
        "input": str(traj_path),
        "selection": selection_reason,
        "n_frames_total": int(n_steps),
        "n_frames_selected": int(np.sum(mask)),
        "avg": {"a": avg_a, "b": avg_b, "c": avg_c, "vol": avg_v},
        "std": {"a": std_a, "b": std_b, "c": std_c, "vol": std_v},
        "stats": {"a": stats_a, "b": stats_b, "c": stats_c, "vol": stats_v},
        "drift_per_axis_unit": {"a": drift_a, "b": drift_b, "c": drift_c, "vol": drift_v},
        "temperature_k": float(temperature_k) if temperature_k is not None else None,
        "bulk_modulus_estimate_gpa": bulk_modulus_gpa,
        "strain_summary": strain_summary,
        "symmetry_counts": symmetry_counts,
        "adp_species_summary": adp_species_summary,
        "adp_top_sites": adp_rank_top,
    }
    if report:
        report_path = out_prefix_path.with_suffix(".report.yaml")
        with open(report_path, "w") as f:
            yaml.safe_dump(summary, f, sort_keys=False)
        log_print(f"Report bundle saved to: {report_path}")

    return summary


def _select_even_jitter_indices(n_total: int, n_target: int, seed: int | None = None) -> list[int]:
    if n_target >= n_total:
        return list(range(n_total))
    if n_target <= 0:
        return []
    rng = np.random.default_rng(seed)
    edges = np.linspace(0, n_total, n_target + 1, dtype=int)
    selected: list[int] = []
    used: set[int] = set()
    for i in range(n_target):
        lo = int(edges[i])
        hi = int(max(edges[i + 1], lo + 1))
        hi = min(hi, n_total)
        candidates = [k for k in range(lo, hi) if k not in used]
        if not candidates:
            candidates = [k for k in range(n_total) if k not in used]
        pick = int(rng.choice(candidates))
        selected.append(pick)
        used.add(pick)
    selected.sort()
    return selected


def run_xt_force_constant(
    input_paths,
    *,
    fc3=False,
    format_hint="auto",
    ff="mattersim",
    model_path=None,
    device="cpu",
    modal=None,
    sequential=False,
    batch_size=None,
    stride=1,
    max_samples=None,
    nstep=None,
    n_traj=None,
    traj_select_seed=None,
    symprec=1e-5,
    output_force_constants="FORCE_CONSTANTS_XT",
    output_fc3_hdf5="fc3_xt.hdf5",
    output_log="xt_fc_fit_metrics.log",
):
    """Fit FC2/FC3 from trajectory frames using MLFF force labels + symfc."""
    from phonopy import Phonopy
    from phonopy.file_IO import write_FORCE_CONSTANTS
    from phonopy.harmonic.force_constants import set_translational_invariance
    from phonopy.structure.atoms import PhonopyAtoms
    from macer.calculator.factory import get_calculator, evaluate_batch, evaluate_sequential

    if batch_size is not None and int(batch_size) < 1:
        raise ValueError("--batch-size must be >= 1 when provided.")
    if int(stride) < 1:
        raise ValueError("--stride must be >= 1.")

    merged_frames = []
    for p in input_paths:
        traj_path = Path(str(p)).expanduser().resolve()
        if not traj_path.exists():
            raise FileNotFoundError(f"Trajectory not found: {traj_path}")
        traj = _read_trajectory_robust(traj_path, format_hint=format_hint)
        if not traj:
            continue
        merged_frames.extend([a.copy() for a in traj])

    if not merged_frames:
        raise ValueError("No trajectory frames loaded from --input.")

    natoms = len(merged_frames[0])
    ref_syms = merged_frames[0].get_chemical_symbols()
    ref_cell = np.array(merged_frames[0].cell, dtype=float)
    for i, at in enumerate(merged_frames, start=1):
        if len(at) != natoms:
            raise ValueError(f"Frame atom count mismatch at frame {i}: {len(at)} != {natoms}")
        if at.get_chemical_symbols() != ref_syms:
            raise ValueError(f"Chemical symbol order mismatch at frame {i}.")
        if not np.allclose(np.array(at.cell, dtype=float), ref_cell, atol=1e-6, rtol=1e-8):
            raise ValueError(
                "Variable-cell trajectory detected. `macer util fc` currently supports fixed-cell trajectories only "
                "(NPT-style trajectories are not supported in this mode)."
            )

    frame_indices = list(range(0, len(merged_frames), int(stride)))
    if max_samples is not None:
        frame_indices = frame_indices[: int(max_samples)]
    if nstep is not None:
        nstep_int = int(nstep)
        if nstep_int < 1:
            raise ValueError("--nstep must be >= 1 when provided.")
        frame_indices = frame_indices[:nstep_int]
    candidate_count = int(len(frame_indices))
    n_req = int(n_traj) if n_traj is not None else 0
    if n_req > 0 and candidate_count > 0:
        if candidate_count <= n_req:
            print(
                f"[xt] FC extraction requested n_traj={n_req}, "
                f"but only {candidate_count} candidate frames are available; using all."
            )
        else:
            rel = _select_even_jitter_indices(candidate_count, n_req, seed=traj_select_seed)
            frame_indices = [frame_indices[i] for i in rel]
    if not frame_indices:
        raise ValueError("No frames selected after stride/max-samples filtering.")

    frames = [merged_frames[i] for i in frame_indices]
    print(
        f"[xt] FC source: trajectories(total)={len(merged_frames)}, "
        f"trajectories(candidates)={candidate_count}, trajectories(used)={len(frames)} "
        f"(format={format_hint}, stride={int(stride)}"
        + (f", max_samples={int(max_samples)}" if max_samples is not None else "")
        + (f", nstep={int(nstep)}" if nstep is not None else "")
        + (f", n_traj={n_req}" if n_req > 0 else "")
        + (f", traj_select_seed={int(traj_select_seed)}" if (n_req > 0 and traj_select_seed is not None) else "")
        + ")."
    )

    calc_kwargs = {"device": device}
    if ff == "mace":
        calc_kwargs["model_paths"] = [model_path]
    else:
        calc_kwargs["model_path"] = model_path
    if modal is not None:
        calc_kwargs["modal"] = modal
    calc = get_calculator(ff_name=ff, **calc_kwargs)

    pred = None
    use_sequential = bool(sequential)
    if not use_sequential:
        try:
            pred = evaluate_batch(
                calc,
                frames,
                batch_size=batch_size,
                properties=["forces"],
            )
        except Exception as exc:
            print(f"[xt] Warning: batch force evaluation failed ({exc}); falling back to sequential.")
            use_sequential = True
    if use_sequential:
        if sequential:
            print("[xt] INFO: Running in forced sequential mode (--sequential).")
        pred = evaluate_sequential(calc, frames, properties=["forces"])

    forces = np.array(pred["forces"], dtype=float)
    ref = frames[0]
    ref_scaled = ref.get_scaled_positions(wrap=True)
    cell = np.array(ref.cell, dtype=float)
    disps = []
    for at in frames:
        scaled = at.get_scaled_positions(wrap=True)
        dfrac = scaled - ref_scaled
        dfrac -= np.round(dfrac)
        disps.append(dfrac @ cell)
    U = np.array(disps, dtype=float)
    F = np.array(forces, dtype=float)
    nsamples = int(U.shape[0])

    print(
        f"[xt] FC dataset: trajectories(total)={len(merged_frames)}, trajectories(used)={len(frames)}, "
        f"samples_used_by_symfc={nsamples}."
    )

    unit = PhonopyAtoms(
        symbols=ref.get_chemical_symbols(),
        cell=np.array(ref.cell, dtype=float),
        scaled_positions=ref.get_scaled_positions(),
    )
    solver = "symfc"
    solver_log_level = 2

    metrics = {
        "input_paths": [str(Path(p).expanduser().resolve()) for p in input_paths],
        "fc_order": 3 if bool(fc3) else 2,
        "ff": str(ff),
        "device": str(device),
        "n_frames_total": int(len(merged_frames)),
        "n_frames_candidates": int(candidate_count),
        "n_frames_used": int(len(frames)),
        "n_samples": int(nsamples),
        "n_atoms": int(natoms),
        "symprec": float(symprec),
        "solver": solver,
        "solver_log_level": int(solver_log_level),
    }

    ph = Phonopy(unit, np.eye(3, dtype=int), symprec=float(symprec))
    ph.dataset = {"displacements": U, "forces": F}
    if hasattr(ph, "_log_level"):
        try:
            ph._log_level = solver_log_level
        except Exception:
            pass
    print(f"FC solver selected: {solver}")
    print(f"FC solver log level: {solver_log_level}")
    ph.produce_force_constants(fc_calculator=solver)
    if ph.force_constants is None:
        raise RuntimeError("symfc failed to produce FC2.")
    fc2 = np.array(ph.force_constants, dtype=float, copy=True)
    set_translational_invariance(fc2)
    ph.force_constants = fc2
    out_fc2 = Path(output_force_constants).expanduser().resolve()
    out_fc2.parent.mkdir(parents=True, exist_ok=True)
    write_FORCE_CONSTANTS(ph.force_constants, filename=str(out_fc2))
    metrics["output_force_constants"] = str(out_fc2)
    print(f"Wrote FC2: {out_fc2}")

    if bool(fc3):
        from phono3py import Phono3py
        from phono3py.file_IO import write_fc3_to_hdf5

        ph3 = Phono3py(
            unitcell=unit,
            supercell_matrix=np.eye(3, dtype=int),
            primitive_matrix=np.eye(3, dtype=int),
            symprec=float(symprec),
        )
        ph3.dataset = {"displacements": U, "forces": F}
        if hasattr(ph3, "_log_level"):
            try:
                ph3._log_level = solver_log_level
            except Exception:
                pass
        ph3.produce_fc3(fc_calculator=solver, fc_calculator_options=None)
        out_fc3 = Path(output_fc3_hdf5).expanduser().resolve()
        out_fc3.parent.mkdir(parents=True, exist_ok=True)
        write_fc3_to_hdf5(ph3.fc3, filename=str(out_fc3))
        metrics["output_fc3_hdf5"] = str(out_fc3)
        print(f"Wrote FC3: {out_fc3}")

    out_log = Path(output_log).expanduser().resolve()
    out_log.parent.mkdir(parents=True, exist_ok=True)
    with out_log.open("w") as fp:
        fp.write("# XT force-constant fit diagnostics\n")
        for k in sorted(metrics.keys()):
            fp.write(f"{k}: {metrics[k]}\n")
    print(f"Wrote log: {out_log}")
