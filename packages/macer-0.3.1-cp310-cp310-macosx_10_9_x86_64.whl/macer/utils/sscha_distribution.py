import argparse
import json
from collections import defaultdict
from pathlib import Path

import numpy as np


def build_sscha_distribution_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(
            prog="macer util sscha distribution-rebuild",
            description="Rebuild element-wise displacement distributions from stored SSCHA cycle snapshots.",
        )
    parser.add_argument("--dir", required=True, help="SSCHA output directory.")
    parser.add_argument("--cycle", type=int, required=True, help="Cycle index that provides U/logp_origin.")
    parser.add_argument("--target-cycle", type=int, default=None, help="Cycle index for logp_current (default: same as --cycle).")
    parser.add_argument("-p", "--poscar", default=None, help="Reference POSCAR (default: <dir>/POSCAR_qscaild_input).")
    parser.add_argument("--dim", nargs="+", type=int, required=True, help="Supercell dim (3 or 9 integers), required for mapping.")
    parser.add_argument("--symprec", type=float, default=5e-3, help="Phonopy symmetry tolerance (default: 5e-3).")
    parser.add_argument("--distribution-axis", type=float, nargs=3, default=None, metavar=("A", "B", "C"), help="Optional fractional projection axis.")
    parser.add_argument("--bins", type=int, default=100, help="Number of histogram bins (default: 100).")
    parser.add_argument("--output-prefix", default="distribution_rebuild", help="Output filename prefix.")
    parser.add_argument("--json-out", default=None, help="Optional JSON summary output.")
    return parser


def run_sscha_distribution(args):
    run_dir = Path(args.dir).expanduser().resolve()
    cyc = int(args.cycle)
    tgt = int(args.target_cycle if args.target_cycle is not None else args.cycle)
    cdir = run_dir / f"cycle_{cyc:03d}"
    if not cdir.exists():
        raise FileNotFoundError(f"Cycle directory not found: {cdir}")

    poscar = Path(args.poscar).expanduser().resolve() if args.poscar else (run_dir / "POSCAR_qscaild_input")
    if not poscar.exists():
        raise FileNotFoundError(f"POSCAR not found: {poscar}")

    from phonopy import Phonopy
    from phonopy.interface.vasp import read_vasp

    dim = _dim_to_matrix(args.dim)
    unitcell = read_vasp(str(poscar))
    ph = Phonopy(unitcell, supercell_matrix=dim, primitive_matrix="auto", symprec=float(args.symprec))
    groups = _primitive_groups_from_phonopy(ph)
    prim_symbols = list(ph.primitive.symbols)

    U = _load_saved_array(cdir / "U")
    w = _load_weights(cdir, tgt)
    if U.shape[0] != w.shape[0]:
        raise ValueError("U/logp snapshot count mismatch")
    if U.shape[1] != len(ph.supercell):
        raise ValueError("U atom count does not match POSCAR+dim supercell")

    U_wrap = _minimum_image_displacements(U, np.asarray(ph.supercell.cell, dtype=float))
    U_avg = np.sum(w[:, None, None] * U_wrap, axis=0)
    du = U_wrap - U_avg[None, :, :]

    proj_unit = _projection_unit_vector_from_fractional(np.asarray(ph.primitive.cell, dtype=float), args.distribution_axis)
    by_elem_dxyz = defaultdict(list)
    by_elem_w = defaultdict(list)
    for p_idx, g in enumerate(groups):
        x = du[:, g, :].reshape(-1, 3)
        wp = np.repeat(w / len(g), len(g))
        wp /= np.sum(wp)
        by_elem_dxyz[prim_symbols[p_idx]].append(x)
        by_elem_w[prim_symbols[p_idx]].append(wp)

    results = []
    for sym in sorted(by_elem_dxyz.keys()):
        dxyz = np.concatenate(by_elem_dxyz[sym], axis=0)
        we = np.concatenate(by_elem_w[sym], axis=0)
        we /= np.sum(we)
        vals_x = dxyz[:, 0]
        vals_y = dxyz[:, 1]
        vals_z = dxyz[:, 2]
        vals_proj = dxyz @ proj_unit if proj_unit is not None else None

        max_abs = max(
            float(np.max(np.abs(vals_x))),
            float(np.max(np.abs(vals_y))),
            float(np.max(np.abs(vals_z))),
            float(np.max(np.abs(vals_proj))) if vals_proj is not None else 0.0,
        )
        xlim = max(1e-4, 1.05 * max_abs)
        bins = np.linspace(-xlim, xlim, int(args.bins) + 1)
        centers = 0.5 * (bins[:-1] + bins[1:])
        hx, _ = np.histogram(vals_x, bins=bins, weights=we, density=True)
        hy, _ = np.histogram(vals_y, bins=bins, weights=we, density=True)
        hz, _ = np.histogram(vals_z, bins=bins, weights=we, density=True)

        out_dat = run_dir / f"{args.output_prefix}_cycle_{cyc:04d}_target_{tgt:04d}_element_{sym}.dat"
        if vals_proj is not None:
            hp, _ = np.histogram(vals_proj, bins=bins, weights=we, density=True)
            arr = np.column_stack((centers, hx, hy, hz, hp))
            header = "disp_A  pdf_x  pdf_y  pdf_z  pdf_proj"
        else:
            arr = np.column_stack((centers, hx, hy, hz))
            header = "disp_A  pdf_x  pdf_y  pdf_z"
        np.savetxt(out_dat, arr, fmt="%.8e", header=header)

        stats = {
            "element": sym,
            "var_x": _wvar(vals_x, we),
            "var_y": _wvar(vals_y, we),
            "var_z": _wvar(vals_z, we),
            "skew_x": _wskew(vals_x, we),
            "skew_y": _wskew(vals_y, we),
            "skew_z": _wskew(vals_z, we),
            "kurt_x": _wkurt(vals_x, we),
            "kurt_y": _wkurt(vals_y, we),
            "kurt_z": _wkurt(vals_z, we),
            "output_dat": str(out_dat),
        }
        results.append(stats)
        print(f"Wrote distribution: {out_dat}")

    payload = {
        "run_dir": str(run_dir),
        "cycle": cyc,
        "target_cycle": tgt,
        "results": results,
    }
    if args.json_out:
        out = Path(args.json_out).expanduser().resolve()
        out.write_text(json.dumps(payload, indent=2))
        print(f"Wrote JSON: {out}")
    return payload


def _dim_to_matrix(dim_list):
    if len(dim_list) == 3:
        return np.diag(dim_list)
    if len(dim_list) == 9:
        return np.asarray(dim_list, dtype=int).reshape(3, 3)
    raise ValueError("--dim must have 3 or 9 integers.")


def _load_saved_array(stem: Path):
    npy = Path(f"{stem}.npy")
    if npy.exists():
        return np.load(npy)
    dat = Path(f"{stem}.dat")
    if not dat.exists():
        raise FileNotFoundError(f"missing both {npy} and {dat}")
    with open(dat, "r") as f:
        first = f.readline().strip()
    if not first.startswith("# shape "):
        raise ValueError(f"Missing shape header in {dat}")
    shape = tuple(int(x) for x in first.replace("#", "").split()[1:])
    raw = np.loadtxt(dat, comments="#")
    if len(shape) == 1:
        if np.ndim(raw) == 1:
            return np.array([float(raw[-1])], dtype=float)
        return np.asarray(raw[:, -1], dtype=float)
    return np.atleast_2d(raw).reshape(shape)


def _load_weights(cycle_dir: Path, target_cycle: int):
    cur = _load_saved_array(cycle_dir / f"logp_current_cycle_{target_cycle:03d}").reshape(-1)
    ori = _load_saved_array(cycle_dir / "logp_origin").reshape(-1)
    if cur.shape != ori.shape:
        raise ValueError("logp shape mismatch")
    logw = cur - ori
    shift = float(np.max(logw))
    w = np.exp(logw - shift)
    w /= float(np.sum(w))
    return w


def _minimum_image_displacements(U: np.ndarray, cell: np.ndarray) -> np.ndarray:
    frac = np.einsum("...j,jk->...k", U, np.linalg.inv(cell))
    frac -= np.rint(frac)
    return np.einsum("...j,jk->...k", frac, cell)


def _primitive_groups_from_phonopy(ph):
    p2p = ph.primitive.p2p_map
    s2p = ph.primitive.s2p_map
    nat_prim = len(ph.primitive)
    groups = [[] for _ in range(nat_prim)]
    for s_idx, p_rep in enumerate(s2p):
        p_idx = p2p[int(p_rep)]
        groups[p_idx].append(s_idx)
    return [np.array(g, dtype=int) for g in groups]


def _projection_unit_vector_from_fractional(cell: np.ndarray, frac_axis):
    if frac_axis is None:
        return None
    vfrac = np.asarray(frac_axis, dtype=float).reshape(3)
    if np.linalg.norm(vfrac) < 1e-12:
        raise ValueError("--distribution-axis cannot be zero")
    vcart = vfrac @ np.asarray(cell, dtype=float)
    nv = np.linalg.norm(vcart)
    if nv < 1e-12:
        raise ValueError("--distribution-axis is near zero in Cartesian basis")
    return vcart / nv


def _wmean(x, w):
    return float(np.sum(w * x))


def _wvar(x, w):
    m = _wmean(x, w)
    return float(np.sum(w * (x - m) ** 2))


def _wskew(x, w):
    m = _wmean(x, w)
    v = _wvar(x, w)
    if v <= 0:
        return 0.0
    s = np.sqrt(v)
    return float(np.sum(w * ((x - m) / s) ** 3))


def _wkurt(x, w):
    m = _wmean(x, w)
    v = _wvar(x, w)
    if v <= 0:
        return 0.0
    s2 = v
    return float(np.sum(w * ((x - m) ** 4) / (s2**2)) - 3.0)
