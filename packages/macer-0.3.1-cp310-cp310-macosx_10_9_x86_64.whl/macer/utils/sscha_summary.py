import argparse
import json
import re
from pathlib import Path

import numpy as np


def build_sscha_summary_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(
            prog="macer util sscha-summary",
            description="Summarize QSCAILD output quality without rerunning calculations.",
        )
    parser.add_argument("--dir", required=True, help="SSCHA output directory.")
    parser.add_argument("--show-cycles", type=int, default=5, help="Show recent N cycles (default: 5).")
    parser.add_argument("--json-out", default=None, help="Write summary JSON.")
    parser.add_argument("--strict", action="store_true", help="Fail if required files are missing.")
    return parser


def run_sscha_summary(args):
    summary = summarize_sscha_directory(Path(args.dir).expanduser().resolve(), show_cycles=args.show_cycles, strict=args.strict)
    _print_summary(summary, show_cycles=args.show_cycles)
    if args.json_out:
        out = Path(args.json_out).expanduser().resolve()
        out.write_text(json.dumps(summary, indent=2))
        print(f"Wrote JSON: {out}")
    return summary


def summarize_sscha_directory(run_dir: Path, show_cycles: int = 5, strict: bool = False):
    if not run_dir.exists():
        raise FileNotFoundError(f"Directory not found: {run_dir}")

    cycle_dirs = sorted([p for p in run_dir.glob("cycle_*") if p.is_dir()], key=lambda x: x.name)
    cycle_ids = [int(p.name.split("_")[1]) for p in cycle_dirs if "_" in p.name]
    last_cycle = max(cycle_ids) if cycle_ids else None
    iteration_file = run_dir / "iteration"
    if iteration_file.exists():
        try:
            last_cycle = int(iteration_file.read_text().strip())
        except Exception:
            pass

    out_fit_rows = _read_numeric_rows(_pick_existing(run_dir, ["out_fit.txt", "out_fit"]))
    out_conv_rows = _read_numeric_rows(_pick_existing(run_dir, ["out_convergence.txt", "out_convergence"]))

    fc_diff_last = float(out_conv_rows[-1][1]) if out_conv_rows and len(out_conv_rows[-1]) >= 2 else float("nan")
    tol = _extract_tolerance_from_log(run_dir)
    fc_ratio = fc_diff_last / tol if np.isfinite(fc_diff_last) and np.isfinite(tol) and tol > 0 else float("nan")

    integrity = _check_integrity(cycle_dirs)
    weight_quality = _compute_weight_quality(cycle_dirs)
    energy_trend = _energy_trend(out_fit_rows)

    status = "OK"
    if integrity["missing_files"] or integrity["shape_mismatch"] or integrity["nan_detected"]:
        status = "UNRELIABLE"
    elif (np.isfinite(fc_ratio) and fc_ratio > 1.0) or weight_quality["min_ess_ratio"] < 0.05:
        status = "REVIEW"

    summary = {
        "run_dir": str(run_dir),
        "cycles_total": len(cycle_dirs),
        "last_cycle": last_cycle,
        "fc_diff_last": fc_diff_last,
        "tolerance": tol,
        "fc_ratio": fc_ratio,
        "status": status,
        "weight_quality": weight_quality,
        "energy_trend": energy_trend,
        "integrity": integrity,
        "recent_cycles": cycle_ids[-max(1, int(show_cycles)) :] if cycle_ids else [],
    }
    if strict and status == "UNRELIABLE":
        raise ValueError("Summary strict mode failed due to integrity issues.")
    return summary


def _pick_existing(base: Path, names):
    for n in names:
        p = base / n
        if p.exists():
            return p
    return None


def _read_numeric_rows(path: Path | None):
    if path is None or not path.exists():
        return []
    rows = []
    with path.open("r") as f:
        for ln in f:
            s = ln.strip()
            if (not s) or s.startswith("#"):
                continue
            try:
                rows.append([float(x) for x in s.split()])
            except Exception:
                continue
    return rows


def _extract_tolerance_from_log(run_dir: Path):
    for name in ["macer_sscha.log", "macer_qscaild.log"]:
        p = run_dir / name
        if not p.exists():
            continue
        txt = p.read_text(errors="ignore")
        m_all = re.findall(r"target<([0-9eE+\-.]+)", txt)
        if m_all:
            try:
                return float(m_all[-1])
            except Exception:
                pass
    return float("nan")


def _load_saved_array(stem: Path):
    npy = Path(f"{stem}.npy")
    if npy.exists():
        return np.load(npy)
    dat = Path(f"{stem}.dat")
    if not dat.exists():
        raise FileNotFoundError(f"missing: {dat}")
    with dat.open("r") as f:
        first = f.readline().strip()
    if not first.startswith("# shape "):
        raise ValueError(f"invalid shape header: {dat}")
    shape = tuple(int(x) for x in first.replace("#", "").split()[1:])
    raw = np.loadtxt(dat, comments="#")
    if len(shape) == 1:
        if np.ndim(raw) == 1:
            return np.array([float(raw[-1])], dtype=float)
        return np.asarray(raw[:, -1], dtype=float)
    return np.atleast_2d(raw).reshape(shape)


def _check_integrity(cycle_dirs):
    missing_files = []
    shape_mismatch = []
    nan_detected = []
    snapshots = []
    for cdir in cycle_dirs:
        for stem in ["U", "F", "E", "logp_origin", "FC_origin"]:
            p = cdir / f"{stem}.dat"
            n = cdir / f"{stem}.npy"
            if not p.exists() and not n.exists():
                missing_files.append(f"{cdir.name}/{stem}")
        try:
            U = _load_saved_array(cdir / "U")
            F = _load_saved_array(cdir / "F")
            E = _load_saved_array(cdir / "E")
            if U.shape != F.shape or U.shape[0] != E.shape[0]:
                shape_mismatch.append(cdir.name)
            snapshots.append(int(U.shape[0]))
            if (not np.all(np.isfinite(U))) or (not np.all(np.isfinite(F))) or (not np.all(np.isfinite(E))):
                nan_detected.append(cdir.name)
        except Exception:
            shape_mismatch.append(cdir.name)
    return {
        "missing_files": sorted(set(missing_files)),
        "shape_mismatch": sorted(set(shape_mismatch)),
        "nan_detected": sorted(set(nan_detected)),
        "snapshot_min": int(min(snapshots)) if snapshots else 0,
        "snapshot_max": int(max(snapshots)) if snapshots else 0,
    }


def _compute_weight_quality(cycle_dirs):
    ess_ratios = []
    flagged = []
    for cdir in cycle_dirs:
        try:
            logp_origin = _load_saved_array(cdir / "logp_origin").reshape(-1)
        except Exception:
            continue
        for p in sorted(cdir.glob("logp_current_cycle_*.dat")):
            try:
                curr = _load_saved_array(cdir / p.stem).reshape(-1)
                if curr.shape != logp_origin.shape:
                    continue
                logw = curr - logp_origin
                shift = float(np.max(logw))
                w = np.exp(logw - shift)
                wsum = float(np.sum(w))
                if not np.isfinite(wsum) or wsum <= 0:
                    continue
                w /= wsum
                ess = 1.0 / float(np.sum(w**2))
                ratio = ess / float(len(w))
                ess_ratios.append(ratio)
                if ratio < 0.05:
                    flagged.append(f"{cdir.name}:{p.name}")
            except Exception:
                continue
    return {
        "min_ess_ratio": float(min(ess_ratios)) if ess_ratios else float("nan"),
        "mean_ess_ratio": float(np.mean(ess_ratios)) if ess_ratios else float("nan"),
        "n_weight_checks": int(len(ess_ratios)),
        "flagged_cycles": flagged[:20],
    }


def _energy_trend(out_fit_rows):
    if not out_fit_rows:
        return {"state": "unknown"}
    fe = [r[7] for r in out_fit_rows if len(r) >= 8 and np.isfinite(r[7])]
    if len(fe) < 3:
        return {"state": "insufficient_points"}
    y = np.asarray(fe[-5:], dtype=float)
    dy = np.diff(y)
    slope = float(np.mean(dy))
    osc = float(np.std(dy))
    if abs(slope) < 1e-3 and osc < 5e-3:
        state = "stable"
    elif slope < 0:
        state = "decreasing"
    elif slope > 0:
        state = "increasing"
    else:
        state = "oscillatory"
    return {"state": state, "recent_mean_delta": slope, "recent_std_delta": osc}


def _print_summary(s, show_cycles=5):
    print("SSCHA Summary")
    print("-" * 72)
    print(f"Run dir       : {s['run_dir']}")
    print(f"Cycles total  : {s['cycles_total']}")
    print(f"Last cycle    : {s['last_cycle']}")
    print(f"FC diff last  : {s['fc_diff_last']:.6e}")
    if np.isfinite(s["tolerance"]):
        print(f"Tolerance     : {s['tolerance']:.6e}")
    if np.isfinite(s["fc_ratio"]):
        print(f"FC ratio      : {s['fc_ratio']:.2f}x")
    print(f"ESS(min/mean) : {s['weight_quality']['min_ess_ratio']:.4f} / {s['weight_quality']['mean_ess_ratio']:.4f}")
    print(f"Energy trend  : {s['energy_trend']['state']}")
    print(f"Status        : {s['status']}")
    if s["integrity"]["missing_files"]:
        print(f"Missing files : {len(s['integrity']['missing_files'])} (showing up to 5)")
        for x in s["integrity"]["missing_files"][:5]:
            print(f"  - {x}")
    if s["integrity"]["shape_mismatch"]:
        print(f"Shape mismatch: {len(s['integrity']['shape_mismatch'])}")
    if s["integrity"]["nan_detected"]:
        print(f"NaN detected  : {len(s['integrity']['nan_detected'])}")
    print(f"Recent cycles : {s['recent_cycles'][-max(1, int(show_cycles)):]}")
