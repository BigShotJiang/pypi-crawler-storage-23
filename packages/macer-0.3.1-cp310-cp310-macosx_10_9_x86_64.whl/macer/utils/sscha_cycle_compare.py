import argparse
import json
from pathlib import Path

import numpy as np


def build_sscha_cycle_compare_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(
            prog="macer util sscha cycle-compare",
            description="Compare two SSCHA cycles (energy/force/displacement statistics).",
        )
    parser.add_argument("--dir", required=True, help="SSCHA output directory.")
    parser.add_argument("--a", type=int, required=True, help="First cycle index.")
    parser.add_argument("--b", type=int, required=True, help="Second cycle index.")
    parser.add_argument("--json-out", default=None, help="Optional JSON output.")
    return parser


def run_sscha_cycle_compare(args):
    run_dir = Path(args.dir).expanduser().resolve()
    ca, cb = int(args.a), int(args.b)
    da = run_dir / f"cycle_{ca:03d}"
    db = run_dir / f"cycle_{cb:03d}"
    if not da.exists() or not db.exists():
        raise FileNotFoundError(f"missing cycle dir: {da if not da.exists() else db}")

    sa = _stats_for_cycle(da)
    sb = _stats_for_cycle(db)
    score_a = _quality_score(sa)
    score_b = _quality_score(sb)
    recommend = ca if score_a >= score_b else cb

    report = {
        "run_dir": str(run_dir),
        "cycle_a": {"index": ca, **sa, "quality_score": score_a},
        "cycle_b": {"index": cb, **sb, "quality_score": score_b},
        "recommended_cycle": recommend,
        "reason": "higher_quality_score",
    }

    print("SSCHA Cycle Compare")
    print("-" * 72)
    print(f"Cycle A ({ca}): score={score_a:.3f}, nconf={sa['nconf']}, E_std={sa['energy_std']:.6e}, F_rms={sa['force_rms']:.6e}, U_rms={sa['disp_rms']:.6e}")
    print(f"Cycle B ({cb}): score={score_b:.3f}, nconf={sb['nconf']}, E_std={sb['energy_std']:.6e}, F_rms={sb['force_rms']:.6e}, U_rms={sb['disp_rms']:.6e}")
    print(f"Recommended cycle: {recommend}")

    if args.json_out:
        out = Path(args.json_out).expanduser().resolve()
        out.write_text(json.dumps(report, indent=2))
        print(f"Wrote JSON: {out}")
    return report


def _stats_for_cycle(cdir: Path):
    U = _load_saved_array(cdir / "U")
    F = _load_saved_array(cdir / "F")
    E = _load_saved_array(cdir / "E").reshape(-1)
    nconf = int(U.shape[0])
    disp_rms = float(np.sqrt(np.mean(U**2)))
    force_rms = float(np.sqrt(np.mean(F**2)))
    energy_std = float(np.std(E))
    energy_mean = float(np.mean(E))
    return {
        "nconf": nconf,
        "disp_rms": disp_rms,
        "force_rms": force_rms,
        "energy_mean": energy_mean,
        "energy_std": energy_std,
    }


def _quality_score(s):
    # Larger is better: prefer more snapshots and lower force/energy spread.
    return float(np.log(max(1, s["nconf"])) - 5.0 * s["force_rms"] - 10.0 * s["energy_std"])


def _load_saved_array(stem: Path):
    npy = Path(f"{stem}.npy")
    if npy.exists():
        return np.load(npy)
    dat = Path(f"{stem}.dat")
    if not dat.exists():
        raise FileNotFoundError(f"missing both {npy} and {dat}")
    with dat.open("r") as f:
        first = f.readline().strip()
    if not first.startswith("# shape "):
        raise ValueError(f"Missing shape header in {dat}")
    shape = tuple(int(x) for x in first.replace("#", "").split()[1:])
    raw = np.loadtxt(dat, comments="#")
    if len(shape) == 1:
        if np.ndim(raw) == 1:
            return np.array([float(raw[-1])], dtype=float)
        return np.asarray(raw[:, -1], dtype=float)
    return np.atleast_2d(raw).reshape(shape)
