import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import yaml
from ase.io import read


KBAR_A3_TO_EV = (1.0e8 * 1.0e-30) / 1.602176634e-19


def build_sscha_thermo_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(
            prog="macer util sscha thermo",
            description="Post-process QSCAILD directories to estimate F/S/U/H/G without rerunning.",
            formatter_class=argparse.RawDescriptionHelpFormatter,
        )
    parser.add_argument("--dir", default=None, help="Single SSCHA result directory.")
    parser.add_argument("--dirs", nargs="+", default=None, help="SSCHA result directories (multiple temperatures).")
    parser.add_argument("--manifest", default=None, help="Path to thermo_manifest.yaml.")
    parser.add_argument(
        "--temperature-k",
        type=float,
        default=None,
        help="Fallback temperature in K when it cannot be inferred from directory/log names.",
    )
    parser.add_argument("--f-source", choices=["history", "last"], default="history", help="Free-energy source (default: history).")
    parser.add_argument(
        "--s-method",
        choices=["finite-diff", "poly-deriv", "phonopy-tp"],
        default=None,
        help="Entropy estimation method. Default: auto (single-run=phonopy-tp, multi-run=finite-diff).",
    )
    parser.add_argument("--fit-order", type=int, default=2, help="Polynomial order for --s-method poly-deriv (default: 2).")
    parser.add_argument(
        "--thermal-properties-file",
        default="thermal_properties.yaml",
        help="Thermal properties YAML filename for --s-method phonopy-tp (default: thermal_properties.yaml).",
    )
    parser.add_argument(
        "--generate-thermal-properties",
        action="store_true",
        help="Auto-generate thermal_properties.yaml from FORCE_CONSTANTS_* when missing.",
    )
    parser.add_argument("--tp-dim", nargs=3, type=int, default=[1, 1, 1], metavar=("NA", "NB", "NC"), help="Supercell DIM for thermal-properties generation (default: 1 1 1).")
    parser.add_argument("--tp-mesh", nargs=3, type=int, default=[7, 7, 7], metavar=("MX", "MY", "MZ"), help="Phonopy mesh for thermal-properties generation (default: 7 7 7).")
    parser.add_argument("--tp-poscar", default=None, help="POSCAR-like file to use for thermal-properties generation.")
    parser.add_argument("--tp-fc-file", default=None, help="Force-constants file path (default: latest FORCE_CONSTANTS_* in run dir).")
    parser.add_argument("--tp-full-range", action="store_true", help="Generate thermal properties on a temperature range instead of single-point T.")
    parser.add_argument("--tp-tmin", type=float, default=0.0, help="Temperature min for --tp-full-range (K).")
    parser.add_argument("--tp-tmax", type=float, default=1500.0, help="Temperature max for --tp-full-range (K).")
    parser.add_argument("--tp-tstep", type=float, default=10.0, help="Temperature step for --tp-full-range (K).")
    parser.add_argument("--tp-symprec", type=float, default=1e-5, help="Symmetry tolerance for phonopy generation.")
    parser.add_argument("--pressure-mode", choices=["auto", "const", "target"], default="auto", help="Pressure mode for PV term.")
    parser.add_argument("--pressure-value", type=float, default=0.0, help="Pressure in kbar for --pressure-mode const.")
    parser.add_argument("--target-pressure", type=float, default=0.0, help="Pressure in kbar for --pressure-mode target.")
    parser.add_argument("--json-out", default=None, help="Write JSON output.")
    parser.add_argument("--csv-out", default=None, help="Write CSV output.")
    parser.add_argument("--with-summary", action="store_true", help="Also compute SSCHA summary for each run directory.")
    parser.add_argument("--strict", action="store_true", help="Fail on missing/mismatched inputs.")
    return parser


def run_sscha_thermo(args) -> int:
    runs, settings = _collect_runs(args)
    if len(runs) < 1:
        raise ValueError("No valid run directories found for thermo post-analysis.")

    if len(runs) == 1:
        rows, notes = _compute_single_temperature_row(runs, settings)
    else:
        rows, notes = _compute_thermo_rows(runs, settings)
    _print_table(rows, notes)
    if len(rows) > 1 and settings.get("s_method") != "phonopy-tp":
        print("Tip: You can also run DOS-based entropy mode with `--s-method phonopy-tp`")
        print("     (requires per-run `thermal_properties.yaml`; use `--generate-thermal-properties` if missing).")
    summaries = None
    if getattr(args, "with_summary", False):
        from macer.utils.sscha_summary import summarize_sscha_directory
        summaries = []
        for r in runs:
            d = r["dir"].split(",")[0]
            try:
                summaries.append(summarize_sscha_directory(Path(d), show_cycles=3, strict=False))
            except Exception as e:
                summaries.append({"run_dir": d, "status": "ERROR", "error": str(e)})
        print("Included SSCHA summary blocks for each run.")

    _write_outputs(rows, notes, settings, args.json_out, args.csv_out, summaries=summaries)
    return 0


def _collect_runs(args):
    if args.manifest:
        manifest = _load_manifest(Path(args.manifest))
        runs = manifest["runs"]
        settings = dict(manifest.get("global", {}))
    else:
        # Convenience mode priority:
        #   --dir > --dirs > cwd
        if getattr(args, "dir", None):
            runs = [{"dir": str(Path(args.dir).expanduser().resolve())}]
        elif args.dirs:
            runs = [{"dir": str(Path(d).expanduser().resolve())} for d in args.dirs]
        else:
            runs = [{"dir": str(Path.cwd().resolve())}]
        settings = {}

    settings.setdefault("f_source", args.f_source)
    settings.setdefault("s_method", args.s_method)
    settings.setdefault("fit_order", args.fit_order)
    settings.setdefault("thermal_properties_file", args.thermal_properties_file)
    settings.setdefault("pressure_mode", args.pressure_mode)
    settings.setdefault("pressure_value", args.pressure_value)
    settings.setdefault("target_pressure", args.target_pressure)

    # Early effective method for per-run pre-processing.
    # If a single run directory is explicitly provided and --s-method is omitted,
    # default to phonopy-tp (so missing thermal_properties.yaml can be auto-generated).
    if settings.get("s_method") is None and getattr(args, "dir", None) and not args.manifest and not args.dirs:
        settings["s_method"] = "phonopy-tp"

    parsed = []
    comp_ref = None
    comp_ref_dir = None
    issues = []
    for item in runs:
        rdir = Path(item["dir"]).expanduser().resolve()
        if not rdir.exists():
            issues.append(f"missing directory: {rdir}")
            continue
        t = item.get("temperature_K")
        if t is None:
            t = _infer_temperature_from_path(rdir)
        if t is None:
            t = _infer_temperature_from_logs(rdir)
        if t is None and args.temperature_k is not None:
            t = float(args.temperature_k)
        if t is None:
            issues.append(f"cannot infer temperature for: {rdir}")
            continue
        t = float(t)

        if settings["s_method"] == "phonopy-tp":
            _maybe_generate_thermal_properties(rdir=rdir, temperature=t, args=args, issues=issues)

        f_eV = _read_free_energy(rdir, settings["f_source"])
        v_a3, comp, n_atoms = _read_volume_and_composition(rdir)
        p_kbar = _read_pressure_kbar(rdir)

        if comp_ref is None:
            comp_ref = comp
            comp_ref_dir = rdir
        elif comp != comp_ref:
            issues.append(f"composition mismatch: {rdir} != {comp_ref_dir}")

        parsed.append(
            {
                "dir": str(rdir),
                "T_K": t,
                "F_eV": f_eV,
                "V_A3": v_a3,
                "P_auto_kbar": p_kbar,
                "N_atoms": int(n_atoms),
            }
        )

    if issues and args.strict:
        raise ValueError("; ".join(issues))
    if issues:
        print("Warnings:")
        for msg in issues:
            print(f"  - {msg}")

    # Merge duplicate temperatures by averaging.
    grouped = defaultdict(list)
    for r in parsed:
        grouped[r["T_K"]].append(r)
    merged = []
    for t in sorted(grouped.keys()):
        items = grouped[t]
        if len(items) == 1:
            merged.append(items[0])
            continue
        merged.append(
            {
                "dir": ",".join(i["dir"] for i in items),
                "T_K": t,
                "F_eV": float(np.mean([i["F_eV"] for i in items])),
                "V_A3": float(np.mean([i["V_A3"] for i in items])),
                "P_auto_kbar": float(np.nanmean([i["P_auto_kbar"] for i in items])),
                "N_atoms": int(round(float(np.mean([i["N_atoms"] for i in items])))),
            }
        )
    if settings.get("s_method") is None:
        settings["s_method"] = "phonopy-tp" if len(merged) <= 1 else "finite-diff"
    return merged, settings


def _compute_single_temperature_row(runs, settings):
    r = runs[0]
    T = float(r["T_K"])
    F = float(r["F_eV"])
    V = float(r["V_A3"])
    p_auto = float(r["P_auto_kbar"])

    mode = settings["pressure_mode"]
    s_method = settings.get("s_method", "finite-diff")
    if s_method == "phonopy-tp":
        try:
            S = _read_entropy_from_thermal_properties(Path(r["dir"]), T, settings["thermal_properties_file"])
            U = F + T * S
            base_note = f"single_temperature: S from {settings['thermal_properties_file']} (phonopy thermal properties)"
        except Exception:
            S = float("nan")
            U = float("nan")
            base_note = (
                f"single_temperature: failed to read {settings['thermal_properties_file']} "
                "(S/U set to NaN)"
            )
    else:
        S = float("nan")
        U = float("nan")
        base_note = "single_temperature: entropy/internal-energy derivatives are unavailable (S/U/H set to NaN)"
    if mode == "auto":
        P = p_auto if np.isfinite(p_auto) else 0.0
        notes = [
            base_note,
            "pressure-mode=auto (missing pressure -> 0.0 kbar)",
        ]
    elif mode == "const":
        P = float(settings["pressure_value"])
        notes = [
            base_note,
            f"pressure-mode=const ({P:.6g} kbar)",
        ]
    else:
        P = float(settings["target_pressure"])
        notes = [
            base_note,
            f"pressure-mode=target ({P:.6g} kbar)",
        ]

    PV = P * V * KBAR_A3_TO_EV
    row = {
        "dir": r["dir"],
        "T_K": T,
        "F_eV": F,
        "S_eV_per_K": S,
        "U_eV": U,
        "P_kbar": P,
        "V_A3": V,
        "N_atoms": int(r.get("N_atoms", 0)),
        "PV_eV": PV,
        "H_eV": (U + PV) if np.isfinite(U) else float("nan"),
        "G_eV": F + PV,
    }
    return [row], notes


def _compute_thermo_rows(runs, settings):
    runs = sorted(runs, key=lambda x: x["T_K"])
    T = np.asarray([r["T_K"] for r in runs], dtype=float)
    F = np.asarray([r["F_eV"] for r in runs], dtype=float)
    V = np.asarray([r["V_A3"] for r in runs], dtype=float)
    P_auto = np.asarray([r["P_auto_kbar"] for r in runs], dtype=float)

    if settings["s_method"] == "phonopy-tp":
        S = np.asarray(
            [
                _read_entropy_from_thermal_properties(Path(r["dir"]), float(t), settings["thermal_properties_file"])
                for r, t in zip(runs, T)
            ],
            dtype=float,
        )
        notes = [f"s-method=phonopy-tp ({settings['thermal_properties_file']})"]
    else:
        S = _estimate_entropy(T, F, settings["s_method"], int(settings["fit_order"]))
        notes = [f"s-method={settings['s_method']}"]
    U = F + T * S

    mode = settings["pressure_mode"]
    if mode == "auto":
        P = np.where(np.isfinite(P_auto), P_auto, 0.0)
        notes.append("pressure-mode=auto (missing pressure -> 0.0 kbar)")
    elif mode == "const":
        P = np.full_like(T, float(settings["pressure_value"]))
        notes.append(f"pressure-mode=const ({float(settings['pressure_value']):.6g} kbar)")
    else:
        P = np.full_like(T, float(settings["target_pressure"]))
        notes.append(f"pressure-mode=target ({float(settings['target_pressure']):.6g} kbar)")

    PV = P * V * KBAR_A3_TO_EV
    H = U + PV
    G = F + PV

    rows = []
    for i, run in enumerate(runs):
        rows.append(
            {
                "dir": run["dir"],
                "T_K": float(T[i]),
                "F_eV": float(F[i]),
                "S_eV_per_K": float(S[i]),
                "U_eV": float(U[i]),
                "P_kbar": float(P[i]),
                "V_A3": float(V[i]),
                "N_atoms": int(run.get("N_atoms", 0)),
                "PV_eV": float(PV[i]),
                "H_eV": float(H[i]),
                "G_eV": float(G[i]),
            }
        )
    return rows, notes


def _estimate_entropy(T, F, method: str, fit_order: int):
    if method not in {"finite-diff", "poly-deriv"}:
        raise ValueError(f"Unsupported entropy method for multi-T fit: {method}")
    n = len(T)
    if method == "poly-deriv":
        deg = max(1, min(int(fit_order), n - 1))
        coeff = np.polyfit(T, F, deg=deg)
        dcoeff = np.polyder(coeff)
        return -np.polyval(dcoeff, T)

    S = np.zeros_like(F)
    if n == 2:
        d = -(F[1] - F[0]) / (T[1] - T[0])
        S[:] = d
        return S
    for i in range(n):
        if i == 0:
            S[i] = -(F[1] - F[0]) / (T[1] - T[0])
        elif i == n - 1:
            S[i] = -(F[-1] - F[-2]) / (T[-1] - T[-2])
        else:
            S[i] = -(F[i + 1] - F[i - 1]) / (T[i + 1] - T[i - 1])
    return S


def _read_entropy_from_thermal_properties(run_dir: Path, target_t: float, filename: str) -> float:
    tp_path = run_dir / filename
    if not tp_path.exists() and filename != "thermal_properties.yaml":
        fallback = run_dir / "thermal_properties.yaml"
        tp_path = fallback if fallback.exists() else tp_path
    if not tp_path.exists():
        raise FileNotFoundError(f"thermal properties file not found: {tp_path}")

    with tp_path.open("r") as f:
        data = yaml.safe_load(f) or {}
    rows = data.get("thermal_properties", [])
    if not rows:
        raise ValueError(f"thermal_properties list is empty: {tp_path}")

    temps = np.asarray([float(x["temperature"]) for x in rows], dtype=float)
    entropies_j_per_mol_k = np.asarray([float(x["entropy"]) for x in rows], dtype=float)
    if len(temps) == 0:
        raise ValueError(f"no temperature points in: {tp_path}")

    s_j_per_mol_k = float(np.interp(float(target_t), temps, entropies_j_per_mol_k))
    # Convert J/mol-K -> eV/cell-K using eV/mol = 96485.33212331002 J/mol
    s_eV_per_K = s_j_per_mol_k / 96485.33212331002
    return s_eV_per_K


def _maybe_generate_thermal_properties(rdir: Path, temperature: float, args, issues: list[str]) -> None:
    tp_path = rdir / str(args.thermal_properties_file)
    if tp_path.exists():
        return
    auto_single_dir_mode = bool(getattr(args, "dir", None)) and not getattr(args, "dirs", None) and not getattr(args, "manifest", None)
    should_generate = bool(getattr(args, "generate_thermal_properties", False)) or auto_single_dir_mode
    if not should_generate:
        return
    try:
        _generate_thermal_properties(rdir=rdir, temperature=temperature, args=args, out_path=tp_path)
        print(f"Generated thermal properties: {tp_path}")
    except Exception as e:
        issues.append(f"failed to generate thermal properties for {rdir}: {e}")


def _generate_thermal_properties(rdir: Path, temperature: float, args, out_path: Path) -> None:
    from phonopy import Phonopy
    from phonopy.interface.vasp import read_vasp
    from phonopy.file_IO import parse_FORCE_CONSTANTS

    poscar_path = _resolve_tp_poscar(rdir=rdir, tp_poscar=getattr(args, "tp_poscar", None))
    fc_path = _resolve_tp_fc_path(rdir=rdir, tp_fc_file=getattr(args, "tp_fc_file", None))

    unitcell = read_vasp(str(poscar_path))
    dim = np.array(getattr(args, "tp_dim", [1, 1, 1]), dtype=int)
    if dim.shape != (3,) or np.any(dim <= 0):
        raise ValueError(f"invalid --tp-dim: {getattr(args, 'tp_dim', None)}")
    ph = Phonopy(
        unitcell,
        supercell_matrix=np.diag(dim),
        primitive_matrix="auto",
        symprec=float(getattr(args, "tp_symprec", 1e-5)),
    )
    ph.force_constants = parse_FORCE_CONSTANTS(filename=str(fc_path))

    mesh = [int(x) for x in getattr(args, "tp_mesh", [7, 7, 7])]
    if len(mesh) != 3 or any(x <= 0 for x in mesh):
        raise ValueError(f"invalid --tp-mesh: {mesh}")
    ph.run_mesh(mesh)

    if bool(getattr(args, "tp_full_range", False)):
        tmin = float(getattr(args, "tp_tmin", 0.0))
        tmax = float(getattr(args, "tp_tmax", 1500.0))
        tstep = float(getattr(args, "tp_tstep", 10.0))
        if tmax < tmin or tstep <= 0:
            raise ValueError("invalid --tp-tmin/--tp-tmax/--tp-tstep")
        ph.run_thermal_properties(t_min=tmin, t_max=tmax, t_step=tstep)
    else:
        t = float(temperature)
        t_step = t if t > 0 else 1.0
        ph.run_thermal_properties(t_min=t, t_max=t, t_step=t_step)

    ph.write_yaml_thermal_properties(filename=str(out_path))


def _resolve_tp_poscar(rdir: Path, tp_poscar: str | None) -> Path:
    if tp_poscar:
        p = Path(tp_poscar).expanduser()
        if not p.is_absolute():
            p = (rdir / p).resolve()
        if p.exists():
            return p
        raise FileNotFoundError(f"tp POSCAR-like file not found: {p}")

    candidates = [
        rdir / "POSCAR_qscaild_input",
        rdir / "POSCAR_average_supercell_final",
        rdir / "POSCAR_average_final",
        rdir / "POSCAR",
    ]
    for p in candidates:
        if p.exists():
            return p
    raise FileNotFoundError(f"no POSCAR-like file for thermal-properties generation in: {rdir}")


def _resolve_tp_fc_path(rdir: Path, tp_fc_file: str | None) -> Path:
    if tp_fc_file:
        p = Path(tp_fc_file).expanduser()
        if not p.is_absolute():
            p = (rdir / p).resolve()
        if p.exists():
            return p
        raise FileNotFoundError(f"tp force-constants file not found: {p}")

    fc_candidates = [p for p in rdir.glob("FORCE_CONSTANTS*") if p.is_file()]
    if not fc_candidates:
        raise FileNotFoundError(f"no FORCE_CONSTANTS* file found in: {rdir}")
    # "Latest" means newest by modification time.
    return max(fc_candidates, key=lambda p: p.stat().st_mtime)


def _read_free_energy(run_dir: Path, source: str) -> float:
    if source == "history":
        p = run_dir / "qscaild_free_energy_history.log"
        if p.exists():
            rows = _read_numeric_rows(p)
            if rows:
                return float(rows[-1][1])
    for name in ("out_fit.txt", "out_fit"):
        p = run_dir / name
        if p.exists():
            rows = _read_numeric_rows(p)
            if rows and len(rows[-1]) >= 7:
                return float(rows[-1][6])
    raise ValueError(f"free energy not found in: {run_dir}")


def _read_pressure_kbar(run_dir: Path) -> float:
    for name in ("out_volume.txt", "out_volume"):
        p = run_dir / name
        if p.exists():
            rows = _read_numeric_rows(p)
            if rows and len(rows[-1]) >= 4:
                return float(np.mean(rows[-1][1:4]))
    return float("nan")


def _read_volume_and_composition(run_dir: Path):
    candidates = [
        "POSCAR_average_supercell_final",
        "POSCAR_average_final",
        "POSCAR_average_primitive_final",
        "POSCAR_qscaild_input",
        "POSCAR",
    ]
    poscar = None
    for name in candidates:
        p = run_dir / name
        if p.exists():
            poscar = p
            break
    if poscar is None:
        raise ValueError(f"no POSCAR-like file found in: {run_dir}")
    atoms = read(str(poscar), format="vasp")
    symbols = atoms.get_chemical_symbols()
    comp = tuple(sorted(Counter(symbols).items()))
    return float(atoms.get_volume()), comp, int(len(symbols))


def _read_numeric_rows(path: Path):
    rows = []
    with path.open("r") as f:
        for ln in f:
            s = ln.strip()
            if (not s) or s.startswith("#"):
                continue
            try:
                rows.append([float(x) for x in s.split()])
            except Exception:
                continue
    return rows


def _infer_temperature_from_path(path: Path):
    m = re.search(r"(\d+(?:\.\d+)?)\s*[kK]\b", str(path))
    if m:
        return float(m.group(1))
    return None


def _infer_temperature_from_logs(run_dir: Path):
    # Prefer explicit key-value line in log summary.
    log_path = run_dir / "macer_sscha.log"
    if log_path.exists():
        try:
            text = log_path.read_text(errors="ignore")
        except Exception:
            text = ""
        m = re.search(r"^\s*-\s*temperature\s*:\s*([0-9]+(?:\.[0-9]+)?)\s*$", text, flags=re.MULTILINE)
        if m:
            return float(m.group(1))
        # Fallback to CLI command snippet (e.g., "-T 300" / "--temperature 300").
        m = re.search(r"(?:^|\s)(?:-T|--temperature)\s+([0-9]+(?:\.[0-9]+)?)\b", text)
        if m:
            return float(m.group(1))
    return None


def _load_manifest(path: Path):
    with path.open("r") as f:
        data = yaml.safe_load(f) or {}
    if "runs" not in data or not isinstance(data["runs"], list):
        raise ValueError("Manifest must contain a 'runs' list.")
    return data


def _print_table(rows, notes):
    print("SSCHA Thermo Post-Analysis")
    print("-" * 72)
    for n in notes:
        print(f"Note: {n}")
    print("Units: F/S/U/H/G are raw run values (NOT per-atom normalized).")
    print("T[K]    F_raw[eV]    S_raw[eV/K]  U_raw[eV]    P[kbar]   V[A^3]   N_atoms   G_raw[eV]")
    for r in rows:
        print(
            f"{r['T_K']:7.2f} "
            f"{r['F_eV']:12.6f} "
            f"{r['S_eV_per_K']:12.6e} "
            f"{r['U_eV']:12.6f} "
            f"{r['P_kbar']:9.3f} "
            f"{r['V_A3']:9.3f} "
            f"{int(r.get('N_atoms', 0)):8d} "
            f"{r['G_eV']:12.6f}"
        )


def _write_outputs(rows, notes, settings, json_out, csv_out, summaries=None):
    if json_out:
        payload = {
            "meta": {
                "tool": "macer util sscha-thermo",
                "units": {
                    "temperature": "K",
                    "energy": "eV (raw, not per-atom)",
                    "entropy": "eV/K (raw, not per-atom)",
                    "pressure": "kbar",
                    "volume": "A^3",
                },
                "settings": settings,
                "notes": notes,
            },
            "thermo_table": rows,
        }
        if summaries is not None:
            payload["summaries"] = summaries
        jp = Path(json_out).expanduser().resolve()
        jp.write_text(json.dumps(payload, indent=2))
        print(f"Wrote JSON: {jp}")

    if csv_out:
        cp = Path(csv_out).expanduser().resolve()
        with cp.open("w", newline="") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "dir",
                    "T_K",
                    "F_eV",
                    "S_eV_per_K",
                    "U_eV",
                    "P_kbar",
                    "V_A3",
                    "PV_eV",
                    "H_eV",
                    "G_eV",
                ],
            )
            writer.writeheader()
            writer.writerows(rows)
        print(f"Wrote CSV: {cp}")
