import os
from io import StringIO
import torch
import numpy as np
import tqdm
import matplotlib.pyplot as plt
from ase.io import read
from ase.constraints import voigt_6_to_full_3x3_stress
from ase.units import GPa
from macer.calculator.factory import get_calculator, evaluate_batch, evaluate_sequential

def calc_r2(true, pred):
    """
    Calculates the square of the Pearson correlation coefficient (r^2).
    This is invariant to constant shifts and scales, reflecting the true 'correlation'.
    """
    if len(true) < 2:
        return np.nan
    # Use correlation matrix [0,1] element
    c = np.corrcoef(true, pred)[0, 1]
    return c**2

def evaluate_model(
    data_path,
    ff="mattersim",
    model_path=None,
    device="cpu",
    output_dir=".",
    sequential=False,
    batch_size=None,
):
    """
    General model evaluation logic.
    Calculates MAE and Correlation (r^2) for Energy, Forces, and Stress.
    Generates parity plots.
    """
    print(f"Loading data for evaluation: {data_path}")
    if batch_size is not None and int(batch_size) < 1:
        raise ValueError("--batch-size must be >= 1 when provided.")
    # Explicitly set format for XML to avoid ASE auto-detect confusion
    fmt = "vasp-xml" if data_path.lower().endswith(".xml") else None
    atoms_test = _load_eval_structures(data_path, fmt=fmt)
    print(f"Total structures: {len(atoms_test)}")

    print(f"Initializing calculator: FF={ff}, Model={model_path if model_path else 'Default'}")
    
    # Dynamically build kwargs to handle different calculator requirements
    calc_kwargs = {"device": device}
    
    if ff == "mace":
        calc_kwargs["model_paths"] = [model_path] # For MACE compatibility
    else:
        calc_kwargs["model_path"] = model_path
        
    calc = get_calculator(ff_name=ff, **calc_kwargs)
    
    e_true_list, e_pred_list = [], []
    f_true_list, f_pred_list = [], []
    s_true_list, s_pred_list = [], []
    valid_atoms = []
    true_stress_per_struct = []

    print(f"\nCollecting reference labels via macer.calculator ({device})...")
    for atoms in tqdm.tqdm(atoms_test):
        try:
            e_true = atoms.get_potential_energy() / len(atoms) 
            f_true = atoms.get_forces()
        except Exception as e:
            print(f"Warning: Skipping structure due to missing DFT data: {e}")
            continue
            
        try:
            s_true = atoms.get_stress(voigt=False) / GPa
        except Exception:
            s_true = None

        e_true_list.append(e_true)
        f_true_list.extend(f_true.flatten())
        true_stress_per_struct.append(s_true)
        valid_atoms.append(atoms.copy())

    if not valid_atoms:
        print("Error: No valid structures with reference labels were found.")
        return None

    def _stress_to_gpa_3x3(raw_stress, input_unit="ev_a3"):
        try:
            arr = np.array(raw_stress, dtype=float)
            arr = np.squeeze(arr)
            if arr.shape == (6,):
                arr = voigt_6_to_full_3x3_stress(arr)
            elif arr.shape == (9,):
                arr = arr.reshape(3, 3)
            elif arr.shape != (3, 3):
                return None
            if input_unit == "gpa":
                return arr
            return arr / GPa
        except Exception:
            return None

    def _infer_pred_stress_unit(pred_stress_all, true_stress_all):
        """Infer whether batch-predicted stress is in eV/A^3 or GPa using label agreement."""
        score = {"ev_a3": [], "gpa": []}
        n_checked = 0
        for i, s_true in enumerate(true_stress_all):
            if s_true is None:
                continue
            if pred_stress_all is None or i >= len(pred_stress_all):
                continue
            s_ev = _stress_to_gpa_3x3(pred_stress_all[i], input_unit="ev_a3")
            s_gp = _stress_to_gpa_3x3(pred_stress_all[i], input_unit="gpa")
            if s_ev is None or s_gp is None:
                continue
            true_arr = np.array(s_true, dtype=float)
            score["ev_a3"].append(float(np.mean(np.abs(true_arr - s_ev))))
            score["gpa"].append(float(np.mean(np.abs(true_arr - s_gp))))
            n_checked += 1
            if n_checked >= 20:
                break
        if not score["ev_a3"]:
            return "ev_a3"
        return "gpa" if np.mean(score["gpa"]) < np.mean(score["ev_a3"]) else "ev_a3"

    print(f"\nRunning prediction inference on {len(valid_atoms)} structures...")
    use_sequential = bool(sequential)
    pred_res = None
    if not use_sequential:
        try:
            import threading
            import time

            stop_evt = threading.Event()

            def _heartbeat():
                t0 = time.time()
                while not stop_evt.wait(30.0):
                    elapsed = int(time.time() - t0)
                    print(
                        f"  util eval batch running... {elapsed}s "
                        f"(alive, n_structures={len(valid_atoms)})"
                    )

            hb = threading.Thread(target=_heartbeat, daemon=True)
            hb.start()
            pred_res = evaluate_batch(
                calc,
                valid_atoms,
                batch_size=batch_size,
                properties=["energy", "forces", "stress"],
            )
            stop_evt.set()
            hb.join(timeout=0.1)
        except Exception as e:
            try:
                stop_evt.set()
                hb.join(timeout=0.1)
            except Exception:
                pass
            print(f"[Warning] Batch evaluation failed:\n  {e}\n  Falling back to sequential evaluation...")
            use_sequential = True
    if use_sequential:
        if sequential:
            print("INFO: Running in forced sequential mode (--sequential).")
        pred_res = evaluate_sequential(
            calc,
            valid_atoms,
            properties=["energy", "forces", "stress"],
        )

    pred_energy = pred_res["energy"]
    pred_forces = pred_res["forces"]
    pred_stress = pred_res.get("stress", None)
    pred_stress_unit = "ev_a3"
    if pred_stress is not None:
        pred_stress_unit = _infer_pred_stress_unit(pred_stress, true_stress_per_struct)
        if pred_stress_unit == "gpa":
            print("INFO: Detected batch stress unit as GPa; skipping eV/A^3->GPa conversion.")

    for i, atoms in enumerate(valid_atoms):
        e_pred_list.append(float(pred_energy[i]) / len(atoms))
        f_pred_list.extend(np.array(pred_forces[i], dtype=float).flatten())
        s_true = true_stress_per_struct[i]
        s_pred = _stress_to_gpa_3x3(pred_stress[i], input_unit=pred_stress_unit) if pred_stress is not None else None
        if s_true is not None and s_pred is not None:
            s_true_list.extend(np.array(s_true, dtype=float).flatten())
            s_pred_list.extend(np.array(s_pred, dtype=float).flatten())

    if not e_true_list or not e_pred_list:
        print("Error: No valid predictions were made.")
        return None

    e_true_arr, e_pred_arr = np.array(e_true_list), np.array(e_pred_list)
    f_true_arr, f_pred_arr = np.array(f_true_list), np.array(f_pred_list)
    s_true_arr, s_pred_arr = np.array(s_true_list), np.array(s_pred_list)

    # Metrics (Using r^2 for correlation as requested)
    mae_e_raw = np.mean(np.abs(e_true_arr - e_pred_arr))
    r2_e = calc_r2(e_true_arr, e_pred_arr)
    
    shift = np.mean(e_true_arr) - np.mean(e_pred_arr)
    e_pred_shifted = e_pred_arr + shift
    mae_e_trend = np.mean(np.abs(e_true_arr - e_pred_shifted))

    mae_f = np.mean(np.abs(f_true_arr - f_pred_arr))
    r2_f = calc_r2(f_true_arr, f_pred_arr)
    
    mae_s, r2_s = None, None
    if s_true_list:
        mae_s = np.mean(np.abs(s_true_arr - s_pred_arr))
        r2_s = calc_r2(s_true_arr, s_pred_arr)

    # Plotting helper
    def _write_parity_dat(true, pred, filename):
        base, _ = os.path.splitext(filename)
        dat_path = os.path.join(output_dir, f"{base}.dat")
        with open(dat_path, "w") as f:
            f.write("# Input Prediction\n")
            for t, p in zip(true, pred):
                f.write(f"{t:.8f} {p:.8f}\n")

    def plot_parity(true, pred, title, xlabel, ylabel, filename, mae, r2):
        plt.figure(figsize=(6, 6))
        ax = plt.gca()
        ax.scatter(true, pred, alpha=0.5, s=10, edgecolors='none')
        combined = np.concatenate([true, pred])
        lims = [np.min(combined), np.max(combined)]
        ax.plot(lims, lims, 'k--', alpha=0.75, zorder=0)
        ax.set_aspect('equal', adjustable='box')
        ax.set_title(f"{title}\nMAE: {mae:.4f} | r²: {r2:.4f}")
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, filename))
        plt.close()
        _write_parity_dat(true, pred, filename)

    print(f"Generating enhanced parity plots in {os.path.abspath(output_dir)}...")
    plot_parity(e_true_arr, e_pred_shifted, "Absolute Energy (Shifted)", "Input", "Prediction", "eval_parity_energy_abs.pdf", mae_e_trend, r2_e)
    e_true_rel = e_true_arr - np.min(e_true_arr)
    e_pred_rel = e_pred_arr - np.min(e_pred_arr)
    plot_parity(e_true_rel, e_pred_rel, "Relative Energy (min=0)", "Input", "Prediction", "eval_parity_energy_rel.pdf", mae_e_trend, r2_e)
    plot_parity(f_true_arr, f_pred_arr, "Atomic Forces", "Input", "Prediction", "eval_parity_forces.pdf", mae_f, r2_f)
    if s_true_list:
        plot_parity(s_true_arr, s_pred_arr, "Virial Stress", "Input", "Prediction", "eval_parity_stress.pdf", mae_s, r2_s)

    results = []
    results.append("-" * 55)
    results.append(f"{ 'Metric':<15} | {'MAE':<12} | {'r² (Corr)':<12}")
    results.append("-" * 55)
    results.append(f"{ 'Energy (Raw)':<15} | {mae_e_raw:12.6f} | {r2_e:12.4f}")
    results.append(f"{ 'Energy (Trend)':<15} | {mae_e_trend:12.6f} | {r2_e:12.4f}")
    results.append(f"{ 'Forces':<15} | {mae_f:12.6f} | {r2_f:12.4f}")
    if mae_s is not None:
        results.append(f"{ 'Stress':<15} | {mae_s:12.6f} | {r2_s:12.4f}")
    else:
        results.append(f"{ 'Stress':<15} | Not available in data")
    results.append("-" * 55)
    
    return "\n".join(results)


def _load_eval_structures(data_path, fmt=None):
    """Load structures for evaluation with a robust fallback for broken extxyz frames."""
    is_xyz = data_path.lower().endswith(".xyz") or data_path.lower().endswith(".extxyz")
    try:
        return read(data_path, index=":", format=fmt)
    except Exception as exc:
        if not is_xyz:
            raise
        print(f"Warning: standard XYZ reader failed ({exc}). Trying robust frame-skip mode...")
        atoms = _read_extxyz_skip_corrupt(data_path)
        if not atoms:
            raise RuntimeError("No valid XYZ frames found after skipping corrupted frames.")
        return atoms


def _read_extxyz_skip_corrupt(path):
    """Read extxyz while skipping malformed steps (e.g., broken first header)."""
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        lines = f.readlines()

    atoms_all = []
    skipped = 0
    idx = 0
    nlines = len(lines)
    while idx < nlines:
        head = lines[idx].strip()
        try:
            natoms = int(head)
        except Exception:
            skipped += 1
            idx += 1
            continue

        if natoms <= 0:
            skipped += 1
            idx += 1
            continue

        frame_end = idx + natoms + 2
        if frame_end > nlines:
            skipped += 1
            break

        frame_text = "".join(lines[idx:frame_end])
        try:
            frame_atoms = read(StringIO(frame_text), index=":", format="extxyz")
            if frame_atoms:
                atoms_all.extend(frame_atoms)
                idx = frame_end
                continue
        except Exception:
            pass

        skipped += 1
        idx += 1

    if skipped > 0:
        print(f"Warning: skipped {skipped} malformed line/frame block(s) while reading {path}")
    return atoms_all
