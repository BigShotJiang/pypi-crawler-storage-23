from __future__ import annotations

from collections import Counter
from datetime import datetime
import json
from pathlib import Path
import webbrowser
import numpy as np
from pymatgen.analysis.ewald import EwaldSummation
from pymatgen.core import Structure


XRAY_WAVELENGTHS = {
    "CuKa1": 1.5405929,
    "CuKa2": 1.5444274,
    "CuKb": 1.392234,
    "AgKa1": 0.55942178,
    "AgKa2": 0.5638131,
    "MoKa1": 0.70931715,
    "MoKa2": 0.713607,
    "CoKa1": 1.788996,
    "CoKa2": 1.792835,
    "FeKa1": 1.936041,
    "FeKa2": 1.939973,
    "CrKa1": 2.289726,
    "CrKa2": 2.293651,
}

XRAY_MIXTURES = {
    # Common lab default: Cu K-alpha doublet with 2:1 intensity ratio.
    "CuKa12": [("CuKa1", 1.54059, 1.0), ("CuKa2", 1.54432, 0.5)],
}


def _load_structure(input_path: str) -> Structure:
    path = Path(input_path)
    if not path.exists():
        raise FileNotFoundError(f"Structure file not found: {input_path}")
    return Structure.from_file(str(path))


def _parse_oxidation_states(oxidation_states: str | None) -> dict[str, float] | None:
    if not oxidation_states:
        return None
    ox_map: dict[str, float] = {}
    for token in oxidation_states.split(","):
        token = token.strip()
        if not token:
            continue
        if ":" not in token:
            raise ValueError(
                f"Invalid oxidation state token '{token}'. Use format 'Element:Value'."
            )
        elem, value = token.split(":", 1)
        elem = elem.strip()
        value = value.strip()
        if not elem:
            raise ValueError("Element symbol is empty in oxidation state string.")
        ox_map[elem] = float(value)
    if not ox_map:
        raise ValueError("No valid oxidation states parsed.")
    return ox_map


def xrd_from_poscar(
    poscar_path: str = "POSCAR",
    xray_type: str = "CuKa12",
    wavelength: float | None = None,
    output_prefix: str | None = None,
    two_theta_min: float = 0.0,
    two_theta_max: float = 120.0,
    plot_min: float = 10.0,
    plot_max: float = 80.0,
    sigma: float = 0.05,
    npoints: int = 5000,
    show: bool = False,
    make_html: bool = True,
    open_html: bool = False,
):
    import matplotlib.pyplot as plt
    from pymatgen.analysis.diffraction.core import AbstractDiffractionPatternCalculator
    from pymatgen.analysis.diffraction.xrd import XRDCalculator
    from pymatgen.core.composition import Composition
    from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

    poscar_file = Path(poscar_path)
    if not poscar_file.exists():
        raise FileNotFoundError(f"POSCAR file not found: {poscar_path}")

    components: list[tuple[str, float, float]]
    if wavelength is None:
        if xray_type in XRAY_MIXTURES:
            components = XRAY_MIXTURES[xray_type]
            xray_condition = " + ".join(
                f"{name}({w:.5f}A, weight={weight:g})" for name, w, weight in components
            )
        elif xray_type in XRAY_WAVELENGTHS:
            components = [(xray_type, XRAY_WAVELENGTHS[xray_type], 1.0)]
            xray_condition = f"{xray_type}({XRAY_WAVELENGTHS[xray_type]:.6f}A)"
        else:
            valid = ", ".join(sorted([*XRAY_WAVELENGTHS.keys(), *XRAY_MIXTURES.keys()]))
            raise ValueError(f"Unsupported --xraytype '{xray_type}'. Supported: {valid}")
    else:
        components = [("custom", float(wavelength), 1.0)]
        xray_type = f"custom-{wavelength:.6f}A"
        xray_condition = f"custom({wavelength:.6f}A)"

    output_stem = output_prefix if output_prefix else poscar_file.name
    output_peak_dat = Path(f"{output_stem}_peaks.dat")
    output_profile_dat = Path(f"{output_stem}_profile.dat")
    output_sticks_dat = Path(f"{output_stem}_sticks.dat")
    output_pdf = Path(f"{output_stem}.pdf")
    output_html = Path(f"{output_stem}.html")

    structure = _load_structure(str(poscar_file))

    AbstractDiffractionPatternCalculator.SCALED_INTENSITY_TOL = 0

    xrd_data = []
    peak_records = []
    stick_theta: list[float] = []
    stick_intensity: list[float] = []
    for _, line_wavelength, line_weight in components:
        calculator = XRDCalculator(wavelength=line_wavelength)
        pattern = calculator.get_pattern(structure, two_theta_range=(two_theta_min, two_theta_max))
        for idx, theta in enumerate(pattern.x):
            h, k, l = 0, 0, 0
            multiplicity = 0
            if pattern.hkls[idx]:
                hkl_info = pattern.hkls[idx][0]
                h, k, l = hkl_info["hkl"]
                multiplicity = hkl_info.get("multiplicity", 0)
            d_hkl = pattern.d_hkls[idx]
            intensity = float(pattern.y[idx]) * float(line_weight)
            xrd_data.append([h, k, l, multiplicity, d_hkl, theta, intensity])
            peak_records.append(
                {
                    "h": int(h),
                    "k": int(k),
                    "l": int(l),
                    "multiplicity": int(multiplicity),
                    "d_hkl": float(d_hkl),
                    "two_theta": float(theta),
                    "intensity": float(intensity),
                }
            )
            stick_theta.append(float(theta))
            stick_intensity.append(float(intensity))

    if xrd_data:
        xrd_data.sort(key=lambda row: row[5])
    if peak_records:
        peak_records.sort(key=lambda row: row["two_theta"])
    if stick_theta:
        order = np.argsort(np.array(stick_theta))
        stick_theta = [stick_theta[i] for i in order]
        stick_intensity = [stick_intensity[i] for i in order]

    comp = Composition(structure.formula)
    reduced_formula = comp.reduced_formula
    space_group = SpacegroupAnalyzer(structure).get_space_group_symbol()

    header = (
        f"reduced_formula={reduced_formula}, space_group={space_group}, "
        f"xray={xray_type}, condition={xray_condition}\n"
        "h,k,l,multiplicity,d_hkl(Angstrom),two_theta(deg),intensity"
    )
    np.savetxt(
        output_peak_dat,
        np.array(xrd_data, dtype=float),
        fmt=["%d", "%d", "%d", "%d", "%.8f", "%.8f", "%.8f"],
        delimiter=",",
        header=header,
    )

    def _smeared_signal(x_vals):
        y_vals = np.zeros_like(x_vals, dtype=float)
        if sigma <= 0:
            return y_vals
        norm = sigma * np.sqrt(2.0 * np.pi)
        for peak_pos, peak_int in zip(stick_theta, stick_intensity):
            y_vals += peak_int * np.exp(-0.5 * ((x_vals - peak_pos) / sigma) ** 2) / norm
        return y_vals

    x_plot = np.linspace(two_theta_min, two_theta_max, npoints)
    y_plot = _smeared_signal(x_plot)

    np.savetxt(
        output_profile_dat,
        np.column_stack([x_plot, y_plot]),
        fmt="%.8f",
        header="two_theta(deg),intensity",
    )

    np.savetxt(
        output_sticks_dat,
        np.column_stack([stick_theta, stick_intensity]),
        fmt="%.8f",
        header="two_theta(deg),intensity",
    )

    if make_html:
        _write_xrd_interactive_html(
            output_html=output_html,
            title=f"XRD pattern: {poscar_file.name}",
            subtitle=(
                f"{reduced_formula} | SG {space_group} | "
                f"xray={xray_type} | {xray_condition}"
            ),
            plot_min=float(plot_min),
            plot_max=float(plot_max),
            peaks=peak_records,
            profile_theta=x_plot.tolist(),
            profile_intensity=y_plot.tolist(),
        )

    fig = plt.figure()
    plt.plot(x_plot, y_plot, linestyle="solid", linewidth=0.8, color="red", label=poscar_file.name)
    plt.vlines(stick_theta, 0.0, stick_intensity, linestyle="solid", color="black", linewidth=0.5, alpha=0.7)
    plt.xlim(plot_min, plot_max)
    plt.xlabel("2 theta (deg)")
    plt.ylabel("Intensity (arb. unit)")
    plt.legend()
    plt.tight_layout()
    fig.savefig(output_pdf)

    if show:
        plt.show()
    else:
        plt.close(fig)

    print(f"XRD peak data saved: {output_peak_dat}")
    print(f"XRD profile data saved: {output_profile_dat}")
    print(f"XRD sticks data saved: {output_sticks_dat}")
    print(f"XRD plot saved: {output_pdf}")
    if make_html:
        print(f"XRD interactive HTML saved: {output_html}")
        if open_html:
            webbrowser.open(output_html.resolve().as_uri())
            print(f"Opened in browser: {output_html}")


def _write_xrd_interactive_html(
    output_html: Path,
    title: str,
    subtitle: str,
    plot_min: float,
    plot_max: float,
    peaks: list[dict[str, float | int]],
    profile_theta: list[float],
    profile_intensity: list[float],
) -> None:
    profile_max = max(profile_intensity) if profile_intensity else 0.0
    peak_max = max((float(p["intensity"]) for p in peaks), default=0.0)
    y_max = max(profile_max, peak_max, 1.0)
    if y_max <= 0:
        y_max = 1.0
    payload = {
        "title": title,
        "subtitle": subtitle,
        "plotMin": plot_min,
        "plotMax": plot_max,
        "yMax": y_max,
        "peaks": peaks,
        "profileTheta": profile_theta,
        "profileIntensity": profile_intensity,
    }
    payload_json = json.dumps(payload)
    html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>XRD interactive</title>
  <style>
    :root {{
      --bg: #f5f7fb;
      --panel: #ffffff;
      --ink: #1d2433;
      --muted: #5e6779;
      --line: #2f6bd6;
      --stick: #222;
      --grid: #d7dde8;
    }}
    body {{
      margin: 0;
      background: linear-gradient(140deg, #eef2f9 0%, #fbfcfe 100%);
      color: var(--ink);
      font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif;
    }}
    .wrap {{
      max-width: 1100px;
      margin: 22px auto;
      padding: 18px;
    }}
    .card {{
      background: var(--panel);
      border-radius: 14px;
      padding: 18px 18px 14px;
      box-shadow: 0 10px 32px rgba(18, 35, 70, 0.12);
    }}
    h1 {{
      margin: 0 0 6px;
      font-size: 22px;
    }}
    .sub {{
      margin: 0 0 14px;
      color: var(--muted);
      font-size: 13px;
    }}
    .controls {{
      display: flex;
      gap: 8px;
      margin: 0 0 10px;
    }}
    .controls button {{
      border: 1px solid #ccd5e6;
      background: #f7f9fd;
      color: #1d2433;
      border-radius: 8px;
      padding: 6px 10px;
      font-size: 12px;
      cursor: pointer;
    }}
    .controls button:disabled {{
      opacity: 0.45;
      cursor: default;
    }}
    svg {{
      width: 100%;
      height: auto;
      display: block;
      border: 1px solid #e4e8f0;
      border-radius: 10px;
      background: #fff;
    }}
    .tip {{
      position: fixed;
      pointer-events: none;
      z-index: 9999;
      display: none;
      background: rgba(25, 31, 44, 0.96);
      color: #fff;
      padding: 8px 10px;
      border-radius: 8px;
      font-size: 12px;
      line-height: 1.4;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.25);
      white-space: pre;
    }}
    .foot {{
      margin-top: 8px;
      font-size: 12px;
      color: var(--muted);
    }}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1 id="title"></h1>
      <p class="sub" id="subtitle"></p>
      <div class="controls">
        <button id="btn-back" disabled>Back</button>
        <button id="btn-reset" disabled>Reset Zoom</button>
      </div>
      <svg id="xrd" viewBox="0 0 1100 520" aria-label="XRD chart"></svg>
      <div class="foot">Hover peak points for metadata. Drag or wheel to zoom. Double-click or Reset to restore. Right-click for Back.</div>
    </div>
  </div>
  <div class="tip" id="tip"></div>
  <script>
  const data = {payload_json};
  const svg = document.getElementById("xrd");
  const tip = document.getElementById("tip");
  const btnBack = document.getElementById("btn-back");
  const btnReset = document.getElementById("btn-reset");
  document.getElementById("title").textContent = data.title;
  document.getElementById("subtitle").textContent = data.subtitle;

  const W = 1100, H = 520;
  const m = {{l: 72, r: 24, t: 20, b: 56}};
  const iw = W - m.l - m.r, ih = H - m.t - m.b;
  const yMin = 0, yMax = data.yMax * 1.05;
  const ns = "http://www.w3.org/2000/svg";
  const originalXMin = data.plotMin;
  const originalXMax = data.plotMax;
  let currentXMin = originalXMin;
  let currentXMax = originalXMax;
  const zoomHistory = [];
  let isDragging = false;
  let dragStartX = 0;
  let dragCurrentX = 0;

  const make = (tag, attrs = {{}}, parent = svg) => {{
    const el = document.createElementNS(ns, tag);
    for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, String(v));
    parent.appendChild(el);
    return el;
  }};

  const toSvgX = (ev) => {{
    const rect = svg.getBoundingClientRect();
    return ((ev.clientX - rect.left) / rect.width) * W;
  }};
  const clampPlotX = (x) => Math.max(m.l, Math.min(m.l + iw, x));
  const xToData = (x, xMin, xMax) => xMin + ((x - m.l) / iw) * (xMax - xMin);
  const isDefaultRange = () => Math.abs(currentXMin - originalXMin) < 1e-9 && Math.abs(currentXMax - originalXMax) < 1e-9;
  const updateButtons = () => {{
    btnBack.disabled = zoomHistory.length === 0;
    btnReset.disabled = isDefaultRange();
  }};
  const pushHistory = () => {{
    zoomHistory.push([currentXMin, currentXMax]);
    if (zoomHistory.length > 100) zoomHistory.shift();
  }};
  const applyRange = (nextMin, nextMax, keepHistory = true) => {{
    if (nextMax - nextMin <= 1e-6) return;
    if (keepHistory) pushHistory();
    currentXMin = nextMin;
    currentXMax = nextMax;
    draw();
  }};
  const resetZoom = () => {{
    currentXMin = originalXMin;
    currentXMax = originalXMax;
    zoomHistory.length = 0;
    isDragging = false;
    tip.style.display = "none";
    draw();
  }};
  const goBack = () => {{
    if (zoomHistory.length === 0) return;
    const prev = zoomHistory.pop();
    currentXMin = prev[0];
    currentXMax = prev[1];
    isDragging = false;
    tip.style.display = "none";
    draw();
  }};

  const formatPeak = (p) => (
    `hkl: (${{p.h}}, ${{p.k}}, ${{p.l}})\\n` +
    `multiplicity: ${{p.multiplicity}}\\n` +
    `2theta: ${{p.two_theta.toFixed(4)}} deg\\n` +
    `d_hkl: ${{p.d_hkl.toFixed(5)}} A\\n` +
    `intensity: ${{p.intensity.toFixed(4)}}`
  );

  const draw = () => {{
    svg.innerHTML = "";
    const xMin = currentXMin;
    const xMax = currentXMax;
    const xScale = (x) => m.l + ((x - xMin) / (xMax - xMin)) * iw;
    const yScale = (y) => m.t + ih - ((y - yMin) / (yMax - yMin)) * ih;

    make("rect", {{x: m.l, y: m.t, width: iw, height: ih, fill: "#fff"}});

    for (let i = 0; i <= 5; i++) {{
      const y = m.t + (ih / 5) * i;
      make("line", {{x1: m.l, y1: y, x2: m.l + iw, y2: y, stroke: "#d7dde8", "stroke-width": 1}});
    }}
    for (let i = 0; i <= 10; i++) {{
      const x = m.l + (iw / 10) * i;
      make("line", {{x1: x, y1: m.t, x2: x, y2: m.t + ih, stroke: "#edf1f7", "stroke-width": 1}});
    }}
    make("line", {{x1: m.l, y1: m.t + ih, x2: m.l + iw, y2: m.t + ih, stroke: "#69758b", "stroke-width": 1.2}});
    make("line", {{x1: m.l, y1: m.t, x2: m.l, y2: m.t + ih, stroke: "#69758b", "stroke-width": 1.2}});

    for (let i = 0; i <= 10; i++) {{
      const xv = xMin + (xMax - xMin) * (i / 10);
      const x = xScale(xv);
      make("line", {{x1: x, y1: m.t + ih, x2: x, y2: m.t + ih + 5, stroke: "#69758b", "stroke-width": 1}});
      const lbl = make("text", {{x: x, y: m.t + ih + 22, "text-anchor": "middle", "font-size": 11, fill: "#4f5a6d"}});
      lbl.textContent = xv.toFixed(1);
    }}
    for (let i = 0; i <= 5; i++) {{
      const yv = yMin + (yMax - yMin) * (i / 5);
      const y = yScale(yv);
      make("line", {{x1: m.l - 5, y1: y, x2: m.l, y2: y, stroke: "#69758b", "stroke-width": 1}});
      const lbl = make("text", {{x: m.l - 8, y: y + 4, "text-anchor": "end", "font-size": 11, fill: "#4f5a6d"}});
      lbl.textContent = yv.toFixed(1);
    }}

    const xLabel = make("text", {{x: m.l + iw / 2, y: H - 14, "text-anchor": "middle", "font-size": 13, fill: "#2a3346"}});
    xLabel.textContent = "2theta (deg)";
    const yLabel = make("text", {{
      x: 17,
      y: m.t + ih / 2,
      transform: `rotate(-90 17 ${{m.t + ih / 2}})`,
      "text-anchor": "middle",
      "font-size": 13,
      fill: "#2a3346"
    }});
    yLabel.textContent = "Intensity (arb. unit)";

    const pts = [];
    for (let i = 0; i < data.profileTheta.length; i++) {{
      const x = data.profileTheta[i];
      if (x < xMin || x > xMax) continue;
      pts.push(`${{xScale(x).toFixed(2)}},${{yScale(data.profileIntensity[i]).toFixed(2)}}`);
    }}
    if (pts.length > 1) {{
      make("polyline", {{
        points: pts.join(" "),
        fill: "none",
        stroke: "#2f6bd6",
        "stroke-width": 1.6
      }});
    }}

    for (const p of data.peaks) {{
      if (p.two_theta < xMin || p.two_theta > xMax) continue;
      const x = xScale(p.two_theta);
      const y = yScale(p.intensity);
      make("line", {{x1: x, y1: yScale(0), x2: x, y2: y, stroke: "#222", "stroke-width": 1}});
      make("circle", {{cx: x, cy: y, r: 2.8, fill: "#111", stroke: "#f2f5fb", "stroke-width": 0.9}});
      const hit = make("circle", {{cx: x, cy: y, r: 7, fill: "transparent", cursor: "pointer"}});
      hit.addEventListener("mousemove", (ev) => {{
        tip.style.display = "block";
        tip.style.left = `${{ev.clientX + 14}}px`;
        tip.style.top = `${{ev.clientY + 14}}px`;
        tip.textContent = formatPeak(p);
      }});
      hit.addEventListener("mouseleave", () => {{
        tip.style.display = "none";
      }});
    }}

    if (isDragging) {{
      const x0 = clampPlotX(Math.min(dragStartX, dragCurrentX));
      const x1 = clampPlotX(Math.max(dragStartX, dragCurrentX));
      make("rect", {{
        x: x0,
        y: m.t,
        width: Math.max(0, x1 - x0),
        height: ih,
        fill: "rgba(47, 107, 214, 0.20)",
        stroke: "#2f6bd6",
        "stroke-width": 1,
        "pointer-events": "none"
      }});
    }}
    updateButtons();
  }};

  svg.addEventListener("mousedown", (ev) => {{
    if (ev.button !== 0) return;
    const sx = toSvgX(ev);
    if (sx < m.l || sx > m.l + iw) return;
    isDragging = true;
    dragStartX = sx;
    dragCurrentX = sx;
    tip.style.display = "none";
    draw();
  }});
  svg.addEventListener("mousemove", (ev) => {{
    if (!isDragging) return;
    dragCurrentX = clampPlotX(toSvgX(ev));
    draw();
  }});
  svg.addEventListener("mouseup", () => {{
    if (!isDragging) return;
    const x0 = clampPlotX(Math.min(dragStartX, dragCurrentX));
    const x1 = clampPlotX(Math.max(dragStartX, dragCurrentX));
    isDragging = false;
    if (x1 - x0 > 6) {{
      const nextMin = xToData(x0, currentXMin, currentXMax);
      const nextMax = xToData(x1, currentXMin, currentXMax);
      applyRange(nextMin, nextMax, true);
      return;
    }}
    draw();
  }});
  svg.addEventListener("mouseleave", () => {{
    if (isDragging) {{
      isDragging = false;
      draw();
    }}
    tip.style.display = "none";
  }});
  svg.addEventListener("dblclick", () => {{
    resetZoom();
  }});
  svg.addEventListener("wheel", (ev) => {{
    ev.preventDefault();
    const sx = toSvgX(ev);
    if (sx < m.l || sx > m.l + iw) return;
    const factor = ev.deltaY < 0 ? 0.86 : 1.18;
    const center = xToData(clampPlotX(sx), currentXMin, currentXMax);
    const left = center - currentXMin;
    const right = currentXMax - center;
    let nextMin = center - left * factor;
    let nextMax = center + right * factor;
    const fullSpan = originalXMax - originalXMin;
    if (nextMax - nextMin >= fullSpan) {{
      resetZoom();
      return;
    }}
    if (nextMin < originalXMin) {{
      nextMax += (originalXMin - nextMin);
      nextMin = originalXMin;
    }}
    if (nextMax > originalXMax) {{
      nextMin -= (nextMax - originalXMax);
      nextMax = originalXMax;
    }}
    nextMin = Math.max(originalXMin, nextMin);
    nextMax = Math.min(originalXMax, nextMax);
    applyRange(nextMin, nextMax, true);
  }}, {{ passive: false }});
  svg.addEventListener("contextmenu", (ev) => {{
    ev.preventDefault();
    goBack();
  }});
  btnReset.addEventListener("click", resetZoom);
  btnBack.addEventListener("click", goBack);

  draw();
  </script>
</body>
</html>
"""
    output_html.write_text(html, encoding="utf-8")


def calc_madelung_from_poscar(
    poscar_path: str = "POSCAR",
    output_log: str | None = None,
    oxidation_states: str | None = None,
):
    poscar_file = Path(poscar_path)
    if not poscar_file.exists():
        raise FileNotFoundError(f"POSCAR file not found: {poscar_path}")

    structure = _load_structure(str(poscar_file))

    oxidation_map = _parse_oxidation_states(oxidation_states)
    if oxidation_map:
        structure.add_oxidation_state_by_element(oxidation_map)
        oxidation_mode = f"manual ({oxidation_states})"
    else:
        guesses = structure.composition.oxi_state_guesses()
        guess_map = None
        if guesses:
            for candidate in guesses:
                if any(abs(float(v)) > 1e-12 for v in candidate.values()):
                    guess_map = {k: float(v) for k, v in candidate.items()}
                    break
            if guess_map is None:
                guess_map = {k: float(v) for k, v in guesses[0].items()}

        if guess_map:
            structure.add_oxidation_state_by_element(guess_map)
            oxidation_mode = f"guessed by composition ({guess_map})"
        else:
            structure.add_oxidation_state_by_guess()
            oxidation_mode = "guessed by pymatgen"

    if all(abs(float(site.specie.oxi_state)) <= 1e-12 for site in structure):
        raise ValueError(
            "Failed to assign non-zero oxidation states automatically. "
            "Please pass --oxidation-states (e.g., \"Mn:2,Cr:3,O:-2\")."
        )

    ewald = EwaldSummation(structure)
    total_energy = float(ewald.total_energy)
    natoms = len(structure)
    energy_per_atom = total_energy / natoms if natoms > 0 else np.nan
    species_counter = Counter(str(site.specie) for site in structure)
    species_order = []
    for site in structure:
        specie_str = str(site.specie)
        if specie_str not in species_order:
            species_order.append(specie_str)
    oxidation_summary = ", ".join(
        f"{species} x{species_counter[species]}" for species in species_order
    )

    if output_log is None:
        output_log = f"madelung-{poscar_file.name}.log"
    log_path = Path(output_log)

    lines = [
        f"Timestamp: {datetime.now().isoformat()}",
        f"Input POSCAR: {poscar_file.resolve()}",
        f"Oxidation assignment: {oxidation_mode}",
        f"Oxidation states summary: {oxidation_summary}",
        f"Number of atoms: {natoms}",
        f"Madelung energy (total): {total_energy:.12f} eV",
        f"Madelung energy (per atom): {energy_per_atom:.12f} eV/atom",
    ]
    log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    for line in lines[1:]:
        print(line)
    print(f"Log saved: {log_path}")
