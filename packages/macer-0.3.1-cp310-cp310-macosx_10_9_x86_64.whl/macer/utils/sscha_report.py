import argparse
from pathlib import Path


def build_sscha_report_parser(parser: argparse.ArgumentParser | None = None) -> argparse.ArgumentParser:
    if parser is None:
        parser = argparse.ArgumentParser(
            prog="macer util sscha report",
            description="Create consolidated SSCHA post-analysis report (HTML).",
        )
    parser.add_argument("--dir", required=True, help="SSCHA output directory.")
    parser.add_argument("--html", action="store_true", default=True, help="Generate HTML report.")
    parser.add_argument("--output", default="sscha_report.html", help="Output HTML path.")
    parser.add_argument("--show-cycles", type=int, default=5, help="Recent cycles shown in summary.")
    return parser


def run_sscha_report(args):
    from macer.utils.sscha_summary import summarize_sscha_directory

    run_dir = Path(args.dir).expanduser().resolve()
    summary = summarize_sscha_directory(run_dir, show_cycles=args.show_cycles, strict=False)

    out = Path(args.output).expanduser().resolve()
    html = _build_html(summary)
    out.write_text(html, encoding="utf-8")
    print(f"Wrote HTML report: {out}")
    return {"run_dir": str(run_dir), "output_html": str(out)}


def _build_html(summary: dict) -> str:
    rows = []
    rows.append(f"<tr><th>Status</th><td>{summary.get('status')}</td></tr>")
    rows.append(f"<tr><th>Cycles total</th><td>{summary.get('cycles_total')}</td></tr>")
    rows.append(f"<tr><th>Last cycle</th><td>{summary.get('last_cycle')}</td></tr>")
    rows.append(f"<tr><th>FC diff last</th><td>{summary.get('fc_diff_last')}</td></tr>")
    rows.append(f"<tr><th>Tolerance</th><td>{summary.get('tolerance')}</td></tr>")
    rows.append(f"<tr><th>FC ratio</th><td>{summary.get('fc_ratio')}</td></tr>")
    wq = summary.get("weight_quality", {})
    rows.append(f"<tr><th>ESS min ratio</th><td>{wq.get('min_ess_ratio')}</td></tr>")
    rows.append(f"<tr><th>ESS mean ratio</th><td>{wq.get('mean_ess_ratio')}</td></tr>")
    et = summary.get("energy_trend", {})
    rows.append(f"<tr><th>Energy trend</th><td>{et.get('state')}</td></tr>")
    integ = summary.get("integrity", {})
    rows.append(f"<tr><th>Missing files</th><td>{len(integ.get('missing_files', []))}</td></tr>")
    rows.append(f"<tr><th>Shape mismatch</th><td>{len(integ.get('shape_mismatch', []))}</td></tr>")
    rows.append(f"<tr><th>NaN detected</th><td>{len(integ.get('nan_detected', []))}</td></tr>")

    return f"""<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>SSCHA Report</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; margin: 24px; }}
    table {{ border-collapse: collapse; width: 760px; }}
    th, td {{ border: 1px solid #ddd; padding: 8px 10px; text-align: left; }}
    th {{ width: 240px; background: #f6f6f6; }}
    h1 {{ margin: 0 0 12px 0; }}
    .muted {{ color: #666; }}
  </style>
</head>
<body>
  <h1>SSCHA Report</h1>
  <p class="muted">run_dir: {summary.get('run_dir')}</p>
  <table>
    {''.join(rows)}
  </table>
</body>
</html>
"""
