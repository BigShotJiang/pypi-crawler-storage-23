"""
QSCAILD command implementation.

This module owns the `macer phonopy qscaild` execution path.
"""

from __future__ import annotations

import argparse
import itertools
import os
import random
import shutil
import subprocess
import sys
import time
import traceback
from collections import defaultdict
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import scipy.constants as codata
import yaml
from tqdm import tqdm
try:
    from numba import njit, prange
    _HAS_NUMBA = True
except Exception:
    _HAS_NUMBA = False
    njit = None
    prange = range

_NUMERIC_BACKEND = "numba" if _HAS_NUMBA else "numpy"
_NUMBA_RUNTIME_FAILED = False
_NUMBA_FALLBACK_LOGGED = False

def _log_numeric_backend():
    if _NUMERIC_BACKEND == "numba":
        print("Numeric backend: numba-accelerated kernels are enabled.")
    else:
        print("Numeric backend: NumPy fallback is active (numba unavailable).")

from macer.calculator.factory import get_calculator, ALL_SUPPORTED_FFS
from macer.defaults import DEFAULT_MODELS, DEFAULT_DEVICE, DEFAULT_FF, resolve_model_path
from macer.utils.logger import Logger
from macer.utils.struct_tools import resolve_structure_inputs

EV_A3_TO_GPA = 160.21766208


def _resolve_model_path(ff: str, model_path: str | None) -> str | None:
    if model_path:
        return resolve_model_path(str(model_path))

    ffs_using_model_name = {"fairchem", "orb", "chgnet", "m3gnet"}
    default_model_name = DEFAULT_MODELS.get(ff)

    if default_model_name:
        if ff in ffs_using_model_name:
            return default_model_name
        return resolve_model_path(default_model_name)
    return None


# Global cache for symfc basis sets to skip redundant symmetry analysis
# Key: (tuple(atomic_numbers), tuple(supercell_matrix.flatten()), symprec)
_SYMFC_BASIS_CACHE = {}


def _fit_fc2_and_fc3(U_scaled, F_scaled, ph):
    from symfc.utils.utils import SymfcAtoms
    from symfc.basis_sets import FCBasisSetO2, FCBasisSetO3
    from symfc.solvers import FCSolverO2O3

    print("    Fitting 2nd and 3rd order force constants simultaneously using symfc...")
    supercell = ph.supercell
    
    # 1. Check cache for basis sets
    cache_key = (tuple(supercell.numbers), tuple(np.round(supercell.cell, 6).flatten()), 1e-5)
    
    if cache_key in _SYMFC_BASIS_CACHE and "o2" in _SYMFC_BASIS_CACHE[cache_key] and "o3" in _SYMFC_BASIS_CACHE[cache_key]:
        print("    Reusing cached FC2 and FC3 basis sets.")
        basis_set_o2 = _SYMFC_BASIS_CACHE[cache_key]["o2"]
        basis_set_o3 = _SYMFC_BASIS_CACHE[cache_key]["o3"]
    else:
        symfc_supercell = SymfcAtoms(
            cell=supercell.cell,
            scaled_positions=supercell.scaled_positions,
            numbers=supercell.numbers,
        )

        print("    Computing FC2 basis set...")
        basis_set_o2 = FCBasisSetO2(symfc_supercell).run()
        if basis_set_o2._blocked_basis_set is None:
            raise RuntimeError("FC2 basis set computation failed, _blocked_basis_set is None.")

        print("    Computing FC3 basis set...")
        basis_set_o3 = FCBasisSetO3(symfc_supercell).run()
        if basis_set_o3._blocked_basis_set is None:
            raise RuntimeError("FC3 basis set computation failed, _blocked_basis_set is None.")
            
        # Store in cache
        _SYMFC_BASIS_CACHE[cache_key] = {"o2": basis_set_o2, "o3": basis_set_o3}

    print("    Solving for FC2 and FC3...")
    solver = FCSolverO2O3([basis_set_o2, basis_set_o3])
    solver.solve(U_scaled, F_scaled)

    fc2, fc3 = solver.full_fc
    if fc2 is None or fc3 is None:
        raise RuntimeError("symfc failed to compute FC2/FC3.")

    print("    symfc fitting complete.")
    return fc2, fc3
    solver = FCSolverO2O3([basis_set_o2, basis_set_o3])
    solver.solve(U_scaled, F_scaled)

    fc2, fc3 = solver.full_fc
    if fc2 is None or fc3 is None:
        raise RuntimeError("symfc failed to compute FC2/FC3.")

    print("    symfc fitting complete.")
    return fc2, fc3


def _fit_fc2_only(U_scaled, F_scaled, ph):
    from symfc.utils.utils import SymfcAtoms
    from symfc.basis_sets import FCBasisSetO2
    from symfc.solvers import FCSolverO2

    supercell = ph.supercell
    cache_key = (tuple(supercell.numbers), tuple(np.round(supercell.cell, 6).flatten()), 1e-5)
    
    if cache_key in _SYMFC_BASIS_CACHE and "o2" in _SYMFC_BASIS_CACHE[cache_key]:
        print("    Reusing cached FC2 basis set.")
        basis_set_o2 = _SYMFC_BASIS_CACHE[cache_key]["o2"]
    else:
        symfc_supercell = SymfcAtoms(
            cell=supercell.cell,
            scaled_positions=supercell.scaled_positions,
            numbers=supercell.numbers,
        )
        print("    Computing FC2 basis set...")
        basis_set_o2 = FCBasisSetO2(symfc_supercell).run()
        if basis_set_o2._blocked_basis_set is None:
            raise RuntimeError("FC2 basis set computation failed.")
        _SYMFC_BASIS_CACHE[cache_key] = {"o2": basis_set_o2}

    solver = FCSolverO2(basis_set_o2)
    solver.solve(U_scaled, F_scaled)
    return solver.full_fc


def fit_weighted_fc(U, F, w, ph, include_third_order=False):
    sqrtw = np.sqrt(w)[:, None, None]
    U_scaled = sqrtw * U
    F_scaled = sqrtw * F

    if not include_third_order:
        try:
            fc2 = _fit_fc2_only(U_scaled, F_scaled, ph)
            return fc2, None
        except Exception as e:
            import warnings
            warnings.warn(f"symfc FC2 fitting failed ({e}). Falling back to default Phonopy SVD fitting engine.")
            ph.dataset = {"displacements": U_scaled, "forces": F_scaled}
            ph.produce_force_constants()
            return ph.force_constants.copy(), None

    try:
        fc2, fc3 = _fit_fc2_and_fc3(U_scaled, F_scaled, ph)
        return fc2, fc3
    except RuntimeError as exc:
        print(f"  WARNING: FC3 fitting failed with error: {exc}")
        print("           Falling back to FC2-only fitting for this iteration.")
        try:
            fc2 = _fit_fc2_only(U_scaled, F_scaled, ph)
            return fc2, None
        except Exception as e:
            import warnings
            warnings.warn(f"symfc FC2 fitting fallback failed ({e}). Falling back to default Phonopy SVD fitting engine.")
            ph.dataset = {"displacements": U_scaled, "forces": F_scaled}
            ph.produce_force_constants()
            return ph.force_constants.copy(), None


def _compute_fc3_free_energy(fc3, U, w):
    if fc3 is None:
        return 0.0
    cubic = np.einsum("ijklmn,sil,sjm,skn->s", fc3, U, U, U)
    return -np.sum(w * cubic) / 6.0


def compute_weighted_free_energy(U, E, FC, FC3, w, ph, T, mesh, return_components=False):
    from phonopy.physical_units import get_physical_units

    ph.force_constants = FC
    ph.run_mesh(mesh)
    ph.run_thermal_properties(t_min=T, t_max=T, t_step=T)
    hfe_kJmol = ph.get_thermal_properties_dict()["free_energy"][0]
    hfe = hfe_kJmol / get_physical_units().EvTokJmol

    V_mean = np.sum(w * E)
    V_harm = 0.5 * np.sum(w * np.einsum("ijab,nia,njb->n", FC, U, U))
    n_prim = len(ph.supercell) / len(ph.primitive)
    F3 = _compute_fc3_free_energy(FC3, U, w)
    F_total = hfe + (V_mean - V_harm) / n_prim + F3 / n_prim

    if return_components:
        return F_total, hfe, V_mean / n_prim, V_harm / n_prim
    return F_total


def _read_band_yaml_data(band_yaml_path):
    with open(band_yaml_path, "r") as file:
        data = yaml.safe_load(file)

    phonons = data["phonon"]
    distances = []
    frequencies = []
    qpoints = []
    for p in phonons:
        distances.append(p["distance"])
        frequencies.append([b["frequency"] for b in p["band"]])
        qpoints.append(p["q-position"])

    distances = np.array(distances)
    frequencies = np.array(frequencies)
    qpoints = np.array(qpoints)
    segment_nqpoint = data["segment_nqpoint"]

    bands = []
    q_idx = 0
    for nq in segment_nqpoint:
        bands.append(qpoints[q_idx:q_idx + nq])
        q_idx += nq

    return distances, frequencies, bands, segment_nqpoint


def _write_band_dat(band_yaml_path, dat_filename):
    try:
        distances, frequencies, _, segment_nqpoint = _read_band_yaml_data(band_yaml_path)

        with open(dat_filename, "w") as f:
            f.write("# q-distance, frequency\n")
            for i, freqs_band in enumerate(frequencies.T):
                f.write(f"# mode {i + 1}\n")
                q_idx = 0
                for nq in segment_nqpoint:
                    for d, freq in zip(distances[q_idx:q_idx + nq], freqs_band[q_idx:q_idx + nq]):
                        f.write(f"{d:12.8f} {freq:15.8f}\n")
                    q_idx += nq
                    f.write("\n")
                f.write("\n")
    except Exception as exc:
        print(f"    Could not write .dat file: {exc}")


def _plot_iterative_band_structure(ph, band_conf_path, iter_num, input_poscar_stem):
    from phonopy.cui.settings import PhonopyConfParser
    from phonopy.phonon.band_structure import get_band_qpoints

    print(f"  Plotting band structure for iteration {iter_num}...")
    try:
        conf_parser = PhonopyConfParser(filename=str(band_conf_path))
        settings = conf_parser.settings

        npoints = settings.band_points if settings.band_points else 51
        qpoints = get_band_qpoints(settings.band_paths, npoints=npoints)
        labels = settings.band_labels
        path_connections = []
        for paths in settings.band_paths:
            path_connections += [True] * (len(paths) - 2)
            path_connections.append(False)

        ph.run_band_structure(qpoints, path_connections=path_connections, labels=labels)

        pdf_name = f"band-{input_poscar_stem}_{iter_num}.pdf"
        yaml_name = f"band-{input_poscar_stem}_{iter_num}.yaml"
        dat_name = f"band-{input_poscar_stem}_{iter_num}.dat"

        ph.plot_band_structure().savefig(pdf_name)
        ph.write_yaml_band_structure(filename=yaml_name)
        _write_band_dat(yaml_name, dat_name)
    except Exception as exc:
        print(f"    Could not plot band structure for iteration {iter_num}: {exc}")
        traceback.print_exc()


def _append_text(paths, text: str):
    for p in paths:
        with p.open("a") as f:
            f.write(text)


def _describe_top_file(name: str) -> str:
    if name.startswith("FC3_") and name.endswith(".hdf5"):
        return "3rd-order force constants (fc3) snapshot in HDF5."
    if name.startswith("adp_iter_") and name.endswith(".cif"):
        return "Primitive ADP CIF with anisotropic displacement tensor."
    if name.startswith("adp_iter_") and name.endswith(".dat"):
        return "Primitive ADP table: U11/U22/U33/U23/U13/U12/Uiso/Biso."
    if name.startswith("adp_supercell_iter_") and name.endswith(".cif"):
        return "Supercell ADP CIF with anisotropic displacement tensor."
    if name.startswith("adp_supercell_iter_") and name.endswith(".dat"):
        return "Supercell ADP table: U11/U22/U33/U23/U13/U12/Uiso/Biso."
    if name == "adp_final.dat":
        return "Final primitive ADP table (alias of last saved iteration)."
    if name == "adp_final.cif":
        return "Final primitive ADP CIF (alias of last saved iteration)."
    if name == "adp_supercell_final.dat":
        return "Final supercell ADP table (alias of last saved iteration)."
    if name == "adp_supercell_final.cif":
        return "Final supercell ADP CIF (alias of last saved iteration)."
    if name.startswith("distribution_proj_final_element_") and name.endswith(".dat"):
        return "Final element-averaged displacement distribution table."
    if name.startswith("distribution_proj_final_element_") and name.endswith(".pdf"):
        return "Final element-averaged displacement distribution plot."
    if name.startswith("distribution_proj_iter_") and name.endswith(".dat"):
        return "Element-averaged displacement distribution table (x/y/z and optional projected axis)."
    if name.startswith("distribution_proj_iter_") and name.endswith(".pdf"):
        return "Element-averaged displacement distribution plot."
    if name.startswith("band-") and name.endswith(".pdf"):
        return "Band structure plot for a specific saved iteration (or harmonic)."
    if name.startswith("band-") and name.endswith(".yaml"):
        return "Band structure raw YAML for a specific saved iteration (or harmonic)."
    if name.startswith("band-") and name.endswith(".dat"):
        return "Band structure text table for a specific saved iteration (or harmonic)."
    if name == "band.pdf":
        return "Latest promoted band plot."
    if name == "band.yaml":
        return "Latest promoted band YAML."
    if name == "band.dat":
        return "Latest promoted band text table."
    if name == "band.conf":
        return "Band-path configuration used for plotting."
    if name.startswith("cycle_"):
        return "Cycle folder with ensemble snapshots and reweighting logs."
    if name.startswith("FORCE_CONSTANTS_"):
        return "Force-constant tensor snapshot."
    if name == "FORCE_CONSTANTS_init":
        return "Initial harmonic force constants."
    if name == "FORCE_CONSTANTS_CURRENT":
        return "Current force constants after latest update."
    if name == "FORCE_CONSTANTS_PREVIOUS":
        return "Previous-cycle force constants."
    if name == "FORCE_CONSTANTS_QSCAILD_final":
        return "Final force constants at termination."
    if name == "POSCAR_average_primitive_final":
        return "Final weighted average primitive structure (alias of last saved iteration)."
    if name == "POSCAR_average_final":
        return "Final weighted average structure (compatibility alias of last saved iteration)."
    if name == "POSCAR_average_supercell_final":
        return "Final weighted average supercell structure (last saved iteration)."
    if name.startswith("POSCAR_average_supercell_"):
        return "Weighted average supercell structure at saved iteration."
    if name.startswith("POSCAR_average_primitive_"):
        return "Weighted average primitive structure at saved iteration."
    if name.startswith("POSCAR_average_"):
        return "Backward-compatible weighted average POSCAR file."
    if name == "POSCAR_qscaild_input":
        return "Input POSCAR copied into run directory."
    if name == "CONTCAR-relax":
        return "Initial relaxed structure (if initial-isif != 0)."
    if name == "qscaild_fit_r2_history.log":
        return "QSCAILD fit R^2 convergence table by cycle."
    if name == "qscaild_fit_r2_history.pdf":
        return "QSCAILD fit R^2 convergence plot."
    if name == "qscaild_score_history.log":
        return "Compatibility alias of fit-R^2 history log."
    if name == "qscaild_score_history.pdf":
        return "Compatibility alias of fit-R^2 history plot."
    if name == "qscaild_free_energy_history.log":
        return "Compatibility alias of fit-R^2 history."
    if name == "qscaild_free_energy_history.pdf":
        return "Compatibility alias of fit-R^2 history plot."
    if name == "macer_qscaild.log":
        return "Full stdout/stderr log for this run."
    if name.startswith("weights_iter_") and name.endswith(".dat"):
        return "Normalized weights at a saved iteration (text)."
    if name.startswith("weights_iter_") and name.endswith(".npy"):
        return "Normalized weights at a saved iteration (binary)."
    if name == "weights_final.dat":
        return "Final normalized weights (text)."
    if name == "weights_final.npy":
        return "Final normalized weights (binary)."
    if name in ("out_fit", "out_fit.txt"):
        return "Fit summary per iteration."
    if name in ("out_convergence", "out_convergence.txt"):
        return "Convergence summary per iteration."
    if name in ("out_energy", "out_energy.txt"):
        return "Per-cycle mean energy and raw reweighting factors."
    if name in ("out_volume", "out_volume.txt"):
        return "Pressure/volume convergence history (pressure mode)."
    if name == "iteration":
        return "Last completed iteration index."
    if name.startswith("relax-") and name.endswith(".pdf"):
        return "Initial relaxation diagnostics plot."
    if name.startswith("relax-") and name.endswith(".traj"):
        return "Initial relaxation trajectory."
    if name == "README_QSCAILD_OUTPUTS.md":
        return "This guide file."
    return "Run artifact."


def _build_generated_checklist(output_dir: Path) -> str:
    import re
    lines = []
    lines.append("## Generated File Checklist (Current Snapshot)")
    lines.append("This section is refreshed during the run and at run end.")
    entries = sorted(output_dir.iterdir(), key=lambda p: p.name)
    if not entries:
        lines.append("- [ ] No files yet.")
        return "\n".join(lines) + "\n"

    def _category(name: str) -> str:
        if name.startswith("FORCE_CONSTANTS") or name.startswith("FC3_"):
            return "FC"
        if name.startswith("band") or name == "band.conf":
            return "Band"
        if name.startswith("adp_iter_") or name.startswith("adp_supercell_") or name.startswith("adp_final") or name.startswith("POSCAR_average"):
            return "ADP/Structure"
        if name.startswith("distribution_proj_iter_") or name.startswith("distribution_proj_final_"):
            return "Distribution"
        if name.startswith("weights_"):
            return "Weights"
        if name.startswith("out_") or name.startswith("qscaild_free_energy_history") or name.startswith("qscaild_score_history") or name.startswith("qscaild_fit_r2_history") or name == "iteration":
            return "Convergence/History"
        if name.startswith("cycle_"):
            return "Cycle"
        if name.startswith("relax-") or name in ("CONTCAR-relax", "POSCAR_qscaild_input"):
            return "Relax/Input"
        if name in ("macer_qscaild.log", "macer_sscha.log", "README_QSCAILD_OUTPUTS.md"):
            return "Logs/Docs"
        return "Other"

    category_order = [
        "Logs/Docs",
        "Relax/Input",
        "FC",
        "Band",
        "ADP/Structure",
        "Distribution",
        "Weights",
        "Convergence/History",
        "Cycle",
        "Other",
    ]
    grouped = {k: [] for k in category_order}
    for p in entries:
        grouped[_category(p.name)].append(p)

    for cat in category_order:
        if not grouped[cat]:
            continue
        lines.append("")
        lines.append(f"### {cat}")
        
        shown_patterns = set()
        for p in grouped[cat]:
            # Collapse logic: replace iterative numbers with <iter>
            name = p.name
            pattern = re.sub(r'(_i|_iter_|_FIT_)\d{3,4}', r'\1<iter>', name)
            if pattern.startswith("band-") and "_" in pattern:
                # band-<stem>_<iter>.pdf
                pattern = re.sub(r'_\d{4}(\.pdf|\.dat|\.yaml)$', r'_<iter>\1', pattern)
            
            if pattern in shown_patterns:
                continue
            shown_patterns.add(pattern)

            mark = "[x]"
            suffix = "/" if p.is_dir() else ""
            desc = _describe_top_file(name)
            lines.append(f"- {mark} `{pattern}{suffix}`: {desc}")

    # Add one cycle-level detail block if cycle_001 exists.
    c1 = output_dir / "cycle_001"
    if c1.is_dir():
        lines.append("")
        lines.append("## `cycle_001` File Details (Example)")
        for q in sorted(c1.iterdir(), key=lambda x: x.name):
            qdesc = {
                "U.dat": "Displacements (Å), usually shape `(nconf, natom_supercell, 3)`.",
                "U.npy": "Binary version of `U.dat`.",
                "F.dat": "Forces (eV/Å), usually shape `(nconf, natom_supercell, 3)`.",
                "F.npy": "Binary version of `F.dat`.",
                "E.dat": "Energies (eV), usually shape `(nconf,)`.",
                "E.npy": "Binary version of `E.dat`.",
                "FC_origin.dat": "FC used to generate this cycle ensemble.",
                "FC_origin.npy": "Binary version of `FC_origin.dat`.",
                "logp_origin.dat": "Harmonic log-probability under `FC_origin`.",
                "logp_origin.npy": "Binary version of `logp_origin.dat`.",
            }.get(q.name, "Cycle artifact.")
            if q.name.startswith("logp_current_cycle_") and q.suffix == ".dat":
                qdesc = "Re-evaluated log-probability for this cycle under a later FC state."
            if q.name.startswith("logp_current_cycle_") and q.suffix == ".npy":
                qdesc = "Binary version of re-evaluated log-probability."
            lines.append(f"- [x] `cycle_001/{q.name}`: {qdesc}")
    return "\n".join(lines) + "\n"


def _write_output_guide(output_dir: Path, args, input_poscar_path: Path):
    guide_path = output_dir / "README_QSCAILD_OUTPUTS.md"
    projection_axis = getattr(args, "distribution_axis", None)
    proj_text = "not set"
    if projection_axis is not None:
        proj_text = " ".join(f"{x:g}" for x in projection_axis)
    txt = f"""# QSCAILD Output Guide

This file is auto-generated at run start so users can identify each output file quickly.

## Run Summary
- Input structure: `{input_poscar_path}`
- Output directory: `{output_dir}`
- Temperature (K): `{getattr(args, 'temperature', 'N/A')}`
- nconf: `{getattr(args, 'nconf', 'N/A')}`
- nsteps: `{getattr(args, 'nsteps', 'N/A')}`
- save-every: `{getattr(args, 'save_every', 'N/A')}`
- save-npy: `{getattr(args, 'save_npy', False)}`
- tolerance: `{getattr(args, 'tolerance', 'N/A')}`
- pressure mode: `{getattr(args, 'use_pressure', 'False')}`
- pressure tolerance pdiff (kbar): `{getattr(args, 'pdiff', 'N/A')}`
- distribution-axis (fractional): `{proj_text}`

## Top-Level Files
- `macer_qscaild.log`: full run log.
- `FORCE_CONSTANTS_init`: initial harmonic FC.
- `FORCE_CONSTANTS_CURRENT`: FC after the latest update.
- `FORCE_CONSTANTS_PREVIOUS`: FC from the previous cycle.
- `FORCE_CONSTANTS_FIT_<iter>`: fitted FC at saved cycles.
- `FORCE_CONSTANTS_QSCAILD_final`: final FC at termination.
- `FC3_*.hdf5` (if `--include-third-order`): 3rd-order FC snapshots.
- `iteration`: last completed iteration index.

- `out_fit.txt` (`out_fit`): fit summary table per iteration.
- `out_convergence.txt` (`out_convergence`): convergence metrics (`fc_diff_max`, ESS, entropy, pressure error if enabled).
- `out_energy.txt` (`out_energy`): per-cycle mean energy and raw reweighting factors.
- `out_volume.txt` (`out_volume`): pressure/volume history (pressure mode only).

- `qscaild_fit_r2_history.log`: fit-R^2 history table.
- `qscaild_fit_r2_history.pdf`: fit-R^2 convergence plot.
- `qscaild_score_history.log/.pdf`: compatibility aliases.
- `qscaild_free_energy_history.log/.pdf`: compatibility aliases.

- `weights_iter_<iter>.dat` (and optionally `.npy`): normalized weights at saved cycles.
- `weights_final.dat` (and optionally `.npy`): final normalized weights.

- `band-<stem>_harmonic.pdf/.yaml/.dat`: harmonic band output (initial FC).
- `band-<stem>_<iter>.pdf/.yaml/.dat`: band output at saved cycles.
- `band.pdf`, `band.yaml`, `band.dat`: latest promoted band files.
- `band.conf`: band-path configuration used for band exports.

- `POSCAR_qscaild_input`: input POSCAR copied into the run directory.
- `CONTCAR-relax`: initial relaxed structure if `initial-isif != 0`.
- `POSCAR_average_primitive_i<iter>`: weighted average primitive structure at saved cycles.
- `POSCAR_average_i<iter>`: compatibility alias (currently primitive-based output).
- `POSCAR_average_supercell_i<iter>`: weighted average supercell structure at saved cycles.
- `POSCAR_average_primitive_final`, `POSCAR_average_final`, `POSCAR_average_supercell_final`: aliases of the last-cycle weighted average structures.

- `adp_iter_<iter>.dat`: primitive ADP table with columns
  `U11 U22 U33 U23 U13 U12 Uiso Biso(=8*pi^2*Uiso)`.
- `adp_iter_<iter>.cif`: primitive CIF including `_atom_site_U_iso_or_equiv` and anisotropic U tensor block.
- `adp_supercell_iter_<iter>.dat/.cif`: supercell ADP outputs on supercell atoms.
- `adp_final.dat`, `adp_final.cif`: aliases of the last-cycle primitive ADP outputs.
- `adp_supercell_final.dat`, `adp_supercell_final.cif`: aliases of the last-cycle supercell ADP outputs.

- `distribution_proj_iter_<iter>_element_<El>_avg.dat/.pdf`:
  element-averaged displacement distributions on primitive atoms.
- `distribution_proj_final_element_<El>_avg.dat/.pdf`: aliases of the last-cycle element-averaged distributions.
  - `dat` columns: `disp_A pdf_x pdf_y pdf_z` (+ `pdf_proj` if `--distribution-axis` is set).
  - `pdf` curves: `x, y, z` (+ `proj` if enabled), centered around displacement 0.

## `cycle_<NNN>/` Folder Structure
Each cycle folder stores ensemble data used for reweighting and fitting.

- `U.dat` (and optionally `U.npy`):
  displacements, shape typically `(nconf, natom_supercell, 3)`, unit Å.
- `F.dat` (and optionally `F.npy`):
  forces, shape `(nconf, natom_supercell, 3)`, unit eV/Å.
- `E.dat` (and optionally `E.npy`):
  energies, shape `(nconf,)`, unit eV.
- `FC_origin.dat` (and optionally `FC_origin.npy`):
  FC used when this cycle ensemble was generated.
- `logp_origin.dat` (and optionally `logp_origin.npy`):
  harmonic log-probability (up to normalization) under `FC_origin`.
- `logp_current_cycle_<iter>.dat` (and optionally `.npy`):
  the same ensemble re-evaluated with the FC of iteration `<iter>`.
  Reweighting uses `exp(logp_current - logp_origin)`.

## Notes
- `.txt` and no-extension compatibility files are both written.
- When pressure mode is off, volume/pressure files may be empty or minimal.
"""
    txt += "\n" + _build_generated_checklist(output_dir)
    guide_path.write_text(txt)


def _parse_mass_map(args) -> dict[str, float]:
    mass_map = {}
    if not getattr(args, "mass", None):
        return mass_map
    if len(args.mass) % 2 != 0:
        raise ValueError("Error: --mass option requires pairs of Symbol Mass (e.g. H 2.014).")
    for i in range(0, len(args.mass), 2):
        sym = str(args.mass[i])
        try:
            mass_map[sym] = float(args.mass[i + 1])
        except ValueError as exc:
            raise ValueError(f"Error: Invalid mass value for {sym}: {args.mass[i + 1]}") from exc
    return mass_map


def _apply_mass_override_to_phonopy_atoms(unitcell, mass_map: dict[str, float]):
    if not mass_map:
        return unitcell
    symbols = [str(s) for s in unitcell.symbols]
    if getattr(unitcell, "masses", None) is None:
        masses = [None] * len(symbols)
    else:
        masses = list(unitcell.masses)
    for i, sym in enumerate(symbols):
        if sym in mass_map:
            masses[i] = mass_map[sym]
    unitcell.masses = masses
    return unitcell


def _build_output_dir(args, input_poscar_path: Path, create: bool = True) -> Path:
    if args.output_dir:
        base_output_dir = Path(args.output_dir).resolve()
    else:
        # Follow phonopy-style naming convention.
        base_output_dir = input_poscar_path.parent / f"qscaild-{input_poscar_path.stem}-ff={args.ff}"

    output_dir = base_output_dir
    i = 1
    while output_dir.exists():
        output_dir = Path(f"{base_output_dir}-NEW{i:02d}")
        i += 1
    if create:
        output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir


def _prepare_input_poscar(args, output_dir: Path, convert_cif: bool = True) -> Path:
    from ase.io import read as ase_read, write as ase_write

    input_list = resolve_structure_inputs(
        poscar_paths=[args.poscar] if args.poscar else None,
        cif_paths=[args.cif] if args.cif else None,
        formula=getattr(args, "formula", None),
        mpid=getattr(args, "mpid", None),
    )
    if not input_list:
        raise ValueError("Error: Please provide structure input via -p/-c/-f/-m.")

    input_path = Path(input_list[0]).resolve()
    if not input_path.is_file():
        raise FileNotFoundError(f"Input file not found at '{input_path}'.")

    # Convert CIF-like inputs to POSCAR in output dir for a stable run path.
    if convert_cif and input_path.suffix.lower() == ".cif":
        converted_poscar = output_dir / "POSCAR_input"
        atoms_in = ase_read(str(input_path))
        ase_write(str(converted_poscar), atoms_in, format="vasp")
        return converted_poscar

    return input_path


def _prepare_reweighting_engine(fc: np.ndarray, ph, temperature: float):
    """
    Diagonalize FC and prepare quantum variances once for all snapshots.
    """
    natom = len(ph.supercell)
    nmodes = 3 * natom
    fc_2d = fc.reshape(nmodes, nmodes)
    masses = ph.supercell.masses
    m_vec = np.repeat(masses, 3)
    inv_sqrt_m = 1.0 / np.sqrt(m_vec)

    # Diagonalize Dynamical Matrix
    dynmat = fc_2d * np.outer(inv_sqrt_m, inv_sqrt_m)
    eigvals, eigvecs = np.linalg.eigh(dynmat)

    # THz frequencies and Quantum Variances
    # 15.633302 is the VaspToTHz conversion factor: sqrt(eV/A^2/AMU) -> THz
    factor = getattr(ph, "_factor", 15.633302)
    if factor is None: factor = 15.633302
    freqs = np.sqrt(np.abs(eigvals)) * factor
    unit_conv = 0.50449053 # hbar / (4 * pi * AMU * 1e-8) in A^2 * THz
    
    cutoff = 0.05
    safe_freqs = np.where(freqs > cutoff, freqs, 1.0)
    n_B = np.array([_fbe(fq, temperature) for fq in safe_freqs])
    variances = unit_conv / safe_freqs * (0.5 + n_B)

    # Pre-calculated terms for Log-PDF
    active = freqs > cutoff
    engine = {
        "eigvecs": eigvecs[:, active],
        "inv_vars": 1.0 / variances[active],
        "log_vars_sum": np.sum(np.log(2.0 * np.pi * variances[active])),
        "m_vec": m_vec,
    }
    return engine


def _compute_harmonic_logpdf_with_engine(U: np.ndarray, engine: dict) -> np.ndarray:
    """
    Apply pre-calculated reweighting engine to a set of snapshots.
    """
    # Project displacements onto normal modes
    U_flat = U.reshape(U.shape[0], -1)
    U_mw = U_flat * np.sqrt(engine["m_vec"])
    q = U_mw @ engine["eigvecs"] 

    # Sum Log-PDF
    logp = -0.5 * (np.sum((q**2) * engine["inv_vars"], axis=1) + engine["log_vars_sum"])
    return logp


def _compute_harmonic_logpdf(U: np.ndarray, fc: np.ndarray, beta: float, ph=None, temperature: float = 0.0) -> np.ndarray:
    if ph is None or temperature <= 0.0:
        quad = _quad_samples(U, fc)
        return -0.5 * beta * quad

    # For single-shot calls, prepare and apply immediately.
    engine = _prepare_reweighting_engine(fc, ph, temperature)
    return _compute_harmonic_logpdf_with_engine(U, engine)


def _generate_cycle_ensemble(ph, fc_current, temperature: float, nconf: int):
    from phonopy.phonon.random_displacements import RandomDisplacements
    from phonopy.harmonic.force_constants import set_translational_invariance

    fc_asr = fc_current.copy()
    set_translational_invariance(fc_asr)
    rd = RandomDisplacements(ph.supercell, ph.primitive, fc_asr, cutoff_frequency=0.05)
    rd.run(temperature, number_of_snapshots=nconf)
    return np.asarray(rd.u)


def _fbe(freq_thz: float, temperature: float) -> float:
    if temperature == 0.0:
        return 0.0
    x = codata.h * abs(freq_thz) * 1e12 / (codata.k * temperature)
    if x < 2.0:
        return 1.0 / np.expm1(x)
    return -np.exp(-x) / np.expm1(-x)


def _create_mesh(nq: int) -> np.ndarray:
    pts = []
    for i, j, k in itertools.product(range(nq), range(nq), range(nq)):
        pts.append([float(i) / nq, float(j) / nq, float(k) / nq])
    q = np.asarray(pts, dtype=float)
    center = np.mean(q, axis=0)
    q -= center
    return q


if _HAS_NUMBA:
    @njit(parallel=True, cache=True)
    def _build_covariance_kernel_numba(
        qpoints, 
        freqs_all, 
        eigvecs_all, 
        cell_triplets, 
        positions, 
        n_B_all, 
        size, 
        nat_prim, 
        ncells, 
        nmodes
    ):
        matrix = np.zeros((size, size), dtype=np.complex128)
        cutoff = 0.05
        nqpoints = qpoints.shape[0]

        for iq in range(nqpoints):
            q = qpoints[iq]
            freqs = freqs_all[iq]
            eigvecs = eigvecs_all[iq]
            n_B = n_B_all[iq]
            
            # Vectorized phase factors for cell translations (ncells,)
            factors = np.empty(ncells, dtype=np.complex128)
            for icell in range(ncells):
                dot_val = q[0]*cell_triplets[icell, 0] + q[1]*cell_triplets[icell, 1] + q[2]*cell_triplets[icell, 2]
                factors[icell] = np.exp(2j * np.pi * dot_val)
            
            # Vectorized phase factors for primitive atoms (nat_prim,)
            atom_phases = np.empty(nat_prim, dtype=np.complex128)
            for ia in range(nat_prim):
                dot_val = q[0]*positions[0, ia] + q[1]*positions[1, ia] + q[2]*positions[2, ia]
                atom_phases[ia] = np.exp(2j * np.pi * dot_val)

            for im in range(nmodes):
                if freqs[im] <= cutoff:
                    continue
                
                lpsi = np.empty(size, dtype=np.complex128)
                weight = np.sqrt((1.0 + 2.0 * n_B[im]) / freqs[im])
                
                for ia in range(nat_prim):
                    e_ia_x = eigvecs[ia*3 + 0, im]
                    e_ia_y = eigvecs[ia*3 + 1, im]
                    e_ia_z = eigvecs[ia*3 + 2, im]
                    p_ia = atom_phases[ia] * weight
                    
                    for icell in range(ncells):
                        f_c = factors[icell] * p_ia
                        lpsi[ia*ncells*3 + icell*3 + 0] = e_ia_x * f_c
                        lpsi[ia*ncells*3 + icell*3 + 1] = e_ia_y * f_c
                        lpsi[ia*ncells*3 + icell*3 + 2] = e_ia_z * f_c
                
                # Parallel outer product addition
                for i in prange(size):
                    val_i = lpsi[i]
                    for j in range(size):
                        matrix[i, j] += val_i * lpsi[j].conjugate()
                        
        return matrix

def _build_displacement_covariance(ph, fc_current, temperature: float, grid: int, imaginary_freq: float):
    """
    Build displacement covariance in Angstrom^2 using a q-mesh integration.
    """
    from phonopy.harmonic.force_constants import set_translational_invariance
    fc_asr = fc_current.copy()
    set_translational_invariance(fc_asr)
    ph.force_constants = fc_asr
    supercell = ph.supercell
    primitive = ph.primitive
    nat_prim = len(primitive)
    nat_super = len(supercell)
    nmodes = 3 * nat_prim
    dim = np.array(ph.supercell_matrix, dtype=float)
    if dim.shape != (3, 3):
        raise ValueError("Unexpected supercell_matrix shape.")
    if not np.allclose(dim, np.diag(np.diag(dim))):
        raise ValueError("Only diagonal supercell matrices are supported for covariance mesh integration.")
    na, nb, nc = [int(round(v)) for v in np.diag(dim)]
    if na * nb * nc != (nat_super // nat_prim):
        raise ValueError("Inconsistent primitive/supercell relation for covariance assembly.")

    # positions in reduced coordinates (shape: 3 x nat_prim)
    positions = np.asarray(primitive.scaled_positions).T
    masses = np.asarray(supercell.masses, dtype=float) * codata.physical_constants["atomic mass constant"][0]
    nq = max(1, int(grid))
    qpoints = _create_mesh(nq) if nq > 1 else np.array([[0.0, 0.0, 0.0]])
    nqpoints = len(qpoints)

    ncells = na * nb * nc
    size = ncells * nmodes
    
    # Collection phase: Gather all frequencies/eigenvectors
    freqs_all = np.empty((nqpoints, nmodes), dtype=float)
    eigvecs_all = np.empty((nqpoints, nmodes, nmodes), dtype=np.complex128)
    n_B_all = np.empty((nqpoints, nmodes), dtype=float)
    
    for iq, q in enumerate(qpoints):
        freqs, eigvecs = ph.get_frequencies_with_eigenvectors(q)
        freqs = np.array(freqs, dtype=float)
        for i in range(len(freqs)):
            if freqs[i] < -1.0e-4:
                if imaginary_freq == -1:
                    freqs[iq] = abs(freqs[i])
                else:
                    freqs[i] = float(imaginary_freq)
        freqs_all[iq] = freqs
        eigvecs_all[iq] = eigvecs
        n_B_all[iq] = np.array([_fbe(fq, temperature) for fq in freqs])

    cell_triplets = np.array(list(itertools.product(range(nc), range(nb), range(na))), dtype=np.float64)

    if _HAS_NUMBA:
        matrix = _build_covariance_kernel_numba(
            qpoints, freqs_all, eigvecs_all, cell_triplets, positions, n_B_all,
            size, nat_prim, ncells, nmodes
        )
    else:
        matrix = np.zeros((size, size), dtype=np.complex128)
        cutoff = 0.05
        for iq in range(nqpoints):
            q = qpoints[iq]
            freqs = freqs_all[iq]
            eigvecs = eigvecs_all[iq]
            n_B = n_B_all[iq]
            
            factors = np.exp(2j * np.pi * (cell_triplets @ q))
            atom_phases = np.exp(2j * np.pi * (q @ positions))
            
            for im in range(nmodes):
                if freqs[im] <= cutoff:
                    continue
                weight = np.sqrt((1.0 + 2.0 * n_B[im]) / freqs[im])
                res_eig_ph = (eigvecs[:, im].reshape(nat_prim, 3) * atom_phases[:, None]) * weight
                lpsi_3d = factors[:, None, None] * res_eig_ph[None, :, :]
                lpsi_reordered = np.ascontiguousarray(lpsi_3d.transpose(1, 0, 2)).flatten()
                matrix += np.outer(lpsi_reordered, lpsi_reordered.conj())

    # Final normalization and mass weighting
    matrix *= codata.hbar / 2.0 / nqpoints / 2.0 / np.pi / 1.0e12  # m^2
    m_inv_sqrt = 1.0 / np.sqrt(masses)
    m_inv_sqrt_rep = np.empty(size // 3)
    for ia in range(nat_prim):
        for icell in range(ncells):
            m_inv_sqrt_rep[ia * ncells + icell] = m_inv_sqrt[ia * ncells + icell]
            
    m_inv_outer = np.outer(np.repeat(m_inv_sqrt_rep, 3), np.repeat(m_inv_sqrt_rep, 3))
    matrix = matrix.real * m_inv_outer * 1.0e20  # Angstrom^2
    
    # Numerical stabilization for sampling.
    matrix = 0.5 * (matrix + matrix.T)
    return matrix


def _sample_displacements_from_covariance(cov: np.ndarray, nconf: int, n_atoms: int) -> np.ndarray:
    cov = np.asarray(cov, dtype=float)
    jitter = 1.0e-10
    cov = cov + np.eye(cov.shape[0]) * jitter
    disp = np.random.multivariate_normal(mean=np.zeros(cov.shape[0]), cov=cov, size=nconf, check_valid="ignore")
    disp = np.asarray(disp, dtype=float).reshape(nconf, n_atoms, 3)
    return disp


def _generate_cycle_ensemble_staged(
    ph,
    fc_current,
    temperature: float,
    nconf: int,
    use_smalldisp: bool,
    imaginary_freq: float,
    grid: int,
):
    # Phase-2 implementation:
    # - use_smalldisp: fixed tiny Gaussian displacement
    # - otherwise: covariance-based sampling with grid and imaginary handling
    if use_smalldisp:
        n_atoms = len(ph.supercell)
        return np.random.normal(loc=0.0, scale=1e-3, size=(nconf, n_atoms, 3))
    cov = _build_displacement_covariance(
        ph,
        fc_current,
        temperature=temperature,
        grid=grid,
        imaginary_freq=imaginary_freq,
    )
    return _sample_displacements_from_covariance(cov, nconf=nconf, n_atoms=len(ph.supercell))


def _evaluate_ensemble(
    U: np.ndarray,
    base_supercell,
    calculator,
    need_stress: bool = False,
    progress_desc: str | None = None,
    sequential: bool = False,
    batch_size: int | None = None,
):
    from ase import Atoms as AseAtoms
    from macer.calculator.factory import evaluate_batch, evaluate_sequential

    base_positions = np.asarray(base_supercell.positions)

    atoms_list = []
    for disp in U:
        snapshot = AseAtoms(
            symbols=base_supercell.symbols,
            positions=base_positions + np.asarray(disp),
            cell=base_supercell.cell,
            pbc=True,
        )
        atoms_list.append(snapshot)

    properties = ["energy", "forces"]
    if need_stress:
        properties.append("stress")

    if not sequential:
        try:
            res = evaluate_batch(
                calculator,
                atoms_list,
                batch_size=batch_size,
                properties=properties,
                verbose=False,
            )
        except Exception as e:
            print(f"  [Warning] Ensemble batch calculation failed:\n  {e}\n  Falling back to sequential evaluation...")
            res = evaluate_sequential(
                calculator,
                atoms_list,
                properties=properties,
                verbose=False,
            )
    else:
        res = evaluate_sequential(
            calculator,
            atoms_list,
            properties=properties,
            verbose=False,
        )

    forces_arr = res["forces"]
    energy_arr = res["energy"]
    stress_arr = res.get("stress")
    return forces_arr, energy_arr, stress_arr


def _save_cycle_data(
    cycle_dir: Path,
    U: np.ndarray,
    F: np.ndarray,
    E: np.ndarray,
    fc_origin: np.ndarray,
    logp_origin: np.ndarray,
    save_npy: bool = False,
):
    _save_array_with_dat(cycle_dir / "U", U, save_npy=save_npy)
    _save_array_with_dat(cycle_dir / "F", F, save_npy=save_npy)
    _save_array_with_dat(cycle_dir / "E", E, save_npy=save_npy)
    _save_array_with_dat(cycle_dir / "FC_origin", fc_origin, save_npy=save_npy)
    _save_array_with_dat(cycle_dir / "logp_origin", logp_origin, save_npy=save_npy)


def _save_array_with_dat(stem: Path, arr: np.ndarray, save_npy: bool = False):
    """
    Save an array as both `.npy` and `.dat`.
    `.dat` format is a flattened text representation with shape metadata.
    """
    a = np.asarray(arr)
    if save_npy:
        np.save(f"{stem}.npy", a)

    dat_path = f"{stem}.dat"
    shape_str = " ".join(str(x) for x in a.shape)
    if a.ndim == 1:
        idx = np.arange(1, len(a) + 1, dtype=int)
        table = np.column_stack((idx, a))
        np.savetxt(
            dat_path,
            table,
            fmt=["%d", "%.16e"],
            header=f"shape {shape_str}\nindex value",
        )
    else:
        flat2d = a.reshape(a.shape[0], -1)
        np.savetxt(
            dat_path,
            flat2d,
            fmt="%.16e",
            header=f"shape {shape_str}",
        )


def _load_saved_array(stem: Path) -> np.ndarray:
    npy = Path(f"{stem}.npy")
    if npy.exists():
        return np.load(npy)
    dat = Path(f"{stem}.dat")
    if not dat.exists():
        raise FileNotFoundError(f"Missing both {npy.name} and {dat.name}")
    with open(dat, "r") as f:
        first = f.readline().strip()
    if not first.startswith("# shape "):
        raise ValueError(f"Missing shape header in {dat}")
    shape = tuple(int(x) for x in first.replace("#", "").split()[1:])
    raw = np.loadtxt(dat, comments="#")
    if len(shape) == 1:
        if raw.ndim == 1:
            return np.array([float(raw[-1])], dtype=float)
        return np.asarray(raw[:, -1], dtype=float)
    raw2d = np.atleast_2d(raw)
    return raw2d.reshape(shape)


def _save_weights_qscaild(weight_file_stem: Path, w: np.ndarray, save_npy: bool = False):
    w = np.asarray(w, dtype=float).reshape(-1)
    if save_npy:
        np.save(f"{weight_file_stem}.npy", w)
    idx = np.arange(1, len(w) + 1, dtype=int)
    table = np.column_stack((idx, w))
    np.savetxt(
        f"{weight_file_stem}.dat",
        table,
        fmt=["%d", "%.16e"],
        header="snapshot_index weight",
    )


def _load_history_for_fit(output_dir: Path, iteration: int, memory: float):
    iteration_min = max(1, int(np.floor(iteration * (1.0 - memory))))
    cycle_ids = list(range(iteration_min, iteration + 1))
    cycle_dirs = [output_dir / f"cycle_{i:03d}" for i in cycle_ids]
    return cycle_ids, cycle_dirs


def _assemble_fit_data(
    cycle_ids,
    cycle_dirs,
    fc_current,
    beta: float,
    iteration: int,
    use_pressure_mode: str,
    save_npy: bool = False,
    ph=None,
    temperature: float = 0.0,
    engine: dict | None = None,
):
    U_all = []
    F_all = []
    LOGW_all = []
    E_all = []
    Stress_all = []
    energy_lines = [
        "\n"
        f"[Iteration {iteration:04d}] "
        f"history_cycles={cycle_ids} total_snapshots={0}\n"
        "cycle_id    mean_energy_eV        mean_raw_weight\n"
    ]

    for cid, cdir in zip(cycle_ids, cycle_dirs):
        U_hist = _load_saved_array(cdir / "U")
        F_hist = _load_saved_array(cdir / "F")
        E_hist = _load_saved_array(cdir / "E")
        logp_origin_hist = _load_saved_array(cdir / "logp_origin")
        
        if engine is not None:
            logp_current_hist = _compute_harmonic_logpdf_with_engine(U_hist, engine)
        else:
            logp_current_hist = _compute_harmonic_logpdf(U_hist, fc_current, beta, ph=ph, temperature=temperature)
            
        _save_array_with_dat(
            cdir / f"logp_current_cycle_{iteration:03d}",
            logp_current_hist,
            save_npy=save_npy,
        )

        w_hist = np.exp(logp_current_hist - logp_origin_hist)
        w_hist = np.clip(w_hist, 1e-300, None)
        U_all.append(U_hist)
        F_all.append(F_hist)
        W_all.append(w_hist)
        E_all.append(E_hist)
        if use_pressure_mode != "False":
            stress_dat = cdir / "Stress.dat"
            stress_npy = cdir / "Stress.npy"
            if stress_dat.exists() or stress_npy.exists():
                Stress_all.append(_load_saved_array(cdir / "Stress"))
        energy_lines.append(
            f"{cid:8d}    {np.mean(E_hist):16.8f}    {np.mean(w_hist):16.6e}\n"
        )

    U_fit = np.concatenate(U_all, axis=0)
    F_fit = np.concatenate(F_all, axis=0)
    E_fit = np.concatenate(E_all, axis=0)
    w_fit = np.concatenate(W_all, axis=0)
    w_fit /= np.sum(w_fit)
    energy_lines[1] = (
        f"[Iteration {iteration:04d}] "
        f"history_cycles={cycle_ids} total_snapshots={len(U_fit)}\n"
    )
    return U_fit, F_fit, E_fit, w_fit, Stress_all, energy_lines


def _weight_stats(w: np.ndarray):
    w = np.asarray(w, dtype=float).reshape(-1)
    w = np.clip(w, 1e-300, None)
    w /= np.sum(w)
    ess = 1.0 / np.sum(w**2)
    entropy = -np.sum(w * np.log(w))
    return ess, entropy


def _update_cell_from_pressure(unitcell, pressure_mode: str, pressure_diag_kbar, pdiff_kbar: float, stress_weighted_voigt):
    # stress in eV/A^3 -> pressure in kbar (sign: P = -sigma)
    pressure_kbar = -np.asarray(stress_weighted_voigt[:3]) * EV_A3_TO_GPA * 10.0
    target = np.asarray(pressure_diag_kbar, dtype=float)
    factor = np.array([1.0, 1.0, 1.0], dtype=float)
    for i in range(3):
        if pressure_kbar[i] > target[i] + pdiff_kbar / 2.0:
            factor[i] = 1.0 + 0.001 * min((pressure_kbar[i] - target[i]) / 10.0, 4.0)
        elif pressure_kbar[i] < target[i] - pdiff_kbar / 2.0:
            factor[i] = 1.0 - 0.001 * min((target[i] - pressure_kbar[i]) / 10.0, 4.0)

    mode = str(pressure_mode)
    if mode == "cubic":
        m = float(np.mean(factor))
        factor[:] = m
    elif mode == "tetragonal":
        m = 0.5 * (factor[0] + factor[1])
        factor[0] = m
        factor[1] = m
    elif mode == "orthorhombic":
        pass
    else:
        return unitcell, pressure_kbar, np.max(np.abs(pressure_kbar - target))

    new_unitcell = unitcell.copy()
    new_cell = np.array(new_unitcell.cell, dtype=float)
    for i in range(3):
        new_cell[i, :] *= factor[i]
    new_unitcell.cell = new_cell
    pressure_err = float(np.max(np.abs(pressure_kbar - target)))
    return new_unitcell, pressure_kbar, pressure_err


def _primitive_groups_from_phonopy(ph):
    p2p = ph.primitive.p2p_map
    s2p = ph.primitive.s2p_map
    nat_prim = len(ph.primitive)
    groups = [[] for _ in range(nat_prim)]
    for s_idx, p_rep in enumerate(s2p):
        p_idx = p2p[int(p_rep)]
        groups[p_idx].append(s_idx)
    return [np.array(g, dtype=int) for g in groups]


def _projection_unit_vector_from_fractional(cell: np.ndarray, frac_axis):
    if frac_axis is None:
        return None
    vfrac = np.asarray(frac_axis, dtype=float).reshape(3)
    if np.linalg.norm(vfrac) < 1e-12:
        raise ValueError("Error: --distribution-axis cannot be a zero vector.")
    vcart = vfrac @ np.asarray(cell, dtype=float)
    nv = np.linalg.norm(vcart)
    if nv < 1e-12:
        raise ValueError("Error: --distribution-axis becomes near-zero in Cartesian basis.")
    return vcart / nv


def _minimum_image_displacements(U: np.ndarray, cell: np.ndarray) -> np.ndarray:
    """
    Wrap Cartesian displacements into the minimum-image range in fractional space.
    This prevents PBC branch jumps from inflating covariance/ADP estimates.
    """
    U = np.asarray(U, dtype=float)
    cell = np.asarray(cell, dtype=float)
    frac = np.einsum("...j,jk->...k", U, np.linalg.inv(cell))
    frac -= np.rint(frac)
    return np.einsum("...j,jk->...k", frac, cell)


def _hist_pdf(values: np.ndarray, weights: np.ndarray, nbins: int = 100):
    max_abs = float(np.max(np.abs(values)))
    xlim = max(1e-4, 1.05 * max_abs)
    bins = np.linspace(-xlim, xlim, nbins + 1)
    centers = 0.5 * (bins[:-1] + bins[1:])
    hist, _ = np.histogram(values, bins=bins, weights=weights, density=True)
    return centers, hist


def _save_primitive_distributions(
    output_dir: Path,
    iteration: int,
    prim_symbols,
    primitive_cell: np.ndarray,
    du_prim_samples: list[np.ndarray],
    w_prim_samples: list[np.ndarray],
    projection_axis_frac=None,
):
    import matplotlib.pyplot as plt

    proj_unit = _projection_unit_vector_from_fractional(primitive_cell, projection_axis_frac)
    by_element_dxyz = defaultdict(list)
    by_element_w = defaultdict(list)
    for sym, dxyz, wxyz in zip(prim_symbols, du_prim_samples, w_prim_samples):
        if dxyz.size == 0:
            continue
        by_element_dxyz[sym].append(dxyz)
        by_element_w[sym].append(wxyz)

    for sym in sorted(by_element_dxyz.keys()):
        dxyz = np.concatenate(by_element_dxyz[sym], axis=0)
        wxyz = np.concatenate(by_element_w[sym], axis=0)
        wxyz /= np.sum(wxyz)

        vals_x = dxyz[:, 0]
        vals_y = dxyz[:, 1]
        vals_z = dxyz[:, 2]
        vals_proj = dxyz @ proj_unit if proj_unit is not None else None

        max_abs = max(
            float(np.max(np.abs(vals_x))),
            float(np.max(np.abs(vals_y))),
            float(np.max(np.abs(vals_z))),
            float(np.max(np.abs(vals_proj))) if vals_proj is not None else 0.0,
        )
        xlim = max(1e-4, 1.05 * max_abs)
        bins = np.linspace(-xlim, xlim, 101)  # centered at 0
        centers = 0.5 * (bins[:-1] + bins[1:])
        hx, _ = np.histogram(vals_x, bins=bins, weights=wxyz, density=True)
        hy, _ = np.histogram(vals_y, bins=bins, weights=wxyz, density=True)
        hz, _ = np.histogram(vals_z, bins=bins, weights=wxyz, density=True)

        avg_dat = output_dir / f"distribution_proj_iter_{iteration:04d}_element_{sym}_avg.dat"
        avg_pdf = output_dir / f"distribution_proj_iter_{iteration:04d}_element_{sym}_avg.pdf"
        if vals_proj is not None:
            hp, _ = np.histogram(vals_proj, bins=bins, weights=wxyz, density=True)
            data = np.column_stack((centers, hx, hy, hz, hp))
            header = "disp_A  pdf_x  pdf_y  pdf_z  pdf_proj"
        else:
            data = np.column_stack((centers, hx, hy, hz))
            header = "disp_A  pdf_x  pdf_y  pdf_z"
        np.savetxt(avg_dat, data, fmt="%.8e", header=header)

        fig, ax = plt.subplots(1, 1, figsize=(7.2, 4.2))
        ax.plot(centers, hx, lw=1.8, label="x")
        ax.plot(centers, hy, lw=1.8, label="y")
        ax.plot(centers, hz, lw=1.8, label="z")
        if vals_proj is not None:
            ax.plot(centers, hp, lw=2.0, label="proj")
        ax.axvline(0.0, lw=1.0, color="#777777", alpha=0.8)
        ax.set_xlabel("Displacement (A)")
        ax.set_ylabel("Probability density")
        ax.set_title(f"Element-average distribution: {sym} (iter {iteration})")
        ax.grid(True, alpha=0.3)
        ax.legend(frameon=False)
        fig.tight_layout()
        fig.savefig(avg_pdf)
        plt.close(fig)


def _save_weighted_average_and_adp(output_dir: Path, iteration: int, ph, U_fit: np.ndarray, w_fit: np.ndarray, projection_axis_frac=None):
    """
    Save weighted-average structure and per-atom ADP tensor from weighted ensemble.
    """
    from phonopy.interface.vasp import write_vasp

    w = np.asarray(w_fit, dtype=float).reshape(-1)
    w /= np.sum(w)
    # Use minimum-image displacements for output statistics (ADP/averages/distributions).
    U_wrapped = _minimum_image_displacements(U_fit, np.asarray(ph.supercell.cell, dtype=float))
    U_avg = np.sum(w[:, None, None] * U_wrapped, axis=0)  # (natom, 3)

    # Primitive mapping: evaluate ADP/distributions on primitive atoms, not supercell atoms.
    prim = ph.primitive
    prim_symbols = list(prim.symbols)
    groups = _primitive_groups_from_phonopy(ph)

    # Weighted primitive mean displacement from supercell representatives.
    U_avg_prim = np.zeros((len(prim), 3), dtype=float)
    for p_idx, g in enumerate(groups):
        U_avg_prim[p_idx] = np.mean(U_avg[g], axis=0)

    primitive_average = prim.copy()
    primitive_average.positions = np.asarray(prim.positions) + U_avg_prim
    poscar_avg = output_dir / f"POSCAR_average_primitive_i{iteration:04d}"
    write_vasp(str(poscar_avg), primitive_average, direct=True)

    # Backward-compatible filename kept, now primitive-based.
    legacy_avg = output_dir / f"POSCAR_average_i{iteration:04d}"
    write_vasp(str(legacy_avg), primitive_average, direct=True)

    # Supercell weighted average (same atom count as displacement ensemble).
    supercell_average = ph.supercell.copy()
    supercell_average.positions = np.asarray(ph.supercell.positions) + U_avg
    supercell_avg = output_dir / f"POSCAR_average_supercell_i{iteration:04d}"
    write_vasp(str(supercell_avg), supercell_average, direct=True)

    # ADP tensor from weighted covariance around weighted mean (primitive basis).
    du = U_wrapped - U_avg[None, :, :]
    adp_path = output_dir / f"adp_iter_{iteration:04d}.dat"
    adp_cif_path = output_dir / f"adp_iter_{iteration:04d}.cif"
    adp_tensors = []
    du_prim_samples = []
    w_prim_samples = []
    with open(adp_path, "w") as f:
        f.write("# atom_index symbol U11 U22 U33 U23 U13 U12 Uiso Biso(=8*pi^2*Uiso)\n")
        for p_idx, g in enumerate(groups):
            x = du[:, g, :].reshape(-1, 3)  # all translationally-equivalent primitive sites
            wp = np.repeat(w / len(g), len(g))
            wp /= np.sum(wp)
            cov = np.einsum("n,ni,nj->ij", wp, x, x)  # (3,3)
            u11, u22, u33 = cov[0, 0], cov[1, 1], cov[2, 2]
            u23, u13, u12 = cov[1, 2], cov[0, 2], cov[0, 1]
            uiso = (u11 + u22 + u33) / 3.0
            biso = 8.0 * np.pi * np.pi * uiso
            f.write(
                f"{p_idx+1:6d} {prim_symbols[p_idx]:>3s} "
                f"{u11:15.8e} {u22:15.8e} {u33:15.8e} "
                f"{u23:15.8e} {u13:15.8e} {u12:15.8e} {uiso:15.8e} {biso:15.8e}\n"
            )
            adp_tensors.append(cov)
            du_prim_samples.append(x)
            w_prim_samples.append(wp)

    _write_adp_cif(adp_cif_path, primitive_average, adp_tensors)

    # Supercell ADP tensor from weighted covariance around weighted mean.
    supercell_symbols = list(ph.supercell.symbols)
    adp_super_path = output_dir / f"adp_supercell_iter_{iteration:04d}.dat"
    adp_super_cif_path = output_dir / f"adp_supercell_iter_{iteration:04d}.cif"
    adp_super_tensors = []
    with open(adp_super_path, "w") as f:
        f.write("# atom_index symbol U11 U22 U33 U23 U13 U12 Uiso Biso(=8*pi^2*Uiso)\n")
        for s_idx in range(len(ph.supercell)):
            x = du[:, s_idx, :]
            cov = np.einsum("n,ni,nj->ij", w, x, x)  # (3,3)
            u11, u22, u33 = cov[0, 0], cov[1, 1], cov[2, 2]
            u23, u13, u12 = cov[1, 2], cov[0, 2], cov[0, 1]
            uiso = (u11 + u22 + u33) / 3.0
            biso = 8.0 * np.pi * np.pi * uiso
            f.write(
                f"{s_idx+1:6d} {supercell_symbols[s_idx]:>3s} "
                f"{u11:15.8e} {u22:15.8e} {u33:15.8e} "
                f"{u23:15.8e} {u13:15.8e} {u12:15.8e} {uiso:15.8e} {biso:15.8e}\n"
            )
            adp_super_tensors.append(cov)
    _write_adp_cif(adp_super_cif_path, supercell_average, adp_super_tensors)

    _save_primitive_distributions(
        output_dir=output_dir,
        iteration=iteration,
        prim_symbols=prim_symbols,
        primitive_cell=np.asarray(prim.cell, dtype=float),
        du_prim_samples=du_prim_samples,
        w_prim_samples=w_prim_samples,
        projection_axis_frac=projection_axis_frac,
    )

    return poscar_avg, adp_path, adp_cif_path, adp_super_path, adp_super_cif_path


def _write_adp_cif(cif_path: Path, atoms, adp_tensors):
    cell = np.array(atoms.cell, dtype=float)
    a = float(np.linalg.norm(cell[0]))
    b = float(np.linalg.norm(cell[1]))
    c = float(np.linalg.norm(cell[2]))

    def _angle(v1, v2):
        x = float(np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2)))
        x = min(1.0, max(-1.0, x))
        return float(np.degrees(np.arccos(x)))

    alpha = _angle(cell[1], cell[2])
    beta = _angle(cell[0], cell[2])
    gamma = _angle(cell[0], cell[1])

    symbols = list(atoms.symbols)
    scaled_positions = np.asarray(atoms.scaled_positions, dtype=float)
    with open(cif_path, "w") as f:
        f.write("data_qscaild_adp\n")
        f.write("_symmetry_space_group_name_H-M 'P 1'\n")
        f.write("_symmetry_Int_Tables_number 1\n")
        f.write(f"_cell_length_a {a:.10f}\n")
        f.write(f"_cell_length_b {b:.10f}\n")
        f.write(f"_cell_length_c {c:.10f}\n")
        f.write(f"_cell_angle_alpha {alpha:.10f}\n")
        f.write(f"_cell_angle_beta {beta:.10f}\n")
        f.write(f"_cell_angle_gamma {gamma:.10f}\n")
        f.write("\n")
        f.write("loop_\n")
        f.write("_symmetry_equiv_pos_as_xyz\n")
        f.write("'x, y, z'\n")
        f.write("\n")
        f.write("loop_\n")
        f.write("_atom_site_label\n")
        f.write("_atom_site_type_symbol\n")
        f.write("_atom_site_fract_x\n")
        f.write("_atom_site_fract_y\n")
        f.write("_atom_site_fract_z\n")
        f.write("_atom_site_U_iso_or_equiv\n")
        for i, (sym, spos) in enumerate(zip(symbols, scaled_positions), start=1):
            uiso = (adp_tensors[i - 1][0, 0] + adp_tensors[i - 1][1, 1] + adp_tensors[i - 1][2, 2]) / 3.0
            label = f"{sym}{i}"
            f.write(
                f"{label:<6s} {sym:<3s} "
                f"{spos[0]:12.8f} {spos[1]:12.8f} {spos[2]:12.8f} {uiso:12.8f}\n"
            )
        f.write("\n")
        f.write("loop_\n")
        f.write("_atom_site_aniso_label\n")
        f.write("_atom_site_aniso_U_11\n")
        f.write("_atom_site_aniso_U_22\n")
        f.write("_atom_site_aniso_U_33\n")
        f.write("_atom_site_aniso_U_23\n")
        f.write("_atom_site_aniso_U_13\n")
        f.write("_atom_site_aniso_U_12\n")
        for i, (sym, u) in enumerate(zip(symbols, adp_tensors), start=1):
            label = f"{sym}{i}"
            f.write(
                f"{label:<6s} "
                f"{u[0,0]:12.8f} {u[1,1]:12.8f} {u[2,2]:12.8f} "
                f"{u[1,2]:12.8f} {u[0,2]:12.8f} {u[0,1]:12.8f}\n"
            )


def _plot_free_energy_convergence(log_path: Path, output_dir: Path):
    if not log_path.exists():
        return
    x = []
    y = []
    with open(log_path, "r") as f:
        for line in f:
            if line.startswith("#") or not line.strip():
                continue
            parts = line.split()
            if len(parts) < 3:
                continue
            x.append(int(parts[0]))
            y.append(float(parts[2]))
    if not x:
        return
    plt.figure(figsize=(7, 4.5))
    plt.plot(x, y, marker="o", lw=1.8)
    plt.xlabel("Cycle")
    plt.ylabel("Free energy (meV/atom)")
    plt.title("QSCAILD Free-Energy Convergence")
    plt.grid(True, alpha=0.35)
    plt.tight_layout()
    plt.savefig(output_dir / "qscaild_free_energy_history.pdf")
    plt.close()


def _promote_latest_band(output_dir: Path, input_stem: str, iteration: int):
    src_pdf = output_dir / f"band-{input_stem}_{iteration}.pdf"
    src_dat = output_dir / f"band-{input_stem}_{iteration}.dat"
    src_yaml = output_dir / f"band-{input_stem}_{iteration}.yaml"
    if src_pdf.exists():
        shutil.copyfile(src_pdf, output_dir / "band.pdf")
    if src_dat.exists():
        shutil.copyfile(src_dat, output_dir / "band.dat")
    if src_yaml.exists():
        shutil.copyfile(src_yaml, output_dir / "band.yaml")


def _run_qscaild_impl(args, input_poscar_path: Path, output_dir: Path):
    from ase import Atoms as AseAtoms
    from phonopy import Phonopy
    try:
        from phonopy.file_IO import parse_FORCE_CONSTANTS, write_FORCE_CONSTANTS, write_fc3_to_hdf5
        _HAS_WRITE_FC3 = True
    except ImportError:
        from phonopy.file_IO import parse_FORCE_CONSTANTS, write_FORCE_CONSTANTS
        write_fc3_to_hdf5 = None
        _HAS_WRITE_FC3 = False
    from phonopy.interface.vasp import read_vasp
    from scipy.constants import Boltzmann

    from macer.phonopy.band_path import generate_band_conf
    from macer.relaxation.optimizer import relax_structure

    if isinstance(args.nconf, int) and args.nconf < 1:
        raise ValueError("Error: --nconf must be >= 1.")
    if args.nsteps < 1:
        raise ValueError("Error: --nsteps must be >= 1.")
    if getattr(args, "save_every", 5) < 1:
        raise ValueError("Error: --save-every must be >= 1.")
    if not (0.0 <= args.memory <= 1.0):
        raise ValueError("Error: --memory must be in [0, 1].")
    if not (0.0 <= args.mixing <= 1.0):
        raise ValueError("Error: --mixing must be in [0, 1].")
    ess_ratio = getattr(args, "ess_collapse_ratio", None)
    if ess_ratio is not None and not (0.0 < float(ess_ratio) <= 1.0):
        raise ValueError("Error: --ess-collapse-ratio must be in (0, 1] when set.")
    max_regen_raw = getattr(args, "max_regen", None)
    if max_regen_raw is None:
        args.max_regen = 200
    else:
        args.max_regen = int(max_regen_raw)
    if args.max_regen < 0:
        raise ValueError("Error: --max-regen must be >= 0.")
    if getattr(args, "temperature", None) is None:
        raise ValueError("Error: --temperature is required.")
    user_set_use_pressure = "--use-pressure" in sys.argv
    use_pressure_mode = str(args.use_pressure)
    if (not args.optimize_volume) and (not user_set_use_pressure):
        use_pressure_mode = "False"
        args.use_pressure = "False"
    if args.optimize_volume:
        if use_pressure_mode == "False":
            use_pressure_mode = "orthorhombic"
            args.use_pressure = "orthorhombic"
        print(
            f"INFO: --optimize-volume enabled; pressure-coupled volume update is active "
            f"(mode={use_pressure_mode}, target={args.pressure_diag} kbar)."
        )
    elif use_pressure_mode != "False":
        print(
            "INFO: --use-pressure is set without --optimize-volume. "
            "Proceeding with pressure-coupled volume update for backward compatibility."
        )
    if args.reference_method != "random":
        print("WARNING: qscaild phase currently supports random ensemble generation only. Forcing --reference-method random.")
        args.reference_method = "random"
    if args.grid < 0:
        raise ValueError("Error: --grid must be >= 0.")
    if args.imaginary_freq <= -1 and args.imaginary_freq != -1:
        raise ValueError("Error: --imaginary-freq must be -1 or a positive value.")
    mass_map = _parse_mass_map(args)
    if mass_map:
        print("--- Atomic mass override ---")
        for sym, m in mass_map.items():
            print(f"  {sym:3s} : {m:8.4f} amu")
        print("----------------------------")
    if use_pressure_mode != "False":
        print(f"INFO: pressure mode enabled: {use_pressure_mode} (target={args.pressure_diag} kbar).")

    print("--- Starting phonopy QSCAILD workflow ---")
    print(f"All results will be saved in: {output_dir}")
    _write_output_guide(output_dir, args, input_poscar_path)
    if getattr(args, "dry_run", False):
        print("Dry-run enabled. Parsed settings:")
        print(
            f"  T={args.temperature}K nconf={args.nconf} nsteps={args.nsteps} "
            f"memory={args.memory} mixing={args.mixing} tol={args.tolerance}"
        )
        dim_text = " ".join(map(str, args.dim)) if getattr(args, "dim", None) else f"auto(min_length={args.min_length})"
        print(f"  dim={dim_text}")
        print(
            f"  pressure_mode={args.use_pressure} pressure_diag={args.pressure_diag} "
            f"pdiff={args.pdiff}"
        )
        print("Dry-run finished without executing force evaluations.")
        return

    model_path = _resolve_model_path(args.ff, args.model)
    if model_path and os.path.exists(model_path):
        model_path = os.path.abspath(model_path)

    calc_kwargs = {"device": args.device, "modal": args.modal}
    if args.ff == "mace":
        calc_kwargs["model_paths"] = [model_path]
    else:
        calc_kwargs["model_path"] = model_path
    calculator = get_calculator(ff_name=args.ff, **calc_kwargs)

    run_poscar = output_dir / "POSCAR_qscaild_input"
    shutil.copy(input_poscar_path, run_poscar)

    relaxed_poscar_path = run_poscar
    if args.initial_isif != 0:
        relaxed_poscar = output_dir / "CONTCAR-relax"
        relax_structure(
            input_file=str(run_poscar),
            isif=args.initial_isif,
            fmax=args.initial_fmax,
            device=args.device,
            contcar_name=str(relaxed_poscar),
            outcar_name=str(output_dir / "OUTCAR-relax"),
            xml_name=str(output_dir / "vasprun-relax.xml"),
            ff=args.ff,
            model_path=model_path,
            modal=args.modal,
            quiet=True,
            symprec=args.symprec,
            use_symmetry=getattr(args, "initial_use_symmetry", True),
        )
        unitcell = read_vasp(str(relaxed_poscar))
        relaxed_poscar_path = relaxed_poscar
    else:
        unitcell = read_vasp(str(run_poscar))
        relaxed_poscar_path = run_poscar
    unitcell = _apply_mass_override_to_phonopy_atoms(unitcell, mass_map)

    if args.dim:
        if len(args.dim) == 3:
            supercell_matrix = np.diag(args.dim)
        elif len(args.dim) == 9:
            supercell_matrix = np.array(args.dim).reshape(3, 3)
        else:
            raise ValueError("Error: --dim must be 3 or 9 integers.")
    else:
        vector_lengths = [np.linalg.norm(v) for v in unitcell.cell]
        scaling_factors = [int(np.ceil(args.min_length / v)) if v > 0 else 1 for v in vector_lengths]
        supercell_matrix = np.diag(scaling_factors)

    ph = Phonopy(unitcell, supercell_matrix=supercell_matrix, primitive_matrix="auto", symprec=args.symprec)
    base_supercell = ph.supercell
    band_conf_path = output_dir / "band.conf" if getattr(args, "plot_bands", True) else None
    if band_conf_path:
        try:
            dim_override = " ".join(map(str, supercell_matrix.flatten().astype(int)))
            generate_band_conf(
                poscar_path=relaxed_poscar_path,
                out_path=band_conf_path,
                symprec=args.symprec,
                gamma_label=args.gamma_label,
                print_summary_flag=False,
                dim_override=dim_override,
            )
        except Exception as e:
            print(f"WARNING: failed to generate band.conf ({e}); disabling iterative band exports.")
            band_conf_path = None

    if args.read_initial_fc:
        fc_current = parse_FORCE_CONSTANTS(filename=args.read_initial_fc)
    else:
        ph.generate_displacements(distance=args.amplitude, is_plusminus=True, is_diagonal=not args.nodiag)
        from macer.calculator.factory import evaluate_batch, evaluate_sequential
        disp_cells = ph.supercells_with_displacements
        atoms_list_fc2 = []
        for scell in disp_cells:
            atoms_list_fc2.append(AseAtoms(
                symbols=scell.symbols,
                cell=scell.cell,
                scaled_positions=scell.scaled_positions,
                pbc=True,
            ))
        use_sequential = bool(getattr(args, "sequential", False))
        batch_size = getattr(args, "batch_size", None)
        if not use_sequential:
            try:
                fc2_res = evaluate_batch(
                    calculator,
                    atoms_list_fc2,
                    batch_size=batch_size,
                    properties=["forces"],
                )
                forces = fc2_res["forces"]
            except Exception as e:
                print(f"  [Warning] Initial FC2 batch calculation failed:\n  {e}\n  Falling back to sequential evaluation...")
                seq_res = evaluate_sequential(
                    calculator,
                    atoms_list_fc2,
                    properties=["forces"],
                )
                forces = seq_res["forces"]
        else:
            print(f"  Evaluating {len(atoms_list_fc2)} structures sequentially for initial FC2...")
            seq_res = evaluate_sequential(
                calculator,
                atoms_list_fc2,
                properties=["forces"],
            )
            forces = seq_res["forces"]
        ph.forces = list(forces)
        ph.produce_force_constants()
        fc_current = ph.force_constants.copy()

    write_FORCE_CONSTANTS(fc_current, filename=str(output_dir / "FORCE_CONSTANTS_init"))
    write_FORCE_CONSTANTS(fc_current, filename=str(output_dir / "FORCE_CONSTANTS_CURRENT"))
    if band_conf_path is not None:
        try:
            old_cwd = Path.cwd()
            os.chdir(output_dir)
            try:
                ph.force_constants = fc_current
                _plot_iterative_band_structure(ph, band_conf_path, "harmonic", input_poscar_path.stem)
            finally:
                os.chdir(old_cwd)
        except Exception as e:
            print(f"WARNING: failed to export harmonic band outputs: {e}")
    if args.temperature <= 0:
        beta = 1.0e12
    else:
        beta = 1.0 / (Boltzmann / 1.602176634e-19 * args.temperature)

    out_fit_paths = [output_dir / "out_fit.txt"]
    out_conv_paths = [output_dir / "out_convergence.txt"]
    out_energy_paths = [output_dir / "out_energy.txt"]
    out_volume_paths = [output_dir / "out_volume.txt"]
    fe_hist_path = output_dir / "qscaild_free_energy_history.log"
    for p in out_fit_paths + out_conv_paths + out_energy_paths + out_volume_paths:
        p.write_text("")
    _append_text(
        out_fit_paths,
        "# QSCAILD fit history\n"
        "# columns: iteration n_cycles n_snapshots fc_diff_max ess entropy free_energy_eV free_energy_meV_per_atom\n",
    )
    _append_text(
        out_conv_paths,
        "# QSCAILD convergence history\n"
        "# columns: iteration fc_diff_max ess entropy pressure_err_kbar(optional)\n",
    )
    _append_text(
        out_energy_paths,
        "# QSCAILD energy/reweight history\n"
        "# per iteration: cycle_id mean_energy_eV mean_raw_weight\n",
    )
    _append_text(
        out_volume_paths,
        "# QSCAILD pressure/volume history\n"
        "# columns: iteration Pxx_kbar Pyy_kbar Pzz_kbar pressure_err_kbar\n",
    )
    with open(fe_hist_path, "w") as f:
        f.write("# cycle  free_energy_eV  free_energy_meV_per_atom\n")

    converged = False
    final_reason = "max_cycles"
    pressure_converged = (use_pressure_mode == "False")
    pressure_err = np.nan
    pressure_kbar = np.array([np.nan, np.nan, np.nan])
    w_fit = np.array([1.0], dtype=float)
    fc3_current = None
    last_free_energy = np.nan
    regen_count = 0
    for iteration in range(1, args.nsteps + 1):
        cycle_dir = output_dir / f"cycle_{iteration:03d}"
        cycle_dir.mkdir(parents=True, exist_ok=True)

        try:
            U_cycle = _generate_cycle_ensemble_staged(
                ph,
                fc_current,
                args.temperature,
                args.nconf,
                use_smalldisp=args.use_smalldisp,
                imaginary_freq=args.imaginary_freq,
                grid=args.grid,
            )
        except Exception as e:
            print(f"WARNING: covariance-based sampling failed ({e}); falling back to phonopy RandomDisplacements.")
            U_cycle = _generate_cycle_ensemble(ph, fc_current, args.temperature, args.nconf)
        F_cycle, E_cycle, Stress_cycle = _evaluate_ensemble(
            U_cycle,
            base_supercell,
            calculator,
            need_stress=(use_pressure_mode != "False"),
            progress_desc=f"Cycle {iteration:03d} force/stress evaluations",
            sequential=bool(getattr(args, "sequential", False)),
            batch_size=getattr(args, "batch_size", None),
        )
        
        # High-speed reweighting: Pre-calculate engine for fc_current
        rw_engine = _prepare_reweighting_engine(fc_current, ph, args.temperature)
        logp_origin = _compute_harmonic_logpdf_with_engine(U_cycle, rw_engine)
        
        _save_cycle_data(
            cycle_dir,
            U_cycle,
            F_cycle,
            E_cycle,
            fc_current,
            logp_origin,
            save_npy=getattr(args, "save_npy", False),
        )
        if Stress_cycle is not None:
            _save_array_with_dat(cycle_dir / "Stress", Stress_cycle, save_npy=getattr(args, "save_npy", False))

        cycle_ids, cycle_dirs = _load_history_for_fit(output_dir, iteration, args.memory)
        U_fit, F_fit, E_fit, w_fit, Stress_all, energy_lines, weight_issue = _assemble_fit_data(
            cycle_ids=cycle_ids,
            cycle_dirs=cycle_dirs,
            fc_current=fc_current,
            beta=beta,
            iteration=iteration,
            use_pressure_mode=use_pressure_mode,
            save_npy=getattr(args, "save_npy", False),
            ph=ph,
            temperature=args.temperature,
            engine=rw_engine,
        )
        ess, entropy = _weight_stats(w_fit)

        ess_ratio = getattr(args, "ess_collapse_ratio", None)
        if ess_ratio is not None:
            ess_threshold = float(ess_ratio) * len(w_fit)
            if ess < ess_threshold:
                max_regen = int(getattr(args, "max_regen", 200))
                print(
                    f"WARNING: ESS collapse detected at cycle {iteration:03d} "
                    f"(ESS={ess:.2f} < threshold={ess_threshold:.2f})."
                )
                if regen_count >= max_regen:
                    raise RuntimeError(
                        f"ESS collapse persists and max regeneration count reached "
                        f"({regen_count}/{max_regen})."
                    )
                regen_count += 1
                mode = str(getattr(args, "ess_collapse_mode", "soft")).lower()
                if mode == "hard":
                    keep_ids = [iteration]
                    keep_dirs = [cycle_dir]
                    print(
                        f"INFO: ESS regeneration #{regen_count} (hard): "
                        "dropping history and using latest cycle only."
                    )
                else:
                    keep_n = max(2, int(np.ceil(len(cycle_ids) * 0.5)))
                    keep_n = min(keep_n, len(cycle_ids))
                    keep_ids = cycle_ids[-keep_n:]
                    keep_dirs = cycle_dirs[-keep_n:]
                    print(
                        f"INFO: ESS regeneration #{regen_count} (soft): "
                        f"keeping recent history cycles={keep_ids}."
                    )

                U_fit, F_fit, E_fit, w_fit, Stress_all, energy_lines, weight_issue = _assemble_fit_data(
                    cycle_ids=keep_ids,
                    cycle_dirs=keep_dirs,
                    fc_current=fc_current,
                    beta=beta,
                    iteration=iteration,
                    use_pressure_mode=use_pressure_mode,
                    save_npy=getattr(args, "save_npy", False),
                    ph=ph,
                    temperature=args.temperature,
                    engine=rw_engine,
                )
                cycle_ids = keep_ids
                ess, entropy = _weight_stats(w_fit)
                energy_lines.append(
                    f"# ess_regeneration mode={mode} threshold={ess_threshold:.2f}\n"
                )

        save_every = int(getattr(args, "save_every", 5))
        should_save_intermediate = (iteration % save_every == 0)
        if should_save_intermediate:
            _save_weights_qscaild(output_dir / f"weights_iter_{iteration:04d}", w_fit, save_npy=getattr(args, "save_npy", False))

        if args.include_third_order:
            print(f"Cycle {iteration:03d}: FC fit stage started (FC2+FC3).")
        else:
            print(f"Cycle {iteration:03d}: FC fit stage started (FC2 only).")
        t_fit_start = time.perf_counter()
        fc_fit, fc3_fit = fit_weighted_fc(
            U_fit, F_fit, w_fit, ph, include_third_order=args.include_third_order
        )
        t_fit_elapsed = time.perf_counter() - t_fit_start
        if args.include_third_order:
            if fc3_fit is None:
                print(f"Cycle {iteration:03d}: FC fit stage finished in {t_fit_elapsed:.2f} s (FC3 unavailable/fallback).")
            else:
                print(f"Cycle {iteration:03d}: FC fit stage finished in {t_fit_elapsed:.2f} s (FC3 fitted).")
        else:
            print(f"Cycle {iteration:03d}: FC fit stage finished in {t_fit_elapsed:.2f} s.")
        fc_next = (1.0 - args.mixing) * fc_fit + args.mixing * fc_current
        if fc3_fit is not None:
            if fc3_current is None:
                fc3_next = fc3_fit.copy()
            else:
                fc3_next = (1.0 - args.mixing) * fc3_fit + args.mixing * fc3_current
        else:
            fc3_next = fc3_current
        fc_diff_max = float(np.max(np.abs(fc_next - fc_current)))
        try:
            free_energy = compute_weighted_free_energy(
                U_fit, E_fit, fc_next, fc3_next, w_fit, ph, args.temperature, args.mesh, return_components=False
            )
            n_atom_primitive = len(ph.primitive)
            f_mev_atom = (free_energy * 1000.0) / n_atom_primitive
            with open(fe_hist_path, "a") as f:
                f.write(f"{iteration:6d}  {free_energy:16.8f}  {f_mev_atom:16.8f}\n")
            last_free_energy = free_energy
        except Exception:
            free_energy = np.nan
            f_mev_atom = np.nan

        if use_pressure_mode != "False" and Stress_all:
            stress_fit = np.concatenate(Stress_all, axis=0)
            stress_weighted = np.sum(stress_fit * w_fit[:, None], axis=0)
            unitcell, pressure_kbar, pressure_err = _update_cell_from_pressure(
                unitcell,
                use_pressure_mode,
                args.pressure_diag,
                args.pdiff,
                stress_weighted,
            )
            unitcell = _apply_mass_override_to_phonopy_atoms(unitcell, mass_map)
            pressure_converged = pressure_err < args.pdiff

            # Rebuild phonopy object for updated cell state.
            ph = Phonopy(unitcell, supercell_matrix=supercell_matrix, primitive_matrix="auto", symprec=args.symprec)
            ph.force_constants = fc_next
            base_supercell = ph.supercell
        elif use_pressure_mode != "False":
            pressure_converged = False

        if should_save_intermediate:
            write_FORCE_CONSTANTS(fc_fit, filename=str(output_dir / f"FORCE_CONSTANTS_FIT_{iteration}"))
            if fc3_fit is not None:
                if _HAS_WRITE_FC3 and write_fc3_to_hdf5 is not None:
                    write_fc3_to_hdf5(fc3_fit, filename=str(output_dir / f"FC3_FIT_{iteration}.hdf5"))
                else:
                    print("WARNING: write_fc3_to_hdf5 not available in this phonopy build; skipping FC3 save.")
            try:
                (
                    poscar_avg_path,
                    adp_path,
                    adp_cif_path,
                    adp_super_path,
                    adp_super_cif_path,
                ) = _save_weighted_average_and_adp(
                    output_dir=output_dir,
                    iteration=iteration,
                    ph=ph,
                    U_fit=U_fit,
                    w_fit=w_fit,
                    projection_axis_frac=getattr(args, "distribution_axis", None),
                )
                print(f"  Saved weighted average structure: {poscar_avg_path.name}")
                print(f"  Saved weighted ADP table: {adp_path.name}")
                print(f"  Saved weighted ADP CIF: {adp_cif_path.name}")
                print(f"  Saved supercell ADP table: {adp_super_path.name}")
                print(f"  Saved supercell ADP CIF: {adp_super_cif_path.name}")
                print(
                    "  Saved element-average distributions: "
                    f"distribution_proj_iter_{iteration:04d}_element_*_avg.pdf/.dat"
                )
            except Exception as e:
                print(f"WARNING: failed to save weighted average/ADP at cycle {iteration}: {e}")

            if band_conf_path is not None:
                try:
                    ph.force_constants = fc_next
                    old_cwd = Path.cwd()
                    os.chdir(output_dir)
                    try:
                        _plot_iterative_band_structure(ph, band_conf_path, iteration, input_poscar_path.stem)
                        _promote_latest_band(output_dir, input_poscar_path.stem, iteration)
                    finally:
                        os.chdir(old_cwd)
                except Exception as e:
                    print(f"WARNING: failed to export band outputs at cycle {iteration}: {e}")
        write_FORCE_CONSTANTS(fc_current, filename=str(output_dir / "FORCE_CONSTANTS_PREVIOUS"))
        write_FORCE_CONSTANTS(fc_next, filename=str(output_dir / "FORCE_CONSTANTS_CURRENT"))
        (output_dir / "iteration").write_text(f"{iteration}\n")

        fit_line = (
            f"{iteration:8d} {len(cycle_ids):8d} {len(U_fit):12d} "
            f"{fc_diff_max:16.8e} {ess:10.6f} {entropy:10.6f} "
            f"{free_energy:16.8f} {f_mev_atom:18.8f}\n"
        )
        fit_line += f"# fit_elapsed_s {t_fit_elapsed:.6f}\n"
        _append_text(out_fit_paths, fit_line)
        _append_text(out_energy_paths, "".join(energy_lines))
        conv_line = (
            f"{iteration:8d} {fc_diff_max:16.8e} {ess:10.6f} {entropy:10.6f}"
        )
        if use_pressure_mode != "False":
            conv_line += f" {pressure_err:16.6f}"
        _append_text(out_conv_paths, conv_line + "\n")
        if use_pressure_mode != "False":
            _append_text(
                out_volume_paths,
                f"{iteration:8d} {pressure_kbar[0]:12.6f} {pressure_kbar[1]:12.6f} "
                f"{pressure_kbar[2]:12.6f} {pressure_err:16.6f}\n",
            )

        nconf_status = f"{args.nconf}(auto)" if is_auto_nconf else f"{args.nconf}(manual)"
        ess_ratio = ess / float(len(U_fit))
        
        # Hybrid Auto-nconf: Dynamic Scaling check (if logic exists in this script)
        scaling_msg = ""
        is_auto_nconf = (str(args.nconf).lower() == "auto")
        if is_auto_nconf:
            if ess_ratio < 0.3:
                old_nconf = args.nconf
                args.nconf = min(500, int(np.ceil(args.nconf * 1.3)))
                if args.nconf > old_nconf:
                    scaling_msg = f"  INFO: Low ESS detected ({ess_ratio:.2f} < 0.30). Scaling up nconf: {old_nconf} -> {args.nconf}"

        # 1. Main Cycle Header
        nconf_status = f"{args.nconf}(auto)" if is_auto_nconf else f"{args.nconf}(manual)"
        print(
            f"Cycle {iteration:03d}: nconf={nconf_status}, "
            f"history={cycle_ids}, snapshots={len(U_fit)}, "
            f"fc_diff_max={fc_diff_max:.6e}, ESS={ess:.2f} (ratio={ess_ratio:.2f}, threshold=0.30)"
        )
        
        # 2. Status Lines (Indented)
        if scaling_msg:
            print(scaling_msg)

        fc_ratio = fc_diff_max / float(args.tolerance) if args.tolerance > 0 else np.inf
        print(
            "  FC convergence: "
            f"current={fc_diff_max:.6e}, target<{args.tolerance:.6e}, "
            f"ratio={fc_ratio:.2f}x"
        )
        if np.isfinite(f_mev_atom):
            print(f"  Free energy: {f_mev_atom:.6f} meV/atom")
        if should_save_intermediate:
            print(
                f"  Saved intermediate outputs at cycle {iteration} "
                f"(save-every={save_every})."
            )
            print(f"  Saved ensemble snapshot bundle: cycle_{iteration:03d}/")
        if use_pressure_mode != "False":
            p_ratio = pressure_err / float(args.pdiff) if args.pdiff > 0 else np.inf
            print(
                "  Pressure[kbar]="
                f"{pressure_kbar[0]:+.3f},{pressure_kbar[1]:+.3f},{pressure_kbar[2]:+.3f} "
                f"(err={pressure_err:.3f})"
            )
            print(
                "  Pressure convergence: "
                f"current_err={pressure_err:.6f}, target<{args.pdiff:.6f}, "
                f"ratio={p_ratio:.2f}x"
            )

        fc_current = fc_next
        fc3_current = fc3_next
        ph.force_constants = fc_current

        fc_converged = fc_diff_max < args.tolerance
        if use_pressure_mode == "False":
            converged = fc_converged
        else:
            converged = fc_converged and pressure_converged
        if converged:
            if use_pressure_mode == "False":
                final_reason = "fc_tolerance"
            else:
                final_reason = "fc_and_pressure_tolerance"
            converged = True
            break

    _save_weights_qscaild(output_dir / "weights_final", w_fit, save_npy=getattr(args, "save_npy", False))
    try:
        _, adp_path, adp_cif_path, adp_super_path, adp_super_cif_path = _save_weighted_average_and_adp(
            output_dir=output_dir,
            iteration=iteration,
            ph=ph,
            U_fit=U_fit,
            w_fit=w_fit,
            projection_axis_frac=getattr(args, "distribution_axis", None),
        )
        shutil.copyfile(adp_path, output_dir / "adp_final.dat")
        shutil.copyfile(adp_cif_path, output_dir / "adp_final.cif")
        shutil.copyfile(adp_super_path, output_dir / "adp_supercell_final.dat")
        shutil.copyfile(adp_super_cif_path, output_dir / "adp_supercell_final.cif")
        poscar_prim_iter = output_dir / f"POSCAR_average_primitive_i{iteration:04d}"
        poscar_iter = output_dir / f"POSCAR_average_i{iteration:04d}"
        poscar_super_iter = output_dir / f"POSCAR_average_supercell_i{iteration:04d}"
        if poscar_prim_iter.exists():
            shutil.copyfile(poscar_prim_iter, output_dir / "POSCAR_average_primitive_final")
        if poscar_iter.exists():
            shutil.copyfile(poscar_iter, output_dir / "POSCAR_average_final")
        if poscar_super_iter.exists():
            shutil.copyfile(poscar_super_iter, output_dir / "POSCAR_average_supercell_final")

        dist_prefix = f"distribution_proj_iter_{iteration:04d}_"
        for src in output_dir.glob(f"{dist_prefix}element_*_avg.*"):
            dst_name = src.name.replace(dist_prefix, "distribution_proj_final_")
            shutil.copyfile(src, output_dir / dst_name)
        print(
            "Saved final aliases: "
            "adp_final.dat/.cif, adp_supercell_final.dat/.cif, "
            "POSCAR_average_primitive_final, POSCAR_average_final, "
            "POSCAR_average_supercell_final, "
            "distribution_proj_final_element_*_avg.dat/.pdf"
        )
    except Exception as e:
        print(f"WARNING: failed to export final alias outputs: {e}")
    write_FORCE_CONSTANTS(fc_current, filename=str(output_dir / "FORCE_CONSTANTS_QSCAILD_final"))
    if fc3_current is not None:
        if _HAS_WRITE_FC3 and write_fc3_to_hdf5 is not None:
            write_fc3_to_hdf5(fc3_current, filename=str(output_dir / "FC3_QSCAILD_final.hdf5"))
        else:
            print("WARNING: write_fc3_to_hdf5 not available in this phonopy build; skipping final FC3 save.")
    if band_conf_path is not None:
        try:
            ph.force_constants = fc_current
            old_cwd = Path.cwd()
            os.chdir(output_dir)
            try:
                _plot_iterative_band_structure(ph, band_conf_path, "final", input_poscar_path.stem)
            finally:
                os.chdir(old_cwd)
            for ext in ("pdf", "dat", "yaml"):
                src = output_dir / f"band-{input_poscar_path.stem}_final.{ext}"
                if src.exists():
                    shutil.copyfile(src, output_dir / f"band.{ext}")
        except Exception as e:
            print(f"WARNING: failed to export final band outputs: {e}")
    _plot_free_energy_convergence(fe_hist_path, output_dir)
    if np.isfinite(last_free_energy):
        print(f"Final free energy (eV): {last_free_energy:.8f}")
    if converged:
        print(
            "QSCAILD converged "
            f"(reason={final_reason}) at cycle {iteration} "
            f"with fc_tol={args.tolerance}."
        )
    else:
        print(
            f"QSCAILD reached max cycles ({args.nsteps}) without convergence "
            f"(last reason={final_reason})."
        )
    _write_output_guide(output_dir, args, input_poscar_path)
    print("--- QSCAILD workflow finished ---")


def run_qscaild_workflow(args):
    if args.seed is not None:
        random.seed(args.seed)
        np.random.seed(args.seed)

    input_path = None
    output_dir = None
    try:
        # Resolve input first to derive deterministic default output prefix.
        tmp_output = Path.cwd()
        input_path = _prepare_input_poscar(args, tmp_output, convert_cif=False)
        output_dir = _build_output_dir(args, input_path, create=(not getattr(args, "dry_run", False)))

        if getattr(args, "dry_run", False):
            # For dry-run, resolve CIF conversion if needed but do not create output dir.
            input_path = _prepare_input_poscar(args, Path.cwd(), convert_cif=True)
            args.output_dir = str(output_dir)
            print("--- Macer QSCAILD Workflow ---")
            print(f"Command: {' '.join(sys.argv)}")
            _run_qscaild_legacy_backend(args, input_path, output_dir)
            return

        # Ensure converted inputs are inside final output dir for real runs.
        input_path = _prepare_input_poscar(args, output_dir, convert_cif=True)
        args.output_dir = str(output_dir)
        log_file = output_dir / "macer_qscaild.log"
        orig_stdout = sys.stdout
        with Logger(str(log_file)) as lg:
            try:
                sys.stdout = lg
                print("--- Macer QSCAILD Workflow ---")
                print(f"Command: {' '.join(sys.argv)}")
                _run_qscaild_legacy_backend(args, input_path, output_dir)
            finally:
                try:
                    if output_dir is not None and input_path is not None:
                        _write_output_guide(output_dir, args, input_path)
                except Exception:
                    pass
                sys.stdout = orig_stdout
    except Exception as exc:
        print(f"QSCAILD run failed: {exc}")
        traceback.print_exc()
        raise


LEGACY_SUBDIR = "run-qscaild"

QSCAILD_REQUIRED_FILES = [
    "actions.py",
    "generate_conf.py",
    "gradient.py",
    "gruneisen.py",
    "submit_qscaild.py",
    "symmetry.py",
    "thermal_disp.py",
    "thirdorder_common.py",
    "thirdorder_save.py",
]

MPI4PY_STUB = '''"""Minimal serial mpi4py stub for local demo runs."""

class _Comm:
    rank = 0
    size = 1

    def Get_rank(self):
        return 0

    def Get_size(self):
        return 1

    def Barrier(self):
        return None

    def bcast(self, value, root=0):
        return value

    def Reduce(self, sendbuf, recvbuf, op=None, root=0):
        try:
            recvbuf[...] = sendbuf
        except Exception:
            pass
        return None

    def Abort(self, code=1):
        raise SystemExit(code)


class _MPI:
    COMM_WORLD = _Comm()
    SUM = object()


MPI = _MPI()
'''

THIRDORDER_CORE_STUB = '''"""Compatibility stub for Python 3 runs without 3rd-order fitting."""

class _NotAvailable:
    def __init__(self, *args, **kwargs):
        raise NotImplementedError(
            "thirdorder_core extension is unavailable in this environment; set third=False"
        )


SymmetryOperations = _NotAvailable
Wedge = _NotAvailable


def reconstruct_ifcs(*args, **kwargs):
    raise NotImplementedError(
        "thirdorder_core extension is unavailable in this environment; set third=False"
    )


def reconstruct_ifcs_philist(*args, **kwargs):
    raise NotImplementedError(
        "thirdorder_core extension is unavailable in this environment; set third=False"
    )
'''


def _external_qscaild_dir(args) -> Path:
    repo = Path(__file__).resolve().parents[2]
    cli_path = getattr(args, "qscaild_dir", None)
    default_target = repo / "externals" / "qscaild-master"
    candidates = []
    if cli_path:
        candidates.append(Path(str(cli_path)).expanduser().resolve())
    candidates.extend(
        [
            default_target,
            repo / "macer" / "externals" / "qscaild-master",
            repo / "qscaild-master",
        ]
    )
    for cand in candidates:
        if cand.is_dir() and (cand / "submit_qscaild.py").exists():
            _maybe_fetch_qscaild(cand, bool(getattr(args, "qscaild_fetch", False)))
            return cand

    auto_install = bool(getattr(args, "auto_install_qscaild", True))
    if auto_install and cli_path is None:
        _try_clone_qscaild(default_target)
        if default_target.is_dir() and (default_target / "submit_qscaild.py").exists():
            _maybe_fetch_qscaild(default_target, bool(getattr(args, "qscaild_fetch", False)))
            return default_target

    expected = default_target
    raise FileNotFoundError(
        "QSCAILD source not found or install failed.\n"
        "Install guide:\n"
        "  1) Clone: git clone https://github.com/vanroeke/qscaild.git externals/qscaild-master\n"
        f"  2) Place it at: {expected}\n"
        "  3) Ensure files exist: submit_qscaild.py, gradient.py, symmetry.py, thermal_disp.py\n"
        "  4) Re-run `macer phonopy qscaild ...`\n"
        "Optional:\n"
        "  - pass explicit path: --qscaild-dir /path/to/qscaild-master\n"
        "  - enable auto fetch/update: --qscaild-fetch"
    )


def _try_clone_qscaild(target_dir: Path) -> None:
    if target_dir.exists():
        return
    target_dir.parent.mkdir(parents=True, exist_ok=True)
    print(f"QSCAILD source not found. Trying auto-install into: {target_dir}")
    try:
        proc = subprocess.run(
            ["git", "clone", "https://github.com/vanroeke/qscaild.git", str(target_dir)],
            check=True,
            capture_output=True,
            text=True,
        )
        if proc.stdout.strip():
            print(proc.stdout.strip())
        print("QSCAILD auto-install: clone completed.")
    except Exception as e:
        print(f"QSCAILD auto-install failed: {e}")


def _maybe_fetch_qscaild(source_dir: Path, do_fetch: bool) -> None:
    if not do_fetch:
        return
    git_dir = source_dir / ".git"
    if not git_dir.exists():
        print(f"QSCAILD fetch skipped (not a git checkout): {source_dir}")
        return
    print(f"QSCAILD fetch: updating source at {source_dir}")
    try:
        subprocess.run(
            ["git", "-C", str(source_dir), "pull", "--ff-only"],
            check=True,
            capture_output=True,
            text=True,
        )
        print("QSCAILD fetch: update completed.")
    except Exception as e:
        print(f"QSCAILD fetch skipped due to error: {e}")


def _patch_qscaild_engine_files(engine_dir: Path) -> None:
    # submit_qscaild.py: patch phonopy API compatibility at import time.
    submit_py = engine_dir / "submit_qscaild.py"
    src = submit_py.read_text()
    if "_patch_phonopy_compat" not in src:
        marker = "rank = comm.Get_rank()\n\n"
        compat_block = '''rank = comm.Get_rank()


def _patch_phonopy_compat():
    """Patch old QSCAILD expectations to current phonopy API."""
    try:
        from phonopy.api_phonopy import Phonopy
    except Exception:
        return

    if not hasattr(Phonopy, "set_force_constants"):
        def _set_force_constants(self, fc):
            self.force_constants = fc
        Phonopy.set_force_constants = _set_force_constants

    if not hasattr(Phonopy, "get_supercell"):
        def _get_supercell(self):
            return self.supercell
        Phonopy.get_supercell = _get_supercell

    if not hasattr(Phonopy, "get_primitive"):
        def _get_primitive(self):
            return self.primitive
        Phonopy.get_primitive = _get_primitive

    if not hasattr(Phonopy, "get_primitive_symmetry"):
        def _get_primitive_symmetry(self):
            return self.primitive_symmetry
        Phonopy.get_primitive_symmetry = _get_primitive_symmetry

    try:
        from phonopy.structure.atoms import PhonopyAtoms
    except Exception:
        return

    if not hasattr(PhonopyAtoms, "get_masses"):
        def _get_masses(self):
            return np.array(self.masses, dtype=float)
        PhonopyAtoms.get_masses = _get_masses

    if not hasattr(PhonopyAtoms, "get_number_of_atoms"):
        def _get_number_of_atoms(self):
            return len(self)
        PhonopyAtoms.get_number_of_atoms = _get_number_of_atoms


_patch_phonopy_compat()

'''
        src = src.replace(marker, compat_block, 1)
        submit_py.write_text(src)

    # gradient.py: robust FORCE_CONSTANTS header + remove deprecated getchildren.
    gradient_py = engine_dir / "gradient.py"
    src = gradient_py.read_text()
    src = src.replace(
        '        n = int(next(f).strip())\n',
        '''        header = next(f).split()
        if len(header) == 0:
            raise ValueError(f"empty FORCE_CONSTANTS header in {fcs_file}")
        if len(header) == 1:
            n = int(header[0])
        else:
            n = int(header[0])
            n2 = int(header[1])
            if n2 != n:
                raise ValueError(
                    f"invalid FORCE_CONSTANTS header in {fcs_file}: {' '.join(header)}"
                )
''',
    )
    src = src.replace("for i in a.getchildren():", "for i in list(a):")
    src = src.replace(
        "for i in a.getchildren()[0].getchildren()[-1].getchildren(\n        )[0].getchildren()[0].getchildren():",
        """lvl1 = list(a)
        if not lvl1:
            continue
        lvl2 = list(lvl1[0])
        if not lvl2:
            continue
        lvl3 = list(lvl2[-1])
        if not lvl3:
            continue
        lvl4 = list(lvl3[0])
        if not lvl4:
            continue
        lvl5 = list(lvl4[0])
        for i in lvl5:""",
    )
    gradient_py.write_text(src)

    # symmetry.py: compatibility for modern phonopy/spglib dataset access.
    symmetry_py = engine_dir / "symmetry.py"
    src = symmetry_py.read_text()
    src = src.replace("logging.basicConfig(level=0)", "logging.basicConfig(level=logging.INFO)")
    src = src.replace("natoms = structure.get_number_of_atoms()", "natoms = len(structure)")
    src = src.replace(
        'dataset = symmetry.get_dataset()\n    print("Space group {0} ({1}) detected".format(dataset["international"],\n                                                  dataset["number"]))',
        'dataset = symmetry.dataset if hasattr(symmetry, "dataset") else symmetry.get_dataset()\n'
        '    international = getattr(dataset, "international", dataset["international"])\n'
        '    number = getattr(dataset, "number", dataset["number"])\n'
        '    print("Space group {0} ({1}) detected".format(international, number))',
    )
    src = src.replace("operations = symmetry.get_symmetry_operations()", 'operations = symmetry.symmetry_operations if hasattr(symmetry, "symmetry_operations") else symmetry.get_symmetry_operations()')
    src = src.replace('print("permutations: " + str(permutations))', 'print("permutations count: " + str(len(permutations)))')
    src = src.replace("positions = structure.get_scaled_positions()", "positions = np.array(structure.scaled_positions)")
    symmetry_py.write_text(src)

    # thermal_disp.py: VaspToTHz and phonopy API compatibility.
    thermal_py = engine_dir / "thermal_disp.py"
    src = thermal_py.read_text()
    src = src.replace(
        "import generate_conf\nfrom mpi4py import MPI\n\n",
        """import generate_conf
from mpi4py import MPI

try:
    _VASP_TO_THZ = phonopy.units.VaspToTHz
except Exception:
    from phonopy.physical_units import get_physical_units
    _VASP_TO_THZ = get_physical_units().DefaultToTHz


def _set_force_constants_compat(phonon, fc):
    if hasattr(phonon, "set_force_constants"):
        phonon.set_force_constants(fc)
    else:
        phonon.force_constants = fc


def _get_supercell_compat(phonon):
    if hasattr(phonon, "get_supercell"):
        return phonon.get_supercell()
    return phonon.supercell


def _get_primitive_compat(phonon):
    if hasattr(phonon, "get_primitive"):
        return phonon.get_primitive()
    return phonon.primitive


def _get_primitive_symmetry_compat(phonon):
    if hasattr(phonon, "get_primitive_symmetry"):
        return phonon.get_primitive_symmetry()
    return phonon.primitive_symmetry


def _get_masses_compat(atoms_like):
    if hasattr(atoms_like, "get_masses"):
        return atoms_like.get_masses()
    return np.array(atoms_like.masses, dtype=float)

""",
    )
    src = src.replace("factor=phonopy.units.VaspToTHz", "factor=_VASP_TO_THZ")
    src = src.replace(
        "open(\"BORN\"), phonon.get_primitive(),\n            phonon.get_primitive_symmetry()",
        "open(\"BORN\"), _get_primitive_compat(phonon),\n            _get_primitive_symmetry_compat(phonon)",
    )
    src = src.replace("phonon.set_force_constants(fc)", "_set_force_constants_compat(phonon, fc)")
    # Avoid self-recursion if the replacement touches this compatibility helper.
    src = src.replace(
        'if hasattr(phonon, "set_force_constants"):\n        _set_force_constants_compat(phonon, fc)',
        'if hasattr(phonon, "set_force_constants"):\n        phonon.set_force_constants(fc)',
    )
    src = src.replace(
        "masses = phonon.get_supercell().get_masses(\n    ) * codata.physical_constants[\"atomic mass constant\"][0]",
        "masses = _get_masses_compat(_get_supercell_compat(phonon)) * codata.physical_constants[\"atomic mass constant\"][0]",
    )
    src = src.replace(
        "natoms = phonon.get_primitive().get_number_of_atoms()",
        """primitive = _get_primitive_compat(phonon)
    if hasattr(primitive, "get_number_of_atoms"):
        natoms = primitive.get_number_of_atoms()
    else:
        natoms = len(primitive)""",
    )
    thermal_py.write_text(src)

    # gruneisen.py: VaspToTHz and phonopy API compatibility.
    grun_py = engine_dir / "gruneisen.py"
    src = grun_py.read_text()
    src = src.replace(
        "comm = MPI.COMM_WORLD\nrank = comm.Get_rank()\n\n",
        """comm = MPI.COMM_WORLD
rank = comm.Get_rank()

try:
    _VASP_TO_THZ = phonopy.units.VaspToTHz
except Exception:
    from phonopy.physical_units import get_physical_units
    _VASP_TO_THZ = get_physical_units().DefaultToTHz


def _set_force_constants_compat(phonon, fc):
    if hasattr(phonon, "set_force_constants"):
        phonon.set_force_constants(fc)
    else:
        phonon.force_constants = fc


def _get_primitive_compat(phonon):
    if hasattr(phonon, "get_primitive"):
        return phonon.get_primitive()
    return phonon.primitive


def _get_primitive_symmetry_compat(phonon):
    if hasattr(phonon, "get_primitive_symmetry"):
        return phonon.get_primitive_symmetry()
    return phonon.primitive_symmetry


""",
    )
    src = src.replace("factor=phonopy.units.VaspToTHz", "factor=_VASP_TO_THZ")
    src = src.replace(
        "open(\"BORN\"), phonon.get_primitive(),\n            phonon.get_primitive_symmetry()",
        "open(\"BORN\"), _get_primitive_compat(phonon),\n            _get_primitive_symmetry_compat(phonon)",
    )
    src = src.replace("phonon.set_force_constants(fc)", "_set_force_constants_compat(phonon, fc)")
    # Avoid self-recursion if the replacement touches this compatibility helper.
    src = src.replace(
        'if hasattr(phonon, "set_force_constants"):\n        _set_force_constants_compat(phonon, fc)',
        'if hasattr(phonon, "set_force_constants"):\n        phonon.set_force_constants(fc)',
    )
    grun_py.write_text(src)


def _prepare_qscaild_engine(args, legacy_dir: Path) -> Path:
    source_dir = _external_qscaild_dir(args)
    engine_dir = legacy_dir / "_qscaild_engine"
    if engine_dir.exists():
        shutil.rmtree(engine_dir)
    engine_dir.mkdir(parents=True, exist_ok=True)
    missing = []
    for name in QSCAILD_REQUIRED_FILES:
        src = source_dir / name
        dst = engine_dir / name
        if src.exists():
            shutil.copy(src, dst)
        else:
            missing.append(name)
    for optional in ("README.md", "COPYING"):
        src = source_dir / optional
        if src.exists():
            shutil.copy(src, engine_dir / optional)
    if missing:
        raise FileNotFoundError(
            f"QSCAILD source is missing required files: {', '.join(missing)} "
            f"(source: {source_dir})"
        )
    mpi_dir = engine_dir / "mpi4py"
    mpi_dir.mkdir(exist_ok=True)
    (mpi_dir / "__init__.py").write_text(MPI4PY_STUB)
    # Required when thirdorder_core C-extension is not built.
    (engine_dir / "thirdorder_core.py").write_text(THIRDORDER_CORE_STUB)
    _patch_qscaild_engine_files(engine_dir)
    print(f"QSCAILD engine source: {source_dir}")
    print("QSCAILD compatibility patch: applied automatically for current phonopy runtime")
    print("Reference paper: https://arxiv.org/abs/2006.12867")
    return engine_dir


def _legacy_sanitize_poscar(src: Path, dst: Path) -> None:
    from ase.io import read as ase_read, write as ase_write
    atoms = ase_read(src, format="vasp")
    ase_write(dst, atoms, format="vasp", direct=True, vasp5=True, sort=False)


def _legacy_write_sposcar(poscar: Path, sposcar: Path, dim: tuple[int, int, int]) -> None:
    from phonopy.interface.vasp import read_vasp, write_vasp
    from phonopy.structure.cells import get_supercell
    unitcell = read_vasp(str(poscar))
    supercell = get_supercell(unitcell, np.diag(dim))
    write_vasp(str(sposcar), supercell)


def _legacy_write_parameters(
    workdir: Path,
    temp_k: float,
    nconf: int,
    nfits: int,
    dim: tuple[int, int, int],
    third: bool,
    calc_symm: bool,
    use_smalldisp: bool,
    imaginary_freq: float,
    tolerance: float,
    pdiff: float,
    memory: float,
    mixing: float,
    grid: int,
    use_pressure: str,
    pressure_diag: tuple[float, float, float],
    symm_acoustic: bool,
) -> None:
    content = (
        f"name = {workdir.name}\n"
        f"T_K = {temp_k}\n"
        f"nconf = {nconf}\n"
        f"nfits = {nfits}\n"
        f"n0 = {dim[0]}\n"
        f"n1 = {dim[1]}\n"
        f"n2 = {dim[2]}\n"
        "cutoff = -3\n"
        f"third = {str(third)}\n"
        f"use_smalldisp = {str(bool(use_smalldisp))}\n"
        f"calc_symm = {str(calc_symm)}\n"
        f"symm_acoustic = {str(bool(symm_acoustic))}\n"
        f"imaginary_freq = {float(imaginary_freq)}\n"
        f"use_pressure = {use_pressure}\n"
        f"pressure_diag = {float(pressure_diag[0])},{float(pressure_diag[1])},{float(pressure_diag[2])}\n"
        f"tolerance = {float(tolerance)}\n"
        f"pdiff = {float(pdiff)}\n"
        f"memory = {float(memory)}\n"
        f"mixing = {float(mixing)}\n"
        f"grid = {int(grid)}\n"
    )
    (workdir / "parameters").write_text(content)


def _legacy_ensure_mat_rec_cache(legacy_dir: Path, dim: tuple[int, int, int]) -> None:
    fname = f"mat_rec_ac_2nd_{dim[0]}x{dim[1]}x{dim[2]}.npy"
    expected = legacy_dir.parent / fname
    if expected.exists():
        return
    repo = Path(__file__).resolve().parents[2]
    for c in [legacy_dir / fname, repo / "workdir" / fname, repo / fname]:
        if c.exists():
            shutil.copy(c, expected)
            return


def _legacy_seed_mat_rec_cache_from_arg(args, legacy_dir: Path, dim: tuple[int, int, int]) -> None:
    user_path = getattr(args, "mat_rec_cache", None)
    if not user_path:
        return
    src = Path(user_path).expanduser().resolve()
    if not src.is_file():
        raise FileNotFoundError(f"--mat-rec-cache file not found: {src}")
    expected_name = f"mat_rec_ac_2nd_{dim[0]}x{dim[1]}x{dim[2]}.npy"
    dst = legacy_dir.parent / expected_name
    shutil.copy(src, dst)
    print(f"Loaded mat_rec cache from: {src}")
    print(f"Copied mat_rec cache to:   {dst}")


def _legacy_has_mat_rec_cache(legacy_dir: Path, dim: tuple[int, int, int]) -> bool:
    fname = f"mat_rec_ac_2nd_{dim[0]}x{dim[1]}x{dim[2]}.npy"
    return (legacy_dir.parent / fname).exists()


def _legacy_clean_state(legacy_dir: Path) -> None:
    for pattern in [
        "QSCAILD.db",
        "iteration",
        "finished",
        "to_calc",
        "out_*",
        "FORCE_CONSTANTS",
        "FORCE_CONSTANTS_*",
        "POSCAR_CURRENT",
        "SPOSCAR_CURRENT",
        "qscaild-submit-*.log",
        "macer-force-*.log",
        "run_fit*.log",
    ]:
        for p in legacy_dir.glob(pattern):
            if p.is_file():
                p.unlink()
    for d in legacy_dir.glob("config-*"):
        if d.is_dir():
            shutil.rmtree(d)


def _legacy_clean_top_outputs(workdir: Path) -> None:
    for pattern in [
        "FORCE_CONSTANTS_*",
        "FC3_*",
        "out_*",
        "qscaild_fit_r2_history.*",
        "qscaild_free_energy_history.*",
        "qscaild_score_history.*",
        "sscha_convergence.*",
        "sscha_convergence-*.pdf",
        "band-*",
        "band.*",
        "weights_*",
        "iteration",
        "finished",
        "POSCAR_qscaild_input",
    ]:
        for p in workdir.glob(pattern):
            if p.is_file():
                p.unlink()
    for d in ["pb-harmonic-from-qscaild", "pb-final-from-qscaild", LEGACY_SUBDIR]:
        dd = workdir / d
        if dd.is_dir():
            shutil.rmtree(dd)


def _legacy_run_submit(legacy_dir: Path, engine_dir: Path, submit_idx: int) -> None:
    submit_py = engine_dir / "submit_qscaild.py"
    env = os.environ.copy()
    repo = Path(__file__).resolve().parents[2]
    env["PYTHONPATH"] = f"{engine_dir}:{legacy_dir}:{repo}:{env.get('PYTHONPATH', '')}".rstrip(":")
    log_path = legacy_dir / f"qscaild-submit-{submit_idx:02d}.log"

    def _extract_last_int_from_line(line: str) -> int | None:
        toks = line.replace(":", " ").split()
        for tok in reversed(toks):
            if tok.isdigit():
                return int(tok)
        return None

    def _read_submit_status():
        out_sym = legacy_dir / "out_sym"
        last_sym = ""
        before_asr = None
        after_asr = None
        if out_sym.exists():
            try:
                lines = out_sym.read_text(errors="replace").splitlines()
                if lines:
                    last_sym = lines[-1].strip()
                for line in lines:
                    low = line.lower()
                    if "before acoustic sum rule" in low:
                        before_asr = _extract_last_int_from_line(line)
                    elif "after acoustic sum rule" in low:
                        after_asr = _extract_last_int_from_line(line)
            except Exception:
                last_sym = ""
                before_asr = None
                after_asr = None

        to_calc_count = 0
        to_calc = legacy_dir / "to_calc"
        if to_calc.exists():
            try:
                with to_calc.open() as fp:
                    to_calc_count = sum(1 for line in fp if line.strip())
            except Exception:
                to_calc_count = 0

        config_count = sum(1 for d in legacy_dir.glob("config-*") if d.is_dir())
        return last_sym, before_asr, after_asr, config_count, to_calc_count

    with log_path.open("w") as f:
        proc = subprocess.Popen(
            [sys.executable, str(submit_py)],
            cwd=str(legacy_dir),
            env=env,
            stdout=f,
            stderr=subprocess.STDOUT,
            text=True,
        )
        t0 = time.time()
        next_report = t0 + 10.0
        while True:
            rc = proc.poll()
            if rc is not None:
                if rc != 0:
                    try:
                        tail_lines = log_path.read_text(errors="replace").splitlines()[-80:]
                        tail_msg = "\n".join(tail_lines)
                    except Exception:
                        tail_msg = "(failed to read submit log)"
                    raise RuntimeError(
                        "submit_qscaild.py failed. "
                        f"See log: {log_path}\n"
                        f"--- submit log tail ---\n{tail_msg}"
                    )
                break
            now = time.time()
            if now >= next_report:
                elapsed = int(now - t0)
                last_sym, before_asr, after_asr, config_count, to_calc_count = _read_submit_status()
                parts = [f"{elapsed}s"]
                if before_asr is not None:
                    parts.append(f"symm-before-ASR={before_asr}")
                if after_asr is not None:
                    parts.append(f"symm-after-ASR={after_asr}")
                if config_count > 0:
                    parts.append(f"config-dirs={config_count}")
                    parts.append(f"prepared={to_calc_count}/{config_count}")
                elif to_calc_count > 0:
                    parts.append(f"to-calc-ready={to_calc_count}")
                if last_sym and (before_asr is None and after_asr is None):
                    parts.append(f"out_sym='{last_sym}'")
                print("  submit running... " + ", ".join(parts))
                next_report = now + 10.0
            time.sleep(0.5)
        elapsed_total = int(time.time() - t0)
        _, before_asr, after_asr, config_count, to_calc_count = _read_submit_status()
        done_parts = [f"{elapsed_total}s", f"config-dirs={config_count}", f"to-calc-ready={to_calc_count}"]
        if config_count > 0:
            done_parts.append(f"prepared={to_calc_count}/{config_count}")
        if before_asr is not None:
            done_parts.append(f"symm-before-ASR={before_asr}")
        if after_asr is not None:
            done_parts.append(f"symm-after-ASR={after_asr}")
        print("  submit finished: " + ", ".join(done_parts))


def _legacy_run_forces(
    legacy_dir: Path,
    ff: str,
    device: str,
    cycle_idx: int,
    model_path: str | None = None,
    modal: str | None = None,
    sequential: bool = False,
    batch_size: int | None = None,
    need_stress: bool = False,
) -> int:
    from ase.io import read as ase_read
    from ase.io import write as ase_write
    from ase.calculators.singlepoint import SinglePointCalculator
    from macer.calculator.factory import get_calculator, evaluate_batch, evaluate_sequential
    from macer.io.writers import write_outcar, write_vasprun_xml
    to_calc = legacy_dir / "to_calc"
    if not to_calc.exists():
        raise FileNotFoundError(f"to_calc not found: {to_calc}")
    with to_calc.open() as fin:
        raw_dirs = [line.strip() for line in fin if line.strip()]
    if not raw_dirs:
        return 0
    print(f"  force-eval queue: {len(raw_dirs)} configs")

    calc_dirs: list[Path] = []
    atoms_list = []
    for entry in raw_dirs:
        cdir = Path(entry)
        if not cdir.is_absolute():
            cdir = (legacy_dir / cdir).resolve()
        poscar_path = cdir / "POSCAR"
        if not poscar_path.exists():
            raise FileNotFoundError(f"POSCAR not found in config directory: {poscar_path}")
        calc_dirs.append(cdir)
        atoms_list.append(ase_read(str(poscar_path), format="vasp"))

    calc_kwargs = {"device": device, "modal": modal}
    if model_path:
        if ff == "mace":
            calc_kwargs["model_paths"] = [str(model_path)]
        else:
            calc_kwargs["model_path"] = str(model_path)
    calculator = get_calculator(ff_name=ff, **calc_kwargs)

    properties = ["energy", "forces"]
    if need_stress:
        properties.append("stress")

    if not sequential:
        print(f"  force-eval mode: batch (batch_size={batch_size if batch_size is not None else 'auto'})")
        try:
            res = evaluate_batch(
                calculator,
                atoms_list,
                batch_size=batch_size,
                properties=properties,
            )
        except Exception as e:
            print(f"  [Warning] Legacy force batch calculation failed:\n  {e}\n  Falling back to sequential evaluation...")
            print("  force-eval mode: sequential (fallback)")
            res = evaluate_sequential(
                calculator,
                atoms_list,
                properties=properties,
            )
    else:
        print("  force-eval mode: sequential (user-forced)")
        res = evaluate_sequential(
            calculator,
            atoms_list,
            properties=properties,
        )

    energies = res["energy"]
    forces = res["forces"]
    stress = res.get("stress")

    with (legacy_dir / f"macer-force-{cycle_idx:02d}.log").open("w") as flog:
        for i, cdir in enumerate(tqdm(calc_dirs, desc=f"Cycle {cycle_idx:03d} force eval", unit="cfg")):
            energy_i = float(energies[i])
            forces_i = np.array(forces[i], dtype=float)
            stress_i = None if stress is None else np.array(stress[i], dtype=float)

            atoms_i = atoms_list[i].copy()
            sp_kwargs = {"energy": energy_i, "forces": forces_i}
            if stress_i is not None:
                sp_kwargs["stress"] = stress_i
            atoms_i.calc = SinglePointCalculator(atoms_i, **sp_kwargs)

            outcar_path = cdir / "OUTCAR"
            xml_path = cdir / "vasprun.xml"
            contcar_path = cdir / "CONTCAR"

            write_outcar(atoms_i, energy_i, outcar_name=str(outcar_path), verbose=False)
            write_vasprun_xml(
                atoms_i,
                energy_i,
                xml_name=str(xml_path),
                steps_data=[{"atoms": atoms_i, "energy": energy_i, "forces": forces_i}],
                verbose=False,
            )
            ase_write(str(contcar_path), atoms_i, format="vasp", vasp5=True)
            flog.write(f"[macer] {cdir} energy={energy_i:.12f}\n")

    return len(calc_dirs)


def _legacy_sync_outputs(workdir: Path, legacy_dir: Path) -> None:
    for name in [
        "FORCE_CONSTANTS_CURRENT",
        "FORCE_CONSTANTS_PREVIOUS",
        "iteration",
        "finished",
        "out_fit",
        "out_convergence",
        "out_energy",
        "out_volume",
    ]:
        src = legacy_dir / name
        if src.exists():
            shutil.copy(src, workdir / name)
    for src_name, dst_name in {
        "out_fit": "out_fit.txt",
        "out_convergence": "out_convergence.txt",
        "out_energy": "out_energy.txt",
        "out_volume": "out_volume.txt",
    }.items():
        src = workdir / src_name
        if src.exists():
            shutil.copy(src, workdir / dst_name)


def _format_temp_tag(temperature: float) -> str:
    t = float(temperature)
    if t.is_integer():
        return f"{int(t)}"
    return f"{t:g}"


def _legacy_count_to_calc(legacy_dir: Path) -> int:
    p = legacy_dir / "to_calc"
    if not p.exists():
        return 0
    try:
        with p.open() as f:
            return sum(1 for line in f if line.strip())
    except Exception:
        return 0


def _legacy_latest_score(legacy_dir: Path) -> float:
    out_fit = legacy_dir / "out_fit"
    if not out_fit.exists():
        return float("nan")
    score = float("nan")
    with out_fit.open() as f:
        for line in f:
            s = line.strip()
            if s.startswith("score:"):
                try:
                    score = float(s.split(":", 1)[1].strip())
                except Exception:
                    pass
    return score


def _legacy_history_paths(workdir: Path) -> tuple[Path, Path, Path]:
    fit_r2_log = workdir / "qscaild_fit_r2_history.log"
    score_alias_log = workdir / "qscaild_score_history.log"
    free_energy_alias_log = workdir / "qscaild_free_energy_history.log"
    return fit_r2_log, score_alias_log, free_energy_alias_log


def _legacy_append_score_hist(workdir: Path, iteration: int, score: float, conv: dict[str, float]) -> None:
    fit_r2_log, score_alias_log, _ = _legacy_history_paths(workdir)
    header = (
        "# iter fit_r2 fc_diff_max fc_diff_mean fc_diff_rel_max\n"
    )
    for p in (fit_r2_log, score_alias_log):
        if not p.exists():
            p.write_text(header)

    def _fmt(x: float | None) -> str:
        if x is None:
            return "nan"
        try:
            return f"{float(x):.12g}"
        except Exception:
            return "nan"

    line = " ".join(
        [
            str(int(iteration)),
            _fmt(score),
            _fmt(conv.get("fc_diff_max")),
            _fmt(conv.get("fc_diff_mean")),
            _fmt(conv.get("fc_diff_rel_max")),
        ]
    ) + "\n"
    for p in (fit_r2_log, score_alias_log):
        with p.open("a") as f:
            f.write(line)


def _legacy_last_convergence_metrics(legacy_dir: Path) -> dict[str, float]:
    out_conv = legacy_dir / "out_convergence"
    if not out_conv.exists():
        return {}
    metrics: dict[str, float] = {}
    try:
        with out_conv.open() as f:
            for raw in f:
                s = raw.strip()
                if ":" not in s:
                    continue
                key, val = s.split(":", 1)
                key = key.strip().lower()
                val = val.strip()
                try:
                    x = float(val)
                except Exception:
                    continue
                if key == "fcs max absolute difference":
                    metrics["fc_diff_max"] = x
                elif key == "fcs mean absolute difference":
                    metrics["fc_diff_mean"] = x
                elif key == "fcs max relative difference":
                    metrics["fc_diff_rel_max"] = x
    except Exception:
        return {}
    return metrics


def _legacy_load_iteration_ensemble_with_energy(
    legacy_dir: Path,
    iteration: int,
    natoms_super: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    import sqlite3

    db_path = legacy_dir / "QSCAILD.db"
    if not db_path.exists():
        raise FileNotFoundError(f"QSCAILD.db not found at {db_path}")

    U_rows: list[np.ndarray] = []
    w_rows: list[float] = []
    e_rows: list[float] = []
    conn = sqlite3.connect(str(db_path))
    try:
        cur = conn.cursor()
        cur.execute(
            "SELECT displacements, current_proba, energy, har_energy "
            "FROM configurations WHERE iteration=? ORDER BY id ASC",
            (int(iteration),),
        )
        rows = cur.fetchall()
    finally:
        conn.close()

    if not rows:
        raise RuntimeError(f"No ensemble rows found in DB for iteration={iteration}.")

    ncart = natoms_super * 3
    for disp_txt, w_val, e_val, har_e_val in rows:
        disp = np.fromstring(str(disp_txt).strip().strip("[]"), sep=",", dtype=float)
        if disp.size != ncart:
            raise RuntimeError(
                f"Unexpected displacement length={disp.size}, expected={ncart} "
                f"(natoms_super={natoms_super})"
            )
        U_rows.append(disp.reshape(natoms_super, 3))
        try:
            w_rows.append(float(w_val))
        except Exception:
            w_rows.append(1.0)
        e_use = e_val
        try:
            e_float = float(e_use)
            if not np.isfinite(e_float):
                raise ValueError
            e_rows.append(e_float)
        except Exception:
            try:
                e_har = float(har_e_val)
                if np.isfinite(e_har):
                    e_rows.append(e_har)
                else:
                    e_rows.append(float("nan"))
            except Exception:
                e_rows.append(float("nan"))

    U = np.asarray(U_rows, dtype=float)
    w = np.asarray(w_rows, dtype=float)
    E = np.asarray(e_rows, dtype=float)
    if not np.all(np.isfinite(w)) or float(np.sum(w)) <= 0:
        w = np.ones(len(U), dtype=float)
    w /= np.sum(w)
    return U, w, E


def _legacy_load_iteration_ensemble(legacy_dir: Path, iteration: int, natoms_super: int) -> tuple[np.ndarray, np.ndarray]:
    U, w, _ = _legacy_load_iteration_ensemble_with_energy(legacy_dir, iteration, natoms_super)
    return U, w


def _legacy_compute_cycle_free_energy(
    legacy_dir: Path,
    top_poscar: Path,
    dim: tuple[int, int, int],
    iteration: int,
    temperature: float,
    mesh: list[int],
    symprec: float,
) -> tuple[float, float]:
    from phonopy import Phonopy
    from phonopy.interface.vasp import read_vasp
    from phonopy.file_IO import parse_FORCE_CONSTANTS
    from phonopy.physical_units import get_physical_units

    fc_path = legacy_dir / "FORCE_CONSTANTS_CURRENT"
    if not fc_path.exists():
        return float("nan"), float("nan")

    unitcell = read_vasp(str(top_poscar))
    ph = Phonopy(
        unitcell,
        supercell_matrix=np.diag(dim),
        primitive_matrix="auto",
        symprec=float(symprec),
    )
    natoms_super = len(ph.supercell)
    U_fit, w_fit, E_fit = _legacy_load_iteration_ensemble_with_energy(
        legacy_dir=legacy_dir,
        iteration=int(iteration),
        natoms_super=natoms_super,
    )
    fc_current = parse_FORCE_CONSTANTS(filename=str(fc_path))
    if not np.all(np.isfinite(E_fit)):
        # Fallback: harmonic free energy from FC only.
        ph.force_constants = fc_current
        ph.run_mesh(list(mesh))
        ph.run_thermal_properties(t_min=float(temperature), t_max=float(temperature), t_step=float(temperature))
        hfe_kJmol = ph.get_thermal_properties_dict()["free_energy"][0]
        hfe_eV = hfe_kJmol / get_physical_units().EvTokJmol
        n_atom_primitive = len(ph.primitive)
        hfe_mev_atom = (float(hfe_eV) * 1000.0) / n_atom_primitive
        return float(hfe_eV), float(hfe_mev_atom)

    fe_eV = compute_weighted_free_energy(
        U=U_fit,
        E=E_fit,
        FC=fc_current,
        FC3=None,
        w=w_fit,
        ph=ph,
        T=float(temperature),
        mesh=list(mesh),
        return_components=False,
    )
    n_atom_primitive = len(ph.primitive)
    fe_mev_atom = (float(fe_eV) * 1000.0) / n_atom_primitive
    return float(fe_eV), float(fe_mev_atom)


def _legacy_append_thermo_free_energy(workdir: Path, iteration: int, fe_eV: float, fe_mev_atom: float) -> None:
    p = workdir / "qscaild_thermo_free_energy.log"
    _, _, free_energy_alias_log = _legacy_history_paths(workdir)
    header = "# iter free_energy_eV free_energy_meV_per_atom\n"
    for path in (p, free_energy_alias_log):
        if not path.exists():
            path.write_text(header)
        with path.open("a") as f:
            f.write(f"{int(iteration)} {fe_eV:.12g} {fe_mev_atom:.12g}\n")


def _legacy_export_adp_from_db(
    workdir: Path,
    legacy_dir: Path,
    top_poscar: Path,
    dim: tuple[int, int, int],
    iteration: int,
    symprec: float,
    projection_axis_frac=None,
) -> None:
    from phonopy import Phonopy
    from phonopy.interface.vasp import read_vasp

    unitcell = read_vasp(str(top_poscar))
    ph = Phonopy(
        unitcell,
        supercell_matrix=np.diag(dim),
        primitive_matrix="auto",
        symprec=float(symprec),
    )
    natoms_super = len(ph.supercell)
    U_fit, w_fit = _legacy_load_iteration_ensemble(legacy_dir, int(iteration), natoms_super)
    _save_weighted_average_and_adp(
        output_dir=workdir,
        iteration=int(iteration),
        ph=ph,
        U_fit=U_fit,
        w_fit=w_fit,
        projection_axis_frac=projection_axis_frac,
    )


def _legacy_print_cycle_summary(
    legacy_dir: Path,
    workdir: Path,
    submit_idx: int,
    tolerance: float,
    score: float | None = None,
    conv: dict[str, float] | None = None,
    free_energy_eV: float | None = None,
    free_energy_meV_atom: float | None = None,
) -> None:
    if score is None:
        score = _legacy_latest_score(legacy_dir)
    if conv is None:
        conv = _legacy_last_convergence_metrics(legacy_dir)
    print(f"Cycle {submit_idx:03d} summary:")
    if np.isfinite(float(score)):
        print(f"  Fit R^2: {score:.8f}")
    else:
        print("  Fit R^2: n/a")

    if "fc_diff_max" in conv:
        fc_max = conv["fc_diff_max"]
        if tolerance > 0:
            ratio = fc_max / tolerance
            conv_txt = "yes" if fc_max < tolerance else "no"
            print(
                "  FC convergence: "
                f"current={fc_max:.6e}, target<{tolerance:.6e}, "
                f"ratio={ratio:.2f}x, converged={conv_txt}"
            )
        else:
            print(f"  FC convergence: current={fc_max:.6e}, target=<disabled")
    else:
        print("  FC convergence: n/a")

    if "fc_diff_mean" in conv:
        print(f"  FC diff mean: {conv['fc_diff_mean']:.6e}")
    if "fc_diff_rel_max" in conv:
        print(f"  FC diff rel max: {conv['fc_diff_rel_max']:.6e}")

    if (
        free_energy_eV is not None
        and free_energy_meV_atom is not None
        and np.isfinite(float(free_energy_eV))
        and np.isfinite(float(free_energy_meV_atom))
    ):
        print(
            "  Free energy (estimated from current ensemble): "
            f"{float(free_energy_meV_atom):.6f} meV/atom "
            f"({float(free_energy_eV):.8f} eV)"
        )
    else:
        print("  Free energy (estimated from current ensemble): n/a")

    print(f"  fit_r2 log: {workdir / 'qscaild_fit_r2_history.log'}")
    print(f"  free-energy log: {workdir / 'qscaild_thermo_free_energy.log'}")


def _legacy_plot_score_hist(workdir: Path) -> None:
    fit_r2_log, score_alias_log, free_energy_alias_log = _legacy_history_paths(workdir)
    def _load_xy(path: Path, x_col: int = 0, y_col: int = 1) -> tuple[list[int], list[float]]:
        xs, ys = [], []
        if not path.exists():
            return xs, ys
        with path.open() as f:
            for line in f:
                s = line.strip()
                if not s or s.startswith("#"):
                    continue
                t = s.split()
                if len(t) <= max(x_col, y_col):
                    continue
                try:
                    xs.append(int(float(t[x_col])))
                    ys.append(float(t[y_col]))
                except Exception:
                    pass
        return xs, ys

    # Fit-R^2 plot
    xs, ys = _load_xy(fit_r2_log, 0, 1)
    if xs:
        plt.figure(figsize=(6.0, 4.0))
        plt.plot(xs, ys, marker="o", linewidth=1.5)
        plt.xlabel("Iteration")
        plt.ylabel("Fit R^2")
        plt.title("QSCAILD Fit R^2 Convergence")
        plt.grid(alpha=0.3)
        plt.tight_layout()
        plt.savefig(workdir / "qscaild_fit_r2_history.pdf")
        plt.close()

    # Score plot (same source metric as out_fit score)
    xs_s, ys_s = _load_xy(score_alias_log, 0, 1)
    if xs_s:
        plt.figure(figsize=(6.0, 4.0))
        plt.plot(xs_s, ys_s, marker="o", linewidth=1.5)
        plt.xlabel("Iteration")
        plt.ylabel("Score")
        plt.title("QSCAILD Score History")
        plt.grid(alpha=0.3)
        plt.tight_layout()
        plt.savefig(workdir / "qscaild_score_history.pdf")
        plt.close()

    # Free-energy plot (meV/atom)
    xs_f, ys_f = _load_xy(free_energy_alias_log, 0, 2)
    if xs_f:
        plt.figure(figsize=(6.0, 4.0))
        plt.plot(xs_f, ys_f, marker="o", linewidth=1.5)
        plt.xlabel("Iteration")
        plt.ylabel("Free energy (meV/atom)")
        plt.title("QSCAILD Free Energy History")
        plt.grid(alpha=0.3)
        plt.tight_layout()
        plt.savefig(workdir / "qscaild_free_energy_history.pdf")
        plt.close()


def _legacy_write_sscha_style_convergence(workdir: Path, input_stem: str) -> None:
    fit_r2_log = workdir / "qscaild_fit_r2_history.log"
    if not fit_r2_log.exists():
        return

    rows: list[tuple[int, float, float, float, float]] = []
    with fit_r2_log.open() as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            t = s.split()
            if len(t) < 5:
                continue
            try:
                rows.append((int(float(t[0])), float(t[1]), float(t[2]), float(t[3]), float(t[4])))
            except Exception:
                continue
    if not rows:
        return

    fe_log = workdir / "qscaild_thermo_free_energy.log"
    fe_rows: dict[int, float] = {}
    if fe_log.exists():
        with fe_log.open() as f:
            for line in f:
                s = line.strip()
                if not s or s.startswith("#"):
                    continue
                t = s.split()
                if len(t) < 3:
                    continue
                try:
                    fe_rows[int(float(t[0]))] = float(t[2])
                except Exception:
                    continue

    conv_log = workdir / "sscha_convergence.log"
    with conv_log.open("w") as f:
        f.write("# Iteration    Free_Energy_meV_per_atom    Fit_R2    FC_Diff_Max    FC_Diff_Mean    FC_Diff_Rel_Max\n")
        for it, r2, dmax, dmean, drel in rows:
            fe = fe_rows.get(it, float("nan"))
            f.write(
                f"{it:8d}    {fe:25.8f}    {r2:16.8f}    {dmax:16.8e}    {dmean:16.8e}    {drel:16.8e}\n"
            )

    # Keep only the tabulated convergence log to avoid plot duplication with
    # qscaild_free_energy_history.pdf.


def _legacy_export_final_phonopy_inputs(workdir: Path, pb_final_dir: Path, input_stem: str) -> None:
    # Top-level rerun files for: phonopy -p band-{stem}.conf
    conf_src = pb_final_dir / f"band-{input_stem}-final.conf"
    if conf_src.exists():
        shutil.copy(conf_src, workdir / f"band-{input_stem}.conf")
    for name in ("POSCAR-input", "POSCAR"):
        src = pb_final_dir / name
        if src.exists():
            shutil.copy(src, workdir / name)
    fc_src = workdir / "FORCE_CONSTANTS_CURRENT"
    if fc_src.exists():
        shutil.copy(fc_src, workdir / "FORCE_CONSTANTS")


def _legacy_export_sscha_iteration_aliases(
    workdir: Path,
    input_stem: str,
    iteration: int,
    temperature: float,
    fc_snapshot: Path | None = None,
) -> None:
    fc_curr = fc_snapshot if fc_snapshot is not None else (workdir / "FORCE_CONSTANTS_CURRENT")
    if fc_curr.exists():
        ttag = _format_temp_tag(float(temperature))
        shutil.copy(fc_curr, workdir / f"FORCE_CONSTANTS_SSCHA_T{ttag}_i{iteration}")

    # Iterative band aliases to match sscha.py style (non-zero-padded index).
    for ext in ("pdf", "yaml", "dat"):
        src = workdir / f"band-{input_stem}_{iteration:04d}.{ext}"
        if src.exists():
            shutil.copy(src, workdir / f"band-{input_stem}_{iteration}.{ext}")

    # Keep a simple latest weighted-average alias like sscha.py.
    poscar_avg = workdir / f"POSCAR_average_i{iteration:04d}"
    if poscar_avg.exists():
        shutil.copy(poscar_avg, workdir / "POSCAR_average")


def _legacy_snapshot_fc(workdir: Path, legacy_dir: Path, iteration: int) -> tuple[Path | None, bool]:
    src = legacy_dir / "FORCE_CONSTANTS_CURRENT"
    if not src.exists():
        return None, False

    dst = legacy_dir / f"FORCE_CONSTANTS_iter_{iteration:04d}"
    shutil.copy(src, dst)
    with (workdir / "band_checkpoint_fc_map.log").open("a") as f:
        f.write(f"{iteration:04d} {dst}\n")

    changed = True
    prev_iter = sorted(legacy_dir.glob("FORCE_CONSTANTS_iter_*"))
    if len(prev_iter) >= 2:
        prev = prev_iter[-2]
        try:
            changed = prev.read_bytes() != dst.read_bytes()
        except Exception:
            changed = True
    else:
        # First checkpoint: compare with init FC if present.
        init_fc = workdir / "FORCE_CONSTANTS_init"
        if init_fc.exists():
            try:
                changed = init_fc.read_bytes() != dst.read_bytes()
            except Exception:
                changed = True
    return dst, changed


def _legacy_convert_npy_to_dat(root: Path, keep_npy: bool) -> None:
    for npy in root.rglob("*.npy"):
        try:
            arr = np.load(npy, allow_pickle=False)
        except Exception:
            continue
        dat = npy.with_suffix(".dat")
        with dat.open("w") as f:
            f.write(f"# Converted from {npy.name}\n")
            f.write(f"# shape: {arr.shape}\n")
            if arr.ndim == 0:
                f.write(f"{arr.item()}\n")
            elif arr.ndim == 1:
                for x in arr:
                    f.write(f"{float(x):.16e}\n")
            else:
                flat = arr.reshape(arr.shape[0], -1)
                np.savetxt(f, flat, fmt="%.16e")
        if not keep_npy:
            npy.unlink()


def _legacy_run_pb_from_fc(workdir: Path, poscar: Path, dim: tuple[int, int, int], ff: str, device: str,
                           output_prefix: str, fc_path: Path, out_dir_name: str) -> Path:
    from macer.phonopy.phonon_band import run_macer_workflow
    out_dir = workdir / out_dir_name
    out_dir.mkdir(exist_ok=True)
    run_macer_workflow(
        input_path=poscar,
        min_length=20.0,
        displacement_distance=0.01,
        is_plusminus=True,
        is_diagonal=True,
        macer_device=device,
        macer_model_path=None,
        model_info_str="",
        yaml_path_arg=Path("phonopy_disp.yaml"),
        out_path_arg=Path("band.conf"),
        gamma_label="GM",
        symprec_seekpath=1e-5,
        dim_override=f"{dim[0]} {dim[1]} {dim[2]}",
        no_defaults_band_conf=False,
        atom_names_override=None,
        rename_override=None,
        tolerance_sr=0.01,
        tolerance_phonopy=5e-3,
        macer_optimizer_name="FIRE",
        fix_axis=None,
        macer_ff=ff,
        macer_modal=None,
        plot_gruneisen=False,
        use_relax_unit=False,
        initial_fmax=0.005,
        initial_symprec=1e-5,
        initial_isif=0,
        output_prefix=output_prefix,
        show_irreps=False,
        write_arrow=False,
        output_dir_arg=str(out_dir),
        plot_dos=False,
        mesh=[11, 11, 11],
        read_fc_path=fc_path,
        skip_initial_relax=True,
        manual_band_path=None,
        manual_labels=None,
    )
    return out_dir


def _legacy_build_pb_harmonic_reference(
    workdir: Path,
    poscar: Path,
    dim: tuple[int, int, int],
    ff: str,
    device: str,
    initial_isif: int,
    initial_fmax: float,
    model_path: str | None,
    modal: str | None,
    input_stem: str,
) -> tuple[Path, Path]:
    from macer.phonopy.phonon_band import run_macer_workflow

    out_dir = workdir / "pb-harmonic-ref-from-qscaild"
    out_dir.mkdir(exist_ok=True)
    out_prefix = f"{input_stem}-pb-harmonic"
    run_macer_workflow(
        input_path=poscar,
        min_length=20.0,
        displacement_distance=0.01,
        is_plusminus=True,
        is_diagonal=True,
        macer_device=device,
        macer_model_path=model_path,
        model_info_str="",
        yaml_path_arg=Path("phonopy_disp.yaml"),
        out_path_arg=Path("band.conf"),
        gamma_label="GM",
        symprec_seekpath=1e-5,
        dim_override=f"{dim[0]} {dim[1]} {dim[2]}",
        no_defaults_band_conf=False,
        atom_names_override=None,
        rename_override=None,
        tolerance_sr=0.01,
        tolerance_phonopy=5e-3,
        macer_optimizer_name="FIRE",
        fix_axis=None,
        macer_ff=ff,
        macer_modal=modal,
        plot_gruneisen=False,
        use_relax_unit=False,
        initial_fmax=float(initial_fmax),
        initial_symprec=1e-5,
        initial_isif=int(initial_isif),
        output_prefix=out_prefix,
        show_irreps=False,
        write_arrow=False,
        output_dir_arg=str(out_dir),
        plot_dos=False,
        mesh=[11, 11, 11],
        read_fc_path=None,
        skip_initial_relax=(int(initial_isif) == 0),
        manual_band_path=None,
        manual_labels=None,
    )
    fc_path = out_dir / "FORCE_CONSTANTS"
    if not fc_path.exists():
        raise FileNotFoundError(f"pb-harmonic reference FC not found at {fc_path}")
    return fc_path, out_dir


def _legacy_promote_band_outputs(pb_dir: Path, workdir: Path, prefix: str, tag: str) -> None:
    for ext in ("pdf", "yaml", "dat"):
        src = pb_dir / f"band-{prefix}-{tag}.{ext}"
        if src.exists():
            shutil.copy(src, workdir / f"band-{prefix}_{tag}.{ext}")
            # Keep sscha-like aliases for latest/primary outputs.
            if tag == "final":
                shutil.copy(src, workdir / f"band-{prefix}.{ext}")
                shutil.copy(src, workdir / f"band.{ext}")
    if tag == "harmonic":
        for ext in ("pdf", "yaml", "dat"):
            src = workdir / f"band-{prefix}_harmonic.{ext}"
            if src.exists():
                shutil.copy(src, workdir / f"band-{prefix}_harmoinc.{ext}")
                shutil.copy(src, workdir / f"band-{prefix}_harmoic.{ext}")


def _legacy_promote_checkpoint_band_outputs(pb_dir: Path, workdir: Path, prefix: str, iter_idx: int) -> None:
    tag = f"{iter_idx:04d}"
    for ext in ("pdf", "yaml", "dat"):
        src = pb_dir / f"band-{prefix}-{tag}.{ext}"
        if src.exists():
            shutil.copy(src, workdir / f"band-{prefix}_{tag}.{ext}")
            # Latest checkpoint aliases
            shutil.copy(src, workdir / f"band-{prefix}.{ext}")
            shutil.copy(src, workdir / f"band.{ext}")
    conf_src = pb_dir / f"band-{prefix}-{tag}.conf"
    if conf_src.exists():
        shutil.copy(conf_src, workdir / f"band-{prefix}_{tag}.conf")


def _resolve_legacy_dim(args, input_poscar_path: Path) -> tuple[list[int], str]:
    dim_arg = getattr(args, "dim", None)
    if dim_arg:
        dim = [int(x) for x in dim_arg]
        if len(dim) == 9:
            dmat = np.array(dim).reshape(3, 3)
            if not np.all(dmat == np.diag(np.diag(dmat))):
                raise ValueError("QSCAILD backend supports diagonal --dim only.")
            dim = [int(dmat[0, 0]), int(dmat[1, 1]), int(dmat[2, 2])]
        elif len(dim) != 3:
            raise ValueError("QSCAILD backend requires --dim with 3 or 9 integers.")
        return dim, "from --dim"

    from ase.io import read as ase_read
    atoms = ase_read(str(input_poscar_path), format="vasp")
    vec_lens = [float(np.linalg.norm(v)) for v in atoms.cell]
    min_len = float(getattr(args, "min_length", 15.0))
    dim = [max(1, int(np.ceil(min_len / L))) if L > 0 else 1 for L in vec_lens]
    return dim, f"from --min-length={min_len}"


def _resolve_symm_acoustic(args, input_poscar_path: Path) -> tuple[bool, str]:
    user_value = getattr(args, "symm_acoustic", None)
    if user_value is not None:
        return bool(user_value), "from CLI"

    # Auto heuristic: single-element systems are often over-constrained by
    # acoustic-sum-rule reduction in the bundled QSCAILD fit.
    from ase.io import read as ase_read
    atoms = ase_read(str(input_poscar_path), format="vasp")
    uniq = set(atoms.get_chemical_symbols())
    if len(uniq) == 1:
        return False, "auto(single-element)"
    return True, "auto(default)"


def _print_legacy_run_settings(
    args,
    input_poscar_path: Path,
    output_dir: Path,
    dim: list[int],
    dim_origin: str,
) -> None:
    rows = [
        ("input", str(input_poscar_path)),
        ("output-dir", str(output_dir)),
        ("temperature (K)", f"{float(args.temperature):.1f}"),
        ("supercell dim", f"{dim} ({dim_origin})"),
        ("nconf (configs/cycle)", str(int(args.nconf))),
        ("nsteps (max cycles)", str(int(args.nsteps))),
        ("save-every (FC snapshot)", str(int(getattr(args, "save_every", 5)))),
        ("memory (history ratio)", f"{float(getattr(args, 'memory', 0.3))}"),
        ("mixing (FC update)", f"{float(getattr(args, 'mixing', 0.0))}"),
        ("tolerance (IFC conv)", f"{float(getattr(args, 'tolerance', 1e-2))}"),
        ("pdiff (kbar)", f"{float(getattr(args, 'pdiff', 2.0))}"),
        ("grid (q-grid size)", str(int(getattr(args, "grid", 9)))),
        ("imaginary-freq (THz)", f"{float(getattr(args, 'imaginary_freq', 1.0))}"),
        ("symm-acoustic", f"{bool(getattr(args, 'symm_acoustic', True))} ({getattr(args, '_symm_acoustic_origin', 'n/a')})"),
        ("mesh (free-energy)", f"{getattr(args, 'mesh', None)}"),
        ("ff/model/device/modal", f"{args.ff} / {getattr(args, 'model', None)} / {args.device} / {getattr(args, 'modal', None)}"),
        ("include-third-order", str(bool(getattr(args, "include_third_order", False)))),
        ("plot-bands", str(bool(getattr(args, "plot_bands", True)))),
        ("save-npy", str(bool(getattr(args, "save_npy", False)))),
        ("reference-method", f"{getattr(args, 'reference_method', 'random')} (QSCAILD currently uses random only)"),
        ("optimize-volume", f"{bool(getattr(args, 'optimize_volume', False))} (not used in current QSCAILD flow)"),
        ("read-initial-fc", f"{getattr(args, 'read_initial_fc', None)} (used as harmonic reference when provided)"),
    ]

    width = max(len(k) for k, _ in rows)
    print("Run settings:")
    for key, val in rows:
        print(f"  {key:<{width}} : {val}")


def _run_qscaild_legacy_backend(args, input_poscar_path: Path, output_dir: Path):
    dim, dim_origin = _resolve_legacy_dim(args, input_poscar_path)
    symm_acoustic, symm_acoustic_origin = _resolve_symm_acoustic(args, input_poscar_path)
    args.symm_acoustic = bool(symm_acoustic)
    args._symm_acoustic_origin = symm_acoustic_origin

    if getattr(args, "dry_run", False):
        print("Dry-run mode: validated QSCAILD settings. Exiting before force evaluations.")
        try:
            src = _external_qscaild_dir(args)
            print(f"QSCAILD engine source dir: {src}")
        except Exception as e:
            print(str(e))
        _print_legacy_run_settings(args, input_poscar_path, output_dir, dim, dim_origin)
        return

    _print_legacy_run_settings(args, input_poscar_path, output_dir, dim, dim_origin)

    if getattr(args, "reference_method", "random") != "random":
        print("WARNING: QSCAILD currently supports random ensemble only; forcing reference method to random.")
    if getattr(args, "optimize_volume", False):
        print("WARNING: --optimize-volume is not used in current QSCAILD flow.")

    nconf_eff = int(args.nconf)
    if nconf_eff < 2:
        print("WARNING: QSCAILD requires nconf >= 2. Overriding nconf to 2.")
        nconf_eff = 2

    workdir = output_dir
    legacy_dir = workdir / LEGACY_SUBDIR
    _legacy_clean_state(legacy_dir) if legacy_dir.exists() else None

    if getattr(args, "clean", False):
        _legacy_clean_top_outputs(workdir)
    legacy_dir.mkdir(parents=True, exist_ok=True)
    _legacy_clean_state(legacy_dir)
    engine_dir = _prepare_qscaild_engine(args, legacy_dir)

    # Required placeholders for qscaild submit script.
    if not (legacy_dir / "INCAR").exists():
        (legacy_dir / "INCAR").write_text("SYSTEM = macer-qscaild\n")
    if not (legacy_dir / "POTCAR").exists():
        (legacy_dir / "POTCAR").write_text("POTCAR_PLACEHOLDER_FOR_MLFF\n")
    if not (legacy_dir / "KPOINTS").exists():
        (legacy_dir / "KPOINTS").write_text("Gamma\n0\nGamma\n1 1 1\n0 0 0\n")

    top_poscar = workdir / "POSCAR_qscaild_input"
    _legacy_sanitize_poscar(input_poscar_path, top_poscar)
    legacy_poscar = legacy_dir / "POSCAR"
    shutil.copy(top_poscar, legacy_poscar)
    _legacy_write_sposcar(legacy_poscar, legacy_dir / "SPOSCAR", tuple(dim))

    # Build a harmonic FC reference with the same logic as `macer phonopy pb`.
    # This reference is used for harmonic/harmoinc outputs and init alias.
    harmonic_ref_fc: Path | None = None
    if getattr(args, "read_initial_fc", None):
        cand = Path(str(args.read_initial_fc)).expanduser().resolve()
        if not cand.exists():
            raise FileNotFoundError(f"--read-initial-fc not found: {cand}")
        harmonic_ref_fc = cand
        print(f"Using user-provided harmonic reference FC: {harmonic_ref_fc}")
    else:
        print("Building harmonic reference FC using pb-equivalent workflow...")
        harmonic_ref_fc, pb_ref_dir = _legacy_build_pb_harmonic_reference(
            workdir=workdir,
            poscar=top_poscar,
            dim=tuple(dim),
            ff=args.ff,
            device=args.device,
            initial_isif=int(getattr(args, "initial_isif", 3)),
            initial_fmax=float(getattr(args, "initial_fmax", 5e-3)),
            model_path=_resolve_model_path(args.ff, getattr(args, "model", None)),
            modal=getattr(args, "modal", None),
            input_stem=input_poscar_path.stem,
        )
        print(f"Harmonic reference FC: {harmonic_ref_fc} (from {pb_ref_dir})")
    if harmonic_ref_fc is not None and harmonic_ref_fc.exists():
        shutil.copy(harmonic_ref_fc, workdir / "FORCE_CONSTANTS_harmonic")
        shutil.copy(harmonic_ref_fc, workdir / "FORCE_CONSTANTS_harmoinc")
        shutil.copy(harmonic_ref_fc, workdir / "FORCE_CONSTANTS_init")
        shutil.copy(harmonic_ref_fc, legacy_dir / "FORCE_CONSTANTS")

    _legacy_seed_mat_rec_cache_from_arg(args, legacy_dir, tuple(dim))
    _legacy_ensure_mat_rec_cache(legacy_dir, tuple(dim))
    need_symmetry = not _legacy_has_mat_rec_cache(legacy_dir, tuple(dim))
    if need_symmetry:
        print(
            "No cached 2nd-order symmetry matrix found; "
            "running one-time symmetry build (can be slow on first run)."
        )
    else:
        print("Found cached 2nd-order symmetry matrix; skipping symmetry rebuild.")

    _legacy_write_parameters(
        workdir=legacy_dir,
        temp_k=float(args.temperature),
        nconf=nconf_eff,
        nfits=int(args.nsteps),
        dim=tuple(dim),
        third=bool(getattr(args, "include_third_order", False)),
        # Build only when cache is missing; otherwise reuse cached matrix.
        calc_symm=need_symmetry,
        use_smalldisp=bool(getattr(args, "use_smalldisp", False)),
        imaginary_freq=float(getattr(args, "imaginary_freq", 1.0)),
        tolerance=float(getattr(args, "tolerance", 1e-2)),
        pdiff=float(getattr(args, "pdiff", 2.0)),
        memory=float(getattr(args, "memory", 0.3)),
        mixing=float(getattr(args, "mixing", 0.0)),
        grid=int(getattr(args, "grid", 9)),
        use_pressure=str(getattr(args, "use_pressure", "False")),
        pressure_diag=tuple(float(x) for x in getattr(args, "pressure_diag", [0.0, 0.0, 0.0])),
        symm_acoustic=bool(getattr(args, "symm_acoustic", True)),
    )

    max_cycles = max(int(args.nsteps) + 2, 10)
    submit_idx = 1
    for cycle in range(1, max_cycles + 1):
        print(f"Cycle {cycle:03d}: QSCAILD submit stage started (iteration={submit_idx:03d}).")
        _legacy_run_submit(legacy_dir, engine_dir, submit_idx)
        print(f"Cycle {cycle:03d}: QSCAILD submit stage finished.")
        _legacy_sync_outputs(workdir, legacy_dir)
        score = _legacy_latest_score(legacy_dir)
        conv = _legacy_last_convergence_metrics(legacy_dir)
        _legacy_append_score_hist(workdir, submit_idx, score, conv)
        fe_eV, fe_mev_atom = float("nan"), float("nan")
        try:
            fe_eV, fe_mev_atom = _legacy_compute_cycle_free_energy(
                legacy_dir=legacy_dir,
                top_poscar=top_poscar,
                dim=tuple(dim),
                iteration=submit_idx,
                temperature=float(args.temperature),
                mesh=list(getattr(args, "mesh", [7, 7, 7])),
                symprec=float(getattr(args, "symprec", 1e-5)),
            )
            if np.isfinite(fe_eV):
                _legacy_append_thermo_free_energy(workdir, submit_idx, fe_eV, fe_mev_atom)
        except Exception as e:
            print(f"WARNING: free-energy evaluation failed at iter={submit_idx:04d}: {e}")
        _legacy_print_cycle_summary(
            legacy_dir,
            workdir,
            submit_idx,
            tolerance=float(getattr(args, "tolerance", 1e-2)),
            score=score,
            conv=conv,
            free_energy_eV=fe_eV,
            free_energy_meV_atom=fe_mev_atom,
        )
        finished_after_submit = (legacy_dir / "finished").exists()
        if submit_idx % max(int(getattr(args, "save_every", 5)), 1) == 0:
            fc_ckpt_path, fc_ckpt_changed = _legacy_snapshot_fc(workdir, legacy_dir, submit_idx)
            if not finished_after_submit:
                try:
                    _legacy_export_adp_from_db(
                        workdir=workdir,
                        legacy_dir=legacy_dir,
                        top_poscar=top_poscar,
                        dim=tuple(dim),
                        iteration=submit_idx,
                        symprec=float(getattr(args, "symprec", 1e-5)),
                        projection_axis_frac=getattr(args, "distribution_axis", None),
                    )
                    print(
                        f"Cycle {cycle:03d}: saved ADP/average/distribution outputs "
                        f"(iter={submit_idx:04d})."
                    )
                except Exception as e:
                    print(f"WARNING: failed ADP/average export at iter={submit_idx:04d}: {e}")
            if bool(getattr(args, "plot_bands", True)) and (legacy_dir / "FORCE_CONSTANTS_CURRENT").exists():
                if not fc_ckpt_changed:
                    print(
                        f"Cycle {cycle:03d}: skipping checkpoint band export "
                        f"(iter={submit_idx:04d}, FORCE_CONSTANTS unchanged)."
                    )
                else:
                    prefix = input_poscar_path.stem
                    fc_ckpt = fc_ckpt_path if fc_ckpt_path is not None else (legacy_dir / "FORCE_CONSTANTS_CURRENT")
                    pb_ckpt = _legacy_run_pb_from_fc(
                        workdir=workdir,
                        poscar=top_poscar,
                        dim=tuple(dim),
                        ff=args.ff,
                        device=args.device,
                        output_prefix=f"{prefix}-{submit_idx:04d}",
                        fc_path=fc_ckpt,
                        out_dir_name=f"pb-iter-{submit_idx:04d}-from-qscaild",
                    )
                    _legacy_promote_checkpoint_band_outputs(pb_ckpt, workdir, prefix, submit_idx)
            _legacy_export_sscha_iteration_aliases(
                workdir=workdir,
                input_stem=input_poscar_path.stem,
                iteration=submit_idx,
                temperature=float(args.temperature),
                fc_snapshot=fc_ckpt_path,
            )
        submit_idx += 1
        if finished_after_submit:
            print(f"Cycle {cycle:03d}: finished marker detected after submit stage.")
            break
        n_pending = _legacy_count_to_calc(legacy_dir)
        print(f"Cycle {cycle:03d}: force evaluation stage started ({n_pending} configs).")
        ncalc = _legacy_run_forces(
            legacy_dir,
            args.ff,
            args.device,
            cycle,
            model_path=_resolve_model_path(args.ff, getattr(args, "model", None)),
            modal=getattr(args, "modal", None),
            sequential=bool(getattr(args, "sequential", False)),
            batch_size=getattr(args, "batch_size", None),
            need_stress=(str(getattr(args, "use_pressure", "False")) != "False"),
        )
        print(f"Cycle {cycle:03d}: force evaluation stage finished ({ncalc} configs).")
        if ncalc == 0:
            raise RuntimeError("to_calc was empty before finished was created")
    else:
        raise RuntimeError(f"did not reach finished within max_cycles={max_cycles}")

    _legacy_sync_outputs(workdir, legacy_dir)
    if (workdir / "FORCE_CONSTANTS_CURRENT").exists():
        shutil.copy(workdir / "FORCE_CONSTANTS_CURRENT", workdir / "FORCE_CONSTANTS_QSCAILD_final")
        shutil.copy(workdir / "FORCE_CONSTANTS_CURRENT", workdir / "FORCE_CONSTANTS_SSCHA_final")
        shutil.copy(workdir / "FORCE_CONSTANTS_CURRENT", workdir / "FORCE_CONSTANTS_final")
    # Keep prebuilt pb-equivalent harmonic FC if available.
    if not (workdir / "FORCE_CONSTANTS_harmonic").exists() and not (workdir / "FORCE_CONSTANTS_harmoinc").exists():
        fc_fit1_src = legacy_dir / "FORCE_CONSTANTS_FIT_1"
        if fc_fit1_src.exists():
            shutil.copy(fc_fit1_src, workdir / "FORCE_CONSTANTS_init")
            shutil.copy(fc_fit1_src, workdir / "FORCE_CONSTANTS_harmoinc")
            shutil.copy(fc_fit1_src, workdir / "FORCE_CONSTANTS_harmonic")
    if not (workdir / "FORCE_CONSTANTS_init").exists() and (workdir / "FORCE_CONSTANTS_CURRENT").exists():
        shutil.copy(workdir / "FORCE_CONSTANTS_CURRENT", workdir / "FORCE_CONSTANTS_init")
    if not (workdir / "FORCE_CONSTANTS_harmonic").exists() and (workdir / "FORCE_CONSTANTS_CURRENT").exists():
        shutil.copy(workdir / "FORCE_CONSTANTS_CURRENT", workdir / "FORCE_CONSTANTS_harmonic")
    if not (workdir / "FORCE_CONSTANTS_harmoinc").exists() and (workdir / "FORCE_CONSTANTS_CURRENT").exists():
        shutil.copy(workdir / "FORCE_CONSTANTS_CURRENT", workdir / "FORCE_CONSTANTS_harmoinc")

    if bool(getattr(args, "plot_bands", True)):
        prefix = input_poscar_path.stem
        fc_h = workdir / "FORCE_CONSTANTS_harmonic"
        if not fc_h.exists():
            fc_h = legacy_dir / "FORCE_CONSTANTS_FIT_1"
        if not fc_h.exists():
            fc_h = workdir / "FORCE_CONSTANTS_CURRENT"
        pb_h = _legacy_run_pb_from_fc(
            workdir=workdir,
            poscar=top_poscar,
            dim=tuple(dim),
            ff=args.ff,
            device=args.device,
            output_prefix=f"{prefix}-harmonic",
            fc_path=fc_h,
            out_dir_name="pb-harmonic-from-qscaild",
        )
        _legacy_promote_band_outputs(pb_h, workdir, prefix, "harmonic")
        pb_f = _legacy_run_pb_from_fc(
            workdir=workdir,
            poscar=top_poscar,
            dim=tuple(dim),
            ff=args.ff,
            device=args.device,
            output_prefix=f"{prefix}-final",
            fc_path=workdir / "FORCE_CONSTANTS_CURRENT",
            out_dir_name="pb-final-from-qscaild",
        )
        _legacy_promote_band_outputs(pb_f, workdir, prefix, "final")
        _legacy_export_final_phonopy_inputs(workdir, pb_f, prefix)
        print(f"PB output dirs: {pb_h}, {pb_f}")

    _legacy_plot_score_hist(workdir)
    _legacy_write_sscha_style_convergence(workdir, input_poscar_path.stem)
    _legacy_convert_npy_to_dat(legacy_dir, keep_npy=bool(getattr(args, "save_npy", False)))
    _legacy_convert_npy_to_dat(workdir, keep_npy=bool(getattr(args, "save_npy", False)))
    cache_name = f"mat_rec_ac_2nd_{dim[0]}x{dim[1]}x{dim[2]}.npy"
    cache_top = workdir / cache_name
    if cache_top.exists():
        shutil.move(cache_top, legacy_dir / cache_name)
    print(f"Workdir: {workdir}")
    if (workdir / "finished").exists():
        print(f"Finished: {(workdir / 'finished').read_text().strip()}")
    if (workdir / "FORCE_CONSTANTS_CURRENT").exists():
        print(f"FC: {workdir / 'FORCE_CONSTANTS_CURRENT'}")


def add_qscaild_parser_args(parser):
    from macer.calculator.factory import ALL_SUPPORTED_FFS
    from macer.defaults import DEFAULT_FF, DEFAULT_DEVICE
    from macer.phonopy.sscha import _parse_nconf, _parse_positive_int
    
    general_group = parser.add_argument_group("General & Input")
    general_group.add_argument("-p", "--poscar", required=False, default=None, help="Input crystal structure file (POSCAR).")
    general_group.add_argument("-c", "--cif", required=False, default=None, help="Input CIF file.")
    general_group.add_argument("-f", "--formula", type=str, help="Formula to retrieve from Materials Project (e.g., MgAl2O4)")
    general_group.add_argument("-m", "--mpid", type=str, help="Materials Project ID (e.g., mp-3536)")
    general_group.add_argument("--output-dir", help="Directory to save all output files.")
    general_group.add_argument(
        "--qscaild-dir",
        type=str,
        default=None,
        help="Path to external qscaild source directory. Defaults to ./externals/qscaild-master.",
    )
    general_group.add_argument(
        "--no-auto-install-qscaild",
        dest="auto_install_qscaild",
        action="store_false",
        help="Disable auto-install attempt (git clone) when qscaild source is missing.",
    )
    general_group.add_argument(
        "--qscaild-fetch",
        action="store_true",
        help="Run `git pull --ff-only` on qscaild source before execution.",
    )
    general_group.add_argument("--seed", type=int, help="Random seed for reproducibility.")

    mlff_group = parser.add_argument_group("MLFF Model Settings")
    mlff_group.add_argument("--ff", choices=ALL_SUPPORTED_FFS, default=DEFAULT_FF, help=f"Force field to use (default: {DEFAULT_FF}).")
    mlff_group.add_argument("--model", help="Path to the force field model file.")
    mlff_group.add_argument("--device", default=DEFAULT_DEVICE, choices=["cpu", "mps", "cuda"], help=f"Compute device (default: {DEFAULT_DEVICE}).")
    mlff_group.add_argument("--modal", type=str, default=None, help="Modal for SevenNet model, if required.")
    mlff_group.add_argument(
        "--sequential", "--seq",
        dest="sequential",
        action="store_true",
        help="Force sequential evaluation instead of batch processing. If batch evaluation fails, it will automatically fallback to sequential.",
    )
    mlff_group.add_argument(
        "--batch-size",
        type=_parse_positive_int,
        default=None,
        help="Optional mini-batch size for native batch evaluation (must be >=1).",
    )

    initial_group = parser.add_argument_group("Initial Harmonic FC Settings")
    initial_group.add_argument("--initial-fmax", type=float, default=5e-3, help="Force convergence for initial relaxation (eV/Å).")
    initial_group.add_argument("--initial-isif", type=int, default=3, help="VASP ISIF mode for initial relaxation (default: 3, use 0 to skip).")
    initial_group.add_argument("--dim", type=int, nargs="+", help="Supercell dimension (e.g., '2 2 2').")
    initial_group.add_argument("-l", "--min-length", type=float, default=15.0, help="Minimum supercell length if --dim is not set (Å).")
    initial_group.add_argument("--amplitude", type=float, default=0.03, help="Displacement amplitude for harmonic FC calculation (Å).")
    initial_group.add_argument("--pm", action="store_true", help="Use plus/minus displacements (always enabled).")
    initial_group.add_argument("--nodiag", action="store_true", help="Do not use diagonal displacements.")
    initial_group.add_argument("--symprec", type=float, default=1e-5, help="Symmetry tolerance (Å).")
    initial_group.add_argument("--read-initial-fc", type=str, help="Path to existing FORCE_CONSTANTS to skip initial calculation.")
    initial_group.add_argument("--initial-symmetry-off", dest="initial_use_symmetry", action="store_false", help="Disable FixSymmetry in initial relaxation.")

    ensemble_group = parser.add_argument_group("Reference Ensemble Settings")
    ensemble_group.add_argument("--reference-method", choices=["random", "md"], default="random", help="Method to generate reference ensemble (default: random).")
    ensemble_group.add_argument("--reference-n-samples", type=int, default=200, help=argparse.SUPPRESS)
    ensemble_group.add_argument("--reference-md-nsteps", type=int, default=200, help=argparse.SUPPRESS)
    ensemble_group.add_argument("--reference-md-nequil", type=int, default=100, help=argparse.SUPPRESS)
    ensemble_group.add_argument("--reference-md-tstep", type=float, default=1.0, help=argparse.SUPPRESS)
    ensemble_group.add_argument("--md-thermostat", choices=["nve", "langevin"], default="langevin", help=argparse.SUPPRESS)
    ensemble_group.add_argument("--md-friction", type=float, default=0.01, help=argparse.SUPPRESS)
    ensemble_group.add_argument("--reference-ensemble", help=argparse.SUPPRESS)
    ensemble_group.add_argument("--no-save-reference-ensemble", action="store_true", help=argparse.SUPPRESS)
    ensemble_group.add_argument("--write-xdatcar", action="store_true", help=argparse.SUPPRESS)
    ensemble_group.add_argument("--xdatcar-step", type=int, default=50, help=argparse.SUPPRESS)

    compat_group = parser.add_argument_group("Reweighting / Compatibility Settings")
    compat_group.add_argument("-T", "--temperature", type=float, help="Target temperature in Kelvin.")
    compat_group.add_argument("--num-volumes", type=int, default=1, help=argparse.SUPPRESS)
    compat_group.add_argument("--length-scale", type=float, help=argparse.SUPPRESS)
    compat_group.add_argument("--mesh", type=int, nargs=3, default=[7, 7, 7], help="Q-point mesh for free-energy calculation (default: 7 7 7).")
    compat_group.add_argument("--include-third-order", action="store_true", help="Enable simultaneous fitting of 3rd-order force constants.")
    compat_group.add_argument("--mass", nargs="+", help="Specify atomic masses. Format: Symbol Mass Symbol Mass ...")
    compat_group.add_argument("--gamma-label", type=str, default="GM", help="Label for Gamma point in plots.")
    compat_group.add_argument("--save-every", type=int, default=5, help="Save intermediate FORCE_CONSTANTS every N cycles.")
    compat_group.add_argument("--no-plot-bands", dest="plot_bands", action="store_false", help="Do not plot band structures.")

    scheme_group = parser.add_argument_group("QSCAILD-Style Cycle Settings")
    scheme_group.add_argument("--nconf", type=_parse_nconf, default=10, help="Number of displaced configurations per cycle (default: 10).")
    scheme_group.add_argument("--nsteps", type=int, default=100, help="Maximum number of cycles (default: 100).")
    scheme_group.add_argument("--memory", type=float, default=0.3, help="History fraction used for multi-cycle reweighting fit (default: 0.3).")
    scheme_group.add_argument("--mixing", type=float, default=0.0, help="Linear mixing factor for IFC update (default: 0.0).")
    scheme_group.add_argument("--tolerance", type=float, default=0.01, help="IFC convergence tolerance (default: 0.01).")
    scheme_group.add_argument("--pdiff", type=float, default=1.0, help="Pressure convergence tolerance in kbar (default: 1.0).")
    scheme_group.add_argument("--grid", type=int, default=9, help="Q-grid size for covariance construction (default: 9).")
    scheme_group.add_argument("--use-smalldisp", action="store_true", help="Use small-displacement mode.")
    scheme_group.add_argument("--imaginary-freq", type=float, default=1.0, help="Imaginary-frequency handling parameter in THz.")
    scheme_group.add_argument("--use-pressure", choices=["False", "cubic", "tetragonal", "orthorhombic"], default="False", help="Pressure-driven cell update mode.")
    scheme_group.add_argument("--pressure-diag", nargs=3, type=float, metavar=("PX", "PY", "PZ"), default=[0.0, 0.0, 0.0], help="Target diagonal pressure components in kbar.")
    scheme_group.add_argument("--distribution-axis", nargs=3, type=float, metavar=("A", "B", "C"), help="Fractional direction vector for projected displacement distributions.")
    scheme_group.add_argument("--mat-rec-cache", type=str, help="Path to precomputed mat_rec_ac_2nd.npy to skip symmetry analysis.")
    scheme_group.add_argument("--save-npy", action="store_true", help="Also save binary .npy arrays.")
    scheme_group.add_argument("--dry-run", action="store_true", help="Validate parser/settings and exit before evaluations.")

    parser.set_defaults(func=run_qscaild_workflow)


def add_qscaild_parser(subparsers, aliases=None, command_name="qscaild"):
    from macer import __version__
    from macer.cli.phonopy_main import MACER_LOGO

    parser = subparsers.add_parser(
        command_name,
        aliases=aliases or [],
        help="QSCAILD via external qscaild engine (https://github.com/vanroeke/qscaild)",
        description=MACER_LOGO + f"\nmacer_phonopy qscaild (v{__version__}): Quantum Self-Consistent Ab Initio Lattice Dynamics (QSCAILD) using an external qscaild checkout (https://github.com/vanroeke/qscaild) with macer force evaluations.",
        epilog="""
  # 0) Install external qscaild source once
  git clone https://github.com/vanroeke/qscaild externals/qscaild-master
  #    (or let macer try auto-install on first run)

  # 1) Validate setup only (no expensive force evaluation)
  macer phonopy sscha -p POSCAR -T 300 --dry-run

  # 2) Minimal finite-T run (alias: qscaild)
  macer phonopy qscaild -p POSCAR -T 300 --dim 3 3 3 --ff chgnet

  # 3) Explicit run controls + snapshots every 5 cycles
  macer phonopy sscha -p POSCAR -T 500 --dim 3 3 3 --nconf 10 --nsteps 30 --save-every 5 --ff chgnet

  # 4) Store outputs in a custom directory
  macer phonopy sscha -p POSCAR -T 500 --output-dir ./qscaild-run-500K --ff chgnet

  # 5) Pressure-coupled volume optimization loop
  macer phonopy sscha -p POSCAR -T 500 --optimize-volume --pressure-diag 0 0 0 --pdiff 2.0 --nconf 10 --nsteps 30

  # 6) FC3 fitting + custom mesh
  macer phonopy sscha -p POSCAR -T 300 --include-third-order --mesh 9 9 9 --nconf 20 --nsteps 50

  # 7) Reuse precomputed mat_rec_ac_2nd cache (same dim) to skip symmetry rebuild
  #    Preferred: pass cache path directly
  macer phonopy qscaild -p POSCAR -T 300 --dim 3 3 3 \\
    --mat-rec-cache /path/to/old-run/run-qscaild/mat_rec_ac_2nd_3x3x3.npy

  #    Alternative: copy cache to current directory and run
  cp /path/to/old-run/run-qscaild/mat_rec_ac_2nd_3x3x3.npy ./mat_rec_ac_2nd_3x3x3.npy
  macer phonopy qscaild -p POSCAR -T 300 --dim 3 3 3

  # 8) Control mini-batch size explicitly (must be >= 1)
  macer phonopy qscaild -p POSCAR -T 300 --dim 3 3 3 --batch-size 8

Tip: `--batch-size` must be a positive integer (>=1).
  - Omit `--batch-size` to use backend auto batching.
  - Batch evaluation automatically falls back to sequential mode on failure.
  - Use `--sequential` (alias: `--seq`) to force sequential evaluation.
  - Use smaller values (e.g., 4, 8, 16) when memory is tight.
""",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    general_group = parser.add_argument_group("General & Input")
    general_group.add_argument("-p", "--poscar", required=False, default=None, help="Input crystal structure file (POSCAR).")
    general_group.add_argument("-c", "--cif", required=False, default=None, help="Input CIF file.")
    general_group.add_argument("-f", "--formula", type=str, help="Formula to retrieve from Materials Project (e.g., MgAl2O4)")
    general_group.add_argument("-m", "--mpid", type=str, help="Materials Project ID (e.g., mp-3536)")
    general_group.add_argument("--output-dir", help="Directory to save all output files.")
    general_group.add_argument(
        "--qscaild-dir",
        type=str,
        default=None,
        help="Path to external qscaild source directory. Defaults to ./externals/qscaild-master.",
    )
    general_group.add_argument(
        "--no-auto-install-qscaild",
        dest="auto_install_qscaild",
        action="store_false",
        help="Disable auto-install attempt (git clone) when qscaild source is missing.",
    )
    general_group.add_argument(
        "--qscaild-fetch",
        action="store_true",
        help="Run `git pull --ff-only` on qscaild source before execution.",
    )
    general_group.add_argument("--seed", type=int, help="Random seed for reproducibility.")

    mlff_group = parser.add_argument_group("MLFF Model Settings")
    mlff_group.add_argument("--ff", choices=ALL_SUPPORTED_FFS, default=DEFAULT_FF, help=f"Force field to use (default: {DEFAULT_FF}).")
    mlff_group.add_argument("--model", help="Path to the force field model file.")
    mlff_group.add_argument("--device", default=DEFAULT_DEVICE, choices=["cpu", "mps", "cuda"], help=f"Compute device (default: {DEFAULT_DEVICE}).")
    mlff_group.add_argument("--modal", type=str, default=None, help="Modal for SevenNet model, if required.")

    initial_group = parser.add_argument_group("Initial Harmonic FC Settings")
    initial_group.add_argument("--initial-fmax", type=float, default=5e-3, help="Force convergence for initial relaxation (eV/Å).")
    initial_group.add_argument("--initial-isif", type=int, default=3, help="VASP ISIF mode for initial relaxation (default: 3, use 0 to skip).")
    initial_group.add_argument("--dim", type=int, nargs="+", help="Supercell dimension (e.g., '2 2 2').")
    initial_group.add_argument("-l", "--min-length", type=float, default=15.0, help="Minimum supercell length if --dim is not set (Å).")
    initial_group.add_argument("--amplitude", type=float, default=0.03, help="Displacement amplitude for harmonic FC calculation (Å).")
    initial_group.add_argument("--pm", action="store_true", help="Use plus/minus displacements (always enabled).")
    initial_group.add_argument("--nodiag", action="store_true", help="Do not use diagonal displacements.")
    initial_group.add_argument("--symprec", type=float, default=1e-5, help="Symmetry tolerance (Å).")
    initial_group.add_argument("--read-initial-fc", type=str, help="Path to existing FORCE_CONSTANTS to skip initial calculation.")
    initial_group.add_argument("--initial-symmetry-off", dest="initial_use_symmetry", action="store_false", help="Disable FixSymmetry in initial relaxation.")

    ensemble_group = parser.add_argument_group("Reference Ensemble Settings")
    ensemble_group.add_argument("--reference-method", choices=["random", "md"], default="random", help="Method to generate reference ensemble (default: random).")
    ensemble_group.add_argument("--reference-n-samples", type=int, default=200, help=argparse.SUPPRESS)
    ensemble_group.add_argument("--reference-md-nsteps", type=int, default=200, help=argparse.SUPPRESS)
    ensemble_group.add_argument("--reference-md-nequil", type=int, default=100, help=argparse.SUPPRESS)
    ensemble_group.add_argument("--reference-md-tstep", type=float, default=1.0, help=argparse.SUPPRESS)
    ensemble_group.add_argument("--md-thermostat", choices=["nve", "langevin"], default="langevin", help=argparse.SUPPRESS)
    ensemble_group.add_argument("--md-friction", type=float, default=0.01, help=argparse.SUPPRESS)
    ensemble_group.add_argument("--reference-ensemble", help=argparse.SUPPRESS)
    ensemble_group.add_argument("--no-save-reference-ensemble", action="store_true", help=argparse.SUPPRESS)
    ensemble_group.add_argument("--write-xdatcar", action="store_true", help=argparse.SUPPRESS)
    ensemble_group.add_argument("--xdatcar-step", type=int, default=50, help=argparse.SUPPRESS)

    compat_group = parser.add_argument_group("Reweighting / Compatibility Settings")
    compat_group.add_argument("-T", "--temperature", type=float, help="Target temperature in Kelvin.")
    compat_group.add_argument("--max-iter", type=int, default=200, help=argparse.SUPPRESS)
    compat_group.add_argument(
        "--max-regen",
        type=int,
        default=200,
        help="Maximum ESS-regeneration attempts when collapse handling is enabled (default: 200).",
    )
    compat_group.add_argument(
        "--ess-collapse-ratio",
        type=float,
        default=None,
        help="Enable ESS collapse handling if ESS < ratio * snapshots (disabled by default).",
    )
    compat_group.add_argument(
        "--ess-collapse-mode",
        choices=["soft", "hard"],
        default="soft",
        help="ESS collapse handling mode: soft keeps recent history, hard keeps latest cycle only (default: soft).",
    )
    compat_group.add_argument("--free-energy-conv", type=float, default=0.1, help=argparse.SUPPRESS)
    compat_group.add_argument("--mesh", type=int, nargs=3, default=[7, 7, 7], help="Q-point mesh for free-energy calculation (default: 7 7 7).")
    compat_group.add_argument("--fc-mixing-alpha", type=float, default=0.5, help=argparse.SUPPRESS)
    compat_group.add_argument("--include-third-order", action="store_true", help="Enable simultaneous fitting of 3rd-order force constants.")
    compat_group.add_argument("--mass", nargs="+", help="Specify atomic masses. Format: Symbol Mass Symbol Mass ...")
    compat_group.add_argument(
        "--optimize-volume",
        action="store_true",
        help="Enable pressure-coupled volume optimization loop (default mode: cubic).",
    )
    compat_group.add_argument("--max-volume-iter", type=int, default=10, help=argparse.SUPPRESS)
    compat_group.add_argument("--gamma-label", type=str, default="GM", help="Label for Gamma point in band plots.")
    compat_group.add_argument("--save-every", type=int, default=5, help="Save intermediate FORCE_CONSTANTS every N cycles (default: 5).")
    compat_group.add_argument("--no-plot-bands", dest="plot_bands", action="store_false", help="Do not plot band structures.")

    qscaild_group = parser.add_argument_group("QSCAILD Settings")
    qscaild_group.add_argument("--nconf", type=int, default=10, help="Number of displaced configurations per cycle (default: 10).")
    qscaild_group.add_argument("--nsteps", type=int, default=30, help="Maximum number of QSCAILD cycles (default: 30).")
    qscaild_group.add_argument("--nfits", dest="nsteps", type=int, help=argparse.SUPPRESS)
    qscaild_group.add_argument("--memory", type=float, default=0.3, help="History fraction used for multi-cycle reweighting fit (default: 0.3).")
    qscaild_group.add_argument("--mixing", type=float, default=0.0, help="Linear mixing factor for IFC update (default: 0.0).")
    qscaild_group.add_argument("--tolerance", type=float, default=1e-2, help="IFC convergence tolerance (default: 1e-2).")
    qscaild_group.add_argument("--pdiff", type=float, default=2.0, help="Pressure convergence tolerance in kbar (default: 2.0).")
    qscaild_group.add_argument("--grid", type=int, default=9, help="Q-grid size for covariance construction (default: 9).")
    qscaild_group.add_argument(
        "--symm-acoustic",
        dest="symm_acoustic",
        action="store_true",
        default=None,
        help="Enforce acoustic sum rule in symmetry reduction.",
    )
    qscaild_group.add_argument(
        "--no-symm-acoustic",
        dest="symm_acoustic",
        action="store_false",
        help="Disable acoustic-sum-rule reduction during symmetry matrix construction."
             " If neither flag is set, single-element systems default to disabled.",
    )
    qscaild_group.add_argument("--use-smalldisp", action="store_true", help="Use small-displacement mode.")
    qscaild_group.add_argument("--imaginary-freq", type=float, default=1.0, help="Imaginary-frequency handling parameter in THz.")
    qscaild_group.add_argument(
        "--use-pressure",
        choices=["False", "cubic", "tetragonal", "orthorhombic"],
        default="orthorhombic",
        help="Pressure-driven cell update mode (advanced override for --optimize-volume).",
    )
    qscaild_group.add_argument("--pressure-diag", type=float, nargs=3, metavar=("PX", "PY", "PZ"), default=[0.0, 0.0, 0.0], help="Target diagonal pressure components in kbar.")
    qscaild_group.add_argument(
        "--distribution-axis",
        type=float,
        nargs=3,
        metavar=("A", "B", "C"),
        default=None,
        help="Fractional direction vector for projected displacement distributions on primitive atoms (e.g., 1 2 1).",
    )
    qscaild_group.add_argument(
        "--save-npy",
        action="store_true",
        help="Also save binary .npy arrays (default is dat-only outputs).",
    )
    qscaild_group.add_argument(
        "--mat-rec-cache",
        type=str,
        default=None,
        help="Path to a precomputed mat_rec_ac_2nd_*.npy cache file to reuse.",
    )
    qscaild_group.add_argument("--dry-run", action="store_true", help="Validate parser/settings and exit before expensive evaluations.")
    parser.set_defaults(plot_bands=True, auto_install_qscaild=True)
    parser.set_defaults(func=run_qscaild_workflow)
    return parser
