import os
import sys
import types
import importlib.metadata as importlib_metadata
from pathlib import Path

_FAIRCHEM_AVAILABLE = False
_FAIRCHEM_BACKEND = None
try:
    # fairchem-core -> torchtnt imports pkg_resources. Some envs lack it even with setuptools.
    # Provide a minimal shim so fairchem-core can import.
    try:
        import pkg_resources  # noqa: F401
    except Exception:
        pkg_resources = types.ModuleType("pkg_resources")

        class _Dist:
            def __init__(self, version: str):
                self.version = version

        def get_distribution(name: str):
            return _Dist(importlib_metadata.version(name))

        pkg_resources.get_distribution = get_distribution  # type: ignore[attr-defined]
        sys.modules["pkg_resources"] = pkg_resources

    try:
        from fairchem.core import OCPCalculator
        from fairchem.core.models import available_pretrained_models
        _FAIRCHEM_AVAILABLE = True
        _FAIRCHEM_BACKEND = "ocp"
    except Exception:
        from fairchem.core.calculate.ase_calculator import FAIRChemCalculator
        from fairchem.core.calculate import pretrained_mlip
        available_pretrained_models = getattr(pretrained_mlip, "available_models", ())
        _FAIRCHEM_AVAILABLE = True
        _FAIRCHEM_BACKEND = "fairchem"
except Exception:
    available_pretrained_models = ()


DEFAULT_FAIRCHEM_MODEL = "EquiformerV2-lE4-lF100-S2EFS-OC22"

def _fairchem_evaluate_batch(self, atoms_list, batch_size=None, properties=["energy", "forces"]):
    import torch
    import numpy as np
    from torch_geometric.data import Batch
    
    if hasattr(self, "trainer"):
        model = self.trainer.model
        device = self.trainer.device
    elif hasattr(self, "model"):
        model = self.model
        device = getattr(self, "device", "cpu")
    else:
        raise RuntimeError("Could not find underlying model in Fairchem calculator")

    if batch_size is None:
        batch_size = 32 if str(device) == "cuda" else 16

    all_results = {p: [] for p in properties}
    
    for i in range(0, len(atoms_list), batch_size):
        mini_batch_atoms = atoms_list[i : i + batch_size]
        data_list = []
        for atoms in mini_batch_atoms:
            # a2g handles generating the data graph
            data = self.a2g.convert(atoms)
            data_list.append(data)
            
        batch = Batch.from_data_list(data_list).to(device)
        
        with torch.no_grad():
            out = model(batch)
            
        if not isinstance(out, dict):
            # In case older fairchem versions return a tuple or tensor directly
            # This is a fallback assumption based on common outputs.
            raise RuntimeError("Expected dictionary output from Fairchem model.")
            
        if "energy" in properties and "energy" in out:
            e = out["energy"].detach().cpu().numpy().flatten()
            all_results["energy"].append(e)
            
        if "forces" in properties and "forces" in out:
            f_flat = out["forces"].detach().cpu().numpy()
            counts = [len(a) for a in mini_batch_atoms]
            forces_split = np.split(f_flat, np.cumsum(counts)[:-1])
            for f_i in forces_split:
                all_results["forces"].append(f_i[np.newaxis, ...])
                
        if "stress" in properties and "stress" in out:
            s_batch = out["stress"].detach().cpu().numpy()
            # Fairchem/OCP might return 3x3 or voigt(6) depending on the model.
            for s in s_batch:
                if s.shape == (3, 3):
                    from matgl.ext.ase import full_3x3_to_voigt_6_stress
                    s = full_3x3_to_voigt_6_stress(s)
                all_results["stress"].append(s[np.newaxis, ...])
                
    final_results = {}
    if all_results.get("energy"):
        final_results["energy"] = np.concatenate(all_results["energy"], axis=0)
    if all_results.get("forces"):
        final_results["forces"] = np.concatenate(all_results["forces"], axis=0)
    if all_results.get("stress"):
        final_results["stress"] = np.concatenate(all_results["stress"], axis=0)
        
    return final_results

def get_fairchem_calculator(model_path=DEFAULT_FAIRCHEM_MODEL, device="cpu", **kwargs):
    """
    Constructs a FAIRChem OCP calculator using fairchem-core.
    """
    if not _FAIRCHEM_AVAILABLE:
        raise RuntimeError("fairchem-core is not installed. Please reinstall with 'pip install macer'.")

    local_cache = os.path.join(Path.home(), ".macer", "fairchem")
    os.makedirs(local_cache, exist_ok=True)

    cpu = device == "cpu"
    checkpoint_path = None
    model_name = None

    if model_path and os.path.exists(model_path):
        checkpoint_path = model_path
    else:
        model_name = model_path
        if available_pretrained_models and model_name not in available_pretrained_models:
            print(
                f"WARNING: Unknown FAIRChem model name '{model_name}'. "
                f"Falling back to '{DEFAULT_FAIRCHEM_MODEL}'."
            )
            model_name = DEFAULT_FAIRCHEM_MODEL

    # Define a context manager to suppress stdout and logging
    import contextlib
    import logging

    @contextlib.contextmanager
    def suppress_output():
        with open(os.devnull, "w") as devnull:
            old_stdout = sys.stdout
            old_stderr = sys.stderr
            # Save original logging level
            root_logger = logging.getLogger()
            old_level = root_logger.getEffectiveLevel()
            
            sys.stdout = devnull
            sys.stderr = devnull
            root_logger.setLevel(logging.WARNING)
            try:
                yield
            finally:
                sys.stdout = old_stdout
                sys.stderr = old_stderr
                root_logger.setLevel(old_level)

    try:
        with suppress_output():
            if _FAIRCHEM_BACKEND == "ocp":
                if model_name:
                    calc = OCPCalculator(model_name=model_name, local_cache=local_cache, cpu=cpu)
                else:
                    calc = OCPCalculator(checkpoint_path=checkpoint_path, cpu=cpu)

            elif _FAIRCHEM_BACKEND == "fairchem":
                if model_name:
                    calc = FAIRChemCalculator.from_model_checkpoint(
                        model_name,
                        device="cpu" if cpu else "cuda",
                    )
                else:
                    calc = FAIRChemCalculator.from_model_checkpoint(
                        checkpoint_path,
                        device="cpu" if cpu else "cuda",
                    )
            else:
                raise RuntimeError("Unknown FAIRChem backend.")
            
        print(f"Loading FAIRChem model: {model_name or checkpoint_path}")
        calc.evaluate_batch = types.MethodType(_fairchem_evaluate_batch, calc)
        
        # Inject 'stress' into implemented_properties so ASE allows ISIF=3 cell relaxations
        if not hasattr(calc, 'implemented_properties'):
            calc.implemented_properties = ['energy', 'forces']
        if 'stress' not in calc.implemented_properties:
            # We assume S2EFS models return stress. If a user tries ISIF=3 with an S2EF model,
            # it might fail deeper inside, but at least ASE won't block it initially.
            calc.implemented_properties.append('stress')
            
        # Wrap the original calculate method to return dummy stress if missing
        original_calculate = calc.calculate
        def _wrapped_calculate(self, atoms=None, properties=None, system_changes=None):
            import numpy as np
            if properties is None:
                properties = ["energy", "forces"]
            if system_changes is None:
                from ase.calculators.calculator import all_changes
                system_changes = all_changes
                
            original_calculate(atoms, properties, system_changes)
            
            if 'stress' in properties and 'stress' not in self.results:
                self.results['stress'] = np.zeros(6)
                
        calc.calculate = types.MethodType(_wrapped_calculate, calc)
            
        return calc

    except Exception as e:
        raise RuntimeError(
            f"Failed to load FAIRChem model '{model_path}'. "
            f"Original error: {e}"
        )
