
from ase.calculators.lj import LennardJones
from ase.units import Hartree, Bohr

# Default parameters matching pimd.2.7.1/examples/Ar/mm_nvt/mm.dat (atomic units converted to ASE units)
DEFAULT_EPSILON = 0.00037928 * Hartree
DEFAULT_SIGMA = 6.43451699 * Bohr

def get_lj_calculator(epsilon: float = DEFAULT_EPSILON, sigma: float = DEFAULT_SIGMA, **kwargs):
    """
    Returns an ASE LennardJones calculator.
    kwargs should contain 'epsilon' and 'sigma' in ASE units (eV, Angstrom).
    Defaults to Argon parameters from PIMD example if not provided.

    Note: The units here are eV and Angstrom, matching ASE conventions.
    """
    return LennardJones(epsilon=epsilon, sigma=sigma, **kwargs)
