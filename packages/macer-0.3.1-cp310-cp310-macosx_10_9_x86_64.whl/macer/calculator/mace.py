import os
import sys
from pathlib import Path

_MACE_AVAILABLE = False
try:
    # Prioritize bundled MACE and e3nn_legacy to ensure compatibility
    try:
        from macer.externals import mace_bundled as mace
        # Ensure it's globally available as 'mace' for torch.load compatibility
        if "mace" not in sys.modules:
            sys.modules["mace"] = mace
        from macer.externals.mace_bundled.calculators import MACECalculator, mace_mp
        # Also need e3nn_legacy as e3nn
        import macer.externals.e3nn_legacy as e3nn
        if "e3nn" not in sys.modules:
            sys.modules["e3nn"] = e3nn
        print("INFO: Using bundled MACE and e3nn_legacy.")
    except ImportError:
        import mace
        from mace.calculators import MACECalculator, mace_mp
        print("INFO: Bundled MACE not found, using system mace.")
    
    _MACE_AVAILABLE = True
except Exception as e:
    print(f"DEBUG: MACE initialization error: {e}")
    pass

from macer.defaults import DEFAULT_MODELS, _macer_root, resolve_model_path
from macer.utils.model_manager import ensure_model, print_model_help

class MacerMACECalculator(MACECalculator):
    """MACE Calculator with Batch Evaluation support."""
    def evaluate_batch(self, atoms_list, batch_size=None, properties=["energy", "forces"]):
        import torch
        import numpy as np
        # Native MACE data tools
        try:
            from mace.data import AtomicData, config_from_atoms
            from mace.tools.torch_geometric import Batch
        except ImportError:
            from macer.externals.mace_bundled.data import AtomicData, config_from_atoms
            from macer.externals.mace_bundled.tools.torch_geometric import Batch
            
        if batch_size is None:
            batch_size = 64 if str(self.device) == "cuda" else 16
                
        all_results = {p: [] for p in properties}
        
        # Process in mini-batches
        for i in range(0, len(atoms_list), batch_size):
            mini_batch = atoms_list[i : i + batch_size]
            
            # 1. Convert ASE Atoms to MACE AtomicData via Configuration
            data_list = []
            for at in mini_batch:
                config = config_from_atoms(at)
                data = AtomicData.from_config(config, z_table=self.z_table, cutoff=float(self.r_max))
                data_list.append(data)
            
            # 2. Batch them together
            batch_data = Batch.from_data_list(data_list).to(self.device)
            
            # MACE needs positions to have gradients for force calculation
            if "forces" in properties:
                batch_data.positions.requires_grad = True
            
            # Support ensemble models (MACE uses self.models list)
            # Remove torch.no_grad() because forces require gradients
            all_outs = [m(batch_data.to_dict(), compute_stress="stress" in properties) for m in self.models]
            
            # Average results from all models in the ensemble
            out = {}
            if "energy" in properties:
                out["energy"] = torch.stack([o["energy"] for o in all_outs]).mean(dim=0)
            if "forces" in properties:
                out["forces"] = torch.stack([o["forces"] for o in all_outs]).mean(dim=0)
            if "stress" in properties and "stress" in all_outs[0]:
                out["stress"] = torch.stack([o["stress"] for o in all_outs]).mean(dim=0)
                
            if "energy" in properties:
                all_results["energy"].append(out["energy"].detach().cpu().numpy())
            if "forces" in properties:
                f_flat = out["forces"].detach().cpu().numpy()
                n_atoms = len(mini_batch[0])
                all_results["forces"].append(f_flat.reshape(-1, n_atoms, 3))
            if "stress" in properties and "stress" in out:
                all_results["stress"].append(out["stress"].detach().cpu().numpy())

        # Combine mini-batches
        final_results = {}
        for p in properties:
            if all_results[p]:
                final_results[p] = np.concatenate(all_results[p], axis=0)
                
        return final_results

def get_mace_calculator(model_paths, device="cpu", **kwargs):
    """Construct MACE calculator (use float32 for MPS compatibility)."""
    if not _MACE_AVAILABLE:
        raise RuntimeError("MACE related libraries are not installed. Please reinstall with 'pip install macer'.")

    # ... (MPS patch logic) ...
    if device == "mps":
        import torch
        # --- MPS Compatibility Patch (Reinforced) ---
        if not hasattr(torch.Tensor, "_orig_double_macer_patched"):
            print("INFO: Applying reinforced MPS float64 -> float32 patch...")
            torch.Tensor._orig_double_macer_patched = torch.Tensor.double
            torch.Tensor._orig_to_macer_patched = torch.Tensor.to
            
            def mps_safe_double(self):
                if "mps" in str(self.device):
                    return self.float()
                return torch.Tensor._orig_double_macer_patched(self)
            
            def mps_safe_to(self, *args, **kwargs):
                # Check for float64 in args or kwargs
                new_args = list(args)
                if len(args) > 0 and args[0] is torch.float64:
                    if "mps" in str(self.device):
                        new_args[0] = torch.float32
                
                if kwargs.get("dtype") is torch.float64:
                    if "mps" in str(self.device) or "mps" in str(kwargs.get("device", "")):
                        kwargs["dtype"] = torch.float32
                
                return torch.Tensor._orig_to_macer_patched(self, *tuple(new_args), **kwargs)

            torch.Tensor.double = mps_safe_double
            torch.Tensor.to = mps_safe_to
            print("INFO: MPS patch applied successfully.")

    dtype = "float32" if device == "mps" else "float64"

    # Determine the default MACE model path from DEFAULT_MODELS
    default_mace_model_name = DEFAULT_MODELS.get("mace")

    # If no model path is explicitly provided via --model argument (model_paths is [None])
    if not model_paths or (len(model_paths) == 1 and model_paths[0] is None):
        if default_mace_model_name:
            # Check and Provision
            ensure_model("mace", default_mace_model_name)
            default_mace_model_path = resolve_model_path(default_mace_model_name)
            # Use the model specified in default-model.yaml
            print(f"No specific MACE model path provided; using default: {default_mace_model_path}")
            actual_model_paths = [default_mace_model_path]
        else:
            # Fallback to mace_mp "small" if no default is specified in default-model.yaml
            print("No specific MACE model path provided and no default in default-model.yaml; using `mace_mp` 'small' model.")
            res = mace_mp(
                model="small",
                device=device,
                default_dtype=dtype
            )
            # Safeguard: handle unexpected returns from mace_mp
            if isinstance(res, (tuple, list)):
                model_obj = res[0]
            else:
                model_obj = res
            
            # Re-wrap system calculator to support evaluate_batch
            if not hasattr(model_obj, "evaluate_batch"):
                model_obj.__class__ = MacerMACECalculator
            return model_obj
    else:
        # If a specific model path is provided via --model argument
        actual_model_paths = []
        for p in model_paths:
            if p is None: continue
            
            # Check existence first
            if not os.path.exists(p):
                basename = os.path.basename(p)
                provisioned = ensure_model("mace", basename)
                if provisioned:
                    p = provisioned
                else:
                    print_model_help("mace")
                    raise FileNotFoundError(f"Model file not found: {p}")
            
            if not os.path.isabs(p):
                p = resolve_model_path(p)
            actual_model_paths.append(p)
            
        if not actual_model_paths:
            raise ValueError("No valid MACE model path provided.")

    calc = MacerMACECalculator(
        model_paths=actual_model_paths,
        device=device,
        default_dtype=dtype,
    )
    
    # Final check: Ensure we return a single calculator object, not a tuple
    if isinstance(calc, (tuple, list)):
        return calc[0]
    return calc
