import os
import sys
from importlib.util import find_spec
from unittest.mock import MagicMock

from macer.defaults import resolve_model_path

def get_m3gnet_calculator(model_path=None, device='cpu', elements=None, **kwargs):
    if find_spec("matgl") is None:
        raise RuntimeError('M3GNet (matgl) is not installed. Please reinstall with "pip install macer".')

    # Ensure DGL backend for M3GNet models before importing matgl
    os.environ.setdefault("MATGL_BACKEND", "DGL")

    # On some systems (e.g. macOS with Torch 2.4+),
    # DGL / Graphbolt might fail to load some libraries.
    # We try to mock dgl.graphbolt if it's the culprit.
    try:
        sys.modules.setdefault('dgl.graphbolt', MagicMock())
    except Exception:
        pass

    import matgl
    # Compatibility shim: older ASE may not expose ExpCellFilter in ase.constraints
    try:
        from ase.constraints import ExpCellFilter  # noqa: F401
    except Exception:
        try:
            from ase.filters import ExpCellFilter  # noqa: F401
            import ase.constraints as _ase_constraints
            _ase_constraints.ExpCellFilter = ExpCellFilter
        except Exception:
            raise RuntimeError(
                "ASE ExpCellFilter not available. Please upgrade ASE to a newer version "
                "or install a version that provides ExpCellFilter."
            )
    from matgl.ext.ase import PESCalculator

    try:
        if hasattr(matgl, "set_backend"):
            matgl.set_backend("DGL")
    except Exception:
        pass

    class MacerM3GNetCalculator(PESCalculator):
        """M3GNet Calculator with Batch Evaluation support via DGL."""
        def evaluate_batch(self, atoms_list, batch_size=None, properties=["energy", "forces"]):
            import dgl
            import torch
            import numpy as np
            from matgl.ext._ase_dgl import Atoms2Graph
            
            # Safely determine the device
            try:
                device = next(self.potential.parameters()).device
            except Exception:
                device = torch.device("cpu")
                
            if batch_size is None:
                batch_size = 32 if str(device) == "cuda" else 16
            
            # Setup converter
            element_types = self.element_types
            cutoff = self.cutoff
            converter = Atoms2Graph(element_types, cutoff)
            
            all_results = {p: [] for p in properties}
            
            for i in range(0, len(atoms_list), batch_size):
                mini_batch_atoms = atoms_list[i : i + batch_size]
                
                graphs = []
                lattices = []
                states = []
                
                for atoms in mini_batch_atoms:
                    g, lattice, state_attr = converter.get_graph(atoms)
                    graphs.append(g)
                    
                    lat_t = torch.tensor(lattice, dtype=torch.float32)
                    if lat_t.dim() == 3 and lat_t.shape[0] == 1:
                        lat_t = lat_t.squeeze(0)
                    lattices.append(lat_t)
                    
                    s_attr = self.state_attr if self.state_attr is not None else state_attr
                    s_attr_t = torch.tensor(s_attr, dtype=torch.float32)
                    if s_attr_t.dim() >= 2 and s_attr_t.shape[0] == 1:
                        s_attr_t = s_attr_t.squeeze(0)
                    states.append(s_attr_t)
                
                # Batch DGL graphs and stack tensors
                batched_graph = dgl.batch(graphs).to(device)
                batched_lattice = torch.stack(lattices).to(device)
                batched_state = torch.stack(states).to(device)
                
                # Evaluate Potential
                # matgl.models.PES handles requires_grad internally for force/stress
                calc_result = self.potential(batched_graph, batched_lattice, batched_state)
                # calc_result usually: (energies, forces, stresses, hessian, magmoms)
                
                if "energy" in properties:
                    all_results["energy"].append(calc_result[0].detach().cpu().numpy().flatten())
                    
                if "forces" in properties:
                    # forces shape: (Total_Atoms_in_batch, 3) -> split by n_nodes
                    n_nodes = batched_graph.batch_num_nodes().cpu().numpy()
                    f_flat = calc_result[1].detach().cpu().numpy()
                    forces_split = np.split(f_flat, np.cumsum(n_nodes)[:-1])
                    for f_i in forces_split:
                        all_results["forces"].append(f_i[np.newaxis, ...])
                        
                if "stress" in properties:
                    from matgl.ext.ase import full_3x3_to_voigt_6_stress
                    s_raw = calc_result[2].detach().cpu().numpy()
                    s_list = []
                    for s in s_raw:
                        if self.use_voigt:
                            s_list.append(full_3x3_to_voigt_6_stress(s) * self.stress_weight)
                        else:
                            s_list.append(s * self.stress_weight)
                    all_results["stress"].extend(s_list)

            # Combine mini-batch results
            final_results = {}
            if all_results.get("energy"):
                final_results["energy"] = np.concatenate(all_results["energy"], axis=0)
            if all_results.get("forces"):
                final_results["forces"] = np.concatenate(all_results["forces"], axis=0)
            if all_results.get("stress"):
                final_results["stress"] = np.array(all_results["stress"])
                
            return final_results

    if model_path is None:
        # Use the known M3GNet PES model that includes Zn (and most elements).
        model_candidates = ["M3GNet-MP-2021.2.8-PES"]
    else:
        # Check if it's a known pretrained name or a local path
        resolved = resolve_model_path(model_path)
        if resolved and resolved != model_path:
             model_path = resolved

    last_err = None
    elements = set(elements or [])
    if model_path is None:
        for name in model_candidates:
            try:
                potential = matgl.load_model(name)
                if elements:
                    model_elements = set(getattr(potential.model, "element_types", []))
                    if not elements.issubset(model_elements):
                        last_err = KeyError(f"Missing elements in model '{name}': {sorted(elements - model_elements)}")
                        continue
                print(f"INFO: Using M3GNet model: {name}")
                return MacerM3GNetCalculator(potential=potential)
            except Exception as e:
                last_err = e
    else:
        try:
            potential = matgl.load_model(model_path)
            if elements:
                model_elements = set(getattr(potential.model, "element_types", []))
                if not elements.issubset(model_elements):
                    missing = sorted(elements - model_elements)
                    raise RuntimeError(
                        f"M3GNet model '{model_path}' does not support elements: {missing}. "
                        "Please choose a different pretrained model via --model."
                    )
            return MacerM3GNetCalculator(potential=potential)
        except Exception as e:
            last_err = e

    # Final fallback: try torch.hub universal potential
    try:
        import torch
        potential = torch.hub.load("materialsvirtuallab/matgl", "m3gnet_universal_potential")
        return MacerM3GNetCalculator(potential=potential)
    except Exception as e:
        last_err = e

    raise RuntimeError(
        "Failed to load M3GNet model. Ensure DGL backend is set "
        "and clear any stale cache via `python -c 'import matgl; matgl.clear_cache()'`. "
        "If you are on matgl>=2.x, the default pretrained model names may have changed. "
        "Consider passing a valid model name via `--model` or setting MATGL_BACKEND=DGL. "
        f"Original error: {last_err}"
    )
