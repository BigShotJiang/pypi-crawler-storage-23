"""
Macer: Machine-learning accelerated Atomic Computational Environment for automated Research workflows
Copyright (c) 2025 The Macer Package Authors
Author: Soungmin Bae <soungminbae@gmail.com>
License: MIT
"""

import importlib
from importlib.util import find_spec

# Mapping of force field names to their required python packages
# This allows checking availability without importing the package
FF_DEPENDENCIES = {
    "mace": "mace",
    "sevennet": "sevenn",
    "chgnet": "chgnet",
    "m3gnet": "matgl",
    "allegro": "nequip", # commonly nequip or allegro package
    "mattersim": "mattersim",
    "orb": "orb_models",
    "fairchem": "fairchem",
    "emt": "ase",
    "lj": "ase",
}

ALL_SUPPORTED_FFS = list(FF_DEPENDENCIES.keys())

def is_package_available(package_name):
    """Checks if a package is installed without importing it."""
    try:
        if package_name == "ase": return True # ase is required dependency
        return find_spec(package_name) is not None
    except ImportError:
        return False
    except Exception:
        # Handle cases where find_spec might crash on some environments
        return False

def get_available_ffs():
    """
    Returns a list of currently installed (available) force fields,
    with a preferred order for defaults. Uses lightweight checks.
    """
    available_ffs = []
    
    # Define the preferred order
    preferred_order = ["mattersim", "mace", "sevennet", "orb", "fairchem"]
    
    # Check preferred first
    for ff in preferred_order:
        if ff in FF_DEPENDENCIES and is_package_available(FF_DEPENDENCIES[ff]):
            available_ffs.append(ff)
            
    # Check others
    for ff in ALL_SUPPORTED_FFS:
        if ff not in available_ffs:
            if is_package_available(FF_DEPENDENCIES[ff]):
                available_ffs.append(ff)
                
    return available_ffs

def get_calculator(ff_name: str, **kwargs):
    """
    Creates an ASE Calculator instance for the given force field name.
    """
    # Import locally to avoid startup cost
    if ff_name == "mace":
        from .mace import get_mace_calculator as func
    elif ff_name == "sevennet":
        from .sevennet import get_sevennet_calculator as func
    elif ff_name == "chgnet":
        from .chgnet import get_chgnet_calculator as func
    elif ff_name == "m3gnet":
        from .m3gnet import get_m3gnet_calculator as func
    elif ff_name == "allegro":
        from .allegro import get_allegro_calculator as func
    elif ff_name == "mattersim":
        from .mattersim import get_mattersim_calculator as func
    elif ff_name == "orb":
        from .orb import get_orb_calculator as func
    elif ff_name == "fairchem":
        from .fairchem import get_fairchem_calculator as func
    elif ff_name == "emt":
        from .emt import get_emt_calculator as func
    elif ff_name == "lj":
        from .lj import get_lj_calculator as func
    else:
        raise ValueError(f"Unsupported force field: {ff_name}. Supported: {ALL_SUPPORTED_FFS}")
        
    return func(**kwargs)


def evaluate_batch(calculator, atoms_list, batch_size=None, properties=["energy", "forces"], verbose=True):
    """
    Evaluates a list of Atoms using batch processing if supported by the calculator.
    Handles inhomogeneous atom counts by grouping them.
    """
    import numpy as np
    import time
    
    if not atoms_list:
        return {}

    # 1. Print Info once at the beginning
    if hasattr(calculator, "evaluate_batch"):
        if verbose:
            print(f"INFO: Using Native Batch Evaluation ({type(calculator).__name__})")
    else:
        if verbose:
            print(f"DEBUG: evaluate_batch not found in {type(calculator)}. Falling back to sequential.")
        return evaluate_sequential(calculator, atoms_list, properties=properties, verbose=verbose)

    start_time = time.perf_counter()

    # Group by atom count to ensure homogeneous batches for models that require it
    grouped_atoms = {}
    original_indices = {}
    for i, atoms in enumerate(atoms_list):
        natoms = len(atoms)
        if natoms not in grouped_atoms:
            grouped_atoms[natoms] = []
            original_indices[natoms] = []
        grouped_atoms[natoms].append(atoms)
        original_indices[natoms].append(i)

    # Process each homogeneous group
    all_results = {p: [None] * len(atoms_list) for p in properties}
    
    for natoms, subset_atoms in grouped_atoms.items():
        # Directly call the calculator's evaluate_batch for each group
        subset_res = calculator.evaluate_batch(subset_atoms, batch_size=batch_size, properties=properties)
        
        # Map results back to original order
        indices = original_indices[natoms]
        for p in properties:
            if p in subset_res:
                for j, idx in enumerate(indices):
                    all_results[p][idx] = subset_res[p][j]

    # Combine results into final arrays
    final_results = {}
    for p in properties:
        try:
            final_results[p] = np.array(all_results[p])
        except ValueError:
            # Handle ragged arrays (e.g. different number of atoms)
            final_results[p] = np.array(all_results[p], dtype=object)

    end_time = time.perf_counter()
    elapsed = end_time - start_time
    if verbose:
        print(f"  Batch Job: {len(atoms_list)} structures calculated in {elapsed:.3f} seconds.")
            
    return final_results


def _evaluate_homogeneous_batch(calculator, atoms_list, batch_size, properties):
    """Legacy helper, no longer used by evaluate_batch but kept for internal compatibility if needed."""
    return calculator.evaluate_batch(atoms_list, batch_size=batch_size, properties=properties)


def evaluate_sequential(calculator, atoms_list, properties=["energy", "forces"], verbose=True):
    """
    Standard sequential evaluation fallback.
    """
    import numpy as np
    import time
    from tqdm import tqdm
    
    results = {p: [] for p in properties}
    
    start_time = time.perf_counter()
    
    # Use a small tqdm for visibility in long sequential runs
    for atoms in tqdm(atoms_list, desc="Sequential Evaluation", disable=not verbose):
        atoms.calc = calculator
        if "energy" in properties:
            results["energy"].append(atoms.get_potential_energy())
        if "forces" in properties:
            results["forces"].append(atoms.get_forces())
        if "stress" in properties:
            try:
                results["stress"].append(atoms.get_stress())
            except Exception:
                results["stress"].append(np.zeros(6))

    # Convert to NumPy arrays, handle inhomogeneous shapes
    final_results = {}
    for k, v in results.items():
        try:
            final_results[k] = np.array(v)
        except ValueError:
            # Handle ragged arrays (e.g. different number of atoms)
            final_results[k] = np.array(v, dtype=object)
            
    end_time = time.perf_counter()
    elapsed = end_time - start_time
    if verbose:
        print(f"  Sequential Job: {len(atoms_list)} structures calculated in {elapsed:.3f} seconds.")
            
    return final_results
