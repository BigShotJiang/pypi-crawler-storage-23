import os
from macer.defaults import DEFAULT_MODELS, _macer_root, resolve_model_path

_ALLEGRO_AVAILABLE = False
try:
    from nequip.ase import NequIPCalculator
    from nequip.ase.nequip_calculator import from_ase
    from nequip.data import AtomicDataDict
    from nequip.data.AtomicDataDict import batched_from_list
    import torch
    import numpy as np
    from ase.calculators.calculator import all_changes
    from matgl.ext.ase import full_3x3_to_voigt_6_stress # We might need a generic voigt converter, but matgl is not a hard dependency. 
    # Macer's M3GNet relies on matgl, but if it's not installed, we should provide our own voigt converter or use NequIP's if available.
    # NequIPCalculator has a voigt converter inside.
    _ALLEGRO_AVAILABLE = True
except Exception:
    NequIPCalculator = object
    pass

class MacerAllegroCalculator(NequIPCalculator):
    """Allegro/NequIP Calculator with Batch Evaluation support."""
    def evaluate_batch(self, atoms_list, batch_size=None, properties=["energy", "forces"]):
        if not _ALLEGRO_AVAILABLE:
            raise RuntimeError("Allegro/nequip is not installed.")

        if batch_size is None:
            batch_size = 32 if str(self.device) == "cuda" else 16

        all_results = {p: [] for p in properties}
        
        # 1. Featurize
        data_list = []
        for atoms in atoms_list:
            data = from_ase(atoms)
            for t in self.transforms:
                data = t(data)
            data_list.append(data)

        # 2. Process mini-batches
        for i in range(0, len(data_list), batch_size):
            mini_batch_data = data_list[i : i + batch_size]
            
            # Batch them natively via NequIP
            batch_obj = batched_from_list(mini_batch_data)
            batch_obj = AtomicDataDict.to_(batch_obj, self.device)
            
            # 3. Model inference
            with torch.no_grad():
                out = self.model(batch_obj)
            
            # 4. Extract results
            if "energy" in properties and AtomicDataDict.TOTAL_ENERGY_KEY in out:
                # Shape is usually (B, 1), convert to (B,)
                e_flat = out[AtomicDataDict.TOTAL_ENERGY_KEY].detach().cpu().numpy().flatten()
                all_results["energy"].append(self.energy_units_to_eV * e_flat)
                
            if "forces" in properties and AtomicDataDict.FORCE_KEY in out:
                # Shape is (Total_Atoms_in_batch, 3)
                f_flat = out[AtomicDataDict.FORCE_KEY].detach().cpu().numpy()
                f_flat = f_flat * (self.energy_units_to_eV / self.length_units_to_A)
                
                # Split back into (B, Natoms, 3)
                counts = [data[AtomicDataDict.POSITIONS_KEY].shape[0] for data in mini_batch_data]
                forces_split = np.split(f_flat, np.cumsum(counts)[:-1])
                for f_i in forces_split:
                    all_results["forces"].append(f_i[np.newaxis, ...])
                    
            if "stress" in properties and AtomicDataDict.STRESS_KEY in out:
                # Shape is usually (B, 3, 3)
                s_batch = out[AtomicDataDict.STRESS_KEY].detach().cpu().numpy()
                s_batch = s_batch * (self.energy_units_to_eV / (self.length_units_to_A**3))
                
                from nequip.ase.nequip_calculator import full_3x3_to_voigt_6_stress
                for s in s_batch:
                    s_voigt = full_3x3_to_voigt_6_stress(s)
                    all_results["stress"].append(s_voigt[np.newaxis, ...])
                    
        # 5. Combine mini-batch results
        final_results = {}
        if all_results.get("energy"):
            final_results["energy"] = np.concatenate(all_results["energy"], axis=0)
        
        if all_results.get("forces"):
            final_results["forces"] = np.concatenate(all_results["forces"], axis=0)
            
        if all_results.get("stress"):
            final_results["stress"] = np.concatenate(all_results["stress"], axis=0)
                
        return final_results

def get_allegro_calculator(model_path, device="cpu", **kwargs):
    if not _ALLEGRO_AVAILABLE or NequIPCalculator is object:
        raise RuntimeError("Allegro (nequip) is not installed. Please reinstall with 'pip install macer'.")

    if model_path is None:
        default_allegro_model_name = DEFAULT_MODELS.get("allegro")
        if default_allegro_model_name:
            model_path = resolve_model_path(default_allegro_model_name)
            print(f"No specific Allegro model path provided; using default: {model_path}")
            if not os.path.exists(model_path):
                raise FileNotFoundError(f"Default Allegro model not found at {model_path}. Please provide a valid model path with --model or ensure the default model exists.")
        else:
            raise ValueError("A compiled model path (`.pt2`) is required for Allegro/NequIP. No default model found in default-model.yaml.")
    else:
        model_path = resolve_model_path(model_path)

    calc_kwargs = {
        "device": device,
        "energy_units_to_eV": 1.0,
        "length_units_to_A": 1.0,
    }
    calc_kwargs.update(kwargs)

    # NequIPCalculator uses classmethod `from_compiled_model` to instantiate. 
    # To return MacerAllegroCalculator, we call the classmethod on our subclass.
    return MacerAllegroCalculator.from_compiled_model(
        compile_path=model_path,
        **calc_kwargs
    )
