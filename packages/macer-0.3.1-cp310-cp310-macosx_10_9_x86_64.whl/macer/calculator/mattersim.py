import os
import sys
import types
import importlib.metadata as _importlib_metadata
from macer.defaults import DEFAULT_MODELS, _macer_root, resolve_model_path
from macer.utils.model_manager import ensure_model, print_model_help

def _ensure_pkg_resources():
    try:
        import pkg_resources  # noqa: F401
        return
    except ModuleNotFoundError:
        pass

    class DistributionNotFound(Exception):
        pass

    def get_distribution(dist_name):
        try:
            version = _importlib_metadata.version(dist_name)
        except _importlib_metadata.PackageNotFoundError as e:
            raise DistributionNotFound(str(e))
        return types.SimpleNamespace(version=version)

    shim = types.ModuleType("pkg_resources")
    shim.get_distribution = get_distribution
    shim.DistributionNotFound = DistributionNotFound
    sys.modules["pkg_resources"] = shim

_ensure_pkg_resources()

try:
    from mattersim.forcefield import MatterSimCalculator
    _MATTERSIM_AVAILABLE = True
except Exception as e:
    import traceback
    _MATTERSIM_ERR = f"{e}\n{traceback.format_exc()}"
    _MATTERSIM_AVAILABLE = False
    MatterSimCalculator = object

class MacerMatterSimCalculator(MatterSimCalculator):
    """MatterSim Calculator with Batch Evaluation support."""
    def evaluate_batch(self, atoms_list, batch_size=None, properties=["energy", "forces"]):
        import torch
        import numpy as np
        from mattersim.forcefield.potential import build_dataloader
        
        if batch_size is None:
            if str(self.device) == "cuda":
                batch_size = 32
            elif str(self.device) == "mps":
                batch_size = 16
            else:
                batch_size = 8
                
        potential = getattr(self, "potential", None)
        
        if potential and hasattr(potential, "predict_properties"):
            loader = build_dataloader(
                atoms_list, 
                batch_size=batch_size,
                only_inference=True
            )
            
            res = potential.predict_properties(
                loader, 
                include_forces="forces" in properties,
                include_stresses="stress" in properties
            )
            
            energies, forces, stresses = res
            
            final_results = {}
            if "energy" in properties:
                final_results["energy"] = np.array(energies)
            
            if "forces" in properties:
                try:
                    final_results["forces"] = np.stack(forces)
                except ValueError:
                    squeezed = [np.squeeze(f) for f in forces]
                    try:
                        final_results["forces"] = np.stack(squeezed)
                    except Exception:
                        final_results["forces"] = np.array(list(forces), dtype=object)
                    
            if "stress" in properties:
                try:
                    final_results["stress"] = np.stack(stresses)
                except ValueError:
                    squeezed_s = [np.squeeze(s) for s in stresses]
                    try:
                        final_results["stress"] = np.stack(squeezed_s)
                    except Exception:
                        final_results["stress"] = np.array(list(stresses), dtype=object)
                
            return final_results
        else:
            from macer.calculator.factory import evaluate_sequential as fallback_eval
            return fallback_eval(self, atoms_list, properties=properties)

def get_mattersim_calculator(model_path, device="cpu", **kwargs):
    if not _MATTERSIM_AVAILABLE or MatterSimCalculator is object:
        if "pkg_resources" in _MATTERSIM_ERR:
            raise RuntimeError("MatterSim import failed: missing setuptools (pkg_resources). Please install with 'pip install setuptools'.")
        raise RuntimeError("MatterSim is not installed. Please reinstall with 'pip install macer'.")

    if model_path is None:
        default_mattersim_model_name = DEFAULT_MODELS.get("mattersim")
        if default_mattersim_model_name:
            ensure_model("mattersim", default_mattersim_model_name)
            model_path = resolve_model_path(default_mattersim_model_name)
            print(f"No specific MatterSim model path provided; using default: {model_path}")
        else:
            raise ValueError("A model path (load_path) is required for MatterSim. No default model found in default-model.yaml.")
    else:
        if not os.path.exists(model_path):
            basename = os.path.basename(model_path)
            provisioned = ensure_model("mattersim", basename)
            if provisioned:
                model_path = provisioned
            else:
                print_model_help("mattersim")
                raise FileNotFoundError(f"Model file not found: {model_path}")
        
        if not os.path.isabs(model_path):
             model_path = resolve_model_path(model_path)

    return MacerMatterSimCalculator(device=device, load_path=model_path)