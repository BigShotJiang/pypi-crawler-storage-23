import os
from macer.defaults import DEFAULT_MODELS, _macer_root, resolve_model_path, DEFAULT_SEVENNET_MODAL
from macer.utils.model_manager import ensure_model, print_model_help

_SEVENNET_AVAILABLE = False
try:
    from sevenn.calculator import SevenNetCalculator
    _SEVENNET_AVAILABLE = True
except Exception as e:
    import traceback
    _SEVENNET_ERR = f"{e}\n{traceback.format_exc()}"
    pass

def get_sevennet_calculator(model_path: str, device: str = "cpu", modal: str = None):
    """Construct SevenNet calculator."""
    if not _SEVENNET_AVAILABLE:
        if '_SEVENNET_ERR' in globals():
            print(f"ERROR DETAILS: {_SEVENNET_ERR}")
        raise RuntimeError("SevenNet related libraries are not installed. Please reinstall with 'pip install macer'.")

    # Use default modal from config if not specified
    if modal is None:
        modal = DEFAULT_SEVENNET_MODAL

    # Display available SevenNet tasks and fidelities
    sevennet_tasks = {
        "mpa": "PBE(+U)",
        "omat24": "PBE(+U)",
        "matpes_pbe": "PBE",
        "oc20": "RPBE",
        "oc22": "PBE(+U)",
        "odac23": "PBE-D3",
        "omol25_low": "ωB97M-V",
        "omol25_high": "ωB97M-V*",
        "spice": "ωB97M",
        "qcml": "PBE0",
        "pet_mad": "PBEsol",
        "mp_r2scan": "r²SCAN",
        "matpes_r2scan": "r²SCAN"
    }

    print("\nList of available SevenNet tasks and corresponding fidelities:")
    print(f"{'Task name':<15} | {'Fidelity':<15}")
    print("-" * 33)
    for task, fidelity in sevennet_tasks.items():
        print(f"{task:<15} | {fidelity:<15}")
    
    print(f"\n>>> Selected SevenNet modal: {modal}")

    if model_path is None:
        # Use the default SevenNet model path from DEFAULT_MODELS
        default_sevennet_model_name = DEFAULT_MODELS.get("sevennet")
        if default_sevennet_model_name:
            # Check and Provision
            ensure_model("sevennet", default_sevennet_model_name)
            model_path = resolve_model_path(default_sevennet_model_name)
            print(f"No specific SevenNet model path provided; using default: {model_path}")
        else:
            raise ValueError("No default SevenNet model specified in default-model.yaml and no model_path provided.")
    else:
        # Check if the file exists. If not, try to auto-provision.
        if not os.path.exists(model_path):
            basename = os.path.basename(model_path)
            provisioned = ensure_model("sevennet", basename)
            if provisioned:
                model_path = provisioned
            else:
                # Provisioning failed or model unknown
                print_model_help("sevennet")
                raise FileNotFoundError(f"Model file not found: {model_path}")
        
        # If it was a relative path and exists (or was just provisioned), resolve it to absolute if needed
        if not os.path.isabs(model_path):
             model_path = resolve_model_path(model_path)

    calc_args = {
        "model": model_path,
        "device": device,
    }
    if modal:
        calc_args["modal"] = modal

    return MacerSevenNetCalculator(**calc_args)

class MacerSevenNetCalculator(SevenNetCalculator):
    """SevenNet Calculator with Batch Evaluation support."""
    def evaluate_batch(self, atoms_list, batch_size=None, properties=["energy", "forces"]):
        import torch
        import numpy as np
        from sevenn.train.dataload import unlabeled_atoms_to_graph
        from sevenn.atom_graph_data import AtomGraphData
        import sevenn._keys as KEY
        from torch_geometric.data import Batch

        is_ts_type = hasattr(torch.jit, "_script") and isinstance(self.model, torch.jit._script.RecursiveScriptModule)

        # 1. Convert all atoms to graph data
        data_list = []
        for atoms in atoms_list:
            d = AtomGraphData.from_numpy_dict(
                unlabeled_atoms_to_graph(atoms, self.cutoff, with_shift=is_ts_type)
            )
            if self.modal:
                d[KEY.DATA_MODALITY] = self.modal
            
            if is_ts_type:
                d[KEY.NODE_FEATURE] = torch.tensor(
                    [self.type_map[z.item()] for z in d[KEY.NODE_FEATURE]],
                    dtype=torch.int64,
                )
            data_list.append(d)
        
        # 2. Batch them
        batch = Batch.from_data_list(data_list).to(self.device)
        
        # 3. Model inference
        # Temporarily enable batch mode in SevenNet model if supported
        was_batch = getattr(self.model, "is_batch_data", False)
        if hasattr(self.model, "set_is_batch_data"):
            self.model.set_is_batch_data(True)
        
        # Enable gradients for force/stress computation (SevenNet uses autograd)
        torch.set_grad_enabled(True)
        if hasattr(batch, KEY.POS):
            batch[KEY.POS].requires_grad_(True)
        if hasattr(batch, KEY.CELL):
            batch[KEY.CELL].requires_grad_(True)

        output = self.model(batch)
            
        # Restore batch mode
        if hasattr(self.model, "set_is_batch_data"):
            self.model.set_is_batch_data(was_batch)
            
        # 4. Extract results
        final_results = {}
        
        # SevenNet outputs total energy for each graph in the batch
        if "energy" in properties:
            # PRED_TOTAL_ENERGY usually has shape (B, 1) or (B,)
            energies = output[KEY.PRED_TOTAL_ENERGY].detach().cpu().numpy().flatten()
            final_results["energy"] = energies
            
        if "forces" in properties:
            # PRED_FORCE has shape (Total_Atoms, 3)
            # We need to split them back to (B, Natoms, 3)
            all_forces = output[KEY.PRED_FORCE].detach().cpu().numpy()
            
            # Use batch.ptr to split if available, or just use atoms_list lengths
            forces_list = []
            start_idx = 0
            for atoms in atoms_list:
                n = len(atoms)
                forces_list.append(all_forces[start_idx : start_idx + n, :])
                start_idx += n
            final_results["forces"] = np.array(forces_list)
            
        if "stress" in properties:
            # PRED_STRESS shape (B, 3, 3) or (B, 9)
            # SevenNet calculator uses [[0, 1, 2, 4, 5, 3]] for Voigt
            stresses_raw = output[KEY.PRED_STRESS].detach().cpu().numpy()
            stress_list = []
            for s in stresses_raw:
                # s is 3x3 or flattened
                if s.ndim == 2:
                    # convert to Voigt notation as expected by ASE/Macer
                    # SevenNet: S_xx, S_yy, S_zz, S_yz, S_xz, S_xy? 
                    # Let's match output_to_results: output[KEY.PRED_STRESS].numpy()[[0, 1, 2, 4, 5, 3]]
                    s_flat = s.flatten()
                    stress_list.append(-s_flat[[0, 1, 2, 4, 5, 3]])
                else:
                    stress_list.append(-s[[0, 1, 2, 4, 5, 3]])
            final_results["stress"] = np.array(stress_list)
            
        return final_results
