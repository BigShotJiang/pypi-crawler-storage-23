
import os
import sys

_ORB_AVAILABLE = False
try:
    from orb_models.forcefield import pretrained
    from orb_models.forcefield.calculator import ORBCalculator
    _ORB_AVAILABLE = True
except Exception:
    pass

from macer.defaults import resolve_model_path

def get_orb_calculator(model_path="orb_v2", device="cpu", **kwargs):
    """
    Constructs ORB calculator from a pretrained model name.
    """
    if not _ORB_AVAILABLE:
        raise RuntimeError("orb-models is not installed. Please reinstall with 'pip install macer'.")

    # Fix for macOS: Disable torch.compile to avoid library loading errors (@rpath/libc++.1.dylib)
    if sys.platform == "darwin" and "TORCH_COMPILE_DISABLE" not in os.environ:
        os.environ["TORCH_COMPILE_DISABLE"] = "1"

    # Normalize name for fuzzy matching (ignore hyphens/underscores and case)
    def normalize(s):
        return s.replace("-", "").replace("_", "").lower()

    target = normalize(model_path)
    available_names = dir(pretrained)
    
    # Try to find a match in pretrained models (using full string)
    match = None
    for name in available_names:
        if not name.startswith("_") and normalize(name) == target:
            match = name
            break
            
    # If not found, try using the basename of the path
    # (Because macer md resolves paths to absolute paths like .../orb_v2)
    if not match:
        target_base = normalize(os.path.basename(model_path))
        for name in available_names:
            if not name.startswith("_") and normalize(name) == target_base:
                match = name
                break
    
    if match:
        model_name = match
    else:
        # Try resolving as local path
        resolved = resolve_model_path(model_path)
        if resolved and os.path.exists(resolved):
            model_name = resolved
        else:
            model_name = model_path

    # Final check and loading
    try:
        model_func = getattr(pretrained, model_name)
        print(f"Loading ORB pretrained model: {model_name}")
        orbff = model_func(device=device)
    except AttributeError:
        # One last check: if the original model_path (before resolution) was a match
        # (should have been caught by the loop, but being extra safe)
        if match:
             model_func = getattr(pretrained, match)
             orbff = model_func(device=device)
        else:
             available_models = [name for name in available_names if not name.startswith('_') and callable(getattr(pretrained, name))]
             raise ValueError(f"Unsupported ORB model: '{model_name}'.\nAvailable models are: {available_models}")

    return MacerORBCalculator(orbff, device=device)

class MacerORBCalculator(ORBCalculator):
    """ORB Calculator with Batch Evaluation support."""
    def evaluate_batch(self, atoms_list, batch_size=None, properties=["energy", "forces"]):
        import numpy as np
        import torch
        from orb_models.forcefield.calculator import ase_atoms_to_atom_graphs
        from orb_models.forcefield.base import batch_graphs
        
        if batch_size is None:
            batch_size = 32 if str(self.device) == "cuda" else 16
            
        all_results = {p: [] for p in properties}
        
        # 1. Featurize all atoms into graphs (Python loop overhead exists here but is much smaller than model calls)
        graphs_list = []
        for atoms in atoms_list:
            g = ase_atoms_to_atom_graphs(
                atoms,
                system_config=self.system_config,
                brute_force_knn=self.brute_force_knn,
                device=self.device
            )
            graphs_list.append(g)
            
        # 2. Process mini-batches of graphs
        for i in range(0, len(graphs_list), batch_size):
            mini_batch_graphs = graphs_list[i : i + batch_size]
            
            # ORB Native Batching
            batch_obj = batch_graphs(mini_batch_graphs)
            self.model = self.model.to(self.device)
            
            with torch.no_grad():
                out = self.model.predict(batch_obj)
                
            if "energy" in properties:
                # Flat array of energies
                all_results["energy"].append(out["graph_pred"].detach().cpu().numpy().flatten())
            if "forces" in properties:
                # ORB returns concatenated node predictions: (Total_Nodes_in_Batch, 3)
                f_flat = out["node_pred"].detach().cpu().numpy()
                # Get number of nodes per structure in this mini-batch
                counts = batch_obj.n_node.cpu().numpy()
                
                if f_flat.shape[0] != np.sum(counts):
                    print(f"DEBUG: ORB Shape Mismatch! f_flat.shape={f_flat.shape}, sum(counts)={np.sum(counts)}, counts={counts}")
                
                # Split flat forces into list of (N_i, 3) arrays
                forces_split = np.split(f_flat, np.cumsum(counts)[:-1])
                
                # Each structure should be (N_i, 3). For ensemble, usually N_i is constant.
                for f_i in forces_split:
                    all_results["forces"].append(f_i[np.newaxis, ...]) # Shape (1, N_i, 3)
            if "stress" in properties and "stress_pred" in out:
                all_results["stress"].append(out["stress_pred"].detach().cpu().numpy())

        # Combine results
        final_results = {}
        if all_results.get("energy"):
            final_results["energy"] = np.concatenate(all_results["energy"], axis=0)
        
        if all_results.get("forces"):
            # Concatenate along batch axis (0)
            # Each element is (MiniBatch, Natoms, 3)
            final_results["forces"] = np.concatenate(all_results["forces"], axis=0)
            
        if all_results.get("stress"):
            final_results["stress"] = np.concatenate(all_results["stress"], axis=0)
                
        return final_results
