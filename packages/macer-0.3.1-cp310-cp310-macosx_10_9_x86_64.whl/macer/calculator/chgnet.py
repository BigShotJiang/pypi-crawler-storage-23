
_CHGNET_AVAILABLE = False
try:
    from chgnet.model import CHGNetCalculator, CHGNet
    _CHGNET_AVAILABLE = True
except Exception:
    CHGNetCalculator = object
    _CHGNET_AVAILABLE = False

from macer.defaults import resolve_model_path

class MacerCHGNetCalculator(CHGNetCalculator):
    """CHGNet Calculator with Batch Evaluation support."""
    def evaluate_batch(self, atoms_list, batch_size=None, properties=["energy", "forces"]):
        import numpy as np
        
        # CHGNet's underlying model has predict_structure which supports lists
        model = self.model
        
        # Convert ASE Atoms to pymatgen Structures (required by CHGNet)
        from pymatgen.io.ase import AseAtomsAdaptor
        structures = [AseAtomsAdaptor.get_structure(at) for at in atoms_list]
        
        # Native batch inference
        # CHGNet internally handles batch_size if passed through kwargs or handled manually
        res = model.predict_structure(structures)
        
        # Handle single vs list return (CHGNet returns list if input is list)
        if not isinstance(res, list):
            res = [res]
            
        final_results = {}
        if "energy" in properties:
            # CHGNet uses 'e' for energy in its output dict
            final_results["energy"] = np.array([r["e"] for r in res])
        if "forces" in properties:
            # CHGNet uses 'f' for forces
            final_results["forces"] = np.array([r["f"] for r in res])
        if "stress" in properties:
            # CHGNet uses 's' for stress
            final_results["stress"] = np.array([r["s"] for r in res])
            
        return final_results

def get_chgnet_calculator(model_path=None, device="cpu", **kwargs):
    if not _CHGNET_AVAILABLE or CHGNetCalculator is object:
        raise RuntimeError("CHGNet is not installed. Please reinstall with 'pip install macer'.")
    
    if model_path:
        resolved = resolve_model_path(model_path)
        if resolved:
            model_path = resolved

    # Return the batch-enabled version
    return MacerCHGNetCalculator(use_device=device)
