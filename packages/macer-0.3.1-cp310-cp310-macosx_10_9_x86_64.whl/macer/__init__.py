"""
Macer: Machine-learning accelerated Atomic Computational Environment for automated Research workflows
Copyright (c) 2025 The Macer Package Authors
Author: Soungmin Bae <soungminbae@gmail.com>
License: MIT
"""

__version__ = "0.3.1"
__author__ = "Soungmin Bae"
__email__ = "soungminbae@gmail.com"


# Dynaphopy patch should be applied explicitly by the CLI or main entry point
# to avoid cascading imports (phonopy -> numpy -> etc) at package import time.
# from macer.utils.fix_dynaphopy import apply_dynaphopy_patch
# try:
#     apply_dynaphopy_patch()
# except ImportError:
#     pass
