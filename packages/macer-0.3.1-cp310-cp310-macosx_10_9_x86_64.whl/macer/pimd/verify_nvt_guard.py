from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd


HAM_COLUMNS = [
    "step",
    "H_total_au",
    "temperature_K",
    "V_potential_au",
    "K_dynamic_au",
    "K_quantum_au",
    "Ebath_au",
    "Ebath_cent_au",
    "E_virial_au",
]


def _read_ham(path: Path) -> pd.DataFrame:
    rows: list[list[float]] = []
    for line in path.read_text().splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        toks = s.split()
        if len(toks) < 9:
            continue
        rows.append([float(toks[i]) for i in range(9)])
    if not rows:
        raise ValueError(f"No data rows in {path}")
    df = pd.DataFrame(rows, columns=HAM_COLUMNS)
    df["step"] = df["step"].astype(int)
    return df


def _run_cmd(cmd: list[str], out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    log_path = out_dir / "stdout.log"
    with log_path.open("w") as fp:
        subprocess.run(cmd, check=True, stdout=fp, stderr=subprocess.STDOUT)


def _build_cmd(
    command: str,
    poscar: str,
    ff: str,
    temp: float,
    nbead: int,
    tstep: float,
    nsteps: int,
    seed: int,
    out_dir: Path,
) -> list[str]:
    base = [
        sys.executable,
        "-m",
        "macer.cli.main",
        command,
        "-p",
        poscar,
        "--ff",
        ff,
        "--temp",
        str(temp),
        "--nbead",
        str(nbead),
        "--tstep",
        str(tstep),
        "--nsteps",
        str(nsteps),
        "--seed",
        str(seed),
        "--output-dir",
        str(out_dir),
    ]
    if command == "pimd":
        base.append("--detailed-output")
    return base


def _compare(
    baseline_df: pd.DataFrame,
    candidate_df: pd.DataFrame,
    tol_h: float,
    tol_t: float,
    tol_v: float,
    tol_kd: float,
    tol_kq: float,
) -> int:
    common_steps = sorted(set(baseline_df["step"]).intersection(set(candidate_df["step"])))
    if not common_steps:
        raise RuntimeError("No common steps between baseline and candidate ham.dat")

    b = baseline_df.set_index("step").loc[common_steps]
    c = candidate_df.set_index("step").loc[common_steps]

    metrics = {
        "H_total_au": (tol_h, np.abs(b["H_total_au"] - c["H_total_au"])),
        "temperature_K": (tol_t, np.abs(b["temperature_K"] - c["temperature_K"])),
        "V_potential_au": (tol_v, np.abs(b["V_potential_au"] - c["V_potential_au"])),
        "K_dynamic_au": (tol_kd, np.abs(b["K_dynamic_au"] - c["K_dynamic_au"])),
        "K_quantum_au": (tol_kq, np.abs(b["K_quantum_au"] - c["K_quantum_au"])),
    }

    failed = False
    print("=== NVT Guard Comparison ===")
    print(f"Compared common steps: {len(common_steps)} (first={common_steps[0]}, last={common_steps[-1]})")
    for name, (tol, series) in metrics.items():
        max_abs = float(series.max())
        mean_abs = float(series.mean())
        ok = max_abs <= tol
        failed = failed or (not ok)
        print(f"{name:16s} max_abs={max_abs:.6e} mean_abs={mean_abs:.6e} tol={tol:.6e} pass={ok}")

    return 1 if failed else 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description="NVT regression guard for pimd (Phase A).",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--poscar", required=True, help="Input POSCAR path.")
    parser.add_argument("--ff", default="emt", help="Force field.")
    parser.add_argument("--temp", type=float, default=300.0, help="Temperature [K].")
    parser.add_argument("--nbead", type=int, default=4, help="Number of beads.")
    parser.add_argument("--tstep", type=float, default=0.25, help="Time step [fs].")
    parser.add_argument("--nsteps", type=int, default=200, help="Number of steps.")
    parser.add_argument("--seed", type=int, default=42, help="Random seed.")
    parser.add_argument("--workdir", default="workdir/nvt-guard", help="Guard output root directory.")

    parser.add_argument("--baseline-dir", default=None, help="Use existing baseline directory (contains ham.dat).")
    parser.add_argument("--candidate-dir", default=None, help="Use existing candidate directory (contains ham.dat).")
    parser.add_argument("--baseline-command", choices=["pimd"], default="pimd")
    parser.add_argument("--candidate-command", choices=["pimd"], default="pimd")

    parser.add_argument("--tol-h", type=float, default=1.0e-4, help="Tolerance for H_total_au.")
    parser.add_argument("--tol-t", type=float, default=2.0e2, help="Tolerance for temperature_K.")
    parser.add_argument("--tol-v", type=float, default=1.0e-2, help="Tolerance for V_potential_au.")
    parser.add_argument("--tol-kd", type=float, default=2.0e-2, help="Tolerance for K_dynamic_au.")
    parser.add_argument("--tol-kq", type=float, default=2.0e-2, help="Tolerance for K_quantum_au.")
    args = parser.parse_args()

    root = Path(args.workdir).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)

    if args.baseline_dir:
        baseline_dir = Path(args.baseline_dir).expanduser().resolve()
    else:
        baseline_dir = root / "baseline"
        baseline_cmd = _build_cmd(
            command=args.baseline_command,
            poscar=args.poscar,
            ff=args.ff,
            temp=args.temp,
            nbead=args.nbead,
            tstep=args.tstep,
            nsteps=args.nsteps,
            seed=args.seed,
            out_dir=baseline_dir,
        )
        print("Running baseline:", " ".join(baseline_cmd))
        _run_cmd(baseline_cmd, baseline_dir)

    if args.candidate_dir:
        candidate_dir = Path(args.candidate_dir).expanduser().resolve()
    else:
        candidate_dir = root / "candidate"
        candidate_cmd = _build_cmd(
            command=args.candidate_command,
            poscar=args.poscar,
            ff=args.ff,
            temp=args.temp,
            nbead=args.nbead,
            tstep=args.tstep,
            nsteps=args.nsteps,
            seed=args.seed,
            out_dir=candidate_dir,
        )
        print("Running candidate:", " ".join(candidate_cmd))
        _run_cmd(candidate_cmd, candidate_dir)

    b_ham = baseline_dir / "ham.dat"
    c_ham = candidate_dir / "ham.dat"
    if not b_ham.exists():
        raise FileNotFoundError(f"Missing baseline ham.dat: {b_ham}")
    if not c_ham.exists():
        raise FileNotFoundError(f"Missing candidate ham.dat: {c_ham}")

    baseline_df = _read_ham(b_ham)
    candidate_df = _read_ham(c_ham)
    rc = _compare(
        baseline_df=baseline_df,
        candidate_df=candidate_df,
        tol_h=float(args.tol_h),
        tol_t=float(args.tol_t),
        tol_v=float(args.tol_v),
        tol_kd=float(args.tol_kd),
        tol_kq=float(args.tol_kq),
    )

    print(f"baseline_dir={baseline_dir}")
    print(f"candidate_dir={candidate_dir}")
    print("NVT_GUARD_RESULT:", "PASS" if rc == 0 else "FAIL")
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
