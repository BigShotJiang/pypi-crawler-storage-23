import numpy as np
from dataclasses import dataclass, field
from typing import Optional

@dataclass
class PIMDASEState:
    """
    Encapsulates the state of a PIMD simulation, replacing the legacy global P.* parameters.
    """
    # Dimensions
    natom: int
    nbead: int
    
    # Coordinates and Forces (Normal Mode and Bead Space)
    # [3, natom, nbead] or similar based on original implementation's preference
    # Original PIMD uses (3, natom, nbead) mostly
    ur: np.ndarray    # NM positions
    vur: np.ndarray   # NM velocities
    fur: np.ndarray   # NM forces
    
    r: np.ndarray     # Bead positions (cartesian)
    vr: np.ndarray    # Bead velocities (cartesian)
    fr: np.ndarray    # Bead forces (cartesian)
    pot_beads: np.ndarray  # Potential energy per bead
    stress_beads: np.ndarray # Stress per bead
    
    # Reference (Spring) forces
    f_ref: np.ndarray
    
    # Masses
    physmass: np.ndarray  # Physical masses [natom]
    fictmass: np.ndarray  # Fictitious NM masses [natom, nbead]
    dnmmass: np.ndarray   # NM masses [natom, nbead]
    
    # Normal Mode Transform Matrices
    u: np.ndarray
    uinv: np.ndarray
    tnm: np.ndarray
    tnminv: np.ndarray
    
    # Thermostat (NHC) State
    # Non-centroid bath
    qmass: np.ndarray     # Bath masses [nbead]
    rbath: np.ndarray     # Bath positions [3, natom, nnhc, nbead]
    vrbath: np.ndarray    # Bath velocities [3, natom, nnhc, nbead]
    
    # Centroid bath (if Ncent=3)
    qmcent31: np.ndarray  # Centroid bath masses [nnhc]
    rbc31: np.ndarray     # Centroid bath positions [3, natom, nnhc]
    vrbc31: np.ndarray    # Centroid bath velocities [3, natom, nnhc]
    
    # barostat_nhc (if anisotropic, this might be more complex, but let's start with isotropic/full stress)
    # Positions and velocities for barostat's own chain
    rb_baro: np.ndarray
    vb_baro: np.ndarray
    qb_baro: np.ndarray

    # Cell and Barostat variables
    cell: np.ndarray
    h: np.ndarray
    h_past: np.ndarray
    eta: np.ndarray
    # Barostat strain-rate tensor (3x3): drives cell evolution via h_dot = h @ eta.
    eta_past: np.ndarray
    # Previous-step eta for centered-difference update.
    zeta: float
    # Thermostat friction scalar: damps/amplifies momenta to control temperature.
    zeta_past: float
    # Previous-step zeta for centered-difference update.
    zeta_integrated: float
    pfactor: float
    pfact: float
    tfact: float
    desired_ekin: float
    mask: np.ndarray
    frac_traceless: float
    p_eps: np.ndarray
    W: float
    external_stress: np.ndarray
    stress_inst: np.ndarray

    # Step Counters and Timing
    istepsv: int = 0
    dt: float = 0.0
    dt_ref: float = 0.0
    
    # Observables
    dkinetic: float = 0.0
    dkinetic_centroid: float = 0.0
    qkinetic: float = 0.0
    ebath: float = 0.0
    ebath_cent: float = 0.0
    ebath_baro: float = 0.0
    e_virial: float = 0.0
    potential: float = 0.0
    hamiltonian: float = 0.0
    temp_inst: float = 0.0
    pressure_inst: float = 0.0
    
    # Constant Weights
    ysweight: np.ndarray = field(default_factory=lambda: np.zeros(5))

    @property
    def beta(self) -> float:
        # This will need to be provided or calculated from T
        return self._beta

    def __post_init__(self):
        # Validation or extra init if needed
        pass
