import os
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from macer.pimd.state import PIMDASEState

SCHEMA_VERSION = "pimd-npz-v2"
BOHR_TO_ANG = 0.529177249
FORCE_AU_TO_EV_ANG = 51.422067


def _as_int(value) -> int:
    arr = np.array(value)
    if arr.ndim == 0:
        return int(arr.item())
    raise ValueError(f"Expected scalar integer, got shape={arr.shape}")


def _to_scalar_or_array(val):
    if isinstance(val, np.ndarray):
        return val
    if isinstance(val, (int, float, bool)):
        return np.array(val)
    return None


def _extract_last_frame(payload: dict, key: str, expected_ndim: int):
    arr = np.array(payload[key], dtype=float)
    if arr.ndim == expected_ndim:
        return arr
    if arr.ndim == expected_ndim + 1:
        if arr.shape[0] < 1:
            raise ValueError(f"{key} has zero frames.")
        return arr[-1]
    raise ValueError(f"Invalid {key} rank: shape={arr.shape}")


def _validate_v2_payload(payload: dict, state: PIMDASEState | None = None) -> None:
    required = ("schema_version", "steps", "r_bead", "f_bead", "cell", "natom", "nbead", "pbc")
    missing = [k for k in required if k not in payload]
    if missing:
        raise ValueError(f"Restart NPZ missing required keys: {missing}")

    schema = str(np.array(payload["schema_version"]).reshape(()).item())
    if schema != SCHEMA_VERSION:
        raise ValueError(f"Unsupported schema_version: {schema} (expected {SCHEMA_VERSION})")

    natom_npz = _as_int(payload["natom"])
    nbead_npz = _as_int(payload["nbead"])

    steps = np.array(payload["steps"], dtype=int).reshape(-1)
    if steps.size < 1:
        raise ValueError("steps is empty.")

    r_last = _extract_last_frame(payload, "r_bead", expected_ndim=3)  # [nbead, natom, 3]
    f_last = _extract_last_frame(payload, "f_bead", expected_ndim=3)  # [nbead, natom, 3]
    c_last = _extract_last_frame(payload, "cell", expected_ndim=2)    # [3,3]

    if r_last.shape != f_last.shape:
        raise ValueError(f"r_bead/f_bead shape mismatch: {r_last.shape} vs {f_last.shape}")
    if r_last.shape != (nbead_npz, natom_npz, 3):
        raise ValueError(
            f"Invalid r_bead shape: {r_last.shape} (expected {(nbead_npz, natom_npz, 3)})"
        )
    if c_last.shape != (3, 3):
        raise ValueError(f"Invalid cell shape: {c_last.shape}")
    if not np.isfinite(r_last).all() or not np.isfinite(f_last).all() or not np.isfinite(c_last).all():
        raise ValueError("Restart NPZ contains non-finite values in r_bead/f_bead/cell")

    if state is not None:
        if int(state.natom) != natom_npz or int(state.nbead) != nbead_npz:
            raise ValueError(
                "Restart natom/nbead mismatch with initialized state: "
                f"state=({state.natom},{state.nbead}) vs restart=({natom_npz},{nbead_npz})"
            )


def save_state(
    state: PIMDASEState,
    filepath: str,
    *,
    verbose: bool = False,
    symbols: list[str] | None = None,
):
    """
    Save restart in canonical pimd-npz-v2 format.
    """
    r_internal = np.asarray(state.r, dtype=float)   # [3, natom, nbead] in bohr
    fr_internal = np.asarray(state.fr, dtype=float) # [3, natom, nbead] in hartree/bohr with 1/nbead scaling
    cell_bohr = np.asarray(state.cell, dtype=float) # [3,3] in bohr

    r_bead = np.transpose(r_internal, (2, 1, 0)) * BOHR_TO_ANG
    f_bead = np.transpose(fr_internal, (2, 1, 0)) * FORCE_AU_TO_EV_ANG * float(state.nbead)
    cell_ang = cell_bohr * BOHR_TO_ANG
    step = int(getattr(state, "istepsv", 0))

    symbol_list = [str(s) for s in symbols] if symbols is not None else None
    if symbol_list is None:
        symbol_list = []
    species = list(dict.fromkeys(symbol_list)) if symbol_list else []
    species_counts = np.array([symbol_list.count(sp) for sp in species], dtype=int) if species else np.array([], dtype=int)

    payload: dict[str, np.ndarray] = {
        "schema_version": np.array(SCHEMA_VERSION, dtype=object),
        "producer": np.array("macer.pimd.restart", dtype=object),
        "created_at": np.array(datetime.now(timezone.utc).isoformat(), dtype=object),
        "units_length": np.array("angstrom", dtype=object),
        "units_cell": np.array("angstrom", dtype=object),
        "units_force": np.array("eV/angstrom", dtype=object),
        "units_energy": np.array("eV", dtype=object),
        "units_stress": np.array("GPa", dtype=object),
        "pbc": np.array([True, True, True], dtype=bool),
        "symbols": np.array(symbol_list, dtype=object),
        "species": np.array(species, dtype=object),
        "species_counts": species_counts,
        "frame_valid_mask": np.array([True], dtype=bool),
        "steps": np.array([step], dtype=int),
        "r_bead": r_bead[np.newaxis, ...],   # [1, nbead, natom, 3]
        "f_bead": f_bead[np.newaxis, ...],   # [1, nbead, natom, 3]
        "cell": cell_ang[np.newaxis, ...],   # [1, 3, 3]
        "nbead": np.int64(state.nbead),
        "natom": np.int64(state.natom),
        "step": np.int64(step),
    }

    # Restart-only full state payload under `state_*` namespace.
    for key, value in state.__dict__.items():
        saved = _to_scalar_or_array(value)
        if saved is not None:
            payload[f"state_{key}"] = saved

    _atomic_write_restart_npz(filepath, payload)
    if verbose:
        print(f"[pimd] Restart state saved to {filepath}")


def _atomic_write_restart_npz(filepath: str, payload: dict[str, np.ndarray]) -> None:
    dst = Path(filepath)
    if dst.suffix.lower() != ".npz":
        raise ValueError(f"Restart filepath must end with .npz: {dst}")
    tmp = dst.with_name(f"{dst.name}.tmp")
    if dst.name == "restart.npz":
        backup = dst.with_name("restart.prev.npz")
    else:
        backup = dst.with_name(f"{dst.stem}.prev{dst.suffix}")

    dst.parent.mkdir(parents=True, exist_ok=True)
    moved_old = False
    try:
        with open(tmp, "wb") as fh:
            np.savez(fh, **payload)
            fh.flush()
            os.fsync(fh.fileno())

        if dst.exists():
            os.replace(dst, backup)
            moved_old = True

        os.replace(tmp, dst)
    except Exception:
        if moved_old and backup.exists() and not dst.exists():
            os.replace(backup, dst)
        raise
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except Exception:
                pass


def _load_payload(path: Path) -> dict:
    with np.load(path, allow_pickle=True) as data:
        return {k: data[k] for k in data.files}


def _apply_payload_to_state(payload: dict, state: PIMDASEState) -> None:
    _validate_v2_payload(payload, state=state)

    # Prefer explicit restart state if present.
    state_keys = [k for k in payload.keys() if k.startswith("state_")]
    for sk in state_keys:
        attr = sk[len("state_") :]
        if hasattr(state, attr):
            val = payload[sk]
            if isinstance(val, np.ndarray) and val.ndim == 0:
                val = val.item()
            setattr(state, attr, val)

    # Ensure core tensors are always recoverable from canonical frame payload.
    r_last = _extract_last_frame(payload, "r_bead", expected_ndim=3)   # [nbead, natom, 3] ang
    f_last = _extract_last_frame(payload, "f_bead", expected_ndim=3)   # [nbead, natom, 3] eV/ang
    c_last = _extract_last_frame(payload, "cell", expected_ndim=2)      # [3,3] ang

    state.r = np.transpose(r_last / BOHR_TO_ANG, (2, 1, 0))
    state.fr = np.transpose(f_last / (FORCE_AU_TO_EV_ANG * float(state.nbead)), (2, 1, 0))
    state.cell = c_last / BOHR_TO_ANG

    # Keep step cursor synced with canonical metadata.
    if "step" in payload:
        state.istepsv = int(np.array(payload["step"]).reshape(()).item())
    else:
        steps = np.array(payload["steps"], dtype=int).reshape(-1)
        state.istepsv = int(steps[-1])


def load_state(filepath: str, state: PIMDASEState):
    """
    Load restart from canonical pimd-npz-v2 format.
    Fallback order: requested path -> restart.prev.npz (same directory).
    """
    primary = Path(filepath)
    backup = primary.with_name("restart.prev.npz")
    candidates: list[Path] = [primary]
    if backup != primary:
        candidates.append(backup)

    load_errors: list[str] = []
    existing = [p for p in candidates if p.exists()]
    if not existing:
        raise FileNotFoundError(f"Restart file not found: {primary}")

    for idx, path in enumerate(candidates):
        if not path.exists():
            continue
        try:
            payload = _load_payload(path)
            _apply_payload_to_state(payload, state)
            if idx > 0:
                print(f"[pimd] Warning: failed to load {primary.name}; recovered from {path.name}.")
            print(f"[pimd] Restart state loaded from {path}")
            return state
        except Exception as exc:
            load_errors.append(f"{path}: {exc}")
            continue

    raise RuntimeError("Failed to load restart state from all candidates:\n" + "\n".join(load_errors))
