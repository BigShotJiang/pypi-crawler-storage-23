from __future__ import annotations

import json
from pathlib import Path
import numpy as np

from macer.pimd import energy, thermostat, transforms
from macer.pimd.force_bridge import evaluate_bead_forces


K_TO_AU = 8.617333262145e-5 / 27.211396132
ANG_TO_AU = 1.0 / 0.529177249
EVA3_PER_AU_STRESS = 27.211386245988 / (0.529177210903**3)
# 1 atomic-unit stress (Hartree / Bohr^3) = 29421.01 GPa.
AU_STRESS_TO_GPA = 29421.01


def _matrix_exp_clipped(mat: np.ndarray, clip: float) -> np.ndarray:
    """Stable matrix exponential with eigenvalue clipping."""
    try:
        eigvals, eigvecs = np.linalg.eig(mat)
        eigvals = np.clip(np.real(eigvals), -clip, clip)
        exp_diag = np.diag(np.exp(eigvals))
        out = eigvecs @ exp_diag @ np.linalg.inv(eigvecs)
        return np.real_if_close(out).astype(float)
    except Exception:
        return np.eye(3, dtype=float) + np.array(mat, dtype=float)


def _apply_linear_to_nm_tensor(tensor: np.ndarray, mat3: np.ndarray) -> np.ndarray:
    """Apply 3x3 linear transform to [3, natom, nbead]-shaped tensors."""
    return np.einsum("ab,bij->aij", mat3, tensor)


def _nm_to_bead(state, tensor_nm: np.ndarray) -> np.ndarray:
    """Convert NM-space tensor [3,natom,nbead] to bead-space."""
    return np.einsum("jk,xik->xij", state.tnm, tensor_nm)


def _bead_to_nm(state, tensor_bead: np.ndarray) -> np.ndarray:
    """Convert bead-space tensor [3,natom,nbead] to NM-space."""
    return np.einsum("jk,xik->xij", state.tnminv, tensor_bead)


def _separate_trace(mat: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    trace_part = (np.trace(mat) / 3.0) * np.eye(3)
    return trace_part, mat - trace_part


def _is_upper_triangular(m: np.ndarray, tol: float = 1e-14) -> bool:
    return abs(m[1, 0]) <= tol and abs(m[2, 0]) <= tol and abs(m[2, 1]) <= tol


def _is_lower_triangular(m: np.ndarray, tol: float = 1e-14) -> bool:
    return _is_upper_triangular(m.T, tol=tol)


def _maketriangular_like_ase(h: np.ndarray, mat: np.ndarray) -> np.ndarray:
    """
    Triangular projection for delta-eta updates.
    Components map as (xx, yy, zz, yz, xz, xy).
    """
    m = np.array(mat, dtype=float)
    xx, yy, zz = m[0, 0], m[1, 1], m[2, 2]
    yz, xz, xy = m[1, 2], m[0, 2], m[0, 1]
    if _is_upper_triangular(h):
        return np.array(
            [[xx, xy, xz], [0.0, yy, yz], [0.0, 0.0, zz]],
            dtype=float,
        )
    if _is_lower_triangular(h):
        return np.array(
            [[xx, 0.0, 0.0], [xy, yy, 0.0], [xz, yz, zz]],
            dtype=float,
        )
    # Fallback for non-triangular cells: keep full matrix.
    return m


def _refresh_pfact(state) -> None:
    pfactor = float(getattr(state, "pfactor", 0.0) or 0.0)
    vol = max(float(abs(np.linalg.det(state.h))), 1e-16)
    state.pfact = (1.0 / (pfactor * vol)) if pfactor > 0.0 else 0.0


def _compute_delta_eta(state, dt: float) -> np.ndarray:
    pfactor = float(getattr(state, "pfactor", 0.0) or 0.0)
    if pfactor <= 0.0:
        return np.zeros((3, 3), dtype=float)
    _refresh_pfact(state)
    # Use locked control-stress snapshot if present to avoid timing drift.
    stress = np.array(
        getattr(state, "_control_stress_for_eta", state.stress_inst),
        dtype=float,
    )
    ext = np.array(state.external_stress, dtype=float)
    return -2.0 * dt * (state.pfact * np.linalg.det(state.h) * (stress - ext))


def _next_eta(state, delta_eta: np.ndarray) -> np.ndarray:
    mask = np.array(getattr(state, "mask", np.ones((3, 3))), dtype=float)
    tri_delta_eta = _maketriangular_like_ase(np.array(state.h, dtype=float), delta_eta)
    eta_trial = np.array(state.eta_past, dtype=float) + mask * tri_delta_eta
    frac = float(getattr(state, "frac_traceless", 1.0))
    if frac == 1.0:
        return eta_trial
    trace_part, traceless_part = _separate_trace(eta_trial)
    return trace_part + frac * traceless_part


def _initialize_centered_history_once(state) -> None:
    """
    One-time backward initialization of centered-difference history,
    following ASE NPT initialization intent:
      h_past <- h - dt * (h @ eta)
      eta_past <- eta - delta_eta(dt)
      zeta_past <- zeta - dt * tfact * (K - K_target)
      q_past <- q - dt * (inv(h) @ v_bead)
    """
    if getattr(state, "_cd_history_initialized", False):
        return

    h_now = np.array(state.h, dtype=float)
    dt = float(state.dt)
    eta_now = np.array(state.eta, dtype=float)

    state.h_past = h_now - dt * (h_now @ eta_now)

    delta_eta_half = _compute_delta_eta(state, 0.5 * dt)
    state.eta_past = np.array(state.eta, dtype=float) - delta_eta_half

    dz_half = dt * float(state.tfact) * (float(state.dkinetic) - float(state.desired_ekin))
    state.zeta_past = float(state.zeta) - dz_half

    # Two-pass q_past/q_future initialization generalized for bead tensors.
    inv_h = np.linalg.inv(h_now)
    transforms.nmtrans_ur2r(state)
    q_now = np.einsum("ab,bij->aij", inv_h, state.r) - 0.5
    v_bead0 = _nm_to_bead(state, np.asarray(state.vur, dtype=float))
    v_bead = np.array(v_bead0, copy=True)
    q_past = np.array(q_now, copy=True)
    q_future = np.array(q_now, copy=True)

    # Two-pass momentum correction:
    #   v <- (2*v0 - v_est) after each provisional q_future.
    for _ in range(2):
        q_past = q_now - dt * np.einsum("ab,bij->aij", inv_h, v_bead)
        q_future = _compute_q_future_from_force(
            state=state,
            h_current=h_now,
            eta=np.array(state.eta, dtype=float),
            zeta=float(state.zeta),
            q_now=q_now,
            q_past=q_past,
            fr_now=np.asarray(state.fr, dtype=float),
        )
        v_est = _bead_velocity_from_q_history(h_now, q_past, q_future, dt)
        if _ekin_like_ase_from_velocity(state, v_est) < 1.0e-5:
            v_bead = v_est
            break
        v_bead = (2.0 * v_bead0) - v_est

    state.q_scaled = q_now
    state.q_scaled_past = q_past
    state.q_scaled_future = q_future
    state.vur = _bead_to_nm(state, v_bead)
    transforms.nmtrans_ur2r(state)

    state._cd_history_initialized = True


def _ensure_fractional_state(state) -> None:
    """Lazily initialize fractional centered-difference state for all beads."""
    if hasattr(state, "q_scaled") and hasattr(state, "q_scaled_past") and hasattr(state, "q_scaled_future"):
        return
    inv_h = np.linalg.inv(np.array(state.h, dtype=float))
    transforms.nmtrans_ur2r(state)
    # q in column form: r = h @ (q + 0.5)
    q_now = np.einsum("ab,bij->aij", inv_h, state.r) - 0.5
    # Backward estimate from current bead velocities.
    v_bead = _nm_to_bead(state, np.asarray(state.vur, dtype=float))
    q_past = q_now - state.dt * np.einsum("ab,bij->aij", inv_h, v_bead)
    state.q_scaled = q_now
    state.q_scaled_past = q_past
    state.q_scaled_future = np.array(q_now, copy=True)


def _compute_q_future_from_force(
    state,
    h_current: np.ndarray,
    eta: np.ndarray,
    zeta: float,
    q_now: np.ndarray,
    q_past: np.ndarray,
    fr_now: np.ndarray,
) -> np.ndarray:
    """Centered-difference recurrence for q_future (all beads)."""
    id3 = np.eye(3, dtype=float)
    inv_h = np.linalg.inv(h_current)
    # Column-vector form equivalent of ASE row update:
    # q_future = (2q + q_past*(beta-I) + alpha) @ inv(beta+I)
    # Here: q_future_col = inv((beta+I)^T) [2q_col + (beta-I)^T q_past_col + alpha_col]
    beta = state.dt * (h_current @ (eta + 0.5 * zeta * id3) @ inv_h)
    lhs_inv_t = np.linalg.inv((beta + id3).T)

    masses = np.asarray(state.physmass, dtype=float)  # [natom]
    q_future = np.empty_like(q_now, dtype=float)

    for ibead in range(state.nbead):
        accel = fr_now[:, :, ibead] / masses[np.newaxis, :]
        alpha = (state.dt**2) * (inv_h @ accel)
        rhs = (
            2.0 * q_now[:, :, ibead]
            + (beta - id3).T @ q_past[:, :, ibead]
            + alpha
        )
        q_future[:, :, ibead] = lhs_inv_t @ rhs

    return q_future


def _q_recurrence_residual(
    state,
    h_current: np.ndarray,
    eta: np.ndarray,
    zeta: float,
    q_now: np.ndarray,
    q_past: np.ndarray,
    q_future: np.ndarray,
    fr_now: np.ndarray,
) -> float:
    """Return max-abs residual of ASE recurrence in column form."""
    q_ref = _compute_q_future_from_force(
        state=state,
        h_current=h_current,
        eta=eta,
        zeta=zeta,
        q_now=q_now,
        q_past=q_past,
        fr_now=fr_now,
    )
    return float(np.max(np.abs(np.asarray(q_future, dtype=float) - q_ref)))


def _bead_velocity_from_q_history(
    h_current: np.ndarray, q_past: np.ndarray, q_future: np.ndarray, dt: float
) -> np.ndarray:
    """Centered-difference bead velocity from q-history (ASE momentum-equivalent)."""
    return np.einsum("ab,bij->aij", h_current, (q_future - q_past) / (2.0 * dt))


def _ekin_like_ase_from_velocity(state, v_bead: np.ndarray) -> float:
    """
    Kinetic indicator from bead velocities.
    Mirrors ekin(p,m) role used in ASE _calculate_q_past_and_future.
    """
    masses = np.asarray(state.physmass, dtype=float)[np.newaxis, :, np.newaxis]
    p = masses * v_bead
    p2 = np.sum(p * p, axis=0)
    return 0.5 * float(np.sum(p2 / masses[0])) / float(max(state.natom, 1))


def _run_velocity_force_split_only(state, config, gkt: float, omega_p2: float) -> None:
    """
    NPT split stage restricted to velocity/force-side updates.
    Position owners (`q_scaled*` and `ur`) must remain unchanged in this stage.
    """
    ur_before = np.array(state.ur, copy=True)
    q_before = (
        np.array(getattr(state, "q_scaled", state.ur), copy=True),
        np.array(getattr(state, "q_scaled_past", state.ur), copy=True),
        np.array(getattr(state, "q_scaled_future", state.ur), copy=True),
    )

    coupling = np.array(state.eta, dtype=float) + 0.5 * float(state.zeta) * np.eye(3)
    vel_coupling_pre = _matrix_exp_clipped(-0.5 * state.dt * coupling, 0.20)
    vel_coupling_ref = _matrix_exp_clipped(-0.5 * state.dt_ref * coupling, 0.05)

    thermostat.nhc_integrate_cent3(state, state.dt, gkt)
    state.vur = _apply_linear_to_nm_tensor(state.vur, vel_coupling_pre)
    transforms.Vupdate(state, state.dt)

    for _iref in range(1, config.nref + 1):
        thermostat.nhc_integrate(state, state.dt_ref, gkt)
        state.vur = _apply_linear_to_nm_tensor(state.vur, vel_coupling_ref)
        transforms.Vupdate_Ref(state, state.dt_ref)
        # NOTE: Position update via Uupdate is intentionally prohibited in NPT.
        transforms.get_force_ref(state, omega_p2)
        transforms.Vupdate_Ref(state, state.dt_ref)
        thermostat.nhc_integrate(state, state.dt_ref, gkt)

    ur_after = np.array(state.ur, copy=False)
    if np.max(np.abs(ur_after - ur_before)) > 1.0e-12:
        raise RuntimeError("NPT split-stage mutated ur positions (forbidden).")
    q_after = (
        np.array(getattr(state, "q_scaled", state.ur), copy=False),
        np.array(getattr(state, "q_scaled_past", state.ur), copy=False),
        np.array(getattr(state, "q_scaled_future", state.ur), copy=False),
    )
    if any(np.max(np.abs(a - b)) > 1.0e-12 for a, b in zip(q_after, q_before)):
        raise RuntimeError("NPT split-stage mutated q history (forbidden).")


def _check_npt_invariants(state, *, check_velocity: bool = False) -> None:
    h = np.array(state.h, dtype=float)
    det_h = float(np.linalg.det(h))
    if not np.isfinite(det_h) or det_h <= 0.0:
        raise RuntimeError(f"Invalid cell determinant in NPT step: det(h)={det_h}")

    q = np.asarray(state.q_scaled, dtype=float)
    if not np.all(np.isfinite(q)):
        raise RuntimeError("Non-finite q_scaled detected in NPT step.")

    r_expected = np.einsum("ab,bij->aij", h, q + 0.5)
    r_actual = np.asarray(state.r, dtype=float)
    closure_err = float(np.max(np.abs(r_actual - r_expected)))
    if closure_err > 1.0e-8:
        raise RuntimeError(f"NPT closure invariant failed: max|r-h(q+0.5)|={closure_err:.3e}")

    if check_velocity:
        v_est = _bead_velocity_from_q_history(
            h_current=h,
            q_past=np.asarray(state.q_scaled_past, dtype=float),
            q_future=np.asarray(state.q_scaled_future, dtype=float),
            dt=float(state.dt),
        )
        v_nm_est = _bead_to_nm(state, v_est)
        v_nm = np.asarray(state.vur, dtype=float)
        v_err = float(np.max(np.abs(v_nm - v_nm_est)))
        if v_err > 1.0e-6:
            raise RuntimeError(f"NPT velocity invariant failed: max|vur-v_recon|={v_err:.3e}")


def _append_npt_step_trace(
    state,
    config,
    *,
    step: int,
    h_used: np.ndarray,
    eta_used: np.ndarray,
    zeta_used: float,
    h_future: np.ndarray | None = None,
    eta_future: np.ndarray | None = None,
    zeta_future: float | None = None,
) -> None:
    """
    Append compact step trace for first few steps to diagnose q-seed parity.
    Always-on for NPT, limited to early steps to keep file size small.
    """
    if not bool(getattr(config, "npt_trace", False)):
        return
    if step > 20:
        return
    out_dir = Path(getattr(config, "output_dir", "."))
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / "npt_step_trace_pimd.jsonl"
    q = np.asarray(state.q_scaled, dtype=float)
    q_p = np.asarray(state.q_scaled_past, dtype=float)
    q_f = np.asarray(state.q_scaled_future, dtype=float)
    fr = np.asarray(state.fr, dtype=float)
    rec_res = _q_recurrence_residual(
        state=state,
        h_current=np.asarray(h_used, dtype=float),
        eta=np.asarray(eta_used, dtype=float),
        zeta=float(zeta_used),
        q_now=q,
        q_past=q_p,
        q_future=q_f,
        fr_now=fr,
    )
    k_control_au = float(getattr(state, "_control_dkin_for_zeta", state.dkinetic))
    k_target_au = float(state.desired_ekin)
    (
        static_stress,
        spring_stress,
        kin_stress,
        control_stress,
        p_display_gpa,
    ) = energy.build_npt_stress_components(
        state,
        k_control_au=k_control_au,
    )
    vol_au3 = float(abs(np.linalg.det(np.asarray(state.h, dtype=float))))
    kin_trace_au = float(np.trace(np.asarray(kin_stress, dtype=float)))
    delta_zeta = float(
        2.0 * float(state.dt) * float(state.tfact) * (k_control_au - k_target_au)
    )
    delta_eta = _compute_delta_eta(state, float(state.dt))
    v_a3 = float(vol_au3 / (ANG_TO_AU**3))
    h_trace_a = float(np.trace(np.asarray(state.h, dtype=float)) / ANG_TO_AU)
    record = {
        "step": int(step),
        "stage": "pre_commit",
        "q_norm": float(np.linalg.norm(q)),
        "q_past_norm": float(np.linalg.norm(q_p)),
        "q_future_norm": float(np.linalg.norm(q_f)),
        "q_recurrence_residual_maxabs": rec_res,
        "P_display_GPa": float(p_display_gpa),
        "P_static_GPa": float(-np.trace(np.asarray(static_stress, dtype=float)) / 3.0 * AU_STRESS_TO_GPA),
        "P_spring_GPa": float(-np.trace(np.asarray(spring_stress, dtype=float)) / 3.0 * AU_STRESS_TO_GPA),
        "P_kin_GPa": float(-np.trace(np.asarray(kin_stress, dtype=float)) / 3.0 * AU_STRESS_TO_GPA),
        "V_A3": v_a3,
        "stress_control_trace_au": float(np.trace(np.asarray(control_stress, dtype=float))),
        "sigma_control_trace_au": float(np.trace(np.asarray(control_stress, dtype=float))),
        "sigma_static_trace_au": float(np.trace(static_stress)),
        "sigma_spring_trace_au": float(np.trace(spring_stress)),
        "sigma_kin_trace_au": kin_trace_au,
        "delta_eta_trace": float(np.trace(delta_eta)),
        "K_control_au": k_control_au,
        "K_target_au": k_target_au,
        "delta_zeta": delta_zeta,
        "pressure_control_GPa": float(-np.trace(np.asarray(control_stress, dtype=float)) / 3.0 * AU_STRESS_TO_GPA),
        "h_trace_A": h_trace_a,
        "h_det_A3": v_a3,
        "dkin_au": float(state.dkinetic),
        "temp_k": float(state.temp_inst),
        "zeta": float(state.zeta),
        "eta_trace": float(np.trace(np.asarray(state.eta, dtype=float))),
        "pfact": float(getattr(state, "pfact", np.nan)),
        "h_trace_au": float(np.trace(np.asarray(state.h, dtype=float))),
        "h_det_au3": float(np.linalg.det(np.asarray(state.h, dtype=float))),
        "h_residual_maxabs": None,
        "eta_residual_maxabs": None,
        "zeta_residual_abs": None,
        "h_future_trace_au": None,
        "eta_future_trace": None,
        "zeta_future": None,
    }
    if h_future is not None:
        h_pred = np.asarray(state.h_past, dtype=float) + 2.0 * float(state.dt) * (
            np.asarray(state.h, dtype=float) @ np.asarray(state.eta, dtype=float)
        )
        record["h_residual_maxabs"] = float(np.max(np.abs(np.asarray(h_future, dtype=float) - h_pred)))
        record["h_future_trace_au"] = float(np.trace(np.asarray(h_future, dtype=float)))
    if eta_future is not None:
        de = _compute_delta_eta(state, float(state.dt))
        eta_pred = _next_eta(state, de)
        record["eta_residual_maxabs"] = float(np.max(np.abs(np.asarray(eta_future, dtype=float) - eta_pred)))
        record["eta_future_trace"] = float(np.trace(np.asarray(eta_future, dtype=float)))
    if zeta_future is not None:
        zeta_pred = float(state.zeta_past) + 2.0 * float(state.dt) * float(state.tfact) * (
            float(getattr(state, "_control_dkin_for_zeta", state.dkinetic)) - float(state.desired_ekin)
        )
        record["zeta_residual_abs"] = float(abs(float(zeta_future) - zeta_pred))
        record["zeta_future"] = float(zeta_future)
    with path.open("a") as f:
        f.write(json.dumps(record) + "\n")


def step_npt(integrator) -> np.ndarray:
    state = integrator.state
    config = integrator.config

    beta = 1.0 / (config.temp * K_TO_AU)
    gkt = 1.0 / beta
    omega_p2 = float(state.nbead) / (beta**2)

    # ---------------------------------------------------------------------
    # Unified NPT state machine (all nbead, no exception branch):
    #   1) sample current observables/stress
    #   2) compute h/eta/zeta futures
    #   3) rotate q-history (q_past <- q, q <- q_future)
    #   4) rotate barostat state (h_past/h, eta_past/eta, zeta_past/zeta)
    #   5) materialize r from q only: r = h @ (q + 0.5)
    #   6) evaluate new force/stress
    #   7) compute next q_future
    #   8) sync velocities from centered difference
    #
    # Coordinate ownership policy in NPT:
    #   q-history is the single source of truth for positions.
    #   No parallel direct coordinate integrator path is allowed.
    # ---------------------------------------------------------------------
    # Lock current stress/kinetic state for eta/zeta forcing.
    energy.calculate_observables(state, beta, K_TO_AU)
    state._control_stress_for_eta = np.array(state.stress_inst, copy=True)
    state._control_dkin_for_zeta = float(state.dkinetic)

    # Keep aliases in sync.
    state.h = np.array(state.cell, dtype=float)
    h_current = np.array(state.h, dtype=float)
    _initialize_centered_history_once(state)

    # Centered-difference targets based on current stress/kinetic state.
    # eta controls cell-rate, so h advances by:
    #   h_future = h_past + 2*dt*(h @ eta)
    h_future = np.array(state.h_past, dtype=float) + 2.0 * state.dt * (state.h @ state.eta)
    eta_future = _next_eta(state, _compute_delta_eta(state, state.dt))
    # zeta is the thermostat friction variable; it advances from kinetic-energy error:
    #   zeta_future = zeta_past + 2*dt*tfact*(K_control - K_target)
    zeta_future = float(state.zeta_past) + 2.0 * state.dt * float(state.tfact) * (
        float(getattr(state, "_control_dkin_for_zeta", state.dkinetic)) - float(state.desired_ekin)
    )
    # Ensure q-history exists before recurrence update.
    _ensure_fractional_state(state)
    if not getattr(state, "_q_future_initialized", False):
        state.q_scaled_future = _compute_q_future_from_force(
            state=state,
            h_current=h_current,
            eta=np.array(state.eta, dtype=float),
            zeta=float(state.zeta),
            q_now=np.asarray(state.q_scaled, dtype=float),
            q_past=np.asarray(state.q_scaled_past, dtype=float),
            fr_now=np.asarray(state.fr, dtype=float),
        )
        state._q_future_initialized = True
    _append_npt_step_trace(
        state,
        config,
        step=int(getattr(state, "istepsv", 0)),
        h_used=np.asarray(h_current, dtype=float),
        eta_used=np.asarray(state.eta, dtype=float),
        zeta_used=float(state.zeta),
        h_future=np.asarray(h_future, dtype=float),
        eta_future=np.asarray(eta_future, dtype=float),
        zeta_future=float(zeta_future),
    )

    # Commit cell/strain state.
    state.h_past = np.array(state.h, copy=True)
    state.h = np.array(h_future, dtype=float)
    state.cell = np.array(state.h, copy=True)
    state.eta_past = np.array(state.eta, copy=True)
    state.eta = np.array(eta_future, dtype=float)
    state.zeta_past = float(state.zeta)
    state.zeta = float(zeta_future)
    # Integral of zeta used in conserved-energy bookkeeping.
    state.zeta_integrated += state.dt * state.zeta

    integrator.atoms.set_cell(state.cell / ANG_TO_AU)

    # q history rotation: q_past <- q, q <- q_future.
    q_now = np.asarray(state.q_scaled, dtype=float)
    q_future_ready = np.asarray(state.q_scaled_future, dtype=float)
    state.q_scaled_past = q_now
    state.q_scaled = q_future_ready

    # r = h @ (q + 0.5), then map back to normal modes.
    state.r = np.einsum("ab,bij->aij", state.h, state.q_scaled + 0.5)
    _check_npt_invariants(state, check_velocity=False)
    transforms.nmtrans_r2ur(state)

    transforms.nmtrans_ur2r(state)
    for ibead in range(state.nbead):
        state.r_list[ibead].set_positions(state.r[:, :, ibead].T / ANG_TO_AU)
        state.r_list[ibead].set_cell(state.cell / ANG_TO_AU)

    calc = integrator.atoms.calc
    inv_nbead = 1.0 / float(state.nbead)
    forces, energies, stresses = evaluate_bead_forces(
        calc,
        state.r_list,
        need_stress=True,
        batch_size=getattr(config, "batch_size", None),
        sequential=bool(getattr(config, "sequential", False)),
        label=f"Cycle {int(getattr(state, 'istepsv', 0)) + 1:03d} force eval",
    )

    from ase.constraints import voigt_6_to_full_3x3_stress

    if stresses is None:
        raise RuntimeError("NPT step requires stress results, but got None.")

    for ibead in range(state.nbead):
        state.fr[:, :, ibead] = (np.array(forces[ibead], dtype=float).T / 51.422067) * inv_nbead
        state.pot_beads[ibead] = (float(energies[ibead]) / 27.211386) * inv_nbead
        s_raw = np.array(stresses[ibead], dtype=float)
        if s_raw.shape == (6,):
            s_3x3 = voigt_6_to_full_3x3_stress(s_raw)
        elif s_raw.shape == (3, 3):
            s_3x3 = s_raw
        else:
            raise ValueError(f"Unsupported stress shape in PIMD batch eval: {s_raw.shape}")
        state.stress_beads[:, :, ibead] = (s_3x3 / EVA3_PER_AU_STRESS) * inv_nbead

    # PIMD split stage: velocity/force-side coupling only.
    # Kept after state rotation/materialization/force evaluation.
    _run_velocity_force_split_only(state, config, gkt, omega_p2)

    transforms.nmtrans_fr2fur(state)
    transforms.Vupdate(state, state.dt)

    # Compute next q_future using newly evaluated force at current q.
    state.q_scaled_future = _compute_q_future_from_force(
        state=state,
        h_current=np.array(state.h, dtype=float),
        eta=np.array(state.eta, dtype=float),
        zeta=float(state.zeta),
        q_now=np.asarray(state.q_scaled, dtype=float),
        q_past=np.asarray(state.q_scaled_past, dtype=float),
        fr_now=np.asarray(state.fr, dtype=float),
    )
    # Momentum-equivalent sync: reconstruct v from q_future - q_past
    v_bead_centered = _bead_velocity_from_q_history(
        np.array(state.h, dtype=float),
        np.asarray(state.q_scaled_past, dtype=float),
        np.asarray(state.q_scaled_future, dtype=float),
        float(state.dt),
    )
    state.vur = _bead_to_nm(state, v_bead_centered)
    _check_npt_invariants(state, check_velocity=True)

    # Final observable refresh after new force/stress and centered velocity sync.
    energy.calculate_observables(state, beta, K_TO_AU)
    state.istepsv += 1

    integrator.atoms.set_cell(state.cell / ANG_TO_AU, scale_atoms=False)
    integrator.atoms.set_positions(state.ur[:, :, 0].T / ANG_TO_AU)
    return state.fr
