import os
import subprocess
import pandas as pd
import numpy as np
import time

PYTHON_EXE = "/opt/homebrew/Caskroom/miniforge/base/bin/python"

def run_simulation(command_type, poscar, nsteps, temp, ff, nbead, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    cmd = [
        PYTHON_EXE, "-m", "macer.cli.main", command_type,
        "-p", poscar,
        "-T", str(temp),
        "--nsteps", str(nsteps),
        "--ff", ff,
        "--nbead", str(nbead),
        "--seed", "42",
        "--output-dir", out_dir
    ]
    print(f"Running {command_type}: {' '.join(cmd)}")
    t0 = time.time()
    with open(os.path.join(out_dir, "stdout.log"), "w") as f:
        subprocess.run(cmd, check=True, stdout=f, stderr=subprocess.STDOUT)
    t1 = time.time()
    return t1 - t0

def parse_legacy_results(out_dir):
    ham_path = os.path.join(out_dir, "Result", "ham.dat")
    if not os.path.exists(ham_path):
        # Maybe it's directly in out_dir? Legacy often puts it in Result/
        ham_path = os.path.join(out_dir, "ham.dat")
    
    if not os.path.exists(ham_path):
        print(f"Warning: Legacy ham.dat not found in {out_dir}")
        return None
        
    df = pd.read_csv(ham_path, sep=r"\s+", comment="#", header=None)
    # 0:Step 1:Ham 2:Temp 3:Pot 4:DKin 5:QKin 6:EBath 7:EBathCent 8:EVirial
    df.columns = ["step", "ham", "temp", "pot", "dkin", "qkin", "ebath", "ebath_cent", "evirial"]
    return df

def parse_ase_results(out_dir):
    ham_path = os.path.join(out_dir, "ham.dat")
    if not os.path.exists(ham_path):
        print(f"Warning: ASE ham.dat not found in {out_dir}")
        return None
    df = pd.read_csv(ham_path, sep=r"\s+", comment="#", header=None)
    df.columns = ["step", "ham_ase", "temp_ase", "pot_ase", "dkin_ase", "qkin_ase", "ebath_ase", "ebath_cent_ase", "evirial_ase"]
    return df

def compare():
    poscar = "workdir/POSCAR_H2O_50K"
    nsteps = 200
    temp = 300 # Using 300K for stability in EMT for now
    ff = "emt"
    nbead = 4
    
    legacy_dir = "workdir/verify_legacy"
    ase_dir = "workdir/verify_ase"
    
    # 1. Run Legacy
    print("\n--- Phase 1: Legacy Run ---")
    t_legacy = run_simulation("pimd", poscar, nsteps, temp, ff, nbead, legacy_dir)
    print(f"Legacy Wall Time: {t_legacy:.2f} s")
    
    # 2. Run ASE
    print("\n--- Phase 2: ASE Run ---")
    t_ase = run_simulation("pimd", poscar, nsteps, temp, ff, nbead, ase_dir)
    print(f"ASE Wall Time: {t_ase:.2f} s")
    
    print(f"\nSPEED RATIO (Legacy/ASE): {t_legacy/t_ase:.2f}x")
    
    # 3. Compare
    print("\n--- Phase 3: Comparison ---")
    df_legacy = parse_legacy_results(legacy_dir)
    df_ase = parse_ase_results(ase_dir)
    
    if df_legacy is not None and df_ase is not None:
        merged = pd.merge(df_legacy, df_ase, on="step")
        
        ham_diff = np.abs(merged["ham"] - merged["ham_ase"])
        temp_diff = np.abs(merged["temp"] - merged["temp_ase"])
        
        print(f"Total Steps Compared: {len(merged)}")
        print(f"Hamiltonian Max Diff: {ham_diff.max():.2e} AU")
        print(f"Temperature Max Diff: {temp_diff.max():.2e} K")
        
        if ham_diff.max() < 1e-4 and temp_diff.max() < 1.0:
            print("\nRESULT: SUCCESS - Engines are consistent!")
        else:
            print("\nRESULT: WARNING - Large deviations detected.")
            # Print sample
            print(merged[["step", "ham", "ham_ase", "temp", "temp_ase"]].tail(10))

if __name__ == "__main__":
    compare()
