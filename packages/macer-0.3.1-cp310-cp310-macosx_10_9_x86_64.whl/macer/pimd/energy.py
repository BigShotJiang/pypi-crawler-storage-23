import numpy as np
from macer.pimd.state import PIMDASEState

# Unit conversion for stress:
# 1 atomic-unit stress (Hartree / Bohr^3) = 29421.01 GPa.
AU_STRESS_TO_GPA = 29421.01

def get_kinetic_ene(state: PIMDASEState):
    """
    Total kinetic energy of the beads in NM space.
    """
    # 0.5 * sum_ij fictmass[i,j] * |v[i,j]|^2
    v2 = np.sum(state.vur**2, axis=0) # [natom, nbead]
    return 0.5 * np.sum(state.fictmass * v2)


def get_centroid_kinetic_ene(state: PIMDASEState):
    """
    Physical centroid kinetic energy used for NPT ideal-gas stress control.
    This reduces to the standard ASE kinetic term at nbead=1.
    """
    v0_2 = np.sum(state.vur[:, :, 0] ** 2, axis=0)  # [natom]
    return 0.5 * np.sum(state.physmass * v0_2)


def get_spring_stress_tensor(state: PIMDASEState):
    """
    Ring-polymer spring stress estimator in bead space.
    Stress convention follows ASE (tension-positive):
      sigma = -(1/V) * <sum_i r_i (x) f_i>_bead
    where f_i is the spring force contribution.
    """
    if state.nbead <= 1:
        return np.zeros((3, 3), dtype=float)
    # Use NM-space internal-mode virial to avoid basis-scaling artifacts:
    #   sigma_spring = -(1/V) * (1/nbead) * sum_{i,m>0} (u_im \otimes f_im^spring)
    # where u_im and f_im are NM coordinates/forces for internal modes.
    ur_int = state.ur[:, :, 1:]
    f_ref_int = state.f_ref[:, :, 1:]
    virial = np.einsum("aim,bim->ab", ur_int, f_ref_int) / float(state.nbead)
    vol = max(float(np.linalg.det(state.cell)), 1.0e-16)
    return -virial / vol


def build_npt_stress_components(
    state: PIMDASEState,
    k_control_au: float | None = None,
):
    """
    Single-source NPT stress assembly for control and diagnostics.
    Returns:
      static_stress, spring_stress, kin_stress, control_stress, p_display_gpa
    """
    static_stress = np.sum(state.stress_beads, axis=2)
    spring_stress = get_spring_stress_tensor(state)
    physical_stress = static_stress + spring_stress

    vol = max(float(np.linalg.det(state.cell)), 1.0e-16)
    if k_control_au is None:
        k_control_au = float(getattr(state, "dkinetic_centroid", state.dkinetic))
    kin_stress = -(2.0 * float(k_control_au) / (3.0 * vol)) * np.eye(3)

    # Fixed control stress: static + spring + kinetic.
    control_stress = physical_stress + kin_stress

    p_display_gpa = -np.trace(physical_stress) / 3.0 * AU_STRESS_TO_GPA
    return static_stress, spring_stress, kin_stress, control_stress, float(p_display_gpa)

def calculate_observables(state: PIMDASEState, beta: float, ktoau: float):
    """
    Ported from macer/pimd/calc_energy.py:ham_temp
    """
    # 1. Classical kinetic energy
    state.dkinetic = get_kinetic_ene(state)
    state.dkinetic_centroid = get_centroid_kinetic_ene(state)
    
    # 2. Temperature (K)
    # P.temp = 2.0 * dkinetic / (P.Natom * P.KtoAU * 3.0) / P.Nbead
    state.temp_inst = 2.0 * state.dkinetic / (state.natom * ktoau * 3.0) / state.nbead
    
    # 3. Quantum kinetic energy (Spring potential)
    ur2 = np.sum(state.ur[:, :, 1:]**2, axis=0) # [natom, nbead-1]
    omega_p2 = float(state.nbead) / (beta**2)
    state.qkinetic = 0.5 * np.sum(state.dnmmass[:, 1:] * omega_p2 * ur2)
    
    # 4. Bath energy
    gkt = 1.0 / beta 
    # Non-centroid
    v_bath_2 = np.sum(state.vrbath[:,:,:,1:]**2, axis=0) # [natom, nnhc, nbead-1]
    state.ebath = 0.5 * np.sum(state.qmass[1:] * np.sum(v_bath_2, axis=(0, 1)))
    state.ebath += gkt * np.sum(state.rbath[:,:,:,1:])
    
    # Centroid
    v_bc31_2 = np.sum(state.vrbc31**2, axis=0) # [natom, nnhc]
    state.ebath_cent = 0.5 * np.sum(state.qmcent31 * np.sum(v_bc31_2, axis=0))
    state.ebath_cent += gkt * np.sum(state.rbc31)
    
    # 5. Hamiltonian
    state.potential = np.sum(state.pot_beads)
    state.hamiltonian = state.dkinetic + state.potential + state.qkinetic + state.ebath + state.ebath_cent
    
    # 5b. Stress and Pressure (NPT)
    if hasattr(state, 'cell'):
        (
            _static_stress,
            _spring_stress,
            _kin_stress,
            control_stress,
            p_display_gpa,
        ) = build_npt_stress_components(
            state,
            k_control_au=float(state.dkinetic_centroid),
        )
        state.stress_inst = control_stress
        state.pressure_inst = p_display_gpa
    
    # 6. Virial
    state.e_virial = virial_estimator(state, beta)

def virial_estimator(state: PIMDASEState, beta: float):
    """
    Ported from macer/pimd/calc_energy.py:virial_estimator
    """
    # diff = P.r[:, iatom, imode] - P.ur[:, iatom, 0]
    # E_Virial += np.dot(P.fr[:, iatom, imode], diff)
    
    # state.r is [3, natom, nbead]
    # state.ur[:,:,0] is [3, natom] -> expand to [3, natom, nbead]
    centroid = state.ur[:, :, 0][:, :, np.newaxis]
    diff = state.r - centroid
    
    # fr * diff elementwise then sum
    inner_prod_sum = np.sum(state.fr * diff)
    
    e_virial_corr = -0.5 * inner_prod_sum
    e_virial_base = 1.5 * float(state.natom) / beta
    
    return e_virial_base + e_virial_corr
