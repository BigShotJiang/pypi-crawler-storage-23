import numpy as np
from ase.build import bulk
from ase.calculators.emt import EMT
from macer.pimd.initialize import initialize_state
from macer.pimd.integrators import PIMDIntegrator
import argparse

def test_pimd_standalone():
    print("--- PIMD Standalone Test (EMT Calculator) ---")
    
    # 1. Setup Atoms (Bulk Al)
    atoms = bulk('Al', 'fcc', a=4.05)
    atoms.calc = EMT()
    
    # 2. Mock Config
    config = argparse.Namespace(
        temp=300.0,
        nbead=4,
        tstep=0.5,
        ensemble="nvt",
        nnhc=4,
        nref=1,
        nys=5,
        ttau=0.0,
        ttau_effective=10.0,
        seed=42,
        output_dir="workdir/test_standalone",
        print_every=1,
        nsteps=5
    )
    
    # 3. Initialize State
    print("[Test] Initializing state...")
    state = initialize_state(atoms, config)
    
    # 4. Initialize Integrator
    print("[Test] Setting up integrator...")
    dyn = PIMDIntegrator(
        atoms=atoms,
        timestep=config.tstep,
        state=state,
        config=config,
        logfile=None
    )
    
    # 5. Run
    print("[Test] Starting run (5 steps)...")
    try:
        dyn.run(steps=5)
        print("[Test] Run completed successfully!")
        
        # Check observables
        print(f"[Test] Final Temp: {state.temp_inst:.2f} K")
        print(f"[Test] Final Hamiltonian: {state.hamiltonian:.6f} AU")
    except Exception as e:
        print(f"[Test] Run failed with error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_pimd_standalone()
