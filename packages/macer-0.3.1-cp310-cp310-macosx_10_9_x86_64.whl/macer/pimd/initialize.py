import numpy as np
from macer.pimd.state import PIMDASEState

# Constants (matching original PIMD)
# pi       = 3.141592653589793
# fs2AU    = 1.0 / 0.024188843
# factmass = 1.6605402e-27 / 9.1093897e-31
# KtoAU    = 8.617333262145e-5 / 27.211396132
# AngtoAU  = 1.0 / 0.529177249

FS2AU = 1.0 / 0.024188843
FACTMASS = 1.6605402e-27 / 9.1093897e-31
K_TO_AU = 8.617333262145e-5 / 27.211396132
ANG_TO_AU = 1.0 / 0.529177249
H_TO_K = 1.0 / K_TO_AU
REF_THERMOSTAT_FREQ_THz = 10.0
REF_OMEGA_SYSTEM_AU = 2.0 * np.pi / (REF_THERMOSTAT_FREQ_THz * FS2AU)
DEFAULT_RANDOM_SEED = 101
# Unit conversion for stress:
# 1 atomic-unit stress (Hartree / Bohr^3) = 29421.01 GPa.
AU_STRESS_TO_GPA = 29421.01


def _effective_gamma_from_config(config) -> float:
    """Match external-wrapper gamma bridge policy for equivalence."""
    base_ttau = 40.0 * float(config.tstep)
    ttau = float(getattr(config, "ttau", 0.0) or 0.0)
    ttau_eff = ttau if ttau > 0.0 else base_ttau
    gamma_base = float(max(int(getattr(config, "igamma", 1) or 1), 1))
    gamma_eff = gamma_base * (base_ttau / max(ttau_eff, 1.0e-12))
    return float(max(gamma_eff, 1.0e-6))


def setup_time_mass(state: PIMDASEState, config):
    """
    Ported from macer/pimd/set_ini_md.py:setup_time_mass
    """
    # Equivalence policy with external QM path:
    # keep reference substep as dt / nref for all PIMD ensembles.
    # (External wrapper drives Isimulation=0 path, which uses dt_ref=dt/Nref.)
    state.dt_ref = state.dt / float(config.nref)

    # Beta in AU
    beta = 1.0 / (config.temp * K_TO_AU)
    temp_au = config.temp * K_TO_AU
    
    # Centroid bath masses
    if config.ensemble in ["nvt", "npt"]: 
        # Reference policy (external core): fixed system frequency basis (10 THz).
        omega2 = REF_OMEGA_SYSTEM_AU**2

        # Reference-equivalent centroid chain mass:
        # Q_cent,1 = 3 * Natom / (beta * omega^2)
        state.qmcent31[0] = 3.0 * float(state.natom) / beta / omega2
        for inhc in range(1, config.nnhc):
            state.qmcent31[inhc] = 1.0 / beta / omega2

    # Barostat mass W and Barostat NHC masses qb_baro
    if config.ensemble == "npt":
        # Use a much gentler default for barostat than thermostat auto-ttau.
        # (NVT path is untouched; this applies to NPT only.)
        ptau = config.ptau if config.ptau > 0 else 1000.0
        omega_p = 1.0 / (ptau * FS2AU)
        omega_p2 = omega_p**2
        # W = (3*N + 1) * kT * tau^2
        state.W = (3.0 * float(state.natom) + 1.0) / beta / omega_p2
        
        # Barostat NHC chain
        state.qb_baro[0] = 1.0 / beta / omega_p2 # Simplification
        for inhc in range(1, config.nnhc):
            state.qb_baro[inhc] = 1.0 / beta / omega_p2

        # NPT control constants.
        # If explicit pfactor is not provided, map ptau to pfactor using a
        # conservative bulk modulus reference (~100 GPa).
        explicit_pfactor = getattr(config, "pfactor", None)
        if explicit_pfactor is not None:
            raw_pfactor = float(explicit_pfactor)
        else:
            ptau_fs = config.ptau if config.ptau > 0 else 1000.0
            ptime_au = ptau_fs * FS2AU
            bulk_au = 100.0 / AU_STRESS_TO_GPA
            raw_pfactor = (ptime_au**2) * bulk_au
        state.pfactor = raw_pfactor
        vol = max(float(abs(np.linalg.det(state.cell))), 1e-16)
        state.pfact = (1.0 / (state.pfactor * vol)) if state.pfactor > 0.0 else 0.0
    else:
        state.pfactor = 0.0
        state.pfact = 0.0

    # Thermostat control constants.
    # In this implementation zeta-coupling is applied to bead-resolved velocities
    # (all RP DOF), and dkinetic is accumulated over all beads. Therefore both the
    # control prefactor and kinetic target must scale with nbead to avoid
    # over-damping at larger bead counts.
    ttau_fs = config.ttau if config.ttau > 0 else 40.0 * config.tstep
    ttime_au = ttau_fs * FS2AU
    n_dof_thermo = 3.0 * float(state.natom) * float(max(state.nbead, 1))
    if ttime_au > 0.0:
        state.tfact = 2.0 / (n_dof_thermo * temp_au * ttime_au * ttime_au)
    else:
        state.tfact = 0.0
    state.desired_ekin = (
        1.5
        * float(max(state.natom - 1, 1))
        * float(max(state.nbead, 1))
        * temp_au
    )

    # Non-centroid mode bath masses
    omega_p = (float(state.nbead) / beta) # standard PIMD omega_p
    omega_p2 = omega_p**2
    
    state.qmass[0] = 0.0
    for imode in range(1, state.nbead):
        # Each mode 'imode' has 3*Natom degrees of freedom? 
        # Actually nhc_integrate uses qmass[imode] for each [3, natom] element.
        # So qmass[imode] should be 1/beta/omega_p2
        state.qmass[imode] = 1.0 / beta / omega_p2

    # Yoshida-Suzuki weights
    if config.nys == 1:
        state.ysweight[0] = 1.0
    elif config.nys == 3:
        w1 = 1.0 / (2.0 - 2.0**(1.0/3.0))
        state.ysweight[0] = w1
        state.ysweight[1] = 1.0 - 2.0 * w1
        state.ysweight[2] = w1
    elif config.nys == 5:
        w1 = 1.0 / (4.0 - 4.0**(1.0/3.0))
        state.ysweight[0] = w1
        state.ysweight[1] = w1
        state.ysweight[2] = 1.0 - 4.0 * w1
        state.ysweight[3] = w1
        state.ysweight[4] = w1

def normal_mode(state: PIMDASEState):
    """
    Ported from macer/pimd/set_ini_md.py:normal_mode
    """
    dp = float(state.nbead)
    sqp = np.sqrt(dp)
    sqpinv = 1.0 / sqp
    dnorm = np.sqrt(2.0 / dp)

    dum = -1.0
    for imode in range(state.nbead):
        state.u[imode, 0] = sqpinv
        state.u[imode, state.nbead - 1] = dum * sqpinv
        dum *= -1.0

    for imode in range(1, (state.nbead - 2) // 2 + 1):
        di = float(imode)
        for jmode in range(state.nbead):
            dj = float(jmode + 1)
            state.u[jmode, 2 * imode - 1] = dnorm * np.cos(2.0 * np.pi * di * dj / dp)
            state.u[jmode, 2 * imode]     = dnorm * np.sin(2.0 * np.pi * di * dj / dp)

    state.uinv = state.u.T.copy()
    state.tnm = sqp * state.u
    state.tnminv = sqpinv * state.uinv

def init_mass(state: PIMDASEState, config):
    """
    Ported from macer/pimd/set_ini_md.py:init_mass
    """
    twopi = 2.0 * np.pi
    dp = float(state.nbead)
    gamma1 = _effective_gamma_from_config(config)
    gamma2 = gamma1**2

    state.dnmmass[:, 0] = 0.0
    for iatom in range(state.natom):
        state.dnmmass[iatom, state.nbead - 1] = 4.0 * dp * state.physmass[iatom]
        for imode in range(1, (state.nbead - 2) // 2 + 1):
            di = float(imode)
            val = 2.0 * (1.0 - np.cos(twopi * di / dp)) * dp * state.physmass[iatom]
            state.dnmmass[iatom, 2 * imode - 1] = val
            state.dnmmass[iatom, 2 * imode]     = val

    # fictmass
    for iatom in range(state.natom):
        state.fictmass[iatom, 0] = state.physmass[iatom]
        for imode in range(1, state.nbead):
            state.fictmass[iatom, imode] = gamma2 * state.dnmmass[iatom, imode]

def init_position(state: PIMDASEState, atoms):
    """
    Initialize positions from ASE atoms.
    Broadcast centroid to all beads.
    """
    pos_ang = atoms.get_positions()
    pos_bohr = pos_ang.T * ANG_TO_AU
    # Centroid (mode 0) is the only one with physical position in this definition
    state.ur[:, :, 0] = pos_bohr
    # Internal modes (1:) remain zero (unless random_coor requested later)
    state.ur[:, :, 1:] = 0.0

def remove_translation_rotation(state: PIMDASEState):
    """
    Ported from macer/pimd/set_ini_md.py:remove_translation_rotation
    """
    delta = 1.0e-5
    for j in range(state.nbead):
        comr = np.zeros(3)
        sumvr = np.zeros(3)
        
        totmas = np.sum(state.fictmass[:, j])
        for k in range(3):
            sumvr[k] = np.sum(state.vur[k, :, j] * state.fictmass[:, j]) / totmas
            comr[k] = np.sum(state.ur[k, :, j] * state.fictmass[:, j]) / totmas

        # Inertia tensor
        inertia = np.zeros((3, 3))
        for i in range(state.natom):
            r = state.ur[:, i, j] - comr
            m = state.fictmass[i, j]
            inertia += m * (np.dot(r, r) * np.identity(3) - np.outer(r, r))

        detmat = np.linalg.det(inertia)
        if detmat <= delta:
            dinvmat = np.zeros((3, 3))
            for k in range(3):
                if abs(inertia[k, k]) > delta:
                    dinvmat[k, k] = 1.0 / inertia[k, k]
        else:
            dinvmat = np.linalg.inv(inertia)

        moment = np.zeros(3)
        for i in range(state.natom):
            r = state.ur[:, i, j] - comr
            v = state.vur[:, i, j]
            m = state.fictmass[i, j]
            moment += m * np.cross(r, v)

        ang_vel = dinvmat @ moment

        for i in range(state.natom):
            r = state.ur[:, i, j] - comr
            state.vur[:, i, j] -= sumvr
            state.vur[:, i, j] -= np.cross(ang_vel, r)

def temp_ctr(state: PIMDASEState, target_temp: float):
    """
    Ported from macer/pimd/mod_md_subroutine.py:temp_ctr
    """
    from macer.pimd.energy import get_kinetic_ene
    kine = get_kinetic_ene(state)
    
    # 3/2 N beads k_B T = K
    # T = 2 * K / (3 * N * P * k_B)
    tempi = 2.0 * kine / (3.0 * float(state.natom) * K_TO_AU * float(state.nbead))
    if tempi > 1e-10:
        temp_scale = np.sqrt(target_temp / tempi)
        state.vur *= temp_scale

def init_velocity(state: PIMDASEState, config, rng):
    """
    Ported from macer/pimd/set_ini_md.py:init_velocity
    """
    beta = 1.0 / (config.temp * K_TO_AU)

    for imode in range(state.nbead):
        for iatom in range(state.natom):
            vsigma = np.sqrt(1.0 / beta / state.fictmass[iatom, imode])
            for k in range(3):
                state.vur[k, iatom, imode] = vsigma * rng.normal(0.0, 1.0)
    
    remove_translation_rotation(state)
    temp_ctr(state, config.temp)

def init_bath(state: PIMDASEState, config, rng):
    """
    Initialize bath variables.
    Ported from macer/pimd/set_ini_md.py:init_bath
    """
    beta = 1.0 / (config.temp * K_TO_AU)
    # Non-centroid
    for imode in range(1, state.nbead):
        vsigma = np.sqrt(1.0 / beta / state.qmass[imode])
        for inhc in range(config.nnhc):
            for iatom in range(state.natom):
                state.vrbath[:, iatom, inhc, imode] = vsigma * rng.normal(0.0, 1.0, size=3)
    
    # Centroid
    if config.ensemble in ["nvt", "npt"]:
        for inhc in range(config.nnhc):
            vsigma = np.sqrt(1.0 / beta / state.qmcent31[inhc])
            for iatom in range(state.natom):
                state.vrbc31[:, iatom, inhc] = vsigma * rng.normal(0.0, 1.0, size=3)
    
    # Barostat
    if config.ensemble == "npt":
        vsigma = np.sqrt(1.0 / beta / state.qb_baro[0]) # Start with isotropic-like
        for inhc in range(config.nnhc):
            state.vb_baro[inhc] = vsigma * rng.normal(0.0, 1.0)

def initialize_state(atoms, config) -> PIMDASEState:
    """
    Orchestrates full state initialization.
    """
    natom = len(atoms)
    # nbead logic from config
    nbead = config.nbead 
    
    # Allocation
    # Convert AMU -> AU (Electron mass)
    factmass = 1.6605402e-27 / 9.1093897e-31 
    physmass_au = atoms.get_masses() * factmass

    state = PIMDASEState(
        natom=natom, nbead=nbead,
        ur=np.zeros((3, natom, nbead)),
        vur=np.zeros((3, natom, nbead)),
        fur=np.zeros((3, natom, nbead)),
        r=np.zeros((3, natom, nbead)),
        vr=np.zeros((3, natom, nbead)),
        fr=np.zeros((3, natom, nbead)),
        pot_beads=np.zeros(nbead),
        stress_beads=np.zeros((3, 3, nbead)),
        f_ref=np.zeros((3, natom, nbead)),
        physmass=physmass_au,
        fictmass=np.zeros((natom, nbead)),
        dnmmass=np.zeros((natom, nbead)),
        u=np.zeros((nbead, nbead)),
        uinv=np.zeros((nbead, nbead)),
        tnm=np.zeros((nbead, nbead)),
        tnminv=np.zeros((nbead, nbead)),
        qmass=np.zeros(nbead),
        rbath=np.zeros((3, natom, config.nnhc, nbead)),
        vrbath=np.zeros((3, natom, config.nnhc, nbead)),
        qmcent31=np.zeros(config.nnhc),
        rbc31=np.zeros((3, natom, config.nnhc)),
        vrbc31=np.zeros((3, natom, config.nnhc)),
        rb_baro=np.zeros(config.nnhc),
        vb_baro=np.zeros(config.nnhc),
        qb_baro=np.zeros(config.nnhc),
        cell=atoms.get_cell().array * ANG_TO_AU,
        h=np.zeros((3, 3)),
        h_past=np.zeros((3, 3)),
        eta=np.zeros((3, 3)),
        eta_past=np.zeros((3, 3)),
        zeta=0.0,
        zeta_past=0.0,
        zeta_integrated=0.0,
        pfactor=0.0,
        pfact=0.0,
        tfact=0.0,
        desired_ekin=0.0,
        mask=np.ones((3, 3)),
        frac_traceless=1.0,
        p_eps=np.zeros((3, 3)),
        W=0.0,
        external_stress=np.zeros((3, 3)),
        stress_inst=np.zeros((3, 3)),
        dt=config.tstep * FS2AU
    )
    
    # NPT Extras
    if config.ensemble == "npt":
        # Match ASE sign convention: external scalar pressure (compression +)
        # maps to stress tensor (-p, -p, -p).
        stress_au = -config.press / AU_STRESS_TO_GPA
        state.external_stress = np.eye(3) * stress_au

    # Cell/strain-rate state initialization.
    state.h = state.cell.copy()
    state.h_past = state.h.copy()
    
    # Run setup functions
    setup_time_mass(state, config)
    normal_mode(state)
    init_mass(state, config)
    init_position(state, atoms)
    seed = int(config.seed) if getattr(config, "seed", None) is not None else DEFAULT_RANDOM_SEED
    rng = np.random.RandomState(seed)
    init_velocity(state, config, rng)
    init_bath(state, config, rng)
    
    # Initialize 'r' from 'ur'
    from macer.pimd.transforms import nmtrans_ur2r
    nmtrans_ur2r(state)
    
    # Initialize 'f_ref'
    from macer.pimd import transforms
    beta = 1.0 / (config.temp * K_TO_AU)
    omega_p2 = float(state.nbead) / (beta**2)
    transforms.get_force_ref(state, omega_p2)

    return state
