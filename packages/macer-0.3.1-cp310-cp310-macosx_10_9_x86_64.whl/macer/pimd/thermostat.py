import numpy as np
from macer.pimd.state import PIMDASEState

def nhc_integrate_cent3(state: PIMDASEState, dt: float, gkt: float):
    """
    Integrates Nosé-Hoover chain thermostats attached to the centroid.
    Matches macer/pimd/nhc_integrate.py logic exactly.
    """
    for iys in range(len(state.ysweight)):
        dt_ys = dt * state.ysweight[iys]

        for iatom in range(state.natom):
            # Element-wise kinetic energy of centroid [3]
            dkinr = state.fictmass[iatom, 0] * state.vur[:, iatom, 0]**2

            # Force for the first thermostat
            frbc31 = np.zeros((3, len(state.qmcent31)))
            frbc31[:, 0] = (dkinr - gkt) / state.qmcent31[0]

            # Higher chain levels
            for inhc in range(1, len(state.qmcent31)):
                prev_v = state.vrbc31[:, iatom, inhc - 1]
                frbc31[:, inhc] = (state.qmcent31[inhc - 1] * prev_v**2 - gkt) / state.qmcent31[inhc]

            # Update thermostat velocities (first half)
            state.vrbc31[:, iatom, -1] += 0.25 * frbc31[:, -1] * dt_ys

            for inhc in range(len(state.qmcent31) - 2, -1, -1):
                v = state.vrbc31[:, iatom, inhc + 1]
                vrfact = np.exp(-0.125 * v * dt_ys)
                state.vrbc31[:, iatom, inhc] = (
                    state.vrbc31[:, iatom, inhc] * vrfact**2 +
                    0.25 * frbc31[:, inhc] * vrfact * dt_ys
                )

            # Update particle velocity scaling factor
            pvrfact = np.exp(-0.5 * state.vrbc31[:, iatom, 0] * dt_ys)

            # Update force for first thermostat again
            frbc31[:, 0] = (pvrfact**2 * dkinr - gkt) / state.qmcent31[0]

            # Update thermostat positions
            state.rbc31[:, iatom, :] += 0.5 * state.vrbc31[:, iatom, :] * dt_ys

            # Update thermostat velocities (second half)
            for inhc in range(len(state.qmcent31) - 1):
                v = state.vrbc31[:, iatom, inhc + 1]
                vrfact = np.exp(-0.125 * v * dt_ys)
                state.vrbc31[:, iatom, inhc] = (
                    state.vrbc31[:, iatom, inhc] * vrfact**2 +
                    0.25 * frbc31[:, inhc] * vrfact * dt_ys
                )
                frbc31[:, inhc + 1] = (state.qmcent31[inhc] * state.vrbc31[:, iatom, inhc]**2 - gkt) / state.qmcent31[inhc + 1]

            # Final velocity update
            state.vrbc31[:, iatom, -1] += 0.25 * frbc31[:, -1] * dt_ys

            # Final particle velocity update
            state.vur[:, iatom, 0] *= pvrfact

def nhc_integrate(state: PIMDASEState, dt_ref: float, gkt: float):
    """
    Integrates Nosé-Hoover chain thermostats for non-centroid modes.
    Matches macer/pimd/nhc_integrate.py logic exactly.
    """
    for iys in range(len(state.ysweight)):
        dt_ys = dt_ref * state.ysweight[iys]

        for imode in range(1, state.nbead):
            for iatom in range(state.natom):
                dkinr = state.fictmass[iatom, imode] * state.vur[:, iatom, imode]**2

                # Force on first NHC [3]
                frbath = np.zeros((3, state.rbath.shape[2]))
                frbath[:, 0] = (dkinr - gkt) / state.qmass[imode]

                for inhc in range(1, state.rbath.shape[2]):
                    v_sq = state.vrbath[:, iatom, inhc-1, imode]**2
                    frbath[:, inhc] = (state.qmass[imode] * v_sq - gkt) / state.qmass[imode]

                # Update thermostat velocities (1st half)
                state.vrbath[:, iatom, -1, imode] += 0.25 * frbath[:, -1] * dt_ys

                for inhc in range(state.rbath.shape[2] - 2, -1, -1):
                    vrfact = np.exp(-0.125 * state.vrbath[:, iatom, inhc+1, imode] * dt_ys)
                    state.vrbath[:, iatom, inhc, imode] = (
                        state.vrbath[:, iatom, inhc, imode] * vrfact**2 +
                        0.25 * frbath[:, inhc] * vrfact * dt_ys
                    )

                # Scaling factor
                pvrfact = np.exp(-0.5 * state.vrbath[:, iatom, 0, imode] * dt_ys)

                # Force re-update
                frbath[:, 0] = (pvrfact**2 * dkinr - gkt) / state.qmass[imode]

                # Position update
                state.rbath[:, iatom, :, imode] += 0.5 * state.vrbath[:, iatom, :, imode] * dt_ys

                # Update thermostat velocities (2nd half)
                for inhc in range(state.rbath.shape[2] - 1):
                    vrfact = np.exp(-0.125 * state.vrbath[:, iatom, inhc+1, imode] * dt_ys)
                    state.vrbath[:, iatom, inhc, imode] = (
                        state.vrbath[:, iatom, inhc, imode] * vrfact**2 +
                        0.25 * frbath[:, inhc] * vrfact * dt_ys
                    )
                    frbath[:, inhc+1] = (state.qmass[imode] * state.vrbath[:, iatom, inhc, imode]**2 - gkt) / state.qmass[imode]

                # Final updates
                state.vrbath[:, iatom, -1, imode] += 0.25 * frbath[:, -1] * dt_ys
                state.vur[:, iatom, imode] *= pvrfact
def nhc_integrate_baro(state: PIMDASEState, dt: float, gkt: float):
    """
    Integrates Nosé-Hoover chain thermostats attached to the barostat.
    Matches the stable MTK pattern with correct momentum scaling.
    """
    if not hasattr(state, 'W') or state.W == 0:
        return

    fr_baro = np.zeros(len(state.qb_baro))

    for iys in range(len(state.ysweight)):
        dt_ys = dt * state.ysweight[iys]

        # Kinetic energy of barostat: trace(p_eps^2)/W.
        p_e = np.trace(state.p_eps) / 3.0
        dkin_baro = p_e**2 / state.W 
        
        # Force on first barostat NHC
        fr_baro[0] = (dkin_baro - gkt) / state.qb_baro[0]
        for inhc in range(1, len(state.qb_baro)):
            fr_baro[inhc] = (state.qb_baro[inhc-1] * state.vb_baro[inhc-1]**2 - gkt) / state.qb_baro[inhc]

        # 1st half
        state.vb_baro[-1] += 0.25 * fr_baro[-1] * dt_ys
        for inhc in range(len(state.qb_baro) - 2, -1, -1):
            vrfact = np.exp(-0.125 * state.vb_baro[inhc+1] * dt_ys)
            state.vb_baro[inhc] = state.vb_baro[inhc] * vrfact**2 + 0.25 * fr_baro[inhc] * vrfact * dt_ys

        # particle scale
        pvrfact = np.exp(-0.5 * state.vb_baro[0] * dt_ys)
        fr_baro[0] = (pvrfact**2 * dkin_baro - gkt) / state.qb_baro[0]

        # position
        state.rb_baro[:] += 0.5 * state.vb_baro[:] * dt_ys

        # 2nd half
        for inhc in range(len(state.qb_baro) - 1):
            vrfact = np.exp(-0.125 * state.vb_baro[inhc+1] * dt_ys)
            state.vb_baro[inhc] = state.vb_baro[inhc] * vrfact**2 + 0.25 * fr_baro[inhc] * vrfact * dt_ys
            fr_baro[inhc+1] = (state.qb_baro[inhc] * state.vb_baro[inhc]**2 - gkt) / state.qb_baro[inhc+1]

        state.vb_baro[-1] += 0.25 * fr_baro[-1] * dt_ys
        # Scale barostat momentum
        state.p_eps *= pvrfact
