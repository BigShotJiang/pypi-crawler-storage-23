import os
import sys
import subprocess
import numpy as np
import shutil

def run_cmd(cmd):
    print(f"Running: {cmd}")
    subprocess.run(cmd, shell=True, check=True)

def verify_restart():
    workdir = "workdir/verify_restart"
    if os.path.exists(workdir):
        shutil.rmtree(workdir)
    os.makedirs(workdir, exist_ok=True)
    
    poscar = "workdir/POSCAR_H2O_50K"
    if not os.path.exists(poscar):
        print("Missing test POSCAR. Please run verify_parity_runner.py first.")
        return

    # 1. Continuous run for 40 steps
    out_cont = os.path.join(workdir, "continuous")
    run_cmd(f"PYTHONPATH=. {sys.executable} -m macer.cli.main pimd -p {poscar} -T 300 --nsteps 40 --ff emt --nbead 4 --seed 42 --output-dir {out_cont}")
    
    # 2. Part 1: Run for 20 steps
    out_part1 = os.path.join(workdir, "part1")
    run_cmd(f"PYTHONPATH=. {sys.executable} -m macer.cli.main pimd -p {poscar} -T 300 --nsteps 20 --ff emt --nbead 4 --seed 42 --output-dir {out_part1} --save-restart-every 20")
    
    restart_file = os.path.join(out_part1, "pimd_state_step20.npz")
    if not os.path.exists(restart_file):
        print(f"FAILED: Restart file {restart_file} not found.")
        return

    # 3. Part 2: Continue from step 20 for another 20 steps
    out_part2 = os.path.join(workdir, "part2")
    os.makedirs(out_part2, exist_ok=True)
    # Copy ham.dat and other files to simulate continuation in the same dir? 
    # Actually, the engine will create new files in out_part2.
    # We just care if the values match.
    run_cmd(f"PYTHONPATH=. {sys.executable} -m macer.cli.main pimd -p {poscar} -T 300 --nsteps 20 --ff emt --nbead 4 --seed 42 --output-dir {out_part2} --restart {restart_file}")

    # 4. Compare ham.dat
    def load_ham(path):
        return np.loadtxt(path, comments="#")

    cont_data = load_ham(os.path.join(out_cont, "ham.dat"))
    rest_data = load_ham(os.path.join(out_part2, "ham.dat"))

    print("\n--- Continuous Run (Tail 5) ---")
    print(cont_data[-5:])
    
    print("\n--- Restart Run (Tail 5) ---")
    print(rest_data[-5:])

    # Compare the last step
    last_cont = cont_data[-1]
    last_rest = rest_data[-1]
    
    # Indices in ham.dat based on header: 
    # step(0) hamiltonian(1) temp(2) potential(3) ...
    diff = np.abs(last_cont[1] - last_rest[1])
    print(f"\nHamiltonian Diff at last step: {diff:e} AU")
    
    if diff < 1e-10:
        print("RESULT: SUCCESS - Restart parity confirmed.")
    else:
        print("RESULT: FAILURE - Hamiltonian mismatch.")

if __name__ == "__main__":
    verify_restart()
