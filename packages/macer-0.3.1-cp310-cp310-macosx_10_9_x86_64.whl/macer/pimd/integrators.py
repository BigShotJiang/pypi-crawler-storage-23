from ase.md.md import MolecularDynamics
from macer.pimd.state import PIMDASEState
from macer.pimd import transforms, thermostat, energy
from macer.pimd.npt_stepper import step_npt
from macer.pimd.force_bridge import evaluate_bead_forces
import numpy as np

# Physical Constants (matching original)
FS2AU = 1.0 / 0.024188843
K_TO_AU = 8.617333262145e-5 / 27.211396132
H_TO_K = 1.0 / K_TO_AU
ANG_TO_AU = 1.0 / 0.529177249
EVA3_PER_AU_STRESS = 27.211386245988 / (0.529177210903**3)

class PIMDIntegrator(MolecularDynamics):
    """
    PIMD Integrator.
    Implements the core PIMD step loop using the state encapsulated in PIMDASEState.
    """
    def __init__(self, atoms, timestep, state: PIMDASEState, config, **kwargs):
        self.state = state
        self.config = config
        super().__init__(atoms, timestep, **kwargs)

    def step(self):
        """
        Implementation of a single PIMD step.
        """
        if str(self.config.ensemble).lower() == "npt":
            return step_npt(self)
        return self._step_nvt_preserved()

    def _step_nvt_preserved(self):
        """
        NVT/NVE path preserved from existing implementation.
        NOTE: NPT work is routed to `npt_stepper.step_npt` to avoid touching NVT logic.
        """
        state = self.state
        config = self.config
        
        # Determine constants for this step
        beta = 1.0 / (config.temp * K_TO_AU)
        gkt = 1.0 / beta
        omega_p2 = float(state.nbead) / (beta**2)

        # 1. Thermostat half-step (Centroid)
        if config.ensemble in ["nvt", "npt"]:
            thermostat.nhc_integrate_cent3(state, state.dt, gkt)
        
        # 1.5 Barostat (NPT initial half)
        if config.ensemble == "npt":
            vol = np.linalg.det(state.cell)
            p_ext_au = config.press / 29421.01
            p_inst_au = state.pressure_inst / 29421.01
            g_eps = 3.0 * vol * (p_inst_au - p_ext_au) + (state.natom + 1.0/3.0) * gkt
            state.p_eps += 0.5 * state.dt * g_eps * np.eye(3) / 3.0
            
            eps_dot_iso = np.trace(state.p_eps) / (3.0 * state.W)
            v_fac = np.exp(-0.5 * state.dt * eps_dot_iso)
            state.vur *= v_fac

        # 2. Velocity half-step (physical force)
        transforms.Vupdate(state, state.dt)
        
        # 3. Inner reference loop (Spring forces and non-centroid thermostats)
        for iref in range(1, config.nref + 1):
            if config.ensemble in ["nvt", "npt"]:
                thermostat.nhc_integrate(state, state.dt_ref, gkt)
            
            transforms.Vupdate_Ref(state, state.dt_ref)
            
            # Position update (plus MTK scaling if NPT)
            if config.ensemble == "npt":
                eps_dot_iso = np.trace(state.p_eps) / (3.0 * state.W)
                pos_fac = np.exp(state.dt_ref * eps_dot_iso)
                state.ur *= pos_fac
            transforms.Uupdate(state, state.dt_ref)
            
            transforms.get_force_ref(state, omega_p2)
            transforms.Vupdate_Ref(state, state.dt_ref)
            
            if config.ensemble in ["nvt", "npt"]:
                thermostat.nhc_integrate(state, state.dt_ref, gkt)

        # 4. Cell update (NPT)
        if config.ensemble == "npt":
            eps_dot_iso = np.trace(state.p_eps) / (3.0 * state.W)
            cell_fac = np.exp(state.dt * eps_dot_iso)
            state.cell *= cell_fac
            atoms.set_cell(state.cell / ANG_TO_AU)

        # 5. Core Force Calculation (Full physical force)
        transforms.nmtrans_ur2r(state)
        for ibead in range(state.nbead):
            state.r_list[ibead].set_positions(state.r[:, :, ibead].T / ANG_TO_AU)
            state.r_list[ibead].set_cell(state.cell / ANG_TO_AU)

        calc = self.atoms.calc
        inv_nbead = 1.0 / float(state.nbead)
        forces, energies, stresses = evaluate_bead_forces(
            calc,
            state.r_list,
            need_stress=(config.ensemble == "npt"),
            batch_size=getattr(config, "batch_size", None),
            sequential=bool(getattr(config, "sequential", False)),
            label=f"Cycle {int(getattr(state, 'istepsv', 0)) + 1:03d} force eval",
        )

        for ibead in range(state.nbead):
            # eV/A -> Hartree/Bohr, then PIMD 1/nbead scaling.
            state.fr[:, :, ibead] = (np.array(forces[ibead], dtype=float).T / 51.422067) * inv_nbead
            state.pot_beads[ibead] = (float(energies[ibead]) / 27.211386) * inv_nbead

        if config.ensemble == "npt":
            from ase.constraints import voigt_6_to_full_3x3_stress

            if stresses is None:
                raise RuntimeError("NPT step requires stress results, but got None.")
            for ibead in range(state.nbead):
                s_raw = np.array(stresses[ibead], dtype=float)
                if s_raw.shape == (6,):
                    s_3x3 = voigt_6_to_full_3x3_stress(s_raw)
                elif s_raw.shape == (3, 3):
                    s_3x3 = s_raw
                else:
                    raise ValueError(f"Unsupported stress shape in PIMD batch eval: {s_raw.shape}")
                state.stress_beads[:, :, ibead] = (s_3x3 / EVA3_PER_AU_STRESS) * inv_nbead
        
        transforms.nmtrans_fr2fur(state)

        # 6. Final updates
        transforms.Vupdate(state, state.dt)

        if config.ensemble == "npt":
            # Barostat second half
            energy.calculate_observables(state, beta, K_TO_AU)
            vol = np.linalg.det(state.cell)
            p_ext_au = config.press / 29421.01
            p_inst_au = state.pressure_inst / 29421.01
            g_eps = 3.0 * vol * (p_inst_au - p_ext_au) + (state.natom + 1.0/3.0) * gkt
            
            eps_dot_iso = np.trace(state.p_eps) / (3.0 * state.W)
            v_fac = np.exp(-0.5 * state.dt * eps_dot_iso)
            state.vur *= v_fac
            state.p_eps += 0.5 * state.dt * g_eps * np.eye(3) / 3.0
            
            # Barostat NHC closing
            if hasattr(thermostat, 'nhc_integrate_baro'):
                thermostat.nhc_integrate_baro(state, state.dt, gkt)

        if config.ensemble in ["nvt", "npt"]:
            thermostat.nhc_integrate_cent3(state, state.dt, gkt)
        
        energy.calculate_observables(state, beta, K_TO_AU)
        state.istepsv += 1
        
        # Centroid position for ASE 'log' consistency
        self.atoms.set_cell(state.cell / 0.529177, scale_atoms=False)
        self.atoms.set_positions(state.ur[:, :, 0].T * 0.529177)
        
        return state.fr 
# or centroid force
