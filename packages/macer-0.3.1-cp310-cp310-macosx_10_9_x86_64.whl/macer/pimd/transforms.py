import numpy as np
from macer.pimd.state import PIMDASEState

def nmtrans_ur2r(state: PIMDASEState):
    """
    Transform NM positions (ur) to bead positions (r).
    r(xyz, i, j) = sum_k tnm(j, k) * ur(xyz, i, k)
    """
    state.r[:, :, :] = np.einsum("jk, xik -> xij", state.tnm, state.ur)

def nmtrans_r2ur(state: PIMDASEState):
    """
    Transform bead positions (r) to NM positions (ur).
    ur(xyz, i, j) = sum_k tnminv(j, k) * r(xyz, i, k)
    """
    state.ur[:, :, :] = np.einsum("jk, xik -> xij", state.tnminv, state.r)

def nmtrans_fr2fur(state: PIMDASEState):
    """
    Transform bead forces (fr) to NM forces (fur).
    fur(xyz, i, m) = sum_j fr(xyz, i, j) * tnm(j, m)
    """
    # Original used np.einsum("kij,jm->kim", P.fr, P.tnm) where fr was [3, Natom, Nbead]
    state.fur[:, :, :] = np.einsum("kij, jm -> kim", state.fr, state.tnm)

def get_force_ref(state: PIMDASEState, omega_p2: float):
    """
    Compute reference (spring) forces in NM space.
    """
    state.f_ref[:, :, 0] = 0.0
    j_slice = slice(1, state.nbead)
    state.f_ref[:, :, j_slice] = -state.dnmmass[:, j_slice] * omega_p2 * state.ur[:, :, j_slice]

def Uupdate(state: PIMDASEState, dt_ref: float):
    """
    Update NM positions.
    """
    state.ur[:, :, :] += dt_ref * state.vur[:, :, :]

def Vupdate(state: PIMDASEState, dt: float):
    """
    Full velocity update (from physical forces).
    """
    state.vur += 0.5 * dt * state.fur / state.fictmass

def Vupdate_Ref(state: PIMDASEState, dt_ref: float):
    """
    Reference (spring) velocity update.
    """
    j_slice = slice(1, state.nbead)
    state.vur[:, :, j_slice] += 0.5 * dt_ref * state.f_ref[:, :, j_slice] / state.fictmass[:, j_slice]
