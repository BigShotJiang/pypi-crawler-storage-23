import os
import sys
import numpy as np
import subprocess
import shutil

def run_cmd(cmd):
    print(f"Running: {cmd}")
    subprocess.run(cmd, shell=True, check=True)

def verify_npt():
    workdir = "workdir/verify_npt"
    if os.path.exists(workdir):
        shutil.rmtree(workdir)
    os.makedirs(workdir, exist_ok=True)
    
    poscar = "workdir/POSCAR_H2O_50K"
    if not os.path.exists(poscar):
        print("Missing test POSCAR. Creating one...")
        # Create a simple box if missing
        from ase.build import molecule
        from ase.io import write
        atoms = molecule('H2O')
        atoms.set_cell([10, 10, 10])
        os.makedirs("workdir", exist_ok=True)
        write(poscar, atoms, format="vasp")

    # Run PIMD-NPT for 50 steps
    # Target 1 GPa (high enough to see volume change)
    out_dir = os.path.join(workdir, "npt_run")
    run_cmd(f"PYTHONPATH=. {sys.executable} -m macer.cli.main pimd -p {poscar} -T 300 --ensemble npt --press 1.0 --nsteps 50 --ff emt --nbead 4 --seed 42 --output-dir {out_dir}")
    
    # Check results
    ham_path = os.path.join(out_dir, "ham.dat")
    if not os.path.exists(ham_path):
        print("FAILED: ham.dat not found.")
        return

    data = np.loadtxt(ham_path, comments="#")
    # Indices: step(0) ham(1) temp(2) pot(3) dkin(4) qkin(5) bath(6) bcent(7) virial(8) pressure(9)
    
    pressures = data[:, 9]
    print(f"\nPressure Stats (Target 1.0 GPa):")
    print(f"Mean: {np.mean(pressures):.4f} GPa")
    print(f"Std:  {np.std(pressures):.4f} GPa")
    print(f"Final: {pressures[-1]:.4f} GPa")

    # Check XDATCAR for volume change
    # Since XDATCAR is hard to parse for volume without a full VASP parser,
    # let's just inspect md.log if ASE's logger captured it, 
    # or look at the traj file if we can.
    # Actually, let's use the traj file.
    from ase.io.trajectory import Trajectory
    traj = Trajectory(os.path.join(out_dir, "pimd.traj"))
    volumes = [atoms.get_volume() for atoms in traj]
    print(f"\nVolume Stats:")
    print(f"Initial: {volumes[0]:.4f} A^3")
    print(f"Final:   {volumes[-1]:.4f} A^3")
    print(f"Diff:    {volumes[-1] - volumes[0]:.4f} A^3")

    if abs(volumes[-1] - volumes[0]) > 1e-6:
        print("\nRESULT: SUCCESS - Cell volume is dynamic.")
    else:
        print("\nRESULT: FAILURE - Cell volume remains static.")

if __name__ == "__main__":
    verify_npt()
