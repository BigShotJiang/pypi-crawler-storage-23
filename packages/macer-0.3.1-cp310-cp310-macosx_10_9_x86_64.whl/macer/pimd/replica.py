from __future__ import annotations

import contextlib
import copy
import io
import json
import os
import re
import shutil
import sys
import time
import traceback
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
from ase.io import read, write
from ase.io.trajectory import Trajectory

try:
    import psutil  # type: ignore
except Exception:
    psutil = None

_PIMD_IO_TIMING_KEYS = (
    "setup_io",
    "post_outputs",
    "post_ham_csv",
    "post_traj_parse",
)


def _emit_orch_line(base_args, text: str) -> None:
    print(text)
    log_path = getattr(base_args, "_replica_orch_log", None)
    if not log_path:
        return
    try:
        with Path(log_path).open("a", encoding="utf-8") as fp:
            fp.write(str(text) + "\n")
    except Exception:
        pass


def _peak_rss_gb() -> float:
    if psutil is None:
        return 0.0
    try:
        return float(psutil.Process().memory_info().rss / (1024**3))
    except Exception:
        return 0.0


def _load_pimd_timing_payload(out_dir: str | os.PathLike[str]) -> dict[str, Any]:
    base = Path(out_dir)
    timing_json = base / "pimd_phase_timing.json"
    if timing_json.exists():
        try:
            payload = json.loads(timing_json.read_text(encoding="utf-8"))
            if isinstance(payload, dict):
                return payload
        except Exception:
            pass
    timing_log = base / "pimd-timing.log"
    if not timing_log.exists():
        return {}
    payload: dict[str, Any] = {}
    pat = re.compile(r"^\[pimd\]\s+([A-Za-z0-9_]+):\s+([0-9]+(?:\.[0-9]+)?)s\b")
    try:
        for ln in timing_log.read_text(encoding="utf-8", errors="ignore").splitlines():
            m = pat.match(ln.strip())
            if not m:
                continue
            key = str(m.group(1))
            if key in ("total", "fractions_percent"):
                continue
            payload[key] = float(m.group(2))
    except Exception:
        return {}
    if payload:
        payload["total"] = float(sum(float(v) for v in payload.values()))
    return payload


def _estimate_pimd_io_fraction(out_dir: str | os.PathLike[str], wall_time_s: float) -> tuple[float, float]:
    payload = _load_pimd_timing_payload(out_dir)
    if not payload:
        return 0.0, 0.0
    io_wall_s = float(sum(float(payload.get(k, 0.0) or 0.0) for k in _PIMD_IO_TIMING_KEYS))
    if io_wall_s <= 0.0:
        return 0.0, 0.0
    denom = max(float(wall_time_s), 1e-12)
    io_frac = max(0.0, min(io_wall_s / denom, 1.0))
    return float(io_wall_s), float(io_frac)


def write_pimd_replica_manifest(manifest: dict[str, Any], out_path: str | os.PathLike[str]) -> None:
    path = Path(out_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2, ensure_ascii=True, sort_keys=True)


def _allocate_production_steps(total_nsteps: int, n_replica: int) -> list[int]:
    n_replica = max(1, int(n_replica))
    total_nsteps = max(1, int(total_nsteps))
    base = int(total_nsteps // n_replica)
    rem = int(total_nsteps % n_replica)
    steps = [int(base + (1 if i < rem else 0)) for i in range(n_replica)]
    if total_nsteps < n_replica:
        steps = [1 for _ in range(n_replica)]
    return steps


def _resolve_workers(parallelism: int | None, n_replica: int) -> int:
    # Policy: always run all replicas concurrently.
    # `parallelism` is accepted for backward compatibility but ignored.
    return max(1, int(n_replica))


def _monitor_mode(base_args) -> str:
    mode = str(getattr(base_args, "monitor", "auto") or "auto").lower()
    if mode == "off":
        return "off"
    if mode == "line":
        return "line"
    if mode == "live":
        if sys.stdout.isatty() and os.environ.get("TERM", "").lower() != "dumb":
            return "live"
        return "line"
    if mode == "auto":
        # Default to line monitor to avoid duplicated live-block lines
        # in environments that do not honor cursor control escapes.
        return "line"
    return "off"


def _format_hms(seconds: float) -> str:
    sec = max(0.0, float(seconds))
    h = int(sec // 3600)
    m = int((sec % 3600) // 60)
    s = sec % 60.0
    return f"{h:02d}:{m:02d}:{s:04.1f}"


def _format_eta(seconds: float | None) -> str:
    if seconds is None:
        return "--:--:--"
    sec = max(0.0, float(seconds))
    h = int(sec // 3600)
    m = int((sec % 3600) // 60)
    s = int(sec % 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def _monitor_stats(
    results: list[dict[str, Any]],
    total_replica: int,
    steps_per_replica: int,
    elapsed_s: float,
    planned_total_steps: int | None = None,
) -> dict[str, Any]:
    done_n = len(results)
    ok_n = sum(1 for r in results if r.get("status") == "ok")
    fail_n = done_n - ok_n
    running_n = max(0, int(total_replica) - int(done_n))
    done_steps = int(sum(int(r.get("nsteps_run", steps_per_replica) or 0) for r in results))
    if planned_total_steps is not None and int(planned_total_steps) >= 0:
        total_steps = int(planned_total_steps)
    else:
        total_steps = int(total_replica) * int(max(0, steps_per_replica))
    progress_pct = (100.0 * done_steps / total_steps) if total_steps > 0 else 0.0
    avg_step_s = (float(done_steps) / max(float(elapsed_s), 1e-12)) if done_steps > 0 else 0.0
    rem_steps = max(0, total_steps - done_steps)
    eta_s = (float(rem_steps) / avg_step_s) if avg_step_s > 1e-12 else None
    return {
        "done_n": int(done_n),
        "ok_n": int(ok_n),
        "fail_n": int(fail_n),
        "running_n": int(running_n),
        "done_steps": int(done_steps),
        "total_steps": int(total_steps),
        "progress_pct": float(progress_pct),
        "avg_step_s": float(avg_step_s),
        "eta_s": eta_s,
    }


def _render_live_block(
    phase: str,
    total_replica: int,
    steps_per_replica: int,
    elapsed_s: float,
    stats: dict[str, Any],
    replica1_step_line: str | None = None,
) -> list[str]:
    lines = [
        f"[pimd] Stage {phase} | n_replica={int(total_replica)} | nsteps={int(steps_per_replica)}",
        (
            f"[pimd][progress] replicas done={stats['done_n']}/{int(total_replica)} "
            f"running={stats['running_n']} ok={stats['ok_n']} fail={stats['fail_n']} "
            f"elapsed={_format_hms(elapsed_s)}"
        ),
        (
            f"[pimd][progress] steps={stats['done_steps']}/{stats['total_steps']} "
            f"({stats['progress_pct']:.1f}%) avg={stats['avg_step_s']:.2f} step/s "
            f"eta={_format_eta(stats['eta_s'])}"
        ),
    ]
    if replica1_step_line:
        norm = _normalize_replica_step_line(replica1_step_line)
        lines.append(f"[replica-01] {norm}")
    return lines


def _write_live_block(lines: list[str], prev_line_count: int) -> int:
    if prev_line_count > 0:
        print(f"\x1b[{prev_line_count}A", end="", flush=True)
    for ln in lines:
        print("\x1b[2K\r" + ln, flush=True)
    return len(lines)


def _normalize_replica_step_line(line: str | None) -> str | None:
    if not line:
        return line
    s = str(line).strip()
    if s.startswith("[pimd] "):
        return s[len("[pimd] ") :]
    return s


def _build_pimd_replica_args(
    base_args,
    replica_index: int,
    *,
    nsteps_i: int,
    out_dir: str,
    restart_path: str | None,
):
    def _resolve_replica_seed_root(base_args) -> int:
        cached = getattr(base_args, "_replica_seed_root", None)
        if cached is not None:
            return int(cached)
        if getattr(base_args, "seed", None) is not None:
            root = int(base_args.seed)
            setattr(base_args, "_replica_seed_root", root)
            return root
        if getattr(base_args, "replica_seed_base", None) is not None:
            root = int(base_args.replica_seed_base)
            setattr(base_args, "_replica_seed_root", root)
            return root
        # No explicit root provided: generate one once per run.
        root = int.from_bytes(os.urandom(8), "little") & 0xFFFFFFFF
        setattr(base_args, "_replica_seed_root", root)
        return root

    def _seedsequence_seed(seed_root: int, replica_idx: int) -> int:
        # Use independent child streams per replica while keeping reproducibility from seed_root.
        ss = np.random.SeedSequence([int(seed_root), int(replica_idx)])
        return int(ss.generate_state(1, dtype=np.uint32)[0])

    args_i = copy.deepcopy(base_args)
    args_i.replica = False
    args_i.dry_run = False
    args_i.no_auto_tune = True
    args_i.nsteps = int(nsteps_i)
    args_i.output_dir = str(out_dir)
    args_i._replica_quiet_terminal = True
    args_i._restart_step_reset = True
    args_i._replica_index = int(replica_index)
    args_i.restart = str(restart_path) if restart_path else None
    args_i.restart_npz = None
    init_mode = str(getattr(base_args, "replica_init", "auto") or "auto").lower()
    if init_mode == "auto":
        init_mode = "jitter" if restart_path else "reseed"
    args_i._replica_init_mode = init_mode
    args_i._replica_init_seed = int(getattr(args_i, "seed", 0) or 0)
    args_i._replica_jitter_scale = float(getattr(base_args, "replica_jitter_scale", 0.03) or 0.03)
    seed_root = _resolve_replica_seed_root(base_args)
    args_i._replica_seed_root = int(seed_root)
    args_i._replica_seed_strategy = "seedsequence"
    args_i.seed = _seedsequence_seed(seed_root, int(replica_index))
    args_i._replica_init_seed = int(getattr(args_i, "seed", args_i._replica_init_seed) or 0)
    return args_i


def _poll_step_lines(log_path: Path, cursor: dict[str, Any]) -> tuple[list[str], str | None]:
    try:
        if not log_path.exists():
            return [], cursor.get("latest")
        size = int(log_path.stat().st_size)
        pos = int(cursor.get("pos", 0) or 0)
        if size < pos:
            pos = 0
        with log_path.open("r", encoding="utf-8", errors="ignore") as f:
            f.seek(pos)
            chunk = f.read()
            pos = f.tell()
        cursor["pos"] = int(pos)
        if not chunk:
            return [], cursor.get("latest")
        latest = cursor.get("latest")
        out: list[str] = []
        for ln in chunk.splitlines():
            s = ln.strip()
            if s.startswith("[pimd] step="):
                latest = s
                out.append(s)
        if latest:
            cursor["latest"] = latest
        return out, latest
    except Exception:
        return [], cursor.get("latest")


def _prepare_resample_start_files(
    base_args,
    *,
    initial_restart_path: str | None,
    replica_dirs: list[Path],
) -> list[str | None]:
    init_mode = str(getattr(base_args, "replica_init", "auto") or "auto").lower()
    if init_mode == "auto":
        init_mode = "jitter" if initial_restart_path else "reseed"
    if init_mode != "resample":
        return [None for _ in replica_dirs]

    if not initial_restart_path:
        _emit_orch_line(base_args, "[pimd] Warning: replica-init=resample requires equil restart; fallback to clone/restart.")
        return [None for _ in replica_dirs]

    eq_dir = Path(initial_restart_path).resolve().parent
    traj_path = eq_dir / "pimd.traj"
    if not traj_path.exists():
        _emit_orch_line(base_args, f"[pimd] Warning: resample trajectory not found: {traj_path}. fallback to clone/restart.")
        return [None for _ in replica_dirs]

    starts: list[str | None] = [None for _ in replica_dirs]
    try:
        with Trajectory(str(traj_path), "r") as traj:
            nframe = len(traj)
            if nframe < 1:
                _emit_orch_line(base_args, "[pimd] Warning: equil trajectory empty; fallback to clone/restart.")
                return starts
            tstep_fs = float(getattr(base_args, "tstep", 0.1))
            window_ps = float(getattr(base_args, "replica_start_window_ps", 2.0))
            window_steps = max(1, int(round(window_ps * 1000.0 / max(tstep_fs, 1e-12))))
            i0 = max(0, nframe - window_steps)
            pool = list(range(i0, nframe))
            for i, rdir in enumerate(replica_dirs):
                if len(replica_dirs) == 1:
                    pick = pool[-1]
                else:
                    pos = int(round(i * (len(pool) - 1) / max(len(replica_dirs) - 1, 1)))
                    pick = pool[pos]
                at = traj[pick]
                poscar_path = rdir / "POSCAR-resample"
                write(str(poscar_path), at, format="vasp")
                starts[i] = str(poscar_path)
            _emit_orch_line(
                base_args,
                f"[pimd] replica-init=resample | traj={traj_path} | frames={nframe} | window=[{i0},{nframe-1}]",
            )
    except Exception as exc:
        _emit_orch_line(base_args, f"[pimd] Warning: resample preparation failed ({exc}); fallback to clone/restart.")
    return starts


def run_pimd_replica_worker(replica_args, out_dir: str, restart_path: str | None, replica_index: int) -> dict[str, Any]:
    from macer.pimd.runner import run_pimd

    result = {
        "replica_index": int(replica_index),
        "replica_name": f"replica-{int(replica_index):02d}",
        "output_dir": str(out_dir),
        "status": "ok",
        "error": None,
        "wall_time_s": 0.0,
        "peak_rss_gb": 0.0,
        "nsteps_run": int(getattr(replica_args, "nsteps", 0)),
        "io_wall_time_s": 0.0,
        "io_fraction": 0.0,
    }
    t0 = time.perf_counter()
    try:
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            run_pimd(replica_args)
    except Exception as exc:
        msg = f"{type(exc).__name__}: {exc}"
        result["status"] = "oom" if "out of memory" in msg.lower() else "failed"
        result["error"] = msg
        result["traceback"] = traceback.format_exc()
    result["wall_time_s"] = max(time.perf_counter() - t0, 1e-12)
    result["peak_rss_gb"] = _peak_rss_gb()
    io_wall_s, io_fraction = _estimate_pimd_io_fraction(out_dir, result["wall_time_s"])
    result["io_wall_time_s"] = float(io_wall_s)
    result["io_fraction"] = float(io_fraction)
    return result


def launch_pimd_replicas(
    base_args,
    *,
    initial_restart_path: str | None,
    n_replica: int,
    parallelism: int | None = None,
    step_plan: list[int] | None = None,
) -> dict[str, Any]:
    n_replica = int(n_replica)
    if n_replica < 1:
        raise ValueError(f"n_replica must be >= 1 (got {n_replica})")

    base_dir = Path(base_args.output_dir).resolve()
    base_dir.mkdir(parents=True, exist_ok=True)
    replica_dirs = [base_dir / f"replica-{i:02d}" for i in range(1, n_replica + 1)]
    for out_dir in replica_dirs:
        out_dir.mkdir(parents=True, exist_ok=True)

    if not step_plan:
        step_plan = [int(max(1, int(getattr(base_args, "nsteps", 1)))) for _ in range(n_replica)]

    max_workers = _resolve_workers(parallelism, n_replica)
    manifest = {
        "schema_version": "pimd-replica-manifest-v1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "n_replica": int(n_replica),
        "parallelism": int(max_workers),
        "replica_init_mode": str(getattr(base_args, "replica_init", "auto")),
        "target_total_nsteps": int(getattr(base_args, "nsteps", 0)),
        "replica_nsteps": [int(x) for x in step_plan],
        "results": [],
    }
    if parallelism is not None and int(parallelism) != int(n_replica):
        _emit_orch_line(
            base_args,
            f"[pimd] Info: --replica-parallel={int(parallelism)} is ignored; using full parallelism={int(n_replica)}.",
        )
    mon_mode = _monitor_mode(base_args)
    t0 = time.perf_counter()
    monitor_refresh = max(0.2, float(getattr(base_args, "monitor_refresh", 1.0)))
    live_line_count = 0
    last_emit = 0.0
    phase = str(getattr(base_args, "_replica_phase", "replica"))
    stream_replica01 = phase == "production"
    steps_per_replica = int(max(step_plan) if step_plan else 0)
    target_total_nsteps = int(sum(step_plan))
    replica01_cursor: dict[str, Any] = {"pos": 0, "latest": None}
    replica01_last_printed: str | None = None
    replica01_log_path = base_dir / "replica-01" / "pimd.log"
    resample_poscars = _prepare_resample_start_files(
        base_args,
        initial_restart_path=initial_restart_path,
        replica_dirs=replica_dirs,
    )

    def _print_progress() -> None:
        nonlocal live_line_count, replica01_last_printed
        elapsed = max(0.0, time.perf_counter() - t0)
        stats = _monitor_stats(
            manifest["results"],
            n_replica,
            steps_per_replica,
            elapsed,
            planned_total_steps=target_total_nsteps,
        )
        latest_step = None
        if stream_replica01:
            step_lines, latest_step = _poll_step_lines(replica01_log_path, replica01_cursor)
            if mon_mode == "line":
                for ln in step_lines:
                    if ln and ln != replica01_last_printed:
                        norm = _normalize_replica_step_line(ln)
                        _emit_orch_line(base_args, f"  [replica-01] {norm}")
                        replica01_last_printed = ln
        if mon_mode == "off":
            return
        if mon_mode == "line":
            # Keep line mode concise: stream replica-01 step lines and completion lines only.
            return
        lines = _render_live_block(
            phase,
            n_replica,
            steps_per_replica,
            elapsed,
            stats,
            replica1_step_line=latest_step if stream_replica01 else None,
        )
        live_line_count = _write_live_block(lines, live_line_count)

    with ProcessPoolExecutor(max_workers=max_workers) as ex:
        futures = {}
        for i, out_dir in enumerate(replica_dirs, start=1):
            restart_i = initial_restart_path
            if resample_poscars[i - 1] is not None:
                restart_i = None
            args_i = _build_pimd_replica_args(
                base_args,
                i,
                nsteps_i=int(step_plan[i - 1]),
                out_dir=str(out_dir),
                restart_path=restart_i,
            )
            _emit_orch_line(
                base_args,
                f"[pimd] replica-{int(i):02d} start: "
                f"nsteps={int(step_plan[i - 1])} "
                f"init_mode={str(getattr(args_i, '_replica_init_mode', 'clone'))} "
                f"seed={int(getattr(args_i, '_replica_init_seed', 0) or 0)}",
            )
            if resample_poscars[i - 1] is not None:
                args_i.poscar = str(resample_poscars[i - 1])
            fut = ex.submit(run_pimd_replica_worker, args_i, str(out_dir), restart_i, i)
            futures[fut] = i

        pending = set(futures.keys())
        _print_progress()
        while pending:
            done, pending = wait(pending, timeout=monitor_refresh, return_when=FIRST_COMPLETED)
            if not done:
                now = time.perf_counter()
                if (now - last_emit) >= monitor_refresh:
                    _print_progress()
                    last_emit = now
                continue
            for fut in done:
                idx = futures[fut]
                try:
                    res = fut.result()
                except Exception as exc:
                    res = {
                        "replica_index": int(idx),
                        "replica_name": f"replica-{int(idx):02d}",
                        "output_dir": str(base_dir / f"replica-{idx:02d}"),
                        "status": "failed",
                        "error": f"{type(exc).__name__}: {exc}",
                        "wall_time_s": 0.0,
                        "peak_rss_gb": 0.0,
                        "nsteps_run": int(step_plan[idx - 1]),
                    }
                manifest["results"].append(res)
                status = str(res.get("status", "failed"))
                _emit_orch_line(base_args, f"[pimd] replica-{int(idx):02d} done status={status}")
                _print_progress()
                last_emit = time.perf_counter()
        if mon_mode == "live" and live_line_count > 0:
            print("", flush=True)

    manifest["results"] = sorted(manifest["results"], key=lambda x: int(x.get("replica_index", 0)))
    n_failed = sum(1 for r in manifest["results"] if str(r.get("status")) != "ok")
    manifest["n_failed"] = int(n_failed)
    manifest["n_succeeded"] = int(n_replica - n_failed)
    manifest["status"] = "ok" if n_failed == 0 else ("partial_failed" if n_failed < n_replica else "failed")

    manifest_path = base_dir / "replica_manifest.json"
    write_pimd_replica_manifest(manifest, manifest_path)
    return manifest


def _resolve_replica_candidates(base_args, requested_n: int | None = None) -> list[int]:
    explicit = getattr(base_args, "replica_dry_run_candidates", None)
    if explicit:
        return sorted({int(x) for x in explicit if int(x) >= 1})
    cap = max(1, int(getattr(base_args, "replica_dry_run_max", 8)))
    upper = int(requested_n) if requested_n is not None and int(requested_n) >= 1 else cap
    upper = min(upper, cap)
    return list(range(1, upper + 1))


def _probe_score(throughput: float, io_fraction: float) -> float:
    io_penalty_cap = 0.5
    return float(throughput * (1.0 - min(max(io_fraction, 0.0), io_penalty_cap)))


def run_pimd_replica_tuner(base_args, *, initial_restart_path: str | None) -> dict[str, Any]:
    candidates = _resolve_replica_candidates(base_args, requested_n=getattr(base_args, "n_replica", None))
    warmup = max(0, int(getattr(base_args, "replica_dry_run_warmup", 0)))
    dry_steps = max(1, int(getattr(base_args, "replica_dry_run_steps", 10)))
    total_steps = int(warmup + dry_steps)
    metric = str(getattr(base_args, "replica_dry_run_metric", "steps_per_sec"))
    force_all = bool(getattr(base_args, "replica_dry_run_force_all", False))
    mem_headroom = float(getattr(base_args, "replica_mem_headroom", 0.95))
    mem_limit_gb = getattr(base_args, "replica_mem_limit_gb", None)
    degrade_tol = max(0.0, float(getattr(base_args, "replica_degrade_tol", 0.05)))
    degrade_patience = max(1, int(getattr(base_args, "replica_degrade_patience", 2)))

    effective_cap_gb = None
    if mem_limit_gb is not None:
        effective_cap_gb = float(mem_limit_gb) * float(mem_headroom)

    stop_reason = ""
    peak_r1_gb = None
    r_cap_mem = None
    best_score = None
    degrade_count = 0

    rows: list[dict[str, Any]] = []
    for r in sorted(candidates):
        should_break = False
        if (r_cap_mem is not None) and (int(r) > int(r_cap_mem)) and not force_all:
            rows.append(
                {
                    "replicas": int(r),
                    "status": "mem_exceeded",
                    "throughput": 0.0,
                    "peak_rss_gb": 0.0,
                    "io_fraction": 0.0,
                    "score": 0.0,
                    "manifest_path": "",
                    "reason": f"r>{int(r_cap_mem)}",
                }
            )
            stop_reason = f"memory_cap_prune_at_r={int(r)}"
            should_break = True
        if should_break:
            break

        probe_args = copy.deepcopy(base_args)
        probe_args.nsteps = int(total_steps)
        probe_args.output_dir = str(Path(base_args.output_dir).resolve() / f"_probe_r{int(r)}")
        manifest = launch_pimd_replicas(
            probe_args,
            initial_restart_path=initial_restart_path,
            n_replica=int(r),
            parallelism=getattr(base_args, "replica_parallel", None),
            step_plan=[int(total_steps)] * int(r),
        )
        ok_rows = [x for x in manifest.get("results", []) if str(x.get("status")) == "ok"]
        wall = max(float(sum(float(x.get("wall_time_s", 0.0) or 0.0) for x in ok_rows)), 1e-12)
        done_steps = int(sum(int(x.get("nsteps_run", total_steps) or 0) for x in ok_rows))
        throughput = float(done_steps / wall) if done_steps > 0 else 0.0
        if metric == "ps_per_sec":
            throughput = float(throughput * float(getattr(base_args, "tstep", 0.1)) / 1000.0)
        peak_rss = max([float(x.get("peak_rss_gb", 0.0) or 0.0) for x in ok_rows] + [0.0])
        io_wall = float(sum(float(x.get("io_wall_time_s", 0.0) or 0.0) for x in ok_rows))
        io_fraction = max(0.0, min(io_wall / wall, 1.0))
        if int(r) == 1 and peak_rss > 0.0:
            peak_r1_gb = float(peak_rss)
            if effective_cap_gb is not None:
                r_cap_mem = max(1, int(effective_cap_gb // max(peak_r1_gb, 1e-12)))
        row = {
            "replicas": int(r),
            "status": str(manifest.get("status", "failed")),
            "throughput": float(throughput),
            "peak_rss_gb": float(peak_rss),
            "io_fraction": float(io_fraction),
            "score": _probe_score(float(throughput), float(io_fraction)),
            "manifest_path": str(Path(probe_args.output_dir) / "replica_manifest.json"),
        }
        if effective_cap_gb is not None and peak_rss > effective_cap_gb:
            row["status"] = "mem_exceeded"
            row["reason"] = (
                f"peak_rss={peak_rss:.3f}GB > effective_cap={effective_cap_gb:.3f}GB"
            )
        rows.append(row)

        if row["status"] == "ok":
            cur_score = float(row["score"])
            if best_score is None or cur_score > best_score:
                best_score = cur_score
                degrade_count = 0
            else:
                threshold = float(best_score) * float(1.0 - degrade_tol)
                if cur_score < threshold:
                    degrade_count += 1
                else:
                    degrade_count = 0
            if degrade_count >= degrade_patience and not force_all:
                stop_reason = f"degrade_patience_reached_at_r={int(r)}"
                should_break = True
        elif row["status"] in ("oom", "mem_exceeded") and not force_all:
            stop_reason = f"{row['status']}_at_r={int(r)}"
            should_break = True

        if not bool(getattr(base_args, "replica_dry_run_output", None)):
            try:
                shutil.rmtree(probe_args.output_dir, ignore_errors=True)
            except Exception:
                pass
        if should_break:
            break

    best_ok = [r for r in rows if r.get("status") == "ok"]
    if best_ok:
        best = max(best_ok, key=lambda x: (float(x.get("score", 0.0)), int(x.get("replicas", 0))))
        selected = int(best["replicas"])
        reason = "best_score"
    else:
        selected = 1
        reason = "all_failed_fallback_1"

    return {
        "schema_version": "pimd-replica-dry-run-v1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "selected_replicas": int(selected),
        "selection_reason": reason,
        "metric": metric,
        "candidates": [int(c) for c in candidates],
        "results": rows,
        "mem_cap_gb": mem_limit_gb,
        "mem_headroom": mem_headroom,
        "effective_cap_gb": effective_cap_gb,
        "peak_r1_gb": peak_r1_gb,
        "r_cap_mem": r_cap_mem,
        "stop_reason": stop_reason or "--",
    }
