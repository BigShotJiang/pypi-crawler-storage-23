from __future__ import annotations
import argparse
import copy
from pathlib import Path

from macer.calculator.factory import ALL_SUPPORTED_FFS, get_available_ffs
from macer.cli.argparse_common import enable_helpful_argparse_errors
from macer.defaults import DEFAULT_DEVICE
from macer.molecular_dynamics.pimd.io import dedupe_output_dir
from macer.molecular_dynamics.pimd.params import auto_nbead_from_temperature
from macer.utils.struct_tools import resolve_structure_inputs

enable_helpful_argparse_errors()

def get_pimd_parser():
    """
    Build `macer pimd` parser.
    Shares logic with `macer pimd` but tailored for the internal engine.
    """
    available_ffs = get_available_ffs()
    dynamic_default_ff = available_ffs[0] if available_ffs else None

    parser = argparse.ArgumentParser(
        description="Path Integral Molecular Dynamics with macer (internal engine with structural extension path).",
        epilog="""
Examples:
  # 1) Basic run (single-run, nbead specified)
  macer pimd -p POSCAR --ff mattersim --temp 300 --nbead 16 --tstep 0.25 --nsteps 100

  # 2) Force sequential evaluation (single-run)
  macer pimd -p POSCAR --ff mattersim --temp 300 --tstep 0.25 --sequential

  # 3) NPT trial run
  macer pimd -p POSCAR --ff emt --temp 300 --ensemble npt --press 1.0 --nsteps 200

  # 4) Continue from restart file
  macer pimd --ff mattersim --temp 300 --nsteps 100 --restart ./pimd-run/restart.npz

  # 5) Multi-replica run (--n-replica >= 2)
  # Replica mode default: sequential evaluation (unless --batch-size is explicitly set)
  macer pimd -p POSCAR --ff mattersim --temp 300 --n-replica 4 --nsteps 2000

  # 6) Replica dry-run tuner only (recommend replica count)
  macer pimd -p POSCAR --ff mattersim --temp 300 --n-replica 8 --dry-run

Tip: `--batch-size` must be a positive integer (>=1).
  - Single-run + omit `--batch-size`: use `nbead`-based batch by default
    (backend/device policy may reduce the effective batch).
  - Replica mode + omit `--batch-size`: default to sequential (safety default).
  - Use `--sequential` to force per-structure fallback mode.

""",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        add_help=False,
    )

    structure_group = parser.add_argument_group("Structure Input")
    structure_input = structure_group.add_mutually_exclusive_group(required=False)
    structure_input.add_argument("--poscar", "-p", type=str, default=None, help="Input POSCAR path.")
    structure_input.add_argument("--cif", "-c", type=str, default=None, help="Input CIF path.")
    structure_input.add_argument("-f", "--formula", type=str, help="Materials Project formula input.")
    structure_input.add_argument("-m", "--mpid", type=str, help="Materials Project ID input.")
    parser.add_argument(
        "--dim",
        type=int,
        nargs="+",
        help="Supercell dimension as 3 or 9 integers.",
    )

    mlff_group = parser.add_argument_group("MLFF Model Settings")
    mlff_group.add_argument("--model", default=None, help="Path to MLFF model file.")
    mlff_group.add_argument(
        "--ff",
        type=str,
        default=dynamic_default_ff,
        choices=ALL_SUPPORTED_FFS,
        help="Force field to use.",
    )
    mlff_group.add_argument("--modal", type=str, default=None, help="Modal for supported force fields.")
    mlff_group.add_argument(
        "--device",
        choices=["cpu", "mps", "cuda"],
        default=DEFAULT_DEVICE,
        help="Compute device.",
    )
    mlff_group.add_argument(
        "--batch-size",
        type=int,
        default=None,
        help=(
            "Optional mini-batch size for force evaluation. "
            "When omitted: single-run uses auto batch; replica run defaults to sequential safety mode."
        ),
    )
    mlff_group.add_argument(
        "--sequential",
        action="store_true",
        default=False,
        help="Run force calculations sequentially (disable batch run).",
    )

    pimd_group = parser.add_argument_group("PIMD Parameters")
    pimd_group.add_argument(
        "--ensemble",
        choices=["nve", "nvt", "nte", "npt"],
        default="nvt",
        help="PIMD ensemble (`nte` is treated as `nvt`). Default: nvt.",
    )
    pimd_group.add_argument(
        "--ttau",
        type=float,
        default=0.0,
        help="Thermostat time constant [fs]. Default: 0.0 (auto: ttau = 40 * tstep).",
    )
    pimd_group.add_argument(
        "--ptau",
        type=float,
        default=0.0,
        help=(
            "Barostat time constant [fs]. Default: 0.0 (auto: choose a stable value "
            "from bulk-modulus policy for NPT)."
        ),
    )
    pimd_group.add_argument(
        "--press",
        "--pressure",
        type=float,
        default=0.0,
        help="Target pressure [GPa] (used in NPT). Default: 0.0.",
    )
    pimd_group.add_argument(
        "-T",
        "--temp",
        "--temperature",
        type=float,
        help="Target temperature [K].",
    )
    pimd_group.add_argument(
        "--nbead",
        type=int,
        default=None,
        help="Number of PIMD beads. Default: auto-selected from temperature when omitted.",
    )
    pimd_group.add_argument("--tstep", type=float, default=0.1, help="Time step [fs]. Default: 0.1.")
    pimd_group.add_argument("--nsteps", type=int, default=10, help="Number of integration steps. Default: 10.")
    
    # Thermostat settings
    pimd_group.add_argument(
        "--igamma",
        type=int,
        default=1,
        help="Adiabaticity parameter for internal-mode fictitious masses. Default: 1.",
    )
    pimd_group.add_argument("--nref", type=int, default=5, help="Number of inner reference loop steps. Default: 5.")
    pimd_group.add_argument("--nnhc", type=int, default=4, help="Number of Nose-Hoover Chain links. Default: 4.")
    pimd_group.add_argument("--nys", type=int, default=5, choices=[1, 3, 5], help="Yoshida-Suzuki integration order. Default: 5.")
    pimd_group.add_argument("--seed", type=int, default=None, help="Random seed for reproducibility. Default: None.")
    pimd_group.add_argument(
        "--mass",
        nargs="+",
        default=None,
        help="Atomic mass override pairs: Symbol Mass Symbol Mass ... (e.g., --mass H 2.014 O 15.999).",
    )
    
    out_group = parser.add_argument_group("Output Settings")
    out_group.add_argument("--output-dir", type=str, default=".", help="Output directory.")
    out_group.add_argument("--print-every", type=int, default=1, help="Stdout print interval.")
    out_group.add_argument("--save-xdatcar-every", type=int, default=1, help="Save cadence for XDATCAR-PIMD, XDATCAR-PIMD-BEADS, and coor.xyz.")
    out_group.add_argument(
        "--debug",
        action="store_true",
        default=False,
        help="Enable debug outputs (e.g., step-0 NPT diagnostics).",
    )
    out_group.add_argument(
        "--npt-trace",
        action="store_true",
        default=False,
        help="Enable NPT step trace JSONL output (debug artifact, first 20 steps).",
    )
    out_group.add_argument(
        "--save-restart-every",
        type=int,
        default=1,
        help="Interval (in steps) for saving restart .npz files.",
    )
    out_group.add_argument(
        "--save-checkpoint-every",
        type=int,
        default=1000,
        help="Cadence for writing `pimd_state_step*.npz` checkpoint snapshots.",
    )
    out_group.add_argument(
        "--restart",
        "-r",
        type=str,
        default=None,
        help="Path to a restart .npz file to continue from.",
    )

    replica_group = parser.add_argument_group("Replica run (--n-replica >= 2)")
    replica_group.add_argument(
        "--n-replica",
        type=int,
        default=1,
        help="Number of production replicas. 1 means single-run mode; >=2 enables replica run.",
    )
    replica_group.add_argument(
        "--replica-parallel",
        type=int,
        default=None,
        help=argparse.SUPPRESS,
    )
    replica_group.add_argument(
        "--replica-init",
        choices=["auto", "clone", "jitter", "reseed", "resample"],
        default="auto",
        help=argparse.SUPPRESS,
    )
    replica_group.add_argument("--replica-seed-base", type=int, default=None, help=argparse.SUPPRESS)
    replica_group.add_argument("--replica-jitter-scale", type=float, default=0.03, help=argparse.SUPPRESS)
    replica_group.add_argument("--replica-start-window-ps", type=float, default=2.0, help=argparse.SUPPRESS)
    replica_group.add_argument(
        "--equil-steps",
        type=int,
        default=0,
        help="Thermal-equilibration steps before starting replica runs. Default: 0.",
    )
    replica_group.add_argument("--equil-ps", type=float, default=None, help="Equilibration time in ps (converted via --tstep).")
    replica_group.add_argument("--monitor", choices=["auto", "off", "line", "live"], default="auto", help=argparse.SUPPRESS)
    replica_group.add_argument("--dry-run", action="store_true", help="Run replica dry-run tuner only and exit.")

    dry_run_group = parser.add_argument_group("Replica Auto Tuner")
    dry_run_group.add_argument("--no-auto-tune", action="store_true", help=argparse.SUPPRESS)
    dry_run_group.add_argument("--replica-dry-run-max", type=int, default=8, help=argparse.SUPPRESS)
    dry_run_group.add_argument("--replica-dry-run-candidates", type=int, nargs="+", default=None, help=argparse.SUPPRESS)
    dry_run_group.add_argument("--replica-dry-run-steps", type=int, default=10, help=argparse.SUPPRESS)
    dry_run_group.add_argument("--replica-dry-run-warmup", type=int, default=0, help=argparse.SUPPRESS)
    dry_run_group.add_argument(
        "--replica-dry-run-metric",
        choices=["steps_per_sec", "ps_per_sec"],
        default="steps_per_sec",
        help=argparse.SUPPRESS,
    )
    dry_run_group.add_argument("--replica-dry-run-output", type=str, default=None, help=argparse.SUPPRESS)
    dry_run_group.add_argument("--replica-mem-limit-gb", type=float, default=None, help=argparse.SUPPRESS)
    dry_run_group.add_argument("--replica-mem-headroom", type=float, default=0.95, help=argparse.SUPPRESS)
    dry_run_group.add_argument("--replica-dry-run-force-all", action="store_true", help=argparse.SUPPRESS)

    return parser

def run_pimd_simulation(args):
    prepare_pimd_args(args)
    if bool(getattr(args, "replica", False)):
        return _run_pimd_orchestrated(args)

    if bool(getattr(args, "_ensemble_alias_nte", False)):
        print("[pimd] Info: `--ensemble nte` is treated as `nvt`.")
    print(f"[pimd] Resolved output dir: {getattr(args, 'output_dir')}")

    from macer.pimd.runner import run_pimd
    run_pimd(args)


def _resolve_equil_steps(args) -> int:
    equil_steps = int(getattr(args, "equil_steps", 0) or 0)
    equil_ps = getattr(args, "equil_ps", None)
    if equil_ps is None:
        return max(0, equil_steps)
    return max(0, int(round(float(equil_ps) * 1000.0 / max(float(args.tstep), 1e-12))))


def _run_pimd_orchestrated(args):
    from macer.pimd.replica import (
        _allocate_production_steps,
        launch_pimd_replicas,
        run_pimd_replica_tuner,
        write_pimd_replica_manifest,
    )
    from macer.pimd.runner import run_pimd

    base_output_dir = Path(args.output_dir).resolve()
    base_output_dir.mkdir(parents=True, exist_ok=True)
    orch_log_path = base_output_dir / "pimd_replica_run.log"
    setattr(args, "_replica_orch_log", str(orch_log_path))

    def _emit(line: str) -> None:
        print(line)
        try:
            with orch_log_path.open("a", encoding="utf-8") as fp:
                fp.write(line + "\n")
        except Exception:
            pass

    n_replica_requested = int(getattr(args, "n_replica", 1) or 1)
    _emit(
        "[pimd] Replica mode: enabled "
        f"| requested_n_replica={n_replica_requested} "
        f"| nsteps={int(getattr(args, 'nsteps', 0))} "
        f"| nbead={int(getattr(args, 'nbead', 0))} "
        f"| device={getattr(args, 'device', 'cpu')}"
    )
    _emit(f"[pimd] replica run log: {orch_log_path}")
    if bool(getattr(args, "_auto_sequential_for_replica", False)):
        _emit("[pimd] replica default policy: sequential enabled (no --batch-size provided).")

    initial_restart_path = str(getattr(args, "restart", None) or "")
    equil_steps = _resolve_equil_steps(args)

    if equil_steps > 0:
        eq_args = copy.deepcopy(args)
        eq_args.replica = False
        eq_args.dry_run = False
        eq_args.no_auto_tune = True
        eq_args.nsteps = int(equil_steps)
        eq_args.output_dir = str(base_output_dir / "equilibrium")
        _emit(f"[pimd] Stage 1/2: equilibration ({equil_steps} steps) -> {eq_args.output_dir}")
        run_pimd(eq_args)
        initial_restart_path = str(Path(eq_args.output_dir) / "restart.npz")
        _emit(f"[pimd] equilibration restart: {initial_restart_path}")

    n_replica = int(getattr(args, "n_replica", 1) or 1)
    if n_replica < 1:
        raise ValueError("--n-replica must be >= 1.")

    if bool(getattr(args, "dry_run", False)):
        tuner = run_pimd_replica_tuner(args, initial_restart_path=initial_restart_path or None)
        if getattr(args, "replica_dry_run_output", None):
            write_pimd_replica_manifest(tuner, args.replica_dry_run_output)
            _emit(f"[pimd] dry-run result saved: {args.replica_dry_run_output}")
        _emit(f"[pimd] recommended_replicas={tuner.get('selected_replicas')}")
        return tuner

    if (
        n_replica > 1
        and bool(getattr(args, "auto_tune_production", False))
        and not bool(getattr(args, "no_auto_tune", False))
    ):
        tuner = run_pimd_replica_tuner(args, initial_restart_path=initial_restart_path or None)
        if getattr(args, "replica_dry_run_output", None):
            write_pimd_replica_manifest(tuner, args.replica_dry_run_output)
            _emit(f"[pimd] dry-run result saved: {args.replica_dry_run_output}")
        n_replica = int(tuner.get("selected_replicas", n_replica))
        _emit(f"[pimd] auto-tuner selected n_replica={n_replica}")
    elif n_replica > 1:
        _emit(f"[pimd] fixed replica count mode: n_replica={n_replica} (production auto-tuner disabled).")

    step_plan = _allocate_production_steps(total_nsteps=int(args.nsteps), n_replica=int(n_replica))
    force_eval_mode = (
        "sequential"
        if bool(getattr(args, "sequential", False))
        else f"batch(batch_size={getattr(args, 'batch_size', None) or 'auto'})"
    )
    _emit(
        f"[pimd] replica runtime: resolved_n_replica={int(n_replica)} "
        f"| parallel={int(n_replica)} "
        f"| force_eval={force_eval_mode} "
        f"| monitor={getattr(args, 'monitor', 'auto')}"
    )
    _emit(
        f"[pimd] Stage 2/2: launching {n_replica} replicas "
        f"(parallel={int(n_replica)})"
    )
    _emit(
        f"[pimd] production step-plan: total_target={int(args.nsteps)} "
        f"| per-replica={step_plan} | total_assigned={int(sum(step_plan))}"
    )
    setattr(args, "_replica_phase", "production")
    manifest = launch_pimd_replicas(
        args,
        initial_restart_path=initial_restart_path or None,
        n_replica=int(n_replica),
        parallelism=getattr(args, "replica_parallel", None),
        step_plan=step_plan,
    )
    _emit(
        f"[pimd] replica launch done: status={manifest.get('status')} "
        f"ok={manifest.get('n_succeeded')}/{manifest.get('n_replica')}"
    )
    _emit(f"[pimd] manifest: {Path(args.output_dir) / 'replica_manifest.json'}")
    return manifest


def prepare_pimd_args(args) -> None:
    n_replica_raw = int(getattr(args, "n_replica", 1) or 1)
    if n_replica_raw < 1:
        raise ValueError("--n-replica must be >= 1.")
    setattr(args, "replica", bool(n_replica_raw >= 2))

    ens = str(getattr(args, "ensemble", "nvt")).lower()
    prev_nte_alias = bool(getattr(args, "_ensemble_alias_nte", False))
    setattr(args, "_ensemble_alias_nte", prev_nte_alias or (ens == "nte"))
    if ens == "nte":
        ens = "nvt"
    setattr(args, "ensemble", ens)

    prev_auto_nbead = bool(getattr(args, "_auto_nbead", False))
    if getattr(args, "nbead", None) is None and getattr(args, "temp", None) is not None:
        setattr(args, "nbead", int(auto_nbead_from_temperature(float(args.temp))))
        setattr(args, "_auto_nbead", True)
    elif not prev_auto_nbead:
        setattr(args, "_auto_nbead", False)

    restart_arg = getattr(args, "restart", None)
    restart_path: Path | None = None
    if restart_arg:
        restart_path = Path(str(restart_arg)).expanduser().resolve()
        if not restart_path.exists():
            raise FileNotFoundError(f"Restart file not found: {restart_path}")
        if restart_path.suffix.lower() != ".npz":
            raise ValueError(f"Invalid restart file extension: {restart_path.name} (expected .npz)")

    user_output = str(getattr(args, "output_dir", ".") or ".")
    if user_output == ".":
        input_list = resolve_structure_inputs(
            poscar_paths=[args.poscar] if getattr(args, "poscar", None) else None,
            cif_paths=[args.cif] if getattr(args, "cif", None) else None,
            formula=getattr(args, "formula", None),
            mpid=getattr(args, "mpid", None),
        )
        if input_list:
            # Output-dir policy is structure-based and independent of restart input.
            input_path = Path(input_list[0]).expanduser().resolve()
            base_output = input_path.parent / f"pimd-{input_path.stem}-mlff={args.ff}"
            resolved_output = dedupe_output_dir(base_output)
        elif restart_path is not None:
            # Backward compatibility for restart-only runs without structure inputs.
            resolved_output = restart_path.parent
        else:
            raise ValueError("Missing structure input for pimd output-dir resolution.")
    else:
        resolved_output = Path(user_output).expanduser().resolve()
        resolved_output.mkdir(parents=True, exist_ok=True)
    setattr(args, "output_dir", str(resolved_output))
    setattr(args, "mass_map", _parse_mass_map(getattr(args, "mass", None)))
    batch_size = getattr(args, "batch_size", None)
    if batch_size is not None and int(batch_size) < 1:
        raise ValueError("--batch-size must be >= 1.")
    if int(getattr(args, "save_restart_every", 1) or 1) < 1:
        raise ValueError("--save-restart-every must be >= 1.")
    if int(getattr(args, "save_checkpoint_every", 1000) or 1000) < 1:
        raise ValueError("--save-checkpoint-every must be >= 1.")
    igamma = int(getattr(args, "igamma", 1) or 1)
    if igamma < 1:
        raise ValueError("--igamma must be >= 1.")
    if bool(getattr(args, "replica", False)):
        rp = getattr(args, "replica_parallel", None)
        if rp is not None and int(rp) < 1:
            raise ValueError("--replica-parallel must be >= 1 when provided.")
        es = int(getattr(args, "equil_steps", 0) or 0)
        if es < 0:
            raise ValueError("--equil-steps must be >= 0.")
        eps = getattr(args, "equil_ps", None)
        if eps is not None and float(eps) < 0:
            raise ValueError("--equil-ps must be >= 0 when provided.")
    auto_seq_replica = False
    if (
        bool(getattr(args, "replica", False))
        and not bool(getattr(args, "sequential", False))
        and getattr(args, "batch_size", None) is None
    ):
        setattr(args, "sequential", True)
        auto_seq_replica = True
    setattr(args, "_auto_sequential_for_replica", bool(auto_seq_replica))



def _parse_mass_map(raw_mass_args) -> dict[str, float] | None:
    if not raw_mass_args:
        return None
    if len(raw_mass_args) % 2 != 0:
        raise ValueError("Error: --mass requires Symbol Mass pairs (e.g. --mass H 2.014 O 15.999).")

    mass_map: dict[str, float] = {}
    for idx in range(0, len(raw_mass_args), 2):
        symbol = str(raw_mass_args[idx])
        try:
            value = float(raw_mass_args[idx + 1])
        except ValueError as exc:
            raise ValueError(f"Error: invalid mass value for {symbol}: {raw_mass_args[idx + 1]}") from exc
        if value <= 0.0:
            raise ValueError(f"Error: mass for {symbol} must be > 0.0")
        mass_map[symbol] = value
    return mass_map
