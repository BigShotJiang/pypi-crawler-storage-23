from __future__ import annotations
import os
import sys
import time
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from ase import Atoms
import ase.io
import numpy as np
from macer.calculator.factory import get_calculator
from macer.pimd.force_bridge import resolve_pimd_batch_size
from macer.pimd.initialize import initialize_state, ANG_TO_AU
from macer.pimd.integrators import PIMDIntegrator
from macer.pimd import restart
from macer.molecular_dynamics.pimd.external_linker import _report_phase_timings

FS2AU = 1.0 / 0.024188843
# 1 atomic-unit stress (Hartree / Bohr^3) = 29421.01 GPa.
AU_STRESS_TO_GPA = 29421.01
GPA_TO_AU = 1.0 / AU_STRESS_TO_GPA
EVA3_PER_AU_STRESS = 27.211386245988 / (0.529177210903**3)
# ASE time unit per fs (ase.units.fs).
ASE_FS = 0.09822694788464063
# Convert pfactor from atomic units to ASE internal units:
# pf_ase = pf_au * (ASE_FS/FS2AU)^2 * (AU_STRESS_TO_GPA/160.21766208)
PFACTOR_ASE_PER_AU = (ASE_FS / FS2AU) ** 2 * (AU_STRESS_TO_GPA / 160.21766208)


class _StdoutTee:
    """Mirror stdout stream into a log file."""

    def __init__(self, stream_a, stream_b):
        self._a = stream_a
        self._b = stream_b

    def write(self, data):
        self._a.write(data)
        self._b.write(data)
        return len(data)

    def flush(self):
        self._a.flush()
        self._b.flush()


def _apply_md_style_npt_autos(args, atoms) -> None:
    ensemble = str(getattr(args, "ensemble", "nvt")).lower()
    if ensemble != "npt":
        return

    ttau = float(getattr(args, "ttau", 0.0) or 0.0)
    if ttau <= 0.0:
        auto_ttau = 40.0 * float(getattr(args, "tstep", 0.1))
        setattr(args, "ttau", float(auto_ttau))
        print(f"[pimd] Info: auto thermostat time constant enabled (`ttau = 40 * dt = {auto_ttau:.3f} fs`).")

    # If pfactor is already supplied, preserve it.
    explicit_pfactor = getattr(args, "pfactor", None)
    if explicit_pfactor is not None:
        pf_au = float(explicit_pfactor)
        pf_ase = pf_au * PFACTOR_ASE_PER_AU
        print(f"[pimd] Info: using provided pfactor={pf_au:.6e} (au; ASE={pf_ase:.6e}).")
        return

    ptau = float(getattr(args, "ptau", 0.0) or 0.0)
    if ptau > 0.0:
        # Match macer md policy for explicit ptau: assume ~100 GPa fallback bulk modulus.
        b_gpa_fallback = 100.0
        pfactor_au = (ptau * FS2AU) ** 2 * (b_gpa_fallback * GPA_TO_AU)
        setattr(args, "pfactor", float(pfactor_au))
        pfactor_ase = pfactor_au * PFACTOR_ASE_PER_AU
        print(f"[pimd] Info: using user-provided ptau={ptau:.3f} fs.")
        print(
            f"[pimd] Info: mapped pfactor={pfactor_au:.6e} (au; ASE={pfactor_ase:.6e}) "
            f"with fallback B={b_gpa_fallback:.1f} GPa."
        )
        return

    print("[pimd] Info: estimating bulk modulus for automatic NPT ptau selection...")
    try:
        from macer.relaxation.bulk_modulus import get_bulk_modulus_and_volume

        # Keep the auto-policy identical to `macer md`:
        # single default E-V fit attempt with the same helper defaults.
        b_gpa, _ = get_bulk_modulus_and_volume(atoms, args)
        if b_gpa is None or not np.isfinite(b_gpa) or b_gpa <= 0.0:
            raise RuntimeError("bulk modulus fit failed")
        b_gpa = float(b_gpa)
        if b_gpa > 100.0:
            ptau_val = 200.0
        elif b_gpa > 30.0:
            ptau_val = 500.0
        else:
            ptau_val = 1000.0
        setattr(args, "ptau", float(ptau_val))
        # Match macer md policy for auto mode: use estimated B in pfactor.
        pfactor_au = (ptau_val * FS2AU) ** 2 * (b_gpa * GPA_TO_AU)
        setattr(args, "pfactor", float(pfactor_au))
        pfactor_ase = pfactor_au * PFACTOR_ASE_PER_AU
        print(f"[pimd] Info: bulk modulus={b_gpa:.2f} GPa -> auto ptau={ptau_val:.1f} fs.")
        print(f"[pimd] Info: mapped pfactor={pfactor_au:.6e} (au; ASE={pfactor_ase:.6e}) from estimated B.")
    except Exception as exc:
        setattr(args, "ptau", 1000.0)
        b_gpa_fallback = 100.0
        pfactor_au = (1000.0 * FS2AU) ** 2 * (b_gpa_fallback * GPA_TO_AU)
        setattr(args, "pfactor", float(pfactor_au))
        pfactor_ase = pfactor_au * PFACTOR_ASE_PER_AU
        print(f"[pimd] Warning: auto ptau estimation failed ({exc}); fallback ptau=1000.0 fs.")
        print(
            f"[pimd] Info: mapped pfactor={pfactor_au:.6e} (au; ASE={pfactor_ase:.6e}) "
            f"with fallback B={b_gpa_fallback:.1f} GPa."
        )


def _apply_mass_override(atoms: Atoms, mass_map: dict[str, float] | None) -> None:
    if not mass_map:
        return
    symbols = atoms.get_chemical_symbols()
    old_masses = np.array(atoms.get_masses(), dtype=float)
    new_masses = old_masses.copy()
    applied: dict[str, float] = {}
    present_symbols = set(symbols)

    for idx, sym in enumerate(symbols):
        if sym in mass_map:
            new_masses[idx] = float(mass_map[sym])
            applied[sym] = float(mass_map[sym])

    missing = [sym for sym in mass_map.keys() if sym not in present_symbols]
    if missing:
        print(f"[pimd] Warning: --mass entries not present in structure: {', '.join(missing)}")

    atoms.set_masses(new_masses.tolist())
    print("[pimd] Atomic mass override:")
    for sym, mass in sorted(applied.items()):
        print(f"  {sym:3s} : {mass:8.4f} amu")


def _format_pimd_realtime_line(
    state,
    step: int,
    *,
    include_pressure: bool = False,
    include_cell: bool = False,
) -> str:
    line = (
        "[pimd] "
        f"step={int(step):6d} "
        f"H_total(au)={float(state.hamiltonian):10.6f} "
        f"T(K)={float(state.temp_inst):8.3f} "
        f"V_pot(au)={float(state.potential):10.6f} "
        f"K_dyn(au)={float(state.dkinetic):10.6f} "
        f"K_q(au)={float(state.qkinetic):10.6f} "
        f"Ebath(au)={float(state.ebath):10.6f} "
        f"Ebath_cent(au)={float(state.ebath_cent):10.6f}"
    )
    if include_cell:
        cell_ang = np.array(state.cell, dtype=float) / ANG_TO_AU
        a, b, c = np.linalg.norm(cell_ang, axis=1)
        volume = abs(np.linalg.det(cell_ang))
        pressure = float(state.pressure_inst)
        line += (
            f" a(A)={a:9.4f}"
            f" b(A)={b:9.4f}"
            f" c(A)={c:9.4f}"
            f" volume(A^3)={volume:11.4f}"
            f" pressure(GPa)={pressure:9.4f}"
        )
    elif include_pressure:
        pressure = float(state.pressure_inst)
        line += f" pressure(GPa)={pressure:9.4f}"
    return line


def _format_pimd_cell_line(state) -> str:
    cell_ang = np.array(state.cell, dtype=float) / ANG_TO_AU
    a, b, c = np.linalg.norm(cell_ang, axis=1)
    volume = abs(np.linalg.det(cell_ang))
    pressure = float(state.pressure_inst)
    return (
        "[pimd] "
        f"a(A)={a:9.4f} "
        f"b(A)={b:9.4f} "
        f"c(A)={c:9.4f} "
        f"volume(A^3)={volume:11.4f} "
        f"pressure(GPa)={pressure:9.4f}"
    )


def _write_step0_npt_diagnostics(args, atoms: Atoms, state) -> None:
    """Dump step-0 NPT diagnostics for parity debugging."""
    if str(getattr(args, "ensemble", "nvt")).lower() != "npt":
        return
    out_path = Path(args.output_dir) / "step0_npt_diag_pimd.json"
    from macer.pimd.energy import build_npt_stress_components
    cell_ang = np.array(state.cell, dtype=float) / ANG_TO_AU
    dkin_cent = float(getattr(state, "dkinetic_centroid", state.dkinetic))
    (
        static_stress,
        spring_stress,
        kin_stress,
        control_stress,
        p_display_gpa,
    ) = build_npt_stress_components(
        state,
        k_control_au=dkin_cent,
    )
    diag = {
        "step": int(getattr(state, "istepsv", 0)),
        "pressure_gpa_from_state": float(p_display_gpa),
        "temperature_k_from_state": float(state.temp_inst),
        "dkin_au": float(state.dkinetic),
        "dkin_centroid_au": float(getattr(state, "dkinetic_centroid", state.dkinetic)),
        "potential_au": float(state.potential),
        "volume_a3_from_state": float(abs(np.linalg.det(cell_ang))),
        "cell_h_au": np.array(state.h, dtype=float).tolist(),
        "eta": np.array(state.eta, dtype=float).tolist(),
        "zeta": float(state.zeta),
        "pfactor": float(getattr(state, "pfactor", 0.0)),
        "pfact": float(getattr(state, "pfact", 0.0)),
        "external_stress_au": np.array(state.external_stress, dtype=float).tolist(),
        "stress_tensor_au_from_state": np.array(state.stress_inst, dtype=float).tolist(),
        "stress_static_au_from_state": static_stress.tolist(),
        "stress_spring_au_from_state": spring_stress.tolist(),
        "stress_kinetic_au_from_state": kin_stress.tolist(),
        "stress_control_au_reconstructed": control_stress.tolist(),
        "pressure_gpa_static_from_state": float(-np.trace(static_stress) / 3.0 * AU_STRESS_TO_GPA),
        "pressure_gpa_control_from_state": float(-np.trace(control_stress) / 3.0 * AU_STRESS_TO_GPA),
        "stress_voigt_eva3_atoms": None,
        "stress_voigt_eva3_atoms_include_ideal_gas": None,
        "pressure_gpa_from_atoms": None,
        "volume_a3_from_atoms": float(atoms.get_volume()),
    }
    try:
        s_noig = atoms.get_stress(voigt=True, include_ideal_gas=False)
        s_ig = atoms.get_stress(voigt=True, include_ideal_gas=True)
        diag["stress_voigt_eva3_atoms"] = [float(x) for x in s_noig]
        diag["stress_voigt_eva3_atoms_include_ideal_gas"] = [float(x) for x in s_ig]
        diag["pressure_gpa_from_atoms"] = float(-np.mean(np.array(s_ig[:3], dtype=float) * 160.21766208))
    except Exception:
        pass
    out_path.write_text(json.dumps(diag, indent=2))
    print(f"[pimd] Wrote step-0 diagnostics: {out_path}")


def _apply_replica_init_mode(state, args) -> None:
    mode = str(getattr(args, "_replica_init_mode", "clone") or "clone").lower()
    if mode == "clone":
        return

    seed = int(getattr(args, "_replica_init_seed", getattr(args, "seed", 0) or 0))
    rng = np.random.RandomState(seed)
    if mode == "reseed":
        from macer.pimd.initialize import init_bath, init_velocity

        init_velocity(state, args, rng)
        init_bath(state, args, rng)
        print(f"[pimd] Replica init: reseed (seed={seed}).")
        return

    if mode == "jitter":
        from macer.pimd.initialize import temp_ctr

        scale = float(getattr(args, "_replica_jitter_scale", 0.03) or 0.03)
        v = np.asarray(state.vur, dtype=float)
        v_rms = float(np.sqrt(np.mean(v * v))) if v.size else 0.0
        sigma = float(max(0.0, scale) * v_rms)
        if sigma > 0.0:
            state.vur = v + rng.normal(0.0, sigma, size=v.shape)
            temp_ctr(state, float(getattr(args, "temp", 300.0)))
        print(f"[pimd] Replica init: jitter (seed={seed}, scale={scale:.4f}).")
        return

    print(f"[pimd] Warning: unsupported replica init mode '{mode}', using clone.")


def read_structure(args):
    """
    Reads structure using ASE.
    """
    if args.poscar:
        return ase.io.read(args.poscar)
    elif args.cif:
        return ase.io.read(args.cif)
    elif args.formula or args.mpid:
        from macer.relaxation.optimizer import get_structure_from_mp
        # Note: This might import pymatgen and trigger the error, 
        # so we'll wrap it or accept it as a known dependency.
        return get_structure_from_mp(args.formula or args.mpid)
    elif getattr(args, "restart", None):
        restart_path = Path(str(args.restart)).expanduser().resolve()
        if not restart_path.exists():
            return None

        # Preferred fallback: preserved input POSCAR in restart directory.
        for name in ("POSCAR-input", "POSCAR_pimd_mean_final", "POSCAR"):
            cand = restart_path.parent / name
            if cand.exists():
                try:
                    return ase.io.read(str(cand))
                except Exception:
                    pass

        # Secondary fallback: reconstruct Atoms from restart payload.
        try:
            with np.load(restart_path, allow_pickle=True) as d:
                if "symbols" not in d:
                    return None
                symbols = [str(s) for s in np.array(d["symbols"]).tolist()]
                # Canonical v2 payload
                if "r_bead" in d and "cell" in d:
                    r_bead = np.array(d["r_bead"], dtype=float)
                    cell_ang = np.array(d["cell"], dtype=float)
                    if r_bead.ndim == 4:
                        r_bead = r_bead[-1]
                    if cell_ang.ndim == 3:
                        cell_ang = cell_ang[-1]
                    if r_bead.ndim != 3 or r_bead.shape[2] != 3:
                        return None
                    if cell_ang.ndim != 2 or cell_ang.shape != (3, 3):
                        return None
                    centroid_ang = np.mean(r_bead, axis=0)
                    if len(symbols) != int(centroid_ang.shape[0]):
                        return None
                    atoms = Atoms(symbols=symbols, positions=centroid_ang, cell=cell_ang, pbc=True)
                    return atoms
                # state_* fallback
                if "state_r" in d and "state_cell" in d:
                    r_internal = np.array(d["state_r"], dtype=float)  # [3, natom, nbead] in Bohr
                    cell_bohr = np.array(d["state_cell"], dtype=float)
                    if r_internal.ndim != 3 or r_internal.shape[0] != 3:
                        return None
                    if cell_bohr.ndim != 2 or cell_bohr.shape != (3, 3):
                        return None
                    r_bead = np.transpose(r_internal, (2, 1, 0))
                    centroid_ang = np.mean(r_bead, axis=0) / ANG_TO_AU
                    cell_ang = cell_bohr / ANG_TO_AU
                    if len(symbols) != int(centroid_ang.shape[0]):
                        return None
                    atoms = Atoms(symbols=symbols, positions=centroid_ang, cell=cell_ang, pbc=True)
                    return atoms
        except Exception:
            return None
    return None

def run_pimd(args):
    """
    Main entry point for PIMD simulation.
    Orchestrates structure loading, calculator setup, state initialization, and integration loop.
    """
    phase_times_s: dict[str, float] = {}
    t_total0 = time.perf_counter()
    args.npt_debug = bool(getattr(args, "debug", False))
    args.npt_trace = bool(getattr(args, "npt_trace", False))
    is_npt = str(getattr(args, "ensemble", "nvt")).lower() == "npt"
    os.makedirs(args.output_dir, exist_ok=True)
    pimd_log_path = os.path.join(args.output_dir, "pimd.log")

    orig_stdout = sys.stdout
    with open(pimd_log_path, "w", buffering=1) as pimd_log_fp:
        sys.stdout = _StdoutTee(orig_stdout, pimd_log_fp)
        try:
            print(f"\n[pimd] Starting PIMD engine")
            if bool(getattr(args, "sequential", False)):
                if bool(getattr(args, "_auto_sequential_for_replica", False)):
                    print("[pimd] Force evaluation mode: sequential (auto-enabled for --replica safety default).")
                else:
                    print("[pimd] Force evaluation mode: sequential (forced by --sequential).")
            else:
                bs = getattr(args, "batch_size", None)
                if bs is None:
                    print("[pimd] Force evaluation mode: batch-first (auto; effective batch resolved after nbead init).")
                else:
                    print(f"[pimd] Force evaluation mode: batch-first (batch_size={int(bs)}).")
            if is_npt and args.npt_trace:
                print("[pimd] Info: NPT trace enabled (`npt_step_trace_pimd.jsonl`, first 20 steps).")
            if bool(getattr(args, "_auto_nbead", False)):
                print(
                    f"[pimd] Auto: nbead not provided -> nbead={int(args.nbead)} "
                    f"(from temperature T={float(args.temp):.1f} K policy)."
                )
            seed_root = getattr(args, "seed", None)
            seed_origin = "user"
            if seed_root is None:
                seed_root = int.from_bytes(os.urandom(8), "little") & 0xFFFFFFFF
                args.seed = int(seed_root)
                seed_origin = "auto"
            print(f"[pimd] RNG context: seed_root={int(seed_root)} ({seed_origin})")
            rep_idx = getattr(args, "_replica_index", None)
            if rep_idx is not None:
                rep_mode = str(getattr(args, "_replica_init_mode", "clone") or "clone")
                rep_seed = getattr(args, "_replica_init_seed", None)
                seed_root = getattr(args, "_replica_seed_root", getattr(args, "replica_seed_base", None))
                seed_strategy = str(getattr(args, "_replica_seed_strategy", "legacy_plus_index"))
                ctx = (
                    f"[pimd] Replica context: replica_index={int(rep_idx):02d} "
                    f"init_mode={rep_mode} "
                    f"seed={int(rep_seed) if rep_seed is not None else 'NA'} "
                    f"seed_strategy={seed_strategy}"
                )
                if seed_root is not None:
                    ctx += f" (seed_root={int(seed_root)})"
                print(ctx)

            # 1. Load Structure
            t_setup0 = time.perf_counter()
            atoms: Atoms = read_structure(args)
            if atoms is None:
                print("[pimd] Error: Failed to load structure.")
                sys.exit(1)
            input_poscar_path = Path(args.output_dir) / "POSCAR-input"
            try:
                poscar_src = None
                if getattr(args, "poscar", None):
                    candidate = Path(str(args.poscar)).expanduser().resolve()
                    if candidate.exists() and candidate.is_file():
                        poscar_src = candidate
                if poscar_src is not None:
                    shutil.copyfile(poscar_src, input_poscar_path)
                    print(f"[pimd] Preserved input POSCAR: {input_poscar_path}")
                else:
                    ase.io.write(str(input_poscar_path), atoms, format="vasp")
                    print(f"[pimd] Saved input structure as POSCAR: {input_poscar_path}")
            except Exception as exc:
                print(f"[pimd] Warning: failed to preserve POSCAR-input ({exc})")

            # Supercell handle (optional)
            if args.dim:
                from ase.build import make_supercell

                if len(args.dim) == 3:
                    P = np.diag(args.dim)
                else:
                    P = np.array(args.dim).reshape((3, 3))
                atoms = make_supercell(atoms, P)
            atoms.pbc = True
            _apply_mass_override(atoms, getattr(args, "mass_map", None))

            # 2. Setup Calculator (MLFF)
            calc_kwargs = {
                "ff_name": args.ff,
                "device": args.device,
                "modal": args.modal,
            }
            if args.ff == "mace":
                calc_kwargs["model_paths"] = [args.model]
            elif args.ff == "orb":
                # ORB has an internal default model ("orb_v2"); avoid passing None.
                if args.model is not None:
                    calc_kwargs["model_path"] = args.model
            else:
                calc_kwargs["model_path"] = args.model
            calc = get_calculator(**calc_kwargs)
            atoms.calc = calc

            # 3. Configure Simulation Parameters
            if not hasattr(args, "nnhc"):
                args.nnhc = 4
            if not hasattr(args, "nref"):
                args.nref = 1
            if not hasattr(args, "nys"):
                args.nys = 5
            if not hasattr(args, "ttau_effective"):
                args.ttau_effective = args.ttau if args.ttau > 0 else 40.0 * float(args.tstep)
            if (not is_npt) and float(getattr(args, "ttau", 0.0) or 0.0) <= 0.0:
                print(
                    f"[pimd] Auto: ttau not provided (or <=0) -> "
                    f"ttau_effective=40*dt={float(args.ttau_effective):.3f} fs."
                )

            if args.nbead is None:
                args.nbead = 16
                print(f"[pimd] Auto-selected nbead={args.nbead} for T={args.temp}K")

            resolved_bs, batch_policy = resolve_pimd_batch_size(
                calc,
                nbead=int(args.nbead),
                batch_size=getattr(args, "batch_size", None),
                sequential=bool(getattr(args, "sequential", False)),
            )
            setattr(args, "resolved_batch_size", resolved_bs)
            if resolved_bs is None:
                print(f"[pimd] Batch policy: {batch_policy}")
            else:
                print(
                    f"[pimd] Batch policy: nbead={int(args.nbead)}, "
                    f"resolved_batch_size={int(resolved_bs)} | {batch_policy}"
                )
            _apply_md_style_npt_autos(args, atoms)
            if is_npt:
                ttau_eff = float(getattr(args, "ttau", 0.0) or 0.0)
                ptau_eff = float(getattr(args, "ptau", 0.0) or 0.0)
                pf_au = float(getattr(args, "pfactor", 0.0) or 0.0)
                pf_ase = pf_au * PFACTOR_ASE_PER_AU
                print(
                    f"[pimd] Effective NPT params: "
                    f"ttau={ttau_eff:.3f} fs, ptau={ptau_eff:.3f} fs, "
                    f"pfactor={pf_au:.6e} (au; ASE={pf_ase:.6e})."
                )

            phase_times_s["setup_io"] = float(time.perf_counter() - t_setup0)

            # 4. Initialize State
            state = initialize_state(atoms, args)
            state.r_list = [atoms.copy() for _ in range(state.nbead)]

            # 4.1 Load Restart if requested
            if args.restart:
                restart.load_state(args.restart, state)
                if bool(getattr(args, "_restart_step_reset", False)):
                    state.istepsv = 0
                    print("[pimd] Info: restart step counter reset for replica timeline.")
                _apply_replica_init_mode(state, args)

            if not args.restart:
                inv_nbead = 1.0 / state.nbead
                for ibead in range(state.nbead):
                    atoms.set_positions(state.r[:, :, ibead].T * 0.529177249)  # AU to Ang
                    state.pot_beads[ibead] = (atoms.get_potential_energy() / 27.211386) * inv_nbead
                    state.fr[:, :, ibead] = (atoms.get_forces().T * (0.529177249 / 27.211386)) * inv_nbead
                    if args.ensemble == "npt":
                        from ase.constraints import voigt_6_to_full_3x3_stress

                        s_voigt = atoms.get_stress()
                        s_3x3 = voigt_6_to_full_3x3_stress(s_voigt)
                        state.stress_beads[:, :, ibead] = (s_3x3 / EVA3_PER_AU_STRESS) * inv_nbead

                from macer.pimd import transforms, energy
                from macer.pimd.initialize import K_TO_AU

                transforms.nmtrans_fr2fur(state)
                beta = 1.0 / (args.temp * K_TO_AU)
                energy.calculate_observables(state, beta, K_TO_AU)
            else:
                from macer.pimd.initialize import K_TO_AU
                from macer.pimd import energy

                beta = 1.0 / (args.temp * K_TO_AU)
                energy.calculate_observables(state, beta, K_TO_AU)

            # Align helper atoms with centroid snapshot for step-0 diagnostics.
            atoms.set_cell(state.cell / ANG_TO_AU, scale_atoms=False)
            atoms.set_positions(state.ur[:, :, 0].T / ANG_TO_AU)
            if args.npt_debug:
                _write_step0_npt_diagnostics(args, atoms, state)

            print("[pimd] realtime columns: step, H_total(au), T(K), V_pot(au), K_dyn(au), K_q(au), Ebath(au), Ebath_cent(au)")
            print(
                _format_pimd_realtime_line(
                    state,
                    state.istepsv,
                    include_pressure=not is_npt,
                    include_cell=is_npt,
                )
            )
            initial_logged_step = int(state.istepsv)

            # 5. Initialize Integrator (disable ASE md.log logger)
            dyn = PIMDIntegrator(
                atoms=atoms,
                timestep=args.tstep,
                state=state,
                config=args,
                logfile=None,
            )

            # 6. Attach observers
            from ase.io.trajectory import Trajectory

            traj = Trajectory(os.path.join(args.output_dir, "pimd.traj"), "w", atoms)
            xdat_interval = max(int(getattr(args, "save_xdatcar_every", 1)), 1)
            dyn.attach(traj.write, interval=xdat_interval)

            def log_pimd_info():
                if state.istepsv % args.print_every == 0 and int(state.istepsv) != initial_logged_step:
                    print(
                        _format_pimd_realtime_line(
                            state,
                            state.istepsv,
                            include_pressure=not is_npt,
                            include_cell=is_npt,
                        )
                    )

            dyn.attach(log_pimd_info, interval=args.print_every)

            # 7. Legacy logging (ham.dat, XDATCAR, coor.xyz)
            legacy_log_path = os.path.join(args.output_dir, "ham.dat")
            with open(legacy_log_path, "w") as f:
                f.write(
                    "# step hamiltonian(AU) temp_inst(K) potential(AU) dkinetic(AU) qkinetic(AU) ebath(AU) ebath_cent(AU) e_virial(AU) pressure(GPa)\n"
                )

            xdatcar_centroid = os.path.join(args.output_dir, "XDATCAR-PIMD")
            xdatcar_beads = os.path.join(args.output_dir, "XDATCAR-PIMD-BEADS")
            coor_xyz = os.path.join(args.output_dir, "coor.xyz")

            all_symbols = atoms.get_chemical_symbols()
            species = list(dict.fromkeys(all_symbols))
            counts = [all_symbols.count(spec) for spec in species]
            bead_counts = [c * int(state.nbead) for c in counts]
            species_indices = {spec: [i for i, sym in enumerate(all_symbols) if sym == spec] for spec in species}
            species_title = " ".join(species) + "\n"
            species_line = " " + " ".join(f"{s:>2}" for s in species) + "\n"

            def _write_xdatcar_lattice_header(fh, cell_mat, counts_out) -> None:
                # Match `macer md` XDATCAR header format for OVITO compatibility.
                fh.write(species_title)
                fh.write("    1.000000\n")
                for row in cell_mat:
                    fh.write(f"     {row[0]:11.6f} {row[1]:11.6f} {row[2]:11.6f}\n")
                fh.write(species_line)
                fh.write(" " + " ".join(f"{int(c):16d}" for c in counts_out) + "\n")

            def write_xdatcar_header(path, atoms_obj, *, beads_mode: bool = False):
                counts_out = bead_counts if beads_mode else counts
                with open(path, "w") as f:
                    _write_xdatcar_lattice_header(f, atoms_obj.get_cell(), counts_out)

            write_xdatcar_header(xdatcar_centroid, atoms, beads_mode=False)
            write_xdatcar_header(xdatcar_beads, atoms, beads_mode=True)
            with open(coor_xyz, "w") as _:
                pass

            def log_legacy():
                if state.istepsv % xdat_interval == 0:
                    with open(legacy_log_path, "a") as f:
                        f.write(
                            f"{state.istepsv:10d} {state.hamiltonian:18.10e} {state.temp_inst:18.10e} {state.potential:18.10e} "
                            f"{state.dkinetic:18.10e} {state.qkinetic:18.10e} {state.ebath:18.10e} {state.ebath_cent:18.10e} "
                            f"{state.e_virial:18.10e} {state.pressure_inst:18.10e}\n"
                        )

                    at_helper = atoms.copy()
                    at_helper.set_cell(state.cell / ANG_TO_AU, scale_atoms=False)
                    frame_idx = int(state.istepsv) + 1

                    at_helper.set_positions(state.ur[:, :, 0].T * 0.529177249)
                    direct = at_helper.get_scaled_positions(wrap=False)
                    with open(xdatcar_centroid, "a") as f:
                        if is_npt and frame_idx > 1:
                            _write_xdatcar_lattice_header(f, at_helper.get_cell(), counts)
                        f.write(f"Direct configuration= {frame_idx:5d}\n")
                        for row in direct:
                            f.write(f"  {row[0]:11.8f} {row[1]:11.8f} {row[2]:11.8f}\n")

                    with open(xdatcar_beads, "a") as f:
                        if is_npt and frame_idx > 1:
                            _write_xdatcar_lattice_header(f, at_helper.get_cell(), bead_counts)
                        f.write(f"Direct configuration= {frame_idx:5d}\n")
                        bead_direct_positions: list[np.ndarray] = []
                        for ib in range(state.nbead):
                            at_helper.set_positions(state.r[:, :, ib].T * 0.529177249)
                            bead_direct_positions.append(at_helper.get_scaled_positions(wrap=False))
                        for spec in species:
                            for ib in range(state.nbead):
                                direct_ib = bead_direct_positions[ib]
                                for ia in species_indices[spec]:
                                    row = direct_ib[ia]
                                    f.write(f"  {row[0]:11.8f} {row[1]:11.8f} {row[2]:11.8f}\n")

                    if state.istepsv > 0:
                        symbols = atoms.get_chemical_symbols()
                        nline = state.nbead * state.natom
                        with open(coor_xyz, "a") as f:
                            f.write(f"{nline}\n")
                            f.write(f"{state.istepsv}\n")
                            for ib in range(state.nbead):
                                pos_ang = state.r[:, :, ib].T * 0.529177249
                                for ia, sym in enumerate(symbols):
                                    x, y, z = pos_ang[ia]
                                    f.write(f"{sym:2s} {x: .12f} {y: .12f} {z: .12f}\n")

            dyn.attach(log_legacy, interval=xdat_interval)

            # 7.1 Restart saving
            npz_steps: list[int] = []
            npz_r_bead: list[np.ndarray] = []
            npz_f_bead: list[np.ndarray] = []
            npz_cell: list[np.ndarray] = []
            symbols_np = np.array(atoms.get_chemical_symbols(), dtype=object)
            history_npz_path = os.path.join(args.output_dir, "pimd_state_history.npz")
            save_restart_every = int(getattr(args, "save_restart_every", 1) or 1)
            save_checkpoint_every = int(getattr(args, "save_checkpoint_every", 1000) or 1000)

            def _checkpoint_path(step: int) -> Path:
                return Path(args.output_dir) / f"pimd_state_step{int(step):06d}.npz"

            def _append_npz_frame() -> None:
                # state.r shape: [3, natom, nbead] in Bohr -> [nbead, natom, 3] in Angstrom
                # state.fr shape: [3, natom, nbead] in Hartree/Bohr per-bead with 1/nbead scaling in integrator
                # -> [nbead, natom, 3] in eV/Angstrom (physical per-bead forces)
                if not hasattr(state, "fr"):
                    raise RuntimeError("Cannot write history NPZ v2: state.fr is missing (required for f_bead).")
                r_bead_ang = np.transpose(np.asarray(state.r, dtype=float), (2, 1, 0)) * 0.529177249
                fr_internal = np.transpose(np.asarray(state.fr, dtype=float), (2, 1, 0))
                f_bead_eva = fr_internal * 51.422067 * float(state.nbead)
                cell_ang = np.asarray(state.cell, dtype=float) * 0.529177249
                npz_steps.append(int(state.istepsv))
                npz_r_bead.append(r_bead_ang)
                npz_f_bead.append(f_bead_eva)
                npz_cell.append(cell_ang)

            def _append_npz_frame_if_needed() -> None:
                step_now = int(state.istepsv)
                if npz_steps and npz_steps[-1] == step_now:
                    return
                _append_npz_frame()

            def _flush_history_npz(path: str) -> None:
                if not npz_steps:
                    return
                steps_arr = np.array(npz_steps, dtype=int)
                r_bead_arr = np.stack(npz_r_bead, axis=0)  # [nstep, nbead, natom, 3]
                f_bead_arr = np.stack(npz_f_bead, axis=0)  # [nstep, nbead, natom, 3]
                cell_arr = np.stack(npz_cell, axis=0)      # [nstep, 3, 3]
                natom = int(state.natom)
                nbead = int(state.nbead)
                if r_bead_arr.ndim != 4:
                    raise ValueError(f"Invalid r_bead rank for history NPZ: expected 4, got {r_bead_arr.ndim}")
                if r_bead_arr.shape[1] != nbead or r_bead_arr.shape[2] != natom or r_bead_arr.shape[3] != 3:
                    raise ValueError(
                        "Invalid r_bead shape for history NPZ: "
                        f"got {r_bead_arr.shape}, expected (nstep,{nbead},{natom},3)"
                    )
                if f_bead_arr.ndim != 4:
                    raise ValueError(f"Invalid f_bead rank for history NPZ: expected 4, got {f_bead_arr.ndim}")
                if f_bead_arr.shape[1] != nbead or f_bead_arr.shape[2] != natom or f_bead_arr.shape[3] != 3:
                    raise ValueError(
                        "Invalid f_bead shape for history NPZ: "
                        f"got {f_bead_arr.shape}, expected (nstep,{nbead},{natom},3)"
                    )
                if cell_arr.ndim != 3 or cell_arr.shape[1:] != (3, 3):
                    raise ValueError(f"Invalid cell shape for history NPZ: {cell_arr.shape}")
                if (
                    steps_arr.shape[0] != r_bead_arr.shape[0]
                    or steps_arr.shape[0] != f_bead_arr.shape[0]
                    or steps_arr.shape[0] != cell_arr.shape[0]
                ):
                    raise ValueError(
                        "History NPZ length mismatch: "
                        f"steps={steps_arr.shape[0]}, r_bead={r_bead_arr.shape[0]}, "
                        f"f_bead={f_bead_arr.shape[0]}, cell={cell_arr.shape[0]}"
                    )

                symbol_list = [str(s) for s in symbols_np.tolist()]
                species = list(dict.fromkeys(symbol_list))
                species_counts = np.array([symbol_list.count(sp) for sp in species], dtype=int)
                payload = dict(
                    schema_version=np.array("pimd-npz-v2", dtype=object),
                    producer=np.array("macer.pimd.runner", dtype=object),
                    created_at=np.array(datetime.now(timezone.utc).isoformat(), dtype=object),
                    units_length=np.array("angstrom", dtype=object),
                    units_cell=np.array("angstrom", dtype=object),
                    units_force=np.array("eV/angstrom", dtype=object),
                    units_energy=np.array("eV", dtype=object),
                    units_stress=np.array("GPa", dtype=object),
                    pbc=np.array(atoms.get_pbc(), dtype=bool),
                    symbols=symbols_np,
                    species=np.array(species, dtype=object),
                    species_counts=species_counts,
                    frame_valid_mask=np.ones((steps_arr.shape[0],), dtype=bool),
                    steps=steps_arr,
                    r_bead=r_bead_arr,
                    f_bead=f_bead_arr,
                    cell=cell_arr,
                    nbead=np.int64(nbead),
                    natom=np.int64(natom),
                    step=np.int64(steps_arr[-1]),
                )
                required_keys = (
                    "schema_version",
                    "symbols",
                    "steps",
                    "r_bead",
                    "f_bead",
                    "cell",
                    "nbead",
                    "natom",
                    "pbc",
                )
                missing = [k for k in required_keys if k not in payload]
                if missing:
                    raise ValueError(f"History NPZ payload missing required keys: {missing}")

                dst = Path(path)
                dst.parent.mkdir(parents=True, exist_ok=True)
                tmp = dst.with_name(f"{dst.stem}.tmp.npz")
                try:
                    np.savez(tmp, **payload)
                    os.replace(tmp, dst)
                finally:
                    if tmp.exists():
                        try:
                            tmp.unlink()
                        except Exception:
                            pass

            # Include step 0 snapshot in cumulative history.
            _append_npz_frame()
            _flush_history_npz(history_npz_path)

            def save_restart():
                if state.istepsv <= 0:
                    return
                if state.istepsv % save_restart_every == 0:
                    latest_path = os.path.join(args.output_dir, "restart.npz")
                    restart.save_state(state, latest_path, symbols=atoms.get_chemical_symbols())
                    # Keep cumulative history aligned with restart cadence.
                    _append_npz_frame_if_needed()
                    _flush_history_npz(history_npz_path)
                if state.istepsv % save_checkpoint_every == 0:
                    # Save cumulative history on checkpoint cadence and emit step snapshot.
                    _append_npz_frame_if_needed()
                    _flush_history_npz(history_npz_path)
                    step_ckpt = _checkpoint_path(int(state.istepsv))
                    shutil.copyfile(history_npz_path, step_ckpt)
            dyn.attach(save_restart, interval=1)

            # 8. Run
            t_core0 = time.perf_counter()
            print(f"[pimd] Beginning integration: {args.nsteps} steps")
            dyn.run(args.nsteps)
            phase_times_s["external_core"] = float(time.perf_counter() - t_core0)

            # Ensure cumulative history and latest restart are written at final step.
            final_step = int(state.istepsv)
            _append_npz_frame_if_needed()
            _flush_history_npz(history_npz_path)
            latest_path = os.path.join(args.output_dir, "restart.npz")
            restart.save_state(state, latest_path, symbols=atoms.get_chemical_symbols())

            # 9. Post-processing (disabled for pimd runtime path)
            t_post0 = time.perf_counter()
            phase_times_s["postprocess_total"] = float(time.perf_counter() - t_post0)
            phase_times_s["wrapper_init"] = 0.0
            phase_times_s["wall_total"] = float(time.perf_counter() - t_total0)

            phase_times_s.setdefault("post_ham_csv", 0.0)
            phase_times_s.setdefault("post_traj_parse", 0.0)
            phase_times_s.setdefault("post_outputs", float(phase_times_s["postprocess_total"] + phase_times_s["post_ham_csv"]))

            _report_phase_timings(Path(args.output_dir), phase_times_s, emit_stdout=False)
            # Rename generic timing log to pimd specific name for clarity.
            try:
                timing_src = Path(args.output_dir) / "pimd-calculation.log"
                timing_dst = Path(args.output_dir) / "pimd-timing.log"
                if timing_src.exists():
                    timing_src.replace(timing_dst)
            except Exception:
                pass
            print("[pimd] Simulation finished successfully.")
        finally:
            sys.stdout = orig_stdout
