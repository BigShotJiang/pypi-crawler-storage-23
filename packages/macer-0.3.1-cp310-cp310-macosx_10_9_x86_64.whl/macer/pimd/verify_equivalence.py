import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import numpy as np
from ase.build import molecule
from ase.io import write


def _run(cmd: list[str], env: dict[str, str] | None = None) -> None:
    print("Running:", " ".join(cmd))
    subprocess.run(cmd, check=True, env=env)


def _load_ham(path: Path) -> np.ndarray:
    arr = np.loadtxt(str(path), comments="#")
    if arr.ndim == 1:
        arr = arr[np.newaxis, :]
    return arr


def _ensure_poscar(path: Path) -> Path:
    if path.exists():
        return path
    path.parent.mkdir(parents=True, exist_ok=True)
    atoms = molecule("H2O")
    atoms.center(vacuum=6.0)
    atoms.pbc = False
    write(str(path), atoms, format="vasp")
    return path


def _align_by_step(native: np.ndarray, external: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    if native.shape[1] == 0 or external.shape[1] == 0:
        return native[:0], external[:0]
    native_steps = native[:, 0].astype(int)
    external_steps = external[:, 0].astype(int)
    common = sorted(set(native_steps.tolist()) & set(external_steps.tolist()))
    if not common:
        return native[:0], external[:0]
    nidx = [int(np.where(native_steps == s)[0][0]) for s in common]
    eidx = [int(np.where(external_steps == s)[0][0]) for s in common]
    return native[nidx], external[eidx]


def _calc_metrics(native: np.ndarray, external: np.ndarray) -> dict:
    native, external = _align_by_step(native, external)
    nrow = len(native)
    ncol = min(native.shape[1], external.shape[1]) if nrow > 0 else 0
    native = native[:, :ncol] if nrow > 0 else native
    external = external[:, :ncol] if nrow > 0 else external
    diff = native - external
    abs_diff = np.abs(diff)

    headers = [
        "step",
        "hamiltonian",
        "temp",
        "potential",
        "dkinetic",
        "qkinetic",
        "ebath",
        "ebath_cent",
        "e_virial",
        "pressure",
    ][:ncol]
    by_col = {}
    for i, name in enumerate(headers):
        col = diff[:, i]
        by_col[name] = {
            "max_abs": float(np.max(np.abs(col))),
            "mean_abs": float(np.mean(np.abs(col))),
            "rms": float(np.sqrt(np.mean(col**2))),
            "last_abs": float(np.abs(col[-1])),
        }

    drift = {}
    if ncol > 1:
        dh_native = native[:, 1] - native[0, 1]
        dh_external = external[:, 1] - external[0, 1]
        drift["hamiltonian_drift_max_abs"] = float(np.max(np.abs(dh_native - dh_external)))
        drift["hamiltonian_drift_last_abs"] = float(np.abs((dh_native - dh_external)[-1]))
    if ncol > 2:
        dt_native = native[:, 2] - native[0, 2]
        dt_external = external[:, 2] - external[0, 2]
        drift["temp_drift_max_abs"] = float(np.max(np.abs(dt_native - dt_external)))
        drift["temp_drift_last_abs"] = float(np.abs((dt_native - dt_external)[-1]))

    return {
        "rows_compared": int(nrow),
        "cols_compared": int(ncol),
        "steps_compared": native[:, 0].astype(int).tolist() if nrow > 0 else [],
        "by_column": by_col,
        "drift": drift,
    }


def _write_markdown(report: dict, out_md: Path) -> None:
    lines = ["# PIMD Equivalence Report", ""]
    lines.append(f"- poscar: `{report['config']['poscar']}`")
    lines.append(f"- ff: `{report['config']['ff']}`")
    lines.append(f"- ensemble: `{report['config']['ensemble']}`")
    lines.append(f"- temp: `{report['config']['temp']}`")
    lines.append(f"- nbead: `{report['config']['nbead']}`")
    lines.append(f"- nref: `{report['config']['nref']}`")
    lines.append(f"- tstep: `{report['config']['tstep']}`")
    lines.append(f"- seed: `{report['config']['seed']}`")
    lines.append("")

    for case in report["cases"]:
        lines.append(f"## nsteps={case['nsteps']}")
        lines.append(f"- native: `{case['native_dir']}`")
        lines.append(f"- external: `{case['external_dir']}`")
        lines.append(f"- rows_compared: {case['metrics']['rows_compared']}")
        lines.append("")
        lines.append("| column | max_abs | mean_abs | rms | last_abs |")
        lines.append("|---|---:|---:|---:|---:|")
        for k, v in case["metrics"]["by_column"].items():
            lines.append(
                f"| {k} | {v['max_abs']:.6e} | {v['mean_abs']:.6e} | {v['rms']:.6e} | {v['last_abs']:.6e} |"
            )
        if case["metrics"]["drift"]:
            lines.append("")
            lines.append("Drift:")
            for k, v in case["metrics"]["drift"].items():
                lines.append(f"- {k}: {v:.6e}")
        lines.append("")

    out_md.write_text("\n".join(lines) + "\n")


def main() -> None:
    p = argparse.ArgumentParser(description="Compare macer pimd vs util pimd-python (ham.dat based).")
    p.add_argument("--poscar", type=str, default="workdir/POSCAR_EQ_H2O", help="Input POSCAR.")
    p.add_argument("--workdir", type=str, default="workdir/verify_equivalence", help="Working directory.")
    p.add_argument("--temp", type=float, default=300.0)
    p.add_argument("--nbead", type=int, default=8)
    p.add_argument("--nref", type=int, default=5)
    p.add_argument("--tstep", type=float, default=0.1)
    p.add_argument("--seed", type=int, default=101)
    p.add_argument("--ff", type=str, default="emt")
    p.add_argument("--ensemble", type=str, default="nvt", choices=["nvt", "nte", "nve"])
    p.add_argument("--nsteps", type=int, default=20, help="Used when --steps-list is not provided.")
    p.add_argument("--steps-list", type=str, default=None, help="Comma-separated sweep, e.g. 10,100,1000")
    args = p.parse_args()

    if args.steps_list:
        steps_list = [int(x.strip()) for x in args.steps_list.split(",") if x.strip()]
    else:
        steps_list = [int(args.nsteps)]

    workdir = Path(args.workdir).resolve()
    if workdir.exists():
        shutil.rmtree(workdir)
    workdir.mkdir(parents=True, exist_ok=True)

    poscar = _ensure_poscar(Path(args.poscar).resolve())
    env = dict(os.environ)
    env["PYTHONPATH"] = "."

    report = {
        "config": {
            "poscar": str(poscar),
            "ff": args.ff,
            "ensemble": args.ensemble,
            "temp": args.temp,
            "nbead": args.nbead,
            "nref": args.nref,
            "tstep": args.tstep,
            "seed": args.seed,
            "steps_list": steps_list,
        },
        "cases": [],
    }

    for nsteps in steps_list:
        case_root = workdir / f"case-{nsteps}"
        out_native = case_root / "native"
        out_external = case_root / "external"
        out_native.mkdir(parents=True, exist_ok=True)
        out_external.mkdir(parents=True, exist_ok=True)

        common = [
            "-p",
            str(poscar),
            "--ff",
            args.ff,
            "--ensemble",
            args.ensemble,
            "-T",
            str(args.temp),
            "--nbead",
            str(args.nbead),
            "--nsteps",
            str(nsteps),
            "--nref",
            str(args.nref),
            "--tstep",
            str(args.tstep),
            "--seed",
            str(args.seed),
        ]

        _run(
            [
                sys.executable,
                "-m",
                "macer.cli.main",
                "pimd",
                *common,
                "--output-dir",
                str(out_native),
            ],
            env=env,
        )

        # Keep external path lightweight while preserving ham.dat cadence parity.
        _run(
            [
                sys.executable,
                "-m",
                "macer.cli.main",
                "util",
                "pimd-python",
                *common,
                "--output-dir",
                str(out_external),
                "--detailed-output",
                "--external-out-every",
                "1",
                "--save-xdatcar-every",
                "100000",
                "--save-poscar-every",
                "100000",
                "--save-distribution-every",
                "100000",
                "--postprocess-later",
                "--no-distribution-pdf",
            ],
            env=env,
        )

        ham_native = _load_ham(out_native / "ham.dat")
        ham_external = _load_ham(out_external / "ham.dat")
        metrics = _calc_metrics(ham_native, ham_external)
        report["cases"].append(
            {
                "nsteps": int(nsteps),
                "native_dir": str(out_native),
                "external_dir": str(out_external),
                "metrics": metrics,
            }
        )

        print(f"\n=== nsteps={nsteps} summary ===")
        for k, v in metrics["by_column"].items():
            print(f"{k:>12s}: max_abs_diff={v['max_abs']:.6e}")

    out_json = workdir / "equiv-report.json"
    out_md = workdir / "equiv-report.md"
    out_json.write_text(json.dumps(report, indent=2) + "\n")
    _write_markdown(report, out_md)
    print(f"\nSaved report:\n  {out_json}\n  {out_md}")


if __name__ == "__main__":
    main()
