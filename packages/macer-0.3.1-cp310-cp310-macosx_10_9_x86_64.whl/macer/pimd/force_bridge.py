from __future__ import annotations

import threading
import time
from typing import Any

import numpy as np

from macer.calculator.factory import evaluate_batch, evaluate_sequential


def evaluate_bead_forces(
    calculator: Any,
    atoms_list: list,
    *,
    need_stress: bool = False,
    batch_size: int | None = None,
    sequential: bool = False,
    label: str = "PIMD",
) -> tuple[list[np.ndarray], list[float], list[np.ndarray] | None]:
    """Evaluate bead structures with batch-first policy and sequential fallback."""
    if not atoms_list:
        return [], [], [] if need_stress else None

    properties = ["energy", "forces"]
    if need_stress:
        properties.append("stress")

    stop_evt = threading.Event()
    hb = None
    if not sequential:
        try:
        # Keep the same alive-style message used in other batch workflows.
            def _heartbeat():
                t0 = time.time()
                while not stop_evt.wait(30.0):
                    elapsed = int(time.time() - t0)
                    print(
                        f"  {label} batch running... {elapsed}s "
                        f"(alive, n_structures={len(atoms_list)})"
                    )

            hb = threading.Thread(target=_heartbeat, daemon=True)
            hb.start()
            res = evaluate_batch(
                calculator,
                atoms_list,
                batch_size=batch_size,
                properties=properties,
                verbose=False,
            )
            stop_evt.set()
            hb.join(timeout=0.1)

            forces = [np.array(f, dtype=float) for f in res["forces"]]
            energies = [float(e) for e in res["energy"]]
            stresses = None
            if need_stress:
                if "stress" not in res:
                    raise RuntimeError("Batch result does not contain 'stress'.")
                stresses = [np.array(s, dtype=float) for s in res["stress"]]
            return forces, energies, stresses

        except Exception as exc:
            try:
                stop_evt.set()
                if hb is not None:
                    hb.join(timeout=0.1)
            except Exception:
                pass
            print(f"[pimd] Warning: {label} batch evaluation failed: {exc}")
            print("[pimd]          Falling back to sequential evaluation.")
    else:
        print(f"[pimd] Info: {label} running in forced sequential mode (--sequential).")

    res = evaluate_sequential(
        calculator,
        atoms_list,
        properties=properties,
        verbose=False,
    )
    forces = [np.array(f, dtype=float) for f in res["forces"]]
    energies = [float(e) for e in res["energy"]]
    stresses = None
    if need_stress:
        stresses = [np.array(s, dtype=float) for s in res["stress"]]
    return forces, energies, stresses
