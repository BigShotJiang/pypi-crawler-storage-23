import sys
from pathlib import Path


def _normalize_value(value):
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (list, tuple)):
        return [str(v) if isinstance(v, Path) else v for v in value]
    if isinstance(value, dict):
        out = {}
        for k, v in value.items():
            out[k] = str(v) if isinstance(v, Path) else v
        return out
    return value


def format_run_summary(args, title="Execution Summary"):
    data = vars(args) if hasattr(args, "__dict__") else {}
    keys = sorted(k for k in data.keys() if k not in {"func"})
    lines = [f"--- {title} ---", f"Command: {' '.join(sys.argv)}", "Effective arguments:"]
    for k in keys:
        v = _normalize_value(data.get(k))
        lines.append(f"  - {k}: {v}")
    lines.append("-" * 50)
    return "\n".join(lines)


def print_run_summary(args, title="Execution Summary"):
    print(format_run_summary(args, title=title))
