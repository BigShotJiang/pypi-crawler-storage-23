import argparse
import sys

_PATCHED = False


def enable_helpful_argparse_errors():
    """
    Make argparse print command help first, then show a clear final reason line.
    Applies process-wide once and affects all ArgumentParser instances.
    """
    global _PATCHED
    if _PATCHED:
        return

    def _patched_error(self, message):
        self.print_help(sys.stderr)
        self.exit(2, f"\nArgument issue: {message}\n")

    argparse.ArgumentParser.error = _patched_error
    _PATCHED = True

