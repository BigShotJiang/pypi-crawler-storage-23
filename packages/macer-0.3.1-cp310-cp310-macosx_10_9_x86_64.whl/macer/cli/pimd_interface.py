
"""
Macer PIMD Interface
Allows PIMD (pimd.x) to drive Macer calculators (MLFF) via a client-server model.
This avoids reloading the MLFF model at every step.
"""

import sys
import os
import time
import socket
import threading
import struct
import shutil
import subprocess
import numpy as np
from ase import Atoms
from ase.units import Bohr

from macer.calculator.factory import get_calculator

# Default PIMD settings
DEFAULT_TIMEOUT = 600  # Seconds to wait for PIMD connection/data

def get_free_port():
    """Get a free port on localhost."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('localhost', 0))
        _, port = s.getsockname()
        return port

class PimdSocketServer(threading.Thread):
    def __init__(self, port, calculator, nbead, natom, symbol_list, stop_event):
        super().__init__()
        self.port = port
        self.calculator = calculator
        self.nbead = nbead
        self.natom = natom
        self.symbol_list = symbol_list
        self.stop_event = stop_event
        self.daemon = True
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.bind(('localhost', self.port))
        self.sock.listen(5)
        self.lock = threading.Lock()

    def run(self):
        """Run the server loop."""
        print(f"[Macer-PIMD] Server listening on port {self.port}...")
        self.sock.settimeout(1.0) # check stop_event periodically
        
        while not self.stop_event.is_set():
            try:
                conn, addr = self.sock.accept()
            except socket.timeout:
                continue
            except Exception as e:
                print(f"[Macer-PIMD] Socket error: {e}")
                break

            # Handle client in a thread (though logic is sequential, PIMD calls one by one)
            # Actually, PIMD calls external program synchronously, so we can handle it here or in thread.
            # Using thread allows handling quick reconnections.
            t = threading.Thread(target=self.handle_client, args=(conn,))
            t.start()

    def handle_client(self, conn):
        with conn:
            try:
                # 1. Receive data size (positions)
                # nbead * natom * 3 * 8 bytes (float64)
                data_size = self.nbead * self.natom * 3 * 8
                
                # Read all data
                raw_data = b''
                while len(raw_data) < data_size:
                    packet = conn.recv(data_size - len(raw_data))
                    if not packet:
                        return
                    raw_data += packet
                
                # Unpack coordinates (Bohr)
                # PIMD sends in Bohr
                positions_bohr = np.frombuffer(raw_data, dtype=np.float64).reshape(self.nbead, self.natom, 3)
                
                # 2. Compute Energy and Forces
                energies = []
                forces = []
                
                # Calculate for each bead
                # Optimization: Could batch if calculator supports it, but standard ASE calc is one-by-one.
                # However, calculator is stateful. We should be careful about state?
                # Usually get_potential_energy / get_forces is fine.
                
                for ib in range(self.nbead):
                    # Convert Bohr to Angstrom for ASE
                    # 1 Bohr = 0.529177210903 Angstrom
                    pos_angstrom = positions_bohr[ib] * 0.529177210903
                    
                    atoms = Atoms(symbols=self.symbol_list, positions=pos_angstrom)
                    # We reuse the same calculator instance
                    # This assumes the calculator can handle changing atoms repeatedly efficiently (MLFFs usually do)
                    atoms.calc = self.calculator
                    
                    e = atoms.get_potential_energy() # eV
                    f = atoms.get_forces() # eV/Angstrom
                    
                    # Convert back to atomic units for PIMD
                    # Energy: eV -> Hartree
                    # Force: eV/Angstrom -> Hartree/Bohr
                    
                    # Constants from ASE
                    # Bohr = 0.529177210903 Angstrom (ase.units.Bohr)
                    # Hartree = 27.211386245988 eV (ase.units.Hartree)
                    from ase.units import Hartree, Bohr as Bohr_ase
                    
                    e_au = e / Hartree
                    f_au = f / (Hartree / Bohr_ase)
                    
                    energies.append(e_au)
                    forces.append(f_au)
                
                # 3. Pack results
                # Energies: nbead floats
                # Forces: nbead * natom * 3 floats
                
                energies_arr = np.array(energies, dtype=np.float64)
                forces_arr = np.array(forces, dtype=np.float64)
                
                response = energies_arr.tobytes() + forces_arr.tobytes()
                conn.sendall(response)
                
            except Exception as e:
                print(f"[Macer-PIMD] Calculation error: {e}")
                # Send error or just close? PIMD will crash if we close.
                # Ideally send zeros or some signal.

def generate_adapter_script(port, nbead, natom):
    """Generate the python script that pimd.x calls."""
    script_content = f"""
import sys
import socket
import numpy as np
import os

PORT = {port}
NBEAD = {nbead}
NATOM = {natom}

# PIMD 'USER' interface writes 'pos.inp'
# Format: simple list of x y z
# We assume 'pos.inp' exists.

def main():
    try:
        # Read positions
        # PIMD writes all beads sequentially
        pos_data = np.loadtxt("pos.inp")
        if pos_data.size != NBEAD * NATOM * 3:
            raise ValueError(f"Shape mismatch: {{pos_data.size}} vs {{NBEAD*NATOM*3}}")
            
        pos_bytes = pos_data.astype(np.float64).tobytes()
        
        # Connect to server
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect(('localhost', PORT))
            s.sendall(pos_bytes)
            
            # Receive results
            # Energy: NBEAD * 8 bytes
            # Forces: NBEAD * NATOM * 3 * 8 bytes
            e_size = NBEAD * 8
            f_size = NBEAD * NATOM * 3 * 8
            total_size = e_size + f_size
            
            response = b''
            while len(response) < total_size:
                packet = s.recv(total_size - len(response))
                if not packet:
                    break
                response += packet
                
            if len(response) != total_size:
                raise RuntimeError("Incomplete response from Macer server")
                
            energies = np.frombuffer(response[:e_size], dtype=np.float64)
            forces = np.frombuffer(response[e_size:], dtype=np.float64).reshape(-1, 3) # reshape to flat list of forces
            
        # Write output
        # out.dat format required by generic 'force_user' ?
        # Actually our verifying run_suite.py adapter combined them:
        # PIMD documentation says 'forces.out' and 'energy.out' typically?
        # But 'force_user.F90' typically relies on what user_command does.
        # Wait, run_suite.py adapter wrote to 'out.dat'.
        # Let's verify what PIMD reads.
        # It reads from <user_output_file>, usually 'out.dat'.
        # The expected format in 'out.dat' is:
        # For each bead:
        #   Energy (1 line)
        #   Forces (natom lines)
        
        with open("out.dat", "w") as f:
            # We must interleave? Or E first then F?
            # Re-checking run_suite.py adapter:
            #   with open("energy.out", "r") as f: out.write(f.read())
            #   with open("forces.out", "r") as f: out.write(f.read())
            # So run_suite.py wrote ALL energies, THEN ALL forces.
            # Is that what force_user.F90 expects?
            #
            # Re-reading force_user.F90 logic would be good, but assuming run_suite.py worked,
            # we should follow its pattern: All Energies block, then All Forces block.
            
            np.savetxt(f, energies)
            np.savetxt(f, forces)
            
    except Exception as e:
        sys.stderr.write(f"Adapter Error: {{e}}\\n")
        sys.exit(1)

if __name__ == "__main__":
    main()
"""
    with open("adapter.py", "w") as f:
        f.write(script_content)

def run_pimd_interface(args):
    """Main entry point for 'macer util pimd-interface'."""
    
    # 1. Load Calculator
    print(f"[Macer] Loading model: {args.ff} / {args.model} on {args.device}...")
    try:
        calc = get_calculator(args.ff, model=args.model, device=args.device, default_dtype="float64")
    except Exception as e:
        print(f"[Error] Failed to load calculator: {e}")
        return

    # 2. Read POSCAR to get atoms info
    from ase.io import read
    if not os.path.exists(args.poscar):
        print(f"[Error] POSCAR not found at {args.poscar}")
        return
    
    # Check for PIMD executable
    pimd_exe = "pimd.x" # Default
    # Check environment variable or config? (TODO in future step)
    if not shutil.which(pimd_exe):
        # Locate local build from scripts/Makefile.pimd.mac?
        # Or look in @macer/externals (not implemented yet)
        if os.path.exists("./pimd.x"):
             pimd_exe = "./pimd.x"
        else:
            print("[Error] 'pimd.x' not found.")
            print("Please compile PIMD (v2.7.1) and modify your PATH or place it here.")
            print(f"Compilation helper: scripts/Makefile.pimd.mac")
            return

    atoms = read(args.poscar)
    natom = len(atoms)
    # Sort symbols for OLD style input compliance
    # We must sort atoms by symbol because PIMD 'OLD' style reads species sequentially.
    # We will generate input.dat with sorted species, so our server must expect sorted atoms.
    # We update 'atoms' to be sorted.
    atoms.pbc = True 
    original_indices = np.argsort(atoms.get_chemical_symbols())
    atoms = atoms[original_indices] # Reordered
    
    symbol_list = atoms.get_chemical_symbols()
    masses = atoms.get_masses()
    unique_symbols = sorted(list(set(symbol_list))) # PIMD sorts species alphabetically usually?
    # Actually PIMD 'OLD' style: we define <nsymbol> then list species.
    # The order we list in input.dat must match the order in pos.inp or centroid.dat?
    # No, 'read_species_old' assigns species ID.
    
    # 3. Setup Server
    port = get_free_port()
    stop_event = threading.Event()
    server = PimdSocketServer(port, calc, args.nbead, natom, symbol_list, stop_event)
    server.start()
    
    # 4. Generate Files
    # input.dat, centroid.dat, adapter.py
    
    # We use run_suite.py logic for input.dat
    # Note: centroid.dat must use Bohr!
    
    # Write centroid.dat (Bohr)
    pos_bohr = atoms.get_positions() / 0.529177210903
    with open("centroid.dat", "w") as f:
        # PIMD format: x y z ikind (for each atom)
        # But wait, verification said 'OLD' style uses 'read_species_old' which reads from input.dat?
        # And 'init_centroid_old' reads from centroid.dat.
        # Let's check format again.
        # From run_suite.py:
        # f.write(f"{natom}\n")
        # f.write(f"# ...\n")
        # for i, atom in enumerate(sorted_atoms): ...
        
        # We REPLICATE run_suite.py structure: Raw coordinates in Bohr (no header, no symbols)
        for i, atom in enumerate(atoms):
            p = pos_bohr[i]
            f.write(f"{p[0]:.10f} {p[1]:.10f} {p[2]:.10f}\n")

    # Write adapter.py
    generate_adapter_script(port, args.nbead, natom)
    
    # Write input.dat
    with open("input.dat", "w") as f:
        # Basic tags
        f.write(f"<method>\nPIMD\n") 
        # For now hardcode PIMD for MD. 
        # Support args.ensemble later if needed. 'nvt' is default.
        
        f.write(f"<temperature>\n{args.temp}\n")
        f.write(f"<pressure>\n{getattr(args, 'pressure', 0.0)}\n") # args might not have pressure
        f.write(f"<nbead>\n{args.nbead}\n")
        f.write(f"<dt>\n{args.tstep}\n") # args.tstep from parser
        f.write(f"<nstep>\n{args.nsteps}\n")
        f.write(f"<time_bath>\n10.0\n") 
        f.write(f"<time_baro>\n10.0\n")
        f.write(f"<iprint>\n{args.print_every}\n")
        f.write(f"<iprint_rest>\n{args.save_every}\n")
        f.write(f"<input_style>\nOLD\n")
        f.write(f"<natom>\n{natom}\n")
        
        # Species
        # Species (OLD style: <nspec> block)
        # <nspec>
        # N
        # Sym1 Mass1 Count1
        # Sym2 Mass2 Count2
        f.write(f"<nspec>\n{len(unique_symbols)}\n")
        from ase.data import atomic_numbers
        
        for s in unique_symbols:
            # Find mass and count
            indices = [i for i, x in enumerate(symbol_list) if x == s]
            count = len(indices)
            # Mass from atoms object (assuming all atoms of species have same mass)
            mass = atoms[indices[0]].mass
            f.write(f"{s} {mass:.5f} {count}\n")
            
        # <nsymbol> block (Required for mapping to atomic numbers)
        f.write(f"<nsymbol>\n{len(unique_symbols)}\n")
        for s in unique_symbols:
             f.write(f"{s} {atomic_numbers[s]}\n")
        
        # Bath setup (MNHC default as per run_suite.py)
        if hasattr(args, 'bath_type') and args.bath_type:
             f.write(f"<bath_type>\n{args.bath_type.upper()}\n")
        else:
             f.write("<bath_type>\nMNHC\n") # Default
        
        # Add Thermostat details (required for MNHC/NHC)
        f.write(f"<nnhc>\n{getattr(args, 'nnhc', 4)}\n")
        f.write(f"<ncolor>\n1\n") 
        f.write(f"<nys>\n{getattr(args, 'nys', 3)}\n") 
        f.write(f"<nref>\n{getattr(args, 'nref', 1)}\n")
             
        if hasattr(args, 'ensemble') and args.ensemble:
             f.write(f"<ensemble>\n{args.ensemble.upper()}\n")
        else:
             f.write("<ensemble>\nNVT\n")
             
        # Boundary (Essential for periodic systems)
        if atoms.pbc.any():
            f.write("<iboundary>\nANGSTROM\n")
            cell = atoms.get_cell()
            for vec in cell:
                f.write(f"{vec[0]:.10f} {vec[1]:.10f} {vec[2]:.10f}\n")
        else:
            f.write("<iboundary>\nANGSTROM\n")
            cell = atoms.get_cell()
            if np.allclose(cell, 0.0):
                cell = np.eye(3) * 20.0 # Default box
            for vec in cell:
                 f.write(f"{vec[0]:.10f} {vec[1]:.10f} {vec[2]:.10f}\n")

        # <species> block
        f.write("<species>\n")
        for s in unique_symbols:
            indices = [i for i, x in enumerate(symbol_list) if x == s]
            mass = atoms[indices[0]].mass
            f.write(f"{s} {mass}\n")

        # User Interface
        f.write("<ipotential>\nUSER\n")
        f.write("<user_input_file>\npos.inp\n")
        f.write("<user_output_file>\nout.dat\n")
        f.write(f"<user_command>\n'{sys.executable} adapter.py'\n")
        
        # Mandatory Dummy Tags
        f.write("<mech_type>\nNONE\n") # Mandatory in v2.7.1
        f.write("<iprint_mech>\n0\n")  # Mandatory
        f.write("<iprint_std>\n0\n")   # Mandatory
        f.write("<iprint_bond>\n0\n")
        f.write("<iprint_angle>\n0\n")
        f.write("<iprint_dihed>\n0\n")
        f.write("<iprint_impro>\n0\n")
        f.write("<iprint_cross>\n0\n")
        f.write("<iprint_eavg>\n0\n")
        f.write("<iprint_prim>\n0\n")
        f.write("<iprint_vir>\n0\n")
        f.write("<iprint_rgy>\n0\n")
        f.write("<iprint_len>\n0\n")
        f.write("<iprint_pair>\n0\n")
        f.write("<iprint_rdf>\n0\n")
        f.write("<iprint_trj>\n0\n")
        f.write("<iprint_cent>\n0\n")
        f.write("<iprint_dip>\n0\n")
        f.write("<iprint_pol>\n0\n")
        f.write("<iprint_mom>\n0\n")
        f.write("<iprint_xyz>\n0\n")
        f.write("<iprint_xsf>\n0\n")
        f.write("<iprint_dcd>\n0\n")
        f.write("<iprint_box>\n0\n")
        f.write("<iprint_cons>\n0\n")
        f.write("<iprint_rdfbead>\n0\n")
        f.write("<iprint_minfo>\n0\n")
        f.write("<iprint_oniom>\n0\n")
        f.write("<iprint_qmmm>\n0\n")
        f.write("<iprint_poly>\n0\n")
        f.write("<iprint_rdfcent>\n0\n")
        f.write("<iprint_akin>\n0\n")
        f.write("<iprint_cavg>\n0\n")
        f.write("<qmmm_potential>\nNONE\n")
        f.write("<qmmm_embedding>\nEE\n")
        f.write("<oniom_hi_potential>\nNONE\n")
        f.write("<oniom_lo_potential>\nNONE\n")
        f.write(f"<beadspread>\n{args.temp}\n")
        f.write("<iread_exit>\n0\n")
        f.write("<nph_type>\nNONE\n")
        f.write("<nth_type>\nNONE\n")
        f.write("<npt_type>\nNONE\n")
        f.write("<ntt_type>\nNONE\n")
        f.write("<iorder_hmc>\n2\n")
        f.write("<irem_type>\nNONE\n")
        f.write("<ends_string>\nNONE\n")
        f.write("<pimd_command>\npimd.x\n")
        f.write("<equation_om>\nUNDER\n")
        f.write("<afed_type>\nNONE\n")
        f.write("<tamd_type>\nNONE\n")
        f.write("<logmfd_type>\nNONE\n")
        f.write("<tension>\n0.0 0.0 0.0\n0.0 0.0 0.0\n0.0 0.0 0.0\n")
        f.write("<atom_change>\n0\n")
        f.write("<igamma>\n0\n")
        f.write("<time_mode>\n1.0\n")
        f.write("<ncons>\n0\n")
        f.write("<corrections>\n0 0\n")

     # Copy input.dat to input_default.dat (Required by PIMD 2.7.1)
    shutil.copy("input.dat", "input_default.dat")

    # 5. Run PIMD
    print(f"[Macer-PIMD] Starting {pimd_exe}...")
    try:
        # Clean logs
        if os.path.exists("pimd.log"): os.remove("pimd.log")
        
        process = subprocess.Popen(
            [pimd_exe],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        # Tail log logic?
        # subprocess.PIPE means we capture it. PIMD writes to stdout?
        # run_suite.py didn't see standard.out because of error.
        # But typically PIMD writes to stdout OR files.
        # The logs earlier in verification showed output in pimd.log ? 
        # No, pimd.log was the file I was trying to cat.
        # PIMD usually writes to 'standard.out' if redirected? 
        # Checking run_suite.py: it captured output?
        # Actually checking verification logs: "PIMD run complete with output files... pimd.log"
        #
        # If I run `pimd.x`, it usually writes to stdout.
        # I should redirect stdout to a file but also print some progress.
        
        # Let's write to pimd.log and tail it for the user.
        with open("pimd.log", "w") as log:
             # We can use tee-like behavior if we want.
             # Or just Popen and read stdout.
             pass
        # Actually, PIMD creates `pimd.log` itself? No, standard.out.
        # I will let PIMD write to stdout, and I will capture it line by line.
        
        while True:
            output = process.stdout.readline()
            if output == '' and process.poll() is not None:
                break
            if output:
                print(output.strip()) # Stream to user
                
        rc = process.poll()
        if rc != 0:
            print(f"[Error] PIMD exited with code {rc}")
            stderr = process.stderr.read()
            print(stderr)
            
    except Exception as e:
        print(f"[Error] Execution failed: {e}")
    finally:
        stop_event.set()
        server.join()
        print("[Macer-PIMD] Finished.")

