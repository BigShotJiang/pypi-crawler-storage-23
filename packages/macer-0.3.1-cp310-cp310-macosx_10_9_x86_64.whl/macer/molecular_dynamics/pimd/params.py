from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PIMDRunConfig:
    ff: str
    model: str | None
    device: str | None
    modal: str | None
    nbead: int
    nsteps: int
    tstep: float
    ensemble: str
    temperature: float
    nref: int
    nys: int
    nnhc: int
    igamma: int
    ttau_effective: float
    bath_type: str
    seed: int | None
    poscar: str | None
    cif: str | None
    formula: str | None
    mpid: str | None
    dim: list[int] | None
    output_dir: str | None
    batch_size: int | None
    sequential: bool
    restart: str | None
    restart_npz: str | None
    mass_map: dict[str, float] | None
    print_every: int
    external_out_every: int
    save_restart_every: int
    checkpoint_keep: int
    save_xdatcar_every: int
    save_poscar_every: int
    save_distribution_every: int
    postprocess_later: bool
    distribution_pdf: bool
    distribution_point_alpha: float
    distribution_point_size: float


def auto_nbead_from_temperature(temp_k: float) -> int:
    t = float(temp_k)
    if t <= 75.0:
        return 64
    if t <= 150.0:
        return 32
    if t <= 300.0:
        return 16
    if t <= 600.0:
        return 8
    return 4


def _parse_mass_map(raw_mass_args) -> dict[str, float] | None:
    if not raw_mass_args:
        return None
    if len(raw_mass_args) % 2 != 0:
        raise ValueError("Error: --mass requires Symbol Mass pairs (e.g. --mass H 2.014 O 15.999).")

    mass_map: dict[str, float] = {}
    for idx in range(0, len(raw_mass_args), 2):
        symbol = str(raw_mass_args[idx])
        try:
            value = float(raw_mass_args[idx + 1])
        except ValueError as exc:
            raise ValueError(f"Error: invalid mass value for {symbol}: {raw_mass_args[idx + 1]}") from exc
        mass_map[symbol] = value
    return mass_map


def config_from_args(args) -> PIMDRunConfig:
    temp_arg = getattr(args, "temp", None)
    if temp_arg is None:
        temp_arg = getattr(args, "temperature", None)
    if temp_arg is None:
        raise ValueError("Error: --temp/--temperature is required.")
    ensemble_raw = str(getattr(args, "ensemble", "nvt")).lower()
    ensemble_norm = "nvt" if ensemble_raw == "nte" else ensemble_raw

    tstep = float(getattr(args, "tstep"))
    ttau_raw = float(getattr(args, "ttau", 0.0) or 0.0)
    ttau_effective = ttau_raw if ttau_raw > 0.0 else 40.0 * tstep
    nbead_arg = getattr(args, "nbead", None)
    nbead = int(nbead_arg) if nbead_arg is not None else auto_nbead_from_temperature(float(temp_arg))

    return PIMDRunConfig(
        ff=str(getattr(args, "ff")),
        model=getattr(args, "model", None),
        device=getattr(args, "device", None),
        modal=getattr(args, "modal", None),
        nbead=nbead,
        nsteps=int(getattr(args, "nsteps")),
        tstep=tstep,
        ensemble=ensemble_norm,
        temperature=float(temp_arg),
        nref=int(getattr(args, "nref", 5)),
        nys=int(getattr(args, "nys", 5)),
        nnhc=int(getattr(args, "nnhc", 4)),
        igamma=int(getattr(args, "igamma", 1)),
        ttau_effective=float(ttau_effective),
        bath_type=str(getattr(args, "bath_type", "none")),
        seed=getattr(args, "seed", None),
        poscar=getattr(args, "poscar", None),
        cif=getattr(args, "cif", None),
        formula=getattr(args, "formula", None),
        mpid=getattr(args, "mpid", None),
        dim=getattr(args, "dim", None),
        output_dir=getattr(args, "output_dir", None),
        batch_size=getattr(args, "batch_size", None),
        sequential=bool(getattr(args, "sequential", False)),
        restart=getattr(args, "restart", None),
        restart_npz=getattr(args, "restart_npz", None),
        mass_map=_parse_mass_map(getattr(args, "mass", None)),
        print_every=int(getattr(args, "print_every", 1)),
        external_out_every=int(getattr(args, "external_out_every", 100)),
        save_restart_every=int(getattr(args, "save_restart_every", 100)),
        checkpoint_keep=int(getattr(args, "checkpoint_keep", 2)),
        save_xdatcar_every=int(getattr(args, "save_xdatcar_every", 10)),
        save_poscar_every=int(getattr(args, "save_poscar_every", 100)),
        save_distribution_every=int(getattr(args, "save_distribution_every", 1000)),
        postprocess_later=bool(
            getattr(
                args,
                "postprocess_later",
                getattr(args, "defer_postprocess", False),
            )
        ),
        distribution_pdf=bool(True if getattr(args, "distribution_pdf", None) is None else getattr(args, "distribution_pdf")),
        distribution_point_alpha=float(getattr(args, "distribution_point_alpha", 0.45)),
        distribution_point_size=float(getattr(args, "distribution_point_size", 4.0)),
    )
