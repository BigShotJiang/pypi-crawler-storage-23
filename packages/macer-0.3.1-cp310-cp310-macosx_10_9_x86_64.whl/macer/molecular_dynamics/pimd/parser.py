from __future__ import annotations

from macer.molecular_dynamics.pimd.params import PIMDRunConfig, config_from_args


def parse_cli_args(args) -> PIMDRunConfig:
    return config_from_args(args)
