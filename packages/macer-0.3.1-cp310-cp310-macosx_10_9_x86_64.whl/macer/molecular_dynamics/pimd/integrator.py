from __future__ import annotations

from macer.molecular_dynamics.pimd.params import PIMDRunConfig


def validate_integrator_inputs(config: PIMDRunConfig) -> None:
    if config.nbead < 1:
        raise ValueError("nbead must be >= 1")
    if config.nsteps < 1:
        raise ValueError("nsteps must be >= 1")
    if config.nref < 1:
        raise ValueError("nref must be >= 1")
    if config.nys < 1:
        raise ValueError("nys must be >= 1")
    if config.nnhc < 1:
        raise ValueError("nnhc must be >= 1")
    if config.tstep <= 0:
        raise ValueError("tstep must be > 0")
    if config.print_every < 1:
        raise ValueError("print-every must be >= 1")
    if config.external_out_every < 1:
        raise ValueError("external-out-every must be >= 1")
    if config.save_restart_every < 1:
        raise ValueError("save-restart-every must be >= 1")
    if config.checkpoint_keep < 0:
        raise ValueError("checkpoint-keep must be >= 0")
    if config.save_xdatcar_every < 1:
        raise ValueError("save-xdatcar-every must be >= 1")
    if config.save_poscar_every < 1:
        raise ValueError("save-poscar-every must be >= 1")
    if config.save_distribution_every < 1:
        raise ValueError("save-distribution-every must be >= 1")
    if config.distribution_point_alpha < 0.0 or config.distribution_point_alpha > 1.0:
        raise ValueError("distribution-point-alpha must be in [0, 1]")
    if config.distribution_point_size <= 0.0:
        raise ValueError("distribution-point-size must be > 0")
    if config.ensemble not in {"nve", "nvt"}:
        raise ValueError(f"unsupported ensemble: {config.ensemble}")
    if config.mass_map:
        for symbol, mass in config.mass_map.items():
            if mass <= 0:
                raise ValueError(f"mass for {symbol} must be > 0")
