from __future__ import annotations

from dataclasses import replace

from macer.molecular_dynamics.pimd.integrator import validate_integrator_inputs
from macer.molecular_dynamics.pimd.external_linker import run_external_simulation
from macer.molecular_dynamics.pimd.io import resolve_pimd_output_dir
from macer.molecular_dynamics.pimd.parser import parse_cli_args

def run_pimd_from_args(args) -> None:
    config = parse_cli_args(args)
    validate_integrator_inputs(config)
    final_output_dir = resolve_pimd_output_dir(config)
    config = replace(config, output_dir=str(final_output_dir))
    setattr(args, "output_dir", str(final_output_dir))
    # Legacy API name kept for compatibility; runtime now uses external wrapper path.
    run_external_simulation(config)


def run_pimd_legacy_from_args(args) -> None:
    config = parse_cli_args(args)
    validate_integrator_inputs(config)
    final_output_dir = resolve_pimd_output_dir(config)
    config = replace(config, output_dir=str(final_output_dir))
    setattr(args, "output_dir", str(final_output_dir))
    run_external_simulation(config)
