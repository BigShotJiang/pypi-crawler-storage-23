from __future__ import annotations

from pathlib import Path

import numpy as np
from ase import Atoms
from ase.build import make_supercell
from ase.io import read

from macer.molecular_dynamics.pimd.params import PIMDRunConfig


def normalize_output_dir(path_like: str | None) -> Path | None:
    if path_like is None:
        return None
    return Path(path_like).expanduser().resolve()


def resolve_structure_inputs_for_pimd(config: PIMDRunConfig) -> list[str]:
    from macer.utils.struct_tools import resolve_structure_inputs

    return resolve_structure_inputs(
        poscar_paths=[config.poscar] if config.poscar else None,
        cif_paths=[config.cif] if config.cif else None,
        formula=config.formula,
        mpid=config.mpid,
    )


def dedupe_output_dir(base_dir: Path) -> Path:
    if not base_dir.exists():
        return base_dir
    index = 1
    while True:
        candidate = base_dir.parent / f"{base_dir.name}-NEW{index:02d}"
        if not candidate.exists():
            return candidate
        index += 1


def resolve_pimd_output_dir(config: PIMDRunConfig) -> Path:
    user_output = str(config.output_dir or ".")
    has_restart = bool(config.restart) or bool(getattr(config, "restart_npz", None))
    if has_restart:
        if user_output == ".":
            restart_path = str(config.restart or getattr(config, "restart_npz", ""))
            return Path(restart_path).expanduser().resolve().parent
        out = Path(user_output).expanduser().resolve()
        out.mkdir(parents=True, exist_ok=True)
        return out

    input_list = resolve_structure_inputs_for_pimd(config)
    if not input_list:
        raise ValueError("Missing structure input for output-dir resolution.")
    input_path = Path(input_list[0]).expanduser().resolve()

    if user_output == ".":
        base_output_dir = input_path.parent / f"pimd-{input_path.stem}-mlff={config.ff}"
        return dedupe_output_dir(base_output_dir)

    out = Path(user_output).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    return out


def load_initial_atoms(config: PIMDRunConfig) -> Atoms:
    input_list = resolve_structure_inputs_for_pimd(config)
    if not input_list:
        raise ValueError(
            "Please provide structure input via -p/--poscar, -c/--cif, -f/--formula, or -m/--mpid."
        )
    atoms = read(str(input_list[0]))
    if config.dim:
        dim = list(config.dim)
        if len(dim) == 3:
            sc_matrix = np.diag(dim)
        elif len(dim) == 9:
            sc_matrix = np.array(dim, dtype=int).reshape(3, 3)
        else:
            raise ValueError("--dim must contain 3 or 9 integers.")
        atoms = make_supercell(atoms, sc_matrix)
        print(f"[pimd] Applied supercell --dim: {dim} (natom={len(atoms)})")
    return atoms
