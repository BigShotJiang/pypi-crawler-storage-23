from __future__ import annotations

import argparse

from macer.calculator.factory import ALL_SUPPORTED_FFS, get_available_ffs
from macer.cli.argparse_common import enable_helpful_argparse_errors
from macer.defaults import DEFAULT_DEVICE
from macer.molecular_dynamics.pimd.params import auto_nbead_from_temperature
from macer.molecular_dynamics.pimd.runner import run_pimd_legacy_from_args

enable_helpful_argparse_errors()


class _PIMDHelpFormatter(argparse.ArgumentDefaultsHelpFormatter, argparse.RawDescriptionHelpFormatter):
    pass


_FAST_EXTERNAL_OUT_EVERY = 20
_FAST_SAVE_RESTART_EVERY = 2000
_FAST_SAVE_XDATCAR_EVERY = 50
_FAST_SAVE_DISTRIBUTION_EVERY = 5000
_FAST_CHECKPOINT_KEEP = 1


def get_pimd_parser(mode: str = "native"):
    """
    Build `macer pimd` parser in style consistent with `macer md`.
    """
    available_ffs = get_available_ffs()
    dynamic_default_ff = available_ffs[0] if available_ffs else None

    is_legacy = str(mode).lower() == "legacy"
    cmd_name = "macer pimd-legacy" if is_legacy else "macer pimd"
    core_desc = (
        "Path Integral Molecular Dynamics with macer (legacy compatibility backend wrapping external PIMD_python core)."
        if is_legacy
        else "Path Integral Molecular Dynamics with macer (wrapper around external PIMD_python core)."
    )
    parser = argparse.ArgumentParser(
        description=core_desc,
        epilog="""
Examples:
  # 1) Most basic run (NVT is default; `--nbead` omitted -> auto from temperature)
  {cmd} -p POSCAR --ff mattersim --temp 300 --tstep 0.25 --nsteps 2000

  # 2) NVE with explicit beads/steps
  #    Note: `--temp` is still required for initialization and NVE warning will be printed.
  {cmd} -p POSCAR --ensemble nve --temp 300 --nbead 16 --tstep 0.25 --nsteps 2000 --ff mattersim

  # 3) NVT/NTE with thermostat controls
  {cmd} -p POSCAR --ensemble nte --bath-type mnhc --ttau 10.0 --temp 300 --ff mattersim

  # 4) Mass override and explicit output directory
  {cmd} -p POSCAR --mass H 2.014 O 15.999 --output-dir ./pimd-run --ff emt

  # 5) Distribution/structure save cadence and PDF style controls
  {cmd} -p POSCAR --ff mattersim --temp 300 --save-xdatcar-every 10 --save-poscar-every 100 --save-distribution-every 1000 --distribution-point-alpha 0.30 --distribution-point-size 2.0

  # 6) Detailed/frequent output mode (overrides default fast behavior)
  {cmd} -p POSCAR --ff mattersim --temp 300 --nsteps 2000 --detailed-output

  # 6-b) Native batching vs sequential mode
  # Default is batch-first with automatic sequential fallback on failure.
  # You can force sequential mode:
  {cmd} -p POSCAR --ff mattersim --temp 300 --nsteps 2000 --sequential
  {cmd} -p POSCAR --ff mattersim --temp 300 --nsteps 2000 --seq

  # 7) Restart from external core restart file
  {cmd} --ff mattersim --nsteps 200 --restart ./pimd-run/restart.dat

  # 8) Restart from NPZ snapshot (only NPZ that contains embedded external restart data)
  {cmd} --ff mattersim --nsteps 200 --restart-npz ./pimd-run/pimd_state_step002000.npz

Notes:
  - upstream project: https://github.com/kuwahatakazuaki/PIMD_python
  - current mode: {mode_note}
  - `--nbead` is optional. If omitted, auto rule is used:
      T<=75K -> 64, <=150K -> 32, <=300K -> 16, <=600K -> 8, >600K -> 4
  - default run mode is already fast; use `--detailed-output` for dense diagnostics.

""".format(
            cmd=cmd_name,
            mode_note=(
                "legacy compatibility backend (same CLI arguments as native `macer pimd`)"
                if is_legacy
                else "external PIMD_python wrapper (default `macer pimd` path)"
            ),
        ),
        formatter_class=_PIMDHelpFormatter,
        add_help=False,
    )

    structure_group = parser.add_argument_group("Structure Input")
    structure_input = structure_group.add_mutually_exclusive_group(required=False)
    structure_input.add_argument("--poscar", "-p", type=str, default=None, help="Input POSCAR path.")
    structure_input.add_argument("--cif", "-c", type=str, default=None, help="Input CIF path.")
    structure_input.add_argument("-f", "--formula", type=str, help="Materials Project formula input.")
    structure_input.add_argument("-m", "--mpid", type=str, help="Materials Project ID input.")
    parser.add_argument(
        "--dim",
        type=int,
        nargs="+",
        help="Supercell dimension as 3 or 9 integers (e.g. '2 2 2' or '2 0 0 0 2 0 0 0 2').",
    )

    mlff_group = parser.add_argument_group("MLFF Model Settings")
    mlff_group.add_argument("--model", default=None, help="Path to MLFF model file.")
    mlff_group.add_argument(
        "--ff",
        type=str,
        default=dynamic_default_ff,
        choices=ALL_SUPPORTED_FFS,
        help="Force field to use.",
    )
    mlff_group.add_argument("--modal", type=str, default=None, help="Modal for supported force fields.")
    mlff_group.add_argument(
        "--device",
        choices=["cpu", "mps", "cuda"],
        default=DEFAULT_DEVICE,
        help="Compute device.",
    )
    mlff_group.add_argument(
        "--batch-size",
        type=int,
        default=None,
        help="Optional mini-batch size for native batch evaluation. Default: auto (backend-managed). Must be >= 1.",
    )
    mlff_group.add_argument(
        "--sequential", "--seq",
        dest="sequential",
        action="store_true",
        default=False,
        help="Force per-structure sequential evaluation (disable native batch evaluation).",
    )

    pimd_group = parser.add_argument_group("PIMD Parameters")
    pimd_group.add_argument(
        "--ensemble",
        choices=["nve", "nvt", "nte"],
        default="nvt",
        help="PIMD ensemble (`nte` is an alias of `nvt`).",
    )
    pimd_group.add_argument(
        "-T",
        "--temp",
        "--temperature",
        type=float,
        help="Target temperature [K].",
    )
    pimd_group.add_argument(
        "--nbead",
        type=int,
        default=None,
        help="Number of beads. If omitted, auto-selected from temperature (T<=75:64, <=150:32, <=300:16, <=600:8, >600:4).",
    )
    pimd_group.add_argument("--tstep", type=float, default=0.1, help="Time step [fs].")
    pimd_group.add_argument("--nsteps", type=int, default=10, help="Number of integration steps.")
    pimd_group.add_argument("--nref", type=int, default=5, help="Inner reference substeps.")
    pimd_group.add_argument(
        "--bath-type",
        choices=["none", "nhc", "nhcs", "mnhc"],
        default="nhc",
        help="Thermostat mode. Current external mapping: `none -> Ncent=0`, `nhc/nhcs/mnhc -> Ncent=3`.",
    )
    pimd_group.add_argument(
        "--ttau",
        type=float,
        default=0.0,
        help="Thermostat policy [fs]; 0 means auto `40 * --tstep` (macer md style). (External core has no dedicated ttau input key.)",
    )
    pimd_group.add_argument("--igamma", type=int, default=1, help="Adiabaticity parameter.")
    pimd_group.add_argument("--nys", type=int, default=5, help="Suzuki-Yoshida thermostat substeps.")
    pimd_group.add_argument("--nnhc", type=int, default=4, help="Thermostat chain length.")
    pimd_group.add_argument("--seed", type=int, default=None, help="Random seed.")
    pimd_group.add_argument(
        "--mass",
        nargs="+",
        help="Atomic mass override pairs: Symbol Mass Symbol Mass ...",
    )

    out_group = parser.add_argument_group("Output Settings")
    out_group.add_argument("--output-dir", type=str, default=".", help="Output directory.")
    out_group.add_argument("--print-every", type=int, default=1, help="Stdout print interval.")
    mode_group = out_group.add_mutually_exclusive_group(required=False)
    mode_group.add_argument(
        "--fast",
        action="store_true",
        help=(
            "Apply production-fast preset "
            f"(external-out-every={_FAST_EXTERNAL_OUT_EVERY}, "
            f"save-restart-every={_FAST_SAVE_RESTART_EVERY}, "
            f"checkpoint-keep={_FAST_CHECKPOINT_KEEP}, "
            f"save-xdatcar-every={_FAST_SAVE_XDATCAR_EVERY}, "
            f"save-distribution-every={_FAST_SAVE_DISTRIBUTION_EVERY}, "
            "deferred postprocess, distribution PDF off by default). "
            "This is already the default mode."
        ),
    )
    mode_group.add_argument(
        "--detailed-output",
        action="store_true",
        help="Use detailed/frequent output cadence (disables default production-fast mode).",
    )
    out_group.add_argument(
        "--external-out-every",
        type=int,
        default=1,
        help="External-core output cadence (`out_step`) for `ham.dat`/`std.out`/`restart.dat`.",
    )
    out_group.add_argument(
        "--save-restart-every",
        type=int,
        default=100,
        help="Wrapper snapshot cadence for `pimd_state_step*.npz`.",
    )
    out_group.add_argument(
        "--checkpoint-keep",
        type=int,
        default=2,
        help="Number of recent checkpoint NPZ files to keep (0 means keep all).",
    )
    out_group.add_argument(
        "--save-every",
        dest="external_out_every",
        type=int,
        help=argparse.SUPPRESS,
    )
    out_group.add_argument(
        "--save-xdatcar-every",
        type=int,
        default=10,
        help="Postprocess save interval for `pimd.traj`, `XDATCAR-PIMD`, and `XDATCAR-PIMD-BEADS`.",
    )
    out_group.add_argument(
        "--save-poscar-every",
        type=int,
        default=100,
        help="Postprocess save interval for `POSCAR_pimd_mean_step*`, `POSCAR_pimd_beads_step*`, and `adp_step*.dat`.",
    )
    out_group.add_argument(
        "--save-distribution-every",
        type=int,
        default=1000,
        help="Postprocess save interval for distribution outputs (`distribution_step_*`, `distribution2d_step_*`).",
    )
    out_group.add_argument(
        "--postprocess-later",
        action="store_true",
        default=False,
        dest="postprocess_later",
        help="Run heavy postprocess outputs (POSCAR/distribution PDFs) at end-of-run for speed.",
    )
    out_group.add_argument(
        "--defer-postprocess",
        action="store_true",
        dest="postprocess_later",
        help=argparse.SUPPRESS,
    )
    out_group.add_argument(
        "--distribution-pdf",
        dest="distribution_pdf",
        action="store_true",
        default=None,
        help="Enable distribution PDF generation (1D/2D).",
    )
    out_group.add_argument(
        "--no-distribution-pdf",
        dest="distribution_pdf",
        action="store_false",
        default=None,
        help="Disable distribution PDF generation (keep DAT outputs).",
    )
    out_group.add_argument(
        "--distribution-point-alpha",
        type=float,
        default=0.45,
        help="Point transparency [0,1] for distribution PDF scatter.",
    )
    out_group.add_argument(
        "--distribution-point-size",
        type=float,
        default=4.0,
        help="Point size for distribution PDF scatter.",
    )
    out_group.add_argument(
        "--restart",
        default=None,
        help="External-core restart file path (typically `restart.dat`).",
    )
    out_group.add_argument(
        "--restart-npz",
        default=None,
        help="NPZ snapshot path containing embedded external restart payload.",
    )

    return parser


def has_structure_or_restart(args) -> bool:
    has_structure = bool(
        getattr(args, "poscar", None)
        or getattr(args, "cif", None)
        or getattr(args, "formula", None)
        or getattr(args, "mpid", None)
    )
    return has_structure or bool(getattr(args, "restart", None)) or bool(getattr(args, "restart_npz", None))


def get_missing_required_args(args) -> list[str]:
    missing: list[str] = []
    if not has_structure_or_restart(args):
        missing.append("one of --poscar/--cif/--formula/--mpid (or --restart/--restart-npz)")
    if getattr(args, "temp", None) is None and getattr(args, "temperature", None) is None:
        missing.append("-T/--temp/--temperature")
    return missing


def run_pimd_simulation(args) -> None:
    """
    Run PIMD while preserving original kernel behavior.
    Parser/output style is exposed through the new `macer pimd` command.
    """
    print("[pimd] Core: macer/externals/PIMD_python-main")
    print("[pimd] Upstream project: https://github.com/kuwahatakazuaki/PIMD_python")
    batch_size = getattr(args, "batch_size", None)
    if batch_size is not None and int(batch_size) < 1:
        raise ValueError("--batch-size must be >= 1 when provided.")
    if bool(getattr(args, "sequential", False)):
        print("[pimd] Force evaluation mode: sequential (forced by --sequential/--seq).")
    else:
        if batch_size is None:
            print("[pimd] Force evaluation mode: batch-first (backend auto batching).")
        else:
            print(f"[pimd] Force evaluation mode: batch-first (batch_size={int(batch_size)}).")
    use_detailed = bool(getattr(args, "detailed_output", False))
    use_fast_default = not use_detailed
    use_fast = bool(getattr(args, "fast", False)) or use_fast_default

    if use_fast:
        if int(getattr(args, "external_out_every", 1)) == 1:
            setattr(args, "external_out_every", _FAST_EXTERNAL_OUT_EVERY)
        if int(getattr(args, "save_restart_every", 100)) == 100:
            setattr(args, "save_restart_every", _FAST_SAVE_RESTART_EVERY)
        if int(getattr(args, "checkpoint_keep", 2)) == 2:
            setattr(args, "checkpoint_keep", _FAST_CHECKPOINT_KEEP)
        if int(getattr(args, "save_xdatcar_every", 10)) == 10:
            setattr(args, "save_xdatcar_every", _FAST_SAVE_XDATCAR_EVERY)
        if int(getattr(args, "save_distribution_every", 1000)) == 1000:
            setattr(args, "save_distribution_every", _FAST_SAVE_DISTRIBUTION_EVERY)
        if not bool(getattr(args, "postprocess_later", False)):
            setattr(args, "postprocess_later", True)
        if getattr(args, "distribution_pdf", None) is None:
            setattr(args, "distribution_pdf", False)
        preset_label = "--fast preset applied" if bool(getattr(args, "fast", False)) else "default fast preset applied"
        print(
            f"[pimd] Info: {preset_label} "
            f"(external_out_every={int(getattr(args, 'external_out_every'))}, "
            f"save_restart_every={int(getattr(args, 'save_restart_every'))}, "
            f"checkpoint_keep={int(getattr(args, 'checkpoint_keep', 2))}, "
            f"save_xdatcar_every={int(getattr(args, 'save_xdatcar_every'))}, "
            f"save_distribution_every={int(getattr(args, 'save_distribution_every'))}, "
            f"postprocess_later={bool(getattr(args, 'postprocess_later', False))}, "
            f"distribution_pdf={bool(True if getattr(args, 'distribution_pdf', None) is None else getattr(args, 'distribution_pdf'))})."
        )
    else:
        print("[pimd] Info: detailed output mode selected (`--detailed-output`); fast preset is disabled.")
    print(
        "[pimd] Effective(post-preset): "
        f"external_out_every={int(getattr(args, 'external_out_every', 1))}, "
        f"save_restart_every={int(getattr(args, 'save_restart_every', 100))}, "
        f"checkpoint_keep={int(getattr(args, 'checkpoint_keep', 2))}, "
        f"save_xdatcar_every={int(getattr(args, 'save_xdatcar_every', 10))}, "
        f"save_poscar_every={int(getattr(args, 'save_poscar_every', 100))}, "
        f"save_distribution_every={int(getattr(args, 'save_distribution_every', 1000))}, "
        f"postprocess_later={bool(getattr(args, 'postprocess_later', False))}, "
        f"distribution_pdf={bool(True if getattr(args, 'distribution_pdf', None) is None else getattr(args, 'distribution_pdf'))}"
    )
    ensemble = str(getattr(args, "ensemble", "nvt")).lower()
    if ensemble == "nte":
        print("[pimd] Info: `--ensemble nte` is treated as `nvt`.")
    if ensemble == "nve":
        print("[pimd] Warning: `--ensemble nve` selected. Running NVE (no thermostat control).")
    if ensemble in {"nvt", "nte"}:
        ttau = float(getattr(args, "ttau", 0.0) or 0.0)
        if ttau <= 0.0:
            auto_ttau = 40.0 * float(getattr(args, "tstep", 0.25))
            print(f"[pimd] Info: auto thermostat time constant enabled (`ttau = 40 * dt = {auto_ttau:.3f} fs`).")
    ttau_raw = float(getattr(args, "ttau", 0.0) or 0.0)
    ttau_effective = ttau_raw if ttau_raw > 0.0 else 40.0 * float(getattr(args, "tstep", 0.25))
    if ensemble in {"nvt", "nte"}:
        print(f"[pimd] Using ttau_effective={ttau_effective:.3f} fs.")
    else:
        print(f"[pimd] Using ttau_effective={ttau_effective:.3f} fs (computed; thermostat inactive in NVE).")
    if getattr(args, "nbead", None) is None:
        temp_arg = getattr(args, "temp", None)
        if temp_arg is None:
            temp_arg = getattr(args, "temperature", None)
        if temp_arg is not None:
            auto_nbead = auto_nbead_from_temperature(float(temp_arg))
            setattr(args, "nbead", int(auto_nbead))
            print(f"[pimd] Info: auto nbead selected from temperature ({float(temp_arg):.1f} K) -> nbead={int(auto_nbead)}.")
    print(f"[pimd] Using nbead={int(getattr(args, 'nbead'))}.")
    print(f"[pimd] Postprocess mode={'deferred' if bool(getattr(args, 'postprocess_later', False)) else 'online'}.")
    nsteps = int(getattr(args, "nsteps", 0))
    ext_out = int(getattr(args, "external_out_every", 1))
    xdat = int(getattr(args, "save_xdatcar_every", 10))
    rst = int(getattr(args, "save_restart_every", 100))
    dist = int(getattr(args, "save_distribution_every", 1000))
    if nsteps >= 1000 and (ext_out <= 2 or xdat <= 10 or rst <= 100 or dist <= 1000):
        print(
            "[pimd] Hint: heavy save cadence detected for long run. "
            "Consider `--fast` or larger *-every intervals to reduce I/O overhead."
        )
    bath = str(getattr(args, "bath_type", "none")).lower()
    if bath in {"nhc", "nhcs", "mnhc"}:
        print("[pimd] Info: current core maps nhc/nhcs/mnhc equivalently (Ncent=3).")
    run_pimd_legacy_from_args(args)


def run_pimd_legacy_simulation(args) -> None:
    print("[pimd-legacy] Core: macer/externals/PIMD_python-main")
    print("[pimd-legacy] Upstream project: https://github.com/kuwahatakazuaki/PIMD_python")
    run_pimd_simulation(args)
