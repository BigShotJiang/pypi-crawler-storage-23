from __future__ import annotations

from pathlib import Path

import numpy as np
from ase import Atoms

from macer.calculator.factory import get_calculator, evaluate_batch, evaluate_sequential
from macer.defaults import DEFAULT_DEVICE, DEFAULT_MODELS, resolve_model_path
from macer.molecular_dynamics.pimd.params import PIMDRunConfig


def _resolve_model_path(ff: str, model_path: str | None) -> str | None:
    if model_path:
        return resolve_model_path(str(model_path))
    default_model = DEFAULT_MODELS.get(ff)
    if not default_model:
        return None
    return resolve_model_path(default_model)


def build_calculator_from_config(config: PIMDRunConfig):
    calc_kwargs = {"device": config.device or DEFAULT_DEVICE, "modal": config.modal}
    model_path = _resolve_model_path(config.ff, config.model)
    if model_path:
        if config.ff == "mace":
            calc_kwargs["model_paths"] = [model_path]
        else:
            calc_kwargs["model_path"] = model_path
    return get_calculator(ff_name=config.ff, **calc_kwargs)


def build_external_run_cal(modules: dict, config: PIMDRunConfig):
    """
    Build a runtime-patched `run_cal` for external PIMD core.
    This avoids tight coupling to external `run_matlantis.py` internals and keeps
    force-evaluation policy controlled from macer wrapper side.
    """
    parameters = modules["parameters"]
    calculator = build_calculator_from_config(config)

    atoms_cache_key = None
    atoms_cache_list = None
    cell_cache = None

    def _load_periodic_cell_from_lattice() -> np.ndarray:
        lattice_path = Path("LATTICE")
        lines = [line.strip() for line in lattice_path.read_text().splitlines() if line.strip()]
        if len(lines) < 5:
            raise ValueError('Invalid "LATTICE": expected at least 5 non-empty lines.')
        scale = float(lines[1].split()[0])
        vec1 = [float(x) for x in lines[2].split()[:3]]
        vec2 = [float(x) for x in lines[3].split()[:3]]
        vec3 = [float(x) for x in lines[4].split()[:3]]
        return scale * np.array([vec1, vec2, vec3], dtype=float)

    def _get_atoms_list():
        nonlocal atoms_cache_key, atoms_cache_list, cell_cache

        labels = tuple(str(x) for x in parameters.alabel)
        if bool(parameters.Lperiodic):
            if cell_cache is None:
                cell_cache = _load_periodic_cell_from_lattice()
            cell_key = tuple(float(x) for x in np.array(cell_cache, dtype=float).ravel())
        else:
            cell_key = ()
        key = (int(parameters.Nbead), int(parameters.Natom), bool(parameters.Lperiodic), labels, cell_key)
        if atoms_cache_list is not None and atoms_cache_key == key:
            return atoms_cache_list

        atoms_list = []
        label_list = list(labels)
        if bool(parameters.Lperiodic):
            cell = np.array(cell_cache, dtype=float)
            for ib in range(int(parameters.Nbead)):
                pos = (parameters.r[:, :, ib] * parameters.AUtoAng).T
                atoms_list.append(Atoms(symbols=label_list, positions=pos, cell=cell, pbc=(True, True, True)))
        else:
            for ib in range(int(parameters.Nbead)):
                pos = (parameters.r[:, :, ib] * parameters.AUtoAng).T
                atoms_list.append(Atoms(symbols=label_list, positions=pos, pbc=(False, False, False)))

        atoms_cache_key = key
        atoms_cache_list = atoms_list
        return atoms_cache_list

    def _run_cal():
        atoms_list = _get_atoms_list()
        nbead = int(parameters.Nbead)
        batch_size = getattr(config, "batch_size", None)
        use_sequential = bool(getattr(config, "sequential", False))

        for ib, atoms in enumerate(atoms_list):
            atoms.set_positions((parameters.r[:, :, ib] * parameters.AUtoAng).T)

        results = None
        if not use_sequential:
            try:
                results = evaluate_batch(
                    calculator,
                    atoms_list,
                    batch_size=batch_size,
                    properties=["energy", "forces"],
                    verbose=True,
                )
            except Exception as e:
                print(
                    "[pimd] Warning: native batch evaluation failed in external core bridge:\n"
                    f"  {e}\n"
                    "[pimd]          Falling back to sequential evaluation."
                )
                use_sequential = True

        if use_sequential:
            if bool(getattr(config, "sequential", False)):
                print("[pimd] Info: external core bridge running in forced sequential mode (--sequential).")
            results = evaluate_sequential(
                calculator,
                atoms_list,
                properties=["energy", "forces"],
                verbose=True,
            )

        energies = np.array(results["energy"], dtype=float)
        forces = results["forces"]
        if energies.shape[0] != nbead:
            raise RuntimeError(f"Energy result size mismatch: expected {nbead}, got {energies.shape[0]}")
        if len(forces) != nbead:
            raise RuntimeError(f"Forces result size mismatch: expected {nbead}, got {len(forces)}")
        for ib in range(nbead):
            parameters.Eenergy[ib] = float(energies[ib])
            parameters.fr[:, :, ib] = np.array(forces[ib], dtype=float).T

        parameters.fr *= parameters.eVAng2AU * parameters.dp_inv
        parameters.Eenergy *= parameters.eVtoAU
        parameters.potential = float(np.sum(parameters.Eenergy) * parameters.dp_inv)

    return _run_cal
