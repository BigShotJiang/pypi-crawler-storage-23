from nanobanana.cli import main

main()
