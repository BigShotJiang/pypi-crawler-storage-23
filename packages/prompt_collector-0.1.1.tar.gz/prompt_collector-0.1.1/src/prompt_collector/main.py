"""Main entry point for the prompt collector.

This module coordinates all other modules and implements the CLI argument parsing.
The tool supports --type argument to specify whether sending prompt or result.
"""

import argparse
import sys
from typing import Optional

from prompt_collector.config import (
    get_api_base_url,
    get_api_key,
    get_timeout,
    get_username,
)
from prompt_collector.formatter import (
    EventType,
    format_payload,
    get_api_endpoint,
    truncate_content,
)
from prompt_collector.parser import parse_event, read_stdin
from prompt_collector.sender import _log_error, send_event


def parse_args(args: Optional[list] = None) -> argparse.Namespace:
    """Parse command line arguments.

    Args:
        args: Command line arguments list, defaults to sys.argv[1:].

    Returns:
        Parsed arguments namespace.
    """
    parser = argparse.ArgumentParser(
        prog="prompt-collector",
        description="Collect and send prompt/result events to API.",
    )
    parser.add_argument(
        "--type",
        dest="event_type",
        choices=["prompt", "result"],
        required=True,
        help="Type of event to send: 'prompt' for user input, 'result' for AI response",
    )
    parser.add_argument(
        "--session-id",
        dest="session_id",
        default="",
        help="Session identifier (can also be read from stdin JSON)",
    )
    parser.add_argument(
        "--content",
        dest="content",
        default="",
        help="Content to send (can also be read from stdin)",
    )
    return parser.parse_args(args)


def run(event_type: EventType, session_id: str = "", content: str = "") -> None:
    """Run the collector workflow.

    This function orchestrates the entire flow:
    1. Read configuration from environment variables
    2. Read and parse input from stdin
    3. Format the event for the target API
    4. Send the event

    Args:
        event_type: The type of event (prompt or result).
        session_id: Optional session_id from command line.
        content: Optional content from command line.
    """
    # Step 1: Get configuration
    api_base_url = get_api_base_url()
    if not api_base_url:
        return

    username = get_username()
    if not username:
        return

    api_key = get_api_key()
    timeout = get_timeout()

    # Step 2: Read and parse input from stdin
    input_data = read_stdin()

    # Use command line content if stdin is empty
    if not input_data and content:
        input_data = content

    if not input_data:
        return

    event = parse_event(input_data)
    if not event:
        return

    # Merge session_id: command line takes precedence over stdin
    final_session_id = session_id or event.session_id
    if not final_session_id:
        return

    # Use stdin content if no command line content provided
    final_content = content or event.content
    if not final_content:
        return

    # Step 3: Format and truncate content
    truncated_content = truncate_content(final_content, max_length=10000)

    payload = format_payload(
        username=username,
        session_id=final_session_id,
        event_type=event_type,
        content=truncated_content,
    )

    # Step 4: Send the event
    api_endpoint = get_api_endpoint(api_base_url)
    send_event(
        api_endpoint=api_endpoint,
        payload=payload,
        api_key=api_key,
        timeout=timeout,
    )


def main() -> int:
    """Main entry point.

    This function provides the top-level error handling that catches
    any unhandled exceptions to ensure the parent process is never affected.

    Returns:
        Always returns 0 to indicate success to the calling process.
    """
    try:
        args = parse_args()
        event_type = EventType(args.event_type)
        run(
            event_type=event_type,
            session_id=args.session_id,
            content=args.content,
        )
    except SystemExit:
        # Allow argparse to exit on --help or invalid arguments
        raise
    except Exception as e:
        # Top-level catch-all: log error but don't interrupt parent
        _log_error("Top-level exception in main", e)
    return 0


if __name__ == "__main__":
    sys.exit(main())
