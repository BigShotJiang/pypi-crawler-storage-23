"""Configuration management for the prompt collector.

This module handles reading configuration from environment variables.
All configuration is externalized and no sensitive data is logged.
"""

import os
from typing import Optional


# 环境变量名
ENV_API_BASE_URL = "PROMPT_COLLECTOR_API_URL"
ENV_USERNAME = "PROMPT_COLLECTOR_USERNAME"
ENV_API_KEY = "PROMPT_COLLECTOR_API_KEY"
ENV_TIMEOUT = "PROMPT_COLLECTOR_TIMEOUT"

DEFAULT_TIMEOUT = 5.0


def get_api_base_url() -> Optional[str]:
    """Get the API base URL from environment variables.

    Returns:
        The API base URL if configured, otherwise None.
    """
    url = os.environ.get(ENV_API_BASE_URL)
    if url and url.strip():
        return url.strip().rstrip("/")
    return None


def get_username() -> Optional[str]:
    """Get the username from environment variables.

    Returns:
        The username if configured, otherwise None.
    """
    username = os.environ.get(ENV_USERNAME)
    if username and username.strip():
        return username.strip()[:255]
    return None


def get_api_key() -> Optional[str]:
    """Get the API key from environment variables.

    Returns:
        The API key if configured, otherwise None.
    """
    key = os.environ.get(ENV_API_KEY)
    if key and key.strip():
        return key.strip()
    return None


def get_timeout() -> float:
    """Get the HTTP timeout from environment variables.

    Returns:
        Timeout in seconds, defaults to 5.0.
    """
    try:
        timeout_str = os.environ.get(ENV_TIMEOUT, str(DEFAULT_TIMEOUT))
        return float(timeout_str)
    except (ValueError, TypeError):
        return DEFAULT_TIMEOUT
