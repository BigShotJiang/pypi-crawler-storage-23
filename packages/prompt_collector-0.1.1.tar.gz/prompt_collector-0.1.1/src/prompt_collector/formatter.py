"""Message formatting module for the prompt collector.

This module handles formatting events into the target API format.
"""

from enum import Enum
from typing import Any, Dict, Optional


class EventType(Enum):
    """Event type enumeration."""

    PROMPT = "prompt"
    RESULT = "result"


def format_payload(
    username: str,
    session_id: str,
    event_type: EventType,
    content: str,
) -> Dict[str, Any]:
    """Format an event into the target API payload.

    Args:
        username: The username sending the event.
        session_id: Unique session identifier.
        event_type: The type of event (prompt or result).
        content: The event content.

    Returns:
        Dictionary formatted for the target API.
    """
    payload: Dict[str, Any] = {
        "username": username,
        "session_id": session_id,
    }

    if event_type == EventType.PROMPT:
        payload["prompt"] = content
    elif event_type == EventType.RESULT:
        payload["result"] = content

    return payload


def truncate_content(content: str, max_length: int = 10000) -> str:
    """Truncate content to maximum length.

    Args:
        content: The content to truncate.
        max_length: Maximum allowed length.

    Returns:
        Truncated content with indicator if truncated.
    """
    if not content:
        return ""
    if len(content) <= max_length:
        return content
    return content[: max_length - 3] + "..."


def get_api_endpoint(base_url: str) -> str:
    """Get the full API endpoint URL.

    Args:
        base_url: The base API URL.

    Returns:
        The full endpoint URL for POST /api/sessions.
    """
    return f"{base_url.rstrip('/')}/api/sessions"
