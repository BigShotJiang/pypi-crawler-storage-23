"""HTTP sending module for the prompt collector.

This module handles sending events to the target API.
All network errors are handled silently to ensure the main process
is never interrupted.
"""

import os
import tempfile
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

import httpx

# 使用跨平台的临时目录
ERROR_LOG = Path(tempfile.gettempdir()) / "prompt_collector_error.log"
DEFAULT_TIMEOUT = 5.0


def _log_error(context: str, exception: Exception) -> None:
    """Log error details to file for debugging."""
    try:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        with open(ERROR_LOG, "a", encoding="utf-8") as f:
            f.write(f"[{timestamp}] {context}\n")
            f.write(f"  Exception: {type(exception).__name__}: {exception}\n")
            f.write("  Traceback:\n")
            for line in traceback.format_exc().split("\n"):
                f.write(f"    {line}\n")
            f.write("\n")
    except Exception:
        pass


_PROXY_ENV_VARS = (
    "HTTP_PROXY", "http_proxy",
    "HTTPS_PROXY", "https_proxy",
    "ALL_PROXY", "all_proxy",
)


def _send_without_proxy(
    api_endpoint: str,
    payload: Dict[str, Any],
    headers: Dict[str, str],
    timeout: float,
) -> bool:
    """Fallback: send request bypassing system proxy settings.

    Temporarily clears proxy environment variables so httpx won't
    attempt to use the system proxy.
    """
    saved = {}
    try:
        for var in _PROXY_ENV_VARS:
            if var in os.environ:
                saved[var] = os.environ.pop(var)

        with httpx.Client(timeout=timeout, http2=False) as client:
            response = client.post(
                api_endpoint,
                json=payload,
                headers=headers,
            )
            response.raise_for_status()
            return True
    except Exception as e:
        _log_error("Send without proxy also failed", e)
        return False
    finally:
        os.environ.update(saved)


def send_event(
    api_endpoint: str,
    payload: Dict[str, Any],
    api_key: str = None,
    timeout: float = DEFAULT_TIMEOUT,
) -> bool:
    """Send an event to the target API.

    This function handles all errors silently. Any network error,
    timeout, or invalid response is ignored to ensure the main
    process is never interrupted.

    Args:
        api_endpoint: The target API endpoint URL.
        payload: The event payload dictionary.
        api_key: Optional API key for authentication.
        timeout: HTTP request timeout in seconds.

    Returns:
        True if the request succeeded, False otherwise.
    """
    headers = {
        "Content-Type": "application/json",
    }
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    try:
        with httpx.Client(timeout=timeout, http2=False) as client:
            response = client.post(
                api_endpoint,
                json=payload,
                headers=headers,
            )
            response.raise_for_status()
            return True

    except ImportError as e:
        _log_error("Proxy dependency missing, retrying without proxy", e)
        return _send_without_proxy(api_endpoint, payload, headers, timeout)
    except httpx.TimeoutException as e:
        _log_error("HTTP timeout", e)
    except httpx.RequestError as e:
        _log_error("HTTP request error", e)
    except httpx.HTTPStatusError as e:
        _log_error(f"HTTP error: {e.response.status_code}", e)
    except Exception as e:
        _log_error("Unexpected error in send_event", e)

    return False
