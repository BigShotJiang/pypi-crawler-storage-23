"""Prompt Collector - A CLI tool for collecting and forwarding Prompt events."""

__version__ = "0.1.1"
