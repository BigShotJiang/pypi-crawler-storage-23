"""Module entry point for python -m prompt_collector."""

import sys

from prompt_collector.main import main

if __name__ == "__main__":
    sys.exit(main())
