"""Input parsing module for the prompt collector.

This module handles reading from stdin and parsing JSON event data.
All parsing is defensive - any error returns None instead of raising exceptions.
"""

import json
import sys
from dataclasses import dataclass
from typing import Optional


@dataclass
class Event:
    """Represents a parsed event from stdin.

    Attributes:
        session_id: Unique session identifier.
        content: The event content (prompt or result).
    """

    session_id: str
    content: str


def read_stdin() -> Optional[str]:
    """Read input from stdin.

    Returns:
        The input string if available and non-empty, otherwise None.
    """
    try:
        # Windows 上需要强制使用 UTF-8 编码读取，避免 BOM 被错误解码
        if hasattr(sys.stdin, 'buffer'):
            # 从二进制流读取并手动解码，确保 UTF-8
            data = sys.stdin.buffer.read().decode('utf-8-sig')  # utf-8-sig 自动去除 BOM
        else:
            data = sys.stdin.read()
            # 如果已经是字符串，尝试去除 BOM（可能是 GBK 解码的乱码形式）
            if data.startswith('\ufeff'):
                data = data[1:]
            # 处理 GBK 解码 BOM 产生的乱码 "锘縶"
            elif data.startswith('锘縶'):
                data = data[2:]

        if data and data.strip():
            return data.strip()
        return None
    except Exception:
        return None


def _read_transcript_content(transcript_path: Optional[str]) -> str:
    """Read AI response content from transcript file.

    Cursor's stop event doesn't include the AI response directly.
    It provides a path to a JSONL transcript file that contains
    the full conversation history.

    Cursor transcript format:
    {"role":"assistant","message":{"content":[{"type":"text","text":"..."}]}}

    Args:
        transcript_path: Path to the transcript JSONL file.

    Returns:
        The last assistant message content, or empty string if not found.
    """
    if not transcript_path:
        return ""

    try:
        from pathlib import Path

        path = Path(transcript_path)
        if not path.exists():
            return ""

        # Read JSONL file and find the last assistant message
        last_assistant_content = ""
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                    # Look for assistant role messages
                    if entry.get("role") == "assistant":
                        # Cursor format: message.content[].text
                        message = entry.get("message", {})
                        content_list = message.get("content", [])

                        # Extract text from content array
                        texts = []
                        for item in content_list:
                            if isinstance(item, dict) and item.get("type") == "text":
                                text = item.get("text", "")
                                if text:
                                    texts.append(text)

                        if texts:
                            last_assistant_content = "\n".join(texts)

                        # Fallback: try direct content field if exists
                        if not last_assistant_content:
                            content = entry.get("content", "")
                            if content:
                                last_assistant_content = str(content)

                except (json.JSONDecodeError, TypeError):
                    continue

        return last_assistant_content
    except Exception:
        return ""


def parse_event(data: str) -> Optional[Event]:
    """Parse JSON event data into an Event object.

    Supports multiple formats:
    1. Standard format:
       {
           "session_id": "uuid-string",
           "content": "message text"
       }

    2. Claude Code hooks format:
       {
           "hook_event_name": "UserPromptSubmit",
           "last_assistant_message": "message text",
           "session_id": "uuid-string",
           "cwd": "/path/to/project"
       }

    3. Cursor hooks format (beforeSubmitPrompt):
       {
           "hook_event_name": "beforeSubmitPrompt",
           "conversation_id": "uuid-string",
           "prompt": "user message",
           "transcript_path": null
       }

    4. Cursor hooks format (stop):
       {
           "hook_event_name": "stop",
           "conversation_id": "uuid-string",
           "transcript_path": "path/to/transcript.jsonl"
       }

    Or simple string (will use as content with empty session_id):
    "raw message text"

    Args:
        data: The JSON string or raw text to parse.

    Returns:
        An Event object if parsing succeeds, otherwise None.
    """
    if not data or not data.strip():
        return None

    # 防御性处理：去除可能存在的 BOM 头
    # Windows 上 BOM 可能被解码为乱码 "锘縶"
    if data.startswith('\ufeff'):
        data = data[1:]
    elif data.startswith('锘縶'):
        data = data[2:]

    try:
        # Try to parse as JSON
        payload = json.loads(data)

        if isinstance(payload, dict):
            # Check for Cursor/Claude Code hooks format
            if "hook_event_name" in payload:
                hook_event_name = payload.get("hook_event_name", "")

                # Cursor uses "conversation_id", Claude Code uses "session_id"
                session_id = payload.get("conversation_id") or payload.get("session_id", "")
                if not isinstance(session_id, str):
                    session_id = str(session_id) if session_id is not None else ""

                content = ""

                # Handle different hook event types
                if hook_event_name == "beforeSubmitPrompt":
                    # Cursor: user prompt is in "prompt" field
                    content = payload.get("prompt", "")
                elif hook_event_name in ("stop", "Stop"):
                    # Cursor stop event: need to read from transcript file
                    transcript_path = payload.get("transcript_path")
                    content = _read_transcript_content(transcript_path)
                else:
                    # Claude Code format: check "prompt" or "last_assistant_message"
                    content = payload.get("prompt") or payload.get("last_assistant_message", "")

                if not isinstance(content, str):
                    content = str(content) if content is not None else ""

                return Event(session_id=session_id, content=content)

            # Standard format
            session_id = payload.get("session_id", "")
            if not isinstance(session_id, str):
                session_id = str(session_id) if session_id is not None else ""

            content = payload.get("content", "")
            if not isinstance(content, str):
                content = str(content) if content is not None else ""

            return Event(session_id=session_id, content=content)

        elif isinstance(payload, str):
            # If payload is a plain string, treat as content
            return Event(session_id="", content=payload)

        else:
            # Other types, convert to string
            return Event(session_id="", content=str(payload))

    except json.JSONDecodeError:
        # Not valid JSON, treat as raw text
        return Event(session_id="", content=data)
    except (TypeError, AttributeError):
        return None
