"""Tests for the main module."""

import pytest
from unittest.mock import patch, MagicMock

from prompt_collector.main import parse_args, run
from prompt_collector.formatter import EventType


class TestParseArgs:
    """Test cases for parse_args function."""

    def test_parse_prompt_type(self):
        """Test parsing --type prompt."""
        args = parse_args(["--type", "prompt"])
        assert args.event_type == "prompt"

    def test_parse_result_type(self):
        """Test parsing --type result."""
        args = parse_args(["--type", "result"])
        assert args.event_type == "result"

    def test_parse_with_session_id(self):
        """Test parsing with --session-id."""
        args = parse_args(["--type", "prompt", "--session-id", "abc123"])
        assert args.session_id == "abc123"

    def test_parse_with_content(self):
        """Test parsing with --content."""
        args = parse_args(["--type", "prompt", "--content", "Hello"])
        assert args.content == "Hello"

    def test_missing_type_raises_error(self):
        """Test that missing --type raises error."""
        with pytest.raises(SystemExit):
            parse_args([])

    def test_invalid_type_raises_error(self):
        """Test that invalid --type raises error."""
        with pytest.raises(SystemExit):
            parse_args(["--type", "invalid"])


class TestRun:
    """Test cases for run function."""

    @patch("prompt_collector.main.get_api_base_url")
    def test_no_api_url_exits_silently(self, mock_get_url):
        """Test that missing API URL exits silently."""
        mock_get_url.return_value = None
        # Should not raise
        run(EventType.PROMPT)

    @patch("prompt_collector.main.get_username")
    @patch("prompt_collector.main.get_api_base_url")
    def test_no_username_exits_silently(self, mock_get_url, mock_get_user):
        """Test that missing username exits silently."""
        mock_get_url.return_value = "https://api.example.com"
        mock_get_user.return_value = None
        # Should not raise
        run(EventType.PROMPT)

    @patch("prompt_collector.main.send_event")
    @patch("prompt_collector.main.read_stdin")
    @patch("prompt_collector.main.get_api_key")
    @patch("prompt_collector.main.get_timeout")
    @patch("prompt_collector.main.get_username")
    @patch("prompt_collector.main.get_api_base_url")
    def test_successful_run(
        self,
        mock_get_url,
        mock_get_user,
        mock_get_timeout,
        mock_get_key,
        mock_read_stdin,
        mock_send,
    ):
        """Test successful run with all parameters."""
        mock_get_url.return_value = "https://api.example.com"
        mock_get_user.return_value = "testuser"
        mock_get_timeout.return_value = 5.0
        mock_get_key.return_value = None
        mock_read_stdin.return_value = '{"session_id": "abc123", "content": "Hello"}'
        mock_send.return_value = True

        run(EventType.PROMPT)

        # Verify send_event was called
        mock_send.assert_called_once()
        call_args = mock_send.call_args
        assert call_args[1]["api_endpoint"] == "https://api.example.com/api/sessions"
        assert call_args[1]["payload"]["username"] == "testuser"
        assert call_args[1]["payload"]["session_id"] == "abc123"
        assert call_args[1]["payload"]["prompt"] == "Hello"
