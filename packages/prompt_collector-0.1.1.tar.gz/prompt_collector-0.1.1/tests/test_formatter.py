"""Tests for the formatter module."""

import pytest

from prompt_collector.formatter import (
    EventType,
    format_payload,
    get_api_endpoint,
    truncate_content,
)


class TestFormatPayload:
    """Test cases for format_payload function."""

    def test_format_prompt_event(self):
        """Test formatting a prompt event."""
        payload = format_payload(
            username="testuser",
            session_id="sess123",
            event_type=EventType.PROMPT,
            content="Hello AI",
        )
        assert payload["username"] == "testuser"
        assert payload["session_id"] == "sess123"
        assert payload["prompt"] == "Hello AI"
        assert "result" not in payload

    def test_format_result_event(self):
        """Test formatting a result event."""
        payload = format_payload(
            username="testuser",
            session_id="sess123",
            event_type=EventType.RESULT,
            content="AI response",
        )
        assert payload["username"] == "testuser"
        assert payload["session_id"] == "sess123"
        assert payload["result"] == "AI response"
        assert "prompt" not in payload

    def test_format_with_empty_content(self):
        """Test formatting with empty content."""
        payload = format_payload(
            username="user",
            session_id="sess",
            event_type=EventType.PROMPT,
            content="",
        )
        assert payload["prompt"] == ""


class TestTruncateContent:
    """Test cases for truncate_content function."""

    def test_short_content_not_truncated(self):
        """Test that short content is not truncated."""
        content = "Short message"
        assert truncate_content(content, max_length=100) == content

    def test_long_content_truncated(self):
        """Test that long content is truncated with ellipsis."""
        content = "a" * 1000
        result = truncate_content(content, max_length=100)
        assert len(result) == 100
        assert result.endswith("...")
        assert result[:97] == "a" * 97

    def test_empty_content(self):
        """Test that empty content returns empty string."""
        assert truncate_content("") == ""

    def test_exact_max_length(self):
        """Test content exactly at max length."""
        content = "a" * 100
        assert truncate_content(content, max_length=100) == content


class TestGetApiEndpoint:
    """Test cases for get_api_endpoint function."""

    def test_basic_url(self):
        """Test basic URL formatting."""
        assert get_api_endpoint("https://api.example.com") == \
               "https://api.example.com/api/sessions"

    def test_url_with_trailing_slash(self):
        """Test URL with trailing slash."""
        assert get_api_endpoint("https://api.example.com/") == \
               "https://api.example.com/api/sessions"

    def test_url_with_path(self):
        """Test URL with existing path."""
        assert get_api_endpoint("https://api.example.com/v1") == \
               "https://api.example.com/v1/api/sessions"
