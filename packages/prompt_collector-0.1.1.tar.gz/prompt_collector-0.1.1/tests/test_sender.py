"""Tests for the sender module."""

import pytest
import responses

from prompt_collector.sender import send_event


class TestSendEvent:
    """Test cases for send_event function."""

    @responses.activate
    def test_successful_send(self):
        """Test successful HTTP request."""
        responses.add(
            responses.POST,
            "https://api.example.com/api/sessions",
            json={"status": "ok"},
            status=201,
        )

        result = send_event(
            api_endpoint="https://api.example.com/api/sessions",
            payload={"test": "data"},
        )
        assert result is True

    @responses.activate
    def test_successful_send_with_auth(self):
        """Test successful HTTP request with API key."""
        responses.add(
            responses.POST,
            "https://api.example.com/api/sessions",
            json={"status": "ok"},
            status=201,
        )

        result = send_event(
            api_endpoint="https://api.example.com/api/sessions",
            payload={"test": "data"},
            api_key="secret123",
        )
        assert result is True
        # Verify Authorization header was sent
        assert responses.calls[0].request.headers["Authorization"] == "Bearer secret123"

    @responses.activate
    def test_failed_send_returns_false(self):
        """Test that failed requests return False."""
        responses.add(
            responses.POST,
            "https://api.example.com/api/sessions",
            status=500,
        )

        result = send_event(
            api_endpoint="https://api.example.com/api/sessions",
            payload={"test": "data"},
        )
        assert result is False

    @responses.activate
    def test_400_error_returns_false(self):
        """Test that 400 error returns False."""
        responses.add(
            responses.POST,
            "https://api.example.com/api/sessions",
            json={"error": "validation failed"},
            status=400,
        )

        result = send_event(
            api_endpoint="https://api.example.com/api/sessions",
            payload={"test": "data"},
        )
        assert result is False

    @responses.activate
    def test_request_exception_handled(self):
        """Test that request exceptions are handled silently."""
        # Don't add any response to simulate connection error
        result = send_event(
            api_endpoint="https://invalid-domain-that-does-not-exist.com/api/sessions",
            payload={"test": "data"},
            timeout=0.001,
        )
        assert result is False
