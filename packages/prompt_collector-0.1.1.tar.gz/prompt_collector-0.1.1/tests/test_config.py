"""Tests for the config module."""

import os

import pytest

from prompt_collector.config import (
    ENV_API_BASE_URL,
    ENV_API_KEY,
    ENV_TIMEOUT,
    ENV_USERNAME,
    DEFAULT_TIMEOUT,
    get_api_base_url,
    get_api_key,
    get_timeout,
    get_username,
)


class TestGetApiBaseUrl:
    """Test cases for get_api_base_url function."""

    def test_returns_url_when_set(self, monkeypatch):
        """Test that URL is returned when environment variable is set."""
        monkeypatch.setenv(ENV_API_BASE_URL, "https://api.example.com")
        assert get_api_base_url() == "https://api.example.com"

    def test_trims_trailing_slash(self, monkeypatch):
        """Test that trailing slash is trimmed."""
        monkeypatch.setenv(ENV_API_BASE_URL, "https://api.example.com/")
        assert get_api_base_url() == "https://api.example.com"

    def test_returns_none_when_not_set(self, monkeypatch):
        """Test that None is returned when environment variable is not set."""
        monkeypatch.delenv(ENV_API_BASE_URL, raising=False)
        assert get_api_base_url() is None

    def test_returns_none_when_empty(self, monkeypatch):
        """Test that None is returned when environment variable is empty."""
        monkeypatch.setenv(ENV_API_BASE_URL, "")
        assert get_api_base_url() is None


class TestGetUsername:
    """Test cases for get_username function."""

    def test_returns_username_when_set(self, monkeypatch):
        """Test that username is returned when environment variable is set."""
        monkeypatch.setenv(ENV_USERNAME, "testuser")
        assert get_username() == "testuser"

    def test_truncates_long_username(self, monkeypatch):
        """Test that long username is truncated to 255 chars."""
        long_name = "a" * 300
        monkeypatch.setenv(ENV_USERNAME, long_name)
        assert len(get_username()) == 255

    def test_returns_none_when_not_set(self, monkeypatch):
        """Test that None is returned when environment variable is not set."""
        monkeypatch.delenv(ENV_USERNAME, raising=False)
        assert get_username() is None


class TestGetApiKey:
    """Test cases for get_api_key function."""

    def test_returns_key_when_set(self, monkeypatch):
        """Test that API key is returned when environment variable is set."""
        monkeypatch.setenv(ENV_API_KEY, "secret123")
        assert get_api_key() == "secret123"

    def test_returns_none_when_not_set(self, monkeypatch):
        """Test that None is returned when environment variable is not set."""
        monkeypatch.delenv(ENV_API_KEY, raising=False)
        assert get_api_key() is None


class TestGetTimeout:
    """Test cases for get_timeout function."""

    def test_returns_default_when_not_set(self, monkeypatch):
        """Test that default timeout is returned when not set."""
        monkeypatch.delenv(ENV_TIMEOUT, raising=False)
        assert get_timeout() == DEFAULT_TIMEOUT

    def test_returns_parsed_value(self, monkeypatch):
        """Test that parsed float value is returned."""
        monkeypatch.setenv(ENV_TIMEOUT, "10.5")
        assert get_timeout() == 10.5

    def test_returns_default_on_invalid_value(self, monkeypatch):
        """Test that default is returned on invalid value."""
        monkeypatch.setenv(ENV_TIMEOUT, "invalid")
        assert get_timeout() == DEFAULT_TIMEOUT
