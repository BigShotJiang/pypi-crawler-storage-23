"""Tests for the parser module."""

import pytest

from prompt_collector.parser import Event, parse_event, read_stdin


class TestParseEvent:
    """Test cases for parse_event function."""

    def test_valid_json_event(self):
        """Test parsing a valid JSON event."""
        data = '{"session_id": "abc123", "content": "Hello"}'
        event = parse_event(data)
        assert event is not None
        assert event.session_id == "abc123"
        assert event.content == "Hello"

    def test_json_with_empty_session_id(self):
        """Test parsing JSON with empty session_id."""
        data = '{"session_id": "", "content": "Hello"}'
        event = parse_event(data)
        assert event is not None
        assert event.session_id == ""
        assert event.content == "Hello"

    def test_json_missing_session_id(self):
        """Test parsing JSON missing session_id field."""
        data = '{"content": "Hello"}'
        event = parse_event(data)
        assert event is not None
        assert event.session_id == ""
        assert event.content == "Hello"

    def test_json_missing_content(self):
        """Test parsing JSON missing content field."""
        data = '{"session_id": "abc123"}'
        event = parse_event(data)
        assert event is not None
        assert event.session_id == "abc123"
        assert event.content == ""

    def test_raw_text_not_json(self):
        """Test parsing raw text that is not JSON."""
        data = "This is a raw message"
        event = parse_event(data)
        assert event is not None
        assert event.session_id == ""
        assert event.content == "This is a raw message"

    def test_empty_string(self):
        """Test that empty string returns None."""
        event = parse_event("")
        assert event is None

    def test_whitespace_only(self):
        """Test that whitespace-only string returns None."""
        event = parse_event("   \n\t  ")
        assert event is None

    def test_json_string_value(self):
        """Test parsing a JSON string value."""
        data = '"plain string"'
        event = parse_event(data)
        assert event is not None
        assert event.session_id == ""
        assert event.content == "plain string"

    def test_json_number_value(self):
        """Test parsing a JSON number value."""
        data = "123"
        event = parse_event(data)
        assert event is not None
        assert event.content == "123"

    def test_nested_json_content(self):
        """Test parsing JSON with complex content."""
        data = '{"session_id": "abc", "content": "{\\"nested\\": \\"value\\"}"}'
        event = parse_event(data)
        assert event is not None
        assert event.session_id == "abc"
        assert "nested" in event.content


class TestParseCursorHooks:
    """Test cases for Cursor hooks JSON format."""

    def test_cursor_before_submit_prompt(self):
        """Test parsing Cursor beforeSubmitPrompt event."""
        data = '''{
            "conversation_id": "28eea6bb-6499-4901-ba6d-51a5d9a53e0f",
            "generation_id": "bc7b6ce1-bae7-4715-9bb3-62d4270d6d9f",
            "model": "kimi-k2.5",
            "prompt": "这个项目是做什么的？",
            "attachments": [],
            "hook_event_name": "beforeSubmitPrompt",
            "cursor_version": "2.6.11",
            "workspace_roots": ["/d:/08-Code/prompt_pitcher_cli"],
            "user_email": "jiangjiyu@zkme.io",
            "transcript_path": null
        }'''
        event = parse_event(data)
        assert event is not None
        assert event.session_id == "28eea6bb-6499-4901-ba6d-51a5d9a53e0f"
        assert event.content == "这个项目是做什么的？"

    def test_cursor_stop_without_transcript(self):
        """Test parsing Cursor stop event without transcript path."""
        data = '''{
            "conversation_id": "28eea6bb-6499-4901-ba6d-51a5d9a53e0f",
            "generation_id": "bc7b6ce1-bae7-4715-9bb3-62d4270d6d9f",
            "model": "kimi-k2.5",
            "status": "completed",
            "loop_count": 0,
            "hook_event_name": "stop",
            "cursor_version": "2.6.11",
            "workspace_roots": ["/d:/08-Code/prompt_pitcher_cli"],
            "user_email": "jiangjiyu@zkme.io",
            "transcript_path": null
        }'''
        event = parse_event(data)
        assert event is not None
        assert event.session_id == "28eea6bb-6499-4901-ba6d-51a5d9a53e0f"
        # Without transcript file, content should be empty
        assert event.content == ""

    def test_cursor_conversation_id_as_session_id(self):
        """Test that conversation_id is correctly mapped to session_id."""
        data = '''{
            "conversation_id": "test-conv-123",
            "hook_event_name": "beforeSubmitPrompt",
            "prompt": "Hello"
        }'''
        event = parse_event(data)
        assert event is not None
        assert event.session_id == "test-conv-123"
        assert event.content == "Hello"
