"""
OCR引擎单元测试
"""

import pytest
from pathlib import Path
from src import create_ocr_engine, load_config, get_default_config


class TestOCREngine:
    """OCR引擎测试"""

    def test_create_ocr_engine_chinese(self):
        """测试创建中文OCR引擎"""
        ocr = create_ocr_engine(lang="ch", use_gpu=False)
        assert ocr is not None
        assert ocr.lang == "ch"
        assert ocr.use_gpu is False

    def test_create_ocr_engine_english(self):
        """测试创建英文OCR引擎"""
        ocr = create_ocr_engine(lang="en", use_gpu=False)
        assert ocr is not None
        assert ocr.lang == "en"

    def test_ocr_repr(self):
        """测试OCR引擎的字符串表示"""
        ocr = create_ocr_engine(lang="ch", use_gpu=False)
        repr_str = repr(ocr)
        assert "ch" in repr_str
        assert "False" in repr_str

    def test_recognize_nonexistent_file(self):
        """测试识别不存在的文件"""
        ocr = create_ocr_engine()
        result, elapse = ocr.recognize("nonexistent.jpg")

        assert result is None
        assert elapse == 0.0

    def test_recognize_invalid_format(self):
        """测试识别不支持的格式"""
        ocr = create_ocr_engine()
        # 创建一个临时文本文件
        test_file = Path("test_temp.txt")
        test_file.write_text("test")

        result, elapse = ocr.recognize(str(test_file))
        assert result is None

        # 清理
        test_file.unlink()

    def test_get_text_only_empty_result(self):
        """测试从空结果提取文本"""
        ocr = create_ocr_engine()
        text = ocr.get_text_only([])
        assert text == ""

    def test_get_detailed_result_empty(self):
        """测试获取空的详细结果"""
        ocr = create_ocr_engine()
        detailed = ocr.get_detailed_result([])
        assert detailed == []


class TestConfig:
    """配置管理测试"""

    def test_get_default_config(self):
        """测试获取默认配置"""
        config = get_default_config()

        assert 'model' in config
        assert 'image' in config
        assert 'output' in config
        assert 'batch' in config
        assert 'logging' in config

        assert config['model']['lang'] == 'ch'
        assert config['batch']['threads'] == 4

    def test_load_config_not_exists(self):
        """测试加载不存在的配置文件"""
        with pytest.raises(FileNotFoundError):
            load_config("nonexistent_config.yaml")

    def test_load_config_default(self):
        """测试加载默认配置文件"""
        try:
            config = load_config("config/config.yaml")
            assert 'model' in config
        except FileNotFoundError:
            # 如果配置文件不存在,跳过测试
            pytest.skip("配置文件不存在")

    def test_merge_configs(self):
        """测试配置合并"""
        from src import _merge_config

        default = {'a': 1, 'b': {'x': 10, 'y': 20}}
        custom = {'b': {'y': 30}, 'c': 3}

        result = _merge_config(default, custom)

        assert result['a'] == 1
        assert result['b']['x'] == 10
        assert result['b']['y'] == 30
        assert result['c'] == 3


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
