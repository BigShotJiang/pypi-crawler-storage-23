"""
图像处理器测试
用于保护重构后的功能
"""

import pytest
from pathlib import Path
from PIL import Image
import numpy as np
from src.image_processor import ImageProcessor, create_image_processor


class TestImageProcessor:
    """图像处理器测试"""

    def test_create_processor(self):
        """测试创建图像处理器"""
        processor = create_image_processor()
        assert processor is not None
        assert processor.max_size == 2048
        assert processor.auto_rotate is True

    def test_validate_image_missing_file(self):
        """测试验证不存在的文件"""
        valid, msg = ImageProcessor.validate_image("nonexistent.jpg")
        assert valid is False
        assert "不存在" in msg

    def test_validate_image_success(self, tmp_path):
        """测试验证有效的图片"""
        # 创建测试图片
        img = Image.new('RGB', (100, 100), color='red')
        test_file = tmp_path / "test.jpg"
        img.save(test_file)

        valid, msg = ImageProcessor.validate_image(str(test_file))
        assert valid is True
        assert msg == ""

    def test_resize_image_no_resize_needed(self):
        """测试不需要调整尺寸的图片"""
        processor = ImageProcessor(max_size=2048)
        img = np.zeros((100, 100, 3), dtype=np.uint8)

        result = processor.resize_image(img)
        assert result.shape == (100, 100, 3)

    def test_resize_image_needs_resize(self):
        """测试需要缩小的大图片"""
        processor = ImageProcessor(max_size=100)
        img = np.zeros((200, 300, 3), dtype=np.uint8)

        result = processor.resize_image(img)
        # 长边应该被缩放到100
        assert max(result.shape[:2]) <= 100

    def test_to_grayscale(self):
        """测试转换为灰度图"""
        processor = ImageProcessor()
        img = np.zeros((100, 100, 3), dtype=np.uint8)

        result = processor.to_grayscale(img)
        assert len(result.shape) == 2  # 灰度图是2D的
        assert result.shape == (100, 100)

    def test_get_image_info(self, tmp_path):
        """测试获取图片信息"""
        # 创建测试图片
        img = Image.new('RGB', (800, 600), color='blue')
        test_file = tmp_path / "test_info.jpg"
        img.save(test_file)

        processor = ImageProcessor()
        info = processor.get_image_info(str(test_file))

        assert info is not None
        assert info['width'] == 800
        assert info['height'] == 600
        assert info['channels'] == 3
        assert info['format'] == '.JPG'


class TestImageProcessorIntegration:
    """图像处理器集成测试"""

    def test_preprocess_workflow(self, tmp_path):
        """测试完整的预处理流程"""
        # 创建测试图片
        img = Image.new('RGB', (3000, 2000), color='white')
        test_file = tmp_path / "large.jpg"
        img.save(test_file)

        processor = ImageProcessor(max_size=1000)
        result = processor.preprocess(str(test_file))

        assert result is not None
        # 应该被缩放
        assert max(result.shape[:2]) <= 1000

    def test_enhance_image(self):
        """测试图片增强"""
        processor = ImageProcessor(enhance_contrast=True)
        img = np.zeros((100, 100, 3), dtype=np.uint8)

        result = processor.enhance_image(img)
        assert result is not None
        assert result.shape == img.shape


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
