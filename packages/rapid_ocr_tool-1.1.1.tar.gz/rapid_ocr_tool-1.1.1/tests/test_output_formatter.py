"""
输出格式化器测试
用于保护重构后的功能
"""

import pytest
import json
from pathlib import Path
from src.output_formatter import OutputFormatter, create_formatter


class TestOutputFormatter:
    """输出格式化器测试"""

    def test_create_formatter(self):
        """测试创建格式化器"""
        formatter = create_formatter()
        assert formatter is not None
        assert formatter.indent == 2

    def test_format_text_empty(self):
        """测试格式化空结果"""
        formatter = OutputFormatter()
        result = formatter.format_text([])
        assert result == ""

    def test_format_text_simple(self):
        """测试格式化简单文本"""
        formatter = OutputFormatter()
        # OCR结果格式(简化版): [text] 或 [bbox, text, confidence]
        ocr_result = [
            ["第一行"],
            ["第二行"]
        ]

        result = formatter.format_text(ocr_result)
        assert "第一行" in result
        assert "第二行" in result

    def test_format_json_with_coords(self):
        """测试JSON格式(包含坐标)"""
        formatter = OutputFormatter()
        ocr_result = [
            [[[0, 0], [10, 0], [10, 10], [0, 10]], "文本", 0.99]
        ]

        result = formatter.format_json(ocr_result, include_coords=True)
        data = json.loads(result)

        assert "lines" in data
        assert len(data["lines"]) == 1
        assert data["lines"][0]["text"] == "文本"
        assert "bbox" in data["lines"][0]

    def test_format_markdown(self):
        """测试Markdown格式"""
        formatter = OutputFormatter()
        ocr_result = [
            ["第一行"],
            ["第二行"]
        ]

        result = formatter.format_markdown(ocr_result)
        assert "# OCR识别结果" in result
        assert "1. 第一行" in result
        assert "2. 第二行" in result

    def test_format_html(self):
        """测试HTML格式"""
        formatter = OutputFormatter()
        ocr_result = [["测试文本"]]

        result = formatter.format_html(ocr_result)
        assert "<!DOCTYPE html>" in result
        assert "测试文本" in result
        assert "</html>" in result

    def test_save_file_txt(self, tmp_path):
        """测试保存为TXT"""
        formatter = OutputFormatter()
        test_file = tmp_path / "output.txt"

        result = formatter.save_file("测试内容", str(test_file))
        assert result is True
        assert test_file.exists()

        content = test_file.read_text(encoding='utf-8')
        assert "测试内容" in content

    def test_save_file_json(self, tmp_path):
        """测试保存为JSON"""
        formatter = OutputFormatter()
        test_file = tmp_path / "output.json"

        result = formatter.save_file('{"key": "value"}', str(test_file))
        assert result is True
        assert test_file.exists()

        data = json.loads(test_file.read_text(encoding='utf-8'))
        assert data["key"] == "value"

    def test_format_and_save_txt(self, tmp_path):
        """测试格式化并保存为TXT"""
        formatter = OutputFormatter()
        test_file = tmp_path / "result.txt"
        ocr_result = [["识别的文本"]]

        result = formatter.format_and_save(
            ocr_result,
            str(test_file),
            format_type="txt"
        )

        assert result is True
        assert test_file.exists()
        content = test_file.read_text(encoding='utf-8')
        assert "识别的文本" in content


class TestOutputFormatterEdgeCases:
    """边界情况测试"""

    def test_format_text_with_bbox(self):
        """测试带边界框的文本格式化"""
        formatter = OutputFormatter()
        ocr_result = [
            [[[0, 0], [10, 0], [10, 10], [0, 10]], "文本", 0.99],
            [[[20, 20], [30, 20], [30, 30], [20, 30]], "更多", 0.95]
        ]

        result = formatter.format_text(ocr_result)
        lines = result.strip().split('\n')
        assert len(lines) == 2
        assert "文本" in lines[0]
        assert "更多" in lines[1]

    def test_format_json_empty_result(self):
        """测试空结果的JSON格式"""
        formatter = OutputFormatter()
        result = formatter.format_json([])
        data = json.loads(result)

        assert data["lines"] == []
        assert data["line_count"] == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
