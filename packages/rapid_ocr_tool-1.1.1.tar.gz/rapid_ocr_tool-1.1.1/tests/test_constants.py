"""
常量模块测试
"""

import pytest
from src.constants import (
    MAX_FILE_SIZE,
    SUPPORTED_IMAGE_FORMATS,
    DEFAULT_MAX_IMAGE_SIZE,
    DEFAULT_THREAD_COUNT,
    DEFAULT_LANGUAGE,
    SUPPORTED_OUTPUT_FORMATS
)


class TestConstants:
    """常量测试"""

    def test_max_file_size(self):
        """测试文件大小限制"""
        assert MAX_FILE_SIZE == 50 * 1024 * 1024  # 50MB

    def test_supported_image_formats(self):
        """测试支持的图片格式"""
        assert '.jpg' in SUPPORTED_IMAGE_FORMATS
        assert '.png' in SUPPORTED_IMAGE_FORMATS
        assert '.jpeg' in SUPPORTED_IMAGE_FORMATS
        assert '.bmp' in SUPPORTED_IMAGE_FORMATS

    def test_default_max_image_size(self):
        """测试默认最大图片尺寸"""
        assert DEFAULT_MAX_IMAGE_SIZE == 2048

    def test_default_thread_count(self):
        """测试默认线程数"""
        assert DEFAULT_THREAD_COUNT == 4

    def test_default_language(self):
        """测试默认语言"""
        assert DEFAULT_LANGUAGE == "ch"

    def test_supported_output_formats(self):
        """测试支持的输出格式"""
        assert 'txt' in SUPPORTED_OUTPUT_FORMATS
        assert 'json' in SUPPORTED_OUTPUT_FORMATS
        assert 'md' in SUPPORTED_OUTPUT_FORMATS


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
