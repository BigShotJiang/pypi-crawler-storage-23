"""
本地轻量级OCR工具
基于RapidOCR实现
"""

import yaml
from pathlib import Path
from typing import Dict, Any

from .ocr_engine import OCREngine, create_ocr_engine
from .image_processor import ImageProcessor, create_image_processor
from .batch_processor import BatchProcessor, create_batch_processor
from .output_formatter import OutputFormatter, create_formatter
from .constants import (
    DEFAULT_LANGUAGE,
    DEFAULT_MAX_IMAGE_SIZE,
    DEFAULT_THREAD_COUNT,
    SUPPORTED_OUTPUT_FORMATS
)

__all__ = [
    "OCREngine",
    "create_ocr_engine",
    "ImageProcessor",
    "create_image_processor",
    "BatchProcessor",
    "create_batch_processor",
    "OutputFormatter",
    "create_formatter",
    "load_config",
    "get_default_config",
]

__version__ = "1.0.0"


def get_default_config() -> Dict[str, Any]:
    """获取默认配置"""
    return {
        'model': {
            'lang': DEFAULT_LANGUAGE,
            'use_gpu': False,
            'download_path': './models'
        },
        'image': {
            'max_size': DEFAULT_MAX_IMAGE_SIZE,
            'auto_rotate': True,
            'enhance_contrast': False
        },
        'output': {
            'default_dir': './output',
            'default_format': 'txt',
            'include_coords': False,
            'json_indent': 2
        },
        'batch': {
            'threads': DEFAULT_THREAD_COUNT,
            'retry': 2,
            'skip_exists': False
        },
        'logging': {
            'level': 'INFO',
            'to_file': True,
            'file_path': './logs/ocr.log'
        }
    }


def load_config(config_path: str = "config/config.yaml") -> Dict[str, Any]:
    """
    加载配置文件

    Args:
        config_path: 配置文件路径

    Returns:
        配置字典

    Raises:
        FileNotFoundError: 配置文件不存在
        yaml.YAMLError: YAML格式错误
    """
    config_file = Path(config_path)

    if not config_file.exists():
        raise FileNotFoundError(f"配置文件不存在: {config_path}")

    try:
        with open(config_file, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)

        # 合并默认配置
        default_config = get_default_config()
        merged_config = _merge_config(default_config, config)

        return merged_config

    except yaml.YAMLError as e:
        raise yaml.YAMLError(f"配置文件格式错误: {e}")


def _merge_config(
    default: Dict[str, Any],
    custom: Dict[str, Any]
) -> Dict[str, Any]:
    """合并配置(自定义配置覆盖默认配置)"""
    result = default.copy()

    for key, value in custom.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _merge_config(result[key], value)
        else:
            result[key] = value

    return result
