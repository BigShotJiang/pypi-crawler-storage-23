"""
输出格式化模块
支持多种输出格式: 纯文本、Markdown、JSON等
"""

import json
from pathlib import Path
from typing import List, Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)


class OutputFormatter:
    """输出格式化器"""

    def __init__(self, indent: int = 2, ensure_ascii: bool = False):
        """
        初始化格式化器

        Args:
            indent: JSON缩进空格数
            ensure_ascii: JSON是否确保ASCII(中文显示为\\uXXXX)
        """
        self.indent = indent
        self.ensure_ascii = ensure_ascii

    def _extract_text(self, line: List) -> Optional[str]:
        """从OCR结果行中提取文本"""
        if not isinstance(line, list) or len(line) == 0:
            return None

        # line格式: [text] 或 [bbox, text, confidence]
        text = line[1] if len(line) > 1 else line[0]
        return text if isinstance(text, str) else None

    def _extract_texts(self, result: List) -> List[str]:
        """提取所有文本行"""
        return [text for line in result if (text := self._extract_text(line))]

    def format_text(self, result: List) -> str:
        """
        格式化为纯文本

        Args:
            result: OCR识别结果

        Returns:
            纯文本字符串
        """
        return "\n".join(self._extract_texts(result))

    def format_markdown(self, result: List, title: str = "OCR识别结果") -> str:
        """
        格式化为Markdown

        Args:
            result: OCR识别结果
            title: 文档标题

        Returns:
            Markdown字符串
        """
        texts = self._extract_texts(result)

        if not texts:
            return f"# {title}\n\n*未识别到文字*"

        lines = [f"# {title}\n"]
        lines.extend(f"{idx}. {text}" for idx, text in enumerate(texts, 1))

        return "\n".join(lines)

    def format_json(
        self,
        result: List,
        image_path: Optional[str] = None,
        include_coords: bool = False,
        include_confidence: bool = True,
    ) -> str:
        """
        格式化为JSON

        Args:
            result: OCR识别结果
            image_path: 图片路径
            include_coords: 是否包含坐标
            include_confidence: 是否包含置信度

        Returns:
            JSON字符串
        """
        lines = []
        texts = []

        for line in result:
            if not isinstance(line, list) or len(line) == 0:
                continue

            line_data = {}
            if len(line) >= 3:
                # [bbox, text, confidence]
                line_data["text"] = line[1]
                if include_coords:
                    line_data["bbox"] = line[0]
                if include_confidence:
                    line_data["confidence"] = line[2]
                texts.append(line[1])
            elif len(line) == 1:
                # [text]
                line_data["text"] = line[0]
                texts.append(line[0])

            lines.append(line_data)

        data = {
            "image": image_path or "",
            "lines": lines,
            "text": "\n".join(texts),
            "line_count": len(lines)
        }

        return json.dumps(data, ensure_ascii=self.ensure_ascii, indent=self.indent)

    def format_html(
        self,
        result: List,
        title: str = "OCR识别结果"
    ) -> str:
        """
        格式化为HTML

        Args:
            result: OCR识别结果
            title: 页面标题

        Returns:
            HTML字符串
        """
        texts = self._extract_texts(result)

        html_template = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        body {{
            font-family: "Microsoft YaHei", Arial, sans-serif;
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .container {{
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #333;
            border-bottom: 2px solid #4CAF50;
            padding-bottom: 10px;
        }}
        .line {{
            padding: 8px 0;
            line-height: 1.6;
            border-bottom: 1px dashed #eee;
        }}
        .line:last-child {{
            border-bottom: none;
        }}
        .line-number {{
            color: #4CAF50;
            font-weight: bold;
            margin-right: 10px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>{title}</h1>
"""

        # 添加文本行
        for idx, text in enumerate(texts, 1):
            html_template += f'        <div class="line"><span class="line-number">{idx}.</span>{text}</div>\n'

        html_template += """    </div>
</body>
</html>"""

        return html_template

    def format_csv(self, result: List) -> str:
        """
        格式化为CSV

        Args:
            result: OCR识别结果

        Returns:
            CSV字符串
        """
        import csv
        from io import StringIO

        output = StringIO()
        writer = csv.writer(output)
        writer.writerow(["行号", "文本内容", "置信度"])

        for idx, line in enumerate(result, 1):
            if not isinstance(line, list) or len(line) == 0:
                continue

            text = line[1] if len(line) > 1 else line[0]
            confidence = line[2] if len(line) >= 3 else ""

            if isinstance(text, str):
                writer.writerow([idx, text, confidence])

        return output.getvalue()

    def save_file(
        self,
        content: str,
        output_path: str,
        encoding: str = "utf-8"
    ) -> bool:
        """
        保存内容到文件

        Args:
            content: 文件内容
            output_path: 输出路径
            encoding: 文件编码

        Returns:
            是否成功
        """
        try:
            output_path = Path(output_path)
            output_path.parent.mkdir(parents=True, exist_ok=True)

            with open(output_path, 'w', encoding=encoding) as f:
                f.write(content)

            logger.info(f"已保存到: {output_path}")
            return True

        except Exception as e:
            logger.error(f"保存失败: {e}")
            return False

    def format_and_save(
        self,
        result: List,
        output_path: str,
        format_type: str = "txt",
        **kwargs
    ) -> bool:
        """
        格式化并保存

        Args:
            result: OCR识别结果
            output_path: 输出路径
            format_type: 格式类型(txt/md/json/html/csv)
            **kwargs: 其他参数

        Returns:
            是否成功
        """
        # 根据格式类型格式化
        if format_type == "txt":
            content = self.format_text(result)
        elif format_type == "md":
            content = self.format_markdown(result, kwargs.get("title", "OCR识别结果"))
        elif format_type == "json":
            content = self.format_json(
                result,
                kwargs.get("image_path"),
                kwargs.get("include_coords", False),
                kwargs.get("include_confidence", True)
            )
        elif format_type == "html":
            content = self.format_html(result, kwargs.get("title", "OCR识别结果"))
        elif format_type == "csv":
            content = self.format_csv(result)
        else:
            logger.error(f"不支持的格式: {format_type}")
            return False

        # 保存文件
        return self.save_file(content, output_path)

    def print_to_console(
        self,
        result: List,
        format_type: str = "text",
        show_line_numbers: bool = True
    ):
        """
        打印到控制台(带美化)

        Args:
            result: OCR识别结果
            format_type: 显示格式
            show_line_numbers: 是否显示行号
        """
        try:
            from rich.console import Console
            from rich.syntax import Syntax
            console = Console()

        except ImportError:
            # 如果没有rich,使用普通打印
            self._print_plain(result, show_line_numbers)
            return

        if format_type == "json":
            # JSON格式用语法高亮
            json_str = self.format_json(result)
            syntax = Syntax(json_str, "json", theme="monokai", line_numbers=True)
            console.print(syntax)

        else:
            # 普通文本格式
            texts = []
            for idx, line in enumerate(result, 1):
                if isinstance(line, list) and len(line) > 0:
                    text = line[1] if len(line) > 1 else line[0]
                    if isinstance(text, str):
                        if show_line_numbers:
                            texts.append(f"[green]{idx:3d}.[/green] {text}")
                        else:
                            texts.append(text)

            console.print("\n".join(texts))

    @staticmethod
    def _print_plain(result: List, show_line_numbers: bool):
        """普通打印(无rich)"""
        for idx, line in enumerate(result, 1):
            if isinstance(line, list) and len(line) > 0:
                text = line[1] if len(line) > 1 else line[0]
                if isinstance(text, str):
                    if show_line_numbers:
                        print(f"{idx:3d}. {text}")
                    else:
                        print(text)


def create_formatter(indent: int = 2) -> OutputFormatter:
    """
    创建格式化器的便捷函数

    Args:
        indent: JSON缩进

    Returns:
        OutputFormatter实例
    """
    return OutputFormatter(indent=indent)
