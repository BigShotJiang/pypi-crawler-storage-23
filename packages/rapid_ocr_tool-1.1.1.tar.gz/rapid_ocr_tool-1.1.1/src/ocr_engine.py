"""
OCR引擎核心模块
基于RapidOCR实现文字识别功能
"""

from rapidocr_onnxruntime import RapidOCR
from pathlib import Path
from typing import List, Tuple, Optional, Dict, Any
import logging

logger = logging.getLogger(__name__)


class OCREngine:
    """OCR引擎封装类"""

    def __init__(
        self,
        lang: str = "ch",
        use_gpu: bool = False,
        model_path: Optional[str] = None,
        **kwargs
    ):
        """
        初始化OCR引擎

        Args:
            lang: 识别语言 (ch=中文, en=英文)
            use_gpu: 是否使用GPU加速
            model_path: 自定义模型路径
            **kwargs: 其他RapidOCR参数
        """
        self.lang = lang
        self.use_gpu = use_gpu

        try:
            # 初始化RapidOCR
            logger.info(f"初始化OCR引擎 - 语言: {lang}, GPU: {use_gpu}")
            self.ocr = RapidOCR(
                det_model_path=model_path,
                use_gpu=use_gpu,
                **kwargs
            )
            logger.info("OCR引擎初始化成功")
        except Exception as e:
            logger.error(f"OCR引擎初始化失败: {e}")
            raise

    def recognize(
        self,
        image_path: str,
        return_coords: bool = False,
        return_confidence: bool = False,
    ) -> Tuple[Optional[List], float]:
        """
        识别单张图片

        Args:
            image_path: 图片路径
            return_coords: 是否返回坐标信息
            return_confidence: 是否返回置信度

        Returns:
            (识别结果列表, 耗时秒数)
            识别结果格式: [(bbox, text, confidence), ...]
        """
        img_path = Path(image_path)

        # 检查文件存在
        if not img_path.exists():
            logger.error(f"图片不存在: {image_path}")
            return None, 0.0

        # 检查文件格式
        supported_formats = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif'}
        if img_path.suffix.lower() not in supported_formats:
            logger.error(f"不支持的图片格式: {img_path.suffix}")
            return None, 0.0

        try:
            logger.debug(f"开始识别图片: {image_path}")

            # 执行识别
            result, elapse = self.ocr(image_path)

            if result is None or len(result) == 0:
                logger.warning(f"未识别到文字: {image_path}")
                return [], elapse

            # 处理结果
            if not return_coords and not return_confidence:
                # 只返回文本
                text_only = [[line[1]] for line in result]
                return text_only, elapse

            return result, elapse

        except Exception as e:
            logger.error(f"识别失败 {image_path}: {e}")
            return None, 0.0

    def recognize_batch(
        self,
        image_paths: List[str],
        return_coords: bool = False,
        return_confidence: bool = False,
    ) -> List[Tuple[List, float]]:
        """
        批量识别图片

        Args:
            image_paths: 图片路径列表
            return_coords: 是否返回坐标信息
            return_confidence: 是否返回置信度

        Returns:
            [(识别结果, 耗时), ...] 列表
        """
        results = []

        for img_path in image_paths:
            result, elapse = self.recognize(
                img_path,
                return_coords=return_coords,
                return_confidence=return_confidence
            )
            results.append((result, elapse))

        return results

    def get_text_only(self, result: List) -> str:
        """
        从识别结果中提取纯文本

        Args:
            result: recognize()返回的结果

        Returns:
            拼接后的文本字符串
        """
        if not result:
            return ""

        texts = []
        for line in result:
            if isinstance(line, list) and len(line) > 0:
                # line格式: [text] 或 [bbox, text, confidence]
                text = line[1] if len(line) > 1 else line[0]
                if isinstance(text, str):
                    texts.append(text)

        return "\n".join(texts)

    def get_detailed_result(self, result: List) -> List[Dict[str, Any]]:
        """
        获取结构化的详细结果

        Args:
            result: recognize()返回的结果

        Returns:
            结构化数据列表
        """
        if not result:
            return []

        detailed = []
        for idx, line in enumerate(result):
            item = {
                "index": idx,
                "text": "",
                "confidence": 0.0,
                "bbox": []
            }

            if len(line) >= 3:
                # [bbox, text, confidence]
                item["bbox"] = line[0]
                item["text"] = line[1]
                item["confidence"] = line[2]
            elif len(line) == 1:
                # [text]
                item["text"] = line[0]

            detailed.append(item)

        return detailed

    def __repr__(self) -> str:
        return f"<OCREngine lang={self.lang} gpu={self.use_gpu}>"


# 便捷函数
def create_ocr_engine(lang: str = "ch", use_gpu: bool = False) -> OCREngine:
    """
    创建OCR引擎实例的便捷函数

    Args:
        lang: 识别语言
        use_gpu: 是否使用GPU

    Returns:
        OCREngine实例
    """
    return OCREngine(lang=lang, use_gpu=use_gpu)
