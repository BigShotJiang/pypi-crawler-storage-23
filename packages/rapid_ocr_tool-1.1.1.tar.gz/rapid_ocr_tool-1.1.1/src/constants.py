"""
常量定义模块
定义项目中使用的各种常量
"""

import logging

# 文件大小限制
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
MIN_FILE_SIZE = 100  # 100 bytes

# 支持的图片格式
SUPPORTED_IMAGE_FORMATS = {
    '.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif'
}

# 图片处理常量
DEFAULT_MAX_IMAGE_SIZE = 2048  # 最大图片尺寸(长边)
DEFAULT_IMAGE_QUALITY = 95  # JPEG质量

# OCR常量
DEFAULT_THREAD_COUNT = 4  # 默认线程数
DEFAULT_RETRY_COUNT = 2  # 默认重试次数
DEFAULT_LANGUAGE = "ch"  # 默认语言(ch=中文, en=英文)

# 输出格式
SUPPORTED_OUTPUT_FORMATS = {
    'txt', 'json', 'md', 'html', 'csv'
}

# 日志级别
LOG_LEVELS = {
    'DEBUG': logging.DEBUG,
    'INFO': logging.INFO,
    'WARNING': logging.WARNING,
    'ERROR': logging.ERROR,
    'CRITICAL': logging.CRITICAL
}

# 性能相关
DEFAULT_BATCH_SIZE = 32  # 批处理大小
PROGRESS_BAR_UPDATE_INTERVAL = 1  # 进度条更新间隔

# 颜色和样式(用于终端输出)
COLORS = {
    'success': 'green',
    'error': 'red',
    'warning': 'yellow',
    'info': 'blue'
}

# 置信度阈值
CONFIDENCE_THRESHOLD = 0.8  # 高置信度阈值
LOW_CONFIDENCE_THRESHOLD = 0.5  # 低置信度阈值
