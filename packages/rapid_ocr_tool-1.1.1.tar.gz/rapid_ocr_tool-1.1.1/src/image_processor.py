"""
图像预处理模块
用于优化OCR识别前的图像质量
"""

import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
from pathlib import Path
from typing import Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class ImageProcessor:
    """图像预处理器"""

    def __init__(
        self,
        max_size: int = 2048,
        auto_rotate: bool = True,
        enhance_contrast: bool = False,
        denoise: bool = False,
    ):
        """
        初始化图像处理器

        Args:
            max_size: 图片最大尺寸(长边)
            auto_rotate: 是否自动旋转矫正
            enhance_contrast: 是否增强对比度
            denoise: 是否去噪
        """
        self.max_size = max_size
        self.auto_rotate = auto_rotate
        self.enhance_contrast = enhance_contrast
        self.denoise = denoise

    def load_image(self, image_path: str) -> Optional[np.ndarray]:
        """
        加载图片

        Args:
            image_path: 图片路径

        Returns:
            OpenCV图像对象
        """
        img_path = Path(image_path)

        if not img_path.exists():
            logger.error(f"图片不存在: {image_path}")
            return None

        try:
            # 使用OpenCV读取
            img = cv2.imread(str(img_path))

            if img is None:
                logger.error(f"无法读取图片: {image_path}")
                return None

            logger.debug(f"成功加载图片: {image_path}, 尺寸: {img.shape}")
            return img

        except Exception as e:
            logger.error(f"加载图片失败 {image_path}: {e}")
            return None

    def resize_image(self, img: np.ndarray) -> np.ndarray:
        """
        调整图片尺寸(保持宽高比)

        Args:
            img: OpenCV图像对象

        Returns:
            调整后的图像
        """
        height, width = img.shape[:2]

        # 获取长边
        long_edge = max(height, width)

        # 如果超过最大尺寸,按比例缩放
        if long_edge > self.max_size:
            scale = self.max_size / long_edge
            new_width = int(width * scale)
            new_height = int(height * scale)

            img = cv2.resize(img, (new_width, new_height), interpolation=cv2.INTER_AREA)
            logger.debug(f"图片缩放: {width}x{height} -> {new_width}x{new_height}")

        return img

    def enhance_image(self, img: np.ndarray) -> np.ndarray:
        """
        增强图片质量

        Args:
            img: OpenCV图像对象

        Returns:
            增强后的图像
        """
        # 转换为PIL格式
        pil_img = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))

        # 增强对比度
        if self.enhance_contrast:
            enhancer = ImageEnhance.Contrast(pil_img)
            pil_img = enhancer.enhance(1.5)
            logger.debug("已增强对比度")

        # 增强锐度
        enhancer = ImageEnhance.Sharpness(pil_img)
        pil_img = enhancer.enhance(1.3)

        # 去噪
        if self.denoise:
            pil_img = pil_img.filter(ImageFilter.MedianFilter())
            logger.debug("已去噪")

        # 转回OpenCV格式
        img = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

        return img

    def binarize(self, img: np.ndarray) -> np.ndarray:
        """
        图像二值化(黑白化)

        Args:
            img: OpenCV图像对象(灰度图)

        Returns:
            二值化后的图像
        """
        # 自适应阈值二值化
        binary = cv2.adaptiveThreshold(
            img, 255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY,
            11, 2
        )

        logger.debug("已完成二值化")
        return binary

    def to_grayscale(self, img: np.ndarray) -> np.ndarray:
        """
        转换为灰度图

        Args:
            img: OpenCV图像对象

        Returns:
            灰度图
        """
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        logger.debug("已转换为灰度图")
        return gray

    def preprocess(self, image_path: str, save_path: Optional[str] = None) -> Optional[np.ndarray]:
        """
        完整的预处理流程

        Args:
            image_path: 输入图片路径
            save_path: 保存处理后的图片路径(可选)

        Returns:
            处理后的OpenCV图像对象
        """
        # 1. 加载图片
        img = self.load_image(image_path)
        if img is None:
            return None

        # 2. 调整尺寸
        img = self.resize_image(img)

        # 3. 增强图片
        img = self.enhance_image(img)

        # 4. 保存处理后的图片(可选)
        if save_path:
            cv2.imwrite(save_path, img)
            logger.debug(f"已保存预处理图片: {save_path}")

        return img

    def get_image_info(self, image_path: str) -> Optional[dict]:
        """
        获取图片信息

        Args:
            image_path: 图片路径

        Returns:
            图片信息字典
        """
        img = self.load_image(image_path)
        if img is None:
            return None

        height, width = img.shape[:2]
        file_size = Path(image_path).stat().st_size

        info = {
            "path": image_path,
            "width": width,
            "height": height,
            "channels": img.shape[2] if len(img.shape) == 3 else 1,
            "file_size": file_size,
            "file_size_mb": round(file_size / (1024 * 1024), 2),
            "format": Path(image_path).suffix.upper()
        }

        return info

    @staticmethod
    def validate_image(image_path: str) -> Tuple[bool, str]:
        """
        验证图片是否有效

        Args:
            image_path: 图片路径

        Returns:
            (是否有效, 错误信息)
        """
        path = Path(image_path)

        # 检查文件存在
        if not path.exists():
            return False, "文件不存在"

        # 检查文件大小
        file_size = path.stat().st_size
        if file_size == 0:
            return False, "文件为空"
        if file_size > 50 * 1024 * 1024:  # 50MB
            return False, "文件过大(>50MB)"

        # 检查格式
        supported_formats = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif'}
        if path.suffix.lower() not in supported_formats:
            return False, f"不支持的格式: {path.suffix}"

        # 尝试打开图片
        try:
            with Image.open(image_path) as img:
                img.verify()
            return True, ""
        except Exception as e:
            return False, f"图片损坏: {str(e)}"


def create_image_processor(
    max_size: int = 2048,
    auto_rotate: bool = True,
    enhance_contrast: bool = False,
) -> ImageProcessor:
    """
    创建图像处理器的便捷函数

    Args:
        max_size: 最大图片尺寸
        auto_rotate: 是否自动旋转
        enhance_contrast: 是否增强对比度

    Returns:
        ImageProcessor实例
    """
    return ImageProcessor(
        max_size=max_size,
        auto_rotate=auto_rotate,
        enhance_contrast=enhance_contrast
    )
