"""
批量处理模块
支持多线程批量OCR识别
"""

from pathlib import Path
from typing import List, Callable, Optional, Dict, Any
from concurrent.futures import ThreadPoolExecutor, as_completed
import logging
from tqdm import tqdm

from .ocr_engine import OCREngine

logger = logging.getLogger(__name__)


class BatchProcessor:
    """批量OCR处理器"""

    def __init__(
        self,
        ocr_engine: OCREngine,
        threads: int = 4,
        retry: int = 2,
        skip_exists: bool = False,
    ):
        """
        初始化批量处理器

        Args:
            ocr_engine: OCR引擎实例
            threads: 线程数
            retry: 失败重试次数
            skip_exists: 是否跳过已存在的输出文件
        """
        self.ocr_engine = ocr_engine
        self.threads = threads
        self.retry = retry
        self.skip_exists = skip_exists

    def get_image_files(
        self,
        input_path: str,
        recursive: bool = False
    ) -> List[Path]:
        """
        获取所有图片文件

        Args:
            input_path: 输入路径(文件或文件夹)
            recursive: 是否递归查找子文件夹

        Returns:
            图片文件路径列表
        """
        input_path = Path(input_path)
        image_files = []

        # 支持的图片格式
        supported_extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif'}

        if input_path.is_file():
            # 单个文件
            if input_path.suffix.lower() in supported_extensions:
                image_files.append(input_path)
            else:
                logger.warning(f"跳过非图片文件: {input_path}")

        elif input_path.is_dir():
            # 文件夹
            if recursive:
                # 递归查找
                image_files = [
                    f for f in input_path.rglob('*')
                    if f.is_file() and f.suffix.lower() in supported_extensions
                ]
            else:
                # 只查找当前目录
                image_files = [
                    f for f in input_path.iterdir()
                    if f.is_file() and f.suffix.lower() in supported_extensions
                ]

        # 排序
        image_files.sort()

        logger.info(f"找到 {len(image_files)} 个图片文件")
        return image_files

    def _init_result(self, image_path: Path) -> Dict[str, Any]:
        """初始化结果字典"""
        return {
            "image": str(image_path),
            "success": False,
            "text": "",
            "elapse": 0.0,
            "error": None
        }

    def _should_skip(
        self,
        image_path: Path,
        output_dir: Optional[Path],
        output_format: str
    ) -> bool:
        """检查是否应该跳过该文件"""
        if not (self.skip_exists and output_dir):
            return False

        output_file = output_dir / f"{image_path.stem}.{output_format}"
        if output_file.exists():
            logger.debug(f"跳过已存在: {output_file}")
            return True

        return False

    def _perform_ocr(
        self,
        image_path: Path,
        return_coords: bool
    ) -> tuple[Optional[List], float]:
        """执行OCR识别"""
        return self.ocr_engine.recognize(
            str(image_path),
            return_coords=return_coords,
            return_confidence=return_coords
        )

    def _save_ocr_result(
        self,
        text: str,
        image_path: Path,
        output_dir: Optional[Path],
        output_format: str,
        ocr_result: Optional[List]
    ):
        """保存OCR识别结果"""
        if not output_dir:
            return

        self.save_result(
            text,
            output_dir / f"{image_path.stem}.{output_format}",
            ocr_result
        )

    def _retry_ocr(
        self,
        image_path: Path,
        return_coords: bool
    ) -> tuple[Optional[List], float]:
        """重试OCR识别"""
        for attempt in range(self.retry):
            try:
                logger.info(f"重试 {image_path} (第{attempt + 1}次)")
                ocr_result, elapse = self.ocr_engine.recognize(
                    str(image_path),
                    return_coords=return_coords
                )

                if ocr_result:
                    return ocr_result, elapse

            except Exception as retry_error:
                logger.error(f"重试失败: {retry_error}")

        return None, 0.0

    def process_single(
        self,
        image_path: Path,
        output_dir: Optional[Path] = None,
        output_format: str = "txt",
        return_coords: bool = False,
    ) -> Dict[str, Any]:
        """
        处理单张图片

        Args:
            image_path: 图片路径
            output_dir: 输出目录
            output_format: 输出格式
            return_coords: 是否返回坐标

        Returns:
            处理结果字典
        """
        result = self._init_result(image_path)

        # 检查是否跳过
        if self._should_skip(image_path, output_dir, output_format):
            result["success"] = True
            result["skipped"] = True
            return result

        try:
            # 执行OCR识别
            ocr_result, elapse = self._perform_ocr(image_path, return_coords)

            if ocr_result is not None:
                # 提取文本
                text = self.ocr_engine.get_text_only(ocr_result)

                result["success"] = True
                result["text"] = text
                result["elapse"] = elapse
                result["line_count"] = len(ocr_result)

                # 保存到文件
                self._save_ocr_result(
                    text,
                    image_path,
                    output_dir,
                    output_format,
                    ocr_result if return_coords else None
                )

            else:
                result["error"] = "OCR识别失败"

        except Exception as e:
            logger.error(f"处理失败 {image_path}: {e}")
            result["error"] = str(e)

            # 重试
            ocr_result, elapse = self._retry_ocr(image_path, return_coords)

            if ocr_result:
                text = self.ocr_engine.get_text_only(ocr_result)
                result["success"] = True
                result["text"] = text
                result["elapse"] = elapse

        return result

    def _prepare_output_dir(self, output_dir: Optional[str]) -> Optional[Path]:
        """准备输出目录"""
        if not output_dir:
            return None

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        logger.info(f"输出目录: {output_path}")
        return output_path

    def _submit_tasks(
        self,
        executor: ThreadPoolExecutor,
        image_files: List[Path],
        output_path: Optional[Path],
        output_format: str,
        return_coords: bool
    ) -> dict:
        """提交所有任务到线程池"""
        return {
            executor.submit(
                self.process_single,
                img,
                output_path,
                output_format,
                return_coords
            ): img for img in image_files
        }

    def _process_with_progress(
        self,
        futures: dict,
        image_files: List[Path],
        progress_callback: Optional[Callable]
    ) -> List[Dict[str, Any]]:
        """处理任务并显示进度"""
        results = []

        with tqdm(total=len(image_files), desc="处理进度") as pbar:
            for future in as_completed(futures):
                result = future.result()
                results.append(result)

                # 更新进度条
                pbar.update(1)
                pbar.set_postfix({
                    "成功": sum(1 for r in results if r["success"]),
                    "失败": sum(1 for r in results if not r["success"])
                })

                # 进度回调
                if progress_callback:
                    progress_callback(result, len(results), len(image_files))

        return results

    def _log_batch_summary(self, results: List[Dict[str, Any]]):
        """记录批量处理摘要"""
        success_count = sum(1 for r in results if r["success"])
        failed_count = len(results) - success_count
        total_elapse = sum(r.get("elapse", 0) for r in results)

        logger.info(
            f"批量处理完成 - 成功: {success_count}, "
            f"失败: {failed_count}, 总耗时: {total_elapse:.2f}秒"
        )

    def process_batch(
        self,
        input_path: str,
        output_dir: Optional[str] = None,
        output_format: str = "txt",
        recursive: bool = False,
        return_coords: bool = False,
        progress_callback: Optional[Callable] = None,
    ) -> List[Dict[str, Any]]:
        """
        批量处理图片

        Args:
            input_path: 输入路径(文件或文件夹)
            output_dir: 输出目录
            output_format: 输出格式
            recursive: 是否递归处理子文件夹
            return_coords: 是否返回坐标
            progress_callback: 进度回调函数

        Returns:
            处理结果列表
        """
        # 获取所有图片文件
        image_files = self.get_image_files(input_path, recursive)

        if not image_files:
            logger.warning("没有找到图片文件")
            return []

        # 创建输出目录
        output_path = self._prepare_output_dir(output_dir)

        # 多线程处理
        results = []
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            # 提交所有任务
            futures = self._submit_tasks(
                executor,
                image_files,
                output_path,
                output_format,
                return_coords
            )

            # 处理并显示进度
            results = self._process_with_progress(
                futures,
                image_files,
                progress_callback
            )

        # 统计结果
        self._log_batch_summary(results)

        return results

    @staticmethod
    def save_result(
        text: str,
        output_path: Path,
        detailed_result: Optional[List] = None
    ):
        """
        保存识别结果到文件

        Args:
            text: 识别文本
            output_path: 输出文件路径
            detailed_result: 详细结果(用于JSON格式)
        """
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)

            if output_path.suffix == ".json":
                # JSON格式
                import json
                data = {
                    "text": text,
                    "lines": detailed_result if detailed_result else []
                }
                with open(output_path, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2)

            else:
                # 文本格式
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(text)

            logger.debug(f"已保存: {output_path}")

        except Exception as e:
            logger.error(f"保存失败 {output_path}: {e}")

    def get_summary(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        获取处理结果摘要

        Args:
            results: 处理结果列表

        Returns:
            摘要信息
        """
        total = len(results)
        success = sum(1 for r in results if r["success"])
        failed = total - success
        skipped = sum(1 for r in results if r.get("skipped", False))

        total_lines = sum(r.get("line_count", 0) for r in results)
        total_chars = sum(len(r.get("text", "")) for r in results)
        total_elapse = sum(r.get("elapse", 0) for r in results)

        summary = {
            "total_images": total,
            "successful": success,
            "failed": failed,
            "skipped": skipped,
            "total_lines": total_lines,
            "total_chars": total_chars,
            "total_elapse": round(total_elapse, 2),
            "avg_time": round(total_elapse / total, 2) if total > 0 else 0
        }

        return summary


def create_batch_processor(
    ocr_engine: OCREngine,
    threads: int = 4,
    retry: int = 2,
) -> BatchProcessor:
    """
    创建批量处理器的便捷函数

    Args:
        ocr_engine: OCR引擎
        threads: 线程数
        retry: 重试次数

    Returns:
        BatchProcessor实例
    """
    return BatchProcessor(
        ocr_engine=ocr_engine,
        threads=threads,
        retry=retry
    )
