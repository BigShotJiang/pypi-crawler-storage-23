"""
OCR工具安装配置
"""

from setuptools import setup, find_packages
from pathlib import Path

# 读取README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

# 读取requirements
requirements_file = Path(__file__).parent / "requirements.txt"
requirements = []
if requirements_file.exists():
    requirements = [
        line.strip()
        for line in requirements_file.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.startswith("#")
    ]

setup(
    name="rapid-ocr-tool",
    version="1.1.1",
    author="OCR Tool Team",
    author_email="your-email@example.com",
    description="本地轻量级OCR识别工具 - 基于RapidOCR",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/ocr-tool",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: End Users/Desktop",
        "Topic :: Scientific/Engineering :: Image Recognition",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "ocr-tool=main:cli",  # 保留完整命令以向后兼容
            "ocr=main:cli",         # 新增简短命令
        ],
    },
    include_package_data=True,
    package_data={
        "": ["config/*.yaml", "models/*.onnx"],  # 包含配置和模型文件
    },
    keywords="ocr text-recognition rapidocr paddleocr chinese english",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/ocr-tool/issues",
        "Source": "https://github.com/yourusername/ocr-tool",
        "Documentation": "https://github.com/yourusername/ocr-tool/blob/main/README.md",
    },
)
