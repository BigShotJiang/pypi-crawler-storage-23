"""
本地OCR识别工具 - 主入口
支持单张/批量图片文字识别
"""

import sys
import logging
from pathlib import Path
import click

# 添加src目录到路径
sys.path.insert(0, str(Path(__file__).parent))

from src import (
    create_ocr_engine,
    create_batch_processor,
    create_formatter,
    ImageProcessor
)

# 全局配置
USE_EMOJI = True


def _emoji(icon: str) -> str:
    """根据设置返回emoji或空字符串"""
    return icon if USE_EMOJI else ""


# 配置日志
def setup_logging(verbose: bool = False):
    """配置日志系统"""
    level = logging.DEBUG if verbose else logging.INFO

    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout)
        ]
    )


@click.group()
@click.version_option(version="1.1.1")
def cli():
    """本地轻量级OCR识别工具

    基于RapidOCR,支持中英文离线识别
    """
    pass


@cli.command()
@click.argument('image_path', type=click.Path(exists=True))
@click.option('--output', '-o', type=click.Path(), help='输出文件路径')
@click.option('--format', '-f', type=click.Choice(['txt', 'md', 'json', 'html', 'csv']),
              default='txt', help='输出格式')
@click.option('--lang', '-l', type=click.Choice(['ch', 'en']), default='ch',
              help='识别语言 (ch=中文, en=英文)')
@click.option('--gpu', is_flag=True, help='使用GPU加速')
@click.option('--coords', is_flag=True, help='包含坐标信息(仅JSON格式)')
@click.option('--verbose', '-v', is_flag=True, help='显示详细信息')
@click.option('--no-emoji', is_flag=True, help='禁用emoji表情')
def image(image_path, output, format, lang, gpu, coords, verbose, no_emoji):
    """识别单张图片

    IMAGE_PATH: 图片文件路径
    """
    global USE_EMOJI
    USE_EMOJI = not no_emoji

    setup_logging(verbose)

    click.echo(f"{_emoji('🚀')} 初始化OCR引擎 (语言: {lang}, GPU: {gpu})...")

    # 创建OCR引擎
    ocr_engine = create_ocr_engine(lang=lang, use_gpu=gpu)

    # 创建格式化器
    formatter = create_formatter()

    # 执行识别
    click.echo(f"{_emoji('📖')} 正在识别: {image_path}")
    result, elapse = ocr_engine.recognize(
        image_path,
        return_coords=coords,
        return_confidence=coords
    )

    if result is None:
        click.echo(f"{_emoji('❌')} 识别失败", err=True)
        sys.exit(1)

    if len(result) == 0:
        click.echo(f"{_emoji('⚠️')} 未识别到文字")
        return

    # 显示结果
    try:
        elapse_str = f"{elapse:.2f}" if isinstance(elapse, (int, float)) else str(elapse)
    except (TypeError, ValueError, AttributeError) as e:
        elapse_str = "未知"
        logger.debug(f"无法格式化耗时: {e}")

    click.echo(f"{_emoji('✅')} 识别成功! 耗时: {elapse_str}秒, 识别行数: {len(result) if result else 0}")

    # 打印到控制台
    formatter.print_to_console(result, format_type="json" if coords else "text")

    # 保存到文件
    if output:
        formatter.format_and_save(
            result,
            output,
            format_type=format,
            image_path=image_path,
            include_coords=coords
        )
        click.echo(f"{_emoji('💾')} 已保存到: {output}")


@cli.command()
@click.argument('input_path', type=click.Path(exists=True))
@click.option('--output', '-o', type=click.Path(), help='输出目录')
@click.option('--format', '-f', type=click.Choice(['txt', 'json', 'md']),
              default='txt', help='输出格式')
@click.option('--lang', '-l', type=click.Choice(['ch', 'en']), default='ch',
              help='识别语言')
@click.option('--threads', '-t', type=int, default=4, help='并发线程数')
@click.option('--recursive', '-r', is_flag=True, help='递归处理子文件夹')
@click.option('--gpu', is_flag=True, help='使用GPU加速')
@click.option('--skip-exists', is_flag=True, help='跳过已存在的输出文件')
@click.option('--verbose', '-v', is_flag=True, help='显示详细信息')
def batch(input_path, output, format, lang, threads, recursive, gpu,
          skip_exists, verbose):
    """批量处理图片

    INPUT_PATH: 图片文件或文件夹路径
    """
    setup_logging(verbose)

    click.echo(f"🚀 初始化OCR引擎 (语言: {lang}, GPU: {gpu})...")

    # 创建OCR引擎
    ocr_engine = create_ocr_engine(lang=lang, use_gpu=gpu)

    # 创建批量处理器
    processor = create_batch_processor(
        ocr_engine,
        threads=threads,
        skip_exists=skip_exists
    )

    # 创建格式化器
    formatter = create_formatter()

    # 执行批量处理
    click.echo(f"📂 开始批量处理: {input_path}")
    results = processor.process_batch(
        input_path=input_path,
        output_dir=output,
        output_format=format,
        recursive=recursive,
        return_coords=(format == "json")
    )

    # 显示统计
    summary = processor.get_summary(results)

    click.echo("\n" + "="*50)
    click.echo("📊 处理完成!")
    click.echo(f"  总计: {summary['total_images']} 张")
    click.echo(f"  成功: {summary['successful']} 张")
    click.echo(f"  失败: {summary['failed']} 张")
    if summary.get('skipped', 0) > 0:
        click.echo(f"  跳过: {summary['skipped']} 张")
    click.echo(f"  总行数: {summary['total_lines']} 行")
    click.echo(f"  总字符: {summary['total_chars']} 字")
    click.echo(f"  总耗时: {summary['total_elapse']} 秒")
    click.echo(f"  平均: {summary['avg_time']} 秒/张")
    click.echo("="*50)

    # 保存摘要
    if output:
        summary_path = Path(output) / "summary.txt"
        with open(summary_path, 'w', encoding='utf-8') as f:
            f.write("批量处理摘要\n")
            f.write("="*50 + "\n")
            for key, value in summary.items():
                f.write(f"{key}: {value}\n")
        click.echo(f"💾 摘要已保存: {summary_path}")


@cli.command()
@click.argument('image_path', type=click.Path(exists=True))
def info(image_path):
    """显示图片信息

    IMAGE_PATH: 图片文件路径
    """
    processor = ImageProcessor()

    image_info = processor.get_image_info(image_path)

    if image_info is None:
        click.echo("❌ 无法读取图片", err=True)
        sys.exit(1)

    click.echo("\n📷 图片信息:")
    click.echo(f"  路径: {image_info['path']}")
    click.echo(f"  尺寸: {image_info['width']} x {image_info['height']}")
    click.echo(f"  通道数: {image_info['channels']}")
    click.echo(f"  格式: {image_info['format']}")
    click.echo(f"  大小: {image_info['file_size_mb']} MB")


@cli.command()
@click.argument('image_path', type=click.Path(exists=True))
@click.option('--output', '-o', type=click.Path(), help='保存预处理后的图片')
def preprocess(image_path, output):
    """图像预处理(增强、去噪等)

    IMAGE_PATH: 图片文件路径
    """
    processor = ImageProcessor(
        max_size=2048,
        enhance_contrast=True,
        denoise=True
    )

    click.echo(f"🔧 预处理图片: {image_path}")

    result = processor.preprocess(image_path, output)

    if result is not None:
        click.echo("✅ 预处理完成")

        if output:
            click.echo(f"💾 已保存到: {output}")
    else:
        click.echo("❌ 预处理失败", err=True)
        sys.exit(1)


def main():
    """主入口"""
    cli()


if __name__ == "__main__":
    main()
