# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a lightweight offline OCR (Optical Character Recognition) tool built with RapidOCR and ONNX Runtime. It achieves 4-5x faster performance than PaddleOCR with 200MB+ lower memory usage while maintaining 99%+ accuracy.

**Core Technology Stack:**
- OCR Engine: RapidOCR (optimized PaddleOCR)
- Inference: ONNX Runtime
- Model: PP-OCRv3 lightweight model (12.3MB)
- Language: Python 3.8+

## Essential Commands

### Testing
```bash
# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_ocr_engine.py -v

# Run with coverage report
pytest tests/ --cov=src --cov-report=html

# Run single test
pytest tests/test_output_formatter.py::TestOutputFormatter::test_format_text_simple -v
```

### Running the Tool
```bash
# Single image recognition
python main.py image <image_path>

# Batch processing
python main.py batch <folder_path>

# With specific output format
python main.py image <image_path> --format json --coords

# Disable emoji output
python main.py image <image_path> --no-emoji
```

### Installation
```bash
# Install dependencies
pip install -r requirements.txt

# Run with virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows
```

## Architecture

### Module Structure

The codebase follows a modular architecture with clear separation of concerns:

**Core Modules (`src/`)**:
1. **`ocr_engine.py`** - Wraps RapidOCR, handles single/batch recognition, returns structured results with optional coordinates and confidence scores
2. **`image_processor.py`** - Preprocessing pipeline: validation, resize (max 2048px), grayscale, contrast enhancement, denoising
3. **`batch_processor.py`** - Multi-threaded batch processing using ThreadPoolExecutor, handles progress tracking and error recovery
4. **`output_formatter.py`** - Formats OCR results to multiple output types (TXT, JSON, Markdown, HTML, CSV)
5. **`constants.py`** - Centralized configuration constants (max file size, supported formats, thresholds)

**Entry Point**:
- **`main.py`** - Click-based CLI with emoji output control (global `USE_EMOJI` flag)

### Data Flow

```
Image Input → ImageProcessor (optional preprocessing) → OCREngine → Raw OCR Result → OutputFormatter → File Output
```

**OCR Result Format**: List of lists where each item is either:
- `[text]` - Simple text only
- `[[bbox], text, confidence]` - With bounding box and confidence

Example: `[[[[0,0], [10,0], [10,10], [0,10]], "Hello", 0.99], ["World"]]`

### Configuration System

Two-layer configuration:
1. **Default config** in `src/__init__.py:get_default_config()`
2. **YAML override** in `config/config.yaml` (loaded via `load_config()`)

Config merging is recursive - custom values override defaults at any depth.

### Key Design Patterns

**Factory Functions**: Each module exports a `create_*()` function for convenient instantiation:
- `create_ocr_engine(lang, use_gpu)`
- `create_image_processor(max_size, auto_rotate)`
- `create_batch_processor(ocr, threads)`
- `create_formatter(indent)`

**Text Extraction**: `OutputFormatter` uses helper methods to avoid code duplication:
- `_extract_text(line)` - Extract text from single OCR result line
- `_extract_texts(result)` - Extract all text lines using list comprehension with walrus operator

**Batch Processing**: `BatchProcessor.process_single()` was refactored from 88 lines into 6 smaller methods:
- `_init_result()` - Initialize result dictionary
- `_should_skip()` - Check if output exists (for skip_exists mode)
- `_load_and_process()` - Load and OCR image
- `_save_result()` - Save to file
- `_process_error()` - Handle errors
- Main method orchestrates the workflow

## Code Quality Standards

**Testing**: TDD methodology with RED→GREEN→REFACTOR cycle. Current test coverage: 51% (37 tests).

**Refactoring**: Code underwent TDD refactoring to eliminate duplication. Example: `OutputFormatter` reduced from 330 to 280 lines by extracting common text extraction logic.

**Error Handling**: Avoid naked `except:` clauses. Use specific exception types like `(TypeError, ValueError, AttributeError)`.

**Emoji Control**: Global `USE_EMOJI` flag in `main.py` controls emoji output. Use `_emoji()` helper function. Pass `--no-emoji` CLI flag to disable.

**Constants**: All magic numbers centralized in `src/constants.py`:
- `MAX_FILE_SIZE = 50 * 1024 * 1024` (50MB)
- `DEFAULT_MAX_IMAGE_SIZE = 2048`
- `CONFIDENCE_THRESHOLD = 0.8`

## Important Constraints

- **First Run**: Auto-downloads ONNX models (~12MB) to `./models/` directory
- **Image Size**: Automatically resized to max 2048px on longest side
- **Supported Formats**: .jpg, .jpeg, .png, .bmp, .tiff, .tif
- **Thread Safety**: BatchProcessor uses ThreadPoolExecutor with configurable thread count (default: 4)
- **File Encoding**: All file I/O uses UTF-8 encoding

## Troubleshooting

**Import Errors**: Ensure virtual environment is activated and dependencies installed via `requirements.txt`.

**Model Download Failures**: Check internet connection on first run. Models download from RapidOCR repository.

**Memory Issues**: Reduce `max_size` in config or `ImageProcessor` initialization. Lower thread count in batch processing.

**Low Accuracy**: Enable image preprocessing (contrast enhancement, denoising) or preprocess images externally before OCR.
