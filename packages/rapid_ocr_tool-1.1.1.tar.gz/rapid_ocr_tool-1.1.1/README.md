# 本地轻量级OCR识别工具

基于 RapidOCR + ONNX Runtime 的本地OCR工具,极速识别(~1秒/张)、低资源占用(<300MB)、完全离线。

## ✨ 特性

- ✅ 极速识别 (~1秒/张)
- ✅ 低资源占用 (<300MB)
- ✅ 高准确率 (中文99.5%, 英文99%+)
- ✅ 完全离线 (保护隐私)
- ✅ 批量处理 (多线程)
- ✅ 多种输出 (TXT/JSON/MD/HTML/CSV)
- ✅ 跨平台 (Windows/Linux/Mac)

## 📦 安装

```bash
pip install rapid-ocr-tool
```

## 🚀 使用

> **⚠️ 平台差异说明**:
> - **Linux/Mac**: 安装后可直接使用 `ocr` 命令
> - **Windows**: 由于系统限制无法直接使用 `ocr` 命令,需使用以下方式之一:
>   1. 使用 `python -m main` 方式(推荐,所有平台通用)
>   2. 配置 PowerShell 函数实现 `ocr` 命令(见下方)

### Linux/Mac

```bash
# 安装后直接使用简短命令
ocr image photo.jpg
ocr batch ./photos --output ./results
```

### Windows

**方式一: 通用命令** (推荐):
```powershell
python -m main image photo.jpg
python -m main batch ./photos --output ./results
```

**方式二: 配置OCR命令** (PowerShell):

1. 编辑PowerShell配置文件:
```powershell
notepad $PROFILE
```

2. 添加以下内容:
```powershell
function ocr {
    $ocrDir = "D:\z_code\code\tools\ocr"  # 改为你的路径
    if (Test-Path $ocrDir) {
        Push-Location $ocrDir
        try { python -m main @args }
        finally { Pop-Location }
    }
}
```

3. 重新加载配置:
```powershell
. $PROFILE
```

4. 现在可以直接使用:
```powershell
ocr image photo.jpg
```

## 📋 常用命令

> **💡 提示**: Windows用户请将下方命令中的 `ocr` 替换为 `python -m main`

```bash
# 识别单张图片
ocr image photo.jpg

# 批量处理
ocr batch ./photos --output ./results

# 指定输出格式
ocr image photo.jpg --format json
ocr image photo.jpg --format txt
ocr image photo.jpg --format md

# 保存结果
ocr image photo.jpg --output result.txt

# 英文识别
ocr image english.jpg --lang en

# 查看帮助
ocr --help
ocr image --help
```

## 🎯 可用命令

- `image` - 识别单张图片
- `batch` - 批量处理文件夹
- `info` - 显示图片信息
- `preprocess` - 图像预处理

## 📂 支持的格式

- PNG (.png)
- JPEG (.jpg, .jpeg)
- BMP (.bmp)
- TIFF (.tiff, .tif)

## 🔧 技术栈

- **OCR引擎**: [RapidOCR](https://github.com/RapidAI/RapidOCR)
- **推理框架**: ONNX Runtime
- **模型**: PP-OCRv3 (12.3MB)

## 📄 许可证

MIT License

## 🙏 致谢

- [RapidOCR](https://github.com/RapidAI/RapidOCR)
- [PaddleOCR](https://github.com/PaddlePaddle/PaddleOCR)
- [ONNX Runtime](https://onnxruntime.ai/)

---

**版本**: 1.1.1 | **PyPI**: [rapid-ocr-tool](https://pypi.org/project/rapid-ocr-tool/)
