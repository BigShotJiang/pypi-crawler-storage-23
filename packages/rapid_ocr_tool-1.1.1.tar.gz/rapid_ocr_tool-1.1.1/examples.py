"""
使用示例代码
展示如何使用OCR工具的各种功能
"""

from src import (
    create_ocr_engine,
    create_batch_processor,
    create_formatter,
    ImageProcessor
)


def example_single_image():
    """示例1: 识别单张图片"""
    print("\n=== 示例1: 识别单张图片 ===\n")

    # 创建OCR引擎
    ocr = create_ocr_engine(lang="ch", use_gpu=False)

    # 识别图片
    result, elapse = ocr.recognize("test.jpg")

    # 输出结果
    if result:
        text = ocr.get_text_only(result)
        print(f"识别内容:\n{text}")
        print(f"\n耗时: {elapse:.2f}秒")


def example_batch_processing():
    """示例2: 批量处理文件夹"""
    print("\n=== 示例2: 批量处理 ===\n")

    # 创建OCR引擎和批量处理器
    ocr = create_ocr_engine(lang="ch")
    processor = create_batch_processor(ocr, threads=4)

    # 批量处理
    results = processor.process_batch(
        input_path="./images",
        output_dir="./output",
        output_format="txt"
    )

    # 显示摘要
    summary = processor.get_summary(results)
    print(f"\n处理完成: {summary}")


def example_different_formats():
    """示例3: 多种输出格式"""
    print("\n=== 示例3: 不同输出格式 ===\n")

    ocr = create_ocr_engine(lang="ch")
    formatter = create_formatter()

    # 识别图片
    result, _ = ocr.recognize("test.jpg", return_coords=True)

    # 保存为不同格式
    formatter.format_and_save(result, "output.txt", format_type="txt")
    formatter.format_and_save(result, "output.json", format_type="json")
    formatter.format_and_save(result, "output.md", format_type="md")
    formatter.format_and_save(result, "output.html", format_type="html")

    print("已保存为多种格式: txt, json, md, html")


def example_image_preprocessing():
    """示例4: 图像预处理"""
    print("\n=== 示例4: 图像预处理 ===\n")

    processor = ImageProcessor(
        max_size=2048,
        enhance_contrast=True,
        denoise=True
    )

    # 获取图片信息
    info = processor.get_image_info("test.jpg")
    print(f"图片信息: {info}")

    # 预处理图片
    processed = processor.preprocess("test.jpg", "processed.jpg")
    if processed:
        print("预处理完成!")


def example_detailed_result():
    """示例5: 获取详细识别结果"""
    print("\n=== 示例5: 详细结果 ===\n")

    ocr = create_ocr_engine(lang="ch")

    # 识别(包含坐标和置信度)
    result, _ = ocr.recognize(
        "test.jpg",
        return_coords=True,
        return_confidence=True
    )

    # 获取结构化结果
    detailed = ocr.get_detailed_result(result)

    for line in detailed:
        print(f"文本: {line['text']}")
        print(f"置信度: {line['confidence']:.2f}")
        print(f"坐标: {line['bbox']}")
        print("-" * 40)


def example_custom_config():
    """示例6: 自定义配置"""
    print("\n=== 示例6: 自定义配置 ===\n")

    # 创建带自定义参数的OCR引擎
    ocr = create_ocr_engine(
        lang="ch",
        use_gpu=False,
        det_model_path=None,  # 可指定自定义模型路径
    )

    result, elapse = ocr.recognize("test.jpg")

    if result:
        print(f"识别到 {len(result)} 行文字")
        print(f"耗时: {elapse:.2f}秒")


def example_api_usage():
    """示例7: API调用方式"""
    print("\n=== 示例7: API调用 ===\n")

    from src.ocr_engine import OCREngine

    # 直接使用类
    ocr = OCREngine(lang="ch", use_gpu=False)

    # 批量识别
    image_list = ["img1.jpg", "img2.jpg", "img3.jpg"]
    results = ocr.recognize_batch(image_list)

    for img_path, (result, elapse) in zip(image_list, results):
        print(f"{img_path}: {len(result) if result else 0} 行, {elapse:.2f}秒")


if __name__ == "__main__":
    print("""
    ╔════════════════════════════════════════════════╗
    ║       本地OCR工具 - 使用示例                   ║
    ║       基于 RapidOCR + ONNX Runtime            ║
    ╚════════════════════════════════════════════════╝
    """)

    # 运行示例(需要实际的测试图片)
    # example_single_image()
    # example_batch_processing()
    # example_different_formats()
    # example_image_preprocessing()
    # example_detailed_result()
    # example_custom_config()
    # example_api_usage()

    print("\n请取消注释相应的示例代码来运行")
