read @CLAUDE.md
