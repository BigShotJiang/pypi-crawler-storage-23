#!/usr/bin/env bash

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Get the directory of this script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR/"

echo -e "${BLUE}═══════════════════════════════════════════════${NC}"
echo -e "${BLUE}   Reportify CLI - Version Bump Script${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════${NC}"
echo ""

# Check if we're in the right directory
if [ ! -f "pyproject.toml" ]; then
    echo -e "${RED}Error: pyproject.toml not found. Are you in the right directory?${NC}"
    exit 1
fi

# Extract current version from pyproject.toml
CURRENT_VERSION=$(grep '^version = ' pyproject.toml | sed 's/version = "\(.*\)"/\1/')
echo -e "${YELLOW}Current version: ${CURRENT_VERSION}${NC}"
echo ""

# Parse version components
IFS='.' read -ra VERSION_PARTS <<< "$CURRENT_VERSION"
MAJOR="${VERSION_PARTS[0]}"
MINOR="${VERSION_PARTS[1]}"
PATCH="${VERSION_PARTS[2]}"

# Determine bump type
BUMP_TYPE="${1:-patch}"

case "$BUMP_TYPE" in
    major)
        MAJOR=$((MAJOR + 1))
        MINOR=0
        PATCH=0
        ;;
    minor)
        MINOR=$((MINOR + 1))
        PATCH=0
        ;;
    patch)
        PATCH=$((PATCH + 1))
        ;;
    *)
        echo -e "${RED}Error: Invalid bump type. Use 'major', 'minor', or 'patch'${NC}"
        echo "Usage: $0 [major|minor|patch]"
        exit 1
        ;;
esac

NEW_VERSION="${MAJOR}.${MINOR}.${PATCH}"
echo -e "${GREEN}New version: ${NEW_VERSION}${NC}"
echo ""

# Confirm the change
#read -p "Bump version from ${CURRENT_VERSION} to ${NEW_VERSION}? (y/n): " CONFIRM
#if [ "$CONFIRM" != "y" ]; then
#    echo -e "${YELLOW}Version bump cancelled${NC}"
#    exit 0
#fi

# Update version in pyproject.toml
echo -e "${BLUE}Updating pyproject.toml...${NC}"
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    sed -i '' "s/^version = \".*\"/version = \"${NEW_VERSION}\"/" pyproject.toml
else
    # Linux
    sed -i "s/^version = \".*\"/version = \"${NEW_VERSION}\"/" pyproject.toml
fi
echo -e "${GREEN}✓ Updated pyproject.toml${NC}"
echo ""

# Show the diff
echo -e "${BLUE}Changes:${NC}"
git diff pyproject.toml
echo ""

# Ask if we should commit

if [ -n "$(git status --porcelain)" ]; then
    echo -e "${RED}提交版本修改记录"
    # 配置git信息
    git config --global user.name "GitLab Runner Bot"
    git config --global user.email "gitlab-runner-arm@xiaobangtouzi.com"
    git remote set-url origin "https://gitlab-ci-token:${GITLAB_PUSHER_TOKEN}@${CI_SERVER_HOST}/${CI_PROJECT_PATH}.git"
    # 提交和推送代码逻辑
    git add pyproject.toml
    git commit -am "chore: bump version to ${NEW_VERSION} [ci skip]"
    echo -e "${GREEN}✓ Changes committed${NC}"
    echo ""
    git push origin -o ci.skip HEAD:${CI_COMMIT_REF_NAME}
    echo -e "${GREEN}✓ Changes pushed to remote${NC}"
fi

if [ -n "$(git status --porcelain)" ]; then
    echo -e "${RED}Error: You have uncommitted changes. Please commit or stash them first.${NC}"
    git status --short
    exit 1
else
    echo -e "${GREEN}✓ No uncommitted changes${NC}"
fi

echo ""
echo -e "${GREEN}═══════════════════════════════════════════════${NC}"
echo -e "${GREEN}   ✓ Version Bumped Successfully!${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════${NC}"
echo ""
echo -e "Old version: ${YELLOW}${CURRENT_VERSION}${NC}"
echo -e "New version: ${GREEN}${NEW_VERSION}${NC}"
echo ""
echo -e "Next steps:"
echo -e "  1. Run tests: ${YELLOW}make test${NC}"
echo -e "  2. Publish to test PyPI: ${YELLOW}./scripts/publish.sh test${NC}"
echo -e "  3. Publish to prod PyPI: ${YELLOW}./scripts/publish.sh prod${NC}"
echo ""
