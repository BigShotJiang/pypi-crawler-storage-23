"""Tests for search crawl command."""

from unittest.mock import Mock, patch

import pytest
from typer.testing import CliRunner

from src.commands.search import app

runner = CliRunner()


@pytest.fixture
def mock_client():
    """Mock Reportify SDK client."""
    with patch("src.commands.search.get_client") as mock_get_client:
        client = Mock()
        mock_get_client.return_value = client
        yield client


class TestSearchCrawl:
    """Tests for search crawl command."""

    def test_crawl_basic(self, mock_client):
        """Test basic crawl with URLs only."""
        mock_response = {
            "results": [
                {
                    "url": "https://example.com",
                    "title": "Example Page",
                    "text": "Example content text",
                }
            ],
            "requestId": "req-123",
        }
        mock_client.search.crawl.return_value = mock_response

        result = runner.invoke(
            app, ["crawl", "--input", '{"urls": ["https://example.com"]}']
        )

        assert result.exit_code == 0
        mock_client.search.crawl.assert_called_once_with(["https://example.com"])
        assert "Example Page" in result.stdout

    def test_crawl_without_urls_should_fail(self, mock_client):
        """Test crawl without urls raises error."""
        result = runner.invoke(app, ["crawl", "--input", "{}"])

        assert result.exit_code == 1
        error_output = result.stdout + result.stderr
        assert "urls is required" in error_output

    def test_crawl_with_text_options(self, mock_client):
        """Test crawl with nested text options (maxCharacters, verbosity)."""
        mock_response = {
            "results": [
                {
                    "url": "https://example.com",
                    "title": "Example",
                    "text": "Short text",
                }
            ],
        }
        mock_client.search.crawl.return_value = mock_response

        result = runner.invoke(
            app,
            [
                "crawl",
                "--input",
                '{"urls": ["https://example.com"], "text": {"maxCharacters": 2000, "verbosity": "compact"}}',
            ],
        )

        assert result.exit_code == 0
        call_args = mock_client.search.crawl.call_args
        assert call_args[0][0] == ["https://example.com"]
        assert call_args[1]["text"] == {"maxCharacters": 2000, "verbosity": "compact"}

    def test_crawl_with_highlights_options(self, mock_client):
        """Test crawl with nested highlights options (numSentences, highlightsPerUrl)."""
        mock_response = {
            "results": [
                {
                    "url": "https://example.com",
                    "title": "Example",
                    "highlights": ["key finding 1", "key finding 2"],
                }
            ],
        }
        mock_client.search.crawl.return_value = mock_response

        result = runner.invoke(
            app,
            [
                "crawl",
                "--input",
                '{"urls": ["https://example.com"], "highlights": {"query": "key data", "numSentences": 3, "highlightsPerUrl": 2}}',
            ],
        )

        assert result.exit_code == 0
        call_args = mock_client.search.crawl.call_args
        assert call_args[1]["highlights"] == {
            "query": "key data",
            "numSentences": 3,
            "highlightsPerUrl": 2,
        }

    def test_crawl_with_summary(self, mock_client):
        """Test crawl with summary options."""
        mock_response = {
            "results": [
                {
                    "url": "https://example.com",
                    "title": "Example",
                    "summary": "This is a summary of the page.",
                }
            ],
        }
        mock_client.search.crawl.return_value = mock_response

        result = runner.invoke(
            app,
            [
                "crawl",
                "--input",
                '{"urls": ["https://example.com"], "summary": {"query": "summarize key points"}}',
            ],
        )

        assert result.exit_code == 0
        call_args = mock_client.search.crawl.call_args
        assert call_args[1]["summary"] == {"query": "summarize key points"}

    def test_crawl_with_all_options(self, mock_client):
        """Test crawl with all options combined."""
        mock_response = {
            "results": [
                {
                    "url": "https://example.com",
                    "title": "Full Crawl",
                    "text": "Full text content",
                    "highlights": ["highlight 1"],
                    "summary": "Page summary",
                }
            ],
        }
        mock_client.search.crawl.return_value = mock_response

        input_json = (
            '{"urls": ["https://example.com"], '
            '"text": {"maxCharacters": 4000, "verbosity": "full"}, '
            '"highlights": {"query": "revenue", "numSentences": 5, "highlightsPerUrl": 1}, '
            '"summary": {"query": "key points"}, '
            '"subpages": 5, '
            '"subpage_target": ["api", "docs"]}'
        )

        result = runner.invoke(app, ["crawl", "--input", input_json])

        assert result.exit_code == 0
        call_args = mock_client.search.crawl.call_args
        assert call_args[0][0] == ["https://example.com"]
        assert call_args[1]["text"] == {"maxCharacters": 4000, "verbosity": "full"}
        assert call_args[1]["highlights"]["query"] == "revenue"
        assert call_args[1]["subpages"] == 5
        assert call_args[1]["subpage_target"] == ["api", "docs"]

    def test_crawl_with_table_format(self, mock_client):
        """Test crawl with table output format."""
        mock_response = {
            "results": [
                {
                    "url": "https://example.com",
                    "title": "Example",
                    "text": "Content",
                }
            ],
        }
        mock_client.search.crawl.return_value = mock_response

        result = runner.invoke(
            app,
            [
                "crawl",
                "--input",
                '{"urls": ["https://example.com"]}',
                "--format",
                "table",
            ],
        )

        assert result.exit_code == 0
        mock_client.search.crawl.assert_called_once()
