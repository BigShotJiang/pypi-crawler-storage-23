============================================
2025-11-10 Retire governance-sigs repository
============================================

The governance-sigs repository (openstack/governance-sigs) has been merged
into the governance repository (openstack/governance). All SIGs documentation,
including sigs.yaml, archived-sigs.yaml, completed-sigs.yaml, and related
documentation files, are now located in the reference/sigs/ directory of the
governance repository.

The governance-sigs repository is hereby retired. All future updates to SIGs
documentation should be made in the governance repository.

The SIGs website (https://governance.openstack.org/sigs/) continues to be
served from the governance repository.

