==================================================
2018-02-06 Dedicate Queens Release to Shawn Pearce
==================================================

The OpenStack Technical Committee would like to dedicate Queens to the memory
of Shawn Pearce, who passed away in January.

Shawn was the founder of `Gerrit`_ which has been at the center of OpenStack's
development process since the Diablo release. Shawn's work in the space of
developer tooling and collaboration has been essential to OpenStack's growth
and success.

.. _Gerrit: https://www.gerritcodereview.com/
