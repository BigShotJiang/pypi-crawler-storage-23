========================
 Superseded Resolutions
========================

This is a list of resolutions which were superseded by more recent
resolutions.

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   *
