=========================
2018-10-18 T Release Name
=========================

As the coordinator for the T release name poll, I hereby request that the TC
allow **Train** to be added to the Release name poll for the T release.
Train does not meet the `release name criteria`_ as it is not a '*physical
or human geography*'.  The same criteria do provide for the TC to accept
additions to the poll but doesn't explain the mechanism by which it can do
that.  This is the most direct format.

Train celebrates a humorous moment in our community and is a little fun.  Based
on the `discussion`_ it could be a popular option on the poll.

.. _`release name criteria`: https://governance.openstack.org/tc/reference/release-naming.html#release-name-criteria
.. _`discussion`: http://lists.openstack.org/pipermail/openstack-dev/2018-October/135824.html

