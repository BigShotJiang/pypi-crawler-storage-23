.. _resolutions:

=============
 Resolutions
=============

When a motion does not result in a change in a reference doc, it can
be expressed as a resolution.

2025
====

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   2025*

2024
====

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   2024*

2023
====

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   2023*

2022
====

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   2022*

2021
====

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   2021*

2020
====

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   2020*

2019
====

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   2019*

2018
====

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   2018*

2017
====

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   2017*

2016
====

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   2016*

2015
====

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   2015*

2014
====

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   2014*

2013
====

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   2013*
