======
 Tags
======

.. warning::

   The tags framework has been removed and we no longer maintain it. Instead,
   we encourage projects to continue following the policies they were adhering
   to with the tag framework, for example, deprecation, upgrade, stable branch,
   VMT, etc.
