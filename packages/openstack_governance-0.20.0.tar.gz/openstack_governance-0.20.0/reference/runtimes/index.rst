========================
 Release based Runtimes
========================

OpenStack is tested with certain runtimes and expected to work there.  For
more details about what this means, refer to the
:ref:`Project Testing Interface tested runtimes <pti-tested-runtimes>`.

Below are the specific runtimes per release.

..
   TODO: The list below breaks with the 3000.1 release.

.. toctree::
   :maxdepth: 1
   :glob:
   :reversed:

   [stuvwxyz]*
   2*
