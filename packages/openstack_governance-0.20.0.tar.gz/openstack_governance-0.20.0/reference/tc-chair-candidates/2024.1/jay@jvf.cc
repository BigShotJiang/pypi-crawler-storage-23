Hi,

I am the departing vice-chair for 2024.1 and am self-nominating for TC chair.
I am willing to serve as chair for the 2024.1 cycle.

Thanks,
Jay Faulkner
