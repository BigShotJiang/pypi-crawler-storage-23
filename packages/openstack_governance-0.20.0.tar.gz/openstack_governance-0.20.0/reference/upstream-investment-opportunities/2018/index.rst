:orphan:

========================================
 2018 Upstream Investment Opportunities
========================================

.. note::

    This page links to the items from the previous "Help Most Wanted" list,
    which are retained here for reference. We are in the process of rewriting
    these items in the form of upstream investment opportunities for 2019.
    Please refer to the :doc:`../index` page for the latest information.

.. toctree::
    :glob:
    :maxdepth: 1
    :titlesonly:

    *
