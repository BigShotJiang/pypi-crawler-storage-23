.. _tc-repos:

============================================================
Repositories maintained by the OpenStack Technical Committee
============================================================

.. datatemplate:yaml::
   :source: technical-committee-repos.yaml
   :template: ../../templates/technical_committee_repos_table.tmpl
