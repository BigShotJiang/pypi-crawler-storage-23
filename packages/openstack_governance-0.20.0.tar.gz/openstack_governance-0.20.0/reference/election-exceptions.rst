================================
 TC and PTL Elections exceptions
================================

TC and PTL elections period is defined in TC charter but sometime
due to various reason if we are not able to follow the defined
period or process, we will be recording that as exceptions in this
document.

TC Election
===========

2020 Sept term election
-----------------------
TC elections for 4 seats in Sept 2020 term is late
by ~4 weeks. Election is scheduled to be held between
6th to 13th Oct 2020(R1-R0 week).

2022 Aug term election
----------------------
TC elections for 4 seats in Aug 2022 term is late
by ~1 week. Election is scheduled to be held between
7th to 14th Sept 2022(R4-R3 week).

PTL Election
============

Wallaby cycle election
----------------------
PTL elections for Wallaby cycle in Sept 2020 is late
by ~3 weeks. Election is scheduled to be held between
6th to 13th Oct 2020(R1-R0 week).

2023.1(Antelope) cycle election
-------------------------------
PTL elections for 2023.1(Antelope) cycle in Aug 2022
term is late by 1 week. Election is scheduled to be
held between 7th to 14th Sept 2022(R4-R3 week).

