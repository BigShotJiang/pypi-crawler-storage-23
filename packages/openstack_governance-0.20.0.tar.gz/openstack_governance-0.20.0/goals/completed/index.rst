===============
Completed goals
===============

.. toctree::
   :glob:
   :maxdepth: 2
   :reversed:

   */index
