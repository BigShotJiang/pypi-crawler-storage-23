from mxlpy import Model


def add_transaldolase_f6p_e4p_s7p_gap() -> Model:
    raise NotImplementedError
