---
name: New Encoding Request
about: Request implementation of a specific quantum encoding
title: "[Encoding] "
labels: encoding-request
---

**Encoding Name**
<!-- The name of the encoding -->

**Reference**
<!-- Paper or source describing the encoding (DOI or arXiv link preferred) -->

**Description**
<!-- Brief description of how the encoding works -->

**Why should it be included?**
<!-- What makes this encoding useful or interesting -->
