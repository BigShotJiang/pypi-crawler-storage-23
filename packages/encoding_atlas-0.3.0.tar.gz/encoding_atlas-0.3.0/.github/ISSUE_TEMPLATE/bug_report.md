---
name: Bug Report
about: Report a bug in encoding-atlas
title: "[Bug] "
labels: bug
---

**Describe the bug**
<!-- A clear description of what the bug is -->

**To Reproduce**
```python
# Minimal code to reproduce the issue
from encoding_atlas import ...
```

**Expected behavior**
<!-- What you expected to happen -->

**Actual behavior**
<!-- What actually happened (include error messages/tracebacks) -->

**Environment**
- encoding-atlas version: <!-- pip show encoding-atlas -->
- Python version: <!-- python --version -->
- OS:
- Backend: <!-- pennylane/qiskit/cirq -->
