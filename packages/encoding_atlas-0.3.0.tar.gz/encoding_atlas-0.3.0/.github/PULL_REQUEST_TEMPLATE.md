## Summary

<!-- Brief description of what this PR does -->

## Changes

<!-- List the specific changes made -->
-
-

## Type of Change

- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] New encoding (adds a new quantum encoding implementation)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update
- [ ] CI/CD change
- [ ] Refactoring (no functional changes)

## Testing

- [ ] Tests pass locally (`pytest`)
- [ ] New tests added for new functionality
- [ ] Coverage threshold maintained (>=80%)

## Checklist

- [ ] Code follows the project style guide (ran `ruff check` and `black`)
- [ ] Type hints added/updated (`mypy` passes)
- [ ] Documentation updated (if applicable)
- [ ] CHANGELOG.md updated (for user-facing changes)
