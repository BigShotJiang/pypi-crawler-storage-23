---
title: Quantum Encoding Atlas
description: A comprehensive Python library for quantum data encodings in machine learning
template: home.html
hide:
  - navigation
  - toc
  - footer
---
