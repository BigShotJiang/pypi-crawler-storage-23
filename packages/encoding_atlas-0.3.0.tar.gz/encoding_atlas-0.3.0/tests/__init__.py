"""Tests for encoding_atlas."""
