"""Tests for the encoding guide (recommender) module."""
