"""Encoding tests."""
