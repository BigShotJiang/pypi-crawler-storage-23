# Examples

Usage examples for the Quantum Encoding Atlas library.

## Contents

- `01_basic_usage.py` - Getting started with encodings
- `02_comparing_encodings.py` - Comparing different encodings
- `03_encoding_properties.py` - Analyzing encoding properties
- `04_custom_encoding.py` - Creating custom encodings
- `05_benchmark_study.py` - Running benchmarks
- `06_decision_guide.py` - Using the recommender
- `07_cross_framework.py` - Multi-backend usage
