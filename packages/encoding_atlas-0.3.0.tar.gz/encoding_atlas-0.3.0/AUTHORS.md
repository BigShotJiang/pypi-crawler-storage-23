# Authors and Contributors

## Core Team

- **Ashutosh Mishra** - *Project Lead* - [GitHub](https://github.com/ashutoshm1771)

## Contributors

We thank all contributors who have helped improve this project!

<!-- Contributors will be listed here as they contribute -->

## How to Contribute

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines on how to contribute to this project.

## Acknowledgments

This project builds on the foundational work of many researchers and developers in the quantum computing community. We especially thank:

- The PennyLane team at Xanadu
- The Qiskit team at IBM
- The Cirq team at Google
- The broader quantum machine learning research community

## Academic Collaborators

<!-- List any academic collaborators here -->
