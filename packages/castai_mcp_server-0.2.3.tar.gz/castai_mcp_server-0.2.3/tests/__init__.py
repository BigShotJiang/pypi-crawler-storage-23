"""Tests for CAST.AI External MCP Server."""
