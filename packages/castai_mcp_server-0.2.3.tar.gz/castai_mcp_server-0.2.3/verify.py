#!/usr/bin/env python3
"""
Quick verification script to check the MCP server configuration.
This does NOT require an API key - it just checks the structure.
"""

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

print("=" * 60)
print("CAST.AI External MCP Server - Verification")
print("=" * 60)

# Check imports
print("\n1. Checking imports...")
try:
    from src.logger import logger
    print("   ✅ logger imported")
    from src.config import API_BASE_URL
    print("   ✅ config imported")
    from src.client import get_headers
    print("   ✅ client imported")
    from src.cache import resolve_cluster_id
    print("   ✅ cache imported")
    from src.tools.clusters import register_cluster_tools
    print("   ✅ clusters tools imported")
except ImportError as e:
    print(f"   ❌ Import error: {e}")
    sys.exit(1)

# Check configuration
print("\n2. Checking configuration...")
print(f"   API Base URL: {API_BASE_URL}")

from src.config import API_KEY
if API_KEY:
    print(f"   API Key: {'*' * 20} (configured)")
else:
    print("   API Key: Not configured (this is OK for verification)")

# Check tool registration
print("\n3. Checking tool registration...")
from fastmcp import FastMCP
mcp = FastMCP("CAST.AI-Test")
register_cluster_tools(mcp)

# Count registered tools
tool_count = len([item for item in dir(mcp) if not item.startswith('_')])
print(f"   ✅ Tools registered successfully")

# List the tool names
print("\n4. Available tools:")
import inspect
from src.tools import clusters
for name, obj in inspect.getmembers(clusters):
    if inspect.iscoroutinefunction(obj) and not name.startswith('_'):
        print(f"   • {name}")

print("\n5. Dependencies:")
try:
    import fastmcp
    print(f"   ✅ fastmcp {fastmcp.__version__}")
except:
    print("   ❌ fastmcp not found")

try:
    import httpx
    print(f"   ✅ httpx {httpx.__version__}")
except:
    print("   ❌ httpx not found")

try:
    import pydantic
    print(f"   ✅ pydantic {pydantic.__version__}")
except:
    print("   ❌ pydantic not found")

print("\n" + "=" * 60)
print("Verification complete!")
print("=" * 60)
print("\nNext steps:")
print("1. Set CASTAI_API_KEY environment variable")
print("2. Run: export CASTAI_API_KEY='your-key-here'")
print("3. Test: uv run python main.py")
print("=" * 60)
