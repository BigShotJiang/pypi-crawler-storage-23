from opticedge_types.enums.card import GradingType

ON_DEMAND_ELIGIBLE_GRADING_TYPES = {
    GradingType.DEEP_2024,
    GradingType.DEEP,
    GradingType.INSTANT,
    GradingType.DEEP_INSTANT
}

POST_GRADING_ELIGIBLE_GRADING_TYPES = {
    GradingType.DEEP,
    GradingType.INSTANT,
    GradingType.DEEP_INSTANT
}
