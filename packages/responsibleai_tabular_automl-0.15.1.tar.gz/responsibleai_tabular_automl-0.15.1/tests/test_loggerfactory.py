# Copyright (c) Microsoft Corporation
# Licensed under the MIT License.
"""Tests for _loggerfactory.py track_python_environment method."""
import json
import logging


class TestTrackPythonEnvironment:
    """Tests for the track_python_environment method in _LoggerFactory."""

    def test_track_python_environment_logs_packages(self):
        """Verify track_python_environment captures installed packages.

        This tests the fix for pkg_resources -> importlib.metadata migration
        which was causing import failures in Python 3.10+ environments.
        """
        from responsibleai_tabular_automl._loggerfactory import (
            _LoggerFactory,
            ActivityLoggerAdapter,
        )

        logger = logging.getLogger('test_track_env')
        logger.setLevel(logging.INFO)

        # Intercept ActivityLoggerAdapter to capture the payload
        captured_payload = {}
        original_init = ActivityLoggerAdapter.__init__

        def capture_init(self, logger, extra):
            captured_payload.update(extra)
            original_init(self, logger, extra)

        ActivityLoggerAdapter.__init__ = capture_init
        try:
            _LoggerFactory.track_python_environment(logger)
        finally:
            ActivityLoggerAdapter.__init__ = original_init

        # Verify python_environment was captured
        assert 'python_environment' in captured_payload

        # Verify it's valid JSON
        payload = json.loads(captured_payload['python_environment'])
        assert isinstance(payload, dict)

        # Should have packages installed
        assert len(payload) > 0

        # Check for known packages that must be present
        assert 'responsibleai' in payload, \
            f"responsibleai not found in: {list(payload.keys())[:20]}"

    def test_track_python_environment_no_none_keys(self):
        """Verify no None keys appear in the package dictionary."""
        from responsibleai_tabular_automl._loggerfactory import (
            _LoggerFactory,
            ActivityLoggerAdapter,
        )

        logger = logging.getLogger('test_no_none')
        logger.setLevel(logging.INFO)

        captured_payload = {}
        original_init = ActivityLoggerAdapter.__init__

        def capture_init(self, logger, extra):
            captured_payload.update(extra)
            original_init(self, logger, extra)

        ActivityLoggerAdapter.__init__ = capture_init
        try:
            _LoggerFactory.track_python_environment(logger)
        finally:
            ActivityLoggerAdapter.__init__ = original_init

        payload = json.loads(captured_payload['python_environment'])

        # No None keys should exist
        assert None not in payload
        # All keys should be non-empty strings
        for key in payload:
            assert isinstance(key, str)
            assert len(key) > 0

    def test_track_python_environment_valid_versions(self):
        """Verify all package versions are valid strings."""
        from responsibleai_tabular_automl._loggerfactory import (
            _LoggerFactory,
            ActivityLoggerAdapter,
        )

        logger = logging.getLogger('test_versions')
        logger.setLevel(logging.INFO)

        captured_payload = {}
        original_init = ActivityLoggerAdapter.__init__

        def capture_init(self, logger, extra):
            captured_payload.update(extra)
            original_init(self, logger, extra)

        ActivityLoggerAdapter.__init__ = capture_init
        try:
            _LoggerFactory.track_python_environment(logger)
        finally:
            ActivityLoggerAdapter.__init__ = original_init

        payload = json.loads(captured_payload['python_environment'])

        # All versions should be strings
        for name, version in payload.items():
            assert isinstance(version, str), \
                f"Version for {name} is not a string: {version}"
