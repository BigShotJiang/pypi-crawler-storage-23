"""Module vantage-agent.vantage_agent."""

from importlib.metadata import version

__version__ = version('vantage-agent')