"""
Gevety API Client

HTTP client for interacting with the Gevety Health API.
Handles authentication, caching, and error handling.
"""

import logging
from typing import Any, Optional

import httpx
from pydantic import BaseModel

logger = logging.getLogger(__name__)


# Response models (mirror the API schemas)


class BiomarkerInfo(BaseModel):
    canonical_name: str
    aliases: list[str] = []
    category: Optional[str] = None
    test_count: int
    latest_test_date: str
    unit: str


class WearableDevice(BaseModel):
    source: str
    device_model: Optional[str] = None
    is_active: bool
    last_sync: Optional[str] = None
    connected_at: str


class WearableStats(BaseModel):
    connected_devices: list[WearableDevice] = []
    metrics_available: list[str] = []
    date_range: Optional[dict[str, str]] = None
    total_days_of_data: int = 0


class InsightsAvailable(BaseModel):
    healthspan_score: bool = False
    healthspan_score_value: Optional[float] = None
    healthspan_status: Optional[str] = None
    opportunities_count: int = 0
    axis_scores_available: list[str] = []


class ListAvailableDataResponse(BaseModel):
    biomarkers: list[BiomarkerInfo] = []
    wearables: WearableStats = WearableStats()
    insights: InsightsAvailable = InsightsAvailable()
    data_coverage: float = 0.0
    last_lab_upload: Optional[str] = None
    total_biomarkers_tracked: int = 0
    total_test_results: int = 0


class AxisScore(BaseModel):
    axis: str
    score: float
    status: str
    data_completeness: float = 0.0
    top_biomarkers: list[dict[str, Any]] = []


class TopConcern(BaseModel):
    biomarker: str
    axis: str
    impact: float
    current_value: Optional[float] = None
    unit: Optional[str] = None
    status: str


class HealthSummaryResponse(BaseModel):
    overall_score: Optional[float] = None
    overall_status: Optional[str] = None
    trend: Optional[str] = None
    axis_scores: list[AxisScore] = []
    top_concerns: list[TopConcern] = []
    total_biomarkers: int = 0
    last_test_date: Optional[str] = None
    computed_at: Optional[str] = None


class BiomarkerDataPoint(BaseModel):
    test_date: str
    value: float
    unit: str
    flag: Optional[str] = None
    reference_low: Optional[float] = None
    reference_high: Optional[float] = None
    source: str = "pdf"


class BiomarkerTrend(BaseModel):
    direction: str
    percent_change: Optional[float] = None
    data_points: int


class QueryBiomarkerResponse(BaseModel):
    canonical_name: str
    category: Optional[str] = None
    unit: str
    history: list[BiomarkerDataPoint] = []
    latest: Optional[BiomarkerDataPoint] = None
    trend: Optional[BiomarkerTrend] = None
    optimal_range: Optional[dict[str, float]] = None


class DailyMetrics(BaseModel):
    metric_date: str
    steps: Optional[int] = None
    resting_hr: Optional[int] = None
    hrv: Optional[float] = None
    sleep_duration_hours: Optional[float] = None
    sleep_score: Optional[int] = None
    recovery_score: Optional[int] = None
    active_calories: Optional[float] = None
    source: Optional[str] = None  # May be omitted if aggregated from multiple sources


class MetricSummary(BaseModel):
    metric: str
    average: Optional[float] = None
    min: Optional[float] = None
    max: Optional[float] = None
    data_points: int = 0
    trend: Optional[str] = None


class WearableStatsResponse(BaseModel):
    connected_sources: list[str] = []
    date_range: Optional[dict[str, str]] = None
    daily_metrics: list[DailyMetrics] = []
    summaries: list[MetricSummary] = []
    total_days: int = 0


# Phase 2a Response Models


class OpportunityItem(BaseModel):
    biomarker: str
    axis: str
    current_value: Optional[float] = None
    optimal_value: Optional[float] = None
    unit: Optional[str] = None
    opportunity_score: float
    years_estimate: Optional[float] = None
    status: str
    priority: int


class GetOpportunitiesResponse(BaseModel):
    opportunities: list[OpportunityItem] = []
    total_opportunity_score: Optional[float] = None
    total_years_estimate: Optional[float] = None
    healthspan_score: Optional[float] = None
    computed_at: Optional[str] = None


class BiomarkerContribution(BaseModel):
    biomarker: str
    value: float
    unit: str
    contribution: str  # "aging" or "protective"


class BiologicalAgeResult(BaseModel):
    biological_age: float
    chronological_age: float
    age_acceleration: float
    algorithm: str
    biomarkers_used: list[BiomarkerContribution] = []
    interpretation: Optional[str] = None


class GetBiologicalAgeResponse(BaseModel):
    result: Optional[BiologicalAgeResult] = None
    available: bool = False
    reason: Optional[str] = None
    upgrade_available: bool = False
    upgrade_message: Optional[str] = None


class SupplementItem(BaseModel):
    id: int
    name: str
    amount: Optional[str] = None
    unit: Optional[str] = None
    frequency: Optional[str] = None
    is_active: bool
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    duration_days: Optional[int] = None
    note: Optional[str] = None


class ListSupplementsResponse(BaseModel):
    supplements: list[SupplementItem] = []
    active_count: int = 0
    total_count: int = 0


class ActivityItem(BaseModel):
    id: int
    activity_type: str
    name: Optional[str] = None
    start_time: str
    duration_minutes: Optional[float] = None
    distance_km: Optional[float] = None
    calories: Optional[int] = None
    avg_hr: Optional[int] = None
    max_hr: Optional[int] = None
    source: str


class GetActivitiesResponse(BaseModel):
    activities: list[ActivityItem] = []
    total_count: int = 0
    total_duration_minutes: Optional[float] = None
    total_distance_km: Optional[float] = None
    total_calories: Optional[int] = None


# Phase 2b Response Models


class TodayActionItem(BaseModel):
    action_id: int
    title: str
    action_type: str
    completed: bool
    scheduled_window: Optional[str] = None
    dose_text: Optional[str] = None


class GetTodayActionsResponse(BaseModel):
    effective_date: str
    timezone: str
    window_start: str  # ISO datetime
    window_end: str  # ISO datetime
    actions: list[TodayActionItem] = []
    completed_count: int = 0
    total_count: int = 0
    completion_pct: float = 0.0
    last_updated_at: str  # ISO datetime


class ProtocolPriorityItem(BaseModel):
    priority_id: int
    rank: int
    biomarker: str
    status: str
    target: Optional[str] = None
    last_value: Optional[float] = None
    unit: Optional[str] = None
    measured_at: Optional[str] = None
    why_prioritized: str = ""


class GetProtocolResponse(BaseModel):
    protocol_id: int
    phase: str
    days_remaining: int
    generated_at: str  # ISO datetime
    last_updated_at: str  # ISO datetime
    top_priorities: list[ProtocolPriorityItem] = []
    key_recommendations: list[str] = []
    total_actions: int = 0


# Phase 2c Response Models


class UpcomingTestItem(BaseModel):
    test_id: str
    name: str
    source: str  # "panel" | "ai"
    urgency: str  # "overdue" | "due_soon" | "recommended"
    due_date: Optional[str] = None
    days_until_due: Optional[int] = None
    due_reason: str
    biomarkers: list[str] = []


class GetUpcomingTestsResponse(BaseModel):
    tests: list[UpcomingTestItem] = []
    overdue_count: int = 0
    due_soon_count: int = 0
    ai_recommended_count: int = 0
    total_count: int = 0
    last_updated_at: str  # ISO datetime


# Phase 3 Response Models


class TestReportItem(BaseModel):
    report_id: int
    report_date: str
    source: str
    lab_name: Optional[str] = None
    biomarker_count: int = 0
    filename: Optional[str] = None


class ListTestResultsResponse(BaseModel):
    reports: list[TestReportItem] = []
    total_reports: int = 0


class StatusCounts(BaseModel):
    optimal: int = 0
    suboptimal: int = 0
    high: int = 0
    low: int = 0
    critical_high: int = 0
    critical_low: int = 0
    unknown: int = 0


class BiomarkerSummaryItem(BaseModel):
    name: str
    category: Optional[str] = None
    latest_value: float
    unit: str
    status: str
    last_test_date: str
    trend_direction: Optional[str] = None


class ListAllBiomarkersResponse(BaseModel):
    biomarkers: list[BiomarkerSummaryItem] = []
    total_count: int = 0
    counts_by_status: StatusCounts = StatusCounts()


class ContentRecommendationItem(BaseModel):
    content_id: int
    title: str
    summary: str
    category: Optional[str] = None
    relevance_reason: str
    quality_score: Optional[float] = None
    url: Optional[str] = None


class GetContentRecommendationsResponse(BaseModel):
    recommendations: list[ContentRecommendationItem] = []
    total_available: int = 0


class GevetyError(Exception):
    """Error from Gevety API."""

    def __init__(
        self,
        message: str,
        code: str,
        status_code: int = 500,
        suggestion: Optional[str] = None,
        did_you_mean: Optional[list[str]] = None,
    ):
        self.message = message
        self.code = code
        self.status_code = status_code
        self.suggestion = suggestion  # User-actionable hint
        self.did_you_mean = did_you_mean or []  # Alternative suggestions
        super().__init__(message)


class GevetyClient:
    """
    HTTP client for Gevety Health API.

    Handles authentication with bearer token and provides
    typed methods for each MCP tool endpoint.
    """

    # Production URL (gevety.com API)
    DEFAULT_BASE_URL = "https://api.gevety.com"

    def __init__(
        self,
        api_token: str,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ):
        """
        Initialize the Gevety API client.

        Args:
            api_token: Gevety API token (gvt_xxx)
            base_url: API base URL (defaults to production)
            timeout: Request timeout in seconds
        """
        self.api_token = api_token
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout

        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {api_token}",
                "Content-Type": "application/json",
                "User-Agent": "gevety-mcp/0.1.0",
            },
            timeout=httpx.Timeout(timeout),
        )

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> "GevetyClient":
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()

    def _handle_error(self, response: httpx.Response) -> None:
        """Handle error responses from the API."""
        if response.is_success:
            return

        # Check for redirect to wrong domain (common misconfiguration)
        final_url = str(response.url)
        if "gevety.com" in final_url and "api.gevety.com" not in final_url:
            raise GevetyError(
                message="API request was redirected to the wrong domain",
                code="redirect_error",
                status_code=response.status_code,
                suggestion=(
                    "Set GEVETY_API_URL=https://api.gevety.com in your MCP config. "
                    "The default URL may have been redirected incorrectly."
                ),
            )

        # Handle 404 specifically with helpful message
        if response.status_code == 404:
            raise GevetyError(
                message="API endpoint not found",
                code="not_found",
                status_code=404,
                suggestion=(
                    f"Check that GEVETY_API_URL is set correctly. "
                    f"Current URL: {self.base_url}. "
                    f"Expected: https://api.gevety.com"
                ),
            )

        try:
            error_data = response.json()
            detail = error_data.get("detail", {})

            if isinstance(detail, dict):
                raise GevetyError(
                    message=detail.get("message", "Unknown error"),
                    code=detail.get("code", "unknown_error"),
                    status_code=response.status_code,
                    suggestion=detail.get("suggestion"),  # User-actionable hint
                    did_you_mean=detail.get("did_you_mean", []),  # Alternatives
                )
            else:
                raise GevetyError(
                    message=str(detail),
                    code="unknown_error",
                    status_code=response.status_code,
                )
        except (KeyError, ValueError, GevetyError):
            # Re-raise GevetyError, handle other exceptions
            if isinstance(response.status_code, int) and response.status_code >= 400:
                raise GevetyError(
                    message=response.text or "Unknown error",
                    code="unknown_error",
                    status_code=response.status_code,
                )
            raise

    def _log_cache_headers(self, response: httpx.Response) -> None:
        """Log cache-related headers for debugging."""
        cache_hit = response.headers.get("X-Gevety-Cache-Hit")
        data_age = response.headers.get("X-Gevety-Data-Age")

        if cache_hit:
            logger.debug(f"Cache: hit={cache_hit}, age={data_age}s")

    async def list_available_data(self) -> ListAvailableDataResponse:
        """
        List available health data.

        Returns summary of biomarkers, wearables, and insights
        available for the authenticated user.
        """
        response = await self._client.get("/api/v1/mcp/tools/list_available_data")
        self._handle_error(response)
        self._log_cache_headers(response)

        return ListAvailableDataResponse.model_validate(response.json())

    async def get_health_summary(self) -> HealthSummaryResponse:
        """
        Get overall health status summary.

        Returns healthspan score, axis scores, and top concerns.
        """
        response = await self._client.get("/api/v1/mcp/tools/get_health_summary")
        self._handle_error(response)
        self._log_cache_headers(response)

        return HealthSummaryResponse.model_validate(response.json())

    async def query_biomarker(
        self,
        biomarker: str,
        days: int = 365,
    ) -> QueryBiomarkerResponse:
        """
        Query a specific biomarker by name.

        Args:
            biomarker: Biomarker name or alias (e.g., "vitamin d", "ldl")
            days: Number of days of history to retrieve (1-730)

        Returns:
            Biomarker history, trend analysis, and current status.
        """
        response = await self._client.get(
            "/api/v1/mcp/tools/query_biomarker",
            params={"biomarker": biomarker, "days": days},
        )
        self._handle_error(response)
        self._log_cache_headers(response)

        return QueryBiomarkerResponse.model_validate(response.json())

    async def get_wearable_stats(
        self,
        days: int = 30,
        metric: Optional[str] = None,
    ) -> WearableStatsResponse:
        """
        Get wearable-derived health statistics.

        Args:
            days: Number of days of history (1-90)
            metric: Optional specific metric to focus on

        Returns:
            Daily metrics, summaries, and trend analysis.
        """
        params: dict[str, Any] = {"days": days}
        if metric:
            params["metric"] = metric

        response = await self._client.get(
            "/api/v1/mcp/tools/get_wearable_stats",
            params=params,
        )
        self._handle_error(response)
        self._log_cache_headers(response)

        return WearableStatsResponse.model_validate(response.json())

    async def get_opportunities(
        self,
        limit: int = 10,
        axis: Optional[str] = None,
    ) -> GetOpportunitiesResponse:
        """
        Get health improvement opportunities.

        Args:
            limit: Maximum opportunities to return (1-50)
            axis: Optional filter by health axis

        Returns:
            Ranked opportunities with healthspan impact.
        """
        params: dict[str, Any] = {"limit": limit}
        if axis:
            params["axis"] = axis

        response = await self._client.get(
            "/api/v1/mcp/tools/get_opportunities",
            params=params,
        )
        self._handle_error(response)
        self._log_cache_headers(response)

        return GetOpportunitiesResponse.model_validate(response.json())

    async def get_biological_age(self) -> GetBiologicalAgeResponse:
        """
        Get biological age calculation.

        Returns biological age, age acceleration, and contributing factors.
        """
        response = await self._client.get("/api/v1/mcp/tools/get_biological_age")
        self._handle_error(response)
        self._log_cache_headers(response)

        return GetBiologicalAgeResponse.model_validate(response.json())

    async def list_supplements(
        self,
        active_only: bool = False,
    ) -> ListSupplementsResponse:
        """
        Get user's supplement stack.

        Args:
            active_only: Only show currently active supplements

        Returns:
            List of supplements with dosage and duration.
        """
        params: dict[str, Any] = {"active_only": active_only}

        response = await self._client.get(
            "/api/v1/mcp/tools/list_supplements",
            params=params,
        )
        self._handle_error(response)
        self._log_cache_headers(response)

        return ListSupplementsResponse.model_validate(response.json())

    async def get_activities(
        self,
        days: int = 30,
        activity_type: Optional[str] = None,
    ) -> GetActivitiesResponse:
        """
        Get workout/activity history.

        Args:
            days: Number of days of history (1-90)
            activity_type: Optional filter by activity type

        Returns:
            List of activities with metrics.
        """
        params: dict[str, Any] = {"days": days}
        if activity_type:
            params["activity_type"] = activity_type

        response = await self._client.get(
            "/api/v1/mcp/tools/get_activities",
            params=params,
        )
        self._handle_error(response)
        self._log_cache_headers(response)

        return GetActivitiesResponse.model_validate(response.json())

    async def get_today_actions(
        self,
        timezone: str = "UTC",
    ) -> GetTodayActionsResponse:
        """
        Get today's action checklist.

        Args:
            timezone: IANA timezone (e.g., "America/New_York")

        Returns:
            Actions due today with completion status.
        """
        params: dict[str, Any] = {"timezone": timezone}

        response = await self._client.get(
            "/api/v1/mcp/tools/get_today_actions",
            params=params,
        )
        self._handle_error(response)
        self._log_cache_headers(response)

        return GetTodayActionsResponse.model_validate(response.json())

    async def get_protocol(self) -> GetProtocolResponse:
        """
        Get health protocol with priorities.

        Returns:
            90-day protocol with top priorities and recommendations.
        """
        response = await self._client.get("/api/v1/mcp/tools/get_protocol")
        self._handle_error(response)
        self._log_cache_headers(response)

        return GetProtocolResponse.model_validate(response.json())

    async def get_upcoming_tests(
        self,
        days_ahead: int = 30,
    ) -> GetUpcomingTestsResponse:
        """
        Get upcoming tests that are due or recommended.

        Args:
            days_ahead: How many days ahead to check (1-90)

        Returns:
            Tests due with urgency levels.
        """
        params: dict[str, Any] = {"days_ahead": days_ahead}

        response = await self._client.get(
            "/api/v1/mcp/tools/get_upcoming_tests",
            params=params,
        )
        self._handle_error(response)
        self._log_cache_headers(response)

        return GetUpcomingTestsResponse.model_validate(response.json())

    async def list_test_results(
        self,
        limit: int = 10,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> ListTestResultsResponse:
        """
        List lab reports with dates, source, and biomarker count.

        Args:
            limit: Maximum reports to return (1-50)
            start_date: Optional start date filter (YYYY-MM-DD)
            end_date: Optional end date filter (YYYY-MM-DD)

        Returns:
            Lab reports sorted by date with biomarker counts.
        """
        params: dict[str, Any] = {"limit": limit}
        if start_date:
            params["start_date"] = start_date
        if end_date:
            params["end_date"] = end_date

        response = await self._client.get(
            "/api/v1/mcp/tools/list_test_results",
            params=params,
        )
        self._handle_error(response)
        self._log_cache_headers(response)

        return ListTestResultsResponse.model_validate(response.json())

    async def list_all_biomarkers(
        self,
        category: Optional[str] = None,
        status: Optional[str] = None,
    ) -> ListAllBiomarkersResponse:
        """
        Get all biomarkers with current value, status, and trend.

        Args:
            category: Optional filter by biomarker category
            status: Optional filter by status

        Returns:
            All biomarkers with latest values and classification.
        """
        params: dict[str, Any] = {}
        if category:
            params["category"] = category
        if status:
            params["status"] = status

        response = await self._client.get(
            "/api/v1/mcp/tools/list_all_biomarkers",
            params=params,
        )
        self._handle_error(response)
        self._log_cache_headers(response)

        return ListAllBiomarkersResponse.model_validate(response.json())

    async def get_content_recommendations(
        self,
        limit: int = 5,
        category: Optional[str] = None,
    ) -> GetContentRecommendationsResponse:
        """
        Get personalized health content recommendations.

        Args:
            limit: Maximum recommendations to return (1-20)
            category: Optional filter by content category

        Returns:
            Ranked content recommendations with relevance explanations.
        """
        params: dict[str, Any] = {"limit": limit}
        if category:
            params["category"] = category

        response = await self._client.get(
            "/api/v1/mcp/tools/get_content_recommendations",
            params=params,
        )
        self._handle_error(response)
        self._log_cache_headers(response)

        return GetContentRecommendationsResponse.model_validate(response.json())
