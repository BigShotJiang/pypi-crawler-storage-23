# Gevety MCP Skills

Reserved for future skill definitions.
