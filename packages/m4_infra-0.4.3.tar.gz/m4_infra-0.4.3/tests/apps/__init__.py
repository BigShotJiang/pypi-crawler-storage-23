"""Tests for M4 MCP apps."""
