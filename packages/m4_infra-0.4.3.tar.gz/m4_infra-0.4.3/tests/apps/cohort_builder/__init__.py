"""Tests for the cohort builder MCP app."""
