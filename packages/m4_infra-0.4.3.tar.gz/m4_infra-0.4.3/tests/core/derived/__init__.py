"""Tests for m4.core.derived module."""
