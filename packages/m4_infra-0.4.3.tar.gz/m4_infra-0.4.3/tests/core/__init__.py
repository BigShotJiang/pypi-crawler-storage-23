"""Tests for m4.core module."""
