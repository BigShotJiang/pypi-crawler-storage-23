"""Tests for m4.core.tools module."""
