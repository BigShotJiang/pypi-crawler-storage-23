"""Tests for m4.core.backends module."""
