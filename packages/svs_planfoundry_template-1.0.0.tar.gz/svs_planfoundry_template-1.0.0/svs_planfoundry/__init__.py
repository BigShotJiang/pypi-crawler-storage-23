import os

def get_template_path():
    """Return the absolute path to the Plan Foundry Lite Template docx."""
    return os.path.join(os.path.dirname(__file__), 'Plan_Foundry_Lite_Template.docx')
