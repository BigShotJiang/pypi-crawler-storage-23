import brian2 as b2
from .base_telemetry import BaseTelemetry

class SpikeTelemetry(BaseTelemetry):
    def __init__(self):
        self.spike_monitor = None

    def attach(self, organoid):
        self.spike_monitor = b2.SpikeMonitor(organoid.neuron_group)
        organoid.register_hardware(self.spike_monitor)

    def get_data(self):
        return {
            "times_ms": self.spike_monitor.t / b2.ms,
            "neuron_ids": self.spike_monitor.i
        }

class OpsinTelemetry(BaseTelemetry):
    def __init__(self, record_indices):
        self.record_indices = record_indices
        self.state_monitor = None

    def attach(self, organoid):
        if 'O_blue' in organoid.neuron_group.equations.names:
            self.state_monitor = b2.StateMonitor(
                organoid.neuron_group, ['O_blue', 'O_yellow'], record=self.record_indices
            )
            organoid.register_hardware(self.state_monitor)
        else:
            raise ValueError("OpsinTelemetry attached to an organoid without Opsins.")

    def get_data(self):
        return {
            "times_ms": self.state_monitor.t / b2.ms,
            "O_blue": self.state_monitor.O_blue,
            "O_yellow": self.state_monitor.O_yellow
        }
