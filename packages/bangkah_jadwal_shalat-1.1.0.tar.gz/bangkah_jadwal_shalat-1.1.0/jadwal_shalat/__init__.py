"""jadwal-shalat: CLI tool untuk menampilkan jadwal shalat berdasarkan lokasi."""

__version__ = "1.1.0"
