"""Validation system."""

from galangal.validation.runner import ValidationResult, ValidationRunner

__all__ = ["ValidationRunner", "ValidationResult"]
