sphinx-icalendar
================

A minimal Sphinx extension that renders ``.. code-block:: calendar`` directives as HTML event tables, so you can embed live iCalendar data directly in your documentation.

.. toctree::
   :maxdepth: 2
   :caption: Contents

   install
   usage
   changelog
