Installation
============

Requirements
------------

- Python 3.10 or later
- Sphinx 5.0 or later
- `icalendar <https://icalendar.readthedocs.io/>`_ 7.0 or later
- `recurring-ical-events <https://recurring-ical-events.readthedocs.io/>`_

From PyPI
---------

The package is available on `PyPI <https://pypi.org/project/sphinx-icalendar/>`_:

.. code-block:: bash

    pip install sphinx-icalendar

From source
-----------

Clone the repository and install in editable mode:

.. code-block:: bash

    git clone https://github.com/nicco/sphinx-icalendar-extension.git
    cd sphinx-icalendar-extension
    pip install -e .

Enabling the extension
----------------------

Add ``sphinx_icalendar`` to the ``extensions`` list in your project's ``conf.py``:

.. code-block:: python

    extensions = [
        "sphinx_icalendar",
    ]

No further configuration is required.
