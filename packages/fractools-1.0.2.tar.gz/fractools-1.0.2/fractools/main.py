class Frac:
    def __init__(self, num, den):
        if den == 0:
            raise ValueError("Denominator cannot be zero.")
        self.numerator = num
        self.denominator = den

    def num(self):
        return self.numerator / self.denominator

    def __str__(self):
        return f"{self.numerator}/{self.denominator}"

    def __repr__(self):
        return f"Frac({self.numerator}, {self.denominator})"

class Mixed:
    def __init__(self, whole, num, den):
        if den == 0:
            raise ValueError("Denominator cannot be zero.")
        self.whole = whole
        self.numerator = num
        self.denominator = den

    def to_frac(self):
        # Formula: (whole * den + num) / den
        new_num = (self.whole * self.denominator) + self.numerator
        return Frac(new_num, self.denominator)

    def __str__(self):
        return f"{self.whole} {self.numerator}/{self.denominator}"

    def __repr__(self):
        return f"Mixed({self.whole}, {self.numerator}, {self.denominator})"

def fraction(num, den=None):
    if isinstance(num, str) and den is None:
        parts = num.split("/")
        return Frac(int(parts[0]), int(parts[1]))
    return Frac(num, den)

def mixed(whole, num, den):
    return Mixed(whole, num, den)