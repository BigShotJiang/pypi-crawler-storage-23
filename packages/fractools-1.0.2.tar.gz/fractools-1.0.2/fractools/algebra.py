from . import main
from . import arithmetic

def power(f_obj, p):
    f_obj = arithmetic._ensure_frac(f_obj)
    new_num = f_obj.numerator ** p
    new_den = f_obj.denominator ** p
    return arithmetic.simplify(main.Frac(int(new_num), int(new_den)))

def root(f_obj, r):
    f_obj = arithmetic._ensure_frac(f_obj)
    new_num = f_obj.numerator ** (1/r)
    new_den = f_obj.denominator ** (1/r)
    if new_num % 1 == 0 and new_den % 1 == 0:
        return arithmetic.simplify(main.Frac(int(new_num), int(new_den)))
    return new_num / new_den