from . import main

def _get_gcd(a, b):
    while b:
        a, b = b, a % b
    return abs(a)

def _ensure_frac(obj):
    if isinstance(obj, main.Mixed):
        return obj.to_frac()
    if isinstance(obj, main.Frac):
        return obj
    raise TypeError("Input must be a Frac or Mixed object")

def simplify(f_obj):
    f_obj = _ensure_frac(f_obj)
    common = _get_gcd(f_obj.numerator, f_obj.denominator)
    new_num = f_obj.numerator // common
    new_den = f_obj.denominator // common
    if new_den < 0:
        new_num, new_den = -new_num, abs(new_den)
    return main.Frac(new_num, new_den)

def add(f1, f2):
    f1, f2 = _ensure_frac(f1), _ensure_frac(f2)
    new_num = (f1.numerator * f2.denominator) + (f2.numerator * f1.denominator)
    new_den = f1.denominator * f2.denominator
    return simplify(main.Frac(new_num, new_den))

def subtract(f1, f2):
    f1, f2 = _ensure_frac(f1), _ensure_frac(f2)
    new_num = (f1.numerator * f2.denominator) - (f2.numerator * f1.denominator)
    new_den = f1.denominator * f2.denominator
    return simplify(main.Frac(new_num, new_den))

def multiply(f1, f2):
    f1, f2 = _ensure_frac(f1), _ensure_frac(f2)
    new_num = f1.numerator * f2.numerator
    new_den = f1.denominator * f2.denominator
    return simplify(main.Frac(new_num, new_den))

def divide(f1, f2):
    f1, f2 = _ensure_frac(f1), _ensure_frac(f2)
    if f2.numerator == 0:
        raise ZeroDivisionError("Cannot divide by zero")
    new_num = f1.numerator * f2.denominator
    new_den = f1.denominator * f2.numerator
    return simplify(main.Frac(new_num, new_den))