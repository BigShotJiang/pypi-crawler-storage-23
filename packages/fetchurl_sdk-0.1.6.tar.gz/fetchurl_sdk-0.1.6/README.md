# fetchurl

Simple caching server for URLs with a hash.
