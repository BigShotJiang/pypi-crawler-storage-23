# Blank Robot Template

Template for new robot implementations. Add discovered resources and documentation links below.

## Resources
