class TasxRegistryAPIError(Exception):
    """General exception for TASX Registry API errors."""

    pass


class TasxRunnerAPIError(Exception):
    pass


class TaskNotFoundError(TasxRegistryAPIError):
    """Exception raised when a task is not found."""
    pass


class TasxUserError(Exception):
    """
    Exception raised when a task fails due to a user-facing error.
    The message of this exception is safe to be displayed to the user.
    """
    pass
