TASX_PREFIX = "tasx"


class TaskReturnKeys:
    ATTACHMENTS: str = f"{TASX_PREFIX}:attachments"
    HINTS: str = f"{TASX_PREFIX}:hints"


class RunnerHeaders:
    """HTTP headers the runner attaches when calling a task provider.

    IDENTITY: An Internal Service Token (IST) that lets the provider identify
        the calling user.  Sent when ``call_anonymously=False`` (i.e. the task
        has ``requires_identity=True``).  The provider can forward this to
        auth-server's ``/oauth2/proxy`` to act on behalf of that user.
    SECURITY_STATUS: Semicolon-separated list of security features the user
        has enabled.  Sent when ``expose_security_status=True``.
    """
    IDENTITY: str = "X-Runner-Identity"
    SECURITY_STATUS: str = "X-Runner-Security-Status"
