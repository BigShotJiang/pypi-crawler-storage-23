version = '1.20260220.234910'
long_version = '1.20260220.234910+git.848e18a'
