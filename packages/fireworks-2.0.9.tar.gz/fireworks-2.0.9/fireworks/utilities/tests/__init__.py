"""Tests for FireWorks utilities."""
