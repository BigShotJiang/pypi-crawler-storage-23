class AuthenticationError(Exception):
    """Authentication failed."""


class ConnectionError(Exception):
    """Connection failed."""
