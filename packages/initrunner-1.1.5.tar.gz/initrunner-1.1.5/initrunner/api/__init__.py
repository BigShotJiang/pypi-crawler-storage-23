"""Dashboard API — FastAPI backend for the InitRunner web dashboard."""
