"""LLM Path - A tool for tracing LLM requests."""

from ._version import __version__

__all__ = ["__version__"]
