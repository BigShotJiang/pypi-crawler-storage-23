"""Integration tests for MCP protocol communication."""

import json
import subprocess
import time
from pathlib import Path

import pytest


class TestMCPProtocol:
    """Tests for MCP protocol communication via stdio."""

    @pytest.fixture
    def server_process(self, test_dirs, monkeypatch):
        """Start server process for testing."""
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test-key")
        monkeypatch.setenv("OPENCODE_MEM_FAISS_DIRECTORY", str(test_dirs["faiss_dir"]))

        # Start server process
        process = subprocess.Popen(
            ["python", "-m", "opencode_memory.server", "--stdio"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=Path(__file__).parent.parent,
        )

        # Wait for server to start
        time.sleep(1)

        yield process

        # Cleanup
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()

    def send_request(self, process, request):
        """Send JSON-RPC request and return response."""
        request_line = json.dumps(request) + "\n"
        process.stdin.write(request_line)
        process.stdin.flush()

        # Read response
        response_line = process.stdout.readline()
        return json.loads(response_line)

    def test_initialize_handshake(self, server_process):
        """Test MCP initialize handshake."""
        request = {
            "jsonrpc": "2.0",
            "id": 0,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "test-client", "version": "1.0.0"},
            },
        }

        response = self.send_request(server_process, request)

        assert "result" in response
        assert response["result"]["protocolVersion"] == "2024-11-05"
        assert "serverInfo" in response["result"]

    def test_list_tools(self, server_process):
        """Test listing tools via MCP protocol."""
        # First initialize
        init_request = {
            "jsonrpc": "2.0",
            "id": 0,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "test-client", "version": "1.0.0"},
            },
        }
        self.send_request(server_process, init_request)

        # Then list tools
        request = {"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}}

        response = self.send_request(server_process, request)

        assert "result" in response
        assert "tools" in response["result"]
        tools = response["result"]["tools"]

        # Check all expected tools are present
        tool_names = [t["name"] for t in tools]
        expected = [
            "add_memory",
            "search_memory",
            "get_all_memories",
            "update_memory",
            "delete_memory",
        ]

        for tool in expected:
            assert tool in tool_names, f"Missing tool: {tool}"

    @pytest.mark.skip(reason="Requires real OpenAI API key - tested via mocked unit tests")
    def test_call_add_memory(self, server_process):
        """Test calling add_memory tool via MCP protocol.

        Note: This test requires a real OpenAI API key and is skipped by default.
        The functionality is tested via mocked unit tests in test_server.py.
        """
        # Initialize
        init_request = {
            "jsonrpc": "2.0",
            "id": 0,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "test-client", "version": "1.0.0"},
            },
        }
        self.send_request(server_process, init_request)

        # Call add_memory
        request = {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/call",
            "params": {
                "name": "add_memory",
                "arguments": {"content": "Test memory via protocol", "categories": ["test"]},
            },
        }

        response = self.send_request(server_process, request)

        assert "result" in response
        # Result content is a JSON string in the response
        content = response["result"]["content"][0]["text"]
        data = json.loads(content)

        assert data["success"] is True
        assert data["content"] == "Test memory via protocol"
