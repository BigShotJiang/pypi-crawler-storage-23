"""Tests for MCP server tools."""

import json

import pytest


class TestAddMemory:
    """Tests for add_memory tool."""

    def test_add_memory_success(self, initialized_server):
        """Test adding a memory successfully."""
        result = initialized_server.add_memory(
            content="User loves Python programming", categories=["preferences", "programming"]
        )

        data = json.loads(result)
        assert data["success"] is True
        assert "memory_id" in data
        assert data["content"] == "User loves Python programming"
        assert data["categories"] == ["preferences", "programming"]
        assert "metadata" in data

    def test_add_memory_without_categories(self, initialized_server):
        """Test adding a memory without categories."""
        result = initialized_server.add_memory(content="Simple test memory")

        data = json.loads(result)
        assert data["success"] is True
        assert data["categories"] == []

    def test_add_memory_with_metadata(self, initialized_server):
        """Test adding a memory with custom metadata."""
        result = initialized_server.add_memory(
            content="Memory with metadata", metadata={"source": "test", "priority": "high"}
        )

        data = json.loads(result)
        assert data["success"] is True
        assert data["metadata"]["source"] == "test"
        assert data["metadata"]["priority"] == "high"
        assert "created_at" in data["metadata"]

    def test_add_memory_empty_content(self, initialized_server):
        """Test adding memory with empty content fails."""
        result = initialized_server.add_memory(content="")
        data = json.loads(result)
        assert "error" in data
        assert "empty" in data["error"].lower()

    def test_add_memory_whitespace_content(self, initialized_server):
        """Test adding memory with whitespace-only content fails."""
        result = initialized_server.add_memory(content="   ")
        data = json.loads(result)
        assert "error" in data


class TestSearchMemory:
    """Tests for search_memory tool."""

    @pytest.fixture(autouse=True)
    def setup_memories(self, initialized_server):
        """Add test memories before each test."""
        # Add some test memories
        initialized_server.add_memory(
            content="User loves Python programming", categories=["programming"]
        )
        initialized_server.add_memory(
            content="User enjoys hiking in mountains", categories=["hobbies"]
        )
        initialized_server.add_memory(
            content="User prefers dark mode in IDEs", categories=["preferences"]
        )

    def test_search_memory_basic(self, initialized_server):
        """Test basic memory search."""
        result = initialized_server.search_memory(query="programming languages", limit=5)

        data = json.loads(result)
        assert data["success"] is True
        assert "results" in data
        assert isinstance(data["results"], list)

    def test_search_memory_with_limit(self, initialized_server):
        """Test search with limit."""
        result = initialized_server.search_memory(query="user", limit=2)

        data = json.loads(result)
        assert data["success"] is True
        assert data["count"] <= 2

    def test_search_memory_empty_query(self, initialized_server):
        """Test search with empty query fails."""
        result = initialized_server.search_memory(query="")
        data = json.loads(result)
        assert "error" in data

    def test_search_memory_with_threshold(self, initialized_server):
        """Test search with similarity threshold."""
        result = initialized_server.search_memory(query="programming", threshold=0.5)

        data = json.loads(result)
        assert data["success"] is True
        # All results should have score >= 0.5
        for item in data["results"]:
            assert item["score"] >= 0.5


class TestGetAllMemories:
    """Tests for get_all_memories tool."""

    @pytest.fixture(autouse=True)
    def setup_memories(self, initialized_server):
        """Add test memories before each test."""
        initialized_server.add_memory(content="Memory one", categories=["cat1"])
        initialized_server.add_memory(content="Memory two", categories=["cat2"])

    def test_get_all_memories_basic(self, initialized_server):
        """Test getting all memories."""
        result = initialized_server.get_all_memories()

        data = json.loads(result)
        assert data["success"] is True
        assert "memories" in data
        assert isinstance(data["memories"], list)
        assert data["count"] >= 2

    def test_get_all_memories_with_limit(self, initialized_server):
        """Test getting memories with limit."""
        result = initialized_server.get_all_memories(limit=1)

        data = json.loads(result)
        assert data["success"] is True
        assert data["count"] <= 1

    def test_get_all_memories_with_categories(self, initialized_server):
        """Test filtering by categories."""
        result = initialized_server.get_all_memories(categories=["cat1"])

        data = json.loads(result)
        assert data["success"] is True
        # All returned memories should have cat1 in categories
        for memory in data["memories"]:
            assert "cat1" in memory.get("categories", [])


class TestUpdateMemory:
    """Tests for update_memory tool."""

    @pytest.fixture
    def existing_memory(self, initialized_server):
        """Create a memory and return its ID."""
        result = initialized_server.add_memory(content="Original content", categories=["test"])
        data = json.loads(result)
        return data["memory_id"]

    def test_update_memory_success(self, initialized_server, existing_memory):
        """Test updating a memory successfully."""
        result = initialized_server.update_memory(
            memory_id=existing_memory, new_content="Updated content"
        )

        data = json.loads(result)
        assert data["success"] is True
        assert data["memory_id"] == existing_memory
        assert data["updated_content"] == "Updated content"

    def test_update_memory_empty_id(self, initialized_server):
        """Test update with empty memory ID fails."""
        result = initialized_server.update_memory(memory_id="", new_content="Content")
        data = json.loads(result)
        assert "error" in data

    def test_update_memory_empty_content(self, initialized_server, existing_memory):
        """Test update with empty content fails."""
        result = initialized_server.update_memory(memory_id=existing_memory, new_content="")
        data = json.loads(result)
        assert "error" in data


class TestDeleteMemory:
    """Tests for delete_memory tool."""

    @pytest.fixture
    def existing_memory(self, initialized_server):
        """Create a memory and return its ID."""
        result = initialized_server.add_memory(content="Memory to delete", categories=["test"])
        data = json.loads(result)
        return data["memory_id"]

    def test_delete_memory_success(self, initialized_server, existing_memory):
        """Test deleting a memory successfully."""
        result = initialized_server.delete_memory(memory_id=existing_memory)

        data = json.loads(result)
        assert data["success"] is True
        assert data["deleted_memory_id"] == existing_memory

    def test_delete_memory_empty_id(self, initialized_server):
        """Test delete with empty ID fails."""
        result = initialized_server.delete_memory(memory_id="")
        data = json.loads(result)
        assert "error" in data


class TestServerInitialization:
    """Tests for server initialization."""

    def test_initialize_memory_client(self, server_module, mock_config):
        """Test memory client initialization."""
        client = server_module.initialize_memory_client(mock_config)
        assert client is not None

    def test_user_id_constant(self, server_module):
        """Test that USER_ID is hardcoded to 'opencode'."""
        assert server_module.USER_ID == "opencode"

    def test_tools_registered(self, server_module):
        """Test that all expected tools are registered."""
        import asyncio

        async def check_tools():
            tools = await server_module.mcp.list_tools()
            tool_names = [t.name for t in tools]

            expected_tools = [
                "add_memory",
                "search_memory",
                "get_all_memories",
                "update_memory",
                "delete_memory",
            ]

            for tool in expected_tools:
                assert tool in tool_names, f"Tool {tool} not registered"

        asyncio.run(check_tools())
