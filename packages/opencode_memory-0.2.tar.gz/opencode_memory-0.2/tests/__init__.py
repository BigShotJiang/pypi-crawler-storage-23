"""Tests for opencode-memory."""
