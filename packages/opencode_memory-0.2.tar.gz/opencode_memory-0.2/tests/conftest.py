"""Functional tests for opencode-memory MCP server."""

import os
import shutil
import tempfile
from pathlib import Path
from unittest.mock import MagicMock

import pytest

# Set test environment variables before importing server
os.environ.setdefault("OPENAI_API_KEY", "sk-test-key")


@pytest.fixture(scope="session")
def test_dirs():
    """Create temporary directories for testing."""
    temp_dir = tempfile.mkdtemp(prefix="opencode-memory-test-")
    faiss_dir = Path(temp_dir) / "faiss"
    faiss_dir.mkdir(parents=True)

    yield {
        "temp_dir": temp_dir,
        "faiss_dir": faiss_dir,
    }

    # Cleanup
    shutil.rmtree(temp_dir, ignore_errors=True)


@pytest.fixture
def mock_config(test_dirs, monkeypatch):
    """Mock configuration for testing."""
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test-key")
    monkeypatch.setenv("OPENCODE_MEM_FAISS_DIRECTORY", str(test_dirs["faiss_dir"]))

    return {
        "openai_api_key": "sk-test-key",
        "faiss_directory": test_dirs["faiss_dir"],
        "embedding_model": "text-embedding-3-large",
        "embedding_provider": "openai",
        "embedding_base_url": None,
    }


@pytest.fixture
def mock_memory_client():
    """Create a mock Memory client."""
    client = MagicMock()

    # Mock add method
    def mock_add(messages, user_id, metadata):
        return {
            "results": [
                {
                    "id": f"mem_{hash(str(messages)) % 10000}",
                    "memory": messages[0]["content"] if messages else "",
                    "user_id": user_id,
                    "metadata": metadata,
                }
            ]
        }

    client.add.side_effect = mock_add

    # Mock search method
    def mock_search(query, user_id, limit=100):
        return {
            "results": [
                {
                    "id": "mem_123",
                    "memory": f"Test memory about {query}",
                    "score": 0.85,
                    "user_id": user_id,
                    "categories": ["test"],
                    "metadata": {},
                    "created_at": "2025-01-01T00:00:00",
                }
            ]
        }

    client.search.side_effect = mock_search

    # Mock get_all method
    def mock_get_all(user_id):
        return {
            "results": [
                {
                    "id": "mem_1",
                    "memory": "Memory one",
                    "user_id": user_id,
                    "categories": ["cat1"],
                    "metadata": {},
                    "created_at": "2025-01-01T00:00:00",
                },
                {
                    "id": "mem_2",
                    "memory": "Memory two",
                    "user_id": user_id,
                    "categories": ["cat2"],
                    "metadata": {},
                    "created_at": "2025-01-02T00:00:00",
                },
            ]
        }

    client.get_all.side_effect = mock_get_all

    # Mock update method
    def mock_update(memory_id, data):
        return {
            "id": memory_id,
            "memory": data,
            "event": "UPDATE",
        }

    client.update.side_effect = mock_update

    # Mock delete method
    def mock_delete(memory_id):
        return {
            "id": memory_id,
            "event": "DELETE",
        }

    client.delete.side_effect = mock_delete

    return client


@pytest.fixture
def server_module(mock_config, mock_memory_client):
    """Import and configure server module with mocked memory client."""
    # Import after setting env vars
    from opencode_memory import server

    # Reset global state
    server.memory_client = None

    # Inject mock client
    server.memory_client = mock_memory_client

    yield server

    # Cleanup
    server.memory_client = None


@pytest.fixture
def initialized_server(server_module):
    """Return initialized server with mocked memory client."""
    return server_module
