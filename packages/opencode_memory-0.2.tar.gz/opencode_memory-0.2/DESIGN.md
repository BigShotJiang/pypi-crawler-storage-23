# Architecture Design

## Overview

This project implements an MCP (Model Context Protocol) stdio server that provides memory capabilities to AI coding agents. The server acts as a **storage and retrieval layer** without LLM processing, leaving intelligence decisions to the AI agent (opencode).

## Architecture Decision

### No Built-in LLM

**Decision:** Remove LLM configuration and processing from the MCP server.

**Rationale:**
- Opencode already has its own LLM connection
- Mem0's LLM extraction (`infer=True`) is redundant when the AI agent can decide what to store
- Simpler architecture with fewer failure points
- Lower latency (no LLM calls during storage)
- Reduced costs (no duplicate LLM usage)

**Trade-offs:**
- AI agent must explicitly decide what memories to create/update
- No automatic memory conflict resolution (agent handles this)
- No automatic fact extraction from conversations (agent provides structured data)

## Component Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        AI Agent                             │
│                      (e.g., opencode)                       │
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   LLM Logic  │  │ Memory Logic │  │   Planning   │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└────────────────────┬────────────────────────────────────────┘
                     │ MCP Protocol (stdio)
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                  MCP Memory Server                          │
│                                                             │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              MCP Tool Handlers                        │  │
│  │                                                       │  │
│  │  Memory Management:                                  │  │
│  │  • add_memory(data, metadata)                        │  │
│  │  • search_memory(query, filters)                     │  │
│  │  • update_memory(memory_id, data)                    │  │
│  │  • delete_memory(memory_id)                          │  │
│  └──────────────────────────────────────────────────────┘  │
│                          │                                  │
│                          ▼                                  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │                 mem0 (Storage Layer)                  │  │
│  │                                                       │  │
│  │  ┌──────────────┐      ┌──────────────────────┐      │  │
│  │  │   Metadata   │      │   Vector Database    │      │  │
│  │  │   Storage    │      │      (FAISS)         │      │  │
│  │  └──────────────┘      └──────────────────────┘      │  │
│  └──────────────────────────────────────────────────────┘  │
│                          │                                  │
│                          ▼                                  │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Embedding Model                          │  │
│  │       (text-embedding-3-large via OpenAI)            │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## Data Flow

### Adding Memory

1. AI agent decides what to remember
2. Agent calls `add_memory` with structured data
3. Server stores raw data in mem0 with `infer=False`
4. Embedding model generates vectors for search
5. Memory is persisted to FAISS + metadata storage

### Searching Memory

1. AI agent needs context
2. Agent calls `search_memory` with query
3. Embedding model converts query to vector
4. FAISS performs similarity search
5. Returns matching memories to agent

### Updating Memory

1. AI agent identifies outdated memory
2. Agent calls `update_memory` with new data
3. Server updates stored memory
4. Embedding regenerated if content changed

### Deleting Memory

1. AI agent identifies irrelevant memory
2. Agent calls `delete_memory` with memory_id
3. Server removes from storage and vector index

## Two-Layer Storage Architecture

The MCP server provides two distinct storage layers:

### 1. Memory Layer (Semantic Storage)
- **Purpose**: Store extracted insights, facts, and knowledge
- **Storage**: FAISS vector database + metadata
- **Search**: Semantic similarity search via embeddings
- **Use case**: "What do I know about the user's preferences?"

### 2. Conversation Layer (Markdown Files)
- **Purpose**: Store complete conversation histories as readable files
- **Storage**: Markdown files in a directory of your choice
- **Access**: Opencode's native `ls`, `read`, `edit`, `write`, and `grep` tools
- **Format**: Human-readable markdown with keywords header
- **Use case**: "What did we discuss in the last session?"

**Why markdown files?**
- Opencode can natively read, write, edit, list, and search markdown files
- No need for custom MCP retrieval/search tools
- Human-readable format for debugging
- Version control friendly
- Standard format that works with any text editor

**Benefits of this dual approach:**
- Memories provide fast semantic retrieval of key facts
- Conversations provide complete audit trail and context
- Agent can extract new memories from old conversations
- Debugging: inspect raw conversations vs. extracted memories

## Configuration

### Required Environment Variables

```bash
OPENAI_API_KEY                    # For embedding model
OPENCODE_MEM_FAISS_DIRECTORY      # Path to FAISS vector database
```

### Optional Environment Variables

```bash
OPENCODE_MEM_EMBEDDING_MODEL       # Default: text-embedding-3-large
OPENCODE_MEM_EMBEDDING_PROVIDER    # Default: openai
OPENCODE_MEM_EMBEDDING_BASE_URL    # For custom embedding endpoints
```

### Removed Configuration

The following are **not** used (LLM handled by AI agent):
- `OPENCODE_MEM_LLM_PROVIDER`
- `OPENCODE_MEM_LLM_BASE_URL`

## MCP Tools

### `add_memory`

Store a new memory in the system.

**Parameters:**
- `data` (string): The memory content to store
- `metadata` (object, optional): Key-value pairs for filtering
- `user_id` (string, optional): Scope to specific user

**Returns:**
- `memory_id`: Unique identifier for the stored memory

### `search_memory`

Search for relevant memories using semantic similarity.

**Parameters:**
- `query` (string): Search query
- `filters` (object, optional): Metadata filters
- `limit` (number, optional): Maximum results (default: 5)

**Returns:**
- Array of matching memories with relevance scores

### `update_memory`

Update an existing memory.

**Parameters:**
- `memory_id` (string): ID of memory to update
- `data` (string): New memory content
- `metadata` (object, optional): Updated metadata

**Returns:**
- Success confirmation

### `delete_memory`

Remove a memory from storage.

**Parameters:**
- `memory_id` (string): ID of memory to delete

**Returns:**
- Success confirmation

## Storage Details

### FAISS Vector Database

- Stores vector embeddings for semantic search
- Persisted to disk at `OPENCODE_MEM_FAISS_DIRECTORY`
- Supports approximate nearest neighbor search

#### Conversation File Format

Each conversation markdown file starts with a keywords header followed by the raw conversation:

```markdown
keywords: conversation_keyword_1, conversation_keyword_2, conversation_keyword_3
---

## User
Hello, I need help with Python async functions.

## Assistant
I'd be happy to help you with Python async functions. What specific aspect would you like to understand?

## User
How do I use asyncio.gather()?
...
```

**Keyword Header:**
- The `keywords` field contains a comma-separated list of relevant keywords
- Keywords are updated after each conversation update/appending
- Used by opencode's `grep` tool for searching conversation history
- Helps quickly locate relevant conversations by topic

**Benefits:**
- Simple text-based format that works with standard Unix tools
- Keywords enable fast topic-based discovery
- Easy to parse and update programmatically

## Benefits of This Architecture

1. **Separation of Concerns**: AI agent handles intelligence, server handles storage
2. **Flexibility**: Agent can implement any memory strategy it prefers
3. **Transparency**: Agent has full visibility into what gets stored
4. **Efficiency**: No redundant LLM calls
5. **Simplicity**: Fewer components to configure and maintain

## Future Considerations

- Optional LLM features could be added as opt-in for non-opencode agents
- Graph memory could be exposed as additional MCP tools
- Memory expiration/ TTL could be managed via metadata

## CI/CD Pipeline

### Versioning

The project uses **hatch-vcs** for automatic versioning from git tags. When a tag is pushed (e.g., `v1.0.0`), the version is automatically derived and embedded into the package.

**Version file generation:**
- `hatch-vcs` generates `src/opencode_memory/_version.py` at build time
- The `__init__.py` imports version from `_version.py` with fallback for development

### Workflows

#### CI Workflow (`ci.yml`)
- **Triggers:** Push to `main`, Pull Requests
- **Runs on:** Ubuntu, Python 3.10-3.13 matrix
- **Steps:**
  1. Lint with ruff
  2. Run tests with pytest
  3. Build package with uv
  4. Upload coverage to Codecov (optional)

#### Release Workflow (`release.yml`)
- **Triggers:** Push of tags matching `v*`
- **Steps:**
  1. Run tests (quality gate)
  2. Build package with uv
  3. Publish to PyPI using trusted publishing

### PyPI Publishing

The project uses **Trusted Publishing** (OIDC) for secure PyPI deployment without long-lived credentials. This is configured in the GitHub repository settings.
