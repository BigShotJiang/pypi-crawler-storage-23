"""MCP server implementation for memory management using mem0 and Faiss."""

import argparse
import json
import os
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP
from mem0 import Memory

__version__ = "0.1.0"

# Hardcoded user - opencode is the only user
USER_ID = "opencode"

# Global memory instance (initialized in main)
memory_client: Memory | None = None


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        prog="opencode-memory",
        description="A Python MCP stdio instance for adding memory to AI coding agents",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Environment Variables:
  OPENAI_API_KEY                      Required. API key for OpenAI embedding services
  OPENCODE_MEM_FAISS_DIRECTORY        Required. Path to Faiss vector database directory
  OPENCODE_MEM_EMBEDDING_MODEL        Optional. Embedding model (default: text-embedding-3-large)
  OPENCODE_MEM_EMBEDDING_PROVIDER     Optional. Embedding provider (default: openai)
  OPENCODE_MEM_EMBEDDING_BASE_URL     Optional. Custom base URL for embedding API

Note: This MCP server operates without an LLM. The AI agent (opencode) provides
intelligence, and this server provides storage + vector search capabilities.
        """,
    )
    parser.add_argument(
        "--stdio",
        action="store_true",
        help="Run in MCP stdio mode (required for AI agent integration)",
    )
    return parser.parse_args()


def validate_directory(path: str, name: str) -> Path:
    """Validate and create directory if needed.

    Args:
        path: The directory path to validate.
        name: Human-readable name of the directory for error messages.

    Returns:
        Resolved Path object.

    Raises:
        SystemExit: If the path is not a directory or cannot be created.

    """
    dir_path = Path(path).expanduser().resolve()
    if not dir_path.exists():
        try:
            dir_path.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            print(f"Error: Failed to create {name} directory: {e}", file=sys.stderr)
            sys.exit(1)
    if not dir_path.is_dir():
        print(f"Error: {name} path is not a directory: {dir_path}", file=sys.stderr)
        sys.exit(1)
    return dir_path


def load_config() -> dict:
    """Load and validate all configuration from environment variables."""
    config = {}

    # Required: OPENAI_API_KEY (for embeddings)
    openai_api_key = os.environ.get("OPENAI_API_KEY")
    if not openai_api_key:
        print(
            "Error: OPENAI_API_KEY environment variable is required",
            file=sys.stderr,
        )
        sys.exit(1)
    config["openai_api_key"] = openai_api_key

    # Required: OPENCODE_MEM_FAISS_DIRECTORY
    faiss_dir = os.environ.get("OPENCODE_MEM_FAISS_DIRECTORY")
    if not faiss_dir:
        print(
            "Error: OPENCODE_MEM_FAISS_DIRECTORY environment variable is required",
            file=sys.stderr,
        )
        sys.exit(1)
    config["faiss_directory"] = validate_directory(faiss_dir, "Faiss")

    # Optional: Embedding configuration with defaults
    config["embedding_model"] = os.environ.get(
        "OPENCODE_MEM_EMBEDDING_MODEL",
        "text-embedding-3-large",
    )
    config["embedding_provider"] = os.environ.get(
        "OPENCODE_MEM_EMBEDDING_PROVIDER",
        "openai",
    )
    config["embedding_base_url"] = os.environ.get(
        "OPENCODE_MEM_EMBEDDING_BASE_URL",
    )

    return config


def initialize_memory_client(config: dict) -> Memory:
    """Initialize mem0 client with Faiss vector store configuration."""
    mem0_config = {
        "vector_store": {
            "provider": "faiss",
            "config": {
                "collection_name": "opencode_memories",
                "path": str(config["faiss_directory"]),
                "distance_strategy": "cosine",
            },
        },
        "embedder": {
            "provider": config["embedding_provider"],
            "config": {
                "model": config["embedding_model"],
            },
        },
    }

    # Add base URL if provided
    if config["embedding_base_url"]:
        mem0_config["embedder"]["config"]["base_url"] = config["embedding_base_url"]

    return Memory.from_config(mem0_config)


# Create MCP server instance
mcp = FastMCP("opencode-memory")


# ============================================================================
# MCP Tool: add_memory - Store new memories
# ============================================================================
@mcp.tool()
def add_memory(
    content: str,
    metadata: dict | None = None,
    categories: list[str] | None = None,
    expiration_date: str | None = None,
) -> str:
    """Store a new memory or insight.

    Extract key facts, preferences, or important information from conversations
    to remember for future reference.

    Args:
        content: The content to remember (fact, preference, insight, etc.)
        metadata: Optional dictionary of additional metadata
        categories: Optional list of category tags for the memory
        expiration_date: Optional expiration date (YYYY-MM-DD or ISO format).
            After this date, the memory will no longer appear in search results.

    Returns:
        JSON string with the stored memory details.

    """
    try:
        if not memory_client:
            return json.dumps({"error": "Memory client not initialized"})

        if not content or not content.strip():
            return json.dumps({"error": "Content cannot be empty"})

        meta = metadata or {}
        meta["created_at"] = datetime.now(timezone.utc).isoformat()
        if categories:
            meta["categories"] = categories

        messages = [
            {"role": "user", "content": content},
        ]

        add_params: dict[str, Any] = {
            "messages": messages,
            "user_id": USER_ID,
            "metadata": meta,
        }

        if expiration_date:
            add_params["expiration_date"] = expiration_date

        result = memory_client.add(**add_params)

        results = result.get("results", [])
        memory_id = results[0].get("id", "unknown") if results else "unknown"

        response = {
            "success": True,
            "memory_id": memory_id,
            "content": content,
            "categories": categories or [],
            "metadata": meta,
        }
        if expiration_date:
            response["expiration_date"] = expiration_date

        return json.dumps(response, indent=2)

    except Exception as e:
        error_msg = f"Failed to add memory: {str(e)}"
        print(error_msg, file=sys.stderr)
        print(traceback.format_exc(), file=sys.stderr)
        return json.dumps({"error": error_msg})


def _filter_by_categories(results: list, categories: list[str]) -> list:
    """Filter results by categories using OR logic."""
    filtered = []
    for item in results:
        item_categories = item.get("metadata", {}).get("categories", [])
        if any(cat in item_categories for cat in categories):
            filtered.append(item)
    return filtered


def _filter_by_metadata(results: list, metadata_filter: dict) -> list:
    """Filter results by metadata key-value pairs."""
    filtered = []
    for item in results:
        item_meta = item.get("metadata", {})
        if all(item_meta.get(k) == v for k, v in metadata_filter.items()):
            filtered.append(item)
    return filtered


def _format_memory_result(item: dict) -> dict:
    """Format a memory result for JSON response."""
    item_meta = item.get("metadata", {})
    return {
        "id": item.get("id"),
        "memory": item.get("memory"),
        "score": item.get("score"),
        "categories": item_meta.get("categories", []),
        "metadata": item_meta,
        "expiration_date": item.get("expiration_date"),
    }


# ============================================================================
# MCP Tool: search_memory - Search memories
# ============================================================================
@mcp.tool()
def search_memory(
    query: str,
    categories: list[str] | None = None,
    metadata_filter: dict | None = None,
    limit: int = 10,
    threshold: float = 0.0,
) -> str:
    """Search for relevant memories using semantic similarity.

    Returns memories that match the query conceptually, not just by keywords.

    Args:
        query: The search query describing what you're looking for
        categories: Optional list of categories to filter by (OR logic)
        metadata_filter: Optional metadata key-value pairs to filter by
        limit: Maximum number of results to return (default: 10)
        threshold: Minimum similarity score threshold (0.0 to 1.0)

    Returns:
        JSON string with search results.

    """
    try:
        if not memory_client:
            return json.dumps({"error": "Memory client not initialized"})

        if not query or not query.strip():
            return json.dumps({"error": "Query cannot be empty"})

        search_params: dict[str, Any] = {
            "query": query,
            "user_id": USER_ID,
            "limit": limit,
        }

        result = memory_client.search(**search_params)
        results = result.get("results", [])

        if categories:
            results = _filter_by_categories(results, categories)

        if metadata_filter:
            results = _filter_by_metadata(results, metadata_filter)

        if threshold > 0:
            results = [r for r in results if r.get("score", 0) >= threshold]

        formatted_results = [_format_memory_result(item) for item in results]

        return json.dumps(
            {
                "success": True,
                "query": query,
                "count": len(formatted_results),
                "results": formatted_results,
            },
            indent=2,
        )

    except Exception as e:
        error_msg = f"Failed to search memories: {str(e)}"
        print(error_msg, file=sys.stderr)
        print(traceback.format_exc(), file=sys.stderr)
        return json.dumps({"error": error_msg})


# ============================================================================
# MCP Tool: get_all_memories - Retrieve all memories
# ============================================================================
@mcp.tool()
def get_all_memories(
    categories: list[str] | None = None,
    metadata_filter: dict | None = None,
    limit: int = 100,
) -> str:
    """Retrieve all stored memories.

    Optionally filter by categories or metadata.

    Args:
        categories: Optional list of categories to filter by (OR logic)
        metadata_filter: Optional metadata key-value pairs to filter by
        limit: Maximum number of memories to return (default: 100)

    Returns:
        JSON string with all matching memories.

    """
    try:
        if not memory_client:
            return json.dumps({"error": "Memory client not initialized"})

        result = memory_client.get_all(user_id=USER_ID)
        results = result.get("results", [])

        if categories:
            results = _filter_by_categories(results, categories)

        if metadata_filter:
            results = _filter_by_metadata(results, metadata_filter)

        results = results[:limit]
        formatted_results = [_format_memory_result(item) for item in results]

        return json.dumps(
            {
                "success": True,
                "count": len(formatted_results),
                "memories": formatted_results,
            },
            indent=2,
        )

    except Exception as e:
        error_msg = f"Failed to retrieve memories: {str(e)}"
        print(error_msg, file=sys.stderr)
        print(traceback.format_exc(), file=sys.stderr)
        return json.dumps({"error": error_msg})


# ============================================================================
# MCP Tool: update_memory - Update existing memory
# ============================================================================
@mcp.tool()
def update_memory(
    memory_id: str,
    new_content: str,
    metadata: dict | None = None,
) -> str:
    """Update an existing memory by ID.

    Useful for correcting or enhancing previously stored information.

    Args:
        memory_id: The ID of the memory to update
        new_content: The updated content
        metadata: Optional updated metadata

    Returns:
        JSON string with update confirmation.

    """
    try:
        if not memory_client:
            return json.dumps({"error": "Memory client not initialized"})

        if not memory_id or not memory_id.strip():
            return json.dumps({"error": "Memory ID cannot be empty"})

        if not new_content or not new_content.strip():
            return json.dumps({"error": "New content cannot be empty"})

        # Update memory using mem0 - takes memory_id and data parameters
        result = memory_client.update(
            memory_id=memory_id,
            data=new_content,
        )

        return json.dumps(
            {
                "success": True,
                "memory_id": memory_id,
                "updated_content": new_content,
                "event": result.get("event", "UPDATE"),
            },
            indent=2,
        )

    except Exception as e:
        error_msg = f"Failed to update memory: {str(e)}"
        print(error_msg, file=sys.stderr)
        print(traceback.format_exc(), file=sys.stderr)
        return json.dumps({"error": error_msg})


# ============================================================================
# MCP Tool: delete_memory - Remove memory
# ============================================================================
@mcp.tool()
def delete_memory(memory_id: str) -> str:
    """Delete a specific memory by its ID.

    Use with caution as this operation cannot be undone.

    Args:
        memory_id: The ID of the memory to delete

    Returns:
        JSON string with deletion confirmation.

    """
    try:
        if not memory_client:
            return json.dumps({"error": "Memory client not initialized"})

        if not memory_id or not memory_id.strip():
            return json.dumps({"error": "Memory ID cannot be empty"})

        # Delete memory using mem0
        result = memory_client.delete(memory_id=memory_id)

        return json.dumps(
            {
                "success": True,
                "deleted_memory_id": memory_id,
                "event": result.get("event", "DELETE"),
                "message": f"Memory {memory_id} has been deleted",
            },
            indent=2,
        )

    except Exception as e:
        error_msg = f"Failed to delete memory: {str(e)}"
        print(error_msg, file=sys.stderr)
        print(traceback.format_exc(), file=sys.stderr)
        return json.dumps({"error": error_msg})


def run_stdio_server(config: dict) -> None:
    """Run the MCP stdio server with the provided configuration."""
    global memory_client

    print("Starting MCP stdio server...", file=sys.stderr)
    print(f"  Faiss directory: {config['faiss_directory']}", file=sys.stderr)
    print(f"  Embedding model: {config['embedding_model']}", file=sys.stderr)
    print(f"  Embedding provider: {config['embedding_provider']}", file=sys.stderr)
    if config["embedding_base_url"]:
        print(f"  Embedding base URL: {config['embedding_base_url']}", file=sys.stderr)
    print("  Mode: Storage + Vector Search (no LLM)", file=sys.stderr)
    print(f"  User: {USER_ID}", file=sys.stderr)

    try:
        memory_client = initialize_memory_client(config)

        print("  Memory client initialized successfully", file=sys.stderr)
        print("  Running MCP server with stdio transport...", file=sys.stderr)

        # Run the MCP server with stdio transport
        mcp.run(transport="stdio")

    except Exception as e:
        print(f"Fatal error: {e}", file=sys.stderr)
        print(traceback.format_exc(), file=sys.stderr)
        sys.exit(1)


def main() -> None:
    """Run the opencode-memory server."""
    args = parse_args()

    if not args.stdio:
        print("Usage: opencode-memory --stdio", file=sys.stderr)
        print(
            "\nThis server implements the Model Context Protocol (MCP) stdio transport.",
            file=sys.stderr,
        )
        print("It must be run with the --stdio flag for AI agent integration.", file=sys.stderr)
        print("\nUse --help for more information.", file=sys.stderr)
        sys.exit(1)

    config = load_config()
    run_stdio_server(config)


if __name__ == "__main__":
    main()
