# Project Tasks

## Setup & Configuration
- [X] Initialize Python project structure with pyproject.toml
- [X] Set up virtual environment and dependency management
- [X] Install MCP SDK and dependencies
- [X] Install mem0 with Faiss vector store support
- [X] Create basic project directory structure

## Core Server Foundation
- [X] Implement CLI argument parser with '--stdio' option
- [X] Show help usage when '--stdio' option is not provided
- [X] Read and validate OPENAI_API_KEY env var (fail with error if missing)
- [X] Read OPENCODE_MEM_EMBEDDING_MODEL env var (default: "text-embedding-3-large")
- [X] Read OPENCODE_MEM_EMBEDDING_PROVIDER env var (default: "openai")
- [X] Read optional OPENCODE_MEM_EMBEDDING_BASE_URL env var
- [X] Read and validate OPENCODE_MEM_FAISS_DIRECTORY env var (fail with error if missing)

## MCP Server Implementation
- [X] Implement MCP stdio server base structure
- [X] Define MCP tool schemas for memory operations
- [X] Implement memory storage tool (add memory)
- [X] Implement memory retrieval tool (search memory)
- [X] Implement memory deletion tool (remove memory)
- [X] Implement memory update tool (update existing memory)
- [X] Implement conversation storage tool (store_conversation)
- [X] Add error handling and validation for all tools

## Mem0 Integration
- [X] Configure mem0 with Faiss vector database
- [X] Implement memory storage with metadata support
- [X] Implement semantic search capabilities
- [X] Add memory categorization/tagging support
- [X] Configure memory expiration/ttl if needed

## Testing & Quality
- [ ] Write unit tests for memory operations
- [ ] Write integration tests for MCP tools
- [ ] Add test coverage reporting
- [ ] Perform end-to-end testing with sample agent

## Documentation
- [X] Write README.md with setup instructions
- [X] Document MCP tool usage and parameters
- [X] Add configuration examples
- [X] Create usage examples for common scenarios

## Deployment & Distribution
- [X] Package project for distribution
- [X] Add CLI entry point for easy execution
- [ ] Test stdio transport with real AI agent
- [X] Create installation instructions

## GitHub Actions CI/CD
- [X] Create GitHub Action workflow triggered before new tag creation
- [X] Configure workflow to run tests
- [X] Configure workflow to build uv package
- [X] Configure workflow to publish uv package
