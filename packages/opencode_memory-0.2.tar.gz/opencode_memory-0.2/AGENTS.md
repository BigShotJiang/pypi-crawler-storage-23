# Project-Specific Agent Guidelines

## Overview
- **Purpose**: A Python MCP (Model Context Protocol) stdio instance for adding memory to any AI coding agent
- **Language**: Python
- **Key Technologies**:
  - MCP (Model Context Protocol) - stdio transport
  - mem0 - Memory layer for AI applications
  - Faiss - Vector database for similarity search
- **Key Files**:
  - `AGENTS.md` - This file with project-specific rules
  - `README.md` - End-user documentation with setup and usage
  - `API.md` - Complete MCP tool reference with examples
  - `DESIGN.md` - Architecture and design decisions documentation
  - `TASKS.md` - Project roadmap and task tracking

## Project Rules

### Task Tracking
- All tasks MUST be tracked in `TASKS.md`
- Task format: `- [ ] Description` for pending, `- [X] Description` for completed
- Each task MUST fit on one line
- Update TASKS.md immediately after completing any task

### Documentation Standards
- Keep `DESIGN.md` updated with architectural decisions as the project evolves
- Document any non-trivial design choices in `DESIGN.md`
- Code comments should explain WHY, not WHAT
- End-user documentation in `README.md` focuses on benefits and usage
- Technical API details in `API.md`

### Development Workflow
1. Check `TASKS.md` for next pending task
2. Update task status to in-progress during work
3. Mark task as complete immediately after finishing
4. Update `DESIGN.md` if the task involves architectural changes
5. **Always run `uvx ruff check src tests` after any code modification**

### Technology-Specific Rules
- Use mem0 as the memory backend for all memory operations
- Use Faiss as the vector database (configured through mem0)
- Implement MCP stdio transport for communication
- Keep the implementation framework-agnostic for AI agent compatibility

### Error Handling and Learning
- When an error is encountered or suboptimal code is written:
  - Document the issue in this file under `## Lessons Learned`
  - Include the correct approach/solution
  - Add context to prevent repetition

## Lessons Learned
- **hatch-vcs generated `_version.py` linting**: The default template uses deprecated `typing.Tuple` and `typing.Union` imports. Fix by providing a custom `template` in `[tool.hatch.build.hooks.vcs]` with modern Python syntax. The `_version.py` file should be in `.gitignore` as it's auto-generated during build.

## See Also
- [README.md](README.md) - Project overview and setup
- [API.md](API.md) - MCP tool reference
- [DESIGN.md](DESIGN.md) - Architecture documentation
- [TASKS.md](TASKS.md) - Task tracking and roadmap
