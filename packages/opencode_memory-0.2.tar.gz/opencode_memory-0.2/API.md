# API Reference

This document provides detailed documentation for all MCP tools provided by OpenCode Memory.

## Overview

OpenCode Memory provides 5 MCP tools for memory management:

| Tool | Purpose |
|------|---------|
| `add_memory` | Store new memories |
| `search_memory` | Search memories semantically |
| `get_all_memories` | Retrieve all memories |
| `update_memory` | Update existing memories |
| `delete_memory` | Remove memories |

---

## add_memory

Store a new memory or insight for future reference.

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `content` | string | Yes | The memory content to store |
| `metadata` | object | No | Additional key-value metadata |
| `categories` | string[] | No | Category tags for filtering |
| `expiration_date` | string | No | Expiration date (YYYY-MM-DD or ISO format). After this date, the memory will not appear in search results |

### Example Request

```json
{
  "content": "User prefers dark mode for all code editors",
  "categories": ["preferences", "ui"],
  "metadata": {
    "project": "main-project",
    "confidence": "high"
  }
}
```

### Example Response

```json
{
  "success": true,
  "memory_id": "mem_abc123",
  "content": "User prefers dark mode for all code editors",
  "categories": ["preferences", "ui"],
  "metadata": {
    "project": "main-project",
    "confidence": "high",
    "created_at": "2024-01-15T10:30:00Z"
  }
}
```

### With Expiration

```json
{
  "content": "User is currently working on the authentication module for sprint 3",
  "categories": ["current-focus"],
  "expiration_date": "2024-02-15"
}
```

---

## search_memory

Search for relevant memories using semantic similarity. Returns memories that match the query conceptually, not just by keywords.

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `query` | string | Yes | Search query describing what you're looking for |
| `categories` | string[] | No | Filter by categories (OR logic - returns memories matching ANY category) |
| `metadata_filter` | object | No | Filter by metadata key-value pairs (AND logic - must match ALL) |
| `limit` | number | No | Maximum results to return (default: 10) |
| `threshold` | number | No | Minimum similarity score 0.0-1.0 (default: 0.0) |

### Example Request

```json
{
  "query": "user preferences for code editors",
  "categories": ["preferences"],
  "limit": 5
}
```

### Example Response

```json
{
  "success": true,
  "query": "user preferences for code editors",
  "count": 2,
  "results": [
    {
      "id": "mem_abc123",
      "memory": "User prefers dark mode for all code editors",
      "score": 0.92,
      "categories": ["preferences", "ui"],
      "metadata": {
        "project": "main-project",
        "created_at": "2024-01-15T10:30:00Z"
      },
      "expiration_date": null
    }
  ]
}
```

### Filtering by Metadata

```json
{
  "query": "project architecture",
  "metadata_filter": {
    "project": "main-app"
  },
  "limit": 10
}
```

---

## get_all_memories

Retrieve all stored memories with optional filtering. Useful for browsing or bulk operations.

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `categories` | string[] | No | Filter by categories (OR logic) |
| `metadata_filter` | object | No | Filter by metadata key-value pairs |
| `limit` | number | No | Maximum memories to return (default: 100) |

### Example Request

```json
{
  "categories": ["preferences"],
  "limit": 50
}
```

### Example Response

```json
{
  "success": true,
  "count": 3,
  "memories": [
    {
      "id": "mem_abc123",
      "memory": "User prefers dark mode for all code editors",
      "score": null,
      "categories": ["preferences", "ui"],
      "metadata": {"project": "main-project"}
    },
    {
      "id": "mem_def456",
      "memory": "User prefers 2-space indentation for Python",
      "score": null,
      "categories": ["preferences", "python"],
      "metadata": {}
    }
  ]
}
```

---

## update_memory

Update an existing memory by ID. Useful for correcting or enhancing previously stored information.

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `memory_id` | string | Yes | ID of the memory to update |
| `new_content` | string | Yes | Updated memory content |
| `metadata` | object | No | Updated metadata (not currently used by mem0 update) |

### Example Request

```json
{
  "memory_id": "mem_abc123",
  "new_content": "User prefers dark mode with Solarized theme for all code editors"
}
```

### Example Response

```json
{
  "success": true,
  "memory_id": "mem_abc123",
  "updated_content": "User prefers dark mode with Solarized theme for all code editors",
  "event": "UPDATE"
}
```

---

## delete_memory

Delete a memory by ID. Use with caution as this operation cannot be undone.

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `memory_id` | string | Yes | ID of the memory to delete |

### Example Request

```json
{
  "memory_id": "mem_abc123"
}
```

### Example Response

```json
{
  "success": true,
  "deleted_memory_id": "mem_abc123",
  "event": "DELETE",
  "message": "Memory mem_abc123 has been deleted"
}
```

---

## Error Handling

All tools return errors in a consistent format:

```json
{
  "error": "Description of the error"
}
```

Common error scenarios:

| Tool | Error | Cause |
|------|-------|-------|
| All | `"Memory client not initialized"` | Server startup failed |
| All | `"History directory not initialized"` | Server startup failed |
| `add_memory` | `"Content cannot be empty"` | Empty or whitespace-only content |
| `search_memory` | `"Query cannot be empty"` | Empty or whitespace-only query |
| `update_memory` | `"Memory ID cannot be empty"` | Missing memory_id |
| `update_memory` | `"New content cannot be empty"` | Empty or whitespace-only content |
| `delete_memory` | `"Memory ID cannot be empty"` | Missing memory_id |

---

## Best Practices

### Choosing Categories

Categories enable filtering and organization. Use consistent naming:

| Category Type | Examples |
|---------------|----------|
| Preferences | `preferences`, `ui`, `editor`, `formatting` |
| Project Context | `project-context`, `architecture`, `tech-stack` |
| Current Work | `current-focus`, `sprint`, `milestone` |
| Decisions | `decision`, `design-decision`, `api-design` |
| Knowledge | `knowledge`, `pattern`, `best-practice` |

### Metadata Usage

Use metadata for structured filtering:

```json
{
  "content": "Database uses connection pooling with max 20 connections",
  "categories": ["project-context", "database"],
  "metadata": {
    "project": "main-app",
    "component": "database",
    "date": "2024-01-15"
  }
}
```

### Memory Expiration

Use expiration for time-sensitive information:

- Current sprint focus
- Temporary workarounds
- Time-bound decisions

```json
{
  "content": "API rate limit temporarily increased to 1000 req/min during load testing",
  "categories": ["temporary", "api"],
  "expiration_date": "2024-02-01"
}
```

---

## See Also

- [README.md](README.md) - Project overview and setup
- [DESIGN.md](DESIGN.md) - Architecture decisions
