"""Milco AI – deterministic, human-in-the-loop repo automation."""

__version__ = "0.4.7"
