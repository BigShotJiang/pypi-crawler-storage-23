"""Task type registry."""
