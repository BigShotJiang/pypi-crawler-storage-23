"""Tests for --version flag."""

from milco.cli import main


def test_version_exits_zero(capsys):
    exit_code = main(["--version"])
    assert exit_code == 0


def test_version_prints_version(capsys):
    main(["--version"])
    out = capsys.readouterr().out.strip()
    assert out
    parts = out.split(".")
    assert len(parts) >= 2
    assert all(p.isdigit() for p in parts[:3])
