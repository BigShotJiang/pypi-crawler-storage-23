"""Tests for LLM provider base class."""

import pytest
from milco.llm.base import LLMProvider


def test_llm_provider_complete_raises_not_implemented():
    provider = LLMProvider()
    with pytest.raises(NotImplementedError):
        provider.complete("hello")


def test_llm_provider_ping_raises_not_implemented():
    provider = LLMProvider()
    with pytest.raises(NotImplementedError):
        provider.ping()


def test_llm_provider_name_raises_not_implemented():
    provider = LLMProvider()
    with pytest.raises(NotImplementedError):
        _ = provider.name
