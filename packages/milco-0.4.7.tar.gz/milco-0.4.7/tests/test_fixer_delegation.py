"""Tests that fixer.py delegates to the task registry."""

from milco.core.run_context import RunContext
from milco.core.artifacts import write_artifact
from milco.fix.fixer import run_fix


def _make_ctx(tmp_path, task_type=None):
    contract = tmp_path / "TASK_CONTRACT.md"
    contract.write_text(
        "# Task Contract\n\n"
        "## Goal\n\nTest.\n\n"
        "## Scope\n\nTest.\n\n"
        "## Out of scope\n\nNone.\n\n"
        "## Success Criteria\n\nPass.\n\n"
        "## Constraints\n\nNone.\n\n"
        "## Approvals required\n\nCONFIRM APPLY\n\n"
        "## Notes\n\nNone.\n",
        encoding="utf-8",
    )
    ctx = RunContext(
        repo_root=tmp_path,
        run_id="test-delegation",
        apply_mode=False,
        contract_path=str(contract),
        task_type=task_type,
    )
    write_artifact(ctx, "evidence.md", "# Evidence\n\nSome evidence.\n")
    return ctx


def test_fixer_delegates_to_map_gen(tmp_path):
    ctx = _make_ctx(tmp_path, task_type="map-gen")
    result = run_fix(ctx)
    assert result["success"] is True
    assert ctx.artifact_path("patches.diff").exists()


def test_fixer_defaults_to_map_gen_when_no_task_type(tmp_path):
    ctx = _make_ctx(tmp_path, task_type=None)
    result = run_fix(ctx)
    assert result["success"] is True
    assert ctx.artifact_path("patches.diff").exists()


def test_fixer_returns_dict_format(tmp_path):
    ctx = _make_ctx(tmp_path, task_type="map-gen")
    result = run_fix(ctx)
    assert "phase" in result
    assert "run_id" in result
    assert "applied" in result
    assert "errors" in result
    assert "success" in result
