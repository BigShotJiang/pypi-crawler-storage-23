"""End-to-end smoke test: full pipeline with map-gen and doc-gen."""

from milco.cli import main

import milco.tasks.map_gen  # noqa: F401
import milco.tasks.doc_gen  # noqa: F401


def _write_contract(tmp_path, task_type="map-gen", confirm=True):
    text = (
        "# Task Contract\n\n"
        f"## Task Type\n\n{task_type}\n\n"
        "## Goal\n\nTest.\n\n"
        "## Scope\n\nTest.\n\n"
        "## Out of scope\n\nNone.\n\n"
        "## Success Criteria\n\nPass.\n\n"
        "## Constraints\n\nNone.\n\n"
        "## Approvals required\n\n"
    )
    if confirm:
        text += "CONFIRM APPLY\n\n"
    else:
        text += "None.\n\n"
    text += "## Notes\n\nNone.\n"
    p = tmp_path / "TASK_CONTRACT.md"
    p.write_text(text, encoding="utf-8")
    return str(p)


def test_full_pipeline_map_gen(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    # Seed a passing test so the pytest gate succeeds in the temp dir
    (tmp_path / "test_ok.py").write_text("def test_ok(): pass\n", encoding="utf-8")
    contract = _write_contract(tmp_path, "map-gen")
    exit_code = main(["run", "--apply", "--contract", contract])
    assert exit_code == 0
    assert (tmp_path / "map.json").exists()
    assert (tmp_path / "runs").exists()


def test_full_pipeline_map_gen_dry_run(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    contract = _write_contract(tmp_path, "map-gen")
    exit_code = main(["run", "--contract", contract])
    assert exit_code == 0
    assert (tmp_path / "runs").exists()
