"""Tests for milco show on a REFUSED run."""

from milco.cli import main


def _setup_refused(tmp_path, monkeypatch, run_id="show-refused"):
    contract = tmp_path / "TASK_CONTRACT.md"
    contract.write_text(
        "# Task Contract\n\n"
        "## Goal\n\nTest.\n\n## Scope\n\nTest.\n\n"
        "## Out of scope\n\nNone.\n\n## Success Criteria\n\nPass.\n\n"
        "## Constraints\n\nNone.\n\n## Approvals required\n\nNone.\n\n"
        "## Notes\n\nNone.\n",
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)
    main(["run", "--apply", "--contract", str(contract), "--run-id", run_id])


def test_show_refused_decision(tmp_path, monkeypatch, capsys):
    _setup_refused(tmp_path, monkeypatch, "ref-show")
    capsys.readouterr()

    exit_code = main(["show", "ref-show"])
    assert exit_code == 0
    out = capsys.readouterr().out
    assert "REFUSED" in out


def test_show_refused_exit_code_displayed(tmp_path, monkeypatch, capsys):
    _setup_refused(tmp_path, monkeypatch, "ref-exit")
    capsys.readouterr()

    main(["show", "ref-exit"])
    out = capsys.readouterr().out
    assert "Exit code: 1" in out


def test_show_refused_notes(tmp_path, monkeypatch, capsys):
    _setup_refused(tmp_path, monkeypatch, "ref-notes")
    capsys.readouterr()

    main(["show", "ref-notes"])
    out = capsys.readouterr().out
    assert "Notes:" in out
    assert "CONFIRM APPLY" in out
