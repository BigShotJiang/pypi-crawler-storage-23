"""Tests for improved error messages with suggestions."""

from milco.cli import main

import milco.tasks.map_gen  # noqa: F401
import milco.tasks.doc_gen  # noqa: F401


def _write_contract(tmp_path, task_type="map-gen", confirm=True):
    text = (
        "# Task Contract\n\n"
        f"## Task Type\n\n{task_type}\n\n"
        "## Goal\n\nTest.\n\n"
        "## Scope\n\nTest.\n\n"
        "## Out of scope\n\nNone.\n\n"
        "## Success Criteria\n\nPass.\n\n"
        "## Constraints\n\nNone.\n\n"
        "## Approvals required\n\n"
    )
    if confirm:
        text += "CONFIRM APPLY\n\n"
    else:
        text += "None.\n\n"
    text += "## Notes\n\nNone.\n"
    p = tmp_path / "TASK_CONTRACT.md"
    p.write_text(text, encoding="utf-8")
    return str(p)


def test_unknown_task_suggests_close_match(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    contract = _write_contract(tmp_path, "doc-gn")
    main(["run", "--contract", contract])
    output = capsys.readouterr().out
    assert "doc-gen" in output or "Did you mean" in output


def test_unknown_task_suggests_list_tasks(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    contract = _write_contract(tmp_path, "banana")
    main(["run", "--contract", contract])
    output = capsys.readouterr().out
    assert "--list-tasks" in output


def test_unknown_task_shows_what_to_do_next(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    contract = _write_contract(tmp_path, "banana")
    main(["run", "--contract", contract])
    output = capsys.readouterr().out
    assert "What to do next" in output


def test_llm_task_no_config_suggests_init(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    contract = _write_contract(tmp_path, "doc-gen")
    main(["run", "--contract", contract])
    output = capsys.readouterr().out
    assert "milco.toml" in output or "milco init" in output


def test_llm_task_no_config_shows_what_to_do_next(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    contract = _write_contract(tmp_path, "doc-gen")
    main(["run", "--contract", contract])
    output = capsys.readouterr().out
    assert "What to do next" in output
