"""Integration test for format task (requires ruff in path)."""

import subprocess
import pytest
from milco.cli import main

try:
    subprocess.run(["ruff", "--version"], capture_output=True, check=True)
    RUFF_AVAILABLE = True
except (subprocess.CalledProcessError, FileNotFoundError):
    RUFF_AVAILABLE = False


@pytest.mark.skipif(not RUFF_AVAILABLE, reason="ruff not installed")
def test_run_format_task_dry_run(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "TASK_CONTRACT.md").write_text(
        "# Task Contract\n\n"
        "## Task Type\n\nformat\n\n"
        "## Goal\n\nFormat.\n\n"
        "## Scope\n\n.\n\n"
        "## Out of scope\n\nNone.\n\n"
        "## Success Criteria\n\nPass.\n\n"
        "## Constraints\n\nNone.\n\n"
        "## Approvals required\n\nCONFIRM APPLY\n\n"
        "## Notes\n\nNone.\n",
        encoding="utf-8",
    )
    (tmp_path / "foo.py").write_text("x=1\n", encoding="utf-8")
    exit_code = main(["run", "--contract", str(tmp_path / "TASK_CONTRACT.md")])
    assert exit_code == 0
    assert (tmp_path / "runs").exists()
