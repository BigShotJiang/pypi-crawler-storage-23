"""Tests for Task Type section parsing in contracts."""

from milco.core.contract import parse_task_type


CONTRACT_WITH_TASK_TYPE = """\
# Task Contract

## Task Type

doc-gen

## Goal

Generate docs.

## Scope

README only.

## Out of scope

Nothing.

## Success Criteria

README exists.

## Constraints

None.

## Approvals required

CONFIRM APPLY

## Notes

None.
"""

CONTRACT_WITHOUT_TASK_TYPE = """\
# Task Contract

## Goal

Generate map.json.

## Scope

Scan.

## Out of scope

Nothing.

## Success Criteria

map.json.

## Constraints

None.

## Approvals required

CONFIRM APPLY

## Notes

None.
"""


def test_parse_task_type_present():
    assert parse_task_type(CONTRACT_WITH_TASK_TYPE) == "doc-gen"


def test_parse_task_type_missing_defaults_to_map_gen():
    assert parse_task_type(CONTRACT_WITHOUT_TASK_TYPE) == "map-gen"


def test_parse_task_type_whitespace():
    text = CONTRACT_WITH_TASK_TYPE.replace("doc-gen", "  scaffold  ")
    assert parse_task_type(text) == "scaffold"
