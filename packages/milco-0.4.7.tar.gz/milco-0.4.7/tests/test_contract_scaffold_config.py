"""Tests for ## Scaffold section parsing in contracts."""

from milco.core.contract import parse_scaffold_config


CONTRACT_WITH_SCAFFOLD = """\
# Task Contract

## Task Type

scaffold

## Goal

Create a new module.

## Scaffold

template: python_module
target: src/mymodule.py
module_name: mymodule
docstring: My new module.

## Scope

One file.

## Out of scope

Nothing.

## Success Criteria

File exists.

## Constraints

None.

## Approvals required

CONFIRM APPLY

## Notes

None.
"""

CONTRACT_WITHOUT_SCAFFOLD = """\
# Task Contract

## Task Type

map-gen

## Goal

Generate map.

## Scope

Repo.

## Out of scope

Nothing.

## Success Criteria

Done.

## Constraints

None.

## Approvals required

CONFIRM APPLY

## Notes

None.
"""


def test_parse_scaffold_config_present():
    config = parse_scaffold_config(CONTRACT_WITH_SCAFFOLD)
    assert config is not None
    assert config.get("template") == "python_module"
    assert config.get("target") == "src/mymodule.py"
    assert config.get("module_name") == "mymodule"
    assert config.get("docstring") == "My new module."


def test_parse_scaffold_config_missing_returns_none():
    assert parse_scaffold_config(CONTRACT_WITHOUT_SCAFFOLD) is None


def test_parse_scaffold_config_normalizes_keys():
    text = """## Scaffold

Template: pytest_file
Target: tests/test_foo.py
Module_Name: foo
"""
    config = parse_scaffold_config(text)
    assert config is not None
    assert config.get("template") == "pytest_file"
    assert config.get("target") == "tests/test_foo.py"
    assert config.get("module_name") == "foo"


def test_parse_scaffold_config_ignores_empty_and_comments():
    text = """## Scaffold

template: python_module
target: x.py

# comment
module_name: x
"""
    config = parse_scaffold_config(text)
    assert config is not None
    assert config.get("template") == "python_module"
    assert config.get("target") == "x.py"
    assert config.get("module_name") == "x"
