"""Tests for milco history when index.jsonl is missing or empty."""

from milco.cli import main


def test_missing_index_exits_0(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    exit_code = main(["history"])
    assert exit_code == 0
    out = capsys.readouterr().out
    assert "missing" in out.lower()


def test_empty_index_exits_0(tmp_path, monkeypatch, capsys):
    runs_dir = tmp_path / "runs"
    runs_dir.mkdir()
    (runs_dir / "index.jsonl").write_text("", encoding="utf-8")

    monkeypatch.chdir(tmp_path)
    exit_code = main(["history"])
    assert exit_code == 0
    out = capsys.readouterr().out
    assert "empty" in out.lower()


def test_missing_index_message_text(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    main(["history"])
    out = capsys.readouterr().out
    assert "runs/index.jsonl missing" in out


def test_invalid_last_exits_1(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    exit_code = main(["history", "--last", "0"])
    assert exit_code == 1
