"""Tests for milco init command."""

from milco.cli import main


def test_init_creates_contract(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    exit_code = main(["init"])
    assert exit_code == 0
    contract = tmp_path / "TASK_CONTRACT.md"
    assert contract.exists()
    text = contract.read_text(encoding="utf-8")
    assert "## Goal" in text
    assert "## Scope" in text


def test_init_creates_milco_toml(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    exit_code = main(["init"])
    assert exit_code == 0
    toml = tmp_path / "milco.toml"
    assert toml.exists()
    text = toml.read_text(encoding="utf-8")
    assert "[llm]" in text
    assert "ollama" in text


def test_init_skips_existing_files(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "TASK_CONTRACT.md").write_text("existing", encoding="utf-8")
    exit_code = main(["init"])
    assert exit_code == 0
    assert (tmp_path / "TASK_CONTRACT.md").read_text(encoding="utf-8") == "existing"
    output = capsys.readouterr().out
    assert "Skipped" in output


def test_init_with_task_type(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    exit_code = main(["init", "--task-type", "doc-gen"])
    assert exit_code == 0
    text = (tmp_path / "TASK_CONTRACT.md").read_text(encoding="utf-8")
    assert "## Task Type" in text
    assert "doc-gen" in text


def test_init_without_task_type_defaults_map_gen(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    exit_code = main(["init"])
    assert exit_code == 0
    text = (tmp_path / "TASK_CONTRACT.md").read_text(encoding="utf-8")
    assert "## Task Type" in text
    assert "map-gen" in text
