"""Tests for task type descriptions."""

from milco.tasks.registry import get_task, list_tasks

import milco.tasks.map_gen  # noqa: F401
import milco.tasks.doc_gen  # noqa: F401
import milco.tasks.scaffold_task  # noqa: F401

try:
    import milco.tasks.format_task  # noqa: F401
except ImportError:
    pass
try:
    import milco.tasks.lint_task  # noqa: F401
except ImportError:
    pass


def test_map_gen_has_description():
    cls = get_task("map-gen")
    assert cls.description != ""
    assert isinstance(cls.description, str)


def test_doc_gen_has_description():
    cls = get_task("doc-gen")
    assert cls.description != ""
    assert isinstance(cls.description, str)


def test_all_registered_tasks_have_descriptions():
    for name in list_tasks():
        cls = get_task(name)
        assert cls.description, f"Task '{name}' has no description"
