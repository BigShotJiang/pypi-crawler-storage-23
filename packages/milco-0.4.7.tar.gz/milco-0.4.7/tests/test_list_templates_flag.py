"""Tests for --list-templates flag."""

import milco.tasks.scaffold_task  # noqa: F401

from milco.cli import main


def test_list_templates_exits_zero(capsys):
    exit_code = main(["--list-templates"])
    assert exit_code == 0


def test_list_templates_shows_bundled_templates(capsys):
    main(["--list-templates"])
    output = capsys.readouterr().out
    assert "python_module" in output
    assert "pytest_file" in output
    assert "package_init" in output
    assert "script" in output


def test_list_templates_mentions_scaffold(capsys):
    main(["--list-templates"])
    output = capsys.readouterr().out
    assert "scaffold" in output.lower()
