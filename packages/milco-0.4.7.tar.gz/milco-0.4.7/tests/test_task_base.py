"""Tests for task base class and FixResult."""

from milco.tasks.base import FixResult


def test_fix_result_success():
    r = FixResult(success=True, applied=False, diff_text="--- a\n+++ b\n", errors=[])
    assert r.success is True
    assert r.applied is False
    assert r.diff_text == "--- a\n+++ b\n"
    assert r.errors == []


def test_fix_result_failure():
    r = FixResult(
        success=False, applied=False, diff_text="", errors=["something broke"]
    )
    assert r.success is False
    assert r.errors == ["something broke"]
