"""Tests for --list-tasks flag."""

import milco.tasks.map_gen  # noqa: F401
import milco.tasks.doc_gen  # noqa: F401

from milco.cli import main


def test_list_tasks_exits_zero(capsys):
    exit_code = main(["--list-tasks"])
    assert exit_code == 0


def test_list_tasks_shows_task_names(capsys):
    main(["--list-tasks"])
    output = capsys.readouterr().out
    assert "map-gen" in output
    assert "doc-gen" in output


def test_list_tasks_shows_descriptions(capsys):
    main(["--list-tasks"])
    output = capsys.readouterr().out
    assert "map.json" in output.lower() or "knowledge index" in output.lower()
    assert "readme" in output.lower()


def test_list_tasks_shows_llm_indicator(capsys):
    main(["--list-tasks"])
    output = capsys.readouterr().out
    assert "deterministic" in output.lower() or "llm" in output.lower()
