APP_CATEGORIES = frozenset([
    'Annotation',
    'Assembly',
    'Debugging',
    'Export',
    'Import',
    'Interactive',
    'Machine Learning',
    'Mappings Manipulation',
    'Read Manipulation',
    'Read Mapping',
    'Reports',
    'RNA-Seq',
    'Statistics',
    'Structural Variation',
    'Translational Informatics',
    'Variation Calling'
])
