"""Core compression engine."""
