"""Application package for fake repo."""
