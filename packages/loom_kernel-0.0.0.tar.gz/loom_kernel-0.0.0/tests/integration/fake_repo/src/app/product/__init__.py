from app.product.interface import ProductRestInterface

__all__ = ["ProductRestInterface"]
