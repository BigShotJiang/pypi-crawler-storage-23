"""Configuration package for fake integration repo."""
