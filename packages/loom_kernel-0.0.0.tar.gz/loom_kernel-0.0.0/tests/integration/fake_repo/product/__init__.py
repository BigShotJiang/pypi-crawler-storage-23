from tests.integration.fake_repo.product.interface import ProductRestInterface

__all__ = ["ProductRestInterface"]
