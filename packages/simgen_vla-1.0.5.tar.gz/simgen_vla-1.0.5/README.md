# SimGen

**Exact GPU Computation. Every calculation. Zero error.**

SimGen is a proprietary exact arithmetic library for GPU computing. It eliminates floating-point errors in scientific computing, machine learning, finance, and simulation.

## Installation

```bash
pip install simgen-vla
```

## Requirements

- **Linux** (Ubuntu 20.04+, RHEL 8+, or similar)
- Python 3.10+
- PyTorch 2.0+
- Triton 2.0+
- NVIDIA GPU with CUDA support:
  - T4, RTX 20xx (sm_75 Turing)
  - A10, A30, RTX 30xx (sm_80 Ampere)
  - A100 (sm_80 Ampere)
  - RTX 40xx (sm_89 Ada Lovelace)
  - H100 (sm_90 Hopper)

## Quick Start

```python
from simgen import vla

# Exact dot product
result = vla.dot(x, y)

# Exact matrix multiplication
C = vla.matmul(A, B)

# Exact cross-entropy loss
loss = vla.cross_entropy(logits, targets)

# Exact layer normalization
out = vla.layer_norm(x, normalized_shape)
```

## Operations

### Exact (Zero Error)
- `sum`, `mean` - Reductions
- `matmul`, `bmm`, `linear` - Linear algebra
- `conv1d`, `conv2d` - Convolutions
- `avg_pool2d`, `max_pool2d` - Pooling
- `mul`, `div`, `sqrt`, `exp`, `log` - Element-wise math

### Near-Exact (Up to 780M x improvement over standard)
- `softmax`, `log_softmax` - Attention
- `layer_norm`, `rms_norm`, `batch_norm`, `group_norm` - Normalization
- `cross_entropy`, `logsumexp` - Loss functions
- `gelu`, `silu`, `tanh`, `sigmoid`, `relu` - Activations

### ML Training
- `adam_step`, `adamw_step`, `sgd_step` - Optimizers
- `GradientAccumulator` - Exact gradient accumulation
- `KVCache` - Exact KV caching for inference

## Use Cases

| Domain | Benefit |
|--------|---------|
| **Finance** | Penny-perfect calculations, no rounding drift |
| **Scientific Simulation** | Exact conservation laws, reproducible results |
| **Machine Learning** | No gradient drift, exact loss computation |
| **Molecular Dynamics** | Energy conservation over billions of steps |
| **Climate Modeling** | Century-scale predictions without error accumulation |

## Benchmarks

Tested on NVIDIA T4, RTX 4070, A100:

| Operation | Improvement vs FP32 |
|-----------|---------------------|
| sigmoid | 780,000,000x |
| softmax | 629,000,000x |
| rms_norm | 537,000,000x |
| cross_entropy | 138,000,000x |
| matmul | **EXACT** |
| conv2d | **EXACT** |
| sum | **EXACT** |

## License

Proprietary. All rights reserved.
Clouthier Simulation Labs.

## Contact

- Website: https://simgen.dev
- Email: kyle@simgen.dev
