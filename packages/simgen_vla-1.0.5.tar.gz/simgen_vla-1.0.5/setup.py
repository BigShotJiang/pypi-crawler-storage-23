"""
SimGen VLA - Exact GPU Computation
==================================
Linux only. Requires NVIDIA GPU (sm_75 to sm_90).
"""

from setuptools import setup, find_packages

NAME = "simgen-vla"
VERSION = "1.0.5"
DESCRIPTION = "SimGen: Exact GPU Computation. Every calculation. Zero error."

setup(
    name=NAME,
    version=VERSION,
    description=DESCRIPTION,
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Clouthier Simulation Labs",
    author_email="kyle@simgen.dev",
    url="https://simgen.dev",
    packages=find_packages(),
    package_data={"simgen": ["*.py"]},
    install_requires=[
        "torch>=2.0",
        "triton>=2.0",
    ],
    python_requires=">=3.10",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
