"""
SimGen - Exact Computation Platform
====================================

GPU-accelerated exact arithmetic for scientific computing,
machine learning, finance, and simulation.

Every calculation. Zero error.

Usage:
    from simgen import vla

    # Exact operations
    result = vla.dot(x, y)       # Zero error dot product
    result = vla.matmul(a, b)    # Exact matrix multiplication
    loss = vla.cross_entropy(logits, targets)  # Exact loss

Website: https://simgen.dev
License: Proprietary - All rights reserved
"""

__version__ = "1.0.5"
__author__ = "Clouthier Simulation Labs"

from . import vla

__all__ = ["vla", "__version__"]
