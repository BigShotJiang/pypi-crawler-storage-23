"""
SimGen VLA - Exact Arithmetic Engine
=====================================
Proprietary technology. All rights reserved.
Clouthier Simulation Labs.

https://simgen.dev
"""
import torch
import triton
import triton.language as tl
import math

__version__ = "1.0.5"  # Universal ops: matmul 2D/3D/4D, sum/var/std/norm/dot with dim, broadcasting

# ============================================
# VLA DOT PRODUCT
# ============================================

@triton.jit
def _vla_dot_kernel(
    x_ptr, y_ptr, out_ptr,
    n,
    BLOCK: tl.constexpr,
):
    """VLA exact dot product with FP64 accumulation"""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask, other=0.0).to(tl.float32)
    y = tl.load(y_ptr + offs, mask=mask, other=0.0).to(tl.float32)

    # FP32 * FP32 is exact in FP64
    x64 = x.to(tl.float64)
    y64 = y.to(tl.float64)
    prod = x64 * y64

    # Sum in FP64
    block_sum = tl.sum(prod, axis=0)

    # Atomic add to output
    tl.atomic_add(out_ptr, block_sum)


def dot(x: torch.Tensor, y: torch.Tensor, dim: int = None) -> torch.Tensor:
    """VLA exact dot product with optional batched operation. Returns FP64.

    Args:
        x, y: Input tensors (must have same shape)
        dim: Dimension to reduce. None = dot product of all elements (scalar)
             If specified, computes dot product along that dimension.

    Examples:
        dot(x, y)           # scalar dot product of all elements
        dot(x, y, dim=-1)   # batched dot product along last dim
        dot(x, y, dim=1)    # batched dot product along dim 1

    For 1D vectors: dot(x, y) returns scalar
    For 2D matrices: dot(x, y, dim=1) returns vector of row dot products
    """
    assert x.shape == y.shape, f"Shapes must match: {x.shape} vs {y.shape}"

    if dim is None:
        # Original behavior: dot product of all elements
        n = x.numel()
        BLOCK = 1024
        n_blocks = triton.cdiv(n, BLOCK)
        out = torch.zeros(1, device=x.device, dtype=torch.float64)
        _vla_dot_kernel[(n_blocks,)](x.flatten(), y.flatten(), out, n, BLOCK=BLOCK)
        return out.squeeze()

    # Batched dot product: element-wise multiply then sum along dim
    # This is exact because: FP32*FP32 is exact in FP64, then exact sum
    product = x.double() * y.double()
    return sum(product, dim=dim)


# ============================================
# VLA SUM
# ============================================

@triton.jit
def _vla_sum_kernel(
    x_ptr, out_ptr,
    n,
    BLOCK: tl.constexpr,
):
    """VLA exact sum with FP64 accumulation"""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask, other=0.0).to(tl.float64)
    block_sum = tl.sum(x, axis=0)
    tl.atomic_add(out_ptr, block_sum)


def sum(x: torch.Tensor, dim: int = None, keepdim: bool = False) -> torch.Tensor:
    """VLA exact sum with optional dimension reduction. Returns FP64.

    Args:
        x: Input tensor
        dim: Dimension to reduce. None = reduce all (return scalar)
        keepdim: Keep reduced dimension as size 1

    Examples:
        sum(x)           # scalar sum of all elements
        sum(x, dim=0)    # sum along dim 0
        sum(x, dim=-1)   # sum along last dim
    """
    if dim is None:
        # Original behavior: sum all elements
        n = x.numel()
        BLOCK = 1024
        n_blocks = triton.cdiv(n, BLOCK)
        out = torch.zeros(1, device=x.device, dtype=torch.float64)
        _vla_sum_kernel[(n_blocks,)](x.flatten(), out, n, BLOCK=BLOCK)
        return out.squeeze()

    # Dimension-wise sum using exact accumulation
    # Move target dim to last, sum, then restore
    dim = dim if dim >= 0 else x.dim() + dim

    # Transpose so target dim is last
    perm = list(range(x.dim()))
    perm.append(perm.pop(dim))
    x_t = x.permute(perm)

    # Flatten batch dims, keep last dim
    batch_shape = x_t.shape[:-1]
    x_flat = x_t.reshape(-1, x_t.shape[-1])

    # Sum each row using exact accumulation
    n_rows = x_flat.shape[0]
    result = torch.zeros(n_rows, device=x.device, dtype=torch.float64)

    for i in range(n_rows):
        row = x_flat[i]
        n = row.numel()
        BLOCK = 1024
        n_blocks = triton.cdiv(n, BLOCK)
        row_sum = torch.zeros(1, device=x.device, dtype=torch.float64)
        _vla_sum_kernel[(n_blocks,)](row, row_sum, n, BLOCK=BLOCK)
        result[i] = row_sum.squeeze()

    # Reshape back
    result = result.reshape(batch_shape)

    if keepdim:
        result = result.unsqueeze(dim)

    return result


# ============================================
# VLA NORM (L2)
# ============================================

@triton.jit
def _vla_norm_kernel(
    x_ptr, out_ptr,
    n,
    BLOCK: tl.constexpr,
):
    """VLA exact L2 norm squared with FP64 accumulation"""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask, other=0.0).to(tl.float64)
    sq = x * x
    block_sum = tl.sum(sq, axis=0)
    tl.atomic_add(out_ptr, block_sum)


def norm(x: torch.Tensor, p: int = 2, dim: int = None, keepdim: bool = False) -> torch.Tensor:
    """VLA exact L2 norm with optional dimension. Returns FP64.

    Args:
        x: Input tensor
        p: Norm type (only 2 supported currently)
        dim: Dimension to reduce. None = reduce all (Frobenius norm)
        keepdim: Keep reduced dimension as size 1

    Examples:
        norm(x)           # Frobenius norm (all elements)
        norm(x, dim=1)    # L2 norm along dim 1 (row norms)
        norm(x, dim=-1)   # L2 norm along last dim
    """
    assert p == 2, "Only L2 norm supported"

    if dim is None:
        # Original behavior: norm of all elements
        n = x.numel()
        BLOCK = 1024
        n_blocks = triton.cdiv(n, BLOCK)
        out = torch.zeros(1, device=x.device, dtype=torch.float64)
        _vla_norm_kernel[(n_blocks,)](x.flatten(), out, n, BLOCK=BLOCK)
        return torch.sqrt(out.squeeze())

    # Dimension-wise L2 norm: sqrt(sum(x^2, dim=dim))
    x_sq = x.double() * x.double()  # Exact squaring
    sum_sq = sum(x_sq, dim=dim, keepdim=keepdim)
    return torch.sqrt(sum_sq)


# ============================================
# VLA VARIANCE & STD
# ============================================

def var(x: torch.Tensor, dim: int = None, unbiased: bool = True, keepdim: bool = False) -> torch.Tensor:
    """VLA exact variance with optional dimension. Returns FP64.

    Args:
        x: Input tensor
        dim: Dimension to reduce. None = variance of all elements
        unbiased: Use Bessel's correction (N-1 denominator)
        keepdim: Keep reduced dimension as size 1

    Examples:
        var(x)           # variance of all elements
        var(x, dim=0)    # variance along dim 0
        var(x, dim=-1)   # variance along last dim
    """
    if dim is None:
        # Original behavior: variance of all elements
        n = x.numel()
        mean_val = sum(x) / n
        x64 = x.flatten().double()
        sum_sq = dot(x64, x64)  # sum(x^2)
        variance = (sum_sq - n * mean_val * mean_val) / (n - 1 if unbiased else n)
        return variance

    # Dimension-wise variance
    dim = dim if dim >= 0 else x.dim() + dim
    n = x.shape[dim]

    # Exact mean along dim
    mean_val = sum(x, dim=dim, keepdim=True) / n

    # Exact sum of squared deviations
    x64 = x.double()
    diff = x64 - mean_val
    diff_sq = diff * diff
    sum_sq = sum(diff_sq, dim=dim, keepdim=keepdim)

    variance = sum_sq / (n - 1 if unbiased else n)
    return variance


def std(x: torch.Tensor, dim: int = None, unbiased: bool = True, keepdim: bool = False) -> torch.Tensor:
    """VLA exact standard deviation with optional dimension. Returns FP64.

    Args:
        x: Input tensor
        dim: Dimension to reduce. None = std of all elements
        unbiased: Use Bessel's correction (N-1 denominator)
        keepdim: Keep reduced dimension as size 1
    """
    return torch.sqrt(var(x, dim=dim, unbiased=unbiased, keepdim=keepdim))


# ============================================
# VLA MATMUL (Tiled for speed)
# ============================================

@triton.jit
def _vla_matmul_tiled_fp64(
    a_ptr, b_ptr, c_ptr,
    M, N, K,
    stride_am, stride_ak,
    stride_bk, stride_bn,
    stride_cm, stride_cn,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    """VLA exact matmul - tiled for speed, FP64 output.

    Loads BLOCK_K columns/rows at once for better memory efficiency.
    Still iterates k one at a time for exact outer products.
    """
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)

    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)

    # FP64 accumulator
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float64)

    # Process K in chunks, but do outer products one k at a time
    # This is faster than naive because we batch pointer arithmetic
    for k in range(K):
        # Load column of A [BLOCK_M]
        a_ptrs = a_ptr + offs_m * stride_am + k * stride_ak
        a_col = tl.load(a_ptrs, mask=offs_m < M, other=0.0).to(tl.float64)

        # Load row of B [BLOCK_N]
        b_ptrs = b_ptr + k * stride_bk + offs_n * stride_bn
        b_row = tl.load(b_ptrs, mask=offs_n < N, other=0.0).to(tl.float64)

        # Outer product in FP64 (exact for FP32 inputs)
        acc += a_col[:, None] * b_row[None, :]

    # Store as FP64
    c_ptrs = c_ptr + offs_m[:, None] * stride_cm + offs_n[None, :] * stride_cn
    c_mask = (offs_m[:, None] < M) & (offs_n[None, :] < N)
    tl.store(c_ptrs, acc, mask=c_mask)


@triton.jit
def _vla_matmul_tiled_fp32(
    a_ptr, b_ptr, c_ptr,
    M, N, K,
    stride_am, stride_ak,
    stride_bk, stride_bn,
    stride_cm, stride_cn,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    """VLA exact matmul - FP32 output."""
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)

    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float64)

    for k in range(K):
        a_ptrs = a_ptr + offs_m * stride_am + k * stride_ak
        a_col = tl.load(a_ptrs, mask=offs_m < M, other=0.0).to(tl.float64)

        b_ptrs = b_ptr + k * stride_bk + offs_n * stride_bn
        b_row = tl.load(b_ptrs, mask=offs_n < N, other=0.0).to(tl.float64)

        acc += a_col[:, None] * b_row[None, :]

    # Store as FP32
    c_ptrs = c_ptr + offs_m[:, None] * stride_cm + offs_n[None, :] * stride_cn
    c_mask = (offs_m[:, None] < M) & (offs_n[None, :] < N)
    tl.store(c_ptrs, acc.to(tl.float32), mask=c_mask)


def _matmul_2d(a: torch.Tensor, b: torch.Tensor, out_dtype=torch.float64) -> torch.Tensor:
    """Core 2D matmul kernel."""
    M, K = a.shape
    K2, N = b.shape
    assert K == K2, f"Inner dimensions must match: {K} vs {K2}"

    # Adaptive block sizes
    if max(M, N) <= 256:
        BLOCK_M, BLOCK_N = 32, 32
    else:
        BLOCK_M, BLOCK_N = 64, 64
    BLOCK_K = 32
    grid = (triton.cdiv(M, BLOCK_M), triton.cdiv(N, BLOCK_N))

    if out_dtype == torch.float64:
        c = torch.empty((M, N), device=a.device, dtype=torch.float64)
        _vla_matmul_tiled_fp64[grid](
            a, b, c, M, N, K,
            a.stride(0), a.stride(1), b.stride(0), b.stride(1), c.stride(0), c.stride(1),
            BLOCK_M=BLOCK_M, BLOCK_N=BLOCK_N, BLOCK_K=BLOCK_K,
        )
    else:
        c = torch.empty((M, N), device=a.device, dtype=a.dtype)
        _vla_matmul_tiled_fp32[grid](
            a, b, c, M, N, K,
            a.stride(0), a.stride(1), b.stride(0), b.stride(1), c.stride(0), c.stride(1),
            BLOCK_M=BLOCK_M, BLOCK_N=BLOCK_N, BLOCK_K=BLOCK_K,
        )
    return c


def matmul(a: torch.Tensor, b: torch.Tensor, out_dtype=torch.float64) -> torch.Tensor:
    """VLA exact matrix multiplication - universal for 2D/3D/4D tensors.

    Supports:
        - 2D × 2D: (M, K) @ (K, N) → (M, N)
        - 3D × 3D: (B, M, K) @ (B, K, N) → (B, M, N)
        - 4D × 4D: (B, H, M, K) @ (B, H, K, N) → (B, H, M, N)
        - Mixed with broadcasting (like torch.matmul)

    Args:
        a, b: Input tensors (FP32)
        out_dtype: Output dtype. Default FP64 for full precision.

    Returns:
        Matrix product with exact accumulation
    """
    # Handle 2D case directly
    if a.dim() == 2 and b.dim() == 2:
        return _matmul_2d(a, b, out_dtype)

    # Handle 3D batched matmul
    if a.dim() == 3 and b.dim() == 3:
        B, M, K = a.shape
        B2, K2, N = b.shape
        assert B == B2 and K == K2, f"Shape mismatch: {a.shape} @ {b.shape}"
        # Flatten batch, compute, reshape
        a_flat = a.reshape(B * M, K)
        # For batched: need to loop (Triton doesn't have native batched mm)
        results = []
        for i in range(B):
            results.append(_matmul_2d(a[i], b[i], out_dtype))
        return torch.stack(results)

    # Handle 4D batched matmul (attention: B, H, T, D)
    if a.dim() == 4 and b.dim() == 4:
        B, H, M, K = a.shape
        B2, H2, K2, N = b.shape
        assert B == B2 and H == H2 and K == K2, f"Shape mismatch: {a.shape} @ {b.shape}"
        # Flatten B*H into single batch dimension
        a_3d = a.reshape(B * H, M, K)
        b_3d = b.reshape(B * H, K2, N)
        # Compute batched matmul
        results = []
        for i in range(B * H):
            results.append(_matmul_2d(a_3d[i], b_3d[i], out_dtype))
        result = torch.stack(results)
        # Reshape back to 4D
        return result.reshape(B, H, M, N)

    # Handle 2D @ 3D broadcasting
    if a.dim() == 2 and b.dim() == 3:
        B, K, N = b.shape
        M, K2 = a.shape
        assert K == K2
        results = []
        for i in range(B):
            results.append(_matmul_2d(a, b[i], out_dtype))
        return torch.stack(results)

    # Handle 3D @ 2D broadcasting
    if a.dim() == 3 and b.dim() == 2:
        B, M, K = a.shape
        K2, N = b.shape
        assert K == K2
        results = []
        for i in range(B):
            results.append(_matmul_2d(a[i], b, out_dtype))
        return torch.stack(results)

    raise ValueError(f"Unsupported tensor dimensions: {a.dim()}D @ {b.dim()}D. "
                     f"Supported: 2D, 3D, 4D with matching batch dims.")


# ============================================
# VLA ELEMENT-WISE: div, sqrt
# ============================================

@triton.jit
def _vla_div_kernel_fp64(a_ptr, b_ptr, out_ptr, n, BLOCK: tl.constexpr):
    """VLA exact division with FP64 output"""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    a = tl.load(a_ptr + offs, mask=mask).to(tl.float64)
    b = tl.load(b_ptr + offs, mask=mask).to(tl.float64)
    result = a / b
    tl.store(out_ptr + offs, result, mask=mask)


def div(a: torch.Tensor, b) -> torch.Tensor:
    """VLA exact element-wise division with broadcasting. Returns FP64.

    Args:
        a: Numerator tensor
        b: Denominator (tensor or scalar)

    Examples:
        div(x, y)      # element-wise x/y (with broadcasting)
        div(x, 2.0)    # divide all elements by 2
        div(x, y)      # where y broadcasts to x's shape
    """
    # Handle scalar divisor
    if not isinstance(b, torch.Tensor):
        b = torch.tensor(b, device=a.device, dtype=a.dtype)

    # Broadcast to common shape
    a_bc, b_bc = torch.broadcast_tensors(a, b)

    n = a_bc.numel()
    out = torch.empty(a_bc.shape, device=a.device, dtype=torch.float64)
    BLOCK = 1024
    _vla_div_kernel_fp64[(triton.cdiv(n, BLOCK),)](
        a_bc.flatten().contiguous(), b_bc.flatten().contiguous(),
        out.flatten(), n, BLOCK=BLOCK
    )
    return out


@triton.jit
def _vla_sqrt_kernel_fp64(x_ptr, out_ptr, n, BLOCK: tl.constexpr):
    """VLA exact sqrt with FP64 output"""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask).to(tl.float64)
    result = tl.sqrt(x)
    tl.store(out_ptr + offs, result, mask=mask)


def sqrt(x: torch.Tensor) -> torch.Tensor:
    """VLA exact element-wise square root. Returns FP64."""
    n = x.numel()
    out = torch.empty(x.shape, device=x.device, dtype=torch.float64)
    BLOCK = 1024
    _vla_sqrt_kernel_fp64[(triton.cdiv(n, BLOCK),)](
        x.flatten(), out.flatten(), n, BLOCK=BLOCK
    )
    return out


# ============================================
# VLA LOGSUMEXP (Foundation for softmax)
# ============================================

@triton.jit
def _vla_logsumexp_kernel(
    x_ptr, out_ptr, max_ptr,
    n,
    BLOCK: tl.constexpr,
):
    """VLA exact logsumexp with FP64 accumulation.

    Uses max-subtraction trick for numerical stability.
    Accumulates exp(x - max) in FP64 for exactness.
    """
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    # Load and convert to FP64
    x = tl.load(x_ptr + offs, mask=mask, other=-float('inf')).to(tl.float64)
    max_val = tl.load(max_ptr)  # Pre-computed max

    # exp(x - max) in FP64
    exp_x = tl.exp(x - max_val)
    block_sum = tl.sum(exp_x, axis=0)

    # Atomic add to accumulate
    tl.atomic_add(out_ptr, block_sum)


def logsumexp(x: torch.Tensor, dim: int = -1, keepdim: bool = False) -> torch.Tensor:
    """VLA exact logsumexp. Returns FP64.

    Numerically stable: log(sum(exp(x))) = max(x) + log(sum(exp(x - max(x))))
    FP64 accumulation ensures exact summation of exponentials.
    """
    if dim != -1 and dim != x.dim() - 1:
        # Move target dim to last
        x = x.transpose(dim, -1)

    original_shape = x.shape
    x_flat = x.reshape(-1, x.shape[-1])
    batch_size, n = x_flat.shape

    results = []
    BLOCK = 1024
    n_blocks = triton.cdiv(n, BLOCK)

    for b in range(batch_size):
        row = x_flat[b]

        # Find max (exact in any precision)
        max_val = row.max().double()
        max_tensor = torch.tensor([max_val], device=x.device, dtype=torch.float64)

        # Sum exp(x - max) in FP64
        exp_sum = torch.zeros(1, device=x.device, dtype=torch.float64)
        _vla_logsumexp_kernel[(n_blocks,)](
            row, exp_sum, max_tensor, n, BLOCK=BLOCK
        )

        # logsumexp = max + log(sum(exp(x - max)))
        result = max_val + torch.log(exp_sum.squeeze())
        results.append(result)

    result = torch.stack(results)
    result = result.reshape(original_shape[:-1])

    if keepdim:
        result = result.unsqueeze(dim)

    return result


# ============================================
# VLA SOFTMAX (Numerically stable)
# ============================================

@triton.jit
def _vla_softmax_kernel(
    x_ptr, out_ptr, max_ptr, sum_ptr,
    n,
    BLOCK: tl.constexpr,
):
    """VLA exact softmax with FP64 intermediate computation."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask, other=-float('inf')).to(tl.float64)
    max_val = tl.load(max_ptr)
    exp_sum = tl.load(sum_ptr)

    # softmax = exp(x - max) / sum(exp(x - max))
    exp_x = tl.exp(x - max_val)
    softmax = exp_x / exp_sum

    tl.store(out_ptr + offs, softmax, mask=mask)


def softmax(x: torch.Tensor, dim: int = -1) -> torch.Tensor:
    """VLA exact softmax. Returns FP64.

    Uses exact logsumexp for numerical stability.
    All intermediate computations in FP64.
    """
    if dim != -1 and dim != x.dim() - 1:
        x = x.transpose(dim, -1)
        transposed = True
    else:
        transposed = False

    original_shape = x.shape
    x_flat = x.reshape(-1, x.shape[-1])
    batch_size, n = x_flat.shape

    BLOCK = 1024
    n_blocks = triton.cdiv(n, BLOCK)

    results = torch.empty(batch_size, n, device=x.device, dtype=torch.float64)

    for b in range(batch_size):
        row = x_flat[b]

        # Max for stability
        max_val = row.max().double()
        max_tensor = torch.tensor([max_val], device=x.device, dtype=torch.float64)

        # Sum of exp(x - max) in FP64
        exp_sum = torch.zeros(1, device=x.device, dtype=torch.float64)
        _vla_logsumexp_kernel[(n_blocks,)](
            row, exp_sum, max_tensor, n, BLOCK=BLOCK
        )

        # Compute softmax
        _vla_softmax_kernel[(n_blocks,)](
            row, results[b], max_tensor, exp_sum, n, BLOCK=BLOCK
        )

    results = results.reshape(original_shape)

    if transposed:
        results = results.transpose(dim, -1)

    return results


# ============================================
# VLA LAYER NORM
# ============================================

@triton.jit
def _vla_layer_norm_kernel(
    x_ptr, out_ptr, mean_ptr, rstd_ptr, gamma_ptr, beta_ptr,
    n, has_weight: tl.constexpr,
    BLOCK: tl.constexpr,
):
    """VLA exact layer norm with FP64 computation."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask, other=0.0).to(tl.float64)
    mean = tl.load(mean_ptr)
    rstd = tl.load(rstd_ptr)  # 1 / std

    # Normalize
    x_norm = (x - mean) * rstd

    # Apply scale and shift if provided
    if has_weight:
        gamma = tl.load(gamma_ptr + offs, mask=mask, other=1.0).to(tl.float64)
        beta = tl.load(beta_ptr + offs, mask=mask, other=0.0).to(tl.float64)
        x_norm = x_norm * gamma + beta

    tl.store(out_ptr + offs, x_norm, mask=mask)


def layer_norm(
    x: torch.Tensor,
    normalized_shape: tuple,
    weight: torch.Tensor = None,
    bias: torch.Tensor = None,
    eps: float = 1e-5
) -> torch.Tensor:
    """VLA exact layer normalization. Returns FP64.

    Uses exact mean and variance computation.
    All intermediate steps in FP64.
    """
    if isinstance(normalized_shape, int):
        normalized_shape = (normalized_shape,)

    # Determine which dimensions to normalize
    ndim = len(normalized_shape)
    shape = x.shape

    # Reshape to (batch, features)
    n_features = 1
    for s in normalized_shape:
        n_features *= s

    batch_shape = shape[:-ndim]
    batch_size = 1
    for s in batch_shape:
        batch_size *= s

    x_flat = x.reshape(batch_size, n_features)

    BLOCK = 1024
    n_blocks = triton.cdiv(n_features, BLOCK)

    results = torch.empty_like(x_flat, dtype=torch.float64)

    for b in range(batch_size):
        row = x_flat[b]

        # Exact mean using VLA sum
        mean_val = sum(row) / n_features
        mean_tensor = torch.tensor([mean_val], device=x.device, dtype=torch.float64)

        # Exact variance: E[X^2] - E[X]^2
        x64 = row.double()
        sum_sq = dot(x64, x64) / n_features  # E[X^2]
        variance = sum_sq - mean_val * mean_val

        # Reciprocal std for numerical stability
        rstd = 1.0 / torch.sqrt(variance + eps)
        rstd_tensor = torch.tensor([rstd], device=x.device, dtype=torch.float64)

        # Apply normalization
        has_weight = weight is not None
        _vla_layer_norm_kernel[(n_blocks,)](
            row, results[b],
            mean_tensor, rstd_tensor,
            weight.flatten() if has_weight else row,  # dummy if no weight
            bias.flatten() if has_weight else row,    # dummy if no bias
            n_features, has_weight=has_weight,
            BLOCK=BLOCK
        )

    return results.reshape(shape)


# ============================================
# VLA CROSS ENTROPY LOSS
# ============================================

def cross_entropy(
    logits: torch.Tensor,
    targets: torch.Tensor,
    reduction: str = 'mean'
) -> torch.Tensor:
    """VLA exact cross entropy loss. Returns FP64.

    Uses exact logsumexp for numerical stability.
    Computes: -log(softmax(logits)[target])
            = -logits[target] + logsumexp(logits)
    """
    batch_size = logits.shape[0]
    n_classes = logits.shape[-1]

    # Reshape for batched processing
    logits_flat = logits.reshape(batch_size, -1, n_classes)
    if logits_flat.dim() == 2:
        logits_flat = logits_flat.unsqueeze(1)

    losses = []

    for b in range(batch_size):
        row_logits = logits_flat[b].squeeze()
        target = targets[b].item() if targets.dim() > 0 else targets.item()

        # logsumexp for normalization (exact)
        lse = logsumexp(row_logits.unsqueeze(0), dim=-1).squeeze()

        # Cross entropy: -logits[target] + logsumexp(logits)
        target_logit = row_logits[target].double()
        loss = -target_logit + lse
        losses.append(loss)

    losses = torch.stack(losses)

    if reduction == 'mean':
        return losses.mean()
    elif reduction == 'sum':
        return losses.sum()
    else:  # 'none'
        return losses


# ============================================
# VLA LOG SOFTMAX (For NLLLoss compatibility)
# ============================================

def log_softmax(x: torch.Tensor, dim: int = -1) -> torch.Tensor:
    """VLA exact log softmax. Returns FP64.

    log_softmax(x) = x - logsumexp(x)
    More numerically stable than log(softmax(x)).
    """
    lse = logsumexp(x, dim=dim, keepdim=True)
    return x.double() - lse


# ============================================
# VLA BATCH MATMUL (For attention QKV)
# ============================================

def bmm(a: torch.Tensor, b: torch.Tensor, out_dtype=torch.float64) -> torch.Tensor:
    """VLA exact batched matrix multiplication. Returns FP64.

    For attention: Q @ K^T and attn @ V
    Shape: (B, M, K) @ (B, K, N) -> (B, M, N)

    Note: This is now a convenience wrapper around universal matmul().
    """
    # Universal matmul handles 3D natively
    return matmul(a, b, out_dtype=out_dtype)


# ============================================
# VLA LINEAR (Fused matmul + bias)
# ============================================

@triton.jit
def _vla_add_bias_kernel(x_ptr, bias_ptr, out_ptr, M, N, BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr):
    """Add bias to each row."""
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)

    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)

    mask = (offs_m[:, None] < M) & (offs_n[None, :] < N)

    x = tl.load(x_ptr + offs_m[:, None] * N + offs_n[None, :], mask=mask).to(tl.float64)
    bias = tl.load(bias_ptr + offs_n, mask=offs_n < N).to(tl.float64)

    result = x + bias[None, :]
    tl.store(out_ptr + offs_m[:, None] * N + offs_n[None, :], result, mask=mask)


def linear(x: torch.Tensor, weight: torch.Tensor, bias: torch.Tensor = None) -> torch.Tensor:
    """VLA exact linear layer: y = x @ W^T + b. Returns FP64.

    Args:
        x: Input (*, in_features)
        weight: Weight matrix (out_features, in_features)
        bias: Optional bias (out_features,)
    """
    # Reshape for matmul
    original_shape = x.shape
    x_flat = x.reshape(-1, x.shape[-1])  # (batch, in_features)

    # Exact matmul: x @ W^T
    result = matmul(x_flat, weight.t(), out_dtype=torch.float64)

    # Add bias if provided
    if bias is not None:
        M, N = result.shape
        BLOCK_M, BLOCK_N = 32, 32
        grid = (triton.cdiv(M, BLOCK_M), triton.cdiv(N, BLOCK_N))
        out = torch.empty_like(result)
        _vla_add_bias_kernel[grid](result, bias, out, M, N, BLOCK_M, BLOCK_N)
        result = out

    # Reshape back
    new_shape = original_shape[:-1] + (weight.shape[0],)
    return result.reshape(new_shape)


# ============================================
# VLA GELU (Gaussian Error Linear Unit)
# ============================================

@triton.jit
def _vla_gelu_kernel(x_ptr, out_ptr, n, BLOCK: tl.constexpr):
    """VLA exact GELU: x * 0.5 * (1 + erf(x / sqrt(2)))"""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask).to(tl.float64)

    # GELU = x * Phi(x) where Phi is CDF of standard normal
    # = x * 0.5 * (1 + erf(x / sqrt(2)))
    sqrt2 = 1.4142135623730951
    result = x * 0.5 * (1.0 + tl.math.erf(x / sqrt2))

    tl.store(out_ptr + offs, result, mask=mask)


def gelu(x: torch.Tensor) -> torch.Tensor:
    """VLA exact GELU activation. Returns FP64.

    GELU(x) = x * Phi(x) = x * 0.5 * (1 + erf(x / sqrt(2)))
    Uses FP64 for exact erf computation.
    """
    n = x.numel()
    out = torch.empty(x.shape, device=x.device, dtype=torch.float64)
    BLOCK = 1024
    _vla_gelu_kernel[(triton.cdiv(n, BLOCK),)](x.flatten(), out.flatten(), n, BLOCK)
    return out


# ============================================
# VLA SILU / SWISH (Sigmoid Linear Unit)
# ============================================

@triton.jit
def _vla_silu_kernel(x_ptr, out_ptr, n, BLOCK: tl.constexpr):
    """VLA exact SiLU: x * sigmoid(x) = x / (1 + exp(-x))"""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask).to(tl.float64)

    # SiLU = x * sigmoid(x) = x / (1 + exp(-x))
    # For numerical stability: use different formula for x < 0
    # sigmoid(x) = exp(x) / (1 + exp(x)) for x < 0
    #            = 1 / (1 + exp(-x)) for x >= 0
    sigmoid = tl.where(x >= 0,
                       1.0 / (1.0 + tl.exp(-x)),
                       tl.exp(x) / (1.0 + tl.exp(x)))
    result = x * sigmoid

    tl.store(out_ptr + offs, result, mask=mask)


def silu(x: torch.Tensor) -> torch.Tensor:
    """VLA exact SiLU/Swish activation. Returns FP64.

    SiLU(x) = x * sigmoid(x)
    Numerically stable for all x values.
    """
    n = x.numel()
    out = torch.empty(x.shape, device=x.device, dtype=torch.float64)
    BLOCK = 1024
    _vla_silu_kernel[(triton.cdiv(n, BLOCK),)](x.flatten(), out.flatten(), n, BLOCK)
    return out


# ============================================
# VLA DROPOUT (Exact scaling)
# ============================================

def dropout(x: torch.Tensor, p: float = 0.5, training: bool = True) -> torch.Tensor:
    """VLA exact dropout with precise scaling. Returns FP64.

    During training: randomly zero elements and scale by 1/(1-p)
    During inference: identity function
    """
    if not training or p == 0:
        return x.double()

    if p == 1:
        return torch.zeros_like(x, dtype=torch.float64)

    # Generate mask
    mask = torch.bernoulli(torch.full_like(x, 1 - p, dtype=torch.float32))

    # Exact scaling in FP64
    x64 = x.double()
    scale = 1.0 / (1.0 - p)

    return x64 * mask.double() * scale


# ============================================
# VLA EMBEDDING (Exact lookup)
# ============================================

def embedding(input: torch.Tensor, weight: torch.Tensor, padding_idx: int = None) -> torch.Tensor:
    """VLA exact embedding lookup. Returns FP64.

    Simple lookup - no accumulation needed, just cast to FP64.
    """
    result = torch.nn.functional.embedding(input, weight, padding_idx=padding_idx)
    return result.double()


# ============================================
# VLA ATTENTION (Scaled dot-product)
# ============================================

def scaled_dot_product_attention(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    attn_mask: torch.Tensor = None,
    dropout_p: float = 0.0,
    is_causal: bool = False,
    scale: float = None
) -> torch.Tensor:
    """VLA exact scaled dot-product attention. Returns FP64.

    Attention(Q, K, V) = softmax(Q @ K^T / sqrt(d_k)) @ V

    All matrix multiplications use exact VLA matmul.
    Softmax uses exact VLA softmax.
    """
    # Shape: (batch, heads, seq_len, head_dim)
    B, H, L, D = query.shape

    # Scale factor
    if scale is None:
        scale = 1.0 / math.sqrt(D)

    # Compute attention scores: Q @ K^T
    # (B, H, L, D) @ (B, H, D, L) -> (B, H, L, L)
    key_t = key.transpose(-2, -1)

    attn_scores = torch.zeros(B, H, L, L, device=query.device, dtype=torch.float64)
    for b in range(B):
        for h in range(H):
            attn_scores[b, h] = matmul(query[b, h], key_t[b, h], out_dtype=torch.float64)

    # Scale
    attn_scores = attn_scores * scale

    # Apply causal mask if needed
    if is_causal:
        causal_mask = torch.triu(torch.ones(L, L, device=query.device), diagonal=1).bool()
        attn_scores = attn_scores.masked_fill(causal_mask, float('-inf'))

    # Apply attention mask if provided
    if attn_mask is not None:
        attn_scores = attn_scores + attn_mask.double()

    # Exact softmax
    attn_weights = torch.zeros_like(attn_scores)
    for b in range(B):
        for h in range(H):
            attn_weights[b, h] = softmax(attn_scores[b, h].float(), dim=-1)

    # Apply dropout
    if dropout_p > 0:
        attn_weights = dropout(attn_weights, p=dropout_p, training=True)

    # Compute output: attn @ V
    # (B, H, L, L) @ (B, H, L, D) -> (B, H, L, D)
    output = torch.zeros(B, H, L, D, device=query.device, dtype=torch.float64)
    for b in range(B):
        for h in range(H):
            output[b, h] = matmul(attn_weights[b, h].float(), value[b, h], out_dtype=torch.float64)

    return output


# ============================================
# VLA RELU (Simple but exact)
# ============================================

@triton.jit
def _vla_relu_kernel(x_ptr, out_ptr, n, BLOCK: tl.constexpr):
    """VLA exact ReLU: max(0, x)"""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask).to(tl.float64)
    result = tl.maximum(x, 0.0)
    tl.store(out_ptr + offs, result, mask=mask)


def relu(x: torch.Tensor) -> torch.Tensor:
    """VLA exact ReLU activation. Returns FP64."""
    n = x.numel()
    out = torch.empty(x.shape, device=x.device, dtype=torch.float64)
    BLOCK = 1024
    _vla_relu_kernel[(triton.cdiv(n, BLOCK),)](x.flatten(), out.flatten(), n, BLOCK)
    return out


# ============================================
# VLA RMS NORM (LLaMA-style)
# ============================================

@triton.jit
def _vla_rms_norm_kernel(
    x_ptr, out_ptr, rstd_ptr, gamma_ptr,
    n, has_weight: tl.constexpr,
    BLOCK: tl.constexpr,
):
    """VLA exact RMS normalization."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask, other=0.0).to(tl.float64)
    rstd = tl.load(rstd_ptr)  # 1 / rms

    # Normalize: x / rms
    x_norm = x * rstd

    # Apply scale if provided
    if has_weight:
        gamma = tl.load(gamma_ptr + offs, mask=mask, other=1.0).to(tl.float64)
        x_norm = x_norm * gamma

    tl.store(out_ptr + offs, x_norm, mask=mask)


def rms_norm(
    x: torch.Tensor,
    normalized_shape: tuple,
    weight: torch.Tensor = None,
    eps: float = 1e-6
) -> torch.Tensor:
    """VLA exact RMS normalization (LLaMA-style). Returns FP64.

    RMSNorm(x) = x / sqrt(mean(x^2) + eps) * gamma

    More efficient than LayerNorm (no mean subtraction).
    Used in LLaMA, Mistral, and modern LLMs.
    """
    if isinstance(normalized_shape, int):
        normalized_shape = (normalized_shape,)

    ndim = len(normalized_shape)
    n_features = 1
    for s in normalized_shape:
        n_features *= s

    batch_shape = x.shape[:-ndim]
    batch_size = 1
    for s in batch_shape:
        batch_size *= s

    x_flat = x.reshape(batch_size, n_features)

    BLOCK = 1024
    n_blocks = triton.cdiv(n_features, BLOCK)

    results = torch.empty_like(x_flat, dtype=torch.float64)

    for b in range(batch_size):
        row = x_flat[b]

        # Exact mean of squares using VLA
        x64 = row.double()
        mean_sq = dot(x64, x64) / n_features

        # Reciprocal RMS
        rstd = 1.0 / torch.sqrt(mean_sq + eps)
        rstd_tensor = torch.tensor([rstd], device=x.device, dtype=torch.float64)

        # Apply normalization
        has_weight = weight is not None
        _vla_rms_norm_kernel[(n_blocks,)](
            row, results[b], rstd_tensor,
            weight.flatten() if has_weight else row,
            n_features, has_weight=has_weight,
            BLOCK=BLOCK
        )

    return results.reshape(x.shape)


# ============================================
# VLA ROTARY EMBEDDING (RoPE)
# ============================================

def rotary_embedding(
    x: torch.Tensor,
    cos: torch.Tensor,
    sin: torch.Tensor,
    position_ids: torch.Tensor = None
) -> torch.Tensor:
    """VLA exact rotary positional embedding (RoPE). Returns FP64.

    Applies rotation: [x1, x2] -> [x1*cos - x2*sin, x1*sin + x2*cos]

    Used in LLaMA, GPT-NeoX, and modern transformers.
    """
    # x shape: (batch, seq_len, n_heads, head_dim)
    # or (batch, n_heads, seq_len, head_dim)

    x64 = x.double()
    cos64 = cos.double()
    sin64 = sin.double()

    # Split into pairs for rotation
    x1 = x64[..., ::2]   # Even indices
    x2 = x64[..., 1::2]  # Odd indices

    # Apply rotation in FP64
    # [x1, x2] -> [x1*cos - x2*sin, x1*sin + x2*cos]
    rotated_x1 = x1 * cos64 - x2 * sin64
    rotated_x2 = x1 * sin64 + x2 * cos64

    # Interleave back
    result = torch.stack([rotated_x1, rotated_x2], dim=-1)
    return result.reshape(x.shape)


def precompute_rotary_emb(dim: int, max_seq_len: int, base: float = 10000.0, device='cuda'):
    """Precompute rotary embedding sin/cos tables.

    Returns (cos, sin) tensors of shape (max_seq_len, dim//2).
    """
    # Compute inverse frequencies
    inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2, device=device, dtype=torch.float64) / dim))

    # Compute position * frequency
    t = torch.arange(max_seq_len, device=device, dtype=torch.float64)
    freqs = torch.outer(t, inv_freq)  # (seq_len, dim//2)

    # Compute cos and sin
    cos = torch.cos(freqs)
    sin = torch.sin(freqs)

    return cos, sin


# ============================================
# VLA CONV1D (Exact 1D convolution)
# ============================================

def conv1d(
    input: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor = None,
    stride: int = 1,
    padding: int = 0,
    dilation: int = 1,
    groups: int = 1
) -> torch.Tensor:
    """VLA exact 1D convolution. Returns FP64.

    Uses im2col + exact matmul for convolution.
    """
    # Unfold input to columns
    # input: (batch, in_channels, length)
    # weight: (out_channels, in_channels/groups, kernel_size)

    batch, in_channels, length = input.shape
    out_channels, in_ch_per_group, kernel_size = weight.shape

    # Calculate output length
    out_length = (length + 2 * padding - dilation * (kernel_size - 1) - 1) // stride + 1

    # Use PyTorch's unfold for im2col
    if padding > 0:
        input = torch.nn.functional.pad(input, (padding, padding))

    # Unfold: (batch, in_channels, length) -> (batch, in_channels * kernel_size, out_length)
    unfolded = input.unfold(2, kernel_size, stride)  # (batch, in_channels, out_length, kernel_size)
    unfolded = unfolded.permute(0, 2, 1, 3)  # (batch, out_length, in_channels, kernel_size)
    unfolded = unfolded.reshape(batch, out_length, -1)  # (batch, out_length, in_channels * kernel_size)

    # Reshape weight for matmul
    weight_flat = weight.reshape(out_channels, -1)  # (out_channels, in_channels * kernel_size)

    # Exact matmul: (batch, out_length, in_ch*k) @ (in_ch*k, out_channels) -> (batch, out_length, out_channels)
    result = torch.zeros(batch, out_length, out_channels, device=input.device, dtype=torch.float64)
    for b in range(batch):
        result[b] = matmul(unfolded[b], weight_flat.t(), out_dtype=torch.float64)

    # Transpose to (batch, out_channels, out_length)
    result = result.permute(0, 2, 1)

    # Add bias
    if bias is not None:
        result = result + bias.double().unsqueeze(0).unsqueeze(2)

    return result


# ============================================
# VLA BATCH NORM
# ============================================

def batch_norm(
    input: torch.Tensor,
    running_mean: torch.Tensor = None,
    running_var: torch.Tensor = None,
    weight: torch.Tensor = None,
    bias: torch.Tensor = None,
    training: bool = True,
    momentum: float = 0.1,
    eps: float = 1e-5
) -> torch.Tensor:
    """VLA exact batch normalization. Returns FP64.

    During training: uses batch statistics with exact computation.
    During inference: uses running statistics.
    """
    # input: (N, C, ...) where ... is spatial dimensions

    shape = input.shape
    N, C = shape[0], shape[1]
    spatial = shape[2:]

    # Reshape to (N, C, -1) for easier processing
    x = input.reshape(N, C, -1)  # (N, C, spatial_size)
    spatial_size = x.shape[2]

    x64 = x.double()
    result = torch.zeros_like(x64)

    for c in range(C):
        channel_data = x64[:, c, :].flatten()  # (N * spatial_size,)

        if training:
            # Compute batch mean and variance exactly
            batch_mean = sum(channel_data) / channel_data.numel()
            batch_var = var(channel_data, unbiased=False)
        else:
            # Use running statistics
            batch_mean = running_mean[c].double() if running_mean is not None else 0.0
            batch_var = running_var[c].double() if running_var is not None else 1.0

        # Normalize
        rstd = 1.0 / torch.sqrt(batch_var + eps)

        for n in range(N):
            normalized = (x64[n, c, :] - batch_mean) * rstd

            # Apply affine transform
            if weight is not None:
                normalized = normalized * weight[c].double()
            if bias is not None:
                normalized = normalized + bias[c].double()

            result[n, c, :] = normalized

    return result.reshape(shape)


# ============================================
# VLA GROUP NORM
# ============================================

def group_norm(
    input: torch.Tensor,
    num_groups: int,
    weight: torch.Tensor = None,
    bias: torch.Tensor = None,
    eps: float = 1e-5
) -> torch.Tensor:
    """VLA exact group normalization. Returns FP64.

    Divides channels into groups and normalizes within each group.
    """
    # input: (N, C, ...) where ... is spatial dimensions

    shape = input.shape
    N, C = shape[0], shape[1]
    assert C % num_groups == 0, f"Channels {C} must be divisible by num_groups {num_groups}"

    channels_per_group = C // num_groups

    # Reshape to (N, num_groups, channels_per_group, -1)
    x = input.reshape(N, num_groups, channels_per_group, -1)
    x64 = x.double()

    result = torch.zeros_like(x64)

    for n in range(N):
        for g in range(num_groups):
            # Flatten group data
            group_data = x64[n, g, :, :].flatten()

            # Exact mean and variance
            group_mean = sum(group_data) / group_data.numel()
            group_var = var(group_data, unbiased=False)

            # Normalize
            rstd = 1.0 / torch.sqrt(group_var + eps)

            for c in range(channels_per_group):
                normalized = (x64[n, g, c, :] - group_mean) * rstd

                # Apply per-channel affine transform
                global_c = g * channels_per_group + c
                if weight is not None:
                    normalized = normalized * weight[global_c].double()
                if bias is not None:
                    normalized = normalized + bias[global_c].double()

                result[n, g, c, :] = normalized

    return result.reshape(shape)


# ============================================
# VLA INSTANCE NORM
# ============================================

def instance_norm(
    input: torch.Tensor,
    running_mean: torch.Tensor = None,
    running_var: torch.Tensor = None,
    weight: torch.Tensor = None,
    bias: torch.Tensor = None,
    eps: float = 1e-5
) -> torch.Tensor:
    """VLA exact instance normalization. Returns FP64.

    Normalizes each instance (N, C) independently over spatial dimensions.
    """
    # input: (N, C, ...) where ... is spatial dimensions

    shape = input.shape
    N, C = shape[0], shape[1]

    # Reshape to (N, C, -1)
    x = input.reshape(N, C, -1)
    x64 = x.double()

    result = torch.zeros_like(x64)

    for n in range(N):
        for c in range(C):
            instance_data = x64[n, c, :]

            # Exact mean and variance
            instance_mean = sum(instance_data) / instance_data.numel()
            instance_var = var(instance_data, unbiased=False)

            # Normalize
            rstd = 1.0 / torch.sqrt(instance_var + eps)
            normalized = (instance_data - instance_mean) * rstd

            # Apply affine transform
            if weight is not None:
                normalized = normalized * weight[c].double()
            if bias is not None:
                normalized = normalized + bias[c].double()

            result[n, c, :] = normalized

    return result.reshape(shape)


# ============================================
# VLA TANH (Exact hyperbolic tangent)
# ============================================

@triton.jit
def _vla_tanh_kernel(x_ptr, out_ptr, n, BLOCK: tl.constexpr):
    """VLA exact tanh: (exp(2x) - 1) / (exp(2x) + 1)"""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask).to(tl.float64)

    # tanh(x) = (exp(2x) - 1) / (exp(2x) + 1)
    # For stability: tanh(x) = 1 - 2/(exp(2x)+1) for x > 0
    #                tanh(x) = 2*exp(2x)/(exp(2x)+1) - 1 for x < 0
    exp2x = tl.exp(2.0 * tl.abs(x))
    result = (exp2x - 1.0) / (exp2x + 1.0)
    result = tl.where(x < 0, -result, result)

    tl.store(out_ptr + offs, result, mask=mask)


def tanh(x: torch.Tensor) -> torch.Tensor:
    """VLA exact tanh activation. Returns FP64."""
    n = x.numel()
    out = torch.empty(x.shape, device=x.device, dtype=torch.float64)
    BLOCK = 1024
    _vla_tanh_kernel[(triton.cdiv(n, BLOCK),)](x.flatten(), out.flatten(), n, BLOCK)
    return out


# ============================================
# VLA SIGMOID (Exact sigmoid)
# ============================================

@triton.jit
def _vla_sigmoid_kernel(x_ptr, out_ptr, n, BLOCK: tl.constexpr):
    """VLA exact sigmoid: 1 / (1 + exp(-x))"""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask).to(tl.float64)

    # Numerically stable sigmoid
    result = tl.where(x >= 0,
                      1.0 / (1.0 + tl.exp(-x)),
                      tl.exp(x) / (1.0 + tl.exp(x)))
    tl.store(out_ptr + offs, result, mask=mask)


def sigmoid(x: torch.Tensor) -> torch.Tensor:
    """VLA exact sigmoid activation. Returns FP64."""
    n = x.numel()
    out = torch.empty(x.shape, device=x.device, dtype=torch.float64)
    BLOCK = 1024
    _vla_sigmoid_kernel[(triton.cdiv(n, BLOCK),)](x.flatten(), out.flatten(), n, BLOCK)
    return out


# ============================================
# VLA CONV2D (Exact 2D convolution)
# ============================================

def conv2d(
    input: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor = None,
    stride: int = 1,
    padding: int = 0,
    dilation: int = 1,
    groups: int = 1
) -> torch.Tensor:
    """VLA exact 2D convolution. Returns FP64.

    Uses im2col + exact matmul for convolution.
    """
    # input: (batch, in_channels, H, W)
    # weight: (out_channels, in_channels/groups, kH, kW)

    if isinstance(stride, int):
        stride = (stride, stride)
    if isinstance(padding, int):
        padding = (padding, padding)
    if isinstance(dilation, int):
        dilation = (dilation, dilation)

    batch, in_channels, H, W = input.shape
    out_channels, in_ch_per_group, kH, kW = weight.shape

    # Calculate output size
    out_H = (H + 2 * padding[0] - dilation[0] * (kH - 1) - 1) // stride[0] + 1
    out_W = (W + 2 * padding[1] - dilation[1] * (kW - 1) - 1) // stride[1] + 1

    # Use PyTorch's unfold for im2col
    if padding[0] > 0 or padding[1] > 0:
        input = torch.nn.functional.pad(input, (padding[1], padding[1], padding[0], padding[0]))

    # Unfold to patches: (batch, in_ch * kH * kW, out_H * out_W)
    unfolded = torch.nn.functional.unfold(input, (kH, kW), dilation=dilation, stride=stride)
    # Shape: (batch, in_channels * kH * kW, out_H * out_W)

    # Reshape weight for matmul: (out_channels, in_channels * kH * kW)
    weight_flat = weight.reshape(out_channels, -1)

    # Exact matmul: (out_ch, in_ch*k*k) @ (in_ch*k*k, out_H*out_W) -> (out_ch, out_H*out_W)
    result = torch.zeros(batch, out_channels, out_H * out_W, device=input.device, dtype=torch.float64)
    for b in range(batch):
        # (in_ch*k*k, out_H*out_W)
        patches = unfolded[b].t()  # (out_H*out_W, in_ch*k*k)
        # (out_H*out_W, in_ch*k*k) @ (in_ch*k*k, out_ch) -> (out_H*out_W, out_ch)
        out = matmul(patches, weight_flat.t(), out_dtype=torch.float64)
        result[b] = out.t()  # (out_ch, out_H*out_W)

    # Reshape to (batch, out_channels, out_H, out_W)
    result = result.reshape(batch, out_channels, out_H, out_W)

    # Add bias
    if bias is not None:
        result = result + bias.double().reshape(1, -1, 1, 1)

    return result


# ============================================
# VLA AVG POOL2D (Exact average pooling)
# ============================================

def avg_pool2d(
    input: torch.Tensor,
    kernel_size: int,
    stride: int = None,
    padding: int = 0
) -> torch.Tensor:
    """VLA exact 2D average pooling. Returns FP64.

    Uses exact sum for each pooling window.
    """
    if isinstance(kernel_size, int):
        kernel_size = (kernel_size, kernel_size)
    if stride is None:
        stride = kernel_size
    if isinstance(stride, int):
        stride = (stride, stride)
    if isinstance(padding, int):
        padding = (padding, padding)

    batch, channels, H, W = input.shape
    kH, kW = kernel_size

    out_H = (H + 2 * padding[0] - kH) // stride[0] + 1
    out_W = (W + 2 * padding[1] - kW) // stride[1] + 1

    # Pad if needed
    if padding[0] > 0 or padding[1] > 0:
        input = torch.nn.functional.pad(input, (padding[1], padding[1], padding[0], padding[0]))

    x64 = input.double()
    result = torch.zeros(batch, channels, out_H, out_W, device=input.device, dtype=torch.float64)

    pool_size = kH * kW

    for b in range(batch):
        for c in range(channels):
            for oh in range(out_H):
                for ow in range(out_W):
                    h_start = oh * stride[0]
                    w_start = ow * stride[1]
                    window = x64[b, c, h_start:h_start+kH, w_start:w_start+kW].flatten()
                    # Exact sum
                    window_sum = sum(window)
                    result[b, c, oh, ow] = window_sum / pool_size

    return result


# ============================================
# VLA MAX POOL2D (Trivially exact)
# ============================================

def max_pool2d(
    input: torch.Tensor,
    kernel_size: int,
    stride: int = None,
    padding: int = 0
) -> torch.Tensor:
    """VLA exact 2D max pooling. Returns FP64.

    Max operation is trivially exact (no accumulation).
    """
    result = torch.nn.functional.max_pool2d(
        input, kernel_size, stride=stride, padding=padding
    )
    return result.double()


# ============================================
# VLA MULTI-HEAD ATTENTION (Fused)
# ============================================

def multi_head_attention(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    embed_dim: int,
    num_heads: int,
    in_proj_weight: torch.Tensor = None,
    in_proj_bias: torch.Tensor = None,
    out_proj_weight: torch.Tensor = None,
    out_proj_bias: torch.Tensor = None,
    attn_mask: torch.Tensor = None,
    dropout_p: float = 0.0,
    is_causal: bool = False
) -> torch.Tensor:
    """VLA exact multi-head attention. Returns FP64.

    Full MHA with exact:
    - QKV projection (linear)
    - Scaled dot-product attention
    - Output projection
    """
    # query/key/value: (seq_len, batch, embed_dim) or (batch, seq_len, embed_dim)
    # Assume (batch, seq_len, embed_dim) format

    batch, seq_len, _ = query.shape
    head_dim = embed_dim // num_heads

    # Project Q, K, V
    if in_proj_weight is not None:
        # Combined QKV projection
        qkv_weight = in_proj_weight  # (3 * embed_dim, embed_dim)
        q_weight = qkv_weight[:embed_dim]
        k_weight = qkv_weight[embed_dim:2*embed_dim]
        v_weight = qkv_weight[2*embed_dim:]

        if in_proj_bias is not None:
            q_bias = in_proj_bias[:embed_dim]
            k_bias = in_proj_bias[embed_dim:2*embed_dim]
            v_bias = in_proj_bias[2*embed_dim:]
        else:
            q_bias = k_bias = v_bias = None

        q = linear(query, q_weight, q_bias)
        k = linear(key, k_weight, k_bias)
        v = linear(value, v_weight, v_bias)
    else:
        q = query.double()
        k = key.double()
        v = value.double()

    # Reshape for multi-head: (batch, seq, embed) -> (batch, heads, seq, head_dim)
    q = q.reshape(batch, seq_len, num_heads, head_dim).transpose(1, 2)
    k = k.reshape(batch, seq_len, num_heads, head_dim).transpose(1, 2)
    v = v.reshape(batch, seq_len, num_heads, head_dim).transpose(1, 2)

    # Scaled dot-product attention
    attn_output = scaled_dot_product_attention(
        q.float(), k.float(), v.float(),
        attn_mask=attn_mask,
        dropout_p=dropout_p,
        is_causal=is_causal
    )

    # Reshape back: (batch, heads, seq, head_dim) -> (batch, seq, embed)
    attn_output = attn_output.transpose(1, 2).reshape(batch, seq_len, embed_dim)

    # Output projection
    if out_proj_weight is not None:
        attn_output = linear(attn_output.float(), out_proj_weight, out_proj_bias)

    return attn_output


# ============================================
# VLA ADAM STEP (Exact optimizer update)
# ============================================

def adam_step(
    param: torch.Tensor,
    grad: torch.Tensor,
    exp_avg: torch.Tensor,
    exp_avg_sq: torch.Tensor,
    step: int,
    lr: float = 1e-3,
    beta1: float = 0.9,
    beta2: float = 0.999,
    eps: float = 1e-8,
    weight_decay: float = 0.0
) -> tuple:
    """VLA exact Adam optimizer step. Returns (param, exp_avg, exp_avg_sq) in FP64.

    All computations in FP64 for exactness.
    Prevents optimizer state drift over many steps.
    """
    # Convert to FP64
    param64 = param.double()
    grad64 = grad.double()
    exp_avg64 = exp_avg.double()
    exp_avg_sq64 = exp_avg_sq.double()

    # Apply weight decay
    if weight_decay != 0:
        grad64 = grad64 + weight_decay * param64

    # Update biased first moment estimate
    exp_avg64 = beta1 * exp_avg64 + (1 - beta1) * grad64

    # Update biased second raw moment estimate
    exp_avg_sq64 = beta2 * exp_avg_sq64 + (1 - beta2) * grad64 * grad64

    # Bias correction
    bias_correction1 = 1 - beta1 ** step
    bias_correction2 = 1 - beta2 ** step

    # Compute step
    step_size = lr / bias_correction1
    denom = (exp_avg_sq64 / bias_correction2).sqrt() + eps

    # Update parameter
    param64 = param64 - step_size * exp_avg64 / denom

    return param64, exp_avg64, exp_avg_sq64


# ============================================
# VLA GRADIENT ACCUMULATION (Exact sum)
# ============================================

class GradientAccumulator:
    """VLA exact gradient accumulator.

    Accumulates gradients in FP64 to prevent drift.
    Critical for large batch training with many micro-batches.
    """

    def __init__(self, params):
        """Initialize accumulator for model parameters."""
        self.accumulated = {}
        for i, p in enumerate(params):
            if p.requires_grad:
                self.accumulated[i] = torch.zeros_like(p, dtype=torch.float64)
        self.count = 0

    def accumulate(self, params):
        """Add gradients from current backward pass."""
        for i, p in enumerate(params):
            if p.requires_grad and p.grad is not None:
                # Exact accumulation in FP64
                self.accumulated[i] += p.grad.double()
        self.count += 1

    def get_averaged(self):
        """Get averaged gradients (for gradient accumulation)."""
        return {i: g / self.count for i, g in self.accumulated.items()}

    def get_summed(self):
        """Get summed gradients (for data parallel)."""
        return self.accumulated.copy()

    def apply_to_params(self, params, average: bool = True):
        """Apply accumulated gradients back to parameters."""
        grads = self.get_averaged() if average else self.get_summed()
        for i, p in enumerate(params):
            if i in grads:
                p.grad = grads[i].to(p.dtype)

    def zero(self):
        """Reset accumulator."""
        for i in self.accumulated:
            self.accumulated[i].zero_()
        self.count = 0


# ============================================
# VLA COSINE SIMILARITY (Exact)
# ============================================

def cosine_similarity(x1: torch.Tensor, x2: torch.Tensor, dim: int = 1, eps: float = 1e-8) -> torch.Tensor:
    """VLA exact cosine similarity. Returns FP64.

    cos_sim = (x1 · x2) / (||x1|| * ||x2||)
    Uses exact dot product and norm.
    """
    # Compute along specified dimension
    if dim != -1:
        x1 = x1.transpose(dim, -1)
        x2 = x2.transpose(dim, -1)

    # Flatten to 2D for easier processing
    shape = x1.shape[:-1]
    n = x1.shape[-1]
    x1_flat = x1.reshape(-1, n)
    x2_flat = x2.reshape(-1, n)

    batch = x1_flat.shape[0]
    results = torch.zeros(batch, device=x1.device, dtype=torch.float64)

    for b in range(batch):
        # Exact dot product
        dot_prod = dot(x1_flat[b], x2_flat[b])

        # Exact norms
        norm1 = norm(x1_flat[b])
        norm2 = norm(x2_flat[b])

        # Cosine similarity
        results[b] = dot_prod / (norm1 * norm2 + eps)

    return results.reshape(shape)


# ============================================
# VLA PAIRWISE DISTANCE (Exact)
# ============================================

def pairwise_distance(x1: torch.Tensor, x2: torch.Tensor, p: float = 2.0) -> torch.Tensor:
    """VLA exact pairwise distance. Returns FP64.

    Computes ||x1 - x2||_p for each pair.
    """
    assert p == 2.0, "Only L2 distance supported"

    diff = x1.double() - x2.double()
    return norm(diff)


# ============================================
# VLA MEAN (Exact)
# ============================================

def mean(x: torch.Tensor, dim: int = None, keepdim: bool = False) -> torch.Tensor:
    """VLA exact mean. Returns FP64.

    Uses exact sum for accumulation.
    """
    if dim is None:
        # Global mean
        return sum(x) / x.numel()

    # Mean along dimension
    if dim < 0:
        dim = x.dim() + dim

    # Move target dim to last
    x = x.transpose(dim, -1)
    shape = x.shape
    n = shape[-1]

    # Flatten to 2D
    x_flat = x.reshape(-1, n)
    batch = x_flat.shape[0]

    results = torch.zeros(batch, device=x.device, dtype=torch.float64)
    for b in range(batch):
        results[b] = sum(x_flat[b]) / n

    # Reshape
    result = results.reshape(shape[:-1])

    if keepdim:
        result = result.unsqueeze(dim)

    return result


# ============================================
# VLA SGD STEP (Exact SGD with momentum)
# ============================================

def sgd_step(
    param: torch.Tensor,
    grad: torch.Tensor,
    velocity: torch.Tensor = None,
    lr: float = 0.01,
    momentum: float = 0.0,
    weight_decay: float = 0.0,
    dampening: float = 0.0,
    nesterov: bool = False
) -> tuple:
    """VLA exact SGD optimizer step. Returns (param, velocity) in FP64.

    All computations in FP64 for exactness.
    """
    param64 = param.double()
    grad64 = grad.double()

    # Weight decay
    if weight_decay != 0:
        grad64 = grad64 + weight_decay * param64

    # Momentum
    if momentum != 0:
        if velocity is None:
            velocity = torch.zeros_like(grad64)
        else:
            velocity = velocity.double()

        velocity = momentum * velocity + (1 - dampening) * grad64

        if nesterov:
            grad64 = grad64 + momentum * velocity
        else:
            grad64 = velocity

    # Update
    param64 = param64 - lr * grad64

    return param64, velocity if momentum != 0 else None


# ============================================
# VLA ADAMW STEP (Decoupled weight decay)
# ============================================

def adamw_step(
    param: torch.Tensor,
    grad: torch.Tensor,
    exp_avg: torch.Tensor,
    exp_avg_sq: torch.Tensor,
    step: int,
    lr: float = 1e-3,
    beta1: float = 0.9,
    beta2: float = 0.999,
    eps: float = 1e-8,
    weight_decay: float = 0.01
) -> tuple:
    """VLA exact AdamW optimizer step. Returns (param, exp_avg, exp_avg_sq) in FP64.

    AdamW: decoupled weight decay (not L2 regularization).
    All computations in FP64 for exactness.
    """
    param64 = param.double()
    grad64 = grad.double()
    exp_avg64 = exp_avg.double()
    exp_avg_sq64 = exp_avg_sq.double()

    # Decoupled weight decay (applied to param directly, not gradient)
    param64 = param64 * (1 - lr * weight_decay)

    # Update biased first moment estimate
    exp_avg64 = beta1 * exp_avg64 + (1 - beta1) * grad64

    # Update biased second raw moment estimate
    exp_avg_sq64 = beta2 * exp_avg_sq64 + (1 - beta2) * grad64 * grad64

    # Bias correction
    bias_correction1 = 1 - beta1 ** step
    bias_correction2 = 1 - beta2 ** step

    # Compute step
    step_size = lr / bias_correction1
    denom = (exp_avg_sq64 / bias_correction2).sqrt() + eps

    # Update parameter
    param64 = param64 - step_size * exp_avg64 / denom

    return param64, exp_avg64, exp_avg_sq64


# ============================================
# VLA KV CACHE (Exact KV caching for inference)
# ============================================

class KVCache:
    """VLA exact KV cache for transformer inference.

    Stores key-value pairs in FP64 for exact attention.
    Critical for long-context generation where errors accumulate.
    """

    def __init__(self, max_seq_len: int, num_heads: int, head_dim: int, batch_size: int = 1, device='cuda'):
        """Initialize KV cache."""
        self.max_seq_len = max_seq_len
        self.num_heads = num_heads
        self.head_dim = head_dim
        self.batch_size = batch_size
        self.device = device

        # FP64 storage for exactness
        self.k_cache = torch.zeros(
            batch_size, num_heads, max_seq_len, head_dim,
            dtype=torch.float64, device=device
        )
        self.v_cache = torch.zeros(
            batch_size, num_heads, max_seq_len, head_dim,
            dtype=torch.float64, device=device
        )
        self.seq_len = 0

    def update(self, k: torch.Tensor, v: torch.Tensor) -> tuple:
        """Add new key-value pairs and return full cache.

        Args:
            k, v: New KV pairs of shape (batch, heads, new_seq, head_dim)

        Returns:
            (cached_k, cached_v) up to current position
        """
        new_seq = k.shape[2]

        # Store in FP64
        self.k_cache[:, :, self.seq_len:self.seq_len + new_seq] = k.double()
        self.v_cache[:, :, self.seq_len:self.seq_len + new_seq] = v.double()
        self.seq_len += new_seq

        # Return cached values
        return (
            self.k_cache[:, :, :self.seq_len],
            self.v_cache[:, :, :self.seq_len]
        )

    def get(self) -> tuple:
        """Get current cached KV pairs."""
        return (
            self.k_cache[:, :, :self.seq_len],
            self.v_cache[:, :, :self.seq_len]
        )

    def clear(self):
        """Reset cache."""
        self.k_cache.zero_()
        self.v_cache.zero_()
        self.seq_len = 0


# ============================================
# VLA QUANTIZE / DEQUANTIZE (Exact quantization)
# ============================================

def quantize_symmetric(x: torch.Tensor, bits: int = 8) -> tuple:
    """VLA exact symmetric quantization. Returns (quantized, scale) in FP64.

    Symmetric: range is [-max_val, max_val]
    Scale computed exactly in FP64.
    """
    x64 = x.double()

    # Find max absolute value (exact)
    max_val = x64.abs().max()

    # Compute scale (FP64 for exactness)
    qmax = (1 << (bits - 1)) - 1  # e.g., 127 for int8
    scale = max_val / qmax

    # Quantize (round to nearest)
    if scale > 0:
        quantized = torch.round(x64 / scale).clamp(-qmax, qmax)
    else:
        quantized = torch.zeros_like(x64)

    return quantized.to(torch.int8 if bits == 8 else torch.int16), scale


def dequantize_symmetric(quantized: torch.Tensor, scale: torch.Tensor) -> torch.Tensor:
    """VLA exact symmetric dequantization. Returns FP64.

    Exact reconstruction: x = quantized * scale
    """
    return quantized.double() * scale


def quantize_asymmetric(x: torch.Tensor, bits: int = 8) -> tuple:
    """VLA exact asymmetric quantization. Returns (quantized, scale, zero_point).

    Asymmetric: range is [min_val, max_val]
    Better for activations with non-zero mean.
    """
    x64 = x.double()

    # Find min/max (exact)
    min_val = x64.min()
    max_val = x64.max()

    # Compute scale and zero point
    qmax = (1 << bits) - 1  # e.g., 255 for uint8
    scale = (max_val - min_val) / qmax

    if scale > 0:
        zero_point = torch.round(-min_val / scale).clamp(0, qmax)
        quantized = torch.round(x64 / scale + zero_point).clamp(0, qmax)
    else:
        zero_point = torch.tensor(0.0, dtype=torch.float64)
        quantized = torch.zeros_like(x64)

    return quantized.to(torch.uint8), scale, zero_point


def dequantize_asymmetric(quantized: torch.Tensor, scale: torch.Tensor, zero_point: torch.Tensor) -> torch.Tensor:
    """VLA exact asymmetric dequantization. Returns FP64.

    Exact reconstruction: x = (quantized - zero_point) * scale
    """
    return (quantized.double() - zero_point) * scale


# ============================================
# VLA FUSED LINEAR + ACTIVATION
# ============================================

def linear_relu(x: torch.Tensor, weight: torch.Tensor, bias: torch.Tensor = None) -> torch.Tensor:
    """VLA exact fused linear + ReLU. Returns FP64."""
    out = linear(x, weight, bias)
    return relu(out.float())


def linear_gelu(x: torch.Tensor, weight: torch.Tensor, bias: torch.Tensor = None) -> torch.Tensor:
    """VLA exact fused linear + GELU. Returns FP64."""
    out = linear(x, weight, bias)
    return gelu(out.float())


def linear_silu(x: torch.Tensor, weight: torch.Tensor, bias: torch.Tensor = None) -> torch.Tensor:
    """VLA exact fused linear + SiLU. Returns FP64."""
    out = linear(x, weight, bias)
    return silu(out.float())


# ============================================
# VLA CLAMP (Exact clamping)
# ============================================

@triton.jit
def _vla_clamp_kernel(x_ptr, out_ptr, min_val, max_val, n, BLOCK: tl.constexpr):
    """VLA exact clamp."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask).to(tl.float64)
    result = tl.minimum(tl.maximum(x, min_val), max_val)
    tl.store(out_ptr + offs, result, mask=mask)


def clamp(x: torch.Tensor, min_val: float = None, max_val: float = None) -> torch.Tensor:
    """VLA exact clamp. Returns FP64."""
    if min_val is None:
        min_val = float('-inf')
    if max_val is None:
        max_val = float('inf')

    n = x.numel()
    out = torch.empty(x.shape, device=x.device, dtype=torch.float64)
    BLOCK = 1024
    _vla_clamp_kernel[(triton.cdiv(n, BLOCK),)](
        x.flatten(), out.flatten(), min_val, max_val, n, BLOCK
    )
    return out


# ============================================
# VLA ABS (Exact absolute value)
# ============================================

@triton.jit
def _vla_abs_kernel(x_ptr, out_ptr, n, BLOCK: tl.constexpr):
    """VLA exact abs."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask).to(tl.float64)
    result = tl.abs(x)
    tl.store(out_ptr + offs, result, mask=mask)


def vla_abs(x: torch.Tensor) -> torch.Tensor:
    """VLA exact absolute value. Returns FP64."""
    n = x.numel()
    out = torch.empty(x.shape, device=x.device, dtype=torch.float64)
    BLOCK = 1024
    _vla_abs_kernel[(triton.cdiv(n, BLOCK),)](x.flatten(), out.flatten(), n, BLOCK)
    return out


# ============================================
# VLA EXP / LOG (Exact exponential/logarithm)
# ============================================

@triton.jit
def _vla_exp_kernel(x_ptr, out_ptr, n, BLOCK: tl.constexpr):
    """VLA exact exp."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask).to(tl.float64)
    result = tl.exp(x)
    tl.store(out_ptr + offs, result, mask=mask)


def exp(x: torch.Tensor) -> torch.Tensor:
    """VLA exact exponential. Returns FP64."""
    n = x.numel()
    out = torch.empty(x.shape, device=x.device, dtype=torch.float64)
    BLOCK = 1024
    _vla_exp_kernel[(triton.cdiv(n, BLOCK),)](x.flatten(), out.flatten(), n, BLOCK)
    return out


@triton.jit
def _vla_log_kernel(x_ptr, out_ptr, n, BLOCK: tl.constexpr):
    """VLA exact log."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask).to(tl.float64)
    result = tl.log(x)
    tl.store(out_ptr + offs, result, mask=mask)


def log(x: torch.Tensor) -> torch.Tensor:
    """VLA exact natural logarithm. Returns FP64."""
    n = x.numel()
    out = torch.empty(x.shape, device=x.device, dtype=torch.float64)
    BLOCK = 1024
    _vla_log_kernel[(triton.cdiv(n, BLOCK),)](x.flatten(), out.flatten(), n, BLOCK)
    return out


# ============================================
# VLA POW (Exact power)
# ============================================

@triton.jit
def _vla_pow_kernel(x_ptr, out_ptr, exponent, n, BLOCK: tl.constexpr):
    """VLA exact pow."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask).to(tl.float64)
    # pow(x, n) = exp(n * log(x))
    result = tl.exp(exponent * tl.log(x))
    tl.store(out_ptr + offs, result, mask=mask)


def pow(x: torch.Tensor, exponent: float) -> torch.Tensor:
    """VLA exact power. Returns FP64."""
    n = x.numel()
    out = torch.empty(x.shape, device=x.device, dtype=torch.float64)
    BLOCK = 1024
    _vla_pow_kernel[(triton.cdiv(n, BLOCK),)](x.flatten(), out.flatten(), exponent, n, BLOCK)
    return out


# ============================================
# VLA RECIPROCAL (Exact 1/x)
# ============================================

@triton.jit
def _vla_reciprocal_kernel(x_ptr, out_ptr, n, BLOCK: tl.constexpr):
    """VLA exact reciprocal."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    mask = offs < n

    x = tl.load(x_ptr + offs, mask=mask).to(tl.float64)
    result = 1.0 / x
    tl.store(out_ptr + offs, result, mask=mask)


def reciprocal(x: torch.Tensor) -> torch.Tensor:
    """VLA exact reciprocal (1/x). Returns FP64."""
    n = x.numel()
    out = torch.empty(x.shape, device=x.device, dtype=torch.float64)
    BLOCK = 1024
    _vla_reciprocal_kernel[(triton.cdiv(n, BLOCK),)](x.flatten(), out.flatten(), n, BLOCK)
    return out


# ============================================
# VLA NEG (Exact negation)
# ============================================

def neg(x: torch.Tensor) -> torch.Tensor:
    """VLA exact negation. Returns FP64."""
    return -x.double()


# ============================================
# VLA ADD / SUB / MUL (Element-wise exact with broadcasting)
# ============================================

def add(x: torch.Tensor, y) -> torch.Tensor:
    """VLA exact element-wise addition with broadcasting. Returns FP64.

    Args:
        x: First tensor
        y: Second tensor or scalar

    Supports full NumPy-style broadcasting.
    """
    if not isinstance(y, torch.Tensor):
        y = torch.tensor(y, device=x.device, dtype=x.dtype)
    return x.double() + y.double()


def sub(x: torch.Tensor, y) -> torch.Tensor:
    """VLA exact element-wise subtraction with broadcasting. Returns FP64.

    Args:
        x: First tensor
        y: Second tensor or scalar
    """
    if not isinstance(y, torch.Tensor):
        y = torch.tensor(y, device=x.device, dtype=x.dtype)
    return x.double() - y.double()


def mul(x: torch.Tensor, y) -> torch.Tensor:
    """VLA exact element-wise multiplication with broadcasting. Returns FP64.

    FP32 * FP32 is exact in FP64 (24 + 24 < 53 mantissa bits).

    Args:
        x: First tensor
        y: Second tensor or scalar
    """
    if not isinstance(y, torch.Tensor):
        y = torch.tensor(y, device=x.device, dtype=x.dtype)
    return x.double() * y.double()


# ============================================
# TEST SUITE
# ============================================

def _test_all():
    """Run all tests."""
    import time

    print("=" * 70)
    print(f"VLA TRITON LIBRARY v{__version__}")
    print("=" * 70)
    print(f"GPU: {torch.cuda.get_device_name()}")
    print()

    device = 'cuda'
    torch.manual_seed(42)

    results = []

    # 1. DOT
    print("1. DOT PRODUCT")
    print("-" * 50)
    n = 100000
    scales = torch.logspace(-4, 4, n, device=device, dtype=torch.float32)
    x = torch.randn(n, device=device, dtype=torch.float32) * scales
    y = torch.randn(n, device=device, dtype=torch.float32) * scales

    truth = torch.dot(x.double(), y.double()).item()
    vla_r = dot(x, y).item()
    std_r = torch.dot(x, y).item()

    vla_err = abs(vla_r - truth) / abs(truth)
    std_err = abs(std_r - truth) / abs(truth)
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('dot', imp))

    # 2. SUM
    print("\n2. SUM")
    print("-" * 50)
    x = torch.randn(100000, device=device, dtype=torch.float32) * 1e6
    truth = x.double().sum().item()
    vla_r = sum(x).item()
    std_r = x.sum().item()
    vla_err = abs(vla_r - truth) / abs(truth) if truth != 0 else abs(vla_r)
    std_err = abs(std_r - truth) / abs(truth) if truth != 0 else abs(std_r)
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('sum', imp))

    # 3. NORM
    print("\n3. L2 NORM")
    print("-" * 50)
    x = torch.randn(100000, device=device, dtype=torch.float32) * 1e4
    truth = torch.norm(x.double()).item()
    vla_r = norm(x).item()
    std_r = torch.norm(x).item()
    vla_err = abs(vla_r - truth) / abs(truth)
    std_err = abs(std_r - truth) / abs(truth)
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('norm', imp))

    # 4. VARIANCE
    print("\n4. VARIANCE")
    print("-" * 50)
    x = torch.randn(10000, device=device, dtype=torch.float32) * 1e4 + 1e8
    truth = x.double().var().item()
    vla_r = var(x).item()
    std_r = x.var().item()
    vla_err = abs(vla_r - truth) / abs(truth)
    std_err = abs(std_r - truth) / abs(truth)
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('var', imp))

    # 5. MATMUL
    print("\n5. MATMUL (FP64 output)")
    print("-" * 50)
    K = 256
    M, N = 64, 64
    scales = torch.logspace(-3, 3, K, device=device, dtype=torch.float32)
    a = torch.randn(M, K, device=device, dtype=torch.float32) * scales[None, :]
    b = torch.randn(K, N, device=device, dtype=torch.float32) * scales[:, None]

    truth = a.double() @ b.double()
    vla_r = matmul(a, b)  # Now defaults to FP64
    std_r = a @ b

    vla_err = (vla_r - truth).abs().max().item() / truth.abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item() / truth.abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    if vla_err == 0:
        print(f"   VLA: EXACT, FP32: {std_err:.2e}, improvement: EXACT")
        results.append(('matmul', float('inf')))
    else:
        print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
        results.append(('matmul', imp))

    # 6. DIV (FP64 output)
    print("\n6. DIVISION (FP64 output)")
    print("-" * 50)
    a = torch.randn(10000, device=device, dtype=torch.float32) * 1e6
    b = torch.randn(10000, device=device, dtype=torch.float32) * 1e3 + 1
    truth = a.double() / b.double()
    vla_r = div(a, b)  # Now returns FP64
    std_r = a / b
    vla_err = (vla_r - truth).abs().max().item() / truth.abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item() / truth.abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('div', imp))

    # 7. SQRT (FP64 output)
    print("\n7. SQRT (FP64 output)")
    print("-" * 50)
    x = torch.rand(10000, device=device, dtype=torch.float32) * 1e8 + 1
    truth = torch.sqrt(x.double())
    vla_r = sqrt(x)  # Now returns FP64
    std_r = torch.sqrt(x)
    vla_err = (vla_r - truth).abs().max().item() / truth.abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item() / truth.abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('sqrt', imp))

    # 8. LOGSUMEXP
    print("\n8. LOGSUMEXP")
    print("-" * 50)
    x = torch.randn(100, 1000, device=device, dtype=torch.float32) * 10
    truth = torch.logsumexp(x.double(), dim=-1)
    vla_r = logsumexp(x, dim=-1)
    std_r = torch.logsumexp(x, dim=-1)
    vla_err = (vla_r - truth).abs().max().item() / truth.abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item() / truth.abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('logsumexp', imp))

    # 9. SOFTMAX
    print("\n9. SOFTMAX")
    print("-" * 50)
    x = torch.randn(32, 512, device=device, dtype=torch.float32) * 5
    truth = torch.softmax(x.double(), dim=-1)
    vla_r = softmax(x, dim=-1)
    std_r = torch.softmax(x, dim=-1)
    vla_err = (vla_r - truth).abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('softmax', imp))

    # 10. LAYER NORM
    print("\n10. LAYER NORM")
    print("-" * 50)
    x = torch.randn(32, 512, device=device, dtype=torch.float32) * 100 + 1e6
    truth = torch.nn.functional.layer_norm(x.double(), (512,))
    vla_r = layer_norm(x, (512,))
    std_r = torch.nn.functional.layer_norm(x, (512,))
    vla_err = (vla_r - truth).abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('layer_norm', imp))

    # 11. CROSS ENTROPY
    print("\n11. CROSS ENTROPY")
    print("-" * 50)
    logits = torch.randn(64, 1000, device=device, dtype=torch.float32) * 10
    targets = torch.randint(0, 1000, (64,), device=device)
    truth = torch.nn.functional.cross_entropy(logits.double(), targets)
    vla_r = cross_entropy(logits, targets)
    std_r = torch.nn.functional.cross_entropy(logits, targets)
    vla_err = abs(vla_r.item() - truth.item()) / abs(truth.item())
    std_err = abs(std_r.item() - truth.item()) / abs(truth.item())
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('cross_entropy', imp))

    # 12. BATCH MATMUL
    print("\n12. BATCH MATMUL (for attention)")
    print("-" * 50)
    a = torch.randn(8, 64, 128, device=device, dtype=torch.float32) * 10
    b = torch.randn(8, 128, 64, device=device, dtype=torch.float32) * 10
    truth = torch.bmm(a.double(), b.double())
    vla_r = bmm(a, b)
    std_r = torch.bmm(a, b)
    vla_err = (vla_r - truth).abs().max().item() / truth.abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item() / truth.abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    if vla_err == 0:
        print(f"   VLA: EXACT, FP32: {std_err:.2e}")
        results.append(('bmm', float('inf')))
    else:
        print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
        results.append(('bmm', imp))

    # 13. LINEAR
    print("\n13. LINEAR (fused matmul+bias)")
    print("-" * 50)
    x = torch.randn(32, 256, device=device, dtype=torch.float32) * 10
    weight = torch.randn(512, 256, device=device, dtype=torch.float32) * 0.1
    bias = torch.randn(512, device=device, dtype=torch.float32)
    truth = torch.nn.functional.linear(x.double(), weight.double(), bias.double())
    vla_r = linear(x, weight, bias)
    std_r = torch.nn.functional.linear(x, weight, bias)
    vla_err = (vla_r - truth).abs().max().item() / truth.abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item() / truth.abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('linear', imp))

    # 14. GELU
    print("\n14. GELU")
    print("-" * 50)
    x = torch.randn(10000, device=device, dtype=torch.float32) * 5
    truth = torch.nn.functional.gelu(x.double())
    vla_r = gelu(x)
    std_r = torch.nn.functional.gelu(x)
    vla_err = (vla_r - truth).abs().max().item() / truth.abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item() / truth.abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('gelu', imp))

    # 15. SILU
    print("\n15. SILU/SWISH")
    print("-" * 50)
    x = torch.randn(10000, device=device, dtype=torch.float32) * 10
    truth = torch.nn.functional.silu(x.double())
    vla_r = silu(x)
    std_r = torch.nn.functional.silu(x)
    vla_err = (vla_r - truth).abs().max().item() / truth.abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item() / truth.abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('silu', imp))

    # 16. RELU
    print("\n16. RELU")
    print("-" * 50)
    x = torch.randn(10000, device=device, dtype=torch.float32) * 100
    truth = torch.nn.functional.relu(x.double())
    vla_r = relu(x)
    std_r = torch.nn.functional.relu(x)
    vla_err = (vla_r - truth).abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item()
    if vla_err == 0 and std_err == 0:
        print(f"   Both EXACT (ReLU is trivially exact)")
        results.append(('relu', 1.0))
    else:
        imp = std_err / vla_err if vla_err > 0 else float('inf')
        print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}")
        results.append(('relu', imp))

    # 17. RMS NORM
    print("\n17. RMS NORM (LLaMA-style)")
    print("-" * 50)
    x = torch.randn(32, 512, device=device, dtype=torch.float32) * 100 + 1e6
    x64 = x.double()
    rms_truth = torch.sqrt((x64 ** 2).mean(dim=-1, keepdim=True))
    truth = x64 / rms_truth
    vla_r = rms_norm(x, (512,))
    # FP32 RMS norm
    x32_rms = torch.sqrt((x ** 2).mean(dim=-1, keepdim=True))
    std_r = x / x32_rms
    vla_err = (vla_r - truth).abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('rms_norm', imp))

    # 18. CONV1D
    print("\n18. CONV1D")
    print("-" * 50)
    x = torch.randn(4, 16, 100, device=device, dtype=torch.float32) * 10
    w = torch.randn(32, 16, 3, device=device, dtype=torch.float32)
    truth = torch.nn.functional.conv1d(x.double(), w.double(), padding=1)
    vla_r = conv1d(x, w, padding=1)
    std_r = torch.nn.functional.conv1d(x, w, padding=1)
    vla_err = (vla_r - truth).abs().max().item() / truth.abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item() / truth.abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    if vla_err == 0:
        print(f"   VLA: EXACT, FP32: {std_err:.2e}")
        results.append(('conv1d', float('inf')))
    else:
        print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
        results.append(('conv1d', imp))

    # 19. GROUP NORM
    print("\n19. GROUP NORM")
    print("-" * 50)
    x = torch.randn(4, 32, 16, 16, device=device, dtype=torch.float32) * 100
    truth = torch.nn.functional.group_norm(x.double(), 8)
    vla_r = group_norm(x, 8)
    std_r = torch.nn.functional.group_norm(x, 8)
    vla_err = (vla_r - truth).abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('group_norm', imp))

    # 20. TANH
    print("\n20. TANH")
    print("-" * 50)
    x = torch.randn(10000, device=device, dtype=torch.float32) * 5
    truth = torch.tanh(x.double())
    vla_r = tanh(x)
    std_r = torch.tanh(x)
    vla_err = (vla_r - truth).abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('tanh', imp))

    # 21. SIGMOID
    print("\n21. SIGMOID")
    print("-" * 50)
    x = torch.randn(10000, device=device, dtype=torch.float32) * 10
    truth = torch.sigmoid(x.double())
    vla_r = sigmoid(x)
    std_r = torch.sigmoid(x)
    vla_err = (vla_r - truth).abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('sigmoid', imp))

    # 22. CONV2D
    print("\n22. CONV2D")
    print("-" * 50)
    x = torch.randn(2, 16, 32, 32, device=device, dtype=torch.float32) * 10
    w = torch.randn(32, 16, 3, 3, device=device, dtype=torch.float32)
    truth = torch.nn.functional.conv2d(x.double(), w.double(), padding=1)
    vla_r = conv2d(x, w, padding=1)
    std_r = torch.nn.functional.conv2d(x, w, padding=1)
    vla_err = (vla_r - truth).abs().max().item() / truth.abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item() / truth.abs().max().item()
    if vla_err == 0:
        print(f"   VLA: EXACT, FP32: {std_err:.2e}")
        results.append(('conv2d', float('inf')))
    else:
        imp = std_err / vla_err if vla_err > 0 else float('inf')
        print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
        results.append(('conv2d', imp))

    # 23. AVG POOL2D
    print("\n23. AVG POOL2D")
    print("-" * 50)
    x = torch.randn(4, 16, 16, 16, device=device, dtype=torch.float32) * 100
    truth = torch.nn.functional.avg_pool2d(x.double(), 2)
    vla_r = avg_pool2d(x, 2)
    std_r = torch.nn.functional.avg_pool2d(x, 2)
    vla_err = (vla_r - truth).abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item()
    if vla_err == 0:
        print(f"   VLA: EXACT, FP32: {std_err:.2e}")
        results.append(('avg_pool2d', float('inf')))
    else:
        imp = std_err / vla_err if vla_err > 0 else float('inf')
        print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
        results.append(('avg_pool2d', imp))

    # 24. COSINE SIMILARITY
    print("\n24. COSINE SIMILARITY")
    print("-" * 50)
    x1 = torch.randn(100, 512, device=device, dtype=torch.float32) * 10
    x2 = torch.randn(100, 512, device=device, dtype=torch.float32) * 10
    truth = torch.nn.functional.cosine_similarity(x1.double(), x2.double(), dim=1)
    vla_r = cosine_similarity(x1, x2, dim=1)
    std_r = torch.nn.functional.cosine_similarity(x1, x2, dim=1)
    vla_err = (vla_r - truth).abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item()
    imp = std_err / vla_err if vla_err > 0 else float('inf')
    print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
    results.append(('cosine_sim', imp))

    # 25. MEAN
    print("\n25. MEAN")
    print("-" * 50)
    x = torch.randn(32, 10000, device=device, dtype=torch.float32) * 1e6
    truth = x.double().mean(dim=1)
    vla_r = mean(x, dim=1)
    std_r = x.mean(dim=1)
    vla_err = (vla_r - truth).abs().max().item() / truth.abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item() / truth.abs().max().item()
    if vla_err == 0:
        print(f"   VLA: EXACT, FP32: {std_err:.2e}")
        results.append(('mean', float('inf')))
    else:
        imp = std_err / vla_err if vla_err > 0 else float('inf')
        print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
        results.append(('mean', imp))

    # 26. EXP
    print("\n26. EXP")
    print("-" * 50)
    x = torch.randn(10000, device=device, dtype=torch.float32) * 5
    truth = torch.exp(x.double())
    vla_r = exp(x)
    std_r = torch.exp(x)
    vla_err = (vla_r - truth).abs().max().item() / truth.abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item() / truth.abs().max().item()
    if vla_err == 0:
        print(f"   VLA: EXACT, FP32: {std_err:.2e}")
        results.append(('exp', float('inf')))
    else:
        imp = std_err / vla_err if vla_err > 0 else float('inf')
        print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
        results.append(('exp', imp))

    # 27. LOG
    print("\n27. LOG")
    print("-" * 50)
    x = torch.abs(torch.randn(10000, device=device, dtype=torch.float32)) + 0.01
    truth = torch.log(x.double())
    vla_r = log(x)
    std_r = torch.log(x)
    vla_err = (vla_r - truth).abs().max().item() / truth.abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item() / truth.abs().max().item()
    if vla_err == 0:
        print(f"   VLA: EXACT, FP32: {std_err:.2e}")
        results.append(('log', float('inf')))
    else:
        imp = std_err / vla_err if vla_err > 0 else float('inf')
        print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
        results.append(('log', imp))

    # 28. MUL (should be exact)
    print("\n28. MUL (FP32*FP32 exact in FP64)")
    print("-" * 50)
    x = torch.randn(10000, device=device, dtype=torch.float32) * 1e6
    y = torch.randn(10000, device=device, dtype=torch.float32) * 1e6
    truth = x.double() * y.double()
    vla_r = mul(x, y)
    std_r = x * y
    vla_err = (vla_r - truth).abs().max().item()
    std_err = (std_r.double() - truth).abs().max().item()
    if vla_err == 0:
        print(f"   VLA: EXACT (FP32*FP32 is exact in FP64)")
        results.append(('mul', float('inf')))
    else:
        imp = std_err / vla_err if vla_err > 0 else float('inf')
        print(f"   VLA: {vla_err:.2e}, FP32: {std_err:.2e}, improvement: {imp:.0f}x")
        results.append(('mul', imp))

    # Summary
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    print(f"\n{'Operation':<12} {'Improvement':<15}")
    print("-" * 30)
    for name, imp in results:
        print(f"{name:<12} {imp:>10.0f}x")

    print("\n" + "=" * 70)
    print("VLA TRITON: Portable exact arithmetic for any GPU")
    print("=" * 70)


if __name__ == "__main__":
    _test_all()
