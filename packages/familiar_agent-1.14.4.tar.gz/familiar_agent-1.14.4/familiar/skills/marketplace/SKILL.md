# Plugin Marketplace

Discover, install, and manage plugins from the Pi Agent community.

## Usage

- "Browse available plugins"
- "Search plugins for spotify"
- "Install the home-assistant plugin"
- "What plugins do I have installed?"
- "Update all my plugins"
- "Tell me about the github plugin"
- "Uninstall the spotify plugin"

## Available Categories

- **productivity** - Notion, Todoist, Linear, etc.
- **smart-home** - Home Assistant, MQTT, IoT
- **media** - Spotify, music control
- **development** - GitHub, CI/CD
- **communication** - Slack, Discord
- **finance** - Stocks, crypto
- **ai** - Image generation, ML
- **health** - Fitness tracking
- **lifestyle** - Recipes, travel

## How Plugins Work

Plugins are Git repositories with a standard structure:

```
my-plugin/
├── SKILL.md          # Documentation
├── skill.py          # Tools and handlers
├── requirements.txt  # Python dependencies
└── README.md        # Plugin info
```

When installed, plugins are:
1. Cloned to `~/.pi_agent/plugins/`
2. Dependencies are installed via pip
3. Symlinked to the skills directory
4. Automatically loaded on next agent start

## Creating a Plugin

1. Create a new repo with the structure above
2. Define tools in skill.py using the TOOLS list format
3. Add to the registry (or install from local path)

Example skill.py:
```python
def my_function(data: dict) -> str:
    name = data.get("name", "world")
    return f"Hello, {name}!"

TOOLS = [
    {
        "name": "greet",
        "description": "Say hello",
        "input_schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"}
            }
        },
        "handler": my_function,
        "category": "greeting"
    }
]
```

## Featured Plugins

### Home Assistant
Control smart home devices - lights, thermostats, sensors, scenes.
```
"Turn off the living room lights"
"Set thermostat to 72 degrees"
"Is the garage door open?"
```

### Spotify
Control music playback, search, manage playlists.
```
"Play some jazz"
"Skip this song"
"Add this to my liked songs"
```

### GitHub
Manage repositories, issues, pull requests.
```
"Show my open PRs"
"Create an issue for the login bug"
"What's the status of CI?"
```

### Notion
Create pages, manage databases, take notes.
```
"Add a note to my work notebook"
"Show my task database"
"Create a new page for project ideas"
```
