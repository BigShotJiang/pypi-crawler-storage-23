# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Familiar Voice Skill

Comprehensive voice capabilities:
- Text-to-speech (TTS) with Piper (local, HIPAA-safe) and other engines
- Speech-to-text (STT) via Whisper (local) or cloud APIs
- Document reading aloud (DOCX, PDF, TXT, MD, HTML)
- Real-time transcription streaming
- Audio file transcription (any format)
- Voice activity detection
- Speaker diarization (who said what)
- Meeting/interview transcription
- Voice memos with automatic summarization

HIPAA Compliance:
- Piper TTS runs 100% locally - no cloud transmission
- Whisper transcription runs locally
- Safe for PHI and sensitive documents
"""

from .skill import (
    TOOLS,
    list_whisper_models,
    listen_microphone,
    set_voice_config,
    speak_text,
    start_realtime_transcription,
    stop_realtime_transcription,
    transcribe_audio,
    transcribe_meeting,
)

# Document reader (Piper TTS)
try:
    from .document_reader import (
        DOCUMENT_READER_TOOLS,
        PIPER_VOICES,
        get_reading_status,
        install_piper,
        list_voices,
        parse_document,
        read_aloud,
        read_document,
        speak_with_piper,
        stop_reading,
    )

    DOCUMENT_READER_AVAILABLE = True
except ImportError:
    DOCUMENT_READER_AVAILABLE = False

__all__ = [
    "TOOLS",
    "transcribe_audio",
    "transcribe_meeting",
    "start_realtime_transcription",
    "stop_realtime_transcription",
    "speak_text",
    "listen_microphone",
    "set_voice_config",
    "list_whisper_models",
    # Document reader
    "read_document",
    "stop_reading",
    "get_reading_status",
    "list_voices",
    "install_piper",
    "read_aloud",
    "parse_document",
    "speak_with_piper",
    "DOCUMENT_READER_TOOLS",
    "PIPER_VOICES",
    "DOCUMENT_READER_AVAILABLE",
]
