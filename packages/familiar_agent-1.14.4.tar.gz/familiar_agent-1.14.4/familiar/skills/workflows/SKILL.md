# Workflow Templates Skill

Pre-built multi-step workflows for recurring operations.
Reduces complex procedures to a single command.

## Usage

Use this skill when the user wants to:
- Run a multi-step workflow (e.g. new donor onboarding, board meeting prep)
- List available workflow templates
- Create a custom workflow from a sequence of steps
- Check progress of a running workflow

## Bundled Workflows

1. **new_donor_onboarding**: log_donor → add_contact → generate_receipt →
   create_letter (thank-you) → send_email → add_task (follow-up call 7 days)
2. **grant_application**: add_grant → create tasks for LOI/narrative/budget/submission →
   set deadline alerts → track status
3. **board_meeting_prep**: board_packet → create_agenda → schedule_meeting →
   send materials to attendees
4. **year_end_acknowledgments**: search donors (gifts this year) → for each:
   generate_receipt → create_letter → send_email
5. **monthly_close**: financial_summary → donor_report → grant_report →
   export_to_xlsx → send to treasurer

## Architecture

Workflows are orchestration over existing skills. Each step references
a tool name and parameter mapping. The workflow engine calls tools
sequentially, passing results forward.
