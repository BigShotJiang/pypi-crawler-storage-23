# Proactive Skill

Proactive notifications, daily briefings, and smart reminders.

## Features

- **Morning Briefing**: Summary of calendar, tasks, and emails at a set time
- **Smart Reminders**: Context-aware reminders (e.g., "remind me about X when I talk to Y")
- **Deadline Alerts**: Warns about approaching deadlines
- **Follow-up Prompts**: Reminds to follow up on sent emails or tasks

## Usage

- "Give me my morning briefing"
- "Set up daily briefing at 8am"
- "Remind me to ask Sarah about the grant when I email her"
- "Alert me 3 days before any grant deadlines"

## How It Works

The proactive system runs in the background and can:
1. Send messages via Telegram at scheduled times
2. Check conditions periodically (deadlines, waiting items)
3. Learn patterns (when you usually check in, what you care about)
