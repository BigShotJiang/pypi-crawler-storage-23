# Bookkeeping Skill

Track income, expenses, and generate financial records.
Nonprofit-specific: donation receipts, 990-prep data, fund accounting.

## Usage

Use this skill when the user wants to:
- Log a donation, grant payment, or other income
- Record an expense (vendor, amount, category)
- View transactions with date/category/fund filters
- Check budget vs. actual spending
- Generate donation receipts (IRS-compliant)
- Get a financial summary for a period
- View fund balances (restricted / unrestricted)
- Export data for IRS Form 990 preparation

## Fund Accounting

Nonprofits track money by fund (general, restricted, temporarily
restricted). Every transaction tags to a fund. Budget comparisons
are per-fund.

## Cross-Skill Integration

- **nonprofit**: Donor gifts auto-create income entries
- **contacts**: generate_receipt pulls contact info from contacts skill
- **documents**: generate_receipt creates formatted PDF via documents skill
- **reports**: financial_summary feeds into board_packet and export tools

## Data Storage

All data in ~/.familiar/data/bookkeeping.json (pure stdlib, no external deps).
