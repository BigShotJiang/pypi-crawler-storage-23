# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Cross-channel Connect Wizard package — re-exports for backward compatibility."""

from ._core import ConnectMixin
from ._helpers import (
    EMAIL_PRESETS,
    SERVICE_BUTTON_LABELS,
    SERVICE_DISPLAY,
    TAB_CATEGORIES,
    TAB_ORDER,
    _check_google_libs,
    _check_tcp_port,
    _check_twilio_lib,
    _password_help,
    _test_http_service,
    _test_imap_connection,
    _update_env_file,
    _update_yaml_config,
)

__all__ = [
    "EMAIL_PRESETS",
    "SERVICE_BUTTON_LABELS",
    "SERVICE_DISPLAY",
    "TAB_CATEGORIES",
    "TAB_ORDER",
    "ConnectMixin",
    "_check_google_libs",
    "_check_tcp_port",
    "_check_twilio_lib",
    "_password_help",
    "_test_http_service",
    "_test_imap_connection",
    "_update_env_file",
    "_update_yaml_config",
]
