import argparse
import os

from . import __version__
from .web_app import create_app
from .paths import resolve_base_dir, ensure_app_dirs, resolve_dir


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Start the mushroom analysis web app."
    )
    parser.add_argument("--host", default=os.getenv("SMPAS_HOST", os.getenv("MUSHROOM_HOST", "0.0.0.0")))
    parser.add_argument("--port", type=int, default=int(os.getenv("SMPAS_PORT", os.getenv("MUSHROOM_PORT", "5000"))))
    parser.add_argument("--base-dir", default=os.getenv("SMPAS_HOME", os.getenv("MUSHROOM_HOME")))
    parser.add_argument("--models-dir", default=os.getenv("SMPAS_MODELS_DIR", os.getenv("MUSHROOM_MODELS_DIR")))
    parser.add_argument("--data-dir", default=os.getenv("SMPAS_DATA_DIR", os.getenv("MUSHROOM_DATA_DIR")))
    parser.add_argument("--uploads-dir", default=os.getenv("SMPAS_UPLOAD_DIR", os.getenv("MUSHROOM_UPLOAD_DIR")))
    parser.add_argument("--yolo-model", default=os.getenv("SMPAS_YOLO_MODEL", os.getenv("MUSHROOM_YOLO_MODEL")))
    parser.add_argument("--sam-model", default=os.getenv("SMPAS_SAM_MODEL", os.getenv("MUSHROOM_SAM_MODEL")))
    parser.add_argument("--device", default=os.getenv("SMPAS_DEVICE", os.getenv("MUSHROOM_DEVICE", "cuda")))
    parser.add_argument("--apriltag-size", type=float, default=float(os.getenv("SMPAS_APRILTAG_SIZE", os.getenv("MUSHROOM_APRILTAG_SIZE", "37.58"))))
    parser.add_argument("--max-workers", type=int, default=int(os.getenv("SMPAS_MAX_WORKERS", os.getenv("MUSHROOM_MAX_WORKERS", "4"))))
    parser.add_argument("--no-parallel", action="store_true")
    parser.add_argument("--debug", action="store_true")
    parser.add_argument("--version", action="store_true")
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.version:
        print(__version__)
        return

    base_dir = resolve_base_dir(args.base_dir)
    ensure_app_dirs(base_dir)
    models_dir = resolve_dir(base_dir, args.models_dir, "SMPAS_MODELS_DIR", "models")
    data_dir = resolve_dir(base_dir, args.data_dir, "SMPAS_DATA_DIR", "data")
    uploads_dir = resolve_dir(base_dir, args.uploads_dir, "SMPAS_UPLOAD_DIR", "uploads")
    models_dir.mkdir(parents=True, exist_ok=True)
    data_dir.mkdir(parents=True, exist_ok=True)
    uploads_dir.mkdir(parents=True, exist_ok=True)

    app = create_app(
        base_dir=str(base_dir),
        models_dir=str(models_dir),
        data_dir=str(data_dir),
        yolo_model_path=args.yolo_model,
        sam_model_path=args.sam_model,
        device=args.device,
        enable_parallel=not args.no_parallel,
        max_workers=args.max_workers,
        apriltag_size_mm=args.apriltag_size,
        upload_dir=str(uploads_dir),
    )

    print("=" * 60)
    print("SMPAS web app")
    print(f"Listening on http://{args.host}:{args.port}")
    print(f"Base dir: {base_dir}")
    print(f"Models dir: {models_dir}")
    print(f"Data dir: {data_dir}")
    print("=" * 60)

    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
