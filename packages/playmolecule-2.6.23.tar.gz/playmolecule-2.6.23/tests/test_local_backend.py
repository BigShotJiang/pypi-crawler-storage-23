import os
import pytest


@pytest.fixture
def test_fake_app_root():
    os.environ["PM_REGISTRIES"] = "local:/dev/null"
    yield
    os.environ["PM_REGISTRIES"] = ""


def test_local_backend_without_installation(test_fake_app_root):
    from playmolecule._backends._local import _LocalManifestBackend

    backend = _LocalManifestBackend("/dev/null")
    assert backend.get_apps() == {}

    # Set the PM_REGISTRIES to the temporary directory
    from playmolecule import apps

    ignore_attrs = ["Path", "logging", "logger", "os", "stat", "KWARGS"]
    assert (
        len([x for x in dir(apps) if not x.startswith("_") and x not in ignore_attrs])
        == 0
    )
    assert not hasattr(apps, "datasets")

    from playmolecule import JobStatus, ExecutableDirectory
