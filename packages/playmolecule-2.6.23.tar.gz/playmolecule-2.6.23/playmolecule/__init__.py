# (c) 2015-2023 Acellera Ltd http://www.acellera.com
# All Rights Reserved
# Distributed under HTMD Software License Agreement
# No redistribution in whole or part
#
import os
import sys
import logging.config
from playmolecule.apps import _find_apps
from playmolecule._backends._slurm import slurm_mps
from playmolecule._update import update_apps
from importlib.metadata import version as __version
from importlib.metadata import PackageNotFoundError
from playmolecule._protocols import __find_protocols
from playmolecule._config import _get_config
from playmolecule._public_api import JobStatus, ExecutableDirectory, describe_apps
from playmolecule._backends._http import login, logout, _check_login_status

# from importlib.resources import files

try:
    __version__ = __version("playmolecule")
except PackageNotFoundError:
    pass

dirname = os.path.dirname(__file__)

try:
    logging.config.fileConfig(
        os.path.join(dirname, "logging.ini"), disable_existing_loggers=False
    )
except Exception:
    print("playmolecule: Logging setup failed")


logger = logging.getLogger(__name__)

module = sys.modules[__name__]
setattr(module, "protocols", None)

# Load configuration from environment
_config = _get_config()

if _config.registries is not None:
    _find_apps(_config.registries)
    if any(registry.startswith("http") for registry in _config.registries):
        _check_login_status()

    local_registry = [
        registry for registry in _config.registries if registry.startswith("local:")
    ]
    if len(local_registry) > 0:
        setattr(
            module,
            "protocols",
            __find_protocols(local_registry[0], parent_module=__name__),
        )
