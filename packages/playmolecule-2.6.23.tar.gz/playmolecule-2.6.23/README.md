# Server-less PlayMolecule

Look up the docs

pip install playmolecule google-cloud-storage==1.35.0
