# -*- coding: utf-8 -*-

# Copyright 2025 (c) Vladislav Punko <iam.vlad.punko@gmail.com>

from easy_mirrors import logger_wrapper

logger_wrapper.setup()
