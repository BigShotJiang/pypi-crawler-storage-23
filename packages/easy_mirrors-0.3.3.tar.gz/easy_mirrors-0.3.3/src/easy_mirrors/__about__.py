# -*- coding: utf-8 -*-

# Copyright 2025 (c) Vladislav Punko <iam.vlad.punko@gmail.com>

__description__ = "Simplest way to mirror and restore git repositories."
