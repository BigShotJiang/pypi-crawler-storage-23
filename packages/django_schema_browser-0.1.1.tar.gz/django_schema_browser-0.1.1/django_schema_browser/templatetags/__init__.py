"""Template tags for django_schema_browser."""
