"""测试 DocLintConfig 配置加载功能"""
import sys
import os

# 添加 src 到路径
src_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'src')
sys.path.insert(0, src_path)

from config import DocLintConfig


def test_basic_load():
    """测试基础配置加载"""
    print("=== 测试 1: 基础配置加载 ===")
    config = DocLintConfig(config_path="tests/test_config.yaml")

    print(f"✅ 配置加载成功")
    print(f"   配置文件: {config.config_path}")
    print(f"   启用规则: {config.get_all_enabled_rules()}")
    print(f"   忽略模式: {config.ignore_patterns}")
    print(f"   LLM 模型: {config.llm_config.get('model')}")

    # 验证规则开关
    assert config.is_rule_enabled("paired-punctuation") == True
    assert config.is_rule_enabled("llm-chinese-typo") == False  # 测试配置中设为 false
    print("✅ 规则开关验证通过")


def test_rule_config():
    """测试规则配置获取"""
    print("\n=== 测试 2: 规则配置获取 ===")
    config = DocLintConfig(config_path="tests/test_config.yaml")

    # 测试基础规则配置
    punct_config = config.get_rule_config("paired-punctuation")
    print(f"   paired-punctuation 配置: {punct_config}")

    # 测试 LLM 规则配置（应合并全局 LLM 配置）
    llm_config = config.get_rule_config("llm-chinese-typo")
    print(f"   llm-chinese-typo 配置: {llm_config}")
    assert llm_config.get("model") == "gpt-4o-mini"  # 规则级覆盖
    assert llm_config.get("timeout") == 30  # 继承全局配置
    print("✅ 规则配置验证通过")


def test_file_ignore():
    """测试文件忽略逻辑"""
    print("\n=== 测试 3: 文件忽略逻辑 ===")
    config = DocLintConfig(config_path="tests/test_config.yaml")

    test_cases = [
        ("src/main.py", False),
        ("node_modules/package/README.md", True),  # ✅ 应忽略
        ("a/b/node_modules/x.md", True),  # ✅ 深层 node_modules
        ("docs/CHANGELOG.md", True),  # ✅ 精确匹配
        ("tests/test.md", False),
        ("dist/output.md", True),  # ✅ dist/**
        ("build/temp/file.md", True),  # ✅ build/**
        ("vendor/lib/README.md", True),  # ✅ vendor/**
    ]

    for file_path, expected in test_cases:
        result = config.should_ignore_file(file_path)
        status = "✅" if result == expected else "❌"
        print(f"   {status} {file_path}: {'忽略' if result else '检查'} (期望: {'忽略' if expected else '检查'})")
        assert result == expected, f"Failed for {file_path}"

    print("✅ 文件忽略验证通过")


def test_default_config():
    """测试默认配置（无配置文件）"""
    print("\n=== 测试 4: 默认配置 ===")
    config = DocLintConfig(config_path="")

    print(f"   启用规则: {config.get_all_enabled_rules()}")
    print(f"   LLM 模型: {config.llm_config.get('model')}")

    # 默认配置应使用 DEFAULT_RULES
    assert config.is_rule_enabled("paired-punctuation") == True
    assert config.llm_config.get("model") == "gpt-3.5-turbo"
    print("✅ 默认配置验证通过")


if __name__ == "__main__":
    test_basic_load()
    test_rule_config()
    test_file_ignore()
    test_default_config()
    print("\n🎉 所有测试通过!")