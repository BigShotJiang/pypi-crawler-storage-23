from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional

class Diagnostic:
    def __init__(self, file: str, line: int, column: int, message: str, severity: str, rule_id: str):
        self.file = file
        self.line = line
        self.column = column
        self.message = message
        self.severity = severity
        self.rule_id = rule_id

    def to_dict(self):
        return self.__dict__

class BaseRule(ABC):
    # 类属性作为默认值
    rule_id = "base_rule"
    severity = "warning"

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化规则，支持从配置文件传入参数
        :param config: 规则配置字典
        """
        self.config = config or {}
        # 初始化实例属性，支持配置覆盖
        self.rule_id = self.config.get("rule_id", self.__class__.rule_id)
        self.severity = self.config.get("severity", self.__class__.severity)

    @abstractmethod
    def check(self, file_path: str, content: str) -> List[Diagnostic]:
        pass
