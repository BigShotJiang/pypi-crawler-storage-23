# src/rules/static/__init__.py
from .punctuation import PairedPunctuationRule
from .trailing_whitespace import NoTrailingWhitespaceRule
from .heading_space import HeadingSpaceRule
from .relative_link import RelativeLinkRule

__all__ = [
    'PairedPunctuationRule',
    'NoTrailingWhitespaceRule',
    'HeadingSpaceRule',
    'RelativeLinkRule'
]