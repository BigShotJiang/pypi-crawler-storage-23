# src/__init__.py
__version__ = "0.1.2"
__all__ = ["main", "config", "engine", "rules"]