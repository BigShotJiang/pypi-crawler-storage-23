"""
Integration tests for TimeFilter model and its integration with get_objects().

Tests use the same in-memory SQLite database and exam-crm production schema.
Applicant model has created_at and updated_at fields.
"""

from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

import sqlmodel_object_helpers as soh

from conftest import Applicant, Organization


# ============================================================================
# TimeFilter model validation tests
# ============================================================================


def test_time_filter_empty():
    """TimeFilter with no fields is valid (noop filter)."""
    tf = soh.TimeFilter()
    assert tf.created_after is None
    assert tf.created_before is None


def test_time_filter_created_range():
    """TimeFilter with valid created range, aware UTC datetimes."""
    tf = soh.TimeFilter(
        created_after=datetime(2026, 1, 1, tzinfo=timezone.utc),
        created_before=datetime(2026, 12, 31, tzinfo=timezone.utc),
    )
    assert tf.created_after == datetime(2026, 1, 1, tzinfo=timezone.utc)
    assert tf.created_before == datetime(2026, 12, 31, tzinfo=timezone.utc)


def test_time_filter_rejects_naive():
    """TimeFilter rejects naive datetime (no tzinfo)."""
    with pytest.raises(ValidationError, match="Naive datetime is not allowed"):
        soh.TimeFilter(created_after=datetime(2026, 1, 1))


def test_time_filter_invalid_created_range():
    """TimeFilter rejects created_after >= created_before."""
    with pytest.raises(ValidationError, match="created_after must be before"):
        soh.TimeFilter(
            created_after=datetime(2026, 12, 31, tzinfo=timezone.utc),
            created_before=datetime(2026, 1, 1, tzinfo=timezone.utc),
        )


def test_time_filter_invalid_updated_range():
    """TimeFilter rejects updated_after >= updated_before."""
    with pytest.raises(ValidationError, match="updated_after must be before"):
        soh.TimeFilter(
            updated_after=datetime(2026, 6, 1, tzinfo=timezone.utc),
            updated_before=datetime(2026, 1, 1, tzinfo=timezone.utc),
        )


def test_time_filter_equal_dates_rejected():
    """TimeFilter rejects created_after == created_before (must be strictly before)."""
    with pytest.raises(ValidationError):
        soh.TimeFilter(
            created_after=datetime(2026, 6, 1, tzinfo=timezone.utc),
            created_before=datetime(2026, 6, 1, tzinfo=timezone.utc),
        )


def test_time_filter_cross_type_validation():
    """TimeFilter rejects created_after >= updated_before (logically impossible)."""
    with pytest.raises(ValidationError, match="created_after cannot be >= updated_before"):
        soh.TimeFilter(
            created_after=datetime(2026, 6, 1, tzinfo=timezone.utc),
            updated_before=datetime(2026, 5, 1, tzinfo=timezone.utc),
        )


def test_time_filter_cross_type_equal_rejected():
    """TimeFilter rejects created_after == updated_before."""
    with pytest.raises(ValidationError, match="created_after cannot be >= updated_before"):
        soh.TimeFilter(
            created_after=datetime(2026, 6, 1, tzinfo=timezone.utc),
            updated_before=datetime(2026, 6, 1, tzinfo=timezone.utc),
        )


def test_time_filter_cross_type_valid():
    """TimeFilter allows created_after < updated_before."""
    tf = soh.TimeFilter(
        created_after=datetime(2026, 1, 1, tzinfo=timezone.utc),
        updated_before=datetime(2026, 6, 1, tzinfo=timezone.utc),
    )
    assert tf.created_after == datetime(2026, 1, 1, tzinfo=timezone.utc)
    assert tf.updated_before == datetime(2026, 6, 1, tzinfo=timezone.utc)


def test_time_filter_forbids_extra():
    """TimeFilter rejects unknown fields."""
    with pytest.raises(ValidationError):
        soh.TimeFilter(unknown_field="value")


# ============================================================================
# TimeFilter integration with get_objects
# ============================================================================


@pytest.mark.asyncio
async def test_get_objects_time_filter_created_after(session, seed_data):
    """get_objects with time_filter filters by created_at >= value."""
    # applicant1: 2026-01-05, applicant2: 2026-01-08, applicant3: 2026-01-10
    results = await soh.get_objects(
        session, Applicant,
        time_filter=soh.TimeFilter(created_after=datetime(2026, 1, 9, tzinfo=timezone.utc)),
    )
    assert len(results) == 1
    assert results[0].last_name == "Сидоров"


@pytest.mark.asyncio
async def test_get_objects_time_filter_created_before(session, seed_data):
    """get_objects with time_filter filters by created_at < value (half-open interval)."""
    results = await soh.get_objects(
        session, Applicant,
        time_filter=soh.TimeFilter(created_before=datetime(2026, 1, 6, tzinfo=timezone.utc)),
    )
    assert len(results) == 1
    assert results[0].last_name == "Иванов"


@pytest.mark.asyncio
async def test_get_objects_time_filter_before_boundary_exclusive(session, seed_data):
    """created_before is exclusive (half-open interval): record with created_at == boundary is NOT included."""
    # applicant1: created_at = 2026-01-05 10:00
    # Using created_before = exact same timestamp should EXCLUDE applicant1
    results = await soh.get_objects(
        session, Applicant,
        time_filter=soh.TimeFilter(created_before=datetime(2026, 1, 5, 10, 0, tzinfo=timezone.utc)),
    )
    assert len(results) == 0


@pytest.mark.asyncio
async def test_get_objects_time_filter_range(session, seed_data):
    """get_objects with time_filter range: created_after AND created_before."""
    results = await soh.get_objects(
        session, Applicant,
        time_filter=soh.TimeFilter(
            created_after=datetime(2026, 1, 6, tzinfo=timezone.utc),
            created_before=datetime(2026, 1, 9, tzinfo=timezone.utc),
        ),
    )
    assert len(results) == 1
    assert results[0].last_name == "Петрова"


@pytest.mark.asyncio
async def test_get_objects_time_filter_with_regular_filters(session, seed_data):
    """time_filter combined with regular filters (AND)."""
    results = await soh.get_objects(
        session, Applicant,
        filters={"is_nrs": {soh.Operator.EQ: True}},
        time_filter=soh.TimeFilter(created_after=datetime(2026, 1, 6, tzinfo=timezone.utc)),
    )
    # applicant3 (Сидоров): is_nrs=True, created_at=2026-01-10 → matches
    # applicant1 (Иванов): is_nrs=True, created_at=2026-01-05 → created_at too early
    assert len(results) == 1
    assert results[0].last_name == "Сидоров"


@pytest.mark.asyncio
async def test_get_objects_time_filter_no_field_on_model_raises(session, seed_data):
    """time_filter raises InvalidFilterError when model lacks the datetime field."""
    with pytest.raises(soh.InvalidFilterError, match="Organization has no field created_at"):
        await soh.get_objects(
            session, Organization,
            time_filter=soh.TimeFilter(created_after=datetime(2020, 1, 1, tzinfo=timezone.utc)),
        )


@pytest.mark.asyncio
async def test_get_objects_time_filter_no_field_on_model_suspend_error(session, seed_data):
    """time_filter silently ignores missing fields when suspend_error=True."""
    results = await soh.get_objects(
        session, Organization,
        time_filter=soh.TimeFilter(created_after=datetime(2020, 1, 1, tzinfo=timezone.utc)),
        suspend_error=True,
    )
    assert len(results) == 2


@pytest.mark.asyncio
async def test_count_objects_time_filter_no_field_raises(session, seed_data):
    """count_objects raises InvalidFilterError when model lacks datetime field."""
    with pytest.raises(soh.InvalidFilterError, match="Organization has no field created_at"):
        await soh.count_objects(
            session, Organization,
            time_filter=soh.TimeFilter(created_after=datetime(2020, 1, 1, tzinfo=timezone.utc)),
        )


@pytest.mark.asyncio
async def test_get_objects_time_filter_empty_no_error_on_any_model(session, seed_data):
    """Empty TimeFilter (all None) is a valid noop — no error even on models without datetime fields."""
    results = await soh.get_objects(
        session, Organization,
        time_filter=soh.TimeFilter(),
    )
    assert len(results) == 2
