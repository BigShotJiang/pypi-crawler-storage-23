"""Tests for sqlmodel_object_helpers.standalone module.

Verifies that standalone wrappers correctly create sessions,
commit on success, and rollback on error.
"""

import logging
from datetime import datetime
from unittest.mock import AsyncMock

import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy import event
from sqlmodel import SQLModel

import sqlmodel_object_helpers as soh
import sqlmodel_object_helpers.standalone as soh_sa
from conftest import (
    Applicant, Application, Attempt, Bank, BankAccount, Billing,
    BillingPaymentAO, Organization, Payment, Unit, Schedule,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture
async def sa_engine():
    """Standalone engine — separate from the main test engine."""
    eng = create_async_engine("sqlite+aiosqlite:///:memory:")

    @event.listens_for(eng.sync_engine, "connect")
    def _set_sqlite_pragma(dbapi_conn, connection_record):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    async with eng.begin() as conn:
        await conn.run_sync(SQLModel.metadata.create_all)
    yield eng
    await eng.dispose()


@pytest_asyncio.fixture
async def sa_factory(sa_engine):
    """Configure soh with a session factory for standalone tests."""
    factory = async_sessionmaker(sa_engine, expire_on_commit=False)
    soh.configure(factory)
    yield factory
    # Reset after test
    soh.settings.session_factory = None


@pytest_asyncio.fixture
async def sa_seed(sa_factory):
    """Seed minimal data for standalone query tests."""
    async with sa_factory() as session:
        org = Organization(
            short_name="TestOrg", inn="1234567890",
        )
        session.add(org)
        await session.flush()

        unit = Unit(
            address="Test Address", full_name="Test Unit",
            short_name="TU", max_pc=10, organization_id=org.id,
        )
        session.add(unit)
        await session.flush()

        applicant = Applicant(
            last_name="Тестов", first_name="Тест",
            passport_number="999999",
        )
        session.add(applicant)
        await session.flush()

        app = Application(
            applicant_id=applicant.id, email="test@test.com",
        )
        session.add(app)
        await session.flush()

        schedule = Schedule(
            is_nostroy=True, is_nopriz=False, is_portfolio=False,
            is_singly=False, schedule_date=datetime(2026, 3, 15, 9, 0),
            unit_id=unit.id, max_pc=10,
        )
        session.add(schedule)
        await session.flush()

        attempt = Attempt(
            application_id=app.id, schedule_id=schedule.id,
            unit_id=unit.id, status_id=10, is_active=True, is_blocked=False,
        )
        session.add(attempt)
        await session.commit()

    return {
        "organization": org,
        "unit": unit,
        "applicant": applicant,
        "application": app,
        "attempt": attempt,
    }


# ---------------------------------------------------------------------------
# configure() tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_configure_not_called_raises():
    """Calling standalone without configure() raises RuntimeError."""
    soh.settings.session_factory = None
    with pytest.raises(RuntimeError, match="Session factory not configured"):
        await soh_sa.get_object(Applicant, pk={"id": 1})


@pytest.mark.asyncio
async def test_auto_session_without_configure_raises():
    """auto_session() directly raises RuntimeError without configure()."""
    soh.settings.session_factory = None
    with pytest.raises(RuntimeError, match="Session factory not configured"):
        async with soh.auto_session():
            pass


@pytest.mark.asyncio
async def test_configure_sets_factory(sa_factory):
    """configure() stores the factory in settings."""
    assert soh.settings.session_factory is sa_factory


@pytest.mark.asyncio
async def test_configure_warns_expire_on_commit_true(sa_engine, caplog):
    """configure() warns when expire_on_commit is True (default)."""
    factory = async_sessionmaker(sa_engine)  # default expire_on_commit=True
    with caplog.at_level(logging.WARNING, logger="sqlmodel_object_helpers"):
        soh.configure(factory)
    assert "expire_on_commit=True" in caplog.text
    soh.settings.session_factory = None


# ---------------------------------------------------------------------------
# Query tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_object(sa_seed):
    """get_object returns a single object by pk."""
    applicant = sa_seed["applicant"]
    result = await soh_sa.get_object(Applicant, pk={"id": applicant.id})
    assert result is not None
    assert result.last_name == "Тестов"


@pytest.mark.asyncio
async def test_get_object_not_found(sa_seed):
    """get_object raises ObjectNotFoundError for missing pk."""
    with pytest.raises(soh.ObjectNotFoundError):
        await soh_sa.get_object(Applicant, pk={"id": 99999})


@pytest.mark.asyncio
async def test_get_object_suspend_error(sa_seed):
    """get_object returns None with suspend_error=True."""
    result = await soh_sa.get_object(
        Applicant, pk={"id": 99999}, suspend_error=True,
    )
    assert result is None


@pytest.mark.asyncio
async def test_get_objects(sa_seed):
    """get_objects returns all matching objects."""
    result = await soh_sa.get_objects(Applicant)
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0].last_name == "Тестов"


@pytest.mark.asyncio
async def test_get_objects_with_filters(sa_seed):
    """get_objects with filters."""
    result = await soh_sa.get_objects(
        Applicant, filters={"last_name": {soh.Operator.EQ: "Тестов"}},
    )
    assert len(result) == 1


@pytest.mark.asyncio
async def test_count_objects(sa_seed):
    """count_objects returns correct count."""
    count = await soh_sa.count_objects(Applicant)
    assert count == 1


@pytest.mark.asyncio
async def test_exists_object(sa_seed):
    """exists_object returns True/False."""
    applicant = sa_seed["applicant"]
    assert await soh_sa.exists_object(Applicant, pk={"id": applicant.id}) is True
    assert await soh_sa.exists_object(Applicant, pk={"id": 99999}) is False


@pytest.mark.asyncio
async def test_get_projection(sa_seed):
    """get_projection returns specific columns as dicts."""
    result = await soh_sa.get_projection(
        Applicant,
        columns=["last_name", "passport_number"],
    )
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0]["last_name"] == "Тестов"
    assert result[0]["passport_number"] == "999999"


# ---------------------------------------------------------------------------
# Mutation tests — verify commit actually happens
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_add_object_commits(sa_factory):
    """add_object commits data — verifiable in a separate session."""
    new_applicant = Applicant(
        last_name="Новиков", first_name="Новик",
        passport_number="777777",
    )
    result = await soh_sa.add_object(new_applicant)
    assert result.id is not None

    # Verify in a separate session — data must be committed
    async with sa_factory() as verify_session:
        row = await verify_session.get(Applicant, result.id)
        assert row is not None
        assert row.last_name == "Новиков"


@pytest.mark.asyncio
async def test_add_objects_commits(sa_factory):
    """add_objects commits multiple objects."""
    items = [
        Applicant(last_name="Один", passport_number="111111"),
        Applicant(last_name="Два", passport_number="222222"),
    ]
    result = await soh_sa.add_objects(items)
    assert len(result) == 2
    assert all(r.id is not None for r in result)

    # Verify
    async with sa_factory() as verify_session:
        row = await verify_session.get(Applicant, result[0].id)
        assert row is not None
        assert row.last_name == "Один"


@pytest.mark.asyncio
async def test_update_object_commits(sa_factory):
    """update_object commits changes."""
    created = await soh_sa.add_object(
        Applicant(last_name="Старый", passport_number="333333"),
    )

    updated = await soh_sa.update_object(created, {"last_name": "Новый"})
    assert updated.last_name == "Новый"

    # Verify
    async with sa_factory() as verify_session:
        row = await verify_session.get(Applicant, created.id)
        assert row.last_name == "Новый"


@pytest.mark.asyncio
async def test_delete_object_commits(sa_factory):
    """delete_object commits deletion."""
    created = await soh_sa.add_object(
        Applicant(last_name="Удаляемый", passport_number="444444"),
    )
    pk = {"id": created.id}

    await soh_sa.delete_object(Applicant, pk=pk)

    # Verify — should be gone
    async with sa_factory() as verify_session:
        row = await verify_session.get(Applicant, created.id)
        assert row is None


@pytest.mark.asyncio
async def test_delete_object_by_instance_commits(sa_factory):
    """delete_object with instance= (detached) commits deletion."""
    created = await soh_sa.add_object(
        Applicant(last_name="Удаляемый2", passport_number="444555"),
    )
    saved_id = created.id

    # created is detached — loaded in a different auto_session
    await soh_sa.delete_object(Applicant, instance=created)

    # Verify — should be gone
    async with sa_factory() as verify_session:
        row = await verify_session.get(Applicant, saved_id)
        assert row is None


@pytest.mark.asyncio
async def test_mutation_rollback_on_error(sa_factory):
    """Failed mutation rolls back — no partial data in DB."""
    created = await soh_sa.add_object(
        Applicant(last_name="Целый", passport_number="555555"),
    )

    with pytest.raises(soh.MutationError):
        await soh_sa.update_object(created, {"nonexistent_field": "value"})

    # Verify — original data unchanged
    async with sa_factory() as verify_session:
        row = await verify_session.get(Applicant, created.id)
        assert row.last_name == "Целый"


@pytest.mark.asyncio
async def test_update_objects_commits(sa_factory):
    """update_objects bulk-updates and commits."""
    a1 = await soh_sa.add_object(
        Applicant(last_name="Первый", passport_number="100001", is_nrs=False),
    )
    a2 = await soh_sa.add_object(
        Applicant(last_name="Второй", passport_number="100002", is_nrs=False),
    )

    count = await soh_sa.update_objects(
        Applicant,
        data={"is_nrs": True},
        filters={"is_nrs": {soh.Operator.EQ: False}},
    )
    assert count == 2

    # Verify
    async with sa_factory() as verify_session:
        row1 = await verify_session.get(Applicant, a1.id)
        row2 = await verify_session.get(Applicant, a2.id)
        assert row1.is_nrs is True
        assert row2.is_nrs is True


@pytest.mark.asyncio
async def test_delete_objects_commits(sa_factory):
    """delete_objects bulk-deletes and commits."""
    a1 = await soh_sa.add_object(
        Applicant(last_name="Удаляемый", passport_number="200001", is_nrs=True),
    )
    a2 = await soh_sa.add_object(
        Applicant(last_name="Остаётся", passport_number="200002", is_nrs=False),
    )

    count = await soh_sa.delete_objects(
        Applicant,
        filters={"is_nrs": {soh.Operator.EQ: True}},
    )
    assert count == 1

    # Verify
    async with sa_factory() as verify_session:
        assert await verify_session.get(Applicant, a1.id) is None
        assert await verify_session.get(Applicant, a2.id) is not None


@pytest.mark.asyncio
async def test_check_for_related_records(sa_seed):
    """check_for_related_records finds dependent children."""
    applicant = sa_seed["applicant"]
    related = await soh_sa.check_for_related_records(
        Applicant, pk={"id": applicant.id},
    )
    # applicant has an Application → related records exist
    assert related is not None
    assert len(related) >= 1


@pytest.mark.asyncio
async def test_check_for_related_records_none(sa_factory):
    """check_for_related_records returns None when no children."""
    created = await soh_sa.add_object(
        Applicant(last_name="Одинокий", passport_number="300001"),
    )
    related = await soh_sa.check_for_related_records(
        Applicant, pk={"id": created.id},
    )
    assert related is None


# ---------------------------------------------------------------------------
# auto_session() direct usage test
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_auto_session_multiple_operations(sa_factory):
    """auto_session() allows multiple operations in one transaction."""
    async with soh.auto_session() as session:
        a1 = Applicant(last_name="Первый", passport_number="666666")
        await soh.add_object(session, a1)
        a2 = Applicant(last_name="Второй", passport_number="777777")
        await soh.add_object(session, a2)
    # Both committed together

    async with sa_factory() as verify_session:
        row1 = await verify_session.get(Applicant, a1.id)
        row2 = await verify_session.get(Applicant, a2.id)
        assert row1 is not None
        assert row2 is not None
        assert row1.last_name == "Первый"
        assert row2.last_name == "Второй"


@pytest.mark.asyncio
async def test_auto_session_rollback_all_on_error(sa_factory):
    """auto_session() rolls back ALL operations on any error."""
    a1_id = None
    with pytest.raises(soh.MutationError):
        async with soh.auto_session() as session:
            a1 = Applicant(last_name="Сохранится?", passport_number="888888")
            await soh.add_object(session, a1)
            a1_id = a1.id
            # This will fail — nonexistent field
            await soh.update_object(session, a1, {"bad_field": "x"})

    # Both operations rolled back
    if a1_id is not None:
        async with sa_factory() as verify_session:
            row = await verify_session.get(Applicant, a1_id)
            assert row is None  # rolled back


# ---------------------------------------------------------------------------
# Standalone logging tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_standalone_get_object_logs(sa_seed, caplog):
    """standalone.get_object writes a DEBUG log entry."""
    applicant = sa_seed["applicant"]
    with caplog.at_level(logging.DEBUG, logger="sqlmodel_object_helpers"):
        await soh_sa.get_object(Applicant, pk={"id": applicant.id})
    assert "standalone.get_object(Applicant" in caplog.text


@pytest.mark.asyncio
async def test_standalone_add_object_logs(sa_factory, caplog):
    """standalone.add_object writes a DEBUG log entry."""
    with caplog.at_level(logging.DEBUG, logger="sqlmodel_object_helpers"):
        await soh_sa.add_object(
            Applicant(last_name="ЛогТест", passport_number="900001"),
        )
    assert "standalone.add_object(Applicant)" in caplog.text


@pytest.mark.asyncio
async def test_standalone_count_objects_logs(sa_seed, caplog):
    """standalone.count_objects writes a DEBUG log entry."""
    with caplog.at_level(logging.DEBUG, logger="sqlmodel_object_helpers"):
        await soh_sa.count_objects(Applicant)
    assert "standalone.count_objects(Applicant)" in caplog.text


# ---------------------------------------------------------------------------
# Safe rollback tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_auto_session_rollback_failure_preserves_original_error(sa_factory):
    """If rollback() itself fails, the original exception is still raised."""
    original_error = soh.MutationError("original error")

    async def _broken_body(session):
        raise original_error

    with pytest.raises(soh.MutationError, match="original error"):
        async with soh.auto_session() as session:
            # Patch rollback to also fail
            session.rollback = AsyncMock(side_effect=RuntimeError("rollback broken"))
            raise original_error


# ---------------------------------------------------------------------------
# create_session_dependency() tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_session_dependency_yields_session(sa_factory):
    """create_session_dependency() yields a working AsyncSession."""
    get_session = soh.create_session_dependency(sa_factory)
    gen = get_session()
    session = await gen.__anext__()
    assert isinstance(session, AsyncSession)
    # Clean exit — triggers commit
    with pytest.raises(StopAsyncIteration):
        await gen.__anext__()


@pytest.mark.asyncio
async def test_create_session_dependency_commits_on_success(sa_factory):
    """DI session commits data that is visible in a subsequent session."""
    get_session = soh.create_session_dependency(sa_factory)

    # Simulate endpoint: add object via DI session
    gen = get_session()
    session = await gen.__anext__()
    new_app = Applicant(last_name="DI-Тест", passport_number="DI0001")
    await soh.add_object(session, new_app)
    saved_id = new_app.id
    # Exit generator → commit
    with pytest.raises(StopAsyncIteration):
        await gen.__anext__()

    # Verify — data must be committed
    async with sa_factory() as verify:
        row = await verify.get(Applicant, saved_id)
        assert row is not None
        assert row.last_name == "DI-Тест"


@pytest.mark.asyncio
async def test_create_session_dependency_rollback_on_error(sa_factory):
    """DI session rolls back when the endpoint raises an error."""
    get_session = soh.create_session_dependency(sa_factory)

    gen = get_session()
    session = await gen.__anext__()
    new_app = Applicant(last_name="DI-Rollback", passport_number="DI0002")
    await soh.add_object(session, new_app)
    saved_id = new_app.id
    # Throw into generator → triggers rollback, then re-raises
    with pytest.raises(ValueError, match="endpoint error"):
        await gen.athrow(ValueError("endpoint error"))

    # Verify — data must NOT be committed
    async with sa_factory() as verify:
        row = await verify.get(Applicant, saved_id)
        assert row is None


# ---------------------------------------------------------------------------
# Endpoint-simulation tests — realistic multi-call scenarios
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_endpoint_get_attempt_with_related_data(sa_seed):
    """
    Simulate GET /attempts/{id}/details — multiple get_object calls
    to gather attempt + application + applicant in one session.
    """
    attempt_data = sa_seed["attempt"]
    app_data = sa_seed["application"]

    async with soh.auto_session() as session:
        attempt = await soh.get_object(session, Attempt, pk={"id": attempt_data.id})
        assert attempt is not None
        assert attempt.status_id == 10

        application = await soh.get_object(
            session, Application, pk={"id": attempt.application_id},
        )
        assert application is not None
        assert application.email == "test@test.com"

        applicant = await soh.get_object(
            session, Applicant, pk={"id": application.applicant_id},
        )
        assert applicant is not None
        assert applicant.last_name == "Тестов"


@pytest.mark.asyncio
async def test_endpoint_create_attempt_with_validation(sa_seed):
    """
    Simulate POST /attempts — validate that applicant and schedule
    exist before creating a new attempt.
    """
    applicant_data = sa_seed["applicant"]
    unit_data = sa_seed["unit"]

    async with soh.auto_session() as session:
        # Step 1: validate applicant exists
        applicant = await soh.get_object(
            session, Applicant, pk={"id": applicant_data.id},
        )
        assert applicant is not None

        # Step 2: get existing application
        apps = await soh.get_objects(
            session, Application,
            filters={"applicant_id": {soh.Operator.EQ: applicant.id}},
        )
        assert len(apps) >= 1
        application = apps[0]

        # Step 3: count existing active attempts
        active_count = await soh.count_objects(
            session, Attempt,
            filters={"application_id": {soh.Operator.EQ: application.id}},
        )
        assert active_count >= 1

        # Step 4: create new attempt
        new_attempt = Attempt(
            application_id=application.id,
            unit_id=unit_data.id,
            status_id=10,
            is_active=True,
            is_blocked=False,
        )
        await soh.add_object(session, new_attempt)
        assert new_attempt.id is not None

    # Verify the new attempt was committed
    result = await soh_sa.get_object(Attempt, pk={"id": new_attempt.id})
    assert result is not None
    assert result.application_id == application.id


@pytest.mark.asyncio
async def test_endpoint_update_status_with_validation(sa_seed):
    """
    Simulate PUT /attempts/{id}/status — get attempt, validate
    current status, then update.
    """
    attempt_data = sa_seed["attempt"]

    async with soh.auto_session() as session:
        # Step 1: fetch attempt
        attempt = await soh.get_object(
            session, Attempt, pk={"id": attempt_data.id},
        )
        assert attempt is not None

        # Step 2: business rule — can only move from status 10 (draft)
        assert attempt.status_id == 10, "Can only transition from Черновик"

        # Step 3: update status
        updated = await soh.update_object(session, attempt, {"status_id": 20})
        assert updated.status_id == 20

    # Verify committed
    result = await soh_sa.get_object(Attempt, pk={"id": attempt_data.id})
    assert result.status_id == 20


@pytest.mark.asyncio
async def test_endpoint_bulk_read_and_aggregation(sa_seed):
    """
    Simulate GET /dashboard — multiple get_objects + count_objects + exists_object
    aggregated into a single session for a dashboard response.
    """
    async with soh.auto_session() as session:
        # Active attempts
        active_attempts = await soh.get_objects(
            session, Attempt,
            filters={"is_active": {soh.Operator.EQ: True}},
        )
        assert len(active_attempts) >= 1

        # Total applicants
        total = await soh.count_objects(session, Applicant)
        assert total >= 1

        # Check if schedule exists
        schedule = sa_seed["attempt"].schedule_id
        has_schedule = await soh.exists_object(
            session, Schedule, pk={"id": schedule},
        )
        assert has_schedule is True

        # Get unit info
        unit = await soh.get_object(
            session, Unit, pk={"id": sa_seed["unit"].id},
        )
        assert unit is not None
        assert unit.short_name == "TU"


@pytest.mark.asyncio
async def test_endpoint_add_and_update_in_one_session(sa_factory):
    """
    Simulate POST /applicants + immediate profile update
    (create then patch in one request).
    """
    async with soh.auto_session() as session:
        # Step 1: create applicant
        applicant = Applicant(
            last_name="Создан", first_name="Тест", passport_number="EP0001",
        )
        await soh.add_object(session, applicant)
        assert applicant.id is not None

        # Step 2: immediately update phone
        updated = await soh.update_object(
            session, applicant, {"phone": "+79001112233"},
        )
        assert updated.phone == "+79001112233"

        # Step 3: create application for this applicant
        app = Application(
            applicant_id=applicant.id, email="created@test.com",
        )
        await soh.add_object(session, app)
        assert app.id is not None

    # Verify all committed
    async with sa_factory() as verify:
        row = await verify.get(Applicant, applicant.id)
        assert row.last_name == "Создан"
        assert row.phone == "+79001112233"
        app_row = await verify.get(Application, app.id)
        assert app_row.applicant_id == applicant.id


@pytest.mark.asyncio
async def test_endpoint_partial_failure_rolls_back_everything(sa_factory):
    """
    Simulate endpoint where first mutation succeeds but second fails —
    entire transaction must be rolled back.
    """
    created_id = None
    with pytest.raises(soh.MutationError):
        async with soh.auto_session() as session:
            # Step 1: create applicant — succeeds
            applicant = Applicant(
                last_name="Должен-откатиться", passport_number="RB0001",
            )
            await soh.add_object(session, applicant)
            created_id = applicant.id

            # Step 2: update with invalid field — fails
            await soh.update_object(session, applicant, {"bad_field": "x"})

    # Verify: applicant must NOT exist (rolled back)
    if created_id is not None:
        async with sa_factory() as verify:
            row = await verify.get(Applicant, created_id)
            assert row is None


@pytest.mark.asyncio
async def test_endpoint_di_session_multiple_reads_and_write(sa_seed, sa_factory):
    """
    Simulate a full DI endpoint: multiple reads + one write via
    create_session_dependency (same pattern as FastAPI Depends).
    """
    get_session = soh.create_session_dependency(sa_factory)
    attempt_data = sa_seed["attempt"]

    gen = get_session()
    session = await gen.__anext__()

    # Read 1: get attempt
    attempt = await soh.get_object(session, Attempt, pk={"id": attempt_data.id})
    assert attempt is not None

    # Read 2: get applicant through application
    application = await soh.get_object(
        session, Application, pk={"id": attempt.application_id},
    )
    applicant = await soh.get_object(
        session, Applicant, pk={"id": application.applicant_id},
    )
    assert applicant.last_name == "Тестов"

    # Write: update attempt status
    await soh.update_object(session, attempt, {"status_id": 100})

    # Exit generator → commit
    with pytest.raises(StopAsyncIteration):
        await gen.__anext__()

    # Verify committed
    async with sa_factory() as verify:
        row = await verify.get(Attempt, attempt_data.id)
        assert row.status_id == 100


@pytest.mark.asyncio
async def test_endpoint_check_before_delete(sa_seed):
    """
    Simulate DELETE /applicants/{id} — check for related records
    before attempting deletion (should fail due to existing application).
    """
    applicant = sa_seed["applicant"]

    async with soh.auto_session() as session:
        # Step 1: check for related records
        related = await soh.check_for_related_records(
            session, Applicant, pk={"id": applicant.id},
        )
        assert related is not None, "Should find related Application"
        assert len(related) >= 1

        # Step 2: since related records exist, do NOT delete — return 409-like response
        # (business logic: abort instead of cascade)

    # Verify applicant still exists
    result = await soh_sa.get_object(
        Applicant, pk={"id": applicant.id}, suspend_error=True,
    )
    assert result is not None


@pytest.mark.asyncio
async def test_endpoint_get_object_not_found_suspend_in_session(sa_factory):
    """
    Simulate endpoint that gracefully handles missing related data
    using suspend_error=True within a session.
    """
    applicant = await soh_sa.add_object(
        Applicant(last_name="Одинокий", passport_number="NF0001"),
    )

    async with soh.auto_session() as session:
        # Fetch applicant — exists
        found = await soh.get_object(
            session, Applicant, pk={"id": applicant.id},
        )
        assert found is not None

        # Try to fetch nonexistent application — suspend_error avoids crash
        maybe_app = await soh.get_object(
            session, Application, pk={"id": 99999}, suspend_error=True,
        )
        assert maybe_app is None

        # Session still usable after suspend_error
        count = await soh.count_objects(session, Applicant)
        assert count >= 1


# ---------------------------------------------------------------------------
# Rich seed fixture — mirrors production exam-crm data graph
# ---------------------------------------------------------------------------


@pytest_asyncio.fixture
async def sa_seed_full(sa_factory):
    """
    Seed a full production-like data graph for realistic endpoint tests.

    Chain: Organization → Bank → BankAccount
                       → Unit → Schedule → Attempt → Application → Applicant
                                         → Billing ←→ Payment (via BillingPaymentAO)
    """
    async with sa_factory() as session:
        org = Organization(
            short_name='ООО "Квалитех"',
            full_name='Общество с ограниченной ответственностью "Квалитех"',
            inn="5003112233", kpp="500301001",
        )
        session.add(org)
        await session.flush()

        bank = Bank(name="АО Альфа-Банк", bik="044525593", ks="30101810200000000593")
        session.add(bank)
        await session.flush()

        bank_acc = BankAccount(
            bank_rs="40702810501000077777",
            organization_id=org.id, bank_id=bank.id,
        )
        session.add(bank_acc)
        await session.flush()

        unit = Unit(
            address="г. Новосибирск, ул. Кирова, д. 42, оф. 510",
            full_name="Экзаменационный центр Новосибирск",
            short_name="ЭЦ-НСК",
            max_pc=15, organization_id=org.id, city="Новосибирск",
        )
        session.add(unit)
        await session.flush()

        schedule = Schedule(
            is_nostroy=True, is_nopriz=False, is_portfolio=False,
            is_singly=False, schedule_date=datetime(2026, 4, 20, 10, 0),
            unit_id=unit.id, max_pc=15,
        )
        session.add(schedule)
        await session.flush()

        applicant = Applicant(
            last_name="Козлов", first_name="Дмитрий", middle_name="Андреевич",
            passport_number="887766", passport_series="5420",
            snils="555-666-777 88", phone="+79539876543",
            is_nrs=True,
        )
        session.add(applicant)
        await session.flush()

        application = Application(
            applicant_id=applicant.id, email="kozlov.da@qualiteh.ru",
            is_closed=False,
        )
        session.add(application)
        await session.flush()

        attempt = Attempt(
            application_id=application.id, schedule_id=schedule.id,
            unit_id=unit.id, status_id=10, is_active=True, is_blocked=False,
            email="kozlov.da@qualiteh.ru",
        )
        session.add(attempt)
        await session.flush()

        billing = Billing(
            attempt_id=attempt.id, billing_type_id=1,
            bank_acc_id=bank_acc.id, organization_id=org.id,
            is_physical=True, is_paid=False,
            invoice_reason="Независимая оценка квалификации ГИП",
            invoice_date=datetime(2026, 3, 10).date(),
            agreement_create_date=datetime(2026, 3, 1).date(),
            agreement_expire_date=datetime(2027, 2, 28).date(),
            address="г. Новосибирск, ул. Кирова, д. 42",
            invoice_number="КТ-0001",
            agreement_number="КТ-Д-0001",
            organization_short_name=org.short_name,
            organization_inn=org.inn,
            bank_bik=bank.bik, bank_name=bank.name,
            bank_rs=bank_acc.bank_rs,
        )
        session.add(billing)
        await session.flush()

        payment = Payment(
            operation_date=datetime(2026, 3, 12).date(),
            corespond_inn=org.inn,
            corespond_name=org.short_name,
            doc_number="ПП-7701",
            doc_date=datetime(2026, 3, 12).date(),
            credit=7500,
            payment_type_id=1, user_id=1,
            md5="f9e8d7c6b5a4",
            applicant_id=applicant.id,
        )
        session.add(payment)
        await session.flush()

        bp = BillingPaymentAO(billing_id=billing.id, payment_id=payment.id)
        session.add(bp)
        await session.commit()

    return {
        "organization": org,
        "bank": bank,
        "bank_account": bank_acc,
        "unit": unit,
        "schedule": schedule,
        "applicant": applicant,
        "application": application,
        "attempt": attempt,
        "billing": billing,
        "payment": payment,
    }


# ---------------------------------------------------------------------------
# Production-like endpoint tests — mirrors real ExamCRM handlers
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_endpoint_generate_docs_flow(sa_seed_full):
    """
    Simulate generate_docs_1c() — the most complex real endpoint:
      1. get_object(Attempt) with load_paths=["unit", "billings"]
      2. get_object(Application) with load_paths=["applicant"]
      3. Access relationship attrs: attempt.unit.full_name, attempt.billings,
         application.applicant.last_name
      4. get_objects(Billing) by attempt filter
    """
    d = sa_seed_full

    async with soh.auto_session() as session:
        # Step 1: load attempt with unit + billings (like production)
        attempt = await soh.get_object(
            session, Attempt,
            pk={"id": d["attempt"].id},
            load_paths=["unit", "billings"],
        )
        assert attempt is not None
        assert attempt.unit is not None
        assert attempt.unit.full_name == "Экзаменационный центр Новосибирск"
        assert len(attempt.billings) == 1
        assert attempt.billings[0].invoice_number == "КТ-0001"

        # Step 2: load application with applicant
        application = await soh.get_object(
            session, Application,
            pk={"id": attempt.application_id},
            load_paths=["applicant"],
        )
        assert application is not None
        assert application.applicant is not None
        assert application.applicant.last_name == "Козлов"
        assert application.applicant.middle_name == "Андреевич"

        # Step 3: check billing has payment linked
        billing = attempt.billings[0]
        billing_full = await soh.get_object(
            session, Billing,
            pk={"id": billing.id},
            load_paths=["organization", "billing_payments"],
        )
        assert billing_full.organization is not None
        assert billing_full.organization.inn == "5003112233"
        assert len(billing_full.billing_payments) == 1


@pytest.mark.asyncio
async def test_endpoint_attempt_status_transition_with_billings(sa_seed_full):
    """
    Simulate PUT /attempts/{id}/status — real workflow:
      1. get_object(Attempt) with load_paths=["application", "unit", "billings"]
      2. Validate all billings are paid before moving to status 100
      3. If not — update billing to paid first, then update attempt status
    """
    d = sa_seed_full

    async with soh.auto_session() as session:
        attempt = await soh.get_object(
            session, Attempt,
            pk={"id": d["attempt"].id},
            load_paths=["application", "unit", "billings"],
        )
        assert attempt is not None
        assert attempt.application is not None
        assert attempt.unit.short_name == "ЭЦ-НСК"

        # Business rule: all billings must be paid before status=100
        unpaid = [b for b in attempt.billings if not b.is_paid]
        assert len(unpaid) == 1  # our seed has is_paid=False

        # Mark billing as paid
        for billing in unpaid:
            await soh.update_object(session, billing, {"is_paid": True})

        # Now transition attempt to status 100 ("Запись на экзамен")
        await soh.update_object(session, attempt, {"status_id": 100})

    # Verify everything committed
    result = await soh_sa.get_object(Attempt, pk={"id": d["attempt"].id})
    assert result.status_id == 100

    billing_result = await soh_sa.get_object(Billing, pk={"id": d["billing"].id})
    assert billing_result.is_paid is True


@pytest.mark.asyncio
async def test_endpoint_payment_matching(sa_seed_full):
    """
    Simulate payment matching endpoint:
      1. get_object(Payment) — incoming payment
      2. get_object(Applicant) via payment.applicant_id with load_paths
      3. get_objects(Application) for that applicant
      4. get_objects(Attempt) for the application with load_paths=["billings"]
      5. Find matching billing and link payment
    """
    d = sa_seed_full

    async with soh.auto_session() as session:
        # Step 1: get payment
        payment = await soh.get_object(
            session, Payment,
            pk={"id": d["payment"].id},
            load_paths=["applicant"],
        )
        assert payment is not None
        assert payment.applicant is not None
        assert payment.applicant.last_name == "Козлов"
        assert payment.credit == 7500

        # Step 2: find applications for this applicant
        applications = await soh.get_objects(
            session, Application,
            filters={"applicant_id": {soh.Operator.EQ: payment.applicant_id}},
        )
        assert len(applications) >= 1

        # Step 3: find active attempts with billings
        for app in applications:
            attempts = await soh.get_objects(
                session, Attempt,
                filters={
                    "application_id": {soh.Operator.EQ: app.id},
                    "is_active": {soh.Operator.EQ: True},
                },
                load_paths=["billings"],
            )
            for att in attempts:
                # Step 4: find unpaid billing matching payment amount
                for billing in att.billings:
                    if not billing.is_paid:
                        # Mark as paid
                        await soh.update_object(
                            session, billing, {"is_paid": True},
                        )

    # Verify billing is now paid
    result = await soh_sa.get_object(Billing, pk={"id": d["billing"].id})
    assert result.is_paid is True


@pytest.mark.asyncio
async def test_endpoint_applicant_profile_with_full_chain(sa_seed_full):
    """
    Simulate GET /applicants/{id}/profile — full chain traversal:
      1. get_object(Applicant) with load_paths=["applications", "payments"]
      2. For each application → get_objects(Attempt) with load_paths
      3. For each attempt → access unit and schedule via load_paths
      4. Aggregate counts via count_objects
    """
    d = sa_seed_full

    async with soh.auto_session() as session:
        # Step 1: load applicant with applications + payments
        applicant = await soh.get_object(
            session, Applicant,
            pk={"id": d["applicant"].id},
            load_paths=["applications", "payments"],
        )
        assert applicant is not None
        assert len(applicant.applications) == 1
        assert len(applicant.payments) == 1
        assert applicant.payments[0].credit == 7500

        # Step 2: for each application, load attempts with schedule+unit
        for app in applicant.applications:
            attempts = await soh.get_objects(
                session, Attempt,
                filters={"application_id": {soh.Operator.EQ: app.id}},
                load_paths=["schedule", "unit"],
            )
            assert len(attempts) >= 1
            for att in attempts:
                assert att.unit is not None
                assert att.unit.city == "Новосибирск"
                if att.schedule is not None:
                    assert att.schedule.is_nostroy is True

        # Step 3: aggregate — total attempts for this applicant
        total_attempts = await soh.count_objects(
            session, Attempt,
            filters={"application_id": {soh.Operator.EQ: applicant.applications[0].id}},
        )
        assert total_attempts == 1

        # Step 4: check billing exists
        has_billing = await soh.exists_object(
            session, Billing,
            filters={"attempt_id": {soh.Operator.EQ: d["attempt"].id}},
        )
        assert has_billing is True


@pytest.mark.asyncio
async def test_endpoint_create_billing_for_attempt(sa_seed_full, sa_factory):
    """
    Simulate POST /billings — create billing after validating attempt chain:
      1. get_object(Attempt) with load_paths=["application", "unit"]
      2. get_object(Applicant) via application
      3. get_object(Organization) for the unit
      4. count existing billings to generate invoice number
      5. add_object(Billing)
    """
    d = sa_seed_full

    async with soh.auto_session() as session:
        # Step 1: load attempt with application + unit
        attempt = await soh.get_object(
            session, Attempt,
            pk={"id": d["attempt"].id},
            load_paths=["application", "unit"],
        )
        assert attempt.application is not None
        assert attempt.unit is not None

        # Step 2: get applicant
        applicant = await soh.get_object(
            session, Applicant,
            pk={"id": attempt.application.applicant_id},
        )
        assert applicant.snils == "555-666-777 88"

        # Step 3: get organization for invoicing
        org = await soh.get_object(
            session, Organization,
            pk={"id": attempt.unit.organization_id},
            load_paths=["bank_accounts"],
        )
        assert org is not None
        assert len(org.bank_accounts) >= 1

        # Step 4: count existing billings for this attempt
        existing = await soh.count_objects(
            session, Billing,
            filters={"attempt_id": {soh.Operator.EQ: attempt.id}},
        )
        next_number = f"КТ-{existing + 1:04d}"

        # Step 5: load bank account with bank for BIK
        bank_acc = await soh.get_object(
            session, BankAccount,
            pk={"id": org.bank_accounts[0].id},
            load_paths=["bank"],
        )

        # Step 6: create new billing (type=2 = Гарантия)
        new_billing = Billing(
            attempt_id=attempt.id, billing_type_id=2,
            bank_acc_id=bank_acc.id,
            organization_id=org.id,
            is_physical=True, is_paid=False,
            invoice_reason="Гарантия пересдачи",
            invoice_date=datetime(2026, 3, 1).date(),
            agreement_create_date=datetime(2026, 3, 1).date(),
            agreement_expire_date=datetime(2026, 12, 31).date(),
            address=attempt.unit.address,
            invoice_number=next_number,
            agreement_number=f"КТ-Д-{existing + 1:04d}",
            organization_short_name=org.short_name,
            organization_inn=org.inn,
            bank_bik=bank_acc.bank.bik if bank_acc.bank else None,
            bank_name=bank_acc.bank.name if bank_acc.bank else None,
            bank_rs=bank_acc.bank_rs,
        )
        await soh.add_object(session, new_billing)
        assert new_billing.id is not None

    # Verify committed
    async with sa_factory() as verify:
        row = await verify.get(Billing, new_billing.id)
        assert row is not None
        assert row.invoice_number == "КТ-0002"
        assert row.billing_type_id == 2
        assert row.attempt_id == d["attempt"].id


@pytest.mark.asyncio
async def test_endpoint_di_session_generate_docs_pattern(sa_seed_full, sa_factory):
    """
    Same as generate_docs_1c but through create_session_dependency (FastAPI DI).
    Verifies the full DI lifecycle with production-like chained reads.
    """
    get_session = soh.create_session_dependency(sa_factory)
    d = sa_seed_full

    gen = get_session()
    session = await gen.__anext__()

    # 1. Load attempt with eager paths
    attempt = await soh.get_object(
        session, Attempt,
        pk={"id": d["attempt"].id},
        load_paths=["unit", "billings"],
    )
    assert attempt.unit.full_name == "Экзаменационный центр Новосибирск"
    assert len(attempt.billings) >= 1
    has_nds = any(b.nds_id for b in attempt.billings)

    # 2. Load application → applicant
    application = await soh.get_object(
        session, Application,
        pk={"id": attempt.application_id},
        load_paths=["applicant"],
    )
    fio = (
        f"{application.applicant.last_name} "
        f"{application.applicant.first_name} "
        f"{application.applicant.middle_name}"
    )
    assert fio == "Козлов Дмитрий Андреевич"

    # 3. Get billing documents count (simulating document query)
    billing_count = await soh.count_objects(
        session, Billing,
        filters={"attempt_id": {soh.Operator.EQ: attempt.id}},
    )
    assert billing_count == 1

    # 4. Update attempt status to mark docs generated
    await soh.update_object(session, attempt, {"status_id": 60})

    # Exit generator → commit
    with pytest.raises(StopAsyncIteration):
        await gen.__anext__()

    # Verify
    async with sa_factory() as verify:
        row = await verify.get(Attempt, d["attempt"].id)
        assert row.status_id == 60
