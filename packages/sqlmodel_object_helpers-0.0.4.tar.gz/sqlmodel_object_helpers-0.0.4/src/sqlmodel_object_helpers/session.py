import logging
import time
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from .constants import settings

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator

    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

logger = logging.getLogger("sqlmodel_object_helpers")


def configure(factory: async_sessionmaker) -> None:
    """
    Register an ``async_sessionmaker`` for standalone mode.

    Call once at application startup::

        import sqlmodel_object_helpers as soh

        soh.configure(async_session_factory)

    After this, ``sqlmodel_object_helpers.standalone`` functions will
    create and commit sessions automatically.
    """
    # async_sessionmaker stores kwargs in .kw dict
    expire_on_commit = getattr(factory, "kw", {}).get("expire_on_commit", True)
    if expire_on_commit:
        logger.warning(
            "expire_on_commit=True (default) — standalone functions will return "
            "expired objects after session close. "
            "Set expire_on_commit=False in async_sessionmaker()."
        )

    settings.session_factory = factory
    logger.info("Session factory configured: %s", type(factory).__name__)


@asynccontextmanager
async def auto_session() -> AsyncGenerator[AsyncSession]:
    """
    Async context manager that creates a session, commits on success,
    rolls back on error.

    Used internally by ``standalone`` module. Can also be used directly::

        async with soh.auto_session() as session:
            await soh.add_object(session, instance)
            await soh.update_object(session, other, data)
            # commit happens automatically on exit

    Raises:
        RuntimeError: If ``soh.configure(factory)`` has not been called.

    """
    if settings.session_factory is None:
        msg = (
            "Session factory not configured. "
            "Call soh.configure(async_session_factory) at application startup."
        )
        raise RuntimeError(msg)

    start = time.perf_counter()
    async with settings.session_factory() as session:
        sid = id(session)
        logger.debug("auto_session[%x] opened", sid)
        try:
            yield session
        except Exception as exc:
            elapsed = time.perf_counter() - start
            logger.warning(
                "auto_session[%x] rollback (%.3fs) — %s: %s",
                sid, elapsed, type(exc).__name__, exc,
            )
            try:
                await session.rollback()
            except Exception:
                logger.exception("auto_session[%x] rollback itself failed", sid)
            raise
        else:
            try:
                await session.commit()
                elapsed = time.perf_counter() - start
                logger.debug("auto_session[%x] committed (%.3fs)", sid, elapsed)
            except Exception as exc:
                elapsed = time.perf_counter() - start
                logger.warning(
                    "auto_session[%x] commit failed, rollback (%.3fs) — %s: %s",
                    sid, elapsed, type(exc).__name__, exc,
                )
                try:
                    await session.rollback()
                except Exception:
                    logger.exception("auto_session[%x] rollback itself failed", sid)
                raise


def create_session_dependency(factory: async_sessionmaker):
    """
    Create an async session generator for FastAPI Depends.

    Contract: the library calls flush() on mutations,
    this generator calls commit() on success, rollback() on error.

    Usage::

        get_session = create_session_dependency(async_session_factory)
        DbSession = Annotated[AsyncSession, Depends(get_session)]

        @router.get("/")
        async def endpoint(session: DbSession):
            ...
    """

    async def get_session() -> AsyncGenerator[AsyncSession]:
        start = time.perf_counter()
        async with factory() as session:
            sid = id(session)
            logger.debug("di_session[%x] opened", sid)
            try:
                yield session
            except Exception as exc:
                elapsed = time.perf_counter() - start
                logger.warning(
                    "di_session[%x] rollback (%.3fs) — %s: %s",
                    sid, elapsed, type(exc).__name__, exc,
                )
                try:
                    await session.rollback()
                except Exception:
                    logger.exception("di_session[%x] rollback itself failed", sid)
                raise
            else:
                try:
                    await session.commit()
                    elapsed = time.perf_counter() - start
                    logger.debug("di_session[%x] committed (%.3fs)", sid, elapsed)
                except Exception as exc:
                    elapsed = time.perf_counter() - start
                    logger.warning(
                        "di_session[%x] commit failed, rollback (%.3fs) — %s: %s",
                        sid, elapsed, type(exc).__name__, exc,
                    )
                    try:
                        await session.rollback()
                    except Exception:
                        logger.exception("di_session[%x] rollback itself failed", sid)
                    raise

    return get_session
