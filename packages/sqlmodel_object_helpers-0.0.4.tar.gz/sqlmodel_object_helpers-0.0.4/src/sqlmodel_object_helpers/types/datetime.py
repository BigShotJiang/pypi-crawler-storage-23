"""Timezone-aware datetime types for consistent UTC handling."""

from datetime import datetime, timezone
from typing import Annotated

from pydantic import AfterValidator


def _ensure_utc(v: datetime) -> datetime:
    """Validate that datetime is timezone-aware and convert to UTC.

    - Naive datetime (no tzinfo) is **rejected** with ``ValueError``.
    - Aware datetime is converted to UTC via ``.astimezone(UTC)``.
    """
    if v.tzinfo is None:
        msg = (
            "Naive datetime is not allowed — "
            "pass a timezone-aware datetime (e.g. with tzinfo=timezone.utc)"
        )
        raise ValueError(msg)
    return v.astimezone(timezone.utc)


UTCDatetime = Annotated[datetime, AfterValidator(_ensure_utc)]
"""Datetime type that guarantees ``tzinfo=UTC`` after Pydantic validation.

Usage::

    from sqlmodel_object_helpers import UTCDatetime

    class MyFilter(BaseModel):
        created_at: UTCDatetime | None = None

    class MyModel(SQLModel, table=True):
        created_at: UTCDatetime | None = Field(
            sa_column=Column(DateTime(timezone=True), ...),
        )
"""
