"""
antaris-contracts — Versioned state schemas, failure semantics, and debug CLI
for the Antaris Analytics Suite.

Provides the canonical data contracts shared across antaris-memory, antaris-guard,
antaris-context, antaris-router, and antaris-pipeline.

Usage:
    from antaris_contracts import TelemetryEvent, GuardDecision, MemoryEntry
    from antaris_contracts.migration import SchemaVersion, migrate
"""

__version__ = "1.1.0"

from antaris_contracts.version import SCHEMA_VERSION

from antaris_contracts.schemas.memory import (
    MemoryEntry,
    SearchResult,
    MemoryShard,
    MemoryIndex,
)
from antaris_contracts.schemas.router import (
    ClassificationResult,
    RouteDecision,
    RouterState,
)
from antaris_contracts.schemas.guard import (
    PatternMatch,
    GuardDecision,
    GuardPolicyRule,
    GuardPolicy,
    AuditRecord,
)
from antaris_contracts.schemas.context import (
    ContextItem,
    ContextSection,
    ContextPacket,
)
from antaris_contracts.schemas.telemetry import (
    PerformanceMetrics,
    TelemetryEvent,
    MODULE_MEMORY,
    MODULE_ROUTER,
    MODULE_GUARD,
    MODULE_CONTEXT,
    MODULE_PIPELINE,
    BASIS_CLASSIFIER,
    BASIS_QUALITY_TRACKER,
    BASIS_GUARD,
    BASIS_CONTEXT_BUDGET,
    BASIS_KEYWORD,
    BASIS_COMPOSITE,
    BASIS_RULE,
    BASIS_FALLBACK,
)
from antaris_contracts.migration import SchemaVersion, migrate

__all__ = [
    # version
    "SCHEMA_VERSION",
    # memory schemas
    "MemoryEntry",
    "SearchResult",
    "MemoryShard",
    "MemoryIndex",
    # router schemas
    "ClassificationResult",
    "RouteDecision",
    "RouterState",
    # guard schemas
    "PatternMatch",
    "GuardDecision",
    "GuardPolicyRule",
    "GuardPolicy",
    "AuditRecord",
    # context schemas
    "ContextItem",
    "ContextSection",
    "ContextPacket",
    # telemetry schemas
    "PerformanceMetrics",
    "TelemetryEvent",
    # telemetry constants
    "MODULE_MEMORY",
    "MODULE_ROUTER",
    "MODULE_GUARD",
    "MODULE_CONTEXT",
    "MODULE_PIPELINE",
    "BASIS_CLASSIFIER",
    "BASIS_QUALITY_TRACKER",
    "BASIS_GUARD",
    "BASIS_CONTEXT_BUDGET",
    "BASIS_KEYWORD",
    "BASIS_COMPOSITE",
    "BASIS_RULE",
    "BASIS_FALLBACK",
    # migration
    "SchemaVersion",
    "migrate",
]
