"""
Schema migration tooling for antaris-contracts.

Provides SchemaVersion enum and migrate() function for upgrading
persisted data across schema versions.

Design decisions:
- Migration functions are pure (dict-in, dict-out) — no I/O.
- Migrations are chained: to go from 2.0.0 → 2.2.0, we apply
  2.0.0→2.1.0 then 2.1.0→2.2.0 in sequence.
- Unknown schema_version raises MigrationError rather than silently
  guessing — predictability over convenience.
- Downgrades are not supported; raise MigrationError.
"""

from __future__ import annotations

import copy
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple


class SchemaVersion(str, Enum):
    """Known schema versions for antaris-contracts data."""
    V2_0_0 = "2.0.0"
    V2_1_0 = "2.1.0"
    V2_1_1 = "2.1.1"
    V2_2_0 = "2.2.0"

    @classmethod
    def ordered(cls) -> List["SchemaVersion"]:
        """Return all versions in ascending order."""
        return [cls.V2_0_0, cls.V2_1_0, cls.V2_1_1, cls.V2_2_0]

    def __lt__(self, other: "SchemaVersion") -> bool:
        order = self.ordered()
        return order.index(self) < order.index(other)

    def __le__(self, other: "SchemaVersion") -> bool:
        return self == other or self < other


class MigrationError(Exception):
    """Raised when a migration cannot be performed."""
    pass


# Migration functions: Dict[Tuple[from, to], Callable[[dict], dict]]
# Each function takes the data dict and returns a migrated copy.
_MIGRATIONS: Dict[Tuple[str, str], Callable[[Dict[str, Any]], Dict[str, Any]]] = {}


def _register(from_v: str, to_v: str) -> Callable:
    """Decorator to register a migration function."""
    def decorator(fn: Callable[[Dict[str, Any]], Dict[str, Any]]) -> Callable:
        _MIGRATIONS[(from_v, to_v)] = fn
        return fn
    return decorator


# ── 2.0.0 → 2.1.0 ──────────────────────────────────────────────────────────

@_register("2.0.0", "2.1.0")
def _migrate_200_210(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    2.0.0 → 2.1.0 changes:
    - MemoryEntry: add `memory_type` field (default "episodic")
    - MemoryEntry: add `type_metadata` field (default {})
    - TelemetryEvent: add `correlations` and `triggers` fields
    """
    d = copy.deepcopy(data)
    d.setdefault("memory_type", "episodic")
    d.setdefault("type_metadata", {})
    d.setdefault("correlations", [])
    d.setdefault("triggers", [])
    d["schema_version"] = "2.1.0"
    return d


# ── 2.1.0 → 2.1.1 ──────────────────────────────────────────────────────────

@_register("2.1.0", "2.1.1")
def _migrate_210_211(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    2.1.0 → 2.1.1 changes:
    - MemoryShard: safety cap raised from 10k to 25k (metadata only — no field change)
    - TelemetryEvent: add `trace_id` field (default None)
    - Bug fix marker: strip timestamp-prefixed contamination metadata
    """
    d = copy.deepcopy(data)
    d.setdefault("trace_id", None)
    # Remove contamination artifact if present
    d.pop("_heartbeat_contaminated", None)
    d["schema_version"] = "2.1.1"
    return d


# ── 2.1.1 → 2.2.0 ──────────────────────────────────────────────────────────

@_register("2.1.1", "2.2.0")
def _migrate_211_220(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    2.1.1 → 2.2.0 changes:
    - RouteDecision: add `escalated`, `original_confidence`, `escalation_reason` fields
    - RouteDecision: add `sla_compliant`, `sla_breaches`, `sla_adjustments` fields
    - RouteDecision: add `ab_variant`, `explanation`, `supports_streaming` fields
    - GuardDecision: add `pattern_version`, `audit_id` fields
    - TelemetryEvent: add `user_id`, `conversation_id`, `agent_id` fields
    - ContextPacket: add `strategy` field (default "hybrid")
    """
    d = copy.deepcopy(data)
    # RouteDecision fields
    d.setdefault("escalated", False)
    d.setdefault("original_confidence", None)
    d.setdefault("escalation_reason", None)
    d.setdefault("sla_compliant", True)
    d.setdefault("sla_breaches", [])
    d.setdefault("sla_adjustments", [])
    d.setdefault("ab_variant", None)
    d.setdefault("explanation", "")
    d.setdefault("supports_streaming", False)
    # GuardDecision fields
    d.setdefault("pattern_version", "")
    d.setdefault("audit_id", "")
    # TelemetryEvent fields
    d.setdefault("user_id", None)
    d.setdefault("conversation_id", None)
    d.setdefault("agent_id", None)
    # ContextPacket fields
    d.setdefault("strategy", "hybrid")
    d["schema_version"] = "2.2.0"
    return d


# Also handle the 2.1.0 → 2.2.0 shortcut (chain through 2.1.1)
@_register("2.1.0", "2.2.0")
def _migrate_210_220(data: Dict[str, Any]) -> Dict[str, Any]:
    intermediate = _migrate_210_211(data)
    return _migrate_211_220(intermediate)


# And 2.0.0 → 2.2.0 (chain all the way through)
@_register("2.0.0", "2.2.0")
def _migrate_200_220(data: Dict[str, Any]) -> Dict[str, Any]:
    intermediate = _migrate_200_210(data)
    return _migrate_210_220(intermediate)


# ── Public API ───────────────────────────────────────────────────────────────

def migrate(
    data: Dict[str, Any],
    from_version: Optional[str] = None,
    to_version: str = "2.2.0",
) -> Dict[str, Any]:
    """
    Migrate a data dict from one schema version to another.

    Args:
        data: The data dict to migrate (must contain schema_version if from_version
              is not specified).
        from_version: Source schema version string. If None, reads from
                      data["schema_version"].
        to_version: Target schema version string. Defaults to current ("2.2.0").

    Returns:
        A new dict (deep copy) migrated to to_version.

    Raises:
        MigrationError: If the migration path is unknown, or if downgrade is
                        attempted.
    """
    source = from_version or data.get("schema_version")
    if not source:
        raise MigrationError(
            "Cannot determine source schema version: provide from_version or "
            "ensure data contains 'schema_version' key."
        )

    if source == to_version:
        return copy.deepcopy(data)

    # Validate both versions are known
    known = {v.value for v in SchemaVersion}
    if source not in known:
        raise MigrationError(
            f"Unknown source schema version: {source!r}. "
            f"Known versions: {sorted(known)}"
        )
    if to_version not in known:
        raise MigrationError(
            f"Unknown target schema version: {to_version!r}. "
            f"Known versions: {sorted(known)}"
        )

    # Check for downgrade
    src_v = SchemaVersion(source)
    tgt_v = SchemaVersion(to_version)
    if tgt_v < src_v:
        raise MigrationError(
            f"Downgrade not supported: {source} → {to_version}."
        )

    # Try direct migration first
    if (source, to_version) in _MIGRATIONS:
        return _MIGRATIONS[(source, to_version)](data)

    # Chain migrations through ordered versions
    versions = SchemaVersion.ordered()
    src_idx = versions.index(src_v)
    tgt_idx = versions.index(tgt_v)

    result = copy.deepcopy(data)
    for i in range(src_idx, tgt_idx):
        step_from = versions[i].value
        step_to = versions[i + 1].value
        if (step_from, step_to) not in _MIGRATIONS:
            raise MigrationError(
                f"No migration registered for {step_from} → {step_to}."
            )
        result = _MIGRATIONS[(step_from, step_to)](result)

    return result


def get_migration_path(from_version: str, to_version: str) -> List[Tuple[str, str]]:
    """
    Return the list of (from, to) migration steps that will be applied.
    Useful for dry-run inspection.

    Raises MigrationError if the path cannot be resolved.
    """
    if from_version == to_version:
        return []

    known = {v.value for v in SchemaVersion}
    if from_version not in known:
        raise MigrationError(f"Unknown source version: {from_version!r}")
    if to_version not in known:
        raise MigrationError(f"Unknown target version: {to_version!r}")

    if (from_version, to_version) in _MIGRATIONS:
        return [(from_version, to_version)]

    versions = SchemaVersion.ordered()
    src_idx = versions.index(SchemaVersion(from_version))
    tgt_idx = versions.index(SchemaVersion(to_version))

    if tgt_idx < src_idx:
        raise MigrationError(f"Downgrade not supported: {from_version} → {to_version}")

    steps = []
    for i in range(src_idx, tgt_idx):
        step = (versions[i].value, versions[i + 1].value)
        if step not in _MIGRATIONS:
            raise MigrationError(f"No migration for step {step[0]} → {step[1]}")
        steps.append(step)
    return steps
