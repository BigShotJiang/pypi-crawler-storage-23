"""
Context state contracts for antaris-context.

Failure behavior:
- ContextPacket: if token budget is exceeded during build, the lowest-priority
  sections are dropped until the packet fits; the packet is never silently
  truncated mid-entry.
- ContextSection: if compression raises, the original (uncompressed) content
  is used as fallback; compression failure is non-fatal.
- If total_budget is 0 or negative, a ValueError is raised at construction time
  (not silently coerced to a sentinel).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

SCHEMA_VERSION = "2.2.0"


@dataclass
class ContextItem:
    """
    A single item within a ContextSection.

    Items are ordered by priority (descending) within a section.
    Zero-token items are valid (e.g., empty system message placeholders).
    """
    content: str = ""
    tokens: int = 0
    priority: float = 1.0
    added_at: str = ""
    item_type: str = "text"
    metadata: Dict[str, Any] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ContextItem":
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(**filtered)


@dataclass
class ContextSection:
    """
    A named, budgeted section within a context window.

    Failure semantics:
    - If `used` exceeds `budget`, an overflow warning is recorded in
      `overflow_warnings` but the section is NOT hard-truncated during read.
    - On compression failure: use uncompressed content, log warning.
    - Sections with priority <= 0 are dropped first when the window is full.
    """
    name: str = ""
    budget: int = 0
    used: int = 0
    compression_level: str = "light"
    items: List[ContextItem] = field(default_factory=list)
    overflow_warnings: List[str] = field(default_factory=list)
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ContextSection":
        items_raw = data.pop("items", [])
        items = [ContextItem.from_dict(i) for i in items_raw]
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(items=items, **filtered)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, s: str) -> "ContextSection":
        return cls.from_dict(json.loads(s))


@dataclass
class ContextPacket:
    """
    A fully-built context packet ready for delivery to a sub-agent or LLM.

    Produced by antaris-context and consumed by the pipeline and sub-agents.

    Failure semantics:
    - If total_budget is exceeded: drop lowest-priority sections first.
    - If memory retrieval fails: include empty memories list, set
      memory_retrieval_failed=True in metadata.
    - If pitfall extraction fails: omit pitfalls silently (non-critical).
    - The packet is always returned; an empty packet is a valid (safe) response.
    """
    task: str = ""
    memories: List[Dict[str, Any]] = field(default_factory=list)
    pitfalls: List[str] = field(default_factory=list)
    environment: Dict[str, str] = field(default_factory=dict)
    instructions: List[str] = field(default_factory=list)
    sections: List[ContextSection] = field(default_factory=list)
    total_budget: int = 4096
    total_used: int = 0
    strategy: str = "hybrid"
    metadata: Dict[str, Any] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ContextPacket":
        sections_raw = data.pop("sections", [])
        sections = [ContextSection.from_dict(s) for s in sections_raw]
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(sections=sections, **filtered)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, s: str) -> "ContextPacket":
        return cls.from_dict(json.loads(s))
