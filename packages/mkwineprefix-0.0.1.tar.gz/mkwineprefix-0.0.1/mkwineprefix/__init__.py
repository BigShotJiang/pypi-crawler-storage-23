"""Create a Wine prefix with custom settings."""

from __future__ import annotations

from .prefix import create_wine_prefix

__all__ = ('create_wine_prefix',)
__version__ = '0.0.1'
