<div align="center">

<h1>Quantum Pixel</h1>

<img src="https://raw.githubusercontent.com/Linos1391/quantum-pixel/bde7747758dd6f9a5fbd3fb06ce9a39528d348c6/quantum_pixel/static/favicon.svg" width="60%">

**When everything is possibility.**

[![][latest-release-shield]][latest-release-url]
[![][latest-commit-shield]][latest-commit-url]
[![][pypi-shield]][pypi-url]
[![][python-shield]][python-url]

[latest-release-shield]: https://badgen.net/github/release/Linos1391/quantum-pixel/development?icon=github
[latest-release-url]: https://github.com/Linos1391/quantum-pixel/releases/latest
[latest-commit-shield]: https://badgen.net/github/last-commit/Linos1391/quantum-pixel/master?icon=github
[latest-commit-url]: https://github.com/Linos1391/quantum-pixel/commits/master
[pypi-shield]: https://img.shields.io/badge/pypi-quantum--pixel-blue
[pypi-url]: https://pypi.org/project/quantum-pixel/
[python-shield]: https://img.shields.io/badge/python-3.14+-yellow
[python-url]: https://www.python.org/downloads/

<img alt="intro image" width="75%" src="https://github.com/Linos1391/quantum-pixel/blob/master/assets/intro.png?raw=true">
</div>
<br>

>"When I think about it, maybe quantum mechanics was made to prevent AI. Like being both wave and particle, we as players perceive the environment normally, and computers got strokes while analyzing. Thats why we forgot the precedent memory to prevent AI screenshot reality."
>
> &mdash; <cite>**Me** in Dec 11th 2025 for absolutely no reasons.</cite>

<br>

- [1. Introduction](#1-introduction)
  - [1.1. Local system (RECOMMEND)](#11-local-system-recommend)
  - [1.2. Web service (NOT RECOMMEND)](#12-web-service-not-recommend)
- [2. Can I host from Github?](#2-can-i-host-from-github)
- [3. License](#3-license)
- [4. Disclaimer](#4-disclaimer)


<br>

# 1. Introduction

I made this in response of AI slop. Those so-called AI artists had gone too far that annoy me... I am not against the development of AI, but the disrespects towards ARTS and ARTISTS.

<!-- Change from "assets/mermaid.png" to "https://github.com/Linos1391/quantum-pixel/blob/master/assets/mermaid.png?raw=true" in `quantum_pixel/README_PYPI.md` -->
![rendered mermaid](https://github.com/Linos1391/quantum-pixel/blob/master/assets/mermaid.png?raw=true)
<details>
  <summary>Mermaid source</summary>

```mermaid
flowchart LR
  Material[<img src="https://github.com/Linos1391/quantum-pixel/blob/dev/assets/material.png?raw=true" width="50" height="100"/><br><label>material.png</label>]
  Preview[<img src="https://github.com/Linos1391/quantum-pixel/blob/dev/assets/preview.png?raw=true" width="50" height="100"/><br><label>preview.png</label>]
  Encoded[<img src="https://github.com/Linos1391/quantum-pixel/blob/dev/assets/encoded.png?raw=true" width="50" height="100"/><br><label>encoded.png</label>]
  Grok[<img src="https://github.com/Linos1391/quantum-pixel/blob/dev/assets/grok.png?raw=true" width="50" height="100"/><br><label>grok.png</label>]

  Material -->|Built-in Generate Preview| Preview
  Material -->|Embed Within Steganography| Encoded
  Preview -->|Encode Steganography| Encoded
  Encoded -->|Decode Steganography| Material
  Encoded -->|Edit by Grok| Grok
```

</details>

<br>

**Notice:** it is still in development and not guaranteed protected from img2img. I tried on Grok some details are detected, most are NOT :D.

## 1.1. Local system (RECOMMEND)

| UV                                 | Python                      |
| ---------------------------------- | --------------------------- |
| `uv run pip install quantum-pixel` | `pip install quantum-pixel` |
| `uv run quantum_pixel`             | `quantum_pixel`             |

## 1.2. Web service (NOT RECOMMEND)

Really slow and often exceed RAM limit.
- [quantum-pixel.onrender.com/](https://quantum-pixel.onrender.com/)

<br>

# 2. Can I host from [Github](https://github.com/Linos1391/quantum-pixel)?

- For private use or sharing with friends? Absolutely yes. I am using the free version of Render right now and totally recommend to try. Import `render.yml` as blueprint.

- For your website? You may embed this project as it is and let it be entirely free.

<br>

# 3. License

[GNU GPLv3](LICENSE)

<br>

# 4. Disclaimer

Remember, this will NOT 100% prevent AI from analyzing; in fact, the process of Steganography is open-source. I am still researching for better algorithms and would love to hear from YOU!
