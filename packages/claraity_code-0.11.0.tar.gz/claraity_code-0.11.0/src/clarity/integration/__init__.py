"""
ClarAIty Integration Module

Integrates ClarAIty with the AI Coding Agent.
"""

from .agent_hook import ClarityAgentHook, should_use_clarity

__all__ = ["ClarityAgentHook", "should_use_clarity"]
