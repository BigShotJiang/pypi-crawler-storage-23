"""
ClarAIty Code Analyzer

Analyzes existing codebases to extract architectural components,
relationships, and design decisions for documentation in ClarAIty.
"""

from .code_analyzer import CodeAnalyzer
from .design_decision_extractor import DesignDecisionExtractor

__all__ = ['CodeAnalyzer', 'DesignDecisionExtractor']
