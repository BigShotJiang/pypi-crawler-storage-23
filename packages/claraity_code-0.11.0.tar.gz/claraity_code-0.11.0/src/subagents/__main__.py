"""Allow running subagent runner via: python -m src.subagents"""
from src.subagents.runner import main

main()
