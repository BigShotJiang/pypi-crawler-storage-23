"""Tests for demo.py script.

Covers:
- Agent initialization
- Codebase indexing
- Task execution (mocked)
- Statistics retrieval
- Session saving

These tests mock CodingAgent to avoid real LLM/network/file indexing work.
"""

import importlib
from unittest.mock import Mock

import pytest


@pytest.fixture
def demo_module():
    """Import demo module fresh per test (allows patching module globals)."""
    import demo

    return importlib.reload(demo)


@pytest.fixture
def mock_agent():
    """Mock CodingAgent instance used by the demo."""
    agent = Mock(name="CodingAgentInstance")

    # Step 2: index_codebase
    agent.index_codebase = Mock(return_value={"total_files": 3, "total_chunks": 12})

    # Step 3: execute_task twice
    agent.execute_task = Mock(side_effect=[
        Mock(content="Memory system explanation"),
        Mock(content="Helper function implementation"),
    ])

    # Step 4: statistics
    agent.get_statistics = Mock(return_value={
        "model": "qwen3-coder:30b",
        "context_window": 131072,
        "indexed_chunks": 12,
        "memory": {
            "working_memory": {"tokens": 100},
            "episodic_memory": {"total_turns": 2},
        },
    })

    # Step 5: save_session
    agent.save_session = Mock(return_value="/tmp/demo_session.json")

    return agent


def _run_demo_with_mocked_agent(demo_module, mocker, mock_agent):
    """Helper to run demo.main with CodingAgent patched."""
    mock_cls = mocker.patch.object(demo_module, "CodingAgent", autospec=True)
    mock_cls.return_value = mock_agent

    demo_module.main()

    return mock_cls


class TestDemo:
    def test_agent_initialization(self, demo_module, mocker, mock_agent):
        mock_cls = _run_demo_with_mocked_agent(demo_module, mocker, mock_agent)

        mock_cls.assert_called_once_with(
            model_name="qwen3-coder:30b",
            backend="ollama",
            context_window=131072,
        )

    def test_codebase_indexing_functionality(self, demo_module, mocker, mock_agent):
        _run_demo_with_mocked_agent(demo_module, mocker, mock_agent)

        mock_agent.index_codebase.assert_called_once_with(directory="./src")

    def test_task_execution_mocked_llm_responses(self, demo_module, mocker, mock_agent):
        _run_demo_with_mocked_agent(demo_module, mocker, mock_agent)

        assert mock_agent.execute_task.call_count == 2
        mock_agent.execute_task.assert_any_call(
            task_description="Explain how the hierarchical memory system works",
            task_type="explain",
            use_rag=True,
            stream=False,
        )
        mock_agent.execute_task.assert_any_call(
            task_description="Create a helper function to format token usage statistics",
            task_type="implement",
            use_rag=True,
            stream=False,
        )

    def test_statistics_retrieval(self, demo_module, mocker, mock_agent):
        _run_demo_with_mocked_agent(demo_module, mocker, mock_agent)

        mock_agent.get_statistics.assert_called_once_with()

    def test_session_saving(self, demo_module, mocker, mock_agent):
        _run_demo_with_mocked_agent(demo_module, mocker, mock_agent)

        mock_agent.save_session.assert_called_once_with("demo_session")
