PRAGMA journal_mode=DELETE;
PRAGMA synchronous=NORMAL;
PRAGMA case_sensitive_like=ON;
PRAGMA page_size=4096;

PRAGMA blobs.journal_mode=DELETE;
PRAGMA blobs.synchronous=NORMAL;
PRAGMA blobs.page_size=16384;