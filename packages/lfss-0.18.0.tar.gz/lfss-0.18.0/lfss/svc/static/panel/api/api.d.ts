export interface Config {
    endpoint: string;
    token: string;
    cachingStrategy?: 'default' | 'no-store' | 'no-cache' | 'force-cache' | 'only-if-cached';
}
export interface UserRecord {
    id: number;
    username: string;
    credential: string;
    is_admin: boolean;
    create_time: string;
    last_active: string;
    max_storage: number;
    permission: number;
}
export interface UserExpireInfo {
    user_id: number;
    username: string;
    expire_seconds: number | null;
}
export interface UserPasswordUpdateInfo {
    username: string;
    token: string;
}
export interface UserStorageInfo {
    quota: number;
    used: number;
}
export interface FileRecord {
    url: string;
    owner_id: number;
    file_id: string;
    file_size: number;
    create_time: string;
    access_time: string;
    permission: number;
    external: number;
    mime_type: string;
}
export interface DirectoryRecord {
    url: string;
    size: number;
    create_time: string;
    update_time: string;
    access_time: string;
    n_files: number;
}
export interface PathListResponse {
    dirs: DirectoryRecord[];
    files: FileRecord[];
}
export interface HttpTraffic {
    code_100_count: number;
    code_200_count: number;
    code_300_count: number;
    code_400_count: number;
    code_500_count: number;
    total_count: number;
    bytes_in: number;
    bytes_out: number;
    response_time_sum: number;
}
export type FileSortKey = "" | "url" | "file_size" | "create_time" | "access_time" | "mime_type";
export type DirectorySortKey = "" | "dirname";
export declare const permMap: Record<number, string>;
export declare const accessLevelMap: Record<number, string>;
export declare class Fetcher {
    config: Config;
    constructor(config: Config);
    _buildUrl(path: string, params?: Record<string, any>): string;
    request(method: string, path: string, { params, headers, body }?: {
        params?: Record<string, any>;
        headers?: Record<string, string>;
        body?: BodyInit | null;
    }): Promise<Response>;
    get(path: string, options?: {
        params?: Record<string, any>;
        headers?: Record<string, string>;
    }): Promise<Response>;
    head(path: string, options?: {
        params?: Record<string, any>;
        headers?: Record<string, string>;
    }): Promise<Response>;
    post(path: string, body: BodyInit | null, options?: {
        params?: Record<string, any>;
        headers?: Record<string, string>;
    }): Promise<Response>;
    put(path: string, body: BodyInit | null, options?: {
        params?: Record<string, any>;
        headers?: Record<string, string>;
    }): Promise<Response>;
    delete(path: string, options?: {
        params?: Record<string, any>;
        headers?: Record<string, string>;
    }): Promise<Response>;
}
export default class Connector {
    fetcher: Fetcher;
    constructor();
    get config(): Config;
    set config(config: Config);
    version(): Promise<string>;
    exists(path: string): Promise<boolean>;
    getText(path: string): Promise<string>;
    putText(path: string, text: string, { conflict, type }?: {
        conflict?: 'abort' | 'overwrite' | 'skip';
        type?: string;
    }): Promise<string>;
    put(path: string, file: Blob, { conflict, permission }?: {
        conflict?: 'abort' | 'overwrite' | 'skip';
        permission?: number;
    }): Promise<string>;
    post(path: string, file: File | Blob, { conflict, permission }?: {
        conflict?: 'abort' | 'overwrite' | 'skip';
        permission?: number;
    }): Promise<string>;
    putJson(path: string, data: any, { conflict, permission }?: {
        conflict?: 'abort' | 'overwrite' | 'skip';
        permission?: number;
    }): Promise<string>;
    getJson(path: string): Promise<any>;
    getMultipleText(paths: string[], { skipContent }?: {
        skipContent?: boolean;
    }): Promise<Record<string, string | null>>;
    delete(path: string): Promise<void>;
    getMetadata(path: string): Promise<FileRecord | DirectoryRecord | null>;
    _sanitizeDirPath(path: string): string;
    countFiles(path: string, { flat }?: {
        flat?: boolean;
    }): Promise<number>;
    listFiles(path: string, { offset, limit, orderBy, orderDesc, flat }?: {
        offset?: number;
        limit?: number;
        orderBy?: FileSortKey;
        orderDesc?: boolean;
        flat?: boolean;
    }): Promise<FileRecord[]>;
    countDirs(path: string): Promise<number>;
    listDirs(path: string, { offset, limit, orderBy, orderDesc, skim }?: {
        offset?: number;
        limit?: number;
        orderBy?: DirectorySortKey;
        orderDesc?: boolean;
        skim?: boolean;
    }): Promise<DirectoryRecord[]>;
    whoami(): Promise<UserRecord>;
    databaseID(): Promise<string>;
    listPeers({ level, incoming, admin, as_user }?: {
        level?: number;
        incoming?: boolean;
        admin?: boolean;
        as_user?: string;
    }): Promise<UserRecord[]>;
    queryUser(userId: number): Promise<UserRecord>;
    getUserStorage(as_user?: string): Promise<UserStorageInfo>;
    setFilePermission(path: string, permission: number): Promise<void>;
    move(path: string, newPath: string): Promise<void>;
    copy(srcPath: string, dstPath: string): Promise<void>;
    updateMyPassword(password: string): Promise<UserPasswordUpdateInfo>;
    updateMyPermission(permission: number | 'unset' | 'private' | 'protected' | 'public'): Promise<void>;
    queryHttpTraffic(resolution: 'minute' | 'hour' | 'day', time: number, count?: number): Promise<HttpTraffic[]>;
    listUsers({ username_filter, include_virtual, order_by, order_desc, offset, limit }?: {
        username_filter?: string;
        include_virtual?: boolean;
        order_by?: 'username' | 'create_time' | 'is_admin' | 'last_active';
        order_desc?: boolean;
        offset?: number;
        limit?: number;
    }): Promise<UserRecord[]>;
    addUser(params: {
        username: string;
        password?: string;
        admin?: boolean;
        max_storage?: string;
        permission?: string;
    }): Promise<UserRecord>;
    addVirtualUser(params: {
        tag?: string;
        peers?: string;
        max_storage?: string;
        expire?: string | number;
    }): Promise<UserRecord>;
    updateUser(params: {
        username: string;
        password?: string;
        admin?: boolean;
        max_storage?: string;
        permission?: string;
    }): Promise<UserRecord>;
    deleteUser(username: string): Promise<UserRecord>;
    setPeer(src_username: string, dst_username: string, level: 'NONE' | 'READ' | 'WRITE'): Promise<void>;
    queryUserExpire(params?: {
        username?: string;
        userid?: number;
    }): Promise<UserExpireInfo>;
    setUserExpire(username: string, expire?: string | number): Promise<UserExpireInfo>;
}
export declare class ApiUtils {
    static listPath(conn: Connector, path: string, { offset, limit, orderBy, orderDesc, }?: {
        offset?: number;
        limit?: number;
        orderBy?: FileSortKey | 'none';
        orderDesc?: boolean;
    }): Promise<[PathListResponse, {
        dirs: number;
        files: number;
    }]>;
    static uploadFile(conn: Connector, path: string, file: File, { conflict, permission }?: {
        conflict?: 'abort' | 'overwrite' | 'skip';
        permission?: number;
    }): Promise<string>;
    static encodePath(path: string): string;
    static decodePath(path: string): string;
    static getFullUrl(conn: Connector, url: string, includeToken?: boolean): string;
    static getDownloadUrl(conn: Connector, url: string, includeToken?: boolean): string;
    static getThumbUrl(conn: Connector, url: string, includeToken?: boolean): string;
    static getBundleUrl(conn: Connector, path: string): string;
}
