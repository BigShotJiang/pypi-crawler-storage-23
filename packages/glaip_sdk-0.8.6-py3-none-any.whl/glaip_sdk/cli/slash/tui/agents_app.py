"""Textual UI for `/agents` selection.

This app is the A1 selector surface and is designed to be wired into the
runtime `/agents` flow in A2.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any
from collections.abc import Callable

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.coordinate import Coordinate
from textual.reactive import reactive
from textual.widgets import DataTable, Footer, Input, Static

from glaip_sdk.cli.slash.tui.context import TUIContext
from glaip_sdk.cli.slash.tui.keybind_registry import KeybindRegistry
from glaip_sdk.cli.slash.tui.loading import hide_loading_indicator, show_loading_indicator
from glaip_sdk.cli.slash.tui.toast import ToastBus

logger = logging.getLogger(__name__)

AGENTS_TABLE_ID = "#agents-table"
FILTER_INPUT_ID = "#filter-input"
STATUS_ID = "#status"
AGENTS_LOADING_ID = "#agents-loading"

CSS_FILE_NAME = "agents.tcss"
KEYBIND_CATEGORY = "Agents"
APP_QUIT_ACTION = "app.quit"
DESCRIPTION_MAX_LEN = 72


@dataclass
class AgentInfo:
    """Agent row info used by the selector table."""

    id: str
    name: str
    description: str
    mcp_count: int
    is_active: bool = False


@dataclass
class AgentPage:
    """Pagination payload for the selector app."""

    items: list[AgentInfo]
    total: int | None = None
    page: int = 1
    limit: int = 25
    has_next: bool | None = None
    has_prev: bool | None = None


AgentPageFetcher = Callable[[int, int], AgentPage | dict[str, Any] | Any]


class AgentsApp(App[AgentInfo | None]):
    """Main Textual app for `/agents` command."""

    CSS_PATH = CSS_FILE_NAME

    BINDINGS = [
        Binding("q", APP_QUIT_ACTION, "Close", show=False),
        Binding("escape", APP_QUIT_ACTION, "Close", show=True, priority=True),
        Binding("ctrl+c", APP_QUIT_ACTION, "Quit", show=False),
        Binding("enter", "select_agent", "Select", show=True),
        Binding("up", "cursor_up", "Up", show=False, priority=True),
        Binding("down", "cursor_down", "Down", show=False, priority=True),
        Binding("left", "page_left", "Prev", show=True, priority=True),
        Binding("right", "page_right", "Next", show=True, priority=True),
        Binding("[", "page_left", "Prev", show=False, priority=True),
        Binding("]", "page_right", "Next", show=False, priority=True),
        Binding("/", "focus_filter", "Filter", show=False),
    ]

    agents: reactive[list[AgentInfo]] = reactive(list)
    filtered_agents: reactive[list[AgentInfo]] = reactive(list)
    selected_agent: reactive[AgentInfo | None] = reactive(None)

    def __init__(
        self,
        *,
        ctx: TUIContext | None = None,
        agents_data: list[dict[str, Any]] | None = None,
        fetch_page: AgentPageFetcher | None = None,
        page_size: int = 25,
    ) -> None:
        super().__init__()
        self._ctx = ctx
        self._raw_agents_data = agents_data or []
        self._fetch_page = fetch_page
        self._keybind_registry: KeybindRegistry | None = None
        self._toast_bus: ToastBus | None = None

        self._page_size = max(1, page_size)
        self._current_page = 1
        self._total_pages = 1
        self._total_items = 0
        self._has_next = False
        self._has_prev = False
        self._last_query = ""
        self._filter_source_cache: list[AgentInfo] | None = None

    def compose(self) -> ComposeResult:
        with Vertical(id="main-container"):
            yield Static("Select an agent to open its workspace", id="header")
            yield Input(placeholder="Filter agents...", id="filter-input")
            yield DataTable(id="agents-table")
            yield Static("Ready", id="status")
        yield Footer()

    def on_mount(self) -> None:
        self._initialize_services()
        self._setup_table()
        self._load_agents()
        self.query_one(AGENTS_TABLE_ID, DataTable).focus()

    def _initialize_services(self) -> None:
        self._toast_bus = ToastBus()
        self._keybind_registry = KeybindRegistry()
        self._register_keybindings()

    def _register_keybindings(self) -> None:
        if self._keybind_registry is None:
            return
        self._keybind_registry.register(
            category=KEYBIND_CATEGORY,
            action="select_agent",
            key="enter",
            description="Select agent",
        )
        self._keybind_registry.register(
            category=KEYBIND_CATEGORY,
            action="focus_filter",
            key="/",
            description="Focus filter",
        )
        self._keybind_registry.register(
            category=KEYBIND_CATEGORY,
            action="page_left",
            key="left",
            description="Previous page",
        )
        self._keybind_registry.register(
            category=KEYBIND_CATEGORY,
            action="page_right",
            key="right",
            description="Next page",
        )
        self._keybind_registry.register(
            category=KEYBIND_CATEGORY,
            action="cursor_up",
            key="up",
            description="Previous row",
        )
        self._keybind_registry.register(
            category=KEYBIND_CATEGORY,
            action="cursor_down",
            key="down",
            description="Next row",
        )

    def _setup_table(self) -> None:
        table = self.query_one(AGENTS_TABLE_ID, DataTable)
        table.add_columns("ID", "Name", "Description")
        table.cursor_type = "row"
        table.zebra_stripes = True

    def _load_agents(self) -> None:
        self._load_page(self._current_page)

    def _load_page(self, page: int) -> None:
        show_loading_indicator(self, AGENTS_LOADING_ID)
        try:
            if self._fetch_page is not None:
                page_data = self._coerce_page_result(self._fetch_page(page, self._page_size), page, self._page_size)
            elif self._raw_agents_data:
                page_data = self._build_local_page(page, self._page_size)
            else:
                page_data = self._fetch_agents_page(page, self._page_size)

            self._apply_page(page_data)
            self._apply_filter(self._last_query)

        except Exception as exc:
            logger.error("Failed to load agents: %s", exc)
            self._show_error(f"Failed to load agents: {exc}")
        finally:
            hide_loading_indicator(self, AGENTS_LOADING_ID)

    def _apply_page(self, page_data: AgentPage) -> None:
        self._current_page = max(1, page_data.page)
        self._page_size = max(1, page_data.limit)
        self.agents = list(page_data.items)

        total = page_data.total if page_data.total is not None else len(page_data.items)
        self._total_items = max(0, total)
        self._total_pages = max(1, (self._total_items + self._page_size - 1) // self._page_size)

        self._has_prev = page_data.has_prev if page_data.has_prev is not None else self._current_page > 1
        self._has_next = (
            page_data.has_next if page_data.has_next is not None else self._current_page < self._total_pages
        )
        # Invalidate cached global filter source when page payload changes.
        self._filter_source_cache = None

    def _build_local_page(self, page: int, limit: int) -> AgentPage:
        agents = self._parse_agents(self._raw_agents_data)
        total = len(agents)
        start = max(0, (max(1, page) - 1) * limit)
        end = start + limit
        return AgentPage(
            items=agents[start:end],
            total=total,
            page=max(1, page),
            limit=limit,
            has_prev=page > 1,
            has_next=end < total,
        )

    def _coerce_page_result(self, payload: Any, page: int, limit: int) -> AgentPage:
        if isinstance(payload, AgentPage):
            return payload

        if isinstance(payload, dict):
            items = self._parse_agents(payload.get("data") or payload.get("items") or [])
            return AgentPage(
                items=items,
                total=payload.get("total"),
                page=int(payload.get("page") or page),
                limit=int(payload.get("limit") or limit),
                has_next=payload.get("has_next"),
                has_prev=payload.get("has_prev"),
            )

        if hasattr(payload, "items") and hasattr(payload, "total"):
            items = self._parse_agents(getattr(payload, "items"))
            return AgentPage(
                items=items,
                total=getattr(payload, "total", None),
                page=getattr(payload, "page", page) or page,
                limit=getattr(payload, "limit", limit) or limit,
                has_next=getattr(payload, "has_next", None),
                has_prev=getattr(payload, "has_prev", None),
            )

        if isinstance(payload, list):
            return AgentPage(items=self._parse_agents(payload), total=len(payload), page=1, limit=max(1, len(payload)))

        return AgentPage(items=[], total=0, page=1, limit=limit)

    def _parse_agents(self, data: list[dict[str, Any]] | list[Any]) -> list[AgentInfo]:
        agents: list[AgentInfo] = []
        for item in data:
            payload = self._agent_to_dict(item)
            agents.append(
                AgentInfo(
                    id=str(payload.get("id", "")),
                    name=payload.get("name", "Unnamed"),
                    description=payload.get("description", "") or "",
                    mcp_count=len(payload.get("mcps", []) or []),
                    is_active=bool(payload.get("is_active", False)),
                )
            )
        return sorted(agents, key=lambda a: a.name.lower())

    def _agent_to_dict(self, item: Any) -> dict[str, Any]:
        if isinstance(item, dict):
            return item
        return {
            "id": getattr(item, "id", ""),
            "name": getattr(item, "name", "Unnamed"),
            "description": getattr(item, "description", ""),
            "mcps": getattr(item, "mcps", []) or [],
            "is_active": getattr(item, "is_active", False),
        }

    def _fetch_agents(self) -> list[AgentInfo]:
        return []

    def _fetch_agents_page(self, page: int, limit: int) -> AgentPage:
        all_agents = self._fetch_agents()
        total = len(all_agents)
        start = max(0, (max(1, page) - 1) * limit)
        end = start + limit
        return AgentPage(
            items=all_agents[start:end],
            total=total,
            page=max(1, page),
            limit=limit,
            has_prev=page > 1,
            has_next=end < total,
        )

    def _build_filter_source(self) -> list[AgentInfo]:
        """Build filter source across all available agents.

        Behavior:
        - For local demo payloads, use full in-memory list.
        - For paged callbacks, collect all pages once and cache while filtering.
        - For non-paged fallback path, use current loaded page.
        """
        if self._raw_agents_data:
            return self._parse_agents(self._raw_agents_data)

        if self._fetch_page is None:
            return list(self.agents)

        if self._filter_source_cache is not None:
            return self._filter_source_cache

        self._filter_source_cache = self._collect_filter_source_from_pages()
        return self._filter_source_cache

    def _collect_filter_source_from_pages(self) -> list[AgentInfo]:
        """Collect unique agents across paged fetch callback responses."""
        fetch_page = self._fetch_page
        if fetch_page is None:
            return list(self.agents)

        collected: list[AgentInfo] = []
        seen_ids: set[str] = set()
        page = 1

        while True:
            page_data = self._coerce_page_result(fetch_page(page, self._page_size), page, self._page_size)
            self._append_unique_agents(page_data.items, collected, seen_ids)

            if self._is_last_filter_page(page_data, collected):
                break

            page += 1

        return sorted(collected, key=lambda a: a.name.lower())

    @staticmethod
    def _append_unique_agents(
        page_items: list[AgentInfo],
        collected: list[AgentInfo],
        seen_ids: set[str],
    ) -> None:
        for agent in page_items:
            if agent.id in seen_ids:
                continue
            seen_ids.add(agent.id)
            collected.append(agent)

    @staticmethod
    def _is_last_filter_page(page_data: AgentPage, collected: list[AgentInfo]) -> bool:
        if page_data.has_next is not None:
            return not page_data.has_next

        total = page_data.total if page_data.total is not None else len(collected)
        return len(collected) >= total or not page_data.items

    @staticmethod
    def _format_description(description: str) -> str:
        if len(description) <= DESCRIPTION_MAX_LEN:
            return description
        return description[:DESCRIPTION_MAX_LEN] + "..."

    def _update_table(self) -> None:
        table = self.query_one(AGENTS_TABLE_ID, DataTable)
        table.clear()

        if not self.filtered_agents:
            status = self.query_one(STATUS_ID, Static)
            if self.agents:
                status.update("No agents match the filter")
            else:
                status.update("No agents available")
            return

        for agent in self.filtered_agents:
            table.add_row(
                agent.id,
                agent.name,
                self._format_description(agent.description),
            )

        status = self.query_one(STATUS_ID, Static)
        status.update(self._status_line())

    def _status_line(self) -> str:
        if self._last_query:
            return f"{len(self.filtered_agents)} match(es) | global filter"

        parts = [
            f"{len(self.filtered_agents)} shown",
            f"page {self._current_page}/{self._total_pages}",
            "↑↓ navigate",
        ]
        if self._has_prev or self._has_next:
            parts.append("←/→ or bracket keys page")
        return " | ".join(parts)

    def watch_filtered_agents(self, agents: list[AgentInfo]) -> None:
        self._update_table()

    def _fuzzy_match(self, query: str, text: str) -> bool:
        query = query.lower()
        text = text.lower()
        query_idx = 0
        text_idx = 0

        while query_idx < len(query) and text_idx < len(text):
            if query[query_idx] == text[text_idx]:
                query_idx += 1
            text_idx += 1

        return query_idx == len(query)

    def _apply_filter(self, query: str) -> None:
        self._last_query = query.strip().lower()
        if not self._last_query:
            self.filtered_agents = list(self.agents)
            self._filter_source_cache = None
            return

        source = self._build_filter_source()
        self.filtered_agents = [
            agent
            for agent in source
            if self._fuzzy_match(self._last_query, agent.name) or self._fuzzy_match(self._last_query, agent.id)
        ]

    def on_input_changed(self, event: Input.Changed) -> None:
        self._apply_filter(event.value)

    def on_key(self, event: Any) -> None:
        key = getattr(event, "key", "")
        if key not in {"left", "right"}:
            return

        filter_input = self.query_one(FILTER_INPUT_ID, Input)
        if filter_input.has_focus:
            return

        if key == "left":
            self.action_page_left()
        else:
            self.action_page_right()

        stop = getattr(event, "stop", None)
        if callable(stop):
            stop()

    def action_focus_filter(self) -> None:
        self.query_one(FILTER_INPUT_ID, Input).focus()

    def _move_cursor(self, delta: int) -> None:
        if not self.filtered_agents:
            return

        table = self.query_one(AGENTS_TABLE_ID, DataTable)
        current = table.cursor_row if table.cursor_row is not None else 0
        target = max(0, min(len(self.filtered_agents) - 1, current + delta))

        try:
            table.cursor_coordinate = Coordinate(target, 0)
        except Exception:
            try:
                table.move_cursor(row=target, column=0)
            except Exception:
                pass

        table.focus()

    def action_cursor_up(self) -> None:
        self._move_cursor(-1)

    def action_cursor_down(self) -> None:
        self._move_cursor(1)

    def action_page_left(self) -> None:
        if self._last_query:
            return
        if self._has_prev:
            self._load_page(self._current_page - 1)

    def action_page_right(self) -> None:
        if self._last_query:
            return
        if self._has_next:
            self._load_page(self._current_page + 1)

    def action_select_agent(self) -> None:
        table = self.query_one(AGENTS_TABLE_ID, DataTable)
        if table.cursor_row is None:  # pragma: no cover
            self._show_error("No agent selected")
            return

        if not self.filtered_agents:
            return

        try:  # pragma: no cover
            agent = self.filtered_agents[table.cursor_row]
            self.selected_agent = agent
            self._on_agent_selected(agent)
        except IndexError:  # pragma: no cover
            self._show_error("Invalid selection")

    def _on_agent_selected(self, agent: AgentInfo) -> None:
        if self._toast_bus:
            self._toast_bus.show(f"Opening {agent.name} workspace...", variant="info")
        self.exit(agent)

    def _show_error(self, message: str) -> None:
        self.query_one(STATUS_ID, Static).update(f"Error: {message}")
        if self._toast_bus:
            self._toast_bus.show(message, variant="error")


def run_agents_app(
    *,
    ctx: TUIContext | None = None,
    agents_data: list[dict[str, Any]] | None = None,
    fetch_page: AgentPageFetcher | None = None,
    page_size: int = 25,
) -> AgentInfo | None:
    """Run agents selector app and return selected agent."""
    app = AgentsApp(ctx=ctx, agents_data=agents_data, fetch_page=fetch_page, page_size=page_size)  # pragma: no cover
    return app.run()  # pragma: no cover


if __name__ == "__main__":
    demo_agents = [
        {
            "id": "agent-001",
            "name": "Code Reviewer",
            "description": "Reviews code for best practices and potential issues",
            "mcps": ["mcp-github", "mcp-gitlab"],
            "is_active": False,
        },
        {
            "id": "agent-002",
            "name": "Documentation Writer",
            "description": "Creates and updates technical documentation",
            "mcps": ["mcp-notion", "mcp-confluence"],
            "is_active": True,
        },
        {
            "id": "agent-003",
            "name": "Bug Triage",
            "description": "Triage and prioritize bug reports",
            "mcps": ["mcp-jira", "mcp-slack"],
            "is_active": False,
        },
    ]

    selected = run_agents_app(agents_data=demo_agents, page_size=2)
    if selected:
        print(f"Selected: {selected.name} ({selected.id})")
    else:
        print("No agent selected")
