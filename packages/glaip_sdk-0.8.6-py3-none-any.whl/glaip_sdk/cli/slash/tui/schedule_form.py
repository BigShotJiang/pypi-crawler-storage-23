# pyright: reportGeneralTypeIssues=false
"""Schedule form modal for create/edit actions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, cast

from glaip_sdk.cli.slash.tui.schedule_timing_wizard import ScheduleTimingWizardModal
from glaip_sdk.models.schedule import ScheduleConfig

if TYPE_CHECKING:  # pragma: no cover - type checking only
    from textual.app import ComposeResult
    from textual.binding import Binding
    from textual.containers import Horizontal
    from textual.screen import ModalScreen
    from textual.widgets import Button, Static, TextArea
else:
    try:  # pragma: no cover - optional dependency
        from textual.app import ComposeResult
        from textual.binding import Binding
        from textual.containers import Horizontal
        from textual.screen import ModalScreen
        from textual.widgets import Button, Static, TextArea
    except Exception:  # pragma: no cover - optional dependency
        ComposeResult = None  # type: ignore[assignment]
        Binding = None  # type: ignore[assignment]
        Horizontal = None  # type: ignore[assignment]
        ModalScreen = None  # type: ignore[assignment]
        Button = None  # type: ignore[assignment]
        Static = None  # type: ignore[assignment]
        TextArea = None  # type: ignore[assignment]

if ModalScreen is None:  # pragma: no cover - fallback stubs

    class ModalScreen:  # type: ignore[no-redef]
        """Fallback stub for ModalScreen."""

        pass


if Button is None:  # pragma: no cover - fallback stubs

    class Button:  # type: ignore[no-redef]
        """Fallback stub for Button."""

        class Pressed:  # pragma: no cover - stub
            """Fallback stub for Button.Pressed event."""

            def __init__(self, button: Any) -> None:
                """Initialize the event."""
                self.button = button

        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            """Initialize the button."""
            self.id = _kwargs.get("id")


if TextArea is None:  # pragma: no cover - fallback stubs

    class TextArea:  # type: ignore[no-redef]
        """Fallback stub for TextArea."""

        class Changed:  # pragma: no cover - stub
            """Fallback stub for TextArea.Changed event."""

            def __init__(self, text_area: Any, text: str) -> None:
                """Initialize the event."""
                self.text_area = text_area
                self.text = text

        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            """Initialize the text area."""
            self.id = _kwargs.get("id")
            self.text = _kwargs.get("text", "")


TEXTUAL_SUPPORTED = ModalScreen is not None and TextArea is not None and Button is not None and Static is not None


_FormBase = cast(Any, ModalScreen) if ModalScreen is not None else cast(Any, object)

TextAreaType = cast(Any, TextArea)
StaticType = cast(Any, Static)
ButtonType = cast(Any, Button)
HorizontalType = cast(Any, Horizontal)

MAX_INPUT_LENGTH = 10240
NOT_CONFIGURED_TEXT = "Not configured"
SET_SCHEDULE_TEXT = "Configure Timing..."
MODIFY_SCHEDULE_TEXT = "Change Timing..."


def _get_time_string(config: ScheduleConfig) -> str:
    """Format time string from config."""
    hours = config.hour.split(",") if config.hour != "*" else ["9"]
    minutes = config.minute.split(",") if config.minute != "*" else ["0"]
    times = [f"{h.zfill(2)}:{m.zfill(2)}" for h in hours for m in minutes]
    time_str = ", ".join(times[:2])  # Show max 2 times
    if len(times) > 2:
        time_str += f" and {len(times) - 2} more"
    return time_str


def _get_weekly_string(day_of_week: str) -> str:
    """Format weekly schedule string."""
    days_map = {0: "Sun", 1: "Mon", 2: "Tue", 3: "Wed", 4: "Thu", 5: "Fri", 6: "Sat"}
    day_parts = []
    for d in day_of_week.split(","):
        if d.isdigit():
            day_parts.append(days_map.get(int(d), d))
        else:
            # Handle ranges or other non-simple values
            day_parts.append(d)
    return f"Weekly on {', '.join(day_parts)}"


def _get_yearly_string(month: str, day_of_month: str) -> str:
    """Format yearly schedule string."""
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    month_name = months[int(month) - 1] if month.isdigit() else month
    return f"Yearly on {month_name} {day_of_month}"


def schedule_config_to_human_readable(config: ScheduleConfig) -> str:
    """Convert ScheduleConfig to human-readable description."""
    if not config:
        return NOT_CONFIGURED_TEXT

    # Determine frequency type
    if config.minute.startswith("*/"):
        # Interval
        interval = config.minute.replace("*/", "")
        return f"Every {interval} minutes"

    time_str = _get_time_string(config)

    if config.day_of_week != "*":
        return f"{_get_weekly_string(config.day_of_week)} at {time_str}"

    if config.month != "*":
        return f"{_get_yearly_string(config.month, config.day_of_month)} at {time_str}"

    if config.day_of_month != "*":
        # Monthly
        return f"Monthly on day {config.day_of_month} at {time_str}"

    # Daily
    return f"Daily at {time_str}"


@dataclass(frozen=True)
class ScheduleFormResult:
    """Result from the schedule form modal."""

    input_text: str
    schedule_config: ScheduleConfig
    schedule_id: str | None = None


class ScheduleFormModal(_FormBase):  # type: ignore[misc]
    """Modal form for schedule create/edit."""

    CSS_PATH = "schedules.tcss"

    if Binding:
        BINDINGS = [
            Binding("escape", "dismiss", "Cancel", priority=True),
            Binding("ctrl+s", "save", "Save", priority=True),
        ]
    else:  # pragma: no cover - optional dependency missing
        BINDINGS = []

    def __init__(
        self,
        *,
        mode: str,
        agent_name: str | None,
        agent_id: str | None,
        existing: Any | None,
        clone_source: bool = False,
    ) -> None:
        """Initialize the schedule form modal.

        Args:
            mode: "create" or "edit".
            agent_name: Name of the agent.
            agent_id: ID of the agent.
            existing: Existing schedule object (if editing or cloning).
            clone_source: Whether we are cloning the existing schedule.
        """
        super().__init__()
        self._mode = mode
        self._agent_name = agent_name
        self._agent_id = agent_id
        self._existing = existing
        self._clone_source = clone_source
        self._schedule_config: ScheduleConfig | None = None
        self._warned_fast_cadence = False

    def compose(self) -> ComposeResult:  # type: ignore[override]
        """Compose the form UI."""
        if not TEXTUAL_SUPPORTED:
            return  # type: ignore[return-value]
        title = "Create Schedule" if self._mode == "create" else "Edit Schedule"

        agent_label = self._agent_name or self._agent_id or "Active agent"
        if self._agent_name and self._agent_id:
            agent_label = f"{self._agent_name} ({self._agent_id})"

        yield StaticType(title, id="form-title")
        yield StaticType(f"Agent: {agent_label}", id="form-agent")

        yield StaticType("Input *", classes="section-label")
        yield StaticType("What should the agent do?", classes="help-text")

        # Use markdown highlighting if available, otherwise default
        try:
            input_widget = TextAreaType(text=self._initial_input(), id="form-input", language="markdown")
        except TypeError:
            # Fallback for older Textual versions if language param not supported
            input_widget = TextAreaType(text=self._initial_input(), id="form-input")

        yield input_widget
        yield StaticType("0 characters", id="form-input-counter")

        yield StaticType("Schedule *", classes="section-label")
        yield StaticType("When should this run?", classes="help-text")

        yield HorizontalType(
            StaticType("Not configured", id="form-schedule-status"),
            StaticType("", id="form-preview"),
            StaticType("", id="form-cron-preview"),
            ButtonType("Configure Timing...", id="form-configure", variant="primary"),
            id="form-timing-row",
        )

        save_label = "Create" if self._mode == "create" else "Save"
        yield HorizontalType(
            ButtonType(save_label, id="form-save", variant="success"),
            ButtonType("Cancel", id="form-cancel"),
            id="form-actions",
        )

        yield StaticType("", id="form-hint")
        yield StaticType("", id="form-status")

    def on_mount(self) -> None:
        """Initialize form state on mount."""
        if not TEXTUAL_SUPPORTED:
            return
        if self._existing and getattr(self._existing, "schedule_config", None):
            existing_config = getattr(self._existing, "schedule_config", None)
            if isinstance(existing_config, ScheduleConfig):
                self._schedule_config = existing_config
            elif isinstance(existing_config, dict):
                self._schedule_config = ScheduleConfig(**existing_config)
        self._update_preview()
        self._update_counter()
        self._update_save_state()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button actions."""
        btn_id = event.button.id or ""
        if btn_id == "form-cancel":
            self.dismiss(None)
            return
        if btn_id == "form-save":
            self.action_save()
            return
        if btn_id == "form-configure":
            self._open_timing_wizard()

    def on_text_area_changed(self, event: TextArea.Changed) -> None:
        """Update char counter when text area changes."""
        if event.text_area.id == "form-input":
            self._update_counter()
            self._update_save_state()

    def action_save(self) -> None:
        """Validate and save the form."""
        input_text = self._get_input_value()
        if not input_text:
            self._set_status("Input is required.")
            return
        if len(input_text) > MAX_INPUT_LENGTH:
            self._set_status("Input exceeds 10,240 characters.")
            return
        if self._schedule_config is None:
            self._set_status("Schedule timing is required.")
            return
        if self._requires_fast_cadence_warning(self._schedule_config) and not self._warned_fast_cadence:
            self._warned_fast_cadence = True
            self._set_status("Fast cadence detected (<30 min). Press Save again to confirm.")
            return
        schedule_id = None
        if self._existing is not None and not self._clone_source:
            schedule_id = str(getattr(self._existing, "id", "")) or None
        self.dismiss(
            ScheduleFormResult(input_text=input_text, schedule_config=self._schedule_config, schedule_id=schedule_id)
        )

    def _open_timing_wizard(self) -> None:
        modal = ScheduleTimingWizardModal(
            initial=self._schedule_config,
            agent_name=self._agent_name or self._agent_id,
            action_preview=self._get_input_value() or None,
        )
        self.app.push_screen(modal, self._on_wizard_result)

    def _on_wizard_result(self, result: ScheduleConfig | None) -> None:
        if result is None:
            return
        self._schedule_config = result
        self._warned_fast_cadence = False
        self._update_preview()
        self._update_save_state()

    def _update_save_state(self) -> None:
        """Disable save until required fields are set."""
        if not TEXTUAL_SUPPORTED:
            return
        input_ok = bool(self._get_input_value())
        timing_ok = self._schedule_config is not None

        missing: list[str] = []
        if not input_ok:
            missing.append("input")
        if not timing_ok:
            missing.append("schedule")

        try:
            save_btn = self.query_one("#form-save", ButtonType)
            save_btn.disabled = bool(missing)
        except Exception:
            pass

        hint = ""
        if missing:
            hint = f"[dim]Missing: {', '.join(missing)}[/dim]"
        self.query_one("#form-hint", StaticType).update(hint)

    def _update_counter(self) -> None:
        """Update the character counter display."""
        if not TEXTUAL_SUPPORTED:
            return
        count = len(self._get_input_value())
        text = f"{count} characters"
        if count > MAX_INPUT_LENGTH * 0.8:
            text += f" / {MAX_INPUT_LENGTH}"

        self.query_one("#form-input-counter", StaticType).update(text)

    def _update_preview(self) -> None:
        """Update the schedule preview display."""
        if not TEXTUAL_SUPPORTED:
            return
        if not self._schedule_config:
            self.query_one("#form-schedule-status", StaticType).update(NOT_CONFIGURED_TEXT)
            self.query_one("#form-preview", StaticType).update("")
            self.query_one("#form-cron-preview", StaticType).update("")
            configure_btn = self.query_one("#form-configure", ButtonType)
            configure_btn.label = SET_SCHEDULE_TEXT
            return

        human_readable = schedule_config_to_human_readable(self._schedule_config)
        self.query_one("#form-schedule-status", StaticType).update("Schedule configured")
        self.query_one("#form-preview", StaticType).update(human_readable)
        self.query_one("#form-cron-preview", StaticType).update(f"Cron: {self._schedule_config.to_cron_string()}")

        configure_btn = self.query_one("#form-configure", ButtonType)
        configure_btn.label = MODIFY_SCHEDULE_TEXT

    def _get_input_value(self) -> str:
        """Get the input text value."""
        if not TEXTUAL_SUPPORTED:
            return ""
        return self.query_one("#form-input", TextAreaType).text.strip()

    def _initial_input(self) -> str:
        """Get the initial input from existing schedule."""
        if self._existing is None:
            return ""
        return str(getattr(self._existing, "input", "") or "")

    def _set_status(self, message: str) -> None:
        """Set a status message."""
        if not TEXTUAL_SUPPORTED:
            return
        self.query_one("#form-status", StaticType).update(f"[yellow]{message}[/]")

    @staticmethod
    def _requires_fast_cadence_warning(config: ScheduleConfig) -> bool:
        minute = (config.minute or "").strip()
        if minute.startswith("*/"):
            try:
                interval = int(minute.replace("*/", ""))
            except ValueError:
                return False
            if interval < 30 and config.hour == "*" and config.day_of_month == "*" and config.month == "*":
                return True
        return False
