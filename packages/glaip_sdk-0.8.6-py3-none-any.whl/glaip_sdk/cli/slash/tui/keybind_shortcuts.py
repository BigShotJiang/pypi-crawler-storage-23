"""Shared Textual keybinding shortcut builders."""

from __future__ import annotations

from textual.binding import Binding


def close_shortcuts(
    *,
    escape_action: str,
    quit_action: str,
    show_escape: bool = True,
) -> tuple[Binding, Binding]:
    """Build standardized close shortcuts.

    Returns Esc as the visible close action and q as hidden fallback.
    """
    return (
        Binding("escape", escape_action, "Close", priority=True, show=show_escape),
        Binding("q", quit_action, "Close", priority=True, show=False),
    )
