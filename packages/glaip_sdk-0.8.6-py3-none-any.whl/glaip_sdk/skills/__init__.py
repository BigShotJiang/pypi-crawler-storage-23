"""Skill helpers for local agent execution.

This module re-exports the AIP Agents Skill object for use in glaip-sdk
without requiring callers to import aip_agents directly. Imports are lazy
so aip_agents remains an optional dependency unless local skills are used.

Example:
    >>> from glaip_sdk.skills import Skill
    >>> skill = Skill.from_path(".agents/skills/brand-guidelines")

Authors:
    Saul Sayers (saul.sayers@gdplabs.id)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:  # pragma: no cover - import only for type checking
    from aip_agents.skills import Skill as Skill  # noqa: F401

__all__ = ["Skill"]


def _load_skill() -> type:
    """Load the Skill class from aip_agents.

    Returns:
        The Skill class from aip_agents.skills.
    """
    # Keep aip_agents optional until Skill is accessed.
    from aip_agents.skills import Skill  # noqa: PLC0415

    return Skill


def __getattr__(name: str) -> Any:
    """Lazy attribute access for Skill to avoid hard dependency on aip_agents."""
    if name == "Skill":
        try:
            skill_cls = _load_skill()
        except ImportError as exc:
            raise ImportError("aip_agents is required for Skill. Install with: pip install 'glaip-sdk[local]'") from exc
        globals()["Skill"] = skill_cls
        return skill_cls
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    """Return module attributes for dir()."""
    return sorted(__all__)
