"""Audio interface for AIP agents.

This module provides a provider-agnostic interface for adding audio input/output
to AIP agents. Realtime sessions (LiveKit) are supported for local development.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from glaip_sdk.audio_interface import livekit_session as _livekit_session
from glaip_sdk.audio_interface.livekit_session import LiveKitAudioSession

AudioSessionFactory = Callable[..., Any]

# Backward-compatible module alias used by existing tests/patching.
importlib = _livekit_session.importlib

# Internal shim remains available for tests/backward compatibility.
_GlaipSDKAgentAudioShim = _livekit_session._GlaipSDKAgentAudioShim

__all__ = [
    "AudioSessionFactory",
    "LiveKitAudioSession",
    "register_audio_session_implementation",
    "create_audio_session",
]


_AUDIO_SESSION_FACTORIES: dict[str, AudioSessionFactory] = {
    "livekit": LiveKitAudioSession,
}


def register_audio_session_implementation(name: str, factory: AudioSessionFactory) -> None:
    """Register an audio session implementation factory.

    Args:
        name: Provider/implementation name (e.g., "livekit", "webrtc").
        factory: Callable that returns a session instance. It should accept the
            same keyword arguments used by ``create_audio_session``.
    """
    normalized = name.strip().lower()
    if not normalized:
        raise ValueError("Implementation name cannot be empty")
    if not callable(factory):
        raise TypeError("Audio session factory must be callable")
    _AUDIO_SESSION_FACTORIES[normalized] = factory


def _resolve_audio_session_factory(
    implementation: str | AudioSessionFactory | None,
    *,
    config: Any | None,
) -> AudioSessionFactory:
    if implementation is None:
        if isinstance(config, dict):
            provider = config.get("provider")
            if isinstance(provider, str):
                configured = _AUDIO_SESSION_FACTORIES.get(provider.strip().lower())
                if configured is not None:
                    return configured
        raise ValueError(
            "Audio implementation must be specified (e.g. implementation='livekit'). "
            "No default is provided to ensure explicit transport selection."
        )

    if isinstance(implementation, str):
        resolved = _AUDIO_SESSION_FACTORIES.get(implementation.strip().lower())
        if resolved is None:
            available = ", ".join(sorted(_AUDIO_SESSION_FACTORIES))
            raise ValueError(f"Unknown audio implementation {implementation!r}. Available: {available}")
        return resolved

    if callable(implementation):
        return implementation

    raise TypeError("Audio implementation must be a registered name or callable factory")


def create_audio_session(
    config: Any | None = None,
    *,
    agent: Any | None = None,
    instructions: str | None = None,
    implementation: str | AudioSessionFactory | None = None,
    **session_kwargs: Any,
) -> Any:
    """Create an audio session using a selected implementation.

    This keeps LiveKit as the zero-config path while allowing low-code swaps to
    custom implementations via either:
    - a registered provider name (``implementation="my-provider"``), or
    - a callable session factory/class (``implementation=MySession``).
    """
    factory = _resolve_audio_session_factory(implementation, config=config)
    return factory(
        config=config,
        agent=agent,
        instructions=instructions,
        **session_kwargs,
    )
