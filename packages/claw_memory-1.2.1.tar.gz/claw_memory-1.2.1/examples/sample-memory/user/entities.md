---
type: entity
importance: 3
reinforcement: 2
created: '2026-02-10'
updated: '2026-02-13'
status: active
---
- Xiao Lin: Full-stack engineer, responsible for backend and frontend development
- Zhang San: Backend team lead, responsible for payment and order services
- Project uses PostgreSQL 15 with asyncpg driver
