---
type: instruction
importance: 5
reinforcement: 3
created: '2026-02-10'
updated: '2026-02-14'
status: active
---
- All APIs must return snake_case format
- Run lint and tests before committing
- Use Conventional Commits format for commit messages
- Never use `any` type in TypeScript code
