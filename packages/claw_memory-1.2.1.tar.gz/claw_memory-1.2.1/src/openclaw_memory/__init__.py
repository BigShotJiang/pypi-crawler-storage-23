"""OpenClaw Memory — record and search AI chat history."""

# Keep in sync with pyproject.toml [project] version
__version__ = "1.2.1"
