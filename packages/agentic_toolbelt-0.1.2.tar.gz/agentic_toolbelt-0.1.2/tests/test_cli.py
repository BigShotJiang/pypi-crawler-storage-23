from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from unittest.mock import patch

from agentic_toolbelt.cli import copy_payload, main


class CliTests(unittest.TestCase):
    def test_copy_payload_to_empty_directory(self):
        with TemporaryDirectory() as tmp:
            destination = Path(tmp)
            copied, skipped = copy_payload(destination)

            self.assertEqual(skipped, [])
            self.assertEqual(set(copied), {".agents", ".codex", "AGENTS.md"})
            self.assertTrue((destination / ".agents" / "ralph" / "agents.sh").is_file())
            self.assertTrue((destination / ".codex" / "skills" / "commit" / "SKILL.md").is_file())
            self.assertTrue((destination / "AGENTS.md").is_file())

    def test_copy_payload_skips_existing_without_force(self):
        with TemporaryDirectory() as tmp:
            destination = Path(tmp)
            existing_agents = destination / "AGENTS.md"
            existing_agents.write_text("custom\n", encoding="utf-8")

            copied, skipped = copy_payload(destination)

            self.assertIn("AGENTS.md", skipped)
            self.assertNotIn("AGENTS.md", copied)
            self.assertEqual(existing_agents.read_text(encoding="utf-8"), "custom\n")

    def test_copy_payload_overwrites_when_force_enabled(self):
        with TemporaryDirectory() as tmp:
            destination = Path(tmp)
            existing_agents = destination / "AGENTS.md"
            existing_agents.write_text("custom\n", encoding="utf-8")

            copied, skipped = copy_payload(destination, force=True)

            self.assertEqual(skipped, [])
            self.assertIn("AGENTS.md", copied)
            self.assertTrue(existing_agents.read_text(encoding="utf-8").startswith("# ~/.codex/AGENTS.md"))

    def test_main_copies_into_current_directory(self):
        with TemporaryDirectory() as tmp:
            with patch("agentic_toolbelt.cli.Path.cwd", return_value=Path(tmp)):
                exit_code = main([])

            self.assertEqual(exit_code, 0)
            self.assertTrue((Path(tmp) / "AGENTS.md").is_file())

    def test_main_recovers_from_partial_destination(self):
        with TemporaryDirectory() as tmp:
            smoke_root = Path(tmp) / ".agents"
            smoke_root.mkdir()
            (smoke_root / "ralph").mkdir()
            (smoke_root / "ralph" / "README.md").write_text("stale", encoding="utf-8")

            with patch("agentic_toolbelt.cli.Path.cwd", return_value=Path(tmp)):
                exit_code = main(["--force"])

            self.assertEqual(exit_code, 0)
            self.assertTrue((Path(tmp) / ".agents" / "ralph" / "agents.sh").is_file())
            self.assertTrue((Path(tmp) / ".codex" / "skills" / "commit" / "SKILL.md").is_file())


if __name__ == "__main__":
    unittest.main()
