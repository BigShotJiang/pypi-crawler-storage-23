from importlib import resources
import unittest

import agentic_toolbelt


class PackagingTests(unittest.TestCase):
    def test_payload_files_are_available(self):
        root = resources.files(agentic_toolbelt)
        self.assertTrue((root / ".agents").is_dir())
        self.assertTrue((root / ".codex").is_dir())
        self.assertTrue((root / "AGENTS.md").is_file())
        self.assertTrue((root / ".agents" / "ralph" / "agents.sh").is_file())
        self.assertTrue((root / ".codex" / "skills" / "commit" / "SKILL.md").is_file())
