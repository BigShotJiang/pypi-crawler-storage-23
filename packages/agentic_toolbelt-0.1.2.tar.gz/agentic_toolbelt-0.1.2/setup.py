from pathlib import Path

from setuptools import find_packages, setup


PACKAGE_DIR = Path(__file__).parent / "agentic_toolbelt"


def _data_files():
    files = []
    for path in sorted(PACKAGE_DIR.rglob("*")):
        if not path.is_file():
            continue
        if path.name.endswith(".py") or path.name == "__pycache__":
            continue
        rel_path = path.relative_to(PACKAGE_DIR)
        files.append(str(rel_path))
    return files


setup(
    name="agentic-toolbelt",
    version="0.1.2",
    description="Installs this folder's AGENTS and .codex/.agents content as package data.",
    packages=find_packages(),
    include_package_data=True,
    package_data={"agentic_toolbelt": _data_files()},
    entry_points={"console_scripts": ["agentic-set=agentic_toolbelt.cli:main"]},
)
