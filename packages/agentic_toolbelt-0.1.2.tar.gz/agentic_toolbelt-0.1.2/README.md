# Agentic Toolbelt

**Author:** Roberto Del Prete

## Purpose

`agentic-set` is a small installer utility that copies a standardized agent setup payload into a project directory.

It places three items in the current working directory:

- `.agents`
- `.codex`
- `AGENTS.md`

This provides a repeatable baseline for agentic workflows by ensuring every project has the same instruction, tooling, and metadata files.

## Features

- CLI entrypoint: `agentic-set`
- Copies packaged payload directly into the directory where the command is launched
- Supports `--force` to overwrite existing `.agents`, `.codex`, and `AGENTS.md`
- Safe copy flow with temporary staging and cleanup

## Installation

From the repository root:

```bash
uv pip install -e . --python /path/to/venv/bin/python
```

This registers the `agentic-set` console script in that virtual environment.

## Usage

From any project directory:

```bash
agentic-set
```

Force overwrite when files already exist:

```bash
agentic-set --force
```

## Development

- Python package entrypoint is also declared in `setup.py` and `pyproject.toml`.
- Current package version is maintained in both `pyproject.toml` and `setup.py`.
