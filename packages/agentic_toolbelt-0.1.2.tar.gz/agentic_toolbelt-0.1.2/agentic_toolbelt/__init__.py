"""Package metadata for the agentic-toolbelt installer payload."""

from importlib import resources


def resource_path(*parts):
    """Return a path-like object for a packaged file under this package."""

    return resources.files(__name__).joinpath(*parts)
