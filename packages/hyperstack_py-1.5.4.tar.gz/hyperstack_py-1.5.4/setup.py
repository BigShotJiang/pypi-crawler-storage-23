from setuptools import setup, find_packages

setup(
    name="hyperstack-py",
    version="1.5.4",
    description="The Agent Provenance Graph for AI agents. Timestamped facts, auditable decisions, deterministic trust. Prove what agents knew, trace why they knew it, coordinate without an LLM in the loop. $0 per operation.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="CascadeAI",
    author_email="deeq@cascadeai.dev",
    url="https://cascadeai.dev",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[],  # Zero dependencies!
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Topic :: Software Development :: Libraries",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords="ai memory agent llm hyperstack mcp claude cursor",
    license="MIT",
    project_urls={
        "Documentation": "https://cascadeai.dev",
        "Source": "https://github.com/deeqyaqub1-cmd/hyperstack-py",
        "Discord": "https://discord.gg/tdnXaV6e",
    },
)
