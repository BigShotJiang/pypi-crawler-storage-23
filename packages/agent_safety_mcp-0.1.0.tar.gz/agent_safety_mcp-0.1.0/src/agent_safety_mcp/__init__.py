"""MCP server for AI agent safety — cost guards, injection scanning, and decision tracing."""

__version__ = "0.1.0"
