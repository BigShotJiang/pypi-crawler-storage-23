"""Allow running the Prismer CLI via `python -m prismer`."""

from prismer.cli import main

main()
