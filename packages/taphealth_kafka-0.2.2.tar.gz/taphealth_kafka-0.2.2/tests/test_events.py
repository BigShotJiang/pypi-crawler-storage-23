import json

from taphealth_kafka import (
    ActivityPlan,
    ConversationSummaryData,
    DailyPlan,
    DailyPlanCreatedData,
    DailyTask,
    DailyTaskType,
    DietCreatedData,
    ExerciseData,
    ExerciseLoggedData,
    ExercisePlan,
    FeedbackBreakdown,
    GeneratedMeal,
    GlucoseLoggedData,
    GlucosePlan,
    GlucoseRange,
    GlucoseType,
    HabitKey,
    LoggedMeal,
    Macros,
    MealComponent,
    MealData,
    MealFeedback,
    MealLoggedData,
    MealVariation,
    MetricLoggedData,
    MetricType,
    Nudge,
    NudgeContext,
    NudgePlan,
    NutritionPlan,
    ProfileUpdatedData,
    TargetCalorieDistribution,
    TargetMacros,
    TaskTarget,
    VoiceCallAnalyticsData,
    WorkoutStatus,
)


class TestConversationSummaryData:
    def test_to_dict(self):
        data = ConversationSummaryData(
            user_id="user-123",
            summary="User discussed meal planning and glucose targets for the week.",
            conversation_id="conv-456",
            started_at="2025-01-28T10:00:00Z",
            ended_at="2025-01-28T10:15:00Z",
        )
        result = data.to_dict()

        assert result["userId"] == "user-123"
        assert result["summary"] == "User discussed meal planning and glucose targets for the week."
        assert result["conversationId"] == "conv-456"
        assert result["startedAt"] == "2025-01-28T10:00:00Z"
        assert result["endedAt"] == "2025-01-28T10:15:00Z"

    def test_json_serializable(self):
        data = ConversationSummaryData(
            user_id="user-789",
            summary="Brief check-in about exercise routine.",
            conversation_id="conv-789",
            started_at="2025-01-28T14:00:00Z",
            ended_at="2025-01-28T14:05:00Z",
        )
        json_str = json.dumps(data.to_dict())
        parsed = json.loads(json_str)

        assert parsed["userId"] == "user-789"
        assert parsed["conversationId"] == "conv-789"
        assert isinstance(parsed["summary"], str)

    def test_camel_case_field_names(self):
        data = ConversationSummaryData(
            user_id="user-123",
            summary="Test summary",
            conversation_id="conv-123",
            started_at="2025-01-28T10:00:00Z",
            ended_at="2025-01-28T10:15:00Z",
        )
        result = data.to_dict()

        # Verify camelCase
        assert "userId" in result
        assert "conversationId" in result
        assert "startedAt" in result
        assert "endedAt" in result

        # Verify no snake_case
        assert "user_id" not in result
        assert "conversation_id" not in result
        assert "started_at" not in result
        assert "ended_at" not in result


class TestGlucoseLoggedData:
    def test_to_dict_required_fields(self):
        data = GlucoseLoggedData(
            user_id="user-123",
            date="2025-01-27",
            glucose_type=GlucoseType.FASTING,
            glucose_reading=95.0,
            glucose_range=GlucoseRange.NORMAL,
            is_critical=False,
        )
        result = data.to_dict()

        assert result["userId"] == "user-123"
        assert result["date"] == "2025-01-27"
        assert result["type"] == GlucoseType.FASTING.value
        assert result["glucoseReading"] == 95.0
        assert result["glucoseRange"] == GlucoseRange.NORMAL.value
        assert result["isCritical"] is False
        assert "timezone" not in result

    def test_to_dict_with_timezone(self):
        data = GlucoseLoggedData(
            user_id="user-123",
            date="2025-01-27",
            glucose_type=GlucoseType.POST_LUNCH,
            glucose_reading=140.0,
            glucose_range=GlucoseRange.HIGH,
            is_critical=True,
            timezone="America/New_York",
        )
        result = data.to_dict()

        assert result["timezone"] == "America/New_York"
        assert result["type"] == GlucoseType.POST_LUNCH.value
        assert result["glucoseRange"] == GlucoseRange.HIGH.value

    def test_json_serializable(self):
        data = GlucoseLoggedData(
            user_id="user-123",
            date="2025-01-27",
            glucose_type=GlucoseType.FASTING,
            glucose_reading=95.0,
            glucose_range=GlucoseRange.NORMAL,
            is_critical=False,
        )
        json_str = json.dumps(data.to_dict())
        parsed = json.loads(json_str)

        assert parsed["userId"] == "user-123"


class TestMetricLoggedData:
    def test_to_dict(self):
        data = MetricLoggedData(
            user_id="user-456",
            date="2025-01-27",
            metric_type=MetricType.WEIGHT,
            value=75.5,
        )
        result = data.to_dict()

        assert result["userId"] == "user-456"
        assert result["date"] == "2025-01-27"
        assert result["metricType"] == MetricType.WEIGHT.value
        assert result["value"] == 75.5

    def test_all_metric_types(self):
        for metric_type in MetricType:
            data = MetricLoggedData(
                user_id="user-1",
                date="2025-01-27",
                metric_type=metric_type,
                value=100.0,
            )
            result = data.to_dict()
            assert result["metricType"] == metric_type.value


class TestExerciseLoggedData:
    def test_to_dict(self):
        exercises = [
            ExerciseData(
                name="Running",
                date="2025-01-27",
                duration=30,
                calories_burnt=300,
                status=WorkoutStatus.COMPLETE,
            ),
            ExerciseData(name="Yoga"),
        ]
        data = ExerciseLoggedData(
            user_id="user-789",
            logged_at="2025-01-27T10:00:00Z",
            exercises=exercises,
            timezone="Asia/Kolkata",
        )
        result = data.to_dict()

        assert result["userId"] == "user-789"
        assert result["loggedAt"] == "2025-01-27T10:00:00Z"
        assert result["timezone"] == "Asia/Kolkata"
        assert len(result["exercises"]) == 2
        assert result["exercises"][0]["name"] == "Running"
        assert result["exercises"][0]["duration"] == 30
        assert result["exercises"][0]["caloriesBurnt"] == 300
        assert result["exercises"][0]["status"] == WorkoutStatus.COMPLETE.value
        assert result["exercises"][1]["name"] == "Yoga"
        assert "duration" not in result["exercises"][1]


class TestDietCreatedData:
    def test_to_dict(self):
        macros = Macros(calories=500, carbs=60, fat=20, protein=25, fibre=5)
        component = MealComponent(
            id="comp-1",
            name="Rice",
            type="grain",
            quantity="1",
            unit="cup",
            macros=macros,
            is_vegetarian=True,
            variation=MealVariation.MODERATE,
        )
        generated = GeneratedMeal(components=[component])
        meal = MealData(
            date="2025-01-27",
            meal_type="LUNCH",
            meal_time="12:30",
            rationale="Balanced lunch",
            generated=generated,
        )
        data = DietCreatedData(
            user_id="user-123",
            scheduled_date="2025-01-27",
            meals=[meal],
        )
        result = data.to_dict()

        assert result["userId"] == "user-123"
        assert result["scheduledDate"] == "2025-01-27"
        assert len(result["meals"]) == 1
        assert result["meals"][0]["mealType"] == "LUNCH"
        assert result["meals"][0]["mealTime"] == "12:30"
        assert result["meals"][0]["generated"]["components"][0]["name"] == "Rice"
        assert result["meals"][0]["generated"]["components"][0]["isVegetarian"] is True
        assert result["meals"][0]["generated"]["components"][0]["variation"] == "MODERATE"


class TestMealLoggedData:
    def test_to_dict(self):
        macros = Macros(calories=400, carbs=50, fat=15, protein=20, fibre=3)
        component = MealComponent(
            id="comp-1",
            name="Dal",
            type="pulse",
            quantity="1",
            unit="bowl",
            macros=macros,
            is_vegetarian=True,
        )
        breakdown = FeedbackBreakdown(item="Dal", type="positive", reason="Good protein source")
        feedback = MealFeedback(meal_score=85, flags={}, breakdown=[breakdown])
        logged_meal = LoggedMeal(components=[component], feedback=feedback)

        data = MealLoggedData(
            user_id="user-123",
            date="2025-01-27",
            meal_type="DINNER",
            logged_at="2025-01-27T19:30:00Z",
            logged_meal=logged_meal,
            had_generated_meal=True,
            logged_variation=MealVariation.EASY,
        )
        result = data.to_dict()

        assert result["userId"] == "user-123"
        assert result["mealType"] == "DINNER"
        assert result["loggedAt"] == "2025-01-27T19:30:00Z"
        assert result["hadGeneratedMeal"] is True
        assert result["loggedVariation"] == "EASY"
        assert result["loggedMeal"]["feedback"]["mealScore"] == 85
        assert result["loggedMeal"]["components"][0]["macros"]["calories"] == 400


class TestProfileUpdatedData:
    def test_to_dict_minimal(self):
        data = ProfileUpdatedData(id="profile-123")
        result = data.to_dict()

        assert result["id"] == "profile-123"
        assert len(result) == 1

    def test_to_dict_with_fields(self):
        data = ProfileUpdatedData(
            id="profile-123",
            user_id="user-123",
            name="John Doe",
            age=30,
            diabetes=True,
            profile_completed=True,
        )
        result = data.to_dict()

        assert result["id"] == "profile-123"
        assert result["userId"] == "user-123"
        assert result["name"] == "John Doe"
        assert result["age"] == 30
        assert result["diabetes"] is True
        assert result["profileCompleted"] is True


class TestDailyPlanCreatedData:
    def test_to_dict(self):
        target = TaskTarget(unit="mg/dL", initial=0, current=1)
        task = DailyTask(
            type=DailyTaskType.GLUCOSE_LOGGING,
            description="Log fasting glucose",
            target=target,
            habit_key=HabitKey.GLUCOSE_LOG_TIMELY,
            is_micro_challenge=False,
            current_progress=0,
        )
        nudge_context = NudgeContext(
            summary="Time to log glucose",
            log_patterns=["morning"],
            plan_summary="Daily glucose monitoring",
        )
        nudge = Nudge(
            module="glucose",
            time="08:00",
            priority=1,
            channel="push",
            context=nudge_context,
            name="morning_glucose",
        )
        nudge_plan = NudgePlan(
            day_number=1,
            date="2025-01-27",
            user_id="user-123",
            plan_summary="Day 1 plan",
            nudges=[nudge],
            warnings=[],
        )
        target_macros = TargetMacros(protein=80, carbs=200, fats=60, fibre=25)
        calorie_dist = TargetCalorieDistribution(carbs=50, protein=20, fat=25, fibre=5)
        nutrition = NutritionPlan(
            target_calories=1800,
            target_macros=target_macros,
            target_calorie_distribution=calorie_dist,
        )
        glucose = GlucosePlan(fasting=True, postprandial=True, night=False, pre_workout=False)
        exercise = ExercisePlan(duration=30, type="walking", intensity="moderate")
        activity = ActivityPlan(steps=8000, exercise=exercise)
        plan = DailyPlan(nutrition=nutrition, glucose=glucose, activity=activity)

        data = DailyPlanCreatedData(
            user_id="user-123",
            timezone="Asia/Kolkata",
            date="2025-01-27",
            tasks={"glucose": [task]},
            nudge_plan=nudge_plan,
            plan=plan,
        )
        result = data.to_dict()

        assert result["userId"] == "user-123"
        assert result["timezone"] == "Asia/Kolkata"
        assert result["date"] == "2025-01-27"
        assert "glucose" in result["tasks"]
        assert result["tasks"]["glucose"][0]["habitKey"] == HabitKey.GLUCOSE_LOG_TIMELY.value
        assert result["nudgePlan"]["dayNumber"] == 1
        assert result["plan"]["nutrition"]["targetCalories"] == 1800
        assert result["plan"]["nutrition"]["targetMacros"]["fats"] == 60
        assert result["plan"]["activity"]["exercise"]["duration"] == 30


class TestCamelCaseConversion:
    """Test that all snake_case fields are properly converted to camelCase."""

    def test_glucose_logged_field_names(self):
        data = GlucoseLoggedData(
            user_id="u1",
            date="2025-01-27",
            glucose_type=GlucoseType.FASTING,
            glucose_reading=100,
            glucose_range=GlucoseRange.NORMAL,
            is_critical=False,
            timezone="UTC",
        )
        result = data.to_dict()

        # Verify camelCase
        assert "userId" in result
        assert "type" in result
        assert "glucoseReading" in result
        assert "glucoseRange" in result
        assert "isCritical" in result

        # Verify no snake_case
        assert "user_id" not in result
        assert "glucose_type" not in result
        assert "glucoseType" not in result
        assert "glucose_reading" not in result
        assert "glucose_range" not in result
        assert "is_critical" not in result

    def test_exercise_logged_field_names(self):
        exercise = ExerciseData(
            name="Running",
            calories_burnt=200,
            status=WorkoutStatus.COMPLETE,
        )
        result = exercise.to_dict()

        assert "caloriesBurnt" in result
        assert "calories_burnt" not in result


class TestEnumSerialization:
    """Test that enums serialize to canonical wire values."""

    def test_glucose_type_values(self):
        for gt in GlucoseType:
            data = GlucoseLoggedData(
                user_id="u1",
                date="2025-01-27",
                glucose_type=gt,
                glucose_reading=100,
                glucose_range=GlucoseRange.NORMAL,
                is_critical=False,
            )
            result = data.to_dict()
            assert result["type"] == gt.value
            assert isinstance(result["type"], int)

    def test_workout_status_values(self):
        for status in WorkoutStatus:
            exercise = ExerciseData(name="Test", status=status)
            result = exercise.to_dict()
            assert result["status"] == status.value
            assert isinstance(result["status"], int)


class TestVoiceCallAnalyticsData:
    def test_to_dict_required_fields(self):
        data = VoiceCallAnalyticsData(
            call_id="call-123",
            user_id="user-456",
            call_type="inbound",
            language="en",
            agent_name="HealthBot",
            is_new_user=False,
            is_user_initiated=True,
            initiated_at="2025-01-28T10:00:00Z",
            status="completed",
            welcome_completed=True,
            transcript=[{"role": "agent", "content": "Hello!"}],
            total_turns=5,
            usage_summary={"tokens": 150},
            timezone="America/New_York",
        )
        result = data.to_dict()

        assert result["callId"] == "call-123"
        assert result["userId"] == "user-456"
        assert result["callType"] == "inbound"
        assert result["language"] == "en"
        assert result["agentName"] == "HealthBot"
        assert result["isNewUser"] is False
        assert result["isUserInitiated"] is True
        assert result["initiatedAt"] == "2025-01-28T10:00:00Z"
        assert result["status"] == "completed"
        assert result["welcomeCompleted"] is True
        assert result["transcript"] == [{"role": "agent", "content": "Hello!"}]
        assert result["totalTurns"] == 5
        assert result["usageSummary"] == {"tokens": 150}
        assert result["timezone"] == "America/New_York"
        # Optional fields should not be present
        assert "answeredAt" not in result
        assert "endedAt" not in result
        assert "durationSeconds" not in result
        assert "scheduledTime" not in result
        assert "actions" not in result

    def test_to_dict_with_optional_fields(self):
        data = VoiceCallAnalyticsData(
            call_id="call-123",
            user_id="user-456",
            call_type="outbound",
            language="es",
            agent_name="HealthBot",
            is_new_user=True,
            is_user_initiated=False,
            initiated_at="2025-01-28T10:00:00Z",
            status="completed",
            welcome_completed=True,
            transcript=[],
            total_turns=10,
            usage_summary={},
            timezone="Europe/Madrid",
            answered_at="2025-01-28T10:00:05Z",
            ended_at="2025-01-28T10:15:00Z",
            duration_seconds=895,
            scheduled_time="2025-01-28T10:00:00Z",
            actions={"booking": {"confirmed": True}},
        )
        result = data.to_dict()

        assert result["answeredAt"] == "2025-01-28T10:00:05Z"
        assert result["endedAt"] == "2025-01-28T10:15:00Z"
        assert result["durationSeconds"] == 895
        assert result["scheduledTime"] == "2025-01-28T10:00:00Z"
        assert result["actions"] == {"booking": {"confirmed": True}}

    def test_json_serializable(self):
        data = VoiceCallAnalyticsData(
            call_id="call-789",
            user_id="user-789",
            call_type="inbound",
            language="en",
            agent_name="HealthBot",
            is_new_user=False,
            is_user_initiated=True,
            initiated_at="2025-01-28T10:00:00Z",
            status="in_progress",
            welcome_completed=False,
            transcript=None,
            total_turns=0,
            usage_summary=None,
            timezone="UTC",
        )
        json_str = json.dumps(data.to_dict())
        parsed = json.loads(json_str)

        assert parsed["callId"] == "call-789"
        assert parsed["userId"] == "user-789"
        assert parsed["totalTurns"] == 0

    def test_camel_case_field_names(self):
        data = VoiceCallAnalyticsData(
            call_id="call-123",
            user_id="user-456",
            call_type="inbound",
            language="en",
            agent_name="HealthBot",
            is_new_user=False,
            is_user_initiated=True,
            initiated_at="2025-01-28T10:00:00Z",
            status="completed",
            welcome_completed=True,
            transcript=[],
            total_turns=5,
            usage_summary={},
            timezone="UTC",
            answered_at="2025-01-28T10:00:05Z",
            duration_seconds=300,
        )
        result = data.to_dict()

        # Verify camelCase
        assert "callId" in result
        assert "userId" in result
        assert "callType" in result
        assert "agentName" in result
        assert "isNewUser" in result
        assert "isUserInitiated" in result
        assert "initiatedAt" in result
        assert "welcomeCompleted" in result
        assert "totalTurns" in result
        assert "usageSummary" in result
        assert "answeredAt" in result
        assert "durationSeconds" in result

        # Verify no snake_case
        assert "call_id" not in result
        assert "user_id" not in result
        assert "call_type" not in result
        assert "agent_name" not in result
        assert "is_new_user" not in result
        assert "is_user_initiated" not in result
        assert "initiated_at" not in result
        assert "welcome_completed" not in result
        assert "total_turns" not in result
        assert "usage_summary" not in result
        assert "answered_at" not in result
        assert "duration_seconds" not in result
