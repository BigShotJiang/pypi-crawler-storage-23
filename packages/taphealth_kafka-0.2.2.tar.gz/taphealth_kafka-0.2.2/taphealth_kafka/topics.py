from __future__ import annotations

import warnings
from enum import Enum


class Topics(str, Enum):
    """
    Enum containing all available Kafka topic names in the TapHealth ecosystem.

    Each enum value maps to a Kafka topic string. Use these constants when
    implementing producers and consumers to ensure consistency across services.

    Topics are automatically created by KafkaClient on connection.

    Examples:
        >>> Topics.GLUCOSE_LOGGED.value
        'glucose-logged'
        >>>
        >>> class MyProducer(KafkaProducer):
        ...     @property
        ...     def topic(self) -> Topics:
        ...         return Topics.GLUCOSE_LOGGED
    """

    WEEKLY_PLAN_CREATED = "weekly-plan-created"
    """Weekly health plan creation event."""

    UPDATE_WEEKLY_NUTRITION_PLAN = "update-weekly-nutrition-plan"
    """Weekly nutrition plan update event."""

    UPDATE_WEEKLY_PLAN = "update-weekly-plan"
    """General weekly plan update event."""

    CONVERSATION_SUMMARY = "conversation-summary"
    """AI conversation summary event."""

    PROFILE_UPDATED = "profile-updated"
    """User profile update event. See ProfileUpdatedData in events."""

    DAILY_PLAN_CREATED = "daily-plan-created"
    """Daily plan creation event. See DailyPlanCreatedData in events."""

    DIET_CREATED = "diet-created"
    """Diet plan creation event. See DietCreatedData in events."""

    EXERCISE_LOGGED = "exercise-logged"
    """Exercise logging event. See ExerciseLoggedData in events."""

    GLUCOSE_LOGGED = "glucose-logged"
    """Glucose reading logging event. See GlucoseLoggedData in events."""

    MEAL_LOGGED = "meal-logged"
    """Meal logging event. See MealLoggedData in events."""

    METRIC_LOGGED = "metric-logged"
    """Health metric logging event. See MetricLoggedData in events."""

    VOICE_ANALYTICS = "voice-analytics"
    """Voice conversation analytics event."""

    PLAN_UPDATE = "plan-update"
    """Plan update command event with trigger and guidelines context."""

    PLAN_UPDATED = "plan-updated"
    """Plan update event with trigger and guidelines context."""

    @classmethod
    def get_all_topics(cls) -> list[str]:
        """
        Get a list of all topic string values.

        Returns:
            list[str]: List of all Kafka topic names.

        Examples:
            >>> Topics.get_all_topics()
            ['weekly-plan-created', 'update-weekly-nutrition-plan', ...]
        """
        return [topic.value for topic in cls]


# Backward-compatible alias for the old misspelled name.
# Deprecated: use UPDATE_WEEKLY_NUTRITION_PLAN instead.
_DEPRECATED_ALIAS = "UPDATE_WEEEKLY_NUTRTION_PLAN"


def __getattr__(name: str):
    if name == _DEPRECATED_ALIAS:
        warnings.warn(
            f"Topics.{_DEPRECATED_ALIAS} is deprecated due to typos. Use Topics.UPDATE_WEEKLY_NUTRITION_PLAN instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return Topics.UPDATE_WEEKLY_NUTRITION_PLAN
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
