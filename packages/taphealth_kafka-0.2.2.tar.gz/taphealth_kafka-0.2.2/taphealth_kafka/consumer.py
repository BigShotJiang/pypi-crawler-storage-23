from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from typing import Any

from .client import KafkaClient
from .topics import Topics

logger = logging.getLogger(__name__)


class KafkaConsumer(ABC):
    """
    Abstract base class for Kafka consumers.

    This class provides a high-level interface for consuming messages from Kafka topics.
    Subclasses must implement three abstract properties/methods:
    - topic: Specifies which topic to consume from
    - group_id: Defines the consumer group for coordinated consumption
    - on_message: Handles processing of each received message

    Messages are automatically deserialized from JSON before being passed to on_message().

    Subclasses may override ``consumer_config`` to customize auto_offset_reset,
    enable_auto_commit, or other consumer settings.

    Attributes:
        client (KafkaClient): KafkaClient instance managing the connection.

    Examples:
        >>> class GlucoseConsumer(KafkaConsumer):
        ...     @property
        ...     def topic(self) -> Topics:
        ...         return Topics.GLUCOSE_LOGGED
        ...
        ...     @property
        ...     def group_id(self) -> str:
        ...         return "glucose-processor"
        ...
        ...     def on_message(self, data: dict, message) -> None:
        ...         print(f"Processing: {data}")
        ...
        >>> consumer = GlucoseConsumer(kafka_client)
        >>> consumer.consume()  # Blocking call
    """

    def __init__(self, client: KafkaClient) -> None:
        """
        Initialize the consumer with a KafkaClient instance.

        Args:
            client (KafkaClient): KafkaClient instance that manages the Kafka connection.
        """
        self.client = client

    @property
    @abstractmethod
    def topic(self) -> Topics:
        """
        Abstract property that must return the topic to consume from.

        Returns:
            Topics: The Topics enum value for this consumer.

        Examples:
            >>> @property
            ... def topic(self) -> Topics:
            ...     return Topics.MEAL_LOGGED
        """
        pass

    @property
    @abstractmethod
    def group_id(self) -> str:
        """
        Abstract property that must return the consumer group ID.

        The consumer group ID is used to coordinate message consumption across
        multiple consumer instances. Consumers in the same group share the load
        of processing messages from the topic.

        Returns:
            str: Consumer group identifier.

        Examples:
            >>> @property
            ... def group_id(self) -> str:
            ...     return "meal-processor-group"
        """
        pass

    @abstractmethod
    def on_message(self, data: Any, message: Any) -> None:
        """
        Abstract method that handles processing of each received message.

        This method is called for each message successfully received and deserialized
        from the Kafka topic. Implement your business logic here.

        Args:
            data (Any): Deserialized message data (typically a dict from JSON).
            message (Any): Raw Confluent-kafka Message object with metadata
                (partition, offset, timestamp, etc.).

        Examples:
            >>> def on_message(self, data: dict, message) -> None:
            ...     user_id = data.get("userId")
            ...     print(f"Processing event for user: {user_id}")
            ...     # Your business logic here
        """
        pass

    @property
    def consumer_config(self) -> dict[str, Any]:
        """
        Consumer configuration passed to ``create_consumer()``.

        Override this property in subclasses to customize consumer settings
        such as ``auto_offset_reset`` or ``enable_auto_commit``.

        Returns:
            Dict[str, Any]: Configuration dict with snake_case keys.

        Examples:
            >>> @property
            ... def consumer_config(self) -> dict:
            ...     return {"auto_offset_reset": "latest", "enable_auto_commit": False}
        """
        return {
            "auto_offset_reset": "earliest",
            "enable_auto_commit": True,
        }

    def ensure_topics_exist(self) -> None:
        """
        Ensure that the topic this consumer subscribes to exists.

        Called automatically before starting consumption to verify/create the topic.
        """
        self.client.create_topics([self.topic.value])
        logger.info("Ensured topic %s exists.", self.topic.value)

    def consume(self) -> None:
        """
        Start consuming messages from the configured topic.

        This is a blocking method that continuously polls for messages and processes
        them via the on_message() callback. The method runs until interrupted by
        KeyboardInterrupt (Ctrl+C) or an unhandled exception occurs.

        The consumer automatically:
        - Ensures the topic exists
        - Subscribes to the topic
        - Polls for messages with 1-second timeout
        - Deserializes JSON messages
        - Calls on_message() for each valid message
        - Handles graceful shutdown

        Raises:
            Exception: Re-raised after logging if an error occurs during consumption.

        Examples:
            >>> consumer = MyConsumer(kafka_client)
            >>> consumer.consume()  # Blocks until interrupted
        """
        self.ensure_topics_exist()
        consumer = self.client.create_consumer(
            group_id=self.group_id,
            **self.consumer_config,
        )

        consumer.subscribe([self.topic.value])
        logger.info("Started consuming from topic %s", self.topic.value)

        try:
            while True:
                # Poll for messages with 1 second timeout
                message = consumer.poll(timeout=1.0)

                if message is None:
                    # No message received within timeout
                    continue

                if message.error():
                    logger.error("Consumer error: %s", message.error())
                    continue

                # Deserialize the message value
                try:
                    raw_value = message.value()
                    data = json.loads(raw_value.decode("utf-8")) if raw_value is not None else None
                except json.JSONDecodeError as e:
                    logger.error("Failed to decode message: %s", e)
                    continue

                logger.info(
                    "Received message on topic %s and partition %s",
                    self.topic.value,
                    message.partition(),
                )
                self.on_message(data, message)

        except KeyboardInterrupt:
            logger.info("Stopping consumer due to keyboard interrupt")
        except Exception as e:
            logger.error("Error consuming message: %s", e)
            raise
        finally:
            consumer.close()
            logger.info("Consumer closed")
