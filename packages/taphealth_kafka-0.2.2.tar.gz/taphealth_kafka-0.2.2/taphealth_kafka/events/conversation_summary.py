from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..serialization import dataclass_from_dict, dataclass_to_dict


@dataclass
class ConversationSummaryData:
    """
    Data structure for conversation summary events.

    Represents an AI-generated summary of a user conversation with timestamps.
    Used with the CONVERSATION_SUMMARY topic.

    Attributes:
        user_id (str): Unique identifier for the user.
        summary (str): AI-generated summary of the conversation.
        conversation_id (str): Unique identifier for the conversation.
        started_at (str): Conversation start timestamp in ISO 8601 format.
        ended_at (str): Conversation end timestamp in ISO 8601 format.

    Examples:
        >>> from taphealth_kafka.events import ConversationSummaryData
        >>> data = ConversationSummaryData(
        ...     user_id="user-123",
        ...     summary="User discussed meal planning and glucose targets...",
        ...     conversation_id="conv-456",
        ...     started_at="2025-01-28T10:00:00Z",
        ...     ended_at="2025-01-28T10:15:00Z"
        ... )
        >>> producer.send(data.to_dict())
    """

    user_id: str
    summary: str
    conversation_id: str
    started_at: str
    ended_at: str

    def to_dict(self) -> dict[str, Any]:
        """
        Convert to camelCase dictionary for Kafka message serialization.

        Returns:
            Dict[str, Any]: Dictionary with camelCase field names suitable for JSON serialization.
        """
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ConversationSummaryData:
        return dataclass_from_dict(cls, data)
