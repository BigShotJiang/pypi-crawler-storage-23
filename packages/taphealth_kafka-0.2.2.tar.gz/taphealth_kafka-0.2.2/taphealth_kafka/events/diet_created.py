from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..serialization import dataclass_from_dict, dataclass_to_dict
from .types import MealComponent


@dataclass
class GeneratedMeal:
    """
    Data structure for a generated meal plan.

    Attributes:
        components (Optional[List[MealComponent]]): List of meal components with nutritional info.
    """

    components: list[MealComponent] | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GeneratedMeal:
        return dataclass_from_dict(cls, data)


@dataclass
class MealData:
    """
    Data structure for individual meal details in a diet plan.

    Attributes:
        date (str): Date of the meal in ISO format (YYYY-MM-DD).
        meal_type (str): Type of meal (breakfast, lunch, dinner, snack).
        meal_time (Optional[str]): Scheduled time for the meal.
        rationale (Optional[str]): Explanation for meal selection or adjustments.
        generated (Optional[GeneratedMeal]): Generated meal plan details with components.
    """

    date: str
    meal_type: str
    meal_time: str | None = None
    rationale: str | None = None
    generated: GeneratedMeal | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MealData:
        return dataclass_from_dict(cls, data)


@dataclass
class DietCreatedData:
    """
    Data structure for diet plan creation events.

    Represents a generated diet plan with scheduled meals. Used with the DIET_CREATED topic.

    Attributes:
        user_id (str): Unique identifier for the user.
        scheduled_date (str): Start date for the diet plan in ISO format (YYYY-MM-DD).
        meals (List[MealData]): List of scheduled meals in the diet plan.

    Examples:
        >>> from taphealth_kafka.events import DietCreatedData, MealData
        >>> data = DietCreatedData(
        ...     user_id="user-123",
        ...     scheduled_date="2025-01-28",
        ...     meals=[MealData(date="2025-01-28", meal_type="breakfast")]
        ... )
        >>> producer.send(data.to_dict())
    """

    user_id: str
    scheduled_date: str
    meals: list[MealData]

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DietCreatedData:
        return dataclass_from_dict(cls, data)
