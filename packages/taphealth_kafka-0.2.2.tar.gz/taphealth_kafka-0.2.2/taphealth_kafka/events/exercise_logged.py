from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..serialization import dataclass_from_dict, dataclass_to_dict
from .types import WorkoutStatus


@dataclass
class ExerciseData:
    """
    Data structure for individual exercise activity details.

    Attributes:
        name (str): Name of the exercise activity.
        date (Optional[str]): Date when the exercise was performed in ISO format (YYYY-MM-DD).
        duration (Optional[int]): Duration of the exercise in minutes.
        calories_burnt (Optional[int]): Estimated calories burned during the exercise.
        status (Optional[WorkoutStatus]): Completion status of the workout.
    """

    name: str
    date: str | None = None
    duration: int | None = None
    calories_burnt: int | None = None
    status: WorkoutStatus | None = None

    def to_dict(self) -> dict[str, Any]:
        """
        Convert to camelCase dictionary for Kafka message serialization.

        Returns:
            Dict[str, Any]: Dictionary with camelCase field names suitable for JSON serialization.
        """
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ExerciseData:
        return dataclass_from_dict(cls, data)


@dataclass
class ExerciseLoggedData:
    """
    Data structure for exercise logging events.

    Represents one or more exercise activities logged by a user. Used with the
    EXERCISE_LOGGED topic.

    Attributes:
        user_id (str): Unique identifier for the user.
        logged_at (str): Timestamp when the exercises were logged in ISO 8601 format.
        exercises (List[ExerciseData]): List of exercise activities in this log entry.
        timezone (Optional[str]): IANA timezone identifier (e.g., "America/New_York").

    Examples:
        >>> from taphealth_kafka.events import ExerciseLoggedData, ExerciseData, WorkoutStatus
        >>> data = ExerciseLoggedData(
        ...     user_id="user-123",
        ...     logged_at="2025-01-28T10:30:00Z",
        ...     exercises=[
        ...         ExerciseData(
        ...             name="Running",
        ...             date="2025-01-28",
        ...             duration=30,
        ...             calories_burnt=250,
        ...             status=WorkoutStatus.COMPLETE
        ...         )
        ...     ],
        ...     timezone="UTC"
        ... )
        >>> producer.send(data.to_dict())
    """

    user_id: str
    logged_at: str
    exercises: list[ExerciseData]
    timezone: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """
        Convert to camelCase dictionary for Kafka message serialization.

        Returns:
            Dict[str, Any]: Dictionary with camelCase field names suitable for JSON serialization.
        """
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ExerciseLoggedData:
        return dataclass_from_dict(cls, data)
