from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..serialization import dataclass_from_dict, dataclass_to_dict
from .types import DailyTask


@dataclass
class NudgeContext:
    summary: str
    log_patterns: list[str]
    plan_summary: str

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NudgeContext:
        return dataclass_from_dict(cls, data)


@dataclass
class Nudge:
    module: str
    time: str
    priority: int
    channel: str
    context: NudgeContext
    name: str

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Nudge:
        return dataclass_from_dict(cls, data)


@dataclass
class NudgePlan:
    day_number: int
    date: str
    user_id: str
    plan_summary: str
    nudges: list[Nudge]
    warnings: list[str]

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NudgePlan:
        return dataclass_from_dict(cls, data)


@dataclass
class TargetMacros:
    protein: float
    carbs: float
    fats: float
    fibre: float

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TargetMacros:
        return dataclass_from_dict(cls, data)


@dataclass
class TargetCalorieDistribution:
    carbs: float
    protein: float
    fat: float
    fibre: float

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TargetCalorieDistribution:
        return dataclass_from_dict(cls, data)


@dataclass
class NutritionPlan:
    target_calories: float
    target_macros: TargetMacros
    target_calorie_distribution: TargetCalorieDistribution

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NutritionPlan:
        return dataclass_from_dict(cls, data)


@dataclass
class GlucosePlan:
    fasting: bool
    postprandial: bool
    night: bool
    pre_workout: bool

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GlucosePlan:
        return dataclass_from_dict(cls, data)


@dataclass
class ExercisePlan:
    duration: int
    type: str
    intensity: str

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ExercisePlan:
        return dataclass_from_dict(cls, data)


@dataclass
class ActivityPlan:
    steps: int
    exercise: ExercisePlan | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ActivityPlan:
        return dataclass_from_dict(cls, data)


@dataclass
class EducationPlan:
    topic: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> EducationPlan:
        return dataclass_from_dict(cls, data)


@dataclass
class DailyPlan:
    nutrition: NutritionPlan
    glucose: GlucosePlan
    activity: ActivityPlan
    education: EducationPlan | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DailyPlan:
        return dataclass_from_dict(cls, data)


@dataclass
class DailyPlanCreatedData:
    """
    Data structure for daily plan creation events.

    Represents a comprehensive daily health plan including nutrition targets,
    glucose monitoring schedule, activity goals, educational content, tasks,
    and personalized nudges. Used with the DAILY_PLAN_CREATED topic.

    Attributes:
        user_id (str): Unique identifier for the user.
        timezone (str): IANA timezone identifier (e.g., "America/New_York").
        date (str): Date of the plan in ISO format (YYYY-MM-DD).
        tasks (Dict[str, List[DailyTask]]): Tasks organized by module.
        nudge_plan (NudgePlan): Scheduled nudges/notifications for the day.
        plan (DailyPlan): Comprehensive daily health plan with nutrition, glucose,
            activity, and education components.

    Examples:
        >>> from taphealth_kafka.events import DailyPlanCreatedData
        >>> data = DailyPlanCreatedData(
        ...     user_id="user-123",
        ...     timezone="UTC",
        ...     date="2025-01-28",
        ...     tasks={},
        ...     nudge_plan=nudge_plan_obj,
        ...     plan=daily_plan_obj
        ... )
        >>> producer.send(data.to_dict())
    """

    user_id: str
    timezone: str
    date: str
    tasks: dict[str, list[DailyTask]]
    nudge_plan: NudgePlan
    plan: DailyPlan

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DailyPlanCreatedData:
        return dataclass_from_dict(cls, data)
