from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..serialization import dataclass_from_dict, dataclass_to_dict
from .types import MetricType


@dataclass
class MetricLoggedData:
    """
    Data structure for health metric logging events.

    Represents a logged health metric measurement such as weight, blood pressure,
    heart rate, etc. Used with the METRIC_LOGGED topic.

    Attributes:
        user_id (str): Unique identifier for the user.
        date (str): Date of the metric reading in ISO format (YYYY-MM-DD).
        metric_type (MetricType): Type of health metric being logged.
        value (float): Numerical value of the metric.
        timezone (Optional[str]): IANA timezone identifier (e.g., "America/New_York").

    Examples:
        >>> from taphealth_kafka.events import MetricLoggedData, MetricType
        >>> data = MetricLoggedData(
        ...     user_id="user-123",
        ...     date="2025-01-28",
        ...     metric_type=MetricType.WEIGHT,
        ...     value=75.5,
        ...     timezone="UTC"
        ... )
        >>> producer.send(data.to_dict())
    """

    user_id: str
    date: str
    metric_type: MetricType
    value: float
    timezone: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """
        Convert to camelCase dictionary for Kafka message serialization.

        Returns:
            Dict[str, Any]: Dictionary with camelCase field names suitable for JSON serialization.
        """
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MetricLoggedData:
        return dataclass_from_dict(cls, data)
