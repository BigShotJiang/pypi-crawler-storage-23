from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ...serialization import dataclass_from_dict, dataclass_to_dict


@dataclass
class GlucoseSchedule:
    fasting: int | None = None
    post_lunch: int | None = None
    bedtime: int | None = None
    post_exercise: bool | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GlucoseSchedule:
        return dataclass_from_dict(cls, data)


@dataclass
class PersonalSettings:
    weight: str
    height: str
    exercise_level: int | None = None
    workout_days: list[str] | None = None
    glucose_schedule: GlucoseSchedule | None = None
    target_steps: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PersonalSettings:
        return dataclass_from_dict(cls, data)


@dataclass
class LifeStyleRoutineSettings:
    current_family_structure: str
    employment_status: str
    work_type: str
    work_timings: str
    post_work_routine: str
    sleep_start_time: str
    sleep_end_time: str
    sleep_quality: str

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LifeStyleRoutineSettings:
        return dataclass_from_dict(cls, data)


@dataclass
class MedicalSettings:
    medical_conditions: list[str]
    recent_surgery: bool

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MedicalSettings:
        return dataclass_from_dict(cls, data)


@dataclass
class DietSettings:
    diet_reason: str
    activity_level: str
    allergies: list[str]
    diet_type: str
    cuisine_preferences: list[str]
    pulses: list[str]
    grains: list[str]
    vegetables: list[str]
    non_veg_preferences: list[str]
    non_veg_days: list[str]
    medications: list[str]
    staple_preference: str
    calorie_intake: int | None = None
    breakfast_preference: list[str] | None = None
    lunch_preference: list[str] | None = None
    dinner_preference: list[str] | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DietSettings:
        return dataclass_from_dict(cls, data)


@dataclass
class GoalTarget:
    type: str | None = None
    value: float | None = None
    months: int | None = None
    reduction: float | None = None
    date: str | None = None
    pace: str | None = None
    start_value: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GoalTarget:
        return dataclass_from_dict(cls, data)


@dataclass
class DiabetesSettings:
    program_reason: list[str]
    motivation: list[str]
    goal: list[str]
    barriers: list[str]
    cravings: list[str]
    diagnosis_date: str
    sugar_fasting_level: str
    sugar_fasting_checked_date: str
    sugar_post_meal_level: str
    sugar_post_meal_checked_date: str
    hba1c_level: str
    hba1c_checked_date: str
    history: list[str]
    diabetes_in_family: bool
    medications: list[str]
    program_pace: str
    coach_type: str
    diabetes_type: str
    low_blood_sugar_experience: bool
    high_blood_sugar_experience: bool
    diabetes_medication_changes: bool
    comorbidities: list[str]
    notification_preference: str | None = None
    primary_goal: str | None = None
    secondary_goals: list[str] | None = None
    goal_target: GoalTarget | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DiabetesSettings:
        return dataclass_from_dict(cls, data)


@dataclass
class Settings:
    personal: PersonalSettings
    diet: DietSettings
    lifestyle_routine: LifeStyleRoutineSettings
    medical: MedicalSettings
    diabetes: DiabetesSettings
    tags: list[str] = field(default_factory=list)
    timezone: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Settings:
        return dataclass_from_dict(cls, data)
