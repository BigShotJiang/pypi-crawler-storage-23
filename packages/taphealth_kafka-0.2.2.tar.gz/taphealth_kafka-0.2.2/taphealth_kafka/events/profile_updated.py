from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..serialization import dataclass_from_dict, dataclass_to_dict
from .types import Settings

_PROFILE_KEY_OVERRIDES = {
    "shared_on_whatsapp": "sharedOnWhatsApp",
    "shared_on_sms": "sharedOnSMS",
}


@dataclass
class ProfileUpdatedData:
    """
    Data structure for user profile update events.

    Represents changes to user profile information including personal details,
    health conditions, and user settings. Used with the PROFILE_UPDATED topic.

    All fields except 'id' are optional to support partial updates.

    Attributes:
        id (str): Unique profile identifier.
        user_id (Optional[str]): User account identifier.
        patient_id (Optional[str]): Patient record identifier.
        name (Optional[str]): User's full name.
        relation (Optional[str]): Relationship to primary user (for caregivers).
        gender (Optional[str]): User's gender.
        age (Optional[int]): User's age in years.
        location (Optional[str]): User's location.
        email (Optional[str]): User's email address.
        device_id (Optional[str]): Associated device identifier.
        profile_completed (Optional[bool]): Whether profile setup is complete.
        smoking (Optional[bool]): Smoking status.
        drinking (Optional[bool]): Alcohol consumption status.
        pregnancy (Optional[bool]): Pregnancy status.
        diabetes (Optional[bool]): Diabetes diagnosis status.
        hypertension (Optional[bool]): Hypertension diagnosis status.
        follow_symptom (Optional[bool]): Symptom tracking enabled.
        meta_question (Optional[bool]): Meta question participation status.
        shared_on_whatsapp (Optional[bool]): WhatsApp sharing status.
        registered_on_meradoc (Optional[bool]): Meradoc registration status.
        shared_on_sms (Optional[bool]): SMS sharing status.
        share_count (Optional[int]): Number of profile shares.
        preferred_language (Optional[str]): User's preferred language code.
        created_at (Optional[str]): Profile creation timestamp in ISO 8601 format.
        updated_at (Optional[str]): Last update timestamp in ISO 8601 format.
        dtx_onboarding_completed (Optional[bool]): DTX onboarding completion status.
        free_onboarding_completed (Optional[bool]): Free tier onboarding completion status.
        settings (Optional[Settings]): Detailed user settings object.
        onboarding_date (Optional[str]): Onboarding completion date.

    Examples:
        >>> from taphealth_kafka.events import ProfileUpdatedData
        >>> data = ProfileUpdatedData(
        ...     id="profile-123",
        ...     user_id="user-123",
        ...     name="John Doe",
        ...     age=45,
        ...     diabetes=True
        ... )
        >>> producer.send(data.to_dict())
    """

    id: str
    user_id: str | None = None
    patient_id: str | None = None
    name: str | None = None
    relation: str | None = None
    gender: str | None = None
    age: int | None = None
    location: str | None = None
    email: str | None = None
    device_id: str | None = None
    profile_completed: bool | None = None
    smoking: bool | None = None
    drinking: bool | None = None
    pregnancy: bool | None = None
    diabetes: bool | None = None
    hypertension: bool | None = None
    follow_symptom: bool | None = None
    meta_question: bool | None = None
    shared_on_whatsapp: bool | None = None
    registered_on_meradoc: bool | None = None
    shared_on_sms: bool | None = None
    share_count: int | None = None
    preferred_language: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    dtx_onboarding_completed: bool | None = None
    free_onboarding_completed: bool | None = None
    settings: Settings | None = None
    onboarding_date: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self, key_overrides=_PROFILE_KEY_OVERRIDES)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProfileUpdatedData:
        return dataclass_from_dict(cls, data, key_overrides=_PROFILE_KEY_OVERRIDES)
