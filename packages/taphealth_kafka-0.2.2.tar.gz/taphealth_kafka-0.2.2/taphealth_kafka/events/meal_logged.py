from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..serialization import dataclass_from_dict, dataclass_to_dict
from .types import MealComponent, MealVariation


@dataclass
class FeedbackBreakdown:
    item: str
    type: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> FeedbackBreakdown:
        return dataclass_from_dict(cls, data)


@dataclass
class MealFeedback:
    meal_score: int
    flags: Any
    breakdown: list[FeedbackBreakdown]

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MealFeedback:
        return dataclass_from_dict(cls, data)


@dataclass
class LoggedMeal:
    components: list[MealComponent]
    feedback: MealFeedback

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LoggedMeal:
        return dataclass_from_dict(cls, data)


@dataclass
class MealLoggedData:
    """
    Data structure for meal logging events.

    Represents a logged meal with components, nutritional feedback, and variations.
    Used with the MEAL_LOGGED topic.

    Attributes:
        user_id (str): Unique identifier for the user.
        date (str): Date of the meal in ISO format (YYYY-MM-DD).
        meal_type (str): Type of meal (breakfast, lunch, dinner, snack).
        logged_at (str): Timestamp when the meal was logged in ISO 8601 format.
        logged_meal (LoggedMeal): Logged meal details with components and feedback.
        had_generated_meal (Optional[bool]): Whether the user had a generated meal plan.
        logged_variation (Optional[MealVariation]): Difficulty variation logged (EASY, MODERATE, CHALLENGING).

    Examples:
        >>> from taphealth_kafka.events import MealLoggedData, LoggedMeal
        >>> data = MealLoggedData(
        ...     user_id="user-123",
        ...     date="2025-01-28",
        ...     meal_type="breakfast",
        ...     logged_at="2025-01-28T08:30:00Z",
        ...     logged_meal=logged_meal_obj
        ... )
        >>> producer.send(data.to_dict())
    """

    user_id: str
    date: str
    meal_type: str
    logged_at: str
    logged_meal: LoggedMeal
    had_generated_meal: bool | None = None
    logged_variation: MealVariation | None = None

    def to_dict(self) -> dict[str, Any]:
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MealLoggedData:
        return dataclass_from_dict(cls, data)
