from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..serialization import dataclass_from_dict, dataclass_to_dict


@dataclass
class VoiceCallAnalyticsData:
    """
    Data structure for voice call analytics events.

    Represents analytics data for a voice conversation including call metadata,
    transcript, and usage summary. Used with the VOICE_ANALYTICS topic.

    Attributes:
        call_id (str): Unique identifier for the call.
        user_id (str): Unique identifier for the user.
        call_type (str): Type of the call (e.g., "inbound", "outbound").
        language (str): Language used in the call.
        agent_name (str): Name of the AI agent handling the call.
        is_new_user (bool): Whether this is a new user.
        is_user_initiated (bool): Whether the user initiated the call.
        initiated_at (str): Call initiation timestamp in ISO 8601 format.
        status (str): Current status of the call.
        welcome_completed (bool): Whether the welcome message was completed.
        transcript (Any): Transcript data for the call.
        total_turns (int): Total number of conversation turns.
        usage_summary (Any): Usage summary data for the call.
        timezone (str): Timezone of the call.
        answered_at (Optional[str]): When the call was answered, ISO 8601 format.
        ended_at (Optional[str]): When the call ended, ISO 8601 format.
        duration_seconds (Optional[int]): Duration of the call in seconds.
        scheduled_time (Optional[str]): Scheduled time for the call, ISO 8601 format.
        actions (Optional[Dict[str, Any]]): Actions taken during the call.

    Examples:
        >>> from taphealth_kafka.events import VoiceCallAnalyticsData
        >>> data = VoiceCallAnalyticsData(
        ...     call_id="call-123",
        ...     user_id="user-456",
        ...     call_type="inbound",
        ...     language="en",
        ...     agent_name="HealthBot",
        ...     is_new_user=False,
        ...     is_user_initiated=True,
        ...     initiated_at="2025-01-28T10:00:00Z",
        ...     status="completed",
        ...     welcome_completed=True,
        ...     transcript=[{"role": "agent", "content": "Hello!"}],
        ...     total_turns=5,
        ...     usage_summary={"tokens": 150},
        ...     timezone="America/New_York",
        ... )
        >>> producer.send(data.to_dict())
    """

    call_id: str
    user_id: str
    call_type: str
    language: str
    agent_name: str
    is_new_user: bool
    is_user_initiated: bool
    initiated_at: str
    status: str
    welcome_completed: bool
    transcript: Any
    total_turns: int
    usage_summary: Any
    timezone: str
    answered_at: str | None = None
    ended_at: str | None = None
    duration_seconds: int | None = None
    scheduled_time: str | None = None
    actions: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """
        Convert to camelCase dictionary for Kafka message serialization.

        Returns:
            Dict[str, Any]: Dictionary with camelCase field names suitable for JSON serialization.
        """
        return dataclass_to_dict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> VoiceCallAnalyticsData:
        return dataclass_from_dict(cls, data)
