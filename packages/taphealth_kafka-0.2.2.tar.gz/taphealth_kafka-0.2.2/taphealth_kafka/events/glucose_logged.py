from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..serialization import dataclass_from_dict, dataclass_to_dict
from .types import GlucoseRange, GlucoseType

_GLUCOSE_KEY_OVERRIDES = {"glucose_type": "type"}


@dataclass
class GlucoseLoggedData:
    """
    Data structure for glucose reading logging events.

    Represents a glucose measurement event with type, reading value, range classification,
    and criticality indicator. Used with the GLUCOSE_LOGGED topic.

    Attributes:
        user_id (str): Unique identifier for the user.
        date (str): Date of the glucose reading in ISO format (YYYY-MM-DD).
        glucose_type (GlucoseType): Type of glucose reading (FASTING, PRE_LUNCH, etc.).
        glucose_reading (float): Glucose level measurement in mg/dL.
        glucose_range (GlucoseRange): Classification of the reading (LOW, NORMAL, HIGH, etc.).
        is_critical (bool): Whether the reading is in a critical range requiring attention.
        timezone (Optional[str]): IANA timezone identifier (e.g., "America/New_York").

    Examples:
        >>> from taphealth_kafka.events import GlucoseLoggedData, GlucoseType, GlucoseRange
        >>> data = GlucoseLoggedData(
        ...     user_id="user-123",
        ...     date="2025-01-28",
        ...     glucose_type=GlucoseType.FASTING,
        ...     glucose_reading=105.0,
        ...     glucose_range=GlucoseRange.NORMAL,
        ...     is_critical=False,
        ...     timezone="UTC"
        ... )
        >>> producer.send(data.to_dict())
    """

    user_id: str
    date: str
    glucose_type: GlucoseType
    glucose_reading: float
    glucose_range: GlucoseRange
    is_critical: bool
    timezone: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """
        Convert to camelCase dictionary for Kafka message serialization.

        Returns:
            Dict[str, Any]: Dictionary with camelCase field names suitable for JSON serialization.
        """
        return dataclass_to_dict(self, key_overrides=_GLUCOSE_KEY_OVERRIDES)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GlucoseLoggedData:
        return dataclass_from_dict(cls, data, key_overrides=_GLUCOSE_KEY_OVERRIDES)
