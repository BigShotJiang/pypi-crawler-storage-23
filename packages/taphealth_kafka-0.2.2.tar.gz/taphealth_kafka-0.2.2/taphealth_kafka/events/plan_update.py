from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from .types.plan import PlanUpdatedTrigger, PlanUpdateTarget


@dataclass
class PlanUpdateData:
    """
    Data structure for plan-update command events.

    Represents a request to update a plan triggered by lab reports, symptoms, or routine.
    Used with the PLAN_UPDATE topic.

    Mirrors the TypeScript interface in kafka/src/events/plan-update.ts.

    Attributes:
        user_id (str): Unique identifier for the user.
        trigger (PlanUpdatedTrigger): What triggered the plan update.
        guidelines (dict): Optional module-to-content mapping of guidelines.
    """

    user_id: str
    trigger: PlanUpdatedTrigger = PlanUpdatedTrigger.ROUTINE
    guidelines: Optional[Dict[str, str]] = field(default=None)
    target: Optional[PlanUpdateTarget] = field(default=None)

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to camelCase dictionary for Kafka message serialization.

        Returns:
            Dict[str, Any]: Dictionary with camelCase field names suitable for JSON serialization.
        """
        result: Dict[str, Any] = {
            "userId": self.user_id,
            "trigger": self.trigger.value,
        }
        if self.guidelines:
            result["guidelines"] = self.guidelines
        if self.target:
            result["target"] = self.target.value
        return result
