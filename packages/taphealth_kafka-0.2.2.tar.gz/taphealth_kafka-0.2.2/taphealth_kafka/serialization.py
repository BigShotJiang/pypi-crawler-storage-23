"""Serialization utilities for Kafka event dataclasses."""

from __future__ import annotations

import dataclasses
import typing
from enum import Enum
from typing import Any, TypeVar

T = TypeVar("T")


def _to_camel_case(name: str) -> str:
    """Convert snake_case to camelCase."""
    components = name.split("_")
    return components[0] + "".join(x.title() for x in components[1:])


def _serialize_value(value: Any) -> Any:
    """Recursively serialize a value for JSON output."""
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return dataclass_to_dict(value)
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, list):
        return [_serialize_value(item) for item in value]
    if isinstance(value, dict):
        return {k: _serialize_value(v) for k, v in value.items()}
    return value


def dataclass_to_dict(
    obj: Any,
    key_overrides: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Convert a dataclass instance to a camelCase dictionary.

    Recursively converts nested dataclasses, enums to their values,
    and skips None fields.

    Args:
        obj: A dataclass instance.
        key_overrides: Optional mapping of field_name -> custom_key
            for fields that don't follow standard camelCase conversion.

    Returns:
        Dictionary with camelCase keys and serialized values.

    Raises:
        TypeError: If obj is not a dataclass instance.
    """
    if not dataclasses.is_dataclass(obj) or isinstance(obj, type):
        raise TypeError(f"{type(obj)} is not a dataclass instance")

    overrides = key_overrides or {}
    result: dict[str, Any] = {}

    for f in dataclasses.fields(obj):
        value = getattr(obj, f.name)
        if value is None:
            continue
        key = overrides.get(f.name, _to_camel_case(f.name))
        result[key] = _serialize_value(value)

    return result


def _get_type_hints(cls: type) -> dict[str, Any]:
    """Get type hints, falling back to __annotations__ on failure."""
    try:
        return typing.get_type_hints(cls)
    except Exception:
        return getattr(cls, "__annotations__", {})


def _unwrap_optional(tp: Any) -> Any:
    """Unwrap Optional[X] to X."""
    origin = typing.get_origin(tp)
    if origin is typing.Union:
        args = typing.get_args(tp)
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1:
            return non_none[0]
    return tp


def _deserialize_value(value: Any, tp: Any) -> Any:
    """Deserialize a value based on its expected type."""
    if value is None:
        return None

    if tp is Any:
        return value

    tp = _unwrap_optional(tp)
    origin = typing.get_origin(tp)

    if origin is list:
        args = typing.get_args(tp)
        item_type = args[0] if args else Any
        return [_deserialize_value(item, item_type) for item in value]

    if origin is dict:
        args = typing.get_args(tp)
        val_type = args[1] if len(args) > 1 else Any
        return {k: _deserialize_value(v, val_type) for k, v in value.items()}

    if isinstance(tp, type) and issubclass(tp, Enum):
        return tp(value)

    if isinstance(tp, type) and dataclasses.is_dataclass(tp):
        if isinstance(value, dict):
            return dataclass_from_dict(tp, value)
        return value

    return value


def dataclass_from_dict(
    cls: type[T],
    data: dict[str, Any],
    key_overrides: dict[str, str] | None = None,
) -> T:
    """Construct a dataclass instance from a camelCase dictionary.

    Recursively deserializes nested dataclasses and enums.

    Args:
        cls: The dataclass type to construct.
        data: Dictionary with camelCase keys.
        key_overrides: Optional mapping of field_name -> custom_key
            (same overrides used in dataclass_to_dict).

    Returns:
        An instance of cls.

    Raises:
        TypeError: If cls is not a dataclass.
    """
    if not dataclasses.is_dataclass(cls):
        raise TypeError(f"{cls} is not a dataclass")

    overrides = key_overrides or {}
    hints = _get_type_hints(cls)
    kwargs: dict[str, Any] = {}

    for f in dataclasses.fields(cls):
        camel_key = overrides.get(f.name, _to_camel_case(f.name))
        if camel_key in data:
            tp = hints.get(f.name, Any)
            kwargs[f.name] = _deserialize_value(data[camel_key], tp)

    return cls(**kwargs)
