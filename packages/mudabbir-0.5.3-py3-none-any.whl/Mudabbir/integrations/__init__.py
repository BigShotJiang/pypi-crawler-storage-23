# Integrations package — OAuth, Gmail, Google Calendar, etc.
# Created: 2026-02-07
