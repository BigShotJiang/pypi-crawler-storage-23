"""Agents package for Mudabbir."""

from Mudabbir.agents.router import AgentRouter

__all__ = ["AgentRouter"]
