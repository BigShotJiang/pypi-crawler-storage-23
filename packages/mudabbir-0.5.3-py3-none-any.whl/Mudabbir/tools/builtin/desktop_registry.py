"""Registry/security placeholder groups for staged rollout."""

REGISTRY_ACTIONS: set[str] = {"registry_tools"}
