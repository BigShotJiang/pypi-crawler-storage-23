"""Audio/media action groups for DesktopTool."""

AUDIO_ACTIONS = {
    "volume",
    "media_control",
    "microphone_record",
}

