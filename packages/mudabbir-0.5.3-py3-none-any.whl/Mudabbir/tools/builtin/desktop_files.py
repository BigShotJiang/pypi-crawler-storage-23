"""File/navigation action groups for DesktopTool."""

FILE_ACTIONS = {
    "search_files",
    "move_mouse_to_desktop_file",
    "file_tools",
}
