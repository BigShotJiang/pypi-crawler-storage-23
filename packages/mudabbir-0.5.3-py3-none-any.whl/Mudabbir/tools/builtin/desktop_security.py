"""High-risk security actions placeholder for staged rollout."""

SECURITY_ACTIONS: set[str] = {"security_tools", "web_tools"}
