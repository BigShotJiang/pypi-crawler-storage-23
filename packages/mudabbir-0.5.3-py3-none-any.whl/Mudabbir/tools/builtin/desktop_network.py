"""Network-related action groups for DesktopTool."""

NETWORK_ACTIONS = {
    "bluetooth_control",
    "network_tools",
    "browser_control",
}
