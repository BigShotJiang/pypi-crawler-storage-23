### Running Web Interface
To run just type from the command line
```shell
streamlit run main.py
```

