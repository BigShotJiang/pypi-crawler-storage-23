# MediaWikiServerTools
MediaWiki Server Tools

[![pypi](https://img.shields.io/pypi/pyversions/MediaWikiServerTools)](https://pypi.org/project/MediaWikiServerTools/)
[![PyPI Status](https://img.shields.io/pypi/v/MediaWikiServerTools.svg)](https://pypi.python.org/pypi/MediaWikiServerTools/)
[![Github Actions Build](https://github.com/WolfgangFahl/MediaWikiServerTools/actions/workflows/build.yml/badge.svg)](https://github.com/WolfgangFahl/MediaWikiServerTools/actions/workflows/build.yml)
[![GitHub issues](https://img.shields.io/github/issues/WolfgangFahl/MediaWikiServerTools.svg)](https://github.com/WolfgangFahl/MediaWikiServerTools/issues)
[![GitHub closed issues](https://img.shields.io/github/issues-closed/WolfgangFahl/MediaWikiServerTools.svg)](https://github.com/WolfgangFahl/MediaWikiServerTools/issues/?q=is%3Aissue+is%3Aclosed)
[![API Docs](https://img.shields.io/badge/API-Documentation-blue)](https://WolfgangFahl.github.io/MediaWikiServerTools/)
[![License](https://img.shields.io/github/license/WolfgangFahl/MediaWikiServerTools.svg)](https://www.apache.org/licenses/LICENSE-2.0)

[![BITPlan](https://wiki.bitplan.com/images/wiki/thumb/3/38/BITPlanLogoFontLessTransparent.png/198px-BITPlanLogoFontLessTransparent.png)](https://www.bitplan.com)
