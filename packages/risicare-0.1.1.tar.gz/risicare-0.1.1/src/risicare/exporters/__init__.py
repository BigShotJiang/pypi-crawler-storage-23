"""
Span exporters for the Risicare SDK.

Exporters handle sending spans to various backends:
- ConsoleExporter: Local debugging output
- HttpExporter: Send to Risicare backend
- OTLPExporter: OpenTelemetry Protocol format (OTLP/HTTP JSON)
"""

from risicare.exporters.base import SpanExporter, ExportResult
from risicare.exporters.console import ConsoleExporter
from risicare.exporters.http import HttpExporter
from risicare.exporters.otlp import OTLPExporter

__all__ = [
    "SpanExporter",
    "ExportResult",
    "ConsoleExporter",
    "HttpExporter",
    "OTLPExporter",
]
