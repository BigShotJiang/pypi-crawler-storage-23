"""
Instrumentation for LLM providers and frameworks.

This package provides automatic instrumentation via import hooks:
- LLM providers (OpenAI, Anthropic, Cohere, Google, Mistral)
- Agent frameworks (via dedicated integration packages)

Usage:
    # Automatic via environment variable (Tier 0):
    RISICARE_TRACING=true python app.py

    # Programmatic:
    from risicare.instrumentation import install_import_hooks
    install_import_hooks()

    import openai  # Automatically instrumented
"""

from risicare.instrumentation.hooks import (
    RisicareImportFinder,
    get_instrumented_modules,
    get_supported_modules,
    install_import_hooks,
    instrument_already_imported,
    is_instrumented,
    remove_import_hooks,
)

__all__ = [
    "RisicareImportFinder",
    "install_import_hooks",
    "remove_import_hooks",
    "instrument_already_imported",
    "is_instrumented",
    "get_instrumented_modules",
    "get_supported_modules",
]


def _check_auto_instrumentation() -> None:
    """
    Check if auto-instrumentation should be enabled via environment.

    Called at module import time to support Tier 0 zero-code tracing.
    """
    import os

    tracing_enabled = os.environ.get("RISICARE_TRACING", "").lower() in (
        "true",
        "1",
        "yes",
        "on",
    )

    if tracing_enabled:
        # Install import hooks
        install_import_hooks()

        # Initialize the SDK if API key is present
        api_key = os.environ.get("RISICARE_API_KEY")
        if api_key:
            try:
                from risicare.client import init

                endpoint = os.environ.get("RISICARE_ENDPOINT")
                environment = os.environ.get("RISICARE_ENVIRONMENT", "production")
                service_name = os.environ.get("RISICARE_SERVICE_NAME", "default")

                init(
                    api_key=api_key,
                    endpoint=endpoint,
                    environment=environment,
                    service_name=service_name,
                )
            except Exception:
                pass  # SDK init failed, but hooks are still installed


# Check for auto-instrumentation on import
_check_auto_instrumentation()
