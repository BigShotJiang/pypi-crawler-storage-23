"""
threatmap module entry point.
"""
from threatmap.cli import main

if __name__ == "__main__":
    main()
