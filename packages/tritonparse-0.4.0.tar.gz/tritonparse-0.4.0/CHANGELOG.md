# Changelog

All notable changes to this project will be documented in this file.

For detailed release notes, see [GitHub Releases](https://github.com/meta-pytorch/tritonparse/releases).

## [0.3.2] - 2025-12-22
See [release notes](https://github.com/meta-pytorch/tritonparse/releases/tag/v0.3.2)

## [0.3.1] - 2025-11-03
See [release notes](https://github.com/meta-pytorch/tritonparse/releases/tag/v0.3.1)

## [0.3.0] - 2025-10-14
See [release notes](https://github.com/meta-pytorch/tritonparse/releases/tag/v0.3.0)

## [0.2.3] - 2025-09-19
See [release notes](https://github.com/meta-pytorch/tritonparse/releases/tag/v0.2.3)

## [0.2.0] - 2025-09-11
See [release notes](https://github.com/meta-pytorch/tritonparse/releases/tag/v0.2.0)

## [0.1.1] - 2025-07-25
See [release notes](https://github.com/meta-pytorch/tritonparse/releases/tag/v0.1.1)

## [0.1.0] - 2025-07-21
See [release notes](https://github.com/meta-pytorch/tritonparse/releases/tag/v0.1.0)
