"""CPU tests for tritonparse (no GPU required)."""
