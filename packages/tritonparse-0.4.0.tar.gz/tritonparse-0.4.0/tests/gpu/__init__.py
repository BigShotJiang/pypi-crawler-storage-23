"""GPU tests for tritonparse (require CUDA)."""
