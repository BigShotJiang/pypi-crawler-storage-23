# Copyright (c) Meta Platforms, Inc. and affiliates.

# pyre-strict

"""Test artifacts for multi-file call graph analyzer integration tests."""
