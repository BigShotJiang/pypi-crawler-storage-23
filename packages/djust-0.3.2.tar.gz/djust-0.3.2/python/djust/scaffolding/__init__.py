"""
Scaffolding module for generating new djust projects.

Provides templates and generation logic for ``python -m djust new``
and ``python manage.py djust_new``.
"""
