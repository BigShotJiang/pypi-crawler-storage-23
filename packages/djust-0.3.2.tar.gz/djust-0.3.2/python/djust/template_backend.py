"""Backward compatibility shim - imports from template package."""

from .template import *  # noqa: F401,F403
