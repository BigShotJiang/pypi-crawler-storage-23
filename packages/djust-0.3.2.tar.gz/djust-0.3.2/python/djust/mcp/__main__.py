"""Allow running the MCP server with ``python -m djust.mcp``."""

from djust.mcp.server import main

main()
