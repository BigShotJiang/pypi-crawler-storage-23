# Namespace package — allows `from quantjourney.sdk import ...`
