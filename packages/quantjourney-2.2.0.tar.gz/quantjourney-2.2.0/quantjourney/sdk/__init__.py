"""
QuantJourney SDK (package)

Provides `QuantJourneyAPI` client and per-connector endpoint classes under
`quantjourney.sdk.connectors`.

Import path remains stable for users/tests:
    from quantjourney.sdk import QuantJourneyAPI
"""

import os
from .client import APIClient, APIError  # re-export for convenience
from .client import ConnectorEndpoint  # for custom extensions
from .client import DomainResponse  # domain API response wrapper with meta
from .registry import SDK_CONNECTORS
from .auth import AuthClient
from .warehouse import WarehouseClient
from .domains import DomainsClient

from importlib import import_module
from typing import Any, Optional, Dict
from .domains import DomainProxy  # re-export for backward compat


DEFAULT_API_URL = "https://api.quantjourney.cloud"
DEFAULT_AUTH_URL = "https://auth.quantjourney.cloud"


class QuantJourneyAPI:
    """QuantJourney HTTP SDK Client (aggregator with lazy connector loading)."""

    def __init__(self, api_url: str = DEFAULT_API_URL,
                 auth_url: str = DEFAULT_AUTH_URL,
                 api_key: Optional[str] = None,
                 token: Optional[str] = None,
                 timeout: int = 30,
                 tenant_id: Optional[str] = None):
        # token is an alias for api_key for friendlier ergonomics
        if api_key is None and token is not None:
            api_key = token
        self._client = APIClient(base_url=api_url, api_key=api_key, timeout=timeout, tenant_id=tenant_id, auth_url=auth_url)
        self._endpoints: Dict[str, Any] = {}
        self._auth = AuthClient(self._client)

    @classmethod
    def from_env(cls) -> "QuantJourneyAPI":
        api = os.getenv("QJ_API", DEFAULT_API_URL).rstrip("/")
        auth = os.getenv("QJ_AUTH_URL", DEFAULT_AUTH_URL).rstrip("/")
        key = os.getenv("QJ_API_KEY") or os.getenv("QJ_ACCESS_TOKEN") or os.getenv("QJ_TOKEN")
        tid = os.getenv("QJ_TENANT_ID")
        user = os.getenv("QJ_USER_ID")
        pwd = os.getenv("QJ_PASSWORD")
        inst = cls(api_url=api, auth_url=auth, api_key=key, tenant_id=tid)
        # If no key but have creds, login
        if not key and user and pwd:
            inst.auth.login(email=user, password=pwd, tenant_id=tid or "")
        return inst

    # --- Lazy properties for common connectors used in tests ---
    @property
    def eod(self):
        return self._get_endpoint("eod")

    @property
    def fmp(self):
        return self._get_endpoint("fmp")

    @property
    def fred(self):
        return self._get_endpoint("fred")

    @property
    def yf(self):
        return self._get_endpoint("yf")

    @property
    def openfigi(self):
        return self._get_endpoint("openfigi")

    @property
    def sec(self):
        return self._get_endpoint("sec")

    @property
    def cboe(self):
        return self._get_endpoint("cboe")

    @property
    def ccxt(self):
        return self._get_endpoint("ccxt")

    @property
    def imf(self):
        return self._get_endpoint("imf")

    @property
    def cnnf(self):
        return self._get_endpoint("cnnf")

    @property
    def cftc(self):
        return self._get_endpoint("cftc")

    @property
    def ff(self):
        return self._get_endpoint("ff")

    @property
    def oecd(self):
        return self._get_endpoint("oecd")

    @property
    def multpl(self):
        return self._get_endpoint("multpl")

    @property
    def finra(self):
        return self._get_endpoint("finra")

    @property
    def dbnomics(self):
        return self._get_endpoint("dbnomics")

    @property
    def insider(self):
        return self._get_endpoint("insider")

    @property
    def ratios(self):
        # Simple wrapper over /ratios endpoints (available + series)
        return _RatiosClient(self._client)

    @property
    def bt(self):
        return self._get_endpoint("bt")

    @property
    def analytics(self):
        return self._get_endpoint("analytics")

    @property
    def universe(self):
        return self._get_endpoint("universe")

    @property
    def warehouse(self):
        """Data Warehouse endpoints (/data/v1/*)."""
        if '_warehouse' not in self.__dict__:
            self._warehouse = WarehouseClient(self._client)
        return self._warehouse

    @property
    def domains(self) -> DomainsClient:
        """Domain routing layer (/d/*) – provider-agnostic data access."""
        if '_domains' not in self.__dict__:
            self._domains = DomainsClient(self._client)
        return self._domains

    # --- Utilities ---
    def _get_endpoint(self, key: str):
        ep = self._endpoints.get(key)
        if ep is not None:
            return ep
        spec = SDK_CONNECTORS.get(key)
        if not spec:
            raise AttributeError(f"Connector '{key}' not registered in SDK")
        module_path, class_name = spec.split(":", 1)
        mod = import_module(module_path)
        cls = getattr(mod, class_name)
        inst = cls(self._client, key)
        self._endpoints[key] = inst
        return inst

    def health(self) -> Dict[str, Any]:
        return self._client.health_check()

    def __repr__(self) -> str:
        return f"QuantJourneyAPI(url={self._client.base_url})"

    # Domain dynamic access (fallback): any unknown attribute becomes a domain proxy.
    def __getattr__(self, name: str):
        # Avoid catching dunder attrs
        if name.startswith("__"):
            raise AttributeError(name)
        return DomainProxy(self._client, name)

    # Auth facade
    @property
    def auth(self) -> AuthClient:
        return self._auth

__all__ = ["QuantJourneyAPI", "APIClient", "APIError", "ConnectorEndpoint", "DomainResponse", "DomainsClient"]


# Backward/forward-compatible alias: QuantJourney
class QuantJourney(QuantJourneyAPI):
    """Alias for QuantJourneyAPI for simpler imports/naming."""
    pass


class _RatiosClient:
    def __init__(self, api_client: APIClient):
        self._api = api_client

    def available(self, source: str = "eod"):
        # GET endpoint
        return self._api.get(endpoint="/ratios/available", params={"source": source})

    def series(self, ratio: str, ticker: str, exchange: str = "US", source: str = "eod",
               start: str = None, end: str = None, compute: bool = False, period: str = "q"):
        # GET endpoint with query params
        params = {
            "ratio": ratio,
            "ticker": ticker,
            "exchange": exchange,
            "source": source,
            "period": period,
            "compute": str(bool(compute)).lower(),
        }
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        return self._api.get(endpoint="/ratios/series", params=params)

__all__.append("QuantJourney")
