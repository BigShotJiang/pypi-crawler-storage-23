from ..client import ConnectorEndpoint


class CNNFEndpoint(ConnectorEndpoint):
    """SDK endpoints for CNN Fear & Greed connector.

    Relies on dynamic fallback for get_*/search_* methods.
    """

    # >>> AUTO-GENERATED SDK METHODS BEGIN (cnnf) <<<
    # NOTE: Auto-generated from connector manifest.

    def get_1d_average(self, **params):
        return self._call('get_1d_average', **params)

    def get_1d_fear_greed_value(self, **params):
        return self._call('get_1d_fear_greed_value', **params)

    def get_1d_maximum(self, **params):
        return self._call('get_1d_maximum', **params)

    def get_1d_minimum(self, **params):
        return self._call('get_1d_minimum', **params)

    def get_1d_sentiment_label(self, **params):
        return self._call('get_1d_sentiment_label', **params)

    def get_1d_volatility(self, **params):
        return self._call('get_1d_volatility', **params)

    def get_30d_average(self, **params):
        return self._call('get_30d_average', **params)

    def get_30d_fear_greed_value(self, **params):
        return self._call('get_30d_fear_greed_value', **params)

    def get_30d_maximum(self, **params):
        return self._call('get_30d_maximum', **params)

    def get_30d_minimum(self, **params):
        return self._call('get_30d_minimum', **params)

    def get_30d_sentiment_label(self, **params):
        return self._call('get_30d_sentiment_label', **params)

    def get_30d_volatility(self, **params):
        return self._call('get_30d_volatility', **params)

    def get_7d_average(self, **params):
        return self._call('get_7d_average', **params)

    def get_7d_fear_greed_value(self, **params):
        return self._call('get_7d_fear_greed_value', **params)

    def get_7d_maximum(self, **params):
        return self._call('get_7d_maximum', **params)

    def get_7d_minimum(self, **params):
        return self._call('get_7d_minimum', **params)

    def get_7d_sentiment_label(self, **params):
        return self._call('get_7d_sentiment_label', **params)

    def get_7d_volatility(self, **params):
        return self._call('get_7d_volatility', **params)

    def get_90d_average(self, **params):
        return self._call('get_90d_average', **params)

    def get_90d_fear_greed_value(self, **params):
        return self._call('get_90d_fear_greed_value', **params)

    def get_90d_maximum(self, **params):
        return self._call('get_90d_maximum', **params)

    def get_90d_minimum(self, **params):
        return self._call('get_90d_minimum', **params)

    def get_90d_sentiment_label(self, **params):
        return self._call('get_90d_sentiment_label', **params)

    def get_90d_volatility(self, **params):
        return self._call('get_90d_volatility', **params)

    def get_average_fear_greed(self, **params):
        return self._call('get_average_fear_greed', **params)

    def get_cnnf_index_for_day(self, **params):
        return self._call('get_cnnf_index_for_day', **params)

    def get_cnnf_index_range(self, **params):
        return self._call('get_cnnf_index_range', **params)

    def get_latest_fear_greed_value(self, **params):
        return self._call('get_latest_fear_greed_value', **params)

    def get_latest_sentiment_label(self, **params):
        return self._call('get_latest_sentiment_label', **params)

    def get_maximum_fear_greed(self, **params):
        return self._call('get_maximum_fear_greed', **params)

    def get_minimum_fear_greed(self, **params):
        return self._call('get_minimum_fear_greed', **params)

    def get_volatility(self, **params):
        return self._call('get_volatility', **params)

    # >>> AUTO-GENERATED SDK METHODS END (cnnf) <<<
