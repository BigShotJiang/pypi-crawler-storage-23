from typing import Any, Dict, List, Optional, Union
from ..client import ConnectorEndpoint


class YFEndpoint(ConnectorEndpoint):
    """Yahoo Finance endpoints with friendly argument mapping.

    Notes:
    - Server expects `symbols` (str | List[str]) for batch-friendly methods.
    - These helpers accept either `symbol` or `symbols` and normalize to `symbols`.
    """

    @staticmethod
    def _norm_symbols(symbol: Optional[str] = None,
                      symbols: Optional[Union[str, List[str]]] = None) -> Union[str, List[str]]:
        if symbols is not None:
            return symbols
        if symbol is None:
            raise ValueError("symbol or symbols is required")
        return symbol

    def get_historical_prices(
        self,
        symbol: Optional[str] = None,
        symbols: Optional[Union[str, List[str]]] = None,
        start_date: str = "",
        end_date: str = "",
        frequency: str = "1d",
        exchanges: Optional[Union[str, List[str]]] = None,
    ) -> Any:
        payload: Dict[str, Any] = {
            "symbols": self._norm_symbols(symbol=symbol, symbols=symbols),
            "start_date": start_date,
            "end_date": end_date,
            "frequency": frequency,
        }
        if exchanges is not None:
            payload["exchanges"] = exchanges
        return self._call("get_historical_prices", **payload)

    def get_real_time_prices(
        self,
        symbol: Optional[str] = None,
        symbols: Optional[Union[str, List[str]]] = None,
        exchange: Optional[str] = "US",
    ) -> Any:
        payload: Dict[str, Any] = {
            "symbols": self._norm_symbols(symbol=symbol, symbols=symbols),
        }
        if exchange is not None:
            payload["exchange"] = exchange
        return self._call("get_real_time_prices", **payload)

    def get_intraday_prices(
        self,
        symbol: Optional[str] = None,
        symbols: Optional[Union[str, List[str]]] = None,
        start_time: str = "",
        end_time: str = "",
        frequency: str = "5m",
        exchanges: Optional[Union[str, List[str]]] = None,
    ) -> Any:
        payload: Dict[str, Any] = {
            "symbols": self._norm_symbols(symbol=symbol, symbols=symbols),
            "start_time": start_time,
            "end_time": end_time,
            "frequency": frequency,
        }
        if exchanges is not None:
            payload["exchanges"] = exchanges
        return self._call("get_intraday_prices", **payload)
    # >>> AUTO-GENERATED SDK METHODS BEGIN (yf) <<<
    # NOTE: Auto-generated from connector manifest.

    def get_balance_sheet_statement(self, **params):
        return self._call('get_balance_sheet_statement', **params)

    def get_beta(self, **params):
        return self._call('get_beta', **params)

    def get_book_value(self, **params):
        return self._call('get_book_value', **params)

    def get_book_value_per_share_ttm(self, **params):
        return self._call('get_book_value_per_share_ttm', **params)

    def get_cash_flow_statement(self, **params):
        return self._call('get_cash_flow_statement', **params)

    def get_cash_per_share_ttm(self, **params):
        return self._call('get_cash_per_share_ttm', **params)

    def get_cash_ratio_ttm(self, **params):
        return self._call('get_cash_ratio_ttm', **params)

    def get_current_ratio_ttm(self, **params):
        return self._call('get_current_ratio_ttm', **params)

    def get_debt_equity_ratio_ttm(self, **params):
        return self._call('get_debt_equity_ratio_ttm', **params)

    def get_debt_ratio_ttm(self, **params):
        return self._call('get_debt_ratio_ttm', **params)

    def get_debt_to_assets_ttm(self, **params):
        return self._call('get_debt_to_assets_ttm', **params)

    def get_debt_to_equity_ttm(self, **params):
        return self._call('get_debt_to_equity_ttm', **params)

    def get_diluted_eps_ttm(self, **params):
        return self._call('get_diluted_eps_ttm', **params)

    def get_dividend_share(self, **params):
        return self._call('get_dividend_share', **params)

    def get_dividend_yield_ttm(self, **params):
        return self._call('get_dividend_yield_ttm', **params)

    def get_earnings_yield_ttm(self, **params):
        return self._call('get_earnings_yield_ttm', **params)

    def get_enterprise_value(self, **params):
        return self._call('get_enterprise_value', **params)

    def get_enterprise_value_ebitda(self, **params):
        return self._call('get_enterprise_value_ebitda', **params)

    def get_enterprise_value_multiple_ttm(self, **params):
        return self._call('get_enterprise_value_multiple_ttm', **params)

    def get_enterprise_value_over_ebitda_ttm(self, **params):
        return self._call('get_enterprise_value_over_ebitda_ttm', **params)

    def get_enterprise_value_revenue(self, **params):
        return self._call('get_enterprise_value_revenue', **params)

    def get_enterprise_value_ttm(self, **params):
        return self._call('get_enterprise_value_ttm', **params)

    def get_eps(self, **params):
        return self._call('get_eps', **params)

    def get_ev_to_sales_ttm(self, **params):
        return self._call('get_ev_to_sales_ttm', **params)

    def get_free_cash_flow_per_share_ttm(self, **params):
        return self._call('get_free_cash_flow_per_share_ttm', **params)

    def get_free_cash_flow_yield_ttm(self, **params):
        return self._call('get_free_cash_flow_yield_ttm', **params)

    def get_graham_number_ttm(self, **params):
        return self._call('get_graham_number_ttm', **params)

    def get_gross_profit_margin_ttm(self, **params):
        return self._call('get_gross_profit_margin_ttm', **params)

    def get_historical_prices_multi(self, **params):
        return self._call('get_historical_prices_multi', **params)

    def get_income_statement(self, **params):
        return self._call('get_income_statement', **params)

    def get_index_history(self, **params):
        return self._call('get_index_history', **params)

    def get_intraday_prices_multi(self, **params):
        return self._call('get_intraday_prices_multi', **params)

    def get_key_statistics(self, **params):
        return self._call('get_key_statistics', **params)

    def get_last_dividend(self, **params):
        return self._call('get_last_dividend', **params)

    def get_market_cap(self, **params):
        return self._call('get_market_cap', **params)

    def get_market_cap_mln(self, **params):
        return self._call('get_market_cap_mln', **params)

    def get_nasdaq_100_index(self, **params):
        return self._call('get_nasdaq_100_index', **params)

    def get_net_debt_to_ebitda_ttm(self, **params):
        return self._call('get_net_debt_to_ebitda_ttm', **params)

    def get_net_income_per_share_ttm(self, **params):
        return self._call('get_net_income_per_share_ttm', **params)

    def get_net_profit_margin_ttm(self, **params):
        return self._call('get_net_profit_margin_ttm', **params)

    def get_operating_cash_flow_per_share_ttm(self, **params):
        return self._call('get_operating_cash_flow_per_share_ttm', **params)

    def get_operating_margin_ttm(self, **params):
        return self._call('get_operating_margin_ttm', **params)

    def get_operating_profit_margin_ttm(self, **params):
        return self._call('get_operating_profit_margin_ttm', **params)

    def get_payout_ratio_ttm(self, **params):
        return self._call('get_payout_ratio_ttm', **params)

    def get_pb_ratio_ttm(self, **params):
        return self._call('get_pb_ratio_ttm', **params)

    def get_pe_ratio(self, **params):
        return self._call('get_pe_ratio', **params)

    def get_pe_ratio_ttm(self, **params):
        return self._call('get_pe_ratio_ttm', **params)

    def get_peg_ratio(self, **params):
        return self._call('get_peg_ratio', **params)

    def get_price_earnings_to_growth_ratio_ttm(self, **params):
        return self._call('get_price_earnings_to_growth_ratio_ttm', **params)

    def get_price_to_book_ttm(self, **params):
        return self._call('get_price_to_book_ttm', **params)

    def get_price_to_sales_ratio_ttm(self, **params):
        return self._call('get_price_to_sales_ratio_ttm', **params)

    def get_price_to_sales_ttm(self, **params):
        return self._call('get_price_to_sales_ttm', **params)

    def get_profit_margin(self, **params):
        return self._call('get_profit_margin', **params)

    def get_quick_ratio_ttm(self, **params):
        return self._call('get_quick_ratio_ttm', **params)

    def get_real_time_prices_multi(self, **params):
        return self._call('get_real_time_prices_multi', **params)

    def get_return_on_assets_ttm(self, **params):
        return self._call('get_return_on_assets_ttm', **params)

    def get_return_on_equity_ttm(self, **params):
        return self._call('get_return_on_equity_ttm', **params)

    def get_revenue_per_share_ttm(self, **params):
        return self._call('get_revenue_per_share_ttm', **params)

    def get_roe_ttm(self, **params):
        return self._call('get_roe_ttm', **params)

    def get_roic_ttm(self, **params):
        return self._call('get_roic_ttm', **params)

    def get_shareholders_equity_per_share_ttm(self, **params):
        return self._call('get_shareholders_equity_per_share_ttm', **params)

    def get_sp500(self, **params):
        return self._call('get_sp500', **params)

    def get_sp500_index(self, **params):
        return self._call('get_sp500_index', **params)

    def get_sp500_index_history(self, **params):
        return self._call('get_sp500_index_history', **params)

    def get_sp500_sectors(self, **params):
        return self._call('get_sp500_sectors', **params)

    def get_sp500_stocks_info(self, **params):
        return self._call('get_sp500_stocks_info', **params)

    def get_symbol_info(self, **params):
        return self._call('get_symbol_info', **params)

    def get_tangible_book_value_per_share_ttm(self, **params):
        return self._call('get_tangible_book_value_per_share_ttm', **params)

    def get_ticker_info(self, **params):
        return self._call('get_ticker_info', **params)

    def get_trailing_pe(self, **params):
        return self._call('get_trailing_pe', **params)

    # >>> AUTO-GENERATED SDK METHODS END (yf) <<<
