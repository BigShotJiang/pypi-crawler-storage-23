from ..client import ConnectorEndpoint


class MULTPLEndpoint(ConnectorEndpoint):
    """SDK endpoints for Multpl connector.

    Relies on dynamic fallback for get_*/search_* methods.
    """

    # >>> AUTO-GENERATED SDK METHODS BEGIN (multpl) <<<
    # NOTE: Auto-generated from connector manifest.

    def get_10_year_treasury_rate(self, **params):
        return self._call('get_10_year_treasury_rate', **params)

    def get_20_year_treasury_rate(self, **params):
        return self._call('get_20_year_treasury_rate', **params)

    def get_30_year_treasury_rate(self, **params):
        return self._call('get_30_year_treasury_rate', **params)

    def get_all_dividend_data(self, **params):
        return self._call('get_all_dividend_data', **params)

    def get_all_earnings_data(self, **params):
        return self._call('get_all_earnings_data', **params)

    def get_all_economic_indicators(self, **params):
        return self._call('get_all_economic_indicators', **params)

    def get_all_pe_ratios(self, **params):
        return self._call('get_all_pe_ratios', **params)

    def get_all_price_data(self, **params):
        return self._call('get_all_price_data', **params)

    def get_all_sales_data(self, **params):
        return self._call('get_all_sales_data', **params)

    def get_all_treasury_rates(self, **params):
        return self._call('get_all_treasury_rates', **params)

    def get_all_valuation_ratios(self, **params):
        return self._call('get_all_valuation_ratios', **params)

    def get_available_dividend_series(self, **params):
        return self._call('get_available_dividend_series', **params)

    def get_available_earnings_series(self, **params):
        return self._call('get_available_earnings_series', **params)

    def get_available_pe_ratios(self, **params):
        return self._call('get_available_pe_ratios', **params)

    def get_available_sales_series(self, **params):
        return self._call('get_available_sales_series', **params)

    def get_available_series(self, **params):
        return self._call('get_available_series', **params)

    def get_available_valuation_ratios(self, **params):
        return self._call('get_available_valuation_ratios', **params)

    def get_book_value(self, **params):
        return self._call('get_book_value', **params)

    def get_cache_stats(self, **params):
        return self._call('get_cache_stats', **params)

    def get_complete_fundamentals_dataset(self, **params):
        return self._call('get_complete_fundamentals_dataset', **params)

    def get_dividend_growth(self, **params):
        return self._call('get_dividend_growth', **params)

    def get_dividend_yield_ttm(self, **params):
        return self._call('get_dividend_yield_ttm', **params)

    def get_dividends(self, **params):
        return self._call('get_dividends', **params)

    def get_earnings(self, **params):
        return self._call('get_earnings', **params)

    def get_earnings_growth(self, **params):
        return self._call('get_earnings_growth', **params)

    def get_earnings_yield(self, **params):
        return self._call('get_earnings_yield', **params)

    def get_gdp_growth_rate(self, **params):
        return self._call('get_gdp_growth_rate', **params)

    def get_historical_prices(self, **params):
        return self._call('get_historical_prices', **params)

    def get_inflation_rate(self, **params):
        return self._call('get_inflation_rate', **params)

    def get_median_income(self, **params):
        return self._call('get_median_income', **params)

    def get_pe_ratio(self, **params):
        return self._call('get_pe_ratio', **params)

    def get_price_to_book_ratio(self, **params):
        return self._call('get_price_to_book_ratio', **params)

    def get_price_to_sales_ratio(self, **params):
        return self._call('get_price_to_sales_ratio', **params)

    def get_real_gdp_growth_rate(self, **params):
        return self._call('get_real_gdp_growth_rate', **params)

    def get_sales(self, **params):
        return self._call('get_sales', **params)

    def get_sales_growth(self, **params):
        return self._call('get_sales_growth', **params)

    def get_shiller_pe_ratio(self, **params):
        return self._call('get_shiller_pe_ratio', **params)

    def get_valuation_summary(self, **params):
        return self._call('get_valuation_summary', **params)

    # >>> AUTO-GENERATED SDK METHODS END (multpl) <<<
