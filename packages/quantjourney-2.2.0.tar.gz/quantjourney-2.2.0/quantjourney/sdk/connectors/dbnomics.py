from ..client import ConnectorEndpoint


class DBNOMICSEndpoint(ConnectorEndpoint):
    """SDK endpoints for DBNOMICS connector."""

    # >>> AUTO-GENERATED SDK METHODS BEGIN (dbnomics) <<<
    # NOTE: Auto-generated from connector manifest.

    def get_consumer_price_index(self, **params):
        return self._call('get_consumer_price_index', **params)

    def get_datasets(self, **params):
        return self._call('get_datasets', **params)

    def get_exchange_rates(self, **params):
        return self._call('get_exchange_rates', **params)

    def get_gdp_growth(self, **params):
        return self._call('get_gdp_growth', **params)

    def get_gdp_nominal(self, **params):
        return self._call('get_gdp_nominal', **params)

    def get_inflation_rates(self, **params):
        return self._call('get_inflation_rates', **params)

    def get_interest_rates(self, **params):
        return self._call('get_interest_rates', **params)

    def get_providers(self, **params):
        return self._call('get_providers', **params)

    def get_unemployment_rates(self, **params):
        return self._call('get_unemployment_rates', **params)

    def search_series(self, **params):
        return self._call('search_series', **params)

    # >>> AUTO-GENERATED SDK METHODS END (dbnomics) <<<
