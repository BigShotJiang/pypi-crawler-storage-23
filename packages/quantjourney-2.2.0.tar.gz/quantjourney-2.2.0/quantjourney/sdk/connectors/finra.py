from ..client import ConnectorEndpoint


class FINRAEndpoint(ConnectorEndpoint):
    """SDK endpoints for FINRA connector."""

    # >>> AUTO-GENERATED SDK METHODS BEGIN (finra) <<<
    # NOTE: Auto-generated from connector manifest.

    def get_ats_vs_non_ats(self, **params):
        return self._call('get_ats_vs_non_ats', **params)

    def get_available_settlement_dates(self, **params):
        return self._call('get_available_settlement_dates', **params)

    def get_available_short_interest_dates_impl(self, **params):
        return self._call('get_available_short_interest_dates_impl', **params)

    def get_cache_stats(self, **params):
        return self._call('get_cache_stats', **params)

    def get_market_overview(self, **params):
        return self._call('get_market_overview', **params)

    def get_market_tiers(self, **params):
        return self._call('get_market_tiers', **params)

    def get_otc_aggregate(self, **params):
        return self._call('get_otc_aggregate', **params)

    def get_otc_aggregate_data(self, **params):
        return self._call('get_otc_aggregate_data', **params)

    def get_otc_top_symbols(self, **params):
        return self._call('get_otc_top_symbols', **params)

    def get_short_interest(self, **params):
        return self._call('get_short_interest', **params)

    def get_short_interest_by_date(self, **params):
        return self._call('get_short_interest_by_date', **params)

    def get_short_interest_data(self, **params):
        return self._call('get_short_interest_data', **params)

    def get_symbol_analysis(self, **params):
        return self._call('get_symbol_analysis', **params)

    def get_tier_comparison(self, **params):
        return self._call('get_tier_comparison', **params)

    # >>> AUTO-GENERATED SDK METHODS END (finra) <<<
