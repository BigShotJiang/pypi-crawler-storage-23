from ..client import ConnectorEndpoint


class CCXTEndpoint(ConnectorEndpoint):
    """SDK endpoints for CCXT connector."""

    def get_historical_prices(self, **params):
        return self._call('get_historical_prices', **params)

    # >>> AUTO-GENERATED SDK METHODS BEGIN (ccxt) <<<
    # NOTE: Auto-generated from connector manifest.

    def get_account_balance(self, **params):
        return self._call('get_account_balance', **params)

    def get_bids_asks(self, **params):
        return self._call('get_bids_asks', **params)

    def get_deposit_address(self, **params):
        return self._call('get_deposit_address', **params)

    def get_exchange_symbols(self, **params):
        return self._call('get_exchange_symbols', **params)

    def get_funding_rate(self, **params):
        return self._call('get_funding_rate', **params)

    def get_historical_funding_rates(self, **params):
        return self._call('get_historical_funding_rates', **params)

    def get_intraday_prices(self, **params):
        return self._call('get_intraday_prices', **params)

    def get_l2_order_book(self, **params):
        return self._call('get_l2_order_book', **params)

    def get_last_prices(self, **params):
        return self._call('get_last_prices', **params)

    def get_ledger(self, **params):
        return self._call('get_ledger', **params)

    def get_market_details(self, **params):
        return self._call('get_market_details', **params)

    def get_my_trades(self, **params):
        return self._call('get_my_trades', **params)

    def get_ohlcv_data(self, **params):
        return self._call('get_ohlcv_data', **params)

    def get_open_interest(self, **params):
        return self._call('get_open_interest', **params)

    def get_positions(self, **params):
        return self._call('get_positions', **params)

    def get_real_time_prices(self, **params):
        return self._call('get_real_time_prices', **params)

    def get_recent_trades(self, **params):
        return self._call('get_recent_trades', **params)

    def get_ticker(self, **params):
        return self._call('get_ticker', **params)

    def get_tickers(self, **params):
        return self._call('get_tickers', **params)

    def get_trading_fees(self, **params):
        return self._call('get_trading_fees', **params)

    # >>> AUTO-GENERATED SDK METHODS END (ccxt) <<<
