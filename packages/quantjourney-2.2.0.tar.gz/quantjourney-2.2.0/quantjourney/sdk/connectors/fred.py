from ..client import ConnectorEndpoint


class FREDEndpoint(ConnectorEndpoint):
    """SDK endpoints for FRED connector."""

    # >>> AUTO-GENERATED SDK METHODS BEGIN (fred) <<<
    # NOTE: Auto-generated from connector manifest.

    def get_all_fred_data_sources(self, **params):
        return self._call('get_all_fred_data_sources', **params)

    def get_all_fred_data_tags(self, **params):
        return self._call('get_all_fred_data_tags', **params)

    def get_all_fred_releases(self, **params):
        return self._call('get_all_fred_releases', **params)

    def get_all_fred_series_by_tags(self, **params):
        return self._call('get_all_fred_series_by_tags', **params)

    def get_available_economic_indicators(self, **params):
        return self._call('get_available_economic_indicators', **params)

    def get_available_fed_balance_sheet_items(self, **params):
        return self._call('get_available_fed_balance_sheet_items', **params)

    def get_available_h41_series(self, **params):
        return self._call('get_available_h41_series', **params)

    def get_available_market_rates(self, **params):
        return self._call('get_available_market_rates', **params)

    def get_average_hourly_earnings(self, **params):
        return self._call('get_average_hourly_earnings', **params)

    def get_building_permits(self, **params):
        return self._call('get_building_permits', **params)

    def get_business_inventories(self, **params):
        return self._call('get_business_inventories', **params)

    def get_cache_stats(self, **params):
        return self._call('get_cache_stats', **params)

    def get_capacity_utilization(self, **params):
        return self._call('get_capacity_utilization', **params)

    def get_categories(self, **params):
        return self._call('get_categories', **params)

    def get_consumer_confidence(self, **params):
        return self._call('get_consumer_confidence', **params)

    def get_cpi(self, **params):
        return self._call('get_cpi', **params)

    def get_current_account_balance(self, **params):
        return self._call('get_current_account_balance', **params)

    def get_durable_goods_orders(self, **params):
        return self._call('get_durable_goods_orders', **params)

    def get_effective_federal_funds_rate(self, **params):
        return self._call('get_effective_federal_funds_rate', **params)

    def get_fed_agency_debt_securities(self, **params):
        return self._call('get_fed_agency_debt_securities', **params)

    def get_fed_currency_in_circulation(self, **params):
        return self._call('get_fed_currency_in_circulation', **params)

    def get_fed_funds_rate(self, **params):
        return self._call('get_fed_funds_rate', **params)

    def get_fed_loans_total(self, **params):
        return self._call('get_fed_loans_total', **params)

    def get_fed_mortgage_backed_securities(self, **params):
        return self._call('get_fed_mortgage_backed_securities', **params)

    def get_fed_primary_credit(self, **params):
        return self._call('get_fed_primary_credit', **params)

    def get_fed_reserve_balances(self, **params):
        return self._call('get_fed_reserve_balances', **params)

    def get_fed_reverse_repo_agreements(self, **params):
        return self._call('get_fed_reverse_repo_agreements', **params)

    def get_fed_securities_held_outright(self, **params):
        return self._call('get_fed_securities_held_outright', **params)

    def get_fed_total_assets(self, **params):
        return self._call('get_fed_total_assets', **params)

    def get_fed_treasury_bills(self, **params):
        return self._call('get_fed_treasury_bills', **params)

    def get_fed_treasury_general_account(self, **params):
        return self._call('get_fed_treasury_general_account', **params)

    def get_fed_treasury_inflation_indexed(self, **params):
        return self._call('get_fed_treasury_inflation_indexed', **params)

    def get_fed_treasury_notes_bonds_nominal(self, **params):
        return self._call('get_fed_treasury_notes_bonds_nominal', **params)

    def get_fed_treasury_securities(self, **params):
        return self._call('get_fed_treasury_securities', **params)

    def get_fred_data_series_by_id(self, **params):
        return self._call('get_fred_data_series_by_id', **params)

    def get_fred_data_series_info(self, **params):
        return self._call('get_fred_data_series_info', **params)

    def get_fred_data_series_list_by_category(self, **params):
        return self._call('get_fred_data_series_list_by_category', **params)

    def get_fred_data_series_list_by_release(self, **params):
        return self._call('get_fred_data_series_list_by_release', **params)

    def get_gdp(self, **params):
        return self._call('get_gdp', **params)

    def get_h41_factors_absorbing_reserve_funds(self, **params):
        return self._call('get_h41_factors_absorbing_reserve_funds', **params)

    def get_h41_factors_supplying_reserve_funds(self, **params):
        return self._call('get_h41_factors_supplying_reserve_funds', **params)

    def get_h41_foreign_currency_assets(self, **params):
        return self._call('get_h41_foreign_currency_assets', **params)

    def get_h41_gold_stock(self, **params):
        return self._call('get_h41_gold_stock', **params)

    def get_h41_reserve_bank_credit(self, **params):
        return self._call('get_h41_reserve_bank_credit', **params)

    def get_h41_sdr_certificate_account(self, **params):
        return self._call('get_h41_sdr_certificate_account', **params)

    def get_h41_treasury_currency_outstanding(self, **params):
        return self._call('get_h41_treasury_currency_outstanding', **params)

    def get_housing_starts(self, **params):
        return self._call('get_housing_starts', **params)

    def get_industrial_production(self, **params):
        return self._call('get_industrial_production', **params)

    def get_jobless_claims(self, **params):
        return self._call('get_jobless_claims', **params)

    def get_labor_force_participation(self, **params):
        return self._call('get_labor_force_participation', **params)

    def get_m2_money_supply(self, **params):
        return self._call('get_m2_money_supply', **params)

    def get_manufacturing_pmi(self, **params):
        return self._call('get_manufacturing_pmi', **params)

    def get_nonfarm_payrolls(self, **params):
        return self._call('get_nonfarm_payrolls', **params)

    def get_overnight_bank_funding_rate(self, **params):
        return self._call('get_overnight_bank_funding_rate', **params)

    def get_pce(self, **params):
        return self._call('get_pce', **params)

    def get_personal_income(self, **params):
        return self._call('get_personal_income', **params)

    def get_personal_spending(self, **params):
        return self._call('get_personal_spending', **params)

    def get_ppi(self, **params):
        return self._call('get_ppi', **params)

    def get_release_dates(self, **params):
        return self._call('get_release_dates', **params)

    def get_releases(self, **params):
        return self._call('get_releases', **params)

    def get_retail_sales(self, **params):
        return self._call('get_retail_sales', **params)

    def get_savings_rate(self, **params):
        return self._call('get_savings_rate', **params)

    def get_secured_overnight_financing_rate(self, **params):
        return self._call('get_secured_overnight_financing_rate', **params)

    def get_series_info(self, **params):
        return self._call('get_series_info', **params)

    def get_services_pmi(self, **params):
        return self._call('get_services_pmi', **params)

    def get_small_business_optimism(self, **params):
        return self._call('get_small_business_optimism', **params)

    def get_sources(self, **params):
        return self._call('get_sources', **params)

    def get_tags(self, **params):
        return self._call('get_tags', **params)

    def get_time_series(self, **params):
        return self._call('get_time_series', **params)

    def get_trade_balance(self, **params):
        return self._call('get_trade_balance', **params)

    def get_treasury_10y(self, **params):
        return self._call('get_treasury_10y', **params)

    def get_treasury_2y(self, **params):
        return self._call('get_treasury_2y', **params)

    def get_treasury_repo_rate(self, **params):
        return self._call('get_treasury_repo_rate', **params)

    def get_unemployment_rate(self, **params):
        return self._call('get_unemployment_rate', **params)

    def get_velocity_of_money(self, **params):
        return self._call('get_velocity_of_money', **params)

    def search_dealer_positioning_data(self, **params):
        return self._call('search_dealer_positioning_data', **params)

    def search_fred_for_series(self, **params):
        return self._call('search_fred_for_series', **params)

    def search_ofr_primary_dealer_data(self, **params):
        return self._call('search_ofr_primary_dealer_data', **params)

    def search_repo_market_data(self, **params):
        return self._call('search_repo_market_data', **params)

    def search_series(self, **params):
        return self._call('search_series', **params)

    # >>> AUTO-GENERATED SDK METHODS END (fred) <<<
