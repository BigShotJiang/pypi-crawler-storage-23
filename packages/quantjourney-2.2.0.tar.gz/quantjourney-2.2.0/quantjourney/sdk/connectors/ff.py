from ..client import ConnectorEndpoint


class FFEndpoint(ConnectorEndpoint):
    """SDK endpoints for Fama-French connector.

    Relies on dynamic fallback for get_*/search_* methods.
    """

    # >>> AUTO-GENERATED SDK METHODS BEGIN (ff) <<<
    # NOTE: Auto-generated from connector manifest.

    def get_available_breakpoints(self, **params):
        return self._call('get_available_breakpoints', **params)

    def get_available_factors(self, **params):
        return self._call('get_available_factors', **params)

    def get_available_portfolios(self, **params):
        return self._call('get_available_portfolios', **params)

    def get_available_regions(self, **params):
        return self._call('get_available_regions', **params)

    def get_breakpoints(self, **params):
        return self._call('get_breakpoints', **params)

    def get_cache_stats(self, **params):
        return self._call('get_cache_stats', **params)

    def get_country_portfolio_returns(self, **params):
        return self._call('get_country_portfolio_returns', **params)

    def get_factors(self, **params):
        return self._call('get_factors', **params)

    def get_international_index_returns(self, **params):
        return self._call('get_international_index_returns', **params)

    def get_regional_portfolio_returns(self, **params):
        return self._call('get_regional_portfolio_returns', **params)

    def get_us_portfolio_returns(self, **params):
        return self._call('get_us_portfolio_returns', **params)

    # >>> AUTO-GENERATED SDK METHODS END (ff) <<<
