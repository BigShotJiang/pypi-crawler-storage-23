from ..client import ConnectorEndpoint


class CFTCEndpoint(ConnectorEndpoint):
    """SDK endpoints for CFTC connector.

    Relies on dynamic fallback for get_*/search_* methods.
    """

    # >>> AUTO-GENERATED SDK METHODS BEGIN (cftc) <<<
    # NOTE: Auto-generated from connector manifest.

    def get_cot_data(self, **params):
        return self._call('get_cot_data', **params)

    def get_cot_id_by_symbol(self, **params):
        return self._call('get_cot_id_by_symbol', **params)

    def get_cot_summary(self, **params):
        return self._call('get_cot_summary', **params)

    def get_popular_symbols(self, **params):
        return self._call('get_popular_symbols', **params)

    def search_cot_symbols(self, **params):
        return self._call('search_cot_symbols', **params)

    # >>> AUTO-GENERATED SDK METHODS END (cftc) <<<
