from ..client import ConnectorEndpoint


class OECDEndpoint(ConnectorEndpoint):
    """SDK endpoints for OECD connector.

    Relies on dynamic fallback for get_*/search_* methods.
    """

    # >>> AUTO-GENERATED SDK METHODS BEGIN (oecd) <<<
    # NOTE: Auto-generated from connector manifest.

    def get_available_countries(self, **params):
        return self._call('get_available_countries', **params)

    def get_cache_stats(self, **params):
        return self._call('get_cache_stats', **params)

    def get_composite_leading_indicator(self, **params):
        return self._call('get_composite_leading_indicator', **params)

    def get_cpi_data(self, **params):
        return self._call('get_cpi_data', **params)

    def get_current_account_balance(self, **params):
        return self._call('get_current_account_balance', **params)

    def get_economic_dashboard(self, **params):
        return self._call('get_economic_dashboard', **params)

    def get_gdp_data(self, **params):
        return self._call('get_gdp_data', **params)

    def get_gdp_forecast(self, **params):
        return self._call('get_gdp_forecast', **params)

    def get_gdp_nominal(self, **params):
        return self._call('get_gdp_nominal', **params)

    def get_gdp_per_employee(self, **params):
        return self._call('get_gdp_per_employee', **params)

    def get_gdp_quarterly(self, **params):
        return self._call('get_gdp_quarterly', **params)

    def get_house_price_index(self, **params):
        return self._call('get_house_price_index', **params)

    def get_inflation_data(self, **params):
        return self._call('get_inflation_data', **params)

    def get_interest_rates_data(self, **params):
        return self._call('get_interest_rates_data', **params)

    def get_share_price_index(self, **params):
        return self._call('get_share_price_index', **params)

    def get_unemployment_data(self, **params):
        return self._call('get_unemployment_data', **params)

    # >>> AUTO-GENERATED SDK METHODS END (oecd) <<<
