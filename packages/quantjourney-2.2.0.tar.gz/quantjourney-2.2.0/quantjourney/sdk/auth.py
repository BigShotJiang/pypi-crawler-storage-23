"""
QuantJourney SDK - Authentication Module
========================================

This module provides authentication helpers for the QuantJourney SDK.

Classes:
    AuthClient: Authentication client for login, token refresh, and API key management.
    Tokens: Dataclass representing access/refresh token pair.
    ApiKeyInfo: Dataclass representing API key metadata.
    NewApiKey: Dataclass representing a newly created API key (shown once).

Usage:
    >>> from quantjourney.sdk import QuantJourneyAPI
    >>> qj = QuantJourneyAPI()
    >>> qj.auth.login(email="user@example.com", password="secret", tenant_id="default")
    >>> print(qj.auth.whoami())

Copyright (c) 2024-2026 QuantJourney. All rights reserved.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Dict, Any, List

from .client import APIClient, APIError


@dataclass
class Tokens:
    access_token: str
    refresh_token: Optional[str]
    expires_in: Optional[int] = None


@dataclass
class ApiKeyInfo:
    """API key information (without full key)."""
    key_id: str
    key_prefix: str
    name: str
    tier: str
    status: str
    scopes: List[str]
    created_at: Optional[str] = None
    last_used_at: Optional[str] = None
    expires_at: Optional[str] = None


@dataclass
class NewApiKey:
    """Newly created API key (full key shown ONCE!)."""
    key: str  # Full key - SAVE THIS!
    key_id: str
    key_prefix: str
    name: str
    tier: str
    scopes: List[str]
    expires_at: Optional[str] = None


class AuthClient:
    """Auth helper for QuantJourney SDK.

    Provides login/refresh/whoami and API key management.
    Wires tokens into the underlying APIClient.

    Auth requests (login, refresh, whoami) are routed to ``auth_url``
    (defaults to ``https://auth.quantjourney.cloud``) while all data
    requests stay on ``api_url``.  This ensures a single token issuer
    (RS256) and clean separation of identity vs data planes.
    """

    def __init__(self, api_client: APIClient):
        self._api = api_client

    # ── helpers to POST against the auth service ────────────────
    def _auth_post(self, path: str, payload: dict) -> dict:
        """POST to auth_url + path, returning parsed JSON."""
        import requests as _requests
        url = f"{self._api.auth_url}{path}"
        headers = {"Content-Type": "application/json"}
        bearer = self._api.session.headers.get("Authorization")
        if bearer:
            headers["Authorization"] = bearer
        resp = _requests.post(url, json=payload, headers=headers, timeout=self._api.timeout)
        resp.raise_for_status()
        return resp.json()

    def _auth_get(self, path: str, params: dict | None = None) -> dict:
        """GET from auth_url + path, returning parsed JSON."""
        import requests as _requests
        url = f"{self._api.auth_url}{path}"
        headers = {}
        bearer = self._api.session.headers.get("Authorization")
        if bearer:
            headers["Authorization"] = bearer
        resp = _requests.get(url, params=params, headers=headers, timeout=self._api.timeout)
        resp.raise_for_status()
        return resp.json()

    def login(self, email: str, password: str, tenant_id: str = "") -> Tokens:
        payload = {"email": email, "password": password}
        if tenant_id:
            payload["tenant_id"] = tenant_id
        doc = self._auth_post("/auth/login", payload)
        # /auth/login returns a structured object (not wrapped in success)
        access = doc.get("access_token")
        refresh = doc.get("refresh_token")
        if not access:
            raise APIError("Login did not return access_token")
        self._api.set_bearer_tokens(access, refresh)
        # If tenant header was not set explicitly, derive from token claims via whoami
        try:
            w = self.whoami()
            tid = w.get("tenant_id")
            if tid:
                self._api.set_tenant(tid)
        except Exception:
            pass
        return Tokens(access_token=access, refresh_token=refresh, expires_in=doc.get("expires_in"))

    def refresh(self) -> Tokens:
        if not getattr(self._api, "_refresh_token", None):
            raise APIError("No refresh token available")
        doc = self._auth_post("/auth/refresh", {"refresh_token": self._api._refresh_token})
        access = doc.get("access_token")
        refresh = doc.get("refresh_token") or self._api._refresh_token
        if not access:
            raise APIError("Refresh did not return access_token")
        self._api.set_bearer_tokens(access, refresh)
        return Tokens(access_token=access, refresh_token=refresh, expires_in=doc.get("expires_in"))

    def whoami(self) -> Dict[str, Any]:
        return self._auth_get("/auth/whoami")

    # =========================================================================
    # API Key Management (QJ_ keys)
    # =========================================================================
    
    def create_api_key(
        self,
        name: str,
        scopes: Optional[List[str]] = None,
        tier: str = "free",
        expires_days: Optional[int] = None,
    ) -> NewApiKey:
        """
        Generate a new API key for the authenticated user.
        
        **IMPORTANT**: The full key is returned ONLY ONCE! Save it securely.
        
        Args:
            name: Human-readable name for the key (e.g., "Production", "CI/CD")
            scopes: List of scopes (default: inherit user scopes)
            tier: Pricing tier (free/pro/enterprise)
            expires_days: Days until expiration (None = permanent)
        
        Returns:
            NewApiKey with the full key (save it!)
        
        Example:
            >>> key = qj.auth.create_api_key("Production", tier="pro")
            >>> print(f"SAVE THIS: {key.key}")
            >>> # Use it: qj = QuantJourneyAPI(api_key=key.key)
        """
        payload: Dict[str, Any] = {"name": name, "tier": tier}
        if scopes:
            payload["scopes"] = scopes
        if expires_days:
            payload["expires_days"] = expires_days
        
        doc = self._api._request(endpoint="/auth/api-keys", payload=payload)
        
        return NewApiKey(
            key=doc["key"],
            key_id=doc["key_id"],
            key_prefix=doc["key_prefix"],
            name=doc["name"],
            tier=doc["tier"],
            scopes=doc.get("scopes", []),
            expires_at=doc.get("expires_at"),
        )
    
    def list_api_keys(self) -> List[ApiKeyInfo]:
        """
        List all API keys for the authenticated user.
        
        Returns masked keys (key_prefix only, not full keys).
        
        Returns:
            List of ApiKeyInfo objects
        """
        docs = self._api.get("/auth/api-keys")
        return [
            ApiKeyInfo(
                key_id=d["key_id"],
                key_prefix=d["key_prefix"],
                name=d["name"],
                tier=d["tier"],
                status=d["status"],
                scopes=d.get("scopes", []),
                created_at=d.get("created_at"),
                last_used_at=d.get("last_used_at"),
                expires_at=d.get("expires_at"),
            )
            for d in docs
        ]
    
    def revoke_api_key(self, key_id: str) -> Dict[str, Any]:
        """
        Permanently revoke an API key.
        
        The key will immediately stop working and cannot be reactivated.
        
        Args:
            key_id: The key ID (from list_api_keys or create_api_key)
        
        Returns:
            {"status": "revoked", "key_id": "..."}
        """
        return self._api._request_with_method("DELETE", f"/auth/api-keys/{key_id}")
    
    def suspend_api_key(self, key_id: str) -> Dict[str, Any]:
        """
        Temporarily suspend an API key.
        
        The key will stop working but can be reactivated later.
        
        Args:
            key_id: The key ID
        
        Returns:
            {"status": "suspended", "key_id": "..."}
        """
        return self._api._request_with_method("PATCH", f"/auth/api-keys/{key_id}/suspend")
    
    def reactivate_api_key(self, key_id: str) -> Dict[str, Any]:
        """
        Reactivate a suspended API key.
        
        Only works for suspended keys (not revoked).
        
        Args:
            key_id: The key ID
        
        Returns:
            {"status": "active", "key_id": "..."}
        """
        return self._api._request_with_method("PATCH", f"/auth/api-keys/{key_id}/reactivate")

