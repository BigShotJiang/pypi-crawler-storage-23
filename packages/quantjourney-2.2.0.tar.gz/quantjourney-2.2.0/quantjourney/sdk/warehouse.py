"""
QuantJourney SDK — Data Warehouse client.

Provides typed methods for all /data/v1/* warehouse proxy endpoints.

Usage:
    from quantjourney.sdk import QuantJourney

    qj = QuantJourney()
    qj.auth.login(tenant_id="default", user_id="...", password="...")

    # Prices
    bars = qj.warehouse.prices("AAPL", start="2025-01-01", limit=100)
    latest = qj.warehouse.latest("AAPL")
    returns = qj.warehouse.returns("AAPL")
    batch = qj.warehouse.prices_batch(["AAPL", "MSFT", "GOOGL"], limit=10)

    # Instruments
    results = qj.warehouse.search("apple")
    instruments = qj.warehouse.instruments_list(sector="Technology", limit=20)
    profile = qj.warehouse.instrument("AAPL")

    # Coverage
    catalog = qj.warehouse.coverage(limit=50)
    detail = qj.warehouse.coverage_ticker("AAPL")

    # Cache
    status = qj.warehouse.cache_status()
    qj.warehouse.cache_refresh()

    # Health
    qj.warehouse.health()
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .client import APIClient


class WarehouseClient:
    """SDK client for Data Warehouse endpoints (/data/v1/*)."""

    PREFIX = "/data/v1"

    def __init__(self, api_client: APIClient):
        self._api = api_client

    # ── Prices ─────────────────────────────────────────────

    def prices(self, ticker: str, *,
               start: Optional[str] = None,
               end: Optional[str] = None,
               resolution: str = "1d",
               source: Optional[str] = None,
               limit: int = 1000,
               offset: int = 0) -> Dict[str, Any]:
        """Historical OHLCV bars for a ticker.

        Args:
            ticker: Instrument ticker (e.g. "AAPL").
            start: Start date (YYYY-MM-DD). Default: 1 year ago.
            end: End date (YYYY-MM-DD). Default: today.
            resolution: Bar resolution — "1d", "1w", or "1m".
            source: Filter by data source.
            limit: Max bars (≤ 10000).
            offset: Pagination offset.

        Returns:
            Dict with keys: ticker, instrument_id, resolution, count, has_more, bars.
        """
        params: Dict[str, Any] = {
            "resolution": resolution,
            "limit": limit,
            "offset": offset,
        }
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        if source:
            params["source"] = source
        return self._api.get(f"{self.PREFIX}/prices/{ticker}", params=params)

    def latest(self, ticker: str) -> Dict[str, Any]:
        """Latest price snapshot for a ticker.

        Returns:
            Dict with keys: ticker, instrument_id, close, adj_close, volume, time, change_pct.
        """
        return self._api.get(f"{self.PREFIX}/prices/{ticker}/latest")

    def returns(self, ticker: str) -> Dict[str, Any]:
        """Multi-period returns (1d, 1w, 1m, 3m, 6m, 1y, YTD) for a ticker.

        Returns:
            Dict with keys: ticker, returns (sub-dict with period keys).
        """
        return self._api.get(f"{self.PREFIX}/prices/{ticker}/returns")

    def prices_batch(self, tickers: List[str], *,
                     start: Optional[str] = None,
                     end: Optional[str] = None,
                     limit: int = 1000) -> Any:
        """Batch prices for multiple tickers.

        Args:
            tickers: List of ticker symbols.
            start: Start date (YYYY-MM-DD).
            end: End date (YYYY-MM-DD).
            limit: Max bars per ticker.

        Returns:
            List of price results per ticker.
        """
        body: Dict[str, Any] = {"tickers": tickers, "limit": limit}
        if start:
            body["start"] = start
        if end:
            body["end"] = end
        return self._api.post(f"{self.PREFIX}/prices/batch", json=body)

    # ── Instruments ────────────────────────────────────────

    def search(self, query: str, *, limit: int = 10) -> Any:
        """Fuzzy search instruments by ticker or name.

        Uses pg_trgm trigram matching. Results sorted by relevance.

        Args:
            query: Search term (e.g. "apple", "TSLA", "gold").
            limit: Max results.

        Returns:
            List of instrument dicts with score field.
        """
        return self._api.get(f"{self.PREFIX}/instruments/search",
                             params={"q": query, "limit": limit})

    def instruments_list(self, *,
                         exchange: Optional[str] = None,
                         sector: Optional[str] = None,
                         industry: Optional[str] = None,
                         country: Optional[str] = None,
                         instrument_type: Optional[str] = None,
                         is_active: Optional[bool] = None,
                         is_etf: Optional[bool] = None,
                         is_fund: Optional[bool] = None,
                         ticker: Optional[str] = None,
                         cik: Optional[str] = None,
                         isin: Optional[str] = None,
                         figi: Optional[str] = None,
                         limit: int = 100,
                         offset: int = 0) -> Any:
        """List instruments with filters.

        Args:
            exchange: Filter by exchange (e.g. "NASDAQ").
            sector: Filter by sector (e.g. "Technology").
            industry: Filter by industry (partial match).
            country: Filter by country code (e.g. "US").
            instrument_type: Filter by type (e.g. "COMMON", "ETF").
            is_active: Active instruments only (default: True).
            is_etf: ETFs only.
            is_fund: Funds only.
            ticker: Exact ticker match.
            cik: SEC CIK lookup.
            isin: ISIN lookup.
            figi: FIGI lookup.
            limit: Max results (≤ 100).
            offset: Pagination offset.

        Returns:
            List of instrument dicts.
        """
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        for key, val in [
            ("exchange", exchange), ("sector", sector),
            ("industry", industry), ("country", country),
            ("instrument_type", instrument_type),
            ("is_active", is_active), ("is_etf", is_etf),
            ("is_fund", is_fund), ("ticker", ticker),
            ("cik", cik), ("isin", isin), ("figi", figi),
        ]:
            if val is not None:
                params[key] = val
        return self._api.get(f"{self.PREFIX}/instruments/list", params=params)

    def instrument(self, ticker: str) -> Dict[str, Any]:
        """Full instrument profile including FIGI, CIK, ISIN, CUSIP.

        Args:
            ticker: Instrument ticker.

        Returns:
            Dict with 19+ fields: ticker, name, exchange, sector, industry,
            cik, isin, cusip, figi, composite_figi, mic_code, ipo_date, etc.
        """
        return self._api.get(f"{self.PREFIX}/instruments/{ticker}")

    # ── Coverage ───────────────────────────────────────────

    def coverage(self, *,
                 exchange: Optional[str] = None,
                 sector: Optional[str] = None,
                 stale_days: Optional[int] = None,
                 limit: int = 100,
                 offset: int = 0) -> Any:
        """Data coverage catalog — freshness per instrument.

        Args:
            exchange: Filter by exchange.
            sector: Filter by sector.
            stale_days: Only instruments stale > N days.
            limit: Max results (≤ 500).
            offset: Pagination offset.

        Returns:
            Dict with count, instruments, and freshness metrics.
        """
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if exchange:
            params["exchange"] = exchange
        if sector:
            params["sector"] = sector
        if stale_days is not None:
            params["stale_days"] = stale_days
        return self._api.get(f"{self.PREFIX}/coverage", params=params)

    def coverage_ticker(self, ticker: str) -> Dict[str, Any]:
        """Per-ticker coverage detail.

        Returns:
            Dict with date range, bar count, gap count, quality score.
        """
        return self._api.get(f"{self.PREFIX}/coverage/{ticker}")

    # ── Cache ──────────────────────────────────────────────

    def cache_status(self) -> Dict[str, Any]:
        """Materialized view statistics (row counts, sizes, last refresh).

        Returns:
            Dict with status per view (cagg_prices_daily, mv_latest_prices, etc.).
        """
        return self._api.get(f"{self.PREFIX}/cache/status")

    def cache_refresh(self) -> Dict[str, Any]:
        """Manually trigger materialized view refresh.

        Returns:
            Dict with refresh result per view.
        """
        return self._api.post(f"{self.PREFIX}/cache/refresh")

    # ── Health ─────────────────────────────────────────────

    def health(self) -> Dict[str, Any]:
        """Check warehouse backend connectivity.

        Returns:
            Dict with status from warehouse backend.
        """
        return self._api.get(f"{self.PREFIX}/health")
