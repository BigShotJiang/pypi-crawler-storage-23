"""
QuantJourney SDK – Domains Client
=================================

Wraps the ``/d/`` domain-routing layer which provides a unified,
provider-agnostic interface to financial data.

Classes
-------
DomainsClient
    Exposes domain discovery (list / tree / aliases / describe) and
    an explicit ``call()`` method for invoking any domain route by name.

DomainProxy
    Returned by ``__getattr__`` — enables dot-chained calls like
    ``qj.domains.equities.fundamentals.get_income_statement(symbol="AAPL")``.

Usage::

    qj = QuantJourneyAPI.from_env()

    # Discovery
    routes   = qj.domains.list()          # GET /d/
    tree     = qj.domains.tree()          # GET /d/tree
    aliases  = qj.domains.aliases()       # GET /d/aliases
    synonyms = qj.domains.synonyms()      # GET /d/synonyms
    info     = qj.domains.describe("equities.fundamentals.get_income_statement")

    # Invoke by name
    data = qj.domains.call("equities.fundamentals.get_income_statement",
                           symbol="AAPL", period="annual")

    # Dot-chained shorthand (same result)
    data = qj.domains.equities.fundamentals.get_income_statement(
        symbol="AAPL", period="annual",
    )

Copyright (c) 2024-2026 QuantJourney. All rights reserved.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .client import APIClient


# ---------------------------------------------------------------------------
# DomainProxy – dot-chained dynamic accessor
# ---------------------------------------------------------------------------

class DomainProxy:
    """Chainable proxy for domain routes.

    Attribute access builds up a dotted path.  When the final segment looks
    like a method name (``get_*``, ``list_*``, ``search_*``, ``fetch_*``),
    it returns a callable that POSTs to ``/d/<path>``.
    """

    __slots__ = ("_api", "_path")

    def __init__(self, api_client: "APIClient", path: str):
        self._api = api_client
        self._path = path

    # ---- attribute access → build path or call ----
    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        if name.startswith(("get_", "search_", "list_", "fetch_")):
            route = f"{self._path}.{name}"

            def _call(**payload: Any) -> Any:
                return self._api._request(endpoint=f"/d/{route}", payload=payload)

            _call.__doc__ = f"POST /d/{route}"
            _call.__name__ = name
            return _call
        # keep chaining (subdomain)
        return DomainProxy(self._api, f"{self._path}.{name}")

    def __repr__(self) -> str:
        return f"DomainProxy({self._path!r})"


# ---------------------------------------------------------------------------
# DomainsClient – explicit discovery + call helpers
# ---------------------------------------------------------------------------

class DomainsClient:
    """High-level client for the ``/d/`` domain routing layer.

    Parameters
    ----------
    api_client : APIClient
        The low-level SDK HTTP client (sync).
    """

    def __init__(self, api_client: "APIClient"):
        self._api = api_client

    # ---- Discovery endpoints (GET) ----

    def list(self) -> Dict[str, Any]:
        """List all registered domain routes.

        Returns
        -------
        dict
            ``{"count": int, "routes": [...], "aliases_count": int, ...}``
        """
        return self._api.get("/d/")

    def tree(
        self,
        scope: str = "all",
        include_aliases: bool = True,
        include_unavailable: bool = True,
    ) -> Dict[str, Any]:
        """Return a hierarchical tree of domain routes.

        Parameters
        ----------
        scope : str
            ``"all"`` (default) or ``"effective"`` (tenant-specific).
        include_aliases : bool
            Include alias list per route.
        include_unavailable : bool
            When *scope='effective'*, include unavailable providers.

        Returns
        -------
        dict
            ``{"scope": str, "routes_count": int, "tree": {...}}``
        """
        params: Dict[str, Any] = {
            "scope": scope,
            "include_aliases": str(include_aliases).lower(),
            "include_unavailable": str(include_unavailable).lower(),
        }
        return self._api.get("/d/tree", params=params)

    def aliases(self) -> Dict[str, Any]:
        """Return the alias → canonical mapping.

        Returns
        -------
        dict
            ``{"count": int, "aliases": {alias: canonical, ...}}``
        """
        return self._api.get("/d/aliases")

    def synonyms(self) -> Dict[str, Any]:
        """Return top-level and subdomain synonym/abbreviation maps.

        Returns
        -------
        dict
            ``{"top_level": {...}, "subdomains": {...}}``
        """
        return self._api.get("/d/synonyms")

    def describe(self, route_path: str) -> Dict[str, Any]:
        """Describe a specific domain route.

        Parameters
        ----------
        route_path : str
            Canonical or alias id, e.g. ``"equities.fundamentals.get_income_statement"``.

        Returns
        -------
        dict
            Provider list, priority, chosen provider, existence flag.
        """
        return self._api.get(f"/d/describe/{route_path}")

    # ---- Invocation ----

    def call(self, route: str, **payload: Any) -> Any:
        """Invoke a domain route by name.

        Parameters
        ----------
        route : str
            Dotted domain route, e.g. ``"equities.get_pricing"``.
        **payload
            Key-value pairs forwarded as JSON body.

        Returns
        -------
        Any
            Parsed response data from the domain layer.
        """
        return self._api._request(endpoint=f"/d/{route}", payload=payload)

    # ---- Dynamic attribute access → DomainProxy ----

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        return DomainProxy(self._api, name)

    def __repr__(self) -> str:
        return f"DomainsClient(base_url={self._api.base_url!r})"
