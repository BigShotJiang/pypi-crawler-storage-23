# quantjourney

Python SDK for [api.quantjourney.cloud](https://api.quantjourney.cloud) — financial data API.

## Install

```bash
pip install quantjourney
```

## Quick Start

### With API key

```python
from quantjourney.sdk import QuantJourneyAPI

qj = QuantJourneyAPI(token="your-api-key")
prices = qj.fmp.get_historical_prices(symbol="AAPL")
```

### With email / password

```python
from quantjourney.sdk import QuantJourneyAPI

qj = QuantJourneyAPI()
qj.auth.login(email="you@example.com", password="...")
prices = qj.fmp.get_historical_prices(symbol="AAPL")
```

## User Portal

Manage your account at [users.quantjourney.cloud](https://users.quantjourney.cloud):

- **API Keys** — generate and manage API keys for SDK access
- **Data Sources** — add your own keys for premium connectors (FMP, EOD, Tiingo, …)
- **AI Models** — add your OpenAI / Anthropic / Google AI keys for Copilot

Free connectors (FRED, SEC, OECD, World Bank, …) work without additional configuration.

## Migration from 1.x

```python
# Before (1.x):
from quantjourney_sdk import QuantJourneyAPI

# After (2.0):
from quantjourney.sdk import QuantJourneyAPI
```

## Links

- [API Documentation](https://docs.quantjourney.cloud)
- [Terms of Use](https://quantjourney.cloud/terms-of-usage)
- [Privacy Policy](https://quantjourney.cloud/privacy-policy)
