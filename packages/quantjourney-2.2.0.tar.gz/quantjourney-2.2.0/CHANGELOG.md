# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.2.0] — 2026-02-24

**Requires API ≥ 3.7** · Python ≥ 3.10

### Added
- **`DomainsClient`** — new high-level client for the `/d/` domain routing layer
  - `qj.domains.call(route, **params)` — invoke any domain route by name
- **Integration test suite** (`tests/`) — 27 pytest tests covering domains + connectors
  - `test_domains.py` — 18 tests (unit + integration): list, tree, aliases, synonyms, describe, call, dot-chain, alias resolve
  - `test_connectors.py` — 9 tests: FMP, YF, FRED, EOD, auth
- `.env.example` — template for test configuration

---

## [2.1.0] — 2026-02-24

**Requires API ≥ 3.7** · Python ≥ 3.10

### Breaking Changes
- **Auth routing**: SDK now sends login, refresh, and whoami requests to
  dedicated auth service (RS256 tokens) instead of previous `api.quantjourney.cloud`
  (HS256). Existing API-key users are **not affected** — only email/password
  login flows change.

### Added
- `auth_url` parameter on `QuantJourneyAPI`, `APIClient`, and `AsyncAPIClient`
- `QJ_AUTH_URL` environment variable support in `QuantJourneyAPI.from_env()`
- `AuthClient._auth_post()` / `_auth_get()` helpers for dedicated auth-service
  communication
- Automatic token refresh now uses `auth_url`

### Changed
- AuthClient now routes authentication via `auth_url`
- Tokens migrated from HS256 to RS256
- Default token TTL reduced to 5 minutes (from 60 minutes)

### Migration from 2.0

```python
# No code changes needed for most users.

# If you need a custom auth URL:
qj = QuantJourneyAPI(auth_url="https://my-auth.example.com")

# Or via environment:
export QJ_AUTH_URL=https://my-auth.example.com
```

## [2.0.0] — 2026-02-17

**Requires API ≥ 3.7** · Python ≥ 3.10

### Breaking Changes
- **Package renamed**: `quantjourney-sdk` → `quantjourney` (matches PyPI name)
- **Import path changed**: `from quantjourney_sdk import ...` → `from quantjourney.sdk import ...`
- **Python version**: now supports `>=3.10` (previously `>=3.12`)

### Added — SDK
- Full docstrings on `APIClient` and `AsyncAPIClient`
- `AsyncAPIClient` — full async support via `httpx` (`pip install quantjourney[async]`)
- Connection pooling configuration (`pool_connections`, `pool_maxsize`)
- Configurable timeouts (`connect_timeout`, `read_timeout`, `write_timeout`)
- `DomainResponse` wrapper with `.meta` attribute for domain API calls
- ETag caching for GET requests (leverages API 3.7 ETag support)
- `X-Request-ID` header for request tracing (leverages API 3.7 header propagation)
- `DomainProxy` for `qj.<domain>.<method>(...)` syntax
- `WarehouseClient` for data warehouse operations (API 3.5+)
- `AuthClient` with token refresh support (API 3.1+)
- Full connector endpoints for all 16 data providers
- `[all]`, `[async]`, `[pandas]`, `[dev]` optional dependency groups
- PyPI publish tooling (Makefile, CHANGELOG, LICENSE)

### Added — API features supported (since SDK 1.0.4)
- API 4.4 (2026-02-12): Backtesting endpoints, benchmark endpoints (SPY, QQQ, Russell 2000, Dow Jones)
- API 4.3 (2026-02-11): Streamable HTTP MCP protocol, QJ Data warehouse query endpoints
- API 4.1 (2026-02-07): MCP (Model Context Protocol) support
- API 4.0 (2026-02-01): Async SDK support, throttling mechanism
- API 3.9 (2026-01-28): US Government connectors (Treasury, BLS, BEA, Census), Energy (EIA), Agriculture (USDA), International (World Bank, Eurostat), Central Banks (BoC, RBA, SNB), Tiingo
- API 3.8 (2026-01-27): OpenAI/Gemini/Anthropic AI connectors
- API 3.7 (2026-01-25): RFC 7807 error responses, X-Request-ID, ETag, API key expiration
- API 3.5 (2026-01-09): Data Warehouse endpoints and connector
- API 3.4 (2026-01-06): FMP analyst estimates, dividends, earnings
- API 3.3 (2025-12-29): FMP universe screening, bulk EOD, connection pooling

### Migration from 1.x

```python
# Before (1.x):
from quantjourney_sdk import QuantJourneyAPI
# or
pip install quantjourney-sdk

# After (2.0):
from quantjourney.sdk import QuantJourneyAPI
# or
pip install quantjourney
```

## [1.0.4] — 2025-12-01

- Previous PyPI release under `quantjourney` name
- Basic sync HTTP client, 6 connectors

## [1.0.0] — 2025-10-01

- Initial SDK release as `quantjourney-sdk`
- Auto-generated connector methods from `routers.yaml`
- Supported API 1.5+
