"""Turtle MCP Server entry point."""

from turtle_mcp.server import main

if __name__ == "__main__":
    main()
