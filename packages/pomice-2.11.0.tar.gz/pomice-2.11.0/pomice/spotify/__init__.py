"""Spotify module for Pomice, made possible by cloudwithax 2023"""
from .client import Client
from .exceptions import *
from .objects import *
