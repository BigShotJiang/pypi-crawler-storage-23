"""Apple Music module for Pomice, made possible by cloudwithax 2023"""
from .client import *
from .exceptions import *
from .objects import *
