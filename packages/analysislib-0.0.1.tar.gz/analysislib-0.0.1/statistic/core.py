import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm
from scipy import stats


def calculate_statistics(y):
    mean_y = np.mean(y)
    var_y = np.var(y, ddof=1)
    return mean_y, var_y


def fit_regression(x, y):
    X = sm.add_constant(x)
    model = sm.OLS(y, X).fit()
    RSS = np.sum(model.resid ** 2)
    return model, RSS


def moving_average(y, window=3):
    return np.convolve(y, np.ones(window)/window, mode='valid')


def chow_test(x, y, break_point):
    n = len(x)
    k = 2

    model_all, RSS_all = fit_regression(x, y)

    model1, RSS1 = fit_regression(x[:break_point], y[:break_point])

    model2, RSS2 = fit_regression(x[break_point:], y[break_point:])

    n1 = break_point
    n2 = n - break_point

    F = ((RSS_all - (RSS1 + RSS2)) / k) / ((RSS1 + RSS2) / (n1 + n2 - 2 * k))
    p_value = 1 - stats.f.cdf(F, k, n1 + n2 - 2 * k)

    return F, p_value, model_all, model1, model2


def fourier_analysis(y):
    n = len(y)
    fft_vals = np.fft.fft(y)
    fft_freq = np.fft.fftfreq(n)

    positive = fft_freq > 0

    return fft_freq[positive], np.abs(fft_vals[positive])


def plot_moving_average(x, y, window=3):
    ma = moving_average(y, window)
    x_ma = x[window-1:]

    plt.figure(figsize=(10, 5))
    plt.plot(x, y, label="Исходный ряд", alpha=0.5)
    plt.plot(x_ma, ma, label=f"Скользящее среднее (окно={window})", linewidth=2)

    plt.title("Скользящее среднее")
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.legend()
    plt.grid(True)
    plt.show()


def plot_fourier(y):
    freqs, amplitudes = fourier_analysis(y)

    plt.figure(figsize=(10, 5))
    plt.stem(freqs, amplitudes, basefmt=" ")
    plt.title("Спектр Фурье")
    plt.xlabel("Частота")
    plt.ylabel("Амплитуда")
    plt.grid(True)
    plt.show()


def plot_chow(x, y, break_point, model_all, model1, model2, F, p_value):
    mean_y = np.mean(y)
    var_y = np.var(y, ddof=1)

    X_all = sm.add_constant(x)
    y_pred_all = model_all.predict(X_all)

    X1 = sm.add_constant(x[:break_point])
    X2 = sm.add_constant(x[break_point:])

    y_pred_part = np.concatenate([
        model1.predict(X1),
        model2.predict(X2)
    ])

    width = 0.25
    indices = np.arange(len(x))

    fig = plt.figure(figsize=(14, 6))
    gs = fig.add_gridspec(1, 2, width_ratios=[3, 1])

    ax_plot = fig.add_subplot(gs[0])
    ax_stats = fig.add_subplot(gs[1])

    ax_plot.bar(indices - width, y, width=width, label="Фактические данные")
    ax_plot.bar(indices, y_pred_all, width=width, label="Общая регрессия")
    ax_plot.bar(indices + width, y_pred_part, width=width, label="Регрессия по частям")

    ax_plot.axvline(x=break_point - 0.5, color='red', linestyle='--', label="Точка разрыва")

    ax_plot.set_xticks(indices)
    ax_plot.set_xticklabels(x, rotation=90)
    ax_plot.set_xlabel("X")

    ax_top = ax_plot.twiny()
    ax_top.set_xlim(ax_plot.get_xlim())
    ax_top.set_xticks(indices)
    ax_top.set_xticklabels(np.arange(1, len(x) + 1))
    ax_top.tick_params(axis='x', rotation=90)

    ax_plot.set_ylabel("Y")
    ax_plot.set_title("Тест Чоу")
    ax_plot.legend()
    ax_plot.grid(axis='y')

    ax_stats.axis("off")

    table_data = [
        ["Мат ожидание", f"{mean_y:.3f}"],
        ["Дисперсия", f"{var_y:.3f}"],
        ["F-статистика", f"{F:.3f}"],
        ["p-value", f"{p_value:.3f}"],
        ["Результат",
         "Есть сдвиг" if p_value < 0.05 else "Сдвига нет"]
    ]

    table = ax_stats.table(cellText=table_data,
                           colLabels=["Показатель", "Значение"],
                           loc="center")

    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1.1, 1.5)

    ax_stats.set_title("Статистика")

    plt.tight_layout()
    plt.show()


def get_statistics(x, y, break_point):
    F, p_value, model_all, model1, model2 = chow_test(x, y, break_point)

    plot_chow(x, y, break_point, model_all, model1, model2, F, p_value)    

    plot_moving_average(x, y, window=3)

    plot_fourier(y)
