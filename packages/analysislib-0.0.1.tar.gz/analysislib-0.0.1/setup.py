from setuptools import setup, find_packages


def readme():
    with open('README.md', 'r', encoding='utf-8') as f:
        return f.read()


setup(
    name='analysislib',
    version='0.0.1',
    author='egor_kh',
    author_email='egorkharitonchik@gmail.com',
    description='Statistical time series analysis tools with Chow test and Fourier analysis.',
    long_description=readme(),
    long_description_content_type='text/markdown',
    packages=find_packages(),
    install_requires=[
        'requests>=2.25.1'
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.14',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    keywords='statistics time-series chow-test fourier',
    python_requires='>=3.9',
)