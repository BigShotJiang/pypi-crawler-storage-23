import io
import json
import zipfile
from abc import ABC, abstractmethod
from collections import defaultdict
from collections.abc import Hashable, Iterable, Iterator, Sequence
from functools import cached_property
from pathlib import Path
from typing import Generic

import questionary
import typer
from cognite.client import data_modeling as dm
from cognite.client.data_classes import (
    filters,
)
from cognite.client.data_classes.data_modeling import ViewId
from cognite.client.data_classes.documents import SourceFileProperty
from cognite.client.data_classes.functions import (
    Function,
)
from cognite.client.exceptions import CogniteAPIError
from cognite.client.utils import ms_to_datetime
from questionary import Choice
from rich import print
from rich.console import Console
from rich.panel import Panel

from cognite_toolkit._cdf_tk.client import ToolkitClient
from cognite_toolkit._cdf_tk.client.http_client import ToolkitAPIError
from cognite_toolkit._cdf_tk.client.request_classes.filters import DataModelFilter, StreamlitFilter, ViewFilter
from cognite_toolkit._cdf_tk.client.resource_classes.agent import AgentResponse
from cognite_toolkit._cdf_tk.client.resource_classes.data_modeling import (
    ContainerReference,
    DataModelReference,
    DataModelReferenceNoVersion,
    DataModelResponse,
    SpaceReference,
    SpaceResponse,
    ViewReference,
    ViewReferenceNoVersion,
    ViewResponse,
)
from cognite_toolkit._cdf_tk.client.resource_classes.dataset import DataSetResponse
from cognite_toolkit._cdf_tk.client.resource_classes.extraction_pipeline import ExtractionPipelineResponse
from cognite_toolkit._cdf_tk.client.resource_classes.function import FunctionResponse
from cognite_toolkit._cdf_tk.client.resource_classes.group import GroupResponse
from cognite_toolkit._cdf_tk.client.resource_classes.identifiers import (
    ExternalId,
    NameId,
    WorkflowVersionId,
)
from cognite_toolkit._cdf_tk.client.resource_classes.instance_api import TypedViewReference
from cognite_toolkit._cdf_tk.client.resource_classes.location_filter import LocationFilterResponse
from cognite_toolkit._cdf_tk.client.resource_classes.resource_view_mapping import ResourceViewMappingResponse
from cognite_toolkit._cdf_tk.client.resource_classes.search_config import SearchConfigResponse
from cognite_toolkit._cdf_tk.client.resource_classes.streamlit_ import StreamlitResponse
from cognite_toolkit._cdf_tk.client.resource_classes.transformation import TransformationResponse
from cognite_toolkit._cdf_tk.client.resource_classes.workflow import WorkflowResponse
from cognite_toolkit._cdf_tk.client.resource_classes.workflow_version import WorkflowVersionResponse
from cognite_toolkit._cdf_tk.cruds import (
    AgentCRUD,
    ContainerCRUD,
    DataModelCRUD,
    DataSetsCRUD,
    ExtractionPipelineConfigCRUD,
    ExtractionPipelineCRUD,
    FunctionCRUD,
    FunctionScheduleCRUD,
    GroupCRUD,
    LocationFilterCRUD,
    NodeCRUD,
    ResourceCRUD,
    ResourceViewMappingCRUD,
    SearchConfigCRUD,
    SpaceCRUD,
    StreamlitCRUD,
    TransformationCRUD,
    TransformationNotificationCRUD,
    TransformationScheduleCRUD,
    ViewCRUD,
    WorkflowCRUD,
    WorkflowTriggerCRUD,
    WorkflowVersionCRUD,
)
from cognite_toolkit._cdf_tk.cruds._base_cruds import T_ID
from cognite_toolkit._cdf_tk.exceptions import (
    ResourceRetrievalError,
    ToolkitMissingResourceError,
    ToolkitResourceMissingError,
    ToolkitValueError,
)
from cognite_toolkit._cdf_tk.protocols import ResourceResponseProtocol
from cognite_toolkit._cdf_tk.tk_warnings import FileExistsWarning, HighSeverityWarning, MediumSeverityWarning
from cognite_toolkit._cdf_tk.utils import humanize_collection
from cognite_toolkit._cdf_tk.utils.file import safe_rmtree, safe_write, sanitize_filename, yaml_safe_dump
from cognite_toolkit._cdf_tk.utils.interactive_select import DataModelingSelect

from ._base import ToolkitCommand

_INTERACTIVE_SELECT_HELPER_TEXT = " Use arrow keys to navigate and space key to select. Press enter to confirm."


class ResourceFinder(Iterable, ABC, Generic[T_ID]):
    def __init__(self, client: ToolkitClient, identifier: T_ID | None = None):
        self.client = client
        self.identifier = identifier

    def _selected(self) -> T_ID:
        return self.identifier or self._interactive_select()

    @abstractmethod
    def __iter__(
        self,
    ) -> Iterator[tuple[Sequence[Hashable], Sequence[ResourceResponseProtocol] | None, ResourceCRUD, None | str]]:
        raise NotImplementedError

    @abstractmethod
    def _interactive_select(self) -> T_ID:
        raise NotImplementedError

    # Can be implemented in subclasses
    def update(self, resources: Sequence[ResourceResponseProtocol]) -> None: ...


class DataModelFinder(ResourceFinder[DataModelReferenceNoVersion]):
    def __init__(
        self, client: ToolkitClient, identifier: DataModelReferenceNoVersion | None = None, include_global: bool = False
    ):
        super().__init__(client, identifier)
        self._include_global = include_global
        self.data_model: DataModelResponse | None = None
        self.view_ids: set[ViewReference] = set()
        self.container_ids: set[ContainerReference] = set()
        self.space_ids: set[SpaceReference] = set()

    def _interactive_select(self) -> DataModelReference:
        all_models = self.client.tool.data_models.list(
            filter=DataModelFilter(all_versions=False, include_global=self._include_global)
        )
        data_model_ids = [model.as_id() for model in all_models]
        available_spaces = sorted({model.space for model in data_model_ids})
        if not available_spaces:
            raise ToolkitMissingResourceError("No data models found")
        if len(available_spaces) == 1:
            selected_space = available_spaces[0]
        else:
            selected_space = questionary.select(
                "In which space is your data model located?", available_spaces
            ).unsafe_ask()
        data_model_ids = sorted(
            [model for model in data_model_ids if model.space == selected_space],
            key=lambda model: (model.space, model.external_id, model.version),
        )

        selected_data_model: DataModelReference = questionary.select(
            "Which data model would you like to dump?",
            [
                Choice(f"{model_id!r}", value=model_id)
                for model_id in sorted(
                    data_model_ids, key=lambda model: (model.space, model.external_id, model.version)
                )
            ],
        ).unsafe_ask()

        all_versions = self.client.tool.data_models.retrieve(
            [DataModelReferenceNoVersion(space=selected_space, external_id=selected_data_model.external_id)]
        )
        retrieved_models = [m for m in all_versions if m.external_id == selected_data_model.external_id]
        if not retrieved_models:
            # This happens if the data model is removed after the list call above.
            raise ToolkitMissingResourceError(f"Data model {selected_data_model} not found")
        if len(retrieved_models) == 1:
            self.data_model = retrieved_models[0]
            return selected_data_model
        models_by_version = {model.version: model for model in retrieved_models}
        if len(models_by_version) == 1:
            self.data_model = retrieved_models[0]
            return selected_data_model
        if not questionary.confirm(
            f"Would you like to select a different version than {selected_data_model.version} of the data model",
            default=False,
        ).unsafe_ask():
            self.data_model = models_by_version[selected_data_model.version]
            return selected_data_model

        selected_model = questionary.select(
            "Which version would you like to dump?",
            [
                Choice(f"{version} ({len(model.views or [])} views)", value=version)
                for version, model in models_by_version.items()
            ],
        ).unsafe_ask()
        self.data_model = models_by_version[selected_model]
        return self.data_model.as_id()

    def update(self, resources: Sequence[ResourceResponseProtocol]) -> None:
        if not resources:
            return
        first = resources[0]
        if isinstance(first, DataModelResponse):
            for item in resources:
                if isinstance(item, DataModelResponse):
                    self.view_ids |= set(item.views or [])
        elif isinstance(first, ViewResponse):
            for item in resources:
                if isinstance(item, ViewResponse):
                    self.container_ids |= set(item.mapped_containers)
        elif isinstance(first, SpaceResponse):
            return
        self.space_ids |= {SpaceReference(space=item.space) for item in resources if hasattr(item, "space")}

    def __iter__(
        self,
    ) -> Iterator[tuple[Sequence[Hashable], Sequence[ResourceResponseProtocol] | None, ResourceCRUD, None | str]]:
        self.identifier = self._selected()
        model_loader = DataModelCRUD.create_loader(self.client)
        if self.data_model:
            is_global_model = self.data_model.is_global
            yield [], [self.data_model], model_loader, None
        else:
            model_list = self.client.tool.data_models.retrieve([self.identifier])
            if not model_list:
                raise ToolkitResourceMissingError(f"Data model {self.identifier} not found", str(self.identifier))
            is_global_model = model_list[0].is_global
            yield [], model_list, model_loader, None
        if self._include_global or is_global_model:
            yield list(self.view_ids), None, ViewCRUD.create_loader(self.client), "views"
            yield list(self.container_ids), None, ContainerCRUD.create_loader(self.client), "containers"
            yield list(self.space_ids), None, SpaceCRUD.create_loader(self.client), None
        else:
            view_loader = ViewCRUD(self.client, None, None, topological_sort_implements=True)
            views = [view for view in view_loader.retrieve(list(self.view_ids)) if not view.is_global]
            yield [], views, view_loader, "views"
            container_loader = ContainerCRUD.create_loader(self.client)
            containers = [
                container
                for container in container_loader.retrieve(list(self.container_ids))
                if not container.is_global
            ]
            yield [], containers, container_loader, "containers"

            space_loader = SpaceCRUD.create_loader(self.client)
            spaces = [space for space in space_loader.retrieve(list(self.space_ids)) if not space.is_global]
            yield [], spaces, space_loader, None


class WorkflowFinder(ResourceFinder[WorkflowVersionId]):
    def __init__(self, client: ToolkitClient, identifier: WorkflowVersionId | None = None):
        super().__init__(client, identifier)
        self._workflow: WorkflowResponse | None = None
        self._workflow_version: WorkflowVersionResponse | None = None

    def _interactive_select(self) -> WorkflowVersionId:
        workflows = self.client.tool.workflows.list(limit=None)
        if not workflows:
            raise ToolkitMissingResourceError("No workflows found")
        workflow_external_ids = [wf.external_id for wf in workflows]
        selected_workflow_id: str = questionary.select(
            "Which workflow would you like to dump?",
            [Choice(workflow_id, value=workflow_id) for workflow_id in workflow_external_ids],
        ).unsafe_ask()
        for workflow in workflows:
            if workflow.external_id == selected_workflow_id:
                self._workflow = workflow
                break

        versions = [
            v
            for page in self.client.tool.workflows.versions.iterate(workflow_external_id=selected_workflow_id)
            for v in page
        ]
        if len(versions) == 0:
            raise ToolkitMissingResourceError(f"No versions found for workflow {selected_workflow_id}")
        if len(versions) == 1:
            self._workflow_version = versions[0]
            return self._workflow_version.as_id()

        version_ids = [v.as_id() for v in versions]
        selected_version: WorkflowVersionId = questionary.select(
            "Which version would you like to dump?",
            [Choice(f"{version!r}", value=version) for version in version_ids],
        ).unsafe_ask()
        for version in versions:
            if version.version == selected_version.version:
                self._workflow_version = version
                break
        return selected_version

    def __iter__(
        self,
    ) -> Iterator[tuple[Sequence[Hashable], Sequence[ResourceResponseProtocol] | None, ResourceCRUD, None | str]]:
        self.identifier = self._selected()
        workflow_id = ExternalId(external_id=self.identifier.workflow_external_id)
        if self._workflow:
            yield [], [self._workflow], WorkflowCRUD.create_loader(self.client), None
        else:
            yield [workflow_id], None, WorkflowCRUD.create_loader(self.client), None
        if self._workflow_version:
            yield (
                [],
                [self._workflow_version],
                WorkflowVersionCRUD.create_loader(self.client),
                None,
            )
        else:
            yield [self.identifier], None, WorkflowVersionCRUD.create_loader(self.client), None
        trigger_loader = WorkflowTriggerCRUD.create_loader(self.client)
        trigger_list = list(trigger_loader.iterate(parent_ids=[workflow_id]))
        yield [], trigger_list, trigger_loader, None


class TransformationFinder(ResourceFinder[tuple[str, ...]]):
    def __init__(self, client: ToolkitClient, identifier: tuple[str, ...] | None = None):
        super().__init__(client, identifier)
        self.transformations: list[TransformationResponse] | None = None

    def _interactive_select(self) -> tuple[str, ...]:
        self.transformations = self.client.tool.transformations.list(limit=None)
        if self.transformations and not any(transformation.external_id for transformation in self.transformations):
            raise ToolkitValueError(
                "ExternalID is required for dumping transformations. "
                f"Found {len(self.transformations)} transformations with only internal IDs."
            )
        elif not self.transformations:
            raise ToolkitMissingResourceError("No transformations found")

        choices = [
            Choice(f"{transformation.name} ({transformation.external_id})", value=transformation.external_id)
            for transformation in sorted(self.transformations, key=lambda t: t.name or "")
            if transformation.external_id
        ]

        selected_transformation_ids: tuple[str, ...] | None = questionary.checkbox(
            "Which transformation(s) would you like to dump?",
            choices=choices,
            validate=lambda choices: True if choices else "You must select at least one transformation.",
        ).unsafe_ask()
        if not selected_transformation_ids:
            raise ToolkitValueError(f"No transformations selected for dumping.{_INTERACTIVE_SELECT_HELPER_TEXT}")
        return tuple(selected_transformation_ids)

    def __iter__(
        self,
    ) -> Iterator[tuple[Sequence[Hashable], Sequence[ResourceResponseProtocol] | None, ResourceCRUD, None | str]]:
        self.identifier = self._selected()
        external_ids = [ExternalId(external_id=id_) for id_ in self.identifier]
        if self.transformations:
            yield (
                [],
                [t for t in self.transformations if t.external_id in self.identifier],
                TransformationCRUD.create_loader(self.client),
                None,
            )
        else:
            yield external_ids, None, TransformationCRUD.create_loader(self.client), None

        schedule_loader = TransformationScheduleCRUD.create_loader(self.client)
        schedule_list = list(schedule_loader.iterate(parent_ids=external_ids))
        yield [], schedule_list, schedule_loader, None
        notification_loader = TransformationNotificationCRUD.create_loader(self.client)
        notification_list = list(notification_loader.iterate(parent_ids=external_ids))
        yield [], notification_list, notification_loader, None


class GroupFinder(ResourceFinder[tuple[str, ...]]):
    def __init__(self, client: ToolkitClient, identifier: tuple[str, ...] | None = None):
        super().__init__(client, identifier)
        self.groups: list[GroupResponse] | None = None

    def _interactive_select(self) -> tuple[str, ...]:
        groups = self.client.tool.groups.list(all_groups=True)
        if not groups:
            raise ToolkitMissingResourceError("No groups found")
        groups_by_name: dict[str, list[GroupResponse]] = defaultdict(list)
        for group in groups:
            groups_by_name[group.name].append(group)
        selected_groups: list[list[GroupResponse]] | None = questionary.checkbox(
            "Which group(s) would you like to dump?",
            choices=[
                Choice(f"{group_name} ({len(group_list)} group{'s' if len(group_list) > 1 else ''})", value=group_list)
                for group_name, group_list in sorted(groups_by_name.items())
            ],
            validate=lambda choices: True if choices else "You must select at least one group.",
        ).unsafe_ask()
        if not selected_groups:
            raise ToolkitValueError(f"No group selected for dumping.{_INTERACTIVE_SELECT_HELPER_TEXT}")
        self.groups = [group for group_list in selected_groups for group in group_list]
        return tuple(group_list[0].name for group_list in selected_groups)

    def __iter__(
        self,
    ) -> Iterator[tuple[Sequence[Hashable], Sequence[ResourceResponseProtocol] | None, ResourceCRUD, None | str]]:
        self.identifier = self._selected()
        if self.groups:
            yield (
                [],
                [group for group in self.groups if group.name in self.identifier],
                GroupCRUD.create_loader(self.client),
                None,
            )
        else:
            yield [NameId(name=name) for name in self.identifier], None, GroupCRUD.create_loader(self.client), None


class AgentFinder(ResourceFinder[tuple[str, ...]]):
    def __init__(self, client: ToolkitClient, identifier: tuple[str, ...] | None = None):
        super().__init__(client, identifier)
        self.agents: list[AgentResponse] | None = None

    def _interactive_select(self) -> tuple[str, ...]:
        self.agents = self.client.tool.agents.list()
        if not self.agents:
            raise ToolkitMissingResourceError("No agents found")

        choices = [
            Choice(
                f"{agent.name} ({agent.external_id}) with {len(agent.tools or [])} tools",
                value=agent.external_id,
            )
            for agent in sorted(self.agents, key=lambda a: a.name or a.external_id)
        ]

        selected_agent_ids: list[str] | None = questionary.checkbox(
            "Which agent(s) would you like to dump?",
            choices=choices,
            validate=lambda choices: True if choices else "You must select at least one agent.",
        ).unsafe_ask()
        if not selected_agent_ids:
            raise ToolkitValueError(f"No agents selected for dumping.{_INTERACTIVE_SELECT_HELPER_TEXT}")
        return tuple(selected_agent_ids)

    def __iter__(
        self,
    ) -> Iterator[tuple[Sequence[Hashable], Sequence[ResourceResponseProtocol] | None, ResourceCRUD, None | str]]:
        self.identifier = self._selected()
        loader = AgentCRUD.create_loader(self.client)
        if self.agents:
            yield (
                [],
                [agent for agent in self.agents if agent.external_id in self.identifier],
                loader,
                None,
            )
        else:
            yield [ExternalId(external_id=external_id) for external_id in self.identifier], None, loader, None


class NodeFinder(ResourceFinder[ViewReferenceNoVersion]):
    def __init__(self, client: ToolkitClient, identifier: ViewReferenceNoVersion | None = None):
        super().__init__(client, identifier)
        self.is_interactive = False

    def _interactive_select(self) -> ViewReferenceNoVersion:
        self.is_interactive = True
        spaces = self.client.tool.spaces.list(limit=None)
        if not spaces:
            raise ToolkitMissingResourceError("No spaces found")
        selected_space: str = questionary.select(
            "In which space is your node property view located?", [space.space for space in spaces]
        ).unsafe_ask()

        views = self.client.tool.views.list(ViewFilter(space=selected_space), limit=None)
        if not views:
            raise ToolkitMissingResourceError(f"No views found in {selected_space}")
        if len(views) == 1:
            return views[0].as_id()
        selected_view_id: ViewReference = questionary.select(
            "Which node property view would you like to dump?",
            [Choice(repr(view.as_id()), value=view.as_id()) for view in views],
        ).unsafe_ask()
        return selected_view_id

    def __iter__(
        self,
    ) -> Iterator[tuple[Sequence[Hashable], Sequence[ResourceResponseProtocol] | None, ResourceCRUD, None | str]]:
        self.identifier = self._selected()
        view_id: TypedViewReference
        identifier = self._selected()

        if isinstance(identifier, ViewReference):
            view_id = TypedViewReference(
                space=identifier.space,
                external_id=identifier.external_id,
                version=identifier.version,
            )
        else:
            # Find latest version of view.
            view = self.client.tool.views.retrieve([self.identifier])
            if not view:
                raise ToolkitResourceMissingError(f"View {identifier} not found", str(identifier))
            view_id = view[0].as_typed_id()

        loader = NodeCRUD(self.client, None, None, view_id)
        if self.is_interactive:
            count = self.client.data_modeling.instances.aggregate(
                ViewId(
                    self.identifier.space,
                    self.identifier.external_id,
                    self.identifier.version if isinstance(self.identifier, ViewReference) else None,
                ),
                dm.aggregations.Count("externalId"),
                instance_type="node",
            ).value
            if count == 0 or count is None:
                raise ToolkitMissingResourceError(f"No nodes found in {self.identifier}")
            elif count > 50:
                if not questionary.confirm(
                    f"Are you sure you want to dump {count} nodes? This may take a while.",
                    default=False,
                ).unsafe_ask():
                    typer.Exit(0)
        nodes = dm.NodeList[dm.Node](list(loader.iterate()))
        yield [], nodes, loader, None


class LocationFilterFinder(ResourceFinder[tuple[str, ...]]):
    @cached_property
    def all_filters(self) -> list[LocationFilterResponse]:
        return self.client.tool.location_filters.list()

    def _interactive_select(self) -> tuple[str, ...]:
        filters = self.all_filters
        if not filters:
            raise ToolkitMissingResourceError("No filters found")
        id_by_display_name = {f"{filter.name} ({filter.external_id})": filter.external_id for filter in filters}
        selected_filter_ids: tuple[str, ...] | None = questionary.checkbox(
            "Which filters would you like to dump?",
            choices=[Choice(name, value=id_) for name, id_ in id_by_display_name.items()],
            validate=lambda choices: True if choices else "You must select at least one filter.",
        ).unsafe_ask()
        if not selected_filter_ids:
            raise ToolkitValueError(f"No filters selected for dumping.{_INTERACTIVE_SELECT_HELPER_TEXT}")
        return tuple(selected_filter_ids)

    def _get_filters(self, identifiers: tuple[str, ...]) -> list[LocationFilterResponse]:
        if not identifiers:
            return self.all_filters
        filters = [f for f in self.all_filters if f.external_id in identifiers]
        if not filters:
            raise ToolkitResourceMissingError(f"Location filters {identifiers} not found", str(identifiers))
        return filters

    def __iter__(
        self,
    ) -> Iterator[tuple[Sequence[Hashable], Sequence[ResourceResponseProtocol] | None, ResourceCRUD, None | str]]:
        self.identifier = self.identifier or self._interactive_select()
        filters = self._get_filters(self.identifier)
        yield [], filters, LocationFilterCRUD.create_loader(self.client), None


class ExtractionPipelineFinder(ResourceFinder[tuple[str, ...]]):
    def __init__(self, client: ToolkitClient, identifier: tuple[str, ...] | None = None):
        super().__init__(client, identifier)
        self.extraction_pipelines: list[ExtractionPipelineResponse] | None = None

    def _interactive_select(self) -> tuple[str, ...]:
        self.extraction_pipelines = self.client.tool.extraction_pipelines.list(limit=None)
        if not self.extraction_pipelines:
            raise ToolkitMissingResourceError("No extraction pipelines found")
        choices = [
            Choice(f"{pipeline.name} ({pipeline.external_id})", value=pipeline.external_id)
            for pipeline in sorted(self.extraction_pipelines, key=lambda p: p.name or "")
        ]
        selected_pipeline_ids: tuple[str, ...] | None = questionary.checkbox(
            "Which extraction pipeline(s) would you like to dump?",
            choices=choices,
            validate=lambda choices: True if choices else "You must select at least one pipeline.",
        ).unsafe_ask()
        if not selected_pipeline_ids:
            raise ToolkitValueError(f"No extraction pipelines selected for dumping.{_INTERACTIVE_SELECT_HELPER_TEXT}")
        return tuple(selected_pipeline_ids)

    def __iter__(
        self,
    ) -> Iterator[tuple[Sequence[Hashable], Sequence[ResourceResponseProtocol] | None, ResourceCRUD, None | str]]:
        self.identifier = self._selected()
        external_ids = [ExternalId(external_id=ext_id) for ext_id in self.identifier]
        pipeline_loader = ExtractionPipelineCRUD.create_loader(self.client)
        if self.extraction_pipelines:
            selected_pipelines = [p for p in self.extraction_pipelines if p.external_id in self.identifier]
            yield [], selected_pipelines, pipeline_loader, None
        else:
            yield external_ids, None, pipeline_loader, None
        config_loader = ExtractionPipelineConfigCRUD.create_loader(self.client)
        configs = list(config_loader.iterate(parent_ids=external_ids))
        yield [], configs, config_loader, None


class DataSetFinder(ResourceFinder[tuple[str, ...]]):
    """Finds data sets to dump."""

    def __init__(self, client: ToolkitClient, identifier: tuple[str, ...] | None = None):
        super().__init__(client, identifier)
        self.datasets: list[DataSetResponse] | None = None

    def _interactive_select(self) -> tuple[str, ...]:
        self.datasets = self.client.tool.datasets.list(limit=None)
        if not self.datasets:
            raise ToolkitMissingResourceError("No datasets found")
        choices = [
            Choice(f"{dataset.name} ({dataset.external_id})", value=dataset.external_id)
            for dataset in sorted(self.datasets, key=lambda d: d.name or "")
            if dataset.external_id
        ]
        selected_dataset_ids: tuple[str, ...] | None = questionary.checkbox(
            "Which dataset(s) would you like to dump?",
            choices=choices,
            validate=lambda choices: True if choices else "You must select at least one dataset.",
        ).unsafe_ask()
        if not selected_dataset_ids:
            raise ToolkitValueError(f"No datasets selected for dumping.{_INTERACTIVE_SELECT_HELPER_TEXT}")
        return tuple(selected_dataset_ids)

    def __iter__(
        self,
    ) -> Iterator[tuple[Sequence[Hashable], Sequence[ResourceResponseProtocol] | None, ResourceCRUD, None | str]]:
        self.identifier = self._selected()
        loader = DataSetsCRUD.create_loader(self.client)
        if self.datasets:
            yield (
                [],
                [d for d in self.datasets if d.external_id in set(self.identifier)],
                loader,
                None,
            )
        else:
            yield list(self.identifier), None, loader, None


class FunctionFinder(ResourceFinder[tuple[str, ...]]):
    def __init__(self, client: ToolkitClient, identifier: tuple[str, ...] | None = None):
        super().__init__(client, identifier)
        self.functions: list[FunctionResponse] | None = None

    def _interactive_select(self) -> tuple[str, ...]:
        self.functions = self.client.tool.functions.list(limit=-1)
        if not self.functions:
            raise ToolkitMissingResourceError("No functions found")
        choices = [
            Choice(f"{function.name} ({function.external_id})", value=function.external_id)
            for function in sorted(self.functions, key=lambda f: f.name)
            if function.external_id
        ]
        selected_function_ids: tuple[str, ...] | None = questionary.checkbox(
            "Which function(s) would you like to dump?",
            choices=choices,
            validate=lambda choices: True if choices else "You must select at least one function.",
        ).unsafe_ask()
        if not selected_function_ids:
            raise ToolkitValueError(f"No functions selected for dumping.{_INTERACTIVE_SELECT_HELPER_TEXT}")
        return tuple(selected_function_ids)

    def __iter__(
        self,
    ) -> Iterator[tuple[Sequence[Hashable], Sequence[ResourceResponseProtocol] | None, ResourceCRUD, None | str]]:
        self.identifier = self._selected()
        loader = FunctionCRUD.create_loader(self.client)
        if self.functions:
            selected_functions = [f for f in self.functions if f.external_id in self.identifier]
            yield [], selected_functions, loader, None
        else:
            # Convert string identifiers to ExternalId objects
            external_ids = [ExternalId(external_id=ext_id) for ext_id in self.identifier]
            yield external_ids, None, loader, None

        schedule_loader = FunctionScheduleCRUD.create_loader(self.client)
        # Pass ExternalId objects as parent_ids
        parent_external_ids = [ExternalId(external_id=ext_id) for ext_id in self.identifier]
        schedules = schedule_loader.iterate(parent_ids=parent_external_ids)
        yield [], list(schedules), schedule_loader, None

    def dump_function_code(self, function: Function, folder: Path) -> None:
        try:
            zip_bytes = self.client.files.download_bytes(id=function.file_id)
        except CogniteAPIError as e:
            if e.code == 400 and "File ids not found" in e.message:
                HighSeverityWarning(
                    f"The function {function.external_id!r} does not have code to dump. It is not available in CDF."
                ).print_warning()
                return
            raise
        try:
            top_level = f"{sanitize_filename(function.external_id or 'unknown_external_id')}/"
            with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
                if all(name.startswith(top_level) for name in zf.namelist()):
                    zf.extractall(folder)
                else:
                    zf.extractall(folder / top_level)
        except zipfile.BadZipFile as e:
            HighSeverityWarning(
                f"The function {function.external_id!r} has a corrupted code zip file. Unable to extract code: {e!s}"
            ).print_warning()


class StreamlitFinder(ResourceFinder[tuple[str, ...]]):
    def __init__(self, client: ToolkitClient, identifier: tuple[str, ...] | None = None):
        super().__init__(client, identifier)
        self.apps: list[StreamlitResponse] | None = None

    def _interactive_select(self) -> tuple[str, ...]:
        """Interactively select one or more Streamlit apps to dump."""
        result = self.client.documents.aggregate_unique_values(
            SourceFileProperty.metadata_key("creator"),
            filter=filters.Equals(SourceFileProperty.directory, "/streamlit-apps/"),
        )
        if not result:
            raise ToolkitMissingResourceError("No Streamlit apps found")

        selected_creator = questionary.select(
            "Who is the creator of the Streamlit app you would like to dump? [name (app count)]",
            choices=[
                Choice(f"{item.value} ({item.count})", value=item.value)
                for item in sorted(result, key=lambda r: (r.count, str(r.value) or ""))
            ],
        ).unsafe_ask()
        self.apps = self.client.tool.streamlit.list(limit=None, filter=StreamlitFilter(creator=str(selected_creator)))
        selected_ids: list[str] | None = questionary.checkbox(
            message="Which Streamlit app(s) would you like to dump?",
            choices=[
                Choice(
                    title=f"{app.name} ({app.creator} - {ms_to_datetime(app.last_updated_time)})", value=app.external_id
                )
                for app in sorted(self.apps, key=lambda a: a.name)
            ],
            validate=lambda choices: True if choices else "You must select at least one Streamlit app.",
        ).unsafe_ask()
        if not selected_ids:
            raise ToolkitValueError(f"No Streamlit app selected for dumping.{_INTERACTIVE_SELECT_HELPER_TEXT}")
        return tuple(selected_ids)

    def __iter__(
        self,
    ) -> Iterator[tuple[Sequence[Hashable], Sequence[ResourceResponseProtocol] | None, ResourceCRUD, None | str]]:
        identifier = self.identifier or self._interactive_select()
        loader = StreamlitCRUD.create_loader(self.client)
        # If the user used interactive select, we have already downloaded the streamlit apps,
        # Thus, we do not need to download them again. If not pass the identifier and let the main logic
        # take care of the download.
        if self.apps:
            yield [], [app for app in self.apps if app.external_id in identifier], loader, None
        else:
            yield [ExternalId(external_id=id_) for id_ in identifier], None, loader, None

    def dump_code(self, app: StreamlitResponse, folder: Path, console: Console | None = None) -> None:
        """Dump the code of a Streamlit app to the specified folder.

        The code is extracted from the JSON content of the app file in CDF.

        Args:
            app (Streamlit): The Streamlit app whose code is to be dumped.
            folder (Path): The directory where the app code will be saved.
            console (Console | None): Optional Rich console for printing warnings.
        """
        try:
            content = self.client.files.download_bytes(external_id=app.external_id)
        except CogniteAPIError as e:
            if e.code == 400 and e.missing:
                HighSeverityWarning(
                    f"The source code for {app.external_id!r} could not be retrieved from CDF."
                ).print_warning(console=console)
                return
            raise

        try:
            json_content = json.loads(content)
        except json.JSONDecodeError as e:
            HighSeverityWarning(
                f"The JSON content for the Streamlit app {app.external_id!r} is corrupt and could not be extracted. "
                f"Download file with the same external id manually to remediate. {e!s}"
            ).print_warning(console=console)
            return

        app_folder = sanitize_filename(app.external_id)
        app_path = folder / app_folder
        app_path.mkdir(exist_ok=True)
        if isinstance(json_content.get("requirements"), list):
            requirements_txt = app_path / "requirements.txt"
            requirements = json_content["requirements"]
            if not requirements:
                HighSeverityWarning(
                    f"The Streamlit app {app.external_id!r} has a requirements.txt file with no content. Skipping..."
                ).print_warning()
            else:
                requirements_txt.write_text("\n".join(requirements), encoding="utf-8")
        files = json_content.get("files", {})
        if not isinstance(files, dict) or (not files):
            HighSeverityWarning(
                f"The Streamlit app {app.external_id!r} does not have any files to dump. It is likely corrupted."
            ).print_warning(console=console)
            return
        created_files: set[str] = set()
        for relative_filepath, content in files.items():
            filepath = app_path / relative_filepath
            filepath.parent.mkdir(parents=True, exist_ok=True)
            file_content = content.get("content", {}).get("text", "")
            if not isinstance(file_content, str):
                HighSeverityWarning(
                    f"The Streamlit app {app.external_id!r} has a file {relative_filepath} with invalid content. Skipping..."
                ).print_warning(console=console)
                continue
            safe_write(filepath, file_content, encoding="utf-8")
            created_files.add(relative_filepath)

        entry_point = json_content.get("entrypoint")
        if entry_point and entry_point not in created_files:
            HighSeverityWarning(
                f"The Streamlit app {app.external_id!r} has an entry point {entry_point} that was not found in the files. "
                "The app may be corrupted."
            ).print_warning(console=console)


class SpaceFinder(ResourceFinder[tuple[str, ...]]):
    def __init__(self, client: ToolkitClient, identifier: tuple[str, ...] | None = None):
        super().__init__(client, identifier)

    def _interactive_select(self) -> tuple[str, ...]:
        # Using new interactive select component for selecting instance spaces
        # This will raise a ToolkitValueError if no instance spaces are selected and this is handled in the caller.
        data_modeling_select = DataModelingSelect(self.client, "dump")
        selected_spaces = data_modeling_select.select_instance_space(
            multiselect=True, message="Which instance space(s) would you like to dump?"
        )
        return tuple(selected_spaces)

    def __iter__(
        self,
    ) -> Iterator[tuple[Sequence[Hashable], Sequence[ResourceResponseProtocol] | None, ResourceCRUD, None | str]]:
        self.identifier = self._selected()
        loader = SpaceCRUD.create_loader(self.client)
        yield [SpaceReference(space=space) for space in self.identifier], None, loader, None


class SearchConfigFinder(ResourceFinder[tuple[ViewReferenceNoVersion, ...]]):
    def __init__(self, client: ToolkitClient, identifier: tuple[ViewReferenceNoVersion, ...] | None = None):
        super().__init__(client, identifier)
        self.search_configs: list[SearchConfigResponse] | None = None

    def _interactive_select(self) -> tuple[ViewReferenceNoVersion, ...]:
        self.search_configs = self.client.tool.search_configurations.list()
        if not self.search_configs:
            raise ToolkitMissingResourceError("No search configurations found!")
        choices = [
            Choice(f"{config.view.external_id} {config.view.space}", value=config.view)
            for config in self.search_configs
        ]
        selected_view_ids: list[ViewReferenceNoVersion] | None = questionary.checkbox(
            "For which view would you like to dump the search configuration?",
            choices=choices,
            validate=lambda choices: True if choices else "You must select at least one view.",
        ).unsafe_ask()
        if not selected_view_ids:
            raise ToolkitValueError("No view selected for dumping the search configuration.")
        return tuple(selected_view_ids)

    def __iter__(
        self,
    ) -> Iterator[tuple[Sequence[Hashable], Sequence[ResourceResponseProtocol] | None, ResourceCRUD, None | str]]:
        self.identifier = self._selected()
        loader = SearchConfigCRUD.create_loader(self.client)
        if self.search_configs:
            yield [], [sc for sc in self.search_configs if sc.view in self.identifier], loader, None
        else:
            yield list(self.identifier), None, loader, None


class ResourceViewMappingFinder(ResourceFinder[tuple[str, ...]]):
    def __init__(self, client: ToolkitClient, identifier: tuple[str, ...] | None = None):
        super().__init__(client, identifier)
        self.resource_view_mappings: list[ResourceViewMappingResponse] | None = None

    def _interactive_select(self) -> tuple[str, ...]:
        mappings = self.client.migration.resource_view_mapping.list(limit=-1)
        if not mappings:
            raise ToolkitMissingResourceError("No resource view mappings found")
        self.resource_view_mappings = list(mappings)
        choices = [
            Choice(
                f"{mapping.external_id} ({mapping.resource_type} -> {mapping.view_id.external_id})",
                value=mapping.external_id,
            )
            for mapping in sorted(mappings, key=lambda m: m.external_id)
        ]
        selected_ids: list[str] | None = questionary.checkbox(
            "Which resource view mapping(s) would you like to dump?",
            choices=choices,
            validate=lambda choices: True if choices else "You must select at least one resource view mapping.",
        ).unsafe_ask()
        if not selected_ids:
            raise ToolkitValueError(f"No resource view mappings selected for dumping.{_INTERACTIVE_SELECT_HELPER_TEXT}")
        return tuple(selected_ids)

    def __iter__(
        self,
    ) -> Iterator[tuple[Sequence[Hashable], Sequence[ResourceResponseProtocol] | None, ResourceCRUD, None | str]]:
        self.identifier = self._selected()
        loader = ResourceViewMappingCRUD.create_loader(self.client)
        if self.resource_view_mappings:
            selected_mappings = [m for m in self.resource_view_mappings if m.external_id in self.identifier]
            yield [], selected_mappings, loader, None
        else:
            yield [ExternalId(external_id=external_id) for external_id in self.identifier], None, loader, None


class DumpResourceCommand(ToolkitCommand):
    def dump_to_yamls(
        self,
        finder: ResourceFinder,
        output_dir: Path,
        clean: bool,
        verbose: bool,
    ) -> None:
        is_populated = output_dir.exists() and any(output_dir.iterdir())
        if is_populated and clean:
            safe_rmtree(output_dir)
            output_dir.mkdir()
            self.console(f"Cleaned existing output directory {output_dir!s}.")
        elif is_populated:
            self.warn(MediumSeverityWarning("Output directory is not empty. Use --clean to remove existing files."))
        elif not output_dir.exists():
            output_dir.mkdir(exist_ok=True)

        dumped_ids: list[Hashable] = []
        for identifiers, resources, loader, subfolder in finder:
            if not identifiers and not resources:
                # No resources to dump
                continue
            if resources is None:
                try:
                    resources = loader.retrieve(list(identifiers))
                except (CogniteAPIError, ToolkitAPIError) as e:
                    raise ResourceRetrievalError(f"Failed to retrieve {humanize_collection(identifiers)}: {e!s}") from e
                if len(resources) == 0:
                    raise ToolkitResourceMissingError(
                        f"Resource(s) {humanize_collection(identifiers)} not found", str(identifiers)
                    )

            finder.update(resources)
            resource_folder = output_dir / loader.folder_name
            if subfolder:
                resource_folder = resource_folder / subfolder
            resource_folder.mkdir(exist_ok=True, parents=True)
            for resource in resources:
                resource_id = loader.get_id(resource)
                name = loader.as_str(resource_id)
                base_filepath = resource_folder / f"{name}.{loader.kind}.yaml"
                if base_filepath.exists():
                    self.warn(FileExistsWarning(base_filepath, "Skipping... Use --clean to remove existing files."))
                    continue
                dumped = loader.dump_resource(resource)
                for filepath, subpart in loader.split_resource(base_filepath, dumped):
                    content = subpart if isinstance(subpart, str) else yaml_safe_dump(subpart)
                    safe_write(filepath, content, encoding="utf-8")
                    if verbose:
                        self.console(f"Dumped {loader.kind} {name} to {filepath!s}")
                if isinstance(finder, FunctionFinder) and isinstance(resource, Function):
                    finder.dump_function_code(resource, resource_folder)
                if isinstance(finder, StreamlitFinder) and isinstance(resource, StreamlitResponse):
                    finder.dump_code(resource, resource_folder)
                dumped_ids.append(resource_id)
        print(Panel(f"Dumped {humanize_collection(dumped_ids)}", title="Success", style="green", expand=False))
