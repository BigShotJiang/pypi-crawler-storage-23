# The category for artifacts used in venusian scanning.
MR_ARTIFACTS_CATEGORY = "mr_artifacts"
# The category for customizable used in venusian scanning.
MR_CUSTOMIZABLE_CATEGORY = "mr_customizable"
# The default path to the repo config file.
REPO_CONFIG_PATH = ".makerrepo/config.yaml"
