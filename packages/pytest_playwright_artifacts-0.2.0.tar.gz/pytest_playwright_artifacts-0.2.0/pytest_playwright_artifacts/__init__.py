from pytest_playwright_artifacts.assertions import assert_no_console_errors

__all__ = ["assert_no_console_errors"]
