infrahouse\_toolkit.cli.ih\_elastic.cmd\_snapshots.cmd\_policy package
======================================================================

Module contents
---------------

.. automodule:: infrahouse_toolkit.cli.ih_elastic.cmd_snapshots.cmd_policy
   :members:
   :undoc-members:
   :show-inheritance:
