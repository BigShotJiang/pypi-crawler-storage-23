infrahouse\_toolkit.cli.ih\_elastic.cmd\_snapshots package
==========================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   infrahouse_toolkit.cli.ih_elastic.cmd_snapshots.cmd_create
   infrahouse_toolkit.cli.ih_elastic.cmd_snapshots.cmd_create_repository
   infrahouse_toolkit.cli.ih_elastic.cmd_snapshots.cmd_delete_repository
   infrahouse_toolkit.cli.ih_elastic.cmd_snapshots.cmd_policy
   infrahouse_toolkit.cli.ih_elastic.cmd_snapshots.cmd_restore
   infrahouse_toolkit.cli.ih_elastic.cmd_snapshots.cmd_status

Module contents
---------------

.. automodule:: infrahouse_toolkit.cli.ih_elastic.cmd_snapshots
   :members:
   :undoc-members:
   :show-inheritance:
