"""
Command line interface to the InfraHouse toolkit.

There are several commands in the toolkit. All of them start with an ``ih-`` prefix.
"""
