"""AgentWard — Open-source permission control plane for AI agents."""

__version__ = "0.2.1"
