
import torch
import gc
from threading import Thread
from transformers import (
    AutoModelForCausalLM, 
    AutoTokenizer, 
    AutoProcessor, 
    AutoModelForImageTextToText,
    TextIteratorStreamer
)
from types import SimpleNamespace

#--------------------------------------------------------------------------------------------
# Transformers / Torch バックエンド
#--------------------------------------------------------------------------------------------
class TransformersLLMInterface:
    def __init__(
        self, 
        model_path: str, 
        use_vision: bool = False, 
        temp: float = 0.7,
        top_k: int = 50, 
        top_p: float = 0.95, 
        min_p: float = 0.05, 
        max_tokens: int = 8192,
        enable_thinking: bool = True
    ):
        self.model_path = model_path
        self.use_vision = use_vision
        
        self.temp = temp
        self.top_k = top_k
        self.top_p = top_p
        self.min_p = min_p # transformersでは標準サポートされていない場合があります
        self.max_tokens = max_tokens
        self.enable_thinking = enable_thinking
        
        self.model = None
        self.tokenizer = None
        self.processor = None

    def _get_device(self):
        # 環境に応じて最適なデバイスを判定
        if torch.cuda.is_available():
            return "cuda"
        elif torch.backends.mps.is_available():
            return "mps"
        return "cpu"

    def _load_model(self):
        # メモリ効率と互換性のためのデータ型設定
        dtype = torch.bfloat16
        
        if self.use_vision:
            # VLM用ロード
            self.model = AutoModelForImageTextToText.from_pretrained(
                self.model_path, 
                torch_dtype=dtype, 
                device_map="auto",
                trust_remote_code=True
            )
            self.processor = AutoProcessor.from_pretrained(self.model_path, trust_remote_code=True)
            self.tokenizer = self.processor.tokenizer
        else:
            # 通常のLLM用ロード
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_path, 
                torch_dtype=dtype, 
                device_map="auto",
                trust_remote_code=True
            )
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_path, trust_remote_code=True)

    def _free_model(self):
        # メモリの明示的な解放
        self.model = None
        self.tokenizer = None
        self.processor = None
        gc.collect()
        
        # デバイスごとのキャッシュクリア
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        if torch.backends.mps.is_available():
            torch.mps.empty_cache()

    def generate(self, messages, images=None, stream=False):
        self._load_model()
        
        try:
            device = self.model.device

            # kwargsにenable_thinkingを追加（対応しているモデルのみ）
            template_kwargs = {"add_generation_prompt": True}
            if self.enable_thinking is not None:
                template_kwargs["enable_thinking"] = self.enable_thinking

            # ==========================================
            # プロンプトの構築と入力テンソルの準備
            # ==========================================
            if self.use_vision:
                # 画像処理を含むVLMの入力準備
                prompt = self.processor.apply_chat_template(messages, tokenize=False, **template_kwargs)
                inputs = self.processor(
                    text=prompt, 
                    images=images if images else None, 
                    return_tensors="pt"
                ).to(device)
            else:
                # テキスト専用LLMの入力準備
                prompt = self.tokenizer.apply_chat_template(messages, tokenize=False, **template_kwargs)
                inputs = self.tokenizer(prompt, return_tensors="pt", add_special_tokens=False).to(device)

            # 生成パラメータの準備
            generation_kwargs = dict(
                **inputs,
                max_new_tokens=self.max_tokens,
                do_sample=True if self.temp > 0 else False,
                temperature=self.temp if self.temp > 0 else None,
                top_k=self.top_k,
                top_p=self.top_p,
                eos_token_id=self.tokenizer.eos_token_id,
                pad_token_id=self.tokenizer.pad_token_id or self.tokenizer.eos_token_id
            )

            # ==========================================
            # 生成処理 (ストリーミング / 一括)
            # ==========================================
            if stream:
                streamer = TextIteratorStreamer(
                    self.tokenizer, 
                    skip_prompt=True, 
                    skip_special_tokens=True
                )
                generation_kwargs["streamer"] = streamer
                
                # Transformersのストリーミングは別スレッドで回す必要があります
                thread = Thread(target=self.model.generate, kwargs=generation_kwargs)
                thread.start()
                
                for new_text in streamer:
                    yield new_text
            else:
                output_ids = self.model.generate(**generation_kwargs)
                # 入力プロンプト部分のトークンをカットしてデコード
                input_len = inputs["input_ids"].shape[1]
                response_text = self.tokenizer.decode(output_ids[0][input_len:], skip_special_tokens=True)
                yield SimpleNamespace(text=response_text)
        
        finally:
            self._free_model()