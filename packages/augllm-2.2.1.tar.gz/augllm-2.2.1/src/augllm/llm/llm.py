
from typing import List, Optional, Dict
from PIL import Image
from .interface import TransformersLLMInterface

def load_image_pil(image_path: str) -> Image.Image:
    """PILを使用して画像を読み込み、RGBに変換するユーティリティ"""
    return Image.open(image_path).convert("RGB")

#--------------------------------------------------------------------------------------------
# LLM推論を制御するメインクラス (Transformers版)
#--------------------------------------------------------------------------------------------
class TransformersLLM:
    def __init__(
            self,
            model_path: str, 
            use_vision: bool = False, 
            temp: float = 0.7,
            top_k: int = 50, 
            top_p: float = 0.95, 
            min_p: float = 0.05, 
            max_tokens: int = 8192,
            enable_thinking: bool = True
    ):
        self.llm = TransformersLLMInterface(
            model_path=model_path,
            use_vision=use_vision,
            temp=temp,
            top_k=top_k,
            top_p=top_p,
            min_p=min_p,
            max_tokens=max_tokens,
            enable_thinking=enable_thinking
        )
    
    def _build_message(self, role: str, text: str, images: Optional[List] = None) -> Dict:
        # VLMインターフェースが有効な場合 (画像の有無に関わらずVLM形式を採用)
        if self.llm.use_vision:
            content = [{"type": "text", "text": text}]
            if images:
                for _ in images:
                    content.append({"type": "image"})
            return {"role": role, "content": content}
        
        # 通常のテキストのみのモデルの場合
        return {"role": role, "content": text}

    def respond(
            self,
            user_text: str, 
            user_images: List[str] = None,
            system_prompt: str = None,
            stream: bool = False):
        
        messages = []
        
        if system_prompt:
            messages.append(self._build_message(role="system", text=system_prompt))
        
        # Transformers(Hugging Face)のVLMは、通常PILのImageオブジェクトを受け取ります
        user_images = user_images or []
        pil_user_images = [load_image_pil(str(p)) for p in user_images]
        
        messages.append(self._build_message(role="user", text=user_text, images=pil_user_images))

        # Generatorの取得
        generator = self.llm.generate(
            messages=messages, 
            images=pil_user_images if len(pil_user_images) > 0 else None,
            stream=stream
        )

        if stream:
            for response in generator:
                # TransformersのTextIteratorStreamerは直接文字列を返すため分岐処理
                chunk = response.text if hasattr(response, 'text') else response
                yield chunk
        else:
            full_reply = ""
            for response in generator:
                chunk = response.text if hasattr(response, 'text') else response
                full_reply += chunk
            yield full_reply