
import os
import gc
from typing import Optional, List, Generator
from llama_cpp import Llama
from llama_cpp.llama_chat_format import Llava15ChatHandler
from huggingface_hub import hf_hub_download, list_repo_files

class LlamaCppUnifiedLLM:
    def __init__(
            self, 
            model_path_or_repo: str,
            filename: Optional[str] = None,       # "Q8_0" などのキーワードだけでOKになります
            mmproj_path_or_repo: Optional[str] = None,
            mmproj_filename: str = "mmproj-model-f16.gguf",
            temp: float = 0.6,
            n_ctx: int = 4096,
            n_gpu_layers: int = -1
    ):
        self.chat_handler = None
        if mmproj_path_or_repo:
            mmproj_path = self._prepare_file(mmproj_path_or_repo, mmproj_filename)
            self.chat_handler = Llava15ChatHandler(clip_model_path=mmproj_path)
            print(f"Vision mode enabled: {mmproj_path}")

        # ローカルパスが存在する場合はそのままロード
        if os.path.exists(model_path_or_repo):
            self.llm = Llama(
                model_path=model_path_or_repo,
                chat_handler=self.chat_handler,
                n_gpu_layers=n_gpu_layers,
                n_ctx=n_ctx,
                logits_all=True if self.chat_handler else False,
                verbose=False
            )
        else:
            print(f"Hugging Faceリポジトリ '{model_path_or_repo}' を確認中...")
            
            # --- 🌟 ここが自動検索ロジック ---
            search_keyword = filename or "Q4_K_M"  # デフォルトは Q4_K_M
            exact_filename = self._find_gguf_filename(model_path_or_repo, search_keyword)
            print(f"対象ファイルを発見: {exact_filename} (ダウンロード開始/キャッシュ確認)")
            # -------------------------------

            self.llm = Llama.from_pretrained(
                repo_id=model_path_or_repo,
                filename=exact_filename, # 見つけた完全なファイル名を渡す
                chat_handler=self.chat_handler,
                n_gpu_layers=n_gpu_layers,
                n_ctx=n_ctx,
                logits_all=True if self.chat_handler else False,
                verbose=False
            )
        
        self.temp = temp

    def _find_gguf_filename(self, repo_id: str, keyword: str) -> str:
        """Hugging Faceのリポジトリから、キーワードを含むGGUFファイルを探す"""
        # すでに完全なファイル名（.gguf付き）が指定されている場合はそのまま返す
        if keyword.endswith(".gguf") and "*" not in keyword:
            return keyword
            
        # ワイルドカードの * を取り除く
        clean_keyword = keyword.replace("*", "").lower()
        
        # リポジトリ内の全ファイルリストを取得
        files = list_repo_files(repo_id=repo_id)
        
        # キーワードを含み、かつ .gguf で終わるファイルを探す
        for f in files:
            if f.endswith(".gguf") and clean_keyword in f.lower():
                return f
                
        raise ValueError(f"リポジトリ '{repo_id}' の中に '{keyword}' を含む .gguf ファイルが見つかりませんでした。利用可能なファイル: {files}")

    def _prepare_file(self, path_or_repo: str, filename: str) -> str:
        if os.path.exists(path_or_repo):
            return path_or_repo
        return hf_hub_download(repo_id=path_or_repo, filename=filename)

    def respond(
        self, 
        user_text: str, 
        user_images: Optional[List[str]] = None, 
        system_prompt: str = "あなたは優秀なアシスタントです。", 
        stream: bool = False
    ) -> Generator[str, None, None]:
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        
        if not user_images or not self.chat_handler:
            messages.append({"role": "user", "content": user_text})
        else:
            content = [{"type": "text", "text": user_text}]
            for b64 in user_images:
                img_url = b64 if b64.startswith("data:") else f"data:image/jpeg;base64,{b64}"
                content.append({"type": "image_url", "image_url": {"url": img_url}})
            messages.append({"role": "user", "content": content})

        try:
            response_iter = self.llm.create_chat_completion(
                messages=messages, stream=stream, temperature=self.temp
            )
            for chunk in (response_iter if stream else [response_iter]):
                item = chunk if not stream else chunk['choices'][0].get('delta', {})
                content = item.get('content') or item.get('message', {}).get('content')
                if content: yield content
        except Exception as e:
            yield f"[Error] {str(e)}"

    def free_model(self):
        if hasattr(self, "llm"): del self.llm
        if hasattr(self, "chat_handler"): del self.chat_handler
        gc.collect()