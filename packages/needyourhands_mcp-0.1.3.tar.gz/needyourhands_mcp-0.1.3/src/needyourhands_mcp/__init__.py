"""NeedYourHands MCP Server - AI agents interface for hiring humans."""

__version__ = "0.1.3"
