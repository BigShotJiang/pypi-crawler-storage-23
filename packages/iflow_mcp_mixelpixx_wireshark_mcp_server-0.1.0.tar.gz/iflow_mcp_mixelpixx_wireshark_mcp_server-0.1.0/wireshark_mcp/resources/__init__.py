"""MCP resource implementations."""

__all__ = []
