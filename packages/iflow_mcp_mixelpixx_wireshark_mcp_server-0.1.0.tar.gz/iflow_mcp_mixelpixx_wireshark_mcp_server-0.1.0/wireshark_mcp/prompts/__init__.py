"""MCP prompt implementations."""

__all__ = []
