"""Tests for FSM integration module.

These tests were migrated from the dataknobs-fsm package.
"""
