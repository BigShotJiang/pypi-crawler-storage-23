# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'


class WGCException(Exception):
    """
    Common framework exception.
    All framework exceptions should be derived from this exception.
    """
    
    
class ArsenalException(Exception):
    """
    Common framework exception.
    All framework exceptions should be derived from this exception.
    """


class AnotherInstanceRunning(WGCException):
    """
    There is another session with WGC client, try to close it first. error.
    """


class WebSocketConnectionClosed(WGCException):
    """
    WebSocketConnectionClosed error.
    """


class Attention(Exception):
    """
    Not a critical error, to attract attention
    """


class WG_TRACK(WGCException):
    """
    WG_TRACK assertation exception.
    """


class AbnormalTermination(WGCException):
    """
    AbnormalTermination exception.
    """


class WGCCrash(WGCException):
    """
    Crash exception.
    """


class ApplicationCrash(WGCException):
    """
    Application Error
    """


class WGCInplaceError(WGCException):
    """
    WGC inplace error exception.
    """


class WGCFailedToLoadTorrent(WGCException):
    """
    WGC FailedToLoadTorrent error exception.
    """


class WGCDownloadTimeout(WGCException):
    """
    WGC DownloadTimeout error exception.
    """


class WGCUnableToOpenArchive(WGCException):
    """
    WGC UnableToOpenArchive error exception.
    """


class WGCAssert(WGCException):
    """
    Assert exception.
    """


class WGCReport(WGCException):
    """
    Report exception.
    """


class WGCRunningTimeoutException(WGCException):
    """
    Running timeout exception.
    """


class WGCIPCRequestException(WGCRunningTimeoutException):
    """
    WGC IPC Request exception
    """


class WGCIncorrectFileHash(WGCRunningTimeoutException):
    """
    WGC WGCIncorrectFileHash exception
    """


class UnsupportedProtocolVersion(WGCRunningTimeoutException):
    """
    WGC UnsupportedProtocolVersion exception
    """


class WGCSanityCheckException(WGCException):
    """
    WGC sanity check exception.
    """


class WGCDoesntGetResponseException(WGCException):
    """
    Not respond from WGC exception.
    """
    
    
class MissingParamException(WGCException):
    """
    Raised when a required parameter is missing in a mock request.
    """
