﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from wgc_core.logger.logger import get_logger, log_config_path

__all__ = ['get_logger', 'log_config_path']
