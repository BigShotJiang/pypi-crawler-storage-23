﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from os import path

from wgc_core.exceptions import WGCException


def get_file_template(filename, as_bytes=False):
    """
    Gets file content from template.

    :param str filename: file name.
    :param bool as_bytes: flag that indicates should we return bytes or string.
    :rtype: bytes | str
    :return: content of file.
    """
    file_template_path = path.join(path.dirname(__file__), filename)
    if not path.isfile(file_template_path):
        raise WGCException('File "%s" was not found in file patterns.' %
                           filename)

    with open(file_template_path, 'rb') as file_template:
        file_template_content = file_template.read()

    return file_template_content if as_bytes else \
        file_template_content.decode('utf-8')


def get_file_template_path(filename):
    """
    Get file template path.

    :param str filename: file name.
    :rtype: str
    :return: path to template file.
    """
    return path.join(path.dirname(__file__), filename)
