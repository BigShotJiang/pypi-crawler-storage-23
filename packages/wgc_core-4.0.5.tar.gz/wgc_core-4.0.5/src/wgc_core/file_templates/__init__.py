﻿# -*- coding: utf-8 -*-

__author__ = 'm_beloborodko@wargaming.net'

from wgc_core.file_templates.file_templates import get_file_template, get_file_template_path  # noqa
