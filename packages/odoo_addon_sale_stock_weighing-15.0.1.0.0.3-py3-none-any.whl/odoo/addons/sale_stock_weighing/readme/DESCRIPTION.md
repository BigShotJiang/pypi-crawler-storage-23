Show sale order infos in the weighing assistant cards.
