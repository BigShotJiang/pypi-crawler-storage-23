# lang_guardx/__init__.py
from .detection.core import Detector, DetectionResult

__version__ = "0.1.1"

__all__ = ["Detector", "DetectionResult"]