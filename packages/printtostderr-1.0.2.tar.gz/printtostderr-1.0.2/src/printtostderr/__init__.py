from printtostderr.core import *
from printtostderr.tests import *

if __name__ == "__main__":
    main()
