from __future__ import annotations

from bot_framework.core.protocols.i_message_core_base import IMessageCoreBase
from bot_framework.domain.flow_management.protocols.i_flow_message_storage import (
    IFlowMessageStorage,
)
from bot_framework.platform.facebook.services.facebook_message_core import (
    FacebookMessageCore,
)


class FacebookPlatformFactory:
    def __init__(
        self,
        page_access_token: str,
        verify_token: str,
    ) -> None:
        self._page_access_token = page_access_token
        self._verify_token = verify_token

    def create_core(
        self,
        bot_token: str,
        database_url: str,
        flow_message_storage: IFlowMessageStorage,
    ) -> FacebookMessageCore:
        return FacebookMessageCore(
            page_access_token=self._page_access_token,
            verify_token=self._verify_token,
            flow_message_storage=flow_message_storage,
        )

    def run(self, core: IMessageCoreBase) -> None:
        if not isinstance(core, FacebookMessageCore):
            msg = "FacebookPlatformFactory.run() requires FacebookMessageCore"
            raise TypeError(msg)
        core.run()

    @property
    def supports_support_chat(self) -> bool:
        return False
