from __future__ import annotations

from typing import Protocol

from bot_framework.core.protocols.i_message_core_base import IMessageCoreBase
from bot_framework.domain.flow_management.protocols.i_flow_message_storage import (
    IFlowMessageStorage,
)


class IPlatformFactory(Protocol):
    def create_core(
        self,
        bot_token: str,
        database_url: str,
        flow_message_storage: IFlowMessageStorage,
    ) -> IMessageCoreBase: ...

    def run(self, core: IMessageCoreBase) -> None: ...

    @property
    def supports_support_chat(self) -> bool: ...
