"""Basilisk DoS attacks."""
