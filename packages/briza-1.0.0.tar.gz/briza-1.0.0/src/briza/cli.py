import typer
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from briza.generator import create_project

app = typer.Typer(
    help="🌬️ Briza — minimal project scaffolding for developers.",
    no_args_is_help=True,
)

console = Console()


@app.callback()
def main():
    pass


@app.command()
def new(
    name: str = typer.Argument(..., help="Name of the project to create."),
):
    """
    Create a new project.
    """
    try:
        console.print(f"\n🌬️  Creating project: [bold cyan]{name}[/bold cyan]\n")

        create_project(name)

        success_message = Text()
        success_message.append("✔ Project created successfully!\n", style="bold green")
        success_message.append("\nNext steps:\n", style="bold")
        success_message.append(f"  cd {name}\n")
        success_message.append("  pip install -e .\n")

        console.print(Panel(success_message, border_style="green"))

    except FileExistsError:
        console.print(
            Panel(
                f"Directory '{name}' already exists.",
                title="Error",
                border_style="red",
            )
        )
        raise typer.Exit(code=1)

    except Exception as e:
        console.print(
            Panel(
                f"Unexpected error: {e}",
                title="Error",
                border_style="red",
            )
        )
        raise typer.Exit(code=1)


if __name__ == "__main__":
    app()
