from dataclasses import dataclass
from datetime import datetime


@dataclass
class ProjectContext:
    project_name: str
    package_name: str
    author: str = "Unknown"
    python_version: str = "3.8"
    created_at: datetime = datetime.now()
