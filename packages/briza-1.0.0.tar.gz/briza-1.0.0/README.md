# 🌬️ briza

![Python](https://img.shields.io/badge/python-3.10%2B-blue)
![Version](https://img.shields.io/badge/version-1.0.0-green)
![License](https://img.shields.io/badge/license-GPL--3.0-red)
![Status](https://img.shields.io/badge/status-stable-brightgreen)

> A fast, opinionated CLI to bootstrap clean Python projects.

briza helps you create structured, production-ready Python projects in seconds — with sensible defaults and zero boilerplate friction.

---

## ✨ Features

- ⚡ Instant project scaffolding
- 📦 Pre-configured `pyproject.toml`
- 🗂 Clean `src/`-based structure
- 🧩 Minimal and opinionated defaults
- 🛠 Built for real-world Python development

---

## 📦 Installation

```bash
pip install briza
```

---

## 🚀 Quick Start

Create a new project:

```bash
briza new my_project
```

Done.

Your project is ready to go.

---

## 🛠 Commands

### `briza new <project_name>`

Creates a new Python project with:

- Configured `pyproject.toml`
- Organized directory structure
- Starter files
- Clean entry point

Example:

```bash
briza new api_service
```

---

## 📁 Example Generated Structure

```
my_project/
├── pyproject.toml
├── README.md
└── src/
    └── my_project/
        ├── __init__.py
        └── main.py
```

---

## 🎯 Philosophy

briza follows a few core principles:

- Keep it simple
- Prefer convention over configuration
- Avoid unnecessary complexity
- Stay fast and lightweight

It is designed for developers who want structure — not ceremony.

---

## 📌 Version

Current stable release: **1.0.0**

briza follows [Semantic Versioning](https://semver.org/).

---

## 🛣 Roadmap

Future improvements may include:

- Plugin system
- Template customization
- Project presets (API, CLI, library)
- Optional CI configuration

---

## 🤝 Contributing

Contributions, issues, and suggestions are welcome.

If you'd like to improve briza:

1. Fork the repository
2. Create your feature branch
3. Submit a Pull Request

---

## 📄 License

This project is licensed under the **GNU General Public License v3.0 (GPL-3.0)**.

You are free to use, modify, and distribute this software under the same license terms.

See the `LICENSE` file for full details.