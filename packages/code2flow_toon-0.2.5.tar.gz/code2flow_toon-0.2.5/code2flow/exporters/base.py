"""Base Exporter class for code2flow."""

from abc import ABC, abstractmethod
from ..core.models import AnalysisResult


class Exporter(ABC):
    """Abstract base class for all exporters."""
    
    @abstractmethod
    def export(self, result: AnalysisResult, output_path: str, **kwargs) -> None:
        """Export analysis result to the specified path."""
        pass
