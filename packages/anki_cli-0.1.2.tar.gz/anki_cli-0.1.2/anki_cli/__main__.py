from anki_cli.cli.app import main

if __name__ == "__main__":
    main()