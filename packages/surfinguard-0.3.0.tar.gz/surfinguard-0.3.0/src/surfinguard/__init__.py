"""Surfinguard Python SDK — the trust layer for AI agents."""

from ._version import __version__
from .client import Guard
from .enums import ActionType, Policy, RiskLevel, RiskPrimitive
from .exceptions import (
    APIError,
    AuthenticationError,
    NotAllowedError,
    RateLimitError,
    SurfinguardError,
)
from .models import CheckResult, HealthResponse, PrimitiveScore

__all__ = [
    "__version__",
    "Guard",
    "CheckResult",
    "HealthResponse",
    "PrimitiveScore",
    "RiskLevel",
    "RiskPrimitive",
    "Policy",
    "ActionType",
    "SurfinguardError",
    "AuthenticationError",
    "RateLimitError",
    "APIError",
    "NotAllowedError",
]
