from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from .enums import RiskLevel, RiskPrimitive


class PrimitiveScore(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    primitive: RiskPrimitive
    score: int = Field(ge=0, le=10)
    reasons: list[str] = Field(default_factory=list)


class CheckResult(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    allow: bool
    score: int = Field(ge=0, le=10)
    level: RiskLevel
    primitive: RiskPrimitive | None = None
    primitive_scores: list[PrimitiveScore] = Field(default_factory=list, alias="primitiveScores")
    reasons: list[str] = Field(default_factory=list)
    alternatives: list[str] | None = None
    latency_ms: float = Field(default=0, alias="latencyMs")


class HealthResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    ok: bool
    version: str
    analyzers: list[str]
    auth: bool = False
    llm: bool = False
    uptime: int = 0
