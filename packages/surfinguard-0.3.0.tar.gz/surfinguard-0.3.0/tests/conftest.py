from __future__ import annotations

import pytest
import respx
import httpx

from surfinguard import Guard, Policy


SAFE_RESPONSE = {
    "allow": True,
    "score": 0,
    "level": "SAFE",
    "primitive": None,
    "primitiveScores": [],
    "reasons": [],
    "alternatives": None,
    "latencyMs": 1.2,
}

CAUTION_RESPONSE = {
    "allow": True,
    "score": 4,
    "level": "CAUTION",
    "primitive": "MANIPULATION",
    "primitiveScores": [{"primitive": "MANIPULATION", "score": 4, "reasons": ["Suspicious"]}],
    "reasons": ["Suspicious pattern"],
    "alternatives": None,
    "latencyMs": 2.1,
}

DANGER_RESPONSE = {
    "allow": False,
    "score": 9,
    "level": "DANGER",
    "primitive": "DESTRUCTION",
    "primitiveScores": [{"primitive": "DESTRUCTION", "score": 9, "reasons": ["Destructive"]}],
    "reasons": ["Destructive operation detected"],
    "alternatives": ["Use a safer command"],
    "latencyMs": 1.5,
}

HEALTH_RESPONSE = {
    "ok": True,
    "version": "2.2.0",
    "analyzers": ["url", "command", "text", "file_read", "file_write"],
    "auth": False,
    "llm": False,
    "uptime": 3600,
}


@pytest.fixture()
def mock_api():
    """respx mock router scoped to each test."""
    with respx.mock(base_url="https://test.surfinguard.com", assert_all_called=False) as api:
        yield api


@pytest.fixture()
def guard():
    """Guard instance pointed at mock API."""
    return Guard(
        api_key="sg_test_0123456789abcdef0123456789abcdef",
        base_url="https://test.surfinguard.com",
        policy=Policy.MODERATE,
    )


@pytest.fixture()
def strict_guard():
    """Guard with STRICT policy."""
    return Guard(
        api_key="sg_test_0123456789abcdef0123456789abcdef",
        base_url="https://test.surfinguard.com",
        policy=Policy.STRICT,
    )


@pytest.fixture()
def permissive_guard():
    """Guard with PERMISSIVE policy."""
    return Guard(
        api_key="sg_test_0123456789abcdef0123456789abcdef",
        base_url="https://test.surfinguard.com",
        policy=Policy.PERMISSIVE,
    )
