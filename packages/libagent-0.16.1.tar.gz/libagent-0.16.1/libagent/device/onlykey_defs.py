"""OnlyKey-related definitions."""

# pylint: disable=unused-import,import-error,no-name-in-module

from onlykey import Message, OnlyKey
