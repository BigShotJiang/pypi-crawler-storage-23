# stocksim_easy

Beginner-friendly Python library for your **Stock Simulator API**.

## Install

From your project venv:

```bash
pip install -U requests pandas plotly
```

Then (option A) copy this folder into your project and import it.

Or (option B) install editable from this folder:

```bash
pip install -e .
```

## Super simple usage (recommended)

```python
from stocksim_easy.easy import quickstart

result = quickstart(
    base_url="http://127.0.0.1:8000",
    csv_path="stock_data_csv",
    feature_ids=[1, 11, 36],  # ret_1d, sma_20, rsi_14
    # If weights omitted, uses your default formula:
    # score = 0.3*rsi_14 + 0.3*sma_signal + 0.4*ret_1d
    out_dir="out",
    signals="long",
)

print("Score preview:", result["scores_preview"])
print("Open these files in your browser:", result["plots"])
```

## More control

```python
from stocksim_easy import StockSim
from stocksim_easy.scoring import compute_scores
from stocksim_easy.plots import save_price_and_score_plot

sim = StockSim("http://127.0.0.1:8000")

# 1) get features
feats = sim.ohlcv_with_features("stock_data_csv", feature_ids=[1, 11, 36])

# 2) compute score with custom weights (still returns a plain list)
scores = compute_scores(feats, {"rsi_14": 0.3, "sma_signal": 0.3, "ret_1d": 0.4})

# 3) make a plot HTML file
save_price_and_score_plot(feats, scores, out_html="price_and_score.html")
```

## Notes

- Users don’t need to know pandas/matplotlib.
- Plots are HTML files. Double-click to open them in a browser.
