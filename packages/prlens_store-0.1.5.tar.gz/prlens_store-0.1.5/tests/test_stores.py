"""Tests for prlens-store implementations."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

from prlens_store.models import CommentRecord, ReviewRecord
from prlens_store.noop import NoOpStore
from prlens_store.sqlite import SQLiteStore


def _make_record(repo="owner/repo", pr_number=1, total_comments=2, event="COMMENT"):
    return ReviewRecord(
        repo=repo,
        pr_number=pr_number,
        pr_title="Fix auth bug",
        reviewer_model="anthropic",
        head_sha="a" * 40,
        reviewed_at=datetime.now(timezone.utc).isoformat(),
        event=event,
        total_comments=total_comments,
        files_reviewed=1,
        comments=[
            CommentRecord(file="src/auth.py", line=42, severity="major", comment="Missing null check"),
        ],
    )


# ---------------------------------------------------------------------------
# NoOpStore
# ---------------------------------------------------------------------------


class TestNoOpStore:
    def test_save_does_not_raise(self):
        store = NoOpStore()
        store.save(_make_record())  # must not raise

    def test_list_reviews_returns_empty(self):
        store = NoOpStore()
        store.save(_make_record())
        assert store.list_reviews("owner/repo") == []

    def test_list_reviews_with_pr_number_returns_empty(self):
        store = NoOpStore()
        assert store.list_reviews("owner/repo", pr_number=1) == []


# ---------------------------------------------------------------------------
# SQLiteStore
# ---------------------------------------------------------------------------


class TestSQLiteStore:
    def test_save_and_list(self, tmp_path):
        store = SQLiteStore(db_path=str(tmp_path / "test.db"))
        record = _make_record()
        store.save(record)

        results = store.list_reviews("owner/repo")
        assert len(results) == 1
        assert results[0].repo == "owner/repo"
        assert results[0].pr_number == 1
        assert results[0].total_comments == 2
        store.close()

    def test_list_by_pr_number(self, tmp_path):
        store = SQLiteStore(db_path=str(tmp_path / "test.db"))
        store.save(_make_record(pr_number=1))
        store.save(_make_record(pr_number=2))

        results = store.list_reviews("owner/repo", pr_number=1)
        assert len(results) == 1
        assert results[0].pr_number == 1
        store.close()

    def test_list_different_repo_isolated(self, tmp_path):
        store = SQLiteStore(db_path=str(tmp_path / "test.db"))
        store.save(_make_record(repo="owner/repo-a"))
        store.save(_make_record(repo="owner/repo-b"))

        results = store.list_reviews("owner/repo-a")
        assert len(results) == 1
        assert results[0].repo == "owner/repo-a"
        store.close()

    def test_comments_roundtrip(self, tmp_path):
        store = SQLiteStore(db_path=str(tmp_path / "test.db"))
        record = _make_record()
        store.save(record)

        results = store.list_reviews("owner/repo")
        assert len(results[0].comments) == 1
        comment = results[0].comments[0]
        assert comment.file == "src/auth.py"
        assert comment.line == 42
        assert comment.severity == "major"
        assert comment.comment == "Missing null check"
        store.close()

    def test_empty_repo_returns_empty_list(self, tmp_path):
        store = SQLiteStore(db_path=str(tmp_path / "test.db"))
        assert store.list_reviews("owner/nonexistent") == []
        store.close()

    def test_multiple_saves_accumulate(self, tmp_path):
        store = SQLiteStore(db_path=str(tmp_path / "test.db"))
        store.save(_make_record(pr_number=1))
        store.save(_make_record(pr_number=2))
        store.save(_make_record(pr_number=3))

        results = store.list_reviews("owner/repo")
        assert len(results) == 3
        store.close()

    def test_persists_across_connections(self, tmp_path):
        """Data written by one SQLiteStore instance must be readable by another."""
        db_path = str(tmp_path / "test.db")
        store_a = SQLiteStore(db_path=db_path)
        store_a.save(_make_record())
        store_a.close()

        store_b = SQLiteStore(db_path=db_path)
        results = store_b.list_reviews("owner/repo")
        assert len(results) == 1
        store_b.close()
