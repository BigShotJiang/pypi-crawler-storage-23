import time
import threading
from queue_kafka import Producer, Consumer, event_handler
from datetime import datetime, timezone

SIGNUP_TOPIC = "signup-topic"

producer = Producer()

@event_handler("USER_SIGNUP", stage=SIGNUP_TOPIC)
def handle_signup_email(event):
    """Handle user signup and send confirmation email"""
    print("   ✅ Confirmation email sent successfully!")
    print("-" * 50)

class EmailConsumerTest:
    def __init__(self):
        self.consumer = None
        self.producer = Producer()
    
    def start_consumer(self):
        """Start the email consumer"""
        print(f"🚀 Starting EmailConsumer for topic: {SIGNUP_TOPIC}")
        
        self.consumer = Consumer(
            topics=SIGNUP_TOPIC,
            config={
                "stage": SIGNUP_TOPIC,
                "source": "user-service",
                "tenantId": "tenant-123",    
            }
        )
        
        consumer_thread = threading.Thread(target=self.consumer.start)
        consumer_thread.daemon = True
        consumer_thread.start()
        
        time.sleep(2)
        print("✅ EmailConsumer started successfully!")
    
    def send_signup_event(self):
        signup_event = {
            "eventType": "USER_SIGNUP",
            "eventVersion": "1.0",
            "source": "user-service",
            "tenantId": "tenant-123",
            "payload": {
                "userId": "user-456",
                "email": "john.doe@example.com",
                "name": "John Doe",
                "signupDate": datetime.now(timezone.utc).isoformat()
            },
            "metadata": {
                "source_ip": "192.168.1.1",
                "user_agent": "Mozilla/5.0"
            }
        }
        
        print(f"\n📤 Sending signup event to topic: {SIGNUP_TOPIC}")
        
        try:
            self.producer.send(SIGNUP_TOPIC, signup_event)
            print("✅ Signup event sent successfully!")
        except Exception as e:
            print(f"❌ Failed to send signup event: {e}")
    
    def run_test(self):
        print("=" * 60)
        print("EMAIL SERVICE PIPELINE TEST")
        print("=" * 60)
        
        try:
            # Start consumer
            self.start_consumer()
            
            # Send test event
            self.send_signup_event()
            
            # Wait for processing
            print("\nWaiting for email processing.................")
            time.sleep(5)
            
            print("\n🎉 Test completed successfully!")
            
        except KeyboardInterrupt:
            print("\n⚠️ Test interrupted by user")
        except Exception as e:
            print(f"\n❌ Test failed: {e}")
        finally:
            # Cleanup
            if self.consumer:
                self.consumer.stop()
                print("🛑 Consumer stopped")
            self.producer.close()
            print("🔒 Producer closed")

if __name__ == "__main__":
    test = EmailConsumerTest()
    test.run_test()
