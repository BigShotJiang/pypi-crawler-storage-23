class QueueSDKError(Exception):
    """Base exception for all Queue SDK errors."""
    pass


class ConfigurationError(QueueSDKError):
    """Raised when there's a configuration issue."""
    pass


class HandlerNotFoundError(QueueSDKError):
    """Raised when no handler is found for an event type/stage combination."""
    pass


class EventProcessingError(QueueSDKError):
    """Raised when event processing fails."""
    pass


class ProducerError(QueueSDKError):
    """Raised when producer operations fail."""
    pass


class ConsumerError(QueueSDKError):
    """Raised when consumer operations fail."""
    pass


class SerializationError(QueueSDKError):
    """Raised when event serialization/deserialization fails."""
    pass
