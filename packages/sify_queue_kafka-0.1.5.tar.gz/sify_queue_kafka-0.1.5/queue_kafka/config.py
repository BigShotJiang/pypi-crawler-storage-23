from dataclasses import dataclass

@dataclass
class QueueConfig:
    bootstrap_servers: str = "223.30.168.148:9092"
    group_id: str = ""
    enable_auto_commit: bool = False
    auto_offset_reset: str = "earliest"

    enable_idempotency: bool = True
    enable_retry: bool = True
    dead_letter_topic: str = None
    stage: str = ""
    
    enable_idempotent_producer: bool = False  
