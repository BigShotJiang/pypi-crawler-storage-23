from .registry import EventRegistry

registry = EventRegistry()

def event_handler(event_type: str, stage: str = None):
    def decorator(func):
        registry.register(event_type, func, stage)
        return func
    return decorator
