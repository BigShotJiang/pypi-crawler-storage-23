from pydantic import BaseModel, Field
from typing import Any, Dict, Optional
from datetime import datetime
import uuid

class KafkaEvent(BaseModel):
    eventId: str = Field(default_factory=lambda: str(uuid.uuid4()))
    eventType: str
    eventVersion: str
    source: str
    tenantId: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

    correlationId: Optional[str] = None
    traceId: Optional[str] = None

    priority: Optional[str] = "MEDIUM"
    retryCount: int = 0
    maxRetries: Optional[int] = 5

    payload: Dict[str, Any]
    metadata: Optional[Dict[str, Any]] = None