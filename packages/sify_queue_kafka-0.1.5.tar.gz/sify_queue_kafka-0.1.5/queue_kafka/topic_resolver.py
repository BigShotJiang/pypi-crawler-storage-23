class TopicResolver:
    def __init__(self, environment: str):
        self.environment = environment

    def resolve(self, logical_topic: str) -> str:
        return f"{self.environment}.{logical_topic}"
