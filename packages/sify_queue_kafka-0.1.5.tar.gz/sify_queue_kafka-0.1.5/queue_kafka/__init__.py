"""
Sify Queue Kafka
"""

__version__ = "0.1.5"

from .config import QueueConfig
from .models import KafkaEvent
from .producer import Producer
from .consumer import Consumer
from .dispatcher import Dispatcher
from .decorators import event_handler
from .registry import EventRegistry, registry
from .exceptions import (
    QueueSDKError,
    ConfigurationError,
    HandlerNotFoundError,
    EventProcessingError,
    ProducerError,
    ConsumerError,
    SerializationError,
)

__all__ = [
    "QueueConfig",
    "KafkaEvent",
    "Producer",
    "Consumer",
    "Dispatcher",
    "event_handler",
    "registry",
    "EventRegistry",
    "QueueSDKError",
    "ConfigurationError",
    "HandlerNotFoundError",
    "EventProcessingError",
    "ProducerError",
    "ConsumerError",
    "SerializationError",
]
