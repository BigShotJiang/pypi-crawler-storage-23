import json
from kafka import KafkaConsumer
from typing import Optional, Dict, Union, List

from .models import KafkaEvent
from .utils import get_logger
from .dispatcher import Dispatcher
from .config import QueueConfig
from .decorators import registry


BOOTSTRAP = "223.30.168.148:9092"

class Consumer:
    def __init__( self, topics: Union[str, List[str]], config: Optional[Dict] = None, ):
        if isinstance(topics, str):
            topics = [topics]

        stage = None
        dead_letter_topic = None
        tenant_id = None
        source = None

        if config:
            stage = config.get("stage")
            dead_letter_topic = config.get("dead_letter_topic")
            tenant_id = config.get("tenant_id")
            source = config.get("source")
            
        self.config = QueueConfig(
            group_id=f"{tenant_id}.{source}.{stage}.group",
            dead_letter_topic=dead_letter_topic,
            stage=stage,
        )

        self.running = True
        self.logger = get_logger(f"Consumer.{self.config.stage or 'default'}")

        self.consumer = KafkaConsumer(
            bootstrap_servers=self.config.bootstrap_servers,
            group_id=self.config.group_id,
            enable_auto_commit=self.config.enable_auto_commit,
            auto_offset_reset=self.config.auto_offset_reset,
            value_deserializer=lambda m: json.loads(m.decode("utf-8")),
        )

        self.consumer.subscribe(topics)
        self.dispatcher = Dispatcher(registry, self.config)
        self.logger.info("Consumer initialized successfully")

    def start(self):
        self.logger.info(f"Consumer started...")
        try:
            while self.running:
                records = self.consumer.poll(timeout_ms=1000)

                for tp, messages in records.items():
                    for message in messages:
                        try:
                            event = KafkaEvent(**message.value)
                            self.logger.debug(f"Processing event: {event.eventId}")

                            self.dispatcher.dispatch(event)

                            if not self.config.enable_auto_commit:
                                self.consumer.commit()

                        except Exception as e:
                            event_id = message.value.get("eventId", "unknown")
                            self.logger.error(
                                f"Error processing event {event_id}: {e}"
                            )
                            continue

        except KeyboardInterrupt:
            self.logger.info("Keyboard interrupt received. Shutting down...")

        except Exception as e:
            self.logger.error(f"Unexpected error in consumer: {e}")

        finally:
            self.consumer.close()
            self.logger.info("Consumer closed.")

    def stop(self):
        self.running = False
        self.logger.info("Stop signal received.")