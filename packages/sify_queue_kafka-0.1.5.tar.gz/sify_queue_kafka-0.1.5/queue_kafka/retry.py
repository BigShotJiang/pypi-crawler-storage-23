import time
from typing import Callable, Any
from .utils import get_logger


def retry_with_backoff(handler: Callable[[Any], Any], event: Any, max_retries: int, 
                      base_delay: float = 1.0, max_delay: float = 60.0) -> Any:
    
    logger = get_logger("Retry")
    
    while event.retryCount < max_retries:
        try:
            return handler(event)
        except Exception as e:
            event.retryCount += 1
            
            if event.retryCount >= max_retries:
                logger.error(f"Max retries ({max_retries}) exceeded for event {event.eventId}")
                raise MaxRetriesExceededError(f"Failed after {max_retries} retries: {e}")
            
            delay = min(base_delay * (2 ** (event.retryCount - 1)), max_delay)
            jitter = delay * 0.1 * (0.5 - time.time() % 1)
            final_delay = delay + jitter
            
            logger.warning(f"Retry {event.retryCount}/{max_retries} for event {event.eventId} "
                          f"after {final_delay:.2f}s. Error: {e}")
            time.sleep(final_delay)
    
    raise MaxRetriesExceededError(f"Failed after {max_retries} retries")
