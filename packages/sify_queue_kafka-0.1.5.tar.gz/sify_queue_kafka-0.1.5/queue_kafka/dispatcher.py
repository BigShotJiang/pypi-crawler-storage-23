from .idempotency import IdempotencyStore
from .retry import retry_with_backoff
from .utils import get_logger
from .exceptions import HandlerNotFoundError

class Dispatcher:

    def __init__(self, registry, config):
        self.registry = registry
        self.config = config
        self.logger = get_logger(f"Dispatcher.{config.stage or 'default'}")
        self.idempotency_store = IdempotencyStore()

    def dispatch(self, event):
        if self.config.enable_idempotency and self.idempotency_store.is_duplicate( self.config.group_id, event.eventId ):
            self.logger.debug(f"Duplicate event detected: {event.eventId}")
            return

        handler = self.registry.get_handler(
            event.eventType,
            self.config.stage
        )

        if not handler:
            error_msg = f"No handler found for {event.eventType} @ {self.config.stage}"
            self.logger.warning(error_msg)
            raise HandlerNotFoundError(error_msg)

        try:
            if self.config.enable_retry:
                retry_with_backoff(handler, event, event.maxRetries)
            else:
                handler(event)
            
            self.logger.info(f"Successfully processed event: {event.eventId}")
            
        except Exception as e:
            self.logger.error(f"Failed to process event {event.eventId}: {e}")
            
            if self.config.dead_letter_topic:
                self._send_to_dlq(event, str(e))
            else:
                raise

    def _send_to_dlq(self, event, error_message):
        try:
            from .producer import Producer
                        
            if event.metadata is None:
                event.metadata = {}
            event.metadata['error'] = error_message
            event.metadata['failed_stage'] = self.config.stage
            event.metadata['failure_time'] = str(event.timestamp)
            
            producer = Producer(self.config)
            producer.send(self.config.dead_letter_topic, event)
            producer.close()
            
            self.logger.info(f"Sent event {event.eventId} to DLQ: {self.config.dead_letter_topic}")
            
        except Exception as dlq_error:
            self.logger.error(f"Failed to send event {event.eventId} to DLQ: {dlq_error}")
            raise