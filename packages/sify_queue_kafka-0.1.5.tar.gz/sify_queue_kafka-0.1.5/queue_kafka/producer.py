import json
import uuid
from datetime import datetime, timezone
from kafka import KafkaProducer
from .models import KafkaEvent
from .utils import get_logger
from .exceptions import ProducerError
from .config import QueueConfig
from typing import Union, List, Optional

class Producer:
    def __init__(self, config: Optional[QueueConfig] = None):
        self.logger = get_logger("Producer")
        self.config = QueueConfig()
        try:
            print("bootstrap_servers", self.config.bootstrap_servers, flush=True)
            self.producer = KafkaProducer(
                bootstrap_servers=self.config.bootstrap_servers,
                value_serializer=lambda v: json.dumps(v, default=str).encode("utf-8"),
                key_serializer=lambda k: k.encode("utf-8") if k else None,
                acks="all",
                enable_idempotence=self.config.enable_idempotency
            )
            self.logger.info("Producer initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize producer: {e}")
            raise ProducerError(f"Producer initialization failed: {e}")

    def send(self, topic: Union[str, List[str]], message: dict) -> None:
        try:
            event = KafkaEvent(
                eventId=str(uuid.uuid4()),
                eventType=message.get("eventType"),
                eventVersion=message.get("eventVersion", "1.0"),
                source=message.get("source"),
                tenantId=message.get("tenantId"),
                timestamp=datetime.now(timezone.utc),
                correlationId=str(uuid.uuid4()),
                traceId=str(uuid.uuid4()),
                priority=message.get("priority", "MEDIUM"),
                payload=message.get("payload", {}),
                metadata=message.get("metadata", {})
            )

            event_dict = event.model_dump(mode="json")

            topics = [topic] if isinstance(topic, str) else topic

            for t in topics:
                self.producer.send(t, value=event_dict, key=event.eventId)

        except Exception as e:
            self.logger.error(f"Failed to send event: {e}")
            raise ProducerError(f"Failed to send event: {e}")

    def flush(self):
        try:
            self.producer.flush()
            self.logger.debug("Producer flushed successfully")
        except Exception as e:
            self.logger.error(f"Failed to flush producer: {e}")
            raise ProducerError(f"Failed to flush producer: {e}")

    def close(self):
        try:
            self.producer.flush()
            self.producer.close()
            self.logger.info("Producer closed successfully")
        except Exception as e:
            self.logger.error(f"Error closing producer: {e}")
            raise ProducerError(f"Error closing producer: {e}")
