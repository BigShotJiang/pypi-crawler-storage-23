class EventRegistry:
    def __init__(self):
        self._handlers = {}

    def register(self, event_type, handler, stage=None):
        key = (event_type, stage)
        self._handlers[key] = handler

    def get_handler(self, event_type, stage=None):
        return self._handlers.get((event_type, stage))


registry = EventRegistry()
