import threading

class IdempotencyStore:
    def __init__(self):
        self.processed_ids = set()
        self.lock = threading.Lock()

    def is_duplicate(self, group_id: str, event_id: str) -> bool:
        key = f"{group_id}:{event_id}"

        with self.lock:
            if key in self.processed_ids:
                return True

            self.processed_ids.add(key)
            return False
