"""Operator-specific conversion module for dag_converter."""
