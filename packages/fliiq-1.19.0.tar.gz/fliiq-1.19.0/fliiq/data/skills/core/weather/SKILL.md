---
name: weather
description: "Get current weather and forecasts for any location. Free, no API key required. Returns temperature, humidity, wind, conditions, and daily forecasts."
---

Use this tool to get weather information for any city or coordinates. Returns current conditions and optional multi-day forecast. Powered by Open-Meteo (free, no API key needed).

## Usage
- Pass a city name (e.g. "Tokyo", "New York") or coordinates ("48.8566,2.3522")
- Optionally request a forecast (1-7 days)
- Returns temperature in Celsius, humidity, wind speed, and weather conditions

## No Setup Required
This skill uses the Open-Meteo API which is free and requires no API key.
