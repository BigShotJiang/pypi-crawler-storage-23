---
name: receive_sms
description: "Fetch recent inbound SMS messages via Twilio API. Requires TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_PHONE_NUMBER environment variables."
---

Fetch inbound SMS messages sent to your Twilio phone number. Filters by direction (inbound only) and optional `since` timestamp.

Defaults to messages from the last hour if `since` is not provided. Returns up to 10 messages with sender number, body, and timestamp.

Setup: Same credentials as send_sms — TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_PHONE_NUMBER in your .env file.
