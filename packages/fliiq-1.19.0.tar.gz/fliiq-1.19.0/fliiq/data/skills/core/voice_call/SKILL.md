---
name: voice_call
description: "Make outbound voice calls via Twilio. Speak a text message to the recipient using text-to-speech, or check call status."
---

Use this tool to make phone calls. The recipient hears a text-to-speech message. You can also check the status of a previous call.

## Setup
Uses the same Twilio credentials as the `send_sms` skill. Verify your phone number has voice capability:
1. Go to https://console.twilio.com > Phone Numbers > Active Numbers
2. Click your number and check that **Voice** is listed under Capabilities
3. If not, buy a voice-capable number (~$1.15/month for US local)

Required in `.env` (likely already configured for SMS):
```
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=...
TWILIO_PHONE_NUMBER=+1...
```

## Pricing
- Outbound to US: ~$0.014/min
- Outbound to international: varies by country
- See https://www.twilio.com/en-us/voice for pricing

## Notes
- On trial accounts, you can only call **verified phone numbers**
- Default voice is "alice" (natural-sounding). Options: alice, man, woman
