---
name: memory_read
description: "Read a memory file by name (MEMORY, daily log, or skill-specific memory)."
---

Use this tool to read from the agent's persistent memory. Memory types:
- `"MEMORY"` — curated long-term memory summary
- `"2026-02-03"` — daily log for a specific date
- `"skills/cantonese"` — deep skill-specific state

Returns the content and whether the file exists.
