---
name: memory_write
description: "Write or append to a memory file (MEMORY, daily log, or skill-specific memory)."
---

Use this tool to persist information to the agent's memory. Memory types:
- `"MEMORY"` — curated long-term memory (overwrite mode recommended)
- `"2026-02-03"` — daily log (append mode recommended)
- `"skills/fitness"` — deep skill-specific state

Modes:
- `"overwrite"` (default) — replace entire file
- `"append"` — append to file with separator (best for daily logs)
