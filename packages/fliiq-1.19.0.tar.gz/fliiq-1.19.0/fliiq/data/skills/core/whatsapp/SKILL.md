---
name: whatsapp
description: "Send WhatsApp messages and templates via the WhatsApp Business Cloud API (Meta Graph API)."
---

Use this tool to send WhatsApp messages. Supports free-form text messages (within 24-hour window after user messages you) and pre-approved message templates (for outbound at any time).

## Setup (Complex — allow 1-2 hours)
1. Create a Meta Business Portfolio at https://business.facebook.com/ if you don't have one
2. Complete **Business Verification** (Settings > Security Center > Start Verification) — requires legal docs, may take days
3. Go to https://developers.facebook.com/apps/ and create a new **Business** app
4. In the app dashboard, find WhatsApp > "Set up" and accept terms
5. Add and verify a phone number (the number must NOT be registered on any WhatsApp account)
6. Note the **Phone Number ID** from the API Setup page
7. Create a **System User** (Business Settings > Users > System Users) with Admin role
8. Assign your WhatsApp app to the system user with full control
9. Generate a **permanent token** with `whatsapp_business_messaging` permission

Add to your `.env` file:
```
WHATSAPP_TOKEN=your-permanent-system-user-token
WHATSAPP_PHONE_NUMBER_ID=your-phone-number-id
```

## Important Notes
- **Business Verification is mandatory** — without it you're limited to test numbers
- **Message Templates required** for outbound messages outside the 24-hour conversation window
- Templates must be submitted to Meta for approval (usually within 24 hours)
- Within the 24-hour window (after user messages you), free-form text is allowed
- The phone number **cannot** be registered on any existing WhatsApp account
