---
name: mark_email_read
description: "Mark an email as read by IMAP UID. Uses OAuth (via `fliiq google auth`) or app password fallback."
---

Mark an email as read (SEEN) using its IMAP UID from `receive_emails`. This prevents it from appearing in future `receive_emails` calls.

Pass the `id` field from a receive_emails result as the `message_id` parameter.
