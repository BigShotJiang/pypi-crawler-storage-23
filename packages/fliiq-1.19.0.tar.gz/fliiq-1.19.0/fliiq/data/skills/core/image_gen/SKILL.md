---
name: image_gen
description: "Generate images from text prompts using OpenAI DALL-E 3. Saves generated images to ~/.fliiq/generated/."
---

Use this tool to generate images from text descriptions using DALL-E 3. The generated image is saved locally and the file path is returned.

## Setup
Requires `OPENAI_API_KEY` environment variable (same key used for other OpenAI features).

Add to your `.env` file:
```
OPENAI_API_KEY=sk-...
```

Get an API key at https://platform.openai.com/api-keys

## Pricing
- Standard 1024x1024: ~$0.04/image
- HD 1024x1024: ~$0.08/image
- HD 1792x1024 or 1024x1792: ~$0.12/image
