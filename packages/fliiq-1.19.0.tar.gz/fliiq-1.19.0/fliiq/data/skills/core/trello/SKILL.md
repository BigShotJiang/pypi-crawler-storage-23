---
name: trello
description: "Manage Trello boards, lists, and cards. List boards, view cards, create/move/archive cards, and add comments."
---

Use this tool to interact with Trello for project management. Supports listing boards, viewing cards, creating cards, moving cards between lists, archiving cards, and adding comments.

## Setup
1. Go to https://trello.com/power-ups/admin and click "New" to create a Power-Up
2. Fill in name, select workspace, provide a placeholder URL for iframe connector
3. Go to the **API Key** tab and click "Generate a new API Key" — copy it
4. On the same page, click the **"Token"** link next to your API key
5. Click "Allow" on the authorization screen — copy the token

Add to your `.env` file:
```
TRELLO_API_KEY=your-api-key
TRELLO_TOKEN=your-token
```

## Important Notes
- You must create a **Power-Up first** just to get an API key (the old direct URL no longer works)
- Rate limits: 300 requests per 10 seconds per API key, 100 per 10 seconds per token
- The token grants access to **your Trello account only**
