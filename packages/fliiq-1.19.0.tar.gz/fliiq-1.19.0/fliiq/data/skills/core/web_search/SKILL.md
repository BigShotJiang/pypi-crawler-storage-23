---
name: web_search
description: "Search the web using Brave Search API and return structured results."
---

Use this tool to search the web. Returns titles, URLs, and snippets. Requires BRAVE_API_KEY environment variable. Use for finding documentation, tutorials, API references, news, etc.
