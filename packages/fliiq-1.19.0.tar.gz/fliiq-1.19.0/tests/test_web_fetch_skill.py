"""Tests for the web_fetch skill (migrated format)."""

import os

from fliiq.runtime.package_data import bundled_skills_dir
from fliiq.runtime.skills.base import SkillBase

SKILLS_DIR = str(bundled_skills_dir())


def _load_skill(name: str) -> SkillBase:
    return SkillBase(os.path.join(SKILLS_DIR, name))


def test_web_fetch_loads():
    """fetch_html skill loads with new SKILL.md format."""
    skill = _load_skill("web_fetch")
    assert skill.name == "fetch_html"
    assert "url" in skill.schema()["parameters"]["properties"]


def test_web_fetch_schema():
    """Schema includes all expected fields."""
    skill = _load_skill("web_fetch")
    schema = skill.schema()
    props = schema["parameters"]["properties"]
    assert "url" in props
    assert "start_index" in props
    assert "as_markdown" in props
    assert "url" in schema["parameters"]["required"]
