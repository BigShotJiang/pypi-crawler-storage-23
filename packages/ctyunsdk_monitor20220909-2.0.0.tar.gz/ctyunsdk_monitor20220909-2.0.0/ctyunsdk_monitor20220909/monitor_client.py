from ctyun_python_sdk_core import CtyunClient, Credential, ClientConfig, CtyunRequestException

from .models import *


class MonitorClient:
    def __init__(self, client_config: ClientConfig):
        self.endpoint = client_config.endpoint
        self.credential = Credential(client_config.access_key_id, client_config.access_key_secret)
        self.ctyun_client = CtyunClient(client_config.verify_tls)

    def v41_monitor_create_alarm_rule(self, request: V41MonitorCreateAlarmRuleRequest) -> V41MonitorCreateAlarmRuleResponse:
        """创建一个或多个告警规则。"""
        url = f"{self.endpoint}/v4.1/monitor/create-alarm-rule"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorCreateAlarmRuleResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_delete_alarm_rules(self, request: V41MonitorDeleteAlarmRulesRequest) -> V41MonitorDeleteAlarmRulesResponse:
        """调用此接口可批量删除多个告警规则。"""
        url = f"{self.endpoint}/v4.1/monitor/delete-alarm-rules"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorDeleteAlarmRulesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_change_alarm_rules_status(self, request: V41MonitorChangeAlarmRulesStatusRequest) -> V41MonitorChangeAlarmRulesStatusResponse:
        """批量更新告警规则状态为禁用或启用。"""
        url = f"{self.endpoint}/v4.1/monitor/change-alarm-rules-status"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorChangeAlarmRulesStatusResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_update_alarm_rule(self, request: V41MonitorUpdateAlarmRuleRequest) -> V41MonitorUpdateAlarmRuleResponse:
        """更新指定告警规则， 支持全量字段修改。"""
        url = f"{self.endpoint}/v4.1/monitor/update-alarm-rule"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorUpdateAlarmRuleResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_describe_alarm_rule(self, request: V41MonitorDescribeAlarmRuleRequest) -> V41MonitorDescribeAlarmRuleResponse:
        """查看告警规则的详情信息。"""
        url = f"{self.endpoint}/v4.1/monitor/describe-alarm-rule"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorDescribeAlarmRuleResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_query_alarm_rules(self, request: V41MonitorQueryAlarmRulesRequest) -> V41MonitorQueryAlarmRulesResponse:
        """根据筛选项查询告警规则列表。"""
        url = f"{self.endpoint}/v4.1/monitor/query-alarm-rules"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorQueryAlarmRulesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_create_task(self, request: V4MonitorIntelligentInspectionCreateTaskRequest) -> V4MonitorIntelligentInspectionCreateTaskResponse:
        """调用此接口可创建巡检任务。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/create-task"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionCreateTaskResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_query_task_overview(self, request: V4MonitorIntelligentInspectionQueryTaskOverviewRequest) -> V4MonitorIntelligentInspectionQueryTaskOverviewResponse:
        """调用此接口可查询巡检结果总览。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/query-task-overview"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionQueryTaskOverviewResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_query_task_detail(self, request: V4MonitorIntelligentInspectionQueryTaskDetailRequest) -> V4MonitorIntelligentInspectionQueryTaskDetailResponse:
        """调用此接口可查询巡检结果详情。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/query-task-detail"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionQueryTaskDetailResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_query_history_list(self, request: V4MonitorIntelligentInspectionQueryHistoryListRequest) -> V4MonitorIntelligentInspectionQueryHistoryListResponse:
        """调用此接口可查询巡检历史列表。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/query-history-list"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionQueryHistoryListResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_query_history_detail(self, request: V4MonitorIntelligentInspectionQueryHistoryDetailRequest) -> V4MonitorIntelligentInspectionQueryHistoryDetailResponse:
        """调用此接口可查询巡检历史详情。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/query-history-detail"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionQueryHistoryDetailResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_modify_inspection_item(self, request: V4MonitorIntelligentInspectionModifyInspectionItemRequest) -> V4MonitorIntelligentInspectionModifyInspectionItemResponse:
        """调用此接口可修改巡检项。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/modify-inspection-item"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionModifyInspectionItemResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_enable_inspection_item(self, request: V4MonitorIntelligentInspectionEnableInspectionItemRequest) -> V4MonitorIntelligentInspectionEnableInspectionItemResponse:
        """调用此接口可启用巡检项。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/enable-inspection-item"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionEnableInspectionItemResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_query_inspection_item(self, request: V4MonitorIntelligentInspectionQueryInspectionItemRequest) -> V4MonitorIntelligentInspectionQueryInspectionItemResponse:
        """调用此接口可查询巡检项。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/query-inspection-item"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionQueryInspectionItemResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_intelligent_inspection_disable_inspection_item(self, request: V4MonitorIntelligentInspectionDisableInspectionItemRequest) -> V4MonitorIntelligentInspectionDisableInspectionItemResponse:
        """调用此接口可禁用巡检项。"""
        url = f"{self.endpoint}/v4/monitor/intelligent-inspection/disable-inspection-item"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorIntelligentInspectionDisableInspectionItemResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_probe_point(self, request: V4MonitorQueryProbePointRequest) -> V4MonitorQueryProbePointResponse:
        """调用此接口可查询探测节点列表。"""
        url = f"{self.endpoint}/v4/monitor/query-probe-point"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQueryProbePointResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_modify_site_monitor(self, request: V4MonitorModifySiteMonitorRequest) -> V4MonitorModifySiteMonitorResponse:
        """调用此接口可修改站点监控任务。"""
        url = f"{self.endpoint}/v4/monitor/modify-site-monitor"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorModifySiteMonitorResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_create_site_monitor(self, request: V4MonitorCreateSiteMonitorRequest) -> V4MonitorCreateSiteMonitorResponse:
        """调用此接口可创建站点监控任务。"""
        url = f"{self.endpoint}/v4/monitor/create-site-monitor"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorCreateSiteMonitorResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_delete_site_monitor(self, request: V4MonitorDeleteSiteMonitorRequest) -> V4MonitorDeleteSiteMonitorResponse:
        """调用此接口可删除站点监控任务。"""
        url = f"{self.endpoint}/v4/monitor/delete-site-monitor"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDeleteSiteMonitorResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_enable_site_monitor(self, request: V4MonitorEnableSiteMonitorRequest) -> V4MonitorEnableSiteMonitorResponse:
        """调用此接口可启用站点监控任务。"""
        url = f"{self.endpoint}/v4/monitor/enable-site-monitor"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorEnableSiteMonitorResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_site_monitor(self, request: V4MonitorQuerySiteMonitorRequest) -> V4MonitorQuerySiteMonitorResponse:
        """调用此接口可查询站点监控任务。"""
        url = f"{self.endpoint}/v4/monitor/query-site-monitor"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQuerySiteMonitorResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_disable_site_monitor(self, request: V4MonitorDisableSiteMonitorRequest) -> V4MonitorDisableSiteMonitorResponse:
        """调用此接口可禁用站点监控任务。"""
        url = f"{self.endpoint}/v4/monitor/disable-site-monitor"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDisableSiteMonitorResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_task_center_create_task(self, request: V4MonitorTaskCenterCreateTaskRequest) -> V4MonitorTaskCenterCreateTaskResponse:
        """调用此接口可创建数据导出任务。"""
        url = f"{self.endpoint}/v4/monitor/task-center/create-task"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorTaskCenterCreateTaskResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_task_center_delete_task(self, request: V4MonitorTaskCenterDeleteTaskRequest) -> V4MonitorTaskCenterDeleteTaskResponse:
        """参见请求参数说明。"""
        url = f"{self.endpoint}/v4/monitor/task-center/delete-task"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorTaskCenterDeleteTaskResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_task_center_download(self, request: V4MonitorTaskCenterDownloadRequest) -> V4MonitorTaskCenterDownloadResponse:
        """调用此接口可获取下载链接地址。"""
        url = f"{self.endpoint}/v4/monitor/task-center/download"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorTaskCenterDownloadResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_create(self, request: V4MonitorMonitorBoardCreateRequest) -> V4MonitorMonitorBoardCreateResponse:
        """创建监控看板，可以创建空看板，也可以附带视图创建。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/create"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardCreateResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_create_view(self, request: V4MonitorMonitorBoardCreateViewRequest) -> V4MonitorMonitorBoardCreateViewResponse:
        """为已存在的监控看板创建视图。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/create-view"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardCreateViewResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_delete_view(self, request: V4MonitorMonitorBoardDeleteViewRequest) -> V4MonitorMonitorBoardDeleteViewResponse:
        """删除监控视图。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/delete-view"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardDeleteViewResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_copy_view(self, request: V4MonitorMonitorBoardCopyViewRequest) -> V4MonitorMonitorBoardCopyViewResponse:
        """复制已有监控视图。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/copy-view"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardCopyViewResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_delete(self, request: V4MonitorMonitorBoardDeleteRequest) -> V4MonitorMonitorBoardDeleteResponse:
        """删除监控看板。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/delete"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardDeleteResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_update_sys_resources(self, request: V4MonitorMonitorBoardUpdateSysResourcesRequest) -> V4MonitorMonitorBoardUpdateSysResourcesResponse:
        """为系统看板增加监控资源实例，会用给定的新资源替换原有旧资源。仅支持系统看板。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/update-sys-resources"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardUpdateSysResourcesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_update_view(self, request: V4MonitorMonitorBoardUpdateViewRequest) -> V4MonitorMonitorBoardUpdateViewResponse:
        """更新已有监控视图。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/update-view"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardUpdateViewResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_describe(self, request: V4MonitorMonitorBoardDescribeRequest) -> V4MonitorMonitorBoardDescribeResponse:
        """查看监控看板详细信息，包括视图信息，不包含监控数据信息。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/describe"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardDescribeResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_list(self, request: V4MonitorMonitorBoardListRequest) -> V4MonitorMonitorBoardListResponse:
        """查询监控看板列表，仅返回基础信息，不返回视图信息。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/list"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardListResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_query_sys_services(self, request: V4MonitorMonitorBoardQuerySysServicesRequest) -> V4MonitorMonitorBoardQuerySysServicesResponse:
        """查询系统看板支持的服务维度。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/query-sys-services"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardQuerySysServicesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_describe_view(self, request: V4MonitorMonitorBoardDescribeViewRequest) -> V4MonitorMonitorBoardDescribeViewResponse:
        """查看监控看板详细信息，包括视图信息，不包含监控数据信息。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/describe-view"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardDescribeViewResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_rename(self, request: V4MonitorMonitorBoardRenameRequest) -> V4MonitorMonitorBoardRenameResponse:
        """重命名监控看板。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/rename"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardRenameResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_monitor_board_query_view_data(self, request: V4MonitorMonitorBoardQueryViewDataRequest) -> V4MonitorMonitorBoardQueryViewDataResponse:
        """查询看板下某个视图的数据。"""
        url = f"{self.endpoint}/v4/monitor/monitor-board/query-view-data"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMonitorBoardQueryViewDataResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_update_contacts(self, request: V4MonitorUpdateContactsRequest) -> V4MonitorUpdateContactsResponse:
        """调用此接口可修改告警联系人配置，支持全量字段修改。"""
        url = f"{self.endpoint}/v4/monitor/update-contacts"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorUpdateContactsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_create_contact(self, request: V4MonitorCreateContactRequest) -> V4MonitorCreateContactResponse:
        """调用此接口可创建告警联系人，用于告警通知。"""
        url = f"{self.endpoint}/v4/monitor/create-contact"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorCreateContactResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_contact_activation_code(self, request: V4MonitorContactActivationCodeRequest) -> V4MonitorContactActivationCodeResponse:
        """调用此接口可对告警联系人发送手机短息激活验证码或邮箱激活验证码。"""
        url = f"{self.endpoint}/v4/monitor/contact-activation-code"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorContactActivationCodeResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_delete_contacts(self, request: V4MonitorDeleteContactsRequest) -> V4MonitorDeleteContactsResponse:
        """调用此接口可批量删除多个创建告警联系人。"""
        url = f"{self.endpoint}/v4/monitor/delete-contacts"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDeleteContactsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_describe_contact(self, request: V4MonitorDescribeContactRequest) -> V4MonitorDescribeContactResponse:
        """调用此接口可查看告警联系人的配置详情。"""
        url = f"{self.endpoint}/v4/monitor/describe-contact"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDescribeContactResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_query_contacts(self, request: V41MonitorQueryContactsRequest) -> V41MonitorQueryContactsResponse:
        """调用此接口可查询告警联系人的列表。"""
        url = f"{self.endpoint}/v4.1/monitor/query-contacts"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorQueryContactsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_activate_contact(self, request: V4MonitorActivateContactRequest) -> V4MonitorActivateContactResponse:
        """调用此接口可激活告警联系人的手机短息或邮箱，激活后的媒介可接收平台告警信息。"""
        url = f"{self.endpoint}/v4/monitor/activate-contact"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorActivateContactResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_create_contact_group(self, request: V4MonitorCreateContactGroupRequest) -> V4MonitorCreateContactGroupResponse:
        """调用此接口可创建告警联系组。"""
        url = f"{self.endpoint}/v4/monitor/create-contact-group"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorCreateContactGroupResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_delete_contact_group(self, request: V4MonitorDeleteContactGroupRequest) -> V4MonitorDeleteContactGroupResponse:
        """调用此接口可删除告警联系人组。"""
        url = f"{self.endpoint}/v4/monitor/delete-contact-group"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDeleteContactGroupResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_update_group_contacts(self, request: V4MonitorUpdateGroupContactsRequest) -> V4MonitorUpdateGroupContactsResponse:
        """调用此接口可变更告警联系组内的告警联系人列表。"""
        url = f"{self.endpoint}/v4/monitor/update-group-contacts"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorUpdateGroupContactsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_delete_contact_groups(self, request: V4MonitorDeleteContactGroupsRequest) -> V4MonitorDeleteContactGroupsResponse:
        """调用此接口可批量删除多个删除告警联系人组。"""
        url = f"{self.endpoint}/v4/monitor/delete-contact-groups"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDeleteContactGroupsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_update_contact_group(self, request: V4MonitorUpdateContactGroupRequest) -> V4MonitorUpdateContactGroupResponse:
        """调用此接口可修改告警联系组基本信息， 支持全量字段修改。"""
        url = f"{self.endpoint}/v4/monitor/update-contact-group"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorUpdateContactGroupResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_describe_contact_group(self, request: V4MonitorDescribeContactGroupRequest) -> V4MonitorDescribeContactGroupResponse:
        """调用此接口可查询告警联系人组的配置详情。"""
        url = f"{self.endpoint}/v4/monitor/describe-contact-group"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDescribeContactGroupResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_query_contact_groups(self, request: V41MonitorQueryContactGroupsRequest) -> V41MonitorQueryContactGroupsResponse:
        """调用此接口可查询告警联系人组的列表。"""
        url = f"{self.endpoint}/v4.1/monitor/query-contact-groups"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorQueryContactGroupsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_message_records(self, request: V4MonitorQueryMessageRecordsRequest) -> V4MonitorQueryMessageRecordsResponse:
        """查询通知记录列表。"""
        url = f"{self.endpoint}/v4/monitor/query-message-records"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQueryMessageRecordsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_update_event_alarm_rule(self, request: V4MonitorUpdateEventAlarmRuleRequest) -> V4MonitorUpdateEventAlarmRuleResponse:
        """修改事件的告警规则配置信息。"""
        url = f"{self.endpoint}/v4/monitor/update-event-alarm-rule"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorUpdateEventAlarmRuleResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_create_event_alarm_rule(self, request: V4MonitorCreateEventAlarmRuleRequest) -> V4MonitorCreateEventAlarmRuleResponse:
        """创建一个事件监控的告警规则。"""
        url = f"{self.endpoint}/v4/monitor/create-event-alarm-rule"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorCreateEventAlarmRuleResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_alert_history(self, request: V4MonitorQueryAlertHistoryRequest) -> V4MonitorQueryAlertHistoryResponse:
        """查询告警历史, 返回结果按告警历史的触发时间(createTime)降序排列。"""
        url = f"{self.endpoint}/v4/monitor/query-alert-history"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQueryAlertHistoryResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_items(self, request: V4MonitorQueryItemsRequest) -> V4MonitorQueryItemsResponse:
        """获取资源池下服务、维度、监控项信息。"""
        url = f"{self.endpoint}/v4/monitor/query-items"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQueryItemsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v42_monitor_query_latest_metric_data(self, request: V42MonitorQueryLatestMetricDataRequest) -> V42MonitorQueryLatestMetricDataResponse:
        """查询指定设备的实时监控数据。"""
        url = f"{self.endpoint}/v4.2/monitor/query-latest-metric-data"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V42MonitorQueryLatestMetricDataResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_alarm_top_event(self, request: V4MonitorQueryAlarmTopEventRequest) -> V4MonitorQueryAlarmTopEventResponse:
        """调用此接口可查询指定资源池下告警Top事件。"""
        url = f"{self.endpoint}/v4/monitor/query-alarm-top-event"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQueryAlarmTopEventResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_alarm_top_dimension(self, request: V4MonitorQueryAlarmTopDimensionRequest) -> V4MonitorQueryAlarmTopDimensionResponse:
        """调用此接口可查询指定资源池下告警Top产品。"""
        url = f"{self.endpoint}/v4/monitor/query-alarm-top-dimension"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQueryAlarmTopDimensionResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_alarm_top_resource(self, request: V4MonitorQueryAlarmTopResourceRequest) -> V4MonitorQueryAlarmTopResourceResponse:
        """调用此接口可查询指定资源池下告警Top实例。"""
        url = f"{self.endpoint}/v4/monitor/query-alarm-top-resource"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQueryAlarmTopResourceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_alarm_top_metric(self, request: V4MonitorQueryAlarmTopMetricRequest) -> V4MonitorQueryAlarmTopMetricResponse:
        """调用此接口可查询指定资源池下告警Top指标。"""
        url = f"{self.endpoint}/v4/monitor/query-alarm-top-metric"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQueryAlarmTopMetricResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_create_notice_template(self, request: V4MonitorCreateNoticeTemplateRequest) -> V4MonitorCreateNoticeTemplateResponse:
        """调用此接口可创建通知模板。"""
        url = f"{self.endpoint}/v4/monitor/create-notice-template"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorCreateNoticeTemplateResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_delete_notice_templates(self, request: V4MonitorDeleteNoticeTemplatesRequest) -> V4MonitorDeleteNoticeTemplatesResponse:
        """调用此接口可批量删除通知模板。"""
        url = f"{self.endpoint}/v4/monitor/delete-notice-templates"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDeleteNoticeTemplatesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_update_notice_template(self, request: V4MonitorUpdateNoticeTemplateRequest) -> V4MonitorUpdateNoticeTemplateResponse:
        """调用此接口可更新通知模板。"""
        url = f"{self.endpoint}/v4/monitor/update-notice-template"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorUpdateNoticeTemplateResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_describe_notice_template(self, request: V4MonitorDescribeNoticeTemplateRequest) -> V4MonitorDescribeNoticeTemplateResponse:
        """调用此接口可查看通知模板详情。"""
        url = f"{self.endpoint}/v4/monitor/describe-notice-template"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDescribeNoticeTemplateResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_notice_templates(self, request: V4MonitorQueryNoticeTemplatesRequest) -> V4MonitorQueryNoticeTemplatesResponse:
        """调用此接口可查询通知模板列表。"""
        url = f"{self.endpoint}/v4/monitor/query-notice-templates"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQueryNoticeTemplatesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_notice_template_variable(self, request: V4MonitorQueryNoticeTemplateVariableRequest) -> V4MonitorQueryNoticeTemplateVariableResponse:
        """调用此接口可查询信息配置的基本信息和告警对象。"""
        url = f"{self.endpoint}/v4/monitor/query-notice-template-variable"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQueryNoticeTemplateVariableResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_mark_notice_template_isdefault(self, request: V4MonitorMarkNoticeTemplateIsdefaultRequest) -> V4MonitorMarkNoticeTemplateIsdefaultResponse:
        """调用此接口可标记自定义默认通知模板。"""
        url = f"{self.endpoint}/v4/monitor/mark-notice-template-isdefault"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorMarkNoticeTemplateIsdefaultResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_create_alarm_template(self, request: V4MonitorCreateAlarmTemplateRequest) -> V4MonitorCreateAlarmTemplateResponse:
        """调用此接口可创建告警模板。"""
        url = f"{self.endpoint}/v4/monitor/create-alarm-template"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorCreateAlarmTemplateResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_delete_alarm_template(self, request: V4MonitorDeleteAlarmTemplateRequest) -> V4MonitorDeleteAlarmTemplateResponse:
        """调用此接口可删除告警模板。"""
        url = f"{self.endpoint}/v4/monitor/delete-alarm-template"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDeleteAlarmTemplateResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_copy_alarm_template(self, request: V4MonitorCopyAlarmTemplateRequest) -> V4MonitorCopyAlarmTemplateResponse:
        """调用此接口可复制告警模板。"""
        url = f"{self.endpoint}/v4/monitor/copy-alarm-template"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorCopyAlarmTemplateResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_delete_alarm_templates(self, request: V4MonitorDeleteAlarmTemplatesRequest) -> V4MonitorDeleteAlarmTemplatesResponse:
        """调用此接口可批量删除告警模板。"""
        url = f"{self.endpoint}/v4/monitor/delete-alarm-templates"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDeleteAlarmTemplatesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_update_alarm_template(self, request: V4MonitorUpdateAlarmTemplateRequest) -> V4MonitorUpdateAlarmTemplateResponse:
        """调用此接口可更新告警模板。"""
        url = f"{self.endpoint}/v4/monitor/update-alarm-template"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorUpdateAlarmTemplateResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_describe_alarm_template(self, request: V4MonitorDescribeAlarmTemplateRequest) -> V4MonitorDescribeAlarmTemplateResponse:
        """调用此接口可查看告警模板的配置详情。"""
        url = f"{self.endpoint}/v4/monitor/describe-alarm-template"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorDescribeAlarmTemplateResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_query_alarm_templates(self, request: V4MonitorQueryAlarmTemplatesRequest) -> V4MonitorQueryAlarmTemplatesResponse:
        """调用此接口可查询告警模板列表。"""
        url = f"{self.endpoint}/v4/monitor/query-alarm-templates"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorQueryAlarmTemplatesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_alert_onekey_enable_service(self, request: V41MonitorAlertOnekeyEnableServiceRequest) -> V41MonitorAlertOnekeyEnableServiceResponse:
        """此接口用于启用维度的一键告警规则。"""
        url = f"{self.endpoint}/v4.1/monitor/alert-onekey/enable-service"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorAlertOnekeyEnableServiceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_alert_onekey_disable_service(self, request: V4MonitorAlertOnekeyDisableServiceRequest) -> V4MonitorAlertOnekeyDisableServiceResponse:
        """此接口用于禁用一个产品的一键告警规则。"""
        url = f"{self.endpoint}/v4/monitor/alert-onekey/disable-service"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorAlertOnekeyDisableServiceResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_alert_onekey_describe_alert_config(self, request: V41MonitorAlertOnekeyDescribeAlertConfigRequest) -> V41MonitorAlertOnekeyDescribeAlertConfigResponse:
        """此接口用于获取单个产品一键告警规则配置信息。"""
        url = f"{self.endpoint}/v4.1/monitor/alert-onekey/describe-alert-config"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorAlertOnekeyDescribeAlertConfigResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_alert_onekey_update_service_notify_config(self, request: V4MonitorAlertOnekeyUpdateServiceNotifyConfigRequest) -> V4MonitorAlertOnekeyUpdateServiceNotifyConfigResponse:
        """此接口用于修改一个产品的已启用的一键告警通知策略， 对禁用的一键告警通知策略不生效。"""
        url = f"{self.endpoint}/v4/monitor/alert-onekey/update-service-notify-config"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorAlertOnekeyUpdateServiceNotifyConfigResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_alert_onekey_update_alert_config(self, request: V41MonitorAlertOnekeyUpdateAlertConfigRequest) -> V41MonitorAlertOnekeyUpdateAlertConfigResponse:
        """此接口用于修改一个产品的一键告警规则。"""
        url = f"{self.endpoint}/v4.1/monitor/alert-onekey/update-alert-config"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorAlertOnekeyUpdateAlertConfigResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_alert_onekey_change_alert_config_status(self, request: V4MonitorAlertOnekeyChangeAlertConfigStatusRequest) -> V4MonitorAlertOnekeyChangeAlertConfigStatusResponse:
        """此接口用于修改一个产品的一键告警规则状态。"""
        url = f"{self.endpoint}/v4/monitor/alert-onekey/change-alert-config-status"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorAlertOnekeyChangeAlertConfigStatusResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_events_count_data(self, request: V4MonitorEventsCountDataRequest) -> V4MonitorEventsCountDataResponse:
        """根据指定时间段统计指定事件发生情况。"""
        url = f"{self.endpoint}/v4/monitor/events/count-data"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorEventsCountDataResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_events_query_events(self, request: V4MonitorEventsQueryEventsRequest) -> V4MonitorEventsQueryEventsResponse:
        """获取资源池下指定维度下的事件。"""
        url = f"{self.endpoint}/v4/monitor/events/query-events"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorEventsQueryEventsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_events_query_list(self, request: V4MonitorEventsQueryListRequest) -> V4MonitorEventsQueryListResponse:
        """根据指定时间段查询事件发生情况。"""
        url = f"{self.endpoint}/v4/monitor/events/query-list"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorEventsQueryListResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v4_monitor_events_query_services(self, request: V4MonitorEventsQueryServicesRequest) -> V4MonitorEventsQueryServicesResponse:
        """获取资源池下服务维度信息。"""
        url = f"{self.endpoint}/v4/monitor/events/query-services"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V4MonitorEventsQueryServicesResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v42_monitor_query_history_metric_data(self, request: V42MonitorQueryHistoryMetricDataRequest) -> V42MonitorQueryHistoryMetricDataResponse:
        """查询指定时间段内的设备时序指标监控数据。接口调用可参考[帮助中心-云监控服务-最佳实践-通过云监控OpenAPI查询监控数据](https://www.ctyun.cn/document/10032263/11087634)。"""
        url = f"{self.endpoint}/v4.2/monitor/query-history-metric-data"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V42MonitorQueryHistoryMetricDataResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_create_resource_group(self, request: V41MonitorCreateResourceGroupRequest) -> V41MonitorCreateResourceGroupResponse:
        """调用此接口可创建一个资源分组。"""
        url = f"{self.endpoint}/v4.1/monitor/create-resource-group"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorCreateResourceGroupResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_update_resource_group(self, request: V41MonitorUpdateResourceGroupRequest) -> V41MonitorUpdateResourceGroupResponse:
        """调用此接口可更新资源分组，支持全量字段修改。"""
        url = f"{self.endpoint}/v4.1/monitor/update-resource-group"
        method = 'POST'
        try:
            headers = request.get_headers() or {} 
            body = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                body=body
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorUpdateResourceGroupResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))

    def v41_monitor_query_resource_groups(self, request: V41MonitorQueryResourceGroupsRequest) -> V41MonitorQueryResourceGroupsResponse:
        """调用此接口可查询用户资源分组列表。"""
        url = f"{self.endpoint}/v4.1/monitor/query-resource-groups"
        method = 'GET'
        try:
            headers = request.get_headers() or {} 
            params = request.to_dict()
            response = self.ctyun_client.request(
                url=url,
                method=method,
                credential=self.credential,
                headers=headers,
                params=params
            ) 
            return self.ctyun_client.handle_response(response, V41MonitorQueryResourceGroupsResponse)
        except Exception as e:
            raise CtyunRequestException(str(e))



