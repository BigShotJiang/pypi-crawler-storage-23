from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorCreateAlarmTemplateRequest(CtyunOpenAPIRequest):
    regionID: str  # ctyun资源池ID
    name: str  # 告警模板名称
    service: str  # 本参数表示服务。取值范围：<br>ecs：云主机。<br>evs：云硬盘。<br>pms：物理机。<br>...<br>详见"[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)"接口返回。
    dimension: str  # 本参数表示告警维度。取值范围：<br>ecs：云主机。<br>disk：磁盘。<br>pms：物理机。<br>...<br>详见"[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)"接口返回。
    desc: Optional[str] = None  # 告警模板描述
    conditions: Optional[List['V4MonitorCreateAlarmTemplateRequestConditions']] = None  # 告警规则

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorCreateAlarmTemplateRequestConditions:
    evaluationCount: Optional[int] = None  # 持续次数，当规则执行结果持续多久符合条件时报警（防抖），默认值：2
    metric: Optional[str] = None  # 监控指标，说明有condition参数时，metric是必填项
    fun: Optional[str] = None  # 本参数表示采用算法。默认值：min。取值范围：<br>last：原始值。<br>avg：平均值。<br>max：最大值。<br>min：最小值。<br>sum：总和。<br>根据以上范围取值。
    operator: Optional[str] = None  # 本参数表示比较符。默认值：le。取值范围：<br>eq：等于。<br>gt：大于。<br>ge：大于等于。<br>lt：小于。<br>le：小于等于。<br>ne：不等于。<br>rg：环比上升。<br>cf：环比下降。<br>rc：环比变化。<br>根据以上范围取值。
    value: Optional[str] = None  # 告警阈值，整数型或小数点型字符串， 默认值：80。 <br>&#32; 如果是小数点型字符串，小数点位数不能超过2位。
    period: Optional[str] = None  # 本参数表示算法统计周期。默认值：5m。<br>参数fun为last时不可传。<br>参数fun为avg、max、min、sum均需填此参数。<br>本参数格式为“数字+单位”。单位取值范围：<br>m：分钟。<br>h：小时。<br>d：天。<br>根据以上范围取值。
    unit: Optional[str] = None  # 本参数表示单位. 默认值：空字符。
    level: Optional[int] = None  # 本参数表示告警等级。默认值：3。 取值范围：<br>1：紧急。<br>2：警示。<br>3：普通。<br>根据以上范围取值。


@dataclass_json
@dataclass
class V4MonitorCreateAlarmTemplateResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorCreateAlarmTemplateReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorCreateAlarmTemplateReturnObj:
    templateID: Optional[str] = None  # 告警模板ID
