from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V41MonitorAlertOnekeyUpdateAlertConfigRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    alarmType: str  # 本参数表示告警类型。            取值范围：<br>series：时序指标。<br>event：事件。  <br>根据以上范围取值。
    alarmRuleID: str  # 告警规则ID
    service: str  # 本参数表示服务。取值范围：<br>ecs：云主机。<br>evs：云硬盘。<br>...<br>详见“[一键告警：产品列表]”接口返回。
    dimension: str  # 本参数表示云监控维度。取值范围：<br>ecs：云主机。<br>disk：磁盘。<br>pms：物理机。<br>...<br>详见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)
    name: str  # 规则名
    conditions: List['V41MonitorAlertOnekeyUpdateAlertConfigRequestConditions']  # 规则的触发条件，conditions元素个数需为1。
    repeatTimes: Optional[int] = None  # 重复告警通知次数，默认值：0，当repeatTimes值为-1，代表无限重复。
    silenceTime: Optional[int] = None  # 告警接收策略静默时间，多久重复通知一次，单位为秒。 默认值：300
    recoverNotify: Optional[int] = None  # 本参数表示恢复是否通知。默认值：0。取值范围：<br>0：否。<br>1：是。<br>根据以上范围取值。
    notifyType: Optional[List[str]] = None  # 本参数表示告警接收策略。取值范围：<br>email：邮件告警。<br>sms：短信告警。<br>根据以上范围取值。
    contactGroupList: Optional[List[str]] = None  # 告警联系人组
    defaultContact: Optional[int] = None  # 是否使用天翼云默认联系人发送通知。默认值：0<br />0：否<br />1：是
    notifyWeekdays: Optional[List[int]] = None  # 本参数表示通知周期。默认值[0,1,2,3,4,5,6]。取值范围：<br>0：周日。<br>1：周一。<br>2：周二。<br>3：周三。<br>4：周四。<br>5：周五。<br>6：周六。<br>根据以上范围取值。
    notifyStart: Optional[str] = None  # 通知起始时段，默认值：00:00:00
    notifyEnd: Optional[str] = None  # 通知结束时段，默认值：23:59:59
    webhookUrl: Optional[List[str]] = None  # 告警状态变更webhook推送地址
    noticeStrategyID: Optional[str] = None  # 通知策略ID

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V41MonitorAlertOnekeyUpdateAlertConfigRequestConditions:
    metric: str  # 指标名
    operator: str  # 注意：一键告警规则的告警类型（alarmType）为事件类型（event）时，不需要传入此参数；为其它告警类型时，是必填参数。<br>本参数表示比较符。默认值le，取值范围：<br>eq：等于。<br>gt：大于。<br>ge：大于等于。<br>lt：小于。<br>le：小于等于。<br>rg：环比上升。<br>cf：环比下降。<br>rc：环比变化。<br>根据以上范围取值。
    value: str  # 注意：一键告警规则的告警类型（alarmType）为事件类型（event）时，不需要传入此参数；为其它告警类型时，是必填参数。<br>&#32;告警阈值，可以是整数、小数或百分数格式字符串
    evaluationCount: Optional[int] = None  # 连续出现次数，默认0次
    unit: Optional[str] = None  # 单位
    level: Optional[int] = None  # 本参数表示告警等级。默认值：3。 取值范围：<br>1：紧急。<br>2：警示。<br>3：普通。<br>根据以上范围取值。
    fun: Optional[str] = None  # 本参数表示告警采用算法。默认值：last，取值范围：<br>last：原始值算法。<br>avg：平均值算法。<br>max：最大值算法。<br>min：最小值算法。<br>sum：求和算法。<br>根据以上范围取值。
    period: Optional[str] = None  # 本参数表示算法统计周期。默认值5m。<br>参数fun为last时不可传。<br>参数fun为avg、max、min均需填此参数。<br>本参数格式为“数字+单位”。单位取值范围：<br>m：分钟。<br>h：小时。<br>d：天。<br>根据以上范围取值。


@dataclass_json
@dataclass
class V41MonitorAlertOnekeyUpdateAlertConfigResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V41MonitorAlertOnekeyUpdateAlertConfigReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V41MonitorAlertOnekeyUpdateAlertConfigReturnObj:
    success: Optional[bool] = None  # 是否成功
