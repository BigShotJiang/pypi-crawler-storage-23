from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorDescribeAlarmTemplateRequest(CtyunOpenAPIRequest):
    regionID: str  # ctyun资源池ID
    templateID: str  # 告警模板ID

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorDescribeAlarmTemplateResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorDescribeAlarmTemplateReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorDescribeAlarmTemplateReturnObj:
    templateID: Optional[str] = None  # 告警模板ID
    name: Optional[str] = None  # 告警模板名称
    service: Optional[str] = None  # 服务
    dimension: Optional[str] = None  # 维度
    desc: Optional[str] = None  # 告警模板描述
    conditions: Optional[List['V4MonitorDescribeAlarmTemplateReturnObjConditions']] = None  # 告警规则
    createTime: Optional[int] = None  # 创建时间，时间戳，精确到毫秒
    updateTime: Optional[int] = None  # 最近更新时间, 时间戳，精确到毫秒


@dataclass_json
@dataclass
class V4MonitorDescribeAlarmTemplateReturnObjConditions:
    evaluationCount: Optional[int] = None  # 持续次数，当规则执行结果持续多久符合条件时报警（防抖）
    metric: Optional[str] = None  # 监控指标
    metricCnName: Optional[str] = None  # 监控指标中文描述
    fun: Optional[str] = None  # 本参数表示告警采用算法。取值范围：<br>last：原始值算法。<br>avg：平均值算法。<br>max：最大值算法。<br>min：最小值算法。<br>sum：求和算法。<br>根据以上范围取值。
    operator: Optional[str] = None  # 本参数表示比较符。取值范围：<br>eq：等于。<br>gt：大于。<br>ge：大于等于。<br>lt：小于。<br>le：小于等于。<br>rg：环比上升。<br>cf：环比下降。<br>rc：环比变化。<br>根据以上范围取值。
    value: Optional[str] = None  # 告警阈值
    period: Optional[str] = None  # 本参数表示算法统计周期。<br>参数fun为last时无效。<br>本参数格式为“数字+单位”。单位取值范围：<br>m：分钟。<br>h：小时。<br>d：天。<br>根据以上范围取值。
    unit: Optional[str] = None  # 单位
    level: Optional[int] = None  # 本参数表示告警等级。取值范围：<br>1：紧急。<br>2：警示。<br>3：普通。<br>根据以上范围取值。
