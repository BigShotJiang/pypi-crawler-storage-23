from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V41MonitorQueryResourceGroupsRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    name: Optional[str] = None  # 名称模糊搜索
    resGroupID: Optional[str] = None  # 资源分组ID搜索
    pageNo: Optional[int] = None  # 页码，默认为1
    pageSize: Optional[int] = None  # 每页数量，默认10

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V41MonitorQueryResourceGroupsResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V41MonitorQueryResourceGroupsReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V41MonitorQueryResourceGroupsReturnObj:
    resGroupList: Optional[List['V41MonitorQueryResourceGroupsReturnObjResGroupList']] = None  # 返回用户的资源分组列表
    resGroupQuota: Optional[int] = None  # 资源分组配额剩余数量
    totalCount: Optional[int] = None  # 总记录数
    currentCount: Optional[int] = None  # 当前页记录数
    totalPage: Optional[int] = None  # 总页数


@dataclass_json
@dataclass
class V41MonitorQueryResourceGroupsReturnObjResGroupList:
    regionID: Optional[str] = None  # 资源池ID
    resGroupID: Optional[str] = None  # 资源分组ID
    name: Optional[str] = None  # 名称
    createType: Optional[str] = None  # 本参数表示创建方式。取值范围：<br>instance：实例创建。<br>根据以上范围取值。
    desc: Optional[str] = None  # 描述
    updateTime: Optional[int] = None  # 最近更新时间，时间戳，秒级
    createTime: Optional[int] = None  # 创建时间，时间戳，秒级
    resourceList: Optional[List['V41MonitorQueryResourceGroupsReturnObjResGroupListResourceList']] = None  # 创建方式为实例创建时的资源列表
    projectInfo: Optional['V41MonitorQueryResourceGroupsReturnObjResGroupListProjectInfo'] = None  # 创建方式为企业项目创建时的企业项目信息
    alarmStatus: Optional[int] = None  # 本参数表示状态。取值范围：<br>0：未配置告警规则。<br>1：有告警规则但未告警。<br>2：告警中。<br>根据以上范围取值。
    totalAlarm: Optional[int] = None  # 资源分组的告警资源总数
    totalRule: Optional[int] = None  # 资源分组的规则数
    totalResource: Optional[int] = None  # 资源分组的的资源总数
    totalResourceType: Optional[int] = None  # 资源分组的资源类型数


@dataclass_json
@dataclass
class V41MonitorQueryResourceGroupsReturnObjResGroupListResourceList:
    service: Optional[str] = None  # 云监控服务，具体服务参见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)
    dimension: Optional[str] = None  # 云监控维度，具体维度参见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)
    resourcesTotal: Optional[int] = None  # 某一类型下资源总数
    alarmNum: Optional[int] = None  # 某一类型下告警中的资源总数
    resources: Optional[List['V41MonitorQueryResourceGroupsReturnObjResGroupListResourceListResources']] = None  # 资源信息列表


@dataclass_json
@dataclass
class V41MonitorQueryResourceGroupsReturnObjResGroupListResourceListResources:
    resource: Optional[List['V41MonitorQueryResourceGroupsReturnObjResGroupListResourceListResourcesResource']] = None  # 资源信息
    status: Optional[int] = None  # 本参数表示具体资源是否告警。取值范围：<br>0：正常。<br>1：告警。<br>根据以上范围取值。


@dataclass_json
@dataclass
class V41MonitorQueryResourceGroupsReturnObjResGroupListResourceListResourcesResource:
    name: Optional[str] = None  # 资源实例标签键
    value: Optional[str] = None  # 资源实例标签值，无效值将无法正常产生告警。


@dataclass_json
@dataclass
class V41MonitorQueryResourceGroupsReturnObjResGroupListProjectInfo:
    projectID: Optional[str] = None  # 企业项目ID
    projectProducts: Optional[List['V41MonitorQueryResourceGroupsReturnObjResGroupListProjectInfoProjectProducts']] = None  # 企业项目产品列表


@dataclass_json
@dataclass
class V41MonitorQueryResourceGroupsReturnObjResGroupListProjectInfoProjectProducts:
    service: Optional[str] = None  # 本参数表示服务。取值范围：<br>ecs：云主机。<br>evs：云硬盘。<br>pms：物理机。<br>...<br>详见“[告警规则：获取告警服务列表](https://www.ctyun.cn/document/10032263/10040008)”接口返回。
    dimension: Optional[str] = None  # 本参数表示告警维度。取值范围：<br>ecs：云主机。<br>disk：磁盘。<br>pms：物理机。<br>...<br>详见“[告警规则：获取告警服务维度关系](https://www.ctyun.cn/document/10032263/10040009)”接口返回。
