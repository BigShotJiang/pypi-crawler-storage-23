from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorQueryNoticeTemplateVariableRequest(CtyunOpenAPIRequest):
    group: str  # 本参数表示分组名称。取值范围：<br>basic：基本信息。<br>entity：告警对象。<br>&#32;根据以上范围取值。
    dimension: str  # 告警维度。取值范围：<br>ecs：云主机。<br>disk：磁盘。<br>pms：物理机。<br>...<br>详见"[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)"接口返回。

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorQueryNoticeTemplateVariableResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional[List['V4MonitorQueryNoticeTemplateVariableReturnObj']] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorQueryNoticeTemplateVariableReturnObj:
    name: Optional[str] = None  # lable名称
    description: Optional[str] = None  # lable描述
