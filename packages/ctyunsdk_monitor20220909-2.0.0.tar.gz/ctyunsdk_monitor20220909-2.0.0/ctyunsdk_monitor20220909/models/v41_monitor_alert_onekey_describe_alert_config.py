from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V41MonitorAlertOnekeyDescribeAlertConfigRequest(CtyunOpenAPIRequest):
    regionID: str  # ctyun资源池ID
    service: str  # 本参数表示产品名称。取值范围：<br>ecs：云主机。<br>evs：云硬盘。<br>...<br>详见“[一键告警：产品列表]”接口返回。
    alarmType: str  # 本参数表示告警类型。            取值范围：<br>series：时序指标。<br>event：事件。  <br>根据以上范围取值。
    dimension: Optional[str] = None  # 本参数表示云监控维度。取值范围：<br>ecs：云主机。<br>disk：磁盘。<br>pms：物理机。<br>...<br>详见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V41MonitorAlertOnekeyDescribeAlertConfigResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V41MonitorAlertOnekeyDescribeAlertConfigReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V41MonitorAlertOnekeyDescribeAlertConfigReturnObj:
    alertConfigList: Optional[List['V41MonitorAlertOnekeyDescribeAlertConfigReturnObjAlertConfigList']] = None  # 初始化规则列表


@dataclass_json
@dataclass
class V41MonitorAlertOnekeyDescribeAlertConfigReturnObjAlertConfigList:
    alarmRuleID: Optional[str] = None  # 规则ID
    name: Optional[str] = None  # 规则名称
    service: Optional[str] = None  # 服务。取值范围：<br>ecs：云主机。<br>evs：云硬盘。<br>...<br>详见“[一键告警：产品列表]”接口返回。
    serviceName: Optional[str] = None  # 服务名称
    dimension: Optional[str] = None  # 维度。取值范围：<br>ecs：云主机。<br>disk：磁盘。<br>pms：物理机。<br>...<br>详见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)
    dimensionName: Optional[str] = None  # 维度名称
    repeatTimes: Optional[int] = None  # 重复告警通知次数，默认为0，当repeatTimes值为-1，代表无限重复。
    silenceTime: Optional[int] = None  # 告警接收策略静默时间，多久重复通知一次，单位为秒
    recoverNotify: Optional[int] = None  # 恢复是否通知。值范围：<br>0：否。<br>1：是。
    notifyType: Optional[List[str]] = None  # 告警接收策略。值范围：<br>email：邮件告警。<br>sms：短信告警。
    contactGroupList: Optional[List[str]] = None  # 告警联系人组
    defaultContact: Optional[int] = None  # 是否使用天翼云默认联系人发送通知。默认值：0<br />0：否<br />1：是
    notifyWeekdays: Optional[List[int]] = None  # 通知周期。值范围：<br>0：周日。<br>1：周一。<br>2：周二。<br>3：周三。<br>4：周四。<br>5：周五。<br>6：周六。
    notifyStart: Optional[str] = None  # 通知起始时段
    notifyEnd: Optional[str] = None  # 通知结束时段
    webhookUrl: Optional[List[str]] = None  # 告警状态变更webhook推送地址
    status: Optional[int] = None  # 告警规则启用状态。值范围：<br>0：启用。<br>1：停用。
    createTime: Optional[int] = None  # 创建时间
    updateTime: Optional[int] = None  # 更新时间
    conditions: Optional[List['V41MonitorAlertOnekeyDescribeAlertConfigReturnObjAlertConfigListConditions']] = None  # 规则的触发条件
    noticeStrategyID: Optional[str] = None  # 通知策略ID


@dataclass_json
@dataclass
class V41MonitorAlertOnekeyDescribeAlertConfigReturnObjAlertConfigListConditions:
    evaluationCount: Optional[int] = None  # 连续出现次数
    metric: Optional[str] = None  # 指标名
    operator: Optional[str] = None  # 本参数表示比较符，取值范围：<br>eq：等于。<br>gt：大于。<br>ge：大于等于。<br>lt：小于。<br>le：小于等于。<br>rg：环比上升。<br>cf：环比下降。<br>rc：环比变化。<br>根据以上范围取值。
    value: Optional[str] = None  # 本参数表示告警阈值，可以是整数、小数或百分数格式字符串
    unit: Optional[str] = None  # 单位
    level: Optional[int] = None  # 本参数表示告警等级。取值范围：<br>1：紧急。<br>2：警示。<br>3：普通。<br>根据以上范围取值。
    fun: Optional[str] = None  # 本参数表示告警采用算法。取值范围：<br>last：原始值算法。<br>avg：平均值算法。<br>max：最大值算法。<br>min：最小值算法。<br>sum：求和算法。<br>根据以上范围取值。
    period: Optional[str] = None  # 本参数表示算法统计周期。<br>本参数格式为“数字+单位”。单位取值范围：<br>m：分钟。<br>h：小时。<br>d：天。<br>根据以上范围取值。
    metricName: Optional[str] = None  # 监控项名称
