from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorQueryAlarmTemplatesRequest(CtyunOpenAPIRequest):
    regionID: str  # ctyun资源池ID
    queryContent: Optional[str] = None  # 名称模糊搜索
    services: Optional[List[str]] = None  # 本参数表示展示出来的服务。默认返回所有服务。取值范围：<br>ecs：云主机。<br>evs：云硬盘。<br>pms：物理机。<br>...<br>详见"[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)"接口返回。
    templateType: Optional[str] = None  # 本参数表示模板类型。默认all。取值范围：<br>system：系统默认。<br>custom：自定义。<br>all：所有。<br>根据以上范围取值。
    pageNo: Optional[int] = None  # 页码，默认为1
    page: Optional[int] = None  # 页码，默认为1，建议使用pageNo，该参数后续会下线
    pageSize: Optional[int] = None  # 页大小，默认为10

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorQueryAlarmTemplatesResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorQueryAlarmTemplatesReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorQueryAlarmTemplatesReturnObj:
    templateList: Optional[List['V4MonitorQueryAlarmTemplatesReturnObjTemplateList']] = None  # 告警模板列表
    totalCount: Optional[int] = None  # 总记录数
    templateQuota: Optional[int] = None  # 用户告警模板配额数
    currentCount: Optional[int] = None  # 当前页记录数
    totalPage: Optional[int] = None  # 总页数
    pageNo: Optional[int] = None  # 页码
    pageSize: Optional[int] = None  # 页大小


@dataclass_json
@dataclass
class V4MonitorQueryAlarmTemplatesReturnObjTemplateList:
    templateID: Optional[str] = None  # 告警模板ID
    name: Optional[str] = None  # 告警模板名称
    service: Optional[str] = None  # 服务
    dimension: Optional[str] = None  # 维度
    desc: Optional[str] = None  # 告警模板描述
    conditions: Optional[List['V4MonitorQueryAlarmTemplatesReturnObjTemplateListConditions']] = None  # 告警规则
    createTime: Optional[int] = None  # 创建时间，时间戳，精确到毫秒
    updateTime: Optional[int] = None  # 最近更新时间, 时间戳，精确到毫秒


@dataclass_json
@dataclass
class V4MonitorQueryAlarmTemplatesReturnObjTemplateListConditions:
    evaluationCount: Optional[int] = None  # 持续次数，当规则执行结果持续多久符合条件时报警（防抖）
    metric: Optional[str] = None  # 监控指标
    metricCnName: Optional[str] = None  # 监控指标中文描述
    fun: Optional[str] = None  # 本参数表示告警采用算法。取值范围：<br>last：原始值算法。<br>avg：平均值算法。<br>max：最大值算法。<br>min：最小值算法。<br>sum：求和算法。<br>根据以上范围取值。
    operator: Optional[str] = None  # 本参数表示比较符。取值范围：<br>eq：等于。<br>gt：大于。<br>ge：大于等于。<br>lt：小于。<br>le：小于等于。<br>rg：环比上升。<br>cf：环比下降。<br>rc：环比变化。<br>根据以上范围取值。
    value: Optional[str] = None  # 告警阈值
    period: Optional[str] = None  # 本参数表示算法统计周期。<br>参数fun为last时无效。<br>本参数格式为“数字+单位”。单位取值范围：<br>m：分钟。<br>h：小时。<br>d：天。<br>根据以上范围取值。
    unit: Optional[str] = None  # 单位
    level: Optional[int] = None  # 本参数表示告警等级。取值范围：<br>1：紧急。<br>2：警示。<br>3：普通。<br>根据以上范围取值。
