from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorUpdateNoticeTemplateRequest(CtyunOpenAPIRequest):
    noticeTemplateID: str  # 通知模板ID
    name: str  # 通知模板名称，长度2-40个字符。
    contents: List['V4MonitorUpdateNoticeTemplateRequestContents']  # 通知模板

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorUpdateNoticeTemplateRequestContents:
    content: str  # 通知模板内容，长度不能超过400个字符。
    notifyType: str  # 本参数表示通知方式。取值范围：<br>sms：短信。<br>email：邮件。<br>webhook：告警回调。<br>&#32;根据以上范围取值。


@dataclass_json
@dataclass
class V4MonitorUpdateNoticeTemplateResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorUpdateNoticeTemplateReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorUpdateNoticeTemplateReturnObj:
    success: Optional[bool] = None  # 删除成功标识
