from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorQuerySiteMonitorRequest(CtyunOpenAPIRequest):
    protocol: Optional[str] = None  # 本参数表示探测类型。取值范围：<br>http：http探测。<br>ping：ping探测。<br>tcp：tcp探测。<br>udp：udp探测。<br>pagehttp：浏览器探测。<br>根据以上范围取值。
    taskName: Optional[str] = None  # 站点监控任务名称，支持中英文
    taskID: Optional[str] = None  # 站点监控任务ID
    search: Optional[str] = None  # 对站点地址（address）进行模糊搜索
    pageNo: Optional[int] = None  # 页码，默认为 1
    pageSize: Optional[int] = None  # 页大小，默认为 10
    sort: Optional[str] = None  # 本参数表示排序字段。取值范围：<br>avgAvailability：可用率。<br>avgResponseTime：平均响应时间。<br>根据以上范围取值。
    asc: Optional[int] = None  # 本参数表示排序字段。取值范围：<br>0：倒序。<br>1：正序。<br>根据以上范围取值。

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorQuerySiteMonitorResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorQuerySiteMonitorReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorQuerySiteMonitorReturnObj:
    taskList: Optional[List['V4MonitorQuerySiteMonitorReturnObjTaskList']] = None  # 站点监控任务列表
    totalCount: Optional[int] = None  # 总记录数
    allCount: Optional[int] = None  # 全部记录数，不随筛选信息而改变
    totalPage: Optional[int] = None  # 总页数
    currentCount: Optional[int] = None  # 当前页记录数


@dataclass_json
@dataclass
class V4MonitorQuerySiteMonitorReturnObjTaskList:
    taskID: Optional[str] = None  # 站点监控任务 ID
    taskName: Optional[str] = None  # 站点监控任务名称
    protocol: Optional[str] = None  # 本参数表示探测类型。取值范围：<br>http：http 探测。<br>ping：ping 探测。<br>tcp：tcp 探测。<br>udp：udp 探测。<br>pagehttp：浏览器探测。<br>根据以上范围取值。
    address: Optional[str] = None  # 站点地址
    evalInterval: Optional[int] = None  # 本参数表示探测间隔，单位秒。取值范围：<br>60：60s。<br>300：300s。<br>1200：1200s。<br>1800：1800s。<br>根据以上范围取值。
    probePoint: Optional[List[str]] = None  # 探测节点ID列表
    probeStatus: Optional['V4MonitorQuerySiteMonitorReturnObjTaskListProbeStatus'] = None  # 探测状态信息
    lastChange: Optional[str] = None  # 最近更新时间
    status: Optional[bool] = None  # 状态
    avgAvailability: Optional[str] = None  # 可用率，单位%
    avgResponseTime: Optional[str] = None  # 平均响应时间，单位毫秒


@dataclass_json
@dataclass
class V4MonitorQuerySiteMonitorReturnObjTaskListProbeStatus:
    name: Optional[str] = None  # 任务探测状态
    detail: Optional[object] = None  # 各拨测点探测状态信息
