from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    viewID: str  # 面板ID
    startTime: Optional[int] = None  # 查询起始Unix时间戳,  startTime和endTime成对使用，且时间间隔不超过31天
    endTime: Optional[int] = None  # 查询结束Unix时间戳，  startTime和endTime成对使用，且时间间隔不超过31天
    fun: Optional[str] = None  # 本参数表示聚合类型。默认值为avg。取值范围:<br>raw：原始值。<br>avg：平均值。<br>min：最小值。<br>max：最大值。<br>variance：方差。<br>sum：求和。<br>根据以上范围取值。
    period: Optional[int] = None  # 聚合周期，单位：秒，默认300，需不小于60，推荐使用60的整倍数。当fun为raw时本参数无效。

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorMonitorBoardQueryViewDataReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObj:
    viewID: Optional[str] = None  # 视图ID
    viewType: Optional[str] = None  # 视图类型。取值范围:<br>timeSeries：折线图。<br>gauge：仪表盘。<br>barChart：柱状图。<br>table：表格。<br>pieChart：饼状图。<br>根据以上范围取值。
    monitorType: Optional[str] = None  # 视图属性。取值范围:<br>metric：指标。<br>resource：实例。<br>根据以上范围取值。
    viewData: Optional['V4MonitorMonitorBoardQueryViewDataReturnObjViewData'] = None  # 数据


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewData:
    timeSeriesData: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTimeSeriesData']] = None  # 折线图数据
    barChartData: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataBarChartData']] = None  # 柱状图数据
    gaugeData: Optional['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataGaugeData'] = None  # 仪表盘数据
    pieChartData: Optional['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataPieChartData'] = None  # 饼状图数据
    tableData: Optional['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTableData'] = None  # 表格数据


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTimeSeriesData:
    itemName: Optional[str] = None  # 监控项名称
    itemDesc: Optional[str] = None  # 监控项中文介绍
    itemUnit: Optional[str] = None  # 监控项单位
    compareType: Optional[str] = None  # 本参数表示比较类型。取值范围:<br>1d：环比。<br>7d：同比。<br>0d：原始。<br>根据以上范围取值。
    itemData: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTimeSeriesDataItemData']] = None  # 折线图数据
    dimensions: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTimeSeriesDataDimensions']] = None  # 监控项标签
    resource: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTimeSeriesDataResource']] = None  # 资源


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTimeSeriesDataItemData:
    value: Optional[float] = None  # 监控项值，具体请参考对应监控项文档
    timestamp: Optional[int] = None  # 监控数据Unix时间戳


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTimeSeriesDataDimensions:
    name: Optional[str] = None  # 监控项标签键
    value: Optional[str] = None  # 监控项标签键对应的值


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTimeSeriesDataResource:
    key: Optional[str] = None  # 资源实例标签键
    value: Optional[str] = None  # 资源实例标签值


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataBarChartData:
    itemName: Optional[str] = None  # 监控项名称
    itemDesc: Optional[str] = None  # 监控项中文介绍
    itemUnit: Optional[str] = None  # 监控项单位
    compareType: Optional[str] = None  # 本参数表示比较类型。取值范围:<br>1d：环比。<br>7d：同比。<br>0d：原始。<br>根据以上范围取值。
    itemData: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataBarChartDataItemData']] = None  # 柱状图数据
    dimensions: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataBarChartDataDimensions']] = None  # 监控项标签
    resource: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataBarChartDataResource']] = None  # 资源


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataBarChartDataItemData:
    value: Optional[float] = None  # 监控项值，具体请参考对应监控项文档
    timestamp: Optional[int] = None  # 监控数据Unix时间戳


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataBarChartDataDimensions:
    name: Optional[str] = None  # 监控项标签键
    value: Optional[str] = None  # 监控项标签键对应的值


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataBarChartDataResource:
    key: Optional[str] = None  # 资源实例标签键
    value: Optional[str] = None  # 资源实例标签值


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataGaugeData:
    itemName: Optional[str] = None  # 监控项名称
    itemDesc: Optional[str] = None  # 监控项中文介绍
    itemUnit: Optional[str] = None  # 监控项单位
    rawValue: Optional[str] = None  # 监控项原始值
    compareData: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataGaugeDataCompareData']] = None  # 比较数据
    minValue: Optional[int] = None  # 表盘最小值
    maxValue: Optional[int] = None  # 表盘最大值
    threshold: Optional[List[int]] = None  # 表盘阈值
    resource: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataGaugeDataResource']] = None  # 资源


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataGaugeDataCompareData:
    value: Optional[str] = None  # 监控项值，具体请参考对应监控项文档
    compareType: Optional[str] = None  # 本参数表示比较类型。取值范围:<br>1d：环比。<br>7d：同比。<br>根据以上范围取值。


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataGaugeDataResource:
    key: Optional[str] = None  # 资源实例标签键
    value: Optional[str] = None  # 资源实例标签值


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataPieChartData:
    itemName: Optional[str] = None  # 监控项名称
    itemDesc: Optional[str] = None  # 监控项中文介绍
    itemUnit: Optional[str] = None  # 监控项单位
    itemData: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataPieChartDataItemData']] = None  # 饼图数据


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataPieChartDataItemData:
    rawValue: Optional[float] = None  # 监控项原始值
    compareData: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataPieChartDataItemDataCompareData']] = None  # 比较数据
    resource: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataPieChartDataItemDataResource']] = None  # 资源
    proportion: Optional[str] = None  # 占比


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataPieChartDataItemDataCompareData:
    value: Optional[str] = None  # 监控项值，具体请参考对应监控项文档
    compareType: Optional[str] = None  # 本参数表示比较类型。取值范围:<br>1d：环比。<br>7d：同比。<br>根据以上范围取值。


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataPieChartDataItemDataResource:
    key: Optional[str] = None  # 资源实例标签键
    value: Optional[str] = None  # 资源实例标签值


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTableData:
    tableHead: Optional[List[str]] = None  # 表头
    itemData: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTableDataItemData']] = None  # 表格数据


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTableDataItemData:
    service: Optional[str] = None  # 服务
    dimension: Optional[str] = None  # 维度
    dimensions: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTableDataItemDataDimensions']] = None  # 监控项标签
    timestamp: Optional[int] = None  # 监控数据Unix时间戳
    itemName: Optional[str] = None  # 监控项名称
    itemDesc: Optional[str] = None  # 监控项中文介绍
    itemUnit: Optional[str] = None  # 监控项单位
    rawValue: Optional[float] = None  # 监控项原始值
    compareData: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTableDataItemDataCompareData']] = None  # 比较数据
    resource: Optional[List['V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTableDataItemDataResource']] = None  # 资源


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTableDataItemDataDimensions:
    name: Optional[str] = None  # 监控项标签键
    value: Optional[str] = None  # 监控项标签键对应的值


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTableDataItemDataCompareData:
    value: Optional[str] = None  # 监控项值，具体请参考对应监控项文档
    compareType: Optional[str] = None  # 本参数表示比较类型。取值范围:<br>1d：环比。<br>7d：同比。<br>根据以上范围取值。


@dataclass_json
@dataclass
class V4MonitorMonitorBoardQueryViewDataReturnObjViewDataTableDataItemDataResource:
    key: Optional[str] = None  # 资源实例标签键
    value: Optional[str] = None  # 资源实例标签值
