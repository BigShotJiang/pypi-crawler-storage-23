from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V42MonitorQueryHistoryMetricDataRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    service: str  # 云监控服务，具体服务参见[云监控：查询服务维度及监控项](https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=22&api=15746&data=90&isNormal=1&vid=84)
    dimension: str  # 云监控维度，具体维度参见[云监控：查询服务维度及监控项](https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=22&api=15746&data=90&isNormal=1&vid=84)
    itemNameList: List[str]  # 待查监控项名称，单次请求长度限制为10，具体设备对应监控项参见[云监控：查询服务维度及监控项](https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=22&api=15746&data=90&isNormal=1&vid=84)
    startTime: int  # 查询起始Unix时间戳，秒级
    endTime: int  # 查询结束Unix时间戳，秒级
    fun: str  # 本参数表示聚合类型。默认值为avg。取值范围:<br>raw：原始值。<br>avg：平均值。<br>min：最小值。<br>max：最大值。<br>sum：求和。<br>根据以上范围取值。
    dimensions: List['V42MonitorQueryHistoryMetricDataRequestDimensions']  # 查询设备标签列表，用于定位要查询监控数据的目标设备，多标签查询取交集，单次请求设备数量限制为10
    period: Optional[int] = None  # 聚合周期，单位：秒，默认300，需不小于60，推荐使用60的整倍数。当fun为raw时本参数无效。

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V42MonitorQueryHistoryMetricDataRequestDimensions:
    name: str  # 设备标签键，取值范围参考[云监控：查询服务维度及监控项](https://eop.ctyun.cn/ebp/ctapiDocument/search?sid=22&api=15746&data=90&isNormal=1&vid=84)响应的dimensions字段。<br>以云主机为例，该字段为uuid。
    value: List[str]  # 设备标签键所对应的值，最大数量限制为10。<br>以云主机为例，该字段为云主机的instanceID。


@dataclass_json
@dataclass
class V42MonitorQueryHistoryMetricDataResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V42MonitorQueryHistoryMetricDataReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V42MonitorQueryHistoryMetricDataReturnObj:
    itemList: Optional[List['V42MonitorQueryHistoryMetricDataReturnObjItemList']] = None  # 监控项列表


@dataclass_json
@dataclass
class V42MonitorQueryHistoryMetricDataReturnObjItemList:
    itemName: Optional[str] = None  # 监控项名称
    itemDesc: Optional[str] = None  # 监控项中文介绍
    itemUnit: Optional[str] = None  # 监控项单位
    itemData: Optional[List['V42MonitorQueryHistoryMetricDataReturnObjItemListItemData']] = None  # 监控项内容
    dimensions: Optional[List['V42MonitorQueryHistoryMetricDataReturnObjItemListDimensions']] = None  # 监控项标签
    unitRelations: Optional[List['V42MonitorQueryHistoryMetricDataReturnObjItemListUnitRelations']] = None  # 单位转换字典


@dataclass_json
@dataclass
class V42MonitorQueryHistoryMetricDataReturnObjItemListItemData:
    value: Optional[float] = None  # 监控项值，具体请参考对应监控项文档
    timestamp: Optional[int] = None  # 监控数据Unix时间戳


@dataclass_json
@dataclass
class V42MonitorQueryHistoryMetricDataReturnObjItemListDimensions:
    name: Optional[str] = None  # 监控项标签键
    value: Optional[str] = None  # 监控项标签键对应的值


@dataclass_json
@dataclass
class V42MonitorQueryHistoryMetricDataReturnObjItemListUnitRelations:
    unit: Optional[str] = None  # 单位
    weight: Optional[float] = None  # 权重
