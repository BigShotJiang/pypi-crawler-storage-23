from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorQueryNoticeTemplatesRequest(CtyunOpenAPIRequest):
    service: Optional[str] = None  # 本参数表示服务。取值范围：<br>ecs：云主机。<br>evs：云硬盘。<br>pms：物理机。<br>...<br>详见"[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)"接口返回。
    dimension: Optional[str] = None  # 本参数表示告警维度。取值范围：<br>ecs：云主机。<br>disk：磁盘。<br>pms：物理机。<br>...<br>详见"[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)"接口返回。
    name: Optional[str] = None  # 名称模糊搜索
    pageNo: Optional[int] = None  # 页码，默认为1
    pageSize: Optional[int] = None  # 页大小，默认为10

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorQueryNoticeTemplatesResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorQueryNoticeTemplatesReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorQueryNoticeTemplatesReturnObj:
    noticeTemplateList: Optional[List['V4MonitorQueryNoticeTemplatesReturnObjNoticeTemplateList']] = None  # 通知模板
    totalCount: Optional[int] = None  # 总记录数
    currentCount: Optional[int] = None  # 当前页记录数
    totalPage: Optional[int] = None  # 总页数
    pageNo: Optional[int] = None  # 页码
    pageSize: Optional[int] = None  # 页大小


@dataclass_json
@dataclass
class V4MonitorQueryNoticeTemplatesReturnObjNoticeTemplateList:
    noticeTemplateID: Optional[str] = None  # 通知模板ID
    name: Optional[str] = None  # 通知模板名称
    service: Optional[str] = None  # 服务
    dimension: Optional[str] = None  # 维度
    contents: Optional[List['V4MonitorQueryNoticeTemplatesReturnObjNoticeTemplateListContents']] = None  # 通知模板
    isDefault: Optional[bool] = None  # 是否为自定义默认通知模板
    createTime: Optional[int] = None  # 创建时间，时间戳，精确到秒
    updateTime: Optional[int] = None  # 最近更新时间，时间戳，精确到秒


@dataclass_json
@dataclass
class V4MonitorQueryNoticeTemplatesReturnObjNoticeTemplateListContents:
    content: Optional[str] = None  # 通知模板内容
    notifyType: Optional[str] = None  # 本参数表示通知方式。取值范围：<br>sms：短信。<br>email：邮件。<br>webhook：告警回调。<br>根据以上范围取值。
