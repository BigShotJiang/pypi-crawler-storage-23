from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V4MonitorAlertOnekeyDisableServiceRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    service: str  # 本参数表示产品名称。取值范围：<br>ecs：云主机。<br>evs：云硬盘。<br>...<br>详见“[一键告警：产品列表]”接口返回。
    alarmType: str  # 本参数表示告警类型。            取值范围：<br>series：时序指标。<br>event：事件。  <br>根据以上范围取值。
    dimension: Optional[str] = None  # 本参数表示云监控维度。取值范围：<br>ecs：云主机。<br>disk：磁盘。<br>pms：物理机。<br>...<br>详见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorAlertOnekeyDisableServiceResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V4MonitorAlertOnekeyDisableServiceReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V4MonitorAlertOnekeyDisableServiceReturnObj:
    success: Optional[bool] = None  # 是否成功
