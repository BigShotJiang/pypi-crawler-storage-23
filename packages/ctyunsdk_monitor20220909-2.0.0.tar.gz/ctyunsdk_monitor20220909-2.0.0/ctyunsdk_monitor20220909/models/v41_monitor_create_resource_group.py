from typing import Optional, List, Dict

from ctyun_python_sdk_core.ctyun_openapi_request import CtyunOpenAPIRequest
from ctyun_python_sdk_core.ctyun_openapi_response import CtyunOpenAPIResponse
from dataclasses_json import dataclass_json
from dataclasses import dataclass


@dataclass_json
@dataclass
class V41MonitorCreateResourceGroupRequest(CtyunOpenAPIRequest):
    regionID: str  # 资源池ID
    name: str  # 资源分组名称，长度2-40个字符。
    desc: Optional[str] = None  # 资源分组描述，长度不超过100个字符，默认值为空字符。
    createType: Optional[str] = None  # 本参数表示创建方式，默认值：instance。取值范围：<br>instance：实例创建。<br>project：企业项目创建。<br>根据以上范围取值。
    resourceList: Optional[List['V41MonitorCreateResourceGroupRequestResourceList']] = None  # 创建方式为实例创建时的资源列表，创建方式（createType）为instance时，resourceList为必填参数，资源列表中的元素resourceListObj的个数不超过20个。
    projectInfo: Optional['V41MonitorCreateResourceGroupRequestProjectInfo'] = None  # 创建方式为企业项目创建时的企业项目信息， 创建方式（createType）为project时，projectInfo为必填参数。

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V41MonitorCreateResourceGroupRequestResourceList:
    service: str  # 云监控服务，具体服务参见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)
    dimension: str  # 云监控维度，具体维度参见[云监控：查询服务维度及监控项](https://www.ctyun.cn/document/10032263/10747790)
    resources: List['V41MonitorCreateResourceGroupRequestResourceListResources']  # 资源信息列表


@dataclass_json
@dataclass
class V41MonitorCreateResourceGroupRequestResourceListResources:
    resource: List['V41MonitorCreateResourceGroupRequestResourceListResourcesResource']  # 资源信息


@dataclass_json
@dataclass
class V41MonitorCreateResourceGroupRequestResourceListResourcesResource:
    name: str  # 资源实例标签键
    value: str  # 资源实例标签值，无效值将无法正常产生告警。


@dataclass_json
@dataclass
class V41MonitorCreateResourceGroupRequestProjectInfo:
    projectID: str  # 企业项目ID
    projectProducts: List['V41MonitorCreateResourceGroupRequestProjectInfoProjectProducts']  # 企业项目产品列表


@dataclass_json
@dataclass
class V41MonitorCreateResourceGroupRequestProjectInfoProjectProducts:
    service: str  # 本参数表示服务。取值范围：<br>ecs：云主机。<br>evs：云硬盘。<br>pms：物理机。<br>...<br>详见“[告警规则：获取告警服务列表](https://www.ctyun.cn/document/10032263/10040008)”接口返回。
    dimension: str  # 本参数表示告警维度。取值范围：<br>ecs：云主机。<br>disk：磁盘。<br>pms：物理机。<br>...<br>详见“[告警规则：获取告警服务维度关系](https://www.ctyun.cn/document/10032263/10040009)”接口返回。


@dataclass_json
@dataclass
class V41MonitorCreateResourceGroupResponse(CtyunOpenAPIResponse):
    statusCode: Optional[int] = None  # 返回状态码（800为成功，900为失败）
    errorCode: Optional[str] = None  # 错误码，为product.module.code三段式码
    error: Optional[str] = None  # 错误码，为product.module.code三段式码
    message: Optional[str] = None  # 失败时的错误描述，一般为英文描述
    description: Optional[str] = None  # 失败时的错误描述，一般为中文描述
    returnObj: Optional['V41MonitorCreateResourceGroupReturnObj'] = None  # 成功时返回的数据

    def __post_init__(self):
        super().__init__()


@dataclass_json
@dataclass
class V41MonitorCreateResourceGroupReturnObj:
    resGroupID: Optional[str] = None  # 资源分组ID
