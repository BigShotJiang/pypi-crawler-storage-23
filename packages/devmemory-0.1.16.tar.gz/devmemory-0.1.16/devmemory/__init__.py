__version__ = "0.1.16"
__app_name__ = "devmemory"
