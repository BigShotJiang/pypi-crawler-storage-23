# SPDX-License-Identifier: Apache-2.0
"""
MOON Python package core. Defines parsing and representing pipelines.
"""
