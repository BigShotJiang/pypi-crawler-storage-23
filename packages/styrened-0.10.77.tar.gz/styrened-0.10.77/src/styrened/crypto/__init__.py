from styrened.crypto.pqc_crypto import pqc_available
