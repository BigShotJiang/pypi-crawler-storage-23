"""Cross-platform test scenarios that run on SSH or K8s backends."""
