"""memctl MCP server — optional, requires mcp[cli]."""
