"""pypublish - A CLI tool for publishing Python packages to PyPI."""

from pypublish.__main__ import main

__all__ = ['main']
