"""
playwright-healer — Production-grade self-healing locator engine for Playwright Python.

Advantages over competitors:
  ✓ 3-tier healing: heuristic (free) → DOM fuzzy (free) → AI (paid)
  ✓ Provider fallback chain — if Groq fails, try OpenAI, then Gemini
  ✓ ARIA-first healed selectors (get_by_role/text instead of brittle CSS)
  ✓ HealingPage wrapper — zero boilerplate, just wrap your page
  ✓ Shadow DOM & iframe auto-penetration
  ✓ Confidence-ranked candidates from AI
  ✓ Adaptive cache TTL based on selector stability history
  ✓ Native pytest-playwright plugin — zero conftest required
  ✓ Rich coloured console output with healing details
  ✓ Full type hints throughout
"""

from playwright_healer.config import HealerConfig, AIProviderConfig, CacheConfig, HealingStrategy
from playwright_healer.healer import HealingPage
from playwright_healer.locator import HealingLocator
from playwright_healer.auto_config import auto_config

__all__ = [
    "HealingPage",
    "HealingLocator",
    "HealerConfig",
    "AIProviderConfig",
    "CacheConfig",
    "HealingStrategy",
    "auto_config",
]

__version__ = "1.0.0"
