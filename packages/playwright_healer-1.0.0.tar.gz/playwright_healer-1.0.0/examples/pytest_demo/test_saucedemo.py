"""
pytest fixture example — playwright-healer.

No conftest.py required!  The pytest plugin auto-registers via the
entry point and provides the `healing_page` fixture automatically.

Run with:
  export GROQ_API_KEY=gsk_...
  pytest examples/pytest_demo/ -v

Or pass strategy via CLI:
  pytest examples/pytest_demo/ --ph-strategy DOM_ONLY -v
"""

import pytest


@pytest.mark.asyncio
async def test_login_with_working_selectors(healing_page):
    """Standard test — working selectors, no healing needed."""
    await healing_page.goto("https://www.saucedemo.com")
    await healing_page.fill("#user-name", "Username field", value="standard_user")
    await healing_page.fill("#password", "Password field", value="secret_sauce")
    await healing_page.click("#login-button", "Login button")
    await healing_page.wait_for_url("**/inventory.html")
    assert "inventory" in healing_page.url


@pytest.mark.asyncio
async def test_login_with_broken_selectors(healing_page):
    """
    Selectors are intentionally broken — playwright-healer heals them.
    This test should STILL PASS because the healer finds the right elements.
    """
    await healing_page.goto("https://www.saucedemo.com")
    await healing_page.fill("#user-name-BROKEN", "Username input on saucedemo login page", value="standard_user")
    await healing_page.fill("#password-BROKEN", "Password input on saucedemo login page", value="secret_sauce")
    await healing_page.click("#login-button-BROKEN", "Login submit button on saucedemo", )
    await healing_page.wait_for_url("**/inventory.html")
    assert "inventory" in healing_page.url


@pytest.mark.asyncio
async def test_element_presence_check(healing_page):
    """is_present() returns False without raising on missing element."""
    await healing_page.goto("https://www.saucedemo.com")
    assert not await healing_page.is_present("#ghost-element", "Ghost element")


@pytest.mark.asyncio
async def test_get_page_title(healing_page):
    """Navigation methods are forwarded transparently."""
    await healing_page.goto("https://www.saucedemo.com")
    title = await healing_page.title()
    assert "Swag Labs" in title


@pytest.mark.asyncio
async def test_count_multiple_elements(healing_page):
    """count() finds all matching elements after login."""
    await healing_page.goto("https://www.saucedemo.com")
    await healing_page.fill("#user-name", "Username", value="standard_user")
    await healing_page.fill("#password", "Password", value="secret_sauce")
    await healing_page.click("#login-button", "Login button")
    await healing_page.wait_for_url("**/inventory.html")

    count = await healing_page.count(".inventory_item", "Inventory items")
    assert count == 6, f"Expected 6 items, got {count}"


@pytest.mark.asyncio
async def test_get_text_content(healing_page):
    """get_text() returns visible text of an element."""
    await healing_page.goto("https://www.saucedemo.com")
    # The login button has value="Login" but we can get its text content
    assert await healing_page.is_present("#login-button", "Login button")
