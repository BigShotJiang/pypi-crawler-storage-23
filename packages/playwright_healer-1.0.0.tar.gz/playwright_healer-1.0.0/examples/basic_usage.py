"""
playwright-healer — Basic usage example.

Shows the three common usage patterns:
  1. HealingPage context manager (recommended)
  2. Direct HealingPage instance
  3. Manual HealingLocator

Run with:
  export GROQ_API_KEY=gsk_...
  python examples/basic_usage.py
"""

import asyncio
from dotenv import load_dotenv

load_dotenv()

from playwright.async_api import async_playwright
from playwright_healer import HealingPage, auto_config


async def pattern_1_context_manager():
    """
    Pattern 1: HealingPage as async context manager.
    Reports are generated automatically on exit.
    """
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()

        config = auto_config()

        async with HealingPage(page, config, test_name="example_1") as hp:
            await hp.goto("https://www.saucedemo.com")

            # These selectors work fine on saucedemo
            await hp.fill("#user-name", "Username field", value="standard_user")
            await hp.fill("#password", "Password field", value="secret_sauce")
            await hp.click("#login-button", "Login button")

            await hp.wait_for_url("**/inventory.html")
            print(f"✓ Logged in successfully. URL: {hp.url}")

            # Now try BROKEN selectors — playwright-healer will heal them
            # (simulating what happens when a dev renames IDs)
            await hp.goto("https://www.saucedemo.com")
            await hp.fill("#user-name-BROKEN", "Username field", value="standard_user")
            await hp.fill("#password-BROKEN", "Password field", value="secret_sauce")
            await hp.click("#login-button-BROKEN", "Login button")

            await hp.wait_for_url("**/inventory.html")
            print(f"✓ Healed and logged in! URL: {hp.url}")

            # Session report is printed and HTML/JSON saved when context exits

        await browser.close()


async def pattern_2_healing_locator():
    """
    Pattern 2: Use HealingLocator for chainable element interaction.
    """
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()

        config = auto_config()
        hp = HealingPage(page, config, test_name="example_2")

        await hp.goto("https://www.saucedemo.com")

        # HealingLocator — lazy, heals on first interaction
        username = hp.locator("#user-name-BROKEN", "Username input on login page")
        password = hp.locator("#password-BROKEN", "Password input on login page")
        login_btn = hp.locator("#login-button-BROKEN", "Login button on login page")

        await username.fill("standard_user")
        await password.fill("secret_sauce")
        await login_btn.click()

        await hp.wait_for_url("**/inventory.html")
        print(f"✓ Pattern 2 success. URL: {hp.url}")

        await hp.shutdown()
        await browser.close()


async def pattern_3_pytest_plugin():
    """
    Pattern 3 is the pytest plugin — see examples/pytest_demo/ directory.
    No conftest.py required.

    Just install playwright-healer and pytest-playwright, then use:
      async def test_login(healing_page):
          await healing_page.goto("https://example.com")
          await healing_page.click("#submit", "Submit button")
    """
    print("✓ See examples/pytest_demo/ for the pytest fixtures example")


async def main():
    print("\n=== playwright-healer basic usage ===\n")
    await pattern_1_context_manager()
    await pattern_2_healing_locator()
    await pattern_3_pytest_plugin()
    print("\n✓ All patterns complete")


if __name__ == "__main__":
    asyncio.run(main())
