"""
Unit tests for the heuristic healer.
"""

import pytest
from playwright_healer.heuristic import HeuristicHealer

SAMPLE_HTML = """
<!DOCTYPE html>
<html>
<body>
  <form id="login-form">
    <input id="username-field" name="username" type="text" placeholder="Enter username" aria-label="Username">
    <input id="password-field" name="password" type="password" placeholder="Enter password" aria-label="Password">
    <button id="login-button" type="submit" class="btn btn-primary">Login</button>
    <a href="/forgot" class="forgot-link" aria-label="Forgot Password">Forgot Password</a>
  </form>
</body>
</html>
"""


class TestHeuristicHealer:
    def setup_method(self):
        self.healer = HeuristicHealer()

    def test_id_suffix_mutation_finds_renamed_id(self):
        # #login-btn → #login-button (common rename pattern)
        candidates = self.healer.heal("#login-btn", "Login button", SAMPLE_HTML)
        selectors = [c.selector for c in candidates]
        assert any("login-button" in s for s in selectors), \
            f"Expected login-button in candidates, got: {selectors}"

    def test_text_match_finds_button(self):
        candidates = self.healer.heal("#nonexistent", "Login button", SAMPLE_HTML)
        text_candidates = [c for c in candidates if c.selector_type == "text"]
        assert text_candidates, f"Expected text candidates, got: {candidates}"
        assert any("Login" in c.selector for c in text_candidates)

    def test_placeholder_match_finds_input(self):
        candidates = self.healer.heal("#broken-username", "Enter username input", SAMPLE_HTML)
        ph_candidates = [c for c in candidates if c.selector_type == "placeholder"]
        assert ph_candidates, f"Expected placeholder candidates, got: {candidates}"

    def test_aria_match_finds_by_label(self):
        candidates = self.healer.heal("#broken", "Password field", SAMPLE_HTML)
        role_candidates = [c for c in candidates if c.selector_type == "role"]
        assert role_candidates, f"Expected role candidates for aria-label match"

    def test_class_similarity(self):
        # .btn matches elements with class set {btn, btn-primary} — Jaccard = 1/2 = 0.5
        # Use a selector that shares at least 50% of classes with the button
        candidates = self.healer.heal(".btn.btn-primary", "Primary button", SAMPLE_HTML)
        css_candidates = [c for c in candidates if c.selector_type == "css"]
        assert css_candidates, f"Expected CSS class candidates, got: {candidates}"

    def test_no_false_positives_on_empty_html(self):
        candidates = self.healer.heal("#submit", "Submit", "<html><body></body></html>")
        assert isinstance(candidates, list)

    def test_confidence_order(self):
        candidates = self.healer.heal("#login-btn", "Login", SAMPLE_HTML)
        confidences = [c.confidence for c in candidates]
        assert confidences == sorted(confidences, reverse=True), \
            "Candidates should be sorted by confidence descending"

    def test_deduplication(self):
        candidates = self.healer.heal("#login-btn", "Login button", SAMPLE_HTML)
        selectors = [c.selector for c in candidates]
        assert len(selectors) == len(set(selectors)), "Duplicate selectors in results"
