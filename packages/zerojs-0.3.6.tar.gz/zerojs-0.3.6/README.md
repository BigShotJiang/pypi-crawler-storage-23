<div align="center">

[![ZeroJS logo](https://cdn.zerojs.dev/brand/logo/zerojs-logo.png)](https://github.com/kennylajara/zerojs)

---


<!-- Compatibility -->
[![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-blue?logo=hackthebox&logoColor=white)](https://github.com/kennylajara/zerojs)
[![Python](https://img.shields.io/pypi/pyversions/zerojs.svg?logo=python&logoColor=white)](https://pypi.org/project/zerojs/)
[![PyPI](https://img.shields.io/pypi/v/zerojs?logo=pypi&logoColor=white&color=blue)](https://pypi.org/project/zerojs/)
[![Wheel](https://img.shields.io/pypi/wheel/zerojs?logo=pypi&logoColor=white&color=blue)](https://pypi.org/project/zerojs/)
<!-- Code Quality — badges hosted on S3, updated by CI via self-hosted SonarQube -->
<!-- ?ref= is auto-managed: stripped on main (Worker defaults), set to ?ref=develop on develop -->
[![Quality Gate](https://cdn.zerojs.dev/badges/sonar/alert_status.svg?ref=develop)](https://github.com/kennylajara/zerojs)
[![Reliability](https://cdn.zerojs.dev/badges/sonar/reliability_rating.svg?ref=develop)](https://github.com/kennylajara/zerojs)
[![Security](https://cdn.zerojs.dev/badges/sonar/security_rating.svg?ref=develop)](https://github.com/kennylajara/zerojs)
[![Maintainability](https://cdn.zerojs.dev/badges/sonar/sqale_rating.svg?ref=develop)](https://github.com/kennylajara/zerojs)
[![Tests](https://cdn.zerojs.dev/badges/sonar/tests.svg?ref=develop)](https://github.com/kennylajara/zerojs)
[![Coverage](https://cdn.zerojs.dev/badges/sonar/coverage.svg?ref=develop)](https://github.com/kennylajara/zerojs)

</div>

---

# ZeroJS

**Modern frontend capabilities for Python developers — no JavaScript required.**

ZeroJS is a FastAPI-based framework that brings file-based routing, Jinja2 templating, and seamless HTMX integration to Python. Build interactive, modern web applications using only Python and HTML.

## Table of contents

* [Why ZeroJS?](#why-zerojs)
* [Technical snapshot](#technical-snapshot)
* [Features](#features)
* [Installation](#installation)
* [Quick start](#quick-start)
* [Usage patterns](#usage-patterns)
* [API reference](#api-reference)
* [Security](#security)
* [Contributing](#contributing)
* [Roadmap](#roadmap)
* [Support](#support)
* [License](#license)
* [Changelog](#changelog)
* [FAQ](#faq)
* [Acknowledgements](#acknowledgements)

---

## Why ZeroJS?

Building modern, interactive web apps usually means juggling two ecosystems: Python for the backend, JavaScript for the frontend. ZeroJS eliminates that split. You get file-based routing, reactive UI updates, and form handling—all in Python and HTML. No build steps, no node_modules, no context switching.

---

## Technical Snapshot

- **Built on top of FastAPI** — One of the fastest Python web frameworks
- **Zero build step** — No webpack, no bundlers, just Python and HTML
- **Middleware system** — Django-style, plug what you need (sessions, CORS, rate limiting...)
- **Production-ready** — ASGI-native, works with Uvicorn, Gunicorn, Docker-friendly

---

## Features

**Routing & Structure**

- [File-based routing](docs/guide/00_README_BACKUP.md) — Pages map directly to URLs; no manual route registration.
- [Dynamic routes](docs/guide/00_README_BACKUP.md) — `[param]` syntax for URL parameters; clean, intuitive URLs.
- [Jinja2 templating](docs/guide/00_README_BACKUP.md) — Full template inheritance; reuse layouts across pages.
- [Static files](docs/guide/00_README_BACKUP.md) — Built-in serving of CSS, JS, images, and other assets.

**Interactivity**

- [Form handling](docs/guide/00_README_BACKUP.md) — Automatic validation with Pydantic; less boilerplate.
- [HTMX integration](docs/guide/00_README_BACKUP.md) — Partial page updates without writing JavaScript.
- [SPA-like navigation](docs/guide/00_README_BACKUP.md) — `hx-boost` enabled; smoother transitions, no full reloads.

**Security**

- [Authentication](docs/guide/00_README_BACKUP.md) — Built-in session-based auth; secure by default.
- [Authorization](docs/guide/00_README_BACKUP.md) — Role and permission checks; protect routes declaratively.
- [Middleware system](docs/guide/00_README_BACKUP.md) — Sessions, CORS, rate limiting, security headers built-in.

**Developer Experience**

- [Hot reload](docs/guide/00_README_BACKUP.md) — Automatic refresh on file changes; faster dev cycles.
- [Custom error pages](docs/guide/00_README_BACKUP.md) — Configurable 404 and 500 pages.

**Advanced**

- [PyScript support](docs/guide/00_README_BACKUP.md) — Run Python in the browser with MicroPython/Pyodide.
- [Shadow Components](docs/guide/00_README_BACKUP.md) — Style-encapsulated components; no CSS leaks.

---

## Installation

**Requirements:** Python 3.10+ · Windows, macOS, or Linux

```bash
pip install zerojs
```

Optional extras:

| Extra          | Command                    | Includes                   |
|----------------|----------------------------|----------------------------|
| Development    | `pip install zerojs[dev]`  | Hot reload for HTML/CSS/JS |
| Authentication | `pip install zerojs[auth]` | Session auth, JWT          |
| All            | `pip install zerojs[all]`  | Everything                 |

---

## Quick start

**1. Create project structure:**

```
my-app/
├── pages/
│   └── index.html
├── components/
│   └── base.html
└── main.py
```

**2. Create base template** (`components/base.html`):

```html
{% extends 'zerojs/base.html' %}
{% block title %}My Awesome App{% endblock %}
```

**3. Create a page** (`pages/index.html`):

```html
{% extends 'base.html' %}
{% block content %}
<h1>Hello, ZeroJS!</h1>
{% endblock %}
```

**4. Run it** (`main.py`):

```python
from lajara_ai.zerojs_app import ZeroJS
app = ZeroJS()
app.start(reload=True)
```

```bash
python main.py
```

Visit `http://localhost:3000` — done!

→ [Full tutorial](docs/guide/00_README_BACKUP.md)

---

## Usage patterns

**Dynamic route with parameter:**

```python
# pages/users/_id.py
def get(id: int) -> dict:
    return {"user": get_user_by_id(id)}
```
```html
<!-- pages/users/[id].html -->
<h1>{{ user.name }}</h1>
```
Access `/users/123` → `id = 123`

**Form with validation and auto-generated HTML:**

```python
# pages/_contact.py
from pydantic import BaseModel, EmailStr

class ContactForm(BaseModel):
    email: EmailStr
    message: str

def get() -> dict:
    return {"ContactForm": ContactForm}

def post(data: ContactForm) -> dict:
    send_email(data)
    return {"ContactForm": ContactForm, "success": True}
```
```html
<!-- pages/contact.html -->
{{ render_form(ContactForm, values, errors, submit_text="Send") }}
```

**Live search with HTMX:**

```html
<!-- pages/search.html -->
<input type="search"
       hx-get="/components/search-results"
       hx-trigger="keyup changed delay:300ms"
       hx-target="#results"
       placeholder="Search users...">
<div id="results"></div>
```
```python
# components/_search-results.py
def get(q: str = "") -> dict:
    return {"users": search_users(q)}
```
```html
<!-- components/search-results.html -->
{% for user in users %}
<div>{{ user.name }}</div>
{% endfor %}
```

**Client-side Python with PyScript:**

```html
<!-- pages/counter.html -->
<button id="btn-increment">+1</button>
<span id="count">0</span>

<script type="mpy" src="/static/py/counter.py"></script>
```
```python
# static/py/counter.py
from pyscript import document, when

@when("click", "#btn-increment")
def increment(event):
    el = document.querySelector("#count")
    el.innerText = str(int(el.innerText) + 1)
```

→ [More patterns](docs/guide/00_README_BACKUP.md)

---

## API reference

Documentation lives in [`docs/guide/`](docs/guide/00_README_BACKUP.md).

**Modules:**
- `lajara_ai.zerojs_app` — Main app class and utilities
- `lajara_ai.auth` — Authentication helpers
- `lajara_ai.middleware` — Built-in middleware
- `lajara_ai.routes` — Routing utilities
- `lajara_ai.security` — Security utilities
- `lajara_ai.session` — Session storage backends

<!--

---

## Examples & Recipes

**Starter apps:**
- [Todo App](examples/todo) — CRUD with authentication
- [Blog](examples/blog) — Markdown posts, dynamic routing
- [Admin Dashboard](examples/dashboard) — Charts, real-time updates
- [E-commerce](examples/ecommerce) — Cart, checkout, payments

**Deployment:**
- [Docker](docs/deployment/docker.md)
- [Docker Compose + PostgreSQL](docs/deployment/docker-compose.md)
- [Gunicorn + Nginx](docs/deployment/gunicorn-nginx.md)
- [Railway / Render / Fly.io](docs/deployment/paas.md)

**Integrations:**
- [SQLAlchemy](docs/integrations/sqlalchemy.md) — ORM setup
- [PostgreSQL / MySQL / SQLite](docs/integrations/databases.md)
- [Redis](docs/integrations/redis.md) — Cache and sessions
- [Celery](docs/integrations/celery.md) — Background tasks
- [S3 / MinIO](docs/integrations/s3.md) — File storage

→ [All examples](examples/)

-->

---

## Security

**Reporting vulnerabilities:**

Please report security issues to **security@zerojs.dev** — do not open public issues for vulnerabilities.

**What to include:**
- Description of the vulnerability
- Steps to reproduce
- Potential impact

**Estimated response time:**
- Acknowledgment: 48 hours
- Initial assessment: 7 days
- Fix or mitigation: depends on severity and technical complexity

**Built-in protections:**
- CSRF protection enabled by default
- Signed session cookies
- Path traversal protection on route params
- Security headers middleware (CSP, HSTS, etc.)

→ [Security policy](SECURITY.md)

---

## Migration guide

We are in Alpha version. During this period, no migration guide will be provided. That will change in the future as the
framework matures.

<!--

**Version upgrades:**

- [v0.x → v1.0](docs/migrations/v0-to-v1.md)
- Breaking changes documented in [CHANGELOG.md](CHANGELOG.md)
- Deprecation warnings one minor version before removal

**Migrating from other frameworks:**

- [From Flask](docs/migrations/from-flask.md)
- [From Django](docs/migrations/from-django.md)
- [From FastAPI + Jinja2](docs/migrations/from-fastapi.md)

→ [All migration guides](docs/migrations/)
-->

---

## Contributing

We welcome contributions! Here's how to get started:

1. Fork the repo and create a branch from `develop`
2. Make your changes
3. Run tests: `uv run pytest`
4. Follow code style: `uv run ruff check . && uv run ruff format .`
5. Open a PR against `develop`

**Branch strategy:**
- `main` — stable releases
- `develop` — next release
- `feature/*` — new features
- `fix/*` — bug fixes

→ [Contributing guide](CONTRIBUTING.md) &bull; [Code of Conduct](CODE_OF_CONDUCT.md)

---

## Roadmap

![Roadmap timeline](https://cdn.zerojs.dev/common/roadmap.svg)

- **2026** — Public validation (alpha → beta → RC)
- **Apr 2027** — v1.0 LTS (first stable release with 36-month support)
- **2027+** — Six-month release cadence with overlapping LTS lines

→ [Full roadmap](ROADMAP.md) with timeline details, version labels, and support windows

---

## Support

**Community support:**
- [GitHub Issues](https://github.com/kennylajara/zerojs/issues) — Bug reports and feature requests
- [GitHub Discussions](https://github.com/kennylajara/zerojs/discussions) — Questions and ideas

Commercial support and SLAs will be available after v1.0 LTS (April 2027).

---

## Licensing

See the [LICENSE](LICENSE) file for licensing information as it pertains to
files in this repository.

---

## Changelog

See [GitHub Releases](https://github.com/kennylajara/zerojs/releases) for version history.

A detailed `CHANGELOG.md` following [Keep a Changelog](https://keepachangelog.com/) will be added before v1.0.

---

## FAQ

<details>
<summary><strong>1. Can I use ZeroJS in production apps?</strong></summary>

Well... ZeroJS is not officially production-ready. We're in alpha stage and v1.0 LTS (April 2027) will be the first 
production-recommended release. That said, ZeroJS is a superset of FastAPI, which is production-ready.
</details>
<br>
<details>
<summary><strong>2. What if I need JavaScript for something?</strong></summary>

No problem. ZeroJS serves static files, so you can add any JS library. HTMX and PyScript cover most use cases, but 
vanilla JS or external scripts work fine when needed.
</details>
<br>
<details>
<summary><strong>3. Why avoid JavaScript?</strong></summary>

You don't have to — ZeroJS works alongside JS if needed. But if your team is Python-first, you can build rich UIs 
without context-switching, build tools, or npm. One language, one runtime, less complexity.
</details>
<br>
<details>
<summary><strong>4. What if I just add HTMX and PyScript to Flask/Django/FastAPI myself?</strong></summary>

You can! ZeroJS saves you the setup: file-based routing, automatic partial rendering for HTMX, form generation and data
validation from Pydantic models, and PyScript integration work out of the box. It's the boilerplate you'd write anyway, already done.
</details>

---

## Acknowledgements

Built on the shoulders of giants:

- [FastAPI](https://fastapi.tiangolo.com/) — The foundation
- [Pydantic](https://docs.pydantic.dev/) — Data validation and form generation
- [HTMX](https://htmx.org/) — HTML-driven interactivity
- [PyScript](https://pyscript.net/) — Python in the browser
- [Jinja2](https://jinja.palletsprojects.com/) — Templating engine
