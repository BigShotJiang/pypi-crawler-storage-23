"""HTTP types for ZeroJS.

Re-exports Starlette HTTP types for consistent imports across the codebase.
This provides a single import point and allows for future customization.

Example:
    from lajara_ai.http import Request, Response, JSONResponse

    async def handler(request: Request) -> Response:
        return JSONResponse({"status": "ok"})
"""

from starlette.datastructures import FormData, MutableHeaders
from starlette.requests import HTTPConnection, Request
from starlette.responses import JSONResponse, Response

__all__ = [
    "FormData",
    "HTTPConnection",
    "JSONResponse",
    "MutableHeaders",
    "Request",
    "Response",
]
