"""Entry-point based plugin discovery for ZeroJS."""

from collections.abc import Callable
from typing import Any


def _discover_component(group: str, name: str) -> Callable[..., Any] | None:
    """Discover a component via Python entry points.

    Looks up the given entry-point *group* for an entry whose name matches
    *name*.  This allows third-party packages to provide components
    without any coupling to the core package.

    Args:
        group: Entry-point group (e.g., "lajara_ai.storage_backends").
        name: Entry-point name to look up (e.g., "redis").

    Returns:
        The loaded callable if an entry point is found, None otherwise.
    """
    from importlib.metadata import entry_points

    eps = entry_points(group=group)
    for ep in eps:
        if ep.name == name:
            return ep.load()  # type: ignore[no-any-return]
    return None
