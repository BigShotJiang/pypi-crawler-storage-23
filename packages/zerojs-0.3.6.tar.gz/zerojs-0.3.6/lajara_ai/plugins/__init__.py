"""Entry-point based plugin discovery for ZeroJS."""

from .core import _discover_component

__all__ = ["_discover_component"]
