"""Decorators for ZeroJS route handlers."""

from .core import rate_limit

__all__ = ["rate_limit"]
