"""Context building utilities for template rendering."""

from .core import build_error_context, build_page_context

__all__ = ["build_error_context", "build_page_context"]
