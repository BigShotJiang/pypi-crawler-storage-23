"""Type annotations for ZeroJS."""

from .core import UnsafePath, UnsafeStr

__all__ = ["UnsafePath", "UnsafeStr"]
