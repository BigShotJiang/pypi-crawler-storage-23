"""Session storage protocol and factory."""

from collections.abc import Callable
from typing import Protocol
from urllib.parse import ParseResult, urlparse

from .data import SessionData

# Type alias for storage backend factory functions.
# A factory receives the parsed URI and returns a SessionStoreProtocol instance.
StorageFactory = Callable[[ParseResult], "SessionStoreProtocol"]


class SessionStoreProtocol(Protocol):
    """Protocol defining session storage interface.

    All methods are synchronous. Async backends should use
    connection pooling with synchronous wrapper calls.
    """

    def get(self, session_id: str) -> SessionData | None:
        """Retrieve session data by ID.

        Args:
            session_id: The unique session identifier.

        Returns:
            SessionData if found and not expired, None otherwise.
        """
        ...

    def set(self, session_id: str, data: SessionData, ttl: int) -> None:
        """Store session data.

        Args:
            session_id: The unique session identifier.
            data: The session data to store.
            ttl: Time-to-live in seconds.
        """
        ...

    def delete(self, session_id: str) -> None:
        """Delete session data.

        Args:
            session_id: The unique session identifier.
        """
        ...

    def exists(self, session_id: str) -> bool:
        """Check if session exists and is not expired.

        Args:
            session_id: The unique session identifier.

        Returns:
            True if session exists and is valid, False otherwise.
        """
        ...

    def touch(self, session_id: str, ttl: int) -> bool:
        """Update session accessed_at timestamp (sliding expiration).

        Args:
            session_id: The unique session identifier.
            ttl: New TTL in seconds (for backends with native expiration).

        Returns:
            True if session was touched, False if not found.
        """
        ...

    def clear(self) -> None:
        """Clear all sessions. Use with caution."""
        ...

    def increment(self, key: str, amount: int = 1, ttl: int = 0) -> int:
        """Atomically increment a counter.

        Used for rate limiting and other atomic counter operations.
        Creates the counter with value `amount` if it doesn't exist.

        Args:
            key: The counter key (not a session ID).
            amount: Amount to increment by (default: 1).
            ttl: Time-to-live in seconds. 0 = no expiration.

        Returns:
            The new counter value after incrementing.
        """
        ...

    def get_counter(self, key: str) -> int:
        """Get current counter value.

        For counters created with increment(). For session data, use get().

        Args:
            key: The counter key.

        Returns:
            Current counter value, or 0 if counter doesn't exist.
        """
        ...


def _memory_factory(parsed: ParseResult) -> SessionStoreProtocol:  # noqa: ARG001
    """Create a MemorySessionStore from a parsed URI.

    ``parsed`` is unused — memory needs no configuration — but required
    by the ``StorageFactory`` interface so all backends share the same
    calling convention.
    """
    from .backends.memory import MemorySessionStore

    return MemorySessionStore()


# Module-level registry mapping URI schemes to factory functions.
_registry: dict[str, StorageFactory] = {
    "memory": _memory_factory,
}


def register_storage_backend(scheme: str, factory: StorageFactory) -> None:
    """Register a session storage backend for a URI scheme.

    Args:
        scheme: URI scheme (e.g., "redis", "memcached").
        factory: Callable that receives a ParseResult and returns a SessionStoreProtocol.

    Raises:
        ValueError: If scheme is already registered.
    """
    if scheme in _registry:
        raise ValueError(f"Storage backend already registered for scheme: {scheme}")
    _registry[scheme] = factory


def storage_from_uri(uri: str) -> SessionStoreProtocol:
    """Create a session store from a URI string.

    Uses the backend registry to find the appropriate factory
    for the URI scheme.  When the scheme is not explicitly registered,
    falls back to entry-point discovery (group ``lajara_ai.storage_backends``).

    Args:
        uri: Storage URI in format "scheme://..."
            - "memory://" - In-memory storage (default)
            - Additional schemes registered via register_storage_backend()
            - Entry-point backends discovered automatically

    Returns:
        SessionStoreProtocol implementation.

    Raises:
        ValueError: If URI scheme is not supported.
    """
    parsed = urlparse(uri)
    scheme = parsed.scheme

    factory = _registry.get(scheme)
    if factory is None:
        from lajara_ai.plugins import _discover_component

        factory = _discover_component("lajara_ai.storage_backends", scheme)
        if factory is not None:
            _registry[scheme] = factory

    if factory is not None:
        return factory(parsed)

    raise ValueError(f"Unsupported session storage scheme: {scheme}")
