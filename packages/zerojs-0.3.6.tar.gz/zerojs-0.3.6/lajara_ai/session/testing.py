"""Testing utilities for session storage.

Provides mock implementations of session protocols for testing.
"""

from typing import Any

from .storage import SessionStoreProtocol


class MockSessionStore:
    """In-memory session store for testing.

    Provides all SessionStoreProtocol methods including counter operations.
    TTL is tracked but not enforced (items don't expire automatically).

    Example:
        store = MockSessionStore()
        store.set("session:123", {"user_id": 1}, ttl=3600)
        data = store.get("session:123")
        assert data["user_id"] == 1
    """

    def __init__(
        self,
        data: dict[str, Any] | None = None,
        counters: dict[str, int] | None = None,
        ttls: dict[str, int] | None = None,
    ) -> None:
        """Initialize the mock store.

        Args:
            data: Optional pre-populated session data.
            counters: Optional pre-populated counters.
            ttls: Optional pre-populated TTLs.
        """
        self._data: dict[str, Any] = data.copy() if data else {}
        self._counters: dict[str, int] = counters.copy() if counters else {}
        self._ttls: dict[str, int] = ttls.copy() if ttls else {}

    def get(self, key: str) -> Any | None:
        """Get data by key.

        Args:
            key: The key to retrieve.

        Returns:
            Stored data or None if not found.
        """
        return self._data.get(key)

    def set(self, key: str, data: Any, ttl: int) -> None:
        """Store data with TTL.

        Args:
            key: The key to store under.
            data: The data to store.
            ttl: Time-to-live in seconds (tracked but not enforced).
        """
        self._data[key] = data
        self._ttls[key] = ttl

    def delete(self, key: str) -> None:
        """Delete data by key.

        Args:
            key: The key to delete.
        """
        self._data.pop(key, None)
        self._counters.pop(key, None)
        self._ttls.pop(key, None)

    def exists(self, key: str) -> bool:
        """Check if key exists.

        Args:
            key: The key to check.

        Returns:
            True if key exists, False otherwise.
        """
        return key in self._data or key in self._counters

    def touch(self, key: str, ttl: int) -> bool:
        """Update TTL for a key.

        Args:
            key: The key to update.
            ttl: New TTL in seconds.

        Returns:
            True if key exists, False otherwise.
        """
        if key in self._data:
            self._ttls[key] = ttl
            # Call touch() on data if available (SessionData compatibility)
            if hasattr(self._data[key], "touch"):
                self._data[key].touch()
            return True
        return False

    def clear(self) -> None:
        """Clear all data."""
        self._data.clear()
        self._counters.clear()
        self._ttls.clear()

    def increment(self, key: str, amount: int = 1, ttl: int = 0) -> int:
        """Atomically increment a counter.

        Args:
            key: The counter key.
            amount: Amount to increment by.
            ttl: Optional TTL in seconds.

        Returns:
            New counter value after increment.
        """
        self._counters[key] = self._counters.get(key, 0) + amount
        if ttl > 0:
            self._ttls[key] = ttl
        return self._counters[key]

    def get_counter(self, key: str) -> int:
        """Get counter value.

        Args:
            key: The counter key.

        Returns:
            Counter value or 0 if not found.
        """
        return self._counters.get(key, 0)

    def get_ttl(self, key: str) -> int | None:
        """Get TTL value for a key.

        Args:
            key: The key to get TTL for.

        Returns:
            TTL value or None if not found.
        """
        return self._ttls.get(key)


# Type assertion to verify MockSessionStore implements SessionStoreProtocol
def _assert_protocol_compliance() -> None:
    """Static type assertion to verify MockSessionStore implements SessionStoreProtocol.

    This function is NEVER called at runtime. It exists solely for mypy
    static analysis. The assignment verifies that MockSessionStore correctly
    implements the SessionStoreProtocol protocol.

    If mypy passes, MockSessionStore correctly implements SessionStoreProtocol.
    """
    _session_store: SessionStoreProtocol = MockSessionStore()


def reset_storage_registry() -> None:
    """Reset the storage backend registry to default state (memory only).

    Use in test teardown to ensure backend registration doesn't leak between tests.
    """
    from .storage import _memory_factory, _registry

    _registry.clear()
    _registry["memory"] = _memory_factory


__all__ = ["MockSessionStore", "reset_storage_registry"]
