"""Cache strategy and backend registry with entry-point discovery."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from .backends.memory import MemoryBackend
from .strategies.none import NoneStrategy
from .strategies.ttl import TTLStrategy

# Module-level registries
_strategy_registry: dict[str, Callable[..., Any]] = {
    "none": NoneStrategy,
    "ttl": TTLStrategy,
}

_backend_registry: dict[str, Callable[..., Any]] = {
    "memory": MemoryBackend,
}


def register_strategy(name: str, cls: Callable[..., Any]) -> None:
    """Register a cache strategy.

    Args:
        name: Strategy name (e.g., "custom").
        cls: Strategy class.

    Raises:
        ValueError: If name is already registered.
    """
    if name in _strategy_registry:
        raise ValueError(f"Cache strategy already registered: {name}")
    _strategy_registry[name] = cls


def register_backend(name: str, cls: Callable[..., Any]) -> None:
    """Register a cache backend.

    Args:
        name: Backend name (e.g., "redis").
        cls: Backend class.

    Raises:
        ValueError: If name is already registered.
    """
    if name in _backend_registry:
        raise ValueError(f"Cache backend already registered: {name}")
    _backend_registry[name] = cls


def resolve_strategy(name: str) -> Any:
    """Resolve a strategy by name, falling back to entry-point discovery.

    Args:
        name: Strategy name.

    Returns:
        Strategy instance.

    Raises:
        ValueError: If strategy is unknown.
    """
    cls = _strategy_registry.get(name)
    if cls is None:
        from lajara_ai.plugins import _discover_component

        cls = _discover_component("lajara_ai.cache_strategies", name)
        if cls is not None:
            _strategy_registry[name] = cls

    if cls is None:
        raise ValueError(f"Unknown cache strategy: {name}")

    return cls()


def resolve_backend(name: str) -> Any:
    """Resolve a backend by name, falling back to entry-point discovery.

    Args:
        name: Backend name.

    Returns:
        Backend instance.

    Raises:
        ValueError: If backend is unknown.
    """
    cls = _backend_registry.get(name)
    if cls is None:
        from lajara_ai.plugins import _discover_component

        cls = _discover_component("lajara_ai.cache_backends", name)
        if cls is not None:
            _backend_registry[name] = cls

    if cls is None:
        raise ValueError(f"Unknown cache backend: {name}")

    return cls()
