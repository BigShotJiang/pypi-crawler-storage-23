"""Testing utilities for the cache module.

Provides mock implementations for cache protocols.
"""

from .decision import CacheDecision
from .entry import CacheEntry
from .protocols import CacheBackendProtocol, CacheStrategyProtocol


class MockCacheBackend:
    """In-memory mock cache backend for testing."""

    def __init__(self) -> None:
        """Initialize with empty storage."""
        self.data: dict[str, CacheEntry] = {}

    def get(self, key: str) -> CacheEntry | None:
        """Retrieve a cache entry by key."""
        return self.data.get(key)

    def set(self, key: str, entry: CacheEntry) -> None:
        """Store a cache entry."""
        self.data[key] = entry

    def delete(self, key: str) -> None:
        """Delete a cache entry."""
        self.data.pop(key, None)

    def clear(self) -> None:
        """Clear all cache entries."""
        self.data.clear()


class MockCacheStrategy:
    """Mock cache strategy for testing.

    Always returns a configurable decision.
    """

    def __init__(self, decision: CacheDecision | None = None) -> None:
        """Initialize with a fixed decision.

        Args:
            decision: The decision to always return.
                Defaults to cache miss with cache_on_miss=True.
        """
        self.decision = decision or CacheDecision(html=None)

    def evaluate(self, entry: CacheEntry | None, ttl: int) -> CacheDecision:
        """Return the configured decision."""
        return self.decision


def reset_cache_registry() -> None:
    """Reset the cache registries to default state.

    Use in test teardown to ensure registry changes don't leak between tests.
    """
    from .backends.memory import MemoryBackend
    from .registry import _backend_registry, _strategy_registry
    from .strategies.none import NoneStrategy
    from .strategies.ttl import TTLStrategy

    _strategy_registry.clear()
    _strategy_registry["none"] = NoneStrategy
    _strategy_registry["ttl"] = TTLStrategy

    _backend_registry.clear()
    _backend_registry["memory"] = MemoryBackend


def _assert_protocol_compliance() -> None:
    """Static type assertion to verify mocks implement their protocols.

    This function is NEVER called at runtime. It exists solely for mypy
    static analysis.
    """
    _backend: CacheBackendProtocol = MockCacheBackend()
    _strategy: CacheStrategyProtocol = MockCacheStrategy()
