"""Cache manager — mediates between strategies, backends, and HTTP responses."""

from __future__ import annotations

import os
import time
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from fastapi import Request
from fastapi.responses import HTMLResponse

from .config import CacheConfig
from .entry import CacheEntry
from .protocols import CacheBackendProtocol, CacheStrategyProtocol

if TYPE_CHECKING:
    from lajara_ai.settings.model import Settings


class CacheManager:
    """Mediator that coordinates cache strategies and backends.

    The manager is the single integration point between cache logic
    (strategies, backends) and the web framework (HTMLResponse).
    Strategies remain pure; the manager handles HTTP concerns.
    """

    def __init__(
        self,
        backend: CacheBackendProtocol,
        strategies: dict[str, CacheStrategyProtocol],
    ) -> None:
        """Initialize the cache manager.

        Args:
            backend: The cache storage backend.
            strategies: Map of strategy name to strategy instance.
        """
        self._backend = backend
        self._strategies = strategies

    @classmethod
    def from_settings(cls, settings: Settings) -> CacheManager:
        """Create a CacheManager from application settings.

        Resolves backend and strategies from the registry. If a
        ``lajara_ai.cache_manager`` entry-point is installed, uses that class.

        Args:
            settings: Application settings.

        Returns:
            CacheManager (or subclass) instance.

        Raises:
            ValueError: If an unknown strategy is referenced in settings,
                or if multiple cache_manager entry-points are found.
        """
        from .registry import resolve_backend, resolve_strategy

        # Resolve the manager class via entry-point
        manager_cls = cls
        from importlib.metadata import entry_points

        eps = list(entry_points(group="lajara_ai.cache_manager"))
        if len(eps) == 1:
            manager_cls = eps[0].load()
        elif len(eps) > 1:
            names = [ep.name for ep in eps]
            raise ValueError(f"Multiple cache manager entry-points found: {names}")

        # Resolve backend
        backend = resolve_backend(settings.CACHE_BACKEND)

        # Collect all unique strategy names from settings
        strategy_names: set[str] = set()

        strategy_names.add(settings.CACHE_STRATEGY)

        cache_routes = settings.CACHE_ROUTES
        for route_config in cache_routes.values():
            strategy_names.add(route_config.get("strategy", "none"))

        # Resolve all strategies (errors at startup if unknown)
        strategies: dict[str, CacheStrategyProtocol] = {}
        for name in strategy_names:
            strategies[name] = resolve_strategy(name)

        return manager_cls(backend=backend, strategies=strategies)

    def process(
        self,
        key: str,
        config: CacheConfig,
        render_func: Callable[..., str],
        path_params: dict[str, Any],
        request: Request,
    ) -> HTMLResponse:
        """Process a cache request.

        Checks cache, renders if needed, stores result.

        Args:
            key: Cache key (URL path).
            config: Cache configuration for this route.
            render_func: Function to render HTML on cache miss.
            path_params: Path parameters for render_func.
            request: The HTTP request.

        Returns:
            HTMLResponse with cached or freshly rendered content.
        """
        response, _ = self._process_internal(key, config, render_func, path_params, request)
        return response

    def _process_internal(
        self,
        key: str,
        config: CacheConfig,
        render_func: Callable[..., str],
        path_params: dict[str, Any],
        request: Request,
    ) -> tuple[HTMLResponse, CacheEntry | None]:
        """Internal processing that returns both response and entry.

        Subclasses can use the returned entry for additional processing.

        Args:
            key: Cache key.
            config: Cache configuration.
            render_func: Render function for cache miss.
            path_params: Path parameters.
            request: HTTP request.

        Returns:
            Tuple of (HTMLResponse, CacheEntry or None).
        """
        # Dev mode: skip cache entirely
        if os.environ.get("ZEROJS_DEV_MODE"):
            html = render_func(path_params, request)
            return HTMLResponse(content=html), None

        # Look up strategy
        strategy = self._strategies.get(config.strategy)
        if strategy is None:
            # Fallback: render without caching
            html = render_func(path_params, request)
            return HTMLResponse(content=html), None

        # Pre-fetch entry from backend
        entry = self._backend.get(key)

        # Evaluate strategy
        decision = strategy.evaluate(entry, config.ttl)

        # Cache hit
        if decision.html is not None:
            return HTMLResponse(content=decision.html), entry

        # Cache miss: render fresh
        html = render_func(path_params, request)

        if decision.cache_on_miss:
            new_entry = CacheEntry(html=html, cached_at=time.time())
            self._backend.set(key, new_entry)

        return HTMLResponse(content=html), None

    def store(self, key: str, html: str) -> None:
        """Store rendered HTML in the cache backend.

        Args:
            key: Cache key.
            html: Rendered HTML content.
        """
        entry = CacheEntry(html=html, cached_at=time.time())
        self._backend.set(key, entry)

    def invalidate(self, key: str) -> None:
        """Remove a specific entry from cache.

        Args:
            key: Cache key to invalidate.
        """
        self._backend.delete(key)

    def clear(self) -> None:
        """Clear all cached entries."""
        self._backend.clear()
