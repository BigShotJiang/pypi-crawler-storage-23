"""In-memory cache backend."""

from ..entry import CacheEntry


class MemoryBackend:
    """In-memory cache backend using a Python dict."""

    def __init__(self) -> None:
        """Initialize with empty storage."""
        self._cache: dict[str, CacheEntry] = {}

    def get(self, key: str) -> CacheEntry | None:
        """Retrieve a cache entry by key.

        Args:
            key: The cache key.

        Returns:
            CacheEntry if found, None otherwise.
        """
        return self._cache.get(key)

    def set(self, key: str, entry: CacheEntry) -> None:
        """Store a cache entry.

        Args:
            key: The cache key.
            entry: The cache entry to store.
        """
        self._cache[key] = entry

    def delete(self, key: str) -> None:
        """Delete a cache entry.

        Args:
            key: The cache key to delete.
        """
        self._cache.pop(key, None)

    def clear(self) -> None:
        """Clear all cache entries."""
        self._cache.clear()
