"""TTL-based cache strategy."""

import time

from ..decision import CacheDecision
from ..entry import CacheEntry


class TTLStrategy:
    """Strategy with hard expiration after TTL seconds.

    If the entry is fresh (age < ttl), serves cached content.
    If the entry is expired (age >= ttl), returns cache miss.
    """

    def evaluate(self, entry: CacheEntry | None, ttl: int) -> CacheDecision:
        """Evaluate entry freshness against TTL.

        Args:
            entry: The cache entry (None if cache miss).
            ttl: TTL in seconds.

        Returns:
            CacheDecision with cached html if fresh, None if expired or miss.
        """
        if entry is None:
            return CacheDecision(html=None)

        age = time.time() - entry.cached_at
        if age >= ttl:
            return CacheDecision(html=None)

        return CacheDecision(html=entry.html)
