"""No-cache strategy."""

from ..decision import CacheDecision
from ..entry import CacheEntry


class NoneStrategy:
    """Strategy that disables caching entirely.

    Always returns a cache miss decision with cache_on_miss=False,
    so the manager never stores rendered content.
    """

    def evaluate(self, entry: CacheEntry | None, ttl: int) -> CacheDecision:
        """Always return cache miss, never cache.

        Args:
            entry: Ignored.
            ttl: Ignored.

        Returns:
            CacheDecision with html=None and cache_on_miss=False.
        """
        return CacheDecision(html=None, cache_on_miss=False)
