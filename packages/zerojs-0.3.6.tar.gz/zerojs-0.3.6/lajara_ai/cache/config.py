"""Cache configuration."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from lajara_ai.settings.model import Settings


@dataclass
class CacheConfig:
    """Configuration for a cached route."""

    strategy: str
    ttl: int  # Seconds

    @classmethod
    def from_dict(cls, data: dict) -> CacheConfig:
        """Create CacheConfig from a dictionary."""
        strategy = data.get("strategy", "none")
        ttl = data.get("ttl", 0)
        return cls(strategy=strategy, ttl=ttl)

    @classmethod
    def none(cls) -> CacheConfig:
        """Create a no-cache config."""
        return cls(strategy="none", ttl=0)


def get_cache_config(settings: Settings, url_path: str) -> CacheConfig:
    """Get cache configuration for a specific URL path.

    Args:
        settings: Application settings.
        url_path: The URL path (e.g., "/users/1")

    Returns:
        CacheConfig for this route
    """
    cache_routes = settings.CACHE_ROUTES

    # Check for exact route match
    if url_path in cache_routes:
        route_config = cache_routes[url_path]
        return CacheConfig.from_dict(route_config)

    # Use global defaults
    strategy = settings.CACHE_STRATEGY
    ttl = settings.CACHE_TTL

    # If strategy is none or ttl is 0, return no-cache config
    if strategy == "none" or (strategy != "none" and ttl <= 0):
        return CacheConfig.none()

    return CacheConfig(strategy=strategy, ttl=ttl)
