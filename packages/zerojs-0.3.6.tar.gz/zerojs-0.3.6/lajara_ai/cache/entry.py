"""Cache entry data type."""

from dataclasses import dataclass


@dataclass
class CacheEntry:
    """A cached HTML response with timestamp."""

    html: str
    cached_at: float
