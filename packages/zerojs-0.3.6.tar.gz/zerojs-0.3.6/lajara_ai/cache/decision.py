"""Cache decision data type."""

from dataclasses import dataclass


@dataclass
class CacheDecision:
    """Result of a cache strategy evaluation.

    Attributes:
        html: Cached HTML if cache hit, None if cache miss.
        cache_on_miss: Whether the manager should store the result
            after rendering on cache miss. Default True.
            Only NoneStrategy sets this to False.
    """

    html: str | None
    cache_on_miss: bool = True
