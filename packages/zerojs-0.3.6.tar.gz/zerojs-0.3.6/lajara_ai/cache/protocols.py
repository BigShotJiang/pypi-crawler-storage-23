"""Cache protocol definitions.

Defines the interfaces for cache backends and cache strategies,
allowing applications to type-hint against abstractions rather
than concrete implementations.
"""

from __future__ import annotations

from typing import Protocol

from .decision import CacheDecision
from .entry import CacheEntry


class CacheBackendProtocol(Protocol):
    """Protocol defining cache storage interface.

    Backends are responsible for pure key-value storage of cache entries.
    They do not make any decisions about caching strategy.
    """

    def get(self, key: str) -> CacheEntry | None:
        """Retrieve a cache entry by key.

        Args:
            key: The cache key (usually the URL path).

        Returns:
            CacheEntry if found, None otherwise.
        """
        ...

    def set(self, key: str, entry: CacheEntry) -> None:
        """Store a cache entry.

        Args:
            key: The cache key.
            entry: The cache entry to store.
        """
        ...

    def delete(self, key: str) -> None:
        """Delete a cache entry.

        Args:
            key: The cache key to delete.
        """
        ...

    def clear(self) -> None:
        """Clear all cache entries."""
        ...


class CacheStrategyProtocol(Protocol):
    """Protocol defining cache strategy interface.

    Strategies evaluate cache entries and make decisions about whether
    to serve cached content or require fresh rendering. They receive
    pure data and return pure decisions — no HTTP or framework coupling.
    """

    def evaluate(self, entry: CacheEntry | None, ttl: int) -> CacheDecision:
        """Evaluate a cache entry and decide what to do.

        Args:
            entry: The cache entry (None if cache miss).
            ttl: The TTL in seconds for this route.

        Returns:
            CacheDecision with html and cache_on_miss fields.
        """
        ...
