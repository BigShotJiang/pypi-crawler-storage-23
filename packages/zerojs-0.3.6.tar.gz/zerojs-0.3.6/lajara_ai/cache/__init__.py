"""HTML response cache with pluggable strategies and backends."""

from .config import CacheConfig, get_cache_config
from .decision import CacheDecision
from .entry import CacheEntry
from .manager import CacheManager
from .protocols import CacheBackendProtocol, CacheStrategyProtocol
from .registry import register_backend, register_strategy

__all__ = [
    "CacheBackendProtocol",
    "CacheConfig",
    "get_cache_config",
    "CacheDecision",
    "CacheEntry",
    "CacheManager",
    "CacheStrategyProtocol",
    "register_backend",
    "register_strategy",
]
