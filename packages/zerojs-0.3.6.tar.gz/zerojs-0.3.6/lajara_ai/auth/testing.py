"""Testing utilities for the auth module.

Provides mock implementations and helpers for testing code
that uses the authentication system.

Example:
    from lajara_ai.auth.testing import mock_user, MockUser, MockUserProvider

    # Test protected endpoint
    def test_protected_endpoint(client):
        user = MockUser(id=1, email="test@example.com")
        with mock_user(user):
            response = client.get("/dashboard")
            assert response.status_code == 200

    # Test with permissions
    def test_delete_requires_permission(client):
        user = MockUser(id=1, email="test@example.com")
        with mock_user(user, permissions={"users.delete"}):
            response = client.delete("/users/123")
            assert response.status_code == 200
"""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from datetime import datetime
from typing import Any, Generic, TypeVar

from lajara_ai.events import EventEmitterProtocol, EventListener
from lajara_ai.events.testing import MockEventEmitter, MockEventListener
from lajara_ai.security.testing import SecretGenerator

from .context import AuthContext
from .permissions.backend import _permission_backend
from .permissions.testing import MockPermissionBackend
from .protocols import (
    CredentialVerifier,
    MFAProvider,
    RawSessionProtocol,
    TokenProvider,
    UserProvider,
)
from .user import BaseUser

T = TypeVar("T")

_default_secrets = SecretGenerator(prefix="mock")


class MockUser(BaseUser):
    """Mock user for testing that implements the full BaseUser contract.

    Provides a complete BaseUser implementation with additional fields
    for testing RBAC, MFA, and tracking login/logout calls.

    Attributes:
        id: User ID.
        email: User email address (also used as identifier).
        name: User display name.
        password_hash: Hashed password (auto-generated via SecretGenerator).
        is_active: Whether the user account is active.
        roles: Set of role names for RBAC testing.
        permissions: Set of direct permissions for testing.
        is_admin: Whether user has admin privileges.
        mfa_enabled: Whether MFA is enabled for this user.
        login_count: Number of times login() was called.
        logout_count: Number of times logout() was called.

    Example:
        user = MockUser(id=1, email="admin@example.com", roles={"admin"})
        assert user.is_active
        assert "admin" in user.roles

        # Use with mock_user for permission testing
        with mock_user(user, permissions={"users.delete"}):
            # @requires_permission("users.delete") will pass
            ...
    """

    def __init__(
        self,
        id: Any = 1,  # noqa: A002
        email: str = "test@example.com",
        name: str = "Test User",
        password_hash: str = _default_secrets.password(),
        is_active: bool = True,
        roles: set[str] | None = None,
        permissions: set[str] | None = None,
        is_admin: bool = False,
        mfa_enabled: bool = False,
    ) -> None:
        """Initialize a mock user.

        Args:
            id: User identifier.
            email: User email address.
            name: User display name.
            password_hash: Hashed password.
            is_active: Whether account is active.
            roles: Set of role names for RBAC.
            permissions: Set of permission strings.
            is_admin: Whether user has admin privileges.
            mfa_enabled: Whether MFA is enabled.
        """
        self._id = id
        self.email = email
        self.name = name
        self._password_hash = password_hash
        self._is_active = is_active
        self.roles = roles if roles is not None else set()
        self.permissions = permissions if permissions is not None else set()
        self.is_admin = is_admin
        self.mfa_enabled = mfa_enabled
        self._last_login: datetime | None = None
        self.login_count: int = 0
        self.logout_count: int = 0

    # --- BaseUser implementations ---

    @property
    def id(self) -> Any:
        """Unique identifier for this user."""
        return self._id

    def get_identifier(self) -> str:
        """Return email as the login identifier."""
        return self.email

    @property
    def password_hash(self) -> str:
        """The hashed password."""
        return self._password_hash

    def set_password_hash(self, hashed: str) -> None:
        """Set the password hash."""
        self._password_hash = hashed

    @property
    def is_active(self) -> bool:
        """Whether this account can log in."""
        return self._is_active

    @property
    def last_login(self) -> datetime | None:
        """Last login timestamp."""
        return self._last_login

    def _set_last_login(self, dt: datetime) -> None:
        """Update last login timestamp."""
        self._last_login = dt

    async def login(self) -> None:
        """Called after successful authentication.

        Sets last_login and increments login_count for test verification.
        """
        self._set_last_login(datetime.now())
        self.login_count += 1

    async def logout(self) -> None:
        """Called on logout.

        Increments logout_count for test verification.
        """
        self.logout_count += 1

    def __repr__(self) -> str:
        """Return string representation."""
        return f"MockUser(id={self._id!r}, email={self.email!r})"


class MockUserProvider(Generic[T]):
    """In-memory user provider for testing.

    Stores users in memory and provides lookup by ID or identifier.

    Example:
        users = [
            MockUser(id=1, email="user@test.com"),
            MockUser(id=2, email="admin@test.com", roles=["admin"]),
        ]
        provider = MockUserProvider(users)

        user = await provider.get_by_identifier("user@test.com")
        assert user.id == 1

        admin = await provider.get_by_id(2)
        assert "admin" in admin.roles
    """

    def __init__(self, users: list[T] | None = None):
        """Initialize the mock provider.

        Args:
            users: List of user objects to store.
        """
        self._by_id: dict[Any, T] = {}
        self._by_identifier: dict[str, T] = {}

        for user in users or []:
            self.add_user(user)

    def add_user(self, user: T) -> None:
        """Add a user to the provider.

        Args:
            user: User object to add.
        """
        user_id = getattr(user, "id", None)
        if user_id is not None:
            self._by_id[user_id] = user

        # Index by common identifier fields
        for field_name in ("email", "username", "phone"):
            if identifier := getattr(user, field_name, None):
                self._by_identifier[identifier.lower()] = user

    def remove_user(self, user_id: Any) -> None:
        """Remove a user from the provider.

        Args:
            user_id: ID of the user to remove.
        """
        user = self._by_id.pop(user_id, None)
        if user:
            for field_name in ("email", "username", "phone"):
                if identifier := getattr(user, field_name, None):
                    self._by_identifier.pop(identifier.lower(), None)

    async def get_by_identifier(self, identifier: str) -> T | None:
        """Find user by email, username, or phone.

        Args:
            identifier: The identifier to search for.

        Returns:
            User if found, None otherwise.
        """
        return self._by_identifier.get(identifier.lower())

    async def get_by_id(self, user_id: Any) -> T | None:
        """Find user by ID.

        Args:
            user_id: The user ID to search for.

        Returns:
            User if found, None otherwise.
        """
        return self._by_id.get(user_id)

    async def is_active(self, user: T) -> bool:
        """Check if user account is active.

        Args:
            user: The user to check.

        Returns:
            True if user is active, False otherwise.
        """
        return getattr(user, "is_active", True)


class MockCredentialVerifier:
    """Simple credential verifier for testing.

    Verifies credentials against a predefined password or
    a dictionary of user-specific passwords.

    Example:
        # Auto-generated password by default
        verifier = MockCredentialVerifier()

        # Or specify valid password
        verifier = MockCredentialVerifier(valid_password=SecretGenerator().password())

        # Or use a dict of user_id -> password
        verifier = MockCredentialVerifier(passwords={1: "pass1", 2: "pass2"})
    """

    def __init__(
        self,
        valid_password: str = _default_secrets.password(),
        passwords: dict[Any, str] | None = None,
    ):
        """Initialize the mock verifier.

        Args:
            valid_password: Default password for all users.
            passwords: Optional dict mapping user IDs to passwords.
        """
        self._valid_password = valid_password
        self._passwords = passwords or {}
        self.dummy_verify_called = False

    async def verify(self, user: Any, credential: str) -> bool:
        """Verify credential against user.

        Args:
            user: The user to verify against.
            credential: The credential (password) to verify.

        Returns:
            True if credential is valid, False otherwise.
        """
        user_id = getattr(user, "id", None)
        if user_id in self._passwords:
            return credential == self._passwords[user_id]
        return credential == self._valid_password

    def dummy_verify(self) -> None:
        """Perform dummy verification for timing attack prevention.

        Call this when a user is not found to prevent timing attacks
        that reveal whether an account exists.
        """
        self.dummy_verify_called = True


class MockTokenProvider:
    """Simple token provider for testing.

    Generates sequential tokens and stores payloads in memory.

    Example:
        provider = MockTokenProvider()

        # Create a token
        token = provider.create({"user_id": 1, "role": "admin"})
        # Returns "token_1"

        # Verify and decode
        payload = provider.verify(token)
        assert payload["user_id"] == 1

        # Refresh token
        new_token = provider.refresh(token)
        # Returns "token_2" with same payload
    """

    def __init__(self) -> None:
        """Initialize the mock token provider."""
        self._tokens: dict[str, dict[str, Any]] = {}
        self._counter = 0

    def create(self, payload: dict[str, Any]) -> str:
        """Create a token with the given payload.

        Args:
            payload: Data to encode in the token.

        Returns:
            The generated token string.
        """
        self._counter += 1
        token = f"token_{self._counter}"
        self._tokens[token] = payload.copy()
        return token

    def verify(self, token: str) -> dict[str, Any] | None:
        """Verify and decode a token.

        Args:
            token: The token to verify.

        Returns:
            Decoded payload if valid, None if invalid.
        """
        return self._tokens.get(token)

    def refresh(self, token: str) -> str | None:
        """Refresh a token.

        Args:
            token: The token to refresh.

        Returns:
            New token if renewable, None otherwise.
        """
        payload = self._tokens.get(token)
        if payload is not None:
            return self.create(payload)
        return None


class MockMFAProvider(Generic[T]):
    """Mock MFA provider for testing.

    Simulates MFA with configurable behavior.

    Example:
        provider = MockMFAProvider(
            enabled_users={1, 2},
            valid_code="123456",
        )

        # Check if user has MFA enabled
        assert await provider.is_enabled(user_with_id_1)

        # Verify a code
        assert await provider.verify(user, "totp", "123456")
    """

    def __init__(
        self,
        enabled_users: set[Any] | None = None,
        methods: list[str] | None = None,
        valid_code: str = "123456",
    ):
        """Initialize the mock provider.

        Args:
            enabled_users: Set of user IDs with MFA enabled.
            methods: Available MFA methods (default: ["totp"]).
            valid_code: The code that will be accepted as valid.
        """
        self._enabled_users = enabled_users if enabled_users is not None else set()
        self._methods = methods if methods is not None else ["totp"]
        self._valid_code = valid_code
        self._challenges_sent: list[tuple[Any, str]] = []

    async def is_enabled(self, user: T) -> bool:
        """Check if user has MFA enabled.

        Args:
            user: The user to check.

        Returns:
            True if MFA is enabled, False otherwise.
        """
        user_id = getattr(user, "id", None)
        return user_id in self._enabled_users

    async def get_methods(self, user: T) -> list[str]:
        """Get available MFA methods for user.

        Args:
            user: The user to get methods for.

        Returns:
            List of available method names.
        """
        return self._methods.copy()

    async def send_challenge(self, user: T, method: str) -> bool:
        """Send MFA challenge to user.

        Args:
            user: The user to send challenge to.
            method: The MFA method to use.

        Returns:
            True if challenge was sent.
        """
        user_id = getattr(user, "id", None)
        self._challenges_sent.append((user_id, method))
        return True

    async def verify(self, user: T, method: str, code: str) -> bool:
        """Verify MFA code.

        Args:
            user: The user to verify for.
            method: The MFA method used.
            code: The code to verify.

        Returns:
            True if code is valid, False otherwise.
        """
        return code == self._valid_code

    @property
    def challenges_sent(self) -> list[tuple[Any, str]]:
        """Read-only access to challenges sent.

        Returns:
            List of (user_id, method) tuples for verification in tests.
        """
        return list(self._challenges_sent)


@contextmanager
def mock_user(user: Any, permissions: set[str] | None = None) -> Iterator[Any]:
    """Context manager to mock an authenticated user in tests.

    Sets the user in AuthContext for the duration of the context.
    When permissions are provided, also configures a MockPermissionBackend
    so that @requires_permission decorators work correctly.

    Args:
        user: The user object to set as current user.
        permissions: Optional set of permission strings. When provided,
            sets user.permissions and configures MockPermissionBackend.

    Yields:
        The user object.

    Example:
        with mock_user(fake_user):
            response = client.get("/protected")
            assert response.status_code == 200

        with mock_user(admin_user, permissions={"users.delete"}):
            # @requires_permission("users.delete") will pass
            response = client.delete("/users/123")
            assert response.status_code == 200
    """
    original_backend = None
    original_permissions = None

    if permissions is not None:
        # Store and set permissions on user
        original_permissions = getattr(user, "permissions", None)
        user.permissions = permissions

        # Configure MockPermissionBackend so @requires_permission works
        original_backend = _permission_backend.get()
        _permission_backend.set(MockPermissionBackend())

    token = AuthContext.set_user(user)
    try:
        yield user
    finally:
        AuthContext.reset(token)

        if permissions is not None:
            # Restore original backend
            _permission_backend.set(original_backend)

            # Restore original permissions
            if original_permissions is not None:
                user.permissions = original_permissions
            elif hasattr(user, "permissions"):
                del user.permissions


class MockRawSessionStore:
    """Mock implementation of RawSessionProtocol for testing.

    Provides in-memory storage for temporary tokens and counters,
    used by MFA and rate limiting tests.

    Example:
        from lajara_ai.auth.testing import MockRawSessionStore
        from lajara_ai.auth.mfa import MFAManager

        store = MockRawSessionStore()
        manager = MFAManager(provider=my_provider, session_adapter=store)
    """

    def __init__(self) -> None:
        """Initialize with empty storage."""
        self.data: dict[str, dict[str, Any]] = {}
        self.counters: dict[str, int] = {}

    def set_raw(self, key: str, data: dict[str, Any], ttl: int) -> None:
        """Store data with key.

        Args:
            key: Storage key.
            data: Data to store.
            ttl: TTL in seconds (ignored in mock).
        """
        self.data[key] = data

    def get_raw(self, key: str) -> dict[str, Any] | None:
        """Get data by key.

        Args:
            key: Storage key.

        Returns:
            Stored data or None.
        """
        return self.data.get(key)

    def delete_raw(self, key: str) -> None:
        """Delete data by key.

        Args:
            key: Storage key to delete.
        """
        self.data.pop(key, None)
        self.counters.pop(key, None)

    def increment_raw(self, key: str, amount: int = 1, ttl: int = 0) -> int:
        """Increment counter.

        Args:
            key: Counter key.
            amount: Amount to increment.
            ttl: TTL in seconds (ignored in mock).

        Returns:
            New counter value.
        """
        self.counters[key] = self.counters.get(key, 0) + amount
        return self.counters[key]

    def get_counter_raw(self, key: str) -> int:
        """Get counter value.

        Args:
            key: Counter key.

        Returns:
            Counter value or 0.
        """
        return self.counters.get(key, 0)


# Type assertions to verify mocks implement their protocols
def _assert_protocol_compliance() -> None:
    """Static type assertion to verify mocks implement their protocols.

    This function is NEVER called at runtime. It exists solely for mypy
    static analysis. Each assignment verifies that a mock class correctly
    implements its corresponding protocol.

    How it works:
        - mypy analyzes this function during type checking
        - If a mock is missing a method or has wrong signatures, mypy fails
        - Example error: "MockUserProvider is missing method 'get_by_id'"

    Why no '# type: ignore':
        - Adding '# type: ignore[assignment]' would suppress errors
        - Without it, mypy actually validates protocol compliance

    If mypy passes, all mocks correctly implement their protocols.
    """
    _user_provider: UserProvider[MockUser] = MockUserProvider[MockUser]()
    _credential_verifier: CredentialVerifier[MockUser] = MockCredentialVerifier()
    _token_provider: TokenProvider = MockTokenProvider()
    _mfa_provider: MFAProvider[MockUser] = MockMFAProvider[MockUser]()
    _raw_session: RawSessionProtocol = MockRawSessionStore()
    _event_listener: EventListener = MockEventListener()
    _event_emitter: EventEmitterProtocol = MockEventEmitter()
