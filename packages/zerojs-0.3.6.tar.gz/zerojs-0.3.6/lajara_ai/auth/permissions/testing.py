"""Testing utilities for permission protocols.

Provides mock implementations of permission protocols for testing.
"""

from typing import Any

from .backend import PermissionBackend
from .rbac import RoleProvider


class MockRoleProvider:
    """Mock role provider for RBAC testing.

    Extracts roles from user.roles attribute.

    Example:
        provider = MockRoleProvider()

        user = MockUser(id=1, roles=["admin", "editor"])
        roles = await provider.get_roles(user)
        assert "admin" in roles
    """

    async def get_roles(self, user: Any) -> set[str]:
        """Get roles for a user.

        Args:
            user: The user to get roles for.

        Returns:
            Set of role names.
        """
        roles = getattr(user, "roles", [])
        return set(roles) if isinstance(roles, list) else roles


class MockPermissionBackend:
    """Simple permission backend that checks user.permissions attribute.

    Used by mock_user() to enable permission testing without configuring
    a full backend.

    Example:
        user = MockUser(id=1, permissions={"posts:read", "posts:edit"})
        backend = MockPermissionBackend()
        assert await backend.can(user, "posts:read")
        assert not await backend.can(user, "posts:delete")
    """

    async def can(self, user: Any, permission: str, **context: Any) -> bool:
        """Check if user has the permission in their permissions set.

        Args:
            user: The user to check permissions for.
            permission: The permission to check.
            **context: Additional context (ignored).

        Returns:
            True if permission is in user.permissions, False otherwise.
        """
        user_permissions: set[str] = getattr(user, "permissions", set())
        return permission in user_permissions


# Type assertions to verify mocks implement their protocols
def _assert_protocol_compliance() -> None:
    """Static type assertion to verify mocks implement their protocols.

    This function is NEVER called at runtime. It exists solely for mypy
    static analysis. Each assignment verifies that a mock class correctly
    implements its corresponding protocol.

    If mypy passes, all mocks correctly implement their protocols.
    """
    _role_provider: RoleProvider = MockRoleProvider()
    _permission_backend: PermissionBackend = MockPermissionBackend()


__all__ = ["MockRoleProvider", "MockPermissionBackend"]
