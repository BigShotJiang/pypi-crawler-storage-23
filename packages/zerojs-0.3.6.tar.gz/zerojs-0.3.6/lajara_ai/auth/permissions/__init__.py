"""Permission system with pluggable backends.

Provides flexible permission checking through pluggable backends.
Includes Role-Based Access Control (RBAC) as the built-in backend.

Example (RBAC):
    from lajara_ai.auth.permissions import (
        RBACBackend, RoleProvider, configure_permissions, requires_permission
    )

    class MyRoleProvider:
        async def get_roles(self, user) -> set[str]:
            return set(user.roles)

    rbac = RBACBackend(MyRoleProvider())
    rbac.define_roles({
        "admin": ["*"],
        "editor": ["posts:*"],
        "viewer": ["posts:read"],
    })
    configure_permissions(rbac)

    @requires_permission("posts:edit")
    async def edit_post(post_id: int):
        ...
"""

from .backend import PermissionBackend, configure_permissions, get_backend
from .decorators import check_permission, require_permission, requires_permission
from .rbac import RBACBackend, RoleProvider

__all__ = [
    # Backend protocol and configuration
    "PermissionBackend",
    "configure_permissions",
    "get_backend",
    # RBAC
    "RBACBackend",
    "RoleProvider",
    # Decorator
    "requires_permission",
    # Helper functions
    "check_permission",
    "require_permission",
]
