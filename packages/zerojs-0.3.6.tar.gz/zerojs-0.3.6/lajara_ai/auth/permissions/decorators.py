"""Permission decorators and helper functions.

Provides decorator-based permission checking and utility functions
for checking permissions programmatically.

Example:
    from lajara_ai.auth.permissions import requires_permission, check_permission

    @requires_permission("posts:edit")
    async def edit_post(post_id: int):
        ...

    # Or check programmatically
    if await check_permission(user, "posts:edit"):
        show_edit_button = True
"""

from collections.abc import Awaitable, Callable
from functools import wraps
from typing import Any, Literal

from ..context import AuthContext
from ..exceptions import PermissionDenied
from .backend import PermissionBackend, get_backend

__all__ = [
    "requires_permission",
    "check_permission",
    "require_permission",
]


async def _check_all_permissions(
    backend: PermissionBackend,
    user: Any,
    permissions: tuple[str, ...],
    ctx: dict[str, Any],
) -> str | None:
    """Check that user has all permissions. Returns first denied permission or None."""
    for perm in permissions:
        if not await backend.can(user, perm, **ctx):
            return perm
    return None


async def _check_any_permission(
    backend: PermissionBackend,
    user: Any,
    permissions: tuple[str, ...],
    ctx: dict[str, Any],
) -> bool:
    """Check that user has at least one permission. Returns True if any granted."""
    for perm in permissions:
        if await backend.can(user, perm, **ctx):
            return True
    return False


def _build_context(kwargs: dict[str, Any], resource_param: str | None) -> dict[str, Any]:
    """Build permission context from kwargs, adding resource_id if specified."""
    ctx = dict(kwargs)
    if resource_param and resource_param in kwargs:
        ctx["resource_id"] = kwargs[resource_param]
    return ctx


def requires_permission(
    *permissions: str,
    mode: Literal["all", "any"] = "all",
    resource_param: str | None = None,
) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]:
    """Decorator to verify permissions using the configured backend.

    Args:
        *permissions: Required permissions to check.
        mode: "all" requires all permissions (AND), "any" requires at least one (OR).
        resource_param: Name of function parameter containing resource_id for context.

    Returns:
        Decorator that wraps the function with permission checking.

    Raises:
        PermissionDenied: If user lacks required permissions.
        AuthenticationError: If no user is authenticated.

    Examples:
        # Single permission
        @requires_permission("posts:edit")
        async def edit_post(post_id: int):
            ...

        # Multiple permissions (AND - all required)
        @requires_permission("posts:edit", "posts:publish")
        async def edit_and_publish():
            ...

        # Multiple permissions (OR - any one sufficient)
        @requires_permission("posts:edit", "posts:admin", mode="any")
        async def manage_post():
            ...

        # With resource context
        @requires_permission("posts:edit", resource_param="post_id")
        async def edit_post(post_id: int):
            # Backend receives resource_id=post_id in context
            ...
    """

    def decorator(
        fn: Callable[..., Awaitable[Any]],
    ) -> Callable[..., Awaitable[Any]]:
        @wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            user: Any = AuthContext.require_user()
            backend = get_backend()
            user_id = getattr(user, "id", None)
            ctx = _build_context(kwargs, resource_param)

            if mode == "all":
                denied_perm = await _check_all_permissions(backend, user, permissions, ctx)
                if denied_perm:
                    raise PermissionDenied(denied_perm, user_id)
            else:  # mode == "any"
                if not await _check_any_permission(backend, user, permissions, ctx):
                    raise PermissionDenied(permissions, user_id, mode="any")

            return await fn(*args, **kwargs)

        return wrapper

    return decorator


async def check_permission(
    user: Any,
    permission: str,
    **context: Any,
) -> bool:
    """Check if user has permission without raising an exception.

    Use this for conditional logic where you need to check permissions
    programmatically without decorators.

    Args:
        user: The user to check permissions for.
        permission: The permission to check.
        **context: Additional context (e.g., resource_id).

    Returns:
        True if user has the permission, False otherwise.

    Example:
        if await check_permission(user, "posts:edit", resource_id=post.id):
            show_edit_button = True
    """
    return await get_backend().can(user, permission, **context)


async def require_permission(
    user: Any,
    permission: str,
    **context: Any,
) -> None:
    """Check permission and raise PermissionDenied if denied.

    Use this when you need to check permissions inline without a decorator.

    Args:
        user: The user to check permissions for.
        permission: The permission to check.
        **context: Additional context (e.g., resource_id).

    Raises:
        PermissionDenied: If user lacks the permission.

    Example:
        await require_permission(user, "posts:edit", resource_id=post.id)
        # Continue with edit logic...
    """
    if not await get_backend().can(user, permission, **context):
        raise PermissionDenied(permission, getattr(user, "id", None))
