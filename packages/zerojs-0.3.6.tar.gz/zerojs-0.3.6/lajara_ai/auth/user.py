"""Base user class for the auth system."""

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any


class BaseUser(ABC):
    """Abstract base class for users in the auth system.

    Subclass and implement all abstract methods to create your user model.
    The `login` and `logout` methods define the authentication lifecycle.

    Example:
        @dataclass
        class User(BaseUser):
            id: int
            email: str
            _password_hash: str = ""
            _is_active: bool = True
            _last_login: datetime | None = None

            def get_identifier(self) -> str:
                return self.email

            @property
            def password_hash(self) -> str:
                return self._password_hash

            def set_password_hash(self, hashed: str) -> None:
                self._password_hash = hashed

            @property
            def is_active(self) -> bool:
                return self._is_active

            @property
            def last_login(self) -> datetime | None:
                return self._last_login

            def _set_last_login(self, dt: datetime) -> None:
                self._last_login = dt

            async def login(self) -> None:
                self._set_last_login(datetime.now())
                # Save to database, emit events, etc.

            async def logout(self) -> None:
                # Clean up sessions, emit events, etc.
                pass
    """

    # --- Identity ---

    @property
    @abstractmethod
    def id(self) -> Any:
        """Unique identifier for this user (primary key)."""
        ...

    @abstractmethod
    def get_identifier(self) -> str:
        """Return the identifier used for login (email, username, etc.)."""
        ...

    # --- Password ---

    @property
    @abstractmethod
    def password_hash(self) -> str:
        """The hashed password."""
        ...

    @abstractmethod
    def set_password_hash(self, hashed: str) -> None:
        """Set the password hash. Use PasswordHasher to hash first."""
        ...

    # --- Account status ---

    @property
    @abstractmethod
    def is_active(self) -> bool:
        """Whether this account can log in."""
        ...

    # --- Tracking ---

    @property
    @abstractmethod
    def last_login(self) -> datetime | None:
        """Last login timestamp."""
        ...

    @abstractmethod
    def _set_last_login(self, dt: datetime) -> None:
        """Update last login. Call this from login()."""
        ...

    # --- Lifecycle ---

    @abstractmethod
    async def login(self) -> None:
        """Called after successful authentication.

        Implementers should:
        - Call self._set_last_login(datetime.now())
        - Persist changes to database
        - Emit events if needed
        """
        ...

    @abstractmethod
    async def logout(self) -> None:
        """Called on logout.

        Implementers should:
        - Clean up user-specific state
        - Invalidate sessions if needed
        - Emit events if needed
        """
        ...
