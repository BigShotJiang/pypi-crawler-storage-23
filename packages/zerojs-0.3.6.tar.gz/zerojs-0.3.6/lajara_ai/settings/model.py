"""Pydantic settings model for typed configuration."""

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class SecurityHeadersSettings(BaseModel):
    """Configuration for the SecurityHeadersMiddleware (Secweb).

    Each field maps to a Secweb header option.  ``None`` means the
    header is not set.
    """

    model_config = ConfigDict(frozen=True)

    csp: dict[str, list[str]] | None = None
    xframe: Literal["DENY", "SAMEORIGIN"] | None = "SAMEORIGIN"
    hsts: dict[str, Any] | None = None
    xcto: bool = True
    referrer: list[str] | None = Field(default_factory=lambda: ["strict-origin-when-cross-origin"])
    coop: Literal["same-origin", "same-origin-allow-popups", "unsafe-none"] | None = None
    coep: Literal["require-corp", "unsafe-none", "credentialless"] | None = None
    corp: Literal["same-origin", "same-site", "cross-origin"] | None = None


class Settings(BaseModel):
    """Typed application settings with validation.

    All fields have sensible defaults.  Unknown keys from ``settings.py``
    are silently ignored (``extra="ignore"``).  The model is frozen so
    settings cannot be mutated after loading — use
    ``model_copy(update=...)`` when a post-load override is needed.
    """

    model_config = ConfigDict(frozen=True, extra="ignore")

    # Cache
    CACHE_BACKEND: str = "memory"
    CACHE_STRATEGY: str = "none"
    CACHE_TTL: int = 0
    CACHE_ROUTES: dict[str, dict[str, Any]] = Field(default_factory=dict)

    # PyScript
    PYSCRIPT_ENABLED: bool = False
    PYSCRIPT_RUNTIME: Literal["micropython", "pyodide"] = "micropython"
    PYSCRIPT_VERSION: str = "2025.10.1"

    # CSRF
    CSRF_ENABLED: bool = True
    CSRF_TOKEN_NAME: str = "csrf_token"
    CSRF_EXEMPT_ROUTES: list[str] = Field(default_factory=list)
    CSRF_COOKIE_SECURE: bool = False

    # Middleware
    MIDDLEWARE: list[str] = Field(default_factory=list)

    # TrustedHostMiddleware
    TRUSTED_HOSTS: list[str] = Field(default_factory=lambda: ["*"])

    # CORSMiddleware
    CORS_ALLOWED_ORIGINS: list[str] = Field(default_factory=list)
    CORS_ALLOWED_METHODS: list[str] = Field(default_factory=lambda: ["GET"])
    CORS_ALLOWED_HEADERS: list[str] = Field(default_factory=list)
    CORS_ALLOW_CREDENTIALS: bool = False
    CORS_MAX_AGE: int = 600

    # GZipMiddleware
    GZIP_MINIMUM_SIZE: int = 500

    # SessionMiddleware
    SECRET_KEY: str = ""
    SESSION_COOKIE: str = "session"
    SESSION_MAX_AGE: int = 1209600  # 14 days
    SESSION_SAME_SITE: Literal["lax", "strict", "none"] = "lax"
    SESSION_HTTPS_ONLY: bool = False
    SESSION_ABSOLUTE_LIFETIME: int = 0
    SESSION_STORAGE: str = "memory://"

    # SecurityHeadersMiddleware
    SECURITY_HEADERS: SecurityHeadersSettings = Field(default_factory=SecurityHeadersSettings)

    # RateLimitMiddleware
    RATE_LIMIT_DEFAULT: str = "100/minute"
    RATE_LIMIT_STORAGE: str = "memory://"
    RATE_LIMIT_STRATEGY: Literal["fixed-window", "moving-window"] = "fixed-window"
    RATE_LIMIT_HEADERS: bool = True

    # AuthMiddleware
    AUTH_USER_PROVIDER: str = ""
    AUTH_SESSION_KEY: str = "user_id"

    # Static URL (set post-load via model_copy)
    STATIC_URL: str = "/static"
