"""Settings loader for user configuration."""

import importlib.util
from pathlib import Path
from types import ModuleType
from typing import Any

from dotenv import load_dotenv

from .env import load_env_overrides
from .model import Settings


def load_user_settings(
    settings_file: Path | None = None,
    schema_file: Path | None = None,
    dotenv_path: Path | None = None,
) -> Settings:
    """Load settings from user's settings.py, .env file, and environment variables.

    Reads the user's ``settings.py``, loads ``.env`` into the process
    environment, applies schema-driven overrides, and validates
    everything through the :class:`Settings` Pydantic model.

    Args:
        settings_file: Path to settings.py. If None, looks in current directory.
        schema_file: Path to .env.schema.yaml. If None, looks in current directory.
        dotenv_path: Path to .env file. If None, looks in current directory.

    Returns:
        Validated, immutable Settings instance.
        Precedence: env vars > .env file > settings.py > defaults.
    """
    overrides: dict[str, Any] = {}

    if settings_file is None:
        settings_file = Path("settings.py")

    if settings_file.exists():
        module = _load_settings_module(settings_file)
        if module is not None:
            for field_name in Settings.model_fields:
                if hasattr(module, field_name):
                    overrides[field_name] = getattr(module, field_name)

    # Load .env file into os.environ (does NOT override existing env vars)
    load_dotenv(dotenv_path, override=False)

    # Apply environment variable overrides from schema
    env_overrides = load_env_overrides(schema_file)
    overrides.update(env_overrides)

    return Settings(**overrides)


def _load_settings_module(settings_file: Path) -> ModuleType | None:
    """Load a settings.py file as a Python module.

    Args:
        settings_file: Path to the settings file.

    Returns:
        The loaded module, or None if it could not be loaded.
    """
    spec = importlib.util.spec_from_file_location("settings", settings_file)
    if spec is None or spec.loader is None:
        return None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
