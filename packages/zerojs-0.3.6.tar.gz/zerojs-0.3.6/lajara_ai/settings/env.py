"""Environment variable loading from .env.schema.yaml."""

import os
from pathlib import Path
from typing import Any, Literal

import yaml

InferSecretsMode = Literal["none", "lax", "smart", "strict"]


class EnvConfigError(Exception):
    """Raised when environment configuration is invalid."""


_MISSING = object()


def load_env_overrides(schema_path: Path | None = None) -> dict[str, Any]:
    """Load environment variable overrides from a schema file.

    Reads ``.env.schema.yaml``, extracts matching environment variables,
    coerces types, validates values, and returns a dict of overrides.

    Args:
        schema_path: Path to the schema file.  If None, looks for
            ``.env.schema.yaml`` in the current directory.

    Returns:
        Dictionary with validated overrides.  Empty if no schema file exists.

    Raises:
        EnvConfigError: If a required variable is missing or validation fails.
    """
    if schema_path is None:
        schema_path = Path(".env.schema.yaml")

    if not schema_path.exists():
        return {}

    with open(schema_path, encoding="utf-8") as f:
        schema = yaml.safe_load(f)

    if not schema or "env" not in schema:
        return {}

    config = schema.get("config", {})
    prefix = config.get("prefix", "")
    separator = config.get("dict_separator", "__")
    profile_var = config.get("profile_var", "ZEROJS_ENV_PROFILE")
    active_profile = os.environ.get(profile_var)
    profiles_available: list[str] | None = config.get("profiles_available")

    infer_secrets: InferSecretsMode = config.get("infer_secrets", "smart")
    if infer_secrets not in ("none", "lax", "smart", "strict"):
        raise EnvConfigError(
            f"Invalid infer_secrets mode '{infer_secrets}' in {schema_path}. Must be one of: none, lax, smart, strict"
        )

    env_schema: dict[str, dict[str, Any]] = schema["env"]

    _validate_secrets(env_schema, schema_path, mode=infer_secrets)

    if profiles_available is not None:
        _validate_profiles(env_schema, profiles_available, active_profile, profile_var, schema_path)

    result: dict[str, Any] = {}

    for key, entry in env_schema.items():
        type_str = entry.get("type", "str")

        if type_str == "dict":
            value = _resolve_dict(key, entry, prefix, separator, schema_path, active_profile)
        else:
            value = _resolve_scalar(key, entry, type_str, prefix, schema_path, active_profile)

        if value is not _MISSING:
            result[key] = value

    return result


_SECRET_FORBIDDEN_KEYS = ("default", "profiles")

_ALWAYS_SECRET = frozenset({"SECRET", "PASSWORD", "PASSWD", "PWD", "CREDENTIAL"})
_CONDITIONAL_SECRET: dict[str, frozenset[str]] = {
    "KEY": frozenset(
        {"API", "SECRET", "ENCRYPTION", "SSH", "AUTH", "ACCESS", "SIGNING", "SERVICE", "PRIVATE", "MASTER"}
    ),
    "TOKEN": frozenset({"API", "AUTH", "ACCESS", "REFRESH", "SESSION", "SERVICE", "BEARER", "SECRET", "PRIVATE"}),
}


def _infer_secret(name: str, parent_name: str | None = None, *, mode: InferSecretsMode = "smart") -> bool:
    """Infer whether a variable is secret based on its name.

    Always-secret words (e.g. ``PASSWORD``) are matched on the entry's
    own name only.  Conditional words (e.g. ``KEY``) require a qualifier
    (e.g. ``API``) which may come from the entry name or the parent name.

    Args:
        name: The variable or child key name.
        parent_name: The parent key name for dict children.
        mode: Inference aggressiveness — ``"none"`` disables inference,
            ``"lax"`` matches only always-secret words, ``"smart"``
            (default) uses qualifier-based matching, ``"strict"`` treats
            conditional words as always secret.

    Returns:
        True if the name looks like a secret.
    """
    if mode == "none":
        return False

    tokens = set(name.upper().split("_"))

    if tokens & _ALWAYS_SECRET:
        return True

    if mode == "lax":
        return False

    if mode == "strict":
        for word in _CONDITIONAL_SECRET:
            if word in tokens:
                return True
        return False

    # mode == "smart" (default)
    all_tokens = tokens | set(parent_name.upper().split("_")) if parent_name is not None else tokens
    for word, qualifiers in _CONDITIONAL_SECRET.items():
        if word in tokens and all_tokens & qualifiers:
            return True

    return False


def _is_secret(
    entry: dict[str, Any], name: str, parent_name: str | None = None, *, mode: InferSecretsMode = "smart"
) -> bool:
    """Determine whether a schema entry is secret.

    Uses the explicit ``secret`` field if present, otherwise infers
    from the variable name.

    Args:
        entry: The schema entry.
        name: The variable or child key name.
        parent_name: The parent key name for dict children.
        mode: Inference aggressiveness passed to :func:`_infer_secret`.

    Returns:
        True if the entry is considered secret.
    """
    if "secret" in entry:
        return bool(entry["secret"])
    return _infer_secret(name, parent_name, mode=mode)


def _check_secret_entry(
    entry: dict[str, Any],
    label: str,
    schema_path: Path,
) -> None:
    """Raise if a secret entry contains forbidden keys.

    Args:
        entry: The schema entry.
        label: Display name for error messages (e.g. ``'SECRET_KEY'``).
        schema_path: Path to schema file (for error messages).

    Raises:
        EnvConfigError: If the entry contains ``default`` or ``profiles``.
    """
    for forbidden in _SECRET_FORBIDDEN_KEYS:
        if forbidden in entry:
            raise EnvConfigError(f"Secret variable '{label}' must not have '{forbidden}' (defined in {schema_path})")


def _validate_secrets(
    env_schema: dict[str, dict[str, Any]],
    schema_path: Path,
    *,
    mode: InferSecretsMode = "smart",
) -> None:
    """Validate that secret entries do not expose hardcoded values.

    Entries that are secret (explicitly or by inference) must not have
    ``default`` or ``profiles`` keys, as those would embed sensitive
    values in the schema file.

    Args:
        env_schema: The ``env`` section of the schema.
        schema_path: Path to schema file (for error messages).
        mode: Inference aggressiveness passed to :func:`_is_secret`.

    Raises:
        EnvConfigError: If a secret entry contains forbidden keys.
    """
    for key, entry in env_schema.items():
        if _is_secret(entry, key, mode=mode):
            _check_secret_entry(entry, key, schema_path)

        if entry.get("type") == "dict":
            for child_key, child_entry in entry.get("items", {}).items():
                if _is_secret(child_entry, child_key, parent_name=key, mode=mode):
                    _check_secret_entry(child_entry, f"{key}.items.{child_key}", schema_path)


def _check_profile_names(
    entry: dict[str, Any],
    label: str,
    allowed: set[str],
    profiles_available: list[str],
    schema_path: Path,
) -> None:
    """Raise if any profile key in an entry is not in the allowed set.

    Args:
        entry: The schema entry.
        label: Display name for error messages (e.g. ``'DEBUG.profiles'``).
        allowed: Set of allowed profile names.
        profiles_available: Original list (for error messages).
        schema_path: Path to schema file (for error messages).

    Raises:
        EnvConfigError: If an unknown profile name is found.
    """
    for name in entry.get("profiles", {}):
        if name not in allowed:
            raise EnvConfigError(
                f"Profile '{name}' in '{label}.profiles' is not in "
                f"profiles_available {profiles_available} (defined in {schema_path})"
            )


def _validate_profiles(
    env_schema: dict[str, dict[str, Any]],
    profiles_available: list[str],
    active_profile: str | None,
    profile_var: str,
    schema_path: Path,
) -> None:
    """Validate profile names against the allowed list.

    Checks that every profile key used in ``profiles`` entries (including
    dict children) is declared in ``config.profiles_available``, and that
    the active profile (if set) is also in the list.

    Args:
        env_schema: The ``env`` section of the schema.
        profiles_available: Allowed profile names from config.
        active_profile: The currently active profile (may be None).
        profile_var: Name of the env var that sets the active profile.
        schema_path: Path to schema file (for error messages).

    Raises:
        EnvConfigError: If an unknown profile name is found.
    """
    allowed = set(profiles_available)

    if active_profile is not None and active_profile not in allowed:
        raise EnvConfigError(
            f"Active profile '{active_profile}' (from {profile_var}) is not in "
            f"profiles_available {profiles_available} (defined in {schema_path})"
        )

    for key, entry in env_schema.items():
        _check_profile_names(entry, key, allowed, profiles_available, schema_path)

        if entry.get("type") == "dict":
            for child_key, child_entry in entry.get("items", {}).items():
                _check_profile_names(child_entry, f"{key}.items.{child_key}", allowed, profiles_available, schema_path)


def _coerce_if_str(value: Any, type_str: str, env_key: str, schema_path: Path) -> Any:
    """Coerce *value* only when it is a string and the target type differs.

    YAML often delivers the correct Python type (``42`` → ``int``), but
    quoted values (``"42"``) arrive as ``str``.  This helper applies
    :func:`_coerce` only when coercion is actually needed, leaving
    already-typed values untouched.

    Args:
        value: The value from a profile or default.
        type_str: The declared type string.
        env_key: Environment variable name (for error messages).
        schema_path: Path to schema file (for error messages).

    Returns:
        The value, coerced if necessary.
    """
    if isinstance(value, str) and type_str != "str":
        return _coerce(value, type_str, env_key, schema_path)
    return value


def _resolve_scalar(
    key: str,
    entry: dict[str, Any],
    type_str: str,
    prefix: str,
    schema_path: Path,
    active_profile: str | None = None,
) -> Any:
    """Resolve a scalar environment variable.

    Args:
        key: The setting key.
        entry: The schema entry for this variable.
        type_str: The declared type string.
        prefix: Environment variable prefix.
        schema_path: Path to schema file (for error messages).
        active_profile: Active configuration profile name.

    Returns:
        The coerced and validated value, or ``_MISSING`` if not set.

    Raises:
        EnvConfigError: If required and missing, or validation fails.
    """
    env_key = f"{prefix}{key}"
    raw = os.environ.get(env_key)

    if raw is not None:
        value = _coerce(raw, type_str, env_key, schema_path)
        _validate(value, entry, env_key, schema_path)
        return value

    if active_profile is not None:
        profiles = entry.get("profiles", {})
        if active_profile in profiles:
            value = _coerce_if_str(profiles[active_profile], type_str, env_key, schema_path)
            _validate(value, entry, env_key, schema_path)
            return value

    if entry.get("required", False):
        raise EnvConfigError(f"Required environment variable '{env_key}' is not set (defined in {schema_path})")

    if "default" in entry:
        value = _coerce_if_str(entry["default"], type_str, env_key, schema_path)
        _validate(value, entry, env_key, schema_path)
        return value

    return _MISSING


def _resolve_dict(
    key: str,
    entry: dict[str, Any],
    prefix: str,
    separator: str,
    schema_path: Path,
    active_profile: str | None = None,
) -> Any:
    """Resolve a dict-type environment variable from its items.

    Args:
        key: The setting key (e.g., ``SECURITY_HEADERS``).
        entry: The schema entry containing ``items``.
        prefix: Environment variable prefix.
        separator: Separator between parent and child keys.
        schema_path: Path to schema file (for error messages).
        active_profile: Active configuration profile name.

    Returns:
        A dictionary built from child env vars, or ``_MISSING``.

    Raises:
        EnvConfigError: If a required child is missing or validation fails.
    """
    items: dict[str, dict[str, Any]] = entry.get("items", {})
    if not items:
        return _MISSING

    result: dict[str, Any] = {}
    has_any = False

    for child_key, child_entry in items.items():
        child_type = child_entry.get("type", "str")
        env_key = f"{prefix}{key}{separator}{child_key}"
        raw = os.environ.get(env_key)

        if raw is not None:
            value = _coerce(raw, child_type, env_key, schema_path)
            _validate(value, child_entry, env_key, schema_path)
            result[child_key] = value
            has_any = True
        elif active_profile is not None and active_profile in child_entry.get("profiles", {}):
            value = _coerce_if_str(child_entry["profiles"][active_profile], child_type, env_key, schema_path)
            _validate(value, child_entry, env_key, schema_path)
            result[child_key] = value
            has_any = True
        elif child_entry.get("required", False):
            raise EnvConfigError(f"Required environment variable '{env_key}' is not set (defined in {schema_path})")
        elif "default" in child_entry:
            value = _coerce_if_str(child_entry["default"], child_type, env_key, schema_path)
            _validate(value, child_entry, env_key, schema_path)
            result[child_key] = value
            has_any = True

    if not has_any and entry.get("required", False):
        raise EnvConfigError(
            f"Required environment variable '{prefix}{key}' has no items set (defined in {schema_path})"
        )

    return result if has_any else _MISSING


def _coerce_bool(value: str, env_key: str, schema_path: Path) -> bool:
    """Coerce a string value to a boolean.

    Args:
        value: The raw string from the environment.
        env_key: The environment variable name (for error messages).
        schema_path: Path to schema file (for error messages).

    Returns:
        The coerced boolean value.

    Raises:
        EnvConfigError: If the value is not a recognized boolean string.
    """
    lowered = value.lower()
    if lowered in ("true", "1", "yes", "y"):
        return True
    if lowered in ("false", "0", "no", "n"):
        return False
    raise EnvConfigError(
        f"Environment variable '{env_key}' must be a boolean "
        f"(true/false/1/0/yes/no/y/n), got '{value}' (defined in {schema_path})"
    )


def _coerce(value: str, type_str: str, env_key: str, schema_path: Path) -> Any:
    """Coerce a string value to the declared type.

    Args:
        value: The raw string from the environment.
        type_str: The declared type (``str``, ``int``, ``float``, ``bool``,
            ``json``, ``list[<scalar>]``).  Lists are split by ``,``.
        env_key: The environment variable name (for error messages).
        schema_path: Path to schema file (for error messages).

    Returns:
        The coerced value.

    Raises:
        EnvConfigError: If coercion fails.
    """
    if type_str == "str":
        return value

    if type_str == "int":
        try:
            return int(value)
        except ValueError as exc:
            raise EnvConfigError(
                f"Environment variable '{env_key}' must be an integer, got '{value}' (defined in {schema_path})"
            ) from exc

    if type_str == "float":
        try:
            return float(value)
        except ValueError as exc:
            raise EnvConfigError(
                f"Environment variable '{env_key}' must be a float, got '{value}' (defined in {schema_path})"
            ) from exc

    if type_str == "bool":
        return _coerce_bool(value, env_key, schema_path)

    if type_str == "json":
        import json

        try:
            return json.loads(value)
        except json.JSONDecodeError as exc:
            raise EnvConfigError(
                f"Environment variable '{env_key}' must be valid JSON, got '{value}' (defined in {schema_path})"
            ) from exc

    if type_str.startswith("list[") and type_str.endswith("]"):
        inner_type = type_str[5:-1]
        items = [item.strip() for item in value.split(",")]
        return [_coerce(item, inner_type, env_key, schema_path) for item in items]

    raise EnvConfigError(
        f"Unsupported type '{type_str}' for environment variable '{env_key}' (defined in {schema_path})"
    )


def _validate(value: Any, entry: dict[str, Any], env_key: str, schema_path: Path) -> None:
    """Validate a coerced value against schema constraints.

    Args:
        value: The coerced value.
        entry: The schema entry with constraints.
        env_key: The environment variable name (for error messages).
        schema_path: Path to schema file (for error messages).

    Raises:
        EnvConfigError: If validation fails.
    """
    choices = entry.get("choices")
    if choices is not None and value not in choices:
        raise EnvConfigError(
            f"Environment variable '{env_key}' must be one of {choices}, got '{value}' (defined in {schema_path})"
        )
