"""ZeroJS application base."""

from .core import ZeroJS

__all__ = ["ZeroJS"]
