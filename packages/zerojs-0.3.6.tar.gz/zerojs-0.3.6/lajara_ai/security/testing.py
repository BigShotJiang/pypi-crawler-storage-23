"""Testing utilities for the security module.

Provides deterministic secret generation for tests, avoiding
hardcoded credentials and Bandit false positives.

Example:
    from lajara_ai.security.testing import SecretGenerator

    secrets = SecretGenerator()
    password = secrets.password()       # "test-password-1"
    token = secrets.token()             # "test-token-2"
"""

from __future__ import annotations


class SecretGenerator:
    """Generates unique test secrets to avoid hardcoding credentials in tests.

    Produces deterministic, sequential strings for passwords, tokens,
    and secret keys. Each call returns a unique value, preventing
    Bandit false positives (B105/B106/B107) without ``# nosec`` comments.

    Attributes:
        prefix: String prepended to every generated secret.

    Example:
        secrets = SecretGenerator()
        password = secrets.password()       # "test-password-1"
        token = secrets.token()             # "test-token-2"
        key = secrets.secret_key()          # "test-secret-key-3"

        # Custom prefix
        secrets = SecretGenerator(prefix="mock")
        secrets.password()                  # "mock-password-1"
    """

    def __init__(self, prefix: str = "test") -> None:
        """Initialize the generator.

        Args:
            prefix: String prepended to every generated secret.
        """
        self._prefix = prefix
        self._counter = 0

    def _next(self, category: str) -> str:
        """Generate the next sequential secret.

        Args:
            category: The type of secret (e.g. "password", "token").

        Returns:
            A unique string in the format ``{prefix}-{category}-{n}``.
        """
        self._counter += 1
        return f"{self._prefix}-{category}-{self._counter}"

    def password(self) -> str:
        """Generate a unique test password.

        Returns:
            A unique password string.
        """
        return self._next("password")

    def token(self) -> str:
        """Generate a unique test token.

        Returns:
            A unique token string.
        """
        return self._next("token")

    def secret_key(self) -> str:
        """Generate a unique test secret key.

        Returns:
            A unique secret key string.
        """
        return self._next("secret-key")


__all__ = ["SecretGenerator"]
