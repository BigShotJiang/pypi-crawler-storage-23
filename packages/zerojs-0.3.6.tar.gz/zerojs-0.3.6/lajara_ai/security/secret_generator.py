"""Cryptographically secure secret generation.

Provides a production-ready secret generator using the ``secrets``
standard-library module for passwords, tokens, and secret keys.
"""

import secrets
import string


class SecretGenerator:
    """Generate cryptographically secure passwords, tokens, and secret keys.

    Each method produces a random string suitable for production use.
    The generator is stateless; create an instance and call methods directly.

    Example:
        gen = SecretGenerator()
        password = gen.password()        # random 16-char password
        token = gen.token()              # random URL-safe token
        key = gen.secret_key()           # random URL-safe secret key
    """

    _PASSWORD_ALPHABET = string.ascii_letters + string.digits + string.punctuation

    def password(self, length: int = 16) -> str:
        """Generate a secure random password.

        Args:
            length: Number of characters (default 16).

        Returns:
            A random password drawn from letters, digits, and punctuation.
        """
        return "".join(secrets.choice(self._PASSWORD_ALPHABET) for _ in range(length))

    def token(self, length: int = 32) -> str:
        """Generate a secure URL-safe token.

        Args:
            length: Number of random bytes before base64 encoding (default 32).

        Returns:
            A URL-safe base64-encoded token string.
        """
        return secrets.token_urlsafe(length)

    def secret_key(self, length: int = 32) -> str:
        """Generate a secure URL-safe secret key.

        Args:
            length: Number of random bytes before base64 encoding (default 32).

        Returns:
            A URL-safe base64-encoded secret key string.
        """
        return secrets.token_urlsafe(length)


__all__ = ["SecretGenerator"]
