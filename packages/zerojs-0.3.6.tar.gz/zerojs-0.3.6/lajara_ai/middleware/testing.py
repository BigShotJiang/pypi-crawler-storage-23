"""Testing utilities for middleware.

Provides mock implementations of middleware protocols for testing.
"""

from starlette.types import ASGIApp, Receive, Scope, Send

from .base import BaseMiddleware
from .protocols import MiddlewareProtocol


class MockMiddleware:
    """Mock middleware for testing.

    Implements MiddlewareProtocol for testing middleware registration
    and ASGI middleware chains.

    Example:
        def test_middleware_registration():
            app = ZeroJS(...)
            app.add_middleware(MockMiddleware, option="value")
            # Verify middleware was registered
    """

    def __init__(self, app: ASGIApp, **kwargs: object) -> None:
        """Initialize middleware with ASGI app.

        Args:
            app: The ASGI application to wrap.
            **kwargs: Additional options (stored for test verification).
        """
        self.app = app
        self.kwargs = kwargs

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Pass through to wrapped app.

        Args:
            scope: ASGI connection scope.
            receive: ASGI receive callable.
            send: ASGI send callable.
        """
        await self.app(scope, receive, send)


# Type assertion to verify MockMiddleware implements MiddlewareProtocol
def _assert_protocol_compliance() -> None:
    """Static type assertion to verify MockMiddleware implements MiddlewareProtocol.

    This function is NEVER called at runtime. It exists solely for mypy
    static analysis. The assignment verifies that MockMiddleware correctly
    implements the MiddlewareProtocol interface.

    How it works:
        - mypy analyzes this function during type checking
        - If MockMiddleware is missing __init__ or __call__, mypy fails
        - If method signatures don't match the protocol, mypy fails

    Why we instantiate the mock:
        - Protocols define instance interfaces, not class interfaces
        - We need `MockMiddleware(app)` (instance), not `MockMiddleware` (class)

    If mypy passes, MockMiddleware correctly implements MiddlewareProtocol.
    """

    async def _dummy_app(
        scope: Scope, receive: Receive, send: Send
    ) -> None: ...  # No-op ASGI app used only for protocol compliance checks above

    _mock_middleware: MiddlewareProtocol = MockMiddleware(_dummy_app)
    _base_middleware: MiddlewareProtocol = BaseMiddleware(_dummy_app)


__all__ = ["MockMiddleware"]
