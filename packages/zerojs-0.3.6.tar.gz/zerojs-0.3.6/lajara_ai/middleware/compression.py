"""Compression middleware for ZeroJS."""

from starlette.middleware.gzip import GZipMiddleware as _GZipMiddleware


class GZipMiddleware(_GZipMiddleware):
    """GZip compression middleware.

    Compresses responses for clients that support it.
    """

    pass


__all__ = [
    "GZipMiddleware",
]
