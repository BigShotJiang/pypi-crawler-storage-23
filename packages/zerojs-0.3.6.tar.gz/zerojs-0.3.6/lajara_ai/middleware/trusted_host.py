"""Trusted host middleware for ZeroJS."""

from starlette.middleware.trustedhost import TrustedHostMiddleware as _TrustedHostMiddleware


class TrustedHostMiddleware(_TrustedHostMiddleware):
    """Trusted host middleware.

    Guards against HTTP Host header attacks.
    """

    pass


__all__ = [
    "TrustedHostMiddleware",
]
