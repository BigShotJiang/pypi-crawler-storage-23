"""Rate limiting middleware for ZeroJS."""

from collections.abc import Callable
from typing import Any

from slowapi import Limiter as _Limiter  # type: ignore[import-untyped]
from slowapi.middleware import SlowAPIASGIMiddleware  # type: ignore[import-untyped]
from slowapi.util import get_remote_address  # type: ignore[import-untyped]


class Limiter(_Limiter):
    """Rate limiter for controlling request frequency.

    Wraps slowapi's Limiter for rate limiting functionality.
    """

    pass


class RateLimitMiddleware(SlowAPIASGIMiddleware):
    """Rate limiting middleware for ZeroJS.

    Wraps slowapi's SlowAPIASGIMiddleware with automatic configuration.

    Usage in settings.py:
        MIDDLEWARE = [
            "lajara_ai.middleware.RateLimitMiddleware",
            ...
        ]

        RATE_LIMIT_DEFAULT = "100/minute"  # Default limit for all routes
        RATE_LIMIT_STORAGE = "memory://"   # or "redis://localhost:6379"
        RATE_LIMIT_STRATEGY = "fixed-window"  # or "moving-window"
        RATE_LIMIT_HEADERS = True  # Include X-RateLimit-* headers

    Rate limit format: "{count}/{period}"
        - count: number of requests allowed
        - period: second, minute, hour, day (or s, m, h, d)
        - Examples: "100/minute", "1000/hour", "5/second"

    Can also be used directly with explicit configuration:
        limiter = Limiter(key_func=get_remote_address, default_limits=["100/minute"])
        app.state.limiter = limiter
        app.add_middleware(RateLimitMiddleware)
    """

    def __init__(
        self,
        app: Any,
        *,
        limiter: Limiter | None = None,
        default_limits: list[str] | None = None,
        storage_uri: str = "memory://",
        strategy: str = "fixed-window",
        headers_enabled: bool = True,
        key_func: Callable[..., str] | None = None,
    ) -> None:
        """Initialize rate limiting middleware.

        Args:
            app: The ASGI application.
            limiter: Pre-configured Limiter instance. If provided, other
                limiter configuration arguments are ignored. The limiter
                must already be stored in the FastAPI app's state.
            default_limits: Default rate limits (e.g., ["100/minute"]).
            storage_uri: Storage backend URI ("memory://" or "redis://...").
            strategy: Rate limiting strategy ("fixed-window" or "moving-window").
            headers_enabled: Whether to include X-RateLimit-* headers.
            key_func: Function to extract rate limit key from request.
                Defaults to client IP address.
        """
        if limiter is None:
            limiter = Limiter(
                key_func=key_func or get_remote_address,
                default_limits=default_limits or ["100/minute"],  # type: ignore[arg-type]
                storage_uri=storage_uri,
                strategy=strategy,
                headers_enabled=headers_enabled,
            )
            # Store limiter in app state (required by slowapi)
            # Note: Only set if we created the limiter - otherwise caller
            # is responsible for storing it on the actual FastAPI app
            app.state.limiter = limiter

        super().__init__(app)


__all__ = [
    "Limiter",
    "RateLimitMiddleware",
]
