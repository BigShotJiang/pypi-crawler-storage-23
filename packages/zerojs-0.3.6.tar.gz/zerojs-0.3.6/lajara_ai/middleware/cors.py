"""CORS middleware for ZeroJS."""

from starlette.middleware.cors import CORSMiddleware as _CORSMiddleware


class CORSMiddleware(_CORSMiddleware):
    """Cross-Origin Resource Sharing middleware.

    Handles CORS preflight requests and adds appropriate headers.
    """

    pass


__all__ = [
    "CORSMiddleware",
]
