"""Security headers middleware for ZeroJS."""

from typing import Any

from starlette.types import ASGIApp, Message, Receive, Scope, Send


class SecurityHeadersMiddleware:
    """Security headers middleware for ZeroJS.

    Adds configurable security headers to all responses in a single middleware.

    Usage in settings.py:
        MIDDLEWARE = [
            "lajara_ai.middleware.SecurityHeadersMiddleware",
            ...
        ]

        SECURITY_HEADERS = {
            "xframe": "DENY",
            "xcto": True,
            "hsts": {"max-age": 31536000, "includeSubDomains": True},
            "csp": {"default-src": ["'self'"]},
            "referrer": ["strict-origin-when-cross-origin"],
            "coop": "same-origin",
            "coep": "require-corp",
            "corp": "same-origin",
        }

    Can also be used directly with explicit configuration:
        app.add_middleware(
            SecurityHeadersMiddleware,
            xframe="DENY",
            xcto=True,
            hsts={"max-age": 31536000},
        )
    """

    def __init__(
        self,
        app: ASGIApp,
        *,
        csp: dict[str, list[str]] | None = None,
        hsts: dict[str, Any] | None = None,
        xframe: str | None = None,
        xcto: bool = False,
        referrer: list[str] | None = None,
        coop: str | None = None,
        coep: str | None = None,
        corp: str | None = None,
    ) -> None:
        """Initialize security headers middleware.

        Args:
            app: The ASGI application.
            csp: Content-Security-Policy directives.
                Example: {"default-src": ["'self'"], "script-src": ["'self'", "'unsafe-inline'"]}
            hsts: Strict-Transport-Security options.
                Example: {"max-age": 31536000, "includeSubDomains": True, "preload": True}
            xframe: X-Frame-Options value ("DENY" or "SAMEORIGIN").
            xcto: Whether to add X-Content-Type-Options: nosniff.
            referrer: Referrer-Policy values.
                Example: ["strict-origin-when-cross-origin"]
            coop: Cross-Origin-Opener-Policy value.
                Example: "same-origin", "same-origin-allow-popups", "unsafe-none"
            coep: Cross-Origin-Embedder-Policy value.
                Example: "require-corp", "unsafe-none"
            corp: Cross-Origin-Resource-Policy value.
                Example: "same-site", "same-origin", "cross-origin"
        """
        self.app = app
        self._headers: list[tuple[bytes, bytes]] = []

        # Build headers list
        if csp:
            self._headers.append((b"content-security-policy", self._build_csp(csp).encode()))

        if hsts:
            self._headers.append((b"strict-transport-security", self._build_hsts(hsts).encode()))

        if xframe:
            self._headers.append((b"x-frame-options", xframe.encode()))

        if xcto:
            self._headers.append((b"x-content-type-options", b"nosniff"))

        if referrer:
            self._headers.append((b"referrer-policy", ", ".join(referrer).encode()))

        if coop:
            self._headers.append((b"cross-origin-opener-policy", coop.encode()))

        if coep:
            self._headers.append((b"cross-origin-embedder-policy", coep.encode()))

        if corp:
            self._headers.append((b"cross-origin-resource-policy", corp.encode()))

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Process the request and add security headers to response."""
        if scope["type"] != "http" or not self._headers:
            await self.app(scope, receive, send)
            return

        async def send_with_headers(message: Message) -> None:
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))
                headers.extend(self._headers)
                message = {**message, "headers": headers}
            await send(message)

        await self.app(scope, receive, send_with_headers)

    def _build_csp(self, csp: dict[str, list[str]]) -> str:
        """Build Content-Security-Policy header value."""
        directives = []
        for directive, values in csp.items():
            directives.append(f"{directive} {' '.join(values)}")
        return "; ".join(directives)

    def _build_hsts(self, hsts: dict[str, Any]) -> str:
        """Build Strict-Transport-Security header value."""
        parts = []
        if "max-age" in hsts:
            parts.append(f"max-age={hsts['max-age']}")
        if hsts.get("includeSubDomains"):
            parts.append("includeSubDomains")
        if hsts.get("preload"):
            parts.append("preload")
        return "; ".join(parts)


__all__ = [
    "SecurityHeadersMiddleware",
]
