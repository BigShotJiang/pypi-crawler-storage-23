"""Middleware protocols for ZeroJS.

Defines the contract that all ASGI middlewares must follow.
"""

from typing import Any, Protocol

from starlette.types import ASGIApp, Receive, Scope, Send


class MiddlewareProtocol(Protocol):
    """Protocol defining the ASGI middleware contract.

    All middlewares in ZeroJS follow this pattern:
    - Accept an ASGI app and optional kwargs in __init__
    - Implement async __call__ with ASGI signature

    Example:
        class MyMiddleware:
            def __init__(self, app: ASGIApp, option: str = "default") -> None:
                self.app = app
                self.option = option

            async def __call__(
                self, scope: Scope, receive: Receive, send: Send
            ) -> None:
                # Pre-processing
                await self.app(scope, receive, send)
                # Post-processing
    """

    def __init__(self, app: ASGIApp, **kwargs: Any) -> None:
        """Initialize middleware with ASGI app and options.

        Args:
            app: The ASGI application to wrap.
            **kwargs: Middleware-specific options.
        """
        ...

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Process an ASGI request.

        Args:
            scope: ASGI connection scope.
            receive: ASGI receive callable.
            send: ASGI send callable.
        """
        ...


__all__ = ["MiddlewareProtocol"]
