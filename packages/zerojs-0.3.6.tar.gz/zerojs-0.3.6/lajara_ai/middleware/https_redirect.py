"""HTTPS redirect middleware for ZeroJS."""

from starlette.middleware.httpsredirect import (
    HTTPSRedirectMiddleware as _HTTPSRedirectMiddleware,
)


class HTTPSRedirectMiddleware(_HTTPSRedirectMiddleware):
    """HTTPS redirect middleware.

    Redirects HTTP requests to HTTPS.
    """

    pass


__all__ = [
    "HTTPSRedirectMiddleware",
]
