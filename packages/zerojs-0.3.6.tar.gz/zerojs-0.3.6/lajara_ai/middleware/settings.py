"""Settings middleware for exposing settings on request.state."""

from __future__ import annotations

from typing import TYPE_CHECKING

from starlette.types import ASGIApp, Receive, Scope, Send

if TYPE_CHECKING:
    from lajara_ai.settings.model import Settings


class SettingsMiddleware:
    """ASGI middleware that attaches read-only settings to request state.

    Makes settings accessible via ``request.state.settings`` in handlers
    and downstream middleware.  The :class:`Settings` model is frozen, so
    consumers cannot mutate it.
    """

    def __init__(self, app: ASGIApp, settings: Settings) -> None:
        self.app = app
        self._settings = settings

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] in ("http", "websocket"):
            scope.setdefault("state", {})
            scope["state"]["settings"] = self._settings

        await self.app(scope, receive, send)
