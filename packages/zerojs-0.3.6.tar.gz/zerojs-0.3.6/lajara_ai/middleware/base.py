"""Base middleware class for ZeroJS."""

from starlette.middleware.base import BaseHTTPMiddleware as _BaseHTTPMiddleware


class BaseMiddleware(_BaseHTTPMiddleware):
    """Base HTTP middleware class.

    Inherit from this class to create custom middleware.

    Example:
        from lajara_ai.middleware import BaseMiddleware

        class TimingMiddleware(BaseMiddleware):
            async def dispatch(self, request, call_next):
                start = time.time()
                response = await call_next(request)
                duration = time.time() - start
                response.headers["X-Process-Time"] = str(duration)
                return response
    """

    pass


__all__ = [
    "BaseMiddleware",
]
