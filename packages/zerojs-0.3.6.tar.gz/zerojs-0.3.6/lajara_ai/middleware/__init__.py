"""ZeroJS middleware - re-exports for convenience."""

from lajara_ai.session.middleware import SessionMiddleware

from .base import BaseMiddleware
from .compression import GZipMiddleware
from .cors import CORSMiddleware
from .https_redirect import HTTPSRedirectMiddleware
from .protocols import MiddlewareProtocol
from .rate_limit import Limiter, RateLimitMiddleware
from .security_headers import SecurityHeadersMiddleware
from .settings import SettingsMiddleware
from .trusted_host import TrustedHostMiddleware

__all__ = [
    # Base
    "BaseMiddleware",
    "MiddlewareProtocol",
    # Session
    "SessionMiddleware",
    # Compression
    "GZipMiddleware",
    # CORS
    "CORSMiddleware",
    # Rate limiting
    "Limiter",
    "RateLimitMiddleware",
    # Security
    "HTTPSRedirectMiddleware",
    "TrustedHostMiddleware",
    "SecurityHeadersMiddleware",
    # Settings
    "SettingsMiddleware",
]
