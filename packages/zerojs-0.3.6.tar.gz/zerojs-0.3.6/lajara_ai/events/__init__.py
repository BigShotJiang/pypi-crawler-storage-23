"""ZeroJS event system.

An extensible, string-based event system with a central registry
for collision prevention. Applications and plugins register events
under their own namespaces and emit them through an event emitter.

Example:
    from lajara_ai.events import Event, register_event

    # Use built-in events
    emitter.on(Event.LOGIN_SUCCESS)

    # Register custom events
    MY_EVENT = register_event("myplugin.user_upgraded")
"""

from .constants import Event
from .null import NullEventEmitter
from .protocols import EventEmitterProtocol, EventListener
from .registry import register_event, registered_events

__all__ = [
    "Event",
    "EventEmitterProtocol",
    "EventListener",
    "NullEventEmitter",
    "register_event",
    "registered_events",
]
