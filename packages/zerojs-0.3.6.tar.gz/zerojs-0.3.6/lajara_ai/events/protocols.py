"""Event system protocols.

Defines the interfaces for event listeners and event emitters,
allowing applications to type-hint against abstractions rather
than concrete implementations.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class EventListener(Protocol):
    """Protocol for event listener functions.

    Event listeners are async callables that receive event data
    as keyword arguments.

    Example:
        async def my_listener(**kwargs: Any) -> None:
            print(f"Event received: {kwargs}")
    """

    async def __call__(self, **kwargs: Any) -> None:
        """Handle an event.

        Args:
            **kwargs: Event data as keyword arguments.
        """
        ...


@runtime_checkable
class EventEmitterProtocol(Protocol):
    """Protocol for event emitters.

    Allows code to depend on the emitter interface without
    coupling to a concrete implementation.
    """

    def on(
        self,
        event: str,
        critical: bool = False,
    ) -> Callable[[Callable[..., Awaitable[None]]], Callable[..., Awaitable[None]]]:
        """Decorator to register an event listener.

        Args:
            event: The event to listen for.
            critical: If True, errors in this listener will be re-raised.

        Returns:
            Decorator that registers the function as a listener.
        """
        ...

    def add_listener(
        self,
        event: str,
        fn: Callable[..., Awaitable[None]],
        critical: bool = False,
    ) -> None:
        """Register a listener programmatically.

        Args:
            event: The event to listen for.
            fn: Async function to call when event is emitted.
            critical: If True, errors in this listener will be re-raised.
        """
        ...

    def remove_listener(
        self,
        event: str,
        fn: Callable[..., Awaitable[None]],
    ) -> bool:
        """Remove a listener.

        Args:
            event: The event the listener was registered for.
            fn: The listener function to remove.

        Returns:
            True if listener was found and removed, False otherwise.
        """
        ...

    def clear_listeners(self, event: str | None = None) -> None:
        """Clear listeners.

        Args:
            event: If provided, clear only listeners for this event.
                If None, clear all listeners.
        """
        ...

    async def emit(self, event: str, **data: Any) -> None:
        """Emit an event to all registered listeners.

        Args:
            event: The event to emit.
            **data: Event data passed to listeners as keyword arguments.
        """
        ...

    def listener_count(self, event: str | None = None) -> int:
        """Get the number of listeners.

        Args:
            event: If provided, count only listeners for this event.
                If None, count all listeners across all events.

        Returns:
            Number of registered listeners.
        """
        ...
