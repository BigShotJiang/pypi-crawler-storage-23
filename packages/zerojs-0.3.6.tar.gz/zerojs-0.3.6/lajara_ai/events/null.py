"""Null Object implementation of EventEmitterProtocol.

Provides a no-op emitter so consumers can call emit() unconditionally
without checking for None, reducing cognitive complexity across modules.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any


class NullEventEmitter:
    """Event emitter that silently discards all operations.

    Implements the Null Object Pattern for EventEmitterProtocol,
    allowing code to call emit() without guarding against None.

    Example:
        emitter = NullEventEmitter()
        await emitter.emit("auth.login_success", user=user)  # no-op
    """

    def on(
        self,
        event: str,
        critical: bool = False,
    ) -> Callable[[Callable[..., Awaitable[None]]], Callable[..., Awaitable[None]]]:
        """Return a no-op decorator.

        Args:
            event: The event to listen for.
            critical: Ignored.

        Returns:
            Decorator that returns the function unchanged.
        """

        def decorator(fn: Callable[..., Awaitable[None]]) -> Callable[..., Awaitable[None]]:
            return fn

        return decorator

    def add_listener(
        self,
        event: str,
        fn: Callable[..., Awaitable[None]],
        critical: bool = False,
    ) -> None:
        """No-op listener registration.

        Args:
            event: Ignored.
            fn: Ignored.
            critical: Ignored.
        """

    def remove_listener(
        self,
        event: str,
        fn: Callable[..., Awaitable[None]],
    ) -> bool:
        """No-op listener removal.

        Args:
            event: Ignored.
            fn: Ignored.

        Returns:
            Always False.
        """
        return False

    def clear_listeners(self, event: str | None = None) -> None:
        """No-op listener clearing.

        Args:
            event: Ignored.
        """

    async def emit(self, event: str, **data: Any) -> None:
        """No-op event emission.

        Args:
            event: Ignored.
            **data: Ignored.
        """

    def listener_count(self, event: str | None = None) -> int:
        """Return zero listeners.

        Args:
            event: Ignored.

        Returns:
            Always 0.
        """
        return 0
