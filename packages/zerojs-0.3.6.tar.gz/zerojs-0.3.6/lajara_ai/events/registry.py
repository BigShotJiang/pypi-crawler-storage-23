"""Event registry for collision-safe event registration.

Provides a central registry where applications and plugins
register string-based event names under their own namespaces.

Example:
    from lajara_ai.events import register_event

    MY_EVENT = register_event("myplugin.user_upgraded")
"""

from __future__ import annotations

import re

_EVENT_NAME_RE = re.compile(r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$")

_registry: set[str] = set()


def register_event(name: str) -> str:
    """Register an event name in the global registry.

    Validates that the name follows the ``namespace.event_name`` format
    and prevents duplicate registrations.

    Args:
        name: Event name (e.g., ``"zerojs.auth.login_success"``).

    Returns:
        The registered event name.

    Raises:
        ValueError: If name format is invalid or already registered.

    Example:
        MY_EVENT = register_event("myplugin.user_upgraded")
    """
    if not _EVENT_NAME_RE.match(name):
        raise ValueError(
            f"Invalid event name: {name!r}. Must match 'namespace.event_name' (lowercase, dots, underscores)."
        )
    if name in _registry:
        raise ValueError(f"Event already registered: {name!r}")
    _registry.add(name)
    return name


def registered_events() -> frozenset[str]:
    """Return all registered event names.

    Returns:
        Frozen set of all registered event name strings.
    """
    return frozenset(_registry)


def _reset_registry() -> None:
    """Reset the event registry. For testing only."""
    _registry.clear()
