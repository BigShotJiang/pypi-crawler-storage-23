"""System-wide event constants.

Defines the built-in event names for ZeroJS core modules.
Applications and plugins register their own events under
separate namespaces using :func:`register_event`.

Example:
    from lajara_ai.events import Event

    if event_name == Event.LOGIN_SUCCESS:
        print("User logged in!")
"""

from __future__ import annotations

from .registry import register_event


class Event:
    """Built-in event constants for ZeroJS.

    All authentication events use the ``zerojs.auth.`` namespace.
    """

    # Login / Logout
    LOGIN_SUCCESS: str = register_event("zerojs.auth.login_success")
    LOGIN_FAILED: str = register_event("zerojs.auth.login_failed")
    LOGOUT: str = register_event("zerojs.auth.logout")

    # Password
    PASSWORD_CHANGED: str = register_event("zerojs.auth.password_changed")
    PASSWORD_RESET_REQUESTED: str = register_event("zerojs.auth.password_reset_requested")
    PASSWORD_RESET_COMPLETED: str = register_event("zerojs.auth.password_reset_completed")

    # Session
    SESSION_EXPIRED: str = register_event("zerojs.auth.session_expired")
    SESSION_ROTATED: str = register_event("zerojs.auth.session_rotated")

    # MFA
    MFA_ENABLED: str = register_event("zerojs.auth.mfa_enabled")
    MFA_DISABLED: str = register_event("zerojs.auth.mfa_disabled")
    MFA_CHALLENGE_SENT: str = register_event("zerojs.auth.mfa_challenge_sent")
    MFA_CHALLENGE_PASSED: str = register_event("zerojs.auth.mfa_challenge_passed")
    MFA_CHALLENGE_FAILED: str = register_event("zerojs.auth.mfa_challenge_failed")

    # Authorization
    PERMISSION_DENIED: str = register_event("zerojs.auth.permission_denied")
