"""Testing utilities for the events module.

Provides mock implementations for event protocols.
"""

from __future__ import annotations

from typing import Any

from .protocols import EventEmitterProtocol, EventListener


class MockEventListener:
    """Mock event listener that records calls for testing.

    Example:
        listener = MockEventListener()
        emitter.add_listener(Event.LOGIN_SUCCESS, listener)
        await emitter.emit(Event.LOGIN_SUCCESS, user=user)
        assert len(listener.calls) == 1
    """

    def __init__(self) -> None:
        """Initialize with empty call list."""
        self._calls: list[dict[str, Any]] = []

    async def __call__(self, **kwargs: Any) -> None:
        """Record event call.

        Args:
            **kwargs: Event data as keyword arguments.
        """
        self._calls.append(kwargs)

    @property
    def calls(self) -> list[dict[str, Any]]:
        """Read-only access to recorded calls.

        Returns:
            List of event kwargs dicts for verification in tests.
        """
        return list(self._calls)

    def reset(self) -> None:
        """Clear recorded calls."""
        self._calls.clear()


class MockEventEmitter:
    """Mock event emitter that records emitted events for testing.

    Example:
        emitter = MockEventEmitter()
        await emitter.emit(Event.LOGIN_SUCCESS, user=user)
        assert emitter.events[0] == (Event.LOGIN_SUCCESS, {"user": user})
    """

    def __init__(self) -> None:
        """Initialize with empty events and listeners."""
        self.events: list[tuple[str, dict[str, Any]]] = []
        self._listeners: dict[str, list[tuple[Any, bool]]] = {}

    def on(
        self,
        event: str,
        critical: bool = False,
    ) -> Any:
        """Decorator to register a listener.

        Args:
            event: The event to listen for.
            critical: If True, errors will be re-raised.

        Returns:
            Decorator that registers the function.
        """

        def decorator(fn: Any) -> Any:
            self.add_listener(event, fn, critical=critical)
            return fn

        return decorator

    def add_listener(
        self,
        event: str,
        fn: Any,
        critical: bool = False,
    ) -> None:
        """Register a listener.

        Args:
            event: The event to listen for.
            fn: Async function to call when event is emitted.
            critical: If True, errors will be re-raised.
        """
        self._listeners.setdefault(event, []).append((fn, critical))

    def remove_listener(self, event: str, fn: Any) -> bool:
        """Remove a listener.

        Args:
            event: The event the listener was registered for.
            fn: The listener function to remove.

        Returns:
            True if found and removed, False otherwise.
        """
        if event not in self._listeners:
            return False
        for i, (listener_fn, _) in enumerate(self._listeners[event]):
            if listener_fn is fn:
                self._listeners[event].pop(i)
                return True
        return False

    def clear_listeners(self, event: str | None = None) -> None:
        """Clear listeners.

        Args:
            event: If provided, clear only for this event. If None, clear all.
        """
        if event is None:
            self._listeners.clear()
        elif event in self._listeners:
            self._listeners[event].clear()

    async def emit(self, event: str, **data: Any) -> None:
        """Record event and call registered listeners.

        Args:
            event: The event to emit.
            **data: Event data passed to listeners.

        Raises:
            Exception: If a critical listener fails.
        """
        self.events.append((event, data))
        for fn, critical in self._listeners.get(event, []):
            try:
                await fn(**data)
            except Exception:
                if critical:
                    raise

    def listener_count(self, event: str | None = None) -> int:
        """Get the number of listeners.

        Args:
            event: If provided, count only listeners for this event.
                If None, count all listeners across all events.

        Returns:
            Number of registered listeners.
        """
        if event is None:
            return sum(len(listeners) for listeners in self._listeners.values())
        return len(self._listeners.get(event, []))


def _assert_protocol_compliance() -> None:
    """Static type assertion to verify mocks implement their protocols.

    This function is NEVER called at runtime. It exists solely for mypy
    static analysis.
    """
    from .null import NullEventEmitter

    _event_listener: EventListener = MockEventListener()
    _event_emitter: EventEmitterProtocol = MockEventEmitter()
    _null_emitter: EventEmitterProtocol = NullEventEmitter()
