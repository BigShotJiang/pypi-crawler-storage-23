"""File-based routing utilities."""

from .core import (
    STATIC_TEXT_EXTENSIONS,
    SUPPORTED_EXTENSIONS,
    TEMPLATE_EXTENSIONS,
    Route,
    file_to_route,
    scan_pages,
)

__all__ = [
    "STATIC_TEXT_EXTENSIONS",
    "SUPPORTED_EXTENSIONS",
    "TEMPLATE_EXTENSIONS",
    "Route",
    "file_to_route",
    "scan_pages",
]
