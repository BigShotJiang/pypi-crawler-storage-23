"""Tests for CLI commands (Click runner)."""

import json

from click.testing import CliRunner

from greatsky_internal_metaflow import config
from greatsky_internal_metaflow.cli import cli


def _setup_gsm_dir(tmp_path, monkeypatch):
    """Set up a temporary GSM directory and patch resolution to use it."""
    gsm_dir = tmp_path / ".greatsky_gsm"
    gsm_dir.mkdir()
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.setattr(config, "write_target_dir", lambda: gsm_dir)
    return gsm_dir


def test_logout_when_not_logged_in(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: None)

    runner = CliRunner()
    result = runner.invoke(cli, ["logout"])
    assert result.exit_code == 0
    assert "Already logged out" in result.output


def test_status_not_logged_in(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: None)

    runner = CliRunner()
    result = runner.invoke(cli, ["status"])
    assert result.exit_code == 0
    assert "Not logged in" in result.output


def test_status_logged_in(tmp_path, monkeypatch):
    _setup_gsm_dir(tmp_path, monkeypatch)

    config.write_credentials(
        api_key="gsk_test",
        expires_at="2026-03-05T00:00:00Z",
        github_user="wade",
        name="Wade",
        access_type="org_member",
    )
    config.write_config(
        {
            "GSM_AUTH_API": "https://auth.gr8sky.dev",
            "METAFLOW_SERVICE_AUTH_KEY": "gsk_test",
        }
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["status"])
    assert result.exit_code == 0
    assert "wade" in result.output
    assert "org member" in result.output


def test_validate_not_logged_in(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: None)

    runner = CliRunner()
    result = runner.invoke(cli, ["validate"])
    assert result.exit_code == 1
    assert "Not logged in" in result.output


def test_version():
    runner = CliRunner()
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    assert "version" in result.output


# ── refresh ─────────────────────────────────────────────────────────────────


def test_refresh_not_logged_in(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: None)

    runner = CliRunner()
    result = runner.invoke(cli, ["refresh"])
    assert result.exit_code == 1
    assert "Not logged in" in result.output


def test_refresh_success(tmp_path, monkeypatch):
    gsm_dir = _setup_gsm_dir(tmp_path, monkeypatch)

    config.write_config(
        {
            "GSM_AUTH_API": "https://auth.example.com",
            "METAFLOW_SERVICE_AUTH_KEY": "gsk_test",
        }
    )

    remote_payload = {"metaflow_config": {"METAFLOW_DEFAULT_DATASTORE": "s3"}}

    class FakeResponse:
        status_code = 200

        def raise_for_status(self):
            pass

        def json(self):
            return remote_payload

    import httpx

    monkeypatch.setattr(httpx, "get", lambda url, **kw: FakeResponse())

    runner = CliRunner()
    result = runner.invoke(cli, ["refresh"])
    assert result.exit_code == 0
    assert "refreshed" in result.output

    cache = json.loads((gsm_dir / "config_cache.json").read_text())
    assert cache["METAFLOW_DEFAULT_DATASTORE"] == "s3"


# ── cleanup ─────────────────────────────────────────────────────────────────


def test_cleanup_removes_legacy_metaflow_config(tmp_path, monkeypatch):
    _setup_gsm_dir(tmp_path, monkeypatch)

    mf_dir = tmp_path / ".metaflowconfig"
    mf_dir.mkdir()
    (mf_dir / "config.json").write_text(json.dumps({"GSM_AUTH_API": "https://old.example.com"}))

    from pathlib import Path

    monkeypatch.setattr(Path, "home", lambda: tmp_path)

    runner = CliRunner()
    result = runner.invoke(cli, ["cleanup"])
    assert result.exit_code == 0
    assert "Removed" in result.output
    assert not (mf_dir / "config.json").exists()


def test_cleanup_nothing_to_do(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: None)

    from pathlib import Path

    monkeypatch.setattr(Path, "home", lambda: tmp_path)

    runner = CliRunner()
    result = runner.invoke(cli, ["cleanup"])
    assert result.exit_code == 0
    assert "No legacy" in result.output


# ── login --scope ───────────────────────────────────────────────────────────


def test_login_scope_global_option_is_accepted():
    """Verify the --scope flag is recognized by Click (does not test full login flow)."""
    runner = CliRunner()
    result = runner.invoke(cli, ["login", "--scope", "global", "--help"])
    assert result.exit_code == 0


def test_login_scope_invalid_choice():
    runner = CliRunner()
    result = runner.invoke(cli, ["login", "--scope", "invalid"])
    assert result.exit_code != 0
    assert "Invalid value" in result.output


# ── revoke ──────────────────────────────────────────────────────────────────


def test_revoke_not_logged_in(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: None)

    runner = CliRunner()
    result = runner.invoke(cli, ["revoke"])
    assert result.exit_code == 1
    assert "Not logged in" in result.output


def test_revoke_success(tmp_path, monkeypatch):
    _setup_gsm_dir(tmp_path, monkeypatch)

    config.write_credentials(
        api_key="gsk_test",
        expires_at="2026-03-05T00:00:00Z",
        github_user="wade",
        name="Wade",
        access_type="org_member",
    )

    class FakeResponse:
        status_code = 200

        def json(self):
            return {"message": "API key revoked"}

    import httpx

    monkeypatch.setattr(httpx, "delete", lambda url, **kw: FakeResponse())

    runner = CliRunner()
    result = runner.invoke(cli, ["revoke"])
    assert result.exit_code == 0
    assert "revoked" in result.output


# ── admin revoke-keys ───────────────────────────────────────────────────────


def test_admin_revoke_keys_not_logged_in(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: None)

    runner = CliRunner()
    result = runner.invoke(cli, ["admin", "revoke-keys", "someuser"])
    assert result.exit_code == 1
    assert "Not logged in" in result.output


# ── service-key ──────────────────────────────────────────────────────────────


def test_service_key_create_not_logged_in(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: None)

    runner = CliRunner()
    result = runner.invoke(cli, ["service-key", "create", "test-key"])
    assert result.exit_code == 1
    assert "Not logged in" in result.output


def test_service_key_create_success(tmp_path, monkeypatch):
    _setup_gsm_dir(tmp_path, monkeypatch)

    config.write_credentials(
        api_key="gsk_test",
        expires_at="2026-03-05T00:00:00Z",
        github_user="wade",
        name="Wade",
        access_type="org_member",
    )
    config.write_config(
        {
            "GSM_AUTH_API": "https://auth.gr8sky.dev",
            "METAFLOW_SERVICE_AUTH_KEY": "gsk_test",
        }
    )

    class FakeResponse:
        status_code = 201

        def json(self):
            return {
                "api_key": "gsk_svc_abc",
                "label": "test-key",
                "expires_at": "2026-04-01T00:00:00Z",
                "created_by": "wade",
            }

    import httpx

    monkeypatch.setattr(httpx, "post", lambda url, **kw: FakeResponse())

    runner = CliRunner()
    result = runner.invoke(cli, ["service-key", "create", "test-key"])
    assert result.exit_code == 0
    assert "gsk_svc_abc" in result.output
    assert "cannot be retrieved again" in result.output


def test_service_key_create_duplicate(tmp_path, monkeypatch):
    _setup_gsm_dir(tmp_path, monkeypatch)

    config.write_credentials(
        api_key="gsk_test",
        expires_at="2026-03-05T00:00:00Z",
        github_user="wade",
        name="Wade",
        access_type="org_member",
    )

    class FakeResponse:
        status_code = 409

        def json(self):
            return {"error": "duplicate"}

    import httpx

    monkeypatch.setattr(httpx, "post", lambda url, **kw: FakeResponse())

    runner = CliRunner()
    result = runner.invoke(cli, ["service-key", "create", "test-key"])
    assert result.exit_code == 1
    assert "already exists" in result.output


def test_service_key_create_max_cap(tmp_path, monkeypatch):
    _setup_gsm_dir(tmp_path, monkeypatch)

    config.write_credentials(
        api_key="gsk_test",
        expires_at="2026-03-05T00:00:00Z",
        github_user="wade",
        name="Wade",
        access_type="org_member",
    )

    class FakeResponse:
        status_code = 429

        def json(self):
            return {"error": "too many keys"}

    import httpx

    monkeypatch.setattr(httpx, "post", lambda url, **kw: FakeResponse())

    runner = CliRunner()
    result = runner.invoke(cli, ["service-key", "create", "test-key"])
    assert result.exit_code == 1
    assert "Too many active service keys" in result.output


def test_service_key_list(tmp_path, monkeypatch):
    _setup_gsm_dir(tmp_path, monkeypatch)

    config.write_credentials(
        api_key="gsk_test",
        expires_at="2026-03-05T00:00:00Z",
        github_user="wade",
        name="Wade",
        access_type="org_member",
    )

    class FakeResponse:
        status_code = 200

        def json(self):
            return {
                "service_keys": [
                    {
                        "label": "my-key",
                        "expires_at": "2026-04-01",
                        "ip": "10.0.0.0/24",
                        "status": "active",
                    }
                ]
            }

    import httpx

    monkeypatch.setattr(httpx, "get", lambda url, **kw: FakeResponse())

    runner = CliRunner()
    result = runner.invoke(cli, ["service-key", "list"])
    assert result.exit_code == 0
    assert "my-key" in result.output


def test_service_key_revoke_success(tmp_path, monkeypatch):
    _setup_gsm_dir(tmp_path, monkeypatch)

    config.write_credentials(
        api_key="gsk_test",
        expires_at="2026-03-05T00:00:00Z",
        github_user="wade",
        name="Wade",
        access_type="org_member",
    )

    class FakeResponse:
        status_code = 200

        def json(self):
            return {"message": "revoked"}

    import httpx

    monkeypatch.setattr(httpx, "request", lambda method, url, **kw: FakeResponse())

    runner = CliRunner()
    result = runner.invoke(cli, ["service-key", "revoke", "test-key"])
    assert result.exit_code == 0
    assert "revoked" in result.output


# ── admin list-service-keys ──────────────────────────────────────────────────


def test_admin_list_service_keys_not_logged_in(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: None)

    runner = CliRunner()
    result = runner.invoke(cli, ["admin", "list-service-keys"])
    assert result.exit_code == 1
    assert "Not logged in" in result.output


def test_admin_list_service_keys_success(tmp_path, monkeypatch):
    _setup_gsm_dir(tmp_path, monkeypatch)

    config.write_credentials(
        api_key="gsk_test",
        expires_at="2026-03-05T00:00:00Z",
        github_user="wade",
        name="Wade",
        access_type="org_member",
    )

    class FakeResponse:
        status_code = 200

        def json(self):
            return {
                "service_keys": [
                    {
                        "label": "deploy-key",
                        "created_by": "wade",
                        "expires_at": "2026-04-01",
                        "ip": "10.0.0.0/24",
                        "status": "active",
                    }
                ]
            }

    import httpx

    monkeypatch.setattr(httpx, "get", lambda url, **kw: FakeResponse())

    runner = CliRunner()
    result = runner.invoke(cli, ["admin", "list-service-keys"])
    assert result.exit_code == 0
    assert "wade" in result.output
    assert "deploy-key" in result.output


# ── login kubeconfig (direct kubeconfig writing) ─────────────────────────────


def _make_login_mocks(monkeypatch, creds):
    """Wire up auth mocks for a full login flow."""
    from greatsky_internal_metaflow import auth

    monkeypatch.setattr(
        auth,
        "fetch_bootstrap_config",
        lambda: {
            "github_client_id": "test-id",
            "auth_url": "https://auth.test",
        },
    )
    monkeypatch.setattr(
        auth,
        "request_device_code",
        lambda _: auth.DeviceCode(
            device_code="dc",
            user_code="uc",
            verification_uri="https://github.com/login/device",
            expires_in=900,
            interval=5,
        ),
    )
    monkeypatch.setattr(auth, "poll_for_token", lambda *a, **k: "ghp_fake")
    monkeypatch.setattr(auth, "exchange_token", lambda _: creds)


def test_login_writes_kubeconfig_to_gsm_dir(tmp_path, monkeypatch):
    """When token-exchange returns EKS details, login writes kubeconfig inside the GSM directory."""
    gsm_dir = _setup_gsm_dir(tmp_path, monkeypatch)
    monkeypatch.setattr(config, "GLOBAL_DIR", gsm_dir)

    from greatsky_internal_metaflow import auth

    creds = auth.PlatformCredentials(
        api_key="gsk_test",
        expires_at="2026-03-05T00:00:00Z",
        github_user="alice",
        name="Alice",
        access_type="org_member",
        metaflow_config={},
        eks_cluster_name="greatsky-mgmt-cluster",
        eks_region="us-east-1",
        eks_endpoint="https://ABCDEF.eks.us-east-1.amazonaws.com",
        eks_ca_cert="LS0tLS1CRUdJTi...",
    )
    _make_login_mocks(monkeypatch, creds)

    runner = CliRunner()
    result = runner.invoke(cli, ["login", "--scope", "global"], input="\n")
    assert result.exit_code == 0
    assert "Welcome" in result.output
    assert "kubectl configured" in result.output

    import yaml

    kubeconfig_path = gsm_dir / "kubeconfig"
    assert kubeconfig_path.exists()
    kc = yaml.safe_load(kubeconfig_path.read_text())

    assert kc["current-context"] == "greatsky-mgmt-cluster"
    assert len(kc["clusters"]) == 1
    assert kc["clusters"][0]["cluster"]["server"] == "https://ABCDEF.eks.us-east-1.amazonaws.com"
    assert kc["clusters"][0]["cluster"]["certificate-authority-data"] == "LS0tLS1CRUdJTi..."

    assert len(kc["users"]) == 1
    exec_cfg = kc["users"][0]["user"]["exec"]
    assert exec_cfg["apiVersion"] == "client.authentication.k8s.io/v1beta1"
    assert exec_cfg["args"] == ["get-kube-token"]

    # ~/.kube/config must NOT have been touched
    assert not (tmp_path / ".kube" / "config").exists()


def test_login_skips_kubeconfig_when_creds_lack_eks_endpoint(tmp_path, monkeypatch):
    """When token-exchange does not return EKS endpoint/ca, login skips kubeconfig."""
    gsm_dir = _setup_gsm_dir(tmp_path, monkeypatch)
    monkeypatch.setattr(config, "GLOBAL_DIR", gsm_dir)

    from greatsky_internal_metaflow import auth

    creds = auth.PlatformCredentials(
        api_key="gsk_test",
        expires_at="2026-03-05T00:00:00Z",
        github_user="alice",
        name="Alice",
        access_type="org_member",
        metaflow_config={},
        eks_cluster_name="",
        eks_region="",
        eks_endpoint="",
        eks_ca_cert="",
    )
    _make_login_mocks(monkeypatch, creds)

    runner = CliRunner()
    result = runner.invoke(cli, ["login", "--scope", "global"], input="\n")
    assert result.exit_code == 0
    assert "Welcome" in result.output
    assert "kubectl configured" not in result.output
    assert not (gsm_dir / "kubeconfig").exists()


# ── get-kube-token ──────────────────────────────────────────────────────────


def test_get_kube_token_success(tmp_path, monkeypatch):
    """get-kube-token fetches a token from the auth API and outputs ExecCredential JSON."""
    _setup_gsm_dir(tmp_path, monkeypatch)

    config.write_credentials(
        api_key="gsk_test",
        expires_at="2026-03-05T00:00:00Z",
        github_user="alice",
        name="Alice",
        access_type="org_member",
    )
    config.write_config(
        {
            "GSM_AUTH_API": "https://auth.test",
            "METAFLOW_SERVICE_AUTH_KEY": "gsk_test",
        }
    )

    exec_cred = {
        "kind": "ExecCredential",
        "apiVersion": "client.authentication.k8s.io/v1beta1",
        "status": {
            "token": "k8s-aws-v1.aHR0cHM6Ly9zdHM...",
            "expirationTimestamp": "2026-03-01T00:14:00Z",
        },
    }

    class FakeResponse:
        status_code = 200

        def raise_for_status(self):
            pass

        def json(self):
            return exec_cred

    import httpx

    monkeypatch.setattr(httpx, "get", lambda url, **kw: FakeResponse())

    runner = CliRunner()
    result = runner.invoke(cli, ["get-kube-token"])
    assert result.exit_code == 0
    parsed = json.loads(result.output)
    assert parsed["kind"] == "ExecCredential"
    assert parsed["status"]["token"].startswith("k8s-aws-v1.")


def test_get_kube_token_not_logged_in(tmp_path, monkeypatch):
    """get-kube-token exits 1 when not logged in."""
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: None)

    runner = CliRunner()
    result = runner.invoke(cli, ["get-kube-token"])
    assert result.exit_code == 1


# ── clear_all removes kubeconfig ─────────────────────────────────────────────


def test_clear_all_removes_kubeconfig(tmp_path, monkeypatch):
    """gsm logout should remove the kubeconfig file alongside other config."""
    gsm_dir = _setup_gsm_dir(tmp_path, monkeypatch)

    config.write_config({"GSM_AUTH_API": "https://auth.test", "METAFLOW_SERVICE_AUTH_KEY": "k"})
    config.write_credentials(
        api_key="gsk_test",
        expires_at="2026-03-05",
        github_user="a",
        name="A",
        access_type="org_member",
    )
    (gsm_dir / "kubeconfig").write_text("apiVersion: v1\nkind: Config\n")

    assert (gsm_dir / "kubeconfig").exists()
    config.clear_all()
    assert not (gsm_dir / "kubeconfig").exists()
    assert not (gsm_dir / "config.json").exists()
    assert not (gsm_dir / "credentials.json").exists()


# ── init_config sets KUBECONFIG ──────────────────────────────────────────────


def test_init_config_sets_kubeconfig_env(tmp_path, monkeypatch):
    """init_config() should set KUBECONFIG to the scoped kubeconfig file."""
    gsm_dir = tmp_path / ".greatsky_gsm"
    gsm_dir.mkdir()

    from greatsky_internal_metaflow import config as gsm_config

    monkeypatch.setattr(gsm_config, "resolve_gsm_dir", lambda: gsm_dir)

    gsm_config.write_config(
        {"GSM_AUTH_API": "https://auth.test", "METAFLOW_SERVICE_AUTH_KEY": "gsk_test"},
        target=gsm_dir,
    )
    gsm_config.write_credentials(
        api_key="gsk_test",
        expires_at="2026-03-05",
        github_user="a",
        name="A",
        access_type="org_member",
        target=gsm_dir,
    )
    (gsm_dir / "kubeconfig").write_text("apiVersion: v1\nkind: Config\n")

    monkeypatch.delenv("KUBECONFIG", raising=False)
    monkeypatch.delenv("__GSM_CONFIG_RESOLVED__", raising=False)

    from metaflow_extensions.greatsky.remote_config import _inject_kubeconfig

    _inject_kubeconfig(gsm_dir)

    import os

    assert os.environ.get("KUBECONFIG") == str(gsm_dir / "kubeconfig")


def test_init_config_respects_existing_kubeconfig_env(tmp_path, monkeypatch):
    """init_config() should NOT overwrite an existing KUBECONFIG env var."""
    gsm_dir = tmp_path / ".greatsky_gsm"
    gsm_dir.mkdir()
    (gsm_dir / "kubeconfig").write_text("apiVersion: v1\nkind: Config\n")

    monkeypatch.setenv("KUBECONFIG", "/custom/path/kubeconfig")

    from metaflow_extensions.greatsky.remote_config import _inject_kubeconfig

    _inject_kubeconfig(gsm_dir)

    import os

    assert os.environ["KUBECONFIG"] == "/custom/path/kubeconfig"
