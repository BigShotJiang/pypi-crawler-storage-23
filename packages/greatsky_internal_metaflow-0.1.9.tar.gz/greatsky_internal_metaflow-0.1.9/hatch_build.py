"""Custom hatch build hook to inject top_level.txt into the wheel dist-info.

Metaflow's extension discovery (extension_support.py) gates on
dist.read_text("top_level.txt") containing "metaflow_extensions".
Hatchling does not generate this file (it's a legacy setuptools artifact),
so without this hook the greatsky extension is silently skipped.
"""

import zipfile

from hatchling.builders.hooks.plugin.interface import BuildHookInterface


class CustomBuildHook(BuildHookInterface):
    PLUGIN_NAME = "custom"

    def finalize(self, version, build_data, artifact_path):
        if self.target_name != "wheel":
            return
        with zipfile.ZipFile(artifact_path, "a") as whl:
            dist_info = next(
                (n.rsplit("/", 1)[0] for n in whl.namelist() if n.endswith(".dist-info/METADATA")),
                None,
            )
            if dist_info:
                whl.writestr(f"{dist_info}/top_level.txt", "metaflow_extensions\n")
