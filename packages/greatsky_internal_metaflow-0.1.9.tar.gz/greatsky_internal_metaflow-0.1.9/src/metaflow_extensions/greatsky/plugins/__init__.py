"""GreatSky Metaflow plugins extension.

This module is loaded by Metaflow's plugin discovery (process_plugins ->
get_modules("plugins")) during `import metaflow`, BEFORE any flow file
is parsed. This is the correct time to patch KubernetesDecorator.defaults
so that device/vram/pool kwargs are accepted by @kubernetes(...).
"""

from metaflow_extensions.greatsky.compute_router import _apply_monkey_patch

_apply_monkey_patch()
del _apply_monkey_patch
