"""Hugging Face Hub integration utilities.

Provides helpers for pushing/pulling models and datasets between the
GreatSky Metaflow platform (S3) and Hugging Face Hub, with automatic
authentication via the platform-injected HF_TOKEN.

Dataset helpers return DatasetVersion objects that can be stored as
Metaflow artifacts for lineage tracking.
"""

from __future__ import annotations

import os
import tempfile
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, List, Optional, Tuple

# ---------------------------------------------------------------------------
# DatasetVersion — lineage tracking for HF datasets
# ---------------------------------------------------------------------------


@dataclass
class DatasetVersion:
    """Captures the exact version of an HF dataset used in or produced by a flow.

    Store as a Metaflow artifact (``self.dataset_version = version``) to create
    a lineage trail: dataset commit -> flow run -> model.
    """

    repo_id: str
    commit_sha: str = ""
    revision: str = "main"
    split: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    flow_name: str = ""
    run_id: str = ""

    def __post_init__(self) -> None:
        if not self.flow_name or not self.run_id:
            self._try_fill_metaflow_context()

    def _try_fill_metaflow_context(self) -> None:
        try:
            from metaflow import current

            if current.is_running_flow:
                self.flow_name = self.flow_name or current.flow_name
                self.run_id = self.run_id or current.run_id
        except Exception:
            pass

    def to_dict(self) -> dict:
        return asdict(self)

    def __repr__(self) -> str:
        sha_short = self.commit_sha[:8] if self.commit_sha else "unknown"
        parts = [f"{self.repo_id}@{sha_short}"]
        if self.split:
            parts.append(f"split={self.split}")
        if self.run_id:
            parts.append(f"run={self.flow_name}/{self.run_id}")
        return f"DatasetVersion({', '.join(parts)})"


def get_hf_token() -> str:
    """Resolve the HF token from environment or platform config cache."""
    token = os.environ.get("HF_TOKEN", "")
    if token:
        return token

    from greatsky_internal_metaflow.config import read_config_cache

    cache = read_config_cache()
    if cache and cache.get("HF_TOKEN"):
        return cache["HF_TOKEN"]

    raise RuntimeError(
        "HF_TOKEN not found. Either:\n"
        "  1. Set HF_TOKEN environment variable\n"
        "  2. Ensure the platform injects it via External Secrets\n"
        "  3. Run: huggingface-cli login"
    )


def get_hf_org() -> str:
    """Resolve the HF org from environment or platform config cache."""
    org = os.environ.get("HF_ORG", "")
    if org:
        return org

    from greatsky_internal_metaflow.config import read_config_cache

    cache = read_config_cache()
    if cache and cache.get("HF_ORG"):
        return cache["HF_ORG"]

    return ""


def _ensure_auth(token: Optional[str] = None) -> str:
    """Authenticate with HF Hub and return the token used."""
    from huggingface_hub import login

    t = token or get_hf_token()
    login(token=t, add_to_git_credential=False)
    return t


def resolve_repo_id(name: str, repo_type: str = "model") -> str:
    """Prepend the org prefix if not already namespaced.

    >>> resolve_repo_id("my-model")
    'Great-Sky/my-model'
    >>> resolve_repo_id("other-org/my-model")
    'other-org/my-model'
    """
    if "/" in name:
        return name
    org = get_hf_org()
    if org:
        return f"{org}/{name}"
    return name


def push_model_to_hub(
    local_path: str | Path,
    repo_id: str,
    *,
    commit_message: str = "Upload model",
    token: Optional[str] = None,
    private: bool = False,
) -> str:
    """Push a local model directory to Hugging Face Hub.

    Returns the URL of the uploaded repo.
    """
    from huggingface_hub import HfApi

    t = _ensure_auth(token)
    api = HfApi(token=t)
    full_id = resolve_repo_id(repo_id)

    api.create_repo(repo_id=full_id, repo_type="model", private=private, exist_ok=True)
    api.upload_folder(
        folder_path=str(local_path),
        repo_id=full_id,
        repo_type="model",
        commit_message=commit_message,
    )
    return f"https://huggingface.co/{full_id}"


def push_dataset_to_hub(
    local_path: str | Path,
    repo_id: str,
    *,
    commit_message: str = "Upload dataset",
    token: Optional[str] = None,
    private: bool = False,
) -> str:
    """Push a local dataset directory to Hugging Face Hub.

    Returns the URL of the uploaded repo.
    """
    from huggingface_hub import HfApi

    t = _ensure_auth(token)
    api = HfApi(token=t)
    full_id = resolve_repo_id(repo_id, repo_type="dataset")

    api.create_repo(repo_id=full_id, repo_type="dataset", private=private, exist_ok=True)
    api.upload_folder(
        folder_path=str(local_path),
        repo_id=full_id,
        repo_type="dataset",
        commit_message=commit_message,
    )
    return f"https://huggingface.co/datasets/{full_id}"


def pull_from_hub(
    repo_id: str,
    *,
    local_dir: Optional[str | Path] = None,
    revision: str = "main",
    repo_type: str = "model",
    token: Optional[str] = None,
) -> str:
    """Download a model or dataset from HF Hub.

    Returns the local path to the downloaded snapshot.
    """
    from huggingface_hub import snapshot_download

    t = _ensure_auth(token)
    full_id = resolve_repo_id(repo_id, repo_type=repo_type)

    kwargs: dict = {
        "repo_id": full_id,
        "repo_type": repo_type,
        "revision": revision,
        "token": t,
    }
    if local_dir:
        kwargs["local_dir"] = str(local_dir)

    return snapshot_download(**kwargs)


def sync_s3_to_hf(
    s3_path: str,
    repo_id: str,
    *,
    repo_type: str = "model",
    commit_message: str = "Sync from S3",
    token: Optional[str] = None,
    private: bool = False,
) -> str:
    """Download artifacts from S3 and push them to HF Hub.

    Requires boto3 (available in Metaflow worker environments).
    Returns the HF Hub URL.
    """
    from urllib.parse import urlparse

    import boto3

    parsed = urlparse(s3_path)
    bucket = parsed.netloc
    prefix = parsed.path.lstrip("/")

    s3 = boto3.client("s3")
    paginator = s3.get_paginator("list_objects_v2")

    with tempfile.TemporaryDirectory() as tmpdir:
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            for obj in page.get("Contents", []):
                key = obj["Key"]
                rel = key[len(prefix) :].lstrip("/")
                if not rel:
                    continue
                local = Path(tmpdir) / rel
                local.parent.mkdir(parents=True, exist_ok=True)
                s3.download_file(bucket, key, str(local))

        if repo_type == "dataset":
            return push_dataset_to_hub(tmpdir, repo_id, commit_message=commit_message, token=token, private=private)
        return push_model_to_hub(tmpdir, repo_id, commit_message=commit_message, token=token, private=private)


def sync_hf_to_s3(
    repo_id: str,
    s3_path: str,
    *,
    repo_type: str = "model",
    revision: str = "main",
    token: Optional[str] = None,
) -> int:
    """Download a repo from HF Hub and upload it to S3.

    Returns the number of files uploaded.
    """
    from urllib.parse import urlparse

    import boto3

    local_dir = pull_from_hub(repo_id, repo_type=repo_type, revision=revision, token=token)

    parsed = urlparse(s3_path)
    bucket = parsed.netloc
    prefix = parsed.path.lstrip("/").rstrip("/")

    s3 = boto3.client("s3")
    count = 0
    local_root = Path(local_dir)
    for fpath in local_root.rglob("*"):
        if fpath.is_file():
            key = f"{prefix}/{fpath.relative_to(local_root)}"
            s3.upload_file(str(fpath), bucket, key)
            count += 1

    return count


# ---------------------------------------------------------------------------
# Dataset helpers — first-class load / save / list
# ---------------------------------------------------------------------------


def _resolve_commit_sha(repo_id: str, revision: str, token: str) -> str:
    """Get the current HEAD commit SHA for a dataset repo."""
    try:
        from huggingface_hub import HfApi

        api = HfApi(token=token)
        info = api.repo_info(repo_id=repo_id, repo_type="dataset", revision=revision)
        return info.sha or ""
    except Exception:
        return ""


def load_dataset(
    name: str,
    *,
    split: Optional[str] = None,
    revision: str = "main",
    token: Optional[str] = None,
    **kwargs: Any,
) -> Tuple[Any, DatasetVersion]:
    """Load a dataset from HF Hub with auto org-resolution and version tracking.

    Returns ``(dataset, DatasetVersion)`` so the version can be stored as a
    Metaflow artifact for lineage.

    Examples::

        ds, version = load_dataset("my-dataset", split="train")
        self.dataset_version = version   # store as Metaflow artifact

        # Public datasets work too
        ds, version = load_dataset("imdb", split="train")
    """
    import datasets

    full_id = resolve_repo_id(name, repo_type="dataset")
    t = _try_get_token(token)

    ds = datasets.load_dataset(full_id, split=split, revision=revision, token=t, **kwargs)

    sha = _resolve_commit_sha(full_id, revision, t) if t else ""

    version = DatasetVersion(
        repo_id=full_id,
        commit_sha=sha,
        revision=revision,
        split=split,
    )

    return ds, version


def save_dataset(
    dataset: Any,
    name: str,
    *,
    commit_message: str = "Update dataset",
    revision: str = "main",
    token: Optional[str] = None,
    private: bool = False,
) -> DatasetVersion:
    """Save a dataset to HF Hub with auto org-resolution.

    Accepts:
      - A HF ``datasets.Dataset`` or ``DatasetDict``
      - A pandas ``DataFrame``
      - A ``dict`` of lists (converted to Dataset)
      - A ``str`` / ``Path`` pointing to a file (H5, Parquet, etc.) or directory

    Returns a ``DatasetVersion`` with the new commit SHA.

    Examples::

        version = save_dataset(my_df, "my-dataset")
        version = save_dataset("/data/train.h5", "my-h5-dataset")
        version = save_dataset("/data/parquet_dir/", "my-parquet-dataset")
    """
    import datasets as ds_lib
    from huggingface_hub import HfApi

    full_id = resolve_repo_id(name, repo_type="dataset")
    t = _ensure_auth(token)
    api = HfApi(token=t)

    api.create_repo(repo_id=full_id, repo_type="dataset", private=private, exist_ok=True)

    if isinstance(dataset, (str, Path)):
        p = Path(dataset)
        if p.is_file():
            api.upload_file(
                path_or_fileobj=str(p),
                path_in_repo=p.name,
                repo_id=full_id,
                repo_type="dataset",
                commit_message=commit_message,
            )
        elif p.is_dir():
            api.upload_folder(
                folder_path=str(p),
                repo_id=full_id,
                repo_type="dataset",
                commit_message=commit_message,
            )
        else:
            raise FileNotFoundError(f"Path does not exist: {p}")
    elif isinstance(dataset, (ds_lib.Dataset, ds_lib.DatasetDict)):
        dataset.push_to_hub(full_id, token=t, commit_message=commit_message, revision=revision)
    elif _is_dataframe(dataset):
        hf_ds = ds_lib.Dataset.from_pandas(dataset)
        hf_ds.push_to_hub(full_id, token=t, commit_message=commit_message, revision=revision)
    elif isinstance(dataset, dict):
        hf_ds = ds_lib.Dataset.from_dict(dataset)
        hf_ds.push_to_hub(full_id, token=t, commit_message=commit_message, revision=revision)
    else:
        raise TypeError(
            f"Unsupported dataset type: {type(dataset).__name__}. "
            "Expected Dataset, DatasetDict, DataFrame, dict, or path."
        )

    sha = _resolve_commit_sha(full_id, revision, t)

    return DatasetVersion(
        repo_id=full_id,
        commit_sha=sha,
        revision=revision,
    )


def list_datasets(org: Optional[str] = None, token: Optional[str] = None) -> List[dict]:
    """List all datasets in the org.

    Returns a list of dicts with ``id``, ``private``, ``last_modified``, and ``downloads``.
    """
    from huggingface_hub import HfApi

    org = org or get_hf_org()
    if not org:
        raise ValueError("No HF org configured. Set HF_ORG or pass org explicitly.")

    t = _try_get_token(token)
    api = HfApi(token=t)

    results = []
    for ds_info in api.list_datasets(author=org):
        results.append(
            {
                "id": ds_info.id,
                "private": ds_info.private,
                "last_modified": str(ds_info.last_modified) if ds_info.last_modified else None,
                "downloads": ds_info.downloads,
            }
        )

    return results


def download_file(
    repo_id: str,
    filename: str,
    *,
    local_dir: Optional[str | Path] = None,
    revision: str = "main",
    repo_type: str = "dataset",
    token: Optional[str] = None,
) -> Tuple[str, DatasetVersion]:
    """Download a single file from an HF Hub repo.

    Useful for H5/HDF5 files or other non-tabular formats that don't
    work with ``datasets.load_dataset()``.

    Returns ``(local_path, DatasetVersion)``.

    Examples::

        path, version = download_file("my-h5-dataset", "train.h5")
        self.dataset_version = version
        import h5py
        with h5py.File(path) as f:
            data = f["features"][:]
    """
    from huggingface_hub import hf_hub_download

    full_id = resolve_repo_id(repo_id, repo_type=repo_type)
    t = _try_get_token(token)

    kwargs: dict = {
        "repo_id": full_id,
        "filename": filename,
        "repo_type": repo_type,
        "revision": revision,
    }
    if t:
        kwargs["token"] = t
    if local_dir:
        kwargs["local_dir"] = str(local_dir)

    local_path = hf_hub_download(**kwargs)

    sha = _resolve_commit_sha(full_id, revision, t) if t else ""
    version = DatasetVersion(
        repo_id=full_id,
        commit_sha=sha,
        revision=revision,
    )

    return local_path, version


def _try_get_token(token: Optional[str] = None) -> str:
    """Like get_hf_token but returns empty string instead of raising."""
    if token:
        return token
    try:
        return get_hf_token()
    except RuntimeError:
        return ""


def _is_dataframe(obj: Any) -> bool:
    """Check if obj is a pandas DataFrame without importing pandas."""
    return type(obj).__name__ == "DataFrame" and hasattr(obj, "to_dict")
