"""Read and write GSM config and credentials with 3-tier directory resolution.

Resolution order (first match wins):
    1. Project — walk up from CWD looking for an existing .greatsky_gsm/ directory
    2. Venv   — $VIRTUAL_ENV/.greatsky/  (only when a virtualenv is active)
    3. Global — ~/.greatsky/

Write target (gsm login):
    1. Project — walk up from CWD for a project marker (pyproject.toml, .git, etc.)
       and create .greatsky_gsm/ there
    2. Venv   — $VIRTUAL_ENV/.greatsky/
    3. Global — ~/.greatsky/

Each directory stores:
    config.json        — minimal GSM config (auth API URL + service auth key)
    credentials.json   — user metadata (user, expiry, access type)
    config_cache.json  — cached remote platform config (for offline fallback)
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

PROJECT_DIR_NAME = ".greatsky_gsm"
VENV_DIR_NAME = ".greatsky"
GLOBAL_DIR = Path.home() / ".greatsky"

PROJECT_MARKERS = ("pyproject.toml", "setup.py", "setup.cfg", ".git")


# ---------------------------------------------------------------------------
# Directory resolution
# ---------------------------------------------------------------------------


def resolve_gsm_dir() -> Path | None:
    """Find the first existing GSM directory in the 3-tier hierarchy.

    Returns None if no GSM directory exists anywhere (user never logged in).
    """
    # 1. Project
    project_dir = _find_existing_project_gsm_dir()
    if project_dir is not None:
        return project_dir

    # 2. Venv
    venv_dir = _venv_gsm_dir()
    if venv_dir is not None and venv_dir.is_dir():
        return venv_dir

    # 3. Global
    if GLOBAL_DIR.is_dir():
        return GLOBAL_DIR

    return None


def write_target_dir() -> Path:
    """Determine where `gsm login` should write config files.

    Prefers a project root (creating .greatsky_gsm/ there), then the active
    venv, then the global home directory.
    """
    # 1. Project root
    project_root = _find_project_root()
    if project_root is not None:
        return project_root / PROJECT_DIR_NAME

    # 2. Venv
    venv_dir = _venv_gsm_dir()
    if venv_dir is not None:
        return venv_dir

    # 3. Global
    return GLOBAL_DIR


def _find_existing_project_gsm_dir() -> Path | None:
    """Walk up from CWD looking for an existing .greatsky_gsm/ directory."""
    current = Path.cwd().resolve()
    while True:
        candidate = current / PROJECT_DIR_NAME
        if candidate.is_dir():
            return candidate
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None


def _find_project_root() -> Path | None:
    """Walk up from CWD looking for a project marker file/directory."""
    current = Path.cwd().resolve()
    while True:
        for marker in PROJECT_MARKERS:
            if (current / marker).exists():
                return current
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None


def _venv_gsm_dir() -> Path | None:
    """Return the GSM dir inside the active virtualenv, or None."""
    venv = os.environ.get("VIRTUAL_ENV")
    if venv:
        return Path(venv) / VENV_DIR_NAME
    if sys.prefix != sys.base_prefix:
        return Path(sys.prefix) / VENV_DIR_NAME
    return None


# ---------------------------------------------------------------------------
# Read helpers
# ---------------------------------------------------------------------------


def read_credentials() -> dict[str, Any] | None:
    """Read cached GSM credentials from the first matching tier."""
    gsm_dir = resolve_gsm_dir()
    if gsm_dir is None:
        return None
    return _read_json(gsm_dir / "credentials.json")


def read_config() -> dict[str, Any] | None:
    """Read the GSM config (auth URL + API key) from the first matching tier."""
    gsm_dir = resolve_gsm_dir()
    if gsm_dir is None:
        return None
    return _read_json(gsm_dir / "config.json")


def read_config_cache() -> dict[str, Any] | None:
    """Read the cached remote config from the first matching tier."""
    gsm_dir = resolve_gsm_dir()
    if gsm_dir is None:
        return None
    return _read_json(gsm_dir / "config_cache.json")


# ---------------------------------------------------------------------------
# Write helpers
# ---------------------------------------------------------------------------


def write_config(config: dict[str, Any], target: Path | None = None) -> Path:
    """Write the GSM config file to the given (or default write-target) dir."""
    d = target or write_target_dir()
    d.mkdir(parents=True, exist_ok=True)
    path = d / "config.json"
    path.write_text(json.dumps(config, indent=2) + "\n")
    return path


def write_credentials(
    *,
    api_key: str,
    expires_at: str,
    github_user: str,
    name: str,
    access_type: str,
    invited_by: str | None = None,
    guest_expires: str | None = None,
    target: Path | None = None,
) -> Path:
    """Write GSM credential metadata to the given (or default write-target) dir."""
    d = target or write_target_dir()
    d.mkdir(parents=True, exist_ok=True)
    data: dict[str, Any] = {
        "api_key": api_key,
        "expires_at": expires_at,
        "github_user": github_user,
        "name": name,
        "access_type": access_type,
    }
    if invited_by:
        data["invited_by"] = invited_by
    if guest_expires:
        data["guest_expires"] = guest_expires
    path = d / "credentials.json"
    path.write_text(json.dumps(data, indent=2) + "\n")
    return path


def write_config_cache(config: dict[str, Any], target: Path | None = None) -> None:
    """Write the remote config cache to the given (or default write-target) dir."""
    d = target or write_target_dir()
    try:
        d.mkdir(parents=True, exist_ok=True)
        (d / "config_cache.json").write_text(json.dumps(config, indent=2) + "\n")
    except OSError:
        pass


def clear_all() -> bool:
    """Remove config files from the resolved GSM directory. Returns True if anything was removed."""
    gsm_dir = resolve_gsm_dir()
    if gsm_dir is None:
        return False
    removed = False
    for name in ("config.json", "credentials.json", "config_cache.json", "kubeconfig"):
        removed |= _remove(gsm_dir / name)
    return removed


# ---------------------------------------------------------------------------
# Internal utilities
# ---------------------------------------------------------------------------


def _read_json(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def _remove(path: Path) -> bool:
    try:
        path.unlink()
        return True
    except FileNotFoundError:
        return False
