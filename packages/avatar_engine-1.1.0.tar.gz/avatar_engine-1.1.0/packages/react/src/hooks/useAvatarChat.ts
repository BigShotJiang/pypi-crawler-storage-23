import { useCallback, useEffect, useRef, useState, type MutableRefObject } from 'react'
import { useTranslation } from 'react-i18next'
import type {
  ChatAttachment,
  ChatMessage,
  SafetyMode,
  ServerMessage,
  ToolInfo,
  UploadedFile,
  PermissionRequest,
} from '@avatar-engine/core'
import { buildOptionsDict, isImageModel, nextId, summarizeParams } from '@avatar-engine/core'
import { useAvatarWebSocket } from './useAvatarWebSocket'
import { useFileUpload } from './useFileUpload'

export interface AvatarChatOptions {
  /** REST API base URL (default: '/api/avatar') */
  apiBase?: string
  /** Auto-switch to this provider on first connect */
  initialProvider?: string
  /** Auto-switch to this model on first connect (requires initialProvider) */
  initialModel?: string
  /** Provider options to apply on initial switch */
  initialOptions?: Record<string, string | number>
  /** Called when an assistant response completes (chat_response message) */
  onResponse?: (message: ChatMessage) => void
}

/**
 * Return type for the {@link useAvatarChat} hook.
 *
 * @property messages - Chat message history (user + assistant).
 * @property sendMessage - Send a user message, optionally with file attachments.
 * @property stopResponse - Abort the current assistant response.
 * @property clearHistory - Clear all messages and reset chat state.
 * @property switchProvider - Switch to a different AI provider/model with optional config.
 * @property resumeSession - Resume a previous chat session by its ID.
 * @property newSession - Start a fresh session (clears messages and resets server state).
 * @property activeOptions - Currently active provider options (flat key-value map).
 * @property pendingFiles - Files queued for upload but not yet sent.
 * @property uploading - Whether a file upload is currently in progress.
 * @property uploadFile - Upload a file to the backend; resolves with metadata or null on failure.
 * @property removeFile - Remove a pending file by its ID.
 * @property isStreaming - Whether the assistant is currently streaming a response.
 * @property safetyMode - Current safety mode (safe, ask, or unrestricted).
 * @property permissionRequest - Pending permission request from the AI, if any.
 * @property sendPermissionResponse - Respond to a pending permission request.
 * @property switching - Whether a provider/model switch is in progress.
 * @property connected - Whether the WebSocket connection is established and ready.
 * @property wasConnected - Whether a connection was previously established (for reconnect UI).
 * @property initDetail - Human-readable initialization status detail.
 * @property sessionId - Current server-side session ID, if known.
 * @property sessionTitle - Display title for the current session.
 * @property provider - Active provider ID (e.g. "anthropic", "google").
 * @property model - Active model ID, or null if using the provider default.
 * @property version - Engine backend version string.
 * @property cwd - Server working directory.
 * @property engineState - Current engine state (idle, thinking, responding, etc.).
 * @property thinking - Thinking indicator state (phase, subject, timing).
 * @property cost - Cumulative token usage and cost for the session.
 * @property capabilities - Provider capability flags reported by the backend.
 * @property toolName - Name of the tool currently being executed, if any.
 * @property error - Last error message, or null.
 * @property diagnostic - Last diagnostic message, or null.
 */
export interface UseAvatarChatReturn {
  messages: ChatMessage[]
  sendMessage: (text: string, attachments?: UploadedFile[], context?: Record<string, unknown>) => void
  stopResponse: () => void
  clearHistory: () => void
  switchProvider: (provider: string, model?: string, options?: Record<string, string | number>) => void
  resumeSession: (sessionId: string) => void
  newSession: () => void
  activeOptions: Record<string, string | number>
  pendingFiles: UploadedFile[]
  uploading: boolean
  uploadFile: (file: File) => Promise<UploadedFile | null>
  removeFile: (fileId: string) => void
  isStreaming: boolean
  safetyMode: SafetyMode
  permissionRequest: PermissionRequest | null
  sendPermissionResponse: (requestId: string, optionId: string, cancelled: boolean) => void
  switching: boolean
  connected: boolean
  wasConnected: boolean
  initDetail: string
  sessionId: string | null
  sessionTitle: string | null
  provider: string
  model: string | null
  version: string
  cwd: string
  engineState: string
  thinking: { active: boolean; phase: string; subject: string; startedAt: number }
  cost: { totalCostUsd: number; totalInputTokens: number; totalOutputTokens: number }
  capabilities: ReturnType<typeof useAvatarWebSocket>['state']['capabilities']
  toolName: string | undefined
  error: string | null
  diagnostic: string | null
}

/**
 * Primary hook for Avatar Engine chat integration.
 *
 * Manages the full chat lifecycle: WebSocket connection, message streaming,
 * file uploads, provider switching, session management, and permission handling.
 *
 * @param wsUrl - WebSocket URL for the Avatar Engine backend (e.g. "ws://localhost:3000/ws").
 * @param optionsOrApiBase - Configuration options, or a plain string for the REST API base URL (legacy).
 *
 * @example
 * ```tsx
 * function ChatApp() {
 *   const chat = useAvatarChat('ws://localhost:3000/ws', {
 *     apiBase: '/api/avatar',
 *     initialProvider: 'anthropic',
 *     initialModel: 'claude-sonnet-4-20250514',
 *   });
 *
 *   return (
 *     <div>
 *       {chat.messages.map(m => <p key={m.id}>{m.content}</p>)}
 *       <button onClick={() => chat.sendMessage('Hello!')}>Send</button>
 *     </div>
 *   );
 * }
 * ```
 */
export function useAvatarChat(wsUrl: string, optionsOrApiBase?: AvatarChatOptions | string): UseAvatarChatReturn {
  const { t } = useTranslation()

  // Backwards-compatible: accept string (apiBase) or options object
  const options: AvatarChatOptions = typeof optionsOrApiBase === 'string'
    ? { apiBase: optionsOrApiBase }
    : optionsOrApiBase ?? {}

  const resolvedApiBase = options.apiBase ?? '/api/avatar'
  const onResponseRef = useRef(options.onResponse)
  onResponseRef.current = options.onResponse

  const { state, sendMessage: wsSend, clearHistory: wsClear, switchProvider: wsSwitch, resumeSession: wsResume, newSession: wsNew, sendPermissionResponse: wsPermission, onServerMessage, stopResponse: wsStop } =
    useAvatarWebSocket(wsUrl)
  const { pending: pendingFiles, uploading, upload: uploadFile, remove: removeFile, clear: clearFiles } =
    useFileUpload(resolvedApiBase)
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [isStreaming, setIsStreaming] = useState(false)
  const [activeOptions, setActiveOptions] = useState<Record<string, string | number>>({})
  const [permissionRequest, setPermissionRequest] = useState<PermissionRequest | null>(null)
  const currentAssistantIdRef = useRef<string | null>(null)
  const resumeAbortRef = useRef<AbortController | null>(null)
  const initialSwitchDoneRef = useRef(false)

  // Auto-switch provider/model on first connect
  useEffect(() => {
    if (!state.connected || initialSwitchDoneRef.current) return
    if (!options.initialProvider) return
    initialSwitchDoneRef.current = true
    // Switch if provider differs, or specific model/options requested
    if (options.initialProvider !== state.provider || options.initialModel || options.initialOptions) {
      const flatOpts = options.initialOptions
      if (flatOpts && Object.keys(flatOpts).length > 0) {
        setActiveOptions(flatOpts)
      }
      const builtOptions = flatOpts && Object.keys(flatOpts).length > 0
        ? buildOptionsDict(options.initialProvider, flatOpts)
        : undefined
      wsSwitch(options.initialProvider, options.initialModel, builtOptions)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.connected])

  useEffect(() => {
    const cleanup = onServerMessage((msg: ServerMessage) => {
      switch (msg.type) {
        case 'text': {
          const textId = currentAssistantIdRef.current
          if (!textId) break
          setMessages((prev) =>
            prev.map((m) =>
              m.id === textId
                ? {
                    ...m,
                    content: m.content + msg.data.text,
                    thinking: m.thinking ? { ...m.thinking, isComplete: true } : undefined,
                  }
                : m
            )
          )
          break
        }

        case 'thinking': {
          if (msg.data.is_complete) break
          const thinkId = currentAssistantIdRef.current
          if (!thinkId) break
          setMessages((prev) =>
            prev.map((m) =>
              m.id === thinkId
                ? {
                    ...m,
                    thinking: {
                      phase: msg.data.phase,
                      subject: msg.data.subject || m.thinking?.subject || '',
                      startedAt: m.thinking?.startedAt || Date.now(),
                      isComplete: false,
                    },
                  }
                : m
            )
          )
          break
        }

        case 'tool': {
          const toolId = currentAssistantIdRef.current
          if (!toolId) break
          setMessages((prev) =>
            prev.map((m) => {
              if (m.id !== toolId) return m
              const tools = [...m.tools]
              const existing = tools.findIndex(
                (t) => t.toolId === (msg.data.tool_id || msg.data.tool_name)
              )
              if (msg.data.status === 'started') {
                if (existing === -1) {
                  tools.push({
                    toolId: msg.data.tool_id || msg.data.tool_name,
                    name: msg.data.tool_name,
                    status: 'started',
                    params: summarizeParams(msg.data.parameters),
                    startedAt: Date.now(),
                  })
                }
              } else if (existing >= 0) {
                tools[existing] = {
                  ...tools[existing],
                  status: msg.data.status as ToolInfo['status'],
                  error: msg.data.error || undefined,
                  completedAt: Date.now(),
                }
              }
              return { ...m, tools }
            })
          )
          break
        }

        case 'chat_response': {
          const responseId = currentAssistantIdRef.current
          currentAssistantIdRef.current = null
          setIsStreaming(false)
          setPermissionRequest(null)
          if (!responseId) break
          setMessages((prev) => {
            const updated = prev.map((m) =>
              m.id === responseId
                ? {
                    ...m,
                    content: m.content || msg.data.content || (msg.data.error ? `Error: ${msg.data.error}` : ''),
                    isStreaming: false,
                    durationMs: msg.data.duration_ms,
                    costUsd: msg.data.cost_usd || undefined,
                    thinking: m.thinking ? { ...m.thinking, isComplete: true } : undefined,
                    images: msg.data.images,
                  }
                : m
            )
            const finalMsg = updated.find((m) => m.id === responseId)
            if (finalMsg && onResponseRef.current) {
              // Defer callback to avoid state update during render
              queueMicrotask(() => {
                try { onResponseRef.current?.(finalMsg) } catch { /* consumer callback error */ }
              })
            }
            return updated
          })
          break
        }

        case 'error': {
          const errorId = currentAssistantIdRef.current
          if (errorId) {
            currentAssistantIdRef.current = null
            setIsStreaming(false)
            setMessages((prev) =>
              prev.map((m) =>
                m.id === errorId
                  ? { ...m, content: m.content || `Error: ${msg.data.error}`, isStreaming: false }
                  : m
              )
            )
          }
          break
        }

        case 'history_cleared': {
          setMessages([])
          currentAssistantIdRef.current = null
          setIsStreaming(false)
          break
        }

        case 'permission_request': {
          setPermissionRequest({
            requestId: msg.data.request_id,
            toolName: msg.data.tool_name,
            toolInput: msg.data.tool_input,
            options: msg.data.options,
          })
          break
        }
      }
    })
    return cleanup
  }, [onServerMessage])

  const sendMessage = useCallback(
    (text: string, attachments?: UploadedFile[], context?: Record<string, unknown>) => {
      if (!text.trim() || isStreaming) return

      const allFiles = attachments?.length ? attachments : pendingFiles.length ? pendingFiles : undefined

      const userMsg: ChatMessage = {
        id: nextId(),
        role: 'user',
        content: text,
        timestamp: Date.now(),
        tools: [],
        isStreaming: false,
        attachments: allFiles,
        context,
      }

      const assistantMsg: ChatMessage = {
        id: nextId(),
        role: 'assistant',
        content: '',
        timestamp: Date.now(),
        tools: [],
        isStreaming: true,
      }
      currentAssistantIdRef.current = assistantMsg.id

      setMessages((prev) => [...prev, userMsg, assistantMsg])
      setIsStreaming(true)

      const wsAttachments: ChatAttachment[] | undefined = allFiles?.map((f) => ({
        file_id: f.fileId,
        filename: f.filename,
        mime_type: f.mimeType,
        path: f.path,
      }))
      wsSend(text, wsAttachments, context)
      clearFiles()
    },
    [wsSend, isStreaming, pendingFiles, clearFiles]
  )

  const clearHistory = useCallback(() => {
    wsClear()
    setMessages([])
    currentAssistantIdRef.current = null
    setIsStreaming(false)
  }, [wsClear])

  const switchProvider = useCallback((provider: string, model?: string, flatOptions?: Record<string, string | number>) => {
    setMessages([])
    currentAssistantIdRef.current = null
    setIsStreaming(false)
    setPermissionRequest(null)
    setActiveOptions(flatOptions && Object.keys(flatOptions).length > 0 ? flatOptions : {})

    const safetyValue = flatOptions?.safety_mode
    const providerFlatOptions = flatOptions ? { ...flatOptions } : undefined
    if (providerFlatOptions) delete providerFlatOptions.safety_mode

    let builtOptions: Record<string, unknown> | undefined =
      providerFlatOptions && Object.keys(providerFlatOptions).length > 0
        ? buildOptionsDict(provider, providerFlatOptions)
        : undefined

    if (safetyValue !== undefined) {
      builtOptions = { ...(builtOptions ?? {}), safety_mode: safetyValue }
    }

    if (model && isImageModel(model)) {
      const genCfg = ((builtOptions?.generation_config ?? {}) as Record<string, unknown>)
      builtOptions = {
        ...(builtOptions ?? {}),
        generation_config: { ...genCfg, response_modalities: 'TEXT,IMAGE' },
      }
    }

    wsSwitch(provider, model, builtOptions)
  }, [wsSwitch])

  const resumeSession = useCallback((sessionId: string) => {
    // Abort any in-flight history fetch
    resumeAbortRef.current?.abort()
    const controller = new AbortController()
    resumeAbortRef.current = controller

    currentAssistantIdRef.current = null
    setIsStreaming(false)
    setActiveOptions({})
    wsResume(sessionId)

    fetch(`${resolvedApiBase}/sessions/${encodeURIComponent(sessionId)}/messages`, {
      signal: controller.signal,
    })
      .then((r) => r.json())
      .then((data: Array<{ role: string; content: string }>) => {
        if (!data || !data.length) {
          setMessages([])
          return
        }
        const historyMessages: ChatMessage[] = data.map((m, i) => ({
          id: `history-${i}-${Date.now()}`,
          role: m.role as 'user' | 'assistant',
          content: m.content,
          timestamp: Date.now() - (data.length - i) * 1000,
          tools: [],
          isStreaming: false,
        }))
        setMessages(historyMessages)
      })
      .catch((e) => {
        if (e?.name !== 'AbortError') setMessages([])
      })
  }, [wsResume, resolvedApiBase])

  const newSession = useCallback(() => {
    setMessages([])
    currentAssistantIdRef.current = null
    setIsStreaming(false)
    setActiveOptions({})
    wsNew()
  }, [wsNew])

  const sendPermissionResponse = useCallback((requestId: string, optionId: string, cancelled: boolean) => {
    wsPermission(requestId, optionId, cancelled)
    setPermissionRequest(null)
  }, [wsPermission])

  const stopResponse = useCallback(() => {
    wsStop()
    setPermissionRequest(null)
    if (currentAssistantIdRef.current) {
      setMessages((prev) =>
        prev.map((m) =>
          m.id === currentAssistantIdRef.current
            ? { ...m, isStreaming: false, content: m.content || t('chat.stopped') }
            : m
        )
      )
      currentAssistantIdRef.current = null
      setIsStreaming(false)
    }
  }, [wsStop, t])

  return {
    messages,
    sendMessage,
    stopResponse,
    clearHistory,
    switchProvider,
    resumeSession,
    newSession,
    activeOptions,
    pendingFiles,
    uploading,
    uploadFile,
    removeFile,
    isStreaming,
    safetyMode: state.safetyMode,
    permissionRequest,
    sendPermissionResponse,
    switching: state.switching,
    connected: state.connected,
    wasConnected: state.wasConnected,
    initDetail: state.initDetail,
    sessionId: state.sessionId,
    sessionTitle: state.sessionTitle
      || messages.find((m) => m.role === 'user')?.content?.slice(0, 80)
      || null,
    provider: state.provider,
    model: state.model,
    version: state.version,
    cwd: state.cwd,
    engineState: state.engineState,
    thinking: state.thinking,
    toolName: state.toolName,
    cost: state.cost,
    capabilities: state.capabilities,
    error: state.error,
    diagnostic: state.diagnostic,
  }
}
