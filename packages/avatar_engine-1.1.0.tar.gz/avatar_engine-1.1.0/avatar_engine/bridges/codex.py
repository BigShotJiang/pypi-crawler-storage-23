"""
Codex CLI bridge — ACP warm session via codex-acp adapter.

Architecture:
    start() spawns codex-acp via ACP Python SDK:
        npx @zed-industries/codex-acp
    → initialize → authenticate → new_session → prompt → prompt …
    = ONE process, multiple prompts = TRUE warm session

    ┌─────────────┐     ACP JSON-RPC (stdin/stdout)     ┌─────────────┐
    │ Python App  │ ──────────────────────────────────→  │ codex-acp   │
    │ (ACP SDK)   │ ←──────────────────────────────────  │ (Rust bin)  │
    └─────────────┘                                      └─────────────┘
                                                           ↕ codex-core
                                                         OpenAI API

Unlike GeminiBridge, there is NO oneshot fallback — codex-acp is the only
integration path. The Codex CLI does not have a headless stream-json mode.

Authentication:
    ACP uses ``authenticate(methodId="chatgpt")`` for browser OAuth,
    or ``codex-api-key`` / ``openai-api-key`` for API key auth.

Requirements:
    pip install agent-client-protocol>=0.6.0
    npm install -g @zed-industries/codex-acp  (or use npx)
"""

import asyncio
import logging
import shutil
import threading
import time
from collections import deque
from collections.abc import AsyncIterator, Callable
from typing import Any

from ..types import Attachment
from .base import BaseBridge, BridgeResponse, BridgeState, Message
from .gemini import _build_prompt_blocks

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional ACP SDK import
# ---------------------------------------------------------------------------
_ACP_AVAILABLE = False
try:
    from acp import PROTOCOL_VERSION, connect_to_agent
    from acp.interfaces import Client as ACPClient
    from acp.schema import (
        AgentMessageChunk,
        AgentThoughtChunk,
        AllowedOutcome,
        ClientCapabilities,
        DeniedOutcome,
        FileSystemCapability,
        RequestPermissionResponse,
        TextContentBlock,
        ToolCallProgress,
        ToolCallStart,
    )

    _ACP_AVAILABLE = True
except ImportError:
    logger.info(
        "agent-client-protocol not installed — Codex ACP unavailable. "
        "Install with: uv add agent-client-protocol"
    )


from ._acp_session import ACPSessionMixin  # noqa: E402


class CodexBridge(ACPSessionMixin, BaseBridge):
    """
    Codex CLI bridge via ACP adapter (codex-acp).

    Uses the same ACP Python SDK as GeminiBridge but communicates
    with the codex-acp Rust binary instead of Gemini CLI.

    ACP-only: no oneshot fallback (Codex CLI has no headless stream-json mode).

    Lifecycle::

        bridge = CodexBridge(...)
        await bridge.start()     # Spawns codex-acp, authenticates, creates session
        resp = await bridge.send("Hello!")   # Instant (warm session)
        resp = await bridge.send("More?")    # Same session
        await bridge.stop()
    """

    def __init__(
        self,
        executable: str = "npx",
        executable_args: list[str] | None = None,
        model: str = "",  # Empty = Codex default (gpt-5.3-codex)
        working_dir: str = "",
        timeout: int = 600,
        system_prompt: str = "",
        auth_method: str = "chatgpt",  # chatgpt | codex-api-key | openai-api-key
        approval_mode: str = "auto",   # auto-approve tool calls
        sandbox_mode: str = "workspace-write",  # read-only | workspace-write | danger-full-access
        env: dict[str, str] | None = None,
        mcp_servers: dict[str, Any] | None = None,
        resume_session_id: str | None = None,
        continue_last: bool = False,
        permission_handler: Any | None = None,
    ):
        """
        Args:
            executable: Path to codex-acp binary or npx.
            executable_args: Arguments after executable (default: ["@zed-industries/codex-acp"]).
            model: Model name (empty = Codex default).
            working_dir: Working directory for the Codex session.
            timeout: Request timeout in seconds.
            system_prompt: System prompt for the AI.
            auth_method: ACP authentication method:
                - "chatgpt" — Browser OAuth flow via codex-login
                - "codex-api-key" — CODEX_API_KEY env var
                - "openai-api-key" — OPENAI_API_KEY env var
            approval_mode: Tool approval mode:
                - "auto" — Auto-approve all tool calls (non-interactive)
                - "ask" — Route to GUI via permission_handler
                - "manual" — Require explicit approval (interactive only)
            sandbox_mode: Filesystem sandbox mode:
                - "read-only" — Can read files, no writes
                - "workspace-write" — Can modify workspace files
                - "danger-full-access" — Full filesystem access
            env: Extra environment variables for the subprocess.
            mcp_servers: MCP server configurations (passed per-session).
            resume_session_id: Resume a specific session by ID (via ACP load_session).
            continue_last: Continue the most recent session (via ACP list+load).
            permission_handler: Async callback for Ask mode permission routing.
        """
        super().__init__(
            executable=executable,
            model=model,
            working_dir=working_dir,
            timeout=timeout,
            system_prompt=system_prompt,
            env=env,
            mcp_servers=mcp_servers,
        )
        self.executable_args = executable_args if executable_args is not None else ["@zed-industries/codex-acp"]
        self.auth_method = auth_method
        self.approval_mode = approval_mode
        self._acp_session_mode = approval_mode  # Used by ACPSessionMixin._apply_session_mode
        self.sandbox_mode = sandbox_mode
        self.resume_session_id = resume_session_id
        self.continue_last = continue_last
        self._permission_handler = permission_handler

        # ACP state
        self._acp_conn = None
        self._acp_proc = None
        self._acp_session_id: str | None = None
        self._acp_stderr_task: asyncio.Task | None = None

        # Collected events from ACP session_update notifications
        self._acp_events: list[dict[str, Any]] = []
        self._acp_text_buffer: str = ""
        self._recent_thinking_norm = deque(maxlen=8)
        self._thinking_raw = ""      # Raw accumulated thinking text (for replay dedup)
        self._message_raw = ""       # Raw accumulated message text (for replay dedup)
        self._dedup_active = True    # True while message text still tracks thinking replay
        self._was_thinking = False   # Track thinking→text transition for is_complete
        self._acp_buffer_lock = threading.Lock()  # RC-3/4: sync callback vs main thread

        # Provider capabilities
        self._provider_capabilities.thinking_supported = True   # Codex reasoning
        self._provider_capabilities.thinking_structured = True
        self._provider_capabilities.cost_tracking = False
        self._provider_capabilities.budget_enforcement = False
        self._provider_capabilities.system_prompt_method = "injected"  # ACP prepend
        self._provider_capabilities.streaming = True
        self._provider_capabilities.parallel_tools = False
        self._provider_capabilities.cancellable = False
        self._provider_capabilities.mcp_supported = True

    @property
    def provider_name(self) -> str:
        return "codex"

    @property
    def is_persistent(self) -> bool:
        return True  # Always ACP warm session

    # ======================================================================
    # Lifecycle — ACP only (no oneshot fallback)
    # ======================================================================

    async def start(self) -> None:
        """
        Start the Codex bridge via ACP.

        Spawns codex-acp, authenticates, and creates a session.
        Raises RuntimeError if ACP SDK is not installed.
        """
        if not _ACP_AVAILABLE:
            raise RuntimeError(
                "agent-client-protocol SDK not installed. "
                "Install with: pip install agent-client-protocol"
            )

        logger.info(f"Starting Codex bridge (auth: {self.auth_method})")

        try:
            await self._start_acp()
            logger.info(
                f"Codex ACP warm session active. Session: {self._acp_session_id}, "
                f"Auth: {self.auth_method}"
            )
        except Exception as exc:
            logger.error(f"Codex ACP start failed: {exc}")
            self._set_state(BridgeState.ERROR)
            await self._cleanup_acp()
            raise

    async def stop(self) -> None:
        """Shutdown bridge — clean up ACP context."""
        await self._cleanup_acp()
        await super().stop()

    # ======================================================================
    # ACP warm session management
    # ======================================================================

    async def _start_acp(self) -> None:
        """Spawn codex-acp via connect_to_agent (official SDK API)."""
        self._set_state(BridgeState.WARMING_UP, "Spawning Codex ACP...")

        # Verify executable is available
        exe_bin = shutil.which(self.executable)
        if not exe_bin:
            raise FileNotFoundError(
                f"Executable not found: '{self.executable}'. "
                "Install npx (Node.js) or codex-acp binary."
            )

        # Build command: executable + executable_args
        cmd_args = [exe_bin] + self.executable_args
        env = self._build_subprocess_env()

        logger.info(f"Spawning ACP: {' '.join(cmd_args[:6])}")

        # Spawn process with stdio pipes
        self._acp_proc = await asyncio.create_subprocess_exec(
            *cmd_args,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=self.working_dir,
            env=env,
        )

        # Monitor stderr — surfaces CLI diagnostics (auth, rate-limit, errors)
        self._acp_stderr_task = asyncio.create_task(self._monitor_acp_stderr())

        # Build ACP client that handles permission requests
        client = _CodexACPClient(
            auto_approve=(self.approval_mode == "auto"),
            on_update=self._handle_acp_update,
            permission_handler=self._permission_handler,
        )

        # Connect via official SDK API
        self._acp_conn = connect_to_agent(
            client, self._acp_proc.stdin, self._acp_proc.stdout
        )

        # Step 1: Initialize protocol with client capabilities
        self._set_state(BridgeState.WARMING_UP, "Initializing ACP protocol...")
        init_resp = await asyncio.wait_for(
            self._acp_conn.initialize(
                protocol_version=PROTOCOL_VERSION,
                client_capabilities=ClientCapabilities(
                    fs=FileSystemCapability(
                        read_text_file=True,
                        write_text_file=True,
                    ),
                    terminal=True,
                ),
            ),
            timeout=self.timeout,
        )
        logger.debug(f"ACP initialized: protocol v{init_resp.protocol_version}")
        self._store_acp_capabilities(init_resp)

        # Expose ACP session capabilities to the web frontend
        if self._session_capabilities.can_list:
            self._provider_capabilities.can_list_sessions = True
        if self._session_capabilities.can_load:
            self._provider_capabilities.can_load_session = True

        # Step 2: Authenticate
        self._set_state(BridgeState.WARMING_UP, "Authenticating...")
        try:
            await asyncio.wait_for(
                self._acp_conn.authenticate(method_id=self.auth_method),
                timeout=self.timeout,
            )
            logger.info(f"ACP authenticated via: {self.auth_method}")
        except asyncio.TimeoutError:
            logger.error(f"ACP authentication timed out after {self.timeout}s")
            raise RuntimeError(
                f"Codex authentication timed out. "
                f"For '{self.auth_method}' auth, ensure credentials are available. "
                f"Run 'codex login' for ChatGPT auth, or set CODEX_API_KEY/OPENAI_API_KEY."
            )
        except Exception as exc:
            exc_str = str(exc).lower()
            if "not supported" in exc_str or "not implemented" in exc_str:
                logger.info("ACP authenticate not required (auto-detect mode)")
            else:
                logger.warning(
                    f"ACP authenticate issue: {exc} — continuing. "
                    f"If session fails, check your Codex credentials."
                )

        # Step 3: Create or resume session
        self._set_state(BridgeState.WARMING_UP, "Creating session...")
        mcp_servers_acp = self._build_mcp_servers_acp()
        await self._create_or_resume_acp_session(mcp_servers_acp)

    def _build_mcp_servers_acp(self) -> list:
        """Convert MCP servers dict to ACP format."""
        mcp_servers_acp = []
        if self.mcp_servers:
            for name, srv in self.mcp_servers.items():
                env_dict = srv.get("env", {})
                env_list = [{"name": k, "value": v} for k, v in env_dict.items()]
                entry = {
                    "name": name,
                    "command": srv["command"],
                    "args": srv.get("args", []),
                    "env": env_list,
                }
                mcp_servers_acp.append(entry)
        return mcp_servers_acp

    # Known-harmless Codex stderr patterns (internal debug noise, not user-facing)
    _CODEX_STDERR_IGNORE = (
        "state db missing rollout path",  # Stale session DB entry (fixed in Codex ≥0.100)
        "rollout::list",                  # Related rollout listing noise
    )

    async def _monitor_acp_stderr(self) -> None:
        """Background task reading ACP subprocess stderr.

        Surfaces CLI diagnostics (auth prompts, rate-limit, errors) via
        the DiagnosticEvent pipeline so the user isn't blind.
        """
        from .base import _classify_stderr_level, _strip_ansi

        try:
            proc = self._acp_proc
            while proc and proc.stderr and proc.returncode is None:
                line = await proc.stderr.readline()
                if not line:
                    break
                text = _strip_ansi(line.decode(errors="replace").strip())
                if not text:
                    continue
                # Skip known-harmless internal Codex noise
                if any(pat in text for pat in self._CODEX_STDERR_IGNORE):
                    logger.debug(f"ACP stderr (ignored): {text}")
                    continue
                with self._stderr_lock:
                    self._stderr_buffer.append(text)
                logger.debug(f"ACP stderr: {text}")
                if self._on_stderr:
                    self._on_stderr(text)
                if self._on_event:
                    self._on_event({
                        "type": "diagnostic",
                        "message": text,
                        "level": _classify_stderr_level(text),
                        "source": "acp-stderr",
                    })
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            logger.debug(f"ACP stderr monitor: {exc}")

    async def _cleanup_acp(self) -> None:
        """Clean up ACP connection and terminate process.

        Closes subprocess pipes and transport explicitly to prevent
        'Event loop is closed' errors from BaseSubprocessTransport.__del__.
        """
        # Cancel stderr monitor first
        if self._acp_stderr_task and not self._acp_stderr_task.done():
            self._acp_stderr_task.cancel()
            try:
                await self._acp_stderr_task
            except (asyncio.CancelledError, Exception):
                pass
            self._acp_stderr_task = None

        if self._acp_conn:
            try:
                await self._acp_conn.close()
            except Exception as exc:
                logger.debug(f"ACP conn close: {exc}")
            self._acp_conn = None
        if self._acp_proc:
            # Close stdin to signal EOF to child process
            if self._acp_proc.stdin:
                try:
                    self._acp_proc.stdin.close()
                except Exception:
                    pass
            if self._acp_proc.returncode is None:
                try:
                    self._acp_proc.terminate()
                    await asyncio.wait_for(self._acp_proc.wait(), timeout=5)
                except asyncio.TimeoutError:
                    self._acp_proc.kill()
                    await self._acp_proc.wait()
                except Exception as exc:
                    logger.debug(f"ACP process cleanup: {exc}")
            # Close the subprocess transport so pipe transports are cleaned up
            # while the event loop is still running
            try:
                transport = getattr(self._acp_proc, "_transport", None)
                if transport and hasattr(transport, "close"):
                    transport.close()
                # Give event loop a chance to process pipe close callbacks
                await asyncio.sleep(0)
            except Exception:
                pass
        self._acp_proc = None
        self._acp_session_id = None

    def _handle_acp_update(self, session_id: str, update: Any) -> None:
        """Callback for ACP session/update notifications (streaming text + thinking).

        Called from ACP SDK thread — all buffer writes protected by lock (RC-3/4).
        Wrapped in try-except so exceptions don't propagate into ACP SDK internals.
        """
        try:
            self._handle_acp_update_inner(session_id, update)
        except Exception as exc:
            logger.warning(f"Error in ACP update handler: {exc}", exc_info=True)
            if self._on_event:
                self._on_event({
                    "type": "diagnostic",
                    "message": f"ACP update error: {exc}",
                    "level": "error",
                    "source": "acp-callback",
                })

    def _handle_acp_update_inner(self, session_id: str, update: Any) -> None:
        """Inner handler for ACP updates — uses typed SDK objects.

        The ACP SDK delivers typed updates:
        - AgentThoughtChunk → thinking event (spinner, NOT printed)
        - AgentMessageChunk → response text (printed to output)
        - ToolCallStart/ToolCallProgress → tool events
        - Fallback: legacy attribute-based extraction
        """
        # --- Typed dispatch (ACP SDK 0.8+) ---
        if _ACP_AVAILABLE and isinstance(update, AgentThoughtChunk):
            thinking = _text_from_content(update.content)
            if thinking:
                self._was_thinking = True
                norm = _normalize_reasoning_text(thinking)
                if norm:
                    with self._acp_buffer_lock:
                        self._recent_thinking_norm.append(norm)
                with self._acp_buffer_lock:
                    self._thinking_raw += thinking
                thinking_event = {
                    "type": "thinking",
                    "session_id": session_id,
                    "thought": thinking,
                }
                with self._acp_buffer_lock:
                    self._acp_events.append(thinking_event)
                if self._on_event:
                    self._on_event(thinking_event)
            return

        if _ACP_AVAILABLE and isinstance(update, AgentMessageChunk):
            text = _text_from_content(update.content)
            if text and not self._should_suppress_text_output(text):
                # Thinking→text transition: emit is_complete so display stops spinner
                if self._was_thinking:
                    self._was_thinking = False
                    complete_event = {
                        "type": "thinking",
                        "session_id": session_id,
                        "thought": "",
                        "is_complete": True,
                    }
                    if self._on_event:
                        self._on_event(complete_event)

                event = {"type": "acp_update", "session_id": session_id, "text": text}
                with self._acp_buffer_lock:
                    self._acp_text_buffer += text
                    self._acp_events.append(event)
                if self._on_output:
                    self._on_output(text)
                if self._on_event:
                    self._on_event(event)
            return

        if _ACP_AVAILABLE and isinstance(update, (ToolCallStart, ToolCallProgress)):
            tool_event = _extract_tool_event_from_update(update)
            if tool_event:
                tool_event["session_id"] = session_id
                with self._acp_buffer_lock:
                    self._acp_events.append(tool_event)
                if self._on_event:
                    self._on_event(tool_event)
            return

        # --- Fallback: legacy attribute-based extraction ---
        event = {"type": "acp_update", "session_id": session_id, "raw": str(update)}

        thinking = _extract_thinking_from_update(update)
        if thinking:
            self._was_thinking = True
            norm = _normalize_reasoning_text(thinking)
            if norm:
                with self._acp_buffer_lock:
                    self._recent_thinking_norm.append(norm)
            thinking_event = {
                "type": "thinking",
                "session_id": session_id,
                "thought": thinking,
            }
            with self._acp_buffer_lock:
                self._acp_events.append(thinking_event)
            if self._on_event:
                self._on_event(thinking_event)

        tool_event = _extract_tool_event_from_update(update)
        if tool_event:
            tool_event["session_id"] = session_id
            with self._acp_buffer_lock:
                self._acp_events.append(tool_event)
            if self._on_event:
                self._on_event(tool_event)

        text = None if thinking else _extract_text_from_update(update)
        if text and not self._should_suppress_text_output(text):
            if self._was_thinking:
                self._was_thinking = False
                complete_event = {
                    "type": "thinking",
                    "session_id": session_id,
                    "thought": "",
                    "is_complete": True,
                }
                if self._on_event:
                    self._on_event(complete_event)

            event["text"] = text
            with self._acp_buffer_lock:
                self._acp_text_buffer += text
            if self._on_output:
                self._on_output(text)

        with self._acp_buffer_lock:
            self._acp_events.append(event)
        if self._on_event:
            self._on_event(event)

    # ======================================================================
    # send() / send_stream() — ACP only
    # ======================================================================

    async def send(self, prompt: str, attachments: list[Attachment] | None = None) -> BridgeResponse:
        """Send prompt through the ACP warm session."""
        if self.state == BridgeState.DISCONNECTED:
            await self.start()

        if not self._acp_conn or not self._acp_session_id:
            raise RuntimeError("Codex ACP session not active. Call start() first.")

        # GAP-5: Inject system prompt into first ACP message
        effective_prompt = self._prepend_system_prompt(prompt)

        self._set_state(BridgeState.BUSY)
        t0 = time.time()
        with self._acp_buffer_lock:  # RC-3/4
            self._acp_events.clear()
            self._acp_text_buffer = ""
            self._recent_thinking_norm.clear()
            self._thinking_raw = ""
            self._message_raw = ""
            self._dedup_active = True

        try:
            prompt_blocks = _build_prompt_blocks(effective_prompt, attachments)

            # No timeout on prompt — user controls stop via UI.
            # Codex tool chains and complex analyses can take many minutes.
            result = await self._acp_conn.prompt(
                session_id=self._acp_session_id,
                prompt=prompt_blocks,
            )

            elapsed = int((time.time() - t0) * 1000)

            # Prefer accumulated streaming buffer, fallback to result, then thinking
            with self._acp_buffer_lock:  # RC-3/4
                content = self._acp_text_buffer or _extract_text_from_result(result)
                # Codex sends responses as thinking chunks — if text buffer is
                # empty, reconstruct content from thinking events
                if not content:
                    thinking_parts = [
                        e["thought"] for e in self._acp_events
                        if e.get("type") == "thinking" and e.get("thought")
                    ]
                    if thinking_parts:
                        content = "".join(thinking_parts).strip()
                events_copy = self._acp_events.copy()

            with self._history_lock:  # RC-9
                self.history.append(Message(role="user", content=prompt))
                self.history.append(Message(role="assistant", content=content))
            self._set_state(BridgeState.READY)

            response = BridgeResponse(
                content=content,
                raw_events=events_copy,
                duration_ms=elapsed,
                session_id=self._acp_session_id,
                success=True,
            )
            self._update_stats(response)
            return response

        except asyncio.TimeoutError:
            self._set_state(BridgeState.ERROR)
            response = BridgeResponse(
                content="",
                duration_ms=int((time.time() - t0) * 1000),
                success=False,
                error=f"Codex ACP timeout ({int(time.time() - t0)}s) — cancelled by outer timeout",
            )
            self._update_stats(response)
            return response
        except Exception as exc:
            logger.error(f"Codex ACP send failed: {exc}", exc_info=True)
            self._set_state(BridgeState.ERROR)
            response = BridgeResponse(
                content="",
                duration_ms=int((time.time() - t0) * 1000),
                success=False,
                error=str(exc),
            )
            self._update_stats(response)
            return response

    async def send_stream(self, prompt: str) -> AsyncIterator[str]:
        """Stream response from ACP warm session."""
        if self.state == BridgeState.DISCONNECTED:
            await self.start()

        if not self._acp_conn or not self._acp_session_id:
            raise RuntimeError("Codex ACP session not active. Call start() first.")

        # GAP-5: Inject system prompt into first ACP message
        effective_prompt = self._prepend_system_prompt(prompt)

        self._set_state(BridgeState.BUSY)
        with self._acp_buffer_lock:  # RC-3/4
            self._acp_events.clear()
            self._acp_text_buffer = ""
            self._recent_thinking_norm.clear()
            self._thinking_raw = ""
            self._message_raw = ""
            self._dedup_active = True

        # Bridge callback → async iterator via Queue
        queue: asyncio.Queue[str | None] = asyncio.Queue()
        original_callback = self._on_output

        def _stream_callback(text: str) -> None:
            queue.put_nowait(text)
            if original_callback:
                original_callback(text)

        self._on_output = _stream_callback

        async def _run_prompt():
            try:
                await self._acp_conn.prompt(
                    session_id=self._acp_session_id,
                    prompt=_build_prompt_blocks(effective_prompt),
                )
            finally:
                await queue.put(None)  # Signal completion

        task = asyncio.create_task(_run_prompt())

        try:
            full_text = ""
            while True:
                # Per-chunk timeout (not total): wait up to 10 min for next chunk.
                # Codex tool chains can have long pauses between outputs.
                chunk = await asyncio.wait_for(queue.get(), timeout=600)
                if chunk is None:
                    break
                full_text += chunk
                yield chunk

            with self._history_lock:  # RC-9
                self.history.append(Message(role="user", content=prompt))
                self.history.append(Message(role="assistant", content=full_text))
            self._set_state(BridgeState.READY)
        except asyncio.TimeoutError:
            task.cancel()
            self._set_state(BridgeState.ERROR)
            raise
        finally:
            self._on_output = original_callback
            if not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass

    # ======================================================================
    # Config — Zero Footprint (no files needed for Codex)
    # ======================================================================

    def _setup_config_files(self) -> None:
        """No config files needed for Codex ACP.

        Codex ACP receives all configuration through the ACP protocol:
        - MCP servers via new_session()
        - Auth via authenticate()
        - No settings.json or config files needed in project directory
        """
        pass  # Zero Footprint naturally satisfied

    # ======================================================================
    # BaseBridge abstract method stubs
    # (Not used — ACP handles everything, but required by ABC)
    # ======================================================================

    def _build_persistent_command(self) -> list[str]:
        raise NotImplementedError("Codex uses ACP, not raw subprocess")

    def _format_user_message(self, prompt: str, attachments: list[Attachment] | None = None) -> str:
        raise NotImplementedError("Codex uses ACP, not raw subprocess")

    def _build_oneshot_command(self, prompt: str) -> list[str]:
        raise NotImplementedError("Codex is ACP-only, no oneshot mode")

    def _is_turn_complete(self, event: dict[str, Any]) -> bool:
        return event.get("type") == "result"

    def _parse_session_id(self, events: list[dict[str, Any]]) -> str | None:
        # Session ID comes from new_session(), not from events
        return self._acp_session_id

    def _parse_content(self, events: list[dict[str, Any]]) -> str:
        parts = []
        for ev in events:
            if ev.get("type") == "acp_update" and "text" in ev:
                parts.append(ev["text"])
        return "".join(parts)

    def _parse_tool_calls(self, events: list[dict[str, Any]]) -> list[dict[str, Any]]:
        calls = []
        for ev in events:
            if ev.get("type") == "tool_call":
                calls.append({
                    "tool": ev.get("tool_name", ""),
                    "parameters": ev.get("parameters", {}),
                    "tool_id": ev.get("tool_id", ""),
                    "kind": ev.get("kind", ""),
                })
        return calls

    def _parse_usage(self, events: list[dict[str, Any]]) -> dict[str, Any] | None:
        # Token usage may come from ACP notifications
        for ev in events:
            if ev.get("type") == "token_usage":
                return ev.get("usage", {})
        return None

    def _extract_text_delta(self, event: dict[str, Any]) -> str | None:
        if event.get("type") == "acp_update":
            return event.get("text")
        return None

    def _should_suppress_text_output(self, text: str) -> bool:
        """Suppress text chunks that duplicate recent thinking/reasoning content.

        Codex ACP replays the full thinking text as AgentMessageChunk.
        We detect this replay by tracking accumulated raw text:
        if the growing message text is still a prefix of the thinking text,
        it's a replay and should be suppressed.

        Once the message diverges from thinking, dedup stops permanently
        for this turn (the real response has started).
        """
        if not text or not text.strip():
            return False

        with self._acp_buffer_lock:
            thinking_raw = self._thinking_raw
            dedup_active = self._dedup_active

        # No thinking text accumulated, or dedup already stopped → pass through
        if not thinking_raw or not dedup_active:
            return False

        # Check if accumulated message + this chunk is still a prefix of thinking
        with self._acp_buffer_lock:
            candidate = self._message_raw + text
        thinking_norm = _normalize_reasoning_text(thinking_raw)
        candidate_norm = _normalize_reasoning_text(candidate)

        if thinking_norm.startswith(candidate_norm):
            # Still replaying thinking text — suppress
            with self._acp_buffer_lock:
                self._message_raw += text
            return True

        # Diverged — real response started. Stop dedup permanently for this turn.
        with self._acp_buffer_lock:
            self._dedup_active = False
        return False


# ==========================================================================
# ACP Client implementation (handles permission requests from Codex)
# ==========================================================================

if _ACP_AVAILABLE:

    class _CodexACPClient(ACPClient):
        """
        ACP client that handles codex-acp's permission requests and
        session update notifications for the Avatar Engine.

        Modes:
        - auto_approve=True: silently approve all tool calls (auto/unrestricted)
        - auto_approve=False + permission_handler: route to GUI (ask mode)
        - auto_approve=False + no handler: deny all (safe fallback)
        """

        def __init__(
            self,
            auto_approve: bool = True,
            on_update: Callable | None = None,
            permission_handler: Any | None = None,
        ):
            self._auto_approve = auto_approve
            self._on_update = on_update
            self._permission_handler = permission_handler

        async def request_permission(
            self, options, session_id, tool_call, **kwargs
        ):
            """Handle tool permission requests from codex-acp.

            Codex ACP sends RequestPermission for exec, patch, MCP calls.
            Returns typed RequestPermissionResponse (SDK 0.8+).
            """
            if self._auto_approve:
                logger.debug(
                    f"Auto-approving tool call in session {session_id}"
                )
                if hasattr(options, "options") and options.options:
                    opt = options.options[0]
                    return RequestPermissionResponse(
                        outcome=AllowedOutcome(
                            option_id=opt.option_id, outcome="selected"
                        )
                    )
                return RequestPermissionResponse(
                    outcome=AllowedOutcome(
                        option_id="approved", outcome="selected"
                    )
                )

            # Extract tool name
            tool_name = getattr(tool_call, "function_name", str(tool_call))

            # Auto-approve non-destructive interactive tools (ask_user, etc.)
            auto_approve_tools = {"ask_user"}
            if tool_name in auto_approve_tools:
                logger.info(
                    f"Auto-approving non-destructive tool '{tool_name}'"
                )
                if hasattr(options, "options") and options.options:
                    for opt in options.options:
                        if getattr(opt, "kind", "") in {"allow_once", "allow_always"}:
                            return RequestPermissionResponse(
                                outcome=AllowedOutcome(
                                    option_id=opt.option_id, outcome="selected"
                                )
                            )
                    return RequestPermissionResponse(
                        outcome=AllowedOutcome(
                            option_id=options.options[0].option_id, outcome="selected"
                        )
                    )
                return RequestPermissionResponse(
                    outcome=AllowedOutcome(
                        option_id="approved", outcome="selected"
                    )
                )

            # Ask mode: route to GUI via permission_handler
            if self._permission_handler:
                import uuid
                request_id = str(uuid.uuid4())
                tool_input = str(getattr(tool_call, "arguments", ""))[:500]

                gui_options = []
                if hasattr(options, "options") and options.options:
                    for opt in options.options:
                        gui_options.append({
                            "option_id": getattr(opt, "option_id", ""),
                            "kind": getattr(opt, "kind", ""),
                        })

                logger.info(
                    f"Permission request for {tool_name}: "
                    f"{len(gui_options)} options, waiting for user..."
                )

                try:
                    result = await self._permission_handler(
                        request_id, tool_name, tool_input, gui_options,
                    )
                except Exception as exc:
                    logger.error(f"Permission handler error: {exc}")
                    return RequestPermissionResponse(
                        outcome=DeniedOutcome(outcome="cancelled")
                    )

                if result.get("cancelled"):
                    logger.info(f"Permission denied by user for {tool_name}")
                    return RequestPermissionResponse(
                        outcome=DeniedOutcome(outcome="cancelled")
                    )

                selected_id = result.get("option_id", "")
                logger.info(
                    f"Permission granted by user for {tool_name}: {selected_id}"
                )
                return RequestPermissionResponse(
                    outcome=AllowedOutcome(
                        option_id=selected_id, outcome="selected"
                    )
                )

            # No handler — deny (ask mode without GUI connected)
            logger.warning(
                f"Permission denied for '{tool_name}': no permission_handler "
                f"configured (auto_approve=False, ask mode without GUI?)"
            )
            return RequestPermissionResponse(
                outcome=DeniedOutcome(outcome="cancelled")
            )

        async def session_update(self, session_id, update, **kwargs):
            """Handle streaming session updates from codex-acp."""
            if self._on_update:
                self._on_update(session_id, update)

else:

    class _CodexACPClient:  # type: ignore[no-redef]
        """Placeholder when ACP SDK is not installed."""

        pass


# ==========================================================================
# Helpers for extracting content from ACP response objects
# ==========================================================================


def _extract_thinking_from_update(update: Any) -> str | None:
    """Extract thinking content from a codex-acp AgentThoughtChunk."""
    try:
        # AgentThoughtChunk with content.text
        if hasattr(update, "thought") and update.thought:
            if hasattr(update.thought, "text"):
                return update.thought.text
            if isinstance(update.thought, str):
                return update.thought

        # Content block with type "thinking"
        if hasattr(update, "content"):
            content = update.content
            if hasattr(content, "type") and getattr(content, "type", "") == "thinking":
                if hasattr(content, "text"):
                    return content.text
            if isinstance(content, list):
                for block in content:
                    if hasattr(block, "type") and block.type == "thinking":
                        if hasattr(block, "text"):
                            return block.text

        # AgentThoughtChunk pattern
        type_name = type(update).__name__
        if "Thought" in type_name:
            if hasattr(update, "content"):
                content = update.content
                if hasattr(content, "text"):
                    return content.text
                if isinstance(content, str):
                    return content

        # Dict-style access
        if isinstance(update, dict):
            if "thought" in update:
                return update["thought"]
            if update.get("type") == "AgentThoughtChunk":
                return update.get("content", {}).get("text", "")

    except Exception as exc:
        logger.debug(f"Could not extract thinking from update: {exc}")
    return None


def _extract_text_from_update(update: Any) -> str | None:
    """Extract text from a codex-acp AgentMessageChunk."""
    try:
        def _is_reasoning_block(block_type: Any) -> bool:
            if not block_type:
                return False
            bt = str(block_type).lower()
            return bt in {"thinking", "thought", "reasoning", "analysis"}

        # AgentMessageChunk.content.text
        if hasattr(update, "content"):
            content = update.content
            if hasattr(content, "text"):
                # Skip thinking blocks
                if hasattr(content, "type") and _is_reasoning_block(getattr(content, "type", "")):
                    return None
                return content.text
            if isinstance(content, list):
                parts = []
                for block in content:
                    if hasattr(block, "type") and _is_reasoning_block(getattr(block, "type", "")):
                        continue  # Skip thinking blocks
                    if isinstance(block, dict) and _is_reasoning_block(block.get("type")):
                        continue
                    if hasattr(block, "text"):
                        parts.append(block.text)
                    elif isinstance(block, dict) and "text" in block:
                        parts.append(str(block["text"]))
                return "".join(parts) if parts else None

        # Check for message chunk pattern by type name
        type_name = type(update).__name__
        if "Message" in type_name and "Thought" not in type_name:
            if hasattr(update, "content"):
                content = update.content
                if hasattr(content, "text"):
                    if hasattr(content, "type") and _is_reasoning_block(getattr(content, "type", "")):
                        return None
                    return content.text

        # Dict-style access
        if isinstance(update, dict):
            if update.get("type") == "AgentMessageChunk":
                content = update.get("content", {})
                if isinstance(content, dict):
                    if _is_reasoning_block(content.get("type")):
                        return None
                    if "text" in content:
                        return str(content.get("text") or "")
                if isinstance(content, list):
                    parts = []
                    for block in content:
                        if isinstance(block, dict):
                            if _is_reasoning_block(block.get("type")):
                                continue
                            if "text" in block:
                                parts.append(str(block["text"]))
                    return "".join(parts) if parts else None
            msg = update.get("agentMessage", {})
            content = msg.get("content", [])
            parts = []
            for block in content:
                if isinstance(block, dict) and _is_reasoning_block(block.get("type")):
                    continue
                if isinstance(block, dict) and "text" in block:
                    parts.append(block["text"])
            return "".join(parts) if parts else None

    except Exception as exc:
        logger.debug(f"Could not extract text from update: {exc}")
    return None


def _extract_tool_event_from_update(update: Any) -> dict[str, Any] | None:
    """Extract tool call events from codex-acp ToolCall/ToolCallUpdate."""
    try:
        type_name = type(update).__name__

        # ToolCall — tool invocation started
        if type_name == "ToolCall" or (isinstance(update, dict) and update.get("type") == "ToolCall"):
            tool_name = ""
            tool_id = ""
            kind = ""
            parameters = {}

            if hasattr(update, "name"):
                tool_name = update.name
            if hasattr(update, "id"):
                tool_id = update.id
            if hasattr(update, "kind"):
                kind = str(update.kind)
            if hasattr(update, "parameters"):
                parameters = update.parameters if isinstance(update.parameters, dict) else {}

            if isinstance(update, dict):
                tool_name = update.get("name", tool_name)
                tool_id = update.get("id", tool_id)
                kind = update.get("kind", kind)
                parameters = update.get("parameters", parameters)

            return {
                "type": "tool_call",
                "tool_name": tool_name,
                "tool_id": tool_id,
                "kind": kind,
                "parameters": parameters,
                "status": "started",
            }

        # ToolCallUpdate — tool result/progress
        if type_name == "ToolCallUpdate" or (isinstance(update, dict) and update.get("type") == "ToolCallUpdate"):
            tool_id = ""
            status = "completed"
            result = None
            error = None

            if hasattr(update, "id"):
                tool_id = update.id
            if hasattr(update, "status"):
                status = str(update.status)
            if hasattr(update, "output"):
                result = str(update.output) if update.output else None
            if hasattr(update, "error"):
                error = str(update.error) if update.error else None

            if isinstance(update, dict):
                tool_id = update.get("id", tool_id)
                status = update.get("status", status)
                result = update.get("output", result)
                error = update.get("error", error)

            # Map status
            if error or "fail" in status.lower():
                mapped_status = "failed"
            elif "complet" in status.lower():
                mapped_status = "completed"
            else:
                mapped_status = status

            return {
                "type": "tool_result",
                "tool_id": tool_id,
                "status": mapped_status,
                "result": result,
                "error": error,
            }

    except Exception as exc:
        logger.debug(f"Could not extract tool event from update: {exc}")
    return None


def _extract_text_from_result(result: Any) -> str:
    """Extract text content from an ACP PromptResponse."""
    try:
        if hasattr(result, "content"):
            content = result.content
            if hasattr(content, "text"):
                return content.text
            if isinstance(content, list):
                parts = []
                for block in content:
                    if hasattr(block, "text"):
                        parts.append(block.text)
                    elif isinstance(block, dict) and "text" in block:
                        parts.append(block["text"])
                if parts:
                    return "".join(parts)
    except Exception as exc:
        logger.debug(f"Could not extract text from result: {exc}")
    return ""


def _text_from_content(content: Any) -> str | None:
    """Extract text from a typed ACP content block (SDK 0.8+).

    Handles TextContentBlock and plain strings.
    """
    if content is None:
        return None
    if _ACP_AVAILABLE and isinstance(content, TextContentBlock):
        return content.text or None
    if isinstance(content, str):
        return content or None
    if hasattr(content, "text"):
        return content.text or None
    return None


def _normalize_reasoning_text(text: Any) -> str:
    """Normalize text for lightweight reasoning/output dedupe."""
    if text is None:
        return ""
    normalized = str(text).strip().lower()
    if not normalized:
        return ""
    normalized = normalized.replace("**", "")
    normalized = " ".join(normalized.split())
    return normalized
