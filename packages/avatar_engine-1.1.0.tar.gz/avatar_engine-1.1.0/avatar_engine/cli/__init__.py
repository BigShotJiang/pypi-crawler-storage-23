"""Avatar Engine CLI."""

from .app import cli

__all__ = ["cli"]
