"""TableShot — Extract tables from PDFs into clean, structured data."""

__version__ = "0.1.0"
