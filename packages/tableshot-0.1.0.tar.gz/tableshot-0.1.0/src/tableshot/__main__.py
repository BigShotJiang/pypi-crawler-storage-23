"""Allow running as `python -m tableshot`."""

from tableshot.server import main

main()
