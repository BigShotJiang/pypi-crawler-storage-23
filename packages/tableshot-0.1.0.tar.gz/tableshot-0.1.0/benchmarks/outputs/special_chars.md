## Table 1 (page 1, 5 rows x 2 cols)

| Description       | Value     |
| ----------------- | --------- |
| Price (USD)       | $1,234.56 |
| Ratio             | 3:1       |
| Contains "quotes" | yes       |
| A & B             | <tag>     |