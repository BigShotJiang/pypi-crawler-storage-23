## Table 1 (page 1, 4 rows x 2 cols)

| Item     | Count |
| -------- | ----- |
| Apples   | 50    |
| Bananas  | 30    |
| Cherries | 100   |

## Table 2 (page 2, 3 rows x 3 cols)

| Item    | Unit Price | Currency |
| ------- | ---------- | -------- |
| Apples  | 1.50       | USD      |
| Bananas | 0.75       | USD      |