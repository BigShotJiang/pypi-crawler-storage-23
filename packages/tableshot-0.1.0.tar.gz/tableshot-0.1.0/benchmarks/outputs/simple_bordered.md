## Table 1 (page 1, 5 rows x 4 cols)

| Product  | Price   | Quantity | Total     |
| -------- | ------- | -------- | --------- |
| Widget A | $10.00  | 100      | $1,000.00 |
| Widget B | $25.50  | 50       | $1,275.00 |
| Widget C | $5.99   | 200      | $1,198.00 |
| Widget D | $149.00 | 10       | $1,490.00 |