## Table 1 (page 2, 3 rows x 2 cols)

| Name  | Score |
| ----- | ----- |
| Alice | 95    |
| Bob   | 87    |