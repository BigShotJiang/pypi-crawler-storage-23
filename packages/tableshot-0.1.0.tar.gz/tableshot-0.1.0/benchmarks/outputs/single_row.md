## Table 1 (page 1, 2 rows x 2 cols)

| Key     | Value |
| ------- | ----- |
| version | 1.0.0 |