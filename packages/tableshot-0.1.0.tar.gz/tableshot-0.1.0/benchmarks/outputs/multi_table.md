## Table 1 (page 1, 3 rows x 3 cols)

| Name        | Department  | Email             |
| ----------- | ----------- | ----------------- |
| Alice Smith | Engineering | alice@example.com |
| Bob Jones   | Marketing   | bob@example.com   |

## Table 2 (page 1, 4 rows x 2 cols)

| Category  | Amount   |
| --------- | -------- |
| Salaries  | $500,000 |
| Equipment | $50,000  |
| Travel    | $25,000  |