"""Tests for _allow_decompose recall parameter."""

from __future__ import annotations

import os
import tempfile

from scripts._recall_core import recall
from scripts.init_workspace import init


def _make_workspace():
    td = tempfile.TemporaryDirectory()
    ws = os.path.join(td.name, "ws")
    os.makedirs(ws)
    init(ws)
    blocks_md = os.path.join(ws, "decisions", "decompose_test.md")
    with open(blocks_md, "w") as f:
        f.write("[AD-001]\nType: Decision\nStatement: Decomposition test alpha\n\n")
        f.write("[AD-002]\nType: Decision\nStatement: Decomposition test beta\n\n")
    return ws, td


def test_allow_decompose_true():
    """_allow_decompose=True works."""
    ws, td = _make_workspace()
    try:
        results = recall(ws, "decomposition test alpha and beta", limit=5, _allow_decompose=True)
        assert isinstance(results, list)
    finally:
        td.cleanup()


def test_allow_decompose_false():
    """_allow_decompose=False works."""
    ws, td = _make_workspace()
    try:
        results = recall(ws, "decomposition test alpha and beta", limit=5, _allow_decompose=False)
        assert isinstance(results, list)
    finally:
        td.cleanup()
