"""
Field-level response filtering based on OPA authorization decisions.

OPA returns per-field access decisions (allowed_fields, allow_all_fields)
for GET requests.  When allow_all_fields is False, this module strips
restricted fields from the response before it reaches the client.

How it works:
  1. If OPA says allow_all_fields=True or the request was bypassed,
     the model is returned unchanged.
  2. Otherwise, every field NOT in allowed_fields is set to None.
  3. Combined with FastAPI's ``response_model_exclude_none=True``,
     the filtered-out fields simply disappear from the JSON response.
"""
from __future__ import annotations

from typing import Any, Dict, List, Sequence, TypeVar

from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)


def filter_model_fields(model: T, authz_info: Dict[str, Any]) -> T:
    """
    Return a copy of *model* with fields restricted by OPA nullified.

    Args:
        model: A Pydantic model instance (e.g. UserProfile, UserStatus).
        authz_info: The dict returned by ``authorize_request`` dependency.
            Expected shape::

                {
                    "opa_decision": {
                        "allow_all_fields": bool,
                        "allowed_fields": list[str],
                        "bypass": bool,  # optional, present on self-service bypass
                        ...
                    },
                    ...
                }

    Returns:
        The original model if full access is granted, or a shallow copy
        with restricted fields set to None.
    """
    opa_decision = authz_info.get("opa_decision", {})

    # Bypass path or full access -> no filtering needed
    if opa_decision.get("bypass") or opa_decision.get("allow_all_fields", True):
        return model

    allowed_fields = set(opa_decision.get("allowed_fields", []))
    if not allowed_fields:
        # Safety net: if OPA allowed the request but returned no
        # allowed_fields list, return model unchanged.
        return model

    # Build a dict with restricted fields nullified
    data = model.model_dump()
    filtered = {
        k: (v if k in allowed_fields else None)
        for k, v in data.items()
    }

    # model_construct skips validation (the data was already valid)
    return type(model).model_construct(**filtered)  # type: ignore[return-value]


def filter_model_list(
    models: Sequence[T],
    authz_info: Dict[str, Any],
) -> List[T]:
    """
    Apply field filtering to every item in a list of models.

    Useful for paginated / batch GET endpoints (e.g. admin list views).
    """
    opa_decision = authz_info.get("opa_decision", {})
    if opa_decision.get("bypass") or opa_decision.get("allow_all_fields", True):
        return list(models)

    return [filter_model_fields(m, authz_info) for m in models]
