"""
Userstatus Operations - CRUD operations for Userstatus
"""
import os
import logging
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional, TYPE_CHECKING

from google.cloud import firestore
from pydantic import ValidationError as PydanticValidationError

from ...models import UserStatus
from ...exceptions import ResourceNotFoundError, UserStatusError
from ..base import BaseFirestoreService

# Type checking imports to avoid circular dependencies
if TYPE_CHECKING:
    from .user_subscription_operations import UsersubscriptionOperations
    from .user_permissions_operations import UserpermissionsOperations


class UserstatusOperations:
    """
    Handles CRUD operations for Userstatus documents
    """

    def __init__(
        self,
        firestore_client: firestore.Client,
        logger: Optional[logging.Logger] = None,
        timeout: float = 10.0,
        status_collection: Optional[str] = None,
        subscription_ops: Optional["UsersubscriptionOperations"] = None,
        permissions_ops: Optional["UserpermissionsOperations"] = None
    ):
        self.db = firestore_client
        self.logger = logger or logging.getLogger(__name__)
        self.timeout = timeout

        # Optional dependencies for comprehensive operations
        self.subscription_ops = subscription_ops
        self.permissions_ops = permissions_ops

        self.status_collection_name = status_collection or UserStatus.get_collection_name()

        # Archival configuration
        self.archive_userstatus_on_delete = os.getenv('ARCHIVE_USERSTATUS_ON_DELETE', 'true').lower() == 'true'
        self.archive_userstatus_collection_name = os.getenv(
            'ARCHIVE_USERSTATUS_COLLECTION_NAME',
            "~archive_core_user_userstatuss"
        )

        # Initialize DB service
        self._status_db_service = BaseFirestoreService[UserStatus](
            db=self.db,
            collection_name=self.status_collection_name,
            resource_type=UserStatus.OBJ_REF,
            model_class=UserStatus,
            logger=self.logger,
            timeout=self.timeout
        )

    async def get_userstatus(self, user_uid: str, convert_to_model: bool = True) -> Optional[UserStatus]:
        """Retrieve a user status by UID"""
        userstatus_id = f"{UserStatus.OBJ_REF}_{user_uid}"

        try:
            userstatus = await self._status_db_service.get_document(
                userstatus_id,
                convert_to_model=convert_to_model
            )
            if userstatus:
                self.logger.debug("Successfully retrieved user status for %s", user_uid)
                # Always return a UserStatus model to match the return type
                if isinstance(userstatus, dict):
                    return UserStatus(**userstatus)
                return userstatus
            else:
                self.logger.debug("User status not found for %s", user_uid)
                return None

        except ResourceNotFoundError:
            self.logger.debug("User status not found for %s", user_uid)
            return None
        except Exception as e:
            self.logger.error("Failed to fetch user status for %s: %s", user_uid, str(e), exc_info=True)
            raise UserStatusError(
                detail=f"Failed to fetch user status: {str(e)}",
                user_uid=user_uid,
                operation="get_userstatus",
                original_error=e
            ) from e

    async def create_userstatus(self, userstatus: UserStatus, creator_uid: Optional[str] = None) -> UserStatus:
        """Create a new user status"""
        self.logger.info(f"Creating user status for UID: {userstatus.user_uid}")
        try:
            doc_id = f"{UserStatus.OBJ_REF}_{userstatus.user_uid}"
            effective_creator_uid = creator_uid or userstatus.user_uid
            await self._status_db_service.create_document(doc_id, userstatus, effective_creator_uid)
            self.logger.info("Successfully created user status for UID: %s", userstatus.user_uid)
            return userstatus
        except Exception as e:
            self.logger.error("Error creating user status for %s: %s", userstatus.user_uid, e, exc_info=True)
            raise UserStatusError(
                detail=f"Failed to create user status: {str(e)}",
                user_uid=userstatus.user_uid,
                operation="create_userstatus",
                original_error=e
            ) from e

    async def update_userstatus(self, user_uid: str, status_data: Dict[str, Any], updater_uid: str) -> UserStatus:
        """Update a user status"""
        userstatus_id = f"{UserStatus.OBJ_REF}_{user_uid}"

        # Remove system fields that shouldn't be updated
        update_data = status_data.copy()
        update_data.pop('user_uid', None)
        update_data.pop('id', None)
        update_data.pop('created_at', None)
        update_data.pop('created_by', None)

        try:
            updated_doc_dict = await self._status_db_service.update_document(
                doc_id=userstatus_id,
                update_data=update_data,
                updater_uid=updater_uid
            )
            self.logger.info("Userstatus for %s updated successfully by %s", user_uid, updater_uid)
            return UserStatus(**updated_doc_dict)
        except ResourceNotFoundError as exc:
            raise UserStatusError(
                detail="User status not found",
                user_uid=user_uid,
                operation="update_userstatus"
            ) from exc
        except Exception as e:
            self.logger.error("Error updating Userstatus for %s: %s", user_uid, str(e), exc_info=True)
            raise UserStatusError(
                detail=f"Failed to update user status: {str(e)}",
                user_uid=user_uid,
                operation="update_userstatus",
                original_error=e
            ) from e

    async def delete_userstatus(self, user_uid: str, updater_uid: str = "system_deletion", archive: Optional[bool] = True) -> bool:
        """Delete (archive and delete) user status"""
        status_doc_id = f"{UserStatus.OBJ_REF}_{user_uid}"
        should_archive = archive if archive is not None else self.archive_userstatus_on_delete

        try:
            if should_archive:
                deleted = await self._status_db_service.archive_and_delete_document(
                    doc_id=status_doc_id,
                    archive_collection=self.archive_userstatus_collection_name,
                    archived_by=updater_uid,
                    require_exists=False,
                )
                if not deleted:
                    self.logger.warning("User status %s not found for deletion", status_doc_id)
                    return True
                self.logger.info("Successfully archived and deleted user status: %s", status_doc_id)
                return True

            await self._status_db_service.delete_document(status_doc_id, require_exists=False)
            self.logger.info("Successfully deleted user status without archival: %s", status_doc_id)
            return True

        except ResourceNotFoundError:
            self.logger.debug("User status %s not found for deletion (idempotent)", status_doc_id)
            return True  # Idempotent - already "deleted"
        except Exception as e:
            self.logger.error("Failed to delete user status %s: %s", status_doc_id, str(e), exc_info=True)
            raise UserStatusError(
                detail=f"Failed to delete user status: {str(e)}",
                user_uid=user_uid,
                operation="delete_userstatus",
                original_error=e
            ) from e

    async def validate_userstatus_data(
        self,
        status_data: Optional[Dict[str, Any]] = None
    ) -> tuple[bool, list[str]]:
        """Validate user status data without creating documents"""
        errors = []
        if status_data:
            try:
                UserStatus(**status_data)
            except PydanticValidationError as e:
                errors.append(f"Status validation error: {str(e)}")
        return len(errors) == 0, errors

    async def validate_and_cleanup_user_permissions(
        self, user_uid: str, updater_uid: str, delete_expired: bool = True
    ) -> int:
        """Validate and clean up expired IAM permissions for a user."""
        userstatus = await self.get_userstatus(user_uid)
        if not userstatus:
            self.logger.warning("Userstatus not found for %s, cannot validate permissions.", user_uid)
            return 0

        removed_count = userstatus.cleanup_expired_permissions()

        if removed_count > 0 and delete_expired:
            await self.update_userstatus(
                user_uid,
                userstatus.model_dump(exclude_none=True),
                updater_uid=updater_uid
            )
            self.logger.info("Removed %d expired permissions for user %s.", removed_count, user_uid)

        return removed_count

    async def list_userstatuss(
        self,
        limit: int = 50,
        offset: int = 0,
    ) -> List[UserStatus]:
        """List user statuses with pagination.

        Args:
            limit: Maximum number of statuses to return
            offset: Number of statuses to skip

        Returns:
            List of UserStatus models
        """
        all_docs = await self._status_db_service.list_documents(as_models=True)
        return all_docs[offset:offset + limit]

    async def batch_update_userstatuss(
        self,
        updates: List[Dict[str, Any]],
        updater_uid: str,
    ) -> Dict[str, Any]:
        """Batch update user statuses.

        Args:
            updates: List of dicts, each containing 'user_uid' and fields to update
            updater_uid: UID of the user performing the update

        Returns:
            Dict with 'successful' (list of UIDs) and 'failed' (dict of UID to error)
        """
        successful: List[str] = []
        failed: Dict[str, str] = {}

        for update_item in updates:
            user_uid = update_item.get("user_uid")
            if not user_uid:
                failed[f"idx_{len(successful) + len(failed)}"] = "Missing user_uid"
                continue

            status_updates = update_item.get("status_updates", update_item)
            if not isinstance(status_updates, dict):
                failed[user_uid] = "status_updates must be a dict"
                continue

            status_updates = status_updates.copy()
            status_updates.pop("user_uid", None)

            try:
                await self.update_userstatus(user_uid=user_uid, status_data=status_updates, updater_uid=updater_uid)
                successful.append(user_uid)
            except Exception as exc:
                failed[user_uid] = str(exc)

        return {"successful": successful, "failed": failed}

    async def batch_delete_userstatuss(
        self,
        user_uids: List[str],
        updater_uid: str,
        archive: bool = True,
    ) -> Dict[str, List[str]]:
        """Batch delete user statuses.

        Args:
            user_uids: List of user UIDs to delete
            updater_uid: UID of the user performing the deletion
            archive: Whether to archive before deleting

        Returns:
            Dict with 'deleted' and 'failed' lists of UIDs
        """
        deleted: List[str] = []
        failed: List[str] = []

        for user_uid in user_uids:
            try:
                await self.delete_userstatus(user_uid=user_uid, updater_uid=updater_uid, archive=archive)
                deleted.append(user_uid)
            except Exception:
                failed.append(user_uid)

        return {"deleted": deleted, "failed": failed}

    async def userstatus_exists(self, user_uid: str) -> bool:
        """Check if a user status exists."""
        return await self._status_db_service.document_exists(f"{UserStatus.OBJ_REF}_{user_uid}")

    def _update_userstatus_transactional(self, user_uid: str, status_data: Dict[str, Any], updater_uid: str) -> UserStatus:
        """Update userstatus atomically using Firestore transaction."""
        userstatus_id = f"{UserStatus.OBJ_REF}_{user_uid}"
        user_ref = self.db.collection(self.status_collection_name).document(userstatus_id)

        update_data = status_data.copy()
        update_data.pop('user_uid', None)
        update_data.pop('id', None)
        update_data.pop('created_at', None)
        update_data.pop('created_by', None)
        update_data['updated_by'] = updater_uid
        update_data['updated_at'] = datetime.now(timezone.utc)

        @firestore.transactional
        def _execute(transaction_obj):
            user_doc = user_ref.get(transaction=transaction_obj)
            if not user_doc.exists:
                raise UserStatusError(
                    detail="User status not found",
                    user_uid=user_uid,
                    operation="update_userstatus_transactional"
                )

            transaction_obj.update(user_ref, update_data)
            merged_data = user_doc.to_dict() or {}
            merged_data.update(update_data)
            merged_data['user_uid'] = user_uid
            return UserStatus(**merged_data)

        transaction = self.db.transaction()
        return _execute(transaction)

    def _mutate_userstatus_transactional(
        self,
        user_uid: str,
        mutation_func,
        updater_uid: str
    ) -> tuple[UserStatus, Any]:
        """Apply a mutation atomically inside a Firestore transaction.

        Unlike _update_userstatus_transactional (which takes pre-computed data),
        this method reads fresh data inside the transaction and applies the
        mutation function to it. On retry, fresh data is re-read and the mutation
        is re-applied -- preventing TOCTOU race conditions with concurrent requests.

        Args:
            user_uid: The user's UID
            mutation_func: Callable(UserStatus) -> Any. Mutates the UserStatus
                in-place and returns metadata. If the return value is a dict
                containing '_has_changes': False, the write is skipped.
            updater_uid: Who is performing the update

        Returns:
            Tuple of (UserStatus, mutation_func_return_value)
        """
        userstatus_id = f"{UserStatus.OBJ_REF}_{user_uid}"
        user_ref = self.db.collection(self.status_collection_name).document(userstatus_id)
        result_holder: Dict[str, Any] = {}

        @firestore.transactional
        def _execute(transaction_obj):
            user_doc = user_ref.get(transaction=transaction_obj)
            if not user_doc.exists:
                raise UserStatusError(
                    detail="User status not found",
                    user_uid=user_uid,
                    operation="mutate_userstatus_transactional"
                )

            current_data = user_doc.to_dict() or {}
            current_data['user_uid'] = user_uid
            userstatus = UserStatus(**current_data)

            # Apply mutation to fresh data — re-applied on every retry
            mutation_result = mutation_func(userstatus)
            result_holder["value"] = mutation_result

            # Check if write should be skipped (no changes to persist)
            if isinstance(mutation_result, dict) and not mutation_result.get('_has_changes', True):
                return userstatus

            # Prepare and write the update
            update_data = userstatus.model_dump(exclude_none=False)
            update_data.pop('user_uid', None)
            update_data.pop('id', None)
            update_data.pop('created_at', None)
            update_data.pop('created_by', None)
            update_data['updated_by'] = updater_uid
            update_data['updated_at'] = datetime.now(timezone.utc)

            transaction_obj.update(user_ref, update_data)

            merged_data = current_data.copy()
            merged_data.update(update_data)
            merged_data['user_uid'] = user_uid
            return UserStatus(**merged_data)

        transaction = self.db.transaction()
        updated_userstatus = _execute(transaction)
        return updated_userstatus, result_holder.get("value")

    ######################################################################
    ######################### Comprehensive Review Methods #############
    ######################################################################

    async def review_and_clean_active_subscription_credits_and_permissions(
        self,
        user_uid: str,
        updater_uid: str = "system_review",
        review_auto_renewal: bool = True,
        apply_fallback: bool = True,
        clean_expired_permissions: bool = True,
        review_credits: bool = True
    ) -> Dict[str, Any]:
        """
        Comprehensive review of user's active subscription, credits, and permissions.
        This method handles:
        1. Subscription lifecycle (auto-renewal, fallback, expiration)
        2. Credit management based on subscription cycle timing
        3. Permission cleanup and management

        All state mutations are applied inside a Firestore transaction using
        _mutate_userstatus_transactional, which reads fresh data on each attempt
        (including retries). This prevents TOCTOU race conditions where concurrent
        requests could overwrite each other's changes.

        This is designed to be called on every authz request for comprehensive user state management.

        Args:
            user_uid: User UID to review
            updater_uid: User ID performing the review
            review_auto_renewal: Whether to auto-renew expired cycles if auto_renew_end_datetime is valid
            apply_fallback: Whether to apply fallback plans when subscriptions expire
            clean_expired_permissions: Whether to clean expired permissions
            review_credits: Whether to review and update subscription-based credits

        Returns:
            Dict containing detailed results of the review and actions taken
        """
        from datetime import datetime, timezone
        from ipulse_shared_base_ftredge.enums import SubscriptionStatus
        from ...models import UserSubscription

        self.logger.info("Starting comprehensive subscription, credits, and permissions review for user %s", user_uid)

        result = {
            'user_uid': user_uid,
            'timestamp': datetime.now(timezone.utc),
            'actions_taken': [],
            'subscription_status': None,
            'subscription_renewed': False,
            'fallback_applied': False,
            'subscription_revoked': False,
            'permissions_cleaned': 0,
            'permissions_added': 0,
            'credits_updated': 0,
            'error': None,
            'original_subscription': None,
            'final_subscription': None,
            'updated_userstatus': None
        }

        try:
            # Phase 1: Pre-read for decision-making and early returns (non-transactional)
            userstatus = await self.get_userstatus(user_uid)
            if not userstatus:
                result['actions_taken'].append('no_userstatus_found')
                return result

            # Default to pre-read state (will be updated after transaction if changes occur)
            result['updated_userstatus'] = userstatus

            # Quick no-op: no subscription and no permission cleanup requested
            if not userstatus.active_subscription and not clean_expired_permissions:
                result['actions_taken'].append('no_active_subscription')
                return result

            # Phase 1b: Pre-fetch catalog data for potential fallback (async -- MUST be outside transaction)
            # Only fetch if pre-read suggests the subscription is expired and fallback might be needed
            prefetched_fallback_plan = None
            if (userstatus.active_subscription
                    and not userstatus.active_subscription.is_active()
                    and apply_fallback
                    and userstatus.active_subscription.fallback_plan_id
                    and self.subscription_ops):
                try:
                    # Resolve fallback plan (supports both plan_name and legacy versioned plan_id)
                    prefetched_fallback_plan = await self.subscription_ops.catalog_subscriptionplan_service.resolve_plan_by_reference(
                        userstatus.active_subscription.fallback_plan_id
                    )
                except Exception as e:
                    self.logger.warning(
                        "Failed to pre-fetch fallback plan %s for user %s: %s",
                        userstatus.active_subscription.fallback_plan_id, user_uid, e
                    )

            # Phase 2: All state mutations happen inside a Firestore transaction.
            # The mutation function receives FRESH data on each attempt (including retries),
            # preventing TOCTOU race conditions with concurrent requests.
            def _review_mutation(fresh_userstatus):
                """Mutation function applied to fresh userstatus inside the transaction."""
                meta = {
                    'original_subscription': fresh_userstatus.active_subscription,
                    'subscription_status': None,
                    'final_subscription': None,
                    'subscription_renewed': False,
                    'fallback_applied': False,
                    'subscription_revoked': False,
                    'credits_updated': 0,
                    'permissions_cleaned': 0,
                    'permissions_added': 0,
                    'actions_taken': [],
                    'error': None,
                    '_has_changes': False
                }

                # Branch A: No active subscription
                if not fresh_userstatus.active_subscription:
                    meta['actions_taken'].append('no_active_subscription')
                    if clean_expired_permissions:
                        expired = fresh_userstatus.cleanup_expired_permissions()
                        if expired > 0:
                            meta['permissions_cleaned'] = expired
                            meta['actions_taken'].append('cleaned_expired_permissions')
                            meta['_has_changes'] = True
                    return meta

                now = datetime.now(timezone.utc)

                # Branch B: Subscription still active
                if fresh_userstatus.active_subscription.is_active():
                    meta['subscription_status'] = str(SubscriptionStatus.ACTIVE)
                    meta['final_subscription'] = fresh_userstatus.active_subscription
                    meta['actions_taken'].append('subscription_still_active')

                    if review_credits:
                        credits = fresh_userstatus.update_subscription_credits()
                        if credits > 0:
                            meta['credits_updated'] = credits
                            meta['actions_taken'].append('updated_subscription_credits')
                            meta['_has_changes'] = True

                    if clean_expired_permissions:
                        expired = fresh_userstatus.cleanup_expired_permissions()
                        if expired > 0:
                            meta['permissions_cleaned'] = expired
                            meta['actions_taken'].append('cleaned_expired_permissions_only')
                            meta['_has_changes'] = True

                    return meta

                # Branch C: Subscription expired -- renewal, fallback, or revocation
                meta['_has_changes'] = True  # Expired subscription always requires state changes
                subscription = fresh_userstatus.active_subscription

                # C1: Auto-renewal attempt
                if (review_auto_renewal
                        and subscription.auto_renew_end_datetime
                        and now <= subscription.auto_renew_end_datetime
                        and now > subscription.cycle_end_datetime_safe):
                    try:
                        new_cycle_start = subscription.cycle_end_datetime_safe
                        subscription_dict = subscription.model_dump()
                        subscription_dict.update({
                            'cycle_start_datetime': new_cycle_start,
                            'cycle_end_datetime': None,
                            'updated_at': now,
                            'updated_by': f"UserstatusOperations.auto_renew:{updater_uid}"
                        })
                        renewed_subscription = UserSubscription(**subscription_dict)
                        fresh_userstatus.apply_subscription(
                            renewed_subscription,
                            add_associated_permissions=True,
                            remove_previous_subscription_permissions=True,
                            granted_by=f"UserstatusOperations.review.auto_renew:{updater_uid}"
                        )
                        meta['subscription_renewed'] = True
                        meta['subscription_status'] = str(fresh_userstatus.active_subscription.status)
                        meta['final_subscription'] = renewed_subscription
                        meta['actions_taken'].append('auto_renewed_cycle')
                    except (ValueError, UserStatusError) as renewal_error:
                        self.logger.error("Auto-renewal failed for user %s: %s", user_uid, renewal_error)
                        meta['error'] = f"Auto-renewal failed: {str(renewal_error)}"
                        meta['actions_taken'].append('auto_renewal_failed')

                # C2: Fallback plan application
                if not meta['subscription_renewed']:
                    if apply_fallback and subscription.fallback_plan_id:
                        if self.subscription_ops and prefetched_fallback_plan:
                            try:
                                fallback_subscription = self.subscription_ops.create_subscription_from_subscriptionplan(
                                    plan=prefetched_fallback_plan,
                                    source=f"fallback_from_{subscription.plan_id}:review:{updater_uid}",
                                    granted_at=now,
                                    auto_renewal_end=prefetched_fallback_plan.plan_default_auto_renewal_end
                                )
                                permissions_added = fresh_userstatus.apply_subscription(
                                    fallback_subscription,
                                    add_associated_permissions=True,
                                    remove_previous_subscription_permissions=True,
                                    granted_by=f"UserstatusOperations.review.fallback:{updater_uid}"
                                )
                                meta['fallback_applied'] = True
                                meta['subscription_status'] = str(fresh_userstatus.active_subscription.status)
                                meta['final_subscription'] = fallback_subscription
                                meta['permissions_added'] = permissions_added
                                meta['actions_taken'].append('applied_fallback_plan')
                            except (ValueError, UserStatusError) as fallback_error:
                                self.logger.error("Fallback application failed for user %s: %s", user_uid, fallback_error)
                                meta['error'] = f"Fallback failed: {str(fallback_error)}"
                                meta['actions_taken'].append('fallback_failed')
                        elif self.subscription_ops and not prefetched_fallback_plan:
                            self.logger.warning("Fallback plan %s not found for user %s", subscription.fallback_plan_id, user_uid)
                            meta['actions_taken'].append('fallback_plan_not_found')
                        else:
                            self.logger.warning("Cannot apply fallback - subscription_ops not available")
                            meta['actions_taken'].append('fallback_unavailable_no_subscription_ops')

                # C3: Revocation -- if neither renewal nor fallback succeeded
                if not meta['subscription_renewed'] and not meta['fallback_applied']:
                    permissions_cleaned = fresh_userstatus.revoke_subscription(remove_associated_permissions=True)
                    meta['subscription_revoked'] = True
                    meta['subscription_status'] = None
                    meta['permissions_cleaned'] = permissions_cleaned
                    meta['actions_taken'].append('subscription_revoked')

                # C4: Clean up all expired permissions
                if clean_expired_permissions:
                    additional_expired = fresh_userstatus.cleanup_expired_permissions()
                    if additional_expired > 0:
                        meta['permissions_cleaned'] += additional_expired
                        meta['actions_taken'].append('cleaned_additional_expired_permissions')

                return meta

            # Execute the mutation inside a Firestore transaction
            updated_userstatus, meta = self._mutate_userstatus_transactional(
                user_uid=user_uid,
                mutation_func=_review_mutation,
                updater_uid=f"review:{updater_uid}"
            )

            # Build result from transaction metadata
            result['original_subscription'] = meta.get('original_subscription')
            result['subscription_status'] = meta.get('subscription_status')
            result['final_subscription'] = meta.get('final_subscription')
            result['subscription_renewed'] = meta.get('subscription_renewed', False)
            result['fallback_applied'] = meta.get('fallback_applied', False)
            result['subscription_revoked'] = meta.get('subscription_revoked', False)
            result['credits_updated'] = meta.get('credits_updated', 0)
            result['permissions_cleaned'] = meta.get('permissions_cleaned', 0)
            result['permissions_added'] = meta.get('permissions_added', 0)
            result['actions_taken'] = meta.get('actions_taken', [])
            if meta.get('error'):
                result['error'] = meta['error']
            result['updated_userstatus'] = updated_userstatus

            self.logger.info(
                "Completed comprehensive review for user %s. Status: %s, Actions: %s",
                user_uid, result['subscription_status'], result['actions_taken']
            )

        except Exception as e:
            self.logger.error("Comprehensive review failed for user %s: %s", user_uid, e, exc_info=True)
            result['error'] = str(e)
            result['actions_taken'].append('review_failed')
            raise

        return result
