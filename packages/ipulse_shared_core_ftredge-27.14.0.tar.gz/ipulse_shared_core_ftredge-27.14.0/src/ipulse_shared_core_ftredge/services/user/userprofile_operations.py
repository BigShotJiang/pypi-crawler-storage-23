"""
User Profile Operations - CRUD operations for UserProfile
"""
import os
import logging
from typing import Dict, Any, List, Optional
from google.cloud import firestore
from pydantic import ValidationError as PydanticValidationError

from ...models import UserProfile
from ...exceptions import ResourceNotFoundError, UserProfileError
from ..base import BaseFirestoreService


class UserprofileOperations:
    """
    Handles CRUD operations for UserProfile documents
    """

    def __init__(
        self,
        firestore_client: firestore.Client,
        logger: Optional[logging.Logger] = None,
        timeout: float = 10.0,
        profile_collection: Optional[str] = None,
    ):
        collection_name = profile_collection or UserProfile.get_collection_name()
        self.db_service = BaseFirestoreService[UserProfile](
            db=firestore_client,
            collection_name=collection_name,
            resource_type="UserProfile",
            model_class=UserProfile,
            logger=logger,
            timeout=timeout
        )
        self.logger = logger or logging.getLogger(__name__)
        self.profile_collection_name = collection_name

        # Archival configuration
        self.archive_profile_on_delete = os.getenv('ARCHIVE_PROFILE_ON_DELETE', 'true').lower() == 'true'
        self.archive_profile_collection_name = os.getenv(
            'ARCHIVE_PROFILE_COLLECTION_NAME',
            f"~archive_{self.profile_collection_name}"
        )

    async def get_userprofile(self, user_uid: str) -> Optional[UserProfile]:
        """Fetches a user profile from Firestore."""
        self.logger.info(f"Fetching user profile for UID: {user_uid}")
        try:
            profile_data = await self.db_service.get_document(f"{UserProfile.OBJ_REF}_{user_uid}", convert_to_model=True)
            if profile_data and isinstance(profile_data, UserProfile):
                return profile_data
            return None
        except ResourceNotFoundError:
            self.logger.warning(f"UserProfile not found for UID: {user_uid}")
            return None
        except Exception as e:
            self.logger.error("Error fetching user profile for %s: %s", user_uid, e, exc_info=True)
            raise UserProfileError(
                detail=f"Failed to fetch user profile: {str(e)}",
                user_uid=user_uid,
                operation="get_userprofile",
                original_error=e
            ) from e

    async def create_userprofile(self, userprofile: UserProfile, creator_uid: Optional[str] = None) -> UserProfile:
        """Creates a new user profile in Firestore."""
        self.logger.info(f"Creating user profile for UID: {userprofile.user_uid}")
        try:
            doc_id = f"{UserProfile.OBJ_REF}_{userprofile.user_uid}"
            effective_creator_uid = creator_uid or userprofile.user_uid
            await self.db_service.create_document(doc_id, userprofile.model_dump(exclude_none=True), creator_uid=effective_creator_uid)
            self.logger.info(f"Successfully created user profile for UID: {userprofile.user_uid}")
            return userprofile
        except Exception as e:
            self.logger.error(f"Error creating user profile for {userprofile.user_uid}: {e}", exc_info=True)
            raise UserProfileError(
                detail=f"Failed to create user profile: {str(e)}",
                user_uid=userprofile.user_uid,
                operation="create_userprofile",
                original_error=e
            )

    async def update_userprofile(self, user_uid: str, profile_data: Dict[str, Any], updater_uid: str) -> UserProfile:
        """Updates an existing user profile in Firestore."""
        self.logger.info(f"Updating user profile for UID: {user_uid}")
        try:
            doc_id = f"{UserProfile.OBJ_REF}_{user_uid}"
            await self.db_service.update_document(doc_id, profile_data, updater_uid)
            updated_profile = await self.get_userprofile(user_uid)
            if not updated_profile:
                raise ResourceNotFoundError(
                    resource_type="UserProfile",
                    resource_id=doc_id
                )
            self.logger.info(f"Successfully updated user profile for UID: {user_uid}")
            return updated_profile
        except ResourceNotFoundError as e:
            self.logger.error(f"Cannot update non-existent user profile for {user_uid}")
            raise e
        except Exception as e:
            self.logger.error(f"Error updating user profile for {user_uid}: {e}", exc_info=True)
            raise UserProfileError(
                detail=f"Failed to update user profile: {str(e)}",
                user_uid=user_uid,
                operation="update_userprofile",
                original_error=e
            )

    async def delete_userprofile(self, user_uid: str, updater_uid: str = "system_deletion", archive: bool = True) -> bool:
        """Delete (archive and delete) user profile"""
        profile_doc_id = f"{UserProfile.OBJ_REF}_{user_uid}"
        should_archive = archive if archive is not None else self.archive_profile_on_delete

        try:
            if should_archive:
                deleted = await self.db_service.archive_and_delete_document(
                    doc_id=profile_doc_id,
                    archive_collection=self.archive_profile_collection_name,
                    archived_by=updater_uid,
                    require_exists=False,
                )
                if not deleted:
                    self.logger.warning(f"User profile {profile_doc_id} not found for deletion")
                    return True
                self.logger.info(f"Successfully archived and deleted user profile: {profile_doc_id}")
                return True

            await self.db_service.delete_document(profile_doc_id, require_exists=False)
            self.logger.info(f"Successfully deleted user profile without archival: {profile_doc_id}")
            return True

        except Exception as e:
            self.logger.error(f"Failed to delete user profile {profile_doc_id}: {e}", exc_info=True)
            raise UserProfileError(
                detail=f"Failed to delete user profile: {str(e)}",
                user_uid=user_uid,
                operation="delete_userprofile",
                original_error=e
            )



    async def list_userprofiles(
        self,
        limit: int = 50,
        offset: int = 0,
        user_type_filter: Optional[str] = None,
    ) -> List[UserProfile]:
        """List user profiles with pagination and optional usertype filter.

        Args:
            limit: Maximum number of profiles to return
            offset: Number of profiles to skip
            user_type_filter: Optional primary_usertype value to filter by

        Returns:
            List of UserProfile models
        """
        filters = []
        if user_type_filter:
            filters.append(("primary_usertype", "==", user_type_filter.lower()))

        # BaseFirestoreService.list_documents handles querying and model conversion
        all_docs = await self.db_service.list_documents(
            filters=filters if filters else None,
            as_models=True,
        )
        # Apply offset/limit in Python (Firestore doesn't support native offset)
        return all_docs[offset:offset + limit]

    async def batch_update_userprofiles(
        self,
        updates: List[Dict[str, Any]],
        updater_uid: str,
    ) -> Dict[str, Any]:
        """Batch update user profiles.

        Args:
            updates: List of dicts, each containing 'user_uid' and fields to update
            updater_uid: UID of the user performing the update

        Returns:
            Dict with 'successful' (list of UIDs) and 'failed' (dict of UID to error)
        """
        successful: List[str] = []
        failed: Dict[str, str] = {}

        for update_item in updates:
            user_uid = update_item.get("user_uid")
            if not user_uid:
                failed[f"idx_{len(successful) + len(failed)}"] = "Missing user_uid"
                continue

            profile_updates = update_item.get("profile_updates", update_item)
            if not isinstance(profile_updates, dict):
                failed[user_uid] = "profile_updates must be a dict"
                continue

            profile_updates = profile_updates.copy()
            profile_updates.pop("user_uid", None)

            try:
                await self.update_userprofile(user_uid=user_uid, profile_data=profile_updates, updater_uid=updater_uid)
                successful.append(user_uid)
            except Exception as exc:
                failed[user_uid] = str(exc)

        return {"successful": successful, "failed": failed}

    async def batch_delete_userprofiles(
        self,
        user_uids: List[str],
        updater_uid: str,
        archive: bool = True,
    ) -> Dict[str, Any]:
        """Batch delete user profiles.

        Args:
            user_uids: List of user UIDs to delete
            updater_uid: UID of the user performing the deletion
            archive: Whether to archive before deleting

        Returns:
            Dict with 'successful' (list of UIDs) and 'failed' (dict of UID to error)
        """
        successful: List[str] = []
        failed: Dict[str, str] = {}

        for user_uid in user_uids:
            try:
                await self.delete_userprofile(user_uid=user_uid, updater_uid=updater_uid, archive=archive)
                successful.append(user_uid)
            except Exception as exc:
                failed[user_uid] = str(exc)

        return {"successful": successful, "failed": failed}

    async def userprofile_exists(self, user_uid: str) -> bool:
        """Check if a user profile exists."""
        return await self.db_service.document_exists(f"{UserProfile.OBJ_REF}_{user_uid}")

    async def validate_userprofile_data(
        self,
        profile_data: Optional[Dict[str, Any]] = None,
    ) -> tuple[bool, list[str]]:
        """Validate user profile data without creating documents"""
        errors = []
        if profile_data:
            try:
                UserProfile(**profile_data)
            except PydanticValidationError as e:
                errors.append(f"Profile validation error: {str(e)}")
        return len(errors) == 0, errors