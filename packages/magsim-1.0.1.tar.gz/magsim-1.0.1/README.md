# magsim
Models and simulates Magical Athlete races

## Changelog
See the [CHANGELOG.md](https://github.com/pschonev/magical-athlete-simulator/blob/main/CHANGELOG.md) for version history.
