// Minimal config.h stub for the Python extension module

#ifndef INC_CONFIG_H_
#define INC_CONFIG_H_

#define VERSION "1.6.10"
#define MAINTAINER "pat@mousebrains.com"

#define HAVE_INT8_T

#endif // INC_CONFIG_H_
