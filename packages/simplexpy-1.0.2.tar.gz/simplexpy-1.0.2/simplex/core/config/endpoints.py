from dataclasses import dataclass
from simplex.core.config.environment import Environment, ENVIRONMENT

LICENSE_PREFIX = "api-foundation/"
MATERIAL_PREFIX = "foundation/"

@dataclass(frozen=True)
class Endpoint:
    path: str
    environment: Environment = ENVIRONMENT
    prefix: str = LICENSE_PREFIX

    @property
    def url(self) -> str:
        return f"{self.environment.base_url}{self.prefix}{self.path}"

class _EurocodeEndpoints:
    update_gammas = Endpoint("eurocode/EN/gamma/")

class _FoundationEndpoints:
    soil_control = Endpoint("foundation/soilCtrl/", prefix=LICENSE_PREFIX)
    rc_control = Endpoint("foundation/rcCtrl/", prefix=LICENSE_PREFIX)
    geo_design = Endpoint("foundation/geoDesign/", prefix=LICENSE_PREFIX)
    rc_design = Endpoint("foundation/rcDesign/", prefix=LICENSE_PREFIX)

class _BeamEndpoints:
     analysis = Endpoint("beam/analysis/")
     design = Endpoint("beam/design/")

class _MaterialEndpoints:
    all = Endpoint("asset/api/v1/materials/list", prefix=MATERIAL_PREFIX)

    def get(self, GUID: str) -> Endpoint:
        """
        Returns the endpoint for a specific material GUID.

        Args:
            GUID (str): The GUID of the material.

        Returns:
            Endpoint: The endpoint for the material.
        """
        return Endpoint(f"asset/api/v1/materials/{GUID}", prefix=MATERIAL_PREFIX)


class Endpoints:
    eurocode = _EurocodeEndpoints()
    foundation = _FoundationEndpoints()
    beam = _BeamEndpoints()
    material = _MaterialEndpoints()