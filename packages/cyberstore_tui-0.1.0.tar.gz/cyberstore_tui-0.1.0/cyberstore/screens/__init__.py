"""CyberStore screen components."""
