"""CyberStore widget components."""
