"""CyberStore - Object Storage TUI client (Cloudflare R2 / Aliyun OSS)."""

__version__ = "0.1.0"
