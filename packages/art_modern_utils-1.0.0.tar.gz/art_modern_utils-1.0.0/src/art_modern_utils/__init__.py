__version__ = "1.0.0"

QUAL_MAX = 71
