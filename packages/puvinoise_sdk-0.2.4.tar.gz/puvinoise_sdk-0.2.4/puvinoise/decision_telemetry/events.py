"""
Decision telemetry event model and common envelope.
Schema: trace_id, span_id, agent_id, session_id, timestamp, model_used, prompt_hash, decision_metadata.
All events use the same envelope; decision_metadata is type-specific.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


def _timestamp_ns() -> int:
    """Current time in nanoseconds since epoch (OTEL convention)."""
    return int(time.time() * 1e9)


def _otel_value(v: Any) -> Any:
    """Ensure value is OTEL-compatible (string, int, float, bool)."""
    if v is None:
        return None
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return v
    return str(v)


def flatten_attributes(attrs: Dict[str, Any]) -> Dict[str, Any]:
    """Convert attributes dict to OTEL-safe primitives."""
    return {k: _otel_value(v) for k, v in attrs.items() if _otel_value(v) is not None}


def flatten_decision_metadata(metadata: Dict[str, Any], prefix: str = "decision_metadata.") -> Dict[str, Any]:
    """Flatten decision_metadata for OTEL; list/dict as JSON string."""
    out = {}
    for k, v in metadata.items():
        if v is None:
            continue
        key = f"{prefix}{k}"
        if isinstance(v, (list, dict)):
            out[key] = json.dumps(v) if not isinstance(v, str) else v
        else:
            out[key] = _otel_value(v)
    return out


# ---------------------------------------------------------------------------
# Envelope (common fields for every event)
# ---------------------------------------------------------------------------

@dataclass
class DecisionEventEnvelope:
    """Common envelope for all decision telemetry events."""
    trace_id: str
    span_id: str
    agent_id: str
    timestamp_ns: int
    session_id: Optional[str] = None
    model_used: Optional[str] = None
    prompt_hash: Optional[str] = None
    turn_index: Optional[int] = None
    message_id: Optional[str] = None

    def to_otel_attributes(self) -> Dict[str, Any]:
        attrs = {
            "trace_id": self.trace_id,
            "span_id": self.span_id,
            "agent_id": self.agent_id,
            "timestamp_ns": self.timestamp_ns,
        }
        if self.session_id is not None:
            attrs["session_id"] = self.session_id
        if self.model_used is not None:
            attrs["model_used"] = self.model_used
        if self.prompt_hash is not None:
            attrs["prompt_hash"] = self.prompt_hash
        if self.turn_index is not None:
            attrs["turn_index"] = int(self.turn_index)
        if self.message_id is not None:
            attrs["message_id"] = str(self.message_id)[:200]
        return attrs


# ---------------------------------------------------------------------------
# 1. Intent detection event
# ---------------------------------------------------------------------------

@dataclass
class IntentDetectionEvent:
    """decision.intent_detection"""
    intent: str
    goal: Optional[str] = None
    task_type: Optional[str] = None
    confidence: Optional[float] = None

    def decision_metadata(self) -> Dict[str, Any]:
        m = {"intent": self.intent}
        if self.goal is not None:
            m["goal"] = self.goal
        if self.task_type is not None:
            m["task_type"] = self.task_type
        if self.confidence is not None:
            m["confidence"] = float(self.confidence)
        return m


# ---------------------------------------------------------------------------
# 2. Tool candidate ranking event
# ---------------------------------------------------------------------------

@dataclass
class ToolCandidateRankingEvent:
    """decision.tool_candidate_ranking"""
    candidates: List[str]
    rankings: Optional[List[str]] = None
    selected: Optional[str] = None
    reasoning: Optional[str] = None
    confidence: Optional[float] = None

    def decision_metadata(self) -> Dict[str, Any]:
        m = {"candidates": self.candidates}
        if self.rankings is not None:
            m["rankings"] = self.rankings
        if self.selected is not None:
            m["selected"] = self.selected
        if self.reasoning is not None:
            m["reasoning"] = str(self.reasoning)[:500]
        if self.confidence is not None:
            m["confidence"] = float(self.confidence)
        return m


# ---------------------------------------------------------------------------
# 3. Reasoning checkpoint event (standard structure + depth)
# ---------------------------------------------------------------------------

# Standard checkpoint types — when to emit
CHECKPOINT_TYPE_LLM_REASONING_FINISHED = "llm_reasoning_finished"
CHECKPOINT_TYPE_PLAN_STEP = "plan_step"
CHECKPOINT_TYPE_TOOL_DECISION = "tool_decision"
CHECKPOINT_TYPE_RETRY = "retry"
CHECKPOINT_TYPE_FALLBACK = "fallback"

CHECKPOINT_TYPES = (
    CHECKPOINT_TYPE_LLM_REASONING_FINISHED,
    CHECKPOINT_TYPE_PLAN_STEP,
    CHECKPOINT_TYPE_TOOL_DECISION,
    CHECKPOINT_TYPE_RETRY,
    CHECKPOINT_TYPE_FALLBACK,
)


@dataclass
class ReasoningCheckpointEvent:
    """
    decision.reasoning_checkpoint — standard reasoning checkpoint structure.
    Emit when: LLM finishes reasoning, plan step is generated, tool decision is made,
    a retry occurs, or a fallback happens. depth = current reasoning depth (from context).
    """
    checkpoint_type: str  # one of CHECKPOINT_TYPES
    checkpoint_name: Optional[str] = None  # optional label e.g. "before_tool_choice"
    summary: Optional[str] = None
    step_index: Optional[int] = None
    depth: Optional[int] = None  # reasoning depth at time of checkpoint
    metadata: Optional[Dict[str, Any]] = None  # type-specific: tool_name, retry_count, etc.

    def decision_metadata(self) -> Dict[str, Any]:
        m = {"checkpoint_type": self.checkpoint_type}
        if self.checkpoint_name is not None:
            m["checkpoint_name"] = str(self.checkpoint_name)[:200]
        if self.summary is not None:
            m["summary"] = str(self.summary)[:500]
        if self.step_index is not None:
            m["step_index"] = int(self.step_index)
        if self.depth is not None:
            m["depth"] = int(self.depth)
        if self.metadata:
            for k, v in list(self.metadata.items())[:10]:
                if v is not None:
                    key = f"meta_{k}"
                    m[key] = str(v)[:200] if not isinstance(v, (int, float, bool)) else v
        return m


# ---------------------------------------------------------------------------
# 4. Tool selection event
# ---------------------------------------------------------------------------

@dataclass
class ToolSelectionEvent:
    """decision.tool_selection"""
    tool_name: str
    reasoning: str
    confidence: Optional[float] = None

    def decision_metadata(self) -> Dict[str, Any]:
        m = {"tool_name": self.tool_name, "reasoning": str(self.reasoning)[:500]}
        if self.confidence is not None:
            m["confidence"] = float(self.confidence)
        return m


# ---------------------------------------------------------------------------
# 5. Confidence score event
# ---------------------------------------------------------------------------

@dataclass
class ConfidenceScoreEvent:
    """decision.confidence_score"""
    confidence: float
    scope: str = "turn"

    def decision_metadata(self) -> Dict[str, Any]:
        return {"confidence": float(self.confidence), "scope": self.scope}


# ---------------------------------------------------------------------------
# 6. Agent step transition event
# ---------------------------------------------------------------------------

@dataclass
class AgentStepTransitionEvent:
    """decision.agent_step_transition"""
    from_state: str
    to_state: str
    reason: Optional[str] = None

    def decision_metadata(self) -> Dict[str, Any]:
        m = {"from_state": self.from_state, "to_state": self.to_state}
        if self.reason is not None:
            m["reason"] = str(self.reason)[:200]
        return m


# ---------------------------------------------------------------------------
# Legacy aliases (same payload, old event names / helpers)
# ---------------------------------------------------------------------------

IntentClassification = IntentDetectionEvent
ToolCandidates = ToolCandidateRankingEvent
ReasoningCheckpoint = ReasoningCheckpointEvent
DecisionConfidence = ConfidenceScoreEvent
ToolSelectionReasoning = ToolSelectionEvent
AgentStateTransition = AgentStepTransitionEvent


# ---------------------------------------------------------------------------
# 7. Retrieval ranking (for auto-capture interceptors)
# ---------------------------------------------------------------------------

@dataclass
class RetrievalRankingEvent:
    """decision.retrieval_ranking — ordered list of retrieved doc ids/snippets and optional scores."""
    query_summary: str  # truncated query or hash
    doc_ids: List[str]  # ordered by rank
    scores: Optional[List[float]] = None
    top_k: Optional[int] = None

    def decision_metadata(self) -> Dict[str, Any]:
        m = {"query_summary": str(self.query_summary)[:200], "doc_ids": self.doc_ids}
        if self.scores is not None:
            m["scores"] = self.scores
        if self.top_k is not None:
            m["top_k"] = int(self.top_k)
        return m


# ---------------------------------------------------------------------------
# 8. Tool execution result (for auto-capture interceptors)
# ---------------------------------------------------------------------------

@dataclass
class ToolExecutionResultEvent:
    """decision.tool_execution_result — outcome of a tool call."""
    tool_name: str
    success: bool
    result_summary: Optional[str] = None
    duration_ms: Optional[float] = None
    error_code: Optional[str] = None

    def decision_metadata(self) -> Dict[str, Any]:
        m = {"tool_name": self.tool_name, "success": self.success}
        if self.result_summary is not None:
            m["result_summary"] = str(self.result_summary)[:500]
        if self.duration_ms is not None:
            m["duration_ms"] = float(self.duration_ms)
        if self.error_code is not None:
            m["error_code"] = str(self.error_code)[:100]
        return m


# ---------------------------------------------------------------------------
# 9. Structured failure (root cause)
# ---------------------------------------------------------------------------

FAILURE_CATEGORY_TIMEOUT = "timeout"
FAILURE_CATEGORY_RATE_LIMIT = "rate_limit"
FAILURE_CATEGORY_CONTENT_FILTER = "content_filter"
FAILURE_CATEGORY_TOKEN_LIMIT = "token_limit"
FAILURE_CATEGORY_TOOL_ERROR = "tool_error"
FAILURE_CATEGORY_RETRIEVAL_ERROR = "retrieval_error"
FAILURE_CATEGORY_AUTH_ERROR = "auth_error"
FAILURE_CATEGORY_BAD_REQUEST = "bad_request"
FAILURE_CATEGORY_UNKNOWN = "unknown"

FAILURE_CATEGORIES = (
    FAILURE_CATEGORY_TIMEOUT,
    FAILURE_CATEGORY_RATE_LIMIT,
    FAILURE_CATEGORY_CONTENT_FILTER,
    FAILURE_CATEGORY_TOKEN_LIMIT,
    FAILURE_CATEGORY_TOOL_ERROR,
    FAILURE_CATEGORY_RETRIEVAL_ERROR,
    FAILURE_CATEGORY_AUTH_ERROR,
    FAILURE_CATEGORY_BAD_REQUEST,
    FAILURE_CATEGORY_UNKNOWN,
)


@dataclass
class FailureEvent:
    """decision.failure — structured failure for root cause analysis."""
    category: str  # one of FAILURE_CATEGORIES
    code: Optional[str] = None
    message: Optional[str] = None

    def decision_metadata(self) -> Dict[str, Any]:
        m = {"category": str(self.category)[:100]}
        if self.code is not None:
            m["code"] = str(self.code)[:100]
        if self.message is not None:
            m["message"] = str(self.message)[:500]
        return m


# ---------------------------------------------------------------------------
# 10. User/business outcome
# ---------------------------------------------------------------------------

OUTCOME_SOURCE_SYSTEM = "system"
OUTCOME_SOURCE_USER_FEEDBACK = "user_feedback"
OUTCOME_SOURCE_BUSINESS_RULE = "business_rule"


@dataclass
class OutcomeEvent:
    """decision.outcome — explicit success/failure from user or business logic."""
    success: bool
    source: str = OUTCOME_SOURCE_SYSTEM  # system | user_feedback | business_rule
    confidence: Optional[float] = None

    def decision_metadata(self) -> Dict[str, Any]:
        m = {"success": self.success, "source": str(self.source)[:50]}
        if self.confidence is not None:
            m["confidence"] = float(self.confidence)
        return m


# ---------------------------------------------------------------------------
# 11. Guardrail triggered
# ---------------------------------------------------------------------------

GUARDRAIL_TYPE_CONTENT_FILTER = "content_filter"
GUARDRAIL_TYPE_POLICY_VIOLATION = "policy_violation"
GUARDRAIL_TYPE_PII_REDACTION = "pii_redaction"
GUARDRAIL_TYPE_SAFETY_BLOCK = "safety_block"

GUARDRAIL_ACTION_BLOCK = "block"
GUARDRAIL_ACTION_REWRITE = "rewrite"
GUARDRAIL_ACTION_WARN = "warn"


@dataclass
class GuardrailTriggeredEvent:
    """decision.guardrail_triggered — content filter, policy, safety."""
    type: str  # content_filter | policy_violation | pii_redaction | safety_block
    action: str  # block | rewrite | warn
    rule_id: Optional[str] = None
    detail: Optional[str] = None

    def decision_metadata(self) -> Dict[str, Any]:
        m = {"type": str(self.type)[:50], "action": str(self.action)[:50]}
        if self.rule_id is not None:
            m["rule_id"] = str(self.rule_id)[:100]
        if self.detail is not None:
            m["detail"] = str(self.detail)[:200]
        return m
