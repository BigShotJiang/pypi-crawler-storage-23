"""
Emit decision telemetry to the current OpenTelemetry span (attributes and events).
Optimized for high-frequency (e.g. every second per agent):
- Async: events can be queued and emitted by a background thread to avoid blocking agent execution.
- Batching: handled by OTEL BatchSpanProcessor (see bootstrap).
- Set PUVINOISE_TELEMETRY_SYNC=1 to force synchronous emission (no queue).
"""

from __future__ import annotations

import logging
import os
import queue
import threading
import time
from typing import Optional

from opentelemetry import trace

from puvinoise.context import AgentContext
from puvinoise.decision_telemetry.events import (
    IntentDetectionEvent,
    ToolCandidateRankingEvent,
    ReasoningCheckpointEvent,
    CHECKPOINT_TYPE_LLM_REASONING_FINISHED,
    CHECKPOINT_TYPE_PLAN_STEP,
    CHECKPOINT_TYPE_TOOL_DECISION,
    CHECKPOINT_TYPE_RETRY,
    CHECKPOINT_TYPE_FALLBACK,
    CHECKPOINT_TYPES,
    ToolSelectionEvent,
    ConfidenceScoreEvent,
    AgentStepTransitionEvent,
    RetrievalRankingEvent,
    ToolExecutionResultEvent,
    FailureEvent,
    OutcomeEvent,
    GuardrailTriggeredEvent,
    FAILURE_CATEGORIES,
    OUTCOME_SOURCE_SYSTEM,
    OUTCOME_SOURCE_USER_FEEDBACK,
    OUTCOME_SOURCE_BUSINESS_RULE,
    DecisionEventEnvelope,
    flatten_decision_metadata,
)

logger = logging.getLogger(__name__)

_USE_SYNC_EMIT = os.getenv("PUVINOISE_TELEMETRY_SYNC", "").strip().lower() in ("1", "true", "yes")
_DECISION_QUEUE: Optional[queue.Queue] = None
_QUEUE_MAX_SIZE = int(os.getenv("PUVINOISE_TELEMETRY_QUEUE_SIZE", "16384"))
_DRAIN_BATCH_SIZE = 64
_worker_thread: Optional[threading.Thread] = None
_worker_ready = threading.Event()
_dropped_events: int = 0
_emitted_events: int = 0
_emit_errors: int = 0
_dropped_lock = threading.Lock()
_stats_lock = threading.Lock()

_BACKPRESSURE_HIGH_WATERMARK = int(_QUEUE_MAX_SIZE * 0.85)
_BACKPRESSURE_LOW_WATERMARK = int(_QUEUE_MAX_SIZE * 0.50)
_backpressured: bool = False


def get_dropped_event_count() -> int:
    """Return the number of events dropped due to queue overflow."""
    return _dropped_events


def get_telemetry_stats() -> dict:
    """Return SDK-side telemetry health stats."""
    q = _DECISION_QUEUE
    return {
        "emitted": _emitted_events,
        "dropped": _dropped_events,
        "errors": _emit_errors,
        "queue_size": q.qsize() if q else 0,
        "queue_capacity": _QUEUE_MAX_SIZE,
        "backpressured": _backpressured,
        "worker_alive": _worker_thread is not None and _worker_thread.is_alive(),
    }


def _get_decision_queue() -> queue.Queue:
    global _DECISION_QUEUE
    if _DECISION_QUEUE is None:
        _DECISION_QUEUE = queue.Queue(maxsize=_QUEUE_MAX_SIZE)
    return _DECISION_QUEUE


def _decision_worker() -> None:
    """Background thread: batch-drain queue and call span.add_event in tight loops."""
    global _emitted_events, _emit_errors, _backpressured
    q = _get_decision_queue()
    batch: list = []
    while True:
        try:
            item = q.get()
            if item is None:
                q.task_done()
                break
            batch.append(item)
            while len(batch) < _DRAIN_BATCH_SIZE:
                try:
                    batch.append(q.get_nowait())
                except queue.Empty:
                    break

            emitted = 0
            for span, event_name, attrs in batch:
                try:
                    if span and span.is_recording():
                        span.add_event(event_name, attrs)
                        emitted += 1
                except Exception:
                    with _stats_lock:
                        _emit_errors += 1

            with _stats_lock:
                _emitted_events += emitted

            for _ in batch:
                q.task_done()
            batch.clear()

            qsize = q.qsize()
            if _backpressured and qsize < _BACKPRESSURE_LOW_WATERMARK:
                _backpressured = False
            elif not _backpressured and qsize >= _BACKPRESSURE_HIGH_WATERMARK:
                _backpressured = True
                logger.warning("Telemetry queue backpressure: %d/%d", qsize, _QUEUE_MAX_SIZE)

        except Exception as e:
            logger.debug("Decision worker: %s", e)
            for _ in batch:
                try:
                    q.task_done()
                except ValueError:
                    pass
            batch.clear()


def _start_decision_worker_if_needed() -> None:
    global _worker_thread
    if _worker_ready.is_set():
        return
    _worker_ready.set()
    _worker_thread = threading.Thread(target=_decision_worker, daemon=True, name="puvinoise-decision-emit")
    _worker_thread.start()


_cached_queue: Optional[queue.Queue] = None


def _enqueue_or_emit(span, event_name: str, attrs: dict) -> None:
    """Route event to sync emit or async queue. Never raises."""
    if _USE_SYNC_EMIT:
        span.add_event(event_name, attrs)
    else:
        global _cached_queue
        _start_decision_worker_if_needed()
        q = _cached_queue
        if q is None:
            q = _get_decision_queue()
            _cached_queue = q
        try:
            q.put_nowait((span, event_name, attrs))
        except queue.Full:
            global _dropped_events
            with _dropped_lock:
                _dropped_events += 1
            if _dropped_events <= 10 or _dropped_events % 1000 == 0:
                logger.warning("Decision telemetry queue full, event dropped (total dropped: %d)", _dropped_events)


def _emit_with_envelope(event_name: str, decision_metadata: dict, span=None) -> None:
    """Emit event with full schema envelope + decision_metadata. Async by default to avoid blocking. Never raises."""
    try:
        if span is None:
            span = trace.get_current_span()
        if not span or not span.is_recording():
            return
        ctx = span.get_span_context()
        trace_id, span_id = _trace_span_id_to_hex(ctx)
        agent_id = AgentContext.get_agent_name() or AgentContext.get_run_id() or "unknown"
        timestamp_ns = int(time.time() * 1e9)
        envelope = DecisionEventEnvelope(
            trace_id=trace_id,
            span_id=span_id,
            agent_id=agent_id,
            timestamp_ns=timestamp_ns,
            session_id=AgentContext.get_session_id(),
            model_used=AgentContext.get_model_used(),
            prompt_hash=AgentContext.get_prompt_hash(),
            turn_index=AgentContext.get_turn_index(),
            message_id=AgentContext.get_message_id(),
        )
        attrs = envelope.to_otel_attributes()
        attrs.update(flatten_decision_metadata(decision_metadata))
        _enqueue_or_emit(span, event_name, attrs)
    except Exception as e:
        logger.debug("Decision telemetry emit skipped: %s", e)

# Canonical event names (schema)
EVENT_INTENT_DETECTION = "decision.intent_detection"
EVENT_TOOL_CANDIDATE_RANKING = "decision.tool_candidate_ranking"
EVENT_REASONING_CHECKPOINT = "decision.reasoning_checkpoint"
EVENT_TOOL_SELECTION = "decision.tool_selection"
EVENT_CONFIDENCE_SCORE = "decision.confidence_score"
EVENT_AGENT_STEP_TRANSITION = "decision.agent_step_transition"
EVENT_RETRIEVAL_RANKING = "decision.retrieval_ranking"
EVENT_TOOL_EXECUTION_RESULT = "decision.tool_execution_result"
EVENT_FAILURE = "decision.failure"
EVENT_OUTCOME = "decision.outcome"
EVENT_GUARDRAIL_TRIGGERED = "decision.guardrail_triggered"


def _trace_span_id_to_hex(span_context) -> tuple[str, str]:
    """Get trace_id and span_id as hex strings from OTEL SpanContext."""
    try:
        tid = getattr(span_context, "trace_id", None) or 0
        sid = getattr(span_context, "span_id", None) or 0
        if isinstance(tid, int):
            tid = format(tid, "032x")
        if isinstance(sid, int):
            sid = format(sid, "016x")
        return str(tid), str(sid)
    except Exception:
        return "0" * 32, "0" * 16


def _set_span_attr_safe(span, key: str, value) -> None:
    """Set one span attribute; never raise."""
    try:
        if span and span.is_recording() and value is not None:
            span.set_attribute(key, value)
    except Exception:
        pass


def _clamp_confidence(c: Optional[float]) -> Optional[float]:
    """Clamp confidence to [0, 1] or return None."""
    if c is None:
        return None
    try:
        f = float(c)
        return max(0.0, min(1.0, f))
    except (TypeError, ValueError):
        return None


def flush_decision_events(timeout_seconds: float = 5.0) -> bool:
    """
    Wait for queued decision events to be emitted (async mode only). Returns True when queue is drained or timeout.
    Call before process exit to reduce event loss. No-op if PUVINOISE_TELEMETRY_SYNC=1.
    """
    if _USE_SYNC_EMIT or _DECISION_QUEUE is None:
        return True
    try:
        q = _get_decision_queue()
        deadline = time.monotonic() + timeout_seconds
        while time.monotonic() < deadline and q.qsize() > 0:
            time.sleep(0.05)
        return q.qsize() == 0
    except Exception:
        return False


def record_intent_classification(
    intent: str,
    goal: str | None = None,
    task_type: str | None = None,
    confidence: float | None = None,
) -> None:
    """
    Record intent classification. Emits an OpenTelemetry span event on the current trace span.
    Event: decision.intent_detection. Never raises.
    """
    try:
        intent_str = str(intent).strip() if intent else ""
        if not intent_str:
            return
        span = trace.get_current_span()
        if not span or not span.is_recording():
            return
        conf = _clamp_confidence(confidence)
        ev = IntentDetectionEvent(
            intent=intent_str,
            goal=str(goal).strip()[:500] if goal else None,
            task_type=str(task_type).strip()[:200] if task_type else None,
            confidence=conf,
        )
        _emit_with_envelope(EVENT_INTENT_DETECTION, ev.decision_metadata(), span=span)
        _set_span_attr_safe(span, "agent.intent", intent_str)
        if goal is not None:
            _set_span_attr_safe(span, "agent.goal", str(goal)[:500])
        if task_type is not None:
            _set_span_attr_safe(span, "agent.task_type", str(task_type)[:200])
            _set_span_attr_safe(span, "agent.task", str(task_type)[:200])
        if conf is not None:
            _set_span_attr_safe(span, "decision.intent_confidence", conf)
    except Exception as e:
        logger.debug("record_intent_classification skipped: %s", e)


def record_tool_candidates(
    candidates: list[str],
    selected_name: str | None = None,
    reasoning: str | None = None,
    confidence: float | None = None,
) -> None:
    """
    Record tool candidates considered. Emits an OpenTelemetry span event on the current trace span.
    Event: decision.tool_candidate_ranking. Never raises.
    """
    try:
        if not candidates:
            return
        names = [str(c).strip() for c in candidates if str(c).strip()]
        if not names:
            return
        conf = _clamp_confidence(confidence)
        ev = ToolCandidateRankingEvent(
            candidates=names,
            selected=str(selected_name).strip()[:200] if selected_name else None,
            reasoning=str(reasoning)[:500] if reasoning else None,
            confidence=conf,
        )
        _emit_with_envelope(EVENT_TOOL_CANDIDATE_RANKING, ev.decision_metadata())
    except Exception as e:
        logger.debug("record_tool_candidates skipped: %s", e)


def record_reasoning_checkpoint(
    checkpoint_type_or_name: str,
    summary: str | None = None,
    step_index: int | None = None,
    *,
    checkpoint_name: str | None = None,
    depth: int | None = None,
    metadata: dict | None = None,
) -> None:
    """
    Record a reasoning checkpoint (standard structure). Emits decision.reasoning_checkpoint.
    checkpoint_type_or_name: one of llm_reasoning_finished, plan_step, tool_decision, retry, fallback,
    or a custom label (then checkpoint_type=custom). depth defaults to current reasoning depth from context.
    Never raises.
    """
    try:
        ct = str(checkpoint_type_or_name).strip() if checkpoint_type_or_name else ""
        if not ct:
            return
        if ct not in CHECKPOINT_TYPES:
            name = ct
            ct = "custom"
        else:
            name = checkpoint_name
        step = None
        if step_index is not None:
            try:
                step = int(step_index)
            except (TypeError, ValueError):
                pass
        d = depth if depth is not None else AgentContext.get_reasoning_depth()
        ev = ReasoningCheckpointEvent(
            checkpoint_type=ct,
            checkpoint_name=str(name)[:200] if name else None,
            summary=str(summary)[:500] if summary else None,
            step_index=step,
            depth=d,
            metadata=metadata,
        )
        _emit_with_envelope(EVENT_REASONING_CHECKPOINT, ev.decision_metadata())
    except Exception as e:
        logger.debug("record_reasoning_checkpoint skipped: %s", e)


def record_llm_reasoning_finished(
    summary: str,
    step_index: int | None = None,
    metadata: dict | None = None,
) -> None:
    """Emit checkpoint when an LLM finishes reasoning. Uses current depth. Never raises."""
    record_reasoning_checkpoint(
        CHECKPOINT_TYPE_LLM_REASONING_FINISHED,
        summary=summary,
        step_index=step_index,
        metadata=metadata,
    )


def record_plan_step(
    summary: str,
    step_index: int,
    checkpoint_name: str | None = None,
    metadata: dict | None = None,
) -> None:
    """Emit checkpoint when a plan step is generated. Never raises."""
    record_reasoning_checkpoint(
        CHECKPOINT_TYPE_PLAN_STEP,
        summary=summary,
        step_index=step_index,
        checkpoint_name=checkpoint_name,
        metadata=metadata,
    )


def record_tool_decision_checkpoint(
    tool_name: str,
    reasoning: str,
    metadata: dict | None = None,
) -> None:
    """Emit checkpoint when a tool decision is made. Never raises."""
    meta = dict(metadata or {})
    meta["tool_name"] = str(tool_name)[:200]
    meta["reasoning"] = str(reasoning)[:500]
    record_reasoning_checkpoint(
        CHECKPOINT_TYPE_TOOL_DECISION,
        summary=reasoning[:500],
        checkpoint_name=f"tool_decision_{tool_name}",
        metadata=meta,
    )


def record_retry_checkpoint(
    reason: str,
    retry_count: int,
    metadata: dict | None = None,
    *,
    attempt_index: int | None = None,
    max_attempts: int | None = None,
) -> None:
    """Emit checkpoint when a retry occurs. Sets decision.retry_attempt and decision.retry_max_attempts on current span when provided. Never raises."""
    try:
        meta = dict(metadata or {})
        meta["retry_count"] = retry_count
        if attempt_index is not None:
            meta["attempt_index"] = int(attempt_index)
        if max_attempts is not None:
            meta["max_attempts"] = int(max_attempts)
        record_reasoning_checkpoint(
            CHECKPOINT_TYPE_RETRY,
            summary=reason,
            checkpoint_name=f"retry_{retry_count}",
            metadata=meta,
        )
        span = trace.get_current_span()
        if span and span.is_recording():
            if attempt_index is not None:
                _set_span_attr_safe(span, "decision.retry_attempt", int(attempt_index))
            if max_attempts is not None:
                _set_span_attr_safe(span, "decision.retry_max_attempts", int(max_attempts))
    except Exception as e:
        logger.debug("record_retry_checkpoint skipped: %s", e)


def set_retry_attempt(attempt_index: int, max_attempts: int | None = None) -> None:
    """Set retry attempt attributes on the current span (e.g. when starting attempt 2 of 3). Never raises."""
    try:
        span = trace.get_current_span()
        if span and span.is_recording():
            _set_span_attr_safe(span, "decision.retry_attempt", int(attempt_index))
            if max_attempts is not None:
                _set_span_attr_safe(span, "decision.retry_max_attempts", int(max_attempts))
    except Exception:
        pass


def record_fallback_checkpoint(
    reason: str,
    fallback_target: str | None = None,
    metadata: dict | None = None,
) -> None:
    """Emit checkpoint when a fallback happens. Never raises."""
    meta = dict(metadata or {})
    if fallback_target:
        meta["fallback_target"] = str(fallback_target)[:200]
    record_reasoning_checkpoint(
        CHECKPOINT_TYPE_FALLBACK,
        summary=reason,
        checkpoint_name=f"fallback_{fallback_target}" if fallback_target else "fallback",
        metadata=meta,
    )


def record_decision_confidence(confidence: float, scope: str = "turn") -> None:
    """
    Record decision confidence. Emits an OpenTelemetry span event on the current trace span.
    Event: decision.confidence_score. Confidence clamped to [0, 1]. Never raises.
    """
    try:
        conf = _clamp_confidence(confidence)
        if conf is None:
            return
        span = trace.get_current_span()
        if not span or not span.is_recording():
            return
        ev = ConfidenceScoreEvent(confidence=conf, scope=str(scope)[:100] if scope else "turn")
        _emit_with_envelope(EVENT_CONFIDENCE_SCORE, ev.decision_metadata(), span=span)
        _set_span_attr_safe(span, "decision.confidence", conf)
        _set_span_attr_safe(span, "decision.confidence_scope", scope or "turn")
    except Exception as e:
        logger.debug("record_decision_confidence skipped: %s", e)


def record_tool_selection(
    tool_name: str,
    reasoning: str,
    confidence: float | None = None,
) -> None:
    """
    Record tool selection (which tool was chosen and why). Emits an OpenTelemetry span event on the
    current trace span. Event: decision.tool_selection. Never raises.
    """
    try:
        name = str(tool_name).strip() if tool_name else ""
        reason = str(reasoning).strip() if reasoning else ""
        if not name:
            return
        span = trace.get_current_span()
        if not span or not span.is_recording():
            return
        conf = _clamp_confidence(confidence)
        ev = ToolSelectionEvent(tool_name=name, reasoning=reason[:500] or " ", confidence=conf)
        _emit_with_envelope(EVENT_TOOL_SELECTION, ev.decision_metadata(), span=span)
        _set_span_attr_safe(span, "decision.tool_selection_reasoning", reason[:500])
        if conf is not None:
            _set_span_attr_safe(span, "decision.tool_selection_confidence", conf)
    except Exception as e:
        logger.debug("record_tool_selection skipped: %s", e)


def record_tool_selection_reasoning(
    tool_name: str,
    reasoning: str,
    confidence: float | None = None,
) -> None:
    """Alias for record_tool_selection. Never raises."""
    record_tool_selection(tool_name=tool_name, reasoning=reasoning, confidence=confidence)


def record_agent_state_transition(
    from_state: str,
    to_state: str,
    reason: str | None = None,
) -> None:
    """
    Record agent state transition. Emits an OpenTelemetry span event on the current trace span and
    updates context state. Event: decision.agent_step_transition. Never raises.
    """
    try:
        from_s = str(from_state).strip() if from_state else ""
        to_s = str(to_state).strip() if to_state else ""
        if not from_s or not to_s:
            return
        ev = AgentStepTransitionEvent(
            from_state=from_s,
            to_state=to_s,
            reason=str(reason)[:200] if reason else None,
        )
        _emit_with_envelope(EVENT_AGENT_STEP_TRANSITION, ev.decision_metadata())
        AgentContext.set_agent_state(to_s)
    except Exception as e:
        logger.debug("record_agent_state_transition skipped: %s", e)


def record_retrieval_ranking(
    query_summary: str,
    doc_ids: list[str],
    scores: list[float] | None = None,
    top_k: int | None = None,
) -> None:
    """
    Record retrieval ranking. Emits decision.retrieval_ranking. Never raises.
    """
    try:
        if not doc_ids:
            return
        q = str(query_summary).strip()[:200] if query_summary else "query"
        ids = [str(x) for x in doc_ids[:100]]
        sc = [float(x) for x in scores[:100]] if scores and len(scores) >= len(ids) else None
        ev = RetrievalRankingEvent(query_summary=q, doc_ids=ids, scores=sc, top_k=top_k)
        _emit_with_envelope(EVENT_RETRIEVAL_RANKING, ev.decision_metadata())
    except Exception as e:
        logger.debug("record_retrieval_ranking skipped: %s", e)


def record_tool_execution_result(
    tool_name: str,
    success: bool,
    result_summary: str | None = None,
    duration_ms: float | None = None,
    error_code: str | None = None,
) -> None:
    """
    Record tool execution result. Emits decision.tool_execution_result. Never raises.
    """
    try:
        name = str(tool_name).strip() if tool_name else ""
        if not name:
            return
        ev = ToolExecutionResultEvent(
            tool_name=name,
            success=bool(success),
            result_summary=str(result_summary)[:500] if result_summary else None,
            duration_ms=float(duration_ms) if duration_ms is not None else None,
            error_code=str(error_code)[:100] if error_code else None,
        )
        _emit_with_envelope(EVENT_TOOL_EXECUTION_RESULT, ev.decision_metadata())
    except Exception as e:
        logger.debug("record_tool_execution_result skipped: %s", e)


def record_failure(
    category: str,
    code: str | None = None,
    message: str | None = None,
) -> None:
    """
    Record a structured failure for root cause analysis. Emits decision.failure event and sets
    decision.failure.category (and optional code, message) on current span.
    category: one of timeout, rate_limit, content_filter, token_limit, tool_error, retrieval_error, auth_error, bad_request, unknown.
    Never raises.
    """
    try:
        span = trace.get_current_span()
        if not span or not span.is_recording():
            return
        cat = str(category).strip().lower() if category else FAILURE_CATEGORIES[-1]
        if cat not in FAILURE_CATEGORIES:
            cat = FAILURE_CATEGORIES[-1]
        ev = FailureEvent(
            category=cat,
            code=str(code).strip()[:100] if code else None,
            message=str(message).strip()[:500] if message else None,
        )
        _emit_with_envelope(EVENT_FAILURE, ev.decision_metadata(), span=span)
        _set_span_attr_safe(span, "decision.failure.category", cat)
        if code is not None:
            _set_span_attr_safe(span, "decision.failure.code", str(code)[:100])
        if message is not None:
            _set_span_attr_safe(span, "decision.failure.message", str(message)[:500])
    except Exception as e:
        logger.debug("record_failure skipped: %s", e)


def set_trace_outcome(outcome: str, reason: str | None = None) -> None:
    """
    Set explicit trace outcome on the current span (should be agent.run). Use when the app knows
    the business outcome: success | failure | timeout | cancelled | partial.
    Backend prefers this over inferred status. Never raises.
    """
    try:
        span = trace.get_current_span()
        if not span or not span.is_recording():
            return
        out = str(outcome).strip().lower()[:50]
        if out:
            span.set_attribute("decision.trace_outcome", out)
            if reason is not None:
                span.set_attribute("decision.trace_outcome_reason", str(reason)[:200])
    except Exception:
        pass


def record_outcome(
    success: bool,
    source: str = OUTCOME_SOURCE_SYSTEM,
    confidence: float | None = None,
) -> None:
    """
    Record explicit user or business outcome (e.g. task completed, thumbs down). Emits decision.outcome event.
    source: system | user_feedback | business_rule. Never raises.
    """
    try:
        span = trace.get_current_span()
        if not span or not span.is_recording():
            return
        src = str(source).strip().lower()[:50] or OUTCOME_SOURCE_SYSTEM
        conf = _clamp_confidence(confidence)
        ev = OutcomeEvent(success=bool(success), source=src, confidence=conf)
        _emit_with_envelope(EVENT_OUTCOME, ev.decision_metadata(), span=span)
        _set_span_attr_safe(span, "decision.outcome.success", success)
        _set_span_attr_safe(span, "decision.outcome.source", src)
        if conf is not None:
            _set_span_attr_safe(span, "decision.outcome.confidence", conf)
    except Exception as e:
        logger.debug("record_outcome skipped: %s", e)


def record_task_completed(completed: bool) -> None:
    """Convenience: record outcome with source=business_rule. Never raises."""
    record_outcome(completed, source=OUTCOME_SOURCE_BUSINESS_RULE)


def record_guardrail_triggered(
    type: str,
    action: str,
    rule_id: str | None = None,
    detail: str | None = None,
) -> None:
    """
    Record guardrail/safety trigger (content filter, policy violation, PII redaction, safety block).
    type: content_filter | policy_violation | pii_redaction | safety_block.
    action: block | rewrite | warn. Never raises.
    """
    try:
        t = str(type).strip().lower()[:50]
        a = str(action).strip().lower()[:50]
        if not t or not a:
            return
        ev = GuardrailTriggeredEvent(
            type=t,
            action=a,
            rule_id=str(rule_id).strip()[:100] if rule_id else None,
            detail=str(detail).strip()[:200] if detail else None,
        )
        _emit_with_envelope(EVENT_GUARDRAIL_TRIGGERED, ev.decision_metadata())
        span = trace.get_current_span()
        if span and span.is_recording():
            _set_span_attr_safe(span, "decision.guardrail.type", t)
            _set_span_attr_safe(span, "decision.guardrail.action", a)
            if rule_id is not None:
                _set_span_attr_safe(span, "decision.guardrail.rule_id", str(rule_id)[:100])
    except Exception as e:
        logger.debug("record_guardrail_triggered skipped: %s", e)
