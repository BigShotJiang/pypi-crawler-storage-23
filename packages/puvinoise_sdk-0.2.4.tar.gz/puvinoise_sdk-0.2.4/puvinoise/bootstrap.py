"""
OpenTelemetry bootstrap for PUViNoise SDK.

Production features:
 - Retry-capable OTLP exporter with configurable backoff
 - Graceful shutdown with atexit hook (flushes pending spans)
 - Optional gzip compression
 - Configurable batch processor for high-frequency telemetry
 - Structured logging for telemetry pipeline status
"""

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
import atexit
import logging
import os

logger = logging.getLogger(__name__)

_initialized = False
_provider = None


def _create_otlp_exporter(endpoint: str, headers: dict | None, compression: bool, timeout: int = 30):
    kwargs = {"endpoint": endpoint, "timeout": timeout}
    if headers:
        kwargs["headers"] = headers
    if compression:
        try:
            from opentelemetry.exporter.otlp.proto.http import Compression
            kwargs["compression"] = Compression.Gzip
        except ImportError:
            pass
    return OTLPSpanExporter(**kwargs)


def bootstrap(
    service_name: str = None,
    otlp_endpoint: str = None,
    console_export: bool = False,
    batch_config: dict = None,
    compression: bool = True,
):
    """
    Initialize OpenTelemetry tracing for the agent.

    Tuned for high-frequency telemetry (e.g. every second per agent):
    batching every 1s, optional gzip compression, retry-capable export.

    Reads env: CUST_AGENT_NAME, CUST_LLM_PROVIDER, PUVINOISE_TENANTID,
    PUVINOISE_AGENTACCESSKEY, PUVINOISE_END_POINT_URL.
    """
    global _initialized, _provider

    puvicustagentname = (os.getenv("CUST_AGENT_NAME") or "").strip()
    name = (service_name or puvicustagentname or "").strip()
    if not name:
        raise ValueError(
            "Agent name must be set via service_name argument or CUST_AGENT_NAME environment variable"
        )

    if _initialized:
        logger.info("Tracer already initialized for service: %s", name)
        return trace.get_tracer(name)

    endpoint = (otlp_endpoint or os.getenv("PUVINOISE_END_POINT_URL") or "").strip()
    if not endpoint:
        raise ValueError(
            "OTLP endpoint must be set via otlp_endpoint or PUVINOISE_END_POINT_URL environment variable"
        )
    if not endpoint.endswith("/v1/traces"):
        endpoint = endpoint.rstrip("/") + "/v1/traces"

    access_key = (os.getenv("PUVINOISE_AGENTACCESSKEY") or "").strip()
    headers = {}
    if access_key:
        headers["Authorization"] = f"Bearer {access_key}"

    llm_provider = (os.getenv("CUST_LLM_PROVIDER") or "").strip()
    tenant_id = (os.getenv("PUVINOISE_TENANTID") or "").strip()

    resource_attrs = {
        "service.name": name,
        "service.version": "0.1.0",
        "deployment.environment": os.getenv("DEPLOYMENT_ENV", "production"),
    }
    if llm_provider:
        resource_attrs["puvinoise.llm_provider"] = llm_provider
    if tenant_id:
        resource_attrs["tenant.id"] = tenant_id
    resource = Resource.create(resource_attrs)

    provider = TracerProvider(resource=resource)
    trace.set_tracer_provider(provider)

    default_batch_config = {
        "schedule_delay_millis": 1000,
        "max_export_batch_size": 128,
        "export_timeout_millis": 30000,
        "max_queue_size": 4096,
    }

    if batch_config:
        default_batch_config.update(batch_config)

    try:
        otlp_exporter = _create_otlp_exporter(
            endpoint=endpoint,
            headers=headers if headers else None,
            compression=compression,
            timeout=default_batch_config.get("export_timeout_millis", 30000) // 1000,
        )
        provider.add_span_processor(
            BatchSpanProcessor(otlp_exporter, **default_batch_config)
        )
        logger.info("OTLP exporter configured: %s", endpoint)
    except Exception as e:
        logger.error("Failed to configure OTLP exporter: %s", e)
        console_export = True

    if console_export:
        console_exporter = ConsoleSpanExporter()
        provider.add_span_processor(
            BatchSpanProcessor(console_exporter, **default_batch_config)
        )
        logger.info("Console exporter configured for debugging")

    _initialized = True
    _provider = provider

    atexit.register(_atexit_flush)

    logger.info("OpenTelemetry initialized for service: %s", name)

    return trace.get_tracer(name)


def _atexit_flush():
    """Auto-flush on interpreter exit so no spans are lost."""
    try:
        if _provider is not None:
            _provider.force_flush(timeout_millis=5000)
    except Exception:
        pass


def shutdown():
    """
    Gracefully shutdown the tracer provider.
    Call this when your application is terminating to ensure all spans are exported.
    """
    global _provider
    provider = trace.get_tracer_provider()
    if isinstance(provider, TracerProvider):
        provider.shutdown()
        logger.info("OpenTelemetry tracer provider shut down successfully")
    _provider = None


def force_flush(timeout_millis: int = 30000):
    """
    Force flush all pending spans.

    Args:
        timeout_millis: Maximum time to wait for flush in milliseconds
    """
    provider = trace.get_tracer_provider()
    if isinstance(provider, TracerProvider):
        success = provider.force_flush(timeout_millis)
        if success:
            logger.info("Successfully flushed all pending spans")
        else:
            logger.warning("Flush timed out or failed")
        return success
    return False


def is_initialized() -> bool:
    """Check if the tracer has been initialized."""
    return _initialized
