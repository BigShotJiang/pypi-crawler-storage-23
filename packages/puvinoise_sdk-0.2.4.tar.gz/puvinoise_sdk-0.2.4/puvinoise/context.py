import uuid
import contextvars
from typing import Optional

# Context variables automatically propagate across async calls
_run_id = contextvars.ContextVar("run_id", default=None)
_agent_name = contextvars.ContextVar("agent_name", default=None)
_goal = contextvars.ContextVar("goal", default=None)
_task_type = contextvars.ContextVar("task_type", default=None)
_intent = contextvars.ContextVar("intent", default=None)
_agent_state = contextvars.ContextVar("agent_state", default=None)
_session_id = contextvars.ContextVar("session_id", default=None)
_model_used = contextvars.ContextVar("model_used", default=None)
_prompt_hash = contextvars.ContextVar("prompt_hash", default=None)
_reasoning_depth = contextvars.ContextVar("reasoning_depth", default=0)
_turn_index = contextvars.ContextVar("turn_index", default=None)
_message_id = contextvars.ContextVar("message_id", default=None)


class AgentContext:
    """
    Holds metadata for a single agent execution.
    Uses contextvars for thread-safe and async-safe context propagation.
    Optional decision-telemetry fields: goal, task_type, intent, agent_state.
    """
    
    def __init__(
        self,
        agent_name: str,
        run_id: Optional[str] = None,
        goal: Optional[str] = None,
        task_type: Optional[str] = None,
        intent: Optional[str] = None,
        session_id: Optional[str] = None,
        turn_index: Optional[int] = None,
        message_id: Optional[str] = None,
    ):
        """
        Initialize agent context.

        Args:
            agent_name: Name of the agent
            run_id: Optional custom run ID (generates UUID if not provided)
            goal: Optional high-level goal (decision telemetry)
            task_type: Optional task type (decision telemetry)
            intent: Optional classified intent (decision telemetry)
            session_id: Optional session/conversation ID (decision telemetry envelope)
            turn_index: Optional 1-based turn number in session (decision telemetry envelope)
            message_id: Optional request/message ID within session (decision telemetry envelope)
        """
        self.run_id = run_id or str(uuid.uuid4())
        self.agent_name = agent_name
        self._goal = goal
        self._task_type = task_type
        self._intent = intent
        self._session_id = session_id
        self._turn_index = turn_index
        self._message_id = message_id
        self._tokens = []
    
    def activate(self):
        """Activate this context for the current execution."""
        self._tokens = [
            _run_id.set(self.run_id),
            _agent_name.set(self.agent_name),
            _goal.set(self._goal),
            _task_type.set(self._task_type),
            _intent.set(self._intent),
            _agent_state.set("idle"),
            _session_id.set(self._session_id),
            _turn_index.set(self._turn_index),
            _message_id.set(self._message_id),
        ]
    
    def deactivate(self):
        """Deactivate this context and restore previous values."""
        for token in reversed(self._tokens):
            try:
                if token:
                    token.var.reset(token)
            except Exception:
                pass  # Token may have already been reset
        self._tokens.clear()
    
    def __enter__(self):
        """Context manager support."""
        self.activate()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager cleanup."""
        self.deactivate()
        return False
    
    @staticmethod
    def get_run_id() -> Optional[str]:
        """Get the current run ID from context."""
        return _run_id.get()
    
    @staticmethod
    def get_agent_name() -> Optional[str]:
        """Get the current agent name from context."""
        return _agent_name.get()
    
    @staticmethod
    def get_goal() -> Optional[str]:
        """Get the current goal from context (decision telemetry)."""
        return _goal.get()
    
    @staticmethod
    def get_task_type() -> Optional[str]:
        """Get the current task type from context (decision telemetry)."""
        return _task_type.get()
    
    @staticmethod
    def get_intent() -> Optional[str]:
        """Get the current intent from context (decision telemetry)."""
        return _intent.get()
    
    @staticmethod
    def get_agent_state() -> Optional[str]:
        """Get the current agent state from context (decision telemetry)."""
        return _agent_state.get()
    
    @staticmethod
    def set_agent_state(state: str) -> None:
        """Set the current agent state in context (decision telemetry)."""
        _agent_state.set(state)

    @staticmethod
    def get_session_id() -> Optional[str]:
        """Get the current session ID from context (decision telemetry envelope)."""
        return _session_id.get()

    @staticmethod
    def set_session_id(session_id: Optional[str]) -> None:
        """Set the current session ID in context."""
        _session_id.set(session_id)

    @staticmethod
    def get_model_used() -> Optional[str]:
        """Get the current model used from context (decision telemetry envelope)."""
        return _model_used.get()

    @staticmethod
    def set_model_used(model: Optional[str]) -> None:
        """Set the current model used in context (e.g. after LLM call)."""
        _model_used.set(model)

    @staticmethod
    def get_prompt_hash() -> Optional[str]:
        """Get the current prompt hash from context (decision telemetry envelope)."""
        return _prompt_hash.get()

    @staticmethod
    def set_prompt_hash(hash_value: Optional[str]) -> None:
        """Set the current prompt hash in context."""
        _prompt_hash.set(hash_value)

    @staticmethod
    def get_turn_index() -> Optional[int]:
        """Get the current turn index (1-based) in session from context."""
        v = _turn_index.get()
        return int(v) if v is not None else None

    @staticmethod
    def set_turn_index(turn_index: Optional[int]) -> None:
        """Set the current turn index in context (decision telemetry envelope)."""
        _turn_index.set(turn_index)

    @staticmethod
    def get_message_id() -> Optional[str]:
        """Get the current message/request ID in session from context."""
        return _message_id.get()

    @staticmethod
    def set_message_id(message_id: Optional[str]) -> None:
        """Set the current message ID in context (decision telemetry envelope)."""
        _message_id.set(message_id)

    # -------------------------------------------------------------------------
    # Reasoning depth (for checkpoint system: nested reasoning steps)
    # -------------------------------------------------------------------------

    @staticmethod
    def get_reasoning_depth() -> int:
        """Return current reasoning depth (0 = top level). Incremented by enter_reasoning_step."""
        try:
            d = _reasoning_depth.get()
            return int(d) if d is not None else 0
        except Exception:
            return 0

    @staticmethod
    def enter_reasoning_step():
        """
        Enter a reasoning step (increments depth). Returns a token to pass to exit_reasoning_step.
        Use as: token = AgentContext.enter_reasoning_step(); try: ... finally: AgentContext.exit_reasoning_step(token)
        """
        prev = AgentContext.get_reasoning_depth()
        return _reasoning_depth.set(prev + 1)

    @staticmethod
    def exit_reasoning_step(token) -> None:
        """Exit a reasoning step (restores previous depth). Pass the token from enter_reasoning_step."""
        try:
            if token is not None:
                _reasoning_depth.reset(token)
        except Exception:
            pass

    @staticmethod
    def reasoning_step():
        """
        Context manager that increments reasoning depth on entry and restores on exit.
        Use: with AgentContext.reasoning_step(): ...
        """
        class _ReasoningStepContext:
            def __enter__(self):
                self._token = AgentContext.enter_reasoning_step()
                return self

            def __exit__(self, *args):
                AgentContext.exit_reasoning_step(self._token)
                return False

        return _ReasoningStepContext()
    
    @staticmethod
    def get_context() -> dict:
        """Get all current context values as a dictionary."""
        return {
            "run_id": _run_id.get(),
            "agent_name": _agent_name.get(),
            "goal": _goal.get(),
            "task_type": _task_type.get(),
            "intent": _intent.get(),
            "agent_state": _agent_state.get(),
            "session_id": _session_id.get(),
            "model_used": _model_used.get(),
            "prompt_hash": _prompt_hash.get(),
            "turn_index": AgentContext.get_turn_index(),
            "message_id": _message_id.get(),
            "reasoning_depth": AgentContext.get_reasoning_depth(),
        }
    
    @staticmethod
    def is_active() -> bool:
        """Check if there's an active agent context."""
        return _run_id.get() is not None