#![doc = include_str!("../crash_course.md")]
