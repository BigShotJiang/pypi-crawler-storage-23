"""Tests for parity monitoring and arbitrage detection (Rust core)."""

import pytest
from horizon import (
    Engine,
    RiskConfig,
    ParityResult,
    ArbitrageOpportunity,
)


@pytest.fixture
def engine():
    config = RiskConfig(
        max_position_per_market=1000.0,
        max_portfolio_notional=10000.0,
        max_order_size=500.0,
    )
    return Engine(risk_config=config, paper_fee_rate=0.0)


class TestParityResult:
    def test_parity_result_fields(self):
        """ParityResult exposes all expected fields."""
        # We test via engine.parity_check, which requires feeds.
        # Since parity is a Rust pure function, just verify the type exists.
        assert ParityResult is not None

    def test_engine_parity_check_no_feeds(self, engine):
        """Without feeds, parity_check returns None."""
        result = engine.parity_check("mkt_1")
        assert result is None

    def test_engine_parity_check_with_threshold(self, engine):
        """Custom threshold works (no feeds → None)."""
        result = engine.parity_check("mkt_1", threshold=0.01)
        assert result is None


class TestArbitrageOpportunity:
    def test_arb_type_exists(self):
        assert ArbitrageOpportunity is not None

    def test_scan_arbitrage_no_feeds(self, engine):
        """Without feeds, scan returns empty."""
        opps = engine.scan_arbitrage(
            "mkt_1",
            [("feed_poly", "polymarket", 0.002), ("feed_kalshi", "kalshi", 0.002)],
        )
        assert opps == []

    def test_scan_arbitrage_empty_map(self, engine):
        """Empty market_feed_map returns empty."""
        opps = engine.scan_arbitrage("mkt_1", [])
        assert opps == []


class TestParityIntegration:
    """Integration tests using paper exchange feeds simulation."""

    def test_parity_check_default_threshold(self, engine):
        """Default threshold is 0.02."""
        # No feeds means None, but verifies the API accepts default
        assert engine.parity_check("mkt_1") is None

    def test_scan_arbitrage_max_liquidity(self, engine):
        """max_liquidity parameter works."""
        opps = engine.scan_arbitrage(
            "mkt_1",
            [("f1", "ex1", 0.01), ("f2", "ex2", 0.01)],
            max_liquidity=50.0,
        )
        assert isinstance(opps, list)
