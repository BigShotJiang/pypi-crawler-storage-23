"""Backtesting engine - replay historical data through the same pipeline as live trading."""

from __future__ import annotations

import csv
import logging
import os
from dataclasses import dataclass
from typing import Any, Callable

from horizon._horizon import Engine, Market, Quote, RiskConfig, Side
from horizon.context import Context, FeedData, InventorySnapshot
from horizon.result import BacktestResult
from horizon.risk import Risk
from horizon.strategy import _run_pipeline, _process_result

logger = logging.getLogger("horizon.backtest")


@dataclass
class Tick:
    """A single data point in the backtest timeline."""

    timestamp: float
    price: float = 0.0
    bid: float = 0.0
    ask: float = 0.0
    volume: float = 0.0


def backtest(
    name: str = "backtest",
    markets: list[str] | None = None,
    data: Any = None,
    feeds: dict[str, Any] | None = None,
    pipeline: list[Callable] | None = None,
    risk: Risk | RiskConfig | None = None,
    params: dict[str, Any] | None = None,
    paper_fee_rate: float = 0.001,
    initial_capital: float = 1000.0,
    outcomes: dict[str, float] | None = None,
) -> BacktestResult:
    """Run a backtest over historical data using the same pipeline as hz.run().

    Args:
        name: Strategy name (for logging).
        markets: List of market IDs to quote on. Defaults to ["market"].
        data: Historical data - list[dict], CSV path (str), pandas DataFrame,
              or dict[feed_name → data] for multi-feed backtests.
        feeds: Feed name mapping when using a single data source.
               e.g., {"btc": None} maps the data to feed name "btc".
               If not provided and data is not a dict, defaults to {"default": data}.
        pipeline: List of pipeline functions (same as hz.run()).
        risk: Risk config.
        params: Arbitrary parameters passed to Context.
        paper_fee_rate: Fee rate for the paper exchange.
        initial_capital: Starting capital for equity tracking.
        outcomes: dict of market_id → outcome (1.0 or 0.0) for Brier score.

    Returns:
        BacktestResult with equity curve, trades, positions, and metrics.
    """
    if pipeline is None or len(pipeline) == 0:
        raise ValueError("pipeline must contain at least one function")
    if markets is None:
        markets = ["market"]
    if params is None:
        params = {}

    # Resolve feed data from inputs
    feed_ticks = _resolve_feed_data(data, feeds, markets)

    # Validate all tick streams (skip empty feeds)
    has_data = False
    for feed_name, ticks in feed_ticks.items():
        if ticks:
            _validate_ticks(ticks, feed_name)
            has_data = True

    # Build merged timeline
    timeline = _build_timeline(feed_ticks) if has_data else []

    if not timeline:
        return BacktestResult(
            equity_curve=[(0.0, initial_capital)],
            initial_capital=initial_capital,
            outcomes=outcomes,
        )

    # Build risk config - auto-relax rate limits for backtest speed
    risk_config = _build_risk_config(risk)

    # Create paper engine (no persistence, no feeds)
    engine = Engine(
        risk_config=risk_config,
        paper_fee_rate=paper_fee_rate,
        db_path=None,
    )

    # Set daily baseline
    engine.set_daily_baseline(0.0)

    # Create market objects
    market_objs = [Market(id=slug, name=slug, slug=slug) for slug in markets]

    # Run simulation
    equity_curve: list[tuple[float, float]] = []
    all_fills: list = []
    seen_fill_ids: set[str] = set()

    for ts, feed_states in timeline:
        # Update daily PnL tracking
        status = engine.status()
        current_pnl = status.total_realized_pnl + status.total_unrealized_pnl
        engine.update_daily_pnl(current_pnl)

        for market in market_objs:
            try:
                ctx = _build_backtest_context(engine, market, feed_states, params)
                result = _run_pipeline(pipeline, ctx)

                if result is not None:
                    _process_result(engine, market, result, ctx)

                    # Post-submission tick: _process_result does cancel → tick → submit,
                    # so newly submitted orders haven't been matched yet. Tick again
                    # at the current feed price to fill the new resting orders.
                    feed_price = _get_feed_mid(feed_states)
                    if feed_price is not None:
                        engine.tick(market.id, feed_price)
            except Exception as e:
                logger.warning("Pipeline error for %s at t=%.2f: %s", market.id, ts, e)

        # Drain fills using fill_id-based dedup (immune to 1000-fill cap)
        for fill in engine.recent_fills():
            if fill.fill_id not in seen_fill_ids:
                seen_fill_ids.add(fill.fill_id)
                all_fills.append(fill)

        # Snapshot equity
        status = engine.status()
        equity = initial_capital + status.total_pnl()
        equity_curve.append((ts, equity))

    return BacktestResult(
        equity_curve=equity_curve,
        trades=all_fills,
        positions=engine.positions(),
        initial_capital=initial_capital,
        outcomes=outcomes,
    )


def _normalize_data(data: Any) -> list[Tick]:
    """Convert various data formats to list[Tick].

    Accepts:
        - list[dict] with keys: timestamp, price, [bid, ask, volume]
        - str (CSV file path)
        - pandas DataFrame with columns: timestamp, price, [bid, ask, volume]
    """
    if data is None:
        return []

    if isinstance(data, str):
        return _load_csv(data)

    if isinstance(data, list):
        return _from_dicts(data)

    # Duck-type check for DataFrame (avoid hard pandas dependency)
    if hasattr(data, "iterrows") and hasattr(data, "columns"):
        return _from_dataframe(data)

    raise TypeError(
        f"Unsupported data type: {type(data).__name__}. "
        "Expected list[dict], CSV path (str), or pandas DataFrame."
    )


def _from_dicts(records: list[dict]) -> list[Tick]:
    """Convert list of dicts to list of Tick."""
    ticks = []
    for i, rec in enumerate(records):
        if "timestamp" not in rec:
            raise ValueError(f"Record {i} missing required 'timestamp' field")
        if "price" not in rec and "bid" not in rec:
            raise ValueError(f"Record {i} missing 'price' or 'bid' field")

        price = float(rec.get("price", 0.0))
        bid = float(rec.get("bid", 0.0))
        ask = float(rec.get("ask", 0.0))

        # If only price is given, derive bid/ask
        if price > 0 and bid == 0 and ask == 0:
            bid = price
            ask = price
        # If only bid/ask given, derive price as mid
        if price == 0 and bid > 0 and ask > 0:
            price = (bid + ask) / 2.0

        ticks.append(Tick(
            timestamp=float(rec["timestamp"]),
            price=price,
            bid=bid,
            ask=ask,
            volume=float(rec.get("volume", 0.0)),
        ))
    return ticks


def _load_csv(path: str) -> list[Tick]:
    """Load ticks from a CSV file."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"CSV file not found: {path}")

    records = []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rec = {}
            for key in ("timestamp", "price", "bid", "ask", "volume"):
                if key in row and row[key]:
                    rec[key] = float(row[key])
            records.append(rec)

    return _from_dicts(records)


def _from_dataframe(df: Any) -> list[Tick]:
    """Convert a pandas DataFrame to list of Tick (duck-typed, no pandas import)."""
    # to_dict("records") is ~10-100x faster than iterrows()
    if hasattr(df, "to_dict"):
        return _from_dicts(df.to_dict("records"))
    # Fallback for non-standard DataFrame-like objects
    records = []
    cols = set(df.columns)
    for _, row in df.iterrows():
        rec = {"timestamp": float(row["timestamp"])}
        if "price" in cols:
            rec["price"] = float(row["price"])
        if "bid" in cols:
            rec["bid"] = float(row["bid"])
        if "ask" in cols:
            rec["ask"] = float(row["ask"])
        if "volume" in cols:
            rec["volume"] = float(row["volume"])
        records.append(rec)
    return _from_dicts(records)


def _validate_ticks(ticks: list[Tick], feed_name: str = "default") -> None:
    """Validate tick data: monotonic timestamps, prices in (0, 1]."""
    if not ticks:
        raise ValueError(f"Feed '{feed_name}' has no data")

    for i, tick in enumerate(ticks):
        if tick.price < 0 or tick.price > 1.0:
            raise ValueError(
                f"Feed '{feed_name}' tick {i}: price {tick.price} outside valid range (0, 1]. "
                "Prediction market prices must be between 0 and 1."
            )
        if tick.bid < 0 or tick.bid > 1.0:
            raise ValueError(
                f"Feed '{feed_name}' tick {i}: bid {tick.bid} outside valid range [0, 1]"
            )
        if tick.ask < 0 or tick.ask > 1.0:
            raise ValueError(
                f"Feed '{feed_name}' tick {i}: ask {tick.ask} outside valid range [0, 1]"
            )
        if i > 0 and tick.timestamp < ticks[i - 1].timestamp:
            raise ValueError(
                f"Feed '{feed_name}' tick {i}: timestamps not monotonic "
                f"({tick.timestamp} < {ticks[i - 1].timestamp})"
            )


def _resolve_feed_data(
    data: Any,
    feeds: dict[str, Any] | None,
    markets: list[str],
) -> dict[str, list[Tick]]:
    """Map raw data inputs to dict[feed_name → list[Tick]].

    Handles both single-feed and multi-feed cases.
    """
    # Multi-feed: data is a dict mapping feed names to data sources
    if isinstance(data, dict):
        result = {}
        for feed_name, feed_data in data.items():
            result[feed_name] = _normalize_data(feed_data)
        return result

    # Single data source - map to feed names
    ticks = _normalize_data(data)

    if feeds is not None:
        # Map to each specified feed name
        return {feed_name: list(ticks) for feed_name in feeds}

    # Default: single feed named "default"
    return {"default": ticks}


def _build_timeline(
    feed_ticks: dict[str, list[Tick]],
) -> list[tuple[float, dict[str, FeedData]]]:
    """Merge multi-feed ticks into a single chronological timeline.

    At each unique timestamp, carries forward the latest state of each feed.
    Returns list of (timestamp, {feed_name: FeedData}).
    """
    # Collect all unique timestamps
    all_timestamps: set[float] = set()
    for ticks in feed_ticks.values():
        for tick in ticks:
            all_timestamps.add(tick.timestamp)

    sorted_ts = sorted(all_timestamps)
    if not sorted_ts:
        return []

    # Build index: for each feed, map timestamp -> tick
    feed_indices: dict[str, dict[float, Tick]] = {}
    for feed_name, ticks in feed_ticks.items():
        feed_indices[feed_name] = {t.timestamp: t for t in ticks}

    # Carry-forward state for each feed
    current_state: dict[str, FeedData] = {
        feed_name: FeedData() for feed_name in feed_ticks
    }

    timeline = []
    for ts in sorted_ts:
        for feed_name in feed_ticks:
            if ts in feed_indices[feed_name]:
                tick = feed_indices[feed_name][ts]
                current_state[feed_name] = FeedData(
                    price=tick.price,
                    timestamp=tick.timestamp,
                    bid=tick.bid,
                    ask=tick.ask,
                )

        # Snapshot current state (copy dicts to avoid mutation)
        timeline.append((ts, dict(current_state)))

    return timeline


def _build_backtest_context(
    engine: Engine,
    market: Market,
    feed_states: dict[str, FeedData],
    params: dict[str, Any],
) -> Context:
    """Build a Context with injected historical feed data (bypasses FeedManager)."""
    return Context(
        feeds=feed_states,
        inventory=InventorySnapshot(positions=engine.positions()),
        market=market,
        status=engine.status(),
        params=params,
    )


def _get_feed_mid(feed_states: dict[str, FeedData]) -> float | None:
    """Extract a mid price from feed states for paper exchange ticking."""
    for fdata in feed_states.values():
        if fdata.price > 0:
            if fdata.bid > 0 and fdata.ask > 0:
                return (fdata.bid + fdata.ask) / 2.0
            return fdata.price
    return None


def _build_risk_config(risk: Risk | RiskConfig | None) -> RiskConfig:
    """Build RiskConfig for backtest - auto-relax rate limits."""
    if isinstance(risk, Risk):
        config = risk.to_config()
    elif isinstance(risk, RiskConfig):
        config = risk
    else:
        config = RiskConfig()

    # Create a new config with relaxed rate limits for backtest speed
    return RiskConfig(
        max_position_per_market=config.max_position_per_market,
        max_portfolio_notional=config.max_portfolio_notional,
        max_daily_drawdown_pct=config.max_daily_drawdown_pct,
        max_order_size=config.max_order_size,
        rate_limit_sustained=1_000_000,
        rate_limit_burst=1_000_000,
        dedup_window_ms=0,
    )
