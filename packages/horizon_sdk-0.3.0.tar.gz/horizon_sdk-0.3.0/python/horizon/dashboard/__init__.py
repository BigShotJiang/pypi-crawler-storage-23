"""TUI Dashboard for Horizon."""

from __future__ import annotations

from typing import Any, Callable

from horizon._horizon import Engine, Market


def create_app(
    name: str,
    engine: Engine,
    markets: list[Market],
    feeds: dict[str, Any],
    pipeline: list[Callable],
    interval: float,
    params: dict[str, Any],
):
    """Create the Textual TUI app."""
    from horizon.dashboard.tui import HorizonApp

    return HorizonApp(name, engine, markets, feeds, pipeline, interval, params)
