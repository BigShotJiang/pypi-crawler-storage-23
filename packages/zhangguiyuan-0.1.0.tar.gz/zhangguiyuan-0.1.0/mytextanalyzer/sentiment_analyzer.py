from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# 初始化分析器
analyzer = SentimentIntensityAnalyzer()

def analyze_sentiment(text):
    """分析文本情感，返回分数"""
    if not text:  # 处理空文本
        return {"neg":0.0, "neu":1.0, "pos":0.0, "compound":0.0}
    return analyzer.polarity_scores(text)

def get_sentiment_label(text):
    """返回情感标签：正面/中性/负面"""
    score = analyze_sentiment(text)["compound"]
    if score >= 0.05:
        return "正面"
    elif score <= -0.05:
        return "负面"
    else:
        return "中性"