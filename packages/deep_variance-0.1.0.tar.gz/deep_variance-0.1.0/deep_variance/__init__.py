"""
deep_variance — GPU Virtual Memory Stitching SDK.

Provides CUDA virtual memory management (VMM) with physical chunk caching
and DLPack-backed PyTorch tensors. Use on systems with CUDA-capable GPUs.
"""

from deep_variance._env_check import check_environment, ensure_cuda_visible
from deep_variance.movie import (
    movie_empty,
    movie_empty_nd,
    set_cache_limit,
    cache_stats,
)

__all__ = [
    "check_environment",
    "ensure_cuda_visible",
    "movie_empty",
    "movie_empty_nd",
    "set_cache_limit",
    "cache_stats",
]
__version__ = "0.1.0"
