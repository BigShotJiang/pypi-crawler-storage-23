"""
Setup for deep_variance: GPU Virtual Memory Stitching SDK.

Build is compiler- and CUDA-agnostic: uses CXX from the environment (e.g. g++,
clang++) and PyTorch's build logic to find CUDA. Install with a PyTorch that
matches the user's CUDA (e.g. pip install torch first), then pip install deep_variance.
"""
from setuptools import setup
import os

# Only import torch when we need to build the extension (not when building sdist
# in an isolated env that may not have torch). Sdist still contains this setup.py;
# when users pip install from sdist they have torch, so the extension builds then.
try:
    from torch.utils.cpp_extension import BuildExtension, CUDAExtension
    _torch_available = True
except ImportError:
    _torch_available = False
    BuildExtension = None
    CUDAExtension = None

# C++ flags that work with g++, clang++, and most Unix compilers.
# Override with env DEEP_VARIANCE_CXXFLAGS (space-separated) if needed.
_CXX_FLAGS = ["-O3", "-std=c++17"]


def _get_cxx_args():
    env_cxxflags = os.environ.get("DEEP_VARIANCE_CXXFLAGS", "").strip()
    if env_cxxflags:
        return env_cxxflags.split()
    return _CXX_FLAGS.copy()


def _get_nvcc_args():
    env_nvcc = os.environ.get("DEEP_VARIANCE_NVCCFLAGS", "").strip()
    if env_nvcc:
        return env_nvcc.split()
    return ["-O3"]


_ROOT = os.path.dirname(os.path.abspath(__file__))
_CPP_SOURCE = os.path.join(_ROOT, "movie_vmm_ext.cpp")


def _get_ext_modules():
    if not _torch_available:
        return []
    return [
        CUDAExtension(
            name="deep_variance._movie_vmm_ext",
            sources=[_CPP_SOURCE],
            extra_compile_args={
                "cxx": _get_cxx_args(),
                "nvcc": _get_nvcc_args(),
            },
            libraries=["cuda"],
        )
    ]


def _get_cmdclass():
    if not _torch_available:
        return {}
    return {"build_ext": BuildExtension}


# Metadata (name, version, install_requires, etc.) come from pyproject.toml.
setup(
    packages=["deep_variance"],
    ext_modules=_get_ext_modules(),
    cmdclass=_get_cmdclass(),
)
