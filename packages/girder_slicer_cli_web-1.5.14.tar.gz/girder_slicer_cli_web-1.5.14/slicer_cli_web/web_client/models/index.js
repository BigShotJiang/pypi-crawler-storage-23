export { default as WidgetModel } from './WidgetModel';
