export { default as WidgetCollection } from './WidgetCollection';
