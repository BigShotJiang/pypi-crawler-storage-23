import girderEvents from '@girder/core/events';

export default girderEvents;
