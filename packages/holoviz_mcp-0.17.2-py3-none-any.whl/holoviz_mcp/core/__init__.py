"""Pure Python core functions for holoviz-mcp. No MCP framework required."""
