"""Client for interacting with the HoloViz MCP server.

This module provides a programmatic interface for calling tools on the HoloViz MCP server.
It maintains a singleton client instance to avoid redundant server initialization.

Examples
--------
>>> from holoviz_mcp.client import call_tool
>>>
>>> # List available Panel components
>>> result = await call_tool("pn_list", {})
>>>
>>> # Search documentation
>>> result = await call_tool("search", {"query": "Button"})
"""

import asyncio
from typing import Any

from fastmcp import Client
from fastmcp.client.client import CallToolResult

from holoviz_mcp.server import mcp
from holoviz_mcp.server import setup_composed_server

__all__ = ["call_tool"]

_CLIENT: Client | None = None
_CLIENT_LOCK = asyncio.Lock()


async def _setup_composed_server() -> None:
    """Set up and cache the composed server.

    This function ensures the server is properly initialized before creating
    a client. It only needs to be called once and its result is cached.
    """
    setup_composed_server()


async def _create_client() -> Client:
    """Create a new MCP client connected to the HoloViz MCP server.

    Returns
    -------
    Client
        A FastMCP client instance connected to the composed HoloViz server.
    """
    await _setup_composed_server()
    return Client(mcp)


async def call_tool(tool_name: str, parameters: dict[str, Any]) -> CallToolResult:
    """Call a tool on the MCP server and return the result.

    This function maintains a singleton client instance to avoid redundant
    server initialization. The first call will initialize the server and
    create a client; subsequent calls reuse the same client.

    The client initialization is protected by an asyncio.Lock to prevent
    race conditions when multiple tasks call this function concurrently.

    Parameters
    ----------
    tool_name : str
        The name of the tool to call (e.g., "pn_list",
        "search", "hvplot_list").
    parameters : dict[str, Any]
        A dictionary of parameters to pass to the tool.

    Returns
    -------
    CallToolResult
        The result returned by the tool, which contains the tool's output
        and any error information.

    Examples
    --------
    >>> # List all Panel components
    >>> result = await call_tool("pn_list", {})
    >>>
    >>> # Search for a specific component
    >>> result = await call_tool("pn_search", {"query": "Button", "limit": 5})
    >>>
    >>> # Get documentation for a project
    >>> result = await call_tool("skill_get", {"name": "panel"})
    """
    global _CLIENT
    async with _CLIENT_LOCK:
        if _CLIENT is None:
            _CLIENT = await _create_client()

    async with _CLIENT:
        result = await _CLIENT.call_tool(tool_name, parameters)
        _normalize_root_objects(result)
        return result


def _normalize_root_objects(result: CallToolResult) -> None:
    """Convert FastMCP Root objects in result.data to plain dicts.

    FastMCP deserializes structured tool results into dynamically-generated
    ``Root`` objects that are not JSON-serializable. This function walks
    ``result.data`` and replaces any such objects with their ``__dict__``
    representation so downstream consumers (Panel JSON panes, DataFrames,
    etc.) can serialize them without errors.
    """

    def _normalize(obj: Any) -> Any:
        """Recursively replace FastMCP Root instances with plain dicts."""
        # FastMCP dynamically generates a class named "Root" for structured results.
        if type(obj).__name__ == "Root":
            return vars(obj)
        if isinstance(obj, list):
            return [_normalize(item) for item in obj]
        if isinstance(obj, dict):
            return {key: _normalize(value) for key, value in obj.items()}
        return obj

    # Normalize the primary data payload.
    result.data = _normalize(result.data)

    # Normalize structured_content if present on the result, without assuming
    # that every CallToolResult implementation defines it.
    structured_content = getattr(result, "structured_content", None)
    if structured_content is not None:
        result.structured_content = _normalize(structured_content)
