import __init__

from easy_utils_dev.wsnoclib import WSNOCLIB

ws = WSNOCLIB(
    ip='100.124.230.92',
    username='admin',
    password='Nokia@2025'
)

ws.connect(False)

view = ws.getZicCardView('DTMS017-A2' , return_dict=True)
print(view)
