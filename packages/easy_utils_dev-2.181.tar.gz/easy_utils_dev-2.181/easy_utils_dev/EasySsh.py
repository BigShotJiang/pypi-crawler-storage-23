import paramiko , traceback, socket, threading
from easy_utils_dev.debugger import DEBUGGER
from easy_utils_dev import utils

class CREATESSH :
    def __init__(self, loggerName=None , logger_homepath=None ,  **kwargs) -> None:
        '''
        @Parameters:
        address: address plain string
        user wsnoc user plain string
        password: password plain string
        options: 
        sshPort: ssh 22
        '''
        self.address = kwargs.get('address')
        self.user = kwargs.get('user' , 'root')
        if loggerName is None :
            loggerName = f"ssh-{self.address}"
        self.password = kwargs.get('password')
        self.port = kwargs.get('sshPort' , 22 )
        self.logger = DEBUGGER(loggerName ,homePath=logger_homepath)
        self.ssh = None
        self.ssh_sessions = []
        self.port_forwards = []  # Store port forward threads and sockets


    def init_sftp(self) -> paramiko.SFTPClient :
        return self.ssh.open_sftp()
    
    
    def init_shell(self) -> paramiko.SSHClient :
        ssh = paramiko.SSHClient()
        try :
            ssh.load_system_host_keys()
        except Exception as error:
            self.logger.warning(f"Faield to load system host keys: {error}. [This error is not critical but better to report it]")
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(self.address,self.port,self.user, self.password )
        transport = ssh.get_transport()
        transport.set_keepalive(60)
        def init_ch() :
            return self.init_ch(ssh)
        ssh.init_ch = init_ch
        ssh.connectionId = utils.getRandomKey(5)
        self.ssh_sessions.append(ssh)
        self.ssh = ssh
        ssh.core = self
        return ssh
    
    def isSessionActive(session) -> bool:
        return session.active
    
    def isSshActive(self) -> bool :
        if self.ssh.get_transport() is not None:
            return self.ssh.get_transport().is_active()
        else :
            return False

    def init_ch(self) -> paramiko.Channel:
        # to get new invoked shells for multi executions
        ch = self.ssh.invoke_shell()
        ch.exit_level = 0
        ch.parent_ssh = self.ssh
        def disconnect(ch=ch) :
            try :
                ch.sendall('exit\n')
                ch.close()
            except :
                pass
        ch.disconnect = disconnect
        return ch

    def ssh_execute(self ,command ,  merge_output=False , hide_output=True) :
        self.logger.info(f"executing {command}")
        try :
            stdin_ , stdout_ , stderr_ = self.ssh.exec_command(command)
            r = stdout_.read().decode()
            e = stderr_.read().decode()
            if r.endswith('\n') :
                r = r[ : -1]
            if hide_output : 
                self.logger.debug(f""" 
                =========================
                +command = '{command}'
                -stdout = {r}
                -stderr = {e}
                =========================
                """)
            else :
                self.logger.info(f""" 
                =========================
                +command = '{command}'
                -stdout = {r}
                -stderr = {e}
                =========================
                """)
            if merge_output :
                return str(r) + str(e)
            return r 
        except Exception as error :
            self.logger.info(traceback.format_exc())
            return str(error)
    
    def create_portforward(self, local_port, remote_port, remote_host='localhost'):
        """
        Create an SSH port forward from local port to remote port using paramiko's native port forwarding.
        
        @Parameters:
        local_port: Local port to listen on (int)
        remote_port: Remote port to forward to (int)
        remote_host: Remote host to forward to (default: 'localhost')
        
        Returns:
        dict: Contains 'local_port', 'remote_port', 'remote_host', 'server_socket', and 'thread'
        """
        if self.ssh is None:
            raise Exception("SSH connection not initialized. Call init_shell() first.")
        
        if not self.isSshActive():
            raise Exception("SSH connection is not active.")
        
        transport = self.ssh.get_transport()
        if transport is None:
            raise Exception("SSH transport is not available.")
        
        # Create local socket server
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.bind(('localhost', local_port))
        server_socket.listen(5)
        
        self.logger.info(f"Port forward created: localhost:{local_port} -> {remote_host}:{remote_port}")
        
        def handle_forward(local_sock):
            """Handle individual port forward connection using paramiko's direct-tcpip channel."""
            try:
                # Use paramiko's native port forwarding channel
                channel = transport.open_channel('direct-tcpip', (remote_host, remote_port), local_sock.getsockname())
                
                if channel is None:
                    self.logger.error(f"Failed to open channel for port forward {local_port} -> {remote_host}:{remote_port}")
                    local_sock.close()
                    return
                
                self.logger.debug(f"Port forward channel established: {local_port} -> {remote_host}:{remote_port}")
                
                # Use paramiko's built-in forwarding
                import select
                while True:
                    r, w, x = select.select([local_sock, channel], [], [])
                    if local_sock in r:
                        data = local_sock.recv(1024)
                        if not data:
                            break
                        channel.send(data)
                    if channel in r:
                        data = channel.recv(1024)
                        if not data:
                            break
                        local_sock.sendall(data)
            except Exception as e:
                self.logger.debug(f"Port forward connection closed: {e}")
            finally:
                try:
                    local_sock.close()
                except:
                    pass
                try:
                    channel.close()
                except:
                    pass
        
        def accept_connections():
            """Accept connections and handle port forwarding."""
            try:
                while True:
                    try:
                        local_sock, addr = server_socket.accept()
                        self.logger.debug(f"New connection for port forward {local_port} -> {remote_host}:{remote_port} from {addr}")
                        # Handle each connection in a separate thread
                        conn_thread = threading.Thread(target=handle_forward, args=(local_sock,), daemon=True)
                        conn_thread.start()
                    except OSError:
                        # Socket closed
                        break
                    except Exception as e:
                        self.logger.error(f"Error accepting port forward connection: {e}")
            except Exception as e:
                self.logger.error(f"Port forward server error: {e}")
            finally:
                try:
                    server_socket.close()
                except:
                    pass
        
        # Start the server thread
        server_thread = threading.Thread(target=accept_connections, daemon=True)
        server_thread.start()
        
        # Store port forward info
        port_forward_info = {
            'local_port': local_port,
            'remote_port': remote_port,
            'remote_host': remote_host,
            'server_socket': server_socket,
            'thread': server_thread
        }
        self.port_forwards.append(port_forward_info)
        
        return port_forward_info
    
    def close_portforward(self, local_port=None):
        """
        Close a port forward by local port.
        If local_port is None, closes all port forwards.
        
        @Parameters:
        local_port: Local port to close (int, optional)
        """
        if local_port is None:
            # Close all port forwards
            for pf in self.port_forwards[:]:
                try:
                    pf['server_socket'].close()
                    self.logger.info(f"Closed port forward: {pf['local_port']} -> {pf['remote_host']}:{pf['remote_port']}")
                except:
                    pass
            self.port_forwards.clear()
        else:
            # Close specific port forward
            for pf in self.port_forwards[:]:
                if pf['local_port'] == local_port:
                    try:
                        pf['server_socket'].close()
                        self.logger.info(f"Closed port forward: {pf['local_port']} -> {pf['remote_host']}:{pf['remote_port']}")
                        self.port_forwards.remove(pf)
                    except:
                        pass
                    break
        
        
if __name__ == "__main__" :
    pass
