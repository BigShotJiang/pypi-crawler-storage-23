# decorators.py
from functools import wraps
from flask import request
from authlib.jose import jwt, JsonWebKey
import requests , time , os , json
from cachetools import TTLCache, cached
from easy_utils_dev.utils import start_thread
from easy_utils_dev.debugger import DEBUGGER
from easy_utils_dev.utils import getTimestamp

class Permissions :

    cache = TTLCache(maxsize=128, ttl=1800)

    def __init__(
            self, 
            home , 
            keycloak_url ,
            webserver ,
            redirect_url = None ,
            home_url = None,
            realm="lrm",
            **kwargs
        ):
        '''
        home : the home page of the application
        keycloak_url : the keycloak url . like http://localhost:8080
        webserver : the webserver object
        redirect_url : the redirect url
        home_url : the home url
        '''
        self.logger = DEBUGGER(
            name='WebServerAuth',
            homePath=home
        )
        self.keycloak_url = keycloak_url
        self.session = requests.Session()
        self.redirect_url = redirect_url
        self.home = home
        self.home_url = home_url
        self.webserver= webserver
        self.token_refreshed_times = 5
        self.admin_user = 'admin'
        self.admin_password="admin"
        self.client_secret = "yS92obzbpbk36UPsJx4lMx9EtNujkqDk"
        self.realm = realm
        self._thread_login_started = False
        self.KEYCLOACKACCESSTOKEN = None
        self.KEYCLOACKREFRESHTOKEN = None
        self.KEYCLOACKBEARERTOKEN = None
        start_thread(target=self._thread_login)


    def _admin_login(self) :
        self.logger.info("Admin login process has started")
        self.logger.debug("Logging in as Keycloak admin ...")
        url = f"{self.keycloak_url}/realms/master/protocol/openid-connect/token"
        payload=f'grant_type=password&client_id=admin-cli&username={self.admin_user}&password={self.admin_password}&client_secret={self.client_secret}&scope=openid profile'
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
        }
        response = requests.request("POST", url, headers=headers, data=payload)
        self.logger.debug(f"Admin login response status: [{response.status_code}]")
        if response.ok :
            self.logger.debug("Admin login successful")
            return response.json()['access_token'] , response.json()['refresh_token']
        self.logger.error(f"Admin login failed: {response.text}")
        raise Exception(f"Login Failure status [{response.status_code}] error={response.text}")

    def _thread_login(self) :
            self.logger.info("Auto login/refresh process has initialized")
            sleep_period = 1800
            while True :
                self.logger.debug("Auto login process is running now ...")
                if self.token_refreshed_times >= 5 :
                    self.KEYCLOACKACCESSTOKEN , self.KEYCLOACKREFRESHTOKEN = self._admin_login()
                    self.KEYCLOACKBEARERTOKEN = f"Bearer {self.KEYCLOACKACCESSTOKEN}"
                    self.token_refreshed_times = 0
                    os.environ.setdefault('KEYCLOACKACCESSTOKEN' , self.KEYCLOACKACCESSTOKEN)
                    os.environ.setdefault('KEYCLOACKREFRESHTOKEN' , self.KEYCLOACKREFRESHTOKEN)
                    os.environ.setdefault('KEYCLOACKBEARERTOKEN' , self.KEYCLOACKBEARERTOKEN)
                    time.sleep(sleep_period)
                    continue
                data = {
                    "client_id": 'admin-cli',
                    "grant_type": "refresh_token",
                    "refresh_token": self.KEYCLOACKREFRESHTOKEN,
                    'client_secret' : self.client_secret
                }
                url = f"{self.keycloak_url}/realms/master/protocol/openid-connect/token"
                resp = requests.post(url, data=data)
                self.logger.info(f"Admin token refreshed status [{resp.status_code}]")
                self.KEYCLOACKACCESSTOKEN = resp.json()['access_token']
                self.KEYCLOACKBEARERTOKEN = f"Bearer {self.KEYCLOACKACCESSTOKEN}"
                self.KEYCLOACKREFRESHTOKEN = resp.json()['refresh_token']
                os.environ.setdefault('KEYCLOACKACCESSTOKEN' , self.KEYCLOACKACCESSTOKEN)
                os.environ.setdefault('KEYCLOACKREFRESHTOKEN' , self.KEYCLOACKREFRESHTOKEN)
                os.environ.setdefault('KEYCLOACKBEARERTOKEN' , self.KEYCLOACKBEARERTOKEN)
                self.token_refreshed_times += 1
                time.sleep(sleep_period)
            
    def get_jwk_set(self):
        self.logger.debug(f"Getting JWK set for realm {self.realm}")
        jwks_url = f"{self.keycloak_url}/realms/{self.realm}/protocol/openid-connect/certs"
        resp = requests.get(jwks_url)
        self.logger.debug(f'JWK.Cert.Response text: [{resp.text}]')
        resp.raise_for_status()
        self.logger.debug(f"JWK set for realm {self.realm} retrieved successfully")
        return JsonWebKey.import_key_set(resp.json())
        

    def extract_token(self , token):
        self.logger.debug(f'Extracting token for {token}')
        jwks = self.get_jwk_set()
        self.logger.debug(f'JWKS key is {jwks}')
        claims = jwt.decode(token, key=jwks)
        self.logger.debug(f'Extracted claims: {json.dumps(claims , indent=4)}')
        return claims

    def get_user_info(self , claims) :
        now = getTimestamp()
        if now > claims['exp'] :
            return False
        return True

    def require_roles(self , *allowed_roles):
        def decorator(fn):
            @wraps(fn)
            def wrapper(*args, **kwargs):
                self.webserver.logger.debug(f"Checking roles for function: {fn.__name__}")
                auth = request.headers.get("Authorization", "")
                if not auth.startswith("Bearer "):
                    self.webserver.logger.debug("No Bearer token found in Authorization header")
                    return self.webserver.Response.unauthorized(message='Authorization failed' , err="no bearer token found in Authorization header" , home_url=self.home_url , redirect_url=self.redirect_url)
                token = auth.split(" ")[1]
                claims = self.extract_token(token)
                self.logger.debug(f"Extracted claims: {claims}")
                if not claims:
                    self.webserver.logger.debug(f'Invalid or expired token. will ask client to redirect to "{self.redirect_url}"')
                    return self.webserver.Response.unauthorized(message='Invalid or expired token' , err="invalid or expired token" , home_url=self.home_url , redirect_url=self.redirect_url)
                user_roles = claims.get("roles", [])
                if not any(role in user_roles for role in allowed_roles):
                    self.webserver.logger.debug(f'Insufficient permissions. will ask client to redirect to "{self.redirect_url}"')
                    return self.webserver.Response.unauthorized(message='Insufficient permissions' , err="insufficient permissions" , home_url=self.home_url , redirect_url=self.redirect_url)
                # Inject user info into request context
                request.user_info = claims
                self.webserver.logger.debug(f"Access granted for {fn.__name__} with roles: {user_roles}")
                return fn(*args, **kwargs)
            return wrapper
        return decorator
    
    def check_access(self):
        def decorator(fn):
            @wraps(fn)
            def wrapper(*args, **kwargs):
                self.webserver.logger.debug(f"Checking access for function: {fn.__name__}")
                auth = request.headers.get("Authorization", "")
                email = request.headers.get("email", "")
                if not auth.startswith("Bearer "):
                    self.webserver.logger.debug("No Bearer token found in Authorization header")
                    return self.webserver.Response.unauthorized(message='Authorization failed' , err="no bearer token found in Authorization header" , home_url=self.home_url , redirect_url=self.redirect_url)
                token = auth.split(" ")[1]
                claims = self.extract_token(token)  
                if not claims :
                    self.webserver.logger.debug("Invalid or expired token. will ask client to redirect to \"{self.redirect_url}\"")
                    return self.webserver.Response.unauthorized(message='Invalid or expired token' , err="invalid or expired token" , home_url=self.home_url , redirect_url=self.redirect_url)
                valid = self.get_user_info(claims)
                if not valid :
                    self.webserver.logger.debug("User info validation failed for token")
                    return self.webserver.Response.unauthorized(message='Authorization failed' , err="user info validation failed for token" , home_url=self.home_url , redirect_url=self.redirect_url)
                # Inject user info into request context
                request.user_info = claims
                self.webserver.logger.debug(f"Access granted for email={email}")
                return fn(*args, **kwargs)
            return wrapper
        return decorator

    