# aspxstats

Python 🐍 library for retrieving stats of Battlefield 2 and Battlefield 2142 players

[![ci](https://img.shields.io/github/actions/workflow/status/cetteup/aspxstats/ci.yml?label=ci)](https://github.com/cetteup/aspxstats/actions?query=workflow%3Aci)
[![License](https://img.shields.io/github/license/cetteup/aspxstats)](/LICENSE)
[![Last commit](https://img.shields.io/github/last-commit/cetteup/aspxstats)](https://github.com/cetteup/aspxstats/commits/main)
