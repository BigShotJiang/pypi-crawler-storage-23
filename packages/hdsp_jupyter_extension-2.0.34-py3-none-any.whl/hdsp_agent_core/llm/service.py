"""
LLM 서비스 - vLLM (OpenAI 호환) 프로바이더와의 상호작용 처리

vLLM 프로바이더를 통해 OpenAI 호환 API를 지원합니다.
"""

import json
import ssl
import asyncio
from typing import Dict, Any, Optional
from contextlib import asynccontextmanager
import aiohttp
import certifi


class LLMService:
    """다양한 LLM 프로바이더와 상호작용하는 서비스"""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.provider = config.get("provider", "vllm")
        # certifi 인증서로 SSL 컨텍스트 생성
        self._ssl_context = ssl.create_default_context(cafile=certifi.where())

    # ========== 설정 헬퍼 ==========

    def _get_vllm_config(self) -> tuple[str, str, Dict[str, str]]:
        """vLLM 설정 반환: (model, url, headers)."""
        cfg = self.config.get("vllm", {})
        endpoint = cfg.get("endpoint", "http://localhost:8000").rstrip("/")
        model = cfg.get("model", "default")
        # endpoint가 이미 /v1을 포함하면 중복 추가 방지
        if endpoint.endswith("/v1"):
            url = f"{endpoint}/chat/completions"
        else:
            url = f"{endpoint}/v1/chat/completions"
        headers = {"Content-Type": "application/json"}
        api_key = cfg.get("apiKey", "")
        if not api_key:
            raise Exception(
                "API 키가 설정되지 않았습니다. 설정 패널에서 API 키를 입력해주세요."
            )
        headers["Authorization"] = f"Bearer {api_key}"
        return model, url, headers

    # ========== 메시지/페이로드 빌더 ==========

    def _build_prompt(self, prompt: str, context: Optional[str] = None) -> str:
        """선택적 컨텍스트와 함께 전체 프롬프트 구성"""
        if context:
            return f"Context:\n{context}\n\nUser Request:\n{prompt}"
        return prompt

    async def _retry_with_backoff(
        self,
        operation,
        max_retries: int = 3,
        provider: str = "API",
        retryable_statuses: tuple = (503, 429),
    ):
        """지수 백오프 재시도 로직으로 작업 실행"""
        for attempt in range(max_retries):
            try:
                return await operation()
            except asyncio.TimeoutError:
                if attempt < max_retries - 1:
                    wait_time = (2**attempt) * 3
                    print(
                        f"[LLMService] 요청 시간 초과. {wait_time}초 후 재시도... (시도 {attempt + 1}/{max_retries})"
                    )
                    await asyncio.sleep(wait_time)
                    continue
                raise Exception(f"{max_retries}회 재시도 후 요청 시간 초과")
            except Exception as e:
                error_msg = str(e)
                # 속도 제한 (429) 오류는 재시도 가능
                if "rate limit" in error_msg.lower() or "(429)" in error_msg:
                    if attempt < max_retries - 1:
                        wait_time = 40 + (attempt * 20)
                        print(
                            f"[LLMService] 속도 제한 도달. 재시도 전 {wait_time}초 대기... (시도 {attempt + 1}/{max_retries})"
                        )
                        await asyncio.sleep(wait_time)
                        continue
                    raise Exception(
                        f"{max_retries}회 재시도 후 속도 제한 초과. 잠시 후 다시 시도하세요."
                    )
                # 서버 과부하 (503) 오류도 재시도 가능
                if "overloaded" in error_msg.lower() or "(503)" in error_msg:
                    if attempt < max_retries - 1:
                        wait_time = (2**attempt) * 5
                        print(
                            f"[LLMService] 서버 과부하. {wait_time}초 후 재시도... (시도 {attempt + 1}/{max_retries})"
                        )
                        await asyncio.sleep(wait_time)
                        continue
                    raise
                # 다른 API 오류는 즉시 실패
                if "API error" in error_msg and "rate limit" not in error_msg.lower():
                    raise
                if "timeout" in error_msg.lower():
                    raise
                # 네트워크 오류 재시도
                if attempt < max_retries - 1:
                    wait_time = (2**attempt) * 2
                    print(
                        f"[LLMService] 네트워크 오류: {e}. {wait_time}초 후 재시도... (시도 {attempt + 1}/{max_retries})"
                    )
                    await asyncio.sleep(wait_time)
                    continue
                raise

    @asynccontextmanager
    async def _request(
        self,
        url: str,
        payload: Dict[str, Any],
        headers: Optional[Dict[str, str]] = None,
        timeout_seconds: int = 60,
        provider: str = "API",
    ):
        """자동 세션 정리가 포함된 HTTP POST 요청 컨텍스트 관리자"""
        timeout = aiohttp.ClientTimeout(total=timeout_seconds)
        connector = aiohttp.TCPConnector(ssl=self._ssl_context)
        async with aiohttp.ClientSession(
            timeout=timeout, connector=connector
        ) as session:
            async with session.post(url, json=payload, headers=headers) as response:
                if response.status != 200:
                    error_text = await response.text()
                    print(f"[LLMService] {provider} API 오류: {error_text}")
                    if response.status in (401, 403):
                        raise Exception(
                            "API 키가 유효하지 않거나 만료되었습니다. "
                            "설정 패널에서 API 키를 확인해주세요."
                        )
                    elif response.status == 429:
                        raise Exception("요청 한도 초과. 잠시 후 다시 시도해주세요.")
                    else:
                        raise Exception(
                            f"{provider} API 서버 오류 ({response.status}). "
                            "엔드포인트 설정을 확인하거나 잠시 후 재시도하세요."
                        )
                yield response

    async def _request_json(
        self,
        url: str,
        payload: Dict[str, Any],
        headers: Optional[Dict[str, str]] = None,
        timeout_seconds: int = 60,
        provider: str = "API",
    ) -> Dict[str, Any]:
        """요청 수행 및 JSON 응답 반환"""
        async with self._request(
            url, payload, headers, timeout_seconds, provider
        ) as response:
            return await response.json()

    async def _stream_response(
        self,
        url: str,
        payload: Dict[str, Any],
        headers: Optional[Dict[str, str]],
        provider: str,
        line_parser,
    ):
        """응답 스트리밍 및 파싱된 콘텐츠 yield"""
        async with self._request(
            url, payload, headers, timeout_seconds=120, provider=provider
        ) as response:
            async for line in response.content:
                line_text = line.decode("utf-8").strip()
                content = line_parser(line_text)
                if content:
                    yield content

    # ========== 응답 파서 ==========

    def _parse_openai_response(self, data: Dict[str, Any]) -> str:
        """OpenAI 호환 응답 형식 파싱 (OpenAI 및 vLLM에서 사용)"""
        if "choices" in data and len(data["choices"]) > 0:
            choice = data["choices"][0]
            if "message" in choice and "content" in choice["message"]:
                return choice["message"]["content"]
            elif "text" in choice:
                return choice["text"]
        raise Exception("API로부터 유효한 응답 없음")

    def _parse_sse_line(self, line_text: str, extractor) -> Optional[str]:
        """주어진 추출기 함수로 SSE 라인 파싱"""
        if not line_text.startswith("data: "):
            return None
        data_str = line_text[6:]
        if data_str == "[DONE]":
            return None
        try:
            data = json.loads(data_str)
            return extractor(data)
        except json.JSONDecodeError:
            return None

    def _extract_openai_delta(self, data: Dict[str, Any]) -> Optional[str]:
        """OpenAI 스트림 데이터에서 콘텐츠 델타 추출"""
        if "choices" in data and len(data["choices"]) > 0:
            delta = data["choices"][0].get("delta", {})
            return delta.get("content", "") or None
        return None

    def _parse_openai_stream_line(self, line_text: str) -> Optional[str]:
        """OpenAI 호환 스트림의 단일 SSE 라인 파싱"""
        return self._parse_sse_line(line_text, self._extract_openai_delta)

    def _build_openai_payload(
        self,
        model: str,
        messages: list,
        max_tokens: int = 4096,
        temperature: float = 0.0,
        stream: bool = False,
    ) -> Dict[str, Any]:
        """OpenAI 호환 요청 페이로드 구성"""
        return {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": stream,
        }

    async def generate_response_stream(
        self, prompt: str, context: Optional[str] = None
    ):
        """설정된 LLM 프로바이더로부터 스트리밍 응답 생성 (비동기 제너레이터)"""
        if self.provider == "vllm":
            async for chunk in self._call_vllm_stream(prompt, context):
                yield chunk
        else:
            raise ValueError(f"지원되지 않는 프로바이더: {self.provider}")

    async def generate_response(
        self, prompt: str, context: Optional[str] = None
    ) -> str:
        """설정된 LLM 프로바이더로부터 응답 생성"""
        if self.provider == "vllm":
            return await self._call_vllm(prompt, context)
        else:
            raise ValueError(f"지원되지 않는 프로바이더: {self.provider}")

    async def _call_vllm(self, prompt: str, context: Optional[str] = None) -> str:
        """OpenAI 호환 API로 vLLM 엔드포인트 호출"""
        model, url, headers = self._get_vllm_config()
        full_prompt = self._build_prompt(prompt, context)
        messages = [{"role": "user", "content": full_prompt}]
        payload = self._build_openai_payload(model, messages, stream=False)

        data = await self._request_json(url, payload, headers, provider="vLLM")
        return self._parse_openai_response(data)

    async def _call_vllm_stream(self, prompt: str, context: Optional[str] = None):
        """스트리밍으로 vLLM 엔드포인트 호출"""
        model, url, headers = self._get_vllm_config()
        full_prompt = self._build_prompt(prompt, context)
        messages = [{"role": "user", "content": full_prompt}]
        payload = self._build_openai_payload(model, messages, stream=True)

        async for content in self._stream_response(
            url, payload, headers, "vLLM", self._parse_openai_stream_line
        ):
            yield content


# Auto-Agent를 위한 모듈 수준 헬퍼 함수
async def call_llm(
    prompt: str, config: Dict[str, Any], context: Optional[str] = None
) -> str:
    """
    주어진 설정으로 LLM을 호출하는 편의 함수.

    Args:
        prompt: LLM에 보낼 프롬프트
        config: LLM 설정 딕셔너리
        context: 포함할 선택적 컨텍스트

    Returns:
        LLM 응답 문자열
    """
    service = LLMService(config)
    return await service.generate_response(prompt, context)


async def call_llm_stream(
    prompt: str, config: Dict[str, Any], context: Optional[str] = None
):
    """
    주어진 설정으로 LLM 응답을 스트리밍하는 편의 함수.

    Args:
        prompt: LLM에 보낼 프롬프트
        config: LLM 설정 딕셔너리
        context: 포함할 선택적 컨텍스트

    Yields:
        도착하는 응답 청크
    """
    service = LLMService(config)
    async for chunk in service.generate_response_stream(prompt, context):
        yield chunk
