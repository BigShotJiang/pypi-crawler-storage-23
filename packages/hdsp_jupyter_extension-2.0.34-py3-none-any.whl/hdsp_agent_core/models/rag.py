"""
RAG 설정 및 API Pydantic 모델

로컬 RAG 시스템을 위한 설정 스키마 정의:
- Qdrant 벡터 데이터베이스 설정
- 임베딩 모델 설정
- 문서 청킹 설정
- 파일 감시(watchdog) 설정
- 검색 API 요청/응답 모델
"""

import os
from typing import Optional, List, Literal, Dict, Any
from pydantic import BaseModel, Field


class QdrantConfig(BaseModel):
    """Qdrant 벡터 데이터베이스 설정"""

    mode: Literal["local", "server", "cloud"] = Field(
        default="local",
        description="배포 모드: local (파일 기반), server (Docker), cloud",
    )
    # 로컬 모드 설정
    local_path: Optional[str] = Field(
        default=None,
        description="로컬 Qdrant 저장소 경로. 기본값: ~/.hdsp_agent/qdrant",
    )
    # 서버 모드 설정
    url: Optional[str] = Field(
        default="http://localhost:6333",
        description="server/cloud 모드용 Qdrant 서버 URL",
    )
    api_key: Optional[str] = Field(default=None, description="cloud 모드용 API 키")
    # 컬렉션 설정
    collection_name: str = Field(
        default="hdsp_knowledge", description="벡터 컬렉션 이름"
    )

    def get_mode(self) -> str:
        """Qdrant 배포 모드 반환"""
        return self.mode

    def get_url(self) -> str:
        """Qdrant 서버 URL 반환"""
        return self.url or "http://localhost:6333"

    def get_local_path(self) -> str:
        """해석된 로컬 경로 반환"""
        if self.local_path:
            return os.path.expanduser(self.local_path)
        return os.path.expanduser("~/.hdsp_agent/qdrant")


class EmbeddingConfig(BaseModel):
    """임베딩 모델 설정"""

    model_name: str = Field(
        default="intfloat/multilingual-e5-small",
        description="임베딩용 HuggingFace 모델 이름",
    )
    device: Literal["cpu", "cuda", "mps"] = Field(
        default="cpu", description="임베딩 계산용 디바이스"
    )
    batch_size: int = Field(default=32, description="임베딩 생성 배치 크기")
    cache_folder: Optional[str] = Field(
        default=None, description="모델 캐시 폴더. 기본값: ~/.cache/huggingface"
    )
    # 모델별 설정
    normalize_embeddings: bool = Field(
        default=True, description="코사인 유사도를 위한 임베딩 정규화"
    )

    def get_model_name(self) -> str:
        """임베딩 모델 이름 반환"""
        return self.model_name

    def get_device(self) -> str:
        """임베딩 계산 디바이스 반환"""
        return self.device


class ChunkingConfig(BaseModel):
    """문서 청킹 설정"""

    chunk_size: int = Field(default=512, description="목표 청크 크기 (문자 단위)")
    chunk_overlap: int = Field(default=50, description="청크 간 중첩 (문자 단위)")
    split_by_header: bool = Field(
        default=True, description="의미적 경계를 위해 마크다운을 헤더 기준으로 분할"
    )
    min_chunk_size: int = Field(default=100, description="포함할 최소 청크 크기")
    max_chunk_size: int = Field(default=2000, description="최대 청크 크기 (하드 리밋)")


class WatchdogConfig(BaseModel):
    """파일 모니터링 설정"""

    enabled: bool = Field(default=True, description="파일 시스템 모니터링 활성화")
    debounce_seconds: float = Field(
        default=2.0, description="파일 변경 이벤트 디바운스 시간"
    )
    patterns: List[str] = Field(
        default=["*.md", "*.py", "*.txt", "*.json"], description="모니터링할 파일 패턴"
    )
    ignore_patterns: List[str] = Field(
        default=[".*", "__pycache__", "*.pyc", "*.egg-info"], description="무시할 패턴"
    )


class RAGConfig(BaseModel):
    """메인 RAG 시스템 설정"""

    enabled: bool = Field(default=True, description="RAG 시스템 활성화")
    knowledge_base_path: Optional[str] = Field(
        default=None, description="지식 베이스 경로. 기본값: 내장 libraries/"
    )
    qdrant: QdrantConfig = Field(default_factory=QdrantConfig)
    embedding: EmbeddingConfig = Field(default_factory=EmbeddingConfig)
    chunking: ChunkingConfig = Field(default_factory=ChunkingConfig)
    watchdog: WatchdogConfig = Field(default_factory=WatchdogConfig)

    # 검색 설정
    top_k: int = Field(default=5, description="검색할 청크 수")
    score_threshold: float = Field(default=0.3, description="최소 유사도 점수 임계값")
    max_context_tokens: int = Field(
        default=1500, description="RAG 컨텍스트 주입 최대 토큰"
    )

    def is_enabled(self) -> bool:
        """RAG 활성화 여부 확인"""
        return self.enabled

    def get_knowledge_base_path(self) -> Optional[str]:
        """지식 베이스 경로 반환"""
        if self.knowledge_base_path:
            return os.path.expanduser(self.knowledge_base_path)
        return None  # 내장 기본값 사용


# ============ API 요청/응답 모델 ============


class SearchRequest(BaseModel):
    """명시적 RAG 검색 요청 본문"""

    query: str = Field(description="검색 쿼리")
    top_k: Optional[int] = Field(default=None, description="기본 top_k 오버라이드")
    filters: Optional[Dict[str, Any]] = Field(
        default=None, description="메타데이터 필터 (예: {'source_type': 'library'})"
    )
    include_score: bool = Field(default=True, description="결과에 관련성 점수 포함")


class SearchResult(BaseModel):
    """단일 검색 결과"""

    content: str = Field(description="청크 내용")
    score: float = Field(description="관련성 점수 (0-1)")
    metadata: Dict[str, Any] = Field(description="청크 메타데이터 (소스, 유형 등)")


class SearchResponse(BaseModel):
    """RAG 검색 응답 본문"""

    results: List[SearchResult] = Field(description="관련성순으로 정렬된 검색 결과")
    query: str = Field(description="원본 쿼리")
    total_results: int = Field(description="총 일치 청크 수")


class IndexStatusResponse(BaseModel):
    """인덱스 상태 응답 본문"""

    ready: bool = Field(description="RAG 시스템 준비 여부")
    total_documents: int = Field(default=0, description="총 인덱싱된 문서 수")
    total_chunks: int = Field(default=0, description="총 인덱싱된 청크 수")
    last_updated: Optional[str] = Field(
        default=None, description="마지막 인덱스 업데이트 타임스탬프"
    )
    knowledge_base_path: Optional[str] = Field(
        default=None, description="현재 지식 베이스 경로"
    )


class ReindexRequest(BaseModel):
    """수동 재인덱싱 요청 본문"""

    force: bool = Field(
        default=False, description="파일이 변경되지 않아도 전체 재인덱싱 강제"
    )
    path: Optional[str] = Field(
        default=None, description="재인덱싱할 특정 파일 또는 디렉토리"
    )


class ReindexResponse(BaseModel):
    """재인덱싱 작업 응답 본문"""

    success: bool = Field(description="재인덱싱 성공 여부")
    indexed: int = Field(description="인덱싱된 파일 수")
    skipped: int = Field(description="건너뛴 파일 수 (변경 없음)")
    errors: List[Dict[str, str]] = Field(default=[], description="인덱싱 오류 목록")


# ============ 디버그 모델 ============


class ChunkDebugInfo(BaseModel):
    """디버깅용 청크 상세 점수 정보"""

    chunk_id: str
    content_preview: str  # 처음 200자
    score: float  # 벡터 유사도 점수 (0-1)
    rank: int  # 순위
    metadata: Dict[str, Any]  # source, section 등
    passed_threshold: bool  # 임계값 통과 여부


class LibraryDetectionDebug(BaseModel):
    """라이브러리 감지 단계 디버그 정보"""

    input_query: str
    imported_libraries: List[str]
    available_libraries: List[str]
    detected_libraries: List[str]
    detection_method: str


class SearchConfigDebug(BaseModel):
    """검색 설정 정보"""

    top_k: int
    score_threshold: float
    max_context_tokens: int


class DebugSearchRequest(BaseModel):
    """디버그 검색 요청"""

    query: str = Field(description="디버깅용 검색 쿼리")
    imported_libraries: List[str] = Field(
        default=[], description="검색 필터링을 위한 import된 라이브러리 목록"
    )
    top_k: Optional[int] = Field(default=None, description="기본 top_k 오버라이드")
    include_full_content: bool = Field(
        default=False, description="미리보기 대신 전체 내용 포함"
    )
    simulate_plan_context: bool = Field(
        default=True, description="계획 생성 시와 같은 포맷된 컨텍스트 생성"
    )


class DebugSearchResponse(BaseModel):
    """디버그 검색 응답"""

    library_detection: LibraryDetectionDebug
    config: SearchConfigDebug
    chunks: List[ChunkDebugInfo]
    total_candidates: int
    total_passed_threshold: int
    search_ms: float  # 벡터 검색 시간 (밀리초)
    formatted_context: str
    context_char_count: int
    estimated_context_tokens: int


# ============ 팩토리 함수 ============


def get_default_rag_config() -> RAGConfig:
    """ConfigManager JSON에서 RAG 설정 로드"""
    from hdsp_agent_core.managers.config_manager import get_config_manager

    cfg = get_config_manager().get_config()
    rag = cfg.get("rag", {})
    return RAGConfig(
        enabled=rag.get("enabled", True),
        knowledge_base_path=rag.get("knowledgeBasePath"),
        qdrant=QdrantConfig(
            mode=rag.get("qdrantMode", "local"),
            url=rag.get("qdrantUrl", "http://localhost:6333"),
            local_path=rag.get("qdrantPath"),
            collection_name=rag.get("collectionName", "hdsp_knowledge"),
        ),
        embedding=EmbeddingConfig(
            model_name=rag.get("embeddingModel", "intfloat/multilingual-e5-small"),
            device=rag.get("embeddingDevice", "cpu"),
        ),
        chunking=ChunkingConfig(),
        watchdog=WatchdogConfig(),
    )
