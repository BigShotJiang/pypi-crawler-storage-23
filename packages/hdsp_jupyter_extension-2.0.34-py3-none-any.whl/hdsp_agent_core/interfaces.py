"""
HDSP Agent Core - 서비스 인터페이스

Embedded/Proxy 모드 추상화를 위한 추상 서비스 인터페이스.
이 인터페이스들은 직접 인프로세스 서비스 또는 HTTP 프록시로
구현될 수 있는 에이전트 서비스의 계약을 정의합니다.
"""

from abc import ABC, abstractmethod
from typing import Any, AsyncGenerator, Dict, List, Optional

from hdsp_agent_core.models.agent import (
    PlanRequest,
    PlanResponse,
    RefineRequest,
    RefineResponse,
    ReplanRequest,
    ReplanResponse,
)
from hdsp_agent_core.models.chat import ChatRequest, ChatResponse
from hdsp_agent_core.models.rag import SearchRequest, SearchResponse


class IAgentService(ABC):
    """
    에이전트 서비스의 추상 인터페이스.

    계획 생성, 코드 개선, 재계획 작업을 처리합니다.
    다음과 같이 구현될 수 있습니다:
    - EmbeddedAgentService: 직접 인프로세스 실행
    - ProxyAgentService: 외부 에이전트 서버로의 HTTP 프록시
    """

    @abstractmethod
    async def generate_plan(self, request: PlanRequest) -> PlanResponse:
        """
        자연어 요청으로부터 실행 계획을 생성합니다.

        Args:
            request: 사용자 요청과 노트북 컨텍스트가 포함된 계획 생성 요청

        Returns:
            구조화된 실행 계획이 담긴 PlanResponse
        """
        ...

    @abstractmethod
    async def refine_code(self, request: RefineRequest) -> RefineResponse:
        """
        실행 오류 발생 후 코드를 개선합니다.

        Args:
            request: 실패한 단계와 오류 정보가 포함된 개선 요청

        Returns:
            수정된 도구 호출이 담긴 RefineResponse
        """
        ...

    @abstractmethod
    async def replan(self, request: ReplanRequest) -> ReplanResponse:
        """
        실패한 단계를 어떻게 처리할지 결정합니다.

        오류 분류를 사용하여 복구 전략을 결정합니다.

        Args:
            request: 오류 세부사항과 실행 컨텍스트가 포함된 재계획 요청

        Returns:
            결정과 변경사항이 담긴 ReplanResponse
        """
        ...

    @abstractmethod
    async def validate_code(
        self, code: str, notebook_context: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        실행 전 코드를 검증합니다.

        Args:
            code: 검증할 Python 코드
            notebook_context: 검증을 위한 선택적 노트북 컨텍스트

        Returns:
            이슈와 의존성이 포함된 검증 결과
        """
        ...


class IChatService(ABC):
    """
    채팅 서비스의 추상 인터페이스.

    LLM과의 대화형 상호작용을 처리합니다.
    다음과 같이 구현될 수 있습니다:
    - EmbeddedChatService: 직접 인프로세스 LLM 호출
    - ProxyChatService: 외부 채팅 서버로의 HTTP 프록시
    """

    @abstractmethod
    async def send_message(self, request: ChatRequest) -> ChatResponse:
        """
        채팅 메시지를 보내고 응답을 받습니다.

        Args:
            request: 메시지와 선택적 대화 ID가 포함된 채팅 요청

        Returns:
            LLM 응답과 대화 ID가 담긴 ChatResponse
        """
        ...

    @abstractmethod
    async def send_message_stream(
        self, request: ChatRequest
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        채팅 메시지를 보내고 스트리밍 응답을 받습니다.

        Args:
            request: 메시지와 선택적 대화 ID가 포함된 채팅 요청

        Yields:
            부분 콘텐츠가 포함된 스트림 청크
        """
        ...


class IRAGService(ABC):
    """
    RAG 서비스의 추상 인터페이스.

    검색 증강 생성 작업을 처리합니다.
    다음과 같이 구현될 수 있습니다:
    - EmbeddedRAGService: Qdrant를 사용한 직접 인프로세스 RAG
    - ProxyRAGService: 외부 RAG 서버로의 HTTP 프록시
    """

    @abstractmethod
    async def search(self, request: SearchRequest) -> SearchResponse:
        """
        지식 베이스를 검색합니다.

        Args:
            request: 쿼리와 선택적 필터가 포함된 검색 요청

        Returns:
            일치하는 문서와 점수가 담긴 SearchResponse
        """
        ...

    @abstractmethod
    async def get_context_for_query(
        self,
        query: str,
        detected_libraries: Optional[List[str]] = None,
        max_results: int = 5,
    ) -> Optional[str]:
        """
        쿼리에 대한 포맷된 컨텍스트를 가져옵니다 (프롬프트 주입용).

        Args:
            query: 사용자 쿼리
            detected_libraries: 쿼리에서 감지된 라이브러리들
            max_results: 포함할 최대 결과 수

        Returns:
            포맷된 컨텍스트 문자열 또는 사용 불가시 None
        """
        ...

    @abstractmethod
    def is_ready(self) -> bool:
        """
        RAG 서비스가 준비되었는지 확인합니다.

        Returns:
            서비스가 초기화되어 준비되면 True
        """
        ...

    @abstractmethod
    async def get_index_status(self) -> Dict[str, Any]:
        """
        현재 인덱스 상태를 가져옵니다.

        Returns:
            문서 수, 컬렉션 등이 포함된 인덱스 상태
        """
        ...

    @abstractmethod
    async def trigger_reindex(self, force: bool = False) -> Dict[str, Any]:
        """
        재인덱싱 작업을 트리거합니다.

        Args:
            force: True이면 필요하지 않아도 전체 재인덱싱 강제 실행

        Returns:
            재인덱싱 작업 상태
        """
        ...
