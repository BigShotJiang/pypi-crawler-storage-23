"""
RAG 서비스 구현

IRAGService의 Embedded 및 Proxy 구현.
"""

import logging
from typing import Any, Dict, List, Optional

import httpx

from hdsp_agent_core.interfaces import IRAGService
from hdsp_agent_core.models.rag import SearchRequest, SearchResponse

logger = logging.getLogger(__name__)


class EmbeddedRAGService(IRAGService):
    """
    RAG 서비스의 Embedded 구현.

    HTTP 호출 없이 인프로세스에서 직접 RAGManager를 사용합니다.
    개발 모드(HDSP_AGENT_MODE=embedded)에서 사용됩니다.
    """

    def __init__(self):
        """Embedded RAG 서비스 초기화"""
        self._rag_manager = None
        self._initialized = False
        logger.info("EmbeddedRAGService 생성됨 (아직 초기화되지 않음)")

    async def initialize(self) -> None:
        """RAG 관리자 초기화."""
        if self._initialized:
            return
        try:
            from hdsp_agent_core.services.rag_manager import get_rag_manager

            self._rag_manager = get_rag_manager()
            success = await self._rag_manager.initialize()
            self._initialized = success
            if success:
                logger.info("EmbeddedRAGService: RAG 초기화 완료")
            else:
                logger.info("EmbeddedRAGService: RAG 비활성화 (설정)")
        except Exception as e:
            logger.warning(f"EmbeddedRAGService: RAG 초기화 실패: {e}")
            self._initialized = False

    async def shutdown(self) -> None:
        """RAG 서비스 종료"""
        self._rag_manager = None
        self._initialized = False
        logger.info("EmbeddedRAGService 종료됨")

    def is_ready(self) -> bool:
        """RAG 서비스 준비 상태 확인"""
        if not self._initialized or not self._rag_manager:
            return False
        return self._rag_manager.is_ready

    async def search(self, request: SearchRequest) -> SearchResponse:
        """지식 베이스 검색"""
        logger.info(f"[Embedded] RAG 검색: {request.query[:100]}...")

        if not self.is_ready():
            return SearchResponse(
                results=[],
                total=0,
                query=request.query,
            )

        results = await self._rag_manager.search(
            query=request.query,
            collection=request.collection,
            limit=request.limit,
            score_threshold=request.scoreThreshold,
        )

        return SearchResponse(
            results=results.get("results", []),
            total=results.get("total", 0),
            query=request.query,
        )

    async def get_context_for_query(
        self,
        query: str,
        detected_libraries: Optional[List[str]] = None,
        max_results: int = 5,
    ) -> Optional[str]:
        """쿼리에 대한 포맷된 컨텍스트 가져오기"""
        logger.info(f"[Embedded] 쿼리 컨텍스트 조회: {query[:100]}...")

        if not self.is_ready():
            return None

        try:
            return await self._rag_manager.get_context_for_query(
                query=query,
                detected_libraries=detected_libraries,
                max_results=max_results,
            )
        except Exception as e:
            logger.error(f"RAG 컨텍스트 조회 실패: {e}")
            return None

    async def get_index_status(self) -> Dict[str, Any]:
        """현재 인덱스 상태 가져오기"""
        logger.info("[Embedded] 인덱스 상태 조회")

        if not self.is_ready():
            return {
                "ready": False,
                "documentCount": 0,
                "collections": [],
                "message": "RAG 서비스가 초기화되지 않음",
            }

        try:
            return await self._rag_manager.get_index_status()
        except Exception as e:
            logger.error(f"인덱스 상태 조회 실패: {e}")
            return {
                "ready": False,
                "documentCount": 0,
                "collections": [],
                "message": str(e),
            }

    async def trigger_reindex(self, force: bool = False) -> Dict[str, Any]:
        """재인덱싱 작업 트리거"""
        logger.info(f"[Embedded] 재인덱싱 트리거 (force={force})")

        if not self.is_ready():
            return {
                "success": False,
                "message": "RAG 서비스가 초기화되지 않음",
            }

        try:
            return await self._rag_manager.trigger_reindex(force=force)
        except Exception as e:
            logger.error(f"재인덱싱 트리거 실패: {e}")
            return {
                "success": False,
                "message": str(e),
            }


class ProxyRAGService(IRAGService):
    """
    RAG 서비스의 Proxy 구현.

    HTTP를 통해 외부 에이전트 서버로 요청을 전달합니다.
    프로덕션 모드(HDSP_AGENT_MODE=proxy)에서 사용됩니다.
    """

    def __init__(self, base_url: str, timeout: float = 120.0):
        """Proxy RAG 서비스 초기화"""
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._ready = False
        logger.info(f"ProxyRAGService 초기화됨 (서버: {self._base_url})")

    async def initialize(self) -> None:
        """서버 연결 및 RAG 가용성 확인"""
        try:
            status = await self.get_index_status()
            self._ready = status.get("ready", False)
            logger.info(f"ProxyRAGService 준비 상태: {self._ready}")
        except Exception as e:
            logger.warning(f"RAG 서버 확인 실패: {e}")
            self._ready = False

    async def shutdown(self) -> None:
        """프록시 서비스 종료"""
        self._ready = False

    def is_ready(self) -> bool:
        """RAG 서비스 준비 상태 확인"""
        return self._ready

    async def _request(
        self, method: str, path: str, data: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """RAG 서버로 HTTP 요청"""
        url = f"{self._base_url}{path}"

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            if method == "POST":
                response = await client.post(url, json=data)
            elif method == "GET":
                response = await client.get(url)
            else:
                raise ValueError(f"지원되지 않는 메서드: {method}")

            response.raise_for_status()
            return response.json()

    async def search(self, request: SearchRequest) -> SearchResponse:
        """프록시를 통해 검색"""
        logger.info(f"[Proxy] RAG 검색: {request.query[:100]}...")

        data = request.model_dump(mode="json")
        result = await self._request("POST", "/rag/search", data)

        return SearchResponse(**result)

    async def get_context_for_query(
        self,
        query: str,
        detected_libraries: Optional[List[str]] = None,
        max_results: int = 5,
    ) -> Optional[str]:
        """프록시를 통해 컨텍스트 가져오기"""
        logger.info(f"[Proxy] 쿼리 컨텍스트 조회: {query[:100]}...")

        data = {
            "query": query,
            "detected_libraries": detected_libraries,
            "max_results": max_results,
        }

        try:
            result = await self._request("POST", "/rag/context", data)
            return result.get("context")
        except Exception as e:
            logger.error(f"프록시를 통한 RAG 컨텍스트 조회 실패: {e}")
            return None

    async def get_index_status(self) -> Dict[str, Any]:
        """프록시를 통해 인덱스 상태 가져오기"""
        logger.info("[Proxy] 인덱스 상태 조회")

        try:
            return await self._request("GET", "/rag/status")
        except Exception as e:
            logger.error(f"프록시를 통한 인덱스 상태 조회 실패: {e}")
            return {
                "ready": False,
                "documentCount": 0,
                "collections": [],
                "message": str(e),
            }

    async def trigger_reindex(self, force: bool = False) -> Dict[str, Any]:
        """프록시를 통해 재인덱싱 트리거"""
        logger.info(f"[Proxy] 재인덱싱 트리거 (force={force})")

        data = {"force": force}

        try:
            return await self._request("POST", "/rag/reindex", data)
        except Exception as e:
            logger.error(f"프록시를 통한 재인덱싱 트리거 실패: {e}")
            return {
                "success": False,
                "message": str(e),
            }
