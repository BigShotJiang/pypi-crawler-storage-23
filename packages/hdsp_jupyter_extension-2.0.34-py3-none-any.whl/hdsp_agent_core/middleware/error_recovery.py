"""
Error Recovery Middleware - 런타임 에러 발생 시 자동 Re-plan 프롬프트 주입

HITL 도구(jupyter_cell_tool 등)에서 에러가 반환되면:
1. ErrorClassifier로 에러를 분류 (기존 코드 재사용)
2. ReplanDecision에 따른 re-plan 프롬프트를 HumanMessage로 주입
3. LLM이 write_todos 업데이트 후 수정된 코드를 실행하도록 유도
"""

import json
import logging
import re
from typing import Optional, Tuple

from langchain_core.messages import HumanMessage

from hdsp_agent_core.core.error_classifier import (
    ErrorAnalysis,
    ReplanDecision,
    get_error_classifier,
)
from hdsp_agent_core.middleware.logging_utils import _with_middleware_logging

logger = logging.getLogger(__name__)

# HITL tools that execute code and can produce runtime errors
HITL_ERROR_TOOLS = {
    "jupyter_cell_tool",
    "jupyter_cell",
    "execute_command_tool",
    "execute_command",
}

# Marker prefix for error recovery messages (used for retry counting)
ERROR_RECOVERY_MARKER = "[ERROR_RECOVERY]"

# Error patterns in tool output
ERROR_PATTERNS = [
    r"(\w+Error):\s*(.+)",
    r"(\w+Exception):\s*(.+)",
    r"Traceback \(most recent call last\)",
]


def create_error_recovery_middleware(wrap_model_call, max_retries: int = 3):
    """Create middleware that injects re-plan prompts when HITL tool errors occur.

    Uses ErrorClassifier (hdsp_agent_core.core.error_classifier) to classify errors
    and generates decision-specific prompts to guide the LLM toward self-correction.

    Args:
        wrap_model_call: LangChain's wrap_model_call decorator
        max_retries: Maximum consecutive error recovery attempts (default: 3)

    Returns:
        Middleware function
    """
    classifier = get_error_classifier()

    @wrap_model_call
    @_with_middleware_logging("error_recovery")
    def error_recovery_replan(request, handler):
        messages = request.messages
        if not messages:
            return handler(request)

        last_msg = messages[-1]

        # 1. Is this a ToolMessage from a HITL tool with an error?
        if not _is_hitl_tool_error(last_msg):
            return handler(request)

        # 2. Check consecutive error recovery count
        recovery_count = _count_error_recoveries(messages)
        if recovery_count >= max_retries:
            logger.warning(
                "Error recovery: max retries reached (%d/%d). Passing through.",
                recovery_count,
                max_retries,
            )
            return handler(request)

        # 3. Extract error parts and classify
        error_type, error_msg, traceback_str = _extract_error_parts(last_msg.content)
        if not error_type:
            return handler(request)

        analysis = classifier.classify(error_type, error_msg, traceback_str)

        logger.info(
            "Error recovery: %s -> %s (attempt %d/%d)",
            error_type,
            analysis.decision.value,
            recovery_count + 1,
            max_retries,
        )

        # 4. Build re-plan prompt
        todos = request.state.get("todos", [])
        prompt = _build_replan_prompt(analysis, todos, error_type, error_msg)

        # 5. Inject HumanMessage with re-plan instructions
        new_messages = list(messages) + [HumanMessage(content=prompt)]
        request = request.override(messages=new_messages)

        return handler(request)

    return error_recovery_replan


def _is_hitl_tool_error(msg) -> bool:
    """Check if a message is a ToolMessage from a HITL tool containing an error.

    Supports both plain text errors and structured JSON with execution_result.
    """
    if getattr(msg, "type", "") != "tool":
        return False

    tool_name = getattr(msg, "name", "") or ""
    if tool_name not in HITL_ERROR_TOOLS:
        return False

    content = getattr(msg, "content", "") or ""
    if not isinstance(content, str):
        return False

    # Check structured execution_result first (from HITL tool execution)
    try:
        data = json.loads(content)
        if isinstance(data, dict):
            exec_result = data.get("execution_result")
            if isinstance(exec_result, dict):
                return exec_result.get("success") is False or bool(
                    exec_result.get("error")
                )
    except (json.JSONDecodeError, TypeError, ValueError):
        pass

    return _has_error_indicators(content)


def _has_error_indicators(content: str) -> bool:
    """Check if content contains Python error indicators."""
    for pattern in ERROR_PATTERNS:
        if re.search(pattern, content):
            return True
    return False


def _count_error_recoveries(messages) -> int:
    """Count consecutive error recovery attempts since last successful HITL result.

    Scans backwards through messages. Counts ERROR_RECOVERY_MARKER occurrences.
    Resets count when a successful (non-error) HITL tool result is found.
    """
    count = 0
    for msg in reversed(messages):
        content = getattr(msg, "content", "") or ""
        msg_type = getattr(msg, "type", "")

        if isinstance(content, str) and ERROR_RECOVERY_MARKER in content:
            count += 1
        elif msg_type == "tool":
            tool_name = getattr(msg, "name", "") or ""
            if tool_name in HITL_ERROR_TOOLS:
                if isinstance(content, str) and _has_error_indicators(content):
                    # Error result - continue counting
                    continue
                else:
                    # Successful result - reset and stop
                    break
            # Non-HITL tool result - skip
            continue
        elif msg_type in ("ai", "human"):
            # Skip AI/human messages that aren't recovery markers
            if msg_type == "human" and isinstance(content, str):
                if ERROR_RECOVERY_MARKER not in content:
                    break
            continue
        else:
            break

    return count


def _extract_error_parts(content: str) -> Tuple[Optional[str], str, str]:
    """Extract error type, message, and traceback from tool output.

    Supports two formats:
    1. Structured JSON with execution_result (from HITL tool execution)
    2. Plain text with Python error patterns (traceback, ErrorType: message)

    Returns:
        (error_type, error_message, traceback_string)
    """
    if not content or not isinstance(content, str):
        return None, "", ""

    # Strategy 1: Structured extraction from JSON tool output with execution_result
    try:
        data = json.loads(content)
        if isinstance(data, dict):
            exec_result = data.get("execution_result")
            if isinstance(exec_result, dict):
                error_type = exec_result.get("error_type")
                if error_type:
                    error_msg = exec_result.get("error", "")
                    # Remove error_type prefix from error message
                    prefix = f"{error_type}: "
                    if error_msg.startswith(prefix):
                        error_msg = error_msg[len(prefix) :]
                    traceback_str = exec_result.get("traceback", "") or ""
                    return error_type, error_msg, traceback_str
    except (json.JSONDecodeError, TypeError, ValueError):
        pass

    # Strategy 2: Regex-based extraction from plain text
    lines = content.strip().split("\n")

    error_type = None
    error_msg = ""

    # Search from the end for error type pattern (Python convention)
    for line in reversed(lines):
        line = line.strip()
        # Remove ANSI escape codes
        line = re.sub(r"\x1b\[[0-9;]*m", "", line)

        # Match "ErrorType: error message" anywhere in the line
        # (re.search handles both standalone lines and embedded in JSON/dict repr)
        match = re.search(r"(\w+(?:Error|Exception)):\s*(.*)", line)
        if match:
            error_type = match.group(1)
            error_msg = match.group(2)
            break

        # Match standalone error type at start of line
        match = re.match(r"^(\w+(?:Error|Exception))\s*$", line)
        if match:
            error_type = match.group(1)
            break

    # Extract traceback
    traceback_str = ""
    traceback_match = re.search(
        r"(Traceback \(most recent call last\)[\s\S]*)", content
    )
    if traceback_match:
        traceback_str = traceback_match.group(1)

    return error_type, error_msg, traceback_str


def _build_replan_prompt(
    analysis: ErrorAnalysis,
    todos: list,
    error_type: str,
    error_msg: str,
) -> str:
    """Build re-plan prompt based on ErrorClassifier analysis."""
    decision = analysis.decision
    guidance = _get_error_guidance(error_type, error_msg)

    # Pending todos context
    pending_todos = [t for t in todos if t.get("status") in ("pending", "in_progress")]
    todos_context = ""
    if pending_todos:
        todo_items = "\n".join(
            f"  - [{t.get('status', '?')}] {t.get('content', '')[:60]}"
            for t in pending_todos[:5]
        )
        todos_context = f"\n\nCurrent pending tasks:\n{todo_items}"

    error_preview = error_msg[:200] if error_msg else "unknown error"

    if decision == ReplanDecision.REFINE:
        prompt = (
            f"{ERROR_RECOVERY_MARKER} The previous code execution failed "
            f"with {error_type}: {error_preview}\n\n"
            f"Root cause: {analysis.root_cause}\n\n"
            f"Instructions:\n"
            f"1. Analyze the error carefully\n"
            f"2. {guidance}\n"
            f"3. Call write_todos to update your plan with the fix approach\n"
            f"4. Call jupyter_cell_tool with corrected code\n"
            f"5. Do NOT call final_answer_tool until the error is resolved"
            f"{todos_context}"
        )
    elif decision == ReplanDecision.INSERT_STEPS:
        pkg = analysis.missing_package or "unknown"
        prompt = (
            f"{ERROR_RECOVERY_MARKER} The previous code execution failed "
            f"because package '{pkg}' is missing.\n\n"
            f"Instructions:\n"
            f"1. Call jupyter_cell_tool to install: !pip install {pkg}\n"
            f"2. Then re-execute the original code\n"
            f"3. Call write_todos to reflect the package installation step\n"
            f"4. Do NOT call final_answer_tool until the error is resolved"
            f"{todos_context}"
        )
    elif decision == ReplanDecision.REPLACE_STEP:
        prompt = (
            f"{ERROR_RECOVERY_MARKER} The previous approach completely failed "
            f"with {error_type}: {error_preview}\n\n"
            f"Root cause: {analysis.root_cause}\n\n"
            f"Instructions:\n"
            f"1. The current approach is not viable - try a completely "
            f"different method\n"
            f"2. {guidance}\n"
            f"3. Call write_todos to replace the current step with a new "
            f"approach\n"
            f"4. Call jupyter_cell_tool with the new approach\n"
            f"5. Do NOT call final_answer_tool until the error is resolved"
            f"{todos_context}"
        )
    elif decision == ReplanDecision.REPLAN_REMAINING:
        prompt = (
            f"{ERROR_RECOVERY_MARKER} A critical error occurred: "
            f"{error_type}: {error_preview}\n\n"
            f"Root cause: {analysis.root_cause}\n\n"
            f"Instructions:\n"
            f"1. This is a fundamental issue requiring replanning all "
            f"remaining steps\n"
            f"2. {guidance}\n"
            f"3. Call write_todos to redesign the remaining plan entirely\n"
            f"4. Start executing the new plan with jupyter_cell_tool\n"
            f"5. Do NOT call final_answer_tool until the error is resolved"
            f"{todos_context}"
        )
    else:
        prompt = (
            f"{ERROR_RECOVERY_MARKER} An error occurred: "
            f"{error_type}: {error_preview}\n\n"
            f"Fix the error and continue. "
            f"Do NOT call final_answer_tool until resolved."
            f"{todos_context}"
        )

    return prompt


def _get_error_guidance(error_type: str, error_msg: str) -> str:
    """Get error-specific guidance for the LLM."""
    guidance_map = {
        "KeyError": (
            "Check the actual column/key names by running "
            "`df.columns.tolist()` or `print(list(dict.keys()))` first. "
            "The key name may differ from what you expected "
            "(case, spaces, encoding)."
        ),
        "FileNotFoundError": (
            "Verify the file path by running "
            "`import os; print(os.listdir('.'))` or checking subdirectories. "
            "The file may be in a different location or have a different name."
        ),
        "NameError": (
            "Ensure all imports and variable definitions are in the same cell. "
            "Variables from previous cells may not be available if the kernel "
            "was restarted."
        ),
        "ModuleNotFoundError": (
            "Install the missing package using "
            "`!pip install <package_name>` before importing."
        ),
        "ImportError": (
            "Check if the package is installed and the import path is correct. "
            "Some packages have different import names than install names "
            "(e.g., `pip install scikit-learn` but `import sklearn`)."
        ),
        "TypeError": (
            "Check function arguments and data types. Verify the correct "
            "number and types of arguments are being passed."
        ),
        "ValueError": (
            "Check input values. Verify data types, ranges, and formats "
            "match what the function expects."
        ),
        "IndexError": (
            "Check array/list bounds. Verify the data has the expected "
            "number of elements before accessing by index."
        ),
        "AttributeError": (
            "Check if the object has the expected type. Use `type(obj)` "
            "and `dir(obj)` to verify available attributes and methods."
        ),
        "SyntaxError": (
            "Check for missing colons, brackets, parentheses, or indentation errors."
        ),
    }

    return guidance_map.get(
        error_type,
        f"Analyze the {error_type} carefully and fix the root cause before retrying.",
    )
