"""
HDSP Agent Core - 서비스 팩토리

HDSP_AGENT_MODE 환경 변수에 따라 Embedded 또는 Proxy 서비스 구현을 생성하는 팩토리.

모드:
- embedded: 서비스가 프로세스 내에서 직접 실행 (개발 모드)
- proxy: 서비스가 HTTP를 통해 외부 에이전트 서버로 프록시 (프로덕션 모드)
"""

import logging
import os
from enum import Enum
from typing import Optional

from hdsp_agent_core.interfaces import IAgentService, IChatService, IRAGService

logger = logging.getLogger(__name__)


class AgentMode(Enum):
    """에이전트 실행 모드"""

    EMBEDDED = "embedded"  # 프로세스 내 직접 실행
    PROXY = "proxy"  # 외부 서버로 HTTP 프록시


class ServiceFactory:
    """
    실행 모드에 따라 서비스 인스턴스를 생성하는 팩토리.

    싱글톤 패턴으로 애플리케이션 전체에서 일관된 서비스 인스턴스를 보장함.

    사용법:
        factory = ServiceFactory.get_instance()
        await factory.initialize()

        agent_service = factory.get_agent_service()
        chat_service = factory.get_chat_service()
        rag_service = factory.get_rag_service()

    환경 변수:
        HDSP_AGENT_MODE: "embedded" 또는 "proxy" (기본값: "proxy")
        AGENT_SERVER_URL: 프록시 모드용 URL (기본값: "http://localhost:8000")
        AGENT_SERVER_TIMEOUT: HTTP 타임아웃 초 단위 (기본값: 120.0)
    """

    _instance: Optional["ServiceFactory"] = None

    def __init__(self):
        """팩토리 초기화 (get_instance() 사용 권장)"""
        self._mode = self._detect_mode()
        self._initialized = False

        # 서비스 인스턴스 (지연 로딩)
        self._agent_service: Optional[IAgentService] = None
        self._chat_service: Optional[IChatService] = None
        self._rag_service: Optional[IRAGService] = None

        # 프록시 설정
        self._server_url = os.environ.get("AGENT_SERVER_URL", "http://localhost:8000")
        self._timeout = float(os.environ.get("AGENT_SERVER_TIMEOUT", "120.0"))

        logger.info(f"ServiceFactory created with mode: {self._mode.value}")

    @classmethod
    def get_instance(cls) -> "ServiceFactory":
        """싱글톤 팩토리 인스턴스 반환"""
        if cls._instance is None:
            cls._instance = ServiceFactory()
        return cls._instance

    @classmethod
    def reset_instance(cls) -> None:
        """싱글톤 인스턴스 초기화 (테스트용)"""
        cls._instance = None

    def _detect_mode(self) -> AgentMode:
        """환경 변수에서 실행 모드 감지"""
        mode_str = os.environ.get("HDSP_AGENT_MODE", "proxy").lower()

        if mode_str == "embedded":
            return AgentMode.EMBEDDED
        elif mode_str == "proxy":
            return AgentMode.PROXY
        else:
            logger.warning(f"Unknown HDSP_AGENT_MODE '{mode_str}', defaulting to proxy")
            return AgentMode.PROXY

    @property
    def mode(self) -> AgentMode:
        """현재 실행 모드 반환"""
        return self._mode

    @property
    def is_embedded(self) -> bool:
        """임베디드 모드 여부 확인"""
        return self._mode == AgentMode.EMBEDDED

    @property
    def is_proxy(self) -> bool:
        """프록시 모드 여부 확인"""
        return self._mode == AgentMode.PROXY

    @property
    def is_initialized(self) -> bool:
        """팩토리 초기화 여부 확인"""
        return self._initialized

    @property
    def server_url(self) -> str:
        """에이전트 서버 URL 반환 (프록시 모드용)"""
        return self._server_url

    @property
    def timeout(self) -> float:
        """HTTP 타임아웃 반환 (프록시 모드용)"""
        return self._timeout

    async def initialize(self) -> None:
        """
        현재 모드에 따라 모든 서비스 초기화.

        임베디드 모드: RAG 매니저 초기화, 지식 베이스 로드
        프록시 모드: 서버 연결 검증
        """
        if self._initialized:
            logger.debug("ServiceFactory already initialized")
            return

        logger.info(f"Initializing ServiceFactory in {self._mode.value} mode")

        if self.is_embedded:
            await self._initialize_embedded_services()
        else:
            await self._initialize_proxy_services()

        self._initialized = True
        logger.info(f"ServiceFactory initialization complete ({self._mode.value} mode)")

    async def _initialize_embedded_services(self) -> None:
        """임베디드 모드용 서비스 초기화"""
        from hdsp_agent_core.services.agent_service import EmbeddedAgentService
        from hdsp_agent_core.services.chat_service import EmbeddedChatService
        from hdsp_agent_core.services.rag_service import EmbeddedRAGService

        # 서비스 인스턴스 생성
        self._agent_service = EmbeddedAgentService()
        self._chat_service = EmbeddedChatService()
        self._rag_service = EmbeddedRAGService()

        # RAG 서비스 초기화 (비동기 초기화 필요할 수 있음)
        await self._rag_service.initialize()

        logger.info("Embedded services initialized")

    async def _initialize_proxy_services(self) -> None:
        """프록시 모드용 서비스 초기화"""
        from hdsp_agent_core.services.agent_service import ProxyAgentService
        from hdsp_agent_core.services.chat_service import ProxyChatService
        from hdsp_agent_core.services.rag_service import ProxyRAGService

        # 프록시 서비스 인스턴스 생성
        self._agent_service = ProxyAgentService(
            base_url=self._server_url, timeout=self._timeout
        )
        self._chat_service = ProxyChatService(
            base_url=self._server_url, timeout=self._timeout
        )
        self._rag_service = ProxyRAGService(
            base_url=self._server_url, timeout=self._timeout
        )

        # 연결 검증 (선택적)
        # await self._validate_server_connectivity()

        logger.info(f"Proxy services initialized (server: {self._server_url})")

    async def shutdown(self) -> None:
        """모든 서비스 종료 및 리소스 정리"""
        logger.info("Shutting down ServiceFactory")

        # RAG 서비스 정리
        if self._rag_service and hasattr(self._rag_service, "shutdown"):
            await self._rag_service.shutdown()

        # 서비스 인스턴스 초기화
        self._agent_service = None
        self._chat_service = None
        self._rag_service = None
        self._initialized = False

        logger.info("ServiceFactory shutdown complete")

    def get_agent_service(self) -> IAgentService:
        """
        Agent 서비스 인스턴스 반환.

        Returns:
            현재 모드에 따른 IAgentService 구현체

        Raises:
            RuntimeError: 팩토리가 초기화되지 않은 경우
        """
        if not self._initialized:
            raise RuntimeError(
                "ServiceFactory not initialized. Call await factory.initialize() first."
            )
        return self._agent_service

    def get_chat_service(self) -> IChatService:
        """
        Chat 서비스 인스턴스 반환.

        Returns:
            현재 모드에 따른 IChatService 구현체

        Raises:
            RuntimeError: 팩토리가 초기화되지 않은 경우
        """
        if not self._initialized:
            raise RuntimeError(
                "ServiceFactory not initialized. Call await factory.initialize() first."
            )
        return self._chat_service

    def get_rag_service(self) -> IRAGService:
        """
        RAG 서비스 인스턴스 반환.

        Returns:
            현재 모드에 따른 IRAGService 구현체

        Raises:
            RuntimeError: 팩토리가 초기화되지 않은 경우
        """
        if not self._initialized:
            raise RuntimeError(
                "ServiceFactory not initialized. Call await factory.initialize() first."
            )
        return self._rag_service


# 싱글톤 팩토리 편의 함수
def get_service_factory() -> ServiceFactory:
    """싱글톤 ServiceFactory 인스턴스 반환"""
    return ServiceFactory.get_instance()
