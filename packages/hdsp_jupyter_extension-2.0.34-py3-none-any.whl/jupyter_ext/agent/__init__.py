"""Agent module for HDSP Agent."""

from .agent_factory import (
    AgentConfig,
    AgentEvent,
    AgentFactory,
    AgentRunner,
    config_from_dict,
)
from .middleware import (
    DSMemoryMiddleware,
    DSSkillsMiddleware,
    MemoryEntry,
    MemoryStore,
)
from .skills_registry import SKILLS_REGISTRY

# Backward compatibility alias
DeepAgentRunner = AgentRunner

__all__ = [
    "AgentConfig",
    "AgentEvent",
    "AgentFactory",
    "AgentRunner",
    "DSMemoryMiddleware",
    "DSSkillsMiddleware",
    "DeepAgentRunner",
    "MemoryEntry",
    "MemoryStore",
    "SKILLS_REGISTRY",
    "config_from_dict",
]
