"""
Jupyter 노트북 조작을 위한 LangChain 호환 도구 모음.

NotebookContextManager를 래핑하여 LangChain Agent에서 사용 가능한
LangChain BaseTool 인터페이스를 제공합니다.
"""

import asyncio
import json
import re
import subprocess
from pathlib import Path
from typing import Optional

from langchain_core.tools import BaseTool, tool

from ..tools.context import NotebookContextManager


def create_jupyter_cell_tool(context: NotebookContextManager) -> BaseTool:
    """
    Jupyter 셀 조작용 LangChain 도구를 생성합니다.

    Args:
        context: 노트북 상태 접근을 위한 NotebookContextManager

    Returns:
        셀 조작용 LangChain BaseTool
    """

    @tool
    def jupyter_cell(
        code: Optional[str] = None,
        description: Optional[str] = None,
        execution_result: Optional[dict] = None,
    ) -> str:
        """Jupyter 노트북에 코드 셀을 생성하고 실행합니다.

        Args:
            code: 실행할 Python 코드
            description: 코드 설명 (선택)
            execution_result: 프론트엔드에서 전달된 실행 결과 (HITL edit decision 경유)

        Returns:
            연산 결과가 담긴 JSON 문자열
        """
        # 마크다운 펜스 정리
        cleaned_code = (code or "").strip()
        if cleaned_code.startswith("```python"):
            cleaned_code = cleaned_code[9:]
        elif cleaned_code.startswith("```"):
            cleaned_code = cleaned_code[3:]
        if cleaned_code.endswith("```"):
            cleaned_code = cleaned_code[:-3]
        cleaned_code = cleaned_code.strip()

        response = {
            "tool": "jupyter_cell",
            "parameters": {"code": cleaned_code, "description": description},
            "status": "pending_execution",
            "message": "Code cell queued for execution",
        }
        if execution_result is not None:
            response["execution_result"] = execution_result
            response["status"] = "complete"
            response["message"] = "Code cell executed with client-reported results"
        return json.dumps(response)

    return jupyter_cell


def create_jupyter_markdown_tool(context: NotebookContextManager) -> BaseTool:
    """
    Jupyter 마크다운 셀 조작용 LangChain 도구를 생성합니다.

    Args:
        context: 노트북 상태 접근을 위한 NotebookContextManager

    Returns:
        마크다운 조작용 LangChain BaseTool
    """

    @tool
    def jupyter_markdown(
        operation: str,
        content: str,
        cell_index: Optional[int] = None,
        insert_after: Optional[int] = None,
    ) -> str:
        """
        Jupyter 노트북에서 마크다운 셀을 생성하거나 수정합니다.

        문서화, 설명, 헤더 추가에 사용합니다.

        Args:
            operation: 수행할 연산 (CREATE 또는 UPDATE)
            content: 마크다운 내용
            cell_index: 셀 인덱스 (UPDATE용)
            insert_after: 이 인덱스 뒤에 새 셀 삽입 (CREATE용)

        Returns:
            연산 결과가 담긴 JSON 문자열
        """
        # HITL 모드: 실제 마크다운 셀 추가는 프론트엔드에서 처리됨.
        return json.dumps(
            {
                "success": True,
                "message": "마크다운 셀이 노트북에 추가되었습니다.",
            }
        )

    return jupyter_markdown


def create_notebook_info_tool(context: NotebookContextManager) -> BaseTool:
    """
    노트북 정보 조회용 LangChain 도구를 생성합니다.

    Args:
        context: 노트북 상태 접근을 위한 NotebookContextManager

    Returns:
        노트북 정보 조회용 LangChain BaseTool
    """

    @tool
    def notebook_info() -> str:
        """
        현재 Jupyter 노트북의 정보를 가져옵니다.

        경로, 셀 개수, 커널 정보를 포함한 요약을 반환합니다.

        Returns:
            노트북 요약이 담긴 JSON 문자열
        """
        # NotebookContextManager가 설정되어 있으면 요약 반환, 아니면 기본값
        if context.current_notebook:
            try:
                summary = context.get_summary()
                return json.dumps({"success": True, "data": summary})
            except Exception as e:
                return json.dumps({"success": False, "error": str(e)})
        return json.dumps(
            {
                "success": True,
                "data": {
                    "path": "unknown",
                    "cell_count": 0,
                    "kernel_name": "python3",
                },
            }
        )

    return notebook_info


# =============================================================================
# 파일 도구
# =============================================================================


def create_file_read_tool(workspace_root: str) -> BaseTool:
    """
    파일 내용 읽기용 LangChain 도구를 생성합니다.

    Args:
        workspace_root: 파일 작업의 루트 디렉토리

    Returns:
        파일 읽기용 LangChain BaseTool
    """
    base_path = Path(workspace_root)

    @tool
    def file_read(path: str, encoding: str = "utf-8") -> str:
        """
        파일 내용을 읽습니다.

        파일 내용을 텍스트로 반환합니다. 바이너리 파일은 오류를 반환합니다.

        Args:
            path: 읽을 파일 경로 (워크스페이스 기준 상대 경로)
            encoding: 파일 인코딩 (기본값: utf-8)

        Returns:
            파일 내용 또는 오류가 담긴 JSON 문자열
        """
        if not path:
            return json.dumps({"success": False, "error": "경로가 필요합니다"})

        try:
            file_path = base_path / path
            if not file_path.exists():
                return json.dumps(
                    {"success": False, "error": f"파일을 찾을 수 없음: {path}"}
                )

            if not file_path.is_file():
                return json.dumps({"success": False, "error": f"파일이 아님: {path}"})

            content = file_path.read_text(encoding=encoding)
            return json.dumps(
                {
                    "success": True,
                    "data": {"content": content, "path": str(path)},
                    "metadata": {"size": len(content), "encoding": encoding},
                }
            )

        except UnicodeDecodeError:
            return json.dumps(
                {"success": False, "error": f"텍스트로 읽을 수 없는 파일: {path}"}
            )
        except Exception as e:
            return json.dumps({"success": False, "error": f"파일 읽기 오류: {e}"})

    return file_read


def create_file_write_tool(workspace_root: str) -> BaseTool:
    """
    파일 내용 쓰기용 LangChain 도구를 생성합니다.

    Args:
        workspace_root: 파일 작업의 루트 디렉토리

    Returns:
        파일 쓰기용 LangChain BaseTool
    """
    base_path = Path(workspace_root)

    @tool
    def file_write(path: str, content: str, append: bool = False) -> str:
        """
        파일에 내용을 씁니다.

        파일이 없으면 생성합니다. 필요시 상위 디렉토리도 생성합니다.
        Python 파일(.py)은 자동으로 ruff check --fix와 ruff format을 실행합니다.

        경고: 이 도구는 파일을 수정할 수 있습니다. HITL 승인이 필요합니다.

        Args:
            path: 쓸 파일 경로 (워크스페이스 기준 상대 경로)
            content: 쓸 내용
            append: 덮어쓰기 대신 추가 (기본값: False)

        Returns:
            연산 결과가 담긴 JSON 문자열
        """
        if not path:
            return json.dumps({"success": False, "error": "경로가 필요합니다"})

        try:
            file_path = base_path / path

            # 필요시 상위 디렉토리 생성
            file_path.parent.mkdir(parents=True, exist_ok=True)

            mode = "a" if append else "w"
            with open(file_path, mode, encoding="utf-8") as f:
                f.write(content)

            result = {
                "success": True,
                "data": {
                    "path": str(path),
                    "operation": "append" if append else "write",
                },
                "metadata": {"size": len(content)},
            }

            # Python 파일은 자동으로 ruff 실행
            if path.endswith(".py"):
                try:
                    ruff_fix = subprocess.run(
                        ["ruff", "check", "--fix", str(file_path)],
                        capture_output=True,
                        timeout=30,
                    )
                    ruff_fmt = subprocess.run(
                        ["ruff", "format", str(file_path)],
                        capture_output=True,
                        timeout=30,
                    )
                    result["metadata"]["ruff_applied"] = True
                    result["metadata"]["ruff_fix_returncode"] = ruff_fix.returncode
                    result["metadata"]["ruff_format_returncode"] = ruff_fmt.returncode
                except FileNotFoundError:
                    result["metadata"]["ruff_applied"] = False
                    result["metadata"]["ruff_note"] = "ruff가 설치되지 않음"
                except subprocess.TimeoutExpired:
                    result["metadata"]["ruff_applied"] = False
                    result["metadata"]["ruff_note"] = "ruff 시간 초과"

            return json.dumps(result)

        except Exception as e:
            return json.dumps({"success": False, "error": f"파일 쓰기 오류: {e}"})

    return file_write


def create_file_list_tool(workspace_root: str) -> BaseTool:
    """
    디렉토리 목록 조회용 LangChain 도구를 생성합니다.

    Args:
        workspace_root: 파일 작업의 루트 디렉토리

    Returns:
        디렉토리 목록 조회용 LangChain BaseTool
    """
    base_path = Path(workspace_root)

    @tool
    def file_list(
        path: str = ".", recursive: bool = False, pattern: Optional[str] = None
    ) -> str:
        """
        경로의 파일과 디렉토리를 나열합니다.

        파일/디렉토리 이름과 타입 목록을 반환합니다.

        Args:
            path: 나열할 디렉토리 경로 (워크스페이스 기준 상대 경로, 기본값: ".")
            recursive: 재귀적으로 나열 (기본값: False)
            pattern: 파일 필터링용 글롭 패턴 (예: '*.py')

        Returns:
            항목 목록이 담긴 JSON 문자열
        """
        try:
            dir_path = base_path / path
            if not dir_path.exists():
                return json.dumps(
                    {"success": False, "error": f"경로를 찾을 수 없음: {path}"}
                )

            if not dir_path.is_dir():
                return json.dumps(
                    {"success": False, "error": f"디렉토리가 아님: {path}"}
                )

            entries = []

            if pattern:
                files = dir_path.rglob(pattern) if recursive else dir_path.glob(pattern)
            else:
                files = dir_path.rglob("*") if recursive else dir_path.iterdir()

            for entry in files:
                try:
                    rel_path = entry.relative_to(base_path)
                    entries.append(
                        {
                            "name": entry.name,
                            "path": str(rel_path),
                            "type": "directory" if entry.is_dir() else "file",
                            "size": entry.stat().st_size if entry.is_file() else None,
                        }
                    )
                except ValueError:
                    # base_path 외부 항목은 건너뜀
                    pass

            return json.dumps(
                {
                    "success": True,
                    "data": {"entries": entries, "path": str(path)},
                    "metadata": {"count": len(entries)},
                }
            )

        except Exception as e:
            return json.dumps(
                {"success": False, "error": f"디렉토리 목록 조회 오류: {e}"}
            )

    return file_list


# =============================================================================
# 셸 도구
# =============================================================================


def create_shell_execute_tool(workspace_root: str, timeout: int = 60) -> BaseTool:
    """
    셸 명령 실행용 LangChain 도구를 생성합니다.

    Args:
        workspace_root: 명령 실행의 작업 디렉토리
        timeout: 기본 시간 제한 (초)

    Returns:
        셸 실행용 LangChain BaseTool
    """

    @tool
    def shell_execute(
        command: str,
        working_dir: Optional[str] = None,
        timeout_seconds: int = 60,
    ) -> str:
        """
        셸 명령을 실행하고 출력을 반환합니다.

        스크립트 실행, 패키지 설치, git 작업 등에 사용합니다.
        경고: 이 도구는 임의의 명령을 실행할 수 있습니다. HITL 승인이 필요합니다.

        Args:
            command: 실행할 셸 명령
            working_dir: 명령의 작업 디렉토리 (기본값: 워크스페이스 루트)
            timeout_seconds: 시간 제한 (초, 기본값: 60)

        Returns:
            stdout, stderr, 반환 코드가 담긴 JSON 문자열
        """
        if not command:
            return json.dumps({"success": False, "error": "명령이 필요합니다"})

        cwd = working_dir if working_dir else workspace_root

        try:
            # asyncio.run을 사용하여 동기 컨텍스트에서 비동기 서브프로세스 실행
            async def run_command():
                process = await asyncio.create_subprocess_shell(
                    command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=cwd,
                )
                try:
                    stdout, stderr = await asyncio.wait_for(
                        process.communicate(),
                        timeout=timeout_seconds,
                    )
                    return process.returncode, stdout, stderr, False
                except asyncio.TimeoutError:
                    process.kill()
                    await process.wait()
                    return -1, b"", b"", True

            # 기존 이벤트 루프가 있으면 가져오고, 없으면 새로 생성
            try:
                asyncio.get_running_loop()
                # 이미 비동기 컨텍스트에 있음 - ThreadPoolExecutor 사용
                import concurrent.futures

                with concurrent.futures.ThreadPoolExecutor() as executor:
                    future = executor.submit(asyncio.run, run_command())
                    returncode, stdout, stderr, timed_out = future.result()
            except RuntimeError:
                # 실행 중인 이벤트 루프 없음 - asyncio.run 사용 가능
                returncode, stdout, stderr, timed_out = asyncio.run(run_command())

            if timed_out:
                return json.dumps(
                    {
                        "success": False,
                        "error": f"{timeout_seconds}초 후 명령 시간 초과",
                        "metadata": {"command": command, "timeout": True},
                    }
                )

            stdout_str = stdout.decode("utf-8", errors="replace") if stdout else ""
            stderr_str = stderr.decode("utf-8", errors="replace") if stderr else ""

            success = returncode == 0

            return json.dumps(
                {
                    "success": success,
                    "data": {
                        "stdout": stdout_str,
                        "stderr": stderr_str,
                        "return_code": returncode,
                    },
                    "error": stderr_str if not success and stderr_str else None,
                    "metadata": {"command": command},
                }
            )

        except Exception as e:
            return json.dumps(
                {
                    "success": False,
                    "error": f"명령 실행 오류: {e}",
                    "metadata": {"command": command},
                }
            )

    return shell_execute


# =============================================================================
# 검색 도구
# =============================================================================


def create_search_code_tool(workspace_root: str) -> BaseTool:
    """
    코드 검색용 LangChain 도구를 생성합니다.

    Args:
        workspace_root: 검색 작업의 루트 디렉토리

    Returns:
        코드 검색용 LangChain BaseTool
    """
    base_path = Path(workspace_root)

    @tool
    def search_code(
        pattern: str,
        path: str = ".",
        file_pattern: str = "*",
        max_results: int = 50,
        case_sensitive: bool = True,
    ) -> str:
        """
        코드 파일에서 패턴을 검색합니다.

        정규식 패턴을 사용하여 파일들에서 일치 항목을 찾습니다.
        파일 경로와 줄 번호가 포함된 일치하는 줄을 반환합니다.

        Args:
            pattern: 검색할 정규식 패턴
            path: 검색할 디렉토리 (워크스페이스 기준 상대 경로, 기본값: ".")
            file_pattern: 검색할 파일의 글롭 패턴 (예: '*.py')
            max_results: 반환할 최대 결과 수 (기본값: 50)
            case_sensitive: 대소문자 구분 검색 (기본값: True)

        Returns:
            일치하는 줄이 담긴 JSON 문자열
        """
        if not pattern:
            return json.dumps({"success": False, "error": "패턴이 필요합니다"})

        try:
            flags = 0 if case_sensitive else re.IGNORECASE
            regex = re.compile(pattern, flags)
        except re.error as e:
            return json.dumps({"success": False, "error": f"잘못된 정규식 패턴: {e}"})

        search_path = base_path / path
        if not search_path.exists():
            return json.dumps(
                {"success": False, "error": f"경로를 찾을 수 없음: {path}"}
            )

        results = []
        try:
            for file_path in search_path.rglob(file_pattern):
                if not file_path.is_file():
                    continue

                # 숨김 디렉토리와 일반적인 비코드 디렉토리 건너뛰기
                if any(
                    part.startswith(".")
                    or part in ("node_modules", "__pycache__", "venv", ".venv")
                    for part in file_path.parts
                ):
                    continue

                try:
                    content = file_path.read_text(encoding="utf-8", errors="ignore")
                    for line_num, line in enumerate(content.splitlines(), 1):
                        if regex.search(line):
                            rel_path = file_path.relative_to(base_path)
                            results.append(
                                {
                                    "file": str(rel_path),
                                    "line": line_num,
                                    "content": line.strip()[:200],  # 긴 줄은 잘라냄
                                }
                            )

                            if len(results) >= max_results:
                                break
                except Exception:
                    # 읽을 수 없는 파일은 건너뜀
                    continue

                if len(results) >= max_results:
                    break

            return json.dumps(
                {
                    "success": True,
                    "data": {"matches": results, "pattern": pattern},
                    "metadata": {
                        "count": len(results),
                        "truncated": len(results) >= max_results,
                    },
                }
            )

        except Exception as e:
            return json.dumps({"success": False, "error": f"검색 오류: {e}"})

    return search_code


# =============================================================================
# LSP 도구 (Grep 기반 대체 구현)
# =============================================================================


def create_diagnostics_tool(workspace_root: str) -> BaseTool:
    """
    코드 진단용 LangChain 도구를 생성합니다.

    정적 분석 도구(ruff, mypy)가 있으면 사용하고,
    없으면 기본 패턴 기반 진단을 제공하는 Python 기반 구현입니다.

    Args:
        workspace_root: 분석의 루트 디렉토리

    Returns:
        진단용 LangChain BaseTool
    """
    base_path = Path(workspace_root)

    @tool
    def diagnostics(
        path: Optional[str] = None, severity_filter: Optional[str] = None
    ) -> str:
        """
        파일 또는 전체 프로젝트의 코드 진단(오류, 경고)을 가져옵니다.

        Python 파일의 문제를 탐지하기 위해 ruff를 실행합니다.
        ruff가 없으면 기본 패턴 기반 검사로 대체합니다.

        이 도구의 용도:
        - 코드 실행 전 문법 오류 확인
        - Python 파일의 타입 오류 및 린트 문제 찾기
        - 사용하지 않는 import나 변수 식별

        Args:
            path: 선택적 파일 경로. 미지정시 프로젝트 루트 검사.
            severity_filter: 선택적 필터 ('error', 'warning')

        Returns:
            진단 결과가 담긴 JSON 문자열
        """
        target = base_path / path if path else base_path
        results = []

        try:
            # Python 진단을 위해 ruff 실행 시도
            if target.is_file() and target.suffix == ".py":
                ruff_target = str(target)
            elif target.is_dir():
                ruff_target = str(target)
            else:
                return json.dumps(
                    {
                        "success": True,
                        "data": {
                            "diagnostics": [],
                            "message": "분석할 Python 파일 없음",
                        },
                    }
                )

            try:
                ruff_result = subprocess.run(
                    ["ruff", "check", "--output-format=json", ruff_target],
                    capture_output=True,
                    timeout=60,
                    cwd=str(base_path),
                )

                if ruff_result.stdout:
                    ruff_diagnostics = json.loads(ruff_result.stdout.decode("utf-8"))
                    for diag in ruff_diagnostics:
                        severity = (
                            "error"
                            if diag.get("code", "").startswith("E")
                            else "warning"
                        )
                        if severity_filter and severity != severity_filter:
                            continue

                        results.append(
                            {
                                "file": diag.get("filename", ""),
                                "line": diag.get("location", {}).get("row", 0),
                                "character": diag.get("location", {}).get("column", 0),
                                "severity": severity,
                                "code": diag.get("code", ""),
                                "message": diag.get("message", ""),
                                "source": "ruff",
                            }
                        )

            except FileNotFoundError:
                # Ruff 미설치 - 기본 피드백 제공
                return json.dumps(
                    {
                        "success": True,
                        "data": {
                            "diagnostics": [],
                            "message": "ruff가 설치되지 않음. 설치: pip install ruff",
                        },
                        "metadata": {"tool_available": False},
                    }
                )
            except subprocess.TimeoutExpired:
                return json.dumps({"success": False, "error": "진단 검사 시간 초과"})

            # 심각도순 정렬 (오류 우선)
            results.sort(
                key=lambda x: (
                    0 if x["severity"] == "error" else 1,
                    x["file"],
                    x["line"],
                )
            )

            # 개수 계산
            errors = sum(1 for r in results if r["severity"] == "error")
            warnings = sum(1 for r in results if r["severity"] == "warning")

            return json.dumps(
                {
                    "success": True,
                    "data": {
                        "diagnostics": results[:50],  # 50개로 제한
                        "summary": {
                            "errors": errors,
                            "warnings": warnings,
                            "total": len(results),
                        },
                    },
                    "metadata": {
                        "truncated": len(results) > 50,
                        "tool_available": True,
                    },
                }
            )

        except Exception as e:
            return json.dumps({"success": False, "error": f"진단 조회 오류: {e}"})

    return diagnostics


def create_references_tool(workspace_root: str) -> BaseTool:
    """
    심볼 참조 찾기용 LangChain 도구를 생성합니다.

    코드베이스 전체에서 심볼 사용을 검색하는 grep 기반 구현입니다.

    Args:
        workspace_root: 검색 작업의 루트 디렉토리

    Returns:
        참조 찾기용 LangChain BaseTool
    """
    base_path = Path(workspace_root)

    @tool
    def references(
        symbol: str,
        path: Optional[str] = None,
        file_pattern: str = "*.py",
    ) -> str:
        """
        코드베이스 전체에서 심볼의 모든 참조를 찾습니다.

        grep 기반 검색으로 심볼 사용을 찾습니다. 다음 용도로 유용합니다:
        - 이름 변경/삭제 전 함수/클래스 사용 여부 확인
        - 코드 전체에서 변수가 어떻게 사용되는지 이해
        - 리팩토링 전 모든 사용 위치 찾기

        Args:
            symbol: 찾을 심볼 이름 (함수, 클래스, 변수)
            path: 검색할 선택적 하위 디렉토리 (기본값: 전체 워크스페이스)
            file_pattern: 검색할 파일의 글롭 패턴 (기본값: '*.py')

        Returns:
            참조 위치 목록이 담긴 JSON 문자열
        """
        if not symbol:
            return json.dumps({"success": False, "error": "심볼 이름이 필요합니다"})

        search_path = base_path / path if path else base_path
        if not search_path.exists():
            return json.dumps(
                {
                    "success": False,
                    "error": f"경로를 찾을 수 없음: {path or workspace_root}",
                }
            )

        results = []
        by_file: dict[str, list[dict]] = {}

        try:
            # 정규식 특수문자 이스케이프하되 단어 경계는 허용
            escaped_symbol = re.escape(symbol)
            # 심볼을 단어로 매칭 (다른 식별자의 일부가 아닌)
            pattern = re.compile(rf"\b{escaped_symbol}\b")

            for file_path in search_path.rglob(file_pattern):
                if not file_path.is_file():
                    continue

                # 숨김 디렉토리와 일반적인 비코드 디렉토리 건너뛰기
                if any(
                    part.startswith(".")
                    or part in ("node_modules", "__pycache__", "venv", ".venv")
                    for part in file_path.parts
                ):
                    continue

                try:
                    content = file_path.read_text(encoding="utf-8", errors="ignore")
                    lines = content.splitlines()

                    for line_num, line in enumerate(lines, 1):
                        for match in pattern.finditer(line):
                            rel_path = str(file_path.relative_to(base_path))
                            ref = {
                                "file": rel_path,
                                "line": line_num,
                                "character": match.start(),
                                "preview": line.strip()[:80],
                            }
                            results.append(ref)

                            if rel_path not in by_file:
                                by_file[rel_path] = []
                            by_file[rel_path].append(ref)

                except Exception:
                    continue

            # 파일과 줄 기준 정렬
            results.sort(key=lambda x: (x["file"], x["line"]))

            return json.dumps(
                {
                    "success": True,
                    "data": {
                        "references": results[:100],  # 100개로 제한
                        "by_file": {f: len(refs) for f, refs in by_file.items()},
                        "symbol": symbol,
                    },
                    "metadata": {
                        "count": len(results),
                        "file_count": len(by_file),
                        "truncated": len(results) > 100,
                        "method": "grep",
                    },
                }
            )

        except Exception as e:
            return json.dumps({"success": False, "error": f"참조 찾기 오류: {e}"})

    return references
