"""셸 실행 도구."""

import asyncio
from typing import Any, Optional

from .base import BaseTool, ToolResult


class ShellExecuteTool(BaseTool):
    """셸 명령 실행 도구."""

    def __init__(self, working_dir: Optional[str] = None, timeout: int = 60):
        self._working_dir = working_dir
        self._timeout = timeout

    @property
    def name(self) -> str:
        return "shell_execute"

    @property
    def description(self) -> str:
        return """Execute a shell command and return the output.
Use this for running scripts, installing packages, git operations, etc.
WARNING: This tool can execute arbitrary commands. Use with caution."""

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to execute",
                },
                "working_dir": {
                    "type": "string",
                    "description": "Working directory for the command",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds (default: 60)",
                    "default": 60,
                },
            },
            "required": ["command"],
        }

    @property
    def risk_level(self) -> str:
        return "critical"

    async def execute(self, **kwargs: Any) -> ToolResult:
        """셸 명령을 실행합니다."""
        command = kwargs.get("command", "")
        working_dir = kwargs.get("working_dir", self._working_dir)
        timeout = kwargs.get("timeout", self._timeout)

        if not command:
            return ToolResult(success=False, error="명령이 필요합니다")

        try:
            # 서브프로세스 생성
            process = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=working_dir,
            )

            # 타임아웃과 함께 완료 대기
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
                return ToolResult(
                    success=False,
                    error=f"{timeout}초 후 명령 시간 초과",
                    metadata={"command": command, "timeout": True},
                )

            # 출력 디코딩
            stdout_str = stdout.decode("utf-8", errors="replace") if stdout else ""
            stderr_str = stderr.decode("utf-8", errors="replace") if stderr else ""

            success = process.returncode == 0

            return ToolResult(
                success=success,
                data={
                    "stdout": stdout_str,
                    "stderr": stderr_str,
                    "return_code": process.returncode,
                },
                error=stderr_str if not success and stderr_str else None,
                metadata={"command": command},
            )

        except Exception as e:
            return ToolResult(
                success=False,
                error=f"명령 실행 오류: {str(e)}",
                metadata={"command": command},
            )
