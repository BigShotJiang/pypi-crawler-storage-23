"""Tests for NotebookContextManager."""

import pytest

from jupyter_ext.tools.context import (
    CellInfo,
    NotebookContext,
    NotebookContextManager,
)


class TestCellInfo:
    """Tests for CellInfo dataclass."""

    def test_cell_info_creation(self):
        """Test CellInfo creation with default values."""
        cell = CellInfo(index=0, cell_type="code", source="print('hello')")
        assert cell.index == 0
        assert cell.cell_type == "code"
        assert cell.source == "print('hello')"
        assert cell.outputs == []
        assert cell.execution_count is None

    def test_cell_info_with_outputs(self):
        """Test CellInfo with outputs."""
        outputs = [{"output_type": "stream", "text": "hello\n"}]
        cell = CellInfo(
            index=1,
            cell_type="code",
            source="print('hello')",
            outputs=outputs,
            execution_count=5,
        )
        assert cell.outputs == outputs
        assert cell.execution_count == 5


class TestNotebookContext:
    """Tests for NotebookContext dataclass."""

    def test_empty_notebook(self):
        """Test empty notebook context."""
        ctx = NotebookContext(path="test.ipynb")
        assert ctx.path == "test.ipynb"
        assert ctx.cell_count == 0
        assert ctx.get_code_cells() == []
        assert ctx.get_markdown_cells() == []

    def test_notebook_with_cells(self):
        """Test notebook with mixed cells."""
        cells = [
            CellInfo(index=0, cell_type="code", source="x = 1"),
            CellInfo(index=1, cell_type="markdown", source="# Header"),
            CellInfo(index=2, cell_type="code", source="print(x)"),
        ]
        ctx = NotebookContext(path="test.ipynb", cells=cells)

        assert ctx.cell_count == 3
        assert len(ctx.get_code_cells()) == 2
        assert len(ctx.get_markdown_cells()) == 1

    def test_get_cell(self):
        """Test getting a cell by index."""
        cells = [
            CellInfo(index=0, cell_type="code", source="x = 1"),
            CellInfo(index=1, cell_type="markdown", source="# Header"),
        ]
        ctx = NotebookContext(path="test.ipynb", cells=cells)

        assert ctx.get_cell(0) is not None
        assert ctx.get_cell(0).source == "x = 1"
        assert ctx.get_cell(1).cell_type == "markdown"
        assert ctx.get_cell(2) is None
        assert ctx.get_cell(-1) is None


class TestNotebookContextManager:
    """Tests for NotebookContextManager."""

    @pytest.fixture
    def context_manager(self):
        """Create a NotebookContextManager instance."""
        return NotebookContextManager()

    @pytest.fixture
    def sample_notebook_model(self):
        """Create a sample notebook model."""
        return {
            "content": {
                "cells": [
                    {
                        "cell_type": "code",
                        "source": "import pandas as pd",
                        "outputs": [],
                        "execution_count": 1,
                        "metadata": {},
                    },
                    {
                        "cell_type": "markdown",
                        "source": "# Data Analysis",
                        "metadata": {},
                    },
                    {
                        "cell_type": "code",
                        "source": "df = pd.read_csv('data.csv')",
                        "outputs": [],
                        "execution_count": 2,
                        "metadata": {},
                    },
                ],
                "metadata": {
                    "kernelspec": {
                        "name": "python3",
                        "display_name": "Python 3",
                    }
                },
            }
        }

    def test_initial_state(self, context_manager):
        """Test initial state of context manager."""
        assert context_manager.current_notebook is None
        assert context_manager.notebook_model is None

    def test_set_notebook(self, context_manager, sample_notebook_model):
        """Test setting notebook context."""
        context_manager.set_notebook("test.ipynb", sample_notebook_model)

        assert context_manager.current_notebook is not None
        assert context_manager.current_notebook.path == "test.ipynb"
        assert context_manager.current_notebook.cell_count == 3
        assert context_manager.current_notebook.kernel_name == "python3"

    def test_get_summary(self, context_manager, sample_notebook_model):
        """Test getting notebook summary."""
        # Without notebook
        summary = context_manager.get_summary()
        assert summary == {"status": "no_notebook"}

        # With notebook
        context_manager.set_notebook("test.ipynb", sample_notebook_model)
        summary = context_manager.get_summary()

        assert summary["path"] == "test.ipynb"
        assert summary["cell_count"] == 3
        assert summary["code_cells"] == 2
        assert summary["markdown_cells"] == 1
        assert summary["kernel"] == "python3"

    def test_update_cell(self, context_manager, sample_notebook_model):
        """Test updating a cell."""
        context_manager.set_notebook("test.ipynb", sample_notebook_model)

        # Update existing cell
        assert context_manager.update_cell(0, "import numpy as np")

        # Verify in notebook model
        cells = context_manager.notebook_model["content"]["cells"]
        assert cells[0]["source"] == "import numpy as np"

        # Verify in context
        assert context_manager.current_notebook.cells[0].source == "import numpy as np"

        # Invalid index
        assert not context_manager.update_cell(10, "x = 1")
        assert not context_manager.update_cell(-1, "x = 1")

    def test_insert_cell(self, context_manager, sample_notebook_model):
        """Test inserting a new cell."""
        context_manager.set_notebook("test.ipynb", sample_notebook_model)

        # Insert after index 0
        new_index = context_manager.insert_cell(
            source="# New cell",
            cell_type="code",
            insert_after=0,
        )

        assert new_index == 1
        assert context_manager.current_notebook.cell_count == 4

        # Append to end
        new_index = context_manager.insert_cell(
            source="print('done')",
            cell_type="code",
        )

        assert new_index == 4
        assert context_manager.current_notebook.cell_count == 5

    def test_insert_markdown_cell(self, context_manager, sample_notebook_model):
        """Test inserting a markdown cell."""
        context_manager.set_notebook("test.ipynb", sample_notebook_model)

        new_index = context_manager.insert_cell(
            source="## Section",
            cell_type="markdown",
            insert_after=1,
        )

        cells = context_manager.notebook_model["content"]["cells"]
        assert cells[new_index]["cell_type"] == "markdown"
        assert cells[new_index]["source"] == "## Section"

    def test_delete_cell(self, context_manager, sample_notebook_model):
        """Test deleting a cell."""
        context_manager.set_notebook("test.ipynb", sample_notebook_model)
        initial_count = context_manager.current_notebook.cell_count

        # Delete middle cell
        assert context_manager.delete_cell(1)
        assert context_manager.current_notebook.cell_count == initial_count - 1

        # Check remaining cells have correct indices
        for i, cell in enumerate(context_manager.current_notebook.cells):
            assert cell.index == i

        # Invalid index
        assert not context_manager.delete_cell(10)

    def test_clear(self, context_manager, sample_notebook_model):
        """Test clearing notebook context."""
        context_manager.set_notebook("test.ipynb", sample_notebook_model)
        assert context_manager.current_notebook is not None

        context_manager.clear()

        assert context_manager.current_notebook is None
        assert context_manager.notebook_model is None

    def test_insert_without_notebook_raises(self, context_manager):
        """Test that insert raises when no notebook is set."""
        with pytest.raises(ValueError, match="No notebook model set"):
            context_manager.insert_cell(source="x = 1")
