"""Tests for jupyter_ext package."""
