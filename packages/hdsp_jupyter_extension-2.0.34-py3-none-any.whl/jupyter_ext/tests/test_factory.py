"""Tests for AgentFactory and related classes."""

import importlib.util
import json
from unittest.mock import MagicMock, patch

import pytest

from jupyter_ext.agent.agent_factory import (
    AgentConfig,
    AgentEvent,
    AgentFactory,
    config_from_dict,
)
from jupyter_ext.tools.context import NotebookContextManager


def _has_langchain() -> bool:
    """Check if langchain is installed."""
    return importlib.util.find_spec("langchain") is not None


class TestAgentConfig:
    """Tests for AgentConfig dataclass."""

    def test_default_values(self):
        """Test AgentConfig with default values."""
        config = AgentConfig(
            provider="openai",
            model="gpt-4o",
            api_key="test-key",
        )
        assert config.temperature == 0.0
        assert config.max_tokens == 4096
        assert config.max_iterations == 20
        assert config.mode == "default"

    def test_custom_values(self):
        """Test AgentConfig with custom values."""
        config = AgentConfig(
            provider="anthropic",
            model="claude-3-opus",
            api_key="test-key",
            temperature=0.7,
            max_tokens=8192,
            max_iterations=50,
            mode="data_science",
        )
        assert config.temperature == 0.7
        assert config.max_tokens == 8192
        assert config.max_iterations == 50
        assert config.mode == "data_science"


class TestAgentEvent:
    """Tests for AgentEvent dataclass."""

    def test_to_dict(self):
        """Test AgentEvent serialization."""
        event = AgentEvent(
            type="tool_call",
            data={"name": "jupyter_cell", "arguments": {"operation": "CREATE"}},
        )
        result = event.to_dict()

        assert result["type"] == "tool_call"
        assert result["name"] == "jupyter_cell"
        assert result["arguments"]["operation"] == "CREATE"

    def test_to_dict_empty_data(self):
        """Test AgentEvent with empty data."""
        event = AgentEvent(type="start", data={})
        result = event.to_dict()

        assert result == {"type": "start"}


class TestConfigFromDict:
    """Tests for config_from_dict function."""

    def test_anthropic_config(self):
        """Test parsing Anthropic configuration."""
        data = {
            "provider": "anthropic",
            "anthropic": {
                "apiKey": "sk-ant-test",
                "model": "claude-sonnet-4-20250514",
            },
            "mode": "code_review",
            "maxIterations": 30,
        }
        config = config_from_dict(data)

        assert config.provider == "anthropic"
        assert config.api_key == "sk-ant-test"
        assert config.model == "claude-sonnet-4-20250514"
        assert config.mode == "code_review"
        assert config.max_iterations == 30

    def test_default_values(self):
        """Test parsing with missing optional fields."""
        data = {
            "provider": "vllm",
            "vllm": {
                "endpoint": "http://localhost:8000",
                "apiKey": "test-key",
            },
        }
        config = config_from_dict(data)

        assert config.provider == "vllm"
        assert config.temperature == 0.0  # default
        assert config.max_tokens == 4096  # default


class TestAgentFactory:
    """Tests for AgentFactory class."""

    @pytest.fixture
    def notebook_context(self):
        """Create a NotebookContextManager with sample notebook."""
        ctx = NotebookContextManager()
        ctx.set_notebook(
            "test.ipynb",
            {
                "content": {
                    "cells": [
                        {"cell_type": "code", "source": "x = 1", "outputs": []},
                    ],
                    "metadata": {"kernelspec": {"name": "python3"}},
                }
            },
        )
        return ctx

    @pytest.fixture
    def factory(self, notebook_context):
        """Create an AgentFactory instance."""
        return AgentFactory(notebook_context=notebook_context)

    def test_factory_creation(self, notebook_context):
        """Test AgentFactory creation."""
        factory = AgentFactory(notebook_context=notebook_context)
        assert factory._notebook_context is notebook_context
        assert factory._on_event is None

    def test_factory_with_callbacks(self, notebook_context):
        """Test AgentFactory with event callbacks."""
        on_event = MagicMock()

        factory = AgentFactory(
            notebook_context=notebook_context,
            on_event=on_event,
        )

        assert factory._on_event is on_event

    @pytest.mark.skipif(
        not _has_langchain(),
        reason="langchain not installed",
    )
    @patch("jupyter_ext.agent.agent_factory.SummarizationMiddleware")
    @patch("jupyter_ext.agent.agent_factory.create_deep_agent")
    @patch("jupyter_ext.agent.agent_factory.init_chat_model")
    def test_create_agent(
        self, mock_init_model, mock_create_deep_agent, mock_summarization, factory
    ):
        """Test agent creation."""
        mock_model = MagicMock()
        mock_init_model.return_value = mock_model

        mock_agent_graph = MagicMock()
        # create_deep_agent().with_config() chain
        mock_create_deep_agent.return_value = mock_agent_graph
        mock_agent_graph.with_config.return_value = mock_agent_graph

        config = AgentConfig(
            provider="openai",
            model="gpt-4o",
            api_key="test-key",
        )

        runner = factory.create_agent(config)

        # Verify init_chat_model was called with correct params
        mock_init_model.assert_called_once()
        call_args = mock_init_model.call_args
        assert "openai:gpt-4o" in call_args[0]

        # Verify create_deep_agent was called
        mock_create_deep_agent.assert_called_once()
        call_kwargs = mock_create_deep_agent.call_args[1]
        assert call_kwargs["model"] is mock_model
        assert len(call_kwargs["tools"]) >= 3  # At least jupyter tools

        # Verify with_config was called with recursion_limit
        mock_agent_graph.with_config.assert_called_once_with({"recursion_limit": 1000})

        # Verify runner was created
        assert runner is not None
        assert runner._config is config


class TestLangChainTools:
    """Tests for LangChain-compatible Jupyter tools."""

    @pytest.fixture
    def context(self):
        """Create a NotebookContextManager with sample notebook."""
        ctx = NotebookContextManager()
        ctx.set_notebook(
            "test.ipynb",
            {
                "content": {
                    "cells": [
                        {
                            "cell_type": "code",
                            "source": "x = 1",
                            "outputs": [],
                            "execution_count": 1,
                        },
                        {
                            "cell_type": "markdown",
                            "source": "# Header",
                        },
                    ],
                    "metadata": {"kernelspec": {"name": "python3"}},
                }
            },
        )
        return ctx

    def test_jupyter_cell_create(self, context):
        """Test jupyter_cell CREATE operation."""
        from jupyter_ext.agent.langchain_tools import create_jupyter_cell_tool

        tool = create_jupyter_cell_tool(context)
        result = tool.invoke({"operation": "CREATE", "code": "print('hello')"})
        data = json.loads(result)

        assert data["success"] is True
        assert data["data"]["operation"] == "created"
        assert "cell_index" in data["data"]

    def test_jupyter_cell_read(self, context):
        """Test jupyter_cell READ operation."""
        from jupyter_ext.agent.langchain_tools import create_jupyter_cell_tool

        tool = create_jupyter_cell_tool(context)
        result = tool.invoke({"operation": "READ", "cell_index": 0})
        data = json.loads(result)

        assert data["success"] is True
        assert data["data"]["source"] == "x = 1"
        assert data["data"]["cell_type"] == "code"

    def test_jupyter_cell_update(self, context):
        """Test jupyter_cell UPDATE operation."""
        from jupyter_ext.agent.langchain_tools import create_jupyter_cell_tool

        tool = create_jupyter_cell_tool(context)
        result = tool.invoke({"operation": "UPDATE", "cell_index": 0, "code": "y = 2"})
        data = json.loads(result)

        assert data["success"] is True
        assert data["data"]["operation"] == "updated"

        # Verify update
        assert context.current_notebook.cells[0].source == "y = 2"

    def test_jupyter_cell_delete(self, context):
        """Test jupyter_cell DELETE operation."""
        from jupyter_ext.agent.langchain_tools import create_jupyter_cell_tool

        tool = create_jupyter_cell_tool(context)
        initial_count = context.current_notebook.cell_count

        result = tool.invoke({"operation": "DELETE", "cell_index": 0})
        data = json.loads(result)

        assert data["success"] is True
        assert context.current_notebook.cell_count == initial_count - 1

    def test_jupyter_cell_execute(self, context):
        """Test jupyter_cell EXECUTE operation."""
        from jupyter_ext.agent.langchain_tools import create_jupyter_cell_tool

        tool = create_jupyter_cell_tool(context)
        result = tool.invoke({"operation": "EXECUTE", "code": "print('test')"})
        data = json.loads(result)

        assert data["success"] is True
        assert data["data"]["operation"] == "execute_requested"
        assert data["metadata"]["requires_kernel"] is True

    def test_jupyter_markdown_create(self, context):
        """Test jupyter_markdown CREATE operation."""
        from jupyter_ext.agent.langchain_tools import create_jupyter_markdown_tool

        tool = create_jupyter_markdown_tool(context)
        result = tool.invoke({"operation": "CREATE", "content": "## Section"})
        data = json.loads(result)

        assert data["success"] is True
        assert data["data"]["operation"] == "created"

    def test_notebook_info(self, context):
        """Test notebook_info tool."""
        from jupyter_ext.agent.langchain_tools import create_notebook_info_tool

        tool = create_notebook_info_tool(context)
        result = tool.invoke({})
        data = json.loads(result)

        assert data["success"] is True
        assert data["data"]["path"] == "test.ipynb"
        assert data["data"]["cell_count"] == 2
        assert data["data"]["code_cells"] == 1
        assert data["data"]["markdown_cells"] == 1

    def test_tool_error_handling(self, context):
        """Test tool error handling."""
        from jupyter_ext.agent.langchain_tools import create_jupyter_cell_tool

        tool = create_jupyter_cell_tool(context)

        # Invalid operation
        result = tool.invoke({"operation": "INVALID"})
        data = json.loads(result)
        assert data["success"] is False
        assert "알 수 없는 연산" in data["error"]

        # Missing required params
        result = tool.invoke({"operation": "READ"})
        data = json.loads(result)
        assert data["success"] is False
        assert "cell_index가 필요합니다" in data["error"]


class TestFileTools:
    """Tests for LangChain-compatible file tools."""

    @pytest.fixture
    def temp_workspace(self, tmp_path):
        """Create a temporary workspace with test files."""
        # Create test files
        (tmp_path / "test.py").write_text("x = 1\nprint(x)")
        (tmp_path / "data.txt").write_text("hello world")
        (tmp_path / "subdir").mkdir()
        (tmp_path / "subdir" / "nested.py").write_text("def foo(): pass")
        return str(tmp_path)

    def test_file_read_success(self, temp_workspace):
        """Test file_read tool with valid file."""
        from jupyter_ext.agent.langchain_tools import create_file_read_tool

        tool = create_file_read_tool(temp_workspace)
        result = tool.invoke({"path": "test.py"})
        data = json.loads(result)

        assert data["success"] is True
        assert data["data"]["content"] == "x = 1\nprint(x)"
        assert data["data"]["path"] == "test.py"

    def test_file_read_not_found(self, temp_workspace):
        """Test file_read tool with non-existent file."""
        from jupyter_ext.agent.langchain_tools import create_file_read_tool

        tool = create_file_read_tool(temp_workspace)
        result = tool.invoke({"path": "nonexistent.py"})
        data = json.loads(result)

        assert data["success"] is False
        assert "찾을 수 없음" in data["error"]

    def test_file_write_success(self, temp_workspace):
        """Test file_write tool with new file."""
        from jupyter_ext.agent.langchain_tools import create_file_write_tool

        tool = create_file_write_tool(temp_workspace)
        result = tool.invoke({"path": "new_file.txt", "content": "new content"})
        data = json.loads(result)

        assert data["success"] is True
        assert data["data"]["operation"] == "write"

        # Verify file was created
        from pathlib import Path

        assert (Path(temp_workspace) / "new_file.txt").read_text() == "new content"

    def test_file_write_append(self, temp_workspace):
        """Test file_write tool with append mode."""
        from jupyter_ext.agent.langchain_tools import create_file_write_tool

        tool = create_file_write_tool(temp_workspace)
        result = tool.invoke(
            {"path": "data.txt", "content": "\nappended", "append": True}
        )
        data = json.loads(result)

        assert data["success"] is True
        assert data["data"]["operation"] == "append"

        # Verify content
        from pathlib import Path

        assert (
            Path(temp_workspace) / "data.txt"
        ).read_text() == "hello world\nappended"

    def test_file_list_success(self, temp_workspace):
        """Test file_list tool."""
        from jupyter_ext.agent.langchain_tools import create_file_list_tool

        tool = create_file_list_tool(temp_workspace)
        result = tool.invoke({"path": "."})
        data = json.loads(result)

        assert data["success"] is True
        names = [e["name"] for e in data["data"]["entries"]]
        assert "test.py" in names
        assert "data.txt" in names
        assert "subdir" in names

    def test_file_list_pattern(self, temp_workspace):
        """Test file_list tool with pattern filter."""
        from jupyter_ext.agent.langchain_tools import create_file_list_tool

        tool = create_file_list_tool(temp_workspace)
        result = tool.invoke({"path": ".", "pattern": "*.py"})
        data = json.loads(result)

        assert data["success"] is True
        names = [e["name"] for e in data["data"]["entries"]]
        assert "test.py" in names
        assert "data.txt" not in names

    def test_file_list_recursive(self, temp_workspace):
        """Test file_list tool with recursive option."""
        from jupyter_ext.agent.langchain_tools import create_file_list_tool

        tool = create_file_list_tool(temp_workspace)
        result = tool.invoke({"path": ".", "recursive": True, "pattern": "*.py"})
        data = json.loads(result)

        assert data["success"] is True
        paths = [e["path"] for e in data["data"]["entries"]]
        assert "test.py" in paths
        assert any("nested.py" in p for p in paths)


class TestSearchTools:
    """Tests for LangChain-compatible search tools."""

    @pytest.fixture
    def temp_workspace(self, tmp_path):
        """Create a temporary workspace with test files."""
        (tmp_path / "main.py").write_text("def hello():\n    print('hello')\n\nhello()")
        (tmp_path / "utils.py").write_text("def helper():\n    return 42\n\nhelper()")
        (tmp_path / "data.txt").write_text("some data")
        return str(tmp_path)

    def test_search_code_success(self, temp_workspace):
        """Test search_code tool with valid pattern."""
        from jupyter_ext.agent.langchain_tools import create_search_code_tool

        tool = create_search_code_tool(temp_workspace)
        result = tool.invoke({"pattern": "def", "file_pattern": "*.py"})
        data = json.loads(result)

        assert data["success"] is True
        assert len(data["data"]["matches"]) >= 2

        # Check that we found both functions
        files = [m["file"] for m in data["data"]["matches"]]
        assert "main.py" in files
        assert "utils.py" in files

    def test_search_code_case_insensitive(self, temp_workspace):
        """Test search_code tool with case-insensitive search."""
        from jupyter_ext.agent.langchain_tools import create_search_code_tool

        tool = create_search_code_tool(temp_workspace)
        result = tool.invoke({"pattern": "HELLO", "case_sensitive": False})
        data = json.loads(result)

        assert data["success"] is True
        assert len(data["data"]["matches"]) > 0

    def test_search_code_invalid_regex(self, temp_workspace):
        """Test search_code tool with invalid regex."""
        from jupyter_ext.agent.langchain_tools import create_search_code_tool

        tool = create_search_code_tool(temp_workspace)
        result = tool.invoke({"pattern": "[invalid"})
        data = json.loads(result)

        assert data["success"] is False
        assert "잘못된 정규식" in data["error"]


class TestAllToolsIntegration:
    """Tests for _create_all_tools method."""

    @pytest.fixture
    def notebook_context(self):
        """Create a NotebookContextManager with sample notebook."""
        ctx = NotebookContextManager()
        ctx.set_notebook(
            "test.ipynb",
            {
                "content": {
                    "cells": [
                        {"cell_type": "code", "source": "x = 1", "outputs": []},
                    ],
                    "metadata": {"kernelspec": {"name": "python3"}},
                }
            },
        )
        return ctx

    @pytest.fixture
    def factory(self, notebook_context, tmp_path):
        """Create an AgentFactory instance with workspace_root."""
        return AgentFactory(
            notebook_context=notebook_context,
            workspace_root=str(tmp_path),
        )

    def test_create_all_tools_count(self, factory):
        """Test that _create_all_tools returns all 8 tools."""
        tools = factory._create_all_tools()

        assert len(tools) == 8

    def test_create_all_tools_names(self, factory):
        """Test that all expected tools are created."""
        tools = factory._create_all_tools()
        tool_names = [t.name for t in tools]

        # Jupyter tools
        assert "jupyter_cell" in tool_names
        assert "jupyter_markdown" in tool_names
        assert "notebook_info" in tool_names

        # File tools (file_list은 FilesystemMiddleware의 glob_search가 대체)
        assert "file_read" in tool_names
        assert "file_write" in tool_names

        # Shell tools
        assert "shell_execute" in tool_names

        # LSP tools (grep-based; search_code는 grep_search가 대체)
        assert "diagnostics" in tool_names
        assert "references" in tool_names
