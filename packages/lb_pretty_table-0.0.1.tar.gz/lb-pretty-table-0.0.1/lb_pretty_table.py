import math
import sys

class PrettyTable:
    def __init__(self, headers=None):
        # Заголовки остаются в исходном регистре
        self.headers = [str(h) for h in headers] if headers else []
        self.rows = []
        # Квадратные углы - самые стабильные для отображения
        self.chars = {
            "t": "┌", "m": "┬", "tr": "┐", 
            "l": "├", "c": "┼", "r": "┤", 
            "b": "└", "bm": "┴", "br": "┘", 
            "v": "│", "h": "─"
        }

    def add_row(self, row):
        """Добавить строку данных."""
        self.rows.append([str(item) for item in row])

    @staticmethod
    def show(data):
        """
        Универсальный метод. Автоматически подгоняет разные списки друг под друга.
        """
        if not data:
            print("No data to display")
            return

        # Если передали словарь {Заголовок: [Список элементов]}
        if isinstance(data, dict):
            headers = list(data.keys())
            lists = list(data.values())
            # Находим длину самого длинного списка
            max_len = max(len(lst) for lst in lists)
            
            table = PrettyTable(headers)
            for i in range(max_len):
                row = []
                for lst in lists:
                    # Если данных меньше, чем в других колонках - ставим прочерк
                    row.append(lst[i] if i < len(lst) else "-")
                table.add_row(row)
            print(table.render())
            return

        # Для обычных списков списков
        if isinstance(data[0], list):
            table = PrettyTable(data[0])
            for row in data[1:]:
                table.add_row(row)
            print(table.render())

    def _get_col_widths(self):
        """Считает ширину колонок по самому длинному контенту."""
        widths = [len(str(h)) for h in self.headers]
        for row in self.rows:
            for i, cell in enumerate(row):
                if i < len(widths):
                    widths[i] = max(widths[i], len(str(cell)))
                else:
                    widths.append(len(str(cell)))
        # +2 для небольших отступов по бокам
        return [w + 2 for w in widths]

    def _format_cell(self, text, width):
        """Выравнивание: теперь всё всегда по левому краю."""
        clean_text = text.strip()
        inner_w = width - 2
        # Всегда используем ljust для выравнивания влево
        return f" {clean_text.ljust(inner_w)} "

    def _build_line(self, widths, left, mid, right):
        """Рисует горизонтальную линию (верх, низ или разделитель)."""
        line = left
        for i, w in enumerate(widths):
            line += self.chars["h"] * w
            if i < len(widths) - 1:
                line += mid
        return line + right

    def render(self):
        """Собирает таблицу в одну строку."""
        if not self.headers and not self.rows:
            return "Empty Table"

        widths = self._get_col_widths()
        output = []
        
        # Шапка таблицы
        output.append(self._build_line(widths, self.chars["t"], self.chars["m"], self.chars["tr"]))
        
        # Заголовки
        header_line = self.chars["v"]
        for i, h in enumerate(self.headers):
            header_line += f" {h} ".ljust(widths[i]) + self.chars["v"]
        output.append(header_line)
        
        # Разделитель
        output.append(self._build_line(widths, self.chars["l"], self.chars["c"], self.chars["r"]))
        
        # Данные
        for row in self.rows:
            row_line = self.chars["v"]
            for i, cell in enumerate(row):
                if i < len(widths):
                    row_line += self._format_cell(cell, widths[i]) + self.chars["v"]
            output.append(row_line)
            
        # Подвал
        output.append(self._build_line(widths, self.chars["b"], self.chars["bm"], self.chars["br"]))
        
        return "\n".join(output)

# --- ПРИМЕР С ТВОИМИ ДАННЫМИ ---
if __name__ == "__main__":
    # Твои списки разной длины
    table = PrettyTable(["Ник", "Ранг"]) # Создаем с заголовками
    table.add_row(["abobus", "Junior"])   # Добавляем по одной строке
    table.add_row(["logic-break", "God"])

    print(table.render()) # Выводим результат
