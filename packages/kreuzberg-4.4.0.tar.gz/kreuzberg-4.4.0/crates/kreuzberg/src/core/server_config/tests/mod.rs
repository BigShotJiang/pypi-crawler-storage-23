//! Tests for server configuration module.

mod basic_tests;
mod env_tests;
mod file_loading_tests;
