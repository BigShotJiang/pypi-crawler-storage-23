To use this module, you need to:

1. Go to Point of Sale and open a POS session.
2. Close the POS session. A "Closing Register" form will apear, fill its "Closing note" field.
3. Once the POS session is closed, go to Point of Sale / Orders / Sessions, and access to the form view of your closed session. There you will see the new "Closing Notes" field with the notes you wrote. If the cash count at closing did not match the expected amount, the difference will also be shown in the notes.
