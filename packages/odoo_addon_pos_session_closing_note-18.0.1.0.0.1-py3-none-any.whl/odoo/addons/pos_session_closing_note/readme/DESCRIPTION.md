This module adds the closing POS session notes to the POS session form view of the backend.

If there is a closing cash difference, it will also be shown in the closing notes
