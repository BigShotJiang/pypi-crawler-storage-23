# Configurator

## About

```{eval-rst}
.. automodule:: bc_configs.configurator
   :members:
   :undoc-members:
   :show-inheritance:
```

## BaseConfig

```{eval-rst}
.. automodule:: bc_configs.configurator.BaseConfig
   :members:
   :undoc-members:
   :show-inheritance:
   :no-index:
```
