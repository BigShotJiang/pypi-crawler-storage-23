"""Allow running export module as python -m openadapt_ml.export."""

from openadapt_ml.export.cli import main

if __name__ == "__main__":
    main()
