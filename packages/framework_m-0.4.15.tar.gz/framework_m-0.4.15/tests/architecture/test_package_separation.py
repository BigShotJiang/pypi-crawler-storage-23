"""Architecture tests to ensure clean package separation.

These tests enforce that the `core` package does not import from `adapters`,
which is required for the future package split (Phase 11: MX Pattern).
"""

import ast
import importlib.util
from pathlib import Path

import pytest


def get_package_path(package_name: str) -> Path:
    """Get the filesystem path for a package."""
    spec = importlib.util.find_spec(package_name)
    if spec is None or spec.origin is None:
        pytest.skip(f"Package {package_name} not found")
    return Path(spec.origin).parent


def get_all_python_files(directory: Path) -> list[Path]:
    """Get all Python files in a directory recursively."""
    return list(directory.rglob("*.py"))


def get_imports_from_file(filepath: Path) -> list[str]:
    """Extract all import statements from a Python file."""
    try:
        source = filepath.read_text()
        tree = ast.parse(source)
    except (SyntaxError, UnicodeDecodeError):
        return []

    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append(alias.name)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.append(node.module)
    return imports


class TestCoreDoesNotImportAdapters:
    """Ensure core package has no dependency on adapters.

    This is critical for the future package split where:
    - framework-m-core: Pure protocols, no concrete implementations
    - framework-m-standard: SQLAlchemy and other adapters

    If core imports adapters, the split becomes impossible without refactoring.
    """

    def test_core_interfaces_do_not_import_adapters(self):
        """Core interfaces should be pure protocols with no adapter deps."""
        # Check both framework_m.core and framework_m_core
        packages = ["framework_m.core", "framework_m_core"]

        violations = []
        for pkg in packages:
            try:
                core_path = get_package_path(pkg)
                interfaces_path = core_path / "interfaces"
                if not interfaces_path.exists():
                    continue

                for py_file in get_all_python_files(interfaces_path):
                    imports = get_imports_from_file(py_file)
                    for imp in imports:
                        if (
                            "framework_m.adapters" in imp
                            or "framework_m_standard.adapters" in imp
                        ):
                            violations.append(f"{pkg}/{py_file.name}: imports {imp}")
            except (pytest.skip.Exception, ImportError):
                continue

        assert not violations, (
            "Core interfaces must not import from adapters!\n"
            "Violations:\n" + "\n".join(violations)
        )

    def test_core_domain_does_not_import_adapters(self):
        """Core domain models should be pure with no adapter deps."""
        packages = ["framework_m.core", "framework_m_core"]

        violations = []
        for pkg in packages:
            try:
                core_path = get_package_path(pkg)
                domain_path = core_path / "domain"
                if not domain_path.exists():
                    continue

                for py_file in get_all_python_files(domain_path):
                    imports = get_imports_from_file(py_file)
                    for imp in imports:
                        if (
                            "framework_m.adapters" in imp
                            or "framework_m_standard.adapters" in imp
                        ):
                            violations.append(f"{pkg}/{py_file.name}: imports {imp}")
            except (pytest.skip.Exception, ImportError):
                continue

        assert not violations, (
            "Core domain must not import from adapters!\n"
            "Violations:\n" + "\n".join(violations)
        )

    def test_core_does_not_import_sqlalchemy(self):
        """Core should not have direct SQLAlchemy dependency.

        SQLAlchemy types should only appear in adapters.
        Core uses abstract types (e.g., `Any` for session).
        """
        packages = ["framework_m.core", "framework_m_core"]

        violations = []
        for pkg in packages:
            try:
                core_path = get_package_path(pkg)
                for py_file in get_all_python_files(core_path):
                    imports = get_imports_from_file(py_file)
                    for imp in imports:
                        if imp.startswith("sqlalchemy"):
                            violations.append(f"{pkg}/{py_file.name}: imports {imp}")
            except (pytest.skip.Exception, ImportError):
                continue

        assert not violations, (
            "Core should not import SQLAlchemy directly!\n"
            "Use abstract types in protocols.\n"
            "Violations:\n" + "\n".join(violations)
        )


class TestAdaptersImplementProtocols:
    """Ensure adapters properly implement core protocols.

    This validates the Ports & Adapters architecture.
    """

    def test_adapters_import_from_core(self):
        """Adapters should import protocols from core.

        Checks both framework_m (aliases) and framework_m_standard (implementations).
        """
        imports_core = False

        # Check both adapter packages
        adapter_pkgs = ["framework_m_standard.adapters", "framework_m.adapters"]
        core_names = ["framework_m.core", "framework_m_core"]

        for adapter_pkg in adapter_pkgs:
            try:
                adapters_path = get_package_path(adapter_pkg)
                for py_file in get_all_python_files(adapters_path):
                    imports = get_imports_from_file(py_file)
                    if any(
                        any(core_name in imp for core_name in core_names)
                        for imp in imports
                    ):
                        imports_core = True
                        break
            except (pytest.skip.Exception, ImportError):
                continue
            if imports_core:
                break

        assert imports_core, (
            "Adapters should import protocols from core.interfaces. "
            "This validates the Ports & Adapters pattern."
        )
