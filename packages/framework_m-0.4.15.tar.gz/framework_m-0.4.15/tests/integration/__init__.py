"""Integration tests for Framework M.

This package contains integration tests that verify the interaction
between multiple components of the framework.
"""
