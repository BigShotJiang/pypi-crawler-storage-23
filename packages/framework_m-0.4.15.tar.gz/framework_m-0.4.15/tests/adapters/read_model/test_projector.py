"""Tests for Projector - Event handlers that update Read Models.

Following TDD approach - tests written before implementation.
"""

from typing import Any
from unittest.mock import AsyncMock

import pytest

from framework_m.core.interfaces.event_bus import Event


class TestProjectorProtocolStructure:
    """Test that Projector has the required structure."""

    def test_projector_protocol_exists(self) -> None:
        """Projector should be importable from adapters."""
        from framework_m.adapters.read_model.projector import Projector

        assert Projector is not None

    def test_projector_has_handle_method(self) -> None:
        """Projector should define handle() method for events."""
        from framework_m.adapters.read_model.projector import Projector

        assert hasattr(Projector, "handle")

    def test_projector_has_subscribe_method(self) -> None:
        """Projector should define subscribe() for event bus registration."""
        from framework_m.adapters.read_model.projector import Projector

        assert hasattr(Projector, "subscribe")

    def test_projector_has_event_patterns_property(self) -> None:
        """Projector should define event_patterns for topics to subscribe to."""
        from unittest.mock import AsyncMock

        from framework_m.adapters.read_model.projector import Projector

        mock_read_model = AsyncMock()
        projector = Projector(read_model=mock_read_model)
        assert hasattr(projector, "event_patterns")


class TestProjectorEventHandling:
    """Test projector event handling behavior."""

    @pytest.fixture
    def mock_read_model(self) -> Any:
        """Create a mock read model."""
        mock = AsyncMock()
        mock.project = AsyncMock(return_value=None)
        return mock

    @pytest.fixture
    def mock_event_bus(self) -> Any:
        """Create a mock event bus."""
        mock = AsyncMock()
        mock.subscribe_pattern = AsyncMock(return_value="sub-123")
        mock.unsubscribe = AsyncMock()
        return mock

    @pytest.mark.asyncio
    async def test_handle_delegates_to_read_model_project(
        self, mock_read_model: Any
    ) -> None:
        """handle() should delegate to read_model.project()."""
        from framework_m.adapters.read_model.projector import Projector

        projector = Projector(read_model=mock_read_model)
        event = Event(type="doc.created", data={"doctype": "Invoice", "id": "123"})

        await projector.handle(event)

        mock_read_model.project.assert_called_once_with(event)

    @pytest.mark.asyncio
    async def test_subscribe_registers_patterns_with_event_bus(
        self, mock_read_model: Any, mock_event_bus: Any
    ) -> None:
        """subscribe() should register event patterns with event bus."""
        from framework_m.adapters.read_model.projector import Projector

        projector = Projector(
            read_model=mock_read_model,
            event_patterns=["doc.created", "doc.updated"],
        )

        await projector.subscribe(mock_event_bus)

        # Should subscribe to both patterns
        assert mock_event_bus.subscribe_pattern.call_count == 2

    @pytest.mark.asyncio
    async def test_subscribe_stores_subscription_ids(
        self, mock_read_model: Any, mock_event_bus: Any
    ) -> None:
        """subscribe() should store subscription IDs for later unsubscribe."""
        from framework_m.adapters.read_model.projector import Projector

        projector = Projector(
            read_model=mock_read_model,
            event_patterns=["doc.*"],
        )

        await projector.subscribe(mock_event_bus)

        assert len(projector.subscription_ids) == 1
        assert "sub-123" in projector.subscription_ids

    @pytest.mark.asyncio
    async def test_unsubscribe_removes_all_subscriptions(
        self, mock_read_model: Any, mock_event_bus: Any
    ) -> None:
        """unsubscribe() should remove all event bus subscriptions."""
        from framework_m.adapters.read_model.projector import Projector

        projector = Projector(
            read_model=mock_read_model,
            event_patterns=["doc.created"],
        )
        await projector.subscribe(mock_event_bus)

        await projector.unsubscribe(mock_event_bus)

        mock_event_bus.unsubscribe.assert_called_once_with("sub-123")
        assert len(projector.subscription_ids) == 0


class TestProjectorFiltering:
    """Test projector event filtering behavior."""

    @pytest.fixture
    def mock_read_model(self) -> Any:
        """Create a mock read model."""
        mock = AsyncMock()
        mock.project = AsyncMock(return_value=None)
        return mock

    @pytest.mark.asyncio
    async def test_handle_filters_by_doctype(self, mock_read_model: Any) -> None:
        """handle() should filter events by doctype if configured."""
        from framework_m.adapters.read_model.projector import Projector

        projector = Projector(
            read_model=mock_read_model,
            doctype_filter=["Invoice", "Payment"],
        )

        # Should process Invoice event
        invoice_event = Event(
            type="doc.created", data={"doctype": "Invoice", "id": "1"}
        )
        await projector.handle(invoice_event)
        assert mock_read_model.project.call_count == 1

        # Should skip Todo event
        todo_event = Event(type="doc.created", data={"doctype": "Todo", "id": "2"})
        await projector.handle(todo_event)
        assert mock_read_model.project.call_count == 1  # Still 1, not called again

    @pytest.mark.asyncio
    async def test_handle_processes_all_if_no_filter(
        self, mock_read_model: Any
    ) -> None:
        """handle() should process all events if no doctype_filter."""
        from framework_m.adapters.read_model.projector import Projector

        projector = Projector(read_model=mock_read_model)

        event1 = Event(type="doc.created", data={"doctype": "Invoice", "id": "1"})
        event2 = Event(type="doc.created", data={"doctype": "Todo", "id": "2"})

        await projector.handle(event1)
        await projector.handle(event2)

        assert mock_read_model.project.call_count == 2


class TestProjectorExports:
    """Test that Projector is properly exported."""

    def test_exported_from_adapters_read_model(self) -> None:
        """Projector should be importable from adapters.read_model."""
        from framework_m.adapters.read_model import Projector

        assert Projector is not None
