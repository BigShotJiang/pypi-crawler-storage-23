"""Tests for ReadModelProtocol interface.

Following TDD approach - tests written before implementation.
"""

from typing import Any
from unittest.mock import AsyncMock

import pytest

from framework_m.core.interfaces.event_bus import Event


class TestReadModelProtocolStructure:
    """Test that ReadModelProtocol has the required structure."""

    def test_read_model_protocol_exists(self) -> None:
        """ReadModelProtocol should be importable from interfaces."""
        from framework_m_core.interfaces.read_model import ReadModelProtocol

        assert ReadModelProtocol is not None

    def test_read_model_protocol_has_project_method(self) -> None:
        """ReadModelProtocol should define project() method."""
        from framework_m_core.interfaces.read_model import ReadModelProtocol

        # Protocol should have project method
        assert hasattr(ReadModelProtocol, "project")

    def test_read_model_protocol_has_query_method(self) -> None:
        """ReadModelProtocol should define query() method."""
        from framework_m_core.interfaces.read_model import ReadModelProtocol

        assert hasattr(ReadModelProtocol, "query")

    def test_read_model_protocol_has_rebuild_method(self) -> None:
        """ReadModelProtocol should define rebuild() method."""
        from framework_m_core.interfaces.read_model import ReadModelProtocol

        assert hasattr(ReadModelProtocol, "rebuild")


class TestReadModelProtocolCompliance:
    """Test that implementations can comply with ReadModelProtocol."""

    @pytest.fixture
    def mock_read_model(self) -> Any:
        """Create a mock that matches ReadModelProtocol."""
        mock = AsyncMock()
        mock.project = AsyncMock(return_value=None)
        mock.query = AsyncMock(return_value=[{"id": "1", "name": "Test"}])
        mock.rebuild = AsyncMock(return_value=None)
        return mock

    @pytest.mark.asyncio
    async def test_project_accepts_event(self, mock_read_model: Any) -> None:
        """project() should accept an Event and return None."""
        event = Event(type="doc.created", data={"doctype": "Todo", "id": "123"})

        result = await mock_read_model.project(event)

        mock_read_model.project.assert_called_once_with(event)
        assert result is None

    @pytest.mark.asyncio
    async def test_query_returns_list_of_dicts(self, mock_read_model: Any) -> None:
        """query() should return a list of dictionaries."""
        result = await mock_read_model.query()

        assert isinstance(result, list)
        assert all(isinstance(item, dict) for item in result)

    @pytest.mark.asyncio
    async def test_query_accepts_filters(self, mock_read_model: Any) -> None:
        """query() should accept optional filters parameter."""
        filters = {"status": "active", "doctype": "Invoice"}

        await mock_read_model.query(filters=filters)

        mock_read_model.query.assert_called_once_with(filters=filters)

    @pytest.mark.asyncio
    async def test_query_accepts_pagination(self, mock_read_model: Any) -> None:
        """query() should accept limit and offset for pagination."""
        await mock_read_model.query(limit=10, offset=20)

        mock_read_model.query.assert_called_once_with(limit=10, offset=20)

    @pytest.mark.asyncio
    async def test_query_accepts_order_by(self, mock_read_model: Any) -> None:
        """query() should accept order_by for sorting."""
        await mock_read_model.query(order_by=["created_at", "-total"])

        mock_read_model.query.assert_called_once_with(order_by=["created_at", "-total"])

    @pytest.mark.asyncio
    async def test_rebuild_is_callable(self, mock_read_model: Any) -> None:
        """rebuild() should be callable with no arguments."""
        result = await mock_read_model.rebuild()

        mock_read_model.rebuild.assert_called_once()
        assert result is None


class TestReadModelExports:
    """Test that ReadModelProtocol is properly exported."""

    def test_exported_from_interfaces_init(self) -> None:
        """ReadModelProtocol should be exported from core.interfaces."""
        from framework_m.core.interfaces import ReadModelProtocol

        assert ReadModelProtocol is not None

    def test_query_result_model_exported(self) -> None:
        """ReadQueryResult should be exported for type hints."""
        from framework_m_core.interfaces.read_model import ReadQueryResult

        assert ReadQueryResult is not None
