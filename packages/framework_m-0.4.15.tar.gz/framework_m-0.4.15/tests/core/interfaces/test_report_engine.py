"""Tests for Report Engine Protocol."""

from typing import Any

# =============================================================================
# Test: ReportEngineProtocol Import
# =============================================================================


class TestReportEngineProtocolImport:
    """Tests for ReportEngineProtocol import."""

    def test_import_protocol(self) -> None:
        """ReportEngineProtocol should be importable."""
        from framework_m_core.interfaces.report_engine import ReportEngineProtocol

        assert ReportEngineProtocol is not None

    def test_import_result_model(self) -> None:
        """ReportResult should be importable."""
        from framework_m_core.interfaces.report_engine import ReportResult

        assert ReportResult is not None


# =============================================================================
# Test: ReportResult Model
# =============================================================================


class TestReportResult:
    """Tests for ReportResult model."""

    def test_create_report_result(self) -> None:
        """ReportResult should be creatable with rows."""
        from framework_m_core.interfaces.report_engine import ReportResult

        result = ReportResult(
            rows=[
                {"name": "Product A", "total": 1000},
                {"name": "Product B", "total": 2000},
            ],
        )

        assert len(result.rows) == 2
        assert result.rows[0]["name"] == "Product A"

    def test_report_result_with_columns(self) -> None:
        """ReportResult should include column metadata."""
        from framework_m_core.interfaces.report_engine import ReportResult

        result = ReportResult(
            rows=[{"name": "Product A", "total": 1000}],
            columns=["name", "total"],
        )

        assert result.columns == ["name", "total"]

    def test_report_result_with_metadata(self) -> None:
        """ReportResult should include optional metadata."""
        from framework_m_core.interfaces.report_engine import ReportResult

        result = ReportResult(
            rows=[],
            metadata={"execution_time_ms": 150, "data_source": "SQL"},
        )

        assert result.metadata["execution_time_ms"] == 150
        assert result.metadata["data_source"] == "SQL"


# =============================================================================
# Test: ReportEngineProtocol Contract
# =============================================================================


class TestReportEngineProtocol:
    """Tests for ReportEngineProtocol contract."""

    def test_protocol_has_execute_method(self) -> None:
        """Protocol should define execute method."""
        from framework_m_core.interfaces.report_engine import ReportEngineProtocol

        assert hasattr(ReportEngineProtocol, "execute")

    def test_protocol_has_validate_method(self) -> None:
        """Protocol should define validate method."""
        from framework_m_core.interfaces.report_engine import ReportEngineProtocol

        assert hasattr(ReportEngineProtocol, "validate")


# =============================================================================
# Test: Mock Implementation
# =============================================================================


class TestMockReportEngine:
    """Tests for a mock implementation of ReportEngineProtocol."""

    async def test_mock_sql_engine(self) -> None:
        """Mock SQL engine should satisfy protocol."""
        from framework_m_core.interfaces.report_engine import (
            ReportEngineProtocol,
            ReportResult,
        )

        class MockSQLEngine:
            """Mock SQL report engine."""

            async def execute(
                self,
                query: str,
                parameters: dict[str, Any] | None = None,
            ) -> ReportResult:
                """Execute SQL query."""
                return ReportResult(
                    rows=[{"count": 42}],
                    columns=["count"],
                )

            async def validate(self, query: str) -> bool:
                """Validate SQL syntax."""
                return "SELECT" in query.upper()

        engine: ReportEngineProtocol = MockSQLEngine()
        result = await engine.execute("SELECT COUNT(*) FROM users")

        assert len(result.rows) == 1
        assert result.rows[0]["count"] == 42

    async def test_mock_elastic_engine(self) -> None:
        """Mock Elastic engine should satisfy protocol."""
        from framework_m_core.interfaces.report_engine import (
            ReportEngineProtocol,
            ReportResult,
        )

        class MockElasticEngine:
            """Mock Elasticsearch report engine."""

            async def execute(
                self,
                query: str,
                parameters: dict[str, Any] | None = None,
            ) -> ReportResult:
                """Execute Elastic DSL query."""
                return ReportResult(
                    rows=[{"_source": {"name": "log1"}}],
                    columns=["_source"],
                )

            async def validate(self, query: str) -> bool:
                """Validate Elastic DSL."""
                try:
                    import json

                    json.loads(query)
                    return True
                except Exception:
                    return False

        engine: ReportEngineProtocol = MockElasticEngine()
        result = await engine.execute('{"query": {"match_all": {}}}')

        assert len(result.rows) == 1
        assert "_source" in result.rows[0]

    async def test_mock_clickhouse_engine(self) -> None:
        """Mock ClickHouse engine should satisfy protocol."""
        from framework_m_core.interfaces.report_engine import (
            ReportEngineProtocol,
            ReportResult,
        )

        class MockClickHouseEngine:
            """Mock ClickHouse report engine."""

            async def execute(
                self,
                query: str,
                parameters: dict[str, Any] | None = None,
            ) -> ReportResult:
                """Execute ClickHouse query."""
                return ReportResult(
                    rows=[
                        {"date": "2026-01-01", "events": 1000},
                        {"date": "2026-01-02", "events": 1500},
                    ],
                    columns=["date", "events"],
                )

            async def validate(self, query: str) -> bool:
                """Validate ClickHouse SQL."""
                return "SELECT" in query.upper()

        engine: ReportEngineProtocol = MockClickHouseEngine()
        result = await engine.execute(
            "SELECT date, count() as events FROM events GROUP BY date"
        )

        assert len(result.rows) == 2
        assert result.rows[0]["date"] == "2026-01-01"
        assert result.rows[1]["events"] == 1500
