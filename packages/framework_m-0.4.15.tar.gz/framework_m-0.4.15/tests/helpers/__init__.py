"""Test helper modules for Framework M tests."""
