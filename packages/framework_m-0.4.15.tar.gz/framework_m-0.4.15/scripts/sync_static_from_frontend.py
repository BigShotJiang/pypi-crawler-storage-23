from __future__ import annotations

import shutil
import sys
from pathlib import Path


def main() -> int:
    package_root = Path(__file__).resolve().parents[1]
    frontend_dist = package_root.parent.parent / "frontend" / "dist"
    static_dir = package_root / "src" / "framework_m" / "static"

    index_file = frontend_dist / "index.html"
    assets_dir = frontend_dist / "assets"

    if not index_file.exists() or not assets_dir.exists():
        print(
            "Frontend dist is missing. Run `pnpm build` in `frontend/` before releasing framework-m.",
            file=sys.stderr,
        )
        print(f"Expected: {index_file}", file=sys.stderr)
        print(f"Expected: {assets_dir}", file=sys.stderr)
        return 1

    static_dir.mkdir(parents=True, exist_ok=True)

    target_assets = static_dir / "assets"
    if target_assets.exists():
        shutil.rmtree(target_assets)

    shutil.copytree(assets_dir, target_assets)
    shutil.copy2(index_file, static_dir / "index.html")

    favicon = frontend_dist / "favicon.ico"
    if favicon.exists():
        shutil.copy2(favicon, static_dir / "favicon.ico")

    print(f"Synced Desk static assets from {frontend_dist} to {static_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
