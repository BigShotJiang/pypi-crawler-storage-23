# Changelog

## framework-m v0.4.15

### Bug Fixes

- build and package desk (6b39f7b)


## framework-m v0.4.14

### Bug Fixes

- type-fix in AutoForm.tsx (32ea574)
- autoform fixes (e94ce14)


## framework-m v0.4.13

### Bug Fixes

- refine readme reading (46f8e5a)
- refine readme reading (58aa2fb)


## framework-m v0.4.12

### Bug Fixes

- formatting readme.md (99e3250)


## framework-m v0.4.11

### Bug Fixes

- broken link errors (b7822bc)
- broken link errors (c78c1c5)


## framework-m v0.4.10

### Bug Fixes

- update registry url in documentation (7e35e7e)
- set correct npm registry project id (8fd30d2)


## framework-m v0.4.9

### Bug Fixes

- update metapackage readme to www.frameworkm.dev (a8cfd3b)


## framework-m v0.4.8

### Bug Fixes

- use last tag version as base for release bump (bfefd3f)
- support version bumping for package.json in release script (2b6a7c3)
- fix build crash and ensure static assets are packaged (bdc18b7)
- force include gitignored static assets in packages (4fd49a5)


## framework-m v0.4.7

### Bug Fixes

- trigger doc builds on studio changes (d1a2a7b)
- synchronize pages rules with build-docs (3b2d9b7)
- aggressive filtering and dependency decoupling (6b8dbf0)
- global dummy assets and artifact integrity (f6d39f2)
- dual-track artifacts and tag optimization (6b9cdfb)
- optimize tag pipeline and kill duplication (d9154ae)
- use hatch artifacts to resolve duplicate filenames (e499457)


## framework-m v0.4.6

### Bug Fixes

- robustly detect existing tags in auto_tag_release (8aeef39)


## framework-m v0.4.5

### Bug Fixes

- bulletproof tagging and gitlab pypi upload idempotency (530466b)
- make auto_tag_release script idempotent (c211ab5)


## framework-m v0.4.4

### Bug Fixes

- remove unsupported --skip-existing from gitlab twine upload (a1b6a96)


## framework-m v0.4.3

### Bug Fixes

- make test-workspace needs optional (96450fc)
- restore gitlint general section header (7131edc)
- adjust gitlint limits and script for long release titles (1a1371e)
- resolve build failures and enable desk tagging (d616b89)
- resolve duplicate filenames in wheel and improve CI robustness (e24c0ef)


## framework-m v0.4.2

### Bug Fixes

- broken documentation link (557d712)


## framework-m v0.4.1

### Bug Fixes

- refine metapackage description wording (f3c0c42)


## framework-m v0.4.0

### Features

- add metapackage notice and related packages section (b0f8721)


## framework-m v0.3.0

### Features

- complete phase 11 & 12 documentation and package split (7ee5039)


## framework-m v0.2.5

### Bug Fixes

- add pypi and pipeline badges to readme (62590fc)


## framework-m v0.2.4

### Bug Fixes

- robust package detection and safe MR title truncation (36385b6)
- improve changelog extraction for GitLab release pages (bb636b0)


## framework-m v0.2.3

### Bug Fixes

- use show-ref for robust tag check and clear local ghost tags (79563c5)


## framework-m v0.2.2

### Bug Fixes

- finalize air-tight release automation with GitLab releases, professional logging, and zero-spam logic (0dc7b19)
- simplify release rules and regex to stop recursive loops (790b318)
- fix auto-tagging trigger and regex for merge commits (5e69fb9)


## framework-m v0.2.1

### Bug Fixes

- improve commit filtering and fix linting (6e4082d)
- prevent duplicate changelog entries by ensuring tags are fetched and handled correctly (a498f85)
- make release tag parsing more robust for large monorepos (8e1b5d8)
- update project URLs to GitLab and refactor versioning source of truth (84e0bd3)
- prevent recursive release loops and cleanup dead code (6ff3776)


## framework-m 0.2.0

### Features

- add unique constraint support and refine docs (5f9af98)
- add PyPI publishing for framework-m-studio and update docs (d6ed80a)
- comprehensive documentation covering fundamentals, migration guides, i18n, multi-tenancy usage, and API references (6a2c1df)
- implement Frontend Build & Serving (9f9aa79)
- implement desk ui (13ebcc8)
- implement workflows and advanced features (22a7745)
- implement system doctypes and features (05e7f3d)
- implement built-in doctypes and system adapters (23195d1)
- cli tools implementation (18a1d83)
- implement events, webhooks, monitoring and websockets (9381d3f)
- phase-03 complete (00123da)
- prepare for package split after completion (e8abae2)
- permission system implemented (632afb7)
- litestar application setup and authentication middleware (7854664)
- Complete DocType Engine & Database Layer (523f211)
- refactor phase-01 and implemented doctype-engine with CRUD, migrations and cli (3c36234)
- complete Phase 01 - Core Kernel & Interfaces (1dcbfab)
- automated pipeline for gitlab registry (c1a9e2b)

### Bug Fixes

- remove create-studio-release-mr and detached HEAD (d814206)
- lint issues (0c1dc94)
- studio issues and ci pipeline (e17e9c2)
- ruff issue (24fb2ef)
- ruff issue (2b3dfb0)
- mypy issues (23c539b)
- Fix ruff linting errors (ad8997c)
- lint format (8fc33e8)
- format with ruff (c9d5f39)
- mypy issues (5ab1715)
- format all files with ruff (90e3808)
- remove skip ci from release commit message (2db2b6f)
- correct directory navigation in release-package job (5b67a98)
- lint error in base_doctype (47e8c37)
- lint error in test_base_doctype (354f66f)
- use twine for GitLab registry publishing (6472dc7)
- specify dist path for uv publish (86df5c7)
- exclude cache directories from source (695d2fb)
- lint errors in tests (8b4120d)
- rename workspace to avoid package name conflict (20e46bb)


## framework-m 0.1.0

### Features

- Initial release of Framework M
