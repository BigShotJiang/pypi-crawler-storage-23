/**
 * Framework M Desk - Main Application
 *
 * Starter template with automatic DocType discovery and generic
 * list/create/edit pages, so new apps are usable immediately.
 */

import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Refine, useCreate, useList, useOne, useUpdate } from "@refinedev/core";
import routerProvider from "@refinedev/react-router";
import {
  BrowserRouter,
  Navigate,
  Route,
  Routes,
  useLocation,
  useNavigate,
  useParams,
} from "react-router-dom";

import {
  authProvider,
  frameworkMDataProvider,
  liveProvider,
} from "@framework-m/desk";
import { AppNavbar } from "./components/AppNavbar";
import { AppSidebar } from "./components/AppSidebar";

type DocTypeMeta = {
  name: string;
  label?: string;
  api_resource?: boolean;
  show_in_desk?: boolean;
};

type FieldMeta = {
  name: string;
  label?: string;
  type?: string;
  required?: boolean;
};

type SchemaPropertyMeta = {
  title?: string;
  type?: string | string[];
  anyOf?: Array<{ type?: string }>;
};

type SchemaMeta = {
  properties?: Record<string, SchemaPropertyMeta>;
  required?: string[];
};

type MetaResponse = {
  fields?: FieldMeta[];
  schema?: SchemaMeta;
};

function resolveSchemaFieldType(property: SchemaPropertyMeta): string {
  if (typeof property.type === "string") {
    return property.type;
  }

  if (Array.isArray(property.type)) {
    const nonNullType = property.type.find(t => t !== "null");
    if (nonNullType) {
      return nonNullType;
    }
  }

  if (Array.isArray(property.anyOf)) {
    const nonNullType = property.anyOf
      .map(item => item.type)
      .find(t => typeof t === "string" && t !== "null");
    if (typeof nonNullType === "string") {
      return nonNullType;
    }
  }

  return "string";
}

function buildFieldsFromMeta(meta: MetaResponse): FieldMeta[] {
  if (meta.fields && meta.fields.length > 0) {
    return meta.fields;
  }

  const properties = meta.schema?.properties ?? {};
  const requiredSet = new Set(meta.schema?.required ?? []);

  return Object.entries(properties).map(([name, property]) => ({
    name,
    label: property.title || name,
    type: resolveSchemaFieldType(property),
    required: requiredSet.has(name),
  }));
}

function useDocTypes() {
  const [doctypes, setDoctypes] = useState<DocTypeMeta[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    const run = async () => {
      try {
        const response = await fetch("/api/meta/doctypes", {
          credentials: "include",
        });
        const data = await response.json();
        if (!mounted) return;

        const items = (data.doctypes ?? []) as DocTypeMeta[];
        setDoctypes(
          items.filter(
            dt => dt.api_resource !== false && dt.show_in_desk !== false,
          ),
        );
      } finally {
        if (mounted) setIsLoading(false);
      }
    };

    void run();
    return () => {
      mounted = false;
    };
  }, []);

  return { doctypes, isLoading };
}

/* ------------------------------------------------------------------ */
/*  Shell                                                              */
/* ------------------------------------------------------------------ */

function Shell({
  doctypes,
  children,
}: Readonly<{ doctypes: DocTypeMeta[]; children: ReactNode }>) {
  const location = useLocation();
  const currentDocType =
    location.pathname.match(/^\/app\/([^/]+)\//)?.[1] ?? null;

  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      <AppSidebar doctypes={doctypes} currentDocType={currentDocType} />
      <div
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          minWidth: 0,
        }}
      >
        <AppNavbar currentDocType={currentDocType} />
        <main style={{ flex: 1, padding: "var(--space-xl)" }}>{children}</main>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  List Page                                                          */
/* ------------------------------------------------------------------ */

function ListPage() {
  const { doctype = "" } = useParams();
  const navigate = useNavigate();

  const { result, query } = useList({
    resource: doctype,
    pagination: { mode: "off" },
    queryOptions: { enabled: Boolean(doctype) },
  });

  const rows = (result.data ?? []) as Array<Record<string, unknown>>;
  const isLoading = query.isLoading || query.isFetching;
  const error = query.error;
  const columns = useMemo(() => {
    if (!rows.length) return [] as string[];
    return Object.keys(rows[0])
      .filter(key => !key.startsWith("_"))
      .slice(0, 6);
  }, [rows]);

  return (
    <div>
      {/* Page header */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          marginBottom: "var(--space-xl)",
        }}
      >
        <div>
          <h1>{doctype}</h1>
          <p
            className="text-muted text-sm"
            style={{ marginTop: "var(--space-xs)" }}
          >
            {isLoading
              ? "Loading records..."
              : `${rows.length} record${rows.length !== 1 ? "s" : ""}`}
          </p>
        </div>
        <button
          className="btn-primary"
          onClick={() => navigate(`/app/${doctype}/new`)}
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
          >
            <line x1="12" y1="5" x2="12" y2="19" />
            <line x1="5" y1="12" x2="19" y2="12" />
          </svg>
          New {doctype}
        </button>
      </div>

      {error && (
        <div
          className="card"
          style={{
            padding: "var(--space-lg)",
            borderColor: "var(--color-danger)",
            color: "var(--color-danger)",
          }}
        >
          Failed to load records.
        </div>
      )}

      {/* Empty state */}
      {!isLoading && !error && !rows.length && (
        <div
          className="card"
          style={{
            padding: "var(--space-2xl) var(--space-xl)",
            textAlign: "center",
          }}
        >
          <div
            style={{
              width: 56,
              height: 56,
              borderRadius: "var(--radius-lg)",
              background: "var(--color-primary-light)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto var(--space-lg)",
            }}
          >
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="var(--color-primary)"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <rect x="3" y="3" width="18" height="18" rx="2" />
              <line x1="12" y1="8" x2="12" y2="16" />
              <line x1="8" y1="12" x2="16" y2="12" />
            </svg>
          </div>
          <h3 style={{ marginBottom: "var(--space-sm)" }}>No records yet</h3>
          <p className="text-muted text-sm">
            Get started by creating your first <strong>{doctype}</strong>.
          </p>
          <button
            className="btn-primary"
            onClick={() => navigate(`/app/${doctype}/new`)}
            style={{ marginTop: "var(--space-lg)" }}
          >
            Create {doctype}
          </button>
        </div>
      )}

      {/* Data table */}
      {!!rows.length && (
        <div className="card" style={{ overflow: "hidden" }}>
          <table>
            <thead>
              <tr>
                {columns.map(col => (
                  <th key={col}>{col}</th>
                ))}
                <th style={{ width: 100 }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, index) => {
                const rowId = displayValue(row.id ?? row.name ?? index);
                return (
                  <tr
                    key={rowId}
                    style={{ cursor: "pointer" }}
                    onClick={() => navigate(`/app/${doctype}/edit/${rowId}`)}
                  >
                    {columns.map(col => (
                      <td key={col}>{displayValue(row[col])}</td>
                    ))}
                    <td>
                      <button
                        className="btn-sm"
                        onClick={e => {
                          e.stopPropagation();
                          navigate(`/app/${doctype}/edit/${rowId}`);
                        }}
                      >
                        Edit
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function parseValue(value: string, type: string): unknown {
  const normalized = type.toLowerCase();
  if (
    normalized.includes("int") ||
    normalized.includes("float") ||
    normalized.includes("number")
  ) {
    return value === "" ? null : Number(value);
  }
  return value;
}

function displayValue(value: unknown): string {
  if (value == null) return "";
  if (typeof value === "string") return value;
  if (typeof value === "number" || typeof value === "bigint") return `${value}`;
  if (typeof value === "boolean") return value ? "true" : "false";
  if (typeof value === "object") return JSON.stringify(value);
  return "";
}

function resolveInputType(fieldType: string): string {
  if (
    fieldType.includes("int") ||
    fieldType.includes("float") ||
    fieldType.includes("number")
  ) {
    return "number";
  }
  if (fieldType.includes("date") && fieldType.includes("time")) {
    return "datetime-local";
  }
  if (fieldType.includes("date")) {
    return "date";
  }
  return "text";
}

/* ------------------------------------------------------------------ */
/*  Form Page                                                          */
/* ------------------------------------------------------------------ */

function FormPage() {
  const { doctype = "", id } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(id);

  const [fields, setFields] = useState<FieldMeta[]>([]);
  const [formData, setFormData] = useState<Record<string, unknown>>({});

  const { mutateAsync: createRecord } = useCreate();
  const { mutateAsync: updateRecord } = useUpdate();

  const { result: recordData, query: recordQuery } = useOne({
    resource: doctype,
    id: id ?? "",
    queryOptions: { enabled: isEdit && Boolean(doctype) },
  });

  const recordLoading = recordQuery.isLoading || recordQuery.isFetching;

  useEffect(() => {
    let mounted = true;
    const run = async () => {
      const response = await fetch(`/api/meta/${doctype}`, {
        credentials: "include",
      });
      const meta = (await response.json()) as MetaResponse;
      if (!mounted) return;

      const visibleFields = buildFieldsFromMeta(meta).filter(
        field => !field.name.startsWith("_") && field.name !== "id",
      );
      setFields(visibleFields);
    };

    if (doctype) {
      void run();
    }

    return () => {
      mounted = false;
    };
  }, [doctype]);

  useEffect(() => {
    if (recordData) {
      setFormData(recordData as Record<string, unknown>);
    }
  }, [recordData]);

  return (
    <div style={{ maxWidth: 680 }}>
      {/* Page header */}
      <div style={{ marginBottom: "var(--space-xl)" }}>
        <h1>{isEdit ? `Edit ${doctype}` : `New ${doctype}`}</h1>
        <p
          className="text-muted text-sm"
          style={{ marginTop: "var(--space-xs)" }}
        >
          {isEdit ? `Editing record ${id}` : "Fill in the details below"}
        </p>
      </div>

      {recordLoading && isEdit && (
        <div className="card card-body text-muted">Loading record...</div>
      )}

      <div className="card">
        <div className="card-body">
          <form
            onSubmit={async event => {
              event.preventDefault();

              if (isEdit && id) {
                await updateRecord({ resource: doctype, id, values: formData });
              } else {
                await createRecord({ resource: doctype, values: formData });
              }

              navigate(`/app/${doctype}/list`);
            }}
            style={{ display: "grid", gap: "var(--space-lg)" }}
          >
            {fields.map(field => {
              const fieldType = (field.type ?? "string").toLowerCase();
              const value = formData[field.name];

              if (fieldType.includes("bool")) {
                return (
                  <label
                    key={field.name}
                    style={{
                      display: "flex",
                      gap: "0.5rem",
                      alignItems: "center",
                      cursor: "pointer",
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={Boolean(value)}
                      onChange={event => {
                        setFormData(prev => ({
                          ...prev,
                          [field.name]: event.target.checked,
                        }));
                      }}
                      style={{ width: "auto" }}
                    />
                    <span style={{ fontSize: "0.8125rem" }}>
                      {field.label || field.name}
                    </span>
                  </label>
                );
              }

              const inputType = resolveInputType(fieldType);

              return (
                <label
                  key={field.name}
                  style={{ display: "grid", gap: "var(--space-xs)" }}
                >
                  <span
                    style={{
                      fontSize: "0.8125rem",
                      fontWeight: 500,
                      color: "var(--color-text)",
                    }}
                  >
                    {field.label || field.name}
                    {field.required && (
                      <span
                        style={{ color: "var(--color-danger)", marginLeft: 2 }}
                      >
                        *
                      </span>
                    )}
                  </span>
                  <input
                    type={inputType}
                    required={Boolean(field.required)}
                    value={value == null ? "" : String(value)}
                    onChange={event => {
                      setFormData(prev => ({
                        ...prev,
                        [field.name]: parseValue(event.target.value, fieldType),
                      }));
                    }}
                  />
                </label>
              );
            })}

            {/* Actions */}
            <div
              style={{
                display: "flex",
                gap: "var(--space-sm)",
                paddingTop: "var(--space-sm)",
                borderTop: "1px solid var(--color-border-light)",
              }}
            >
              <button type="submit" className="btn-primary">
                {isEdit ? "Update" : "Create"}
              </button>
              <button
                type="button"
                onClick={() => navigate(`/app/${doctype}/list`)}
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Login                                                              */
/* ------------------------------------------------------------------ */

function Login() {
  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "var(--color-bg)",
      }}
    >
      <div
        className="card"
        style={{ width: "100%", maxWidth: 400, padding: "var(--space-2xl)" }}
      >
        {/* Brand */}
        <div style={{ textAlign: "center", marginBottom: "var(--space-2xl)" }}>
          <div
            style={{
              width: 48,
              height: 48,
              borderRadius: "var(--radius-lg)",
              background: "var(--color-primary)",
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#fff",
              fontWeight: 700,
              fontSize: "1.125rem",
              marginBottom: "var(--space-md)",
            }}
          >
            M
          </div>
          <h2 style={{ marginBottom: "var(--space-xs)" }}>Welcome back</h2>
          <p className="text-muted text-sm">Sign in to your account</p>
        </div>

        <form
          onSubmit={async e => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            const result = await authProvider.login?.({
              email: formData.get("email") as string,
              password: formData.get("password") as string,
            });
            if (result?.success) {
              globalThis.location.href = "/";
            } else {
              alert(result?.error?.message || "Login failed");
            }
          }}
          style={{ display: "grid", gap: "var(--space-lg)" }}
        >
          <label style={{ display: "grid", gap: "var(--space-xs)" }}>
            <span style={{ fontSize: "0.8125rem", fontWeight: 500 }}>
              Email
            </span>
            <input
              name="email"
              type="email"
              placeholder="you@example.com"
              required
            />
          </label>
          <label style={{ display: "grid", gap: "var(--space-xs)" }}>
            <span style={{ fontSize: "0.8125rem", fontWeight: 500 }}>
              Password
            </span>
            <input
              name="password"
              type="password"
              placeholder="••••••••"
              required
            />
          </label>
          <button
            type="submit"
            className="btn-primary"
            style={{ width: "100%", padding: "0.625rem" }}
          >
            Sign In
          </button>
        </form>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  App Content                                                        */
/* ------------------------------------------------------------------ */

function AppContent() {
  const { doctypes, isLoading } = useDocTypes();

  const resources = doctypes.map(dt => ({
    name: dt.name,
    list: `/app/${dt.name}/list`,
    create: `/app/${dt.name}/new`,
    edit: `/app/${dt.name}/edit/:id`,
    meta: { label: dt.label || dt.name },
  }));

  return (
    <Refine
      dataProvider={frameworkMDataProvider}
      authProvider={authProvider}
      liveProvider={liveProvider}
      routerProvider={routerProvider}
      options={{
        liveMode: "auto",
        syncWithLocation: true,
      }}
      resources={resources}
    >
      <Shell doctypes={doctypes}>
        {isLoading ? (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              padding: "var(--space-2xl)",
            }}
          >
            <p className="text-muted">Loading modules...</p>
          </div>
        ) : (
          <Routes>
            <Route
              path="/"
              element={
                doctypes.length > 0 ? (
                  <Navigate to={`/app/${doctypes[0].name}/list`} replace />
                ) : (
                  <div
                    className="card"
                    style={{
                      padding: "var(--space-2xl)",
                      maxWidth: 640,
                    }}
                  >
                    <div
                      style={{
                        width: 56,
                        height: 56,
                        borderRadius: "var(--radius-lg)",
                        background: "var(--color-primary-light)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        marginBottom: "var(--space-lg)",
                      }}
                    >
                      <svg
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="var(--color-primary)"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
                      </svg>
                    </div>
                    <h2 style={{ marginBottom: "var(--space-sm)" }}>
                      No modules discovered
                    </h2>
                    <p
                      className="text-muted text-sm"
                      style={{ marginBottom: "var(--space-lg)" }}
                    >
                      Create your first DocType to get started:
                    </p>
                    <pre
                      className="mono"
                      style={{
                        margin: 0,
                        padding: "var(--space-md) var(--space-lg)",
                        background: "var(--color-bg)",
                        borderRadius: "var(--radius-md)",
                        fontSize: "0.8125rem",
                        color: "var(--color-primary)",
                        border: "1px solid var(--color-border)",
                      }}
                    >
                      m new:doctype Contact
                    </pre>
                  </div>
                )
              }
            />
            <Route path="/login" element={<Login />} />
            <Route path="/app/:doctype/list" element={<ListPage />} />
            <Route path="/app/:doctype/new" element={<FormPage />} />
            <Route path="/app/:doctype/edit/:id" element={<FormPage />} />
          </Routes>
        )}
      </Shell>
    </Refine>
  );
}

/**
 * Main App Component
 *
 * In production backend serving mode, UI is under /desk.
 * In Vite dev mode, UI is served from root.
 */
export function App() {
  const basename = globalThis.location.pathname.startsWith("/desk")
    ? "/desk"
    : "/";

  return (
    <BrowserRouter basename={basename}>
      <AppContent />
    </BrowserRouter>
  );
}
