type AppNavbarProps = {
  currentDocType: string | null;
};

export function AppNavbar({ currentDocType }: Readonly<AppNavbarProps>) {
  return (
    <header
      style={{
        height: "var(--navbar-height)",
        background: "var(--color-surface)",
        borderBottom: "1px solid var(--color-border)",
        boxShadow: "var(--shadow-xs)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "0 1.5rem",
        position: "sticky",
        top: 0,
        zIndex: 10,
      }}
    >
      {/* Left: Breadcrumb */}
      <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
        {currentDocType ? (
          <>
            <span
              style={{
                fontSize: "0.8125rem",
                color: "var(--color-text-secondary)",
              }}
            >
              Modules
            </span>
            <span
              style={{
                fontSize: "0.75rem",
                color: "var(--color-text-muted)",
              }}
            >
              /
            </span>
            <span
              style={{
                fontSize: "0.8125rem",
                fontWeight: 600,
                color: "var(--color-text)",
              }}
            >
              {currentDocType}
            </span>
          </>
        ) : (
          <span
            style={{
              fontSize: "0.875rem",
              fontWeight: 600,
              color: "var(--color-text)",
            }}
          >
            Workspace
          </span>
        )}
      </div>

      {/* Center: Search */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          background: "var(--color-bg)",
          border: "1px solid var(--color-border)",
          borderRadius: "var(--radius-md)",
          padding: "0.375rem 0.75rem",
          gap: "0.5rem",
          width: "320px",
          maxWidth: "40%",
        }}
      >
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          style={{ color: "var(--color-text-muted)", flexShrink: 0 }}
        >
          <circle cx="11" cy="11" r="8" />
          <path d="m21 21-4.3-4.3" />
        </svg>
        <span
          style={{
            fontSize: "0.8125rem",
            color: "var(--color-text-muted)",
          }}
        >
          Search...
        </span>
        <span
          style={{
            marginLeft: "auto",
            fontSize: "0.6875rem",
            color: "var(--color-text-muted)",
            background: "var(--color-surface)",
            border: "1px solid var(--color-border)",
            borderRadius: "var(--radius-sm)",
            padding: "1px 6px",
          }}
        >
          ⌘K
        </span>
      </div>

      {/* Right: Avatar */}
      <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
        <div
          style={{
            width: 32,
            height: 32,
            borderRadius: "var(--radius-full)",
            background: "var(--color-surface)",
            border: "1px solid var(--color-border)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "var(--color-text-secondary)",
            cursor: "pointer",
          }}
          aria-label="User profile"
          title="User profile"
        >
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M20 21a8 8 0 1 0-16 0" />
            <circle cx="12" cy="8" r="4" />
          </svg>
        </div>
      </div>
    </header>
  );
}
