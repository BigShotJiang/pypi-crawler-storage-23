import { Link } from "react-router-dom";

type DocTypeMeta = {
  name: string;
  label?: string;
};

type AppSidebarProps = {
  doctypes: DocTypeMeta[];
  currentDocType: string | null;
};

export function AppSidebar({
  doctypes,
  currentDocType,
}: Readonly<AppSidebarProps>) {
  return (
    <aside
      style={{
        width: "var(--sidebar-width)",
        minHeight: "100vh",
        background: "var(--color-sidebar)",
        display: "flex",
        flexDirection: "column",
        flexShrink: 0,
      }}
    >
      {/* Brand */}
      <div
        style={{
          padding: "1.25rem 1.25rem 1rem",
          borderBottom: "1px solid rgba(255,255,255,0.08)",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "0.625rem",
          }}
        >
          <div
            style={{
              width: 32,
              height: 32,
              borderRadius: "var(--radius-md)",
              background: "var(--color-primary)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#fff",
              fontWeight: 700,
              fontSize: "0.875rem",
              letterSpacing: "-0.02em",
            }}
          >
            M
          </div>
          <div>
            <div
              style={{
                fontSize: "0.875rem",
                fontWeight: 600,
                color: "#f8fafc",
                letterSpacing: "-0.01em",
              }}
            >
              Framework M
            </div>
            <div
              style={{
                fontSize: "0.6875rem",
                color: "var(--color-text-on-dark-muted)",
              }}
            >
              Desk
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav style={{ flex: 1, padding: "0.75rem" }}>
        <div
          style={{
            fontSize: "0.6875rem",
            fontWeight: 600,
            textTransform: "uppercase",
            letterSpacing: "0.06em",
            color: "var(--color-text-on-dark-muted)",
            padding: "0.5rem 0.625rem 0.375rem",
          }}
        >
          Modules
        </div>

        <ul
          style={{
            listStyle: "none",
            padding: 0,
            margin: 0,
            display: "flex",
            flexDirection: "column",
            gap: "2px",
          }}
        >
          {doctypes.map((dt) => {
            const isActive = currentDocType === dt.name;
            return (
              <li key={dt.name}>
                <Link
                  to={`/app/${dt.name}/list`}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "0.5rem",
                    textDecoration: "none",
                    padding: "0.5rem 0.625rem",
                    borderRadius: "var(--radius-sm)",
                    color: isActive ? "#ffffff" : "var(--color-text-on-dark)",
                    background: isActive
                      ? "var(--color-sidebar-active)"
                      : "transparent",
                    fontWeight: isActive ? 600 : 400,
                    fontSize: "0.8125rem",
                    transition: "all var(--transition-fast)",
                  }}
                  onMouseEnter={(e) => {
                    if (!isActive) {
                      e.currentTarget.style.background =
                        "var(--color-sidebar-hover)";
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isActive) {
                      e.currentTarget.style.background = "transparent";
                    }
                  }}
                >
                  {/* Icon placeholder: colored dot */}
                  <span
                    style={{
                      width: 6,
                      height: 6,
                      borderRadius: "50%",
                      background: isActive
                        ? "var(--color-primary)"
                        : "var(--color-text-on-dark-muted)",
                      flexShrink: 0,
                    }}
                  />
                  {dt.label || dt.name}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Footer */}
      <div
        style={{
          padding: "0.75rem 1.25rem",
          borderTop: "1px solid rgba(255,255,255,0.08)",
          fontSize: "0.6875rem",
          color: "var(--color-text-on-dark-muted)",
        }}
      >
        Framework M v0.2
      </div>
    </aside>
  );
}
