import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

// Backend URL from environment or default to localhost:8888
// This is set by `m prod --with-frontend` via VITE_BACKEND_URL env var
const BACKEND_URL = process.env.VITE_BACKEND_URL || "http://localhost:8888";
const BACKEND_WS_URL = BACKEND_URL.replace("http://", "ws://").replace(
  "https://",
  "wss://",
);

export default defineConfig(({ command }) => ({
  plugins: [react()],
  // Dev server uses root; build outputs under /desk/
  base: command === "serve" ? "/" : "/desk/",
  server: {
    port: 5173,
    proxy: {
      // Proxy API requests to Framework M backend
      "/api": {
        target: BACKEND_URL,
        changeOrigin: true,
        secure: false,
      },
      // Proxy WebSocket connections
      "/api/v1/stream": {
        target: BACKEND_WS_URL,
        ws: true,
        changeOrigin: true,
      },
    },
  },
}));
