# Framework M Frontend Template

This is a customizable frontend template for Framework M applications.

By default, this starter auto-discovers DocTypes from `/api/meta/doctypes` and provides generic list/create/edit pages out of the box.

## Getting Started

```bash
# Install dependencies
pnpm install

# Start development server
pnpm dev
```

The development server will proxy API requests to `http://localhost:8000`.

## npm Registry Configuration

This template uses the `@framework-m/desk` package from GitLab's npm registry.

**For local development**, you'll need to authenticate:

1. Create a [GitLab Personal Access Token](https://gitlab.com/-/user_settings/personal_access_tokens) with `read_package_registry` scope
2. Configure npm:
   ```bash
   npm config set -- '//gitlab.com/api/v4/projects/YOUR_PROJECT_ID/packages/npm/:_authToken' "YOUR_TOKEN"
   ```

**In GitLab CI**, authentication is automatic via `CI_JOB_TOKEN`.

## Production Deployment

**Important Routing Information:**

When deployed with Framework M backend, the UI is served at the `/desk/` path:

- **UI Routes**: `/desk/` (redirects to first discovered DocType), `/desk/app/:doctype/list`, `/desk/app/:doctype/new`, `/desk/app/:doctype/edit/:id`
- **API Routes**: `/api/v1/` (auth, CRUD, websockets)
- **Static Assets**: `/desk/assets/` (JS, CSS, images)

This separation prevents route conflicts between frontend SPA routing and backend API routes.

**Build Process:**

```bash
pnpm build
```

Built files go to `dist/`. The Framework M CI pipeline copies these to the `framework-m` PyPI package.

## Customization

- **Providers**: Provided by `@framework-m/desk` package - import and use them
- **App**: Edit `src/App.tsx` - customize auto-generated resources, routes, and generic form/list behavior
- **Components**: Create custom components in `src/components/`
- **Hooks**: Add custom business logic in `src/hooks/`

## Available Exports from @framework-m/desk

```typescript
import {
  // Data provider for Refine
  frameworkMDataProvider,

  // Auth provider (cookie-based)
  authProvider,

  // Live provider (WebSocket real-time updates)
  liveProvider,
  closeAllConnections,

  // Configuration
  API_URL,
  META_URL,
  WS_URL,

  // TypeScript types
  type ListResponse,
  type BaseDocument,
  type UserIdentity,
  type ApiError,
} from "@framework-m/desk";
```
