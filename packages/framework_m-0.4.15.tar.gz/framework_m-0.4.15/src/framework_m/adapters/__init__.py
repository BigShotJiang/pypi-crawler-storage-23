"""Module alias to framework-m-standard."""

import sys

import framework_m_standard.adapters as _m

# Replace this module in sys.modules with the standard implementation
# This ensures that any patches to this module affect the actual implementation
sys.modules[__name__] = _m
