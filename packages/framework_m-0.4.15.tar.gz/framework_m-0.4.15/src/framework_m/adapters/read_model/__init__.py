"""Read Model adapters for CQRS pattern.

This package provides adapters for projecting events into read-optimized stores.
"""

from framework_m.adapters.read_model.projector import Projector

__all__ = [
    "Projector",
]
