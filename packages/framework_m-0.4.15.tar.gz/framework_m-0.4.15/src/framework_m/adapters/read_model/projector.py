"""Projector - Event handler that updates Read Models.

Projectors subscribe to domain events and transform them into
read-optimized projections. They bridge the write model (events)
with the read model (denormalized views).

Example:
    class InvoiceAnalyticsProjector:
        def __init__(self, analytics_store: ClickHouseStore):
            self.projector = Projector(
                read_model=InvoiceAnalyticsReadModel(analytics_store),
                event_patterns=["doc.created", "doc.updated"],
                doctype_filter=["Invoice", "Payment"],
            )

        async def start(self, event_bus: EventBusProtocol):
            await self.projector.subscribe(event_bus)
"""

import logging
from collections.abc import Sequence

from framework_m_core.interfaces.read_model import ReadModelProtocol

from framework_m.core.interfaces.event_bus import Event, EventBusProtocol

logger = logging.getLogger(__name__)


class Projector:
    """Event handler that projects domain events into read models.

    The Projector subscribes to specified event patterns and delegates
    each event to a ReadModel for projection into read-optimized storage.

    Features:
    - Subscribe to multiple event patterns (e.g., "doc.created", "doc.*")
    - Filter events by doctype (optional)
    - Automatic subscription management
    - Graceful unsubscribe

    Attributes:
        read_model: The ReadModelProtocol implementation to project into
        event_patterns: List of event patterns to subscribe to
        doctype_filter: Optional list of doctypes to process (None = all)
        subscription_ids: Active subscription IDs for cleanup

    Example:
        projector = Projector(
            read_model=my_analytics_model,
            event_patterns=["doc.created", "doc.updated"],
            doctype_filter=["Invoice", "SalesOrder"],
        )
        await projector.subscribe(event_bus)
    """

    def __init__(
        self,
        read_model: ReadModelProtocol,
        event_patterns: Sequence[str] | None = None,
        doctype_filter: Sequence[str] | None = None,
    ) -> None:
        """Initialize the projector.

        Args:
            read_model: ReadModel implementation to project events into
            event_patterns: Event patterns to subscribe to (default: ["doc.*"])
            doctype_filter: Optional list of doctypes to filter (None = all)
        """
        self.read_model = read_model
        self.event_patterns: Sequence[str] = event_patterns or ["doc.*"]
        self.doctype_filter: Sequence[str] | None = doctype_filter
        self.subscription_ids: list[str] = []

    async def handle(self, event: Event) -> None:
        """Handle an incoming event by projecting to the read model.

        This method is called by the event bus for each matching event.
        It filters by doctype (if configured) and delegates to the read model.

        Args:
            event: The domain event to process
        """
        # Extract doctype from event data
        doctype = event.data.get("doctype") if event.data else None

        # Apply doctype filter if configured
        if self.doctype_filter is not None and doctype not in self.doctype_filter:
            logger.debug(
                "Skipping event for doctype %s (not in filter: %s)",
                doctype,
                self.doctype_filter,
            )
            return

        # Delegate to read model
        logger.debug("Projecting event %s for doctype %s", event.type, doctype)
        await self.read_model.project(event)

    async def subscribe(self, event_bus: EventBusProtocol) -> None:
        """Subscribe to configured event patterns on the event bus.

        Registers this projector's handle method as the callback for
        all configured event patterns.

        Args:
            event_bus: The event bus to subscribe to
        """
        for pattern in self.event_patterns:
            subscription_id = await event_bus.subscribe_pattern(pattern, self.handle)
            self.subscription_ids.append(subscription_id)
            logger.info(
                "Subscribed to pattern '%s' with ID %s", pattern, subscription_id
            )

    async def unsubscribe(self, event_bus: EventBusProtocol) -> None:
        """Unsubscribe from all event patterns.

        Removes all subscriptions from the event bus and clears
        the subscription ID list.

        Args:
            event_bus: The event bus to unsubscribe from
        """
        for subscription_id in self.subscription_ids:
            await event_bus.unsubscribe(subscription_id)
            logger.info("Unsubscribed from subscription %s", subscription_id)

        self.subscription_ids.clear()


__all__ = ["Projector"]
