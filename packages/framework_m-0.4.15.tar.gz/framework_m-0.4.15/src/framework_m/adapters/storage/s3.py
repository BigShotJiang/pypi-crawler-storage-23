# ruff: noqa
from framework_m_standard.adapters.storage.s3 import *
import sys

sys.modules[__name__] = sys.modules["framework_m_standard.adapters.storage.s3"]
