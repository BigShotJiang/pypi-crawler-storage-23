# ruff: noqa
from framework_m_standard.adapters.db.outbox_repository import *
import sys

sys.modules[__name__] = sys.modules[
    "framework_m_standard.adapters.db.outbox_repository"
]
