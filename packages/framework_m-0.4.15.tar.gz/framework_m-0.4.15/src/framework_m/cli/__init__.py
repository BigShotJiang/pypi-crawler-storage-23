"""CLI commands for Framework M."""

from framework_m_core.cli import utility

__all__ = ["utility"]
