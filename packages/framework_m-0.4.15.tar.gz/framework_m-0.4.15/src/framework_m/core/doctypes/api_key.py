# ruff: noqa
from framework_m_core.doctypes.api_key import *
import sys

sys.modules[__name__] = sys.modules["framework_m_core.doctypes.api_key"]
