from framework_m_core.domain.base_controller import BaseController

__all__ = ["BaseController"]
