from framework_m_core.domain.naming_counter import NamingCounter

__all__ = ["NamingCounter"]
