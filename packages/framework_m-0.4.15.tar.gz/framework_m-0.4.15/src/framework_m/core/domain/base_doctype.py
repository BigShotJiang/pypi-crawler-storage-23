from framework_m_core.domain.base_doctype import BaseDocType, Field

__all__ = ["BaseDocType", "Field"]
