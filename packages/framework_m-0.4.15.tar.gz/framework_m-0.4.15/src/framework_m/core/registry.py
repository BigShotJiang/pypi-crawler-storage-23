from framework_m_core.registry import MetaRegistry

__all__ = ["MetaRegistry"]
