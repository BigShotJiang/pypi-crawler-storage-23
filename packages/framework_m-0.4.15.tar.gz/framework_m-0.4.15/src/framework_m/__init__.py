"""Framework M - Meta-package for Core and Standard components."""

import importlib.metadata

from framework_m_core.container import Container
from framework_m_core.domain.base_controller import BaseController as Controller
from framework_m_core.domain.base_doctype import BaseDocType as DocType
from framework_m_core.domain.base_doctype import Field
from framework_m_core.registry import MetaRegistry

try:
    __version__ = importlib.metadata.version("framework-m")
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = ["Container", "Controller", "DocType", "Field", "MetaRegistry", "__version__"]
