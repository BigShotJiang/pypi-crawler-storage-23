from .nfw import NFWHalo
from .einasto import EinastoHalo

__all__ = [
    "NFWHalo",
    "EinastoHalo",
]
