# TypeScript → Python 文件映射

本文档记录 pi-coding Python 实现与 TypeScript 原始文件的对应关系。

## 文件实现状态总览

### Tools (工具) - ✅ 已完成

| TypeScript | Python | 状态 |
|-----------|--------|------|
| `core/tools/bash.ts` | `tools/bash.py` | ✅ |
| `core/tools/edit.ts` | `tools/edit.py` | ✅ |
| `core/tools/edit-diff.ts` | `utils/edit_diff.py` | ✅ |
| `core/tools/find.ts` | `tools/find.py` | ✅ |
| `core/tools/grep.ts` | `tools/grep.py` | ✅ |
| `core/tools/ls.ts` | `tools/ls.py` | ✅ |
| `core/tools/path-utils.ts` | `utils/path_utils.py` | ✅ |
| `core/tools/read.ts` | `tools/read.py` | ✅ |
| `core/tools/truncate.ts` | `utils/truncate.py` | ✅ |
| `core/tools/write.ts` | `tools/write.py` | ✅ |
| `core/tools/index.ts` | `tools/__init__.py` | ✅ |

### Core (核心) - ✅ 已完成

| TypeScript | Python | 状态 | 说明 |
|-----------|--------|------|------|
| `config.ts` | `config.py` | ✅ 完成 | 核心配置路径（get_agent_dir等） |
| `core/agent-session.ts` | - | ⏳ 参考 | Agent会话管理（依赖pi_agent） |
| `core/bash-executor.ts` | - | ⏳ 参考 | Bash执行器 |
| `core/defaults.ts` | `core/defaults.py` | ✅ 完成 | DEFAULT_THINKING_LEVEL |
| `core/sdk.ts` | - | ✅ 对应 | SDK入口（已用`__init__.py`实现） |
| `core/index.ts` | `core/__init__.py` | ✅ 完成 | 核心导出 |
| `index.ts` | `__init__.py` | ✅ | 主入口 |

### Utils (工具函数) - ✅ 已完成

| TypeScript | Python | 状态 | 说明 |
|-----------|--------|------|------|
| `utils/git.ts` | `utils/git.py` | ✅ 完成 | Git工具（parse_git_url, get_current_branch, get_repo_status） |
| `utils/shell.ts` | `utils/shell.py` | ✅ 完成 | Shell配置（get_shell_config, get_shell_env, sanitize_binary_output, kill_process_tree） |

### CLI/TUI/Extensions - ❌ 不在pi_coding范围内

这些文件属于 `pi_tui` 或其他模块：
- `cli.ts`, `cli/*.ts` - CLI相关
- `main.ts` - 主入口（TUI）
- `modes/*` - 交互模式（TUI）
- `core/compaction/*` - 上下文压缩
- `core/extensions/*` - 扩展系统
- `core/export-html/*` - HTML导出

## 目录结构对比

```
TypeScript (coding-agent/src/)              Python (packages/pi_coding/src/pi_coding/)
========================================     ============================================
├── index.ts                              →   __init__.py ✅
├── config.ts                             →   config.py ✅
├── core/
│   ├── index.ts                          →   core/__init__.py ✅
│   ├── sdk.ts                            →   __init__.py (部分对应) ✅
│   ├── agent-session.ts                  →   (参考文件)
│   ├── defaults.ts                       →   core/defaults.py ✅
│   ├── bash-executor.ts                  →   (参考文件)
│   └── tools/
│       ├── index.ts                      →   tools/__init__.py ✅
│       ├── bash.ts                       →   tools/bash.py ✅
│       ├── read.ts                       →   tools/read.py ✅
│       ├── write.ts                      →   tools/write.py ✅
│       ├── edit.ts                       →   tools/edit.py ✅
│       ├── ls.ts                         →   tools/ls.py ✅
│       ├── grep.ts                       →   tools/grep.py ✅
│       ├── find.ts                       →   tools/find.py ✅
│       ├── truncate.ts                   →   utils/truncate.py ✅
│       ├── path-utils.ts                 →   utils/path_utils.py ✅
│       └── edit-diff.ts                  →   utils/edit_diff.py ✅
└── utils/
    ├── git.ts                            →   utils/git.py ✅
    └── shell.ts                          →   utils/shell.py ✅
```

## Python 实现导出对照

### TypeScript SDK 导出 (core/sdk.ts)
```typescript
// Tool factories
export { createReadTool, createBashTool, createEditTool, createWriteTool }
export { createGrepTool, createFindTool, createLsTool }
export { createCodingTools, createReadOnlyTools }

// Pre-built tools
export { readTool, bashTool, editTool, writeTool }
export { grepTool, findTool, lsTool }
export { codingTools, readOnlyTools, allBuiltInTools }
```

### Python 实现 (__init__.py + tools/__init__.py)
```python
# Tool factories
create_read_tool, create_bash_tool, create_edit_tool, create_write_tool
create_grep_tool, create_find_tool, create_ls_tool
create_coding_tools, create_read_only_tools, create_all_tools

# Pre-built tools
read_tool, bash_tool, edit_tool, write_tool
grep_tool, find_tool, ls_tool
coding_tools, read_only_tools, all_tools
```

## 默认值对照

| 常量 | TypeScript | Python |
|------|-----------|--------|
| DEFAULT_MAX_LINES | 2000 | 2000 ✅ |
| DEFAULT_MAX_BYTES | 50 * 1024 (50KB) | 50 * 1024 ✅ |
| GREP_MAX_LINE_LENGTH | 500 | 500 ✅ |
| LS_DEFAULT_LIMIT | 500 | 500 ✅ |
| GREP_DEFAULT_LIMIT | 100 | 100 ✅ |
| FIND_DEFAULT_LIMIT | 1000 | 1000 ✅ |

## 测试状态

| 测试文件 | 测试数 | 状态 |
|---------|--------|------|
| test_truncate.py | 14 | ✅ 通过 |
| test_path_utils.py | 24 | ✅ 通过 |
| test_edit_diff.py | 25 | ✅ 通过 |
| test_tools.py | 20 | ✅ 18通过/2跳过 |
| test_config.py | 12 | ✅ 通过 |
| test_defaults.py | 1 | ✅ 通过 |
| test_shell.py | 6 | ✅ 通过 |
| test_git.py | 13 | ✅ 通过 |

**总测试**: 115 tests, 113 passed, 2 skipped (需要 rg/fd 命令行工具)

## 验证检查清单

- [x] 所有工具已实现 (read, write, edit, bash, ls, grep, find)
- [x] 所有工具函数已实现 (truncate, path_utils, edit_diff)
- [x] 参数类型匹配 (JSON Schema)
- [x] 返回值类型匹配 (AgentToolResult)
- [x] 边界情况处理一致
- [x] 截断行为正确
- [x] 错误处理一致
- [x] 测试用例通过

## 未实现的功能 (按需添加)

1. **core/agent-session.ts** - AgentSession 类
   - 完整的会话管理
   - 工具启用/禁用
   - 模型切换
   - 上下文压缩
   - 依赖: pi_agent, pi_ai

2. **core/bash-executor.ts** - Bash执行器
   - 独立的bash执行实现
   - 当前已在 tools/bash.py 中实现核心功能

---

_最后更新: 2026-02-20_
