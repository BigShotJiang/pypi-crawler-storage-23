import type { ThinkingLevel } from "@mariozechner/pi-agent-core";

export const DEFAULT_THINKING_LEVEL: ThinkingLevel = "medium";
