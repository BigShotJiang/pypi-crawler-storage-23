"""Core default constants for pi_coding module."""

# Default thinking level for agent reasoning
DEFAULT_THINKING_LEVEL = "medium"
