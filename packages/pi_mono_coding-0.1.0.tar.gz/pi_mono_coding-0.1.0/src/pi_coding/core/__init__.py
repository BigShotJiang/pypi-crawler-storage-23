"""Core module for pi_coding."""

from pi_coding.core.defaults import DEFAULT_THINKING_LEVEL

__all__ = ["DEFAULT_THINKING_LEVEL"]
