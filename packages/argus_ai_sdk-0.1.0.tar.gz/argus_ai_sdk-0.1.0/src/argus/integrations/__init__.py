"""Auto-instrumentation integrations for outgoing dependency calls."""
