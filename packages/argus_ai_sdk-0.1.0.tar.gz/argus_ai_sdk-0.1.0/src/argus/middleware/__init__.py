"""Framework middleware: FastAPI, Flask."""

from __future__ import annotations
