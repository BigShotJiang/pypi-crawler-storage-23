
# Project Archived

**This project has been archived and is no longer maintained.**

It has been replaced by the actively developed [`rocm-origami`](https://pypi.org/project/rocm-origami/) package on PyPI.

Please use `rocm-origami` for analytical GEMM solution selection and future updates.
