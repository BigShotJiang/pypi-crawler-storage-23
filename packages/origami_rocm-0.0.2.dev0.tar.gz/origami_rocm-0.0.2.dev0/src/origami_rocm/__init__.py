__version__ = "0.0.2.dev0"

def hello():
    return 'Hello from origami-rocm!'
