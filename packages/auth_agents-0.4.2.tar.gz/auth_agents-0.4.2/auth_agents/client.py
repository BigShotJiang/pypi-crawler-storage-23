"""Agent Auth client for credential verification and agent authentication."""

from __future__ import annotations

import base64
from typing import Any, Dict, Optional

import httpx

DEFAULT_BASE_URL = "https://auth.usevigil.dev"


def _b64url_encode(data: bytes) -> str:
    """Encode bytes as base64url without padding."""
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(s: str) -> bytes:
    """Decode base64url string (with or without padding)."""
    # Add padding if needed
    padding = 4 - len(s) % 4
    if padding != 4:
        s += "=" * padding
    return base64.urlsafe_b64decode(s)


class AuthAgents:
    """Client for the Agent Auth API.

    Args:
        base_url: Base URL of the Agent Auth API.
                  Defaults to https://auth.usevigil.dev
    """

    def __init__(self, base_url: str = DEFAULT_BASE_URL) -> None:
        base_url = base_url.rstrip("/")
        from urllib.parse import urlparse
        parsed = urlparse(base_url)
        if parsed.scheme != "https" and parsed.hostname not in ("localhost", "127.0.0.1"):
            raise ValueError(
                "AuthAgents: base_url must use HTTPS (http://localhost allowed for development)"
            )
        self.base_url = base_url

    # ---- Key Utilities ---------------------------------------------------

    @staticmethod
    def generate_key_pair() -> Dict[str, Dict[str, str]]:
        """Generate an Ed25519 keypair in JWK format.

        Returns:
            Dict with ``public_key_jwk`` and ``private_key_jwk``, each a JWK dict::

                {
                    "kty": "OKP",
                    "crv": "Ed25519",
                    "x": "<base64url-encoded 32-byte public key>",
                    "d": "<base64url-encoded 32-byte private seed>",  # private_key_jwk only
                }

        Example::

            from auth_agents import AuthAgents

            key_pair = AuthAgents.generate_key_pair()
            public_key_jwk  = key_pair["public_key_jwk"]
            private_key_jwk = key_pair["private_key_jwk"]
        """
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives import serialization

        private_key = Ed25519PrivateKey.generate()

        # Export raw 32-byte private seed
        raw_private = private_key.private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )

        # Export raw 32-byte public key
        raw_public = private_key.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )

        x = _b64url_encode(raw_public)
        d = _b64url_encode(raw_private)

        public_key_jwk: Dict[str, str] = {
            "kty": "OKP",
            "crv": "Ed25519",
            "x": x,
        }
        private_key_jwk: Dict[str, str] = {
            "kty": "OKP",
            "crv": "Ed25519",
            "x": x,
            "d": d,
        }

        return {
            "public_key_jwk": public_key_jwk,
            "private_key_jwk": private_key_jwk,
        }

    @staticmethod
    def sign_challenge(private_key_jwk: Dict[str, str], nonce: str) -> str:
        """Sign an authentication challenge nonce with an Ed25519 private key.

        The nonce is signed as UTF-8 encoded bytes (not hex-decoded).

        Args:
            private_key_jwk: JWK dict containing at minimum the ``d`` field
                             (base64url-encoded 32-byte private seed).
            nonce: The challenge nonce string returned by :meth:`challenge`.

        Returns:
            Base64url-encoded Ed25519 signature string (no padding).

        Example::

            from auth_agents import AuthAgents

            key_pair = AuthAgents.generate_key_pair()
            challenge_resp = client.challenge(did)
            signature = AuthAgents.sign_challenge(
                key_pair["private_key_jwk"],
                challenge_resp["nonce"],
            )
        """
        if "d" not in private_key_jwk:
            raise ValueError("private_key_jwk must contain the 'd' (private key) parameter")
        if not nonce:
            raise ValueError("nonce must not be empty")

        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

        raw_private = _b64url_decode(private_key_jwk["d"])
        private_key = Ed25519PrivateKey.from_private_bytes(raw_private)

        # Sign the nonce as UTF-8 text bytes
        signature_bytes = private_key.sign(nonce.encode("utf-8"))

        return _b64url_encode(signature_bytes)

    # ---- Credential Verification (for websites) --------------------------

    def verify(self, credential: str) -> Dict[str, Any]:
        """Verify a VC-JWT credential issued by Agent Auth.

        Args:
            credential: The VC-JWT string from the agent.

        Returns:
            On success, dict with ``valid=True`` and agent identity fields.
            If Agent Auth returns HTTP 401, returns the structured body
            (typically ``valid=False`` with ``error`` and ``message``)
            without raising.

        Example::

            from auth_agents import AuthAgents

            client = AuthAgents()
            result = client.verify("eyJhbGciOiJFZERTQSJ9...")

            if result["valid"]:
                print(result["agent_name"], result["did"])
                print(result["key_origin"])  # "server_generated" or "client_provided"
        """
        resp = httpx.post(
            f"{self.base_url}/v1/credentials/verify",
            json={"credential": credential},
            timeout=10.0,
        )
        if resp.status_code == 401:
            return resp.json()
        resp.raise_for_status()
        return resp.json()

    # ---- Agent Registration ----------------------------------------------

    def register(
        self,
        agent_name: str,
        agent_model: str,
        agent_provider: str,
        agent_purpose: str,
        public_key_jwk: Optional[Dict[str, str]] = None,
        credential_expires_in: Optional[int] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Register a new agent identity.

        The server generates an Ed25519 keypair and returns a DID,
        credential, and private key. Save the private key securely.

        Args:
            agent_name: Display name for the agent.
            agent_model: Model identifier (e.g. "claude-opus-4-6").
            agent_provider: Provider name (e.g. "Anthropic").
            agent_purpose: What the agent intends to do.
            public_key_jwk: Optional Ed25519 public key in JWK format (BYOK).
            credential_expires_in: Optional credential lifetime in seconds.
                                   Use 0 for non-expiring credential.
            metadata: Optional string key/value metadata map.

        Returns:
            Dict with ``did``, ``credential``, ``key_fingerprint``,
            ``key_origin`` (``"server_generated"`` or ``"client_provided"``),
            and ``private_key_jwk`` (only when server-generated).
        """
        body: Dict[str, Any] = {
            "agent_name": agent_name,
            "agent_model": agent_model,
            "agent_provider": agent_provider,
            "agent_purpose": agent_purpose,
        }
        if public_key_jwk is not None:
            body["public_key_jwk"] = public_key_jwk
        if credential_expires_in is not None:
            body["credential_expires_in"] = credential_expires_in
        if metadata is not None:
            body["metadata"] = metadata

        resp = httpx.post(
            f"{self.base_url}/v1/identities",
            json=body,
            timeout=10.0,
        )
        resp.raise_for_status()
        return resp.json()

    # ---- Challenge-Response Auth -----------------------------------------

    def challenge(self, did: str, site_id: Optional[str] = None) -> Dict[str, Any]:
        """Request an authentication challenge nonce.

        Args:
            did: The agent's DID (e.g. "did:key:z6Mk...").
            site_id: Optional site scope for deployments that provision site IDs.

        Returns:
            Dict with ``challenge_id``, ``nonce``, and ``expires_in``.
        """
        payload: Dict[str, Any] = {"did": did}
        if site_id is not None:
            payload["site_id"] = site_id

        resp = httpx.post(
            f"{self.base_url}/v1/auth/challenge",
            json=payload,
            timeout=10.0,
        )
        resp.raise_for_status()
        return resp.json()

    def authenticate(
        self,
        challenge_id: str,
        did: str,
        signature: str,
        credential_expires_in: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Submit a signed challenge to authenticate.

        Args:
            challenge_id: The challenge ID from :meth:`challenge`.
            did: The agent's DID.
            signature: Base64url-encoded Ed25519 signature of the nonce.
            credential_expires_in: Optional credential lifetime in seconds.
                                   Use 0 for non-expiring credential.

        Returns:
            On success, dict with ``valid``, ``session_token``, ``credential``,
            ``agent`` object, and ``expires_in``.
            If Agent Auth returns HTTP 401, returns the structured error body
            without raising.
        """
        payload: Dict[str, Any] = {
            "challenge_id": challenge_id,
            "did": did,
            "signature": signature,
        }
        if credential_expires_in is not None:
            payload["credential_expires_in"] = credential_expires_in

        resp = httpx.post(
            f"{self.base_url}/v1/auth/verify",
            json=payload,
            timeout=10.0,
        )
        if resp.status_code == 401:
            return resp.json()
        resp.raise_for_status()
        return resp.json()


def verify(credential: str) -> Dict[str, Any]:
    """Verify a credential with default settings.

    Shorthand for ``AuthAgents().verify(credential)``.

    Args:
        credential: The VC-JWT string from the agent.

    Returns:
        Dict with verification result.
    """
    return AuthAgents().verify(credential)
