"""Agent Auth SDK — Verify AI agent identities with DID-based authentication."""

from .client import AuthAgents, verify

__version__ = "0.4.1"
__all__ = ["AuthAgents", "verify"]
