"""confpub — Agent-first CLI to publish Markdown to Confluence."""

__version__ = "0.3.0"
