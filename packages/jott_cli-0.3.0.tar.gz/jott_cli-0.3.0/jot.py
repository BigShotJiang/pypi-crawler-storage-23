#!/Users/sonander/.asdf/installs/python/3.12.12/bin/python3
"""
jot - Simple, extensible interactive CLI task list
"""

import csv
import io
import json
import os
import platform
import re
import readline
import select
import shlex
import shutil
import subprocess
import sys
import tarfile
import tempfile
import termios
import time
import tty
import urllib.parse
import uuid
import webbrowser
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path

# File locking for concurrent access protection
try:
    from filelock import FileLock

    FILELOCK_AVAILABLE = True
except ImportError:
    FILELOCK_AVAILABLE = False
    FileLock = None

# Google Calendar API imports (optional - only used if enabled)
try:
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError

    GCAL_AVAILABLE = True
except ImportError:
    GCAL_AVAILABLE = False

# Text-to-Speech library (optional - cross-platform TTS)
try:
    import pyttsx3

    TTS_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False

# Import jot modules
from jot.core import constants
from jot.core.id_manager import IDManager
from jot.core.task_manager import TaskManager
from jot.projects.registry import ProjectRegistry
from jot.projects.backup import ProjectBackup
from jot.categories.manager import CategoryManager
from jot.categories.config import CategoryConfig
from jot.categories.templates import CategoryTemplates
from jot.integrations.gcal.account_manager import GoogleCalendarAccountManager
from jot.integrations.gcal.auth import GoogleCalendarAuth

# Update constants module with actual availability (must be after import checks above)
constants.GCAL_AVAILABLE = GCAL_AVAILABLE
constants.TTS_AVAILABLE = TTS_AVAILABLE
constants.FILELOCK_AVAILABLE = FILELOCK_AVAILABLE
from jot.integrations.gcal.events import create_gcal_event, fetch_gcal_events
from jot.integrations.keywords.handler import KeywordHandler
from jot.utils.validation import validate_safe_name
from jot.utils.date_utils import (
    get_today_day_name,
    sort_tasks_by_day,
    filter_today_tasks,
    round_to_15_minutes,
)
from jot.utils.text_utils import extract_urls, fuzzy_match
from jot.ui import (
    display_all_projects,
    display_archive,
    display_category_stats,
    display_categorized_shortcuts,
    display_help,
    display_tasks,
    format_category_badges,
    format_inline_notes,
)
from jot.commands import CommandHandler

# Update availability flags in constants module
constants.FILELOCK_AVAILABLE = FILELOCK_AVAILABLE
constants.GCAL_AVAILABLE = GCAL_AVAILABLE
constants.TTS_AVAILABLE = TTS_AVAILABLE

# Import constants for backward compatibility
MODE_QUICK_ADD = constants.MODE_QUICK_ADD
MODE_COMMAND = constants.MODE_COMMAND
MODE_MULTISELECT = constants.MODE_MULTISELECT
MODE_FUZZY_SEARCH = constants.MODE_FUZZY_SEARCH
MODE_ALL_CATEGORIES = constants.MODE_ALL_CATEGORIES
DAY_COLORS = constants.DAY_COLORS
DAY_ABBREVIATIONS = constants.DAY_ABBREVIATIONS


def input_with_prefill(prompt, prefill=''):
    """Get input with pre-filled text that user can edit"""

    def hook():
        readline.insert_text(prefill)
        readline.redisplay()

    readline.set_startup_hook(hook)
    try:
        return input(prompt)
    finally:
        readline.set_startup_hook()


# GoogleCalendarAccountManager removed - now imported from jot.integrations.gcal.account_manager
# GoogleCalendarAuth removed - now imported from jot.integrations.gcal.auth
# create_gcal_event removed - now imported from jot.integrations.gcal.events
# fetch_gcal_events removed - now imported from jot.integrations.gcal.events
# KeywordHandler removed - now imported from jot.integrations.keywords.handler
# CategoryConfig removed - now imported from jot.categories.config
# CategoryTemplates removed - now imported from jot.categories.templates

# ProjectBackup removed - now imported from jot.projects.backup
# IDManager removed - now imported from jot.core.id_manager
class ArchiveManager:
    """Manages archived tasks: compress, export, prune"""

    def __init__(self, project_dir=None):
        """Initialize ArchiveManager for a project directory"""
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self.config = self._load_config()

    def _load_config(self):
        """Load archive configuration"""
        config_file = self.project_dir / '.jot.config.json'
        defaults = {
            'archive': {
                'keep_in_main': 20,
                'compress_by': 'month',
                'auto_compress': False,
                'auto_prune_months': None,
            }
        }

        if config_file.exists():
            try:
                with open(config_file) as f:
                    user_config = json.load(f)
                    # Merge with defaults
                    if 'archive' in user_config:
                        defaults['archive'].update(user_config['archive'])
            except (json.JSONDecodeError, OSError):
                pass

        return defaults['archive']

    def _get_archive_files(self):
        """Find all archive files (.jot.archive.*.tar.gz)"""
        pattern = '.jot.archive.*.tar.gz'
        return sorted(self.project_dir.glob(pattern))

    def _read_task_manager_archives(self, category=None):
        """Read archived tasks from TaskManager files"""
        all_archived = []

        if category:
            # Read specific category
            if category == 'default':
                storage_file = self.project_dir / '.jot.json'
            else:
                storage_file = self.project_dir / f'.jot.{category}.json'

            if storage_file.exists():
                with open(storage_file) as f:
                    data = json.load(f)
                    all_archived.extend(data.get('archived', []))
        else:
            # Read all categories
            cat_mgr = CategoryManager(self.project_dir)

            # Default category
            default_file = self.project_dir / '.jot.json'
            if default_file.exists():
                with open(default_file) as f:
                    data = json.load(f)
                    all_archived.extend(data.get('archived', []))

            # Other categories
            for cat in cat_mgr.discover_categories():
                cat_file = self.project_dir / f'.jot.{cat}.json'
                if cat_file.exists():
                    with open(cat_file) as f:
                        data = json.load(f)
                        all_archived.extend(data.get('archived', []))

        return all_archived

    def _read_compressed_archive(self, archive_file):
        """Read tasks from a compressed archive file"""
        try:
            with tarfile.open(archive_file, 'r:gz') as tar:
                # Extract archive.json
                member = tar.getmember('archive.json')
                f = tar.extractfile(member)
                if f:
                    data = json.load(f)
                    return data.get('tasks', [])
        except (tarfile.TarError, KeyError, json.JSONDecodeError):
            return []

        return []

    def compress_archives(self, keep_n=None, category=None):
        """
        Compress old archived tasks into timestamped tar.gz files.

        Args:
            keep_n: Number of recent archived tasks to keep in main file
            category: Specific category to compress (or None for default)

        Returns:
            dict with compression results
        """
        if keep_n is None:
            keep_n = self.config['keep_in_main']

        # Determine storage file
        if category and category != 'default':
            storage_file = self.project_dir / f'.jot.{category}.json'
        else:
            storage_file = self.project_dir / '.jot.json'

        if not storage_file.exists():
            return {'error': f'File not found: {storage_file}'}

        # Read current data
        with open(storage_file) as f:
            data = json.load(f)

        archived = data.get('archived', [])

        if len(archived) <= keep_n:
            return {'message': f'Only {len(archived)} archived tasks, no compression needed'}

        # Keep recent N, compress the rest
        to_keep = archived[-keep_n:]
        to_compress = archived[:-keep_n]

        # Group by month
        by_month = {}
        for task in to_compress:
            # Try to determine month from task data
            month = None

            # Check for created_at or updated_at timestamp
            for field in ['updated_at', 'created_at']:
                if field in task:
                    try:
                        dt = datetime.fromisoformat(task[field].replace('Z', '+00:00'))
                        month = dt.strftime('%Y-%m')
                        break
                    except (ValueError, AttributeError):
                        pass

            # Fallback to current month if no timestamp
            if not month:
                month = datetime.now().strftime('%Y-%m')

            if month not in by_month:
                by_month[month] = []
            by_month[month].append(task)

        # Create compressed archives
        compressed_count = 0
        for month, tasks in by_month.items():
            archive_file = self.project_dir / f'.jot.archive.{month}.tar.gz'

            # If archive already exists, merge tasks
            existing_tasks = []
            if archive_file.exists():
                existing_tasks = self._read_compressed_archive(archive_file)

            # Combine and deduplicate by ID
            all_tasks = existing_tasks + tasks
            task_dict = {t['id']: t for t in all_tasks}
            final_tasks = list(task_dict.values())

            # Create archive data
            archive_data = {
                'month': month,
                'created_at': datetime.now().isoformat(),
                'tasks': final_tasks,
            }

            # Write to tar.gz

            json_data = json.dumps(archive_data, indent=2).encode('utf-8')
            json_file = io.BytesIO(json_data)

            with tarfile.open(archive_file, 'w:gz') as tar:
                tarinfo = tarfile.TarInfo(name='archive.json')
                tarinfo.size = len(json_data)
                tar.addfile(tarinfo, json_file)

            compressed_count += len(tasks)

        # Update storage file with only recent archives
        data['archived'] = to_keep
        with open(storage_file, 'w') as f:
            json.dump(data, f, indent=2)

        return {
            'compressed': compressed_count,
            'kept_in_main': len(to_keep),
            'archive_files_created': len(by_month),
        }

    def export_archives(self, format='json', output=None, include_compressed=True, category=None):
        """
        Export archived tasks to various formats.

        Args:
            format: 'json', 'csv', 'markdown', or 'text'
            output: Output file path (or None for stdout)
            include_compressed: Include tasks from compressed archives
            category: Export specific category only

        Returns:
            dict with export results
        """
        # Collect all archived tasks
        archived_tasks = self._read_task_manager_archives(category)

        # Add tasks from compressed archives if requested
        if include_compressed:
            for archive_file in self._get_archive_files():
                archived_tasks.extend(self._read_compressed_archive(archive_file))

        if not archived_tasks:
            return {'error': 'No archived tasks found'}

        # Determine output destination
        if output:
            output_path = Path(output)
        else:
            # Default output names
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_path = self.project_dir / f'jot_archive_export_{timestamp}.{format}'

        # Export based on format
        if format == 'json':
            self._export_json(archived_tasks, output_path)
        elif format == 'csv':
            self._export_csv(archived_tasks, output_path)
        elif format == 'markdown':
            self._export_markdown(archived_tasks, output_path)
        elif format == 'text':
            self._export_text(archived_tasks, output_path)
        else:
            return {'error': f'Unknown format: {format}'}

        return {
            'exported': len(archived_tasks),
            'format': format,
            'output': str(output_path),
        }

    def _export_json(self, tasks, output_path):
        """Export to JSON format"""
        export_data = {
            'exported_at': datetime.now().isoformat(),
            'task_count': len(tasks),
            'tasks': tasks,
        }
        with open(output_path, 'w') as f:
            json.dump(export_data, f, indent=2)

    def _export_csv(self, tasks, output_path):
        """Export to CSV format"""
        # Determine all possible fields
        fieldnames = [
            'id',
            'text',
            'done',
            'current',
            'day',
            'priority',
            'status',
            'tally',
            'time_spent',
        ]

        with open(output_path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
            writer.writeheader()
            for task in tasks:
                writer.writerow(task)

    def _export_markdown(self, tasks, output_path):
        """Export to Markdown format"""
        with open(output_path, 'w') as f:
            f.write('# Archived Tasks\n\n')
            f.write(f'Exported: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n\n')
            f.write(f'Total tasks: {len(tasks)}\n\n')
            f.write('---\n\n')

            for task in tasks:
                f.write(f'## Task #{task["id"]}\n\n')
                f.write(f'**Text:** {task["text"]}\n\n')

                if task.get('done'):
                    f.write(f'**Status:** ✓ Done\n\n')

                if task.get('day'):
                    f.write(f'**Day:** {task["day"]}\n\n')

                if task.get('priority') and task['priority'] != 'none':
                    f.write(f'**Priority:** {task["priority"]}\n\n')

                if task.get('tally', 0) > 0:
                    f.write(f'**Tally:** {task["tally"]}\n\n')

                if task.get('time_spent'):
                    f.write(f'**Time Spent:** {task["time_spent"]}\n\n')

                f.write('---\n\n')

    def _export_text(self, tasks, output_path):
        """Export to plain text format"""
        with open(output_path, 'w') as f:
            f.write('ARCHIVED TASKS\n')
            f.write('=' * 60 + '\n\n')
            f.write(f'Exported: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
            f.write(f'Total tasks: {len(tasks)}\n\n')

            for i, task in enumerate(tasks, 1):
                f.write(f'{i}. [{task["id"]}] {task["text"]}\n')

                details = []
                if task.get('done'):
                    details.append('✓ Done')
                if task.get('day'):
                    details.append(f'Day: {task["day"]}')
                if task.get('priority') and task['priority'] != 'none':
                    details.append(f'Priority: {task["priority"]}')
                if task.get('tally', 0) > 0:
                    details.append(f'Tally: {task["tally"]}')

                if details:
                    f.write(f'   {" | ".join(details)}\n')

                f.write('\n')

    def prune_archives(self, strategy='older_than', value=None, interactive=False):
        """
        Remove old archived tasks.

        Args:
            strategy: 'older_than' (months), 'keep_last' (count), or 'file' (specific file)
            value: Strategy-specific value (e.g., 6 for 6 months, 100 for 100 tasks)
            interactive: Show confirmation dialog

        Returns:
            dict with prune results
        """
        archive_files = self._get_archive_files()

        if not archive_files:
            return {'message': 'No compressed archive files found'}

        files_to_delete = []

        if strategy == 'older_than' and value:
            # Delete archives older than N months
            cutoff_date = datetime.now() - timedelta(days=value * 30)

            for archive_file in archive_files:
                # Extract date from filename: .jot.archive.2025-11.tar.gz
                match = re.search(r'\.jot\.archive\.(\d{4}-\d{2})\.tar\.gz', archive_file.name)
                if match:
                    archive_month = match.group(1)
                    try:
                        archive_date = datetime.strptime(archive_month, '%Y-%m')
                        if archive_date < cutoff_date:
                            files_to_delete.append(archive_file)
                    except ValueError:
                        pass

        elif strategy == 'file' and value:
            # Delete specific file
            target_file = self.project_dir / value
            if target_file.exists():
                files_to_delete.append(target_file)

        if not files_to_delete:
            return {'message': 'No archives match prune criteria'}

        # Show confirmation if interactive
        if interactive:
            print(f'\nFiles to delete:')
            for f in files_to_delete:
                size = f.stat().st_size
                print(f'  - {f.name} ({size} bytes)')
            print(f'\nTotal: {len(files_to_delete)} files')

            response = input('\nProceed with deletion? (y/N): ').strip().lower()
            if response != 'y':
                return {'cancelled': True}

        # Delete files
        deleted_count = 0
        for file_path in files_to_delete:
            try:
                file_path.unlink()
                deleted_count += 1
            except OSError as e:
                print(f'Error deleting {file_path}: {e}')

        return {
            'deleted': deleted_count,
            'files': [f.name for f in files_to_delete],
        }

    def get_archive_stats(self):
        """Get statistics about archives"""
        # Count archives in main files
        archived_in_main = self._read_task_manager_archives()

        # Count archives in compressed files
        archive_files = self._get_archive_files()
        archived_in_compressed = []
        for archive_file in archive_files:
            archived_in_compressed.extend(self._read_compressed_archive(archive_file))

        # Calculate sizes
        total_size = sum(f.stat().st_size for f in archive_files)

        # Find date range
        all_tasks = archived_in_main + archived_in_compressed
        dates = []
        for task in all_tasks:
            for field in ['updated_at', 'created_at']:
                if field in task:
                    try:
                        dt = datetime.fromisoformat(task[field].replace('Z', '+00:00'))
                        dates.append(dt)
                        break
                    except (ValueError, AttributeError):
                        pass

        oldest = min(dates) if dates else None
        newest = max(dates) if dates else None

        return {
            'total_archived': len(all_tasks),
            'in_main_files': len(archived_in_main),
            'in_compressed': len(archived_in_compressed),
            'compressed_files': len(archive_files),
            'total_size_bytes': total_size,
            'oldest_task': oldest.strftime('%Y-%m-%d') if oldest else None,
            'newest_task': newest.strftime('%Y-%m-%d') if newest else None,
            'archive_files': [f.name for f in archive_files],
        }


# TaskManager removed - now imported from jot.core.task_manager
def get_key(timeout=1.0):
    """Read a single keypress with timeout, including arrow keys and shift combinations

    Args:
        timeout: Seconds to wait for input before returning None

    Returns:
        Key character/code, tuple for paste ('PASTE', text), or None on timeout
    """
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)

        # Use select to wait for input with timeout
        ready, _, _ = select.select([sys.stdin], [], [], timeout)
        if not ready:
            return None  # Timeout - no input available

        ch = sys.stdin.read(1)

        # Check if more characters are immediately available (paste detection)
        # Use a very short timeout (0.001 seconds) to detect rapid input
        more_ready, _, _ = select.select([sys.stdin], [], [], 0.001)
        if more_ready:
            # Multiple characters available - this is likely a paste
            pasted_text = ch
            # Read all available characters
            while True:
                chunk_ready, _, _ = select.select([sys.stdin], [], [], 0.001)
                if not chunk_ready:
                    break
                pasted_text += sys.stdin.read(1)
            return ('PASTE', pasted_text)

        # Handle Ctrl+n (next/down) and Ctrl+p (previous/up)
        if ch == '\x0e':  # Ctrl+n
            return 'DOWN'
        elif ch == '\x10':  # Ctrl+p
            return 'UP'

        # Handle escape sequences (arrow keys)
        if ch == '\x1b':  # ESC
            ch2 = sys.stdin.read(1)
            if ch2 == '[':
                ch3 = sys.stdin.read(1)
                # Check for standard arrow keys
                if ch3 == 'A':
                    return 'UP'
                elif ch3 == 'B':
                    return 'DOWN'
                # Check for shift+arrow keys (1;2A = Shift+Up, 1;2B = Shift+Down)
                elif ch3 == '1':
                    ch4 = sys.stdin.read(1)
                    if ch4 == ';':
                        ch5 = sys.stdin.read(1)
                        if ch5 == '2':
                            ch6 = sys.stdin.read(1)
                            if ch6 == 'A':
                                return 'SHIFT_UP'
                            elif ch6 == 'B':
                                return 'SHIFT_DOWN'

        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def load_auto_backlog_config():
    """Load auto-backlog configuration from ~/.jot-config.json

    Returns:
        dict: Configuration with keys:
            - enabled: bool (default True)
            - age_threshold_days: int (default 30)
            - backlog_category: str (default 'backlog')
    """
    config_file = Path.home() / '.jot-config.json'

    # Default configuration
    default_config = {'enabled': True, 'age_threshold_days': 30, 'backlog_category': 'backlog'}

    if not config_file.exists():
        return default_config

    try:
        with open(config_file, 'r') as f:
            config = json.load(f)
            auto_backlog = config.get('auto_backlog', {})

            # Merge with defaults
            result = default_config.copy()
            result.update(auto_backlog)
            return result
    except (json.JSONDecodeError, IOError):
        return default_config


def main():
    """Main application loop with dual-mode support and project routing"""
    registry = ProjectRegistry()

    # Parse flags
    category = None
    explicit_global = False
    args = sys.argv[1:]  # Skip program name

    # Handle --help / -h flag (check first to ensure it always works)
    if '--help' in args or '-h' in args:
        display_help()
        return

    # Check for --all flag (broadcast to all projects)
    broadcast_all = '--all' in args
    if broadcast_all:
        args.remove('--all')

    # Check for --global flag
    if '--global' in args:
        explicit_global = True
        args.remove('--global')

    # Check for --category / -c flag
    if '--category' in args:
        idx = args.index('--category')
        if idx + 1 < len(args):
            category = args[idx + 1]
            # Remove flag and value from args
            args = args[:idx] + args[idx + 2 :]
    elif '-c' in args:
        idx = args.index('-c')
        if idx + 1 < len(args):
            category = args[idx + 1]
            # Remove flag and value from args
            args = args[:idx] + args[idx + 2 :]

    # Handle project management commands
    if len(args) > 0:
        if args[0] == '--list-projects':
            projects = registry.list_projects()
            if projects:
                print("\nRegistered Projects:")
                for name, path in sorted(projects.items()):
                    print(f"  {name:20} → {path}")
            else:
                print("\nNo registered projects. Run jot to auto-discover projects in ~/projects/")
            return

        elif args[0] == '--register' and len(args) == 3:
            name, path = args[1], args[2]
            registry.register_project(name, path)
            print(f"✓ Registered project '{name}' → {path}")
            return

        elif args[0] == '--unregister' and len(args) == 2:
            name = args[1]
            if registry.unregister_project(name):
                print(f"✓ Unregistered project '{name}'")
            else:
                print(f"✗ Project '{name}' not found")
            return

        elif args[0] == '--refresh':
            registry.refresh()
            print("✓ Project registry refreshed")
            return

        elif args[0] == '--all-projects':
            # Check if --show-categories flag is also present
            show_categories = '--show-categories' in args
            display_all_projects(registry, show_categories=show_categories)
            return

        elif args[0] == '--fix-duplicates':
            # Fix duplicate task IDs in current directory

            jot_file = Path.cwd() / '.jot.json'

            if not jot_file.exists():
                print(f"✗ No .jot.json found in {Path.cwd()}")
                return

            print(f"\n🔧 Fixing duplicate IDs in {jot_file}...")

            # Get path to fix-duplicate-ids.py (same directory as jot.py)
            fix_script = Path(__file__).parent / 'fix-duplicate-ids.py'

            if not fix_script.exists():
                print(f"✗ fix-duplicate-ids.py not found at {fix_script}")
                print(f"   Please run manually: python3 fix-duplicate-ids.py {jot_file}")
                return

            try:
                # Run the fixer
                result = subprocess.run(
                    ['python3', str(fix_script), str(jot_file)],
                    capture_output=True,
                    text=True,
                    check=True,
                )

                # Print output
                print(result.stdout)

                if result.returncode == 0:
                    print("\n✓ Duplicate IDs fixed! You can now run jott again.")
                else:
                    print(f"\n✗ Fix failed with exit code {result.returncode}")
                    if result.stderr:
                        print(f"Error: {result.stderr}")

            except subprocess.CalledProcessError as e:
                print(f"✗ Fix failed: {e}")
                if e.stderr:
                    print(f"Error: {e.stderr}")

            return

        elif args[0] == '--archive':
            # Display archived tasks, optionally filtered by category
            filter_category = None
            if len(args) > 1 and not args[1].startswith('--'):
                filter_category = args[1]
            display_archive(Path.cwd(), filter_category)
            return

        elif args[0] == '--archive-compress':
            # Compress archives
            archive_mgr = ArchiveManager(Path.cwd())
            keep_n = None
            if '--keep' in args:
                idx = args.index('--keep')
                if idx + 1 < len(args):
                    try:
                        keep_n = int(args[idx + 1])
                    except ValueError:
                        print("✗ --keep requires a number")
                        return

            result = archive_mgr.compress_archives(keep_n=keep_n, category=category)

            if 'error' in result:
                print(f"✗ {result['error']}")
            elif 'message' in result:
                print(f"ℹ {result['message']}")
            else:
                print(f"✓ Compressed {result['compressed']} archived tasks")
                print(f"  Kept {result['kept_in_main']} in main file")
                print(f"  Created {result['archive_files_created']} archive files")
            return

        elif args[0] == '--archive-export':
            # Export archives
            archive_mgr = ArchiveManager(Path.cwd())
            format = 'json'
            output = None

            if '--format' in args:
                idx = args.index('--format')
                if idx + 1 < len(args):
                    format = args[idx + 1]

            if '--output' in args:
                idx = args.index('--output')
                if idx + 1 < len(args):
                    output = args[idx + 1]

            result = archive_mgr.export_archives(
                format=format, output=output, include_compressed=True, category=category
            )

            if 'error' in result:
                print(f"✗ {result['error']}")
            else:
                print(f"✓ Exported {result['exported']} archived tasks")
                print(f"  Format: {result['format']}")
                print(f"  Output: {result['output']}")
            return

        elif args[0] == '--archive-prune':
            # Prune archives
            archive_mgr = ArchiveManager(Path.cwd())
            strategy = 'older_than'
            value = None
            interactive = '--interactive' in args

            if '--older-than' in args:
                idx = args.index('--older-than')
                if idx + 1 < len(args):
                    try:
                        value = int(args[idx + 1])
                        strategy = 'older_than'
                    except ValueError:
                        print("✗ --older-than requires a number (months)")
                        return

            if '--file' in args:
                idx = args.index('--file')
                if idx + 1 < len(args):
                    value = args[idx + 1]
                    strategy = 'file'

            result = archive_mgr.prune_archives(
                strategy=strategy, value=value, interactive=interactive
            )

            if 'error' in result:
                print(f"✗ {result['error']}")
            elif 'message' in result:
                print(f"ℹ {result['message']}")
            elif 'cancelled' in result:
                print("✗ Pruning cancelled")
            else:
                print(f"✓ Deleted {result['deleted']} archive files")
                for filename in result['files']:
                    print(f"  - {filename}")
            return

        elif args[0] == '--archive-stats':
            # Show archive statistics
            archive_mgr = ArchiveManager(Path.cwd())
            stats = archive_mgr.get_archive_stats()

            BOLD = '\033[1m'
            CYAN = '\033[96m'
            RESET = '\033[0m'

            print(f"\n{BOLD}Archive Statistics{RESET}")
            print("-" * 60)
            print(f"Total archived tasks:     {CYAN}{stats['total_archived']}{RESET}")
            print(f"  In main files:          {stats['in_main_files']}")
            print(f"  In compressed files:    {stats['in_compressed']}")
            print()
            print(f"Compressed files:         {stats['compressed_files']}")
            print(f"Total size:               {stats['total_size_bytes']} bytes")

            if stats['oldest_task']:
                print(f"Oldest task:              {stats['oldest_task']}")
            if stats['newest_task']:
                print(f"Newest task:              {stats['newest_task']}")

            if stats['archive_files']:
                print(f"\n{BOLD}Archive Files:{RESET}")
                for filename in stats['archive_files']:
                    print(f"  - {filename}")

            print()
            return

        elif args[0] == '--stats':
            # Display category statistics
            display_category_stats(Path.cwd())
            return

        elif args[0] == '--colors':
            # Show available colors with examples
            cat_config = CategoryConfig()
            colors = cat_config.list_available_colors()
            RESET = '\033[0m'
            BOLD = '\033[1m'

            print(f"\n{BOLD}Available Colors:{RESET}")
            print("-" * 40)
            for color_name in colors:
                color_code = CategoryConfig.COLORS[color_name]
                print(f"  {color_code}{color_name:12}{RESET} - {color_code}■■■{RESET} Example text")
            print("-" * 40)
            print(f"\n{BOLD}Usage:{RESET}")
            print(f"  jot --set-color <category> <color>")
            print(f"  jot --list-colors")
            print(f"  jot --reset-colors")
            print()
            return

        elif args[0] == '--set-color' and len(args) >= 3:
            # Set color for a category
            category_name = args[1]
            color_name = args[2]
            cat_config = CategoryConfig()
            success, message = cat_config.set_color(category_name, color_name)
            if success:
                color_code = CategoryConfig.COLORS[color_name]
                RESET = '\033[0m'
                print(f"✓ {message}")
                print(f"  Preview: {color_code}{category_name}{RESET}")
            else:
                print(f"✗ {message}")
            return

        elif args[0] == '--list-colors':
            # List configured colors
            cat_config = CategoryConfig()
            custom_colors = cat_config.get_all_colors()
            RESET = '\033[0m'
            BOLD = '\033[1m'

            print(f"\n{BOLD}Configured Category Colors:{RESET}")
            print("-" * 40)

            if not custom_colors:
                print("  No custom colors configured.")
                print("  Using default colors.")
            else:
                for cat_name, color_name in sorted(custom_colors.items()):
                    color_code = CategoryConfig.COLORS.get(color_name, '\033[96m')
                    print(f"  {color_code}{cat_name:20}{RESET} → {color_name}")

            print("-" * 40)
            print(f"\n{BOLD}Default Colors:{RESET}")
            for cat_name, color_name in sorted(CategoryConfig.DEFAULT_COLORS.items()):
                if cat_name not in custom_colors:
                    color_code = CategoryConfig.COLORS[color_name]
                    print(f"  {color_code}{cat_name:20}{RESET} → {color_name}")
            print()
            return

        elif args[0] == '--reset-colors':
            # Reset all colors to defaults
            cat_config = CategoryConfig()
            cat_config.reset_colors()
            print("✓ Reset all colors to defaults")
            return

        elif args[0] == '--list-templates':
            # List available templates
            templates_manager = CategoryTemplates()
            templates = templates_manager.list_templates()
            RESET = '\033[0m'
            BOLD = '\033[1m'
            CYAN = '\033[96m'
            DIM = '\033[2m'

            print(f"\n{BOLD}Available Category Templates:{RESET}")
            print("=" * 60)

            for template_id, template in sorted(templates.items()):
                print(f"\n{CYAN}{BOLD}{template_id}{RESET}")
                print(f"  {template['name']}")
                print(f"  {DIM}{template['description']}{RESET}")
                print(f"  Categories: {', '.join(template['categories'])}")

            print("\n" + "=" * 60)
            print(f"\n{BOLD}Usage:{RESET}")
            print(f"  jot --template <name>              # Apply template")
            print(f"  jot --template <name> --with-samples  # Include sample tasks")
            print()
            return

        elif args[0] == '--template' and len(args) >= 2:
            # Apply a template
            template_name = args[1]
            with_samples = '--with-samples' in args

            templates_manager = CategoryTemplates()
            success, message = templates_manager.apply_template(
                template_name, with_samples=with_samples
            )

            if success:
                print(f"✓ {message}")
                if with_samples:
                    print("  Sample tasks added to each category")
                print("\n  Use Shift+C to switch between categories")
            else:
                print(f"✗ {message}")
            return

        elif args[0] == '--backup':
            # Create backup of all jot files
            output_file = None
            if '--output' in args:
                idx = args.index('--output')
                if idx + 1 < len(args):
                    output_file = args[idx + 1]

            backup = ProjectBackup()
            success, message = backup.create_backup(output_file)

            if success:
                print(f"✓ {message}")
            else:
                print(f"✗ {message}")
            return

        elif args[0] == '--restore' and len(args) >= 2:
            # Restore from backup
            backup_file = args[1]
            force = '--force' in args

            backup = ProjectBackup()
            success, message = backup.restore_backup(backup_file, force=force)

            if success:
                print(f"✓ {message}")
            else:
                print(f"✗ {message}")
            return

        elif args[0] == '--list-backup' and len(args) >= 2:
            # List contents of a backup
            backup_file = args[1]

            backup = ProjectBackup()
            success, message = backup.list_backup_contents(backup_file)

            if success:
                print(message)
            else:
                print(f"✗ {message}")
            return

        elif args[0] == '--migrate-backlog-schema':
            # Migrate existing tasks to include backlog grooming metadata
            print("\n🔄 Migrating tasks to backlog grooming schema...")
            print(
                "This will add priority, status, labels, timestamps, effort, and blocked_by fields.\n"
            )

            # Confirm with user
            response = input("Proceed with migration? (y/N): ").strip().lower()
            if response != 'y':
                print("✗ Migration cancelled")
                return

            # Create backup before migration
            print("\n📦 Creating backup before migration...")
            backup = ProjectBackup()
            backup_success, backup_msg = backup.create_backup()

            if not backup_success:
                print(f"✗ Backup failed: {backup_msg}")
                print("Migration aborted for safety.")
                return

            print(f"✓ {backup_msg}\n")

            # Run migration on current project
            task_manager = TaskManager(
                storage_file='.jot.json',
                directory=Path.cwd(),
                category=category,
                is_global=explicit_global,
                project_registry=registry,
            )

            stats = task_manager.migrate_backlog_schema()

            # Display results
            print("✓ Migration complete!")
            print(f"\n  Migrated: {stats['migrated']} tasks")
            print(f"  Already migrated: {stats['already_migrated']} tasks")
            print(f"  Total tasks: {stats['total']} tasks\n")

            if stats['migrated'] > 0:
                print("New fields added:")
                print("  • priority: 'none' (default)")
                print("  • status: 'todo' or 'done' (based on existing done field)")
                print("  • created_at: current timestamp")
                print("  • updated_at: current timestamp")
                print("  • labels: [] (empty)")
                print("  • effort: null")
                print("  • blocked_by: [] (empty)\n")

            return

        elif args[0] == '--day' and len(args) >= 2:
            # Filter tasks by specific day
            day_filter = args[1].capitalize()

            # Validate day name
            valid_days = [
                'Monday',
                'Tuesday',
                'Wednesday',
                'Thursday',
                'Friday',
                'Saturday',
                'Sunday',
            ]
            if day_filter not in valid_days:
                print(f"✗ Invalid day: {day_filter}")
                print(f"Valid days: {', '.join(valid_days)}")
                return

            # Load tasks and filter by day
            task_manager = TaskManager(project_registry=registry)
            all_tasks = task_manager.get_tasks()
            filtered_tasks = [t for t in all_tasks if t.get('day') == day_filter]

            # Display filtered tasks
            RESET = '\033[0m'
            BOLD = '\033[1m'
            day_color = DAY_COLORS[day_filter]
            day_abbrev = DAY_ABBREVIATIONS[day_filter]

            print(f"\n{BOLD}Tasks for {day_color}{day_abbrev}{RESET} {BOLD}{day_filter}:{RESET}")
            print("=" * 50)

            if not filtered_tasks:
                print(f"\nNo tasks scheduled for {day_filter}")
            else:
                for task in filtered_tasks:
                    status = "✓" if task.get('done', False) else " "
                    is_current = "✨ " if task.get('current', False) else ""
                    print(f"  [{status}] {task['id']}. {is_current}{task['text']}")
                print(f"\nTotal: {len(filtered_tasks)} tasks")

            print("=" * 50 + "\n")
            return

        elif args[0] == '--today':
            # Show today's tasks
            today = get_today_day_name()

            # Load tasks and filter by today
            task_manager = TaskManager(project_registry=registry)
            all_tasks = task_manager.get_tasks()
            filtered_tasks = [t for t in all_tasks if t.get('day') == today]

            # Display tasks
            RESET = '\033[0m'
            BOLD = '\033[1m'
            day_color = DAY_COLORS[today]
            day_abbrev = DAY_ABBREVIATIONS[today]

            print(f"\n{BOLD}Today's Tasks ({day_color}{day_abbrev}{RESET} {BOLD}{today}):{RESET}")
            print("=" * 50)

            if not filtered_tasks:
                print(f"\nNo tasks scheduled for today")
            else:
                for task in filtered_tasks:
                    status = "✓" if task.get('done', False) else " "
                    is_current = "✨ " if task.get('current', False) else ""
                    print(f"  [{status}] {task['id']}. {is_current}{task['text']}")
                print(f"\nTotal: {len(filtered_tasks)} tasks")

            print("=" * 50 + "\n")
            return

        elif args[0] == '--week':
            # Show this week's tasks sorted by day
            task_manager = TaskManager(project_registry=registry)
            all_tasks = task_manager.get_tasks()

            # Group tasks by day (Sunday through Saturday)
            days_order = [
                'Sunday',
                'Monday',
                'Tuesday',
                'Wednesday',
                'Thursday',
                'Friday',
                'Saturday',
            ]
            tasks_by_day = {day: [] for day in days_order}
            tasks_no_day = []

            for task in all_tasks:
                day = task.get('day')
                if day and day in tasks_by_day:
                    tasks_by_day[day].append(task)
                elif not day:
                    tasks_no_day.append(task)

            # Display
            RESET = '\033[0m'
            BOLD = '\033[1m'
            today = get_today_day_name()

            print(f"\n{BOLD}This Week's Tasks:{RESET}")
            print("=" * 50)

            total_count = 0
            for day in days_order:
                day_tasks = tasks_by_day[day]
                if day_tasks:
                    day_color = DAY_COLORS[day]
                    day_abbrev = DAY_ABBREVIATIONS[day]
                    today_marker = " (Today)" if day == today else ""
                    print(
                        f"\n{day_color}{BOLD}{day_abbrev}{RESET} {BOLD}{day}{today_marker}:{RESET}"
                    )
                    for task in day_tasks:
                        status = "✓" if task.get('done', False) else " "
                        is_current = "✨ " if task.get('current', False) else ""
                        print(f"  [{status}] {task['id']}. {is_current}{task['text']}")
                        total_count += 1

            if tasks_no_day:
                print(f"\n{BOLD}No Day Assigned:{RESET}")
                for task in tasks_no_day:
                    status = "✓" if task.get('done', False) else " "
                    is_current = "✨ " if task.get('current', False) else ""
                    print(f"  [{status}] {task['id']}. {is_current}{task['text']}")

            print(f"\n{BOLD}Total:{RESET} {total_count} tasks with days assigned")
            print("=" * 50 + "\n")
            return

    # Determine target directory and project name
    target_dir = None
    project_name = None
    initial_task = None

    if len(args) > 0:
        # Check if first argument is a project name
        potential_project = args[0]
        project_path = registry.get_project_path(potential_project)

        if project_path:
            # Project routing mode
            target_dir = project_path
            project_name = potential_project
            if len(args) > 1:
                initial_task = ' '.join(args[1:])
        else:
            # Regular mode: all args are task text
            initial_task = ' '.join(args)

    # Determine if we should use global category
    is_global = False
    if category:
        cat_manager = CategoryManager(project_dir=target_dir or Path.cwd())

        if explicit_global:
            # User explicitly requested global
            is_global = True
        else:
            # Resolve category location: local → global → new
            location = cat_manager.resolve_category_location(category)

            if location == 'global':
                # Category exists globally, use it
                is_global = True
            elif location == 'local':
                # Category exists locally, use it
                is_global = False
            else:
                # New category - create locally by default
                is_global = False

                # Check local category limit
                can_create, error_msg = cat_manager.can_create_category(category)
                if not can_create:
                    print(f"✗ {error_msg}")
                    return

                # Show warning if approaching limit
                warning_msg = cat_manager.get_warning_message(category)
                if warning_msg:
                    print(warning_msg)

    # Initialize task manager with appropriate directory and category
    task_manager = TaskManager(
        directory=target_dir,
        category=category,
        is_global=is_global,
        project_registry=registry,
    )
    command_handler = CommandHandler(task_manager, registry)

    # Auto-transfer old tasks to backlog (configurable via ~/.jot-config.json)
    auto_backlog_config = load_auto_backlog_config()
    if auto_backlog_config.get('enabled', True):  # Enabled by default
        age_threshold = auto_backlog_config.get('age_threshold_days', 30)
        backlog_category = auto_backlog_config.get('backlog_category', 'backlog')

        # Only run if not already in backlog category (avoid recursion)
        if category != backlog_category:
            result = task_manager.transfer_old_tasks_to_backlog(
                age_threshold_days=age_threshold, backlog_category=backlog_category
            )
            # Silent operation - don't notify unless tasks were transferred
            if result['transferred'] > 0:
                # Optional: Could add a notification here
                pass

    # Ensure default "take a break" task exists if no tasks present
    task_manager.ensure_default_task()

    # Broadcast task to all registered projects
    if initial_task and broadcast_all:
        projects = registry.list_projects()
        if not projects:
            print("✗ No registered projects found. Use --register to add projects.")
            return
        for proj_name, proj_path in projects.items():
            tm = TaskManager(directory=proj_path, project_registry=registry)
            tm.add_task(initial_task)
        print(f"✓ Added task to {len(projects)} projects: {initial_task}")
        return

    # Add initial task if provided
    if initial_task:
        task_manager.add_task(initial_task)
        location = project_name or Path.cwd().name

        if is_global and category:
            print(f"✓ Added task to global ({category}): {initial_task}")
        elif category:
            print(f"✓ Added task to {location} ({category}): {initial_task}")
        else:
            print(f"✓ Added task to {location}: {initial_task}")
        return

    # Mode state
    mode = MODE_QUICK_ADD  # Start in quick-add mode
    input_buffer = ""
    show_archived = False  # Toggle for showing archived tasks
    sort_by_day = False  # Toggle for sorting tasks by day of week
    show_today_only = False  # Toggle for showing only today's tasks
    include_archived_in_search = True  # Toggle for including archived tasks in fuzzy search
    show_shortcuts = False  # Toggle for showing shortcuts helper text (default: hidden)
    show_notes_inline = False  # Toggle for showing notes indented below tasks

    # Track file modification time for auto-refresh
    last_mtime = (
        os.path.getmtime(task_manager.storage_file) if task_manager.storage_file.exists() else 0
    )

    running = True
    selected_tasks = set()  # Track selected tasks for multi-select mode
    search_buffer = ""  # Track search query for fuzzy search mode
    filtered_tasks = []  # Track filtered/scored tasks for fuzzy search mode
    archived_task_ids = set()  # Track which tasks in display are archived

    while running:
        # Clear screen (works on Unix/Linux/macOS)
        os.system('clear' if os.name != 'nt' else 'cls')

        # Get tasks and optionally filter/sort
        tasks_to_display = task_manager.get_tasks()
        if show_today_only:
            today = get_today_day_name()
            tasks_to_display = filter_today_tasks(tasks_to_display, today)
        if sort_by_day:
            tasks_to_display = sort_tasks_by_day(tasks_to_display)

        # In fuzzy search mode, filter and sort by match score
        if mode == MODE_FUZZY_SEARCH and search_buffer:
            filtered_tasks = []
            archived_task_ids = set()

            # Search active tasks
            for task in tasks_to_display:
                is_match, score, positions = fuzzy_match(search_buffer, task.get('text', ''))
                if is_match:
                    filtered_tasks.append((task, score, positions))

            # Also search archived tasks if enabled
            if include_archived_in_search:
                for task in task_manager.archived:
                    is_match, score, positions = fuzzy_match(search_buffer, task.get('text', ''))
                    if is_match:
                        filtered_tasks.append((task, score, positions))
                        archived_task_ids.add(task['id'])

            # Sort by score (highest first)
            filtered_tasks.sort(key=lambda x: x[1], reverse=True)
            # Extract just the tasks for display
            tasks_to_display = [t[0] for t in filtered_tasks]
            # Set first task as current if available
            if filtered_tasks:
                task_manager.set_current(filtered_tasks[0][0]['id'])
        elif mode == MODE_FUZZY_SEARCH:
            # Fuzzy search mode but no search buffer yet - clear archived tracking
            archived_task_ids = set()

        # Display tasks with current mode, project name, and category
        if mode == MODE_ALL_CATEGORIES:
            # All categories view - display tasks from all categories grouped
            all_cat_data = command_handler.collect_all_category_tasks(
                task_manager.project_dir if not task_manager.is_global else Path.cwd(),
                show_archived=show_archived,
            )

            # Simple display for all categories
            CYAN = '\033[96m'
            BOLD = '\033[1m'
            RESET = '\033[0m'
            DIM = '\033[2m'

            print(f"\n{CYAN}{BOLD}ALL CATEGORIES VIEW{RESET}")
            print("-" * 50)

            cat_config = CategoryConfig(project_dir=task_manager.project_dir)
            task_num = 1
            total_tasks = 0

            for cat_name, is_global, tasks, archived in all_cat_data:
                # Count tasks
                display_tasks_list = tasks + (archived if show_archived else [])
                if not display_tasks_list:
                    continue

                total_tasks += len(display_tasks_list)

                # Category header
                cat_color = cat_config.get_color(cat_name, for_global=is_global)
                global_indicator = (
                    f" {DIM}[global]{RESET}" if is_global else f" {DIM}[local]{RESET}"
                )
                print(
                    f"\n{cat_color}{BOLD}[{cat_name}]{RESET}{global_indicator} ({len(display_tasks_list)} tasks)"
                )

                # Display tasks
                for task in display_tasks_list:
                    status = "✓" if task.get('done', False) else " "
                    is_current = task.get('current', False)
                    marker = "→" if is_current else " "
                    print(f"  {marker} [{status}] {task_num}. {task.get('text', '')}")
                    task_num += 1

            print(f"\n{DIM}Total: {total_tasks} tasks across {len(all_cat_data)} categories{RESET}")
            print("-" * 50)
            print(f"{CYAN}Press Shift+L or ESC to return to single category view{RESET}")
        else:
            display_tasks(
                tasks_to_display,
                mode,
                input_buffer,
                project_name,
                category=task_manager.category,
                is_global=task_manager.is_global,
                show_archived=show_archived,
                archived_tasks=task_manager.archived,
                selected_tasks=selected_tasks,
                search_buffer=search_buffer,
                archived_task_ids=archived_task_ids,
                include_archived_in_search=include_archived_in_search,
                show_shortcuts=show_shortcuts,
                show_notes_inline=show_notes_inline,
            )

        try:
            key = get_key()

            # Auto-refresh: check if file was modified externally
            if key is None:
                # Timeout occurred, check if file changed
                if task_manager.storage_file.exists():
                    current_mtime = os.path.getmtime(task_manager.storage_file)
                    if current_mtime != last_mtime:
                        # File changed externally, reload tasks
                        task_manager._load_tasks()
                        last_mtime = current_mtime
                continue  # Redraw screen with updated tasks

            # Handle paste events (before processing individual keys)
            if isinstance(key, tuple) and key[0] == 'PASTE':
                pasted_text = key[1]
                if mode == MODE_QUICK_ADD:
                    # Add all pasted text to input buffer at once
                    # Filter out any newlines/returns to prevent accidental submission
                    pasted_text = pasted_text.replace('\r', '').replace('\n', '')
                    input_buffer += pasted_text
                continue  # Redraw with updated buffer

            if mode == MODE_QUICK_ADD:
                # Quick-add mode: direct text input
                if key == '\r' or key == '\n':  # Enter
                    if input_buffer.strip():
                        task_manager.add_task(input_buffer.strip())
                        input_buffer = ""
                    else:
                        # No text: increment tally on current task
                        tally_count = task_manager.increment_tally()
                        if tally_count:
                            # Brief visual feedback
                            CYAN = '\033[96m'
                            RESET = '\033[0m'
                            print(f"\n{CYAN}✓ Tally: ×{tally_count}{RESET}")

                            time.sleep(0.3)  # Brief pause to show message
                elif key == '\x1b':  # ESC
                    mode = MODE_COMMAND
                    input_buffer = ""
                elif key == '\x7f':  # Backspace/Delete
                    input_buffer = input_buffer[:-1]
                # Quick shortcuts in quick-add mode (must be before printable char handler)
                elif key == 'C':  # Shift+C: Switch category
                    result = command_handler.switch_category()
                    if isinstance(result, tuple) and result[0] == 'switch_category':
                        # Reload task manager with new category
                        _, new_category, new_is_global = result
                        if new_is_global:
                            task_manager = TaskManager(
                                category=new_category,
                                is_global=True,
                                project_registry=registry,
                            )
                        else:
                            task_manager = TaskManager(
                                directory=target_dir,
                                category=new_category,
                                is_global=False,
                                project_registry=registry,
                            )
                        command_handler = CommandHandler(task_manager, registry)
                        print(f"✓ Switched to category: {new_category or 'default'}")
                        print("\nPress Enter to continue...", end='', flush=True)
                        input()  # Wait for user acknowledgment
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'R':  # Shift+R: Register current project
                    command_handler.register_current_project()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'Z':  # Shift+Z: Switch project
                    result = command_handler.switch_project()
                    if isinstance(result, tuple) and result[0] == 'switch_project':
                        # Reload task manager with new project
                        _, project_name, project_path = result
                        target_dir = project_path
                        task_manager = TaskManager(
                            directory=target_dir,
                            category=None,
                            is_global=False,
                            project_registry=registry,
                        )
                        command_handler = CommandHandler(task_manager, registry)
                        print(f"✓ Switched to project: {project_name}")
                        print("\nPress Enter to continue...", end='', flush=True)
                        input()  # Wait for user acknowledgment
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'L':  # Shift+L: Toggle all categories view
                    should_toggle, new_mode = command_handler.toggle_all_categories_view(mode)
                    if should_toggle:
                        mode = new_mode
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'M':  # Shift+M: Move to project
                    command_handler.move_task_to_project()
                    input_buffer = ""  # Clear buffer after operation
                elif key == '\x0b':  # Ctrl+K: Copy to project
                    command_handler.copy_task_to_project()
                    input_buffer = ""  # Clear buffer after operation
                elif key == '=':  # =: Sort by priority
                    task_manager.sort_by_priority()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'T':  # Shift+T: Transfer to category
                    command_handler.transfer_task_to_category()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'S':  # Shift+S: Web search
                    command_handler.web_search()
                    input_buffer = ""  # Clear buffer after operation
                elif key == '\x13':  # Ctrl+S: Sync subtasks from notes
                    command_handler.sync_subtasks()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'D':  # Shift+D: Delete current task
                    command_handler.delete_current()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'W':  # Shift+W: Assign day
                    command_handler.assign_day()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'P':  # Shift+P: Set priority
                    command_handler.set_priority()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'H':  # Shift+H: Set priority to high (quick shortcut)
                    command_handler.set_priority_high()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'X':  # Shift+X: Set status
                    command_handler.set_status()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'G':  # Shift+G: Export to Google Calendar
                    command_handler.export_to_gcal()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'I':  # Shift+I: Import from Google Calendar
                    command_handler.import_from_gcal()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'K':  # Shift+K: Copy to clipboard
                    command_handler.copy_to_clipboard()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'E':  # Shift+E: Execute keyword action
                    command_handler.trigger_keyword_action()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'N':  # Shift+N: Edit task notes
                    command_handler.edit_task_notes()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'U':  # Shift+U: Open URLs
                    command_handler.open_url()
                    input_buffer = ""  # Clear buffer after operation
                elif key == '(':  # Shift+9: Ultrathink (analyze with Claude)
                    command_handler.ultrathink_task()
                    input_buffer = ""  # Clear buffer after operation
                elif key == ')':  # Shift+0: Execute analysis with Claude
                    command_handler.execute_analysis_task()
                    input_buffer = ""  # Clear buffer after operation
                elif key == '$':  # Shift+4: AI task suggestion
                    command_handler.suggest_task()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'J':  # Shift+J: Mark as agent task
                    command_handler.set_agent_task()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'B':  # Shift+B: Start priority timer
                    command_handler.start_priority_timer()
                    input_buffer = ""  # Clear buffer after operation
                elif key == '!':  # Shift+1: Fix duplicate IDs
                    command_handler.fix_duplicate_ids_interactive()
                    input_buffer = ""  # Clear buffer after operation
                elif key == '@':  # Shift+2: Read tasks aloud (TTS)
                    command_handler.read_tasks_aloud()
                    input_buffer = ""  # Clear buffer after operation
                elif key == '#':  # Shift+3: Re-authenticate Google Calendar
                    command_handler.reauthenticate_google_calendar()
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'A':  # Shift+A: Toggle archived display
                    show_archived = not show_archived
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    status_msg = "Showing" if show_archived else "Hiding"
                    print(f"\n{CYAN}✓ {status_msg} archived tasks{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'O':  # Shift+O: Toggle day sorting
                    sort_by_day = not sort_by_day
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    status_msg = "Sorting by day" if sort_by_day else "Normal order"
                    print(f"\n{CYAN}✓ {status_msg}{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                    input_buffer = ""  # Clear buffer after operation
                elif key == 'Y':  # Shift+Y: Toggle today filter
                    show_today_only = not show_today_only
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    today = get_today_day_name()
                    status_msg = (
                        f"Showing only {today} tasks" if show_today_only else "Showing all tasks"
                    )
                    print(f"\n{CYAN}✓ {status_msg}{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                    input_buffer = ""  # Clear buffer after operation
                # Note: Shift+R is now used for "Register current project" (earlier in the code)
                # Refresh is available via command mode 'r' (ESC then r)
                elif key == 'V':  # Shift+V: Enter multi-select mode
                    mode = MODE_MULTISELECT
                    selected_tasks.clear()  # Clear any previous selections
                    input_buffer = ""  # Clear buffer when switching modes
                elif key == '/':  # /: Enter fuzzy search mode
                    mode = MODE_FUZZY_SEARCH
                    search_buffer = ""  # Initialize search buffer
                    filtered_tasks = []  # Will be populated on first keystroke
                    input_buffer = ""  # Clear buffer when switching modes
                elif key == 'Q':  # Shift+Q: Quit
                    print("\n\nGoodbye!")
                    running = False
                elif key == 'F':  # Shift+F: Toggle inline notes display
                    show_notes_inline = not show_notes_inline
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    status_msg = "Showing" if show_notes_inline else "Hiding"
                    print(f"\n{CYAN}✓ {status_msg} inline notes{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                    input_buffer = ""  # Clear buffer after operation
                elif key == '?':  # ?: Toggle shortcuts display
                    show_shortcuts = not show_shortcuts
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    status_msg = "Showing" if show_shortcuts else "Hiding"
                    print(f"\n{CYAN}✓ {status_msg} shortcuts{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                    input_buffer = ""  # Clear buffer after operation
                # Allow navigation in quick-add mode
                elif key == 'UP':
                    task_manager.set_prev_current(tasks_to_display if show_today_only else None)
                elif key == 'DOWN':
                    task_manager.set_next_current(tasks_to_display if show_today_only else None)
                elif key == 'SHIFT_UP':
                    task_manager.move_task_up()
                elif key == 'SHIFT_DOWN':
                    task_manager.move_task_down()
                # Printable characters add to input buffer (must be last)
                elif len(key) == 1 and key.isprintable():
                    input_buffer += key

            elif mode == MODE_MULTISELECT:
                # Multi-select mode: selection and bulk operations
                if key == '\x1b':  # ESC - Exit multi-select mode
                    mode = MODE_QUICK_ADD
                    selected_tasks.clear()
                elif key == ' ':  # Space - Toggle selection of current task
                    current_task = task_manager.get_current_task()
                    if current_task:
                        task_id = current_task['id']
                        if task_id in selected_tasks:
                            selected_tasks.remove(task_id)
                        else:
                            selected_tasks.add(task_id)
                elif key == 'A':  # Shift+A - Select all
                    for task in task_manager.tasks:
                        selected_tasks.add(task['id'])
                elif key == 'N':  # Shift+N - Select none
                    selected_tasks.clear()
                elif key == 'UP':
                    task_manager.set_prev_current(tasks_to_display if show_today_only else None)
                elif key == 'DOWN':
                    task_manager.set_next_current(tasks_to_display if show_today_only else None)
                elif key == 'SHIFT_UP':
                    # Navigate up and select
                    task_manager.set_prev_current(tasks_to_display if show_today_only else None)
                    current_task = task_manager.get_current_task()
                    if current_task:
                        selected_tasks.add(current_task['id'])
                elif key == 'SHIFT_DOWN':
                    # Navigate down and select
                    task_manager.set_next_current(tasks_to_display if show_today_only else None)
                    current_task = task_manager.get_current_task()
                    if current_task:
                        selected_tasks.add(current_task['id'])
                elif key == 'B':  # Shift+B - Bulk actions menu
                    if selected_tasks:
                        action = command_handler.bulk_actions_menu(selected_tasks)

                        if action == 'priority':
                            command_handler.bulk_set_priority(selected_tasks)
                            selected_tasks.clear()  # Clear selection after operation
                        elif action == 'status':
                            command_handler.bulk_set_status(selected_tasks)
                            selected_tasks.clear()
                        elif action == 'delete':
                            command_handler.bulk_delete(selected_tasks)
                            selected_tasks.clear()
                        elif action == 'archive':
                            command_handler.bulk_archive(selected_tasks)
                            selected_tasks.clear()
                        # If action is 'cancel' or None, do nothing (keep selections)

            elif mode == MODE_FUZZY_SEARCH:
                # Fuzzy search mode: filter tasks and navigate results
                if key == '\x1b':  # ESC - Exit without selecting
                    mode = MODE_QUICK_ADD
                    search_buffer = ""
                elif key == '\r' or key == '\n':  # Enter - Select current and exit
                    current_task = task_manager.get_current_task()
                    if current_task:
                        # Already set as current, just exit mode
                        mode = MODE_QUICK_ADD
                        search_buffer = ""
                elif key == '\x7f':  # Backspace/Delete
                    if search_buffer:
                        search_buffer = search_buffer[:-1]
                        # Filtering will be handled by main loop on next iteration
                elif key == '\x01':  # Ctrl+A - Toggle archived tasks in search
                    include_archived_in_search = not include_archived_in_search
                    # Re-filter with new setting will happen on next loop iteration
                elif key == 'UP':
                    # Navigate to previous task in filtered results
                    if filtered_tasks:
                        current_task = task_manager.get_current_task()
                        if current_task:
                            current_id = current_task['id']
                            # Find current in filtered list
                            filtered_ids = [t[0]['id'] for t in filtered_tasks]
                            if current_id in filtered_ids:
                                current_idx = filtered_ids.index(current_id)
                                if current_idx > 0:
                                    prev_task = filtered_tasks[current_idx - 1][0]
                                    task_manager.set_current(prev_task['id'])
                elif key == 'DOWN':
                    # Navigate to next task in filtered results
                    if filtered_tasks:
                        current_task = task_manager.get_current_task()
                        if current_task:
                            current_id = current_task['id']
                            # Find current in filtered list
                            filtered_ids = [t[0]['id'] for t in filtered_tasks]
                            if current_id in filtered_ids:
                                current_idx = filtered_ids.index(current_id)
                                if current_idx < len(filtered_tasks) - 1:
                                    next_task = filtered_tasks[current_idx + 1][0]
                                    task_manager.set_current(next_task['id'])
                # Printable characters add to search buffer
                elif len(key) == 1 and key.isprintable():
                    search_buffer += key
                    # Filtering will be handled by main loop on next iteration

            elif mode == MODE_ALL_CATEGORIES:
                # All categories view mode: minimal key handling
                if key == '\x1b' or key == 'L':  # ESC or Shift+L - Exit all categories view
                    mode = MODE_QUICK_ADD
                elif key == 'UP':
                    task_manager.set_prev_current(tasks_to_display if show_today_only else None)
                elif key == 'DOWN':
                    task_manager.set_next_current(tasks_to_display if show_today_only else None)
                # Most other keys ignored in this read-only view

            else:  # MODE_COMMAND
                # Command mode: existing command system
                if key == 'a':
                    # Switch to quick-add mode
                    mode = MODE_QUICK_ADD
                    input_buffer = ""
                elif key == 'UP':
                    task_manager.set_prev_current(tasks_to_display if show_today_only else None)
                elif key == 'DOWN':
                    task_manager.set_next_current(tasks_to_display if show_today_only else None)
                elif key == 'SHIFT_UP':
                    task_manager.move_task_up()
                elif key == 'SHIFT_DOWN':
                    task_manager.move_task_down()
                elif key == '\r' or key == '\n':
                    # Enter key in command mode: increment tally on current task
                    tally_count = task_manager.increment_tally()
                    if tally_count:
                        # Brief visual feedback
                        CYAN = '\033[96m'
                        RESET = '\033[0m'
                        print(f"\n{CYAN}✓ Tally: ×{tally_count}{RESET}")

                        time.sleep(0.3)  # Brief pause to show message
                elif key == 'A':  # Shift+A: Toggle archived display
                    show_archived = not show_archived
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    status_msg = "Showing" if show_archived else "Hiding"
                    print(f"\n{CYAN}✓ {status_msg} archived tasks{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                elif key == 'O':  # Shift+O: Toggle day sorting
                    sort_by_day = not sort_by_day
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    status_msg = "Sorting by day" if sort_by_day else "Normal order"
                    print(f"\n{CYAN}✓ {status_msg}{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                elif key == 'Y':  # Shift+Y: Toggle today filter
                    show_today_only = not show_today_only
                    CYAN = '\033[96m'
                    RESET = '\033[0m'
                    today = get_today_day_name()
                    status_msg = (
                        f"Showing only {today} tasks" if show_today_only else "Showing all tasks"
                    )
                    print(f"\n{CYAN}✓ {status_msg}{RESET}")

                    time.sleep(0.3)  # Brief pause to show message
                elif key:
                    running = command_handler.handle(key)

        except (KeyboardInterrupt, EOFError):
            print("\n\nGoodbye!")
            break


if __name__ == '__main__':
    main()
