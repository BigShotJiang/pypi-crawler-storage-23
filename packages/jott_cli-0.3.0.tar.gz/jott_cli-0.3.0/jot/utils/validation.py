"""Validation utilities for jot"""

import os
import re


def validate_safe_name(name, name_type="name"):
    """
    Validate category/project names for path traversal attacks.

    Security: Prevents directory traversal attacks by rejecting:
    - Path separators (/, \\)
    - Parent directory references (..)
    - Absolute paths
    - Non-alphanumeric characters (except dash and underscore)

    Args:
        name: Name to validate (category, project, etc.)
        name_type: Type of name for error messages (default: "name")

    Returns:
        str: Validated name (unchanged if valid)

    Raises:
        ValueError: If name contains dangerous characters or patterns

    Examples:
        >>> validate_safe_name("my-project")
        'my-project'
        >>> validate_safe_name("../etc/passwd")
        ValueError: Invalid name: ../etc/passwd (no path separators allowed)
    """
    if not name or not isinstance(name, str):
        raise ValueError(f"Invalid {name_type}: must be a non-empty string")

    # Reject path traversal attempts
    if '/' in name or '\\' in name:
        raise ValueError(f"Invalid {name_type}: {name} (no path separators allowed)")

    # Reject parent directory references
    if '..' in name:
        raise ValueError(f"Invalid {name_type}: {name} (no parent directory references allowed)")

    # Reject absolute paths
    if os.path.isabs(name):
        raise ValueError(f"Invalid {name_type}: {name} (absolute paths not allowed)")

    # Only allow alphanumeric, dash, underscore, dot
    if not re.match(r'^[a-zA-Z0-9_.-]+$', name):
        raise ValueError(
            f"Invalid {name_type}: {name} (only alphanumeric, dash, underscore, and dot allowed)"
        )

    # Reject names starting with dot (hidden files) except special cases
    if name.startswith('.') and name not in ['.jot', '.jot.json']:
        raise ValueError(f"Invalid {name_type}: {name} (names cannot start with dot)")

    return name
