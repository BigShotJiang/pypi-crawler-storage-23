"""Date and time utility functions for jot"""

from datetime import datetime, timedelta


def get_today_day_name():
    """Get the current day of the week

    Returns:
        str: Full day name like "Monday"
    """
    return datetime.now().strftime('%A')


def sort_tasks_by_day(tasks):
    """Sort tasks by day of week (Sunday-Saturday)

    Args:
        tasks: List of task dictionaries

    Returns:
        Sorted list: tasks with days (Sun-Sat order) + tasks without days
    """
    days_order = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    day_index = {day: i for i, day in enumerate(days_order)}

    # Separate tasks with and without days
    with_day = [t for t in tasks if t.get('day')]
    without_day = [t for t in tasks if not t.get('day')]

    # Sort tasks with days by day order
    with_day.sort(key=lambda t: day_index.get(t.get('day'), 999))

    # Return: tasks with day (sorted Sun-Sat) + tasks without day
    return with_day + without_day


def filter_today_tasks(tasks, today):
    """Filter tasks to only show those assigned to today

    Args:
        tasks: List of task dictionaries
        today: String name of today's day (e.g., "Monday")

    Returns:
        List of tasks assigned to today
    """
    return [t for t in tasks if t.get('day') == today]


def round_to_15_minutes(dt):
    """Round datetime to nearest 15 minutes

    Args:
        dt: datetime object

    Returns:
        datetime rounded to nearest 15 minutes
    """
    minute = dt.minute
    # Round to nearest 15: 0, 15, 30, 45
    rounded_minute = round(minute / 15) * 15

    if rounded_minute == 60:
        # Roll over to next hour
        dt = dt.replace(minute=0, second=0, microsecond=0)
        dt = dt + timedelta(hours=1)
    else:
        dt = dt.replace(minute=rounded_minute, second=0, microsecond=0)

    return dt
