"""Keyword detection and action routing for task automation"""

import json
import platform
import subprocess
from datetime import datetime
from pathlib import Path

# Import availability flag
from jot.core.constants import GCAL_AVAILABLE

# Conditionally import Google Calendar dependencies
if GCAL_AVAILABLE:
    from jot.integrations.gcal.account_manager import GoogleCalendarAccountManager
    from jot.integrations.gcal.auth import GoogleCalendarAuth
    from jot.integrations.gcal.events import create_gcal_event


class KeywordHandler:
    """Manages keyword detection and action routing for task automation"""

    MAX_KEYWORD_LENGTH = 50  # Security: Prevent excessively long keywords

    def __init__(self, project_registry=None):
        """Initialize keyword handler with built-in handlers

        Args:
            project_registry: Optional ProjectRegistry instance for project name routing
        """
        self.handlers = {}  # keyword -> handler function
        self.config = {}  # keyword -> config dict
        self.aliases = {}  # alias -> keyword mapping
        self.project_registry = project_registry
        self._register_builtin_handlers()
        self._load_config()

    def extract_keyword(self, task_text):
        """
        Extract keyword from task text if present.

        Keyword format: "keyword: rest of task text"
        - First word must end with ':'
        - Keyword must be alphanumeric + hyphens/underscores
        - Case-insensitive (normalized to lowercase)
        - Project names are checked first before treating as action keyword

        Args:
            task_text: Full task text

        Returns:
            tuple: (keyword, original_text, project_name) or (None, original_text, None)
                   keyword is lowercase or None
                   original_text is unchanged (keeps "keyword: text" format)
                   project_name is the matched project name or None

        Examples:
            "gcal: Team meeting" -> ("gcal", "gcal: Team meeting", None)
            "bullet: Focus session" -> ("bullet", "bullet: Focus session", None)
            "jot: Fix bug" -> (None, "Fix bug", "jot")  # If "jot" is registered project
            "Regular task" -> (None, "Regular task", None)
            "@invalid: task" -> (None, "@invalid: task", None)
        """
        if ':' not in task_text:
            return None, task_text, None

        # Split on first colon only
        parts = task_text.split(':', 1)
        if len(parts) != 2:
            return None, task_text, None

        first_word = parts[0].strip()

        # Validate keyword length (security: prevent DOS via very long keywords)
        if len(first_word) > self.MAX_KEYWORD_LENGTH:
            return None, task_text, None

        # Validate keyword: alphanumeric + hyphens/underscores only
        # This prevents @mentions, #hashtags, etc. from being treated as keywords
        if first_word and first_word.replace('-', '').replace('_', '').isalnum():
            # Valid keyword format - check if it's a project name first
            keyword_lower = first_word.lower()

            # Check for "all" keyword - broadcast to all registered projects
            if keyword_lower == 'all':
                task_text_without_prefix = parts[1].strip()
                return None, task_text_without_prefix, "__all__"

            # Check if this keyword matches a registered project name
            if self.project_registry:
                registered_projects = self.project_registry.list_projects()
                # Case-insensitive project name matching
                for project_name in registered_projects.keys():
                    if project_name.lower() == keyword_lower:
                        # This is a project name, not an action keyword
                        # Return the task text WITHOUT the project prefix
                        task_text_without_prefix = parts[1].strip()
                        return None, task_text_without_prefix, project_name

            # Not a project name - treat as action keyword
            return keyword_lower, task_text, None  # Return original text unchanged
        else:
            # Invalid keyword format
            return None, task_text, None

    def register(self, keyword, handler_func, auto_trigger=False, description=""):
        """
        Register a keyword action handler.

        Args:
            keyword: Keyword string (will be normalized to lowercase)
            handler_func: Callable that takes (task_dict) and returns result message
            auto_trigger: Whether to auto-execute when task is created
            description: Human-readable description of what this keyword does
        """
        keyword = keyword.lower()
        self.handlers[keyword] = handler_func
        self.config[keyword] = {'auto_trigger': auto_trigger, 'description': description}

    def handle(self, keyword, task):
        """
        Execute handler for detected keyword.

        Args:
            keyword: Keyword to execute (may be an alias)
            task: Task dictionary

        Returns:
            str: Result message from handler, or None if keyword not registered
        """
        # Resolve alias if present
        actual_keyword = keyword
        if hasattr(self, 'aliases') and keyword in self.aliases:
            actual_keyword = self.aliases[keyword]

        if actual_keyword in self.handlers:
            try:
                return self.handlers[actual_keyword](task)
            except Exception as e:
                return f"Error executing {keyword}: {str(e)}"
        else:
            # Unknown keyword - no action, no warning (per user preference)
            return None

    def get_config(self, keyword):
        """Get configuration for a keyword"""
        return self.config.get(keyword.lower())

    def list_keywords(self):
        """List all registered keywords with their configurations"""
        return {k: v for k, v in self.config.items()}

    def _load_config(self):
        """Load user configuration from ~/.jot-keywords.json"""

        config_file = Path.home() / '.jot-keywords.json'

        if not config_file.exists():
            # Create default config on first run
            self._create_default_config(config_file)
            return

        try:
            with open(config_file, 'r') as f:
                user_config = json.load(f)

            # Update config from file
            keywords = user_config.get('keywords', {})
            for keyword, settings in keywords.items():
                if keyword.lower() in self.config:
                    # Update existing keyword config
                    self.config[keyword.lower()].update(settings)
                # Note: Don't register unknown keywords from config
                # They'll be stored silently but won't have handlers

            # Load aliases
            self.aliases = user_config.get('aliases', {})

        except (json.JSONDecodeError, IOError) as e:
            print(f"Warning: Failed to load keyword config: {e}")

    def _create_default_config(self, config_file):
        """Create default keyword configuration file"""

        default_config = {
            "_comment": "Jot Keyword Configuration - See README.org for full documentation",
            "_note": "This file configures EXISTING keywords only. To add NEW keywords, you must edit jot.py",
            "keywords": {
                "bullet": {"auto_trigger": True, "description": "Start bullet priority timer"},
                "gcal": {"auto_trigger": True, "description": "Export task to Google Calendar"},
                "ai": {"auto_trigger": True, "description": "Mark task for AI/agent assistance"},
                "remind": {
                    "auto_trigger": False,
                    "description": "Set system notification (manual trigger with Shift+E)",
                },
                "analyze": {
                    "auto_trigger": True,
                    "description": "Analyze task with Claude Code AI (creates .jot.analysis.{id}.org file)",
                },
            },
            "aliases": {
                "_comment": "Aliases create shortcuts to existing keywords (e.g., 'timer:' -> 'bullet:')",
                "timer": "bullet",
                "cal": "gcal",
                "claude": "ai",
            },
            "_usage": {
                "auto_trigger": "Set to true to execute keyword action automatically when task is created",
                "aliases": "Map shortcut names to existing keywords for convenience",
                "custom_keywords": "To add custom keywords, edit jot.py and add a handler function - see README.org",
            },
        }

        try:
            with open(config_file, 'w') as f:
                json.dump(default_config, f, indent=2)
        except IOError as e:
            print(f"Warning: Failed to create keyword config: {e}")

    def _register_builtin_handlers(self):
        """Register built-in keyword handlers"""
        self.register(
            'bullet',
            self._handle_bullet,
            auto_trigger=True,
            description="Start bullet priority timer",
        )

        self.register(
            'gcal', self._handle_gcal, auto_trigger=True, description="Export to Google Calendar"
        )

        self.register('ai', self._handle_ai, auto_trigger=True, description="Mark as AI/agent task")

        self.register(
            'remind', self._handle_remind, auto_trigger=False, description="Set system notification"
        )

        self.register(
            'analyze',
            self._handle_analyze,
            auto_trigger=True,
            description="Analyze task with Claude Code AI",
        )

    def _handle_bullet(self, task):
        """Start bullet priority timer automatically"""

        try:
            subprocess.Popen(
                ['bullet', 'priority'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
            return "Started bullet priority timer"
        except FileNotFoundError:
            return "bullet command not found (install: cd ~/projects/bullet && npm link)"

    def _handle_gcal(self, task):
        """Export task to Google Calendar automatically"""
        if not GCAL_AVAILABLE:
            return "Google Calendar API not available (install google-auth packages)"

        try:
            # Use GoogleCalendarAccountManager to discover accounts
            account_manager = GoogleCalendarAccountManager()
            accounts = account_manager.discover_accounts()

            if not accounts:
                return "No Google Calendar accounts configured (use Shift+G to set up)"

            # Use first available account
            account_name = accounts[0]

            # Initialize auth and get service
            auth = GoogleCalendarAuth(account_name)
            service = auth.get_service()

            # Create event
            create_gcal_event(service, task['text'])

            return f"Created Google Calendar event ({account_name})"

        except FileNotFoundError:
            return "Google Calendar credentials not found (use Shift+G to set up)"
        except Exception as e:
            return f"Failed to create calendar event: {str(e)}"

    def _handle_ai(self, task):
        """Mark task as AI/agent task"""
        task['agent_task'] = True
        return "Marked as AI/agent task"

    def _handle_remind(self, task):
        """Set system notification (macOS)"""

        if platform.system() != 'Darwin':
            return "Reminders only supported on macOS"

        try:
            # Use JSON escaping for robust string handling (prevents injection)
            # json.dumps() properly escapes quotes, backslashes, newlines, etc.
            task_text_safe = json.dumps(task['text'])[1:-1]  # Remove surrounding quotes

            script = f'''
                display notification "{task_text_safe}" with title "Jot Reminder" sound name "Ping"
            '''

            subprocess.run(
                ['osascript', '-e', script],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=True,
            )

            return "System notification displayed"

        except subprocess.CalledProcessError:
            return "Failed to display notification"
        except Exception as e:
            return f"Notification error: {str(e)}"

    def _handle_analyze(self, task):
        """Analyze task with Claude Code in planning mode"""

        # Remove keyword prefix from task text
        task_text = task['text']
        if task_text.lower().startswith('analyze:'):
            task_text = task_text[8:].strip()

        # Get task notes if they exist
        notes = task.get('notes', '')
        notes_section = f"\n\nTask Notes:\n{notes}" if notes else ""

        # Build analysis prompt
        prompt = f"""Analyze this task and provide a structured implementation plan in org-mode format.

Task: {task_text}{notes_section}

Please create an org-mode document with the following sections:

* Task Analysis
** Overview
Brief description of what needs to be done

** Task Breakdown
- [ ] Subtask 1
- [ ] Subtask 2
- [ ] Subtask 3

** Technical Approach
Key technical decisions and implementation strategy

** Acceptance Criteria
- Criterion 1
- Criterion 2
- Criterion 3

** Complexity Estimate
Simple / Medium / Complex (with justification)

** Potential Risks
Any challenges or unknowns to consider

Format the entire response as a well-structured org-mode document."""

        try:
            # Check if claude CLI is available
            check_result = subprocess.run(['claude', '--version'], capture_output=True, timeout=5)

            if check_result.returncode != 0:
                return "⚠️ Claude CLI not found. Install: https://claude.com/claude-code"

        except (FileNotFoundError, subprocess.TimeoutExpired):
            return "⚠️ Claude CLI not found. Install: https://claude.com/claude-code"

        try:
            # Invoke Claude in plan mode with JSON output
            result = subprocess.run(
                [
                    'claude',
                    '--print',
                    '--permission-mode',
                    'plan',
                    '--output-format',
                    'json',
                    '--max-turns',
                    '5',
                ],
                input=prompt,
                capture_output=True,
                text=True,
                timeout=120,  # 2 minute timeout
            )

            if result.returncode != 0:
                # Check for common errors
                stderr_lower = result.stderr.lower()

                if 'authentication' in stderr_lower or 'login' in stderr_lower:
                    return "⚠️ Claude auth expired. Run: claude login"
                elif 'network' in stderr_lower or 'connection' in stderr_lower:
                    return "⚠️ Network error. Check connection and try again"
                else:
                    # Return first 100 chars of error
                    error_msg = result.stderr[:100] if result.stderr else "Unknown error"
                    return f"⚠️ Claude failed: {error_msg}"

            # Parse JSON response
            try:
                response = json.loads(result.stdout)
                analysis_text = response.get('result', '')

                if not analysis_text:
                    return "⚠️ Empty response from Claude"

            except json.JSONDecodeError:
                return "⚠️ Failed to parse Claude response"

            # Save to .jot.analysis.{id}.org file

            output_file = Path.cwd() / f".jot.analysis.{task['id']}.org"

            try:
                with open(output_file, 'w') as f:
                    f.write(f"#+TITLE: Analysis for Task {task['id']}\n")
                    f.write(f"#+DATE: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
                    f.write(f"#+TASK: {task_text}\n\n")
                    f.write(analysis_text)

                # Store analysis file reference in task
                task['analysis_file'] = str(output_file)

                # Get cost from response if available
                cost = response.get('total_cost_usd', 0)
                cost_str = f" (${cost:.3f})" if cost > 0 else ""

                return f"✓ Analysis saved to {output_file.name}{cost_str}"

            except IOError as e:
                return f"⚠️ Failed to save analysis: {str(e)}"

        except subprocess.TimeoutExpired:
            return "⚠️ Analysis timed out (120s). Task may be too complex or network slow"
        except Exception as e:
            return f"⚠️ Analysis error: {str(e)}"
