"""Google Calendar OAuth authentication"""

import os
import shutil
from pathlib import Path

# Check for Google Calendar API availability
try:
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build

    GCAL_AVAILABLE = True
except ImportError:
    GCAL_AVAILABLE = False

from jot.integrations.gcal.account_manager import GoogleCalendarAccountManager


class GoogleCalendarAuth:
    """Handle Google Calendar OAuth authentication"""

    SCOPES = ['https://www.googleapis.com/auth/calendar']

    def __init__(self, account_name='default'):
        """Initialize with account-specific credentials directory

        Args:
            account_name: Name of the Google Calendar account (default: 'default')
        """
        self.account_name = account_name
        account_manager = GoogleCalendarAccountManager()

        # Check for legacy credentials and migrate if needed
        self._migrate_legacy_credentials_if_needed(account_manager)

        # Use account-specific directory
        self.creds_dir = account_manager.get_account_path(account_name)
        self.creds_file = self.creds_dir / 'credentials.json'
        self.token_file = self.creds_dir / 'token.json'

        # Ensure directory exists
        self.creds_dir.mkdir(parents=True, exist_ok=True)

    def _migrate_legacy_credentials_if_needed(self, account_manager):
        """Migrate legacy single-account credentials to new multi-account structure

        Args:
            account_manager: GoogleCalendarAccountManager instance
        """
        # Only migrate if using 'default' account and legacy files exist
        if self.account_name != 'default':
            return

        legacy_dir = Path.home() / '.jot'
        legacy_creds = legacy_dir / 'credentials.json'
        legacy_token = legacy_dir / 'token.json'

        # Check if legacy files exist and haven't been migrated yet
        default_account_path = account_manager.get_account_path('default')
        if (legacy_creds.exists() or legacy_token.exists()) and not account_manager.account_exists(
            'default'
        ):
            # Create default account directory
            account_manager.create_account('default')

            # Migrate credentials.json if it exists
            if legacy_creds.exists():
                shutil.copy2(legacy_creds, default_account_path / 'credentials.json')

            # Migrate token.json if it exists
            if legacy_token.exists():
                shutil.copy2(legacy_token, default_account_path / 'token.json')

            print(f"\n✓ Migrated legacy Google Calendar credentials to 'default' account")
            print(f"  Location: {default_account_path}\n")

    def get_credentials(self):
        """Get or refresh OAuth credentials

        Returns:
            Credentials object

        Raises:
            FileNotFoundError: If credentials.json not found
        """
        if not GCAL_AVAILABLE:
            raise ImportError(
                "Google Calendar API libraries not installed. "
                "Run: pip install google-auth google-auth-oauthlib "
                "google-auth-httplib2 google-api-python-client"
            )

        if not self.creds_file.exists():
            raise FileNotFoundError(
                f"Credentials file not found: {self.creds_file}\n"
                "Please download credentials.json from Google Cloud Console:\n"
                "https://developers.google.com/workspace/calendar/api/quickstart/python"
            )

        creds = None

        # Load token if it exists
        if self.token_file.exists():
            creds = Credentials.from_authorized_user_file(str(self.token_file), self.SCOPES)

        # If no valid credentials, authenticate
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                try:
                    # Try to refresh expired token
                    creds.refresh(Request())
                except Exception:
                    # Refresh failed (token revoked or expired)
                    # Delete invalid token and re-authenticate
                    if self.token_file.exists():
                        self.token_file.unlink()
                    print(f"\n⚠️  Token expired or revoked. Re-authenticating...")
                    # Run OAuth flow
                    flow = InstalledAppFlow.from_client_secrets_file(
                        str(self.creds_file), self.SCOPES
                    )
                    creds = flow.run_local_server(port=0)
            else:
                # Run OAuth flow
                flow = InstalledAppFlow.from_client_secrets_file(str(self.creds_file), self.SCOPES)
                creds = flow.run_local_server(port=0)

            # Save credentials for future use with restrictive permissions
            # Security: Set umask to create file with 0o600 (user read/write only)
            old_umask = os.umask(0o077)  # Temporarily restrict permissions
            try:
                with open(self.token_file, 'w') as token:
                    token.write(creds.to_json())
            finally:
                os.umask(old_umask)  # Restore original umask

            # Double-check permissions are set correctly (defensive)
            os.chmod(self.token_file, 0o600)

        return creds

    def get_service(self):
        """Build and return Google Calendar service

        Returns:
            Google Calendar API service object
        """
        creds = self.get_credentials()
        return build('calendar', 'v3', credentials=creds)
