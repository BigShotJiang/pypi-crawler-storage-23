"""Command handling for jot interactive UI"""

from jot.commands.handler import CommandHandler

__all__ = ['CommandHandler']
