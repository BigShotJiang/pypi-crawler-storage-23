"""UI formatting utilities for task display"""

import textwrap


def format_inline_notes(notes, max_lines=3, max_width=70):
    """Format task notes for inline display with truncation

    Returns a list of formatted lines ready for printing.
    """
    if not notes:
        return []

    # ANSI color codes
    GRAY = "\033[90m"
    RESET = "\033[0m"

    lines = notes.strip().split('\n')
    formatted_lines = []

    for i, line in enumerate(lines):
        if i >= max_lines:
            formatted_lines.append(f"{GRAY}    ... ({len(lines) - max_lines} more lines){RESET}")
            break

        # Wrap long lines
        if len(line) > max_width:
            wrapped = textwrap.wrap(line, width=max_width, subsequent_indent="    ")
            formatted_lines.extend([f"{GRAY}    {wrapped[0]}{RESET}"])
            if len(wrapped) > 1 and i < max_lines - 1:
                formatted_lines.extend([f"{GRAY}    {w}{RESET}" for w in wrapped[1:2]])
                if len(wrapped) > 2:
                    formatted_lines.append(f"{GRAY}    ...{RESET}")
                    break
        else:
            formatted_lines.append(f"{GRAY}    {line}{RESET}")

    return formatted_lines


def format_category_badges(category_manager, cat_config, current_category, is_global_current):
    """Format category badges for display header"""
    # ANSI color codes for background + black text
    BOLD = "\033[1m"
    RESET = "\033[0m"

    badges = []

    # Global category badge (always show if current)
    if is_global_current:
        global_cfg = cat_config.get_category('global')
        bg_color = global_cfg.get('ansi_bg_color', '\033[48;5;240m')
        badges.append(f"{bg_color}\033[30m GLOBAL {RESET}")

    # Current project category badge
    if current_category:
        cat_cfg = cat_config.get_category(current_category)
        bg_color = cat_cfg.get('ansi_bg_color', '\033[48;5;33m')
        badges.append(f"{bg_color}\033[30m {current_category.upper()} {RESET}")

    # Available categories
    available = []
    for cat_name in category_manager.get_categories():
        if cat_name != current_category and cat_name != 'global':
            cat_cfg = cat_config.get_category(cat_name)
            bg_color = cat_cfg.get('ansi_bg_color', '\033[48;5;240m')
            available.append(f"{bg_color}\033[90m {cat_name} {RESET}")

    if available:
        badges.extend(available)

    return "  ".join(badges) if badges else ""
