"""Project backup and restore functionality"""

import tarfile
from datetime import datetime
from pathlib import Path


class ProjectBackup:
    """Manages project backup and restoration"""

    def __init__(self, project_dir=None):
        """Initialize backup manager"""
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()

    def get_backup_files(self):
        """Get list of all jot files to backup"""
        files = []

        # All .jot.*.json files (categories, config, ids, archive)
        for file in self.project_dir.glob('.jot.*.json'):
            files.append(file)

        # Main .jot.json file
        main_file = self.project_dir / '.jot.json'
        if main_file.exists():
            files.append(main_file)

        return sorted(files)

    def create_backup(self, output_file=None):
        """Create a backup tarball of all jot files"""
        files_to_backup = self.get_backup_files()

        if not files_to_backup:
            return False, "No jot files found to backup"

        # Generate default filename if not provided
        if output_file is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            project_name = self.project_dir.name
            output_file = self.project_dir / f'jot-backup-{project_name}-{timestamp}.tar.gz'
        else:
            output_file = Path(output_file)

        # Create tarball
        try:
            with tarfile.open(output_file, 'w:gz') as tar:
                for file in files_to_backup:
                    # Add file with just its name (not full path)
                    tar.add(file, arcname=file.name)

            return True, f"Backup created: {output_file} ({len(files_to_backup)} files)"
        except Exception as e:
            return False, f"Backup failed: {str(e)}"

    def restore_backup(self, backup_file, force=False):
        """Restore from a backup tarball"""
        backup_path = Path(backup_file)

        if not backup_path.exists():
            return False, f"Backup file not found: {backup_file}"

        # Check for existing files
        if not force:
            existing_files = self.get_backup_files()
            if existing_files:
                return False, f"Project already has jot files. Use --force to overwrite."

        # Extract tarball
        try:
            with tarfile.open(backup_path, 'r:gz') as tar:
                # Verify all files are .jot files (security check)
                members = tar.getmembers()
                for member in members:
                    if not member.name.startswith('.jot'):
                        return False, f"Invalid backup: contains non-jot file '{member.name}'"

                # Extract to project directory
                tar.extractall(self.project_dir)

            return True, f"Restored {len(members)} files from {backup_file}"
        except Exception as e:
            return False, f"Restore failed: {str(e)}"

    def list_backup_contents(self, backup_file):
        """List contents of a backup file"""
        backup_path = Path(backup_file)

        if not backup_path.exists():
            return False, f"Backup file not found: {backup_file}"

        try:
            with tarfile.open(backup_path, 'r:gz') as tar:
                members = tar.getmembers()
                file_list = [m.name for m in members]
            return True, file_list
        except Exception as e:
            return False, f"Failed to read backup: {str(e)}"
