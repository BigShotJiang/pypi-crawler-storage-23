#!/usr/bin/env python3
"""
jot MCP Server - Model Context Protocol server for jot task management

Exposes jot task management functionality via MCP, including:
- Category management (local and global)
- Task operations (CRUD)
- Task properties (day, priority, status)
- Project context
"""

import json
import os
import sys
from pathlib import Path
from typing import Any, Optional

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

# Import jot classes
from jot import TaskManager, CategoryManager, IDManager, CategoryConfig


# Initialize MCP server
app = Server("jot")


def get_project_dir() -> Path:
    """Get current project directory with environment variable fallback

    Resolution order:
    1. JOT_PROJECT_DIR environment variable (configurable per workspace)
    2. Current working directory (Path.cwd())

    The environment variable approach allows Claude Code to specify the correct
    working directory via MCP configuration, overriding the server's launch directory.
    """
    # Check for environment variable override
    if env_dir := os.getenv('JOT_PROJECT_DIR'):
        return Path(env_dir)

    # Fall back to current working directory
    return Path.cwd()


def get_category_manager(project_dir: Optional[Path] = None) -> CategoryManager:
    """Get CategoryManager instance"""
    if project_dir is None:
        project_dir = get_project_dir()
    return CategoryManager(project_dir)


def get_task_manager(
    category: Optional[str] = None, project_dir: Optional[Path] = None
) -> TaskManager:
    """Get TaskManager instance for a category"""
    if project_dir is None:
        project_dir = get_project_dir()

    # Determine storage file based on category
    if category and category != "default":
        storage_file = f".jot.{category}.json"
    else:
        storage_file = ".jot.json"

    # Get ID manager (pass project directory, not file path)
    id_manager = IDManager(project_dir=project_dir)

    return TaskManager(
        storage_file=storage_file, project_dir=project_dir, id_manager=id_manager
    )


# =============================================================================
# MCP Tool Definitions
# =============================================================================


@app.list_tools()
async def list_tools() -> list[Tool]:
    """List available MCP tools"""
    return [
        # Category Operations
        Tool(
            name="list_categories",
            description="List all categories (local and global) in current project",
            inputSchema={
                "type": "object",
                "properties": {},
                "required": [],
            },
        ),
        Tool(
            name="get_category_info",
            description="Get detailed information about a category",
            inputSchema={
                "type": "object",
                "properties": {
                    "category": {
                        "type": "string",
                        "description": "Category name",
                    }
                },
                "required": ["category"],
            },
        ),
        Tool(
            name="create_category",
            description="Create a new category (validates against 12 category limit)",
            inputSchema={
                "type": "object",
                "properties": {
                    "category": {
                        "type": "string",
                        "description": "Category name",
                    },
                    "is_global": {
                        "type": "boolean",
                        "description": "Create as global category",
                        "default": False,
                    },
                },
                "required": ["category"],
            },
        ),
        # Task Operations
        Tool(
            name="list_tasks",
            description="List all tasks in a category",
            inputSchema={
                "type": "object",
                "properties": {
                    "category": {
                        "type": "string",
                        "description": "Category name (default: default category)",
                    }
                },
            },
        ),
        Tool(
            name="add_task",
            description="Add a new task",
            inputSchema={
                "type": "object",
                "properties": {
                    "text": {"type": "string", "description": "Task text"},
                    "category": {
                        "type": "string",
                        "description": "Category name (default: default category)",
                    },
                },
                "required": ["text"],
            },
        ),
        Tool(
            name="get_current_task",
            description="Get the current task",
            inputSchema={
                "type": "object",
                "properties": {
                    "category": {
                        "type": "string",
                        "description": "Category name (default: default category)",
                    }
                },
            },
        ),
        Tool(
            name="set_current_task",
            description="Set a task as current by ID",
            inputSchema={
                "type": "object",
                "properties": {
                    "task_id": {"type": "integer", "description": "Task ID"},
                    "category": {
                        "type": "string",
                        "description": "Category name (default: default category)",
                    },
                },
                "required": ["task_id"],
            },
        ),
        Tool(
            name="update_task",
            description="Update task text",
            inputSchema={
                "type": "object",
                "properties": {
                    "task_id": {"type": "integer", "description": "Task ID"},
                    "text": {"type": "string", "description": "New task text"},
                    "category": {
                        "type": "string",
                        "description": "Category name (default: default category)",
                    },
                },
                "required": ["task_id", "text"],
            },
        ),
        Tool(
            name="delete_task",
            description="Delete/archive a task",
            inputSchema={
                "type": "object",
                "properties": {
                    "task_id": {"type": "integer", "description": "Task ID"},
                    "category": {
                        "type": "string",
                        "description": "Category name (default: default category)",
                    },
                },
                "required": ["task_id"],
            },
        ),
        # Task Properties
        Tool(
            name="set_task_day",
            description="Assign a day of the week to a task",
            inputSchema={
                "type": "object",
                "properties": {
                    "task_id": {"type": "integer", "description": "Task ID"},
                    "day": {
                        "type": "string",
                        "description": "Day name (Monday-Sunday) or null to clear",
                        "enum": [
                            "Monday",
                            "Tuesday",
                            "Wednesday",
                            "Thursday",
                            "Friday",
                            "Saturday",
                            "Sunday",
                            None,
                        ],
                    },
                    "category": {
                        "type": "string",
                        "description": "Category name (default: default category)",
                    },
                },
                "required": ["task_id"],
            },
        ),
        Tool(
            name="set_task_priority",
            description="Set task priority",
            inputSchema={
                "type": "object",
                "properties": {
                    "task_id": {"type": "integer", "description": "Task ID"},
                    "priority": {
                        "type": "string",
                        "description": "Priority level",
                        "enum": ["none", "low", "medium", "high", "urgent"],
                    },
                    "category": {
                        "type": "string",
                        "description": "Category name (default: default category)",
                    },
                },
                "required": ["task_id", "priority"],
            },
        ),
        Tool(
            name="set_task_status",
            description="Set task status",
            inputSchema={
                "type": "object",
                "properties": {
                    "task_id": {"type": "integer", "description": "Task ID"},
                    "status": {
                        "type": "string",
                        "description": "Status",
                        "enum": ["todo", "in-progress", "done", "blocked"],
                    },
                    "category": {
                        "type": "string",
                        "description": "Category name (default: default category)",
                    },
                },
                "required": ["task_id", "status"],
            },
        ),
        # Utility
        Tool(
            name="get_project_context",
            description="Get current project directory and jot configuration",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
    ]


# =============================================================================
# Tool Handlers
# =============================================================================


@app.call_tool()
async def call_tool(name: str, arguments: Any) -> list[TextContent]:
    """Handle tool calls"""

    try:
        if name == "list_categories":
            return await handle_list_categories()
        elif name == "get_category_info":
            return await handle_get_category_info(arguments)
        elif name == "create_category":
            return await handle_create_category(arguments)
        elif name == "list_tasks":
            return await handle_list_tasks(arguments)
        elif name == "add_task":
            return await handle_add_task(arguments)
        elif name == "get_current_task":
            return await handle_get_current_task(arguments)
        elif name == "set_current_task":
            return await handle_set_current_task(arguments)
        elif name == "update_task":
            return await handle_update_task(arguments)
        elif name == "delete_task":
            return await handle_delete_task(arguments)
        elif name == "set_task_day":
            return await handle_set_task_day(arguments)
        elif name == "set_task_priority":
            return await handle_set_task_priority(arguments)
        elif name == "set_task_status":
            return await handle_set_task_status(arguments)
        elif name == "get_project_context":
            return await handle_get_project_context()
        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


# Category Handlers


async def handle_list_categories() -> list[TextContent]:
    """List all categories"""
    cat_mgr = get_category_manager()

    local_cats = cat_mgr.discover_categories()
    global_cats = cat_mgr.discover_global_categories()

    result = {
        "local_categories": local_cats,
        "global_categories": global_cats,
        "total": len(local_cats) + len(global_cats),
        "limit": CategoryManager.MAX_CATEGORIES,
    }

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def handle_get_category_info(arguments: dict) -> list[TextContent]:
    """Get category information"""
    category = arguments["category"]
    cat_mgr = get_category_manager()

    location = cat_mgr.resolve_category_location(category)
    task_mgr = get_task_manager(category)

    tasks = task_mgr.list_tasks()
    current_task = task_mgr.get_current_task()

    result = {
        "category": category,
        "location": location,
        "task_count": len(tasks),
        "current_task_id": current_task["id"] if current_task else None,
        "exists": location != "new",
    }

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def handle_create_category(arguments: dict) -> list[TextContent]:
    """Create a new category"""
    category = arguments["category"]
    is_global = arguments.get("is_global", False)

    cat_mgr = get_category_manager()

    # Validate category creation
    can_create, error_msg = cat_mgr.can_create_category(category)
    if not can_create:
        return [TextContent(type="text", text=f"Error: {error_msg}")]

    # Create empty category file
    if is_global:
        cat_mgr.GLOBAL_CATEGORIES_DIR.mkdir(parents=True, exist_ok=True)
        file_path = cat_mgr.get_category_file_path(category, is_global=True)
    else:
        file_path = cat_mgr.get_category_file_path(category, is_global=False)

    # Initialize empty category
    empty_data = {"tasks": [], "archived": []}
    with open(file_path, "w") as f:
        json.dump(empty_data, f, indent=2)

    result = {
        "category": category,
        "location": "global" if is_global else "local",
        "file_path": str(file_path),
        "status": "created",
    }

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


# Task Handlers


async def handle_list_tasks(arguments: dict) -> list[TextContent]:
    """List tasks in a category"""
    category = arguments.get("category")
    task_mgr = get_task_manager(category)

    tasks = task_mgr.list_tasks()

    # Format tasks for output
    formatted_tasks = []
    for task in tasks:
        formatted_tasks.append(
            {
                "id": task["id"],
                "text": task["text"],
                "done": task.get("done", False),
                "current": task.get("current", False),
                "day": task.get("day"),
                "priority": task.get("priority", "none"),
                "status": task.get("status", "todo"),
                "tally": task.get("tally", 0),
            }
        )

    result = {"category": category or "default", "tasks": formatted_tasks}

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def handle_add_task(arguments: dict) -> list[TextContent]:
    """Add a new task"""
    text = arguments["text"]
    category = arguments.get("category")
    task_mgr = get_task_manager(category)

    task_id = task_mgr.add_task(text)

    result = {
        "task_id": task_id,
        "text": text,
        "category": category or "default",
        "status": "created",
    }

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def handle_get_current_task(arguments: dict) -> list[TextContent]:
    """Get current task"""
    category = arguments.get("category")
    task_mgr = get_task_manager(category)

    current_task = task_mgr.get_current_task()

    if not current_task:
        return [
            TextContent(type="text", text=json.dumps({"current_task": None}, indent=2))
        ]

    result = {
        "current_task": {
            "id": current_task["id"],
            "text": current_task["text"],
            "done": current_task.get("done", False),
            "day": current_task.get("day"),
            "priority": current_task.get("priority", "none"),
            "status": current_task.get("status", "todo"),
        }
    }

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def handle_set_current_task(arguments: dict) -> list[TextContent]:
    """Set current task"""
    task_id = arguments["task_id"]
    category = arguments.get("category")
    task_mgr = get_task_manager(category)

    task_mgr.set_current(task_id)

    result = {"task_id": task_id, "status": "set as current"}

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def handle_update_task(arguments: dict) -> list[TextContent]:
    """Update task text"""
    task_id = arguments["task_id"]
    text = arguments["text"]
    category = arguments.get("category")
    task_mgr = get_task_manager(category)

    task_mgr.edit_task(task_id, text)

    result = {"task_id": task_id, "text": text, "status": "updated"}

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def handle_delete_task(arguments: dict) -> list[TextContent]:
    """Delete/archive task"""
    task_id = arguments["task_id"]
    category = arguments.get("category")
    task_mgr = get_task_manager(category)

    task_mgr.delete_task(task_id)

    result = {"task_id": task_id, "status": "deleted"}

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


# Task Property Handlers


async def handle_set_task_day(arguments: dict) -> list[TextContent]:
    """Set task day"""
    task_id = arguments["task_id"]
    day = arguments.get("day")
    category = arguments.get("category")
    task_mgr = get_task_manager(category)

    task_mgr.set_task_day(task_id, day)

    result = {"task_id": task_id, "day": day, "status": "updated"}

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def handle_set_task_priority(arguments: dict) -> list[TextContent]:
    """Set task priority"""
    task_id = arguments["task_id"]
    priority = arguments["priority"]
    category = arguments.get("category")
    task_mgr = get_task_manager(category)

    task_mgr.set_task_priority(task_id, priority)

    result = {"task_id": task_id, "priority": priority, "status": "updated"}

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def handle_set_task_status(arguments: dict) -> list[TextContent]:
    """Set task status"""
    task_id = arguments["task_id"]
    status = arguments["status"]
    category = arguments.get("category")
    task_mgr = get_task_manager(category)

    task_mgr.set_task_status(task_id, status)

    result = {"task_id": task_id, "status": status, "updated": "success"}

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


# Utility Handlers


async def handle_get_project_context() -> list[TextContent]:
    """Get project context"""
    project_dir = get_project_dir()

    # Check if .jot.json exists
    jot_file = project_dir / ".jot.json"
    has_jot = jot_file.exists()

    # Get categories
    cat_mgr = get_category_manager(project_dir)
    local_cats = cat_mgr.discover_categories()
    global_cats = cat_mgr.discover_global_categories()

    result = {
        "project_dir": str(project_dir),
        "has_jot": has_jot,
        "jot_file": str(jot_file) if has_jot else None,
        "local_categories": local_cats,
        "global_categories": global_cats,
    }

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


# =============================================================================
# Main Server Entry Point
# =============================================================================


async def main():
    """Run the MCP server"""
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


if __name__ == "__main__":
    import asyncio

    asyncio.run(main())
