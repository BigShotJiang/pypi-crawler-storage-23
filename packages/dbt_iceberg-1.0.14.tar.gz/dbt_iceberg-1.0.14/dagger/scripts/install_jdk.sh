#!/bin/bash
set -eo
apt-get update && apt-get install -y \
    default-jdk
