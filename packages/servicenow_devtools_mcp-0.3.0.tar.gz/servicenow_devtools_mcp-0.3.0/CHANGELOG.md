# Changelog

## [0.3.0](https://github.com/Xerrion/servicenow-devtools-mcp/compare/v0.2.4...v0.3.0) (2026-02-27)


### Features

* add ServiceNowQuery builder and wire time-filtering across all modules ([#35](https://github.com/Xerrion/servicenow-devtools-mcp/issues/35)) ([eae49eb](https://github.com/Xerrion/servicenow-devtools-mcp/commit/eae49ebb316949f02042fc56521f34c17bf69d4b))

## [0.2.4](https://github.com/Xerrion/servicenow-devtools-mcp/compare/v0.2.3...v0.2.4) (2026-02-24)


### Bug Fixes

* exhaustive security, correctness, and performance improvements ([#29](https://github.com/Xerrion/servicenow-devtools-mcp/issues/29)) ([154174c](https://github.com/Xerrion/servicenow-devtools-mcp/commit/154174c2f36490b21aa24a32e61138633a70d1f4))

## [0.2.3](https://github.com/Xerrion/servicenow-devtools-mcp/compare/v0.2.2...v0.2.3) (2026-02-20)


### Bug Fixes

* use token in command ([#27](https://github.com/Xerrion/servicenow-devtools-mcp/issues/27)) ([9e46c71](https://github.com/Xerrion/servicenow-devtools-mcp/commit/9e46c7106aad7cad5f7baef4def2591237b2fe12))

## [0.2.2](https://github.com/Xerrion/servicenow-devtools-mcp/compare/v0.2.1...v0.2.2) (2026-02-20)


### Bug Fixes

* update publish step to use uv publish command with environment variable ([#25](https://github.com/Xerrion/servicenow-devtools-mcp/issues/25)) ([d1caea5](https://github.com/Xerrion/servicenow-devtools-mcp/commit/d1caea5f696ce66b8b45ddc65176b305ef3ceb6d))

## [0.2.1](https://github.com/Xerrion/servicenow-devtools-mcp/compare/v0.2.0...v0.2.1) (2026-02-20)


### Bug Fixes

* remvoe the workflow_dispatch that came in by mistake ([#23](https://github.com/Xerrion/servicenow-devtools-mcp/issues/23)) ([9598214](https://github.com/Xerrion/servicenow-devtools-mcp/commit/959821451fa2d050bc747d6f1bdfef35482fb396))

## [0.2.0](https://github.com/Xerrion/servicenow-devtools-mcp/compare/v0.1.0...v0.2.0) (2026-02-20)


### Features

* Phase 3 — developer actions, investigations, and documentation tools ([5749dd8](https://github.com/Xerrion/servicenow-devtools-mcp/commit/5749dd85740772248afe1a5534e9613af0bc0fca))
* ServiceNow MCP server Phase 1+2 complete ([cd67149](https://github.com/Xerrion/servicenow-devtools-mcp/commit/cd6714977083c78701478dde27a0a6b5aa533e6d))


### Bug Fixes

* align release-please workflow with manifest config and correct token ([#20](https://github.com/Xerrion/servicenow-devtools-mcp/issues/20)) ([b25e2bb](https://github.com/Xerrion/servicenow-devtools-mcp/commit/b25e2bb225702fcba57eeaf1542de5ca13a10bf9))
* migrate release-please to manifest config for semver tags ([#18](https://github.com/Xerrion/servicenow-devtools-mcp/issues/18)) ([f5b450d](https://github.com/Xerrion/servicenow-devtools-mcp/commit/f5b450d2daa05c894b313fe7080cb6e3227aa722))


### Documentation

* add GitHub Copilot custom instructions ([#15](https://github.com/Xerrion/servicenow-devtools-mcp/issues/15)) ([350ff80](https://github.com/Xerrion/servicenow-devtools-mcp/commit/350ff80740a264bd97c0453a3520e52c6060541d))
* update README and add banner SVG for improved presentation ([#16](https://github.com/Xerrion/servicenow-devtools-mcp/issues/16)) ([c1179ad](https://github.com/Xerrion/servicenow-devtools-mcp/commit/c1179ad5d1b2c42dc67c4803f48d496a27d72236))

## 0.1.0 (2026-02-20)


### Features

* Phase 3 — developer actions, investigations, and documentation tools ([5749dd8](https://github.com/Xerrion/servicenow-devtools-mcp/commit/5749dd85740772248afe1a5534e9613af0bc0fca))
* ServiceNow MCP server Phase 1+2 complete ([cd67149](https://github.com/Xerrion/servicenow-devtools-mcp/commit/cd6714977083c78701478dde27a0a6b5aa533e6d))


### Documentation

* add GitHub Copilot custom instructions ([#15](https://github.com/Xerrion/servicenow-devtools-mcp/issues/15)) ([350ff80](https://github.com/Xerrion/servicenow-devtools-mcp/commit/350ff80740a264bd97c0453a3520e52c6060541d))
