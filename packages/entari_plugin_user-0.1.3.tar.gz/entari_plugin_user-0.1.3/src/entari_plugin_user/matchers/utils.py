import random
from collections.abc import Sequence

from sqlalchemy import select
from arclet.entari import User as UserModel
from entari_plugin_database import get_session

from ..config import config
from ..utils import get_user
from ..models import Bind


def generate_token(prefix: str = config.user_token_prefix) -> str:
    return f"{prefix}{random.randint(100000, 999999)}"


async def get_bind_list(platform: str, platform_user: UserModel) -> Sequence[Bind]:
    async with get_session() as db_session:
        user = await get_user(platform, platform_user)

        binds = (
            await db_session.scalars(select(Bind).where(Bind.bind_id == user.id))
        ).all()

        return binds
