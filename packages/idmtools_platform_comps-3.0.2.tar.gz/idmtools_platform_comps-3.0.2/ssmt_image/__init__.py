"""idmtools comps platform.

Build docker image.

Copyright 2021, Bill & Melinda Gates Foundation. All rights reserved.
"""
