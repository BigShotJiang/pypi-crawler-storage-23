"""idmtools download workitem.

Copyright 2021, Bill & Melinda Gates Foundation. All rights reserved.
"""
