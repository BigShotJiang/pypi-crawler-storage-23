"""idmtools ssmt utils.

These tools are meant to be used server-side within SSMT.

Copyright 2021, Bill & Melinda Gates Foundation. All rights reserved.
"""
