"""idmtools ssmt operations.

Since SSMT is the same as comps, we only derive the simulation and workfitem operations to do local file access.

Copyright 2021, Bill & Melinda Gates Foundation. All rights reserved.
"""
