"""idmtools comps operations module.

The operations define how to interact with specific item types.

Copyright 2021, Bill & Melinda Gates Foundation. All rights reserved.
"""
