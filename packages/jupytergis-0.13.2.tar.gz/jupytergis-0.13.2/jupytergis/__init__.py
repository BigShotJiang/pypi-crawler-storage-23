__version__ = "0.13.2"

from jupytergis_lab import GISDocument, explore  # noqa
