async def main():
    result = {
        "products": [
            {"name": "Wireless Bluetooth Headphones", "price": 79.99},
            {"name": "Stainless Steel Water Bottle", "price": 24.95},
            {"name": "Portable Phone Charger", "price": 34.50}
        ]
    }
    return result