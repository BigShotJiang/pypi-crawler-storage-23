async def main():
    result = {
        'name': 'John Smith',
        'age': 32,
        'city': 'New York'
    }
    return result