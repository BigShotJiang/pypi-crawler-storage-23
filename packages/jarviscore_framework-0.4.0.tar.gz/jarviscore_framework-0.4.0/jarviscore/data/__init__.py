"""
Data files for JarvisCore scaffolding.

Contains:
- .env.example: Example environment configuration
- examples/: Example agent implementations
"""
