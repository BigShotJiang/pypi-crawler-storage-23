# BNR Exchange Rates Converter

Convert foreign currency to RON (Romanian New Leu).

## Build and Publish

```bash
uv build
uv publish --publish-url https://test.pypi.org/legacy/)
```

## Run Locally

```bash
uvx --from . bnr-converter
```
