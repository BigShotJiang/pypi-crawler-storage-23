"""CLI module for PowerBI Ontology Extractor."""
