"""Application entrypoints."""

from __future__ import annotations

from lerim.app.cli import main

__all__ = ["main"]
