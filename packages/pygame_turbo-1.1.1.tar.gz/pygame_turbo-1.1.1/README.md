# ⚙️ pygame-turbo

pygame turbo is a open-source 2D game engine built on pygame-ce and pymunk.  
It’s designed to keep game development simple and flexible.

## Quick Start

### Installation
To install from PyPI:
```bash
pip install pygame-turbo
```

### Create a New Project
To create a new project:

```bash
pygame-turbo new my_game
```

**Note:** You can add metadata with optional flags like `--author`, `--description`, `--tags`, or use `--input` for an interactive setup. 

### Run the Project
To run your project:
```bash
pygame-turbo run my_game
```

## Managing Projects
The CLI provides several commands to manage your projects:

```bash
pygame-turbo list              # List all projects
pygame-turbo info my_game      # Show project details
pygame-turbo explore my_game   # Open project folder
pygame-turbo build my_game     # Freeze the game
```

To see all available commands:
```bash
pygame-turbo --help
```

## Documentation
The documentation is built using pdoc, a docstring generator.  
It provides an overview of the engine API and how it works.

It is recommended to read the documentation at least once to understand the engine’s structure and usage.

Documentation: [here](https://antonispylos.github.io/pygame-turbo/)

## License

This project is licensed under the MIT License.  
See the [LICENSE](LICENSE.txt) file for the full license text.
