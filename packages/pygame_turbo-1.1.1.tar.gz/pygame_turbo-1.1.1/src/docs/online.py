import webbrowser


def online_docs(*args, **kwargs):
    webbrowser.open("https://antonispylos.github.io/pygame-turbo/")
