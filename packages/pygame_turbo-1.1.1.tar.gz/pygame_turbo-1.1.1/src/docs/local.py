from time import perf_counter as time

import pdoc
import pdoc.web


def local_docs(*args, **kwargs):
    """
    Run a web server to preview documentation for all modules except excluded ones.
    """
    x1 = time()
    ip = "localhost"
    port = 8080
    pdoc.render.configure(docformat="google")
    httpd = pdoc.web.DocServer(
        (ip, port),
        [
            "pygame_turbo",
            "!pygame_turbo.docs",
            "!pygame_turbo.examples",
            "!pygame_turbo.project",
            "!pygame_turbo.templates",
            "!pygame_turbo.editor",
        ],
    )
    x2 = time()
    url = f"http://{ip}:{httpd.server_port}"
    print(f"server ready: {url}")
    print(f"render time: {(x2 - x1) * 1000:.2f} ms")
    print("\nPress Ctrl+C to stop")
    pdoc.web.open_browser(url)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        httpd.server_close()
