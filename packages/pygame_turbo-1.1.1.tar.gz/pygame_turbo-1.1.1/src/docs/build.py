import os
from pathlib import Path
from time import perf_counter as time

import pdoc


def build_docs(*args, **kwargs):
    """
    Build static HTML documentation for all modules except excluded ones.
    Output is placed in a 'build' subfolder of the current working directory.
    """
    x1 = time()
    pdoc.render.configure(docformat="google")
    output_path = Path(os.getcwd()) / "docs"
    output_path.mkdir(parents=True, exist_ok=True)
    pdoc.pdoc(
        "pygame_turbo",
        "!pygame_turbo.examples",
        "!pygame_turbo.docs",
        "!pygame_turbo.project",
        "!pygame_turbo.templates",
        "!pygame_turbo.editor",
        output_directory=output_path,
    )
    x2 = time()
    print("output path:", output_path)
    print(f"build time: {x2 - x1:.2f} seconds")
