---
name: spex-onboard
description: Analyze codebase to identify applications and libraries, then use spex to persist them
---

# Spex-Onboard Skill

Analyze the codebase to identify applications and libraries, then use the `spex` CLI to persist them to `.spex/memory/apps.jsonl`. This skill focuses exclusively on detecting executable apps and reusable libraries—no folders, files, or edges.

> [!IMPORTANT]
> **DO NOT READ FILE CONTENTS.** This skill is for structure detection only. Use `list_dir`, `find_by_name`, and git commands to discover applications and libraries.

## Input Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `rootPath` | Yes | Absolute path to the codebase root |

---

## Step 1: Check Spex CLI Installation

Verify that the `spex` CLI is installed and available in the environment:

```bash
spex
```

If the command fails or is not found, **STOP IMMEDIATELY** and suggest the user install it before continuing:

> [!ERROR]
> `spex-cli` is not installed. Please install it by running:
> `pip install spex`

---

## Step 2: Detect Repository Root

Run git commands to verify the root is a git repository:

```bash
git -C <rootPath> rev-parse --git-dir 2>/dev/null
git -C <rootPath> remote get-url origin 2>/dev/null
```

Store the repository name/URL for use in app entries.

---

## Step 3: Identify Executable Applications

Scan the root directory for key entry files to detect applications:

| File Pattern | App Type | Package Manager |
|--------------|----------|-----------------|
| `package.json` (with main/bin/scripts.dev) | Node.js/Frontend | npm |
| `Dockerfile`, `docker-compose.yml` | Containerized | docker |
| `*.yaml` in `k8s/`, `kubernetes/`, `charts/` | K8s-deployed | kubernetes |
| `main.py`, `app.py`, `manage.py` | Python | pip |
| `Cargo.toml` | Rust | cargo |
| `go.mod` | Go | go |
| `pom.xml`, `build.gradle` | Java | maven/gradle |
| `Gemfile` + `config.ru` | Ruby | bundler |
| `*.csproj`, `*.sln` | .NET | nuget |
| `Package.swift` | Swift | swift |

**Determining appType:**
- `frontend`: React/Vue/Angular apps, Next.js, web applications
- `backend`: Express servers, FastAPI, Django, Spring Boot
- `cli`: Command-line tools with bin entries
- `service`: Microservices, background workers, containerized services

**Determining app name:**
Follow this strategy to identify the application name:
- **Single App**: If only one application is detected (typically at the repository root), use the **repository name** as the app name.
- **Multi-App**: If multiple applications are detected:
  - Look for the closest `README.md` file in the application's directory and extract a name from the header.
  - If no `README.md` is found or it lacks a clear name, use the **name of the directory** containing the application.

---

## Step 4: Identify Libraries

Look for exportable packages and shared code:

**Detection patterns:**
- `package.json` with `"private": false` or `"main"` pointing to index
- Folders named `packages/`, `libs/`, `shared/`, `common/`
- Go modules with library packages (no main.go)
- Rust crates marked as libraries in Cargo.toml
- Python packages with `__init__.py` in `src/` or `lib/`

**Determining owner:**
After detecting each library, **prompt the user** to specify the owner:
```
Found library: <package-name> (<packageManager>) at <filePath>
Who is the owner/maintainer?
```
Wait for user input and use the provided name as the `owner` field. If the user provides no name or skips, the field should be empty (it is optional).

---

## Step 5: Persist to apps.jsonl using spex

For each detected application or library, use the `spex` CLI to add it:

```bash
cd <rootPath>
spex app add \
  --name "<app-name>" \
  --type "application" \
  --repository "<repo-url-or-name>" \
  --app-type "<frontend|backend|cli|service>" \
  --package-manager "<npm|pip|cargo|go|...>" \
  --file-path "<relative-path-from-git-root>" \
  --owner "<owner-name>"  # Optional
```

> [!IMPORTANT]
> All `--file-path` values MUST be relative to the git repository root, never absolute paths.

**Example for an application:**
```bash
spex app add \
  --name "vite_react_shadcn_ts" \
  --type "application" \
  --repository "git@github.com:ran729/speX-frontend.git" \
  --app-type "frontend" \
  --package-manager "npm" \
  --file-path "." \
  --owner "Ran Sasportas"
```

**Example for a library:**
```bash
spex app add \
  --name "shared-utils" \
  --type "library" \
  --repository "git@github.com:ran729/speX-frontend.git" \
  --package-manager "npm" \
  --file-path "packages/shared-utils" \
  --owner "Platform Team"
```

---

## Step 6: Summary Output

Print a summary of what was detected and persisted:

```
✓ Detected <N> applications and <M> libraries
✓ Persisted to .spex/memory/apps.jsonl via spex

Applications:
  - <app-name-1> (frontend, npm) at <path> - Owner: <owner>
  - <app-name-2> (backend, pip) at <path> - Owner: <owner>

Libraries:
  - <lib-name-1> (npm) at <path> - Owner: <owner>
```

---

## Step 7: Onboarding Completion

Instruct the user that onboarding is complete with a celebratory and clear message. **Your final output for this skill MUST include the following message:**

# 🎉 ONBOARDING IS DONE! YOU ARE READY TO GO!!!

**Spex is fully configured and your codebase structure is mapped.**

---

### 💡 Next Steps

#### 1. Teach Spex About Your Project
Help Spex understand your codebase's "soul"—the architecture, product requirements, and best practices.
*   **Use "Teach Me" Mode:** `spex please learn from README.md and docs/architecture.md`
*   **Use Past Conversations:** `spex please learn from our previous discussion about the checkout flow`

#### 2. Start Developing with Spex Skills
Jump straight into coding with the full power of Spex's memory.
*   **Build Features:** `spex please add a user profile edit form using the tailwind-components library`
*   **Solve Tasks:** `spex please fix the concurrency bug in the workers service`

---
Happy Coding! 🚀


**Taxonomy & Governance:**

In a healthy model, knowledge flows from intent to action:
**Requirement (Why)** → **Policy (Law)** → **Decision (How)** → **Trace (Proof)**

#### Requirements (Problem Space)
Define **WHAT** the system must achieve or **WHICH** boundaries it must respect.

> [!IMPORTANT]
> **Source of Truth**: Requirements must originate EXCLUSIVELY from user input (prompts, documents, or explicit directions). Agents MUST NOT infer requirements; all functional and non-functional requirements must be citable back to a user-provided source.

| Type | Name | Definition | Example |
| :--- | :--- | :--- | :--- |
| **FR** | Functional | Specific behavior or feature. | "User can export data to CSV." |
| **NFR** | Non-Functional | Quality attributes (perf, security, UX). | "Exports must complete in <2s." |
| **CR** | Constraint | External, non-negotiable limitation. | "Must use AWS Frankfurt region." |
| **UR** | User-Specified | Raw input from user (needs refinement). | "Make it feel 'snappy'." |

#### Policies (Standing Laws)
A **Policy** is a reusable, mandatory rule that bridges Requirements and Decisions.
*   **Trigger**: Use a policy when you make the same recommendation >2 times.
*   **Scope**: Usually global or cross-application.
*   **Enforcement**: Mandatory. Deviations require an Architectural Decision (Policy Exception).
*   **Example**: *"All API calls must use Circuit Breakers to satisfy NFR (Resiliency)."*

#### Decisions (Action Space)
Defined by their **Reversibility** and **Impact**.

| Class | Reversibility | Impact | Definition |
| :--- | :--- | :--- | :--- |
| **Architectural** | High Cost | System-wide | Choices affecting core frameworks or primitives. |
| **Structural** | Moderate Cost | Component | Choices regarding organization or API contracts. |
| **Tactical** | Low Cost | Local/File | Logic, algorithms, or localized patterns. |

#### Governance Rules

1.  **Reversibility Filter (Avoid Bloat)**: Do not record every choice.
    - **Implicit follows Policy**: If a choice simply follows an existing Policy, **don't record it** as a separate decision.
    - **Explicit Deviation**: If you MUST break a policy, you MUST record it as a Decision.
    - **Arch/Struct Only**: Always record Architectural and Structural choices. Record Tactical only if logic is unintuitive.
2.  **Negative Knowledge**: Always document **Alternatives Considered** for Architectural and Structural decisions.
3.  **Promotion Strategy**:
    - **UR → FR/NFR**: Refine raw User Requirements into testable FRs/NFRs during research. *Note: Refinement must only clarify or formalize user intent, never invent it.*
    - **Tactical → Policy**: If a Tactical Decision is repeated across tasks, "promote" it to a Policy in the `REFLECT` phase.

**Validation:**
**Classification**: Adhere strictly to the definitions in Taxonomy & Governance when defining items.
**Traceability**: Every **Requirement** defines a user-facing capability. Every **Decision** defines the technical approach.
**Policies**: Mandatory standing rules for autonomous execution.
