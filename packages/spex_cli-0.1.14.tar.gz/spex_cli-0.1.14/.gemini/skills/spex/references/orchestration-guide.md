# Spex Orchestration Guide

This guide provides the complete, step-by-step procedures for orchestrating feature development using the Spex state machine.

---

## State Machine Overview

| State | Description | Next State(s) | Human Checkpoint? |
|-------|-------------|---------------|-------------------|
| `INIT` | Feature request received | `RESEARCH` | No |
| `RESEARCH` | Code exploration + technical decision analysis | `RESOLVING_CONFLICTS`, `GENERATE_PLAN`, `RESEARCH` (retry), `STOP` | Conditional |
| `RESOLVING_CONFLICTS`| Deep physical conflict resolution | `GENERATE_PLAN`, `STOP` | **Yes** |
| `GENERATE_PLAN` | Generate requirements + decisions | `REVIEWING_PLAN` | No |
| `REVIEWING_PLAN` | Human reviews and approves plan | `GENERATE_PLAN`, `COMPILING_TASKS` | **Yes** |
| `COMPILING_TASKS` | Break plan into executable tasks | `EXECUTE` | No |
| `EXECUTE` | Execute all tasks with memory-grounded implementation | `EXECUTE` (next task), `COMPLETE` | No |
| `COMPLETE` | All tasks done | - | No |
| `STOP` | Prompt for human clarification | `RESEARCH`, `GENERATE_PLAN` | **Yes** |

---

## Critical Rules

1. **Never skip states** - Follow the state machine exactly.
2. **Autonomous Execution** - Proceed automatically unless a "Human Checkpoint" is reached or blocking conflicts occur.
3. **Always Persist State** - Transitions MUST be performed using `spex validate-and-route `. This ensures the centralized feature plan is always in sync with the current development phase.
4. **Impact Mapping** - Every decision MUST include a detailed mapping of impacted files, data flows, and logic changes.
5. **Evidence Limit** - Max 3 iterations of the RESEARCH loop before STOP.
6. **No Assumptions** - If evidence is insufficient, move to `STOP`.

---

## 0. Scope Initialization (MANDATORY)

Before starting any feature, you MUST determine the active application scope.
1. **Load Active Apps**: `cat .spex/memory/apps.jsonl | jq -rc 'select(.status == "active")'`.
2. **Evaluate Scope**: 
   - Compare the user's request and files with the `filePath` of active apps.
   - The app whose `filePath` is a **prefix** of the working directory or modified files is the relevant scope.
   - If a change affects multiple apps, include all of them in a comma-separated list.
3. **Clarify**: If ambiguous, ask the user.
4. **Normalization**: App names are automatically normalized by replacing spaces with hyphens (e.g., `speX App` → `speX-App`).
5. **Persist**: This scope will be used in the Plan object and all subsequent memory entries. Empty scope means "global" and should be used rarely.

---

1. **Add Plan**: `spex plan add --feature-name <name> --goal <goal> --scope <scope>`
   - This initializes a new feature plan with a unique **Plan ID** (e.g., `P-a3f2b1c4`) and sets the state to `INIT`.
2. **Create folder**: `mkdir -p .spex/plans/<feature-name>`
   - Use this for local artifacts like `research.json`, `plan.md`, and `tasks.md`.

---

## State: RESEARCH

### Purpose
Produce a verifiable, source-cited snapshot of facts from the codebase and technical decisions. The goal is to identify how to build the feature, considering architectural guardrails, existing functions, data flows, and prior rejected alternatives.

### Procedure
1. **Validate Transition**: `spex validate-and-route --plan-id <P-ID> --target-state RESEARCH `
2. **Identify Scrutinized Files**: List the core files/directories relevant to the goal.
3. **Analyze Technical Decisions**: Cross-reference the identified feature scope against historical decisions in `.spex/memory/decisions.jsonl`. Determine *why* the code was built this way and note any relevant rejected alternatives.
4. **Collect EVIDENCE**: Facts with source citations (snippets) found in code.
5. **Collect CONSTRAINTS**: Explicit rules found in code (e.g., hardcoded limits, required props).
6. **Collect INVARIANTS**: Behaviors enforced by code (e.g., "Always uses UUIDs").
7. **Identify UNKNOWNS & TECHNICAL CONFLICTS**: List information needed but missing from the physical codebase, or any discovered technical contradiction (e.g., plan requires adding a field to an API, but a decision mandates strict contracts). These will become Open Questions.
8. **Save codebase section**: Update `.spex/plans/<feature-name>/research.json` with the `codebase` section including `scrutinizedFiles`.
9. **Execute Memory Analysis**:
   > **STOP. Read `memory-analysis.md` in full now and execute its steps verbatim. Do not paraphrase or summarize — follow each step exactly as written.**

**Output**: `.spex/plans/<feature-name>/research.json` with both `codebase` and `memory` sections populated.
- Format defined in: [Appendix: Research Contract](#appendix-research-contract)

### Decision Logic
Based on the results in `research.json`:
- **INSUFFICIENT**: Critical implementation context missing and iterations < 3? -> `RESEARCH` (retry — increment `evidenceGatheringIterations`).
- **CONFLICTS FOUND**: Orphaning risks, Technical Drifts, or Incompatibilities with a High Blast Radius detected in `memory` section? -> `RESOLVING_CONFLICTS`.
- **READY**: Sufficient evidence and NO blocking conflicts? -> `GENERATE_PLAN` (Pass unknowns as "Open Questions").
- **LIMIT REACHED**: Iterations >= 3? -> `STOP`.

---

## State: RESOLVING_CONFLICTS (Human Checkpoint)

### Purpose
When the physical research phase uncovers deep technical conflicts (like Orphaning requirements or breaking Data Flows), you must resolve these with the user before planning.

### Procedure
1. **Validate Transition**: `spex validate-and-route --plan-id <P-ID> --target-state RESOLVING_CONFLICTS `
2. **Present Options to User**:
   - **Group by subject**: Group conflicts (e.g. all conflicts touching the same feature).
   - **Use AskUserQuestion tool**: Present the conflict and ask how to resolve.
   - For each conflict group show:
     *   **The Discrepancy**: "Plan says X, but existing Decision [D-XXX] says Y."
     *   **The Impact Radius**: Summarize `impact_radius` from `research.json` (Orphaned Requirements, Destabilized Decisions, Physical Debt).
     *   **Resolution Options**: (Override, Merge, Cancel, Refine).
3. **Wait for Approval**: Do not proceed until the user answers.
4. **Execute Resolution**:
   - **Deprecate**: `spex decision deprecate --id <ID> `, `spex requirement deprecate --id <ID> `
   - **Update**: `spex requirement update --id <ID> ... `
   - *Note on Orphaning*: When Overriding an Orphaning conflict, you must recursively deprecate dependent requirements and decisions.
5. **Transition**: Move to `GENERATE_PLAN` or `STOP` (if cancelled).

---

## State: GENERATE_PLAN

### Purpose
Generate a comprehensive, grounded proposal for a feature.

### Procedure
1. **Validate Transition**: `spex validate-and-route --plan-id <P-ID> --target-state GENERATE_PLAN `
2. **Draft Plan**: Create `.spex/plans/<feature-name>/plan.md` using the research findings in `research.json`.
2. **Requirement Definition (Capability-First)**:
   - Describe WHAT the user needs or the system must do.
   - **Categorization**: Use the **FR, NFR, CR, UR** types defined in the Spex Taxonomy (core skill instructions).
   - **Scope**: All requirements MUST have a scope.
3. **Decision Definition (Technical Implementation)**:
   - Describe HOW to implement technically.
   - **MANDATORY Alternatives**: State rejected options and rationale ("Negative Knowledge").
   - **Classification**: Classify as **Architectural**, **Structural**, or **Tactical** based on the Reversibility Filter in the core skill.
   - **Impact Maps**: Specify **Files**, **Data Flows**, **Logic**, and **UX** impact (All 4 REQUIRED).
4. **Linking & Traceability**:
   - Every requirement must be satisfied by at least one decision.
   - Link to relevant **Policies** and **Grounding** points from research.
5. **Implementation Plan & Constraints**: Break the changes into steps and define **Non-Goals** and **Open Questions**.
6. **Assign Official IDs**: Use temporary IDs `[FR-XXX]`, `[D-XXX]` during drafting. Official IDs are assigned by the CLI after approval.

### When to Refuse
- Required information is missing or research is incomplete.
- Cannot determine specific files/components to modify.
- Constraints are contradictory.
- Goal is too vague to create actionable decisions.

**Output**: Save to `.spex/plans/<feature-name>/plan.md`.
- Format defined in: [Appendix: Plan Contract](#appendix-plan-contract)

---

## State: REVIEWING_PLAN (Human Checkpoint)

### Purpose
Obtain human validation of the proposed plan. **CRITICAL: Once the plan is approved, it is frozen and should not be changed.**

### Procedure
1. **Validate Transition**: `spex validate-and-route --plan-id <P-ID> --target-state REVIEWING_PLAN `
2. **Present Review**:
   - Summary of changes.
   - **High-Impact Decisions** table (Decision | Risk/Trade-off).
   - Open Questions (If any open questions exist, you MUST use the AskUserQuestion tool to resolve them).
3. **Resolve Open Questions**: Once open questions are resolved with the user, you MUST update `.spex/plans/<feature-name>/plan.md` with the new information and then re-ask the user for explicit approval on the updated plan.
4. **Await Approval**: Must get explicit "Approved" before implementation. **Once approved, the plan is frozen.**
5. **Persist Memory**:
   - `spex plan update-status --id <P-ID> --status approved `
   - `spex requirement add --plan-id <P-ID> --type <type> --description "<desc>" --source "<source>" --acceptance-criteria "<criteria>" --scope "<scope>" `
   - `spex decision add --proposal "<proposal>" --rationale "<rationale>" --alternatives "<alternatives>" --satisfies "<req-ids>" --impact '{"files": [], "dataFlows": [], "logic": [], "ux": []}' --decision-class <class> --scope "<scope>" `
6. **Sync IDs**: Update `plan.md` with returned IDs (e.g., FR-042, D-089).

---

## State: COMPILING_TASKS

### Procedure
1. **Validate Transition**: `spex validate-and-route --plan-id <P-ID> --target-state COMPILING_TASKS `
2. **Deconstruct**: Map approved Decisions to bounded, executable tasks.
3. **Define Implementation Steps**: Every task MUST include:
   - Failing test snippet.
   - Minimal implementation guidance.
   - `git commit` command with one `decision-id` trailer per correlated decision.

**Output**: Save to `.spex/plans/<feature-name>/tasks.md`.

List of tasks.
Each task must include:
- **Task ID**: Unique identifier (e.g., T-001, T-002)
- **Decision ID(s)**: Which decision(s) this task implements (REQUIRED)
- **Plan step**: Which plan step it maps to
- **Description**: Deep description of the flow change.
- **Implementation Steps**: 
  - **Step 1: Write failing test** (Include code snippet and command)
  - **Step 2: Implement minimal logic** (Include code snippet)
  - **Step 3: Verify pass** (Include command and expected output)
  - **Step 4: Commit** (Mandatory: one `--trailer "decision-id: <D-ID>"` per correlated decision)
    - Single decision: `git commit -m "<Task Description>" --trailer "decision-id: D-001"`
    - Multiple decisions: `git commit -m "<Task Description>" --trailer "decision-id: D-001" --trailer "decision-id: D-002"`

---

## State: EXECUTE

### Purpose
Iterate through tasks with memory grounding. Never code "blind."

### Procedure (Per Task)
1. **Validate Transition**: `spex validate-and-route --plan-id <P-ID> --target-state EXECUTE `
2. **Scoped Lookup**: Run `spex blame <files>` for the files being modified.
2. **Build Context**: Compile Constraints (policies), Guidance (patterns), and Gaps.
3. **TDD Implementation**: 
   - Write failing test.
   - Write minimal logic.
   - Verify pass.
4. **Decision Attribution**: Every choice must trace to memory or be recorded as a **New Tactical Decision** via `spex decision add ... `.
5. **Commit**: Add one `--trailer "decision-id: <ID>"` per correlated decision.
   - Single: `git commit -m "<Task Description>" --trailer "decision-id: D-001"`
   - Multiple: `git commit -m "<Task Description>" --trailer "decision-id: D-001" --trailer "decision-id: D-002"`

---

## State: COMPLETE

### Procedure
1. **Validate Transition**: `spex validate-and-route --plan-id <P-ID> --target-state COMPLETE `
2. **Validation Checklist**:
   - All tasks executed.
   - All traces recorded.
2. **Close Plan**: `spex plan update-status --id <P-ID> --status complete `.
3. **Final Report**:
   - Summary of accomplishments.
   - Traceability table (Req -> Decision -> Commit).
4. **Transition to Reflection**: Inform the user that the feature is officially complete. Mention that once they are satisfied with the final result (after their own testing and verification), they can invoke the `spex reflect` skill to capture learnings and improve the process for future features.

---

## Appendix: Data Contracts

### Appendix: Research Contract
The output of the `RESEARCH` state is a unified JSON file saved to `.spex/plans/<feature-name>/research.json`.

```json
{
  "featureName": "string",
  "iterations": "integer",
  "codebase": {
    "scrutinizedFiles": ["string"],
    "evidence": [
      {
        "fact": "string",
        "source": "path/to/file#L1-L10",
        "snippet": "string",
        "context": "string"
      }
    ],
    "constraints": [
      {
        "statement": "string",
        "source": "string",
        "snippet": "string"
      }
    ],
    "invariants": [
      {
        "behavior": "string",
        "tag": "FACT | INFERENCE",
        "source": "string"
      }
    ],
    "unknowns": [
      {
        "missing": "string",
        "whyNeeded": "string"
      }
    ]
  },
  "memory": {
    "conflicts": [
      {
        "severity": "blocking | warning",
        "type": "Incompatibility | Redundancy | Regression | Logic Drift",
        "message": "string",
        "existingId": "string",
        "impact_radius": {
          "upstream": [{"id": "string", "type": "string", "description": "string"}],
          "downstream": [{"id": "string", "type": "string", "proposal": "string"}],
          "traces": [{"traceId": "string", "commitHashes": ["string"]}]
        }
      }
    ],
    "grounding": [
      {
        "id": "string",
        "description": "string",
        "link": "string"
      }
    ],
    "leverage": [
      {
        "id": "string",
        "suggestion": "string"
      }
    ]
  }
}
```

### Appendix: Plan Contract
The output of `GENERATE_PLAN` is a Markdown file saved to `.spex/plans/<feature-name>/plan.md`.

#### Structure
1. **Plan Header**: Goal, Status, Created.
2. **Requirements**: 
   - **Description**: [Clear, testable statement from user perspective]
   - **Source**: [Where requirement came from: user request, constraint, inference]
   - **Type**: FR (Functional), NFR (Non-Functional), CR (Constraint), UR (User Request).
   - **Acceptance Criteria**: must be **Test Cases**: Step-by-step verification instructions.
   - **Scope**: [Comma-separated app names, e.g., speX-Frontend] (All requirements MUST have a scope).
3. **Decisions**:
   - **Proposal**: [The technical approach or architectural choice]
   - **Rationale**: [Why this is the best way to satisfy linked requirements] 
   - **Satisfies**: [Comma-separated list of requirement IDs and Policy IDs].
   - **Grounding**: (optional) [References to historical memory items].
   - **Alternatives**: MANDATORY consideration of other options.
   - **Impact**: Files, Data Flows, Logic, UX (All 4 REQUIRED).
   - **Class**: architectural, structural, tactical (See Reversibility Filter).
   - **Scope**: [Comma-separated app names] (All decisions MUST have a scope).
4. **Implementation Plan**: Sequential steps linking to decisions.
5. **Non-Goals**: Explicitly state what is out of scope.
6. **Open Questions**: Items that block execution or require clarification.
