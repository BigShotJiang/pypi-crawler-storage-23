import os
import json
import sys

def run_debug(output_file: str) -> None:
    """Run the debug command to log environment variables"""
    env_vars = dict(os.environ)
    try:
        with open(output_file, 'w') as f:
            json.dump(env_vars, f, indent=2)
        print(f"Environment variables written to {output_file}")
    except Exception as e:
        print(f"Error writing to {output_file}: {e}", file=sys.stderr)
