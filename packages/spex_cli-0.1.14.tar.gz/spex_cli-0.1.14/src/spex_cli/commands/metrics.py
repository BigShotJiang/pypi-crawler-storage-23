"""Metrics - append-only telemetry for measuring Spex process impact."""

import json
import os
import uuid
from datetime import datetime
from pathlib import Path

from spex_cli.core.models import Metric
from spex_cli.core.constants import METRICS_FILE, SESSION_ID_ENV, PLANS_DIR, TERM_SESSION_ID


def _read_jsonl(filepath, model):
    """Read JSONL file into list of model instances."""
    entries = []
    try:
        with open(filepath) as f:
            for line in f:
                line = line.strip()
                if line:
                    entries.append(model.from_dict(json.loads(line)))
    except FileNotFoundError:
        pass
    return entries


def _append_jsonl(filepath, entry):
    """Append a single entry to a JSONL file."""
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, 'a') as f:
        f.write(json.dumps(entry.to_dict()) + '\n')


def _rewrite_jsonl(filepath, entries):
    """Rewrite entire JSONL file with given entries."""
    with open(filepath, 'w') as f:
        for entry in entries:
            f.write(json.dumps(entry.to_dict()) + '\n')


def get_session_id() -> str:
    """Read SPEX_SESSION_ID from environment (set by SessionStart hook). fallback to TERM_SESSION_ID"""
    return os.environ.get(SESSION_ID_ENV, os.environ.get(TERM_SESSION_ID, ""))


def emit_metric(event: str, data: dict, feature_name: str = "", plan_id: str = "", session_id: str = "", strict: bool = False) -> None:
    """Append a metric event. Best-effort by default."""
    try:
        metric = Metric(
            id=f"M-{str(uuid.uuid4())[:8]}",
            timestamp=datetime.now().isoformat(),
            sessionId=session_id or get_session_id(),
            featureName=feature_name,
            planId=plan_id,
            event=event,
            data=data,
        )
        _append_jsonl(METRICS_FILE, metric)
    except Exception as e:
        if strict:
            raise e


def report_metrics(feature_name: str = "", plan_id: str = "") -> None:
    """Generate a deterministic metrics report for a feature."""
    entries = _read_jsonl(METRICS_FILE, Metric)

    # Filter by feature if provided
    if feature_name:
        # Also include events linked by session IDs from the latest plan
        linked_sessions = set()
        
        # 1. Try to find active plan in PLANS_DIR
        plans_dir = Path(PLANS_DIR)
        if plans_dir.exists():
            for plan_path in plans_dir.glob("*.json"):
                try:
                    with open(plan_path) as f:
                        data = json.load(f)
                        if data.get("featureName") == feature_name:
                            linked_sessions.update(data.get("sessionIds", []))
                except Exception:
                    continue
        
        entries = [
            e for e in entries
            if e.featureName == feature_name
            or (e.sessionId and e.sessionId in linked_sessions)
        ]

    if plan_id:
        entries = [e for e in entries if e.planId == plan_id]

    # Compute summary
    state_transitions = [e for e in entries if e.event == "state_transition"]
    memory_lookups = [e for e in entries if e.event == "memory_lookup"]
    memory_writes = [e for e in entries if e.event == "memory_write"]
    user_prompts = [e for e in entries if e.event == "user_prompt"]

    total_lookup_results = sum(e.data.get("resultsCount", 0) for e in memory_lookups)

    report = {
        "featureName": feature_name or "all",
        "planId": plan_id or "all",
        "totalEvents": len(entries),
        "stateTransitions": len(state_transitions),
        "memoryLookups": {
            "count": len(memory_lookups),
            "totalResults": total_lookup_results,
        },
        "memoryWrites": {
            "count": len(memory_writes),
            "byType": {},
        },
        "userPrompts": {
            "count": len(user_prompts),
            "totalPromptLength": sum(e.data.get("promptLength", 0) for e in user_prompts),
        },
        "sessions": list(set(e.sessionId for e in entries if e.sessionId)),
    }

    # Break down writes by type
    for e in memory_writes:
        wtype = e.data.get("type", "unknown")
        report["memoryWrites"]["byType"][wtype] = report["memoryWrites"]["byType"].get(wtype, 0) + 1

    print(json.dumps(report, indent=2))
