import os
import re
import subprocess
import sys
from pathlib import Path


def _bump_patch(version: str) -> str:
    major, minor, patch = version.split(".")
    return f"{major}.{minor}.{int(patch) + 1}"


def deploy():
    """Bump patch version in pyproject.toml, commit it, then run scripts/deploy.sh."""
    project_root = Path(__file__).parent.parent.parent
    pyproject_path = project_root / "pyproject.toml"
    deploy_script = project_root / "scripts" / "deploy.sh"

    # Read and bump version
    content = pyproject_path.read_text()
    match = re.search(r'^version = "([^"]+)"', content, re.MULTILINE)
    if not match:
        print("Error: could not find version in pyproject.toml")
        sys.exit(1)

    old_version = match.group(1)
    new_version = _bump_patch(old_version)
    content = content.replace(f'version = "{old_version}"', f'version = "{new_version}"', 1)
    pyproject_path.write_text(content)
    print(f"Bumped version: {old_version} → {new_version}")

    # Sync uv.lock to reflect the new version
    subprocess.run(["uv", "sync"], cwd=project_root, check=True)

    # Commit the version bump + updated lockfile
    subprocess.run(["git", "add", str(pyproject_path), str(project_root / "uv.lock")], cwd=project_root, check=True)
    subprocess.run(
        ["git", "commit", "-m", f"Bump version to {new_version}"],
        cwd=project_root,
        check=True,
    )

    # Run deploy.sh
    result = subprocess.run([str(deploy_script)], cwd=project_root)
    sys.exit(result.returncode)


def refresh():
    """Uninstall and reinstall spex-cli using pipx."""
    print("Refreshing spex-cli installation...")
    
    # Uninstall
    print("Running: pipx uninstall spex-cli")
    subprocess.run(["pipx", "uninstall", "spex-cli"])
    
    # Install
    print("Running: pipx install --python python3.11 .")
    result = subprocess.run(["pipx", "install", "--python", "python3.11", "."])
    
    if result.returncode == 0:
        print("✓ spex-cli refreshed successfully!")
    else:
        print("✗ Failed to reinstall spex-cli.")
        sys.exit(result.returncode)

if __name__ == "__main__":
    refresh()
