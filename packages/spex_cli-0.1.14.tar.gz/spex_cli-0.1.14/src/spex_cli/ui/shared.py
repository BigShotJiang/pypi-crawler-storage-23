import streamlit as st
import json
from pathlib import Path

# Common CSS for our exact color palette
COMMON_CSS = """
<style>
    /* Global Background */
    .stApp {
        background-color: #0D1117;
        color: #E5E7EB;
    }
    
    /* Headlines */
    h1, h2, h3, h4, h5, h6 {
        color: #FFFFFF !important;
        font-family: 'Inter', sans-serif;
    }
    
    /* Sidebar */
    [data-testid="stSidebar"] {
        background-color: #161B22;
        border-right: 1px solid #30363D;
        width: 240px !important;
        min-width: 240px !important;
    }

    [data-testid="stSidebar"] > div:first-child {
        width: 240px !important;
    }

    /* Sidebar content spacing */
    [data-testid="stSidebar"] .element-container {
        margin-bottom: 0.75rem;
    }

    /* Sidebar title */
    [data-testid="stSidebar"] h1 {
        font-size: 1.2rem;
        margin-bottom: 1rem;
    }

    /* Sidebar multiselect labels */
    [data-testid="stSidebar"] label {
        font-size: 0.8rem;
        font-weight: 600;
        color: #7D8590;
        margin-bottom: 0.25rem;
    }

    /* Sidebar multiselect */
    [data-testid="stSidebar"] .stMultiSelect {
        font-size: 0.75rem;
    }

    [data-testid="stSidebar"] .stMultiSelect > div {
        min-height: 32px;
    }

    /* Sidebar multiselect dropdown items */
    [data-testid="stSidebar"] [data-baseweb="popover"] {
        font-size: 0.75rem;
    }

    /* Sidebar markdown headers */
    [data-testid="stSidebar"] h3 {
        font-size: 1.1rem;
        margin-top: 0;
        margin-bottom: 1rem;
        color: #E6EDF3;
    }

    /* Compact spacing for sidebar widgets */
    [data-testid="stSidebar"] [data-testid="stVerticalBlock"] > div {
        gap: 0.5rem;
    }

    /* Multiselect tags - smaller */
    [data-testid="stSidebar"] [data-baseweb="tag"] {
        font-size: 0.7rem;
        padding: 2px 6px;
        margin: 1px;
    }

    /* Selected items in multiselect */
    [data-testid="stSidebar"] [data-baseweb="tag"] span {
        font-size: 0.7rem;
    }
    
    /* Metric Cards Override */
    [data-testid="stMetricValue"] {
        color: #F97316;
    }
    
    /* Buttons and UI Elements */
    .stButton>button {
        background-color: #F97316;
        color: white;
        border-radius: 4px;
        border: none;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .stButton>button:hover {
        background-color: #8B5CF6;
        color: white;
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(139, 92, 246, 0.3);
    }

    .stButton>button:active {
        transform: translateY(0);
    }

    /* Sidebar Navigation Buttons - Sleek Routing Style */
    [data-testid="stSidebar"] .stButton>button {
        background-color: transparent !important;
        color: #E6EDF3 !important;
        border: none !important;
        text-align: left !important;
        padding: 4px 12px !important;
        width: 100% !important;
        display: flex !important;
        align-items: center !important;
        justify-content: flex-start !important;
        gap: 10px !important;
        font-size: 0.9rem !important;
        font-weight: 400 !important;
        transition: all 0.2s ease !important;
        border-radius: 6px !important;
        box-shadow: none !important;
    }

    /* Force left alignment on all internal containers */
    [data-testid="stSidebar"] .stButton>button div,
    [data-testid="stSidebar"] .stButton>button span,
    [data-testid="stSidebar"] .stButton>button p {
        text-align: left !important;
        justify-content: flex-start !important;
        margin: 0 !important;
        width: auto !important;
    }

    [data-testid="stSidebar"] .stButton>button:hover {
        background-color: #1C2128 !important;
        color: #F97316 !important;
        transform: none !important;
        box-shadow: none !important;
    }

    [data-testid="stSidebar"] .stButton>button:active {
        background-color: #0D1117;
    }

    /* Reduce spacing between sidebar navigation items */
    [data-testid="stSidebar"] [data-testid="stVerticalBlock"] > div:has(.stButton) {
        margin-bottom: -10px !important;
    }

    /* Tabs */
    .stTabs [data-baseweb="tab-list"] {
        gap: 24px;
        background-color: transparent;
    }

    .stTabs [data-baseweb="tab"] {
        height: 50px;
        white-space: pre-wrap;
        background-color: transparent;
        border-radius: 4px 4px 0px 0px;
        gap: 1px;
        padding-top: 10px;
        padding-bottom: 10px;
        color: #9CA3AF;
    }

    .stTabs [aria-selected="true"] {
        color: #F97316 !important;
        border-bottom: 2px solid #F97316 !important;
    }

    /* Input Fields */
    .stTextInput input {
        background-color: #1C2128 !important;
        border: 1px solid #30363D !important;
        color: #FFFFFF !important;
        border-radius: 6px !important;
    }

    /* Selectbox Styling - making it look like a clear dropdown */
    div[data-baseweb="select"] {
        background-color: #1C2128 !important;
        border: 1px solid #30363D !important;
        border-radius: 6px !important;
        transition: border-color 0.2s ease, box-shadow 0.2s ease;
    }

    div[data-baseweb="select"]:hover {
        border-color: #F97316 !important;
    }

    div[data-baseweb="select"]:focus-within {
        border-color: #F97316 !important;
        box-shadow: 0 0 0 2px rgba(249, 115, 22, 0.2) !important;
    }

    /* Selectbox Text */
    div[data-baseweb="select"] div {
        color: #E6EDF3 !important;
        font-size: 0.9rem !important;
    }

    /* Dropdown List Items */
    ul[role="listbox"] {
        background-color: #161B22 !important;
        border: 1px solid #30363D !important;
    }

    li[role="option"] {
        background-color: transparent !important;
        color: #E6EDF3 !important;
        transition: background-color 0.2s ease;
    }

    li[role="option"]:hover {
        background-color: #1C2128 !important;
        color: #F97316 !important;
    }

    /* Metric Card Styling */
    div[data-testid="metric-container"] {
        background-color: #161B22;
        border: 1px solid #30363D;
        padding: 15px;
        border-radius: 10px;
    }

    /* Tooltip / Popover */
    .spex-tooltip {
        position: relative;
        display: inline-block;
        cursor: help;
        border-bottom: 1px dotted #9CA3AF;
        color: #60A5FA;
        font-weight: 500;
    }
    .spex-tooltip .spex-tooltiptext {
        visibility: hidden;
        width: max-content;
        max-width: 300px;
        background-color: #161B22;
        color: #E5E7EB;
        text-align: left;
        border-radius: 6px;
        padding: 10px 14px;
        position: absolute;
        z-index: 1000;
        bottom: 125%;
        left: 50%;
        transform: translateX(-50%);
        opacity: 0;
        transition: opacity 0.2s;
        border: 1px solid #30363D;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.4);
        font-size: 0.85rem;
        font-weight: normal;
        white-space: normal;
        line-height: 1.5;
    }
    .spex-tooltip:hover .spex-tooltiptext {
        visibility: visible;
        opacity: 1;
    }

    /* Expandable Cards */
    details > summary {
        list-style: none;
        outline: none;
    }
    details > summary::-webkit-details-marker {
        display: none;
    }

    /* Timeline Container */
    .timeline-container {
        position: relative;
        padding-left: 32px;
    }

    /* Timeline vertical line - continuous across all items */
    .timeline-container::before {
        content: '';
        position: absolute;
        left: 11px;
        top: 0;
        bottom: 0;
        width: 2px;
        background-color: #21262D;
    }

    /* Timeline Header */
    .timeline-header {
        color: #7D8590;
        font-size: 0.8rem;
        font-weight: 600;
        margin: 24px 0 12px 0;
        display: flex;
        align-items: center;
        gap: 6px;
        position: relative;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .timeline-header:first-child {
        margin-top: 0;
    }

    /* Commit Item */
    .commit-item {
        background-color: #0D1117;
        border: 1px solid #30363D;
        border-radius: 6px;
        position: relative;
        margin-bottom: 8px;
    }

    /* Timeline dot - single neutral dark color */
    .commit-item::before {
        content: '';
        position: absolute;
        left: -25px;
        top: 22px;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background-color: #30363D;
        border: 2px solid #0D1117;
        z-index: 2;
    }

    .commit-item > summary {
        padding: 12px 16px;
        cursor: pointer;
        display: flex;
        flex-direction: column;
        gap: 4px;
        border-radius: 6px;
        transition: background-color 0.2s ease;
    }

    .commit-item > summary:hover {
        background-color: #161B22;
    }

    .commit-item[open] > summary {
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
    }

    .commit-item[open] > div {
        padding: 8px 16px 16px 16px;
    }

    /* Nested sections within plans */
    .plan-section {
        margin-top: 16px;
        padding-top: 16px;
        border-top: 1px solid #21262D;
    }

    .plan-section-details {
        margin-bottom: 12px;
    }

    .plan-section-details:last-child {
        margin-bottom: 0;
    }

    .plan-section-header {
        background-color: transparent;
        padding: 8px 12px;
        cursor: pointer;
        border-radius: 4px;
        margin-bottom: 0;
        display: flex;
        align-items: center;
        gap: 8px;
        font-weight: 600;
        font-size: 0.8rem;
        color: #7D8590;
        border: 1px solid #21262D;
        transition: all 0.2s ease;
    }

    .plan-section-header:hover {
        background-color: #161B22;
        border-color: #30363D;
    }

    .plan-section-details[open] .plan-section-header {
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
        border-bottom: none;
    }

    .plan-section-content {
        margin-top: 0;
        padding: 4px 12px 12px 12px;
        background-color: transparent;
        border: 1px solid #21262D;
        border-top: none;
        border-bottom-left-radius: 4px;
        border-bottom-right-radius: 4px;
    }

    .nested-item {
        margin-bottom: 8px;
        border: 1px solid #21262D;
        border-radius: 4px;
        background-color: transparent;
    }

    .nested-item:last-child {
        margin-bottom: 0;
    }

    .nested-item > summary {
        padding: 10px 12px;
        cursor: pointer;
        transition: all 0.2s ease;
        border-radius: 4px;
    }

    .nested-item > summary:hover {
        background-color: #161B22;
    }

    .nested-item[open] > summary {
        border-bottom: none;
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
    }

    .nested-item > div {
        padding: 4px 12px 12px 12px;
        background-color: transparent;
    }
</style>
"""

def apply_common_styles(page_title="Spex Memory"):
    """Apply common page configuration and styles."""
    st.set_page_config(
        page_title=page_title,
        layout="wide",
        initial_sidebar_state="expanded"
    )
    st.markdown(COMMON_CSS, unsafe_allow_html=True)

def load_jsonl(filepath):
    """Load items from a JSONL file into a list of dictionaries."""
    if not Path(filepath).exists():
        return []
    items = []
    with open(filepath, 'r') as f:
        for line in f:
            if line.strip():
                try:
                    items.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return items

def load_plans_from_dir(directory):
    """Load all plan JSON files from a directory."""
    path = Path(directory)
    if not path.exists() or not path.is_dir():
        return []
    items = []
    for plan_file in path.glob("*.json"):
        try:
            with open(plan_file, 'r') as f:
                data = json.load(f)
                if isinstance(data, dict) and "id" in data:
                    items.append(data)
        except Exception:
            continue
    return items

def render_sidebar_header():
    """Render a consistent header for the sidebar."""
    st.sidebar.markdown("""
        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px; padding: 0 5px;">
            <span style="font-size: 1.5rem;">📦</span>
            <h1 style="margin: 0; font-size: 1.2rem; color: #E6EDF3; font-weight: 700;">Spex</h1>
        </div>
    """, unsafe_allow_html=True)
