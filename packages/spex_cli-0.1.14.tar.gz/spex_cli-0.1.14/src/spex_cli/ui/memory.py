import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path
import re
from shared import apply_common_styles, load_jsonl, load_plans_from_dir, render_sidebar_header

# Apply styles and config
apply_common_styles("Spex Memory")

def get_latest_versions(items):
    """Filter to only the latest version of each ID."""
    if not items:
        return []

    latest = {}
    for item in items:
        item_id = item.get('id')
        version = item.get('version', 1)
        if item_id not in latest or version > latest[item_id].get('version', 0):
            latest[item_id] = item
    return list(latest.values())

def render_timeline(items, plan_children, format_satisfies):
    """Render a timeline of items grouped by date."""
    if not items:
        return '<div style="padding: 20px; text-align: center; color: #7D8590;">No items found.</div>'

    # Group by date
    items_df = pd.DataFrame(items)
    grouped = items_df.groupby(items_df['createdAt'].dt.date, sort=False)

    # Sort date groups newest first
    sorted_groups = sorted(grouped, key=lambda x: x[0], reverse=True)

    # Start timeline container
    timeline_html = '<div class="timeline-container">'

    for date_val, group_items in sorted_groups:
        # Sort items within each date group newest first
        group_items = group_items.sort_values(by='createdAt', ascending=False)
        date_str = date_val.strftime('%b %d, %Y') if pd.notnull(date_val) else 'Unknown Date'
        timeline_html += (
            f'<div class="timeline-header">'
            f'{date_str}</div>'
        )

        timeline_html += '<div class="commit-group">'
        for _, row in group_items.iterrows():
            t_name = row['item_type']
            item_html = render_item(row, t_name, format_satisfies)

            # If this is a plan, nest its children in separate sections
            if t_name == 'Plans':
                plan_id = str(row['id'])
                children = plan_children.get(plan_id, {'requirements': [], 'decisions': []})

                # Build children HTML with separate sections
                children_html = ""

                if children['requirements'] or children['decisions']:
                    children_html = '<div class="plan-section">'

                    # Requirements section
                    if children['requirements']:
                        reqs = children['requirements']
                        reqs.sort(key=lambda x: x['createdAt'], reverse=True)

                        req_count = len(reqs)
                        children_html += (
                            f'<details class="plan-section-details">'
                            f'<summary class="plan-section-header">'
                            f'<span>📋</span>'
                            f'<span>Requirements ({req_count})</span>'
                            f'</summary>'
                            f'<div class="plan-section-content">'
                        )
                        for req in reqs:
                            req_html = render_nested_item(req, 'Requirements', format_satisfies)
                            children_html += req_html
                        children_html += '</div></details>'

                    # Decisions section
                    if children['decisions']:
                        decs = children['decisions']
                        decs.sort(key=lambda x: x['createdAt'], reverse=True)

                        dec_count = len(decs)
                        children_html += (
                            f'<details class="plan-section-details">'
                            f'<summary class="plan-section-header">'
                            f'<span>🔧</span>'
                            f'<span>Decisions ({dec_count})</span>'
                            f'</summary>'
                            f'<div class="plan-section-content">'
                        )
                        for dec in decs:
                            dec_html = render_nested_item(dec, 'Decisions', format_satisfies)
                            children_html += dec_html
                        children_html += '</div></details>'

                    children_html += '</div>'

                # Insert children before closing details tag
                item_html = item_html.replace('</details>', f'{children_html}</details>')

            timeline_html += item_html
        timeline_html += '</div>'

    # Close timeline container
    timeline_html += '</div>'
    return timeline_html

def render_nested_item(row, t_name, format_satisfies):
    """Render a nested item (requirement or decision within a plan)."""
    def get_val(r, key):
        v = r.get(key)
        if pd.isna(v) or v is None:
            return None
        return str(v)

    # Field Visibility Logic
    all_fields = {}
    if t_name == "Requirements":
        all_fields = {
            "Type": get_val(row, 'type'),
            "Source": get_val(row, 'source'),
            "Acceptance Criteria": get_val(row, 'acceptanceCriteria')
        }
    elif t_name == "Decisions":
        all_fields = {
            "Rationale": get_val(row, 'rationale'),
            "Alternatives": get_val(row, 'alternatives'),
            "Satisfies": format_satisfies(row.get('satisfies')),
            "Impact": str(row.get('impact', '')),
            "Decision Class": get_val(row, 'decisionClass'),
            "Grounding": get_val(row, 'grounding')
        }

    # Build Fields HTML
    fields_html = ""
    for label, val in all_fields.items():
        if val and str(val).strip() and str(val).lower() != 'nan':
            fields_html += f'<div style="margin-bottom: 10px;"><div style="font-weight: 600; color: #7D8590; font-size: 0.75rem; text-transform: uppercase; margin-bottom: 4px; letter-spacing: 0.5px;">{label}</div><div style="color: #E6EDF3; font-size: 0.85rem; line-height: 1.5;">{val}</div></div>'

    # Scope tag footer
    scope_html = ""
    scope = row.get('scope')
    if isinstance(scope, list):
        scope_list = [s for s in scope if s]
    elif scope is not None and not pd.isna(scope) and str(scope).lower() != 'nan':
        scope_list = [scope]
    else:
        scope_list = []
    if scope_list:
        badges = "".join([f'<span style="background-color: #21262D; border: 1px solid #30363D; color: #7D8590; padding: 2px 8px; border-radius: 3px; font-size: 0.7rem; margin-right: 6px;">{s}</span>' for s in scope_list])
        scope_html = f'<div style="margin-top: 12px; display: flex; align-items: center; gap: 8px;"><span style="font-size: 0.7rem; color: #7D8590; text-transform: uppercase; font-weight: 600; letter-spacing: 0.5px;">Scope</span> {badges}</div>'

    status = get_val(row, 'status') or 'active'
    status_colors = {
        'active': '#22C55E',
        'deprecated': '#9CA3AF',
        'obsolete': '#EF4444',
        'draft': '#FBBF24',
        'approved': '#8B5CF6'
    }
    status_color = status_colors.get(status.lower(), '#9CA3AF')

    title = row.get('proposal' if t_name == 'Decisions' else 'description', 'Untitled')
    if title:
        title = re.sub(r'\*\*(.*?)\*\*', r'<strong style="color: #FFFFFF; font-weight: 800;">\1</strong>', str(title))
    author = row['author']

    item_html = (
        f'<details class="nested-item">'
        f'<summary>'
        f'<div style="display: flex; justify-content: space-between; align-items: baseline;">'
        f'<div style="color: #E5E7EB; font-weight: 500; font-size: 0.85rem;">{title}</div>'
        f'<div style="color: #7D8590; font-size: 0.7rem; font-family: monospace; display: flex; align-items: center; gap: 6px;">'
        f'<span style="width: 5px; height: 5px; border-radius: 50%; background-color: {status_color}; display: inline-block;"></span>'
        f'{row["id"]}</div>'
        f'</div>'
        f'<div style="color: #7D8590; font-size: 0.7rem; margin-top: 4px;">'
        f'👤 {author}'
        f'</div>'
        f'</summary>'
        f'<div>{fields_html}{scope_html}</div>'
        f'</details>'
    )
    return item_html

def render_item(row, t_name, format_satisfies):
    """Render a single item (requirement, decision, plan, or policy)."""
    def get_val(r, key):
        v = r.get(key)
        if pd.isna(v) or v is None:
            return None
        return str(v)

    # Field Visibility Logic
    all_fields = {}
    if t_name == "Requirements":
        all_fields = {
            "Type": get_val(row, 'type'),
            "Source": get_val(row, 'source'),
            "Acceptance Criteria": get_val(row, 'acceptanceCriteria')
        }
    elif t_name == "Decisions":
        all_fields = {
            "Rationale": get_val(row, 'rationale'),
            "Alternatives": get_val(row, 'alternatives'),
            "Satisfies": format_satisfies(row.get('satisfies')),
            "Impact": str(row.get('impact', '')),
            "Decision Class": get_val(row, 'decisionClass'),
            "Grounding": get_val(row, 'grounding')
        }
    elif t_name == "Plans":
        all_fields = {
            "Goal": get_val(row, 'goal'),
            "Context": get_val(row, 'context'),
            "Timeline": f"Approved: {get_val(row, 'approvedAt')} | Completed: {get_val(row, 'completedAt')}" if get_val(row, 'approvedAt') else None
        }
    elif t_name == "Policies":
        all_fields = {
            "Rationale": get_val(row, 'rationale'),
            "Satisfies": format_satisfies(row.get('satisfies'))
        }

    # Build Fields HTML
    fields_html = ""
    for label, val in all_fields.items():
        if val and str(val).strip() and str(val).lower() != 'nan':
            fields_html += f'<div style="margin-bottom: 10px;"><div style="font-weight: 600; color: #7D8590; font-size: 0.75rem; text-transform: uppercase; margin-bottom: 4px; letter-spacing: 0.5px;">{label}</div><div style="color: #E6EDF3; font-size: 0.85rem; line-height: 1.5;">{val}</div></div>'

    # Scope tag footer
    scope_html = ""
    scope = row.get('scope')
    if isinstance(scope, list):
        scope_list = [s for s in scope if s]
    elif scope is not None and not pd.isna(scope) and str(scope).lower() != 'nan':
        scope_list = [scope]
    else:
        scope_list = []
    if scope_list:
        badges = "".join([f'<span style="background-color: #21262D; border: 1px solid #30363D; color: #7D8590; padding: 2px 8px; border-radius: 3px; font-size: 0.7rem; margin-right: 6px;">{s}</span>' for s in scope_list])
        scope_html = f'<div style="margin-top: 12px; display: flex; align-items: center; gap: 8px;"><span style="font-size: 0.7rem; color: #7D8590; text-transform: uppercase; font-weight: 600; letter-spacing: 0.5px;">Scope</span> {badges}</div>'

    status = get_val(row, 'status') or 'active'
    status_colors = {
        'active': '#22C55E',
        'deprecated': '#9CA3AF',
        'obsolete': '#EF4444',
        'draft': '#FBBF24',
        'approved': '#8B5CF6'
    }
    status_color = status_colors.get(status.lower(), '#9CA3AF')

    # Add analytics button for Plans
    analytics_button_html = ""
    if t_name == "Plans":
        plan_id = row.get('id', '')
        analytics_button_html = f'''
        <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #21262D;">
            <a href="/analytics?planId={plan_id}" target="_self" style="text-decoration: none;">
                <button style="
                    background-color: #F97316;
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                    font-size: 0.85rem;
                    font-weight: 600;
                    cursor: pointer;
                    display: inline-flex;
                    align-items: center;
                    gap: 8px;
                    transition: all 0.3s ease;
                " onmouseover="this.style.backgroundColor='#8B5CF6'; this.style.transform='translateY(-1px)';" onmouseout="this.style.backgroundColor='#F97316'; this.style.transform='translateY(0)';" onmousedown="this.style.transform='translateY(0)';">
                    📊 View Analytics
                </button>
            </a>
        </div>
        '''

    # Add type label for top-level items (proper singularization)
    type_label_map = {
        'Requirements': '📋 Requirement',
        'Decisions': '🔧 Decision',
        'Plans': '📦 Plan',
        'Policies': '📜 Policy'
    }
    type_label = type_label_map.get(t_name, t_name)

    title = row.get('proposal' if t_name == 'Decisions' else ('featureName' if t_name == 'Plans' else 'description'), 'Untitled')
    if title:
        title = re.sub(r'\*\*(.*?)\*\*', r'<strong style="color: #FFFFFF; font-weight: 800;">\1</strong>', str(title))
    author = row['author']

    item_html = (
        f'<details class="commit-item">'
        f'<summary>'
        f'<div style="margin-bottom: 8px;">'
        f'<span style="color: #7D8590; font-size: 0.7rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">{type_label}</span>'
        f'</div>'
        f'<div style="display: flex; justify-content: space-between; align-items: baseline;">'
        f'<div style="color: #E5E7EB; font-weight: 600; font-size: 0.9rem;">'
        f'{title}'
        f'</div>'
        f'<div style="color: #7D8590; font-size: 0.75rem; font-family: monospace; display: flex; align-items: center; gap: 6px;">'
        f'{row["id"]}</div>'
        f'</div>'
        f'<div style="color: #7D8590; font-size: 0.75rem; margin-top: 6px; display: flex; align-items: center; gap: 12px;">'
        f'<span>👤 {author}</span>'
        f'<span style="display: flex; align-items: center; gap: 4px;">'
        f'<span style="width: 6px; height: 6px; border-radius: 50%; background-color: {status_color}; display: inline-block;"></span>'
        f'{status.capitalize()}'
        f'</span>'
        f'</div>'
        f'</summary>'
        f'<div>{fields_html}{scope_html}{analytics_button_html}</div>'
        f'</details>'
    )
    return item_html

def main():
    # Load data
    base_path = Path(".spex/memory")
    req_items = load_jsonl(base_path / "requirements.jsonl")
    dec_items = load_jsonl(base_path / "decisions.jsonl")
    pol_items = load_jsonl(base_path / "policies.jsonl")
    
    # Load plans from memory only
    plan_items = load_plans_from_dir(base_path / "plans")

    # Filter to latest versions
    requirements = get_latest_versions(req_items)
    decisions = get_latest_versions(dec_items)
    policies = get_latest_versions(pol_items)
    plans = get_latest_versions(plan_items)

    # Assign types for identification
    for r in requirements:
        r["item_type"] = "Requirements"
    for d in decisions:
        d["item_type"] = "Decisions"
    for p in policies:
        p["item_type"] = "Policies"
    for pl in plans:
        pl["item_type"] = "Plans"

    all_items = requirements + decisions + policies + plans
    df = pd.DataFrame(all_items)

    # Header with Member Name
    params = st.query_params
    member_name = params.get("member", "Team Contributions")
    st.title(f"Memory: {member_name}")

    if df.empty:
        st.info("No contributions found in spex memory.")
        return

    # Ensure createdAt is a datetime object
    df['createdAt'] = pd.to_datetime(df['createdAt'], errors='coerce')

    # Build dictionary for description popovers
    id_to_desc = {}
    for _, row in df.iterrows():
        item_id = row.get('id')
        if not item_id or (isinstance(item_id, float) and pd.isna(item_id)):
            continue
        t_name = row.get('item_type')
        if t_name == 'Decisions':
            desc = row.get('proposal', 'Untitled')
        elif t_name == 'Plans':
            desc = row.get('featureName', 'Untitled')
        else:
            desc = row.get('description', 'Untitled')
        id_to_desc[str(item_id)] = str(desc)

    def format_satisfies(satisfies_val):
        if not satisfies_val or (isinstance(satisfies_val, float) and pd.isna(satisfies_val)):
            return None
        
        s_list = satisfies_val if isinstance(satisfies_val, list) else [satisfies_val]
        formatted = []
        for s_id in s_list:
            if not s_id or (isinstance(s_id, float) and pd.isna(s_id)):
                continue
            
            s_id_str = str(s_id).strip()
            if not s_id_str or s_id_str.lower() == 'nan':
                continue
                
            desc = id_to_desc.get(s_id_str, "Description not found")
            safe_desc = desc.replace('&', '&amp;').replace('"', '&quot;').replace('<', '&lt;').replace('>', '&gt;')
            html = f'<span class="spex-tooltip">{s_id_str}<span class="spex-tooltiptext">{safe_desc}</span></span>'
            formatted.append(html)
            
        return ", ".join(formatted) if formatted else None

    # --- SIDEBAR FILTERS ---
    render_sidebar_header()
    
    # Navigation button with a bit more spacing
    st.sidebar.markdown("<div style='margin-bottom: 5px;'></div>", unsafe_allow_html=True)
    if st.sidebar.button("📊 Analytics Dashboard", use_container_width=True):
        st.switch_page("pages/analytics.py")
    
    if st.sidebar.button("🎯 Apps", use_container_width=True):
        st.switch_page("pages/apps.py")
    
    st.sidebar.markdown("<div style='margin-top: 15px; margin-bottom: 15px; border-top: 1px solid #30363D;'></div>", unsafe_allow_html=True)
    st.sidebar.markdown("### 🔍 Filters")

    # Author Filter (Pre-select if in URL)
    authors = sorted(df['author'].dropna().unique().tolist())
    default_authors = []
    if "member" in params:
        param_member = params["member"]
        if param_member in authors:
            default_authors = [param_member]
    selected_authors = st.sidebar.multiselect("👤 Authors", options=authors, default=default_authors, label_visibility="visible")

    # Scope Filter
    scopes = set()
    for s_list in df['scope'].dropna():
        if isinstance(s_list, list):
            scopes.update(s_list)
    selected_scopes = st.sidebar.multiselect("🎯 Scope", options=sorted(list(scopes)), label_visibility="visible")

    # Decision Class Filter
    dec_classes = sorted(df[df['item_type'] == 'Decisions']['decisionClass'].dropna().unique().tolist())
    selected_dec_classes = st.sidebar.multiselect("🔧 Decision Class", options=dec_classes, label_visibility="visible")

    # Requirement Type Filter
    req_types = sorted(df[df['item_type'] == 'Requirements']['type'].dropna().unique().tolist())
    selected_req_types = st.sidebar.multiselect("📋 Requirement Type", options=req_types, label_visibility="visible")

    # Status Filter
    statuses = sorted(df['status'].dropna().unique().tolist())
    # Include draft and approved by default so plans are visible
    default_statuses = [s for s in statuses if s.lower() in ['active', 'complete', 'draft', 'approved']]
    selected_statuses = st.sidebar.multiselect("✓ Status", options=statuses, default=default_statuses, label_visibility="visible")

    # --- FILTER LOGIC ---
    filtered_df = df.copy()
    
    if selected_authors:
        filtered_df = filtered_df[filtered_df['author'].isin(selected_authors)]
    if selected_scopes:
        filtered_df = filtered_df[filtered_df['scope'].apply(lambda x: any(s in x for s in selected_scopes) if isinstance(x, list) else False)]
    if selected_dec_classes:
        filtered_df = filtered_df[(filtered_df['item_type'] != 'Decisions') | (filtered_df['decisionClass'].isin(selected_dec_classes))]
    if selected_req_types:
        filtered_df = filtered_df[(filtered_df['item_type'] != 'Requirements') | (filtered_df['type'].isin(selected_req_types))]
    if selected_statuses:
        filtered_df = filtered_df[filtered_df['status'].isin(selected_statuses)]

    # --- ACTIVITY GRAPH ---
    st.markdown("<div style='margin-top: 40px;'></div>", unsafe_allow_html=True)
    st.subheader("Engagement & Activity")
    st.markdown("<div style='color: #9CA3AF; font-size: 0.9rem; margin-bottom: 20px;'>Visualize contribution frequency and focus areas over time.</div>", unsafe_allow_html=True)
    
    graph_df = filtered_df.dropna(subset=['createdAt']).copy()
    if not graph_df.empty:
        graph_df['date'] = graph_df['createdAt'].dt.date
        
        # Define color map for consistency
        color_map = {
            'Requirements': '#FBBF24', # Amber Gold
            'Decisions': '#F97316',    # Vibrant Orange
            'Plans': '#8B5CF6',        # Electric Purple
            'Policies': '#EC4899'      # Magenta Pink
        }

        # Breakdown Tabs
        g_tab1, g_tab2, g_tab3 = st.tabs(["📈 Total Activity", "🏷️ By Type", "🎯 By Scope"])
        
        with g_tab1:
            chart_data = graph_df.groupby('date').size().reset_index(name='items')
            fig = px.bar(chart_data, x='date', y='items', color_discrete_sequence=['#F97316'],
                         template="plotly_dark", labels={'items': 'Contributions', 'date': 'Date'})
            fig.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', font_color='#E5E7EB', margin=dict(l=0, r=0, t=20, b=0))
            st.plotly_chart(fig, use_container_width=True, key="total_graph")

        with g_tab2:
            chart_data = graph_df.groupby(['date', 'item_type']).size().reset_index(name='items')
            fig = px.bar(chart_data, x='date', y='items', color='item_type', 
                         color_discrete_map=color_map,
                         template="plotly_dark", labels={'items': 'Contributions', 'date': 'Date', 'item_type': 'Category'})
            fig.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', font_color='#E5E7EB', margin=dict(l=0, r=0, t=20, b=0))
            st.plotly_chart(fig, use_container_width=True, key="type_graph")

        with g_tab3:
            exploded_df = graph_df.explode('scope')
            chart_data = exploded_df.groupby(['date', 'scope']).size().reset_index(name='items')
            fig = px.bar(chart_data, x='date', y='items', color='scope',
                         template="plotly_dark", labels={'items': 'Contributions', 'date': 'Date', 'scope': 'Scope'})
            fig.update_layout(paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)', font_color='#E5E7EB', margin=dict(l=0, r=0, t=20, b=0))
            st.plotly_chart(fig, use_container_width=True, key="scope_graph")
    else:
        st.info("No contribution data found for activity chart.")

    # --- UNIVERSAL SEARCH & SORT ---
    st.markdown("---")
    col_search, col_sort = st.columns([4, 1])
    with col_search:
        search_query = st.text_input("Search contributions...", placeholder="Keyword search across all types...", key="universal_search", label_visibility="collapsed")
    with col_sort:
        sort_newest = st.toggle("Newest First", value=True)
    
    if search_query:
        # Filter all columns for keywords
        mask = filtered_df.astype(str).apply(lambda x: x.str.contains(search_query, case=False)).any(axis=1)
        filtered_df = filtered_df[mask]

    # Re-sort
    filtered_df = filtered_df.sort_values(by='createdAt', ascending=not sort_newest)

    # --- BUILD PLAN TREE STRUCTURE ---
    # Create mappings for plan nesting
    plan_children = {}  # plan_id -> {'requirements': [], 'decisions': []}
    req_to_plan = {}  # requirement_id -> plan_id

    # Map requirements to plans
    for _, row in filtered_df[filtered_df['item_type'] == 'Requirements'].iterrows():
        plan_id = row.get('planId')
        if plan_id and not pd.isna(plan_id):
            plan_id_str = str(plan_id)
            if plan_id_str not in plan_children:
                plan_children[plan_id_str] = {'requirements': [], 'decisions': []}
            plan_children[plan_id_str]['requirements'].append(row)
            req_to_plan[row['id']] = plan_id_str

    # Map decisions to plans (via requirement satisfaction)
    for _, row in filtered_df[filtered_df['item_type'] == 'Decisions'].iterrows():
        satisfies = row.get('satisfies')
        if satisfies:
            sat_list = satisfies if isinstance(satisfies, list) else [satisfies]
            for req_id in sat_list:
                if req_id and not pd.isna(req_id):
                    req_id_str = str(req_id)
                    if req_id_str in req_to_plan:
                        plan_id = req_to_plan[req_id_str]
                        if plan_id not in plan_children:
                            plan_children[plan_id] = {'requirements': [], 'decisions': []}
                        plan_children[plan_id]['decisions'].append(row)
                        break  # Only nest under first matching plan

    # Build unified timeline (excluding nested items)
    nested_req_ids = set()
    nested_dec_ids = set()
    for children in plan_children.values():
        nested_req_ids.update([r['id'] for r in children['requirements']])
        nested_dec_ids.update([d['id'] for d in children['decisions']])

    # Include: all plans, standalone requirements, standalone decisions, all policies
    timeline_items = []
    for _, row in filtered_df.iterrows():
        item_type = row['item_type']
        if item_type == 'Plans':
            timeline_items.append(row)
        elif item_type == 'Requirements' and row['id'] not in nested_req_ids:
            timeline_items.append(row)
        elif item_type == 'Decisions' and row['id'] not in nested_dec_ids:
            timeline_items.append(row)
        elif item_type == 'Policies':
            timeline_items.append(row)

    # Sort timeline by createdAt
    timeline_items.sort(key=lambda x: x['createdAt'], reverse=not sort_newest)

    # --- RENDER TABS ---
    st.markdown("---")

    # Prepare separate item lists
    plans_list = [row for _, row in filtered_df.iterrows() if row['item_type'] == 'Plans']
    policies_list = [row for _, row in filtered_df.iterrows() if row['item_type'] == 'Policies']

    # Create tabs
    tab1, tab2, tab3 = st.tabs([
        f"📊 Activity Log ({len(timeline_items)})",
        f"📦 Plans ({len(plans_list)})",
        f"📜 Policies ({len(policies_list)})"
    ])

    with tab1:
        st.markdown("<div style='color: #9CA3AF; font-size: 0.9rem; margin-bottom: 20px;'>Unified timeline of all contributions and decisions.</div>", unsafe_allow_html=True)
        timeline_html = render_timeline(timeline_items, plan_children, format_satisfies)
        st.markdown(timeline_html, unsafe_allow_html=True)

    with tab2:
        st.markdown("<div style='color: #9CA3AF; font-size: 0.9rem; margin-bottom: 20px;'>All feature plans with their associated requirements and decisions.</div>", unsafe_allow_html=True)
        plans_html = render_timeline(plans_list, plan_children, format_satisfies)
        st.markdown(plans_html, unsafe_allow_html=True)

    with tab3:
        st.markdown("<div style='color: #9CA3AF; font-size: 0.9rem; margin-bottom: 20px;'>Project-wide policies and guidelines.</div>", unsafe_allow_html=True)
        policies_html = render_timeline(policies_list, plan_children, format_satisfies)
        st.markdown(policies_html, unsafe_allow_html=True)

if __name__ == "__main__":
    main()
