import streamlit as st
import pandas as pd
from pathlib import Path
from shared import apply_common_styles, load_jsonl, render_sidebar_header

# Apply styles and config
apply_common_styles("Spex Apps")

def main():
    # Sidebar navigation
    render_sidebar_header()
    
    st.sidebar.markdown("<div style='margin-bottom: 5px;'></div>", unsafe_allow_html=True)
    if st.sidebar.button("📋 Back to Memory", use_container_width=True):
        st.switch_page("memory.py")
    
    if st.sidebar.button("📊 Analytics Dashboard", use_container_width=True):
        st.switch_page("pages/analytics.py")
    
    st.sidebar.markdown("<div style='margin-top: 15px; margin-bottom: 15px; border-top: 1px solid #30363D;'></div>", unsafe_allow_html=True)

    st.title("🎯 Registered Applications")
    st.markdown("<p style='color: #7D8590; font-size: 1.1rem;'>View and manage applications registered in this project.</p>", unsafe_allow_html=True)
    st.markdown("<div style='margin-bottom: 2rem;'></div>", unsafe_allow_html=True)

    # Load apps
    apps_path = Path(".spex/memory/apps.jsonl")
    apps_data = load_jsonl(apps_path)

    if not apps_data:
        st.info("No applications registered in spex memory.")
        return

    # Filter to latest versions
    latest_apps = {}
    for app in apps_data:
        app_id = app.get('id')
        version = app.get('version', 1)
        if app_id not in latest_apps or version > latest_apps[app_id].get('version', 0):
            latest_apps[app_id] = app
    
    apps_list = list(latest_apps.values())
    
    # Create DataFrame for display
    df = pd.DataFrame(apps_list)
    
    # Select and rename columns for better display
    display_cols = {
        'name': 'Name',
        'id': 'ID',
        'appType': 'Type',
        'status': 'Status',
        'repository': 'Repository',
        'filePath': 'Path',
        'packageManager': 'Package Manager',
        'owner': 'Owner',
        'createdAt': 'Registered At'
    }
    
    # Ensure all display columns exist in the dataframe
    cols_to_show = [c for c in display_cols.keys() if c in df.columns]
    df_display = df[cols_to_show].rename(columns=display_cols)
    
    # Format dates
    if 'Registered At' in df_display.columns:
        df_display['Registered At'] = pd.to_datetime(df_display['Registered At']).dt.strftime('%Y-%m-%d %H:%M')

    # Display table
    st.dataframe(
        df_display,
        use_container_width=True,
        hide_index=True,
        column_config={
            "Repository": st.column_config.LinkColumn("Repository"),
        }
    )

    st.markdown(f"**Total Registered Apps**: {len(apps_list)}")

if __name__ == "__main__":
    main()
