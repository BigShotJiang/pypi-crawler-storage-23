import streamlit as st
from pathlib import Path
import json
from datetime import datetime
import html
from collections import Counter
from shared import apply_common_styles, load_jsonl, load_plans_from_dir, render_sidebar_header
from spex_cli.core.constants import SESSIONS_FILE, METRICS_FILE

# Apply styles and config
apply_common_styles("Spex Analytics")

def render_question_answers_html(questions, answers):
    """Render questions and answers in a nice HTML format."""
    if not questions:
        return ""

    html_parts = []

    for i, q in enumerate(questions):
        if not isinstance(q, dict):
            continue

        question_text = q.get("question", "")
        header = q.get("header", "")
        options = q.get("options", [])
        multi_select = q.get("multiSelect", False)

        # Find the answer for this question (answers dict uses question text as key)
        answer = None
        if isinstance(answers, dict):
            # Try matching by question text
            answer = answers.get(question_text)
            # Fallback: try by index or header
            if not answer:
                answer = answers.get(str(i)) or answers.get(i) or answers.get(header)

        # Question header
        html_parts.append(
            f'<div style="margin-bottom: 16px; padding: 12px; background-color: #161B22; border-left: 3px solid #79C0FF; border-radius: 4px;">'
        )

        if header:
            html_parts.append(
                f'<div style="color: #79C0FF; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px;">{html.escape(header)}</div>'
            )

        html_parts.append(
            f'<div style="color: #E6EDF3; font-size: 0.9rem; margin-bottom: 8px;">{html.escape(question_text)}</div>'
        )

        # Options (if provided)
        if options:
            html_parts.append('<div style="margin-top: 8px; font-size: 0.8rem; color: #7D8590;">')
            for opt in options:
                if isinstance(opt, dict):
                    label = opt.get("label", "")
                    desc = opt.get("description", "")
                    html_parts.append(
                        f'<div style="margin-left: 12px; margin-bottom: 4px;">• {html.escape(label)}'
                    )
                    if desc:
                        html_parts.append(f' <span style="color: #58606E;">— {html.escape(desc)}</span>')
                    html_parts.append('</div>')
            html_parts.append('</div>')

        # Answer
        if answer:
            html_parts.append(
                f'<div style="margin-top: 10px; padding: 8px 12px; background-color: #1C2128; border-radius: 4px; border: 1px solid #30363D;">'
                f'<span style="color: #7D8590; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Answer:</span> '
                f'<span style="color: #22C55E; font-size: 0.85rem; font-weight: 500;">{html.escape(str(answer))}</span>'
                f'</div>'
            )

        html_parts.append('</div>')

    return "".join(html_parts)

def format_event_data(event_type, data):
    """Format event data based on type."""
    if not data:
        return "No data"

    if event_type == "memory_write":
        mem_type = data.get("type", "unknown")
        mem_id = data.get("id", "unknown")
        icons = {
            "requirement": "📋",
            "decision": "🔧",
            "policy": "📜",
            "plan": "📦",
            "trace": "🔗"
        }
        icon = icons.get(mem_type, "📄")
        return f"{icon} {mem_type.capitalize()} {mem_id}"

    elif event_type == "state_transition":
        from_state = data.get("from", "?")
        to_state = data.get("to", "?")
        return f"{from_state} → {to_state}"

    elif event_type == "user_prompt":
        prompt = data.get("prompt", "")
        questions = data.get("questions", [])

        # If there are questions, it's a tool-triggered prompt
        if questions:
            q = questions[0]
            if isinstance(q, dict):
                header = q.get("header")
                question = q.get("question") or q.get("message")
                q_text = f"[{header}] {question}" if header and question else (question or str(q))
            else:
                q_text = str(q)

            preview_q = q_text.replace("\n", " ").strip()
            if len(preview_q) > 30:
                preview_q = preview_q[:27] + "..."

            preview_a = prompt.replace("\n", " ").strip()
            if len(preview_a) > 30:
                preview_a = preview_a[:27] + "..."

            return f"Q: {preview_q} → {preview_a}"

        if prompt:
            # Truncate and clean up prompt for preview
            preview = prompt.replace("\n", " ").strip()
            if len(preview) > 60:
                preview = preview[:57] + "..."
            return f"Prompt: {preview}"
        length = data.get("promptLength", 0)
        return f"Prompt: {length} chars"

    elif event_type == "plan_write":
        operation = data.get("operation", "unknown")
        plan_id = data.get("planId", "")
        return f"{operation.capitalize()} plan {plan_id}"

    else:
        # Fallback: show event type
        return "Event data available (expand to view)"

def render_timeline(metrics):
    """Render timeline using HTML layout with custom CSS without markdown parser conflicts."""
    from collections import defaultdict

    # Group metrics by date
    metrics_by_date = defaultdict(list)
    for metric in metrics:
        timestamp = metric.get("timestamp", "")
        try:
            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            date_str = dt.strftime("%B %d, %Y")  # e.g., "February 25, 2026"
            metrics_by_date[date_str].append((dt, metric))
        except Exception:
            metrics_by_date["Unknown Date"].append((None, metric))

    html_content = []

    # Render each date group
    for date_str in sorted(metrics_by_date.keys(), key=lambda d: metrics_by_date[d][0][0] if metrics_by_date[d][0][0] else datetime.min):
        # Date header
        html_content.append(f'<div class="timeline-header">{html.escape(date_str)}</div>')
        html_content.append('<div class="timeline-container">')

        # Sort metrics within this date by time
        date_metrics = sorted(metrics_by_date[date_str], key=lambda x: x[0] if x[0] else datetime.min)

        for dt, metric in date_metrics:
            event_type = metric.get("event", "unknown")
            data = metric.get("data", {})
            session_id = metric.get("sessionId", "")

            # Event type styling
            type_colors = {
                "memory_write": "#22C55E",      # Green
                "state_transition": "#8B5CF6",  # Purple
                "user_prompt": "#F97316",       # Orange
                "plan_write": "#3B82F6",        # Blue
                "research_summary": "#EC4899", # Pink
                "task_complete": "#FBBF24"     # Amber
            }
            type_color = type_colors.get(event_type, "#79C0FF")

            # Format time (HH:MM only)
            if dt:
                time_str = dt.strftime("%H:%M")
            else:
                time_str = "??:??"

            # Format data based on type
            formatted_data = html.escape(format_event_data(event_type, data))

            # Session ID tag
            tag_html = ""
            if session_id and session_id not in ["", "none"]:
                short_id = html.escape(session_id[:8])
                tag_html = f'<span style="background-color: #30363D; border: 1px solid #30363D; padding: 2px 8px; border-radius: 12px; font-size: 0.7rem; color: #E6EDF3; margin-left: auto;">{short_id}</span>'

            # Check if this is a user_prompt with questions - render nicely, otherwise dump JSON
            if event_type == "user_prompt" and data.get("questions"):
                questions = data.get("questions", [])
                # Answers are stored in the data['answers'] field for AskUserQuestion tool responses
                # Or fallback to prompt field for simple text responses
                answers = data.get("answers", {})

                # If no structured answers but we have a prompt, use that as a fallback
                if not answers:
                    prompt_text = data.get("prompt", "")
                    if prompt_text:
                        # Use prompt as answer for the first question as a fallback
                        if questions and isinstance(questions[0], dict):
                            q_text = questions[0].get("question", "")
                            if q_text:
                                answers = {q_text: prompt_text}

                content_html = render_question_answers_html(questions, answers)

                item_html = (
                    f'<details class="commit-item">'
                    f'<summary style="display: flex; flex-direction: row; align-items: center; gap: 8px;">'
                    f'<code style="background: #161B22; border: 1px solid {type_color}; border-radius: 4px; padding: 2px 6px; font-size: 0.8rem; color: {type_color}; font-family: monospace;">{html.escape(event_type)}</code>'
                    f'<span style="color: #E6EDF3; font-size: 0.85rem;">{formatted_data}</span>'
                    f'<span style="color: #7D8590; font-size: 0.8rem;">• {time_str}</span>'
                    f'{tag_html}'
                    f'</summary>'
                    f'<div style="padding: 12px 16px; background-color: #0D1117; border-top: 1px solid #30363D;">'
                    f'{content_html}'
                    f'</div>'
                    f'</details>'
                )
            else:
                # Dump JSON safely for other event types
                json_str = html.escape(json.dumps(data, indent=2))

                # Format exactly like memory.py to avoid markdown newline parsing errors
                item_html = (
                    f'<details class="commit-item">'
                    f'<summary style="display: flex; flex-direction: row; align-items: center; gap: 8px;">'
                    f'<code style="background: #161B22; border: 1px solid {type_color}; border-radius: 4px; padding: 2px 6px; font-size: 0.8rem; color: {type_color}; font-family: monospace;">{html.escape(event_type)}</code>'
                    f'<span style="color: #E6EDF3; font-size: 0.85rem;">{formatted_data}</span>'
                    f'<span style="color: #7D8590; font-size: 0.8rem;">• {time_str}</span>'
                    f'{tag_html}'
                    f'</summary>'
                    f'<div style="padding: 12px 16px; background-color: #0D1117; border-top: 1px solid #30363D;">'
                    f'<strong style="color: #7D8590; font-size: 0.8rem; display: block; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px;">Data Payload</strong>'
                    f'<pre style="margin: 0; background-color: #161B22; padding: 12px; border-radius: 6px; border: 1px solid #30363D; color: #E6EDF3; font-size: 0.75rem; overflow-x: auto;">'
                    f'<code style="font-family: monospace;">{json_str}</code>'
                    f'</pre>'
                    f'</div>'
                    f'</details>'
                )
            html_content.append(item_html)

        html_content.append('</div>')

    st.markdown("".join(html_content), unsafe_allow_html=True)

def render_metrics_summary(metrics):
    """Render aggregate counts of event types using st.metric cards."""
    if not metrics:
        return

    # Count event types
    counts = Counter(m.get("event", "unknown") for m in metrics)
    
    # Sort by count descending
    sorted_counts = sorted(counts.items(), key=lambda x: x[1], reverse=True)

    # Display in columns (max 6 columns)
    num_cols = min(len(sorted_counts), 6)
    if num_cols > 0:
        cols = st.columns(num_cols)
        for i, (event_type, count) in enumerate(sorted_counts):
            col_idx = i % num_cols
            with cols[col_idx]:
                st.metric(label=event_type, value=count)

def main():
    # Sidebar navigation
    render_sidebar_header()
    
    st.sidebar.markdown("<div style='margin-bottom: 5px;'></div>", unsafe_allow_html=True)
    if st.sidebar.button("📋 Back to Memory", use_container_width=True):
        st.switch_page("memory.py")
    
    if st.sidebar.button("🎯 Apps", use_container_width=True):
        st.switch_page("pages/apps.py")
    
    st.sidebar.markdown("<div style='margin-top: 15px; margin-bottom: 15px; border-top: 1px solid #30363D;'></div>", unsafe_allow_html=True)

    # Get selection from query params
    params = st.query_params
    plan_id = params.get("planId", None)
    session_id = params.get("sessionId", None)

    # If nothing selected, show selector
    if not plan_id and not session_id:
        st.markdown("<div style='margin-top: 4rem;'></div>", unsafe_allow_html=True)
        
        # Center the header
        _, center_col, _ = st.columns([1, 2, 1])
        with center_col:
            st.title("📊 Spex Analytics")
            st.markdown("<p style='color: #7D8590; font-size: 1.1rem;'>Visualize the evolution of your features and development sessions.</p>", unsafe_allow_html=True)
            st.markdown("<div style='margin-bottom: 2rem;'></div>", unsafe_allow_html=True)

        # Center the selection box and limit its width
        _, main_col, _ = st.columns([1, 1.5, 1])
        
        with main_col:
            tab1, tab2 = st.tabs(["📁 By Plan", "🕒 By Session"])

            with tab1:
                st.markdown("<div style='padding: 1rem 0;'>", unsafe_allow_html=True)
                # Load plans from memory only
                all_plans = load_plans_from_dir(".spex/memory/plans")
                
                # Filter to unique IDs
                unique_plans = {}
                for p in all_plans:
                    p_id = p.get("id")
                    if p_id and p_id not in unique_plans:
                        unique_plans[p_id] = p

                plan_options = {}
                for p_id, plan in unique_plans.items():
                    feature = plan.get("featureName", "unknown")
                    plan_options[f"📦 {feature} ({p_id})"] = p_id

                if plan_options:
                    # Add search filter
                    plan_search = st.text_input("🔍 Filter plans by name or ID:", placeholder="Enter keywords...", key="plan_search")
                    
                    # JavaScript to focus and open selectbox on Enter
                    st.components.v1.html(
                        """
                        <script>
                        const inputs = window.parent.document.querySelectorAll('input[data-testid="stTextInput"]');
                        inputs.forEach(input => {
                            input.addEventListener('keydown', function(e) {
                                if (e.key === 'Enter') {
                                    setTimeout(() => {
                                        const selectboxes = window.parent.document.querySelectorAll('div[data-testid="stSelectbox"]');
                                        if (selectboxes.length > 0) {
                                            const firstSelect = selectboxes[0];
                                            firstSelect.click();
                                        }
                                    }, 100);
                                }
                            });
                        });
                        </script>
                        """,
                        height=0,
                    )
                    
                    filtered_plan_labels = list(plan_options.keys())
                    if plan_search:
                        filtered_plan_labels = [label for label in filtered_plan_labels if plan_search.lower() in label.lower()]

                    if filtered_plan_labels:
                        # Auto-select first match if searching
                        selected_plan_label = st.selectbox(
                            "Select a plan:", 
                            options=filtered_plan_labels,
                            index=0,
                            key="plan_select"
                        )
                        st.markdown("<div style='margin-top: 1.5rem;'></div>", unsafe_allow_html=True)
                        if st.button("🚀 View Plan Analytics", key="btn_plan", use_container_width=True):
                            st.query_params["planId"] = plan_options[selected_plan_label]
                            st.rerun()
                    else:
                        st.warning(f"No plans match '{plan_search}'")
                else:
                    st.info("No plans found in .spex/plans/")
                st.markdown("</div>", unsafe_allow_html=True)

            with tab2:
                st.markdown("<div style='padding: 1rem 0;'>", unsafe_allow_html=True)
                sessions_path = Path(SESSIONS_FILE)
                sessions = load_jsonl(sessions_path)
                
                if sessions:
                    # Load metrics once to enrich session labels
                    all_metrics = load_jsonl(Path(METRICS_FILE))
                    # Map sessionId -> first prompt content
                    session_prompts = {}
                    for m in all_metrics:
                        s_id = m.get("sessionId")
                        if s_id and s_id not in session_prompts and m.get("event") == "user_prompt":
                            prompt = m.get("data", {}).get("prompt", "")
                            if prompt:
                                preview = prompt.replace("\n", " ").strip()
                                if len(preview) > 40:
                                    preview = preview[:37] + "..."
                                session_prompts[s_id] = preview

                    # Group and sort sessions by timestamp descending
                    unique_sessions = {}
                    for s in sessions:
                        s_id = s.get("sessionId")
                        if s_id:
                            unique_sessions[s_id] = s
                    
                    sorted_sessions = sorted(unique_sessions.values(), key=lambda x: x.get("timestamp", ""), reverse=True)
                    
                    session_options = {}
                    for s in sorted_sessions:
                        ts = s.get("timestamp", "Unknown")
                        s_id = s.get("sessionId", "Unknown")
                        if ts != "Unknown":
                            try:
                                dt = datetime.fromisoformat(ts.replace('Z', '+00:00'))
                                ts = dt.strftime("%Y-%m-%d %H:%M")
                            except Exception:
                                pass
                        
                        prompt_preview = session_prompts.get(s_id, s_id[:8])
                        label = f"🕒 {ts} - {prompt_preview}"
                        session_options[label] = s_id

                    # Add search filter
                    session_search = st.text_input("🔍 Filter sessions by prompt or date:", placeholder="Enter keywords...", key="session_search")
                    
                    filtered_session_labels = list(session_options.keys())
                    if session_search:
                        filtered_session_labels = [label for label in filtered_session_labels if session_search.lower() in label.lower()]

                    if filtered_session_labels:
                        # Auto-select first match if searching
                        selected_session_label = st.selectbox(
                            "Select a session:", 
                            options=filtered_session_labels,
                            index=0,
                            key="session_select"
                        )
                        st.markdown("<div style='margin-top: 1.5rem;'></div>", unsafe_allow_html=True)
                        if st.button("🔍 View Session Analytics", key="btn_session", use_container_width=True):
                            st.query_params["sessionId"] = session_options[selected_session_label]
                            st.rerun()
                    else:
                        st.warning(f"No sessions match '{session_search}'")
                else:
                    st.info(f"No sessions found in {SESSIONS_FILE}")
                st.markdown("</div>", unsafe_allow_html=True)
        
        return

    # If something is selected, allow clearing it
    if st.sidebar.button("🗑️ Clear Selection"):
        st.query_params.clear()
        st.rerun()

    # Load metrics
    metrics_path = Path(METRICS_FILE)
    all_metrics = load_jsonl(metrics_path)

    plan_metrics = []
    feature_name = None

    if plan_id:
        # Load plans from directory
        plans_dir = Path(".spex/memory/plans")
        plans = load_plans_from_dir(plans_dir)

        # Find the plan's featureName
        for plan in plans:
            if plan.get("id") == plan_id:
                feature_name = plan.get("featureName")
                break

        # First pass: identify session IDs associated with this plan/feature
        session_ids = set()
        for m in all_metrics:
            if (
                (m.get("planId") == plan_id and m.get("planId") not in ["", "none", None])
                or
                (feature_name and m.get("featureName") == feature_name and m.get("featureName") not in ["", "none", None])
            ):
                s_id = m.get("sessionId")
                if s_id and s_id not in ["", "none"]:
                    session_ids.add(s_id)

        # Also include termSessionIds for these session_ids to capture metrics from terminal-based CLI calls
        sessions_path = Path(SESSIONS_FILE)
        sessions = load_jsonl(sessions_path)
        term_ids = {s.get("termSessionId") for s in sessions if s.get("sessionId") in session_ids and s.get("termSessionId")}
        session_ids.update(term_ids)

        # Second pass: Filter by planId, featureName, OR associated session IDs (including termSessionIds)
        plan_metrics = [
            m for m in all_metrics
            if (
                (m.get("planId") == plan_id and m.get("planId") not in ["", "none", None])
                or
                (feature_name and m.get("featureName") == feature_name and m.get("featureName") not in ["", "none", None])
                or
                (m.get("sessionId") in session_ids)
            )
        ]
        title = f"Plan Analytics: {plan_id}"
    
    elif session_id:
        # Find the termSessionId for this session_id from SESSIONS_FILE
        sessions_path = Path(SESSIONS_FILE)
        sessions = load_jsonl(sessions_path)
        term_id = next((s.get("termSessionId") for s in sessions if s.get("sessionId") == session_id), None)
        
        plan_metrics = [
            m for m in all_metrics 
            if m.get("sessionId") == session_id or (term_id and m.get("sessionId") == term_id)
        ]
        title = f"Session Analytics: {session_id[:8]}"

    if not plan_metrics:
        st.warning(f"No metrics found for {'plan ' + plan_id if plan_id else 'session ' + session_id}")
        return

    # Sort by timestamp ascending (oldest first)
    plan_metrics = sorted(plan_metrics, key=lambda x: x.get("timestamp", ""))

    st.title(title)
    if feature_name:
        st.markdown(f"**Feature**: `{feature_name}`")
    st.markdown(f"**Total Events**: {len(plan_metrics)}")
    
    # Render aggregates
    render_metrics_summary(plan_metrics)
    
    st.markdown("---")

    # Render timeline using native Streamlit components
    render_timeline(plan_metrics)

if __name__ == "__main__":
    main()
