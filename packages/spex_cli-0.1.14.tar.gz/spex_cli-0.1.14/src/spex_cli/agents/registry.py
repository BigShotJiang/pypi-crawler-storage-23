AGENT_CONFIG = {
    "claude": {
        "name": "Claude Code",
        "folder": ".claude/",
        "settings_file": "agents/providers/claude/settings.json",
        "settings_dest": "settings.local.json"
    },
    "gemini": {
        "name": "Gemini CLI",
        "folder": ".gemini/",
        "settings_file": "agents/providers/gemini/settings.json",
        "settings_dest": "settings.json"
    },
    "cursor": {
        "name": "Cursor",
        "folder": ".cursor/",
        "settings_file": "agents/providers/cursor/settings.json",
        "settings_dest": "hooks.json"
    },
    "opencode": {
        "name": "opencode",
        "folder": ".opencode/"
    },
    "codex": {
        "name": "Codex CLI",
        "folder": ".codex/"
    },
    "agy": {
        "name": "Antigravity",
        "folder": ".agent/"
    },
    "copilot": {
        "name": "GitHub Copilot",
        "folder": ".github/"
    }
}