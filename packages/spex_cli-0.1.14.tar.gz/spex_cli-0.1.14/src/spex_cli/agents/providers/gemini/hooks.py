import sys
import json
from spex_cli.agents.hooks import base, gemini

def run_hook(event: str):
    """Execution entry point for Gemini hooks."""
    raw_data = base.get_input()
    
    # 1. Translate to unified format
    unified_data = gemini.translate_to_unified(event, raw_data)
    
    # 2. Dispatch based on event
    if event == base.HookEvent.SESSION_START:
        base.export_session_id(unified_data)
        base.record_session(unified_data)
        print("{}")
    elif event == base.HookEvent.INJECT_CONTEXT:
        context = base.inject_memory_context()
        if context:
            # Gemini CLI expects a specific JSON format for context injection
            # In SessionStart, it injects context as the first turn
            print(json.dumps({
                "hookSpecificOutput": {
                    "hookEventName": "SessionStart",
                    "additionalContext": context
                }
            }))
        else:
            print("{}")
    elif event in (base.HookEvent.USER_PROMPT, base.HookEvent.AFTER_TOOL):
        base.emit_interaction_metrics(unified_data)
        print("{}")

def main():
    if len(sys.argv) < 2:
        return
    run_hook(sys.argv[1])

if __name__ == "__main__":
    main()
