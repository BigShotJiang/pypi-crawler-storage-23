from typing import TypedDict, Any, Optional, Dict, Literal
from . import base
from .base import UnifiedHookData

# --- Claude Code Contracts ---

class ClaudeBaseInput(TypedDict):
    session_id: str
    transcript_path: str
    cwd: str
    hook_event_name: str
    permission_mode: str

class ClaudeSessionStartInput(ClaudeBaseInput):
    source: Literal["startup", "resume", "clear", "compact"]
    model: str
    agent_type: Optional[str]

class ClaudeUserPromptSubmitInput(ClaudeBaseInput):
    prompt: str

class ClaudePostToolUseInput(ClaudeBaseInput):
    tool_name: str
    tool_input: Dict[str, Any]
    tool_response: Any
    tool_use_id: str

# --- Translator ---

def translate_to_unified(event: str, data: Any) -> UnifiedHookData:
    unified: UnifiedHookData = {
        "event": event,
        "session_id": data.get("session_id", ""),
        "transcript_path": data.get("transcript_path", ""),
        "cwd": data.get("cwd", ""),
        "prompt": None,
        "questions": None,
        "tool_name": None,
        "tool_input": None,
        "tool_response_text": None,
        "source": data.get("source"),
        "model": data.get("model")
    }

    if event == base.HookEvent.USER_PROMPT:
        unified["prompt"] = data.get("prompt")
    
    elif event == base.HookEvent.AFTER_TOOL:
        unified["tool_name"] = data.get("tool_name")
        unified["tool_input"] = data.get("tool_input")

        if unified["tool_name"] == "AskUserQuestion" and unified["tool_input"]:
            # Extract questions array from tool input
            questions = unified["tool_input"].get("questions", [])
            if questions:
                unified["questions"] = questions
            else:
                # Fallback for legacy single-question format
                q = unified["tool_input"].get("question")
                if q:
                    unified["questions"] = [q]

        tool_resp = data.get("tool_response", {})
        if unified["tool_name"] == "AskUserQuestion":
            if isinstance(tool_resp, dict) and "answers" in tool_resp:
                answers = tool_resp.get("answers", {})
                if isinstance(answers, dict):
                    unified["answers"] = answers
                    unified["tool_response_text"] = base.format_tool_answers(unified["questions"], answers)

            if not unified["tool_response_text"]:
                unified["tool_response_text"] = str(tool_resp)

    return unified
