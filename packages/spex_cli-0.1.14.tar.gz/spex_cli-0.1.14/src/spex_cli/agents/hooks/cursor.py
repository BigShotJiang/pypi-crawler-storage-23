import json
from typing import TypedDict, Any, Optional, Dict, List
from . import base
from .base import UnifiedHookData

# --- Cursor Hook Contracts ---

class CursorBaseInput(TypedDict):
    conversation_id: str
    model: str
    hook_event_name: str
    workspace_roots: List[str]
    cursor_version: str
    transcript_path: Optional[str]

class CursorSessionStartInput(CursorBaseInput):
    pass

class CursorBeforeSubmitPromptInput(CursorBaseInput):
    prompt: str

class CursorPostToolUseInput(CursorBaseInput):
    tool_name: str
    tool_input: Dict[str, Any]
    tool_output: Any
    tool_use_id: str
    cwd: str
    duration: int

# --- Translator ---

def translate_to_unified(event: str, data: Any) -> UnifiedHookData:
    # Prefer explicit 'cwd' field if available, otherwise fallback to workspace_roots
    cwd = data.get("cwd") or (data.get("workspace_roots", [""])[0] if data.get("workspace_roots") else "")
    
    unified: UnifiedHookData = {
        "event": event,
        "session_id": data.get("conversation_id", ""),
        "transcript_path": data.get("transcript_path", ""),
        "cwd": cwd,
        "prompt": None,
        "questions": None,
        "tool_name": None,
        "tool_input": None,
        "answers": None,
        "tool_response_text": None,
        "source": None,
        "model": data.get("model")
    }

    if event == base.HookEvent.USER_PROMPT:
        unified["prompt"] = data.get("prompt")
    
    elif event == base.HookEvent.AFTER_TOOL:
        unified["tool_name"] = data.get("tool_name")
        unified["tool_input"] = data.get("tool_input")
        
        tool_output = data.get("tool_output", "")
        if isinstance(tool_output, dict):
            unified["answers"] = tool_output
        elif isinstance(tool_output, str):
            try:
                # Try to parse JSON if it's a string, might be structured answers
                parsed = json.loads(tool_output)
                if isinstance(parsed, dict):
                    unified["answers"] = parsed
            except Exception:
                pass
        
        if unified["answers"]:
             unified["tool_response_text"] = base.format_tool_answers(unified["questions"], unified["answers"])
        else:
             unified["tool_response_text"] = str(tool_output)
        
        if unified["tool_input"]:
            # Try a few common keys for questions/messages
            qs = (
                unified["tool_input"].get("question") or 
                unified["tool_input"].get("questions") or 
                unified["tool_input"].get("message") or 
                unified["tool_input"].get("text")
            )
            if isinstance(qs, list):
                unified["questions"] = qs
            elif qs:
                unified["questions"] = [qs]

    return unified
