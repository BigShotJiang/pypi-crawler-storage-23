import json
from typing import TypedDict, Any, Optional, Dict, Literal
from . import base
from .base import UnifiedHookData

# --- Gemini CLI Contracts ---

class GeminiToolResponse(TypedDict):
    llmContent: str
    returnDisplay: str
    error: Optional[str]

class GeminiBaseInput(TypedDict):
    session_id: str
    transcript_path: str
    cwd: str
    hook_event_name: str
    timestamp: str

class GeminiSessionStartInput(GeminiBaseInput):
    source: Literal["startup", "resume", "clear"]

class GeminiBeforeAgentInput(GeminiBaseInput):
    prompt: str

class GeminiAfterToolInput(GeminiBaseInput):
    tool_name: str
    tool_input: Dict[str, Any]
    tool_response: GeminiToolResponse
    mcp_context: Optional[Dict[str, Any]]
    original_request_name: Optional[str]

# --- Translator ---

def translate_to_unified(event: str, data: Any) -> UnifiedHookData:
    unified: UnifiedHookData = {
        "event": event,
        "session_id": data.get("session_id", ""),
        "transcript_path": data.get("transcript_path", ""),
        "cwd": data.get("cwd", ""),
        "prompt": None,
        "questions": None,
        "tool_name": None,
        "tool_input": None,
        "tool_response_text": None,
        "source": data.get("source"),
        "model": data.get("model")
    }

    if event == base.HookEvent.USER_PROMPT:
        unified["prompt"] = data.get("prompt")
    
    elif event == base.HookEvent.AFTER_TOOL:
        unified["tool_name"] = data.get("tool_name")
        unified["tool_input"] = data.get("tool_input")
        
        if unified["tool_name"] == "ask_user" and unified["tool_input"]:
            # Extract questions from tool_input
            qs = unified["tool_input"].get("questions", [])
            if isinstance(qs, list):
                unified["questions"] = qs
            elif isinstance(qs, str):
                unified["questions"] = [qs]
            elif qs:
                unified["questions"] = [qs]
        
        tool_resp = data.get("tool_response", {})
        if unified["tool_name"] == "ask_user":
            # Extract answers from Gemini structure
            answers = tool_resp.get("answers")
            
            # Fallback to llmContent parsing
            if not answers and "llmContent" in tool_resp:
                try:
                    content = json.loads(tool_resp["llmContent"])
                    if isinstance(content, dict) and "answers" in content:
                        answers = content["answers"]
                except Exception:
                    pass

            if isinstance(answers, dict):
                unified["answers"] = answers
                unified["tool_response_text"] = base.format_tool_answers(unified["questions"], answers)
            elif not unified["tool_response_text"] and "llmContent" in tool_resp:
                unified["tool_response_text"] = str(tool_resp["llmContent"])

    return unified
