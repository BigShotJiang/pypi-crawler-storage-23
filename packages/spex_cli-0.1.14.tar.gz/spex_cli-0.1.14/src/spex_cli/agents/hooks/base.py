import sys
import json
import os
from datetime import datetime
from typing import TypedDict, Optional, Dict, Any, List
from enum import Enum
from pathlib import Path

# --- Unified Contract ---

class HookEvent(str, Enum):
    SESSION_START = "session_start"
    INJECT_CONTEXT = "inject_context"
    USER_PROMPT = "user_prompt"
    AFTER_TOOL = "after_tool"

class UnifiedHookData(TypedDict):
    """Unified internal representation of hook data across all agents."""
    event: str
    session_id: str
    transcript_path: str
    cwd: str
    prompt: Optional[str]
    questions: Optional[List[Any]]
    answers: Optional[Dict[str, Any]]
    tool_name: Optional[str]
    tool_input: Optional[Dict[str, Any]]
    tool_response_text: Optional[str]
    source: Optional[str]
    model: Optional[str]

# --- Shared Helpers ---

def get_input() -> Dict[str, Any]:
    """Read JSON from stdin."""
    try:
        content = sys.stdin.read()
        if not content:
            return {}
        return json.loads(content)
    except json.JSONDecodeError:
        return {}

def format_tool_answers(questions: Optional[List[Any]], answers: Optional[Dict[str, Any]]) -> Optional[str]:
    """Formats structured answers into a readable string, pairing them with question headers if possible."""
    if not answers:
        return None
    
    if not questions:
        return " | ".join(str(v) for v in answers.values())
    
    formatted_parts = []
    # If answers is keyed by "0", "1", etc. and matches questions length
    for i, q in enumerate(questions):
        # Try finding answer by index (str or int) or specific key if q is a dict
        ans = answers.get(str(i)) or answers.get(i)
        
        # Fallback for Claude/Gemini specific keys if they exist
        if ans is None and isinstance(q, dict):
            q_id = q.get("id")
            if q_id:
                ans = answers.get(q_id)
        
        if ans is not None:
            header = None
            if isinstance(q, dict):
                header = q.get("header") or q.get("label")
            
            if header:
                formatted_parts.append(f"[{header}] {ans}")
            else:
                formatted_parts.append(str(ans))
    
    if not formatted_parts:
        return " | ".join(str(v) for v in answers.values())
        
    return " | ".join(formatted_parts)

def export_session_id(data: UnifiedHookData):
    """Persists session_id to the agent's environment file."""
    session_id = data.get("session_id")
    # Both platforms use similar env file patterns for session-scoped vars
    env_file = os.environ.get("CLAUDE_ENV_FILE") or os.environ.get("GEMINI_ENV_FILE")
    
    if env_file and session_id:
        try:
            with open(env_file, "a") as f:
                f.write(f"\nSPEX_SESSION_ID={session_id}\n")
        except Exception:
            pass

def record_session(data: UnifiedHookData):
    """Saves session metadata to ~/.spex/debug/sessions.jsonl."""
    from spex_cli.core.constants import SESSIONS_FILE
    
    session_id = data.get("session_id")
    if not session_id:
        return

    record = {
        "sessionId": session_id,
        "transcriptPath": data.get("transcript_path"),
        "cwd": data.get("cwd"),
        "source": data.get("source"),
        "timestamp": datetime.now().isoformat(),
        "termSessionId": os.environ.get("TERM_SESSION_ID"),
    }
    
    try:
        path = Path(SESSIONS_FILE)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "a") as f:
            f.write(json.dumps(record) + "\n")
    except Exception:
        pass

def inject_memory_context() -> str:
    """Returns init.md content, active policies and apps for agent context injection."""
    from spex_cli.core.constants import POLICIES_FILE, APPS_FILE
    from spex_cli.core.utils import run_jq

    lines = []

    # 0. Init Guidelines
    # Core package-level guidelines (Workflow Policy)
    pkg_init_md = Path(__file__).parent.parent.parent / "templates" / "skills" / "init.md"
    if pkg_init_md.exists():
        try:
            lines.append(pkg_init_md.read_text())
            lines.append("\n---\n")
        except Exception:
            pass

    # 1. Policies
    if Path(POLICIES_FILE).exists():
        try:
            active_policies = run_jq('select(.status == "active")', POLICIES_FILE)
            if active_policies:
                lines.append("\n<active_policies>")
                for p in active_policies:
                    rationale = f" (Rationale: {p['rationale']})" if p.get('rationale') else ""
                    lines.append(f"- {p['id']}: {p['description']}{rationale}")
                lines.append("</active_policies>")
        except Exception:
            pass

    # 2. Apps
    if Path(APPS_FILE).exists():
        try:
            active_apps = run_jq('select(.status == "active")', APPS_FILE)
            if active_apps:
                lines.append("\n<active_applications>")
                for a in active_apps:
                    app_type = a.get('appType', 'app')
                    lines.append(f"- {a['name']} ({app_type}): Located at '{a['filePath']}'")
                lines.append("</active_applications>")
        except Exception:
            pass
    
    return "\n".join(lines)

def emit_interaction_metrics(data: UnifiedHookData):
    """Emits metrics for user prompts or tool-based answers."""
    from spex_cli.commands.metrics import emit_metric

    # Unified interaction text: either the direct prompt or the user's answer to a tool question
    interaction_text = data.get("prompt") or data.get("tool_response_text")

    if interaction_text:
        metric_data = {
            "prompt": interaction_text,
            "promptLength": len(interaction_text)
        }

        # Include questions if present
        if data.get("questions"):
            metric_data["questions"] = data.get("questions")

        # Include answers if present (from AskUserQuestion tool)
        if data.get("answers"):
            metric_data["answers"] = data.get("answers")

        emit_metric(
            event="user_prompt",
            data=metric_data,
            session_id=data.get("session_id")
        )
