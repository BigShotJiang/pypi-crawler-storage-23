"""Shared constants for spex."""

import os
import subprocess
from pathlib import Path

DECISION_ID_TRAILER = "decision-id"

# Global paths
HOME_SPEX_DIR = Path(os.environ.get("SPEX_HOME", str(Path.home() / ".spex")))

def get_project_identifier(cwd: str = None) -> str:
    """
    Get a unique identifier for the current project.
    Tries to use git repo name, falls back to directory basename.

    Args:
        cwd: Working directory to identify. Defaults to os.getcwd()

    Returns:
        Project identifier string (e.g., "spex", "my-project")
    """
    if cwd is None:
        cwd = os.getcwd()

    # Try to get git repo name
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=2
        )
        if result.returncode == 0:
            repo_path = result.stdout.strip()
            return Path(repo_path).name
    except Exception:
        pass

    # Fallback to directory basename
    return Path(cwd).name

def get_project_debug_dir(cwd: str = None) -> Path:
    """Get the debug directory for the current project."""
    project_id = get_project_identifier(cwd)
    return HOME_SPEX_DIR / "debug" / project_id

# Project-specific debug paths (computed at runtime)
DEBUG_DIR = get_project_debug_dir()

REQUIREMENTS_FILE = ".spex/memory/requirements.jsonl"
DECISIONS_FILE = ".spex/memory/decisions.jsonl"
POLICIES_FILE = ".spex/memory/policies.jsonl"
PLANS_DIR = ".spex/memory/plans"
TRACES_FILE = ".spex/memory/traces.jsonl"
APPS_FILE = ".spex/memory/apps.jsonl"
METRICS_FILE = str(DEBUG_DIR / "metrics.jsonl")
SESSIONS_FILE = str(DEBUG_DIR / "sessions.jsonl")
SESSION_ID_ENV = "SPEX_SESSION_ID"
TERM_SESSION_ID = "TERM_SESSION_ID"
