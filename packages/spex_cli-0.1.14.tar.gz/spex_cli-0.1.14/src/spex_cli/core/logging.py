import json
import logging
from datetime import datetime
from logging.handlers import RotatingFileHandler
import traceback

from spex_cli.core.constants import DEBUG_DIR

class JsonFormatter(logging.Formatter):
    """Custom JSON formatter for logging"""
    def __init__(self, get_session_id_func=None):
        super().__init__()
        self.get_session_id = get_session_id_func

    def format(self, record):
        log_entry = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "name": record.name,
            "message": record.getMessage(),
        }
        
        if self.get_session_id:
            try:
                log_entry["session_id"] = self.get_session_id()
            except Exception:
                log_entry["session_id"] = "unknown"

        if record.exc_info:
            log_entry["traceback"] = self.formatException(record.exc_info)
        elif record.levelno >= logging.ERROR:
            # For errors without exc_info, include the current call stack
            log_entry["stack"] = "".join(traceback.format_stack())

        return json.dumps(log_entry)

def setup_logging(get_session_id_func=None):
    """Configure standard python logging to ~/.spex/debug/errors.log"""
    DEBUG_DIR.mkdir(parents=True, exist_ok=True)
    log_file = DEBUG_DIR / "errors.log"
    
    logger = logging.getLogger()
    logger.setLevel(logging.ERROR)
    
    # Avoid adding multiple handlers if setup is called multiple times
    if not logger.handlers:
        handler = RotatingFileHandler(log_file, maxBytes=10*1024*1024, backupCount=5)
        handler.setFormatter(JsonFormatter(get_session_id_func=get_session_id_func))
        logger.addHandler(handler)
