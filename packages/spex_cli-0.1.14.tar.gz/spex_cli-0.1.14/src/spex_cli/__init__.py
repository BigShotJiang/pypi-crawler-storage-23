from rich.align import Align
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from spex_cli.main import main as _main, __version__

_BANNER_LINES = [
    " ███████╗██████╗ ███████╗██╗  ██╗",
    " ██╔════╝██╔══██╗██╔════╝╚██╗██╔╝",
    " ███████╗██████╔╝█████╗   ╚███╔╝ ",
    " ╚════██║██╔═══╝ ██╔══╝   ██╔██╗ ",
    " ███████║██║     ███████╗██╔╝ ██╗",
    " ╚══════╝╚═╝     ╚══════╝╚═╝  ╚═╝",
]

_ROW_COLORS = [
    "#F97316",
    "#F97316",
    "#FBBF24",
    "#FBBF24",
    "#EC4899",
    "#EC4899",
]


def print_banner() -> None:
    console = Console(stderr=True)

    art = Text(justify="center")
    for i, (line, color) in enumerate(zip(_BANNER_LINES, _ROW_COLORS)):
        art.append(line, style=f"bold {color}")
        if i < len(_BANNER_LINES) - 1:
            art.append("\n")

    subtitle = Text(justify="center")
    subtitle.append("Autonomous Engineering experience", style="bold #8B5CF6")
    subtitle.append("  ·  ", style="dim")
    subtitle.append(f"v{__version__}", style="#FBBF24")

    console.print(
        Panel(
            Align.center(Text.assemble(art, "\n\n", subtitle)),
            border_style="#8B5CF6",
            padding=(1, 4),
        )
    )


_BANNER_COMMANDS = frozenset({"healthcheck", "enable", "disable"})


def _should_show_banner() -> bool:
    import sys
    args = sys.argv[1:]
    if not args:
        return True
    first = args[0]
    if first in ("-h", "--help", "--version"):
        return True
    if first in _BANNER_COMMANDS:
        return True
    return False


def main() -> None:
    import sys
    if "--version" in sys.argv:
        print(f"spex version {__version__}")
        sys.exit(0)

    if _should_show_banner():
        print_banner()
    _main()
