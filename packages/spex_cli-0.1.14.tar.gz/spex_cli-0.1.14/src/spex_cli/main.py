#!/usr/bin/env python3
"""
spex - CLI tool for managing requirements and decisions

Handles write operations (add, deprecate) only.
Read operations should use native tools (grep, jq, cat).
Conflict detection is handled by the agent's intelligence in the historical-context-analyzer skill.
"""

import json
import os
import subprocess
import sys
import uuid
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Type, TypeVar
from dataclasses import asdict
import re
import logging
import traceback



import typer
import click
from typing_extensions import Annotated

from spex_cli.commands.enable import run_enable
from spex_cli.commands.disable import run_disable
from spex_cli.commands.blame import blame_targets
from spex_cli.commands.debug import run_debug

import importlib.metadata

try:
    __version__ = importlib.metadata.version("spex-cli")
except importlib.metadata.PackageNotFoundError:
    __version__ = "unknown"

# Import data models
from spex_cli.core.models import (
    Requirement, Decision, Policy, Plan, App,
    validate_requirement_type, validate_decision_class
)
from spex_cli.core.constants import (
    REQUIREMENTS_FILE, DECISIONS_FILE, POLICIES_FILE,
    PLANS_DIR, APPS_FILE
)
from spex_cli.core.utils import run_jq, get_latest_active_jq, ValidationError, ReferenceError
from spex_cli.commands.metrics import emit_metric, get_session_id, report_metrics
from spex_cli.core.logging import setup_logging

# Type variable for generic operations
T = TypeVar('T')

app = typer.Typer(
    rich_markup_mode="rich",
    epilog="Run [bold #F97316]spex[/bold #F97316] [dim]<command> --help for more information.[/dim]"
)
def version_callback(value: bool):
    if value:
        print(f"spex {__version__}")
        raise typer.Exit()

@app.callback(invoke_without_command=True)
def main_callback(
    ctx: typer.Context,
    version: Annotated[
        Optional[bool], typer.Option("--version", callback=version_callback, help="Show version", is_eager=True)
    ] = None,
):
    if ctx.invoked_subcommand is None and not version:
        # Print SPEX banner
        from spex_cli import print_banner
        print_banner()
        print(ctx.get_help())
        raise typer.Exit()



req_app = typer.Typer(help="Requirement operations")
app.add_typer(req_app, name="requirement", rich_help_panel="Memory")

dec_app = typer.Typer(help="Decision operations")
app.add_typer(dec_app, name="decision", rich_help_panel="Memory")

pol_app = typer.Typer(help="Policy operations")
app.add_typer(pol_app, name="policy", rich_help_panel="Memory")

app_app = typer.Typer(help="App/Library operations")
app.add_typer(app_app, name="app", rich_help_panel="Memory")

plan_app = typer.Typer(help="Plan operations")
app.add_typer(plan_app, name="plan", rich_help_panel="Memory")

trace_app = typer.Typer(help="Decision trace operations")
app.add_typer(trace_app, name="trace", rich_help_panel="System")

metric_app = typer.Typer(help="Analytics telemetry operations", hidden=True)
app.add_typer(metric_app, name="metric", rich_help_panel="System")





def get_git_author() -> str:
    """Get the current git author (name or email)"""
    try:
        # 1. Try to get user name directly
        result = subprocess.run(['git', 'config', 'user.name'], capture_output=True, text=True)
        name = result.stdout.strip()
        if name:
            return name
            
        # 2. Fallback to GIT_AUTHOR_IDENT which is more robust
        # Format: Name <email> timestamp timezone
        result = subprocess.run(['git', 'var', 'GIT_AUTHOR_IDENT'], capture_output=True, text=True)
        ident = result.stdout.strip()
        if ident:
            # Extract name from "Name <email> ..."
            name_match = re.match(r'^(.*?) <', ident)
            if name_match:
                name = name_match.group(1).strip()
                if name:
                    return name
            
            # Extract email if name is empty
            email_match = re.search(r'<(.*?)>', ident)
            if email_match:
                return email_match.group(1).strip()
        
        # 3. Last resort fallback to email from config
        result = subprocess.run(['git', 'config', 'user.email'], capture_output=True, text=True)
        email = result.stdout.strip()
        if email:
            return email
    except Exception:
        pass
    return "ai"






def ensure_file_exists(filepath: str) -> None:
    """Create file and parent directories if they don't exist"""
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.touch()


def read_jsonl(filepath: str, model: Type[T]) -> List[T]:
    """Read all entries from a JSONL file and parse into dataclass instances"""
    ensure_file_exists(filepath)
    entries = []
    with open(filepath, 'r') as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if line:
                try:
                    data = json.loads(line)
                    entries.append(model.from_dict(data))
                except (json.JSONDecodeError, ValueError, KeyError) as e:
                    raise ValidationError(f"Error parsing line {line_num} in {filepath}: {e}")
    return entries


def verify_jsonl(filepath: str, model: Type[T]) -> int:
    """Verify all entries in a JSONL file without loading all into memory. Returns count."""
    ensure_file_exists(filepath)
    count = 0
    with open(filepath, 'r') as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if line:
                try:
                    data = json.loads(line)
                    # This validates schema via __post_init__ without storing the object
                    model.from_dict(data)
                    count += 1
                except (json.JSONDecodeError, ValueError, KeyError) as e:
                    raise ValidationError(f"Error parsing line {line_num} in {filepath}: {e}")
    return count

def append_jsonl(filepath: str, entry: object) -> None:
    """Append a dataclass entry to a JSONL file, ensuring proper newline separation"""
    ensure_file_exists(filepath)
    path = Path(filepath)
    # Ensure file ends with newline before appending
    if path.stat().st_size > 0:
        with open(filepath, 'rb') as f:
            f.seek(-1, 2)
            if f.read(1) != b'\n':
                with open(filepath, 'a') as fa:
                    fa.write('\n')
    with open(filepath, 'a') as f:
        # Convert dataclass to dict, then to JSON
        entry_dict = asdict(entry) if hasattr(entry, '__dataclass_fields__') else entry
        f.write(json.dumps(entry_dict) + '\n')


def rewrite_jsonl(filepath: str, entries: List[object]) -> None:
    """Rewrite a JSONL file with updated dataclass entries"""
    ensure_file_exists(filepath)
    with open(filepath, 'w') as f:
        for entry in entries:
            # Convert dataclass to dict, then to JSON
            entry_dict = asdict(entry) if hasattr(entry, '__dataclass_fields__') else entry
            f.write(json.dumps(entry_dict) + '\n')


def get_latest_version(entries: List[T], entry_id: str) -> Optional[T]:
    """Get the latest version of an entry by ID"""
    matching = [e for e in entries if e.id == entry_id]
    if not matching:
        return None
    return max(matching, key=lambda e: e.version)


def get_active_entries(entries: List[T]) -> List[T]:
    """Filter to only active entries (latest version with status=active)"""
    active = []
    entry_ids = set(e.id for e in entries)
    for entry_id in entry_ids:
        latest = get_latest_version(entries, entry_id)
        if latest and latest.status == 'active':
            active.append(latest)
    return active


def validate_references(ref_ids: List[str], filepath: str, ref_type: str, model: Type[T]) -> None:
    """Validate that referenced IDs exist and are active"""
    if not ref_ids:
        return
    
    entries = read_jsonl(filepath, model)
    active = get_active_entries(entries)
    active_ids = set(e.id for e in active)
    
    for ref_id in ref_ids:
        if ref_id not in active_ids:
            raise ReferenceError(f"{ref_type} '{ref_id}' does not exist or is not active")


def validate_apps(app_names: List[str]) -> None:
    """Validate that scoped apps exist"""
    if not app_names:
        return
    
    apps = read_jsonl(APPS_FILE, App)
    active_apps = get_active_entries(apps)
    active_app_names = set(a.name.lower() for a in active_apps)
    
    for app_name in app_names:
        if app_name not in active_app_names:
            raise ReferenceError(f"App '{app_name}' does not exist or is not active")


def check_orphaned_references(entry_id: str, entry_type: str) -> List[str]:
    """Check if deprecating this entry will orphan any references"""
    warnings = []
    
    if entry_type == 'requirement':
        # Check if any active decisions reference this requirement
        decisions = read_jsonl(DECISIONS_FILE, Decision)
        active_decisions = get_active_entries(decisions)
        for decision in active_decisions:
            if entry_id in decision.satisfies:
                warnings.append(f"Decision {decision.id} still references {entry_id}")
        
        # Check if any active policies reference this requirement
        policies = read_jsonl(POLICIES_FILE, Policy)
        active_policies = get_active_entries(policies)
        for policy in active_policies:
            if entry_id in policy.satisfies:
                warnings.append(f"Policy {policy.id} still references {entry_id}")

    elif entry_type == 'policy':
        # Check if any active decisions reference this policy
        decisions = read_jsonl(DECISIONS_FILE, Decision)
        active_decisions = get_active_entries(decisions)
        for decision in active_decisions:
            if entry_id in decision.satisfiesPolicies:
                warnings.append(f"Decision {decision.id} still references policy {entry_id}")
    
    # Note: No need to check requirements when deprecating decisions
    # since requirements no longer have satisfiedBy field
    
    return warnings


@req_app.command("add")
def add_requirement(
    type: Annotated[str, typer.Option(..., help="Requirement Category: FR, NFR, CR, UR", click_type=click.Choice(['FR', 'NFR', 'CR', 'UR']))],
    description: Annotated[str, typer.Option(..., help="Clear, testable statement")],
    source: Annotated[str, typer.Option(..., help="Where this requirement came from")],
    acceptance_criteria: Annotated[str, typer.Option(..., help="Step-by-step instructions")],
    plan_id: Annotated[Optional[str], typer.Option(help="Plan ID")] = None,
    scope: Annotated[Optional[str], typer.Option(help="Comma-separated list (e.g., app1,app2)")] = None
) -> None:
    """Add a new requirement"""
    # Auto-generate ID
    req_id = get_next_requirement_id(type)

    # Create Requirement instance (validation happens in __post_init__)
    requirement = Requirement(
        id=req_id,
        version=1,
        status='active',
        createdAt=datetime.now().isoformat(),
        author=get_git_author(),
        planId=plan_id,
        type=type,
        description=description,
        source=source,
        acceptanceCriteria=acceptance_criteria,
        scope=[s.strip().replace(' ', '-').lower() for s in scope.split(',')] if scope else []
    )

    # Validate apps if scope provided
    validate_apps(requirement.scope)

    # Append to file
    append_jsonl(REQUIREMENTS_FILE, requirement)
    print(f"✓ Added requirement {req_id} (v1)")
    emit_metric("memory_write", {"type": "requirement", "id": req_id},
                feature_name="", plan_id=plan_id or "", session_id=get_session_id())


@req_app.command("deprecate")
def deprecate_requirement(
    id: Annotated[str, typer.Option(..., help="Requirement ID")],
    reason: Annotated[str, typer.Option(..., help="Deprecation reason")],
    superseded_by: Annotated[Optional[str], typer.Option(help="ID of replacement requirement")] = None
) -> None:
    """Deprecate a requirement (updates all versions)"""
    requirements = read_jsonl(REQUIREMENTS_FILE, Requirement)
    latest = get_latest_version(requirements, id)

    if not latest:
        raise ValidationError(f"Requirement {id} does not exist")

    if latest.status != 'active':
        raise ValidationError(f"Requirement {id} is already deprecated")

    # Check for orphaned references
    warnings = check_orphaned_references(id, 'requirement')

    now = datetime.now().isoformat()

    # Update all existing versions of this ID to deprecated
    for entry in requirements:
        if entry.id == id and entry.status == 'active':
            entry.status = 'deprecated'
            entry.deprecatedAt = now
            entry.deprecatedReason = reason
            if superseded_by:
                entry.supersededBy = superseded_by

    # Create new version as the canonical deprecation record
    new_version = Requirement(
        id=latest.id,
        version=latest.version + 1,
        status='deprecated',
        createdAt=latest.createdAt,
        author=latest.author,
        planId=latest.planId,
        type=latest.type,
        description=latest.description,
        source=latest.source,
        acceptanceCriteria=latest.acceptanceCriteria,
        deprecatedAt=now,
        deprecatedReason=reason,
        supersededBy=superseded_by if superseded_by else None
    )
    requirements.append(new_version)

    # Rewrite file with all versions updated
    rewrite_jsonl(REQUIREMENTS_FILE, requirements)
    print(f"✓ Deprecated requirement {id} (v{latest.version} → v{new_version.version})")

    for warning in warnings:
        print(f"⚠ Warning: {warning}", file=sys.stderr)
    emit_metric("memory_write", {"type": "requirement_deprecate", "id": id},
                feature_name="", plan_id=latest.planId or "", session_id=get_session_id())


@req_app.command("update")
def update_requirement(
    id: Annotated[str, typer.Option(..., help="Requirement ID")],
    description: Annotated[Optional[str], typer.Option(help="New description")] = None,
    source: Annotated[Optional[str], typer.Option(help="New source")] = None,
    acceptance_criteria: Annotated[Optional[str], typer.Option(help="New acceptance criteria")] = None,
    scope: Annotated[Optional[str], typer.Option(help="New comma-separated app names")] = None
) -> None:
    """Update a requirement (creates new version)"""
    requirements = read_jsonl(REQUIREMENTS_FILE, Requirement)
    latest = get_latest_version(requirements, id)

    if not latest:
        raise ValidationError(f"Requirement {id} does not exist")

    if latest.status != 'active':
        raise ValidationError(f"Requirement {id} is not active")

    # Parse and validate new scope if provided
    new_scope = latest.scope
    if scope is not None:
        new_scope = [s.strip().replace(' ', '-').lower() for s in scope.split(',') if s.strip()]
        validate_apps(new_scope)

    # Create new version with updated fields
    new_version = Requirement(
        id=latest.id,
        version=latest.version + 1,
        status=latest.status,
        createdAt=latest.createdAt,
        author=get_git_author(),
        planId=latest.planId,
        type=latest.type,
        description=description if description is not None else latest.description,
        source=source if source is not None else latest.source,
        acceptanceCriteria=acceptance_criteria if acceptance_criteria is not None else latest.acceptanceCriteria,
        scope=new_scope
    )

    # Mark old active versions as superseded
    for entry in requirements:
        if entry.id == id and entry.status == 'active':
            entry.status = 'superseded'
            entry.supersededBy = f"v{new_version.version}"

    requirements.append(new_version)

    # Rewrite file
    rewrite_jsonl(REQUIREMENTS_FILE, requirements)
    print(f"✓ Updated requirement {id} (v{latest.version} → v{new_version.version})")
    emit_metric("memory_write", {"type": "requirement_update", "id": id},
                feature_name="", plan_id=latest.planId or "", session_id=get_session_id())


@dec_app.command("add")
def add_decision(
    proposal: Annotated[str, typer.Option(..., help="Clear description of the technical implementation")],
    rationale: Annotated[str, typer.Option(..., help="Justification for approach")],
    alternatives: Annotated[Optional[str], typer.Option(..., help="What else was considered")],
    satisfies: Annotated[Optional[str], typer.Option(help="Comma-separated req IDs")] = None,
    decision_class: Annotated[str, typer.Option(..., help="architectural, structural, tactical", click_type=click.Choice(['architectural', 'structural', 'tactical']))] = "tactical",
    impact: Annotated[Optional[str], typer.Option(help="JSON string mapping impact")] = None,
    satisfies_policies: Annotated[Optional[str], typer.Option(help="Comma-separated policy IDs")] = None,
    grounding: Annotated[Optional[str], typer.Option(help="JSON object mapping memory IDs")] = None,
    scope: Annotated[Optional[str], typer.Option(help="Comma-separated list active app names")] = None
) -> None:
    """Add a new decision"""
    # Parse satisfies
    satisfies_list = [s.strip() for s in satisfies.split(',')] if satisfies else []

    # Validate requirement references
    if satisfies_list:
        validate_references(satisfies_list, REQUIREMENTS_FILE, "Requirement", Requirement)

    # Validate decision class (now required)
    validate_decision_class(decision_class)

    # Parse satisfiesPolicies
    satisfies_policies_list = [p.strip() for p in satisfies_policies.split(',')] if satisfies_policies else []
    if satisfies_policies_list:
        validate_references(satisfies_policies_list, POLICIES_FILE, "Policy", Policy)

    # Auto-generate ID
    dec_id = get_next_decision_id()

    # Attempt to parse impact as JSON for structured data
    impact_data = impact
    try:
        impact_data = json.loads(impact) if impact else None
    except Exception:
        pass

    # Parse grounding as JSON if provided
    grounding_data = None
    if grounding:
        try:
            grounding_data = json.loads(grounding)
        except json.JSONDecodeError as e:
            raise ValidationError(f"Invalid JSON for --grounding: {e}")

    # Create Decision instance (validation happens in __post_init__)
    decision = Decision(
        id=dec_id,
        version=1,
        status='active',
        createdAt=datetime.now().isoformat(),
        author=get_git_author(),
        proposal=proposal,
        rationale=rationale,
        alternatives=alternatives,
        satisfies=satisfies_list,
        satisfiesPolicies=satisfies_policies_list,
        impact=impact_data,
        decisionClass=decision_class,
        grounding=grounding_data,
        scope=[s.strip().replace(' ', '-').lower() for s in scope.split(',')] if scope else []
    )

    # Validate apps if scope provided
    validate_apps(decision.scope)

    # Append to file
    append_jsonl(DECISIONS_FILE, decision)
    print(f"✓ Added {decision_class.upper()} decision {dec_id} (v1)")
    emit_metric("memory_write", {"type": "decision", "id": dec_id, "class": decision_class}, session_id=get_session_id())


@dec_app.command("deprecate")
def deprecate_decision(
    id: Annotated[str, typer.Option(..., help="Decision ID")],
    reason: Annotated[str, typer.Option(..., help="Reason for obsolescence")],
    superseded_by: Annotated[Optional[str], typer.Option(help="ID of replacement decision")] = None
) -> None:
    """Deprecate a decision (updates all versions)"""
    decisions = read_jsonl(DECISIONS_FILE, Decision)
    latest = get_latest_version(decisions, id)

    if not latest:
        raise ValidationError(f"Decision {id} does not exist")

    if latest.status != 'active':
        raise ValidationError(f"Decision {id} is already obsolete")

    # Check for orphaned references
    warnings = check_orphaned_references(id, 'decision')

    now = datetime.now().isoformat()

    # Update all existing versions of this ID to obsolete
    for entry in decisions:
        if entry.id == id and entry.status == 'active':
            entry.status = 'obsolete'
            entry.obsoleteAt = now
            entry.obsoleteReason = reason
            if superseded_by:
                entry.supersededBy = superseded_by

    # Create new version as the canonical obsolescence record
    new_version = Decision(
        id=latest.id,
        version=latest.version + 1,
        status='obsolete',
        createdAt=latest.createdAt,
        author=latest.author,
        proposal=latest.proposal,
        rationale=latest.rationale,
        alternatives=latest.alternatives,
        satisfies=latest.satisfies,
        satisfiesPolicies=latest.satisfiesPolicies,
        impact=latest.impact,
        decisionClass=latest.decisionClass,
        grounding=latest.grounding,
        obsoleteAt=now,
        obsoleteReason=reason,
        supersededBy=superseded_by if superseded_by else None
    )
    decisions.append(new_version)

    # Rewrite file with all versions updated
    rewrite_jsonl(DECISIONS_FILE, decisions)
    print(f"✓ Deprecated decision {id} (v{latest.version} → v{new_version.version})")

    for warning in warnings:
        print(f"⚠ Warning: {warning}", file=sys.stderr)
    emit_metric("memory_write", {"type": "decision_deprecate", "id": id},
                feature_name="", plan_id="", session_id=get_session_id())


@dec_app.command("update")
def update_decision(
    id: Annotated[str, typer.Option(..., help="Decision ID")],
    proposal: Annotated[Optional[str], typer.Option(help="New proposal")] = None,
    rationale: Annotated[Optional[str], typer.Option(help="New rationale")] = None,
    alternatives: Annotated[Optional[str], typer.Option(help="New alternatives")] = None,
    satisfies: Annotated[Optional[str], typer.Option(help="New comma-separated req IDs")] = None,
    satisfies_policies: Annotated[Optional[str], typer.Option(help="New comma-separated policy IDs")] = None,
    impact: Annotated[Optional[str], typer.Option(help="New impact (JSON string)")] = None,
    scope: Annotated[Optional[str], typer.Option(help="New comma-separated app names")] = None
) -> None:
    """Update a decision (creates new version)"""
    decisions = read_jsonl(DECISIONS_FILE, Decision)
    latest = get_latest_version(decisions, id)

    if not latest:
        raise ValidationError(f"Decision {id} does not exist")

    if latest.status != 'active':
        raise ValidationError(f"Decision {id} is not active")

    # Parse and validate new satisfies if provided
    new_satisfies = latest.satisfies
    if satisfies is not None:
        new_satisfies = [s.strip() for s in satisfies.split(',') if s.strip()]
        if new_satisfies:
            validate_references(new_satisfies, REQUIREMENTS_FILE, "Requirement", Requirement)

    # Parse and validate new satisfiesPolicies if provided
    new_satisfies_policies = latest.satisfiesPolicies
    if satisfies_policies is not None:
        new_satisfies_policies = [p.strip() for p in satisfies_policies.split(',') if p.strip()]
        if new_satisfies_policies:
            validate_references(new_satisfies_policies, POLICIES_FILE, "Policy", Policy)

    # Parse new impact if provided
    new_impact = latest.impact
    if impact is not None:
        try:
            new_impact = json.loads(impact)
        except json.JSONDecodeError:
            new_impact = impact

    # Parse and validate new scope if provided
    new_scope = latest.scope
    if scope is not None:
        new_scope = [s.strip().replace(' ', '-').lower() for s in scope.split(',') if s.strip()]
        validate_apps(new_scope)

    # Create new version with updated fields
    new_version = Decision(
        id=latest.id,
        version=latest.version + 1,
        status=latest.status,
        createdAt=latest.createdAt,
        author=get_git_author(),
        proposal=proposal if proposal is not None else latest.proposal,
        rationale=rationale if rationale is not None else latest.rationale,
        alternatives=alternatives if alternatives is not None else latest.alternatives,
        satisfies=new_satisfies,
        satisfiesPolicies=new_satisfies_policies,
        impact=new_impact,
        decisionClass=latest.decisionClass,
        grounding=latest.grounding,
        scope=new_scope
    )

    # Mark old active versions as superseded
    for entry in decisions:
        if entry.id == id and entry.status == 'active':
            entry.status = 'superseded'
            entry.supersededBy = f"v{new_version.version}"

    decisions.append(new_version)

    # Rewrite file
    rewrite_jsonl(DECISIONS_FILE, decisions)
    print(f"✓ Updated decision {id} (v{latest.version} → v{new_version.version})")
    emit_metric("memory_write", {"type": "decision_update", "id": id, "class": latest.decisionClass},
                feature_name="", plan_id="", session_id=get_session_id())


def get_next_requirement_id(req_type: str) -> str:
    """Generate a unique requirement ID using short UUID
    
    Format: <TYPE>-<8-char-uuid>
    Example: FR-a3f2b1c4
    
    This approach eliminates ID conflicts when working on multiple branches.
    """
    validate_requirement_type(req_type)
    return f"{req_type}-{str(uuid.uuid4())[:8]}"


def get_next_decision_id() -> str:
    """Generate a unique decision ID using short UUID
    
    Format: D-<8-char-uuid>
    Example: D-7e9d2a1f
    
    This approach eliminates ID conflicts when working on multiple branches.
    """
    return f"D-{str(uuid.uuid4())[:8]}"


def get_next_policy_id() -> str:
    """Generate a unique policy ID using short UUID
    
    Format: POL-<8-char-uuid>
    Example: POL-b4c8e2f1
    
    This approach eliminates ID conflicts when working on multiple branches.
    """
    return f"POL-{str(uuid.uuid4())[:8]}"


@pol_app.command("add")
def add_policy(
    description: Annotated[str, typer.Option(..., help="Clear statement of the policy or best practice")],
    rationale: Annotated[str, typer.Option(..., help="Why this policy is necessary")],
    plan_id: Annotated[Optional[str], typer.Option(help="Plan ID")] = None,
    satisfies: Annotated[Optional[str], typer.Option(help="Comma-separated req IDs")] = None,
    scope: Annotated[Optional[str], typer.Option(help="Comma-separated app names")] = None
) -> None:
    """Add a new policy"""
    # Parse satisfies
    satisfies_list = [s.strip() for s in satisfies.split(',')] if satisfies else []

    # Validate requirement references
    if satisfies_list:
        validate_references(satisfies_list, REQUIREMENTS_FILE, "Requirement", Requirement)

    # Auto-generate ID
    pol_id = get_next_policy_id()

    # Create Policy instance (validation happens in __post_init__)
    policy = Policy(
        id=pol_id,
        version=1,
        status='active',
        createdAt=datetime.now().isoformat(),
        author=get_git_author(),
        planId=plan_id if plan_id else None,
        description=description,
        rationale=rationale,
        satisfies=satisfies_list,
        scope=[s.strip().replace(' ', '-').lower() for s in scope.split(',')] if scope else []
    )

    # Validate apps if scope provided
    validate_apps(policy.scope)

    # Append to file
    append_jsonl(POLICIES_FILE, policy)
    print(f"✓ Added policy {pol_id} (v1)")
    emit_metric("memory_write", {"type": "policy", "id": pol_id},
                feature_name="", plan_id=plan_id or "", session_id=get_session_id())


@pol_app.command("deprecate")
def deprecate_policy(
    id: Annotated[str, typer.Option(..., help="Policy ID")],
    reason: Annotated[str, typer.Option(..., help="Deprecation reason")],
    superseded_by: Annotated[Optional[str], typer.Option(help="ID of replacement policy")] = None
) -> None:
    """Deprecate a policy (updates all versions)"""
    policies = read_jsonl(POLICIES_FILE, Policy)
    latest = get_latest_version(policies, id)

    if not latest:
        raise ValidationError(f"Policy {id} does not exist")

    if latest.status != 'active':
        raise ValidationError(f"Policy {id} is already deprecated")

    # Check for orphaned references
    warnings = check_orphaned_references(id, 'policy')

    now = datetime.now().isoformat()

    # Update all existing versions of this ID to deprecated
    for entry in policies:
        if entry.id == id and entry.status == 'active':
            entry.status = 'deprecated'
            entry.deprecatedAt = now
            entry.deprecatedReason = reason
            if superseded_by:
                entry.supersededBy = superseded_by

    # Create new version as the canonical deprecation record
    new_version = Policy(
        id=latest.id,
        version=latest.version + 1,
        status='deprecated',
        createdAt=latest.createdAt,
        author=latest.author,
        planId=latest.planId,
        description=latest.description,
        rationale=latest.rationale,
        satisfies=latest.satisfies,
        deprecatedAt=now,
        deprecatedReason=reason,
        supersededBy=superseded_by if superseded_by else None
    )
    policies.append(new_version)

    # Rewrite file with all versions updated
    rewrite_jsonl(POLICIES_FILE, policies)
    print(f"✓ Deprecated policy {id} (v{latest.version} → v{new_version.version})")

    for warning in warnings:
        print(f"⚠ Warning: {warning}", file=sys.stderr)
    emit_metric("memory_write", {"type": "policy_deprecate", "id": id},
                feature_name="", plan_id=latest.planId or "", session_id=get_session_id())


@pol_app.command("update")
def update_policy(
    id: Annotated[str, typer.Option(..., help="Policy ID")],
    description: Annotated[Optional[str], typer.Option(help="New description")] = None,
    rationale: Annotated[Optional[str], typer.Option(help="New rationale")] = None,
    satisfies: Annotated[Optional[str], typer.Option(help="New comma-separated req IDs")] = None,
    scope: Annotated[Optional[str], typer.Option(help="New comma-separated app names")] = None
) -> None:
    """Update a policy (creates new version)"""
    policies = read_jsonl(POLICIES_FILE, Policy)
    latest = get_latest_version(policies, id)

    if not latest:
        raise ValidationError(f"Policy {id} does not exist")

    if latest.status != 'active':
        raise ValidationError(f"Policy {id} is not active")

    # Parse and validate new satisfies if provided
    new_satisfies = latest.satisfies
    if satisfies is not None:
        new_satisfies = [s.strip() for s in satisfies.split(',') if s.strip()]
        if new_satisfies:
            validate_references(new_satisfies, REQUIREMENTS_FILE, "Requirement", Requirement)

    # Parse and validate new scope if provided
    new_scope = latest.scope
    if scope is not None:
        new_scope = [s.strip().replace(' ', '-').lower() for s in scope.split(',') if s.strip()]
        validate_apps(new_scope)

    # Create new version with updated fields
    new_version = Policy(
        id=latest.id,
        version=latest.version + 1,
        status=latest.status,
        createdAt=latest.createdAt,
        author=get_git_author(),
        planId=latest.planId,
        description=description if description is not None else latest.description,
        rationale=rationale if rationale is not None else latest.rationale,
        satisfies=new_satisfies,
        scope=new_scope
    )

    # Mark old active versions as superseded
    for entry in policies:
        if entry.id == id and entry.status == 'active':
            entry.status = 'superseded'
            entry.supersededBy = f"v{new_version.version}"

    policies.append(new_version)

    # Rewrite file
    rewrite_jsonl(POLICIES_FILE, policies)
    print(f"✓ Updated policy {id} (v{latest.version} → v{new_version.version})")
    emit_metric("memory_write", {"type": "policy_update", "id": id},
                feature_name="", plan_id=latest.planId or "", session_id=get_session_id())


def get_next_app_id() -> str:
    """Generate a unique app ID using short UUID
    
    Format: APP-<8-char-uuid>
    Example: APP-a3f2b1c4
    
    This approach eliminates ID conflicts when working on multiple branches.
    """
    return f"APP-{str(uuid.uuid4())[:8]}"


@app_app.command("add")
def add_app(
    name: Annotated[str, typer.Option(..., help="Display name of the app or library")],
    type: Annotated[str, typer.Option(..., help="Category: application or library")],
    repository: Annotated[str, typer.Option(..., help="Git repository URL or name")],
    file_path: Annotated[str, typer.Option(..., help="Relative path from git root")],
    app_type: Annotated[Optional[str], typer.Option(help="Specialization: frontend, backend...")] = None,
    package_manager: Annotated[Optional[str], typer.Option(help="Primary package manager: npm, pip...")] = None,
    owner: Annotated[Optional[str], typer.Option(help="Owner or team")] = None
) -> None:
    """Add a new app or library"""
    # Auto-generate ID
    app_id = get_next_app_id()
    
    normalized_name = name.replace(' ', '-').lower()
    
    # Validate uniqueness
    apps = read_jsonl(APPS_FILE, App)
    if any(app.id == app_id for app in apps):
        raise ValidationError(f"App ID collision: {app_id}")
    
    active_apps = get_active_entries(apps)
    
    # Check for name collision
    for app in active_apps:
        if app.name == normalized_name:
            raise ValidationError(f"An active app with name '{normalized_name}' already exists (ID: {app.id})")

    # Check for filepath collision
    new_abs_path = os.path.abspath(file_path)
    for app in active_apps:
        if app.filePath:
            existing_abs_path = os.path.abspath(app.filePath)
            if existing_abs_path == new_abs_path:
                raise ValidationError(f"An active app with filepath '{file_path}' already exists (ID: {app.id}, Name: {app.name})")

    # Create App instance (validation happens in __post_init__)
    app_instance = App(
        id=app_id,
        version=1,
        status='active',
        createdAt=datetime.now().isoformat(),
        author=get_git_author(),
        name=normalized_name,
        type=type,
        repository=repository,
        appType=app_type if app_type else None,
        packageManager=package_manager if package_manager else None,
        filePath=file_path,
        owner=owner if owner else ""
    )

    # Append to file
    append_jsonl(APPS_FILE, app_instance)
    print(f"✓ Added {type} {app_id} (v1)")


@app_app.command("update")
def update_app(
    id: Annotated[str, typer.Option(..., help="App ID")],
    name: Annotated[Optional[str], typer.Option(help="New name")] = None,
    owner: Annotated[Optional[str], typer.Option(help="New owner/maintainer")] = None
) -> None:
    """Update an app or library (e.g. change owner)"""
    apps = read_jsonl(APPS_FILE, App)
    latest = get_latest_version(apps, id)

    if not latest:
        raise ValidationError(f"App {id} does not exist")

    if latest.status != 'active':
        raise ValidationError(f"App {id} is not active")

    normalized_name = name.replace(' ', '-').lower() if name else latest.name.lower()

    # Validate name uniqueness if it changed
    if name:
        active_apps = get_active_entries(apps)
        for app in active_apps:
            if app.name == normalized_name and app.id != id:
                raise ValidationError(f"An active app with name '{normalized_name}' already exists (ID: {app.id})")



    # Create new version with updated fields
    new_version = App(
        id=latest.id,
        version=latest.version + 1,
        status=latest.status,
        createdAt=latest.createdAt,
        author=get_git_author(),
        name=normalized_name,
        type=latest.type,
        repository=latest.repository,
        appType=latest.appType,
        packageManager=latest.packageManager,
        filePath=latest.filePath,
        owner=owner if owner else latest.owner
    )
    
    # Mark old active versions as superseded
    for entry in apps:
        if entry.id == id and entry.status == 'active':
            entry.status = 'superseded'
            entry.supersededBy = f"v{new_version.version}"

    apps.append(new_version)

    # Rewrite file
    rewrite_jsonl(APPS_FILE, apps)
    print(f"✓ Updated app {id} (v{latest.version} → v{new_version.version})")
    emit_metric("memory_write", {"type": "app_update", "id": id},
                feature_name="", plan_id="", session_id=get_session_id())


def validate_plan_status(status: str) -> None:
    """Validate plan status"""
    valid_statuses = ['draft', 'approved', 'executing', 'complete', 'abandoned']
    if status not in valid_statuses:
        raise ValidationError(f"Invalid status '{status}'. Must be one of: {', '.join(valid_statuses)}")


def get_next_plan_id() -> str:
    """Generate a unique plan ID using short UUID
    
    Format: P-<8-char-uuid>
    Example: P-a3f2b1c4
    
    This approach eliminates ID conflicts when working on multiple branches.
    """
    return f"P-{str(uuid.uuid4())[:8]}"


@plan_app.command("add")
def add_plan(
    feature_name: Annotated[str, typer.Option(..., help="Feature name")],
    goal: Annotated[str, typer.Option(..., help="Plan goal")],
    scope: Annotated[Optional[str], typer.Option(help="Comma-separated app scopes")] = None
) -> None:
    """Add a new plan"""
    # Auto-generate ID
    plan_id = get_next_plan_id()

    # Create Plan instance (validation happens in __post_init__)
    plan = Plan(
        id=plan_id,
        version=1,
        status='draft',
        createdAt=datetime.now().isoformat(),
        author=get_git_author(),
        featureName=feature_name,
        goal=goal,
        scope=[s.strip() for s in scope.split(',') if s.strip()] if scope else [],
        currentState='INIT',
        sessionIds=[get_session_id()]   
    )

    # Save to individual JSON file
    plan_file = Path(PLANS_DIR) / f"{plan_id}.json"
    plan_file.parent.mkdir(parents=True, exist_ok=True)
    with open(plan_file, 'w') as f:
        json.dump(asdict(plan), f, indent=2)
    
    print(f"✓ Added plan {plan_id} (v1, status=draft)")
    emit_metric("memory_write", {"type": "plan", "id": plan_id}, feature_name=feature_name, plan_id=plan_id, session_id=get_session_id())


@plan_app.command("update-status")
def update_plan_status(
    id: Annotated[str, typer.Option(..., help="Plan ID (e.g., P-a3f2b1c4)")],
    status: Annotated[str, typer.Option(..., help="New status: draft, approved, executing, complete, abandoned", click_type=click.Choice(['draft', 'approved', 'executing', 'complete', 'abandoned']))]
) -> None:
    """Update plan status"""
    validate_plan_status(status)
    
    plan_file = Path(PLANS_DIR) / f"{id}.json"
    if not plan_file.exists():
        raise ValidationError(f"Plan {id} does not exist")
    
    with open(plan_file, 'r') as f:
        plan_data = json.load(f)
        plan = Plan.from_dict(plan_data)
    
    if plan.status == 'abandoned':
        raise ValidationError(f"Plan {id} is abandoned and cannot be updated")
    
    # Update plan
    plan.status = status
    if status == 'approved' and not plan.approvedAt:
        plan.approvedAt = datetime.now().isoformat()
    if status == 'complete' and not plan.completedAt:
        plan.completedAt = datetime.now().isoformat()
    
    with open(plan_file, 'w') as f:
        json.dump(asdict(plan), f, indent=2)
        
    print(f"✓ Updated plan {id} status to {status}")
    emit_metric("memory_write", {"type": "plan_update", "id": id, "status": status}, feature_name=plan.featureName, plan_id=id, session_id=get_session_id())


@plan_app.command("deprecate")
def deprecate_plan(
    id: Annotated[str, typer.Option(..., help="Plan ID")],
    reason: Annotated[str, typer.Option(..., help="Deprecation reason")],
    superseded_by: Annotated[Optional[str], typer.Option(help="ID of replacement plan")] = None
) -> None:
    """Deprecate a plan (updates all versions)"""
    plan_file = Path(PLANS_DIR) / f"{id}.json"
    if not plan_file.exists():
        raise ValidationError(f"Plan {id} does not exist")

    with open(plan_file, 'r') as f:
        plan_data = json.load(f)
        plan = Plan.from_dict(plan_data)

    if plan.status == 'abandoned':
        raise ValidationError(f"Plan {id} is already abandoned")

    now = datetime.now().isoformat()
    plan.status = 'abandoned'
    plan.abandonedAt = now
    plan.abandonedReason = reason
    if superseded_by:
        plan.supersededBy = superseded_by

    with open(plan_file, 'w') as f:
        json.dump(asdict(plan), f, indent=2)

    print(f"✓ Abandoned plan {id}")
    emit_metric("memory_write", {"type": "plan_deprecate", "id": id},
                feature_name=plan.featureName, plan_id=id, session_id=get_session_id())


@plan_app.command("migrate")
def migrate_plans(
    cleanup: Annotated[bool, typer.Option(help="Remove old plans.jsonl and state.json files after migration")] = False
) -> None:
    """Migrate plans from plans.jsonl and state.json to individual JSON files"""
    plans_dir = Path(PLANS_DIR)
    plans_dir.mkdir(parents=True, exist_ok=True)
    
    old_plans_file = Path(".spex/memory/plans.jsonl")
    migrated_count = 0
    
    # 1. Load plans from plans.jsonl
    plans_data = {}
    if old_plans_file.exists():
        with open(old_plans_file, 'r') as f:
            for line in f:
                if not line.strip():
                    continue
                try:
                    data = json.loads(line)
                    plan_id = data.get("id")
                    if plan_id:
                        plans_data[plan_id] = data
                except Exception:
                    continue

    # 2. Scan for state.json files to merge or add
    plans_root = Path(".spex/plans")
    if plans_root.exists():
        for feat_dir in plans_root.iterdir():
            if not feat_dir.is_dir():
                continue
            
            state_file = feat_dir / "state.json"
            if state_file.exists():
                try:
                    with open(state_file, 'r') as f:
                        state_data = json.load(f)
                    
                    # Plan ID might be in context or at top level in some versions
                    plan_id = state_data.get("context", {}).get("planId") or state_data.get("planId")
                    
                    if plan_id:
                        if plan_id in plans_data:
                            # Merge state info into existing plan data
                            plans_data[plan_id].update({
                                "currentState": state_data.get("currentState", plans_data[plan_id].get("currentState", "INIT")),
                                "sessionIds": state_data.get("sessionIds", plans_data[plan_id].get("sessionIds", [])),
                                "scope": state_data.get("context", {}).get("scope", plans_data[plan_id].get("scope", []))
                            })
                        else:
                            # Create new plan entry from state.json
                            plans_data[plan_id] = {
                                "id": plan_id,
                                "version": 1,
                                "status": "draft",
                                "createdAt": state_data.get("metadata", {}).get("createdAt", datetime.now().isoformat()),
                                "author": get_git_author(),
                                "featureName": state_data.get("featureName", feat_dir.name),
                                "goal": state_data.get("context", {}).get("goal", ""),
                                "scope": state_data.get("context", {}).get("scope", []),
                                "currentState": state_data.get("currentState", "INIT"),
                                "sessionIds": state_data.get("sessionIds", [])
                            }
                except Exception as e:
                    print(f"Warning: Failed to read {state_file}: {e}")

    # 3. Write individual JSON files
    for plan_id, data in plans_data.items():
        plan_file = plans_dir / f"{plan_id}.json"
        
        try:
            # Ensure required fields exist for Plan.from_dict
            data.setdefault("version", 1)
            if data.get("status") == "active":
                 data["status"] = "draft"
            data.setdefault("status", "draft")
            data.setdefault("createdAt", datetime.now().isoformat())
            data.setdefault("author", get_git_author())
            
            plan = Plan.from_dict(data)
            with open(plan_file, 'w') as f:
                json.dump(asdict(plan), f, indent=2)
            migrated_count += 1
        except Exception as e:
            print(f"Error migrating plan {plan_id}: {e}")

    print(f"✓ Migrated {migrated_count} plans to {PLANS_DIR}")
    
    if cleanup:
        if old_plans_file.exists():
            old_plans_file.unlink()
            print(f"✓ Deleted {old_plans_file}")
        
        if plans_root.exists():
            for feat_dir in plans_root.iterdir():
                if not feat_dir.is_dir():
                    continue
                state_file = feat_dir / "state.json"
                if state_file.exists():
                    state_file.unlink()
                    print(f"✓ Deleted {state_file}")


@app.command("validate-and-route", rich_help_panel="System")
def validate_and_route(
    plan_id: Annotated[str, typer.Option(..., help="Plan ID (e.g., P-a3f2b1c4)")],
    target_state: Annotated[str, typer.Option(..., help="State to transition to")]
) -> None:
    """Validate a state transition and update state in plans directory"""
    # 1. Load the plan
    active_plan = None
    plan_file = Path(PLANS_DIR) / f"{plan_id}.json"
    
    if plan_file.exists():
        try:
            with open(plan_file, 'r') as f:
                data = json.load(f)
                active_plan = Plan.from_dict(data)
        except Exception as e:
            print(json.dumps({
                "valid": False,
                "nextState": "UNKNOWN",
                "error": f"Failed to read plan {plan_id}: {e}"
            }))
            sys.exit(1)
    
    if not active_plan:
        # Fallback search by ID as feature_name just in case for legacy
        plans_dir = Path(PLANS_DIR)
        if plans_dir.exists():
            for plan_path in plans_dir.glob("*.json"):
                try:
                    with open(plan_path, 'r') as f:
                        data = json.load(f)
                        if data.get("id") == plan_id or data.get("featureName") == plan_id:
                            active_plan = Plan.from_dict(data)
                            break
                except Exception:
                    continue

    if not active_plan:
        print(json.dumps({
            "valid": False,
            "nextState": "UNKNOWN",
            "error": f"Plan {plan_id} not found"
        }))
        sys.exit(1)
        
    feature_name = active_plan.featureName
    current_state = active_plan.currentState
    
    # Define valid transitions
    transitions = {
        "INIT": ["RESEARCH"],
        "RESEARCH": ["RESOLVING_CONFLICTS", "GENERATE_PLAN", "RESEARCH", "STOP"],
        "RESOLVING_CONFLICTS": ["GENERATE_PLAN", "STOP"],
        "GENERATE_PLAN": ["REVIEWING_PLAN"],
        "REVIEWING_PLAN": ["COMPILING_TASKS", "GENERATE_PLAN"],
        "COMPILING_TASKS": ["EXECUTE"],
        "EXECUTE": ["COMPLETE", "EXECUTE"],
        "STOP": ["RESEARCH", "GENERATE_PLAN"],
        "COMPLETE": []
    }
    
    # 1. Check if transition exists in graph
    if target_state not in transitions.get(current_state, []):
        print(json.dumps({
            "valid": False,
            "nextState": current_state,
            "error": f"Invalid transition: {current_state} -> {target_state}"
        }))
        sys.exit(1)
        
    # 2. Artifact Validation
    valid = True
    error = None
    feature_dir = Path(f".spex/plans/{feature_name}")

    if target_state == "GENERATE_PLAN":
        res_file = feature_dir / "research.json"
        if not res_file.exists():
            valid = False
            error = "Missing research.json (required for GENERATE_PLAN)"
        else:
            try:
                with open(res_file, 'r') as f:
                    res_data = json.load(f)
                    if not res_data.get("memory"):
                        valid = False
                        error = "research.json is missing 'memory' section (requires grounded research)"
            except Exception:
                valid = False
                error = "Could not parse research.json"

                
    elif target_state == "REVIEWING_PLAN":
        if not (feature_dir / "plan.md").exists():
            valid = False
            error = "Missing plan.md (required for REVIEWING_PLAN)"
            
    elif target_state == "COMPILING_TASKS":
        # Check if plan is approved
        if active_plan.status != "approved":
            valid = False
            error = f"Plan {active_plan.id} must be 'approved' before compiling tasks"
            
    elif target_state == "EXECUTE":
        if not (feature_dir / "tasks.md").exists():
            valid = False
            error = "Missing tasks.md (required for EXECUTE)"

    if not valid:
        print(json.dumps({
            "valid": False,
            "nextState": current_state,
            "error": error
        }))
        sys.exit(1)
        
    # 3. Update Plan
    active_plan.currentState = target_state

    # Track session IDs
    session_id = get_session_id()
    if session_id and session_id not in active_plan.sessionIds:
        active_plan.sessionIds.append(session_id)
    
    # Save plan back
    plan_file = Path(PLANS_DIR) / f"{active_plan.id}.json"
    with open(plan_file, 'w') as f:
        json.dump(asdict(active_plan), f, indent=2)
        
    print(json.dumps({
        "valid": True,
        "nextState": target_state,
        "error": None
    }))

    # Emit metric
    emit_metric("state_transition",
                {"from": current_state, "to": target_state, "result": "success"},
                feature_name=feature_name, plan_id=plan_id, session_id=get_session_id())





def find_referencing_files(file_path: str) -> List[str]:
    """Find files that reference the given file_path using grep (rg)"""
    filename = os.path.basename(file_path)
    stem = os.path.splitext(filename)[0]
    
    try:
        found_files = set()
        
        # Search for literal filename
        cmd1 = ["rg", "-l", "--fixed-strings", filename, "-g", f"!{file_path}"]
        result1 = subprocess.run(cmd1, capture_output=True, text=True)
        if result1.returncode == 0:
            found_files.update(result1.stdout.splitlines())
            
        # Search for stem with word boundaries (for extensionless imports)
        if stem and stem != filename:
            cmd2 = ["rg", "-l", "-w", stem, "-g", f"!{file_path}"]
            result2 = subprocess.run(cmd2, capture_output=True, text=True)
            if result2.returncode == 0:
                found_files.update(result2.stdout.splitlines())
        
        return [f.strip() for f in found_files if f.strip()]
    except Exception as e:
        print(f"⚠ Warning: grep fallback failed: {e}", file=sys.stderr)
        return []


def get_blame_commit(file_path: str, line: int) -> Optional[str]:
    """Get the commit hash for a specific line in a file using git blame"""
    try:
        # -L start,end (here start=end)
        # -l show long rev (Default)
        # -s suppress author name and timestamp
        cmd = ["git", "blame", "-L", f"{line},{line}", "-l", "-s", file_path]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode == 0 and result.stdout:
            # Output format: <sha> <content> or just <sha> if -s used? 
            # -s suppresses the author name and timestamp from the output.
            # Output is usually: "sha ( ... ) content" or just "sha content" depending on options.
            # With -l -s: "sha (Original Line)" but sometimes varies.
            # Only first token is reliably the SHA.
            parts = result.stdout.split()
            if parts:
                return parts[0]
    except Exception:
        pass
    return None



@app.command("impact", rich_help_panel="System")
def impact_radius(
    id: Annotated[str, typer.Argument(..., help="ID of the item to analyze (e.g., D-a3f2b1c4)")]
) -> None:
    """Calculate the impact radius of a memory item (Requirement, Decision, or Policy)"""
    entry_id = id
    
    # Identify type based on prefix
    target_type = None
    filepath = None
    model = None
    
    if entry_id.startswith(('FR', 'NFR', 'CR', 'UR')):
        target_type = "Requirement"
        filepath = REQUIREMENTS_FILE
        model = Requirement
    elif entry_id.startswith('D'):
        target_type = "Decision"
        filepath = DECISIONS_FILE
        model = Decision
    elif entry_id.startswith('POL'):
        target_type = "Policy"
        filepath = POLICIES_FILE
        model = Policy
    else:
        raise ValidationError(f"Invalid ID format: {entry_id}")

    # Get latest active version
    target_dict = get_latest_active_jq(entry_id, filepath)
    if not target_dict:
        # Check if it exists at all (maybe deprecated)
        all_versions = run_jq(f'select(.id == "{entry_id}")', filepath)
        if not all_versions:
            raise ValidationError(f"Item {entry_id} not found in {filepath}")
        target_dict = max(all_versions, key=lambda x: x.get('version', 1))

    # Use model.from_dict if possible, but some fields might be missing in legacy data
    # Requirement and Decision have from_dict that handles missing fields.
    target_entry = model.from_dict(target_dict)
    
    upstream = []
    downstream = []

    # 1. Upstream: What does this implementation satisfy?
    if target_type == "Decision":
        # Decisions satisfy Requirements
        satisfies = target_dict.get('satisfies') or []
        if isinstance(satisfies, str):
            satisfies = [s.strip() for s in satisfies.split(',') if s.strip()]
            
        for req_id in satisfies:
            req_dict = get_latest_active_jq(req_id, REQUIREMENTS_FILE)
            if req_dict:
                upstream.append({"id": req_id, "type": "Requirement", "description": req_dict.get('description', '')})
        
        # Decisions satisfy Policies
        satisfies_pols = target_dict.get('satisfiesPolicies') or []
        if isinstance(satisfies_pols, str):
            satisfies_pols = [s.strip() for s in satisfies_pols.split(',') if s.strip()]
            
        for pol_id in satisfies_pols:
            pol_dict = get_latest_active_jq(pol_id, POLICIES_FILE)
            if pol_dict:
                upstream.append({"id": pol_id, "type": "Policy", "description": pol_dict.get('description', '')})
                
    elif target_type == "Policy":
        # Policies satisfy Requirements
        satisfies = target_dict.get('satisfies') or []
        if isinstance(satisfies, str):
            satisfies = [s.strip() for s in satisfies.split(',') if s.strip()]
            
        for req_id in satisfies:
            req_dict = get_latest_active_jq(req_id, REQUIREMENTS_FILE)
            if req_dict:
                upstream.append({"id": req_id, "type": "Requirement", "description": req_dict.get('description', '')})

    # 2. Downstream: What depends on this?
    if target_type == "Requirement":
        # Decisions satisfying this req
        dec_query = f'select(.status == "active" and ((.satisfies? // []) | index("{entry_id}")))'
        for d in run_jq(dec_query, DECISIONS_FILE):
             downstream.append({"id": d['id'], "type": "Decision", "proposal": d.get('proposal', '')})
        # Policies satisfying this req
        pol_query = f'select(.status == "active" and ((.satisfies? // []) | index("{entry_id}")))'
        for p in run_jq(pol_query, POLICIES_FILE):
             downstream.append({"id": p['id'], "type": "Policy", "description": p.get('description', '')})
             
    elif target_type == "Policy":
        # Decisions satisfying this policy
        dec_query = f'select(.status == "active" and ((.satisfiesPolicies? // []) | index("{entry_id}")))'
        for d in run_jq(dec_query, DECISIONS_FILE):
             downstream.append({"id": d['id'], "type": "Decision", "proposal": d.get('proposal', '')})

    elif target_type == "Decision":
        # Other decisions grounded in this one
        ground_query = f'select(.status == "active" and .grounding != null and .grounding["{entry_id}"] != null)'
        for d in run_jq(ground_query, DECISIONS_FILE):
             downstream.append({"id": d['id'], "type": "Decision", "proposal": d.get('proposal', ''), "groundingContext": d['grounding'][entry_id]})

    result = {
        "id": entry_id,
        "type": target_type,
        "status": target_entry.status,
        "upstream": upstream,
        "downstream": downstream
    }

    print(json.dumps(result, separators=(',', ':')))
    emit_metric("memory_lookup", {
        "type": "impact",
        "id": entry_id,
        "upstreamCount": len(upstream),
        "downstreamCount": len(downstream),
    }, session_id=get_session_id())



@app.command("search", rich_help_panel="Memory")
def search_memory(
    keywords_list: Annotated[List[str], typer.Argument(..., help="Keywords to search for")]
) -> None:
    """Search active memory items for keywords"""
    if not keywords_list:
        print("No keywords provided.")
        return

    keywords = [k.lower() for k in keywords_list]
    
    def contains_keywords(texts) -> bool:
        text = " ".join(str(t) for t in texts if t).lower()
        return any(k in text for k in keywords)

    print(f"Searching memory for keywords: {', '.join(keywords_list)}\n")
    found_any = False
    results = []

    # 1. Decisions
    if os.path.exists(DECISIONS_FILE):
        decisions = read_jsonl(DECISIONS_FILE, Decision)
        active_decisions = get_active_entries(decisions)
        found = [d for d in active_decisions if contains_keywords([d.proposal, d.rationale, d.alternatives, getattr(d, 'impact', ''), getattr(d, 'grounding', ''), d.scope])]
        if found:
            found_any = True
            print(f"Decisions found ({len(found)}):")
            for d in found:
                print(f"[{d.id}] {d.proposal}")
                results.append(d)
            print()
            
    # 2. Requirements
    if os.path.exists(REQUIREMENTS_FILE):
        reqs = read_jsonl(REQUIREMENTS_FILE, Requirement)
        active_reqs = get_active_entries(reqs)
        found = [r for r in active_reqs if contains_keywords([r.description, r.source, getattr(r, 'acceptanceCriteria', ''), r.scope])]
        if found:
            found_any = True
            print(f"Requirements found ({len(found)}):")
            for r in found:
                print(f"[{r.id}] {r.description}")
                results.append(r)
            print()
            
    if not found_any:
        print("No matches found in active memory.")

    emit_metric("memory_lookup", {
        "query": " ".join(keywords_list),
        "resultsCount": len(results),
        "matches": [r.id for r in results]
    }, session_id=get_session_id())


@app.command("healthcheck", rich_help_panel="Developers")
def healthcheck() -> None:
    """Audit hooks and memory integrity"""
    errors = []
    
    # 1. Audit Hooks
    print("Auditing Git Hooks...")
    try:
        # Check core.hooksPath
        result = subprocess.run(['git', 'config', 'core.hooksPath'], capture_output=True, text=True)
        hooks_path = result.stdout.strip()
        if hooks_path != '.spex/hooks':
            errors.append(f"Git core.hooksPath is set to '{hooks_path}' instead of '.spex/hooks'")
        else:
            print("  ✓ core.hooksPath is correctly set to .spex/hooks")
        
        # Check if hook files exist and are executable
        hooks_dir = Path('.spex/hooks')
        if not hooks_dir.is_dir():
            errors.append("Hooks directory .spex/hooks not found")
        else:
            required_hooks = ['post-commit']
            for hook in required_hooks:
                hook_file = hooks_dir / hook
                if not hook_file.exists():
                    errors.append(f"Required hook file missing: {hook_file}")
                elif not os.access(hook_file, os.X_OK):
                    errors.append(f"Hook file not executable: {hook_file}")
                else:
                    print(f"  ✓ Hook {hook} exists and is executable")
        
    except Exception as e:
        errors.append(f"Error auditing hooks: {e}")

    # 2. Audit Memory Integrity
    print("\nAuditing Memory Integrity...")
    memory_map = [
        (REQUIREMENTS_FILE, Requirement),
        (DECISIONS_FILE, Decision),
        (POLICIES_FILE, Policy),
        (PLANS_DIR, Plan),
        (APPS_FILE, App),
    ]
    
    for filepath, model in memory_map:
        if filepath == PLANS_DIR:
             print(f"  ✓ {PLANS_DIR}: Individual JSON files directory")
             continue

        if not os.path.exists(filepath):
            print(f"  - {filepath}: Not found (Empty memory is valid)")
            continue
            
        try:
            # verify_jsonl validates schema without loading all entries into memory
            count = verify_jsonl(filepath, model)
            print(f"  ✓ {filepath}: Valid ({count} entries)")
        except ValidationError as e:
            errors.append(f"Corruption in {filepath}: {e}")
        except Exception as e:
            errors.append(f"Unexpected error reading {filepath}: {e}")

    # Summary
    if errors:
        print("\n❌ Healthcheck failed with the following issues:")
        for err in errors:
            print(f"  - {err}")
        sys.exit(1)
    else:
        print("\n✅ Healthcheck passed! All systems nominal.")


@app.command("ui", rich_help_panel="Developers")
def run_ui() -> None:
    """Launch the Spex visual memory in the browser"""
    import webbrowser
    import time
    
    # Path to the streamlit app script
    ui_dir = Path(__file__).parent / "ui"
    app_script = ui_dir / "memory.py"
    
    if not app_script.exists():
        print(f"Error: UI app script not found at {app_script}", file=sys.stderr)
        sys.exit(1)

    # Launch streamlit
    cmd = [
        sys.executable, "-m", "streamlit", "run",
        str(app_script),
        "--server.port", "5888",
        "--server.headless", "true",
        "--browser.gatherUsageStats", "false"
    ]
    
    # Ensure memory dir exists so streamlit doesn't crash on startup if no memory yet
    Path(".spex/memory").mkdir(parents=True, exist_ok=True)
    
    print("Launching Spex UI at http://localhost:5888/ ...")
    print("Press Ctrl+C to stop the server.")
    
    process = None
    try:
        # Start the process
        process = subprocess.Popen(cmd)
        
        # Give it a couple of seconds to start before opening the browser
        time.sleep(3)
        
        # Open the browser
        webbrowser.open("http://localhost:5888/")
        
        # Wait for the process to finish (usually by Ctrl+C)
        process.wait()
    except KeyboardInterrupt:
        print("\nStopping Spex UI server...")
        if process:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
        print("Done.")
    except Exception as e:
        print(f"Error launching UI: {e}", file=sys.stderr)
        if process:
            process.kill()
        sys.exit(1)


@app.command("hook", hidden=True, rich_help_panel="System")
def run_hook(
    agent: Annotated[str, typer.Argument(..., help="Agent type: gemini, claude, cursor")],
    event: Annotated[str, typer.Argument(..., help="Hook event name")]
) -> None:
    """Run an agent hook."""
    if agent == 'gemini':
        from spex_cli.agents.providers.gemini import hooks
        hooks.run_hook(event)
    elif agent == 'claude':
        from spex_cli.agents.providers.claude import hooks
        hooks.run_hook(event)
    elif agent == 'cursor':
        from spex_cli.agents.providers.cursor import hooks
        hooks.run_hook(event)
    else:
        raise ValidationError(f"Unknown agent: {agent}")


@app.command("blame", rich_help_panel="System")
def blame(
    targets: Annotated[List[str], typer.Argument(..., help="One or more targets to blame. Format: 'file' or 'file:lines'")]
) -> None:
    """Find relevant context for files and line ranges"""
    blame_targets(targets)


@metric_app.command("report")
def report_metrics_cmd(
    feature_name: Annotated[Optional[str], typer.Option(help="Filter by feature name")] = None,
    plan_id: Annotated[Optional[str], typer.Option(help="Filter by plan ID")] = None
) -> None:
    """Generate metrics report for a feature"""
    report_metrics(feature_name=feature_name or "", plan_id=plan_id or "")


@app.command("enable", rich_help_panel="Developers")
def enable() -> None:
    """Set up spex in the current repository"""
    run_enable()

@app.command("disable", rich_help_panel="Developers")
def disable() -> None:
    """Remove spex git hook and revert agent settings"""
    run_disable()


@app.command("debug", rich_help_panel="Developers")
def debug(
    output_file: Annotated[str, typer.Argument(..., help="File to write environment variables to")]
) -> None:
    """Debug command to write environment variables to a file"""
    run_debug(output_file)


@app.command("ls", rich_help_panel="Memory")
def ls(
    entity: Annotated[str, typer.Argument(help="Entity type to list (app, policy, requirement, decision)")],
    active: Annotated[bool, typer.Option("--active", help="Only show active entities")] = False,
    plan_id: Annotated[Optional[str], typer.Option("--plan-id", help="Filter by plan ID (for decisions/requirements)")] = None,
    entry_id: Annotated[Optional[str], typer.Option("--id", help="Filter by specific entity ID")] = None
) -> None:
    """List memory entities using jq for streaming memory efficiency"""
    entity = entity.lower()
    
    if entity == "app":
        filepath = APPS_FILE
    elif entity == "policy":
        filepath = POLICIES_FILE
    elif entity == "requirement":
        filepath = REQUIREMENTS_FILE
    elif entity == "decision":
        filepath = DECISIONS_FILE
    else:
        raise click.ClickException(f"Unknown entity type: '{entity}'. Supported: app, policy, requirement, decision")
        
    if not os.path.exists(filepath):
        print("[]")
        return

    # Build jq query pipeline
    filters = []
    if active:
        filters.append('reduce inputs as $i ({}; .[$i.id] = $i) | .[] | select(.status == "active")')
    else:
        filters.append('inputs')

    if plan_id:
        if entity == "requirement":
            filters.append(f'select(.planId == "{plan_id}")')
        elif entity == "decision":
            filters.append(f'select(.grounding?.planId == "{plan_id}")')
        else:
            raise click.ClickException(f"--plan-id filter is not supported for entity type: '{entity}'")

    if entry_id:
        filters.append(f'select(.id == "{entry_id}")')

    jq_filter = " | ".join(filters)
    jq_query = f"[{jq_filter}]"
    
    cmd = ["jq", "-n", "-c", jq_query, filepath]

    try:
        subprocess.run(cmd, check=True)
    except subprocess.CalledProcessError as e:
        raise click.ClickException(f"Failed to query {entity} data with jq (exit code: {e.returncode})")



def main():
    setup_logging(get_session_id_func=get_session_id)
    try:
        app(standalone_mode=False)
    except BaseException as e:
        if isinstance(e, (SystemExit, typer.Exit)):
             exit_code = getattr(e, "code", getattr(e, "exit_code", 0))
             sys.exit(exit_code)
        
        if isinstance(e, (ValidationError, ReferenceError)):
             print(f"Error: {e}", file=sys.stderr)
             sys.exit(1 if isinstance(e, ValidationError) else 3)
        
        if isinstance(e, click.ClickException):
             e.show()
             sys.exit(e.exit_code)
             
        logging.error(f"Unexpected error: {e}", exc_info=True)
        traceback.print_exc(file=sys.stderr)
        sys.exit(1)



if __name__ == '__main__':
    main()
