---
name: spex-reflect
description: Analyzes a completed feature development cycle to identify missing context, confusing decisions, and propose actionable memory updates. Invoke manually after feature completion.
triggers:
  - "spex reflect"
  - "use spex to reflect"
  - "reflect on this feature"
  - "analyze this feature"
  - "extract learnings"
  - "propose memory updates"
---

# Reflection Skill

Analyzes the entire feature development lifecycle to identify what context was missing, what context was confusing, and propose actionable memory updates that can guide future development.

## Purpose

You are a reflection agent. Your goal is to review a completed feature, extract meaningful learnings about our memory gaps, and propose actionable Memory Updates (Policies, Domain Knowledge, and Context Deprecation) to ensure we don't repeat mistakes next time.

## When to Invoke

This skill should be invoked **manually** after a feature has been completed. It is NOT part of the automatic Spex state machine flow, but rather a deliberate step to capture knowledge and improve future development.

## Core Workflow

### 1. Gather Context

**Required Inputs:**
- **Frozen Plan Artifact**: Load `plan.md` from `.spex/plans/<feature-name>/` directory
- **Plan Object**: Read the central Plan from the memory directory to understand the original goal, feature scope, and metadata.
- **Decision Records**: Read all decisions using `spex ls decision --plan-id <P-ID>` associated with this feature's plan ID
- **Requirement Records**: Read all requirements using `spex ls requirement --plan-id <P-ID>` for this feature
- **Trace Records**: Review decision traces from `.spex/memory/traces.jsonl` for this feature
- **Metrics Report**: Run `spex metric report --feature-name <feature-name>` to get quantitative data (state transitions, memory lookups, memory writes, user prompts). Use this data to ground your qualitative analysis with numbers.
- **User Feedback**: Review entire conversation transcript for user corrections, guidance, and feedback at every stage

**Context Questions to Answer:**
1. What was the original goal?
2. What requirements were identified?
3. What decisions were made (architectural, structural, tactical)?
4. How did the implementation align with the plan?
6. How many iterations were needed for evidence gathering, conflict resolution, or plan refinement?

### 2. Analyze Major Learnings

Identify key insights from the development process. Focus strictly on actionable context changes:

#### Missing Context
- **Question**: What didn't we know when we started? Did we need multiple research iterations to find simple facts?
- **Learning**: What specific rules, constraints, architectural patterns, or domain knowledge were we missing?
- **Insight**: What context should we explicitly add to memory for the next agent?

#### Confusing Context
- **Question**: Were there existing decisions, requirements, or policies that actively confused the agent or caused friction?
- **Learning**: What specific records were outdated, overly restrictive, or poorly communicated?
- **Insight**: What context should we deprecate or clarify to avoid repeating this confusion?

#### User Guidance & Corrections
- **Question**: Did the user have to correct or guide the agent at any point during the conversation? What blind spots did they catch?
- **Learning**: What specific details, requirements, constraints, or stylistic preferences were corrected?
- **Insight**: How do we encode this preference or correction so the user never has to correct us on this again?

### 3. Optional: Ask Clarifying Questions

If there are ambiguities in the gathered context, or if you are unsure *why* a specific decision was made or *what* information was missing, use your `AskUserQuestion` tool (or standard interaction) to ask the user.
- **Why ask?**: Proposing a memory update without understanding the root cause of friction can lead to unhelpful or overly broad policies.
- **When to ask?**: Do this *before* proposing memory updates if you suspect you might be missing the "why" behind a user's correction or architectural choice.

### 4. Propose Memory Updates

Memory updates are **actionable changes** to the long-term memory that directly address the learnings above.

There are three types of Memory Updates you can propose:

#### 1. Policies
Broad, governing rules (architectural, tactical, or behavioral) that serve as guardrails to prevent repeated mistakes and enforce better decisions across the entire project.
- **Criteria**: Should NOT be specific to a single file or folder. Must be a highly reusable governing rule that enforces consistency and reduces ambiguity for future features.
- **Format**: Requires Category, Title, Statement, Rationale, Examples (Good/Bad), and Exceptions.

#### 2. Context Deprecation / Correction
Identifying existing requirements, decisions, or policies that actively confused the planning phase or caused execution drift.
- **Strict Rule**: Only propose deprecation if you have **High Confidence**. Before suggesting deprecation, you MUST carefully consider all downstream implications and other features that might depend on this context. 
- **Format**: Requires Target ID, Rationale for Deprecation, and Proposed Replacement (if any).

#### 3. Domain Knowledge
Capturing specific constraints, structural setups, or project-specific requirements discovered during this feature that are highly likely to be relevant for future work.
- **Criteria**: Not a broad "rule", but a specific fact ("Our backend uses X for Y", "The `foo` module depends on `bar` via a hidden webhook").
- **Format**: Requires Statement, Scope, and Rationale.

### 5. Generate Reflection Report

Create a reflection report saved to `.spex/plans/<feature-name>/reflection.md`. Focus ONLY on actionable insights and updates:

```markdown
# Reflection: <Feature Name>

**Feature**: <feature-name>
**Plan ID**: <PLAN-ID>
**Completed**: <timestamp>

---

## 🎯 Major Learnings

### What Context Was Missing?
- <Insight 1>
- <Insight 2>

### What Context Was Confusing?
- <Insight 1>
- <Insight 2>

### User Corrections
- <Correction 1>
- <Correction 2>

---

## ⚡ Proposed Memory Updates

### Policies
- **POL-XXX**: <Title> - <Statement>

### Context Deprecation
- **Deprecate <ID>**: <Rationale>

### Domain Knowledge
- **New Fact**: <Statement>

---

## 🔄 Next Steps

**Decision required:** Do you approve these memory updates?

- **If approved**: I will use the `spex` CLI to persist the policies, domain knowledge, and deprecations to memory.
- **If refinement needed**: Please provide feedback, and I will update the reflection report.
```

### 6. Present to User (Human Checkpoint)

Present the reflection report to the user using this template:

```markdown
# 🔍 Reflection: <Feature Name>

I've completed a reflection on the <feature-name> feature development cycle. Here's what I propose for our memory:

## 🎯 Major Learnings
- <Top 1-2 missing context insights>
- <Top 1-2 confusing context insights>

## ⚡ Proposed Memory Updates
I've identified <N> actionable updates for our long-term memory:

| Type | Target/Title | Rationale |
|------|--------------|-----------|
| Policy | <Title> | ... |
| Deprecation | <ID> | ... |
| Domain Info | <Fact> | ... |

**Full details are in `.spex/plans/<feature-name>/reflection.md`**

---

**Decision required:** Do you approve these memory updates?
- **Yes**: I will persist the approved updates to Spex memory
- **No/Modify**: Please provide feedback, and I will refine the reflection
```

### 7. Persist Approved Updates

**ONLY** if the user approves the updates, persist them using the appropriate `spex` CLI commands:

- **For Policies**: Use `spex policy add ... `
- **For Deprecations**: Use `spex decision modify/deprecate ... ` or `spex requirement modify/deprecate ... ` depending on the entity type.
- **For Domain Knowledge**: Use the appropriate requirement or decision CLI command to add new contextual facts.

**Notes:**
- IDs are auto-generated by the CLI for new entities. Do not provide `--id` for insertions.
- The CLI handles validation, versioning, and timestamps automatically.
- If a command fails (e.g., invalid reference), fix the issue and retry.

**After Persistence:**
- Update `reflection.md` with any official IDs returned by the CLI
- Confirm to the user that memory has been successfully updated.

## Output Artifacts

1. **Reflection Report**: `.spex/plans/<feature-name>/reflection.md`
   - Major learnings
   - Proposed memory updates

2. **Updated Memory**: Modifies memory via CLI
   - New policies, deprecated context, and domain knowledge added

## Best Practices

### Be Project-Specific, Not Generic
- Reflection is NOT for generating generic software engineering advice that applies to any project. It is for capturing knowledge specific to *this* codebase, *this* team, and *these* requirements.
- ❌ **Bad (Too Generic)**: "We should write better tests." or "Every React component should have unit tests."
- ✅ **Good (Project-Specific)**: "When adding new Spex CLI commands, test coverage must specifically mock the `MemoryManager` to avoid side-effects in memory."

### Focus on Patterns, Not One-Offs
- ❌ **Bad (Too Generic / One-Off)**: "Use `useState` for the research findings toggle."
- ✅ **Good (Project-Specific Pattern)**: "In the Spex React frontend, use `useState` for simple boolean UI toggles; but use the centralized `useSpexState` reducer for any state that syncs with the backend agent."

### Distinguish Policies from Domain Knowledge
- **Policies** are broad, governing rules and guardrails valid across the project. They govern *how* we build things (e.g., "All DB queries must go through the repository layer").
- **Domain Knowledge** is a specific fact or constraint. It captures *what* exists (e.g., "The `UserService` relies on a legacy SOAP API for authentication"). Don't make a specific fact into a generic policy.

### Ground Updates in Evidence
- Every memory update should reference specific friction points in this conversation that led to it.
- Updates without grounding are just opinions.

### Make Updates Actionable
- Rules and knowledge should be clear enough that a future developer can follow them without ambiguity.
- Include examples of both good and bad implementations for policies.

### Acknowledge Trade-offs
- No policy is universal; document exceptions and edge cases.
- Be honest about when a policy might not apply.

## Common Pitfalls to Avoid

1. **Over-Deprecating**: Do not suggest removing context unless there is high confidence it actively harmed the current feature's development. Always consider downstream impacts.
2. **Under-Specifying**: Vague updates like "keep code clean" are not useful. Be precise.
3. **Ignoring Exceptions**: Policies should acknowledge when they don't apply.
4. **Skipping Rationale**: Always explain *why* an update matters, not just *what* it is.

## Integration with Spex Orchestration

While this skill is **manually invoked**, it fits into the broader Spex workflow:

1. **After COMPLETE**: Once a feature is marked as COMPLETE, the user can choose to invoke the `reflect` skill.
2. **Standalone Use**: The skill can also be invoked independently to analyze historical features or patterns across multiple features.
3. **Memory Evolution**: Over time, context can be refined or deprecated based on new learnings.

> [!IMPORTANT]
> This skill is NOT part of the automatic Spex state machine. It must be explicitly invoked by the user or agent when reflection is desired.


**Taxonomy & Governance:**

In a healthy model, knowledge flows from intent to action:
**Requirement (Why)** → **Policy (Law)** → **Decision (How)** → **Trace (Proof)**

#### Requirements (Problem Space)
Define **WHAT** the system must achieve or **WHICH** boundaries it must respect.

> [!IMPORTANT]
> **Source of Truth**: Requirements must originate EXCLUSIVELY from user input (prompts, documents, or explicit directions). Agents MUST NOT infer requirements; all functional and non-functional requirements must be citable back to a user-provided source.

| Type | Name | Definition | Example |
| :--- | :--- | :--- | :--- |
| **FR** | Functional | Specific behavior or feature. | "User can export data to CSV." |
| **NFR** | Non-Functional | Quality attributes (perf, security, UX). | "Exports must complete in <2s." |
| **CR** | Constraint | External, non-negotiable limitation. | "Must use AWS Frankfurt region." |
| **UR** | User-Specified | Raw input from user (needs refinement). | "Make it feel 'snappy'." |

#### Policies (Standing Laws)
A **Policy** is a reusable, mandatory rule that bridges Requirements and Decisions.
*   **Trigger**: Use a policy when you make the same recommendation >2 times.
*   **Scope**: Usually global or cross-application.
*   **Enforcement**: Mandatory. Deviations require an Architectural Decision (Policy Exception).
*   **Example**: *"All API calls must use Circuit Breakers to satisfy NFR (Resiliency)."*

#### Decisions (Action Space)
Defined by their **Reversibility** and **Impact**.

| Class | Reversibility | Impact | Definition |
| :--- | :--- | :--- | :--- |
| **Architectural** | High Cost | System-wide | Choices affecting core frameworks or primitives. |
| **Structural** | Moderate Cost | Component | Choices regarding organization or API contracts. |
| **Tactical** | Low Cost | Local/File | Logic, algorithms, or localized patterns. |

#### Governance Rules

1.  **Reversibility Filter (Avoid Bloat)**: Do not record every choice.
    - **Implicit follows Policy**: If a choice simply follows an existing Policy, **don't record it** as a separate decision.
    - **Explicit Deviation**: If you MUST break a policy, you MUST record it as a Decision.
    - **Arch/Struct Only**: Always record Architectural and Structural choices. Record Tactical only if logic is unintuitive.
2.  **Negative Knowledge**: Always document **Alternatives Considered** for Architectural and Structural decisions.
3.  **Promotion Strategy**:
    - **UR → FR/NFR**: Refine raw User Requirements into testable FRs/NFRs during research. *Note: Refinement must only clarify or formalize user intent, never invent it.*
    - **Tactical → Policy**: If a Tactical Decision is repeated across tasks, "promote" it to a Policy in the `REFLECT` phase.

**Validation:**
**Classification**: Adhere strictly to the definitions in Taxonomy & Governance when defining items.
**Traceability**: Every **Requirement** defines a user-facing capability. Every **Decision** defines the technical approach.
**Policies**: Mandatory standing rules for autonomous execution.
