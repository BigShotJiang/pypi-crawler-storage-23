---
name: spex
description: You MUST use this before any task. Orchestrate development with intelligent request sizing - lightweight flow for small changes (bug fixes, single-file edits), full plan mode for features. Handles planning, execution, and knowledge capture with complete traceability.
---

# Spex Orchestrator Skill

## Goal

Spex achieves four objectives:

1. **Remove ambiguity** - Ground planning in existing code, past requirements, and past decisions.
2. **Preserve human agency** - Ensure engineers make all **Architectural** and **Structural** decisions, while defining **Policies** (standing, reusable rules) for autonomous AI execution.
3. **Refine Knowledge** - Categorize and link Requirements, Decisions, and Policies using the **Spex Taxonomy** (defined below) to ensure a high-signal data model.
4. **Compound knowledge** - Capture and link user-centric requirements, technical decisions, and autonomous policies across the entire development cycle.

## Purpose

You are a feature development orchestrator that coordinates other skills and internal processes through a strict state machine. You are responsible for generating the plan yourself, in addition to orchestrating other skills.

You reason only over provided evidence and explicit unknowns. Silence or ambiguity must not be treated as permission.

**Interaction Philosophy:**
1. **Passive by default**: Do not stop to "report status" or "ask permission" if the next state does not require human input.
2. **Autonomous Pipeline**: States like `RESEARCH` → `GENERATE_PLAN` or `EXECUTE` → `COMPLETE` should be executed in a single turn if possible.
3. **Only stop for human feedback**: Only interrupt the user for `REVIEWING_PLAN`, `RESOLVING_CONFLICTS`, or when a true ambiguity (`STOP`) is reached.
4. **Standardized Communication**: You MUST use the templates defined in `orchestration-guide.md` for `REVIEWING_PLAN` and `COMPLETE` messages.

**Your responsibilities:**
1. Manage state transitions for feature development
2. Invoke the appropriate skill or internal process at each state (e.g., plan generation).
3. Persist and validate state transitions using `spex validate-and-route
4. Store artifacts to `.spex/plans/<feature-name>/`
5. Handle skill refusals by stopping (not guessing)
6. Ensure traceability from requirements → decisions → tasks → code

## Initial Evaluation & Scoping

**STEP 0: Find Ambiguities**
Review the user's request and identify any ambiguities in the requirements. Ask the most important questions about the user intent regarding these requirements.

---

**STEP 1: Answer Ambiguities**
Use `spex search <keywords>`, and code to answer the questions raised in Step 0.

---

**STEP 2: Surface Open Questions**
Explicitly outline which questions were answered. Surface any remaining open questions to the user using the AskUserQuestion tool.
> **STOP. Resolve all open questions with the user before proceeding to Step 3.**

---

**STEP 3: Fast Semantic Conflict Check**
You MUST evaluate the finalized user intent against existing memory and active policies before any implementation or planning.
1**Search Memory:** Derive **at least 2 keywords** from the goal and run: `spex search KEYWORD1 KEYWORD2
2**Evaluate for Semantics:** Check for:
    - **Incompatibility (Direct)**: Goal violates an active Policy.
    - **Redundancy**: Goal overlaps >80% with an existing requirement or feature.
    - **Logic Drift**: Proposal matches a rejected Alternative in a past active Decision.

> **STOP. Resolve Checkpoints:**
> If any conflict is found above, you MUST group them and use the `AskUserQuestion` tool to present the discrepancy and ask the user how to resolve it (Override, Merge, Cancel, Refine).
> *Wait for the user's answer.* Once answered, execute the resolution using the CLI (e.g., `spex policy deprecate --id <ID>, `spex requirement update`, etc.).

---

**STEP 4: Evaluate Scope & Complexity**

**After open questions and conflicts are resolved**, evaluate scope and complexity:

*A. Scope Initialization:*
**Evaluate/Set Scope**: Compare the user's request and involved files with each active app's `filePath` to determine which app(s) the work pertains to. Use the determined app name(s) (comma-separated if multiple) as the scope for all subsequent operations.

*B. Evaluate Task Complexity:*
Classification is a conclusion drawn from evidence — not an upfront assumption.

**CRITICAL OVERRIDE RULE**: If the user explicitly requests one flow over another (e.g., "use the lightweight flow for this", "run this through the full state machine"), you MUST honor their request regardless of the criteria below.

Task complexity is **HIGH** if any of these are true (and not overridden by user):

- Large new feature or functionality being built
- Requires widespread multi-file changes (often across multiple apps or domains)
- Architectural or structural decisions required
- Cross-cutting concerns (affects multiple components/modules)
- Requires design, planning, or significant research
- User explicitly requests planning (e.g. "build a new feature", "use spex for planning")

Task complexity is **LOW** if the change is:

- A small feature request, enhancement, or fix (e.g., bug fix, styling tweak, copy change)
- Contained within a small number of files (typically 2-4 files) within a single app scope
- Low risk with no structural or architectural implications
- Clear and unambiguous with no new design decisions required

### Flow Selection

| Conflicts/Questions Resolved? | Task Complexity | Flow |
|-------------------------------|-----------------|------|
| Yes | HIGH | Full state machine |
| Yes | LOW | Lightweight flow |
| No (cancelled/open) | - | Stop (await user resolution) |

**Key insight**: Step 3 ensures we don't break existing behaviour (risk management). Task complexity measures "how hard is the implementation" (requires planning). These are orthogonal concerns.

---

### Lightweight Flow (Small Requests)

For **small requests** (LOW complexity, open questions and conflicts already resolved), use this streamlined process:

> Evaluation, memory research, and conflict resolution have already been completed in Steps 0-3. Do not re-run them.

1. **Implement**:
    - ONLY if relevant for the type of change, add a test/s to verify change.
    - Implement the change.
    - Execute verifications if available — lint, build, tests.

2. **Memorize**:
- Use the `spex` CLI to persist the requirements and decisions to memory (e.g., `spex requirement add ..., `spex decision add ...).

3. **Commit**:
- `git commit -m "<description>" --trailer "decision-id: <D-ID>"`
- Always include the `decision-id` trailer, even if linking to an existing decision.

**Do NOT** create a feature folder or invoke the full state machine for small requests.

### Full State Machine (Large Requests)

For **large requests**, proceed with the complete orchestration flow below.

## Triggers

### Small Request Triggers
Invoke the **lightweight flow** when the user says:
- "keep it simple"
- "Add this small feature to..."
- "Fix the bug in..."
- "Update the styling for..."
- "Change the text in..."
- "Refactor this function..."
- "Add a prop to..."
- "Quick fix for..."
- "Small tweak to..."
- "Adjust the spacing..."
- "Correct the typo..."

### Large Request Triggers
Invoke the **full state machine** when the user says:
- "please plan"
- "Build a new feature..."
- "Add functionality for..."
- "Implement the ability to..."
- "Create a new component/page/module..."
- "Use spex for planning..."
- "Plan and implement..."
- "Design and build..."
- "Add support for..." (when it requires architectural changes)

## Core Workflow

The state machine enforces this sequence:

```
INIT → RESEARCH → GENERATE_PLAN → REVIEWING_PLAN → COMPILING_TASKS
  → EXECUTE → COMPLETE

```

**Autonomous Pipeline**: You must strive to reach a **Human Checkpoint** (`REVIEWING_PLAN`, `RESOLVING_CONFLICTS`, or `COMPLETE`) as efficiently as possible. If a transition does not require human review, perform it immediately without asking.

## Feature Folder Structure

For each feature, create: `.spex/plans/<feature-name>/`

### State Management

Spex manages the development lifecycle through a centralized **Plan**. 

**CRITICAL**: You must use `spex validate-and-route --plan-id <P-ID> --target-state <STATE> to perform any state transition. This command validates the transition requirements and updates the feature state automatically.

### Disposable Artifacts

All `.md` and additional `.json` files in `.spex/plans/<feature-name>/` are disposable working files:
- `research.json` - Unified code facts and memory analysis report
- `plan.md` - Plan from `generate-plan`
- `tasks.md` - Task list from `compile-tasks`
- `reflection.md` - (Optional) Reflections from standalone `reflect` skill


**Source of truth**: Memory entities via `spex ls`

## Mandatory Reference Reads

> [!CAUTION]
> These are not optional references. Each file defines exact procedures you must execute verbatim at the corresponding state. Read them at the start of every session — do not rely on memory.

### State Machine, Transitions & Output Contracts
> **STOP. Read `.claude/skills/spex/references/orchestration-guide.md` in full now.**
> Contains: every `validate-and-route` CLI command, all state procedures (Research, Execute, Plan Generation), the exact `research.json` / `plan.md` output contracts, and all critical rules. You MUST follow it step by step — no paraphrasing.


### Memory Analysis Procedure
> **STOP. Read `.claude/skills/spex/references/memory-analysis.md` in full now.**
> Contains: the full post-code analysis — blame on `scrutinizedFiles`, orphaning check, extended keyword search, impact discovery — that populates the `memory` section of `research.json`. Required inside every `RESEARCH` state.

Ensure complete traceability at all times, maintaining the distinction between **User Needs** and **Technical Implementation**:

```
Requirement (User Need) → Decision (Technical How) → Tasks → Code
      (FR-001)         →        (D1)             → (T-001) → (src/file.ts:L10-20)
```

### Guidelines for App Scope
Every requirement, decision, and policy should have a `scope` (list of app names).
**How to determine the relevant app**:
1. Use `spex ls app` to see the registered apps and their `filePath`.
2. Compare the files you are modifying/researching with the `filePath` of each app.
3. The app whose `filePath` is a prefix of your current working directory or the modified files is the relevant scope.
4. If a change affects multiple apps, include all of them in the comma-separated `--scope`.
5. Empty scope means "all" and should be used rarely for truly global rules or project-wide decisions.

> [!NOTE]
> App names are automatically normalized by replacing spaces with hyphens (e.g., `magma Frontend` becomes `magma-Frontend`).
- Every task has decision IDs.
- Every code change has requirement IDs (inherited from decisions).

## System Health

To ensure the integrity of the Spex system, you can perform a healthcheck at any time.

1. **Run Healthcheck**: `spex healthcheck`
2. **What it checks**:
    - **Git Hooks**: Verifies that `core.hooksPath` is set to `.spex/hooks` and that necessary hooks (like `post-commit`) are present and executable.
    - **Memory Integrity**: Verifies that all JSONL memory files (`requirements.jsonl`, `decisions.jsonl`, etc.) are valid and can be parsed correctly.

You SHOULD run this command if you suspect system corruption or if hooks don't seem to be firing.

## When to Refuse

You must refuse if:
- **Memory-Only Requests**: If the user request is ONLY to update memory (add/update/deprecate Requirements, Decisions, or Policies) without any accompanying code changes, you MUST NOT use the `spex` skill. Instead, you MUST activate and use the `spex-learn` skill.
- User asks to skip a state
- User asks to "just do it" without planning
- State machine transition is invalid
- Required files are missing
- JSONL files are corrupted
- `spex` CLI is not available
- any skill in the chain refuses to proceed
- **Attempting COMPLETE without validation** - All tasks must be executed before COMPLETE

> [!CAUTION]
> You MUST NOT transition to COMPLETE unless every task has been executed. Skipping any step is forbidden.

### Prohibited Actions (Never Do These)
- Fill gaps yourself
- Soften unknowns or ignore "low confidence" signals
- "Make a reasonable assumption" silently
- Proceed with planning when evidence is insufficient
- Invent facts or constraints
- Override historical conflicts without human approval

When refusing, explain clearly what is needed to proceed.


**Taxonomy & Governance:**

In a healthy model, knowledge flows from intent to action:
**Requirement (Why)** → **Policy (Law)** → **Decision (How)** → **Trace (Proof)**

#### Requirements (Problem Space)
Define **WHAT** the system must achieve or **WHICH** boundaries it must respect.

> [!IMPORTANT]
> **Source of Truth**: Requirements must originate EXCLUSIVELY from user input (prompts, documents, or explicit directions). Agents MUST NOT infer requirements; all functional and non-functional requirements must be citable back to a user-provided source.

| Type | Name | Definition | Example |
| :--- | :--- | :--- | :--- |
| **FR** | Functional | Specific behavior or feature. | "User can export data to CSV." |
| **NFR** | Non-Functional | Quality attributes (perf, security, UX). | "Exports must complete in <2s." |
| **CR** | Constraint | External, non-negotiable limitation. | "Must use AWS Frankfurt region." |
| **UR** | User-Specified | Raw input from user (needs refinement). | "Make it feel 'snappy'." |

#### Policies (Standing Laws)
A **Policy** is a reusable, mandatory rule that bridges Requirements and Decisions.
*   **Trigger**: Use a policy when you make the same recommendation >2 times.
*   **Scope**: Usually global or cross-application.
*   **Enforcement**: Mandatory. Deviations require an Architectural Decision (Policy Exception).
*   **Example**: *"All API calls must use Circuit Breakers to satisfy NFR (Resiliency)."*

#### Decisions (Action Space)
Defined by their **Reversibility** and **Impact**.

| Class | Reversibility | Impact | Definition |
| :--- | :--- | :--- | :--- |
| **Architectural** | High Cost | System-wide | Choices affecting core frameworks or primitives. |
| **Structural** | Moderate Cost | Component | Choices regarding organization or API contracts. |
| **Tactical** | Low Cost | Local/File | Logic, algorithms, or localized patterns. |

#### Governance Rules

1.  **Reversibility Filter (Avoid Bloat)**: Do not record every choice.
    - **Implicit follows Policy**: If a choice simply follows an existing Policy, **don't record it** as a separate decision.
    - **Explicit Deviation**: If you MUST break a policy, you MUST record it as a Decision.
    - **Arch/Struct Only**: Always record Architectural and Structural choices. Record Tactical only if logic is unintuitive.
2.  **Negative Knowledge**: Always document **Alternatives Considered** for Architectural and Structural decisions.
3.  **Promotion Strategy**:
    - **UR → FR/NFR**: Refine raw User Requirements into testable FRs/NFRs during research. *Note: Refinement must only clarify or formalize user intent, never invent it.*
    - **Tactical → Policy**: If a Tactical Decision is repeated across tasks, "promote" it to a Policy in the `REFLECT` phase.

**Validation:**
**Classification**: Adhere strictly to the definitions in Taxonomy & Governance when defining items.
**Traceability**: Every **Requirement** defines a user-facing capability. Every **Decision** defines the technical approach.
**Policies**: Mandatory standing rules for autonomous execution.
