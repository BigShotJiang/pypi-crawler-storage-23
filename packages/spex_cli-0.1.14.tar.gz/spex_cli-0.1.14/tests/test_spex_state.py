import json
import pytest
from datetime import datetime


@pytest.fixture
def temp_spex_env(tmp_path):
    """Setup a temporary .spex directory structure"""
    spex_dir = tmp_path / ".spex"
    memory_dir = spex_dir / "memory"
    memory_dir.mkdir(parents=True)
    
    # Global memory files
    (memory_dir / "requirements.jsonl").touch()
    (memory_dir / "decisions.jsonl").touch()
    (memory_dir / "plans").mkdir(parents=True, exist_ok=True)
    (memory_dir / "traces.jsonl").touch()
    
    return tmp_path

def run_spex(cwd, args):
    """Run spex CLI with args"""
    import subprocess
    import os
    import sys
    from pathlib import Path
    env = os.environ.copy()
    # Add src to PYTHONPATH
    src_dir = str(Path(__file__).parent.parent / "src")
    env["PYTHONPATH"] = src_dir
    main_py = str(Path(src_dir) / "spex_cli" / "main.py")
    return subprocess.run([sys.executable, main_py] + args, cwd=cwd, capture_output=True, text=True, env=env)

def init_feature(env, name, plan_id="P-TEST-1"):
    """Initialize a feature directory and a plan in memory"""
    feat_dir = env / ".spex" / "plans" / name
    feat_dir.mkdir(parents=True)
    
    plans_dir = env / ".spex" / "memory" / "plans"
    plans_dir.mkdir(parents=True, exist_ok=True)
    
    plan_data = {
        "id": plan_id,
        "version": 1,
        "status": "draft",
        "createdAt": datetime.now().isoformat(),
        "author": "test",
        "featureName": name,
        "goal": "test goal",
        "scope": [],
        "currentState": "INIT",
        "sessionIds": []
    }
    with open(plans_dir / f"{plan_id}.json", "w") as f:
        json.dump(plan_data, f)
    
    return feat_dir

def test_valid_transition_init_to_research(temp_spex_env):
    init_feature(temp_spex_env, "feat1")
    res = run_spex(temp_spex_env, ["validate-and-route", "--plan-id", "P-TEST-1", "--target-state", "RESEARCH"])
    assert res.returncode == 0
    data = json.loads(res.stdout)
    assert data["valid"] is True
    assert data["nextState"] == "RESEARCH"

    # Verify plan was updated in central memory
    with open(temp_spex_env / ".spex/memory/plans/P-TEST-1.json", "r") as f:
        plan = json.load(f)
        assert plan["currentState"] == "RESEARCH"

def test_invalid_transition(temp_spex_env):
    init_feature(temp_spex_env, "feat1")
    # INIT -> GENERATE_PLAN is invalid
    res = run_spex(temp_spex_env, ["validate-and-route", "--plan-id", "P-TEST-1", "--target-state", "GENERATE_PLAN"])
    assert res.returncode != 0
    data = json.loads(res.stdout)
    assert data["valid"] is False
    assert "Invalid transition" in data["error"]

def test_missing_artifact_enforcement(temp_spex_env):
    init_feature(temp_spex_env, "feat1")

    # First move to RESEARCH
    run_spex(temp_spex_env, ["validate-and-route", "--plan-id", "P-TEST-1", "--target-state", "RESEARCH"])

    # Now try to move to GENERATE_PLAN without research.json
    res = run_spex(temp_spex_env, ["validate-and-route", "--plan-id", "P-TEST-1", "--target-state", "GENERATE_PLAN"])
    assert res.returncode != 0
    data = json.loads(res.stdout)
    assert data["valid"] is False
    assert "Missing research.json" in data["error"]

def test_valid_research_to_generate_plan_transition(temp_spex_env):
    feat_dir = init_feature(temp_spex_env, "feat1")
    run_spex(temp_spex_env, ["validate-and-route", "--plan-id", "P-TEST-1", "--target-state", "RESEARCH"])

    # Create research.json with memory section
    with open(feat_dir / "research.json", "w") as f:
        json.dump({"codebase": {"facts": []}, "memory": {"conflicts": []}}, f)

    res = run_spex(temp_spex_env, ["validate-and-route", "--plan-id", "P-TEST-1", "--target-state", "GENERATE_PLAN"])
    assert res.returncode == 0
    assert json.loads(res.stdout)["valid"] is True

def test_generate_plan_requires_memory_facts(temp_spex_env):
    feat_dir = init_feature(temp_spex_env, "feat1")
    # Fast track to RESEARCH in central memory
    plan_file = temp_spex_env / ".spex" / "memory" / "plans" / "P-TEST-1.json"
    with open(plan_file, "r") as f:
        plan = json.load(f)
        plan["currentState"] = "RESEARCH"
        with open(plan_file, "w") as wf:
            json.dump(plan, wf)

    # Create research.json WITHOUT 'memory' section
    with open(feat_dir / "research.json", "w") as f:
        json.dump({"codebase": {}}, f)

    res = run_spex(temp_spex_env, ["validate-and-route", "--plan-id", "P-TEST-1", "--target-state", "GENERATE_PLAN"])
    assert res.returncode != 0
    assert "missing 'memory' section" in json.loads(res.stdout)["error"]


def test_compiling_tasks_requires_approved_plan(temp_spex_env):
    """COMPILING_TASKS gate must find an approved plan via get_latest_jq (not get_latest_active_jq)."""
    init_feature(temp_spex_env, "feat1")

    # Fast-track to REVIEWING_PLAN in central memory
    plan_file = temp_spex_env / ".spex" / "memory" / "plans" / "P-TEST-1.json"
    with open(plan_file, "r") as f:
        plan = json.load(f)
    plan["currentState"] = "REVIEWING_PLAN"
    with open(plan_file, "w") as f:
        json.dump(plan, f)

    # Approve plan in central memory
    plan_file = temp_spex_env / ".spex" / "memory" / "plans" / "P-TEST-1.json"
    with open(plan_file, "r") as f:
        plan = json.load(f)
    plan["status"] = "approved"
    plan["approvedAt"] = datetime.now().isoformat()
    with open(plan_file, "w") as f:
        json.dump(plan, f)

    res = run_spex(temp_spex_env, ["validate-and-route", "--plan-id", "P-TEST-1", "--target-state", "COMPILING_TASKS"])
    assert res.returncode == 0, f"Expected success but got: {res.stdout} {res.stderr}"
    data = json.loads(res.stdout)
    assert data["valid"] is True
    assert data["nextState"] == "COMPILING_TASKS"
