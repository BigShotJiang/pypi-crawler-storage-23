"""Tests for the disable command.

Critical invariants:
- .spex/memory/ files are NEVER modified.
- Unrelated keys/values in agent settings.json are NEVER removed.
- Only the exact entries spex wrote (matched by value) are reverted.
"""

import json
import subprocess
from pathlib import Path

import pytest

from spex_cli.commands.disable import _deep_remove, _remove_git_hook, _revert_agent_settings


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def _read_json(path: Path) -> dict:
    with open(path) as f:
        return json.load(f)


@pytest.fixture()
def git_repo(tmp_path):
    subprocess.run(["git", "init", str(tmp_path)], check=True, capture_output=True)
    subprocess.run(["git", "config", "user.email", "t@t.com"], cwd=tmp_path, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.name", "T"], cwd=tmp_path, check=True, capture_output=True)
    return tmp_path


@pytest.fixture()
def spex_env(tmp_path):
    """Repo with populated .spex/memory/ files and no agent settings yet."""
    memory_dir = tmp_path / ".spex" / "memory"
    memory_dir.mkdir(parents=True)
    files = {
        "requirements.jsonl": '{"id":"FR-abc","status":"active"}\n',
        "decisions.jsonl":    '{"id":"D-abc","status":"active"}\n',
        "policies.jsonl":     '{"id":"P-abc","status":"active"}\n',
        "traces.jsonl":       '{"id":"T-abc","status":"active"}\n',
        "apps.jsonl":         '{"id":"APP-abc","status":"active"}\n',
    }
    for name, content in files.items():
        (memory_dir / name).write_text(content)
    
    plans_dir = memory_dir / "plans"
    plans_dir.mkdir(parents=True, exist_ok=True)
    (plans_dir / "PL-abc.json").write_text('{"id":"PL-abc","status":"draft"}\n')
    return tmp_path


def _memory_snapshot(env: Path) -> dict[str, str]:
    snapshot = {}
    memory_dir = env / ".spex" / "memory"
    for item in memory_dir.rglob("*"):
        if item.is_file():
            snapshot[str(item.relative_to(memory_dir))] = item.read_text()
    return snapshot


# ---------------------------------------------------------------------------
# _deep_remove unit tests
# ---------------------------------------------------------------------------

class TestDeepRemove:

    def test_removes_matching_scalar(self):
        result = _deep_remove({"a": "spex-val", "b": "keep"}, {"a": "spex-val"})
        assert "a" not in result
        assert result["b"] == "keep"

    def test_preserves_scalar_modified_by_user(self):
        """If the user changed a value after enable, do NOT remove it."""
        result = _deep_remove({"a": "user-changed"}, {"a": "original-spex-value"})
        assert result["a"] == "user-changed"

    def test_removes_only_matching_list_items(self):
        spex = ["Bash(python3 .spex/scripts/spex.py:*)", "Edit(.spex/**)"]
        user = ["Bash(npm run build:*)", "Bash(pytest:*)"]
        result = _deep_remove({"allow": user + spex}, {"allow": spex})
        assert result["allow"] == user

    def test_unmatched_list_items_untouched(self):
        user = ["Bash(npm run build:*)", "Bash(pytest:*)"]
        result = _deep_remove({"allow": user}, {"allow": ["something-spex-never-added"]})
        assert result["allow"] == user

    def test_empty_list_key_is_removed(self):
        result = _deep_remove({"allow": ["spex-only"]}, {"allow": ["spex-only"]})
        assert "allow" not in result

    def test_nested_dict_partial_removal(self):
        base = {
            "permissions": {"allow": ["spex-entry", "user-entry"]},
            "other": "untouched",
        }
        result = _deep_remove(base, {"permissions": {"allow": ["spex-entry"]}})
        assert result["permissions"]["allow"] == ["user-entry"]
        assert result["other"] == "untouched"

    def test_fully_empty_nested_dict_key_removed(self):
        hook = {"type": "command", "command": "spex hook claude inject_context"}
        base = {"hooks": {"SessionStart": [{"hooks": [hook]}]}}
        result = _deep_remove(base, {"hooks": {"SessionStart": [{"hooks": [hook]}]}})
        assert "hooks" not in result

    def test_unrelated_top_level_keys_never_touched(self):
        base = {"theme": "dark", "plugins": ["foo"], "nested": {"x": 1}}
        result = _deep_remove(base, {"nonexistent": "value"})
        assert result == base

    def test_key_absent_from_base_is_noop(self):
        result = _deep_remove({"a": 1}, {"b": 2})
        assert result == {"a": 1}

    def test_complex_list_items_matched_by_deep_equality(self):
        spex_hook = {"type": "command", "command": "spex hook claude inject_context"}
        user_hook = {"type": "command", "command": "echo hello"}
        result = _deep_remove({"hooks": [spex_hook, user_hook]}, {"hooks": [spex_hook]})
        assert result["hooks"] == [user_hook]

    def test_does_not_remove_superset_value(self):
        """Spex set 'x', user later added 'y' to the same list. Only 'x' goes."""
        result = _deep_remove({"tags": ["spex", "user-added"]}, {"tags": ["spex"]})
        assert result["tags"] == ["user-added"]


# ---------------------------------------------------------------------------
# _revert_agent_settings tests
# ---------------------------------------------------------------------------

class TestRevertAgentSettings:
    def test_returns_false_when_no_settings_file(self, tmp_path):
        assert _revert_agent_settings(tmp_path, "claude") is False

    def test_unrelated_keys_fully_preserved(self, tmp_path):
        settings_dst = tmp_path / ".claude" / "settings.local.json"
        original = {
            "theme": "dark",
            "keybindings": {"ctrl+s": "save", "ctrl+z": "undo"},
            "plugins": ["foo", "bar"],
            "telemetry": False,
        }
        _write_json(settings_dst, original)

        _revert_agent_settings(tmp_path, "claude")

        result = _read_json(settings_dst)
        assert result["theme"] == "dark"
        assert result["keybindings"] == {"ctrl+s": "save", "ctrl+z": "undo"}
        assert result["plugins"] == ["foo", "bar"]
        assert result["telemetry"] is False

    def test_agent_without_settings_file_configured_is_noop(self, tmp_path):
        """Agents with no settings_file key (e.g. agy, codex) never touch the fs."""
        changed = _revert_agent_settings(tmp_path, "agy")
        assert changed is False

    def test_hooks_key_only_spex_item_removed(self, tmp_path):
        """SessionStart hooks added by spex are removed; user hooks remain."""
        spex_hook_entry = {
            "hooks": [
                {"type": "command", "command": "spex hook claude session_start"},
                {"type": "command", "command": "spex hook claude inject_context"}
            ]
        }
        user_hook_entry = {"hooks": [{"type": "command", "command": "echo my-hook"}]}
        settings_dst = tmp_path / ".claude" / "settings.local.json"
        _write_json(settings_dst, {"hooks": {"SessionStart": [spex_hook_entry, user_hook_entry]}})

        _revert_agent_settings(tmp_path, "claude")

        result = _read_json(settings_dst)
        session_hooks = result["hooks"]["SessionStart"]
        assert spex_hook_entry not in session_hooks
        assert user_hook_entry in session_hooks

    def test_settings_file_written_as_valid_json(self, tmp_path):
        settings_dst = tmp_path / ".claude" / "settings.local.json"
        _write_json(settings_dst, {"permissions": {"allow": ["Edit(.spex/**)"]}, "x": 1})

        _revert_agent_settings(tmp_path, "claude")

        # Must be parseable JSON, not corrupted
        result = _read_json(settings_dst)
        assert isinstance(result, dict)


# ---------------------------------------------------------------------------
# _remove_git_hook tests
# ---------------------------------------------------------------------------

class TestRemoveGitHook:

    def test_unsets_when_pointing_to_spex_hooks(self, git_repo):
        subprocess.run(["git", "config", "core.hooksPath", ".spex/hooks"], cwd=git_repo, check=True)

        removed = _remove_git_hook(git_repo)

        assert removed is True
        r = subprocess.run(["git", "config", "core.hooksPath"], cwd=git_repo, capture_output=True)
        assert r.returncode != 0  # key is gone

    def test_noop_when_hook_not_configured(self, git_repo):
        assert _remove_git_hook(git_repo) is False

    def test_noop_when_hook_points_elsewhere(self, git_repo):
        subprocess.run(["git", "config", "core.hooksPath", "/other/path"], cwd=git_repo, check=True)

        removed = _remove_git_hook(git_repo)

        assert removed is False
        r = subprocess.run(["git", "config", "core.hooksPath"], cwd=git_repo, capture_output=True, text=True)
        assert r.stdout.strip() == "/other/path"  # left intact


# ---------------------------------------------------------------------------
# Memory safety — critical invariant
# ---------------------------------------------------------------------------

class TestMemorySafety:

    def test_memory_untouched_after_settings_revert(self, spex_env):
        before = _memory_snapshot(spex_env)

        settings = spex_env / ".claude" / "settings.local.json"
        settings.parent.mkdir(parents=True)
        settings.write_text(json.dumps({"permissions": {"allow": ["Edit(.spex/**)"]}}))

        _revert_agent_settings(spex_env, "claude")

        assert _memory_snapshot(spex_env) == before

    def test_memory_untouched_when_no_settings_file(self, spex_env):
        before = _memory_snapshot(spex_env)
        _revert_agent_settings(spex_env, "claude")
        assert _memory_snapshot(spex_env) == before

    def test_memory_untouched_after_hook_removal(self, spex_env):
        subprocess.run(["git", "init", str(spex_env)], check=True, capture_output=True)
        subprocess.run(
            ["git", "config", "core.hooksPath", ".spex/hooks"],
            cwd=spex_env, check=True, capture_output=True,
        )

        before = _memory_snapshot(spex_env)
        _remove_git_hook(spex_env)
        assert _memory_snapshot(spex_env) == before

    def test_memory_untouched_when_hook_not_set(self, spex_env):
        subprocess.run(["git", "init", str(spex_env)], check=True, capture_output=True)

        before = _memory_snapshot(spex_env)
        _remove_git_hook(spex_env)
        assert _memory_snapshot(spex_env) == before

    def test_all_memory_files_individually_untouched(self, spex_env):
        """Verify each memory file individually — not just directory equality."""
        memory_dir = spex_env / ".spex" / "memory"
        before = {
            "requirements.jsonl": (memory_dir / "requirements.jsonl").read_text(),
            "decisions.jsonl": (memory_dir / "decisions.jsonl").read_text(),
            "policies.jsonl": (memory_dir / "policies.jsonl").read_text(),
            "traces.jsonl": (memory_dir / "traces.jsonl").read_text(),
            "apps.jsonl": (memory_dir / "apps.jsonl").read_text(),
            "plans/PL-abc.json": (memory_dir / "plans" / "PL-abc.json").read_text(),
        }

        settings = spex_env / ".claude" / "settings.local.json"
        settings.parent.mkdir(parents=True)
        settings.write_text(json.dumps({
            "permissions": {"allow": ["Edit(.spex/**)", "Bash(pytest:*)"]},
            "hooks": {"SessionStart": [{"hooks": [{"type": "command", "command": "spex hook claude inject_context"}]}]},
        }))
        _revert_agent_settings(spex_env, "claude")

        for fname, content in before.items():
            assert (memory_dir / fname).read_text() == content, f"{fname} was modified"
