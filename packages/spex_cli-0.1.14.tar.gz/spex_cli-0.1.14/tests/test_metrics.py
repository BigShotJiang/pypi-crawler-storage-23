import json
import subprocess
import pytest
import os


@pytest.fixture
def temp_spex_env(tmp_path):
    """Setup a temporary .spex directory structure"""
    spex_dir = tmp_path / ".spex"
    memory_dir = spex_dir / "memory"
    debug_dir = spex_dir / "debug"
    memory_dir.mkdir(parents=True)
    debug_dir.mkdir(parents=True)

    # Create required memory files
    for f in ["requirements.jsonl", "decisions.jsonl", "traces.jsonl"]:
        (memory_dir / f).touch()

    # Per-project debug files will be created automatically
    (memory_dir / "plans").mkdir(parents=True, exist_ok=True)

    return tmp_path


def get_metrics_file(temp_spex_env):
    """Helper to find the actual metrics file in the per-project debug structure"""
    debug_dir = temp_spex_env / ".spex" / "debug"
    # Find the project-specific subdirectory (there should be only one in tests)
    project_dirs = [d for d in debug_dir.iterdir() if d.is_dir()]
    if not project_dirs:
        # Return expected path even if it doesn't exist yet
        project_name = temp_spex_env.name
        return debug_dir / project_name / "metrics.jsonl"
    return project_dirs[0] / "metrics.jsonl"


def run_spex(cwd, args, env_extra=None):
    """Run spex CLI with args"""
    import sys
    from pathlib import Path
    env = os.environ.copy()
    src_dir = str(Path(__file__).parent.parent / "src")
    env["PYTHONPATH"] = src_dir
    env["SPEX_HOME"] = str(cwd / ".spex")
    if env_extra:
        env.update(env_extra)
    main_py = str(Path(src_dir) / "spex_cli" / "main.py")
    return subprocess.run([sys.executable, main_py] + args, cwd=cwd, capture_output=True, text=True, env=env)


# ── spex metric report ──────────────────────────────────────────────────────

def test_metric_report_empty(temp_spex_env):
    """Report on empty metrics returns zero counts."""
    res = run_spex(temp_spex_env, ["metric", "report"])
    assert res.returncode == 0
    report = json.loads(res.stdout)
    assert report['totalEvents'] == 0
    assert report['stateTransitions'] == 0
    assert report['memoryLookups']['count'] == 0


# ── CLI emission side-effects ─────────────────────────────────────────────

def test_requirement_add_emits_metric(temp_spex_env):
    """Adding a requirement also emits a memory_write metric."""
    res = run_spex(temp_spex_env, [
        "requirement", "add", "--plan-id", "P-1", "--type", "FR",
        "--description", "Test", "--source", "U", "--acceptance-criteria", "C"
    ])
    assert res.returncode == 0
    metrics_file = get_metrics_file(temp_spex_env)
    content = metrics_file.read_text().strip()
    assert content  # not empty
    data = json.loads(content)
    assert data['event'] == 'memory_write'
    assert data['data']['type'] == 'requirement'


def test_decision_add_emits_metric(temp_spex_env):
    """Adding a decision also emits a memory_write metric."""
    # First add requirement
    req_res = run_spex(temp_spex_env, [
        "requirement", "add", "--plan-id", "P-1", "--type", "FR",
        "--description", "R1", "--source", "U", "--acceptance-criteria", "C"
    ])
    assert req_res.returncode == 0
    req_id = req_res.stdout.split("Added requirement ")[1].split(" ")[0]

    res = run_spex(temp_spex_env, [
        "decision", "add",
        "--proposal", "P", "--rationale", "R", "--alternatives", "A",
        "--satisfies", req_id, "--impact", "I",
        "--decision-class", "tactical"
    ])
    assert res.returncode == 0
    metrics_file = get_metrics_file(temp_spex_env)
    lines = metrics_file.read_text().strip().split('\n')
    # Should have 2 metrics: one for requirement, one for decision
    assert len(lines) == 2
    dec_metric = json.loads(lines[1])
    assert dec_metric['event'] == 'memory_write'
    assert dec_metric['data']['type'] == 'decision'


def test_requirement_update_emits_metric(temp_spex_env):
    """Updating a requirement emits a memory_write metric."""
    # First add a requirement
    add_res = run_spex(temp_spex_env, [
        "requirement", "add", "--plan-id", "P-1", "--type", "FR",
        "--description", "Initial", "--source", "User", "--acceptance-criteria", "Test"
    ])
    assert add_res.returncode == 0
    req_id = add_res.stdout.split("Added requirement ")[1].split(" ")[0]

    # Update the requirement
    update_res = run_spex(temp_spex_env, [
        "requirement", "update", "--id", req_id,
        "--description", "Updated description"
    ])
    assert update_res.returncode == 0

    metrics_file = get_metrics_file(temp_spex_env)
    lines = metrics_file.read_text().strip().split('\n')
    # Should have 2 metrics: one for add, one for update
    assert len(lines) == 2
    update_metric = json.loads(lines[1])
    assert update_metric['event'] == 'memory_write'
    assert update_metric['data']['type'] == 'requirement_update'


def test_decision_update_emits_metric(temp_spex_env):
    """Updating a decision emits a memory_write metric."""
    # First add requirement
    req_res = run_spex(temp_spex_env, [
        "requirement", "add", "--plan-id", "P-1", "--type", "FR",
        "--description", "R1", "--source", "U", "--acceptance-criteria", "C"
    ])
    assert req_res.returncode == 0
    req_id = req_res.stdout.split("Added requirement ")[1].split(" ")[0]

    # Add decision
    add_res = run_spex(temp_spex_env, [
        "decision", "add",
        "--proposal", "Initial", "--rationale", "R", "--alternatives", "A",
        "--satisfies", req_id, "--impact", "I",
        "--decision-class", "tactical"
    ])
    assert add_res.returncode == 0
    dec_id = add_res.stdout.split("Added TACTICAL decision ")[1].split(" ")[0]

    # Update the decision
    update_res = run_spex(temp_spex_env, [
        "decision", "update", "--id", dec_id,
        "--proposal", "Updated proposal"
    ])
    assert update_res.returncode == 0

    metrics_file = get_metrics_file(temp_spex_env)
    lines = metrics_file.read_text().strip().split('\n')
    # Should have 3 metrics: req add, dec add, dec update
    assert len(lines) == 3
    update_metric = json.loads(lines[2])
    assert update_metric['event'] == 'memory_write'
    assert update_metric['data']['type'] == 'decision_update'


def test_policy_update_emits_metric(temp_spex_env):
    """Updating a policy emits a memory_write metric."""
    # First add a policy
    add_res = run_spex(temp_spex_env, [
        "policy", "add",
        "--description", "Initial policy", "--rationale", "Because"
    ])
    assert add_res.returncode == 0
    pol_id = add_res.stdout.split("Added policy ")[1].split(" ")[0]

    # Update the policy
    update_res = run_spex(temp_spex_env, [
        "policy", "update", "--id", pol_id,
        "--description", "Updated policy"
    ])
    assert update_res.returncode == 0

    metrics_file = get_metrics_file(temp_spex_env)
    lines = metrics_file.read_text().strip().split('\n')
    # Should have 2 metrics: one for add, one for update
    assert len(lines) == 2
    update_metric = json.loads(lines[1])
    assert update_metric['event'] == 'memory_write'
    assert update_metric['data']['type'] == 'policy_update'


def test_requirement_deprecate_emits_metric(temp_spex_env):
    """Deprecating a requirement emits a memory_write metric."""
    # First add a requirement
    add_res = run_spex(temp_spex_env, [
        "requirement", "add", "--plan-id", "P-1", "--type", "FR",
        "--description", "Test", "--source", "User", "--acceptance-criteria", "Test"
    ])
    assert add_res.returncode == 0
    req_id = add_res.stdout.split("Added requirement ")[1].split(" ")[0]

    # Deprecate the requirement
    deprecate_res = run_spex(temp_spex_env, [
        "requirement", "deprecate", "--id", req_id,
        "--reason", "No longer needed"
    ])
    assert deprecate_res.returncode == 0

    metrics_file = get_metrics_file(temp_spex_env)
    lines = metrics_file.read_text().strip().split('\n')
    # Should have 2 metrics: one for add, one for deprecate
    assert len(lines) == 2
    deprecate_metric = json.loads(lines[1])
    assert deprecate_metric['event'] == 'memory_write'
    assert deprecate_metric['data']['type'] == 'requirement_deprecate'


def test_decision_deprecate_emits_metric(temp_spex_env):
    """Deprecating a decision emits a memory_write metric."""
    # First add requirement
    req_res = run_spex(temp_spex_env, [
        "requirement", "add", "--plan-id", "P-1", "--type", "FR",
        "--description", "R1", "--source", "U", "--acceptance-criteria", "C"
    ])
    assert req_res.returncode == 0
    req_id = req_res.stdout.split("Added requirement ")[1].split(" ")[0]

    # Add decision
    add_res = run_spex(temp_spex_env, [
        "decision", "add",
        "--proposal", "P", "--rationale", "R", "--alternatives", "A",
        "--satisfies", req_id, "--impact", "I",
        "--decision-class", "tactical"
    ])
    assert add_res.returncode == 0
    dec_id = add_res.stdout.split("Added TACTICAL decision ")[1].split(" ")[0]

    # Deprecate the decision
    deprecate_res = run_spex(temp_spex_env, [
        "decision", "deprecate", "--id", dec_id,
        "--reason", "Obsolete"
    ])
    assert deprecate_res.returncode == 0

    metrics_file = get_metrics_file(temp_spex_env)
    lines = metrics_file.read_text().strip().split('\n')
    # Should have 3 metrics: req add, dec add, dec deprecate
    assert len(lines) == 3
    deprecate_metric = json.loads(lines[2])
    assert deprecate_metric['event'] == 'memory_write'
    assert deprecate_metric['data']['type'] == 'decision_deprecate'


def test_policy_deprecate_emits_metric(temp_spex_env):
    """Deprecating a policy emits a memory_write metric."""
    # First add a policy
    add_res = run_spex(temp_spex_env, [
        "policy", "add",
        "--description", "Test policy", "--rationale", "Because"
    ])
    assert add_res.returncode == 0
    pol_id = add_res.stdout.split("Added policy ")[1].split(" ")[0]

    # Deprecate the policy
    deprecate_res = run_spex(temp_spex_env, [
        "policy", "deprecate", "--id", pol_id,
        "--reason", "No longer needed"
    ])
    assert deprecate_res.returncode == 0

    metrics_file = get_metrics_file(temp_spex_env)
    lines = metrics_file.read_text().strip().split('\n')
    # Should have 2 metrics: one for add, one for deprecate
    assert len(lines) == 2
    deprecate_metric = json.loads(lines[1])
    assert deprecate_metric['event'] == 'memory_write'
    assert deprecate_metric['data']['type'] == 'policy_deprecate'
