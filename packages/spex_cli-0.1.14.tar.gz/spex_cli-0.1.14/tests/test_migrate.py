import json
import os
import subprocess
import pytest
from pathlib import Path

def run_spex(cwd, args):
    """Run spex CLI with args"""
    import sys
    env = os.environ.copy()
    src_dir = str(Path(__file__).parent.parent / "src")
    env["PYTHONPATH"] = src_dir
    main_py = str(Path(src_dir) / "spex_cli" / "main.py")
    return subprocess.run([sys.executable, main_py] + args, cwd=cwd, capture_output=True, text=True, env=env)

@pytest.fixture
def old_spex_env(tmp_path):
    """Setup a .spex directory with old format files"""
    spex_dir = tmp_path / ".spex"
    memory_dir = spex_dir / "memory"
    memory_dir.mkdir(parents=True)
    
    # 1. Create plans.jsonl
    plans_jsonl = memory_dir / "plans.jsonl"
    plan1 = {
        "id": "P-OLD-1",
        "version": 1,
        "status": "draft",
        "createdAt": "2026-01-01T10:00:00Z",
        "author": "old-author",
        "featureName": "legacy-feat",
        "goal": "old goal"
    }
    with open(plans_jsonl, "w") as f:
        f.write(json.dumps(plan1) + "\n")
    
    # 2. Create a feature directory with state.json
    feat_dir = spex_dir / "plans" / "legacy-feat"
    feat_dir.mkdir(parents=True)
    state_json = feat_dir / "state.json"
    state_data = {
        "featureName": "legacy-feat",
        "currentState": "RESEARCH",
        "stateHistory": [
            {"state": "INIT", "timestamp": "2026-01-01T10:00:00Z"},
            {"state": "RESEARCH", "timestamp": "2026-01-01T10:05:00Z"}
        ],
        "context": {
            "planId": "P-OLD-1",
            "goal": "old goal updated"
        },
        "metadata": {
            "createdAt": "2026-01-01T10:00:00Z"
        }
    }
    with open(state_json, "w") as f:
        json.dump(state_data, f)
        
    return tmp_path

def test_migration_basic(old_spex_env):
    # Run migration
    res = run_spex(old_spex_env, ["plan", "migrate"])
    assert res.returncode == 0
    assert "Migrated 1 plans" in res.stdout
    
    # Check if individual JSON exists
    plan_file = old_spex_env / ".spex/memory/plans/P-OLD-1.json"
    assert plan_file.exists()
    
    with open(plan_file, "r") as f:
        data = json.load(f)
        assert data["id"] == "P-OLD-1"
        assert data["currentState"] == "RESEARCH" # Merged from state.json
        assert data["author"] == "old-author"
        
    # Check old files still exist (cleanup=False by default)
    assert (old_spex_env / ".spex/memory/plans.jsonl").exists()
    assert (old_spex_env / ".spex/plans/legacy-feat/state.json").exists()

def test_migration_with_cleanup(old_spex_env):
    # Run migration with cleanup
    res = run_spex(old_spex_env, ["plan", "migrate", "--cleanup"])
    assert res.returncode == 0
    assert "Migrated 1 plans" in res.stdout
    assert "Deleted" in res.stdout
    
    # Check individual JSON exists
    plan_file = old_spex_env / ".spex/memory/plans/P-OLD-1.json"
    assert plan_file.exists()
    
    # Check old files are gone
    assert not (old_spex_env / ".spex/memory/plans.jsonl").exists()
    assert not (old_spex_env / ".spex/plans/legacy-feat/state.json").exists()

def test_migration_from_state_only(tmp_path):
    """Test migration when only state.json exists but no plans.jsonl"""
    spex_dir = tmp_path / ".spex"
    feat_dir = spex_dir / "plans" / "new-feat"
    feat_dir.mkdir(parents=True)
    
    state_data = {
        "featureName": "new-feat",
        "currentState": "INIT",
        "context": {"planId": "P-NEW-1"}
    }
    with open(feat_dir / "state.json", "w") as f:
        json.dump(state_data, f)
        
    res = run_spex(tmp_path, ["plan", "migrate"])
    assert res.returncode == 0
    assert "Migrated 1 plans" in res.stdout
    assert (tmp_path / ".spex/memory/plans/P-NEW-1.json").exists()
