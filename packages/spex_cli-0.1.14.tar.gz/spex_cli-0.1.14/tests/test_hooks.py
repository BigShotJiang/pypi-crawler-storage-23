import json
from unittest.mock import patch
from spex_cli.agents.hooks import base, claude, gemini, cursor
from spex_cli.agents.providers.claude.hooks import run_hook as claude_run_hook
from spex_cli.agents.providers.gemini.hooks import run_hook as gemini_run_hook
from spex_cli.agents.providers.cursor.hooks import run_hook as cursor_run_hook

def test_claude_translate_session_start():
    data = {
        "session_id": "sess-123",
        "transcript_path": "/tmp/transcript.jsonl",
        "cwd": "/home/user/repo",
        "source": "startup",
        "model": "claude-3-opus",
        "hook_event_name": "session_start"
    }
    unified = claude.translate_to_unified(base.HookEvent.SESSION_START, data)
    assert unified["session_id"] == "sess-123"
    assert unified["event"] == base.HookEvent.SESSION_START
    assert unified["source"] == "startup"
    assert unified["model"] == "claude-3-opus"

def test_claude_translate_user_prompt():
    data = {
        "session_id": "sess-123",
        "prompt": "Hello world",
        "hook_event_name": "user_prompt"
    }
    unified = claude.translate_to_unified(base.HookEvent.USER_PROMPT, data)
    assert unified["prompt"] == "Hello world"
    assert unified["event"] == base.HookEvent.USER_PROMPT

def test_claude_translate_after_tool_ask_user():
    data = {
        "session_id": "sess-123",
        "tool_name": "AskUserQuestion",
        "tool_input": {"question": {"header": "Confirm", "text": "Ready?"}},
        "tool_response": {"answers": {"0": "Yes"}},
        "hook_event_name": "after_tool"
    }
    unified = claude.translate_to_unified(base.HookEvent.AFTER_TOOL, data)
    assert unified["tool_name"] == "AskUserQuestion"
    assert unified["tool_response_text"] == "[Confirm] Yes"
    assert unified["questions"] == [{"header": "Confirm", "text": "Ready?"}]
    assert unified["answers"] == {"0": "Yes"}

def test_gemini_translate_session_start():
    data = {
        "session_id": "gem-123",
        "source": "resume",
        "hook_event_name": "session_start"
    }
    unified = gemini.translate_to_unified(base.HookEvent.SESSION_START, data)
    assert unified["session_id"] == "gem-123"
    assert unified["source"] == "resume"

def test_gemini_translate_after_tool_ask_user():
    # Test with llmContent JSON
    data = {
        "tool_name": "ask_user",
        "tool_input": {"questions": [{"header": "Approval", "message": "Is this OK?"}]},
        "tool_response": {
            "llmContent": json.dumps({"answers": {"0": "confirmed"}})
        }
    }
    unified = gemini.translate_to_unified(base.HookEvent.AFTER_TOOL, data)
    assert unified["tool_response_text"] == "[Approval] confirmed"
    assert unified["questions"] == [{"header": "Approval", "message": "Is this OK?"}]
    assert unified["answers"] == {"0": "confirmed"}

def test_cursor_translate_session_start():
    data = {
        "conversation_id": "cur-123",
        "workspace_roots": ["/repo"],
        "model": "gpt-4",
        "hook_event_name": "session_start"
    }
    unified = cursor.translate_to_unified(base.HookEvent.SESSION_START, data)
    assert unified["session_id"] == "cur-123"
    assert unified["cwd"] == "/repo"
    assert unified["model"] == "gpt-4"

def test_cursor_translate_after_tool():
    data = {
        "tool_name": "edit_file",
        "tool_input": {"question": "What to edit?"},
        "tool_output": "Success",
        "hook_event_name": "after_tool"
    }
    unified = cursor.translate_to_unified(base.HookEvent.AFTER_TOOL, data)
    assert unified["tool_name"] == "edit_file"
    assert unified["tool_response_text"] == "Success"
    assert unified["questions"] == ["What to edit?"]

def test_cursor_translate_after_tool_json_output():
    data = {
        "tool_name": "ask_user",
        "tool_input": {"question": "Pick one"},
        "tool_output": '{"choice": "A"}',
        "hook_event_name": "after_tool"
    }
    unified = cursor.translate_to_unified(base.HookEvent.AFTER_TOOL, data)
    assert unified["answers"] == {"choice": "A"}

def test_cursor_translate_after_tool_no_output():
    data = {
        "tool_name": "edit_file",
        "hook_event_name": "after_tool"
    }
    unified = cursor.translate_to_unified(base.HookEvent.AFTER_TOOL, data)
    assert unified["tool_response_text"] == ""

def test_export_session_id(tmp_path):
    env_file = tmp_path / "claude_env"
    with patch.dict("os.environ", {"CLAUDE_ENV_FILE": str(env_file)}):
        data = {"session_id": "sess-export-123"}
        base.export_session_id(data)
        assert env_file.exists()
        assert "SPEX_SESSION_ID=sess-export-123" in env_file.read_text()
        assert "export " not in env_file.read_text()

def test_record_session(tmp_path):
    sessions_file = tmp_path / "sessions.jsonl"
    with patch("spex_cli.core.constants.SESSIONS_FILE", str(sessions_file)):
        data = {
            "session_id": "sess-record-123",
            "transcript_path": "/path/to/transcript",
            "cwd": "/path/to/repo",
            "source": "startup"
        }
        base.record_session(data)
        assert sessions_file.exists()
        content = sessions_file.read_text()
        record = json.loads(content)
        assert record["sessionId"] == "sess-record-123"
        assert record["cwd"] == "/path/to/repo"

@patch("spex_cli.commands.metrics.emit_metric")
def test_emit_interaction_metrics_prompt(mock_emit):
    data = {"prompt": "What is the capital of France?"}
    base.emit_interaction_metrics(data)
    mock_emit.assert_called_once()
    args, kwargs = mock_emit.call_args
    assert kwargs["event"] == "user_prompt"
    assert kwargs["data"]["prompt"] == "What is the capital of France?"
    assert kwargs["data"]["promptLength"] == 30

@patch("spex_cli.commands.metrics.emit_metric")
def test_emit_interaction_metrics_tool_response(mock_emit):
    data = {
        "tool_response_text": "Paris is the capital.",
        "questions": ["What is the capital?"]
    }
    base.emit_interaction_metrics(data)
    mock_emit.assert_called_once()
    args, kwargs = mock_emit.call_args
    assert kwargs["event"] == "user_prompt"
    assert kwargs["data"]["prompt"] == "Paris is the capital."
    assert kwargs["data"]["questions"] == ["What is the capital?"]

@patch("spex_cli.agents.hooks.base.get_input")
@patch("spex_cli.agents.hooks.base.export_session_id")
@patch("spex_cli.agents.hooks.base.record_session")
def test_claude_run_hook_session_start(mock_record, mock_export, mock_input):
    mock_input.return_value = {"session_id": "c1", "hook_event_name": "session_start"}
    claude_run_hook(base.HookEvent.SESSION_START)
    mock_export.assert_called_once()
    mock_record.assert_called_once()

@patch("spex_cli.agents.hooks.base.get_input")
@patch("spex_cli.agents.hooks.base.emit_interaction_metrics")
def test_claude_run_hook_user_prompt(mock_emit, mock_input):
    mock_input.return_value = {"session_id": "c1", "prompt": "hi"}
    claude_run_hook(base.HookEvent.USER_PROMPT)
    mock_emit.assert_called_once()

@patch("spex_cli.agents.hooks.base.get_input")
@patch("spex_cli.agents.hooks.base.emit_interaction_metrics")
def test_gemini_run_hook_after_tool(mock_emit, mock_input):
    mock_input.return_value = {"session_id": "g1", "tool_name": "ask_user", "tool_response": {"llmContent": "resp"}}
    gemini_run_hook(base.HookEvent.AFTER_TOOL)
    mock_emit.assert_called_once()

def test_gemini_translate_after_tool_no_answers():
    data = {
        "tool_name": "ask_user",
        "tool_response": {"other": "data"}
    }
    unified = gemini.translate_to_unified(base.HookEvent.AFTER_TOOL, data)
    assert unified["tool_response_text"] is None

def test_claude_translate_after_tool_no_answers():
    data = {
        "tool_name": "AskUserQuestion",
        "tool_response": {"other": "data"}
    }
    unified = claude.translate_to_unified(base.HookEvent.AFTER_TOOL, data)
    assert unified["tool_response_text"] == "{'other': 'data'}"

@patch("spex_cli.agents.hooks.base.get_input")
@patch("spex_cli.agents.hooks.base.export_session_id")
@patch("spex_cli.agents.hooks.base.record_session")
def test_cursor_run_hook_session_start(mock_record, mock_export, mock_input, capsys):
    mock_input.return_value = {"conversation_id": "cur1", "hook_event_name": "session_start"}
    cursor_run_hook(base.HookEvent.SESSION_START)
    mock_export.assert_called_once()
    mock_record.assert_called_once()
    captured = capsys.readouterr()
    assert "SPEX_SESSION_ID" in captured.out
