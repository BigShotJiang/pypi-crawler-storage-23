# Implementation Tasks: Plan Metrics Timeline

**Plan ID**: P-5024baf1

---

## Task T-001: Create Pages Directory and Analytics Page Scaffold

**Decision IDs**: D-515e314f, D-ab6bf359

**Plan Step**: Step 1 - Create Pages Directory and Analytics Page

**Description**: Set up the Streamlit multi-page app structure by creating the `pages/` directory and a basic `analytics.py` file with page configuration and CSS styling. This establishes the foundation for the analytics page following Streamlit conventions.

**Implementation Steps**:

### Step 1: Write failing test (Manual verification)
No automated test for this step. Manual verification will be:
```bash
# After implementation, verify the page exists
ls src/spex_cli/ui/pages/analytics.py
# Start the UI and verify the analytics page appears in sidebar
spex ui
# Navigate to http://localhost:5888 and check sidebar for "Analytics" link
```

### Step 2: Implement minimal logic
Create the directory structure and basic page file:

```python
# File: src/spex_cli/ui/pages/analytics.py

import streamlit as st
from pathlib import Path

# Page configuration
st.set_page_config(
    page_title="Spex Analytics",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS (copied from memory.py)
st.markdown("""
<style>
    /* Paste the entire CSS block from memory.py lines 15-377 */
    /* Global Background */
    .stApp {
        background-color: #0D1117;
        color: #E5E7EB;
    }
    /* ... rest of CSS ... */
</style>
""", unsafe_allow_html=True)

st.title("Plan Analytics")
st.markdown("Analytics page placeholder")
```

Commands:
```bash
mkdir -p src/spex_cli/ui/pages
# Create the file with above content
```

### Step 3: Verify pass
```bash
# Start the Streamlit app
spex ui
# Navigate to http://localhost:5888
# Expected: "Analytics" page appears in sidebar
# Expected: Page loads with dark theme
# Expected: Page title shows "Plan Analytics"
```

### Step 4: Commit
```bash
git add src/spex_cli/ui/pages/
git commit -m "Create Streamlit pages directory and analytics page scaffold with CSS styling" --trailer "decision-id: D-515e314f" --trailer "decision-id: D-ab6bf359"
```

---

## Task T-002: Implement Metrics Data Loading with load_jsonl

**Decision IDs**: D-079565d8, D-8b5fe23d

**Plan Step**: Step 2 - Implement Metrics Data Loading

**Description**: Implement the `load_jsonl()` function to read metrics data from `.spex/memory/metrics.jsonl` with error handling. Add logic to read the `planId` from URL query parameters and filter metrics to show only events for that specific plan. Handle empty/invalid planId gracefully.

**Implementation Steps**:

### Step 1: Write failing test (Manual verification)
No automated test. Manual verification after implementation:
```bash
# Test 1: Valid planId with metrics
# Navigate to http://localhost:5888/analytics?planId=P-5024baf1
# Expected: Metrics for that plan are displayed

# Test 2: Invalid planId
# Navigate to http://localhost:5888/analytics?planId=INVALID
# Expected: Empty state message

# Test 3: No planId parameter
# Navigate to http://localhost:5888/analytics
# Expected: Prompt to select a plan
```

### Step 2: Implement minimal logic
Add data loading functions to analytics.py:

```python
import json

def load_jsonl(filepath):
    """Load items from a JSONL file into a list of dictionaries."""
    if not Path(filepath).exists():
        return []
    items = []
    with open(filepath, 'r') as f:
        for line in f:
            if line.strip():
                try:
                    items.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return items

def main():
    # Get planId from query params
    params = st.query_params
    plan_id = params.get("planId", None)

    if not plan_id:
        st.info("Please select a plan from the Memory page to view its analytics.")
        return

    # Load metrics
    metrics_path = Path(".spex/memory/metrics.jsonl")
    all_metrics = load_jsonl(metrics_path)

    # Filter by planId (exclude empty and "none")
    plan_metrics = [
        m for m in all_metrics
        if m.get("planId") == plan_id
        and m.get("planId") not in ["", "none", None]
    ]

    if not plan_metrics:
        st.warning(f"No metrics found for plan {plan_id}")
        return

    st.write(f"Found {len(plan_metrics)} metrics for plan {plan_id}")
    # Display metrics (will be implemented in next task)
    st.json(plan_metrics)

if __name__ == "__main__":
    main()
```

### Step 3: Verify pass
```bash
# Test with a valid plan that has metrics
spex ui
# Navigate to http://localhost:5888/analytics?planId=P-5024baf1
# Expected: Page shows count of metrics and displays them as JSON
# Expected: No error messages

# Test with empty planId
# Navigate to http://localhost:5888/analytics
# Expected: Shows "Please select a plan..." message
```

### Step 4: Commit
```bash
git add src/spex_cli/ui/pages/analytics.py
git commit -m "Add metrics data loading and planId filtering in analytics page" --trailer "decision-id: D-079565d8" --trailer "decision-id: D-8b5fe23d"
```

---

## Task T-003: Build Timeline Visualization with Type-Specific Formatting

**Decision IDs**: D-dcd53814, D-440510dd

**Plan Step**: Step 3 - Build Timeline Visualization

**Description**: Implement the timeline rendering logic that displays metrics events in ascending chronological order (oldest first). Add type-specific formatting for different event types (memory_write, state_transition, user_prompt, etc.) to make the timeline readable and informative.

**Implementation Steps**:

### Step 1: Write failing test (Manual verification)
```bash
# After implementation:
# Navigate to http://localhost:5888/analytics?planId=P-5024baf1
# Expected: Events are displayed oldest to newest (ascending timestamp)
# Expected: Event type "memory_write" shows icon + type + ID (e.g., "📋 Requirement FR-001")
# Expected: Event type "state_transition" shows "STATE_A → STATE_B"
# Expected: Event type "user_prompt" shows "Prompt: XX chars"
```

### Step 2: Implement minimal logic
Add event formatting and timeline rendering to analytics.py:

```python
import pandas as pd
from datetime import datetime

def format_event_data(event_type, data):
    """Format event data based on type."""
    if not data:
        return "No data"

    if event_type == "memory_write":
        mem_type = data.get("type", "unknown")
        mem_id = data.get("id", "unknown")
        icons = {
            "requirement": "📋",
            "decision": "🔧",
            "policy": "📜",
            "plan": "📦",
            "trace": "🔗"
        }
        icon = icons.get(mem_type, "📄")
        return f"{icon} {mem_type.capitalize()} {mem_id}"

    elif event_type == "state_transition":
        from_state = data.get("from", "?")
        to_state = data.get("to", "?")
        return f"{from_state} → {to_state}"

    elif event_type == "user_prompt":
        length = data.get("promptLength", 0)
        return f"Prompt: {length} chars"

    elif event_type == "plan_write":
        operation = data.get("operation", "unknown")
        plan_id = data.get("planId", "")
        return f"{operation.capitalize()} plan {plan_id}"

    else:
        # Fallback: formatted JSON
        return f"<pre>{json.dumps(data, indent=2)}</pre>"

def render_timeline(metrics):
    """Render timeline HTML for metrics."""
    timeline_html = '<div class="timeline-container">'

    for metric in metrics:
        event_type = metric.get("event", "unknown")
        timestamp = metric.get("timestamp", "")
        data = metric.get("data", {})

        # Format timestamp
        try:
            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            time_str = dt.strftime("%Y-%m-%d %H:%M:%S")
        except:
            time_str = timestamp

        # Format data based on type
        formatted_data = format_event_data(event_type, data)

        timeline_html += f'''
        <details class="commit-item">
            <summary>
                <div style="margin-bottom: 8px;">
                    <span style="color: #7D8590; font-size: 0.7rem; font-weight: 600; text-transform: uppercase;">{event_type}</span>
                </div>
                <div style="display: flex; justify-content: space-between; align-items: baseline;">
                    <div style="color: #E5E7EB; font-weight: 500; font-size: 0.85rem;">{formatted_data}</div>
                    <div style="color: #7D8590; font-size: 0.75rem; font-family: monospace;">{time_str}</div>
                </div>
            </summary>
            <div style="padding: 12px;">
                <pre style="background-color: #161B22; padding: 12px; border-radius: 4px; font-size: 0.75rem; overflow-x: auto;">{json.dumps(data, indent=2)}</pre>
            </div>
        </details>
        '''

    timeline_html += '</div>'
    return timeline_html

# Update main() function:
def main():
    # ... (existing code for loading and filtering) ...

    # Sort by timestamp ascending (oldest first)
    plan_metrics = sorted(plan_metrics, key=lambda x: x.get("timestamp", ""))

    st.subheader(f"Analytics: {plan_id}")
    st.markdown(f"**Total Events**: {len(plan_metrics)}")
    st.markdown("---")

    # Render timeline
    timeline_html = render_timeline(plan_metrics)
    st.markdown(timeline_html, unsafe_allow_html=True)
```

### Step 3: Verify pass
```bash
spex ui
# Navigate to analytics page with a plan that has metrics
# Expected: Events are sorted oldest to newest
# Expected: memory_write events show formatted icons and IDs
# Expected: state_transition events show state flow arrows
# Expected: Each event is expandable to show full JSON
```

### Step 4: Commit
```bash
git add src/spex_cli/ui/pages/analytics.py
git commit -m "Implement timeline visualization with type-specific event formatting and ascending order" --trailer "decision-id: D-dcd53814" --trailer "decision-id: D-440510dd"
```

---

## Task T-004: Add View Analytics Button to Plan Cards

**Decision IDs**: D-3091cfa0, D-8b5fe23d

**Plan Step**: Step 4 - Add Navigation Button to Memory Page

**Description**: Modify the `render_item()` function in memory.py to add a "View Analytics 📊" button for plan cards. The button should be positioned after the existing fields (Goal, Context, Timeline) but before the nested Requirements/Decisions sections. The button generates a link to the analytics page with the plan ID as a query parameter.

**Implementation Steps**:

### Step 1: Write failing test (Manual verification)
```bash
# After implementation:
# Navigate to http://localhost:5888 (memory page)
# Go to Plans tab
# Expand a plan card
# Expected: "View Analytics 📊" button appears after Timeline field
# Click the button
# Expected: Navigates to analytics page with correct planId in URL
```

### Step 2: Implement minimal logic
Modify the `render_item()` function in memory.py:

```python
# In memory.py, locate the render_item function around line 575-679
# Find the section that builds fields_html and adds scope_html

# After line 629 (after scope_html is built), add this for Plans:

# Add analytics button for Plans
analytics_button_html = ""
if t_name == "Plans":
    plan_id = row.get('id', '')
    analytics_button_html = f'''
    <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #21262D;">
        <a href="/analytics?planId={plan_id}" target="_self" style="text-decoration: none;">
            <button style="
                background-color: #F97316;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 6px;
                font-size: 0.85rem;
                font-weight: 600;
                cursor: pointer;
                display: inline-flex;
                align-items: center;
                gap: 6px;
                transition: background-color 0.2s ease;
            " onmouseover="this.style.backgroundColor='#8B5CF6'" onmouseout="this.style.backgroundColor='#F97316'">
                📊 View Analytics
            </button>
        </a>
    </div>
    '''

# Then modify the item_html assembly (around line 655-678) to insert analytics_button_html
# BEFORE the children sections are inserted:

item_html = (
    f'<details class="commit-item">'
    f'<summary>'
    # ... existing summary content ...
    f'</summary>'
    f'<div>{fields_html}{scope_html}{analytics_button_html}</div>'  # Add analytics button here
    f'</details>'
)

# For Plans, the children will be inserted later at line 488
```

### Step 3: Verify pass
```bash
spex ui
# Navigate to memory page
# Click on Plans tab
# Expand a plan (e.g., P-5024baf1)
# Expected: "View Analytics 📊" button appears after scope tags
# Expected: Button has orange background
# Hover over button
# Expected: Button changes to purple
# Click button
# Expected: Navigates to /analytics?planId=P-5024baf1
# Expected: Analytics page loads with that plan's metrics
```

### Step 4: Commit
```bash
git add src/spex_cli/ui/memory.py
git commit -m "Add View Analytics button to plan cards in memory page" --trailer "decision-id: D-3091cfa0" --trailer "decision-id: D-8b5fe23d"
```

---

## Summary

**Total Tasks**: 4
**Decisions Covered**: All 7 decisions
**Estimated Implementation Time**: ~2 hours

### Task-Decision Mapping
- T-001: D-515e314f, D-ab6bf359
- T-002: D-079565d8, D-8b5fe23d
- T-003: D-dcd53814, D-440510dd
- T-004: D-3091cfa0, D-8b5fe23d

### Dependencies
- T-001 must complete before T-002 (need page scaffold before adding logic)
- T-002 must complete before T-003 (need data loading before rendering)
- T-004 can be done in parallel with T-002/T-003
