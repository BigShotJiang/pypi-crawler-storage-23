# Feature Plan: Plan Metrics Timeline

**Plan ID**: P-5024baf1

**Goal**: Add an analytics page that displays a chronological timeline of metrics events for each plan, with navigation from plan cards in the memory page.

**Status**: Approved

**Created**: 2026-02-25

---

## Requirements

### FR-afbcc95d Plan Analytics Page
- **Description**: Users must be able to view a dedicated analytics page showing all metrics events for a specific plan in chronological order (oldest to newest).
- **Source**: User request
- **Type**: FR (Functional Requirement)
- **Acceptance Criteria**:
  1. Navigate to `/pages/analytics.py` (Streamlit page) with a `planId` query parameter
  2. Verify the page loads and displays metrics for the specified plan
  3. Verify events are sorted oldest to newest (ascending timestamp)
  4. Verify each event shows: event type, timestamp, and associated data
- **Scope**: spex-ui

### FR-9ceba3b6 Navigation Button on Plan Cards
- **Description**: Each plan card in the memory page must have a "View Analytics" button that navigates to the analytics page for that plan.
- **Source**: User request
- **Type**: FR (Functional Requirement)
- **Acceptance Criteria**:
  1. Open the memory page and navigate to the Plans tab
  2. Expand a plan card
  3. Verify a "View Analytics" button is visible
  4. Click the button
  5. Verify navigation to analytics page with correct planId
- **Scope**: spex-ui

### NFR-e3540e57 Visual Consistency
- **Description**: The analytics page must maintain the same dark theme color palette and visual style as the memory page.
- **Source**: Constraint - maintaining UI consistency
- **Type**: NFR (Non-Functional Requirement)
- **Acceptance Criteria**:
  1. Compare the analytics page color scheme with memory page
  2. Verify background color matches (#0D1117)
  3. Verify primary accent color matches (#F97316)
  4. Verify typography and spacing follows same patterns
- **Scope**: spex-ui

### NFR-7747b6a4 Empty State Handling
- **Description**: The analytics page must gracefully handle cases where a plan has no metrics or the planId is invalid.
- **Source**: Inferred from metrics data analysis (many empty planIds exist)
- **Type**: NFR (Non-Functional Requirement)
- **Acceptance Criteria**:
  1. Navigate to analytics page with a planId that has no metrics
  2. Verify a friendly empty state message is displayed
  3. Navigate with an invalid planId
  4. Verify error handling shows appropriate message
- **Scope**: spex-ui

---

## Decisions

### D-515e314f Create Streamlit Multi-Page App Structure
- **Proposal**: Create a `pages/` directory in `src/spex_cli/ui/` and add `analytics.py` as a new Streamlit page.
- **Rationale**: Streamlit's multi-page app pattern automatically discovers pages in the `pages/` directory and adds them to the sidebar navigation. This is the standard Streamlit pattern and requires no additional routing configuration.
- **Satisfies**: FR-afbcc95d, POL-12ec7e31
- **Grounding**: D-a9958d58 (Use Streamlit for memory visualization UI)
- **Alternatives**:
  - **Single-page app with tabs**: Would require cramming all functionality into memory.py, making it harder to maintain
  - **Separate Streamlit instance**: Would require additional port and deployment complexity
  - **Modal/dialog within memory page**: Streamlit doesn't have built-in modal support, would require custom JavaScript
- **Impact**:
  - **Files**: New `src/spex_cli/ui/pages/analytics.py`, modified `src/spex_cli/ui/memory.py`
  - **Data Flows**: Analytics page reads from `.spex/memory/metrics.jsonl`, no writes
  - **Logic**: New page initialization, data loading, filtering by planId
  - **UX**: New page appears in Streamlit sidebar, accessible via link from plan cards
- **Class**: Structural
- **Scope**: spex-ui

### D-8b5fe23d Use Query Parameters for Plan ID Passing
- **Proposal**: Pass the `planId` to the analytics page via URL query parameters using Streamlit's `st.query_params` and `st.link` for navigation.
- **Rationale**: This approach is consistent with how the memory page already uses query params (see line 709 for `member` parameter). It also makes analytics pages directly linkable and bookmarkable.
- **Satisfies**: FR-afbcc95d, FR-9ceba3b6
- **Grounding**: Existing pattern in memory.py (line 709: `params = st.query_params`)
- **Alternatives**:
  - **Session state**: Would not persist across page reloads or be shareable via URL
  - **Custom routing with path parameters**: Not natively supported by Streamlit, would require complex workarounds
- **Impact**:
  - **Files**: `src/spex_cli/ui/pages/analytics.py` (reads query params), `src/spex_cli/ui/memory.py` (generates links)
  - **Data Flows**: planId flows from memory.py → URL → analytics.py → metrics filtering
  - **Logic**: Query param extraction and validation in analytics.py
  - **UX**: Direct URL linkability (e.g., `http://localhost:5888/analytics?planId=P-001`)
- **Class**: Tactical
- **Scope**: spex-ui

### D-079565d8 Reuse load_jsonl Pattern for Metrics Data
- **Proposal**: Create a `load_jsonl()` function in analytics.py (copied from memory.py pattern) to load metrics data with error handling.
- **Rationale**: The existing `load_jsonl()` pattern in memory.py handles file missing and JSON parse errors gracefully. Consistency in data loading across pages reduces bugs and maintenance burden.
- **Satisfies**: NFR-9ceba3b6
- **Grounding**: Existing implementation in memory.py (lines 380-392)
- **Alternatives**:
  - **Direct file reading with pandas**: Less error handling, would fail ungracefully if file is missing or malformed
  - **Import function from memory.py**: Would create tight coupling between pages; Streamlit pages should be independent
- **Impact**:
  - **Files**: `src/spex_cli/ui/pages/analytics.py` (new function)
  - **Data Flows**: Reads `.spex/memory/metrics.jsonl` → filters by planId → returns list of metric events
  - **Logic**: Error handling for missing file, malformed JSON, empty results
  - **UX**: Graceful degradation with empty state messages
- **Class**: Tactical
- **Scope**: spex-ui

### D-dcd53814 Display Timeline in Ascending Order (Oldest First)
- **Proposal**: Sort metrics events by timestamp in ascending order (oldest to newest) to tell the chronological story of a plan's execution.
- **Rationale**: Unlike the memory page which shows recent activity first, the analytics timeline should show the development narrative from start to finish. This helps users understand the sequence of events during feature development.
- **Satisfies**: FR-afbcc95d
- **Grounding**: User request specified "oldest to newest to tell the story"
- **Alternatives**:
  - **Descending order (newest first)**: Would be consistent with memory page but doesn't serve the narrative purpose of analytics
  - **User-configurable toggle**: Adds complexity for minimal benefit in this context
- **Impact**:
  - **Files**: `src/spex_cli/ui/pages/analytics.py` (sort logic)
  - **Data Flows**: Metrics loaded → sorted ascending by timestamp → rendered
  - **Logic**: `sorted(metrics, key=lambda x: x['timestamp'])` (ascending)
  - **UX**: Events appear top-to-bottom from earliest to latest
- **Class**: Tactical
- **Scope**: spex-ui

### D-3091cfa0 Add Analytics Button to Plan Card Details Section
- **Proposal**: Add a "View Analytics 📊" button/link inside the expanded `<details>` section of plan cards, positioned after the existing fields (Goal, Context, Timeline) but before nested Requirements/Decisions sections.
- **Rationale**: Placing the button in the details section keeps the summary view clean and uncluttered. Users who expand a plan to see details are more likely to want analytics. The button appears in a logical location within the plan's information hierarchy.
- **Satisfies**: FR-9ceba3b6, NFR-afbcc95d
- **Grounding**: Existing plan card structure in memory.py (lines 600-605, 655-678)
- **Alternatives**:
  - **Button in summary header**: Would clutter the collapsed view and compete with expand/collapse interaction
  - **Button as a floating action**: Not supported well in Streamlit's HTML rendering context
  - **Sidebar link**: Would be disconnected from the specific plan context
- **Impact**:
  - **Files**: `src/spex_cli/ui/memory.py` (modify `render_item` function for Plans)
  - **Data Flows**: Plan ID → HTML link → URL with query param
  - **Logic**: Conditional rendering of analytics button only for t_name == "Plans"
  - **UX**: Button appears in expanded plan card details, styled consistently with theme
- **Class**: Tactical
- **Scope**: spex-ui

### D-ab6bf359 Share CSS Styling via Inline Definition
- **Proposal**: Copy the custom CSS styling from memory.py into analytics.py as an inline definition using `st.markdown("""<style>...</style>""", unsafe_allow_html=True)`.
- **Rationale**: Streamlit pages are independent Python scripts. While this creates duplication, it ensures each page is self-contained and can be modified independently without breaking others. Future refactoring could extract to a shared module if needed.
- **Satisfies**: NFR-afbcc95d
- **Grounding**: Existing pattern in memory.py (lines 15-378)
- **Alternatives**:
  - **External CSS file**: Streamlit doesn't easily support external CSS references for multi-page apps
  - **Shared Python module**: Would add complexity for importing CSS as a string; current duplication is manageable for two pages
  - **Streamlit theming config**: Too limited for the custom dark theme requirements
- **Impact**:
  - **Files**: `src/spex_cli/ui/pages/analytics.py` (duplicated CSS)
  - **Data Flows**: None
  - **Logic**: Inline CSS loaded on page render
  - **UX**: Consistent visual appearance between memory and analytics pages
- **Class**: Tactical
- **Scope**: spex-ui

### D-440510dd Type-Specific Event Data Formatting
- **Proposal**: Parse and format the `data` field based on event type for better readability:
  - `memory_write`: Display type icon + ID (e.g., "📋 Requirement FR-afbcc95d")
  - `state_transition`: Display state flow (e.g., "INIT → RESEARCH")
  - `user_prompt`: Display prompt length (e.g., "Prompt: 245 chars")
  - `plan_write`: Display plan operation (e.g., "Created plan P-001")
  - Other events: Display formatted JSON as fallback
- **Rationale**: Different event types have different data structures. Type-specific formatting makes the timeline more readable and actionable compared to raw JSON dumps. Users can quickly understand what happened at each step.
- **Satisfies**: FR-afbcc95d
- **Grounding**: User preference from open question resolution
- **Alternatives**:
  - **Raw JSON for all**: Simpler to implement but harder to read, especially for non-technical users
  - **Hide data field**: Would lose valuable context about what happened in each event
  - **Unified formatting**: Would either be too generic (losing detail) or too complex (trying to fit all types into one format)
- **Impact**:
  - **Files**: `src/spex_cli/ui/pages/analytics.py` (event rendering logic)
  - **Data Flows**: Metric data → type detection → format selection → rendered HTML
  - **Logic**: Switch/case or dict-based formatter selection based on event type; extraction of specific fields from data object
  - **UX**: Timeline events show contextual, readable information instead of technical JSON
- **Class**: Tactical
- **Scope**: spex-ui

---

## Implementation Plan

1. **Create Pages Directory and Analytics Page**
   - Create `src/spex_cli/ui/pages/` directory
   - Create `src/spex_cli/ui/pages/analytics.py` with basic Streamlit structure
   - Copy and adapt CSS styling from memory.py → Links to D-ab6bf359

2. **Implement Metrics Data Loading**
   - Add `load_jsonl()` function to analytics.py → Links to D-079565d8
   - Add logic to read planId from `st.query_params` → Links to D-8b5fe23d
   - Filter metrics by planId → Links to D-079565d8
   - Handle empty state when no metrics found → Links to NFR-7747b6a4

3. **Build Timeline Visualization**
   - Sort metrics by timestamp (ascending) → Links to D-dcd53814
   - Render timeline HTML similar to memory.py pattern but simplified
   - Implement type-specific event data formatting → Links to D-440510dd
   - Display event type, timestamp, and formatted event data → Links to FR-afbcc95d

4. **Add Navigation Button to Memory Page**
   - Modify `render_item()` function in memory.py → Links to D-3091cfa0
   - Add conditional logic for Plans type
   - Insert analytics button HTML after fields_html but before children sections
   - Use `st.link` pattern or HTML anchor with query params → Links to D-8b5fe23d

5. **Test End-to-End Flow**
   - Verify analytics page appears in Streamlit sidebar
   - Test navigation from plan card to analytics page
   - Verify correct planId is passed and metrics are filtered
   - Test empty state handling

---

## Non-Goals

- **Metrics aggregation or statistics**: This feature only displays raw event timeline, not computed metrics or dashboards
- **Metrics editing or deletion**: Read-only view only
- **Multi-plan comparison**: Analytics page shows one plan at a time
- **Export functionality**: No CSV/PDF export in this iteration
- **Real-time updates**: Page requires manual refresh to see new metrics

---

## Open Questions

~~All open questions have been resolved:~~

1. **Analytics Button Placement**: ✓ RESOLVED - Button will be placed after fields (Goal/Context/Timeline), before nested sections (Requirements/Decisions)

2. **Empty PlanId Handling**: ✓ RESOLVED - Filter out metrics with empty or "none" planId completely. They're not associated with any plan.

3. **Event Data Display**: ✓ RESOLVED - Implement type-specific formatting for the data field:
   - `memory_write`: Show type and ID with appropriate icon
   - `state_transition`: Show from/to states
   - `user_prompt`: Show prompt length
   - Others: Display as formatted JSON

**Implementation Note**: Decision D-007 will be added to cover the type-specific event formatting logic.
