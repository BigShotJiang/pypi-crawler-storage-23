# Plan: Show All Sessions UI

Add a dedicated "Sessions" page to the Spex UI to allow users to browse and search historical development sessions.

## 1. Create Sessions Page
Create `src/spex_cli/ui/pages/sessions.py`:
- Apply common styles from `shared.py`.
- Load all sessions from `.spex/memory/sessions.jsonl`.
- Enrich session data with event counts from `.spex/memory/metrics.jsonl`.
- Implement a search bar to filter sessions by ID, source, or CWD.
- Render sessions in a chronological timeline/list (newest first).
- Provide a "📊 View Analytics" button for each session that links to `analytics.py?sessionId=<ID>`.

## 2. Update Sidebar Navigation
Modify `src/spex_cli/ui/memory.py`:
- Add a "🕒 Sessions History" button to the sidebar.

Modify `src/spex_cli/ui/pages/analytics.py`:
- Add a "🕒 Sessions History" button to the sidebar.

## 3. Decisions
- **D-sessions-page-path**: Use `src/spex_cli/ui/pages/sessions.py` to leverage Streamlit's multi-page support.
- **D-session-card-design**: Use the same card-based timeline design as `memory.py` for visual consistency.
- **D-session-analytics-link**: Use `st.query_params` to pass `sessionId` to the analytics page.

## 4. Verification
- Launch the UI using `spex ui`.
- Verify navigation from Memory -> Sessions.
- Verify navigation from Analytics -> Sessions.
- Verify session search.
- Verify that clicking "View Analytics" on a session card correctly loads the analytics for that session.
