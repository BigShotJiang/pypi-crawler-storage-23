# Plan: Aggregate Metrics by Type

## Goal
Add an aggregate summary section to the analytics page that shows the count of each event type using metric cards.

## Proposed Requirements
- **FR-agg-001**: Display aggregate counts for all event types in the filtered set.
- **FR-agg-002**: Use `st.metric` cards for visualization.
- **NFR-agg-001**: Handle empty states gracefully.

## Proposed Decisions
- **D-agg-001**: Use `collections.Counter` for aggregation.
- **D-agg-002**: Render cards in `st.columns`.
- **D-agg-003**: Position summary at the top of the page.

## Implementation Steps
1. Modify `src/spex_cli/ui/pages/analytics.py` to:
    - Import `Counter` from `collections`.
    - Extract event types from `plan_metrics`.
    - Calculate frequencies.
    - Create a new function `render_metrics_summary(metrics)`.
    - Invoke `render_metrics_summary` in `main()` after filtering metrics.
2. Verify visual layout in Streamlit.
3. Update memory with new requirements and decisions.
