# Tasks for Aggregate Metrics by Type

- [ ] **T-001**: Register new Requirements and Decisions in `.spex/memory/`.
    - Requirements: `FR-AGG-1`, `FR-AGG-2`, `NFR-AGG-1`
    - Decisions: `D-AGG-1`, `D-AGG-2`, `D-AGG-3`
- [ ] **T-002**: Implement `render_metrics_summary` and integrate into `main` in `src/spex_cli/ui/pages/analytics.py`.
    - Import `Counter`
    - Add `render_metrics_summary` function
    - Update `main` to call it
- [ ] **T-003**: Verify implementation visually (conceptual check) and run `spex healthcheck`.
