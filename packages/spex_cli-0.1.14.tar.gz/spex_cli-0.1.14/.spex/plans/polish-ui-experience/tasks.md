# Tasks for feature: polish-ui-experience

- [x] **T1**: Create shared UI module `src/spex_cli/ui/shared.py` with common CSS and `load_jsonl`. (Decision: D-db9b2274)
- [x] **T2**: Implement `apply_common_styles()` in `shared.py` to handle `st.set_page_config` and theme CSS. (Decision: D-db9b2274)
- [x] **T3**: Refactor `src/spex_cli/ui/memory.py` (renamed back from app.py) to use `shared.py` for common styles and logic. (Requirement: NFR-3b06977f)
- [x] **T4**: Refactor `src/spex_cli/ui/pages/analytics.py` to use `shared.py` for common styles and logic. (Requirement: NFR-3b06977f)
- [x] **T5**: Enhance sidebars in both pages: add branding, consistent headers, and improved spacing. (Requirement: NFR-3b06977f)
- [x] **T6**: Add "← Back to Memory" button to `analytics.py` sidebar. (Requirement: FR-9edfcb68)
- [x] **T7**: Refine timeline item rendering in `memory.py` with icons and polished layout. (Requirement: NFR-3b06977f)
- [x] **T8**: Refine timeline event rendering in `analytics.py` with icons and polished labels. (Requirement: NFR-3b06977f)
- [x] **T9**: Persist new requirements and decisions to Spex memory. Deprecate D-ab6bf359.
- [x] **T10**: Commit all changes with decision-id trailers.
- [x] **T11**: Fix UI entry point (renamed back to memory.py) to resolve 'file not found' error.
