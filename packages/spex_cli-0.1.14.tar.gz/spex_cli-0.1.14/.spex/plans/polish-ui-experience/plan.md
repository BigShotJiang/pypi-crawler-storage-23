# Plan: UI Polish & Refactor

Goal: Unify UI styles, enhance navigation, refresh sidebar, and polish UI components across spex-ui.

## Requirements & Decisions
- **R-polish-ui-1**: Create a shared UI module for consistent styling and common logic.
- **R-polish-ui-2**: Ensure sidebar visual hierarchy and headers are consistent across all pages.
- **R-polish-ui-3**: Add "Back to Memory" navigation link in Analytics page.
- **R-polish-ui-4**: Polish icons and labels for events and memory artifacts in timelines.
- **D-refactor-ui-css**: Replaces tactical D-ab6bf359. Use a shared module `shared.py` for UI theme and styling to ensure consistency and maintainability.

## Tasks

### Phase 1: Shared Module & CSS Refactor
- [ ] **T1**: Create `src/spex_cli/ui/shared.py` and move common CSS and basic utils like `load_jsonl`.
- [ ] **T2**: Add `apply_common_styles()` function to `shared.py` that handles `st.set_page_config` and applies the theme CSS.
- [ ] **T3**: Refactor `app.py` to use `shared.py` for styles and basic logic.
- [ ] **T4**: Refactor `analytics.py` to use `shared.py` for styles and basic logic.

### Phase 2: Sidebar & Navigation
- [ ] **T5**: Enhance sidebar in both pages: add branding/logo (using an icon), consistent headers, and improved spacing.
- [ ] **T6**: Add "← Back to Memory" button to `analytics.py` sidebar for easy navigation.
- [ ] **T7**: Ensure `st.title` and headers use consistent font weights and colors via `shared.py`.

### Phase 3: Component Polish
- [ ] **T8**: Refine timeline item rendering in `app.py`: add icons for Requirements (📋), Decisions (🔧), Plans (📦), and Policies (📜).
- [ ] **T9**: Refine timeline event rendering in `analytics.py`: more distinct coloring and icons for different event types.
- [ ] **T10**: Add hover effects and better transition animations via CSS in `shared.py`.

### Phase 4: Verification & Memory
- [ ] **T11**: Run and verify UI manually (if possible) or check for runtime errors.
- [ ] **T12**: Update Spex memory with new requirements and decisions. Deprecate D-ab6bf359.
