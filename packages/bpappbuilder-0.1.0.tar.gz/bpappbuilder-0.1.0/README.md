# BPAppBuilder

Оболочка над PyQt для создания приложений, как в 1С:Предприятии, но на Python

**WORK IN PROGRESS, DO NOT USE**

