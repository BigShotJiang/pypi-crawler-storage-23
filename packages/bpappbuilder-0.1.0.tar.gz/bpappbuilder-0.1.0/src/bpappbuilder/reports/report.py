from PySide6.QtWidgets import (QWidget, QLabel, QSplitter, QGroupBox, QPushButton, QMessageBox,
                            QTableWidget, QHeaderView, QStyleOptionHeader, QTableView,
                            QVBoxLayout, QLayout, QFormLayout)
from PySide6.QtCharts import (QChart, QChartView, QScatterSeries, QLineSeries, QCategoryAxis,
                            QValueAxis, QBarSet, QBarSeries, QBarCategoryAxis, QPieSeries,
                            QPieSlice)
from PySide6.QtCore import Qt, QRect, QAbstractTableModel, QModelIndex
from PySide6.QtGui import QPainter

from ..app.db import DataBase
from ..tabs.tab import Tab
from ..tabs.table import FormFieldWidget
from ..tabs.table_tab import TableTab
from ..fields.field import Field

from typing import Optional, Union, Sequence, Any, Callable, Iterable
from abc import ABC, abstractmethod
from enum import Enum, auto
from dataclasses import dataclass
from math import ceil
import string


def delete_children(layout: QLayout):
    while layout.count():
        child = layout.takeAt(0)
        if child.widget():
            child.widget().deleteLater()

@dataclass
class ReportSettingsItem:
    data: Union[str, None]  # Данные из формы формирования запроса
    optional: bool  # Является ли поле необязательным

class MultiLevelHeader(QHeaderView):
    """
    Заголовок таблицы с несколькими строками (уровнями).
    У одной колонки может быть несколько заголовков на разных уровнях.
    Пример того, как может выглядеть таблица:
    ----------------------------------  <-- Начало заголовка
    |    A1    |    A2    |    A3    |
    |----------|----------|----------|
    |    B1    |    B2    |    B3    |
    |----------|----------|----------|
    |    C1    |    C2    |    C3    |
    -----------|----------|-----------  <-- Конец заголовка
    |  Данные  |Ещё что-то|    48    |  <-- Начало данных
    |----------|----------|----------|
    |          |          |          |
    """

    def __init__(self, headers: list[list[str]]):
        """
        Args:
            headers (list[list[str]]): Список с построчными названиями колонок.
                Каждый уровень заголока - отдельный список со своими названиями
                
        """
        
        super().__init__(Qt.Orientation.Horizontal)
        self.headers = headers
        self.levels = len(headers)
        self.setMinimumHeight(25 * self.levels)

    def paintSection(self, painter: QPainter, rect: QRect, logical_index: int):
        opt = QStyleOptionHeader()
        self.initStyleOption(opt)
        opt.rect = rect
        opt.section = logical_index
        self.style().drawControl(self.style().ControlElement.CE_HeaderSection, opt, painter, self)
        
        painter.save()

        height = rect.height() // self.levels
        for level in range(self.levels):
            if logical_index >= len(self.headers[level]):
                break
            painter.drawText(QRect(rect.x(), rect.y() + height*level, rect.width(), height),
                             Qt.AlignmentFlag.AlignCenter,
                             self.headers[level][logical_index])

        painter.restore()


@dataclass
class Header:
    name: str
    subheaders: Union[list[Union["Header", str]], None] = None

@dataclass
class BottomHeader:
    name: str
    height: int
    level: int
    groups: list[int]
    x: int = -1
    width: int = -1

@dataclass
class HeaderGroup:
    name: str
    level: int
    bottom_headers_start: int
    bottom_headers_end: int

class ComplexMultiLevelHeader(QHeaderView):
    """
    Многоуровнеый заголовок таблицы любой сложности, где каждая колонка может включать в себя
    множество подколонок, подподколонок и т.д. Пример того, как может выглядеть таблица:
    ----------------------------------------  <-- Заголовок
    |      |       A2       |      A3      |
    |      |----------------|--------------|
    |  A1  |    B1   |      |    |    |    |
    |      |---------|  B2  | B1 | B2 | B3 |
    |      | C1 | C2 |      |    |    |    |
    ----------------------------------------
    |Данные| Да | Да |Что-то| 15 | 73 |0.15|  <-- Данные
    |--------------------------------------|
    |      |    |    |      |    |    |    |
    """

    def __init__(self, headers: list[Union[Header, str]]):
        """
        Args:
            headers (list[Header | str]): Список заголовков колонок таблицы. Список состоит
                из объектов Header, у каждого из которых есть поле name (название столбца) и
                subheaders (список подзаголвков, который также содержит объекты Headers).
                Вместо объекта Header может быть просто строка с именем колонки ("name" == Header("name")),
                в таком случае у этой колонки не будет дочерних подколонок
        """
        
        super().__init__(Qt.Orientation.Horizontal)
        self.headers, self.groups = self.calc_headers(headers.copy())
        self.headers_count = len(self.headers)
        self.levels = max(map(lambda x: x.level, self.headers)) + 1

        for header in self.headers:
            header.height = self.levels - len(header.groups)
      
        self.setMinimumHeight(25 * self.levels)
        self.sectionResized.connect(
            lambda *_: self.viewport().update()
        )

        
    def calc_headers(self, headers: list[Union[Header, str]], header_groups: Optional[list[HeaderGroup]] = None) -> tuple[list[BottomHeader], list[HeaderGroup]]:
        new_headers: list[BottomHeader] = []
        if header_groups is None:
            header_groups: list[HeaderGroup] = []

        for header in headers:
            if header.__class__ == str:
                new_headers.append(BottomHeader(header, 1, 0, []))
            elif header.subheaders is None or len(header.subheaders) == 0:
                new_headers.append(BottomHeader(header.name, 1, 0, []))
            else:
                group_idx = len(header_groups)
                group = HeaderGroup(header.name, 0, len(new_headers), -1)
                header_groups.append(group)
                subheaders, _ = self.calc_headers(header.subheaders, header_groups)
                group.bottom_headers_end = len(new_headers) + len(subheaders)

                for subgroup in header_groups[group_idx+1:]:
                    subgroup.level += 1
                    subgroup.bottom_headers_start += len(new_headers)
                    subgroup.bottom_headers_end += len(new_headers)
                
                for subheader in subheaders:
                    subheader.groups.insert(0, group_idx)
                    subheader.level += 1
                new_headers.extend(subheaders)
        return new_headers, header_groups

    def paintSection(self, painter: QPainter, rect: QRect, logical_index: int):
        self.headers[logical_index].x = rect.x()
        self.headers[logical_index].width = rect.width()
        
        # opt = QStyleOptionHeader()
        # self.initStyleOption(opt)
        # opt.rect = rect
        # opt.section = logical_index
        # self.style().drawControl(self.style().ControlElement.CE_HeaderSection, opt, painter, self)
        
        painter.save()

        height = rect.height() // self.levels
        header = self.headers[logical_index]
      
        painter.drawRect(rect.x(), rect.y() + height*header.level, rect.width(), height*header.height)
        painter.drawText(QRect(rect.x(), rect.y() + header.level*height, rect.width(), height*header.height),
                         Qt.AlignmentFlag.AlignCenter, self.headers[logical_index].name)
        painter.drawLine(rect.left(), rect.bottom(), rect.right(), rect.bottom())
        if logical_index == self.headers_count-1:
            painter.drawLine(rect.right(), rect.top() + height*header.level, rect.right(), rect.bottom())
        
        painter.restore()

    def paintEvent(self, event):
        super().paintEvent(event)

        painter = QPainter(self.viewport())
        height = self.height() // self.levels

        for group in self.groups:          
            x = self.headers[group.bottom_headers_start].x
            width = 0
            for header_idx in range(group.bottom_headers_start, group.bottom_headers_end):
                width += self.headers[header_idx].width

            painter.fillRect(x, height*group.level, width, height, self.palette().window())
            painter.drawRect(x, height*group.level, width, height)
            painter.drawText(x, height*group.level, width, height,
                             Qt.AlignmentFlag.AlignCenter, group.name)
        
        painter.end()


class ListReportTableModel(QAbstractTableModel):
    """
    Модель таблицы для отчёта в виде списка с возможностью заголовка с несколькими строками
    """

    def __init__(self, columns_count: int):
        super().__init__()
        self.rows_count = 0
        self.columns_count = columns_count

    def rowCount(self, parent=None):
        return self.rows_count

    def columnCount(self, parent=None):
        return self.columns_count

    def data(self, index, role):
        if role == Qt.ItemDataRole.DisplayRole:
            return ""
    
    def insertRow(self, row: int, parent=QModelIndex()):
        self.beginInsertRows(QModelIndex(), row, row)
        self.endInsertRows()
        self.rows_count += 1
        return True

    def flags(self, index):
        return Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable

@dataclass
class TextReportField:
    name: str
    widget: QLabel

GetTableWidget = Callable[[int, int], QWidget]
CreateTextReportHandler = Callable[[dict[str, TextReportField], dict[str, ReportSettingsItem], DataBase], None]
CreateTableReportHandler = Callable[[GetTableWidget, dict[str, ReportSettingsItem], DataBase], None]


class ReportSection(ABC):
    """
    Класс части отчёта с данными, отображаемыми в определённом виде.
    Данные для формирования отчёта берутся из БД
    """

    def __init__(self, sql_request: str, stretch: int = 0):
        """
        Args:
            sql_request (str): Запрос, отправляемый в БД для получения данных для отображения в отчёте
            stretch (int, optional): Число от 0 до 255, растяжение относительно других частей отчёта.
                Например, если у одной части stretch равно 1, а у второй 2, то вторая часть будет в 2 раза больше первой.
                По умолчанию 0.
        """

        self.sql_request = sql_request
        self.stretch = stretch
        self.db: Union[DataBase | None] = None
    
    def parse_in_braces(self, request: str, settings: dict[str, ReportSettingsItem], brackets: bool) -> tuple[str, int]:
        """
        Функция рекурсивной обработки части SQL запроса отчёта, находящейся в фигурных или квадратных кнопках
        Args:
            request (str): Оригинальный текст части запроса (он не должен начинаться с фигурной или квадратной скобки)
            settings (dict[str, ReportSettingsItem]): Словарь настроек запрос, указанных в его форме
            brackets (bool): Если True, обработка закончится при выходе за квадратные скобки,
                иначе - при выходе за фигурные скобки
        Returns:
            tuple: кортеж из 2 значений; tuple[part_text, part_end]
                - part_test (str): Текст обработанной части запроса, находящейся в скобках
                - part_end (int): Номер символа из оригинального запроса, на котором закончилась обработка
        """
        braces_list = []
        i = j = 0
        while i < len(request):
            if request[i] == "{":
                braces_list.append(i)
            elif request[i] == "}":
                if not brackets and len(braces_list) == 0:
                    return request[:i], j
                
                last_brace = braces_list.pop()
                last_find = 0
                while (field_start := request.find(":", max(last_brace, last_find)), i) != -1:
                    last_find = field_start
                    field_name = ""
                    k = field_start+1
                    while request[k] in string.ascii_letters + string.digits + "_-":
                        field_name += request[k]
                        k += 1
                    if settings[field_name].optional:
                        break

                if settings[field_name].data is None:
                    request = request[:last_brace] + request[i+1:]
                    i = last_brace
                    j += 1
                    if request[i] == "[":
                        block_data, block_end = self.parse_in_braces(request[i+1:], settings, True)
                        request = request[:i] + block_data + request[i+block_end+2:]
                        i += block_end-1
                        j += block_end+1
                else:
                    braces_block_data, braces_block_end = self.parse_in_braces(request[last_brace+1:], settings, False)
                    request = request[:last_brace] + braces_block_data + request[i+1:]
                    i -= 2
                    j -= 1

                    if request[i+1] == "[":
                        brackets_count = 0
                        start = True
                        brackets_block_end = i+1
                        while brackets_count > 0 or start:
                            start = False
                            if request[brackets_block_end] == "[":
                                brackets_count += 1
                            elif request[brackets_block_end] == "]":
                                brackets_count -= 1
                            brackets_block_end += 1
                        
                        request = request[:i+1] + request[brackets_block_end:]
                        j += brackets_block_end - i

            elif request[i] == "]" and brackets:
                return request[:i], j
            i += 1
            j += 1
        
        return request, -1

    def generate_sql_request(self, settings: dict[str, ReportSettingsItem]) -> str:
        """
        Создаёт SQL запрос для отправки в БД из запроса отчёта, производя в нём некоторые изменения:
            - Если поле настроек отчёта необязательное и оно не активировано, удаляется всё содержимое
                всех фигурных скобок, в которых вставляется значение этого поля и на их место ставится
                содержимое квадратных скобок (если есть), идущее за фигурными
            - Если поле настроек отчёта необязательное и оно активировано, удаляется содержимое квадратных
                скобок, идущих после фигурных с использованием внутри них этого поля, и вставляется содержимое
                фигурных скобок
        
        То есть, если в запросе отчёта будет конструкция
        {WHEN count > :min_count}[WHEN count > 0]
        и поле :min_count не будет активировано, на месте этой конструкции будет вставлено содержимое квадратных
        скобок (WHEN count > 0), а если будет активировано - фигурных (WHEN count > :min_count).
         
        Квадратные скобки не обязательны. Если их не будет, при неактивированном поле содержимое фигурных скобок
        будет просто вырезаться, а не заменяться на что-то.
        Например, в выражении
        WHEN count > 0 {AND count < :max_count}
        Будет удалено всё, что есть в фигурных скобках, если поле max_count не активировано.

        Другими словами, то, что находится в фигурных скобках, вставляется, если поле внутри них активировано, а иначе
        вставляется из квадратных.
        """
        return self.parse_in_braces(self.sql_request, settings, False)[0]
    
    @abstractmethod
    def create_widget(self, settings: dict[str, ReportSettingsItem]) -> QWidget:
        """
        Создание виджета с частью сформированного отчёта по указанным настройкам
        Args:
            settings (dict[name, data]): Словарь настроек для формирования отчёта,
                указанных пользователем, где
                - name (str): Название настройки
                - data (Union[str, None]): Введённые пользователем данные этой настройки
        """
        pass

class TextReport(ReportSection):
    """
    Отчёт в виде текста, где у каждого поля есть свои данные, отображается в формате
    
    ```
    Поле1: Значение1
    Поле2: Значение2
    ...
    ПолеN: ЗначениеN
    ```

    В таблице, получаемой из БД должна быть одна строка, в которой будут содержаться все
    отображаемые пользователю в виде отчёта данные
    """

    def __init__(self, sql_request: str, fields: list[Field],
                 create_form_handler: Optional[CreateTextReportHandler] = None, stretch: int = 0):
        """
        Args:
            fields (list): Список полей Field, из которых формируется текст отчёта, определяют то,
                какие имена будут у полей отчёта и как их данные будут отображаться
            create_form_handler ((fields, settings, db) -> None, optional): Функция, вызываемая после
                создания отчёта, с её помощью можно программно изменять данные, которые будут показаны
                пользователю, и их вид
                - fields (dict[str, TextReportField]): Словарь с виджетами отчёта, у которого ключи - это
                    SQL названия полей и их столбцов из таблицы, а значения - это объекты с атрибутами name
                    (отображаемое название поля) и widget (виджет QLabel с данными отчёта)
                - settings (dict[str, ReportSettingsItem]): Словарь с настройками отчёта, указанными
                    пользователем, ключи - SQL названия настроек, значения - данные настроек, объекты с атрибутами:
                    data (Optional[str]) - данные настройки, optional (bool) - является ли настройка необязательной
                - db (DataBase): База данных
        """

        super().__init__(sql_request, stretch)
        self.fields = {x.sql_name: x for x in fields}
        self.create_form_handler = create_form_handler
    
    def create_widget(self, settings: dict[str, ReportSettingsItem]) -> QWidget:
        widget = QWidget()
        widget.setProperty("class", "report-section")
        layout = QFormLayout()

        request = self.generate_sql_request(settings)
        db_data = self.db.cur.execute(request, {k: v.data for k, v in settings.items()}).fetchone()

        fields_rows: dict[str, TextReportField] = {}
        for field_name, field in self.fields.items():
            fields_rows[field_name] = TextReportField(field.name, QLabel(field.get_widget_text(field.create_for_table(str(db_data[field_name])))))

        if self.create_form_handler is not None:
            self.create_form_handler(fields_rows, settings, self.db)

        for field_name, field_row in fields_rows.items():
            layout.addRow(field_row.name + ": ", field_row.widget)
        
        widget.setLayout(layout)
        return widget

class ListReport(ReportSection):
    """
    Отчёт в виде списка со всеми строками получаемой из БД таблицы.
    
    Не производит никаких хитростей и перестановок, а выводит данные так,
    как они были получены из БД, только лишь преобразовывая данные в ячейках,
    чтобы они были понятны пользователю.

    Каждая строка списка может иметь свои подсписки.
    """

    def __init__(self, sql_request: str, columns: list[Field], subgroups: Optional[list] = None,
                 create_report_handler: Optional[CreateTableReportHandler] = None, stretch: int = 0):
        """
        Args:
            columns (list[Field]): список объектов полей, которые приводят данные каждой ячейки данных из БД
                в удобный для пользователя формат
            subgroups (list[ListReport], optional): Список объектов списочных отчётов,
                которые будут отображаться как подсписки для каждой строки этого основного списка,
                то есть каждая строка этого списка ещё имеет подсписки, формируемые на её основе
            create_report_handler ((get_widget_fn, settings, db) -> None, optional): Функция, вызываемая
                после создания отчёта, которая может менять данные и их отображение в таблице
                - get_widget_fn ((int, int) -> QWidget): Функция, которая получает в качестве аргументов
                    два числа: номера строки и колонки ячейки таблицы, а возвращает находящийся в этой ячейке виджет
                - settings (dict[str, ReportSettingsItem]): Словарь с настройками отчёта, указанными
                    пользователем, ключи - SQL названия настроек, значения - данные настроек, объекты с атрибутами:
                    data (Optional[str]) - данные настройки, optional (bool) - является ли настройка необязательной
                - db (DataBase): База данных
        """

        super().__init__(sql_request, stretch)
        self.columns: list[Field] = columns
        self.subgroups: list[ListReport] = [] if subgroups is None else subgroups
        self.create_report_handler = create_report_handler

        self.db: Union[DataBase | None] = None
    
    def create_widget(self, settings: dict[str, ReportSettingsItem]) -> QWidget:
        widget = QTableView()
        widget.setProperty("class", "report-section")
        model = ListReportTableModel(len(self.columns))
        header = MultiLevelHeader(self.get_header())

        widget.setModel(model)
        widget.setHorizontalHeader(header)

        for i, field in enumerate(self.columns):
            if field.column_width is None:
                widget.setColumnWidth(i, len(field.name)*9)
            else:
                widget.setColumnWidth(i, field.column_width)

        self.add_rows(model, widget, 0, settings)
        
        if self.create_report_handler is not None:
            self.create_report_handler(lambda row, column: widget.indexWidget(model.index(row, column)), settings, self.db)

        return widget
    
    def get_header(self, level: int = 0):
        header = [[x.name + " "*2 * level * (i == 0) for i, x in enumerate(self.columns)]]
        for sub in self.subgroups:
            header.extend(sub.get_header(level + 1))
        return header
    
    def add_rows(self, table_model: QAbstractTableModel, table_view: QTableView,
                 level: int, settings: dict[str, ReportSettingsItem]):
        request = self.generate_sql_request(settings)
        db_data = self.db.cur.execute(request, {k: v.data for k, v in settings.items()}).fetchall()
        for row_db_data in db_data:
            row_data: dict[str, ReportSettingsItem] = settings.copy()
            for key in row_db_data.keys():
                row_data[key] = ReportSettingsItem(row_db_data[key], False)

            row_id = table_model.rowCount()
            table_model.insertRow(row_id)

            for column_id, field in enumerate(self.columns):
                field_name = field.sql_name
                table_view.setIndexWidget(table_model.index(row_id, column_id),
                                          field.create_for_table(str(row_data[field_name].data) + " "*2 * level * (column_id == 0)))

            for subgroup in self.subgroups:
                subgroup.add_rows(table_model, table_view, level+1,row_data)


TableTotalFn = Callable[list[Any], Any]

class TableTotal:
    SUM: TableTotalFn = sum
    COUNT: TableTotalFn = len
    MIN:TableTotalFn = min
    MAX:TableTotalFn = max
    AVG:TableTotalFn = lambda l: sum(map(float, (l))) / len(l)

class TableReport(ReportSection):
    def __init__(self, sql_request: str, rows: str, columns: Union[list[str], str],
                 values: list[Field], total: Optional[TableTotalFn] = None,
                 create_report_handler: Optional[CreateTableReportHandler] = None, stretch: int = 0):
        super().__init__(sql_request, stretch)
        self.rows = rows
        self.columns = columns if columns.__class__ == list else [columns]
        self.values = values
        self.total = total
        self.create_report_handler = create_report_handler

    def create_widget(self, settings: dict[str, ReportSettingsItem]):
        request = self.generate_sql_request(settings)
        db_data = self.db.cur.execute(request, {k: v.data for k, v in settings.items()}).fetchall()
                
        widget = QTableView()
        widget.setProperty("class", "report-section")
        table_headers, table_columns = self.create_header(db_data)
        header = ComplexMultiLevelHeader(table_headers)
        model = ListReportTableModel(header.headers_count)

        widget.setModel(model)
        widget.setHorizontalHeader(header)
        
        for i in range(header.headers_count-1):
            field = self.values[i % len(self.values)]
            if field.column_width is None:
                widget.setColumnWidth(i+1, len(field.name) * 9)
            else:
                widget.setColumnWidth(i+1, field.column_width)

        rows = sorted({row[self.rows] for row in db_data})
        if self.total is not None:
            columns_data: list[list] = []
            for i in range(header.headers_count - 1):
                columns_data.append([])
        for row in rows:
            data = [x for x in db_data if x[self.rows] == row]

            row_id = model.rowCount()
            model.insertRow(row_id)
            widget.setIndexWidget(model.index(row_id, 0), QLabel(str(row)))

            for d in data:
                cells_in_column = 1
                for col in table_columns:
                    cells_in_column *= len(col)

                column_number = 1
                for level, col in enumerate(self.columns):
                    cell_column = table_columns[level].index(d[col])
                    column_number += cells_in_column // len(table_columns[level])*cell_column

                for field in self.values:
                    if self.total is not None:
                        columns_data[column_number - 1].append(d[field.sql_name])
                    widget.setIndexWidget(model.index(row_id, column_number), field.create_for_table(str(d[field.sql_name])))
                    column_number += 1
            
            if self.total is not None:
                column_number = header.headers_count - len(self.values)
                for field in self.values:
                    total_row = self.total([row[field.sql_name] for row in data])
                    if self.total is not None:
                        columns_data[column_number - 1].append(total_row)
                    widget.setIndexWidget(model.index(row_id, column_number), field.create_for_table(str(total_row)))
                    column_number += 1

        if self.total is not None:
            print(columns_data)
            
            row_id = model.rowCount()
            model.insertRow(row_id)
            widget.setIndexWidget(model.index(row_id, 0), QLabel("Итог"))
            for i in range(len(columns_data)):
                column_total = self.total(columns_data[i])
                field = self.values[i % len(self.values)]
                widget.setIndexWidget(model.index(row_id, i+1), field.create_for_table(str(column_total)))

        if self.create_report_handler is not None:
            self.create_report_handler(lambda row, column: widget.indexWidget(model.index(row, column)), settings, self.db)
        
        return widget
 
    def create_header(self, db_data: list) -> tuple[list[Header], list[list[str]]]:
        columns: list[list[str]] = []
        headers: list[Header] = [Header("")]

        for level, column in enumerate(self.columns):
            new_headers = {row[column] for row in db_data}
            columns.append(list(new_headers))
            new_headers = [Header(x) for x in new_headers]
            if level == 0:
                headers.extend(new_headers)
            else:
                for header in headers[1:]:
                    while header.subheaders is not None:
                        header = header.subheaders[0]
                    header.subheaders = new_headers

        if self.total is not None:
            headers.append(Header("Итог"))
        
        new_headers = [Header(field.name) for field in self.values]
        columns.append([field.name for field in self.values])
        for header in headers[1:]:
            while header.subheaders is not None:
                header = header.subheaders[0]
            header.subheaders = new_headers

        return headers, columns


class LineChartReport(ReportSection):
    """
    Отчёт в виде графика с линиями. У графика по одной оси X и Y, но при этом на нём
    может быть несколько линий.
    """

    def __init__(self, title: str, sql_request: str, x: str, values: str, lines: Optional[str] = None,
                 int_y_labels: bool = False, stretch: int = 0):
        """
        Args:
            title (str): Заголовок графика
            x (str): Имя столбца в SQLite таблице, который используется как набор значения для оси X
            values (str): Имя столбца в SQLite таблице для значений по оси Y у каждой точки графика
            lines (str, optional): Имя столбца в SQLite таблице, используемого как набор названий
                для множества линий графика. Например, если у значений этого столбца будет два варианта:
                "Апельсины" и "Яблоки", то на графике будет две линии: одна для всех значений, у которых
                в этом столбце было "Апельсины", а другая линия для "Яблок", а таблица, получаемая из БД
                должна будет содержать значения X и Y и для линии "Апельсины", и для линии "Яблоки"
            int_y_labels (bool, optional): Если True, метки на оси Y будут целочисленными
        """

        super().__init__(sql_request, stretch)
        self.title = title
        self.x = x
        self.lines = lines
        self.values = values
        self.int_y_labels = int_y_labels
    
    def create_widget(self, settings: dict[str, ReportSettingsItem]):
        request = self.generate_sql_request(settings)
        db_data = self.db.cur.execute(request, {k: v.data for k, v in settings.items()}).fetchall()

        chart = QChart()
        chart.setTitle(self.title)
        
        axis_x = QCategoryAxis()
        # axis_x.append("", -1)
        x_titles = {row[self.x] for row in db_data}
        for i, x in enumerate(sorted(x_titles)):
            axis_x.append(x, i)
        axis_x.setLabelsPosition(QCategoryAxis.AxisLabelsPosition.AxisLabelsPositionOnValue)
        axis_x.setRange(-0.3, len(x_titles)-0.7)
        chart.addAxis(axis_x, Qt.AlignmentFlag.AlignBottom)

        axis_y = QValueAxis()
        if self.int_y_labels:
            axis_y.setLabelFormat("%d")
        chart.addAxis(axis_y, Qt.AlignmentFlag.AlignLeft)

        max_y = float("-inf")
        min_y = float("inf")

        if self.lines is not None:
            lines_titles = {row[self.lines] for row in db_data}
            
            only_one_point = True
            for title in lines_titles:
                data = [row[self.values] for row in db_data if row[self.lines] == title]

                if len(data) == 1:
                    series = QScatterSeries(chart)
                else:
                    series = QLineSeries(chart)
                    only_one_point = False
                series.setName(title)
                series.setPointsVisible(True)

                for i, value in enumerate(data):
                    max_y = max(max_y, value + 0.5)
                    min_y = min(min_y, value)
                    series.append(i, value)
                
                chart.addSeries(series)
                series.attachAxis(axis_x)
                series.attachAxis(axis_y)
            
            if only_one_point and len(db_data) > 0:
                axis_x.setRange(-1, 1)
                axis_y.setRange(data[0]-1, data[0]+1)
            else:
                axis_y.setRange(min_y, max_y)
                if self.int_y_labels:
                    axis_y.setTickType(QValueAxis.TickType.TicksDynamic)
                    axis_y.setTickInterval(ceil((max_y - min_y) / 10))
        else:
            if len(db_data) == 1:
                series = QScatterSeries()
                axis_x.setRange(-1, 1)
                axis_y.setRange(data[0]-1, data[0]+1)
            else:
                series = QLineSeries()
            series.setPointsVisible(True)

            for i, row in enumerate(db_data):
                max_y = max(max_y, row[self.values] + 0.5)
                min_y = min(min_y, row[self.values])
                series.append(i, row[self.values])
            
            chart.addSeries(series)
            series.attachAxis(axis_x)
            series.attachAxis(axis_y)

            if len(db_data) > 1:
                axis_y.setRange(min_y, max_y)
                if self.int_y_labels:
                    axis_y.setTickType(QValueAxis.TickType.TicksDynamic)
                    axis_y.setTickInterval(ceil((max_y - min_y) / 10))

        widget = QChartView(chart)
        widget.setProperty("class", "report-section")
        widget.setRenderHint(QPainter.RenderHint.Antialiasing)

        return widget


class BarChartReport(ReportSection):
    """
    Отчёт в виде столбчатой диаграммы. Одна ось X, одна ось Y, возможны несколько
    наборов столбцов на одной диаграмме.
    """
    
    def __init__(self, title: str, sql_request: str, x: str, values: str, bar_sets: Optional[str] = None,
                 int_y_labels: bool = False, stretch: int = 0):
        """
        Args:
            title (str): Заголовок диаграммы
            x (str): Имя столбца в SQLite таблице, который используется как набор значения для оси X
            values (str): Имя столбца в SQLite таблице для значений по оси Y у каждой точки графика
            bar_sets (str, optional): Имя столбца в SQLite таблице, значения из которого используются
                как названия наборов столбцов. Работает аналогично аргументу lines в LineChartReport.
            int_y_labels (bool, optional): Если True, метки на оси Y будут целочисленными
        
        """
        super().__init__(sql_request, stretch)
        self.title = title
        self.x = x
        self.bar_sets = bar_sets
        self.values = values
        self.int_y_labels = int_y_labels

    def create_widget(self, settings: dict[str,ReportSettingsItem]):
        request = self.generate_sql_request(settings)
        db_data = self.db.cur.execute(request, {k: v.data for k, v in settings.items()}).fetchall()

        chart = QChart()
        chart.setTitle(self.title)

        axis_x = QBarCategoryAxis()
        x_titles = [row[self.x] for row in db_data]
        axis_x.append(x_titles)
        chart.addAxis(axis_x, Qt.AlignmentFlag.AlignBottom)

        axis_y = QValueAxis()
        if self.int_y_labels:
            axis_y.setLabelFormat("%d")
        chart.addAxis(axis_y, Qt.AlignmentFlag.AlignLeft)
  
        max_y = float("-inf")
        min_y = 0.0

        series = QBarSeries(chart)
        chart.addSeries(series)
        
        if self.bar_sets is not None:
            sets = {row[self.bar_sets] for row in db_data}
            for set_title in sets:
                data = [row[self.values] for row in db_data if row[self.bar_sets] == set_title]
            
                bar_set = QBarSet(set_title)
                bar_set.append(data)

                max_y = max(max(data) + 0.5, max_y)
                min_y = min(min(data), min_y)
            
                series.append(bar_set)
        else:
            data = [row[self.values] for row in db_data]
            bar_set = QBarSet()
            bar_set.append(data)

            max_y = max(max(data) + 0.5, max_y)
            min_y = min(min(data), min_y)
        
            series.append(bar_set)

        series.attachAxis(axis_x)
        series.attachAxis(axis_y)

        axis_y.setRange(min_y, max_y)
        if self.int_y_labels:
            axis_y.setTickType(QValueAxis.TickType.TicksDynamic)
            axis_y.setTickInterval(ceil((max_y - min_y) / 10))

        widget = QChartView(chart)
        widget.setProperty("class", "report-section")
        widget.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        return widget
        

class PieChartReport(ReportSection):
    """
    Отчёт как круговая диаграмма.
    """
    def __init__(self, title: str, sql_request: str, x: str, values: str,
                 hole: bool = False, distance: float = 0.0, stretch: int = 0):
        """
        Args:
            title (str): заголовок диаграммы
            x (str): Имя столбца SQLite таблицы, который используется как
                набор имён сегментов круговой диаграммы
            values (str): Имя столбца SQLite таблицы, из которого берутся
                размеры сегментов
            hole (bool): Будет ли диаграмма в виде пончика (с дыркой по середине).
                По умолчанию False
            distance (float): Расстояние между сегментами от 0 до 1. По умолчанию 0
        """
        super().__init__(sql_request, stretch)
        self.title = title
        self.x = x
        self.values = values
        self.hole = hole
        self.distance = distance
    
    def create_widget(self, settings: dict[str, ReportSettingsItem]):
        request = self.generate_sql_request(settings)
        db_data = self.db.cur.execute(request, {k: v.data for k, v in settings.items()}).fetchall()

        chart = QChart()
        chart.setTitle(self.title)

        series = QPieSeries(chart)
        if self.hole:
            series.setHoleSize(0.35)
        
        for row in db_data:
            slc: QPieSlice = series.append(row[self.x], row[self.values])
            slc.setLabelVisible()
            if self.distance > 0.0:
                slc.setExploded()
                slc.setExplodeDistanceFactor(self.distance)
            slc.setLabelPosition(QPieSlice.LabelPosition.LabelOutside)
        series.setPieSize(0.7)
        chart.addSeries(series)

        widget = QChartView(chart)
        widget.setProperty("class", "report-section")
        widget.setRenderHint(QPainter.RenderHint.Antialiasing)

        return widget 


class ReportTab(Tab):
    """
    Вкладка отчёта. Отчёт представляет собой структурированные в виде
    графика, таблицы или списка данные, взятые из БД по особому запросу,
    которыми может управлять пользователь через настройки отчёта.

    Вкладка имеет две части: одна форма для создания отчёта и управления его настройками,
    вторая содержит сам отчёт
    """

    def __init__(self, name: str, description: str, sections: list[ReportSection], settings: Optional[list[Field]] = None):
        """
        Args:
            name (str): Название вкладки, отображаемое в приложении
            description (str): Описание вкладки, отображаемое над отчётом и формой
            sections (list[ReportSection]): Список частей отчёта; один отчёт может состоять из нескольких
                частей, имеющих разные запросы в БД, по-разному отображающиеся, но с одинаковыми настройками
            settings (list[Field], optional): Список настроек в форме создания отчёта,
                которые может изменять пользователь, тем самым меняя то, как и какие данные будут взяты из БД
        """

        super().__init__(name)
        self.description = description
        self.sections = sections
        self.settings = {x.sql_name: x for x in settings} if settings is not None else {}

        self.forms_data_widgets: list[dict[str, FormFieldWidget]] = []
        self.forms_widgets: list[QGroupBox] = []
        self.forms_count = 0

        self.reports_widgets: list[QGroupBox] = []

    def create_report_widget(self, replace: bool = False, report_id: Optional[int] = None) -> QGroupBox:
        """
        Создание или обновление виджета для отчётов
         Args:
            replace (bool, optional): Нужно ли заменить старый виджет отчёта в приложении новым. По умолчанию False
            report_id (int, optional): Номер виджета отчёта, необходимо при замене (когда replace == True)
        """

        if replace:
            layout = self.reports_widgets[report_id].layout()
            delete_children(layout)
        else:
            report_id = self.forms_count

            widget = QGroupBox()
            widget.setProperty("class", "report-widget")
            self.reports_widgets.append(widget)

            layout = QVBoxLayout()

        self.reports_widgets[report_id].setLayout(layout)

        return self.reports_widgets[report_id]

    def create_form(self, replace: bool = False, form_id: Optional[int] = None) -> QGroupBox:
        """
        Создание или обновление виджета формы для настройки отчёта
        Args:
            replace (bool, optional): Нужно ли заменить старый виджет формы в приложении новым. По умолчанию False
            form_id (int, optional): Номер формы, необходимо при замене (когда replace == True)
        """

        if replace:
            layout = self.forms_widgets[form_id].layout()
            delete_children(layout)
        else:
            form_id = self.forms_count
            self.forms_widgets.append(QGroupBox())
            self.forms_data_widgets.append({})

            layout = QFormLayout()

        label = QLabel("<b>Формирование отчёта</b>")
        label.setProperty("class", "form-label")
        layout.addWidget(label)

        for field_name, field in self.settings.items():
            form_widget = field.create_for_form_whole()
            layout.addRow(field.name + ": ", form_widget.whole_widget)
            self.forms_data_widgets[form_id][field_name] = form_widget

        add_button = QPushButton("Сформировать")
        add_button.setProperty("class", "add-button")
        add_button.clicked.connect(lambda f=self.forms_count: self.generate_report(f))
        layout.addWidget(add_button)

        self.forms_widgets[form_id].setLayout(layout)

        if not replace:
            self.forms_count += 1

        return self.forms_widgets[form_id]
    
    def generate_report(self, form_id: int):
        widget = self.reports_widgets[form_id]
        layout: QVBoxLayout = widget.layout()
        delete_children(layout)
        
        data: dict[str, ReportSettingsItem] = {}
        for field_name, field in self.settings.items():
            form_widget = self.forms_data_widgets[form_id][field_name]
            if not form_widget.is_activated():
                data[field_name] = ReportSettingsItem(None, True)
                continue
            
            ok, message = field.check_widget(form_widget.field_widget, form=True)
            if not ok:
                QMessageBox.information(None, "Внимание!", field.name + ": " + message)
                return
            data[field_name] = ReportSettingsItem(field.get_widget_data(form_widget.field_widget, form=True),
                                                         form_widget.optional)

        settings_widget = QWidget()
        settings_widget.setProperty("class", "report-section")
        settings_layout = QFormLayout()

        for item_name, settings_item in data.items():
            if not (settings_item.optional and settings_item.data is None):
                field = self.settings[item_name]
                settings_layout.addRow(field.name + ": ", QLabel(field.get_widget_text(field.create_for_table(settings_item.data))))
        settings_widget.setLayout(settings_layout)
        layout.addWidget(settings_widget)

        splitter = QSplitter(orientation=Qt.Orientation.Vertical)
        for i, section in enumerate(self.sections):
            splitter.addWidget(section.create_widget(data))
            splitter.setStretchFactor(i, section.stretch)
        layout.addWidget(splitter)

    def create_tab_widget(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        reload_btn = QPushButton("Обновить")
        reload_btn.setFixedWidth(75)
        reload_btn.clicked.connect(self.update_tab)
        layout.addWidget(reload_btn)

        if len(self.description) > 0:
            label = QLabel(self.description)
            label.setWordWrap(True)
            layout.addWidget(label)
        
        splitter = QSplitter()
        splitter.addWidget(self.create_report_widget())
        splitter.addWidget(self.create_form())
        splitter.setStretchFactor(0, 1)
        layout.addWidget(splitter, stretch=1)
        
        widget.setLayout(layout)

        return widget
    
    def update_tab(self):
        for field in self.settings.values():
            field.fetch_data_from_db("")

        for i in range(self.forms_count):
            self.create_report_widget(True, i)
            self.create_form(True, i)
    
    def app_add_tab(self, db: DataBase):
        super().app_add_tab(db)

        for section in self.sections:
            section.db = db
        
        for field in self.settings.values():
            field.db = db
            field.fetch_data_from_db("")
