from PySide6.QtWidgets import (QTableWidget, QTableWidgetItem, QAbstractItemView, QDialogButtonBox, 
                             QLabel, QWidget, QCheckBox, QMessageBox, QDialog, QVBoxLayout, QFormLayout)
from PySide6.QtCore import Qt
from PySide6.QtGui import QKeyEvent

from ..app.db import DataBase
from ..app.themes import apply_styles

from typing import Any, Optional, Sequence, Union, Callable, overload
from dataclasses import dataclass
import sqlite3
import os


@dataclass
class FormFieldWidget:
    """
    Класс виджетов формы, относящихся к полю.
    Содержит отображаемый виджет, рабочий виджет поля с данными и функцию,
    возвращающую текущее состояние активности поля
    """

    whole_widget: QWidget
    field_widget: QWidget = None
    check_widget: QCheckBox = None
    is_activated: Callable[[], bool] = lambda: True
    optional: bool = True

    def __post_init__(self):
        if self.field_widget is None:
            self.field_widget = self.whole_widget
            self.optional = False
    
    def set_activated(self, state: bool):
        self.check_widget.setChecked(state)

@dataclass
class FormRow:
    """
    Класс строки формы определённого поля
    """

    name: str  # Отображаемое имя строки
    widget: FormFieldWidget  # Виджет формы

CreateFormHandler = Callable[[dict[str, FormRow], dict[str, Any], DataBase], None]
ColumnWidgetGenerator = Callable[[dict[str, QWidget], dict[str, Any], DataBase], QWidget]
BeforeSaveHandler = Callable[[dict[str, FormFieldWidget], dict[str, Any], DataBase], tuple[bool, str]]
AfterSaveHandler = Callable[[dict[str, FormFieldWidget], dict[str, Any], DataBase], None]

@dataclass
class TableColumn:
    """
    Класс дополнительной колонки таблицы, к которой не относится ни одно поле
    """

    name: str  # Отображаемое название колонки
    sql_name: str  # Название колонки для использования в коде
    widget_generator: ColumnWidgetGenerator  # Функция, создающая виджет для этой колонки, который будет вставлен в таблицу
    column_width: Optional[int] = None  # Ширина колонки

TableRowChangeHandler = Callable[[dict[str, QWidget], dict[str, Any], dict[str, TableColumn], DataBase], None]

class Table:
    """
    Объект для работы с таблицами
    """

    def __init__(self, name: str, sql_name: str, fields: dict[str, Any],
                 db: DataBase, additional_columns: Optional[dict[str, TableColumn]] = None,
                 before_save_handler: Optional[BeforeSaveHandler] = None,
                 after_save_handler: Optional[AfterSaveHandler] = None,
                 create_form_handler: Optional[CreateFormHandler] = None,
                 table_row_change_handler: Optional[TableRowChangeHandler] = None,
                 system_invisible_fields: Optional[list[str]] = None, request_end: str = ""):
        """
        Args:
            name (str): Имя таблицы, отображаемое в интерфейсе приложения
            sql_name (str): Название таблицы в SQL
            fields (dict[str, Field]): Список полей таблицы
            db (DataBase): База данных
            additional_columns (dict[str, TableColumn], optional): Словарь дополнительных колонок таблицы, для которых нет полей
            before_save_handler: Функция-обработчик, вызываемая перед сохранением данных формы в БД
            after_save_handler: Функция-обработчик, вызываемая после сохранения данных формы в БД
            create_form_handler: Функция, вызываемая при создании формы редактирования строки таблицы
            table_row_change_handler: Функция, обрабатывающая событие изменения данных в строке таблицы
            system_invisible_fields (list[str], optional): Список невидимых системных полей таблицы,
                которые должны задаваться вручную и не имеют объектов полей
            request_end (str, optional): Строка, которая добавляется в конец SQL запроса на создание таблицы
        """

        self.name = name
        self.sql_name = sql_name
        self.fields = fields
        self.db = db
        self.additional_columns = additional_columns if additional_columns is not None else {}
        self.before_save_handler = before_save_handler
        self.after_save_handler = after_save_handler
        self.create_form_handler = create_form_handler
        self.table_row_change_handler = table_row_change_handler
        self.system_invisible_fields = system_invisible_fields if system_invisible_fields is not None else []
        self.request_end = request_end

    def create_SQL_request(self) -> str:
        """
        Генерирует SQL запрос для добавления таблицы в БД
        """

        request: str = f"CREATE TABLE IF NOT EXISTS {self.sql_name} \n(\n\tid INTEGER PRIMARY KEY AUTOINCREMENT"
        for system_field in self.system_invisible_fields:
            request += ",\n\t" + system_field
        request += '\n' if len(self.fields) == 0 else ',\n'

        for i, field in enumerate(self.fields.values()):
            request += "\t" + field.sql_name + " " + field.sql_type
            if field.primary_key:
                request += " PRIMARY KEY"
            if field.unique:
                request += " UNIQUE"
            if field.autoincrement:
                request += " AUTOINCREMENT"
            if field.not_null:
                request += " NOT NULL"
            if field.default is not None:
                request += " DEFAULT '" + field.default + "'"
            if i < len(self.fields) - 1 or len(self.request_end):
                request += ","
            request += "\n"

        if len(self.request_end) > 0:
            request += self.request_end + "\n"

        request += ");"

        return request

    def create_table(self, table: QTableWidget, form_data_widgets: dict[str, FormFieldWidget], conditions: Optional[str] = None, no_db: bool = False):
        """
        Изменяет виджет таблицы с заполненными значениями из БД
        Args:
            table (QTableWidget): Виджет таблицы, в который надо добавить данные
            form_data_widgets: (dict[str, FormFieldWidget]): Словарь из виджетов формы, который будет установлен полям
            conditions (str, optional): Условия отбора строк в таблицы
            no_db (bool, optional): Если True, у таблицы не будет никаких связей с БД, не будет полей ID.
                По умолчанию False
        """

        table.setRowCount(0)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)

        if no_db:
            table.setColumnCount(len(self.fields) + len(self.additional_columns))
            table.setHorizontalHeaderLabels([x.name for x in list(self.fields.values()) + list(self.additional_columns.values())])
            shift = 0
        else:
            table.setColumnCount(1 + len(self.fields) + len(self.additional_columns))
            table.setHorizontalHeaderLabels(["ID"] + [x.name for x in list(self.fields.values()) + list(self.additional_columns.values())])
            table.setColumnWidth(0, 50)
            shift = 1

        for i, field in enumerate(list(self.fields.values()) + list(self.additional_columns.values())):
            if field.column_width is None:
                table.setColumnWidth(i+shift, len(field.name) * 7)
            else:
                table.setColumnWidth(i+shift, field.column_width)
        
        if not no_db:
            all_data = self.db.cur.execute(
                f"SELECT * FROM {self.sql_name} {'WHERE '+conditions if conditions is not None else ''}"
                ).fetchall()
            for row_data in all_data:
                self.add_row(table, row_data, False)
        
        try:
            table.cellDoubleClicked.disconnect()
        except:
            pass
            
        table.cellDoubleClicked.connect(lambda row, column: self.open_row_data(row, table, form_data_widgets, no_db))
        table.keyPressEvent = lambda e: self.table_keyPressEvent(e, table, no_db)

    def add_row(self, table: QTableWidget, data: Sequence[Any], no_id_column: bool = False):
        """
        Добавляет в виджет таблицы новую строку
        Args:
            table (QTableWidget): Виджет таблицы, в который надо добавить строку
            data (Sequence[Any]): Данные для добавления в строку
            no_id_column (bool, optional): Если True, в строку не будет добавлен ID. По умолчанию False
        """

        last_row = table.rowCount()
        table.insertRow(last_row)

        if not no_id_column:
            id_widget = QTableWidgetItem(str(data["id"]))
            id_widget.setFlags(id_widget.flags() & ~Qt.ItemFlag.ItemIsEditable)
            table.setItem(last_row, 0, id_widget)
            shift = 1
        else:
            shift = 0

        for i, field in enumerate(self.fields.values()):
            widget = field.create_for_table(str(data[field.sql_name]) if data[field.sql_name] is not None else None)
            ok, message = field.check_widget(widget, form=False)
            if not ok:
                table.removeRow(last_row)
                return
            table.setCellWidget(last_row, i+shift, widget)

        row_widgets: dict[str, QWidget] = {"id": table.item(last_row, 0)} if not no_id_column else {}
        row_widgets.update({field.sql_name: table.cellWidget(last_row, i+shift) for i, field in enumerate(self.fields.values())})

        for j, column in enumerate(self.additional_columns.values()):
            table.setCellWidget(last_row, j+1+i+shift, column.widget_generator(row_widgets, self.fields, self.db))

    def open_row_data(self, row: int, table: QTableWidget, form_data_widgets: dict[str, FormFieldWidget], no_db: bool):
        """
        Функция, которая при двойном клике на строку в таблице выводит в отдельном окне все данные из данной строки
        Args:
            row (int): Номер строки в таблице
            table (QTableWidget): Виджет таблицы
            form_data_widgets: (dict[str, QWidget]): Словарь из виджетов формы, который будет установлен полям
            no_db (bool, optional): Если True, то у таблицы нет никаких связей с БД, нет полей ID.
                По умолчанию False
        """

        if not no_db:
            data = {"id": table.item(row, 0).text()}
            shift = 1
        else:
            data = {}
            shift = 0
        
        for i, field in enumerate(self.fields.values()):
            data[field.sql_name] = field.get_widget_data(table.cellWidget(row, i+shift), form=False)

        dialog = RowDataDialog(data, self.fields, self.name, self.before_save_handler, self.create_form_handler, self.db, no_db)
        dialog_result = dialog.exec()
        if dialog_result == QDialog.DialogCode.Accepted:
            for i, field in enumerate(self.fields.values()):
                if not dialog.form_widgets[field.sql_name].is_activated():
                    data[field.sql_name] = None
                    field_data = None
                else:
                    field_data = field.get_widget_data(dialog.form_widgets[field.sql_name].field_widget, form=True)
                    data[field.sql_name] = field_data

                field.change_widget_data(table.cellWidget(row, i+shift), field_data)

            if not no_db:
                request = f"UPDATE {self.sql_name} SET {', '.join(map(lambda x: x + ' = ?', self.fields.keys()))} WHERE id = ?"
                self.db.cur.execute(request, (*list(data.values())[1:], data["id"]))
                self.db.conn.commit()

            if self.after_save_handler is not None:
                self.after_save_handler(dialog.form_widgets, self.fields, self.db)
        
        row_widgets: dict[str, QWidget] = {"id": table.item(row, 0)} if not no_db else {}
        for i, field in enumerate(self.fields.values()):
            field.form_widgets = form_data_widgets
            row_widgets[field.sql_name] = table.cellWidget(row, i+shift)

        for j, column in enumerate(self.additional_columns.values()):
            row_widgets[column.sql_name] = table.cellWidget(row, j+1+i+shift)
        
        if self.table_row_change_handler is not None and dialog_result == QDialog.DialogCode.Accepted:
            self.table_row_change_handler(row_widgets, self.fields, self.additional_columns, self.db)
    
    def add_data_to_db(self, data: dict[str, str]) -> int:
        """
        Добавляет данные в БД
        Args:
            data (dict[str, str]): Данные, которые надо добавить в БД
        Returns:
            int: ID добавленной в БД строки
        """

        try:
            self.db.cur.execute(f"INSERT INTO {self.sql_name} ({', '.join(data.keys())}) VALUES ({', '.join(['?']*len(data))})",
                                (*data.values(),))
            data["id"] = self.db.cur.lastrowid
            self.db.conn.commit()
        except sqlite3.IntegrityError:
            QMessageBox.information(None, "Внимание!", "Нарушена уникальность данных таблицы, данные не могут быть добавлены")
            return -1

        return self.db.cur.lastrowid

    def get_and_check_form_data(self, form_data_widgets: dict[str, FormFieldWidget]) -> Union[dict[str, str], None]:
        """
        Получает и проверяет данные из формы
        Args:
            form_data_widgets: (dict[str, QWidget]): Словарь из виджетов формы, из которой надо брать данные
        Returns:
            dict: Словарь с данными формы, где ключи - SQL названия полей, а значения - данные из этого поля.
                Функция может вернуть None, если в данных будет ошибка
        """

        data = {}
        for field_sql_name, field in self.fields.items():
            if not form_data_widgets[field_sql_name].is_activated():
                data[field_sql_name] = None
                continue

            widget = form_data_widgets[field_sql_name].field_widget
            ok, message = field.check_widget(widget, form=True)
            if not ok:
                QMessageBox.information(None, "Внимание!", field.name + ": " + message)
                return
            data[field_sql_name] = field.get_widget_data(widget, form=True)
        
        if self.before_save_handler is not None:
            ok, message = self.before_save_handler(form_data_widgets, self.fields, self.db)
            if not ok:
                QMessageBox.information(None, "Внимание!", message)
                return
        
        return data

    def add_data(self, form_data_widgets: dict[str, FormFieldWidget], tables: list[QTableWidget], no_db: bool = False,
                 additional_system_data: Optional[dict[str, str]] = None) -> dict[str, str]:
        """
        Получает и проверяет данны в форме, добавляет полученные данные в БД и виджеты таблиц
        Args:
            form_data_widgets: (dict[str, FormFieldWidget]): Словарь из виджетов формы, который будет установлен полям
            tables (list[QTableWidget]): Список таблиц, которым надо добавить строку
            no_db (bool, optional): Если True, то у таблицы нет никаких связей с БД, нет полей ID.
                По умолчанию False
            additional_system_data (dict[str, str], optional): Словарь из данных для невидимых системных полей,
                где ключи - их названия
        """

        data = self.get_and_check_form_data(form_data_widgets)
        if data is None:
            return
        if additional_system_data is not None:
            data.update(additional_system_data)

        if not no_db:
            data_id = self.add_data_to_db(data)
            if data_id == -1:
                return None
            
            for field in self.fields.values():
                field.add_to_db(form_data_widgets[field.sql_name], data, self.sql_name)

        for table in tables:
            self.add_row(table, data, no_db)
        
        if self.after_save_handler is not None:
            if no_db:
                new_form_widgets = form_data_widgets
            else:
                new_form_widgets = form_data_widgets.copy()
                new_form_widgets.update({"id": FormFieldWidget(QLabel(str(data_id)))})
            self.after_save_handler(new_form_widgets, self.fields, self.db)
        
        return data

    def get_table_data(self, table: QTableWidget, check: bool = False) -> Union[list[dict[str, str]], None]:
        """
        Получает все данные из таблицы и возвращает их в виде списка словарей
        Args:
            table (QTableWidget): Виджет таблицы, из которой будут браться данные
            check (bool, optional): Нужно ли проверять данные таблицы. По умолчанию False
        Returns:
            list: Список словарей dict[name, data], где name - SQL-имя поля, а data - его данные из строки таблицы.
                Если было установлено check в True и была найдена ячейка с невалидными данные, функция вернёт None
        """

        data = []
        for row in range(table.rowCount()):
            row_data = {}
            for i, field in enumerate(self.fields.values()):
                row_data[field.sql_name] = field.get_widget_data(table.cellWidget(row, i), form=False)
                if check:
                    ok, message = field.check_widget(table.cellWidget(row, i), form=False)
                    if ok:
                        return None
            data.append(row_data)
        
        return data

    def table_keyPressEvent(self, event: QKeyEvent, table: QTableWidget, no_db: bool):
        """
        Обработчик событий для таблицы
        Args:
            event (QKeyEvent): Событие, которое надо обработать
            table (QTableWidget): Виджет таблицы, из которой были удалены строки
            no_db (bool, optional): Если True, то у таблицы нет никаких связей с БД, нет полей ID.
                По умолчанию False
        """

        if event.key() == Qt.Key.Key_Delete:
            selected_rows = sorted(table.selectionModel().selectedRows(), key=lambda x: x.row())
            canceled = 0
            all = False
            while len(selected_rows)-canceled > 0:
                row = selected_rows[canceled].row()
                if not no_db:
                    data_id = table.item(row, 0).text()
                if all or (dialog := SubmitDialog(
                        f"Вы уверены, что хотите удалить {f'строку <b>{row+1}</b>' if no_db else f'запись <b>{self.name} #{data_id}</b>'}?"
                        )).exec() == QDialog.DialogCode.Accepted:
                    table.removeRow(row)
                    if not no_db:
                        self.db.cur.execute(f"DELETE FROM {self.sql_name} WHERE id = ?", (data_id,))
                        self.db.conn.commit()

                    if not all:
                        all = dialog.yes_to_all
                else:
                    canceled += 1
                selected_rows = sorted(table.selectionModel().selectedRows(), key=lambda x: x.row())

class RowDataDialog(QDialog):
    """
    Окно для отображения и изменения данных из строки таблицы.
    Список виджетов, из которых можно взять данные после нажатия кнопки "Apply", находится в атрибуте form_widgets
    """

    def __init__(self, data: Sequence[Any], fields: dict[str, Any], table_name: str,
                 before_save_handler: Optional[BeforeSaveHandler], create_form_handler: Optional[CreateFormHandler],
                 db: DataBase, hidden_id: bool = False):
        """
        Создание формы редактирования по имеющимся данным
        Args:
            data (Sequence[Any]): Объект пар ключ-значение, в которых ключ - имя поля, а значение - данные поля, взятые из таблицы
            fields (list[Field]): Список полей, которым принадлежат данные
            table_name (str): Имя таблицы, данные из которых должны быть отображены
            before_save_handler: Функция-обработчик, вызываемая перед сохранением данных формы в БД
            create_form_handler: Функция, вызываемая при создании формы редактирования строки таблицы
            db (DataBase): База данных
            hidden_id (bool): Если True, в форме не будет создаваться строка ID
        """

        super().__init__()
        self.setWindowTitle("Просмотр и изменение записи")

        self.before_save_handler = before_save_handler
        self.fields = fields
        self.db = db

        apply_styles(self)
        
        buttonBox = QDialogButtonBox(QDialogButtonBox.StandardButton.Apply |
                                     QDialogButtonBox.StandardButton.Cancel)
        buttonBox.button(QDialogButtonBox.StandardButton.Apply).clicked.connect(self.check_and_accept)
        buttonBox.rejected.connect(self.reject)

        layout = QVBoxLayout()
        self.setLayout(layout)

        label = QLabel(f"<b>{table_name} #{data['id']}</b>" if "id" in data.keys() else f"<b>Добавление {table_name}</b>")
        label.setProperty("class", "rowdatadialog-label")
        layout.addWidget(label)

        form = QWidget()
        form_layout = QFormLayout()
        form.setLayout(form_layout)

        self.form_widgets: dict[str, FormRow] = {}
        if "id" in data.keys():
            self.form_widgets["id"] = FormRow("ID", FormFieldWidget(QLabel(str(data["id"]))))
        for field_sql_name, field in fields.items():
            self.form_widgets[field_sql_name] = FormRow(field.name, field.create_for_form_whole(data[field_sql_name]))
        
        if create_form_handler is not None:
            create_form_handler(self.form_widgets, fields, db)

        for field_sql_name, field_row in self.form_widgets.items():
            if field_sql_name != "id" or not hidden_id:
                if field_sql_name in fields.keys():
                    fields[field_sql_name].connect_on_change_handler(field_row.widget.field_widget)

                tooltip = field_row.widget.whole_widget.toolTip()
                if tooltip == "":
                    tooltip = field_row.widget.field_widget.toolTip()
                
                form_layout.addRow(QLabel(field_row.name + ": ", toolTip=tooltip), field_row.widget.whole_widget)
        
        for field_name, field_widget in self.form_widgets.items():
            self.form_widgets[field_name] = field_widget.widget
        # self.form_widgets: dict[str, FormFieldWidget] = {k: v.widget for k, v in self.form_widgets.items()}

        for field in fields.values():
            field.form_widgets = self.form_widgets

        layout.addWidget(form)

        layout.addStretch()
        layout.addWidget(buttonBox)

    def check_and_accept(self):
        for field_sql_name, field in self.fields.items():
            if not self.form_widgets[field_sql_name].is_activated():
                continue

            widget = self.form_widgets[field_sql_name].field_widget
            ok, message = field.check_widget(widget, form=True)
            if not ok:
                QMessageBox.information(None, "Внимание!", field.name + ": " + message)
                return

        if self.before_save_handler is not None:
            ok, message = self.before_save_handler(self.form_widgets, self.fields, self.db)
            if not ok:
                QMessageBox.information(None, "Внимание!", message)
                return
        
        self.accept()

class SubmitDialog(QDialog):
    """
    Замена QMessageBox.question со стилями из styles.qss
    """

    def __init__(self, message: str):
        super().__init__()
        self.setWindowTitle("Подтверждение")

        apply_styles(self)
        
        self.yes_to_all = False

        layout = QVBoxLayout()
        self.setLayout(layout)

        buttonBox = QDialogButtonBox(QDialogButtonBox.StandardButton.Yes |
                                     QDialogButtonBox.StandardButton.No |
                                     QDialogButtonBox.StandardButton.YesToAll)
        buttonBox.accepted.connect(self.accept)
        buttonBox.rejected.connect(self.reject)
        buttonBox.button(QDialogButtonBox.StandardButton.YesToAll).clicked.connect(self.accept_to_all)

        label = QLabel(message)
        label.setProperty("class", "submitdialog-label")
        layout.addWidget(label)

        layout.addWidget(buttonBox)

    def accept_to_all(self):
        self.yes_to_all = True
        self.accept()
