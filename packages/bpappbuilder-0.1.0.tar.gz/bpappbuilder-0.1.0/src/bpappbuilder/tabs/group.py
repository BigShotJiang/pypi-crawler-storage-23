from ..app.db import DataBase
from .tab import Tab

from typing import Optional

class TabGroup:
    """
    Группа вкладок
    """

    def __init__(self, name: str, tabs: Optional[list[Tab]] = None):
        """
        Args:
            name (str): Отображаемое название группы
            tabs (list[Tab], optional): Список вкладок группы
        """

        self.name = name
        if tabs is None:
            self.tabs = []
        else:
            self.tabs = tabs
    
    def add_tab(self, tab: Tab):
        """
        Добавление вкладки в список таблиц группы
        Args:
            tab (Tab): Вкладка, которую надо добавить в список
        """

        self.tabs.append(tab)
