from PySide6.QtWidgets import QWidget, QLabel, QVBoxLayout

from ..app.db import DataBase

from abc import ABC, abstractmethod
from typing import Union

class Tab(ABC):
    """
    Вкладка в приложении
    """

    def __init__(self, name: str):
        """
        Args:
            name (str): Название вкладки
        """

        self.name = name
        self.db: Union[DataBase, None] = None

    def app_add_tab(self, db: DataBase):
        """
        Метод, который вызывается при добавлении вкладки в приложение
        Args:
            db (DataBase): База данных
        """
        self.db = db

    @abstractmethod
    def create_tab_widget(self) -> QWidget:
        """
        Создание виджета вкладки
        Returns:
            QWidget: Виджет вкладки для добавления в приложение
        """
        pass

class InfoTab(Tab):
    """
    Вкладка только с текстом. Может использоваться для выведения справки
    """

    def __init__(self, name: str, text: str):
        """
        Args:
            text (str): Текст, который будет показан на вкладке
        """

        super().__init__(name)
        self.text = text

    def create_tab_widget(self) -> QWidget:
        widget = QWidget()
        layout = QVBoxLayout()
        widget.setLayout(layout)

        text = QLabel(self.text)
        text.setWordWrap(True)
        layout.addWidget(text)

        layout.addStretch()

        return widget

class CustomTab(Tab):
    def __init__(self, name: str, widget: QWidget):
        super().__init__(name)
        self.widget = widget
    
    def create_tab_widget(self):
        widget = QWidget()
        layout = QVBoxLayout()
        widget.setLayout(layout)

        layout.addWidget(self.widget)

        layout.addStretch()

        return widget
