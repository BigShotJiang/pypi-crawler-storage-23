from PySide6.QtWidgets import (QTableWidget, QGroupBox, QWidget, QLineEdit, QLabel, 
                             QPushButton, QSplitter, QCheckBox, QFormLayout, QVBoxLayout,
                             QHBoxLayout)
from PySide6.QtCore import Qt

from ..fields.field import Field
from ..app.db import DataBase
from .tab import Tab
from .table import (Table, FormRow, FormFieldWidget, TableColumn, BeforeSaveHandler,
                    AfterSaveHandler, CreateFormHandler, TableRowChangeHandler)

from typing import Union, Optional


class TableTab(Tab):
    """
    Вкладка таблицы, в которой хранятся строки данных, согласно указанным полям таблицы.
    Также имеет форму для добавлений строк в таблицу
    """

    def __init__(self, name: str, sql_name: str, description: str = "", hide_form: bool = False,
                 form_under_table: bool = False, additional_columns: Optional[list[TableColumn]] = None,
                 unique: list[list[str]] = None,
                 before_save_handler: Optional[BeforeSaveHandler] = None,
                 after_save_handler: Optional[AfterSaveHandler] = None,
                 create_form_handler: Optional[CreateFormHandler] = None,
                 table_row_change_handler: Optional[TableRowChangeHandler] = None):
        """
        Args:
            name (str): Имя вкладки, отображаемое в интерфейсе приложения
            sql_name (str): Название таблицы в SQL
            description (str, optional): Описание таблицы, отображается как многострочный текст над виджетами таблицы и формы
            hide_form (bool, optional): Если True, форма не будет показываться, на вкладке будет только таблица. По умолчанию False
            form_under_table (bool, optional): Если True, форма будет находится под таблицей, иначе справа от таблицы. По умолчанию False
            additional_columns (list[TableColumn], optional): Список дополнительных колонок таблицы, для которых нет полей; у TableColumn поля
                - name (str): Отображаемое название колонки
                - sql_name (str): Название колонки для использования в коде
                - widget_generator (ColumnWidgetGenerator): Функция, создающая виджет для этой колонки, который будет вставлен в таблицу
                - column_width (int, optional): Ширина колонки
            unique (list): Список списков SQL названий столбцов, которые должны быть в таблице уникальными,
                определяет уникальность групп столбцов; добавляет ограничение на уровне таблицы, а не отдельных столбцов.
                Например, если этот аргумент будет равен [["age", "email"], ["data1", "data2"]], то в таблицу нельзя будет
                добавить 2 строки с одинаковыми столбцами "age" и "email" или одинаковыми "data1" и "data2"
            before_save_handler ((form_widgets, fields, db) -> tuple[ok, message], optional): Функция-обработчик, вызываемая перед сохранением данных формы в БД
                - form_widgets (dict[str, FormFieldWidget]): Словарь виджетов формы (ключи - sql_name'ы полей)
                - fields (dict[str, Field]): Словарь полей данной формы (ключи - sql_name'ы полей)
                - db (DataBase): База данных
                - ok (bool): True, если разрешается сохранение данных в БД
                - message (str): Сообщения для пользователя о том, почему данные были отклонены
            after_save_handler ((form_widgets, fields, db) -> None, optional): Функция-обработчик, вызываемая после сохранения данных формы в БД
                - form_widgets (dict[str, FormFieldWidget]): Словарь виджетов формы (ключи - sql_name'ы полей)
                - fields (dict[str, Field]): Словарь полей данной формы (ключи - sql_name'ы полей)
                - db (DataBase): База данных
            create_form_handler ((form_widgets, fields, db) -> None, optional): Функция, вызываемая при создании формы редактирования строки таблицы, где
                - form_widgets (dict[str, row]): Словарь виджетов формы (ключи - sql_name'ы полей), словарь можно изменять, и эти изменения отразятся на форме
                - - row (FormRow): Объект данных строки формы, у которого name - название поля, отображаемое в форме, а widget - сам виджет поля
                - fields (dict[str, Field]): Словарь полей данной формы (ключи - sql_name'ы полей)
                - db (DataBase): База данных
            table_row_change_handler ((row_widgets, fields, additional_columns, db) -> None, optional): Функция, обрабатывающая событие изменения данных в строке таблицы, в которой
                - row_widgets (dict[str, QWidget]): Словарь виджетов строки таблицы
                - fields (dict[str, Field]): Словарь полей данной формы (ключи - sql_name'ы полей)
                - additional_columns (dict[str, TableColumn]): Словарь дополнительных столбцов таблицы (ключи - их sql_name'ы)
                - db (DataBase): База данных
        """
        
        self.name = name
        self.sql_name = sql_name
        self.description = description
        self.hide_form = hide_form
        self.form_under_table = form_under_table
        self.additional_columns = {x.sql_name: x for x in additional_columns} if additional_columns is not None else {}
        self.unique = unique

        self.table: Union[Table, None] = None

        self.forms_data_widgets: list[dict[str, FormFieldWidget]] = [{}]
        self.forms_widgets: list[QWidget] = []
        self.forms_count = 0

        self.tables_widgets: list[QTableWidget] = []
        self.tables_count = 0

        self.search_line: Union[QLineEdit, None] = None

        self.fields: dict[str, Field] = {}
        self.db: Union[DataBase, None] = None
        
        self.before_save_handler: Union[BeforeSaveHandler, None] = before_save_handler
        self.after_save_handler: Union[AfterSaveHandler, None] = after_save_handler
        self.create_form_handler: Union[CreateFormHandler, None] = create_form_handler
        self.table_row_change_handler: Union[TableRowChangeHandler, None] = table_row_change_handler
    
    def add_field(self, field: Field):
        """
        Добавляет таблице и форме свойство
        Args:
            field (Field): Свойство для добавления
        """

        field.form_widgets = self.forms_data_widgets[self.forms_count]
        field.table_fields = self.fields
        self.fields[field.sql_name] = field

    def create_table(self, replace: bool = False, table_id: Optional[int] = None) -> QTableWidget:
        """
        Создаёт виджет таблицы с заполненными значениями из БД
        Args:
            replace (bool, optional): Нужно ли заменить старый виджет таблицы в приложении новым. По умолчанию False
            table_id (iny, optional): Номер таблицы, необходимо при замене (когда replace == True)
        """

        if not replace:
            table_id = self.tables_count
            self.tables_widgets.append(QTableWidget())
        
        self.table.create_table(self.tables_widgets[table_id], self.forms_data_widgets[table_id])

        self.tables_count += 1

        return self.tables_widgets[table_id]

    def create_form(self, replace: bool = False, form_id: Optional[int] = None) -> QGroupBox:
        """
        Создаёт виджет формы для добавления записей в таблицу
        Args:
            replace (bool, optional): Нужно ли заменить старый виджет формы в приложении новым. По умолчанию False
            form_id (int, optional): Номер формы, необходимо при замене (когда replace == True)
        """

        if replace:
            layout = self.forms_widgets[form_id].layout()
            while layout.count():
                child = layout.takeAt(0)
                if child.widget():
                    child.widget().deleteLater()
        else:
            form_id = self.forms_count
            self.forms_widgets.append(QGroupBox())
            self.forms_data_widgets.append({})
            
            layout = QFormLayout()

        label = QLabel("<b>Добавить запись</b>")
        label.setProperty("class", "form-label")
        layout.addWidget(label)

        form_data_widgets = self.forms_data_widgets[form_id]

        for field_sql_name, field in self.fields.items():
            form_data_widgets[field_sql_name] = FormRow(field.name, field.create_for_form_whole())
        
        if self.create_form_handler is not None:
            self.create_form_handler(form_data_widgets, self.fields, self.db)

        for field_sql_name, field_row in form_data_widgets.items():
            if field_sql_name in self.fields.keys():
                self.fields[field_sql_name].connect_on_change_handler(field_row.widget.field_widget)

            tooltip = field_row.widget.whole_widget.toolTip()
            if tooltip == "":
                tooltip = field_row.widget.field_widget.toolTip()

            layout.addRow(QLabel(field_row.name + ": ", toolTip=tooltip), field_row.widget.whole_widget)
            form_data_widgets[field_sql_name] = field_row

        for field_name, field_widget in self.forms_data_widgets[form_id].items():
            self.forms_data_widgets[form_id][field_name] = field_widget.widget
        # self.forms_data_widgets[form_id] = form_data_widgets = {k: v.widget for k, v in form_data_widgets.items()}

        for field in self.fields.values():
            field.form_widgets = form_data_widgets

        add_button = QPushButton("Добавить")
        add_button.setProperty("class", "add-button")
        add_button.clicked.connect(lambda: self.table.add_data(form_data_widgets, self.tables_widgets))
        layout.addWidget(add_button)

        self.forms_widgets[form_id].setLayout(layout)

        if not replace:
            self.forms_count += 1

        return self.forms_widgets[form_id]

    def set_before_save_handler(self, fn: BeforeSaveHandler):
        """
        Устанавливает обработчик события сохранения данных формы в таблицу,
        который вызывается перед добавлением новой или изменением старой записи
        Args:
            fn ((form_widgets, fields, db) -> tuple[ok, message]): Функция-обработчик события, где
                - form_widgets (dict[str, QWidget]): Словарь виджетов формы (ключи - sql_name'ы полей)
                - fields (dict[str, Field]): Словарь полей данной формы (ключи - sql_name'ы полей)
                - db (DataBase): База данных
                - ok (bool): True, если разрешается сохранение данных в БД
                - message (str): Сообщения для пользователя о том, почему данные были отклонены
        """

        self.before_save_handler = fn

    def app_add_tab(self, db: DataBase):
        super().app_add_tab(db)

        for field in self.fields.values():
            field.db = db
            field.fetch_data_from_db(self.sql_name)
        
        self.table = Table(self.name, self.sql_name, self.fields, self.db,
                           self.additional_columns, self.before_save_handler, self.after_save_handler,
                           self.create_form_handler, self.table_row_change_handler, None,
                           "" if self.unique is None else ",\n".join(map(lambda x: f"\tUNIQUE ({', '.join(x)})", self.unique)))

        self.db.cur.execute(self.table.create_SQL_request())
        self.db.conn.commit()

    def create_tab_widget(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        if len(self.description) > 0:
            label = QLabel(self.description)
            label.setWordWrap(True)
            layout.addWidget(label)

        table_top = QWidget()
        table_top_layout = QHBoxLayout()

        reload_btn = QPushButton("Обновить")
        reload_btn.setFixedWidth(75)
        reload_btn.clicked.connect(self.update_tab)
        table_top_layout.addWidget(reload_btn)

        table_top_layout.addStretch()

        self.search_line = QLineEdit()
        self.search_line.setFixedWidth(250)
        table_top_layout.addWidget(self.search_line)

        search_button = QPushButton("Поиск")
        search_button.setFixedWidth(75)
        search_button.clicked.connect(lambda t=self.tables_count: self.search_in_table(t))
        table_top_layout.addWidget(search_button)

        table_top.setLayout(table_top_layout)
        layout.addWidget(table_top)

        if not self.hide_form:
            tab_in_splitter = QSplitter()
            tab_in_splitter.setOrientation(Qt.Orientation.Vertical if self.form_under_table else Qt.Orientation.Horizontal)
            tab_in_splitter.addWidget(self.create_table())
            tab_in_splitter.addWidget(self.create_form())
            tab_in_splitter.setStretchFactor(0, 1)
            layout.addWidget(tab_in_splitter, stretch=1)
        else:
            layout.addWidget(self.create_table())

        tab.setLayout(layout)

        return tab

    def search_in_table(self, table_id: int):
        """
        Вызывается при нажатии кнопки "Поиск", фильтрует строки в таблице
        Args:
            table_id (int): Номер таблицы, по которой будет вестись поиск
        """

        search_text = self.search_line.text().strip().lower()
        for row in range(self.tables_widgets[table_id].rowCount()):
            show = False
            if search_text == "":
                show = True
            else:
                for column, field in enumerate(self.fields.values()):
                    if search_text in str(field.get_widget_text(self.tables_widgets[table_id].cellWidget(row, column+1))).lower():
                        show = True
                        break
            self.tables_widgets[table_id].setRowHidden(row, not show)

    def update_tab(self):
        """
        Вызывается при нажатии кнопки "Обновить", удаляет содержимое таблиц и форм и заполняет из заново
        """

        for field in self.fields.values():
            field.fetch_data_from_db(self.sql_name)

        for i in range(self.forms_count):
            self.create_table(True, i)
            self.create_form(True, i)
