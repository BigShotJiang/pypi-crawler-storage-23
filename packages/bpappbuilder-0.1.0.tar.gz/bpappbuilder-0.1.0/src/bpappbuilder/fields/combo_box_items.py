from ..app.db import DataBase

from abc import ABC, abstractmethod
from typing import Optional, Callable, Sequence, Any, Iterable


NameGenerator = Callable[[Sequence[Any]], str]

class StandardNameGenerators():
    def Id(data: dict[str, str]) -> str:
        return "#" + data["id"]
    def DateTime(data: dict[str, str]) -> str:
        return "от " + data["date"]
    def IdDateTime(data: dict[str, str]) -> str:
        return "#" + data["id"] + " от " + data["date"]

class ComboBoxItems(ABC):
    """
    Класс данных, из которых будут формироваться элементы выбора в ComboBoxField
    """

    @abstractmethod
    def get_items(self) -> dict[int, str]:
        """
        Получает списки с элементами для ComboBoxField
        Returns:
            dict Словарь, где ключи - данные элемента, которые будут сохранены в БД,
                а значения - отображаемый текст элемента
        """
        pass

class StaticItems(ComboBoxItems):
    """
    Статичный неизменяемый список элементов для ComboBox
    """

    def __init__(self, items: list[str]):
        """
        Args:
            items (list[str]): Список строк для элементов
        """

        self.items = items
    
    def get_items(self) -> dict[int, str]:
        return {i: value for i, value in enumerate(self.items)}

class TableFieldItems(ComboBoxItems):
    """
    Список элементов генерируется из конкретного поля одной из таблиц
    """

    def __init__(self, table_sql_name: str, field_sql_name: str, db: DataBase) -> dict[int, str]:
        """
        Args:
            table_sql_name (str): SQL название таблицы, из которой будут браться данные
            field_sql_name (str): SQL название поля, данные которого будут составлять элементы списка
            db (DataBase): База данных
        """

        self.table = table_sql_name
        self.field = field_sql_name
        self.db = db
    
    def get_items(self) -> tuple[list[int], list[str]]:
        result = self.db.cur.execute(f"SELECT id, {self.field} FROM {self.table}").fetchall()
        return {int(x["id"]): x[self.field] for x in result}

class TableItems(ComboBoxItems):
    """
    Список элементов формируется по названиям строк определённой таблицы
    """

    def __init__(self, table_sql_name: str, db: DataBase, name_generator: NameGenerator, columns: Optional[Iterable[str]] = None):
        """
        Args:
            table_sql_name (str): SQL название таблицы, из которой будут браться данные
            db (DataBase): база данных
            name_generator ((row_data) -> row_name): Функция создания названия строки таблицы, в которой:
                - row_data (Sequence[Any]): Данные из строки таблицы в виде массива пар ключ-значения (ключи - названия полей)
                - row_name (str): Название строки таблицы, которое будет добавлено в список элементов
            columns (list[str], optional): Список SQL названий столбцов, которые будут получены из БД; если не указано,
                будут извлекаться все столбцы
        """

        self.table = table_sql_name
        self.name_generator = name_generator
        self.columns = columns
        self.db = db
    
    def get_items(self) -> dict[int, str]:
        result = self.db.cur.execute(f"SELECT {'*' if self.columns is None else ', '.join(self.columns)} FROM {self.table}").fetchall()
        return {int(x["id"]): self.name_generator(x) for x in result}
