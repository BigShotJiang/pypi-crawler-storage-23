from PySide6.QtWidgets import (QWidget, QCheckBox, QSpinBox, QDoubleSpinBox, QLabel, QLineEdit,
                             QTextEdit, QComboBox, QDateTimeEdit, QDateEdit, QTimeEdit,
                             QTableWidget, QPushButton, QDialog, QFormLayout, QMessageBox,
                             QDialogButtonBox, QFileDialog, QVBoxLayout, QHBoxLayout)
from PySide6.QtCore import Qt, QDateTime, QDate, QTime
from PySide6.QtGui import QKeyEvent

from .combo_box_items import ComboBoxItems, StaticItems
from ..app.db import DataBase
from ..app.themes import apply_styles
from ..tabs.table import (Table, FormFieldWidget, TableColumn, FormRow,
                          BeforeSaveHandler, AfterSaveHandler, CreateFormHandler,
                          TableRowChangeHandler)

from abc import ABC, abstractmethod
from typing import Any, Union, Optional, Callable
import os


OnChangeHandler = Callable[[Any, dict[str, FormFieldWidget], dict[str, Any], DataBase], None]

class Field(ABC):
    """
    Поле для формы, столбец для таблицы с данными
    """

    sql_type: str  # Тип поля в SQLite таблице в БД

    def __init__(self, name: str, sql_name: str, tooltip: Optional[str] = None, column_width: Optional[int] = None, const: bool = False, primary_key: bool = False,
                 unique: bool = False, autoincrement: bool = False, not_null: bool = False, default: Optional[Any] = None,
                 on_change_handler: Optional[OnChangeHandler] = None, is_optional: bool = False):
        """
        Args:
            name (str): Название параметра, отображается в форме и таблице
            sql_name (str): Имя столбца в SQL таблице
            tooltip (str, optional): Текст подсказки, который будет показываться при наведении мышки на виджет в форме
            column_width (int, optional): Ширина столбца в таблице
            const (bool, optional): Неизменяемость поля в форме
            primary_key (bool, optional): Является ли столбец первичным ключом в SQL таблице
            unique (bool, optional): Должен ли столбец быть уникальным в SQL таблице
            autoincrement (bool, optional): Параметр автоинкремента для SQL таблицы
            not_null (bool, optional): Параметр NOT NULL для столбца в SQL таблице
            default (Any, optional): Значение по-умолчанию для столбца в SQL таблице
            on_change_handler ((data, form_widgets, fields, db) -> tuple[ok, message]): функция-обработчик события изменения данных в виджете формы
                - data (Any): Данные виджета после изменения
                - form_widgets (dict[str, FormFieldWidget]): Словарь виджетов формы (ключи - sql_name'ы полей)
                - fields (dict[str, Field]): Словарь полей данной формы (ключи - sql_name'ы полей)
                - db (DataBase): База данных
            is_optional (bool, optional): Если True, у поля будет галочка и можно будет не устанавливать значение полю. По умолчанию False
        """

        self.name = name
        self.sql_name = sql_name
        self.tooltip = tooltip
        self.column_width = column_width
        self.const = const
        self.primary_key = primary_key
        self.unique = unique
        self.autoincrement = autoincrement
        self.not_null = not_null
        self.default = default
        self.optional = is_optional

        self.db: Union[DataBase, None] = None
        self.form_widgets: Union[dict[str, FormFieldWidget], None] = None
        self.table_fields: Union[dict[str, Field], None] = None

        self.on_change: Union[Callable[[Any], None], None] = None
        if on_change_handler is not None:
            self.set_on_change_handler(on_change_handler)
    
    @abstractmethod
    def create_for_form(self, data: Optional[str] = None) -> QWidget:
        """
        Создание PyQt объекта для формы
        Args:
            data (str, optional): Данные, которые должны быть в виджете
        Returns:
            QWidget: Виджет, который будет находится в форме
        """
        pass
    
    def create_for_form_tooltips(self, data: Optional[str] = None) -> QWidget:
        """
        Создание виджета для формы и добавление к нему и подсказки tooltip
        Args:
            data (str, optional): Данные, которые должны быть в виджете
        Returns:
            QWidget: Виджет, который будет находится в форме
        """

        widget = self.create_for_form(data)
        if self.tooltip is not None:
            widget.setToolTip(self.tooltip)
        
        return widget
    
    def create_for_form_whole(self, data: Optional[str] = None) -> FormFieldWidget:
        """
        Создание виджета для формы и добавление к нему чекбокса и подсказки tooltip
        Args:
            data (str, optional): Данные, которые должны быть в виджете
        Returns:
            QWidget: Полный виджет, который будет находится в форме (вместе с галочкой для optional полей)
        """

        field_widget = self.create_for_form(data)
        if self.tooltip is not None:
            field_widget.setToolTip(self.tooltip)

        if self.optional:
            field_widget.setEnabled(data is not None)

            check_widget = QCheckBox()
            check_widget.setChecked(data is not None)
            check_widget.checkStateChanged.connect(lambda state, w=field_widget: w.setEnabled(not w.isEnabled()))

            widget = QWidget()
            widget_layout = QHBoxLayout()
            widget_layout.setContentsMargins(0, 0, 0, 0)
            widget_layout.addWidget(check_widget)
            widget_layout.addWidget(field_widget, stretch=1)
            widget.setLayout(widget_layout)

            return FormFieldWidget(widget, field_widget, check_widget, lambda w=check_widget: w.isChecked())
        else:
            return FormFieldWidget(field_widget)

    @abstractmethod
    def create_for_table(self, data: Optional[str]) -> QWidget:
        """
        Создание неизменяемого PyQt объекта для таблицы
        Args:
            data (str): Данные, которые должны быть помещены в ячейку
        Returns:
            QWidget: Виджет, который будет находится в соответствующей ячейке таблицы (он должен быть только для чтения)
        """
        pass
    
    @abstractmethod
    def change_widget_data(self, widget: QWidget, data: Optional[str]):
        """
        Изменяет данные в виджете из таблицы
        Args:
            widget (QWidget): Виджет из ячейки таблицы, в котором надо изменить данные
            data (str): Новые данные для виджета
        """
        pass

    @abstractmethod
    def get_widget_data(self, widget: QWidget, form: bool) -> Union[str, None]:
        """
        Возвращает данные из виджета в виде строки
        Args:
            widget (QWidget): Виджет, из которого берутся данные
            form (bool): Взят ли виджет из формы; из формы - True, из таблицы - False
        Returns:
            str: Данные из виджета
        """
        pass

    @abstractmethod
    def check_widget(self, widget: QWidget, form: bool) -> tuple[bool, str]:
        """
        Проверяет данные виджета из формы, то есть можно ли их добавить в БД
        Args:
            widget (QWidget): Виджет для проверки
            form (bool): Взят ли виджет из формы; из формы - True, из таблицы - False
        Returns:
            tuple: Кортеж из (ok, message)
            - ok (bool): True, если данные нормальные
            - message (str): Сообщение для пользователя, говорящее о том, что не так с данными
        """
        pass

    def set_on_change_handler(self, fn: OnChangeHandler):
        """
        Изменяет обработчик сигнала изменения данных в виджете из формы
        Args:
            fn ((data, form_widgets, fields, db) -> tuple[ok, message]): функция-обработчик, где
                - data (Any): Данные виджета после изменения
                - form_widgets (dict[str, QWidget]): Словарь виджетов формы (ключи - sql_name'ы полей)
                - fields (dict[str, Field]): Словарь полей данных формы (ключи - sql_name'ы полей)
                - db (DataBase): База данных
        """
        self.on_change = lambda data: fn(data, self.form_widgets, self.table_fields, self.db)

    def connect_on_change_handler(self, widget: QWidget):
        """
        Подключение обработчика обновления сигнала данных к виджету.
        При этом в методе create_for_form не надо подключать обработчик,
        это должно быть сделано только в данном методе
        """
        pass

    def fetch_data_from_db(self, parent_table_sql_name: str):
        """
        Получение данных из БД; вызывается при подключении БД к полю и при обновлении вкладки
        Args:
            parent_table_sql_name (str): SQL название родительской таблицы
        """
        pass

    def add_to_db(self, widget: FormFieldWidget, form_data: dict[str, str], parent_table_sql_name: str):
        """
        Вызывается после добавления данных из формы в БД
        Args:
            widget (FormFieldWidget): Виджет из формы добавления данных
            form_data (dict[str, str]): Словарь данных формы (ключи - sql_name'ы полей)
            parent_table_sql_name (str): SQL название таблицы, в которую добавляются данные
        """
        pass

    def get_widget_text(self, widget: QWidget) -> str:
        """
        Возвращает текст с виджета таблицы
        Args:
            widget (QWidget): Виджет, из которого надо взять текст
        Returns:
            str: Отображаемый на виджете текст
        """
        
        return str(widget.text())

class DataLabel(QLabel):
    def __init__(self, text: str, data: Any):
        super().__init__(text)
        self.field_data = data

class DataCheckBox(QCheckBox):
    def __init__(self, data: Any):
        super().__init__()
        self.field_data = data

class DataWidget(QWidget):
    def __init__(self, data: Any):
        super().__init__()
        self.field_data = data

class CheckField(Field):
    """
    Поле галочки, может быть включено или выключено
    - Таблица: QCheckBox
    - Форма: QCheckBox
    - - Получить данные виджета: widget.isChecked()
    - - Первый аргумент обработчика on_change: Qt.CheckState
    """

    sql_type = "INTEGER"

    def __init__(self, name: str, sql_name: str, tooltip: Optional[str] = None, column_width: Optional[int] = None, const: bool = False,
                 primary_key: bool = False, unique: bool = False, default: bool = False,
                 on_change_handler: Optional[OnChangeHandler] = None, is_optional: bool = False):
        super().__init__(name, sql_name, tooltip, column_width, const, primary_key, unique, False, False, str(int(default)), on_change_handler)
    
    def create_for_form(self, data: Optional[str] = None) -> QCheckBox:
        widget = QCheckBox()
        if self.default is not None and data is None:
            widget.setChecked(bool(int(self.default)))
        if data is not None:
            widget.setChecked(bool(int(data)))
        if self.const:
            widget.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        
        return widget

    def connect_on_change_handler(self, widget: QCheckBox):
        if self.on_change is not None:
            widget.stateChanged.connect(self.on_change)

    def create_for_table(self, data: Optional[str]) -> DataCheckBox:
        widget = DataCheckBox(data)
        widget.setChecked(bool(int(data)) if data is not None else 0)
        widget.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        return widget

    def change_widget_data(self, widget: DataCheckBox, data: Optional[str]):
        widget.setChecked(bool(int(data)))
        widget.field_data = data

    def get_widget_data(self, widget: Union[QCheckBox, DataCheckBox], form: bool) -> Optional[str]:
        if form:
            return str(int(widget.isChecked()))
        else:
            return widget.field_data

    def get_widget_text(self, widget: QCheckBox) -> str:
        return "Да" if widget.isChecked() else "Нет"

    def check_widget(self, widget: QCheckBox, form: bool) -> tuple[bool, str]:
        return True, ""

class IntField(Field):
    """
    Поле целочисленного значения
    - Таблица: QLabel
    - Форма: QSpinBox
    - - Получить данные виджета: widget.value()
    - - Первый аргумент обработчика on_change: int
    """

    sql_type = "INTEGER"

    def __init__(self, name: str, sql_name: str, min_value: int = 0, max_value: int = 100,
                 tooltip: Optional[str] = None, column_width: Optional[int] = None, const: bool = False,
                 primary_key: bool = False, unique: bool = False, autoincrement: bool = False, not_null: bool = False,
                 default: Optional[int] = None, on_change_handler: Optional[OnChangeHandler] = None, is_optional: bool = False):
        """
        Args:
            min_value (int, optional): Минимальное значение, которое может принимать поле.
                Оно будет значением по умолчанию для поля, если не будет указан аргумент default.
                По умолчанию 0.
            max_value (int, optional): Максимальное значение, которое может принимать поле. По умолчанию 100.
        """
        
        super().__init__(name, sql_name, tooltip, column_width, const, primary_key, unique, autoincrement, not_null,
                         str(default if default is not None else min_value), on_change_handler, is_optional)
        self.min_value = min_value
        self.max_value = max_value

    def create_for_form(self, data: Optional[str] = None) -> QSpinBox:
        widget = QSpinBox()
        widget.setMinimum(self.min_value)
        widget.setMaximum(self.max_value)
        widget.setValue(int(data) if data is not None else int(self.default))
        widget.setReadOnly(self.const)

        return widget

    def connect_on_change_handler(self, widget: QSpinBox):
        if self.on_change is not None:
            widget.valueChanged.connect(self.on_change)

    def create_for_table(self, data: Optional[str]) -> DataLabel:
        return DataLabel(data if data is not None else "", data)

    def change_widget_data(self, widget: DataLabel, data: Optional[str]):
        widget.setText(data)
        widget.field_data = data

    def get_widget_data(self, widget: Union[QSpinBox, DataLabel], form: bool) -> Union[str, None]:
        if form:
            return str(widget.value())
        else:
            return widget.field_data

    def check_widget(self, widget: Union[QSpinBox, DataLabel], form: bool) -> tuple[bool, str]:
        if form:
            value = widget.value()

            if value > self.max_value:
                return False, f"Данные поля превышают максимальное допустимое значение {self.max_value}"
            if value < self.min_value:
                return False, f"Данные поля меньше допустимого минимального значения {self.min_value}"
            
        return True, ""

class FloatField(Field):
    """
    Поле числа с плавающей запятой
    - Таблица: QLabel
    - Форма: QDoubleSpinBox
    - - Получить данные виджета: widget.value()
    - - Первый аргумент обработчика on_change: float
    """

    sql_type = "REAL"

    def __init__(self, name: str, sql_name: str, min_value: float = 0.0, max_value: float = 100.0,
                 accuracy: Optional[int] = None, tooltip: Optional[str] = None, column_width: Optional[float] = None,
                 const: bool = False, primary_key: bool = False, unique: bool = False, not_null: bool = False,
                 default: Optional[float] = None, on_change_handler: Optional[OnChangeHandler] = None, is_optional: bool = False):
        """
        Args:
            min_value (int, optional): Минимальное значение, которое может принимать поле.
                Оно будет значением по умолчанию для поля, если не будет указан аргумент default.
                По умолчанию 0
            max_value (int, optional): Максимальное значение, которое может принимать поле. По умолчанию 100
            accuracy (int): Количество цифр после запятой
        """
        super().__init__(name, sql_name, tooltip, column_width, const, primary_key, unique, False, not_null,
                         str(default if default is not None else min_value), on_change_handler, is_optional)
        self.min_value = min_value
        self.max_value = max_value
        self.accuracy = accuracy
    
    def create_for_form(self, data: Optional[str] = None) -> QDoubleSpinBox:
        widget = QDoubleSpinBox()
        widget.setMinimum(self.min_value)
        widget.setMaximum(self.max_value)
        if self.accuracy is not None:
            widget.setDecimals(self.accuracy)
        widget.setValue(float(data) if data is not None else float(self.default))
        widget.setReadOnly(self.const)

        return widget

    def connect_on_change_handler(self, widget: QDoubleSpinBox):
        if self.on_change is not None:
            widget.valueChanged.connect(self.on_change)

    def create_for_table(self, data: Optional[str]) -> DataLabel:
        return DataLabel(data if data is not None else "", data)

    def change_widget_data(self, widget: DataLabel, data: Optional[str]):
        widget.setText(data)
        widget.field_data = data

    def get_widget_data(self, widget: Union[QSpinBox, DataLabel], form: bool) -> Union[str, None]:
        if form:
            return str(widget.value())
        else:
            return widget.field_data

    def check_widget(self, widget: Union[QDoubleSpinBox, DataLabel], form: bool) -> tuple[bool, str]:
        if form:
            value = widget.value()

            if value > self.max_value:
                return False, f"Данные поля превышают максимальное допустимое значение {self.max_value}"
            if value < self.min_value:
                return False, f"Данные поля меньше допустимого минимального значения {self.min_value}"
        
        return True, ""

class TextLineField(Field):
    """
    Строка ввода
    - Таблица: QLabel
    - Форма: QLineEdit
    - - Получить данные виджета: widget.text()
    - - Первый аргумент обработчика on_change: None
    """

    sql_type = "TEXT"

    def __init__(self, name: str, sql_name: str, max_len: Optional[int] = None, placeholder: Optional[str] = None,
                 tooltip: Optional[str] = None, column_width: Optional[int] = None, const: bool = False,
                 primary_key: bool = False, unique: bool = False, not_null: bool = False, default: str = "",
                 on_change_handler: Optional[OnChangeHandler] = None, is_optional: bool = False):
        super().__init__(name, sql_name, tooltip, column_width, const, primary_key, unique, False, not_null, default, on_change_handler, is_optional)
        self.max_len = max_len
        self.placeholder = placeholder
    
    def create_for_form(self, data: Optional[str] = None) -> QLineEdit:
        widget = QLineEdit()
        if self.placeholder is not None:
            widget.setPlaceholderText(self.placeholder)
        if self.max_len is not None:
            widget.setMaxLength(self.max_len)
        widget.setText(data if data is not None else self.default)

        widget.setReadOnly(self.const)

        return widget
    
    def connect_on_change_handler(self, widget: QLineEdit):
        if self.on_change is not None:
            widget.editingFinished.connect(lambda: self.on_change(None))

    def create_for_table(self, data: Optional[str]) -> DataLabel:
        return DataLabel(data if data is not None else "", data)

    def change_widget_data(self, widget: DataLabel, data: Optional[str]):
        widget.setText(data)
        widget.field_data = data
    
    def get_widget_data(self, widget: Union[QLineEdit, DataLabel], form: bool) -> Union[str, None]:
        if form:
            return widget.text()
        else:
            return widget.field_data
    
    def check_widget(self, widget: Union[QLineEdit, DataLabel], form: bool) -> tuple[bool, str]:
        if self.not_null and len(widget.text()) == 0:
            return False, "Поле не может быть пустым"
        else:
            return True, ""

class TextAreaField(Field):
    """
    Поле многострочного ввода
    - Таблица: QLabel
    - Форма: QTextEdit
    - - Получить данные виджета: widget.toPlainText()
    - - Первый аргумент обработчика on_change: None
    """

    sql_type = "TEXT"

    def __init__(self, name: str, sql_name: str, placeholder: Optional[str] = None, tooltip: Optional[str] = None,
                 column_width: Optional[int] = None, const: bool = False, primary_key: bool = False, unique: bool = False,
                 not_null: bool = False, default: str = "", on_change_handler: Optional[OnChangeHandler] = None,
                 is_optional: bool = False):
        super().__init__(name, sql_name, tooltip, column_width, const, primary_key, unique, False, not_null, default, on_change_handler, is_optional)
        self.placeholder = placeholder
    
    def create_for_form(self, data: Optional[str] = None) -> QTextEdit:
        widget = QTextEdit()
        if self.placeholder is not None:
            widget.setPlaceholderText(self.placeholder)
        widget.setText(data if data is not None else self.default)
        widget.setReadOnly(self.const)
        
        return widget
    
    def connect_on_change_handler(self, widget: QTextEdit):
        if self.on_change is not None:
            widget.textChanged.connect(lambda: self.on_change(None))

    def create_for_table(self, data: Optional[str]) -> DataLabel:
        return DataLabel(data if data is not None else "", data)

    def change_widget_data(self, widget: DataLabel, data: Optional[str]):
        widget.setText(data)
        widget.field_data = data
    
    def get_widget_data(self, widget: Union[QTextEdit, DataLabel], form: bool) -> str:
        if form:
            return widget.toPlainText()
        else:
            return widget.field_data
    
    def check_widget(self, widget: Union[QTextEdit, DataLabel], form: bool) -> tuple[bool, str]:
        if self.not_null and len(widget.text()) == 0:
            return False, "Поле не может быть пустым"
        else:
            return True, ""

class ComboBoxField(Field):
    """
    Поле со списком для выбора значения; список может быть статичным с постоянными значениями,
    так и как имена строк или столбец других строк

    - Таблица: DataLabel(QLabel)
    - Форма: QComboBox
    - - Получить данные виджета (id выбранного элемента): widget.currentData()
    - - Первый аргумент обработчика on_change: None
    """

    sql_type = "INTEGER"

    def __init__(self, name: str, sql_name: str, items: ComboBoxItems, table_sql_name: Optional[str] = None,
                 tooltip: Optional[str] = None, column_width: Optional[int] = None, const: bool = False,
                 primary_key: bool = False, unique: bool = False, not_null: bool = False, default: Optional[int] = None,
                 on_change_handler: Optional[OnChangeHandler] = None, is_optional: bool = False):
        """
        Args:
            table_sql_name (str, optional): SQL название таблицы, в которой будет поле; нужно
                для обновления данных в БД, если у списка элементов есть привязка к другой таблице
            not_null (bool, optional): Удалять всю строку из таблицы, если значение виджета становится равным NULL,
                то есть если будет удалена строка из другой таблицы, к которой была привязка элементов. По умолчанию False
        """

        super().__init__(name, sql_name, tooltip, column_width, const, primary_key, unique, False, not_null,
                         str(default) if default is not None else None, on_change_handler, is_optional)
        self.table_sql_name = table_sql_name

        self.items = items

        self.items_data: dict[int, str] = {}
        self.items_data_keys: list[int] = []
        self.static_items_created = False

    def create_for_form(self, data: Optional[str] = None) -> QComboBox:
        widget = QComboBox()

        for i, key_value in enumerate(self.items_data.items()):
            widget.addItem(key_value[1], key_value[0])
            widget.model().item(i).setEnabled(not self.const)
        if data is not None:
            if int(data) in self.items_data_keys:
                widget.setCurrentIndex(self.items_data_keys.index(int(data)))
            else:
                widget.setCurrentText("")
                widget.setCurrentIndex(-1)
        elif self.default is not None and self.default != "None":
            widget.setCurrentIndex(self.items_data_keys.index(int(self.default)))
        else:
            widget.setCurrentIndex(-1)

        return widget
    
    def connect_on_change_handler(self, widget: QComboBox):
        if self.on_change is not None:
            widget.currentIndexChanged.connect(lambda idx: self.on_change(widget.itemData(idx)))

    def create_for_table(self, data: Optional[str]) -> DataLabel:
        if data != "None" and data is not None and int(data) in self.items_data_keys:
            return DataLabel(self.items_data[int(data)], int(data))
        else:
            if (self.items.__class__ != StaticItems) and (self.table_sql_name is not None) and (data != "None" and data is not None):
                db: DataBase = self.items.db
                if self.not_null:
                    db.cur.execute(f"DELETE FROM {self.table_sql_name} WHERE {self.sql_name} = ?", (data,))
                else:
                    db.cur.execute(f"UPDATE {self.table_sql_name} SET {self.sql_name} = NULL WHERE {self.sql_name} = ?", (data, ))
                db.conn.commit()

            return DataLabel("", -1 if data is not None else None)

    def change_widget_data(self, widget: DataLabel, data: Optional[str]):
        if data is not None and int(data) in self.items_data_keys: 
            widget.setText(self.items_data[int(data)])
            widget.field_data = int(data)
        else:
            widget.setText("")
            widget.field_data = -1 if data is not None else None
    
    def get_widget_data(self, widget: Union[QComboBox, DataLabel], form: bool) -> Union[str, None]:
        if form:
            return str(widget.currentData())
        else:
            return str(widget.field_data) if widget.field_data is not None else None
    
    def get_widget_text(self, widget: DataLabel) -> str:
        if widget.field_data is not None and int(widget.field_data) in self.items_data_keys:
            return str(widget.text())

    def check_widget(self, widget: Union[QComboBox, DataLabel], form: bool) -> tuple[bool, str]:
        if form:
            if self.not_null and widget.currentIndex() == -1:
                return False, "Вы не выбрали ни один элемент"
            else:
                return True, ""
        else:
            return widget.field_data in self.items_data_keys, ""

    def fetch_data_from_db(self, parent_table_sql_name: str):
        if self.items.__class__ != StaticItems or not self.static_items_created:
            self.items_data = self.items.get_items()
            self.items_data_keys = list(self.items_data.keys())
        self.static_items_created = True

class DateTimeField(Field):
    """
    Поле с датой временем
    - Таблица: QLabel
    - Форма: QDateTimeEdit
    - - Получить данные виджета: widget.dateTime()
    - - Первый аргумент обработчика on_change: QDateTime
    """

    sql_type = "TEXT"
    date_format = "yyyy-MM-dd"
    time_format = "hh:mm:ss"
    datetime_format = date_format + " " + time_format

    def __init__(self, name: str, sql_name: str, min_date: Optional[Union[str, QDate]] = None, max_date: Optional[Union[str, QDate]] = None,
                 min_time: Optional[Union[str, QTime]] = None, max_time: Optional[Union[str, QTime]] = None,
                 only_current: bool = False, tooltip: Optional[str] = None, column_width: Optional[int] = None,
                 const: bool = False, primary_key: bool = False, unique: bool = False, not_null: bool = False,
                 default: Union[str, QDateTime] = "", on_change_handler: Optional[OnChangeHandler] = None,
                 is_optional: bool = False):
        """
        Args:
            min_date (str | QDate, optional): Минимальная дата (формат строки в DateTimeField.date_format)
            max_date (str | QDate, optional): Максимальная дата (формат строки в DateTimeField.date_format)
            min_time (str | QTime, optional): Минимальное время (формат строки в DateTimeField.time_format)
            max_time (str | QTime, optional): Максимальное время (формат строки в DateTimeField.time_format)
            only_current (bool, optional): Если True, при записи в поле будут текущая дата и время,
                а редактирование будет запрещено. По умолчанию False
        """

        super().__init__(name, sql_name, tooltip, column_width, const, primary_key, unique, False, not_null, 
                         default if default.__class__ == str else QDateTime.toString(default, self.datetime_format), on_change_handler, is_optional)
        self.min_date = min_date
        self.max_date = max_date
        self.min_time = min_time
        self.max_time = max_time
        self.only_current = only_current
        self.datetime_default: QDateTime = default if default.__class__ == QDateTime else QDateTime.fromString(default, self.datetime_format)
    
    def create_for_form(self, data: Optional[str] = None) -> Union[QDateTimeEdit, QLabel]:
        if data is None and self.only_current:
            return QLabel("<i>Текущая дата и время</i>")

        widget = QDateTimeEdit(calendarPopup=True)
        widget.setDisplayFormat(self.datetime_format)
        widget.setReadOnly(self.const or self.only_current)

        if self.min_date is not None:
            widget.setMinimumDate(self.min_date if self.min_date.__class__ == QDate else 
                                  (QDate.currentDate() if self.min_date == "now" else QDate.fromString(self.min_date, self.date_format)))
        if self.max_date is not None:
            widget.setMaximumDate(self.max_date if self.max_date.__class__ == QDate else 
                                  (QDate.currentDate() if self.max_date == "now" else QDate.fromString(self.max_date, self.date_format)))
        if self.min_time is not None:
            widget.setMinimumTime(self.min_time if self.min_time.__class__ == QTime else 
                                  (QTime.currentTime() if self.min_time == "now" else QTime.fromString(self.min_time, self.time_format)))
        if self.max_time is not None:
            widget.setMaximumTime(self.max_time if self.max_time.__class__ == QTime else 
                                  (QTime.currentTime() if self.max_time == "now" else QTime.fromString(self.max_time, self.time_format)))

        if data is not None:
            widget.setDateTime(QDateTime.fromString(data, self.datetime_format))
        else:
            if self.default == "now":
                widget.setDateTime(QDateTime.currentDateTime())
            else:
                widget.setDateTime(self.datetime_default)

        if self.on_change is not None:
            widget.dateTimeChanged.connect(self.on_change)
        
        return widget
    
    def connect_on_change_handler(self, widget: Union[QDateTimeEdit, QLabel]):
        if widget.__class__ == QDateTimeEdit and self.on_change is not None:
            widget.dateTimeChanged.connect(self.on_change)
    
    def create_for_table(self, data: Optional[str]) -> DataLabel:
        return DataLabel(data if data is not None else "", data)

    def change_widget_data(self, widget: DataLabel, data: Optional[str]):
        widget.setText(data)
        widget.field_data = data
    
    def get_widget_data(self, widget: Union[QDateTimeEdit, DataLabel, QLabel], form: bool) -> Union[str, None]:
        if form:
            if widget.__class__ == QLabel:
                return QDateTime.toString(QDateTime.currentDateTime(), self.datetime_format)
            else:
                return QDateTime.toString(widget.dateTime(), self.datetime_format)
        else:
            return widget.field_data
    
    def check_widget(self, widget: Union[QDateTimeEdit, DataLabel, QLabel], form: bool) -> tuple[bool, str]:
        return True, ""
    
class DateField(Field):
    """
    Поле с временем
    - Таблица: QLabel
    - Форма: QDateEdit
    - - Получить данные виджета: widget.date()
    - - Первый аргумент обработчика on_change: QDate
    """

    sql_type = "TEXT"
    date_format = "yyyy-MM-dd"

    def __init__(self, name: str, sql_name: str, min_date: Optional[Union[str, QDate]] = None, max_date: Optional[Union[str, QDate]] = None,
                 only_current: bool = False, tooltip: Optional[str] = None, column_width: Optional[int] = None, const: bool = False,
                 primary_key: bool = False, unique: bool = False, not_null: bool = False, default: Union[str, QDate] = "",
                 on_change_handler: Optional[OnChangeHandler] = None, is_optional: bool = False):
        """
        Args:
            min_date (str | QDate, optional): Минимальная дата (формат строки в DateField.date_format)
            max_date (str | QDate, optional): Максимальная дата (формат строки в DateField.date_format)
        """

        super().__init__(name, sql_name, tooltip, column_width, const, primary_key, unique, False, not_null, 
                         default if default.__class__ == str else QDate.toString(default, self.date_format), on_change_handler, is_optional)
        self.min_date = min_date
        self.max_date = max_date
        self.only_current = only_current
        self.date_default: QDate = default if default.__class__ == QDate else QDate.fromString(default, self.date_format)
    
    def create_for_form(self, data: Optional[str] = None) -> Union[QDateEdit, QLabel]:
        if data is None and self.only_current:
            return QLabel("<i>Текущая дата</i>")
        
        widget = QDateEdit(calendarPopup=True)
        widget.setDisplayFormat(self.date_format)
        widget.setReadOnly(self.const or self.only_current)

        if self.min_date is not None:
            widget.setMinimumDate(self.min_date if self.min_date.__class__ == QDate else 
                                  (QDate.currentDate() if self.min_date == "now" else QDate.fromString(self.min_date, self.date_format)))
        if self.max_date is not None:
            widget.setMaximumDate(self.max_date if self.max_date.__class__ == QDate else 
                                  (QDate.currentDate() if self.max_date == "now" else QDate.fromString(self.max_date, self.date_format)))

        if data is not None:
            widget.setDate(QDate.fromString(data, self.date_format))
        else:
            if self.default == "now":
                widget.setDate(QDate.currentDate())
            else:
                widget.setDate(self.date_default)
        
        return widget
    
    def connect_on_change_handler(self, widget: Union[QDateEdit, QLabel]):
        if widget.__class__ == QDateEdit and self.on_change is not None:
            widget.dateChanged.connect(self.on_change)

    def create_for_table(self, data: Optional[str]) -> DataLabel:
        return DataLabel(data if data is not None else "", data)

    def change_widget_data(self, widget: DataLabel, data: Optional[str]):
        widget.setText(data)
        widget.field_data = data
    
    def get_widget_data(self, widget: Union[QDateEdit, DataLabel, QLabel], form: bool) -> Union[str, None]:
        if form:
            if widget.__class__ == QLabel:
                return QDate.toString(QDate.currentDate(), self.date_format)
            else:
                return QDate.toString(widget.date(), self.date_format)
        else:
            return widget.field_data
    
    def check_widget(self, widget: Union[QDateEdit, DataLabel, QLabel], form: bool) -> tuple[bool, str]:
        return True, ""

class TimeField(Field):
    """
    Поле с датой временем
    - Таблица: QLabel
    - Форма: QTimeEdit
    - - Получить данные виджета: widget.time()
    - - Первый аргумент обработчика on_change: QTime
    """

    sql_type = "TEXT"
    time_format = "hh:mm:ss"

    def __init__(self, name: str, sql_name: str, min_time: Optional[Union[str, QTime]] = None, max_time: Optional[Union[str, QTime]] = None,
                 only_current: bool = False, tooltip: Optional[str] = None, column_width: Optional[int] = None, const: bool = False,
                 primary_key: bool = False, unique: bool = False, not_null: bool = False, default: Union[str, QTime] = "",
                 on_change_handler: Optional[OnChangeHandler] = None, is_optional: bool = False):
        """
        Args:
            min_time (str | QTime, optional): Минимальное время (формат строки в TimeField.time_format)
            max_time (str | QTime, optional): Максимальное время (формат строки в TimeField.time_format)
        """

        super().__init__(name, sql_name, tooltip, column_width, const, primary_key, unique, False, not_null, 
                         default if default.__class__ == str else QTime.toString(default, self.time_format), on_change_handler, is_optional)
        self.min_time = min_time
        self.max_time = max_time
        self.only_current = only_current
        self.time_default: QTime = default if default.__class__ == QTime else QTime.fromString(default, self.time_format)
    
    def create_for_form(self, data: Optional[str] = None) -> Union[QTimeEdit, QLabel]:
        if data is None and self.only_current:
            return QLabel("<i>Текущее время</i>")
        
        widget = QTimeEdit()
        widget.setDisplayFormat(self.time_format)
        widget.setReadOnly(self.const or self.only_current)

        if self.min_time is not None:
            widget.setMinimumTime(self.min_time if self.min_time.__class__ == QTime else 
                                  (QTime.currentTime() if self.min_time == "now" else QTime.fromString(self.min_time, self.time_format)))
        if self.max_time is not None:
            widget.setMaximumTime(self.max_time if self.max_time.__class__ == QTime else 
                                  (QTime.currentTime() if self.max_time == "now" else QTime.fromString(self.max_time, self.time_format)))

        if data is not None:
            widget.setTime(QTime.fromString(data, self.time_format))
        else:
            if self.default == "now":
                widget.setTime(QTime.currentTime())
            else:
                widget.setTime(self.time_default)
        
        return widget
    
    def connect_on_change_handler(self, widget: Union[QTimeEdit, QLabel]):
        if widget.__class__ == QTimeEdit and self.on_change is not None:
            widget.timeChanged.connect(self.on_change)
    
    def create_for_table(self, data: Optional[str]) -> DataLabel:
        return DataLabel(data if data is not None else "", data)

    def change_widget_data(self, widget: DataLabel, data: Optional[str]):
        widget.setText(data)
        widget.field_data = data
    
    def get_widget_data(self, widget: Union[QTimeEdit, DataLabel, QLabel], form: bool) -> Union[str, None]:
        if form:
            if widget.__class__ == QLabel:
                return QTime.toString(QTime.currentTime(), self.time_format)
            else:
                return QTime.toString(widget.time(), self.time_format)
        else:
            return widget.field_data
    
    def check_widget(self, widget: Union[QTimeEdit, DataLabel, QLabel], form: bool) -> tuple[bool, str]:
        return True, ""

class FileSelectWidget(QWidget):
    def __init__(self, file: str = "", file_types: str = ""):
        super().__init__()
        self.file_types = file_types

        self.setContentsMargins(0, 0, 0, 0)

        layout = QHBoxLayout()

        self.line = QLineEdit()
        self.line.setText(file)
        self.line.setToolTip(file)
        layout.addWidget(self.line)

        self.open = QPushButton("Открыть")
        self.open.setFixedSize(65, 25)
        self.open.clicked.connect(self.open_btn_clicked)
        layout.addWidget(self.open)

        self.setLayout(layout)
    
    def open_btn_clicked(self):
        current_file = self.line.text()
        filename, ok = QFileDialog.getOpenFileName(
            self,
            "Выберите файл",
            current_file[:current_file.rindex("/")+1] if "/" in current_file else "",
            self.file_types
        )
        if ok:
            self.line.setToolTip(filename)
            self.line.setText(filename)

class FileField(Field):
    """
    Поле выбора файла
    - Таблица: QLabel
    - Форма: FileSelectWidget
    - - Получить данные виджета: widget.line.text()
    - - Первый аргумент обработчика on_change: None
    """

    sql_type = "TEXT"

    def __init__(self, name: str, sql_name: str, file_types: str = "", tooltip: Optional[str] = None, column_width: Optional[int] = None,
                 const: bool = False, primary_key: bool = False, unique: bool = False, not_null: bool = False,
                 default: Optional[str] = "", on_change_handler: Optional[OnChangeHandler] = None, is_optional: bool = False):
        """
        Args:
            types (str, optional): Строка с типами допустимых файлов, например "Images (*.png *.jpg *.jpeg *.svg)"
        """
        super().__init__(name, sql_name, tooltip, column_width, const, primary_key, unique, False, not_null, default, on_change_handler, is_optional)
        self.file_types = file_types

    def create_for_form(self, data: Optional[str] = None) -> FileSelectWidget:
        widget = FileSelectWidget(data if data is not None else self.default, self.file_types)
        widget.line.setReadOnly(self.const)
        widget.open.setDisabled(self.const)

        return widget
    
    def connect_on_change_handler(self, widget: FileSelectWidget):
        if self.on_change is not None:
            widget.line.editingFinished.connect(lambda: self.on_change(None))

    def create_for_table(self, data: Optional[str]) -> DataLabel:
        return DataLabel(data if data is not None else "", data)

    def change_widget_data(self, widget: DataLabel, data: Optional[str]):
        widget.setText(data)
        widget.field_data = data
    
    def get_widget_data(self, widget: Union[FileSelectWidget, DataLabel], form: bool) -> Union[str, None]:
        if form:
            return widget.line.text()
        else:
            return widget.field_data
    
    def check_widget(self, widget: Union[FileSelectWidget, DataLabel], form: bool) -> tuple[bool, str]:
        if form:
            if not os.path.exists(widget.line.text()):
                return False, f"Файл '{widget.line.text()}' не существует"
        return True, ""

class TableFieldAddFormDialog(QDialog):
    def __init__(self, fields: dict[str, Field], before_save_handler: Optional[BeforeSaveHandler],
                 create_form_handler: Optional[CreateFormHandler], table_name: str, db: DataBase):
        super().__init__()
        self.setWindowTitle(f"Добавление записи")

        self.before_save_handler = before_save_handler
        self.fields = fields
        self.db = db

        apply_styles(self)
                
        buttonBox = QDialogButtonBox(QDialogButtonBox.StandardButton.Apply |
                                     QDialogButtonBox.StandardButton.Cancel)
        buttonBox.button(QDialogButtonBox.StandardButton.Apply).clicked.connect(self.check_and_accept)
        buttonBox.rejected.connect(self.reject)

        layout = QVBoxLayout()
        self.setLayout(layout)

        label = QLabel(f"<b>Добавление в \"{table_name}\"</b>")
        label.setProperty("class", "rowdatadialog-label")
        layout.addWidget(label)

        form = QWidget()
        form_layout = QFormLayout()
        form.setLayout(form_layout)

        self.form_widgets: dict[str, FormRow] = {}
        for field_sql_name, field in fields.items():
            self.form_widgets[field_sql_name] = FormRow(field.name, field.create_for_form_whole(None))
        
        if create_form_handler is not None:
            create_form_handler(self.form_widgets, fields, db)
        
        for field_sql_name, field_row in self.form_widgets.items():
            if field_sql_name in fields.keys():
                fields[field_sql_name].connect_on_change_handler(field_row.widget.field_widget)
            
            tooltip = field_row.widget.whole_widget.toolTip()
            if tooltip == "":
                tooltip = field_row.widget.field_widget.toolTip()

            form_layout.addRow(QLabel(field_row.name + ": ", toolTip=tooltip), field_row.widget.whole_widget)
        
        for field_name, field_widget in self.form_widgets.items():
            self.form_widgets[field_name] = field_widget.widget
        # self.form_widgets: dict[str, FormFieldWidget] = {k: v.widget for k, v in self.form_widgets.items()}
        
        for field in fields.values():
            field.form_widgets = self.form_widgets

        layout.addWidget(form)

        layout.addStretch()
        layout.addWidget(buttonBox)

    def check_and_accept(self):
        for field_sql_name, field in self.fields.items():
            if not self.form_widgets[field_sql_name].is_activated():
                continue

            widget = self.form_widgets[field_sql_name].field_widget
            ok, message = field.check_widget(widget, form=True)
            if not ok:
                QMessageBox.information(None, "Внимание!", field.name + ": " + message)
                return

        if self.before_save_handler is not None:
            ok, message = self.before_save_handler(self.form_widgets, self.fields, self.db)
            if not ok:
                QMessageBox.information(None, "Внимание!", message)
                return
        
        self.accept()

class TableField(Field):
    """
    Табличное поле, которое может содержать множество строк
    - Таблица: DataLabel(QLabel)
    - Форма: QWidget (внутри находится QTableWidget)
    """

    sql_type = "INTEGER"

    def __init__(self, name: str, sql_name: str, table_sql_name: str, fields: list[Field],
                 additional_columns: Optional[list[TableColumn]] = None, tooltip: Optional[str] = None, column_width: Optional[int] = None,
                 const: bool = False, primary_key: bool = False, unique: bool = False, not_null: bool = False, default: str = "",
                 before_save_handler: Optional[BeforeSaveHandler] = None, after_save_handler: Optional[AfterSaveHandler] = None,
                 create_form_handler: Optional[CreateFormHandler] = None, table_row_change_handler: Optional[TableRowChangeHandler] = None,
                 on_change_handler: Optional[OnChangeHandler] = None):
        super().__init__(name, sql_name, tooltip, column_width, const, primary_key, unique, False, not_null, default, on_change_handler, False)
        self.table_sql_name = table_sql_name
        self.additional_columns = additional_columns
        self.before_save_handler = before_save_handler
        self.after_save_handler = after_save_handler
        self.create_form_handler = create_form_handler
        self.table_row_change_handler = table_row_change_handler

        self.fields: dict[str, Field] = {}
        for field in fields:
            field.table_fields = self.fields
            self.fields[field.sql_name] = field
        
        self.table_created = False
        self.table: Union[Table, None] = None
    
    def new_table_keyPressEvent(self, table: Table, event: QKeyEvent, *args):
        table.table_keyPressEvent(event, *args)
        if self.on_change is not None and event.key() == Qt.Key.Key_Delete:
            self.on_change(None)

    def create_for_form(self, data: Optional[str] = None):
        widget = DataWidget(data)
        layout = QVBoxLayout()

        table_widget = QTableWidget()
        self.table.create_table(table_widget, {}, f"parent = {data}", data is None)
        table_widget.keyPressEvent = lambda e: self.new_table_keyPressEvent(self.table, e, table_widget, data is None)
        layout.addWidget(table_widget)

        add_button_div = QWidget()
        add_button_div_layout = QHBoxLayout()
        add_button_div_layout.setContentsMargins(0, 0, 0, 0)
        add_button_div_layout.addStretch(1)

        add_button = QPushButton("Добавить строку")
        add_button.setFixedWidth(115)
        add_button_div_layout.addWidget(add_button)
        add_button.clicked.connect(lambda: self.open_form(table_widget, data))

        add_button_div.setLayout(add_button_div_layout)
        layout.addWidget(add_button_div)

        widget.setLayout(layout)
        return widget
    
    def open_form(self, table_widget: QTableWidget, parent: Optional[str] = None):
        dialog = TableFieldAddFormDialog(self.fields, self.before_save_handler,
                                            self.create_form_handler, self.name, self.db)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            if parent is None:
                self.table.add_data(dialog.form_widgets, [table_widget], True)
            else:
                self.table.add_data(dialog.form_widgets, [table_widget], False, {"parent": parent})

    def create_for_table(self, data: Optional[str]) -> DataLabel:
        return DataLabel("<i>Табличная часть</i>", data)
    
    def change_widget_data(self, widget: DataLabel, data: str):
        widget.field_data = data

    def get_widget_data(self, widget: Union[DataWidget, DataLabel], form: bool) -> str:
        if widget.field_data is None:
            return "-1"
        else:
            return str(widget.field_data)
    
    def check_widget(self, widget: Union[DataWidget, DataLabel], form: bool) -> tuple[bool, str]:
        return True, ""
    
    def new_after_save_handler(self, *args):
        """
        Обычный указанный пользователем after_save_handler, после которого ещё
        вызывается on_change_handler
        """

        if self.after_save_handler is not None:
            self.after_save_handler(*args)
        if self.on_change is not None:
            self.on_change(None)

    def fetch_data_from_db(self, parent_table_sql_name: str):
        if not self.table_created:
            self.table = Table(self.name, self.table_sql_name, self.fields, self.db,
                               self.additional_columns, self.before_save_handler, self.new_after_save_handler,
                               self.create_form_handler, self.table_row_change_handler,
                               [f"parent INTEGER REFERENCES {parent_table_sql_name} (id) ON DELETE CASCADE"],
                               f"FOREIGN KEY (\nparent\n)\nREFERENCES {parent_table_sql_name} (id) ON DELETE CASCADE")
            
            self.db.cur.execute(self.table.create_SQL_request())
            self.db.conn.commit()

            self.table_created = True

        for field in self.fields.values():
            field.db = self.db
            field.fetch_data_from_db(self.sql_name)

    def add_to_db(self, widget: FormFieldWidget, form_data: dict[str, str], parent_table_sql_name: str):
        table_widget: QTableWidget = widget.field_widget.findChild(QTableWidget)

        for row in range(table_widget.rowCount()):
            data = {"parent": form_data["id"]}
            for i, field in enumerate(self.fields.values()):
                data[field.sql_name] = field.get_widget_data(table_widget.cellWidget(row, i), form=False)
            
            self.table.add_data_to_db(data)
        
        self.db.cur.execute(f"UPDATE {parent_table_sql_name} SET {self.sql_name} = ? WHERE id = ?", (form_data["id"], form_data["id"]))
        self.db.conn.commit()

        form_data[self.sql_name] = form_data["id"]

class LabelField(Field):
    """
    Поле с нередактируемым текстом
    """

    def __init__(self, name: str, sql_name: str, tooltip: Optional[str] = None, column_width: Optional[int] = None, default: Optional[str] = None):
        super().__init__(name, sql_name, tooltip, column_width, default=default)
    
    def create_for_form(self, data: Optional[str] = None) -> QLabel:
        return QLabel(data if data is not None else self.default)
    
    def create_for_table(self, data: Optional[str]) -> QLabel:
        return QLabel(data if data is not None else self.default)
    
    def change_widget_data(self, widget: QLabel, data: Optional[str]):
        widget.text = data if data is not None else self.default
    
    def get_widget_data(self, widget: QLabel, form: bool) -> Union[str, None]:
        return widget.text()

    def check_widget(self, widget: QLabel, form: bool) -> tuple[bool, str]:
        return True, ""
