from PySide6.QtWidgets import QApplication, QMainWindow, QTabWidget, QWidget, QVBoxLayout, QLabel
from PySide6.QtGui import QIcon

from ..tabs.tab import Tab
from ..tabs.group import TabGroup
from .db import DataBase
from .themes import apply_styles

from typing import Optional
import logging
import sys
import os


logging.basicConfig(level=logging.DEBUG,
                    format="%(asctime)s %(module)s %(funcName)s: %(lineno)d - %(levelname)s - %(message)s",
                    datefmt='%H:%M:%S')


class App:
    """
    Класс приложения с таблицами
    """

    def __init__(self, name: str, db: DataBase, window_width: int, window_height: int, icon_path: Optional[str] = None):
        """
        Args:
            name (str): Отображаемое название приложения
            db (DataBase): Объект базы данных
            window_width (int): Начальная ширина окна приложения в пикселях
            window_height (int): Начальная ширина окна приложения в пикселях
            icon_path (str, optional): Путь к файлу изображения, который будет использоваться как иконка приложения
        """

        self.tabs: list[Tab] = []
        self.groups: list[TabGroup] = []
        self.icon_path = icon_path

        self.db = db
        self.name = name
        self.window_width = window_width
        self.window_height = window_height

        logging._defaultLastResort
 
    def add_tab(self, tab: Tab):
        """
        Добавление вкладки в приложение

        Args:
            tab (Tab): Объект вкладки
        """

        tab.app_add_tab(self.db)
        
        self.tabs.append(tab)

    def add_group(self, group: TabGroup):
        """
        Добавление группы вкладок в приложение.
        После добавления хотя бы одной группы, добавленные вне групп вкладки отображаться не будут.
        Args:
            group (TabGroup): Объект группы вкладок
        """
        
        for tab in group.tabs:
            tab.app_add_tab(self.db)
        
        self.groups.append(group)

    def run(self):
        """
        Запуск приложения
        """

        # TODO: Добавить поддержку тёмной темы

        # Создание базы данных
        if len(self.groups) > 0:  # Если есть группы, то используем только вкладки из них
            self.tabs = []
            for group in self.groups:
                self.tabs.extend(group.tabs)

        # Создание объекта приложения
        app = QApplication(sys.argv)

        # Создание главного окна
        window_widget = QMainWindow()
        window_widget.setWindowTitle(self.name)
        if self.icon_path is not None:
            window_widget.setWindowIcon(QIcon(self.icon_path))
        window_widget.resize(self.window_width, self.window_height)

        container = QWidget()
        container.setProperty("class", "main-container")
        container_layout = QVBoxLayout()
        container_layout.setContentsMargins(0, 0, 0, 0)
        container.setLayout(container_layout)

        apply_styles(window_widget)
        QApplication.instance().paletteChanged.connect(lambda: apply_styles(window_widget))

        if len(self.groups) > 0:
            groups_tab_widget = QTabWidget()
            groups_tab_widget.setProperty("class", "groups-tab")

            tab_bar = groups_tab_widget.tabBar()
            tab_bar.setProperty("class", "groups-tab-bar")

            for group in self.groups:
                tabs_tab_widget = QTabWidget()
                for tab in group.tabs:
                    tabs_tab_widget.addTab(tab.create_tab_widget(), tab.name)
                tabs_tab_widget.setCurrentIndex(0)

                groups_tab_widget.addTab(tabs_tab_widget, group.name)
            
            groups_tab_widget.setCurrentIndex(0)
            container_layout.addWidget(groups_tab_widget)
        else:
            tabs_widget = QTabWidget()

            for tab in self.tabs:
                tabs_widget.addTab(tab.create_tab_widget(), tab.name)
            
            tabs_widget.setCurrentIndex(0)
            container_layout.addWidget(tabs_widget)
        
        window_widget.setCentralWidget(container)

        window_widget.show()

        app.exec()
        self.db.close()
