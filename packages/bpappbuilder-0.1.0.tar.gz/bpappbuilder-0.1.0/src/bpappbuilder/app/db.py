from abc import ABC, abstractmethod
from typing import Optional
import sqlite3
import logging

class DataBase(ABC):
    """
    Базовый класс базы данных, имеющий поля conn и cur
    """

    @abstractmethod
    def __init__(self):
        self.conn = None
        self.cur = None

    @abstractmethod
    def close(self):
        """
        Закрытие соединения с БД при завершении работы приложения
        """
        pass

class SQLiteDB(DataBase):
    """
    База данных SQLite
    """
    
    def __init__(self, path: str):
        """
        Args:
            path (str): Путь к .db файлу
        """

        self.conn = sqlite3.connect(path, check_same_thread = False)
        self.conn.row_factory = sqlite3.Row
        self.conn.set_trace_callback(self.log)  # Логирование всех запросов к БД
        self.cur = self.conn.cursor()
        
        self.cur.execute("PRAGMA foreign_keys = ON")
        self.conn.commit()
    
    def close(self):
        self.cur.close()
        self.conn.close()
    
    def log(self, statement: str):
        logging.info(f"SQlite: \033[2;32m{statement}\033[0m")
