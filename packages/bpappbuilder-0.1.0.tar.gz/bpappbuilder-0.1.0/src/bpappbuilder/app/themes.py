from PySide6.QtWidgets import QWidget, QApplication

from typing import Optional
import os

THEMES = {
	"light": {
		"--app-bg": "#eee",
		"--tab-border": "#C2C7CB",
		"--selected-tab-border": "#679dcf",
		"--unselected-tab-bg": "#e4e4e4",
		"--groups-bar-bg": "#e3e3e3",
		"--default-widget-border": "gray",
		"--default-selected-widget-border": "#3484cf",
		"--gray-btn-bg": "#e3e3e3",
		"--hover-gray-btn-bg": "#dbdbdb",
		"--pressed-gray-btn-bg": "#d4d4d4",
		"--add-btn-bg": "#3484cf",
		"--hover-add-btn-bg": "#2679c7",
		"--pressed-add-btn-bg": "#1f6eb8",
		"--red-btn-bg": "#ff4d4d",
		"--hover-red-btn": "#f74444",
		"--pressed-red-btn-bg": "#f13737",
		"--green-btn-bg": "#30c72b",
		"--hover-green-btn-bg": "#30be2b",
		"--pressed-green-btn-bg": "#33af2e",
		"--report-section-border": "#E6E6E6",
		"--report-widget-bg": "white",
	},
	"dark": {
		"--app-bg": "#111215",
		"--tab-border": "#545454",
		"--selected-tab-border": "#2472d1",
		"--unselected-tab-bg": "#1c1e23",
		"--groups-bar-bg": "#1c1e23",
		"--default-widget-border": "#545454",
		"--default-selected-widget-border": "#3484cf",
		"--gray-btn-bg": "#24262c",
		"--hover-gray-btn-bg": "#282a30",
		"--pressed-gray-btn-bg": "#31333b",
		"--add-btn-bg": "#3484cf",
		"--hover-add-btn-bg": "#2679c7",
		"--pressed-add-btn-bg": "#1f6eb8",
		"--red-btn-bg": "#ff2b2f",
		"--hover-red-btn": "#f74444",
		"--pressed-red-btn-bg": "#e62026",
		"--green-btn-bg": "#35b62e",
		"--hover-green-btn-bg": "#30be2b",
		"--pressed-green-btn-bg": "#33af2e",
		"--report-section-border": "#414141",
		"--report-widget-bg": "#15161a",
	}
}

def apply_styles(widget: QWidget, previous_theme: Optional[str] = None) -> str:
	app = QApplication.instance()
	palette = app.palette()
	
	is_dark = palette.color(palette.ColorRole.Window).lightness() < 128
	theme = "dark" if is_dark else "light"
	
	if previous_theme == theme:
		return theme
	
	with open(os.path.dirname(os.path.realpath(__file__)) + "/styles.qss", "r") as f:
	    style = f.read()
	for var, data in THEMES[theme].items():
	    style = style.replace(f"var({var})", data)
	widget.setStyleSheet(style)

	return theme

