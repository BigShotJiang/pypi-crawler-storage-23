from bpappbuilder.app import App, DataBase, SQLiteDB
from bpappbuilder.tabs import TableTab, TabGroup
from bpappbuilder.fields import (Field, TableField, TimeField, DateField, TextLineField, ComboBoxField,
                                 TextAreaField, DateTimeField, StaticItems, TableFieldItems)

from PySide6.QtWidgets import QWidget, QComboBox, QTimeEdit, QTableWidget
from PySide6.QtCore import QDate

from typing import Any


ages = [
    "Младший дошкольный возраст(3-5 лет)",
    "Старший дошкольный возраст (5-7 лет)",
    "Младший школьный возраст (7-10 лет)",
    "Средний школьный возраст (10-14 лет)",
    "Старший школьный возраст (14-17 лет)"
]

weekdays = [
    "Понедельник",
    "Вторник",
    "Среда",
    "Четверг",
    "Пятница",
    "Суббота",
    "Воскресение"
]

def club_start_changed(data: Any, form_widgets: dict[str, QWidget], fields: dict[str, Field], db: DataBase):
    club_id = form_widgets["club"].currentData()
    db_data = db.cur.execute("SELECT ages FROM Clubs WHERE id = ?", (club_id,)).fetchone()
    ages_widget: QComboBox = form_widgets["ages"]
    ages_widget.setCurrentIndex(int(db_data["ages"]))

def club_start_check(form_widgets: dict[str, QWidget], fields: dict[str, Field], db: DataBase) -> tuple[bool, str]:
    time_start: QTimeEdit = form_widgets['time_start']
    time_end: QTimeEdit = form_widgets['time_end']
    teacher: QComboBox = form_widgets["teacher"]

    days_widget: QTableWidget = form_widgets["days"].layout().itemAt(0).widget()
    days_field: TableField = fields["days"]
    days_list = [str(x["day"]) for x in days_field.table.get_table_data(days_widget)]

    result = db.cur.execute(f"SELECT club FROM ClubStart \
                             WHERE teacher = {teacher.currentData()} \
                             AND (time_start <= '{time_start.time().toString(TimeField.time_format)}' OR time_end >= '{time_end.time().toString(TimeField.time_format)}') \
                             AND '{QDate.currentDate().toString(DateField.date_format)}' <= period \
                             AND EXISTS (SELECT 1 FROM ClubStartDays WHERE parent = ClubStart.id AND day in ({', '.join(days_list)}))").fetchone()
    if result is not None:
        club_name = db.cur.execute("SELECT name FROM Clubs WHERE id = ?", (result[0],)).fetchone()[0]
        teacher_name = db.cur.execute("SELECT name FROM Teachers WHERE id = ?", (teacher.currentData(),)).fetchone()[0]
        return False, f"Преподаватель {teacher_name} уже ведёт кружок <b>{club_name}</b> в это время"
    else:
        return True, ""

app = App("Приложение", SQLiteDB("pf_app.db"), 1280, 720)

schedule_group = TabGroup("Расписание")
set_group = TabGroup("Набор")

club_table = TableTab("Кружки", "Clubs")
club_table.add_field(TextLineField("Название", "name", column_width=175))
club_table.add_field(ComboBoxField("Возрастной интервал", "ages", StaticItems(ages), column_width=225))
club_table.add_field(TextAreaField("Описание", "description", column_width=300))
schedule_group.add_tab(club_table)
set_group.add_tab(club_table)

teachers_tab = TableTab("Преподаватели", "Teachers")
teachers_tab.add_field(TextLineField("ФИО", "name", column_width=300))
schedule_group.add_tab(teachers_tab)

club_start_table = TableTab("Старт кружка", "ClubStart", before_save_handler=club_start_check)
club_start_table.add_field(DateTimeField("Дата формирования приказа", "date", only_current=True, column_width=180))
club_start_table.add_field(ComboBoxField("Кружок", "club", TableFieldItems("Clubs", "name", app.db), not_null=True, column_width=175, on_change_handler=club_start_changed))
club_start_table.add_field(ComboBoxField("Возрастной интервал", "ages", StaticItems(ages), const=True, column_width=225))
club_start_table.add_field(DateField("Период работы", "period", min_date="now", column_width=100))
club_start_table.add_field(ComboBoxField("Преподаватель", "teacher", TableFieldItems("Teachers", "name", app.db), column_width=300))
club_start_table.add_field(TableField("Дни недели", "days", "ClubStartDays", [
                                                ComboBoxField("Дни", "day", StaticItems(weekdays), column_width=100)
                                            ]))
club_start_table.add_field(TimeField("Время проведения занятий с", "time_start", column_width=170))
club_start_table.add_field(TimeField("Время проведения занятий до", "time_end", column_width=175))
schedule_group.add_tab(club_start_table)
set_group.add_tab(club_start_table)

payment_group = TabGroup("Оплата")

app.add_group(schedule_group)
app.add_group(set_group)
app.add_group(payment_group)

app.run()
