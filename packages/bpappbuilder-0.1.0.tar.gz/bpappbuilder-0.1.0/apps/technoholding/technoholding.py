from bpappbuilder.app import App, DataBase, SQLiteDB
from bpappbuilder.tabs import TableTab, FormFieldWidget, FormRow
from bpappbuilder.reports import ReportTab, TextReport, ListReport, TextReportField, ReportSettingsItem
from bpappbuilder.fields import (Field, LabelField, DateTimeField, TextLineField,
                                 ComboBoxField, FloatField, DateField, TimeField, IntField, TextAreaField,
                                 TableField, TableFieldItems, TableItems)

from PySide6.QtWidgets import QDoubleSpinBox, QMessageBox, QTableWidget, QDateTimeEdit, QLabel, QComboBox
from PySide6.QtCore import QDateTime
from PySide6.QtGui import QFont
from typing import Any, Union


max_float_value = 10_000_000_000_000.0
max_int_value = 1_000_000_000


class MoneyLabelField(LabelField):
    def create_for_table(self, data: Union[str, None]) -> QLabel:
        return QLabel("%.2f" % float(data if data is not None else self.default))

def update_total(data: Any, form_widgets: dict[str, FormFieldWidget], fields: dict[str, Field], db: DataBase):
    count = form_widgets["count"].field_widget.value()
    price = form_widgets["price"].field_widget.value()
    form_widgets["total"].field_widget.setValue(round(count * price, 2))

def update_price(data: Any, form_widgets: dict[str, FormFieldWidget], fields: dict[str, Field], db: DataBase):
    price_widget: QDoubleSpinBox = form_widgets["price"].field_widget
    product_widget: QComboBox = form_widgets["product"].field_widget
    provider_widget: QComboBox = form_widgets["provider"].field_widget
    product = product_widget.currentData()
    provider = provider_widget.currentData()

    if product is None or provider is None:
        price_widget.setValue(0)
        form_widgets["total"].field_widget.setValue(0)
    else:
        data = db.cur.execute("SELECT price FROM Prices WHERE product = ? AND provider = ?", (product, provider)).fetchone()
        if data is None:
            names_data = db.cur.execute("SELECT (SELECT name FROM Products WHERE id = ?) AS product, \
                                                (SELECT name FROM Providers WHERE id = ?) AS provider", (product, provider)).fetchone()
            QMessageBox.information(None, "Внимание!", f"У поставщика <b>{names_data['provider']}</b> нет установленной цены на <b>\"{product} {names_data['product']}\"</b>")
            price_widget.setValue(0)
        else:
            price_widget.setValue(data[0])
        
        current_provider_products = db.cur.execute("""WITH P AS (
                                                        SELECT product FROM Prices
                                                        WHERE provider = ?
                                                      )
                                                      SELECT name, (id IN P) AS selected FROM Products""", (provider,)).fetchall()
        
        normal_font = QFont()
        normal_font.setBold(False)
        bold_font = QFont()
        bold_font.setBold(True)

        for i in range(len(current_provider_products)):
            selected = bool(int(current_provider_products[i]["selected"]))
            product_widget.model().item(i).setFont(bold_font if selected else normal_font)
        
        current_product_providers = db.cur.execute("""WITH P AS (
                                                        SELECT provider FROM Prices
                                                        WHERE product = ?
                                                      )
                                                      SELECT (id in P) AS selected FROM Providers""", (product,)).fetchall()
        for i in range(len(current_product_providers)):
            selected = bool(int(current_product_providers[i]["selected"]))
            provider_widget.model().item(i).setFont(bold_font if selected else normal_font)
    
        update_total(None, form_widgets, fields, db)

def check_order_item(form_widgets: dict[str, FormFieldWidget], fields: dict[str, Field], db: DataBase):
    product = int(form_widgets["product"].field_widget.currentData())
    provider = int(form_widgets["provider"].field_widget.currentData())

    data = db.cur.execute("SELECT price FROM Prices WHERE product = ? AND provider = ?", (product, provider)).fetchone()
    if data is None:
        names_data = db.cur.execute("SELECT (SELECT name FROM Products WHERE id = ?) AS product, \
                                            (SELECT name FROM Providers WHERE id = ?) AS provider", (product, provider)).fetchone()
        return False, f"У поставщика <b>{names_data['provider']}</b> нет установленной цены на <b>\"{product} {names_data['product']}\"</b>"
    
    return True, ""

def products_form_create(form_widgets: dict[str, FormRow], fields: dict[str, Field], db: DataBase):
    update_price(None, {key: value.widget for key, value in form_widgets.items()}, fields, db)

def calc_cost(data: None, form_widgets: dict[str, FormFieldWidget], fields: dict[str, Field], db: DataBase):
    table_widget: QTableWidget = form_widgets["products"].field_widget.findChild(QTableWidget)
    cost_widget: QDoubleSpinBox = form_widgets["cost"].field_widget

    total_column = 4 if table_widget.horizontalHeaderItem(0).text() == "ID" else 3
    cost = 0.0
    for row in range(table_widget.rowCount()):
        cost += float(table_widget.cellWidget(row, total_column).field_data)
    
    cost_widget.setValue(cost)

def check_order(form_widgets: dict[str, FormFieldWidget], fields: dict[str, Field], db: DataBase):
    event = form_widgets["event"].field_widget.currentData()
    order_datetime: QDateTime = form_widgets["date"].field_widget.dateTime()

    data = db.cur.execute("SELECT date, time_start FROM Events WHERE id = ?", (event,)).fetchone()
    event_datetime = QDateTime.fromString(data["date"] + " " + data["time_start"], DateTimeField.datetime_format)
    if order_datetime.addDays(1) > event_datetime:
        return False, f"Заказ можно формировать не позднее, чем за сутки до начала мероприятия. Вы указали дату и время поставки в <b>{order_datetime.toString(DateTimeField.datetime_format)}</b>, а мероприятие начинается в <b>{data['date']} {data['time_start']}</b>"
    
    return True, ""

def event_changed(data: None, form_widgets: dict[str, FormFieldWidget], fields: dict[str, Field], db: DataBase):
    event = form_widgets["event"].field_widget.currentData()
    if event is None:
        return
    datetime_widget: QDateTimeEdit = form_widgets["date"].field_widget

    data = db.cur.execute("SELECT date, time_start, budget FROM Events WHERE id = ?", (event,)).fetchone()

    event_datetime = QDateTime.fromString(data["date"] + " " + data["time_start"], DateTimeField.datetime_format)
    datetime_widget.setMaximumDateTime(event_datetime.addDays(-1))

    form_widgets["budget"].field_widget.setText("%.2f" % float(data["budget"]))

def cost_changed(cost: float, form_widgets: dict[str, FormFieldWidget], fields: dict[str, Field], db: DataBase):
    cost_widget = form_widgets["cost"].field_widget
    event = form_widgets["event"].field_widget.currentData()
    
    if event is not None:
        budget = float(form_widgets["budget"].field_widget.text())
        cost_widget.setStyleSheet("background-color: #f13737;" if budget < cost else "background-color: #30c72b;")

def order_form_create(form_widgets: dict[str, FormRow], fields: dict[str, Field], db: DataBase):
    budget_widget = QLabel("0.00", toolTip="Бюджет берётся из мероприятия, в рамках которого оформляется заказ")
    form_widgets["budget"] = FormRow("Бюджет", FormFieldWidget(budget_widget))

    if "id" in form_widgets.keys():
        new_form_widgets = {key: value.widget for key, value in form_widgets.items()}
        event_changed(None, new_form_widgets, fields, db)
        cost_changed(float(form_widgets["cost"].widget.field_widget.value()), new_form_widgets, fields, db)

def create_food_report(fields: dict[str, TextReportField], settings: dict[str, ReportSettingsItem], db: DataBase):
    budget_widget = fields["budget"].widget
    cost_widget = fields["cost"].widget
    if float(cost_widget.text()) > float(budget_widget.text()):
        cost_widget.setStyleSheet("background-color: #f13737;")


app = App("Организация мероприятий \"ТехноХолдинг \"Восток\"", SQLiteDB("holding.db"), 1280, 720)

categories_table = TableTab("Категории затрат", "Categories")
categories_table.add_field(TextLineField("Название", "name", column_width=150, not_null=True))
app.add_tab(categories_table)

products_table = TableTab("Номенклатура", "Products")
products_table.add_field(TextLineField("Название", "name", column_width=200, not_null=True))
products_table.add_field(ComboBoxField("Категория затрат", "category",
                                             TableFieldItems("Categories", "name", app.db),
                                             not_null=True, column_width=150))
app.add_tab(products_table)

providers_table = TableTab("Поставщики", "Providers")
providers_table.add_field(TextLineField("Наименование", "name", column_width=200, not_null=True))
providers_table.add_field(ComboBoxField("Категория затрат", "category",
                                             TableFieldItems("Categories", "name", app.db),
                                             not_null=True, column_width=150))
app.add_tab(providers_table)

prices_table = TableTab("Цены от поставщиков", "Prices", unique=(("product", "provider"),))
prices_table.add_field(ComboBoxField("Продукт или услуга", "product",
                                           TableItems("Products", app.db, lambda x: f"{x['id']} {x['name']}", ("id", "name")),
                                           not_null=True, column_width=200))
prices_table.add_field(ComboBoxField("Поставщик", "provider",
                                           TableFieldItems("Providers", "name", app.db),
                                           not_null=True, column_width=200))
prices_table.add_field(FloatField("Цена", "price", max_value=max_float_value, accuracy=2, column_width=100))
app.add_tab(prices_table)

events_table = TableTab("Мероприятия", "Events")
events_table.add_field(TextLineField("Название", "name", column_width=175, not_null=True))
events_table.add_field(DateField("Дата", "date", min_date="now", column_width=100))
events_table.add_field(TimeField("Время начала", "time_start"))
events_table.add_field(IntField("Ожидаемое количество гостей", "guests", max_value=max_int_value))
events_table.add_field(FloatField("Бюджет руб.", "budget", max_value=max_float_value, accuracy=2))
events_table.add_field(TextAreaField("Описание", "description", column_width=200))
app.add_tab(events_table)

orders_table = TableTab("Заказы", "Orders", before_save_handler=check_order, create_form_handler=order_form_create)
orders_table.add_field(DateTimeField("Дата и время", "date", min_date="now", default="now", column_width=100))
orders_table.add_field(ComboBoxField("Мероприятие", "event", TableFieldItems("Events", "name", app.db), not_null=True, column_width=175, on_change_handler=event_changed))
orders_table.add_field(TableField("Заказываемое", "products", "OrderedObjects", [
    ComboBoxField("Продукт или услуга", "product",
                     TableItems("Products", app.db, lambda x: f"{x['id']} {x['name']}", ("id", "name")),
                     not_null=True, column_width=200, on_change_handler=update_price),
    FloatField("Количество", "count", max_value=max_float_value, accuracy=2, column_width=100, on_change_handler=update_total),
    FloatField("Цена", "price", max_value=max_float_value, accuracy=2, column_width=100, on_change_handler=update_total),
    FloatField("Стоимость", "total", max_value=max_float_value, accuracy=2, column_width=100),
    ComboBoxField("Поставщик", "provider",
                     TableFieldItems("Providers", "name", app.db),
                     not_null=True, column_width=200, on_change_handler=update_price)
    ], create_form_handler=products_form_create, before_save_handler=check_order_item, on_change_handler=calc_cost))
orders_table.add_field(FloatField("Общая сумма", "cost", max_value=max_float_value, accuracy=2, column_width=100, on_change_handler=cost_changed))
app.add_tab(orders_table)

food_report = ReportTab("Отчет о расходах на питание на мероприятии", "", [
    TextReport("""
        SELECT COALESCE((SELECT SUM(cost) FROM Orders WHERE event = :event {AND date(date) >= :from} {AND date(date) <= :to}), 0) as cost,
               COALESCE((SELECT budget FROM Events WHERE id = :event), 0) AS budget,
               (SELECT date FROM Events WHERE id = :event) AS date""",
        [
            LabelField("Дата проведения", "date"),
            MoneyLabelField("Общий бюджет, руб", "budget"),
            MoneyLabelField("Общие расходы, руб", "cost")
        ], create_form_handler=create_food_report),
    ListReport("""
        SELECT Categories.name AS category, SUM(total) AS cost FROM OrderedObjects
        LEFT JOIN Orders ON OrderedObjects.parent = Orders.id
        LEFT JOIN Events ON Orders.event = Events.id
        LEFT JOIN Products ON Products.id = OrderedObjects.product
        LEFT JOIN Categories ON Categories.id = Products.category
        WHERE event = :event {AND date(Orders.date) >= :from} {AND date(Orders.date) <= :to}
        GROUP BY Categories.name
        """, [
            LabelField("Категория затрат", "category", column_width=150),
            MoneyLabelField("Расходы, руб", "cost")
        ])
    ], [
        ComboBoxField("Мероприятие", "event", TableFieldItems("Events", "name", app.db), not_null=True),
        DateField("Период с", "from", default="now", is_optional=True),
        DateField("Период до", "to", default="now", is_optional=True)
    ])
app.add_tab(food_report)

app.run()

