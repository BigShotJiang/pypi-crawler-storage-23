# pyinstaller -D -n "Развитие 360" --windowed --icon "dev360_icon.ico" .\development360.py

from bpappbuilder.app import App, DataBase, SQLiteDB
from bpappbuilder.tabs import TableTab, TableColumn, FormFieldWidget, FormRow
from bpappbuilder.fields import (Field, DateField, TimeField, TextLineField,
                                 TextAreaField, ComboBoxField, IntField, FloatField, TableField,
                                 TableFieldItems, LabelField, StaticItems, FileField)
from bpappbuilder.reports import ReportTab, LineChartReport, ListReport

from PySide6.QtWidgets import QWidget, QCalendarWidget, QToolTip, QPushButton
from PySide6.QtGui import QColor, QPalette, QPen, QPainter
from PySide6.QtCore import QDate, QTime, Qt, QEvent, QObject, QPoint, QRect

# import win11toast
import notifypy  # notify_py
import threading
import time
import random
from math import log10
from typing import Optional


app_name = "Развитие 360"

def set_class_field(widget: QWidget, new_class: str):
    widget.setProperty("class", new_class)
    old = widget.styleSheet()
    if not old:
        widget.setStyleSheet('* {}')
    widget.setStyleSheet(old)


class HabitMarkButton(QPushButton):
    def __init__(self, habit_type: int):
        super().__init__()
        self.marked = False
        self.habit_type = habit_type

class HabitsCalendar(QCalendarWidget):
    def __init__(self, habit_id: int, habit_type: int, db: DataBase):
        super().__init__()

        self.habit_id = habit_id
        self.habit_type = habit_type
        self.db = db

        self.notes = self.db.cur.execute("SELECT id, text, date FROM Notes WHERE habit = ?", (self.habit_id,)).fetchall()
        self.files = self.db.cur.execute("SELECT NotesFiles.name, NotesFiles.parent, Notes.date FROM NotesFiles LEFT JOIN Notes ON NotesFiles.parent = Notes.id WHERE Notes.habit = ?", (self.habit_id,)).fetchall()

        self.setMouseTracking(True)
        self.installEventFilter(self)

        self.enabled_dates = set()

        self.get_days(QDate.currentDate().year(), QDate.currentDate().month())
        self.updateCells()

        self.clicked.connect(self.toggle_day)
        self.currentPageChanged.connect(self.get_days)

    def toggle_day(self, date: QDate):
        if date > QDate.currentDate().addDays(30) or date < QDate.currentDate().addDays(-30):
            return

        date_str = date.toString(DateField.date_format)

        if date in self.enabled_dates:
            self.enabled_dates.remove(date)
            self.db.cur.execute("DELETE FROM HabitMarks WHERE habit = ? AND date = ?", (self.habit_id, date_str))
            self.db.conn.commit()
        else:
            score = calculate_score(self.habit_id, self.habit_type, date_str)
            self.enabled_dates.add(date)
            self.db.cur.execute("INSERT INTO HabitMarks (habit, score, date) VALUES (?, ?, ?)",
                                (self.habit_id, score, date_str))
            app.db.conn.commit()
        if date == QDate.currentDate():
            for table in habits_table.tables_widgets:
                find = False
                for row in range(table.rowCount()):
                    if int(table.item(row, 0).text()) == self.habit_id:
                        find = True
                        break
                
                if find:
                    mark_btn_clicked(table.cellWidget(row, len(habits_table.fields)+1), self.habit_id)
            
            if date in self.enabled_dates:
                data = self.db.cur.execute(
                    "SELECT * FROM (SELECT name FROM Habits WHERE id = ?), (SELECT SUM(score) AS score FROM HabitMarks WHERE date = ?)",
                    (self.habit_id, date_str)).fetchone()
                
                threading.Thread(target=lambda:notifypy.Notify(
                    app_name,
                    f"{score:+} {score_word(score)} за привычку \"{data['name']}\"! Теперь у вас за сегодня {data['score']} {score_word(data['score'])}",
                    app_name,
                    default_notification_icon="dev360_icon.ico").send(), daemon=True).start()

        self.updateCells()
    
    def get_days(self, year: int, month: int):
        days_data = self.db.cur.execute(
            "SELECT date FROM HabitMarks WHERE habit = ? AND date BETWEEN ? AND ?", (self.habit_id, f"{year}-{month:02}-00", f"{year}-{month:02}-31")
            ).fetchall()
        self.enabled_dates = {QDate.fromString(x["date"], DateField.date_format) for x in days_data}

    def paintCell(self, painter: QPainter, rect: QRect, date: QDate):
        super().paintCell(painter, rect, date)

        if date in self.enabled_dates or date == self.selectedDate():
            if date != self.selectedDate():
                painter.fillRect(rect, QColor(65, 243, 71) if self.habit_type == 0 else QColor(243, 65, 65))
            elif date in self.enabled_dates:
                painter.fillRect(rect, QColor(63, 235, 66) if self.habit_type == 0 else QColor(228, 62, 62))
            else:
                painter.fillRect(rect, self.palette().color(QPalette.ColorRole.Midlight))
            painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, str(date.day()))
        
        date_str = date.toString(DateField.date_format)
        if date_str in map(lambda x: x["date"], self.notes):
            painter.setPen(QPen(Qt.GlobalColor.black, 2, Qt.PenStyle.SolidLine))
            painter.drawEllipse(QPoint(rect.x()+6, rect.y()+6), 3, 3)

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        if obj is self and event.type() == QEvent.Type.ToolTip:
            pos: QPoint = event.pos()
            date = self.get_date_at_position(pos)

            QToolTip.showText(self.mapToGlobal(pos), self.create_tooltip(date), self)
        return super().eventFilter(obj, event)

    def create_tooltip(self, date: QDate) -> str:
        date_str = date.toString(DateField.date_format)

        # notes = self.db.cur.execute("SELECT id, text FROM Notes WHERE date = ? AND habit = ?", (date.toString(DateField.date_format), self.habit_id)).fetchall()
        notes = [x for x in self.notes if x["date"] == date_str]

        text = ""
        for note_data in notes:
            text += note_data["text"]
            # files = self.db.cur.execute("SELECT name FROM NotesFiles WHERE parent = ?", (note_data["id"],)).fetchall()
            files = [x for x in self.files if x["parent"] == note_data["id"]]
            for file in files:
                text += f"<img src = '{file['name']}'/><br>"
            if len(notes) > 1:
                text += "<hr>"
        
        return text

    def get_date_at_position(self, pos: QPoint) -> QDate:
        table_view: QTableView = self.findChild(QTableView)
        if not table_view:
            return QDate()
        
        table_pos = table_view.mapFrom(self, pos)
        
        index = table_view.indexAt(table_pos)
        if not index.isValid():
            return QDate()
        
        return self.get_date_from_index(index.row()-1, index.column()-1)

    def get_date_from_index(self, row: int, column: int) -> QDate:
        year = self.yearShown()
        month = self.monthShown()

        first_day = QDate(year, month, 1)
        offset = (first_day.dayOfWeek() - self.firstDayOfWeek().value) % 7

        start_date = first_day.addDays(-offset)

        if offset == 0:
            start_date = start_date.addDays(-7)

        return start_date.addDays(row * 7 + column)

def calculate_score(habit_id: int, habit_type: int, date: str):
    data = app.db.cur.execute("""
WITH RECURSIVE
Marks AS (
    SELECT date FROM HabitMarks WHERE habit = :habit_id
),
MonthMarksCount AS (
    SELECT COUNT(*) AS month_count FROM Marks WHERE date BETWEEN date(:date, '-30 days') AND :date
),
Streak AS (
    SELECT :date AS day
    WHERE day IS NOT NULL
    UNION ALL
    SELECT date(day, '-1 day')
    FROM Streak
    WHERE date(day, '-1 day') IN Marks
    LIMIT 100
),
Complexity AS (
    SELECT complexity FROM Habits WHERE id = :habit_id
)
SELECT COUNT(day) AS streak, month_count, complexity FROM Streak, MonthMarksCount, Complexity
""", {"habit_id": habit_id, "date": date}).fetchone()
    
    complexity = (0.5, 1, 2)
    score = (10 + log10(1 + data["streak"]) * 15) * ((data["month_count"]+1) / 30) * complexity[data["complexity"]]
    score = max(1, int(score)) * (1 if habit_type == 0 else -1)

    return score

def create_form(form_widgets: dict[str, FormRow], fields: dict[str, Field], db: DataBase):
    if "id" in form_widgets.keys():
        calendar = HabitsCalendar(int(form_widgets["id"].widget.field_widget.text()), int(form_widgets["type"].widget.field_widget.currentData()), db) 
        form_widgets["calendar"] = FormRow("Календарь", FormFieldWidget(calendar))

def update_habits_type(data: None, form_widgets: dict[str, FormFieldWidget], fields: dict[str, Field], db: DataBase):
    habit_type = int(form_widgets["type"].field_widget.currentData())
    
    if habit_type == 1:
        form_widgets["remind_every"].set_activated(False)
        form_widgets["remind_at"].set_activated(False)
    
    if "id" in form_widgets.keys():
        calendar: HabitsCalendar = form_widgets["calendar"].field_widget
        calendar.habit_type = habit_type
        calendar.updateCells()

        habit_id = int(form_widgets["id"].field_widget.text())
        app.db.cur.execute("UPDATE HabitMarks SET score = ABS(score) * IIF(? = 0, 1, -1) WHERE habit = ?", (habit_type, habit_id))
        app.db.conn.commit()
    
    form_widgets["remind_every"].whole_widget.setEnabled(not habit_type)
    form_widgets["remind_at"].whole_widget.setEnabled(not habit_type)

def score_word(score: int) -> str:
    if 5 <= abs(score) <= 20:
        return "баллов"
    elif abs(score) % 10 == 1:
        return "балл"
    elif abs(score) in (2,3,4):
        return "балла"
    else:
        return "баллов"

def mark_btn_clicked(button: HabitMarkButton, habit_id: int, db: Optional[DataBase] = None):
    current_date = QDate.currentDate().toString(DateField.date_format)
    
    if button.marked:  # Выключение
        button.setText("Пометить выполненной за сегодня")
        set_class_field(button, "")
        if db is not None:
            db.cur.execute("DELETE FROM HabitMarks WHERE habit = ? AND date = ?", (habit_id, current_date))
            db.conn.commit()
    else:  # Включение
        button.setText("Помечена выполненной за сегодня")
        set_class_field(button, "green-button" if button.habit_type == 0 else "red-button")
        if db is not None:
            score = calculate_score(habit_id, button.habit_type, current_date)
            db.cur.execute("INSERT INTO HabitMarks (habit, score, date) VALUES (?, ?, ?)", (habit_id, score, current_date))
            db.conn.commit()

            data = db.cur.execute(
                "SELECT * FROM (SELECT name FROM Habits WHERE id = ?), (SELECT SUM(score) AS score FROM HabitMarks WHERE date = ?)",
                (habit_id, current_date)).fetchone()
            
            threading.Thread(target=lambda:notifypy.Notify(
                app_name,
                f"{score:+} {score_word(score)} за привычку \"{data['name']}\"! Теперь у вас за сегодня {data['score']} {score_word(data['score'])}",
                app_name,
                default_notification_icon="dev360_icon.ico").send(), daemon=True).start()

    button.marked = not button.marked
    if habit_id in remind_times.keys():
        remind_times[habit_id]["completed"] = button.marked

def mark_btn_generator(row_widgets: dict[str, QWidget], fields: dict[str, Field], db: DataBase):
    habit = int(row_widgets["id"].text())
    habit_type = int(row_widgets["type"].field_data)

    button = HabitMarkButton(habit_type)
    button.clicked.connect(lambda: mark_btn_clicked(button, habit, db))

    marked = db.cur.execute("SELECT COUNT(*) FROM HabitMarks WHERE habit = ? AND date = ?", (habit, QDate.currentDate().toString(DateField.date_format))).fetchall()[0][0] > 0
    if marked:
        button.setText("Помечена выполненной за сегодня")
        button.setProperty("class", "green-button" if habit_type == 0 else "red-button")
    else:
        button.setText("Пометить выполненной за сегодня")
    button.marked = marked

    if habit in remind_times.keys():
        remind_times[habit]["completed"] = marked

    return button

def habit_row_changed(row_widgets: dict[str, QWidget],  fields: dict[str, Field], additional_columns: dict[str, TableColumn], db: DataBase):
    habit_type: int = int(row_widgets["type"].field_data)
    button: HabitMarkButton = row_widgets["mark_btn"]

    button.habit_type = habit_type
    if button.marked:
        set_class_field(button, "green-button" if habit_type == 0 else "red-button")

def habit_after_save(form_widgets: dict[str, FormFieldWidget], fields: dict[str, Field], db: DataBase):
    habit_id = int(form_widgets["id"].field_widget.text())
    remind_every = form_widgets["remind_every"]
    remind_at = form_widgets["remind_at"]

    remind_every_activated = remind_every.is_activated()
    remind_at_activated = remind_at.is_activated()

    with remind_times_mutex:
        if form_widgets["type"].field_widget.currentData() == 1:
            if habit_id in remind_times.keys():
                del remind_times[habit_id]
            return True, ""

        if habit_id in remind_times.keys():
            if not remind_every_activated and not remind_at_activated:
                del remind_times[habit_id]
                return True, ""
        else:
            remind_times[habit_id] = {}
    
        remind_times[habit_id]["remind_every"] = remind_every.field_widget.value() if remind_every_activated else None
        remind_times[habit_id]["remind_at"] = QTime.toString(remind_at.field_widget.time(), TimeField.time_format) if remind_at_activated else None
        if remind_every_activated:
            if "last_time_reminder" not in remind_times[habit_id].keys() or remind_times[habit_id]["last_time_reminder"] is None:
                remind_times[habit_id]["last_time_reminder"] = QTime.currentTime().addSecs(60*random.randint(30, int(remind_every.field_widget.value())*60))

app = App(app_name, SQLiteDB("dev360.db"), 1280, 720, "dev360_icon.ico")

app.db.cur.execute("""
CREATE TABLE IF NOT EXISTS HabitMarks
(
    habit   INTEGER REFERENCES Habits (id) ON DELETE CASCADE NOT NULL,
    score   INTEGER DEFAULT (0) NOT NULL,
    date    TEXT    UNIQUE NOT NULL,
    FOREIGN KEY (
        habit
    )
    REFERENCES Habits (id) ON DELETE CASCADE
)
""")
app.db.conn.commit()

habits_table = TableTab("Привычки", "Habits", create_form_handler=create_form, table_row_change_handler=habit_row_changed, after_save_handler=habit_after_save,
                        additional_columns=[TableColumn(" "*31, "mark_btn", mark_btn_generator)])
habits_table.add_field(TextLineField("Название", "name", placeholder="Короткое название привычки", not_null=True, column_width=200))
habits_table.add_field(TextAreaField("Описание", "description", placeholder="Описание привычки или комментарий", column_width=300))
habits_table.add_field(ComboBoxField("Тип", "type", StaticItems(["Нужно развивать", "Нужно избавляться"]), column_width=113, on_change_handler=update_habits_type))
habits_table.add_field(ComboBoxField("Сложность привычки", "complexity", StaticItems(["Лёгкая", "Средняя", "Сложная"])))
habits_table.add_field(IntField("Напоминать раз в (часов)", "remind_every", min_value=1, max_value=24, tooltip="Регулярная отправка напоминаний раз в некоторое количество часов", is_optional=True))
habits_table.add_field(TimeField("Напоминать в", "remind_at", column_width=100, is_optional=True))
app.add_tab(habits_table)

notes_table = TableTab("Заметки", "Notes", "Здесь вы можете записывать свои мысли, успехи и трудности, связанные с выполнением привычек. Каждая заметка относится к определённой привычке.")
notes_table.add_field(DateField("Дата", "date", max_date="now", default="now", column_width=100))
notes_table.add_field(ComboBoxField("Привычка", "habit", TableFieldItems("Habits", "name", app.db), column_width=200))
notes_table.add_field(TextAreaField("Текст", "text", placeholder="Текст заметки", column_width=250))
notes_table.add_field(TableField("Прикреплённые изображения", "files", "NotesFiles", [FileField("Имя файла", "name", column_width=200)]))
app.add_tab(notes_table)

habits_report = ReportTab("Отчёт по выполненным привычкам", "", [
    LineChartReport("График выполненных привычек", """
        WITH RECURSIVE
        HM AS (
            SELECT date AS mark_date, type
            FROM HabitMarks
            LEFT JOIN Habits ON Habits.id = HabitMarks.habit
            WHERE 1 {AND habit = :habit} {AND date >= :from} {AND date <= :to}
        ),
        HMType0 AS (
            SELECT mark_date
            FROM HM
            WHERE type = 0
        ),
        HMType1 AS (
            SELECT mark_date
            FROM HM
            WHERE type = 1
        ),
        MinMax AS (
        SELECT
            strftime(IIF(:ctype = '0', '%Y-01-01', IIF(:ctype = '1', '%Y-%m-01', '%Y-%m-%d')), date({MAX(MIN(mark_date), :from)}[MIN(mark_date)], IIF(:ctype = '2', 'weekday 0', '+0 days'))) AS min_date,
            strftime(IIF(:ctype = '0', '%Y-01-01', IIF(:ctype = '1', '%Y-%m-01', '%Y-%m-%d')), date({MIN(MAX(mark_date), :to)}[MAX(mark_date)], IIF(:ctype = '2', 'weekday 0', '+0 days'))) AS max_date
        FROM HM
        ),
        Months AS (
            SELECT min_date AS month_date
            FROM MinMax
            WHERE min_date IS NOT NULL
            UNION ALL
            SELECT date(month_date, IIF(:ctype = '0', '+1 year', IIF(:ctype = '1', '+1 month', IIF(:ctype = '2', '+7 days', '+1 days'))))
            FROM Months
            WHERE month_date < (SELECT max_date FROM MinMax)
        ),
        Type0 AS (
            SELECT
            strftime(IIF(:ctype = '1', '%Y-%m', IIF(:ctype = '3', '%Y-%m-%d', '%Y ')), Months.month_date) || IIF(:ctype = '2', strftime('%W', Months.month_date)+1, '') AS month,
            COUNT(HMType0.mark_date) AS count,
            "Нужно развивать" AS type
            FROM Months
            LEFT JOIN HMType0 ON strftime(IIF(:ctype = '1', '%Y-%m', IIF(:ctype = '3', '%Y-%m-%d', '%Y ')), HMType0.mark_date) || IIF(:ctype = '2', strftime('%W', HMType0.mark_date)+1, '') = month
            GROUP BY Months.month_date
            ORDER BY Months.month_date
        ),
        Type1 AS (
            SELECT
            strftime(IIF(:ctype = '1', '%Y-%m', IIF(:ctype = '3', '%Y-%m-%d', '%Y ')), Months.month_date) || IIF(:ctype = '2', strftime('%W', Months.month_date)+1, '') AS month,
            COUNT(HMType1.mark_date) AS count,
            "Нужно избавляться" AS type
            FROM Months
            LEFT JOIN HMType1 ON strftime(IIF(:ctype = '1', '%Y-%m', IIF(:ctype = '3', '%Y-%m-%d', '%Y ')), HMType1.mark_date) || IIF(:ctype = '2', strftime('%W', HMType1.mark_date)+1, '') = month
            GROUP BY Months.month_date
            ORDER BY Months.month_date
        )
        SELECT * FROM Type0
        UNION
        SELECT * FROM Type1
        ORDER BY month
        """, x="month", values="count", lines="type", int_y_labels=True, stretch=10)],
    [ComboBoxField("Привычка", "habit", TableFieldItems("Habits", "name", app.db), is_optional=True, not_null=True),
     ComboBoxField("Считать по", "ctype", StaticItems(["Годам", "Месяцам", "Неделям", "Дням"]), default=1),
     DateField("С", "from", default="now", tooltip="Начальная дата периода", is_optional=True),
     DateField("До", "to", default="now", tooltip="Конечная дата периода", is_optional=True)])
app.add_tab(habits_report)

score_report = ReportTab("Отчёт по накопленным баллам", "", [
    ListReport("""
        SELECT COALESCE(SUM(HabitMarks.score), 0) AS score
        FROM HabitMarks
        WHERE 1 {AND habit = :habit} {AND date >= :from} {AND date <= :to}
        """, [LabelField("Всего баллов за период", "score")], stretch=1),
    LineChartReport("График распределения баллов по времени", """
        WITH RECURSIVE
        HM AS (
            SELECT * FROM HabitMarks
            WHERE 1 {AND habit = :habit} {AND date >= :from} {AND date <= :to}
        ),
        MinMax AS (
            SELECT
            strftime(IIF(:ctype = '0', '%Y-01-01', IIF(:ctype = '1', '%Y-%m-01', '%Y-%m-%d')), date(MIN(date), IIF(:ctype = '2', 'weekday 0', '+0 days'))) AS min_date,
            strftime(IIF(:ctype = '0', '%Y-01-01', IIF(:ctype = '1', '%Y-%m-01', '%Y-%m-%d')), date(MAX(date), IIF(:ctype = '2', 'weekday 0', '+0 days'))) AS max_date
            FROM HM
        ),
        Months AS (
            SELECT min_date AS month_date
            FROM MinMax
            WHERE min_date IS NOT NULL
            UNION ALL
            SELECT date(month_date, IIF(:ctype = '0', '+1 year', IIF(:ctype = '1', '+1 month', IIF(:ctype = '2', '+7 days', '+1 days'))))
            FROM Months
            WHERE month_date < (SELECT max_date FROM MinMax)
        )
        SELECT
        strftime(IIF(:ctype = '1', '%Y-%m', IIF(:ctype = '3', '%Y-%m-%d', '%Y ')), Months.month_date) || IIF(:ctype = '2', strftime('%W', Months.month_date)+1, '') AS month,
        COALESCE(SUM(HM.score), 0) AS score
        FROM Months
        LEFT JOIN HM ON strftime(IIF(:ctype = '1', '%Y-%m', IIF(:ctype = '3', '%Y-%m-%d', '%Y ')), HM.date) || IIF(:ctype = '2', strftime('%W', HM.date)+1, '') = month
        GROUP BY Months.month_date
        ORDER BY Months.month_date
        """, x="month", values="score", int_y_labels=True, stretch=10)],
    [ComboBoxField("Привычка", "habit", TableFieldItems("Habits", "name", app.db), is_optional=True, not_null=True),
     ComboBoxField("Считать по", "ctype", StaticItems(["Годам", "Месяцам", "Неделям", "Дням"]), default=1),
     DateField("С", "from", default="now", tooltip="Начальная дата периода", is_optional=True),
     DateField("До", "to", default="now", tooltip="Конечная дата периода", is_optional=True)])
app.add_tab(score_report)

remind_times: dict[int, dict] =  {int(x["id"]): {"name": x["name"], "completed": False, "remind_every": x["remind_every"], "remind_at": x["remind_at"], "last_time_reminder": QTime.currentTime().addSecs(60*random.randint(30, int(x["remind_every"])*60)) if x["remind_every"] is not None else None} for x in
                                 app.db.cur.execute("SELECT id, name, remind_every, remind_at FROM Habits WHERE type = 0 AND (remind_every IS NOT NULL OR remind_at IS NOT NULL)").fetchall()
                                 }
remind_times_mutex = threading.Lock()

def notifications():
    while True:
        time.sleep(1)

        with remind_times_mutex:
            current_time = QTime.currentTime()
            current_time_str = current_time.toString(TimeField.time_format)

            find = False
            habit_name = ""
            for remind in remind_times.values():
                if remind["completed"]:
                    continue

                if remind["remind_at"] == current_time_str:
                    find = True
                    habit_name = remind["name"]
                    break
                if remind["remind_every"] is not None and current_time_str == remind["last_time_reminder"].addSecs(60*60*int(remind["remind_every"])).toString(TimeField.time_format):
                    remind["last_time_reminder"] = current_time
                    find = True
                    habit_name = remind["name"]
                    break

        # if find:
        #     threading.Thread(target=lambda:notifypy.Notify(
        #         app_name,
        #         f"Напоминание, что вы должны выполнить привычку \"{habit_name}\"",
        #         app_name,
        #         default_notification_icon="dev360_icon.ico").send(), daemon=True).start()

# threading.Thread(target=notifications, daemon=True).start()

app.run()
