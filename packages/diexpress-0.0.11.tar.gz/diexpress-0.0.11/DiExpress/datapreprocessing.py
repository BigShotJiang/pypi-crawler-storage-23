import os
import random
import csv
import numpy as np
import pandas as pd
import scipy.sparse as sp
# drug graph features
import hickle as hkl
from dataclasses import dataclass

@dataclass
class DataConfig:
    drug_info_file: str
    cell_line_info_file: str
    drug_feature_file: str
    genomic_mutation_file: str
    cancer_response_file: str
    gene_expression_file: str
    methylation_file: str

class DeepCDRDataLoader:
    def __init__(
        self,
        config: DataConfig,
        max_atoms=100,
        train_ratio=0.95,
        seed=0,
    ):
        self.drug_info_file = config.drug_info_file
        self.cell_line_info_file = config.cell_line_info_file
        self.drug_feature_file = config.drug_feature_file
        self.genomic_mutation_file = config.genomic_mutation_file
        self.cancer_response_file = config.cancer_response_file
        self.gene_expression_file = config.gene_expression_file
        self.methylation_file = config.methylation_file

        self.max_atoms = max_atoms
        self.train_ratio = train_ratio
        random.seed(seed)
    
        # ==============================
    # Utility
    # ==============================

    def _normalize_adj(self, adj):
        adj = adj + np.eye(adj.shape[0])
        d = sp.diags(np.power(np.array(adj.sum(1)), -0.5).flatten(), 0).toarray()
        return adj.dot(d).transpose().dot(d)

    def _calculate_graph_feat(self, feat_mat, adj_list):
        feat = np.zeros((self.max_atoms, feat_mat.shape[-1]), dtype="float32")
        adj_mat = np.zeros((self.max_atoms, self.max_atoms), dtype="float32")

        feat[:feat_mat.shape[0], :] = feat_mat

        for i in range(len(adj_list)):
            for node in adj_list[i]:
                adj_mat[i, int(node)] = 1

        adj = adj_mat[: len(adj_list), : len(adj_list)]
        adj_norm = self._normalize_adj(adj)
        adj_mat[: len(adj_list), : len(adj_list)] = adj_norm

        return feat, adj_mat

    # ==============================
    # Metadata
    # ==============================

    def _load_metadata(self):
        # drug id mapping
        reader = csv.reader(open(self.drug_info_file, "r"))
        rows = [item for item in reader]
        drugid2pubchemid = {
            item[0]: item[5] for item in rows if item[5].isdigit()
        }

        # mutation
        mutation_feature = pd.read_csv(
            self.genomic_mutation_file, index_col=0
        )

        # gene expression
        gexpr_feature = pd.read_csv(
            self.gene_expression_file, index_col=0
        )

        mutation_feature = mutation_feature.loc[gexpr_feature.index]

        # methylation
        methylation_feature = pd.read_csv(
            self.methylation_file, index_col=0
        )



        drug_feature = {}
        for file in os.listdir(self.drug_feature_file):
            pubchem_id = file.split(".")[0]
            feat_mat, adj_list, _ = hkl.load(
                f"{self.drug_feature_file}/{file}"
            )
            drug_feature[pubchem_id] = (feat_mat, adj_list)

        # IC50
        experiment_data = pd.read_csv(
            self.cancer_response_exp_file, index_col=0
        )

        data_idx = []

        for drug in experiment_data.index:
            drug_id = drug.split(":")[-1]
            if drug_id not in drugid2pubchemid:
                continue

            pubchem_id = drugid2pubchemid[drug_id]

            if pubchem_id not in drug_feature:
                continue

            for cell in experiment_data.columns:
                if cell not in mutation_feature.index:
                    continue

                value = experiment_data.loc[drug, cell]

                if not np.isnan(value):
                    data_idx.append(
                        (cell, pubchem_id, float(value))
                    )

        return (
            mutation_feature,
            gexpr_feature,
            methylation_feature,
            drug_feature,
            data_idx,
        )

    # ==============================
    # Split
    # ==============================

    def _split_data(self, data_idx):
        train_size = int(len(data_idx) * self.train_ratio)
        random.shuffle(data_idx)
        return data_idx[:train_size], data_idx[train_size:]

    # ==============================
    # Feature Extraction
    # ==============================

    def _feature_extract(
        self,
        data_idx,
        mutation_feature,
        gexpr_feature,
        methylation_feature,
        drug_feature,
    ):
        n = len(data_idx)

        nb_mut = mutation_feature.shape[1]
        nb_gexpr = gexpr_feature.shape[1]
        nb_meth = methylation_feature.shape[1]

        drug_data = []
        mutation_data = np.zeros((n, 1, nb_mut, 1), dtype="float32")
        gexpr_data = np.zeros((n, nb_gexpr), dtype="float32")
        methylation_data = np.zeros((n, nb_meth), dtype="float32")
        target = np.zeros(n, dtype="float32")

        for i, (cell, pubchem_id, ic50) in enumerate(data_idx):
            feat_mat, adj_list = drug_feature[pubchem_id]
            drug_data.append(
                self._calculate_graph_feat(feat_mat, adj_list)
            )

            mutation_data[i, 0, :, 0] = mutation_feature.loc[cell].values
            gexpr_data[i] = gexpr_feature.loc[cell].values
            methylation_data[i] = methylation_feature.loc[cell].values
            target[i] = ic50

        drug_feat = np.array([d[0] for d in drug_data])
        drug_adj = np.array([d[1] for d in drug_data])

        return (
            drug_feat,
            drug_adj,
            mutation_data,
            gexpr_data,
            methylation_data,
            target,
        )

    # ==============================
    # Public API
    # ==============================

    def load_data(self):
        (
            mutation_feature,
            gexpr_feature,
            methylation_feature,
            drug_feature,
            data_idx,
        ) = self._load_metadata()

        train_idx, test_idx = self._split_data(data_idx)

        train_data = self._feature_extract(
            train_idx,
            mutation_feature,
            gexpr_feature,
            methylation_feature,
            drug_feature,
        )

        test_data = self._feature_extract(
            test_idx,
            mutation_feature,
            gexpr_feature,
            methylation_feature,
            drug_feature,
        )

        return train_data, test_data
  
  
