"""
Mojentic LLM registry module for managing model registrations.
"""
