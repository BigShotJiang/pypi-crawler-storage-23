"""
Mojentic context module for managing shared working memory and context.
"""
