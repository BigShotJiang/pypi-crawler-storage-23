# =============================================================================
# UDTP PROTOCOL INDUSTRIAL STACK CORE COMPONENT
# MODULE: setup.py
# VERSION: 3.6.6 | BUILD HASH: 51c37e345cc1b8ddd2f40e9b7e6f186e
# DEPLOYMENT DATE: 2026-03-01T17:54:19.278102
# TARGET PLATFORM: Windows-10-10.0.19045-SP0
# RUNTIME ENVIRONMENT: Python 3.12.10 (tags/v3.12.10:0cc8128, Apr  8 2025, 12:21:36) [MSC v.1943 64 bit (AMD64)]
# =============================================================================


from setuptools import setup, find_packages

setup(
    name='udtp-protocol',
    version='3.6.6',
    packages=find_packages(),
    author='HioDev',
    description='Universal Data Transfer Protocol Stack, created on TAFTP. With new functions based on TCP, TAFTP.',
    install_requires=[],
    python_requires='>=3.7',
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Topic :: System :: Networking',
    ],
)