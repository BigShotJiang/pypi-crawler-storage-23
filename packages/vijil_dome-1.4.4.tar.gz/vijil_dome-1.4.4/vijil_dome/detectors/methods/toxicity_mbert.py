# Copyright 2025 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# vijil and vijil-dome are trademarks owned by Vijil Inc.

import logging
import torch
from vijil_dome.detectors import (
    MODERATION_MBERT,
    register_method,
    DetectionCategory,
    DetectionResult,
    BatchDetectionResult,
)
from transformers import pipeline
from vijil_dome.detectors.utils.hf_model import HFBaseModel
from vijil_dome.detectors.utils.sliding_window import chunk_text
from typing import List, Optional

logger = logging.getLogger("vijil.dome")


@register_method(DetectionCategory.Moderation, MODERATION_MBERT)
class MBertToxicContentModel(HFBaseModel):
    """
    Vijil Finetuned ModernBERT model for toxic content detection.
    https://huggingface.co/vijil/vijil_dome_toxic_content_detection
    """

    def __init__(
        self,
        score_threshold: float = 0.5,
        truncation: bool = True,
        max_length: int = 8192,
        window_stride: int = 4096,
    ):
        """
        Parameters
        ----------
        score_threshold:
            Toxicity probability above which input is flagged.
        truncation:
            Whether to truncate inputs exceeding *max_length*.
        max_length:
            Maximum tokens per window. ModernBERT natively supports up
            to 8192 tokens, so sliding windows only activate for very
            long inputs.
        window_stride:
            Step size in tokens between sliding windows for inputs that
            exceed *max_length*. Default 4096 (half of *max_length*).
        """
        try:
            super().__init__(
                model_name="vijil/vijil_dome_toxic_content_detection",
                tokenizer_name="answerdotai/ModernBERT-base",
            )

            self.score_threshold = score_threshold
            self.max_length = max_length
            self.window_stride = window_stride
            self.classifier = pipeline(
                "text-classification",
                model=self.model,
                tokenizer=self.tokenizer,
                truncation=truncation,
                max_length=max_length,
                device=torch.device("cuda" if torch.cuda.is_available() else "cpu"),
            )
            self.response_string = f"Method:{MODERATION_MBERT}"
            self.run_in_executor = True
            logger.info("Initialized Vijil MBert toxic content model..")
        except Exception as e:
            logger.error(
                f"Failed to initialize MBert toxic content model: {str(e)}"
            )
            raise

    def _extract_toxic_score(self, item):
        if item["label"] in ("toxic", "LABEL_1", 1, "1"):
            return item["score"]
        return 1.0 - item["score"]

    def sync_detect(
        self, query_string: str, agent_id: Optional[str] = None
    ) -> DetectionResult:
        chunks = chunk_text(
            query_string, self.tokenizer, self.max_length, self.window_stride
        )
        num_windows = len(chunks)

        if num_windows == 1:
            pred = self.classifier(query_string)
            toxic_score = self._extract_toxic_score(pred[0])
            flagged = toxic_score >= self.score_threshold
            return flagged, {
                "type": type(self),
                "score": toxic_score,
                "predictions": pred,
                "response_string": self.response_string if flagged else query_string,
                "num_windows": 1,
            }

        # Multi-window: batch all chunks, any-positive with max score
        all_preds = self.classifier(chunks)
        max_score = 0.0
        for window_pred in all_preds:
            item = window_pred[0] if isinstance(window_pred, list) else window_pred
            score = self._extract_toxic_score(item)
            if score > max_score:
                max_score = score

        flagged = max_score >= self.score_threshold
        return flagged, {
            "type": type(self),
            "score": max_score,
            "predictions": all_preds,
            "response_string": self.response_string if flagged else query_string,
            "num_windows": num_windows,
        }

    async def detect(self, query_string: str) -> DetectionResult:
        logger.info(f"Detecting using {self.__class__.__name__}...")
        return self.sync_detect(query_string)

    async def detect_batch(self, inputs: List[str]) -> BatchDetectionResult:
        # Phase 1: chunk each input, build flat list + per-input ranges
        flat_chunks: List[str] = []
        ranges = []
        for text in inputs:
            chunks = chunk_text(
                text, self.tokenizer, self.max_length, self.window_stride
            )
            start = len(flat_chunks)
            flat_chunks.extend(chunks)
            ranges.append((start, len(flat_chunks)))

        # Phase 2: single pipeline call on all chunks
        all_preds = self.classifier(flat_chunks)

        # Phase 3: re-aggregate per input using any-positive with max score
        results = []
        for query_string, (start, end) in zip(inputs, ranges):
            chunk_preds = all_preds[start:end]
            num_windows = end - start
            max_score = 0.0
            for pred in chunk_preds:
                item = pred[0] if isinstance(pred, list) else pred
                score = self._extract_toxic_score(item)
                if score > max_score:
                    max_score = score
            flagged = max_score >= self.score_threshold
            results.append((flagged, {
                "type": type(self),
                "score": max_score,
                "predictions": chunk_preds,
                "response_string": self.response_string if flagged else query_string,
                "num_windows": num_windows,
            }))
        return results
