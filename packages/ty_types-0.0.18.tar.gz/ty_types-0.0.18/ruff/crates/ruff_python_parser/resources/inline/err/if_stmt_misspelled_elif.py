if True:
    pass
elf:
    pass
else:
    pass
