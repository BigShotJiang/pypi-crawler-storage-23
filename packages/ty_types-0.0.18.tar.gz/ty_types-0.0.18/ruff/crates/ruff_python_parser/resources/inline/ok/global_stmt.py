global x
global x, y, z
