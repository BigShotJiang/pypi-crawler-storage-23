type X[**P = *int] = int
type X[**P = yield x] = int
type X[**P = yield from x] = int
type X[**P = x := int] = int
type X[**P = *int] = int
