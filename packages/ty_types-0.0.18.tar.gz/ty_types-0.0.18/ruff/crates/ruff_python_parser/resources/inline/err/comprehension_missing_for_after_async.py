(async)
(x async x in iter)
