match[0]: int
match [x, y, z]: dict
