lambda x: yield y
lambda x: yield from y
