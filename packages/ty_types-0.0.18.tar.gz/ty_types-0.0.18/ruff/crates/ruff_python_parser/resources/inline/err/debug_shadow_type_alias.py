type __debug__ = list[int]  # visited as an Expr but still flagged
type Debug[__debug__] = str
