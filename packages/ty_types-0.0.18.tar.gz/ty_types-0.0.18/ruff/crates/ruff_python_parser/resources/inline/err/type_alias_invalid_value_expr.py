type x = *y
type x = yield y
type x = yield from y
type x = x := 1
