if True:
    \
        1
    \
2
else:\
    3
