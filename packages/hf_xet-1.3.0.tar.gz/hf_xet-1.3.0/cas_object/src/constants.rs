utils::test_configurable_constants! {
    /// Target 1024 chunks per CAS block
    ref XORB_BLOCK_SIZE: usize = 64 * 1024 * 1024;
}
