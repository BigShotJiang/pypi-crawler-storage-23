# ImageStego
ImageStego may be a versatile multimedia processing tool, it features an intuitive web interface built with PyWebIO
## Features

- **Image Obfuscation**  
  Multiple scrambling algorithms to distort images:
  - Pixel Scramble
  - Block Scramble
  - Arnold Cat Map
  - Baker's Map
  - Henon Map

- **GIF Obfuscation**  
  Frame‑wise scrambling of animated GIFs

- **MP4 Obfuscation**  
  Video‑level scrambling using frame permutation.

- **Image Steganography (LSB)**  
  Hide secret messages inside PNG/JPG/BMP images:

