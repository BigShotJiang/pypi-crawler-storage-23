"""opkssh-wrapper: a thin shim that transparently injects opkssh into SSH workflows."""

from __future__ import annotations

__version__ = "0.1.1"
