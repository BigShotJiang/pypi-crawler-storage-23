"""Pluggable sinks for domain events and metrics.

Provides protocols and logging defaults for the ``publish`` and
``emit_metric`` built-in actions.  Users swap in production backends
(Kafka, Redis Pub/Sub, Datadog, etc.) by implementing the protocol
and calling the configure helper.

Usage::

    from pystator import builtin_registries, configure_event_sink

    guards, actions = builtin_registries()          # logging defaults
    configure_event_sink(actions, MyKafkaSink())     # swap in Kafka
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from datetime import datetime, timezone
from typing import Any, Protocol, runtime_checkable

from pystator.actions import ACTION_PARAMS_KEY, ActionRegistry

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Protocols
# ---------------------------------------------------------------------------


@runtime_checkable
class EventSink(Protocol):
    """Protocol for domain event sinks."""

    def send(
        self, topic: str, payload: dict[str, Any], metadata: dict[str, Any]
    ) -> None: ...


@runtime_checkable
class MetricSink(Protocol):
    """Protocol for metric emission sinks."""

    def emit(self, name: str, value: float, tags: dict[str, str]) -> None: ...


# ---------------------------------------------------------------------------
# Default implementations
# ---------------------------------------------------------------------------


class LoggingEventSink:
    """Logs events at INFO. Zero-dependency default."""

    def __init__(self, logger_name: str = "pystator.events") -> None:
        self._logger = logging.getLogger(logger_name)

    def send(
        self, topic: str, payload: dict[str, Any], metadata: dict[str, Any]
    ) -> None:
        self._logger.info("event.%s payload=%s", topic, payload)


class LoggingMetricSink:
    """Logs metrics at INFO. Zero-dependency default."""

    def __init__(self, logger_name: str = "pystator.metrics") -> None:
        self._logger = logging.getLogger(logger_name)

    def emit(self, name: str, value: float, tags: dict[str, str]) -> None:
        self._logger.info("metric.%s value=%s tags=%s", name, value, tags)


# ---------------------------------------------------------------------------
# Factory functions
# ---------------------------------------------------------------------------


def create_publish_action(
    sink: EventSink,
) -> Callable[[dict[str, Any]], None]:
    """Create a ``publish`` action backed by the given EventSink.

    The returned function reads from ``ACTION_PARAMS_KEY``:

    - ``topic`` (str, required): Event topic name.
    - ``include`` (list[str], optional): Context keys to include in
      payload.  If omitted, all non-underscore context keys are sent.

    YAML::

        actions:
          - { name: publish, params: { topic: "order.filled", include: [order_id, fill_qty] } }
    """

    def publish(ctx: dict[str, Any]) -> None:
        params = ctx.get(ACTION_PARAMS_KEY, {})
        topic = params.get("topic")
        if not topic:
            logger.warning("publish: missing 'topic' param")
            return

        include = params.get("include")
        if include and isinstance(include, list):
            payload = {k: ctx.get(k) for k in include}
        else:
            payload = {k: v for k, v in ctx.items() if not k.startswith("_")}

        metadata = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "state": ctx.get("current_state", ctx.get("state")),
            "trigger": ctx.get("trigger"),
        }
        sink.send(topic, payload, metadata)

    return publish


def create_metric_action(
    sink: MetricSink,
) -> Callable[[dict[str, Any]], None]:
    """Create an ``emit_metric`` action backed by the given MetricSink.

    The returned function reads from ``ACTION_PARAMS_KEY``:

    - ``name`` (str, required): Metric name.
    - ``value`` (float, optional): Metric value. Defaults to 1.0.
    - ``type`` (str, optional): ``"counter"`` or ``"gauge"``. Informational.
    - ``tags`` (dict, optional): Additional key-value tags.

    YAML::

        actions:
          - { name: emit_metric, params: { name: "orders.submitted", type: counter } }
    """

    def emit_metric(ctx: dict[str, Any]) -> None:
        params = ctx.get(ACTION_PARAMS_KEY, {})
        metric_name = params.get("name")
        if not metric_name:
            logger.warning("emit_metric: missing 'name' param")
            return

        value = float(params.get("value", 1.0))
        metric_type = params.get("type", "counter")
        tags = dict(params.get("tags", {}))
        tags["metric_type"] = metric_type

        state = ctx.get("current_state", ctx.get("state"))
        if state:
            tags["state"] = str(state)

        sink.emit(metric_name, value, tags)

    return emit_metric


# ---------------------------------------------------------------------------
# Configure helpers
# ---------------------------------------------------------------------------


def configure_event_sink(
    registry: ActionRegistry,
    sink: EventSink | None = None,
) -> None:
    """Register the ``publish`` action backed by the given sink.

    If *sink* is ``None``, uses :class:`LoggingEventSink`.
    Replaces the action if already registered.
    """
    if sink is None:
        sink = LoggingEventSink()
    if registry.has("publish"):
        registry.unregister("publish")
    registry.register("publish", create_publish_action(sink))


def configure_metric_sink(
    registry: ActionRegistry,
    sink: MetricSink | None = None,
) -> None:
    """Register the ``emit_metric`` action backed by the given sink.

    If *sink* is ``None``, uses :class:`LoggingMetricSink`.
    Replaces the action if already registered.
    """
    if sink is None:
        sink = LoggingMetricSink()
    if registry.has("emit_metric"):
        registry.unregister("emit_metric")
    registry.register("emit_metric", create_metric_action(sink))
