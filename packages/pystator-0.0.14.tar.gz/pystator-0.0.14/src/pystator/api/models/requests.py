"""Request models for PyStator API.

Centralizes all request body models used across API routes.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


class LoginRequest(BaseModel):
    """Request body for authentication."""

    username: str = Field(..., description="Username")
    password: str = Field(..., description="Password")


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------


class DatabaseTestRequest(BaseModel):
    """Request body for testing database connection."""

    connection_string: str | None = Field(
        None, description="Full connection string (overrides individual fields)"
    )
    host: str | None = Field(None, description="Database host")
    port: int | None = Field(None, description="Database port")
    database: str | None = Field(None, description="Database name")
    username: str | None = Field(None, description="Database username")
    password: str | None = Field(None, description="Database password")


# ---------------------------------------------------------------------------
# Entities
# ---------------------------------------------------------------------------


class ProcessEntityEventRequest(BaseModel):
    """Request body for processing an event for an entity."""

    trigger: str = Field(..., description="Event trigger name")
    context: dict[str, Any] = Field(
        default_factory=dict, description="Optional context for guards/actions"
    )
    machine_name: str | None = Field(
        None, description="Machine name (required if entity doesn't exist yet)"
    )
    machine_version: str | None = Field(
        None, description="Machine version (defaults to latest)"
    )


# ---------------------------------------------------------------------------
# FSM config operations
# ---------------------------------------------------------------------------


class ProcessRequest(BaseModel):
    """Request body for processing an FSM event."""

    config: dict[str, Any] = Field(
        ...,
        description="FSM configuration (meta, states, transitions, optional error_policy)",
    )
    current_state: str = Field(
        ...,
        description="Current state name of the entity",
    )
    trigger: str = Field(
        ...,
        description="Event trigger name",
    )
    context: dict[str, Any] | None = Field(
        default=None,
        description="Runtime context for guards (e.g. fill_qty, order_qty)",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "config": {
                    "meta": {"machine_name": "order", "version": "1.0"},
                    "states": [
                        {"name": "OPEN", "type": "initial"},
                        {"name": "FILLED", "type": "terminal"},
                    ],
                    "transitions": [
                        {"trigger": "fill", "source": "OPEN", "dest": "FILLED"},
                    ],
                },
                "current_state": "OPEN",
                "trigger": "fill",
                "context": {"fill_qty": 100, "order_qty": 100},
            }
        }
    }


class MachineCreateRequest(BaseModel):
    """Request body for creating/storing an FSM machine in the database."""

    config: dict[str, Any] = Field(
        ...,
        description="Full FSM configuration (meta, states, transitions, error_policy)",
    )


class MachineUpdateRequest(BaseModel):
    """Request body for updating an FSM machine."""

    config: dict[str, Any] = Field(
        ...,
        description="Full FSM configuration to replace existing",
    )


class ValidateRequest(BaseModel):
    """Request body for validating FSM config."""

    config: dict[str, Any] = Field(
        ...,
        description="FSM configuration to validate",
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "config": {
                    "meta": {"machine_name": "order", "version": "1.0"},
                    "states": [
                        {"name": "OPEN", "type": "initial"},
                        {"name": "FILLED", "type": "terminal"},
                    ],
                    "transitions": [
                        {"trigger": "fill", "source": "OPEN", "dest": "FILLED"},
                    ],
                },
            }
        }
    }
