"""Lightweight config parser -- no Pydantic dependency.

Converts raw config dicts directly to core _types objects.
Used when Pydantic is not installed or when validation is disabled.
"""

from __future__ import annotations

from typing import Any

from pystator._types import (
    InvokeSpec,
    Region,
    State,
    StateType,
    Timeout,
    Transition,
    parse_delay,
)
from pystator.config._shared import (
    auto_trigger,
    expand_wildcard_sources,
    implicit_trigger_for_after,
    parse_action_specs,
    parse_guard_specs,
    resolve_entry_exit_points,
)

# ---------------------------------------------------------------------------
# State parsing
# ---------------------------------------------------------------------------


def _parse_state(raw: dict[str, Any]) -> State:
    """Convert a raw state dict to a State object."""
    name = raw["name"]
    state_type = StateType(raw.get("type", "stable"))

    timeout = None
    timeout_raw = raw.get("timeout")
    if timeout_raw and isinstance(timeout_raw, dict):
        timeout = Timeout(
            seconds=float(timeout_raw["seconds"]),
            destination=timeout_raw["destination"],
        )

    regions = tuple(
        Region(
            name=r["name"],
            initial=r["initial"],
            states=tuple(r.get("states", ())),
            description=r.get("description", ""),
            final=r.get("final"),
        )
        for r in raw.get("regions", [])
    )

    invoke = tuple(
        InvokeSpec(
            id=inv["id"],
            src=inv["src"],
            on_done=inv.get("on_done"),
        )
        for inv in raw.get("invoke", [])
    )

    # Collect metadata: explicit metadata field + any extra keys
    known_keys = {
        "name",
        "type",
        "description",
        "parent",
        "initial_child",
        "regions",
        "on_enter",
        "on_exit",
        "invoke",
        "timeout",
        "group",
        "entry_points",
        "exit_points",
        "submachine",
        "metadata",
    }
    metadata = dict(raw.get("metadata", {}))
    for k, v in raw.items():
        if k not in known_keys:
            metadata[k] = v

    return State(
        name=name,
        type=state_type,
        description=raw.get("description", ""),
        parent=raw.get("parent"),
        initial_child=raw.get("initial_child"),
        regions=regions,
        on_enter=parse_action_specs(raw.get("on_enter")),
        on_exit=parse_action_specs(raw.get("on_exit")),
        invoke=invoke,
        timeout=timeout,
        group=raw.get("group"),
        entry_points=tuple(raw.get("entry_points", ())),
        exit_points=tuple(raw.get("exit_points", ())),
        metadata=metadata,
    )


# ---------------------------------------------------------------------------
# Transition parsing
# ---------------------------------------------------------------------------


def _parse_transition(raw: dict[str, Any]) -> Transition:
    """Convert a raw transition dict to a Transition object."""
    source_raw = raw["source"]
    if isinstance(source_raw, str):
        source_list = [source_raw]
    elif isinstance(source_raw, list):
        source_list = list(source_raw)
    else:
        source_list = [str(source_raw)]
    source_set = frozenset(source_list)

    after_ms: int | None = None
    if raw.get("after") is not None:
        after_ms = parse_delay(raw["after"])

    trigger = (raw.get("trigger") or "").strip()

    # Generate synthetic trigger when not provided
    if not trigger:
        if after_ms is not None:
            if len(source_set) != 1:
                raise ValueError(
                    "Delayed transition with implicit trigger must have exactly one source"
                )
            (single_source,) = source_set
            trigger = implicit_trigger_for_after(single_source, after_ms)
        elif raw.get("auto"):
            if len(source_set) != 1:
                raise ValueError(
                    "Auto transition with implicit trigger must have exactly one source"
                )
            (single_source,) = source_set
            trigger = auto_trigger(single_source)
        else:
            raise ValueError(
                "Transition must have either 'trigger', 'after', or 'auto: true'"
            )

    region = raw.get("region")
    if not isinstance(region, str):
        region = None

    # Merge ref (single) and refs (list) into one tuple
    refs_list: list[str] = list(raw.get("refs", []))
    ref_single = raw.get("ref")
    if ref_single and isinstance(ref_single, str):
        refs_list.insert(0, ref_single)
    refs = tuple(refs_list)

    # Collect metadata: explicit metadata field + any extra keys
    known_keys = {
        "trigger",
        "source",
        "dest",
        "region",
        "guards",
        "actions",
        "after",
        "internal",
        "auto",
        "priority",
        "description",
        "ref",
        "refs",
        "metadata",
    }
    metadata = dict(raw.get("metadata", {}))
    for k, v in raw.items():
        if k not in known_keys:
            metadata[k] = v

    return Transition(
        trigger=trigger,
        source=source_set,
        dest=raw["dest"],
        region=region,
        guards=parse_guard_specs(raw.get("guards")),
        actions=parse_action_specs(raw.get("actions")),
        after=after_ms,
        internal=bool(raw.get("internal", False)),
        auto=bool(raw.get("auto", False)),
        priority=raw.get("priority"),
        description=raw.get("description", ""),
        refs=refs,
        metadata=metadata,
    )


# ---------------------------------------------------------------------------
# Meta parsing
# ---------------------------------------------------------------------------


def _parse_meta(raw: Any) -> dict[str, Any]:
    """Parse the meta section of a config dict."""
    if not raw or not isinstance(raw, dict):
        return {}

    meta: dict[str, Any] = {}
    if raw.get("version") is not None:
        meta["version"] = raw["version"]
    if raw.get("machine_name") is not None:
        meta["machine_name"] = raw["machine_name"]
    meta["strict_mode"] = raw.get("strict_mode", True)
    if raw.get("event_normalizer") is not None:
        meta["event_normalizer"] = raw["event_normalizer"]
    if raw.get("description") is not None:
        meta["description"] = raw["description"]
    meta["validate_context"] = raw.get("validate_context", False)

    # Extra keys in meta (forward compatibility)
    known_meta_keys = {
        "version",
        "machine_name",
        "strict_mode",
        "event_normalizer",
        "description",
        "validate_context",
    }
    for k, v in raw.items():
        if k not in known_meta_keys:
            meta[k] = v

    return meta


# ---------------------------------------------------------------------------
# Top-level conversion
# ---------------------------------------------------------------------------


def raw_config_to_core(
    config: dict[str, Any],
) -> tuple[dict[str, State], list[Transition], dict[str, Any]]:
    """Convert a raw config dict to (states, transitions, meta).

    No Pydantic required. Performs basic structural conversion but not
    schema validation. For full validation, install ``pystator[validation]``.
    """
    states_raw = config.get("states", [])
    transitions_raw = config.get("transitions", [])

    if not states_raw:
        raise ValueError("At least one state is required")

    states = {}
    for s in states_raw:
        state = _parse_state(s)
        states[state.name] = state

    transitions = [_parse_transition(t) for t in transitions_raw]

    # Expand wildcard sources
    transitions = expand_wildcard_sources(states, transitions)

    # Resolve entry/exit point references
    transitions = resolve_entry_exit_points(states, transitions)

    meta = _parse_meta(config.get("meta"))

    # Groups (state grouping metadata)
    groups_raw = config.get("groups")
    if groups_raw and isinstance(groups_raw, dict):
        meta["groups"] = groups_raw

    # State variables (metadata)
    sv_raw = config.get("state_variables")
    if sv_raw and isinstance(sv_raw, list):
        normalized = []
        for item in sv_raw:
            if isinstance(item, str):
                normalized.append({"key": item})
            elif isinstance(item, dict):
                normalized.append(item)
            else:
                normalized.append({"key": str(item)})
        meta["state_variables"] = normalized

    events_raw = config.get("events")
    if events_raw is not None:
        meta["events"] = events_raw

    return states, transitions, meta
