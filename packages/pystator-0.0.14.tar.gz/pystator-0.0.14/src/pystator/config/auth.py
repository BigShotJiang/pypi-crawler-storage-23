"""Auth for PyStator API. Env or pystator.cfg [auth]; keys = env names (e.g. PYSTATOR_AUTH_JWT_SECRET)."""

from __future__ import annotations

import os
from configparser import ConfigParser

from pystator.config.paths import find_config_file


def _cfg(section: str, key: str) -> str | None:
    cfg_path = find_config_file("pystator.cfg")
    if not cfg_path:
        return None
    try:
        cfg = ConfigParser()
        cfg.read(cfg_path)
        if cfg.has_section(section):
            return cfg.get(section, key, fallback=None)
    except Exception:
        pass
    return None


def get_auth_initial_credentials() -> tuple[str, str] | None:
    u = os.getenv("PYSTATOR_AUTH_INITIAL_USERNAME") or _cfg(
        "auth", "PYSTATOR_AUTH_INITIAL_USERNAME"
    )
    p = os.getenv("PYSTATOR_AUTH_INITIAL_PASSWORD") or _cfg(
        "auth", "PYSTATOR_AUTH_INITIAL_PASSWORD"
    )
    if u and p:
        return (u.strip(), p.strip())
    return None


def get_auth_jwt_secret() -> str | None:
    return os.getenv("PYSTATOR_AUTH_JWT_SECRET") or _cfg(
        "auth", "PYSTATOR_AUTH_JWT_SECRET"
    )


def get_auth_service_url() -> str | None:
    url = os.getenv("PYSTATOR_AUTH_SERVICE_URL") or _cfg(
        "auth", "PYSTATOR_AUTH_SERVICE_URL"
    )
    return url.rstrip("/") if url else None


def get_auth_service_introspect_path() -> str | None:
    return os.getenv("PYSTATOR_AUTH_SERVICE_INTROSPECT_PATH") or _cfg(
        "auth", "PYSTATOR_AUTH_SERVICE_INTROSPECT_PATH"
    )


def is_auth_disabled() -> bool:
    raw = (
        os.getenv("PYSTATOR_AUTH_DISABLED")
        or _cfg("auth", "PYSTATOR_AUTH_DISABLED")
        or ""
    )
    if raw.strip().lower() in ("1", "true", "yes"):
        return True
    if get_auth_service_url():
        return False
    if get_auth_initial_credentials() and get_auth_jwt_secret():
        return False
    return True
