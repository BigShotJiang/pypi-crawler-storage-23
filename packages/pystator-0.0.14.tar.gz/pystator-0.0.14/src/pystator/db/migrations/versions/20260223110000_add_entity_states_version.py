"""Add version column to entity_states for optimistic locking

Revision ID: 20260223110000
Revises: 20260223100000
Create Date: 2026-02-23

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260223110000"
down_revision: str | None = "20260223100000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    """Use pystator schema for PostgreSQL; None for SQLite (no schema support)."""
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()
    op.add_column(
        "entity_states",
        sa.Column("version", sa.Integer(), nullable=False, server_default=sa.text("1")),
        schema=schema_name,
    )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_column("entity_states", "version", schema=schema_name)
