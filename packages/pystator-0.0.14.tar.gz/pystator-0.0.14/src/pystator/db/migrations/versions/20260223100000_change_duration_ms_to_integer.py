"""Change transition_history.duration_ms from String to Integer

Revision ID: 20260223100000
Revises: 20260219000000
Create Date: 2026-02-23

"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20260223100000"
down_revision: str | None = "20260219000000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    """Use pystator schema for PostgreSQL; None for SQLite (no schema support)."""
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()
    if schema_name is None:
        # SQLite: batch_alter_table recreates the table and copies data
        with op.batch_alter_table("transition_history") as batch_op:
            batch_op.alter_column(
                "duration_ms",
                existing_type=sa.String(50),
                type_=sa.Integer(),
                existing_nullable=True,
            )
    else:
        # PostgreSQL: alter column with USING to cast existing string data
        op.alter_column(
            "transition_history",
            "duration_ms",
            existing_type=sa.String(50),
            type_=sa.Integer(),
            existing_nullable=True,
            schema=schema_name,
            postgresql_using="NULLIF(trim(duration_ms), '')::integer",
        )


def downgrade() -> None:
    schema_name = _schema()
    if schema_name is None:
        with op.batch_alter_table("transition_history") as batch_op:
            batch_op.alter_column(
                "duration_ms",
                existing_type=sa.Integer(),
                type_=sa.String(50),
                existing_nullable=True,
            )
    else:
        op.alter_column(
            "transition_history",
            "duration_ms",
            existing_type=sa.Integer(),
            type_=sa.String(50),
            existing_nullable=True,
            schema=schema_name,
        )
