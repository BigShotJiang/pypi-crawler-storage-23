"""Built-in guards and actions for PyStator.

Universal, domain-agnostic guards and actions that can be referenced by name
in YAML configs with zero custom Python.

Guards:
    always        -- always passes (stub, testing)
    never         -- always blocks (disable transition, testing)
    key_present   -- context key is not None (parameterized)
    key_missing   -- context key is None (parameterized)

Actions:
    noop          -- does nothing (placeholder, stub)
    log           -- logs transition info (parameterized: message, level)
    trace         -- appends to ctx["_trace"] for test assertions
    set_context   -- copies action params into context
    snapshot      -- deep-copies context to ctx["_snapshots"] (parameterized: label)
    copy_key      -- copies one context key to another (parameterized: from, to)
    validate_keys -- checks required keys exist (parameterized: required)
    publish       -- sends event via EventSink (parameterized: topic, include)
    emit_metric   -- emits metric via MetricSink (parameterized: name, value, type, tags)

Usage::

    from pystator import builtin_registries

    guards, actions = builtin_registries()
    machine = StateMachine.from_yaml("my_fsm.yaml")
    # guards and actions are ready to use by name in the YAML
"""

from __future__ import annotations

import copy
import logging
from datetime import datetime, timezone
from typing import Any

from pystator.actions import ACTION_PARAMS_KEY, ActionRegistry
from pystator.guards import GUARD_PARAMS_KEY, GuardRegistry

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Guards
# ---------------------------------------------------------------------------


def always(ctx: dict[str, Any]) -> bool:
    """Always returns True. Use as a stub or to mark a transition as unconditional."""
    return True


def never(ctx: dict[str, Any]) -> bool:
    """Always returns False. Use to disable a transition or in tests."""
    return False


def key_present(ctx: dict[str, Any]) -> bool:
    """True if the named context key exists and is not None.

    The key name comes from guard params::

        guards:
          - name: key_present
            params: { key: order_id }

    Without params, checks for the literal key ``"key"``.
    """
    params = ctx.get(GUARD_PARAMS_KEY, {})
    key = params.get("key", "key")
    return ctx.get(key) is not None


def key_missing(ctx: dict[str, Any]) -> bool:
    """True if the named context key is absent or None.

    The key name comes from guard params::

        guards:
          - name: key_missing
            params: { key: error }

    Without params, checks for the literal key ``"key"``.
    """
    params = ctx.get(GUARD_PARAMS_KEY, {})
    key = params.get("key", "key")
    return ctx.get(key) is None


# ---------------------------------------------------------------------------
# Actions
# ---------------------------------------------------------------------------


def noop(ctx: dict[str, Any]) -> None:
    """Does nothing. Use as an explicit placeholder or stub action."""
    pass


def log(ctx: dict[str, Any]) -> None:
    """Log a message with transition context.

    Parameterized via ActionSpec.params::

        actions:
          - name: log
            params: { message: "Order submitted", level: "info" }

    Supported levels: debug, info, warning, error. Defaults to info.
    If no message param is provided, logs a default transition summary.
    """
    params = ctx.get(ACTION_PARAMS_KEY, {})
    level_name = params.get("level", "info").lower()
    level = getattr(logging, level_name.upper(), logging.INFO)

    message = params.get("message")
    if message is None:
        state = ctx.get("current_state", ctx.get("state", "?"))
        trigger = ctx.get("trigger", "?")
        dest = ctx.get("dest", ctx.get("destination", "?"))
        message = f"{trigger}: {state} -> {dest}"

    logger.log(level, message)


def trace(ctx: dict[str, Any]) -> None:
    """Append a trace entry to ctx["_trace"] for test assertions.

    Each entry is a dict with action name, state, trigger, and timestamp.
    In tests::

        ctx = {"order_id": "123"}
        # ... process transitions ...
        assert len(ctx["_trace"]) == 2
        assert ctx["_trace"][0]["action"] == "trace"
    """
    entry = {
        "action": "trace",
        "state": ctx.get("current_state", ctx.get("state")),
        "trigger": ctx.get("trigger"),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    ctx.setdefault("_trace", []).append(entry)


def set_context(ctx: dict[str, Any]) -> None:
    """Copy action params into context.

    Lets you set arbitrary context keys from YAML without writing Python::

        actions:
          - name: set_context
            params: { status: "processing", attempts: 0 }

    After execution, ``ctx["status"] == "processing"`` and ``ctx["attempts"] == 0``.
    """
    params = ctx.get(ACTION_PARAMS_KEY, {})
    ctx.update(params)


def snapshot(ctx: dict[str, Any]) -> None:
    """Deep-copy current context to ctx["_snapshots"] for debugging, audit, or rollback.

    Only non-underscore keys are captured (avoids copying internal machinery
    and the ``_snapshots`` list itself).

    Parameterized via ActionSpec.params::

        actions:
          - { name: snapshot, params: { label: "pre_execution" } }

    Without a label param, the label defaults to the current ISO timestamp.
    """
    params = ctx.get(ACTION_PARAMS_KEY, {})
    label = params.get("label", datetime.now(timezone.utc).isoformat())

    entry = {
        "label": label,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "data": {k: v for k, v in copy.deepcopy(ctx).items() if not k.startswith("_")},
    }
    ctx.setdefault("_snapshots", []).append(entry)


def copy_key(ctx: dict[str, Any]) -> None:
    """Copy value from one context key to another.

    Silent no-op if the source key is absent. Logs a warning if
    required params (``from``, ``to``) are missing.

    Parameterized via ActionSpec.params::

        actions:
          - { name: copy_key, params: { from: current_price, to: entry_price } }
    """
    params = ctx.get(ACTION_PARAMS_KEY, {})
    src = params.get("from")
    dst = params.get("to")
    if not src or not dst:
        logger.warning("copy_key: missing 'from' or 'to' param")
        return
    if src in ctx:
        ctx[dst] = ctx[src]


def validate_keys(ctx: dict[str, Any]) -> None:
    """Check that required context keys exist and are not None.

    Does NOT raise — logs at WARNING level for each missing key and
    appends missing key names to ``ctx["_validation_errors"]`` so
    downstream guards or actions can inspect them.

    Parameterized via ActionSpec.params::

        actions:
          - { name: validate_keys, params: { required: [order_id, quantity] } }
    """
    params = ctx.get(ACTION_PARAMS_KEY, {})
    required = params.get("required", [])
    if not isinstance(required, list):
        logger.warning("validate_keys: 'required' param must be a list")
        return

    missing = [k for k in required if ctx.get(k) is None]
    if missing:
        for key in missing:
            logger.warning("validate_keys: required key '%s' is missing or None", key)
        ctx.setdefault("_validation_errors", []).extend(missing)


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

_BUILTIN_GUARDS: dict[str, Any] = {
    "always": always,
    "never": never,
    "key_present": key_present,
    "key_missing": key_missing,
}

_BUILTIN_ACTIONS: dict[str, Any] = {
    "noop": noop,
    "log": log,
    "trace": trace,
    "set_context": set_context,
    "snapshot": snapshot,
    "copy_key": copy_key,
    "validate_keys": validate_keys,
}


def register_builtins(
    guard_registry: GuardRegistry | None = None,
    action_registry: ActionRegistry | None = None,
) -> tuple[GuardRegistry, ActionRegistry]:
    """Register all built-in guards and actions into the given registries.

    Creates new registries if ``None`` is passed.
    Returns ``(guard_registry, action_registry)``.
    """
    if guard_registry is None:
        guard_registry = GuardRegistry()
    if action_registry is None:
        action_registry = ActionRegistry()

    for name, func in _BUILTIN_GUARDS.items():
        if not guard_registry.has(name):
            guard_registry.register(name, func)

    for name, func in _BUILTIN_ACTIONS.items():
        if not action_registry.has(name):
            action_registry.register(name, func)

    # Wire adapter-backed actions with logging defaults
    from pystator.sinks import configure_event_sink, configure_metric_sink

    if not action_registry.has("publish"):
        configure_event_sink(action_registry)
    if not action_registry.has("emit_metric"):
        configure_metric_sink(action_registry)

    return guard_registry, action_registry


def builtin_registries() -> tuple[GuardRegistry, ActionRegistry]:
    """Create fresh registries with all builtins pre-registered."""
    return register_builtins()
