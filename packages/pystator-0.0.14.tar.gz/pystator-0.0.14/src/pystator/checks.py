"""Declarative guard check evaluation for PyStator FSM.

Checks are simple, inline field conditions expressed in YAML config
without requiring Python functions or simpleeval. They are the guard-side
counterpart to declarative effects.

Supported operators:
    eq       -- ctx[field] == value
    neq      -- ctx[field] != value
    gt       -- ctx[field] > value
    gte      -- ctx[field] >= value
    lt       -- ctx[field] < value
    lte      -- ctx[field] <= value
    in       -- ctx[field] in values
    not_in   -- ctx[field] not in values
    is_set   -- ctx.get(field) is not None
    is_null  -- ctx.get(field) is None
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pystator._types import CheckSpec


def evaluate_check(check: CheckSpec, ctx: dict[str, Any]) -> bool:
    """Evaluate a declarative check against a context dict.

    Args:
        check: The CheckSpec defining field, operator, and comparison value(s).
        ctx: Context dict to check against.

    Returns:
        True if the check passes, False otherwise.

    Raises:
        ValueError: If the operator is unknown.
    """
    field_val = ctx.get(check.field)
    op = check.op

    # Nullability checks (no comparison value needed)
    if op == "is_set":
        return field_val is not None
    if op == "is_null":
        return field_val is None

    # Collection membership checks
    if op == "in":
        return field_val in check.values
    if op == "not_in":
        return field_val not in check.values

    # Comparison checks (require non-None field value for ordering)
    if op == "eq":
        return field_val == check.value
    if op == "neq":
        return field_val != check.value

    if field_val is None:
        return False

    if op == "gt":
        return field_val > check.value
    if op == "gte":
        return field_val >= check.value
    if op == "lt":
        return field_val < check.value
    if op == "lte":
        return field_val <= check.value

    raise ValueError(f"Unknown check operator: {op}")
