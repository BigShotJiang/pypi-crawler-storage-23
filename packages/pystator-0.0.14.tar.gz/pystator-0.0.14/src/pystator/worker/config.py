"""Worker config. Env PYSTATOR_WORKER_* or pystator.cfg [worker] with same keys (e.g. PYSTATOR_WORKER_DB_URL)."""

from __future__ import annotations

import os
import platform
import uuid
from configparser import ConfigParser
from dataclasses import dataclass, field

from pystator.config.database import get_database_url
from pystator.config.paths import find_config_file
from pystator.db.config import get_db_url

_PREFIX = "PYSTATOR_WORKER_"


def _default_worker_id() -> str:
    host = platform.node() or "worker"
    return f"{host}-{os.getpid()}-{uuid.uuid4().hex[:8]}"


def _read_worker_cfg() -> dict[str, str]:
    path = find_config_file("pystator.cfg")
    if not path:
        return {}
    p = ConfigParser()
    p.read(path)
    if not p.has_section("worker"):
        return {}
    return dict(p.items("worker"))


def _env(suffix: str) -> str | None:
    return os.getenv(_PREFIX + suffix)


@dataclass
class WorkerConfig:
    db_url: str | None = None
    poll_interval_ms: int = 500
    concurrency: int = 5
    drain_timeout_s: int = 30
    max_attempts: int = 5
    machine_source: str = "db"
    machine_dir: str | None = None
    worker_id: str = field(default_factory=_default_worker_id)
    claim_lease_timeout_s: int = 300
    retry_backoff_base_ms: int = 1000
    retry_backoff_max_ms: int = 300000

    def __post_init__(self) -> None:
        cfg = _read_worker_cfg()

        def _get(suffix: str) -> str | None:
            return _env(suffix) or cfg.get(_PREFIX + suffix)

        if self.db_url is None:
            self.db_url = _get("DB_URL") or get_database_url()
        self.poll_interval_ms = int(_get("POLL_INTERVAL_MS") or self.poll_interval_ms)
        self.concurrency = int(_get("CONCURRENCY") or self.concurrency)
        self.drain_timeout_s = int(_get("DRAIN_TIMEOUT_S") or self.drain_timeout_s)
        self.max_attempts = int(_get("MAX_ATTEMPTS") or self.max_attempts)
        self.machine_source = _get("MACHINE_SOURCE") or self.machine_source
        if self.machine_dir is None:
            self.machine_dir = _get("MACHINE_DIR")
        wid = _get("ID")
        if wid:
            self.worker_id = wid
        self.claim_lease_timeout_s = int(
            _get("CLAIM_LEASE_TIMEOUT_S") or self.claim_lease_timeout_s
        )
        self.retry_backoff_base_ms = int(
            _get("RETRY_BACKOFF_BASE_MS") or self.retry_backoff_base_ms
        )
        self.retry_backoff_max_ms = int(
            _get("RETRY_BACKOFF_MAX_MS") or self.retry_backoff_max_ms
        )

    def resolve_db_url(self) -> str:
        return get_db_url(self.db_url, required=True)
