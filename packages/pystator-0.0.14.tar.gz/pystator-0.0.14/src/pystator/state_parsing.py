"""Parse stored state string into single state or parallel config.

Used by Orchestrator/EntitySession to support both single-state and
parallel-state persistence with a single string store.
"""

from __future__ import annotations

from collections.abc import Callable

from pystator._parallel import ParallelStateConfig


def parse_stored_state(
    value: str,
    is_parallel_state: Callable[[str], bool],
) -> str | ParallelStateConfig:
    """Parse a stored state string into either a single state or a parallel config.

    If value contains ":" and parses as a valid parallel config for a parallel
    state, returns ParallelStateConfig. Otherwise returns the string as single state.

    Args:
        value: The stored state string (e.g. "pending" or "P:r1=a,r2=b").
        is_parallel_state: Callable(state_name) -> bool for the machine.

    Returns:
        Either the single state name (str) or a ParallelStateConfig.
    """
    if not value or ":" not in value:
        return value
    config = ParallelStateConfig.from_string(value)
    if is_parallel_state(config.parallel_state) and config.region_states:
        return config
    return value
