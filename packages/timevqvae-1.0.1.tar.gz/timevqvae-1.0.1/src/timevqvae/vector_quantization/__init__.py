from timevqvae.vector_quantization.vq import VectorQuantize as VectorQuantize

