"""Core model components."""
