# Yuino protobuf
### Build
```shell
protoc --python_out=. ./yuino.proto
```
