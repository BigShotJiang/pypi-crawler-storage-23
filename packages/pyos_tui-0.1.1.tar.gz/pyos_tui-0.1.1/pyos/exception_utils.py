from loguru import logger
import traceback

def try_make_lines(context, remaining_height):
    try:
        line_printers = context["line_generator"](context, remaining_height)
        return line_printers
    except Exception as e:
        raise Exception("Problem with line generator") from e


def try_print_line(line_printer, screen, y):
    try:
        line_printer(screen, y)
    except Exception as e:
        raise Exception(f"problem with line printer {line_printer} at y={y}") from e
