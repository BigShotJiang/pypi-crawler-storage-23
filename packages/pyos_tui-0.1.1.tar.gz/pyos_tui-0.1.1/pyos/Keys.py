import curses

LEFT_BRACKET = 91
RIGHT_BRACKET = 93
ESC = 27
ENTER = 10
BACKSPACE = 8
TAB = 9
CTRL_F = 6
F1 = 265
F5 = 269
FORWARD_SLASH = 47
UP = curses.KEY_UP
DOWN = curses.KEY_DOWN
LEFT = curses.KEY_LEFT
RIGHT = curses.KEY_RIGHT

_NORMALIZE = {
    13: ENTER,
    curses.KEY_ENTER: ENTER,
    127: BACKSPACE,
    curses.KEY_BACKSPACE: BACKSPACE,
}


def normalize(key_code):
    """Map platform-variant key codes to their canonical Keys constant."""
    return _NORMALIZE.get(key_code, key_code)