# printers/TopBar.py
import curses
from .printers import print_empty_line

def make_top_bar(context, remaining_height):
    def print_top_bar(screen, y):
        _, num_cols = screen.getmaxyx()
        items = [text for key, text in context["items"].items()]
        text = " | ".join(items)
        clipped = text[: max(0, num_cols - 1)]
        screen.addstr(y, 0, clipped, curses.A_BOLD)
    return [print_top_bar, print_empty_line]


class TopBar:
    @staticmethod
    def layout():
        return {"height": 2}

    @staticmethod
    def display_state(items=None):
        if items is None:
            items = {}
        return {
            "items": items,
            "layout": TopBar.layout(),
            "line_generator": make_top_bar
        }
