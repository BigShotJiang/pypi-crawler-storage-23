# printers/HorizontalBar.py

from .printers import make_horizontal_bar

class HorizontalBar:
    @staticmethod
    def layout():
        return {"height": 1}

    @staticmethod
    def display_state():
        return {
            "layout": HorizontalBar.layout(),
            "line_generator": make_horizontal_bar
        }
