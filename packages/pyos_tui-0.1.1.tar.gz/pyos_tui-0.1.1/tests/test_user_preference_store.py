"""Tests for pyos/db/UserPreferenceStore.py — SQLite-backed key/value store."""

import pytest

from pyos.db.UserPreferenceStore import UserPreferenceStore


@pytest.fixture
def store(tmp_path):
    """Create a UserPreferenceStore backed by a temp database."""
    db_path = str(tmp_path / "test_prefs.db")
    return UserPreferenceStore(db_path)


class TestUserPreferenceStore:
    def test_roundtrip(self, store):
        store.set("color", "blue")
        assert store.get("color") == "blue"

    def test_get_missing_key_returns_default(self, store):
        assert store.get("nonexistent") == ""

    def test_get_with_custom_default(self, store):
        assert store.get("nonexistent", "fallback") == "fallback"

    def test_set_overwrites_existing(self, store):
        store.set("k", "v1")
        store.set("k", "v2")
        assert store.get("k") == "v2"

    def test_set_none_value(self, store):
        """Type surprise: None is stored and returned as None, not as string 'None'."""
        store.set("k", None)
        result = store.get("k")
        assert result is None

    def test_multiple_independent_keys(self, store):
        store.set("a", "1")
        store.set("b", "2")
        assert store.get("a") == "1"
        assert store.get("b") == "2"

    def test_empty_string_key_and_value(self, store):
        store.set("", "")
        assert store.get("") == ""
