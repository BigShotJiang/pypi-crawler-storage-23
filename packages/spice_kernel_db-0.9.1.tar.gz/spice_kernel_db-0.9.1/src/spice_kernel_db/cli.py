"""Command-line interface for spice-kernel-db."""

from __future__ import annotations

import argparse
import sys
import urllib.error
import urllib.request
from pathlib import Path

from rich.console import Console
from rich.table import Table

from spice_kernel_db.config import (
    ensure_config,
    setup_interactive,
    show_config,
)
from spice_kernel_db.db import KernelDB
from spice_kernel_db.remote import (
    SPICE_SERVERS,
    check_mk_availability,
    list_remote_metakernels,
    list_remote_missions,
)

console = Console()


def main(argv: list[str] | None = None):
    config = ensure_config()

    # ANSI green for command names when outputting to a terminal
    if sys.stdout.isatty():
        _g, _r = "\033[1;32m", "\033[0m"
    else:
        _g, _r = "", ""

    _EPILOG = f"""\
commands:
  browse & acquire:
    {_g}browse{_r}          Browse remote metakernels in a NAIF mk/ directory
    {_g}get{_r}             Download missing kernels for a remote metakernel
    {_g}update{_r}          Re-fetch a metakernel and download new kernels

  inspect:
    {_g}check{_r}           Check which kernels in a metakernel are available locally
    {_g}coverage{_r}        Check SPK body coverage in a metakernel
    {_g}metakernels{_r}     List tracked metakernels or show details  (alias: {_g}mk{_r})
    {_g}resolve{_r}         Find local path for a kernel filename
    {_g}stats{_r}           Show database statistics
    {_g}duplicates{_r}      Report duplicate kernels

  transform:
    {_g}scan{_r}            Scan a directory for kernel files
    {_g}rewrite{_r}         Rewrite a metakernel with a local symlink tree
    {_g}dedup{_r}           Deduplicate kernel files using symlinks

  configure:
    {_g}mission{_r}         Manage configured missions
    {_g}config{_r}          Show or update configuration
    {_g}reset{_r}           Delete the database and start fresh
"""

    parser = argparse.ArgumentParser(
        prog="spice-kernel-db",
        usage="%(prog)s [-h] [--db DB] {command} ...",
        description="Browse, get, and manage SPICE kernels and metakernels",
        epilog=_EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--db", default=config.db_path,
        help=f"Path to DuckDB database file (default: {config.db_path})",
    )
    sub = parser.add_subparsers(dest="command", metavar="{command}", help=argparse.SUPPRESS)

    # --- scan ---
    p_scan = sub.add_parser("scan", help="Scan a directory for kernel files")
    p_scan.add_argument("directory", help="Root directory to scan recursively")
    p_scan.add_argument(
        "--mission", help="Override auto-detected mission name"
    )
    p_scan.add_argument(
        "-v", "--verbose", action="store_true",
        help="Print each registered file",
    )
    p_scan.add_argument(
        "--archive", action="store_true",
        help="Move files to the configured kernel directory and leave symlinks",
    )

    # --- stats ---
    sub.add_parser("stats", help="Show database statistics")

    # --- duplicates ---
    sub.add_parser("duplicates", help="Report duplicate kernels")

    # --- check ---
    p_check = sub.add_parser(
        "check", help="Check which kernels in a metakernel are available locally"
    )
    p_check.add_argument(
        "metakernel", nargs="?", default=None,
        help="Path to .tm file (omit to select from local registry)",
    )
    p_check.add_argument("--mission", help="Override mission name")
    p_check.add_argument(
        "-v", "--verbose", action="store_true",
        help="Show full per-file warnings instead of summary",
    )

    # --- rewrite ---
    p_rewrite = sub.add_parser(
        "rewrite",
        help="Rewrite a metakernel with a local symlink tree",
    )
    p_rewrite.add_argument("metakernel", help="Path to original .tm file")
    p_rewrite.add_argument(
        "-o", "--output", required=True,
        help="Output .tm path",
    )
    p_rewrite.add_argument(
        "--link-root",
        help="Root for symlink tree (default: kernels/ next to output)",
    )
    p_rewrite.add_argument("--mission", help="Override mission name")

    # --- dedup ---
    p_dedup = sub.add_parser(
        "dedup", help="Deduplicate kernel files using symlinks"
    )
    p_dedup.add_argument(
        "--execute", action="store_true",
        help="Actually replace files (default: dry run)",
    )

    # --- resolve ---
    p_resolve = sub.add_parser(
        "resolve", help="Find local path for a kernel filename"
    )
    p_resolve.add_argument("filename", help="Kernel filename to resolve")
    p_resolve.add_argument("--mission", help="Preferred mission")

    # --- metakernels ---
    p_mk = sub.add_parser(
        "metakernels", aliases=["mk"],
        help="List tracked metakernels or show details",
    )
    p_mk.add_argument(
        "name", nargs="?",
        help="Show info for a specific metakernel (by filename)",
    )
    p_mk.add_argument("--mission", help="Filter by mission name")

    # --- get ---
    p_get = sub.add_parser(
        "get",
        help="Download missing kernels for a remote metakernel",
    )
    p_get.add_argument(
        "url", nargs="?", default=None,
        help="URL or filename of a .tm metakernel (omit to select interactively)",
    )
    p_get.add_argument(
        "--download-dir", default=config.kernel_dir,
        help=f"Directory for downloaded kernels (default: {config.kernel_dir})",
    )
    p_get.add_argument("--mission", help="Override auto-detected mission name")
    p_get.add_argument(
        "-y", "--yes", action="store_true",
        help="Skip confirmation prompt",
    )

    # --- update ---
    p_update = sub.add_parser(
        "update",
        help="Re-fetch a metakernel from its source and download new kernels",
    )
    p_update.add_argument(
        "metakernel", nargs="?", default=None,
        help="Metakernel filename or path (omit to select interactively)",
    )
    p_update.add_argument("--mission", help="Override mission name")
    p_update.add_argument(
        "--download-dir", default=config.kernel_dir,
        help=f"Directory for downloaded kernels (default: {config.kernel_dir})",
    )
    p_update.add_argument(
        "-y", "--yes", action="store_true",
        help="Skip confirmation prompt",
    )

    # --- browse ---
    p_browse = sub.add_parser(
        "browse",
        help="Browse remote metakernels in a NAIF mk/ directory",
    )
    p_browse.add_argument(
        "url", nargs="?", default=None,
        help="URL to a mission's mk/ directory, or a mission name (omit to list known directories)",
    )
    p_browse.add_argument("--mission", help="Override auto-detected mission name")
    p_browse.add_argument(
        "--show-versioned", action="store_true",
        help="Show versioned snapshots under each metakernel",
    )

    # --- mission ---
    p_mission = sub.add_parser(
        "mission",
        help="Manage configured missions",
    )
    mission_sub = p_mission.add_subparsers(dest="mission_command")
    mission_sub.add_parser("add", help="Add a new mission (interactive)")
    mission_sub.add_parser("list", help="List configured missions")
    p_mission_rm = mission_sub.add_parser("remove", help="Remove a mission")
    p_mission_rm.add_argument("name", help="Mission name to remove")

    # --- coverage ---
    p_cov = sub.add_parser(
        "coverage",
        help="Check SPK body coverage in a metakernel",
    )
    p_cov.add_argument(
        "body_id",
        help="NAIF body ID (e.g. 399) or body name (e.g. Earth)",
    )
    p_cov.add_argument(
        "metakernel", nargs="?", default=None,
        help="Path to .tm file or registry filename (omit to select interactively)",
    )
    p_cov.add_argument("--mission", help="Override mission name")

    # --- config ---
    p_config = sub.add_parser("config", help="Show or update configuration")
    p_config.add_argument(
        "--setup", action="store_true",
        help="Re-run interactive setup",
    )

    # --- reset ---
    p_reset = sub.add_parser("reset", help="Delete the database and start fresh")
    p_reset.add_argument(
        "-y", "--yes", action="store_true",
        help="Skip confirmation prompt",
    )

    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return

    # --- Commands that don't need a DB connection ---
    if args.command == "config":
        if args.setup:
            setup_interactive()
        else:
            show_config(config)
        return

    if args.command == "reset":
        db_path = Path(args.db).expanduser()
        if not db_path.is_file():
            print(f"No database found at {db_path}")
            return
        if not args.yes:
            answer = input(
                f"Delete database at {db_path}? [y/N]: "
            ).strip().lower()
            if answer not in ("y", "yes"):
                print("Aborted.")
                return
        db_path.unlink()
        kernel_dir = Path(config.kernel_dir).expanduser()
        print(f"Database deleted: {db_path}")
        print(f"Kernel files in {kernel_dir} are untouched.\n")
        print("To re-index existing kernels:")
        print(f"  spice-kernel-db scan {kernel_dir}")
        return

    # --- All other commands need a DB connection ---
    db = KernelDB(args.db)
    try:
        if args.command == "scan":
            archive_dir = config.kernel_dir if args.archive else None
            count, missions_found = db.scan_directory(
                args.directory,
                mission=args.mission,
                verbose=args.verbose,
                archive_dir=archive_dir,
            )
            _configure_new_missions(
                db, missions_found, Path(args.directory).expanduser().resolve(),
            )
            db.stats()

        elif args.command == "stats":
            db.stats()

        elif args.command == "duplicates":
            db.report_duplicates()

        elif args.command == "check":
            metakernel = _require_metakernel(args.metakernel, db, args.mission)
            if metakernel is None:
                return
            db.check_metakernel(
                metakernel, mission=args.mission, verbose=args.verbose,
            )

        elif args.command == "rewrite":
            db.rewrite_metakernel(
                args.metakernel,
                args.output,
                mission=args.mission,
                link_root=args.link_root,
            )

        elif args.command == "dedup":
            db.deduplicate_with_symlinks(dry_run=not args.execute)

        elif args.command == "resolve":
            path, warnings = db.resolve_kernel(
                args.filename, preferred_mission=args.mission,
            )
            if path:
                print(path)
            else:
                print(f"Not found: {args.filename}", file=sys.stderr)
            for w in warnings:
                print(f"  ⚠ {w}", file=sys.stderr)

        elif args.command in ("metakernels", "mk"):
            if args.name:
                db.info_metakernel(args.name)
            else:
                db.list_metakernels(mission=args.mission)

        elif args.command == "coverage":
            body_id = _resolve_body_interactive(args.body_id)
            if body_id is None:
                return

            metakernel = _require_metakernel(args.metakernel, db, args.mission)
            if metakernel is None:
                return

            try:
                results = db.coverage_metakernel(
                    metakernel, body_id, mission=args.mission,
                )
            except ImportError:
                print(
                    "SpiceyPy is required for coverage analysis.\n"
                    "Install it with: pip install spice-kernel-db[spice]",
                    file=sys.stderr,
                )
                sys.exit(1)
            _print_coverage_table(results, body_id, metakernel)

        elif args.command == "get":
            url = args.url
            if url is None:
                # Interactive selection — fetch remote listing
                url = _interactive_select_metakernel(db, args.mission)
                if not url:
                    return
                args.mission = args.mission or _guess_mission_from_url(url)
            elif not url.startswith("http"):
                # Treat as a filename — resolve mission mk_dir_url
                mk_dir_url, mission_name = _resolve_mission_mk_dir(
                    db, args.mission,
                )
                if not mk_dir_url:
                    return
                url = mk_dir_url + url
                args.mission = args.mission or mission_name
            db.get_metakernel(
                url,
                download_dir=args.download_dir,
                mission=args.mission,
                yes=args.yes,
            )

        elif args.command == "update":
            metakernel = _require_metakernel(args.metakernel, db, args.mission)
            if metakernel is None:
                return
            db.update_metakernel(
                metakernel,
                mission=args.mission,
                download_dir=args.download_dir,
                yes=args.yes,
            )

        elif args.command == "browse":
            if args.url:
                url = args.url
                # If not a URL, treat as a mission name
                if not url.startswith("http"):
                    m = db.get_mission(url)
                    if not m:
                        print(
                            f"No configured mission '{url}'.\n"
                            f"Use 'spice-kernel-db mission add' to configure it.",
                            file=sys.stderr,
                        )
                        return
                    url = m["mk_dir_url"]
                    args.mission = args.mission or m["name"]
                try:
                    db.browse_remote_metakernels(
                        url,
                        mission=args.mission,
                        show_versioned=args.show_versioned,
                    )
                except urllib.error.HTTPError as e:
                    if e.code == 404:
                        print(
                            f"No metakernel directory found at:\n  {url}\n\n"
                            f"This mission may not publish metakernels at this location.\n"
                            f"Use 'spice-kernel-db mission remove' and re-add with the correct URL.",
                            file=sys.stderr,
                        )
                    else:
                        raise
            else:
                # No args — list configured missions
                missions = db.list_missions()
                if not missions:
                    print("No configured missions.")
                    print("Use 'spice-kernel-db mission add' to set one up.")
                    return
                table = Table(title="Configured missions")
                table.add_column("Mission")
                table.add_column("mk/ URL")
                for m in missions:
                    table.add_row(m["name"], m["mk_dir_url"])
                console.print(table)
                console.print(
                    "\n[dim]Use 'spice-kernel-db browse <mission>' to scan a specific directory.\n"
                    "Use 'spice-kernel-db mission add' to add another mission.[/dim]"
                )

        elif args.command == "mission":
            _handle_mission(db, args)

    finally:
        db.close()


def _print_coverage_table(results, body_id: int, metakernel: str):
    """Print a rich table summarising body coverage results."""
    from rich.panel import Panel

    spk_count = sum(1 for r in results if r.kernel_type == "spk")
    cov_count = sum(1 for r in results if r.body_found)

    console.print(Panel(
        f"Body ID:      [bold]{body_id}[/bold]\n"
        f"Metakernel:   {metakernel}\n"
        f"SPK files:    {spk_count}\n"
        f"With coverage: {cov_count}",
        title="Coverage summary",
    ))

    table = Table(title="Kernel coverage")
    table.add_column("Kernel", no_wrap=True)
    table.add_column("Type")
    table.add_column("Coverage")
    table.add_column("Start (UTC)")
    table.add_column("End (UTC)")

    for r in results:
        if r.kernel_type != "spk":
            table.add_row(r.filename, r.kernel_type, "N/A", "", "")
            continue
        if r.error:
            # Truncate long SPICE tracebacks to the key message
            err_msg = r.error
            if len(err_msg) > 60:
                # Extract the short SPICE error if present
                for marker in ("SPICE(", "Input file"):
                    idx = err_msg.find(marker)
                    if idx >= 0:
                        err_msg = err_msg[idx:idx + 80].split("\n")[0]
                        break
                else:
                    err_msg = err_msg[:60] + "…"
            table.add_row(
                r.filename, r.kernel_type,
                f"[red]{err_msg}[/red]", "", "",
            )
            continue
        if not r.body_found:
            table.add_row(
                r.filename, r.kernel_type,
                "[dim]not found[/dim]", "", "",
            )
            continue
        for i, iv in enumerate(r.intervals):
            label = r.filename if i == 0 else ""
            type_label = r.kernel_type if i == 0 else ""
            cov_str = "[green]yes[/green]" if i == 0 else "[green]gap[/green]"
            table.add_row(
                label, type_label, cov_str,
                iv.utc_start or f"{iv.et_start:.3f} ET",
                iv.utc_end or f"{iv.et_end:.3f} ET",
            )

    console.print(table)


def _require_metakernel(
    metakernel: str | None, db: KernelDB, mission: str | None,
) -> str | None:
    """Return *metakernel* if given, otherwise prompt the user to pick one."""
    if metakernel is not None:
        return metakernel
    return _select_local_metakernel(db, mission)


def _resolve_body_interactive(name_or_id: str) -> int | None:
    """Resolve a body name/ID string to a single NAIF ID, prompting if ambiguous.

    Returns the integer body ID, or None on failure / user cancellation.
    Calls ``sys.exit(1)`` for unknown names.
    """
    from spice_kernel_db.coverage import resolve_body_id

    candidates = resolve_body_id(name_or_id)
    if not candidates:
        print(
            f"Unknown body: '{name_or_id}'. "
            f"Use a NAIF ID (e.g. 399) or a known name (e.g. Earth).",
            file=sys.stderr,
        )
        sys.exit(1)

    if len(candidates) == 1:
        return candidates[0][0]

    # Disambiguation prompt
    console.print(f"\n'{name_or_id}' matches multiple NAIF bodies:\n")
    for i, (bid, desc) in enumerate(candidates, 1):
        console.print(f"  [{i}] {desc}  (NAIF ID {bid})")
    console.print()
    try:
        raw = input(f"Select [1-{len(candidates)}]: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return None
    try:
        idx = int(raw)
        if 1 <= idx <= len(candidates):
            return candidates[idx - 1][0]
    except ValueError:
        pass
    print("Invalid selection.", file=sys.stderr)
    sys.exit(1)


def _select_local_metakernel(
    db: KernelDB, mission: str | None,
) -> str | None:
    """List locally registered metakernels and let the user pick one.

    Returns the mk_path of the selected metakernel, or None on failure.
    Prints a hint about ``browse`` and ``get`` when no metakernels are found
    or when the user wants to fetch more.
    """
    rows = db.con.execute("""
        SELECT r.mk_path, r.filename, r.mission, r.acquired_at
        FROM metakernel_registry r
        {}
        ORDER BY r.mission, r.filename
    """.format(
        "WHERE LOWER(r.mission) LIKE LOWER(?) || '%'" if mission else "",
    ), [mission] if mission else []).fetchall()

    if not rows:
        mission_hint = f" for mission '{mission}'" if mission else ""
        console.print(
            f"[yellow]No locally acquired metakernels{mission_hint}.[/yellow]\n\n"
            f"[dim]To browse and download metakernels:\n"
            f"  spice-kernel-db browse [MISSION]\n"
            f"  spice-kernel-db get [METAKERNEL][/dim]\n",
            stderr=True,
        )
        return None

    table = Table(title="Local metakernels")
    table.add_column("#", justify="right", style="bold")
    table.add_column("Filename")
    table.add_column("Mission")
    table.add_column("Acquired")
    for i, (mk_path, filename, mis, acquired) in enumerate(rows, 1):
        acq_str = str(acquired)[:16] if acquired else ""
        table.add_row(str(i), filename, mis, acq_str)
    console.print(table)

    console.print(
        "\n[dim]To fetch more metakernels: "
        "spice-kernel-db browse [MISSION][/dim]\n"
    )

    try:
        raw = input(f"Select metakernel [1-{len(rows)}]: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return None
    try:
        idx = int(raw)
        if 1 <= idx <= len(rows):
            return rows[idx - 1][0]  # mk_path
    except ValueError:
        pass
    console.print("[red]Invalid selection.[/red]", stderr=True)
    return None


def _read_spice_server_marker(directory: Path) -> dict[str, str] | None:
    """Read a .spice-server marker file from a directory.

    Returns a dict with 'server_url' and 'mk_dir_url' keys, or None.
    """
    marker = directory / ".spice-server"
    if not marker.is_file():
        return None
    data: dict[str, str] = {}
    for line in marker.read_text().splitlines():
        if "=" in line:
            key, _, val = line.partition("=")
            data[key.strip()] = val.strip()
    if "server_url" in data and "mk_dir_url" in data:
        return data
    return None


def _configure_new_missions(
    db: KernelDB, missions_found: set[str], scan_root: Path,
) -> None:
    """Configure missions found during scan that aren't in the DB yet.

    Checks for .spice-server marker files first, prompts user as fallback.
    """
    skip_names = {"generic", "unknown"}
    server_names = list(SPICE_SERVERS.keys())

    for name in sorted(missions_found):
        if name.lower() in skip_names:
            continue
        if db.get_mission(name):
            continue

        # Look for .spice-server marker in the mission directory
        # Check both <root>/<mission>/ and <root>/<mission>/kernels/
        marker = None
        for candidate in [scan_root / name, scan_root / name / "kernels"]:
            marker = _read_spice_server_marker(candidate)
            if marker:
                break

        if marker:
            mk_dir_url = marker["mk_dir_url"]
            server_url = marker["server_url"]
            server_label = "custom"
            for label, url in SPICE_SERVERS.items():
                if server_url == url:
                    server_label = label
                    break
            db.add_mission(name, server_url, mk_dir_url)
            print(f"  Configured {name} from .spice-server ({server_label}).")
            continue

        # No marker — prompt user
        print(f"\n  {name} is not yet configured for remote access.")
        for i, sname in enumerate(server_names, 1):
            print(f"    [{i}] {sname}  ({SPICE_SERVERS[sname]})")
        print(f"    [{len(server_names) + 1}] Skip")
        while True:
            choice = input(f"  Select [1-{len(server_names) + 1}]: ").strip()
            if choice.isdigit():
                idx = int(choice)
                if 1 <= idx <= len(server_names):
                    server_label = server_names[idx - 1]
                    server_url = SPICE_SERVERS[server_label]
                    mk_dir_url = f"{server_url}{name}/kernels/mk/"
                    db.add_mission(name, server_url, mk_dir_url)
                    print(f"  Configured {name} ({server_label}).")
                    break
                elif idx == len(server_names) + 1:
                    break
            print("  Invalid choice.")


def _resolve_mission_mk_dir(
    db: KernelDB, mission_name: str | None,
) -> tuple[str | None, str | None]:
    """Resolve a mission name to an mk/ directory URL.

    Looks up the missions table. Returns (mk_dir_url, mission_name)
    or (None, None) on failure.
    """
    if mission_name:
        m = db.get_mission(mission_name)
        if m:
            return m["mk_dir_url"], m["name"]

    # No mission specified — check if exactly one is configured
    missions = db.list_missions()
    if len(missions) == 1:
        m = missions[0]
        return m["mk_dir_url"], m["name"]

    if not missions:
        console.print(
            "[yellow]No missions configured.[/yellow]\n"
            "[dim]Use 'spice-kernel-db mission add' first.[/dim]",
            stderr=True,
        )
        return None, None

    # Multiple missions — let user pick interactively
    table = Table(title="Select a mission")
    table.add_column("#", justify="right", style="bold")
    table.add_column("Mission")
    table.add_column("mk/ URL")
    for i, m in enumerate(missions, 1):
        table.add_row(str(i), m["name"], m["mk_dir_url"])
    console.print(table)

    try:
        raw = input(f"\nSelect mission [1-{len(missions)}]: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return None, None
    try:
        idx = int(raw)
        if 1 <= idx <= len(missions):
            m = missions[idx - 1]
            return m["mk_dir_url"], m["name"]
    except ValueError:
        pass
    console.print("[red]Invalid selection.[/red]", stderr=True)
    return None, None


def _guess_mission_from_url(url: str) -> str | None:
    """Extract mission name from a metakernel URL."""
    from spice_kernel_db.hashing import guess_mission
    return guess_mission(url)


def _interactive_select_metakernel(
    db: KernelDB, mission_name: str | None,
) -> str | None:
    """Fetch remote metakernels and let the user pick one interactively.

    Returns the full URL of the selected metakernel, or None on failure.
    """
    mk_dir_url, resolved_name = _resolve_mission_mk_dir(db, mission_name)
    if not mk_dir_url:
        return None

    console.print(f"Fetching metakernels from [bold]{mk_dir_url}[/bold] ...")
    try:
        entries = list_remote_metakernels(mk_dir_url)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            console.print(
                f"[red]No metakernel directory found at:[/red]\n  {mk_dir_url}",
                stderr=True,
            )
        else:
            raise
        return None

    if not entries:
        console.print("[red]No metakernels found.[/red]", stderr=True)
        return None

    # Group by base_name, show latest version per group
    from collections import defaultdict
    groups: dict[str, list] = defaultdict(list)
    for entry in entries:
        groups[entry.base_name].append(entry)

    # Check which are locally acquired
    local_rows = db.con.execute(
        "SELECT filename FROM metakernel_registry WHERE LOWER(mission) LIKE LOWER(?) || '%'",
        [resolved_name or ""],
    ).fetchall()
    local_filenames = {r[0] for r in local_rows}

    # Build selection list — one row per base_name, link to latest version
    choices: list[tuple[str, str, bool]] = []  # (url, base_name, is_local)
    for base_name in sorted(groups):
        group = groups[base_name]
        latest = max(group, key=lambda e: e.filename)
        is_local = any(e.filename in local_filenames for e in group)
        choices.append((latest.url, base_name, is_local))

    table = Table(title=f"Available metakernels — {resolved_name or 'remote'}")
    table.add_column("#", justify="right", style="bold")
    table.add_column("Metakernel")
    table.add_column("Versions", justify="right")
    table.add_column("Latest")
    table.add_column("Local", justify="center")
    for i, (base_name, group) in enumerate(sorted(groups.items()), 1):
        latest = max(group, key=lambda e: e.filename)
        is_local = any(e.filename in local_filenames for e in group)
        n_ver = str(len(group)) if len(group) > 1 else ""
        local_col = "[green]\u2713[/green]" if is_local else ""
        table.add_row(str(i), base_name, n_ver, latest.date, local_col)
    console.print(table)

    try:
        raw = input(f"\nSelect metakernel [1-{len(choices)}]: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return None
    try:
        idx = int(raw)
        if 1 <= idx <= len(choices):
            url, _, _ = choices[idx - 1]
            return url
    except ValueError:
        pass
    console.print("[red]Invalid selection.[/red]", stderr=True)
    return None


def _handle_mission(db: KernelDB, args):
    """Handle the 'mission' subcommand group."""
    if args.mission_command == "list":
        missions = db.list_missions()
        if not missions:
            print("No configured missions.")
            print("Use 'spice-kernel-db mission add' to set one up.")
            return
        table = Table(title="Configured missions")
        table.add_column("Mission")
        table.add_column("Server")
        table.add_column("Dedup")
        table.add_column("mk/ URL")
        for m in missions:
            dedup_str = "yes" if m["dedup"] else "no"
            table.add_row(
                m["name"], m["server_label"], dedup_str, m["mk_dir_url"],
            )
        console.print(table)

    elif args.mission_command == "remove":
        if db.remove_mission(args.name):
            print(f"Mission '{args.name}' removed.")
        else:
            print(f"Mission '{args.name}' not found.", file=sys.stderr)

    elif args.mission_command == "add":
        _mission_add_interactive(db)

    else:
        print("Usage: spice-kernel-db mission {add,list,remove}")


def _mission_add_interactive(db: KernelDB):
    """Interactive mission setup: choose server → pick mission → configure."""
    # 1. Choose server
    server_names = list(SPICE_SERVERS.keys())
    print("\nAvailable SPICE archive servers:\n")
    for i, name in enumerate(server_names, 1):
        print(f"  [{i}] {name}  ({SPICE_SERVERS[name]})")
    print()
    while True:
        choice = input(f"Select server [1-{len(server_names)}]: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(server_names):
            server_label = server_names[int(choice) - 1]
            break
        print("Invalid choice.")
    server_url = SPICE_SERVERS[server_label]

    # 2. List missions and check which have metakernel directories
    print(f"\nFetching missions from {server_label}...")
    all_missions = list_remote_missions(server_url)
    if not all_missions:
        print("No missions found.", file=sys.stderr)
        return

    mk_status = check_mk_availability(server_url, all_missions)
    supported = [m for m in all_missions if mk_status.get(m)]
    unsupported = [m for m in all_missions if not mk_status.get(m)]

    if not supported:
        print("No missions with metakernel directories found.", file=sys.stderr)
        return

    print(f"\nAvailable missions ({len(supported)} with metakernels):\n")
    for i, name in enumerate(supported, 1):
        print(f"  [{i:>3}] {name}")

    if unsupported:
        print(
            f"\nNot yet supported ({len(unsupported)} without metakernels "
            f"— see github.com/michaelaye/spice-kernel-db/issues/2):"
        )
        print(f"  {', '.join(unsupported)}")

    print()
    while True:
        choice = input(f"Select mission [1-{len(supported)}] or type name: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(supported):
            mission_name = supported[int(choice) - 1]
            break
        elif choice in supported:
            mission_name = choice
            break
        # Case-insensitive match
        matches = [m for m in supported if m.lower() == choice.lower()]
        if matches:
            mission_name = matches[0]
            break
        print("Invalid choice.")

    # 3. mk/ directory URL (already validated by check_mk_availability)
    mk_dir_url = f"{server_url}{mission_name}/kernels/mk/"

    # 4. Dedup preference
    dedup_answer = input(
        f"\nEnable deduplication for {mission_name}? [Y/n]: "
    ).strip().lower()
    dedup = dedup_answer not in ("n", "no")

    # 5. Store
    db.add_mission(mission_name, server_url, mk_dir_url, dedup)
    dedup_str = "enabled" if dedup else "disabled"
    print(f"\nMission '{mission_name}' ({server_label}) configured.")
    print(f"  Deduplication: {dedup_str}")
    print(f"  mk/ directory: {mk_dir_url}")
    print(f"\nNext steps:")
    print(f"  spice-kernel-db browse {mission_name}")
    print(f"  spice-kernel-db get <metakernel>.tm --mission {mission_name}")
