"""PulsimCore Validation Framework.

Validates simulation results against analytical solutions and reference simulators.
"""
