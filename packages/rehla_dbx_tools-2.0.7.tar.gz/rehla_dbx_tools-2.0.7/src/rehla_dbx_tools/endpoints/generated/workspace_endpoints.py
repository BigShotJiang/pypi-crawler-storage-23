"""Compatibility module for generated workspace endpoint constants."""

from databricks_api.endpoints.generated.workspace_endpoints import (
    WORKSPACE_2_0_ENDPOINTS,
    WORKSPACE_2_1_ENDPOINTS,
    WORKSPACE_PREVIEW_ENDPOINTS,
)

__all__ = ["WORKSPACE_2_0_ENDPOINTS", "WORKSPACE_2_1_ENDPOINTS", "WORKSPACE_PREVIEW_ENDPOINTS"]
