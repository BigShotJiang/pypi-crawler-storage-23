from workos.types.pipes.pipes import (
    AccessToken as AccessToken,
    GetAccessTokenFailureResponse as GetAccessTokenFailureResponse,
    GetAccessTokenResponse as GetAccessTokenResponse,
    GetAccessTokenSuccessResponse as GetAccessTokenSuccessResponse,
)
