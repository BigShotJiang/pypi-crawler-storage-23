from workos.types.list_resource import ListArgs


class ApiKeyListFilters(ListArgs, total=False):
    pass
