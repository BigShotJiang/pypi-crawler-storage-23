from cmp3.core import *
from cmp3.tests import *
