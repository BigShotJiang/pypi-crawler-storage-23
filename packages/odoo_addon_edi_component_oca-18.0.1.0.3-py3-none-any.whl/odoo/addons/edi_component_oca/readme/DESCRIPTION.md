This module allows to use components to handle code to execute on EDI Exchanges.
