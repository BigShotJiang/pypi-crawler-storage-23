class SwitchError(Exception):
    """Raised when an if/elif/else chain reaches an unexpected else clause."""

    ...
