LOGIN_PAGE = "https://www.fresh-r.me/login/index.php?page=login"
LOGIN_API = "https://www.fresh-r.me/login/api/auth.php"
DEVICES_PAGE = "https://dashboard.bw-log.com/?page=devices&t="
DEVICES_API = "https://dashboard.bw-log.com/api.php?q="

ATTR_INSIDE_TEMPERATURE = "inside_temperature"
ATTR_OUTSIDE_TEMPERATURE = "outside_temperature"
ATTR_HUMIDITY = "humidity"
ATTR_CO2 = "CO2"