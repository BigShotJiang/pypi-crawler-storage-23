class LoginError(Exception):
    pass

class ScrapeError(Exception):
    pass
