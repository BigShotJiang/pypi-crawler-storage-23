# pyfreshr
Python library around the Fresh-R web interface for use in a Home Assistant addon

## Example

Run the example script (without installing the package) from the repository root:

```bash
PYTHONPATH=src python examples/example_usage.py
```

You can also set credentials via environment variables `FRESHR_USER` and `FRESHR_PASS` before running the script.
