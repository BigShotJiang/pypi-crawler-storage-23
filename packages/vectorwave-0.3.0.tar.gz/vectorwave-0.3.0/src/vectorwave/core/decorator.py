import inspect
import logging
import os
from functools import wraps
from typing import List, Optional, Dict, Any

from weaviate.util import generate_uuid5

from ..batch.batch import get_batch_manager
from ..models.db_config import get_weaviate_settings
from ..monitoring.tracer import trace_root, trace_span
from ..utils.function_cache import function_cache_manager
from ..utils.return_caching_utils import _check_and_return_cached_result
from ..vectorizer.factory import get_vectorizer
from ..utils.context import execution_source_context
from ..utils.path_utils import get_repo_root_and_relative_path

logger = logging.getLogger(__name__)

PENDING_FUNCTIONS: List[Dict[str, Any]] = []


def vectorize(search_description: Optional[str] = None,
              sequence_narrative: Optional[str] = None,
              auto: bool = False,
              capture_return_value: bool = False,
              semantic_cache: bool = False,
              cache_threshold: float = 0.9,
              replay: bool = False,
              attributes_to_capture: Optional[List[str]] = None,
              capture_inputs: bool = False,
              semantic_cache_filters: Optional[Dict[str, Any]] = None,
              semantic_cache_scope: Optional[List[str]] = None,
              enable_alert: bool = True,
              **execution_tags):
    """
    VectorWave Decorator with Auto-Generation support.
    """

    if semantic_cache:
        if get_vectorizer() is None:
            logger.warning(
                f"Semantic caching requested for '{search_description}' but no Python vectorizer is configured. "
                f"Disabling semantic_cache."
            )
            semantic_cache = False

    if semantic_cache and not capture_return_value:
        capture_return_value = True

    if replay and not capture_return_value:
        capture_return_value = True

    def decorator(func):
        is_async_func = inspect.iscoroutinefunction(func)

        module_name = func.__module__
        function_name = func.__name__
        func_identifier = f"{module_name}.{function_name}"
        func_uuid = generate_uuid5(func_identifier)

        # Prepare attributes to capture
        final_attributes = ['function_uuid', 'team', 'priority', 'run_id', 'exec_source']
        if attributes_to_capture:
            for attr in attributes_to_capture:
                if attr not in final_attributes:
                    final_attributes.append(attr)

        if capture_inputs or replay:
            try:
                sig = inspect.signature(func)
                for param_name in sig.parameters:
                    if param_name not in ('self', 'cls') and param_name not in final_attributes:
                        final_attributes.append(param_name)
            except Exception as e:
                logger.warning(f"Failed to inspect signature for auto-capture in '{function_name}': {e}")

        # Extract Execution Tags
        valid_execution_tags = {}
        settings = get_weaviate_settings()
        if execution_tags and settings.custom_properties:
            allowed_keys = set(settings.custom_properties.keys())
            for key, value in execution_tags.items():
                if key in allowed_keys:
                    valid_execution_tags[key] = value
                else:
                    logger.warning(
                        "Function '%s' has undefined execution_tag: '%s'. "
                        "This tag will be IGNORED. Please add it to your .weaviate_properties file.",
                        function_name,
                        key
                    )

        try:
            # define static properties
            docstring = inspect.getdoc(func) or ""
            source_code = inspect.getsource(func)

            try:
                abs_file_path = os.path.abspath(inspect.getsourcefile(func))
                repo_root, relative_file_path = get_repo_root_and_relative_path(abs_file_path)
                if relative_file_path:
                    file_path = relative_file_path
                else:
                    file_path = abs_file_path
                    logger.warning(f"Function '{function_name}' is not in a Git repository. "
                                   f"PR creation might fail for absolute path: {file_path}")
            except Exception as e:
                file_path = ""
                logger.error(f"Failed to determine file path for '{function_name}': {e}")

            static_properties = {
                "function_name": function_name,
                "file_path": file_path,
                "module_name": module_name,
                "docstring": docstring,
                "source_code": source_code,
                "search_description": search_description,
                "sequence_narrative": sequence_narrative
            }
            static_properties.update(valid_execution_tags)

            if auto:
                logger.info(f"Function '{function_name}' registered for auto-metadata generation.")
                PENDING_FUNCTIONS.append({
                    "func_name": function_name,
                    "func_uuid": func_uuid,
                    "func_identifier": func_identifier,
                    "static_properties": static_properties
                })
            else:
                current_content_hash = function_cache_manager.calculate_content_hash(func_identifier, static_properties)

                if function_cache_manager.is_cached_and_unchanged(func_uuid, current_content_hash):
                    logger.info(f"Function '{function_name}' is UNCHANGED. Skipping DB write.")
                else:
                    logger.info(f"Function '{function_name}' is NEW or CHANGED. Writing to DB.")
                    batch = get_batch_manager()
                    vectorizer = get_vectorizer()
                    vector_to_add = None

                    if vectorizer is not None and search_description:
                        try:
                            vector_to_add = vectorizer.embed(search_description)
                        except Exception as e:
                            logger.warning(f"Failed to vectorize '{function_name}': {e}")

                    batch.add_object(
                        collection=settings.COLLECTION_NAME,
                        properties=static_properties,
                        uuid=func_uuid,
                        vector=vector_to_add
                    )
                    function_cache_manager.update_cache(func_uuid, current_content_hash)

        except Exception as e:
            logger.error("Error in @vectorize setup for '%s': %s", func.__name__, e)

        def resolve_semantic_filters(args, kwargs):
            runtime_filters = semantic_cache_filters.copy() if semantic_cache_filters else {}

            if semantic_cache_scope:
                try:
                    sig = inspect.signature(func)
                    bound_args = sig.bind(*args, **kwargs)
                    bound_args.apply_defaults()

                    for arg_name in semantic_cache_scope:
                        if arg_name in bound_args.arguments:
                            runtime_filters[arg_name] = bound_args.arguments[arg_name]
                        else:
                            logger.warning(f"Semantic Scope: Argument '{arg_name}' not found in call to '{function_name}'.")
                except Exception as e:
                    logger.error(f"Failed to resolve semantic_cache_scope for '{function_name}': {e}")

            return runtime_filters

        # --- Wrapper Logic ---

        def _try_cache(args, kwargs):
            """Check semantic cache. Returns cached result or None."""
            if not semantic_cache:
                return None
            filters = resolve_semantic_filters(args, kwargs)
            return _check_and_return_cached_result(
                func, args, kwargs, function_name, cache_threshold,
                is_async_func, filters=filters
            )

        def _build_full_kwargs(kwargs):
            """Build kwargs with execution tags and metadata."""
            full_kwargs = kwargs.copy()
            full_kwargs.update(valid_execution_tags)
            full_kwargs['function_uuid'] = func_uuid
            full_kwargs['exec_source'] = execution_source_context.get()
            return full_kwargs

        if is_async_func:
            @trace_root()
            @trace_span(
                attributes_to_capture=final_attributes,
                capture_return_value=capture_return_value,
                force_sync=semantic_cache,
                enable_alert=enable_alert
            )
            @wraps(func)
            async def inner_wrapper(*args, **kwargs):
                clean_kwargs = {k: v for k, v in kwargs.items() if
                                k not in valid_execution_tags and k != 'function_uuid' and k != 'exec_source'}
                return await func(*args, **clean_kwargs)

            @wraps(func)
            async def outer_wrapper(*args, **kwargs):
                cached = _try_cache(args, kwargs)
                if cached is not None:
                    return cached
                return await inner_wrapper(*args, **_build_full_kwargs(kwargs))

            outer_wrapper._is_vectorized = True
            return outer_wrapper

        else:  # Sync wrapper
            @trace_root()
            @trace_span(
                attributes_to_capture=final_attributes,
                capture_return_value=capture_return_value,
                force_sync=semantic_cache,
                enable_alert=enable_alert
            )
            @wraps(func)
            def inner_wrapper(*args, **kwargs):
                clean_kwargs = {k: v for k, v in kwargs.items() if
                                k not in valid_execution_tags and k != 'function_uuid' and k != 'exec_source'}
                return func(*args, **clean_kwargs)

            @wraps(func)
            def outer_wrapper(*args, **kwargs):
                cached = _try_cache(args, kwargs)
                if cached is not None:
                    return cached
                return inner_wrapper(*args, **_build_full_kwargs(kwargs))

            outer_wrapper._is_vectorized = True
            return outer_wrapper

    return decorator