# vs-engine
# Copyright (C) 2022  cid-chan
# Copyright (C) 2025  Jaded-Encoding-Thaumaturgy
# This project is licensed under the EUPL-1.2
# SPDX-License-Identifier: EUPL-1.2
"""Tests for the vpy module (script loading and execution)."""

import ast
import contextlib
import gc
import logging
import os
import sys
import textwrap
import threading
import types
import weakref
from collections.abc import Callable, Iterator
from pathlib import Path
from typing import Any

import pytest
import vapoursynth

from tests._testutils import BLACKBOARD
from vsengine.adapters.asyncio import AsyncIOLoop
from vsengine.loops import set_loop
from vsengine.policy import GlobalStore, ManagedEnvironment, Policy
from vsengine.vpy import (
    ExecutionError,
    Script,
    WrapAllErrors,
    _load,
    _ModifiedArgv0,
    _ModifiedPath,
    chdir_runner,
    inline_runner,
    load_code,
    load_script,
)

DIR: str = os.path.dirname(__file__)
PATH: str = os.path.join(DIR, "fixtures", "test.vpy")


@contextlib.contextmanager
def noop() -> Iterator[None]:
    yield


class VpyTestError(Exception):
    pass


def callback_script(
    func: Callable[[types.ModuleType], None],
) -> Callable[[contextlib.AbstractContextManager[None], types.ModuleType], None]:
    def _script(ctx: contextlib.AbstractContextManager[None], module: types.ModuleType) -> None:
        with ctx:
            func(module)

    return _script


def test_run_executes_successfully() -> None:
    run = False

    @callback_script
    def test_code(_: types.ModuleType) -> None:
        nonlocal run
        run = True

    with Policy(GlobalStore()) as p, p.new_environment() as env:
        s = Script(test_code, types.ModuleType("__test__"), env.vs_environment, inline_runner)
        s.run()

    assert run


def test_run_wraps_exception() -> None:
    @callback_script
    def test_code(_: types.ModuleType) -> None:
        raise VpyTestError()

    with Policy(GlobalStore()) as p, p.new_environment() as env:
        s = Script(test_code, types.ModuleType("__test__"), env.vs_environment, inline_runner)
        fut = s.run()

        exc = fut.exception()
        assert isinstance(exc, ExecutionError)
        assert isinstance(exc.parent_error, VpyTestError)


def test_execute_resolves_immediately() -> None:
    run = False

    @callback_script
    def test_code(_: types.ModuleType) -> None:
        nonlocal run
        run = True

    with Policy(GlobalStore()) as p, p.new_environment() as env:
        s = Script(test_code, types.ModuleType("__test__"), env.vs_environment, inline_runner)
        s.result()

    assert run


def test_execute_resolves_to_script() -> None:
    @callback_script
    def test_code(_: types.ModuleType) -> None:
        pass

    with Policy(GlobalStore()) as p, p.new_environment() as env:
        s = Script(test_code, types.ModuleType("__test__"), env.vs_environment, inline_runner)
        s.result()


def test_execute_resolves_immediately_when_raising() -> None:
    @callback_script
    def test_code(_: types.ModuleType) -> None:
        raise VpyTestError

    with Policy(GlobalStore()) as p, p.new_environment() as env:
        s = Script(test_code, types.ModuleType("__test__"), env.vs_environment, inline_runner)
        try:
            s.result()
        except ExecutionError as err:
            assert isinstance(err.parent_error, VpyTestError)
        except Exception as e:
            pytest.fail(f"Wrong exception: {e!r}")
        else:
            pytest.fail("Test execution didn't fail properly.")


@pytest.mark.asyncio
async def test_run_async() -> None:
    set_loop(AsyncIOLoop())
    run = False

    @callback_script
    def test_code(_: types.ModuleType) -> None:
        nonlocal run
        run = True

    with Policy(GlobalStore()) as p, p.new_environment() as env:
        s = Script(test_code, types.ModuleType("__test__"), env.vs_environment, inline_runner)
        await s.run_async()

    assert run


@pytest.mark.asyncio
async def test_await_directly() -> None:
    set_loop(AsyncIOLoop())
    run = False

    @callback_script
    def test_code(_: types.ModuleType) -> None:
        nonlocal run
        run = True

    with Policy(GlobalStore()) as p, p.new_environment() as env:
        await Script(test_code, types.ModuleType("__test__"), env.vs_environment, inline_runner)

    assert run


def test_disposes_managed_environment() -> None:
    @callback_script
    def test_code(_: types.ModuleType) -> None:
        pass

    with Policy(GlobalStore()) as p:
        env = p.new_environment()
        s = Script(test_code, types.ModuleType("__test__"), env, inline_runner)

        try:
            s.dispose()
        except Exception:
            env.dispose()
            raise


def test_disposing_context_manager_for_managed_environments() -> None:
    @callback_script
    def test_code(_: types.ModuleType) -> None:
        pass

    with Policy(GlobalStore()) as p:
        env = p.new_environment()
        with Script(test_code, types.ModuleType("__test__"), env, inline_runner):
            pass

        try:
            assert env.disposed
        except Exception:
            env.dispose()
            raise


def test_chdir_changes_chdir() -> None:
    curdir: str | None = None

    @callback_script
    def test_code(_: types.ModuleType) -> None:
        nonlocal curdir
        curdir = os.getcwd()

    wrapped = chdir_runner(DIR, inline_runner)
    wrapped(test_code, noop(), 2)  # type: ignore[arg-type]
    assert curdir == DIR


def test_chdir_changes_chdir_back() -> None:
    @callback_script
    def test_code(_: types.ModuleType) -> None:
        pass

    wrapped = chdir_runner(DIR, inline_runner)

    before = os.getcwd()
    wrapped(test_code, noop(), None)  # type: ignore[arg-type]
    assert os.getcwd() == before


def test_load_uses_current_environment() -> None:
    vpy_env: Any = None

    @callback_script
    def test_code(_: types.ModuleType) -> None:
        nonlocal vpy_env
        vpy_env = vapoursynth.get_current_environment()

    with Policy(GlobalStore()) as p, p.new_environment() as env, env.use():
        _load(test_code, None, "__vapoursynth__", inline=False, chdir=None).result()
        assert vpy_env == env.vs_environment


def test_load_creates_new_environment() -> None:
    vpy_env: Any = None

    @callback_script
    def test_code(_: types.ModuleType) -> None:
        nonlocal vpy_env
        vpy_env = vapoursynth.get_current_environment()

    with Policy(GlobalStore()) as p:
        s = _load(test_code, p, "__vapoursynth__", inline=True, chdir=None)
        try:
            s.result()
            assert vpy_env == s.environment.vs_environment
        finally:
            s.dispose()


def test_load_chains_script() -> None:
    @callback_script
    def test_code_1(module: types.ModuleType) -> None:
        assert not hasattr(module, "test")
        module.test = True  # type: ignore[attr-defined]

    @callback_script
    def test_code_2(module: types.ModuleType) -> None:
        assert module.test is True

    with Policy(GlobalStore()) as p:
        script1 = _load(test_code_1, p, "__test_1__", inline=True, chdir=None)
        env = script1.environment
        try:
            script1.result()
            script2 = _load(test_code_2, script1, "__test_2__", inline=True, chdir=None)
            script2.result()
        finally:
            env.dispose()


def test_load_with_custom_name() -> None:
    @callback_script
    def test_code_1(module: types.ModuleType) -> None:
        assert module.__name__ == "__test_1__"

    @callback_script
    def test_code_2(module: types.ModuleType) -> None:
        assert module.__name__ == "__test_2__"

    with Policy(GlobalStore()) as p:
        try:
            script1 = _load(test_code_1, p, "__test_1__", inline=True, chdir=None)
            script1.result()
        finally:
            script1.dispose()  # pyright: ignore[reportPossiblyUnboundVariable]

        try:
            script2 = _load(test_code_2, p, "__test_2__", inline=True, chdir=None)
            script2.result()
        finally:
            script2.dispose()  # pyright: ignore[reportPossiblyUnboundVariable]


def test_load_runs_chdir() -> None:
    curdir: str | None = None

    @callback_script
    def test_code(_: types.ModuleType) -> None:
        nonlocal curdir
        curdir = os.getcwd()

    with Policy(GlobalStore()) as p, p.new_environment() as env, env.use():
        previous = os.getcwd()
        _load(test_code, None, "__vapoursynth__", inline=True, chdir=DIR).result()
        assert curdir == DIR
        assert os.getcwd() == previous


def test_load_runs_in_thread_when_requested() -> None:
    thread: threading.Thread | None = None

    @callback_script
    def test_code(_: types.ModuleType) -> None:
        nonlocal thread
        thread = threading.current_thread()

    with Policy(GlobalStore()) as p, p.new_environment() as env, env.use():
        _load(test_code, None, "__vapoursynth__", inline=False, chdir=None).result()
        assert thread is not threading.current_thread()


def test_load_runs_inline_by_default() -> None:
    thread: threading.Thread | None = None

    @callback_script
    def test_code(_: types.ModuleType) -> None:
        nonlocal thread
        thread = threading.current_thread()

    with Policy(GlobalStore()) as p, p.new_environment() as env, env.use():
        _load(test_code, None, "__vapoursynth__", True, chdir=None).result()
        assert thread is threading.current_thread()


def test_code_runs_string() -> None:
    code = textwrap.dedent("""
        from tests._testutils import BLACKBOARD
        BLACKBOARD["vpy_test_runs_raw_code_str"] = True
    """)

    with Policy(GlobalStore()) as p, p.new_environment() as env, env.use():
        load_code(code).result()
        assert BLACKBOARD.get("vpy_test_runs_raw_code_str") is True


def test_code_runs_bytes() -> None:
    code = textwrap.dedent("""
        # encoding: latin-1
        from tests._testutils import BLACKBOARD
        BLACKBOARD["vpy_test_runs_raw_code_bytes"] = True
    """).encode("latin-1")

    with Policy(GlobalStore()) as p, p.new_environment() as env, env.use():
        load_code(code).result()
        assert BLACKBOARD.get("vpy_test_runs_raw_code_bytes") is True


def test_code_runs_ast() -> None:
    code = ast.parse(
        textwrap.dedent("""
        from tests._testutils import BLACKBOARD
        BLACKBOARD["vpy_test_runs_raw_code_ast"] = True
    """)
    )

    with Policy(GlobalStore()) as p, p.new_environment() as env, env.use():
        load_code(code).result()
        assert BLACKBOARD.get("vpy_test_runs_raw_code_ast") is True


def test_script_runs() -> None:
    BLACKBOARD.clear()
    with Policy(GlobalStore()) as p, p.new_environment() as env, env.use():
        load_script(PATH).result()
        assert BLACKBOARD.get("vpy_run_script") is True


def test_script_runs_with_custom_name() -> None:
    BLACKBOARD.clear()
    with Policy(GlobalStore()) as p, p.new_environment() as env, env.use():
        load_script(PATH, module="__test__").result()
        assert BLACKBOARD.get("vpy_run_script_name") == "__test__"


def test_wrap_exceptions_wraps_exception() -> None:
    err = RuntimeError()
    try:
        with WrapAllErrors():
            raise err
    except ExecutionError as e:
        assert e.parent_error is err
    else:
        pytest.fail("Wrap all errors swallowed the exception")


@pytest.mark.parametrize("fail", [False, True])
def test_dispose_clears_future(fail: bool) -> None:
    code = "raise RuntimeError()" if fail else "pass"
    with Policy(GlobalStore()) as p:
        s = load_code(code, p)
        with contextlib.suppress(ExecutionError):
            s.result()

        assert hasattr(s, "_future")
        s.dispose()
        assert not hasattr(s, "_future")


def test_dispose_prevents_hospice_warning_on_error(caplog: pytest.LogCaptureFixture) -> None:
    @callback_script
    def test_code(mod: types.ModuleType) -> None:
        import vapoursynth

        setattr(mod, "leak", vapoursynth.core.std.BlankClip())
        raise VpyTestError()

    with Policy(GlobalStore()) as p:
        s = Script(test_code, types.ModuleType("__test__"), p.new_environment(), inline_runner)
        with pytest.raises(ExecutionError):
            s.result()

        s.dispose()

        with caplog.at_level(logging.WARNING, logger="vsengine._hospice"):
            for _ in range(5):
                gc.collect()

        assert not any("Core is still in use" in r.message for r in caplog.records if "vsengine._hospice" in r.name)


def test_hospice_warns_if_future_not_deleted(caplog: pytest.LogCaptureFixture) -> None:
    @callback_script
    def test_code(mod: types.ModuleType) -> None:
        import vapoursynth

        setattr(mod, "clip", vapoursynth.core.std.BlankClip())
        raise VpyTestError()

    with Policy(GlobalStore()) as p:
        env = p.new_environment()
        s = Script(test_code, types.ModuleType("__test__"), env, inline_runner)
        fut = s.run()
        with pytest.raises(ExecutionError):
            fut.result()

        # Monkeypatch dispose to NOT delete the future and NOT clear module dict
        original_dispose = s.dispose

        def leaky_dispose() -> None:
            # We ONLY dispose the environment, skipping del self._future and module.clear()
            if isinstance(s.environment, ManagedEnvironment):
                s.environment.dispose()

        setattr(s, "dispose", leaky_dispose)

        try:
            # Clear local ref to future. It should still be held by s._future
            del fut

            s.dispose()

            # Trigger hospice collection
            with caplog.at_level(logging.WARNING, logger="vsengine._hospice"):
                for _ in range(10):
                    gc.collect()

            # There should be a warning from hospice now because s._future still exists
            # and is holding onto the traceback, which holds onto the module, which holds the core (via mod.clip)
            assert any("Core is still in use" in r.message for r in caplog.records)
        finally:
            setattr(s, "dispose", original_dispose)
            s.module.__dict__.clear()
            with contextlib.suppress(AttributeError):
                del s._future


def test_script_is_collectible_after_dispose() -> None:
    def _run_and_dispose() -> weakref.ReferenceType[Script[Any]]:
        with Policy(GlobalStore()) as p:
            s = load_code("raise RuntimeError()", p)
            s.run()
            s_ref = weakref.ref(s)
            s.dispose()
            return s_ref

    s_ref = _run_and_dispose()

    for _ in range(5):
        gc.collect()

    assert s_ref() is None


def test_modified_path() -> None:
    original_path = sys.path.copy()
    test_path = os.path.abspath("test_path_dummy")
    with _ModifiedPath(test_path):
        assert sys.path[0] == test_path
        assert test_path in sys.path
    assert sys.path == original_path
    assert test_path not in sys.path


def test_modified_argv0() -> None:
    original_argv0 = sys.argv[0]
    test_argv0 = "test_script_argv0.py"
    with _ModifiedArgv0(test_argv0):
        assert sys.argv[0] == test_argv0
    assert sys.argv[0] == original_argv0


def test_load_script_dunder_attributes(tmp_path: Path) -> None:
    script_path = tmp_path / "test_script.vpy"
    script_path.write_text(
        "from tests._testutils import BLACKBOARD; "
        "BLACKBOARD['script_dunders'] = {k: v for k, v in globals().items() if k.startswith('__')}"
    )

    BLACKBOARD.clear()

    with Policy(GlobalStore()) as p, p.new_environment() as env, env.use():
        load_script(script_path).result()

    dunders = BLACKBOARD["script_dunders"]
    assert dunders["__file__"] == os.path.abspath(os.path.normpath(str(script_path)))
    assert dunders["__name__"] == "__vapoursynth__"
    assert "__cached__" in dunders
    assert "__doc__" in dunders
    assert "__loader__" in dunders
    assert "__package__" in dunders
    assert "__spec__" in dunders


def test_load_code_dunder_attributes() -> None:
    code = (
        "from tests._testutils import BLACKBOARD; "
        "BLACKBOARD['code_dunders'] = {k: v for k, v in globals().items() if k.startswith('__')}"
    )

    BLACKBOARD.clear()
    filename = "test_code_attributes.py"
    # Create the file so resolve works as expected if it exists check is used
    Path(filename).touch()
    try:
        with Policy(GlobalStore()) as p, p.new_environment() as env, env.use():
            load_code(code, filename=filename).result()

        dunders = BLACKBOARD["code_dunders"]
        assert dunders["__file__"] == os.path.abspath(os.path.normpath(filename))
        assert dunders["__name__"] == "__vapoursynth__"
    finally:
        if os.path.exists(filename):
            os.remove(filename)


def test_load_script_adds_to_path(tmp_path: Path) -> None:
    # Create a submodule in a temp directory
    sub_dir = tmp_path / "my_module"
    sub_dir.mkdir()
    (sub_dir / "__init__.py").write_text("VAL = 42")

    script_path = tmp_path / "main_script.vpy"
    script_path.write_text(
        "from tests._testutils import BLACKBOARD; import my_module; BLACKBOARD['module_val'] = my_module.VAL"
    )

    BLACKBOARD.clear()

    with Policy(GlobalStore()) as p, p.new_environment() as env, env.use():
        load_script(script_path).result()

    assert BLACKBOARD["module_val"] == 42
