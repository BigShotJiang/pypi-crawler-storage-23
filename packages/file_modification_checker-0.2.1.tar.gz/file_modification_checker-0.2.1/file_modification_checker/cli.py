from .modified_checker import find_differences as find
from pathlib import Path
import argparse
parser = argparse.ArgumentParser(description="tool to check for modifications")
parser.add_argument("folder", help="Name of folder to scan.")
parser.add_argument("-e","--exclude", nargs="+", required= False, default=[], help = "file suffixes to exclude (seperate by spaces)")
parser.add_argument("-i", "--information", nargs = "+", required = False, default = [], help="gives information on the files")
parser.add_argument("-ba", "--before_after", nargs="+", required=False, default = ["after"], help="gives information on the files before and after the changes")
args=parser.parse_args()
folder = Path(args.folder)
new, deleted, modified, before_changes_info, after_changes_info = find(folder)

def return_values():
    # Determine which info types to show based on -i/--information argument
    # Default to all info types if not specified
    # Always include "name" even if not specified
    if args.information:
        info_types = args.information
        if "name" not in info_types:
            info_types.insert(0, "name")
    else:
        info_types = ["name", "size", "date", "permissions", "owner", "group", "contents"]
    
    # Create mappings from filename (just the name) to info for easier lookup
    before_map = {info["name"]: info for info in before_changes_info}
    after_map = {info["name"]: info for info in after_changes_info}
    
    # Process each change type and build dictionaries
    new_result = []
    deleted_result = []
    modified_result = []
    
    for change in new.copy():
        if change.suffix in args.exclude:
            continue
        change_dict = {}
        # New files only have "after" info - use just the filename for lookup
        after_info = after_map.get(change.name)
        if after_info:
            for key in info_types:
                if key in after_info:
                    if "after" in args.before_after:
                        change_dict[key] = {"after": after_info[key]}
                    else:
                        change_dict[key] = {"before": after_info[key]}
            new_result.append(change_dict)
    
    for change in deleted.copy():
        if change.suffix in args.exclude:
            continue
        change_dict = {}
        # Deleted files only have "before" info - use just the filename for lookup
        before_info = before_map.get(change.name)
        if before_info:
            for key in info_types:
                if key in before_info:
                    if "before" in args.before_after:
                        change_dict[key] = {"before": before_info[key]}
                    else:
                        change_dict[key] = {"after": before_info[key]}
            deleted_result.append(change_dict)
    
    for change in modified.copy():
        if change.suffix in args.exclude:
            continue
        change_dict = {}
        # Modified files have both - use just the filename for lookup
        before_info = before_map.get(change.name)
        after_info = after_map.get(change.name)
        if before_info and after_info:
            for key in info_types:
                if key in before_info and key in after_info:
                    if "before" in args.before_after and "after" in args.before_after:
                        change_dict[key] = {"before": before_info[key], "after": after_info[key]}
                    elif "after" in args.before_after:
                        change_dict[key] = {"after": after_info[key]}
                    else:
                        change_dict[key] = {"before": before_info[key]}
            modified_result.append(change_dict)
    
    print(f"\033[31mDeleted Files:\033[0m")
    for file_dict in deleted_result:
        for key, value in file_dict.items():
            if "before" in value:
                print(f"\033[31m        {key}: {value['before']}\033[0m")
            else:
                print(f"\033[31m        {key}: No Information Available\033[0m")
        print()
    
    print(f"\033[32mAdded Files:\033[0m")
    for file_dict in new_result:
        for key, value in file_dict.items():
            if "after" in value:
                print(f"\033[32m        {key}: {value['after']}\033[0m")
            else:
                print(f"\033[32m        {key}: No Information Available\033[0m")
        print()
    
    print(f"\033[33mModified Files:\033[0m")
    for file_dict in modified_result:
        for key, value in file_dict.items():
            if "before" in value and "after" in value:
                print(f"\033[33m        {key} - Before: {value['before']}, After: {value['after']}\033[0m")
            elif "before" in value:
                print(f"\033[33m        {key}: {value['before']}\033[0m")
            elif "after" in value:
                print(f"\033[33m        {key}: {value['after']}\033[0m")
        print()
