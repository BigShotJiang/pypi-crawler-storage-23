from pathlib import Path
def get_file_sizes(folder:Path)->list:
    list_of_file_sizes = []
    for item in folder.iterdir():
        if item.is_file():
            list_of_file_sizes.append(item)
        else:
            list_of_file_sizes.extend(get_file_sizes(item))
            continue
    return list_of_file_sizes
def get_file_information(file:Path)->dict:
    return {
        "name": file.name,
        "size": file.stat().st_size,
        "date": file.stat().st_mtime,
        "permissions": file.stat().st_mode,
        "owner": file.stat().st_uid,
        "group": file.stat().st_gid,
        "contents": file.read_text()
    }
def find_differences(folder)->list:
    before_changes = get_file_sizes(folder)
    before_changes_info = [get_file_information(file) for file in before_changes]
    input("Make changes to the files in the folder and press Enter when done. ")
    after_changes = get_file_sizes(folder)
    after_changes_info = [get_file_information(file) for file in after_changes]
    deleted_differences = [file for file in before_changes if file not in after_changes]
    new_differences = [file for file in after_changes if file not in before_changes]
    modified_differences = []
    before_changes = [file for file in before_changes if file not in deleted_differences]
    after_changes = [file for file in after_changes if file not in new_differences]
    for index in range(len(before_changes)):
        file = before_changes[index]
        if before_changes_info[index]["contents"] != after_changes_info[index]["contents"]:
            modified_differences.append(file) 
    return new_differences, deleted_differences, modified_differences, before_changes_info, after_changes_info