# Modification Checking Tool
A fast CLI tool to detect new, deleted, and modified files in a folder.

## 0.1.0

### Installing and Importing
> **Installing**
Use:
```bash
pip install file_modfication_checker==0.1.0
```
>**Importing**
Use:
```python
import file_modfication_checker
```
>**Output**
Use:
```python
find_differences(folder) = new, deleted, modified
```
### Command Usage
> **How To Use**
Usage:
```bash
mcheck <folder> [OPTIONS]
```
Arguments:
<folder>           Name of folder to check

Options:
-e, --exclude     File types to ignore

> **Result**
- Red Text: files that were deleted
- Green Text: files that were added
- Yellow Text: files that were modified

## 0.2.0

### Installing and Importing
> **Installing**
Use:
```bash
pip install file_modfication_checker==0.2.0
```
>**Importing**
Use:
```python
import file_modfication_checker
```
>**Output**
Use:
```python
find_differences(folder) = new, deleted, modified
```
### Comand Usage
> **How To Use**
Usage:
```bash
mcheck <folder> [OPTIONS]
```
Arguments:
<folder>           Name of folder to check

Options:
-e, --exclude      File types to ignore

-i, --information  Type of information to show

> **Result**
- Red Text: files that were deleted - no infromation will be given
- Green Text: files that were added - requested information will be given
- Yellow Text: files that were modified - requested information will be given

## 0.2.1

### Installing and Importing
> **Installing**
Use:
```bash
pip install file_modfication_checker==0.2.0
```
>**Importing**
Use:
```python
import file_modfication_checker
```
>**Output**
Use:
```python
find_differences(folder) = new, deleted, modified, before_changes_information, after_changes_information
```
### Comand Usage
> **How To Use**
Usage:
```bash
mcheck <folder> [OPTIONS]
```
Arguments:
<folder>           Name of folder to check

Options:
-e, --exclude      File types to ignore

-i, --information  Type of information to show

-ba, --before/after present or past information to show

> **Result**
- Red Text: files that were deleted - requested inforation before the deletion will be given
- Green Text: files that were added - requested information after the addition will be given
- Yellow Text: files that were modified - requested information after the modification and/or before the modification will be given