"""Tests for wiremock-mock."""
