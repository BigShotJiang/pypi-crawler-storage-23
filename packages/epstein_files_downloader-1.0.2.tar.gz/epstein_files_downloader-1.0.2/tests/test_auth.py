"""Tests for the auth module."""

import pytest
from pathlib import Path

from epstein_downloader.auth import AuthManager


class TestAuthManager:
    """Tests for AuthManager class."""

    def test_default_auth_file(self):
        """Test default auth file location."""
        auth = AuthManager()
        assert auth.auth_file == Path.home() / ".config" / "epstein-downloader" / "auth.json"

    def test_custom_auth_file(self, tmp_path):
        """Test custom auth file location."""
        custom_path = tmp_path / "custom-auth.json"
        auth = AuthManager(auth_file=custom_path)
        assert auth.auth_file == custom_path

    def test_is_authenticated_missing_file(self, tmp_path):
        """Test is_authenticated returns False when file doesn't exist."""
        auth = AuthManager(auth_file=tmp_path / "nonexistent.json")
        assert auth.is_authenticated() is False

    def test_is_authenticated_empty_file(self, tmp_path):
        """Test is_authenticated returns False when file is empty."""
        auth_file = tmp_path / "empty.json"
        auth_file.write_text("")
        auth = AuthManager(auth_file=auth_file)
        assert auth.is_authenticated() is False

    def test_is_authenticated_valid_file(self, tmp_path):
        """Test is_authenticated returns True when file exists and has content."""
        auth_file = tmp_path / "valid.json"
        auth_file.write_text('{"cookies": []}')
        auth = AuthManager(auth_file=auth_file)
        assert auth.is_authenticated() is True

    def test_auth_file_directory_created(self, tmp_path):
        """Test that auth file directory is created."""
        nested_dir = tmp_path / "deep" / "nested" / "dir"
        auth = AuthManager(auth_file=nested_dir / "auth.json")
        assert nested_dir.exists()
