"""Tests for the downloader module."""

import pytest
from pathlib import Path

from epstein_downloader.downloader import DownloadItem, Downloader


class TestDownloadItem:
    """Tests for DownloadItem class."""

    def test_pdf_url_conversion(self):
        """Test URL conversion to PDF format."""
        item = DownloadItem("https://example.com/file.doc")
        assert item.pdf_url == "https://example.com/file.pdf"

    def test_extension_extraction(self):
        """Test original extension extraction."""
        item = DownloadItem("https://example.com/file.doc")
        assert item.extension == ".doc"

    def test_no_extension(self):
        """Test handling of URLs without extension."""
        item = DownloadItem("https://example.com/file")
        assert item.extension == ""
        assert item.pdf_url == "https://example.com/file.pdf"

    def test_filename_generation(self):
        """Test filename generation."""
        item = DownloadItem("https://example.com/my%20file.doc")
        assert item.filename == "my file.doc"

    def test_filename_no_extension(self):
        """Test filename generation without extension."""
        item = DownloadItem("https://example.com/file")
        assert item.filename == "file.pdf"


class TestDownloader:
    """Tests for Downloader class."""

    def test_extract_urls(self):
        """Test URL extraction from text."""
        downloader = Downloader()
        text = "Here are two URLs: https://example.com/1 and https://example.com/2"
        urls = downloader.extract_urls(text)
        assert len(urls) == 2
        assert "https://example.com/1" in urls
        assert "https://example.com/2" in urls

    def test_extract_urls_deduplication(self):
        """Test that duplicate URLs are deduplicated."""
        downloader = Downloader()
        text = "https://example.com/1 https://example.com/1 https://example.com/2"
        urls = downloader.extract_urls(text)
        assert len(urls) == 2

    def test_extract_urls_from_file(self, tmp_path):
        """Test URL extraction from file."""
        test_file = tmp_path / "urls.txt"
        test_file.write_text("https://example.com/1\nhttps://example.com/2\n")
        
        downloader = Downloader()
        urls = downloader.extract_urls_from_file(test_file)
        assert len(urls) == 2

    def test_download_dir_creation(self, tmp_path):
        """Test that download directory is created."""
        download_dir = tmp_path / "new_dir"
        Downloader(download_dir=download_dir)
        assert download_dir.exists()
