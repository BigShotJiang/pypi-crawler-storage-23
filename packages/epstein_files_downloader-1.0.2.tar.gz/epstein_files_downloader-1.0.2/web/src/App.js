import React, { useState, useCallback, useEffect } from 'react';
import './App.css';

function App() {
  const [inputText, setInputText] = useState('');
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [status, setStatus] = useState(null);
  const [authStep, setAuthStep] = useState('start'); // start, verifying, verified
  const [isOpeningAll, setIsOpeningAll] = useState(false);
  const [blockedCount, setBlockedCount] = useState(0);

  // Check auth status on load
  useEffect(() => {
    const hasVisited = localStorage.getItem('epstein-doj-visited');
    if (hasVisited) {
      setAuthStep('verified');
    }
  }, []);

  const startAuth = () => {
    setAuthStep('verifying');
    // Open DOJ in new tab
    window.open('https://www.justice.gov/epstein', '_blank');
  };

  const completeAuth = () => {
    localStorage.setItem('epstein-doj-visited', 'true');
    setAuthStep('verified');
    setStatus('✅ Age verification confirmed! You can now download files.');
  };

  const resetAuth = () => {
    localStorage.removeItem('epstein-doj-visited');
    setAuthStep('start');
    setStatus(null);
  };

  // Extract URLs from input text
  const extractUrls = useCallback(async () => {
    if (!inputText.trim()) {
      setError('Please paste some text containing URLs');
      return;
    }

    setLoading(true);
    setError(null);
    setStatus('Extracting URLs...');

    try {
      const urlRegex = /https:\/\/[^\s"'<>]+/g;
      const matches = inputText.match(urlRegex) || [];
      const uniqueUrls = [...new Set(matches)].sort();
      
      const newItems = uniqueUrls.map(url => {
        const decoded = decodeURIComponent(url);
        const filename = decoded.split('/').pop() || 'unknown.pdf';
        return {
          url,
          filename: filename.endsWith('.pdf') ? filename : filename + '.pdf',
          status: 'pending',
          openedAt: null
        };
      });

      setItems(newItems);
      setStatus(`Found ${newItems.length} file(s). Click Download All or download individually.`);
    } catch (err) {
      setError(err.message);
      setStatus(null);
    } finally {
      setLoading(false);
    }
  }, [inputText]);

  // Open a single file
  const openFile = useCallback((index, isManual = false) => {
    const item = items[index];
    if (!item) return false;

    try {
      const newWindow = window.open(item.url, '_blank');
      
      if (newWindow) {
        setItems(prev => prev.map((it, i) => 
          i === index ? { 
            ...it, 
            status: 'opened', 
            openedAt: new Date().toLocaleTimeString()
          } : it
        ));
        
        if (isManual) {
          setStatus(`Downloaded: ${item.filename}`);
        }
        return true;
      } else {
        setItems(prev => prev.map((it, i) => 
          i === index ? { ...it, status: 'error', error: 'Popup blocked' } : it
        ));
        if (isManual) {
          setError(`Popup blocked! Please allow popups for this site.`);
        }
        return false;
      }
    } catch (err) {
      setItems(prev => prev.map((it, i) => 
        i === index ? { ...it, status: 'error', error: err.message } : it
      ));
      return false;
    }
  }, [items]);

  // Open all pending files
  const openAll = useCallback(async (retryBlocked = false) => {
    if (items.length === 0 || isOpeningAll) return;

    const targetItems = retryBlocked 
      ? items.filter(it => it.status === 'error' || it.error === 'Popup blocked')
      : items.filter(it => it.status === 'pending');

    if (targetItems.length === 0) {
      setStatus(retryBlocked ? 'No blocked files to retry' : 'All files have been downloaded');
      return;
    }

    if (targetItems.length > 10) {
      const confirmed = window.confirm(
        `You're about to open ${targetItems.length} tabs. Your browser may block this. Continue?`
      );
      if (!confirmed) return;
    }

    setIsOpeningAll(true);
    setError(null);
    setBlockedCount(0);

    // Check for popup blocker
    const testWindow = window.open('', '_blank');
    if (!testWindow || testWindow.closed) {
      setError('⚠️ Popup blocker detected! Please allow popups for this site and try again.');
      setIsOpeningAll(false);
      return;
    }
    testWindow.close();

    let downloaded = 0;
    let blocked = 0;

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const isTarget = retryBlocked 
        ? (item.status === 'error' || item.error === 'Popup blocked')
        : item.status === 'pending';
      
      if (!isTarget) continue;

      setStatus(`Downloading ${downloaded + blocked + 1} of ${targetItems.length}...`);
      
      // Reset error status before retrying
      if (item.status === 'error') {
        setItems(prev => prev.map((it, idx) => 
          idx === i ? { ...it, status: 'pending', error: null } : it
        ));
      }
      
      const success = openFile(i, false);
      if (success) downloaded++; else blocked++;

      if (i < items.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 800));
      }
    }

    setIsOpeningAll(false);
    setBlockedCount(blocked);
    
    if (blocked > 0) {
      setStatus(`${downloaded} downloaded, ${blocked} blocked by popup blocker`);
    } else {
      setStatus(`✅ Downloaded ${downloaded} file(s)`);
    }
  }, [items, isOpeningAll, openFile]);

  const cancelOpening = useCallback(() => {
    setIsOpeningAll(false);
    setStatus('Cancelled');
  }, []);

  const clearAll = useCallback(() => {
    if (isOpeningAll) cancelOpening();
    setInputText('');
    setItems([]);
    setError(null);
    setStatus(null);
    setBlockedCount(0);
  }, [isOpeningAll, cancelOpening]);

  const resetOpened = useCallback(() => {
    setItems(prev => prev.map(it => 
      it.status === 'opened' ? { ...it, status: 'pending', openedAt: null } : it
    ));
    setStatus('Reset - ready to download again');
  }, []);

  

  const formatFilename = (filename) => {
    if (filename.length > 50) {
      return filename.substring(0, 25) + '...' + filename.substring(filename.length - 20);
    }
    return filename;
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'opened': return '✓';
      case 'error': return '!';
      default: return '○';
    }
  };

  const stats = {
    total: items.length,
    opened: items.filter(i => i.status === 'opened').length,
    pending: items.filter(i => i.status === 'pending').length,
    error: items.filter(i => i.status === 'error').length
  };

  // Render auth step
  const renderAuthStep = () => {
    switch (authStep) {
      case 'start':
        return (
          <div className="auth-step">
            <div className="step-number">1</div>
            <div className="step-content">
              <h3>Complete Age Verification</h3>
              <p>
                Before you can download files, you need to visit the DOJ website and 
                confirm you are 18+ years old.
              </p>
              <button onClick={startAuth} className="btn-primary btn-large">
                🌐 Open DOJ Website
              </button>
              <p className="step-hint">
                A new tab will open. Click "Yes" on the age check, then return here.
              </p>
            </div>
          </div>
        );
      
      case 'verifying':
        return (
          <div className="auth-step verifying">
            <div className="step-number active">1</div>
            <div className="step-content">
              <h3>Waiting for Verification...</h3>
              <p>
                A new tab should have opened with the DOJ website. 
                Please click <strong>"Yes"</strong> to confirm you are 18+, then come back here.
              </p>
              <div className="step-actions">
                <button onClick={completeAuth} className="btn-success btn-large">
                  ✅ I've Clicked "Yes"
                </button>
                <button onClick={() => setAuthStep('start')} className="btn-secondary">
                  ↩️ Start Over
                </button>
              </div>
            </div>
          </div>
        );
      
      case 'verified':
        return (
          <div className="auth-step verified">
            <div className="step-number done">✓</div>
            <div className="step-content">
              <h3>Age Verification Complete</h3>
              <p>You can now download files. The DOJ cookie is saved in your browser.</p>
              <button onClick={resetAuth} className="btn-text">
                Reset (if downloads aren't working)
              </button>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>📄 Epstein Files Downloader</h1>
        <p>Download PDFs from the DOJ Epstein files</p>
      </header>

      <main className="App-main">
        {/* Auth Section */}
        <section className="auth-section">
          {renderAuthStep()}
        </section>

        {/* Step 2: Paste URLs */}
        {authStep === 'verified' && (
          <section className="input-section">
            <div className="section-header">
              <div className="step-number">2</div>
              <h2>Paste File URLs</h2>
            </div>
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Paste your URLs here, one per line...&#10;&#10;Example:&#10;https://www.justice.gov/epstein/files/DataSet%209/EFTA00639714.pdf&#10;https://www.justice.gov/epstein/files/DataSet%209/EFTA00639715.pdf"
              rows={6}
              disabled={loading || isOpeningAll}
            />
            <div className="button-row">
              <button
                onClick={extractUrls}
                disabled={loading || !inputText.trim() || isOpeningAll}
                className="btn-primary"
              >
                {loading ? '⏳ Processing...' : '🔍 Find Files'}
              </button>
              <button
                onClick={clearAll}
                disabled={loading || isOpeningAll}
                className="btn-secondary"
              >
                Clear
              </button>
            </div>
          </section>
        )}

        {/* Status Messages */}
        {status && (
          <div className={`status-message ${status.includes('✅') ? 'success' : ''}`}>
            {isOpeningAll && <span className="spinner" />} {status}
          </div>
        )}

        {error && (
          <div className="error-message">
            {error}
          </div>
        )}

        {/* File List */}
        {items.length > 0 && authStep === 'verified' && (
          <section className="files-section">
            <div className="section-header">
              <div className="step-number">3</div>
              <h2>Download Files ({items.length})</h2>
            </div>

            {/* Stats */}
            <div className="stats-bar">
              <span className={`stat ${stats.opened > 0 ? 'done' : ''}`}>
                ✓ {stats.opened} downloaded
              </span>
              <span className="stat">
                ○ {stats.pending} remaining
              </span>
              {stats.error > 0 && (
                <span className="stat error">
                  ! {stats.error} error
                </span>
              )}
            </div>

            {/* Batch Actions */}
            <div className="batch-actions">
              {isOpeningAll ? (
                <button onClick={cancelOpening} className="btn-danger">
                  ⏹ Cancel Download
                </button>
              ) : blockedCount > 0 ? (
                <>
                  <button
                    onClick={() => openAll(true)}
                    className="btn-warning btn-large"
                  >
                    🔄 Retry Blocked ({blockedCount})
                  </button>
                  <button
                    onClick={() => {
                      setBlockedCount(0);
                      setStatus(null);
                    }}
                    className="btn-secondary"
                  >
                    Dismiss
                  </button>
                </>
              ) : (
                <button
                  onClick={() => openAll(false)}
                  disabled={stats.pending === 0}
                  className="btn-primary btn-large"
                >
                  ⬇️ Download All ({stats.pending})
                </button>
              )}
              {stats.opened > 0 && blockedCount === 0 && (
                <button onClick={resetOpened} className="btn-secondary">
                  🔄 Download Again
                </button>
              )}
            </div>

            {/* File List */}
            <div className="file-list">
              {items.map((item, index) => (
                <div key={index} className={`file-item ${item.status}`}>
                  <span className="file-status">{getStatusIcon(item.status)}</span>
                  <span className="file-number">{index + 1}</span>
                  <span className="file-name" title={item.url}>
                    {formatFilename(item.filename)}
                    {item.openedAt && (
                      <span className="file-time">at {item.openedAt}</span>
                    )}
                  </span>
                  <div className="file-actions">
                    <button
                      onClick={() => openFile(index, true)}
                      disabled={isOpeningAll}
                      className={item.status === 'opened' ? 'btn-done' : 'btn-open'}
                    >
                      {item.status === 'opened' ? '✓ Downloaded' : '⬇️ Download'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* How it works */}
        <section className="help-section">
          <h3>How This Works</h3>
          <ol>
            <li>
              <strong>Age Verification:</strong> DOJ requires you to confirm you're 18+. 
              Click the button to open their site, click "Yes", then return here.
            </li>
            <li>
              <strong>Paste URLs:</strong> Paste the PDF links you want to download.
            </li>
            <li>
              <strong>Download:</strong> Click "Download" to open each PDF in a new tab. 
              Your browser will automatically save the file.
            </li>
          </ol>
          <div className="help-note">
            <strong>Tip:</strong> If downloads aren't working, make sure you've allowed 
            popups for this site. Files open in new tabs due to browser security restrictions.
          </div>
        </section>
      </main>

      <footer className="App-footer">
        <p>
          <a href="https://github.com/hackingbutlegal/epstein-files-downloader" target="_blank" rel="noopener noreferrer">
            GitHub
          </a>
          {' • '}
          <span>100% client-side, no data collection</span>
        </p>
      </footer>
    </div>
  );
}

export default App;
