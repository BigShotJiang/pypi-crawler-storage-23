"""Epstein Files Downloader - A tool to download PDFs from the DOJ Epstein files."""

__version__ = "1.0.2"
__all__ = ["Downloader", "AuthManager"]

from epstein_downloader.downloader import Downloader
from epstein_downloader.auth import AuthManager
