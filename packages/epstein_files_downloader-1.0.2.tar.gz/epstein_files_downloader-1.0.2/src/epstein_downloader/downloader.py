"""Main downloader functionality for Epstein files."""

from __future__ import annotations

import re
from pathlib import Path
from typing import TYPE_CHECKING
from urllib.parse import unquote, urlparse, urlunparse

from playwright.sync_api import sync_playwright

from epstein_downloader.auth import AuthManager

if TYPE_CHECKING:
    from playwright.sync_api import APIRequestContext, BrowserContext, Page


class DownloadItem:
    """Represents a single file to download."""

    def __init__(self, orig_url: str) -> None:
        """
        Initialize download item from original URL.

        Args:
            orig_url: The original URL found in the source file.
        """
        self.orig_url = orig_url
        # URL can be:
        # 1. Direct PDF: /files/.../filename.pdf
        # 2. Document page: /file/{id}/dl (needs to be fetched via browser)
        self.is_direct_pdf = orig_url.lower().endswith('.pdf')
        self.pdf_url = orig_url if self.is_direct_pdf else None
        self.extension = self._extract_extension(orig_url)

    @staticmethod
    def _extract_extension(url: str) -> str:
        """Extract original file extension from URL."""
        # Decode URL encoding first
        decoded = unquote(url)
        name = urlparse(decoded).path.split("/")[-1]
        return ("." + name.rsplit(".", 1)[1]) if "." in name else ""

    @property
    def filename(self) -> str:
        """Generate output filename."""
        decoded = unquote(self.orig_url)
        name = urlparse(decoded).path.split("/")[-1]
        # If no extension or it's not pdf, use pdf
        if not self.extension:
            return name + ".pdf"
        return name


class Downloader:
    """Downloads PDFs from the DOJ Epstein files website."""

    URL_RE = re.compile(r"https://[^\s\"']+")
    LANDING_PAGE = "https://www.justice.gov/epstein"
    DEFAULT_TIMEOUT = 60_000  # 60 seconds

    def __init__(
        self,
        download_dir: str | Path = "downloads",
        auth_file: str | Path | None = None,
        timeout: int = DEFAULT_TIMEOUT,
    ) -> None:
        """
        Initialize the downloader.

        Args:
            download_dir: Directory to save downloaded files.
            auth_file: Path to authentication state file.
            timeout: Request timeout in milliseconds.
        """
        self.download_dir = Path(download_dir)
        self.download_dir.mkdir(exist_ok=True)
        self.auth_manager = AuthManager(auth_file)
        self.timeout = timeout

    def extract_urls(self, text: str) -> list[str]:
        """
        Extract URLs from text content.

        Args:
            text: Text containing URLs.

        Returns:
            List of unique URLs found in the text.
        """
        return sorted(set(self.URL_RE.findall(text)))

    def extract_urls_from_file(self, path: str | Path) -> list[str]:
        """
        Extract URLs from a file.

        Args:
            path: Path to file containing URLs.

        Returns:
            List of unique URLs found in the file.
        """
        text = Path(path).read_text(encoding="utf-8", errors="ignore")
        return self.extract_urls(text)

    def download(
        self,
        urls: list[str],
        progress: bool = True,
        retry_auth: bool = True,
    ) -> list[Path]:
        """
        Download files from URLs.

        Args:
            urls: List of URLs to download.
            progress: Whether to print progress messages.
            retry_auth: Whether to retry with re-auth on 401/403 errors.

        Returns:
            List of paths to successfully downloaded files.
        """
        items = [DownloadItem(u) for u in urls]
        # Deduplicate by original URL
        seen: dict[str, DownloadItem] = {}
        for item in items:
            seen[item.orig_url] = item
        items = list(seen.values())

        if progress:
            print(f"After deduplication: {len(items)} unique files to download")

        downloaded: list[Path] = []

        with sync_playwright() as p:
            if not self.auth_manager.is_authenticated():
                if progress:
                    print("Authentication required...")
                self.auth_manager.authenticate(headless=False)

            browser = p.chromium.launch(headless=True)

            try:
                context = self.auth_manager.load_context(browser)
                page = context.new_page()
                page.goto(self.LANDING_PAGE, wait_until="networkidle")

                for i, item in enumerate(items, 1):
                    if progress:
                        print(f"[{i}/{len(items)}] {item.orig_url}")

                    try:
                        path = self._download_single(context, page, item)
                        if path:
                            downloaded.append(path)
                            if progress:
                                print(f"  -> saved {path}")

                    except Exception as e:
                        error_str = str(e)
                        if progress:
                            print(f"  !! Error: {e}")

                        if retry_auth and ("403" in error_str or "401" in error_str):
                            if progress:
                                print("  Auth cookie expired. Re-authenticating...")

                            self._cleanup(context, page)
                            self.auth_manager.authenticate(headless=False)

                            context = self.auth_manager.load_context(browser)
                            page = context.new_page()
                            page.goto(self.LANDING_PAGE, wait_until="networkidle")

                            try:
                                path = self._download_single(context, page, item)
                                if path:
                                    downloaded.append(path)
                                    if progress:
                                        print(f"  -> saved after re-auth: {path}")
                            except Exception as e2:
                                if progress:
                                    print(f"  !! Still failed after re-auth: {e2}")
                        elif progress:
                            print(f"  !! Non-auth error, skipping")

                self._cleanup(context, page)
            finally:
                browser.close()

        return downloaded

    def _download_single(
        self, context: BrowserContext, page: Page, item: DownloadItem
    ) -> Path | None:
        """
        Download a single file.

        Args:
            context: Playwright browser context.
            page: Playwright page for navigation.
            item: DownloadItem to download.

        Returns:
            Path to downloaded file, or None if failed.

        Raises:
            Exception: If download fails (non-200 status).
        """
        url = item.orig_url
        
        if item.is_direct_pdf:
            # Direct PDF URL - fetch with request context
            response = context.request.get(url, timeout=self.timeout)
            
            if response.status == 200:
                content_type = response.headers.get('content-type', '')
                body = response.body()
                
                # Verify it's actually a PDF
                if body[:4] != b'%PDF' and 'pdf' not in content_type.lower():
                    # Might be HTML error page
                    raise Exception(f"Got non-PDF content (type: {content_type}, size: {len(body)})")
                
                target_path = self.download_dir / item.filename
                target_path.write_bytes(body)
                return target_path
            else:
                raise Exception(f"HTTP {response.status}")
        else:
            # Document page URL (/file/{id}/dl) - use browser to download
            # Navigate to the URL and wait for any redirects
            response = page.goto(url, wait_until="networkidle")
            
            if not response:
                raise Exception("No response from page")
            
            # Check if we got redirected to the PDF or if the page has a download link
            current_url = page.url
            
            if current_url.lower().endswith('.pdf'):
                # Redirected to PDF directly
                pdf_response = context.request.get(current_url, timeout=self.timeout)
                if pdf_response.status == 200:
                    target_path = self.download_dir / item.filename
                    target_path.write_bytes(pdf_response.body())
                    return target_path
                else:
                    raise Exception(f"PDF download failed: HTTP {pdf_response.status}")
            else:
                # Look for actual PDF link on the page
                pdf_link = page.eval_on_selector(
                    "a[href$='.pdf']", 
                    "el => el.href"
                )
                
                if pdf_link:
                    pdf_response = context.request.get(pdf_link, timeout=self.timeout)
                    if pdf_response.status == 200:
                        # Update filename from the PDF link
                        pdf_name = unquote(pdf_link.split("/")[-1])
                        target_path = self.download_dir / pdf_name
                        target_path.write_bytes(pdf_response.body())
                        return target_path
                    else:
                        raise Exception(f"PDF link failed: HTTP {pdf_response.status}")
                else:
                    # Try to trigger download via page
                    raise Exception(f"Could not find PDF link on page (URL: {current_url})")

    def _cleanup(self, context: BrowserContext, page: Page) -> None:
        """Safely close page and context."""
        try:
            page.close()
        except Exception:
            pass
        try:
            context.close()
        except Exception:
            pass
