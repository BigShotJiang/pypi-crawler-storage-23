"""Authentication management for DOJ Epstein files access."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from playwright.sync_api import sync_playwright

if TYPE_CHECKING:
    from playwright.sync_api import Browser, BrowserContext, Page


class AuthManager:
    """Manages authentication for the DOJ Epstein files website."""

    DEFAULT_AUTH_FILE = Path.home() / ".config" / "epstein-downloader" / "auth.json"
    LANDING_PAGE = "https://www.justice.gov/epstein"

    def __init__(self, auth_file: str | Path | None = None) -> None:
        """
        Initialize the AuthManager.

        Args:
            auth_file: Path to store/load authentication state.
                      Defaults to ~/.config/epstein-downloader/auth.json
        """
        self.auth_file = Path(auth_file) if auth_file else self.DEFAULT_AUTH_FILE
        self.auth_file.parent.mkdir(parents=True, exist_ok=True)

    def authenticate(self, headless: bool = False) -> None:
        """
        Perform interactive authentication with the DOJ website.

        Opens a browser window for the user to complete age verification.
        Saves the authenticated session to the auth file.

        Args:
            headless: If True, runs browser in headless mode (not recommended
                     for interactive auth). Defaults to False.
        """
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=headless)
            context = browser.new_context()
            page = context.new_page()

            try:
                self._perform_auth_flow(page, context)
            finally:
                browser.close()

    def _perform_auth_flow(
        self, page: Page, context: BrowserContext
    ) -> None:
        """Execute the authentication flow."""
        print(f"Opening {self.LANDING_PAGE}...")
        page.goto(self.LANDING_PAGE, wait_until="networkidle")

        print(
            "Please click 'Yes' on the age verification page, "
            "then press Enter here..."
        )
        input()

        # Wait for the /age-verify response to settle
        page.wait_for_load_state("networkidle")

        # Verify cookies were set
        cookies = context.cookies()
        age_cookies = [
            c for c in cookies
            if "age" in c["name"].lower() or "verify" in c["name"].lower()
        ]

        if not age_cookies:
            print(
                "WARNING: No age/verify cookie found — did you click 'Yes'?"
            )
        else:
            print(f"Found auth cookie(s): {[c['name'] for c in age_cookies]}")

        context.storage_state(path=self.auth_file)
        print(f"Auth state saved to {self.auth_file}")

    def is_authenticated(self) -> bool:
        """Check if valid authentication state exists."""
        return self.auth_file.exists() and self.auth_file.stat().st_size > 0

    def load_context(self, browser: Browser) -> BrowserContext:
        """
        Load an authenticated browser context.

        Args:
            browser: Playwright browser instance.

        Returns:
            BrowserContext with stored authentication state.

        Raises:
            FileNotFoundError: If auth file doesn't exist.
        """
        if not self.is_authenticated():
            raise FileNotFoundError(
                f"No auth file found at {self.auth_file}. "
                "Please run authentication first."
            )
        return browser.new_context(storage_state=self.auth_file)


def main() -> None:
    """CLI entry point for authentication."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Authenticate with DOJ Epstein files website"
    )
    parser.add_argument(
        "--auth-file",
        type=Path,
        help="Custom path for auth state file",
    )

    args = parser.parse_args()
    auth_manager = AuthManager(args.auth_file)
    auth_manager.authenticate(headless=False)


if __name__ == "__main__":
    main()
