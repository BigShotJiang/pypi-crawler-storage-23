"""Command-line interface for the Epstein Files Downloader."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from epstein_downloader.downloader import Downloader
from epstein_downloader.auth import AuthManager


def create_parser() -> argparse.ArgumentParser:
    """Create the argument parser."""
    parser = argparse.ArgumentParser(
        prog="epstein-download",
        description="Download PDFs from the DOJ Epstein files",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Authenticate (one-time setup)
  epstein-auth

  # Download from URLs in a file
  epstein-download -i urls.txt

  # Download to custom directory
  epstein-download -i urls.txt -o ./my-downloads

  # Use custom auth file location
  epstein-auth --auth-file ./my-auth.json
  epstein-download -i urls.txt --auth-file ./my-auth.json
        """.strip(),
    )

    parser.add_argument(
        "-i", "--input",
        type=Path,
        required=True,
        help="Input file containing URLs to download",
    )

    parser.add_argument(
        "-o", "--output",
        type=Path,
        default="downloads",
        help="Output directory for downloaded files (default: downloads)",
    )

    parser.add_argument(
        "--auth-file",
        type=Path,
        help="Path to authentication state file",
    )

    parser.add_argument(
        "--timeout",
        type=int,
        default=60000,
        help="Download timeout in milliseconds (default: 60000)",
    )

    parser.add_argument(
        "--no-retry",
        action="store_true",
        help="Don't retry with re-authentication on failure",
    )

    parser.add_argument(
        "-q", "--quiet",
        action="store_true",
        help="Suppress progress output",
    )

    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 1.0.0",
    )

    return parser


def main() -> int:
    """Main entry point."""
    parser = create_parser()
    args = parser.parse_args()

    # Validate input file
    if not args.input.exists():
        print(f"Error: Input file not found: {args.input}", file=sys.stderr)
        return 1

    # Create downloader
    downloader = Downloader(
        download_dir=args.output,
        auth_file=args.auth_file,
        timeout=args.timeout,
    )

    # Extract URLs
    if not args.quiet:
        print(f"Reading URLs from {args.input}...")

    urls = downloader.extract_urls_from_file(args.input)

    if not urls:
        print("No URLs found in input file.", file=sys.stderr)
        return 1

    if not args.quiet:
        print(f"Found {len(urls)} URLs")

    # Download
    try:
        downloaded = downloader.download(
            urls,
            progress=not args.quiet,
            retry_auth=not args.no_retry,
        )

        if not args.quiet:
            print(f"\nDownloaded {len(downloaded)} files to {args.output}")

        return 0

    except KeyboardInterrupt:
        print("\nDownload interrupted by user.", file=sys.stderr)
        return 130

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
