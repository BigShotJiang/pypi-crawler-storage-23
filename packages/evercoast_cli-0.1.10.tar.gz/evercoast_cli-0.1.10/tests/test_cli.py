"""Tests for Click CLI commands using CliRunner."""

import os
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from evercoast_cli.main import cli


@pytest.fixture
def runner():
    return CliRunner()


class TestCLIHelp:
    def test_main_help(self, runner):
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "Evercoast CLI" in result.output
        assert "login" in result.output
        assert "upload" in result.output

    def test_login_help(self, runner):
        result = runner.invoke(cli, ["login", "--help"])
        assert result.exit_code == 0
        assert "Authenticate" in result.output
        # --staging is hidden from help (internal use only)
        assert "--staging" not in result.output

    def test_upload_help(self, runner):
        result = runner.invoke(cli, ["upload", "--help"])
        assert result.exit_code == 0
        assert "--type" in result.output
        assert "--to" in result.output
        assert "--dry-run" in result.output
        assert "--no-checksum" in result.output
        assert "--exclude" in result.output
        assert "--yes" in result.output
        # --staging is hidden from help (internal use only)
        assert "--staging" not in result.output

    def test_version(self, runner):
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output


class TestUploadCommand:
    def test_missing_path_argument(self, runner):
        result = runner.invoke(cli, ["upload"])
        assert result.exit_code != 0
        assert "Missing argument" in result.output

    def test_nonexistent_path(self, runner):
        result = runner.invoke(cli, ["upload", "/nonexistent/path/12345"])
        assert result.exit_code != 0

    def test_invalid_type(self, runner, tmp_path):
        # Create a file so path exists
        test_file = tmp_path / "test.txt"
        test_file.write_text("test")
        result = runner.invoke(cli, ["upload", str(test_file), "--type", "invalid"])
        assert result.exit_code != 0
        assert "Invalid value" in result.output

    def test_valid_types_accepted(self, runner, tmp_path):
        """Verify valid --type values are accepted (will fail at config check)."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("test")

        for type_val in ["takes", "renders", "other"]:
            result = runner.invoke(cli, ["upload", str(test_file), "--type", type_val])
            # Should fail at "Not configured" not at argument parsing
            assert "Not configured" in result.output or "Error" in result.output

    def test_not_configured_error(self, runner, tmp_path):
        """Upload without login should show helpful error."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("test")

        with patch("evercoast_cli.main.Config") as MockConfig:
            mock_config = MagicMock()
            mock_config.get_profile_name.return_value = "default"
            mock_config.get_profile.return_value = None
            MockConfig.return_value = mock_config

            result = runner.invoke(cli, ["upload", str(test_file), "--type", "takes"])
            assert "Not configured" in result.output
            assert "evercoast login" in result.output

    def test_staging_flag_uses_staging_profile(self, runner, tmp_path):
        """--staging should check for staging profile."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("test")

        with patch("evercoast_cli.main.Config") as MockConfig:
            mock_config = MagicMock()
            mock_config.get_profile_name.return_value = "staging"
            mock_config.get_profile.return_value = None
            MockConfig.return_value = mock_config

            result = runner.invoke(cli, ["upload", str(test_file), "--type", "takes", "--staging"])
            mock_config.get_profile_name.assert_called_with(True)
            assert "Not configured" in result.output
            assert "evercoast login" in result.output

    def test_exclude_option_repeatable(self, runner, tmp_path):
        """--exclude should accept multiple values."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("test")

        result = runner.invoke(cli, [
            "upload", str(test_file),
            "--type", "takes",
            "--exclude", "*.log",
            "--exclude", "*.tmp",
        ])
        # Should fail at config check, not arg parsing
        assert result.exit_code != 0


class TestLoginCommand:
    def test_login_prompts_for_credentials(self, runner):
        """Login should prompt for email and password."""
        with patch("evercoast_cli.main.Config") as MockConfig, \
             patch("evercoast_cli.main.login") as mock_login_fn:
            mock_config = MagicMock()
            MockConfig.return_value = mock_config

            # Simulate empty email
            result = runner.invoke(cli, ["login"], input="\n")
            # Should either prompt or error on empty

    @patch("evercoast_cli.main.fetch_s3_credentials")
    @patch("evercoast_cli.main.login")
    def test_login_success_flow(self, mock_api_login, mock_fetch, runner, mock_s3_response):
        """Successful login should save config."""
        mock_api_login.return_value = "test-token"
        mock_fetch.return_value = mock_s3_response

        with patch("evercoast_cli.main.Config") as MockConfig, \
             patch("evercoast_cli.main.setup_aws_cli_profile", return_value=False):
            mock_config = MagicMock()
            mock_config.get_profile_name.return_value = "default"
            MockConfig.return_value = mock_config

            result = runner.invoke(cli, ["login"], input="user@test.com\npassword123\n")

            # Verify config was saved
            if result.exit_code == 0:
                mock_config.save_profile.assert_called_once()
                call_kwargs = mock_config.save_profile.call_args
                assert "test-token" in str(call_kwargs)

    def test_login_staging_flag(self, runner):
        """--staging should still work (hidden but functional)."""
        with patch("evercoast_cli.main.Config") as MockConfig, \
             patch("evercoast_cli.main.login") as mock_login_fn:
            mock_login_fn.side_effect = Exception("test stop")
            mock_config = MagicMock()
            mock_config.get_profile_name.return_value = "staging"
            MockConfig.return_value = mock_config

            result = runner.invoke(cli, ["login", "--staging"], input="user@test.com\npass\n")
            # Should not expose "STAGING" label to users
            assert "Authentication" in result.output
