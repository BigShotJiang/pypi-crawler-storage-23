"""API client for Evercoast backend.

Handles login, S3 credential fetching, and auto-refreshing boto3 sessions.
"""

import platform
import subprocess
import sys
from pathlib import Path
from typing import Dict, Optional

import boto3
import requests
from botocore.credentials import RefreshableCredentials
from botocore.session import get_session

from . import __version__

EC_AGENT_HEADER = "CB"
USER_AGENT = f"evercoast-cli/{__version__} ({platform.system()})"

# Common headers for all API calls
BASE_HEADERS = {
    "EC-Agent": EC_AGENT_HEADER,
    "Content-Type": "application/json",
    "User-Agent": USER_AGENT,
}


class APIError(Exception):
    """Raised when an API call fails."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        self.status_code = status_code
        super().__init__(message)


def login(api_url: str, email: str, password: str) -> str:
    """Authenticate with the Evercoast API and return an auth token.

    Uses EC-Agent: CB to create a Cloudbreak token that persists
    indefinitely and won't conflict with Mavericks sessions.

    Returns:
        Auth token string

    Raises:
        APIError: If login fails
    """
    try:
        resp = requests.post(
            f"{api_url}/login/",
            headers=BASE_HEADERS,
            json={"email": email, "password": password},
            timeout=30,
        )
    except requests.ConnectionError:
        raise APIError("Could not connect to Evercoast API. Check your internet connection.")
    except requests.Timeout:
        raise APIError("Connection to Evercoast API timed out.")

    if resp.status_code != 200:
        data = {}
        try:
            data = resp.json()
        except ValueError:
            pass
        msg = (
            data.get("detail")
            or data.get("error")
            or (data.get("non_field_errors") or [""])[0]
            or "Invalid credentials"
        )
        raise APIError(f"Login failed: {msg}", status_code=resp.status_code)

    data = resp.json()
    token = data.get("token")
    if not token:
        raise APIError("Login failed: no token received")

    return token


def fetch_s3_credentials(api_url: str, token: str) -> Dict:
    """Fetch S3 upload credentials from the API.

    Returns:
        Dict with keys: access_key_id, secret_access_key, session_token,
        expiration, bucket, region, upload_path

    Raises:
        APIError: If credential fetch fails
    """
    headers = {
        **BASE_HEADERS,
        "Authorization": f"Token {token}",
    }

    try:
        resp = requests.post(
            f"{api_url}/s3-credentials/",
            headers=headers,
            timeout=30,
        )
    except requests.ConnectionError:
        raise APIError("Could not connect to Evercoast API. Check your internet connection.")
    except requests.Timeout:
        raise APIError("Connection to Evercoast API timed out.")

    if resp.status_code == 401:
        raise APIError(
            "Authentication expired. Run 'evercoast login' to re-authenticate.",
            status_code=401,
        )

    if resp.status_code != 200:
        data = {}
        try:
            data = resp.json()
        except ValueError:
            pass
        msg = data.get("error") or data.get("detail") or "Unknown error"
        raise APIError(f"Failed to get S3 credentials: {msg}", status_code=resp.status_code)

    return resp.json()


def _make_refreshable_metadata(api_url: str, token: str) -> Dict[str, str]:
    """Fetch credentials and return in botocore RefreshableCredentials format."""
    data = fetch_s3_credentials(api_url, token)
    return {
        "access_key": data["access_key_id"],
        "secret_key": data["secret_access_key"],
        "token": data["session_token"],
        "expiry_time": data["expiration"],
    }


def get_s3_client(api_url: str, token: str, region: str):
    """Create an S3 client with auto-refreshing credentials.

    Uses botocore's RefreshableCredentials so credentials are automatically
    refreshed before expiration during long uploads.
    """
    credentials = RefreshableCredentials.create_from_metadata(
        metadata=_make_refreshable_metadata(api_url, token),
        refresh_using=lambda: _make_refreshable_metadata(api_url, token),
        method="sts-assume-role",
    )

    botocore_session = get_session()
    botocore_session._credentials = credentials
    boto3_session = boto3.Session(botocore_session=botocore_session)
    from botocore.config import Config as BotoConfig
    return boto3_session.client(
        "s3",
        region_name=region,
        config=BotoConfig(
            connect_timeout=10,
            read_timeout=30,
            retries={"max_attempts": 0},  # We handle retries ourselves
        ),
    )


def setup_aws_cli_profile(
    api_url: str,
    token: str,
    region: str,
    profile_name: str,
):
    """Set up an AWS CLI credential_process profile as a bonus.

    Creates a credential helper script and configures AWS CLI to use it.
    If AWS CLI is not installed, this is silently skipped.
    """
    # Check if AWS CLI is available
    try:
        subprocess.run(
            ["aws", "--version"],
            capture_output=True,
            check=True,
        )
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False

    config_dir = Path.home() / ".evercoast"
    config_dir.mkdir(parents=True, exist_ok=True)

    if platform.system() == "Windows":
        helper_path = config_dir / f"{profile_name}-credential-helper.ps1"
        helper_content = _generate_powershell_helper(api_url, token)
        helper_path.write_text(helper_content, encoding="utf-8")
        credential_process = f'powershell.exe -NoProfile -File "{helper_path}"'
    else:
        helper_path = config_dir / f"{profile_name}-credential-helper.sh"
        helper_content = _generate_bash_helper(api_url, token)
        helper_path.write_text(helper_content, encoding="utf-8")
        helper_path.chmod(0o700)
        credential_process = str(helper_path)

    subprocess.run(
        ["aws", "configure", "set", "credential_process", credential_process,
         "--profile", profile_name],
        capture_output=True,
    )
    subprocess.run(
        ["aws", "configure", "set", "region", region,
         "--profile", profile_name],
        capture_output=True,
    )
    return True


def _generate_bash_helper(api_url: str, token: str) -> str:
    """Generate a bash credential helper script."""
    return f"""#!/usr/bin/env bash
# Auto-generated by evercoast CLI
# Called automatically by AWS CLI to get fresh credentials.
RESPONSE=$(curl -s -X POST "{api_url}/s3-credentials/" \\
    -H "Authorization: Token {token}" \\
    -H "EC-Agent: CB" \\
    -H "Content-Type: application/json")

ERROR=$(echo "$RESPONSE" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('error',''))" 2>/dev/null)
if [ -n "$ERROR" ]; then
    echo "Error: $ERROR" >&2
    echo "Run 'evercoast login' to re-authenticate." >&2
    exit 1
fi

echo "$RESPONSE" | python3 -c "
import sys, json
d = json.load(sys.stdin)
print(json.dumps({{
    'Version': 1,
    'AccessKeyId': d['access_key_id'],
    'SecretAccessKey': d['secret_access_key'],
    'SessionToken': d['session_token'],
    'Expiration': d['expiration']
}}))
"
"""


def _generate_powershell_helper(api_url: str, token: str) -> str:
    """Generate a PowerShell credential helper script."""
    return f"""# Auto-generated by evercoast CLI
$ErrorActionPreference = "Stop"
try {{
    $Headers = @{{
        "Authorization" = "Token {token}"
        "EC-Agent" = "CB"
        "Content-Type" = "application/json"
    }}
    $Response = Invoke-RestMethod -Uri "{api_url}/s3-credentials/" `
        -Method Post `
        -ContentType "application/json" `
        -Headers $Headers `
        -ErrorAction Stop
    @{{
        Version = 1
        AccessKeyId = $Response.access_key_id
        SecretAccessKey = $Response.secret_access_key
        SessionToken = $Response.session_token
        Expiration = $Response.expiration
    }} | ConvertTo-Json
}}
catch {{
    Write-Error "Error refreshing credentials. Run 'evercoast login' to re-authenticate."
    exit 1
}}
"""
