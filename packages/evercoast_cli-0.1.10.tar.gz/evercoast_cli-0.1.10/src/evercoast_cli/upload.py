"""Upload logic for Evercoast CLI.

Handles file walking, sync comparison, S3 uploads with progress,
retry with network resilience, and data type routing.
"""

import fnmatch
import os
import socket
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from botocore.exceptions import ClientError, EndpointConnectionError
from requests.exceptions import ConnectionError as RequestsConnectionError
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)
from rich.table import Table

console = Console()


# Data type routing
TYPE_PREFIXES = {
    "takes": "takes/",
    "renders": "renders/",
    "calibrations": "calibrations/",
    "registrations": "registrations/",
    "other": "",
}

TYPE_LABELS = {
    "takes": "Raw take data (images, videos, 2D data)",
    "renders": "PLY or OBJ sequences",
    "calibrations": "Camera calibration data",
    "registrations": "Multicamera registration data",
    "other": "Other data",
}


def resolve_destination(
    data_type: str,
    source_path: str,
    upload_path: str,
    is_dir: bool,
    custom_dest: Optional[str] = None,
) -> str:
    """Resolve the S3 destination prefix for an upload.

    Args:
        data_type: One of 'takes', 'renders', 'other'
        source_path: Local path being uploaded
        upload_path: Base upload path (e.g. 'client-uploads/')
        is_dir: Whether source_path is a directory
        custom_dest: Custom --to override (if provided)

    Returns:
        Full S3 prefix string (e.g. 'client-uploads/takes/session-42/')
    """
    # Ensure upload_path ends with /
    if not upload_path.endswith("/"):
        upload_path += "/"

    # Custom --to override
    if custom_dest:
        dest = custom_dest.strip("/")
        return f"{upload_path}{dest}/"

    basename = os.path.basename(source_path.rstrip("/\\"))
    type_prefix = TYPE_PREFIXES.get(data_type, "")

    if is_dir:
        return f"{upload_path}{type_prefix}{basename}/"
    else:
        return f"{upload_path}{type_prefix}{basename}"


def walk_local_files(
    local_path: str,
    exclude_patterns: Optional[List[str]] = None,
) -> List[str]:
    """Walk a local directory and return all file paths.

    Args:
        local_path: Root directory to walk
        exclude_patterns: Glob patterns to exclude (matched against relative paths)

    Returns:
        Sorted list of absolute file paths
    """
    files = []
    local_path = os.path.abspath(local_path)

    for root, dirs, filenames in os.walk(local_path):
        for filename in sorted(filenames):
            filepath = os.path.join(root, filename)
            relative = os.path.relpath(filepath, local_path)

            if exclude_patterns:
                if any(fnmatch.fnmatch(relative, p) or fnmatch.fnmatch(filename, p)
                       for p in exclude_patterns):
                    continue

            files.append(filepath)

    return sorted(files)


def get_remote_files(s3_client, bucket: str, prefix: str) -> Dict[str, int]:
    """List all objects under an S3 prefix.

    Returns:
        Dict mapping relative key (without prefix) to file size
    """
    remote = {}
    paginator = s3_client.get_paginator("list_objects_v2")
    try:
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            for obj in page.get("Contents", []):
                rel_key = obj["Key"][len(prefix):]
                if rel_key:  # skip the prefix itself
                    remote[rel_key] = obj["Size"]
    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code", "")
        if error_code == "AccessDenied":
            # ListBucket not allowed — fall back to uploading everything
            console.print(
                "[yellow]Warning: Cannot list remote files (permission denied). "
                "All files will be uploaded.[/]"
            )
            return {}
        raise

    return remote


def compute_upload_plan(
    local_path: str,
    remote_files: Dict[str, int],
    exclude_patterns: Optional[List[str]] = None,
) -> Tuple[List[Tuple[str, str, int]], int]:
    """Compare local files against remote and determine what needs uploading.

    Args:
        local_path: Local directory path
        remote_files: Dict of {relative_key: size} from S3
        exclude_patterns: Glob patterns to exclude

    Returns:
        Tuple of (to_upload, skipped_count) where to_upload is a list of
        (local_path, s3_relative_key, file_size) tuples
    """
    to_upload = []
    skipped = 0
    local_files = walk_local_files(local_path, exclude_patterns)

    for filepath in local_files:
        relative = os.path.relpath(filepath, local_path)
        # Normalize to forward slashes for S3 keys
        s3_relative = relative.replace(os.sep, "/")
        local_size = os.path.getsize(filepath)

        if s3_relative in remote_files and remote_files[s3_relative] == local_size:
            skipped += 1
            continue

        to_upload.append((filepath, s3_relative, local_size))

    return to_upload, skipped


def format_size(size_bytes: int) -> str:
    """Format bytes into human-readable string."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"


def print_upload_summary(
    source: str,
    destination: str,
    bucket: str,
    to_upload: List[Tuple[str, str, int]],
    skipped: int,
    use_checksum: bool,
    dry_run: bool = False,
):
    """Print a formatted upload summary table."""
    total_size = sum(size for _, _, size in to_upload)

    table = Table(
        title="Upload Summary" if not dry_run else "Upload Summary (DRY RUN)",
        show_header=False,
        padding=(0, 2),
    )
    table.add_column("Key", style="bold")
    table.add_column("Value")

    table.add_row("Source", source)
    table.add_row("Destination", f"s3://{bucket}/{destination}")
    table.add_row("New files", str(len(to_upload)))
    if skipped > 0:
        table.add_row("Skipped", f"{skipped} (already uploaded)")
    table.add_row("Total size", format_size(total_size))
    if use_checksum:
        table.add_row("Checksum", "SHA256")

    console.print()
    console.print(table)
    console.print()


def print_dry_run_details(
    to_upload: List[Tuple[str, str, int]],
    destination: str,
    skipped: int,
    max_files: int = 20,
):
    """Print detailed dry run output showing what would be uploaded."""
    console.print("[bold yellow]DRY RUN — no files will be uploaded[/]")
    console.print()

    shown = to_upload[:max_files]
    for filepath, s3_key, size in shown:
        console.print(f"  {os.path.basename(filepath)}  →  {destination}{s3_key}  ({format_size(size)})")

    remaining = len(to_upload) - max_files
    if remaining > 0:
        console.print(f"  ... ({remaining} more files)")

    console.print()
    if skipped > 0:
        console.print(f"Would skip {skipped} files (already uploaded)")
    console.print()


def check_network() -> bool:
    """Quick check if we have network connectivity."""
    try:
        socket.create_connection(("s3.amazonaws.com", 443), timeout=5)
        return True
    except (socket.timeout, socket.error, OSError):
        return False


def upload_files(
    s3_client,
    bucket: str,
    destination: str,
    to_upload: List[Tuple[str, str, int]],
    use_checksum: bool = True,
) -> bool:
    """Upload files to S3 with progress bars and retry logic.

    Retries indefinitely on network errors until the user cancels (Ctrl+C).

    Args:
        s3_client: boto3 S3 client with auto-refreshing credentials
        bucket: S3 bucket name
        destination: S3 key prefix
        to_upload: List of (local_path, s3_relative_key, file_size)
        use_checksum: Whether to enable SHA256 checksum validation

    Returns:
        True if all files uploaded successfully
    """
    total_bytes = sum(size for _, _, size in to_upload)
    total_files = len(to_upload)
    uploaded_count = 0

    extra_args = {}
    if use_checksum:
        extra_args["ChecksumAlgorithm"] = "SHA256"

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold blue]{task.description}"),
        BarColumn(),
        DownloadColumn(),
        TransferSpeedColumn(),
        TimeRemainingColumn(),
        console=console,
    ) as progress:
        overall_task = progress.add_task(
            f"Uploading (0/{total_files} files)", total=total_bytes
        )

        for filepath, s3_key, size in to_upload:
            full_s3_key = f"{destination}{s3_key}"
            filename = os.path.basename(filepath)
            file_task = progress.add_task(filename, total=size)

            _upload_single_file_with_retry(
                s3_client=s3_client,
                filepath=filepath,
                bucket=bucket,
                s3_key=full_s3_key,
                extra_args=extra_args,
                progress=progress,
                file_task=file_task,
                overall_task=overall_task,
            )

            uploaded_count += 1
            progress.update(
                overall_task,
                description=f"Uploading ({uploaded_count}/{total_files} files)",
            )
            progress.remove_task(file_task)

    console.print()
    console.print(
        f"[bold green]Upload complete![/] "
        f"{uploaded_count} files ({format_size(total_bytes)})"
    )
    console.print(f"  Destination: s3://{bucket}/{destination}")
    console.print()
    return True


def _upload_single_file_with_retry(
    s3_client,
    filepath: str,
    bucket: str,
    s3_key: str,
    extra_args: dict,
    progress: Progress,
    file_task,
    overall_task,
) -> None:
    """Upload a single file, retrying indefinitely on network errors.

    Retries with exponential backoff (5s → 15s → 45s → ... up to 5 min).
    Waits for network connectivity before each retry. Only stops when the
    user cancels with Ctrl+C.
    """
    attempt = 0
    delay = 5
    max_delay = 300

    while True:
        attempt += 1
        try:
            # Reset progress for this file on retry
            if attempt > 1:
                progress.reset(file_task)

            bytes_transferred = 0

            def callback(bytes_amount):
                nonlocal bytes_transferred
                bytes_transferred += bytes_amount
                progress.advance(file_task, bytes_amount)
                progress.advance(overall_task, bytes_amount)

            s3_client.upload_file(
                filepath,
                bucket,
                s3_key,
                Callback=callback,
                ExtraArgs=extra_args if extra_args else None,
            )
            return

        except (ClientError, EndpointConnectionError, RequestsConnectionError,
                ConnectionError, OSError):
            # Rewind the overall progress for the bytes we reported
            progress.advance(overall_task, -bytes_transferred)

            progress.console.print(
                f"\n[yellow]Connection lost — retrying "
                f"(attempt {attempt})[/]"
            )

            # Wait for network to come back
            while not check_network():
                progress.console.print(
                    "  [dim]No internet connection. Waiting...[/]"
                )
                time.sleep(5)

            progress.console.print(
                f"  [green]Connection restored.[/] Resuming in {delay}s..."
            )
            time.sleep(delay)
            delay = min(delay * 3, max_delay)
