"""Allow running as `python -m evercoast_cli`."""

from .main import cli

cli()
