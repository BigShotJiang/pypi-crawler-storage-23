"""Evercoast CLI — upload files to your company's S3 bucket."""

__version__ = "0.1.10"
