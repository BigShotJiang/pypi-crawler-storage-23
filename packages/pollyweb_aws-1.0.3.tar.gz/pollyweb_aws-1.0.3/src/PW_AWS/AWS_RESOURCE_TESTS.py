class AWS_RESOURCE_TESTS:

    @classmethod
    def TestAll(cls):
        pass