from __future__ import annotations

from pathlib import Path

import pytest
from PW_UTILS.UTILS import UTILS

from DEPLOYER_ARGS import DEPLOYER_ARGS
from DEPLOYER_EXEC import DEPLOYER_EXEC
from DEPLOYER_EXEC_DUMMY import DEPLOYER_EXEC_DUMMY
from DEPLOYER_PARSER import DEPLOYER_PARSER


def _fixtures_root() -> Path:
    return Path(__file__).resolve().parent / "deployer"


def _find_fixture(name: str) -> Path:
    matches = [
        path
        for path in _fixtures_root().rglob("*")
        if path.is_file() and (path.stem == name or path.stem.endswith(name))
    ]
    if not matches:
        raise AssertionError(f"Fixture not found: {name}")
    if len(matches) > 1:
        raise AssertionError(f"Fixture match is ambiguous for {name}: {matches}")
    return matches[0]


def test_pollyweb_deployer_parser_normalizes_dependencies() -> None:
    fixture = _find_fixture("TestParser")
    yaml = UTILS().FromYaml(fixture.read_text())
    tasks = DEPLOYER_PARSER().YamlToTasks(
        stack="PollyWebStack",
        yaml=yaml,
        path=str(fixture),
    )

    assert len(tasks) == 1
    task = tasks[0]
    assert task.RequireStackName() == "PollyWebStack"
    assert task.RequireAsset() == "MyResource"
    assert task.RequireType() == "Dummy"
    assert task.RequireDependencies() == ["PollyWebStack-MyDependency"]


def test_pollyweb_deployer_parser_rejects_dot_dependencies() -> None:
    yaml = {
        "Deploy": {
            "MyResource": {
                "Type": "Dummy",
                "Dependencies": ["SomeStack.MyDependency"],
            }
        }
    }

    with pytest.raises(Exception, match="cannot have dots"):
        DEPLOYER_PARSER().YamlToTasks(
            stack="PollyWebStack",
            yaml=yaml,
            path="inline.yaml",
        )


def test_pollyweb_deployer_verify_tasks_executes_dummy_handlers() -> None:
    yaml = {
        "Deploy": {
            "Step1": {"Type": "Dummy"},
            "Step2": {"Type": "Dummy", "Dependencies": ["Step1"]},
        }
    }

    tasks = DEPLOYER_PARSER().YamlToTasks(
        stack="PollyWebStack",
        yaml=yaml,
        path="inline.yaml",
    )

    DEPLOYER_EXEC_DUMMY.DummyExecutions = []
    DEPLOYER_EXEC.VerifyTasks(
        tasks=tasks,
        deployArgs=DEPLOYER_ARGS(
            Name="PollyWeb.Deployer.Sequence",
            Simulate=True,
            Parallel=False,
        ),
    )

    assert DEPLOYER_EXEC_DUMMY.DummyExecutions == [
        "PollyWebStack-Step1",
        "PollyWebStack-Step2",
    ]
