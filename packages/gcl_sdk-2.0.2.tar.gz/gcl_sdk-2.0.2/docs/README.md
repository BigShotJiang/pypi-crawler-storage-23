Welcome to the Genesis SDK documentation!

The Genesis SDK is a set of tools for developing Genesis elements. There are several topics in the SDK documentation that you can find here:

* [Events](events/events.md)
* [Universal Agent](universal_agent/universal_agent.md)
* [Universal Builder](universal_builder/universal_builder.md)
* [Audit](audit/audit.md)
