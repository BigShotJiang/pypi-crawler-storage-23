#!/bin/sh
exec pip3 install --config-settings editable_mode=strict --group dev --editable .
