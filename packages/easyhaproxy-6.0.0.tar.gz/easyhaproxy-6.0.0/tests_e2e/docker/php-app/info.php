<?php
/**
 * PHP Info Page
 *
 * This page displays comprehensive PHP configuration information
 * including FastCGI environment variables set by EasyHAProxy.
 */

phpinfo();
