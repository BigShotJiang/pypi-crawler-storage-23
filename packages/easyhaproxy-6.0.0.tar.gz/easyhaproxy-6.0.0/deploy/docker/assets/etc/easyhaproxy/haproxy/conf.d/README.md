# Custom HAProxy Configuration

Put `.cfg` files here to be included in the HAProxy configuration.

These files will be available at `/etc/easyhaproxy/haproxy/conf.d/` inside the container.