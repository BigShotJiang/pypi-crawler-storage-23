---
sidebar_position: 9
---

# DigitalOcean

DigitalOcean is a cloud infrastructure provider focused on simplifying web infrastructure for software developers.

EasyHAProxy is available on DigitalOcean Marketplace. 
You can install it with a few clicks directly from the DigitalOcean dashboard.

## Installing EasyHAProxy on DigitalOcean

Please refer the [EasyHAProxy page on DigitalOcean Marketplace](https://marketplace.digitalocean.com/apps/easyhaproxy-ingress-controller).

