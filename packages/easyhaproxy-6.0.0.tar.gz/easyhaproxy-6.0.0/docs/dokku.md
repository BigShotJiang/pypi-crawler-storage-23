---
sidebar_position: 8
---

# Dokku

Dokku is a Docker powered mini-Heroku in around 100 lines of Bash. It is the smallest PaaS implementation you've ever seen, weighing in at a little over 100 MB of memory usage and about 80 MB of disk space.

## Installing EasyHAProxy on Dokku

Please refer to the [official documentation](https://github.com/dokku/dokku/blob/master/docs/networking/proxies/haproxy.md).
