"""Builtin OCTAVE schema definitions."""
