===OCTAVE_LITERACY_PRIMER===
META:
  TYPE::PRIMER
  VERSION::"6.0.0"
  TOKENS::~200
  TIER::ULTRA

§1::ESSENCE
PURPOSE::"Write OCTAVE"
OCTAVE::"Semantic DSL for LLMs"
STRUCTURE::KEY::value,[list],indent_2

§2::MAP
KEY::value→assignment
[a,b,c]→list
KEY:[newline_indent]→block

§3::SYNTAX
::→assign
→→flow
⊕→synthesis
⇌→tension

§4::ONE_SHOT
IN::"flow from A to B"
OUT::A→B

§5::VALIDATE
MUST::[valid_OCTAVE,preserve_§_names_verbatim,no_spaces_around_::,"===END==="]
===END===
