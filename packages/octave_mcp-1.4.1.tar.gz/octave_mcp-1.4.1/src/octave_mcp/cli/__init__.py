"""Command-line interface for OCTAVE tools."""
