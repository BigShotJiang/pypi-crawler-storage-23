"""MCP server tools for OCTAVE processing."""
