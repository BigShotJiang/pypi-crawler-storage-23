"""Mock package for Porringer tests.

This package contains mock implementations and utilities for testing Porringer plugins and environments.
"""
