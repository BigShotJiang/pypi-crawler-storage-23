"""Pytest utilities for Porringer tests.

This package provides shared fixtures, test data, and base test classes for testing Porringer plugins and environments.
"""
