"""Console package for Porringer.

This package contains modules and utilities for the command-line interface,
including command definitions and configuration management.
"""
