"""Utility package for Porringer.

This package contains utility functions and classes used throughout the Porringer application,
including subprocess management, type handling, and exception definitions.
"""
