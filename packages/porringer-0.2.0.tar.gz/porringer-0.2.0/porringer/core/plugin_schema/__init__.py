"""Plugin schema package for Porringer.

This package contains the schema definitions and base classes for plugins,
including environment plugins and their parameters.
"""
