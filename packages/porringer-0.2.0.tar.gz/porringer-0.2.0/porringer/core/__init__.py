"""Core package for Porringer.

This package contains the core schemas and base classes used throughout the Porringer application,
including plugin definitions and shared data models.
"""
