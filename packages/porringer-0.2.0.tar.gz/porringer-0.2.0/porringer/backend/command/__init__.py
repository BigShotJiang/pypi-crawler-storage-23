"""Command package for Porringer backend.

This package contains command modules for backend operations,
including plugin management and self-update functionalities.
"""
