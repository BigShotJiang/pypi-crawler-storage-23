"""Backend package for Porringer.

This package contains modules and utilities for backend processing,
including configuration resolution, plugin management, and command execution.
"""
