"""Python Install Manager (pim) plugin package for Porringer.

This package contains the implementation of the Python Install Manager environment plugin,
providing functionalities for installing, uninstalling, upgrading, and listing Python runtimes
using the official Python Install Manager (pymanager/py) on Windows.

Note: This plugin requires Windows and depends on winget for installation of the
Python Install Manager itself.
"""
