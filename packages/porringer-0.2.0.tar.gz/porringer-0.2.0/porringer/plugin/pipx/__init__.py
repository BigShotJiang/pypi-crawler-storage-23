"""Pipx plugin package for Porringer.

This package contains the implementation of the Pipx environment plugin,
providing functionalities for installing, uninstalling, upgrading, and searching packages.
"""
