"""Plugin package for Porringer.

This package contains the plugin implementations for various environments.
"""
