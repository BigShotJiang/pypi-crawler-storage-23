"""Tests package for Porringer.

This package contains unit and integration tests for the Porringer application,
including tests for plugins, environments, and core functionalities.
"""
