"""Tests for Homebrew (brew) plugin."""
