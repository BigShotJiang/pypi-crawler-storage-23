"""Tests for APT plugin."""
