"""Unit tests for the Python Install Manager (pim) plugin in Porringer.

This package contains unit tests for the pim environment plugin,
ensuring its functionality and correctness.
"""
