"""Unit tests for the Pipx plugin in Porringer.

This package contains unit tests for the Pipx environment plugin,
ensuring its functionality and correctness.
"""
