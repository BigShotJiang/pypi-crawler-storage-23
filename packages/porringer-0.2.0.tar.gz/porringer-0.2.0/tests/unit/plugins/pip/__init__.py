"""Unit tests for the Pip plugin in Porringer.

This package contains unit tests for the Pip environment plugin,
ensuring its functionality and correctness.
"""
