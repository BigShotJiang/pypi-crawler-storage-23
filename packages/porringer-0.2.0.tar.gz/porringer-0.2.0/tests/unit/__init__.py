"""Unit tests package for Porringer.

This package contains unit tests for the Porringer application,
including tests for plugins, environments, and core functionalities.
"""
