"""Tests plugin schemas"""


class TestPluginSchema:
    """Test Environment"""
