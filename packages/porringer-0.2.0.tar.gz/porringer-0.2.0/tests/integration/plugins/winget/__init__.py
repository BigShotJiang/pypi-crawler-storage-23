"""Integration tests for the Winget plugin in Porringer.

This package contains integration tests for the Winget environment plugin,
ensuring its functionality and correctness.
"""
