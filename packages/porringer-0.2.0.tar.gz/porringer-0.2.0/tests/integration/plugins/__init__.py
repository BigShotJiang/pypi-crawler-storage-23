"""Integration tests for Porringer plugins.

This package contains integration tests for the various Porringer plugins,
ensuring their functionality and correctness.
"""
