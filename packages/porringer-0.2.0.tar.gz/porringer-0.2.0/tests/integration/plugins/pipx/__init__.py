"""Integration tests for the Pipx plugin in Porringer.

This package contains integration tests for the Pipx environment plugin,
ensuring its functionality and correctness.
"""
