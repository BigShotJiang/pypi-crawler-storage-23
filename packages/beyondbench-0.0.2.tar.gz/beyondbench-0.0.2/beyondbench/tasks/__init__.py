"""Task implementations for beyondbench package."""

from .easy import *
from .medium import *
from .hard import *