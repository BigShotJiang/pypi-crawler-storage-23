"""Command-line interface for beyondbench."""

from .main import main

__all__ = ["main"]