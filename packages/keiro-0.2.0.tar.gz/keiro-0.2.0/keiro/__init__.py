"""Keiro — EB1 multi-model ensemble inference.

Quick start::

    pip install keiro
    keiro setup                          # configure your API key
    from keiro import models
    print(models("eb1-preview", "What is ML?"))

Prompt-first facade::

    from keiro import models

    reply = models.response("eb1-preview", "Explain quantum computing.")
    print(reply.text)

    creative = models.instance("eb1-preview", temperature=0.8)
    print(creative("Write a limerick"))

The ``complete`` function sends a prompt to the hosted Keiro API and
returns the response text. EB1 runs multiple frontier models in
parallel and synthesizes the best response.

Full client::

    from keiro import Client

    client = Client()
    response = client.chat(
        messages=[{"role": "user", "content": "Explain quantum computing."}],
        model="eb1-preview",
    )

    # Batch concurrent calls
    results = client.batch(
        ["What is ML?", "What is AI?", "What is DL?"],
        model="eb1-preview",
    )

Models:

    - ``"eb1"`` (default) — 3-model ensemble with synthesis
    - ``"eb1-preview"`` — preview ensemble (GPT-5.2, Gemini, Claude)
    - ``"eb1-pro"`` — 4-model ensemble for harder tasks
    - ``"claude-opus-4-6"`` — direct passthrough (no ensemble)
    - ``"gpt-5.2"`` — direct passthrough

Configuration:

    Run ``keiro setup`` to store your API key at ``~/.keiro/credentials``,
    or set ``KEIRO_API_KEY`` and ``KEIRO_BASE_URL`` environment variables.
"""

__version__ = "0.2.0"

from keiro.client import BatchError, Client, KeirError, complete
from keiro.model_api import ModelBinding, ModelInvocation, ModelResult, ModelsAPI, Response

models = ModelsAPI()

__all__ = [
    "BatchError",
    "Client",
    "KeirError",
    "ModelBinding",
    "ModelInvocation",
    "ModelResult",
    "ModelsAPI",
    "Response",
    "complete",
    "models",
    "__version__",
]
