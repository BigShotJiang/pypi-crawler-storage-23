"""
Model representation of a User
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2019 - 2025 Concordia CERC group
Project Coder Peter Yefi peteryefi@gmail.com
Code Contributor: Koa Wells kekoa.wells@concordia.ca
"""
import datetime
import enum
from sqlalchemy import Integer, String, Sequence, DateTime, Enum
from sqlalchemy.orm import relationship, Mapped, mapped_column

from cerc_persistence.configuration import Models


class UserRoles(enum.Enum):
  """
  User roles enum
  """
  Admin = 'Admin'
  Hub_Reader = 'Hub_Reader'


class UserModel(Models):
  """
  UserModel(Models) class
  """
  __tablename__ = 'user'
  id: Mapped[int] = mapped_column(Integer, Sequence('user_id_seq'), primary_key=True)
  username: Mapped[str] = mapped_column(String, nullable=False)
  password: Mapped[str] = mapped_column(String, nullable=False)
  role: Mapped[UserRoles] = mapped_column(Enum(UserRoles), nullable=False, default=UserRoles.Hub_Reader)
  created: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.now)
  updated: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.now)

  user_permissions = relationship("UserPermissionModel", back_populates="user")

  def __init__(self, username, password, role):
    super().__init__()
    self.username = username
    self.password = password
    self.role = role
