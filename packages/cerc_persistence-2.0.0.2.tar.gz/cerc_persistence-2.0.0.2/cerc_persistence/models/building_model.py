"""
Model representation of a building
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2019 - 2025 Concordia CERC group
Project Coder Guille Gutierrez Guillermo.GutierrezMorote@concordia.ca
Code Contributor Koa Wells kekoa.wells@concordia.ca
"""

import datetime
import logging
import pyproj
from pyproj import Transformer
from sqlalchemy import Integer, String, Sequence, ForeignKey, DateTime
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.orm import relationship, Mapped, mapped_column
from geoalchemy2 import Geometry
from geoalchemy2.shape import from_shape
from shapely.geometry import Polygon
from hub.city_model_structure.building import Building as HubBuilding
from hub.version import __version__

from cerc_persistence.types.numpy_float_to_primitive_float import NumpyFloatToPrimitiveFloat
from cerc_persistence.configuration import Models


class BuildingModel(Models):
  """
  BuildingModel(Models) class
  """
  __tablename__ = 'building'
  id: Mapped[int] = mapped_column(Integer, Sequence('building_id_seq'), primary_key=True)
  city_id: Mapped[int] = mapped_column(Integer, ForeignKey('city.id'), nullable=False)
  partition_id: Mapped[str] = mapped_column(String, nullable=True)
  name: Mapped[str] = mapped_column(String, nullable=False)
  aliases: Mapped[dict] = mapped_column(JSON, nullable=True)
  year_of_construction: Mapped[int] = mapped_column(Integer, nullable=True)
  function: Mapped[str] = mapped_column(String, nullable=True)
  height: Mapped[float] = mapped_column(NumpyFloatToPrimitiveFloat, nullable=True)
  usage: Mapped[dict] = mapped_column(JSON, nullable=True)
  volume: Mapped[float] = mapped_column(NumpyFloatToPrimitiveFloat, nullable=False)
  area: Mapped[float] = mapped_column(NumpyFloatToPrimitiveFloat, nullable=False)
  total_heating_area: Mapped[float] = mapped_column(NumpyFloatToPrimitiveFloat, nullable=False)
  wall_area: Mapped[float] = mapped_column(NumpyFloatToPrimitiveFloat, nullable=False)
  windows_area: Mapped[float] = mapped_column(NumpyFloatToPrimitiveFloat, nullable=False)
  roof_area: Mapped[float] = mapped_column(NumpyFloatToPrimitiveFloat, nullable=False)
  total_pv_area: Mapped[float] = mapped_column(NumpyFloatToPrimitiveFloat, nullable=False)
  system_archetype_name: Mapped[str] = mapped_column(String, nullable=False)
  geometry: Mapped[Geometry] = mapped_column(Geometry(geometry_type='POLYGON', srid=4326), nullable=False)
  hub_release: Mapped[str] = mapped_column(String, nullable=False)
  created: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.now)
  updated: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.now)

  city = relationship("CityModel", back_populates="buildings")
  building_simulations = relationship("BuildingSimulationModel", back_populates="building")

  def __init__(self, city_id, hub_city_name: str, partition_id: str, building: HubBuilding):
    super().__init__()
    self.city_id = city_id
    self.hub_city_name = hub_city_name
    self.partition_id = partition_id
    self.name = building.name
    self.aliases = building.aliases
    self.year_of_construction = building.year_of_construction
    self.function = building.function
    self.height = building.max_height
    self.usage = building.usages
    self.volume = building.volume
    self.area = building.floor_area
    self.roof_area = sum(roof.solid_polygon.area for roof in building.roofs)
    self.total_pv_area = sum(roof.solid_polygon.area * roof.solar_collectors_area_reduction_factor for roof in building.roofs)
    self.system_archetype_name = building.energy_systems_archetype_name
    self.hub_release = __version__

    storeys = building.storeys_above_ground
    wall_area = 0
    window_ratio = 0
    try:
      if storeys is None:
        storeys = building.max_height / building.average_storey_height
      for internal_zone in building.internal_zones:
        for thermal_zone in internal_zone.thermal_zones_from_internal_zones:
          for thermal_boundary in thermal_zone.thermal_boundaries:
            window_ratio = thermal_boundary.window_ratio
            break
    except TypeError:
      storeys = 0
      logging.warning(
        'building %s has no storey height so heating area, storeys and window ratio cannot be calculated',
        self.name
      )
    self.total_heating_area = building.floor_area * storeys

    for wall in building.walls:
      wall_area += wall.solid_polygon.area
    self.wall_area = wall_area
    self.windows_area = wall_area * window_ratio

    building_geometry = []
    transformer = Transformer.from_crs('epsg:26911', pyproj.CRS('EPSG:4326'))
    if building.grounds and len(building.grounds) == 1:
      for coordinate in building.grounds[0].solid_polygon.coordinates:
        gps_coordinate = transformer.transform(coordinate[0], coordinate[1])
        building_geometry.append([gps_coordinate[1], gps_coordinate[0]])
    building_polygon = Polygon(building_geometry)
    self.geometry = from_shape(building_polygon, srid=4326)