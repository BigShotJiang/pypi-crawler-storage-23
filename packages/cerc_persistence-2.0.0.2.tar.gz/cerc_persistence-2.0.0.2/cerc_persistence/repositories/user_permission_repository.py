"""
UserPermission repository with database CRUD operations
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2019 - 2025 Concordia CERC group
Project Coder Koa Wells kekoa.wells@concordia.ca
"""
import logging
from pathlib import Path
from sqlalchemy import select, delete
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from cerc_persistence.repository import Repository
from cerc_persistence.models import UserPermissionModel


class UserPermissionRepository(Repository):
  """
  User(Repository) class
  """
  _instance = None

  def __init__(self, dotenv_path: Path, app_env: str):
    super().__init__(dotenv_path, app_env)

  def __new__(cls, dotenv_path, app_env):
    """
    Implemented for a singleton pattern
    """
    if cls._instance is None:
      cls._instance = super(UserPermissionRepository, cls).__new__(cls)
    return cls._instance

  def insert(self, user_id:int, city_id: int):
    """
    Inserts a new user permission into the user_permissions table. This gives the user access to the city with the
    corresponding city_id.
    :param user_id: id of the user
    :param city_id: id of the city
    :return: Identity id
    """
    try:
      user_permission = self.get_by_user_id_and_city_id(user_id, city_id)
      if user_permission is not None:
        raise SQLAlchemyError('Permission already exists')
    except TypeError:
      pass
    try:
      user_permission = UserPermissionModel(user_id, city_id)
      with Session(self.engine) as session:
        session.add(user_permission)
        session.flush()
        session.commit()
        session.refresh(user_permission)
      return user_permission.id
    except SQLAlchemyError as err:
      logging.error('An error occurred while creating user permission %s', err)
      raise SQLAlchemyError from err

  def delete(self, user_permission_id: int):
    """
    Deletes the user permission with the id user_permission_id
    :param user_permission_id: id of the user permission to delete
    :return: None
    """
    try:
      with Session(self.engine) as session:
        statement = delete(UserPermissionModel).where(UserPermissionModel.user_id == user_permission_id)
        session.execute(statement)
        session.commit()
    except SQLAlchemyError as err:
      logging.error('Error while deleting user permission: %s', err)
      raise SQLAlchemyError from err

  def get_by_user_permission_id(self, user_permission_id: int):
    """
    Load user permission by user_permission_id
    :param user_permission_id: id of the user permission to fetch
    :return: UserPermission or None
    """
    try:
      with Session(self.engine) as session:
        query = select(UserPermissionModel).where(UserPermissionModel.id == user_permission_id)
        city_partition = session.execute(query).scalar_one_or_none()
        return city_partition
    except SQLAlchemyError as err:
      logging.error('Error while fetching user permission: %s', err)
      raise SQLAlchemyError from err
    except ValueError as err:
      raise ValueError from err

  def get_by_user_id_and_city_id(self, user_id: int, city_id: int):
    """
    Load specific user permission from the user_permissions table
    :param user_id: id of the user
    :param city_id: id of the city
    :return: UserPermission or None
    """
    try:
      with Session(self.engine) as session:
        query = select(UserPermissionModel).where(UserPermissionModel.user_id == user_id,
                                            UserPermissionModel.city_id == city_id)
        user_permission = session.execute(query).scalar_one_or_none()
        return user_permission
    except SQLAlchemyError as err:
      logging.error('Error while fetching user permission: %s', err)
      raise SQLAlchemyError from err
    except ValueError as err:
      raise ValueError from err

  def get_multiple_by_user_id(self, user_id: int):
    """
    Load all user permissions by user_id
    :param user_id: id of the user
    :return: [UserPermission] or None
    """
    try:
      with Session(self.engine) as session:
        query = select(UserPermissionModel).where(UserPermissionModel.user_id == user_id)
        user_permissions = session.execute(query).scalars().all()
        if not user_permissions:
          return None
        return user_permissions
    except SQLAlchemyError as err:
      logging.error('Error while fetching user permissions: %s', err)
      raise SQLAlchemyError from err
    except ValueError as err:
      raise ValueError from err
