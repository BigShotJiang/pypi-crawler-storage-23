"""
CERC Persistence version number
"""
__version__ = '2.0.0.2'
