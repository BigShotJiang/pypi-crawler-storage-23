# CERC Persistence
The persistence package includes SQLAlchemy models, CRUD functions (repositories), and a database controller for using
the repositories within the CityAnalyzer and the CityLayers API.

## Models
CERC Persistence uses models to define all class objects that we want to persist. It is used for Object Relation Mapping (ORM)
of the class objects to database table columns.

### City
The city is the highest level table in the database. The city has buildings and users that can access it.

| **Column**  | **Description**                                                               |
|-------------|-------------------------------------------------------------------------------|
| id          | autoincremented id of city created upon insertion (primary key)               |
| name        | name of the city                                                              |
| location    | latitude, longitude coordinate of the center of the city stored in WKT format |
| description | description of the city                                                       |
| created     | timestamp of when the city was inserted in the database                       |
| updated     | timestamp of when the city was last updated in the database                   |

### Building
The building contains relevant information about the buildings physical characteristics, age, function, usage, and energy system.
The building may have one or more building simulations associated with it.

| **Column**            | **Description**                                                                                    |
|-----------------------|----------------------------------------------------------------------------------------------------|
| id                    | autoincremented id of building created upon insertion                                              |
| city_id               | id of the city that owns the building                                                              |
| partition_id          | id of the partition to which the building belongs when the city is partitioned by the CityAnalyzer |
| name                  | name of the building from the cerc-hub, usually an id associated with the building                 |
| aliases               | nicknames for the building as input into the cerc-hub                                              |
| year_of_construction  | year that the building was constructed                                                             |
| function              | function of the building                                                                           |
| usage                 | usage of the buildings                                                                             |
| volume                | volume of the building in m^3 calculated by the cerc-hub                                           |
| area                  | area of the building footprint in m^2 calculated by the cerc-hub                                   |
| total_heating_area    | total floor area of the building in m^2 calculated by the cerc-hub                                 |
| wall_area             | total area of all of the walls in m^2 calculated by the cerc-hub                                   |
| windows_area          | total area of all the windows in m^2 calculated by the cerc-hub                                    |
| roof_area             | total area of the roof in m^2 calculated by the cerc-hub                                           |
| total_pv_area         | area that the roof that can support solar panels in m^2 calculated by the cerc-hub                 |
| system_archetype_name | name of the energy system archetype associated with the building                                   |
| hub_release           | version of the cerc-hub used to create the building                                                |
| created               | timestamp of when the building was inserted in the database                                        |
| updated               | timestamp of when the building was last updated in the database                                    |

### Building Simulation
The building simulation stores energy simulations, co2 emission simulations, and lifecycle cost simulations associated with a building
when a specific retrofit scenario is applied to it.

| **Column**            | **Description**                                                                                    |
|-----------------------|----------------------------------------------------------------------------------------------------|
| id                    | autoincremented id of building created upon insertion                                              |
| city_id               | id of the city that owns the building                                                              |
| partition_id          | id of the partition to which the building belongs when the city is partitioned by the CityAnalyzer |
| name                  | description of the city                                                                            |
| aliases               | timestamp of when the city was inserted in the data                                                |
| year_of_construction  | timestamp of when the city was updated in the database                                             |
| function              | function of the building                                                                           |
| usage                 | usage of the buildings                                                                             |
| volume                | volume of the building in m^3 calculated by the cerc-hub                                           |
| area                  | area of the building footprint in m^2 calculated by the cerc-hub                                   |
| total_heating_area    | total floor area of the building in m^2 calculated by the cerc-hub                                 |
| wall_area             | total area of all of the walls in m^2 calculated by the cerc-hub                                   |
| windows_area          | total area of all the windows in m^2 calculated by the cerc-hub                                    |
| roof_area             | total area of the roof in m^2 calculated by the cerc-hub                                           |
| total_pv_area         | area that the roof that can support solar panels in m^2 calculated by the cerc-hub                 |
| system_archetype_name | name of the energy system archetype associated with the building                                   |
| hub_release           | version of the cerc-hub used to create the building                                                |
| created               | timestamp of when the building was inserted in the database                                        |
| updated               | timestamp of when the building was last updated in the database                                    |


### User
The user contains the username, password, and role associated with a user.

| **Column** | **Description**                                             |
|------------|-------------------------------------------------------------|
| id         | autoincremented id of user created upon insertion           |
| username   | username of the user                                        |
| password   | password of the user stored as a bcrypt hash                |
| role       | role of the user (admin or reader)                          |
| created    | timestamp of when the user was inserted in the database     |
| updated    | timestamp of when the user was last updated in the database |

### User Permission
The user permissions are used to dictate which cities a user can access.

| **Column** | **Description**                                             |
|------------|-------------------------------------------------------------|
| id         | autoincremented id of user created upon insertion           |
| username   | username of the user                                        |
| password   | password of the user stored as a bcrypt hash                |
| role       | role of the user (admin or reader)                          |
| created    | timestamp of when the user was inserted in the database     |
| updated    | timestamp of when the user was last updated in the database |

## Repositories

The repository classes contain CRUD methods for database operations. The constructor of all repositories requires
the .env path and the application environment (TEST or PROD).

## Base

This class has a constructor that establishes a database connection and returns a reference for database-related CRUD
operations.

## Database Configuration Parameter

For the CERC Persistence to connect to the database, a .env file is required. A .env.example is provided:

```
# production database credentials
PROD_DB_USER=
PROD_DB_PASSWORD=
PROD_DB_HOST=
PROD_DB_PORT=
PROD_DB_NAME=

# test database credentials
TEST_DB_USER=
TEST_DB_PASSWORD=
TEST_DB_HOST=
TEST_DB_PORT=
TEST_DB_NAME=
```

The CERC Persistence package looks for the .env file inside ~/.local/etc/cerc_persistence/ .

**NOTE:**  
Be very careful when filling out the PROD/TEST environment variables. It is recommended not to use a production database
with the PROD variables unless you are working with the production database or inside a production environment. For local
development, you should use a test database with the TEST environment variables. Always double check your .env. If you
run the unit tests with the production values filled out, you will **delete production database**.

## Database Related Unit Test

Unit tests that involve database operations require a Postgres database to be set up.
The tests connect to the database server using the default postgres user (*postgres*).
NB: You can provide any credentials for the test to connect to postgres, just make sure
the credentials are set in your .env file as explained above in *Database Configuration Parameters* section.

When the tests are run, a **test_db** database is created and then the required tables for
the test. Before the tests run, the *test_db* is deleted to ensure that each test starts
on a clean slate.

## Usage Instructions

1. [Install PostgreSQL (tested with PostgreSQL 16)](https://www.postgresql.org/download/)
2. Using the commandline (cmd or Terminal), connect to the postgres database using the postgres user created during installation  
` psql -U postgres -h localhost -d postgres`
3. Create a database  
` CREATE DATABASE persistence_test_db;`
4. Connect to the database  
` \connect persistence_test_db`
5. Create a new user - this user will own the database you just created  
` CREATE USER persistence_test WITH PASSWORD 'password123';`
6. Make the new user the owner of the new database
` ALTER DATABASE persistence_test_db OWNER TO persistence_test;`
7. Install Postgis extension
` CREATE EXTENSION postgis;`
8. Fill out the .env with the information for the database you just created under the TEST credentials.
```
# test database credentials
TEST_DB_USER=persistence_test
TEST_DB_PASSWORD=pasword123
TEST_DB_HOST=localhost
TEST_DB_PORT=5432
```
9. Move the .env file to ~/.local/etc/cerc_persistence/
10. Create a virtual environment for cerc_persistence (tested with Python 3.12)
11. Install the required packages  
` pip install -r requirements.txt`
12. Inside the root of the repository, run pytest to ensure everything is working correctly
` pytest`

