"""Allow running anji as a module: python -m anji"""

from anji.cli import main

if __name__ == "__main__":
    main()
