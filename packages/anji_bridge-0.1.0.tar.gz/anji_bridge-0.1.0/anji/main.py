"""Entry point for the anji CLI."""

from anji.cli import main

if __name__ == "__main__":
    main()
