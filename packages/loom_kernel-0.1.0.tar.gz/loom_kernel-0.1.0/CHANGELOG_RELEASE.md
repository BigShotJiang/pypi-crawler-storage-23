# 🚀 Release 0.1.0 ([#8](https://github.com/the-reacher-data/loom-py/pull/8)) ([`80c78b1`](https://github.com/the-reacher-data/loom-py/commit/80c78b1d966c398f05896d6546261811ce7a2b02))


## ✨ Features
### core
- **core:** add repository abstractions and SQLAlchemy base

### job
- **job:** introduce async job domain model and orchestration primitives<br>
  > Added `Job[ResultT]` base class with execution/routing ClassVars.
  > Added `JobHandle` / `JobGroup` with dual-mode waiting (Celery + inline).
  > Added typed job errors (`JobTimeoutError`, `JobFailedError`).
  > Added `JobCallback`, `Compilable`, context queue, `JobService`,
  > `InlineJobService`.
  > Wired dispatch flush/clear into executor UoW lifecycle.
  > Exposed stable `loom.core.job` public API.


### celery
- **celery:** add production-ready Celery integration layer<br>
  > Added `CeleryConfig`, `JobConfig`, `create_celery_app`.
  > Added `CeleryJobService` and persistent worker event loop.
  > Emitted `JOB_DISPATCHED` from FastAPI process.
  > Exposed bootstrap/service API.
  > Hardened shutdown, timeout handling, eager fallback, and trace propagation.


### rest
- **rest:** deliver first-class auto-CRUD and OpenAPI improvements<br>
  > Implemented auto-CRUD as a RestInterface feature.
  > Improved OpenAPI contracts, query params, and pagination defaults.
  > Extracted `$defs` into `components.schemas`.
  > Decoupled write DTOs via `CreateInput` / `UpdateInput`.
  > Fixed runtime dependency/input resolution and 404 behavior on missing
  > resources.


### cache
- **cache:** improve cache invalidation and backend flexibility<br>
  > Separated counter backend concerns.
  > Added native increment strategy and `max_size` config.


### projection
- **projection:** make projection runtime backend-agnostic<br>
  > Added projection source model for backend/preloaded execution.
  > Refactored runtime/compile flow for clearer backend-memory resolution.



## 🐛 Fixes
### core
- **core:** correctness and consistency hardening<br>
  > Preserved PATCH camelCase semantics in repository layer.
  > Kept ORM snake_case serialization compatibility.
  > Resolved Load/Exists repository resolution via model container.
  > Fixed `updated_at` onupdate/server_onupdate behavior.
  > Avoided UNSET default leakage in SQLAlchemy/REST paths.






## ⚡ Performance
### core
- **core:** improve hot-path efficiency<br>
  > Removed per-request reflection in repository/executor.
  > Reduced metrics cardinality and parallelized cache fingerprint resolution.





