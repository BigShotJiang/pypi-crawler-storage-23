"""locstat: Count lines of code"""

__version__ = "1.2.0"
__author__ = "Parth Acharya"
__tool_name__ = "locstat"
