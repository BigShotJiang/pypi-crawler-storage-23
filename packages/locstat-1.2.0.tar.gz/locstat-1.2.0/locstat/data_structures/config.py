import io
import json
import tomllib
from dataclasses import dataclass, field
from importlib.metadata import metadata
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping, Optional
from urllib import error, request
from uuid import uuid4

from locstat.data_structures.exceptions import InvalidConfigurationException
from locstat.data_structures.singleton import SingletonMeta
from locstat.data_structures.typing import LanguageMetadata
from locstat.data_structures.verbosity import Verbosity
from locstat.data_structures.parse_modes import ParseMode

__all__ = ("ClocConfig",)


@dataclass(init=False, slots=True, weakref_slot=True)
class ClocConfig(metaclass=SingletonMeta):
    working_directory: Path

    # CLI Options
    verbosity: Verbosity = Verbosity.BARE
    minimum_characters: int = 0
    max_depth: int = -1
    parsing_mode: ParseMode = ParseMode.BUFFERED
    archive_filename: str = field(default="settings.archive.toml")

    # Language metadata
    symbol_mapping: MappingProxyType[str, LanguageMetadata]
    config_file: str
    language_metadata_path: str = ""

    additional_kwargs: dict[str, Any] = field(default_factory=dict)

    @property
    def configurable(self) -> frozenset[str]:
        return frozenset(
            [
                "verbosity",
                "minimum_characters",
                "max_depth",
                "parsing_mode",
                "language_metadata_path",
            ]
        )

    @staticmethod
    def flatten_mapping(mapping: Mapping[Any, Any]) -> dict[Any, Any]:
        flattened: dict[Any, Any] = {}
        leftover: list[Mapping[Any, Any]] = [mapping]
        while leftover:
            popped_map: Mapping[Any, Any] = leftover.pop(0)
            for k, v in popped_map.items():
                if isinstance(v, Mapping):
                    leftover.append(popped_map[k])
                    continue
                flattened[k] = v
        return flattened

    @classmethod
    def load_toml(cls, config_file: Path) -> "ClocConfig":
        with open(config_file, "r", encoding="utf-8") as configurations:
            config_dict: dict[str, Any] = cls.flatten_mapping(
                tomllib.loads(configurations.read())
            )
        instance: ClocConfig = cls()

        object.__setattr__(instance, "config_file", config_file)
        object.__setattr__(instance, "archive_filename", "config.archive.toml")

        additional_kwargs: dict[str, Any] = {}
        for tag, attr in config_dict.items():
            if tag not in instance.__slots__:
                additional_kwargs[tag] = attr
                continue
            if not isinstance(attr, cls.__annotations__[tag]):
                try:
                    if issubclass(cls.__annotations__[tag], (ParseMode, Verbosity)):
                        attr = attr.upper()
                    attr = cls.__annotations__[tag](attr)
                except (ValueError, TypeError):
                    raise InvalidConfigurationException(
                        message=" ".join(
                            (
                                f"Invalid type {type(attr)} for configuration attribute {tag},",
                                f"expected {cls.__annotations__[tag]}",
                            )
                        )
                    )
            object.__setattr__(instance, tag, attr)

        object.__setattr__(instance, "additional_kwargs", additional_kwargs)

        working_directory: Path = Path(__file__).parent.parent
        object.__setattr__(instance, "working_directory", working_directory)

        # Load data about comment symbols
        languages_filepath: Path = (
            Path(instance.language_metadata_path)
            if instance.language_metadata_path
            else working_directory / "languages.json"
        )
        with open(languages_filepath, "rb") as langauges_source:
            languages_data = json.loads(langauges_source.read())

        comments_data: dict[str, list[str]] = languages_data.pop("comments")
        symbol_mapping: dict[str, LanguageMetadata] = {}
        for language, comment_data in comments_data.items():
            if len(comment_data) != 3:
                raise InvalidConfigurationException(
                    " ".join(
                        (
                            f"Comment data for file extension {language} malformed",
                            "Should be of format:",
                            "(singleline, multiline-start, multiline-end)",
                            f"got {comment_data} instead",
                        )
                    )
                )
            singleline, multistart, multiend = comment_data
            symbol_mapping[language] = (
                singleline.encode() if singleline else None,
                multistart.encode() if multistart else None,
                multiend.encode() if multiend else None,
            )
        object.__setattr__(instance, "symbol_mapping", symbol_mapping)
        return instance

    @property
    def configurations(self) -> dict[str, Any]:
        return {
            config_key: getattr(self, config_key)
            for config_key in sorted(self.configurable)
        }

    @property
    def configurations_string(self) -> str:
        return "\n".join(f"{k} : {v}" for k, v in self.configurations.items())

    @staticmethod
    def _cast_toml_dtype(value: str | int) -> str | int:
        if isinstance(value, bool):
            return str(value).lower()
        return value

    @staticmethod
    def config_default_toml_dumps(d: dict[str, Any]) -> str:
        lines: list[str] = ["[defaults]"]
        for k, v in d.items():
            casted: str | int = ClocConfig._cast_toml_dtype(v)
            if isinstance(casted, str):
                casted = f'"{casted}"'
            lines.append("=".join((k, str(casted))))
        return "\n".join(lines)

    def update_configuration(self, configuration: str, value: Any) -> None:
        if configuration not in self.configurable:
            raise ValueError(f"Item {configuration} not supported")

        datatype: type[Any] = ClocConfig.__annotations__[configuration]
        if not isinstance(value, datatype):
            try:
                # What an awful hack
                if issubclass(datatype, (ParseMode, Verbosity)):
                    value = value.upper()
                value = datatype(value)
            except (ValueError, TypeError):
                raise InvalidConfigurationException(
                    " ".join(
                        (
                            f"Value {value} unsupported",
                            f"for configuration {configuration}," "expected type:",
                            str(datatype).split("'")[1],
                        )
                    )
                )

        # Persist original configurations to archive file
        archive_filepath: Path = Path(self.config_file).parent / self.archive_filename
        if not archive_filepath.is_file():
            archive_filepath.write_text(
                data=ClocConfig.config_default_toml_dumps(self.configurations),
                encoding="utf-8",
            )

        setattr(self, configuration, value)
        with open(self.config_file, "w") as config_file:
            config_file.write(ClocConfig.config_default_toml_dumps(self.configurations))

    def restore_configuration(self) -> None:
        config_filepath: Path = Path(self.config_file)
        archive_filepath: Path = config_filepath.parent / self.archive_filename
        if archive_filepath.is_file():
            try:
                archived_config: ClocConfig = ClocConfig.load_toml(archive_filepath)
            except tomllib.TOMLDecodeError:
                print("[ERROR] Archive file does not contain valid TOML")
                raise

            config_filepath.write_text(
                data=ClocConfig.config_default_toml_dumps(
                    archived_config.configurations
                ),
                encoding="utf-8",
            )
            print(f"[INFO] Restored file {config_filepath}")
            return

        # No local archive, attempt to fetch using git repository
        print(
            ", ".join(
                (
                    f"[INFO] No local archive file found (looked for {archive_filepath})",
                    "Attempting to reconcile using package's source repository",
                )
            )
        )

        assert __package__
        package_metadata = metadata(__package__.split(".")[0])
        repository_url_metadata: str = package_metadata["Project-URL"]

        if not repository_url_metadata:
            print(
                ", ".join(
                    (
                        "[ERROR] Failed to reconcile with source repository",
                        "this may be a broken/corrupted installation",
                    )
                )
            )
            return

        repository_url: str = repository_url_metadata.split(",")[1].strip()
        git_ref: Optional[str] = package_metadata["version"]
        if not git_ref:
            print(
                ", ".join(
                    (
                        "[ERROR] Broken installation: No version metadata found for this package!",
                        "will reconcile using latest version.",
                    )
                )
            )
            print(
                f"[INFO] Please reinstall {package_metadata['name']} from PyPi to avoid such errors"
            )

            git_ref = "main"
        else:
            git_ref = "v" + git_ref

        git_ref = "main"
        repository_url = "/".join(
            (
                repository_url.replace("github", "raw.githubusercontent"),
                f"{git_ref}/locstat/config.toml",
            )
        )
        try:
            response: Any = request.urlopen(repository_url)
            file_reader: Any = getattr(response, "fp", None)
            if not (file_reader and isinstance(file_reader, io.BufferedReader)):
                print(
                    ", ".join(
                        (
                            "[ERROR] Failed to reconcile with source repository",
                            "missing file",
                        )
                    )
                )
                return
        except error.HTTPError as e:
            print(e)
            print(
                ", ".join(
                    (
                        "[ERROR] Failed to reconcile with source repository",
                        "Network error",
                    )
                )
            )
            return

        contents: str = file_reader.read().decode("utf-8")

        if git_ref == "main":
            # Addtional parsing is required to trim any addiitonal configurations
            # or handle any incompatible values from the latest stable version
            temp_filepath: Path = config_filepath.parent / f"temp_{uuid4().hex}.toml"
            temp_filepath.write_text(contents, encoding="utf-8")
            try:
                config: ClocConfig = ClocConfig.load_toml(temp_filepath)
            except InvalidConfigurationException:
                print(
                    ", ".join(
                        (
                            "[ERROR] Failed to reconcile with the latest stable version",
                            f"at: {repository_url}",
                        )
                    )
                )
                return
            finally:
                temp_filepath.unlink()

            if config.additional_kwargs:
                message_string: str = ", ".join(
                    (f"{k}:{v}" for k, v in config.additional_kwargs.items())
                )
                print(
                    ", ".join(
                        (
                            "[INFO] Additional configuration paramaters found",
                            f"paramaters: {message_string}",
                            "ignored",
                        )
                    )
                )

            contents = ClocConfig.config_default_toml_dumps(config.configurations)

        archive_filepath.write_text(data=contents, encoding="utf-8")
        config_filepath.write_text(data=contents, encoding="utf-8")

        print(
            ", ".join(
                (
                    f"[INFO] Restored file {config_filepath}",
                    f"created archive {archive_filepath}",
                    "through repository reconciliation",
                )
            )
        )

    def update_languages_metadata(self, metadata: dict[str, LanguageMetadata]) -> None:
        object.__setattr__(
            self,
            "symbol_mapping",
            MappingProxyType(dict(self.symbol_mapping) | metadata),
        )

    def write_language_metadata(self, filepath: Path) -> None:
        with open(self.working_directory / "languages.json", "r") as src:
            filepath.write_text(src.read())
