"""
SimGen - TRUE ZERO Exact Simulation Engine
===========================================

Run ODE simulations with mathematically exact arithmetic.
Zero accumulation error. Perfectly reproducible.

Usage:
    from simgen import simulate

    # Run a simulation (all arithmetic exact internally)
    result = simulate(
        system="lorenz",
        initial=[1.0, 1.0, 1.0],
        params={"sigma": 10, "rho": 28, "beta_num": 8, "beta_denom": 3},
        dt=0.01,
        steps=10000
    )

    # Access results
    print(result.final)        # Final state [x, y, z]
    print(result.trajectory)   # Full trajectory array

Available systems:
    - lorenz: Lorenz attractor (chaotic)
    - rossler: Rossler attractor
    - vanderpol: Van der Pol oscillator
    - harmonic: Simple harmonic oscillator

Advanced usage (direct VLA access):
    from simgen import vla

    # Create exact tensors
    a = vla.from_fraction(1, 3, shape=(100,))  # Exact 1/3
    b = vla.tensor(torch_tensor)               # From float tensor

    # Exact operations
    c = vla.matmul(a, b)
    d = vla.sum(c)

    # Get result
    num, denom = d.to_rational()  # Exact fraction
    value = d.to_float()          # Float approximation

Website: https://simgen.dev
License: Proprietary - All rights reserved
"""

__version__ = "4.1.0"
__author__ = "Clouthier Simulation Labs"

# High-level simulation API
from .simulate import simulate, SimResult, list_systems, system_info

# Low-level VLA access for advanced users
from . import vla

__all__ = [
    # Main API
    "simulate",
    "SimResult",
    "list_systems",
    "system_info",
    # Advanced
    "vla",
    "__version__",
]
