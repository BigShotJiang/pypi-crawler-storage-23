import json
from typing import Any, Dict

# 新しいSDKのインポート
from google import genai

from .prompts import build_prompt

_CFG: Dict[str, Any] = {
    "activated": False,
    "llm": None,
    "model": None,
    "client": None,  # クライアントオブジェクトを保持するキーを追加
}

def activate(llm: str = "gemini", api_key: str | None = None, model: str = "gemini-3-flash-preview", **kwargs) -> None:
    """
    hatsu を初期化し、指定されたLLMのクライアントをセットアップします。
    """
    if not api_key:
        raise ValueError("API key must be provided.")

    if llm == "gemini":
        # 新しいSDKのクライアント初期化
        _CFG["client"] = genai.Client(api_key=api_key)
    else:
        raise NotImplementedError(f"LLM '{llm}' is not supported yet.")

    _CFG["llm"] = llm
    _CFG["model"] = model
    _CFG["activated"] = True


def suggest(
    text: str,
    estimate_data: dict,
    mode: str,
    allow_amplification: bool = False,
    acknowledge_adversarial_risk: bool = False,
    **kwargs
) -> dict:
    """
    外部から受け取った感情推定データに基づき、指定されたモードでテキストを生成します。
    """
    if not _CFG.get("activated"):
        raise RuntimeError("hatsu is not activated. Call hatsu.activate(...) first.")

    # --- Safety Guard (Safety Flag) Validation ---
    if mode == "plus":
        if not allow_amplification:
            raise PermissionError(
                "[hatsu Safety Guard]\n"
                "The 'plus' mode intentionally amplifies the user's emotions, which entails risks.\n"
                "To execute, you must explicitly specify 'allow_amplification=True' in the arguments."
            )
    elif mode == "minus":
        if not acknowledge_adversarial_risk:
            raise PermissionError(
                "[hatsu CRITICAL WARNING]\n"
                "The 'minus' mode causes the AI to directly and logically oppose or deny the user's emotions and inputs.\n"
                "Because this may cause severe psychological distress, strong consent is required for execution.\n"
                "To execute, you must explicitly specify 'acknowledge_adversarial_risk=True' in the arguments."
            )
    else:
        raise ValueError(f"Unknown mode: '{mode}'. Expected 'plus' or 'minus'.")

    # --- LLMによるテキスト生成 ---
    prompt = build_prompt(text=text, estimate_data=estimate_data, mode=mode)

    generated_text = ""
    
    if _CFG["llm"] == "gemini":
        client = _CFG["client"]
        # 新しいSDKでのコンテンツ生成メソッド
        response = client.models.generate_content(
            model=_CFG["model"],
            contents=prompt
        )
        generated_text = response.text

    return {
        "original_text": text,
        "mode": mode,
        "suggestion": generated_text.strip()
    }