import json

def build_prompt(text: str, estimate_data: dict, mode: str) -> str:
    """
    入力テキストと感情推定データから、LLMに渡すプロンプトを構築します。
    """
    # LLMが構造を理解しやすいよう、辞書データをインデント付きのJSON文字列に変換
    estimate_str = json.dumps(estimate_data, ensure_ascii=False, indent=2)

    if mode == "plus":
        instruction = (
            "Based on the provided text and the estimated emotions, "
            "generate a comment that reinforces and amplifies the estimated emotions. "
            "The output MUST be in the same language as the input text."
        )
    elif mode == "minus":
        instruction = (
            "Based on the provided text and the estimated emotions, "
            "generate a comment that contradicts, opposes, or denies the estimated emotions. "
            "The output MUST be in the same language as the input text."
        )
    else:
        # core.py側で弾いていますが、念のためのフェイルセーフ
        raise ValueError(f"Unknown mode: '{mode}'")

    # プロンプトの組み立て（見出しも英語で統一）
    prompt = f"""[Text]
{text}

[Estimated Emotions]
{estimate_str}

[Instruction]
{instruction}"""

    return prompt