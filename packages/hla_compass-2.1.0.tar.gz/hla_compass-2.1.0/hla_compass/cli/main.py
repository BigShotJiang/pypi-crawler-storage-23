import logging

import click

# from .. import __version__
from .._version import __version__
from .auth import auth
from .dev import dev, run, serve, test
from .doctor import doctor
from .keys import keys
from .mcp import mcp
from .module import build, init, publish, publish_status, validate
from .utils import _enable_verbose


@click.group()
@click.version_option(version=__version__)
@click.option("--verbose", is_flag=True, help="Enable verbose logging")
@click.pass_context
def cli(ctx, verbose):
    """HLA-Compass SDK"""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    if verbose:
        _enable_verbose(ctx)
    else:
        logging.getLogger().setLevel(logging.INFO)


# Register Auth commands
cli.add_command(auth)

# Register Module commands
cli.add_command(init)
cli.add_command(build)
cli.add_command(publish)
cli.add_command(publish_status)
cli.add_command(validate)

# Register Dev commands
cli.add_command(dev)
cli.add_command(serve)
cli.add_command(test)
cli.add_command(run)

# Register keys
cli.add_command(keys)

# Register diagnostics
cli.add_command(doctor)

# Register MCP integration
cli.add_command(mcp)


def main():
    cli()


if __name__ == "__main__":
    main()
