# SDK Templates Overview (Canonical Location)

> The canonical SDK templates overview now lives in `internal-docs/components/sdk/templates/templates-overview.md`.

- [SDK Templates Overview](../../../../internal-docs/components/sdk/templates/templates-overview.md)
