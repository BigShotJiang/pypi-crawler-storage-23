# UI Template Frontend (Canonical Location)

> The canonical UI template frontend guide now lives in `internal-docs/components/sdk/templates/ui-template-frontend.md`.

- [UI Template Frontend](../../../../../../internal-docs/components/sdk/templates/ui-template-frontend.md)
