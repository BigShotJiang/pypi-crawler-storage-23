# SDK Template Styling (Canonical Location)

> The canonical styling notes now live in `internal-docs/components/sdk/templates/styling-changes.md`.

- [SDK Template Styling](../../../../internal-docs/components/sdk/templates/styling-changes.md)
