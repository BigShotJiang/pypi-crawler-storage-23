"""MCP-enabled module template.

This module is designed to be consumed by AI clients via the Model Context
Protocol (MCP).  It can also run as a standard HLA-Compass module on the
platform.

Run as MCP server:
    hla-compass mcp serve

Run on the platform:
    hla-compass publish --env dev
"""

from __future__ import annotations

from typing import Any, Dict

from pydantic import BaseModel, Field

from hla_compass import Module


class Input(BaseModel):
    query: str = Field(description="The analysis query to execute")
    limit: int = Field(100, ge=1, le=10000, description="Maximum number of results")


class MCPModule(Module):
    Input = Input

    def execute(self, input_data: Input, context: Dict[str, Any]) -> Dict[str, Any]:
        self.logger.info("Executing query: %s (limit=%d)", input_data.query, input_data.limit)

        # TODO: Replace with your analysis logic.
        # Available helpers:
        #   self.data.sql.query("SELECT ...")     -- run SQL queries
        #   self.data.sql.query_df("SELECT ...")   -- get results as DataFrame
        #   self.peptides.search(sequence="...")   -- search peptides
        #   self.proteins.search(gene_name="...")  -- search proteins
        #   self.storage.save_json(key, data)      -- save artifacts
        #   self.report_progress(50, "Halfway")    -- report progress

        results = {
            "query": input_data.query,
            "matches": [],
            "total": 0,
        }

        summary = {
            "query": input_data.query,
            "total_results": results["total"],
        }

        return self.success(results=results, summary=summary)
