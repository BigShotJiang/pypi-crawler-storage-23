CLASSMARKER = "|class"
ORIGINMARKER = "|origin"
ARGSMARKER = "|args"
