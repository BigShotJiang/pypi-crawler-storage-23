## v0.4.0 (2026-02-24)

### Feat

- add container execution (#6)

### Fix

- trigger build
- cleanup (#5)
- channels (#4)

## v0.3.0 (2026-02-23)

### Feat

- introducing skillbot (#2)

### Fix

- trigger release pipeline after tagging v0.2.0
- release pipeline (#3)

## v0.2.0 (2026-02-23)

### Feat

- skillbot repo setup (#1)
