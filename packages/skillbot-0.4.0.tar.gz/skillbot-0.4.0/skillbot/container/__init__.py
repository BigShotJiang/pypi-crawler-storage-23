"""Container management for isolated skill execution."""
