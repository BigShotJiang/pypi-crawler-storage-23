# Summarize Task Progress

You are summarizing the conversation history so far to reduce context window usage while preserving all important information.

## Task

{{task_description}}

## Instructions

Create a concise summary of the conversation that includes:

1. **Original Task**: What was requested
2. **Actions Taken**: What steps were executed and their results
3. **Current State**: Where things stand now
4. **Outstanding Items**: What still needs to be done
5. **Key Decisions**: Any important decisions or trade-offs made

Be thorough enough that the agent can continue working effectively with only this summary and without the full conversation history.
