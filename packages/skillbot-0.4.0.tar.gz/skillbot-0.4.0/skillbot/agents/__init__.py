"""Agent implementations."""
