"""Communication channels for Skillbot (CLI, etc.)."""
