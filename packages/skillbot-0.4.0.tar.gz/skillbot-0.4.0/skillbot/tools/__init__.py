"""Tool infrastructure for Skillbot agents."""
