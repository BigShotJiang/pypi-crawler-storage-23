"""A2A server setup for Skillbot."""

from skillbot.server.a2a_server import create_a2a_app

__all__ = ["create_a2a_app"]
