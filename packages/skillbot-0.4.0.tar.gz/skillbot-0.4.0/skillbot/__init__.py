"""Skillbot - An agentic bot powered by skills."""

__version__ = "0.4.0"
