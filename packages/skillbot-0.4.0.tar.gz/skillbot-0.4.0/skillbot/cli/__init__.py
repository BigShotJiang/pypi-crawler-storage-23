"""Skillbot CLI."""
