"""Skill discovery and loading."""

from skillbot.skills.loader import (
    SkillMetadata,
    discover_skills,
    load_skill,
    load_skill_scripts,
)

__all__ = [
    "SkillMetadata",
    "discover_skills",
    "load_skill",
    "load_skill_scripts",
]
