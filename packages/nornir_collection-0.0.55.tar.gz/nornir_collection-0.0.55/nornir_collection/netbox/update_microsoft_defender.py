#!/usr/bin/env python3
"""
TBD
"""

import os
import requests
from rich import print as rprint


__author__ = "Willi Kubny"
__maintainer__ = "Willi Kubny"
__version__ = "1.0"
__license__ = "MIT"
__email__ = "willi.kubny@dreyfusbank.ch"
__status__ = "Production"


def main(nr_config: str) -> None:
    """
    TBD
    """

    #### Get Microsoft Defender Data ########################################################################

    entra_tenant_id = os.environ.get("DEFENDER_ENTRA_TENANT_ID")
    entra_app_id = os.environ.get("DEFENDER_ENTRA_APP_ID")
    entra_app_secret = os.environ.get("DEFENDER_ENTRA_APP_SECRET")

    url = f"https://login.microsoftonline.com/{entra_tenant_id}/oauth2/v2.0/token"

    headers = {
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    data = {
        "scope": "https://api.security.microsoft.com/.default",
        "client_id": entra_app_id,
        "client_secret": entra_app_secret,
        "grant_type": "client_credentials",
    }

    response = requests.post(url=url, data=data, headers=headers, timeout=(3.05, 27), verify=False)  # nosec
    json_response = response.json()
    rprint(json_response)
    bearer_token = json_response["access_token"]
    print(bearer_token)

    url = "https://api.security.microsoft.com/api/machines/"
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": f"Bearer {bearer_token}",
    }

    response = requests.get(url=url, headers=headers, timeout=(3.05, 27), verify=False)  # nosec

    json_response = response.json()

    rprint(json_response)
