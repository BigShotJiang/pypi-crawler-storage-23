# UAP Dashboard utilities
