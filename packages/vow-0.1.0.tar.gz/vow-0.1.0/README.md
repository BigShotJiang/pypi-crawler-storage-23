
 vow makes self-signed certs minty fresh.
