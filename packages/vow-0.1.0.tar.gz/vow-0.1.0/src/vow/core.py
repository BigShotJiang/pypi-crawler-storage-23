
"""
vow makes self-signed certs minty fresh.

Copyright (C) 2026  Brian Farrell

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published
by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

Contact: brian.farrell@me.com
"""


import argparse
from datetime import date, datetime, timedelta, UTC
import os
from pathlib import Path

from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from loguru import logger


type PrivateKey = rsa.RSAPrivateKey | Ed25519PrivateKey

# Date/Time
START = datetime.now(UTC)
START_DATE = date(START.year, START.month, START.day)

# RSA Params - Private Key
PUBLIC_EXPONENT = 65537
KEY_SIZE = 4096

# Certificate Params
COUNTRY_NAME = "US"
STATE_OR_PROVINCE_NAME = "Virginia"
LOCALITY_NAME = "McLean"
ORGANIZATION_NAME = "TroveFM"
COMMON_NAME = "trove.internal"
DAYS_VALID = 365
ALT_NAMES = []

# Build Paths
PRIV_KEY_PATH = Path('.', 'certs', COMMON_NAME, START_DATE.isoformat(), 'privkey.pem')
CERT_PATH = Path('.', 'certs', COMMON_NAME, START_DATE.isoformat(), 'cert.pem')



class CertManager(object):
    """docstring for CertManager"""

    def __init__(self, args: argparse.Namespace):
        self._user: str = os.getlogin()
        self._uid: int = os.getuid()
        self._key: PrivateKey
        self._key_alg: str = args.key_alg  # pyright: ignore[reportAny]

        # logger.warning(f"User is: {type(self._user)}")
        # logger.warning(f"UID is: {type(self._uid)}")

    def build(self):
        logger.info("GOIN' TO MAKE A CERT...")
        self._gen_key()
        self._save_private_key()
        self._sign_cert()

    def _gen_key(self):
        # Generate our key
        if self._key_alg == 'ed25519':
            self._key = Ed25519PrivateKey.generate()
        else:
            self._key = rsa.generate_private_key(
                public_exponent=PUBLIC_EXPONENT,
                key_size=KEY_SIZE
            )

        logger.info(f"GENERATED KEY: {self._key_alg}")

    def _save_private_key(self):
        # Write our key to disk for safe keeping
        with open(PRIV_KEY_PATH.resolve(), "wb") as f:
            _ = f.write(
                    self._key.private_bytes(
                        encoding=serialization.Encoding.PEM,
                        format=serialization.PrivateFormat.PKCS8,
                        encryption_algorithm=serialization.NoEncryption(),
                    )
                )
            os.fchmod(f.fileno(), 0o440)

        logger.info(f"SAVED KEY: {PRIV_KEY_PATH.resolve()}")

    def _sign_cert(self):
        # Various details about who we are. For a self-signed certificate the
        # subject and issuer are always the same.
        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COUNTRY_NAME, COUNTRY_NAME),
            x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, STATE_OR_PROVINCE_NAME),
            x509.NameAttribute(NameOID.LOCALITY_NAME, LOCALITY_NAME),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, ORGANIZATION_NAME),
            x509.NameAttribute(NameOID.COMMON_NAME, COMMON_NAME),
        ])

        cert = x509.CertificateBuilder().subject_name(
            subject
        ).issuer_name(
            issuer
        ).public_key(
            self._key.public_key()
        ).serial_number(
            x509.random_serial_number()
        ).not_valid_before(
            START
        ).not_valid_after(
            START + timedelta(days=DAYS_VALID)
        ).add_extension(
            x509.SubjectAlternativeName([x509.DNSName(f"{name}") for name in ALT_NAMES]),
            critical=False,
        ).sign(self._key, hashes.SHA256() if self._key_alg == 'rsa' else None)

        # Write our certificate out to disk.
        with open(CERT_PATH.resolve(), "wb") as f:
            _ = f.write(cert.public_bytes(serialization.Encoding.PEM))
            os.fchmod(f.fileno(), 0o444)

        logger.info(f"GENERATED CERT: {CERT_PATH.resolve()}")
