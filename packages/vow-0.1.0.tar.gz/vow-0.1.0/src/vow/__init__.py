
"""
vow makes self-signed certs minty fresh.

Copyright (C) 2026  Brian Farrell

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published
by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

Contact: brian.farrell@me.com
"""

import argparse
import sys

from loguru import logger

from vow.core import *
from vow.exceptions import ExitCode


parser = argparse.ArgumentParser(
    prog='vow',
    argument_default=argparse.SUPPRESS,
    description='vow makes self-signed certs minty fresh.',
    formatter_class=argparse.RawTextHelpFormatter,
    epilog='\n \n',
)

_ = parser.add_argument(
    '-k', '--key-algorithm',
    action='store',
    choices=['ed25519', 'rsa'],
    default='ed25519',
    dest='key_alg',
    help='key algorithm to use',
)

args_optional = set(
    {
        'key_alg': None
    }
)


def main():
    args = parser.parse_args() or None

    args_given = set(vars(args))
    check = args_given ^ args_optional

    if len(check) > 1:
        parser.print_help()
        return ExitCode.EX_USAGE
    else:
        logger.info(f"ARGS: {args}")

        # Check if 
        pk_parent = PRIV_KEY_PATH.parent
        pk_parent_exists = pk_parent.exists()
        pk_parent_empty = False

        cert_parent = CERT_PATH.parent
        cert_parent_exists = cert_parent.exists()
        cert_parent_empty = False

        dir_match = False

        logger.info(f"PRIV_KEY_PATH: {PRIV_KEY_PATH}")
        logger.info(f"pk_parent: {pk_parent}")

        if pk_parent_exists:
            # pk_parent_empty is True when the list returned by os.listdir is empty
            pk_parent_empty = not os.listdir(pk_parent)
            logger.info(f"pk_parent_empty: {bool(pk_parent_empty)}")
        else:
            logger.info(f"pk_parent_exists: {pk_parent_exists}")
            logger.info(f"Creating Directory: {pk_parent}")
            pk_parent.mkdir(mode=0o755, parents=True)
            pk_parent_exists = pk_parent.exists()
            pk_parent_empty = True

        logger.info(f"CERT_PATH: {CERT_PATH}")
        logger.info(f"cert_parent: {cert_parent}")

        if cert_parent_exists:
            # cert_parent_empty is True when the list returned by os.listdir is empty
            cert_parent_empty = not os.listdir(cert_parent)
            logger.info(f"cert_parent_empty: {bool(cert_parent_empty)}")
        else:
            logger.info(f"cert_parent_exists: {cert_parent_exists}")
            logger.info(f"Creating Directory: {cert_parent}")
            cert_parent.mkdir(mode=0o755, parents=True, exist_ok=True)
            cert_parent_exists = cert_parent.exists()
            cert_parent_empty = True

        if pk_parent_exists and cert_parent_exists:
            dir_match = cert_parent.samefile(pk_parent)
            logger.info(f"dir_match: {dir_match}")
            if not dir_match:
                logger.warning("PK Dir and Cert Dir are not the same path!!!")

        manager = CertManager(args)


        try:
            if pk_parent_empty and cert_parent_empty:
                manager.build()
            else:
                if not pk_parent_empty:
                    logger.error(f"{pk_parent} is NOT an empty directory and --force option not used!!!")
                if not cert_parent_empty and not dir_match:
                    logger.error(f"{cert_parent} is NOT an empty directory and --force option not used!!!")
                logger.error("No certs will be created. Exiting...")
                sys.exit(73)
        except SystemExit as e:
            return e.code
        else:
            return ExitCode.EX_SUCCESS
