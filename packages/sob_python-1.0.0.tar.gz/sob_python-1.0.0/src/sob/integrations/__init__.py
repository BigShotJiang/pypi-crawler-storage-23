"""SOB integrations for LLM frameworks."""
