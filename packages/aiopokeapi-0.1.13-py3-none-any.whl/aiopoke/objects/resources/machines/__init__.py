from aiopoke.objects.resources.machines.machine import Machine

__all__ = ("Machine",)
