<!-- 
Author(s): Shibaji Chakraborty

Disclaimer:


-->

# pyTrace
<div style="text-align: center;">
  <!-- <img src="assets/Colab-trace-logo2.jpg" alt="trace" width="50%"> -->
</div>

[![License: MIT](https://img.shields.io/badge/License%3A-MIT-green)](https://choosealicense.com/licenses/mit/) 
[![Python 3.11](https://img.shields.io/badge/python-3.11-blue.svg)](https://www.python.org/downloads/release/python-3110/) 
![GitHub Stable Release (latest by date)](https://img.shields.io/github/v/release/shibaji7/trace)
[![Documentation Status](https://img.shields.io/readthedocs/trace?logo=readthedocs&label=docs)](https://trace.readthedocs.io/en/latest/?badge=latest)
[![codecov](https://codecov.io/gh/shibaji7/trace/branch/main/graph/badge.svg)](https://codecov.io/gh/shibaji7/trace)


Trace is an open-source Python-based application designed for precision ionospheric HF radio tracing, with a strong focus on analyzing the phase characteristics of radio echoes. Tailored for Space Weather applications, trace offers a suite of unique tools that help extract valuable insights directly and autonomously from ionogram data.

Designed as a comprehensive toolbox, trace empowers researchers to understand HF ray-path efficiently, providing reliable, insights into ionospheric conditions and phenomena. Whether you're focused on space weather forecasting, radio communication, or scientific exploration, trace is your go-to tool for precision ionospheric HF-tracing analysis.

## Source Code 

The library source code can be found on the [trace GitHub](https://github.com/shibaji7/trace) repository. 

If you have any questions or concerns please submit an **Issue** on the [trace GitHub](https://github.com/shibaji7/trace) repository. 