<!-- 
Author(s): Shibaji Chakraborty

Disclaimer:

-->

![Shibaji Chakraborty](../figures/Chakraborty.png)<br>__Shibaji Chakraborty__<br> Developer, contributed to data analysis and software development. Specializes in atmospheric, space physics, space weather, with extensive work in high-frequency (HF) radar systems and the SuperDARN network. 
---

**Disclaimer:**  
This page credits the primary contributors to the project. For more details, refer to the project documentation.
