"""AgentShare - Unifying layer for AI coding agents."""

__version__ = "0.1.0"
