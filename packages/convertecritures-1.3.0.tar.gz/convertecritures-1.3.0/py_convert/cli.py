from py_convert.gui.app import App

def main():
    app = App()
    app.run()

if __name__ == "__main__":
    main()