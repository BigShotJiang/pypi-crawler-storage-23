"""TracingManager — OpenTelemetry tracing lifecycle for AgentOps.

SPEC-007 §3.3: Tracing initialization, Foundry + local modes, framework auto-instrumentation.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class TracingConfig:
    """Configuration for AgentOps tracing (SPEC-007 §3.3)."""

    project_endpoint: str = ""
    capture_content: bool = False
    service_name: str = "agentops"
    local_mode: bool = False
    otlp_endpoint: str | None = None


class TracingManager:
    """Manages OpenTelemetry tracing lifecycle (SPEC-007 §3.3).

    Supports two modes:
    - **Foundry mode**: Sends spans to Application Insights via Foundry project
    - **Local mode**: Console output or OTLP endpoint (Aspire Dashboard, AI Toolkit)
    """

    def __init__(self, config: TracingConfig) -> None:
        self._config = config
        self._tracer = None
        self._initialized = False

    def initialize(self):
        """Set up tracing and return the tracer instance."""
        from opentelemetry import trace

        os.environ["OTEL_SERVICE_NAME"] = self._config.service_name
        if self._config.capture_content:
            os.environ["AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED"] = "true"
            os.environ["OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"] = "true"

        if self._config.local_mode:
            self._setup_local_tracing()
        else:
            self._setup_foundry_tracing()

        self._tracer = trace.get_tracer("agentops")
        self._initialized = True
        logger.info(
            "Tracing initialized (mode=%s, service=%s)",
            "local" if self._config.local_mode else "foundry",
            self._config.service_name,
        )
        return self._tracer

    def _setup_foundry_tracing(self) -> None:
        """Configure tracing to send spans to Foundry via Application Insights."""
        try:
            from azure.ai.projects import AIProjectClient
            from azure.identity import DefaultAzureCredential
            from azure.monitor.opentelemetry import configure_azure_monitor

            client = AIProjectClient(
                credential=DefaultAzureCredential(),
                endpoint=self._config.project_endpoint,
            )
            conn_string = client.telemetry.get_application_insights_connection_string()
            configure_azure_monitor(connection_string=conn_string)
            logger.info("Foundry tracing configured → Application Insights")
        except ImportError as e:
            raise ImportError(
                "Observability dependencies not installed. "
                "Run: pip install agentops-toolkit[observability]"
            ) from e

    def _setup_local_tracing(self) -> None:
        """Configure tracing for local development (console or OTLP)."""
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import ConsoleSpanExporter, SimpleSpanProcessor

        tracer_provider = TracerProvider()

        if self._config.otlp_endpoint:
            try:
                from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

                exporter = OTLPSpanExporter(endpoint=self._config.otlp_endpoint)
                logger.info("Local tracing → OTLP %s", self._config.otlp_endpoint)
            except ImportError:
                logger.warning("OTLP exporter not available, falling back to console")
                exporter = ConsoleSpanExporter()
        else:
            exporter = ConsoleSpanExporter()
            logger.info("Local tracing → console")

        tracer_provider.add_span_processor(SimpleSpanProcessor(exporter))
        trace.set_tracer_provider(tracer_provider)

    def instrument_framework(self, framework: str) -> None:
        """Auto-instrument a supported agent framework (SPEC-007 §3.5)."""
        instrumentors = {
            "openai": self._instrument_openai,
            "semantic-kernel": self._instrument_semantic_kernel,
            "langchain": self._instrument_langchain,
            "openai-agents": self._instrument_openai_agents,
        }
        instrumentor = instrumentors.get(framework)
        if instrumentor:
            instrumentor()
            logger.info("Framework instrumented: %s", framework)
        else:
            logger.warning("Unknown framework for tracing: %s", framework)

    def _instrument_openai(self) -> None:
        try:
            from opentelemetry.instrumentation.openai_v2 import OpenAIInstrumentor

            OpenAIInstrumentor().instrument()
        except ImportError:
            logger.warning("opentelemetry-instrumentation-openai-v2 not installed")

    def _instrument_semantic_kernel(self) -> None:
        try:
            from azure.core.settings import settings

            settings.tracing_implementation = "opentelemetry"
        except ImportError:
            logger.warning("azure-core-tracing-opentelemetry not installed")

    def _instrument_langchain(self) -> None:
        logger.info("LangChain tracing: attach callbacks at chain invocation time")

    def _instrument_openai_agents(self) -> None:
        logger.info("OpenAI Agents SDK: OTEL support configured via env vars")

    @property
    def tracer(self):
        if self._tracer is None:
            raise RuntimeError("TracingManager not initialized. Call initialize() first.")
        return self._tracer

    @property
    def is_initialized(self) -> bool:
        return self._initialized
