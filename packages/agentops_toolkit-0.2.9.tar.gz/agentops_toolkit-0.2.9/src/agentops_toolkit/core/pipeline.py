"""Evaluation pipeline orchestration.

SPEC-003 §2–3: Load & Validate → Agent Execution → Evaluation → Aggregation.

For Sprint 1, we implement a simplified pipeline that:
  1. Loads a JSONL dataset
  2. Runs evaluators against each entry (agent response already in dataset)
  3. Aggregates results into a RunSummary
  4. Persists the Run to disk
"""

from __future__ import annotations

import json
import logging
import statistics
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from agentops_toolkit import __version__
from agentops_toolkit.core.bundle_registry import BundleRegistry
from agentops_toolkit.evaluators.base import FoundryEvaluatorWrapper
from agentops_toolkit.models.dataset import DatasetEntry
from agentops_toolkit.models.run import (
    EntryStatus,
    EvalResult,
    EvaluatorSummary,
    Run,
    RunConfig,
    RunEntry,
    RunStatus,
    RunSummary,
)

logger = logging.getLogger(__name__)

# Suppress verbose Azure SDK retry tracebacks (429 rate-limit errors).
# The SDK handles retries internally; we don't need the noise.
logging.getLogger("azure.ai.evaluation._legacy").setLevel(logging.ERROR)


@dataclass
class EvalProgress:
    """Progress update emitted after each dataset entry is evaluated."""

    current: int  # 1-based entry index
    total: int
    entry_id: str
    query: str  # truncated query text
    status: str  # "success", "error", "skipped"
    scores: dict[str, float | None]  # evaluator_name -> score
    model_deployment: str
    model_name: str


def load_dataset(path: str | Path) -> list[DatasetEntry]:
    """Load a JSONL dataset file into DatasetEntry objects."""
    entries: list[DatasetEntry] = []
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {path}")

    with open(path, encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
                if "id" not in data or not data["id"]:
                    data["id"] = f"{i:04d}"
                entries.append(DatasetEntry.model_validate(data))
            except Exception as e:
                raise ValueError(f"Failed to parse dataset entry on line {i}: {e}") from e
    return entries


def _build_evaluator_input(entry: DatasetEntry) -> dict[str, Any]:
    """Build evaluator input dict from a DatasetEntry."""
    data: dict[str, Any] = {"query": entry.query}
    if entry.response:
        data["response"] = entry.response
    if entry.context:
        ctx = entry.context if isinstance(entry.context, str) else "\n".join(entry.context)
        data["context"] = ctx
    if entry.ground_truth:
        data["ground_truth"] = entry.ground_truth
    return data


async def evaluate_entry(
    entry: DatasetEntry,
    evaluators: list[FoundryEvaluatorWrapper],
) -> RunEntry:
    """Evaluate a single dataset entry against all evaluators.

    Returns a RunEntry with eval_results populated.
    """
    if not entry.response:
        return RunEntry(
            dataset_entry_id=entry.id,
            status=EntryStatus.SKIPPED,
            error_message="No agent response to evaluate",
        )

    input_data = _build_evaluator_input(entry)
    eval_results: list[EvalResult] = []
    start = time.monotonic()

    for evaluator in evaluators:
        # Check required columns
        missing = [c for c in evaluator.required_columns if c not in input_data]
        if missing:
            eval_results.append(
                EvalResult(
                    evaluator_name=evaluator.name,
                    score=None,
                    passed=None,
                    raw_output={"error": f"Missing columns: {missing}"},
                )
            )
            continue

        result = await evaluator.evaluate(input_data)
        eval_results.append(result)

    latency = (time.monotonic() - start) * 1000

    return RunEntry(
        dataset_entry_id=entry.id,
        status=EntryStatus.SUCCESS,
        agent_response=entry.response,
        agent_latency_ms=latency,
        eval_results=eval_results,
    )


def compute_summary(entries: list[RunEntry], total_duration_ms: float) -> RunSummary:
    """Compute aggregate statistics from RunEntries (SPEC-003 §3 Phase 4)."""
    successful = sum(1 for e in entries if e.status == EntryStatus.SUCCESS)
    failed = sum(1 for e in entries if e.status == EntryStatus.ERROR)
    skipped = sum(1 for e in entries if e.status == EntryStatus.SKIPPED)

    # Collect scores per evaluator
    evaluator_scores: dict[str, list[float]] = {}
    evaluator_passes: dict[str, list[bool]] = {}

    for entry in entries:
        for er in entry.eval_results:
            if er.score is not None:
                evaluator_scores.setdefault(er.evaluator_name, []).append(er.score)
            if er.passed is not None:
                evaluator_passes.setdefault(er.evaluator_name, []).append(er.passed)

    summaries: dict[str, EvaluatorSummary] = {}
    for name, scores in evaluator_scores.items():
        passes = evaluator_passes.get(name, [])
        pass_rate = sum(passes) / len(passes) if passes else None
        summaries[name] = EvaluatorSummary(
            evaluator_name=name,
            mean_score=statistics.mean(scores),
            median_score=statistics.median(scores),
            min_score=min(scores),
            max_score=max(scores),
            std_dev=statistics.stdev(scores) if len(scores) > 1 else 0.0,
            pass_rate=pass_rate,
        )

    # Aggregate score = weighted mean of evaluator means
    aggregate = statistics.mean(s.mean_score for s in summaries.values()) if summaries else None

    # Overall pass rate = % of entries where ALL evaluators passed
    all_passed = 0
    for entry in entries:
        if entry.status == EntryStatus.SUCCESS:
            entry_passed = all(
                er.passed is True for er in entry.eval_results if er.passed is not None
            )
            if entry_passed:
                all_passed += 1
    overall_pass_rate = all_passed / successful if successful > 0 else None

    # Latencies
    latencies = [e.agent_latency_ms for e in entries if e.agent_latency_ms is not None]
    avg_latency = statistics.mean(latencies) if latencies else 0.0
    sorted_lat = sorted(latencies)
    p95_idx = int(len(sorted_lat) * 0.95) if sorted_lat else 0
    p95_latency = sorted_lat[min(p95_idx, len(sorted_lat) - 1)] if sorted_lat else 0.0

    return RunSummary(
        total_entries=len(entries),
        successful_entries=successful,
        failed_entries=failed,
        skipped_entries=skipped,
        evaluator_scores=summaries,
        aggregate_score=aggregate,
        pass_rate=overall_pass_rate,
        total_duration_ms=total_duration_ms,
        avg_agent_latency_ms=avg_latency,
        p95_agent_latency_ms=p95_latency,
    )


def _derive_ai_services_endpoint(project_endpoint: str) -> str:
    """Derive the AI Services base endpoint from a project endpoint.

    Project endpoint format:
        https://<account>.services.ai.azure.com/api/projects/<project>
    AI Services base endpoint:
        https://<account>.services.ai.azure.com
    """
    from urllib.parse import urlparse

    parsed = urlparse(project_endpoint)
    return f"{parsed.scheme}://{parsed.netloc}"


def _is_reasoning_model(model_name: str) -> bool:
    """Check if a model is an o-series reasoning model.

    Reasoning models (o1, o3, o4-mini, etc.) require API version
    2024-12-01-preview or later, which is incompatible with the
    azure-ai-evaluation SDK's default of 2024-02-15-preview.
    """
    import re

    name = model_name.lower().strip()
    # Match o-series: o1, o1-mini, o3, o4-mini, etc.
    return bool(re.match(r"^o\d", name))


# The azure-ai-evaluation SDK uses "2024-02-15-preview" by default.
# Reasoning models require "2024-12-01-preview" or later.
_EVAL_SDK_API_VERSION = "2024-02-15-preview"
_REASONING_MODEL_API_VERSION = "2024-12-01-preview"


def _discover_chat_deployment(
    project_endpoint: str,
) -> tuple[str, str, str] | None:
    """Auto-discover a chat-capable model deployment via AI Foundry SDK.

    Returns a ``(deployment_name, model_name, api_version)`` tuple for the
    best candidate, or *None* when no suitable deployment is found.

    Selection criteria:
      1. Must have ``chat_completion`` capability.
      2. Prefers models compatible with the evaluation SDK's default API
         version (``2024-02-15-preview``).  Reasoning / o-series models that
         require a newer version are ranked lower but still usable.
      3. Among compatible models, smaller / cheaper variants are preferred
         (``mini`` → ``gpt-4.1`` → others).
    """
    try:
        from azure.ai.projects import AIProjectClient
        from azure.ai.projects.models import ModelDeployment
        from azure.identity import DefaultAzureCredential

        client = AIProjectClient(
            credential=DefaultAzureCredential(),
            endpoint=project_endpoint,
        )

        # Partition into compatible and reasoning-only buckets
        compatible: list[tuple[str, str]] = []  # (name, model_name)
        reasoning_only: list[tuple[str, str]] = []

        for deployment in client.deployments.list():
            if not isinstance(deployment, ModelDeployment):
                continue
            caps = deployment.capabilities or {}
            if caps.get("chat_completion") != "true":
                continue
            model_name = deployment.model_name or deployment.name
            if _is_reasoning_model(model_name):
                reasoning_only.append((deployment.name, model_name))
            else:
                compatible.append((deployment.name, model_name))

        def _pick_preferred(
            candidates: list[tuple[str, str]],
        ) -> tuple[str, str] | None:
            """Return the best (deployment_name, model_name) from *candidates*."""
            preferred = ["mini", "4.1-mini", "4o-mini", "gpt-4.1"]
            for pref in preferred:
                for dep_name, mdl_name in candidates:
                    if pref in dep_name.lower() or pref in mdl_name.lower():
                        return (dep_name, mdl_name)
            return (candidates[0][0], candidates[0][1]) if candidates else None

        # First try compatible models (work with eval SDK default API version)
        if compatible:
            chosen = _pick_preferred(compatible)
            if chosen:
                logger.info(
                    "Auto-discovered deployment '%s' (%s) (api_version=%s)",
                    chosen[0],
                    chosen[1],
                    _EVAL_SDK_API_VERSION,
                )
                return (chosen[0], chosen[1], _EVAL_SDK_API_VERSION)

        # Fall back to reasoning models with a newer API version
        if reasoning_only:
            chosen = _pick_preferred(reasoning_only)
            if chosen:
                logger.warning(
                    "Only reasoning model deployments available. Using '%s' (%s) with api_version=%s",
                    chosen[0],
                    chosen[1],
                    _REASONING_MODEL_API_VERSION,
                )
                return (chosen[0], chosen[1], _REASONING_MODEL_API_VERSION)

        return None

    except Exception as e:
        logger.warning("Failed to auto-discover deployments: %s", e)
        return None


def list_chat_deployments(
    project_endpoint: str,
) -> list[tuple[str, str, str]]:
    """List all chat-capable model deployments.

    Returns a list of ``(deployment_name, model_name, api_version)`` tuples
    for every deployment that supports ``chat_completion``.
    """
    try:
        from azure.ai.projects import AIProjectClient
        from azure.ai.projects.models import ModelDeployment
        from azure.identity import DefaultAzureCredential

        client = AIProjectClient(
            credential=DefaultAzureCredential(),
            endpoint=project_endpoint,
        )

        results: list[tuple[str, str, str]] = []
        for deployment in client.deployments.list():
            if not isinstance(deployment, ModelDeployment):
                continue
            caps = deployment.capabilities or {}
            if caps.get("chat_completion") != "true":
                continue
            model_name = deployment.model_name or deployment.name
            api_ver = (
                _REASONING_MODEL_API_VERSION
                if _is_reasoning_model(model_name)
                else _EVAL_SDK_API_VERSION
            )
            results.append((deployment.name, model_name, api_ver))
        return results

    except Exception as e:
        logger.warning("Failed to list deployments: %s", e)
        return []


def resolve_model_deployment(
    project_endpoint: str,
    deployment_name: str,
) -> tuple[str, str, str] | None:
    """Resolve a single deployment name to ``(deployment_name, model_name, api_version)``.

    Returns *None* if the deployment is not found or doesn't support chat.
    """
    for dep_name, mdl_name, api_ver in list_chat_deployments(project_endpoint):
        if dep_name == deployment_name:
            return (dep_name, mdl_name, api_ver)
    return None


async def run_evaluation(
    dataset_path: str | Path,
    bundle_name: str,
    output_dir: str | Path = "agentops/runs",
    run_name: str = "default",
    project_connection: str = "",
    model_deployment: str = "",
    on_progress: Callable[[EvalProgress], None] | None = None,
) -> Run:
    """Execute the full evaluation pipeline.

    For Sprint 1, this evaluates a pre-populated dataset (agent responses
    already in the JSONL) against the specified bundle's evaluators.

    Args:
        project_connection: AI Foundry project endpoint URL.
        model_deployment: Model deployment name for LLM-judge evaluators.
            If empty, auto-discovers a suitable chat model from the project.
    """
    output_dir = Path(output_dir)

    # Load bundle
    registry = BundleRegistry()
    bundle = registry.get(bundle_name)

    # Load dataset
    dataset = load_dataset(dataset_path)
    if not dataset:
        raise ValueError(f"Dataset is empty: {dataset_path}")

    # Build model_config for LLM-judge evaluators
    model_config: dict[str, Any] | None = None
    resolved_deployment = ""
    resolved_model_name = ""
    if project_connection:
        # Derive the AI Services base endpoint from the project endpoint
        azure_endpoint = _derive_ai_services_endpoint(project_connection)

        # Resolve deployment + API version
        deployment: str | None = None
        api_version: str = _EVAL_SDK_API_VERSION

        if model_deployment:
            # Explicit deployment — pick correct API version
            deployment = model_deployment
            if _is_reasoning_model(model_deployment):
                api_version = _REASONING_MODEL_API_VERSION
                logger.info(
                    "Reasoning model detected; using api_version=%s",
                    api_version,
                )
        else:
            # Auto-discover
            result = _discover_chat_deployment(project_connection)
            if result:
                deployment, resolved_model_name, api_version = result

        if deployment:
            resolved_deployment = deployment
            model_config = {
                "azure_endpoint": azure_endpoint,
                "azure_deployment": deployment,
                "api_version": api_version,
            }
            logger.info(
                "Using model deployment '%s' at %s (api_version=%s)",
                deployment,
                azure_endpoint,
                api_version,
            )
        else:
            logger.warning(
                "No chat-capable model deployment found. "
                "LLM-judge evaluators will fail. "
                "Deploy a chat model in your AI Foundry project or set "
                "model_deployment in agentops.yaml."
            )

    # Build evaluators
    evaluators = [
        FoundryEvaluatorWrapper(
            evaluator_name=ev.name,
            threshold=bundle.thresholds.get(ev.name),
            model_config=model_config,
            project_connection=project_connection,
        )
        for ev in bundle.evaluators
        if ev.type.value == "foundry"
    ]

    # Create run
    run_id = datetime.now(UTC).strftime("%Y-%m-%d") + "_" + uuid.uuid4().hex[:8]
    run_dir = output_dir / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    run = Run(
        id=run_id,
        name=run_name,
        status=RunStatus.RUNNING,
        config=RunConfig(
            agent_entry="",
            dataset=str(dataset_path),
            bundle=bundle_name,
        ),
        bundle_snapshot=bundle,
        dataset_name=Path(dataset_path).stem,
        created_at=datetime.now(UTC),
        started_at=datetime.now(UTC),
        toolkit_version=__version__,
        foundry_project=project_connection,
        model_deployment=resolved_deployment,
        model_name=resolved_model_name,
    )

    # Evaluate each entry
    start = time.monotonic()
    run_entries: list[RunEntry] = []

    for entry in dataset:
        try:
            run_entry = await evaluate_entry(entry, evaluators)
            run_entries.append(run_entry)

            if on_progress:
                scores = {
                    er.evaluator_name: er.score
                    for er in run_entry.eval_results
                }
                on_progress(
                    EvalProgress(
                        current=len(run_entries),
                        total=len(dataset),
                        entry_id=entry.id,
                        query=entry.query[:60],
                        status=run_entry.status.value,
                        scores=scores,
                        model_deployment=resolved_deployment,
                        model_name=resolved_model_name,
                    )
                )

            # Stream to entries.jsonl (SPEC-003 §5)
            with open(run_dir / "entries.jsonl", "a", encoding="utf-8") as f:
                f.write(run_entry.model_dump_json() + "\n")

        except Exception as e:
            logger.error("Error evaluating entry %s: %s", entry.id, e)
            error_entry = RunEntry(
                dataset_entry_id=entry.id,
                status=EntryStatus.ERROR,
                error_message=str(e),
                error_type=type(e).__name__,
            )
            run_entries.append(error_entry)

            if on_progress:
                on_progress(
                    EvalProgress(
                        current=len(run_entries),
                        total=len(dataset),
                        entry_id=entry.id,
                        query=entry.query[:60],
                        status="error",
                        scores={},
                        model_deployment=resolved_deployment,
                        model_name=resolved_model_name,
                    )
                )

    total_duration = (time.monotonic() - start) * 1000

    # Compute summary
    summary = compute_summary(run_entries, total_duration)

    # Finalize run
    run.entries = run_entries
    run.summary = summary
    run.status = RunStatus.COMPLETED
    run.completed_at = datetime.now(UTC)

    # Persist run.json (atomic write via temp + rename — SPEC-003 §5)
    run_json = run_dir / "run.json"
    tmp = run_json.with_suffix(".tmp")
    tmp.write_text(run.model_dump_json(indent=2), encoding="utf-8")
    tmp.rename(run_json)

    return run
