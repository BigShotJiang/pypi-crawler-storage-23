"""Streaming persistence — incremental run data to disk.

SPEC-003 §5: RunPersistence with entries.jsonl append and atomic run.json writes.
"""
