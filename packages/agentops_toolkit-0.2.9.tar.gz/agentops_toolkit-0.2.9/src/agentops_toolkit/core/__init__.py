"""Core evaluation engine and pipeline.

SPEC-003: Evaluation Engine — pipeline, FoundryClient interface,
evaluator registry, aggregation, persistence.
"""
