"""agentops bundle list|show|create — Evaluator bundle management.

SPEC-002 §3.2–3.4, FR-010–FR-015.
"""

from __future__ import annotations

import json

import typer
from rich.console import Console
from rich.table import Table

from agentops_toolkit.core.bundle_registry import BundleRegistry
from agentops_toolkit.models.config import UseCase

console = Console()

bundle_app = typer.Typer(name="bundle", help="Manage evaluator bundles.")


@bundle_app.command("list")
def bundle_list(
    use_case: UseCase | None = typer.Option(None, "--use-case", "-u", help="Filter by use case"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table|json"),
    builtin_only: bool = typer.Option(False, "--builtin-only", help="Show only built-in bundles"),
) -> None:
    """List available evaluator bundles (SPEC-002 §3.2)."""
    registry = BundleRegistry()
    bundles = registry.list_all(use_case=use_case)

    if builtin_only:
        bundles = [b for b in bundles if b.builtin]

    if format == "json":
        data = [
            {
                "name": b.name,
                "use_case": b.use_case.value if b.use_case else None,
                "evaluators": len(b.evaluators),
                "description": b.description,
                "builtin": b.builtin,
            }
            for b in bundles
        ]
        console.print_json(json.dumps(data))
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("Bundle", style="cyan")
    table.add_column("Use Case")
    table.add_column("Evaluators", justify="right")
    table.add_column("Description")

    for b in bundles:
        uc = b.use_case.value if b.use_case else "any"
        marker = "" if b.builtin else " ✎"
        table.add_row(
            b.name + marker,
            uc,
            str(len(b.evaluators)),
            b.description,
        )

    console.print(table)


@bundle_app.command("show")
def bundle_show(
    name: str = typer.Argument(..., help="Bundle name"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table|json|yaml"),
) -> None:
    """Show detailed information about a bundle (SPEC-002 §3.3)."""
    registry = BundleRegistry()

    try:
        bundle = registry.get(name)
    except KeyError as e:
        console.print(f"[red]✗[/red] {e}")
        raise typer.Exit(code=1) from e

    if format == "json":
        data = bundle.model_dump()
        console.print_json(json.dumps(data, default=str))
        return

    # Header
    console.print()
    console.print(f"[bold]Bundle:[/bold] {bundle.name}")
    console.print(f"[bold]Use Case:[/bold] {bundle.use_case.value if bundle.use_case else 'any'}")
    console.print(f"[bold]Built-in:[/bold] {'✓' if bundle.builtin else '✗'}")
    if bundle.description:
        console.print(f"[bold]Description:[/bold] {bundle.description}")
    console.print()

    # Evaluator table
    table = Table(show_header=True, header_style="bold")
    table.add_column("Evaluator", style="cyan")
    table.add_column("Type")
    table.add_column("Weight", justify="right")
    table.add_column("Threshold", justify="right")

    for ev in bundle.evaluators:
        threshold = str(bundle.thresholds.get(ev.name, "—"))
        table.add_row(
            ev.name,
            ev.type.value,
            f"{ev.weight:.1f}",
            threshold,
        )

    console.print(table)
    console.print()


# ── Evaluator catalog for interactive selection ──

_FOUNDRY_EVALUATORS = [
    "groundedness",
    "relevance",
    "coherence",
    "fluency",
    "similarity",
    "f1_score",
    "hate_unfairness",
    "sexual",
    "violence",
    "self_harm",
    "protected_material",
    "jailbreak",
    "tool_call_accuracy",
    "task_completion",
    "handoff_quality",
]


@bundle_app.command("create")
def bundle_create(
    name: str = typer.Argument(..., help="Bundle name (must be unique)"),
    evaluators: str | None = typer.Option(
        None, "--evaluators", "-e", help="Comma-separated evaluator names"
    ),
    use_case: UseCase | None = typer.Option(None, "--use-case", "-u", help="Target use case"),
    from_bundle: str | None = typer.Option(None, "--from", help="Clone from existing bundle"),
    threshold: list[str] | None = typer.Option(
        None,
        "--threshold",
        "-t",
        help="name=value threshold pairs",
    ),
    description: str = typer.Option("", "--description", "-d", help="Bundle description"),
) -> None:
    """Create a custom evaluation bundle (SPEC-002 §3.4, FR-013)."""
    from pathlib import Path

    from ruamel.yaml import YAML

    registry = BundleRegistry()

    # Check uniqueness
    if name in registry.list_names():
        console.print(f"[red]✗[/red] Bundle '{name}' already exists.")
        raise typer.Exit(code=1)

    # Start from clone or empty
    eval_names: list[str] = []
    thresholds: dict[str, float] = {}

    if from_bundle:
        try:
            source = registry.get(from_bundle)
            eval_names = [e.name for e in source.evaluators]
            thresholds = dict(source.thresholds)
            if not description:
                description = f"Custom bundle based on {from_bundle}"
        except KeyError as e:
            console.print(f"[red]✗[/red] {e}")
            raise typer.Exit(code=1) from e

    if evaluators:
        eval_names = [e.strip() for e in evaluators.split(",")]

    if not eval_names:
        console.print("[red]✗[/red] No evaluators specified. Use --evaluators or --from.")
        raise typer.Exit(code=1)

    # Validate evaluator names
    for ev in eval_names:
        if ev not in _FOUNDRY_EVALUATORS:
            console.print(
                f"[yellow]⚠[/yellow] '{ev}' is not a known Foundry evaluator — treating as custom."
            )

    # Parse thresholds
    if threshold:
        for t in threshold:
            if "=" not in t:
                console.print(f"[red]✗[/red] Invalid threshold format: '{t}'. Use name=value.")
                raise typer.Exit(code=1)
            k, v = t.split("=", 1)
            thresholds[k.strip()] = float(v.strip())

    # Build YAML
    bundle_data = {
        "name": name,
        "description": description or f"Custom bundle: {name}",
        "evaluators": [
            {"name": ev, "type": "foundry" if ev in _FOUNDRY_EVALUATORS else "custom"}
            for ev in eval_names
        ],
        "thresholds": thresholds,
        "tags": ["custom"],
        "builtin": False,
    }
    if use_case:
        bundle_data["use_case"] = use_case.value

    # Write to bundles directory
    bundles_dir = Path("agentops/bundles")
    bundles_dir.mkdir(parents=True, exist_ok=True)
    bundle_path = bundles_dir / f"{name}.yaml"

    yaml = YAML()
    yaml.default_flow_style = False
    with open(bundle_path, "w", encoding="utf-8") as f:
        yaml.dump(bundle_data, f)

    console.print(
        f"[green]✓[/green] Bundle [bold]'{name}'[/bold] created with {len(eval_names)} evaluators"
    )
    console.print(f"  Saved to: {bundle_path}")
    console.print("  [dim]Tip: add to agentops.yaml bundles.custom to register permanently.[/dim]")
