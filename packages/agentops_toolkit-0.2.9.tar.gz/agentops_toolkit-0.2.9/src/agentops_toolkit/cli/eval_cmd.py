"""agentops eval run|entry — Evaluation commands.

SPEC-002 §3.11–3.12, FR-040–FR-049.
Phase 2: --continuous (SPEC-007 §5), --red-team (SPEC-007 §5.4),
         migrate (SPEC-007 §9), cicd (SPEC-007 §6), --via mcp (SPEC-009 §6.2).
"""

from __future__ import annotations

import asyncio
from pathlib import Path

import typer
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from agentops_toolkit.core.config_loader import ConfigError, load_config

console = Console()
eval_app = typer.Typer(name="eval", help="Run evaluations on agent outputs.")


@eval_app.command("run")
def eval_run(
    run_id: str = typer.Argument(
        "latest",
        help="Run ID to evaluate, or 'latest' for most recent. "
        "In Sprint 1, pass a dataset path directly.",
    ),
    bundle: str | None = typer.Option(None, "--bundle", "-b", help="Override bundle"),
    dataset: str | None = typer.Option(None, "--dataset", "-d", help="Dataset path (JSONL)"),
    config: str | None = typer.Option(None, "--config", "-c", help="Config file path"),
    format: str = typer.Option("table", "--format", "-f", help="Output format: table|json"),
    models: str | None = typer.Option(
        None,
        "--models",
        "-m",
        help="Comma-separated deployment names, or 'all' for every chat-capable model. "
        "Runs the evaluation once per model and shows a comparison table.",
    ),
) -> None:
    """Evaluate agent outputs against a bundle of evaluators (SPEC-002 §3.11).

    Sprint 1: Evaluates a pre-populated JSONL dataset (agent responses included)
    against the specified bundle's Foundry evaluators.
    """
    # Resolve config
    try:
        cfg = load_config(config)
    except ConfigError:
        # If no config, use defaults
        cfg = None

    # Resolve dataset path
    dataset_path: str | None = dataset
    if dataset_path is None and cfg:
        # Find default dataset from config
        default_name = cfg.datasets.default
        if default_name:
            for ds in cfg.datasets.entries:
                if ds.name == default_name:
                    dataset_path = ds.path
                    break

    if dataset_path is None:
        console.print(
            "[red]✗[/red] No dataset specified. Use --dataset <path> or configure in agentops.yaml"
        )
        raise typer.Exit(code=2)

    if not Path(dataset_path).exists():
        console.print(f"[red]✗[/red] Dataset not found: {dataset_path}")
        raise typer.Exit(code=2)

    # Resolve bundle
    bundle_name = bundle or (cfg.bundles.default if cfg else "rag_quality")
    project_connection = cfg.foundry.project_connection if cfg else ""
    model_deployment = getattr(cfg.foundry, "model_deployment", "") if cfg else ""
    output_dir = cfg.runs.output_dir if cfg else "agentops/runs"

    # ── Multi-model mode ──
    if models:
        from agentops_toolkit.core.pipeline import (
            EvalProgress,
            list_chat_deployments,
            run_evaluation,
        )
        from agentops_toolkit.models.run import Run

        if not project_connection:
            console.print("[red]✗[/red] --models requires a project_connection in agentops.yaml")
            raise typer.Exit(code=2)

        if models.strip().lower() == "all":
            deployments = list_chat_deployments(project_connection)
            if not deployments:
                console.print("[red]✗[/red] No chat-capable deployments found.")
                raise typer.Exit(code=2)
        else:
            from agentops_toolkit.core.pipeline import resolve_model_deployment

            deployments = []
            for name in models.split(","):
                name = name.strip()
                resolved = resolve_model_deployment(project_connection, name)
                if resolved:
                    deployments.append(resolved)
                else:
                    console.print(f"[yellow]⚠[/yellow] Deployment '{name}' not found, skipping")
            if not deployments:
                console.print("[red]✗[/red] No valid deployments found.")
                raise typer.Exit(code=2)

        console.print(
            f"\n  Comparing [bold]{len(deployments)}[/bold] models against "
            f"bundle [bold]'{bundle_name}'[/bold]\n"
        )
        for dep_name, mdl_name, _ in deployments:
            console.print(f"    • {dep_name} ([cyan]{mdl_name}[/cyan])")
        console.print()

        runs: list[Run] = []
        for dep_name, mdl_name, _ in deployments:
            model_label = f"{dep_name} ({mdl_name})"
            console.print(f"  [blue]▶[/blue] Evaluating with [bold]{model_label}[/bold]...")

            # Per-model progress tracking
            mm_progress: list[tuple[str, str, str, str]] = []

            def _mm_scores_summary(scores: dict[str, float | None]) -> str:
                parts: list[str] = []
                for n, s in scores.items():
                    short = n[:4]
                    parts.append(f"{short}={s:.1f}" if s is not None else f"{short}=—")
                return " ".join(parts) if parts else ""

            def _mm_build_table(total: int) -> Table:
                done = len(mm_progress)
                tbl = Table(
                    title=f"  {model_label}  [dim]({done}/{total})[/dim]",
                    show_edge=True,
                    expand=True,
                )
                tbl.add_column("#", justify="right", style="dim", width=4)
                tbl.add_column("Entry", width=10)
                tbl.add_column("Query", width=40, no_wrap=True, overflow="ellipsis")
                tbl.add_column("Status", width=12)
                tbl.add_column("Scores", no_wrap=True)
                for i, (eid, query, st, sc) in enumerate(mm_progress, 1):
                    icon = {
                        "success": "[green]✓[/green]",
                        "error": "[red]✗[/red]",
                        "skipped": "[yellow]⏭[/yellow]",
                    }.get(st, f"[blue]{st}[/blue]")
                    tbl.add_row(str(i), eid, query, icon, sc)
                remaining = total - done
                for j in range(remaining):
                    idx = done + j + 1
                    if j == 0:
                        tbl.add_row(str(idx), "—", "", "[blue]⠋ ...[/blue]", "")
                    else:
                        tbl.add_row(str(idx), "—", "", "[dim]⏳[/dim]", "")
                return tbl

            mm_live_ref: Live | None = None

            def _mm_on_progress(p: EvalProgress) -> None:
                sc = _mm_scores_summary(p.scores)
                mm_progress.append((p.entry_id, p.query, p.status, sc))
                if mm_live_ref:
                    mm_live_ref.update(_mm_build_table(p.total))

            try:
                with Live(console=console, refresh_per_second=4) as mm_live:
                    mm_live_ref = mm_live
                    mm_live.update(Text(f"⏳ Starting {model_label}..."))
                    run = asyncio.run(
                        run_evaluation(
                            dataset_path=dataset_path,
                            bundle_name=bundle_name,
                            output_dir=output_dir,
                            project_connection=project_connection,
                            model_deployment=dep_name,
                            on_progress=_mm_on_progress,
                        )
                    )
                runs.append(run)
                agg = f"{run.summary.aggregate_score:.2f}" if run.summary and run.summary.aggregate_score else "—"
                console.print(
                    f"    [green]✓[/green] Done — aggregate: {agg}, "
                    f"duration: {run.summary.total_duration_ms:.0f}ms\n"
                    if run.summary
                    else "    [green]✓[/green] Done\n"
                )
            except Exception as e:
                console.print(f"    [red]✗[/red] Failed: {e}\n")

        if len(runs) >= 2:
            _render_comparison_table(runs, console)
        elif len(runs) == 1:
            _render_single_run(runs[0], console)
        else:
            console.print("[red]✗[/red] All model evaluations failed.")
            raise typer.Exit(code=1)

        # Exit code based on threshold
        if cfg and cfg.runs.fail_on_threshold:
            for run in runs:
                any_below = any(
                    er.passed is False for entry in run.entries for er in entry.eval_results
                )
                if any_below:
                    raise typer.Exit(code=1)
        return

    # ── Single-model mode ──
    from agentops_toolkit.core.pipeline import EvalProgress, run_evaluation

    # (entry_id, query, status, scores_summary)
    entry_progress: list[tuple[str, str, str, str]] = []

    def _scores_summary(scores: dict[str, float | None]) -> str:
        """Format scores into a compact summary string."""
        parts: list[str] = []
        for name, score in scores.items():
            short = name[:4]
            if score is not None:
                parts.append(f"{short}={score:.1f}")
            else:
                parts.append(f"{short}=—")
        return " ".join(parts) if parts else ""

    def _build_progress_table(total: int, model_dep: str, model_name: str) -> Table:
        """Build a live-updating progress table."""
        done = len(entry_progress)
        title_parts = [f"Evaluating with bundle [bold]'{bundle_name}'[/bold]"]
        if model_dep:
            model_label = f"{model_dep} ({model_name})" if model_name else model_dep
            title_parts.append(f"[cyan]Model: {model_label}[/cyan]")
        title_parts.append(f"[dim]({done}/{total})[/dim]")
        tbl = Table(title="  ".join(title_parts), show_edge=True, expand=True)
        tbl.add_column("#", justify="right", style="dim", width=4)
        tbl.add_column("Entry", width=10)
        tbl.add_column("Query", width=40, no_wrap=True, overflow="ellipsis")
        tbl.add_column("Status", width=12)
        tbl.add_column("Scores", no_wrap=True)
        for i, (eid, query, st, sc) in enumerate(entry_progress, 1):
            icon = {
                "success": "[green]✓[/green]",
                "error": "[red]✗[/red]",
                "skipped": "[yellow]⏭[/yellow]",
            }.get(st, f"[blue]{st}[/blue]")
            tbl.add_row(str(i), eid, query, icon, sc)
        remaining = total - done
        for j in range(remaining):
            idx = done + j + 1
            if j == 0:
                tbl.add_row(str(idx), "—", "", "[blue]⠋ ...[/blue]", "")
            else:
                tbl.add_row(str(idx), "—", "", "[dim]⏳[/dim]", "")
        return tbl

    live_ref: Live | None = None

    def _on_progress(p: EvalProgress) -> None:
        sc = _scores_summary(p.scores)
        entry_progress.append((p.entry_id, p.query, p.status, sc))
        if live_ref:
            live_ref.update(
                _build_progress_table(p.total, p.model_deployment, p.model_name)
            )

    try:
        with Live(console=console, refresh_per_second=4) as live:
            live_ref = live
            live.update(Text(f"⏳ Starting evaluation with bundle '{bundle_name}'..."))
            run = asyncio.run(
                run_evaluation(
                    dataset_path=dataset_path,
                    bundle_name=bundle_name,
                    output_dir=output_dir,
                    project_connection=project_connection,
                    model_deployment=model_deployment,
                    on_progress=_on_progress,
                )
            )
    except KeyError as e:
        console.print(f"[red]✗[/red] {e}")
        raise typer.Exit(code=1) from e
    except Exception as e:
        console.print(f"[red]✗[/red] Evaluation failed: {e}")
        raise typer.Exit(code=11) from e

    _render_single_run(run, console, format_=format)

    # Exit code based on threshold (FR-054)
    if cfg and cfg.runs.fail_on_threshold:
        any_below = any(er.passed is False for entry in run.entries for er in entry.eval_results)
        if any_below:
            raise typer.Exit(code=1)


# ── Helper: render a single run ──────────────────────────────────────────


def _render_single_run(
    run: object,
    con: Console,
    format_: str = "table",
) -> None:
    """Display results for a single evaluation run."""
    from agentops_toolkit.models.run import Run as RunModel

    assert isinstance(run, RunModel)
    summary = run.summary
    if summary is None:
        con.print("[red]✗[/red] Evaluation produced no results.")
        return

    if format_ == "json":
        con.print_json(run.model_dump_json(indent=2))
        return

    error_count = summary.total_entries - summary.successful_entries - summary.skipped_entries

    model_info = ""
    if run.model_deployment:
        model_info = f"\n  Model: {run.model_deployment}"
        if run.model_name:
            model_info += f" ({run.model_name})"

    con.print()
    con.print(
        Panel(
            f"[green]✓[/green] Run [bold]'{run.name}'[/bold] completed ({run.id})\n"
            f"{model_info}\n"
            f"\n"
            f"  {summary.successful_entries}/{summary.total_entries} entries successful "
            f"({error_count} errors, "
            f"{summary.skipped_entries} skipped)",
            title="[bold]AgentOps Evaluation[/bold]",
            border_style="green",
        )
    )

    if summary.evaluator_scores:
        table = Table(show_header=True, header_style="bold")
        table.add_column("Evaluator", style="cyan")
        table.add_column("Mean", justify="right")
        table.add_column("Median", justify="right")
        table.add_column("Min", justify="right")
        table.add_column("Max", justify="right")
        table.add_column("Pass Rate", justify="right")

        for name, es in sorted(summary.evaluator_scores.items()):
            pass_str = f"{es.pass_rate:.0%}" if es.pass_rate is not None else "—"
            pass_color = (
                "green"
                if es.pass_rate and es.pass_rate >= 0.9
                else ("yellow" if es.pass_rate and es.pass_rate >= 0.7 else "red")
                if es.pass_rate is not None
                else ""
            )
            table.add_row(
                name,
                f"{es.mean_score:.2f}",
                f"{es.median_score:.1f}",
                f"{es.min_score:.1f}",
                f"{es.max_score:.1f}",
                f"[{pass_color}]{pass_str}[/{pass_color}]" if pass_color else pass_str,
            )

        con.print()
        con.print(table)

    con.print()
    agg = f"{summary.aggregate_score:.2f}" if summary.aggregate_score else "—"
    pr = f"{summary.pass_rate:.0%}" if summary.pass_rate is not None else "—"
    con.print(f"  Aggregate score: [bold]{agg}[/bold]")
    con.print(f"  Overall pass rate: [bold]{pr}[/bold]")
    con.print(f"  Duration: {summary.total_duration_ms:.0f}ms")
    con.print()
    con.print(f"  Full report: [bold]agentops report show {run.id}[/bold]")
    con.print()


# ── Helper: render model comparison table ─────────────────────────────────


def _render_comparison_table(
    runs: list,  # list[Run]
    con: Console,
) -> None:
    """Render a side-by-side comparison table for multiple model runs."""
    con.print()
    # Collect all evaluator names across runs
    evaluator_names: list[str] = []
    seen: set[str] = set()
    for run in runs:
        if run.summary and run.summary.evaluator_scores:
            for name in run.summary.evaluator_scores:
                if name not in seen:
                    evaluator_names.append(name)
                    seen.add(name)

    # Build the comparison table
    table = Table(
        title="[bold]Model Comparison[/bold]",
        show_header=True,
        header_style="bold",
        expand=True,
    )
    table.add_column("Evaluator", style="cyan")

    model_labels: list[str] = []
    for run in runs:
        label = run.model_deployment or "default"
        if run.model_name:
            label += f" ({run.model_name})"
        model_labels.append(label)
        table.add_column(label, justify="right")

    # Evaluator rows — mark best with ★
    for ev_name in sorted(evaluator_names):
        means: list[float | None] = []
        for run in runs:
            if run.summary and run.summary.evaluator_scores and ev_name in run.summary.evaluator_scores:
                means.append(run.summary.evaluator_scores[ev_name].mean_score)
            else:
                means.append(None)

        # Find the best (highest) mean for quality evaluators, lowest for safety
        from agentops_toolkit.evaluators.base import _SAFETY_EVALUATORS

        valid = [m for m in means if m is not None]
        if valid:
            best = min(valid) if ev_name in _SAFETY_EVALUATORS else max(valid)
        else:
            best = None

        cells: list[str] = []
        for m in means:
            if m is None:
                cells.append("—")
            elif m == best:
                cells.append(f"[bold green]{m:.2f} ★[/bold green]")
            else:
                cells.append(f"{m:.2f}")
        table.add_row(ev_name, *cells)

    # Separator + aggregate row
    table.add_section()

    # Aggregate scores
    agg_values: list[float | None] = []
    for run in runs:
        agg_values.append(
            run.summary.aggregate_score if run.summary and run.summary.aggregate_score else None
        )
    valid_aggs = [a for a in agg_values if a is not None]
    best_agg = max(valid_aggs) if valid_aggs else None
    agg_cells: list[str] = []
    for a in agg_values:
        if a is None:
            agg_cells.append("—")
        elif a == best_agg:
            agg_cells.append(f"[bold green]{a:.2f} ★[/bold green]")
        else:
            agg_cells.append(f"{a:.2f}")
    table.add_row("[bold]Aggregate[/bold]", *agg_cells)

    # Pass rate
    pr_values: list[float | None] = []
    for run in runs:
        pr_values.append(run.summary.pass_rate if run.summary else None)
    pr_cells: list[str] = []
    for p in pr_values:
        pr_cells.append(f"{p:.0%}" if p is not None else "—")
    table.add_row("[bold]Pass Rate[/bold]", *pr_cells)

    # Duration
    dur_cells: list[str] = []
    for run in runs:
        if run.summary:
            secs = run.summary.total_duration_ms / 1000
            dur_cells.append(f"{secs:.0f}s")
        else:
            dur_cells.append("—")
    table.add_row("[bold]Duration[/bold]", *dur_cells)

    con.print(table)
    con.print()

    # Individual run IDs for follow-up
    for run in runs:
        label = run.model_deployment or "default"
        con.print(f"  {label}: [bold]agentops report show {run.id}[/bold]")
    con.print()


# ── Compare existing runs ─────────────────────────────────────────────


@eval_app.command("compare")
def eval_compare(
    run_ids: list[str] = typer.Argument(
        ...,
        help="Two or more run IDs to compare.",
    ),
    config: str | None = typer.Option(None, "--config", "-c", help="Config file path"),
) -> None:
    """Compare evaluation results across multiple runs side by side.

    Loads persisted runs from disk and displays a comparison table.

    Example::

        agentops eval compare 2026-02-27_a1b2c3d4 2026-02-27_f5e6d7c8
    """
    import json as json_mod
    from agentops_toolkit.models.run import Run

    try:
        cfg = load_config(config)
    except ConfigError:
        cfg = None

    output_dir = Path(cfg.runs.output_dir if cfg else "agentops/runs")

    if len(run_ids) < 2:
        console.print("[red]✗[/red] Need at least 2 run IDs to compare.")
        raise typer.Exit(code=2)

    runs: list[Run] = []
    for rid in run_ids:
        run_json = output_dir / rid / "run.json"
        if not run_json.exists():
            console.print(f"[red]✗[/red] Run not found: {run_json}")
            raise typer.Exit(code=2)
        data = json_mod.loads(run_json.read_text(encoding="utf-8"))
        runs.append(Run.model_validate(data))

    _render_comparison_table(runs, console)