"""RAG / IQ dataset models (Phase 2).

SPEC-008 §6: RAGDatasetEntry with IQ-specific fields.
"""
