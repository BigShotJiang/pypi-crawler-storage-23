"""Unit tests for observability module."""
