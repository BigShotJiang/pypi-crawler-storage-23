"""Fault injection tests for graceful degradation."""
