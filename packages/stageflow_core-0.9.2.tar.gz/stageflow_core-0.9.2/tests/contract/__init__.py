"""Contract tests for stage protocol compliance."""
