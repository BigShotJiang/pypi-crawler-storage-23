from setuptools import setup, find_packages

setup(
    name="django_autoapp",
    version="0.1.0",
    description="A Django app to auto-generate apps with boilerplate code.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Dhiraj Jadav",
    author_email="jadavdhiraj020@gecg28.ac.in",
    url="https://github.com/yourusername/django_autoapp",  # Update with actual GitHub URL
    packages=find_packages(exclude=["tests", "examples"]),
    include_package_data=True,
    install_requires=[
        "Django>=3.0",
        "Jinja2",
    ],
    python_requires=">=3.6",
    classifiers=[
        "Framework :: Django",
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    entry_points={
        "console_scripts": [
            "autoapp = django_autoapp.management.commands.autoapp:main",  # Ensure `main()` exists
        ],
    },
)
