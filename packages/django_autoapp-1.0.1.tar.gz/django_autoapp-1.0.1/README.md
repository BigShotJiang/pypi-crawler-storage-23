# Django AutoApp

Django AutoApp is a package to auto-generate Django apps with boilerplate code.

## Installation

```sh
pip install django-autoapp

how use

```sh
py manage.py autoapp <APP_NAME> <MODEL_NAME>

All done
