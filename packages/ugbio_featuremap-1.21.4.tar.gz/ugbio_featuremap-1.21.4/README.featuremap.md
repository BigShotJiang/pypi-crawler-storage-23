# ugbio_featuremap

This module includes featuremap python scripts and utils for bioinformatics pipelines.
