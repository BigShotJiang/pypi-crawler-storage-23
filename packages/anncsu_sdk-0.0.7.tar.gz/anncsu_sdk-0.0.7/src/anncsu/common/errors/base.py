"""Base error class for ANNCSU SDKs."""

import httpx
from typing import Optional


class AnncsuBaseError(Exception):
    """The base class for all HTTP error responses."""

    message: str
    status_code: int
    body: str
    headers: httpx.Headers
    raw_response: httpx.Response

    def __init__(
        self, message: str, raw_response: httpx.Response, body: Optional[str] = None
    ):
        self.message = message
        self.status_code = raw_response.status_code
        self.body = body if body is not None else raw_response.text
        self.headers = raw_response.headers
        self.raw_response = raw_response

    def __str__(self):
        return self.message
