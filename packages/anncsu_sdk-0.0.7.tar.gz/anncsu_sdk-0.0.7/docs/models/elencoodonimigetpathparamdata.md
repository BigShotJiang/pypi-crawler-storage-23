# ElencoOdonimiGetPathParamData


## Fields

| Field                       | Type                        | Required                    | Description                 | Example                     |
| --------------------------- | --------------------------- | --------------------------- | --------------------------- | --------------------------- |
| `dug`                       | *Optional[str]*             | :heavy_minus_sign:          | N/A                         | AUTOSTRADA                  |
| `denomuff`                  | *Optional[str]*             | :heavy_minus_sign:          | N/A                         | ROMA AEROPORTO DI FIUMICINO |
| `denomloc`                  | *Optional[str]*             | :heavy_minus_sign:          | N/A                         |                             |
| `denomlingua1`              | *Optional[str]*             | :heavy_minus_sign:          | N/A                         |                             |
| `denomlingua2`              | *Optional[str]*             | :heavy_minus_sign:          | N/A                         |                             |