# ElencoaccessiprogPostRequest

search input data


## Fields

| Field              | Type               | Required           | Description        | Example            |
| ------------------ | ------------------ | ------------------ | ------------------ | ------------------ |
| `req`              | *Optional[str]*    | :heavy_minus_sign: | N/A                | elencoaccessiprog  |
| `prognaz`          | *Optional[str]*    | :heavy_minus_sign: | N/A                | 919572             |
| `accparz`          | *Optional[str]*    | :heavy_minus_sign: | N/A                | 42                 |