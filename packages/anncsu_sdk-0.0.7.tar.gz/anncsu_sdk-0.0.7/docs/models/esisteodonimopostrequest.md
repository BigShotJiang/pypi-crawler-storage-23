# EsisteOdonimoPostRequest

search input data


## Fields

| Field              | Type               | Required           | Description        | Example            |
| ------------------ | ------------------ | ------------------ | ------------------ | ------------------ |
| `req`              | *Optional[str]*    | :heavy_minus_sign: | N/A                | esisteodonimo      |
| `codcom`           | *Optional[str]*    | :heavy_minus_sign: | N/A                | H501               |
| `denom`            | *Optional[str]*    | :heavy_minus_sign: | N/A                | VIA ROMA           |