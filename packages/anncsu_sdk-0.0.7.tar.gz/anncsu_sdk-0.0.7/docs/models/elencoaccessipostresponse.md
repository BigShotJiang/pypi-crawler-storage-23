# ElencoAccessiPostResponse

Successful operation


## Fields

| Field                                                                    | Type                                                                     | Required                                                                 | Description                                                              | Example                                                                  |
| ------------------------------------------------------------------------ | ------------------------------------------------------------------------ | ------------------------------------------------------------------------ | ------------------------------------------------------------------------ | ------------------------------------------------------------------------ |
| `res`                                                                    | *Optional[str]*                                                          | :heavy_minus_sign:                                                       | N/A                                                                      | elencoaccessi                                                            |
| `data`                                                                   | List[[models.ElencoAccessiPostData](../models/elencoaccessipostdata.md)] | :heavy_minus_sign:                                                       | N/A                                                                      |                                                                          |