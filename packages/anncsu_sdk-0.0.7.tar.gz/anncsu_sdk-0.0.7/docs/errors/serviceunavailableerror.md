# ServiceUnavailableError

Il server non è disponibile.



## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `status`           | *Optional[str]*    | :heavy_minus_sign: | N/A                |