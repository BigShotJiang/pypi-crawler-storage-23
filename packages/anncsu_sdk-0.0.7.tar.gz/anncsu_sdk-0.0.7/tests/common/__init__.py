"""Tests for anncsu.common package."""
