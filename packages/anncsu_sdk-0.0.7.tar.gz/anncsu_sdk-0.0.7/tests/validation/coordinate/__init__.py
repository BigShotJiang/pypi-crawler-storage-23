"""Validation tests for Coordinate (Aggiornamento coordinate) API."""
