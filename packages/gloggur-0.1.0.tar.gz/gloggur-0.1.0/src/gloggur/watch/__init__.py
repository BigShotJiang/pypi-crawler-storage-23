"""Watch-mode runtime for save-triggered indexing."""

