"""Persistent conversation history across sessions."""

import asyncio
from pydantic_ai import Agent
from sayou.workspace import Workspace
from sayou_pydantic_ai import SayouToolset, SayouMessageHistory

workspace = Workspace(slug="chat-app")


async def chat(conversation_id: str, user_message: str) -> str:
    """Send a message and get a response, with full conversation history."""
    async with workspace:
        history = SayouMessageHistory(
            workspace,
            conversation_id=conversation_id,
            max_messages=50,  # Keep last 50 messages
        )
        agent = Agent(
            "openai:gpt-4o",
            toolsets=[SayouToolset(workspace=workspace)],
            system_prompt="You are a helpful assistant with access to a persistent workspace.",
        )

        # Load previous conversation
        messages = await history.load()

        # Run with history
        result = await agent.run(user_message, message_history=messages)

        # Save updated history
        await history.save(result.all_messages())

        return result.output


async def main():
    conv_id = "project-alpha"

    # First message
    reply = await chat(conv_id, "Let's plan the API. We need user auth and a REST API.")
    print(f"Assistant: {reply}\n")

    # Second message — agent remembers the conversation
    reply = await chat(conv_id, "What did we discuss so far?")
    print(f"Assistant: {reply}\n")

    # List all conversations
    async with workspace:
        history = SayouMessageHistory(workspace)
        convs = await history.list_conversations()
        print(f"Stored conversations: {convs}")


if __name__ == "__main__":
    asyncio.run(main())
