"""Multi-session research agent that builds knowledge over time."""

import asyncio
from pydantic_ai import Agent
from sayou.workspace import Workspace
from sayou_pydantic_ai import SayouToolset

# Share a workspace across sessions
workspace = Workspace(slug="research")


async def session_1():
    """First session: gather initial findings."""
    async with workspace:
        agent = Agent("openai:gpt-4o", toolsets=[SayouToolset(workspace=workspace)])

        await agent.run(
            "Research the current state of WebAssembly. "
            "Save your findings as structured notes in the workspace under research/wasm/."
        )
        print("Session 1 complete — findings saved.")


async def session_2():
    """Second session: build on previous research."""
    async with workspace:
        agent = Agent("openai:gpt-4o", toolsets=[SayouToolset(workspace=workspace)])

        await agent.run(
            "Read the WebAssembly research notes from the workspace. "
            "Then write a summary comparing WASM to native code performance. "
            "Save it as research/wasm/summary.md."
        )
        print("Session 2 complete — summary written.")

        # Verify the files exist
        result = await workspace.glob("research/wasm/**")
        print(f"Files in workspace: {[f['path'] for f in result['files']]}")


async def main():
    await session_1()
    await session_2()


if __name__ == "__main__":
    asyncio.run(main())
