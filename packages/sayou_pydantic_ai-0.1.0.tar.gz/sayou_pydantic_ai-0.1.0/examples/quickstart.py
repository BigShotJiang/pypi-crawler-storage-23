"""Quickstart: give any Pydantic AI agent persistent workspace memory."""

import asyncio
from pydantic_ai import Agent
from sayou_pydantic_ai import SayouToolset

agent = Agent("openai:gpt-4o", toolsets=[SayouToolset()])


async def main():
    result = await agent.run("Save a note about our meeting: we decided to use PostgreSQL for the new service")
    print(result.output)

    result = await agent.run("What decisions have we made?")
    print(result.output)


if __name__ == "__main__":
    asyncio.run(main())
