"""Shared test fixtures for sayou-pydantic-ai."""

import pytest
import pytest_asyncio

from sayou.workspace import Workspace


@pytest_asyncio.fixture
async def workspace():
    """In-memory Workspace (SQLite) for testing."""
    ws = Workspace(database_url="sqlite+aiosqlite://")
    async with ws:
        yield ws
