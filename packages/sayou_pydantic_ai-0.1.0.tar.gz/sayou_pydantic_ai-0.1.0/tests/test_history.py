"""Tests for SayouMessageHistory."""

import pytest

from pydantic_ai.messages import (
    ModelMessage,
    ModelRequest,
    ModelResponse,
    UserPromptPart,
    TextPart,
)

from sayou_pydantic_ai.history import SayouMessageHistory


def _make_messages() -> list[ModelMessage]:
    """Create a sample conversation."""
    return [
        ModelRequest(parts=[UserPromptPart(content="Hello")]),
        ModelResponse(parts=[TextPart(content="Hi there!")]),
        ModelRequest(parts=[UserPromptPart(content="How are you?")]),
        ModelResponse(parts=[TextPart(content="I'm doing well, thanks!")]),
    ]


class TestSayouMessageHistory:
    async def test_load_empty(self, workspace):
        history = SayouMessageHistory(workspace, "test-conv")
        messages = await history.load()
        assert messages == []

    async def test_save_and_load(self, workspace):
        history = SayouMessageHistory(workspace, "test-conv")
        original = _make_messages()

        await history.save(original)
        loaded = await history.load()

        assert len(loaded) == len(original)
        assert isinstance(loaded[0], ModelRequest)
        assert isinstance(loaded[1], ModelResponse)

    async def test_roundtrip_content(self, workspace):
        history = SayouMessageHistory(workspace, "test-conv")
        original = _make_messages()

        await history.save(original)
        loaded = await history.load()

        # Check content is preserved
        req = loaded[0]
        assert isinstance(req, ModelRequest)
        assert req.parts[0].content == "Hello"

        resp = loaded[1]
        assert isinstance(resp, ModelResponse)
        assert resp.parts[0].content == "Hi there!"

    async def test_max_messages(self, workspace):
        history = SayouMessageHistory(workspace, "truncated", max_messages=2)
        messages = _make_messages()  # 4 messages

        await history.save(messages)
        loaded = await history.load()

        assert len(loaded) == 2
        # Should keep the last 2
        req = loaded[0]
        assert isinstance(req, ModelRequest)
        assert req.parts[0].content == "How are you?"

    async def test_clear(self, workspace):
        history = SayouMessageHistory(workspace, "to-clear")
        await history.save(_make_messages())

        await history.clear()
        loaded = await history.load()
        assert loaded == []

    async def test_multiple_conversations(self, workspace):
        h1 = SayouMessageHistory(workspace, "conv-1")
        h2 = SayouMessageHistory(workspace, "conv-2")

        await h1.save([ModelRequest(parts=[UserPromptPart(content="Hello from 1")])])
        await h2.save([ModelRequest(parts=[UserPromptPart(content="Hello from 2")])])

        loaded1 = await h1.load()
        loaded2 = await h2.load()

        assert len(loaded1) == 1
        assert len(loaded2) == 1
        assert loaded1[0].parts[0].content == "Hello from 1"
        assert loaded2[0].parts[0].content == "Hello from 2"

    async def test_list_conversations(self, workspace):
        h1 = SayouMessageHistory(workspace, "alpha")
        h2 = SayouMessageHistory(workspace, "beta")

        await h1.save(_make_messages())
        await h2.save(_make_messages())

        convs = await h1.list_conversations()
        assert "alpha" in convs
        assert "beta" in convs

    async def test_key_format(self, workspace):
        history = SayouMessageHistory(workspace, "my-conv")
        assert history.key == "pydantic_ai:history:my-conv"

    async def test_overwrite_existing(self, workspace):
        history = SayouMessageHistory(workspace, "overwrite")

        # Save initial
        await history.save([ModelRequest(parts=[UserPromptPart(content="First")])])

        # Overwrite
        await history.save([
            ModelRequest(parts=[UserPromptPart(content="Second")]),
            ModelResponse(parts=[TextPart(content="Reply")]),
        ])

        loaded = await history.load()
        assert len(loaded) == 2
        assert loaded[0].parts[0].content == "Second"
