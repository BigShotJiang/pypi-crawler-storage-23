"""Tests for SayouToolset."""

import pytest
from unittest.mock import MagicMock

from sayou.workspace import Workspace
from sayou_pydantic_ai.toolset import SayouToolset, DEFAULT_TOOLS, ALL_TOOLS, _dispatch


@pytest.fixture
def mock_ctx():
    """Minimal mock RunContext for get_tools calls."""
    ctx = MagicMock()
    ctx.deps = None
    return ctx


class TestToolsetInit:
    def test_default_tools(self):
        ts = SayouToolset()
        assert ts._tools == DEFAULT_TOOLS

    def test_custom_tools(self):
        ts = SayouToolset(tools={"read", "write"})
        assert ts._tools == {"read", "write"}

    def test_all_tools(self):
        ts = SayouToolset(tools=ALL_TOOLS)
        assert "delete" in ts._tools

    def test_unknown_tool_raises(self):
        with pytest.raises(ValueError, match="Unknown tools"):
            SayouToolset(tools={"nonexistent"})

    def test_id_property(self):
        assert SayouToolset().id == "sayou"
        assert SayouToolset(id="custom").id == "custom"
        assert SayouToolset(id=None).id is None


class TestGetTools:
    async def test_returns_default_tools(self, mock_ctx):
        ts = SayouToolset()
        tools = await ts.get_tools(mock_ctx)
        assert len(tools) == len(DEFAULT_TOOLS)
        for name in DEFAULT_TOOLS:
            assert f"workspace_{name}" in tools

    async def test_custom_prefix(self, mock_ctx):
        ts = SayouToolset(tool_prefix="ws")
        tools = await ts.get_tools(mock_ctx)
        assert "ws_read" in tools
        assert "workspace_read" not in tools

    async def test_no_prefix(self, mock_ctx):
        ts = SayouToolset(tool_prefix="")
        tools = await ts.get_tools(mock_ctx)
        assert "read" in tools
        assert "workspace_read" not in tools

    async def test_tool_definitions_have_schemas(self, mock_ctx):
        ts = SayouToolset()
        tools = await ts.get_tools(mock_ctx)
        for name, tool in tools.items():
            assert tool.tool_def.description is not None
            assert tool.tool_def.parameters_json_schema is not None
            assert tool.tool_def.parameters_json_schema["type"] == "object"

    async def test_subset_tools(self, mock_ctx):
        ts = SayouToolset(tools={"read", "write"})
        tools = await ts.get_tools(mock_ctx)
        assert len(tools) == 2
        assert "workspace_read" in tools
        assert "workspace_write" in tools


class TestDispatch:
    """Test _dispatch against a real in-memory Workspace."""

    async def test_write_and_read(self, workspace):
        result = await _dispatch(workspace, "write", {
            "path": "test.md",
            "content": "# Hello\nWorld",
        })
        assert "test.md" in result
        assert "v1" in result

        result = await _dispatch(workspace, "read", {"path": "test.md"})
        assert "# Hello" in result
        assert "World" in result

    async def test_list(self, workspace):
        await workspace.write("docs/a.md", "content a")
        await workspace.write("docs/b.md", "content b")

        result = await _dispatch(workspace, "list", {"path": "/docs"})
        assert "2 files" in result

    async def test_search(self, workspace):
        await workspace.write("notes/meeting.md", "---\ntopic: design\n---\nDesign review")
        result = await _dispatch(workspace, "search", {"query": "design"})
        assert "meeting.md" in result

    async def test_grep(self, workspace):
        await workspace.write("code.py", "def hello():\n    print('world')\n")
        result = await _dispatch(workspace, "grep", {"query": "hello"})
        assert "hello" in result

    async def test_grep_no_match(self, workspace):
        await workspace.write("code.py", "def hello():\n    pass\n")
        result = await _dispatch(workspace, "grep", {"query": "nonexistent"})
        assert "No matches" in result

    async def test_glob(self, workspace):
        await workspace.write("docs/a.md", "a")
        await workspace.write("docs/b.txt", "b")
        result = await _dispatch(workspace, "glob", {"pattern": "**/*.md"})
        assert "a.md" in result
        assert "b.txt" not in result

    async def test_glob_no_match(self, workspace):
        result = await _dispatch(workspace, "glob", {"pattern": "**/*.xyz"})
        assert "No files" in result

    async def test_kv_set_get(self, workspace):
        await _dispatch(workspace, "kv", {"action": "set", "key": "k1", "value": '"hello"'})
        result = await _dispatch(workspace, "kv", {"action": "get", "key": "k1"})
        assert "hello" in result

    async def test_kv_list(self, workspace):
        await _dispatch(workspace, "kv", {"action": "set", "key": "a:1", "value": '"x"'})
        await _dispatch(workspace, "kv", {"action": "set", "key": "a:2", "value": '"y"'})
        result = await _dispatch(workspace, "kv", {"action": "list", "prefix": "a:"})
        assert "2 keys" in result

    async def test_kv_delete(self, workspace):
        await _dispatch(workspace, "kv", {"action": "set", "key": "tmp", "value": '"z"'})
        result = await _dispatch(workspace, "kv", {"action": "delete", "key": "tmp"})
        assert "Deleted" in result

    async def test_kv_not_found(self, workspace):
        result = await _dispatch(workspace, "kv", {"action": "get", "key": "nope"})
        assert "not found" in result

    async def test_delete(self, workspace):
        await workspace.write("to-delete.md", "bye")
        result = await _dispatch(workspace, "delete", {"path": "to-delete.md"})
        assert "Deleted" in result

    async def test_history(self, workspace):
        await workspace.write("versioned.md", "v1 content")
        await workspace.write("versioned.md", "v2 content")
        result = await _dispatch(workspace, "history", {"path": "versioned.md"})
        assert "2 versions" in result

    async def test_unknown_tool(self, workspace):
        with pytest.raises(ValueError, match="Unknown tool"):
            await _dispatch(workspace, "nonexistent", {})


class TestToolsetLifecycle:
    async def test_auto_create_workspace(self):
        """SayouToolset creates its own Workspace when none given."""
        ts = SayouToolset(database_url="sqlite+aiosqlite://")
        async with ts:
            assert ts.workspace is not None
            result = await _dispatch(ts.workspace, "write", {
                "path": "test.md",
                "content": "hello",
            })
            assert "test.md" in result
        # After exit, workspace should be cleaned up
        assert ts.workspace is None

    async def test_external_workspace(self, workspace):
        """SayouToolset uses provided Workspace without closing it."""
        ts = SayouToolset(workspace=workspace)
        async with ts:
            result = await _dispatch(ts.workspace, "write", {
                "path": "ext.md",
                "content": "external",
            })
            assert "ext.md" in result
        # External workspace should NOT be closed
        assert ts.workspace is workspace
