"""Integration tests: Agent + SayouToolset end-to-end."""

import pytest
from unittest.mock import MagicMock

from pydantic_ai import Agent
from pydantic_ai.models.test import TestModel

from sayou.workspace import Workspace
from sayou_pydantic_ai import SayouToolset, SayouMessageHistory


class TestAgentIntegration:
    async def test_agent_with_toolset(self, workspace):
        """Agent with SayouToolset can be constructed and run."""
        toolset = SayouToolset(workspace=workspace)
        agent = Agent(TestModel(call_tools=[]), toolsets=[toolset])

        result = await agent.run("Hello")
        assert result.output is not None

    async def test_toolset_tools_registered(self, workspace):
        """Verify tools are properly registered with the agent."""
        toolset = SayouToolset(workspace=workspace)
        mock_ctx = MagicMock()
        mock_ctx.deps = None

        tools = await toolset.get_tools(mock_ctx)
        tool_names = set(tools.keys())

        assert "workspace_write" in tool_names
        assert "workspace_read" in tool_names
        assert "workspace_search" in tool_names
        assert "workspace_list" in tool_names
        assert "workspace_grep" in tool_names
        assert "workspace_glob" in tool_names
        assert "workspace_kv" in tool_names

    async def test_call_tool_through_toolset(self, workspace):
        """Call a tool directly through the toolset interface."""
        toolset = SayouToolset(workspace=workspace)
        mock_ctx = MagicMock()
        mock_ctx.deps = None

        async with toolset:
            tools = await toolset.get_tools(mock_ctx)
            write_tool = tools["workspace_write"]

            result = await toolset.call_tool(
                "workspace_write",
                {"path": "integration.md", "content": "# Integration Test"},
                mock_ctx,
                write_tool,
            )
            assert "integration.md" in result
            assert "v1" in result

            # Read it back
            read_tool = tools["workspace_read"]
            result = await toolset.call_tool(
                "workspace_read",
                {"path": "integration.md"},
                mock_ctx,
                read_tool,
            )
            assert "Integration Test" in result

    async def test_agent_calls_write_tool(self, workspace):
        """Agent actually calls the write tool end-to-end."""
        toolset = SayouToolset(workspace=workspace)
        agent = Agent(
            TestModel(call_tools=["workspace_write"]),
            toolsets=[toolset],
        )

        result = await agent.run("Write a note")
        assert result.output is not None


class TestHistoryWithAgent:
    async def test_history_save_load_roundtrip(self, workspace):
        """Save agent messages and reload them."""
        toolset = SayouToolset(workspace=workspace)
        agent = Agent(TestModel(call_tools=[]), toolsets=[toolset])
        history = SayouMessageHistory(workspace, "test-session")

        # First run
        result = await agent.run("Hello, save something")
        await history.save(result.all_messages())

        # Reload
        messages = await history.load()
        assert len(messages) > 0

        # Second run with history
        result2 = await agent.run("Continue", message_history=messages)
        assert result2.output is not None

        # Save extended history
        await history.save(result2.all_messages())
        final_messages = await history.load()
        assert len(final_messages) >= len(messages)
