"""Conversation history persistence via sayou's KV store."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

from pydantic import TypeAdapter
from pydantic_ai.messages import ModelMessage

if TYPE_CHECKING:
    from sayou.workspace import Workspace

_messages_adapter = TypeAdapter(list[ModelMessage])

_KEY_PREFIX = "pydantic_ai:history"


class SayouMessageHistory:
    """Persist Pydantic AI conversation messages in a sayou workspace KV store.

    Usage::

        async with Workspace() as ws:
            history = SayouMessageHistory(ws, conversation_id="project-alpha")

            # Load previous messages
            messages = await history.load()

            # Run agent with history
            result = await agent.run("Continue our discussion", message_history=messages)

            # Save updated history
            await history.save(result.all_messages())
    """

    def __init__(
        self,
        workspace: Workspace,
        conversation_id: str = "default",
        *,
        max_messages: int | None = None,
        ttl_seconds: int | None = None,
    ):
        """Initialize message history.

        Args:
            workspace: Sayou workspace instance (must be open).
            conversation_id: Unique identifier for this conversation.
            max_messages: If set, only keep the last N messages.
            ttl_seconds: If set, messages expire after this many seconds.
        """
        self._workspace = workspace
        self._conversation_id = conversation_id
        self._max_messages = max_messages
        self._ttl_seconds = ttl_seconds

    @property
    def key(self) -> str:
        return f"{_KEY_PREFIX}:{self._conversation_id}"

    async def load(self) -> list[ModelMessage]:
        """Load conversation messages from the KV store.

        Returns an empty list if no messages are stored.
        """
        result = await self._workspace.kv_get(self.key)
        if not result["found"]:
            return []

        raw = result["value"]
        if isinstance(raw, str):
            raw = json.loads(raw)

        return _messages_adapter.validate_python(raw)

    async def save(self, messages: list[ModelMessage]) -> None:
        """Save conversation messages to the KV store.

        If max_messages is set, only the last N messages are kept.
        """
        if self._max_messages is not None and len(messages) > self._max_messages:
            messages = messages[-self._max_messages:]

        data = _messages_adapter.dump_python(messages, mode="json")
        await self._workspace.kv_set(
            self.key,
            json.dumps(data),
            ttl_seconds=self._ttl_seconds,
        )

    async def clear(self) -> None:
        """Delete this conversation's history."""
        await self._workspace.kv_delete(self.key)

    async def list_conversations(self) -> list[str]:
        """List all conversation IDs stored in this workspace."""
        result = await self._workspace.kv_list(prefix=_KEY_PREFIX)
        prefix_len = len(_KEY_PREFIX) + 1  # +1 for the colon
        return [item["key"][prefix_len:] for item in result["items"]]
