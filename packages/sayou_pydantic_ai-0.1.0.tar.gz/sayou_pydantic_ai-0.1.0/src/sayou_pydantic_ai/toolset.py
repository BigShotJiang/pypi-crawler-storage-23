"""Sayou workspace as a Pydantic AI toolset."""

from __future__ import annotations

import json
from dataclasses import replace
from typing import Any, Callable, Awaitable

from pydantic_ai import RunContext
from pydantic_ai.tools import ToolDefinition
from pydantic_ai.toolsets.abstract import AbstractToolset, ToolsetTool
from pydantic_core import SchemaValidator, core_schema

from sayou.workspace import Workspace

_ANY_VALIDATOR = SchemaValidator(schema=core_schema.any_schema())

# Default tools included in v1
DEFAULT_TOOLS = frozenset({"write", "read", "list", "search", "grep", "glob", "kv"})

# All available tools
ALL_TOOLS = frozenset({
    "write", "read", "list", "search", "grep", "glob", "kv",
    "delete", "history", "links", "chunks",
})

# Tool definitions: name -> (description, parameters_json_schema)
TOOL_DEFS: dict[str, tuple[str, dict[str, Any]]] = {
    "write": (
        "Write a file to the workspace. Creates the file if it doesn't exist, "
        "or creates a new version if it does. Content can include YAML frontmatter "
        "for structured metadata.",
        {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path in the workspace"},
                "content": {"type": "string", "description": "File content to write"},
                "source": {
                    "type": "string",
                    "description": "Source identifier (e.g. agent name)",
                    "default": None,
                },
            },
            "required": ["path", "content"],
        },
    ),
    "read": (
        "Read a file from the workspace. Returns content with frontmatter metadata. "
        "Use token_budget to control output size.",
        {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to read"},
                "token_budget": {
                    "type": "integer",
                    "description": "Max tokens of content to return",
                    "default": 4000,
                },
                "version": {
                    "type": "integer",
                    "description": "Specific version number to read",
                    "default": None,
                },
            },
            "required": ["path"],
        },
    ),
    "list": (
        "List files and subfolders in a workspace folder.",
        {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Folder path to list",
                    "default": "/",
                },
                "recursive": {
                    "type": "boolean",
                    "description": "List recursively",
                    "default": False,
                },
            },
        },
    ),
    "search": (
        "Search files by frontmatter metadata filters and/or full-text query.",
        {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Full-text search query",
                    "default": None,
                },
                "filters": {
                    "type": "object",
                    "description": "Frontmatter key-value filters",
                    "default": None,
                },
            },
        },
    ),
    "grep": (
        "Search file contents for a text query. Returns matching lines with context.",
        {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search string"},
                "path_pattern": {
                    "type": "string",
                    "description": "Glob filter for file paths (e.g. **/*.md)",
                    "default": None,
                },
                "context_lines": {
                    "type": "integer",
                    "description": "Lines of context around each match",
                    "default": 2,
                },
            },
            "required": ["query"],
        },
    ),
    "glob": (
        "Find files matching a glob pattern. "
        "Supports: ** (any path depth), * (any name), ? (single char).",
        {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Glob pattern (e.g. **/*.md, research/**)",
                },
            },
            "required": ["pattern"],
        },
    ),
    "kv": (
        "Key-value store for configuration, caches, and temporary data. "
        "Actions: get, set, list, delete.",
        {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["get", "set", "list", "delete"],
                    "description": "KV operation to perform",
                },
                "key": {"type": "string", "description": "Key name", "default": None},
                "value": {
                    "type": "string",
                    "description": "Value to store (JSON string)",
                    "default": None,
                },
                "ttl_seconds": {
                    "type": "integer",
                    "description": "Time-to-live in seconds",
                    "default": None,
                },
                "prefix": {
                    "type": "string",
                    "description": "Key prefix for list action",
                    "default": None,
                },
            },
            "required": ["action"],
        },
    ),
    "delete": (
        "Delete a file from the workspace (soft-delete). Version history is preserved.",
        {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path to delete"},
            },
            "required": ["path"],
        },
    ),
    "history": (
        "Get version history for a file. Returns versions with timestamps and sizes.",
        {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path"},
                "limit": {
                    "type": "integer",
                    "description": "Max versions to return",
                    "default": 20,
                },
            },
            "required": ["path"],
        },
    ),
    "links": (
        "Get outgoing and incoming links for a file. "
        "Optionally add a link by passing add_target.",
        {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path"},
                "add_target": {
                    "type": "string",
                    "description": "Target file path to link to",
                    "default": None,
                },
                "link_type": {
                    "type": "string",
                    "description": "Link type: reference, parent, depends_on, related, supersedes",
                    "default": "reference",
                },
            },
            "required": ["path"],
        },
    ),
    "chunks": (
        "Get chunk outline for a file: headings, line ranges, token estimates. "
        "Pass chunk_index to read a specific chunk.",
        {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path"},
                "chunk_index": {
                    "type": "integer",
                    "description": "Chunk index to read",
                    "default": None,
                },
            },
            "required": ["path"],
        },
    ),
}


class SayouToolset(AbstractToolset):
    """Pydantic AI toolset that wraps a sayou Workspace.

    Gives agents persistent file storage, search, and key-value state.

    Usage::

        from pydantic_ai import Agent
        from sayou_pydantic_ai import SayouToolset

        agent = Agent("openai:gpt-4o", toolsets=[SayouToolset()])
        result = await agent.run("Save a note about our meeting")
    """

    def __init__(
        self,
        workspace: Workspace | None = None,
        *,
        tools: set[str] | None = None,
        tool_prefix: str = "workspace",
        id: str | None = "sayou",
        **workspace_kwargs: Any,
    ):
        """Initialize the toolset.

        Args:
            workspace: An existing Workspace instance. If None, one is created
                automatically (SQLite at ~/.sayou/).
            tools: Set of tool names to expose. Defaults to the 7 core tools.
                Use ``ALL_TOOLS`` to expose everything including delete.
            tool_prefix: Prefix for tool names (e.g. "workspace_read").
                Set to "" for unprefixed names.
            id: Unique ID for the toolset. Defaults to "sayou".
            **workspace_kwargs: Passed to ``Workspace()`` if no workspace is given.
        """
        self._workspace = workspace
        self._workspace_kwargs = workspace_kwargs
        self._owns_workspace = workspace is None
        self._tools = tools or DEFAULT_TOOLS
        self._prefix = f"{tool_prefix}_" if tool_prefix else ""
        self._id = id

        # Validate tool names
        unknown = self._tools - ALL_TOOLS
        if unknown:
            raise ValueError(f"Unknown tools: {unknown}. Available: {sorted(ALL_TOOLS)}")

    @classmethod
    def from_deps(
        cls,
        accessor: Callable[[Any], Workspace] | Callable[[Any], Awaitable[Workspace]],
        *,
        tools: set[str] | None = None,
        tool_prefix: str = "workspace",
        id: str | None = "sayou",
    ) -> _DepsToolset:
        """Create a toolset that extracts the Workspace from agent dependencies.

        Usage::

            @dataclass
            class MyDeps:
                workspace: Workspace

            toolset = SayouToolset.from_deps(lambda d: d.workspace)
            agent = Agent("openai:gpt-4o", deps_type=MyDeps, toolsets=[toolset])
        """
        return _DepsToolset(
            accessor=accessor,
            tools=tools,
            tool_prefix=tool_prefix,
            id=id,
        )

    @property
    def id(self) -> str | None:
        return self._id

    @property
    def workspace(self) -> Workspace | None:
        return self._workspace

    async def __aenter__(self):
        if self._owns_workspace and self._workspace is None:
            self._workspace = Workspace(**self._workspace_kwargs)
        if self._workspace is not None:
            await self._workspace.open()
        return self

    async def __aexit__(self, *args):
        if self._owns_workspace and self._workspace is not None:
            await self._workspace.close()
            self._workspace = None

    async def get_tools(self, ctx: RunContext) -> dict[str, ToolsetTool]:
        tools = {}
        for name in sorted(self._tools):
            if name not in TOOL_DEFS:
                continue
            desc, schema = TOOL_DEFS[name]
            prefixed_name = f"{self._prefix}{name}"
            tool_def = ToolDefinition(
                name=prefixed_name,
                description=desc,
                parameters_json_schema=schema,
            )
            tools[prefixed_name] = ToolsetTool(
                toolset=self,
                tool_def=tool_def,
                max_retries=1,
                args_validator=_ANY_VALIDATOR,
            )
        return tools

    async def call_tool(
        self, name: str, tool_args: dict[str, Any], ctx: RunContext, tool: ToolsetTool,
    ) -> Any:
        # Strip prefix to get the base tool name
        base_name = name
        if self._prefix and name.startswith(self._prefix):
            base_name = name[len(self._prefix):]

        ws = self._workspace
        if ws is None:
            raise RuntimeError("Workspace not initialized. Use the toolset as an async context manager.")

        return await _dispatch(ws, base_name, tool_args)


class _DepsToolset(AbstractToolset):
    """Internal toolset that extracts Workspace from agent dependencies at runtime."""

    def __init__(
        self,
        accessor: Callable,
        *,
        tools: set[str] | None = None,
        tool_prefix: str = "workspace",
        id: str | None = "sayou",
    ):
        self._accessor = accessor
        self._tools = tools or DEFAULT_TOOLS
        self._prefix = f"{tool_prefix}_" if tool_prefix else ""
        self._id = id

    @property
    def id(self) -> str | None:
        return self._id

    async def get_tools(self, ctx: RunContext) -> dict[str, ToolsetTool]:
        tools = {}
        for name in sorted(self._tools):
            if name not in TOOL_DEFS:
                continue
            desc, schema = TOOL_DEFS[name]
            prefixed_name = f"{self._prefix}{name}"
            tool_def = ToolDefinition(
                name=prefixed_name,
                description=desc,
                parameters_json_schema=schema,
            )
            tools[prefixed_name] = ToolsetTool(
                toolset=self,
                tool_def=tool_def,
                max_retries=1,
                args_validator=_ANY_VALIDATOR,
            )
        return tools

    async def call_tool(
        self, name: str, tool_args: dict[str, Any], ctx: RunContext, tool: ToolsetTool,
    ) -> Any:
        import asyncio
        import inspect

        base_name = name
        if self._prefix and name.startswith(self._prefix):
            base_name = name[len(self._prefix):]

        result = self._accessor(ctx.deps)
        if inspect.isawaitable(result):
            ws = await result
        else:
            ws = result

        return await _dispatch(ws, base_name, tool_args)


async def _dispatch(ws: Workspace, tool_name: str, args: dict[str, Any]) -> Any:
    """Dispatch a tool call to the appropriate Workspace method."""
    if tool_name == "write":
        result = await ws.write(args["path"], args["content"], source=args.get("source"))
        return (
            f"Written {result['path']} v{result['version_number']} "
            f"({result['size_bytes']} bytes)"
        )

    elif tool_name == "read":
        result = await ws.read(
            args["path"],
            token_budget=args.get("token_budget", 4000),
            version=args.get("version"),
        )
        lines = [f"{result['path']} [v{result['version_number']} | {result['size_bytes']} bytes]"]
        if result.get("truncated"):
            lines.append("(truncated to fit token budget)")
        if result.get("frontmatter"):
            lines.append("Frontmatter:")
            for k, v in result["frontmatter"].items():
                lines.append(f"  {k}: {v}")
        lines.append("")
        lines.append(result["content"])
        return "\n".join(lines)

    elif tool_name == "list":
        result = await ws.list(
            args.get("path", "/"),
            recursive=args.get("recursive", False),
        )
        lines = [f"{result['path']} ({result['file_count']} files)"]
        if result["subfolders"]:
            lines.append("Subfolders:")
            for sf in result["subfolders"]:
                lines.append(f"  - {sf}")
        if result.get("index_content"):
            lines.append("")
            lines.append(result["index_content"])
        return "\n".join(lines)

    elif tool_name == "search":
        result = await ws.search(
            query=args.get("query"),
            filters=args.get("filters"),
        )
        lines = [f"{result['total']} results found"]
        for item in result["results"]:
            fm_preview = ""
            if item.get("frontmatter"):
                pairs = [f"{k}={v}" for k, v in list(item["frontmatter"].items())[:3]]
                fm_preview = f" ({', '.join(pairs)})"
            lines.append(f"  - {item['path']}{fm_preview}")
        return "\n".join(lines)

    elif tool_name == "grep":
        result = await ws.grep(
            args["query"],
            path_pattern=args.get("path_pattern"),
            context_lines=args.get("context_lines", 2),
        )
        if not result["results"]:
            return f"No matches for '{args['query']}'"
        lines = [f"{result['total_files']} files match '{args['query']}'"]
        for file_result in result["results"]:
            lines.append(f"\n{file_result['path']} ({file_result['match_count']} matches)")
            for m in file_result["matches"]:
                lines.append(m["context"])
        return "\n".join(lines)

    elif tool_name == "glob":
        result = await ws.glob(args["pattern"])
        if not result["files"]:
            return f"No files matching '{args['pattern']}'"
        lines = [f"{result['total']} files matching '{args['pattern']}'"]
        for f in result["files"]:
            lines.append(f"  - {f['path']}")
        return "\n".join(lines)

    elif tool_name == "kv":
        action = args["action"]
        if action == "get":
            result = await ws.kv_get(args["key"])
            if not result["found"]:
                return f"Key not found: {args['key']}"
            return f"{args['key']} = {json.dumps(result['value'])}"
        elif action == "set":
            value = args.get("value")
            try:
                parsed = json.loads(value) if isinstance(value, str) else value
            except (json.JSONDecodeError, TypeError):
                parsed = value
            await ws.kv_set(args["key"], parsed, ttl_seconds=args.get("ttl_seconds"))
            return f"Set {args['key']}"
        elif action == "delete":
            result = await ws.kv_delete(args["key"])
            return f"Deleted {args['key']}" if result["deleted"] else f"Key not found: {args['key']}"
        elif action == "list":
            result = await ws.kv_list(prefix=args.get("prefix"))
            if not result["items"]:
                return "No keys found"
            lines = [f"{result['total']} keys"]
            for item in result["items"]:
                val_preview = json.dumps(item["value"])
                if len(val_preview) > 60:
                    val_preview = val_preview[:57] + "..."
                lines.append(f"  {item['key']} = {val_preview}")
            return "\n".join(lines)
        else:
            return f"Unknown KV action: {action}. Use get, set, delete, or list."

    elif tool_name == "delete":
        result = await ws.delete(args["path"])
        return f"Deleted {result['path']}"

    elif tool_name == "history":
        result = await ws.history(args["path"], limit=args.get("limit", 20))
        lines = [f"{result['path']} ({result['total']} versions)"]
        for v in result["versions"]:
            lines.append(
                f"  v{v['version_number']}: {v['content_hash'][:12]}... "
                f"({v['size_bytes']} bytes) by {v['created_by']}"
            )
        return "\n".join(lines)

    elif tool_name == "links":
        if args.get("add_target"):
            result = await ws.add_link(
                args["path"], args["add_target"],
                link_type=args.get("link_type", "reference"),
            )
            return f"Linked {result['source_path']} -> {result['target_path']} ({result['link_type']})"
        result = await ws.links(args["path"])
        lines = [f"Links for {result['path']}"]
        if result["outgoing"]:
            for lnk in result["outgoing"]:
                lines.append(f"  -> {lnk['target_path']} ({lnk['link_type']})")
        if result["incoming"]:
            for lnk in result["incoming"]:
                lines.append(f"  <- {lnk['source_path']} ({lnk['link_type']})")
        if not result["outgoing"] and not result["incoming"]:
            lines.append("  No links")
        return "\n".join(lines)

    elif tool_name == "chunks":
        if args.get("chunk_index") is not None:
            result = await ws.chunk(args["path"], args["chunk_index"])
            heading = f" — {result['heading']}" if result.get("heading") else ""
            return (
                f"{result['path']} chunk [{result['chunk_index']}]{heading}\n"
                f"Lines {result['line_start']}-{result['line_end']}\n\n"
                f"{result['content']}"
            )
        result = await ws.chunks(args["path"])
        if not result["chunks"]:
            return f"No chunks for {result['path']}"
        lines = [f"{result['path']} ({result['total']} chunks)"]
        for c in result["chunks"]:
            heading = f" — {c['heading']}" if c.get("heading") else ""
            lines.append(
                f"  [{c['chunk_index']}] lines {c['line_start']}-{c['line_end']}"
                f" (~{c['token_estimate']} tokens){heading}"
            )
        return "\n".join(lines)

    else:
        raise ValueError(f"Unknown tool: {tool_name}")
