"""Tests for evaluation harness modules."""
