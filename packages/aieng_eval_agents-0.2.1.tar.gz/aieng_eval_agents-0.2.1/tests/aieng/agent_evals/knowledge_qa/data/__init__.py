"""Tests for knowledge QA data module."""
