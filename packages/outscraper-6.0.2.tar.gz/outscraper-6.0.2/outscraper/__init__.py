from .client import OutscraperClient

ApiClient = OutscraperClient

__all__ = [
    'OutscraperClient',
    'ApiClient',
]
