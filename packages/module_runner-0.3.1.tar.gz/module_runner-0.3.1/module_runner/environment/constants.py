PYPROJECT_TOML = "pyproject.toml"
REQUIREMENTS_TXT = "requirements.txt"
MAIN_PY = "main.py"
VENV_DIR = ".venv"

PACKAGE_JSON = "package.json"
MAIN_JS = "main.js"
NODE_MODULES_DIR = "node_modules"

MAIN_SH = "main.sh"
