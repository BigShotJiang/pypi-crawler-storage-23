from xsection._benchmarks import load_shape
import pytest 


def test_c01_centroid():
    shape = load_shape("C01")
    shape = shape.translate(-shape.centroid)
    A   = shape.elastic.A
    Iy  = shape.elastic.Iy
    Iz  = shape.elastic.Iz
    Iyz = shape.elastic.Iyz
    J   = shape.elastic.J

    sy, sz = shape._analysis.shear_center()

    assert A   == pytest.approx(    58.8, rel=0.1)
    assert Iy  == pytest.approx(    8039, rel=0.1)
    assert Iz  == pytest.approx(     564, abs=0.3)
    assert Iyz == pytest.approx(     0.0, abs=1e-8)
    assert J   == pytest.approx(      35, abs=1.0)
    assert sy  == pytest.approx( -6.0779, abs=0.06)
    assert sz  == pytest.approx(     0.0, abs=5e-5)


def test_r01_centroid():
    shape = load_shape("R01")
    shape = shape.translate(-shape.centroid)
    d = shape.d 
    b = shape.b
    A = shape.elastic.A
    Iy = shape.elastic.Iy
    Iz = shape.elastic.Iz
    Iyz = shape.elastic.Iyz

    assert A   == pytest.approx(      d*b, rel=1e-3)
    assert Iz  == pytest.approx(d*b**3/12, rel=1e-3)
    assert Iy  == pytest.approx(d**3*b/12, rel=1e-3)
    assert Iyz == pytest.approx(      0.0, abs=1e-8)

