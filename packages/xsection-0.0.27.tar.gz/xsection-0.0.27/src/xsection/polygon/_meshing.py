import numpy as np 

def _mesh_cytri(sections, mesh_size=0.05, min_angle=25.0, coarse=False, quadratic=False):
    """
    Generate a triangular mesh with material interfaces using Shewchuk's Triangle.
    """
    import cytriangle as triangle
    import numpy as np
    import shapely

    vertex_map = {}
    points         = []
    facets         = []
    holes          = []
    control_points = []
    mesh_sizes     = []
    z_indices      = []

    def get_vertex_index(pt):
        key = tuple(np.round(pt, 12))  # prevent numerical duplicates
        if key in vertex_map:
            return vertex_map[key]
        idx = len(points)
        points.append(key)
        vertex_map[key] = idx
        return idx
    
    polygons = [
        shapely.Polygon(section.exterior(), section.interior()) 
        for section in sections
    ]

    for i,(section,polygon) in enumerate(zip(sections, polygons)):
        ext       = section.exterior()
        interiors = section.interior()
        material  = section.material

        z_indices.append(section.z)

        # Exterior
        ext_idx = [get_vertex_index(p) for p in ext]
        facets.extend([(ext_idx[i], ext_idx[(i + 1) % len(ext_idx)]) 
                        for i in range(len(ext_idx))])

        # Holes
        for hole,hole_poly in zip(interiors, polygon.interiors):
            rh = shapely.Polygon(hole_poly).representative_point()

            if any(shapely.contains(p,rh) for p in polygons if p != polygon):
                continue

            hole_idx = [get_vertex_index(p) for p in hole]
            facets.extend([
                (hole_idx[i], hole_idx[(i + 1) % len(hole_idx)]) for i in range(len(hole_idx))
            ])
            holes.append(tuple(rh.coords[0]))


        # Control point for region interior
        control_points.append(polygon.representative_point().coords[0]) #tuple(np.mean(ext, axis=0)))

        # Region mesh size
        if isinstance(mesh_size, dict):
            mesh_sizes.append(mesh_size.get(material, 0.05))

        elif isinstance(mesh_size, list):
            if len(mesh_size) != len(sections):
                raise ValueError("mesh_size list must match number of sections")
            mesh_sizes.append(mesh_size[i])

        else:
            mesh_sizes.append(mesh_size)

    # Prepare Triangle input
    tri = {
        "vertices": points,
        "segments": facets,
        "holes": holes,
        "regions": [
            [cp[0], cp[1], z, mesh_sizes[i]]
            for i, (cp,z) in enumerate(zip(control_points, z_indices))
        ]
    }

    for i, r in enumerate(tri["regions"]):
        if len(r) != 4 or not all(isinstance(v, (float, int)) for v in r):
            raise ValueError(f"Bad region entry at index {i}: {r}")

    opts = "pA" if coarse else f"pq{min_angle:.1f}Aa"

    if quadratic:
        # Quadratic (6-node) triangles
        opts += "o2"

    data = triangle.triangulate(tri, opts)


    points = np.array(data["vertices"], dtype=np.double)

    # Quadratic triangles are 6-node triangles (3 vertices + 3 mid-side nodes)
    # Meshio uses "triangle6" for this
    element = "triangle6" if quadratic else "triangle"
    cells = [(element, np.array(data["triangles"], dtype=np.int32))]
    if quadratic:
        # reorder mid-side nodes to standard convention
        for i in range(len(cells[0][1])):
            cells[0][1][i] = cells[0][1][i][[np.array([0, 1, 2, 5, 3, 4])]]

    # Optional cell data (e.g., region markers)
    cell_data = {}
    if "triangle_attributes" in data:
        triangle_attr = np.array(data["triangle_attributes"], dtype=int).flatten()
        cell_data = {"region": [triangle_attr]}

    import meshio
    return meshio.Mesh(
        points=points,
        cells=cells,
        cell_data=cell_data
    )
