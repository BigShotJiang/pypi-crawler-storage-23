#
# Claudio M. Perez
#
import warnings
from ._base import SectionTransformations
class Mesh:
    nodes: list
    elems: list

class Material:
    pass


class WarpingSection(SectionTransformations):

    def __init__(self,
                 model: "TriangleModel",
                 warp_twist=True,
                 warp_shear=True
        ):

        self._w_model = model

        self._warp_shear:bool = warp_shear
        self._warp_twist:bool = warp_twist

    #
    # Virtual
    #
    @property
    def model(self):
        if self._w_model is None:
            raise ValueError("Model not initialized")
        return self._w_model

    @property
    def _analysis(self):
        # if self._is_composite:
        #     raise ValueError("Warping analysis not implemented for composite sections")
        from xsection.analysis.warping import WarpingAnalysis
        
        if not hasattr(self, "_warp_analysis") or self._warp_analysis is None:
            self._warp_analysis = WarpingAnalysis(self)

        return self._warp_analysis 

    #
    # Final
    #
    @classmethod
    def from_meshio(cls, mesh, **kwds):
        from shps.frame.solvers import TriangleModel
        return WarpingSection(TriangleModel.from_meshio(mesh), **kwds)

    
    def exterior(self):
        return self._w_model.exterior()

    def interior(self):
        return self._w_model.interior()
    
    @property
    def centroid(self):
        return self._analysis.centroid()
    
    @property 
    def depth(self):
        return max(self.model.nodes[:,1]) - min(self.model.nodes[:,1])

    def torsion_warping(self):
        warnings.warn("torsion_warping is deprecated.")
        return self._analysis.warping()
    
    def cnn(self):
        return self._analysis.cnn()
    def cnm(self):
        return self._analysis.cnm()
    def cnv(self):
        return self._analysis.cnv()
    def cmm(self, **kwds):
        return self._analysis.cmm(**kwds)
    def cmw(self):
        return self._analysis.cmw()
    def cmv(self):
        return self._analysis.cmv()
    def cww(self):
        return self._analysis.cww()
    def cvv(self):
        return self._analysis.cvv()
    def css(self):
        return self._analysis.css()

    def create_trace(self, nu: float=None, form=None, u=None):

        if hasattr(self, "_poisson") and self._poisson is not None:
            assert nu is None, "Poisson's ratio already set"
            nu = self._poisson
        return self._analysis.create_trace(nu=nu, form=form)

    def summary(self, shear=False, format=None):
        if format is None:
            return self._summary_console(shear=shear)
        elif format == "tex":
            pass

    def _summary_console(self, shear=False, sv=None):
        s = ""
        tol=1e-13
        clip = lambda x: x if abs(x)>tol else 0.0

        A = self._analysis.cnn()[0,0]

        cnw = self._analysis.cnw()
        cnm = self._analysis.cnm()
        cmm = self.cmm()
        cmw = self.cmw()
        cnv = self._analysis.cnv(shear=shear)

        cmv = self._analysis.cmv()
        cvv = self.cvv()

        # Compute centroid
        Qy = cnm[0,1] # int z
        Qz = cnm[2,0] # int y
        cx, cy = float(Qz/A), float(Qy/A)
        cx, cy = map(clip, (cx, cy))

        # Irw = self.torsion.cmv()[0,0]

        sx, sy = self._analysis.shear_center()
        # print(sx, sy)
        sx, sy = map(clip, (sx, sy))
        ky = f""
        kz = f""

        cww = self._analysis.cww()
        # Translate to shear center to get standard Iww
        Iww = self.translate([-sx, -sy])._analysis.cww()[0,0]

        Isv = self._analysis.torsion_constant()

        s += f"""
  Block                              x            y           z           yz
  [nn]    Area               {A          :>10.4}   {ky}, {kz}
  [nm]    Centroid           {0.0        :>10.4}   {cx         :>10.4}, {cy         :>10.4}
  [nw|v]                     {cnw[0,0]/A :>10.4} | {cnv[1,0]/A :>10.4}, {cnv[2,0]/A :>10.4}

  [mm]    Flexural moments   {cmm[0,0]   :>10.4}   {cmm[1,1]   :>10.4}, {cmm[2,2]   :>10.4}, {cmm[1,2] :>10.4}
  [mv|w]                     {cmv[0,0]   :>10.4} | {cmw[1,0]   :>10.4}, {cmw[2,0]   :>10.4}


  [ww]    Warping constant   {cww[0,0] :>10.4}  ({Iww      :>10.4} at S.C.)
  [vv]    Bishear            {cvv[0,0] :>10.4}


          Shear center       {0.0        :>10.4}   {sx         :>10.4}, {sy :>10.4}
          Torsion constant   {Isv :>10.3f}
          Principal angle   {self._principal_rotation():>10.4f} rad
        """

        if self.material is not None:
            s += f"  E: {self.material.E}\n"
            s += f"  G: {self.material.G}\n"
            # s += f"  ν: {self.material.nu}\n\n"

        s += self._analysis._summarize_mesh()

        return s


    # def translate(self, offset):
    #     return WarpingSection(self.model.translate(offset)) 

    def rotate(self, angle=None, principal=None):
        if angle is not None:
            return WarpingSection(self.model.rotate(angle)) 


    def _principal_rotation(self):
        from shps.rotor import log
        import numpy as np
        import numpy.linalg as la
        # P = [[0,1,0],[1,0,0],[1,0,0]]
        I = self._analysis.cmm()

        vals, vecs = la.eig(I[1:,1:])
        # sort = vals.argsort()
        # Q = vecs[:,sort]
        Q = np.eye(3)
        Q[1:,1:] = vecs
        # Q = np.array([q for q in reversed(Q)])
        theta = log(Q)
        assert np.isclose(theta[1], 0.0), theta
        assert np.isclose(theta[2], 0.0), theta
        return float(theta[0])

    @property
    def elastic(self):
        from xsection import ElasticConstants
        import numpy as np
        y, z = self.model.nodes.T
        e = np.ones(y.shape)
        # try:
        #     k, _ = self._analysis.shear_factor_romano()
        # except:
        #     k = (1.0, 1.0)

        A = self.model.inertia(e, e, weight=None)
        return ElasticConstants(
            A  =A,
            # Ay =float(k[0]*A),
            # Az =float(k[1]*A),
            Iyz=self.model.inertia(y, z, weight=None),
            Iy =self.model.inertia(z, z, weight=None),
            Iz =self.model.inertia(y, y, weight=None),
            J = float(self._analysis.torsion_constant()),
        )


    def create_fibers(self,
                      group=None,
                      warp_type: str = None,
                    #   origin=None, 
                      center=None, 
                    #   shear_model=None,
                    #   poisson: float=None,
                    #   warp=None, 
                    #   shear=None,
                      axes=None,
                      exclude=None,
                      **kwds
        ):
        """
        Create fibers for a finite element simulation.

        Parameters
        ----------
        warp_type: str, optional
            Type of warping to compute. Options are:
            - "UT": Uniform torsion (no shear warping)
            - "UE": Uniform energetic formulation
            - "UG": Uniform geometric formulation
            - "NV": Non-uniform
            - "NR": Non-uniform with Reissner equilibrium
        """
        import warnings

        shear   = kwds.get("shear", None)
        warp    = kwds.get("warp", None)
        poisson = kwds.get("poisson", None)
        shear_model = kwds.get("shear_model", None)
        origin = kwds.get("origin", None)

        if shear_model is not None:
            warnings.warn("shear_model is deprecated")
        if origin is not None:
            warnings.warn("origin is deprecated")
        if poisson is not None:
            warnings.warn("poisson is deprecated, set self._poisson instead")
            self._poisson = poisson


        if warp_type is None and (shear is not None or warp is not None):
            if shear is not None or warp is not None:
                warnings.warn("warp_type not specified, inferring from warp and shear")
            if warp is None:
                warp = True
            if shear is None:
                shear = False
            
            if warp and not shear:
                warp_type = "UT"
            elif warp and shear:
                warp_type = "SV"
            
        else:
            if warp is not None or shear is not None:
                raise ValueError("warp_type cannot be used with warp or shear")

        if warp_type in {"UT","NT"}:
            have_twist_a = False
            have_twist_v = True
            have_shear_v = False
        elif warp_type in {"UE", "UG", "SV"}:
            have_twist_a = False
            have_twist_v = True
            have_shear_v = True
        elif warp_type == "NR":
            have_twist_a = True
            have_twist_v = True
            have_shear_v = False
        elif warp_type is None:
            have_twist_a = False 
            have_twist_v = False
            have_shear_v = False
        else:
            raise ValueError(f"Unknown warp_type {warp_type}")

        if not isinstance(group, set) and group is not None:
            group = self._find_group_patches(group)
        if isinstance(group, int):
            group = set(group)

        if axes is not None:
            shape = self.rotate(principal=axes)
            if len(axes) == 1: # axes == "z":
                # old z was turned into y
                exclude = axes
            yield from shape.create_fibers(origin=origin, 
                                           center=center, 
                                           warp=warp, 
                                           group=group, 
                                           exclude=exclude)
            return


        if origin is not None:
            if origin == "centroid":
                shape = self.translate(-self.centroid)
            elif origin == "shear-center":
                shape = self.translate(-self._analysis.shear_center())
            else:
                shape = self.translate(-origin)

            yield from shape.create_fibers(warp=warp, shear=shear, 
                                           center=center, 
                                           origin=None,
                                           shear_model=shear_model,
                                           group=group, axes=axes,
                                           exclude=exclude)
            return

        model = self.model


        if not have_twist_v:
            pass
        elif center is None:
            twist = self._analysis
            w_twist_sv = self._analysis.solve_twist()
        elif not isinstance(center, str):
            twist = self.translate(center)._analysis
            w_twist_sv = twist.solve_twist()
        elif center == "centroid":
            twist = self.translate(-self.centroid)._analysis
            w_twist_sv = twist.solve_twist()
        elif center == "shear-center":
            w_twist_sv = self._analysis.warping()
            twist = self._analysis


        if have_shear_v:
            if shear_model is not None:
                shear_array = shear_model.fiber_array()
            else:
                shear_array = self._analysis.solve_shear(nu=getattr(self, "_poisson", 0.0))
        else:
            shear_array = None
        
        if have_twist_a:
            w_twist_a = self._analysis.solve_twist_ra()


        for mf in self.model.fibers:
            elem = model.elems[mf.cell]
            if group is not None and elem.group not in group:
                continue

            yz = mf.coord
            fiber = dict(area=mf.area)
            
            fiber["y"] = float(yz[0])
            fiber["z"] = float(yz[1])

            # fiber["warn-2d-z"] = True
            if have_twist_v:
                fiber["warp"] = [
                    [float(twist.model.cell_solution(mf, w_twist_sv)),
                     *map(float, twist.model.cell_gradient(mf,  w_twist_sv))],
                    [0, 0, 0],
                    [0, 0, 0]
                ]
                if have_shear_v:
                    fiber["warp"][1] = [
                        model.cell_solution(mf, shear_array[0]), 
                        *map(float, model.cell_gradient(mf,  shear_array[0]))  
                    ]
                    fiber["warp"][2] = [
                        model.cell_solution(mf, shear_array[1]), 
                        *map(float, model.cell_gradient(mf,  shear_array[1]))  
                    ]
                elif have_twist_a:
                    fiber["warp"][1] = [
                        model.cell_solution(mf, w_twist_a), 
                        *map(float, model.cell_gradient(mf,  w_twist_a))  
                    ]

            yield fiber
    

    def _create_fibers(self, model, warp: list, group=None):

        if not isinstance(group, set) and group is not None:
            group = self._find_group_patches(group)
        if isinstance(group, int):
            group = set(group)
    
        for mf in model.fibers:
            elem = model.elems[mf.cell]
            if group is not None and elem.group not in group:
                continue

            yz = mf.coord
            fiber = dict(area=mf.area)
            
            fiber["y"] = float(yz[0])
            fiber["z"] = float(yz[1])

            if len(warp) > 0:
                fiber["warp"] = [
                    [float(model.cell_solution(mf, warp[0])),
                     *map(float, model.cell_gradient(mf,  warp[0]))],
                    [0, 0, 0],
                    [0, 0, 0]
                ]
                for i in range(1, len(warp)):
                    fiber["warp"][i] = [
                        model.cell_solution(mf, warp[i]), 
                        *map(float, model.cell_gradient(mf,  warp[i]))  
                    ]

            yield fiber

    def _repr_html_(self):
        import veux
        from veux.viewer import Viewer
        m = self.model
        a = veux.create_artist((m.nodes, m.cells()), ndf=1)
        a.draw_surfaces()
        viewer = Viewer(a,hosted=False,standalone=False)
        html = viewer.get_html()
        return html



    def send_xara(self, model, type, tag,
                  material=None, warp=True, shear=False):
        warnings.warn("send_xara is deprecated, use xara.Section instead")

        if type == "Elastic":
            cmm = self.cmm()
            cnn = self.cnn()
            cnv = self.cnv()
            cnm = self.cnm()
            cmw = self.cmw()
            cww = self.cww()
            cvv = self.cvv()
            A = cnn[0,0]
            model.section("ElasticFrame", tag,
                            E=material["E"],
                            G=material["G"],
                            A=cnn[0,0],
                            # Ay=1*A,
                            # Az=1*A,
                            # Qy=cnm[0,1],
                            # Qz=cnm[2,0],
                            Iy=cmm[1,1],
                            Iz=cmm[2,2],
                            J =self._analysis.torsion_constant(),
                            Cw= cww[0,0],
                            Ry= cnv[1,0],
                            Rz= cnv[2,0],
                            Sy= cvv[1,1],
                            Sz= cvv[2,2]
            )
        else:
            if isinstance(material,int):
                mtag = material 
            else:
                mtag = 1
                if "name" in material:
                    mtype = material["name"]
                    del material["name"]
                elif "type" in material:
                    mtype = material["type"]
                    del material["type"]
                else:
                    mtype = "ElasticIsotropic"

                model.material(mtype, mtag, **material)

            model.section("ShearFiber", tag, GJ=0)

            for fiber in self.create_fibers(warp=warp, shear=shear):
                model.fiber(**fiber, material=mtag, section=tag)
