def _create_xara_model(shape):
    import xara
    smodel = shape.model
    xmodel = xara.Model(ndm=2, ndf=1)


    for cell in smodel.elems:
        smat = 



    

def solve_shear(shape):
    xmodel = _create_xara_model(shape)
