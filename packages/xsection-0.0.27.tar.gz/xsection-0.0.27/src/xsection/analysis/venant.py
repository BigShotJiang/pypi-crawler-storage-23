import warnings
import numpy as np
from shps.solve.poisson import poisson_neumann, HilbertLoad, PoissonLoad
from shps.solve.poisson2 import poisson_neumann
from shps.solve.boundary import find_boundaries, Monomial2D, integrate_boundary


try:
    from numba import njit as jit 
    from numba import prange
    jit(lambda x: x**2)(1.0)  # test if numba is available

except:
    prange = range
    def jit(*_, **__):
        def _decorator(func):
            return func
        return _decorator


@jit
def _hat(r):
    return np.array([[    0,-r[1], r[0]],
                     [ r[1],    0,    0],
                     [-r[0],    0,    0]])


oneS = np.eye(2)

@jit
def _shear_poisson(r, rc, nu):
    devR = np.outer(r, r) - 0.5*np.dot(r, r)*oneS
    return -nu*(devR - np.outer(r, rc))

_i = np.array([[1],[0],[0]], dtype=float)
_ix = np.array([[0,-1],[1,0]], dtype=float)


def shift_inertia(r, centroid, A):
    return 2*A*np.dot(r, centroid)*oneS \
        - A*(np.outer(r, centroid) + np.outer(centroid, r)) \
        + A*(np.dot(r, r)*oneS - np.outer(r, r))


def _rotation_average_fiber(u, model, center=None, weight:float=None, balance=None):
    w  = weight
    ro = center
    if balance is not None:
        I = balance
    else:
        I = np.zeros((3,3))
        for fiber in model.fibers:
            r = fiber.coord - ro
            rx = _hat(r)
            dA = fiber.area*w
            I -= rx@rx*dA

    rxu = 0 # np.zeros(3)
    if callable(u):
        for fiber in model.fibers:
            r = fiber.coord - ro
            ur = u(fiber)
            rx = _hat(r)
            dA = fiber.area*w
            rxu += rx @ np.array(ur) * dA
    else:
        for fiber in model.fibers:
            r = fiber.coord - ro
            rx = _hat(r)
            ur = model.elems[fiber.cell].interp(u, fiber.coord)
            dA = fiber.area*w
            rxu += rx @ np.array(ur) * dA
    return np.linalg.solve(I, rxu)


def _find_poisson(shape, nu, materials):
    if nu is not None:
        return nu
    elif not shape._is_composite:
        if shape.material:
            return shape.material["E"]/(2*shape.material["G"]) - 1
        elif hasattr(shape, "_poisson"):
            return shape._poisson
    elif hasattr(shape, "_shear_poisson"):
        return shape._shear_poisson
    else:
        raise ValueError("Poisson's ratio must be provided for composite sections")


class SaintVenantSectionAnalysis:
    def __init__(self, shape, model=None, nu=None, materials=None, mode=None, shift=True, classical: bool=True):
        # In mesh mode, polynomial integrals are computed using
        # barycentric formulas over the mesh.
        # In fiber mode, polynomial integrals are computed using
        # simple quadrature over the fiber array.
        if mode is None:
            mode = "fiber"
        
        self._mode = mode

        self.shape = shape

        nu = _find_poisson(shape, nu, materials)


        if model is None:
            model = shape.model #create_model(materials=materials)

        self._model = model
        self._nu = nu
        self._classical = classical

        # Whether to apply the trace shift to the fiber array
        self._shift = shift

        A = 0
        EA = 0
        GA = 0
        for fiber in model.fibers:
            EA += model.fiber_weight(fiber, weight="e")
            GA += model.fiber_weight(fiber, weight="g")
            A  += fiber.area

        self._G = GA/A #1.0
        # self._E = EA/A #1.0 #self._G*2*(1 + nu)
        self._A  = A
        self._EA = EA
        self._GA = GA
        self._GJ = None
        self._centroid = None
        self._twist_center = None

        self._shear_warp = None 
        self._twist_warp = None
        self._twist_shape_mixed = None


    def summary(self)->str:
        return f"""
        r_psi = {self.iesan_center()}\n

        """
    
    def create_trace(self, form):
        from .trace import _EnergeticTrace, _GeometricTrace
        if form is None or form in {"energetic", "natural", "UE"}:
            return _EnergeticTrace(self.shape, nu=self._nu, sv=self)
        elif form in {"geometric", "average", "UG"}:
            return _GeometricTrace(self.shape, nu=self._nu, sv=self)
        else:
            raise ValueError(f"Unknown trace '{form}'")
        

    def _solve_shear(self):
        if self._shear_warp is not None:
            return self._shear_warp

        # Solve for \WarpShearIesan

        r  = self._model.nodes.T
        rc = self.centroid()

        nu = self._nu

        edge_order = self._model._order

        # Form boundary loads
        f = np.zeros((2,len(self._model.nodes)))
        conn = np.array([elem.nodes for elem in self._model.elems])
        nodes = self._model.nodes
        boundary_nodes = set()
        # NOTE
        for boundary in find_boundaries(conn):
            boundary_nodes.update(boundary)
            # d' = e_y
            f[0] -= integrate_boundary(nodes, boundary,
                                gy_terms=[
                                    # z^2 - y^2
                                    Monomial2D(0,2,  nu/2), Monomial2D(2,0, -nu/2), Monomial2D(1,0, rc[0]*nu)
                                ],
                                gz_terms=[
                                    Monomial2D(1,1,-nu), Monomial2D(0,1, rc[0]*nu)
                                ],
                                edge_order=edge_order)
            # d' = e_z
            f[1] -= integrate_boundary(nodes, boundary,
                                gz_terms=[
                                    # y^2 - z^2
                                    Monomial2D(0,2, -nu/2), Monomial2D(2,0,  nu/2), Monomial2D(0,1, rc[1]*nu)
                                ],
                                gy_terms=[
                                    Monomial2D(1,1,-nu), Monomial2D(1,0, rc[1]*nu)
                                ],
                                edge_order=edge_order)

        # Find an interior node to fix
        fix_node = 0
        for i in range(len(self._model.nodes)):
            if i not in boundary_nodes:
                fix_node = i
                break
                
        # Solve BVP
        u = np.array([
            poisson_neumann(
                self._model.nodes,
                self._model.elems,
                fix_node=fix_node,
                force=f[i],
                loads=[
                    # Note: (2*nu-c) == -2.0
                    HilbertLoad((r[i]-rc[i])*2.0),
                ]
            ) for i in (0,1)
        ])


        A = self._A
        for i in range(2):
            cnw = self.cnw(u[i])[0,0]
            u[i] -= cnw/A


        self._shear_warp = u
        return u


    def solve_shear(self):
        if self._shear_warp is not None:
            return self._shear_warp
        elif not self.shape._is_composite:
            return self._solve_shear()

        # Solve for \WarpShearIesan

        rc = self.centroid()

        nu = self._nu


        @jit
        def _plane_shape(r, rc, nu):
            devR = np.outer(r, r) - 0.5*np.dot(r, r)*oneS
            return -nu*(devR - np.outer(r, rc))

        @jit
        def _plane_strain(i, r):
            return -nu*oneS*(1 if i==3 else r[i])


        # Form loads
        f = np.zeros((2,len(self._model.nodes)))
        ones = np.zeros(len(self._model.nodes))
        for cell in self._model.elems:
            G  = self._model.cell_weight(cell, weight="g")
            C1 = 2*G*(1-nu)/(1-2*nu)
            C2 = 2*G*nu/(1-2*nu)
            for r, dA in cell.fibers:
                Pi = _plane_shape(r, rc, nu) #
                pibar = np.trace(_plane_strain(3, r))
                for node in cell.nodes:
                    for i in (0,1):
                        pi = np.trace(_plane_strain(i, r)) - pibar*rc[i]
                        ones[node] = 1.0
                        w = cell.interp(ones, r)
                        dw = cell.gradient(ones, r)
                        ones[node] = 0.0
                        f[i,node] += C1*dA*w*(r[i]-rc[i]) + C2*dA*w*pi - G*dA*np.dot(dw, Pi[:,i])

                
        # Solve BVP
        u = np.array([
            poisson_neumann(
                model=self._model,
                force=f[i],
                measure="g"
            ) for i in (0,1)
        ])


        A = self._A
        for i in range(2):
            cnw = self.cnw(u[i])[0,0]
            u[i] -= cnw/A


        self._shear_warp = u
        return u

    def cnw(self, ua=None, measure=None)->float:
        # Normalizing Constant = -warpIntegral / A
        c = 0.0
        model = self._model
        if ua is not None:
            for fiber in model.fibers:
                dA = model.fiber_weight(fiber, weight=measure) #fiber.area*self.model.cell_weight(fiber.cell, weight=measure)
                c += model.elems[fiber.cell].interp(ua, fiber.coord)*dA

        return np.array([[ c , 0.0, 0.0],
                         [0.0, 0.0, 0.0],
                         [0.0, 0.0, 0.0]])

    # def cnw(self, ua=None)->float:
    #     # Normalizing Constant = -warpIntegral / A
    #     c = 0.0

    #     if ua is not None:
    #         for fiber in self._model.fibers:
    #             c += self._model.elems[fiber.cell].interp(ua, fiber.coord)*fiber.area

    #     return np.array([[ c , 0.0, 0.0],
    #                      [0.0, 0.0, 0.0],
    #                      [0.0, 0.0, 0.0]])
    
    def solve_twist(self):
        """
        We should have 
          self._model.inertia(np.ones(nf), warp) ~ 0.0
        """
        if self._twist_warp is not None:
            return self._twist_warp

        y, z = self._model.nodes.T
        u = poisson_neumann(
            model=self._model,
            loads=[PoissonLoad( z, -y, measure="g")],
            measure="g"
        )

        cnw = self.cnw(u, measure="e")[0,0]

        u -= cnw/self._EA

        self._twist_warp = u
        return u


    def solve_mixed_twist(self):
        if self._twist_shape_mixed is not None:
            return self._twist_shape_mixed

        w = self.solve_twist()

        u = poisson_neumann(
            model=self._model,
            loads = [HilbertLoad(w, measure="e")],
            measure="g"
        )
        u -= self.cnw(u, measure="e")[0,0]/self._EA
        self._twist_shape_mixed = -u
        return self._twist_shape_mixed


    def css(self):
        u = self.solve_mixed_twist()
        w = self.solve_twist()
        return -self._model.inertia(u,w, weight="e")


    def cmm(self, center=None, weight=None):

        if center is None or center == "origin":
            ro = np.zeros(2)
        elif center in {"axial", "centroid"}:
            ro = self.centroid()
            if False: #weight == "e":
                HF = self.moment_tensor(center=center, weight="e")
                Io = HF[0,0] + HF[1,1]
                ix = np.array([[0,0,0],[0,0,-1],[0,1,0]],dtype=float)
                ioi = np.array([[1,0,0],[0,0,0],[0,0,0]],dtype=float)
                I = np.zeros((3,3))
                I[1:,1:] = -_ix@HF@_ix 
                I += Io*ioi
                return I
        else:
            raise ValueError(f"Unknown center location '{center}'")

        model = self._model

        if self._mode == "mesh":
            y,z = model.nodes.T - ro[:,np.newaxis]
            izy = model.inertia(z,y)
            izz = model.inertia(y,y)
            iyy = model.inertia(z,z)
            return np.array([[izz+iyy,   0,    0],
                             [   0   , iyy, -izy],
                             [   0   ,-izy,  izz]])*w
        else:
            I = np.zeros((3,3))
            for fiber in model.fibers:
                r = fiber.coord - ro
                rx = _hat(r)
                dA = model.fiber_weight(fiber, weight=weight)
                I -= rx@rx*dA
            return I

    # def double_moments(self, weight):
    #     model = self._model
    #     I = np.zeros((3,3))
    #     for fiber in model.fibers:
    #         r = fiber.coord
    #         rx = _hat(r)
    #         dA = model.fiber_weight(fiber, weight=weight)
    #         I -= rx@rx*dA
    #     return I

    def axial_rigidity(self)->float:
        """Compute axial rigidity EA.
        """
        return self._EA

    def twist_rigidity(self):
        """Compute St. Venant's constant.
        """
        if self._GJ is not None:
            return self._GJ
        weight = "g"

        u  = self.solve_twist()
        model = self._model

        GJ = 0.0
        ix = np.array([[0, -1],[1, 0]], dtype=float)
        for fiber in model.fibers:
            r = fiber.coord
            dA = model.fiber_weight(fiber, weight=weight)

            # ∇Ψ (2×2): Du[j] = ∇Ψ_j, so Du = ∇Ψ
            Du = model.elems[fiber.cell].gradient(u, fiber.coord)

            # r × i
            ixr = ix@r

            # (∇Ψ + Π') @ (r × i)
            GJ += (Du @ ixr + np.dot(r,r))*dA

        self._GJ = float(GJ)
        return self._GJ

    def moment_tensor(self, center=None, weight="e"):
        """
        integrate r ⊗ r over the cross-section
        """
        assert weight == "e"

        ix = np.array([[0.0,-1.0],[1.0,0.0]])
        model = self._model
        if self._mode == "mesh":
            if center is None:
                model = self._model
            elif center in {"axial", "centroid"}:
                xc = self.centroid()
                model = self._warping.translate(-xc).model
            else:
                raise ValueError(f"Unknown center location '{center}'")

            y,z = model.nodes.T
            izy = model.inertia(z,y, weight=weight)
            izz = model.inertia(y,y, weight=weight)
            iyy = model.inertia(z,z, weight=weight)
            return  -ix@np.array([[  iyy, -izy],
                                  [ -izy,  izz]])@ix

        else:#if  center in {"axial", "centroid"} and weight == "e":
            # Here we use the Saint-Venant identity: 
            # \int E r⊗r dA = \int G ( (∇Ψ)^T + \Pi_b ) dA
            # weight = "g"
            nu = self._nu 
            u = self.solve_shear()
            rc = self.centroid()
            self._irr = 0 # TODO
            HF = np.zeros((2,2))
            for fiber in model.fibers:
                dA = model.fiber_weight(fiber, weight="g")
                r = fiber.coord
                Du = np.array([
                    model.elems[fiber.cell].gradient(u[0], fiber.coord),
                    model.elems[fiber.cell].gradient(u[1], fiber.coord)
                ])
                W = _shear_poisson(r, rc, nu)
                HF += (Du.T + W)*dA

            # HF += shift_inertia(0.0, rc, self._A)
            return HF

        # else: # center == "origin":
        #     cmm = self.cmm(center=center, weight=weight)
        #     return -ix@cmm[1:,1:]@ix

    def iesan_matrix(self, E=None, G=None):
        def vec(x):
            x = np.asarray(x, dtype=float)
            return x.reshape(2, 1)
        # E = self._E if E is None else E
        # G = self._G if G is None else G

        val = lambda x: np.array([[float(x)]], dtype=float)
        o   = np.zeros((2,1))
        O   = np.zeros((2,2))
        EA  = self._EA
        EArc = self.moment_vector() #self.axial_center()
        GJ   = self.twist_rigidity() #G*self.torsion_constant(weight="g")
        # EJc = E*self.moment_tensor(center="centroid", weight="e")
        # # EJo = E*self.moment_tensor(center="origin", weight="e")

        EJc = self.moment_tensor(center="centroid", weight="e")
        # EJo = E*self.moment_tensor(center="origin", weight="e")
        # EJc = EJo + np.outer(EArc, self.centroid())
        EJo = EJc - np.outer(EArc, self.centroid())
        Kp = np.block([[val(EA), vec(EArc).T, val(0), o.T],
                       [   o, O, o,  EJc],
                       [val(0), o.T, val(GJ), o.T],
                       [vec(-_ix@EArc), -_ix@EJo, o, O]
                       ])
        return Kp

    def energy_tensor(self, weight=None):

        nu = self._nu
        u = self.solve_shear()
        rc = self.centroid()
        model = self._model

        H = np.zeros((2,2))
        if self._mode == "fiber":
            for fiber in model.fibers:
                r = fiber.coord
                Du = np.array([
                    model.elems[fiber.cell].gradient(u[0], fiber.coord), #cell_gradient(i, u[0]),
                    model.elems[fiber.cell].gradient(u[1], fiber.coord) #cell_gradient(i, u[1])
                ])
                𝚷 = _shear_poisson(r, rc, nu)
                B = (Du.T + 𝚷)
                H += B.T@B*model.fiber_weight(fiber, weight=weight)
        else:
            # Setup 𝚷 = nu*( r⊗(rc) - dev r⊗r)
            #         = c3*r⊗(rc) + c1*Q + c2*R)
            # with  Q = (ixr)⊗(ixr),
            #       R = r⊗r
            c1 =   nu/2
            c2 =  -nu/2
            c3 =   nu*0

            y,z = model.nodes.T

            # int 
            brg = model.burgers
            iQV = np.array([
                [ brg(z,z,u[0],0)-brg(z,y,u[0],1),  brg(z,z,u[1],0)-brg(z,y,u[1],1) ],
                [ brg(y,y,u[0],1)-brg(y,z,u[0],0),  brg(y,y,u[1],1)-brg(y,z,u[1],0) ]
            ])
            iRV = np.array([
                [ brg(y,y,u[0],0)+brg(y,z,u[0],1),  brg(y,y,u[1],0)+brg(y,z,u[1],1) ],
                [ brg(z,z,u[0],1)+brg(z,y,u[0],0),  brg(z,z,u[1],1)+brg(z,y,u[1],0) ]
            ])

            Hvw = w*c1*iQV + w*c2*iRV  #+  c1*cmm - c2*ix@cmm@ix + c3*cnv

            # int W^W
            Hww = self.poisson_tensor(weight=weight)

            # cvv = warping.cvv(v=u)[1:,1:]
            _,cvv = model._assemble_K1_K2(*u, weight=weight)

            H = Hvw  + Hvw.T + Hww + cvv
        return H

    def poisson_tensor(self, weight=None):
        r"""
        Integrate (\Pi_b^T)\Pi_b over the cross-section
        """
        model = self._model
        if self._mode != "mesh":
            nu = self._nu
            rc = self.centroid()
            model = self._model
            Hpp = np.zeros((2,2))
            for fiber in model.fibers:
                r = fiber.coord
                W = _shear_poisson(r, rc, nu)
                Hpp += W.T@W*model.fiber_weight(fiber, weight=weight)
        else:
            nu = self._nu
            c1 =   nu/2
            c2 =  -nu/2
            c3 =   nu*0
            y,z = model.nodes.T
            qr = model.quartic
            iQQ = np.array([
                [ qr(y,y,z,z)+qr(z,z,z,z),  -qr(y,y,y,z)-qr(y,z,z,z)],
                [-qr(y,y,y,z)-qr(y,z,z,z),   qr(y,y,y,y)+qr(y,y,z,z)]
            ])
            iRR = np.array([
                [ qr(y,y,z,z)+qr(y,y,y,y),   qr(y,y,y,z)+qr(y,z,z,z)],
                [ qr(y,y,y,z)+qr(y,z,z,z),   qr(z,z,z,z)+qr(y,y,z,z)]
            ])

            rc = self._centroid
            cr = model.cubic
            iRr = np.outer(np.array([
                cr(y,y,y)+cr(z,z,y),
                cr(y,y,z)+cr(z,z,z)
            ]), rc)
            irr = self._irr*np.outer(rc, rc)

            Hpp = c1**2*iQQ + c2**2*iRR + 2*c3*c2*(iRr + iRr.T) + c3**2*irr
            return Hpp*w

        return Hpp

    def centroid(self):
        if self._centroid is not None:
            return self._centroid
        self._centroid = self.moment_vector()/self._EA
        return self._centroid
    
    def elastic_center(self):
        pass

    # def axial_center(self):
    #     return self.moment_vector()

    def moment_vector(self):
        if self._centroid is not None:
            return self._centroid*self._EA
        A  = 1
        Qy = 0
        Qz = 0
        model = self._model
        for fiber in model.fibers:
            dA = model.fiber_weight(fiber, weight="e")
            # A  += dA
            ry = fiber.coord[0]
            rz = fiber.coord[1]
            Qy += ry*dA
            Qz += rz*dA
        return np.array((float(Qy/A), float(Qz/A)))


    def twist_center(self):
        if self._twist_center is not None:
            return self._twist_center
        u = np.zeros((len(self._model.nodes), 3))
        u[:,0] = self.solve_twist()
        self._twist_center = _rotation_average_fiber(
            u=u,
            model=self._model,
            center=self.centroid(),
            weight=1.0,
            balance=self.cmm(center="centroid", weight=None)
        )[1:]
        return self._twist_center

        cmm = self.cmm(center="centroid", weight=None)

        I = np.array([[ cmm[1,1],  cmm[1,2]],
                      [ cmm[2,1],  cmm[2,2]]])

        _, iwy, iwz = self.cmw()[:,0]
        ysc, zsc = np.linalg.solve(I, [iwy, iwz])
        return -np.array((
            float(ysc), #-c[0,0], 
            float(zsc), #+c[1,0]
        ))

    def iesan_center(self):
        """
        Compute r_sc := (1/GJ) ∫ (∇Ψ + Π') (r × i) dG
        """
        u  = self.solve_shear()  # Ψ: flexural warping
        rc = self.centroid()
        GJ = self.twist_rigidity()
        model = self._model

        r_sc = np.zeros(2)
        ix = np.array([[0, -1],[1, 0]], dtype=float)
        for fiber in model.fibers:
            r = fiber.coord
            dA = model.fiber_weight(fiber, weight="g")
            # dA = fiber.area
            
            # ∇Ψ (2×2): Du[j] = ∇Ψ_j, so Du = ∇Ψ
            Du = np.array([
                model.elems[fiber.cell].gradient(u[0], fiber.coord),
                model.elems[fiber.cell].gradient(u[1], fiber.coord)
            ])

            # Π_b (2×2)
            𝜫 = _shear_poisson(r, rc, self._nu)

            # r × i: using r×i = [0, z, -y]^T
            rxi = -ix@r #np.array([r[1], -r[0]])

            # (∇Ψ + Π') @ (r × i)
            r_sc += (Du + 𝜫.T) @ rxi*dA
        
        return r_sc / GJ


    def torsion_constant(self, weight=None):
        # raise NotImplementedError("torsion_constant is now deprecated. Use twist_rigidity instead.")
        warnings.warn("torsion_constant is now deprecated.")
        return self.twist_rigidity()/self._G
    