#
# Claudio M. Perez
#
import warnings
import numpy as np
from shps.solve.poisson import poisson_neumann, HilbertLoad, PoissonLoad
from shps.solve.poisson3 import poisson_neumann


class WarpingAnalysis:
    def __init__(self, shape, materials=None):
        model = shape.model
        self.shape = shape
        self.model = model
        self.nodes = model.nodes
        self.elems = model.elems
        # self._materials = materials

        self._sv_twist = None
        self._sv_twist_sc = None
        self._centroid = None
        self._shear_center = None
        self._shear_warp = {}

        self._nn = None
        self._mm = None 
        self._ww = None
        self._vv = None
        self._nm = None
        self._mw = None
        self._mv = None
        self._nv = None
        self._mm_mode = None

        self._sv_ = {}

    def translate(self, vect):
        return WarpingAnalysis(self.shape.translate(vect))


    def section_tensor(self, twist=None, shear=None):

        External, Constrained, Uniform, Neglected = range(4)

        def constraints(shear, twist):
            nwm = 3
            P  = np.eye(6+2*nwm)
            Pa = np.zeros((3,3))
            Pe = np.zeros((3,6))

            if twist == Constrained or twist == Uniform:
                Pa[0,0] = Pe[0,3] = 1

            if shear == Constrained or shear == Uniform:
                Pa[1,1] = Pe[1,1] = 1
                Pa[2,2] = Pe[2,2] = 1


            P[9:12,0:6] = Pe
            P[9:12,9:12] = np.eye(3) - Pa
            P = P[:, ~(P == 0).all(axis=0)][~(P == 0).all(axis=1),:]

            return P

        cnn = self.cnn()
        cmm = self.cmm()
        cnm = self.cnm()
        cnw = self.cnw()
        cnv = self.cnv()
        cmw = self.cmw()
        cmv = self.cmv()
        cvv = self.cvv()
        cww = self.cww()

        owv =  np.zeros((3,3))
        ACA =  np.block([[cnn  , cnm,   cnw,   cnv],
                         [cnm.T, cmm,   cmw,   cmv],
                         [cnw.T, cmw.T, cww,   owv],
                         [cnv.T, cmv.T, owv.T, cvv]])
        
        if twist is None:
            twist = External
        if shear is None:
            shear = External
        P = constraints(shear, twist)
        BCBP = (ACA@P)[:, ~(P == 0).all(axis=0)]
        PBCBP = (P@BCBP)[~(P == 0).all(axis=1),:]
        return PBCBP

    def cnn(self, _imode=None):
        if _imode is None:
            _imode = "mesh"
        if self._nn is not None:
            return self._nn
        
        if _imode == "mesh":
            e = np.ones(len(self.model.nodes))
            EA = self.model.inertia(e,e, weight="e")
            GA = self.model.inertia(e,e, weight="g")
        else:
            A = sum(fiber.area for fiber in self.model.fibers)
            # TODO: Weight
            GA = EA = A
        self._nn = np.array([[EA,  0,  0],
                            [ 0, GA,  0],
                            [ 0,  0, GA]])
        return self._nn

    def cmm(self, _imode=None):
        if _imode is None:
            _imode = "mesh"

        if self._mm is not None and self._mm_mode == _imode:
            return self._mm

        if _imode == "mesh":
            y,z = self.model.nodes.T
            izy = self.model.inertia(z,y, weight="g")
            izz = self.model.inertia(y,y, weight="e")
            iyy = self.model.inertia(z,z, weight="e")
            self._mm = np.array([[izz+iyy,   0,    0],
                                [   0   , iyy, -izy],
                                [   0   ,-izy,  izz]])
        else:
            I = np.zeros((3,3))
            w = 1.0
            for fiber in self.model.fibers:
                r = fiber.coord
                rx = np.array([[    0,-r[1], r[0]],
                               [ r[1],    0,    0],
                               [-r[0],    0,    0]])
                dA = fiber.area*w
                I -= rx@rx*dA
            self._mm = I
        self._mm_mode = _imode
        return self._mm

    def cww(self):
        """
        \\int \\varphi ⊗ \\varphi
        """
        if self._ww is None:
            w = self.solve_twist()
            Iw = self.model.inertia(w, w, weight="e")
            self._ww = np.array([[Iw, 0, 0],
                                 [ 0, 0, 0],
                                 [ 0, 0, 0]])
        return self._ww

    def cvv(self, v=None):
        if v is None:
            w = self.solve_twist()
            Iww = self.model.energy(w, w, weight="g")
        else:
            Iww = 0

        vv = np.array([[Iww, 0.0, 0.0],
                       [0.0, 0.0, 0.0],
                       [0.0, 0.0, 0.0]])

        if v is not None:
            vv[1,1] = self.model.energy(v[0], v[0], weight="g")
            vv[2,2] = self.model.energy(v[1], v[1], weight="g")
            vv[1,2] = self.model.energy(v[0], v[1], weight="g")
            vv[2,1] = self.model.energy(v[1], v[0], weight="g")
        return vv


    def cnm(self):
        if self._nm is not None:
            return self._nm
        y,z = self.model.nodes.T
        e  = np.ones(len(self.model.nodes))
        EQy = self.model.inertia(e,z, weight="e")
        EQz = self.model.inertia(e,y, weight="e")
        GQy = self.model.inertia(e,z, weight="g")
        GQz = self.model.inertia(e,y, weight="g")
        self._nm = np.array([[ 0,  EQy, -EQz],
                             [-GQy,  0,    0],
                             [ GQz,  0,    0]])
        return self._nm

    def cmw(self):
        if self._mw is not None:
            return self._mw
        y,z =  self.model.nodes.T
        w = self.solve_twist()
        iwy = self.model.inertia(w,z)
        iwz = self.model.inertia(w,y)
        self._mw = np.array([[  0,  0, 0],
                             [ iwy, 0, 0],
                             [-iwz, 0, 0]])
        return self._mw

    def cmv(self):
        if self._mv is not None:
            return self._mv

        w = self.solve_twist()

        yz  = self.model.nodes
        cxx = self.model.curl(yz, w)
        self._mv = np.array([[cxx, 0.0, 0.0],
                             [0.0, 0.0, 0.0],
                             [0.0, 0.0, 0.0]])
        return self._mv

    def cnv(self, shear=False, v=None):
        # if self._nv is not None:
        #     return self._nv
        w = self.solve_twist()

        i = np.zeros_like(self.model.nodes)
        i[:,1] = -1
        # i[:,0] = 1
        cxy = self.model.curl(i, w)
        # i[:,1] = 1
        # i[:,0] = 0
        i[:,0] = 1
        i[:,1] = 0
        cxz = self.model.curl(i, w)

        if shear or (v is not None):
            if v is None:
                v = self.solve_shear()
            o = np.zeros_like(v[0])
            syy = self.model.poisson(v[0],o)
            szz = self.model.poisson(o,v[1])
            syz = self.model.poisson(o,v[0])
            szy = self.model.poisson(v[1],o)
            # syy = self.model.poisson(v[0],v[0])
            # szz = self.model.poisson(v[1],v[1])
            # syz = self.model.poisson(v[0],v[1])
            # szy = self.model.poisson(v[1],v[0])
        else:
            syy = 0
            szz = 0
            syz = 0
            szy = 0

        return np.array([[0.0, 0.0, 0.0],
                         [cxy, syy, szy],
                         [cxz, syz, szz]])
        # return self._nv

    def cnw(self, ua=None, measure=None)->float:
        # Normalizing Constant = -warpIntegral / A
        c = 0.0

        if ua is not None:
            for fiber in self.model.fibers:
                dA = self.model.fiber_weight(fiber, weight=measure) #fiber.area*self.model.cell_weight(fiber.cell, weight=measure)
                c += self.model.elems[fiber.cell].interp(ua, fiber.coord)*dA

        return np.array([[ c , 0.0, 0.0],
                         [0.0, 0.0, 0.0],
                         [0.0, 0.0, 0.0]])


    def shear_model(self, nu:float=0.0, form=None, u=None):
        warnings.warn("shear_model is deprecated.")
        if u is None:
            u = self.solve_shear(nu)

        if form is None:
            return _NaturalShear(self, nu, u=u)

    def create_trace(self, nu: float, form=None):
        warnings.warn("create_trace is deprecated.")
        from .trace import _EnergeticTrace, _GeometricTrace
        from .venant import SaintVenantSectionAnalysis
        if nu not in self._sv_:
            self._sv_[nu] = SaintVenantSectionAnalysis(self.shape, nu=nu, model=self.model)

        if form is None or form in {"energetic", "natural", "UE"}:
            return _EnergeticTrace(self.shape, nu, sv=self._sv_[nu])
        elif form in {"geometric", "average", "UG"}:
            return _GeometricTrace(self.shape, nu, sv=self._sv_[nu])
        else:
            raise ValueError(f"Unknown trace form '{form}'")

    def shear_factor(self, nu=None, v=None):
        if v is None:
            v = self.solve_shear(nu)

        r = self.model.nodes.T

        ca = nu/2
        a1, a2, c = self._shear_coeffs(nu)
        ix = np.array([[0.0,-1.0],[1.0,0.0]])
        a = r*(ca*np.sum(r**2, axis=0))

        cnn = self.cnn()[1:,1:]
        cmm = self.cmm()[1:,1:]
        D =   -np.linalg.solve(ix@cmm@ix, cnn)/c
        u =  D.T@(v + a) - r

        # for i in range(2):
        #     cnw = self.cnw(u[i])[0,0]
        #     u[i] -= cnw/cnn[0,0]

        cnv = self.cnv(v=u)[1:,1:]
        cvv = self.cvv(v=u)[1:,1:]

        # cs = np.linalg.inv(cnn[1:,1:])@cnv[1:,1:] + np.eye(2)
        if False:
            ann = cnn + (cnv+cnv.T)/(6*c) + cnn/(3*c)
            cs = np.linalg.solve(cnn,ann)
            return np.linalg.diagonal(cs)

        ann = cnn + (cnv+cnv.T) + cvv
        cs = np.linalg.solve(cnn,ann)
        return 1/np.linalg.eigvals(cs)


    def shear_factor_romano(self, u=None, nu=None):
        if nu is None and u is None:
            nu = 0
            u = self.solve_shear(nu)
        if nu is None:
            nu = 0
        if u is None:
            u = self.solve_shear(nu)

        # sm = self.shear_model(nu, u=u)


        a1, a2, c = self._shear_coeffs(nu)
        c1 =  -nu/2
        c2 =   nu/2
        c3 =  0

        r = self.model.nodes.T
        y,z = r

        cmm = self.cmm()[1:,1:]
        cnn = self.cnn()[1:,1:]
        ix = np.array([[0.0,-1.0],[1.0,0.0]])
        # D = -np.linalg.solve(ix@cmm@ix, cnn)/c
        Ji = np.linalg.inv(-ix@cmm@ix)


        # cvv = self.cvv(v=u)[1:,1:]
        _,cvv = self.model._assemble_K1_K2(*u, weight="g")


        brg = self.model.burgers
        iQV = np.array([
            [ brg(z,z,u[0],0)-brg(z,y,u[0],1),  brg(z,z,u[1],0)-brg(z,y,u[1],1) ],
            [ brg(y,y,u[0],1)-brg(y,z,u[0],0),  brg(y,y,u[1],1)-brg(y,z,u[1],0) ]
        ])
        iRV = np.array([
            [ brg(y,y,u[0],0)+brg(y,z,u[0],1),  brg(y,y,u[1],0)+brg(y,z,u[1],1) ],
            [ brg(z,z,u[0],1)+brg(z,y,u[0],0),  brg(z,z,u[1],1)+brg(z,y,u[1],0) ]
        ])

        kae = c1*iQV + c2*iRV  #+  c1*cmm - c2*ix@cmm@ix + c3*cnv

        qr = self.model.quartic
        iQQ = np.array([
            [ qr(y,y,z,z)+qr(z,z,z,z),  -qr(y,y,y,z)-qr(y,z,z,z)],
            [-qr(y,y,y,z)-qr(y,z,z,z),   qr(y,y,y,y)+qr(y,y,z,z)]
        ])
        iRR = np.array([
            [ qr(y,y,z,z)+qr(y,y,y,y),   qr(y,y,y,z)+qr(y,z,z,z)],
            [ qr(y,y,y,z)+qr(y,z,z,z),   qr(z,z,z,z)+qr(y,y,z,z)]
        ])
        kaa = (c1**2 + c3)*iQQ + (c2**2 + c3)*iRR + c3**2*cnn


        BB = kae  + kae.T + kaa + cvv

        ann = Ji.T@(BB*cnn[0,0]/(c**2))@Ji

        k = np.linalg.eigvals(np.linalg.inv(ann))
        return k, ann


    def fiber_shear(self, nu=0, u=None, shear_model=None):
        if u is None:
            u = self.solve_shear(nu)

        r = self.model.nodes.T

        cnn = self.cnn()[1:,1:]
        if shear_model is None:
            shear_model = _NaturalShear(self, nu, u=u)

        X = shear_model.align_matrix()

        u =  X.T@u - r

        for i in range(2):
            cnw = self.cnw(u[i])[0,0]
            u[i] -= cnw/cnn[0,0]
        return u

    def shear_enhance(self, u, nu):

        a1, a2, c = self._shear_coeffs(nu)
        c1 =   0 # nu/2 # 1 # c
        c2 =   0 # 5/4*nu #nu/2 # 1.5 #c**2 #1/c # c
        c3 =   0 # c
        # c1 =   nu/2
        # c2 =  -nu/2
        c2 = -(5/4)*nu
        c3 =  0
        r = self.model.nodes.T
        y,z = r

        cmm = self.cmm()[1:,1:]
        cnn = self.cnn()[1:,1:]
        ix = np.array([[0.0,-1.0],[1.0,0.0]])
        knn, xnn = self.shear_factor_romano(u, nu)
        snn = np.linalg.solve(xnn, cnn)
        D = -np.linalg.solve(ix@cmm@ix, snn)/c

        ca = nu/2
        a = D@r*(ca*np.sum(r**2, axis=0))
        u =  D.T@(u + a) - r

        for i in range(2):
            cnw = self.cnw(u[i])[0,0]
            u[i] -= cnw/cnn[0,0]

        cnv = self.cnv(v=u)[1:,1:]
        cvv = self.cvv(v=u)[1:,1:]
        # _,cvv = self.model._assemble_K1_K2(*u, weight="g")

    
        brg = self.model.burgers
        iQV = np.array([
            [ brg(z,z,u[0],0)-brg(z,y,u[0],1),  brg(z,z,u[1],0)-brg(z,y,u[1],1) ],
            [ brg(y,y,u[0],1)-brg(y,z,u[0],0),  brg(y,y,u[1],1)-brg(y,z,u[1],0) ]
        ])
        iRV = np.array([
            [ brg(y,y,u[0],0)+brg(y,z,u[0],1),  brg(y,y,u[1],0)+brg(y,z,u[1],1) ],
            [ brg(z,z,u[0],1)+brg(z,y,u[0],0),  brg(z,z,u[1],1)+brg(z,y,u[1],0) ]
        ])

        kae = c1*iQV + c2*iRV  +  c1*cmm - c2*ix@cmm@ix + c3*cnv

        qr = self.model.quartic
        iQQ = np.array([
            [ qr(y,y,z,z)+qr(z,z,z,z),  -qr(y,y,y,z)-qr(y,z,z,z)],
            [-qr(y,y,y,z)-qr(y,z,z,z),   qr(y,y,y,y)+qr(y,y,z,z)]
        ])
        iRR = np.array([
            [ qr(y,y,z,z)+qr(y,y,y,y),   qr(y,y,y,z)+qr(y,z,z,z)],
            [ qr(y,y,y,z)+qr(y,z,z,z),   qr(z,z,z,z)+qr(y,y,z,z)]
        ])
        kaa = (c1**2 + c3)*iQQ + (c2**2 + c3)*iRR + c3**2*cnn

        T = iRR
        H = c2**2 * D.T@T@D
        # import scipy.linalg
        # H2 = np.linalg.inv(scipy.linalg.sqrtm(H))
        kaa = H
        kae = kae@D


        C = 1 #nu/(1+nu) #1 #nu/(1+nu) #2*nu/4
        ann = cnn*1 + (cnv + cnv.T) + cvv
        # print(np.linalg.diagonal(np.linalg.solve(cnn,ann)))
        # if c1 != 0 or c2 != 0 or c3 != 0:
        #     aee = kae.T@np.linalg.solve(kaa,kae)        # print(kaa)\
        #     ann -= aee # Ji.T@aee@Ji #/c**2 #@D #np.linalg.solve(D,aee)

        k = np.linalg.eigvals(np.linalg.solve(cnn,ann))
        return k

    def _shear_coeffs(self, nu):
        G = 1.0
        E = G*2*(1 + nu)
        v = 2.0*nu*G/E

        # for Ap 
        c = E/G # 2*(1+v)
        a1 =  nu/2 # Q
        a2 = -nu/2 # R

        return a1, a2, c


    def shear_warping(self, nu=0.0):
        return self.solve_shear(nu)

    def solve_shear(self, nu=0.0):
        if nu in self._shear_warp:
            return self._shear_warp[nu]
        # Solve for \WarpShearIesan
        from shps.solve.boundary import find_boundaries, Monomial2D, integrate_boundary

        r = self.model.nodes.T
        rc = self.centroid()

        c1, c2, c = self._shear_coeffs(nu)

        cnn = self.cnn()[1:,1:]

        # Form boundary loads
        f = np.zeros((2,len(self.model.nodes)))
        conn = np.array([elem.nodes for elem in self.model.elems])
        nodes = self.model.nodes
        boundary_nodes = set()
        # NOTE
        for boundary in find_boundaries(conn):
            boundary_nodes.update(boundary)
            # d' = e_y
            f[0] -= integrate_boundary(nodes, boundary,
                        gy_terms=[
                            # z^2 - y^2
                            Monomial2D(0,2,  nu/2), Monomial2D(2,0, -nu/2), Monomial2D(1,0, rc[0]*nu)
                        ],
                        gz_terms=[
                            Monomial2D(1,1,-nu), Monomial2D(0,1, rc[0]*nu)
                        ])
            # d' = e_z
            f[1] -= integrate_boundary(nodes, boundary,
                        gz_terms=[
                            # y^2 - z^2
                            Monomial2D(0,2, -nu/2), Monomial2D(2,0,  nu/2), Monomial2D(0,1, rc[1]*nu)
                        ],
                        gy_terms=[
                            Monomial2D(1,1,-nu), Monomial2D(1,0, rc[1]*nu)
                        ])

        # Find an interior node to fix
        fix_node = 0
        for i in range(len(self.model.nodes)):
            if i not in boundary_nodes:
                fix_node = i
                break
                
        # Solve BVP
        u = np.array([
            poisson_neumann(
                self.model.nodes,
                self.model.elems,
                fix_node=fix_node,
                force=f[i],
                loads=[
                    HilbertLoad((r[i]-rc[i])*2.0), #  Note: (2*nu-c) == -2.0
                ]
            ) for i in (0,1)
        ])


        for i in range(2):
            cnw = self.cnw(u[i])[0,0]
            u[i] -= cnw/cnn[0,0]
        
        self._shear_warp[nu] = u
        return u

    def _summarize_mesh(self):
        return f"""
        nodes: {len(self.model.nodes)}
        elems: {len(self.model.elems)}
        """


    def css(self):
        u = self.solve_twist_ra()
        w = self.solve_twist()
        return -self.model.inertia(u,w, weight="e")

    def solution(self):
        return self.solve_twist()

    def solve_twist(self):
        """
        We should have 
          self.model.inertia(np.ones(nf), warp) ~ 0.0
        """
        if self._sv_twist is not None:
            return self._sv_twist

        y, z = self.model.nodes.T
        u = poisson_neumann(
            model=self.model,
            loads=[PoissonLoad( z, -y, measure="g")],
            measure="g"
        )
        cnw = self.cnw(u, measure="e")[0,0]
        cnn = self.cnn()[0,0]
        u -= cnw/cnn
        self._sv_twist = u
        return u

    def solve_twist_ra(self):

        w = self.solve_twist()

        u = poisson_neumann(
            model = self.model,
            loads = [HilbertLoad(w, measure="e")],
            measure="g"
        )
        u -= self.cnw(u, measure="e")[0,0]/self.cnn()[0,0]
        return -u

    def centroid(self):
        EA = self.cnn()[0,0]
        GA = self.cnn()[1,1]
        if True:
            cnm = self.cnm()
            EQy =  cnm[0,1] # int z
            EQz = -cnm[0,2]
            GQz =  cnm[2,0] # int y

        else:
            Qy = 0
            Qz = 0
            for fiber in self.model.fibers:
                area = fiber.area
                ry, rz = fiber.coord
                Qy += ry*area
                Qz += rz*area

        return np.array((float(EQz/EA), float(EQy/EA)))


    def shear_center(self):
        # if self._shear_center is not None:
        #     return self._shear_center
        xc  = self.centroid()
        cmm = self.translate(-xc).cmm()
        # cmm = self.cmm()

        I = np.array([[ cmm[1,1],  cmm[1,2]],
                      [ cmm[2,1],  cmm[2,2]]])

        _, iwy, iwz = self.cmw()[:,0]
        ysc, zsc = np.linalg.solve(I, [iwy, iwz])
        self._shear_center = -np.array((
            float(ysc), #-c[0,0], 
            float(zsc), #+c[1,0]
        )) # self.centroid()
        return self._shear_center


    def warping(self):
        warnings.warn("warping() is deprecated. Use solve_twist() instead.")
        if self._sv_twist_sc is not None:
            return self._sv_twist_sc

        w = self.solve_twist()
        # w = self.translate(-self.centroid()).solve_twist()

        y,   z = self.model.nodes.T
        cy, cz = self.centroid()
        yc = y - cy 
        zc = z - cz
        sy, sz = self.shear_center()
        # sy = -sy 
        # sz = -sz
        # w =  w + np.array([ys, -zs])@self.model.nodes.T
        w = w + sy*zc - sz*yc

        self._sv_twist_sc = w

        return self._sv_twist_sc


    def torsion_constant(self, weight=None, _imode=None):
        """
        Compute St. Venant's constant.
        """
        if _imode is None:
            _imode = "mesh"
    
        # if _imode == "mesh":
        #     # J = Io + Irw
        #     return self.cmm(_imode=_imode)[0,0] + self.cmv()[0,0]

        u  = self.solve_twist()
        model = self.model

        J0 = 0.0
        ix = np.array([[0, -1],[1, 0]], dtype=float)
        for fiber in model.fibers:
            r = fiber.coord
            dA = model.fiber_weight(fiber, weight="g")

            # ∇Ψ (2×2): Du[j] = ∇Ψ_j, so Du = ∇Ψ
            Du = model.elems[fiber.cell].gradient(u, fiber.coord)

            # r × i: using r×i = [0, z, -y]^T
            ixr = ix@r

            # (∇Ψ + Π') @ (r × i)
            J0 += (Du @ ixr + np.dot(r,r))*dA
        
        return float(J0)



class _ShearModel:
    def __init__(self, warping, nu, u, mode=None):
        if mode is None:
            mode = "fiber"
        self._mode = mode
        self._warping = warping
        self._nu = nu
        self._u  = u

        cnn = warping.cnn()[1:,1:]
        self._GA = cnn[0,0]
        self._factor_matrix = None
        self._fiber_array = None
        self._centroid = warping.centroid()
        self._moment_tensor_origin = None

    
    def moment_tensor(self, loc=None, weight="e"):
        if self._moment_tensor_origin is not None:
            return self._moment_tensor_origin

        nu = self._nu
        G = 1.0
        E = G*2*(1 + nu)
        if True:

            cmm = self._warping.cmm()
            self._irr = 0 # cmm[0,0]
            imm = cmm[1:,1:]
            ix = np.array([[0.0,-1.0],
                           [1.0, 0.0]])
            c = E/G # 2*(1+nu)
            self._moment_tensor_origin = -(ix@imm@ix)*c

        if True:
            u = self._u
            rc = self._centroid
            model = self._warping.model
            self._irr = 0 # TODO
            HF = np.zeros((2,2))
            for i,elem in enumerate(model.elems):
                # E = model._assigns[elem.group]["e"]
                # G = model._assigns[elem.group]["g"]
                # nu = E/(2*G) - 1
                r = sum(model.nodes[elem.nodes])/3.0
                Du = np.array([
                    model.cell_gradient(i, u[0]),
                    model.cell_gradient(i, u[1])
                ])
                devR = np.outer(r, r) - 0.5*np.dot(r, r)*np.eye(2)
                W = -nu*(devR - np.outer(r, rc))
                HF += G*(Du.T + W)*model.cell_area(i)

            # print(f"{HF = }")
            # print(f"Jo-HF = {self._moment_tensor_origin - HF}")

            if self._mode == "fiber":
                self._moment_tensor_origin = HF
        return self._moment_tensor_origin


    def align_matrix(self):
        """obsolete
        Return the shear identification matrix (ShiftB)
        """
        GA = self._GA

        K = self.scale_matrix()
        Jo = self.moment_tensor(loc=None)
        X = GA*np.linalg.solve(Jo, K)
        return X


    def scale_matrix(self, form="natural"):
        if form == "natural":
            return np.linalg.inv(self.romano_tensor())

        elif form == "average":
            J = self.moment_tensor(loc=None)
            GA = self._GA
            X = self.cowper_matrix()
            L = GA*np.linalg.inv(X)@np.linalg.inv(J) - np.eye(2)
            return np.linalg.inv(np.eye(2) + L)
        


    def correction(self, **kwds):
        """
        Return the shear correction factors
        """
        return np.linalg.eigvals(self.scale_matrix(**kwds))
        # return np.diag(self.scale_matrix(**kwds))


    def fiber_array(self):
        warnings.warn("fiber_array() is deprecated.")
        if self._fiber_array is not None:
            return self._fiber_array

        u = self._u
        import os
        # if "Align" not in os.environ:
        #     GA = self._GA
        #     model = self._warping.model
        #     warping = self._warping

        #     r = model.nodes.T

        #     X = self.align_matrix()

        #     u =  X.T@u - r

        #     for i in range(2):
        #         cnw = warping.cnw(u[i])[0,0]
        #         u[i] -= cnw/GA

        self._fiber_array = u
        return u
    
    def cmn(self, _imode=None):

        nu = self._nu
        G = 1.0
        E = G*2*(1 + nu)
        u = self._u
        rc = np.array([0, *self._centroid])
        model = self._warping.model
        oneS = np.array([[0,0,0],
                         [0,1,0],
                         [0,0,1]])

        H = np.zeros((3,3))
        for i,elem in enumerate(model.elems):
            # E = model._assigns[elem.group]["e"]
            # G = model._assigns[elem.group]["g"]
            # nu = E/(2*G) - 1
            r = np.array([0, *sum(model.nodes[elem.nodes])/3.0])
            Du = np.array([
                [0, 0, 0],
                [0, *model.cell_gradient(i, u[0])],
                [0, *model.cell_gradient(i, u[1])]
            ])
            rx = np.array([[    0, -r[2], r[1]],
                           [ r[2],     0,    0],
                           [-r[1],     0,    0]])
            devR = np.outer(r, r) - 0.5*np.dot(r, r)*oneS
            W = -nu*(devR - np.outer(r, rc))
            B = (Du.T + W)
            H += rx.T@B*G*model.cell_area(i)

        return H
                
    def energy_tensor(self):

        nu = self._nu
        G = 1.0
        E = G*2*(1 + nu)
        u = self._u
        rc = self._centroid
        model = self._warping.model

        H = np.zeros((2,2))
        if self._mode == "fiber":
            for i,elem in enumerate(model.elems):
                # E = model._assigns[elem.group]["e"]
                # G = model._assigns[elem.group]["g"]
                # nu = E/(2*G) - 1
                r = sum(model.nodes[elem.nodes])/3.0
                Du = np.array([
                    model.cell_gradient(i, u[0]),
                    model.cell_gradient(i, u[1])
                ])
                devR = np.outer(r, r) - 0.5*np.dot(r, r)*np.eye(2)
                W = -nu*(devR - np.outer(r, rc))
                B = (Du.T + W)
                H += B.T@B*G*model.cell_area(i)
        else:
            # Setup W = nu*( r⊗(rc) - dev r⊗r)
            #         = c3*r⊗(rc) + c1*Q + c2*R)
            # with  Q = (ixr)⊗(ixr),
            #       R = r⊗r
            c1 =   nu/2
            c2 =  -nu/2
            c3 =   nu*0

            y,z = model.nodes.T


            # int 
            brg = model.burgers
            iQV = np.array([
                [ brg(z,z,u[0],0)-brg(z,y,u[0],1),  brg(z,z,u[1],0)-brg(z,y,u[1],1) ],
                [ brg(y,y,u[0],1)-brg(y,z,u[0],0),  brg(y,y,u[1],1)-brg(y,z,u[1],0) ]
            ])
            iRV = np.array([
                [ brg(y,y,u[0],0)+brg(y,z,u[0],1),  brg(y,y,u[1],0)+brg(y,z,u[1],1) ],
                [ brg(z,z,u[0],1)+brg(z,y,u[0],0),  brg(z,z,u[1],1)+brg(z,y,u[1],0) ]
            ])

            Hvw = c1*iQV + c2*iRV  #+  c1*cmm - c2*ix@cmm@ix + c3*cnv

            # int W^W
            Hww = self.poisson_tensor()

            # cvv = warping.cvv(v=u)[1:,1:]
            _,cvv = model._assemble_K1_K2(*u, weight="g")

            H = Hvw  + Hvw.T + Hww + cvv
        return H

    
    def poisson_tensor(self):
        r"""
        Integrate (\Pi_b^T)\Pi_b over the cross-section
        """
        
        model = self._warping.model
        if self._mode == "mesh":
            nu = self._nu
            c1 =   nu/2
            c2 =  -nu/2
            c3 =   nu*0
            y,z = model.nodes.T
            qr = model.quartic
            iQQ = np.array([
                [ qr(y,y,z,z)+qr(z,z,z,z),  -qr(y,y,y,z)-qr(y,z,z,z)],
                [-qr(y,y,y,z)-qr(y,z,z,z),   qr(y,y,y,y)+qr(y,y,z,z)]
            ])
            iRR = np.array([
                [ qr(y,y,z,z)+qr(y,y,y,y),   qr(y,y,y,z)+qr(y,z,z,z)],
                [ qr(y,y,y,z)+qr(y,z,z,z),   qr(z,z,z,z)+qr(y,y,z,z)]
            ])

            rc = self._centroid
            cr = model.cubic
            iRr = np.outer(np.array([
                cr(y,y,y)+cr(z,z,y),
                cr(y,y,z)+cr(z,z,z)
            ]), rc)
            irr = self._irr*np.outer(rc, rc)

            Hww = c1**2*iQQ + c2**2*iRR + 2*c3*c2*(iRr + iRr.T) + c3**2*irr
            return Hww
        else:
            nu = self._nu
            G = 1.0
            E = G*2*(1 + nu)
            u = self._u
            rc = self._centroid
            model = self._warping.model
            self._irr = 0 # TODO
            Hww = np.zeros((2,2))
            for i,elem in enumerate(model.elems):
                # E = model._assigns[elem.group]["e"]
                # G = model._assigns[elem.group]["g"]
                # nu = E/(2*G) - 1
                r = sum(model.nodes[elem.nodes])/3.0
                devR = np.outer(r, r) - 0.5*np.dot(r, r)*np.eye(2)
                W = -nu*(devR - np.outer(r, rc))
                Hww += W.T@W*G*model.cell_area(i)

        return Hww

    def romano_tensor(self):
        """
        Return Romano's dimensionless shear factor tensor
        """
        if self._factor_matrix is not None:
            return self._factor_matrix

        nu = self._nu
        warping = self._warping
        model = warping.model

        H = self.energy_tensor()

        GA = self._GA
        Jo = self.moment_tensor(loc=None)
        Ji = np.linalg.inv(Jo)
        self._factor_matrix = GA*Ji.T@H@Ji
        return self._factor_matrix


    def cowper_matrix(self):
        """obsolete; builds Cowper's ShiftB
        """

        nu = self._nu
        G = 1.0
        u = self._u
        rc = self._centroid
        model = self._warping.model

        cmm = self._warping.cmm()[1:,1:]

        AW = np.zeros((2,2))
        AT = np.zeros((2,2))
        ix = np.array([[0.0,-1.0],[1.0,0.0]])
        A = 0
        for i,elem in enumerate(model.elems):
            r = sum(model.nodes[elem.nodes])/3.0

            ur = sum(u[0][elem.nodes])/3.0, sum(u[1][elem.nodes])/3.0
            yc,zc = r - rc
            dA = model.cell_area(i)
            A += dA
            
            devR = np.outer(r, r) - 0.5*np.dot(r, r)*np.eye(2)
            W = -nu*(devR - np.outer(r, rc))
            AW += W*dA
            for j in range(2):
                AT[j] += [
                    zc*ur[j]*dA,
                    -yc*ur[j]*dA
                ]
        X = AW/A + ix@np.linalg.solve(cmm, AT.T)
        return np.linalg.inv(X)


class _NaturalShear(_ShearModel):
    def __init__(self, warping, nu, u, **kwds):
        super().__init__(warping, nu, u, **kwds)