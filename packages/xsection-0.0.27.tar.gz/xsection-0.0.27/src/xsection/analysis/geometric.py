


class GeometricProperties:
    def __init__(self, shape):
        self.shape = shape