import numpy as np
from xsection.analysis.venant import SaintVenantSectionAnalysis

try:
    from numba import njit as jit 
    from numba import prange
    jit(lambda x: x**2)(1.0)  # test if numba is available

except:
    prange = range
    def jit(*_, **__):
        def _decorator(func):
            return func
        return _decorator


_i = np.array([[1],[0],[0]], dtype=float)
_ix = np.array([[0,-1],[1,0]], dtype=float)

def _cache_method(name: str, cache):
    def wrapper(self, *args, **kwds):
        if name not in getattr(self, cache):
            getattr(self, cache)[name] = getattr(self, "_"+name)(*args, **kwds)
        return getattr(self, cache)[name]
    return wrapper


def _hat(r):
    return np.array([[    0,-r[1], r[0]],
                     [ r[1],    0,    0],
                     [-r[0],    0,    0]])

def _rotation_average_fiber(u, model, center=None, weight:float=None, balance=None):
    w  = weight
    ro = center
    if balance is not None:
        I = balance
    else:
        I = np.zeros((3,3))
        for fiber in model.fibers:
            r = fiber.coord - ro
            rx = np.array([[     0,-r[1], r[0]],
                            [ r[1],    0,    0],
                            [-r[0],    0,    0]])
            dA = fiber.area*w
            I -= rx@rx*dA

    rxu = 0 # np.zeros(3)
    if callable(u):
        for fiber in model.fibers:
            r = fiber.coord - ro
            ur = u(fiber)
            rx = np.array([[    0,-r[1], r[0]],
                            [ r[1],    0,    0],
                            [-r[0],    0,    0]])
            dA = fiber.area*w
            rxu += rx @ np.array(ur) * dA
    else:
        for fiber in model.fibers:
            r = fiber.coord - ro
            rx = np.array([[    0,-r[1], r[0]],
                            [ r[1],    0,    0],
                            [-r[0],    0,    0]])

            ur = model.elems[fiber.cell].interp(u, fiber.coord) #sum(u[elem.nodes])/3.0
            dA = fiber.area*w
            rxu += rx @ np.array(ur) * dA
    return np.linalg.solve(I, rxu)


# @jit
def _shear_poisson(r, rc, nu):
    devR = np.outer(r, r) - 0.5*np.dot(r, r)*np.eye(2)
    return -nu*(devR - np.outer(r, rc))




class _Trace:
    def __init__(self, shape, nu, u=None, sv=None, mode=None, shift=True, classical: bool=True):
        # In mesh mode, polynomial integrals are computed using
        # barycentric formulas over the mesh.
        # In fiber mode, polynomial integrals are computed using
        # simple quadrature over the fiber array.
        if mode is None:
            mode = "fiber"
        self._mode = mode
        self._nu = nu
        self._classical = classical

        if sv is None:
            self._sv = SaintVenantSectionAnalysis(shape, nu=nu)
        else:
            self._sv = sv
        

        self._u = self._sv.solve_shear()

        # Whether to apply the trace shift to the fiber array
        self._shift = shift

        # self._G  = sv._G
        self._GA = sv._GA
        self._A  = sv._A
        self._centroid = sv.centroid()
        self._trace_matrix = None
        self._trace_inverse = None

        self._shift_matrices = {}


    shift_shear_gamma = _cache_method("shift_shear_gamma", "_shift_matrices")
    shift_twist_axial = _cache_method("shift_twist_axial", "_shift_matrices")
    shift_twist_gamma = _cache_method("shift_twist_gamma", "_shift_matrices")
    #
    shift_shear_twist = _cache_method("shift_shear_twist", "_shift_matrices")
    shift_axial_twist = _cache_method("shift_axial_twist", "_shift_matrices")
    #
    shift_shear_axial = _cache_method("shift_shear_axial", "_shift_matrices")
    shift_twist_kappa = _cache_method("shift_twist_kappa", "_shift_matrices")
    shift_shear_kappa = _cache_method("shift_shear_kappa", "_shift_matrices")

    def _shift_shear_gamma(self): ... # ShiftB
    def _shift_twist_axial(self): ... # 𝝆𝜘 = \TraceTF = -\ShiftB^{-1} ShiftT
    def _shift_twist_gamma(self): ... # 𝝆𝛾 = \TraceFT = -\ShiftB^{-1} ShiftK
    def _shift_shear_twist(self):     # ShiftK
        Xb = self.shift_shear_gamma()
        return -Xb@self.shift_twist_gamma()
    def _shift_axial_twist(self):     # ShiftT
        Xb = self.shift_shear_gamma()
        return -Xb@self.shift_twist_axial()

    def _shift_shear_kappa(self):     # ShiftA
        return np.zeros((2,2))
    def _shift_shear_axial(self):     # 𝜼𝜖 = ShiftN
        return np.zeros(2)
    def _shift_twist_kappa(self):     # 𝜼𝛾 = ShiftF
        return np.zeros(2)

    def summary(self)->str:
        return f"""
        r_psi = {self.iesan_center()}\n

        sce = {self.sce()}\n
        shift_shear_gamma = {self.shift_shear_gamma().flatten()}
        shift_twist_axial = {self.shift_twist_axial()}
        shift_twist_gamma = {self.shift_twist_gamma()}
        """
        """
        shift_shear_axial = {self.shift_shear_axial()}
        shift_twist_kappa = {self.shift_twist_kappa()}
        shift_shear_kappa = {self.shift_shear_kappa()}
        """

    def scm(self):
        """Shear correction matrix
        """
        X = self.shift_shear_gamma()
        EJ = self._sv.moment_tensor(center="centroid", weight="e")
        GA = self._GA
        return EJ@X/GA

    def sce(self):
        """Shear correction eigenvalues
        """
        return np.linalg.eigvals(self.scm())
    
    def trace_inverse(self):
        if self._trace_inverse is not None:
            return self._trace_inverse
        self._trace_inverse = np.linalg.inv(self.trace_matrix())
        return self._trace_inverse
    
    def trace_matrix(self):
        if self._trace_matrix is not None:
            return self._trace_matrix
        def vec(x):
            x = np.asarray(x, dtype=float)
            return x.reshape(2, 1)
        val = lambda x: np.array([[float(x)]], dtype=float)
        Xb = self.shift_shear_gamma()      # (2,2)
        Xa = self.shift_shear_kappa()      # (2,2)
        ne = vec(self.shift_shear_axial()) # (2)
        rg = vec(self.shift_twist_gamma()) # (2)
        rk = vec(self.shift_twist_axial()) # (2)
        ng = vec(self.shift_twist_kappa()) # (2)
        zg = -Xb@rg
        zk = -Xb@rk
        me = val(-(np.linalg.solve(Xb, ne).T@Xb@rg)[0,0])
        o  = np.zeros((2,1))
        O  = np.zeros((2,2))
        ix = np.array([[0,-1],[1,0]], dtype=float)
        lk = val(1 - (rk.T@zg)[0,0])

        self._trace_matrix = np.block([
                         [val(1), ne.T, me,  o.T],
                         [  o,    Xa,   ng,  ix ],
                         [val(0), zk.T, lk,  o.T],
                         [  o,    Xb,   zg,  O  ]])

        return self._trace_matrix

    def poisson_shape(self, r):
        return _shear_poisson(r, self._centroid, self._nu)

    def rigid_shift(self):
        E = self.trace_matrix()
        # eta_\epsilon
        assert np.linalg.norm(self.shift_shear_axial() - E[0,1:3]) < 1e-12

        Lr = np.zeros((6,6))
        Lr[1:3,1:3] = -np.eye(2)
        # Lr[3,3] = E[0,3]
        Xa = self.shift_shear_kappa()
        Xb = self.shift_shear_gamma()
        zk = E[3,1:3].flatten() # zeta_kappa
        rho_psi = self.iesan_center() #np.zeros(2) #
        if False:
            a = Xb.T@rho_psi
            sa = self.shift_twist_axial()
            sg = self.shift_twist_gamma()
            zg = -Xb@sg
            b = Xb@sa
            Lr[3,1:3] = a-b 
            Lr[0,1:3] = a-b 
            Lr[3,3] = np.dot(zg, rho_psi-sa)
        else:
            Lr[3,1:3] = Xb.T@rho_psi + zk
            # Lr[0,1:3] = self.shift_shear_axial()
            # Lr[4:,1:3] = -_ix@Xa
            #
            zg = E[1:3,3].flatten() # zeta_gamma
            sg = E[4:,3].flatten() # sigma_gamma
            Lr[3,3] = E[3,3] + np.dot(sg,rho_psi) - 1.0
            Lr[4:,3] = _ix@zg#self.shift_twist_kappa()
        return Lr 

    def shape_shift(self):
        Lv = np.zeros((3,6))
        Xb = self.shift_shear_gamma()
        sa = self.shift_twist_axial()
        sg = self.shift_twist_gamma()
        ic = self.iesan_center() #np.zeros(2) #
        E = self.trace_matrix()
        if False: # Xara
            zg = -Xb@sg
            Lv[0,3] = 1 + np.dot(zg, ic-sa)
            Lv[1:,1:3] = Xb 
            Lv[1:,3]   = zg
        else:
            sg = E[4:,3].flatten() # sigma_gamma
            zk = E[3,1:3].flatten() # zeta_kappa
            Lv[0,1:3] = Xb.T@ic + zk
            Lv[0,3] = ic.dot(sg) + E[3,3]
            Lv[1:,1:3] = Xb
            Lv[1:,3]   = sg
        return Lv
    
    def shear_matrix(self):
        # Return 2x2 shear matrix 
        pass 

    def shear_factors(self):
        # Return two shear factors for y and z directions
        pass

    def solve(self, p):
        return _TraceField(self, p)

    def twist_center(self):
        return self._sv.twist_center()

    def iesan_center(self):
        """
        Compute r_sc := (1/J) ∫ (∇Ψ + Π') (r × i) dA
        """
        # shear_vector
        return self._sv.iesan_center()

    def cse(self, E, G):
        # Tangent stiffness matrix for Saint-Venant torsion and bending
        Kp = self._sv.iesan_matrix(E=E, G=G)
        return Kp@self.trace_matrix()

    def cmm(self, center=None, weight=None):
        return self._sv.cmm(center=center, weight=weight)
    

    def iesan_matrix(self, E=None, G=None):
        return self._sv.iesan_matrix(E=E, G=G)

    def energy_tensor(self, weight=None):
        return self._sv.energy_tensor(weight=weight)

    # def poisson_tensor(self, weight=None):
    #     r"""
    #     Integrate (\Pi_b^T)\Pi_b over the cross-section
    #     """
    #     return self._sv.poisson_tensor(weight=weight)




    def position(self, x: float, p):
        ix = np.array([[0,   0,   0],
                       [0, 0.0,-1.0],
                       [0, 1.0, 0.0]])
        G = np.zeros((6,6))
        G[1:3,4:6] = np.eye(2)
        G[0,  4:6] = - self._sv.centroid()
        Einv = self.trace_inverse()
        eo = Einv@p
        de = Einv@G@p
        return x*eo[:3] - ix@eo[3:6]*0.5*x**2 \
               +0.5*x**2*de[:3]-1/6*x**3*ix@de[3:6]

    def rotation(self, x, p):
        G = np.zeros((6,6))
        G[1:3,4:6] = np.eye(2)
        G[0,  4:6] = - self._sv.centroid()
        Einv = self.trace_inverse()
        eo = Einv@p
        de = Einv@G@p
        return x*eo[3:6] + 0.5*x**2*de[3:6]


class _TraceField:
    def __init__(self, trace, p):
        self._p = p 
        self._trace = trace 

        G = np.zeros((6,6))
        G[1:3,4:6] = np.eye(2)
        G[0,  4:6] = -self._trace._sv.centroid()
        self._G = G
        Ei = self._trace.trace_inverse() 
        e0 = Ei@p 
        de = Ei@G@p 
        self._e0 = e0 
        self._de = de

    def gamma(self, x):
        return (self._e0 + x*self._de)[:3]

    def kappa(self, x):
        return (self._e0 + x*self._de)[3:]

    def strain(self, x, i):
        pass

    def alpha(self, x):
        pass

    def position(self, x: float):
        ix = np.array([[0,   0,   0],
                       [0, 0.0,-1.0],
                       [0, 1.0, 0.0]])
        eo = self._e0 
        de = self._de
        return x*eo[:3] - ix@eo[3:6]*0.5*(x**2) \
               +0.5*x**2*de[:3] - 1/6*(x**3)*ix@de[3:6]


    def rotation(self, x: float):        
        eo = self._e0
        de = self._de
        return x*eo[3:6] + 0.5*(x**2)*de[3:6]


class _GeometricTrace(_Trace):
    def __init__(self, warping, nu, sv=None, u=None, **kwds):
        super().__init__(warping, nu, sv=sv, u=u, **kwds)
        self._avg_pi = None
        self._avg_psi = None

    def mixed_type(self):
        return "UG"

    def _poisson_center(self):
        """
        rho_pi
        """
        nu = self._nu
        rc = self._centroid
        model = self._sv._model

        cmm = self._sv.cmm(center="centroid", weight=None)#[1:,1:]

        TW = _rotation_average_fiber(
            u = lambda fiber: np.block([[0, 0, 0],
                                    [np.zeros((2,1)), 
                                     _shear_poisson(fiber.coord, rc, nu)]]),
            model = model,
            center = rc,
            weight = 1.0,
            balance = cmm
        )
        return (TW.T@[1., 0., 0.]).flatten()[1:]

    def _shear_rotation(self):
        """
        Compute Θ[i⊗Ψ] = I^{-1} ∫ (r - rc) × i⊗Ψ dA
        """
        u = self._u
        rc = self._centroid
        model = self._sv._model
        ix = np.array([[0,-1],[1,0]], dtype=float)

        # def f(fiber):
        #     uy = sum(u[0][model.elems[fiber.cell].nodes])/3.0
        #     uz = sum(u[1][model.elems[fiber.cell].nodes])/3.0
        #     # uy = model.elems[fiber.cell].interp(u[0], fiber.coord)
        #     # uz = model.elems[fiber.cell].interp(u[1], fiber.coord)

        #     return np.array([[0, uy, uz],
        #                      [0,  0,  0],
        #                      [0,  0,  0]])

        # return _rotation_average_fiber(
        #     u = f,
        #     model = model,
        #     center = rc,
        #     weight = 1.0,
        #     balance = self._sv.cmm(center="centroid", weight=1.0)
        # )[1:,1:]

        cmm = self._sv.cmm(center="centroid", weight=None)[1:,1:]

        AT = np.zeros((2,2))
        
        for fiber in model.fibers:
            r = fiber.coord
            ur = (model.elems[fiber.cell].interp(u[0], fiber.coord),
                  model.elems[fiber.cell].interp(u[1], fiber.coord))
            yc,zc = r - rc
            dA = fiber.area

            for j in range(2):
                AT[j] += [
                     zc*ur[j]*dA,
                    -yc*ur[j]*dA
                ]
        return np.linalg.solve(cmm, AT.T)


    def _shift_shear_gamma(self):
        """builds Cowper's ShiftB
        """

        nu = self._nu
        u  = self._u
        rc = self._centroid
        model = self._sv._model

        AW = np.zeros((2,2))
        ix = np.array([[0,-1],[1,0]], dtype=float)
        A  = 0
        
        for fiber in model.fibers:
            r = fiber.coord
            dA = fiber.area
            A += dA
            
            W = _shear_poisson(r, rc, nu)
            AW += W*dA

        # Ω[𝜫] + i × Θ[i⊗Ψ]
        X = AW/A + ix@self._shear_rotation()
        # return np.linalg.inv(X)

        # Θ[𝜫]
        TW = _rotation_average_fiber(
            u = lambda fiber: np.block([[0, 0, 0],
                                    [np.zeros((2,1)), 
                                    _shear_poisson(fiber.coord, rc, nu)]]),
            model = model,
            center = rc,
            weight = 1.0,
            balance = self._sv.cmm(center="centroid", weight=None)
        )
        rp = self._poisson_center()

        Y = -np.outer(ix@self.twist_center(), rp)
        # - rc × Θ[𝜫]
        Y -= (_hat(rc)@TW)[1:,1:]

        if True : #not self._classical:
            X += Y

        return np.linalg.inv(X)


    def _shift_shear_kappa(self): # Xa
        return np.zeros((2,2))
        rho_psi = self._sv.iesan_center()
        rho_phi = self._sv.twist_center()
        Xb = self.shift_shear_gamma()
        RAS = self._shear_rotation()
        return _ix@(np.outer(rho_phi, rho_psi) + RAS)@Xb # TODO; ix@RAS


    def _shift_twist_axial(self):
        Xb = self.shift_shear_gamma() # 𝜩b
        rho_psi = self._sv.iesan_center()
        rho_pi = self._poisson_center()
        shiftT = -Xb@(rho_psi + rho_pi)
        return - np.linalg.solve(Xb, shiftT)

    def _shift_twist_kappa(self):
        return np.zeros(2)
        rho_phi = self.twist_center()
        # compute -ix @ TraceMF @ ShiftB
        ShiftA = self.shift_shear_kappa()
        return -ShiftA @ (_ix @ rho_phi)

    def _shift_twist_gamma(self):
        # return np.zeros(2)
        # return _ix@self.twist_center()
        Xb = self.shift_shear_gamma()
        eta_gam = self.shift_twist_kappa()
        return -np.linalg.solve(Xb, eta_gam)



class _EnergeticTrace(_Trace):
    def __init__(self, warping, nu, sv=None, u=None, **kwds):
        super().__init__(warping, nu, sv=sv, u=u, **kwds)

    def mixed_type(self):
        return "UE"

    def _h_warp_twist(self, weight="g"):
        """
        Compute h_φ := ∫ B_(b)^T b_(φ) dA
        """

        nu = self._nu
        u = self._u  # Ψ: flexural warping
        rc = self._centroid
        model = self._sv._model
        phi = self._sv.solve_twist()
        
        h = np.zeros(2)
        for fiber in model.fibers:
            r = fiber.coord
            dA = model.fiber_weight(fiber, weight=weight)
            
            # B_(b) = (∇Ψ)^T + Π_b
            Du = np.array([
                model.elems[fiber.cell].gradient(u[0], fiber.coord), 
                model.elems[fiber.cell].gradient(u[1], fiber.coord)
            ])
            B_b = Du.T + _shear_poisson(r, rc, nu)
            
            # b_(φ) = i × r + ∇φ
            ixr = np.array([-r[1], r[0]])
            grad_phi = model.elems[fiber.cell].gradient(phi, fiber.coord)
            b_phi = ixr + grad_phi
            
            h += B_b.T @ b_phi * dA

        return h
    
    def _energy_matrix(self):
        def vec(x):
            x = np.asarray(x, dtype=float)
            return x.reshape(2, 1)
        model = self._sv._model

        ic = self.iesan_center()
        rc = self._sv.centroid()
        u_shear = self._sv.solve_shear()
        u_twist = self._sv.solve_twist()
        M = np.zeros((6,6))
        for fiber in model.fibers:
            r = fiber.coord
            dE = model.fiber_weight(fiber, weight="e")
            dG = model.fiber_weight(fiber, weight="g")
            C = np.array([[dE, 0, 0],
                          [0, dG, 0],
                          [0, 0, dG]])
            S = np.array([[1, r[0], r[1],     0, 0, 0],
                          [0,    0,    0,     0, 0, 0],
                          [0,    0,    0,     0, 0, 0]])
            Du_twist = model.cell_gradient(fiber, u_twist)
            Du_shear = np.array([
                model.cell_gradient(fiber, u_shear[0]),
                model.cell_gradient(fiber, u_shear[1])
            ])
            b = _ix@r + Du_twist
            S[1:,3]  += b
            S[1:,4:] += Du_shear.T + _shear_poisson(r, rc, self._nu) + np.outer(b, ic)
            M += S.T @ C @ S

        return M
    
        EA = self._E*self._A #self._sv._EA
        cm  = vec(self._sv.moment_vector()) #vec(self._sv.axial_center(weight="e"))
        GJ  = G*self._sv.torsion_constant(weight="g")
        GH  = G*self._sv.energy_tensor(weight="g")
        EJo = E*self._sv.moment_tensor(center="origin", weight="e")
        EJ  = E*self._sv.moment_tensor(center="centroid", weight="e")
        Gh  = G*self._h_warp_twist(weight="g")
        rs  = self.iesan_center()
        ror = np.outer(rs, rs)
        s = np.block([
            [GJ,                     vec(Gh).T],
            [vec(Gh),    GH+GJ*ror+np.outer(rs, Gh)+np.outer(Gh, rs)]
        ])
        m = np.block([
            [EA, cm.T],
            [cm, EJo]
        ])
        MM = np.block([
            [m,           np.zeros((3,3))],
            [np.zeros((3,3)),    s     ]
        ])

        # from pandas import DataFrame as df
        # print(df(MM))
        # print(df(M))
        return M


    def __trace_matrix(self):
        Kp = self._sv.iesan_matrix()
        Cp = self._energy_matrix()
        return np.linalg.solve(Cp, Kp.T)

    def _shift_shear_gamma(self): # ShiftB
        """
        Return the shear identification matrix (ShiftB)
        """
        T = self.__trace_matrix()
        return T[4:,1:3]

        Gh = self._h_warp_twist(weight="g")
        GJ = self._sv.torsion_constant(weight="g")
        GH = self._sv.energy_tensor(weight="g") - np.outer(Gh, Gh)/GJ
        EJ = self._sv.moment_tensor(center="centroid", weight="e")
        X = np.linalg.solve(GH, EJ)
        return X

    def _shift_shear_kappa(self): # ShiftA
        return np.zeros((2,2))

    def _shift_twist_axial(self): # 𝝆𝜘 ()
        T = self.__trace_matrix()
        zk = T[3, 1:3]
        Xb = self.shift_shear_gamma()
        return -np.linalg.solve(Xb, zk)

        J = self._sv.torsion_constant()
        h = self._h_warp_twist()
        rs = self.iesan_center()
        return rs + h / J

    def _shift_twist_gamma(self): # 𝝆𝛾
        T = self.__trace_matrix()
        zg = T[4:,3]
        Xb = self.shift_shear_gamma()
        return -np.linalg.solve(Xb, zg)

        rk = self.shift_twist_axial()
        EJ = self._sv.moment_tensor(center="centroid", weight="e")
        GJ = self._sv.torsion_constant(weight="g")
        return np.linalg.solve(EJ, rk*GJ)

    def _shift_twist_kappa(self): # 𝜼𝛾 = ShiftF
        return np.zeros(2)
    
    # def _shift_shear_axial(self):
    #     return np.zeros(2)