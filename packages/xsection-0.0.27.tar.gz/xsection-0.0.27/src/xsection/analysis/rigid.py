
"""
- rigid
- plane
 moment
 torsion

  - cnn = EA  = Ce
  - Cmm = EJo
  - Cvv = EJg
  - cv
- twist
- shear

emnvwesux
single_moment
double_moment 
moment_matrix
venant_moment 
twist_rigidity


cnn = EA
cnm = EQy, EQz
cmm = EJo
css = EJg
cxx = GJ
csx = cnm/cnn
nmxs
"""

class RigidAnalysis:
    def __init__(self, section):
        self.section = section