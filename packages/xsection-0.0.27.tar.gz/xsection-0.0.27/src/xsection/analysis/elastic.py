import numpy as np

class ElasticAnalysis:
    def __init__(self, shape, materials, reference: str=None):
        from .venant import SaintVenantSectionAnalysis
        self._sv = SaintVenantSectionAnalysis(shape, materials=materials)
        if reference is None:
            if shape._is_composite:
                raise ValueError("Reference material must be provided for composite sections")
            reference = {"E": 1.0, "G": 1.0}
        elif isinstance(reference, (str,int)):
            reference = materials[reference]
        self._E = reference["E"]
        self._G = reference["G"]

        self._J = None
    
    @property 
    def J(self):
        if self._J is not None:
            return self._J

        u  = self._sv.solve_twist()
        model = self._sv._model

        J0 = 0.0
        ix = np.array([[0, -1],[1, 0]], dtype=float)
        for fiber in model.fibers:
            r = fiber.coord
            dA = model.fiber_weight(fiber, weight="g")
            # dA = fiber.area

            # ∇Ψ (2×2): Du[j] = ∇Ψ_j, so Du = ∇Ψ
            Du = model.elems[fiber.cell].gradient(u, fiber.coord)

            # r × i: using r×i = [0, z, -y]^T
            ixr = ix@r

            # (∇Ψ + Π') @ (r × i)
            J0 += (Du @ ixr + np.dot(r,r))*dA
        
        return float(J0)/self._G