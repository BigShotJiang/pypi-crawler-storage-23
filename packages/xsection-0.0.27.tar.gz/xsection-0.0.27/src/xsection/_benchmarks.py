import re
from xsection.library import (
    Channel, Rectangle, WideFlange, HollowRectangle, Angle, 
    SingleCellGirder,
    from_aisc
)

from xsection.library._girder import GirderSection




def load_shape(shape_name, nu=None, units=None, material=None, mesh_type="T6", mesh_scale=1):
    import os
    ms = os.getenv("nf", None)
    if ms is not None:
        ms = int(ms)


    match shape_name:
        case 1 | "R01":
            shape = Rectangle(d=14, 
                              b=8, 
                                poisson=nu,
                                mesh_scale=1/(ms or 20), 
                                mesher="gmsh",
                                material=material,
                                mesh_type=mesh_type
                    ) #

        # Hollow Rectangle
        case str() as name if re.fullmatch(r"H0[1-6]", name):
            # Armero
            pass 

        case 2: # h07
            # T = T or 0.0
            shape = HollowRectangle(d=14, b=8, t=1,
                                    mesh_scale=1/(ms or 5),
                                    poisson=nu,
                                    mesher="gmsh",
                                    material=material,
                                    mesh_type=mesh_type)
        case 3: # h08
            # Le Corvec, Figure 3.25
            shape = HollowRectangle(d=1*units.ft, 
                                    b=1*units.ft, 
                                    tw=0.05*units.ft,
                                    tf=0.1*units.ft,
                                    mesh_scale=1/(ms or 5),
                                    poisson=nu,
                                    material=material,
                                    mesh_type=mesh_type,
                                    mesher="gmsh")
        
        #
        # Channels
        #
        case "C01" | "c01":
            # G, S & W, 6.2
            shape = Channel(
                    tf =  1.6,
                    tw =  1.0,
                    b  = 10.0,
                    d  = 30.0,
                    poisson=0.3,
                    material=material,
                    mesh_scale=1/(ms or 10),
                    # centroid=(0,0),
                    mesher="gmsh"
                )
        case 4 | "C05":
            shape = Channel(d=14, 
                            b=8, 
                            t=1,
                            mesh_scale=1/(ms or 4),
                            poisson=nu,
                            material=material,
                            mesh_type=mesh_type,
                            mesher="gmsh")
            
        # Angles
        case "A04":
            # Pilkey, Table 6.8, also Schramm (1994)
            pass
        #
        # Wide Flanges
        #
        case 5:
            #   18x40
            shape = from_aisc("W14x48", 
                              units=units, 
                              mesh_scale=1, 
                              fillet=True, 
                              mesher="gmsh")
        case 6:
            # Le Corvec
            shape = WideFlange(
                    d  = 1,
                    b  = 1,
                    tf = 0.05,
                    tw = 0.05,
                    poisson=nu,
                    material=material,
                    mesh_scale=1/(ms or 5),
                    mesher="gmsh"
            )
            
        # Girders
        case "G01" | "painter-girder":
            if units is None:
                import xara.units.english as u 
            else:
                u = units
            shape = GirderSection(
                web_slope      = 0.5,
                thickness_top  = (7 + 1/2)  * u.inch,
                thickness_bot  = (5 + 1/2)  * u.inch,
                height         = 5*u.ft + 8*u.inch,
                width_top      = 2*26 * u.ft,
                width_webs     = [12*u.inch]*7,
                web_spacing    = 7*u.ft + 9*u.inch,
                overhang       = 2*u.ft + 6*u.inch,
                mesh_scale     = 1/(ms or 3),
                # poisson=0.3,
                material=material,
                mesher="gmsh"
            )

        case "G02":
            # Gruttmann, Wagner (2001)
            if material is not None:
                raise ValueError("Material is defined in the shape definition for G02")
            shape = SingleCellGirder(
                d=3.45, 
                br6=7.60,
                # br5=7.50,
                br4=4.50,
                br3=3.75,
                br2=3.50,
                br1=2.00,

                tr5=0.3,
                tr4=0.45,
                tr3=0.75,
                tr2=0.45,
                tr1=0.30,

                bs1=2.50,
                bs2=3.30,
                bs3=3.65,
                ts1=0.3,
                ts2=0.60,
                material={"E": 1, "G": 1/(2*(1+0.2))},
                mesh_scale=mesh_scale, 
                mesh_type=mesh_type,
                mesher="gmsh"
            )
        
        case "M01":
            # Armero Section 7.5
            if material is not None:
                raise ValueError("Material is defined in the shape definition for M01")
            shape = ShapeM01(mesh_type=mesh_type)

    return shape



def ShapeM01(mesh_type="T3"):
    # Section 7.5 of Armero's report

    from xsection.library import DoubleFlange, Rectangle
    from xsection import CompositeSection
    from xara import Section, Material 
    G = 76.92
    E = 200.0

    materials = {
        "1": Material(E=E, G=G),
        "2": Material(E=E/10, G=G/10)
    }

    h = 50
    t = 0.04*h
    bot = DoubleFlange(d=h, 
                       b2=0.3*h, 
                       b1=0.6*h, 
                       t2=1.25*t,
                       t1=t, 
                       tw=t, 
                       group="1", 
                       material=materials["1"],
                       mesh_scale=1/30
    )

    d = 0.2*h
    top = Rectangle(d=d, b=h, group="2", mesh_scale=1/40, material=materials["2"])
    top = top.translate([0, d/2+t/2])

    return CompositeSection([top, bot])
