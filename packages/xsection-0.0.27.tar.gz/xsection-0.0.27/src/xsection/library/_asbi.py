
from xsection.polygon import PolygonSection
from xsection.library._simple import _SimpleShape
import numpy as np

#     |          Symmetric               |<-- br6    ---------------------->|
#                                        |    br5                    |      .
#                                        |    br4                |   .      .
#                                        |    br3            |   .   .      .
#                                        |    br2         |  .   .   .      .
#                                        |    br1         .  .   .   .      .
#                                               .         .  .   .   .      .
#                                               .         .  .   .   .      .
#                                        z      .         .  .   .   .      .
#                                        ^      .         .  .   .   .      .
#                                        |      .         .  .   .   .      .
# _   |_________________________________________|_________|__|___|___|______|
#     |-------____      _________.--------------._________   |   |,..-------|
#                 \    /                                   \ |  /
# d                \  /                  |                  \| /
#                   \ \                  |                  / /
#                    \ `----._________________________,----  /
# _                   \__________________+__________________/  ---> y
#                                        |   bs3      .    .|
#                                        |   bs2      .    |
#                                        |   bs1      |



class SingleCellGirder(_SimpleShape):
    _parameters = [
        "d",
        "br6",
        "br5",
        "br4",
        "br3",
        "br2",
        "br1",
        "tr5",
        "tr4",
        "tr3",
        "tr2",
        "tr1",
        "bs3",
        "bs2",
        "bs1",
        "ts1",
        "ts2",
    ]
    def __init__(self,
                 d      : float,
                 # Roadway
                 br6    : float,
                 br4    : float,
                 br3    : float,
                 br1    : float,
                 tr5    : float,
                 tr4    : float,
                 tr3    : float,
                 tr1    : float,
                 # Soffit
                 bs3    : float,
                 bs1    : float,
                 ts1    : float,

                 br5    : float = None,
                 bs2    : float = None,
                 ts2    : float = None,

                 br2   : float = None,
                 tr2   : float = None,
                 rr2   : float = 0.0,
                 rr1   : float = 0.0,
        mesh_scale     : float = 1/2,
        **kwds
        ):
        self.d = d
        self.br6 = br6
        self.br5 = br5
        self.br4 = br4
        self.br3 = br3
        self.br2 = br2
        self.br1 = br1
        self.tr5 = tr5
        self.tr4 = tr4
        self.tr3 = tr3
        self.tr2 = tr2
        self.tr1 = tr1
        self.bs3 = bs3
        self.bs2 = bs2
        self.bs1 = bs1
        self.ts1 = ts1
        self.ts2 = ts2

        self.width_top = br6*2
        self.width_bot = bs3*2



        mesh_size = tr1*mesh_scale

        H = d


        # 1) exterior ring (cw)
        exterior = np.array([
            (-br6,         H),
            (+br6,         H),
            (+br6,         H-tr5),
        ] + ([
            (+br5,         H-tr5),  #
        ] if br5 is not None else []) + [
            (+br4,         H-tr4),
            (+bs3,         0),
            (-bs3,         0),
            (-br4,         H-tr4),
        ] + ([
            (-br5,         H-tr5),  #
        ] if br5 is not None else []) + [
            (-br6,         H-tr5),
        ])

        interiors = [np.array([
                (-br3, H-tr3),
            ] + ([
                (-br2, H-tr2), # fillet
            ] if tr2 is not None else []) + [
                (-br1, H-tr1),
                (+br1, H-tr1),
            ] + ([
                (+br2, H-tr2), # fillet
            ] if tr2 is not None else []) + [
                (+br3, H-tr3),
            ] + ([
                (+bs2,  +ts2),
            ] if ts2 is not None else []) + [
                (+bs1,  +ts1),
                (-bs1,  +ts1),
            ] + ([
                (-bs2,  +ts2),
            ] if ts2 is not None else [])
        )]
        

        super().__init__(exterior, interiors, mesh_size=mesh_size, **kwds)
    


_MetricKeys = {
    "1800-1",
    "1800-2",
    "2100-1", # TODO(SS)
    "2100-2", # TODO(SS)
    "2400-1", # TODO(SS,BC)
    "2400-2", # TODO(SS,BC)
    "2700-1", #
    "2700-2", # TODO(BC)
    "3000-1", # NOTE: Only BC
    "3000-2", # TODO(BC)
}

# https://asbi-assoc.org/wp-content/uploads/2023/07/Box-Girder-Segments-PCIASBIEnglish.pdf

_EnglishKeys = {
    "6-1",
    "6-2",
    "7-1",
    "7-2",
    "8-1",
    "8-2",  # SS,BC
    "9-1",  # BC
    "9-2",  # BC
    "10-1", # BC
    "10-2", # BC
}


def create_asbi(name, units=None, fillet=False, **kwds)->SingleCellGirder:
    """
    Create a single-cell box girder section from the AASHTO-PCI-ASBI specification.

    Parameters:
        identifier: str
            Identifier with the form <type>-<depth>-<variant>+<overhang>
        units: object


    https://asbi-assoc.org/wp-content/uploads/2023/07/Box-Girder-Segments-PCIASBIMetric.pdf
    https://asbi-assoc.org/wp-content/uploads/2023/07/Box-Girder-Segments-PCIASBIEnglish.pdf
    """

    key = name.split("+")[0]
    construction = key.split("-")[0]
    key = key[len(construction)+1:]

    if fillet:
        raise NotImplementedError

    if "+" in name:
        A = float(name.split("+")[1])
        overhang = True 
    else:
        A = 0.0
        overhang = False


    if units is None:
        if key in _MetricKeys:
            import xara.units.si as units


    shape = None

    match construction:
        case "SS":
            # Span-by-span
            match key:
                case "1800-1":
                    shape = SingleCellGirder(
                        d=1800*units.mm,
                        br6=(1361+1200+269+1370+A)*units.mm,
                        br5=(1361+1200+269+1370)*units.mm if overhang else None,
                        br4=(1361+1200+269)*units.mm,
                        br3=(1361+1200)*units.mm,
                        br1=1361*units.mm,
                        tr5=225*units.mm,
                        tr4=350*units.mm,
                        tr3=350*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(2061+189)*units.mm,
                        bs1= 2061*units.mm,
                        ts1= 200*units.mm,
                        **kwds,
                    )
                case "1800-2":
                    shape = SingleCellGirder(
                        d=1800*units.mm,
                        br6=(1607+1500+323+1970+A)*units.mm,
                        br5=(1607+1500+323+1970)*units.mm if overhang else None,
                        br4=(1607+1500+323)*units.mm,
                        br3=(1607+1500)*units.mm,
                        br1=1607*units.mm,
                        tr5=225*units.mm,
                        tr4=350*units.mm,
                        tr3=350*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(2607+243)*units.mm,
                        bs1= 2607*units.mm,
                        ts1= 200*units.mm,
                        **kwds,
                    )
        case "BC":
            # Balanced cantilever construction with raised soffit
            match key:
                case "1800-1":
                    shape = SingleCellGirder(
                        d=1800*units.mm,
                        br6=(1255+1200+323+1422+A)*units.mm,
                        br5=(1255+1200+323+1422)*units.mm if overhang else None,
                        br4=(1255+1200+323)*units.mm,
                        br3=(1255+1200)*units.mm,
                        br1=1255*units.mm,
                        tr5=225*units.mm,
                        tr4=480*units.mm,
                        tr3=480*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(2107+143)*units.mm,
                        bs2= 2107*units.mm,
                        bs1=(2107-900)*units.mm,
                        ts1= 225*units.mm,
                        ts2=(225+225)*units.mm,
                        **kwds,
                    )
                case "1800-2":
                    shape = SingleCellGirder(
                        d=1800*units.mm,
                        br6=(1528+1500+350+2022+A)*units.mm,
                        br5=(1528+1500+350+2022)*units.mm if overhang else None,
                        br4=(1528+1500+350)*units.mm,
                        br3=(1528+1500)*units.mm,
                        br1=1528*units.mm,
                        tr5=225*units.mm,
                        tr4=480*units.mm,
                        tr3=480*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(2680+170)*units.mm,
                        bs2= 2680*units.mm,
                        bs1=(2680-900)*units.mm,
                        ts1= 225*units.mm,
                        ts2=(225+225)*units.mm,
                        **kwds,
                    )
                case "2100-1":
                    # Page 7
                    shape = SingleCellGirder(
                        d=2100*units.mm,
                        br6=(1228+1200+350+1422+A)*units.mm,
                        br5=(1228+1200+350+1422)*units.mm if overhang else None,
                        br4=(1228+1200+350)*units.mm,
                        br3=(1228+1200)*units.mm,
                        br1=1228*units.mm,
                        tr5=225*units.mm,
                        tr4=480*units.mm,
                        tr3=480*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(1960+170)*units.mm,
                        bs2= 1960*units.mm,
                        bs1=(1960-900)*units.mm,
                        ts1= 225*units.mm,
                        ts2=(225+225)*units.mm,
                        **kwds
                    )

                case "2100-2":
                    shape = SingleCellGirder(
                        d=2100*units.mm,
                        br6=(1501+1500+377+2022+A)*units.mm,
                        br5=(1501+1500+377+2022)*units.mm if overhang else None,
                        br4=(1501+1500+377)*units.mm,
                        br3=(1501+1500)*units.mm,
                        br1=1501*units.mm,
                        tr5=225*units.mm,
                        tr4=480*units.mm,
                        tr3=480*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(2533+197)*units.mm,
                        bs2= 2533*units.mm,
                        bs1=(2533-900)*units.mm,
                        ts1= 225*units.mm,
                        ts2=(225+225)*units.mm,
                        **kwds
                    )

                case "2700-1":
                    shape = SingleCellGirder(
                        d=2700*units.mm,
                        br6=(1174+1200+404+1422+A)*units.mm,
                        br5=(1174+1200+404+1422)*units.mm if overhang else None,
                        br4=(1174+1200+404)*units.mm,
                        br3=(1174+1200)*units.mm,
                        br1=1174*units.mm,
                        tr5=225*units.mm,
                        tr4=480*units.mm,
                        tr3=480*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(1666+224)*units.mm,
                        bs2= 1666*units.mm,
                        bs1=(1666-900)*units.mm,
                        ts1= 225*units.mm,
                        ts2=(225+225)*units.mm,
                        **kwds
                    )
                case "3000-1":
                    shape = SingleCellGirder(
                        d=3000*units.mm,
                        br6=(1147+1200+431+1422+A)*units.mm,
                        br5=(1147+1200+431+1422)*units.mm if overhang else None,
                        br4=(1147+1200+431)*units.mm,
                        br3=(1147+1200)*units.mm,
                        br1=1147*units.mm,
                        tr5=225*units.mm,
                        tr4=480*units.mm,
                        tr3=480*units.mm,
                        tr1=225*units.mm,
                        # Soffit
                        bs3=(1519+251)*units.mm,
                        bs2= 1519*units.mm,
                        bs1=(1519-900)*units.mm,
                        ts1= 225*units.mm,
                        ts2=(225+225)*units.mm,
                        **kwds
                    )

    if shape is None:
        raise ValueError(f"Unknown ASBI section: {name}")
    shape.units = units
    return shape