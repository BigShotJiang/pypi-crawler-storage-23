
from xsection.library import Rectangle, Circle

def torsion_constant(shape, formula=None)->float:
    r"""
    
    Rectangle
    ---------
    ``formula=None``: From young2011roarks
    .. math::
       J \approx a b^3\left(\frac{16}{3}-3.36 \frac{b}{a}\left(1-\frac{b^4}{12 a^4}\right)\right)
    """
    if formula == "all":
        return {
            key: torsion_constant(shape, formula=key) for key in torsion_constant(shape, "list")
        }


    if isinstance(shape, Rectangle):
        if formula == "list":
            return ["roark"]
        width, depth = shape.b, shape.d 
        a = max(width, depth)/2
        b = min(width, depth)/2
        if formula is None or formula == "roark":
            return a*b**3 * (16/3 - 3.36*(b/a)*(1 - b**4/(12*a**4)))
        else:
            raise ValueError(f"Unknown formula {formula} for rectangle torsion constant")