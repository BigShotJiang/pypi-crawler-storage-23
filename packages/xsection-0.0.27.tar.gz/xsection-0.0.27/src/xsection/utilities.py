
# import numpy as np

# def orthogonalize(v1, v2, v3, *, normalize=False, atol=1e-12):
#     """
#     Make three vectors mutually orthogonal.
#     - normalize=True  → return orthonormal vectors
#       normalize=False → keep original norms
#     """
#     V = np.column_stack([np.asarray(v1), np.asarray(v2), np.asarray(v3)])  # (n,3)

#     # Householder-QR is stable and simple
#     Q, R = np.linalg.qr(V, mode="reduced")  # Q: (n,3), R: (3,3)

#     # Guard against (near) linear dependence
#     if np.min(np.abs(np.diag(R))) < atol:
#         raise ValueError("Input vectors are nearly linearly dependent; can't produce 3 independent orthogonal vectors.")

#     if normalize:
#         u1, u2, u3 = Q.T
#     else:
#         # Rescale to the original norms
#         norms = np.linalg.norm(V, axis=0)
#         Q = Q * norms
#         u1, u2, u3 = Q.T

#     return u1, u2, u3
