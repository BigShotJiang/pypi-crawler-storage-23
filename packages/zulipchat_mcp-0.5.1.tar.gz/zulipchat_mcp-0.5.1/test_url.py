import asyncio
from src.zulipchat_mcp.core.client import ZulipClientWrapper
from src.zulipchat_mcp.config import ConfigManager

def test_resolve():
    cm = ConfigManager()
    client = ZulipClientWrapper(config_manager=cm)
    
    # Just mock client.client to avoid network calls if necessary
    from src.zulipchat_mcp.tools.files import _resolve_file_url
    
    # Let's say client.base_url is populated from somewhere
    # Since we can't connect, we'll just mock base_url
    client._base_url = "https://ai4hpc.zulipchat.com/api/"
    
    url = _resolve_file_url(client, "/user_uploads/80757/B-iA4W9ofPWWANFH2qdKNcNQ/issue3-1771776447-user.txt")
    print("Resolved URL:", url)

test_resolve()
