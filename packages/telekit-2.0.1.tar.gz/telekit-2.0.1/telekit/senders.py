# 
# Copyright (C) 2026 Romashka
# 
# This file is part of Telekit.
# 
# Telekit is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License as published by 
# the Free Software Foundation, either version 3 of the License, or 
# (at your option) any later version.
# 
# Telekit is distributed in the hope that it will be useful, 
# but WITHOUT ANY WARRANTY; without even the implied warranty 
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See 
# the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License 
# along with Telekit. If not, see <https://www.gnu.org/licenses/>.
# 

from typing import Any, Literal
import textwrap
import io

from telebot import TeleBot
from telebot.types import (
    Message, InputMediaPhoto, InputFile, InputMediaAudio, InputMediaDocument, InputMediaVideo
)

from telekit.styles import TextEntity, Raw, Group, Bold, Italic
from telekit.types import ParseMode, Effect as _Effect, ChatAction as _ChatAction
from telekit import dices
from ._logger import logger
library = logger.library

__all__ = [
    "TempMessageStore",
    "BaseSender", "Sender"
]

# ---------------------------------------------------------------------------------
# Temporary Messages Manager
# ---------------------------------------------------------------------------------

class TempMessageStore:

    _temporary_messages: dict[int, set[int]] = {}

    @classmethod
    def add_temporary(cls, chat_id: int, message_id: int):
        if chat_id not in cls._temporary_messages:
            cls._temporary_messages[chat_id] = {message_id}
        else:
            messages: set[int] | None = cls._temporary_messages.get(chat_id, None)

            if messages is not None:
                messages.add(message_id)

    @classmethod
    def remove_temporary(cls, bot: TeleBot, chat_id: int):
        user_temps = cls._temporary_messages.get(chat_id, None)

        if user_temps:
            try:
                for _id in user_temps:
                    cls.delete(bot, chat_id, _id)

                cls._temporary_messages.pop(chat_id, None)
            except:
                pass

    @classmethod
    def delete(cls, bot: TeleBot, chat_id: int, message_id: int) -> bool:
        try:
            return bot.delete_message(chat_id, message_id)
        except:
            return False
    
    @classmethod
    def debug(cls, chat_id: int | None=None) -> dict[str, int]:
        return {
            "v.all_temps": len(cls._temporary_messages),
            "v.user_temps": len(cls._temporary_messages.get(chat_id, "")) # type: ignore
        }

# ---------------------------------------------------------------------------------
# Base Sender
# ---------------------------------------------------------------------------------

class BaseSender:

    bot: TeleBot

    Effect: type[_Effect] = _Effect
    ChatAction: type[_ChatAction] = _ChatAction

    @classmethod
    def _init(cls, bot: TeleBot):
        """
        Initializes the bot instance for the class.

        Args:
            bot (TeleBot): The Telegram bot instance to be used for sending messages.
        """
        cls.bot = bot

    parse_mode: Literal["html", "markdown"] | None

    def __init__(
            self,
            chat_id: int,

            text: str = "",
            reply_markup = None,

            is_temporary: bool = False,
            delele_temporaries: bool = True,
            
            parse_mode: Literal["html", "markdown"] | ParseMode | None = "html",
            reply_to_message_id: int | None = None,

            edit_message_id: int | None = None,

            thread_id: int | None = None,
            effect_id: str | None = None,

            photo: str | None = None,
            document: str | Any = None,
            video_note: str | Any = None,  
            animation: str | Any = None,
            video: str | Any = None,
            audio: str | Any = None,
            voice: str | Any = None,
            ):
        """
        Initializes the BaseSender object with message details.

        Args:
            chat_id (int): The ID of the chat to send messages to.
            text (str): The text of the message. Default is an empty string.
            reply_markup: Optional markup for adding inline buttons or keyboards.
            is_temp (bool): Whether the message is temporary. Default is False.
            del_temps (bool): Whether to delete temporary messages. Default is True.
            parse_mode (str): Parse mode for message formatting. Default is 'HTML'.
            reply_to_message_id (int): Optional ID of a message to reply to.
            edit_message_id (int): Optional ID of the message to edit.
        """
        self.chat_id = chat_id
        
        self.text = text
        self.reply_markup = reply_markup
        
        self.is_temporary = is_temporary
        self.delele_temporaries = delele_temporaries

        self.set_parse_mode(parse_mode)
        self.reply_to_message_id = reply_to_message_id

        self.edit_message_id = edit_message_id

        self.thread_id = thread_id
        self.message_effect_id = effect_id

        self.photo = photo
        self.document = document
        self.video = video
        self.animation = animation
        self.audio = audio
        self.voice = voice  
        self.video_note = video_note

        self.venue = []
        self.media = []

        self._do_remove_text = True
        self._do_remove_attachments = True

    # --------------------------------------------------------
    # Setter methods for configuring media attachments
    # --------------------------------------------------------

    def set_photo(self, photo: str | None | Any):
        """
        Sets the photo for the message.
         
        Accepts:
            - URL string (`"http://..."` or `"https://..."`)
            - local file path
            - bytes or file-like object
            - `None` to remove any previously set photo
        
        :param photo: The photo for the message
        :type photo: str | None | Any
        """
        if photo is None:
            self.photo = None
            return

        self.remove_attachments()
        self.photo = self._load_item(photo)

    def set_document(self, document: str | None | Any):
        """
        Sets the document for the message.
         
        Accepts:
            - URL string (`"http://..."` or `"https://..."`)
            - local file path
            - bytes or file-like object
            - `None` to remove any previously set document
        
        :param document: File to send.
        :type document: str | None | Any
        """
        if document is None:
            self.document = None
            return

        self.remove_attachments()
        self.document = self._load_item(document)

    def set_text_as_document(self, text: str | None, name: str="text.txt", encoding: str="utf-8"):
        """
        Set a text string as a document to be sent.

        This method converts the given text into an in-memory file-like object (`BytesIO`) 
        and sets it as a document. The provided `name` is only a **placeholder filename** 
        for Telegram; no actual file is created on disk.
            
        :param text: The text content to convert into a document. If None, removes any previously set document.
        :type text: str | None
        :param name: The placeholder filename for the document (default "text.txt").
        :type name: str
        :param encoding: The text encoding used to convert the string to bytes (default "utf-8").
        :type encoding: str
        """
        if text is None:
            self.set_document(None)
            return
        
        document = io.BytesIO(text.encode(encoding))
        document.name = name

        self.set_document(document)

    def set_video(self, video: str | None | Any):
        """
        Sets the video for the message.
         
        Accepts:
            - URL string (`"http://..."` or `"https://..."`)
            - local file path
            - bytes or file-like object
            - `None` to remove any previously set video
        
        :param video: The video for the message
        :type video: str | None | Any
        """
        if video is None:
            self.video = None
            return

        self.remove_attachments()
        self.video = self._load_item(video)

    def set_animation(self, animation: str | None | Any):
        """
        Sets the animation for the message.
         
        Accepts:
            - URL string (`"http://..."` or `"https://..."`)
            - local file path
            - bytes or file-like object
            - `None` to remove any previously set animation
        
        :param animation: The animation for the message
        :type animation: str | None | Any
        """
        if animation is None:
            self.animation = None
            return

        self.remove_attachments()
        self.animation = self._load_item(animation)

    def set_audio(self, audio: str | None | Any):
        """
        Sets the audio for the message.
         
        Accepts:
            - URL string (`"http://..."` or `"https://..."`)
            - local file path
            - bytes or file-like object
            - `None` to remove any previously set audio
        
        :param audio: The audio for the message
        :type audio: str | None | Any
        """
        if audio is None:
            self.audio = None
            return

        self.remove_attachments()
        self.audio = self._load_item(audio)

    def set_voice(self, voice: str | None | Any):
        """
        Sets the voice for the message.
         
        Accepts:
            - URL string (`"http://..."` or `"https://..."`)
            - local file path
            - bytes or file-like object
            - `None` to remove any previously set voice
        
        :param voice: The voice for the message
        :type voice: str | None | Any
        """
        if voice is None:
            self.voice = None
            return

        self.remove_attachments()
        self.voice = self._load_item(voice)

    def set_video_note(self, video_note: str | None | Any):
        """
        Sets the video note for the message.
         
        Accepts:
            - local file path
            - bytes or file-like object
            - `None` to remove any previously set video note
            
        Sending video notes by a URL is currently unsupported.
        
        :param video_note: The video note for the message
        :type video_note: str | None | Any

        """
        if video_note is None:
            self.video_note = None
            return

        self.remove_attachments()
        video_note = self._load_item(video_note)

        if isinstance(video_note, str) and video_note.startswith(("http://", "https://")):
            raise ValueError("Sending video notes by a URL is currently unsupported")

        self.video_note = video_note

    def set_venue(
            self, 
            latitude: float | None, 
            longitude: float | None, 
            title: str,
            address: str,
            foursquare_id: str | None = None,
            foursquare_type: str | None = None,
        ):
        """
        Sets the venue for the message.
        """
        self.bot.send_venue
        
        self.remove_attachments()
        self.venue = [
            latitude, longitude, 
            address, title,
            foursquare_id, foursquare_type
        ]

    def _load_item(self, item: str | Any):
        if not isinstance(item, str):
            return item

        if item.startswith(("http://", "https://")):
            return item
        
        with open(item, "rb") as item:
            return item.read()

    def set_media(self, *media: str | Any):
        """
        Sets the photos to be sent as InputMediaPhoto objects.
        
        Accepts:
            - URLs
            - local file paths
            - bytes or file-like objects
            - instances of `InputMediaPhoto`
        """
        if not media:
            self.media: list[InputMediaPhoto] = []
            return

        self.remove_attachments()

        for m in media:
            if isinstance(m, InputMediaPhoto):
                self.media.append(m)
                continue

            if not isinstance(m, str):
                # assume it's a file-like object or bytes
                self.media.append(InputMediaPhoto(media=m))
                continue

            if m.startswith(("http://", "https://")):
                self.media.append(InputMediaPhoto(media=m))
                continue

            # assume it's a local file path
            self.media.append(InputMediaPhoto(media=InputFile(open(m, "rb"))))

    def _prepare_media(self):
        if self.media:
            def f(media: InputMediaPhoto):
                media.parse_mode = self._get_parse_mode()
                return media
            self.media[0].caption = self.text
            self.media = list(map(f, self.media))

    # --------------------------------------------------------
    # Setter methods for configuring message properties
    # --------------------------------------------------------

    def set_message_effect_id(self, effect: str):
        """
        Sets the message effect by string ID. Low-level version of the `set_effect` method
        
        :param effect: Effect ID
        :type effect: str
        """
        self.message_effect_id = effect

    def set_effect(self, effect: _Effect | str | int):
        """
        Sets a message effect using enum, string, or integer.
        
        :param effect: Integer, String, or Enum representing the message effect
        :type effect: Effect | str | int
        """
        self.message_effect_id = str(effect)

    def set_chat_id(self, chat_id: int):
        """
        Sets the chat ID for sending messages
        
        :param chat_id: The telegram chat ID
        :type chat_id: int
        """
        self.chat_id = chat_id

    def set_text(self, text: str):
        """
        Sets the plain text of the message.
        
        :param text: A simple text message. Not sanitized. HTML and Markdown tags are allowed
        :type text: str
        """
        self.text = text

    def set_reply_markup(self, reply_markup):
        """
        Sets Inline keyboards, reply keyboards, or other markup objects
        """
        self.reply_markup = reply_markup

    def set_temporary(self, is_temp: bool):
        """
        Marks message as temporary; will be deleted later if `delete_temporaries` is True.  
        """
        self.is_temporary = is_temp

    def set_delete_temporaries(self, del_temps: bool):
        """
        Whether to delete temporary messages in the chat.  
        """
        self.delele_temporaries = del_temps

    def set_parse_mode(self, parse_mode: Literal["html", "markdown"] | ParseMode | None):
        """
        Sets the parse mode to the message
        
        :param parse_mode: `html`, `markdown` or `None`.  
        :type parse_mode: str | None
        """
        match parse_mode:
            case ParseMode():
                self.parse_mode = parse_mode.value
            case "html":
                self.parse_mode = "html"
            case "markdown":
                self.parse_mode = "markdown"
            case None:
                self.parse_mode = None
            case _:
                raise ValueError("Invalid Parse Mode")

    def set_reply_to_message_id(self, reply_to_message_id: int | None):
        """
        Reply to specific message by ID.
        """
        self.reply_to_message_id = reply_to_message_id

    def set_edit_message_id(self, edit_message_id: int | None):
        """
        Edit an existing message by ID.
        """
        self.edit_message_id = edit_message_id

    def set_edit_message(self, edit_message: Message | None):
        """
        Edit a specific message by its `Message` object.  
        """
        if edit_message is None:
            self.edit_message_id = None
            return

        if getattr(edit_message, "message_id", None) is not None:
            self.edit_message_id = edit_message.message_id

    def set_reply_to(self, reply_to: Message | None):
        """
        Reply to a specific message by its `Message` object.  
        """
        if reply_to is None:
            self.reply_to = None
            return

        if getattr(reply_to, "message_id", None) is not None:
            self.reply_to_message_id = reply_to.message_id

    def append(self, *args, **kwargs): # TODO
        """
        Placeholder method in `BaseSender` that does **not perform any action**.
        """
        library.warning("BaseSender().append() called; method does nothing")

    # --------------------------------------------------------
    # Reset logic
    # --------------------------------------------------------

    def set_remove_attachments(self, remove_attachments: bool = True):
        """
        Controls whether sender attachments are automatically cleared after each send.

        When `True` (default), attachments such as photo, document, audio, and others
        are removed from the sender after the message is sent, so they don't
        accidentally appear in the next message.

        Set to `False` to preserve attachments across multiple sends.

        See also: `set_remove_text()`
        """
        self._do_remove_attachments = remove_attachments

    def set_remove_text(self, remove_text: bool = True):
        """
        Controls whether text content is automatically cleared after each send.

        Set to `False` to preserve text content across multiple sends.

        See also: `set_remove_attachments()`
        """
        self._do_remove_text = remove_text

    def reset(self):
        """
        Clears sender's text content and attachments.
        """
        self.remove_text()
        self.remove_attachments()

    def _reset_after_send(self):
        if self._do_remove_text:
            self.remove_text()
        if self._do_remove_attachments:
            self.remove_attachments()

    def remove_text(self):
        self.text = ""

    def remove_attachments(self):
        """
        Clear all attachments from the sender:

        The following fields are reset to their default empty values:
        - `photo`, `document`, `animation`, `video`, `video_note`
        - `audio`, `voice`, `venue`, `media`

        But `text`, `parse_mode`, and other non-attachment properties are preserved.
        """
        self.media: list[InputMediaPhoto] = []
        self.video_note: str | Any = None
        self.animation: str | Any = None
        self.document: str | Any = None
        self.photo: str | Any = None
        self.video: str | Any = None
        self.audio: str | Any = None
        self.voice: str | Any = None
        self.venue: list[Any] = []
        

    # --------------------------------------------------------
    # Methods for preparing send and edit message configurations
    # --------------------------------------------------------

    def _get_send_configs(self) -> dict[str, Any]:
        return {
            "chat_id": self.chat_id,
            "parse_mode": self._get_parse_mode(),
            "message_thread_id": self.thread_id,
            "reply_to_message_id": self.reply_to_message_id,
        }

    def _get_send_args(self) -> dict[str, Any]:
        args: dict[str, Any] = {
            "reply_markup": self.reply_markup,
        }

        if self.message_effect_id:
            args["message_effect_id"] = self.message_effect_id

        args.update(self._get_send_configs())

        return args

    def _get_edit_configs(self) -> dict[str, Any]:
        return {
            "chat_id": self.chat_id,
            # "message_thread_id": self.thread_id,
            "message_id": self.edit_message_id,
        }
    
    # --------------------------------------------------------
    # Internal methods for managing temporary messages
    # --------------------------------------------------------
    
    def _add_temporary(self, message_id: int):
        TempMessageStore.add_temporary(self.chat_id, message_id)

    def _remove_temporary(self):
        TempMessageStore.remove_temporary(self.bot, self.chat_id)

    def _handle_is_temp(self, message: Message | None):
        if self.is_temporary and message:
            self._add_temporary(message.message_id)

    def _handle_del_temps(self):
        if self.delele_temporaries:
            self._remove_temporary()

    def _handle_temporary(self, message: Message | None, edited: bool=False):
        if not edited:
            self._handle_del_temps()
        
        self._handle_is_temp(message)

    # --------------------------------------------------------
    # Internal send dispatcher
    # --------------------------------------------------------

    def _send(self) -> Message | None:
        if self.photo:
            message = self._send_photo()
        elif self.document:
            message = self._send_document()
        elif self.video:
            message = self._send_video()
        elif self.animation:
            message = self._send_animation()
        elif self.audio:
            message = self._send_audio()
        elif self.voice:
            message = self._send_voice()
        elif self.video_note:
            message = self._send_video_note()
        elif self.venue:
            message = self._send_venue()
        elif self.media:
            message = self._send_media()
        else:
            message = self._send_text()
        
        self._reset_after_send()

        return message
        
    def _send_photo(self) -> Message | None:
        return self.bot.send_photo(
            photo=self.photo,
            caption=self.text,
            **self._get_send_args()
        )
    
    def _send_document(self) -> Message | None:
        return self.bot.send_document(
            document=self.document,
            caption=self.text,
            **self._get_send_args()
        )
    
    def _send_video(self) -> Message | None:
        return self.bot.send_video(
            video=self.video,
            caption=self.text,
            **self._get_send_args()
        )
    
    def _send_animation(self) -> Message | None:
        return self.bot.send_animation(
            animation=self.animation,
            caption=self.text,
            **self._get_send_args()
        )
    
    def _send_audio(self) -> Message | None:
        return self.bot.send_audio(
            audio=self.audio,
            caption=self.text,
            **self._get_send_args()
        )
    
    def _send_voice(self) -> Message | None:
        return self.bot.send_voice(
            voice=self.voice,
            caption=self.text,
            **self._get_send_args()
        )
    
    def _send_video_note(self) -> Message | None:
        return self.bot.send_video_note(
            data=self.video_note,
            chat_id=self.chat_id,
            reply_to_message_id=self.reply_to_message_id,
            reply_markup=self.reply_markup,
            message_effect_id=self.message_effect_id
        )
    
    def _send_venue(self) -> Message | None:
        return self.bot.send_venue(
            latitude=self.venue[0],
            longitude=self.venue[1],
            title=self.venue[2],
            address=self.venue[3],
            foursquare_id=self.venue[4],
            foursquare_type=self.venue[5],
            chat_id=self.chat_id,
            reply_to_message_id=self.reply_to_message_id,
            reply_markup=self.reply_markup,
            message_effect_id=self.message_effect_id
        )
    
    def _send_media(self) -> Message | None:
        self._prepare_media()
        media: list[InputMediaAudio | InputMediaDocument | InputMediaPhoto | InputMediaVideo] = list(self.media)

        return self.bot.send_media_group(
            media=media,
            reply_to_message_id=self.reply_to_message_id,
            chat_id=self.chat_id
        )[0]
    
    # --------------------------------------------------------
    # Internal methods for sending and editing messages
    # --------------------------------------------------------

    def _get_parse_mode(self):
        match self.parse_mode:
            case "html":
                return "HTML"
            case "markdown":
                return "MarkdownV2"
            case _:
                return None

    def _send_text(self):
        return self.bot.send_message(
            text=self.text,
            **self._get_send_args()
        )

    def _edit(self) -> Message | None:
        configs = self._get_edit_configs()

        if not self.edit_message_id:
            raise ValueError("edit_message_id is None: Unable to edit message without a valid message ID.")
        
        if self.photo:
            media = InputMediaPhoto(
                media=self.photo, 
                caption=self.text, 
                parse_mode=self._get_parse_mode()
            )
            message = self.bot.edit_message_media(
                media=media,
                reply_markup=self.reply_markup,
                **configs
            )
        else:
            message = self.bot.edit_message_text(
                text=self.text,
                parse_mode=self._get_parse_mode(),
                reply_markup=self.reply_markup,
                **configs
            )

        self._reset_after_send()

        if isinstance(message, Message):
            return message

    def _edit_or_send(self) -> tuple[Message | None, bool]:
        if self.edit_message_id:

            try:
                return self._edit(), True
            except Exception as exception:
                if "Bad Request: there is no text in the message to edit" not in str(exception):
                    library.warning(f"Failed to edit message {self.edit_message_id}, sending new one instead. Exception: {exception}")
                self._delete_message(self.edit_message_id)
        
        return self._send(), False
    
    # --------------------------------------------------------
    # Methods for deleting messages
    # --------------------------------------------------------
    
    def _delete_message(self, message_id: int | None) -> bool:
        """
        Deletes a message by its ID.

        Args:
            message_id (int): The ID of the message to delete.
        """
        if message_id is None:
            return False
        
        try:
            return self.bot.delete_message(chat_id=self.chat_id, message_id=message_id)
        except Exception as exception:
            library.warning(f"Failed to delete message {message_id}. Maybe the user deleted it. Exception: {exception}")
            return False
        
    def delete_message(self, message: Message | None, only_user_messages: bool=False) -> bool:
        """
        Deletes a message optionally ignoring bot messages.  
        """
        if only_user_messages and message and message.from_user and message.from_user.is_bot:
            return False

        return self._delete_message(self.get_message_id(message))
    
    # --------------------------------------------------------
    # Methods for sending and editing messages 
    # --------------------------------------------------------

    def pyerror(self, exception: BaseException) -> Message | None: # type: ignore
        """
        Sends a message with the Python exception details for debugging.

        Args:
            exception (BaseException): The exception that occurred.

        Returns:
            Message | None: The error message sent or None if sending failed.
        """
        try:
            configs = self._get_send_configs()
            configs["parse_mode"] = "HTML"
            return self.bot.send_message(text=f"<b>{type(exception).__name__}</b>\n\n<i>{exception}.</i>", **configs)
        except Exception as exception:
            library.warning(f"Failed to send `pyerror` message: {exception}")
            return None

    def error(self, title: str | TextEntity, message: str | TextEntity) -> Message | None: # type: ignore
        """
        Sends a custom error message with a title and detailed message.

        Args:
            title (str): The title of the error.
            message (str): The error message.

        Returns:
            Message | None: The sent error message or None if sending failed.
        """
        try:
            configs = self._get_send_configs()
            configs["parse_mode"] = "HTML"
            return self.bot.send_message(text=f"<b>{title}</b>\n\n<i>{message}.</i>", **configs)
        except Exception as exception:
            library.warning(f"Failed to send `error` message: {exception}")
            return None
    
    def try_send(self) -> tuple[Message | None, Exception | None]:
        """
        Attempts to send a message, handling potential exceptions.

        Returns:
            tuple[Message | None, Exception | None]: 
                A tuple containing the sent message (or None if an error occurred) 
                and the exception (if any).
        """
        try:
            return self.send(), None
        except Exception as exception:
            library.warning(f"Failed to send message in `try_send`: {exception}")
            return None, exception

    def send_or_handle_error(self) -> Message | None:
        """
        Attempts to send a message and handles any errors that occur.

        This method tries to send a message using the `try_send()` function. If an error occurs
        during sending, it sends a message with the error details using `pyerror()`. 

        Returns:
            Message | None: The sent message if successful, or None if an error occurred and was handled.
        """
        message, error = self.try_send()
    
        if error:
            self.pyerror(error)
        
        return message
        
    def send(self) -> Message | None:
        """
        Sends or edits a message and handles its temporary status.

        Returns:
            Message | None: The sent or edited message.
        """
        message, edited = self._edit_or_send()

        self._handle_temporary(message, edited)

        return message

    # --------------------------------------------------------
    # Methods for sending chat actions and retrieving message IDs
    # --------------------------------------------------------
    
    def send_chat_action(self, action: str | _ChatAction, timeout: int | None = None):
        """
        Send a chat action to a chat.

        ```
        self.chain.sender.send_chat_action(self.chain.sender.ChatAction.UPLOAD_AUDIO)
        self.chain.sender.send_chat_action("upload_audio")
        ```
        
        :param action: Type of action to broadcast. Choose one, depending on what the user is about to receive: typing for text messages, upload_photo for photos, record_video or upload_video for videos, record_voice or upload_voice for voice notes, upload_document for general files, choose_sticker for stickers, find_location for location data, record_video_note or upload_video_note for video notes.
        :type action: str | ChatAction
        :param timeout: Timeout in seconds for the request.
        :type timeout: int | None
        """
        self.bot.send_chat_action(self.chat_id, str(action), timeout)

    def get_message_id(self, message: Message | None) -> int | None: # type: ignore
        """
        Retrieves the message ID from a Message object.

        Args:
            message (Message): The message object.

        Returns:
            int | None: The message ID or None if the message is invalid (None).
        """
        if message:
            return message.message_id
        
    # --------------------------------------------------------
    # Methods for games
    # --------------------------------------------------------
        
    def send_emoji_game(self, emoji: str) -> Any:
        """
        Sends a dice message with the given emoji and returns the game result.

        Prefer using the specific methods (e.g. `send_dice()`, `send_slot_machine()`)
        for typed return values. Use this method only when the emoji is dynamic.

        :param emoji: Emoji on which the dice throw animation is based. Currently, must be one of “🎲”, “🎯”, “🏀”, “⚽”, “🎳”, or “🎰”.
            Dice can have values 1-6 for “🎲”, “🎯” and “🎳”, values 1-5 for “🏀” and “⚽”, and values 1-64 for “🎰”
        :type emoji: :obj:`str`

        :returns: the result of the emoji game.
        :rtype: dices.GameResult
        """
        args: dict[str, Any] = self._get_send_args()
        args.pop("parse_mode", None)

        message: Message = self.bot.send_dice(
            emoji=emoji, 
            **args
        )

        return dices.GameResult.from_message(message)

    def send_dice(self) -> dices.Dice:
        """
        Sends a 🎲 classic dice and returns the result.
        The returned object provides access to the outcome of the throw.

        Properties:
        - `value`:   1–6
        - `is_win`:  value == 6
        - `is_lose`: not is_win
        - `score`:   0–100

        Values (1 win / 5 lose):
        - `1` – lose, score: 17
        - `2` – lose, score: 33
        - `3` – lose, score: 50
        - `4` – lose, score: 67
        - `5` – lose, score: 83
        - `6` – win, score: 100
        """
        return self.send_emoji_game(dices.Dice.emoji)

    def send_darts(self) -> dices.Darts:
        """
        Sends a 🎯 darts throw and returns the result.
        The returned object provides access to the outcome of the throw.

        Properties:
        - `value`:       1–6
        - `is_win`:      value == 6
        - `is_lose`:     not is_win
        - `is_bullseye`: value == 6
        - `score`:       0–100

        Values (1 win / 5 lose):
        - `1` – lose, score: 17
        - `2` – lose, score: 33
        - `3` – lose, score: 50
        - `4` – lose, score: 67
        - `5` – lose, score: 83
        - `6` – win, score: 100
        """
        return self.send_emoji_game(dices.Darts.emoji)

    def send_basketball(self) -> dices.Basketball:
        """
        Sends a 🏀 basketball throw and returns the result.
        The returned object provides access to the outcome of the throw.

        Properties:
        - `value`:      1–5
        - `is_win`:     value in {4, 5}
        - `is_lose`:    not is_win
        - `is_perfect`: value == 5
        - `score`:      0–100

        Values (2 win / 3 lose):
        - `1`: ball hits the backboard and misses (lose, score: 20)
        - `2`: ball rolls around the rim and falls out  (lose, score: 40)
        - `3`: ball gets stuck on the rim (lose score: 60)
        - `4`: ball rolls in (win, score: 80)
        - `5`: clean shot (win, score: 100)
        """
        return self.send_emoji_game(dices.Basketball.emoji)

    def send_football(self) -> dices.Football:
        """
        Sends a ⚽ football kick and returns the result.
        The returned object provides access to the outcome of the throw.

        Properties:
        - `value`:         1–5
        - `is_win`:        value in {3, 4, 5}
        - `is_lose`:       not is_win
        - `is_top_corner`: value == 5
        - `score`:         0–100

        Values (3 win / 2 lose):
        - `1`: completely missed (lose, score: 20)
        - `2`: hits the post and bounces out (lose, score: 40)
        - `3`: straight into the center of the goal (win, score: 60)
        - `4`: hits the post and deflects in (win, score: 80)
        - `5`: top corner (win, score: 100)
        """
        return self.send_emoji_game(dices.Football.emoji)

    def send_bowling(self) -> dices.Bowling:
        """
        Sends a 🎳 bowling roll and returns the result.
        The returned object provides access to the outcome of the throw.

        Properties:
        - `value`:        1–6
        - `is_win`:       value in {4, 5, 6}
        - `is_lose`:      not is_win
        - `is_strike`:    value == 6
        - `pins_knocked`: pins knocked down (0–6)
        - `score`:        0–100

        Values (3 win / 3 lose):
        - `1`: all pins remain (lose, score: 17)
        - `2`: 1 pin knocked down, 5 remain (lose, score: 33)
        - `3`: 3 pins knocked down, 3 remain (lose, score: 50)
        - `4`: 4 pins knocked down, 2 remain (win, score: 67)
        - `5`: 5 pins knocked down, 1 remains (win, score: 83)
        - `6`: strike — all 6 pins down (win, score: 100)
        """
        return self.send_emoji_game(dices.Bowling.emoji)

    def send_slot_machine(self) -> dices.SlotMachine:
        """
        Sends a 🎰 slot machine spin and returns the result.
        The returned object provides access to the outcome of the throw.

        Properties:
        - `value`:        1–64
        - `is_win`:       all three reels match (triple of any kind)
        - `is_lose`:      not is_win
        - `is_jackpot`:   rank == "triple_7"  (7️⃣7️⃣7️⃣)
        - `slots`:        (left, center, right) reel values (1–4 each)
        - `emojis`:       visual emoji string    e.g. `"🍒🍋7️⃣"`
        - `split_emojis`: reel emojis as tuple   e.g. `("🍒", "🍋", "7️⃣")`
        - `letters`:      compact reel string    e.g. `"CLS"`
        - `names`:        full reel names        e.g. `"Cherry Lemon Seven"`
        - `split_names`:  reel names as tuple    e.g. `("cherry", "lemon", "seven")`
        - `rank`:         `"nothing"` | `"pair"` | `"triple"` | `"double_7"` | `"triple_7"`
        - `score`:        `0` / `25` / `60` / `75` / `100`
        """
        return self.send_emoji_game(dices.SlotMachine.emoji)

        
    # --------------------------------------------------------
    # Context manager support methods
    # --------------------------------------------------------
        
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        return False
    
    def then_send(self):
        """
        Returns a context manager that yields the sender instance. 

        When exiting the context block, the message will be automatically sent.
        
        Example usage:
        
        with self.chain.sender.then_send() as sender:
            sender.set_title("Hello!")
            sender.set_message("It's Telekit.")
        # At the end of the block, send() is called automatically.
        """
        class AutoSendContext:
            def __init__(self, sender: BaseSender):
                self.sender = sender

            def __enter__(self):
                return self.sender

            def __exit__(self, exc_type, exc_val, exc_tb):
                self.sender.send()
                return False

        return AutoSendContext(self)
    
    # License
    
    def set_license_text(self, year: str, author: str, project: str):
        """
        Sets the license text for the message using the GNU GPLv3 template.

        Args:
            year (`str`): Copyright year.
            author (`str`): Author name.
            project (`str`): Project name.
        """
        self.set_text(textwrap.dedent(f"""
            {project} — Copyright (C) {year} {author}

            {project} is free software: you can redistribute it and/or modify
            it under the terms of the GNU General Public License as published by
            the Free Software Foundation, either version 3 of the License, or
            (at your option) any later version.

            {project} is distributed in the hope that it will be useful,
            but WITHOUT ANY WARRANTY; without even the implied warranty of
            MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
            GNU General Public License for more details.

            You should have received a copy of the GNU General Public License
            along with {project}. If not, see <https://www.gnu.org/licenses/>.
        """))

    def debug_text(self, label: str | None="BaseSender"):
        code: str = self.text
        parse_mode: str | None = self.parse_mode

        Raw(code).debug(parse_mode, label)

# ---------------------------------------------------------------------------------
# Sender
# ---------------------------------------------------------------------------------

class Sender(BaseSender):

    _text: Group | None
    _title: Bold | None
    _message: Group | None
    _additional: Group | None

    _use_italics: bool
    _new_lines:   int

    # --------------------------------------------------------
    # Internal methods for compiling and formatting message text
    # --------------------------------------------------------

    def _compile_text(self) -> None:
        if not hasattr(self, "_text"):
            self._text = None

        if not hasattr(self, "_title"):
            self._title = None

        if not hasattr(self, "_message"):
            self._message = None

        if not hasattr(self, "_new_lines"):
            self._new_lines = 2
        
        if not hasattr(self, "_use_italics"):
            self._use_italics = False

        if not hasattr(self, "_additional"):
            self._additional = None

        if self._text:
            self._compile_plain()
        elif self._title or self._message:
            self._compile_alert()
        elif self._additional:
            self._compile_additional()

    def _compile_plain(self):
        if self._text is None:
            raise ValueError("Sender._text is None")
        
        text: Group = self._text
        
        if self._additional:
            text = text + self._additional

        super().set_text(text.render(self.parse_mode))

    def _compile_alert(self):
        title: Bold | None = self._title

        if self._additional:
            # message: Group
            if self._message:
                message: TextEntity | None = self._message + self._additional
            else:
                message: TextEntity | None = self._additional
        else:
            # message: Group | None
            message: TextEntity | None = self._message

        if self._use_italics and message:
            message = Italic(message)

        text = ""

        if title:
            text += title.render(self.parse_mode).rstrip("\n")
        
        if self._new_lines and title and message:
            text += "\n" * self._new_lines

        if message:
            text += message.render(self.parse_mode).lstrip("\n")

        super().set_text(text)

    def _compile_additional(self):
        if self._additional is None:
            raise ValueError("Sender._additional is None")

        super().set_text(self._additional.render(self.parse_mode))

    # --------------------------------------------------------
    # Setter methods for configuring alert-styled message properties
    # --------------------------------------------------------

    def _reset_plain(self):
        self._text = None
        self._additional = None

    def _reset_alert(self):
        self._title = None
        self._message = None
        self._additional = None

    def remove_text(self):
        """
        Clears the text content.
        
        Resets `title`, `message`, and `text` to their default empty values.
        Attachments, parse mode, and other properties are preserved.
        """
        self._reset_alert()
        self._reset_plain()
        super().remove_text()

    def set_text(self, *text: str | TextEntity, escape: bool = True, sep: str | TextEntity = ""): # pyright: ignore[reportIncompatibleMethodOverride]
        """
        Set the message as plain text, replacing any previously set title or message content.

        :param text: One or more text parts or ``TextEntity`` objects.
        :type text: ``str | TextEntity``
        :param escape: Whether to escape special characters. Defaults to ``True``.
        :type escape: ``bool``
        :param sep: Separator between text parts. Defaults to ``""``.
        :type sep: ``str | TextEntity``

        Example::

            >>> s.set_text("Hello ", Bold("World"))
            "Hello <b>World</b>"
        """
        self._reset_alert()

        if text:
            self._text = Group(*text, escape=escape, sep=sep)

    def set_title(self, *title: str | TextEntity, escape: bool = True, sep: str | TextEntity = ""):
        """
        Set the title of the message. Clears any previously set plain text content.

        :param title: One or more title parts or ``TextEntity`` objects.
        :type title: ``str | TextEntity``
        :param escape: Whether to escape special characters. Defaults to ``True``.
        :type escape: ``bool``
        :param sep: Separator between title parts. Defaults to ``""``.
        :type sep: ``str | TextEntity``
        """
        self._reset_plain()

        if title:
            self._title = Bold(*title, escape=escape, sep=sep)

    def set_message(self, *message: str | TextEntity, escape: bool = True, sep: str | TextEntity = ""):
        """
        Set the main message body for the alert. Clears any previously set plain text content.

        :param message: One or more message parts or ``TextEntity`` objects.
        :type message: ``str | TextEntity``
        :param escape: Whether to escape special characters. Defaults to ``True``.
        :type escape: ``bool``
        :param sep: Separator between message parts. Defaults to ``""``.
        :type sep: ``str | TextEntity``
        """
        self._reset_plain()

        if message:
            self._message = Group(*message, escape=escape, sep=sep)

    def append(self, *text: str | TextEntity, escape: bool = True, sep: str | TextEntity =""):
        """
        Append text to the end of the current message without replacing existing content.

        Works with both ``set_text()`` and ``set_message()``.

        :param text: One or more text parts or ``TextEntity`` objects.
        :type text: ``str | TextEntity``
        :param escape: Whether to escape special characters. Defaults to ``True``.
        :type escape: ``bool``
        :param sep: Separator between appended parts. Defaults to ``""``.
        :type sep: ``str | TextEntity``

        Example::

            >>> s.set_text("Hel")
            >>> s.append("lo")
            "Hello"
        """
        add = Group(*text, escape=escape, sep=sep)

        if hasattr(self, "_additional"):
            if self._additional is None:
                self._additional = add
            else:
                self._additional += add
        else:
            self._additional = add

    def set_use_italics(self, use_italics: bool=True):
        """
        Enable or disable italics for message body.

        This is a stylistic option where the title is rendered in bold,
        while the message text is rendered in italics.

        Args:
            use_italics (bool): True to enable italics, False to disable.

        Returns:
            None
        """
        self._use_italics = use_italics

    def set_use_newline(self, use_newline: bool | int = True):
        """
        Enable or disable automatic newline between title and message body.

        Args:
            use_newline (bool): True to insert newline (`"\\n\\n"`), False to omit (`"\\n"`).
            use_newline (int): Number of `"\\n"` between title and message.

        >>> set_use_newline(0)
        ```
        "TitleMessage"
        ```
        >>> set_use_newline(1)
        >>> set_use_newline(False)
        ```
        "Title\\nMessage"
        ```
        >>> set_use_newline(2)
        >>> set_use_newline(True)
        ```
        "Title\\n\\nMessage"
        ```
        >>> set_use_newline(3)
        ```
        "Title\\n\\n\\nMessage"
        ```
        """
        if isinstance(use_newline, bool):
            self._new_lines = int(use_newline) + 1
        else:
            self._new_lines = int(use_newline)

    # --------------------------------------------------------
    # Method to compile and send the message
    # --------------------------------------------------------

    def send(self) -> Message | None:
        """
        Compile and send the current message.

        Resolves internal state into final text before sending through
        BaseSender's send method.

        Note:
            This method only sends the message itself. It does not handle inline
            keyboard interactions, so button presses will not be registered unless
            they are links. To properly send a message that supports inline buttons,
            use `chain.send()`.

        Returns:
            Message | None: The sent message object or None if sending failed.
        """
        self._compile_text()
        return super().send()
    
    # License
    
    def set_license_text(self, year: str, author: str, project: str):
        """
        Sets the license text for the message using the GNU GPLv3 template.

        Args:
            year (`str`): Copyright year.
            author (`str`): Author name.
            project (`str`): Project name.
        """
        self.set_title(f"{project} — Copyright (C) {year} {author}")
        self.set_message(textwrap.dedent(f"""
            {project} is free software: you can redistribute it and/or modify
            it under the terms of the GNU General Public License as published by
            the Free Software Foundation, either version 3 of the License, or
            (at your option) any later version.

            {project} is distributed in the hope that it will be useful,
            but WITHOUT ANY WARRANTY; without even the implied warranty of
            MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
            GNU General Public License for more details.

            You should have received a copy of the GNU General Public License
            along with {project}. If not, see <https://www.gnu.org/licenses/>.
        """))

    def debug_text(self, label: str | None = "Sender") -> None:
        """
        Compile and print a formatted debug representation of the sender's current text.

        Compiles the text content before printing, ensuring all pending
        text parts are resolved. Delegates to the parent ``debug_text()``.

        :param label: Optional label shown in the debug header. Defaults to ``"Sender"``.
        :type label: ``str | None``

        Example::

            >>> self.chain.sender.set_text("Hello ", Bold("World"))
            >>> self.chain.sender.debug_text()
            ––––––– Sender Parse Mode: html –––––––

            Hello <b>World</b>
        """
        self._compile_text()
        super().debug_text(label)