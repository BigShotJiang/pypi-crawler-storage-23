from argparse import ArgumentParser
import os
from subprocess import PIPE, Popen

from columnar import columnar


class Colors:
    OKGREEN = "\033[92m"
    WARNING = "\033[93m"
    FAIL = "\033[91m"
    ENDC = "\033[0m"


def _key_equal_val(key: str, line: str):
    parts = line.split(" ")
    for part in parts:
        sub_parts = part.split("=")
        if sub_parts[0] == key and len(sub_parts) > 1:
            return "=".join(sub_parts[1:])
    return None


def _gpu_column_count() -> int:
    raw = os.getenv("NODE_AVAIL_GPU_COUNT", "8")
    try:
        count = int(raw)
    except ValueError:
        return 8
    return count if count > 0 else 8


def read_sinfo_nodes(undrain: bool = False) -> None:
    gpu_column_count = _gpu_column_count()
    sinfo = Popen("scontrol show node --detail", shell=True, stdout=PIPE)
    output = sinfo.stdout.read().decode("UTF-8")
    nodes = output.split("NodeName")
    data = []
    drain_data = []

    for node in nodes[1:]:
        lines = node.split("\n")
        node_name = lines[0].split("=")[1].split(" ")[0]

        cpu_alloc, cpu_total = 0, 0
        memory_alloc, memory_total = 0, 0
        vendor = "???"
        reason = False
        avx2 = False
        gres_used = ""
        gres = ""

        gpu_status = [""] * gpu_column_count
        gpu_index = 0

        for line in lines:
            new_cpu_alloc = _key_equal_val("CPUAlloc", line)
            if new_cpu_alloc:
                cpu_alloc = int(new_cpu_alloc)

            new_cpu_total = _key_equal_val("CPUTot", line)
            if new_cpu_total:
                cpu_total = int(new_cpu_total)

            new_memory_alloc = _key_equal_val("AllocMem", line)
            if new_memory_alloc:
                memory_alloc = int(new_memory_alloc) // 1024

            new_memory_total = _key_equal_val("RealMemory", line)
            if new_memory_total:
                memory_total = int(new_memory_total) // 1024

            new_reason = _key_equal_val("Reason", line)
            if new_reason:
                reason = line.split("=")[1]

            new_features = _key_equal_val("ActiveFeatures", line)
            if new_features and "amd" in new_features:
                vendor = "AMD"
            if new_features and "intel" in new_features:
                vendor = "Intel"
            if new_features and "avx2" in new_features:
                avx2 = True

            new_gres = _key_equal_val("Gres", line)
            if new_gres:
                gres = new_gres

            new_gresused = _key_equal_val("GresUsed", line)
            if new_gresused:
                gres_used = new_gresused

        gpus = {}
        for entry in gres.split(","):
            parts = entry.split(":")
            if len(parts) <= 2:
                continue
            name, resource = parts[1], parts[2].split("(")[0]
            gpus[name] = int(resource)

        for entry in gres_used.split(","):
            parts = entry.split(":")
            if len(parts) <= 2:
                continue

            name, resource = parts[1], int(parts[2].split("(")[0])
            free, used = gpus[name] - resource, resource

            for _ in range(free):
                if gpu_index >= gpu_column_count:
                    break
                gpu_status[gpu_index] = Colors.OKGREEN + name + Colors.ENDC
                gpu_index += 1

            for _ in range(used):
                if gpu_index >= gpu_column_count:
                    break
                gpu_status[gpu_index] = Colors.FAIL + name + Colors.ENDC
                gpu_index += 1

        row = [
            node_name,
            vendor,
            avx2,
            cpu_total - cpu_alloc,
            cpu_alloc,
            cpu_total,
            memory_total - memory_alloc,
            memory_alloc,
            memory_total,
            memory_total // cpu_total,
            *gpu_status,
        ]
        if reason:
            drain_data.append([row[0], reason])
        else:
            data.append(row)

    def sort_func(row):
        return [row[0].split("-")[0], -row[3], -row[2]]

    data.sort(key=sort_func)

    gpu_headers = [f"\n#{i}" for i in range(2, gpu_column_count + 1)]
    if gpu_column_count >= 1:
        gpu_headers = ["GPUs\n#1", *gpu_headers]

    table = columnar(
        data,
        headers=[
            "\nNode",
            "\nCPU",
            "\nAVX2",
            "CPU Cores\nFree",
            "\nAlloc",
            "\nTotal",
            "Memory Gb\nFree",
            "\nAlloc",
            "\nTotal",
            "\nTotal/CPU",
            *gpu_headers,
        ],
        no_borders=True,
    )
    print(table)

    if len(drain_data) > 0:
        print(Colors.WARNING + "The following nodes are on DRAIN and must be restarted")
        table = columnar(drain_data, headers=["Node", "Reason"], no_borders=True)
        print(table)
        print(Colors.ENDC)

        if undrain:
            print("Undrain command preview:")
            for name, _ in drain_data:
                print(f"scontrol update nodename={name} state=down reason=undraining")
                print(f"scontrol update nodename={name} state=idle")


def main() -> None:
    parser = ArgumentParser()
    parser.add_argument("-u", "--undrain", action="store_true")
    args = parser.parse_args()
    read_sinfo_nodes(undrain=args.undrain)


if __name__ == "__main__":
    main()
