"""Skills.sh compatible skill management (install/list/update/search)."""

