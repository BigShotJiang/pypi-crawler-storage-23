"""zsdtdx 统一封装模块导出。"""

from zsdtdx.wrapper.unified_client import UnifiedTdxClient

__all__ = ["UnifiedTdxClient"]
