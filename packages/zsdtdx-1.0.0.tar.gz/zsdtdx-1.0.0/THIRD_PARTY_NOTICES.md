# Third-Party Notices

This project (`zsdtdx`) is developed with reference to and partial adaptation of
the upstream project:

- Project: `pytdx`
- Homepage: <https://github.com/rainx/pytdx>
- PyPI: <https://pypi.org/project/pytdx/>

## Attribution

Portions of protocol parsing and API behavior are derived from or inspired by
`pytdx`, with additional wrapper, retry, routing, batching, and parallel-fetch
logic implemented in this project.

## License Status Note

During packaging preparation, the `pytdx` 1.72 source distribution metadata on
PyPI reports `License: UNKNOWN`, and the source archive does not contain a
standalone `LICENSE` file.

Before public distribution, maintainers should verify the upstream license terms
from the authoritative upstream repository and retain any required notices in
this file.
