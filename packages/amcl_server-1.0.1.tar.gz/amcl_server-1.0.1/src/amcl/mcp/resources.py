"""
MCP Resources — read-only data endpoints agents can access.

Implements 6 resources from the PRD using context:// URI scheme.
"""

from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import FastMCP

from amcl.context.context_manager import ContextManager


def register_resources(mcp: FastMCP, ctx_mgr: ContextManager) -> None:
    """Register all A/MCL resources on the given FastMCP server."""

    @mcp.resource("context://current-project")
    def current_project() -> str:
        """Complete current project context snapshot."""
        context = ctx_mgr.get_current_context()
        return json.dumps(context, indent=2, default=str)

    @mcp.resource("context://conversation")
    def conversation() -> str:
        """Full conversation history for the current project."""
        msgs = ctx_mgr.get_conversation(limit=200)
        return json.dumps({"messages": msgs, "count": len(msgs)}, indent=2, default=str)

    @mcp.resource("context://files")
    def files() -> str:
        """File system state and recent changes."""
        context = ctx_mgr.get_current_context(include=["files"])
        return json.dumps(context.get("files", {}), indent=2, default=str)

    @mcp.resource("context://reasoning")
    def reasoning() -> str:
        """Decision log and reasoning chains."""
        decisions = ctx_mgr.get_reasoning()
        return json.dumps({"decisions": decisions}, indent=2, default=str)

    @mcp.resource("context://tasks")
    def tasks() -> str:
        """Active tasks, completed work, and blockers."""
        all_tasks = ctx_mgr.get_tasks()
        grouped = {
            "completed": [t for t in all_tasks if t.get("status") == "completed"],
            "in_progress": [t for t in all_tasks if t.get("status") == "in_progress"],
            "pending": [t for t in all_tasks if t.get("status") == "pending"],
            "blocked": [t for t in all_tasks if t.get("status") == "blocked"],
        }
        return json.dumps(grouped, indent=2, default=str)

    @mcp.resource("context://agents")
    def agents() -> str:
        """History of which agents worked on the project."""
        sessions = ctx_mgr.get_agent_history()
        return json.dumps({"history": sessions}, indent=2, default=str)
