# podcut

AI-powered podcast segment extractor. Automatically finds the best cold opens, clips, and highlights from podcast episodes.

AIポッドキャスト切り抜きツール。エピソードから最適なコールドオープン・クリップ・ハイライトを自動抽出します。

## Features / 機能

- **Cold Open Extraction / コールドオープン抽出**: Find 10-90 second teasers that hook listeners（10〜90秒のティーザーを検出）
- **Clip Extraction / クリップ抽出**: Extract 1-10 minute standalone highlights（1〜10分の独立したハイライトを抽出）
- **Multiple LLM Providers / LLMプロバイダ**: Gemini, OpenAI, Claude, Grok (cloud) and Ollama (local)（Gemini・OpenAI・Claude・Grokクラウド / Ollamaローカル）
- **Whisper Transcription / Whisper文字起こし**: MLX-accelerated on Apple Silicon, CPU fallback（Apple Silicon MLX高速化、CPUフォールバック対応）
- **Smart Cut Points / スマートカット**: Silence-aware audio cutting with fade in/out（無音検出によるカットポイント最適化）
- **Interactive Wizard / 対話型ウィザード**: Guided setup for first-time users（初回ユーザー向けガイド付きセットアップ）
- **Feedback Loop / フィードバックループ**: Refine results with natural language feedback（自然言語フィードバックで結果を改善）
- **Bilingual UI / 多言語UI**: Japanese and English support（日本語・英語切り替え対応）

## Requirements / 必要環境

- Python 3.11+
- FFmpeg（音声処理用）
- LLM APIキー（いずれか1つ）: [Gemini](https://aistudio.google.com/apikey) / [OpenAI](https://platform.openai.com/api-keys) / [Claude](https://console.anthropic.com/settings/keys) / [Grok](https://console.x.ai/) または Ollama（ローカルLLM、キー不要）

## Installation / インストール

```bash
# pipx（CLIツール推奨）
pipx install .

# または pip
pip install .
```

## Quick Start / クイックスタート

```bash
# 対話型ウィザード
podcut

# 英語UIで起動
podcut --lang en

# 直接コマンド実行
podcut find episode.mp3

# クリップモード（長めのセグメント）
podcut find episode.mp3 --mode clip

# Ollama（ローカルLLM）を使用
podcut find episode.mp3 --provider ollama

# 全候補を自動エクスポート（対話選択スキップ）
podcut find episode.mp3 --auto

# JSON出力
podcut find episode.mp3 --json
```

## Configuration / 設定

初回起動時のウィザードでAPIキーを入力すると `~/.config/podcut/.env` に自動保存されます。設定も `~/.config/podcut/settings.json` に保存され、2回目以降はEnter連打で即開始できます。

手動で設定する場合:

```bash
# LLM APIキー（使用するプロバイダのみ）
export GEMINI_API_KEY=your-key-here
export OPENAI_API_KEY=your-key-here
export ANTHROPIC_API_KEY=your-key-here
export XAI_API_KEY=your-key-here

# または .env ファイル（プロジェクトディレクトリ or ~/.config/podcut/.env）
echo "GEMINI_API_KEY=your-key-here" >> ~/.config/podcut/.env
```

保存済み設定の管理:

```bash
podcut config          # 設定一覧表示
podcut config --reset  # 設定リセット
podcut config --path   # 設定ファイルパス表示
```

Ollama を使う場合（デフォルト以外のURL）:

```bash
export OLLAMA_BASE_URL=http://localhost:11434
export OLLAMA_MODEL=qwen3:8b
```

UI言語の設定:

```bash
# 日本語（デフォルト）
export PODCUT_LANGUAGE=ja

# 英語
export PODCUT_LANGUAGE=en
```

## CLI Options / CLIオプション

```
podcut find [OPTIONS] AUDIO_FILE

Options:
  -o, --output PATH          出力ディレクトリ (default: ./output)
  -n, --candidates INT       候補数 1-10 (default: 3)
  -f, --format TEXT          出力形式: mp3, wav (default: mp3)
  -m, --model TEXT           Gemini モデル (default: gemini-2.5-flash)
  --whisper-model TEXT       Whisper モデル (default: turbo)
  --backend TEXT             Whisper バックエンド: auto, mlx, cpu (default: auto)
  --mode TEXT                抽出モード: cold_open, clip (default: cold_open)
  --provider TEXT            LLMプロバイダ: gemini, ollama, openai, claude, grok (default: gemini)
  --ollama-model TEXT        Ollama モデル (default: qwen3:8b)
  --openai-model TEXT        OpenAI モデル (default: gpt-4.1-mini)
  --claude-model TEXT        Claude モデル (default: claude-sonnet-4-5)
  --grok-model TEXT          Grok モデル (default: grok-3-mini)
  --lang TEXT                UI言語: ja, en
  --auto                     対話選択をスキップし全候補をエクスポート
  --json                     結果をJSON形式で出力
  -v, --verbose              詳細ログを表示
```

## How It Works / 仕組み

1. **Upload / アップロード**: 音声ファイルをアップロード（Geminiのみ。他プロバイダはトランスクリプトのみ使用）
2. **Transcribe / 文字起こし**: Whisper でタイムスタンプ付きトランスクリプトを生成
3. **Analyze / 分析**: LLM が最適なセグメント候補をタイムスタンプ付きで特定
4. **Optimize / 最適化**: カットポイントを無音境界に調整しクリーンな編集を実現
5. **Extract / 抽出**: 音声セグメントをフェードイン/アウト付きでエクスポート

## License

MIT
