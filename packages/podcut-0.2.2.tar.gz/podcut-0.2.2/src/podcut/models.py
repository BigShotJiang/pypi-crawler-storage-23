"""Pydantic models for the cold open finder pipeline."""

from pathlib import Path

from pydantic import BaseModel, Field


class Word(BaseModel):
    """A single word with timestamp from Whisper."""

    word: str
    start: float
    end: float
    probability: float


class Segment(BaseModel):
    """A transcript segment from Whisper."""

    id: int
    start: float
    end: float
    text: str


class Transcript(BaseModel):
    """Complete transcript output from Whisper (Step 1)."""

    text: str
    language: str
    segments: list[Segment] = Field(default_factory=list)
    words: list[Word] = Field(default_factory=list)


class ColdOpenSegmentPart(BaseModel):
    """A single part of a multi-segment cold open."""

    start_time: float
    end_time: float
    transcript_excerpt: str


class ColdOpenCandidate(BaseModel):
    """A cold open candidate identified by Gemini (Step 2)."""

    rank: int
    start_time: float = Field(description="Start time in seconds (from Whisper timestamps)")
    end_time: float = Field(description="End time in seconds (from Whisper timestamps)")
    speaker: str = ""
    hook_type: str = Field(description="Type of hook: question, story, surprising_fact, debate, humor, insight")
    transcript_excerpt: str
    reasoning: str
    engagement_score: int = Field(ge=1, le=10)
    self_contained_score: int = Field(default=0, ge=0, le=10)
    narrative_completeness: int = Field(default=0, ge=0, le=10)
    context_needed: str = ""
    opening_impact_score: int = Field(default=0, ge=0, le=10)
    shareability_score: int = Field(default=0, ge=0, le=10)
    hook_first_3sec_score: int = Field(default=0, ge=0, le=10)
    suggested_title: str = ""
    completion_hook: str = ""
    is_multi_segment: bool = False
    segments: list[ColdOpenSegmentPart] = Field(default_factory=list)


class GeminiAnalysisResult(BaseModel):
    """Structured output from Gemini analysis."""

    candidates: list[ColdOpenCandidate]


class RefinedTimestampPart(BaseModel):
    """A single part of a multi-segment refined timestamp."""

    refined_start_sec: float
    refined_end_sec: float
    duration_seconds: float
    cut_quality: str


class RefinedTimestamp(BaseModel):
    """Optimized cut points from silence detection (Step 3)."""

    original_rank: int
    refined_start_sec: float
    refined_end_sec: float
    duration_seconds: float
    cut_quality: str = Field(description="'clean' (silence cut) or 'word_boundary' (word gap cut)")
    parts: list[RefinedTimestampPart] = Field(default_factory=list)


class ExtractedSegment(BaseModel):
    """Final output combining all pipeline results."""

    rank: int
    file_path: Path
    start_time: float
    end_time: float
    duration_seconds: float
    hook_type: str
    speaker: str
    transcript_excerpt: str
    reasoning: str
    engagement_score: int
    cut_quality: str
    self_contained_score: int = 0
    narrative_completeness: int = 0
    context_needed: str = ""
    opening_impact_score: int = 0
    shareability_score: int = 0
    hook_first_3sec_score: int = 0
    suggested_title: str = ""
    completion_hook: str = ""
