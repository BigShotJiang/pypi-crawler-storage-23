"""Agentic pipeline orchestrator for the 5-step cold open finder workflow."""

from __future__ import annotations

import threading
import time
from pathlib import Path

from rich.console import Console

from podcut.audio_processor import extract_all_segments, get_audio_duration_sec, load_audio
from podcut.config import (
    AVAILABLE_PROVIDERS,
    DEFAULT_CANDIDATES,
    DEFAULT_FORMAT,
    DEFAULT_MODEL,
    DEFAULT_WHISPER_MODEL,
    MAX_TRANSCRIPT_CHARS,
)
from podcut.display import display_candidates_preview, prompt_user_selection
from podcut.extraction_mode import COLD_OPEN_MODE, ExtractionMode
from podcut.i18n import t
from podcut.llm_provider import LLMProvider
from podcut.models import ColdOpenCandidate, ExtractedSegment, RefinedTimestamp, Transcript
from podcut.silence_detector import refine_cut_points
from podcut.transcriber import format_transcript_with_timestamps, transcribe

MAX_FEEDBACK_ROUNDS = 3

console = Console(stderr=True)


def _run_with_progress(label: str, func, *args, interval: float = 1.0, **kwargs):
    """Run a function in a background thread while showing progress from the main thread.

    The work runs in a background thread so that the main thread can reliably
    show elapsed time updates via an in-place spinner. This avoids GIL starvation
    where C extensions (e.g. Whisper/MLX) hold the GIL and prevent a progress
    thread from ever executing.

    Returns the function's return value.
    """
    start_time = time.monotonic()
    result_container: dict = {}
    done_event = threading.Event()

    def _worker():
        try:
            result_container["value"] = func(*args, **kwargs)
        except BaseException as e:
            result_container["error"] = e
        finally:
            done_event.set()

    worker = threading.Thread(target=_worker, daemon=True)
    worker.start()

    if console.is_terminal:
        with console.status(f"  {label}...") as status:
            while not done_event.wait(interval):
                elapsed = time.monotonic() - start_time
                status.update(f"  {t('progress_elapsed', label=label, elapsed=elapsed)}")
    else:
        done_event.wait()

    worker.join(timeout=5.0)

    if "error" in result_container:
        raise result_container["error"]

    elapsed = time.monotonic() - start_time
    if elapsed >= 2.0:
        console.print(f"[dim]  {t('progress_done', label=label, elapsed=elapsed)}[/dim]")
    return result_container.get("value")


def _truncate_transcript(
    transcript_text: str,
    max_chars: int = MAX_TRANSCRIPT_CHARS,
    strategy: str = "head_tail",
) -> str:
    """Truncate transcript to fit within Gemini prompt limits.

    Args:
        transcript_text: Full transcript text.
        max_chars: Maximum character budget.
        strategy: "head_tail" (60/40 split) or "full" (head/middle/tail thirds).
    """
    if len(transcript_text) <= max_chars:
        return transcript_text

    total_lines = transcript_text.count("\n") + 1

    if strategy == "full":
        # Clip mode: sample head, middle, and tail equally
        third = max_chars // 3

        head = transcript_text[:third]
        last_nl = head.rfind("\n")
        if last_nl > 0:
            head = head[:last_nl]

        mid_start = (len(transcript_text) - third) // 2
        middle = transcript_text[mid_start:mid_start + third]
        first_nl = middle.find("\n")
        if first_nl >= 0:
            middle = middle[first_nl + 1:]
        last_nl = middle.rfind("\n")
        if last_nl > 0:
            middle = middle[:last_nl]

        tail = transcript_text[-third:]
        first_nl = tail.find("\n")
        if first_nl >= 0:
            tail = tail[first_nl + 1:]

        kept_lines = head.count("\n") + middle.count("\n") + tail.count("\n") + 3
        omitted = max(0, total_lines - kept_lines)

        return (
            f"{head}\n\n"
            f"[... ~{omitted} lines omitted ...]\n\n"
            f"{middle}\n\n"
            f"[... ~{omitted} lines omitted ...]\n\n"
            f"{tail}"
        )
    else:
        # head_tail: existing 60/40 logic
        head_budget = int(max_chars * 0.6)
        tail_budget = max_chars - head_budget

        head = transcript_text[:head_budget]
        last_nl = head.rfind("\n")
        if last_nl > 0:
            head = head[:last_nl]

        tail = transcript_text[-tail_budget:]
        first_nl = tail.find("\n")
        if first_nl >= 0:
            tail = tail[first_nl + 1:]

        kept_lines = head.count("\n") + tail.count("\n") + 2

        return (
            f"{head}\n\n"
            f"[... transcript middle omitted: showing ~{kept_lines}/{total_lines} lines. "
            f"Content continues below ...]\n\n"
            f"{tail}"
        )


def _repair_timestamps_from_transcript(
    candidate: ColdOpenCandidate,
    transcript: Transcript,
    verbose: bool = False,
) -> bool:
    """Try to repair broken timestamps by finding the excerpt in the transcript.

    When Gemini returns timestamps that are too close together (< MIN_DURATION_SEC),
    we search for the transcript_excerpt text in the Whisper segments and use
    those timestamps instead.

    Returns True if repair was successful, False otherwise.
    """
    excerpt = candidate.transcript_excerpt.strip()
    if not excerpt or not transcript.segments:
        return False

    # Normalize for matching
    excerpt_normalized = excerpt.replace("\n", " ").strip()
    # Take first ~30 chars for fuzzy prefix matching
    excerpt_prefix = excerpt_normalized[:30].strip()

    best_start = None
    best_end = None

    # Strategy 1: Find the segment containing the excerpt prefix
    for seg in transcript.segments:
        seg_text = seg.text.strip()
        if excerpt_prefix in seg_text or seg_text in excerpt_normalized:
            if best_start is None:
                best_start = seg.start
            best_end = seg.end

    # Strategy 2: If no segment match, try word-level matching
    if best_start is None and transcript.words:
        first_words = excerpt_normalized.split()[:3]
        search_str = "".join(w.strip() for w in first_words)

        for i, word in enumerate(transcript.words):
            chunk = "".join(
                transcript.words[j].word.strip()
                for j in range(i, min(i + len(first_words), len(transcript.words)))
            )
            if search_str in chunk:
                best_start = transcript.words[i].start
                # Estimate end: ~30-45 seconds from start
                target_end = best_start + 40.0
                best_end = best_start + 30.0
                for j in range(i, len(transcript.words)):
                    if transcript.words[j].end <= target_end:
                        best_end = transcript.words[j].end
                    else:
                        break
                break

    if best_start is not None and best_end is not None and best_end > best_start:
        if verbose:
            console.print(
                f"[dim]Repaired Candidate {candidate.rank} timestamps: "
                f"{candidate.start_time:.1f}-{candidate.end_time:.1f}s → "
                f"{best_start:.1f}-{best_end:.1f}s (from transcript)[/dim]"
            )
        candidate.start_time = best_start
        candidate.end_time = best_end
        return True

    return False


def _filter_by_duration(
    candidates: list,
    refined: list,
    min_sec: float | None = None,
    max_sec: float | None = None,
    verbose: bool = False,
) -> tuple[list, list]:
    """Filter candidates outside the duration range.

    If ALL candidates would be filtered, keeps the best available ones
    rather than returning empty.
    """
    # Use legacy defaults if not specified (for backward compat with tests)
    if min_sec is None:
        from podcut.config import MIN_DURATION_SEC
        min_sec = MIN_DURATION_SEC
    if max_sec is None:
        from podcut.config import MAX_DURATION_SEC
        max_sec = MAX_DURATION_SEC

    filtered_candidates = []
    filtered_refined = []

    for c, r in zip(candidates, refined):
        if r.duration_seconds < min_sec:
            if verbose:
                console.print(
                    f"[yellow]Warning: Candidate {c.rank} is too short "
                    f"({r.duration_seconds:.1f}s < {min_sec}s). Skipping.[/yellow]"
                )
            continue
        if r.duration_seconds > max_sec:
            if verbose:
                console.print(
                    f"[yellow]Warning: Candidate {c.rank} is too long "
                    f"({r.duration_seconds:.1f}s > {max_sec}s). Skipping.[/yellow]"
                )
            continue
        filtered_candidates.append(c)
        filtered_refined.append(r)

    # If all candidates were filtered, keep the best available
    if not filtered_candidates and candidates:
        if verbose:
            console.print(
                "[yellow]All candidates fell outside duration range. "
                "Using best available candidates.[/yellow]"
            )
        # Sort by engagement score descending, prefer closer to target range
        paired = list(zip(candidates, refined))
        paired.sort(key=lambda p: p[0].engagement_score, reverse=True)
        filtered_candidates = [p[0] for p in paired]
        filtered_refined = [p[1] for p in paired]

    return filtered_candidates, filtered_refined


def _rerank(
    candidates: list[ColdOpenCandidate],
    refined: list[RefinedTimestamp],
    mode: ExtractionMode = COLD_OPEN_MODE,
    verbose: bool = False,
) -> tuple[list[ColdOpenCandidate], list[RefinedTimestamp]]:
    """Re-rank candidates using mode-specific weighted scoring.

    Instead of trusting the LLM's subjective ranking, compute a final score
    based on configurable weights per extraction mode.
    """
    if not mode.rerank_weights or not candidates:
        return candidates, refined

    scored: list[tuple[float, int]] = []
    seen_hook_types: dict[str, int] = {}

    for i, c in enumerate(candidates):
        # Compute weighted score from available fields
        score = 0.0
        for field_name, weight in mode.rerank_weights.items():
            value = getattr(c, field_name, 0)
            score += value * weight

        # Penalty for context_needed == "significant"
        if c.context_needed == "significant":
            score -= mode.context_significant_penalty

        # Diversity penalty: same hook_type appearing multiple times
        count = seen_hook_types.get(c.hook_type, 0)
        if count > 0:
            score -= mode.diversity_penalty * count
        seen_hook_types[c.hook_type] = count + 1

        scored.append((score, i))

    # Sort by score descending
    scored.sort(key=lambda x: x[0], reverse=True)

    reranked_candidates = []
    reranked_refined = []
    for new_rank, (score, original_idx) in enumerate(scored, 1):
        c = candidates[original_idx]
        r = refined[original_idx]
        old_rank = c.rank
        c.rank = new_rank
        if verbose and old_rank != new_rank:
            console.print(
                f"[dim]Rerank: #{old_rank} → #{new_rank} "
                f"(score={score:.1f}, hook={c.hook_type})[/dim]"
            )
        reranked_candidates.append(c)
        reranked_refined.append(r)

    return reranked_candidates, reranked_refined


def _validate_candidates(
    candidates: list[ColdOpenCandidate],
    transcript: Transcript,
    audio_duration: float,
    mode: ExtractionMode = COLD_OPEN_MODE,
    verbose: bool = False,
) -> list[ColdOpenCandidate]:
    """Validate and repair candidate timestamps."""
    valid_candidates = []
    for c in candidates:
        original_duration = c.end_time - c.start_time

        if verbose:
            multi_tag = " [multi-segment]" if c.is_multi_segment else ""
            console.print(
                f"[dim]Candidate {c.rank}: {c.start_time:.1f}s - {c.end_time:.1f}s "
                f"({original_duration:.1f}s) - {c.hook_type}{multi_tag}[/dim]"
            )

        # Reject multi-segment candidates when mode disallows them
        if c.is_multi_segment and not mode.allow_multi_segment:
            if verbose:
                console.print(
                    f"[yellow]Candidate {c.rank} is multi-segment but "
                    f"{mode.label} mode does not allow multi-segment. Skipping.[/yellow]"
                )
            continue

        # Fix timestamps that exceed audio duration
        if c.end_time > audio_duration:
            c.end_time = audio_duration
        if c.start_time > audio_duration:
            continue

        # For multi-segment candidates, validate segment timestamps too
        if c.is_multi_segment and c.segments:
            valid_segments = []
            for seg in c.segments:
                if seg.end_time > audio_duration:
                    seg.end_time = audio_duration
                if seg.start_time > audio_duration:
                    continue
                if seg.end_time > seg.start_time:
                    valid_segments.append(seg)
            c.segments = valid_segments
            if not valid_segments:
                continue
        else:
            # If candidate duration is broken (below mode minimum), try to repair from transcript
            if c.end_time - c.start_time < mode.min_duration_sec:
                if verbose:
                    console.print(
                        f"[yellow]Candidate {c.rank} has broken timestamps "
                        f"({c.end_time - c.start_time:.1f}s). Attempting repair...[/yellow]"
                    )
                repaired = _repair_timestamps_from_transcript(c, transcript, verbose=verbose)
                if not repaired:
                    if verbose:
                        console.print(f"[yellow]Could not repair Candidate {c.rank}. Dropping.[/yellow]")
                    continue

        if c.end_time <= c.start_time:
            continue

        valid_candidates.append(c)

    return valid_candidates


def _optimize_cut_points(
    candidates: list[ColdOpenCandidate],
    audio_path: Path,
    transcript: Transcript,
    audio_duration: float,
    num_candidates: int,
    mode: ExtractionMode = COLD_OPEN_MODE,
    verbose: bool = False,
) -> tuple[list[ColdOpenCandidate], list[RefinedTimestamp]]:
    """Run cut point optimization, duration filtering, and limit to requested count."""
    refined = refine_cut_points(
        candidates=candidates,
        audio_path=audio_path,
        transcript=transcript,
        audio_duration=audio_duration,
    )

    # Handle multi-segment candidates: refine each part
    # Skip entirely when mode disallows multi-segment (e.g. clip mode)
    # Pre-compute silence regions once if any multi-segment candidates exist
    silence_cache = None
    for i, (c, r) in enumerate(zip(candidates, refined)):
        if c.is_multi_segment and c.segments and mode.allow_multi_segment:
            from podcut.models import RefinedTimestampPart
            from podcut.silence_detector import find_nearest_silence, find_nearest_word_boundary, detect_silence_regions

            if silence_cache is None:
                silence_cache = detect_silence_regions(audio_path)
            silence_regions = silence_cache
            parts = []
            total_duration = 0.0
            any_word_boundary = False
            for seg in c.segments:
                seg_start = seg.start_time
                seg_end = seg.end_time
                start_quality = "clean"
                end_quality = "clean"

                sil = find_nearest_silence(seg_start, silence_regions)
                if sil is not None:
                    seg_start = sil
                else:
                    wb = find_nearest_word_boundary(seg_start, transcript)
                    if wb is not None:
                        seg_start = wb
                        start_quality = "word_boundary"

                sil = find_nearest_silence(seg_end, silence_regions)
                if sil is not None:
                    seg_end = sil
                else:
                    wb = find_nearest_word_boundary(seg_end, transcript)
                    if wb is not None:
                        seg_end = wb
                        end_quality = "word_boundary"

                seg_start = max(0.0, min(seg_start, audio_duration))
                seg_end = max(0.0, min(seg_end, audio_duration))
                if seg_end <= seg_start:
                    seg_end = min(seg_start + 15.0, audio_duration)

                part_quality = "word_boundary" if start_quality == "word_boundary" or end_quality == "word_boundary" else "clean"
                if part_quality == "word_boundary":
                    any_word_boundary = True

                part_dur = round(seg_end - seg_start, 3)
                total_duration += part_dur
                parts.append(RefinedTimestampPart(
                    refined_start_sec=round(seg_start, 3),
                    refined_end_sec=round(seg_end, 3),
                    duration_seconds=part_dur,
                    cut_quality=part_quality,
                ))

            overall_quality = "word_boundary" if any_word_boundary else "clean"
            refined[i] = RefinedTimestamp(
                original_rank=c.rank,
                refined_start_sec=parts[0].refined_start_sec if parts else r.refined_start_sec,
                refined_end_sec=parts[-1].refined_end_sec if parts else r.refined_end_sec,
                duration_seconds=round(total_duration, 3),
                cut_quality=overall_quality,
                parts=parts,
            )

    candidates, refined = _filter_by_duration(
        candidates, refined,
        min_sec=mode.min_duration_sec,
        max_sec=mode.max_duration_sec,
        verbose=verbose,
    )
    candidates = candidates[:num_candidates]
    refined = refined[:num_candidates]
    return candidates, refined


def _run_analysis(
    audio_path: Path,
    provider: LLMProvider,
    num_candidates: int,
    whisper_model: str,
    whisper_backend: str,
    mode: ExtractionMode = COLD_OPEN_MODE,
    verbose: bool = False,
    step_offset: int = 0,
    total_steps: int = 4,
) -> tuple[list[ColdOpenCandidate], list[RefinedTimestamp], Transcript, str, float]:
    """Run analysis phase: transcribe, analyze, validate, optimize.

    The provider must have already uploaded the audio file.

    Args:
        step_offset: Number of steps already completed (0 if upload was skipped).
        total_steps: Total number of steps in the pipeline.

    Returns:
        Tuple of (candidates, refined, transcript, transcript_text, audio_duration)
    """
    s1 = step_offset + 1
    s2 = step_offset + 2
    s3 = step_offset + 3

    # Whisper transcription
    console.print(t("step_header", current=s1, total=total_steps, title=t("transcribing_step", model=whisper_model)))
    transcript = _run_with_progress(
        t("transcribing"), transcribe,
        audio_path, model_name=whisper_model, backend=whisper_backend, verbose=verbose,
    )
    console.print(f"  [green]{t('ok')}:[/green] {t('transcription_done', segments=len(transcript.segments), words=len(transcript.words))}")

    if not transcript.segments:
        raise RuntimeError(t("no_transcript"))

    transcript_text = format_transcript_with_timestamps(transcript)

    original_len = len(transcript_text)
    transcript_text = _truncate_transcript(transcript_text, strategy=mode.transcript_strategy)
    if len(transcript_text) < original_len and verbose:
        console.print(
            f"[yellow]{t('transcript_truncated', original=original_len, truncated=len(transcript_text))}[/yellow]"
        )

    # Content analysis
    console.print(t("step_header", current=s2, total=total_steps, title=t("analyzing_with_llm")))
    # Request extra candidates to account for filtering losses; cap at 10 to limit API cost
    request_count = min(num_candidates + 2, 10)
    candidates = _run_with_progress(
        t("llm_analyzing"), provider.analyze,
        transcript_text=transcript_text,
        num_candidates=request_count,
        mode=mode,
        verbose=verbose,
    )

    if not candidates:
        raise RuntimeError(t("llm_no_candidates", label=mode.ui_label.lower()))
    console.print(f"  [green]{t('ok')}:[/green] {t('candidates_found', count=len(candidates))}")

    # Validate timestamps
    audio = load_audio(audio_path)
    audio_duration = get_audio_duration_sec(audio)
    candidates = _validate_candidates(candidates, transcript, audio_duration, mode=mode, verbose=verbose)

    if not candidates:
        raise RuntimeError(t("no_valid_candidates"))

    # Cut point optimization
    console.print(t("step_header", current=s3, total=total_steps, title=t("optimizing_cut_points")))
    candidates, refined = _optimize_cut_points(
        candidates, audio_path, transcript, audio_duration, num_candidates, mode=mode, verbose=verbose,
    )
    console.print(f"  [green]{t('ok')}:[/green] {t('candidates_optimized', count=len(candidates))}")

    # Local re-ranking using mode-specific weights
    candidates, refined = _rerank(candidates, refined, mode=mode, verbose=verbose)

    return candidates, refined, transcript, transcript_text, audio_duration


def _run_extraction(
    candidates: list[ColdOpenCandidate],
    refined: list[RefinedTimestamp],
    audio_path: Path,
    output_dir: Path,
    output_format: str,
    file_prefix: str = "cold_open",
) -> list[ExtractedSegment]:
    """Run extraction phase: export selected candidates as audio files."""
    console.print(f"[bold cyan]{t('extracting_clips')}[/bold cyan]")
    output_paths = extract_all_segments(
        audio_path=audio_path,
        timestamps=refined,
        output_dir=output_dir,
        output_format=output_format,
        file_prefix=file_prefix,
    )
    console.print(f"  [green]{t('ok')}:[/green] {t('files_exported', count=len(output_paths))}")

    results: list[ExtractedSegment] = []
    for candidate, ts, path in zip(candidates, refined, output_paths):
        results.append(
            ExtractedSegment(
                rank=candidate.rank,
                file_path=path,
                start_time=ts.refined_start_sec,
                end_time=ts.refined_end_sec,
                duration_seconds=ts.duration_seconds,
                hook_type=candidate.hook_type,
                speaker=candidate.speaker,
                transcript_excerpt=candidate.transcript_excerpt,
                reasoning=candidate.reasoning,
                engagement_score=candidate.engagement_score,
                cut_quality=ts.cut_quality,
                self_contained_score=candidate.self_contained_score,
                narrative_completeness=candidate.narrative_completeness,
                context_needed=candidate.context_needed,
                opening_impact_score=candidate.opening_impact_score,
                shareability_score=candidate.shareability_score,
                hook_first_3sec_score=candidate.hook_first_3sec_score,
                suggested_title=candidate.suggested_title,
                completion_hook=candidate.completion_hook,
            )
        )

    return results


def _preflight_provider(provider: LLMProvider) -> None:
    """Run provider preflight checks (SDK install, API key) before heavy work."""
    preflight = getattr(provider, "preflight", None)
    if preflight is not None:
        preflight()


def _create_provider(provider_name: str, model: str) -> LLMProvider:
    """Create an LLM provider by name."""
    if provider_name == "ollama":
        from podcut.ollama_provider import OllamaProvider
        return OllamaProvider(model=model)
    elif provider_name == "gemini":
        from podcut.gemini_provider import GeminiProvider
        return GeminiProvider(model=model)
    elif provider_name == "openai":
        from podcut.openai_provider import OpenAIProvider
        return OpenAIProvider(model=model)
    elif provider_name == "claude":
        from podcut.claude_provider import ClaudeProvider
        return ClaudeProvider(model=model)
    elif provider_name == "grok":
        from podcut.openai_provider import OpenAIProvider
        from podcut.config import GROK_BASE_URL
        return OpenAIProvider(model=model, base_url=GROK_BASE_URL, api_key_env="XAI_API_KEY")
    else:
        raise ValueError(
            f"Unknown LLM provider: '{provider_name}'. "
            f"Supported: {', '.join(AVAILABLE_PROVIDERS)}"
        )


def run_pipeline(
    audio_path: Path,
    output_dir: Path,
    num_candidates: int = DEFAULT_CANDIDATES,
    output_format: str = DEFAULT_FORMAT,
    gemini_model: str = DEFAULT_MODEL,
    whisper_model: str = DEFAULT_WHISPER_MODEL,
    whisper_backend: str = "auto",
    mode: ExtractionMode = COLD_OPEN_MODE,
    verbose: bool = False,
    provider_name: str = "gemini",
    llm_model: str | None = None,
) -> list[ExtractedSegment]:
    """Run the full cold open finder pipeline (non-interactive, exports all)."""
    effective_model = llm_model or gemini_model
    provider: LLMProvider = _create_provider(provider_name, effective_model)

    # Preflight: verify SDK/API key before expensive transcription
    _preflight_provider(provider)

    try:
        needs_upload = getattr(provider, "needs_audio_upload", True)
        if needs_upload:
            total_steps = 4
            console.print(t("step_header", current=1, total=total_steps, title=t("uploading_audio")))
            _run_with_progress(t("uploading"), provider.upload, audio_path, verbose=verbose)
            console.print(f"  [green]{t('ok')}:[/green] {t('upload_done')}")
            step_offset = 1
        else:
            total_steps = 3
            step_offset = 0

        candidates, refined, transcript, transcript_text, audio_duration = _run_analysis(
            audio_path=audio_path,
            provider=provider,
            num_candidates=num_candidates,
            whisper_model=whisper_model,
            whisper_backend=whisper_backend,
            mode=mode,
            verbose=verbose,
            step_offset=step_offset,
            total_steps=total_steps,
        )

        return _run_extraction(
            candidates, refined, audio_path, output_dir, output_format,
            file_prefix=mode.output_file_prefix,
        )

    finally:
        provider.cleanup(verbose=verbose)


def run_pipeline_interactive(
    audio_path: Path,
    output_dir: Path,
    num_candidates: int = DEFAULT_CANDIDATES,
    output_format: str = DEFAULT_FORMAT,
    gemini_model: str = DEFAULT_MODEL,
    whisper_model: str = DEFAULT_WHISPER_MODEL,
    whisper_backend: str = "auto",
    mode: ExtractionMode = COLD_OPEN_MODE,
    verbose: bool = False,
    auto: bool = False,
    provider_name: str = "gemini",
    llm_model: str | None = None,
) -> list[ExtractedSegment]:
    """Run the interactive cold open finder pipeline.

    Phases:
    1. Analysis (transcribe → upload → analyze → optimize)
    2. Preview and user selection (or auto-export if auto=True)
    3. Feedback loop (up to MAX_FEEDBACK_ROUNDS times)
    4. Extraction of selected candidates
    """
    effective_model = llm_model or gemini_model
    provider: LLMProvider = _create_provider(provider_name, effective_model)

    # Preflight: verify SDK/API key before expensive transcription
    _preflight_provider(provider)

    try:
        needs_upload = getattr(provider, "needs_audio_upload", True)
        if needs_upload:
            total_steps = 4
            console.print(t("step_header", current=1, total=total_steps, title=t("uploading_audio")))
            _run_with_progress(t("uploading"), provider.upload, audio_path, verbose=verbose)
            console.print(f"  [green]{t('ok')}:[/green] {t('upload_done')}")
            step_offset = 1
        else:
            total_steps = 3
            step_offset = 0

        candidates, refined, transcript, transcript_text, audio_duration = _run_analysis(
            audio_path=audio_path,
            provider=provider,
            num_candidates=num_candidates,
            whisper_model=whisper_model,
            whisper_backend=whisper_backend,
            mode=mode,
            verbose=verbose,
            step_offset=step_offset,
            total_steps=total_steps,
        )

        # Auto mode: export all candidates immediately
        if auto:
            return _run_extraction(
                candidates, refined, audio_path, output_dir, output_format,
                file_prefix=mode.output_file_prefix,
            )

        # Interactive loop
        feedback_round = 0
        while True:
            display_candidates_preview(candidates, refined, mode=mode)

            selected_indices, feedback = prompt_user_selection(candidates)

            if feedback is not None:
                # User provided feedback → re-analyze
                feedback_round += 1
                if feedback_round > MAX_FEEDBACK_ROUNDS:
                    console.print(
                        f"[yellow]{t('max_feedback_rounds', max=MAX_FEEDBACK_ROUNDS)}[/yellow]"
                    )
                    selected_indices = list(range(len(candidates)))
                    feedback = None
                else:
                    console.print(
                        f"\n{t('step_header', current=step_offset + 2, total=total_steps, title=t('reanalyzing_with_feedback', round=feedback_round, max=MAX_FEEDBACK_ROUNDS))}"
                    )
                    request_count = min(num_candidates + 2, 10)
                    new_candidates = _run_with_progress(
                        t("feedback_analyzing"), provider.analyze_with_feedback,
                        transcript_text=transcript_text,
                        num_candidates=request_count,
                        previous=candidates,
                        feedback=feedback,
                        mode=mode,
                        verbose=verbose,
                    )

                    if not new_candidates:
                        console.print(
                            f"[yellow]{t('reanalysis_no_candidates')}[/yellow]"
                        )
                        continue

                    new_candidates = _validate_candidates(
                        new_candidates, transcript, audio_duration, mode=mode, verbose=verbose,
                    )

                    if not new_candidates:
                        console.print(f"[yellow]{t('reanalysis_no_valid')}[/yellow]")
                        continue

                    console.print(t("step_header", current=step_offset + 3, total=total_steps, title=t("optimizing_cut_points")))
                    candidates, refined = _optimize_cut_points(
                        new_candidates, audio_path, transcript, audio_duration, num_candidates,
                        mode=mode, verbose=verbose,
                    )
                    candidates, refined = _rerank(candidates, refined, mode=mode, verbose=verbose)
                    continue

            # User selected specific candidates
            if not selected_indices:
                console.print(f"[yellow]{t('no_candidates_selected')}[/yellow]")
                return []

            selected_candidates = [candidates[i] for i in selected_indices]
            selected_refined = [refined[i] for i in selected_indices]

            return _run_extraction(
                selected_candidates, selected_refined, audio_path, output_dir, output_format,
                file_prefix=mode.output_file_prefix,
            )

    finally:
        provider.cleanup(verbose=verbose)
