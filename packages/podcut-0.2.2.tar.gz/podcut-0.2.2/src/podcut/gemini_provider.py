"""Gemini-based LLM provider implementation."""

from __future__ import annotations

from pathlib import Path

from podcut.config import DEFAULT_MODEL
from podcut.extraction_mode import COLD_OPEN_MODE, ExtractionMode
from podcut.gemini_client import (
    analyze_content,
    analyze_content_with_feedback,
    delete_uploaded_file,
    upload_audio,
)
from podcut.models import ColdOpenCandidate


class GeminiProvider:
    """LLM provider backed by Google Gemini API.

    Wraps the existing gemini_client functions to conform to the LLMProvider protocol.
    """

    def __init__(self, model: str = DEFAULT_MODEL) -> None:
        self._model = model
        self._uploaded_file: object | None = None

    def upload(self, audio_path: Path, verbose: bool = False) -> None:
        self._uploaded_file = upload_audio(audio_path, verbose=verbose)

    def analyze(
        self,
        transcript_text: str,
        num_candidates: int,
        mode: ExtractionMode = COLD_OPEN_MODE,
        verbose: bool = False,
    ) -> list[ColdOpenCandidate]:
        if self._uploaded_file is None:
            raise RuntimeError("No audio uploaded. Call upload() first.")
        return analyze_content(
            uploaded_file=self._uploaded_file,
            transcript_text=transcript_text,
            num_candidates=num_candidates,
            model=self._model,
            mode=mode,
            verbose=verbose,
        )

    def analyze_with_feedback(
        self,
        transcript_text: str,
        num_candidates: int,
        previous: list[ColdOpenCandidate],
        feedback: str,
        mode: ExtractionMode = COLD_OPEN_MODE,
        verbose: bool = False,
    ) -> list[ColdOpenCandidate]:
        if self._uploaded_file is None:
            raise RuntimeError("No audio uploaded. Call upload() first.")
        return analyze_content_with_feedback(
            uploaded_file=self._uploaded_file,
            transcript_text=transcript_text,
            num_candidates=num_candidates,
            previous_candidates=previous,
            feedback=feedback,
            model=self._model,
            mode=mode,
            verbose=verbose,
        )

    def cleanup(self, verbose: bool = False) -> None:
        if self._uploaded_file is not None:
            delete_uploaded_file(self._uploaded_file, verbose=verbose)
            self._uploaded_file = None
