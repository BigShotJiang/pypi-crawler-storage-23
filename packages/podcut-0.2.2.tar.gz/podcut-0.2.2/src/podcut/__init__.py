"""podcut - AI-powered podcast segment extractor."""

__version__ = "0.2.2"


def _init_language() -> None:
    """Initialize i18n language from environment config."""
    from podcut.config import DEFAULT_LANGUAGE
    from podcut.i18n import set_language

    set_language(DEFAULT_LANGUAGE)


_init_language()
