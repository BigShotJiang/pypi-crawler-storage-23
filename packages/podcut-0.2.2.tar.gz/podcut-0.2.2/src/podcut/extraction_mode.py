"""Extraction mode definitions for cold open and clip modes."""

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ExtractionMode:
    """Defines the parameters for an extraction mode."""

    name: str
    label: str
    label_plural: str
    min_duration_sec: int
    max_duration_sec: int
    description: str
    hook_types: tuple[str, ...]
    hook_type_descriptions: dict[str, str]
    allow_multi_segment: bool
    output_file_prefix: str
    # i18n keys for UI display (if set, t(key) is used for translated labels)
    i18n_label_key: str = ""
    i18n_label_plural_key: str = ""
    quality_criteria: tuple[str, ...] = ()
    transcript_strategy: str = "head_tail"
    # Reranking weights: keys are score field names, values are weights (should sum to ~1.0)
    rerank_weights: dict[str, float] = field(default_factory=dict)
    # Penalty applied when context_needed == "significant"
    context_significant_penalty: float = 3.0
    # Penalty for duplicate hook_types (applied to 2nd+ candidate with same type)
    diversity_penalty: float = 1.0
    # Patterns that should be penalized at the start of a segment (for cold opens)
    avoid_start_patterns: tuple[str, ...] = ()
    # Extra score fields this mode requires from the LLM
    extra_score_fields: tuple[str, ...] = ()

    @property
    def ui_label(self) -> str:
        """Return translated label for UI display."""
        if self.i18n_label_key:
            from podcut.i18n import t
            return t(self.i18n_label_key)
        return self.label

    @property
    def ui_label_plural(self) -> str:
        """Return translated plural label for UI display."""
        if self.i18n_label_plural_key:
            from podcut.i18n import t
            return t(self.i18n_label_plural_key)
        return self.label_plural


COLD_OPEN_MODE = ExtractionMode(
    name="cold_open",
    label="Cold Open",
    label_plural="Cold Open Candidates",
    i18n_label_key="mode_label_cold_open",
    i18n_label_plural_key="mode_label_cold_open_plural",
    min_duration_sec=10,
    max_duration_sec=90,
    description="A short teaser (10-90 seconds) played at the very beginning of an episode to hook the listener.",
    hook_types=("question", "story", "surprising_fact", "debate", "humor", "insight", "tsukkomi", "confession", "realization"),
    hook_type_descriptions={
        "question": "A provocative or intriguing question",
        "story": "Beginning of a compelling story or anecdote",
        "surprising_fact": "A surprising or counterintuitive statement",
        "debate": "A moment of disagreement or tension",
        "humor": "A funny moment or joke",
        "insight": "A profound or thought-provoking observation",
        "tsukkomi": "A sharp retort, comeback, or witty correction (ツッコミ) - common in Japanese content",
        "confession": "A candid, vulnerable, or honest personal disclosure (本音吐露)",
        "realization": "An 'aha moment' or sudden epiphany (気づきの瞬間)",
    },
    allow_multi_segment=True,
    output_file_prefix="cold_open",
    quality_criteria=(
        "Opens with a strong audio hook (question, exclamation, laughter, dramatic pause)",
        "Creates immediate curiosity or tension in the first 3 seconds",
        "Works as a standalone teaser without needing prior episode context",
        "Has a natural stopping point that leaves the listener wanting more",
        "Contains vocal energy, emotion, or tonal shifts that grab attention",
        "For Japanese podcasts: reactions like えーっ！, マジで！？, ウソでしょ！ are strong hooks",
        "For Japanese podcasts: tsukkomi/boke timing and comedic rhythm count as humor hooks",
    ),
    transcript_strategy="head_tail",
    rerank_weights={
        "hook_first_3sec_score": 0.30,
        "opening_impact_score": 0.25,
        "engagement_score": 0.25,
        "self_contained_score": 0.20,
    },
    context_significant_penalty=3.0,
    diversity_penalty=1.0,
    avoid_start_patterns=(
        # Japanese fillers and weak openings
        "えーと",
        "えっと",
        "あのですね",
        "えーとですね",
        "まあそうですね",
        "どうなんでしょう",
        "そういえば",
        # Japanese greetings and intros
        "今日は",
        "こんにちは",
        "こんばんは",
        "改めまして",
        "はじめまして",
        "お疲れ様",
        # Context-dependent phrases
        "前回の続き",
        "さっきの",
        "先ほどの",
        "ということで",
        "ちょっと話変わるんですけど",
        "前にも話した",
        "さっき言った",
        "結論から言うと",
        "つまりですね",
        # English greetings and weak openings
        "as I was saying",
        "so today",
        "welcome to",
        "hello everyone",
        "hi guys",
        "hey everyone",
        "good morning",
        "alright so",
        "okay so",
        "um so",
    ),
    extra_score_fields=("opening_impact_score", "hook_first_3sec_score"),
)

CLIP_MODE = ExtractionMode(
    name="clip",
    label="Clip",
    label_plural="Clip Candidates",
    i18n_label_key="mode_label_clip",
    i18n_label_plural_key="mode_label_clip_plural",
    min_duration_sec=60,
    max_duration_sec=600,
    description="A standalone clip (1-10 minutes) that can be shared as a highlight or excerpt.",
    hook_types=(
        "deep_dive",
        "story",
        "debate",
        "insight",
        "practical_advice",
        "emotional_moment",
        "humor",
        "tsukkomi",
        "confession",
        "realization",
    ),
    hook_type_descriptions={
        "deep_dive": "An in-depth exploration of a fascinating topic",
        "story": "A compelling story or anecdote told in full",
        "debate": "A lively disagreement or discussion with tension",
        "insight": "A profound or thought-provoking observation with context",
        "practical_advice": "Actionable advice or how-to explanation",
        "emotional_moment": "An emotionally resonant moment",
        "humor": "A funny exchange or comedic segment",
        "tsukkomi": "A sharp retort, comeback, or witty correction (ツッコミ) - common in Japanese content",
        "confession": "A candid, vulnerable, or honest personal disclosure (本音吐露)",
        "realization": "An 'aha moment' or sudden epiphany with full context (気づきの瞬間)",
    },
    allow_multi_segment=False,
    output_file_prefix="clip",
    quality_criteria=(
        "Self-contained: understandable without listening to the full episode",
        "Has a clear beginning, development, and natural conclusion",
        "Covers a complete topic, story, or discussion thread",
        "Shareable: would make sense posted independently on social media",
        "Does not start or end mid-sentence or mid-thought",
        "For Japanese podcasts: complete tsukkomi/boke exchanges, full anecdotes with punchlines",
    ),
    transcript_strategy="full",
    rerank_weights={
        "narrative_completeness": 0.30,
        "self_contained_score": 0.30,
        "engagement_score": 0.25,
        "shareability_score": 0.15,
    },
    context_significant_penalty=3.0,
    diversity_penalty=1.0,
    extra_score_fields=("shareability_score",),
)

MODE_REGISTRY: dict[str, ExtractionMode] = {
    COLD_OPEN_MODE.name: COLD_OPEN_MODE,
    CLIP_MODE.name: CLIP_MODE,
}

AVAILABLE_MODES = list(MODE_REGISTRY.keys())


def get_mode(name: str) -> ExtractionMode:
    """Get an extraction mode by name.

    Raises:
        ValueError: If the mode name is not recognized.
    """
    if name not in MODE_REGISTRY:
        available = ", ".join(AVAILABLE_MODES)
        raise ValueError(f"Unknown extraction mode: '{name}'. Available modes: {available}")
    return MODE_REGISTRY[name]
