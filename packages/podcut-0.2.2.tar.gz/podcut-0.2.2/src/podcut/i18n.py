"""Simple dictionary-based i18n module for UI text."""

from __future__ import annotations

from typing import Any

_lang: str = "ja"
SUPPORTED_LANGUAGES = ("ja", "en")

_HOOK_TYPE_JA: dict[str, str] = {
    "question": "質問",
    "story": "ストーリー",
    "surprising_fact": "意外な事実",
    "debate": "ディベート",
    "humor": "ユーモア",
    "insight": "インサイト",
    "deep_dive": "深掘り",
    "practical_advice": "実用アドバイス",
    "emotional_moment": "感動の瞬間",
    "tsukkomi": "ツッコミ",
    "confession": "本音吐露",
    "realization": "気づき",
}

_CONTEXT_NEEDED_JA: dict[str, str] = {
    "none": "なし",
    "minimal": "少し必要",
    "significant": "かなり必要",
}

_MESSAGES: dict[str, dict[str, str]] = {
    # ── General ──
    "cancelled_by_user": {
        "ja": "ユーザーによりキャンセルされました。",
        "en": "Cancelled by user.",
    },
    "wizard_cancelled": {
        "ja": "ウィザードがキャンセルされました。",
        "en": "Wizard cancelled.",
    },
    "press_ctrl_c": {
        "ja": "Ctrl+C でキャンセル",
        "en": "Press Ctrl+C to cancel",
    },
    "ok": {
        "ja": "OK",
        "en": "OK",
    },

    # ── Wizard welcome ──
    "welcome_subtitle": {
        "ja": "Tab でファイルパス補完、Ctrl+C でキャンセル",
        "en": "Tab for file path completion, Ctrl+C to cancel",
    },

    # ── Wizard prompt helpers ──
    "prompt_enter_file_path": {
        "ja": "ファイルパスを入力してください。",
        "en": "Please enter a file path.",
    },
    "prompt_file_not_found": {
        "ja": "ファイルが見つかりません: {path}",
        "en": "File not found: {path}",
    },
    "prompt_unsupported_format": {
        "ja": "非対応フォーマット ({suffix})。対応: {exts}",
        "en": "Unsupported format ({suffix}). Supported: {exts}",
    },
    "prompt_enter_number_range": {
        "ja": "{min_val}-{max_val} の数値を入力してください。",
        "en": "Please enter a number ({min_val}-{max_val}).",
    },
    "prompt_must_be_between": {
        "ja": "{min_val} から {max_val} の間で入力してください。",
        "en": "Must be between {min_val} and {max_val}.",
    },
    "prompt_enter_1_to_n": {
        "ja": "1-{n} を入力してください。",
        "en": "Enter 1-{n}.",
    },
    "prompt_invalid_choice": {
        "ja": "無効な選択です。数値 (1-{n}) または次から入力: {options}",
        "en": "Invalid choice. Enter a number (1-{n}) or one of: {options}",
    },
    "default_tag": {
        "ja": " (デフォルト)",
        "en": " (default)",
    },
    "enter_number_or_value": {
        "ja": "番号または値を入力",
        "en": "Enter number or value",
    },

    # ── Wizard steps ──
    "step_header": {
        "ja": "[bold cyan]ステップ {current}/{total}:[/bold cyan] {title}",
        "en": "[bold cyan]Step {current}/{total}:[/bold cyan] {title}",
    },
    "step_language": {
        "ja": "Language / 言語",
        "en": "Language / 言語",
    },
    "step_llm_provider": {
        "ja": "LLM プロバイダ",
        "en": "LLM Provider",
    },
    "step_extraction_mode": {
        "ja": "抽出モード",
        "en": "Extraction Mode",
    },
    "step_audio_file": {
        "ja": "音声ファイル",
        "en": "Audio File",
    },
    "step_ollama_model": {
        "ja": "Ollama モデル",
        "en": "Ollama Model",
    },
    "step_gemini_model": {
        "ja": "Gemini モデル",
        "en": "Gemini Model",
    },
    "step_openai_model": {
        "ja": "OpenAI モデル",
        "en": "OpenAI Model",
    },
    "step_claude_model": {
        "ja": "Claude モデル",
        "en": "Claude Model",
    },
    "step_grok_model": {
        "ja": "Grok モデル",
        "en": "Grok Model",
    },
    "step_whisper_model": {
        "ja": "Whisper モデル",
        "en": "Whisper Model",
    },
    "step_num_candidates": {
        "ja": "候補数",
        "en": "Number of Candidates",
    },
    "step_output_format": {
        "ja": "出力フォーマット",
        "en": "Output Format",
    },

    # ── Wizard prompts ──
    "select_language": {
        "ja": "  言語を選択:",
        "en": "  Select language:",
    },
    "select_llm_provider": {
        "ja": "  LLM プロバイダを選択:",
        "en": "  Select LLM provider:",
    },
    "select_extraction_mode": {
        "ja": "  抽出モードを選択:",
        "en": "  Select extraction mode:",
    },
    "select_ollama_model": {
        "ja": "  Ollama モデルを選択:",
        "en": "  Select Ollama model:",
    },
    "select_gemini_model": {
        "ja": "  Gemini モデルを選択:",
        "en": "  Select Gemini model:",
    },
    "select_openai_model": {
        "ja": "  OpenAI モデルを選択:",
        "en": "  Select OpenAI model:",
    },
    "select_claude_model": {
        "ja": "  Claude モデルを選択:",
        "en": "  Select Claude model:",
    },
    "select_grok_model": {
        "ja": "  Grok モデルを選択:",
        "en": "  Select Grok model:",
    },
    "select_whisper_model": {
        "ja": "  Whisper モデルを選択:",
        "en": "  Select Whisper model:",
    },
    "select_output_format": {
        "ja": "  出力音声フォーマットを選択:",
        "en": "  Select output audio format:",
    },
    "path_to_audio": {
        "ja": "ポッドキャスト音声ファイルのパス",
        "en": "Path to podcast audio file",
    },
    "audio_files_found": {
        "ja": "  音声ファイルが見つかりました:",
        "en": "  Audio files found:",
    },
    "audio_file_entry": {
        "ja": "    {num}. {name}  ({size})",
        "en": "    {num}. {name}  ({size})",
    },
    "audio_select_or_path": {
        "ja": "番号を入力、またはファイルパスを直接入力 (Tab補完あり)",
        "en": "Enter number, or type file path (Tab completion available)",
    },
    "no_audio_files_found": {
        "ja": "  [dim]カレントディレクトリに音声ファイルが見つかりません。パスを直接入力してください。[/dim]",
        "en": "  [dim]No audio files found in current directory. Enter path directly.[/dim]",
    },
    "how_many_candidates": {
        "ja": "{label} の候補をいくつ検出しますか？",
        "en": "How many {label} candidates?",
    },
    "proceed_with_analysis": {
        "ja": "分析を開始しますか？",
        "en": "Proceed with analysis?",
    },

    # ── Provider descriptions ──
    "provider_gemini_desc": {
        "ja": "Google Gemini API (クラウド、高精度)",
        "en": "Google Gemini API (cloud, high accuracy)",
    },
    "provider_ollama_desc": {
        "ja": "Ollama ローカルLLM (オフライン、無料)",
        "en": "Ollama local LLM (offline, free)",
    },
    "provider_openai_desc": {
        "ja": "OpenAI GPT API (クラウド、高精度)",
        "en": "OpenAI GPT API (cloud, high accuracy)",
    },
    "provider_claude_desc": {
        "ja": "Anthropic Claude API (クラウド、高精度)",
        "en": "Anthropic Claude API (cloud, high accuracy)",
    },
    "provider_grok_desc": {
        "ja": "xAI Grok API (クラウド)",
        "en": "xAI Grok API (cloud)",
    },

    # ── Mode descriptions ──
    "mode_cold_open_desc": {
        "ja": "短いティーザー ({min}-{max}秒)",
        "en": "Short teaser ({min}-{max}s)",
    },
    "mode_clip_desc": {
        "ja": "切り抜きクリップ ({min}-{max}分)",
        "en": "Clip excerpt ({min}-{max}min)",
    },

    # ── Whisper descriptions ──
    "whisper_tiny": {
        "ja": "約1分 / 最速、精度低",
        "en": "~1min / fastest, lowest accuracy",
    },
    "whisper_base": {
        "ja": "約2分 / 高速、基本精度",
        "en": "~2min / fast, basic accuracy",
    },
    "whisper_small": {
        "ja": "約5分 / 速度と精度のバランス",
        "en": "~5min / balanced speed & accuracy",
    },
    "whisper_medium": {
        "ja": "約10分 / 高精度",
        "en": "~10min / good accuracy",
    },
    "whisper_turbo": {
        "ja": "高速 / large相当の精度、推奨",
        "en": "fast / large-level accuracy, recommended",
    },
    "whisper_large": {
        "ja": "約20分以上 / 最高精度、低速",
        "en": "~20min+ / best accuracy, slow",
    },

    # ── Summary table ──
    "summary_title": {
        "ja": "設定サマリー",
        "en": "Configuration Summary",
    },
    "summary_audio_file": {
        "ja": "音声ファイル",
        "en": "Audio file",
    },
    "summary_file_size": {
        "ja": "ファイルサイズ",
        "en": "File size",
    },
    "summary_extraction_mode": {
        "ja": "抽出モード",
        "en": "Extraction mode",
    },
    "summary_llm_provider": {
        "ja": "LLM プロバイダ",
        "en": "LLM provider",
    },
    "summary_llm_model": {
        "ja": "LLM モデル",
        "en": "LLM model",
    },
    "summary_whisper_model": {
        "ja": "Whisper モデル",
        "en": "Whisper model",
    },
    "summary_candidates": {
        "ja": "候補数",
        "en": "Candidates",
    },
    "summary_output_format": {
        "ja": "出力フォーマット",
        "en": "Output format",
    },
    "summary_output_dir": {
        "ja": "出力ディレクトリ",
        "en": "Output directory",
    },

    # ── Analysis info ──
    "analyzing": {
        "ja": "分析中: {name}",
        "en": "Analyzing: {name}",
    },
    "mode_info": {
        "ja": "モード: {label}",
        "en": "Mode: {label}",
    },
    "provider_info": {
        "ja": "プロバイダ: {provider} ({model})",
        "en": "Provider: {provider} ({model})",
    },
    "auto_mode_info": {
        "ja": "自動モード: 全候補をエクスポート",
        "en": "Auto mode: exporting all candidates",
    },
    "interactive_mode_info": {
        "ja": "インタラクティブモード: 分析後に候補を選択",
        "en": "Interactive mode: you'll choose candidates after analysis",
    },

    # ── Workflow progress ──
    "progress_elapsed": {
        "ja": "{label}... ({elapsed:.0f}秒 経過)",
        "en": "{label}... ({elapsed:.0f}s elapsed)",
    },
    "progress_done": {
        "ja": "{label}... 完了 ({elapsed:.0f}秒)",
        "en": "{label}... done ({elapsed:.0f}s)",
    },
    "transcribing": {
        "ja": "文字起こし中",
        "en": "Transcribing",
    },
    "transcribing_step": {
        "ja": "Whisper ({model}) で音声を文字起こし中...",
        "en": "Transcribing audio with Whisper ({model})...",
    },
    "transcription_done": {
        "ja": "{segments} セグメント, {words} ワード",
        "en": "{segments} segments, {words} words",
    },
    "no_transcript": {
        "ja": "Whisper が文字起こしを生成できませんでした。音声が無音か破損している可能性があります。",
        "en": "Whisper produced no transcript segments. The audio may be silent or corrupt.",
    },
    "transcript_truncated": {
        "ja": "文字起こしを {original:,} から {truncated:,} 文字に切り詰めました（LLMプロンプト用）。",
        "en": "Transcript truncated from {original:,} to {truncated:,} characters for LLM prompt.",
    },
    "analyzing_with_llm": {
        "ja": "LLM でコンテンツを分析中...",
        "en": "Analyzing content with LLM...",
    },
    "llm_analyzing": {
        "ja": "LLM で分析中",
        "en": "Analyzing with LLM",
    },
    "llm_no_candidates": {
        "ja": "LLM が {label} の候補を返しませんでした。",
        "en": "LLM returned no {label} candidates.",
    },
    "candidates_found": {
        "ja": "{count} 候補を検出",
        "en": "{count} candidates found",
    },
    "no_valid_candidates": {
        "ja": "タイムスタンプ検証後に有効な候補がありません。LLMが不正なタイムスタンプを返した可能性があります。",
        "en": "No valid candidates after timestamp validation. The LLM may have returned incorrect timestamps.",
    },
    "optimizing_cut_points": {
        "ja": "カットポイントを最適化中...",
        "en": "Optimizing cut points...",
    },
    "candidates_optimized": {
        "ja": "{count} 候補を最適化",
        "en": "{count} candidates optimized",
    },
    "extracting_clips": {
        "ja": "音声クリップを抽出中...",
        "en": "Extracting audio clips...",
    },
    "files_exported": {
        "ja": "{count} ファイルを書き出し",
        "en": "{count} files exported",
    },
    "uploading_audio": {
        "ja": "音声を API にアップロード中...",
        "en": "Uploading audio to API...",
    },
    "uploading": {
        "ja": "アップロード中",
        "en": "Uploading",
    },
    "upload_done": {
        "ja": "アップロード完了",
        "en": "Upload complete",
    },
    "max_feedback_rounds": {
        "ja": "フィードバック上限 ({max}) に達しました。現在の候補をエクスポートします。",
        "en": "Maximum feedback rounds ({max}) reached. Exporting current candidates.",
    },
    "reanalyzing_with_feedback": {
        "ja": "フィードバックを元に再分析 (ラウンド {round}/{max})...",
        "en": "Re-analyzing with feedback (round {round}/{max})...",
    },
    "feedback_analyzing": {
        "ja": "フィードバックを元に再分析中",
        "en": "Re-analyzing with feedback",
    },
    "reanalysis_no_candidates": {
        "ja": "再分析で候補が得られませんでした。前の結果を維持します。\n別のフィードバックを試すか、現在の候補から選択してください。",
        "en": "Re-analysis returned no candidates. Keeping previous results.\nTry different feedback or select from current candidates.",
    },
    "reanalysis_no_valid": {
        "ja": "再分析後に有効な候補がありません。前の結果を維持します。",
        "en": "No valid candidates after re-analysis. Keeping previous results.",
    },
    "no_candidates_selected": {
        "ja": "候補が選択されませんでした。終了します。",
        "en": "No candidates selected. Exiting.",
    },

    # ── Display ──
    "no_candidates_found": {
        "ja": "{label} の候補が見つかりませんでした。",
        "en": "No {label} candidates found.",
    },
    "col_number": {
        "ja": "#",
        "en": "#",
    },
    "col_time": {
        "ja": "時間",
        "en": "Time",
    },
    "col_duration": {
        "ja": "長さ",
        "en": "Duration",
    },
    "col_hook": {
        "ja": "タイプ",
        "en": "Hook",
    },
    "panel_candidate": {
        "ja": "候補 #{rank}",
        "en": "Candidate #{rank}",
    },
    "col_score": {
        "ja": "スコア",
        "en": "Score",
    },
    "col_self_contained": {
        "ja": "S/C",
        "en": "S/C",
    },
    "col_cut": {
        "ja": "カット",
        "en": "Cut",
    },
    "col_file": {
        "ja": "ファイル",
        "en": "File",
    },
    "cut_clean": {
        "ja": "無音区間",
        "en": "clean",
    },
    "cut_word": {
        "ja": "単語境界",
        "en": "word",
    },
    "label_speaker": {
        "ja": "話者: ",
        "en": "Speaker: ",
    },
    "label_reasoning": {
        "ja": "理由: ",
        "en": "Reasoning: ",
    },
    "label_self_contained": {
        "ja": "自己完結: ",
        "en": "Self-contained: ",
    },
    "label_narrative": {
        "ja": "物語完結: ",
        "en": "Narrative completeness: ",
    },
    "label_context_needed": {
        "ja": "必要文脈: ",
        "en": "Context needed: ",
    },
    "label_suggested_title": {
        "ja": "SNSタイトル: ",
        "en": "Suggested title: ",
    },
    "label_completion_hook": {
        "ja": "最後まで見る理由: ",
        "en": "Why watch to end: ",
    },
    "label_hook_3sec": {
        "ja": "冒頭3秒: ",
        "en": "First 3sec: ",
    },
    "label_excerpt": {
        "ja": "抜粋: ",
        "en": "Excerpt: ",
    },
    "label_segments": {
        "ja": "セグメント:\n",
        "en": "Segments:\n",
    },
    "label_part": {
        "ja": "  パート {i}: {time} ",
        "en": "  Part {i}: {time} ",
    },
    "multi_segment_tag": {
        "ja": " [マルチセグメント]",
        "en": " [multi-segment]",
    },
    "multi_parts": {
        "ja": "[multi] {count} パート",
        "en": "[multi] {count} parts",
    },
    "preview_suffix": {
        "ja": " (プレビュー)",
        "en": " (Preview)",
    },
    "output_saved_to": {
        "ja": "出力ファイルの保存先: {path}",
        "en": "Output files saved to: {path}",
    },

    # ── Selection prompt ──
    "selection_prompt": {
        "ja": (
            "[bold]候補を選んでください:[/bold]\n"
            "  番号を入力 (例: 1,3)  \u2192 選択してエクスポート\n"
            "  all                    \u2192 全候補をエクスポート\n"
            "  その他のテキスト        \u2192 フィードバックとして再分析\n"
        ),
        "en": (
            "[bold]Select candidates:[/bold]\n"
            "  Enter numbers (e.g. 1,3)  \u2192 Select and export\n"
            "  all                        \u2192 Export all candidates\n"
            "  Other text                 \u2192 Re-analyze as feedback\n"
        ),
    },
    "warn_duplicate": {
        "ja": "#{num} は重複しています。スキップします。",
        "en": "#{num} is duplicated, skipping.",
    },
    "warn_out_of_range": {
        "ja": "#{num} は範囲外です (1-{max})。スキップします。",
        "en": "#{num} is out of range (1-{max}), skipping.",
    },

    # ── Settings persistence ──
    "settings_loaded_hint": {
        "ja": "  前回の設定を読み込みました。Enterで前回の値を使用できます。",
        "en": "  Previous settings loaded. Press Enter to use saved values.",
    },
    "settings_saved": {
        "ja": "設定を保存しました。",
        "en": "Settings saved.",
    },
    "api_key_not_found": {
        "ja": "  ⚠ {provider} の API キー ({env_var}) が見つかりません。",
        "en": "  ⚠ {provider} API key ({env_var}) not found.",
    },
    "api_key_get_at": {
        "ja": "  API キーの取得先: {url}",
        "en": "  Get your API key at: {url}",
    },
    "api_key_enter": {
        "ja": "  {label} を入力",
        "en": "  Enter {label}",
    },
    "api_key_required": {
        "ja": "  API キーは必須です。",
        "en": "  API key is required.",
    },
    "api_key_saved": {
        "ja": "  ✓ API キーを {path} に保存しました。",
        "en": "  ✓ API key saved to {path}.",
    },

    # ── Config command ──
    "config_title": {
        "ja": "保存済み設定",
        "en": "Saved Settings",
    },
    "config_col_key": {
        "ja": "項目",
        "en": "Key",
    },
    "config_col_value": {
        "ja": "値",
        "en": "Value",
    },
    "config_reset_done": {
        "ja": "ウィザード設定をリセットしました（APIキーは ~/.config/podcut/.env に保持）。",
        "en": "Wizard preferences reset (API keys in ~/.config/podcut/.env are kept).",
    },
    "config_no_settings": {
        "ja": "保存済み設定はありません。",
        "en": "No saved settings found.",
    },
    "config_run_wizard_hint": {
        "ja": "podcut を実行してウィザードで設定してください。",
        "en": "Run podcut to configure via the wizard.",
    },
    "config_file_location": {
        "ja": "設定ファイル: {path}",
        "en": "Settings file: {path}",
    },

    # ── CLI ──
    "cli_app_help": {
        "ja": "AI ポッドキャスト切り抜きツール。引数なしでインタラクティブウィザードを起動。",
        "en": "AI-powered podcast segment extractor. Run without arguments for interactive wizard.",
    },
    "cli_find_help": {
        "ja": "ポッドキャストエピソードから最適なセグメント候補を検出します。\n\nいつでも Ctrl+C でキャンセルできます。",
        "en": "Find the best segment candidates in a podcast episode.\n\nPress Ctrl+C at any time to cancel.",
    },
    "cli_cleanup_help": {
        "ja": "Gemini Files API からアップロード済みファイルを全て削除します。",
        "en": "Delete all uploaded files from Gemini Files API.",
    },
    "cli_deleted_files": {
        "ja": "Gemini Files API から {count} ファイルを削除しました。",
        "en": "Deleted {count} file(s) from Gemini Files API.",
    },

    # ── Config errors ──
    "gemini_api_key_missing": {
        "ja": (
            "GEMINI_API_KEY 環境変数が設定されていません。\n"
            "API キーの取得先: https://aistudio.google.com/apikey\n"
            "設定方法: export GEMINI_API_KEY=your-key-here\n"
            "または .env ファイルに GEMINI_API_KEY=your-key-here を記載"
        ),
        "en": (
            "GEMINI_API_KEY environment variable is not set.\n"
            "Get your API key at: https://aistudio.google.com/apikey\n"
            "Then set it: export GEMINI_API_KEY=your-key-here\n"
            "Or create a .env file with: GEMINI_API_KEY=your-key-here"
        ),
    },

    # ── OpenAI errors ──
    "openai_api_key_missing": {
        "ja": (
            "OPENAI_API_KEY 環境変数が設定されていません。\n"
            "API キーの取得先: https://platform.openai.com/api-keys\n"
            "設定方法: export OPENAI_API_KEY=your-key-here\n"
            "または .env ファイルに OPENAI_API_KEY=your-key-here を記載"
        ),
        "en": (
            "OPENAI_API_KEY environment variable is not set.\n"
            "Get your API key at: https://platform.openai.com/api-keys\n"
            "Then set it: export OPENAI_API_KEY=your-key-here\n"
            "Or create a .env file with: OPENAI_API_KEY=your-key-here"
        ),
    },

    # ── Anthropic errors ──
    "anthropic_api_key_missing": {
        "ja": (
            "ANTHROPIC_API_KEY 環境変数が設定されていません。\n"
            "API キーの取得先: https://console.anthropic.com/settings/keys\n"
            "設定方法: export ANTHROPIC_API_KEY=your-key-here\n"
            "または .env ファイルに ANTHROPIC_API_KEY=your-key-here を記載"
        ),
        "en": (
            "ANTHROPIC_API_KEY environment variable is not set.\n"
            "Get your API key at: https://console.anthropic.com/settings/keys\n"
            "Then set it: export ANTHROPIC_API_KEY=your-key-here\n"
            "Or create a .env file with: ANTHROPIC_API_KEY=your-key-here"
        ),
    },

    # ── xAI errors ──
    "xai_api_key_missing": {
        "ja": (
            "XAI_API_KEY 環境変数が設定されていません。\n"
            "API キーの取得先: https://console.x.ai/\n"
            "設定方法: export XAI_API_KEY=your-key-here\n"
            "または .env ファイルに XAI_API_KEY=your-key-here を記載"
        ),
        "en": (
            "XAI_API_KEY environment variable is not set.\n"
            "Get your API key at: https://console.x.ai/\n"
            "Then set it: export XAI_API_KEY=your-key-here\n"
            "Or create a .env file with: XAI_API_KEY=your-key-here"
        ),
    },

    # ── Ollama errors ──
    "ollama_empty_response": {
        "ja": "Ollama が空のレスポンスを返しました。",
        "en": "Ollama returned an empty response.",
    },
    "ollama_connect_error": {
        "ja": (
            "Ollama ({url}) に接続できません。\n"
            "Ollama を起動してください: ollama serve\n"
            "別のアドレスを使用する場合は OLLAMA_BASE_URL を設定してください。"
        ),
        "en": (
            "Cannot connect to Ollama at {url}.\n"
            "Make sure Ollama is running: ollama serve\n"
            "Or set OLLAMA_BASE_URL if using a different address."
        ),
    },
    "ollama_generating": {
        "ja": "生成中... {tokens} tokens ({elapsed:.0f}秒)",
        "en": "Generating... {tokens} tokens ({elapsed:.0f}s)",
    },
    "ollama_generation_done": {
        "ja": "生成完了: {tokens} tokens ({elapsed:.0f}秒)",
        "en": "Generation complete: {tokens} tokens ({elapsed:.0f}s)",
    },

    # ── Gemini messages ──
    "gemini_server_processing": {
        "ja": "Gemini サーバー処理中... ({elapsed:.0f}秒)",
        "en": "Gemini server processing... ({elapsed:.0f}s)",
    },

    # ── Extraction mode labels ──
    "mode_label_cold_open": {
        "ja": "コールドオープン",
        "en": "Cold Open",
    },
    "mode_label_cold_open_plural": {
        "ja": "コールドオープン候補",
        "en": "Cold Open Candidates",
    },
    "mode_label_clip": {
        "ja": "クリップ",
        "en": "Clip",
    },
    "mode_label_clip_plural": {
        "ja": "クリップ候補",
        "en": "Clip Candidates",
    },
}


def set_language(lang: str) -> None:
    """Set the active UI language ('ja' or 'en').

    Unsupported languages fall back to 'ja' with a warning on stderr.
    """
    global _lang
    if lang not in SUPPORTED_LANGUAGES:
        import sys

        print(
            f"Warning: Unsupported language '{lang}'. "
            f"Supported: {', '.join(SUPPORTED_LANGUAGES)}. Defaulting to 'ja'.",
            file=sys.stderr,
        )
        lang = "ja"
    _lang = lang


def get_language() -> str:
    """Return the current UI language."""
    return _lang


def t_hook(hook_type: str) -> str:
    """Translate a hook_type classification label for display."""
    if _lang == "ja":
        return _HOOK_TYPE_JA.get(hook_type, hook_type)
    return hook_type


def t_context(context_needed: str) -> str:
    """Translate a context_needed value for display."""
    if _lang == "ja":
        return _CONTEXT_NEEDED_JA.get(context_needed, context_needed)
    return context_needed


def t(key: str, **kwargs: Any) -> str:
    """Get a translated string by key, with optional format arguments.

    Falls back to the key itself if not found.
    """
    entry = _MESSAGES.get(key)
    if entry is None:
        return key
    text = entry.get(_lang, entry.get("ja", key))
    if kwargs:
        try:
            text = text.format(**kwargs)
        except (KeyError, ValueError, IndexError):
            pass
    return text
