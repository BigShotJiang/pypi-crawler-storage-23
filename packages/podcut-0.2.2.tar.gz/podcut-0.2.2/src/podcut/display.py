"""Rich display utilities for terminal output."""

from __future__ import annotations

import json

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from podcut.extraction_mode import COLD_OPEN_MODE, ExtractionMode
from podcut.i18n import t, t_context, t_hook
from podcut.models import ColdOpenCandidate, ExtractedSegment, RefinedTimestamp

console = Console()


def format_time(seconds: float) -> str:
    """Format seconds as MM:SS."""
    m = int(seconds // 60)
    s = seconds % 60
    return f"{m:02d}:{s:05.2f}"


def display_results(
    segments: list[ExtractedSegment],
    mode: ExtractionMode = COLD_OPEN_MODE,
) -> None:
    """Display extraction results as a rich table."""
    if not segments:
        console.print(f"[yellow]{t('no_candidates_found', label=mode.ui_label.lower())}[/yellow]")
        return

    table = Table(title=mode.ui_label_plural, show_lines=True)

    table.add_column(t("col_number"), style="bold cyan", width=3)
    table.add_column(t("col_time"), style="green", width=15)
    table.add_column(t("col_duration"), width=8)
    table.add_column(t("col_hook"), style="magenta", width=10)
    table.add_column(t("col_score"), style="yellow", width=5)
    table.add_column(t("col_self_contained"), width=4)
    table.add_column(t("col_cut"), width=10)
    table.add_column(t("col_file"), style="dim", width=30)

    for seg in segments:
        time_range = f"{format_time(seg.start_time)} - {format_time(seg.end_time)}"
        duration = f"{seg.duration_seconds:.1f}s"
        score = f"{seg.engagement_score}/10"
        sc_score = str(seg.self_contained_score) if seg.self_contained_score > 0 else "-"
        cut_label = t("cut_clean") if seg.cut_quality == "clean" else t("cut_word")

        table.add_row(
            str(seg.rank),
            time_range,
            duration,
            t_hook(seg.hook_type),
            score,
            sc_score,
            cut_label,
            seg.file_path.name,
        )

    console.print()
    console.print(table)

    # Detail panels for each candidate
    for seg in segments:
        excerpt = seg.transcript_excerpt
        if len(excerpt) > 200:
            excerpt = excerpt[:200] + "..."

        detail = Text()
        if hasattr(seg, "suggested_title") and seg.suggested_title:
            detail.append(t("label_suggested_title"), style="bold")
            detail.append(f"{seg.suggested_title}\n")
        detail.append(t("label_speaker"), style="bold")
        detail.append(f"{seg.speaker}\n")
        detail.append(t("label_reasoning"), style="bold")
        detail.append(f"{seg.reasoning}\n")
        if hasattr(seg, "completion_hook") and seg.completion_hook:
            detail.append(t("label_completion_hook"), style="bold")
            detail.append(f"{seg.completion_hook}\n")
        if seg.self_contained_score > 0:
            detail.append(t("label_self_contained"), style="bold")
            detail.append(f"{seg.self_contained_score}/10\n")
        if seg.narrative_completeness > 0:
            detail.append(t("label_narrative"), style="bold")
            detail.append(f"{seg.narrative_completeness}/10\n")
        if hasattr(seg, "hook_first_3sec_score") and seg.hook_first_3sec_score > 0:
            detail.append(t("label_hook_3sec"), style="bold")
            detail.append(f"{seg.hook_first_3sec_score}/10\n")
        if seg.context_needed:
            detail.append(t("label_context_needed"), style="bold")
            detail.append(f"{t_context(seg.context_needed)}\n")
        detail.append(t("label_excerpt"), style="bold")
        detail.append(f'"{excerpt}"', style="italic")

        console.print(
            Panel(
                detail,
                title=f"[bold]{t('panel_candidate', rank=seg.rank)}[/bold] - {t_hook(seg.hook_type)}",
                border_style="blue",
            )
        )

    console.print()
    console.print(f"[bold green]{t('output_saved_to', path=segments[0].file_path.parent)}[/bold green]")


def display_candidates_preview(
    candidates: list[ColdOpenCandidate],
    refined: list[RefinedTimestamp],
    mode: ExtractionMode = COLD_OPEN_MODE,
) -> None:
    """Display candidate preview table before export (no file paths).

    Shows candidates with timing info, hook type, score, and multi-segment markers.
    """
    if not candidates:
        console.print(f"[yellow]{t('no_candidates_found', label=mode.ui_label.lower())}[/yellow]")
        return

    table = Table(title=f"{mode.ui_label_plural}{t('preview_suffix')}", show_lines=True)

    table.add_column(t("col_number"), style="bold cyan", width=4)
    table.add_column(t("col_time"), style="green", width=20)
    table.add_column(t("col_duration"), width=8)
    table.add_column(t("col_hook"), style="magenta", width=10)
    table.add_column(t("col_score"), style="yellow", width=5)
    table.add_column(t("col_self_contained"), width=4)
    table.add_column(t("col_cut"), width=10)

    for candidate, ts in zip(candidates, refined):
        rank_str = str(candidate.rank)

        if candidate.is_multi_segment and candidate.segments:
            rank_str += "\u2605"  # star marker
            time_parts = []
            for seg in candidate.segments:
                time_parts.append(
                    f"{format_time(seg.start_time)}-{format_time(seg.end_time)}"
                )
            time_range = t("multi_parts", count=len(candidate.segments))
        else:
            time_range = f"{format_time(ts.refined_start_sec)} - {format_time(ts.refined_end_sec)}"

        duration = f"{ts.duration_seconds:.1f}s"
        score = f"{candidate.engagement_score}/10"
        sc_score = str(candidate.self_contained_score) if candidate.self_contained_score > 0 else "-"
        cut_label = t("cut_clean") if ts.cut_quality == "clean" else t("cut_word")

        table.add_row(
            rank_str,
            time_range,
            duration,
            t_hook(candidate.hook_type),
            score,
            sc_score,
            cut_label,
        )

    console.print()
    console.print(table)

    # Detail panels for each candidate
    for candidate, ts in zip(candidates, refined):
        excerpt = candidate.transcript_excerpt
        if len(excerpt) > 200:
            excerpt = excerpt[:200] + "..."

        detail = Text()
        if candidate.suggested_title:
            detail.append(t("label_suggested_title"), style="bold")
            detail.append(f"{candidate.suggested_title}\n")
        detail.append(t("label_speaker"), style="bold")
        detail.append(f"{candidate.speaker}\n")
        detail.append(t("label_reasoning"), style="bold")
        detail.append(f"{candidate.reasoning}\n")
        if candidate.completion_hook:
            detail.append(t("label_completion_hook"), style="bold")
            detail.append(f"{candidate.completion_hook}\n")
        if candidate.self_contained_score > 0:
            detail.append(t("label_self_contained"), style="bold")
            detail.append(f"{candidate.self_contained_score}/10\n")
        if candidate.narrative_completeness > 0:
            detail.append(t("label_narrative"), style="bold")
            detail.append(f"{candidate.narrative_completeness}/10\n")
        if candidate.hook_first_3sec_score > 0:
            detail.append(t("label_hook_3sec"), style="bold")
            detail.append(f"{candidate.hook_first_3sec_score}/10\n")
        if candidate.context_needed:
            detail.append(t("label_context_needed"), style="bold")
            detail.append(f"{t_context(candidate.context_needed)}\n")

        if candidate.is_multi_segment and candidate.segments:
            detail.append(t("label_segments"), style="bold")
            for i, seg in enumerate(candidate.segments, 1):
                seg_excerpt = seg.transcript_excerpt
                if len(seg_excerpt) > 80:
                    seg_excerpt = seg_excerpt[:80] + "..."
                detail.append(
                    t("label_part", i=i, time=f"{format_time(seg.start_time)}-{format_time(seg.end_time)}")
                )
                detail.append(f'"{seg_excerpt}"\n', style="italic")
        else:
            detail.append(t("label_excerpt"), style="bold")
            detail.append(f'"{excerpt}"', style="italic")

        title_suffix = t("multi_segment_tag") if candidate.is_multi_segment else ""
        console.print(
            Panel(
                detail,
                title=f"[bold]{t('panel_candidate', rank=candidate.rank)}[/bold] - {t_hook(candidate.hook_type)}{title_suffix}",
                border_style="blue",
            )
        )

    console.print()


def prompt_user_selection(
    candidates: list[ColdOpenCandidate],
) -> tuple[list[int], str | None]:
    """Prompt user to select candidates or provide feedback.

    Returns:
        Tuple of (selected_indices, feedback).
        - If user selects candidates: (list of 0-based indices, None)
        - If user provides feedback: ([], feedback_string)
        - If user selects all: (list of all indices, None)
    """
    console.print(t("selection_prompt"))

    try:
        user_input = input("> ").strip()
    except (KeyboardInterrupt, EOFError):
        console.print()
        return [], None

    if not user_input:
        # Empty input → export all
        return list(range(len(candidates))), None

    if user_input.lower() == "all":
        return list(range(len(candidates))), None

    # Try to parse as comma-separated numbers
    try:
        numbers = [int(n.strip()) for n in user_input.split(",")]
        # Validate all numbers are in range, deduplicate preserving order
        seen = set()
        valid_indices = []
        for num in numbers:
            if 1 <= num <= len(candidates):
                idx = num - 1  # Convert to 0-based
                if idx in seen:
                    console.print(f"[yellow]{t('warn_duplicate', num=num)}[/yellow]")
                else:
                    seen.add(idx)
                    valid_indices.append(idx)
            else:
                console.print(f"[yellow]{t('warn_out_of_range', num=num, max=len(candidates))}[/yellow]")
        if valid_indices:
            return valid_indices, None
        # All numbers were out of range → treat as feedback
        return [], user_input
    except ValueError:
        # Not numbers → treat as feedback
        return [], user_input


def display_results_json(segments: list[ExtractedSegment]) -> None:
    """Display results as JSON to stdout."""
    data = []
    for seg in segments:
        entry: dict = {
            "rank": seg.rank,
            "file_path": str(seg.file_path),
            "start_time": seg.start_time,
            "end_time": seg.end_time,
            "duration_seconds": seg.duration_seconds,
            "hook_type": seg.hook_type,
            "speaker": seg.speaker,
            "transcript_excerpt": seg.transcript_excerpt,
            "reasoning": seg.reasoning,
            "engagement_score": seg.engagement_score,
            "cut_quality": seg.cut_quality,
            "self_contained_score": seg.self_contained_score,
            "narrative_completeness": seg.narrative_completeness,
            "context_needed": seg.context_needed,
            "hook_first_3sec_score": seg.hook_first_3sec_score,
            "suggested_title": seg.suggested_title,
            "completion_hook": seg.completion_hook,
        }
        data.append(entry)

    # Print JSON to stdout (not stderr) for piping
    print(json.dumps(data, indent=2, ensure_ascii=False))
