"""Gemini prompt templates for cold open analysis."""

from __future__ import annotations

import json

from podcut.extraction_mode import COLD_OPEN_MODE, ExtractionMode
from podcut.i18n import get_language


def _build_language_instruction() -> str:
    """Build language instruction for LLM output fields."""
    if get_language() == "ja":
        return (
            '\nLANGUAGE REQUIREMENT:\n'
            '- Write "reasoning", "suggested_title", "completion_hook" in Japanese (日本語で記述)\n'
            '- Write "speaker" in Japanese when the speaker name is Japanese\n'
            '- "hook_type" must remain in English as specified above\n'
            '- "context_needed" must remain in English: "none", "minimal", or "significant"\n'
        )
    return ""


def _build_quality_criteria_section(mode: ExtractionMode) -> str:
    """Build the quality criteria section from mode configuration."""
    if not mode.quality_criteria:
        return ""
    lines = [f"### Quality Criteria for {mode.label} (IMPORTANT):", ""]
    for i, criterion in enumerate(mode.quality_criteria, 1):
        lines.append(f"{i}. {criterion}")
    return "\n".join(lines)


def _build_few_shot_section(mode: ExtractionMode) -> str:
    """Build few-shot golden samples to anchor LLM scoring calibration."""
    if mode.name == "cold_open":
        return """\

## Scoring Calibration Examples (IMPORTANT - use these to calibrate your scores)

### Example A: EXCELLENT cold open (engagement: 9, hook_first_3sec_score: 10, opening_impact: 9)
```
"transcript_excerpt": "えーっ！マジで言ってる！？それ完全にアウトでしょ！...（笑いが続く）",
"reasoning": "Strong emotional reaction in the first second creates immediate curiosity. The exclamation and laughter are attention-grabbing hooks.",
"suggested_title": "完全にアウト！？思わず叫んだ衝撃発言",
"completion_hook": "The escalating reactions build to a punchline that reframes the entire exchange"
```

### Example B: GOOD cold open (engagement: 7, hook_first_3sec_score: 7, opening_impact: 7)
```
"transcript_excerpt": "実はこれ、誰も知らないと思うんですけど...",
"reasoning": "Creates a curiosity gap with 'nobody knows this' framing. Decent hook but lacks immediate vocal energy.",
"suggested_title": "誰も知らない秘密を初告白",
"completion_hook": "The secret being revealed is genuinely surprising and changes how you see the topic"
```

### Example C: POOR cold open (engagement: 4, hook_first_3sec_score: 2, opening_impact: 3)
```
"transcript_excerpt": "えーと、まあそうですね、この話題なんですけど...",
"reasoning": "Weak filler words at the start. No immediate hook or emotional trigger.",
"suggested_title": "この話題について",
"completion_hook": "Hard to articulate why someone would stay - the content meanders"
```

Use these examples to calibrate: if a candidate is similar to Example C, do NOT give it high scores.
"""
    elif mode.name == "clip":
        return """\

## Scoring Calibration Examples (IMPORTANT - use these to calibrate your scores)

### Example A: EXCELLENT clip (engagement: 9, narrative_completeness: 9, shareability: 9)
```
"reasoning": "Complete story arc: setup → escalating tension → unexpected resolution. Self-contained and shareable.",
"suggested_title": "人生を変えた一言 - ゲストが涙した瞬間",
"completion_hook": "The emotional payoff at the end ties together everything discussed in the segment"
```

### Example B: GOOD clip (engagement: 7, narrative_completeness: 7, shareability: 7)
```
"reasoning": "Clear topic with useful advice. Good standalone content but lacks a strong emotional peak.",
"suggested_title": "プロが教える意外なコツ",
"completion_hook": "The practical tip at the end is immediately actionable"
```

### Example C: POOR clip (engagement: 4, narrative_completeness: 3, shareability: 3)
```
"reasoning": "Topic starts mid-discussion, references earlier context, and ends without clear resolution.",
"suggested_title": "この話の続き...",
"completion_hook": "Difficult to justify - the clip feels incomplete"
```

Use these examples to calibrate: if a candidate is similar to Example C, do NOT give it high scores.
"""
    return ""


def _build_avoid_patterns_section(mode: ExtractionMode) -> str:
    """Build explicit avoid-patterns section from mode configuration."""
    if not mode.avoid_start_patterns:
        return ""
    examples = ", ".join(f'"{p}"' for p in mode.avoid_start_patterns[:15])
    return (
        f"\n### AVOID These Openings (IMPORTANT - penalize candidates starting with these):\n"
        f"Segments that begin with greetings, preambles, filler words, context-dependent phrases, "
        f"or slow warm-ups are POOR candidates. These kill viewer retention in the first 3 seconds.\n"
        f"Examples: {examples}\n"
        f"If a candidate starts with any of these patterns, set hook_first_3sec_score to 3 or below "
        f"and lower engagement_score by at least 2 points."
    )


def _build_what_makes_great_section(mode: ExtractionMode) -> str:
    """Build mode-specific 'What Makes a Great ...' guidance."""
    if mode.name == "cold_open":
        return (
            f"A great {mode.label.lower()} should:\n"
            f"1. **First 3 seconds are EVERYTHING** - the opening must create a pattern interrupt, curiosity gap, "
            f"or emotional trigger that stops the scroll. 85% of viewers decide to stay within 3 seconds.\n"
            f"2. **Create a cliffhanger** - end at a moment that demands resolution\n"
            f"3. **Prefer moments with vocal energy** - laughter, surprise, animated debate, exclamations\n"
            f"4. **Tension curve** - the segment should build or maintain energy throughout, with no 'dead zones'\n"
            f"5. **Be {mode.min_duration_sec}-{mode.max_duration_sec} seconds long** - short enough to tease, long enough to engage\n"
            f"6. **For Japanese content**: reactions like えーっ！, マジで！？, ウソでしょ！ are strong hooks. "
            f"Tsukkomi (ツッコミ) timing, comedic rhythm, and 本音 (honest confessions) create great openings.\n"
            f"\nAvoid: dry explanations, introductions/greetings, ads, slow buildups, "
            f"context-dependent phrases (さっきの続き, 前回の, ということで)"
        )
    elif mode.name == "clip":
        return (
            f"A great {mode.label.lower()} should:\n"
            f"1. **Must tell a complete story** - beginning, middle, and end with a clear payoff\n"
            f"2. **Should work as standalone content** - a listener encountering this clip alone should understand it\n"
            f"3. **Tension curve** - maintain rising or sustained energy. The ideal pattern is: "
            f"hook → build → peak → resolution. Avoid segments with 'dead zones' in the middle.\n"
            f"4. **Be {mode.min_duration_sec}-{mode.max_duration_sec} seconds long** - complete enough to satisfy, concise enough to share\n"
            f"5. **Completion-rate optimized** - prioritize segments listeners will finish. "
            f"The opening must hook, and the ending must deliver a payoff (punchline, conclusion, insight).\n"
            f"6. **For Japanese content**: complete tsukkomi/boke exchanges, full anecdotes with オチ (punchlines). "
            f"本音トーク (honest talk) and 気づきの瞬間 (moments of realization) are highly shareable.\n"
            f'\nAvoid: clips that start with "and so...", "as I was saying...", "ということで", '
            f'"さっきの続き", or end mid-argument without resolution'
        )
    else:
        return (
            f"A great {mode.label.lower()} should:\n"
            f"1. **Hook the listener immediately** - make them want to keep listening\n"
            f"2. **Be self-contained** - understandable without prior context\n"
            f"3. **Have emotional impact** - surprise, humor, curiosity, tension, or insight\n"
            f"4. **Be {mode.min_duration_sec}-{mode.max_duration_sec} seconds long** - short enough to tease, long enough to engage"
        )


def _build_extra_score_fields_json(mode: ExtractionMode) -> str:
    """Build JSON fields for mode-specific extra scores."""
    lines = []
    if "opening_impact_score" in mode.extra_score_fields:
        lines.append('      "opening_impact_score": 8')
    if "hook_first_3sec_score" in mode.extra_score_fields:
        lines.append('      "hook_first_3sec_score": 9')
    if "shareability_score" in mode.extra_score_fields:
        lines.append('      "shareability_score": 7')
    # Always include new fields
    lines.append('      "suggested_title": "A catchy social media title for this segment"')
    lines.append('      "completion_hook": "Why a viewer would watch this to the end"')
    if not lines:
        return ""
    return ",\n" + ",\n".join(lines)


def _build_extra_score_rules(mode: ExtractionMode) -> str:
    """Build CRITICAL RULES entries for mode-specific extra scores."""
    rules = []
    if "opening_impact_score" in mode.extra_score_fields:
        rules.append(
            "- opening_impact_score: Rate 1-10 how strongly the FIRST 2-3 SECONDS grab the listener's attention. "
            "This is THE most important score for cold opens."
        )
    if "hook_first_3sec_score" in mode.extra_score_fields:
        rules.append(
            "- hook_first_3sec_score: Rate 1-10 the FIRST 3 SECONDS ONLY. Does the very first sentence create "
            "a pattern interrupt, curiosity gap, or emotional trigger? "
            "Score 9-10: starts with an exclamation, provocative question, or shocking statement. "
            "Score 5-6: starts with a normal sentence. Score 1-3: starts with filler words or greetings."
        )
    if "shareability_score" in mode.extra_score_fields:
        rules.append(
            "- shareability_score: Rate 1-10 how well this clip works as standalone shareable content. "
            "Can you write a catchy title for it? Would it make sense posted on social media?"
        )
    # Always include new field rules
    rules.append(
        '- suggested_title: Write a catchy, scroll-stopping social media title for this segment. '
        'If you cannot write a compelling title, this candidate is probably weak.'
    )
    rules.append(
        '- completion_hook: In one sentence, explain WHY a viewer would watch this segment to the very end. '
        'What payoff awaits them? (e.g., "The surprising twist at the end reverses everything said before")'
    )
    return "\n".join(rules)


def _build_hook_types_section(mode: ExtractionMode) -> str:
    """Build the hook types section from mode configuration."""
    lines = []
    for ht in mode.hook_types:
        desc = mode.hook_type_descriptions.get(ht, ht)
        lines.append(f"- **{ht}**: {desc}")
    return "\n".join(lines)


def _build_multi_segment_section(mode: ExtractionMode) -> str:
    """Build the multi-segment section (only for modes that allow it)."""
    if not mode.allow_multi_segment:
        return ""

    return f"""
## Multi-Segment {mode.label}s

You may also create a {mode.label.lower()} by combining 2-3 short segments from DIFFERENT parts of the
episode into one compelling teaser. This works well when:
- A single continuous segment is too short to stand alone
- Combining contrasting moments (e.g., a question + a surprising answer from later) creates a stronger hook
- A debate or discussion has great moments scattered across the episode

For multi-segment candidates, set "is_multi_segment": true and provide the "segments" array.
The "start_time" and "end_time" of a multi-segment candidate should cover the first segment's start
to the last segment's end (for reference only). Each segment in the "segments" array should be
{mode.min_duration_sec // 3}-{mode.max_duration_sec // 2} seconds long.
"""


def _build_multi_segment_example(mode: ExtractionMode) -> str:
    """Build the multi-segment JSON example (only for modes that allow it)."""
    if not mode.allow_multi_segment:
        return ""

    extra_fields = _build_extra_score_fields_json(mode)

    return f"""\
,
    {{
      "rank": 2,
      "start_time": 45.0,
      "end_time": 600.0,
      "speaker": "Host and Guest",
      "hook_type": "debate",
      "transcript_excerpt": "Combined excerpts from multiple parts...",
      "reasoning": "These contrasting moments create tension...",
      "engagement_score": 8,
      "self_contained_score": 7,
      "narrative_completeness": 6,
      "context_needed": "minimal"{extra_fields},
      "is_multi_segment": true,
      "segments": [
        {{
          "start_time": 45.0,
          "end_time": 58.0,
          "transcript_excerpt": "First part text..."
        }},
        {{
          "start_time": 580.0,
          "end_time": 600.0,
          "transcript_excerpt": "Second part text..."
        }}
      ]
    }}"""


def _candidate_multi_segment_fields(mode: ExtractionMode) -> str:
    """Return JSON fields for is_multi_segment/segments when mode supports it."""
    if not mode.allow_multi_segment:
        return ""
    return ',\n      "is_multi_segment": false,\n      "segments": []'


def _build_multi_segment_rules(mode: ExtractionMode) -> str:
    """Build multi-segment-specific rules."""
    if not mode.allow_multi_segment:
        return ""

    return f"""\
- For multi-segment candidates: total combined duration should be {mode.min_duration_sec}-{mode.max_duration_sec} seconds
- is_multi_segment defaults to false, segments defaults to empty array
- Include at most 1 multi-segment candidate unless the content strongly warrants more"""


def build_analysis_prompt(
    transcript_text: str,
    num_candidates: int,
    mode: ExtractionMode = COLD_OPEN_MODE,
    has_audio: bool = True,
) -> str:
    """Build the LLM prompt for candidate analysis.

    Args:
        transcript_text: Formatted transcript with timestamps.
        num_candidates: Number of candidates to generate.
        mode: Extraction mode defining analysis parameters.
        has_audio: Whether the LLM also receives the audio file (Gemini=True, Ollama=False).
    """
    hook_types_section = _build_hook_types_section(mode)
    multi_segment_section = _build_multi_segment_section(mode)
    multi_segment_example = _build_multi_segment_example(mode)
    multi_segment_rules = _build_multi_segment_rules(mode)
    quality_criteria_section = _build_quality_criteria_section(mode)
    what_makes_great = _build_what_makes_great_section(mode)
    avoid_patterns_section = _build_avoid_patterns_section(mode)
    extra_score_json = _build_extra_score_fields_json(mode)
    extra_score_rules = _build_extra_score_rules(mode)
    few_shot_section = _build_few_shot_section(mode)

    if has_audio:
        audio_context = (
            "You have been given the podcast audio file for listening context.\n"
            "Below is the accurate transcript with word-level timestamps produced by Whisper."
        )
        step1 = "1. Listen to the audio and read the transcript carefully"
    else:
        audio_context = (
            "Below is the transcript of the podcast episode with word-level timestamps produced by Whisper."
        )
        step1 = "1. Read the transcript carefully"

    return f"""\
You are a podcast editor AI specializing in creating viral-worthy clips. Your task is to identify
the best "{mode.label.lower()}" segments from a podcast episode. {mode.description}

Your goal: find segments that would make viewers STOP SCROLLING on social media and watch to the end.

## Transcript

{audio_context}
IMPORTANT: Use ONLY the timestamps from this transcript. Do NOT estimate your own timestamps.

<transcript>
{transcript_text}
</transcript>

## What Makes a Great {mode.label}

{what_makes_great}

{quality_criteria_section}
{avoid_patterns_section}

### Hook Types (pick the most fitting one):
{hook_types_section}
{few_shot_section}
## Instructions

{step1}
2. For each potential segment, evaluate the FIRST 3 SECONDS - does it create an immediate hook?
3. Identify the {num_candidates} best {mode.label.lower()} candidates
4. For each candidate, write a suggested_title - if you can't write a compelling title, reconsider the candidate
5. For each candidate, reference the EXACT timestamps from the transcript above
6. Return your analysis as JSON
{multi_segment_section}
## Output Format

Return ONLY valid JSON (no markdown, no code fences) in this exact structure:

{{
  "candidates": [
    {{
      "rank": 1,
      "start_time": 123.45,
      "end_time": 156.78,
      "speaker": "Speaker name or description",
      "hook_type": "question",
      "transcript_excerpt": "The exact text from the transcript for this segment...",
      "reasoning": "Why this makes a great {mode.label.lower()}...",
      "engagement_score": 9,
      "self_contained_score": 8,
      "narrative_completeness": 7,
      "context_needed": "none"{extra_score_json}{_candidate_multi_segment_fields(mode)}
    }}{multi_segment_example}
  ]
}}

CRITICAL RULES:
- self_contained_score: Rate 1-10 how well this segment works WITHOUT any prior context
- narrative_completeness: Rate 1-10 how cleanly this starts and ends as a standalone piece
- context_needed: "none" (fully standalone), "minimal" (brief intro needed), or "significant" (requires episode context)
{extra_score_rules}
- NEVER invent or estimate timestamps. Only use values from the transcript above.
- Prefer segments starting AFTER a speaker pause or topic shift, not mid-sentence.
- start_time and end_time MUST be values from the transcript timestamps
- transcript_excerpt MUST be verbatim text from the transcript
- engagement_score is 1-10 (10 = most engaging)
- For single-segment candidates: duration should be {mode.min_duration_sec}-{mode.max_duration_sec} seconds
{multi_segment_rules}
- Rank 1 = best candidate
- Return exactly {num_candidates} candidates
{_build_language_instruction()}"""


MAX_FEEDBACK_LENGTH = 1000


def _sanitize_feedback(feedback: str) -> str:
    """Sanitize user feedback before embedding in an LLM prompt.

    - Truncates to MAX_FEEDBACK_LENGTH characters
    - Strips XML-like closing tags that could break prompt structure
    """
    text = feedback[:MAX_FEEDBACK_LENGTH]
    # Remove any closing tags that could escape the <feedback> block
    text = text.replace("</feedback>", "").replace("</transcript>", "")
    return text.strip()


def build_feedback_prompt(
    transcript_text: str,
    num_candidates: int,
    previous_candidates: list[dict],
    feedback: str,
    mode: ExtractionMode = COLD_OPEN_MODE,
    has_audio: bool = True,
) -> str:
    """Build an LLM prompt for re-analysis based on user feedback.

    Args:
        transcript_text: Formatted transcript with timestamps.
        num_candidates: Number of candidates to generate.
        previous_candidates: Previous candidates as dicts (serialized).
        feedback: User feedback text (may be in Japanese or any language).
        mode: Extraction mode defining analysis parameters.
        has_audio: Whether the LLM also receives the audio file (Gemini=True, Ollama=False).
    """
    feedback = _sanitize_feedback(feedback)
    previous_json = json.dumps(previous_candidates, indent=2, ensure_ascii=False)
    hook_types_section = _build_hook_types_section(mode)
    quality_criteria_section = _build_quality_criteria_section(mode)
    what_makes_great = _build_what_makes_great_section(mode)
    avoid_patterns_section = _build_avoid_patterns_section(mode)
    extra_score_json = _build_extra_score_fields_json(mode)
    extra_score_rules = _build_extra_score_rules(mode)

    if has_audio:
        audio_context = (
            "You have been given the podcast audio file for listening context.\n"
            "Below is the accurate transcript with word-level timestamps produced by Whisper."
        )
    else:
        audio_context = (
            "Below is the transcript of the podcast episode with word-level timestamps produced by Whisper."
        )

    multi_segment_note = ""
    if mode.allow_multi_segment:
        multi_segment_note = f"""
## Multi-Segment {mode.label}s

You may combine 2-3 short segments from DIFFERENT parts of the episode into one {mode.label.lower()}.
For multi-segment candidates, set "is_multi_segment": true and provide the "segments" array.
"""

    return f"""\
You are a podcast editor AI specializing in creating viral-worthy clips. You previously analyzed a podcast
episode and suggested {mode.label.lower()} candidates, but the user was not satisfied.
Re-analyze the episode considering their feedback.

## Transcript

{audio_context}
IMPORTANT: Use ONLY the timestamps from this transcript. Do NOT estimate your own timestamps.

<transcript>
{transcript_text}
</transcript>

## Previous Candidates (User was NOT satisfied with these)

{previous_json}

## User Feedback

The user provided this feedback (may be in any language including Japanese):

<feedback>
{feedback}
</feedback>

## Instructions

1. Carefully consider the user's feedback
2. Propose {num_candidates} NEW and DIFFERENT candidates that address the feedback
3. Do NOT repeat the same candidates as before unless the feedback specifically requests refinement of one
4. Use EXACT timestamps from the transcript above

## What Makes a Great {mode.label}

{what_makes_great}

{quality_criteria_section}
{avoid_patterns_section}

### Hook Types:
{hook_types_section}
{multi_segment_note}
## Output Format

Return ONLY valid JSON (no markdown, no code fences) in this exact structure:

{{
  "candidates": [
    {{
      "rank": 1,
      "start_time": 123.45,
      "end_time": 156.78,
      "speaker": "Speaker name or description",
      "hook_type": "question",
      "transcript_excerpt": "The exact text from the transcript for this segment...",
      "reasoning": "Why this makes a great {mode.label.lower()}, addressing the user's feedback...",
      "engagement_score": 9,
      "self_contained_score": 8,
      "narrative_completeness": 7,
      "context_needed": "none"{extra_score_json}{_candidate_multi_segment_fields(mode)}
    }}
  ]
}}

CRITICAL RULES:
- self_contained_score: Rate 1-10 how well this segment works WITHOUT any prior context
- narrative_completeness: Rate 1-10 how cleanly this starts and ends as a standalone piece
- context_needed: "none" (fully standalone), "minimal" (brief intro needed), or "significant" (requires episode context)
{extra_score_rules}
- NEVER invent or estimate timestamps. Only use values from the transcript above.
- Prefer segments starting AFTER a speaker pause or topic shift, not mid-sentence.
- start_time and end_time MUST be values from the transcript timestamps
- transcript_excerpt MUST be verbatim text from the transcript
- engagement_score is 1-10 (10 = most engaging)
- Duration should be {mode.min_duration_sec}-{mode.max_duration_sec} seconds (single or combined)
- Rank 1 = best candidate
- Return exactly {num_candidates} candidates
{_build_language_instruction()}"""
