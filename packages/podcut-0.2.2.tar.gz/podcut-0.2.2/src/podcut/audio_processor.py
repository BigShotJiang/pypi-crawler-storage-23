"""Audio extraction and processing using PyDub."""

from pathlib import Path

from pydub import AudioSegment

from podcut.config import FADE_IN_MS, FADE_OUT_MS, PADDING_MS
from podcut.models import RefinedTimestamp, RefinedTimestampPart


def check_ffmpeg() -> None:
    """Check if FFmpeg is available by running ffmpeg -version."""
    import shutil

    if shutil.which("ffmpeg") is None:
        raise SystemExit(
            "FFmpeg is required but not found.\n"
            "Install it with: brew install ffmpeg"
        )


def load_audio(audio_path: Path) -> AudioSegment:
    """Load audio file into PyDub AudioSegment."""
    suffix = audio_path.suffix.lower()
    format_map = {
        ".mp3": "mp3",
        ".wav": "wav",
        ".m4a": "m4a",
        ".aac": "aac",
        ".ogg": "ogg",
        ".flac": "flac",
    }
    fmt = format_map.get(suffix, suffix.lstrip("."))
    return AudioSegment.from_file(str(audio_path), format=fmt)


def get_audio_duration_sec(audio: AudioSegment) -> float:
    """Get audio duration in seconds."""
    return len(audio) / 1000.0


def extract_segment(
    audio: AudioSegment,
    timestamp: RefinedTimestamp,
    output_path: Path,
    output_format: str = "mp3",
    padding_ms: int = PADDING_MS,
    fade_in_ms: int = FADE_IN_MS,
    fade_out_ms: int = FADE_OUT_MS,
) -> Path:
    """Extract a segment from audio with padding and fades.

    Args:
        audio: Full audio loaded as AudioSegment.
        timestamp: Refined timestamp with start/end.
        output_path: Where to save the extracted segment.
        output_format: Output format (mp3/wav).
        padding_ms: Padding before and after segment.
        fade_in_ms: Fade in duration.
        fade_out_ms: Fade out duration.

    Returns:
        Path to the saved segment file.
    """
    start_ms = max(0, int(timestamp.refined_start_sec * 1000) - padding_ms)
    end_ms = min(len(audio), int(timestamp.refined_end_sec * 1000) + padding_ms)

    segment = audio[start_ms:end_ms]
    segment = segment.fade_in(fade_in_ms).fade_out(fade_out_ms)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    segment.export(str(output_path), format=output_format)

    return output_path


def extract_multi_segment(
    audio: AudioSegment,
    parts: list[RefinedTimestampPart],
    output_path: Path,
    output_format: str = "mp3",
    gap_ms: int = 300,
    padding_ms: int = PADDING_MS,
    fade_in_ms: int = FADE_IN_MS,
    fade_out_ms: int = FADE_OUT_MS,
) -> Path:
    """Extract and combine multiple segments into a single audio file.

    Each part is cut from the audio, then joined with short silence gaps
    between them. Fade in/out is applied to the final combined result.

    Args:
        audio: Full audio loaded as AudioSegment.
        parts: List of refined timestamp parts to extract and combine.
        output_path: Where to save the combined segment.
        output_format: Output format (mp3/wav).
        gap_ms: Duration of silence gap between parts in milliseconds.
        padding_ms: Padding before first and after last part.
        fade_in_ms: Fade in duration for the combined result.
        fade_out_ms: Fade out duration for the combined result.

    Returns:
        Path to the saved combined segment file.
    """
    silence_gap = AudioSegment.silent(duration=gap_ms)
    combined: AudioSegment | None = None

    for part in parts:
        start_ms = max(0, int(part.refined_start_sec * 1000) - padding_ms)
        end_ms = min(len(audio), int(part.refined_end_sec * 1000) + padding_ms)
        clip = audio[start_ms:end_ms]

        if combined is None:
            combined = clip
        else:
            combined = combined + silence_gap + clip

    if combined is None:
        raise ValueError("No parts provided for multi-segment extraction.")

    combined = combined.fade_in(fade_in_ms).fade_out(fade_out_ms)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    combined.export(str(output_path), format=output_format)

    return output_path


def extract_all_segments(
    audio_path: Path,
    timestamps: list[RefinedTimestamp],
    output_dir: Path,
    output_format: str = "mp3",
    file_prefix: str = "cold_open",
) -> list[Path]:
    """Extract all candidate segments from audio.

    Args:
        audio_path: Path to source audio.
        timestamps: List of refined timestamps.
        output_dir: Output directory.
        output_format: Output format (mp3/wav).
        file_prefix: Prefix for output filenames (e.g. "cold_open", "clip").

    Returns:
        List of paths to extracted segment files.
    """
    audio = load_audio(audio_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = audio_path.stem

    paths: list[Path] = []
    for ts in timestamps:
        filename = f"{stem}_{file_prefix}_{ts.original_rank:02d}.{output_format}"
        output_path = output_dir / filename

        if ts.parts:
            extract_multi_segment(audio, ts.parts, output_path, output_format)
        else:
            extract_segment(audio, ts, output_path, output_format)

        paths.append(output_path)

    return paths
