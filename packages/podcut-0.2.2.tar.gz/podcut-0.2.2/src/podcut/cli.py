"""Typer CLI entry point for podcut."""

import signal
import sys
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from podcut.config import (
    AVAILABLE_CLAUDE_MODELS,
    AVAILABLE_GROK_MODELS,
    AVAILABLE_MODELS,
    AVAILABLE_OLLAMA_MODELS,
    AVAILABLE_OPENAI_MODELS,
    AVAILABLE_PROVIDERS,
    DEFAULT_CANDIDATES,
    DEFAULT_CLAUDE_MODEL,
    DEFAULT_FORMAT,
    DEFAULT_GROK_MODEL,
    DEFAULT_MODEL,
    DEFAULT_OLLAMA_MODEL,
    DEFAULT_OPENAI_MODEL,
    DEFAULT_PROVIDER,
    DEFAULT_WHISPER_MODEL,
)
from podcut.extraction_mode import AVAILABLE_MODES, get_mode
from podcut.i18n import set_language, t

app = typer.Typer(
    name="podcut",
    help="AI-powered podcast segment extractor. Run without arguments for interactive wizard.",
)
console = Console(stderr=True)


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    lang: Annotated[
        str | None,
        typer.Option("--lang", help="UI language: ja (Japanese) or en (English)."),
    ] = None,
) -> None:
    """AI-powered podcast segment extractor.

    Run without arguments to launch the interactive wizard.
    """
    if lang is not None:
        set_language(lang)

    if ctx.invoked_subcommand is None:
        from podcut.wizard import run_wizard

        run_wizard(lang=lang)


def _handle_interrupt(signum, frame):
    """Handle Ctrl+C gracefully."""
    console.print(f"\n[yellow]{t('cancelled_by_user')}[/yellow]")
    sys.exit(130)


@app.command()
def find(
    audio_file: Annotated[
        Path,
        typer.Argument(
            help="Input audio file (MP3/WAV).",
            exists=True,
            readable=True,
        ),
    ],
    output: Annotated[
        Path,
        typer.Option("-o", "--output", help="Output directory for extracted clips."),
    ] = Path("./output"),
    candidates: Annotated[
        int,
        typer.Option("-n", "--candidates", help="Number of candidates to find (1-10).", min=1, max=10),
    ] = DEFAULT_CANDIDATES,
    format: Annotated[
        str,
        typer.Option("-f", "--format", help="Output audio format."),
    ] = DEFAULT_FORMAT,
    model: Annotated[
        str,
        typer.Option("-m", "--model", help=f"Gemini model: {', '.join(AVAILABLE_MODELS)}"),
    ] = DEFAULT_MODEL,
    whisper_model: Annotated[
        str,
        typer.Option("--whisper-model", help="Whisper model size (tiny/base/small/medium/turbo/large-v3)."),
    ] = DEFAULT_WHISPER_MODEL,
    backend: Annotated[
        str,
        typer.Option("--backend", help="Whisper backend: auto (MLX if available), mlx, cpu."),
    ] = "auto",
    mode: Annotated[
        str,
        typer.Option("--mode", help=f"Extraction mode: {', '.join(AVAILABLE_MODES)}"),
    ] = "cold_open",
    auto: Annotated[
        bool,
        typer.Option("--auto", help="Skip interactive selection, export all candidates."),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Output results as JSON."),
    ] = False,
    provider: Annotated[
        str,
        typer.Option("--provider", help=f"LLM provider: {', '.join(AVAILABLE_PROVIDERS)}"),
    ] = DEFAULT_PROVIDER,
    ollama_model: Annotated[
        str,
        typer.Option("--ollama-model", help=f"Ollama model (when --provider=ollama): {', '.join(AVAILABLE_OLLAMA_MODELS)}"),
    ] = DEFAULT_OLLAMA_MODEL,
    openai_model: Annotated[
        str,
        typer.Option("--openai-model", help=f"OpenAI model (when --provider=openai): {', '.join(AVAILABLE_OPENAI_MODELS)}"),
    ] = DEFAULT_OPENAI_MODEL,
    claude_model: Annotated[
        str,
        typer.Option("--claude-model", help=f"Claude model (when --provider=claude): {', '.join(AVAILABLE_CLAUDE_MODELS)}"),
    ] = DEFAULT_CLAUDE_MODEL,
    grok_model: Annotated[
        str,
        typer.Option("--grok-model", help=f"Grok model (when --provider=grok): {', '.join(AVAILABLE_GROK_MODELS)}"),
    ] = DEFAULT_GROK_MODEL,
    verbose: Annotated[
        bool,
        typer.Option("-v", "--verbose", help="Enable verbose logging."),
    ] = False,
) -> None:
    """Find the best segment candidates in a podcast episode.

    Press Ctrl+C at any time to cancel.
    """
    from podcut.audio_processor import check_ffmpeg
    from podcut.display import display_results, display_results_json
    from podcut.workflow import run_pipeline_interactive

    # Register Ctrl+C handler
    signal.signal(signal.SIGINT, _handle_interrupt)

    # Validate provider
    if provider not in AVAILABLE_PROVIDERS:
        raise typer.BadParameter(f"Provider must be one of {', '.join(AVAILABLE_PROVIDERS)}. Got '{provider}'.")

    # Validate mode
    try:
        extraction_mode = get_mode(mode)
    except ValueError as e:
        raise typer.BadParameter(str(e))

    # Validate backend
    valid_backends = ("auto", "mlx", "cpu")
    if backend not in valid_backends:
        raise typer.BadParameter(f"Backend must be one of {', '.join(valid_backends)}. Got '{backend}'.")

    # Validate format
    if format not in ("mp3", "wav"):
        raise typer.BadParameter("Format must be 'mp3' or 'wav'.")

    # Validate audio file extension
    if audio_file.suffix.lower() not in (".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac"):
        raise typer.BadParameter(f"Unsupported audio format: {audio_file.suffix}")

    # Check FFmpeg
    check_ffmpeg()

    # JSON output implies auto mode (no interactive prompts)
    effective_auto = auto or json_output

    # Determine effective LLM model based on provider
    if provider == "ollama":
        effective_llm_model = ollama_model
    elif provider == "openai":
        effective_llm_model = openai_model
    elif provider == "claude":
        effective_llm_model = claude_model
    elif provider == "grok":
        effective_llm_model = grok_model
    else:
        effective_llm_model = model

    # Run the pipeline with progress
    if not json_output:
        console.print(f"[bold]{t('analyzing', name=audio_file.name)}[/bold]")
        console.print(f"[dim]{t('mode_info', label=f'{extraction_mode.label} ({extraction_mode.min_duration_sec}-{extraction_mode.max_duration_sec}s)')}[/dim]")
        console.print(f"[dim]{t('provider_info', provider=provider, model=effective_llm_model)}[/dim]")
        if effective_auto:
            console.print(f"[dim]{t('auto_mode_info')}[/dim]")
        else:
            console.print(f"[dim]{t('interactive_mode_info')}[/dim]")
        console.print(f"[dim]{t('press_ctrl_c')}[/dim]")
        console.print()

    try:
        results = run_pipeline_interactive(
            audio_path=audio_file,
            output_dir=output,
            num_candidates=candidates,
            output_format=format,
            gemini_model=model,
            whisper_model=whisper_model,
            whisper_backend=backend,
            mode=extraction_mode,
            verbose=verbose,
            auto=effective_auto,
            provider_name=provider,
            llm_model=effective_llm_model,
        )
    except KeyboardInterrupt:
        console.print(f"\n[yellow]{t('cancelled_by_user')}[/yellow]")
        raise typer.Exit(code=130)

    if json_output:
        display_results_json(results)
    else:
        display_results(results, mode=extraction_mode)


@app.command()
def config(
    reset: Annotated[
        bool,
        typer.Option("--reset", help="Reset wizard preferences (API keys in .env are kept)."),
    ] = False,
    show_path: Annotated[
        bool,
        typer.Option("--path", help="Show settings file path."),
    ] = False,
) -> None:
    """Show or manage saved settings."""
    from rich.table import Table

    from podcut.settings import get_settings_path, load_settings, reset_settings

    if show_path:
        console.print(t("config_file_location", path=str(get_settings_path())))
        return

    if reset:
        removed = reset_settings()
        if removed:
            console.print(f"[green]{t('config_reset_done')}[/green]")
        else:
            console.print(f"[yellow]{t('config_no_settings')}[/yellow]")
        return

    # Default: show saved settings
    settings = load_settings()
    if not settings:
        console.print(f"[yellow]{t('config_no_settings')}[/yellow]")
        console.print(f"[dim]{t('config_run_wizard_hint')}[/dim]")
        return

    table = Table(title=t("config_title"), border_style="cyan")
    table.add_column(t("config_col_key"), style="bold")
    table.add_column(t("config_col_value"))
    for key, value in sorted(settings.items()):
        table.add_row(key, str(value))
    console.print(table)
    console.print(f"\n[dim]{t('config_file_location', path=str(get_settings_path()))}[/dim]")


@app.command()
def cleanup(
    verbose: Annotated[
        bool,
        typer.Option("-v", "--verbose", help="Enable verbose logging."),
    ] = False,
) -> None:
    """Delete all uploaded files from Gemini Files API."""
    from podcut.gemini_client import cleanup_all_files

    deleted = cleanup_all_files(verbose=verbose)
    console.print(f"[green]{t('cli_deleted_files', count=deleted)}[/green]")


if __name__ == "__main__":
    app()
