"""Abstract LLM provider protocol for content analysis."""

from __future__ import annotations

from pathlib import Path
from typing import Protocol, runtime_checkable

from podcut.extraction_mode import COLD_OPEN_MODE, ExtractionMode
from podcut.models import ColdOpenCandidate


@runtime_checkable
class LLMProvider(Protocol):
    """Protocol defining the interface for LLM-based content analysis."""

    def upload(self, audio_path: Path, verbose: bool = False) -> None:
        """Upload an audio file for analysis.

        Args:
            audio_path: Path to the audio file.
            verbose: Whether to print progress.
        """
        ...

    def analyze(
        self,
        transcript_text: str,
        num_candidates: int,
        mode: ExtractionMode = COLD_OPEN_MODE,
        verbose: bool = False,
    ) -> list[ColdOpenCandidate]:
        """Analyze transcript to identify candidates.

        Args:
            transcript_text: Formatted transcript with timestamps.
            num_candidates: Number of candidates to identify.
            mode: Extraction mode defining analysis parameters.
            verbose: Whether to print progress.

        Returns:
            List of candidates.
        """
        ...

    def analyze_with_feedback(
        self,
        transcript_text: str,
        num_candidates: int,
        previous: list[ColdOpenCandidate],
        feedback: str,
        mode: ExtractionMode = COLD_OPEN_MODE,
        verbose: bool = False,
    ) -> list[ColdOpenCandidate]:
        """Re-analyze with user feedback.

        Args:
            transcript_text: Formatted transcript with timestamps.
            num_candidates: Number of candidates to identify.
            previous: Previous candidates the user was not satisfied with.
            feedback: User feedback text.
            mode: Extraction mode defining analysis parameters.
            verbose: Whether to print progress.

        Returns:
            List of new candidates.
        """
        ...

    def cleanup(self, verbose: bool = False) -> None:
        """Clean up any uploaded resources.

        Args:
            verbose: Whether to print progress.
        """
        ...
