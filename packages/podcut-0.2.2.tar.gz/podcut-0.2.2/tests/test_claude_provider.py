"""Tests for Anthropic Claude provider parsing and API interaction."""

import json
from unittest.mock import MagicMock, patch

import pytest

from podcut.claude_provider import ClaudeProvider, _parse_candidates


def test_parse_candidates_valid_json():
    """Test parsing valid JSON response."""
    data = {
        "candidates": [
            {
                "rank": 1,
                "start_time": 10.0,
                "end_time": 40.0,
                "speaker": "Host",
                "hook_type": "question",
                "transcript_excerpt": "test text",
                "reasoning": "test reason",
                "engagement_score": 8,
            }
        ]
    }
    candidates = _parse_candidates(json.dumps(data))
    assert len(candidates) == 1
    assert candidates[0].rank == 1
    assert candidates[0].start_time == 10.0
    assert candidates[0].hook_type == "question"


def test_parse_candidates_with_code_fences():
    """Test parsing JSON wrapped in markdown code fences."""
    data = {
        "candidates": [
            {
                "rank": 1,
                "start_time": 5.0,
                "end_time": 35.0,
                "speaker": "Guest",
                "hook_type": "humor",
                "transcript_excerpt": "funny bit",
                "reasoning": "it's funny",
                "engagement_score": 9,
            }
        ]
    }
    raw = f"```json\n{json.dumps(data)}\n```"
    candidates = _parse_candidates(raw)
    assert len(candidates) == 1
    assert candidates[0].hook_type == "humor"


def test_parse_candidates_invalid_json():
    """Test that invalid JSON raises RuntimeError."""
    with pytest.raises(RuntimeError, match="Failed to parse Claude response"):
        _parse_candidates("not json at all")


def test_parse_candidates_with_quality_fields():
    """Test parsing candidates with quality signal fields."""
    data = {
        "candidates": [
            {
                "rank": 1,
                "start_time": 10.0,
                "end_time": 40.0,
                "speaker": "Host",
                "hook_type": "question",
                "transcript_excerpt": "test",
                "reasoning": "test",
                "engagement_score": 8,
                "self_contained_score": 7,
                "narrative_completeness": 6,
                "context_needed": "none",
            }
        ]
    }
    candidates = _parse_candidates(json.dumps(data))
    assert candidates[0].self_contained_score == 7
    assert candidates[0].narrative_completeness == 6
    assert candidates[0].context_needed == "none"


def test_provider_needs_audio_upload_false():
    """Test that ClaudeProvider does not need audio upload."""
    provider = ClaudeProvider(model="claude-sonnet-4-5")
    assert provider.needs_audio_upload is False


@patch("podcut.claude_provider.ClaudeProvider._get_client")
def test_analyze_success(mock_get_client):
    """Test successful analysis via Claude API."""
    data = {
        "candidates": [
            {
                "rank": 1,
                "start_time": 10.0,
                "end_time": 40.0,
                "speaker": "Host",
                "hook_type": "question",
                "transcript_excerpt": "test text",
                "reasoning": "test reason",
                "engagement_score": 8,
            }
        ]
    }
    mock_text_block = MagicMock()
    mock_text_block.text = json.dumps(data)
    mock_response = MagicMock()
    mock_response.content = [mock_text_block]

    mock_client = MagicMock()
    mock_client.messages.create.return_value = mock_response
    mock_get_client.return_value = mock_client

    provider = ClaudeProvider(model="claude-sonnet-4-5")
    candidates = provider.analyze(
        transcript_text="[00:00] Hello\n[00:30] World",
        num_candidates=3,
    )
    assert len(candidates) == 1
    assert candidates[0].hook_type == "question"
    mock_client.messages.create.assert_called_once()


@patch("podcut.claude_provider.ClaudeProvider._get_client")
def test_analyze_api_error_retries(mock_get_client):
    """Test that API errors are retried."""
    mock_client = MagicMock()
    mock_client.messages.create.side_effect = RuntimeError("API error")
    mock_get_client.return_value = mock_client

    provider = ClaudeProvider(model="claude-sonnet-4-5")
    with pytest.raises(RuntimeError, match="Claude API failed after 3 attempts"):
        provider.analyze(
            transcript_text="[00:00] Hello",
            num_candidates=3,
        )
    # Should have been called MAX_RETRIES + 1 = 3 times
    assert mock_client.messages.create.call_count == 3


@patch.dict("os.environ", {}, clear=False)
def test_missing_api_key_raises():
    """Test that missing API key raises SystemExit when SDK is available."""
    import os
    os.environ.pop("ANTHROPIC_API_KEY", None)

    provider = ClaudeProvider(model="claude-sonnet-4-5")
    with pytest.raises((SystemExit, RuntimeError)):
        # RuntimeError if anthropic SDK is not installed,
        # SystemExit if SDK is installed but key is missing
        provider._get_client()


@patch.dict("os.environ", {}, clear=False)
def test_preflight_missing_key():
    """Test that preflight catches missing API key early."""
    import os
    os.environ.pop("ANTHROPIC_API_KEY", None)

    provider = ClaudeProvider(model="claude-sonnet-4-5")
    with pytest.raises((SystemExit, RuntimeError)):
        provider.preflight()


@patch.dict("os.environ", {"ANTHROPIC_API_KEY": "test-key"}, clear=False)
def test_preflight_with_key_but_no_sdk():
    """Test that preflight catches missing SDK."""
    from podcut.claude_provider import _check_anthropic_sdk
    try:
        _check_anthropic_sdk()
        # SDK is installed; preflight should pass
        provider = ClaudeProvider(model="claude-sonnet-4-5")
        provider.preflight()  # Should not raise
    except RuntimeError:
        # SDK not installed; preflight should raise RuntimeError
        provider = ClaudeProvider(model="claude-sonnet-4-5")
        with pytest.raises(RuntimeError, match="anthropic package is not installed"):
            provider.preflight()


def test_create_provider_claude():
    """Test _create_provider returns ClaudeProvider for 'claude'."""
    from podcut.workflow import _create_provider

    provider = _create_provider("claude", "claude-sonnet-4-5")
    assert isinstance(provider, ClaudeProvider)
    assert provider._model == "claude-sonnet-4-5"
