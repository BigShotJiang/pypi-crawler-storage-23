"""Tests for display utilities including preview and selection."""

from unittest.mock import patch


from podcut.display import format_time, prompt_user_selection
from podcut.models import ColdOpenCandidate


def _make_candidates(n=3):
    """Create test candidates for display tests."""
    candidates = []
    for i in range(n):
        candidates.append(
            ColdOpenCandidate(
                rank=i + 1,
                start_time=60.0 * i,
                end_time=60.0 * i + 30.0,
                speaker="Host",
                hook_type="question",
                transcript_excerpt=f"Candidate {i + 1} text",
                reasoning=f"Reason {i + 1}",
                engagement_score=8 - i,
            )
        )
    return candidates


class TestFormatTime:
    def test_seconds(self):
        assert format_time(65.5) == "01:05.50"

    def test_zero(self):
        assert format_time(0.0) == "00:00.00"


class TestPromptUserSelection:
    def test_select_single(self):
        candidates = _make_candidates()
        with patch("builtins.input", return_value="1"):
            indices, feedback = prompt_user_selection(candidates)
        assert indices == [0]
        assert feedback is None

    def test_select_multiple(self):
        candidates = _make_candidates()
        with patch("builtins.input", return_value="1,3"):
            indices, feedback = prompt_user_selection(candidates)
        assert indices == [0, 2]
        assert feedback is None

    def test_select_all(self):
        candidates = _make_candidates()
        with patch("builtins.input", return_value="all"):
            indices, feedback = prompt_user_selection(candidates)
        assert indices == [0, 1, 2]
        assert feedback is None

    def test_select_all_uppercase(self):
        candidates = _make_candidates()
        with patch("builtins.input", return_value="ALL"):
            indices, feedback = prompt_user_selection(candidates)
        assert indices == [0, 1, 2]
        assert feedback is None

    def test_empty_input_selects_all(self):
        candidates = _make_candidates()
        with patch("builtins.input", return_value=""):
            indices, feedback = prompt_user_selection(candidates)
        assert indices == [0, 1, 2]
        assert feedback is None

    def test_feedback_text(self):
        candidates = _make_candidates()
        with patch("builtins.input", return_value="more humor please"):
            indices, feedback = prompt_user_selection(candidates)
        assert indices == []
        assert feedback == "more humor please"

    def test_feedback_japanese(self):
        candidates = _make_candidates()
        with patch("builtins.input", return_value="もっとユーモアのある箇所がほしい"):
            indices, feedback = prompt_user_selection(candidates)
        assert indices == []
        assert feedback == "もっとユーモアのある箇所がほしい"

    def test_out_of_range_number(self):
        candidates = _make_candidates(2)
        with patch("builtins.input", return_value="5"):
            indices, feedback = prompt_user_selection(candidates)
        # Out of range treated as feedback
        assert indices == []
        assert feedback == "5"

    def test_partial_out_of_range(self):
        candidates = _make_candidates(3)
        with patch("builtins.input", return_value="1,5"):
            indices, feedback = prompt_user_selection(candidates)
        # Valid number found, out of range one skipped
        assert indices == [0]
        assert feedback is None
