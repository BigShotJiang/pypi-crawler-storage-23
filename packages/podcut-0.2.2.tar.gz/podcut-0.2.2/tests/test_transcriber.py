"""Tests for Whisper transcriber (mocked)."""

from unittest.mock import MagicMock, patch

from podcut.models import Transcript
from podcut.transcriber import format_transcript_with_timestamps, transcribe


class _FakeWordTiming:
    def __init__(self, word, start, end, probability):
        self.word = word
        self.start = start
        self.end = end
        self.probability = probability


class _FakeSegment:
    def __init__(self, id, start, end, text, words=None):
        self.id = id
        self.start = start
        self.end = end
        self.text = text
        self.words = words or []


class _FakeInfo:
    language = "ja"


@patch("podcut.transcriber.WhisperModel", create=True)
def test_transcribe_basic(mock_model_class, tmp_path):
    """Test basic transcription flow with mocked Whisper."""
    # Create a dummy audio file
    audio_path = tmp_path / "test.wav"
    audio_path.touch()

    # Mock the model
    mock_model = MagicMock()
    mock_model_class.return_value = mock_model

    fake_segments = [
        _FakeSegment(
            id=0,
            start=0.0,
            end=3.0,
            text="こんにちは世界",
            words=[
                _FakeWordTiming("こんにちは", 0.0, 1.5, 0.9),
                _FakeWordTiming("世界", 1.6, 3.0, 0.95),
            ],
        ),
        _FakeSegment(
            id=1,
            start=3.5,
            end=6.0,
            text="テストです",
            words=[
                _FakeWordTiming("テスト", 3.5, 4.5, 0.88),
                _FakeWordTiming("です", 4.6, 6.0, 0.92),
            ],
        ),
    ]

    mock_model.transcribe.return_value = (iter(fake_segments), _FakeInfo())

    # Patch the import inside transcribe
    with patch.dict("sys.modules", {"faster_whisper": MagicMock(WhisperModel=mock_model_class)}):
        result = transcribe(audio_path, model_name="tiny", backend="cpu")

    assert isinstance(result, Transcript)
    assert result.language == "ja"
    assert len(result.segments) == 2
    assert len(result.words) == 4
    assert "こんにちは世界" in result.text


def test_format_transcript():
    """Test transcript formatting with timestamps."""
    t = Transcript(
        text="Hello world",
        language="en",
        segments=[
            {"id": 0, "start": 0.0, "end": 2.5, "text": "Hello"},
            {"id": 1, "start": 3.0, "end": 5.5, "text": "world"},
        ],
    )
    formatted = format_transcript_with_timestamps(t)
    assert "[00:00.00 - 00:02.50] Hello" in formatted
    assert "[00:03.00 - 00:05.50] world" in formatted
