"""Tests for prompt generation."""

from podcut.extraction_mode import CLIP_MODE, COLD_OPEN_MODE
from podcut.prompts import build_analysis_prompt, build_feedback_prompt


def test_build_analysis_prompt_contains_multi_segment():
    """Test that analysis prompt includes multi-segment instructions."""
    prompt = build_analysis_prompt("test transcript", 3)
    assert "is_multi_segment" in prompt
    assert "segments" in prompt
    assert "Multi-Segment" in prompt


def test_build_analysis_prompt_contains_transcript():
    prompt = build_analysis_prompt("Hello world transcript", 2)
    assert "Hello world transcript" in prompt
    assert "2 candidates" in prompt or "2" in prompt


def test_build_analysis_prompt_contains_quality_fields():
    """Test that analysis prompt includes new quality signal fields."""
    prompt = build_analysis_prompt("test transcript", 3)
    assert "self_contained_score" in prompt
    assert "narrative_completeness" in prompt
    assert "context_needed" in prompt


def test_build_analysis_prompt_podcut_quality_criteria():
    """Test that cold open prompt includes cold-open-specific quality criteria."""
    prompt = build_analysis_prompt("test transcript", 3, mode=COLD_OPEN_MODE)
    assert "audio hook" in prompt.lower() or "audio impact" in prompt.lower()
    assert "cliffhanger" in prompt.lower()
    assert "Quality Criteria" in prompt


def test_build_analysis_prompt_clip_quality_criteria():
    """Test that clip prompt includes clip-specific quality criteria."""
    prompt = build_analysis_prompt("test transcript", 3, mode=CLIP_MODE)
    assert "Self-contained" in prompt
    assert "complete story" in prompt.lower() or "complete topic" in prompt.lower()
    assert "Quality Criteria" in prompt


def test_build_analysis_prompt_critical_rules():
    """Test that analysis prompt includes anti-hallucination rules."""
    prompt = build_analysis_prompt("test transcript", 3)
    assert "CRITICAL RULES" in prompt
    assert "NEVER invent or estimate timestamps" in prompt


def test_build_feedback_prompt_contains_feedback():
    """Test that feedback prompt includes user feedback and previous candidates."""
    previous = [
        {
            "rank": 1,
            "start_time": 10.0,
            "end_time": 40.0,
            "hook_type": "question",
            "transcript_excerpt": "old text",
            "reasoning": "old reason",
            "engagement_score": 7,
        }
    ]
    prompt = build_feedback_prompt(
        transcript_text="test transcript",
        num_candidates=3,
        previous_candidates=previous,
        feedback="もっと面白い箇所がほしい",
    )

    assert "もっと面白い箇所がほしい" in prompt
    assert "old text" in prompt
    assert "NOT satisfied" in prompt
    assert "3" in prompt


def test_build_feedback_prompt_includes_transcript():
    prompt = build_feedback_prompt(
        transcript_text="My full transcript here",
        num_candidates=2,
        previous_candidates=[],
        feedback="different style",
    )
    assert "My full transcript here" in prompt


def test_build_feedback_prompt_contains_quality_fields():
    """Test that feedback prompt includes new quality signal fields."""
    prompt = build_feedback_prompt(
        transcript_text="test transcript",
        num_candidates=3,
        previous_candidates=[],
        feedback="feedback",
    )
    assert "self_contained_score" in prompt
    assert "narrative_completeness" in prompt
    assert "context_needed" in prompt


def test_build_feedback_prompt_contains_quality_criteria():
    """Test that feedback prompt includes quality criteria section."""
    prompt = build_feedback_prompt(
        transcript_text="test transcript",
        num_candidates=3,
        previous_candidates=[],
        feedback="feedback",
        mode=COLD_OPEN_MODE,
    )
    assert "Quality Criteria" in prompt


def test_build_analysis_prompt_json_example_has_valid_braces():
    """Test that JSON example uses single braces, not double."""
    prompt = build_analysis_prompt("test", 3)
    assert '{\n  "candidates"' in prompt
    assert '{{\n  "candidates"' not in prompt


def test_build_analysis_prompt_has_audio_true():
    """Test that has_audio=True includes audio context."""
    prompt = build_analysis_prompt("test", 3, has_audio=True)
    assert "podcast audio file" in prompt
    assert "Listen to the audio" in prompt


def test_build_analysis_prompt_has_audio_false():
    """Test that has_audio=False removes audio references."""
    prompt = build_analysis_prompt("test", 3, has_audio=False)
    assert "podcast audio file" not in prompt
    assert "Listen to the audio" not in prompt
    assert "Read the transcript carefully" in prompt


def test_build_feedback_prompt_has_audio_false():
    """Test that feedback prompt with has_audio=False removes audio references."""
    prompt = build_feedback_prompt(
        transcript_text="test",
        num_candidates=3,
        previous_candidates=[],
        feedback="feedback",
        has_audio=False,
    )
    assert "podcast audio file" not in prompt


def test_cold_open_prompt_contains_opening_impact_score():
    """Test that cold open prompt includes opening_impact_score field."""
    prompt = build_analysis_prompt("test transcript", 3, mode=COLD_OPEN_MODE)
    assert "opening_impact_score" in prompt
    assert "FIRST 2-3 SECONDS" in prompt


def test_clip_prompt_contains_shareability_score():
    """Test that clip prompt includes shareability_score field."""
    prompt = build_analysis_prompt("test transcript", 3, mode=CLIP_MODE)
    assert "shareability_score" in prompt
    assert "shareable content" in prompt.lower()


def test_cold_open_prompt_contains_avoid_patterns():
    """Test that cold open prompt includes avoid start patterns."""
    prompt = build_analysis_prompt("test transcript", 3, mode=COLD_OPEN_MODE)
    assert "AVOID These Openings" in prompt
    assert "えーと" in prompt
    assert "こんにちは" in prompt


def test_clip_prompt_no_avoid_patterns():
    """Test that clip prompt does not include avoid start patterns (no patterns configured)."""
    prompt = build_analysis_prompt("test transcript", 3, mode=CLIP_MODE)
    assert "AVOID These Openings" not in prompt


def test_cold_open_prompt_japanese_guidance():
    """Test that cold open prompt includes Japanese content guidance."""
    prompt = build_analysis_prompt("test transcript", 3, mode=COLD_OPEN_MODE)
    assert "えーっ！" in prompt or "マジで！？" in prompt


def test_clip_prompt_japanese_guidance():
    """Test that clip prompt includes Japanese content guidance."""
    prompt = build_analysis_prompt("test transcript", 3, mode=CLIP_MODE)
    assert "オチ" in prompt or "tsukkomi" in prompt.lower()


def test_feedback_prompt_cold_open_contains_opening_impact():
    """Test that feedback prompt for cold open includes opening_impact_score."""
    prompt = build_feedback_prompt(
        transcript_text="test",
        num_candidates=3,
        previous_candidates=[],
        feedback="feedback",
        mode=COLD_OPEN_MODE,
    )
    assert "opening_impact_score" in prompt


def test_feedback_prompt_clip_contains_shareability():
    """Test that feedback prompt for clip includes shareability_score."""
    prompt = build_feedback_prompt(
        transcript_text="test",
        num_candidates=3,
        previous_candidates=[],
        feedback="feedback",
        mode=CLIP_MODE,
    )
    assert "shareability_score" in prompt
