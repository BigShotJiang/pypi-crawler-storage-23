"""Tests for silence detection (uses real librosa with generated audio)."""

from podcut.models import ColdOpenCandidate, Transcript, Word
from podcut.silence_detector import (
    detect_silence_regions,
    find_nearest_silence,
    find_nearest_word_boundary,
    refine_cut_points,
)


def test_detect_silence_in_wav_with_tone(sample_wav_with_tone):
    """Test that silence regions are correctly identified in audio with tones."""
    regions = detect_silence_regions(sample_wav_with_tone, top_db=20)
    # Should find silence regions (start, between tones, end)
    assert len(regions) >= 1

    # All regions should be valid (start < end)
    for start, end in regions:
        assert start < end
        assert start >= 0


def test_detect_silence_in_silent_wav(sample_wav):
    """Fully silent audio should have specific behavior."""
    regions = detect_silence_regions(sample_wav, top_db=20)
    # A fully silent file may either report the entire file as silence
    # or no non-silent regions at all - either is acceptable
    assert isinstance(regions, list)


def test_find_nearest_silence():
    """Test finding nearest silence region to a target."""
    regions = [(1.0, 1.5), (5.0, 5.3), (8.0, 8.5)]

    # Should find (1.0, 1.5) - midpoint 1.25
    result = find_nearest_silence(1.2, regions, search_window_ms=500)
    assert result is not None
    assert abs(result - 1.25) < 0.01

    # Should find (5.0, 5.3) - midpoint 5.15
    result = find_nearest_silence(5.1, regions, search_window_ms=500)
    assert result is not None
    assert abs(result - 5.15) < 0.01

    # Too far from any region
    result = find_nearest_silence(3.0, regions, search_window_ms=500)
    assert result is None


def test_find_nearest_word_boundary():
    """Test finding nearest word boundary."""
    transcript = Transcript(
        text="hello world test",
        language="en",
        words=[
            Word(word="hello", start=0.0, end=0.5, probability=0.9),
            Word(word="world", start=0.8, end=1.3, probability=0.9),
            Word(word="test", start=1.5, end=2.0, probability=0.9),
        ],
    )

    # Between "hello" (end=0.5) and "world" (start=0.8) - gap midpoint = 0.65
    result = find_nearest_word_boundary(0.6, transcript, search_window_ms=500)
    assert result is not None
    assert abs(result - 0.65) < 0.01

    # Too far from any boundary
    result = find_nearest_word_boundary(5.0, transcript, search_window_ms=500)
    assert result is None


def test_refine_cut_points(sample_wav_with_tone):
    """Test refining cut points for candidates."""
    candidates = [
        ColdOpenCandidate(
            rank=1,
            start_time=1.0,
            end_time=4.0,
            speaker="Test",
            hook_type="question",
            transcript_excerpt="test",
            reasoning="test",
            engagement_score=8,
        ),
    ]

    transcript = Transcript(
        text="test",
        language="en",
        words=[
            Word(word="test", start=1.0, end=2.0, probability=0.9),
            Word(word="word", start=2.5, end=3.5, probability=0.9),
        ],
    )

    refined = refine_cut_points(candidates, sample_wav_with_tone, transcript)

    assert len(refined) == 1
    assert refined[0].original_rank == 1
    assert refined[0].refined_start_sec >= 0
    assert refined[0].refined_end_sec > refined[0].refined_start_sec
    assert refined[0].duration_seconds > 0
    assert refined[0].cut_quality in ("clean", "word_boundary")
