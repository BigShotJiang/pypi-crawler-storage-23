"""Tests for audio processor."""


from podcut.audio_processor import (
    extract_all_segments,
    extract_multi_segment,
    extract_segment,
    get_audio_duration_sec,
    load_audio,
)
from podcut.models import RefinedTimestamp, RefinedTimestampPart


def test_load_audio(sample_wav):
    """Test loading a WAV file."""
    audio = load_audio(sample_wav)
    assert len(audio) > 0


def test_get_duration(sample_wav):
    """Test getting audio duration."""
    audio = load_audio(sample_wav)
    duration = get_audio_duration_sec(audio)
    assert abs(duration - 5.0) < 0.1


def test_extract_segment(sample_wav_with_tone, tmp_output_dir):
    """Test extracting a single segment."""
    audio = load_audio(sample_wav_with_tone)
    ts = RefinedTimestamp(
        original_rank=1,
        refined_start_sec=1.0,
        refined_end_sec=4.0,
        duration_seconds=3.0,
        cut_quality="clean",
    )

    output_path = tmp_output_dir / "test_segment.wav"
    result = extract_segment(audio, ts, output_path, output_format="wav")

    assert result.exists()
    assert result.stat().st_size > 0

    # Load and verify duration (approximately 3s + padding)
    extracted = load_audio(result)
    duration = get_audio_duration_sec(extracted)
    assert 2.5 < duration < 4.0


def test_extract_multi_segment(sample_wav_with_tone, tmp_output_dir):
    """Test extracting and combining multiple parts into one audio file."""
    audio = load_audio(sample_wav_with_tone)

    parts = [
        RefinedTimestampPart(
            refined_start_sec=1.0,
            refined_end_sec=2.5,
            duration_seconds=1.5,
            cut_quality="clean",
        ),
        RefinedTimestampPart(
            refined_start_sec=5.0,
            refined_end_sec=7.0,
            duration_seconds=2.0,
            cut_quality="clean",
        ),
    ]

    output_path = tmp_output_dir / "multi_segment.wav"
    result = extract_multi_segment(audio, parts, output_path, output_format="wav")

    assert result.exists()
    assert result.stat().st_size > 0

    # Load and verify combined duration (1.5s + 0.3s gap + 2.0s + padding)
    combined = load_audio(result)
    duration = get_audio_duration_sec(combined)
    assert 3.0 < duration < 5.5


def test_extract_all_segments(sample_wav_with_tone, tmp_output_dir):
    """Test extracting multiple segments."""
    timestamps = [
        RefinedTimestamp(
            original_rank=1,
            refined_start_sec=1.0,
            refined_end_sec=3.5,
            duration_seconds=2.5,
            cut_quality="clean",
        ),
        RefinedTimestamp(
            original_rank=2,
            refined_start_sec=5.0,
            refined_end_sec=7.5,
            duration_seconds=2.5,
            cut_quality="word_boundary",
        ),
    ]

    paths = extract_all_segments(
        sample_wav_with_tone,
        timestamps,
        tmp_output_dir,
        output_format="wav",
    )

    assert len(paths) == 2
    for p in paths:
        assert p.exists()
        assert p.stat().st_size > 0


def test_extract_all_segments_with_multi(sample_wav_with_tone, tmp_output_dir):
    """Test extract_all_segments handles multi-segment timestamps."""
    timestamps = [
        RefinedTimestamp(
            original_rank=1,
            refined_start_sec=1.0,
            refined_end_sec=7.0,
            duration_seconds=3.5,
            cut_quality="clean",
            parts=[
                RefinedTimestampPart(
                    refined_start_sec=1.0,
                    refined_end_sec=2.5,
                    duration_seconds=1.5,
                    cut_quality="clean",
                ),
                RefinedTimestampPart(
                    refined_start_sec=5.0,
                    refined_end_sec=7.0,
                    duration_seconds=2.0,
                    cut_quality="clean",
                ),
            ],
        ),
    ]

    paths = extract_all_segments(
        sample_wav_with_tone,
        timestamps,
        tmp_output_dir,
        output_format="wav",
    )

    assert len(paths) == 1
    assert paths[0].exists()
    assert paths[0].stat().st_size > 0
