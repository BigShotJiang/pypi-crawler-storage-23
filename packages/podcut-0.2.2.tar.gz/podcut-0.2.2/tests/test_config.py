"""Tests for podcut.config — especially _load_all_dotenvs."""

import os
from pathlib import Path
from unittest.mock import patch

import pytest


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

_API_KEY_VARS = ("GEMINI_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "XAI_API_KEY")


@pytest.fixture()
def isolated_env(tmp_path, monkeypatch):
    """Provide isolated project dir, home dir and clean API key env vars.

    Yields (project_dir, home_dir).
    """
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    home_dir = tmp_path / "home"
    home_dir.mkdir()

    # Change to isolated CWD so parent traversal won't find real .env
    monkeypatch.chdir(project_dir)
    # Override HOME so Path.home() returns our tmp home
    monkeypatch.setenv("HOME", str(home_dir))

    # Snapshot and clear all API key env vars
    for var in _API_KEY_VARS:
        monkeypatch.delenv(var, raising=False)

    yield project_dir, home_dir


def _make_config_env(home_dir: Path, content: str) -> Path:
    """Create ~/.config/podcut/.env under the given home_dir."""
    config_dir = home_dir / ".config" / "podcut"
    config_dir.mkdir(parents=True, exist_ok=True)
    env_file = config_dir / ".env"
    env_file.write_text(content)
    return env_file


def _run_load() -> None:
    """Call _load_all_dotenvs (re-import to avoid stale closure)."""
    from podcut.config import _load_all_dotenvs

    _load_all_dotenvs()


# ---------------------------------------------------------------------------
# _load_all_dotenvs regression tests
# ---------------------------------------------------------------------------


class TestLoadAllDotenvs:
    """Regression tests for _load_all_dotenvs."""

    def test_empty_project_env_does_not_block_user_config(self, isolated_env):
        """Regression: project .env with GEMINI_API_KEY= must NOT shadow
        the real key in ~/.config/podcut/.env.

        Scenario:
          - project/.env has GEMINI_API_KEY= (empty placeholder)
          - ~/.config/podcut/.env has GEMINI_API_KEY=real-key-123
        Expected:
          - os.environ["GEMINI_API_KEY"] == "real-key-123"
        """
        project_dir, home_dir = isolated_env

        (project_dir / ".env").write_text("GEMINI_API_KEY=\n")
        _make_config_env(home_dir, "GEMINI_API_KEY=real-key-123\n")

        _run_load()
        assert os.environ.get("GEMINI_API_KEY") == "real-key-123"

    def test_project_env_real_value_takes_priority(self, isolated_env):
        """Project .env with a real value should take priority over user config."""
        project_dir, home_dir = isolated_env

        (project_dir / ".env").write_text("GEMINI_API_KEY=project-key\n")
        _make_config_env(home_dir, "GEMINI_API_KEY=user-key\n")

        _run_load()
        assert os.environ.get("GEMINI_API_KEY") == "project-key"

    def test_shell_env_never_overwritten(self, isolated_env, monkeypatch):
        """Shell export should never be overwritten by any .env file."""
        project_dir, home_dir = isolated_env

        monkeypatch.setenv("GEMINI_API_KEY", "shell-exported-key")
        (project_dir / ".env").write_text("GEMINI_API_KEY=project-key\n")
        _make_config_env(home_dir, "GEMINI_API_KEY=user-key\n")

        _run_load()
        assert os.environ["GEMINI_API_KEY"] == "shell-exported-key"

    def test_user_config_only(self, isolated_env):
        """When no project .env exists, user config .env should be loaded."""
        _project_dir, home_dir = isolated_env

        _make_config_env(home_dir, "OPENAI_API_KEY=my-openai-key\n")

        _run_load()
        assert os.environ.get("OPENAI_API_KEY") == "my-openai-key"

    def test_multiple_empty_keys_all_resolved(self, isolated_env):
        """Multiple empty API keys in project .env should all be resolved
        from user config."""
        project_dir, home_dir = isolated_env

        (project_dir / ".env").write_text(
            "GEMINI_API_KEY=\n"
            "OPENAI_API_KEY=\n"
            "ANTHROPIC_API_KEY=\n"
        )
        _make_config_env(
            home_dir,
            "GEMINI_API_KEY=gem-key\n"
            "OPENAI_API_KEY=oai-key\n"
            "ANTHROPIC_API_KEY=ant-key\n",
        )

        _run_load()
        assert os.environ.get("GEMINI_API_KEY") == "gem-key"
        assert os.environ.get("OPENAI_API_KEY") == "oai-key"
        assert os.environ.get("ANTHROPIC_API_KEY") == "ant-key"

    def test_shell_empty_string_respected(self, isolated_env, monkeypatch):
        """An explicit ``export GEMINI_API_KEY=''`` from the shell must NOT be
        overwritten by ~/.config/podcut/.env.

        This is the distinction: project .env empty placeholders are cleaned
        up, but shell-set empty strings are intentional.
        """
        _project_dir, home_dir = isolated_env

        # Simulate: user typed ``export GEMINI_API_KEY=''`` before launch
        monkeypatch.setenv("GEMINI_API_KEY", "")
        _make_config_env(home_dir, "GEMINI_API_KEY=real-key\n")

        _run_load()
        assert os.environ.get("GEMINI_API_KEY") == ""

    def test_no_env_files_no_crash(self, isolated_env):
        """No .env files anywhere should not cause errors."""
        _run_load()

    def test_non_api_key_vars_preserved(self, isolated_env):
        """Non-API-key env vars from project .env should be preserved."""
        project_dir, home_dir = isolated_env

        (project_dir / ".env").write_text("PODCUT_LANGUAGE=en\nGEMINI_API_KEY=\n")
        _make_config_env(home_dir, "GEMINI_API_KEY=real-key\n")

        _run_load()
        assert os.environ.get("PODCUT_LANGUAGE") == "en"
        assert os.environ.get("GEMINI_API_KEY") == "real-key"


# ---------------------------------------------------------------------------
# has_api_key tests
# ---------------------------------------------------------------------------


class TestHasApiKey:
    def test_ollama_always_true(self):
        from podcut.config import has_api_key

        assert has_api_key("ollama") is True

    def test_unknown_provider_returns_true(self):
        from podcut.config import has_api_key

        assert has_api_key("unknown_provider") is True

    def test_gemini_with_key(self, monkeypatch):
        from podcut.config import has_api_key

        monkeypatch.setenv("GEMINI_API_KEY", "test-key")
        assert has_api_key("gemini") is True

    def test_gemini_without_key(self, monkeypatch):
        from podcut.config import has_api_key

        monkeypatch.delenv("GEMINI_API_KEY", raising=False)
        assert has_api_key("gemini") is False


# ---------------------------------------------------------------------------
# save_api_key_to_dotenv tests
# ---------------------------------------------------------------------------


class TestSaveApiKeyToDotenv:
    def test_creates_file_and_sets_env(self, tmp_path, monkeypatch):
        from podcut.config import save_api_key_to_dotenv

        env_file = tmp_path / ".env"
        with patch("podcut.config._dotenv_path_for_save", return_value=env_file):
            path = save_api_key_to_dotenv("TEST_API_KEY_VAR", "secret-value")

        assert path.exists()
        assert "TEST_API_KEY_VAR=secret-value" in path.read_text()
        assert os.environ.get("TEST_API_KEY_VAR") == "secret-value"
        monkeypatch.delenv("TEST_API_KEY_VAR", raising=False)

    def test_updates_existing_key(self, tmp_path, monkeypatch):
        from podcut.config import save_api_key_to_dotenv

        env_file = tmp_path / ".env"
        env_file.write_text("TEST_VAR=old-value\nOTHER=keep\n")

        with patch("podcut.config._dotenv_path_for_save", return_value=env_file):
            save_api_key_to_dotenv("TEST_VAR", "new-value")

        content = env_file.read_text()
        assert "TEST_VAR=new-value" in content
        assert "OTHER=keep" in content
        assert "old-value" not in content
        monkeypatch.delenv("TEST_VAR", raising=False)

    def test_file_permissions_600(self, tmp_path, monkeypatch):
        from podcut.config import save_api_key_to_dotenv

        with patch("podcut.config._dotenv_path_for_save", return_value=tmp_path / ".env"):
            path = save_api_key_to_dotenv("PERM_TEST_KEY", "val")

        mode = path.stat().st_mode & 0o777
        assert mode == 0o600, f"Expected 0600, got {oct(mode)}"
        monkeypatch.delenv("PERM_TEST_KEY", raising=False)
