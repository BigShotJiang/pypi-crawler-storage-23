"""Tests for Ollama provider parsing and API interaction."""

import json
from unittest.mock import MagicMock, patch

import pytest

from podcut.ollama_provider import OllamaProvider, _call_ollama, _parse_candidates


def test_parse_candidates_valid_json():
    """Test parsing valid JSON response."""
    data = {
        "candidates": [
            {
                "rank": 1,
                "start_time": 10.0,
                "end_time": 40.0,
                "speaker": "Host",
                "hook_type": "question",
                "transcript_excerpt": "test text",
                "reasoning": "test reason",
                "engagement_score": 8,
            }
        ]
    }
    candidates = _parse_candidates(json.dumps(data))
    assert len(candidates) == 1
    assert candidates[0].rank == 1
    assert candidates[0].start_time == 10.0
    assert candidates[0].hook_type == "question"


def test_parse_candidates_with_code_fences():
    """Test parsing JSON wrapped in markdown code fences."""
    data = {
        "candidates": [
            {
                "rank": 1,
                "start_time": 5.0,
                "end_time": 35.0,
                "speaker": "Guest",
                "hook_type": "humor",
                "transcript_excerpt": "funny bit",
                "reasoning": "it's funny",
                "engagement_score": 9,
            }
        ]
    }
    raw = f"```json\n{json.dumps(data)}\n```"
    candidates = _parse_candidates(raw)
    assert len(candidates) == 1
    assert candidates[0].hook_type == "humor"


def test_parse_candidates_invalid_json():
    """Test that invalid JSON raises RuntimeError."""
    with pytest.raises(RuntimeError, match="Failed to parse Ollama response"):
        _parse_candidates("not json at all")


def test_parse_candidates_with_quality_fields():
    """Test parsing candidates with quality signal fields."""
    data = {
        "candidates": [
            {
                "rank": 1,
                "start_time": 10.0,
                "end_time": 40.0,
                "speaker": "Host",
                "hook_type": "question",
                "transcript_excerpt": "test",
                "reasoning": "test",
                "engagement_score": 8,
                "self_contained_score": 7,
                "narrative_completeness": 6,
                "context_needed": "none",
            }
        ]
    }
    candidates = _parse_candidates(json.dumps(data))
    assert candidates[0].self_contained_score == 7
    assert candidates[0].narrative_completeness == 6
    assert candidates[0].context_needed == "none"


@patch("podcut.ollama_provider.httpx.Client")
def test_call_ollama_connection_error(mock_client_cls):
    """Test that connection error gives helpful message."""
    import httpx

    mock_client = MagicMock()
    mock_client.__enter__ = MagicMock(return_value=mock_client)
    mock_client.__exit__ = MagicMock(return_value=False)
    # stream() returns a context manager that raises on __enter__
    mock_stream_ctx = MagicMock()
    mock_stream_ctx.__enter__ = MagicMock(side_effect=httpx.ConnectError("Connection refused"))
    mock_stream_ctx.__exit__ = MagicMock(return_value=False)
    mock_client.stream.return_value = mock_stream_ctx
    mock_client_cls.return_value = mock_client

    with pytest.raises(RuntimeError, match="Ollama.*(?:Cannot connect|接続できません)"):
        _call_ollama("qwen3:8b", "test prompt")


@patch("podcut.ollama_provider.httpx.Client")
def test_call_ollama_success(mock_client_cls):
    """Test successful Ollama API call."""
    # Simulate streaming response: each line is a JSON chunk
    import json as _json
    chunk1 = _json.dumps({"message": {"content": '{"candidates"'}, "done": False})
    chunk2 = _json.dumps({"message": {"content": ": []}"}, "done": True})
    lines = [chunk1, chunk2]

    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock()
    mock_response.iter_lines.return_value = iter(lines)

    mock_stream_ctx = MagicMock()
    mock_stream_ctx.__enter__ = MagicMock(return_value=mock_response)
    mock_stream_ctx.__exit__ = MagicMock(return_value=False)

    mock_client = MagicMock()
    mock_client.__enter__ = MagicMock(return_value=mock_client)
    mock_client.__exit__ = MagicMock(return_value=False)
    mock_client.stream.return_value = mock_stream_ctx
    mock_client_cls.return_value = mock_client

    result = _call_ollama("qwen3:8b", "test prompt")
    assert result == '{"candidates": []}'


def test_create_provider_gemini():
    """Test _create_provider returns GeminiProvider for 'gemini'."""
    from podcut.workflow import _create_provider
    from podcut.gemini_provider import GeminiProvider

    provider = _create_provider("gemini", "gemini-2.5-flash")
    assert isinstance(provider, GeminiProvider)


def test_create_provider_ollama():
    """Test _create_provider returns OllamaProvider for 'ollama'."""
    from podcut.workflow import _create_provider

    provider = _create_provider("ollama", "qwen3:8b")
    assert isinstance(provider, OllamaProvider)
    assert provider._model == "qwen3:8b"


def test_preflight_noop_for_ollama():
    """Test that _preflight_provider is a no-op for providers without preflight."""
    from podcut.workflow import _preflight_provider

    provider = OllamaProvider(model="qwen3:8b")
    # Should not raise - Ollama has no preflight method
    _preflight_provider(provider)


def test_preflight_noop_for_gemini():
    """Test that _preflight_provider is a no-op for Gemini."""
    from podcut.workflow import _preflight_provider
    from podcut.gemini_provider import GeminiProvider

    provider = GeminiProvider(model="gemini-2.5-flash")
    # Should not raise - Gemini has no preflight method
    _preflight_provider(provider)
