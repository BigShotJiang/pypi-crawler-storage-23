"""Tests for CLI interface."""

from unittest.mock import patch

from typer.testing import CliRunner

from podcut.cli import app

runner = CliRunner()


def test_help():
    """Test that help command works."""
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "cold open" in result.output.lower() or "podcast" in result.output.lower()


def test_find_help():
    """Test find subcommand help."""
    result = runner.invoke(app, ["find", "--help"])
    assert result.exit_code == 0
    assert "audio" in result.output.lower()


def test_find_missing_file():
    """Test find with non-existent file."""
    result = runner.invoke(app, ["find", "nonexistent.mp3"])
    assert result.exit_code != 0


def test_cleanup_help():
    """Test cleanup subcommand help."""
    result = runner.invoke(app, ["cleanup", "--help"])
    assert result.exit_code == 0


@patch("podcut.audio_processor.check_ffmpeg")
@patch("podcut.workflow.run_pipeline_interactive")
def test_find_json_output(mock_pipeline, mock_ffmpeg, sample_wav_with_tone):
    """Test find with JSON output mode (implies auto mode)."""
    from podcut.models import ExtractedSegment

    mock_pipeline.return_value = [
        ExtractedSegment(
            rank=1,
            file_path=sample_wav_with_tone.parent / "output.wav",
            start_time=1.0,
            end_time=4.0,
            duration_seconds=3.0,
            hook_type="question",
            speaker="Host",
            transcript_excerpt="Test",
            reasoning="Test reason",
            engagement_score=8,
            cut_quality="clean",
        ),
    ]

    result = runner.invoke(app, ["find", str(sample_wav_with_tone), "--json"])
    assert result.exit_code == 0
    # JSON output should contain the candidate data
    assert "question" in result.output
    assert "Host" in result.output
    # JSON mode implies auto=True
    call_kwargs = mock_pipeline.call_args.kwargs
    assert call_kwargs.get("auto") is True


@patch("podcut.audio_processor.check_ffmpeg")
@patch("podcut.workflow.run_pipeline_interactive")
def test_find_auto_flag(mock_pipeline, mock_ffmpeg, sample_wav_with_tone):
    """Test find with --auto flag."""
    from podcut.models import ExtractedSegment

    mock_pipeline.return_value = [
        ExtractedSegment(
            rank=1,
            file_path=sample_wav_with_tone.parent / "output.wav",
            start_time=1.0,
            end_time=4.0,
            duration_seconds=3.0,
            hook_type="question",
            speaker="Host",
            transcript_excerpt="Test",
            reasoning="Test reason",
            engagement_score=8,
            cut_quality="clean",
        ),
    ]

    result = runner.invoke(app, ["find", str(sample_wav_with_tone), "--auto"])
    assert result.exit_code == 0
    call_kwargs = mock_pipeline.call_args.kwargs
    assert call_kwargs.get("auto") is True


def test_find_help_shows_auto():
    """Test that find help includes --auto option."""
    result = runner.invoke(app, ["find", "--help"])
    assert result.exit_code == 0
    assert "--auto" in result.output


# ---------------------------------------------------------------------------
# config subcommand
# ---------------------------------------------------------------------------


def test_config_help():
    """Test config subcommand help."""
    result = runner.invoke(app, ["config", "--help"])
    assert result.exit_code == 0
    assert "--reset" in result.output
    assert "--path" in result.output


def test_config_no_settings(monkeypatch, tmp_path):
    """Test config when no settings file exists."""
    settings_file = tmp_path / "settings.json"
    monkeypatch.setattr("podcut.settings.SETTINGS_FILE", settings_file)
    result = runner.invoke(app, ["config"])
    assert result.exit_code == 0


def test_config_shows_saved_settings(monkeypatch, tmp_path):
    """Test config displays saved settings."""
    import json

    settings_dir = tmp_path / ".config" / "podcut"
    settings_file = settings_dir / "settings.json"
    settings_dir.mkdir(parents=True)
    settings_file.write_text(json.dumps({"language": "ja", "provider": "gemini"}))
    monkeypatch.setattr("podcut.settings.SETTINGS_FILE", settings_file)
    monkeypatch.setattr("podcut.settings.SETTINGS_DIR", settings_dir)

    result = runner.invoke(app, ["config"])
    assert result.exit_code == 0
    assert "gemini" in result.output


def test_config_reset(monkeypatch, tmp_path):
    """Test config --reset removes settings file."""
    settings_dir = tmp_path / ".config" / "podcut"
    settings_file = settings_dir / "settings.json"
    settings_dir.mkdir(parents=True)
    settings_file.write_text("{}")
    monkeypatch.setattr("podcut.settings.SETTINGS_FILE", settings_file)

    result = runner.invoke(app, ["config", "--reset"])
    assert result.exit_code == 0
    assert not settings_file.exists()


def test_config_path(monkeypatch, tmp_path):
    """Test config --path shows settings path."""
    settings_file = tmp_path / "settings.json"
    monkeypatch.setattr("podcut.settings.SETTINGS_FILE", settings_file)

    result = runner.invoke(app, ["config", "--path"])
    assert result.exit_code == 0
    # Rich may wrap long paths across lines, so check the filename part
    assert "settings.json" in result.output
