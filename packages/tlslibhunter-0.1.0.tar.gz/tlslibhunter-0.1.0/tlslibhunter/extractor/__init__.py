"""Library extraction modules."""
