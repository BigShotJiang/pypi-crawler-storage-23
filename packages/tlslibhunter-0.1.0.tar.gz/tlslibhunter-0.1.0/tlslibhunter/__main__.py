"""Allow running as: python -m tlslibhunter"""

from tlslibhunter.cli import main

if __name__ == "__main__":
    main()
