def main() -> None:
    print("Hello from baby-dino-run!")
