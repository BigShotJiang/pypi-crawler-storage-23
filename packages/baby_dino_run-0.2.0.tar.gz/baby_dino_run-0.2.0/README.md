# baby-dino-run
Dino Run Game written in python using pygame

# Tutorial to understand the game code can be found below.
https://youtu.be/9TPtAMpI478

# Python version used
3.12

# How to run the game
Just run the file baby_dino_run.py using command 'python3 baby_dino_game.py'

# How to play the game
Press Space to Jump.  
Press Q or close the window to quit the game.
