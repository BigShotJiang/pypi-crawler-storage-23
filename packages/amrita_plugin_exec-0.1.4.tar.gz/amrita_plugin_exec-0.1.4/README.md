# amrita-plugin-exec

Amrita的命令执行插件

## 功能描述

这是一个为Amrita框架开发的命令执行插件，允许授权用户在聊天中执行服务器命令。

## 安装

使用uv安装：

```bash
uv add amrita-plugin-exec
```

或者使用amrita-cli安装：

```bash
amrita plugin install amrita-plugin-exec
```

## 配置

插件提供了以下配置选项，可以在 .env 或环境变量中进行配置：

```dotenv
ENABLE_DOCKER=false
# 是否启用Docker下的指令执行，默认为 False

PLUGIN_EXEC_IMAGE_NAME=alpine:latest
# 要使用的Docker镜像名称，默认为 "alpine:latest"

PLUGIN_EXEC_DOCKER_HOST=unix://var/run/docker.sock
# Docker守护进程的地址，默认为 "unix://var/run/docker.sock"

PLUGIN_EXEC_SHELL_NAME=sh
# 在容器中执行命令时使用的shell名称，默认为 "sh"

AUTO_REBUILD_CONTAINER=true
# 是否在运行完成后自动重建容器，默认为 true

ENABLE_IN_TOOL=true
# 是否允许LLM执行此工具，默认为 true
```

## 使用方法

在Amrita机器人中，授权用户可以使用以下命令：

- `/exec <command>`：执行指定的服务器命令。

## 注意事项

如果要交给LLM进行命令执行，则仅支持 Docker 容器。

## 权限节点

插件添加了以下权限节点：

- `amrita.exec.full`：允许用户执行宿主命令。
- `amrita.exec.safe`：允许用户容器内执行命令。

## TODO

- [x] 包装为Amrita的Tool
