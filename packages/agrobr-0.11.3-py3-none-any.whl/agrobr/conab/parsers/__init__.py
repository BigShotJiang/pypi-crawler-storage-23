"""Parsers CONAB."""

from __future__ import annotations

from agrobr.conab.parsers.v1 import ConabParserV1

__all__ = ["ConabParserV1"]
