"""Claude Unity Bridge - Control Unity Editor from Claude Code."""

__version__ = "0.2.2"
