"""
Health check module for worker services.

Provides a lightweight HTTP health server with pluggable dependency checkers
for Kubernetes liveness and readiness probes.

Usage:
    from core_lib.core_lib_health import HealthServer, RedisHealthCheck, DatabaseHealthCheck

    server = HealthServer(port=8080)
    server.add_check(RedisHealthCheck())
    server.add_check(DatabaseHealthCheck())
    server.start()  # Starts in a daemon thread
"""

from .health_server import HealthServer
from .checks import (
    HealthCheck,
    HealthCheckResult,
    RedisHealthCheck,
    DatabaseHealthCheck,
    S3HealthCheck,
)

__all__ = [
    "HealthServer",
    "HealthCheck",
    "HealthCheckResult",
    "RedisHealthCheck",
    "DatabaseHealthCheck",
    "S3HealthCheck",
]
