"""
Pluggable health check implementations for common worker dependencies.

Each check implements the HealthCheck protocol and can be registered
with a HealthServer instance.
"""

import logging
import os
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class HealthCheckResult:
    """Result of a single health check."""
    name: str
    healthy: bool
    message: str
    latency_ms: Optional[float] = None


class HealthCheck(ABC):
    """Abstract base class for health checks."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable name of this check (e.g., 'redis', 'database')."""
        ...

    @abstractmethod
    def check(self) -> HealthCheckResult:
        """
        Execute the health check synchronously.

        Returns:
            HealthCheckResult with status and diagnostics.
        """
        ...


class RedisHealthCheck(HealthCheck):
    """
    Check Redis connectivity via a PING command.

    Uses REDIS_HOST and REDIS_PORT from environment (same as CoreSettings).
    """

    @property
    def name(self) -> str:
        return "redis"

    def __init__(self, host: Optional[str] = None, port: Optional[int] = None):
        self._host = host or os.getenv("REDIS_HOST", "localhost")
        self._port = port or int(os.getenv("REDIS_PORT", "6379"))

    def check(self) -> HealthCheckResult:
        import time
        start = time.monotonic()
        try:
            import redis
            client = redis.Redis(
                host=self._host,
                port=self._port,
                socket_connect_timeout=3,
                socket_timeout=3,
            )
            pong = client.ping()
            latency = (time.monotonic() - start) * 1000
            client.close()
            if pong:
                return HealthCheckResult(
                    name=self.name,
                    healthy=True,
                    message=f"Redis PING OK ({self._host}:{self._port})",
                    latency_ms=round(latency, 2),
                )
            return HealthCheckResult(
                name=self.name,
                healthy=False,
                message=f"Redis PING returned False",
            )
        except ImportError:
            return HealthCheckResult(
                name=self.name,
                healthy=False,
                message="redis-py not installed — cannot check Redis health",
            )
        except Exception as e:
            latency = (time.monotonic() - start) * 1000
            return HealthCheckResult(
                name=self.name,
                healthy=False,
                message=f"Redis connection failed: {e}",
                latency_ms=round(latency, 2),
            )


class DatabaseHealthCheck(HealthCheck):
    """
    Check PostgreSQL connectivity via SELECT 1.

    Uses DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_DATABASE from environment
    (same as DBSettings).
    """

    @property
    def name(self) -> str:
        return "database"

    def check(self) -> HealthCheckResult:
        import time
        start = time.monotonic()
        try:
            from ..core_lib_config.settings import DBSettings
            from ..core_lib_db.session import get_db_session
            from sqlalchemy import text

            db_settings = DBSettings()
            session = get_db_session(db_settings)
            session.execute(text("SELECT 1"))
            session.close()
            latency = (time.monotonic() - start) * 1000
            return HealthCheckResult(
                name=self.name,
                healthy=True,
                message=f"Database SELECT 1 OK ({db_settings.DB_HOST}:{db_settings.DB_PORT})",
                latency_ms=round(latency, 2),
            )
        except Exception as e:
            latency = (time.monotonic() - start) * 1000
            return HealthCheckResult(
                name=self.name,
                healthy=False,
                message=f"Database connection failed: {e}",
                latency_ms=round(latency, 2),
            )


class S3HealthCheck(HealthCheck):
    """
    Check S3-compatible storage connectivity via a HEAD bucket call.

    Uses S3_ENDPOINT_URL, S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY, S3_BUCKET
    from environment (same as S3Settings).
    """

    @property
    def name(self) -> str:
        return "s3"

    def check(self) -> HealthCheckResult:
        import time
        start = time.monotonic()
        try:
            from ..core_lib_config.settings import S3Settings
            import boto3
            from botocore.config import Config as BotoConfig

            s3_settings = S3Settings()
            s3_client = boto3.client(
                "s3",
                endpoint_url=s3_settings.S3_ENDPOINT_URL,
                aws_access_key_id=s3_settings.S3_ACCESS_KEY_ID,
                aws_secret_access_key=s3_settings.S3_SECRET_ACCESS_KEY,
                config=BotoConfig(
                    connect_timeout=3,
                    read_timeout=3,
                    retries={"max_attempts": 1},
                ),
            )
            s3_client.head_bucket(Bucket=s3_settings.S3_BUCKET)
            latency = (time.monotonic() - start) * 1000
            return HealthCheckResult(
                name=self.name,
                healthy=True,
                message=f"S3 bucket '{s3_settings.S3_BUCKET}' reachable",
                latency_ms=round(latency, 2),
            )
        except ImportError:
            return HealthCheckResult(
                name=self.name,
                healthy=False,
                message="boto3 not installed — cannot check S3 health",
            )
        except Exception as e:
            latency = (time.monotonic() - start) * 1000
            return HealthCheckResult(
                name=self.name,
                healthy=False,
                message=f"S3 connection failed: {e}",
                latency_ms=round(latency, 2),
            )
