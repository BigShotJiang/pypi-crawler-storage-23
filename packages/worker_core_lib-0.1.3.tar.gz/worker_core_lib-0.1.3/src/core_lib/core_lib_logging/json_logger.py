"""
JSON formatter and correlation-ID propagation for Python workers.

This module replaces the default text-based logging output with structured
JSON, making logs parseable by ELK / Loki / CloudWatch and correlatable
with the NestJS backend via ``correlationId``.
"""
import json
import logging
import os
import socket
import threading
from datetime import datetime, timezone
from typing import Optional

# Thread-local storage for correlation ID (safe for async via contextvars too)
_thread_local = threading.local()


def set_correlation_id(correlation_id: Optional[str]) -> None:
    """Set the correlation ID for the current thread / async context."""
    _thread_local.correlation_id = correlation_id


def get_correlation_id() -> Optional[str]:
    """Return the current correlation ID, or ``None``."""
    return getattr(_thread_local, "correlation_id", None)


def clear_correlation_id() -> None:
    """Clear the correlation ID after a job finishes."""
    _thread_local.correlation_id = None


class CorrelationIdFilter(logging.Filter):
    """
    Logging filter that injects ``correlationId`` and ``worker`` into every
    ``LogRecord`` so formatters can include them automatically.
    """

    def __init__(self, worker_name: str = "unknown-worker") -> None:
        super().__init__()
        self.worker_name = worker_name

    def filter(self, record: logging.LogRecord) -> bool:
        record.correlationId = get_correlation_id() or "no-context"  # type: ignore[attr-defined]
        record.worker = self.worker_name  # type: ignore[attr-defined]
        return True


class JsonFormatter(logging.Formatter):
    """
    Emit each log record as a single-line JSON object.

    Schema::

        {
          "timestamp": "2026-02-08T12:34:56.789Z",
          "level": "INFO",
          "logger": "src.worker",
          "message": "Processing model abc-123",
          "correlationId": "550e8400-e29b-41d4-a716-446655440000",
          "worker": "worker-thumbnail-generation",
          "hostname": "worker-thumb-7f9c6d-abc12",
          "environment": "production"
        }
    """

    def __init__(self) -> None:
        super().__init__()
        self._hostname = socket.gethostname()
        self._environment = os.getenv("NODE_ENV") or os.getenv("WORKER_ENV") or "development"

    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "correlationId": getattr(record, "correlationId", "no-context"),
            "worker": getattr(record, "worker", "unknown-worker"),
            "hostname": self._hostname,
            "environment": self._environment,
        }

        # Include exception info when present
        if record.exc_info and record.exc_info[1] is not None:
            log_entry["error"] = {
                "type": record.exc_info[0].__name__ if record.exc_info[0] else "Exception",
                "message": str(record.exc_info[1]),
                "stack": self.formatException(record.exc_info),
            }

        # Include extra fields (e.g. modelId, jobId) if attached
        extra_keys = set(record.__dict__.keys()) - {
            "name", "msg", "args", "created", "relativeCreated",
            "exc_info", "exc_text", "stack_info", "lineno", "funcName",
            "filename", "module", "pathname", "levelname", "levelno",
            "msecs", "message", "correlationId", "worker",
            "processName", "process", "threadName", "thread",
            "taskName",
        }
        for key in extra_keys:
            val = record.__dict__[key]
            if isinstance(val, (str, int, float, bool, type(None))):
                log_entry[key] = val

        return json.dumps(log_entry, default=str)


def configure_logging(
    worker_name: str = "unknown-worker",
    level: str | None = None,
) -> None:
    """
    Configure the root logger with structured JSON output.

    Call this **once** at worker startup (in ``main.py``) before any other
    logging calls.

    Args:
        worker_name: Identifier for the worker service (appears in every log line).
        level: Logging level string (DEBUG, INFO, WARNING, ERROR). Defaults to
               the ``LOG_LEVEL`` env var or ``INFO``.
    """
    resolved_level = (level or os.getenv("LOG_LEVEL", "INFO")).upper()

    root = logging.getLogger()
    root.setLevel(resolved_level)

    # Remove any existing handlers (prevents duplicate output)
    root.handlers.clear()

    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    handler.addFilter(CorrelationIdFilter(worker_name=worker_name))
    root.addHandler(handler)

    # Suppress noisy third-party loggers
    for noisy in ("urllib3", "botocore", "boto3", "s3transfer", "asyncio"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    logging.getLogger(__name__).info(
        "Structured JSON logging configured for %s at level %s",
        worker_name,
        resolved_level,
    )
