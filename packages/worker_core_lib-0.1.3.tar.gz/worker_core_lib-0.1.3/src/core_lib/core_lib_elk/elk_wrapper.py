"""
ELK Event Wrapper for Worker Metrics

Provides a high-level interface for workers to emit structured events to Elasticsearch
with automatic base field population, metric tracking, and performance monitoring.

Usage Examples:
    # Track LLM execution
    async with elk_wrapper.track_llm_execution(model="gpt-4", user_id="user-123") as tracker:
        result = await llm.generate(prompt)
        tracker.set_token_usage(input=1000, output=500)
        tracker.set_result(result)
    
    # Track Blender operations
    async with elk_wrapper.track_blender_operation(
        operation="thumbnail_generation",
        model_id="model-456"
    ) as tracker:
        thumbnail = await blender.render_thumbnail()
        tracker.set_output_file(thumbnail.path, thumbnail.size)
    
    # Track file processing
    async with elk_wrapper.track_file_processing(
        operation="gltf_conversion",
        input_format="fbx",
        output_format="gltf"
    ) as tracker:
        result = await convert_file(input_path)
        tracker.set_file_size(result.size)
"""

import logging
import os
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Any, Dict, Optional, AsyncGenerator
from enum import Enum

try:
    from elasticsearch import AsyncElasticsearch
    ELASTICSEARCH_AVAILABLE = True
except ImportError:
    ELASTICSEARCH_AVAILABLE = False
    AsyncElasticsearch = None

logger = logging.getLogger(__name__)


class MetricCategory(str, Enum):
    """Categories of metrics that can be tracked"""
    LLM_EXECUTION = "llm_execution"
    BLENDER_OPERATION = "blender_operation"
    FILE_PROCESSING = "file_processing"
    MARKETPLACE_API = "marketplace_api"
    DATABASE_QUERY = "database_query"
    EXTERNAL_API = "external_api"
    CUSTOM = "custom"


class ElkMetricTracker:
    """
    Context manager for tracking a single metric/operation.
    Automatically calculates duration and populates base fields.
    """

    def __init__(
        self,
        elk_wrapper: "ElkEventWrapper",
        category: MetricCategory,
        operation_name: str,
        base_context: Dict[str, Any],
    ):
        self.elk_wrapper = elk_wrapper
        self.category = category
        self.operation_name = operation_name
        self.base_context = base_context
        self.start_time = None
        self.end_time = None
        self.metrics: Dict[str, Any] = {}
        self.error: Optional[Exception] = None
        self.success = True

    async def __aenter__(self):
        """Start tracking the operation"""
        self.start_time = datetime.utcnow()
        logger.debug(f"Started tracking {self.category}: {self.operation_name}")
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Finish tracking and emit event"""
        self.end_time = datetime.utcnow()
        
        if exc_type is not None:
            self.success = False
            self.error = exc_val
        
        # Calculate duration
        duration_ms = int((self.end_time - self.start_time).total_seconds() * 1000)
        
        # Build event document
        event_data = {
            "category": self.category.value,
            "operationName": self.operation_name,
            "success": self.success,
            "durationMs": duration_ms,
            "startedAt": self.start_time.isoformat() + "Z",
            "completedAt": self.end_time.isoformat() + "Z",
            "metrics": self.metrics,
        }
        
        # Add error details if failed
        if not self.success and self.error:
            event_data["error"] = {
                "type": type(self.error).__name__,
                "message": str(self.error),
            }
        
        # Merge with base context
        event_data.update(self.base_context)
        
        # Emit to ELK
        await self.elk_wrapper._emit_metric_event(event_data)
        
        logger.debug(
            f"Completed tracking {self.category}: {self.operation_name} "
            f"(duration={duration_ms}ms, success={self.success})"
        )
        
        # Don't suppress exceptions
        return False

    def set_metric(self, key: str, value: Any) -> None:
        """Add a custom metric"""
        self.metrics[key] = value

    def set_token_usage(self, input_tokens: int, output_tokens: int, total_cost: Optional[float] = None) -> None:
        """Set LLM token usage metrics"""
        self.metrics["inputTokens"] = input_tokens
        self.metrics["outputTokens"] = output_tokens
        self.metrics["totalTokens"] = input_tokens + output_tokens
        if total_cost is not None:
            self.metrics["costUsd"] = total_cost

    def set_file_size(self, size_bytes: int) -> None:
        """Set file size metric"""
        self.metrics["fileSizeBytes"] = size_bytes
        self.metrics["fileSizeMB"] = round(size_bytes / 1024 / 1024, 2)

    def set_output_file(self, file_path: str, size_bytes: int) -> None:
        """Set output file information"""
        self.metrics["outputFilePath"] = file_path
        self.set_file_size(size_bytes)

    def set_api_response_code(self, code: int) -> None:
        """Set API response code"""
        self.metrics["httpStatusCode"] = code

    def set_blender_stats(self, vertices: int, faces: int, render_samples: Optional[int] = None) -> None:
        """Set Blender-specific statistics"""
        self.metrics["vertices"] = vertices
        self.metrics["faces"] = faces
        if render_samples is not None:
            self.metrics["renderSamples"] = render_samples

    def set_database_stats(self, rows_affected: int, query_plan_cost: Optional[float] = None) -> None:
        """Set database query statistics"""
        self.metrics["rowsAffected"] = rows_affected
        if query_plan_cost is not None:
            self.metrics["queryPlanCost"] = query_plan_cost


class ElkEventWrapper:
    """
    High-level wrapper for emitting structured events to Elasticsearch.
    
    Handles:
    - Base field population (timestamp, source, environment)
    - User context fields (userId, userEmail)
    - Model/metamodel context fields
    - Automatic metric calculation (duration, timestamps)
    - Error handling and logging fallback
    """

    def __init__(
        self,
        worker_name: str,
        elasticsearch_url: Optional[str] = None,
        default_user_id: Optional[str] = None,
    ):
        """
        Initialize the ELK event wrapper.
        
        Args:
            worker_name: Name of the worker (e.g., "worker-metadata-generation")
            elasticsearch_url: Elasticsearch connection URL
            default_user_id: Default user ID if not provided in context
        """
        self.worker_name = worker_name
        self.elasticsearch_url = elasticsearch_url or os.getenv(
            "ELASTICSEARCH_URL", "http://149.202.214.99:9200"
        )
        self.elasticsearch_username = os.getenv("ELASTICSEARCH_USERNAME", "elk_user_kibana")
        self.elasticsearch_password = os.getenv("ELASTICSEARCH_PASSWORD", "elk_password_kibana")
        self.default_user_id = default_user_id
        self.es_client: Optional[AsyncElasticsearch] = None
        self.enabled = self._check_elk_available()
        
        if self.enabled:
            self._initialize_es_client()
            logger.info(f"ELK wrapper initialized for {worker_name} -> {self.elasticsearch_url}")
        else:
            logger.warning(f"ELK wrapper disabled for {worker_name} - events will be logged only")

    def _check_elk_available(self) -> bool:
        """Check if Elasticsearch is available"""
        if not ELASTICSEARCH_AVAILABLE:
            logger.warning("elasticsearch-py not installed - ELK disabled")
            return False
        
        enable_elk = os.getenv("ENABLE_ELK", "false").lower() == "true"
        if not enable_elk:
            logger.info("ENABLE_ELK=false - ELK disabled")
            return False
        
        return self.elasticsearch_url is not None

    def _initialize_es_client(self) -> None:
        """Initialize Elasticsearch async client"""
        if not ELASTICSEARCH_AVAILABLE:
            return
        
        try:
            self.es_client = AsyncElasticsearch(
                hosts=[self.elasticsearch_url],
                basic_auth=(self.elasticsearch_username, self.elasticsearch_password),
                verify_certs=False,  # For development - set to True in production
                request_timeout=30,
            )
            logger.info(f"Elasticsearch client initialized for {self.elasticsearch_url}")
        except Exception as e:
            logger.error(f"Failed to initialize Elasticsearch client: {e}", exc_info=True)
            self.enabled = False
            self.es_client = None

    async def _emit_metric_event(self, event_data: Dict[str, Any]) -> bool:
        """
        Emit a metric event to Elasticsearch.
        
        Populates base fields automatically:
        - timestamp (from completedAt)
        - source (worker name)
        - eventVersion
        - environment
        """
        if not self.enabled:
            logger.info(f"[ELK Disabled] Metric event: {event_data.get('category')} - {event_data.get('operationName')}")
            logger.debug(f"Event data: {event_data}")
            return False

        try:
            # Populate base fields
            document = {
                "timestamp": event_data.get("completedAt", datetime.utcnow().isoformat() + "Z"),
                "source": self.worker_name,
                "eventVersion": "1.0.0",
                "environment": os.getenv("ENVIRONMENT", "development"),
            }
            
            # Merge event data
            document.update(event_data)
            
            # Index to Elasticsearch
            if self.es_client:
                index_name = self._get_index_name(event_data.get('category', 'unknown'))
                try:
                    await self.es_client.index(
                        index=index_name,
                        document=document,
                    )
                    logger.info(
                        f"Indexed metric event to {index_name}: {event_data.get('category')} - "
                        f"{event_data.get('operationName')} (duration={event_data.get('durationMs')}ms)"
                    )
                    logger.debug(f"Event document: {document}")
                except Exception as index_error:
                    logger.error(f"Failed to index to Elasticsearch: {index_error}", exc_info=True)
                    # Fallback to logging
                    logger.info(f"[ELK Fallback] Metric event: {event_data.get('category')} - {event_data.get('operationName')}")
                    logger.debug(f"Event data: {event_data}")
            else:
                logger.warning("Elasticsearch client not available - logging event only")
                logger.info(f"[ELK Disabled] Metric event: {event_data.get('category')} - {event_data.get('operationName')}")
                logger.debug(f"Event data: {event_data}")
            
            return True

        except Exception as e:
            logger.error(f"Failed to emit metric event: {e}", exc_info=True)
            return False

    def _get_index_name(self, category: str) -> str:
        """
        Get index name based on category and time-based rotation (monthly).
        
        Pattern: worker-metrics-{category}-{YYYY.MM}
        Example: worker-metrics-llm_execution-2024.11
        """
        year_month = datetime.utcnow().strftime("%Y.%m")
        category_clean = category.replace("_", "-").lower()
        return f"worker-metrics-{category_clean}-{year_month}"

    async def close(self) -> None:
        """Close Elasticsearch client connection"""
        if self.es_client:
            try:
                await self.es_client.close()
                logger.info("Elasticsearch client closed")
            except Exception as e:
                logger.error(f"Error closing Elasticsearch client: {e}", exc_info=True)

    async def __aenter__(self):
        """Context manager entry"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - cleanup resources"""
        await self.close()
        return False

    @asynccontextmanager
    async def track_llm_execution(
        self,
        model: str,
        user_id: Optional[str] = None,
        prompt_type: Optional[str] = None,
        **extra_context,
    ) -> AsyncGenerator[ElkMetricTracker, None]:
        """
        Track LLM execution metrics.
        
        Args:
            model: LLM model name (e.g., "gpt-4", "claude-3-opus")
            user_id: User ID performing the operation
            prompt_type: Type of prompt (e.g., "metadata_generation", "description")
            **extra_context: Additional context fields
        
        Usage:
            async with elk_wrapper.track_llm_execution(
                model="gpt-4",
                user_id="user-123",
                prompt_type="metadata_generation"
            ) as tracker:
                result = await llm.generate(prompt)
                tracker.set_token_usage(input=1000, output=500, total_cost=0.05)
                tracker.set_metric("promptLength", len(prompt))
        """
        base_context = {
            "userId": user_id or self.default_user_id,
            "llmModel": model,
            "promptType": prompt_type,
            **extra_context,
        }
        
        tracker = ElkMetricTracker(
            elk_wrapper=self,
            category=MetricCategory.LLM_EXECUTION,
            operation_name=f"llm_{model}_{prompt_type or 'unknown'}",
            base_context=base_context,
        )
        
        async with tracker:
            yield tracker

    @asynccontextmanager
    async def track_blender_operation(
        self,
        operation: str,
        model_id: Optional[str] = None,
        user_id: Optional[str] = None,
        **extra_context,
    ) -> AsyncGenerator[ElkMetricTracker, None]:
        """
        Track Blender operation metrics.
        
        Args:
            operation: Operation type (e.g., "thumbnail_generation", "gltf_export")
            model_id: Model being processed
            user_id: User ID
            **extra_context: Additional context fields
        
        Usage:
            async with elk_wrapper.track_blender_operation(
                operation="thumbnail_generation",
                model_id="model-456"
            ) as tracker:
                thumbnail = await blender.render_thumbnail(model)
                tracker.set_output_file(thumbnail.path, thumbnail.size)
                tracker.set_blender_stats(vertices=15000, faces=30000, render_samples=128)
        """
        base_context = {
            "userId": user_id or self.default_user_id,
            "modelId": model_id,
            "blenderOperation": operation,
            **extra_context,
        }
        
        tracker = ElkMetricTracker(
            elk_wrapper=self,
            category=MetricCategory.BLENDER_OPERATION,
            operation_name=f"blender_{operation}",
            base_context=base_context,
        )
        
        async with tracker:
            yield tracker

    @asynccontextmanager
    async def track_file_processing(
        self,
        operation: str,
        input_format: Optional[str] = None,
        output_format: Optional[str] = None,
        model_id: Optional[str] = None,
        user_id: Optional[str] = None,
        **extra_context,
    ) -> AsyncGenerator[ElkMetricTracker, None]:
        """
        Track file processing metrics.
        
        Args:
            operation: Operation type (e.g., "gltf_conversion", "stl_validation")
            input_format: Input file format
            output_format: Output file format
            model_id: Model being processed
            user_id: User ID
            **extra_context: Additional context fields
        
        Usage:
            async with elk_wrapper.track_file_processing(
                operation="gltf_conversion",
                input_format="fbx",
                output_format="gltf",
                model_id="model-789"
            ) as tracker:
                result = await convert_file(input_path, output_path)
                tracker.set_file_size(result.output_size)
                tracker.set_metric("compressionRatio", result.compression_ratio)
        """
        base_context = {
            "userId": user_id or self.default_user_id,
            "modelId": model_id,
            "inputFormat": input_format,
            "outputFormat": output_format,
            "processingOperation": operation,
            **extra_context,
        }
        
        tracker = ElkMetricTracker(
            elk_wrapper=self,
            category=MetricCategory.FILE_PROCESSING,
            operation_name=f"file_{operation}",
            base_context=base_context,
        )
        
        async with tracker:
            yield tracker

    @asynccontextmanager
    async def track_marketplace_api_call(
        self,
        marketplace: str,
        api_endpoint: str,
        method: str = "POST",
        user_id: Optional[str] = None,
        **extra_context,
    ) -> AsyncGenerator[ElkMetricTracker, None]:
        """
        Track marketplace API call metrics.
        
        Args:
            marketplace: Marketplace name (e.g., "etsy", "ebay")
            api_endpoint: API endpoint being called
            method: HTTP method
            user_id: User ID
            **extra_context: Additional context fields
        
        Usage:
            async with elk_wrapper.track_marketplace_api_call(
                marketplace="etsy",
                api_endpoint="/v3/listings",
                method="POST"
            ) as tracker:
                response = await etsy_client.create_listing(data)
                tracker.set_api_response_code(response.status_code)
                tracker.set_metric("rateLimitRemaining", response.headers.get("X-RateLimit-Remaining"))
        """
        base_context = {
            "userId": user_id or self.default_user_id,
            "marketplace": marketplace,
            "apiEndpoint": api_endpoint,
            "httpMethod": method,
            **extra_context,
        }
        
        tracker = ElkMetricTracker(
            elk_wrapper=self,
            category=MetricCategory.MARKETPLACE_API,
            operation_name=f"marketplace_{marketplace}_{api_endpoint.replace('/', '_')}",
            base_context=base_context,
        )
        
        async with tracker:
            yield tracker

    @asynccontextmanager
    async def track_database_query(
        self,
        query_type: str,
        table_name: Optional[str] = None,
        **extra_context,
    ) -> AsyncGenerator[ElkMetricTracker, None]:
        """
        Track database query metrics.
        
        Args:
            query_type: Query type (e.g., "SELECT", "INSERT", "UPDATE")
            table_name: Table being queried
            **extra_context: Additional context fields
        
        Usage:
            async with elk_wrapper.track_database_query(
                query_type="SELECT",
                table_name="metamodels"
            ) as tracker:
                result = await db.execute(query)
                tracker.set_database_stats(rows_affected=len(result))
        """
        base_context = {
            "queryType": query_type,
            "tableName": table_name,
            **extra_context,
        }
        
        tracker = ElkMetricTracker(
            elk_wrapper=self,
            category=MetricCategory.DATABASE_QUERY,
            operation_name=f"db_{query_type}_{table_name or 'unknown'}",
            base_context=base_context,
        )
        
        async with tracker:
            yield tracker

    @asynccontextmanager
    async def track_custom_operation(
        self,
        operation_name: str,
        user_id: Optional[str] = None,
        **extra_context,
    ) -> AsyncGenerator[ElkMetricTracker, None]:
        """
        Track a custom operation.
        
        Args:
            operation_name: Name of the operation
            user_id: User ID
            **extra_context: Additional context fields
        
        Usage:
            async with elk_wrapper.track_custom_operation(
                operation_name="custom_analysis",
                user_id="user-123",
                analysisType="complexity"
            ) as tracker:
                result = await perform_custom_analysis()
                tracker.set_metric("analysisScore", result.score)
        """
        base_context = {
            "userId": user_id or self.default_user_id,
            **extra_context,
        }
        
        tracker = ElkMetricTracker(
            elk_wrapper=self,
            category=MetricCategory.CUSTOM,
            operation_name=operation_name,
            base_context=base_context,
        )
        
        async with tracker:
            yield tracker
