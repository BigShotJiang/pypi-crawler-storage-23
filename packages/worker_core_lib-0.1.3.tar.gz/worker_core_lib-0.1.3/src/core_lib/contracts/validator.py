"""Contract validation utilities for worker queue names.

Validates that a worker's queue name has a corresponding YAML contract
definition in worker-backend/messages/.  This can be run:

  - At startup  (soft warning by default)
  - In CI       (hard failure via the reusable worker-python-ci.yml)
  - As a pytest fixture

Usage::

    from core_lib.contracts.validator import validate_queue_contract

    # Returns True/False and logs a warning on mismatch
    is_valid = validate_queue_contract("model.metadata.generation.request")

    # Strict mode raises on mismatch (for CI / tests)
    validate_queue_contract("model.metadata.generation.request", strict=True)
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Optional

import yaml  # type: ignore[import-untyped]

logger = logging.getLogger(__name__)

# Default relative path from a worker directory to the messages/ folder.
_DEFAULT_MESSAGES_DIR = os.environ.get(
    "WORKER_CONTRACTS_DIR",
    str(Path(__file__).resolve().parents[4] / "worker-backend" / "messages"),
)


class ContractValidationError(Exception):
    """Raised when a queue name has no matching YAML contract."""


def _load_queue_names(messages_dir: str) -> dict[str, Path]:
    """Scan all YAML contracts and return {queue_name: yaml_path}."""
    result: dict[str, Path] = {}
    msg_path = Path(messages_dir)
    if not msg_path.is_dir():
        logger.warning("Contract messages directory not found: %s", messages_dir)
        return result

    for yaml_file in msg_path.glob("*.yaml"):
        try:
            with open(yaml_file) as f:
                doc = yaml.safe_load(f)
            if isinstance(doc, dict) and "queue" in doc:
                result[doc["queue"]] = yaml_file
        except Exception:
            logger.debug("Skipping unparseable YAML: %s", yaml_file, exc_info=True)
    return result


def validate_queue_contract(
    queue_name: str,
    *,
    messages_dir: Optional[str] = None,
    strict: bool = False,
) -> bool:
    """Check that *queue_name* has a matching YAML contract.

    Args:
        queue_name: The BullMQ queue name the worker subscribes to.
        messages_dir: Override path to worker-backend/messages/.
        strict: If ``True``, raise :class:`ContractValidationError` on mismatch.

    Returns:
        ``True`` if a matching contract exists.
    """
    resolved_dir = messages_dir or _DEFAULT_MESSAGES_DIR
    contracts = _load_queue_names(resolved_dir)

    if queue_name in contracts:
        logger.debug(
            "Queue '%s' matches contract: %s",
            queue_name,
            contracts[queue_name].name,
        )
        return True

    msg = (
        f"Queue '{queue_name}' has no matching YAML contract in {resolved_dir}. "
        f"Available queues: {sorted(contracts.keys())[:10]}..."
    )

    if strict:
        raise ContractValidationError(msg)

    logger.warning(msg)
    return False
