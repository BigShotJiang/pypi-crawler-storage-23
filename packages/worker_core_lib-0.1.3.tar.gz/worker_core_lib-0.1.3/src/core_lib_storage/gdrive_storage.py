"""Google Drive storage provider using the Google API Python client.

Supports download, upload, and shareable link generation for Google Drive files.
"""

import asyncio
import io
import logging
from pathlib import Path
from typing import Any, Optional

from .base_storage import BaseStorage

logger = logging.getLogger(__name__)


class GoogleDriveStorage(BaseStorage):
    """Google Drive storage provider.

    Uses the Google Drive API v3 via google-api-python-client.
    Requires valid OAuth2 credentials with Drive scope.

    Args:
        access_token: OAuth2 access token.
        refresh_token: OAuth2 refresh token (for auto-refresh).
        client_id: Google OAuth client ID.
        client_secret: Google OAuth client secret.
    """

    def __init__(
        self,
        access_token: str,
        refresh_token: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
    ):
        self._access_token = access_token
        self._refresh_token = refresh_token
        self._client_id = client_id
        self._client_secret = client_secret
        self._service: Any = None

        logger.info("GoogleDriveStorage initialized")

    def _get_service(self) -> Any:
        """Build or return cached Google Drive service."""
        if self._service is not None:
            return self._service

        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build

        creds = Credentials(
            token=self._access_token,
            refresh_token=self._refresh_token,
            client_id=self._client_id,
            client_secret=self._client_secret,
            token_uri="https://oauth2.googleapis.com/token",
        )

        self._service = build("drive", "v3", credentials=creds)
        return self._service

    async def download(self, uri: str, destination: Path) -> None:
        """Download a file from Google Drive.

        Args:
            uri: Google Drive file ID.
            destination: Local directory or file path. If a directory,
                the file's name is fetched from Drive metadata.
        """
        file_id = self._extract_file_id(uri)

        logger.info(
            "Downloading from Google Drive",
            extra={"file_id": file_id, "destination": str(destination)},
        )

        loop = asyncio.get_event_loop()

        def _do_download() -> Path:
            from googleapiclient.http import MediaIoBaseDownload

            service = self._get_service()

            # Get file metadata for name
            file_meta = service.files().get(
                fileId=file_id, fields="name,size,mimeType"
            ).execute()
            file_name = file_meta.get("name", file_id)

            if destination.is_dir():
                dest_file = destination / file_name
            else:
                dest_file = destination
                dest_file.parent.mkdir(parents=True, exist_ok=True)

            # Check if it's a Google Workspace file (Docs, Sheets, etc.)
            mime_type = file_meta.get("mimeType", "")
            if mime_type.startswith("application/vnd.google-apps."):
                # Export as appropriate format
                export_mime = self._get_export_mime(mime_type)
                request = service.files().export_media(
                    fileId=file_id, mimeType=export_mime
                )
            else:
                request = service.files().get_media(fileId=file_id)

            with open(dest_file, "wb") as f:
                downloader = MediaIoBaseDownload(f, request)
                done = False
                while not done:
                    _, done = downloader.next_chunk()

            return dest_file

        try:
            dest_file = await loop.run_in_executor(None, _do_download)
        except Exception as e:
            logger.error(
                "Google Drive download failed",
                extra={"file_id": file_id, "error": str(e)},
            )
            raise

        logger.info(
            "Google Drive download complete",
            extra={"file_id": file_id, "size_bytes": dest_file.stat().st_size},
        )

    async def upload(self, source: Path, uri: str) -> None:
        """Upload a local file to Google Drive.

        Args:
            source: Local file path.
            uri: Target folder ID in Google Drive. The file is uploaded
                into this folder with its original name.
        """
        folder_id = self._extract_file_id(uri) if uri else None

        logger.info(
            "Uploading to Google Drive",
            extra={"source": str(source), "folder_id": folder_id},
        )

        loop = asyncio.get_event_loop()

        def _do_upload() -> None:
            from googleapiclient.http import MediaFileUpload

            service = self._get_service()
            file_metadata: dict[str, Any] = {"name": source.name}
            if folder_id:
                file_metadata["parents"] = [folder_id]

            media = MediaFileUpload(str(source), resumable=True)
            service.files().create(
                body=file_metadata,
                media_body=media,
                fields="id",
            ).execute()

        try:
            await loop.run_in_executor(None, _do_upload)
        except Exception as e:
            logger.error(
                "Google Drive upload failed",
                extra={"source": str(source), "error": str(e)},
            )
            raise

        logger.info("Google Drive upload complete", extra={"source": str(source)})

    async def get_presigned_url(self, uri: str, expiration: int = 3600) -> str:
        """Generate a shareable link for a Google Drive file.

        Note: Google Drive does not support time-limited presigned URLs.
        This creates a reader-accessible link. Expiration is ignored.

        Args:
            uri: Google Drive file ID.
            expiration: Ignored for Google Drive.

        Returns:
            A direct download URL for the file.
        """
        file_id = self._extract_file_id(uri)

        logger.debug("Generating Google Drive download link", extra={"file_id": file_id})

        loop = asyncio.get_event_loop()

        def _get_link() -> str:
            service = self._get_service()
            # Try to set file permission to anyone with link can read
            try:
                service.permissions().create(
                    fileId=file_id,
                    body={"type": "anyone", "role": "reader"},
                ).execute()
            except Exception:
                logger.debug("Could not set permission, file may already be shared")

            return f"https://drive.google.com/uc?export=download&id={file_id}"

        return await loop.run_in_executor(None, _get_link)

    @staticmethod
    def _extract_file_id(uri: str) -> str:
        """Extract Google Drive file ID from various URI formats.

        Supports:
            - Raw file ID: '1a2b3c4d5e'
            - Drive URL: 'https://drive.google.com/file/d/1a2b3c4d5e/view'
            - Open URL: 'https://drive.google.com/open?id=1a2b3c4d5e'
        """
        if uri.startswith("https://drive.google.com"):
            if "/d/" in uri:
                return uri.split("/d/")[1].split("/")[0]
            if "id=" in uri:
                return uri.split("id=")[1].split("&")[0]
        return uri

    @staticmethod
    def _get_export_mime(google_mime: str) -> str:
        """Map Google Workspace MIME types to export formats."""
        export_map = {
            "application/vnd.google-apps.document": "application/pdf",
            "application/vnd.google-apps.spreadsheet": "text/csv",
            "application/vnd.google-apps.presentation": "application/pdf",
            "application/vnd.google-apps.drawing": "image/png",
        }
        return export_map.get(google_mime, "application/pdf")
