# lexer

> Adapted from the Rust lexer.
