-- missing comma
create index i on t (a nulls first b nulls first);
