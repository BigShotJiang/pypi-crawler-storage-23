def main() -> None:
    print("Hello from ggai!")
