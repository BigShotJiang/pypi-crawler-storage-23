"""
spanners
========

Auxjad's spanners.
"""
