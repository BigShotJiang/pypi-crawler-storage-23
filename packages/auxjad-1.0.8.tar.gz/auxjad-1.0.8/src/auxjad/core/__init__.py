"""
core
====

Auxjad's core classes for algorithmic manipulations: loopers, shufflers,
phasers, selectors, etc.
"""
