"""
utilities
=========

Auxjad's utility functions.
"""
