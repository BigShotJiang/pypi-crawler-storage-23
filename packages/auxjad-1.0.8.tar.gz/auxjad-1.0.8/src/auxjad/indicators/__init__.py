"""
indicators
==========

Auxjad's indicators.
"""
