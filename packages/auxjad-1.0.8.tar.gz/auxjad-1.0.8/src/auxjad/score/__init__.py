"""
score
=====

Auxjad's score component classes: leaf maker, artificial and natural harmonics.
"""
