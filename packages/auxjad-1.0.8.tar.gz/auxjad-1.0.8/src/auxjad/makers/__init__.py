"""
makers
======

Auxjad's leaf making classes.
"""
