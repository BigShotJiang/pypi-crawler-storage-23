---
type: person
status: active # active | inactive
name:
aliases: []
description: # One-liner role description
org: # Link to Org
role:
email:
phone:
related: []
relationships: []
created: "{{date}}"
tags: []
---

# {{title}}

## Decisions
![[person.base#Decisions]]

## Tasks
![[person.base#Tasks]]

## Projects
![[person.base#Projects]]

## Sessions
![[person.base#Sessions]]

## Learnings
![[person.base#Learnings]]

## Accounts
![[person.base#Accounts]]

## Assets
![[person.base#Assets]]

## Notes
![[person.base#Notes]]
