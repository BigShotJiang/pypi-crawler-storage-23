---
type: process
status: active # active | proposed | design | deprecated
name:
description:
owner: # Link to Person
frequency: # daily | weekly | fortnightly | monthly | as-needed
area:
depends_on: [] # [[prerequisite processes]]
governed_by: [] # [[regulatory/policy oversight — orgs, constraints]]
related: []
relationships: []
created: "{{date}}"
tags: []
---

# {{title}}

What this process does and why it exists.

## Steps

1. Step one
2. Step two
3. Step three

## Dependencies
![[process.base#Dependencies]]

## Runs
![[process.base#Runs]]

## Notes
![[process.base#Notes]]
