---
type: input
status: unprocessed
input_type: email
source: gmail
received: "{{date}}"
created: "{{date}}"
from:
from_raw:
conversation:
message_id:
in_reply_to:
references: []
project:
alfred_instructions:
related: []
relationships: []
tags: []
---

# {{title}}

Body content here.

## Related
![[related.base#All]]
