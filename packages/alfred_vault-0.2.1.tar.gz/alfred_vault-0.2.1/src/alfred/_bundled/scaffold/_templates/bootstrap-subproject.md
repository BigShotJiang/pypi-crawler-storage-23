---
type: task
status: todo
kind: task
name: Sub-Project Bootstrap
description: "Setup checklist for {{subproject}} — complete to fully initialise this phase/sub-project"
project: "[[project/{{subproject}}]]"
assigned:
priority: high
created: "{{date}}"
tags:
  - bootstrap
---

# Sub-Project Bootstrap — {{subproject}}

Complete this checklist to fully set up [[project/{{subproject}}]].

## Setup Checklist

- [ ] **Define phase deliverables** — What does this phase produce?
- [ ] **Identify dependencies** — What must happen before this phase can start/complete?
- [ ] **Assign owner** — Who drives this phase?
- [ ] **Create initial tasks** — Break into actionable work items.

## Outcome

*Filled on completion — sub-project is fully initialised.*
