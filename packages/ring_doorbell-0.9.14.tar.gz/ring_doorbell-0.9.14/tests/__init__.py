"""Tests for Ring Door Bell components."""
