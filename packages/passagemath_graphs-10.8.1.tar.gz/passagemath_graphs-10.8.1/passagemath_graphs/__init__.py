# sage_setup: distribution = sagemath-graphs

from sage.all__sagemath_graphs import *
