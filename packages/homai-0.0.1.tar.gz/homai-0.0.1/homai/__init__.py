"""Homai — Multi-agent AI teams for Jupyter."""
__version__ = "0.0.1"
