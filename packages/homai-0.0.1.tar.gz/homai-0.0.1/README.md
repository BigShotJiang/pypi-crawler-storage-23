# 🦅 Homai

**Multi-agent AI teams for Jupyter.**

Named after Homa (هما), the Persian mythological bird of fortune.

> Coming soon. Watch the repo: https://github.com/homai-ai/homai
