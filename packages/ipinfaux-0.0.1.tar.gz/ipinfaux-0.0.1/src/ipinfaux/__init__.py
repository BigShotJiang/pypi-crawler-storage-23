"""
ipinfaux - unofficial ipinfo scraper w/ login support
"""

from .lookup import GetFullData, GetJWTByLogin

__version__ = "0.0.1"
__all__ = ["GetFullData", "GetJWTByLogin"]