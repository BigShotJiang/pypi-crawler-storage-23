"""
ipinfaux - unofficial ipinfo scraper w/ login support
"""

import requests
import json
import re
import csv
from bs4 import BeautifulSoup
from urllib.parse import urlparse
import time
from io import StringIO


class GetFullData:
    """
    fetch full ip information from ipinfo.io
    
    usage:
        data = GetFullData(ip_address, jwt_token)
        print(data.summary)
        print(data.as_json())
    """
    
    def __init__(self, ip, jwt_token):
        """
        initialize and fetch data for the given ip
        
        args:
            ip (str): ip address to lookup
            jwt_token (str): jwt token for authentication
        """
        self.ip = ip
        self.jwt_token = jwt_token
        self.raw_data = None
        self.summary = {}
        self.geolocation = {}
        self.privacy = {}
        self.asn = {}
        self.abuse = {}
        self.domains = {}
        self.tags = {}
        self.other_providers = {}
        self.error = None
        
        self._fetch()
    
    def _fetch(self):
        """fetch and parse all information for the ip address"""
        # list of all possible tag ids
        self.tag_ids = [
        "airplane", "airport", "anycast", "bittorrent", "cdn", "cloud",
        "crawler", "geodns", "hosting", "hotel", "hotspot", "ix",
        "mailserver", "mobile", "nameserver", "portscan", "proxy",
        "relay", "router", "satellite", "ssh", "tor", "vpn", "webserver",
        "bus_station", "conference_center", "coworking_space", "in_transit",
        "library", "sports_center", "stadium", "subway_station", "train_station"
        ] # so many useless tags but oh well
        
        url = f"https://ipinfo.io/{self.ip}"
        
        # create session with jwt token
        session = requests.Session()
        session.cookies.set('jwt-express', self.jwt_token)
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', # it'll do
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        })
        
        try:
            response = session.get(url, timeout=10)
            response.raise_for_status()
            
            # check if we got a login page
            if 'signup' in response.text.lower() or 'login' in response.text.lower():
                fresh_token = GetJWTByLogin.get_fresh_token()
                if fresh_token:
                    session.cookies.set('jwt-express', fresh_token)
                    response = session.get(url, timeout=10)
            
            # parse the html
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # extract all data sections
            self.summary = self._parse_summary(soup)
            self.geolocation = self._parse_geolocation(soup)
            self.privacy = self._parse_privacy(soup)
            self.asn = self._parse_asn(soup)
            self.abuse = self._parse_abuse(soup)
            self.domains = self._parse_domains(soup)
            self.tags = self._parse_tags(soup)
            self.other_providers = self._parse_other_providers(soup)
            
            # store raw data
            self.raw_data = {
                "ip": self.ip,
                "summary": self.summary,
                "geolocation": self.geolocation,
                "privacy": self.privacy,
                "asn": self.asn,
                "abuse": self.abuse,
                "domains": self.domains,
                "tags": self.tags,
                "other_providers": self.other_providers
            }
            
        except requests.exceptions.RequestException as e:
            self.error = f"request failed: {e}"
            self.raw_data = {"ip": self.ip, "error": self.error}
        except Exception as e:
            self.error = f"parsing failed: {e}"
            self.raw_data = {"ip": self.ip, "error": self.error}
    
    def _parse_other_providers(self, soup):
        """parse the 'other providers' accuracy callout section"""
        result = {
            "exists": False,
            "city": None,
            "state": None,
            "country_code": None,
            "distance_km": None,
            "distance_text": None,
            "full_text": None
        }
        
        accuracy_div = soup.find('div', id='accuracy-callout')
        if not accuracy_div:
            return result
        
        p_tag = accuracy_div.find('p', class_='font-bold mb-0')
        if not p_tag:
            return result
        
        text = p_tag.get_text(strip=True)
        result["full_text"] = text
        result["exists"] = True
        
        # extract: "in City, State, CC, X,XXX.X kms away"
        pattern = r'in\s+([^,]+),\s+([^,]+),\s+([A-Z]{2}),\s+([\d,]+\.?\d*)\s+kms?\s+away'
        match = re.search(pattern, text)
        
        if match:
            city, state, country_code, distance = match.groups()
            result["city"] = city.strip()
            result["state"] = state.strip()
            result["country_code"] = country_code.strip()
            
            clean_distance = distance.replace(',', '')
            try:
                result["distance_km"] = float(clean_distance)
            except ValueError:
                result["distance_km"] = None
            
            result["distance_text"] = distance
        
        return result
    
    def _parse_summary(self, soup):
        """parse the summary section"""
        summary = {}
        
        # find the summary card
        summary_card = None
        headers = soup.find_all('h2', class_='h4')
        for header in headers:
            if 'Summary' in header.text:
                summary_card = header.find_parent('div', class_='card')
                break
        
        if not summary_card:
            return summary
        
        # find the table
        table = summary_card.find('table', class_='table')
        if not table:
            return summary
        
        rows = table.find_all('tr')
        for row in rows:
            cells = row.find_all('td')
            if len(cells) >= 2:
                label = cells[0].get_text(strip=True)
                value_cell = cells[1]
                
                if 'ASN' in label and 'ASN type' not in label:
                    asn_link = value_cell.find('a')
                    if asn_link:
                        summary['asn'] = asn_link.text.strip()
                    
                    rpki_popover = value_cell.find('span', class_='rpki-popover')
                    summary['rpki'] = rpki_popover is not None
                    
                    asn_text = value_cell.get_text(strip=True)
                    asn_part = summary.get('asn', '')
                    if asn_part:
                        asn_text = asn_text.replace(asn_part, '', 1).strip()
                    
                    if '-' in asn_text:
                        summary['asn_name'] = asn_text.split('-', 1)[1].strip()
                    elif asn_text:
                        summary['asn_name'] = asn_text
                
                elif 'Hostname' in label:
                    summary['hostname'] = value_cell.get_text(strip=True)
                elif 'Range' in label:
                    range_link = value_cell.find('a')
                    if range_link:
                        summary['range'] = range_link.text.strip()
                elif 'Company' in label:
                    summary['company'] = value_cell.get_text(strip=True)
                elif 'Hosted domains' in label:
                    domain_text = value_cell.get_text(strip=True)
                    domain_count = re.sub(r'[^\d]', '', domain_text)
                    summary['hosted_domains_count'] = int(domain_count) if domain_count else 0
                elif 'Privacy' in label:
                    img = value_cell.find('img')
                    summary['privacy'] = img and 'right-big' in img.get('src', '')
                elif 'Anycast' in label:
                    img = value_cell.find('img')
                    summary['anycast'] = img and 'right-big' in img.get('src', '')
                    
                    anycast_span = value_cell.find('span', class_='text-popover')
                    if anycast_span:
                        anycast_text = anycast_span.get('data-content', '')
                        countries_match = re.search(r'(\d+)\s+countries?', anycast_text)
                        cities_match = re.search(r'(\d+)\s+cities?', anycast_text)
                        
                        if countries_match:
                            summary['anycast_countries'] = int(countries_match.group(1))
                        if cities_match:
                            summary['anycast_cities'] = int(cities_match.group(1))
                elif 'ASN type' in label:
                    summary['asn_type'] = value_cell.get_text(strip=True).lower()
                elif 'Abuse contact' in label:
                    abuse_link = value_cell.find('a')
                    if abuse_link and abuse_link.get('href', '').startswith('mailto:'):
                        summary['abuse_email'] = abuse_link.get('href').replace('mailto:', '')
        
        return summary
    
    def _parse_geolocation(self, soup):
        """parse the geolocation section"""
        geo = {}
        
        geo_table = soup.find('table', class_='geo-table')
        if not geo_table:
            return geo
        
        rows = geo_table.find_all('tr')
        for row in rows:
            cells = row.find_all('td')
            if len(cells) >= 2:
                label = cells[0].get_text(strip=True)
                value_cell = cells[1]
                value = value_cell.get_text(strip=True)
                
                if 'City' in label:
                    geo['city'] = value
                elif 'State' in label:
                    geo['state'] = value
                elif 'Country' in label:
                    geo['country'] = value
                    country_link = value_cell.find('a')
                    if country_link and country_link.get('href'):
                        country_code = country_link.get('href').replace('/countries/', '')
                        geo['country_code'] = country_code
                elif 'Postal' in label:
                    geo['postal'] = value
                elif 'Timezone' in label:
                    geo['timezone'] = value
                elif 'Coordinates' in label:
                    coord_parts = value.split(',')
                    if len(coord_parts) == 2:
                        lat_part = coord_parts[0].strip()
                        lon_part = coord_parts[1].strip()
                        
                        lat_match = re.search(r'([\d.]+)', lat_part)
                        lon_match = re.search(r'([\d.]+)', lon_part)
                        
                        if lat_match and lon_match:
                            lat = float(lat_match.group(1))
                            lon = float(lon_match.group(1))
                            
                            if 'S' in lat_part:
                                lat = -lat
                            if 'W' in lon_part:
                                lon = -lon
                            
                            geo['latitude'] = lat
                            geo['longitude'] = lon
        
        return geo
    
    def _parse_privacy(self, soup):
        """parse the privacy detection section"""
        privacy = {
            "hosting": False,
            "vpn": False,
            "proxy": False,
            "tor": False,
            "relay": False,
            "residential_proxy": False,
            "details": {}
        }
        
        privacy_headers = soup.find_all('h2', class_='h4')
        privacy_card = None
        for header in privacy_headers:
            if 'Privacy Detection' in header.text:
                privacy_card = header.find_parent('div', class_='card')
                break
        
        if not privacy_card:
            return privacy
        
        detected_cards = privacy_card.find_all('div', class_='privacy-card-detected')
        for card in detected_cards:
            aria_label = card.get('aria-label', '')
            h3 = card.find('h3')
            
            if h3:
                privacy_type = h3.get_text(strip=True).lower().replace(' ', '_')
            elif 'Detected' in aria_label:
                privacy_type = aria_label.replace('Detected', '').strip().lower().replace(' ', '_')
            else:
                continue
            
            if privacy_type in privacy:
                privacy[privacy_type] = True
            
            subtitle = card.find('p', class_='privacy-card-subtitle')
            if subtitle:
                subtitle_text = subtitle.get_text(strip=True)
                if privacy_type not in privacy['details']:
                    privacy['details'][privacy_type] = {}
                
                provider_match = re.match(r'([^•]+)', subtitle_text)
                if provider_match:
                    privacy['details'][privacy_type]['provider'] = provider_match.group(1).strip()
                
                last_seen_match = re.search(r'Last seen:\s*([^•]+)', subtitle_text)
                if last_seen_match:
                    privacy['details'][privacy_type]['last_seen'] = last_seen_match.group(1).strip()
                
                percent_match = re.search(r'(\d+)%', subtitle_text)
                if percent_match:
                    privacy['details'][privacy_type]['activity_percent'] = int(percent_match.group(1))
        
        return privacy
    
    def _parse_asn(self, soup):
        """parse the asn section"""
        asn_data = {}
        
        asn_headers = soup.find_all('h2', class_='h4')
        asn_card = None
        for header in asn_headers:
            if header.text.strip() == 'ASN':
                asn_card = header.find_parent('div', class_='card')
                break
        
        if not asn_card:
            return asn_data
        
        strong_tag = asn_card.find('strong', class_='font-size-26')
        if strong_tag:
            asn_link = strong_tag.find('a')
            if asn_link:
                asn_href = asn_link.get('href', '')
                asn_data['asn'] = asn_href.replace('/AS', '') if '/AS' in asn_href else asn_href
                
                strong_text = strong_tag.get_text(strip=True)
                if '-' in strong_text:
                    asn_data['asn_name'] = strong_text.split('-', 1)[1].strip()
        
        columns = asn_card.find_all('div', class_='col-sm')
        for col in columns:
            h6 = col.find('h6', class_='uppercase-small-title')
            if not h6:
                continue
            
            title = h6.get_text(strip=True).lower()
            span = col.find('span')
            if not span:
                continue
            
            if 'domain' in title:
                asn_data['domain'] = span.get_text(strip=True)
            elif 'asn type' in title:
                asn_data['asn_type'] = span.get_text(strip=True).lower()
            elif 'route' in title:
                route_link = span.find('a')
                if route_link:
                    asn_data['route'] = route_link.get_text(strip=True)
                else:
                    asn_data['route'] = span.get_text(strip=True)
        
        return asn_data
    
    def _parse_abuse(self, soup):
        """parse the abuse contact section"""
        abuse = {}
        
        abuse_headers = soup.find_all('h2', class_='h4')
        abuse_card = None
        for header in abuse_headers:
            if 'Abuse Details' in header.text:
                abuse_card = header.find_parent('div', class_='card')
                break
        
        if not abuse_card:
            return abuse
        
        contact_divs = abuse_card.find_all('div', class_='my-2')
        for div in contact_divs:
            img = div.find('img')
            if not img:
                continue
            
            img_src = img.get('src', '')
            
            if 'place.svg' in img_src:
                abuse['address'] = div.get_text(strip=True).replace('US, CA,', '').strip()
            elif 'phone.svg' in img_src:
                phone_text = div.get_text(strip=True)
                phone_match = re.search(r'([\+\d\-]+)', phone_text)
                if phone_match:
                    abuse['phone'] = phone_match.group(1)
            elif 'mail.svg' in img_src:
                email_link = div.find('a')
                if email_link and email_link.get('href', '').startswith('mailto:'):
                    abuse['email'] = email_link.get('href').replace('mailto:', '')
        
        info_table = abuse_card.find('div', class_='info-table')
        if info_table:
            cols = info_table.find_all('div', class_='col-lg-6')
            for col in cols:
                title_div = col.find('div', class_='title')
                if not title_div:
                    continue
                
                title = title_div.get_text(strip=True).lower()
                value_div = col.find_all('div')[-1]
                
                if 'name' in title:
                    abuse['name'] = value_div.get_text(strip=True)
                elif 'network' in title:
                    abuse['network'] = value_div.get_text(strip=True)
        
        return abuse
    
    def _parse_domains(self, soup):
        """parse the hosted domains section"""
        domains = {
            "count": 0,
            "domains": []
        }
        
        domains_headers = soup.find_all('h2', class_='h4')
        domains_card = None
        for header in domains_headers:
            if 'Hosted Domains' in header.text:
                domains_card = header.find_parent('div', class_='card')
                break
        
        if not domains_card:
            return domains
        
        restricted = domains_card.find('div', class_='restricted-feature')
        if restricted and restricted.get('data-is-restricted') == 'true':
            domains["restricted"] = True
            return domains
        
        restricted_element = domains_card.find('div', class_='restricted-element')
        if restricted_element:
            domain_links = restricted_element.find_all('a')
            for link in domain_links:
                href = link.get('href', '')
                if 'host.io/' in href:
                    domain = href.replace('https://host.io/', '').replace('http://host.io/', '')
                    domains['domains'].append(domain)
        
        domains['count'] = len(domains['domains'])
        
        return domains
    
    def _parse_tags(self, soup):
        """parse tags from the html"""
        tags = {tag_id: False for tag_id in self.tag_ids}
        
        img_tags = soup.find_all('img')
        
        for img in img_tags:
            src = img.get('src', '')
            
            if 'website-cdn.assets.ipinfo.io/tags/' in src or 'cdn.assets.ipinfo.io/tags/' in src:
                match = re.search(r'/tags/([a-zA-Z0-9_-]+)\.svg', src)
                if match:
                    tag_id = match.group(1).lower()
                    if tag_id in tags:
                        tags[tag_id] = True
        
        return tags
    
    def as_dict(self):
        """return the data as a dictionary"""
        return self.raw_data
    
    def as_json(self, indent=2):
        """return the data as a json string"""
        return json.dumps(self.raw_data, indent=indent, ensure_ascii=False)
    
    def save(self, filename=None):
        """save the data to a json file"""
        if not filename:
            filename = f"ipinfo_{self.ip}.json"
        
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(self.raw_data, f, indent=2, ensure_ascii=False)
            return filename
        except IOError as e:
            self.error = f"failed to save file: {e}"
            return None
    
    def as_csv(self, include_headers=True, delimiter=','):
        """return the data as a csv string"""
        output = StringIO()
        writer = csv.writer(output, delimiter=delimiter)
        
        flat_data = self._flatten_dict(self.raw_data)
        
        if include_headers:
            writer.writerow(flat_data.keys())
        
        writer.writerow(flat_data.values())
        
        return output.getvalue()
    
    def save_csv(self, filename=None, include_headers=True, delimiter=','):
        """save the data as a csv file"""
        if not filename:
            filename = f"ipinfo_{self.ip}.csv"
        
        try:
            with open(filename, 'w', encoding='utf-8', newline='') as f:
                writer = csv.writer(f, delimiter=delimiter)
                
                flat_data = self._flatten_dict(self.raw_data)
                
                if include_headers:
                    writer.writerow(flat_data.keys())
                
                writer.writerow(flat_data.values())
            
            return filename
        except IOError as e:
            self.error = f"failed to save csv: {e}"
            return None
    
    def _flatten_dict(self, d, parent_key='', sep='.'):
        """recursively flatten a nested dictionary"""
        items = []
        for k, v in d.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            
            if isinstance(v, dict):
                items.extend(self._flatten_dict(v, new_key, sep=sep).items())
            elif isinstance(v, list):
                items.append((new_key, json.dumps(v)))
            else:
                items.append((new_key, v))
        
        return dict(items)


class GetJWTByLogin:
    """
    get jwt token by logging into ipinfo.io
    
    usage:
        jwt = GetJWTByLogin(email, password, proxy_url=None)
        jwt = GetJWTByLogin.login(email, password, proxy_url=None)
    """
    
    def __init__(self, email, password, proxy_url=None):
        """
        initialize and get jwt token
        
        args:
            email (str): email address for login
            password (str): password for login
            proxy_url (str, optional): proxy url (e.g., 'http://proxy:8080')
        """
        self.email = email
        self.password = password
        self.proxy_url = proxy_url
        self.token = None
        self.error = None
        self._login()
    
    def _login(self):
        """internal method to perform login"""
        result = self.login(self.email, self.password, self.proxy_url)
        if isinstance(result, str):
            self.token = result
        else:
            self.error = result
    
    def __str__(self):
        """return the token when converted to string"""
        return self.token if self.token else ""
    
    def __repr__(self):
        """return representation"""
        return f"GetJWTByLogin(token='{self.token}')"
    
    @staticmethod
    def login(email, password, proxy_url=None):
        """
        login to ipinfo.io and return the jwt token
        
        args:
            email (str): email address for login
            password (str): password for login
            proxy_url (str, optional): proxy url
        
        returns:
            str: jwt token if successful, None otherwise
        """
        session = requests.Session()
        
        proxies = None
        if proxy_url:
            proxies = {
                'http': proxy_url,
                'https': proxy_url
            }
        
        url = 'https://ipinfo.io/account/login'
        
        headers = {
            'accept': '*/*',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8,fr;q=0.7',
            'cache-control': 'no-cache',
            'content-type': 'application/json',
            'origin': 'https://ipinfo.io',
            'pragma': 'no-cache',
            'referer': 'https://ipinfo.io/login',
            'user-agent': 'Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36'
        }
        
        data = {
            'email': email,
            'password': password
        }
        
        try:
            response = session.post(url, headers=headers, json=data, proxies=proxies, timeout=30)
            response.raise_for_status()
            
            for cookie in session.cookies:
                if cookie.name == 'jwt-express':
                    return cookie.value
            
            return None
                
        except requests.exceptions.RequestException:
            return None
    
    @staticmethod
    def get_fresh_token():
        """attempt to get a fresh jwt token from firebase"""
        try:
            firebase_url = "https://acc-gen-cc81e-default-rtdb.firebaseio.com/jwts/current/.json"
            response = requests.get(firebase_url, timeout=5)
            if response.status_code == 200:
                data = response.json()
                if data and 'jwt' in data:
                    return data['jwt']
            return None
        except:
            return None


# for backwards compatibility
GetFullData = GetFullData