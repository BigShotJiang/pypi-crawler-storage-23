# ipinfaux

Unofficial ipinfo.io scraper. Gets IP data using a JWT token.

## install

```bash
pip install ipinfaux
```

## quick start

### get a jwt token (login)

```python
from ipinfaux import GetJWTByLogin

# login with email/password
jwt = GetJWTByLogin.login("your@email.com", "yourpassword")

# or with a proxy
jwt = GetJWTByLogin.login("your@email.com", "yourpassword", "http://proxy:8080")
```

### lookup an ip

```python
from ipinfaux import GetFullData

# use your jwt token
data = GetFullData("8.8.8.8", "your-jwt-token")

# check if it worked
if data.error:
    print(f"failed: {data.error}")
else:
    # access data
    print(data.summary)
    print(data.geolocation)
    print(data.privacy)
```

## examples

### get data as json

```python
data = GetFullData("1.1.1.1", jwt)
print(data.as_json())     # print json
data.save()               # save to ipinfo_1.1.1.1.json
data.save("custom.json")  # save to custom file
```

### get data as csv

```python
data = GetFullData("8.8.8.8", jwt)
print(data.as_csv())      # print csv
data.save_csv()           # save to ipinfo_8.8.8.8.csv
data.save_csv("data.csv", delimiter=",")
```

### multiple ips

```python
ips = ["8.8.8.8", "1.1.1.1", "9.9.9.9"]
results = []

for ip in ips:
    data = GetFullData(ip, jwt)
    if not data.error:
        results.append(data)
        print(f"{ip}: {data.geolocation.get('city')}")

# save all to one csv
if results:
    results[0].save_csv_batch(results, "all_ips.csv")
```

## data structure

```json
{
  "ip": "8.8.8.8",
  "summary": {
    "asn": "AS15169",
    "rpki": true,
    "asn_name": "Google LLC",
    "hostname": "dns.google",
    "range": "8.8.8.0/24",
    "company": "Google LLC",
    "hosted_domains_count": 20572,
    "privacy": true,
    "anycast": true,
    "asn_type": "hosting",
    "abuse_email": "network-abuse@google.com"
  },
  "geolocation": {
    "city": "Mountain View",
    "state": "California",
    "country": "United States",
    "country_code": "us",
    "postal": "94043",
    "timezone": "America/Los_Angeles",
    "latitude": 37.4056,
    "longitude": -122.0775
  },
  "privacy": {
    "hosting": true,
    "vpn": false,
    "proxy": false,
    "tor": false,
    "relay": false,
    "residential_proxy": false,
    "details": {}
  },
  "asn": {
    "asn": "15169",
    "asn_name": "Google LLC",
    "domain": "google.com",
    "asn_type": "hosting"
  },
  "abuse": {
    "address": "Mountain View, 1600 Amphitheatre Parkway, 94043",
    "phone": "+1-650-253-0000",
    "email": "network-abuse@google.com",
    "name": "Abuse",
    "network": "8.8.8.0/24"
  },
  "domains": {
    "count": 15,
    "domains": [
      "hdchina.org",
      "55188.com",
      "ymck.me",
      "ymjump.com",
      "musicool.cn",
      "viewpointcloud.com",
      "itempurl.com",
      "authrock.com",
      "gbwhatspro.com",
      "epicloud.link",
      "btempurl.com",
      "mysapo.vn",
      "everincloud.com",
      "farglory-hotel.com.tw",
      "raptorx.co"
    ]
  },
  "tags": {
    "airplane": false,
    "airport": false,
    "anycast": true,
    "bittorrent": false,
    "cdn": true,
    "cloud": false,
    "crawler": false,
    "geodns": false,
    "hosting": true,
    "hotel": false,
    "hotspot": false,
    "ix": false,
    "mailserver": false,
    "mobile": false,
    "nameserver": false,
    "portscan": false,
    "proxy": false,
    "relay": false,
    "router": false,
    "satellite": false,
    "ssh": false,
    "tor": false,
    "vpn": false,
    "webserver": true,
    "bus_station": false,
    "conference_center": false,
    "coworking_space": false,
    "in_transit": false,
    "library": false,
    "sports_center": false,
    "stadium": false,
    "subway_station": false,
    "train_station": false
  },
  "other_providers": {
    "exists": false,
    "city": null,
    "state": null,
    "country_code": null,
    "distance_km": null,
    "distance_text": null,
    "full_text": null
  }
}
```

## fields explained

- **summary** - basic ip info (asn, hostname, company)
- **geolocation** - where the ip is located
- **privacy** - if ip is vpn/proxy/tor etc
- **asn** - autonomous system details
- **abuse** - who to contact for abuse
- **domains** - domains hosted on this ip
- **tags** - what kind of ip it is (cdn, hosting, etc)
- **other_providers** - only applicable if ipinfo thinks its wrong, shows what maxmind thinks

## requirements

- python 3.7+
- requests
- beautifulsoup4

## license

mit
