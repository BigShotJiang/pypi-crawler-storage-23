# Модели данных (SQLAlchemy)

Модели хранятся в доменном слое по пути:

```
src/domain/<сущность>/model.py
```

У **каждой** модели в конце имени обязательно используется суффикс **Model**:

- `UserModel`

Используйте современный декларативный стиль с **`Mapped`** и **`mapped_column`**:

- **`Mapped[тип]`** — аннотация атрибута для типизации и декларативного описания колонки.
- **`mapped_column(...)`** — объявление колонки (тип, ключи, индексы, значения по умолчанию и т.д.).

**Колонки-фабрики:**
- Общие (`uuid_column`, `enum_column`) — из `tp_common.model.columns`.
- Для каждого enum — своя обёртка в домене:

```
src/domain/shared/columns/{название группы (ресураса) или общая }.py
```

Обёртка вызывает `enum_column(EnumType, "name_in_db", ...)`:

```python
from sqlalchemy.orm import Mapped

from tp_common.model.columns import enum_column

def event_group_column(
    *,
    nullable: bool = False,
    index: bool = True,
    primary_key: bool = False,
    unique: bool = False,
) -> Mapped[EventGroup]:
    return enum_column(
        EventGroup, "event_group",
        nullable=nullable, index=index, primary_key=primary_key, unique=unique,
    )
```

В моделях: общие колонки (`uuid_column` и др.) — из `tp_common.model.columns`, enum-колонки — из `src.domain.shared.columns`.
