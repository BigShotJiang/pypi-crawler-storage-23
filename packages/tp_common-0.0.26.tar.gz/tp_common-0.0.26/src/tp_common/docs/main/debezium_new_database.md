# Подключение новой БД к Debezium (PostgreSQL)

Краткая инструкция: что сделать, чтобы Debezium начал слать события из **новой** базы на том же PostgreSQL-сервере.

---

## 1. В PostgreSQL (новая БД)

### 1.1. Права пользователя репликации

Роль с репликацией (например `debezium_repl`) должна иметь доступ к новой БД и право читать таблицы:

```sql
-- от суперпользователя
GRANT CONNECT ON DATABASE "имя_новой_базы" TO debezium_repl;
\c "имя_новой_базы"
GRANT USAGE ON SCHEMA public TO debezium_repl;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO debezium_repl;
```

### 1.2. Публикация

Создать публикацию **в этой же новой БД** (не в `postgres`):

```sql
\c "имя_новой_базы"
CREATE PUBLICATION dbz_publication FOR ALL TABLES;
```

Для части таблиц:

```sql
CREATE PUBLICATION dbz_publication FOR TABLE public.table1, public.table2;
```

### 1.3. REPLICA IDENTITY FULL (опционально)

По умолчанию PostgreSQL в logical replication отдаёт в `before` только первичный ключ. Debezium тогда кладёт в `before` только ключ, в `after` — всю новую строку.

Чтобы в `before` были **все столбцы** старой строки, в базе выполнить для каждой нужной таблицы:

```sql
ALTER TABLE public.имя_таблицы REPLICA IDENTITY FULL;
```

Пример для таблицы `test`:

```sql
ALTER TABLE public.test REPLICA IDENTITY FULL;
```

Для всех таблиц схемы `public` (скрипт):

```sql
DO $$
DECLARE r RECORD;
BEGIN
  FOR r IN (SELECT tablename FROM pg_tables WHERE schemaname = 'public')
  LOOP
    EXECUTE format('ALTER TABLE public.%I REPLICA IDENTITY FULL', r.tablename);
  END LOOP;
END $$;
```

**Минус:** дополнительная нагрузка — больше данных в WAL, по репликации и в событиях Kafka (трафик и объём топиков). **Плюс:** в Kafka есть полное «до» и «после» для сравнения и аудита.

### 1.4. Проверка

- Публикация в нужной БД:  
  `SELECT pubname, puballtables FROM pg_publication WHERE pubname = 'dbz_publication';`
- После запуска коннектора слот должен быть активен:  
  `SELECT slot_name, active FROM pg_replication_slots WHERE slot_name = '...';`  
  У работающего коннектора `active = true`.

---

## 2. В Kafka Connect (новый коннектор)

### 2.1. Взять конфиг работающего коннектора

Например, с уже работающего коннектора для другой БД:

```bash
curl -s http://127.0.0.1:8083/connectors/debezium-connector-pg-61/config
```

### 2.2. В новом конфиге изменить только

| Параметр | Значение |
|----------|----------|
| `name` | Уникальное имя, например `debezium-connector-<короткое_имя_базы>` |
| `database.dbname` | Имя новой БД |
| `slot.name` | Уникальный слот, например `debezium_<короткое_имя_базы>` |
| `transforms.topicRouting.topic.replacement` | Префикс топиков, например `$1.<короткое_имя_базы>.$2.$3` |

### 2.3. Не менять способ подключения к PostgreSQL

- **database.hostname** — оставить таким же, как у работающего коннектора (например **192.168.81.61**; не переключать на 127.0.0.1).
- Остальное (пользователь, пароль, порт, `publication.name`, трансформы) — как у работающего коннектора.

### 2.4. Создать коннектор

```bash
curl -s -X POST -H "Content-Type: application/json" \
  --data @config-new-db.json \
  http://127.0.0.1:8083/connectors
```

### 2.5. При необходимости — перезапуск

```bash
curl -X POST http://127.0.0.1:8083/connectors/debezium-connector-<имя>/restart
```

---

## 3. Чеклист

1. В новой БД: `GRANT CONNECT` и права на `public` для пользователя репликации.
2. В новой БД: `CREATE PUBLICATION dbz_publication FOR ALL TABLES;`
3. Новый коннектор в Connect: своё имя, своя БД, свой слот, свой префикс топиков; хост/порт/пользователь/публикация — как у уже работающего коннектора.
4. Проверить слот: `active = true` в `pg_replication_slots`.
5. Топики будут вида: `events.<короткое_имя_базы>.public.<таблица>`.
