from __future__ import annotations

import argparse
from collections.abc import Iterable
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

"""
Скрипт для использования через curl в CI/CD других микросервисов.

Пример:

    curl -sSL "https://gitlab.8525.ru/modules/tp-common/-/raw/main/src/tp_common/devtools/sync_config_ms/sync_config_ms.py" -o sync_config_ms.py
    python sync_config_ms.py --target .

Скрипт:
1. Скачивает конфиги (ruff/mypy/pyright/.pre-commit-config.yaml/.gitignore) из директории
   sync_config_ms/configs репозитория tp-common. Если файл в целевом проекте уже есть — не перезаписывает.
2. Синхронизирует alembic-настройки: проверяет alembic/ в корне проекта, скачивает недостающие файлы
   (README, env.py, run.cmd, script.py.mako). env.py скачивается из env.py.example. Директория versions
   всегда создаётся, её содержимое не трогается.
3. Скачивает pyproject.toml из корня tp-common и выравнивает dev-зависимости в локальном pyproject.toml.
"""

BASE_URL = "https://gitlab.8525.ru/modules/tp-common/-/raw/main/"

# Директория с конфигами для других проектов (в корне — конфиги только для библиотеки tp-common).
CONFIGS_REL_PATH = "src/tp_common/devtools/sync_config_ms/configs"

CONFIG_FILES: tuple[str, ...] = (
    "ruff.toml",
    "mypy.ini",
    "pyrightconfig.json",
    ".pre-commit-config.yaml",
    ".gitignore",
)

# Файлы alembic (версии/ не трогаем). (источник, назначение): env.py.example хранится
# в репо как пример (не исполняемый вне проекта), при скачивании — в env.py
ALEMBIC_FILES: tuple[tuple[str, str], ...] = (
    ("README", "README"),
    ("env.py.example", "env.py"),
    ("run.cmd", "run.cmd"),
    ("script.py.mako", "script.py.mako"),
)

DEV_DEP_SECTION_HEADER = "[tool.poetry.group.dev.dependencies]"
DEV_DEP_KEYS: tuple[str, ...] = (
    "ruff",
    "pre-commit",
    "pylint",
    "mypy",
    "pyright",
    "black",
)


def _http_get_text(relative_path: str) -> str:
    url = f"{BASE_URL}{relative_path}"
    try:
        with urlopen(url) as resp:
            return resp.read().decode("utf-8")
    except URLError as exc:  # pragma: no cover - сетевые ошибки в рантайме CI
        msg = f"Не удалось скачать {relative_path!r} по URL {url!r}: {exc}"
        raise RuntimeError(msg) from exc


def _download_config_files(target_root: Path) -> None:
    for name in CONFIG_FILES:
        dst = target_root / name
        if dst.is_file():
            continue
        content = _http_get_text(f"{CONFIGS_REL_PATH}/{name}")
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_text(content, encoding="utf-8")


def _sync_alembic_config(target_root: Path) -> None:
    """Синхронизирует alembic-настройки. Файл за файлом: нет — скачать, есть — пропустить."""
    alembic_dir = target_root / "alembic"
    versions_dir = alembic_dir / "versions"

    alembic_dir.mkdir(parents=True, exist_ok=True)
    versions_dir.mkdir(parents=True, exist_ok=True)

    for source_name, dest_name in ALEMBIC_FILES:
        dst = alembic_dir / dest_name
        if dst.is_file():
            continue
        content = _http_get_text(f"{CONFIGS_REL_PATH}/alembic/{source_name}")
        dst.write_text(content, encoding="utf-8")


def _iter_section_lines(lines: list[str], start_index: int) -> tuple[int, int]:
    start = start_index + 1
    end = start
    for i in range(start, len(lines)):
        stripped = lines[i].lstrip()
        if stripped.startswith("[") and not stripped.startswith("#["):
            end = i
            break
    else:
        end = len(lines)
    return start, end


def _find_section_header(lines: list[str], header: str) -> int | None:
    for index, line in enumerate(lines):
        if line.strip() == header:
            return index
    return None


def _load_source_dev_dependency_lines_from_http() -> dict[str, str]:
    content = _http_get_text("pyproject.toml").splitlines()

    header_index = _find_section_header(content, DEV_DEP_SECTION_HEADER)
    if header_index is None:
        return {}

    start, end = _iter_section_lines(content, header_index)
    result: dict[str, str] = {}

    for line in content[start:end]:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        for key in DEV_DEP_KEYS:
            if stripped.startswith(f"{key} ") or stripped.startswith(f"{key}="):
                result[key] = line
                break

    return result


def _sync_target_pyproject_dev_deps(
    target_pyproject: Path,
    source_dev_deps: dict[str, str],
) -> None:
    if not target_pyproject.is_file():
        msg = f"pyproject.toml не найден по пути: {target_pyproject}"
        raise FileNotFoundError(msg)

    lines = target_pyproject.read_text(encoding="utf-8").splitlines()

    header_index = _find_section_header(lines, DEV_DEP_SECTION_HEADER)

    if header_index is None:
        new_lines: list[str] = []
        if lines and lines[-1].strip():
            new_lines.append("")
        new_lines.append(DEV_DEP_SECTION_HEADER)

        for key in DEV_DEP_KEYS:
            line = source_dev_deps.get(key)
            if line:
                new_lines.append(line)

        final_lines = new_lines if not lines else lines + [""] + new_lines

        target_pyproject.write_text("\n".join(final_lines) + "\n", encoding="utf-8")
        return

    start, end = _iter_section_lines(lines, header_index)

    def _find_key_line_index(
        key: str,
        search_range: Iterable[int],
    ) -> int | None:
        for i in search_range:
            stripped = lines[i].strip()
            if stripped.startswith(f"{key} ") or stripped.startswith(f"{key}="):
                return i
        return None

    insert_position = end

    for key in DEV_DEP_KEYS:
        source_line = source_dev_deps.get(key)
        if not source_line:
            continue

        existing_index = _find_key_line_index(key, range(start, end))
        if existing_index is not None:
            lines[existing_index] = source_line
        else:
            lines.insert(insert_position, source_line)
            insert_position += 1
            end += 1

    target_pyproject.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Скачать конфиги и dev-зависимости из tp-common и применить к текущему проекту."
        ),
    )
    parser.add_argument(
        "-t",
        "--target",
        type=Path,
        default=Path("."),
        help=(
            "Корень целевого проекта, в который нужно подтянуть конфиги. "
            "По умолчанию — текущая директория."
        ),
    )
    args = parser.parse_args()

    target_root = args.target.resolve()

    _download_config_files(target_root)
    _sync_alembic_config(target_root)

    source_dev_deps = _load_source_dev_dependency_lines_from_http()
    if not source_dev_deps:
        return

    target_pyproject = target_root / "pyproject.toml"
    _sync_target_pyproject_dev_deps(target_pyproject, source_dev_deps)


if __name__ == "__main__":  # pragma: no cover - точка входа для скрипта
    main()
