## tp_common.devtools — синхронизация CI/CD-конфигов

Этот модуль позволяет **другим микросервисам** автоматически подтягивать
единые настройки линтеров и инструментов разработки из репозитория `tp-common`.

### Что подтягивается из tp-common

Из директории `src/tp_common/devtools/sync_config_ms/configs` репозитория `tp-common`
скачиваются файлы (если в целевом проекте такого файла ещё нет — иначе он не перезаписывается):

- `ruff.toml`
- `mypy.ini`
- `pyrightconfig.json`
- `.pre-commit-config.yaml`
- `.gitignore`

Кроме того, из корневого `pyproject.toml` `tp-common` берутся версии пакетов
и синхронизируются в целевом проекте в секции
`[tool.poetry.group.dev.dependencies]`:

- `ruff`
- `pre-commit`
- `pylint`
- `mypy`
- `pyright`
- `black`

### Как микросервис стягивает конфиги

Рекомендуемый способ для CI/CD других микросервисов — **скачать готовый скрипт через `curl` и запустить его**.

1. В CI-джобе скачать скрипт из репозитория `tp-common`:

   ```bash
   curl -sSL "https://gitlab.8525.ru/modules/tp-common/-/raw/main/src/tp_common/devtools/sync_config_ms/sync_config_ms.py" -o sync_config_ms.py
   ```

2. Запустить скрипт, указав корень проекта (обычно `.`):

   ```bash
   python sync_config_ms.py --target .
   ```

Скрипт `sync_config_ms.py` сам скачает нужные конфиги и `pyproject.toml` из `tp-common`
и обновит локальные файлы целевого микросервиса.

### Пример использования в GitLab CI

Условный фрагмент `.gitlab-ci.yml` микросервиса:

```yaml
stages:
  - prepare
  - lint

prepare-devtools:
  stage: prepare
  image: python:3.12
  script:
    - curl -sSL "https://gitlab.8525.ru/modules/tp-common/-/raw/main/src/tp_common/devtools/sync_config_ms/sync_config_ms.py" -o sync_config_ms.py
    - python sync_config_ms.py --target .
  artifacts:
    paths:
      - ruff.toml
      - mypy.ini
      - pyrightconfig.json
      - .pre-commit-config.yaml
      - pyproject.toml

lint:
  stage: lint
  image: python:3.12
  needs: ["prepare-devtools"]
  script:
    - pip install poetry
    - poetry install
    - poetry run ruff check .
    - poetry run mypy .
```

### Поведение и ограничения

- Скрипт **не перезаписывает** уже существующие в целевом проекте конфиги: если файл есть,
  он не трогается. Скачиваются только отсутствующие файлы из `sync_config_ms/configs`.
- В `pyproject.toml` целевого проекта:
  - если секции `[tool.poetry.group.dev.dependencies]` нет — она будет создана;
  - для указанных библиотек (`ruff`, `pre-commit`, `pylint`, `mypy`, `pyright`, `black`)
    версии будут приведены к значениям из `tp-common`;
  - остальные dev-зависимости остаются без изменений.

Таким образом, все микросервисы могут **централизованно использовать единые версии**
линтеров и конфигов, просто вызывая `tp_common.devtools` в своих CI/CD-пайплайнах.

