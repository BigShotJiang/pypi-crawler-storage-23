from enum import Enum
from typing import TypeVar

from dplex.internal.sort import Order
from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel

itemsT = TypeVar("itemsT")
SortFieldT = TypeVar("SortFieldT", bound=Enum)


class BaseResponse(BaseModel):
    model_config = ConfigDict(
        alias_generator=to_camel,
        validate_by_name=True,
        validate_by_alias=True,
        serialize_by_alias=True,
    )


class BaseRequest(BaseModel):
    model_config = ConfigDict(
        alias_generator=to_camel,
        validate_by_name=True,
        validate_by_alias=True,
        serialize_by_alias=True,
        populate_by_name=True,
    )


class BaseQueryResponse[itemsT](BaseResponse):
    items: list[itemsT]
    total: int


class BaseQueryRequest[SortFieldT: Enum](BaseRequest):
    model_config = ConfigDict(use_enum_values=True)

    limit: int | None = Field(
        default=None,
        ge=1,
        le=300,
        description="Максимальное количество объектов в списке",
    )
    offset: int = Field(default=0, ge=0, description="Смещение от начала списка")
    sort: Order = Field(default=Order.DESC, description="Направление сортировки")

    sort_by: SortFieldT | None = Field(
        default=None,
        description="Поле сортировки (Enum, подставляется в наследнике)",
    )
