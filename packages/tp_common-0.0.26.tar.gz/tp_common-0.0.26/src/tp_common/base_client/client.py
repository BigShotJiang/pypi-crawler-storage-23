import asyncio
import json as json_lib
import logging
import time
from datetime import UTC, datetime
from typing import Any, Literal, TypeVar
from urllib.parse import urlencode

import aiohttp
from aiohttp import (
    ClientConnectionError,
    ClientConnectorDNSError,
    ClientHttpProxyError,
    ClientProxyConnectionError,
    ServerTimeoutError,
)

from tp_common.base_client.exceptions import (
    ClientConnectionException,
    ClientDNSException,
    ClientException,
    ClientProxyException,
    ClientResponseErrorException,
    ClientTimeoutException,
)

T = TypeVar("T", bound="BaseClient")


class BaseClient:
    """
    Базовый HTTP клиент для работы с внешними API.

    Поддерживает:
    - Переиспользование сессии
    - Прокси
    - Cookies
    - Имитацию браузера
    - Логирование (с автоматическим созданием логгера при необходимости)
    - Переопределение базового URL для тестирования

    Args:
        cookies: Строка с cookies в формате "name=value; name2=value2"
        proxy: URL прокси-сервера
        logger: Внешний логгер (если не передан, создается автоматически)
        base_url: Базовый URL для запросов (обязательный параметр)
    """

    DEFAULT_TIMEOUT = 30.0  # секунды

    def __init__(
        self,
        base_url: str,
        cookies: str | None = None,
        proxy: str | None = None,
        logger: logging.Logger | None = None,
    ):
        self._raw_cookies = cookies
        self._proxy: str | None = proxy
        self._session: aiohttp.ClientSession | None = None
        self._logger = logger or self._create_logger()
        self._base_url = base_url

    def _create_logger(self) -> logging.Logger:
        """Создает логгер на основе имени класса, если не передан внешний."""
        class_name = self.__class__.__name__
        module_name = self.__class__.__module__
        logger_name = f"{module_name}.{class_name}"
        return logging.getLogger(logger_name)

    @property
    def logger(self) -> logging.Logger:
        """Возвращает логгер для использования в наследниках."""
        return self._logger

    @logger.setter
    def logger(self, logger: logging.Logger) -> None:
        self._logger = logger

    async def __aenter__(self: T) -> T:
        """Инициализация сессии при входе в контекстный менеджер"""
        _ = await self._get_session()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Закрытие сессии при выходе из контекстного менеджера"""
        await self.close()

    async def _get_session(self) -> aiohttp.ClientSession:
        """Получает или создает переиспользуемую сессию"""
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=self.DEFAULT_TIMEOUT)
            connector = aiohttp.TCPConnector(limit=100, limit_per_host=30)

            self._session = aiohttp.ClientSession(
                timeout=timeout,
                connector=connector,
                cookies=self._prepare_cookies_dict(),
            )
        return self._session

    async def close(self) -> None:
        """Закрывает HTTP сессию"""
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None

    def _get_default_headers(self) -> dict[str, str]:
        """Возвращает заголовки по умолчанию для имитации браузера"""
        return {
            "accept": "*/*",
            "accept-language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
            "sec-ch-ua": '"Chromium";v="122"',
            "sec-ch-ua-mobile": "?0",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "referer": f"{self._base_url}/",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        }

    @property
    def cookies(self) -> str | None:
        """Возвращает текущие cookies"""
        return self._raw_cookies

    @cookies.setter
    def cookies(self, cookies: str) -> None:
        """Устанавливает новые cookies (требует пересоздания сессии)"""
        self._raw_cookies = cookies
        # Сразу обнуляем _session, чтобы следующий _get_session() создал новую сессию
        # с новыми cookies; старую сессию закрываем в фоне (иначе гонка: запрос
        # может получить уже закрываемую сессию → "Connector is closed")
        old_session = self._session
        self._session = None
        if old_session and not old_session.closed:

            async def _close_old() -> None:
                await old_session.close()

            asyncio.create_task(_close_old())

    @property
    def proxy(self) -> str | None:
        """Возвращает текущий прокси"""
        return self._proxy

    @proxy.setter
    def proxy(self, proxy: str) -> None:
        """Устанавливает новый прокси"""
        self._proxy = proxy

    def _prepare_cookies_dict(self) -> dict[str, str] | None:
        """Подготавливает словарь cookies из строки для aiohttp"""
        if not self._raw_cookies:
            return None

        cookies_dict: dict[str, str] = {}

        # Парсим строку cookies в формате "name=value; name2=value2"
        for cookie_str in self._raw_cookies.split(";"):
            cookie_str = cookie_str.strip()
            if not cookie_str:
                continue
            if "=" in cookie_str:
                name, value = cookie_str.split("=", 1)
                cookies_dict[name.strip()] = value.strip()

        return cookies_dict if cookies_dict else None

    def extract_cookies_from_session(self) -> str | None:
        """
        Извлекает cookies из текущей сессии в строку формата 'name=value; name2=value2'.

        Returns:
            Строка с кукисами в формате 'name=value; name2=value2' или None
        """
        if not self._session or self._session.closed:
            return self._raw_cookies

        cookies_list: list[str] = []
        for cookie in self._session.cookie_jar:
            cookies_list.append(f"{cookie.key}={cookie.value}")

        if not cookies_list:
            return self._raw_cookies

        return "; ".join(cookies_list)

    def _build_url(self, uri: str, params: str | dict[str, Any] | None = None) -> str:
        """Строит полный URL из базового адреса, URI и параметров"""
        url = f"{self._base_url}/{uri.lstrip('/')}"

        if params and isinstance(params, dict):
            # Фильтруем None значения и конвертируем все значения в строки для urlencode
            filtered_params: dict[str, str] = {}
            for key, val in params.items():
                if val is not None:
                    # Для datetime объектов используем ISO формат с Z и миллисекундами
                    if isinstance(val, datetime):
                        # Формат: 2026-01-20T00:00:00.000Z
                        # Если datetime имеет timezone, конвертируем в UTC, иначе используем как есть
                        if val.tzinfo is not None:
                            # Конвертируем в UTC
                            val_utc = val.astimezone(UTC)
                            filtered_params[key] = (
                                val_utc.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
                            )
                        else:
                            # Naive datetime - используем как есть и добавляем Z
                            filtered_params[key] = (
                                val.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
                            )
                    else:
                        filtered_params[key] = str(val)
            if filtered_params:
                # Используем urlencode для правильного кодирования параметров URL
                query_string = urlencode(filtered_params, doseq=False)
                url += "?" + query_string
        elif params and isinstance(params, str):
            url += f"?{params}"

        return url

    def _merge_headers(self, custom_headers: dict[str, Any] | None) -> dict[str, str]:
        """Объединяет заголовки по умолчанию с пользовательскими"""
        headers = self._get_default_headers()
        if custom_headers:
            headers.update(custom_headers)
        return headers

    def _prepare_payload(
        self, json: dict[str, Any] | None, data: Any | None
    ) -> dict[str, Any] | list[Any] | str | None:
        """Подготавливает payload для логирования"""
        if json is not None:
            return json
        if data is not None:
            if isinstance(data, str):
                try:
                    return json_lib.loads(data)
                except (json_lib.JSONDecodeError, TypeError):
                    return None
            elif isinstance(data, (dict, list)):
                return data
            return None
        return None

    def _prepare_response(self, response_text: str) -> dict[str, Any] | list[Any] | str:
        """Подготавливает response для логирования: пытается распарсить JSON, иначе возвращает текст"""
        if not response_text:
            return response_text
        try:
            return json_lib.loads(response_text)
        except (json_lib.JSONDecodeError, TypeError):
            return response_text

    def _decode_response_body(
        self, body_bytes: bytes, response: aiohttp.ClientResponse
    ) -> str:
        """
        Декодирует тело ответа в строку с учётом кодировки из заголовков
        и резервных кодировок при ошибке UTF-8 (например, cp1251 для российских API).
        """
        encodings_to_try: list[str | tuple[str, str]] = []
        if response.charset:
            encodings_to_try.append(response.charset)
        encodings_to_try.append("utf-8")
        encodings_to_try.append("cp1251")  # Windows-1251, типично для российских API
        encodings_to_try.append(("iso-8859-1", "replace"))
        for entry in encodings_to_try:
            if isinstance(entry, tuple):
                encoding, errors = entry
            else:
                encoding, errors = entry, "strict"
            try:
                return body_bytes.decode(encoding, errors=errors)
            except (UnicodeDecodeError, LookupError):
                continue
        return body_bytes.decode("iso-8859-1", errors="replace")

    async def _make_request(
        self,
        method: Literal["GET", "POST", "PUT", "DELETE", "PATCH"],
        uri: str,
        headers: dict[str, Any] | None = None,
        params: str | dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        data: Any | None = None,
        retry_on_proxy_error: bool = False,
        max_retries: int = 5,
    ) -> str:
        """
        Базовый метод для выполнения HTTP запросов. Возвращает только строку.

        Args:
            method: HTTP метод
            uri: URI endpoint (будет добавлен к base_url)
            headers: Дополнительные заголовки
            params: Query параметры
            json: JSON тело запроса (для POST/PUT/PATCH)
            data: Данные тела запроса (альтернатива json)
            retry_on_proxy_error: Повторять ли запрос при ошибках прокси
            max_retries: Максимальное количество попыток при retry_on_proxy_error

        Returns:
            Текст ответа как строка

        Raises:
            ClientResponseErrorException: При неуспешном HTTP статусе (>=400)
            ClientTimeoutException: При таймауте соединения
            ClientProxyException: При ошибке прокси
            ClientConnectionException: При ошибке соединения
            ClientDNSException: При ошибке DNS
        """
        url = self._build_url(uri, params)
        merged_headers = self._merge_headers(headers)
        session = await self._get_session()

        # Определяем kwargs для запроса
        request_kwargs: dict[str, Any] = {
            "url": url,
            "headers": merged_headers,
            "proxy": self._proxy,
        }

        if json is not None:
            request_kwargs["json"] = json
        elif data is not None:
            request_kwargs["data"] = data

        payload = self._prepare_payload(json, data)
        amount_failed = 0

        while True:
            response_body_text = ""
            start_time = time.perf_counter()
            try:
                async with session.request(method, **request_kwargs) as response:
                    body_bytes = await response.read()
                    response_body_text = self._decode_response_body(
                        body_bytes, response
                    )
                    end_time = time.perf_counter()
                    duration_ms = int((end_time - start_time) * 1000)

                    response_data = self._prepare_response(response_body_text)

                    self._logger.info(
                        "HTTP запрос выполнен",
                        extra={
                            "url": url,
                            "method": method,
                            "status_code": response.status,
                            "payload": payload,
                            "response": response_data,
                            "duration": duration_ms,
                        },
                    )

                    if response.status >= 400:
                        raise ClientResponseErrorException(
                            f"HTTP {response.status} error: {response.reason}",
                            url=url,
                            status_code=response.status,
                            response_body=response_body_text,
                        )

                    return response_body_text

            except (ClientHttpProxyError, ClientProxyConnectionError) as e:
                if not retry_on_proxy_error:
                    self._logger.error(
                        "Ошибка прокси при HTTP запросе",
                        extra={
                            "method": method,
                            "url": url,
                            "proxy": self._proxy,
                            "error": str(e),
                        },
                    )
                    raise ClientProxyException(
                        f"Proxy error: {str(e)}",
                        url=url,
                        proxy=self._proxy,
                    ) from e

                amount_failed += 1
                if amount_failed >= max_retries:
                    self._logger.error(
                        "Ошибка прокси после исчерпания попыток",
                        extra={
                            "method": method,
                            "url": url,
                            "proxy": self._proxy,
                            "retries": amount_failed,
                            "error": str(e),
                        },
                    )
                    raise ClientProxyException(
                        f"Proxy error after {max_retries} retries: {str(e)}",
                        url=url,
                        proxy=self._proxy,
                    ) from e

                self._logger.warning(
                    "Повтор запроса после ошибки прокси",
                    extra={
                        "method": method,
                        "url": url,
                        "proxy": self._proxy,
                        "retry": amount_failed,
                        "max_retries": max_retries,
                    },
                )
                continue

            except (TimeoutError, ServerTimeoutError) as e:
                # self._logger.error(
                #     "Таймаут HTTP запроса",
                #     extra={
                #         "method": method,
                #         "url": url,
                #         "timeout": self.DEFAULT_TIMEOUT,
                #         "error": str(e),
                #     },
                # )
                raise ClientTimeoutException(
                    f"Request timeout after {self.DEFAULT_TIMEOUT}s: {str(e)}",
                    url=url,
                ) from e

            except ClientConnectorDNSError as e:
                self._logger.error(
                    "Ошибка DNS при HTTP запросе",
                    extra={
                        "method": method,
                        "url": url,
                        "error": str(e),
                    },
                )
                raise ClientDNSException(
                    f"DNS resolution failed: {str(e)}",
                    url=url,
                ) from e

            except ClientConnectionError as e:
                self._logger.error(
                    "Ошибка соединения при HTTP запросе",
                    extra={
                        "method": method,
                        "url": url,
                        "error": str(e),
                    },
                )
                raise ClientConnectionException(
                    f"Connection error: {str(e)}",
                    url=url,
                ) from e
            except ClientResponseErrorException as e:
                raise e
            except Exception as e:
                # Неожиданные ошибки
                self._logger.error(
                    "Неожиданная ошибка HTTP запроса",
                    extra={
                        "method": method,
                        "url": url,
                        "error_type": type(e).__name__,
                        "error": str(e),
                        "response": response_body_text or "",
                    },
                )
                raise ClientException(
                    f"Неожиданная HTTP-ошибка: {str(e)}",
                    url=url,
                ) from e

    async def request_text(
        self,
        method: Literal["GET", "POST", "PUT", "DELETE", "PATCH"],
        uri: str,
        headers: dict[str, Any] | None = None,
        params: str | dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        data: Any | None = None,
        retry_on_proxy_error: bool = False,
        max_retries: int = 5,
    ) -> str:
        """
        Выполняет HTTP запрос и возвращает ответ как строку.

        Используется для получения HTML, XML или других текстовых форматов.

        Args:
            method: HTTP метод
            uri: URI endpoint (будет добавлен к base_url)
            headers: Дополнительные заголовки
            params: Query параметры
            json: JSON тело запроса (для POST/PUT/PATCH)
            data: Данные тела запроса (альтернатива json)
            retry_on_proxy_error: Повторять ли запрос при ошибках прокси
            max_retries: Максимальное количество попыток при retry_on_proxy_error

        Returns:
            Текст ответа как строка

        Raises:
            ClientResponseErrorException: При неуспешном HTTP статусе (>=400)
            ClientTimeoutException: При таймауте соединения
            ClientProxyException: При ошибке прокси
            ClientConnectionException: При ошибке соединения
            ClientDNSException: При ошибке DNS
        """
        return await self._make_request(
            method=method,
            uri=uri,
            headers=headers,
            params=params,
            json=json,
            data=data,
            retry_on_proxy_error=retry_on_proxy_error,
            max_retries=max_retries,
        )

    async def request_json(
        self,
        method: Literal["GET", "POST", "PUT", "DELETE", "PATCH"],
        uri: str,
        headers: dict[str, Any] | None = None,
        params: str | dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        data: Any | None = None,
        retry_on_proxy_error: bool = False,
        max_retries: int = 5,
    ) -> dict[str, Any] | list[Any]:
        """
        Выполняет HTTP запрос и возвращает ответ как распарсенный JSON.

        Args:
            method: HTTP метод
            uri: URI endpoint (будет добавлен к base_url)
            headers: Дополнительные заголовки
            params: Query параметры
            json: JSON тело запроса (для POST/PUT/PATCH)
            data: Данные тела запроса (альтернатива json)
            retry_on_proxy_error: Повторять ли запрос при ошибках прокси
            max_retries: Максимальное количество попыток при retry_on_proxy_error

        Returns:
            Распарсенный JSON (dict или list)

        Raises:
            ClientResponseErrorException: При неуспешном HTTP статусе (>=400)
            ClientTimeoutException: При таймауте соединения
            ClientProxyException: При ошибке прокси
            ClientConnectionException: При ошибке соединения
            ClientDNSException: При ошибке DNS
            json.JSONDecodeError: Если ответ не является валидным JSON
        """
        response_text = await self._make_request(
            method=method,
            uri=uri,
            headers=headers,
            params=params,
            json=json,
            data=data,
            retry_on_proxy_error=retry_on_proxy_error,
            max_retries=max_retries,
        )

        try:
            return json_lib.loads(response_text)
        except json_lib.JSONDecodeError as e:
            url = self._build_url(uri, params)
            self._logger.error(
                "Не удалось распарсить ответ как JSON",
                extra={
                    "method": method,
                    "url": url,
                    "response": response_text,
                    "error": str(e),
                },
            )
            raise
