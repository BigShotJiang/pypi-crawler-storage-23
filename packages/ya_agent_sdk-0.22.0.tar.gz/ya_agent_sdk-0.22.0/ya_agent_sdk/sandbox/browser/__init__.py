"""Browser sandbox implementations for isolated browser execution."""

from ya_agent_sdk.sandbox.browser.base import BrowserSandbox

__all__ = ["BrowserSandbox"]
