from abc import ABC, abstractmethod
from typing import Dict, Any, Tuple, List, Callable
from encoding_library.models.payload import Payload

class DataProcessor(ABC):
    """
    Abstract base class for data processors.
    """

    @abstractmethod
    def validate(self, data: Dict[str, Any]) -> bool:
        """
        Validate the input data.
        Raises ValueError if invalid.
        Returns True if valid.
        """
        pass

    @abstractmethod
    def to_sqs_message(self, payload: Payload) -> Tuple[str, Dict[str, Any]]:
        """
        Convert payload to SQS message format.
        Returns a tuple of (MessageBody, MessageAttributes).
        """
        pass

    @abstractmethod
    def prepare_for_vector_db(self, data: Dict[str, Any], embeddings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Prepare data for insertion into Vector DB.
        Returns a LIST of dictionaries, where each dict is a record to be inserted.
        This allows for 1-to-many relationship (e.g. 1 Note -> Multiple Chunks).
        """
        pass

    @abstractmethod
    def create_embeddings(self, data: Dict[str, Any], encoder: Any) -> List[Dict[str, Any]]:
        """
        Create embeddings for the data.
        Returns a list of dictionaries, each containing 'text' and 'vector'.
        """
        pass
