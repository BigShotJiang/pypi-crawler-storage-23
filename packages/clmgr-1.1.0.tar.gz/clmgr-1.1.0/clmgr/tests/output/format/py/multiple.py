#
# Copyright (c) 2015 - 2018 [Enovation B.V. - Capelle aan den IJssel]
# Copyright (c) 2018 - 2026 [Enovation Group B.V. - Capelle aan den IJssel]
# ---
# All rights reserved.
# ---
#
"""Multiple file testcase"""


def multiple():
    print("Copyright test multiple")
