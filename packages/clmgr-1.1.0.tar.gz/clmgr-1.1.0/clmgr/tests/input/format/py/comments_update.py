#
# Copyright (c) 2014 - 2020 [Enovation Group B.V. - Capelle aan den IJssel - NL]
# ---
# All rights reserved.
# ---
# Additional comment lines which should remain intact
# This line should also remain intact
#
# =======================================================================================================================
# Explanation:
#
# Even when the comment is very large and has multiple lines or empty new lines,
# the copyright statement should not be added as a duplicate.
# =======================================================================================================================
#
#
"""Comments file testcase"""


def comments():
    print("Copyright test comments")
