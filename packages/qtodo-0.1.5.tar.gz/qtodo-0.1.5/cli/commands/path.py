import click
from rich.console import Console
from config import CONFIG_FILE

console = Console()

@click.command()
def path():
    """Show the path where qTodo stores its configuration."""
    console.print(f"[bold green]Configuration file is stored at:[/bold green] {CONFIG_FILE}")
