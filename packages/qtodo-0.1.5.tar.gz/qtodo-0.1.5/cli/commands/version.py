import click
from importlib.metadata import version

@click.command()
def show_version():
    """Show the current qTodo version."""
    try:
        ver = version("qtodo")
        click.echo(f"qTodo v{ver}")
    except Exception:
        click.echo("qTodo version could not be determined.")
