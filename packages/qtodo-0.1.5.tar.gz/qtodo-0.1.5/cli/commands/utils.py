import click
from core.db import create_todo_list, todo_list_table, Q as db_Q
from models.todo import TodoList
from config import get_default_list

def resolve_list(list_identifier: str | None) -> tuple[int, str]:
    """Helper to resolve list name to ID. Fails if the list doesn't exist."""
    name = list_identifier or get_default_list()
    if name.startswith("@"):
        name = name[1:]
    
    lst = todo_list_table.get(db_Q.name == name)
    if not lst:
        if name == "Inbox":
            # Inbox is the default, so it's fine to auto-create it if it's missing initially.
            nl = create_todo_list(TodoList(name=name, description="Default Inbox list"))
            return nl.id, nl.name
        
        click.echo(f"Error: List '{name}' does not exist. Please create it first using 'qtodo newlist {name}'")
        raise click.Abort()
        
    return lst['id'], lst['name']
