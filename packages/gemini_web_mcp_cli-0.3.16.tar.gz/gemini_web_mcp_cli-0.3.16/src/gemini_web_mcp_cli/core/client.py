"""GeminiClient: the main entry point that composes all core components.

Usage:
    client = GeminiClient(profile_name="default")
    await client.init()
    response = await client.send("Hello!")
    print(response.text)
"""

from __future__ import annotations

import asyncio
from pathlib import Path

import httpx
from loguru import logger

from .auth import AuthManager
from .constants import (
    CHROME_USER_AGENT,
    DEFAULT_MODEL,
    GEMINI_HEADERS,
    TOKEN_FACTORY_MODELS,
    Model,
    get_model,
)
from .exceptions import AuthError, GeminiError, TokenFactoryError
from .models import BatchResult, ConversationMetadata, RPCPayload, StreamResponse
from .profiles import ProfileManager
from .rpc import RPCTransport, build_stream_response


class GeminiClient:
    """High-level client that composes AuthManager, RPCTransport, and ProfileManager.

    Handles initialization, authentication, and provides simple methods for
    chat, batchexecute, and other operations.
    """

    def __init__(
        self,
        profile_name: str | None = None,
        proxy: str | None = None,
        timeout: float = 300.0,
    ):
        self.profile_manager = ProfileManager()
        self.auth_manager = AuthManager(
            profile_manager=self.profile_manager,
            profile_name=profile_name,
            proxy=proxy,
        )
        self.proxy = proxy
        self.timeout = timeout
        self._http_client: httpx.AsyncClient | None = None
        self._transport: RPCTransport | None = None
        self._token_factory = None  # Lazy-initialized TokenFactory
        self._browser_http_client: httpx.AsyncClient | None = None
        self._browser_cookies: dict[str, str] | None = None  # Full cookies from Token Factory
        self._raw_browser_cookies: list[dict] = []  # Raw CDP cookies with domain info
        self._browser_access_token: str | None = None  # Chrome's live SNlM0e (from WIZ_global_data)
        self._initialized = False

    @property
    def transport(self) -> RPCTransport:
        if not self._transport:
            raise AuthError("Client not initialized. Call init() first.")
        return self._transport

    async def init(self) -> None:
        """Initialize the client: load auth, create HTTP client, set up transport."""
        # Load auth state from profile
        auth_state = self.auth_manager.load()

        if not auth_state.is_valid:
            raise AuthError(
                "No valid authentication found. Run `gemcli login` first."
            )

        # Refresh tokens to ensure they're current (non-fatal if it fails)
        try:
            await self.auth_manager.refresh_tokens()
        except AuthError:
            logger.debug("Token refresh failed, using cached tokens.")

        auth_state = self.auth_manager.state

        # Create HTTP client
        self._http_client = httpx.AsyncClient(
            http2=True,
            timeout=self.timeout,
            proxy=self.proxy,
            follow_redirects=True,
            headers=GEMINI_HEADERS,
            cookies=auth_state.cookies,
        )

        # Create transport
        self._transport = RPCTransport(
            client=self._http_client,
            access_token=auth_state.tokens.snlm0e,
            build_label=auth_state.tokens.cfb2h,
            session_id=auth_state.tokens.fdrfje,
        )

        self._initialized = True
        logger.info("GeminiClient initialized.")

    async def close(self) -> None:
        """Close the HTTP client, Token Factory, and clean up."""
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None
        if self._browser_http_client:
            await self._browser_http_client.aclose()
            self._browser_http_client = None
        if self._token_factory:
            self._token_factory.shutdown()
            self._token_factory = None
        self._transport = None
        self._initialized = False

    async def send(
        self,
        prompt: str,
        model: str | Model | None = None,
        metadata: ConversationMetadata | None = None,
        file_data: list | None = None,
        gem_id: str | None = None,
        tool_id: int | None = None,
        style_preset: dict | None = None,
        force_token_factory: bool = False,
    ) -> StreamResponse:
        """Send a chat message via StreamGenerate.

        Routes through Token Factory when:
        - Pro/Thinking models are requested (need BotGuard for model header)
        - tool_id is set (music tools need BotGuard token in body)
        - force_token_factory is True (video generation needs BotGuard)

        Args:
            tool_id: Optional tool activation ID for inner_req_list[49].
                     Use MUSIC_TOOL_ID (21) for music generation.
            style_preset: Optional music style preset dict (from music_presets.py).
                          Injected into inner[0][9] for remix-style generation.
            force_token_factory: Force Token Factory usage for BotGuard tokens
                                 without setting a tool_id. Required for video
                                 generation (Veo 3.1).
        """
        resolved_model = self._resolve_model(model)

        # Token Factory required for: Pro/Thinking models, tool-based generation
        # (music), features that need BotGuard tokens (video), or file attachments.
        if (
            self._needs_token_factory(resolved_model)
            or tool_id is not None
            or force_token_factory
            or file_data is not None
        ):
            return await self._send_via_token_factory(
                prompt=prompt,
                model=resolved_model,
                metadata=metadata,
                file_data=file_data,
                gem_id=gem_id,
                tool_id=tool_id,
                style_preset=style_preset,
            )

        return await self.transport.stream_generate(
            prompt=prompt,
            model=resolved_model,
            metadata=metadata,
            file_data=file_data,
            gem_id=gem_id,
            tool_id=tool_id,
            style_preset=style_preset,
        )

    async def execute_rpc(
        self,
        rpc_id: str,
        payload: str = "[]",
        source_path: str = "/app",
    ) -> list[BatchResult]:
        """Execute a single RPC via batchexecute."""
        return await self.transport.batchexecute(
            payloads=[RPCPayload(rpc_id=rpc_id, payload=payload)],
            source_path=source_path,
        )

    async def execute_rpcs(
        self,
        payloads: list[RPCPayload],
        source_path: str = "/app",
    ) -> list[BatchResult]:
        """Execute multiple RPCs in a single batchexecute call."""
        return await self.transport.batchexecute(
            payloads=payloads,
            source_path=source_path,
        )

    async def execute_rpc_with_browser_cookies(
        self,
        rpc_id: str,
        payload: str = "[]",
        source_path: str = "/app",
    ) -> list[BatchResult]:
        """Execute a single RPC using full browser cookies.

        Required for RPCs that need full auth (e.g. hNvQHb conversation reload
        after Token Factory-initiated video generation). Falls back to basic
        auth if browser cookies aren't available.
        """
        if not self._browser_cookies:
            return await self.execute_rpc(rpc_id, payload, source_path)

        from .parser import parse_batchexecute_response
        from .rpc import (
            build_batchexecute_body,
            build_batchexecute_url,
            build_headers,
        )

        payloads = [RPCPayload(rpc_id=rpc_id, payload=payload)]
        url = build_batchexecute_url(
            rpc_ids=[rpc_id],
            reqid=self.transport._next_reqid(),
            build_label=self.transport.build_label,
            session_id=self.transport.session_id,
            source_path=source_path,
        )
        body = build_batchexecute_body(
            payloads,
            self._browser_access_token or self.transport.access_token,
        )
        headers = build_headers()

        if self._browser_http_client is None:
            self._browser_http_client = httpx.AsyncClient(
                http2=True, timeout=self.timeout, follow_redirects=True,
            )

        logger.debug(f"batchexecute (browser cookies): [{rpc_id}]")
        response = await self._browser_http_client.post(
            url, content=body, headers=headers, cookies=self._browser_cookies,
        )
        response.raise_for_status()

        parsed = parse_batchexecute_response(response.text)
        return [
            BatchResult(rpc_id=r["rpc_id"], data=r["data"], raw=r["raw"])
            for r in parsed
        ]

    def get_cookies(self) -> dict[str, str]:
        """Get the best available cookies (full browser set if available, else auth-only)."""
        if self._browser_cookies:
            return self._browser_cookies
        return self.auth_manager.state.cookies

    def get_httpx_cookies(self) -> httpx.Cookies:
        """Get cookies as httpx.Cookies with proper domain handling for cross-domain downloads.

        Duplicates cookies for both .google.com and .googleusercontent.com
        to ensure authentication works across Google CDN redirect domains.
        This is required for downloading images from lh3.googleusercontent.com.
        """
        cookies = httpx.Cookies()

        if self._raw_browser_cookies:
            for c in self._raw_browser_cookies:
                name = c.get("name")
                value = c.get("value")
                domain = c.get("domain", "")
                path = c.get("path", "/")

                if not name or not value:
                    continue

                if "google.com" in domain:
                    cookies.set(name, value, domain=domain, path=path)
                    # Duplicate for .googleusercontent.com for CDN downloads
                    if domain == ".google.com":
                        cookies.set(
                            name, value, domain=".googleusercontent.com", path=path
                        )
        else:
            # Fallback: simple cookies without domain info — set for both domains
            for name, value in self.get_cookies().items():
                cookies.set(name, value, domain=".google.com")
                cookies.set(name, value, domain=".googleusercontent.com")

        return cookies

    async def download_media(
        self,
        url: str,
        output_path: str | Path,
        headers: dict[str, str] | None = None,
        timeout: float = 120.0,
    ) -> Path:
        """Download a media file, trying CDP page fetch first, then httpx.

        CDP page fetch uses JavaScript fetch() from the Gemini page context,
        which has access to Chrome's full cookie jar including partitioned
        cookies. This is required for contribution.usercontent.google.com
        downloads, where CDP's Network.getAllCookies is missing critical cookies.

        Falls back to httpx with domain-aware cookies if Chrome is not
        available (e.g., Flash model without Token Factory).

        Args:
            url: The media download URL.
            output_path: Local path to save the downloaded file.
            headers: Optional HTTP headers (used only for httpx fallback).
            timeout: Download timeout in seconds.

        Returns:
            Path to the saved file.
        """
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)

        # Try CDP page fetch first (handles partitioned cookies)
        try:
            data = await self._download_via_cdp(url, timeout=int(timeout))
            output.write_bytes(data)
            logger.info(f"Downloaded via browser: {output} ({len(data)} bytes)")
            return output
        except Exception as e:
            logger.debug(f"CDP download unavailable, falling back to httpx: {e}")

        # Fallback: httpx with domain-aware cookies
        cookies = self.get_httpx_cookies()
        fallback_headers = headers or {
            "User-Agent": CHROME_USER_AGENT,
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            "Origin": "https://gemini.google.com",
            "Referer": "https://gemini.google.com/",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-site",
        }
        http_timeout = httpx.Timeout(
            connect=10.0, read=timeout, write=30.0, pool=30.0,
        )

        async with httpx.AsyncClient(
            http2=True,
            headers=fallback_headers,
            cookies=cookies,
            follow_redirects=True,
            timeout=http_timeout,
        ) as client:
            response = await client.get(url)

            # Check for auth redirect (200 with HTML instead of media)
            content_type = response.headers.get("content-type", "").lower()
            if "text/html" in content_type:
                raise GeminiError(
                    "Media download redirected to login page. "
                    "Ensure Chrome is running with 'gemcli chrome start' "
                    "or re-login with 'gemcli login'."
                )

            response.raise_for_status()
            output.write_bytes(response.content)

        logger.info(f"Downloaded via httpx: {output}")
        return output

    async def _download_via_cdp(self, url: str, timeout: int = 120) -> bytes:
        """Download via CDP page fetch (runs in executor since CDP is sync)."""
        from .cdp import (
            download_via_page_fetch,
            find_existing_chrome,
            get_gemini_page_ws_url,
        )

        loop = asyncio.get_event_loop()

        def _do_download():
            port = find_existing_chrome()
            if not port:
                raise GeminiError("No Chrome instance found for browser download")

            ws_url = get_gemini_page_ws_url(port)
            if not ws_url:
                raise GeminiError("No Gemini page found in Chrome for browser download")

            return download_via_page_fetch(ws_url, url, timeout=timeout)

        return await loop.run_in_executor(None, _do_download)

    def _needs_token_factory(self, model: Model) -> bool:
        """Check if this model requires BotGuard tokens (Pro/Thinking)."""
        return model.name in TOKEN_FACTORY_MODELS

    def _ensure_token_factory(self):
        """Lazy-initialize the Token Factory."""
        if self._token_factory is None:
            from .token_factory import TokenFactory

            auth_state = self.auth_manager.state
            if not auth_state.chrome_profile_path:
                raise TokenFactoryError(
                    "No Chrome profile configured. Run 'gemcli login' first."
                )
            self._token_factory = TokenFactory(
                chrome_profile_path=auth_state.chrome_profile_path,
                profile_name=self.auth_manager.profile_name or "default",
            )
        return self._token_factory

    async def _send_via_token_factory(
        self,
        prompt: str,
        model: Model,
        metadata: ConversationMetadata | None = None,
        file_data: list | None = None,
        gem_id: str | None = None,
        tool_id: int | None = None,
        style_preset: dict | None = None,
    ) -> StreamResponse:
        """Send via Token Factory: Chrome captures BotGuard token, Python sends HTTP."""
        factory = self._ensure_token_factory()

        # TokenFactory is sync (CDP uses sync websocket) — run in executor
        loop = asyncio.get_event_loop()
        captured = await loop.run_in_executor(
            None,
            lambda: factory.capture(prompt=prompt, model=model, metadata=metadata),
        )

        # Create a separate HTTP client for browser-replay requests
        # (no preset cookies — we use the captured cookies directly)
        if self._browser_http_client is None:
            self._browser_http_client = httpx.AsyncClient(
                http2=True,
                timeout=self.timeout,
                follow_redirects=True,
            )

        # Store browser cookies and access token for use by other operations
        # (e.g., image download, video polling batchexecute calls).
        # IMPORTANT: captured.access_token is Chrome's live SNlM0e token extracted
        # from window.WIZ_global_data — use it for ANY subsequent calls that use
        # Chrome cookies, or they will 400 from an at= mismatch.
        self._browser_cookies = captured.cookies
        self._raw_browser_cookies = factory.get_raw_cookies()
        self._browser_access_token = captured.access_token  # Chrome's live SNlM0e

        # We extract the BotGuard token from Chrome's captured body and inject it
        # into our rebuilt body. We use Chrome's live SNlM0e access token
        # (captured.access_token) to ensure the 'at=' parameter is always consistent
        # with the Chrome session's cookies, avoiding HTTP 400 errors.
        from .rpc import build_streamgenerate_body

        botguard_token, botguard_hash = self._extract_botguard(captured.body)

        # Determine access token: prefer Chrome's live token, fall back to cached.
        at_token = captured.access_token or self.transport.access_token

        logger.debug("Token Factory: rebuilding body with full prompt and custom params "
                     f"(tool_id={tool_id}, style_preset={bool(style_preset)}, "
                     f"gem_id={bool(gem_id)}, file_data={bool(file_data)}, "
                     f"botguard={bool(botguard_token)}, "
                     f"chrome_at={bool(captured.access_token)})")

        body_str = build_streamgenerate_body(
            prompt=prompt,
            access_token=at_token,
            metadata=metadata,
            file_data=file_data,
            gem_id=gem_id,
            tool_id=tool_id,
            style_preset=style_preset,
            botguard_token=botguard_token,
            botguard_hash=botguard_hash,
        )

        # Always keep at= in the body. The original Veo video capture included it,
        # and stripping it causes Gemini to fall back to chat/image mode.
        # We built the body with Chrome's live SNlM0e token (at_token above),
        # so the at= value is already correct for the current Chrome session.

        logger.debug(f"Token Factory: sending via Python HTTP ({model.name})")
        response = await self._browser_http_client.post(
            captured.url,
            content=body_str,
            headers=captured.headers,
            cookies=captured.cookies,
        )
        response.raise_for_status()

        return build_stream_response(response.text)

    @staticmethod
    def _extract_botguard(captured_body: str) -> tuple[str | None, str | None]:
        """Extract BotGuard token and challenge hash from Chrome's captured request body.

        Chrome's body is URL-encoded form data with an f.req parameter containing
        a nested JSON array. The BotGuard token is at inner[3] and the challenge
        hash is at inner[4].

        Returns:
            Tuple of (botguard_token, botguard_hash), either may be None.
        """
        import json
        from urllib.parse import parse_qs, unquote

        try:
            parsed = parse_qs(captured_body)
            f_req_raw = parsed.get("f.req", [None])[0]
            if not f_req_raw:
                return None, None
            f_req = unquote(f_req_raw)
            outer = json.loads(f_req)
            inner = json.loads(outer[1])
            token = inner[3] if len(inner) > 3 and isinstance(inner[3], str) else None
            hash_val = inner[4] if len(inner) > 4 and isinstance(inner[4], str) else None
            if token:
                logger.debug(f"Extracted BotGuard token ({len(token)} chars) "
                             f"and hash={hash_val is not None}")
            return token, hash_val
        except Exception as e:
            logger.debug(f"Could not extract BotGuard from captured body: {e}")
            return None, None

    def _resolve_model(self, model: str | Model | None) -> Model:
        """Resolve a model name string to a Model object."""
        if model is None:
            return DEFAULT_MODEL
        if isinstance(model, Model):
            return model
        return get_model(model)

    async def __aenter__(self):
        await self.init()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
