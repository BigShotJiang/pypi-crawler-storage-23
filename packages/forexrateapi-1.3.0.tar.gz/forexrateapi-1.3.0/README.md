# ForexRateAPI

forexrateapi is the official Python API wrapper for ForexRateAPI.com. This allows you to quickly integrate our foreign exchange rate API and currency conversion API into your application. Check https://forexrateapi.com documentation for more information.

## Installation

Install the latest release with:


    pip install forexrateapi

## Usage

```python
from forexrateapi.client import Client

api_key = 'SET_YOUR_API_KEY_HERE'
client = Client(api_key)

# Or use EU server:
# client = Client(api_key, server='eu')
```
---
## Server Regions

ForexRateAPI provides two regional endpoints. Choose the one closest to your servers for optimal performance.

| Region | Base URL |
|--------|----------|
| United States (default) | `https://api.forexrateapi.com/v1` |
| Europe | `https://api-eu.forexrateapi.com/v1` |

```python
# Default (US)
client = Client('SET_YOUR_API_KEY_HERE')

# Europe
client = Client('SET_YOUR_API_KEY_HERE', server='eu')
```

---
## Documentation

#### fetchSymbols()
```python
client.fetchSymbols()
```

[Link](https://forexrateapi.com/documentation#api_symbol)

---
#### setServer(server)

- `server` <[string]> Pass `'eu'` to use the EU server (`api-eu.forexrateapi.com`), or `'us'` for the US server. Defaults to US if not specified.

```python
client.setServer('eu')
```

---
#### fetchLive(base, currencies, math)

- `base` <[string]> Optional. Pass in a base currency, defaults to USD.
- `currencies` <[List]<[string]>> Optional. Pass in an list of currencies to return values for.
- `math` <[string]> Optional. Pass in a math expression to apply to the rates.

```python
client.fetchLive(base='USD', currencies=['AUD', 'CAD', 'GBP', 'JPY'])
```

[Link](https://forexrateapi.com/documentation#api_realtime)

---
#### fetchHistorical(date, base, currencies)

- `date` <[string]> Required. Pass in a string with format `YYYY-MM-DD`
- `base` <[string]> Optional. Pass in a base currency, defaults to USD.
- `currencies` <[List]<[string]>> Optional. Pass in an list of currencies to return values for.

```python
client.fetchHistorical(date='2024-02-05', base='USD', currencies=['AUD', 'CAD', 'GBP', 'JPY'])
```

[Link](https://forexrateapi.com/documentation#api_historical)

---
#### hourly(base, currency, start_date, end_date, math, date_type)

- `base` <[string]> Optional. Pass in a base currency, defaults to USD.
- `currency` <[string]> Required. Specify currency you would like to get hourly rates for.
- `start_date` <[string]> Required. Specify the start date using the format `YYYY-MM-DD`.
- `end_date` <[string]> Required. Specify the end date using the format `YYYY-MM-DD`.
- `math` <[string]> Optional. Pass in a math expression to apply to the rates.
- `date_type` <[string]> Optional. Pass in a date type, overrides date parameters if passed in.

```python
client.hourly(base='USD', currency='EUR', start_date='2024-02-05', end_date='2024-02-05')
```

[Link](https://forexrateapi.com/documentation#api_hourly)

---
#### ohlc(base, currency, date, date_type)

- `base` <[string]> Optional. Pass in a base currency, defaults to USD.
- `currency` <[string]> Required. Specify currency you would like to get OHLC for.
- `date` <[string]> Required. Specify date to use historical midpoint value for conversion with format `YYYY-MM-DD`. Otherwise, it will use live exchange rate date if value not passed in.
- `date_type` <[string]> Optional. Pass in a date type.

```python
client.ohlc(base='USD', currency='EUR', date='2024-02-05', date_type=None)
```

[Link](https://forexrateapi.com/documentation#api_ohlc)

---
#### convert(from_currency, to_currency, amount, date)

- `from_currency` <[string]> Optional. Pass in a base currency, defaults to USD.
- `to_currency` <[string]> Required. Specify currency you would like to convert to.
- `amount` <[number]> Required. The amount to convert.
- `date` <[string]> Optional. Specify date to use historical midpoint value for conversion with format `YYYY-MM-DD`. Otherwise, it will use live exchange rate date if value not passed in.

```python
client.convert(from_currency='USD', to_currency='EUR', amount=100, date='2024-02-05')
```

[Link](https://forexrateapi.com/documentation#api_convert)

---
#### timeframe(start_date, end_date, base, currencies)

- `start_date` <[string]> Required. Specify the start date of your timeframe using the format `YYYY-MM-DD`.
- `end_date` <[string]> Required. Specify the end date of your timeframe using the format `YYYY-MM-DD`.
- `base` <[string]> Optional. Pass in a base currency, defaults to USD.
- `currencies` <[List]<[string]>> Optional. Pass in an list of currencies to return values for.

```python
client.timeframe(start_date='2024-02-05', end_date='2024-02-06', base='USD', currencies=['AUD', 'CAD', 'GBP', 'JPY'])
```

[Link](https://forexrateapi.com/documentation#api_timeframe)

---
#### change(start_date, end_date, base, currencies, date_type)

- `start_date` <[string]> Required. Specify the start date of your timeframe using the format `YYYY-MM-DD`.
- `end_date` <[string]> Required. Specify the end date of your timeframe using the format `YYYY-MM-DD`.
- `base` <[string]> Optional. Pass in a base currency, defaults to USD.
- `currencies` <[List]<[string]>> Optional. Pass in an list of currencies to return values for.
- `date_type` <[string]> Optional. Pass in a date type, overrides date parameters if passed in.

```python
client.change(start_date='2024-02-05', end_date='2024-02-06', base='USD', currencies=['AUD', 'CAD', 'GBP', 'JPY'])
```

[Link](https://forexrateapi.com/documentation#api_change)

---
#### usage()

```python
client.usage()
```

[Link](https://forexrateapi.com/documentation#api_usage)
---
**[Official documentation](https://forexrateapi.com/documentation)**


---
## FAQ

- How do I get an API Key?

    Free API Keys are available [here](https://forexrateapi.com).

- I want more information

    Checkout our FAQs [here](https://forexrateapi.com/faq).


## Support

For support, get in touch using [this form](https://forexrateapi.com/contact).


[List]: https://www.w3schools.com/python/python_datatypes.asp 'List'
[number]: https://www.w3schools.com/python/python_datatypes.asp 'Number'
[string]: https://www.w3schools.com/python/python_datatypes.asp 'String'
