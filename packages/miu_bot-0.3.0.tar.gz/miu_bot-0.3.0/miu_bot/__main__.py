"""
Entry point for running miu_bot as a module: python -m miu_bot
"""

from miu_bot.cli.commands import app

if __name__ == "__main__":
    app()
