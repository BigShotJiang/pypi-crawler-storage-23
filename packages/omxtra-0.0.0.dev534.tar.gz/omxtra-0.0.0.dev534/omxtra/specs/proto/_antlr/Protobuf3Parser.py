# type: ignore
# ruff: noqa
# flake8: noqa
# @omlish-generated
# Generated from Protobuf3.g4 by ANTLR 4.13.2
# encoding: utf-8
from ....text.antlr._runtime._all import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,59,464,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,46,
        7,46,2,47,7,47,1,0,1,0,5,0,99,8,0,10,0,12,0,102,9,0,1,0,1,0,1,1,
        1,1,1,1,1,1,1,1,1,2,1,2,1,2,1,2,1,2,3,2,116,8,2,1,3,1,3,3,3,120,
        8,3,1,3,1,3,1,3,1,4,1,4,1,4,1,4,1,5,1,5,1,5,1,5,1,5,3,5,134,8,5,
        1,5,1,5,1,6,1,6,1,6,1,6,1,6,3,6,143,8,6,1,6,1,6,1,6,3,6,148,8,6,
        5,6,150,8,6,10,6,12,6,153,9,6,1,7,1,7,5,7,157,8,7,10,7,12,7,160,
        9,7,1,7,1,7,1,8,1,8,1,8,1,8,1,9,1,9,1,9,1,9,3,9,172,8,9,1,10,1,10,
        1,10,1,10,1,11,1,11,5,11,180,8,11,10,11,12,11,183,9,11,1,11,1,11,
        1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,3,12,196,8,12,1,13,
        1,13,1,13,1,13,1,14,1,14,1,14,1,14,5,14,206,8,14,10,14,12,14,209,
        9,14,1,14,1,14,1,15,1,15,1,15,3,15,216,8,15,1,15,1,15,1,15,1,15,
        1,15,5,15,223,8,15,10,15,12,15,226,9,15,1,15,1,15,3,15,230,8,15,
        1,15,1,15,1,16,1,16,1,16,1,16,1,17,1,17,1,17,1,17,1,17,3,17,243,
        8,17,1,17,1,17,1,18,1,18,1,18,1,18,1,18,1,18,5,18,253,8,18,10,18,
        12,18,256,9,18,1,18,1,18,1,19,1,19,1,19,1,19,3,19,264,8,19,1,19,
        1,19,1,19,1,19,1,19,3,19,271,8,19,1,19,1,19,1,19,1,19,1,19,5,19,
        278,8,19,10,19,12,19,281,9,19,1,19,1,19,3,19,285,8,19,1,20,1,20,
        1,20,3,20,290,8,20,1,20,1,20,1,21,1,21,1,21,5,21,297,8,21,10,21,
        12,21,300,9,21,1,22,1,22,1,22,1,22,3,22,306,8,22,1,23,1,23,1,23,
        5,23,311,8,23,10,23,12,23,314,9,23,1,24,1,24,3,24,318,8,24,1,25,
        1,25,1,26,1,26,1,27,3,27,325,8,27,1,27,1,27,1,27,1,27,1,27,1,27,
        1,27,1,27,3,27,335,8,27,1,27,1,27,1,28,1,28,1,28,5,28,342,8,28,10,
        28,12,28,345,9,28,1,29,1,29,1,29,1,29,1,30,1,30,1,30,1,30,1,30,5,
        30,356,8,30,10,30,12,30,359,9,30,1,30,1,30,1,31,1,31,1,31,1,31,1,
        31,1,31,1,31,1,31,3,31,371,8,31,1,31,1,31,1,32,1,32,1,32,1,32,1,
        32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,32,3,32,388,8,32,1,32,1,
        32,1,33,1,33,1,34,1,34,1,35,1,35,1,35,5,35,399,8,35,10,35,12,35,
        402,9,35,1,36,1,36,1,37,1,37,1,38,1,38,1,39,1,39,3,39,412,8,39,1,
        40,1,40,1,41,1,41,1,42,1,42,1,43,1,43,1,44,3,44,423,8,44,1,44,1,
        44,5,44,427,8,44,10,44,12,44,430,9,44,1,44,1,44,1,45,3,45,435,8,
        45,1,45,1,45,3,45,439,8,45,1,45,5,45,442,8,45,10,45,12,45,445,9,
        45,1,45,1,45,1,46,1,46,1,47,1,47,3,47,453,8,47,1,47,1,47,3,47,457,
        8,47,1,47,1,47,1,47,3,47,462,8,47,1,47,0,0,48,0,2,4,6,8,10,12,14,
        16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,
        60,62,64,66,68,70,72,74,76,78,80,82,84,86,88,90,92,94,0,6,1,0,32,
        33,2,0,34,34,50,50,6,0,16,18,21,23,25,26,40,43,45,45,48,49,6,0,16,
        16,21,22,25,26,40,43,45,45,48,49,6,0,20,20,28,28,30,31,38,39,44,
        46,50,50,2,0,9,9,15,15,478,0,96,1,0,0,0,2,105,1,0,0,0,4,115,1,0,
        0,0,6,117,1,0,0,0,8,124,1,0,0,0,10,128,1,0,0,0,12,142,1,0,0,0,14,
        154,1,0,0,0,16,163,1,0,0,0,18,171,1,0,0,0,20,173,1,0,0,0,22,177,
        1,0,0,0,24,195,1,0,0,0,26,197,1,0,0,0,28,201,1,0,0,0,30,212,1,0,
        0,0,32,233,1,0,0,0,34,237,1,0,0,0,36,246,1,0,0,0,38,259,1,0,0,0,
        40,286,1,0,0,0,42,293,1,0,0,0,44,305,1,0,0,0,46,307,1,0,0,0,48,317,
        1,0,0,0,50,319,1,0,0,0,52,321,1,0,0,0,54,324,1,0,0,0,56,338,1,0,
        0,0,58,346,1,0,0,0,60,350,1,0,0,0,62,362,1,0,0,0,64,374,1,0,0,0,
        66,391,1,0,0,0,68,393,1,0,0,0,70,395,1,0,0,0,72,403,1,0,0,0,74,405,
        1,0,0,0,76,407,1,0,0,0,78,411,1,0,0,0,80,413,1,0,0,0,82,415,1,0,
        0,0,84,417,1,0,0,0,86,419,1,0,0,0,88,422,1,0,0,0,90,434,1,0,0,0,
        92,448,1,0,0,0,94,461,1,0,0,0,96,100,3,2,1,0,97,99,3,4,2,0,98,97,
        1,0,0,0,99,102,1,0,0,0,100,98,1,0,0,0,100,101,1,0,0,0,101,103,1,
        0,0,0,102,100,1,0,0,0,103,104,5,0,0,1,104,1,1,0,0,0,105,106,5,46,
        0,0,106,107,5,1,0,0,107,108,7,0,0,0,108,109,5,2,0,0,109,3,1,0,0,
        0,110,116,3,6,3,0,111,116,3,8,4,0,112,116,3,10,5,0,113,116,3,18,
        9,0,114,116,3,92,46,0,115,110,1,0,0,0,115,111,1,0,0,0,115,112,1,
        0,0,0,115,113,1,0,0,0,115,114,1,0,0,0,116,5,1,0,0,0,117,119,5,24,
        0,0,118,120,7,1,0,0,119,118,1,0,0,0,119,120,1,0,0,0,120,121,1,0,
        0,0,121,122,5,55,0,0,122,123,5,2,0,0,123,7,1,0,0,0,124,125,5,31,
        0,0,125,126,3,70,35,0,126,127,5,2,0,0,127,9,1,0,0,0,128,129,5,30,
        0,0,129,130,3,12,6,0,130,133,5,1,0,0,131,134,3,94,47,0,132,134,3,
        14,7,0,133,131,1,0,0,0,133,132,1,0,0,0,134,135,1,0,0,0,135,136,5,
        2,0,0,136,11,1,0,0,0,137,143,5,51,0,0,138,139,5,3,0,0,139,140,3,
        70,35,0,140,141,5,4,0,0,141,143,1,0,0,0,142,137,1,0,0,0,142,138,
        1,0,0,0,143,151,1,0,0,0,144,147,5,5,0,0,145,148,5,51,0,0,146,148,
        3,68,34,0,147,145,1,0,0,0,147,146,1,0,0,0,148,150,1,0,0,0,149,144,
        1,0,0,0,150,153,1,0,0,0,151,149,1,0,0,0,151,152,1,0,0,0,152,13,1,
        0,0,0,153,151,1,0,0,0,154,158,5,6,0,0,155,157,3,16,8,0,156,155,1,
        0,0,0,157,160,1,0,0,0,158,156,1,0,0,0,158,159,1,0,0,0,159,161,1,
        0,0,0,160,158,1,0,0,0,161,162,5,7,0,0,162,15,1,0,0,0,163,164,3,12,
        6,0,164,165,5,8,0,0,165,166,3,94,47,0,166,17,1,0,0,0,167,172,3,20,
        10,0,168,172,3,26,13,0,169,172,3,34,17,0,170,172,3,36,18,0,171,167,
        1,0,0,0,171,168,1,0,0,0,171,169,1,0,0,0,171,170,1,0,0,0,172,19,1,
        0,0,0,173,174,5,28,0,0,174,175,3,72,36,0,175,176,3,22,11,0,176,21,
        1,0,0,0,177,181,5,6,0,0,178,180,3,24,12,0,179,178,1,0,0,0,180,183,
        1,0,0,0,181,179,1,0,0,0,181,182,1,0,0,0,182,184,1,0,0,0,183,181,
        1,0,0,0,184,185,5,7,0,0,185,23,1,0,0,0,186,196,3,54,27,0,187,196,
        3,26,13,0,188,196,3,20,10,0,189,196,3,34,17,0,190,196,3,10,5,0,191,
        196,3,60,30,0,192,196,3,64,32,0,193,196,3,40,20,0,194,196,3,92,46,
        0,195,186,1,0,0,0,195,187,1,0,0,0,195,188,1,0,0,0,195,189,1,0,0,
        0,195,190,1,0,0,0,195,191,1,0,0,0,195,192,1,0,0,0,195,193,1,0,0,
        0,195,194,1,0,0,0,196,25,1,0,0,0,197,198,5,19,0,0,198,199,3,74,37,
        0,199,200,3,28,14,0,200,27,1,0,0,0,201,207,5,6,0,0,202,206,3,10,
        5,0,203,206,3,30,15,0,204,206,3,92,46,0,205,202,1,0,0,0,205,203,
        1,0,0,0,205,204,1,0,0,0,206,209,1,0,0,0,207,205,1,0,0,0,207,208,
        1,0,0,0,208,210,1,0,0,0,209,207,1,0,0,0,210,211,5,7,0,0,211,29,1,
        0,0,0,212,213,5,51,0,0,213,215,5,1,0,0,214,216,5,9,0,0,215,214,1,
        0,0,0,215,216,1,0,0,0,216,217,1,0,0,0,217,229,5,52,0,0,218,219,5,
        10,0,0,219,224,3,32,16,0,220,221,5,11,0,0,221,223,3,32,16,0,222,
        220,1,0,0,0,223,226,1,0,0,0,224,222,1,0,0,0,224,225,1,0,0,0,225,
        227,1,0,0,0,226,224,1,0,0,0,227,228,5,12,0,0,228,230,1,0,0,0,229,
        218,1,0,0,0,229,230,1,0,0,0,230,231,1,0,0,0,231,232,5,2,0,0,232,
        31,1,0,0,0,233,234,3,12,6,0,234,235,5,1,0,0,235,236,3,94,47,0,236,
        33,1,0,0,0,237,238,5,20,0,0,238,239,3,88,44,0,239,242,5,6,0,0,240,
        243,3,54,27,0,241,243,3,92,46,0,242,240,1,0,0,0,242,241,1,0,0,0,
        243,244,1,0,0,0,244,245,5,7,0,0,245,35,1,0,0,0,246,247,5,39,0,0,
        247,248,3,84,42,0,248,254,5,6,0,0,249,253,3,10,5,0,250,253,3,38,
        19,0,251,253,3,92,46,0,252,249,1,0,0,0,252,250,1,0,0,0,252,251,1,
        0,0,0,253,256,1,0,0,0,254,252,1,0,0,0,254,255,1,0,0,0,255,257,1,
        0,0,0,256,254,1,0,0,0,257,258,5,7,0,0,258,37,1,0,0,0,259,260,5,38,
        0,0,260,261,3,86,43,0,261,263,5,3,0,0,262,264,5,44,0,0,263,262,1,
        0,0,0,263,264,1,0,0,0,264,265,1,0,0,0,265,266,3,88,44,0,266,267,
        5,4,0,0,267,268,5,37,0,0,268,270,5,3,0,0,269,271,5,44,0,0,270,269,
        1,0,0,0,270,271,1,0,0,0,271,272,1,0,0,0,272,273,3,88,44,0,273,284,
        5,4,0,0,274,279,5,6,0,0,275,278,3,10,5,0,276,278,3,92,46,0,277,275,
        1,0,0,0,277,276,1,0,0,0,278,281,1,0,0,0,279,277,1,0,0,0,279,280,
        1,0,0,0,280,282,1,0,0,0,281,279,1,0,0,0,282,285,5,7,0,0,283,285,
        5,2,0,0,284,274,1,0,0,0,284,283,1,0,0,0,285,39,1,0,0,0,286,289,5,
        36,0,0,287,290,3,42,21,0,288,290,3,46,23,0,289,287,1,0,0,0,289,288,
        1,0,0,0,290,291,1,0,0,0,291,292,5,2,0,0,292,41,1,0,0,0,293,298,3,
        44,22,0,294,295,5,11,0,0,295,297,3,44,22,0,296,294,1,0,0,0,297,300,
        1,0,0,0,298,296,1,0,0,0,298,299,1,0,0,0,299,43,1,0,0,0,300,298,1,
        0,0,0,301,306,5,52,0,0,302,303,5,52,0,0,303,304,5,47,0,0,304,306,
        5,52,0,0,305,301,1,0,0,0,305,302,1,0,0,0,306,45,1,0,0,0,307,312,
        5,55,0,0,308,309,5,11,0,0,309,311,5,55,0,0,310,308,1,0,0,0,311,314,
        1,0,0,0,312,310,1,0,0,0,312,313,1,0,0,0,313,47,1,0,0,0,314,312,1,
        0,0,0,315,318,3,50,25,0,316,318,3,90,45,0,317,315,1,0,0,0,317,316,
        1,0,0,0,318,49,1,0,0,0,319,320,7,2,0,0,320,51,1,0,0,0,321,322,5,
        52,0,0,322,53,1,0,0,0,323,325,5,35,0,0,324,323,1,0,0,0,324,325,1,
        0,0,0,325,326,1,0,0,0,326,327,3,48,24,0,327,328,3,78,39,0,328,329,
        5,1,0,0,329,334,3,52,26,0,330,331,5,10,0,0,331,332,3,56,28,0,332,
        333,5,12,0,0,333,335,1,0,0,0,334,330,1,0,0,0,334,335,1,0,0,0,335,
        336,1,0,0,0,336,337,5,2,0,0,337,55,1,0,0,0,338,343,3,58,29,0,339,
        340,5,11,0,0,340,342,3,58,29,0,341,339,1,0,0,0,342,345,1,0,0,0,343,
        341,1,0,0,0,343,344,1,0,0,0,344,57,1,0,0,0,345,343,1,0,0,0,346,347,
        3,12,6,0,347,348,5,1,0,0,348,349,3,94,47,0,349,59,1,0,0,0,350,351,
        5,29,0,0,351,352,3,80,40,0,352,357,5,6,0,0,353,356,3,62,31,0,354,
        356,3,92,46,0,355,353,1,0,0,0,355,354,1,0,0,0,356,359,1,0,0,0,357,
        355,1,0,0,0,357,358,1,0,0,0,358,360,1,0,0,0,359,357,1,0,0,0,360,
        361,5,7,0,0,361,61,1,0,0,0,362,363,3,48,24,0,363,364,3,78,39,0,364,
        365,5,1,0,0,365,370,3,52,26,0,366,367,5,10,0,0,367,368,3,56,28,0,
        368,369,5,12,0,0,369,371,1,0,0,0,370,366,1,0,0,0,370,371,1,0,0,0,
        371,372,1,0,0,0,372,373,5,2,0,0,373,63,1,0,0,0,374,375,5,27,0,0,
        375,376,5,13,0,0,376,377,3,66,33,0,377,378,5,11,0,0,378,379,3,48,
        24,0,379,380,5,14,0,0,380,381,3,82,41,0,381,382,5,1,0,0,382,387,
        3,52,26,0,383,384,5,10,0,0,384,385,3,56,28,0,385,386,5,12,0,0,386,
        388,1,0,0,0,387,383,1,0,0,0,387,388,1,0,0,0,388,389,1,0,0,0,389,
        390,5,2,0,0,390,65,1,0,0,0,391,392,7,3,0,0,392,67,1,0,0,0,393,394,
        7,4,0,0,394,69,1,0,0,0,395,400,5,51,0,0,396,397,5,5,0,0,397,399,
        5,51,0,0,398,396,1,0,0,0,399,402,1,0,0,0,400,398,1,0,0,0,400,401,
        1,0,0,0,401,71,1,0,0,0,402,400,1,0,0,0,403,404,5,51,0,0,404,73,1,
        0,0,0,405,406,5,51,0,0,406,75,1,0,0,0,407,408,5,51,0,0,408,77,1,
        0,0,0,409,412,5,51,0,0,410,412,3,68,34,0,411,409,1,0,0,0,411,410,
        1,0,0,0,412,79,1,0,0,0,413,414,5,51,0,0,414,81,1,0,0,0,415,416,5,
        51,0,0,416,83,1,0,0,0,417,418,5,51,0,0,418,85,1,0,0,0,419,420,5,
        51,0,0,420,87,1,0,0,0,421,423,5,5,0,0,422,421,1,0,0,0,422,423,1,
        0,0,0,423,428,1,0,0,0,424,425,5,51,0,0,425,427,5,5,0,0,426,424,1,
        0,0,0,427,430,1,0,0,0,428,426,1,0,0,0,428,429,1,0,0,0,429,431,1,
        0,0,0,430,428,1,0,0,0,431,432,3,72,36,0,432,89,1,0,0,0,433,435,5,
        5,0,0,434,433,1,0,0,0,434,435,1,0,0,0,435,443,1,0,0,0,436,439,5,
        51,0,0,437,439,3,68,34,0,438,436,1,0,0,0,438,437,1,0,0,0,439,440,
        1,0,0,0,440,442,5,5,0,0,441,438,1,0,0,0,442,445,1,0,0,0,443,441,
        1,0,0,0,443,444,1,0,0,0,444,446,1,0,0,0,445,443,1,0,0,0,446,447,
        3,76,38,0,447,91,1,0,0,0,448,449,5,2,0,0,449,93,1,0,0,0,450,462,
        3,70,35,0,451,453,7,5,0,0,452,451,1,0,0,0,452,453,1,0,0,0,453,454,
        1,0,0,0,454,462,5,52,0,0,455,457,7,5,0,0,456,455,1,0,0,0,456,457,
        1,0,0,0,457,458,1,0,0,0,458,462,5,53,0,0,459,462,5,55,0,0,460,462,
        5,54,0,0,461,450,1,0,0,0,461,452,1,0,0,0,461,456,1,0,0,0,461,459,
        1,0,0,0,461,460,1,0,0,0,462,95,1,0,0,0,46,100,115,119,133,142,147,
        151,158,171,181,195,205,207,215,224,229,242,252,254,263,270,277,
        279,284,289,298,305,312,317,324,334,343,355,357,370,387,400,411,
        422,428,434,438,443,452,456,461
    ]

class Protobuf3Parser ( Parser ):

    grammarFileName = "Protobuf3.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'='", "';'", "'('", "')'", "'.'", "'{'", 
                     "'}'", "':'", "'-'", "'['", "','", "']'", "'<'", "'>'", 
                     "'+'", "'bool'", "'bytes'", "'double'", "'enum'", "'extend'", 
                     "'fixed32'", "'fixed64'", "'float'", "'import'", "'int32'", 
                     "'int64'", "'map'", "'message'", "'oneof'", "'option'", 
                     "'package'", "'\"proto3\"'", "''proto3''", "'public'", 
                     "'repeated'", "'reserved'", "'returns'", "'rpc'", "'service'", 
                     "'sfixed32'", "'sfixed64'", "'sint32'", "'sint64'", 
                     "'stream'", "'string'", "'syntax'", "'to'", "'uint32'", 
                     "'uint64'", "'weak'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "BOOL", "BYTES", "DOUBLE", "ENUM", "EXTEND", "FIXED32", 
                      "FIXED64", "FLOAT", "IMPORT", "INT32", "INT64", "MAP", 
                      "MESSAGE", "ONEOF", "OPTION", "PACKAGE", "PROTO3_DOUBLE", 
                      "PROTO3_SINGLE", "PUBLIC", "REPEATED", "RESERVED", 
                      "RETURNS", "RPC", "SERVICE", "SFIXED32", "SFIXED64", 
                      "SINT32", "SINT64", "STREAM", "STRING", "SYNTAX", 
                      "TO", "UINT32", "UINT64", "WEAK", "IDENT", "INT_LIT", 
                      "FLOAT_LIT", "BOOL_LIT", "STR_LIT", "QUOTE", "WS", 
                      "COMMENT", "LINE_COMMENT" ]

    RULE_proto = 0
    RULE_syntax = 1
    RULE_syntaxExtra = 2
    RULE_importStmt = 3
    RULE_packageStmt = 4
    RULE_option = 5
    RULE_optionName = 6
    RULE_optionBody = 7
    RULE_optionBodyVariable = 8
    RULE_topLevelDef = 9
    RULE_message = 10
    RULE_messageBody = 11
    RULE_messageBodyContent = 12
    RULE_enumDef = 13
    RULE_enumBody = 14
    RULE_enumField = 15
    RULE_enumValueOption = 16
    RULE_extend = 17
    RULE_service = 18
    RULE_rpc = 19
    RULE_reserved = 20
    RULE_ranges = 21
    RULE_rangeRule = 22
    RULE_fieldNames = 23
    RULE_typeRule = 24
    RULE_simpleType = 25
    RULE_fieldNumber = 26
    RULE_field = 27
    RULE_fieldOptions = 28
    RULE_fieldOption = 29
    RULE_oneof = 30
    RULE_oneofField = 31
    RULE_mapField = 32
    RULE_keyType = 33
    RULE_reservedWord = 34
    RULE_fullIdent = 35
    RULE_messageName = 36
    RULE_enumName = 37
    RULE_messageOrEnumName = 38
    RULE_fieldName = 39
    RULE_oneofName = 40
    RULE_mapName = 41
    RULE_serviceName = 42
    RULE_rpcName = 43
    RULE_messageType = 44
    RULE_messageOrEnumType = 45
    RULE_emptyStmt = 46
    RULE_constant = 47

    ruleNames =  [ "proto", "syntax", "syntaxExtra", "importStmt", "packageStmt", 
                   "option", "optionName", "optionBody", "optionBodyVariable", 
                   "topLevelDef", "message", "messageBody", "messageBodyContent", 
                   "enumDef", "enumBody", "enumField", "enumValueOption", 
                   "extend", "service", "rpc", "reserved", "ranges", "rangeRule", 
                   "fieldNames", "typeRule", "simpleType", "fieldNumber", 
                   "field", "fieldOptions", "fieldOption", "oneof", "oneofField", 
                   "mapField", "keyType", "reservedWord", "fullIdent", "messageName", 
                   "enumName", "messageOrEnumName", "fieldName", "oneofName", 
                   "mapName", "serviceName", "rpcName", "messageType", "messageOrEnumType", 
                   "emptyStmt", "constant" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    BOOL=16
    BYTES=17
    DOUBLE=18
    ENUM=19
    EXTEND=20
    FIXED32=21
    FIXED64=22
    FLOAT=23
    IMPORT=24
    INT32=25
    INT64=26
    MAP=27
    MESSAGE=28
    ONEOF=29
    OPTION=30
    PACKAGE=31
    PROTO3_DOUBLE=32
    PROTO3_SINGLE=33
    PUBLIC=34
    REPEATED=35
    RESERVED=36
    RETURNS=37
    RPC=38
    SERVICE=39
    SFIXED32=40
    SFIXED64=41
    SINT32=42
    SINT64=43
    STREAM=44
    STRING=45
    SYNTAX=46
    TO=47
    UINT32=48
    UINT64=49
    WEAK=50
    IDENT=51
    INT_LIT=52
    FLOAT_LIT=53
    BOOL_LIT=54
    STR_LIT=55
    QUOTE=56
    WS=57
    COMMENT=58
    LINE_COMMENT=59

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProtoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def syntax(self):
            return self.getTypedRuleContext(Protobuf3Parser.SyntaxContext,0)


        def EOF(self):
            return self.getToken(Protobuf3Parser.EOF, 0)

        def syntaxExtra(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.SyntaxExtraContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.SyntaxExtraContext,i)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_proto

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProto" ):
                listener.enterProto(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProto" ):
                listener.exitProto(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProto" ):
                return visitor.visitProto(self)
            else:
                return visitor.visitChildren(self)




    def proto(self):

        localctx = Protobuf3Parser.ProtoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_proto)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 96
            self.syntax()
            self.state = 100
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 553263824900) != 0):
                self.state = 97
                self.syntaxExtra()
                self.state = 102
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 103
            self.match(Protobuf3Parser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SyntaxContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SYNTAX(self):
            return self.getToken(Protobuf3Parser.SYNTAX, 0)

        def PROTO3_DOUBLE(self):
            return self.getToken(Protobuf3Parser.PROTO3_DOUBLE, 0)

        def PROTO3_SINGLE(self):
            return self.getToken(Protobuf3Parser.PROTO3_SINGLE, 0)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_syntax

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSyntax" ):
                listener.enterSyntax(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSyntax" ):
                listener.exitSyntax(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSyntax" ):
                return visitor.visitSyntax(self)
            else:
                return visitor.visitChildren(self)




    def syntax(self):

        localctx = Protobuf3Parser.SyntaxContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_syntax)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 105
            self.match(Protobuf3Parser.SYNTAX)
            self.state = 106
            self.match(Protobuf3Parser.T__0)
            self.state = 107
            _la = self._input.LA(1)
            if not(_la==32 or _la==33):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 108
            self.match(Protobuf3Parser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SyntaxExtraContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def importStmt(self):
            return self.getTypedRuleContext(Protobuf3Parser.ImportStmtContext,0)


        def packageStmt(self):
            return self.getTypedRuleContext(Protobuf3Parser.PackageStmtContext,0)


        def option(self):
            return self.getTypedRuleContext(Protobuf3Parser.OptionContext,0)


        def topLevelDef(self):
            return self.getTypedRuleContext(Protobuf3Parser.TopLevelDefContext,0)


        def emptyStmt(self):
            return self.getTypedRuleContext(Protobuf3Parser.EmptyStmtContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_syntaxExtra

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSyntaxExtra" ):
                listener.enterSyntaxExtra(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSyntaxExtra" ):
                listener.exitSyntaxExtra(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSyntaxExtra" ):
                return visitor.visitSyntaxExtra(self)
            else:
                return visitor.visitChildren(self)




    def syntaxExtra(self):

        localctx = Protobuf3Parser.SyntaxExtraContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_syntaxExtra)
        try:
            self.state = 115
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [24]:
                self.enterOuterAlt(localctx, 1)
                self.state = 110
                self.importStmt()
                pass
            elif token in [31]:
                self.enterOuterAlt(localctx, 2)
                self.state = 111
                self.packageStmt()
                pass
            elif token in [30]:
                self.enterOuterAlt(localctx, 3)
                self.state = 112
                self.option()
                pass
            elif token in [19, 20, 28, 39]:
                self.enterOuterAlt(localctx, 4)
                self.state = 113
                self.topLevelDef()
                pass
            elif token in [2]:
                self.enterOuterAlt(localctx, 5)
                self.state = 114
                self.emptyStmt()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ImportStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IMPORT(self):
            return self.getToken(Protobuf3Parser.IMPORT, 0)

        def STR_LIT(self):
            return self.getToken(Protobuf3Parser.STR_LIT, 0)

        def WEAK(self):
            return self.getToken(Protobuf3Parser.WEAK, 0)

        def PUBLIC(self):
            return self.getToken(Protobuf3Parser.PUBLIC, 0)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_importStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterImportStmt" ):
                listener.enterImportStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitImportStmt" ):
                listener.exitImportStmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitImportStmt" ):
                return visitor.visitImportStmt(self)
            else:
                return visitor.visitChildren(self)




    def importStmt(self):

        localctx = Protobuf3Parser.ImportStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_importStmt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 117
            self.match(Protobuf3Parser.IMPORT)
            self.state = 119
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==34 or _la==50:
                self.state = 118
                _la = self._input.LA(1)
                if not(_la==34 or _la==50):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 121
            self.match(Protobuf3Parser.STR_LIT)
            self.state = 122
            self.match(Protobuf3Parser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PackageStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PACKAGE(self):
            return self.getToken(Protobuf3Parser.PACKAGE, 0)

        def fullIdent(self):
            return self.getTypedRuleContext(Protobuf3Parser.FullIdentContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_packageStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPackageStmt" ):
                listener.enterPackageStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPackageStmt" ):
                listener.exitPackageStmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPackageStmt" ):
                return visitor.visitPackageStmt(self)
            else:
                return visitor.visitChildren(self)




    def packageStmt(self):

        localctx = Protobuf3Parser.PackageStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_packageStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 124
            self.match(Protobuf3Parser.PACKAGE)
            self.state = 125
            self.fullIdent()
            self.state = 126
            self.match(Protobuf3Parser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OptionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OPTION(self):
            return self.getToken(Protobuf3Parser.OPTION, 0)

        def optionName(self):
            return self.getTypedRuleContext(Protobuf3Parser.OptionNameContext,0)


        def constant(self):
            return self.getTypedRuleContext(Protobuf3Parser.ConstantContext,0)


        def optionBody(self):
            return self.getTypedRuleContext(Protobuf3Parser.OptionBodyContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_option

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOption" ):
                listener.enterOption(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOption" ):
                listener.exitOption(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOption" ):
                return visitor.visitOption(self)
            else:
                return visitor.visitChildren(self)




    def option(self):

        localctx = Protobuf3Parser.OptionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_option)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 128
            self.match(Protobuf3Parser.OPTION)
            self.state = 129
            self.optionName()
            self.state = 130
            self.match(Protobuf3Parser.T__0)
            self.state = 133
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [9, 15, 51, 52, 53, 54, 55]:
                self.state = 131
                self.constant()
                pass
            elif token in [6]:
                self.state = 132
                self.optionBody()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 135
            self.match(Protobuf3Parser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OptionNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self, i:int=None):
            if i is None:
                return self.getTokens(Protobuf3Parser.IDENT)
            else:
                return self.getToken(Protobuf3Parser.IDENT, i)

        def fullIdent(self):
            return self.getTypedRuleContext(Protobuf3Parser.FullIdentContext,0)


        def reservedWord(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.ReservedWordContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.ReservedWordContext,i)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_optionName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOptionName" ):
                listener.enterOptionName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOptionName" ):
                listener.exitOptionName(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOptionName" ):
                return visitor.visitOptionName(self)
            else:
                return visitor.visitChildren(self)




    def optionName(self):

        localctx = Protobuf3Parser.OptionNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_optionName)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 142
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [51]:
                self.state = 137
                self.match(Protobuf3Parser.IDENT)
                pass
            elif token in [3]:
                self.state = 138
                self.match(Protobuf3Parser.T__2)
                self.state = 139
                self.fullIdent()
                self.state = 140
                self.match(Protobuf3Parser.T__3)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 151
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==5:
                self.state = 144
                self.match(Protobuf3Parser.T__4)
                self.state = 147
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [51]:
                    self.state = 145
                    self.match(Protobuf3Parser.IDENT)
                    pass
                elif token in [20, 28, 30, 31, 38, 39, 44, 45, 46, 50]:
                    self.state = 146
                    self.reservedWord()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 153
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OptionBodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def optionBodyVariable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.OptionBodyVariableContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.OptionBodyVariableContext,i)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_optionBody

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOptionBody" ):
                listener.enterOptionBody(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOptionBody" ):
                listener.exitOptionBody(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOptionBody" ):
                return visitor.visitOptionBody(self)
            else:
                return visitor.visitChildren(self)




    def optionBody(self):

        localctx = Protobuf3Parser.OptionBodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_optionBody)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 154
            self.match(Protobuf3Parser.T__5)
            self.state = 158
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==3 or _la==51:
                self.state = 155
                self.optionBodyVariable()
                self.state = 160
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 161
            self.match(Protobuf3Parser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OptionBodyVariableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def optionName(self):
            return self.getTypedRuleContext(Protobuf3Parser.OptionNameContext,0)


        def constant(self):
            return self.getTypedRuleContext(Protobuf3Parser.ConstantContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_optionBodyVariable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOptionBodyVariable" ):
                listener.enterOptionBodyVariable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOptionBodyVariable" ):
                listener.exitOptionBodyVariable(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOptionBodyVariable" ):
                return visitor.visitOptionBodyVariable(self)
            else:
                return visitor.visitChildren(self)




    def optionBodyVariable(self):

        localctx = Protobuf3Parser.OptionBodyVariableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_optionBodyVariable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 163
            self.optionName()
            self.state = 164
            self.match(Protobuf3Parser.T__7)
            self.state = 165
            self.constant()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TopLevelDefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def message(self):
            return self.getTypedRuleContext(Protobuf3Parser.MessageContext,0)


        def enumDef(self):
            return self.getTypedRuleContext(Protobuf3Parser.EnumDefContext,0)


        def extend(self):
            return self.getTypedRuleContext(Protobuf3Parser.ExtendContext,0)


        def service(self):
            return self.getTypedRuleContext(Protobuf3Parser.ServiceContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_topLevelDef

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTopLevelDef" ):
                listener.enterTopLevelDef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTopLevelDef" ):
                listener.exitTopLevelDef(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTopLevelDef" ):
                return visitor.visitTopLevelDef(self)
            else:
                return visitor.visitChildren(self)




    def topLevelDef(self):

        localctx = Protobuf3Parser.TopLevelDefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_topLevelDef)
        try:
            self.state = 171
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [28]:
                self.enterOuterAlt(localctx, 1)
                self.state = 167
                self.message()
                pass
            elif token in [19]:
                self.enterOuterAlt(localctx, 2)
                self.state = 168
                self.enumDef()
                pass
            elif token in [20]:
                self.enterOuterAlt(localctx, 3)
                self.state = 169
                self.extend()
                pass
            elif token in [39]:
                self.enterOuterAlt(localctx, 4)
                self.state = 170
                self.service()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MessageContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MESSAGE(self):
            return self.getToken(Protobuf3Parser.MESSAGE, 0)

        def messageName(self):
            return self.getTypedRuleContext(Protobuf3Parser.MessageNameContext,0)


        def messageBody(self):
            return self.getTypedRuleContext(Protobuf3Parser.MessageBodyContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_message

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMessage" ):
                listener.enterMessage(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMessage" ):
                listener.exitMessage(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMessage" ):
                return visitor.visitMessage(self)
            else:
                return visitor.visitChildren(self)




    def message(self):

        localctx = Protobuf3Parser.MessageContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_message)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 173
            self.match(Protobuf3Parser.MESSAGE)
            self.state = 174
            self.messageName()
            self.state = 175
            self.messageBody()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MessageBodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def messageBodyContent(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.MessageBodyContentContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.MessageBodyContentContext,i)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_messageBody

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMessageBody" ):
                listener.enterMessageBody(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMessageBody" ):
                listener.exitMessageBody(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMessageBody" ):
                return visitor.visitMessageBody(self)
            else:
                return visitor.visitChildren(self)




    def messageBody(self):

        localctx = Protobuf3Parser.MessageBodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_messageBody)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 177
            self.match(Protobuf3Parser.T__5)
            self.state = 181
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 4362694618447908) != 0):
                self.state = 178
                self.messageBodyContent()
                self.state = 183
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 184
            self.match(Protobuf3Parser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MessageBodyContentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def field(self):
            return self.getTypedRuleContext(Protobuf3Parser.FieldContext,0)


        def enumDef(self):
            return self.getTypedRuleContext(Protobuf3Parser.EnumDefContext,0)


        def message(self):
            return self.getTypedRuleContext(Protobuf3Parser.MessageContext,0)


        def extend(self):
            return self.getTypedRuleContext(Protobuf3Parser.ExtendContext,0)


        def option(self):
            return self.getTypedRuleContext(Protobuf3Parser.OptionContext,0)


        def oneof(self):
            return self.getTypedRuleContext(Protobuf3Parser.OneofContext,0)


        def mapField(self):
            return self.getTypedRuleContext(Protobuf3Parser.MapFieldContext,0)


        def reserved(self):
            return self.getTypedRuleContext(Protobuf3Parser.ReservedContext,0)


        def emptyStmt(self):
            return self.getTypedRuleContext(Protobuf3Parser.EmptyStmtContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_messageBodyContent

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMessageBodyContent" ):
                listener.enterMessageBodyContent(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMessageBodyContent" ):
                listener.exitMessageBodyContent(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMessageBodyContent" ):
                return visitor.visitMessageBodyContent(self)
            else:
                return visitor.visitChildren(self)




    def messageBodyContent(self):

        localctx = Protobuf3Parser.MessageBodyContentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_messageBodyContent)
        try:
            self.state = 195
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,10,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 186
                self.field()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 187
                self.enumDef()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 188
                self.message()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 189
                self.extend()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 190
                self.option()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 191
                self.oneof()
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 192
                self.mapField()
                pass

            elif la_ == 8:
                self.enterOuterAlt(localctx, 8)
                self.state = 193
                self.reserved()
                pass

            elif la_ == 9:
                self.enterOuterAlt(localctx, 9)
                self.state = 194
                self.emptyStmt()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EnumDefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ENUM(self):
            return self.getToken(Protobuf3Parser.ENUM, 0)

        def enumName(self):
            return self.getTypedRuleContext(Protobuf3Parser.EnumNameContext,0)


        def enumBody(self):
            return self.getTypedRuleContext(Protobuf3Parser.EnumBodyContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_enumDef

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEnumDef" ):
                listener.enterEnumDef(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEnumDef" ):
                listener.exitEnumDef(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEnumDef" ):
                return visitor.visitEnumDef(self)
            else:
                return visitor.visitChildren(self)




    def enumDef(self):

        localctx = Protobuf3Parser.EnumDefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_enumDef)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 197
            self.match(Protobuf3Parser.ENUM)
            self.state = 198
            self.enumName()
            self.state = 199
            self.enumBody()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EnumBodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def option(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.OptionContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.OptionContext,i)


        def enumField(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.EnumFieldContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.EnumFieldContext,i)


        def emptyStmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.EmptyStmtContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.EmptyStmtContext,i)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_enumBody

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEnumBody" ):
                listener.enterEnumBody(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEnumBody" ):
                listener.exitEnumBody(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEnumBody" ):
                return visitor.visitEnumBody(self)
            else:
                return visitor.visitChildren(self)




    def enumBody(self):

        localctx = Protobuf3Parser.EnumBodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_enumBody)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 201
            self.match(Protobuf3Parser.T__5)
            self.state = 207
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 2251800887427076) != 0):
                self.state = 205
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [30]:
                    self.state = 202
                    self.option()
                    pass
                elif token in [51]:
                    self.state = 203
                    self.enumField()
                    pass
                elif token in [2]:
                    self.state = 204
                    self.emptyStmt()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 209
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 210
            self.match(Protobuf3Parser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EnumFieldContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self):
            return self.getToken(Protobuf3Parser.IDENT, 0)

        def INT_LIT(self):
            return self.getToken(Protobuf3Parser.INT_LIT, 0)

        def enumValueOption(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.EnumValueOptionContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.EnumValueOptionContext,i)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_enumField

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEnumField" ):
                listener.enterEnumField(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEnumField" ):
                listener.exitEnumField(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEnumField" ):
                return visitor.visitEnumField(self)
            else:
                return visitor.visitChildren(self)




    def enumField(self):

        localctx = Protobuf3Parser.EnumFieldContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_enumField)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 212
            self.match(Protobuf3Parser.IDENT)
            self.state = 213
            self.match(Protobuf3Parser.T__0)
            self.state = 215
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==9:
                self.state = 214
                self.match(Protobuf3Parser.T__8)


            self.state = 217
            self.match(Protobuf3Parser.INT_LIT)
            self.state = 229
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 218
                self.match(Protobuf3Parser.T__9)
                self.state = 219
                self.enumValueOption()
                self.state = 224
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==11:
                    self.state = 220
                    self.match(Protobuf3Parser.T__10)
                    self.state = 221
                    self.enumValueOption()
                    self.state = 226
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 227
                self.match(Protobuf3Parser.T__11)


            self.state = 231
            self.match(Protobuf3Parser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EnumValueOptionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def optionName(self):
            return self.getTypedRuleContext(Protobuf3Parser.OptionNameContext,0)


        def constant(self):
            return self.getTypedRuleContext(Protobuf3Parser.ConstantContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_enumValueOption

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEnumValueOption" ):
                listener.enterEnumValueOption(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEnumValueOption" ):
                listener.exitEnumValueOption(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEnumValueOption" ):
                return visitor.visitEnumValueOption(self)
            else:
                return visitor.visitChildren(self)




    def enumValueOption(self):

        localctx = Protobuf3Parser.EnumValueOptionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_enumValueOption)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 233
            self.optionName()
            self.state = 234
            self.match(Protobuf3Parser.T__0)
            self.state = 235
            self.constant()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExtendContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EXTEND(self):
            return self.getToken(Protobuf3Parser.EXTEND, 0)

        def messageType(self):
            return self.getTypedRuleContext(Protobuf3Parser.MessageTypeContext,0)


        def field(self):
            return self.getTypedRuleContext(Protobuf3Parser.FieldContext,0)


        def emptyStmt(self):
            return self.getTypedRuleContext(Protobuf3Parser.EmptyStmtContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_extend

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExtend" ):
                listener.enterExtend(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExtend" ):
                listener.exitExtend(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExtend" ):
                return visitor.visitExtend(self)
            else:
                return visitor.visitChildren(self)




    def extend(self):

        localctx = Protobuf3Parser.ExtendContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_extend)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 237
            self.match(Protobuf3Parser.EXTEND)
            self.state = 238
            self.messageType()
            self.state = 239
            self.match(Protobuf3Parser.T__5)
            self.state = 242
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [5, 16, 17, 18, 20, 21, 22, 23, 25, 26, 28, 30, 31, 35, 38, 39, 40, 41, 42, 43, 44, 45, 46, 48, 49, 50, 51]:
                self.state = 240
                self.field()
                pass
            elif token in [2]:
                self.state = 241
                self.emptyStmt()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 244
            self.match(Protobuf3Parser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ServiceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SERVICE(self):
            return self.getToken(Protobuf3Parser.SERVICE, 0)

        def serviceName(self):
            return self.getTypedRuleContext(Protobuf3Parser.ServiceNameContext,0)


        def option(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.OptionContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.OptionContext,i)


        def rpc(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.RpcContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.RpcContext,i)


        def emptyStmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.EmptyStmtContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.EmptyStmtContext,i)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_service

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterService" ):
                listener.enterService(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitService" ):
                listener.exitService(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitService" ):
                return visitor.visitService(self)
            else:
                return visitor.visitChildren(self)




    def service(self):

        localctx = Protobuf3Parser.ServiceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_service)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 246
            self.match(Protobuf3Parser.SERVICE)
            self.state = 247
            self.serviceName()
            self.state = 248
            self.match(Protobuf3Parser.T__5)
            self.state = 254
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 275951648772) != 0):
                self.state = 252
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [30]:
                    self.state = 249
                    self.option()
                    pass
                elif token in [38]:
                    self.state = 250
                    self.rpc()
                    pass
                elif token in [2]:
                    self.state = 251
                    self.emptyStmt()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 256
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 257
            self.match(Protobuf3Parser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RpcContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RPC(self):
            return self.getToken(Protobuf3Parser.RPC, 0)

        def rpcName(self):
            return self.getTypedRuleContext(Protobuf3Parser.RpcNameContext,0)


        def messageType(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.MessageTypeContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.MessageTypeContext,i)


        def RETURNS(self):
            return self.getToken(Protobuf3Parser.RETURNS, 0)

        def STREAM(self, i:int=None):
            if i is None:
                return self.getTokens(Protobuf3Parser.STREAM)
            else:
                return self.getToken(Protobuf3Parser.STREAM, i)

        def option(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.OptionContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.OptionContext,i)


        def emptyStmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.EmptyStmtContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.EmptyStmtContext,i)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_rpc

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRpc" ):
                listener.enterRpc(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRpc" ):
                listener.exitRpc(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRpc" ):
                return visitor.visitRpc(self)
            else:
                return visitor.visitChildren(self)




    def rpc(self):

        localctx = Protobuf3Parser.RpcContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_rpc)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 259
            self.match(Protobuf3Parser.RPC)
            self.state = 260
            self.rpcName()
            self.state = 261
            self.match(Protobuf3Parser.T__2)
            self.state = 263
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==44:
                self.state = 262
                self.match(Protobuf3Parser.STREAM)


            self.state = 265
            self.messageType()
            self.state = 266
            self.match(Protobuf3Parser.T__3)
            self.state = 267
            self.match(Protobuf3Parser.RETURNS)
            self.state = 268
            self.match(Protobuf3Parser.T__2)
            self.state = 270
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==44:
                self.state = 269
                self.match(Protobuf3Parser.STREAM)


            self.state = 272
            self.messageType()
            self.state = 273
            self.match(Protobuf3Parser.T__3)
            self.state = 284
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [6]:
                self.state = 274
                self.match(Protobuf3Parser.T__5)
                self.state = 279
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==2 or _la==30:
                    self.state = 277
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [30]:
                        self.state = 275
                        self.option()
                        pass
                    elif token in [2]:
                        self.state = 276
                        self.emptyStmt()
                        pass
                    else:
                        raise NoViableAltException(self)

                    self.state = 281
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 282
                self.match(Protobuf3Parser.T__6)
                pass
            elif token in [2]:
                self.state = 283
                self.match(Protobuf3Parser.T__1)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReservedContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RESERVED(self):
            return self.getToken(Protobuf3Parser.RESERVED, 0)

        def ranges(self):
            return self.getTypedRuleContext(Protobuf3Parser.RangesContext,0)


        def fieldNames(self):
            return self.getTypedRuleContext(Protobuf3Parser.FieldNamesContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_reserved

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReserved" ):
                listener.enterReserved(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReserved" ):
                listener.exitReserved(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReserved" ):
                return visitor.visitReserved(self)
            else:
                return visitor.visitChildren(self)




    def reserved(self):

        localctx = Protobuf3Parser.ReservedContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_reserved)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 286
            self.match(Protobuf3Parser.RESERVED)
            self.state = 289
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [52]:
                self.state = 287
                self.ranges()
                pass
            elif token in [55]:
                self.state = 288
                self.fieldNames()
                pass
            else:
                raise NoViableAltException(self)

            self.state = 291
            self.match(Protobuf3Parser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RangesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def rangeRule(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.RangeRuleContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.RangeRuleContext,i)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_ranges

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRanges" ):
                listener.enterRanges(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRanges" ):
                listener.exitRanges(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRanges" ):
                return visitor.visitRanges(self)
            else:
                return visitor.visitChildren(self)




    def ranges(self):

        localctx = Protobuf3Parser.RangesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_ranges)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 293
            self.rangeRule()
            self.state = 298
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==11:
                self.state = 294
                self.match(Protobuf3Parser.T__10)
                self.state = 295
                self.rangeRule()
                self.state = 300
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RangeRuleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT_LIT(self, i:int=None):
            if i is None:
                return self.getTokens(Protobuf3Parser.INT_LIT)
            else:
                return self.getToken(Protobuf3Parser.INT_LIT, i)

        def TO(self):
            return self.getToken(Protobuf3Parser.TO, 0)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_rangeRule

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRangeRule" ):
                listener.enterRangeRule(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRangeRule" ):
                listener.exitRangeRule(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRangeRule" ):
                return visitor.visitRangeRule(self)
            else:
                return visitor.visitChildren(self)




    def rangeRule(self):

        localctx = Protobuf3Parser.RangeRuleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_rangeRule)
        try:
            self.state = 305
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,26,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 301
                self.match(Protobuf3Parser.INT_LIT)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 302
                self.match(Protobuf3Parser.INT_LIT)
                self.state = 303
                self.match(Protobuf3Parser.TO)
                self.state = 304
                self.match(Protobuf3Parser.INT_LIT)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FieldNamesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STR_LIT(self, i:int=None):
            if i is None:
                return self.getTokens(Protobuf3Parser.STR_LIT)
            else:
                return self.getToken(Protobuf3Parser.STR_LIT, i)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_fieldNames

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFieldNames" ):
                listener.enterFieldNames(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFieldNames" ):
                listener.exitFieldNames(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFieldNames" ):
                return visitor.visitFieldNames(self)
            else:
                return visitor.visitChildren(self)




    def fieldNames(self):

        localctx = Protobuf3Parser.FieldNamesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_fieldNames)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 307
            self.match(Protobuf3Parser.STR_LIT)
            self.state = 312
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==11:
                self.state = 308
                self.match(Protobuf3Parser.T__10)
                self.state = 309
                self.match(Protobuf3Parser.STR_LIT)
                self.state = 314
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeRuleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def simpleType(self):
            return self.getTypedRuleContext(Protobuf3Parser.SimpleTypeContext,0)


        def messageOrEnumType(self):
            return self.getTypedRuleContext(Protobuf3Parser.MessageOrEnumTypeContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_typeRule

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTypeRule" ):
                listener.enterTypeRule(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTypeRule" ):
                listener.exitTypeRule(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTypeRule" ):
                return visitor.visitTypeRule(self)
            else:
                return visitor.visitChildren(self)




    def typeRule(self):

        localctx = Protobuf3Parser.TypeRuleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_typeRule)
        try:
            self.state = 317
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,28,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 315
                self.simpleType()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 316
                self.messageOrEnumType()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SimpleTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DOUBLE(self):
            return self.getToken(Protobuf3Parser.DOUBLE, 0)

        def FLOAT(self):
            return self.getToken(Protobuf3Parser.FLOAT, 0)

        def INT32(self):
            return self.getToken(Protobuf3Parser.INT32, 0)

        def INT64(self):
            return self.getToken(Protobuf3Parser.INT64, 0)

        def UINT32(self):
            return self.getToken(Protobuf3Parser.UINT32, 0)

        def UINT64(self):
            return self.getToken(Protobuf3Parser.UINT64, 0)

        def SINT32(self):
            return self.getToken(Protobuf3Parser.SINT32, 0)

        def SINT64(self):
            return self.getToken(Protobuf3Parser.SINT64, 0)

        def FIXED32(self):
            return self.getToken(Protobuf3Parser.FIXED32, 0)

        def FIXED64(self):
            return self.getToken(Protobuf3Parser.FIXED64, 0)

        def SFIXED32(self):
            return self.getToken(Protobuf3Parser.SFIXED32, 0)

        def SFIXED64(self):
            return self.getToken(Protobuf3Parser.SFIXED64, 0)

        def BOOL(self):
            return self.getToken(Protobuf3Parser.BOOL, 0)

        def STRING(self):
            return self.getToken(Protobuf3Parser.STRING, 0)

        def BYTES(self):
            return self.getToken(Protobuf3Parser.BYTES, 0)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_simpleType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSimpleType" ):
                listener.enterSimpleType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSimpleType" ):
                listener.exitSimpleType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSimpleType" ):
                return visitor.visitSimpleType(self)
            else:
                return visitor.visitChildren(self)




    def simpleType(self):

        localctx = Protobuf3Parser.SimpleTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_simpleType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 319
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 896102092439552) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FieldNumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT_LIT(self):
            return self.getToken(Protobuf3Parser.INT_LIT, 0)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_fieldNumber

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFieldNumber" ):
                listener.enterFieldNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFieldNumber" ):
                listener.exitFieldNumber(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFieldNumber" ):
                return visitor.visitFieldNumber(self)
            else:
                return visitor.visitChildren(self)




    def fieldNumber(self):

        localctx = Protobuf3Parser.FieldNumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_fieldNumber)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 321
            self.match(Protobuf3Parser.INT_LIT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FieldContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def typeRule(self):
            return self.getTypedRuleContext(Protobuf3Parser.TypeRuleContext,0)


        def fieldName(self):
            return self.getTypedRuleContext(Protobuf3Parser.FieldNameContext,0)


        def fieldNumber(self):
            return self.getTypedRuleContext(Protobuf3Parser.FieldNumberContext,0)


        def REPEATED(self):
            return self.getToken(Protobuf3Parser.REPEATED, 0)

        def fieldOptions(self):
            return self.getTypedRuleContext(Protobuf3Parser.FieldOptionsContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_field

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterField" ):
                listener.enterField(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitField" ):
                listener.exitField(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitField" ):
                return visitor.visitField(self)
            else:
                return visitor.visitChildren(self)




    def field(self):

        localctx = Protobuf3Parser.FieldContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_field)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 324
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 323
                self.match(Protobuf3Parser.REPEATED)


            self.state = 326
            self.typeRule()
            self.state = 327
            self.fieldName()
            self.state = 328
            self.match(Protobuf3Parser.T__0)
            self.state = 329
            self.fieldNumber()
            self.state = 334
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 330
                self.match(Protobuf3Parser.T__9)
                self.state = 331
                self.fieldOptions()
                self.state = 332
                self.match(Protobuf3Parser.T__11)


            self.state = 336
            self.match(Protobuf3Parser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FieldOptionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fieldOption(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.FieldOptionContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.FieldOptionContext,i)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_fieldOptions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFieldOptions" ):
                listener.enterFieldOptions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFieldOptions" ):
                listener.exitFieldOptions(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFieldOptions" ):
                return visitor.visitFieldOptions(self)
            else:
                return visitor.visitChildren(self)




    def fieldOptions(self):

        localctx = Protobuf3Parser.FieldOptionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_fieldOptions)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 338
            self.fieldOption()
            self.state = 343
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==11:
                self.state = 339
                self.match(Protobuf3Parser.T__10)
                self.state = 340
                self.fieldOption()
                self.state = 345
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FieldOptionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def optionName(self):
            return self.getTypedRuleContext(Protobuf3Parser.OptionNameContext,0)


        def constant(self):
            return self.getTypedRuleContext(Protobuf3Parser.ConstantContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_fieldOption

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFieldOption" ):
                listener.enterFieldOption(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFieldOption" ):
                listener.exitFieldOption(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFieldOption" ):
                return visitor.visitFieldOption(self)
            else:
                return visitor.visitChildren(self)




    def fieldOption(self):

        localctx = Protobuf3Parser.FieldOptionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_fieldOption)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 346
            self.optionName()
            self.state = 347
            self.match(Protobuf3Parser.T__0)
            self.state = 348
            self.constant()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OneofContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ONEOF(self):
            return self.getToken(Protobuf3Parser.ONEOF, 0)

        def oneofName(self):
            return self.getTypedRuleContext(Protobuf3Parser.OneofNameContext,0)


        def oneofField(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.OneofFieldContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.OneofFieldContext,i)


        def emptyStmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.EmptyStmtContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.EmptyStmtContext,i)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_oneof

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOneof" ):
                listener.enterOneof(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOneof" ):
                listener.exitOneof(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOneof" ):
                return visitor.visitOneof(self)
            else:
                return visitor.visitChildren(self)




    def oneof(self):

        localctx = Protobuf3Parser.OneofContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_oneof)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 350
            self.match(Protobuf3Parser.ONEOF)
            self.state = 351
            self.oneofName()
            self.state = 352
            self.match(Protobuf3Parser.T__5)
            self.state = 357
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 4362590867619876) != 0):
                self.state = 355
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [5, 16, 17, 18, 20, 21, 22, 23, 25, 26, 28, 30, 31, 38, 39, 40, 41, 42, 43, 44, 45, 46, 48, 49, 50, 51]:
                    self.state = 353
                    self.oneofField()
                    pass
                elif token in [2]:
                    self.state = 354
                    self.emptyStmt()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 359
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 360
            self.match(Protobuf3Parser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OneofFieldContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def typeRule(self):
            return self.getTypedRuleContext(Protobuf3Parser.TypeRuleContext,0)


        def fieldName(self):
            return self.getTypedRuleContext(Protobuf3Parser.FieldNameContext,0)


        def fieldNumber(self):
            return self.getTypedRuleContext(Protobuf3Parser.FieldNumberContext,0)


        def fieldOptions(self):
            return self.getTypedRuleContext(Protobuf3Parser.FieldOptionsContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_oneofField

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOneofField" ):
                listener.enterOneofField(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOneofField" ):
                listener.exitOneofField(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOneofField" ):
                return visitor.visitOneofField(self)
            else:
                return visitor.visitChildren(self)




    def oneofField(self):

        localctx = Protobuf3Parser.OneofFieldContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_oneofField)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 362
            self.typeRule()
            self.state = 363
            self.fieldName()
            self.state = 364
            self.match(Protobuf3Parser.T__0)
            self.state = 365
            self.fieldNumber()
            self.state = 370
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 366
                self.match(Protobuf3Parser.T__9)
                self.state = 367
                self.fieldOptions()
                self.state = 368
                self.match(Protobuf3Parser.T__11)


            self.state = 372
            self.match(Protobuf3Parser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MapFieldContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MAP(self):
            return self.getToken(Protobuf3Parser.MAP, 0)

        def keyType(self):
            return self.getTypedRuleContext(Protobuf3Parser.KeyTypeContext,0)


        def typeRule(self):
            return self.getTypedRuleContext(Protobuf3Parser.TypeRuleContext,0)


        def mapName(self):
            return self.getTypedRuleContext(Protobuf3Parser.MapNameContext,0)


        def fieldNumber(self):
            return self.getTypedRuleContext(Protobuf3Parser.FieldNumberContext,0)


        def fieldOptions(self):
            return self.getTypedRuleContext(Protobuf3Parser.FieldOptionsContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_mapField

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapField" ):
                listener.enterMapField(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapField" ):
                listener.exitMapField(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMapField" ):
                return visitor.visitMapField(self)
            else:
                return visitor.visitChildren(self)




    def mapField(self):

        localctx = Protobuf3Parser.MapFieldContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_mapField)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 374
            self.match(Protobuf3Parser.MAP)
            self.state = 375
            self.match(Protobuf3Parser.T__12)
            self.state = 376
            self.keyType()
            self.state = 377
            self.match(Protobuf3Parser.T__10)
            self.state = 378
            self.typeRule()
            self.state = 379
            self.match(Protobuf3Parser.T__13)
            self.state = 380
            self.mapName()
            self.state = 381
            self.match(Protobuf3Parser.T__0)
            self.state = 382
            self.fieldNumber()
            self.state = 387
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==10:
                self.state = 383
                self.match(Protobuf3Parser.T__9)
                self.state = 384
                self.fieldOptions()
                self.state = 385
                self.match(Protobuf3Parser.T__11)


            self.state = 389
            self.match(Protobuf3Parser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class KeyTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT32(self):
            return self.getToken(Protobuf3Parser.INT32, 0)

        def INT64(self):
            return self.getToken(Protobuf3Parser.INT64, 0)

        def UINT32(self):
            return self.getToken(Protobuf3Parser.UINT32, 0)

        def UINT64(self):
            return self.getToken(Protobuf3Parser.UINT64, 0)

        def SINT32(self):
            return self.getToken(Protobuf3Parser.SINT32, 0)

        def SINT64(self):
            return self.getToken(Protobuf3Parser.SINT64, 0)

        def FIXED32(self):
            return self.getToken(Protobuf3Parser.FIXED32, 0)

        def FIXED64(self):
            return self.getToken(Protobuf3Parser.FIXED64, 0)

        def SFIXED32(self):
            return self.getToken(Protobuf3Parser.SFIXED32, 0)

        def SFIXED64(self):
            return self.getToken(Protobuf3Parser.SFIXED64, 0)

        def BOOL(self):
            return self.getToken(Protobuf3Parser.BOOL, 0)

        def STRING(self):
            return self.getToken(Protobuf3Parser.STRING, 0)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_keyType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKeyType" ):
                listener.enterKeyType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKeyType" ):
                listener.exitKeyType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitKeyType" ):
                return visitor.visitKeyType(self)
            else:
                return visitor.visitChildren(self)




    def keyType(self):

        localctx = Protobuf3Parser.KeyTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_keyType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 391
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 896102083657728) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReservedWordContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EXTEND(self):
            return self.getToken(Protobuf3Parser.EXTEND, 0)

        def MESSAGE(self):
            return self.getToken(Protobuf3Parser.MESSAGE, 0)

        def OPTION(self):
            return self.getToken(Protobuf3Parser.OPTION, 0)

        def PACKAGE(self):
            return self.getToken(Protobuf3Parser.PACKAGE, 0)

        def RPC(self):
            return self.getToken(Protobuf3Parser.RPC, 0)

        def SERVICE(self):
            return self.getToken(Protobuf3Parser.SERVICE, 0)

        def STREAM(self):
            return self.getToken(Protobuf3Parser.STREAM, 0)

        def STRING(self):
            return self.getToken(Protobuf3Parser.STRING, 0)

        def SYNTAX(self):
            return self.getToken(Protobuf3Parser.SYNTAX, 0)

        def WEAK(self):
            return self.getToken(Protobuf3Parser.WEAK, 0)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_reservedWord

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterReservedWord" ):
                listener.enterReservedWord(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitReservedWord" ):
                listener.exitReservedWord(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReservedWord" ):
                return visitor.visitReservedWord(self)
            else:
                return visitor.visitChildren(self)




    def reservedWord(self):

        localctx = Protobuf3Parser.ReservedWordContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_reservedWord)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 393
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1249873333583872) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FullIdentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self, i:int=None):
            if i is None:
                return self.getTokens(Protobuf3Parser.IDENT)
            else:
                return self.getToken(Protobuf3Parser.IDENT, i)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_fullIdent

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFullIdent" ):
                listener.enterFullIdent(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFullIdent" ):
                listener.exitFullIdent(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFullIdent" ):
                return visitor.visitFullIdent(self)
            else:
                return visitor.visitChildren(self)




    def fullIdent(self):

        localctx = Protobuf3Parser.FullIdentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_fullIdent)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 395
            self.match(Protobuf3Parser.IDENT)
            self.state = 400
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==5:
                self.state = 396
                self.match(Protobuf3Parser.T__4)
                self.state = 397
                self.match(Protobuf3Parser.IDENT)
                self.state = 402
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MessageNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self):
            return self.getToken(Protobuf3Parser.IDENT, 0)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_messageName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMessageName" ):
                listener.enterMessageName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMessageName" ):
                listener.exitMessageName(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMessageName" ):
                return visitor.visitMessageName(self)
            else:
                return visitor.visitChildren(self)




    def messageName(self):

        localctx = Protobuf3Parser.MessageNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_messageName)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 403
            self.match(Protobuf3Parser.IDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EnumNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self):
            return self.getToken(Protobuf3Parser.IDENT, 0)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_enumName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEnumName" ):
                listener.enterEnumName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEnumName" ):
                listener.exitEnumName(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEnumName" ):
                return visitor.visitEnumName(self)
            else:
                return visitor.visitChildren(self)




    def enumName(self):

        localctx = Protobuf3Parser.EnumNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_enumName)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 405
            self.match(Protobuf3Parser.IDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MessageOrEnumNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self):
            return self.getToken(Protobuf3Parser.IDENT, 0)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_messageOrEnumName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMessageOrEnumName" ):
                listener.enterMessageOrEnumName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMessageOrEnumName" ):
                listener.exitMessageOrEnumName(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMessageOrEnumName" ):
                return visitor.visitMessageOrEnumName(self)
            else:
                return visitor.visitChildren(self)




    def messageOrEnumName(self):

        localctx = Protobuf3Parser.MessageOrEnumNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_messageOrEnumName)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 407
            self.match(Protobuf3Parser.IDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FieldNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self):
            return self.getToken(Protobuf3Parser.IDENT, 0)

        def reservedWord(self):
            return self.getTypedRuleContext(Protobuf3Parser.ReservedWordContext,0)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_fieldName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFieldName" ):
                listener.enterFieldName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFieldName" ):
                listener.exitFieldName(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFieldName" ):
                return visitor.visitFieldName(self)
            else:
                return visitor.visitChildren(self)




    def fieldName(self):

        localctx = Protobuf3Parser.FieldNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_fieldName)
        try:
            self.state = 411
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [51]:
                self.enterOuterAlt(localctx, 1)
                self.state = 409
                self.match(Protobuf3Parser.IDENT)
                pass
            elif token in [20, 28, 30, 31, 38, 39, 44, 45, 46, 50]:
                self.enterOuterAlt(localctx, 2)
                self.state = 410
                self.reservedWord()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OneofNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self):
            return self.getToken(Protobuf3Parser.IDENT, 0)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_oneofName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOneofName" ):
                listener.enterOneofName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOneofName" ):
                listener.exitOneofName(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitOneofName" ):
                return visitor.visitOneofName(self)
            else:
                return visitor.visitChildren(self)




    def oneofName(self):

        localctx = Protobuf3Parser.OneofNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_oneofName)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 413
            self.match(Protobuf3Parser.IDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MapNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self):
            return self.getToken(Protobuf3Parser.IDENT, 0)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_mapName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapName" ):
                listener.enterMapName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapName" ):
                listener.exitMapName(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMapName" ):
                return visitor.visitMapName(self)
            else:
                return visitor.visitChildren(self)




    def mapName(self):

        localctx = Protobuf3Parser.MapNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_mapName)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 415
            self.match(Protobuf3Parser.IDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ServiceNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self):
            return self.getToken(Protobuf3Parser.IDENT, 0)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_serviceName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterServiceName" ):
                listener.enterServiceName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitServiceName" ):
                listener.exitServiceName(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitServiceName" ):
                return visitor.visitServiceName(self)
            else:
                return visitor.visitChildren(self)




    def serviceName(self):

        localctx = Protobuf3Parser.ServiceNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_serviceName)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 417
            self.match(Protobuf3Parser.IDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RpcNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self):
            return self.getToken(Protobuf3Parser.IDENT, 0)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_rpcName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRpcName" ):
                listener.enterRpcName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRpcName" ):
                listener.exitRpcName(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRpcName" ):
                return visitor.visitRpcName(self)
            else:
                return visitor.visitChildren(self)




    def rpcName(self):

        localctx = Protobuf3Parser.RpcNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_rpcName)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 419
            self.match(Protobuf3Parser.IDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MessageTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def messageName(self):
            return self.getTypedRuleContext(Protobuf3Parser.MessageNameContext,0)


        def IDENT(self, i:int=None):
            if i is None:
                return self.getTokens(Protobuf3Parser.IDENT)
            else:
                return self.getToken(Protobuf3Parser.IDENT, i)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_messageType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMessageType" ):
                listener.enterMessageType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMessageType" ):
                listener.exitMessageType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMessageType" ):
                return visitor.visitMessageType(self)
            else:
                return visitor.visitChildren(self)




    def messageType(self):

        localctx = Protobuf3Parser.MessageTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_messageType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 422
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==5:
                self.state = 421
                self.match(Protobuf3Parser.T__4)


            self.state = 428
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,39,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 424
                    self.match(Protobuf3Parser.IDENT)
                    self.state = 425
                    self.match(Protobuf3Parser.T__4) 
                self.state = 430
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,39,self._ctx)

            self.state = 431
            self.messageName()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MessageOrEnumTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def messageOrEnumName(self):
            return self.getTypedRuleContext(Protobuf3Parser.MessageOrEnumNameContext,0)


        def IDENT(self, i:int=None):
            if i is None:
                return self.getTokens(Protobuf3Parser.IDENT)
            else:
                return self.getToken(Protobuf3Parser.IDENT, i)

        def reservedWord(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Protobuf3Parser.ReservedWordContext)
            else:
                return self.getTypedRuleContext(Protobuf3Parser.ReservedWordContext,i)


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_messageOrEnumType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMessageOrEnumType" ):
                listener.enterMessageOrEnumType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMessageOrEnumType" ):
                listener.exitMessageOrEnumType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMessageOrEnumType" ):
                return visitor.visitMessageOrEnumType(self)
            else:
                return visitor.visitChildren(self)




    def messageOrEnumType(self):

        localctx = Protobuf3Parser.MessageOrEnumTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_messageOrEnumType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 434
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==5:
                self.state = 433
                self.match(Protobuf3Parser.T__4)


            self.state = 443
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,42,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 438
                    self._errHandler.sync(self)
                    token = self._input.LA(1)
                    if token in [51]:
                        self.state = 436
                        self.match(Protobuf3Parser.IDENT)
                        pass
                    elif token in [20, 28, 30, 31, 38, 39, 44, 45, 46, 50]:
                        self.state = 437
                        self.reservedWord()
                        pass
                    else:
                        raise NoViableAltException(self)

                    self.state = 440
                    self.match(Protobuf3Parser.T__4) 
                self.state = 445
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,42,self._ctx)

            self.state = 446
            self.messageOrEnumName()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EmptyStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return Protobuf3Parser.RULE_emptyStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEmptyStmt" ):
                listener.enterEmptyStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEmptyStmt" ):
                listener.exitEmptyStmt(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEmptyStmt" ):
                return visitor.visitEmptyStmt(self)
            else:
                return visitor.visitChildren(self)




    def emptyStmt(self):

        localctx = Protobuf3Parser.EmptyStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_emptyStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 448
            self.match(Protobuf3Parser.T__1)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstantContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fullIdent(self):
            return self.getTypedRuleContext(Protobuf3Parser.FullIdentContext,0)


        def INT_LIT(self):
            return self.getToken(Protobuf3Parser.INT_LIT, 0)

        def FLOAT_LIT(self):
            return self.getToken(Protobuf3Parser.FLOAT_LIT, 0)

        def STR_LIT(self):
            return self.getToken(Protobuf3Parser.STR_LIT, 0)

        def BOOL_LIT(self):
            return self.getToken(Protobuf3Parser.BOOL_LIT, 0)

        def getRuleIndex(self):
            return Protobuf3Parser.RULE_constant

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstant" ):
                listener.enterConstant(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstant" ):
                listener.exitConstant(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstant" ):
                return visitor.visitConstant(self)
            else:
                return visitor.visitChildren(self)




    def constant(self):

        localctx = Protobuf3Parser.ConstantContext(self, self._ctx, self.state)
        self.enterRule(localctx, 94, self.RULE_constant)
        self._la = 0 # Token type
        try:
            self.state = 461
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,45,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 450
                self.fullIdent()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 452
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==9 or _la==15:
                    self.state = 451
                    _la = self._input.LA(1)
                    if not(_la==9 or _la==15):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()


                self.state = 454
                self.match(Protobuf3Parser.INT_LIT)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 456
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==9 or _la==15:
                    self.state = 455
                    _la = self._input.LA(1)
                    if not(_la==9 or _la==15):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()


                self.state = 458
                self.match(Protobuf3Parser.FLOAT_LIT)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 459
                self.match(Protobuf3Parser.STR_LIT)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 460
                self.match(Protobuf3Parser.BOOL_LIT)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





