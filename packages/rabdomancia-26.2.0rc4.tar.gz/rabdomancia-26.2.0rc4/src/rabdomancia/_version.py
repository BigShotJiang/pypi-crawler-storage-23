"""
Provides rabdomancia version information.
"""

# This file is auto-generated! Do not edit!
# Use `incremental` to change this file.

from incremental import Version

__version__ = Version("rabdomancia", 26, 2, 0, release_candidate=4)
__all__ = ["__version__"]
