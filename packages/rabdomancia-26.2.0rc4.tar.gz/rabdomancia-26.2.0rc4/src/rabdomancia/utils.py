import asyncio
from collections.abc import Coroutine

from attrs import Factory, define


@define(auto_attribs=True)
class Tasker:
    background_tasks: set[asyncio.Task] = Factory(set)

    def one_off(self, coroutine: Coroutine):
        task = asyncio.create_task(coroutine)
        self.background_tasks.add(task)
        task.add_done_callback(self.background_tasks.discard)
