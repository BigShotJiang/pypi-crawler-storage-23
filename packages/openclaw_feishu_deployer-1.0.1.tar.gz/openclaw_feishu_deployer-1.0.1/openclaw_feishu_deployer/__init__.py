# -*- coding: utf-8 -*-
"""
🦞 OpenClaw Feishu Deployer
一键部署 OpenClaw + 飞书机器人的专业工具
"""

__version__ = "1.0.1"
__author__ = "Duka Works"
__email__ = "chenzhy.bj@gmail.com"
