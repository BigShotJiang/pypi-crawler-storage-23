/**
 * PBIR-Utils UI Client JavaScript
 * Handles file browsing, action execution, and SSE streaming
 */

// Constants
const SIDEBAR_MIN_WIDTH = 150;
const OUTPUT_PANEL_MIN_HEIGHT = 50;

// State
// currentReportPath, fieldsIndex are defined in template
const selectedActions = new Set();
let reportDirtyState = false;
let currentConfigPath = null;
let customConfigYaml = null;
let expressionRules = [];  // Validation rules
let customRulesConfigYaml = null;  // Custom rules YAML content
let currentRulesConfigPath = null;  // Custom rules config filename


// DOM Elements
const welcomeState = document.getElementById('welcome-state');
const wireframeContainer = document.getElementById('wireframe-container');
const outputContent = document.getElementById('output-content');
const dirtyBanner = document.getElementById('dirty-banner');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadActions();

    // Auto-load report if initial path was provided via CLI
    if (typeof initialReportPath !== 'undefined' && initialReportPath) {
        loadReport(initialReportPath);
    } else {
        // Only browse default directory if NO report is being loaded
        browseDirectory(null);
    }

    if (window.lucide) lucide.createIcons();
});

// ============ File Browser ============

async function browseDirectory(path) {
    try {
        let url = '/api/browse';
        if (path) {
            url += `?path=${encodeURIComponent(path)}`;
        }
        const response = await fetch(url);
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.detail || 'Failed to browse');
        }
        const data = await response.json();
        renderFileList(data);
    } catch (e) {
        appendOutput('error', `Failed to browse: ${e.message}`);
    }
}

function renderFileList(data) {
    const breadcrumb = document.getElementById('breadcrumb');
    const fileList = document.getElementById('file-list');

    // Breadcrumb
    const crumbs = data.current_path.split(/[\/\\]/).filter(Boolean);
    let builtPath = '';
    breadcrumb.innerHTML = crumbs.map(crumb => {
        builtPath += `${crumb}/`;
        const safePath = builtPath.replace(/'/g, "\\'");
        return `<span class="breadcrumb-item" onclick="browseDirectory('${safePath}')">${crumb}</span>`;
    }).join(' / ');

    // Parent directory
    let html = '';
    if (data.parent_path) {
        const safeParent = data.parent_path.replace(/'/g, "\\'").replace(/\\/g, '\\\\');
        html += `<div class="file-item" onclick="browseDirectory('${safeParent}')"><i data-lucide="folder"></i> ..</div>`;
    }

    // Items
    html += data.items.map(item => {
        const icon = item.is_report ? '<i data-lucide="bar-chart-2"></i>' : (item.is_dir ? '<i data-lucide="folder"></i>' : '<i data-lucide="file"></i>');
        const isActive = currentReportPath && item.path === currentReportPath;
        const cls = `file-item${item.is_report ? ' report' : ''}${isActive ? ' active' : ''}`;

        let onclick = '';
        if (item.is_report || item.is_dir) {
            const safePath = item.path.replace(/'/g, "\\'").replace(/\\/g, '\\\\');
            const func = item.is_report ? 'loadReport' : 'browseDirectory';
            onclick = `${func}('${safePath}')`;
        }

        return onclick
            ? `<div class="${cls}" onclick="${onclick}">${icon} ${escapeHtml(item.name)}</div>`
            : '';
    }).join('');

    fileList.innerHTML = html;

    if (window.lucide) lucide.createIcons();
}

// Note: escapeHtml is provided by wireframe.js which is always loaded first

// ============ Report Loading ============

async function loadReport(reportPath, preserveActions) {
    try {
        appendOutput('info', `Loading report: ${reportPath}`);

        // Save current selection if requested
        let savedActions = null;
        if (preserveActions) {
            savedActions = new Set(selectedActions);
        }

        const response = await fetch('/api/reports/wireframe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ report_path: reportPath })
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.detail || 'Failed to load');
        }

        const data = await response.json();
        currentReportPath = reportPath;

        // Update global state for wireframe.js
        fieldsIndex = data.fields_index;
        activePageId = data.active_page_id;

        // Render wireframe
        renderWireframe(data);

        // Enable buttons
        document.getElementById('run-btn').disabled = false;
        document.getElementById('dry-run-btn').disabled = false;
        document.getElementById('export-meta-btn').disabled = false;
        document.getElementById('export-visuals-btn').disabled = false;
        document.getElementById('export-html-btn').disabled = false;

        setDirtyState(false);
        appendOutput('success', `Report loaded: ${data.report_name}`);

        // Reload actions with report path to pick up report-specific config
        await loadActions(reportPath);

        // Restore selections if requested
        if (savedActions) {
            restoreActionSelection(savedActions);
        }

        // Load expression rules for validation
        await loadExpressionRules(reportPath);

        // Navigate file browser to show and highlight the loaded report
        const parentPath = reportPath.replace(/[\\/][^\\/]+$/, '');
        browseDirectory(parentPath);

    } catch (e) {
        appendOutput('error', `Failed to load report: ${e.message}`);
    }
}

function renderWireframe(data) {
    // Hide welcome, show wireframe
    welcomeState.style.display = 'none';

    // Inject server-rendered HTML
    if (data.html_content) {
        wireframeContainer.innerHTML = data.html_content;
    }

    // Move tooltips to document.body (must be outside wireframe-container to avoid overflow clipping)
    const tooltipIds = ['tooltip', 'page-tooltip', 'field-tooltip', 'table-tooltip'];
    tooltipIds.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            document.body.appendChild(el);
        }
    });

    // Re-initialize wireframe.js global tooltip references (they were null at script load time)
    tooltip = document.getElementById('tooltip');
    pageTooltip = document.getElementById('page-tooltip');
    fieldTooltip = document.getElementById('field-tooltip');
    tableTooltip = document.getElementById('table-tooltip');

    // Reset cached elements
    cachedVisuals = null;
    cachedTabs = null;

    // Initialize wireframe.js functions
    initFieldsPane();
    setupVisualEventDelegation();
    initDragSelection();

    // Set theme from localStorage
    const savedTheme = localStorage.getItem('wireframe-theme');
    if (savedTheme === 'dark') {
        document.body.setAttribute('data-theme', 'dark');
    }

    // Upgrade wireframe UI icons to Lucide if available
    if (window.lucide) {
        const undoBtn = document.getElementById('undo-btn');
        if (undoBtn) undoBtn.innerHTML = '<i data-lucide="undo-2"></i>';
        const resetBtn = document.getElementById('reset-btn');
        if (resetBtn) resetBtn.innerHTML = '<i data-lucide="rotate-ccw"></i>';
        const themeBtn = document.getElementById('theme-btn');
        if (themeBtn) {
            themeBtn.innerHTML = document.body.getAttribute('data-theme') === 'dark' ?
                '<i data-lucide="sun"></i>' : '<i data-lucide="moon"></i>';
        }
        lucide.createIcons();
    }
}

// ============ Actions ============


async function loadActions(reportPath) {
    try {
        let url = '/api/reports/actions';
        if (reportPath) {
            url += `?report_path=${encodeURIComponent(reportPath)}`;
        }
        const response = await fetch(url);
        const data = await response.json();

        // Check for stored custom config FIRST
        const storedYaml = customConfigYaml || sessionStorage.getItem('pbir_custom_config_yaml');
        const storedName = (customConfigYaml ? currentConfigPath : null) ||
            sessionStorage.getItem('pbir_custom_config_path');

        if (storedYaml) {
            // Restore custom config
            await applyConfigFromYaml(storedYaml, storedName, true);
        } else {
            // Use default/report config
            currentConfigPath = data.config_path;
            customConfigYaml = null;
            renderActions(data.actions);
            updateConfigIndicator();
        }
    } catch (e) {
        appendOutput('error', `Failed to load actions: ${e.message}`);
    }
}

function renderActions(actions) {
    selectedActions.clear();
    let html = '';

    // Split actions
    const defaultActions = actions.filter(a => a.is_default);
    const additionalActions = actions.filter(a => !a.is_default);

    // --- Default Actions Section ---
    if (defaultActions.length > 0) {
        html += `
        <div class="action-group-header">
            <div class="action-item select-all-container" style="border-bottom: 1px solid var(--border-color); margin-bottom: 4px; padding-bottom: 8px;">
                <input type="checkbox" id="select-all-default" onchange="toggleGroup('default', this)">
                <label for="select-all-default" style="font-weight: 600;">Default Actions</label>
            </div>
        </div>`;

        html += defaultActions.map((action, i) => {
            selectedActions.add(action.id); // Auto-select default
            const description = action.description || action.id.replace(/_/g, ' ');
            return `
            <div class="action-item" title="${escapeHtml(action.id)}">
                <input type="checkbox" id="action-def-${i}" value="${action.id}" checked
                    class="action-checkbox-default" onchange="toggleAction('${action.id}')">
                <label for="action-def-${i}">${escapeHtml(description)}</label>
            </div>`;
        }).join('');
    }

    // --- Additional Actions Section ---
    if (additionalActions.length > 0) {
        html += `
        <div class="action-group-header" style="margin-top: 12px;">
            <div class="action-item select-all-container" style="border-bottom: 1px solid var(--border-color); margin-bottom: 4px; padding-bottom: 8px;">
                <input type="checkbox" id="select-all-additional" onchange="toggleGroup('additional', this)">
                <label for="select-all-additional" style="font-weight: 600;">Additional Actions</label>
            </div>
        </div>`;

        html += additionalActions.map((action, i) => {
            const description = action.description || action.id.replace(/_/g, ' ');
            return `
            <div class="action-item additional" title="${escapeHtml(action.id)}">
                <input type="checkbox" id="action-add-${i}" value="${action.id}"
                    class="action-checkbox-additional" onchange="toggleAction('${action.id}')">
                <label for="action-add-${i}">${escapeHtml(description)}</label>
            </div>`;
        }).join('');
    }

    document.getElementById('actions-list').innerHTML = html;

    // Update select all states initially
    updateSelectAllState();

    if (window.lucide) lucide.createIcons();
}

function restoreActionSelection(savedSet) {
    selectedActions.clear();
    const checkboxes = document.querySelectorAll('.action-checkbox-default, .action-checkbox-additional');

    checkboxes.forEach(cb => {
        cb.checked = savedSet.has(cb.value);
        if (cb.checked) {
            selectedActions.add(cb.value);
        }
    });

    updateSelectAllState();
    updateRunButtons();
}

function updateConfigIndicator() {
    const indicator = document.getElementById('config-indicator');
    if (indicator) {
        if (currentConfigPath) {
            const fileName = currentConfigPath.split(/[\\/]/).pop();
            indicator.innerHTML = `
                <span class="config-name" style="display: flex; align-items: center; gap: 4px;"><i data-lucide="file-json" style="width: 12px; height: 12px;"></i> ${escapeHtml(fileName)}</span>
                <span class="config-reset" onclick="resetConfig(event)" title="Reset to Defaults">×</span>
            `;
            indicator.title = `Custom config: ${currentConfigPath}`;
            indicator.style.display = 'inline-flex';
            if (window.lucide) lucide.createIcons();
        } else {
            indicator.style.display = 'none';
        }
    }
}

async function loadCustomConfig(input) {
    if (!input.files || !input.files[0]) return;

    const file = input.files[0];
    const yamlContent = await file.text();

    await applyConfigFromYaml(yamlContent, file.name);

    // Persist to session storage
    if (customConfigYaml) {
        sessionStorage.setItem('pbir_custom_config_yaml', customConfigYaml);
        sessionStorage.setItem('pbir_custom_config_path', currentConfigPath);
    }

    // Reset file input so same file can be selected again
    input.value = '';
}

async function applyConfigFromYaml(yamlContent, configName, silent = false) {
    const blob = new Blob([yamlContent], { type: 'text/yaml' });
    const formData = new FormData();
    formData.append('file', blob, configName || 'custom.yaml');

    try {
        const response = await fetch('/api/reports/config', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.detail || 'Failed to load config');
        }

        const data = await response.json();

        // Store config for execution
        currentConfigPath = configName;
        customConfigYaml = yamlContent;

        // Render new actions from config
        const actions = data.actions.map(id => {
            const def = data.definitions[id];
            return {
                id,
                description: def ? def.description : id.replace(/_/g, ' '),
                is_default: true
            };
        });
        renderActions(actions);
        updateConfigIndicator();
        if (!silent) {
            ensureOutputPanelVisible();
            appendOutput('success', `Loaded custom config: ${configName}`);
        }

    } catch (e) {
        if (!silent) {
            ensureOutputPanelVisible();
            appendOutput('error', `Failed to load config: ${e.message}`);
        }
        // If failed, clear bad config from session to prevent loop
        sessionStorage.removeItem('pbir_custom_config_yaml');
        sessionStorage.removeItem('pbir_custom_config_path');
    }
}

async function resetConfig(event) {
    if (event) event.stopPropagation();
    currentConfigPath = null;
    customConfigYaml = null;
    sessionStorage.removeItem('pbir_custom_config_yaml');
    sessionStorage.removeItem('pbir_custom_config_path');
    await loadActions(currentReportPath);
    appendOutput('info', 'Reset to default configuration');
    updateRunButtons();
}

function updateSelectAllState() {
    updateGroupState('default');
    updateGroupState('additional');
}

function updateGroupState(type) {
    const checkboxes = Array.from(document.querySelectorAll(`.action-checkbox-${type}`));
    const selectAll = document.getElementById(`select-all-${type}`);

    if (!checkboxes.length || !selectAll) return;

    const allChecked = checkboxes.every(cb => cb.checked);
    const anyChecked = checkboxes.some(cb => cb.checked);

    selectAll.checked = allChecked;
    selectAll.indeterminate = !allChecked && anyChecked;
}

function toggleGroup(type, source) {
    const checkboxes = document.querySelectorAll(`.action-checkbox-${type}`);
    const isChecked = source.checked;

    checkboxes.forEach(cb => {
        cb.checked = isChecked;
        if (isChecked) {
            selectedActions.add(cb.value);
        } else {
            selectedActions.delete(cb.value);
        }
    });
    updateSelectAllState(); // Ensure indeterminate state is cleared
    updateRunButtons();
}

function toggleAction(action) {
    if (selectedActions.has(action)) {
        selectedActions.delete(action);
    } else {
        selectedActions.add(action);
    }
    updateSelectAllState();
    updateRunButtons();
}

function updateRunButtons() {
    const hasActions = selectedActions.size > 0;
    const runBtn = document.getElementById('run-btn');
    const dryRunBtn = document.getElementById('dry-run-btn');

    if (runBtn) runBtn.disabled = !hasActions;
    if (dryRunBtn) dryRunBtn.disabled = !hasActions;
}

async function runActions(dryRun) {
    ensureOutputPanelVisible();
    if (!currentReportPath) {
        appendOutput('warning', 'Please open a report first');
        showToast('⚠️ Please open a report first', 3000);
        return;
    }
    if (selectedActions.size === 0) {
        appendOutput('warning', 'Please select at least one action');
        showToast('⚠️ Please select at least one action', 3000);
        return;
    }

    // Confirmation for actual run
    if (!dryRun) {
        const confirmed = confirm(
            "Are you sure you want to run this?\n\n" +
            "This action cannot be undone from the application.\n" +
            "Please ensure you have a backup or the report is checked into git."
        );
        if (!confirmed) return;
    }

    const actions = Array.from(selectedActions).join(',');
    let url = `/api/reports/run/stream?path=${encodeURIComponent(currentReportPath)}` +
        `&actions=${encodeURIComponent(actions)}` +
        `&dry_run=${dryRun}`;

    // Pass custom config if loaded
    if (customConfigYaml) {
        const encoded = btoa(unescape(encodeURIComponent(customConfigYaml)));
        url += `&config_yaml=${encodeURIComponent(encoded)}`;
    }

    appendOutput('info', (dryRun ? '[DRY RUN] ' : '') + `Running: ${actions}`);

    const eventSource = new EventSource(url);

    eventSource.onmessage = event => {
        const data = JSON.parse(event.data);
        appendOutput(data.type || 'info', data.message);
    };

    eventSource.addEventListener('complete', async () => {
        eventSource.close();
        appendOutput('success', 'Actions completed');

        if (!dryRun) {
            showToast('✓ Actions completed. Reloading report...', 4000);
            await loadReport(currentReportPath, true);
            showToast('✓ Report refreshed', 4000);
        }
    });

    eventSource.onerror = () => {
        eventSource.close();
        setDirtyState(true, 'Action may have failed. Report might be in inconsistent state.');
        appendOutput('error', 'Connection lost');
    };
}

// ============ Validation ============

async function loadExpressionRules(reportPath) {
    if (!reportPath) return;
    try {
        const url = `/api/reports/validate/rules?report_path=${encodeURIComponent(reportPath)}`;
        const response = await fetch(url);
        const data = await response.json();

        // Check for stored custom rules config FIRST
        const storedYaml = customRulesConfigYaml || sessionStorage.getItem('pbir_custom_rules_yaml');
        const storedName = (customRulesConfigYaml ? currentRulesConfigPath : null) ||
            sessionStorage.getItem('pbir_custom_rules_path');

        if (storedYaml) {
            // Restore custom rules
            await applyRulesConfigFromYaml(storedYaml, storedName, true);
        } else {
            expressionRules = data.rules || [];
            renderExpressionRules();
            document.getElementById('check-btn').disabled = false;
        }

    } catch (e) {
        console.error('Failed to load validation rules:', e);
        expressionRules = [];
        renderExpressionRules();
    }
}

function renderExpressionRules() {
    const container = document.getElementById('rules-list');
    if (!container) return;

    if (!expressionRules.length) {
        container.innerHTML = '<div style="padding: 16px; color: var(--text-secondary); font-size: 12px;">No expression rules available</div>';
        return;
    }

    // Header with Select All checkbox (matching Actions panel pattern)
    let html = `
        <div class="action-group-header">
            <div class="action-item select-all-container" style="border-bottom: 1px solid var(--border-color); margin-bottom: 4px; padding-bottom: 8px;">
                <input type="checkbox" id="select-all-rules" onchange="toggleRulesGroup(this)" checked>
                <label for="select-all-rules" style="font-weight: 600;">Expression Rules</label>
            </div>
        </div>`;

    html += expressionRules.map(r => {
        const desc = r.description || r.id.replace(/_/g, ' ');
        const badge = r.severity[0].toUpperCase();
        return `
            <div class="rule-item">
                <input type="checkbox" id="rule-${r.id}" value="${r.id}" class="rule-checkbox" checked onchange="updateRulesGroupState()">
                <label for="rule-${r.id}" style="flex:1;cursor:pointer;">${escapeHtml(desc)}</label>
                <span class="severity-badge ${r.severity}" title="Severity: ${r.severity}">${badge}</span>
            </div>`;
    }).join('');

    container.innerHTML = html;
    updateRulesGroupState();

    if (window.lucide) lucide.createIcons();
}

function toggleRulesGroup(source) {
    const checkboxes = document.querySelectorAll('.rule-checkbox');
    const isChecked = source.checked;

    checkboxes.forEach(cb => {
        cb.checked = isChecked;
    });
    updateRulesGroupState();
}

function updateRulesGroupState() {
    const checkboxes = Array.from(document.querySelectorAll('.rule-checkbox'));
    const selectAll = document.getElementById('select-all-rules');

    if (!checkboxes.length || !selectAll) return;

    const allChecked = checkboxes.every(cb => cb.checked);
    const anyChecked = checkboxes.some(cb => cb.checked);

    selectAll.checked = allChecked;
    selectAll.indeterminate = !allChecked && anyChecked;
}

async function runCheck() {
    ensureOutputPanelVisible();
    if (!currentReportPath) {
        showToast('⚠️ Please open a report first', 3000);
        return;
    }

    // Get selected expression rules
    const exprRules = Array.from(document.querySelectorAll('#rules-list input:checked')).map(cb => cb.value);
    // Get selected sanitize actions from ACTIONS panel
    let sanitizeActions = Array.from(selectedActions);
    // Check if sanitizer checks should be included
    const includeSanitizer = document.getElementById('include-sanitizer-checks')?.checked ?? true;

    // If not including sanitizer, clear the actions
    if (!includeSanitizer) {
        sanitizeActions = [];
    }

    if (exprRules.length === 0 && sanitizeActions.length === 0) {
        appendOutput('warning', 'No rules or actions selected for validation');
        return;
    }

    const btn = document.getElementById('check-btn');
    btn.disabled = true;
    btn.innerHTML = '<i data-lucide="loader" class="spin"></i> Checking...';
    if (window.lucide) lucide.createIcons();

    // Build SSE URL with query parameters
    let url = `/api/reports/validate/run/stream?report_path=${encodeURIComponent(currentReportPath)}`;

    if (exprRules.length > 0) {
        url += `&expression_rules=${encodeURIComponent(exprRules.join(','))}`;
    }
    if (sanitizeActions.length > 0) {
        url += `&sanitize_actions=${encodeURIComponent(sanitizeActions.join(','))}`;
    }
    url += `&include_sanitizer=${includeSanitizer}`;

    // Add custom rules config if loaded (base64 encoded)
    if (customRulesConfigYaml) {
        const encoded = btoa(unescape(encodeURIComponent(customRulesConfigYaml)));
        url += `&rules_config_yaml=${encodeURIComponent(encoded)}`;
    }

    // Add custom sanitize config if loaded from Actions panel (base64 encoded)
    if (customConfigYaml) {
        const encodedSanitize = btoa(unescape(encodeURIComponent(customConfigYaml)));
        url += `&sanitize_config_yaml=${encodeURIComponent(encodedSanitize)}`;
    }

    const eventSource = new EventSource(url);

    eventSource.onmessage = event => {
        const data = JSON.parse(event.data);
        const message = data.message || '';

        // Detect color type from message content (badges like [PASS], [WARNING], etc.)
        let type = data.type || 'info';
        if (message.indexOf('[PASS]') !== -1) {
            type = 'success';
        } else if (message.indexOf('[WARNING]') !== -1) {
            type = 'warning';
        } else if (message.indexOf('[ERROR]') !== -1) {
            type = 'error';
        } else if (message.indexOf('[INFO]') !== -1) {
            type = 'info';
        }

        appendOutput(type, message);
    };

    eventSource.addEventListener('complete', event => {
        eventSource.close();
        btn.disabled = false;
        btn.innerHTML = '<i data-lucide="check"></i> Check';
        if (window.lucide) lucide.createIcons();
    });

    eventSource.onerror = () => {
        eventSource.close();
        appendOutput('error', 'Connection lost during validation');
        btn.disabled = false;
        btn.innerHTML = '<i data-lucide="check"></i> Check';
        if (window.lucide) lucide.createIcons();
    };
}

async function loadCustomRulesConfig(input) {
    if (!input.files || !input.files[0]) return;

    const file = input.files[0];
    const yamlContent = await file.text();

    await applyRulesConfigFromYaml(yamlContent, file.name);

    if (customRulesConfigYaml) {
        sessionStorage.setItem('pbir_custom_rules_yaml', customRulesConfigYaml);
        sessionStorage.setItem('pbir_custom_rules_path', currentRulesConfigPath);
    }

    // Reset file input so same file can be selected again
    input.value = '';
}

async function applyRulesConfigFromYaml(yamlContent, configName, silent = false) {
    const blob = new Blob([yamlContent], { type: 'text/yaml' });
    const formData = new FormData();
    formData.append('file', blob, configName || 'custom_rules.yaml');

    try {
        const response = await fetch('/api/reports/validate/config', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.detail || 'Failed to load rules config');
        }

        const data = await response.json();

        // Store config for validation
        currentRulesConfigPath = configName;
        customRulesConfigYaml = yamlContent;

        // Render new rules from config
        expressionRules = data.rules.map(r => ({
            id: r.id,
            description: r.description,
            severity: r.severity,
            scope: r.scope
        }));
        renderExpressionRules();
        updateRulesConfigIndicator();
        if (!silent) {
            ensureOutputPanelVisible();
            appendOutput('success', `Loaded custom rules config: ${configName}`);
        }

    } catch (e) {
        if (!silent) {
            ensureOutputPanelVisible();
            appendOutput('error', `Failed to load rules config: ${e.message}`);
        }
        sessionStorage.removeItem('pbir_custom_rules_yaml');
        sessionStorage.removeItem('pbir_custom_rules_path');
    }
}

async function resetRulesConfig(event) {
    if (event) event.stopPropagation();
    currentRulesConfigPath = null;
    customRulesConfigYaml = null;
    sessionStorage.removeItem('pbir_custom_rules_yaml');
    sessionStorage.removeItem('pbir_custom_rules_path');
    await loadExpressionRules(currentReportPath);
    updateRulesConfigIndicator();
    appendOutput('info', 'Reset to default rules configuration');
}

function updateRulesConfigIndicator() {
    const indicator = document.getElementById('rules-config-indicator');
    if (indicator) {
        if (currentRulesConfigPath) {
            const fileName = currentRulesConfigPath.split(/[\\/]/).pop();
            indicator.innerHTML = `
                <span class="config-name" style="display: flex; align-items: center; gap: 4px;"><i data-lucide="file-json" style="width: 12px; height: 12px;"></i> ${escapeHtml(fileName)}</span>
                <span class="config-reset" onclick="resetRulesConfig(event)" title="Reset to Defaults">×</span>
            `;
            indicator.title = `Custom rules config: ${currentRulesConfigPath}`;
            indicator.style.display = 'inline-flex';
            if (window.lucide) lucide.createIcons();
        } else {
            indicator.style.display = 'none';
        }
    }
}



// ============ CSV Export ============

function downloadCSV(type, filteredOnly) {
    if (!currentReportPath) return;

    let url = `/api/reports/${type === 'visuals' ? 'visuals' : 'metadata'}/csv` +
        `?report_path=${encodeURIComponent(currentReportPath)}`;

    // Add visual IDs filter if exporting filtered view (WYSIWYG)
    let isFiltered = false;
    if (filteredOnly && typeof getVisibleVisualIds === 'function' && typeof hasActiveFilters === 'function') {
        if (hasActiveFilters()) {
            const visibleIds = getVisibleVisualIds();
            if (visibleIds.length > 0) {
                url += `&visual_ids=${encodeURIComponent(visibleIds.join(','))}`;
                isFiltered = true;
            }
        }
    }

    window.open(url, '_blank');
    appendOutput('info', `Downloading ${type} CSV${isFiltered ? ' (filtered)' : ''}...`);
}

function downloadWireframeHTML(filteredOnly) {
    if (!currentReportPath) return;

    let url = `/api/reports/wireframe/html?report_path=${encodeURIComponent(currentReportPath)}`;

    // Add visual IDs filter if exporting filtered view (WYSIWYG)
    let isFiltered = false;
    if (filteredOnly && typeof getVisibleVisualIds === 'function' && typeof hasActiveFilters === 'function') {
        if (hasActiveFilters()) {
            const visibleIds = getVisibleVisualIds();
            if (visibleIds.length > 0) {
                url += `&visual_ids=${encodeURIComponent(visibleIds.join(','))}`;
                isFiltered = true;
            }
        }
    }

    window.open(url, '_blank');
    appendOutput('info', `Downloading wireframe HTML${isFiltered ? ' (filtered)' : ''}...`);
}

// ============ Output Console ============

function ensureOutputPanelVisible() {
    const panel = document.getElementById('output-panel');
    if (panel && panel.classList.contains('collapsed')) {
        panel.classList.remove('collapsed');
        savePanelState();
    }
}

function appendOutput(type, message) {
    const line = document.createElement('div');
    line.className = `output-line ${type}`;
    line.textContent = message;
    outputContent.appendChild(line);
    outputContent.scrollTop = outputContent.scrollHeight;
}

function clearOutput() {
    outputContent.innerHTML = '';
}

// ============ State Management ============

function setDirtyState(isDirty, message) {
    reportDirtyState = isDirty;
    if (isDirty) {
        dirtyBanner.textContent = `⚠️ ${message || 'Report may need reload'}`;
        dirtyBanner.style.display = 'block';
    } else {
        dirtyBanner.style.display = 'none';
    }
}

// ============ Resizing Logic ============

let isResizingOutput = false;
let isResizingSidebar = false;
let startResizeY = 0;
let startResizeX = 0;
let startResizeHeight = 0;
let startResizeWidth = 0;

function initOutputResize(e) {
    isResizingOutput = true;
    startResizeY = e.clientY;
    const panel = document.getElementById('output-panel');
    startResizeHeight = parseInt(getComputedStyle(panel).height, 10);
    document.body.style.cursor = 'row-resize';
    e.preventDefault();
}

function initSidebarResize(e) {
    isResizingSidebar = true;
    startResizeX = e.clientX;
    const sidebar = document.getElementById('sidebar');
    startResizeWidth = sidebar.getBoundingClientRect().width;
    sidebar.classList.remove('transition-enabled'); // Disable transition for drag
    document.body.style.cursor = 'col-resize';
    e.preventDefault();
}

document.addEventListener('mousemove', e => {
    if (isResizingOutput) {
        const panel = document.getElementById('output-panel');
        let newHeight = startResizeHeight + (startResizeY - e.clientY);

        // Constraints
        if (newHeight < OUTPUT_PANEL_MIN_HEIGHT) newHeight = OUTPUT_PANEL_MIN_HEIGHT;
        if (newHeight > window.innerHeight * 0.8) newHeight = window.innerHeight * 0.8;

        panel.style.height = `${newHeight}px`;
    }

    if (isResizingSidebar) {
        const sidebar = document.getElementById('sidebar');
        let newWidth = startResizeWidth + (e.clientX - startResizeX);

        // Constraints
        if (newWidth < SIDEBAR_MIN_WIDTH) newWidth = SIDEBAR_MIN_WIDTH;
        if (newWidth > window.innerWidth * 0.5) newWidth = window.innerWidth * 0.5;

        sidebar.style.width = `${newWidth}px`;
    }
});

document.addEventListener('mouseup', () => {
    if (isResizingOutput) {
        isResizingOutput = false;
        document.body.style.cursor = 'default';
        savePanelState();
    }
    if (isResizingSidebar) {
        isResizingSidebar = false;
        document.body.style.cursor = 'default';
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.add('transition-enabled'); // Re-enable transition
        savePanelState();
    }
});

function toggleOutputPanel() {
    const panel = document.getElementById('output-panel');
    panel.classList.toggle('collapsed');
    savePanelState();
}

// ============ Sidebar Logic ============

function switchActivityView(sectionId) {
    const sidebar = document.getElementById('sidebar');
    const targetSection = document.getElementById(sectionId);
    if (!targetSection) return;

    const isCollapsed = sidebar.classList.contains('collapsed');
    const isCurrentlyActive = targetSection.classList.contains('active');

    if (isCollapsed) {
        // Sidebar is closed -> Open it and show the requested section
        sidebar.classList.remove('collapsed');
        activateSection(sectionId);
    } else {
        if (isCurrentlyActive) {
            // Clicking the active icon while open -> Collapse sidebar
            sidebar.classList.add('collapsed');
        } else {
            // Clicking a different icon -> Swap section
            activateSection(sectionId);
        }
    }
    savePanelState();
}

function activateSection(sectionId) {
    // Hide all sections
    const sections = ['section-reports', 'section-actions', 'section-validate', 'section-export'];
    sections.forEach(id => {
        const sec = document.getElementById(id);
        if (sec) sec.classList.remove('active');

        // Remove active class from corresponding nav icon
        const navIconId = id.replace('section-', 'nav-');
        const navIcon = document.getElementById(navIconId);
        if (navIcon) navIcon.classList.remove('active');
    });

    // Show target section
    const activeSec = document.getElementById(sectionId);
    if (activeSec) activeSec.classList.add('active');

    // Highlight target nav icon
    const activeNavIconId = sectionId.replace('section-', 'nav-');
    const activeNavIcon = document.getElementById(activeNavIconId);
    if (activeNavIcon) activeNavIcon.classList.add('active');
}

function handleSectionKey(event, sectionId) {
    if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        switchActivityView(sectionId);
    }
}


function savePanelState() {
    const panel = document.getElementById('output-panel');
    const sidebar = document.getElementById('sidebar');

    // Find active section
    let activeView = 'section-reports'; // default
    const sections = ['section-reports', 'section-actions', 'section-validate', 'section-export'];
    sections.forEach(id => {
        const sec = document.getElementById(id);
        if (sec && sec.classList.contains('active')) {
            activeView = id;
        }
    });

    const state = {
        outputHeight: panel.style.height,
        outputCollapsed: panel.classList.contains('collapsed'),
        sidebarWidth: sidebar.style.width,
        sidebarCollapsed: sidebar.classList.contains('collapsed'),
        activeView: activeView
    };

    localStorage.setItem('uiLayout', JSON.stringify(state));
}

function loadPanelState() {
    const saved = localStorage.getItem('uiLayout');
    if (saved) {
        try {
            const state = JSON.parse(saved);
            const panel = document.getElementById('output-panel');
            const sidebar = document.getElementById('sidebar');

            if (state.outputHeight) panel.style.height = state.outputHeight;

            if (state.outputCollapsed) {
                panel.classList.add('collapsed');
            } else {
                panel.classList.remove('collapsed');
            }

            if (state.sidebarWidth) sidebar.style.width = state.sidebarWidth;

            if (state.sidebarCollapsed) {
                sidebar.classList.add('collapsed');
            }

            if (state.activeView) {
                activateSection(state.activeView);
            } else {
                activateSection('section-reports'); // Fallback
            }

        } catch (e) {
            console.error('Failed to load layout:', e);
            activateSection('section-reports');
        }
    }

    // Clean up old obsolete keys from section toggles
    ['section-reports', 'section-actions', 'section-validate', 'section-export'].forEach(id => {
        localStorage.removeItem(`section-${id}-collapsed`);
    });
}

// Load layout on startup
loadPanelState();
