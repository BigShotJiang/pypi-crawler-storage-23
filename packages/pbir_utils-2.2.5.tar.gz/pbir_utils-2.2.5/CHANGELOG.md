## Added
- **UI & Wireframe**: Redesigned the Fields pane to be a right-aligned collapsible bar, for better space efficiency and intuitiveness.

## Changed
- **UI**: Refined the Output pane toggle by replacing the floating blue button with a clean 24px clickable header bar.

## Fixed
- **UI & Wireframe**: Fixed an issue where the Fields pane was completely empty in static HTML wireframe exports.
