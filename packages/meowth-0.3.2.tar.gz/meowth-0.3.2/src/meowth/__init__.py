"""Meowth - GBA Pokemon ROM translation tool."""
