"""Allow running as `python -m meowth`."""
from .cli import main

main()
