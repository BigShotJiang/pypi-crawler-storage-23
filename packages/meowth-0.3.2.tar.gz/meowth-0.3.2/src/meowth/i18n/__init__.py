"""Internationalization module for user-facing messages."""

from .messages import Messages

__all__ = ["Messages"]
