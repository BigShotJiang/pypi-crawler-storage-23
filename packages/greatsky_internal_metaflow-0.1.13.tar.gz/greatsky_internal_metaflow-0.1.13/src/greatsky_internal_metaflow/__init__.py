"""GreatSky Metaflow platform CLI — authenticate and configure Metaflow."""

try:
    from greatsky_internal_metaflow._version import __version__
except ModuleNotFoundError:
    __version__ = "0.0.0-dev"
