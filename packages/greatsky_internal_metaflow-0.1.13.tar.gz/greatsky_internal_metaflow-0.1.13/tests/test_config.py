"""Tests for the 3-tier config resolution and read/write functions."""

from greatsky_internal_metaflow import config


def _make_gsm_dir(tmp_path, name=".greatsky_gsm"):
    """Create a GSM directory with config and credentials files."""
    d = tmp_path / name
    d.mkdir(parents=True)
    return d


def test_write_and_read_config(tmp_path, monkeypatch):
    gsm_dir = _make_gsm_dir(tmp_path)
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.setattr(config, "write_target_dir", lambda: gsm_dir)

    data = {"GSM_AUTH_API": "https://auth.example.com", "METAFLOW_SERVICE_AUTH_KEY": "gsk_test"}
    config.write_config(data)

    result = config.read_config()
    assert result == data


def test_write_and_read_credentials(tmp_path, monkeypatch):
    gsm_dir = _make_gsm_dir(tmp_path)
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.setattr(config, "write_target_dir", lambda: gsm_dir)

    config.write_credentials(
        api_key="gsk_test",
        expires_at="2026-03-05T00:00:00Z",
        github_user="alice",
        name="Alice",
        access_type="org_member",
    )

    creds = config.read_credentials()
    assert creds is not None
    assert creds["github_user"] == "alice"
    assert creds["api_key"] == "gsk_test"
    assert creds["access_type"] == "org_member"


def test_clear_all(tmp_path, monkeypatch):
    gsm_dir = _make_gsm_dir(tmp_path)
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.setattr(config, "write_target_dir", lambda: gsm_dir)

    config.write_config({"key": "val"})
    config.write_credentials(
        api_key="gsk_test",
        expires_at="2026-03-05",
        github_user="bob",
        name="Bob",
        access_type="invited_guest",
    )

    removed = config.clear_all()
    assert removed is True
    assert config.read_config() is None
    assert config.read_credentials() is None


def test_read_credentials_missing(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: None)
    assert config.read_credentials() is None


def test_credentials_with_guest_fields(tmp_path, monkeypatch):
    gsm_dir = _make_gsm_dir(tmp_path)
    monkeypatch.setattr(config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.setattr(config, "write_target_dir", lambda: gsm_dir)

    config.write_credentials(
        api_key="gsk_guest",
        expires_at="2026-04-01",
        github_user="external-user",
        name="External",
        access_type="invited_guest",
        invited_by="wade",
        guest_expires="2026-06-01",
    )

    creds = config.read_credentials()
    assert creds["invited_by"] == "wade"
    assert creds["guest_expires"] == "2026-06-01"


# ---- Resolution order tests ----


def test_project_dir_wins_over_venv_and_global(tmp_path, monkeypatch):
    project_root = tmp_path / "myproject"
    project_root.mkdir()
    project_gsm = project_root / ".greatsky_gsm"
    project_gsm.mkdir()
    (project_gsm / "config.json").write_text('{"from": "project"}')

    venv_dir = tmp_path / "venv"
    venv_gsm = venv_dir / ".greatsky"
    venv_gsm.mkdir(parents=True)
    (venv_gsm / "config.json").write_text('{"from": "venv"}')

    global_dir = tmp_path / "home" / ".greatsky"
    global_dir.mkdir(parents=True)
    (global_dir / "config.json").write_text('{"from": "global"}')

    monkeypatch.setattr(config, "GLOBAL_DIR", global_dir)
    monkeypatch.setattr(config, "_find_existing_project_gsm_dir", lambda: project_gsm)
    monkeypatch.setattr(config, "_venv_gsm_dir", lambda: venv_gsm)

    gsm_dir = config.resolve_gsm_dir()
    assert gsm_dir == project_gsm
    result = config.read_config()
    assert result["from"] == "project"


def test_venv_dir_used_when_no_project(tmp_path, monkeypatch):
    venv_dir = tmp_path / "venv"
    venv_gsm = venv_dir / ".greatsky"
    venv_gsm.mkdir(parents=True)
    (venv_gsm / "config.json").write_text('{"from": "venv"}')

    monkeypatch.setattr(config, "GLOBAL_DIR", tmp_path / "nonexistent")
    monkeypatch.setattr(config, "_find_existing_project_gsm_dir", lambda: None)
    monkeypatch.setattr(config, "_venv_gsm_dir", lambda: venv_gsm)

    gsm_dir = config.resolve_gsm_dir()
    assert gsm_dir == venv_gsm


def test_global_dir_used_as_fallback(tmp_path, monkeypatch):
    global_dir = tmp_path / "home" / ".greatsky"
    global_dir.mkdir(parents=True)
    (global_dir / "config.json").write_text('{"from": "global"}')

    monkeypatch.setattr(config, "GLOBAL_DIR", global_dir)
    monkeypatch.setattr(config, "_find_existing_project_gsm_dir", lambda: None)
    monkeypatch.setattr(config, "_venv_gsm_dir", lambda: None)

    gsm_dir = config.resolve_gsm_dir()
    assert gsm_dir == global_dir


def test_resolve_returns_none_when_nothing_exists(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "GLOBAL_DIR", tmp_path / "nonexistent")
    monkeypatch.setattr(config, "_find_existing_project_gsm_dir", lambda: None)
    monkeypatch.setattr(config, "_venv_gsm_dir", lambda: None)

    assert config.resolve_gsm_dir() is None


# ---- Write target tests ----


def test_write_target_prefers_project_root(tmp_path, monkeypatch):
    project_root = tmp_path / "myproject"
    project_root.mkdir()
    (project_root / "pyproject.toml").touch()

    monkeypatch.setattr(config, "_find_project_root", lambda: project_root)
    monkeypatch.setattr(config, "_venv_gsm_dir", lambda: None)

    target = config.write_target_dir()
    assert target == project_root / ".greatsky_gsm"


def test_write_target_falls_to_venv(tmp_path, monkeypatch):
    venv_gsm = tmp_path / "venv" / ".greatsky"

    monkeypatch.setattr(config, "_find_project_root", lambda: None)
    monkeypatch.setattr(config, "_venv_gsm_dir", lambda: venv_gsm)

    target = config.write_target_dir()
    assert target == venv_gsm


def test_write_target_falls_to_global(tmp_path, monkeypatch):
    monkeypatch.setattr(config, "_find_project_root", lambda: None)
    monkeypatch.setattr(config, "_venv_gsm_dir", lambda: None)

    target = config.write_target_dir()
    assert target == config.GLOBAL_DIR
