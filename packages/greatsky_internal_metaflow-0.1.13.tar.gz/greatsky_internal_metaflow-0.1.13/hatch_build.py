"""Custom hatch build hook to inject top_level.txt into the wheel dist-info.

Metaflow's extension discovery (extension_support.py) gates on
dist.read_text("top_level.txt") containing "metaflow_extensions".
Hatchling does not generate this file (it's a legacy setuptools artifact),
so without this hook the greatsky extension is silently skipped.

After injecting top_level.txt the RECORD file is updated so that the
wheel contents match — required by PyPI validation.  We rebuild the
entire zip to avoid duplicate entries (zipfile append mode cannot
remove existing entries).
"""

import base64
import csv
import hashlib
import io
import os
import shutil
import tempfile
import zipfile

from hatchling.builders.hooks.plugin.interface import BuildHookInterface


def _hash_entry(data: bytes) -> str:
    digest = base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=").decode()
    return f"sha256={digest}"


class CustomBuildHook(BuildHookInterface):
    PLUGIN_NAME = "custom"

    def finalize(self, version, build_data, artifact_path):
        if self.target_name != "wheel":
            return

        top_level_content = b"metaflow_extensions\n"

        fd, tmp_path = tempfile.mkstemp(suffix=".whl")
        os.close(fd)
        try:
            dist_info = None
            with zipfile.ZipFile(artifact_path, "r") as src, zipfile.ZipFile(tmp_path, "w") as dst:
                for item in src.infolist():
                    if item.filename.endswith(".dist-info/METADATA"):
                        dist_info = item.filename.rsplit("/", 1)[0]
                    break

                if not dist_info:
                    for item in src.infolist():
                        if item.filename.endswith(".dist-info/METADATA"):
                            dist_info = item.filename.rsplit("/", 1)[0]
                            break

                if not dist_info:
                    return

                record_name = f"{dist_info}/RECORD"
                top_level_name = f"{dist_info}/top_level.txt"

                old_record = src.read(record_name).decode()

                for item in src.infolist():
                    if item.filename == record_name:
                        continue
                    dst.writestr(item, src.read(item.filename))

                dst.writestr(top_level_name, top_level_content)

                buf = io.StringIO()
                writer = csv.writer(buf, lineterminator="\n")
                for line in old_record.splitlines():
                    if not line.strip():
                        continue
                    row = list(csv.reader([line]))[0]
                    if row[0] == record_name:
                        continue
                    writer.writerow(row)
                writer.writerow([top_level_name, _hash_entry(top_level_content), str(len(top_level_content))])
                writer.writerow([record_name, "", ""])

                dst.writestr(record_name, buf.getvalue())

            shutil.move(tmp_path, artifact_path)
        except BaseException:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
            raise
