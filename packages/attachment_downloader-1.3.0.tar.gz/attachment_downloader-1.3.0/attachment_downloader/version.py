"""
Library Version.
"""
ATTACHMENT_DOWNLOADER_VERSION = "1.3.0"
