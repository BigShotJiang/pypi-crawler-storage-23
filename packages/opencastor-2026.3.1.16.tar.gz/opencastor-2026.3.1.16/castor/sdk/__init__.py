"""castor.sdk — Auto-generated OpenAPI Python client SDK (issue #264).

Usage::

    from castor.sdk.client import CastorClient

    client = CastorClient(base_url="http://localhost:8000", token="...")
    health = client.get_health()
"""
