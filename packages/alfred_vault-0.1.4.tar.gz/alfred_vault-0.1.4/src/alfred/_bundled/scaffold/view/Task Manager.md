---
type: view
name: Task Manager
updated:
tags:
  - view
  - tasks
---

# Task Manager

---

## Open Tasks
![[view-tasks.base#Open]]

## Blocked
![[view-tasks.base#Blocked]]

## Active Projects
![[view-projects.base#Active Projects]]

---

## Workload Intelligence
<!-- ALFRED:DYNAMIC — Alfred updates this with task insights -->

*Alfred will populate this section with workload intelligence: overloaded assignees, projects with no recent task activity, tasks approaching due dates, and suggested prioritisation.*

<!-- END ALFRED:DYNAMIC -->

---

## Recently Completed
![[view-tasks.base#Recently Completed]]
