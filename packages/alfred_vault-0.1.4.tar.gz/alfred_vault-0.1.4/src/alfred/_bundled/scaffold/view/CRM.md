---
type: view
name: CRM
updated:
tags:
  - view
  - crm
---

# CRM

---

## People
![[view-crm.base#People]]

## Organisations
![[view-crm.base#Organisations]]

## Active Conversations
![[view-crm.base#Active Conversations]]

## Waiting On Others
![[view-crm.base#Waiting]]

## Accounts
![[view-crm.base#Accounts]]

## Assets
![[view-crm.base#Assets]]

---

## Relationship Intelligence
<!-- ALFRED:DYNAMIC — Alfred updates this with CRM insights -->

*Alfred will populate this section with relationship intelligence: contacts going cold, orgs with open conversations, accounts nearing renewal, key relationships to nurture.*

<!-- END ALFRED:DYNAMIC -->
