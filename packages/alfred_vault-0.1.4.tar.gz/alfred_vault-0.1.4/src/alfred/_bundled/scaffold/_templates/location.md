---
type: location
status: active
name:
description:
address:
project: # Link to Project
related: []
relationships: []
created: "{{date}}"
tags: []
---

# {{title}}

## Related
![[related.base#All]]
