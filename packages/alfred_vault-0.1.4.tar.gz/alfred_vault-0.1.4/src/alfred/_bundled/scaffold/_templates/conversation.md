---
type: conversation
status: active # active | waiting | resolved | archived
channel: email # email | zoom | in-person | phone | chat | voice-memo | mixed
subject:
participants: []
project:
org:
external_id: # Source system's thread/conversation ID
message_count: 0
last_activity: "{{date}}"
opened: "{{date}}"
created: "{{date}}"
forked_from:
fork_reason:
alfred_instructions:
related: []
relationships: []
tags: []
---

# {{title}}

## Current State

**Status:**
**Ball in court of:**
**Last activity:**
**Risk/urgency:**
**Next expected action:**

## Activity Log

| Date | Who | Action |
|------|-----|--------|

## Messages
![[conversation-detail.base#Messages]]

## Tasks
![[conversation-detail.base#Tasks]]

## Related
![[conversation-detail.base#Related]]
