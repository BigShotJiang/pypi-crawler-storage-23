---
type: constraint
status: active # active | expired | waived | superseded
source: "" # regulation, contract, physics, policy
source_date:
authority: "" # who/what imposes this (council, contract, law)
project: [] # [[project links]]
location: [] # [[location links]]
related: []
created: "{{date}}"
tags: []
---

# {{title}}

## Constraint

<!-- What exactly is constrained, and what are the limits -->

## Source

<!-- Where does this constraint come from? Regulation, contract, physics? -->

## Implications

<!-- What does this prevent or require? What workarounds exist? -->

## Expiry / Review

<!-- Does this expire? When should it be re-checked? -->

![[learn-constraint.base#Affected Projects]]
![[learn-constraint.base#Related]]
