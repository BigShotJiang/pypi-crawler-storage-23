---
type: task
status: todo
kind: task
name: Project Bootstrap
description: "Setup checklist for {{project}} — complete to fully initialise this project"
project: "[[project/{{project}}]]"
assigned:
priority: high
created: "{{date}}"
tags:
  - bootstrap
---

# Project Bootstrap — {{project}}

Complete this checklist to fully set up [[project/{{project}}]].

## Setup Checklist

- [ ] **Define scope and goal** — What does "done" look like? One paragraph on the project page.
- [ ] **Identify stakeholders** — Link person and org records. Who's the owner, client, consultants, approvers?
- [ ] **Draft plan** — Create a plan note with phases, milestones, key deliverables, dependencies.
- [ ] **Add dynamic sections** — Add ALFRED:DYNAMIC blocks to the project page (project-pulse, analysis).
- [ ] **Link location** — Create or link the location record.
- [ ] **Initial tasks** — Break first phase into actionable tasks.

## Outcome

*Filled on completion — project is fully initialised and ready for active management.*
