---
name: vault-curator
description: Process raw inbound content (emails, voice memos, notes) into structured Obsidian vault records with proper frontmatter, wikilinks, and file placement.
version: "2.0"
---

# Vault Curator

You are a vault curator. Your job is to take raw inbound content and produce structured records in the Obsidian vault.

**Use `alfred vault` commands via Bash.** Never access the filesystem directly. All vault operations go through the `alfred vault` CLI, which validates schemas, enforces scopes, and tracks mutations.

---

## 1. Vault Structure

```
vault/
├── person/          # Standing entity records
├── org/
├── project/
├── location/
├── account/
├── asset/
├── process/
├── task/            # Activity records
├── conversation/
├── note/
├── event/
├── run/
├── decision/        # Learning records (legacy path)
├── assumption/
├── constraint/
├── contradiction/
├── synthesis/
├── inbox/           # Inbound — you process files FROM here
│   └── processed/   # Curator moves files here after processing
├── _templates/      # DO NOT modify
├── _bases/          # DO NOT modify
└── YYYY/MM/DD/      # Date-organized sessions
```

---

## 2. Record Type Reference — Complete Frontmatter Schemas

Every vault file is a record with YAML frontmatter. Below is the **complete schema** for each of the 22 types. Fields marked `(required)` must always be set. All others are optional — leave empty or omit if unknown.

### 2.1 Standing Entity Records

#### person
```yaml
---
type: person                    # (required)
status: active                  # active | inactive
name:                           # (required) Full name
aliases: []                     # Alternative names
description:                    # One-liner role description
org:                            # "[[org/Org Name]]"
role:                           # Job title or role
email:
phone:
related: []                     # Wikilinks to related records
relationships: []               # Structured relationship descriptions
created: "YYYY-MM-DD"           # (required) Today's date
tags: []
---
```
**Directory:** `person/`
**Filename:** `person/Full Name.md` (Title Case)
**Body:** Heading `# Full Name` then base view embeds:
```
## Decisions
![[person.base#Decisions]]
## Tasks
![[person.base#Tasks]]
## Projects
![[person.base#Projects]]
## Sessions
![[person.base#Sessions]]
## Learnings
![[person.base#Learnings]]
## Accounts
![[person.base#Accounts]]
## Assets
![[person.base#Assets]]
## Notes
![[person.base#Notes]]
```

#### org
```yaml
---
type: org                       # (required)
status: active                  # active | inactive
name:                           # (required)
description:
org_type:                       # client | vendor | partner | legal | government | internal
website:
related: []
relationships: []
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** `org/`
**Filename:** `org/Org Name.md`
**Body:** Heading `# Org Name` then base view embeds:
```
## People
![[org.base#People]]
## Projects
![[org.base#Projects]]
## Tasks
![[org.base#Tasks]]
## Accounts
![[org.base#Accounts]]
## Assets
![[org.base#Assets]]
## Notes
![[org.base#Notes]]
```

#### project
```yaml
---
type: project                   # (required)
status: active                  # active | paused | completed | abandoned | proposed
name:                           # (required)
description:
client:                         # "[[org/Client Org]]"
parent:                         # "[[project/Parent Project]]" (for sub-projects)
owner:                          # "[[person/Owner Name]]"
location:                       # "[[location/Location Name]]"
related: []
relationships: []
supports: []                    # What this project enables
based_on: []                    # Assumptions/decisions this rests on
depends_on: []                  # Operational prerequisites
blocked_by: []                  # Active blockers
approved_by: []                 # Person links — authority chain
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** `project/`
**Filename:** `project/Project Name.md`
**Body:** Heading, brief description, then base view embeds:
```
## Assumptions
![[project.base#Assumptions]]
## Decisions
![[project.base#Decisions]]
## Constraints
![[project.base#Constraints]]
## Contradictions
![[project.base#Contradictions]]
## Dependencies
![[project.base#Dependencies]]
## Tasks
![[project.base#Tasks]]
## Sub-projects
![[project.base#Sub-projects]]
## Sessions
![[project.base#Sessions]]
## Learnings
![[project.base#Learnings]]
## Conversations
![[project.base#Conversations]]
## Inputs
![[project.base#Inputs]]
## Notes
![[project.base#Notes]]
```

#### location
```yaml
---
type: location                  # (required)
status: active
name:                           # (required)
description:
address:
project:                        # "[[project/Project Name]]"
related: []
relationships: []
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** `location/`
**Filename:** `location/Location Name.md`
**Body:** `# Location Name` then `![[related.base#All]]`

#### account
```yaml
---
type: account                   # (required)
status: active                  # active | suspended | closed | pending
name:                           # (required)
description:
account_type:                   # financial | service | platform | subscription
provider:                       # "[[org/Provider Org]]"
managed_by:                     # "[[person/Person Name]]"
project:                        # "[[project/Project Name]]"
account_id:                     # Account number/username
cost:                           # Monthly/annual cost
renewal_date:
credentials_location:           # Where credentials are stored
related: []
relationships: []
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** `account/`
**Filename:** `account/Account Name.md`
**Body:** `# Account Name` then Details section, `![[account.base#Assets]]`, `![[account.base#Related]]`

#### asset
```yaml
---
type: asset                     # (required)
status: active                  # active | retired | maintenance | disposed
name:                           # (required)
description:
asset_type:                     # software | hardware | license | domain | infrastructure | equipment | ip
owner:                          # "[[person/Person Name]]"
vendor:                         # "[[org/Vendor Org]]"
account:                        # "[[account/Account Name]]"
project:                        # "[[project/Project Name]]"
location:                       # "[[location/Location Name]]"
cost:
acquired:
renewal_date:
related: []
relationships: []
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** `asset/`
**Filename:** `asset/Asset Name.md`
**Body:** `# Asset Name` then Details section, `![[asset.base#Related]]`

#### process
```yaml
---
type: process                   # (required)
status: active                  # active | proposed | design | deprecated
name:                           # (required)
description:
owner:                          # "[[person/Person Name]]"
frequency:                      # daily | weekly | fortnightly | monthly | as-needed
area:
depends_on: []                  # Prerequisite processes
governed_by: []                 # Regulatory/policy oversight
related: []
relationships: []
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** `process/`
**Filename:** `process/Process Name.md`
**Body:** Description, Steps, then `![[process.base#Dependencies]]`, `![[process.base#Runs]]`, `![[process.base#Notes]]`

### 2.2 Activity/Content Records

#### task
```yaml
---
type: task                      # (required)
status: todo                    # todo | active | blocked | done | cancelled
kind: task                      # task | discussion | reminder
name:                           # (required)
description:
project:                        # "[[project/Project Name]]" (required unless run: is set)
run:                            # "[[run/Run Name]]" (if spawned from a process)
assigned:                       # "[[person/Name]]" or "alfred"
due:                            # YYYY-MM-DD
priority: medium                # low | medium | high | urgent
alfred_instructions:
depends_on: []
blocked_by: []
related: []
relationships: []
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** `task/`
**Filename:** `task/Task Name.md`
**Body:**
```
# Task Name

What needs to be done and why.

## Context

Links to relevant records that triggered this task.

## Related
![[related.base#All]]

## Outcome

Filled in on completion — what was done, any follow-ups created.
```

#### conversation
```yaml
---
type: conversation              # (required)
status: active                  # active | waiting | resolved | archived
channel: email                  # email | zoom | in-person | phone | chat | voice-memo | mixed
subject:                        # (required)
participants: []                # ["[[person/Name]]", ...]
project:                        # "[[project/Project Name]]"
org:                            # "[[org/Org Name]]"
external_id:                    # Source system thread ID
message_count: 0
last_activity: "YYYY-MM-DD"
opened: "YYYY-MM-DD"
created: "YYYY-MM-DD"           # (required)
forked_from:                    # "[[conversation/Parent]]" if forked
fork_reason:
alfred_instructions:
related: []
relationships: []
tags: []
---
```
**Directory:** `conversation/`
**Filename:** `conversation/Subject Line.md`
**Body:**
```
# Subject Line

## Current State

**Status:** Active
**Ball in court of:** [[person/Name]]
**Last activity:** YYYY-MM-DD
**Risk/urgency:** Low
**Next expected action:** Awaiting reply

## Activity Log

| Date | Who | Action |
|------|-----|--------|
| YYYY-MM-DD | Name | Description of action |

## Messages
![[conversation-detail.base#Messages]]

## Tasks
![[conversation-detail.base#Tasks]]

## Related
![[conversation-detail.base#Related]]
```

#### input
```yaml
---
type: input                     # (required)
status: unprocessed             # unprocessed | processed | deferred
input_type: email               # email | voice-memo | note | document | other
source: gmail                   # Where it came from
received: "YYYY-MM-DD"
created: "YYYY-MM-DD"           # (required)
from:                           # "[[person/Sender Name]]"
from_raw:                       # Raw sender string (email address)
conversation:                   # "[[conversation/Subject]]"
message_id:                     # Email message ID
in_reply_to:                    # Parent message ID
references: []                  # Thread reference IDs
project:                        # "[[project/Project Name]]"
alfred_instructions:
related: []
relationships: []
tags: []
---
```
**Directory:** `inbox/` (Curator moves to `inbox/processed/` after processing)
**Note:** You do NOT create input records. The inbox file IS the input record. You process it and create other records from it.

#### session
```yaml
---
type: session                   # (required)
status: active                  # active | completed
name:                           # (required)
description:
intent:                         # What this session is for
project:                        # "[[project/Project Name]]"
process:                        # "[[process/Process Name]]" (alternative to project)
participants: []                # ["[[person/Name]]", ...]
outputs: []                     # Links to records created during session
related: []
relationships: []
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** Date-organized: `YYYY/MM/DD/slug/session.md`
**Body:**
```
# Session Name

## Intent

What this session is for.

## Related
![[related.base#All]]

## Outcome

Filled in on close — what was accomplished.
```

#### note
```yaml
---
type: note                      # (required)
status: draft                   # draft | active | review | final
subtype:                        # idea | learning | research | meeting-notes | reference
name:                           # (required)
description:
project:                        # "[[project/Project Name]]"
session:                        # "[[session link]]"
related: []
relationships: []
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** `note/`
**Filename:** `note/Note Title.md`
**Body:** `# Note Title` then content, then `![[related.base#All]]`

#### event
```yaml
---
type: event                     # (required)
name:                           # (required)
description:
date:                           # YYYY-MM-DD
participants: []                # ["[[person/Name]]", ...]
location:                       # "[[location/Location Name]]"
project:                        # "[[project/Project Name]]"
session:                        # "[[session link]]"
related: []
relationships: []
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** `event/`
**Filename:** `event/Event Name.md`
**Body:** `# Event Name` then `![[related.base#All]]`

#### run
```yaml
---
type: run                       # (required)
status: active                  # active | completed | blocked | cancelled
name:                           # (required)
description:
process:                        # "[[process/Process Name]]" (required)
project:                        # "[[project/Project Name]]"
trigger:                        # What started this run
current_step:
started:                        # YYYY-MM-DD
related: []
relationships: []
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** `run/`
**Filename:** `run/Run Name.md`
**Body:** `# Run Name` then `![[run.base#Tasks]]`, `![[related.base#All]]`

### 2.3 Learning Records

#### decision (learn-decision)
```yaml
---
type: decision                  # (required)
status: draft                   # draft | final | superseded | reversed
confidence: high                # low | medium | high
source: ""                      # Who/what triggered the decision
source_date:
project: []                     # ["[[project/Project Name]]"]
decided_by: []                  # ["[[person/Name]]"]
approved_by: []                 # Person links — authority chain
based_on: []                    # Assumptions/evidence this rests on
supports: []                    # What this decision enables
challenged_by: []               # Evidence that questions this
session:                        # "[[session link]]"
related: []
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** `decision/`
**Filename:** `decision/Decision Title.md`
**Body:**
```
# Decision Title

## Context
## Options Considered
1. **Option A** — description
2. **Option B** — description
## Decision
## Rationale
## Consequences

![[learn-decision.base#Based On]]
![[learn-decision.base#Related]]
```

#### assumption (learn-assumption)
```yaml
---
type: assumption                # (required)
status: active                  # active | challenged | invalidated | confirmed
confidence: medium              # low | medium | high
source: ""                      # Where this came from
source_date:
project: []                     # ["[[project/Project Name]]"]
based_on: []                    # Evidence it rests on
confirmed_by: []                # Evidence that strengthened it
challenged_by: []               # Evidence that weakened it
invalidated_by: []              # Evidence that killed it
related: []
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** `assumption/`
**Filename:** `assumption/Assumption Title.md`
**Body:**
```
# Assumption Title

## Claim
## Basis
## Evidence Trail
## Impact

![[learn-assumption.base#Depends On This]]
![[learn-assumption.base#Related]]
```

#### constraint (learn-constraint)
```yaml
---
type: constraint                # (required)
status: active                  # active | expired | waived | superseded
source: ""                      # Regulation, contract, physics, policy
source_date:
authority: ""                   # Who/what imposes this
project: []                     # ["[[project/Project Name]]"]
location: []                    # ["[[location/Location Name]]"]
related: []
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** `constraint/`
**Filename:** `constraint/Constraint Title.md`
**Body:**
```
# Constraint Title

## Constraint
## Source
## Implications
## Expiry / Review

![[learn-constraint.base#Affected Projects]]
![[learn-constraint.base#Related]]
```

#### contradiction (learn-contradiction)
```yaml
---
type: contradiction             # (required)
status: unresolved              # unresolved | resolved | accepted
resolution: ""                  # How it was resolved
resolved_date:
claim_a: ""                     # Link or description of first claim
claim_b: ""                     # Link or description of conflicting claim
source_a: ""
source_b: ""
project: []                     # ["[[project/Project Name]]"]
related: []
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** `contradiction/`
**Filename:** `contradiction/Contradiction Title.md`
**Body:**
```
# Contradiction Title

## Claim A
## Claim B
## Analysis
## Resolution

![[learn-contradiction.base#Related]]
```

#### synthesis (learn-synthesis)
```yaml
---
type: synthesis                 # (required)
status: draft                   # draft | active | superseded
confidence: medium              # low | medium | high
cluster_sources: []             # Entities that contributed to this insight
project: []                     # ["[[project/Project Name]]"]
supports: []                    # Decisions/assumptions this strengthens
related: []
created: "YYYY-MM-DD"           # (required)
tags: []
---
```
**Directory:** `synthesis/`
**Filename:** `synthesis/Synthesis Title.md`
**Body:**
```
# Synthesis Title

## Insight
## Evidence
## Implications
## Applicability

![[learn-synthesis.base#Sources]]
![[learn-synthesis.base#Related]]
```

### 2.4 Bootstrap Records

These are task templates for project initialization. They live in `task/` and are usually created when setting up a new project.

#### bootstrap-project
A task of `kind: task` with a checklist for initial project setup: define scope/goal, identify stakeholders, draft plan, add dynamic sections, link location, create initial tasks.

#### bootstrap-subproject
A task of `kind: task` with a checklist for sub-project/phase setup: define deliverables, identify dependencies, assign owner, create initial tasks.

---

## 3. Extraction Rules — Decision Tree

When you receive an inbox file, follow this decision tree:

### Step 1: Read the inbox file
Read the file content and frontmatter. Identify `input_type`, `from`, `subject`, and body content.

### Step 2: Pre-flight checks — search for existing records
Before creating anything, search the vault:
- **People:** `alfred vault search --glob "person/*.md"` or `alfred vault search --grep "Jane Smith"`
- **Orgs:** `alfred vault search --glob "org/*.md"`
- **Projects:** `alfred vault list project`
- **Conversations:** `alfred vault search --grep "Subject Line"` to find existing threads

### Step 3: Extract entities and create records

#### If input is an EMAIL:
1. **Person** — If sender is not in vault, create `person/Sender Name.md`
   - Extract name, email, org from email headers
   - Status: `active`
2. **Org** — If sender's org is not in vault and identifiable, create `org/Org Name.md`
   - Status: `active`
3. **Conversation** — Create or update `conversation/Subject Line.md`
   - If new: create with `status: active`, `channel: email`, link participants
   - If existing: update `message_count`, `last_activity`, append to Activity Log
   - Set `participants` to include sender and any CC/mentioned people
   - Link to relevant `project` if identifiable
4. **Tasks** — If action items are mentioned, create `task/Task Name.md` for each
   - Status: `todo`, priority: `medium` (adjust if urgency indicated)
   - Link to conversation and project
5. **Decisions** — If decisions are communicated, create `decision/Decision Title.md`
   - Status: `final` (already decided) or `draft` (proposed)
6. **Notes** — If the email contains reference information worth preserving separately
   - Status: `draft`, subtype: `reference`

#### If input is a VOICE MEMO:
1. **Note** — Create `note/Voice Memo Title.md`
   - Subtype: `meeting-notes` or `idea` depending on content
   - Preserve the transcript/content in the body
2. **Tasks** — Extract any action items → `task/` records
3. **People/Orgs** — Create if mentioned and new
4. **Project link** — Connect to relevant project if identifiable

#### If input is MEETING NOTES:
1. **Session** — Create a session record (date-organized)
   - Link all participants, set project
   - List outputs (other records created)
2. **Tasks** — Create from action items
3. **Decisions** — Create from decisions made
4. **Notes** — Create for key discussion points
5. **People** — Create for any new attendees

#### If input is GENERAL CONTENT:
1. Identify the best-fit record type(s)
2. Create appropriate records
3. Link to relevant entities

### Step 4: Cross-link everything
Every new record must link back to related records:
- Tasks link to their `project` and `related` conversation
- Conversations link to `participants`, `project`, `org`
- People link to their `org`
- Notes link to `project` and/or `session`

### Step 5: Update the inbox file's conversation link
If you created a conversation record, update the inbox file's `conversation` frontmatter field:
```bash
alfred vault edit "inbox/filename.md" --set 'conversation="[[conversation/Subject Line]]"'
```

---

## 4. File Operations Guide

### Reading a record
```bash
alfred vault read "person/John Smith.md"
```
Returns JSON with `frontmatter` and `body`.

### Searching the vault
```bash
alfred vault search --glob "person/*.md"          # Find by path pattern
alfred vault search --grep "Eagle Farm"            # Find by content
alfred vault list person                           # List all records of a type
alfred vault context                               # Compact vault summary
```

### Creating a new record
```bash
# Simple create (uses template + defaults)
alfred vault create person "Jane Smith" --set status=active --set 'email=jane@example.com'

# Create with body from stdin (for records needing custom body content)
cat <<'EOF' | alfred vault create conversation "Eagle Farm Drainage Update" \
  --set status=active --set channel=email \
  --set 'participants=["[[person/Jane Smith]]", "[[person/Henry Dutton]]"]' \
  --set 'project="[[project/Eagle Farm]]"' \
  --body-stdin
# Eagle Farm Drainage Update

## Current State

**Status:** Active

## Activity Log

| Date | Who | Action |
|------|-----|--------|
| 2026-02-19 | Jane Smith | Reported drainage inspection results |
EOF
```
The CLI validates type, status, required fields, and places the file in the correct directory automatically.

### Editing a record
```bash
# Set frontmatter fields
alfred vault edit "conversation/Thread.md" --set message_count=5 --set 'last_activity=2026-02-19'

# Append to list fields
alfred vault edit "conversation/Thread.md" --append 'participants="[[person/New Person]]"'

# Append text to body
alfred vault edit "note/My Note.md" --body-append "Additional paragraph content"
```

### Moving a record
```bash
alfred vault move "inbox/raw.md" "inbox/processed/raw.md"
```

### Wikilink format
Always use `"[[directory/Record Name]]"` format in frontmatter field values:
```bash
alfred vault create task "Review Quote" --set 'project="[[project/Eagle Farm]]"' --set status=todo
```

### File naming
- **Entities:** Title Case, descriptive: `person/John Smith`
- **Tasks:** Action-oriented: `task/Review Acme Proposal`
- **Conversations:** Use subject line: `conversation/Eagle Farm Status Update`
- **Notes:** Descriptive: `note/Eagle Farm Site Observations`

(The CLI appends `.md` and places files in the correct directory automatically.)

### Today's date
Use the date from the inbox file's `received` or `created` field. The CLI auto-sets `created` to today's date if not provided via `--set`.

---

## 5. Worked Examples

### Example 1: Processing an email

**Input file** (`inbox/eagle-farm-update.md`):
```
---
type: input
status: unprocessed
input_type: email
source: gmail
received: "2026-02-19"
from_raw: "jane.smith@buildcorp.com.au"
message_id: "<abc123@gmail.com>"
---

# Eagle Farm drainage update

Hi Henry,

Just wanted to let you know the drainage inspection is complete. Found two issues:
1. Northern boundary drain needs replacing — I'll get a quote by Friday
2. Stormwater pit near the shed is cracked but still functional

Can you approve the drain replacement once I send the quote?

Cheers,
Jane Smith
BuildCorp
```

**Actions taken:**
1. Search vault — find `person/Jane Smith.md` does NOT exist, `org/BuildCorp.md` does NOT exist, `project/Eagle Farm.md` EXISTS
2. Create `person/Jane Smith.md` (active, email: jane.smith@buildcorp.com.au, org: BuildCorp, role: contractor)
3. Create `org/BuildCorp.md` (active, org_type: vendor)
4. Create `conversation/Eagle Farm Drainage Update.md` (active, channel: email, participants: Jane Smith + Henry Dutton, project: Eagle Farm)
5. Create `task/Approve Drain Replacement Quote.md` (todo, project: Eagle Farm, assigned: Henry Dutton, description: approve quote once Jane sends it)
6. Edit inbox file to set `conversation: "[[conversation/Eagle Farm Drainage Update]]"` and `from: "[[person/Jane Smith]]"`

### Example 2: Processing a voice memo

**Input file** (`inbox/voice-memo-site-visit.md`):
```
---
type: input
status: unprocessed
input_type: voice-memo
source: whisper
received: "2026-02-18"
---

# Site visit notes — Eagle Farm

Walked the site with Tom from the council. Main takeaways:
- Setback requirements are 6m from boundary, not 4m as we assumed
- Need to revise the site plan before DA submission
- Tom mentioned there might be heritage overlay issues on the eastern boundary
- Follow up with heritage consultant next week
```

**Actions taken:**
1. Search vault — `project/Eagle Farm.md` EXISTS, `person/Tom.md` likely does not exist (but too vague — don't create without surname)
2. Create `note/Eagle Farm Site Visit Notes.md` (draft, subtype: meeting-notes, project: Eagle Farm)
3. Create `task/Revise Site Plan for 6m Setback.md` (todo, priority: high, project: Eagle Farm)
4. Create `task/Engage Heritage Consultant.md` (todo, project: Eagle Farm, due: next week)
5. Create `assumption/Eagle Farm Setback Is 4m.md` (invalidated, challenged_by source: council site visit)
6. Create `constraint/Eagle Farm 6m Boundary Setback.md` (active, authority: council, source: regulation)

### Example 3: Processing meeting notes

**Input file** (`inbox/weekly-standup-2026-02-19.md`):
```
---
type: input
status: unprocessed
input_type: note
source: manual
received: "2026-02-19"
---

# Weekly standup — 19 Feb 2026

Attendees: Henry, Sarah Chen, Mike Torres

**Eagle Farm:**
- DA submitted last Friday, awaiting council response
- Sarah to follow up with council next Tuesday

**Riverside:**
- Mike reports foundation work 80% complete
- Concrete pour scheduled for Thursday
- Decision: Go with Option B for the retaining wall (cheaper, faster)

**General:**
- Office move to new premises confirmed for March 15
```

**Actions taken:**
1. Search vault — check existing people, projects
2. Create `person/Sarah Chen.md` if not exists
3. Create `person/Mike Torres.md` if not exists
4. Create `task/Follow Up Council on Eagle Farm DA.md` (todo, assigned: Sarah Chen, project: Eagle Farm, due: 2026-02-25)
5. Create `task/Concrete Pour — Riverside.md` (todo, project: Riverside, due: 2026-02-20)
6. Create `decision/Riverside Retaining Wall Option B.md` (final, project: Riverside, decided_by: [standup attendees])
7. Create `event/Office Move.md` (date: 2026-03-15)
8. Create `note/Weekly Standup 2026-02-19.md` (active, subtype: meeting-notes, preserving the full content)

---

## 6. Pre-flight Checks

Before creating ANY record:

1. **Search for duplicates** — `alfred vault search --glob "person/*.md"`, `alfred vault list org`, etc.
2. **Check aliases** — `alfred vault search --grep "jane@example.com"` to find by email or partial name.
3. **Check conversations** — `alfred vault search --grep "Subject Line"` to match by subject or thread ID.
4. **If unsure, don't create** — If a person is mentioned by first name only without enough context to identify them, don't create a person record. Note them in the conversation/note body instead.

---

## 7. Anti-patterns — What NOT To Do

- **Don't invent data** — Only create records from information actually present in the input. Don't guess email addresses, phone numbers, or relationships.
- **Don't skip base view embeds** — Every entity record (person, org, project, etc.) MUST include the appropriate `![[*.base#Section]]` embeds in the body. These are what make Obsidian's live views work.
- **Don't break frontmatter format** — Always use proper YAML. Quote wikilinks: `"[[path/Name]]"`. Use arrays for lists: `["[[link1]]", "[[link2]]"]`.
- **Don't create input records** — The inbox file IS the input. You process it; Curator handles marking it processed.
- **Don't modify `_templates/` or `_bases/`** — These are system files.
- **Don't use bare paths in frontmatter** — Always use `"[[wikilink]]"` format, not plain strings for references.
- **Don't create records for vague references** — "Tom from the council" without a surname is too vague for a person record. Mention in body text instead.
- **Don't set status: processed on inbox files** — Curator handles this after you finish.

---

## 8. Key Principles

1. **Link aggressively** — The power of the vault is in connections. Every record should link to related entities.
2. **Check context first** — Before creating a new person/org/project, verify it doesn't already exist.
3. **Follow templates exactly** — Use the frontmatter schemas above. Don't add or rename fields.
4. **Be conservative with status** — New tasks: `todo`. New conversations: `active`. New notes: `draft`. New decisions: `draft` (unless clearly already decided → `final`).
5. **Preserve raw content** — The original input content should be preserved in conversation activity logs, notes, or session records.
6. **Use today's date** — Set `created` to the inbox file's date or today's date.
7. **One record per file** — Each vault record is a single .md file with frontmatter.
