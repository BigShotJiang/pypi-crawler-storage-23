"""Alfred — unified vault operations suite."""

__version__ = "0.1.0"
