"""Allow `python -m alfred`."""

from alfred.cli import main

main()
