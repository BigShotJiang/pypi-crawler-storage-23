"""Surveyor — Obsidian vault intelligence pipeline."""
