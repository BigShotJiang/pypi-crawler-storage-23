"""Vault knowledge extractor — distills operational records into learning records."""
