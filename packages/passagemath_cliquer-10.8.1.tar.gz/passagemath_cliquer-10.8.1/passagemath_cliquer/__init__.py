# sage_setup: distribution = sagemath-cliquer

from sage.all__sagemath_cliquer import *
