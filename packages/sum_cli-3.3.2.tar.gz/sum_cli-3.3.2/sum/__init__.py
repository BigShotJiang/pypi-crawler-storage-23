"""CLI v2 core package."""
