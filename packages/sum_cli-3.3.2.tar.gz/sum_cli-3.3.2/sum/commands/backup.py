# pyright: reportImplicitStringConcatenation=false, reportUnusedCallResult=false

"""Backup command implementation using pgBackRest.

Creates and manages backups using pgBackRest for bare metal PostgreSQL clusters.
"""

from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path
from types import ModuleType

from sum.exceptions import SetupError
from sum.setup.bare_metal_postgres import DEFAULT_PGBACKREST_WRAPPER
from sum.setup.ports import get_site_port
from sum.system_config import ConfigurationError, SystemConfig, get_system_config
from sum.utils.output import OutputFormatter
from sum.utils.preflight import (
    CipherPassFileCheck,
    DiskSpaceCheck,
    PgBackRestStanzaCheck,
    PostgresClusterCheck,
    PreflightRunner,
    SiteExistsCheck,
    SystemConfigCheck,
)
from sum.utils.privilege import require_root_or_escalate
from sum.utils.validation import validate_site_slug

click_module: ModuleType | None
try:
    import click as click_module
except ImportError:  # pragma: no cover
    click_module = None

click: ModuleType | None = click_module


def _update_backup_status(site_dir: Path) -> None:
    """Write backup status marker file for health check.

    The health endpoint reads this file to determine if backups are recent.
    Writes current Unix timestamp to the marker file.

    Args:
        site_dir: Site directory where the marker file is stored.
    """
    marker_file = site_dir / "backup_status"
    try:
        marker_file.write_text(str(int(time.time())))
    except OSError:
        # Best-effort: don't fail backup if marker write fails
        pass


def _check_backup_configured(config: SystemConfig, site_slug: str) -> None:
    """Check that backups are configured for this site.

    Validates both global backup configuration and per-site pgBackRest
    stanza config file existence.

    Args:
        config: System configuration.
        site_slug: Site slug.

    Raises:
        SetupError: If backups not configured or stanza file missing.
    """
    if not config.backups:
        raise SetupError(
            "Backups not configured. Run 'sum-platform setup' and enable backup storage."
        )

    stanza_file = config.get_pgbackrest_config_dir() / f"{site_slug}.conf"
    if not stanza_file.exists():
        raise SetupError(
            f"No pgBackRest stanza configured for site '{site_slug}'. "
            f"Expected config file at: {stanza_file}\n"
            "Run 'sum-platform init' with backup setup or create the stanza manually."
        )


def _check_storage_box_reachable(config: SystemConfig) -> None:
    """Verify Storage Box is reachable via SFTP.

    This is a quick connectivity pre-check only. The actual backup operation
    uses pgBackRest which verifies the host fingerprint via its config
    (repo1-sftp-host-fingerprint). This pre-check uses StrictHostKeyChecking=accept-new
    (TOFU model) since full fingerprint verification happens during the real backup.

    Args:
        config: System configuration with backup settings.

    Raises:
        SetupError: If Storage Box is not reachable.
    """
    if not config.backups:
        return

    storage = config.backups.storage_box
    # Use sftp with batch mode to test connectivity
    # -b /dev/null ensures non-interactive mode (exits immediately after connect)
    # accept-new: accepts first-seen keys but rejects changed keys (TOFU model)
    # pgBackRest verifies the full fingerprint during the actual backup
    cmd = [
        "sftp",
        "-b",
        "/dev/null",
        "-o",
        "BatchMode=yes",
        "-o",
        "StrictHostKeyChecking=accept-new",
        "-o",
        "ConnectTimeout=10",
        "-o",
        f"Port={storage.port}",
        "-i",
        storage.ssh_key,
        f"{storage.user}@{storage.host}",
    ]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode != 0:
            raise SetupError(
                f"Cannot connect to Storage Box: {result.stderr.strip()}\n"
                f"Check SSH key and network connectivity to {storage.host}:{storage.port}"
            )
    except subprocess.TimeoutExpired as exc:
        raise SetupError(
            f"Timeout connecting to Storage Box at {storage.host}:{storage.port}"
        ) from exc
    except FileNotFoundError as exc:
        raise SetupError(
            "sftp command not found. Is openssh-client installed?"
        ) from exc


def _run_pgbackrest(
    site_slug: str,
    args: list[str],
    config: SystemConfig,
) -> subprocess.CompletedProcess[str]:
    """Run pgbackrest command as postgres user.

    Args:
        site_slug: Site slug (used as stanza name).
        args: Additional pgbackrest arguments.
        config: System configuration for paths.

    Returns:
        CompletedProcess result.

    Raises:
        SetupError: If command fails.
    """
    config_include_path = str(config.get_pgbackrest_config_dir())
    cmd = [
        "sudo",
        "-u",
        "postgres",
        DEFAULT_PGBACKREST_WRAPPER,
        f"--config-include-path={config_include_path}",
        f"--stanza={site_slug}",
    ] + args

    try:
        result = subprocess.run(
            cmd,
            check=True,
            capture_output=True,
        )
        # Decode output safely — pgBackRest may emit binary data
        return subprocess.CompletedProcess(
            result.args,
            result.returncode,
            stdout=(
                result.stdout.decode("utf-8", errors="replace")
                if isinstance(result.stdout, bytes)
                else (result.stdout or "")
            ),
            stderr=(
                result.stderr.decode("utf-8", errors="replace")
                if isinstance(result.stderr, bytes)
                else (result.stderr or "")
            ),
        )
    except subprocess.CalledProcessError as exc:
        # pgbackrest writes errors to stdout with log prefixes, not stderr.
        # Output may contain binary data, so decode safely.
        stdout = (
            exc.stdout.decode("utf-8", errors="replace")
            if isinstance(exc.stdout, bytes)
            else (exc.stdout or "")
        )
        stderr = (
            exc.stderr.decode("utf-8", errors="replace")
            if isinstance(exc.stderr, bytes)
            else (exc.stderr or "")
        )
        error_output = stdout or stderr or "No error output"
        raise SetupError(f"pgBackRest command failed: {error_output}") from exc
    except FileNotFoundError as exc:
        raise SetupError(
            f"pgbackrest wrapper not found at {DEFAULT_PGBACKREST_WRAPPER}. "
            "Is pgBackRest installed and was 'sum-platform init' run?"
        ) from exc


def run_backup(
    site_name: str,
    *,
    backup_type: str = "diff",
    list_backups: bool = False,
    skip_preflight: bool = False,
) -> int:
    """Create or list backups using pgBackRest.

    Args:
        site_name: Name/slug of the site.
        backup_type: Backup type (full, diff, incr).
        list_backups: List available backups instead of creating one.

    Returns:
        Exit code (0 for success, non-zero for failure).
    """
    try:
        validate_site_slug(site_name)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    require_root_or_escalate("backup")

    # Pre-flight checks (phase 1: config-independent)
    early_results: list = []
    if not skip_preflight:
        runner = PreflightRunner()
        runner.register(SystemConfigCheck())
        early_results = runner.run()
        if not PreflightRunner.is_go(early_results):
            print(PreflightRunner.format_results(early_results))
            OutputFormatter.error("Pre-flight checks failed. Aborting.")
            return 1

    try:
        config = get_system_config()
    except ConfigurationError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # Pre-flight checks (phase 2: config-dependent)
    if not skip_preflight:
        runner2 = PreflightRunner()
        base_dir = str(config.staging.base_dir)
        runner2.register(SiteExistsCheck(site_name, base_dir=base_dir))
        runner2.register(PostgresClusterCheck(site_name))
        runner2.register(DiskSpaceCheck(path=base_dir))
        if config.backups:
            cipher_pass = getattr(config.backups, "cipher_pass_file", None)
            if cipher_pass:
                runner2.register(CipherPassFileCheck(cipher_pass))
            pgbackrest_conf_dir = str(config.get_pgbackrest_config_dir())
            runner2.register(PgBackRestStanzaCheck(site_name, pgbackrest_conf_dir))
        late_results = runner2.run()
        all_results = early_results + late_results
        print(PreflightRunner.format_results(all_results))
        if not PreflightRunner.is_go(late_results):
            OutputFormatter.error("Pre-flight checks failed. Aborting.")
            return 1

    # Check that site uses managed PostgreSQL (has allocated port)
    port = get_site_port(site_name, config)
    if port is None:
        OutputFormatter.error(
            f"Site '{site_name}' does not have a PostgreSQL cluster configured. "
            "Only sites with managed PostgreSQL support pgBackRest backups."
        )
        return 1

    # Check that backups are configured
    try:
        _check_backup_configured(config, site_name)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # List backups
    if list_backups:
        OutputFormatter.header(f"Backups for {site_name}")
        print()
        try:
            result = _run_pgbackrest(site_name, ["info"], config)
            print(result.stdout)
        except SetupError as exc:
            OutputFormatter.error(str(exc))
            return 1
        return 0

    # Verify Storage Box is reachable before backup
    try:
        OutputFormatter.info("Checking Storage Box connectivity...")
        _check_storage_box_reachable(config)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # Verify a full backup exists before running diff/incr
    if backup_type in ("diff", "incr"):
        try:
            info_result = _run_pgbackrest(site_name, ["info", "--output=json"], config)
            info_data = json.loads(info_result.stdout)
            has_full = any(
                backup_info.get("type") == "full"
                for stanza in info_data
                for backup_info in stanza.get("backup", [])
            )
            if not has_full:
                OutputFormatter.error(
                    f"No full backup exists for '{site_name}'. "
                    f"Run a full backup first: sum-platform backup {site_name} --type full"
                )
                return 1
        except (SetupError, json.JSONDecodeError, KeyError):
            # If we can't check, warn but proceed (pgbackrest will fail with clear error)
            OutputFormatter.warning(
                "Could not verify full backup exists, proceeding anyway"
            )

    # Create backup
    OutputFormatter.header(f"Creating {backup_type} backup for {site_name}")
    print()

    try:
        OutputFormatter.info(f"Running pgbackrest backup --type={backup_type}...")
        result = _run_pgbackrest(site_name, ["backup", f"--type={backup_type}"], config)
        OutputFormatter.success("Backup completed successfully")
        if result.stdout:
            print()
            print(result.stdout)

        # Update backup status marker for health check
        site_dir = config.get_site_dir(site_name)
        _update_backup_status(site_dir)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    return 0


def _backup_command(
    site_name: str,
    backup_type: str,
    list_backups: bool,
    skip_preflight: bool = False,
) -> None:
    """Create or list backups for a site."""
    result = run_backup(
        site_name,
        backup_type=backup_type,
        list_backups=list_backups,
        skip_preflight=skip_preflight,
    )
    if result != 0:
        raise SystemExit(result)


def _missing_click(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("click is required to use the backup command")


if click is None:
    backup = _missing_click
else:

    @click.command(name="backup")
    @click.argument("site_name")
    @click.option(
        "--type",
        "backup_type",
        type=click.Choice(["full", "diff", "incr"], case_sensitive=False),
        default="diff",
        show_default=True,
        help="Backup type: full, differential, or incremental.",
    )
    @click.option(
        "--list",
        "list_backups",
        is_flag=True,
        help="List available backups instead of creating one.",
    )
    @click.pass_context
    def _click_backup(
        ctx: click.Context,
        site_name: str,
        backup_type: str,
        list_backups: bool,
    ) -> None:
        """Create or list backups using pgBackRest.

        Creates backups of PostgreSQL databases using pgBackRest.
        Supports full, differential, and incremental backups.

        \b
        Examples:
          sum-platform backup acme                    # Create diff backup
          sum-platform backup acme --type full        # Create full backup
          sum-platform backup acme --type incr        # Create incremental backup
          sum-platform backup acme --list             # List available backups
        """
        _backup_command(
            site_name,
            backup_type=backup_type,
            list_backups=list_backups,
            skip_preflight=(ctx.obj or {}).get("skip_preflight", False),
        )

    backup = _click_backup
