"""CLI command implementations."""

from __future__ import annotations

from sum.commands.backup import backup
from sum.commands.check import check
from sum.commands.destroy import destroy
from sum.commands.init import init
from sum.commands.monitor import monitor
from sum.commands.promote import promote
from sum.commands.restore import restore
from sum.commands.setup import setup
from sum.commands.test_email import test_email
from sum.commands.theme import theme
from sum.commands.themes import themes
from sum.commands.update import update

__all__ = [
    "backup",
    "check",
    "destroy",
    "init",
    "monitor",
    "promote",
    "restore",
    "setup",
    "test_email",
    "theme",
    "themes",
    "update",
]
