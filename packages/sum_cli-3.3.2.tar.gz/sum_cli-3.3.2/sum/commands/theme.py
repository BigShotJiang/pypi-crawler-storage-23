# pyright: reportUnusedCallResult=false

"""Theme command group for managing themes in projects.

Provides subcommands for listing, checking, and updating themes.
"""

from __future__ import annotations

import sys
from pathlib import Path

from sum.exceptions import ThemeDowngradeError, ThemeNotFoundError, ThemeUpdateError
from sum.setup.remote_themes import (
    compare_versions,
    get_latest_theme_tag,
    list_remote_themes_with_versions,
    list_theme_versions,
)
from sum.setup.scaffold import install_theme, read_theme_lockfile
from sum.themes_registry import list_themes
from sum.utils.environment import resolve_project_path


def _resolve_theme_project_root() -> Path:
    """Resolve the Django project root for theme operations."""
    return resolve_project_path(project=None)


def run_theme_list(*, remote: bool = False) -> int:
    """List available themes.

    Args:
        remote: If True, list themes from remote repository.

    Returns:
        0 on success, 1 on failure.
    """
    try:
        if remote:
            themes_with_versions = list_remote_themes_with_versions()
            if not themes_with_versions:
                print("No themes available in remote repository.")
                print("Check your network connection or SUM_THEMES_REPO setting.")
                return 0

            print("Remote themes (sum-themes repository):")
            print()
            for slug, latest in themes_with_versions.items():
                version_str = f" (latest: {latest})" if latest else ""
                print(f"  {slug}{version_str}")
            print()
            print("Use `sum-platform theme versions <slug>` to see all versions.")
        else:
            themes = list_themes()
            if not themes:
                print("No local themes available.")
                print("Use `sum-platform theme list --remote` to see remote themes.")
                return 0

            print("Local themes:")
            print()
            for theme in themes:
                print(f"  {theme.slug}")
                print(f"    Name: {theme.name}")
                print(f"    Description: {theme.description}")
                print(f"    Version: {theme.version}")
                print()

        return 0
    except Exception as e:
        print(f"[FAIL] Failed to list themes: {e}", file=sys.stderr)
        return 1


def run_theme_versions(slug: str) -> int:
    """List all available versions for a theme.

    Args:
        slug: Theme slug to list versions for.

    Returns:
        0 on success, 1 on failure.
    """
    try:
        versions = list_theme_versions(slug)
        if not versions:
            print(f"No versions found for theme '{slug}'.")
            print("Check the theme slug or your network connection.")
            return 1

        print(f"{slug} versions (latest first):")
        print()
        for i, version in enumerate(versions):
            suffix = " (latest)" if i == 0 else ""
            print(f"  {version}{suffix}")

        # Check if we're in a project with this theme
        try:
            project_root = _resolve_theme_project_root()
        except FileNotFoundError:
            project_root = None

        if project_root is not None:
            lockfile = read_theme_lockfile(project_root)
            if lockfile and lockfile.theme == slug:
                current = lockfile.current_version or lockfile.original_version
                print()
                print(f"You have: {current}")
                if current != versions[0]:
                    print(f"Update available: {versions[0]}")

        return 0
    except ThemeNotFoundError as e:
        print(f"[FAIL] {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"[FAIL] Failed to list versions: {e}", file=sys.stderr)
        return 1


def run_theme_check() -> int:
    """Check current theme version against latest available.

    Returns:
        0 on success, 1 on failure.
    """
    try:
        try:
            project_root = _resolve_theme_project_root()
        except FileNotFoundError:
            print(
                "[FAIL] Not in a project directory. Run from an app directory or site root."
            )
            return 1
        lockfile = read_theme_lockfile(project_root)

        if not lockfile:
            print("[FAIL] No theme lockfile found (.sum/theme.json).")
            print("This doesn't appear to be a CLI-scaffolded project.")
            return 1

        slug = lockfile.theme
        current = lockfile.current_version or lockfile.original_version

        if not slug:
            print("[FAIL] Theme lockfile is malformed (missing theme slug).")
            return 1

        if not current:
            print("[FAIL] Theme lockfile is malformed (missing version).")
            return 1

        latest = get_latest_theme_tag(slug)
        if latest is None:
            print(f"Theme: {slug}")
            print(f"Current version: {current}")
            print("Status: Unable to check for updates (network error or no tags)")
            return 0

        print(f"Theme: {slug}")
        print(f"Current version: {current}")
        print(f"Latest version: {latest}")

        cmp = compare_versions(current, latest)
        if cmp == 0:
            print("Status: Up to date")
        elif cmp < 0:
            print("Status: Update available")
            print()
            print(f"Run `sum-platform theme update` to upgrade to {latest}.")
        else:
            print("Status: Ahead of latest (custom or pre-release version)")

        return 0
    except Exception as e:
        print(f"[FAIL] Failed to check theme: {e}", file=sys.stderr)
        return 1


def run_theme_update(
    *,
    version: str | None = None,
    allow_downgrade: bool = False,
    force: bool = False,
) -> int:
    """Update theme to latest or specified version.

    Args:
        version: Specific version to install, or None for latest.
        allow_downgrade: If True, allow downgrading to older version.
        force: If True, reinstall even if at target version.

    Returns:
        0 on success, 1 on failure.
    """
    try:
        try:
            project_root = _resolve_theme_project_root()
        except FileNotFoundError:
            print(
                "[FAIL] Not in a project directory. Run from an app directory or site root."
            )
            return 1
        lockfile = read_theme_lockfile(project_root)

        if not lockfile:
            print("[FAIL] No theme lockfile found (.sum/theme.json).")
            print("This doesn't appear to be a CLI-scaffolded project.")
            return 1

        slug = lockfile.theme
        current = lockfile.current_version or lockfile.original_version

        if not slug:
            print("[FAIL] Theme lockfile is malformed (missing theme slug).")
            return 1

        print(f"Theme: {slug}")
        print(f"Current version: {current or 'unknown'}")

        target_version = version
        if target_version is None:
            target_version = get_latest_theme_tag(slug)
            if target_version is None:
                print("[FAIL] Unable to determine latest version.")
                print("Check your network connection or try specifying --version.")
                return 1
            print(f"Target version: {target_version} (latest)")
        else:
            print(f"Target version: {target_version}")

        print()

        # Perform the update
        installed_version = install_theme(
            project_root,
            slug,
            target_version,
            allow_downgrade=allow_downgrade,
            force=force,
        )

        print(f"[OK] Theme updated to {installed_version}")
        print()
        print("Next steps:")
        print("  1. Review changes in theme/active/")
        print("  2. Run `python manage.py collectstatic --noinput`")
        print("  3. Test your site to verify the update")

        return 0

    except ThemeDowngradeError as e:
        print(f"[FAIL] {e}", file=sys.stderr)
        return 1
    except ThemeUpdateError as e:
        print(f"[FAIL] {e}", file=sys.stderr)
        return 1
    except ThemeNotFoundError as e:
        print(f"[FAIL] {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"[FAIL] Theme update failed: {e}", file=sys.stderr)
        return 1


# Click command wrappers
_missing_click: bool = False
try:
    import click

    @click.group(name="theme")
    def theme() -> None:
        """Manage themes in SUM Platform projects.

        Use these commands to list available themes, check for updates,
        and update themes in existing projects.
        """

    @theme.command(name="list")
    @click.option(
        "--remote",
        is_flag=True,
        help="List themes from remote sum-themes repository.",
    )
    def theme_list(remote: bool) -> None:
        """List available themes.

        By default, lists local themes. Use --remote to list themes
        available in the sum-themes repository.

        \b
        Examples:
          sum-platform theme list
          sum-platform theme list --remote
        """
        result = run_theme_list(remote=remote)
        if result != 0:
            raise SystemExit(result)

    @theme.command(name="versions")
    @click.argument("slug")
    def theme_versions(slug: str) -> None:
        """List all available versions for a theme.

        Shows versions available in the sum-themes repository,
        sorted from newest to oldest.

        \b
        Examples:
          sum-platform theme versions theme_a
          sum-platform theme versions theme_b
        """
        result = run_theme_versions(slug)
        if result != 0:
            raise SystemExit(result)

    @theme.command(name="check")
    def theme_check() -> None:
        """Check current theme version against latest available.

        Reads the theme lockfile from the current directory and
        compares against the latest version in sum-themes repository.

        \b
        Examples:
          cd /path/to/project
          sum-platform theme check
        """
        result = run_theme_check()
        if result != 0:
            raise SystemExit(result)

    @theme.command(name="update")
    @click.option(
        "--version",
        "version",
        default=None,
        help="Specific version to install (default: latest).",
    )
    @click.option(
        "--allow-downgrade",
        is_flag=True,
        help="Allow downgrading to an older version.",
    )
    @click.option(
        "--force",
        is_flag=True,
        help="Reinstall even if already at target version.",
    )
    def theme_update(
        version: str | None,
        allow_downgrade: bool,
        force: bool,
    ) -> None:
        """Update theme to latest or specified version.

        Updates the theme in theme/active/ to a new version.
        Creates a backup before updating and rolls back on failure.

        Client customizations in templates/overrides/ are preserved.

        \b
        Examples:
          sum-platform theme update
          sum-platform theme update --version 1.2.0
          sum-platform theme update --allow-downgrade --version 1.0.0
        """
        result = run_theme_update(
            version=version,
            allow_downgrade=allow_downgrade,
            force=force,
        )
        if result != 0:
            raise SystemExit(result)

except ImportError:
    _missing_click = True

    def theme() -> None:  # type: ignore[misc]
        """Fallback when click is not installed."""
        raise RuntimeError("Click is required for CLI commands")
