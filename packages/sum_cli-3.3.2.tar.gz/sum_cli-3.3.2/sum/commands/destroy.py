# pyright: reportImplicitStringConcatenation=false, reportUnusedCallResult=false

"""Destroy command implementation.

Tears down a site created by ``sum-platform init``, reversing every
provisioning step in safe order:

1. Stop and disable the systemd service
2. Remove the systemd service file and reload daemon
3. Stop and drop the PostgreSQL cluster (with ``--purge-backups``,
   also deletes remote backup data via pgBackRest stanza-delete)
4. Remove pgBackRest stanza config and backup cron
5. Remove the Caddy site config and reload
6. Remove the site directory tree
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from types import ModuleType

from sum.exceptions import SetupError
from sum.setup.backup_cron import remove_backup_cron
from sum.setup.bare_metal_postgres import cleanup_bare_metal_postgres
from sum.setup.ports import get_site_port
from sum.site_config import SiteConfig, SiteConfigError
from sum.system_config import (
    ConfigurationError,
    InfrastructureConfig,
    get_system_config,
)
from sum.utils.output import OutputFormatter
from sum.utils.preflight import (
    CheckSeverity,
    PreflightRunner,
    SiteExistsCheck,
    SystemConfigCheck,
)
from sum.utils.privilege import require_root_or_escalate
from sum.utils.validation import validate_site_slug

click_module: ModuleType | None
try:
    import click as click_module
except ImportError:  # pragma: no cover - click is expected in the CLI runtime
    click_module = None

click: ModuleType | None = click_module


class DestroyError(SetupError):
    """Raised when site destruction encounters a fatal error."""


def run_destroy(
    site_slug: str,
    *,
    force: bool = False,
    purge_backups: bool = False,
    skip_preflight: bool = False,
) -> int:
    """Destroy a site created by ``sum-platform init``.

    Tears down all infrastructure in reverse order of creation.
    Requires root privileges.

    Args:
        site_slug: Slug of the site to destroy.
        force: Skip confirmation prompts.
        purge_backups: Also purge remote backup data (requires extra
            confirmation unless *force* is set).

    Returns:
        Exit code (0 for success, non-zero for failure).
    """
    # Require root
    require_root_or_escalate("destroy")

    # Validate slug before any filesystem or DB operations
    try:
        validate_site_slug(site_slug)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # Pre-flight checks (phase 1: config-independent)
    early_results: list = []
    if not skip_preflight:
        runner = PreflightRunner()
        runner.register(SystemConfigCheck())
        early_results = runner.run()
        if not PreflightRunner.is_go(early_results):
            print(PreflightRunner.format_results(early_results))
            OutputFormatter.error("Pre-flight checks failed. Aborting.")
            return 1

    # Load system config
    try:
        config = get_system_config()
    except ConfigurationError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # Pre-flight checks (phase 2: RECOMMENDED site check — warn but don't block)
    if not skip_preflight:
        runner2 = PreflightRunner()
        site_check = SiteExistsCheck(site_slug, base_dir=str(config.staging.base_dir))
        site_check.severity = CheckSeverity.RECOMMENDED
        runner2.register(site_check)
        late_results = runner2.run()
        all_results = early_results + late_results
        print(PreflightRunner.format_results(all_results))
        if not PreflightRunner.is_go(late_results):
            OutputFormatter.error("Pre-flight checks failed. Aborting.")
            return 1

    # Validate the site exists
    site_dir = config.get_site_dir(site_slug)
    if not site_dir.exists():
        OutputFormatter.error(
            f"Site directory does not exist: {site_dir}\n"
            f"Nothing to destroy for '{site_slug}'."
        )
        return 1

    # Load site config for informational display (best-effort)
    site_config: SiteConfig | None = None
    try:
        site_config = SiteConfig.load(site_dir)
    except SiteConfigError:
        pass  # Older sites may not have .sum/config.yml

    # Confirmation prompt
    if not force:
        print()
        OutputFormatter.warning(f"This will permanently destroy site '{site_slug}':")
        print(f"  Site directory:  {site_dir}")
        if site_config:
            print(f"  Theme:           {site_config.theme}")
        print("  PostgreSQL cluster will be dropped")
        print("  Systemd service will be removed")
        print("  Caddy config will be removed")
        if purge_backups:
            print("  Remote backup data will be PERMANENTLY DELETED")
        print()

        try:
            answer = input(f"Type the site slug '{site_slug}' to confirm destruction: ")
        except (EOFError, KeyboardInterrupt):
            print("\nAborted.")
            return 130

        if answer.strip() != site_slug:
            OutputFormatter.error("Confirmation did not match. Aborting.")
            return 1

    if purge_backups and not force:
        print()
        OutputFormatter.warning(
            "Remote backup data deletion is IRREVERSIBLE. "
            "All backup history for this site will be lost."
        )
        try:
            answer = input("Type 'DELETE BACKUPS' to confirm: ")
        except (EOFError, KeyboardInterrupt):
            print("\nAborted.")
            return 130

        if answer.strip() != "DELETE BACKUPS":
            OutputFormatter.error("Backup purge confirmation did not match. Aborting.")
            return 1

    # --- Execute teardown ---
    OutputFormatter.header(f"Destroying site: {site_slug}")
    print()

    errors: list[str] = []
    step = 0
    total_steps = _count_destroy_steps()

    # Step 1: Stop systemd service
    step += 1
    service_name = config.get_systemd_service_name(site_slug)
    _progress(step, total_steps, "Stopping systemd service")
    try:
        subprocess.run(
            ["systemctl", "stop", service_name],
            capture_output=True,
            text=True,
        )
        _done(step, total_steps, "Systemd service stopped")
    except (subprocess.SubprocessError, OSError) as exc:
        _warn(step, total_steps, f"Could not stop service (may not exist): {exc}")

    # Step 2: Disable and remove systemd service
    step += 1
    _progress(step, total_steps, "Removing systemd service")
    try:
        subprocess.run(
            ["systemctl", "disable", service_name],
            capture_output=True,
            text=True,
        )
        service_path = Path(f"/etc/systemd/system/{service_name}.service")
        if service_path.exists():
            service_path.unlink()
        subprocess.run(
            ["systemctl", "daemon-reload"],
            capture_output=True,
            text=True,
        )
        _done(step, total_steps, "Systemd service removed")
    except (subprocess.SubprocessError, OSError) as exc:
        msg = f"Could not fully remove systemd service: {exc}"
        _warn(step, total_steps, msg)
        errors.append(msg)

    # Step 3: Stop and drop PostgreSQL cluster + deallocate port
    step += 1
    _progress(step, total_steps, "Removing PostgreSQL cluster")
    has_managed_cluster = get_site_port(site_slug, config) is not None
    if has_managed_cluster:
        postgres_version = InfrastructureConfig.postgres_version
        if config.infrastructure:
            postgres_version = config.infrastructure.postgres_version
        # Only purge remote backup data when --purge-backups is set;
        # otherwise keep remote backups for potential disaster recovery.
        # strict_purge ensures stanza-delete failures propagate when the
        # operator explicitly requested --purge-backups.
        try:
            cleanup_bare_metal_postgres(
                site_slug,
                postgres_version,
                config,
                purge_remote_backups=purge_backups,
                strict_purge=purge_backups,
            )
            _done(step, total_steps, "PostgreSQL cluster removed")
        except (SetupError, subprocess.SubprocessError, OSError) as exc:
            msg = f"Could not fully clean up PostgreSQL: {exc}"
            _warn(step, total_steps, msg)
            errors.append(msg)
    else:
        # Fallback: try to drop DB on system postgres using parameterized psql
        db_name = config.get_db_name(site_slug)
        db_user = config.get_db_user(site_slug)
        postgres_port = str(config.defaults.postgres_port)
        psql_base = ["sudo", "-u", "postgres", "psql", "-p", postgres_port]
        try:
            subprocess.run(
                psql_base + ["-v", f"db_name={db_name}"],
                input='DROP DATABASE IF EXISTS :"db_name";',
                text=True,
                capture_output=True,
            )
            subprocess.run(
                psql_base + ["-v", f"db_user={db_user}"],
                input='DROP USER IF EXISTS :"db_user";',
                text=True,
                capture_output=True,
            )
            _done(step, total_steps, "Database and user dropped")
        except subprocess.SubprocessError as exc:
            msg = f"Could not drop database/user: {exc}"
            _warn(step, total_steps, msg)
            errors.append(msg)

    # Step 4: Remove backup cron
    step += 1
    _progress(step, total_steps, "Removing backup schedule")
    try:
        remove_backup_cron(site_slug)
        _done(step, total_steps, "Backup schedule removed")
    except (SetupError, subprocess.SubprocessError, OSError) as exc:
        msg = f"Could not remove backup cron: {exc}"
        _warn(step, total_steps, msg)
        errors.append(msg)

    # Step 5: Remove Caddy config
    step += 1
    _progress(step, total_steps, "Removing Caddy configuration")
    caddy_config_name = config.get_caddy_config_name(site_slug)
    caddy_path = Path(f"/etc/caddy/sites-enabled/{caddy_config_name}")
    try:
        if caddy_path.exists():
            caddy_path.unlink()
        subprocess.run(
            ["systemctl", "reload", "caddy"],
            capture_output=True,
            text=True,
        )
        _done(step, total_steps, "Caddy configuration removed")
    except (subprocess.SubprocessError, OSError) as exc:
        msg = f"Could not remove Caddy config: {exc}"
        _warn(step, total_steps, msg)
        errors.append(msg)

    # Step 6: Remove site directory
    step += 1
    _progress(step, total_steps, "Removing site directory")
    try:
        resolved = site_dir.resolve()
        # Safety: refuse to remove paths that don't look like a site directory
        if site_slug not in resolved.parts or len(resolved.parts) < 3:
            msg = f"Refusing to remove unsafe path: {resolved}"
            _warn(step, total_steps, msg)
            errors.append(msg)
        else:
            shutil.rmtree(resolved)
            _done(step, total_steps, "Site directory removed")
    except (SetupError, subprocess.SubprocessError, OSError) as exc:
        msg = f"Could not remove site directory: {exc}"
        _warn(step, total_steps, msg)
        errors.append(msg)

    # Summary
    print()
    if errors:
        OutputFormatter.warning(
            f"Site '{site_slug}' destroyed with {len(errors)} warning(s):"
        )
        for err in errors:
            print(f"  - {err}")
        return 0  # Warnings are non-fatal; the site is destroyed
    else:
        OutputFormatter.success(f"Site '{site_slug}' destroyed successfully.")
        return 0


def _count_destroy_steps() -> int:
    """Count total teardown steps for progress display."""
    # Steps: stop service, remove service, remove postgres,
    # remove backup cron, remove caddy, remove directory
    return 6


def _progress(step: int, total: int, message: str) -> None:
    OutputFormatter.progress(step, total, message, "\u23f3")


def _done(step: int, total: int, message: str) -> None:
    OutputFormatter.progress(step, total, message, "\u2705")


def _warn(step: int, total: int, message: str) -> None:
    OutputFormatter.progress(step, total, message, "\u26a0\ufe0f")


def _missing_click(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("click is required to use the destroy command")


if click is None:
    destroy = _missing_click
else:

    @click.command(name="destroy")
    @click.argument("site_slug")
    @click.option(
        "--force",
        is_flag=True,
        help="Skip all confirmation prompts (use with caution).",
    )
    @click.option(
        "--purge-backups",
        is_flag=True,
        help="Also delete remote backup data. IRREVERSIBLE.",
    )
    @click.pass_context
    def _click_destroy(
        ctx: click.Context,
        site_slug: str,
        force: bool,
        purge_backups: bool,
    ) -> None:
        """Destroy a site and all its infrastructure.

        Reverses everything created by ``sum-platform init``:

        \b
        - Stops and removes systemd service
        - Drops PostgreSQL cluster and deallocates port
        - Removes pgBackRest stanza config and backup cron
        - Removes Caddy reverse proxy config
        - Removes site directory (/srv/sum/<SITE_SLUG>/)

        \b
        Requires confirmation: you must type the site slug to proceed.
        Use --force to skip confirmation (e.g., in scripts).

        \b
        Examples:
          sudo sum-platform destroy acme
          sudo sum-platform destroy acme --force
          sudo sum-platform destroy acme --purge-backups
        """
        result = run_destroy(
            site_slug,
            force=force,
            purge_backups=purge_backups,
            skip_preflight=(ctx.obj or {}).get("skip_preflight", False),
        )
        if result != 0:
            raise SystemExit(result)

    destroy = _click_destroy
