# pyright: reportImplicitStringConcatenation=false, reportUnusedCallResult=false

"""Init command implementation.

Creates a working site on staging at /srv/sum/<name>/ with:
- Postgres database
- External venv
- Systemd service
- Caddy configuration
- Git repository (optional, specify provider with --git-provider)
"""

from __future__ import annotations

from types import ModuleType

from sum.exceptions import SetupError
from sum.setup.infrastructure import check_infrastructure
from sum.setup.site_orchestrator import SiteOrchestrator, SiteSetupConfig
from sum.site_config import GitConfig
from sum.system_config import ConfigurationError, get_system_config
from sum.utils.output import OutputFormatter
from sum.utils.preflight import (
    DiskSpaceCheck,
    GiteaTokenCheck,
    PreflightRunner,
    SystemConfigCheck,
    TemplateFilesCheck,
)
from sum.utils.privilege import detect_gitea_token, require_root_or_escalate
from sum.utils.validation import validate_site_slug

click_module: ModuleType | None
try:
    import click as click_module
except ImportError:  # pragma: no cover - click is expected in the CLI runtime
    click_module = None

click: ModuleType | None = click_module


def run_init(
    site_name: str,
    *,
    theme: str = "theme_a",
    profile: str = "starter",
    content_path: str | None = None,
    no_git: bool = False,
    git_provider: str | None = None,
    git_org: str | None = None,
    gitea_url: str | None = None,
    gitea_ssh_port: int = 22,
    gitea_token_env: str = "GITEA_TOKEN",
    skip_systemd: bool = False,
    skip_caddy: bool = False,
    superuser_username: str = "admin",
    dev: bool = False,
    core_ref: str | None = None,
    skip_preflight: bool = False,
) -> int:
    """Initialize a new site on staging.

    Creates a fully working site at /srv/sum/<name>/ with all infrastructure
    configured and ready to serve traffic.

    Args:
        site_name: Name/slug for the site.
        theme: Theme slug to use.
        profile: Content profile name to seed.
        content_path: Optional path to custom content directory.
        no_git: Skip git repository creation.
        git_provider: Git provider ("github" or "gitea").
        git_org: Git organization/namespace.
        gitea_url: Gitea instance URL (required if git_provider=gitea).
        gitea_ssh_port: SSH port for Gitea.
        gitea_token_env: Env var name for Gitea API token.
        skip_systemd: Skip systemd service installation.
        skip_caddy: Skip Caddy configuration.
        superuser_username: Username for Django superuser.
        dev: Use editable sum-core from monorepo.
        core_ref: Git ref (branch/tag) for sum-core install.

    Returns:
        Exit code (0 for success, non-zero for failure).
    """
    # Validate flag combinations
    if dev and core_ref:
        OutputFormatter.error("--dev and --core-ref are mutually exclusive.")
        return 1

    # Validate site name
    try:
        validate_site_slug(site_name)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    site_slug = site_name

    # Detect GITEA_TOKEN before privilege escalation so it can be preserved
    if git_provider == "gitea" and not no_git:
        token = detect_gitea_token(env_var=gitea_token_env)
        if not token:
            OutputFormatter.warning(
                f"{gitea_token_env} not found in environment or ~/.config/tea/config.yml.\n"
                "  Gitea repo creation will be skipped.\n"
                f"  Set {gitea_token_env} or use --no-git to skip."
            )

    # Check for root privileges, auto-escalating if needed.
    # This handles pipx/pip user-space installs transparently; if escalation
    # fails, require_root_or_escalate will terminate the process.
    require_root_or_escalate("init", token_env=gitea_token_env)

    # Pre-flight checks (phase 1: config-independent)
    early_results: list = []
    if not skip_preflight:
        runner = PreflightRunner()
        runner.register(SystemConfigCheck())
        if git_provider == "gitea" and not no_git:
            runner.register(GiteaTokenCheck(env_var=gitea_token_env or "GITEA_TOKEN"))
        early_results = runner.run()
        if not PreflightRunner.is_go(early_results):
            print(PreflightRunner.format_results(early_results))
            OutputFormatter.error("Pre-flight checks failed. Aborting.")
            return 1

    # Check infrastructure prerequisites
    infra = check_infrastructure()

    if infra.errors:
        OutputFormatter.error("Infrastructure prerequisites not met:")
        for error in infra.errors:
            OutputFormatter.error(f"  - {error}")
        return 1

    # Load system config
    try:
        config = get_system_config()
    except ConfigurationError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # Pre-flight checks (phase 2: config-dependent — disk space + template files)
    if not skip_preflight:
        runner2 = PreflightRunner()
        runner2.register(DiskSpaceCheck(path=str(config.staging.base_dir)))
        systemd_path = None if skip_systemd else config.templates.systemd_path
        caddy_path = None if skip_caddy else config.templates.caddy_path
        if systemd_path or caddy_path:
            runner2.register(TemplateFilesCheck(systemd_path, caddy_path))
        late_results = runner2.run()
        all_results = early_results + late_results
        print(PreflightRunner.format_results(all_results))
        if not PreflightRunner.is_go(late_results):
            OutputFormatter.error("Pre-flight checks failed. Aborting.")
            return 1
    # Check if site already exists
    site_dir = config.get_site_dir(site_slug)
    if site_dir.exists():
        OutputFormatter.error(f"Site already exists at {site_dir}")
        return 1

    # Build git config from flags
    git_config: GitConfig | None = None
    if not no_git:
        # Validate required git flags
        if not git_provider:
            OutputFormatter.error(
                "Git provider required. Use --git-provider github or --git-provider gitea.\n"
                "Or use --no-git to skip git setup."
            )
            return 1
        if not git_org:
            OutputFormatter.error(
                "Git organization required. Use --git-org <org>.\n"
                "Or use --no-git to skip git setup."
            )
            return 1
        if git_provider == "gitea" and not gitea_url:
            OutputFormatter.error("Gitea URL required. Use --gitea-url <url>.")
            return 1

        git_config = GitConfig(
            provider=git_provider,
            org=git_org,
            url=gitea_url,
            ssh_port=gitea_ssh_port,
            token_env=gitea_token_env,
        )

    # Build setup config
    setup_config = SiteSetupConfig(
        site_slug=site_slug,
        theme_slug=theme,
        seed_profile=profile,
        content_path=content_path,
        superuser_username=superuser_username,
        skip_systemd=skip_systemd,
        skip_caddy=skip_caddy,
        git_config=git_config,
        dev=dev,
        core_ref=core_ref,
    )

    # Run setup
    OutputFormatter.header(f"Creating site: {site_slug}")
    print()

    orchestrator = SiteOrchestrator(config)
    try:
        result = orchestrator.setup_site(setup_config)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # Output summary
    print()
    OutputFormatter.success("Site created successfully!")
    print()
    print(f"  URL:          https://{result.domain}")
    print(f"  Admin:        {result.admin_url}")
    print(f"  Username:     {result.superuser_username}")
    # Intentional: Display generated password to user (also saved to credentials file)
    print(f"  Password:     {result.superuser_password}")  # nosec B105
    print()
    print(f"  Site dir:     {result.site_dir}")
    print(f"  App dir:      {result.app_dir}")
    if result.repo_url:
        print(f"  Repository:   {result.repo_url}")
    print()
    print(f"  Credentials saved to: {result.credentials_path}")
    print()

    return 0


def _init_command(
    site_name: str,
    theme: str,
    profile: str,
    content_path: str | None,
    no_git: bool,
    git_provider: str | None,
    git_org: str | None,
    gitea_url: str | None,
    gitea_ssh_port: int,
    gitea_token_env: str,
    skip_systemd: bool,
    skip_caddy: bool,
    superuser_username: str,
    dev: bool,
    core_ref: str | None,
    skip_preflight: bool = False,
) -> None:
    """Initialize a new site on staging."""
    result = run_init(
        site_name,
        theme=theme,
        profile=profile,
        content_path=content_path,
        no_git=no_git,
        git_provider=git_provider,
        git_org=git_org,
        gitea_url=gitea_url,
        gitea_ssh_port=gitea_ssh_port,
        gitea_token_env=gitea_token_env,
        skip_systemd=skip_systemd,
        skip_caddy=skip_caddy,
        superuser_username=superuser_username,
        dev=dev,
        core_ref=core_ref,
        skip_preflight=skip_preflight,
    )
    if result != 0:
        raise SystemExit(result)


def _missing_click(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("click is required to use the init command")


if click is None:
    init = _missing_click
else:

    @click.command(name="init")
    @click.argument("site_name")
    @click.option(
        "--theme",
        default="theme_a",
        show_default=True,
        help="Theme slug to use for the site.",
    )
    @click.option(
        "--profile",
        default="starter",
        show_default=True,
        help="Content profile to seed.",
    )
    @click.option(
        "--content-path",
        default=None,
        help="Path to custom content directory for seeding.",
    )
    @click.option(
        "--no-git",
        is_flag=True,
        help="Skip git repository creation (local git init only).",
    )
    @click.option(
        "--git-provider",
        type=click.Choice(["github", "gitea"]),
        default=None,
        help="Git provider: github or gitea. Required unless --no-git.",
    )
    @click.option(
        "--git-org",
        default=None,
        help="Git organization/namespace. Required unless --no-git.",
    )
    @click.option(
        "--gitea-url",
        default=None,
        help="Gitea instance URL. Required if --git-provider=gitea.",
    )
    @click.option(
        "--gitea-ssh-port",
        type=int,
        default=22,
        show_default=True,
        help="SSH port for Gitea.",
    )
    @click.option(
        "--gitea-token-env",
        default="GITEA_TOKEN",
        show_default=True,
        help="Environment variable for Gitea API token.",
    )
    @click.option(
        "--skip-systemd",
        is_flag=True,
        help="Skip systemd service installation.",
    )
    @click.option(
        "--skip-caddy",
        is_flag=True,
        help="Skip Caddy reverse proxy configuration.",
    )
    @click.option(
        "--superuser",
        "superuser_username",
        default="admin",
        show_default=True,
        help="Username for Django superuser.",
    )
    @click.option(
        "--dev",
        is_flag=True,
        help="Use editable sum-core from monorepo (dev testing).",
    )
    @click.option(
        "--core-ref",
        default=None,
        help="Git ref (branch/tag) for sum-core install.",
    )
    @click.pass_context
    def _click_init(
        ctx: click.Context,
        site_name: str,
        theme: str,
        profile: str,
        content_path: str | None,
        no_git: bool,
        git_provider: str | None,
        git_org: str | None,
        gitea_url: str | None,
        gitea_ssh_port: int,
        gitea_token_env: str,
        skip_systemd: bool,
        skip_caddy: bool,
        superuser_username: str,
        dev: bool,
        core_ref: str | None,
    ) -> None:
        """Initialize a new site on staging.

        Creates a working site at /srv/sum/<SITE_NAME>/ with:

        \b
        - PostgreSQL database
        - Django project with selected theme
        - External virtualenv
        - Systemd service
        - Caddy reverse proxy
        - Git repository (optional, specify provider with --git-provider)

        \b
        Examples:
          sudo sum-platform init acme --no-git
          sudo sum-platform init acme --git-provider github --git-org acme-corp
          sudo sum-platform init acme --git-provider gitea --git-org clients \\
              --gitea-url https://git.agency.com

        \b
        Dev/Testing (use unreleased sum-core):
          sudo sum-platform init acme --dev --no-git
          sudo sum-platform init acme --core-ref develop --no-git
        """
        _init_command(
            site_name,
            theme=theme,
            profile=profile,
            content_path=content_path,
            no_git=no_git,
            git_provider=git_provider,
            git_org=git_org,
            gitea_url=gitea_url,
            gitea_ssh_port=gitea_ssh_port,
            gitea_token_env=gitea_token_env,
            skip_systemd=skip_systemd,
            skip_caddy=skip_caddy,
            superuser_username=superuser_username,
            dev=dev,
            core_ref=core_ref,
            skip_preflight=(ctx.obj or {}).get("skip_preflight", False),
        )

    init = _click_init
