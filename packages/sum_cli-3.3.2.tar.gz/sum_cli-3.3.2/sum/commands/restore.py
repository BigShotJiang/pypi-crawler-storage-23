# pyright: reportImplicitStringConcatenation=false, reportUnusedCallResult=false

"""Restore command implementation for point-in-time recovery.

Restores PostgreSQL databases using pgBackRest for point-in-time recovery.
"""

from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path
from types import ModuleType

from sum.commands.backup import _check_backup_configured
from sum.exceptions import SetupError
from sum.setup.bare_metal_postgres import DEFAULT_PGBACKREST_WRAPPER, PGBACKREST_BINARY
from sum.setup.ports import get_site_port
from sum.system_config import ConfigurationError, SystemConfig, get_system_config
from sum.utils.output import OutputFormatter
from sum.utils.preflight import (
    CipherPassFileCheck,
    PgBackRestStanzaCheck,
    PostgresClusterCheck,
    PreflightRunner,
    SiteExistsCheck,
    SystemConfigCheck,
)
from sum.utils.privilege import require_root_or_escalate
from sum.utils.validation import validate_site_slug

click_module: ModuleType | None
try:
    import click as click_module
except ImportError:  # pragma: no cover
    click_module = None

click: ModuleType | None = click_module


def _validate_time_format(time_str: str) -> bool:
    """Validate timestamp format for pgBackRest restore.

    Expected format: YYYY-MM-DD HH:MM:SS
    Validates both format and date/time ranges (e.g., rejects month 13).

    Args:
        time_str: Timestamp string to validate.

    Returns:
        True if valid, False otherwise.
    """
    from datetime import datetime

    try:
        datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S")
        return True
    except ValueError:
        return False


def _check_disk_space(site_slug: str, config: SystemConfig) -> None:
    """Check that there's sufficient disk space for restore.

    Estimates needed space as 2x current PostgreSQL data size (for backup + restore).

    Args:
        site_slug: Site slug.
        config: System configuration.

    Raises:
        SetupError: If insufficient disk space.
    """
    data_dir = _get_data_dir(site_slug, config)
    if not data_dir.exists():
        return  # No existing data, skip check

    # Get current data size
    try:
        # Use du -s for directory size
        result = subprocess.run(
            ["du", "-sb", str(data_dir)],
            capture_output=True,
            text=True,
            check=True,
        )
        data_size = int(result.stdout.split()[0])
    except (subprocess.CalledProcessError, ValueError, IndexError):
        # Can't determine size, skip check
        return

    # Get available space on filesystem
    stat = shutil.disk_usage(data_dir.parent)
    available = stat.free

    # Need 2x data size: one for pre-restore backup, one for restored data
    needed = data_size * 2

    if available < needed:
        available_gb = available / (1024**3)
        needed_gb = needed / (1024**3)
        raise SetupError(
            f"Insufficient disk space for restore.\n"
            f"Available: {available_gb:.1f} GB\n"
            f"Needed: {needed_gb:.1f} GB (2x current data size)\n"
            f"Free up space on {data_dir.parent}."
        )


def _get_postgres_version(config: SystemConfig) -> str:
    """Get PostgreSQL version from configuration.

    Args:
        config: System configuration.

    Returns:
        PostgreSQL version string (e.g., "18").
    """
    version = "18"  # Default
    if config.infrastructure:
        version = config.infrastructure.postgres_version
    return version


def _stop_cluster(site_slug: str, config: SystemConfig) -> None:
    """Stop the PostgreSQL cluster.

    Uses --skip-systemctl-redirect because systemd's %I expansion breaks
    for cluster names containing dashes.

    Args:
        site_slug: Site slug.
        config: System configuration (for postgres version).

    Raises:
        SetupError: If cluster fails to stop.
    """
    version = _get_postgres_version(config)
    OutputFormatter.info("Stopping PostgreSQL cluster...")
    try:
        subprocess.run(
            [
                "pg_ctlcluster",
                "--skip-systemctl-redirect",
                version,
                site_slug,
                "stop",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to stop cluster: {exc.stderr or exc.stdout}") from exc


def _start_cluster(site_slug: str, config: SystemConfig) -> None:
    """Start the PostgreSQL cluster.

    Uses --skip-systemctl-redirect because systemd's %I expansion breaks
    for cluster names containing dashes.

    Args:
        site_slug: Site slug.
        config: System configuration (for postgres version).

    Raises:
        SetupError: If cluster fails to start.
    """
    version = _get_postgres_version(config)
    OutputFormatter.info("Starting PostgreSQL cluster...")
    try:
        subprocess.run(
            [
                "pg_ctlcluster",
                "--skip-systemctl-redirect",
                version,
                site_slug,
                "start",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to start cluster: {exc.stderr or exc.stdout}"
        ) from exc


def _run_pgbackrest_restore(
    site_slug: str,
    config: SystemConfig,
    target_time: str | None = None,
) -> None:
    """Run pgbackrest restore as postgres user.

    Args:
        site_slug: Site slug (used as stanza name).
        config: System configuration for paths.
        target_time: Target time for point-in-time recovery (ISO format).

    Raises:
        SetupError: If restore command fails.
    """
    config_include_path = str(config.get_pgbackrest_config_dir())
    cmd = [
        "sudo",
        "-u",
        "postgres",
        DEFAULT_PGBACKREST_WRAPPER,
        f"--config-include-path={config_include_path}",
        f"--stanza={site_slug}",
        "restore",
    ]

    if target_time:
        cmd.extend([f"--target={target_time}", "--type=time"])

    try:
        subprocess.run(
            cmd,
            check=True,
            capture_output=True,
        )
    except subprocess.CalledProcessError as exc:
        # pgbackrest writes errors to stdout with log prefixes, not stderr.
        # Output may contain binary data, so decode safely.
        stdout = (
            exc.stdout.decode("utf-8", errors="replace")
            if isinstance(exc.stdout, bytes)
            else (exc.stdout or "")
        )
        stderr = (
            exc.stderr.decode("utf-8", errors="replace")
            if isinstance(exc.stderr, bytes)
            else (exc.stderr or "")
        )
        error_output = stdout or stderr or "No error output"
        raise SetupError(f"pgBackRest restore failed: {error_output}") from exc
    except FileNotFoundError as exc:
        raise SetupError(
            f"pgbackrest wrapper not found at {DEFAULT_PGBACKREST_WRAPPER}. "
            "Is pgBackRest installed and was 'sum-platform init' run?"
        ) from exc


def _patch_restore_command(site_slug: str, config: SystemConfig) -> None:
    """Patch restore_command in postgresql.auto.conf to use the wrapper.

    pgBackRest writes a ``restore_command`` using the raw ``pgbackrest``
    binary.  When cipher encryption is enabled the raw binary fails
    because ``repo1-cipher-pass`` is only injected by the wrapper via
    an environment variable.  This function rewrites the
    ``restore_command`` to use the wrapper path instead.

    Args:
        site_slug: Site slug.
        config: System configuration (for postgres version).

    Raises:
        SetupError: If the auto.conf cannot be read or written.
    """
    data_dir = _get_data_dir(site_slug, config)
    auto_conf = data_dir / "postgresql.auto.conf"

    if not auto_conf.exists():
        return  # Nothing to patch

    try:
        content = auto_conf.read_text()
    except OSError as exc:
        raise SetupError(
            f"Cannot read {auto_conf} to patch restore_command: {exc}"
        ) from exc

    # Match restore_command lines written by pgBackRest.
    # pgBackRest may write the bare name "pgbackrest" or the full binary
    # path (e.g. /usr/bin/pgbackrest).  Replace either with the wrapper.
    #
    # Pattern: restore_command = '...<pgbackrest-path> ...'
    # We replace only the binary path, preserving the rest of the command.
    patched = re.sub(
        r"(restore_command\s*=\s*')" + re.escape(PGBACKREST_BINARY) + r"(\s)",
        rf"\g<1>{DEFAULT_PGBACKREST_WRAPPER}\2",
        content,
    )
    # Also handle bare "pgbackrest" (no absolute path)
    patched = re.sub(
        r"(restore_command\s*=\s*')pgbackrest(\s)",
        rf"\g<1>{DEFAULT_PGBACKREST_WRAPPER}\2",
        patched,
    )

    if patched == content:
        return  # No restore_command found or already using wrapper

    try:
        auto_conf.write_text(patched)
    except OSError as exc:
        raise SetupError(f"Cannot write patched {auto_conf}: {exc}") from exc

    OutputFormatter.info("Patched restore_command to use pgbackrest-wrapper")


def _get_data_dir(site_slug: str, config: SystemConfig) -> Path:
    """Get the PostgreSQL data directory path for a site.

    Args:
        site_slug: Site slug.
        config: System configuration.

    Returns:
        Path to the PostgreSQL data directory.
    """
    version = _get_postgres_version(config)
    return Path(f"/var/lib/postgresql/{version}/{site_slug}")


def _backup_current_data(
    site_slug: str, config: SystemConfig, *, force: bool = False
) -> Path | None:
    """Back up current PostgreSQL data directory before restore.

    If the data directory doesn't exist (e.g., after manual cleanup or
    corruption), the backup step is skipped and restore proceeds directly.

    Args:
        site_slug: Site slug.
        config: System configuration.
        force: If True, allow removing pre-restore backup even when main data
            dir is missing (dangerous - destroys the only remaining copy).

    Returns:
        Path to the backup directory, or None if no data to back up.

    Raises:
        SetupError: If backup fails.
    """
    data_dir = _get_data_dir(site_slug, config)
    backup_dir = data_dir.parent / f"{site_slug}.pre-restore"

    # Protect pre-restore backup from destruction when main data is missing.
    # If backup exists but main data doesn't, a previous restore likely failed
    # and this backup is the only remaining copy of the data.
    if backup_dir.exists() and not data_dir.exists() and not force:
        raise SetupError(
            f"Pre-restore backup exists at {backup_dir} but main data dir is missing.\n"
            f"This suggests a previous restore failed. To proceed:\n"
            f"  1. Restore from backup: mv {backup_dir} {data_dir}\n"
            f"  2. Or force: sum-platform restore {site_slug} --latest --force"
        )

    # Safe to remove old pre-restore backup (main data still exists, or --force)
    if backup_dir.exists():
        OutputFormatter.info("Removing old pre-restore backup...")
        try:
            shutil.rmtree(backup_dir)
        except OSError as exc:
            raise SetupError(f"Failed to remove old pre-restore backup: {exc}") from exc

    # Move current data to backup (if it exists)
    if not data_dir.exists():
        OutputFormatter.warning(
            f"No data directory at {data_dir} — skipping pre-restore backup"
        )
        # Create empty target directory for pgBackRest restore
        data_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
        subprocess.run(
            ["chown", "postgres:postgres", str(data_dir)],
            check=True,
            capture_output=True,
        )
        return None

    OutputFormatter.info("Backing up current data...")
    try:
        shutil.move(str(data_dir), str(backup_dir))
    except OSError as exc:
        raise SetupError(f"Failed to backup current data: {exc}") from exc

    # Create empty target directory for pgBackRest restore
    data_dir.mkdir(mode=0o700, exist_ok=True)
    # Set ownership to postgres
    subprocess.run(
        ["chown", "postgres:postgres", str(data_dir)],
        check=True,
        capture_output=True,
    )
    return backup_dir


def _restore_backup_data(
    backup_dir: Path, site_slug: str, config: SystemConfig
) -> None:
    """Restore the pre-restore backup on failure.

    Args:
        backup_dir: Path to backup directory.
        site_slug: Site slug.
        config: System configuration.
    """
    data_dir = _get_data_dir(site_slug, config)

    OutputFormatter.info("Restoring pre-restore backup...")
    try:
        # Remove failed restore data
        if data_dir.exists():
            shutil.rmtree(data_dir)

        # Restore backup
        shutil.move(str(backup_dir), str(data_dir))
    except OSError as exc:
        OutputFormatter.error(f"Failed to restore backup: {exc}")
        OutputFormatter.error(f"Manual recovery required: mv {backup_dir} {data_dir}")


def _cleanup_backup_data(backup_dir: Path) -> None:
    """Remove the pre-restore backup after successful restore.

    Args:
        backup_dir: Path to backup directory.
    """
    OutputFormatter.info("Cleaning up pre-restore backup...")
    try:
        shutil.rmtree(backup_dir)
        OutputFormatter.success("Pre-restore backup removed")
    except OSError as exc:
        OutputFormatter.warning(
            f"Failed to remove pre-restore backup: {exc}. "
            f"You can safely delete {backup_dir} manually."
        )


def _run_pgbackrest_info(site_slug: str, config: SystemConfig) -> str:
    """Get pgBackRest backup info.

    Args:
        site_slug: Site slug (used as stanza name).
        config: System configuration for paths.

    Returns:
        Output from pgbackrest info command.

    Raises:
        SetupError: If info command fails.
    """
    config_include_path = str(config.get_pgbackrest_config_dir())
    cmd = [
        "sudo",
        "-u",
        "postgres",
        DEFAULT_PGBACKREST_WRAPPER,
        f"--config-include-path={config_include_path}",
        f"--stanza={site_slug}",
        "info",
        "--output=text",
    ]

    try:
        result = subprocess.run(
            cmd,
            check=True,
            capture_output=True,
            text=True,
        )
        return result.stdout
    except subprocess.CalledProcessError as exc:
        # pgbackrest writes errors to stdout with log prefixes, not stderr
        error_output = exc.stdout or exc.stderr or "No error output"
        raise SetupError(f"pgBackRest info failed: {error_output}") from exc
    except FileNotFoundError as exc:
        raise SetupError(
            f"pgbackrest wrapper not found at {DEFAULT_PGBACKREST_WRAPPER}. "
            "Is pgBackRest installed and was 'sum-platform init' run?"
        ) from exc


def run_list_backups(site_name: str) -> int:
    """List available backup restore points for a site.

    Args:
        site_name: Name/slug of the site.

    Returns:
        Exit code (0 for success, non-zero for failure).
    """
    try:
        validate_site_slug(site_name)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    try:
        config = get_system_config()
    except ConfigurationError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # Check that site uses managed PostgreSQL (has allocated port)
    port = get_site_port(site_name, config)
    if port is None:
        OutputFormatter.error(
            f"Site '{site_name}' does not have a PostgreSQL cluster configured. "
            "Only sites with managed PostgreSQL support pgBackRest backups."
        )
        return 1

    # Check that backups are configured
    try:
        _check_backup_configured(config, site_name)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    OutputFormatter.header(f"Available backups for {site_name}")
    print()

    try:
        info = _run_pgbackrest_info(site_name, config)
        print(info)
        return 0
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1


def run_restore(
    site_name: str,
    *,
    target_time: str | None = None,
    use_latest: bool = False,
    cleanup: bool = False,
    skip_confirm: bool = False,
    force: bool = False,
    skip_preflight: bool = False,
) -> int:
    """Restore a database using pgBackRest point-in-time recovery.

    Args:
        site_name: Name/slug of the site.
        target_time: Target time for point-in-time recovery (ISO format).
        use_latest: Restore to latest backup.
        cleanup: Remove pre-restore backup data after successful restore.
        skip_confirm: Skip confirmation prompt.
        force: Force restore even if pre-restore backup is the only data copy.

    Returns:
        Exit code (0 for success, non-zero for failure).
    """
    try:
        validate_site_slug(site_name)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    require_root_or_escalate("restore")

    # Pre-flight checks (phase 1: config-independent)
    early_results: list = []
    if not skip_preflight:
        runner = PreflightRunner()
        runner.register(SystemConfigCheck())
        early_results = runner.run()
        if not PreflightRunner.is_go(early_results):
            print(PreflightRunner.format_results(early_results))
            OutputFormatter.error("Pre-flight checks failed. Aborting.")
            return 1

    try:
        config = get_system_config()
    except ConfigurationError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # Pre-flight checks (phase 2: config-dependent)
    if not skip_preflight:
        runner2 = PreflightRunner()
        runner2.register(
            SiteExistsCheck(site_name, base_dir=str(config.staging.base_dir))
        )
        runner2.register(PostgresClusterCheck(site_name))
        if config.backups:
            cipher_pass = getattr(config.backups, "cipher_pass_file", None)
            if cipher_pass:
                runner2.register(CipherPassFileCheck(cipher_pass))
            pgbackrest_conf_dir = str(config.get_pgbackrest_config_dir())
            runner2.register(PgBackRestStanzaCheck(site_name, pgbackrest_conf_dir))
        late_results = runner2.run()
        all_results = early_results + late_results
        print(PreflightRunner.format_results(all_results))
        if not PreflightRunner.is_go(late_results):
            OutputFormatter.error("Pre-flight checks failed. Aborting.")
            return 1

    # Check that site uses managed PostgreSQL (has allocated port)
    port = get_site_port(site_name, config)
    if port is None:
        OutputFormatter.error(
            f"Site '{site_name}' does not have a PostgreSQL cluster configured. "
            "Only sites with managed PostgreSQL support pgBackRest restores."
        )
        return 1

    # Check that backups are configured
    try:
        _check_backup_configured(config, site_name)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # Validate options
    if target_time and use_latest:
        OutputFormatter.error("Cannot specify both --time and --latest")
        return 1

    if not target_time and not use_latest:
        OutputFormatter.error("Must specify either --time or --latest")
        return 1

    # Validate time format if provided
    if target_time and not _validate_time_format(target_time):
        OutputFormatter.error(
            f"Invalid time format: {target_time}\n"
            "Expected format: YYYY-MM-DD HH:MM:SS (e.g., 2024-01-15 14:30:00)"
        )
        return 1

    # Check disk space before restore
    try:
        _check_disk_space(site_name, config)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # Confirm restore
    data_dir = _get_data_dir(site_name, config)
    if not skip_confirm:
        OutputFormatter.warning(
            "WARNING: This will restore the database and replace all current data."
        )
        if target_time:
            OutputFormatter.info(f"Target time: {target_time}")
        else:
            OutputFormatter.info("Target: Latest backup")
        OutputFormatter.info(
            f"Current data will be backed up to {data_dir.parent}/{site_name}.pre-restore"
        )

        if click is not None:
            if not click.confirm("\nContinue with restore?", default=False):
                OutputFormatter.info("Restore cancelled")
                return 0
        else:
            response = input("\nContinue with restore? [y/N]: ").strip().lower()
            if response not in {"y", "yes"}:
                OutputFormatter.info("Restore cancelled")
                return 0

    # Verify a backup exists before starting the destructive restore process
    try:
        info = _run_pgbackrest_info(site_name, config)
        if not info.strip():
            OutputFormatter.error(
                f"No backups available for '{site_name}'. Cannot restore."
            )
            return 1
    except SetupError as exc:
        OutputFormatter.error(f"Cannot verify backup availability: {exc}")
        return 1

    # Run restore process
    OutputFormatter.header(f"Restoring database for {site_name}")
    print()

    backup_dir: Path | None = None

    try:
        # Stop cluster
        _stop_cluster(site_name, config)
        OutputFormatter.success("Cluster stopped")

        # Backup current data
        backup_dir = _backup_current_data(site_name, config, force=force)
        OutputFormatter.success("Current data backed up")

        # Run restore
        restore_target = target_time if target_time else "latest"
        OutputFormatter.info(f"Restoring to {restore_target}...")
        _run_pgbackrest_restore(site_name, config, target_time=target_time)
        OutputFormatter.success("Restore completed")

        # Patch restore_command to use the cipher-aware wrapper.
        # pgBackRest writes restore_command using the raw binary which
        # lacks the cipher passphrase env var needed for encrypted repos.
        _patch_restore_command(site_name, config)

        # Start cluster
        _start_cluster(site_name, config)
        OutputFormatter.success("Cluster started")

        # Cleanup if requested
        if cleanup and backup_dir:
            _cleanup_backup_data(backup_dir)
        elif backup_dir:
            OutputFormatter.info(
                f"Pre-restore backup preserved at: {backup_dir}\n"
                "Use --cleanup flag to remove it automatically next time."
            )

        OutputFormatter.success("Database restore complete")
        return 0

    except SetupError as exc:
        OutputFormatter.error(str(exc))

        # Restore backup data on failure.
        # Rollback regardless of whether pgBackRest itself succeeded — if the
        # cluster won't start, the restored data is useless and the user's
        # pre-restore backup is their safety net.
        rollback_attempted = False
        rollback_succeeded = False
        if backup_dir and backup_dir.exists():
            rollback_attempted = True
            _restore_backup_data(backup_dir, site_name, config)
            # _restore_backup_data moves backup_dir -> data_dir on success;
            # if backup_dir still exists, the move failed.
            rollback_succeeded = not backup_dir.exists()

        # Try to restart cluster regardless of whether rollback happened —
        # _stop_cluster ran before _backup_current_data, so the cluster is
        # down even when the guard in _backup_current_data raises early.
        try:
            _start_cluster(site_name, config)
            if rollback_succeeded:
                OutputFormatter.info("Cluster restarted with original data")
            elif rollback_attempted:
                OutputFormatter.warning(
                    "Cluster restarted but rollback failed — "
                    "data may not be original. "
                    "Check data directory and pre-restore backup manually."
                )
            else:
                OutputFormatter.info("Cluster restarted (no rollback performed)")
        except SetupError as restart_exc:
            if rollback_succeeded:
                OutputFormatter.error(
                    "Failed to restart cluster after rollback.\n"
                    "Current state: cluster stopped, original data restored.\n"
                    f"Data directory: {_get_data_dir(site_name, config)}\n"
                    f"Restart error: {restart_exc}\n"
                    "Try starting manually: pg_ctlcluster "
                    f"{_get_postgres_version(config)} {site_name} start"
                )
            elif rollback_attempted:
                OutputFormatter.error(
                    "Failed to restart cluster after failed rollback.\n"
                    "Current state: cluster stopped, rollback failed.\n"
                    f"Data directory: {_get_data_dir(site_name, config)}\n"
                    f"Pre-restore backup: {backup_dir}\n"
                    f"Restart error: {restart_exc}\n"
                    f"Manual recovery: mv {backup_dir} "
                    f"{_get_data_dir(site_name, config)}"
                )
            else:
                OutputFormatter.error(
                    "Failed to restart cluster.\n"
                    "Current state: cluster stopped, no rollback performed.\n"
                    f"Data directory: {_get_data_dir(site_name, config)}\n"
                    f"Restart error: {restart_exc}\n"
                    "Check cluster logs: pg_lsclusters"
                )

        return 1


def _restore_command(
    site_name: str,
    target_time: str | None,
    use_latest: bool,
    cleanup: bool,
    skip_confirm: bool,
    force: bool,
    skip_preflight: bool = False,
) -> None:
    """Restore a database using pgBackRest."""
    result = run_restore(
        site_name,
        target_time=target_time,
        use_latest=use_latest,
        cleanup=cleanup,
        skip_confirm=skip_confirm,
        force=force,
        skip_preflight=skip_preflight,
    )
    if result != 0:
        raise SystemExit(result)


def _missing_click(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("click is required to use the restore command")


if click is None:
    restore = _missing_click
else:

    @click.command(name="restore")
    @click.argument("site_name")
    @click.option(
        "--list",
        "list_backups",
        is_flag=True,
        help="List available backup restore points.",
    )
    @click.option(
        "--time",
        "target_time",
        type=str,
        help="Point-in-time to restore to (format: YYYY-MM-DD HH:MM:SS).",
    )
    @click.option(
        "--latest",
        "use_latest",
        is_flag=True,
        help="Restore to latest backup.",
    )
    @click.option(
        "--cleanup",
        is_flag=True,
        help="Remove pre-restore backup data after successful restore.",
    )
    @click.option(
        "--confirm",
        "skip_confirm",
        is_flag=True,
        help="Skip confirmation prompt.",
    )
    @click.option(
        "--force",
        is_flag=True,
        help="Force restore even if pre-restore backup is the only data copy.",
    )
    @click.pass_context
    def _click_restore(
        ctx: click.Context,
        site_name: str,
        list_backups: bool,
        target_time: str | None,
        use_latest: bool,
        cleanup: bool,
        skip_confirm: bool,
        force: bool,
    ) -> None:
        """Restore database using pgBackRest point-in-time recovery.

        Restores PostgreSQL databases to a specific point in time or to
        the latest backup. The current data is backed up before restore and
        can be restored if the restore fails.

        \b
        Examples:
          sum-platform restore acme --list
          sum-platform restore acme --latest
          sum-platform restore acme --time "2024-01-15 14:30:00"
          sum-platform restore acme --latest --cleanup
          sum-platform restore acme --latest --confirm

        \b
        The restore process:
          1. Stops the PostgreSQL cluster
          2. Backs up current data
          3. Runs pgBackRest restore
          4. Starts the cluster
          5. Optionally removes the pre-restore backup (--cleanup)

        \b
        On failure, the pre-restore backup is automatically restored.
        """
        if list_backups:
            result = run_list_backups(site_name)
            if result != 0:
                raise SystemExit(result)
            return

        _restore_command(
            site_name,
            target_time=target_time,
            use_latest=use_latest,
            cleanup=cleanup,
            skip_confirm=skip_confirm,
            force=force,
            skip_preflight=(ctx.obj or {}).get("skip_preflight", False),
        )

    restore = _click_restore
