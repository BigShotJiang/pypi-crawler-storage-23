"""Check command for validating SUM project readiness."""

from __future__ import annotations

import sys
from collections.abc import Callable
from pathlib import Path
from types import ModuleType

from sum.utils.environment import ExecutionMode, detect_mode, resolve_project_path
from sum.utils.validation import ProjectValidator, ValidationResult, ValidationStatus

click_module: ModuleType | None
try:
    import click as click_module
except ImportError:  # pragma: no cover
    click_module = None

click: ModuleType | None = click_module


def _resolve_project_path(project: str | None) -> Path:
    return resolve_project_path(project)


def _format_status(status: ValidationStatus) -> str:
    if status is ValidationStatus.OK:
        return "[OK]"
    if status is ValidationStatus.SKIP:
        return "[SKIP]"
    return "[FAIL]"


def _virtualenv_check(validator: ProjectValidator) -> ValidationResult:
    venv_result = validator.check_venv_exists()
    if venv_result.failed:
        return venv_result

    package_result = validator.check_packages_installed()
    if package_result.failed or package_result.skipped:
        return package_result

    return ValidationResult.ok("Virtualenv exists with required packages")


def run_enhanced_checks(project_path: Path, mode: ExecutionMode) -> None:
    """Run enhanced validation checks.

    Example:
        run_enhanced_checks(Path('clients/demo'), ExecutionMode.STANDALONE)
    """
    validator = ProjectValidator(project_path, mode)

    checks: list[tuple[str, Callable[[], ValidationResult]]] = [
        ("Virtualenv", lambda: _virtualenv_check(validator)),
        ("Credentials", validator.check_env_local),
        ("Database", validator.check_migrations_applied),
        ("Homepage", validator.check_homepage_exists),
        ("Theme compiled CSS", validator.check_theme_compiled_css),
        ("Theme slug match", validator.check_theme_slug_match),
        ("Required env vars", validator.check_required_env_vars),
        ("sum_core import", validator.check_sum_core_import),
    ]

    has_failures = False

    for name, check_func in checks:
        result = check_func()
        status = _format_status(result.status)
        print(f"{status} {name}: {result.message}")
        if result.failed and result.remediation:
            print(f"      → {result.remediation}")
            has_failures = True
        elif result.failed:
            has_failures = True

    if has_failures:
        print("\n❌ Some checks failed")
        sys.exit(1)

    print("\n✅ All checks passed")


def run_check(project_path: str | Path | None = None) -> int:
    """V1-compatible check that returns exit code instead of calling sys.exit.

    Note: This runs a reduced check set (6 checks) for backward compatibility.
    Omits Virtualenv and Database checks which require Django environment setup.
    For full validation (8 checks), use run_enhanced_checks() instead.
    """
    try:
        path = _resolve_project_path(str(project_path) if project_path else None)
    except FileNotFoundError:
        return 1
    mode = detect_mode(path)
    validator = ProjectValidator(path, mode)

    checks: list[tuple[str, Callable[[], ValidationResult]]] = [
        ("Credentials", validator.check_env_local),
        ("Homepage", validator.check_homepage_exists),
        ("Theme compiled CSS", validator.check_theme_compiled_css),
        ("Theme slug match", validator.check_theme_slug_match),
        ("Required env vars", validator.check_required_env_vars),
        ("sum_core import", validator.check_sum_core_import),
    ]

    has_failures = False
    for name, check_func in checks:
        result = check_func()
        status = _format_status(result.status)
        print(f"{status} {name}: {result.message}")
        if result.failed and result.remediation:
            print(f"      → {result.remediation}")
            has_failures = True
        elif result.failed:
            has_failures = True

    if has_failures:
        print("\n❌ Some checks failed")
        return 1

    print("\n✅ All checks passed")
    return 0


def _missing_click(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("click is required to use the check command")


if click is None:
    check = _missing_click
else:

    @click.command()
    @click.argument("project", required=False)
    def _click_check(project: str | None) -> None:
        """Validate project setup."""
        try:
            path = _resolve_project_path(project)
        except FileNotFoundError as exc:
            print(f"Error: {exc}", file=sys.stderr)
            raise SystemExit(1)
        mode = detect_mode(path)
        run_enhanced_checks(path, mode)

    check = _click_check
