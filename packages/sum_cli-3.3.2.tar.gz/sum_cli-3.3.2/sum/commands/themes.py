"""Themes command for listing available themes.

DEPRECATED: This command is deprecated in favor of `sum-platform theme list`.
It remains for backward compatibility but will show a deprecation notice.
"""

from __future__ import annotations

import sys

from sum.themes_registry import list_themes

DEPRECATION_MESSAGE = (
    "DeprecationWarning: `sum-platform themes` is deprecated. "
    "Use `sum-platform theme list` instead."
)


def run_themes_list() -> int:
    """
    List all available themes.

    Returns:
        0 on success, 1 on failure
    """
    # Show deprecation notice
    print(DEPRECATION_MESSAGE, file=sys.stderr)
    print(file=sys.stderr)

    try:
        themes = list_themes()

        if not themes:
            print("No themes available.")
            print()
            print("Tip: Use `sum-platform theme list --remote` to see remote themes.")
            return 0

        print("Available themes:")
        print()
        for theme in themes:
            print(f"  {theme.slug}")
            print(f"    Name: {theme.name}")
            print(f"    Description: {theme.description}")
            print(f"    Version: {theme.version}")
            print()

        return 0
    except Exception as e:
        print(f"[FAIL] Failed to list themes: {e}", file=sys.stderr)
        return 1


# Click command wrapper
_missing_click: bool = False
try:
    import click

    @click.command(name="themes")
    def themes() -> None:
        """List available themes (deprecated, use `theme list`)."""
        result = run_themes_list()
        if result != 0:
            raise SystemExit(result)

except ImportError:
    _missing_click = True

    def themes() -> None:  # type: ignore[misc]
        """Fallback when click is not installed."""
        raise RuntimeError("Click is required for CLI commands")
