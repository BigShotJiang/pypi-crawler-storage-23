"""Setup command for initializing /etc/sum/config.yml."""

from __future__ import annotations

import os
from pathlib import Path
from types import ModuleType

import yaml
from sum.system_config import DEFAULT_CONFIG_PATH
from sum.utils.output import OutputFormatter

click_module: ModuleType | None
try:
    import click as click_module
except ImportError:  # pragma: no cover
    click_module = None

click: ModuleType | None = click_module


def _missing_click(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("click is required to use the setup command")


if click is None:
    setup = _missing_click
else:

    @click.command()
    def setup() -> None:
        """Initialize system configuration interactively.

        Creates /etc/sum/config.yml with infrastructure settings.
        Requires sudo.

        \b
        The configuration file stores:
        - Agency information
        - Staging server settings
        - Production server settings
        - Infrastructure template paths
        - Default values

        \b
        Git settings are NOT stored here - they are per-site,
        specified when running 'sum-platform init'.
        """
        if os.geteuid() != 0:
            raise click.ClickException(
                "Setup requires root privileges. Run with: sudo sum-platform setup"
            )

        if DEFAULT_CONFIG_PATH.exists():
            if not click.confirm(f"{DEFAULT_CONFIG_PATH} exists. Overwrite?"):
                raise SystemExit(0)

        click.echo("SUM Platform Setup")
        click.echo("=" * 40)
        click.echo()

        # Agency
        click.echo("Agency Information:")
        agency_name = click.prompt("  Agency name", type=str)

        click.echo()

        # Staging
        click.echo("Staging Server Configuration:")
        staging_server = click.prompt("  Hostname", type=str)
        staging_domain_pattern = click.prompt(
            "  Domain pattern (use {slug} placeholder)",
            default="{slug}." + staging_server,
        )
        staging_base_dir = click.prompt("  Base directory", default="/srv/sum")

        click.echo()

        # Production
        click.echo("Production Server Configuration:")
        prod_server = click.prompt("  Hostname", type=str)
        prod_ssh_host = click.prompt("  SSH host (IP or hostname)", default=prod_server)
        prod_base_dir = click.prompt("  Base directory", default="/srv/sum")

        click.echo()

        # Templates
        click.echo("Infrastructure Templates:")
        templates_dir = click.prompt("  Templates directory", type=str)
        systemd_template = click.prompt(
            "  Systemd template (relative path)",
            default="systemd/sum-site-gunicorn.service.template",
        )
        caddy_template = click.prompt(
            "  Caddy template (relative path)",
            default="caddy/Caddyfile.template",
        )

        click.echo()

        # Defaults
        click.echo("Defaults:")
        default_theme = click.prompt("  Default theme", default="theme_a")
        seed_profile = click.prompt("  Seed profile", default="starter")
        deploy_user = click.prompt("  Deploy user", default="deploy")
        postgres_port = click.prompt("  Postgres port", default=5432, type=int)

        click.echo()

        # Backups (optional)
        click.echo("Backup Configuration (optional):")
        configure_backups = click.confirm("  Configure backup storage?", default=False)

        backups_config = None
        if configure_backups:
            click.echo()
            click.echo("  Hetzner Storage Box Settings:")
            storage_host = click.prompt("    Host (e.g., u123456.your-storagebox.de)")
            storage_user = click.prompt("    User", default="u123456")
            storage_port = click.prompt("    SFTP port", default=23, type=int)
            storage_fingerprint = click.prompt("    SSH host fingerprint (SHA256)")
            ssh_key_path = click.prompt(
                "    SSH key path", default="/etc/sum/backup-key-rsa"
            )

            click.echo()
            click.echo("  Retention Settings:")
            retention_full = click.prompt(
                "    Full backups to keep", default=2, type=int
            )
            retention_diff = click.prompt(
                "    Diff backups to keep", default=7, type=int
            )

            click.echo()
            click.echo("  Alerts:")
            alert_email = click.prompt("    Alert email address")

            click.echo()
            click.echo("  Email Delivery (SMTP):")
            click.echo("    Note: Local sendmail is unreliable for delivery.")
            click.echo("    An external SMTP relay (e.g. Resend, SES) is recommended.")
            configure_smtp = click.confirm(
                "    Configure external SMTP relay? (recommended)", default=True
            )

            smtp_config = {}
            if configure_smtp:
                smtp_host = click.prompt("    SMTP host", type=str)
                smtp_port = click.prompt("    SMTP port", default=587, type=int)
                smtp_username = click.prompt("    SMTP username", default="", type=str)
                smtp_password_file = click.prompt(
                    "    SMTP password file path",
                    default="/etc/sum/smtp-password",
                    type=str,
                )
                smtp_use_tls = click.confirm(
                    "    Use TLS? (STARTTLS on 587, implicit on 465)",
                    default=True,
                )
                from_address = click.prompt(
                    "    From address",
                    default="backup-monitor@localhost",
                    type=str,
                )
                smtp_config = {
                    "smtp_host": smtp_host,
                    "smtp_port": smtp_port,
                    "smtp_username": smtp_username,
                    "smtp_password_file": smtp_password_file,
                    "smtp_use_tls": smtp_use_tls,
                    "from_address": from_address,
                }

            alerts_dict = {"email": alert_email}
            if smtp_config:
                alerts_dict.update(smtp_config)

            backups_config = {
                "storage_box": {
                    "host": storage_host,
                    "user": storage_user,
                    "port": storage_port,
                    "fingerprint": storage_fingerprint,
                    "ssh_key": ssh_key_path,
                    "base_path": "/backups",
                },
                "retention": {
                    "full_backups": retention_full,
                    "diff_backups": retention_diff,
                },
                "alerts": alerts_dict,
            }

        # Build config
        config = {
            "agency": {
                "name": agency_name,
            },
            "staging": {
                "server": staging_server,
                "domain_pattern": staging_domain_pattern,
                "base_dir": staging_base_dir,
            },
            "production": {
                "server": prod_server,
                "ssh_host": prod_ssh_host,
                "base_dir": prod_base_dir,
            },
            "templates": {
                "dir": templates_dir,
                "systemd": systemd_template,
                "caddy": caddy_template,
            },
            "defaults": {
                "theme": default_theme,
                "seed_profile": seed_profile,
                "deploy_user": deploy_user,
                "postgres_port": postgres_port,
            },
        }

        if backups_config:
            config["backups"] = backups_config

        # Write config with restrictive permissions (0o640: root rw, group r)
        config_path = Path(DEFAULT_CONFIG_PATH)
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_content = yaml.dump(config, default_flow_style=False, sort_keys=False)
        fd = os.open(config_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o640)
        os.fchmod(fd, 0o640)
        try:
            os.write(fd, config_content.encode())
        finally:
            os.close(fd)

        click.echo()
        OutputFormatter.success(f"Configuration saved to {DEFAULT_CONFIG_PATH}")
