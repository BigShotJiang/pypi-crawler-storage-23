# pyright: reportImplicitStringConcatenation=false, reportUnusedCallResult=false

"""Test email delivery configuration.

Sends a test email through the configured delivery method to verify
that backup alert emails will work correctly.
"""

from __future__ import annotations

from types import ModuleType

from sum.setup.backup_monitor import send_test_email

click_module: ModuleType | None
try:
    import click as click_module
except ImportError:  # pragma: no cover
    click_module = None

click: ModuleType | None = click_module


def _missing_click(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("click is required to use the test-email command")


if click is None:
    test_email = _missing_click
else:

    @click.command(name="test-email")
    @click.option(
        "-v",
        "--verbose",
        is_flag=True,
        help="Show debug output for troubleshooting delivery failures.",
    )
    def _click_test_email(verbose: bool) -> None:
        """Send a test email to verify alert delivery.

        Reads email configuration from /etc/sum/config.yml and sends a test
        message through the same delivery path used by 'sum-platform monitor'.

        \b
        Examples:
          sum-platform test-email            # Send test email
          sum-platform test-email -v         # With debug output
        """
        result = send_test_email(verbose=verbose)
        if result != 0:
            raise SystemExit(result)

    test_email = _click_test_email
