# pyright: reportImplicitStringConcatenation=false, reportUnusedCallResult=false

"""Backup monitoring command with email alerts.

Checks backup freshness for all managed PostgreSQL sites and sends alerts
when backups are stale (>48 hours old).
"""

from __future__ import annotations

from types import ModuleType

from sum.setup.backup_monitor import run_backup_monitor

click_module: ModuleType | None
try:
    import click as click_module
except ImportError:  # pragma: no cover
    click_module = None

click: ModuleType | None = click_module


def _missing_click(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("click is required to use the monitor command")


if click is None:
    monitor = _missing_click
else:

    @click.command(name="monitor")
    @click.option(
        "--no-alerts",
        is_flag=True,
        help="Check backups without sending email alerts.",
    )
    @click.option(
        "-v",
        "--verbose",
        is_flag=True,
        help="Show status for all sites, not just problems.",
    )
    def _click_monitor(no_alerts: bool, verbose: bool) -> None:
        """Monitor backup health and send alerts.

        Checks backup freshness for all managed PostgreSQL sites. Sends email
        alerts when backups are stale (>48 hours old) or missing.

        \b
        Examples:
          sum-platform monitor                  # Check and alert
          sum-platform monitor --no-alerts      # Check without alerting
          sum-platform monitor -v               # Verbose output

        \b
        Designed for cron:
          0 * * * * /usr/local/bin/sum-platform monitor

        Note: An external SMTP relay is recommended for reliable delivery.
        Configure in /etc/sum/config.yml or via 'sum-platform setup'.
        """
        result = run_backup_monitor(
            send_alerts=not no_alerts,
            verbose=verbose,
        )
        if result != 0:
            raise SystemExit(result)

    monitor = _click_monitor
