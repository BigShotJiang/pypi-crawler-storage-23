# pyright: reportImplicitStringConcatenation=false, reportUnusedCallResult=false

"""Promote command implementation.

Promotes a staging site to production:
- Backup staging DB
- Copy backup to production
- Provision infrastructure on production
- Clone repo, restore DB, sync media
- Start service and verify
"""

from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
import sys
import textwrap
import time
from datetime import UTC, datetime
from pathlib import Path
from types import ModuleType

import yaml
from sum.exceptions import SetupError
from sum.setup.backup_cron import get_staggered_minute
from sum.setup.bare_metal_postgres import (
    DEFAULT_PGBACKREST_WRAPPER,
    render_pgbackrest_wrapper_script,
)
from sum.setup.git_ops import get_git_provider_from_config
from sum.setup.infrastructure import (
    escape_env_value,
    generate_password,
    generate_secret_key,
)
from sum.site_config import GitConfig, SiteConfig, SiteConfigError
from sum.system_config import ConfigurationError, SystemConfig, get_system_config
from sum.utils.output import OutputFormatter
from sum.utils.preflight import (
    CipherPassFileCheck,
    DiskSpaceCheck,
    GiteaRepoCheck,
    GiteaTokenCheck,
    PgBackRestStanzaCheck,
    PostgresClusterCheck,
    PreflightRunner,
    SiteExistsCheck,
    SSHConnectivityCheck,
    SystemConfigCheck,
)
from sum.utils.privilege import detect_gitea_token, require_root_or_escalate
from sum.utils.validation import validate_domain, validate_site_slug

SSH_TIMEOUT = 15
DEFAULT_POSTGRES_VERSION = "18"
_SAFE_PATH_RE = re.compile(r"^[a-zA-Z0-9/_.-]+$")


def _validate_safe_path(value: str, label: str) -> None:
    """Validate a value is safe for embedding in shell commands.

    Checks against _SAFE_PATH_RE and rejects path traversal (``..``).

    Args:
        value: The string to validate.
        label: Human-readable label for error messages.

    Raises:
        SetupError: If the value contains unsafe characters or path traversal.
    """
    if ".." in value:
        raise SetupError(f"Path traversal detected in {label}: {value}")
    if not _SAFE_PATH_RE.match(value):
        raise SetupError(f"Unsafe characters in {label}: {value}")


click_module: ModuleType | None
try:
    import click as click_module
except ImportError:  # pragma: no cover
    click_module = None

click: ModuleType | None = click_module


def _check_ssh_connectivity(config: SystemConfig) -> None:
    """Test SSH connectivity to the production host before destructive operations.

    Raises SetupError if the connection fails or times out.
    """
    ssh_host = config.production.ssh_host
    try:
        subprocess.run(
            [
                "ssh",
                "-o",
                "BatchMode=yes",
                "-o",
                "StrictHostKeyChecking=accept-new",
                "-o",
                f"ConnectTimeout={SSH_TIMEOUT}",
                ssh_host,
                "true",
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=SSH_TIMEOUT,
        )
    except subprocess.TimeoutExpired as exc:
        raise SetupError(
            f"SSH connection to {ssh_host} timed out after {SSH_TIMEOUT}s"
        ) from exc
    except FileNotFoundError as exc:
        raise SetupError(
            "SSH client 'ssh' not found. Please install the OpenSSH client and "
            "ensure 'ssh' is available on your PATH."
        ) from exc
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr or ""
        raise SetupError(f"SSH connection to {ssh_host} failed: {stderr}") from exc


def _backup_staging_db(site_slug: str, staging_dir: Path, config: SystemConfig) -> Path:
    """Create a backup of the staging database."""
    from sum.setup.ports import get_site_port

    db_name = config.get_db_name(site_slug)
    db_port = get_site_port(site_slug, config)
    backup_dir = staging_dir / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    backup_filename = f"{site_slug}_{timestamp}_promote.sql.gz"
    backup_path = backup_dir / backup_filename

    pg_dump_cmd = ["sudo", "-u", "postgres", "pg_dump"]
    if db_port:
        pg_dump_cmd.extend(["--port", str(db_port)])
    pg_dump_cmd.append(db_name)

    try:
        with open(backup_path, "wb") as f:
            pg_dump = subprocess.Popen(
                pg_dump_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            gzip = subprocess.Popen(
                ["gzip"],
                stdin=pg_dump.stdout,
                stdout=f,
                stderr=subprocess.PIPE,
            )
            if pg_dump.stdout:
                pg_dump.stdout.close()

            gzip.communicate()
            pg_dump.wait()

            if pg_dump.returncode != 0:
                stderr = pg_dump.stderr.read() if pg_dump.stderr else b""
                raise SetupError(f"pg_dump failed: {stderr.decode()}")

    except OSError as exc:
        raise SetupError(f"Failed to create backup: {exc}") from exc

    # Restrict permissions on backup file (contains database contents)
    os.chmod(backup_path, 0o600)

    return backup_path


def _copy_backup_to_prod(backup_path: Path, config: SystemConfig) -> str:
    """Copy backup file to production server via secure temp directory."""
    ssh_host = config.production.ssh_host

    # Create secure temp directory on remote (owned by current user, mode 700)
    try:
        result = subprocess.run(
            ["ssh", ssh_host, "mktemp", "-d", "/tmp/sum-promote-XXXXXXXX"],
            check=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
        remote_tmp_dir = result.stdout.strip()
    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to create temp dir on production: {exc.stderr}"
        ) from exc

    # Restrict permissions on the temp directory
    try:
        subprocess.run(
            ["ssh", ssh_host, "chmod", "700", remote_tmp_dir],
            check=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to set temp dir permissions: {exc.stderr}") from exc

    remote_path = f"{remote_tmp_dir}/{backup_path.name}"

    try:
        subprocess.run(
            ["scp", str(backup_path), f"{ssh_host}:{remote_path}"],
            check=True,
            capture_output=True,
            text=True,
            timeout=300,
        )
    except subprocess.CalledProcessError as exc:
        # Clean up on failure
        subprocess.run(
            ["ssh", ssh_host, "rm", "-rf", remote_tmp_dir],
            capture_output=True,
            text=True,
            timeout=30,
        )
        raise SetupError(f"Failed to copy backup to production: {exc.stderr}") from exc

    return remote_path


def _allocate_remote_port(site_slug: str, config: SystemConfig) -> int:
    """Allocate a PostgreSQL port for a site on the production server.

    Performs an atomic read-modify-write of the port registry under a single
    flock acquisition to prevent concurrent allocation races. The entire
    operation runs as a single Python script on the remote side.

    Idempotent: returns the existing port if the site already has one.

    Args:
        site_slug: Site identifier.
        config: System configuration.

    Returns:
        Allocated port number.

    Raises:
        SetupError: If allocation fails or port range is exhausted.
    """
    ssh_host = config.production.ssh_host
    ports_file = str(config.get_ports_file())
    lock_file = str(config.get_ports_lock_file())
    min_port, max_port = config.get_port_range()

    # Inline Python script runs entirely under flock on the remote side.
    # This eliminates the TOCTOU race of separate read/write SSH calls.
    allocate_script = textwrap.dedent(f"""\
        import json, os, sys, tempfile

        ports_file = {json.dumps(ports_file)}
        site_slug = {json.dumps(site_slug)}
        min_port, max_port = {min_port}, {max_port}

        os.makedirs(os.path.dirname(ports_file), exist_ok=True)
        try:
            with open(ports_file) as f:
                ports = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            ports = {{}}

        if not isinstance(ports, dict):
            print("Port registry is not a JSON object", file=sys.stderr)
            sys.exit(1)

        # Idempotent: return existing allocation
        if site_slug in ports:
            print(int(ports[site_slug]))
            sys.exit(0)

        used = set()
        for v in ports.values():
            try:
                used.add(int(v))
            except (TypeError, ValueError):
                continue

        port = min_port
        while port in used:
            port += 1
            if port > max_port:
                print(
                    f"No available ports in range {{min_port}}-{{max_port}} "
                    f"on production. Maximum of {{max_port - min_port + 1}} "
                    "PostgreSQL sites reached.",
                    file=sys.stderr,
                )
                sys.exit(1)

        ports[site_slug] = port

        # Atomic write: tempfile + os.replace
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(ports_file))
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(ports, f, indent=2, sort_keys=True)
            os.replace(tmp, ports_file)
        except BaseException:
            os.unlink(tmp)
            raise

        print(port)
    """)

    q_lock = shlex.quote(lock_file)
    try:
        result = subprocess.run(
            ["ssh", ssh_host, f"sudo flock {q_lock} python3 -"],
            input=allocate_script,
            check=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.strip() if exc.stderr else str(exc)
        raise SetupError(
            f"Failed to allocate PostgreSQL port on production: {stderr}"
        ) from exc

    stdout = result.stdout.strip()
    try:
        return int(stdout)
    except ValueError as exc:
        raise SetupError(
            f"Failed to parse allocated port from production: {stdout!r}"
        ) from exc


def _deallocate_remote_port(site_slug: str, config: SystemConfig) -> None:
    """Best-effort removal of a port allocation from the production registry.

    Runs an inline Python script under flock on the remote side to atomically
    remove the site's port entry. Failures are logged but do not raise.

    Args:
        site_slug: Site identifier.
        config: System configuration.
    """
    ssh_host = config.production.ssh_host
    ports_file = str(config.get_ports_file())
    lock_file = str(config.get_ports_lock_file())

    deallocate_script = textwrap.dedent(f"""\
        import json, os, sys, tempfile

        ports_file = {json.dumps(ports_file)}
        site_slug = {json.dumps(site_slug)}

        os.makedirs(os.path.dirname(ports_file), exist_ok=True)
        try:
            with open(ports_file) as f:
                ports = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            ports = {{}}

        if not isinstance(ports, dict) or site_slug not in ports:
            sys.exit(0)

        del ports[site_slug]

        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(ports_file))
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(ports, f, indent=2, sort_keys=True)
            os.replace(tmp, ports_file)
        except BaseException:
            os.unlink(tmp)
            raise
    """)

    q_lock = shlex.quote(lock_file)
    try:
        subprocess.run(
            ["ssh", ssh_host, f"sudo flock {q_lock} python3 -"],
            input=deallocate_script,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except (subprocess.SubprocessError, OSError) as exc:
        OutputFormatter.warning(f"Failed to deallocate port for {site_slug}: {exc}")


def _provision_remote_postgres(
    site_slug: str,
    config: SystemConfig,
) -> int:
    """Provision an isolated PostgreSQL cluster on production via SSH.

    Creates a per-site PostgreSQL cluster using pg_createcluster, starts it,
    and waits for readiness. Database and user creation is handled separately
    by _provision_prod_infrastructure(). Idempotent: reuses existing clusters.

    Args:
        site_slug: Site identifier.
        config: System configuration.

    Returns:
        The allocated port number.

    Raises:
        SetupError: If provisioning fails.
    """
    ssh_host = config.production.ssh_host

    # Get postgres version from config
    postgres_version = DEFAULT_POSTGRES_VERSION
    if config.infrastructure:
        postgres_version = config.infrastructure.postgres_version

    q_slug = shlex.quote(site_slug)
    q_version = shlex.quote(postgres_version)

    # Check if cluster already exists BEFORE allocating a port.
    # This prevents returning a stale registry port when a cluster was
    # manually created on a different port.
    try:
        result = subprocess.run(
            ["ssh", ssh_host, "pg_lsclusters", "-h"],
            check=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
        for line in result.stdout.strip().splitlines():
            parts = line.split()
            # pg_lsclusters output: version cluster port status ...
            if (
                len(parts) >= 3
                and parts[0] == postgres_version
                and parts[1] == site_slug
            ):
                try:
                    actual_port = int(parts[2])
                except ValueError:
                    # Malformed pg_lsclusters output — skip and create fresh
                    continue
                # Ensure registry consistency (idempotent)
                _allocate_remote_port(site_slug, config)
                OutputFormatter.info(
                    f"PostgreSQL cluster {postgres_version}/{site_slug} already exists"
                )
                return actual_port
    except subprocess.CalledProcessError:
        pass  # pg_lsclusters failed — proceed to create

    # Allocate port (idempotent)
    port = _allocate_remote_port(site_slug, config)

    # Create cluster
    try:
        subprocess.run(
            [
                "ssh",
                ssh_host,
                f"sudo pg_createcluster {q_version} {q_slug}"
                f" -p {shlex.quote(str(port))} --start-conf=auto",
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to create PostgreSQL cluster on production: {exc.stderr}"
        ) from exc

    # Start cluster
    try:
        subprocess.run(
            [
                "ssh",
                ssh_host,
                f"sudo pg_ctlcluster --skip-systemctl-redirect {q_version} {q_slug} start",
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to start PostgreSQL cluster on production: {exc.stderr}"
        ) from exc

    # Wait for postgres to be ready
    q_port = shlex.quote(str(port))
    deadline = time.time() + 60
    while time.time() < deadline:
        try:
            result = subprocess.run(
                ["ssh", ssh_host, f"pg_isready -p {q_port}"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                break
        except (subprocess.TimeoutExpired, subprocess.SubprocessError):
            # Transient SSH/pg_isready failures expected while cluster starts;
            # retry until deadline.
            pass
        time.sleep(2)
    else:
        raise SetupError(
            f"PostgreSQL on production did not become ready within 60 seconds (port {port})"
        )

    return port


def _provision_prod_infrastructure(
    site_slug: str,
    domain: str,
    config: SystemConfig,
) -> dict[str, str]:
    """Provision infrastructure on production server via SSH.

    Creates an isolated PostgreSQL cluster, allocates a unique port,
    provisions the database/user, creates site directories, and writes .env.

    Returns:
        Credentials dict including db_port for the isolated cluster.
    """
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")
    db_name = config.get_db_name(site_slug)
    db_user = config.get_db_user(site_slug)
    db_password = generate_password()
    secret_key = generate_secret_key()
    python_package = site_slug.replace("-", "_")

    # Provision isolated PostgreSQL cluster (idempotent)
    db_port = _provision_remote_postgres(site_slug, config)

    credentials = {
        "db_name": db_name,
        "db_user": db_user,
        "db_password": db_password,
        "secret_key": secret_key,
        "db_port": str(db_port),
    }

    # Create directories
    try:
        subprocess.run(
            [
                "ssh",
                ssh_host,
                f"mkdir -p {shlex.quote(str(site_dir))}/{{app,venv,static,media,backups}}",
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to create directories: {exc.stderr}") from exc

    # Create database user and database on the isolated cluster using -p <port>
    sql_commands = [
        ("CREATE USER :\"db_user\" WITH PASSWORD :'db_password';", "create user"),
        ('CREATE DATABASE :"db_name" OWNER :"db_user";', "create database"),
        (
            'GRANT ALL PRIVILEGES ON DATABASE :"db_name" TO :"db_user";',
            "grant privileges",
        ),
    ]

    # Password set via stdin to avoid /proc exposure
    password_escaped = db_password.replace("'", "''")
    password_preamble = f"\\set db_password '{password_escaped}'\n"

    for sql, description in sql_commands:
        try:
            psql_cmd = (
                f"sudo -u postgres psql -p {shlex.quote(str(db_port))} "
                f"-v db_user={shlex.quote(db_user)} "
                f"-v db_name={shlex.quote(db_name)}"
            )
            subprocess.run(
                ["ssh", ssh_host, psql_cmd],
                input=password_preamble + sql,
                check=True,
                capture_output=True,
                text=True,
                timeout=60,
            )
        except subprocess.CalledProcessError as exc:
            # Ignore "already exists" errors
            if "already exists" not in (exc.stderr or ""):
                raise SetupError(f"Failed to {description}: {exc.stderr}") from exc

    # Write .env file with allocated port
    env_content = f"""# SUM Platform Site Configuration
# Generated by sum-platform promote

DJANGO_SECRET_KEY={escape_env_value(secret_key)}
DJANGO_SETTINGS_MODULE={python_package}.settings.production
DJANGO_DEBUG=False

DJANGO_DB_NAME={escape_env_value(db_name)}
DJANGO_DB_USER={escape_env_value(db_user)}
DJANGO_DB_PASSWORD={escape_env_value(db_password)}
DJANGO_DB_HOST=localhost
DJANGO_DB_PORT={db_port}

DJANGO_STATIC_ROOT={site_dir}/static
DJANGO_MEDIA_ROOT={site_dir}/media

ALLOWED_HOSTS={escape_env_value(domain)}
WAGTAILADMIN_BASE_URL={escape_env_value(f"https://{domain}")}
"""

    # Write env file via SSH using tee (stdin → file).
    # Suppress tee stdout (> /dev/null) so secrets don't transit SSH twice.
    env_path = shlex.quote(f"{site_dir}/.env")
    try:
        subprocess.run(
            ["ssh", ssh_host, f"tee {env_path} > /dev/null"],
            check=True,
            capture_output=True,
            text=True,
            input=env_content,
            timeout=60,
        )
        subprocess.run(
            ["ssh", ssh_host, "chmod", "600", env_path],
            check=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to write .env: {exc.stderr}") from exc

    return credentials


def _clone_repo_on_prod(
    site_slug: str, config: SystemConfig, git_config: GitConfig
) -> None:
    """Clone the site repository on production.

    Uses HTTPS with token to avoid SSH key requirements on production.
    Falls back to SSH if token is not available.
    """
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")
    provider = get_git_provider_from_config(git_config)
    org = git_config.org

    q_app_dir = shlex.quote(f"{site_dir}/app")
    q_site_env = shlex.quote(f"{site_dir}/.env")
    q_app_env = shlex.quote(f"{site_dir}/app/.env")

    # Get URLs from provider
    ssh_clone_url = provider.get_clone_url(org, site_slug)
    clean_https_url = f"{provider.get_repo_url(org, site_slug)}.git"

    # Try to get token for HTTPS clone (avoids SSH key setup on prod)
    token: str | None = None
    if git_config.provider == "github":
        try:
            result = subprocess.run(
                ["gh", "auth", "token"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                token = result.stdout.strip()
        except (subprocess.SubprocessError, FileNotFoundError):
            pass
    elif git_config.provider == "gitea":
        token = os.environ.get(git_config.token_env)

    # Clone repo — token must NEVER appear in process args (local or remote)
    if token:
        # Single remote command with trap EXIT for unconditional cleanup.
        # Token is piped via stdin — never in any local or remote cmdline.
        # trap runs even if mktemp succeeds but cat/chmod/clone fails.
        remote_script = (
            "ASKPASS=$(mktemp) && "
            "trap 'rm -f \"$ASKPASS\"' EXIT && "
            'cat > "$ASKPASS" && '
            'chmod 700 "$ASKPASS" && '
            f'GIT_ASKPASS="$ASKPASS" git clone'
            f" {shlex.quote(clean_https_url)} {q_app_dir} && "
            f"cd {q_app_dir} && git remote set-url origin"
            f" {shlex.quote(ssh_clone_url)}"
        )
        askpass_script = f"#!/bin/sh\necho {shlex.quote(token)}"
        try:
            subprocess.run(
                ["ssh", ssh_host, remote_script],
                input=askpass_script,
                check=True,
                capture_output=True,
                text=True,
                timeout=300,
            )
        except subprocess.CalledProcessError as exc:
            raise SetupError(f"Failed to clone repository: {exc.stderr}") from exc
    else:
        # Fall back to SSH clone (requires SSH key on prod)
        clone_cmd = f"git clone {shlex.quote(ssh_clone_url)} {q_app_dir}"
        try:
            subprocess.run(
                ["ssh", ssh_host, clone_cmd],
                check=True,
                capture_output=True,
                text=True,
                timeout=300,
            )
        except subprocess.CalledProcessError as exc:
            raise SetupError(f"Failed to clone repository: {exc.stderr}") from exc

    # Copy production .env to app directory (overwrite staging .env from repo)
    try:
        subprocess.run(
            ["ssh", ssh_host, f"cp {q_site_env} {q_app_env}"],
            check=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to copy .env to app: {exc.stderr}") from exc


def _setup_venv_on_prod(site_slug: str, config: SystemConfig) -> None:
    """Create venv and install dependencies on production."""
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")

    q_venv = shlex.quote(f"{site_dir}/venv")
    q_pip = shlex.quote(f"{site_dir}/venv/bin/pip")
    q_requirements = shlex.quote(f"{site_dir}/app/requirements.txt")
    commands = [
        f"python3 -m venv {q_venv}",
        f"{q_pip} install -r {q_requirements} -q",
    ]

    for cmd in commands:
        try:
            subprocess.run(
                ["ssh", ssh_host, cmd],
                check=True,
                capture_output=True,
                text=True,
                timeout=600,
            )
        except subprocess.CalledProcessError as exc:
            raise SetupError(f"Failed to setup venv: {exc.stderr}") from exc


def _restore_db_on_prod(
    site_slug: str,
    remote_backup_path: str,
    config: SystemConfig,
    *,
    db_port: int | None = None,
) -> None:
    """Restore database from backup on production.

    Args:
        site_slug: Site identifier.
        remote_backup_path: Path to backup file on production.
        config: System configuration.
        db_port: Port for the isolated PostgreSQL cluster. If None, omits -p flag.
    """
    ssh_host = config.production.ssh_host
    db_name = config.get_db_name(site_slug)

    # Quote paths to prevent shell injection
    q_backup_path = shlex.quote(remote_backup_path)
    q_db_name = shlex.quote(db_name)

    port_flag = f" -p {shlex.quote(str(db_port))}" if db_port is not None else ""
    cmd = f"gunzip -c {q_backup_path} | sudo -u postgres psql{port_flag} {q_db_name}"

    try:
        subprocess.run(
            ["ssh", ssh_host, cmd],
            check=True,
            capture_output=True,
            text=True,
            timeout=600,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to restore database: {exc.stderr}") from exc


def _sync_media_to_prod(site_slug: str, config: SystemConfig) -> None:
    """Sync media files from staging to production."""
    ssh_host = config.production.ssh_host
    staging_dir = config.get_site_dir(site_slug, target="staging")
    prod_dir = config.get_site_dir(site_slug, target="prod")

    staging_media = staging_dir / "media"
    if not staging_media.exists():
        OutputFormatter.warning("No media directory on staging, skipping sync")
        return

    try:
        subprocess.run(
            [
                "rsync",
                "-avz",
                "--delete",
                f"{staging_media}/",
                f"{ssh_host}:{prod_dir}/media/",
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=600,
        )
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr or ""
        if isinstance(stderr, bytes):
            stderr = stderr.decode(errors="replace")
        raise SetupError(f"Failed to sync media: {stderr}") from exc


def _run_django_setup_on_prod(site_slug: str, config: SystemConfig) -> None:
    """Run Django migrations and collectstatic on production."""
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")

    q_app_dir = shlex.quote(f"{site_dir}/app")
    q_venv_python = shlex.quote(f"{site_dir}/venv/bin/python")
    commands = [
        f"cd {q_app_dir} && {q_venv_python} manage.py migrate --noinput",
        f"cd {q_app_dir} && {q_venv_python} manage.py collectstatic --noinput",
    ]

    for cmd in commands:
        try:
            subprocess.run(
                ["ssh", ssh_host, cmd],
                check=True,
                capture_output=True,
                text=True,
                timeout=300,
            )
        except subprocess.CalledProcessError as exc:
            raise SetupError(f"Django setup failed: {exc.stderr}") from exc


def _install_systemd_on_prod(site_slug: str, domain: str, config: SystemConfig) -> None:
    """Install systemd service on production."""
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")
    service_name = config.get_systemd_service_name(site_slug)
    python_package = site_slug.replace("-", "_")
    deploy_user = config.defaults.deploy_user

    # Read local template and substitute
    template_path = config.templates.systemd_path
    if not template_path.exists():
        raise SetupError(f"Systemd template not found: {template_path}")

    template_content = template_path.read_text()
    service_content = template_content.replace("__SITE_SLUG__", site_slug)
    service_content = service_content.replace("__DEPLOY_USER__", deploy_user)
    service_content = service_content.replace("__PROJECT_MODULE__", python_package)
    service_content = service_content.replace("__SITE_DIR__", str(site_dir))

    # Write service file via SSH using sudo tee (stdin → file).
    # Suppress tee stdout so file contents don't transit SSH twice.
    service_path = f"/etc/systemd/system/{service_name}.service"
    try:
        subprocess.run(
            ["ssh", ssh_host, f"sudo tee {shlex.quote(service_path)} > /dev/null"],
            check=True,
            capture_output=True,
            text=True,
            input=service_content,
            timeout=60,
        )
        subprocess.run(
            ["ssh", ssh_host, "sudo", "systemctl", "daemon-reload"],
            check=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
        subprocess.run(
            ["ssh", ssh_host, "sudo", "systemctl", "enable", service_name],
            check=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to install systemd service: {exc.stderr}") from exc


def _configure_caddy_on_prod(site_slug: str, domain: str, config: SystemConfig) -> None:
    """Configure Caddy on production."""
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")
    config_name = config.get_caddy_config_name(site_slug)

    # Read local template and substitute
    template_path = config.templates.caddy_path
    if not template_path.exists():
        raise SetupError(f"Caddy template not found: {template_path}")

    template_content = template_path.read_text()
    caddy_content = template_content.replace("__SITE_SLUG__", site_slug)
    caddy_content = caddy_content.replace("__DOMAIN__", domain)
    caddy_content = caddy_content.replace("__SITE_DIR__", str(site_dir))

    # Write Caddy config via SSH using sudo tee (stdin → file)
    caddy_path = f"/etc/caddy/sites-enabled/{config_name}"
    try:
        subprocess.run(
            ["ssh", ssh_host, "sudo", "mkdir", "-p", "/etc/caddy/sites-enabled"],
            check=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
        subprocess.run(
            ["ssh", ssh_host, f"sudo tee {shlex.quote(caddy_path)} > /dev/null"],
            check=True,
            capture_output=True,
            text=True,
            input=caddy_content,
            timeout=60,
        )
        subprocess.run(
            ["ssh", ssh_host, "sudo", "systemctl", "reload", "caddy"],
            check=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to configure Caddy: {exc.stderr}") from exc


def _write_site_config_on_prod(
    site_slug: str, config: SystemConfig, site_config: SiteConfig
) -> None:
    """Write .sum/config.yml on production server via SSH."""
    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")

    # Build YAML matching SiteConfig.save() format
    data: dict = {
        "site": {
            "slug": site_config.slug,
            "theme": site_config.theme,
            "created": site_config.created.isoformat(),
        },
        "git": None,
    }

    if site_config.git:
        git_data: dict = {
            "provider": site_config.git.provider,
            "org": site_config.git.org,
        }
        if site_config.git.url:
            git_data["url"] = site_config.git.url
        if site_config.git.ssh_port != 22:
            git_data["ssh_port"] = site_config.git.ssh_port
        if site_config.git.token_env != "GITEA_TOKEN":
            git_data["token_env"] = site_config.git.token_env
        data["git"] = git_data

    yaml_content = yaml.dump(data, default_flow_style=False, sort_keys=False)

    try:
        subprocess.run(
            ["ssh", ssh_host, "mkdir", "-p", str(site_dir / ".sum")],
            check=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
        subprocess.run(
            [
                "ssh",
                ssh_host,
                f"tee {shlex.quote(str(site_dir / '.sum' / 'config.yml'))} > /dev/null",
            ],
            check=True,
            capture_output=True,
            text=True,
            input=yaml_content,
            timeout=30,
        )
        subprocess.run(
            [
                "ssh",
                ssh_host,
                "chmod",
                "644",
                str(site_dir / ".sum" / "config.yml"),
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to write site config: {exc.stderr}") from exc


def _start_service_on_prod(site_slug: str, config: SystemConfig) -> None:
    """Start the site service on production."""
    ssh_host = config.production.ssh_host
    service_name = config.get_systemd_service_name(site_slug)

    try:
        subprocess.run(
            ["ssh", ssh_host, "sudo", "systemctl", "start", service_name],
            check=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to start service: {exc.stderr}") from exc


def _configure_remote_wal_archiving(
    site_slug: str,
    db_port: int,
    config: SystemConfig,
) -> None:
    """Configure WAL archiving in the production cluster's postgresql.conf via SSH.

    Appends WAL settings (wal_level, archive_mode, archive_command) to the
    cluster's postgresql.conf, restarts the cluster, and waits for readiness.
    Idempotent: skips if WAL archiving marker already present.

    Must be called AFTER stanza config + stanza-create so that the archive
    command targets an initialised stanza (prevents pg_wal filling up on
    failure).

    Args:
        site_slug: Site identifier.
        db_port: Port for the isolated PostgreSQL cluster.
        config: System configuration.

    Raises:
        SetupError: If configuration fails.
    """
    if not config.backups:
        return

    ssh_host = config.production.ssh_host
    postgres_version = DEFAULT_POSTGRES_VERSION
    if config.infrastructure:
        postgres_version = config.infrastructure.postgres_version

    archive_timeout = 300
    if config.infrastructure:
        archive_timeout = config.infrastructure.archive_timeout

    # Defense-in-depth: validate path components before embedding in shell commands
    _validate_safe_path(site_slug, "site slug")
    _validate_safe_path(postgres_version, "postgres version")

    q_slug = shlex.quote(site_slug)
    q_version = shlex.quote(postgres_version)
    conf_path = f"/etc/postgresql/{postgres_version}/{site_slug}/postgresql.conf"
    q_conf_path = shlex.quote(conf_path)
    config_include_path = str(config.get_pgbackrest_config_dir())

    # B1: Validate config path before embedding in archive_command
    _validate_safe_path(config_include_path, "pgbackrest config path")

    # Idempotency: check if WAL archiving is already configured
    try:
        result = subprocess.run(
            ["ssh", ssh_host, f"sudo grep -q 'pgbackrest.*archive-push' {q_conf_path}"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            OutputFormatter.info(f"WAL archiving already configured for {site_slug}")
            return
    except subprocess.SubprocessError as exc:
        # Assume WAL archiving not yet configured and attempt to configure it.
        OutputFormatter.warning(
            f"Cannot check WAL archiving status on {ssh_host}: {exc}"
        )

    # Build WAL config block — piped via stdin to avoid printf interpreting %p
    # site_slug and config_include_path are embedded raw below; both were
    # validated against _SAFE_PATH_RE earlier in this function.
    wal_config = (
        "\n# WAL archiving for pgBackRest (added by SUM Platform)\n"
        "wal_level = replica\n"
        "archive_mode = on\n"
        f"archive_command = '{DEFAULT_PGBACKREST_WRAPPER} --config-include-path={config_include_path}"
        f" --stanza={site_slug} archive-push %p'\n"
        f"archive_timeout = {archive_timeout}\n"
    )

    # N2: Append via tee -a (stdin) instead of printf (avoids % format issues)
    try:
        subprocess.run(
            ["ssh", ssh_host, f"sudo tee -a {q_conf_path} > /dev/null"],
            input=wal_config,
            check=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to configure WAL archiving on production: {exc.stderr}"
        ) from exc

    # Restart cluster to apply WAL settings
    try:
        subprocess.run(
            [
                "ssh",
                ssh_host,
                f"sudo pg_ctlcluster --skip-systemctl-redirect {q_version} {q_slug} restart",
            ],
            check=True,
            capture_output=True,
            text=True,
            timeout=60,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to restart PostgreSQL cluster after WAL config: {exc.stderr}"
        ) from exc

    # Wait for cluster to be ready again
    q_port = shlex.quote(str(db_port))
    deadline = time.time() + 60
    while time.time() < deadline:
        try:
            result = subprocess.run(
                ["ssh", ssh_host, f"pg_isready -p {q_port}"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                break
        except (subprocess.TimeoutExpired, subprocess.SubprocessError):
            # Transient SSH/pg_isready failures expected during cluster restart;
            # retry until deadline.
            pass
        time.sleep(2)
    else:
        raise SetupError(
            "PostgreSQL on production did not become ready after WAL archiving config"
        )


def _configure_remote_pgbackrest(
    site_slug: str,
    db_port: int,
    config: SystemConfig,
) -> None:
    """Write pgBackRest stanza config and create stanza on production via SSH.

    Reads the stanza template locally, renders it, writes to production via SSH,
    then runs stanza-create. Each sub-step has its own idempotency check so a
    partial failure can be resumed without repeating completed work.

    Does NOT run the initial backup — that must happen after WAL archiving is
    configured (see _run_remote_initial_backup).

    Args:
        site_slug: Site identifier.
        db_port: Port for the isolated PostgreSQL cluster.
        config: System configuration.

    Raises:
        SetupError: If configuration fails.
    """
    if not config.backups:
        return

    ssh_host = config.production.ssh_host
    config_include_path = str(config.get_pgbackrest_config_dir())
    q_config_dir = shlex.quote(config_include_path)
    q_slug = shlex.quote(site_slug)
    stanza_file = f"{config_include_path}/{site_slug}.conf"
    q_stanza_file = shlex.quote(stanza_file)

    # Get infrastructure settings
    postgres_version = DEFAULT_POSTGRES_VERSION
    if config.infrastructure:
        postgres_version = config.infrastructure.postgres_version

    if config.infrastructure and config.infrastructure.pgbackrest:
        compress_type = config.infrastructure.pgbackrest.compress_type
        compress_level = config.infrastructure.pgbackrest.compress_level
        process_max = config.infrastructure.pgbackrest.process_max
    else:
        compress_type = "zst"
        compress_level = 3
        process_max = 2

    # Read template locally if available, otherwise build config directly
    stanza_content: str | None = None
    if config.templates.pgbackrest_stanza_path:
        template_path = config.templates.pgbackrest_stanza_path
        if template_path.exists():
            try:
                content = template_path.read_text()
                replacements = {
                    "__SITE_SLUG__": site_slug,
                    "__POSTGRES_VERSION__": postgres_version,
                    "__POSTGRES_PORT__": str(db_port),
                    "__DB_USER__": config.get_db_user(site_slug),
                    "__BACKUP_KEY_PATH__": config.backups.storage_box.ssh_key,
                    "__STORAGE_BOX_HOST__": config.backups.storage_box.host,
                    "__STORAGE_BOX_USER__": config.backups.storage_box.user,
                    "__STORAGE_BOX_PORT__": str(config.backups.storage_box.port),
                    "__STORAGE_BOX_FINGERPRINT__": config.backups.storage_box.fingerprint,
                    "__STORAGE_BOX_BASE_PATH__": f"{config.backups.storage_box.base_path}/prod",
                    "__RETENTION_FULL__": str(config.backups.retention.full_backups),
                    "__RETENTION_DIFF__": str(config.backups.retention.diff_backups),
                    "__COMPRESS_TYPE__": compress_type,
                    "__COMPRESS_LEVEL__": str(compress_level),
                    "__PROCESS_MAX__": str(process_max),
                }
                for placeholder, value in replacements.items():
                    content = content.replace(placeholder, value)
                stanza_content = content
            except OSError as exc:
                raise SetupError(f"Failed to read pgBackRest template: {exc}") from exc

    if stanza_content is None:
        raise SetupError(
            "pgBackRest stanza template not configured or not found. "
            "Set templates.pgbackrest_stanza in /etc/sum/config.yml."
        )

    # Install pgbackrest wrapper on production so the cipher passphrase
    # is injected via environment variable rather than stanza config files.
    # Uses stdin piping (same pattern as stanza config) to avoid shell-escaping bugs.
    q_wrapper = shlex.quote(DEFAULT_PGBACKREST_WRAPPER)
    wrapper_script = render_pgbackrest_wrapper_script(config.backups.cipher_pass_file)
    try:
        subprocess.run(
            [
                "ssh",
                ssh_host,
                f"sudo tee {q_wrapper}.tmp > /dev/null"
                f" && sudo chown root:postgres {q_wrapper}.tmp"
                f" && sudo chmod 750 {q_wrapper}.tmp"
                f" && sudo mv {q_wrapper}.tmp {q_wrapper}",
            ],
            input=wrapper_script,
            check=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except subprocess.SubprocessError as exc:
        stderr = getattr(exc, "stderr", None) or str(exc)
        raise SetupError(
            f"Failed to install pgbackrest wrapper on production: {stderr}"
        ) from exc

    # B3: Granular idempotency — check stanza config file separately
    stanza_file_exists = False
    try:
        result = subprocess.run(
            ["ssh", ssh_host, f"test -f {q_stanza_file}"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        stanza_file_exists = result.returncode == 0
    except subprocess.SubprocessError as exc:
        # Assume file does not exist and attempt to create it.
        OutputFormatter.warning(
            f"Cannot check pgBackRest stanza config on {ssh_host}: {exc}"
        )

    if stanza_file_exists:
        OutputFormatter.info(f"pgBackRest stanza config already exists for {site_slug}")
    else:
        # Write stanza config to production via SSH
        try:
            subprocess.run(
                [
                    "ssh",
                    ssh_host,
                    f"sudo mkdir -p {q_config_dir}"
                    f" && sudo tee {q_stanza_file} > /dev/null"
                    f" && sudo chown postgres:postgres {q_stanza_file}"
                    f" && sudo chmod 640 {q_stanza_file}",
                ],
                input=stanza_content,
                check=True,
                capture_output=True,
                text=True,
                timeout=30,
            )
        except subprocess.CalledProcessError as exc:
            raise SetupError(
                f"Failed to write pgBackRest stanza config on production: {exc.stderr}"
            ) from exc

    # B3: Granular idempotency — check if stanza is already initialised
    stanza_initialised = False
    try:
        result = subprocess.run(
            [
                "ssh",
                ssh_host,
                f"sudo -u postgres {q_wrapper}"
                f" --config-include-path={q_config_dir}"
                f" --stanza={q_slug} info",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        stanza_initialised = (
            result.returncode == 0 and "missing stanza" not in result.stdout.lower()
        )
    except subprocess.SubprocessError as exc:
        # Assume stanza not initialised and attempt stanza-create.
        OutputFormatter.warning(f"Cannot verify stanza status on {ssh_host}: {exc}")

    if stanza_initialised:
        OutputFormatter.info(f"pgBackRest stanza already initialised for {site_slug}")
    else:
        # Run stanza-create
        try:
            subprocess.run(
                [
                    "ssh",
                    ssh_host,
                    f"sudo -u postgres {q_wrapper}"
                    f" --config-include-path={q_config_dir}"
                    f" --stanza={q_slug} stanza-create",
                ],
                check=True,
                capture_output=True,
                timeout=120,
            )
        except subprocess.CalledProcessError as exc:
            stdout = (
                exc.stdout.decode("utf-8", errors="replace")
                if isinstance(exc.stdout, bytes)
                else (exc.stdout or "")
            )
            stderr = (
                exc.stderr.decode("utf-8", errors="replace")
                if isinstance(exc.stderr, bytes)
                else (exc.stderr or "")
            )
            error_output = stdout or stderr or "No error output"
            raise SetupError(
                f"Failed to create pgBackRest stanza on production:\n{error_output}"
            ) from exc


def _run_remote_initial_backup(
    site_slug: str,
    config: SystemConfig,
) -> None:
    """Run initial full backup on production via SSH.

    Must be called AFTER stanza-create and WAL archiving are configured.
    Idempotent: skips if a backup already exists for this stanza.

    Args:
        site_slug: Site identifier.
        config: System configuration.

    Raises:
        SetupError: If backup fails.
    """
    if not config.backups:
        return

    ssh_host = config.production.ssh_host
    config_include_path = str(config.get_pgbackrest_config_dir())
    q_config_dir = shlex.quote(config_include_path)
    q_slug = shlex.quote(site_slug)
    q_wrapper = shlex.quote(DEFAULT_PGBACKREST_WRAPPER)

    # B3: Granular idempotency — check if a backup already exists
    try:
        result = subprocess.run(
            [
                "ssh",
                ssh_host,
                f"sudo -u postgres {q_wrapper}"
                f" --config-include-path={q_config_dir}"
                f" --stanza={q_slug} info --output=json",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            info = json.loads(result.stdout)
            if info and info[0].get("backup"):
                OutputFormatter.info(f"Backup already exists for stanza {site_slug}")
                return
    except (
        subprocess.SubprocessError,
        json.JSONDecodeError,
        KeyError,
        IndexError,
    ) as exc:
        # Assume no backup exists and attempt initial backup.
        OutputFormatter.warning(f"Cannot verify backup status on {ssh_host}: {exc}")

    # Run initial full backup
    try:
        subprocess.run(
            [
                "ssh",
                ssh_host,
                f"sudo -u postgres {q_wrapper}"
                f" --config-include-path={q_config_dir}"
                f" --stanza={q_slug} --type=full backup",
            ],
            check=True,
            capture_output=True,
            timeout=600,
        )
    except subprocess.CalledProcessError as exc:
        stdout = (
            exc.stdout.decode("utf-8", errors="replace")
            if isinstance(exc.stdout, bytes)
            else (exc.stdout or "")
        )
        stderr = (
            exc.stderr.decode("utf-8", errors="replace")
            if isinstance(exc.stderr, bytes)
            else (exc.stderr or "")
        )
        error_output = stdout or stderr or "No error output"
        raise SetupError(
            f"Failed to run initial backup on production:\n{error_output}"
        ) from exc


def _install_remote_backup_cron(
    site_slug: str,
    config: SystemConfig,
) -> None:
    """Install backup cron entries on production via SSH.

    Adds staggered full (Sunday) and differential (Mon-Sat) backup cron entries
    to /etc/cron.d/sum-backups on production. Idempotent: skips if site's
    marker comment already exists.

    Args:
        site_slug: Site identifier.
        config: System configuration.

    Raises:
        SetupError: If cron installation fails.
    """
    if not config.backups:
        return

    ssh_host = config.production.ssh_host
    cron_file = "/etc/cron.d/sum-backups"
    q_cron_file = shlex.quote(cron_file)
    config_include_path = str(config.get_pgbackrest_config_dir())
    site_dir = str(config.get_site_dir(site_slug, target="prod"))

    # W2: Validate path components before embedding in cron commands
    _validate_safe_path(config_include_path, "pgbackrest config path")
    _validate_safe_path(site_slug, "site slug")

    q_config = shlex.quote(config_include_path)
    q_slug = shlex.quote(site_slug)
    q_marker = shlex.quote(f"{site_dir}/backup_status")

    # Idempotency: check if site marker already exists in cron file
    marker = f"# {site_slug}"
    try:
        result = subprocess.run(
            [
                "ssh",
                ssh_host,
                f"sudo grep -qF {shlex.quote(marker)} {q_cron_file} 2>/dev/null",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            OutputFormatter.info(f"Backup cron already configured for {site_slug}")
            return
    except subprocess.SubprocessError as exc:
        # Assume cron file doesn't exist yet and attempt to create it.
        OutputFormatter.warning(f"Cannot check backup cron on {ssh_host}: {exc}")

    minute = get_staggered_minute(site_slug)
    q_wrapper = shlex.quote(DEFAULT_PGBACKREST_WRAPPER)

    cron_entries = (
        f"# {site_slug}\n"
        f"{minute} 2 * * 0 root bash -o pipefail -c"
        f" 'sudo -u postgres {q_wrapper} --config-include-path={q_config}"
        f" --stanza={q_slug} backup --type=full 2>&1"
        f" | logger -t sum-backup-{q_slug}'"
        f" && date +\\%s > {q_marker}\n"
        f"{minute} 2 * * 1-6 root bash -o pipefail -c"
        f" 'sudo -u postgres {q_wrapper} --config-include-path={q_config}"
        f" --stanza={q_slug} backup --type=diff 2>&1"
        f" | logger -t sum-backup-{q_slug}'"
        f" && date +\\%s > {q_marker}\n"
    )

    # N5: Append cron entries under flock to prevent concurrent promote interleaving
    try:
        subprocess.run(
            [
                "ssh",
                ssh_host,
                f"sudo flock {q_cron_file} tee -a {q_cron_file} > /dev/null",
            ],
            input=cron_entries,
            check=True,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to install backup cron on production: {exc.stderr}"
        ) from exc


def _classify_health_failure(
    domain: str,
    returncode: int | None,
    stderr: str | None,
) -> str:
    """Return a human-readable reason for a failed health check."""
    stderr = (stderr or "").strip().lower()

    if "could not resolve host" in stderr or "name or service not known" in stderr:
        return f"DNS resolution failed for {domain}"
    if "connection refused" in stderr:
        return "Connection refused (service may not be listening)"
    if "ssl certificate problem" in stderr or "tls" in stderr:
        return "SSL/TLS error"
    if "operation timed out" in stderr or "timed out" in stderr:
        return "Timeout after 10 seconds"
    if "server returned nothing" in stderr:
        return "Server returned no data"
    if stderr:
        return f"curl error: {stderr[:100]}"
    return f"Unknown error (exit code {returncode})"


def _verify_health(domain: str) -> bool:
    """Verify the site is responding on production.

    Returns True if healthy, False otherwise. Logs failure reason.
    """
    try:
        result = subprocess.run(
            ["curl", "-fsS", f"https://{domain}/health/", "--max-time", "10"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            return True

        reason = _classify_health_failure(domain, result.returncode, result.stderr)
        OutputFormatter.warning(f"Health check failed: {reason}")
        return False
    except subprocess.SubprocessError as exc:
        OutputFormatter.warning(f"Health check failed: {exc}")
        return False


def _cleanup_prod_on_failure(
    completed_steps: list[str],
    site_slug: str,
    config: SystemConfig,
) -> None:
    """Best-effort cleanup of production resources after a failed promote.

    Reverses completed steps in reverse order. Never raises — errors are
    logged and a recovery runbook is printed to stderr if any cleanup fails.
    """
    if not completed_steps:
        return

    ssh_host = config.production.ssh_host
    site_dir = config.get_site_dir(site_slug, target="prod")
    service_name = config.get_systemd_service_name(site_slug)
    caddy_config = config.get_caddy_config_name(site_slug)

    # Map step names to cleanup commands (reverse order)
    cleanup_actions: list[tuple[str, str, list[str]]] = []

    if "start_service" in completed_steps:
        cleanup_actions.append(
            (
                "stop_service",
                "Stopping service",
                ["ssh", ssh_host, "sudo", "systemctl", "stop", service_name],
            )
        )

    if "install_systemd" in completed_steps:
        cleanup_actions.append(
            (
                "remove_systemd",
                "Removing systemd service",
                [
                    "ssh",
                    ssh_host,
                    f"sudo systemctl disable {shlex.quote(service_name)} && "
                    f"sudo rm -f {shlex.quote(f'/etc/systemd/system/{service_name}.service')} && "
                    "sudo systemctl daemon-reload",
                ],
            )
        )

    if "configure_caddy" in completed_steps:
        cleanup_actions.append(
            (
                "remove_caddy",
                "Removing Caddy config",
                [
                    "ssh",
                    ssh_host,
                    f"sudo rm -f {shlex.quote(f'/etc/caddy/sites-enabled/{caddy_config}')} && "
                    "sudo systemctl reload caddy",
                ],
            )
        )

    if "configure_backups" in completed_steps:
        config_include_path = str(config.get_pgbackrest_config_dir())
        q_stanza_file = shlex.quote(f"{config_include_path}/{site_slug}.conf")
        cleanup_actions.append(
            (
                "remove_stanza_config",
                "Removing pgBackRest stanza config",
                [
                    "ssh",
                    ssh_host,
                    f"sudo rm -f {q_stanza_file}",
                ],
            )
        )

    if "provision_infra" in completed_steps:
        # Get postgres version for cluster cleanup
        postgres_version = DEFAULT_POSTGRES_VERSION
        if config.infrastructure:
            postgres_version = config.infrastructure.postgres_version
        q_slug = shlex.quote(site_slug)
        q_version = shlex.quote(postgres_version)

        cleanup_actions.append(
            (
                "remove_directories",
                "Removing site directories",
                ["ssh", ssh_host, "rm", "-rf", str(site_dir)],
            )
        )
        cleanup_actions.append(
            (
                "drop_cluster",
                "Dropping PostgreSQL cluster",
                [
                    "ssh",
                    ssh_host,
                    f"sudo pg_ctlcluster --skip-systemctl-redirect {q_version} {q_slug} stop 2>/dev/null; "
                    f"sudo pg_dropcluster {q_version} {q_slug} 2>/dev/null; true",
                ],
            )
        )

    OutputFormatter.warning("Cleaning up partial production deployment...")
    failed_cleanups: list[str] = []

    for _action_name, description, cmd in cleanup_actions:
        try:
            OutputFormatter.info(f"  {description}...")
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60,
            )
            if result.returncode != 0:
                stderr = (result.stderr or "").strip()
                stdout = (result.stdout or "").strip()
                details = stderr or stdout or f"exit code {result.returncode}"
                failed_cleanups.append(f"{description}: {details}")
        except (subprocess.SubprocessError, OSError) as exc:
            failed_cleanups.append(f"{description}: {exc}")

    # Best-effort port deallocation (outside the actions loop)
    if "provision_infra" in completed_steps:
        try:
            _deallocate_remote_port(site_slug, config)
        except (subprocess.SubprocessError, OSError):
            failed_cleanups.append("Deallocate remote port: failed")

    if failed_cleanups:
        # Get postgres version for runbook
        postgres_version = DEFAULT_POSTGRES_VERSION
        if config.infrastructure:
            postgres_version = config.infrastructure.postgres_version

        # Print recovery runbook to stderr
        print("\n--- MANUAL RECOVERY REQUIRED ---", file=sys.stderr)
        print(
            f"Some cleanup steps failed on {ssh_host}. " "Run these commands manually:",
            file=sys.stderr,
        )
        print(f"  sudo systemctl stop {service_name}", file=sys.stderr)
        print(
            f"  sudo systemctl disable {service_name}",
            file=sys.stderr,
        )
        print(
            f"  sudo rm -f /etc/systemd/system/{service_name}.service",
            file=sys.stderr,
        )
        print("  sudo systemctl daemon-reload", file=sys.stderr)
        print(
            f"  sudo rm -f /etc/caddy/sites-enabled/{caddy_config}",
            file=sys.stderr,
        )
        print("  sudo systemctl reload caddy", file=sys.stderr)
        config_include_path = str(config.get_pgbackrest_config_dir())
        print(
            f"  sudo rm -f {config_include_path}/{site_slug}.conf",
            file=sys.stderr,
        )
        print(f"  rm -rf {site_dir}", file=sys.stderr)
        print(
            f"  sudo pg_ctlcluster --skip-systemctl-redirect {postgres_version} {site_slug} stop",
            file=sys.stderr,
        )
        print(
            f"  sudo pg_dropcluster {postgres_version} {site_slug}",
            file=sys.stderr,
        )
        print(
            f'  # Edit /etc/sum/ports.json on production and remove the "{site_slug}" entry',
            file=sys.stderr,
        )
        print("--- END RECOVERY RUNBOOK ---\n", file=sys.stderr)
    else:
        OutputFormatter.info("Cleanup completed successfully.")


def run_promote(
    site_name: str,
    *,
    domain: str,
    dry_run: bool = False,
    skip_confirm: bool = False,
    skip_preflight: bool = False,
) -> int:
    """Promote a staging site to production.

    Orchestrates a multi-step workflow:
      1. Validate inputs and check SSH connectivity
      2. Create staging database backup
      3. Provision production infrastructure (isolated Postgres cluster,
         systemd service, Caddy reverse proxy)
      4-11. Deploy application, restore database, start service
      12. Configure pgBackRest and WAL archiving (if backups configured)
      13. Install backup cron schedule (if backups configured)
      14. Write site config

    Steps 12-13 are only executed when config.backups is configured.

    Args:
        site_name: Name/slug of the site to promote.
        domain: Production domain for the site.
        dry_run: If True, preview steps without executing.
        skip_confirm: If True, skip confirmation prompt.

    Returns:
        Exit code (0 for success, non-zero for failure).
    """
    # Validate inputs before any operations
    try:
        validate_site_slug(site_name)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    try:
        validate_domain(domain)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # Pre-flight checks (phase 1: config-independent)
    early_results: list = []
    if not skip_preflight:
        runner = PreflightRunner()
        runner.register(SystemConfigCheck())
        early_results = runner.run()
        if not PreflightRunner.is_go(early_results):
            print(PreflightRunner.format_results(early_results))
            OutputFormatter.error("Pre-flight checks failed. Aborting.")
            return 1

    try:
        config = get_system_config()
    except ConfigurationError as exc:
        OutputFormatter.error(str(exc))
        return 1

    staging_dir = config.get_site_dir(site_name, target="staging")

    # Validate staging site exists
    if not staging_dir.exists():
        OutputFormatter.error(f"Staging site not found: {staging_dir}")
        return 1

    # Load site config to get git settings
    try:
        site_config = SiteConfig.load(staging_dir)
    except SiteConfigError as exc:
        OutputFormatter.error(str(exc))
        return 1

    if site_config.git is None:
        OutputFormatter.error(
            f"Site '{site_name}' was created with --no-git. "
            "Cannot promote without git repository."
        )
        return 1

    git_config = site_config.git

    # Pre-flight checks (phase 2: config-dependent)
    if not skip_preflight:
        runner2 = PreflightRunner()
        staging_base = str(config.staging.base_dir)
        runner2.register(SiteExistsCheck(site_name, base_dir=staging_base))
        runner2.register(PostgresClusterCheck(site_name))
        runner2.register(SSHConnectivityCheck(config.production.ssh_host))
        runner2.register(DiskSpaceCheck(path=staging_base, min_gb=2))
        if git_config.provider == "gitea":
            runner2.register(GiteaTokenCheck(env_var=git_config.token_env))
            runner2.register(
                GiteaRepoCheck(
                    git_config.org or "",
                    site_name,
                    git_config.url or "",
                    token_env=git_config.token_env,
                )
            )
        if config.backups:
            cipher_pass = getattr(config.backups, "cipher_pass_file", None)
            if cipher_pass:
                runner2.register(CipherPassFileCheck(cipher_pass))
            pgbackrest_conf_dir = str(config.get_pgbackrest_config_dir())
            runner2.register(PgBackRestStanzaCheck(site_name, pgbackrest_conf_dir))
        late_results = runner2.run()
        all_results = early_results + late_results
        print(PreflightRunner.format_results(all_results))
        if not PreflightRunner.is_go(late_results):
            OutputFormatter.error("Pre-flight checks failed. Aborting.")
            return 1

    # Detect GITEA_TOKEN before privilege escalation (hard requirement for promote)
    if git_config.provider == "gitea":
        token = detect_gitea_token(env_var=git_config.token_env)
        if not token:
            OutputFormatter.error(
                f"{git_config.token_env} not found in environment or "
                "~/.config/tea/config.yml.\n"
                "  Promote requires Gitea access to clone the repository.\n"
                f"  Export {git_config.token_env} and try again."
            )
            return 1

    # Dry-run mode: show planned steps and exit
    if dry_run:
        OutputFormatter.header(f"Dry run: promote {site_name} to {domain}")
        print()
        steps = [
            "Backup staging database",
            "Copy backup to production",
            f"Provision infrastructure (DB, dirs, .env)"
            f" on {config.production.ssh_host}",
            "Clone repository on production",
            "Setup virtualenv and install dependencies",
            "Restore database from backup",
            "Sync media files",
            "Run Django migrations and collectstatic",
            "Install systemd service",
            "Configure Caddy reverse proxy",
            "Start service",
        ]
        if config.backups:
            steps.extend(
                [
                    "Configure pgBackRest and WAL archiving",
                    "Install backup cron schedule",
                ]
            )
        steps.append("Write site config")
        for i, step in enumerate(steps, 1):
            print(f"  {i:2d}. {step}")
        print()
        OutputFormatter.info("No changes made (dry run)")
        return 0

    # Confirmation prompt (promote is irreversible)
    if not skip_confirm:
        print()
        OutputFormatter.warning(
            f"This will promote '{site_name}' to production at {domain}"
        )
        print(
            "  Steps: backup DB -> copy to prod -> provision infra"
            " -> clone -> restore -> start"
        )
        print()
        try:
            answer = input(f"Type '{site_name}' to confirm: ")
        except (EOFError, KeyboardInterrupt):
            print("\nAborted.")
            return 130
        if answer.strip() != site_name:
            OutputFormatter.error("Confirmation did not match. Aborting.")
            return 1

    # SSH preflight: verify connectivity before sudo so unreachable hosts
    # don't trigger a password prompt unnecessarily
    try:
        _check_ssh_connectivity(config)
    except SetupError as exc:
        OutputFormatter.error(str(exc))
        return 1

    # Require root — after validation/dry-run/confirm/SSH-check so invalid args,
    # --dry-run, and unreachable hosts don't trigger a sudo prompt
    require_root_or_escalate("promote", token_env=git_config.token_env)

    OutputFormatter.header(f"Promoting {site_name} to production")
    print(f"  Domain: {domain}")
    print()

    total_steps = 14 if config.backups else 12
    current_step = 0
    remote_backup: str | None = None
    completed_steps: list[str] = []

    try:
        # Step 1: Backup staging DB
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Backing up staging database", "⏳"
        )
        backup_path = _backup_staging_db(site_name, staging_dir, config)
        completed_steps.append("backup_db")
        OutputFormatter.progress(
            current_step, total_steps, f"Backup created: {backup_path.name}", "✅"
        )

        # Step 2: Copy backup to production
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Copying backup to production", "⏳"
        )
        remote_backup = _copy_backup_to_prod(backup_path, config)
        completed_steps.append("copy_backup")
        OutputFormatter.progress(
            current_step, total_steps, "Backup copied to production", "✅"
        )

        # Step 3: Provision infrastructure on production
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Provisioning production infrastructure", "⏳"
        )
        # Mark infra provisioning as started so rollback will attempt cleanup
        # even if _provision_prod_infrastructure fails part-way through.
        completed_steps.append("provision_infra")
        credentials = _provision_prod_infrastructure(site_name, domain, config)
        db_port = int(credentials["db_port"])
        OutputFormatter.progress(
            current_step, total_steps, "Infrastructure provisioned", "✅"
        )

        # Step 4: Clone repository on production
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Cloning repository on production", "⏳"
        )
        _clone_repo_on_prod(site_name, config, git_config)
        completed_steps.append("clone_repo")
        OutputFormatter.progress(current_step, total_steps, "Repository cloned", "✅")

        # Step 5: Setup venv on production
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Setting up virtualenv on production", "⏳"
        )
        _setup_venv_on_prod(site_name, config)
        completed_steps.append("setup_venv")
        OutputFormatter.progress(
            current_step, total_steps, "Virtualenv configured", "✅"
        )

        # Step 6: Restore database
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Restoring database on production", "⏳"
        )
        _restore_db_on_prod(site_name, remote_backup, config, db_port=db_port)
        completed_steps.append("restore_db")
        OutputFormatter.progress(current_step, total_steps, "Database restored", "✅")

        # Step 7: Sync media
        current_step += 1
        OutputFormatter.progress(current_step, total_steps, "Syncing media files", "⏳")
        _sync_media_to_prod(site_name, config)
        completed_steps.append("sync_media")
        OutputFormatter.progress(current_step, total_steps, "Media synced", "✅")

        # Step 8: Run Django setup
        current_step += 1
        OutputFormatter.progress(
            current_step,
            total_steps,
            "Running Django migrations and collectstatic",
            "⏳",
        )
        _run_django_setup_on_prod(site_name, config)
        completed_steps.append("django_setup")
        OutputFormatter.progress(
            current_step, total_steps, "Django setup complete", "✅"
        )

        # Step 9: Install systemd service
        current_step += 1
        OutputFormatter.progress(
            current_step, total_steps, "Installing systemd service", "⏳"
        )
        completed_steps.append("install_systemd")
        _install_systemd_on_prod(site_name, domain, config)
        OutputFormatter.progress(
            current_step, total_steps, "Systemd service installed", "✅"
        )

        # Step 10: Configure Caddy
        current_step += 1
        OutputFormatter.progress(current_step, total_steps, "Configuring Caddy", "⏳")
        completed_steps.append("configure_caddy")
        _configure_caddy_on_prod(site_name, domain, config)
        OutputFormatter.progress(current_step, total_steps, "Caddy configured", "✅")

        # Step 11: Start service
        current_step += 1
        OutputFormatter.progress(current_step, total_steps, "Starting service", "⏳")
        _start_service_on_prod(site_name, config)
        completed_steps.append("start_service")
        OutputFormatter.progress(current_step, total_steps, "Service started", "✅")

        # Steps 12-13: Backup infrastructure (only if backups configured)
        # W3: Backup config is intentionally NOT rolled back on failure.
        # The site is already running at this point — removing stanza config
        # or WAL archiving settings from a live cluster is riskier than leaving
        # partial backup config that can be fixed or completed manually.
        if config.backups:
            # Step 12: Configure pgBackRest stanza + WAL archiving
            # W4: Order matters — stanza config and stanza-create MUST happen
            # before WAL archiving is enabled. Otherwise archive_command targets
            # a non-existent stanza, pg_wal fills up, and the DB crashes.
            current_step += 1
            OutputFormatter.progress(
                current_step,
                total_steps,
                "Configuring pgBackRest and WAL archiving",
                "⏳",
            )
            _configure_remote_pgbackrest(site_name, db_port, config)
            _configure_remote_wal_archiving(site_name, db_port, config)
            _run_remote_initial_backup(site_name, config)
            completed_steps.append("configure_backups")
            OutputFormatter.progress(
                current_step,
                total_steps,
                "Backup infrastructure configured",
                "✅",
            )

            # Step 13: Install backup cron
            current_step += 1
            OutputFormatter.progress(
                current_step,
                total_steps,
                "Installing backup cron schedule",
                "⏳",
            )
            _install_remote_backup_cron(site_name, config)
            completed_steps.append("install_backup_cron")
            OutputFormatter.progress(
                current_step,
                total_steps,
                "Backup cron installed",
                "✅",
            )

    except SetupError as exc:
        OutputFormatter.error(str(exc))
        _cleanup_prod_on_failure(completed_steps, site_name, config)
        # Best-effort cleanup of remote backup temp directory on failure
        if remote_backup:
            try:
                remote_dir = str(Path(remote_backup).parent)
                subprocess.run(
                    ["ssh", config.production.ssh_host, "rm", "-rf", remote_dir],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
            except (subprocess.SubprocessError, OSError) as exc_cleanup:
                OutputFormatter.warning(
                    f"Failed to remove remote backup directory: {exc_cleanup}"
                )
        return 1

    # Final step: Write site config (non-fatal — deployment is already complete)
    try:
        current_step += 1
        OutputFormatter.progress(current_step, total_steps, "Writing site config", "⏳")
        _write_site_config_on_prod(site_name, config, site_config)
        completed_steps.append("write_site_config")
        OutputFormatter.progress(current_step, total_steps, "Site config written", "✅")
    except SetupError as exc:
        OutputFormatter.warning(f"Failed to write site config: {exc}")
        OutputFormatter.warning("Site is running but .sum/config.yml was not written.")
    finally:
        # Best-effort cleanup of remote backup temp directory
        if remote_backup:
            try:
                remote_dir = str(Path(remote_backup).parent)
                subprocess.run(
                    ["ssh", config.production.ssh_host, "rm", "-rf", remote_dir],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
            except (subprocess.SubprocessError, OSError) as exc:
                OutputFormatter.warning(
                    f"Failed to remove remote backup directory: {exc}"
                )

    print()

    # Verify health (optional, non-fatal)
    OutputFormatter.info("Verifying site health...")
    if _verify_health(domain):
        OutputFormatter.success(f"Site responding at https://{domain}")
    else:
        OutputFormatter.warning(
            f"Site not yet responding at https://{domain}/health/\n"
            "This may be normal if DNS is not yet configured."
        )

    print()
    OutputFormatter.success("Site promoted to production!")
    print()
    print(f"  Production URL:  https://{domain}")
    print(f"  Admin:           https://{domain}/admin/")
    print()
    staging_domain = config.get_site_domain(site_name)
    print(f"  Staging still available at: https://{staging_domain}")
    print()
    print(f"  Next: Ensure DNS for {domain} points to {config.production.ssh_host}")
    print()

    return 0


def _promote_command(
    site_name: str,
    domain: str,
    dry_run: bool = False,
    skip_confirm: bool = False,
    skip_preflight: bool = False,
) -> None:
    """Promote a staging site to production."""
    result = run_promote(
        site_name,
        domain=domain,
        dry_run=dry_run,
        skip_confirm=skip_confirm,
        skip_preflight=skip_preflight,
    )
    if result != 0:
        raise SystemExit(result)


def _missing_click(*_args: object, **_kwargs: object) -> None:
    raise RuntimeError("click is required to use the promote command")


if click is None:
    promote = _missing_click
else:

    @click.command(name="promote")
    @click.argument("site_name")
    @click.option(
        "--domain",
        required=True,
        help="Production domain for the site (e.g., acme-client.com).",
    )
    @click.option(
        "--dry-run",
        is_flag=True,
        help="Preview steps without executing.",
    )
    @click.option(
        "--confirm",
        "skip_confirm",
        is_flag=True,
        help="Skip confirmation prompt.",
    )
    @click.pass_context
    def _click_promote(
        ctx: click.Context,
        site_name: str,
        domain: str,
        dry_run: bool,
        skip_confirm: bool,
    ) -> None:
        """Promote a staging site to production.

        Takes a working staging site and deploys it to production with
        a custom domain. Handles database migration, media sync, and
        all infrastructure configuration.

        \b
        Steps performed:
        1. Backup staging database
        2. Copy backup to production
        3. Provision production infrastructure (DB, dirs, .env)
        4. Clone repository on production
        5. Setup venv and install dependencies
        6. Restore database
        7. Sync media files
        8. Run migrations and collectstatic
        9. Install systemd service
        10. Configure Caddy reverse proxy
        11. Start service
        12. Configure pgBackRest and WAL archiving (if backups configured)
        13. Install backup cron schedule (if backups configured)
        14. Write site config

        \b
        Examples:
          sum-platform promote acme --domain acme-client.com
          sum-platform promote acme --domain acme-client.com --dry-run
          sum-platform promote acme --domain acme-client.com --confirm
        """
        _promote_command(
            site_name,
            domain=domain,
            dry_run=dry_run,
            skip_confirm=skip_confirm,
            skip_preflight=(ctx.obj or {}).get("skip_preflight", False),
        )

    promote = _click_promote
