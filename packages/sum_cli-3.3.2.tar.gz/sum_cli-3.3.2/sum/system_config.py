"""System configuration for SUM Platform CLI.

Reads agency-specific settings from /etc/sum/config.yml.
All values MUST be provided in the config file - no defaults.
"""

from __future__ import annotations

import dataclasses
import logging
import os
import stat
import types
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Union, get_type_hints

import yaml
from sum.exceptions import SumCliError

# Default config file location
DEFAULT_CONFIG_PATH = Path("/etc/sum/config.yml")

# Environment variable override for config path (useful for testing/dev)
CONFIG_PATH_ENV_VAR = "SUM_CONFIG_PATH"

# Default cipher passphrase file for pgBackRest encryption
DEFAULT_CIPHER_PASS_FILE = "/etc/sum/cipher-passphrase"


class ConfigurationError(SumCliError):
    """Configuration file is missing or invalid."""

    pass


@dataclass
class AgencyConfig:
    """Agency identification settings."""

    name: str


@dataclass
class StagingConfig:
    """Staging server configuration."""

    server: str
    domain_pattern: str  # e.g., "{slug}.example.com"
    base_dir: str


@dataclass
class ProductionConfig:
    """Production server configuration."""

    server: str
    ssh_host: str
    base_dir: str


@dataclass
class TemplatesConfig:
    """Infrastructure template paths."""

    dir: str
    systemd: str
    caddy: str
    # pgBackRest stanza template for bare metal PostgreSQL
    pgbackrest_stanza: str | None = None

    @property
    def systemd_path(self) -> Path:
        """Full path to systemd template."""
        return Path(self.dir) / self.systemd

    @property
    def caddy_path(self) -> Path:
        """Full path to Caddy template."""
        return Path(self.dir) / self.caddy

    @property
    def pgbackrest_stanza_path(self) -> Path | None:
        """Full path to pgBackRest stanza template for bare metal."""
        if self.pgbackrest_stanza:
            return Path(self.dir) / self.pgbackrest_stanza
        return None


@dataclass
class PathsConfig:
    """Configurable paths for CLI operations.

    All paths have sensible defaults for standard Debian/Ubuntu systems,
    but can be overridden per-agency in config.yml.
    """

    # pgBackRest stanza config directory
    pgbackrest_config_dir: str = "/etc/pgbackrest/conf.d"

    # Port allocation files
    ports_file: str = "/etc/sum/ports.json"
    ports_lock_file: str = "/etc/sum/ports.lock"

    # PostgreSQL port range for managed clusters
    port_range_min: int = 5433
    port_range_max: int = 5532


@dataclass
class PgBackRestSettings:
    """pgBackRest-specific settings."""

    compress_type: str = "zst"
    compress_level: int = 3
    process_max: int = 2


@dataclass
class InfrastructureConfig:
    """Infrastructure version and settings configuration."""

    postgres_version: str = (
        "18"  # Major version for pg_createcluster (e.g., "17", "18")
    )
    archive_timeout: int = 300  # Seconds before PostgreSQL forces a WAL segment switch
    pgbackrest: PgBackRestSettings | None = None


@dataclass
class DefaultsConfig:
    """Default values for CLI operations."""

    theme: str
    deploy_user: str
    seed_profile: str
    postgres_port: int = 5432  # Default port, can be overridden in config


@dataclass
class StorageBoxConfig:
    """Hetzner Storage Box configuration."""

    host: str
    user: str
    fingerprint: str  # SHA256 host fingerprint for SFTP verification
    port: int = 23
    ssh_key: str = "/etc/sum/backup-key-rsa"
    base_path: str = "/backups"


@dataclass
class RetentionConfig:
    """Backup retention configuration."""

    full_backups: int = 2
    diff_backups: int = 7


@dataclass
class AlertsConfig:
    """Backup alerts configuration."""

    email: str
    smtp_host: str = "localhost"
    smtp_port: int = 25
    smtp_username: str = ""
    smtp_password_file: str = ""
    smtp_use_tls: bool = False
    from_address: str = "backup-monitor@localhost"

    @property
    def has_external_smtp(self) -> bool:
        """Whether an external SMTP relay is configured."""
        host = self.smtp_host.strip().lower().removesuffix(".")
        return host not in ("localhost", "127.0.0.1", "::1", "")

    def get_smtp_password(self) -> str:
        """Read SMTP password from file. Returns empty string if not configured or unreadable."""
        if not self.smtp_password_file:
            return ""
        path = Path(self.smtp_password_file)
        logger = logging.getLogger(__name__)
        try:
            mode = path.stat().st_mode
            if mode & stat.S_IROTH:
                logger.warning(
                    f"SMTP password file {path} is world-readable. "
                    f"Fix with: chmod 600 {path}"
                )
            return path.read_text().strip()
        except OSError:
            logger.warning(f"Cannot read SMTP password file: {self.smtp_password_file}")
            return ""


@dataclass
class BackupsConfig:
    """Backup infrastructure configuration."""

    storage_box: StorageBoxConfig
    retention: RetentionConfig
    alerts: AlertsConfig
    cipher_pass_file: str = DEFAULT_CIPHER_PASS_FILE


@dataclass
class SystemConfig:
    """Complete system configuration.

    Loaded from /etc/sum/config.yml. All values must be provided.
    """

    agency: AgencyConfig
    staging: StagingConfig
    production: ProductionConfig
    templates: TemplatesConfig
    defaults: DefaultsConfig
    infrastructure: InfrastructureConfig | None = None
    backups: BackupsConfig | None = None
    paths: PathsConfig | None = None

    _config_path: Path | None = None

    @classmethod
    def load(cls, config_path: Path | str | None = None) -> SystemConfig:
        """Load configuration from file.

        Args:
            config_path: Optional explicit path to config file.
                         If not provided, checks SUM_CONFIG_PATH env var,
                         then falls back to /etc/sum/config.yml.

        Returns:
            SystemConfig instance with loaded values.

        Raises:
            ConfigurationError: If config file is missing or invalid.
        """
        # Determine config path
        if config_path is None:
            env_path = os.environ.get(CONFIG_PATH_ENV_VAR)
            if env_path:
                config_path = Path(env_path)
            else:
                config_path = DEFAULT_CONFIG_PATH
        else:
            config_path = Path(config_path)

        # Config file is required
        if not config_path.exists():
            raise ConfigurationError(
                f"Configuration file not found: {config_path}\n\n"
                f"The SUM CLI requires a configuration file.\n"
                f"Create {config_path} with your agency settings.\n\n"
                f"See docs/dev/cli/USER_GUIDE.md for the required format."
            )

        return cls._load_from_file(config_path)

    @classmethod
    def _load_from_file(cls, config_path: Path) -> SystemConfig:
        """Load configuration from YAML file."""
        try:
            with open(config_path) as f:
                data = yaml.safe_load(f)
        except yaml.YAMLError as exc:
            raise ConfigurationError(
                f"Invalid YAML in configuration file {config_path}: {exc}"
            ) from exc

        if not data:
            raise ConfigurationError(f"Configuration file is empty: {config_path}")

        # Validate required sections
        required_sections = ["agency", "staging", "production", "templates", "defaults"]
        missing_sections = [s for s in required_sections if s not in data]
        if missing_sections:
            raise ConfigurationError(
                f"Missing required sections in {config_path}: {', '.join(missing_sections)}"
            )

        # Infrastructure section is optional (for backwards compatibility)
        infrastructure_config = None
        if "infrastructure" in data:
            infra_data = data["infrastructure"].copy()
            pgbackrest_settings = None
            if "pgbackrest" in infra_data:
                pgbackrest_settings = cls._load_section(
                    infra_data.pop("pgbackrest"),
                    PgBackRestSettings,
                    "infrastructure.pgbackrest",
                )
            infrastructure_config = cls._load_section(
                infra_data, InfrastructureConfig, "infrastructure"
            )
            infrastructure_config.pgbackrest = pgbackrest_settings

        # Backups section is optional (for backwards compatibility)
        backups_config = None
        if "backups" in data:
            storage_box = cls._load_section(
                data["backups"]["storage_box"], StorageBoxConfig, "backups.storage_box"
            )
            retention = cls._load_section(
                data["backups"]["retention"], RetentionConfig, "backups.retention"
            )
            alerts = cls._load_section(
                data["backups"]["alerts"], AlertsConfig, "backups.alerts"
            )
            backups_config = BackupsConfig(
                storage_box=storage_box,
                retention=retention,
                alerts=alerts,
                cipher_pass_file=data["backups"].get(
                    "cipher_pass_file",
                    DEFAULT_CIPHER_PASS_FILE,
                ),
            )

        # Paths section is optional (uses sensible defaults)
        paths_config = None
        if "paths" in data:
            paths_config = cls._load_section(data["paths"], PathsConfig, "paths")

        try:
            return cls(
                agency=cls._load_section(data["agency"], AgencyConfig, "agency"),
                staging=cls._load_section(data["staging"], StagingConfig, "staging"),
                production=cls._load_section(
                    data["production"], ProductionConfig, "production"
                ),
                templates=cls._load_section(
                    data["templates"], TemplatesConfig, "templates"
                ),
                defaults=cls._load_section(
                    data["defaults"], DefaultsConfig, "defaults"
                ),
                infrastructure=infrastructure_config,
                backups=backups_config,
                paths=paths_config,
                _config_path=config_path,
            )
        except ConfigurationError:
            raise
        except Exception as exc:
            raise ConfigurationError(
                f"Error loading configuration from {config_path}: {exc}"
            ) from exc

    @staticmethod
    def _load_section(
        data: dict[str, Any], config_class: type, section_name: str
    ) -> Any:
        """Load a config section, validating all required fields are present and types match."""
        logger = logging.getLogger(__name__)

        if not isinstance(data, dict):
            raise ConfigurationError(
                f"Section '{section_name}' must be a mapping, got {type(data).__name__}"
            )

        # For dataclasses without default_factory, check which fields have no default
        all_fields = []
        for field_name, field_info in config_class.__dataclass_fields__.items():
            if field_name.startswith("_"):
                continue
            # Field is required if it has no default and no default_factory
            if (
                field_info.default is dataclasses.MISSING
                and field_info.default_factory is dataclasses.MISSING
            ):
                all_fields.append(field_name)

        missing_fields = [f for f in all_fields if f not in data]
        if missing_fields:
            raise ConfigurationError(
                f"Missing required fields in '{section_name}': {', '.join(missing_fields)}"
            )

        # Resolve type hints (handles forward references from __future__ annotations)
        type_hints = get_type_hints(config_class)

        # Build kwargs from data, validating types
        kwargs = {}
        for field_name in config_class.__dataclass_fields__:
            if field_name.startswith("_"):
                continue
            if field_name not in data:
                continue

            value = data[field_name]
            expected_type = type_hints.get(field_name)
            if expected_type is not None:
                value = SystemConfig._validate_field_type(
                    value, expected_type, field_name, section_name, logger
                )
            kwargs[field_name] = value

        return config_class(**kwargs)

    @staticmethod
    def _validate_field_type(
        value: Any,
        expected_type: type,
        field_name: str,
        section_name: str,
        logger: logging.Logger,
    ) -> Any:
        """Validate and optionally coerce a config value to its expected type.

        Returns the (possibly coerced) value, or raises ConfigurationError.
        """
        # Unwrap Optional/Union types (T | None)
        origin = getattr(expected_type, "__origin__", None)
        if origin is Union or isinstance(expected_type, types.UnionType):
            args = expected_type.__args__
            non_none_args = [a for a in args if a is not type(None)]
            # Allow None for Optional fields
            if value is None:
                return value
            # Skip validation if union contains a dataclass (nested structure)
            if any(dataclasses.is_dataclass(a) for a in non_none_args):
                return value
            # Validate against the non-None type(s)
            if len(non_none_args) == 1:
                expected_type = non_none_args[0]
            else:
                # Multi-type union beyond Optional — skip validation
                return value

        # Skip nested dataclass types (handled by separate _load_section calls)
        if dataclasses.is_dataclass(expected_type):
            return value

        # Validate basic types: str, int, bool, Path
        if expected_type is bool:
            # bool check must come before int (bool is subclass of int)
            if not isinstance(value, bool):
                raise ConfigurationError(
                    f"Field '{field_name}' in section '{section_name}' "
                    f"expects bool, got {type(value).__name__}: {value!r}"
                )
        elif expected_type is int:
            if isinstance(value, bool):
                # bool is subclass of int but should not be accepted as int
                raise ConfigurationError(
                    f"Field '{field_name}' in section '{section_name}' "
                    f"expects int, got bool: {value!r}"
                )
            if isinstance(value, str):
                # Auto-coerce str → int if the string is a valid integer
                try:
                    coerced = int(value)
                    logger.warning(
                        "Field '%s' in section '%s' expects int, "
                        "got str '%s' — auto-coercing to %d",
                        field_name,
                        section_name,
                        value,
                        coerced,
                    )
                    return coerced
                except ValueError:
                    raise ConfigurationError(
                        f"Field '{field_name}' in section '{section_name}' "
                        f"expects int, got str: {value!r}"
                    )
            if not isinstance(value, int):
                raise ConfigurationError(
                    f"Field '{field_name}' in section '{section_name}' "
                    f"expects int, got {type(value).__name__}: {value!r}"
                )
        elif expected_type is str:
            if not isinstance(value, str):
                raise ConfigurationError(
                    f"Field '{field_name}' in section '{section_name}' "
                    f"expects str, got {type(value).__name__}: {value!r}"
                )
        elif expected_type is Path:
            # Accept str and convert to Path
            if isinstance(value, str):
                return Path(value)
            if not isinstance(value, Path):
                raise ConfigurationError(
                    f"Field '{field_name}' in section '{section_name}' "
                    f"expects Path, got {type(value).__name__}: {value!r}"
                )

        return value

    def get_site_dir(self, site_slug: str, target: str = "staging") -> Path:
        """Get the base directory for a site.

        Args:
            site_slug: The site slug (e.g., 'acme')
            target: 'staging' or 'prod'

        Returns:
            Path to site directory
        """
        if target == "prod":
            base = self.production.base_dir
        else:
            base = self.staging.base_dir
        return Path(base) / site_slug

    def get_site_domain(self, site_slug: str, target: str = "staging") -> str:
        """Get the domain for a site.

        Args:
            site_slug: The site slug (e.g., 'acme')
            target: 'staging' or 'prod' (prod requires explicit domain)

        Returns:
            Domain string

        Raises:
            ValueError: If target is 'prod' (production requires explicit domain)
        """
        if target == "prod":
            raise ValueError("Production domain must be explicitly specified")
        return self.staging.domain_pattern.replace("{slug}", site_slug)

    def get_db_name(self, site_slug: str) -> str:
        """Get the Postgres database name for a site.

        Replaces hyphens with underscores because PostgreSQL identifiers
        cannot contain unquoted hyphens.
        """
        safe_slug = site_slug.replace("-", "_")
        return f"sum_{safe_slug}"

    def get_db_user(self, site_slug: str) -> str:
        """Get the Postgres database user for a site.

        Replaces hyphens with underscores because PostgreSQL identifiers
        cannot contain unquoted hyphens.
        """
        safe_slug = site_slug.replace("-", "_")
        return f"sum_{safe_slug}_user"

    def get_systemd_service_name(self, site_slug: str) -> str:
        """Get the systemd service name for a site."""
        return f"sum-{site_slug}-gunicorn"

    def get_caddy_config_name(self, site_slug: str) -> str:
        """Get the Caddy config file name for a site."""
        return f"sum-{site_slug}.caddy"

    # Path accessor methods with defaults
    # These provide consistent access to paths whether or not the paths section
    # is configured in config.yml

    def get_pgbackrest_config_dir(self) -> Path:
        """Get pgBackRest stanza config directory."""
        if self.paths:
            return Path(self.paths.pgbackrest_config_dir)
        return Path("/etc/pgbackrest/conf.d")

    def get_ports_file(self) -> Path:
        """Get path to ports.json file."""
        if self.paths:
            return Path(self.paths.ports_file)
        return Path("/etc/sum/ports.json")

    def get_ports_lock_file(self) -> Path:
        """Get path to ports lock file."""
        if self.paths:
            return Path(self.paths.ports_lock_file)
        return Path("/etc/sum/ports.lock")

    def get_port_range(self) -> tuple[int, int]:
        """Get (min_port, max_port) for PostgreSQL cluster allocation."""
        if self.paths:
            return (self.paths.port_range_min, self.paths.port_range_max)
        return (5433, 5532)


# Module-level singleton for convenience
_system_config: SystemConfig | None = None


def get_system_config(reload: bool = False) -> SystemConfig:
    """Get the system configuration singleton.

    Args:
        reload: Force reload from file even if already loaded.

    Returns:
        SystemConfig instance.

    Raises:
        ConfigurationError: If config file is missing or invalid.
    """
    global _system_config
    if _system_config is None or reload:
        _system_config = SystemConfig.load()
    return _system_config


def reset_system_config() -> None:
    """Reset the config singleton (primarily for testing)."""
    global _system_config
    _system_config = None
