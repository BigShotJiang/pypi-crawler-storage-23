"""Command-line entrypoint wiring for the SUM platform CLI."""

from __future__ import annotations

import importlib.metadata

import click
from sum.commands.backup import backup
from sum.commands.check import check
from sum.commands.destroy import destroy
from sum.commands.init import init
from sum.commands.monitor import monitor
from sum.commands.promote import promote
from sum.commands.restore import restore
from sum.commands.setup import setup
from sum.commands.test_email import test_email
from sum.commands.theme import theme
from sum.commands.themes import themes
from sum.commands.update import update


def _get_version() -> str:
    try:
        return importlib.metadata.version("sum-cli")
    except importlib.metadata.PackageNotFoundError:
        return "0.0.0"


@click.group()
@click.version_option(
    version=_get_version(), prog_name="sum-platform", message="%(prog)s %(version)s"
)
@click.option(
    "--skip-preflight",
    is_flag=True,
    default=False,
    envvar="SUM_SKIP_PREFLIGHT",
    help="Skip pre-flight checks (for automation).",
)
@click.pass_context
def cli(ctx: click.Context, skip_preflight: bool) -> None:
    """SUM Platform CLI - Deploy and manage client sites."""
    ctx.ensure_object(dict)
    ctx.obj["skip_preflight"] = skip_preflight


cli.add_command(backup)
cli.add_command(check)
cli.add_command(destroy)
cli.add_command(init)
cli.add_command(monitor)
cli.add_command(promote)
cli.add_command(restore)
cli.add_command(setup)
cli.add_command(test_email)
cli.add_command(theme)
cli.add_command(themes)  # Deprecated, kept for backward compatibility
cli.add_command(update)


if __name__ == "__main__":
    cli()
