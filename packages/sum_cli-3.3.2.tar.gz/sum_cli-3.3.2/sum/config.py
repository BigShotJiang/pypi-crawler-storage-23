from __future__ import annotations

from dataclasses import dataclass
from typing import TypedDict, Unpack


class SetupConfigArgs(TypedDict, total=False):
    full: bool
    quick: bool
    ci: bool
    no_prompt: bool
    skip_venv: bool
    skip_migrations: bool
    skip_seed: bool
    skip_superuser: bool
    run_server: bool
    port: int
    superuser_username: str
    superuser_email: str
    superuser_password: str
    seed_preset: str | None
    seed_site: str | None
    theme_slug: str


@dataclass
class SetupConfig:
    """Configuration for setup orchestration."""

    full: bool = False
    quick: bool = False
    ci: bool = False
    no_prompt: bool = False

    skip_venv: bool = False
    skip_migrations: bool = False
    skip_seed: bool = False
    skip_superuser: bool = False

    run_server: bool = False
    port: int = 8000

    # WARNING: These defaults are for CI/test environments only.
    # Production sites use SiteOrchestrator which generates random credentials
    # via generate_site_credentials() in infrastructure.py.
    superuser_username: str = "admin"
    superuser_email: str = "admin@example.com"
    superuser_password: str = "admin"  # nosec B105 - CI/test default only

    seed_preset: str | None = None
    seed_site: str | None = None
    theme_slug: str = "theme_a"

    def __post_init__(self) -> None:
        """Validate configuration."""
        if self.full and self.quick:
            raise ValueError("--full and --quick are mutually exclusive")
        if self.ci:
            self.no_prompt = True
        if not self.ci and self.superuser_password == "admin":
            raise ValueError(
                "Default superuser credentials ('admin'/'admin') are not allowed outside CI. "
                "Pass --superuser-password or set ci=True."
            )

    @classmethod
    def from_cli_args(cls, **kwargs: Unpack[SetupConfigArgs]) -> SetupConfig:
        """Create a SetupConfig from CLI arguments."""
        return cls(**kwargs)
