"""Backup cron schedule management."""

from __future__ import annotations

import hashlib
import re
import shlex
from pathlib import Path
from typing import TYPE_CHECKING

from sum.setup.bare_metal_postgres import DEFAULT_PGBACKREST_WRAPPER

if TYPE_CHECKING:
    from sum.system_config import SystemConfig

CRON_FILE = Path("/etc/cron.d/sum-backups")

# Default pgBackRest config directory (used when config not provided)
DEFAULT_PGBACKREST_CONFIG_DIR = "/etc/pgbackrest/conf.d"

# Valid site_slug pattern: alphanumeric, hyphens, underscores only
SITE_SLUG_PATTERN = re.compile(r"^[a-zA-Z0-9_-]+$")


def get_staggered_minute(site_slug: str) -> int:
    """Get a consistent minute offset (0-59) based on site_slug hash.

    This staggers backup times across different sites to avoid all sites
    backing up at exactly the same time.

    Args:
        site_slug: Site identifier.

    Returns:
        Minute value (0-59) for cron schedule.
    """
    # Use MD5 for a simple, non-cryptographic hash to derive a stable minute
    # offset. MD5 is acceptable here because this value is not used for any
    # security-sensitive purpose (only to stagger backup times across sites).
    hash_bytes = hashlib.md5(site_slug.encode()).digest()
    return hash_bytes[0] % 60


def install_backup_cron(
    site_slug: str,
    site_dir: str | None = None,
    config: SystemConfig | None = None,
) -> None:
    """Add backup schedule for a site to the system cron.

    Backups are scheduled at 02:XX UTC where XX is a consistent minute
    derived from the site_slug hash. This staggers backups across sites.

    Args:
        site_slug: Site identifier (alphanumeric, hyphens, underscores only).
        site_dir: Site directory path. Defaults to /srv/sum/{site_slug}.
        config: Optional system configuration for custom paths.

    Raises:
        ValueError: If site_slug or config_path contains invalid characters.
    """
    # Validate site_slug to prevent command injection in cron entries
    if not SITE_SLUG_PATTERN.match(site_slug):
        raise ValueError(
            f"Invalid site_slug '{site_slug}': must contain only "
            "alphanumeric characters, hyphens, and underscores"
        )

    if site_dir is None:
        site_dir = f"/srv/sum/{site_slug}"
    marker_file = f"{site_dir}/backup_status"

    # Get staggered minute based on site_slug
    minute = get_staggered_minute(site_slug)

    # Load existing cron file (preserve all lines including comments)
    existing_lines: list[str] = []
    if CRON_FILE.exists():
        existing_lines = CRON_FILE.read_text().splitlines()

    # Check if site already has entries (look for marker comment)
    site_marker = f"# {site_slug}"
    if any(line.strip() == site_marker for line in existing_lines):
        return  # Already configured

    # Get pgBackRest config path from config or use default
    if config is not None:
        config_path = str(config.get_pgbackrest_config_dir())
    else:
        config_path = DEFAULT_PGBACKREST_CONFIG_DIR

    # Validate config_path: must be a safe filesystem path (no shell metacharacters).
    # site_slug is already validated above; config_path comes from system config
    # or the DEFAULT_PGBACKREST_CONFIG_DIR constant.
    if not re.match(r"^[a-zA-Z0-9_./-]+$", config_path):
        raise ValueError(
            f"Invalid config_path '{config_path}': must contain only "
            "alphanumeric characters, hyphens, underscores, dots, and slashes"
        )

    # Add new entries using the pgbackrest wrapper (injects cipher passphrase
    # via env var so the passphrase never appears in cron entries or config)
    # Note: --config-include-path required because pgBackRest 2.50 doesn't support it in config file
    #
    # The cron command uses bash -c '...' (single-quoted body). Values inside
    # the body must NOT be shlex.quote()'d because shlex.quote() itself uses
    # single quotes, which would prematurely terminate the bash -c string.
    # Safety: site_slug is validated (^[a-zA-Z0-9_-]+$), config_path is
    # validated above, and the wrapper path is a constant — none can contain
    # shell metacharacters.
    #
    # marker_file IS shlex.quote()'d because it appears OUTSIDE bash -c,
    # in the outer cron shell context.
    q_marker = shlex.quote(marker_file)
    wrapper = DEFAULT_PGBACKREST_WRAPPER
    # Wrap in bash -o pipefail so a pgbackrest failure propagates through
    # the pipe to logger — otherwise the marker file updates even on failure.
    # Percent signs must be escaped as \% in cron.d files (cron interprets
    # unescaped % as newline).
    new_entries = [
        f"# {site_slug}",
        (
            f"{minute} 2 * * 0 root bash -o pipefail -c"
            f" 'sudo -u postgres {wrapper} --config-include-path={config_path}"
            f" --stanza={site_slug} backup --type=full 2>&1"
            f" | logger -t sum-backup-{site_slug}'"
            f" && date +\\%s > {q_marker}"
        ),
        (
            f"{minute} 2 * * 1-6 root bash -o pipefail -c"
            f" 'sudo -u postgres {wrapper} --config-include-path={config_path}"
            f" --stanza={site_slug} backup --type=diff 2>&1"
            f" | logger -t sum-backup-{site_slug}'"
            f" && date +\\%s > {q_marker}"
        ),
        f"# end {site_slug}",
    ]

    all_entries = existing_lines + new_entries

    # Write cron file
    content = "\n".join(all_entries) + "\n"
    CRON_FILE.write_text(content)


def remove_backup_cron(site_slug: str) -> None:
    """Remove backup schedule for a site from the system cron."""
    if not CRON_FILE.exists():
        return

    lines = CRON_FILE.read_text().splitlines()
    site_marker = f"# {site_slug}"
    end_marker = f"# end {site_slug}"

    # Check whether an end marker exists to choose removal strategy
    has_end_marker = any(line.strip() == end_marker for line in lines)

    new_lines: list[str] = []
    in_removal_block = False

    for line in lines:
        stripped = line.strip()

        # Start of this site's block: skip the marker line
        if stripped == site_marker:
            in_removal_block = True
            continue

        if in_removal_block:
            if has_end_marker:
                # Marker-based removal: skip everything up to and including end marker
                if stripped == end_marker:
                    in_removal_block = False
                continue
            else:
                # Backward-compat heuristic: match cron lines by pattern
                parts = stripped.split()
                if len(parts) >= 5 and parts[0].isdigit() and parts[1] == "2":
                    continue
                # Empty lines after cron entries end the block
                if not stripped:
                    in_removal_block = False
                    continue
                # Non-cron, non-empty line: end block and keep line
                in_removal_block = False

        new_lines.append(line)

    if new_lines:
        CRON_FILE.write_text("\n".join(new_lines) + "\n")
    else:
        CRON_FILE.unlink()
