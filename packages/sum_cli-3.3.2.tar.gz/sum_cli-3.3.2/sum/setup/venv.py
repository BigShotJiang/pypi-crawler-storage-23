from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from sum.exceptions import VenvError
from sum.utils.output import OutputFormatter


class VenvManager:
    """Manage Python virtual environments for CLI projects.

    Supports both internal venv (.venv inside project) and external venv
    (separate directory outside project, e.g., /srv/sum/<name>/venv/).
    """

    def __init__(self, venv_path: Path | None = None):
        """Initialize VenvManager with optional explicit venv path.

        Args:
            venv_path: If provided, use this path for the venv.
                       If None, uses project_path/.venv (legacy behavior).
        """
        self._explicit_venv_path = venv_path

    def _get_venv_path(self, project_path: Path) -> Path:
        """Get the venv path for a project."""
        if self._explicit_venv_path is not None:
            return self._explicit_venv_path
        return project_path / ".venv"

    def create(self, project_path: Path) -> Path:
        """Create a virtualenv if it does not exist.

        Args:
            project_path: Path to the project. Used to determine venv location
                         if no explicit venv_path was provided.

        Returns:
            Path to the virtualenv directory.
        """
        venv_path = self._get_venv_path(project_path)

        if venv_path.is_dir():
            OutputFormatter.info(f"Virtualenv already exists at {venv_path}")
            return venv_path

        OutputFormatter.progress(1, 1, f"Creating virtualenv at {venv_path}")
        try:
            subprocess.run(
                [sys.executable, "-m", "venv", str(venv_path)],
                check=True,
                capture_output=True,
                text=True,
            )
        except subprocess.CalledProcessError as exc:
            OutputFormatter.error("Failed to create virtualenv")
            details = exc.stderr or exc.stdout or "Unknown error"
            raise VenvError(
                f"Failed to create virtualenv at {venv_path}: {details}"
            ) from exc

        OutputFormatter.success(f"Virtualenv created at {venv_path}")
        return venv_path

    def get_python_executable(self, project_path: Path) -> Path:
        """Return the Python executable inside the virtualenv."""
        venv_path = self._get_venv_path(project_path)
        python_path = venv_path / "bin" / "python"
        return python_path

    def get_pip_executable(self, project_path: Path) -> Path:
        """Return the pip executable inside the virtualenv."""
        venv_path = self._get_venv_path(project_path)
        pip_path = venv_path / "bin" / "pip"
        return pip_path

    def is_activated(self) -> bool:
        """Return True when running inside a virtualenv."""
        active = bool(os.environ.get("VIRTUAL_ENV")) or sys.prefix != sys.base_prefix
        return active

    def exists(self, project_path: Path) -> bool:
        """Return True when the virtualenv exists."""
        venv_path = self._get_venv_path(project_path)
        exists = venv_path.is_dir()
        return exists
