"""Site orchestration for production deployment.

Handles the full workflow of creating a working site on staging:
- Directory structure at /srv/sum/<name>/
- Postgres database with credentials
- Code scaffolding
- External venv
- Django setup (migrate, seed, superuser, collectstatic)
- Systemd service
- Caddy configuration
- Git repository
"""

from __future__ import annotations

import shutil
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from pathlib import Path

from sum.exceptions import SeedError, SetupError, SumCliError
from sum.setup.auth import SuperuserManager
from sum.setup.backup_cron import install_backup_cron
from sum.setup.bare_metal_postgres import setup_bare_metal_postgres
from sum.setup.database import DatabaseManager
from sum.setup.deps import DependencyManager
from sum.setup.git_ops import setup_git_for_site
from sum.setup.infrastructure import (
    SiteCredentials,
    check_infrastructure,
    cleanup_site,
    configure_caddy,
    create_site_directories,
    fix_site_ownership,
    generate_site_credentials,
    install_systemd_service,
    start_site_service,
    write_credentials_file,
    write_env_file,
)
from sum.setup.scaffold import scaffold_project
from sum.setup.venv import VenvManager
from sum.site_config import GitConfig, SiteConfig
from sum.system_config import SystemConfig, get_system_config
from sum.utils.django import DjangoCommandExecutor
from sum.utils.environment import ExecutionMode
from sum.utils.output import OutputFormatter


@dataclass
class SiteSetupResult:
    """Result of site setup operation."""

    success: bool
    site_slug: str
    site_dir: Path
    app_dir: Path
    domain: str
    admin_url: str
    credentials_path: Path
    repo_url: str | None
    superuser_username: str
    superuser_password: str


@dataclass
class SiteSetupConfig:
    """Configuration for site setup."""

    site_slug: str
    theme_slug: str = "theme_a"
    seed_profile: str | None = "starter"
    content_path: str | None = None
    superuser_username: str = "admin"
    skip_systemd: bool = False
    skip_caddy: bool = False
    git_config: GitConfig | None = None  # None means --no-git
    dev: bool = False
    core_ref: str | None = None


class SiteOrchestrator:
    """Orchestrates the full site setup workflow for production deployment.

    Creates a working site on staging with all infrastructure configured.
    """

    def __init__(self, config: SystemConfig | None = None):
        self.sys_config = config or get_system_config()
        self._credentials: SiteCredentials | None = None
        self._site_dir: Path | None = None
        self._app_dir: Path | None = None

    def setup_site(self, setup_config: SiteSetupConfig) -> SiteSetupResult:
        """Run the complete site setup workflow.

        Args:
            setup_config: Configuration for the site setup.

        Returns:
            SiteSetupResult with all site information.

        Raises:
            SetupError: If any step fails.
        """
        site_slug = setup_config.site_slug
        total_steps = self._count_steps(setup_config)
        current_step = 0

        try:
            # Step 1: Check infrastructure prerequisites
            current_step += 1
            self._progress(current_step, total_steps, "Checking prerequisites")
            infra = check_infrastructure()
            infra.require_all()
            self._done(current_step, total_steps, "Prerequisites verified")

            # Step 2: Generate credentials
            current_step += 1
            self._progress(current_step, total_steps, "Generating credentials")
            self._credentials = generate_site_credentials(
                site_slug,
                superuser_username=setup_config.superuser_username,
            )
            self._done(current_step, total_steps, "Credentials generated")

            # Step 3: Create directory structure
            current_step += 1
            self._progress(current_step, total_steps, "Creating directories")
            self._site_dir = create_site_directories(site_slug, self.sys_config)
            self._app_dir = self._site_dir / "app"
            self._done(current_step, total_steps, "Directories created")

            # Step 4: Create PostgreSQL cluster (bare metal)
            current_step += 1
            self._progress(current_step, total_steps, "Creating database cluster")
            postgres_port = setup_bare_metal_postgres(
                site_slug,
                self._credentials,
                self.sys_config,
            )
            # Update credentials with allocated port
            self._credentials = replace(self._credentials, postgres_port=postgres_port)
            self._done(current_step, total_steps, "Database cluster created")

            # Install backup cron schedule (if backups configured)
            if self.sys_config.backups:
                current_step += 1
                self._progress(current_step, total_steps, "Configuring backup schedule")
                install_backup_cron(site_slug, str(self._site_dir))
                self._done(current_step, total_steps, "Backup schedule configured")

            # Step 5: Write .env file
            current_step += 1
            self._progress(current_step, total_steps, "Writing configuration")
            write_env_file(
                self._site_dir, site_slug, self._credentials, self.sys_config
            )
            self._done(current_step, total_steps, "Configuration written")

            # Step 6: Scaffold project code
            current_step += 1
            self._progress(current_step, total_steps, "Scaffolding project")
            self._scaffold_to_app_dir(
                site_slug,
                setup_config.theme_slug,
                setup_config.seed_profile,
                git_provider=(
                    setup_config.git_config.provider
                    if setup_config.git_config
                    else None
                ),
                dev=setup_config.dev,
                core_ref=setup_config.core_ref,
            )
            # Copy .env to app directory (Django reads from app/.env, not site root)
            self._copy_env_to_app()
            self._done(current_step, total_steps, "Project scaffolded")

            # Step 7: Create external venv
            current_step += 1
            self._progress(current_step, total_steps, "Creating virtualenv")
            venv_path = self._site_dir / "venv"
            venv_manager = VenvManager(venv_path=venv_path)
            venv_manager.create(self._app_dir)
            self._done(current_step, total_steps, "Virtualenv created")

            # Step 8: Install dependencies
            current_step += 1
            self._progress(current_step, total_steps, "Installing dependencies")
            deps_manager = DependencyManager(venv_manager=venv_manager)
            deps_manager.install(self._app_dir)
            self._done(current_step, total_steps, "Dependencies installed")

            # Step 9: Run migrations
            current_step += 1
            self._progress(current_step, total_steps, "Running migrations")
            django_executor = self._create_django_executor(venv_manager)
            db_manager = DatabaseManager(django_executor)
            db_manager.migrate()
            self._done(current_step, total_steps, "Migrations complete")

            # Step 10: Seed content
            if setup_config.seed_profile:
                current_step += 1
                self._progress(current_step, total_steps, "Seeding content")
                # Use the seed command with YAML content profiles
                # Default profile is 'starter' - a production-ready base
                self._seed_content(
                    django_executor,
                    setup_config.seed_profile,
                    setup_config.content_path,
                )
                self._done(current_step, total_steps, "Content seeded")

            # Step 11: Create superuser
            current_step += 1
            self._progress(current_step, total_steps, "Creating superuser")
            auth_manager = SuperuserManager(django_executor, self._app_dir)
            auth_manager.create(
                username=self._credentials.superuser_username,
                email=self._credentials.superuser_email,
                password=self._credentials.superuser_password,
            )
            self._done(current_step, total_steps, "Superuser created")

            # Step 12: Collect static files
            current_step += 1
            self._progress(current_step, total_steps, "Collecting static files")
            self._collect_static(django_executor)
            self._done(current_step, total_steps, "Static files collected")

            # Step 13: Git init and push (must happen before ownership change)
            repo_url = None
            current_step += 1
            self._progress(current_step, total_steps, "Setting up git repository")
            repo_url = setup_git_for_site(
                self._app_dir,
                site_slug,
                git_config=setup_config.git_config,
            )
            if repo_url:
                self._done(current_step, total_steps, f"Repository created: {repo_url}")
            else:
                self._done(current_step, total_steps, "Git initialized (local only)")

            # Step 14: Fix ownership for deploy user
            current_step += 1
            self._progress(current_step, total_steps, "Setting file ownership")
            fix_site_ownership(site_slug, self.sys_config)
            self._done(current_step, total_steps, "Ownership set")

            # Step 15: Install systemd service (optional)
            if not setup_config.skip_systemd:
                current_step += 1
                self._progress(current_step, total_steps, "Installing systemd service")
                install_systemd_service(site_slug, self.sys_config)
                self._done(current_step, total_steps, "Systemd service installed")

            # Step 16: Configure Caddy (optional)
            if not setup_config.skip_caddy:
                current_step += 1
                self._progress(current_step, total_steps, "Configuring Caddy")
                configure_caddy(site_slug, self.sys_config)
                self._done(current_step, total_steps, "Caddy configured")

            # Step 17: Start service (if systemd was configured)
            if not setup_config.skip_systemd:
                current_step += 1
                self._progress(current_step, total_steps, "Starting service")
                start_site_service(site_slug, self.sys_config)
                self._done(current_step, total_steps, "Service started")

            # Step 18: Write site config
            current_step += 1
            self._progress(current_step, total_steps, "Writing site config")
            site_config = SiteConfig(
                slug=site_slug,
                theme=setup_config.theme_slug,
                created=datetime.now(UTC),
                git=setup_config.git_config,
            )
            site_config.save(self._site_dir)
            self._done(current_step, total_steps, "Site config saved")

            # Step 19: Write credentials file
            current_step += 1
            self._progress(current_step, total_steps, "Saving credentials")
            creds_path = write_credentials_file(
                self._site_dir, site_slug, self._credentials, self.sys_config
            )
            self._done(current_step, total_steps, "Credentials saved")

            # Build result
            domain = self.sys_config.get_site_domain(site_slug)
            return SiteSetupResult(
                success=True,
                site_slug=site_slug,
                site_dir=self._site_dir,
                app_dir=self._app_dir,
                domain=domain,
                admin_url=f"https://{domain}/admin/",
                credentials_path=creds_path,
                repo_url=repo_url,
                superuser_username=self._credentials.superuser_username,
                superuser_password=self._credentials.superuser_password,
            )

        except (SumCliError, KeyboardInterrupt) as exc:
            # Cleanup on failure
            if isinstance(exc, KeyboardInterrupt):
                OutputFormatter.warning("Setup interrupted by user")
            else:
                OutputFormatter.error(f"Setup failed: {exc}")
            OutputFormatter.warning("Cleaning up partial installation...")
            cleanup_site(site_slug, self.sys_config)
            raise

    def _count_steps(self, config: SiteSetupConfig) -> int:
        """Count total steps based on configuration.

        Builds a list of step names to ensure count matches actual execution order.
        """
        steps: list[str] = [
            "check_prerequisites",
            "generate_credentials",
            "create_directories",
            "create_database",
        ]

        if self.sys_config.backups:
            steps.append("install_backup_cron")

        steps.extend(
            [
                "write_env_file",
                "scaffold_project",
                "create_venv",
                "install_dependencies",
                "run_migrations",
            ]
        )

        # Seeding happens before superuser creation
        if config.seed_profile:
            steps.append("seed_content")

        steps.extend(
            [
                "create_superuser",
                "collect_static",
                # Git must happen before ownership change
                "setup_git",
                "fix_ownership",
            ]
        )

        if not config.skip_systemd:
            steps.append("install_systemd_service")

        if not config.skip_caddy:
            steps.append("configure_caddy")

        # Start service after caddy is configured
        if not config.skip_systemd:
            steps.append("start_systemd_service")

        steps.append("write_site_config")
        steps.append("write_credentials_file")

        return len(steps)

    def _progress(self, step: int, total: int, message: str) -> None:
        """Show progress indicator."""
        OutputFormatter.progress(step, total, message, "⏳")

    def _done(self, step: int, total: int, message: str) -> None:
        """Show completion indicator."""
        OutputFormatter.progress(step, total, message, "✅")

    def _scaffold_to_app_dir(
        self,
        site_slug: str,
        theme_slug: str,
        seed_profile: str | None = None,
        git_provider: str | None = None,
        dev: bool = False,
        core_ref: str | None = None,
    ) -> None:
        """Scaffold project code to the app directory.

        The scaffold function expects to create the directory, so we need to
        remove the empty app dir first, let scaffold create it, then the
        result will be in the right place.
        """
        if self._app_dir is None or self._site_dir is None:
            raise SetupError("Site directories not initialized")

        # Remove empty app dir (scaffold will create it)
        if self._app_dir.exists():
            try:
                self._app_dir.rmdir()
            except OSError as exc:
                raise SetupError(
                    f"Cannot remove app directory (not empty?): {exc}"
                ) from exc

        # Scaffold creates <parent>/<slug>, so we use site_dir as parent
        # and site_slug as the name, but we want it in "app" subdir
        # So we scaffold to a temp name then rename
        scaffold_project(
            project_name=site_slug,
            clients_dir=self._site_dir,
            theme_slug=theme_slug,
            seed_profile=seed_profile or "starter",
            git_provider=git_provider,
            dev=dev,
            core_ref=core_ref,
        )

        # Rename from site_slug to app
        temp_path = self._site_dir / site_slug
        if not temp_path.exists():
            raise SetupError(f"Scaffold did not create expected directory: {temp_path}")

        try:
            temp_path.rename(self._app_dir)
        except OSError as exc:
            raise SetupError(
                f"Failed to rename scaffolded directory to app: {exc}"
            ) from exc

    def _create_django_executor(
        self, venv_manager: VenvManager
    ) -> DjangoCommandExecutor:
        """Create a Django command executor for the site."""
        if self._app_dir is None:
            raise SetupError("App directory not initialized")

        # We need a custom executor that uses our external venv
        return DjangoCommandExecutor(
            self._app_dir,
            ExecutionMode.STANDALONE,
            python_path=venv_manager.get_python_executable(self._app_dir),
        )

    def _copy_env_to_app(self) -> None:
        """Copy .env from site root to app directory.

        Django reads .env from the project root (app/), not the site root.
        The scaffolded project has a default .env that needs to be overwritten
        with the production configuration.
        """
        if self._site_dir is None or self._app_dir is None:
            raise SetupError("Site directories not initialized")

        source_env = self._site_dir / ".env"
        target_env = self._app_dir / ".env"

        if not source_env.exists():
            raise SetupError(f".env file not found at {source_env}")

        try:
            shutil.copy2(source_env, target_env)
        except OSError as exc:
            raise SetupError(f"Failed to copy .env to app directory: {exc}") from exc

    def _collect_static(self, django_executor: DjangoCommandExecutor) -> None:
        """Run collectstatic Django command."""
        django_executor.run_command(["collectstatic", "--noinput"])

    def _seed_content(
        self,
        django_executor: DjangoCommandExecutor,
        profile: str,
        content_path: str | None = None,
    ) -> None:
        """Seed the site with content using YAML content profiles.

        Uses the seed management command with the seeders package and
        content profiles.

        Args:
            django_executor: Django command executor for the site.
            profile: Seed profile name (e.g., 'starter', 'sage-stone').
            content_path: Optional path to custom content directory.
        """
        cmd = ["seed", profile, "--clear"]
        if content_path:
            cmd.extend(["--content-path", content_path])

        result = django_executor.run_command(
            cmd,
            check=False,
        )

        if result.returncode != 0:
            details = result.stderr or result.stdout
            raise SeedError(f"Seeding failed: {details}")
