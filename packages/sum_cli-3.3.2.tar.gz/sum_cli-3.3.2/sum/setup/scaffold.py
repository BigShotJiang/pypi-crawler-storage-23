# pyright: reportUnknownArgumentType=false, reportUnknownMemberType=false, reportUnusedCallResult=false, reportImplicitStringConcatenation=false

"""Project scaffold and theme setup utilities."""

from __future__ import annotations

import importlib.resources
import importlib.resources.abc
import json
import os
import shutil
import tempfile
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import cast

from sum.exceptions import (
    SetupError,
    ThemeDowngradeError,
    ThemeNotFoundError,
    ThemeUpdateError,
    ThemeValidationError,
)
from sum.setup.remote_themes import (
    compare_versions,
    fetch_theme_from_repo,
    get_latest_theme_tag,
    parse_theme_spec,
    resolve_remote_theme,
)
from sum.utils.environment import find_monorepo_root
from sum.utils.project import (
    ProjectNaming,
    get_packaged_boilerplate,
    is_boilerplate_dir,
    safe_rmtree,
    safe_text_replace_in_file,
    validate_project_name,
)

BoilerplateSource = Path | importlib.resources.abc.Traversable

DEFAULT_THEME_SLUG = "theme_a"
LEGACY_CORE_CSS_REF = "/static/sum_core/css/main.css"
MIN_COMPILED_CSS_BYTES = 5 * 1024
SUM_CORE_GIT_URL = "https://github.com/markashton480/sum-core.git"


@dataclass(frozen=True, slots=True)
class ThemeManifest:
    slug: str
    name: str
    description: str
    version: str

    def validate(self) -> None:
        if not self.slug:
            raise ValueError("slug cannot be empty")
        if not self.name:
            raise ValueError("name cannot be empty")
        if not self.version:
            raise ValueError("version cannot be empty")


def _read_manifest(theme_dir: Path) -> ThemeManifest:
    manifest_path = theme_dir / "theme.json"
    if not manifest_path.is_file():
        raise ThemeValidationError(f"Missing theme manifest: {manifest_path}")

    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ThemeValidationError(
            f"Invalid JSON in theme manifest: {manifest_path} ({exc})"
        ) from exc

    if not isinstance(data, dict):
        raise ThemeValidationError(f"Theme manifest must be an object: {manifest_path}")

    manifest_data = cast(dict[str, object], data)
    manifest = ThemeManifest(
        slug=str(manifest_data.get("slug", "")).strip(),
        name=str(manifest_data.get("name", "")).strip(),
        description=str(manifest_data.get("description", "")).strip(),
        version=str(manifest_data.get("version", "")).strip(),
    )
    try:
        manifest.validate()
    except ValueError as exc:
        raise ThemeValidationError(str(exc)) from exc

    if manifest.slug != theme_dir.name:
        raise ThemeValidationError(
            f"Theme slug mismatch: dir='{theme_dir.name}' manifest='{manifest.slug}'"
        )
    return manifest


def _resolve_theme_dir(theme_slug: str, repo_root: Path | None) -> Path:
    """Resolve theme directory from slug, optionally with version.

    Resolution order:
    1. SUM_THEME_PATH environment variable (if set)
    2. Monorepo themes directory (repo_root/themes/)
    3. Current working directory (./themes/)
    4. Remote fetch from sum-themes repository

    Args:
        theme_slug: Theme slug, optionally with version (e.g., 'theme_a' or 'theme_a@1.0.0').
        repo_root: Optional path to monorepo root.

    Returns:
        Path to the resolved theme directory.

    Raises:
        ThemeNotFoundError: If theme cannot be found locally or remotely.
    """
    # Parse theme spec to extract slug and optional version
    spec = parse_theme_spec(theme_slug)
    slug = spec.slug

    # If version is specified, skip local lookups and go straight to remote
    # (local themes don't support versioning)
    if spec.version is not None:
        return resolve_remote_theme(theme_slug)

    # Step 1: Check SUM_THEME_PATH environment variable
    env = os.getenv("SUM_THEME_PATH")
    if env:
        path = Path(env).expanduser().resolve()
        if not path.exists():
            raise ThemeNotFoundError(f"SUM_THEME_PATH does not exist: {path}")
        if (path / "theme.json").is_file():
            return path
        candidate = path / slug
        if candidate.is_dir():
            return candidate
        raise ThemeNotFoundError(
            f"Theme '{slug}' not found under SUM_THEME_PATH: {path}"
        )

    # Step 2: Check monorepo themes directory
    if repo_root is not None:
        repo_theme = repo_root / "themes" / slug
        if repo_theme.is_dir():
            return repo_theme

    # Step 3: Check current working directory
    cwd_theme = (Path.cwd() / "themes" / slug).resolve()
    if cwd_theme.is_dir():
        return cwd_theme

    # Step 4: Fetch from remote sum-themes repository
    remote_error: str | None = None
    try:
        return resolve_remote_theme(slug)
    except ThemeNotFoundError as exc:
        # Preserve the remote error details for the final message
        remote_error = str(exc)

    locations = [
        "SUM_THEME_PATH (if set)",
        f"{repo_root}/themes/ (monorepo)" if repo_root else None,
        "./themes/ (current directory)",
        "sum-themes remote repository",
    ]
    locations_str = "\n  - ".join(loc for loc in locations if loc)
    message = f"Theme '{slug}' not found. Looked in:\n  - {locations_str}"
    if remote_error:
        message += f"\n\nRemote fetch error: {remote_error}"
    raise ThemeNotFoundError(message)


def _get_theme(theme_slug: str, repo_root: Path | None) -> tuple[ThemeManifest, Path]:
    theme_dir = _resolve_theme_dir(theme_slug, repo_root)
    return _read_manifest(theme_dir), theme_dir


def _resolve_boilerplate_source(repo_root: Path | None) -> BoilerplateSource:
    env_override = os.getenv("SUM_BOILERPLATE_PATH")
    if env_override:
        path = Path(env_override).expanduser().resolve()
        if not is_boilerplate_dir(path):
            message = (
                "SUM_BOILERPLATE_PATH is set but is not a valid boilerplate dir: "
                f"{path}"
            )
            raise SetupError(message)
        return path

    if repo_root is not None:
        repo_boilerplate = repo_root / "boilerplate"
        if is_boilerplate_dir(repo_boilerplate):
            return repo_boilerplate

    cwd_boilerplate = (Path.cwd() / "boilerplate").resolve()
    if is_boilerplate_dir(cwd_boilerplate):
        return cwd_boilerplate

    packaged = get_packaged_boilerplate()
    return cast(BoilerplateSource, packaged)


def _is_binary_file(path: Path) -> bool:
    """Check if file appears to be binary by looking for null bytes."""
    try:
        with open(path, "rb") as f:
            chunk = f.read(512)
        return b"\x00" in chunk
    except OSError:
        return True  # Can't read = skip


def _replace_placeholders(project_root: Path, naming: ProjectNaming) -> None:
    for dirpath, _, filenames in os.walk(project_root):
        for filename in filenames:
            path = Path(dirpath) / filename
            if _is_binary_file(path):
                continue
            _ = safe_text_replace_in_file(
                path,
                "project_name",
                naming.python_package,
            )


def _rename_project_package_dir(project_root: Path, naming: ProjectNaming) -> None:
    src = project_root / "project_name"
    dst = project_root / naming.python_package
    if not src.exists():
        raise SetupError("Boilerplate is malformed: missing 'project_name/' package.")
    if dst.exists():
        raise SetupError(
            f"Refusing to overwrite existing project package directory: {dst}"
        )
    src.rename(dst)


def _create_env_from_example(project_root: Path) -> None:
    env_example = project_root / ".env.example"
    env_file = project_root / ".env"
    if env_file.exists():
        return
    if env_example.exists():
        shutil.copy2(env_example, env_file)


def _theme_contract_errors(theme_root: Path, theme_slug: str) -> list[str]:
    errors: list[str] = []

    manifest_path = theme_root / "theme.json"
    if not manifest_path.is_file():
        errors.append(f"Missing theme manifest: {manifest_path}")

    base_template = theme_root / "templates" / "theme" / "base.html"
    if not base_template.is_file():
        errors.append(f"Missing theme base template: {base_template}")

    compiled_css = theme_root / "static" / theme_slug / "css" / "main.css"
    if not compiled_css.is_file():
        errors.append(f"Missing compiled CSS: {compiled_css}")
    else:
        try:
            size = compiled_css.stat().st_size
        except OSError as exc:
            errors.append(f"Could not stat compiled CSS: {compiled_css} ({exc})")
        else:
            if size <= MIN_COMPILED_CSS_BYTES:
                errors.append(
                    f"Compiled CSS is unexpectedly small ({size} bytes): {compiled_css}"
                )

        try:
            css_text = compiled_css.read_text(encoding="utf-8", errors="ignore")
        except OSError as exc:
            errors.append(f"Could not read compiled CSS: {compiled_css} ({exc})")
        else:
            if LEGACY_CORE_CSS_REF in css_text:
                errors.append(
                    "Compiled CSS references legacy core stylesheet "
                    f"({LEGACY_CORE_CSS_REF}): {compiled_css}"
                )

    return errors


def _copy_theme_to_active(
    project_root: Path, theme_source_dir: Path, theme_slug: str
) -> None:
    theme_target_dir = project_root / "theme" / "active"
    theme_parent_dir = theme_target_dir.parent
    theme_parent_dir.mkdir(parents=True, exist_ok=True)

    if theme_target_dir.exists():
        raise SetupError(f"Theme target directory already exists: {theme_target_dir}")

    ignore = shutil.ignore_patterns("node_modules")
    with tempfile.TemporaryDirectory(prefix=f"sum-theme-{theme_slug}-") as tmp_root:
        tmp_dir = Path(tmp_root) / theme_slug
        shutil.copytree(theme_source_dir, tmp_dir, dirs_exist_ok=False, ignore=ignore)

        errors = _theme_contract_errors(tmp_dir, theme_slug)
        if errors:
            raise SetupError(
                "Theme copy validation failed:\n  - " + "\n  - ".join(errors)
            )

        shutil.move(str(tmp_dir), str(theme_target_dir))


@dataclass(frozen=True, slots=True)
class ThemeLockfile:
    """Theme lockfile data from .sum/theme.json."""

    theme: str
    original_version: str
    current_version: str | None
    locked_at: str
    updated_at: str | None
    update_history: list[dict[str, str]]


def read_theme_lockfile(project_root: Path) -> ThemeLockfile | None:
    """Read and parse the theme lockfile.

    Args:
        project_root: Path to the project root.

    Returns:
        ThemeLockfile if the file exists and is valid, None otherwise.
    """
    lockfile_path = project_root / ".sum" / "theme.json"
    if not lockfile_path.is_file():
        return None

    try:
        data = json.loads(lockfile_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None

    if not isinstance(data, dict):
        return None

    # Coerce update_history to list (handles null or non-list values)
    raw_history = data.get("update_history")
    update_history = raw_history if isinstance(raw_history, list) else []

    # Coerce optional string fields
    current_version = data.get("current_version")
    if current_version is not None:
        current_version = str(current_version)
    updated_at = data.get("updated_at")
    if updated_at is not None:
        updated_at = str(updated_at)

    return ThemeLockfile(
        theme=str(data.get("theme", "")),
        original_version=str(data.get("original_version", "")),
        current_version=current_version,
        locked_at=str(data.get("locked_at", "")),
        updated_at=updated_at,
        update_history=update_history,
    )


def _write_theme_config(
    project_root: Path, theme_slug: str, theme_version: str
) -> None:
    sum_dir = project_root / ".sum"
    sum_dir.mkdir(parents=True, exist_ok=True)

    theme_config = {
        "theme": theme_slug,
        "original_version": theme_version,
        "locked_at": datetime.now(UTC).isoformat(),
    }

    theme_file = sum_dir / "theme.json"
    theme_file.write_text(
        json.dumps(theme_config, indent=2) + "\n",
        encoding="utf-8",
    )


def _write_theme_config_update(
    project_root: Path,
    theme_slug: str,
    new_version: str,
    existing_lockfile: ThemeLockfile | None,
) -> None:
    """Write updated theme config after a theme update.

    Preserves original_version and adds update tracking.

    Args:
        project_root: Path to the project root.
        theme_slug: Theme slug.
        new_version: New theme version being installed.
        existing_lockfile: Existing lockfile data (if any).
    """
    sum_dir = project_root / ".sum"
    sum_dir.mkdir(parents=True, exist_ok=True)

    now = datetime.now(UTC).isoformat()

    # Build update history
    history: list[dict[str, str]] = []
    if existing_lockfile:
        history = list(existing_lockfile.update_history)
        # Add the previous version to history if not already there
        prev_version = (
            existing_lockfile.current_version or existing_lockfile.original_version
        )
        if prev_version and (not history or history[-1].get("version") != prev_version):
            prev_at = existing_lockfile.updated_at or existing_lockfile.locked_at
            history.append({"version": prev_version, "at": prev_at})

    # Add current update to history
    history.append({"version": new_version, "at": now})

    theme_config = {
        "theme": theme_slug,
        "original_version": (
            existing_lockfile.original_version if existing_lockfile else new_version
        ),
        "current_version": new_version,
        "locked_at": existing_lockfile.locked_at if existing_lockfile else now,
        "updated_at": now,
        "update_history": history,
    }

    theme_file = sum_dir / "theme.json"
    theme_file.write_text(
        json.dumps(theme_config, indent=2) + "\n",
        encoding="utf-8",
    )


def install_theme(
    project_root: Path,
    theme_slug: str,
    version: str | None = None,
    *,
    allow_downgrade: bool = False,
    force: bool = False,
) -> str:
    """Install or update a theme in an existing project.

    This is the main entry point for theme updates. It handles:
    - Fetching the theme from the remote repository
    - Creating a backup of the existing theme
    - Installing the new theme
    - Updating the lockfile
    - Rolling back on failure

    Args:
        project_root: Path to the project root.
        theme_slug: Theme slug to install.
        version: Specific version to install, or None for latest.
        allow_downgrade: If True, allow downgrading to an older version.
        force: If True, reinstall even if already at the target version.

    Returns:
        The version that was installed.

    Raises:
        ThemeUpdateError: If the update fails.
        ThemeDowngradeError: If attempting to downgrade without allow_downgrade.
        ThemeNotFoundError: If the theme or version cannot be found.
    """
    # Validate theme slug to prevent path traversal from malicious lockfiles
    # parse_theme_spec validates the slug format
    parse_theme_spec(theme_slug)

    theme_dir = project_root / "theme" / "active"
    backup_dir = project_root / "theme" / "active.backup"

    # Read existing lockfile
    lockfile = read_theme_lockfile(project_root)

    # Resolve target version
    if version is None:
        version = get_latest_theme_tag(theme_slug)
        if version is None:
            raise ThemeNotFoundError(
                f"No version tags found for theme '{theme_slug}' in remote repository"
            )

    # Get current version for comparison
    current_version = None
    if lockfile:
        current_version = lockfile.current_version or lockfile.original_version

    # Check if already at target version
    if current_version and current_version == version and not force:
        raise ThemeUpdateError(
            f"Theme '{theme_slug}' is already at version {version}. "
            f"Use --force to reinstall."
        )

    # Check for downgrade
    if current_version and compare_versions(version, current_version) < 0:
        if not allow_downgrade:
            raise ThemeDowngradeError(
                f"Cannot downgrade theme '{theme_slug}' from {current_version} to {version}. "
                f"Use --allow-downgrade to force."
            )

    # Fetch the new theme version
    theme_source = fetch_theme_from_repo(theme_slug, version)

    # Validate the new theme
    errors = _theme_contract_errors(theme_source, theme_slug)
    if errors:
        raise ThemeUpdateError("Theme validation failed:\n  - " + "\n  - ".join(errors))

    # Create backup if theme directory exists
    had_backup = False
    if theme_dir.exists():
        if backup_dir.exists():
            shutil.rmtree(backup_dir)
        theme_dir.rename(backup_dir)
        had_backup = True

    try:
        # Install new theme
        theme_parent = theme_dir.parent
        theme_parent.mkdir(parents=True, exist_ok=True)

        ignore = shutil.ignore_patterns("node_modules")
        shutil.copytree(theme_source, theme_dir, dirs_exist_ok=False, ignore=ignore)

        # Update lockfile
        _write_theme_config_update(project_root, theme_slug, version, lockfile)

    except Exception as exc:
        # Cleanup: always remove any partially-installed theme_dir
        if theme_dir.exists():
            shutil.rmtree(theme_dir)

        # Restore backup if we had one
        if had_backup and backup_dir.exists():
            backup_dir.rename(theme_dir)
        raise ThemeUpdateError(f"Theme installation failed: {exc}") from exc

    # Cleanup backup on success
    if backup_dir.exists():
        shutil.rmtree(backup_dir)

    return version


def _resolve_seeders_dir(repo_root: Path | None) -> Path | None:
    """Resolve the seeders package directory.

    Resolution order:
    1. Monorepo seeders directory (repo_root/seeders/)
    2. Current working directory (./seeders/)
    3. Remote fetch from sum-platform repository

    Returns None if seeders cannot be found (will skip seeder copy).
    """
    if repo_root is not None:
        repo_seeders = repo_root / "seeders"
        if repo_seeders.is_dir() and (repo_seeders / "__init__.py").exists():
            return repo_seeders

    cwd_seeders = (Path.cwd() / "seeders").resolve()
    if cwd_seeders.is_dir() and (cwd_seeders / "__init__.py").exists():
        return cwd_seeders

    # Try fetching from remote repository
    try:
        from sum.setup.remote_seeders import resolve_seeders_path

        return resolve_seeders_path()
    except ImportError:
        pass  # remote_seeders module not available
    except SetupError:
        pass  # Seeders fetch failed, continue without

    return None


def _resolve_content_profile_dir(profile: str, repo_root: Path | None) -> Path | None:
    """Resolve the content profile directory.

    Resolution order:
    1. Monorepo content directory (repo_root/content/<profile>/)
    2. Current working directory (./content/<profile>/)
    3. Remote fetch from sum-platform repository (cached alongside seeders)

    Returns None if profile cannot be found (will skip content copy).
    """
    if repo_root is not None:
        repo_content = repo_root / "content" / profile
        if repo_content.is_dir():
            return repo_content

    cwd_content = (Path.cwd() / "content" / profile).resolve()
    if cwd_content.is_dir():
        return cwd_content

    # Try getting from remote cache (fetched alongside seeders)
    try:
        from sum.setup.remote_seeders import get_content_path

        content_root = get_content_path()
        if content_root is not None:
            profile_dir = content_root / profile
            if profile_dir.is_dir():
                return profile_dir
    except ImportError:
        pass  # remote_seeders module not available

    return None


def _copy_seeders_and_content(
    project_path: Path,
    seeders_dir: Path | None,
    content_profile_dir: Path | None,
    profile: str,
) -> None:
    """Copy seeders package and content profile to scaffolded project."""
    ignore = shutil.ignore_patterns("__pycache__", "*.pyc")

    if seeders_dir is not None:
        target_seeders = project_path / "seeders"
        shutil.copytree(seeders_dir, target_seeders, ignore=ignore)

    if content_profile_dir is not None:
        # Create content/<profile>/ structure
        target_content = project_path / "content" / profile
        target_content.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(content_profile_dir, target_content, ignore=ignore)


def _configure_ci_workflows(project_path: Path, git_provider: str | None) -> None:
    """Keep only the CI workflow directory for the configured git provider.

    Boilerplate contains both .github/workflows/ and .gitea/workflows/.
    This removes the one that doesn't match the git_provider.

    Args:
        project_path: Path to the project.
        git_provider: "github", "gitea", or None (defaults to github).
    """
    github_dir = project_path / ".github"
    gitea_dir = project_path / ".gitea"

    provider = git_provider or "github"

    if provider == "gitea":
        # Remove GitHub workflows, keep Gitea
        if github_dir.exists():
            shutil.rmtree(github_dir)
    else:
        # Remove Gitea workflows, keep GitHub (default)
        if gitea_dir.exists():
            shutil.rmtree(gitea_dir)


def _rewrite_core_source(
    project_path: Path,
    dev: bool,
    core_ref: str | None,
) -> None:
    """Rewrite the sum-core line in requirements.txt based on overrides.

    Resolution order (first match wins):
    1. SUM_CORE_SOURCE environment variable (always wins)
    2. dev=True → editable install from monorepo (absolute path)
    3. core_ref → git install at specific branch/tag
    4. Default → keep boilerplate's pinned version (no rewrite)

    For --dev, monorepo detection uses the current working directory (where
    the CLI was invoked), not the scaffold target directory. The generated
    requirement uses an absolute path so pip resolves it correctly regardless
    of working directory.

    Args:
        project_path: Path to the scaffolded project.
        dev: If True, use editable install from monorepo.
        core_ref: Git ref (tag/branch) for sum-core install.

    Raises:
        SetupError: If dev mode requested but monorepo not found,
            or if the sum-core line is missing from requirements.txt.
    """
    env_source = os.getenv("SUM_CORE_SOURCE")
    if env_source:
        new_line = env_source.strip()
    elif dev:
        # Detect monorepo from cwd (where the user ran the command), not from
        # the scaffold target dir which may be /srv/sum/<slug>/.
        cwd_repo_root = find_monorepo_root(Path.cwd())
        if cwd_repo_root is None:
            raise SetupError(
                "--dev requires running from inside the monorepo "
                "(could not detect monorepo root from current directory)"
            )
        core_path = (cwd_repo_root / "core").resolve()
        new_line = f"-e {core_path}"
    elif core_ref is not None:
        new_line = f"sum-core @ git+{SUM_CORE_GIT_URL}@{core_ref}#subdirectory=core"
    else:
        return  # Keep boilerplate default

    requirements_file = project_path / "requirements.txt"
    content = requirements_file.read_text(encoding="utf-8")
    lines = content.splitlines(keepends=True)

    replaced = False
    new_lines: list[str] = []
    for line in lines:
        if line.strip().startswith("sum-core @"):
            new_lines.append(new_line + "\n")
            replaced = True
        else:
            new_lines.append(line)

    if not replaced:
        raise SetupError(
            "sum-core line not found in requirements.txt "
            "— boilerplate may be corrupted"
        )

    requirements_file.write_text("".join(new_lines), encoding="utf-8")


def scaffold_project(
    project_name: str,
    clients_dir: Path,
    theme_slug: str = DEFAULT_THEME_SLUG,
    seed_profile: str = "starter",
    git_provider: str | None = None,
    dev: bool = False,
    core_ref: str | None = None,
) -> Path:
    try:
        naming = validate_project_name(project_name)
    except ValueError as exc:
        raise SetupError(str(exc)) from exc

    project_path: Path = clients_dir / naming.slug
    if project_path.exists():
        raise SetupError(f"Target directory already exists: {project_path}")

    repo_root = find_monorepo_root(clients_dir)

    try:
        theme_manifest, theme_source_dir = _get_theme(theme_slug, repo_root)
    except ThemeNotFoundError as exc:
        raise SetupError(f"Theme '{theme_slug}' does not exist.") from exc
    except ThemeValidationError as exc:
        raise SetupError(f"Theme '{theme_slug}' is invalid: {exc}") from exc

    # Resolve seeders and content profile for the seed command
    seeders_dir = _resolve_seeders_dir(repo_root)
    content_profile_dir = _resolve_content_profile_dir(seed_profile, repo_root)

    boilerplate_source = _resolve_boilerplate_source(repo_root)

    try:
        clients_dir.mkdir(parents=True, exist_ok=True)
        boilerplate_ignore = shutil.ignore_patterns("__pycache__", "*.pyc")
        if isinstance(boilerplate_source, Path):
            if not is_boilerplate_dir(boilerplate_source):
                raise SetupError(
                    f"Boilerplate missing or malformed at: {boilerplate_source}"
                )
            shutil.copytree(
                boilerplate_source,
                project_path,
                dirs_exist_ok=False,
                ignore=boilerplate_ignore,
            )
        else:
            with importlib.resources.as_file(boilerplate_source) as bp_path:
                bp_path = Path(bp_path)
                if not is_boilerplate_dir(bp_path):
                    raise SetupError("Packaged boilerplate missing or malformed.")
                shutil.copytree(
                    bp_path,
                    project_path,
                    dirs_exist_ok=False,
                    ignore=boilerplate_ignore,
                )
    except FileExistsError as exc:
        raise SetupError(f"Target directory already exists: {project_path}") from exc
    except SetupError:
        raise
    except Exception as exc:
        raise SetupError(f"Failed to copy boilerplate: {exc}") from exc

    try:
        _rename_project_package_dir(project_path, naming)
        _replace_placeholders(project_path, naming)
        _rewrite_core_source(project_path, dev, core_ref)
        _create_env_from_example(project_path)
        _configure_ci_workflows(project_path, git_provider)
        _copy_theme_to_active(project_path, theme_source_dir, theme_slug)
        _write_theme_config(project_path, theme_slug, theme_manifest.version)
        _copy_seeders_and_content(
            project_path, seeders_dir, content_profile_dir, seed_profile
        )
    except Exception as exc:
        try:
            safe_rmtree(project_path, tmp_root=None, repo_root=repo_root)
        except Exception:
            # Cleanup failures should not mask the original init error.
            pass
        raise SetupError(f"Project created but failed to finalize init: {exc}") from exc

    return project_path


def validate_project_structure(project_path: Path) -> None:
    if not project_path.is_dir():
        raise SetupError(f"Project directory does not exist: {project_path}")

    required_files = [
        project_path / "manage.py",
        project_path / "pytest.ini",
        project_path / ".env",
        project_path / ".env.example",
    ]
    for path in required_files:
        if not path.exists():
            raise SetupError(f"Missing required file: {path}")

    theme_dir = project_path / "theme" / "active"
    if not theme_dir.is_dir():
        raise SetupError(f"Missing active theme directory: {theme_dir}")

    theme_config = project_path / ".sum" / "theme.json"
    if not theme_config.is_file():
        raise SetupError(f"Missing theme config: {theme_config}")
