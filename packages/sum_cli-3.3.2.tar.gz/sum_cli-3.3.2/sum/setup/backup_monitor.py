"""Backup monitoring with email alerts.

Checks backup freshness for all managed PostgreSQL sites and sends alerts
when backups are stale (>48 hours old).
"""

from __future__ import annotations

import logging
import shutil
import smtplib
import socket
import subprocess
import time
from email.mime.text import MIMEText
from pathlib import Path

from sum.setup.ports import load_allocated_ports
from sum.system_config import AlertsConfig, ConfigurationError, get_system_config
from sum.utils.output import OutputFormatter

# Maximum age in seconds before backup is considered stale (48 hours)
MAX_BACKUP_AGE_SECONDS = 48 * 60 * 60


def _get_backup_age(site_dir: Path) -> int | None:
    """Get age of last successful backup in seconds.

    Args:
        site_dir: Site directory containing backup_status file.

    Returns:
        Age in seconds, or None if no backup status found.
    """
    marker_file = site_dir / "backup_status"
    if not marker_file.exists():
        return None

    try:
        timestamp = int(marker_file.read_text().strip())
        return int(time.time()) - timestamp
    except (ValueError, OSError):
        return None


def _format_age(seconds: int) -> str:
    """Format age in human-readable form.

    Args:
        seconds: Age in seconds.

    Returns:
        Human-readable string like "2 days, 3 hours".
    """
    days = seconds // 86400
    hours = (seconds % 86400) // 3600
    if days > 0:
        return f"{days} day{'s' if days != 1 else ''}, {hours} hour{'s' if hours != 1 else ''}"
    return f"{hours} hour{'s' if hours != 1 else ''}"


def _send_via_sendmail(msg: MIMEText) -> bool:
    """Send email using local sendmail binary.

    Args:
        msg: Prepared email message.

    Returns:
        True if sendmail succeeded, False otherwise.
    """
    sendmail = shutil.which("sendmail")
    if not sendmail:
        logging.getLogger(__name__).debug("sendmail binary not found on PATH")
        return False
    try:
        result = subprocess.run(
            [sendmail, "-t"],
            input=msg.as_string(),
            text=True,
            capture_output=True,
            timeout=30,
        )
        if result.returncode != 0:
            logging.getLogger(__name__).debug(
                f"sendmail exited with code {result.returncode}: "
                f"{result.stderr.strip()}"
            )
        return result.returncode == 0
    except (subprocess.SubprocessError, OSError) as exc:
        logging.getLogger(__name__).debug(f"sendmail failed: {exc}")
        return False


def _send_via_smtp(
    msg: MIMEText,
    host: str,
    port: int,
    username: str = "",
    password: str = "",
    use_tls: bool = False,
) -> bool:
    """Send email via SMTP.

    Args:
        msg: Prepared email message.
        host: SMTP server hostname.
        port: SMTP server port.
        username: SMTP auth username (empty to skip auth).
        password: SMTP auth password (empty to skip auth).
        use_tls: Whether to use TLS. Port 465 always uses implicit TLS
                 (SMTP_SSL) regardless of this flag. Other ports use STARTTLS
                 when True.

    Returns:
        True if email sent successfully, False otherwise.
    """
    logger = logging.getLogger(__name__)
    if username and password and not use_tls and port != 465:
        logger.debug("Refusing to send SMTP credentials without TLS")
        return False
    try:
        if port == 465:
            with smtplib.SMTP_SSL(host, port, timeout=30) as smtp:
                if username and password:
                    smtp.login(username, password)
                smtp.send_message(msg)
        else:
            with smtplib.SMTP(host, port, timeout=30) as smtp:
                if use_tls:
                    smtp.starttls()
                if username and password:
                    smtp.login(username, password)
                smtp.send_message(msg)
        return True
    except (OSError, smtplib.SMTPException) as exc:
        logger.debug(f"SMTP send failed ({host}:{port}): {exc}")
        return False


def _send_alert_email(
    alerts_config: AlertsConfig,
    subject: str,
    body: str,
) -> bool:
    """Send alert email using configured delivery method.

    When an external SMTP relay is configured, sends directly via SMTP.
    Otherwise, tries local sendmail first, then falls back to localhost SMTP.

    Args:
        alerts_config: Alert configuration with email and SMTP settings.
        subject: Email subject.
        body: Email body text.

    Returns:
        True if email sent successfully, False otherwise.
    """
    # Validate headers to prevent email header injection
    for field_name, value in [
        ("from_address", alerts_config.from_address),
        ("email", alerts_config.email),
        ("subject", subject),
    ]:
        if "\r" in value or "\n" in value:
            logging.getLogger(__name__).debug(
                f"Invalid characters in {field_name}: {value!r}"
            )
            return False

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = alerts_config.from_address
    msg["To"] = alerts_config.email

    if alerts_config.has_external_smtp:
        return _send_via_smtp(
            msg,
            host=alerts_config.smtp_host,
            port=alerts_config.smtp_port,
            username=alerts_config.smtp_username,
            password=alerts_config.get_smtp_password(),
            use_tls=alerts_config.smtp_use_tls,
        )

    # Local delivery: try sendmail first, fall back to localhost SMTP
    if _send_via_sendmail(msg):
        return True
    return _send_via_smtp(msg, host="localhost", port=25)


def check_all_backups() -> dict[str, dict]:
    """Check backup status for all managed PostgreSQL sites.

    Returns:
        Dictionary mapping site slug to status info:
        {
            "acme": {
                "status": "ok" | "stale" | "missing",
                "age_seconds": int | None,
                "age_human": str | None,
            }
        }
    """
    try:
        config = get_system_config()
    except ConfigurationError:
        return {}

    # Get all sites with managed PostgreSQL clusters
    ports = load_allocated_ports(config)
    results = {}

    for site_slug in ports:
        site_dir = config.get_site_dir(site_slug)
        age = _get_backup_age(site_dir)

        if age is None:
            results[site_slug] = {
                "status": "missing",
                "age_seconds": None,
                "age_human": None,
            }
        elif age > MAX_BACKUP_AGE_SECONDS:
            results[site_slug] = {
                "status": "stale",
                "age_seconds": age,
                "age_human": _format_age(age),
            }
        else:
            results[site_slug] = {
                "status": "ok",
                "age_seconds": age,
                "age_human": _format_age(age),
            }

    return results


def run_backup_monitor(send_alerts: bool = True, verbose: bool = False) -> int:
    """Run backup monitoring check and optionally send alerts.

    Args:
        send_alerts: Whether to send email alerts for stale backups.
        verbose: Print status for all sites, not just problems.

    Returns:
        Exit code (0 if all OK, 1 if any problems found).
    """
    try:
        config = get_system_config()
    except ConfigurationError as exc:
        OutputFormatter.error(str(exc))
        return 1

    if not config.backups:
        OutputFormatter.error("Backups not configured in system config.")
        return 1

    results = check_all_backups()

    if not results:
        OutputFormatter.info("No managed PostgreSQL sites found.")
        return 0

    # Collect problems
    stale_sites = []
    missing_sites = []

    for site_slug, info in results.items():
        if info["status"] == "stale":
            stale_sites.append((site_slug, info["age_human"]))
            OutputFormatter.error(
                f"{site_slug}: backup stale ({info['age_human']} old)"
            )
        elif info["status"] == "missing":
            missing_sites.append(site_slug)
            OutputFormatter.error(f"{site_slug}: no backup status found")
        elif verbose:
            OutputFormatter.success(f"{site_slug}: OK ({info['age_human']} old)")

    # Send alert if problems found
    if send_alerts and (stale_sites or missing_sites):
        hostname = socket.gethostname()
        subject = f"[BACKUP ALERT] {hostname}: {len(stale_sites) + len(missing_sites)} site(s) need attention"

        body_lines = [
            f"Backup monitoring alert from {hostname}",
            "",
            f"Checked at: {time.strftime('%Y-%m-%d %H:%M:%S')}",
            "",
        ]

        if stale_sites:
            body_lines.append("STALE BACKUPS (>48 hours old):")
            for site, age in stale_sites:
                body_lines.append(f"  - {site}: {age} old")
            body_lines.append("")

        if missing_sites:
            body_lines.append("MISSING BACKUP STATUS:")
            for site in missing_sites:
                body_lines.append(f"  - {site}")
            body_lines.append("")

        body_lines.extend(
            [
                "Action required: Check backup cron jobs and pgBackRest status.",
                "",
                "Commands to investigate:",
                "  sum-platform backup <site> --check",
                "  sum-platform restore <site> --list",
            ]
        )

        body = "\n".join(body_lines)

        if _send_alert_email(config.backups.alerts, subject, body):
            OutputFormatter.info(f"Alert email sent to {config.backups.alerts.email}")
        else:
            OutputFormatter.warning(
                f"Failed to send alert email to {config.backups.alerts.email}"
            )

    if stale_sites or missing_sites:
        return 1

    if verbose:
        OutputFormatter.success("All backups are healthy.")
    return 0


def _describe_delivery_method(alerts_config: AlertsConfig) -> str:
    """Describe the email delivery method in human-readable form.

    Args:
        alerts_config: Alert configuration.

    Returns:
        Description like "smtp.resend.com:587 (STARTTLS)" or
        "local sendmail / localhost:25".
    """
    if alerts_config.has_external_smtp:
        host = alerts_config.smtp_host
        port = alerts_config.smtp_port
        if port == 465:
            tls_desc = "implicit TLS"
        elif alerts_config.smtp_use_tls:
            tls_desc = "STARTTLS"
        else:
            tls_desc = "plain"
        return f"{host}:{port} ({tls_desc})"
    return "local sendmail / localhost:25"


def send_test_email(verbose: bool = False) -> int:
    """Send a test email to verify alert delivery configuration.

    Args:
        verbose: Enable debug logging for troubleshooting.

    Returns:
        Exit code (0 on success, 1 on failure).
    """
    try:
        config = get_system_config()
    except ConfigurationError as exc:
        OutputFormatter.error(str(exc))
        return 1

    if not config.backups:
        OutputFormatter.error("Backups not configured in system config.")
        OutputFormatter.info("Run 'sum-platform setup' to configure backup alerts.")
        return 1

    alerts = config.backups.alerts
    hostname = socket.gethostname()
    subject = f"[TEST] {hostname}: Email delivery test"
    body = (
        f"This is a test email from sum-platform on {hostname}.\n"
        f"\n"
        f"Sent at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"\n"
        f"If you received this, email alerts are working correctly.\n"
    )

    method = _describe_delivery_method(alerts)

    OutputFormatter.info("Email delivery test")
    OutputFormatter.info(f"  From: {alerts.from_address}")
    OutputFormatter.info(f"  To:   {alerts.email}")
    OutputFormatter.info(f"  Via:  {method}")

    debug_handler = None
    module_logger = logging.getLogger(__name__)
    original_level = module_logger.level
    if verbose:
        module_logger.setLevel(logging.DEBUG)
        debug_handler = logging.StreamHandler()
        debug_handler.setFormatter(logging.Formatter("%(name)s: %(message)s"))
        module_logger.addHandler(debug_handler)

    try:
        if _send_alert_email(alerts, subject, body):
            OutputFormatter.success(
                f"Test email sent successfully. Check inbox for: {subject}"
            )
            return 0

        OutputFormatter.error("Test email failed.")
        if not verbose:
            OutputFormatter.info("Run with -v for debug output.")
        return 1
    finally:
        if debug_handler is not None:
            module_logger.removeHandler(debug_handler)
            module_logger.setLevel(original_level)
