"""Infrastructure provisioning for SUM Platform sites.

Handles Postgres database creation, systemd service installation,
Caddy configuration, and directory structure setup.
"""

from __future__ import annotations

import os
import pwd
import secrets
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from sum.exceptions import SetupError
from sum.system_config import SystemConfig, get_system_config
from sum.utils.output import OutputFormatter


def escape_env_value(value: str) -> str:
    """Escape a value for safe inclusion in a .env file.

    Uses single quotes by default because python-dotenv treats them as
    literal (no interpolation of ``$``, no backslash processing).  Falls
    back to double quotes only when the value contains a single quote,
    newline, or carriage return — characters that require escape-sequence
    support only available in double-quoted mode.
    """
    needs_double = "'" in value or "\n" in value or "\r" in value
    if not needs_double:
        return f"'{value}'"
    # Double-quote mode: escape \, ", \n, \r.  Do NOT escape $ or `
    # because python-dotenv does not recognise \$ or \` as escapes and
    # would pass the backslash through literally.
    # WARNING: If .env is sourced by a POSIX shell, $ and backtick will be expanded.
    escaped = value.replace("\\", "\\\\")
    escaped = escaped.replace('"', '\\"')
    escaped = escaped.replace("\n", "\\n").replace("\r", "\\r")
    return f'"{escaped}"'


def generate_password(length: int = 32) -> str:
    """Generate a cryptographically secure password.

    Uses secrets.token_urlsafe() for strong entropy (~6 bits per character).
    """
    # token_urlsafe(n) returns ~4/3 * n characters; request enough to slice
    return secrets.token_urlsafe(length)[:length]


def generate_secret_key(length: int = 50) -> str:
    """Generate a Django SECRET_KEY with strong entropy.

    Django recommends at least 50 characters. Uses secrets.token_urlsafe()
    for high-entropy, URL-safe output.
    """
    return secrets.token_urlsafe(length)[:length]


@dataclass
class InfrastructureCheck:
    """Result of infrastructure prerequisites check."""

    has_sudo: bool
    has_postgres: bool
    has_gh_cli: bool
    has_git: bool
    has_systemctl: bool
    has_deploy_user: bool = True
    errors: list[str] = field(default_factory=list)

    @property
    def can_proceed(self) -> bool:
        """Whether we have minimum requirements to proceed."""
        return (
            self.has_sudo
            and self.has_postgres
            and self.has_git
            and self.has_deploy_user
        )

    def require_all(self) -> None:
        """Raise SetupError if any critical prerequisites are missing."""
        if self.errors:
            raise SetupError(
                "Infrastructure prerequisites not met:\n  - "
                + "\n  - ".join(self.errors)
            )


def check_infrastructure() -> InfrastructureCheck:
    """Check all infrastructure prerequisites."""
    errors: list[str] = []

    # Check if running as root or with sudo capability
    has_sudo = os.geteuid() == 0
    if not has_sudo:
        errors.append(
            "This command requires root privileges. Run with: sudo sum-platform init ..."
        )

    # Check postgres
    has_postgres = shutil.which("psql") is not None
    if not has_postgres:
        errors.append("PostgreSQL client (psql) not found in PATH")

    # Check git
    has_git = shutil.which("git") is not None
    if not has_git:
        errors.append("git not found in PATH")

    # Check gh CLI (optional but noted)
    has_gh_cli = shutil.which("gh") is not None

    # Check systemctl
    has_systemctl = shutil.which("systemctl") is not None
    if not has_systemctl:
        errors.append("systemctl not found - systemd service installation will fail")

    # Check deploy user exists (required for systemd service)
    has_deploy_user = _check_user_exists("deploy")
    if not has_deploy_user:
        errors.append(
            "Deploy user 'deploy' not found. Create with: "
            "sudo useradd -r -s /bin/false -d /srv/sum deploy && "
            "sudo usermod -aG www-data deploy"
        )

    return InfrastructureCheck(
        has_sudo=has_sudo,
        has_postgres=has_postgres,
        has_gh_cli=has_gh_cli,
        has_git=has_git,
        has_systemctl=has_systemctl,
        has_deploy_user=has_deploy_user,
        errors=errors,
    )


def _check_user_exists(username: str) -> bool:
    """Check if a system user exists."""
    try:
        pwd.getpwnam(username)
        return True
    except KeyError:
        return False


@dataclass
class SiteCredentials:
    """Credentials generated for a new site."""

    db_name: str
    db_user: str
    db_password: str
    django_secret_key: str
    superuser_username: str
    superuser_email: str
    superuser_password: str
    postgres_port: int = 5432


def generate_site_credentials(
    site_slug: str,
    superuser_username: str = "admin",
    superuser_email: str | None = None,
) -> SiteCredentials:
    """Generate all credentials needed for a new site."""
    config = get_system_config()

    if superuser_email is None:
        domain = config.get_site_domain(site_slug)
        superuser_email = f"admin@{domain}"

    return SiteCredentials(
        db_name=config.get_db_name(site_slug),
        db_user=config.get_db_user(site_slug),
        db_password=generate_password(),
        django_secret_key=generate_secret_key(),
        superuser_username=superuser_username,
        superuser_email=superuser_email,
        superuser_password=generate_password(16),
    )


def create_site_directories(site_slug: str, config: SystemConfig | None = None) -> Path:
    """Create the directory structure for a new site.

    Creates:
        /srv/sum/<slug>/
        ├── app/          # Django project (empty, filled by scaffold)
        ├── static/       # collectstatic output
        ├── media/        # uploads
        └── backups/      # DB backups

    Note: venv/ is created later by VenvManager to avoid empty directory issues.

    Returns:
        Path to the site root directory.

    Raises:
        SetupError: If directory already exists or cannot be created.
    """
    if config is None:
        config = get_system_config()

    site_dir = config.get_site_dir(site_slug)

    if site_dir.exists():
        raise SetupError(f"Site directory already exists: {site_dir}")

    try:
        site_dir.mkdir(parents=True, mode=0o755)
        (site_dir / "app").mkdir(mode=0o755)
        # Note: venv/ is created by VenvManager, not here
        (site_dir / "static").mkdir(mode=0o755)
        (site_dir / "media").mkdir(mode=0o755)
        (site_dir / "backups").mkdir(mode=0o755)
    except OSError as exc:
        raise SetupError(f"Failed to create site directories: {exc}") from exc

    return site_dir


def create_postgres_database(
    credentials: SiteCredentials, config: SystemConfig | None = None
) -> None:
    """Create Postgres database and user for the site.

    Uses peer authentication (running as postgres user via sudo).
    Uses psql variable substitution to avoid SQL injection.
    """
    if config is None:
        config = get_system_config()

    postgres_port = str(config.defaults.postgres_port)

    # Use psql variable substitution to safely pass credentials
    # :"var" is substituted as an identifier; :'var' is substituted as a string literal
    create_user_sql = "CREATE USER :\"db_user\" WITH PASSWORD :'db_password';"
    create_db_sql = 'CREATE DATABASE :"db_name" OWNER :"db_user";'
    grant_sql = 'GRANT ALL PRIVILEGES ON DATABASE :"db_name" TO :"db_user";'

    # Common args for psql with variable bindings and port
    psql_base = ["sudo", "-u", "postgres", "psql", "-p", postgres_port]
    psql_vars = [
        "-v",
        f"db_user={credentials.db_user}",
        "-v",
        f"db_name={credentials.db_name}",
    ]

    # Password set via stdin to avoid /proc exposure
    password_escaped = credentials.db_password.replace("'", "''")
    password_preamble = f"\\set db_password '{password_escaped}'\n"

    try:
        # Run as postgres user, piping SQL via stdin for variable substitution
        # (psql variable substitution with :var only works via stdin, not -c flag)
        for sql in [create_user_sql, create_db_sql, grant_sql]:
            subprocess.run(
                psql_base + psql_vars,
                input=password_preamble + sql,
                check=True,
                capture_output=True,
                text=True,
            )
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr or ""
        # Check if it's just "already exists" errors
        if "already exists" in stderr:
            OutputFormatter.warning(f"Database or user may already exist: {stderr}")
        else:
            raise SetupError(f"Failed to create Postgres database: {stderr}") from exc


def write_env_file(
    site_dir: Path,
    site_slug: str,
    credentials: SiteCredentials,
    config: SystemConfig | None = None,
) -> Path:
    """Generate and write the .env file for the site.

    Returns:
        Path to the .env file.
    """
    if config is None:
        config = get_system_config()

    domain = config.get_site_domain(site_slug)
    env_path = site_dir / ".env"

    # Convert slug to Python package name (replace hyphens with underscores)
    python_package = site_slug.replace("-", "_")

    postgres_port = credentials.postgres_port

    secret_key = escape_env_value(credentials.django_secret_key)
    db_password = escape_env_value(credentials.db_password)

    env_content = f"""# SUM Platform Site Configuration
# Generated by sum-platform init

# Django
DJANGO_SECRET_KEY={secret_key}
DJANGO_SETTINGS_MODULE={python_package}.settings.production
DJANGO_DEBUG=False

# Database
DJANGO_DB_NAME={credentials.db_name}
DJANGO_DB_USER={credentials.db_user}
DJANGO_DB_PASSWORD={db_password}
DJANGO_DB_HOST=localhost
DJANGO_DB_PORT={postgres_port}

# Paths
DJANGO_STATIC_ROOT={site_dir}/static
DJANGO_MEDIA_ROOT={site_dir}/media

# Domain
ALLOWED_HOSTS={domain}
WAGTAILADMIN_BASE_URL=https://{domain}

# Backup status (for health check)
BACKUP_STATUS_FILE={site_dir}/backup_status
"""

    # Write with restricted permissions atomically to avoid race condition
    fd = os.open(env_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, env_content.encode())
    finally:
        os.close(fd)

    return env_path


def write_credentials_file(
    site_dir: Path,
    site_slug: str,
    credentials: SiteCredentials,
    config: SystemConfig | None = None,
) -> Path:
    """Write credentials to a file for reference.

    Returns:
        Path to the .credentials file.
    """
    if config is None:
        config = get_system_config()

    domain = config.get_site_domain(site_slug)
    creds_path = site_dir / ".credentials"

    content = f"""# SUM Platform Site Credentials
# Generated by sum-platform init
# KEEP THIS FILE SECURE

Site: {site_slug}
URL: https://{domain}
Admin URL: https://{domain}/admin/

Database:
  Name: {credentials.db_name}
  User: {credentials.db_user}
  Password: {credentials.db_password}

Django Admin:
  Username: {credentials.superuser_username}
  Email: {credentials.superuser_email}
  Password: {credentials.superuser_password}
"""

    # Write with restricted permissions atomically to avoid race condition
    fd = os.open(creds_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, content.encode())
    finally:
        os.close(fd)

    return creds_path


def fix_site_ownership(
    site_slug: str,
    config: SystemConfig | None = None,
) -> None:
    """Fix ownership of site directories for the deploy user.

    The site is created as root, but needs to be owned by deploy:www-data
    for gunicorn to run properly.

    Sets the entire site directory tree to deploy:www-data, then locks down
    .credentials to root:root 600 (contains secrets that only root should read).
    """
    if config is None:
        config = get_system_config()

    site_dir = config.get_site_dir(site_slug)
    deploy_user = config.defaults.deploy_user

    try:
        # Chown the entire site directory recursively to deploy:www-data
        subprocess.run(
            ["chown", "-R", f"{deploy_user}:www-data", str(site_dir)],
            check=True,
            capture_output=True,
        )

        # Lock down .credentials to root:root 600 (contains DB and admin passwords)
        credentials_path = site_dir / ".credentials"
        if credentials_path.exists():
            subprocess.run(
                ["chown", "root:root", str(credentials_path)],
                check=True,
                capture_output=True,
            )
            credentials_path.chmod(0o600)
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to fix site ownership: {exc.stderr}") from exc


def install_systemd_service(
    site_slug: str,
    config: SystemConfig | None = None,
) -> None:
    """Install systemd service for the site from template."""
    if config is None:
        config = get_system_config()

    template_path = config.templates.systemd_path
    if not template_path.exists():
        raise SetupError(f"Systemd template not found: {template_path}")

    template_content = template_path.read_text()

    site_dir = config.get_site_dir(site_slug)
    python_package = site_slug.replace("-", "_")

    # Replace placeholders
    service_content = template_content.replace("__SITE_SLUG__", site_slug)
    service_content = service_content.replace(
        "__DEPLOY_USER__", config.defaults.deploy_user
    )
    service_content = service_content.replace("__PROJECT_MODULE__", python_package)
    service_content = service_content.replace("__SITE_DIR__", str(site_dir))

    # Write service file
    service_name = config.get_systemd_service_name(site_slug)
    service_path = Path(f"/etc/systemd/system/{service_name}.service")

    try:
        service_path.write_text(service_content)

        # Reload systemd and enable service
        subprocess.run(["systemctl", "daemon-reload"], check=True, capture_output=True)
        subprocess.run(
            ["systemctl", "enable", service_name],
            check=True,
            capture_output=True,
        )
    except (OSError, subprocess.CalledProcessError) as exc:
        raise SetupError(f"Failed to install systemd service: {exc}") from exc


def configure_caddy(
    site_slug: str,
    config: SystemConfig | None = None,
) -> None:
    """Configure Caddy reverse proxy for the site from template."""
    if config is None:
        config = get_system_config()

    template_path = config.templates.caddy_path
    if not template_path.exists():
        raise SetupError(f"Caddy template not found: {template_path}")

    template_content = template_path.read_text()

    site_dir = config.get_site_dir(site_slug)
    domain = config.get_site_domain(site_slug)

    # Replace placeholders
    caddy_content = template_content.replace("__SITE_SLUG__", site_slug)
    caddy_content = caddy_content.replace("__DOMAIN__", domain)
    caddy_content = caddy_content.replace("__SITE_DIR__", str(site_dir))

    # Write Caddy config
    config_name = config.get_caddy_config_name(site_slug)
    caddy_dir = Path("/etc/caddy/sites-enabled")
    caddy_dir.mkdir(parents=True, exist_ok=True)
    caddy_path = caddy_dir / config_name

    try:
        caddy_path.write_text(caddy_content)

        # Reload Caddy
        subprocess.run(
            ["systemctl", "reload", "caddy"],
            check=True,
            capture_output=True,
        )
    except (OSError, subprocess.CalledProcessError) as exc:
        raise SetupError(f"Failed to configure Caddy: {exc}") from exc


def start_site_service(site_slug: str, config: SystemConfig | None = None) -> None:
    """Start the systemd service for the site."""
    if config is None:
        config = get_system_config()

    service_name = config.get_systemd_service_name(site_slug)

    try:
        subprocess.run(
            ["systemctl", "start", service_name],
            check=True,
            capture_output=True,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to start service {service_name}: {exc.stderr}"
        ) from exc


def cleanup_site(site_slug: str, config: SystemConfig | None = None) -> None:
    """Clean up a partially created site on failure.

    Best effort cleanup - logs errors but doesn't raise.
    """
    if config is None:
        config = get_system_config()

    site_dir = config.get_site_dir(site_slug)
    service_name = config.get_systemd_service_name(site_slug)
    caddy_config = config.get_caddy_config_name(site_slug)
    db_name = config.get_db_name(site_slug)
    db_user = config.get_db_user(site_slug)

    # Clean up PostgreSQL cluster and backup cron if present
    from sum.setup.backup_cron import remove_backup_cron
    from sum.setup.bare_metal_postgres import cleanup_bare_metal_postgres
    from sum.setup.ports import get_site_port

    # Check if site has an allocated PostgreSQL port (indicates managed cluster)
    if get_site_port(site_slug, config) is not None:
        postgres_version = "18"  # Default
        if config.infrastructure:
            postgres_version = config.infrastructure.postgres_version
        cleanup_bare_metal_postgres(site_slug, postgres_version, config)
        remove_backup_cron(site_slug)

    # Stop and disable service
    try:
        subprocess.run(
            ["systemctl", "stop", service_name],
            capture_output=True,
        )
        subprocess.run(
            ["systemctl", "disable", service_name],
            capture_output=True,
        )
        service_path = Path(f"/etc/systemd/system/{service_name}.service")
        if service_path.exists():
            service_path.unlink()
        subprocess.run(["systemctl", "daemon-reload"], capture_output=True)
    except Exception as exc:
        # Best-effort cleanup: log but don't fail if service cleanup fails
        OutputFormatter.warning(f"Cleanup: failed to remove systemd service: {exc}")

    # Remove Caddy config
    try:
        caddy_path = Path(f"/etc/caddy/sites-enabled/{caddy_config}")
        if caddy_path.exists():
            caddy_path.unlink()
        subprocess.run(["systemctl", "reload", "caddy"], capture_output=True)
    except Exception as exc:
        # Best-effort cleanup: log but don't fail if Caddy cleanup fails
        OutputFormatter.warning(f"Cleanup: failed to remove Caddy config: {exc}")

    # Drop database and user for sites using system PostgreSQL (not managed clusters)
    # Managed clusters are fully cleaned up by cleanup_bare_metal_postgres above
    if get_site_port(site_slug, config) is None:
        postgres_port = str(config.defaults.postgres_port)
        psql_base = ["sudo", "-u", "postgres", "psql", "-p", postgres_port]
        try:
            subprocess.run(
                psql_base + ["-v", f"db_name={db_name}"],
                input='DROP DATABASE IF EXISTS :"db_name";',
                text=True,
                capture_output=True,
            )
            subprocess.run(
                psql_base + ["-v", f"db_user={db_user}"],
                input='DROP USER IF EXISTS :"db_user";',
                text=True,
                capture_output=True,
            )
        except Exception as exc:
            # Best-effort cleanup: log but don't fail if database cleanup fails
            OutputFormatter.warning(f"Cleanup: failed to drop database/user: {exc}")

    # Remove site directory with safety validation
    try:
        resolved_site_dir = site_dir.resolve()
        # Safety checks to avoid deleting unintended paths
        if site_slug not in resolved_site_dir.parts or len(resolved_site_dir.parts) < 3:
            OutputFormatter.warning(
                f"Cleanup: refusing to remove unsafe path: {resolved_site_dir}"
            )
        elif resolved_site_dir.exists():
            shutil.rmtree(resolved_site_dir)
    except Exception as exc:
        # Best-effort cleanup: log but don't fail if directory removal fails
        OutputFormatter.warning(f"Cleanup: failed to remove site directory: {exc}")
