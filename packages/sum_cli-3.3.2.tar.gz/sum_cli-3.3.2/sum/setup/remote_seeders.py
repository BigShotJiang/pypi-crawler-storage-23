# pyright: reportUnusedCallResult=false

"""Remote seeders fetching from sum-platform repository.

The seeders package is required for content seeding but is not bundled
with the CLI package. This module fetches seeders from the sum-platform
repository when they're not available locally.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from sum.exceptions import SetupError

# Default repository URL, can be overridden via environment variable
DEFAULT_SUM_PLATFORM_REPO = "https://github.com/markashton480/sum-platform.git"
CACHE_DIR_NAME = "sum-platform"
SEEDERS_CACHE_SUBDIR = "seeders"

# Timeout for git network operations (in seconds)
GIT_NETWORK_TIMEOUT = 120

# Only these content profiles are fetched via remote sparse checkout.
# Dev-only profiles (e.g. sage-stone) must be used from within the monorepo.
REMOTE_ALLOWED_PROFILES = frozenset({"starter"})


def _get_platform_repo_url() -> str:
    """Get the platform repository URL from environment or default."""
    return os.getenv("SUM_PLATFORM_REPO", DEFAULT_SUM_PLATFORM_REPO)


def get_seeders_cache_dir() -> Path:
    """Get the seeders cache directory, creating it if needed.

    Returns:
        Path to ~/.cache/sum-platform/seeders/

    Raises:
        SetupError: If the cache directory cannot be created.
    """
    cache_root = Path.home() / ".cache" / CACHE_DIR_NAME / SEEDERS_CACHE_SUBDIR
    try:
        cache_root.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise SetupError(
            f"Failed to create seeders cache directory '{cache_root}': {exc}. "
            f"Check filesystem permissions and available disk space."
        ) from exc
    return cache_root


def get_cached_seeders(version: str = "latest") -> Path | None:
    """Check if seeders are already cached.

    Args:
        version: Version tag or 'latest' for develop branch.

    Returns:
        Path to cached seeders if they exist and are valid, None otherwise.
    """
    cache_dir = get_seeders_cache_dir()
    seeders_path = cache_dir / version
    if seeders_path.is_dir() and (seeders_path / "__init__.py").is_file():
        return seeders_path
    return None


def _run_git_command(
    args: list[str],
    cwd: Path | None = None,
    check: bool = True,
    timeout: int | None = None,
) -> subprocess.CompletedProcess[str]:
    """Run a git command and return the result."""
    cmd = ["git"] + args
    return subprocess.run(
        cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
        check=check,
        timeout=timeout,
    )


def fetch_seeders_from_repo(version: str = "latest") -> Path:
    """Fetch seeders and allowed content profiles from the sum-platform repository.

    Uses sparse checkout to fetch the seeders directory and content profiles
    listed in REMOTE_ALLOWED_PROFILES.  Caches seeders in
    ~/.cache/sum-platform/seeders/{version}/ and content alongside in
    ~/.cache/sum-platform/seeders/{version}_content/.

    Args:
        version: Version tag (e.g., 'v0.7.2') or 'latest' for develop branch.

    Returns:
        Path to the fetched (and cached) seeders directory.

    Raises:
        SetupError: If seeders cannot be fetched.
    """
    repo_url = _get_platform_repo_url()

    # Check cache first
    cached = get_cached_seeders(version)
    if cached is not None:
        return cached

    # Prepare cache directory
    cache_dir = get_seeders_cache_dir()
    version_dir = cache_dir / version

    # Determine git ref
    git_ref = "develop" if version == "latest" else version

    # Use temp directory for clone
    with tempfile.TemporaryDirectory(prefix="sum-seeders-") as tmp_dir:
        tmp_path = Path(tmp_dir)
        clone_path = tmp_path / "repo"

        try:
            # Initialize sparse checkout with timeout for network operations
            _run_git_command(
                [
                    "clone",
                    "--filter=blob:none",
                    "--sparse",
                    "--depth=1",
                    "--branch",
                    git_ref,
                    repo_url,
                    str(clone_path),
                ],
                check=True,
                timeout=GIT_NETWORK_TIMEOUT,
            )

            # Configure sparse checkout for seeders and allowed content profiles.
            # Dev-only profiles (e.g. sage-stone) are excluded from remote fetch.
            sparse_paths = ["seeders"] + [
                f"content/{p}" for p in sorted(REMOTE_ALLOWED_PROFILES)
            ]
            _run_git_command(
                ["sparse-checkout", "set", *sparse_paths],
                cwd=clone_path,
                check=True,
            )

        except subprocess.TimeoutExpired as exc:
            raise SetupError(
                f"Timeout while fetching seeders from {repo_url}. "
                f"Check your network connection."
            ) from exc
        except subprocess.CalledProcessError as exc:
            stderr = exc.stderr or ""
            raise SetupError(
                f"Failed to fetch seeders from {repo_url}: {stderr}"
            ) from exc

        # Verify seeders directory exists in checkout
        seeders_source = clone_path / "seeders"
        if not seeders_source.is_dir():
            raise SetupError(
                f"Seeders directory not found in repository at ref '{git_ref}'"
            )

        # Verify __init__.py exists
        if not (seeders_source / "__init__.py").is_file():
            raise SetupError(
                f"Seeders package at ref '{git_ref}' is missing __init__.py"
            )

        # Move to cache with error handling
        if version_dir.exists():
            try:
                shutil.rmtree(version_dir)
            except OSError as exc:
                raise SetupError(
                    f"Failed to remove existing seeders cache at '{version_dir}': {exc}"
                ) from exc

        try:
            shutil.move(str(seeders_source), str(version_dir))
        except OSError as exc:
            raise SetupError(
                f"Failed to move seeders to cache at '{version_dir}': {exc}"
            ) from exc

        # Also cache content directory alongside seeders
        content_source = clone_path / "content"
        content_dest = cache_dir / f"{version}_content"
        if content_source.is_dir():
            if content_dest.exists():
                shutil.rmtree(content_dest)
            shutil.move(str(content_source), str(content_dest))

    return version_dir


def resolve_seeders_path(version: str = "latest") -> Path:
    """Resolve seeders to a local path, fetching if needed.

    This is the main entry point for seeders resolution.

    Args:
        version: Version tag or 'latest'.

    Returns:
        Path to the seeders directory (either cached or freshly fetched).

    Raises:
        SetupError: If seeders cannot be resolved or fetched.
    """
    return fetch_seeders_from_repo(version)


def get_content_path(version: str = "latest") -> Path | None:
    """Get the path to cached content profiles for a version.

    Args:
        version: Version tag or 'latest'.

    Returns:
        Path to content directory if cached, None otherwise.
    """
    cache_dir = get_seeders_cache_dir()
    content_path = cache_dir / f"{version}_content"
    if content_path.is_dir():
        return content_path
    return None
