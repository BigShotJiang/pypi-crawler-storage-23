"""Git operations for SUM Platform sites.

Handles git init, initial commit, and remote repository creation.
Supports GitHub (via gh CLI) and Gitea (via REST API).
"""

from __future__ import annotations

import os
import shutil
import subprocess
from abc import ABC, abstractmethod
from pathlib import Path

from sum.exceptions import SetupError
from sum.site_config import GitConfig
from sum.utils.output import OutputFormatter

# =============================================================================
# Git Provider Abstraction
# =============================================================================


class GitProvider(ABC):
    """Abstract base class for git hosting providers."""

    @abstractmethod
    def is_available(self) -> bool:
        """Check if the provider is configured and accessible."""
        ...

    @abstractmethod
    def create_repo(self, app_dir: Path, repo_name: str) -> str:
        """Create a remote repository and push the code.

        Args:
            app_dir: Path to the local git repository.
            repo_name: Name for the remote repository.

        Returns:
            URL of the created repository.

        Raises:
            SetupError: If repo creation or push fails.
        """
        ...

    @abstractmethod
    def get_repo_url(self, org: str, repo_name: str) -> str:
        """Get the HTTPS URL for a repository."""
        ...

    @abstractmethod
    def get_clone_url(self, org: str, repo_name: str) -> str:
        """Get the SSH clone URL for a repository."""
        ...

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable provider name."""
        ...


class GitHubProvider(GitProvider):
    """GitHub provider using gh CLI."""

    def __init__(self, org: str) -> None:
        self.org = org

    @property
    def name(self) -> str:
        return "GitHub"

    def is_available(self) -> bool:
        """Check if gh CLI is available and authenticated."""
        if not shutil.which("gh"):
            return False

        try:
            result = subprocess.run(
                ["gh", "auth", "status"],
                capture_output=True,
                text=True,
            )
            return result.returncode == 0
        except subprocess.SubprocessError:
            return False

    def get_repo_url(self, org: str, repo_name: str) -> str:
        return f"https://github.com/{org}/{repo_name}"

    def get_clone_url(self, org: str, repo_name: str) -> str:
        return f"git@github.com:{org}/{repo_name}.git"

    def create_repo(self, app_dir: Path, repo_name: str) -> str:
        """Create a private GitHub repository and push the code."""
        if not self.is_available():
            raise SetupError(
                "GitHub CLI (gh) is not available or not authenticated. "
                "Run 'gh auth login' to authenticate, or use --no-git to skip."
            )

        try:
            subprocess.run(
                [
                    "gh",
                    "repo",
                    "create",
                    f"{self.org}/{repo_name}",
                    "--private",
                    "--source",
                    str(app_dir),
                    "--push",
                ],
                cwd=app_dir,
                check=True,
                capture_output=True,
                text=True,
            )

            return self.get_repo_url(self.org, repo_name)

        except subprocess.CalledProcessError as exc:
            stderr = exc.stderr or ""
            if "already exists" in stderr.lower():
                OutputFormatter.warning(
                    f"Repository {self.org}/{repo_name} already exists, "
                    "attempting to push..."
                )
                return self._push_to_existing_repo(app_dir, repo_name)
            raise SetupError(f"Failed to create GitHub repository: {stderr}") from exc

    def _push_to_existing_repo(self, app_dir: Path, repo_name: str) -> str:
        """Push to an existing GitHub repository."""
        repo_url = self.get_repo_url(self.org, repo_name)

        try:
            result = subprocess.run(
                ["git", "remote", "get-url", "origin"],
                cwd=app_dir,
                capture_output=True,
                text=True,
            )

            if result.returncode != 0:
                subprocess.run(
                    [
                        "git",
                        "remote",
                        "add",
                        "origin",
                        self.get_clone_url(self.org, repo_name),
                    ],
                    cwd=app_dir,
                    check=True,
                    capture_output=True,
                )

            subprocess.run(
                ["git", "push", "-u", "origin", "main"],
                cwd=app_dir,
                check=True,
                capture_output=True,
            )

            return repo_url

        except subprocess.CalledProcessError as exc:
            raise SetupError(
                f"Failed to push to existing repository: {exc.stderr}"
            ) from exc


class GiteaProvider(GitProvider):
    """Gitea provider using REST API."""

    def __init__(
        self,
        org: str,
        base_url: str,
        ssh_port: int = 22,
        token_env: str = "GITEA_TOKEN",
    ) -> None:
        self.org = org
        self.base_url = base_url.rstrip("/")
        self.ssh_port = ssh_port
        self.token_env = token_env

    @property
    def name(self) -> str:
        return "Gitea"

    def _get_token(self) -> str | None:
        """Get the API token from environment."""
        return os.environ.get(self.token_env)

    def is_available(self) -> bool:
        """Check if Gitea is configured with a valid token."""
        if not self.base_url or not self.org:
            return False
        return self._get_token() is not None

    def get_repo_url(self, org: str, repo_name: str) -> str:
        return f"{self.base_url}/{org}/{repo_name}"

    def get_clone_url(self, org: str, repo_name: str) -> str:
        """Get SSH clone URL for a repository.

        Uses ssh:// URL format when custom port is specified,
        otherwise uses standard git@host:path format.
        """
        from urllib.parse import urlparse

        parsed = urlparse(self.base_url)
        host = parsed.netloc

        if self.ssh_port != 22:
            # Non-standard port requires ssh:// URL format
            return f"ssh://git@{host}:{self.ssh_port}/{org}/{repo_name}.git"
        else:
            # Standard port 22 can use short format
            return f"git@{host}:{org}/{repo_name}.git"

    def create_repo(self, app_dir: Path, repo_name: str) -> str:
        """Create a private Gitea repository and push the code."""
        token = self._get_token()
        if not token:
            raise SetupError(
                f"Gitea API token not found. Set the {self.token_env} environment "
                "variable, or use --no-git to skip repository creation."
            )

        try:
            import httpx
        except ImportError:
            raise SetupError(
                "httpx is required for Gitea support. "
                "Install with: pip install sum-cli[gitea]"
            ) from None

        # Create repository via API
        api_url = f"{self.base_url}/api/v1/orgs/{self.org}/repos"
        headers = {
            "Authorization": f"token {token}",
            "Content-Type": "application/json",
        }
        payload = {
            "name": repo_name,
            "private": True,
            "auto_init": False,
        }

        try:
            response = httpx.post(api_url, json=payload, headers=headers, timeout=30.0)

            if response.status_code == 409:
                # Repository already exists
                OutputFormatter.warning(
                    f"Repository {self.org}/{repo_name} already exists, "
                    "attempting to push..."
                )
                return self._push_to_existing_repo(app_dir, repo_name)

            if response.status_code not in (200, 201):
                error_msg = response.text
                try:
                    error_data = response.json()
                except ValueError:
                    # Response body is not JSON; fall back to raw text message.
                    pass
                else:
                    error_msg = error_data.get("message", response.text)
                raise SetupError(
                    f"Failed to create Gitea repository: {error_msg} "
                    f"(HTTP {response.status_code})"
                )

            # Add remote and push
            return self._setup_remote_and_push(app_dir, repo_name)

        except httpx.RequestError as exc:
            raise SetupError(
                f"Failed to connect to Gitea at {self.base_url}: {exc}"
            ) from exc

    def _setup_remote_and_push(self, app_dir: Path, repo_name: str) -> str:
        """Set up git remote and push to Gitea."""
        clone_url = self.get_clone_url(self.org, repo_name)

        try:
            # Add remote
            subprocess.run(
                ["git", "remote", "add", "origin", clone_url],
                cwd=app_dir,
                check=True,
                capture_output=True,
            )

            # Push
            subprocess.run(
                ["git", "push", "-u", "origin", "main"],
                cwd=app_dir,
                check=True,
                capture_output=True,
            )

            return self.get_repo_url(self.org, repo_name)

        except subprocess.CalledProcessError as exc:
            raise SetupError(f"Failed to push to Gitea: {exc.stderr}") from exc

    def _push_to_existing_repo(self, app_dir: Path, repo_name: str) -> str:
        """Push to an existing Gitea repository."""
        try:
            result = subprocess.run(
                ["git", "remote", "get-url", "origin"],
                cwd=app_dir,
                capture_output=True,
                text=True,
            )

            if result.returncode != 0:
                subprocess.run(
                    [
                        "git",
                        "remote",
                        "add",
                        "origin",
                        self.get_clone_url(self.org, repo_name),
                    ],
                    cwd=app_dir,
                    check=True,
                    capture_output=True,
                )

            subprocess.run(
                ["git", "push", "-u", "origin", "main"],
                cwd=app_dir,
                check=True,
                capture_output=True,
            )

            return self.get_repo_url(self.org, repo_name)

        except subprocess.CalledProcessError as exc:
            raise SetupError(
                f"Failed to push to existing repository: {exc.stderr}"
            ) from exc


# =============================================================================
# Provider Factory
# =============================================================================


def get_git_provider(
    provider: str,
    org: str,
    gitea_url: str | None = None,
    gitea_ssh_port: int = 22,
    gitea_token_env: str = "GITEA_TOKEN",
) -> GitProvider:
    """Create a git provider instance.

    Args:
        provider: "github" or "gitea"
        org: Organization/namespace
        gitea_url: Gitea instance URL (required if provider=gitea)
        gitea_ssh_port: SSH port for Gitea
        gitea_token_env: Env var name for Gitea API token

    Returns:
        GitProvider instance for the specified provider.

    Raises:
        ValueError: If provider is gitea but gitea_url not provided.
    """
    if provider == "gitea":
        if not gitea_url:
            raise ValueError("gitea_url required when provider is 'gitea'")
        return GiteaProvider(
            org=org,
            base_url=gitea_url,
            ssh_port=gitea_ssh_port,
            token_env=gitea_token_env,
        )
    return GitHubProvider(org=org)


def get_git_provider_from_config(git_config: GitConfig) -> GitProvider:
    """Create a git provider from a GitConfig object."""
    return get_git_provider(
        provider=git_config.provider,
        org=git_config.org,
        gitea_url=git_config.url,
        gitea_ssh_port=git_config.ssh_port,
        gitea_token_env=git_config.token_env,
    )


# =============================================================================
# Public API
# =============================================================================


def init_git_repo(app_dir: Path) -> None:
    """Initialize a git repository in the app directory."""
    try:
        subprocess.run(
            ["git", "init", "-b", "main"],
            cwd=app_dir,
            check=True,
            capture_output=True,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to initialize git repository: {exc.stderr}") from exc


def _ensure_gitignore(app_dir: Path) -> None:
    """Ensure .gitignore protects sensitive files before staging."""
    gitignore = app_dir / ".gitignore"
    required_patterns = [".env", ".env.local", ".env.*.local"]

    existing_content = ""
    if gitignore.exists():
        existing_content = gitignore.read_text()

    missing = [p for p in required_patterns if p not in existing_content]
    if missing:
        OutputFormatter.warning(
            f".gitignore missing patterns: {', '.join(missing)} — adding them"
        )
        addition = "\n".join(["", "# Added by sum-platform (security)", *missing, ""])
        gitignore.write_text(existing_content + addition)


_DEFAULT_GIT_AUTHOR_NAME = "SUM Platform"
_DEFAULT_GIT_AUTHOR_EMAIL = "deploy@sum-platform.local"


def create_initial_commit(
    app_dir: Path, message: str = "Initial scaffold from sum-platform init"
) -> None:
    """Create the initial git commit with all files.

    Provides a fallback author identity so the commit succeeds on fresh
    servers that have no ``git config user.name`` / ``user.email``.
    If the system already has a git identity configured, git uses that
    instead (``-c`` values are lowest-priority).
    """
    _ensure_gitignore(app_dir)

    git_identity = [
        "git",
        "-c",
        f"user.name={_DEFAULT_GIT_AUTHOR_NAME}",
        "-c",
        f"user.email={_DEFAULT_GIT_AUTHOR_EMAIL}",
    ]

    try:
        subprocess.run(
            [*git_identity, "add", "-A"],
            cwd=app_dir,
            check=True,
            capture_output=True,
        )

        subprocess.run(
            [*git_identity, "commit", "-m", message],
            cwd=app_dir,
            check=True,
            capture_output=True,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(f"Failed to create initial commit: {exc.stderr}") from exc


def setup_git_for_site(
    app_dir: Path,
    site_slug: str,
    git_config: GitConfig | None,
) -> str | None:
    """Set up git repository for a new site.

    Args:
        app_dir: Path to the app directory.
        site_slug: The site slug (used as repo name).
        git_config: Git configuration, or None to skip remote.

    Returns:
        Remote repo URL if created, None if skipped.
    """
    # Initialize git repo
    init_git_repo(app_dir)

    # Create initial commit
    create_initial_commit(app_dir)

    if git_config is None:
        OutputFormatter.info("Skipping remote repository creation (--no-git)")
        return None

    # Get the provider from config
    provider = get_git_provider_from_config(git_config)

    # Check if provider is available
    if not provider.is_available():
        OutputFormatter.warning(
            f"{provider.name} is not available. " "Skipping repository creation."
        )
        return None

    # Create remote repo
    repo_url = provider.create_repo(app_dir, site_slug)
    return repo_url
