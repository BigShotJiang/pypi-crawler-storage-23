"""Bare metal PostgreSQL provisioning with WAL archiving.

Creates per-site PostgreSQL clusters using pg_createcluster with pgBackRest
for continuous WAL archiving to Hetzner Storage Box.

Each site gets its own PostgreSQL instance (cluster) for isolation:
- Data: /var/lib/postgresql/<version>/<slug>/
- Config: /etc/postgresql/<version>/<slug>/
- Port: Allocated from ports.py (5433-5532 range)

Templates are read from paths configured in /etc/sum/config.yml (templates section)
and use __PLACEHOLDER__ style substitution.
"""

from __future__ import annotations

import logging
import os
import re
import shlex
import subprocess
import time
from pathlib import Path

from sum.exceptions import SetupError
from sum.setup.infrastructure import SiteCredentials
from sum.setup.ports import allocate_port, deallocate_port
from sum.system_config import SystemConfig
from sum.utils.output import OutputFormatter

# Default path for the pgbackrest wrapper script
DEFAULT_PGBACKREST_WRAPPER = "/usr/local/bin/pgbackrest-wrapper"

# Absolute path to the pgbackrest binary.  Standard location on Ubuntu/Debian
# when installed via apt (postgresql-common pgdg repo).  The wrapper script
# exec's this path directly to avoid PATH dependency in archive_command.
PGBACKREST_BINARY = "/usr/bin/pgbackrest"

logger = logging.getLogger(__name__)

# Valid site_slug pattern: alphanumeric, hyphens, underscores only
# Used to prevent command injection in archive_command and other shell contexts
SITE_SLUG_PATTERN = re.compile(r"^[a-zA-Z0-9_-]+$")

# Valid SQL identifier pattern: alphanumeric and underscores only
SQL_IDENTIFIER_PATTERN = re.compile(r"^[a-zA-Z0-9_]+$")

# Safe path characters for use in shell-embedded strings (e.g. archive_command)
_SAFE_PATH_RE = re.compile(r"^[a-zA-Z0-9/_.-]+$")


def _safe_decode(data: bytes | str | None) -> str:
    """Decode bytes to str, replacing undecodable bytes.

    pgBackRest can emit binary data (compressed WAL segments, binary
    metadata) in its stdout/stderr.  Using ``text=True`` in subprocess
    would raise ``UnicodeDecodeError`` on such output.  This helper
    lets us capture raw bytes and decode them losslessly.
    """
    if data is None:
        return ""
    if isinstance(data, str):
        return data
    return data.decode("utf-8", errors="replace")


def _validate_site_slug(site_slug: str) -> None:
    """Validate site_slug contains only safe characters.

    Args:
        site_slug: Site identifier to validate

    Raises:
        SetupError: If site_slug contains invalid characters
    """
    if not SITE_SLUG_PATTERN.match(site_slug):
        raise SetupError(
            f"Invalid site_slug '{site_slug}': must contain only "
            "alphanumeric characters, hyphens, and underscores"
        )


def _validate_sql_identifier(value: str, name: str) -> None:
    """Validate a SQL identifier contains only safe characters.

    Args:
        value: Identifier value to validate
        name: Name of the field (for error messages)

    Raises:
        SetupError: If identifier contains unsafe characters
    """
    if not SQL_IDENTIFIER_PATTERN.match(value):
        raise SetupError(
            f"Invalid {name} '{value}': must contain only "
            "alphanumeric characters and underscores"
        )


def _is_port_conflict_error(exc: SetupError) -> bool:
    """Check if a SetupError from pg_createcluster is a port conflict.

    Inspects the error message for indicators that the port is already
    bound by another process.

    Args:
        exc: The SetupError raised by _create_postgres_cluster

    Returns:
        True if the error indicates a port-in-use conflict.
    """
    msg = str(exc).lower()
    return "port" in msg and ("already" in msg or "in use" in msg)


def _render_template(template_path: Path, replacements: dict[str, str]) -> str:
    """Render a template file with __PLACEHOLDER__ substitutions.

    Args:
        template_path: Path to template file
        replacements: Dict mapping placeholder names to values
                      (without the __ prefix/suffix)

    Returns:
        Rendered template content

    Raises:
        SetupError: If template file doesn't exist
    """
    if not template_path.exists():
        raise SetupError(f"Template not found: {template_path}")

    content = template_path.read_text()

    for key, value in replacements.items():
        placeholder = f"__{key}__"
        content = content.replace(placeholder, str(value))

    return content


def render_pgbackrest_wrapper_script(cipher_pass_file: str) -> str:
    """Render the pgbackrest wrapper shell script.

    The script checks the passphrase file is readable, reads it into an env
    var, and exec's pgbackrest.  Uses shell built-ins (``test -r``,
    ``read``) to avoid PATH assumptions in constrained environments like
    PostgreSQL's ``archive_command``.

    This is the **single source of truth** for the wrapper content — used
    by both local install (``install_pgbackrest_wrapper``) and remote
    install via SSH in ``promote.py``.

    Args:
        cipher_pass_file: Absolute path to the cipher passphrase file.

    Returns:
        The wrapper script as a string.
    """
    q_pass_file = shlex.quote(cipher_pass_file)
    return (
        "#!/bin/sh\n"
        "# Auto-generated by sum-platform — do not edit\n"
        "#\n"
        "# Reads the pgBackRest cipher passphrase from a single protected\n"
        "# file and exports it via environment variable so that stanza\n"
        "# config files never contain the passphrase in plaintext.\n"
        "#\n"
        "# The file must be readable by postgres (owner postgres:postgres,\n"
        "# mode 600) and contain the passphrase on a single line.\n"
        f"PASS_FILE={q_pass_file}\n"
        'if ! test -r "$PASS_FILE"; then\n'
        '  echo "pgbackrest-wrapper: cannot read passphrase file: $PASS_FILE" >&2\n'
        "  exit 1\n"
        "fi\n"
        'IFS= read -r PGBACKREST_REPO1_CIPHER_PASS < "$PASS_FILE"\n'
        "export PGBACKREST_REPO1_CIPHER_PASS\n"
        f'exec {PGBACKREST_BINARY} "$@"\n'
    )


def install_pgbackrest_wrapper(
    cipher_pass_file: str,
    wrapper_path: str = DEFAULT_PGBACKREST_WRAPPER,
) -> None:
    """Install a pgbackrest wrapper script that injects the cipher passphrase.

    The wrapper reads the passphrase from a single protected file and sets
    PGBACKREST_REPO1_CIPHER_PASS before exec'ing pgbackrest.  This avoids
    writing the passphrase into every stanza config file.

    Args:
        cipher_pass_file: Path to the cipher passphrase file (mode 600).
        wrapper_path: Where to install the wrapper script.

    Raises:
        SetupError: If the wrapper cannot be written.
    """
    script = render_pgbackrest_wrapper_script(cipher_pass_file)

    wrapper = Path(wrapper_path)
    tmp_wrapper = wrapper.with_suffix(".tmp")
    try:
        tmp_wrapper.write_text(script)
        # 750 root:postgres — only root and postgres group can execute.
        # postgres needs execute for archive_command and sudo -u postgres calls.
        tmp_wrapper.chmod(0o750)
        subprocess.run(
            ["chown", "root:postgres", str(tmp_wrapper)],
            check=True,
            capture_output=True,
        )
        os.replace(tmp_wrapper, wrapper)
    except (OSError, subprocess.CalledProcessError) as exc:
        tmp_wrapper.unlink(missing_ok=True)
        raise SetupError(
            f"Failed to install pgbackrest wrapper at {wrapper_path}: {exc}"
        ) from exc


def setup_bare_metal_postgres(
    site_slug: str,
    credentials: SiteCredentials,
    config: SystemConfig,
) -> int:
    """Provision a bare metal PostgreSQL cluster with WAL archiving.

    Creates an isolated PostgreSQL cluster for the site using pg_createcluster,
    configures WAL archiving via pgBackRest, and runs an initial backup.

    Args:
        site_slug: Site identifier (e.g., 'acme')
        credentials: Database credentials
        config: System configuration

    Returns:
        Allocated port number for the PostgreSQL cluster.

    Raises:
        SetupError: If provisioning fails.
    """
    # Validate site_slug to prevent command injection in archive_command
    _validate_site_slug(site_slug)

    out = OutputFormatter()
    out.info(f"Setting up bare metal PostgreSQL for {site_slug}")

    # Get PostgreSQL version from config
    postgres_version = "18"  # Default
    if config.infrastructure:
        postgres_version = config.infrastructure.postgres_version

    # Allocate unique port
    port = allocate_port(site_slug, config)
    out.success(f"Allocated port {port} for PostgreSQL")

    try:
        # Create PostgreSQL cluster (with one retry on port conflict)
        try:
            _create_postgres_cluster(site_slug, port, postgres_version)
        except SetupError as exc:
            if _is_port_conflict_error(exc):
                logger.warning(
                    "Port %d conflict during pg_createcluster, "
                    "deallocating and retrying with next port",
                    port,
                )
                out.warning(f"Port {port} conflict detected, retrying with next port")
                deallocate_port(site_slug, config)
                port = allocate_port(site_slug, config)
                out.success(f"Re-allocated port {port} for PostgreSQL")
                _create_postgres_cluster(site_slug, port, postgres_version)
            else:
                raise
        out.success(f"Created PostgreSQL cluster {postgres_version}/{site_slug}")

        # Configure WAL archiving in postgresql.conf
        if config.backups:
            _configure_wal_archiving(site_slug, postgres_version, config)
            out.success("Configured WAL archiving")

        # Start the cluster
        _start_cluster(site_slug, postgres_version)
        out.success("Started PostgreSQL cluster")

        # Wait for PostgreSQL to be ready
        _wait_for_postgres(port)
        out.success("PostgreSQL is ready")

        # Create database and user
        _create_database_and_user(site_slug, port, credentials)
        out.success("Created database and user")

        # Configure pgBackRest if backups are enabled
        if config.backups:
            # Verify SSH key exists
            _verify_backup_ssh_key(config)
            out.success("Verified backup SSH key")

            # Install wrapper script so pgbackrest gets the cipher
            # passphrase via environment variable instead of config files
            install_pgbackrest_wrapper(config.backups.cipher_pass_file)
            out.success("Installed pgbackrest wrapper")

            # Generate pgBackRest stanza config
            _generate_pgbackrest_stanza_config(site_slug, port, credentials, config)
            out.success("Generated pgBackRest stanza config")

            # Initialize pgBackRest stanza
            _init_pgbackrest_stanza(site_slug, config)
            out.success("Initialized pgBackRest stanza")

            # Run initial full backup
            _run_initial_backup(site_slug, config)
            out.success("Completed initial backup")

        return port

    except Exception as exc:
        out.error(f"Bare metal PostgreSQL setup failed: {exc}")
        cleanup_bare_metal_postgres(site_slug, postgres_version, config)
        raise SetupError(f"Failed to setup bare metal PostgreSQL: {exc}") from exc


def _create_postgres_cluster(site_slug: str, port: int, postgres_version: str) -> None:
    """Create a PostgreSQL cluster using pg_createcluster.

    Uses Debian/Ubuntu pg_createcluster command to create an isolated
    PostgreSQL instance with its own data directory and configuration.

    Args:
        site_slug: Site identifier (becomes cluster name)
        port: Port number for the cluster
        postgres_version: PostgreSQL version (e.g., "18")

    Raises:
        SetupError: If cluster creation fails.
    """
    try:
        subprocess.run(
            [
                "pg_createcluster",
                postgres_version,
                site_slug,
                "-p",
                str(port),
                "--start-conf=auto",  # Auto-start on boot
            ],
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to create PostgreSQL cluster:\n{exc.stderr or exc.stdout}"
        ) from exc


def _configure_wal_archiving(
    site_slug: str, postgres_version: str, config: SystemConfig
) -> None:
    """Configure WAL archiving in postgresql.conf.

    Adds the required settings for pgBackRest WAL archiving:
    - wal_level = replica (REQUIRED for WAL archiving)
    - archive_mode = on
    - archive_command = pgbackrest archive-push
    - archive_timeout = 300

    Args:
        site_slug: Site identifier
        postgres_version: PostgreSQL version
        config: System configuration (for pgBackRest config directory path)

    Raises:
        SetupError: If configuration fails.
    """
    conf_path = Path(f"/etc/postgresql/{postgres_version}/{site_slug}/postgresql.conf")

    if not conf_path.exists():
        raise SetupError(f"PostgreSQL config not found: {conf_path}")

    try:
        # Read existing config
        content = conf_path.read_text()

        # Append WAL archiving configuration
        # --config-include-path is required on the command line for pgBackRest 2.50+
        # because it cannot be set in the config file itself
        config_include_path = str(config.get_pgbackrest_config_dir())
        if not _SAFE_PATH_RE.match(config_include_path):
            raise SetupError(
                f"Unsafe characters in pgbackrest config path: {config_include_path}"
            )
        wal_config = f"""

# WAL archiving for pgBackRest (added by SUM Platform)
wal_level = replica
archive_mode = on
archive_command = '{DEFAULT_PGBACKREST_WRAPPER} --config-include-path={config_include_path} --stanza={site_slug} archive-push %p'
archive_timeout = 300
"""
        content += wal_config
        conf_path.write_text(content)

    except OSError as exc:
        raise SetupError(f"Failed to configure WAL archiving: {exc}") from exc


def _start_cluster(site_slug: str, postgres_version: str) -> None:
    """Start a PostgreSQL cluster using pg_ctlcluster.

    Uses --skip-systemctl-redirect because systemd's %I expansion breaks
    for cluster names containing dashes (e.g., testsite-a).

    Args:
        site_slug: Site identifier
        postgres_version: PostgreSQL version

    Raises:
        SetupError: If cluster fails to start.
    """
    try:
        subprocess.run(
            [
                "pg_ctlcluster",
                "--skip-systemctl-redirect",
                postgres_version,
                site_slug,
                "start",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to start PostgreSQL cluster:\n{exc.stderr or exc.stdout}"
        ) from exc


def _wait_for_postgres(port: int, timeout: int = 60) -> None:
    """Wait for PostgreSQL to be ready using pg_isready.

    Args:
        port: PostgreSQL port number
        timeout: Maximum wait time in seconds

    Raises:
        SetupError: If PostgreSQL doesn't become ready within timeout.
    """
    out = OutputFormatter()
    out.info(f"Waiting for PostgreSQL to be ready (timeout: {timeout}s)")

    start_time = time.time()

    while time.time() - start_time < timeout:
        try:
            result = subprocess.run(
                ["pg_isready", "-p", str(port)],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                return
        except subprocess.TimeoutExpired:
            # pg_isready timed out; will retry after sleep
            pass
        except FileNotFoundError as exc:
            raise SetupError(
                "pg_isready not found. Is PostgreSQL client installed?"
            ) from exc
        except subprocess.SubprocessError as exc:
            raise SetupError(
                f"Failed while waiting for PostgreSQL to become ready: {exc}"
            ) from exc

        time.sleep(2)

    raise SetupError(
        f"PostgreSQL did not become ready within {timeout} seconds. "
        f"Check cluster logs with: pg_lsclusters"
    )


def _create_database_and_user(
    site_slug: str, port: int, credentials: SiteCredentials
) -> None:
    """Create database and user for the site.

    Runs as postgres user via sudo to create the database and user
    with appropriate permissions.

    Args:
        site_slug: Site identifier
        port: PostgreSQL port number
        credentials: Database credentials

    Raises:
        SetupError: If database/user creation fails.
    """
    # Validate identifiers contain only safe characters (defense-in-depth)
    # These are generated from validated slugs, but verify to prevent injection
    # if the generation logic ever changes
    _validate_sql_identifier(credentials.db_user, "db_user")
    _validate_sql_identifier(credentials.db_name, "db_name")

    # Use psql variable substitution via stdin to avoid password in command args
    create_user_sql = "CREATE USER :\"db_user\" WITH PASSWORD :'db_password';"
    create_db_sql = 'CREATE DATABASE :"db_name" OWNER :"db_user";'

    psql_base = ["sudo", "-u", "postgres", "psql", "-p", str(port)]
    psql_vars = [
        "-v",
        f"db_user={credentials.db_user}",
        "-v",
        f"db_name={credentials.db_name}",
    ]

    # Password set via stdin to avoid /proc exposure
    password_escaped = credentials.db_password.replace("'", "''")
    password_preamble = f"\\set db_password '{password_escaped}'\n"

    try:
        for sql in [create_user_sql, create_db_sql]:
            subprocess.run(
                psql_base + psql_vars,
                input=password_preamble + sql,
                check=True,
                capture_output=True,
                text=True,
            )

    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to create database/user:\n{exc.stderr or exc.stdout}"
        ) from exc


def _verify_backup_ssh_key(config: SystemConfig) -> None:
    """Verify backup SSH key exists at configured location.

    Args:
        config: System configuration

    Raises:
        SetupError: If SSH key doesn't exist.
    """
    if not config.backups:
        return

    ssh_key_path = Path(config.backups.storage_box.ssh_key)
    if not ssh_key_path.exists():
        raise SetupError(
            f"Backup SSH key not found: {ssh_key_path}\n"
            f"Ensure the key exists at the configured location."
        )


def _generate_pgbackrest_stanza_config(
    site_slug: str,
    port: int,
    credentials: SiteCredentials,
    config: SystemConfig,
) -> None:
    """Generate pgBackRest stanza configuration file.

    Creates a per-site config at /etc/pgbackrest/conf.d/<slug>.conf
    using the template from lintel-ops.

    Args:
        site_slug: Site identifier
        port: PostgreSQL port number
        credentials: Database credentials
        config: System configuration

    Raises:
        SetupError: If config generation fails.
    """
    if not config.backups:
        return

    if not config.templates.pgbackrest_stanza_path:
        raise SetupError(
            "pgBackRest stanza template not configured in /etc/sum/config.yml\n"
            "Add templates.pgbackrest_stanza path."
        )

    # Get infrastructure settings
    infra = config.infrastructure
    postgres_version = "18"
    if infra:
        postgres_version = infra.postgres_version

    # Get pgbackrest settings
    if infra and infra.pgbackrest:
        compress_type = infra.pgbackrest.compress_type
        compress_level = infra.pgbackrest.compress_level
        process_max = infra.pgbackrest.process_max
    else:
        compress_type = "zst"
        compress_level = 3
        process_max = 2

    replacements = {
        "SITE_SLUG": site_slug,
        "POSTGRES_VERSION": postgres_version,
        "POSTGRES_PORT": str(port),
        "DB_USER": credentials.db_user,
        "BACKUP_KEY_PATH": config.backups.storage_box.ssh_key,
        "STORAGE_BOX_HOST": config.backups.storage_box.host,
        "STORAGE_BOX_USER": config.backups.storage_box.user,
        "STORAGE_BOX_PORT": str(config.backups.storage_box.port),
        "STORAGE_BOX_FINGERPRINT": config.backups.storage_box.fingerprint,
        "STORAGE_BOX_BASE_PATH": config.backups.storage_box.base_path,
        "RETENTION_FULL": str(config.backups.retention.full_backups),
        "RETENTION_DIFF": str(config.backups.retention.diff_backups),
        "COMPRESS_TYPE": compress_type,
        "COMPRESS_LEVEL": str(compress_level),
        "PROCESS_MAX": str(process_max),
    }

    content = _render_template(config.templates.pgbackrest_stanza_path, replacements)

    # Safety check: the stanza config must NOT contain a cipher-pass directive.
    # The cipher passphrase is injected at runtime by the pgbackrest-wrapper
    # script.  If the template still contains __CIPHER_PASS__ or a hardcoded
    # repo1-cipher-pass line, flag it immediately rather than writing a config
    # that leaks the passphrase.
    if "cipher-pass=" in content.lower():
        raise SetupError(
            "pgBackRest stanza template contains a cipher-pass directive. "
            "Remove repo1-cipher-pass from the template — the passphrase is "
            "now injected via the pgbackrest-wrapper script."
        )

    # Write stanza config to configured directory
    stanza_dir = config.get_pgbackrest_config_dir()
    stanza_dir.mkdir(parents=True, exist_ok=True)

    stanza_file = stanza_dir / f"{site_slug}.conf"
    try:
        stanza_file.write_text(content)
        # Set ownership to postgres user
        subprocess.run(
            ["chown", "postgres:postgres", str(stanza_file)],
            check=True,
            capture_output=True,
        )
        stanza_file.chmod(0o640)
    except (OSError, subprocess.CalledProcessError) as exc:
        raise SetupError(f"Failed to write pgBackRest stanza config: {exc}") from exc


def _init_pgbackrest_stanza(site_slug: str, config: SystemConfig) -> None:
    """Initialize pgBackRest stanza.

    Runs stanza-create as postgres user to initialize the backup repository.

    Args:
        site_slug: Site identifier
        config: System configuration for paths

    Raises:
        SetupError: If stanza creation fails.
    """
    config_include_path = str(config.get_pgbackrest_config_dir())
    try:
        subprocess.run(
            [
                "sudo",
                "-u",
                "postgres",
                DEFAULT_PGBACKREST_WRAPPER,
                f"--config-include-path={config_include_path}",
                "--stanza",
                site_slug,
                "stanza-create",
            ],
            check=True,
            capture_output=True,
        )
    except subprocess.CalledProcessError as exc:
        # pgbackrest writes errors to stdout with log prefixes, not stderr.
        # Output may contain binary data, so decode safely.
        error_output = (
            _safe_decode(exc.stdout) or _safe_decode(exc.stderr) or "No error output"
        )
        raise SetupError(
            f"Failed to initialize pgBackRest stanza:\n{error_output}"
        ) from exc


def _run_initial_backup(site_slug: str, config: SystemConfig) -> None:
    """Run initial full backup.

    Runs a full backup as postgres user to establish the first restore point.

    Args:
        site_slug: Site identifier
        config: System configuration for paths

    Raises:
        SetupError: If backup fails.
    """
    config_include_path = str(config.get_pgbackrest_config_dir())
    try:
        subprocess.run(
            [
                "sudo",
                "-u",
                "postgres",
                DEFAULT_PGBACKREST_WRAPPER,
                f"--config-include-path={config_include_path}",
                "--stanza",
                site_slug,
                "--type=full",
                "backup",
            ],
            check=True,
            capture_output=True,
        )
    except subprocess.CalledProcessError as exc:
        # pgbackrest writes errors to stdout with log prefixes, not stderr.
        # Output may contain binary data, so decode safely.
        error_output = (
            _safe_decode(exc.stdout) or _safe_decode(exc.stderr) or "No error output"
        )
        raise SetupError(f"Failed to run initial backup:\n{error_output}") from exc


def stop_bare_metal_postgres(site_slug: str, postgres_version: str) -> None:
    """Stop a PostgreSQL cluster.

    Uses --skip-systemctl-redirect because systemd's %I expansion breaks
    for cluster names containing dashes.

    Args:
        site_slug: Site identifier
        postgres_version: PostgreSQL version

    Raises:
        SetupError: If cluster fails to stop.
    """
    out = OutputFormatter()
    out.info(f"Stopping PostgreSQL cluster for {site_slug}")

    try:
        subprocess.run(
            [
                "pg_ctlcluster",
                "--skip-systemctl-redirect",
                postgres_version,
                site_slug,
                "stop",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        out.success("Stopped PostgreSQL cluster")
    except subprocess.CalledProcessError as exc:
        raise SetupError(
            f"Failed to stop PostgreSQL cluster:\n{exc.stderr or exc.stdout}"
        ) from exc


def cleanup_pgbackrest_remote_state(
    site_slug: str,
    config: SystemConfig | None = None,
    *,
    strict: bool = False,
) -> None:
    """Clean up remote pgBackRest stanza state to prevent retry blockers.

    Stops the stanza and runs stanza-delete --force to remove both local and
    remote backup metadata. This prevents the [028] error when retrying init
    after a failed run that left remote state behind.

    Args:
        site_slug: Site identifier
        config: Optional system configuration for paths
        strict: If True, raise SetupError on stanza-delete failure instead
            of logging a warning. Use for ``destroy --purge-backups`` where
            the operator explicitly requested remote purge and must know if
            it failed.
    """
    out = OutputFormatter()

    config_include_path = (
        str(config.get_pgbackrest_config_dir()) if config else "/etc/pgbackrest/conf.d"
    )

    # Stop stanza (create stop marker to allow stanza-delete)
    try:
        subprocess.run(
            [
                "sudo",
                "-u",
                "postgres",
                DEFAULT_PGBACKREST_WRAPPER,
                f"--config-include-path={config_include_path}",
                "--stanza",
                site_slug,
                "stop",
            ],
            capture_output=True,
        )
    except (subprocess.SubprocessError, OSError):
        pass  # Stanza may not exist or already be stopped

    # Delete stanza (removes remote and local metadata)
    try:
        result = subprocess.run(
            [
                "sudo",
                "-u",
                "postgres",
                DEFAULT_PGBACKREST_WRAPPER,
                f"--config-include-path={config_include_path}",
                "--stanza",
                site_slug,
                "stanza-delete",
                "--force",
            ],
            capture_output=True,
        )
        if result.returncode == 0:
            out.info("Cleaned up pgBackRest stanza metadata")
        else:
            # pgBackRest writes errors to stdout (with log prefixes), not
            # just stderr, so include both in the error message.
            detail = (
                _safe_decode(result.stderr)
                or _safe_decode(result.stdout)
                or "no output"
            )
            msg = f"pgBackRest stanza-delete returned {result.returncode}: " f"{detail}"
            if strict:
                raise SetupError(msg)
            out.warning(msg)
    except SetupError:
        raise
    except (subprocess.SubprocessError, OSError) as exc:
        msg = f"Could not delete pgBackRest stanza: {exc}"
        if strict:
            raise SetupError(msg) from exc
        out.warning(f"{msg} (may not exist)")


def cleanup_bare_metal_postgres(
    site_slug: str,
    postgres_version: str,
    config: SystemConfig | None = None,
    *,
    purge_remote_backups: bool = True,
    strict_purge: bool = False,
) -> None:
    """Completely remove PostgreSQL cluster and cleanup resources.

    Stops the cluster, optionally cleans up pgBackRest remote state,
    drops the cluster via pg_dropcluster, deallocates the port,
    and removes the pgBackRest stanza config file.

    Args:
        site_slug: Site identifier
        postgres_version: PostgreSQL version
        config: Optional system configuration for custom paths
        purge_remote_backups: If True (default) and backups are configured,
            also purge remote pgBackRest stanza data. This prevents the
            [028] retry blocker after failed inits. Set to False when
            deliberate destroy should preserve remote backup data.
        strict_purge: If True, raise SetupError when remote purge fails
            instead of logging a warning. Use when the operator explicitly
            requested ``--purge-backups`` and must know if it failed.
    """
    out = OutputFormatter()
    out.info(f"Cleaning up PostgreSQL cluster for {site_slug}")

    # Try to stop cluster first (may already be stopped or not exist)
    # Uses --skip-systemctl-redirect because systemd's %I expansion breaks
    # for cluster names containing dashes.
    try:
        subprocess.run(
            [
                "pg_ctlcluster",
                "--skip-systemctl-redirect",
                postgres_version,
                site_slug,
                "stop",
            ],
            capture_output=True,
            text=True,
        )
    except subprocess.SubprocessError:
        pass  # Cluster may not be running or may not exist

    # Clean up pgBackRest remote state before dropping the cluster.
    # stanza-delete requires the stanza config file to still exist, so
    # this must happen before we remove the local stanza config.
    # If strict mode is on and remote purge fails, defer the error until
    # after local cleanup so we don't leave the cluster behind.
    deferred_purge_error: SetupError | None = None
    if purge_remote_backups and config and config.backups:
        try:
            cleanup_pgbackrest_remote_state(site_slug, config, strict=strict_purge)
        except SetupError as exc:
            deferred_purge_error = exc
            out.warning(
                f"Remote backup purge failed (will report after local cleanup): {exc}"
            )

    # Drop the cluster
    try:
        subprocess.run(
            ["pg_dropcluster", postgres_version, site_slug],
            check=True,
            capture_output=True,
            text=True,
        )
        out.info("Dropped PostgreSQL cluster")
    except subprocess.CalledProcessError as exc:
        # Cluster may not exist
        out.warning(
            f"Could not drop cluster (may not exist): {exc.stderr or exc.stdout}"
        )

    # Deallocate port
    deallocate_port(site_slug, config)
    out.info("Deallocated port")

    # Remove pgBackRest stanza config file (local)
    stanza_dir = (
        config.get_pgbackrest_config_dir() if config else Path("/etc/pgbackrest/conf.d")
    )
    stanza_file = stanza_dir / f"{site_slug}.conf"
    if stanza_file.exists():
        try:
            stanza_file.unlink()
            out.info("Removed pgBackRest stanza config")
        except OSError as exc:
            out.warning(f"Could not remove stanza config: {exc}")

    # Re-raise deferred remote purge error after all local cleanup is done.
    if deferred_purge_error is not None:
        raise deferred_purge_error
