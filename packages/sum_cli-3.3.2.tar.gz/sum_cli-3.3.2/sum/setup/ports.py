"""Port allocation management for PostgreSQL clusters."""

from __future__ import annotations

import fcntl
import json
import logging
import socket
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING

from sum.exceptions import SetupError

if TYPE_CHECKING:
    from sum.system_config import SystemConfig

logger = logging.getLogger(__name__)

# Default paths and ranges (used when config not provided)
DEFAULT_PORTS_FILE = Path("/etc/sum/ports.json")
DEFAULT_LOCK_FILE = Path("/etc/sum/ports.lock")
DEFAULT_MIN_PORT = 5433
DEFAULT_MAX_PORT = 5532


def _get_paths(config: SystemConfig | None) -> tuple[Path, Path, int, int]:
    """Get paths and port range from config or defaults.

    Args:
        config: Optional system configuration

    Returns:
        Tuple of (ports_file, lock_file, min_port, max_port)
    """
    if config is not None:
        ports_file = config.get_ports_file()
        lock_file = config.get_ports_lock_file()
        min_port, max_port = config.get_port_range()
    else:
        ports_file = DEFAULT_PORTS_FILE
        lock_file = DEFAULT_LOCK_FILE
        min_port = DEFAULT_MIN_PORT
        max_port = DEFAULT_MAX_PORT
    return ports_file, lock_file, min_port, max_port


def _is_port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    """Check if a port is currently in use on the system.

    Args:
        port: Port number to check.
        host: Host address to check (default: localhost).

    Returns:
        True if port is in use, False if available.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(1)
        try:
            sock.bind((host, port))
            return False  # Port is available
        except OSError:
            return True  # Port is in use


def load_allocated_ports(config: SystemConfig | None = None) -> dict[str, int]:
    """Load the port allocation map from disk.

    Args:
        config: Optional system configuration for custom paths

    Returns:
        Dict mapping site_slug to allocated port.
    """
    ports_file, _, _, _ = _get_paths(config)

    if not ports_file.exists():
        return {}

    try:
        with open(ports_file) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as exc:
        raise SetupError(f"Failed to load port allocations: {exc}") from exc


def save_allocated_ports(
    ports: dict[str, int], config: SystemConfig | None = None
) -> None:
    """Save the port allocation map to disk.

    Args:
        ports: Dict mapping site_slug to allocated port
        config: Optional system configuration for custom paths
    """
    ports_file, _, _, _ = _get_paths(config)
    ports_file.parent.mkdir(parents=True, exist_ok=True)

    try:
        with open(ports_file, "w") as f:
            json.dump(ports, f, indent=2)
    except OSError as exc:
        raise SetupError(f"Failed to save port allocations: {exc}") from exc


def allocate_port(site_slug: str, config: SystemConfig | None = None) -> int:
    """Allocate a unique port for a site's PostgreSQL cluster.

    Uses file locking to prevent race conditions when multiple
    init commands run concurrently. Also checks that the port is not
    currently in use on the system (e.g., by system Postgres or other services).

    Args:
        site_slug: Site identifier
        config: Optional system configuration for custom paths/ranges

    Returns:
        The allocated port number.

    Raises:
        SetupError: If no ports available in the configured range.
    """
    ports_file, lock_file, min_port, max_port = _get_paths(config)

    # Acquire lock
    lock_file.parent.mkdir(parents=True, exist_ok=True)
    with open(lock_file, "w") as lock_fd:
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX)

            ports = load_allocated_ports(config)

            # Check if already allocated
            if site_slug in ports:
                return ports[site_slug]

            # Find next available port in range
            # Check both registry AND system availability
            used_ports = set(ports.values())
            port = min_port
            while port in used_ports or _is_port_in_use(port):
                port += 1
                if port > max_port:
                    raise SetupError(
                        f"No available ports in range {min_port}-{max_port}. "
                        f"Maximum of {max_port - min_port + 1} PostgreSQL sites reached."
                    )

            ports[site_slug] = port
            save_allocated_ports(ports, config)

            return port
        finally:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)


def deallocate_port(site_slug: str, config: SystemConfig | None = None) -> None:
    """Remove a site's port allocation.

    Args:
        site_slug: Site identifier
        config: Optional system configuration for custom paths
    """
    _, lock_file, _, _ = _get_paths(config)

    # Acquire lock
    lock_file.parent.mkdir(parents=True, exist_ok=True)
    with open(lock_file, "w") as lock_fd:
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX)

            ports = load_allocated_ports(config)
            if site_slug in ports:
                del ports[site_slug]
                save_allocated_ports(ports, config)
        finally:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)


def get_site_port(site_slug: str, config: SystemConfig | None = None) -> int | None:
    """Get the allocated port for a site, or None if not allocated.

    Args:
        site_slug: Site identifier
        config: Optional system configuration for custom paths

    Returns:
        Allocated port number or None
    """
    ports = load_allocated_ports(config)
    return ports.get(site_slug)


def _get_existing_clusters() -> set[str] | None:
    """Get the set of all existing PostgreSQL cluster names.

    Parses ``pg_lsclusters --no-header`` output to find cluster names.
    Returns clusters in any state (online, down, recovery, etc.).

    Returns:
        Set of cluster name strings, or ``None`` if ``pg_lsclusters`` is
        unavailable or failed (callers must distinguish "no clusters" from
        "unable to check").
    """
    try:
        result = subprocess.run(
            ["pg_lsclusters", "--no-header"],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            logger.warning(
                "pg_lsclusters exited with code %d: %s",
                result.returncode,
                result.stderr.strip(),
            )
            return None
        clusters: set[str] = set()
        for line in result.stdout.strip().splitlines():
            # pg_lsclusters columns: Ver Cluster Port Status Owner ...
            parts = line.split()
            if len(parts) >= 2:
                clusters.add(parts[1])
        return clusters
    except FileNotFoundError:
        logger.warning("pg_lsclusters not found; cannot verify cluster state")
        return None
    except OSError as exc:
        logger.warning("pg_lsclusters failed: %s", exc)
        return None


def reconcile_ports(config: SystemConfig | None = None) -> list[str]:
    """Remove stale port allocations for sites with no existing cluster.

    Cross-references the port registry against actual PostgreSQL clusters
    reported by ``pg_lsclusters`` and removes entries whose site slug does
    not correspond to any existing cluster.

    Uses the existing file lock to ensure safe concurrent access.

    Args:
        config: Optional system configuration for custom paths/ranges

    Returns:
        List of site slugs whose stale allocations were removed.
    """
    _, lock_file, _, _ = _get_paths(config)

    lock_file.parent.mkdir(parents=True, exist_ok=True)
    with open(lock_file, "w") as lock_fd:
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX)

            ports = load_allocated_ports(config)
            if not ports:
                return []

            existing_clusters = _get_existing_clusters()
            if existing_clusters is None:
                logger.warning(
                    "Cannot determine existing clusters; "
                    "skipping port reconciliation to avoid data loss"
                )
                return []

            stale_slugs: list[str] = []

            for site_slug in list(ports.keys()):
                if site_slug not in existing_clusters:
                    stale_slugs.append(site_slug)
                    logger.warning(
                        "Removing stale port allocation for '%s' "
                        "(port %d, no existing cluster found)",
                        site_slug,
                        ports[site_slug],
                    )
                    del ports[site_slug]

            if stale_slugs:
                save_allocated_ports(ports, config)

            return stale_slugs
        finally:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
