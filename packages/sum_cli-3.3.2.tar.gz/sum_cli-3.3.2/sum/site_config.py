"""Per-site configuration stored at /srv/sum/<site>/.sum/config.yml."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import yaml
from sum.exceptions import SumCliError


class SiteConfigError(SumCliError):
    """Site configuration error."""

    pass


@dataclass
class GitConfig:
    """Git configuration for a site."""

    provider: str  # "github" or "gitea"
    org: str
    url: str | None = None  # Required for gitea
    ssh_port: int = 22
    token_env: str = "GITEA_TOKEN"


@dataclass
class SiteConfig:
    """Per-site configuration."""

    slug: str
    theme: str
    created: datetime
    git: GitConfig | None  # None if --no-git

    @classmethod
    def load(cls, site_dir: Path) -> SiteConfig:
        """Load site config from .sum/config.yml."""
        config_path = site_dir / ".sum" / "config.yml"
        if not config_path.exists():
            raise SiteConfigError(
                f"Site config not found: {config_path}\n"
                f"This site may have been created before site configs were introduced."
            )

        try:
            with open(config_path) as f:
                data = yaml.safe_load(f)
        except yaml.YAMLError as exc:
            raise SiteConfigError(
                f"Invalid YAML in site config: {config_path}\n{exc}"
            ) from exc

        if not isinstance(data, dict):
            raise SiteConfigError(
                f"Site config is empty or not a mapping: {config_path}"
            )

        try:
            site_data = data["site"]
            slug = site_data["slug"]
            theme = site_data["theme"]
            created_raw = site_data["created"]
        except KeyError as exc:
            raise SiteConfigError(
                f"Missing required field '{exc.args[0]}' in site config: {config_path}"
            ) from exc

        try:
            created_dt = datetime.fromisoformat(created_raw)
        except (TypeError, ValueError) as exc:
            raise SiteConfigError(
                f"Invalid datetime format for 'site.created' in: {config_path}"
            ) from exc

        git_data = data.get("git")
        git_config = None
        if git_data:
            try:
                git_config = GitConfig(
                    provider=git_data["provider"],
                    org=git_data["org"],
                    url=git_data.get("url"),
                    ssh_port=git_data.get("ssh_port", 22),
                    token_env=git_data.get("token_env", "GITEA_TOKEN"),
                )
            except KeyError as exc:
                raise SiteConfigError(
                    f"Missing required git field '{exc.args[0]}' in: {config_path}"
                ) from exc

        return cls(
            slug=slug,
            theme=theme,
            created=created_dt,
            git=git_config,
        )

    def save(self, site_dir: Path) -> None:
        """Save site config to .sum/config.yml."""
        config_dir = site_dir / ".sum"
        config_dir.mkdir(parents=True, exist_ok=True)
        config_path = config_dir / "config.yml"

        data: dict = {
            "site": {
                "slug": self.slug,
                "theme": self.theme,
                "created": self.created.isoformat(),
            },
            "git": None,
        }

        if self.git:
            git_data: dict = {
                "provider": self.git.provider,
                "org": self.git.org,
            }
            if self.git.url:
                git_data["url"] = self.git.url
            if self.git.ssh_port != 22:
                git_data["ssh_port"] = self.git.ssh_port
            if self.git.token_env != "GITEA_TOKEN":
                git_data["token_env"] = self.git.token_env
            data["git"] = git_data

        with open(config_path, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)
