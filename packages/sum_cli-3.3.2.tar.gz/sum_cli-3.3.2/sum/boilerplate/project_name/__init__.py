"""
Root package for this Django project.

Replace 'project_name' with your actual project name after copying.
"""
