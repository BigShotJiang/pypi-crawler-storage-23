"""
Settings package for multi-environment configuration.

This package allows different settings modules for local and production environments.
"""
