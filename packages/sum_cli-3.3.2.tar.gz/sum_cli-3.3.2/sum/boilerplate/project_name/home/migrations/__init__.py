"""
Migrations package for the home app.
"""
