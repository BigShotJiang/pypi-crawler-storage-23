"""
Client home app package.

Replace 'project_name' with your actual project name after copying.
"""
