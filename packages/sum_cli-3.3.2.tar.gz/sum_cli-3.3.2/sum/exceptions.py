"""CLI-specific exception hierarchy.

All CLI exceptions inherit from SumCliError for consistent catching.
ThemeValidationError also inherits ValueError for compatibility with
validation patterns that expect ValueError subclasses.
"""


class SumCliError(Exception):
    """Base exception for SUM CLI failures."""


class SetupError(SumCliError):
    """Raised when initial setup steps fail."""


class ThemeNotFoundError(SumCliError):
    """Raised when a requested theme slug cannot be found."""


class ThemeValidationError(SumCliError, ValueError):
    """Raised when theme exists but is invalid (bad manifest or missing files).

    Inherits ValueError for compatibility with validation error handling patterns.
    """


class VenvError(SumCliError):
    """Raised when virtual environment operations fail."""


class DependencyError(SumCliError):
    """Raised when dependency installation or resolution fails."""


class MigrationError(SumCliError):
    """Raised when database migrations fail."""


class SeedError(SumCliError):
    """Raised when seed data operations fail."""


class SuperuserError(SumCliError):
    """Raised when superuser creation fails."""


class ThemeUpdateError(SumCliError):
    """Raised when theme update operations fail."""


class ThemeDowngradeError(ThemeUpdateError):
    """Raised when attempting to downgrade theme without --allow-downgrade flag."""
