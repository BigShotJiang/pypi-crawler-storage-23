"""Project naming utilities and boilerplate resource access.

This module provides utilities for validating project names, generating
Python package names from slugs, and accessing bundled boilerplate templates.

Migrated from sum_cli.util as part of CLI v2 consolidation.
"""

from __future__ import annotations

import importlib.resources
import importlib.resources.abc
import re
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Final

PROJECT_SLUG_RE: Final[re.Pattern[str]] = re.compile(r"^[a-z][a-z0-9-]*$")


@dataclass(frozen=True)
class ProjectNaming:
    """
    Naming derived from the user-provided project slug.

    - slug: directory name under clients/
    - python_package: importable Python identifier (hyphens converted to underscores)
    """

    slug: str
    python_package: str


def validate_project_name(project_name: str) -> ProjectNaming:
    """
    Validate and normalize the project name.

    Allowed: lowercase letters, digits, hyphens; must start with a letter.
    """
    name = project_name.strip()
    if not PROJECT_SLUG_RE.fullmatch(name):
        raise ValueError(
            "Invalid project name. Use lowercase letters, digits, and hyphens "
            "(must start with a letter). Example: acme-kitchens"
        )
    python_pkg = name.replace("-", "_")
    return ProjectNaming(slug=name, python_package=python_pkg)


def get_packaged_boilerplate() -> importlib.resources.abc.Traversable:
    """
    Return the boilerplate directory bundled with the CLI package as a Traversable.

    Use `importlib.resources.as_file(...)` to materialize this to a real filesystem
    path when you need to pass it to APIs like shutil.copytree.
    """
    root = importlib.resources.files("sum")
    return root.joinpath("boilerplate")


def is_boilerplate_dir(path: Path) -> bool:
    """
    Minimal structural validation for a boilerplate directory.
    """
    return (
        path.is_dir()
        and (path / "manage.py").is_file()
        and (path / "pytest.ini").is_file()
        and (path / "project_name").is_dir()
    )


def safe_text_replace_in_file(path: Path, old: str, new: str) -> bool:
    """
    Replace text in a file if it looks like UTF-8 text.

    Returns True if the file was modified.
    """
    try:
        content = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return False

    if old not in content:
        return False

    path.write_text(content.replace(old, new), encoding="utf-8")
    return True


def find_repo_root(start: Path) -> Path | None:
    """Walk upward to find repo root (contains .git directory)."""
    for directory in [start, *start.parents]:
        if (directory / ".git").exists():
            return directory
    return None


# Default safe parent directories for safe_rmtree.
# NOTE: This assumes the default staging base_dir of /srv/sum.  Deployments
# with a non-default staging.base_dir should pass ``allowed_parents`` to
# safe_rmtree explicitly.
_DEFAULT_SAFE_PARENTS: Final[tuple[Path, ...]] = (
    Path("/srv/sum"),
    Path("/tmp"),
)


def _get_safe_parents(
    allowed_parents: tuple[Path, ...] | None,
    repo_root: Path | None = None,
) -> tuple[Path, ...]:
    """Return the resolved set of safe parent directories."""
    if allowed_parents is not None:
        # Resolve custom parents for consistency with the defaults — callers
        # may pass paths containing symlinks or ``..`` components.
        parents = {p.resolve() for p in allowed_parents}
        if repo_root is not None:
            parents.add(repo_root.resolve())
        return tuple(parents)
    # Include the platform temp directory (e.g. /tmp on most systems, but
    # respects $TMPDIR overrides) alongside the static defaults.
    sys_tmp = Path(tempfile.gettempdir()).resolve()
    parents = set()
    for p in _DEFAULT_SAFE_PARENTS:
        parents.add(p.resolve())
    parents.add(sys_tmp)
    if repo_root is not None:
        parents.add(repo_root.resolve())
    return tuple(parents)


def safe_rmtree(
    path: Path,
    *,
    tmp_root: Path | None,
    repo_root: Path | None,
    allowed_parents: tuple[Path, ...] | None = None,
) -> None:
    resolved = path.resolve()
    if ".git" in resolved.parts:
        raise RuntimeError(f"Refusing to delete path containing .git: {resolved}")
    if repo_root and resolved == repo_root.resolve():
        raise RuntimeError(f"Refusing to delete repo root: {resolved}")
    if tmp_root and not resolved.is_relative_to(tmp_root.resolve()):
        raise RuntimeError(
            "Refusing to delete outside tmp root: " f"{resolved} (tmp_root={tmp_root})"
        )
    # When tmp_root is None, validate the path is under a known-safe parent
    # directory instead of relying on an arbitrary depth heuristic.
    if tmp_root is None:
        safe_parents = _get_safe_parents(allowed_parents, repo_root=repo_root)
        for safe_parent in safe_parents:
            if resolved == safe_parent:
                raise RuntimeError(
                    f"Refusing to delete safe parent directory itself: {resolved}"
                )
        if not any(resolved.is_relative_to(sp) for sp in safe_parents):
            parents_str = ", ".join(str(p) for p in sorted(safe_parents))
            raise RuntimeError(
                f"Refusing to delete path not under a known-safe parent: {resolved}. "
                f"Allowed parents: {parents_str}"
            )
    shutil.rmtree(resolved)
