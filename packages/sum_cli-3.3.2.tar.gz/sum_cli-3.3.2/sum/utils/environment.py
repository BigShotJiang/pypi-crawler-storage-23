from __future__ import annotations

from enum import StrEnum
from pathlib import Path


class ExecutionMode(StrEnum):
    MONOREPO = "monorepo"
    STANDALONE = "standalone"


def _normalize_start_path(start_path: Path | None) -> Path:
    """Return a directory path from a file path or default to the current cwd."""
    path = start_path or Path.cwd()
    if path.is_file():
        return path.parent
    return path


def find_monorepo_root(start_path: Path | None = None) -> Path | None:
    """Walk upward to find monorepo root (contains core/ and boilerplate/)."""
    search_path = _normalize_start_path(start_path)

    for parent in [search_path, *search_path.parents]:
        if (parent / "core").is_dir() and (parent / "boilerplate").is_dir():
            return parent

    return None


def detect_mode(path: Path | None = None) -> ExecutionMode:
    """Detect execution mode based on directory structure."""
    if find_monorepo_root(path) is not None:
        return ExecutionMode.MONOREPO
    return ExecutionMode.STANDALONE


def get_clients_dir(start_path: Path | None = None, *, create: bool = False) -> Path:
    """Resolve the clients directory for monorepo or standalone mode."""
    repo_root = find_monorepo_root(start_path)
    if repo_root is not None:
        monorepo_clients = repo_root / "clients"
        if monorepo_clients.is_dir():
            return monorepo_clients

    search_path = _normalize_start_path(start_path)
    standalone_clients = search_path / "clients"
    if standalone_clients.is_dir():
        return standalone_clients

    if create:
        standalone_clients.mkdir(parents=True, exist_ok=True)
        return standalone_clients

    raise FileNotFoundError(
        "Cannot locate clients directory. Ensure you're running inside the monorepo "
        "or from a standalone project root that contains a 'clients' folder."
    )


def resolve_project_path(project: str | None, start_path: Path | None = None) -> Path:
    """Resolve a project path from name or current directory."""
    if project:
        clients_dir = get_clients_dir(start_path)
        project_path = clients_dir / project
        if project_path.is_dir():
            return project_path
        raise FileNotFoundError(f"Project not found: {project}")

    cwd = _normalize_start_path(start_path)
    if (cwd / "manage.py").exists():
        return cwd

    # Production deployment layout: site root contains app/manage.py
    app_dir = cwd / "app"
    if (app_dir / "manage.py").exists():
        return app_dir

    raise FileNotFoundError(
        "Not in a project directory. Either cd into a project or specify project name."
    )
