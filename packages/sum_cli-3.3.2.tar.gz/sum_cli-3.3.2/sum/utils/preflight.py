"""Pre-flight check framework for SUM Platform CLI.

Provides a reusable framework for validating prerequisites before
command execution. Checks are read-only and must not modify state.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import urllib.error
import urllib.request
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path

from sum.system_config import DEFAULT_CIPHER_PASS_FILE, DEFAULT_CONFIG_PATH
from sum.utils.privilege import detect_gitea_token


class CheckStatus(StrEnum):
    """Result status for a pre-flight check."""

    PASS = "pass"
    FAIL = "fail"
    WARN = "warn"
    SKIP = "skip"


class CheckSeverity(StrEnum):
    """Severity level for a pre-flight check."""

    REQUIRED = "required"
    RECOMMENDED = "recommended"


@dataclass(frozen=True)
class CheckResult:
    """Outcome of a single pre-flight check."""

    status: CheckStatus
    message: str
    fix_hint: str | None = None

    @classmethod
    def ok(cls, message: str) -> CheckResult:
        return cls(CheckStatus.PASS, message)

    @classmethod
    def fail(cls, message: str, fix_hint: str | None = None) -> CheckResult:
        return cls(CheckStatus.FAIL, message, fix_hint)

    @classmethod
    def warn(cls, message: str, fix_hint: str | None = None) -> CheckResult:
        return cls(CheckStatus.WARN, message, fix_hint)

    @classmethod
    def skip(cls, message: str) -> CheckResult:
        return cls(CheckStatus.SKIP, message)


class PreflightCheck(ABC):
    """Abstract base class for pre-flight checks.

    Subclasses must set ``name`` and ``description`` and implement
    the ``check()`` method. Checks must be read-only and should
    complete within 5 seconds.
    """

    name: str
    description: str
    severity: CheckSeverity = CheckSeverity.REQUIRED

    @abstractmethod
    def check(self) -> CheckResult:
        """Execute the check and return the result.

        Must be read-only (no state changes) and should respect a
        5-second timeout for operations involving I/O.
        """


_STATUS_SYMBOLS: dict[CheckStatus, str] = {
    CheckStatus.PASS: "✅",
    CheckStatus.FAIL: "❌",
    CheckStatus.WARN: "⚠️ ",
    CheckStatus.SKIP: "⏭️ ",
}


class PreflightRunner:
    """Collects and runs pre-flight checks, formats output, and decides go/no-go."""

    def __init__(self) -> None:
        self._checks: list[PreflightCheck] = []

    @property
    def has_checks(self) -> bool:
        """Return True if any checks have been registered."""
        return bool(self._checks)

    def register(self, check: PreflightCheck) -> None:
        """Add a check to the runner."""
        self._checks.append(check)

    def run(self) -> list[tuple[PreflightCheck, CheckResult]]:
        """Execute all registered checks and return results."""
        results: list[tuple[PreflightCheck, CheckResult]] = []
        for chk in self._checks:
            try:
                result = chk.check()
            except Exception as exc:
                result = CheckResult.fail(f"Check raised an exception: {exc}")
            results.append((chk, result))
        return results

    @staticmethod
    def format_results(results: list[tuple[PreflightCheck, CheckResult]]) -> str:
        """Format check results as a human-readable table."""
        lines: list[str] = ["", "Pre-flight checks:", "─" * 60]
        for chk, result in results:
            symbol = _STATUS_SYMBOLS.get(result.status, "?")
            severity_tag = (
                "" if chk.severity == CheckSeverity.REQUIRED else " (recommended)"
            )
            lines.append(f"  {symbol} {chk.name}{severity_tag}: {result.message}")
            if result.fix_hint:
                lines.append(f"      ↳ Fix: {result.fix_hint}")
        lines.append("─" * 60)
        return "\n".join(lines)

    @staticmethod
    def is_go(results: list[tuple[PreflightCheck, CheckResult]]) -> bool:
        """Return True if no REQUIRED check has FAIL status."""
        for chk, result in results:
            if (
                chk.severity == CheckSeverity.REQUIRED
                and result.status == CheckStatus.FAIL
            ):
                return False
        return True


# ─── Built-in check implementations ─────────────────────────────────────────


class SiteExistsCheck(PreflightCheck):
    """Verify that the site directory exists."""

    name = "Site directory"
    description = "Checks that the site directory exists"

    def __init__(self, slug: str, base_dir: str) -> None:
        self.slug = slug
        self.base_dir = base_dir

    def check(self) -> CheckResult:
        site_dir = Path(self.base_dir) / self.slug
        if site_dir.is_dir():
            return CheckResult.ok(f"{site_dir} exists")
        return CheckResult.fail(
            f"{site_dir} not found",
            fix_hint=f"Run: sum-platform init {self.slug}",
        )


class PostgresClusterCheck(PreflightCheck):
    """Verify that the PostgreSQL cluster for a site is online."""

    name = "PostgreSQL cluster"
    description = "Checks that the site's PG cluster is running"

    def __init__(self, slug: str) -> None:
        self.slug = slug

    def check(self) -> CheckResult:
        try:
            result = subprocess.run(
                ["pg_lsclusters", "--no-header"],
                capture_output=True,
                text=True,
                timeout=5,
            )
        except FileNotFoundError:
            return CheckResult.skip(
                "pg_lsclusters not found (PostgreSQL not installed)"
            )
        except subprocess.TimeoutExpired:
            return CheckResult.fail(
                "pg_lsclusters timed out",
                fix_hint="Check PostgreSQL installation",
            )

        if result.returncode != 0:
            return CheckResult.fail(
                f"pg_lsclusters exited with code {result.returncode}",
                fix_hint="Check PostgreSQL installation",
            )

        for line in result.stdout.strip().splitlines():
            parts = line.split()
            if len(parts) >= 4 and parts[1] == self.slug:
                if parts[3] == "online":
                    return CheckResult.ok(f"Cluster '{self.slug}' is online")
                return CheckResult.fail(
                    f"Cluster '{self.slug}' is {parts[3]}",
                    fix_hint=f"Run: pg_ctlcluster {parts[0]} {self.slug} start",
                )

        return CheckResult.fail(
            f"Cluster '{self.slug}' not found",
            fix_hint="The PostgreSQL cluster for this site has not been created",
        )


class SystemConfigCheck(PreflightCheck):
    """Verify that the system config file is readable."""

    name = "System config"
    description = "Checks that /etc/sum/config.yml is readable"

    def __init__(self, config_path: Path | None = None) -> None:
        self._config_path = config_path

    def check(self) -> CheckResult:
        path = self._config_path
        if path is None:
            env_path = os.environ.get("SUM_CONFIG_PATH")
            if env_path:
                path = Path(env_path)
            else:
                path = DEFAULT_CONFIG_PATH

        if not path.exists():
            return CheckResult.fail(
                f"Config file not found: {path}",
                fix_hint="Run: sudo sum-platform setup",
            )

        try:
            path.read_bytes()
        except PermissionError:
            return CheckResult.fail(
                f"Cannot read {path} (permission denied)",
                fix_hint=(
                    f"Run this command with sudo, or verify permissions"
                    f" (expected: root:root mode 640): ls -l {path}"
                ),
            )

        return CheckResult.ok(f"{path} is readable")


class SSHConnectivityCheck(PreflightCheck):
    """Verify SSH connectivity to a remote host."""

    name = "SSH connectivity"
    description = "Checks SSH connection to remote host"

    def __init__(self, host: str, port: int = 22, timeout: int = 5) -> None:
        self.host = host
        self.port = port
        self.timeout = timeout

    def check(self) -> CheckResult:
        try:
            result = subprocess.run(
                [
                    "ssh",
                    "-o",
                    "BatchMode=yes",
                    "-o",
                    f"ConnectTimeout={self.timeout}",
                    "-o",
                    "StrictHostKeyChecking=accept-new",
                    "-o",
                    "UserKnownHostsFile=/dev/null",
                    "-p",
                    str(self.port),
                    self.host,
                    "true",
                ],
                capture_output=True,
                text=True,
                timeout=self.timeout,
            )
        except FileNotFoundError:
            return CheckResult.fail(
                "ssh not found",
                fix_hint="Install OpenSSH client",
            )
        except subprocess.TimeoutExpired:
            return CheckResult.fail(
                f"SSH to {self.host}:{self.port} timed out after {self.timeout}s",
                fix_hint=f"Check network connectivity and SSH config for {self.host}",
            )

        if result.returncode == 0:
            return CheckResult.ok(f"SSH to {self.host}:{self.port} succeeded")
        return CheckResult.fail(
            f"SSH to {self.host}:{self.port} failed (exit {result.returncode})",
            fix_hint=f"Check SSH keys and config for {self.host}",
        )


class GiteaTokenCheck(PreflightCheck):
    """Verify that a Gitea token env var is set."""

    name = "Gitea token"

    def __init__(self, env_var: str = "GITEA_TOKEN") -> None:
        self.env_var = env_var
        self.description = f"Checks that {env_var} env var is set"

    def check(self) -> CheckResult:
        token = detect_gitea_token(env_var=self.env_var)
        if token:
            return CheckResult.ok(f"{self.env_var} is set")
        return CheckResult.fail(
            f"{self.env_var} not found in environment or tea config",
            fix_hint=(
                f"Export {self.env_var}, add it to /etc/sum/env,"
                " or configure a tea login via: tea login add"
            ),
        )


class GiteaRepoCheck(PreflightCheck):
    """Verify that a Gitea repository exists and is accessible."""

    name = "Gitea repository"
    description = "Checks that the Gitea repo exists via API"

    def __init__(
        self,
        org: str,
        repo: str,
        url: str = "https://gitea.lintel.digital",
        token_env: str = "GITEA_TOKEN",
    ) -> None:
        self.org = org
        self.repo = repo
        self.url = url.rstrip("/")
        self.token_env = token_env

    def check(self) -> CheckResult:
        if not self.url or not self.url.startswith(("http://", "https://")):
            return CheckResult.fail(
                f"Invalid Gitea URL: {self.url!r}",
                fix_hint="Provide a valid URL starting with http:// or https://",
            )

        token = detect_gitea_token(env_var=self.token_env)
        if not token:
            return CheckResult.skip(f"{self.token_env} not set, cannot check repo")

        req = urllib.request.Request(
            f"{self.url}/api/v1/repos/{self.org}/{self.repo}",
            headers={"Authorization": f"token {token}"},
        )
        try:
            with urllib.request.urlopen(req, timeout=5) as resp:
                if resp.status == 200:
                    return CheckResult.ok(f"{self.org}/{self.repo} exists on Gitea")
                return CheckResult.fail(
                    f"Gitea API returned HTTP {resp.status}",
                    fix_hint=f"Check GITEA_TOKEN permissions for {self.org}/{self.repo}",
                )
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                return CheckResult.fail(
                    f"{self.org}/{self.repo} not found on Gitea",
                    fix_hint=f"Create the repo: tea repo create --name {self.repo} --org {self.org}",
                )
            return CheckResult.fail(
                f"Gitea API returned HTTP {exc.code}",
                fix_hint=f"Check GITEA_TOKEN permissions for {self.org}/{self.repo}",
            )
        except urllib.error.URLError as exc:
            return CheckResult.fail(
                f"Gitea API request failed: {exc.reason}",
                fix_hint=f"Check connectivity to {self.url}",
            )


class CipherPassFileCheck(PreflightCheck):
    """Verify that the cipher passphrase file for pgBackRest exists."""

    name = "Cipher passphrase"
    description = "Checks that the pgBackRest cipher passphrase file exists"

    def __init__(self, path: str | None = None) -> None:
        self._path = path

    def check(self) -> CheckResult:
        path_str = self._path or DEFAULT_CIPHER_PASS_FILE
        path = Path(path_str)

        if not path.exists():
            return CheckResult.fail(
                f"Cipher passphrase file not found: {path}",
                fix_hint=(
                    f"Run: openssl rand -base64 48 | sudo tee {path} > /dev/null"
                    f" && sudo chown postgres:postgres {path}"
                    f" && sudo chmod 600 {path}"
                ),
            )

        try:
            content = path.read_text().strip()
        except PermissionError:
            return CheckResult.fail(
                f"Cannot read {path} (permission denied)",
                fix_hint=f"Run: sudo chown postgres:postgres {path} && sudo chmod 600 {path}",
            )

        if not content:
            return CheckResult.fail(
                f"Cipher passphrase file is empty: {path}",
                fix_hint=f"Add a strong passphrase to {path}",
            )

        return CheckResult.ok(f"{path} exists and is non-empty")


class DiskSpaceCheck(PreflightCheck):
    """Verify sufficient disk space at a given path."""

    name = "Disk space"
    description = "Checks that sufficient disk space is available"

    def __init__(self, path: str, min_gb: float = 1.0) -> None:
        self.path = path
        self.min_gb = min_gb

    def check(self) -> CheckResult:
        target = Path(self.path)
        # Walk up to find an existing ancestor for disk_usage
        check_path = target
        while not check_path.exists() and check_path != check_path.parent:
            check_path = check_path.parent

        if not check_path.exists():
            return CheckResult.skip(
                f"Cannot determine disk space (no ancestor of {target} exists)"
            )

        try:
            usage = shutil.disk_usage(check_path)
        except OSError as exc:
            return CheckResult.fail(
                f"Cannot read disk usage for {check_path}: {exc}",
            )

        free_gb = usage.free / (1024**3)
        if free_gb < self.min_gb:
            return CheckResult.fail(
                f"Only {free_gb:.1f} GB free on {check_path} (need {self.min_gb:.1f} GB)",
                fix_hint=f"Free up disk space on {check_path}",
            )
        return CheckResult.ok(f"{free_gb:.1f} GB free on {check_path}")


class PgBackRestStanzaCheck(PreflightCheck):
    """Verify that a pgBackRest stanza configuration exists for the site."""

    name = "pgBackRest stanza"
    description = "Checks that the pgBackRest stanza config exists"

    def __init__(self, slug: str, config_dir: str = "/etc/pgbackrest/conf.d") -> None:
        self.slug = slug
        self.config_dir = config_dir

    def check(self) -> CheckResult:
        stanza_file = Path(self.config_dir) / f"{self.slug}.conf"
        if stanza_file.is_file():
            return CheckResult.ok(f"Stanza config exists: {stanza_file}")
        return CheckResult.fail(
            f"Stanza config not found: {stanza_file}",
            fix_hint=f"Run backup setup for site '{self.slug}'",
        )


class TemplateFilesCheck(PreflightCheck):
    """Verify that infrastructure template files exist on disk."""

    name = "Template files"
    description = "Checks that systemd/caddy template files exist"

    def __init__(
        self,
        systemd_path: Path | None = None,
        caddy_path: Path | None = None,
    ) -> None:
        self._systemd_path = systemd_path
        self._caddy_path = caddy_path

    def check(self) -> CheckResult:
        missing: list[str] = []
        if self._systemd_path and not self._systemd_path.is_file():
            missing.append(f"systemd: {self._systemd_path}")
        if self._caddy_path and not self._caddy_path.is_file():
            missing.append(f"caddy: {self._caddy_path}")

        if missing:
            return CheckResult.fail(
                f"Template not found: {', '.join(missing)}",
                fix_hint="Create the template files in the templates directory "
                "configured in /etc/sum/config.yml",
            )
        checked = []
        if self._systemd_path:
            checked.append("systemd")
        if self._caddy_path:
            checked.append("caddy")
        return CheckResult.ok(f"Templates found ({', '.join(checked)})")
