from __future__ import annotations

import importlib
import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import cast

from sum.exceptions import SetupError
from sum.setup.venv import VenvManager
from sum.utils.django import DjangoCommandExecutor
from sum.utils.environment import ExecutionMode, find_monorepo_root

# --------------------------------------------------------------------------- #
# Shared input validators (used at CLI entry points for defense-in-depth)
# --------------------------------------------------------------------------- #

# Site slugs: lowercase start, then lowercase/digits/hyphens, max 63 chars.
# This is the *entry-point* validator; stricter SQL-level validation lives in
# bare_metal_postgres._validate_sql_identifier().
_SITE_SLUG_RE = re.compile(r"^[a-z][a-z0-9-]{0,62}$")

# DNS-safe domain: labels of alphanumeric/hyphens separated by dots.
_DOMAIN_RE = re.compile(
    r"^(?!-)[A-Za-z0-9-]{1,63}(?<!-)(\.[A-Za-z0-9-]{1,63})*\.[A-Za-z]{2,}$"
)


def validate_site_slug(slug: str) -> None:
    """Validate a site slug for safe use in paths, SQL, and shell commands.

    Raises:
        SetupError: If the slug is empty, too long, or contains unsafe chars.
    """
    if not slug:
        raise SetupError("Site slug must not be empty")
    if not _SITE_SLUG_RE.match(slug):
        raise SetupError(
            f"Invalid site slug '{slug}': must start with a lowercase letter, "
            "contain only lowercase letters, digits, and hyphens, "
            "and be at most 63 characters"
        )


def validate_domain(domain: str) -> None:
    """Validate a domain name for safe use in Caddy / .env configs.

    Raises:
        SetupError: If the domain is empty or not DNS-safe.
    """
    if not domain:
        raise SetupError("Domain must not be empty")
    if not _DOMAIN_RE.match(domain):
        raise SetupError(
            f"Invalid domain '{domain}': must be a valid DNS hostname "
            "(e.g., acme-client.com)"
        )


class ValidationStatus(StrEnum):
    OK = "ok"
    FAIL = "fail"
    SKIP = "skip"


@dataclass(frozen=True)
class ValidationResult:
    status: ValidationStatus
    message: str
    remediation: str | None = None

    @property
    def passed(self) -> bool:
        return self.status is ValidationStatus.OK

    @property
    def failed(self) -> bool:
        return self.status is ValidationStatus.FAIL

    @property
    def skipped(self) -> bool:
        return self.status is ValidationStatus.SKIP

    @classmethod
    def ok(cls, message: str) -> ValidationResult:
        return cls(ValidationStatus.OK, message)

    @classmethod
    def fail(cls, message: str, remediation: str | None = None) -> ValidationResult:
        return cls(ValidationStatus.FAIL, message, remediation)

    @classmethod
    def skip(cls, message: str) -> ValidationResult:
        return cls(ValidationStatus.SKIP, message)


MIN_COMPILED_CSS_BYTES = 5 * 1024
ENV_KEY_RE = re.compile(r"^([A-Z][A-Z0-9_]*)=(.*)$")


def _parse_env_assignments(path: Path) -> dict[str, str]:
    data: dict[str, str] = {}
    if not path.exists():
        return data

    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except PermissionError as exc:
        raise PermissionError(f"Cannot read {path} (permission denied)") from exc

    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        # Strip optional 'export ' prefix
        if line.startswith("export "):
            line = line[7:]
        match = ENV_KEY_RE.match(line)
        if not match:
            continue
        key, value = match.group(1), match.group(2)
        # Strip surrounding quotes (single or double)
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
            value = value[1:-1]
        data[key] = value
    return data


def _read_json_file(path: Path) -> tuple[dict[str, object] | None, str]:
    if not path.exists():
        return None, f"Missing file: {path}"
    try:
        return json.loads(path.read_text(encoding="utf-8")), ""
    except Exception as exc:  # pragma: no cover - best effort parsing
        return None, f"Invalid JSON in {path}: {exc}"


class ProjectValidator:
    """Validates project setup state."""

    def __init__(self, project_path: Path, mode: ExecutionMode) -> None:
        self.project_path = project_path
        self.mode = mode
        self.venv_manager = self._create_venv_manager()

    def _resolve_venv_path(self) -> Path:
        """Resolve venv path for dev (.venv) and production (site/venv) layouts."""
        local_venv = self.project_path / ".venv"
        if local_venv.is_dir():
            return local_venv

        site_venv = self.project_path.parent / "venv"
        if (self.project_path / "manage.py").is_file() and site_venv.is_dir():
            return site_venv

        return local_venv

    def _create_venv_manager(self) -> VenvManager:
        return VenvManager(venv_path=self._resolve_venv_path())

    def check_venv_exists(self) -> ValidationResult:
        """Check if virtualenv exists."""
        venv_path = self._resolve_venv_path()
        if venv_path.is_dir():
            return ValidationResult.ok(f"Virtualenv exists: {venv_path}")
        return ValidationResult.fail(
            "Virtualenv not found",
            "Run 'sum init --full' or create a venv for this site.",
        )

    def check_packages_installed(self) -> ValidationResult:
        """Check if key packages are installed in venv."""
        if not self.venv_manager.exists(self.project_path):
            return ValidationResult.skip("Virtualenv missing; skipping package checks")

        python = self.venv_manager.get_python_executable(self.project_path)
        for package in ("django", "wagtail"):
            result = subprocess.run(
                [str(python), "-c", f"import {package}"],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                return ValidationResult.fail(
                    f"Package '{package}' not installed",
                    "Run 'pip install -r requirements.txt'",
                )

        return ValidationResult.ok("Required packages installed")

    def check_env_local(self) -> ValidationResult:
        """Check if .env.local exists."""
        env_local = self.project_path / ".env.local"
        if env_local.is_file():
            return ValidationResult.ok(".env.local found")
        return ValidationResult.skip("No .env.local found (superuser not created)")

    def check_migrations_applied(self) -> ValidationResult:
        """Check if migrations are up to date."""
        if not self.venv_manager.exists(self.project_path):
            return ValidationResult.skip("Virtualenv missing; skipping migration check")
        try:
            python_path = self.venv_manager.get_python_executable(self.project_path)
            executor = DjangoCommandExecutor(
                self.project_path, self.mode, python_path=python_path
            )
            result = executor.run_command(["migrate", "--check"], check=False)
        except Exception as exc:
            return ValidationResult.fail(f"Migration check failed: {exc}")

        if result.returncode == 0:
            return ValidationResult.ok("Migrations up to date")
        return ValidationResult.fail(
            "Pending migrations",
            "Run 'python manage.py migrate'",
        )

    def check_homepage_exists(self) -> ValidationResult:
        """Check if homepage is set as site root."""
        if not self.venv_manager.exists(self.project_path):
            return ValidationResult.skip("Virtualenv missing; skipping homepage check")
        try:
            python_path = self.venv_manager.get_python_executable(self.project_path)
            executor = DjangoCommandExecutor(
                self.project_path, self.mode, python_path=python_path
            )
            script = "\n".join(
                [
                    "from wagtail.models import Site",
                    "site = Site.objects.get(is_default_site=True)",
                    "print(site.root_page.slug)",
                ]
            )
            result = executor.run_command(["shell", "-c", script], check=False)
        except Exception as exc:
            return ValidationResult.fail(f"Homepage check failed: {exc}")

        if result.returncode == 0 and result.stdout.strip() == "home":
            return ValidationResult.ok("Homepage set as site root")
        return ValidationResult.fail(
            "Homepage not configured",
            "Run 'python manage.py seed_homepage'",
        )

    def check_required_env_vars(self) -> ValidationResult:
        """Check required env vars from .env.example are set."""
        env_example_path = self.project_path / ".env.example"
        required_env: dict[str, str] = _parse_env_assignments(env_example_path)
        if not env_example_path.exists():
            return ValidationResult.fail("Missing .env.example")

        try:
            env: dict[str, str] = _parse_env_assignments(self.project_path / ".env")
        except PermissionError:
            return ValidationResult.skip(
                "Cannot read .env (permission denied) — re-run with sudo"
            )
        missing: list[str] = []
        for key in sorted(required_env.keys()):
            if key in env:
                continue
            if key in os.environ and os.environ[key].strip():
                continue
            missing.append(str(key))

        if required_env and missing:
            missing_list: list[str] = list(missing)
            return ValidationResult.fail(
                "Missing required env vars",
                "Missing: " + ", ".join(missing_list),
            )
        return ValidationResult.ok("Required env vars present")

    def _resolve_theme_slugs(self) -> tuple[str | None, str | None, str | None]:
        provenance_path = self.project_path / ".sum" / "theme.json"
        provenance, provenance_err = _read_json_file(provenance_path)
        expected_slug: str | None = None
        if provenance is not None:
            theme_value = provenance.get("theme")
            if isinstance(theme_value, str) and theme_value.strip():
                expected_slug = theme_value.strip()

        theme_root = self.project_path / "theme" / "active"
        if not theme_root.is_dir():
            return (
                expected_slug,
                None,
                f"Missing {theme_root} (expected active theme install)",
            )

        manifest_path = theme_root / "theme.json"
        manifest, manifest_err = _read_json_file(manifest_path)
        manifest_slug: str | None = None
        if manifest is None:
            return expected_slug, None, manifest_err

        slug_value = manifest.get("slug")
        if isinstance(slug_value, str) and slug_value.strip():
            manifest_slug = slug_value.strip()
        else:
            return (
                expected_slug,
                None,
                "Missing `slug` field in theme/active/theme.json",
            )

        if provenance is None:
            return expected_slug, manifest_slug, provenance_err

        return expected_slug, manifest_slug, None

    def check_theme_slug_match(self) -> ValidationResult:
        expected_slug, manifest_slug, error = self._resolve_theme_slugs()
        if error:
            return ValidationResult.fail(error)

        if expected_slug and manifest_slug and expected_slug != manifest_slug:
            return ValidationResult.fail(
                f".sum says '{expected_slug}' but theme/active says '{manifest_slug}'"
            )
        if manifest_slug:
            return ValidationResult.ok(manifest_slug)
        return ValidationResult.fail(
            "Could not determine theme slug (check .sum/theme.json and theme/active/theme.json)"
        )

    def check_theme_compiled_css(self) -> ValidationResult:
        expected_slug, manifest_slug, error = self._resolve_theme_slugs()
        if error and manifest_slug is None:
            return ValidationResult.fail(error)

        css_slug = expected_slug or manifest_slug
        if not css_slug:
            return ValidationResult.fail(
                "Could not determine theme slug for static path (check .sum/theme.json and theme/active/theme.json)"
            )

        compiled_css = (
            self.project_path
            / "theme"
            / "active"
            / "static"
            / css_slug
            / "css"
            / "main.css"
        )
        if not compiled_css.is_file():
            return ValidationResult.fail(f"Missing {compiled_css}")

        try:
            size = compiled_css.stat().st_size
        except OSError as exc:
            return ValidationResult.fail(f"Could not stat {compiled_css}: {exc}")

        if size <= MIN_COMPILED_CSS_BYTES:
            return ValidationResult.fail(
                f"File too small ({size} bytes): {compiled_css}"
            )

        return ValidationResult.ok(str(compiled_css))

    def check_sum_core_import(self) -> ValidationResult:
        monorepo_root = find_monorepo_root(self.project_path)
        core_path_added = False
        core_dir: Path | None = None
        if self.mode is ExecutionMode.MONOREPO and monorepo_root is not None:
            core_dir = monorepo_root / "core"
            core_str = str(core_dir)
            if core_str not in sys.path:
                sys.path.insert(0, core_str)
                core_path_added = True

        try:
            module = importlib.import_module("sum_core")
            _ = module.__name__
            if self.mode is ExecutionMode.MONOREPO and monorepo_root is not None:
                return ValidationResult.ok("monorepo mode")
            return ValidationResult.ok("sum_core importable")
        except ImportError:
            if self.mode is ExecutionMode.MONOREPO and monorepo_root is not None:
                return ValidationResult.fail(
                    "Failed in monorepo mode - check core/ directory structure"
                )
            return ValidationResult.fail(
                "Install requirements first: pip install -r requirements.txt"
            )
        except Exception as exc:
            return ValidationResult.fail(f"Failed to import sum_core: {exc}")
        finally:
            if core_path_added and core_dir is not None:
                sys.path.remove(str(cast(Path, core_dir)))
