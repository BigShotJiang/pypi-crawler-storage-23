"""Privilege escalation utilities for CLI commands requiring root.

Handles the complexity of re-executing the CLI with sudo when:
- The command requires root privileges
- The CLI was installed via pip/pipx to user space
- Environment variables need to be preserved
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

import yaml


def is_root() -> bool:
    """Check if running as root."""
    return os.geteuid() == 0


def find_cli_executable() -> str | None:
    """Find the sum-platform executable path.

    Checks multiple locations in order:
    1. sys.argv[0] if it's an absolute path to an existing file
    2. 'which sum-platform' output
    3. Common pipx locations (~/.local/bin/sum-platform)
    4. sys.executable's bin directory

    Returns:
        Absolute path to the CLI executable, or None if not found.
    """
    # Try sys.argv[0] first if it's absolute and exists
    if sys.argv and os.path.isabs(sys.argv[0]):
        argv0 = Path(sys.argv[0])
        if argv0.exists() and argv0.is_file():
            return str(argv0.resolve())

    # Try 'which' command
    which_result = shutil.which("sum-platform")
    if which_result:
        return which_result

    # Try common pipx location
    pipx_path = Path.home() / ".local" / "bin" / "sum-platform"
    if pipx_path.exists() and pipx_path.is_file():
        return str(pipx_path)

    # Try relative to Python executable
    python_bin = Path(sys.executable).parent
    cli_in_python_bin = python_bin / "sum-platform"
    if cli_in_python_bin.exists():
        return str(cli_in_python_bin)

    return None


def get_preserved_env_vars(token_env: str | None = None) -> list[str]:
    """Get list of environment variables to preserve during sudo.

    Args:
        token_env: Specific git token env var name from site config.
    """
    preserved = []

    for var in os.environ:
        if var.startswith("SUM_"):
            preserved.append(var)

    # Explicit git token vars (not wildcard *_TOKEN)
    if token_env and token_env in os.environ:
        preserved.append(token_env)
    else:
        for var in ("GITEA_TOKEN", "GITHUB_TOKEN"):
            if var in os.environ:
                preserved.append(var)

    essential = ["PATH", "HOME", "USER", "VIRTUAL_ENV", "PYTHONPATH"]
    for var in essential:
        if var in os.environ and var not in preserved:
            preserved.append(var)

    return preserved


def escalate_with_sudo(
    args: list[str] | None = None,
    token_env: str | None = None,
) -> int:
    """Re-execute the current command with sudo privileges.

    Finds the CLI executable, preserves necessary environment variables,
    and re-executes with sudo.

    Args:
        args: Command arguments to pass. If None, uses sys.argv[1:].
        token_env: Specific git token env var name to preserve across sudo.

    Returns:
        Exit code from the sudo-elevated process. Non-zero values indicate
        failure to escalate or an error in the elevated command.
    """
    cli_path = find_cli_executable()
    if cli_path is None:
        print(
            "Error: Cannot find sum-platform executable for privilege escalation.\n"
            "Please run manually with: sudo -E $(which sum-platform) ...",
            file=sys.stderr,
        )
        return 1

    if args is None:
        args = sys.argv[1:]

    # Build sudo command with environment preservation
    preserved_vars = get_preserved_env_vars(token_env=token_env)

    # Use --preserve-env=LIST so values stay in the environment without
    # appearing in process arguments (avoids /proc/PID/cmdline exposure)
    sudo_cmd = ["sudo"]
    if preserved_vars:
        sudo_cmd.append(f"--preserve-env={','.join(preserved_vars)}")

    sudo_cmd.append(cli_path)
    sudo_cmd.extend(args)

    print(f"Elevating privileges: sudo {cli_path} {' '.join(args)}")
    print("You may be prompted for your password.\n")

    try:
        result = subprocess.run(sudo_cmd, check=False)
        return result.returncode
    except FileNotFoundError:
        print(
            "Error: sudo command not found. Please install sudo or run as root.",
            file=sys.stderr,
        )
        return 1
    except KeyboardInterrupt:
        print("\nCancelled.")
        return 130


def require_root_or_escalate(
    command_name: str = "this command",
    token_env: str | None = None,
) -> bool:
    """Check for root privileges, escalating if needed.

    If not running as root, attempts to re-execute with sudo.
    If escalation succeeds (or was already root), returns True.
    If escalation fails or user cancels, exits the process.

    Args:
        command_name: Name of the command for error messages.
        token_env: Specific git token env var name to preserve across sudo.

    Returns:
        True if running as root (caller should continue).
        Never returns False - either escalates or exits.
    """
    if is_root():
        return True

    # Not root - attempt escalation
    print(f"The '{command_name}' command requires root privileges.")
    exit_code = escalate_with_sudo(token_env=token_env)
    sys.exit(exit_code)


def detect_gitea_token(
    env_var: str = "GITEA_TOKEN",
    tea_config_path: Path | None = None,
) -> str | None:
    """Detect a Gitea API token from environment or tea CLI config.

    Checks in order:
    1. The specified environment variable (default: GITEA_TOKEN)
    2. The tea CLI config file at ``~/.config/tea/config.yml``

    If found in the tea config, the token is also injected into
    ``os.environ[env_var]`` so that privilege escalation preserves it.

    Args:
        env_var: Environment variable name to check first.
        tea_config_path: Override path to tea config (for testing).

    Returns:
        The token string if found, or None.
    """
    # 1. Check environment
    token = os.environ.get(env_var, "").strip()
    if token:
        return token

    # 2. Fall back to tea CLI config
    if tea_config_path is None:
        tea_config_path = Path.home() / ".config" / "tea" / "config.yml"

    if not tea_config_path.is_file():
        return None

    try:
        data = yaml.safe_load(tea_config_path.read_text())
    except (OSError, yaml.YAMLError, UnicodeError):
        return None

    if not isinstance(data, dict):
        return None

    # tea config stores servers as a list under the "logins" key.
    # NOTE: Returns the first token found. If a user has multiple Gitea
    # servers configured, the wrong token may be returned. A future
    # improvement could match by URL against --gitea-url.
    logins = data.get("logins")
    if isinstance(logins, list):
        for entry in logins:
            if isinstance(entry, dict):
                found = entry.get("token")
                if found and isinstance(found, str) and found.strip():
                    found = found.strip()
                    os.environ[env_var] = found
                    return found

    return None
