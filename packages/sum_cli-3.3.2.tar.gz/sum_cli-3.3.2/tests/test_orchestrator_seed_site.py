"""Tests for CLI v2 seed site selection."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from sum.config import SetupConfig
from sum.exceptions import SetupError
from sum.setup.orchestrator import SetupOrchestrator
from sum.utils.environment import ExecutionMode


def _make_orchestrator(tmp_path: Path) -> tuple[SetupOrchestrator, Path, Path]:
    project_path = tmp_path / "project"
    package_dir = project_path / "demo_pkg"
    commands_dir = package_dir / "home" / "management" / "commands"
    commands_dir.mkdir(parents=True)
    (commands_dir / "__init__.py").write_text("", encoding="utf-8")

    orchestrator = SetupOrchestrator(project_path, ExecutionMode.STANDALONE)
    return orchestrator, project_path, package_dir


def _make_fake_monorepo(tmp_path: Path) -> Path:
    repo_root = tmp_path / "repo"
    (repo_root / "core").mkdir(parents=True)
    (repo_root / "boilerplate").mkdir(parents=True)

    seeders_dir = repo_root / "seeders"
    seeders_dir.mkdir(parents=True)
    (seeders_dir / "__init__.py").write_text("", encoding="utf-8")
    (seeders_dir / "orchestrator.py").write_text(
        "# test placeholder\n", encoding="utf-8"
    )

    profile_dir = repo_root / "content" / "sage-stone"
    pages_dir = profile_dir / "pages"
    pages_dir.mkdir(parents=True)
    (profile_dir / "site.yaml").write_text('company_name: "Test"\n', encoding="utf-8")
    (profile_dir / "navigation.yaml").write_text(
        "footer:\n  tagline: Test\n", encoding="utf-8"
    )
    (pages_dir / "home.yaml").write_text(
        'title: "Home"\nslug: "home"\n', encoding="utf-8"
    )

    seed_command = (
        repo_root
        / "core"
        / "sum_core"
        / "test_project"
        / "home"
        / "management"
        / "commands"
        / "seed.py"
    )
    seed_command.parent.mkdir(parents=True)
    seed_command.write_text("# test seed command placeholder\n", encoding="utf-8")

    return repo_root


@patch("sum.setup.orchestrator.ContentSeeder.seed_profile")
@patch("sum.setup.orchestrator.ContentSeeder.seed_homepage")
@patch("sum.setup.orchestrator.DjangoCommandExecutor")
@patch("sum.setup.orchestrator.find_monorepo_root")
def test_seed_content_routes_sage_and_stone(
    mock_find_monorepo_root: MagicMock,
    mock_executor_class: MagicMock,
    mock_seed_homepage: MagicMock,
    mock_seed_profile: MagicMock,
    tmp_path: Path,
) -> None:
    config = SetupConfig(seed_site="sage-and-stone", ci=True)
    orchestrator, project_root, package_dir = _make_orchestrator(tmp_path)
    repo_root = _make_fake_monorepo(tmp_path)
    mock_find_monorepo_root.return_value = repo_root

    orchestrator._seed_content(config)

    mock_executor_class.assert_called_once_with(
        orchestrator.project_path, ExecutionMode.STANDALONE
    )
    mock_seed_profile.assert_called_once_with("sage-stone")
    mock_seed_homepage.assert_not_called()
    assert (project_root / "seeders").is_dir()
    assert (project_root / "content" / "sage-stone").is_dir()
    assert (package_dir / "home" / "management" / "commands" / "seed.py").is_file()


@patch("sum.setup.orchestrator.ContentSeeder.seed_profile")
@patch("sum.setup.orchestrator.ContentSeeder.seed_homepage")
@patch("sum.setup.orchestrator.DjangoCommandExecutor")
def test_seed_content_defaults_to_homepage(
    mock_executor_class: MagicMock,
    mock_seed_homepage: MagicMock,
    mock_seed_profile: MagicMock,
    tmp_path: Path,
) -> None:
    config = SetupConfig(seed_preset="theme-x", ci=True)
    orchestrator, _, _ = _make_orchestrator(tmp_path)

    orchestrator._seed_content(config)

    mock_executor_class.assert_called_once_with(
        orchestrator.project_path, ExecutionMode.STANDALONE
    )
    mock_seed_homepage.assert_called_once_with(preset="theme-x")
    mock_seed_profile.assert_not_called()


@patch("sum.setup.orchestrator.ContentSeeder.seed_homepage")
@patch("sum.setup.orchestrator.DjangoCommandExecutor")
def test_seed_content_rejects_unknown_site(
    mock_executor_class: MagicMock,
    mock_seed_homepage: MagicMock,
    tmp_path: Path,
) -> None:
    config = SetupConfig(seed_site="unknown-site", ci=True)
    orchestrator, _, _ = _make_orchestrator(tmp_path)

    with pytest.raises(SetupError, match="Unknown seed site"):
        orchestrator._seed_content(config)

    mock_executor_class.assert_called_once_with(
        orchestrator.project_path, ExecutionMode.STANDALONE
    )
    mock_seed_homepage.assert_not_called()
