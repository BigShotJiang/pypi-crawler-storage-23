from __future__ import annotations

import subprocess

from sum.setup.infrastructure import cleanup_site
from sum.system_config import (
    AgencyConfig,
    DefaultsConfig,
    ProductionConfig,
    StagingConfig,
    SystemConfig,
    TemplatesConfig,
)


def test_cleanup_site_uses_psql_variables_for_drop_commands(monkeypatch, tmp_path):
    config = SystemConfig(
        agency=AgencyConfig(name="testco"),
        staging=StagingConfig(
            server="test-staging",
            domain_pattern="{slug}.test.site",
            base_dir=str(tmp_path / "srv" / "sum"),
        ),
        production=ProductionConfig(
            server="test-prod",
            ssh_host="192.168.1.1",
            base_dir="/srv/prod",
        ),
        templates=TemplatesConfig(
            dir="/opt/infra",
            systemd="systemd/test.service",
            caddy="caddy/test.caddy",
        ),
        defaults=DefaultsConfig(
            theme="theme_a",
            deploy_user="deploy",
            seed_profile="sage-stone",
        ),
    )
    site_dir = config.get_site_dir("acme")
    site_dir.mkdir(parents=True)

    calls: list[tuple[list[str], object | None]] = []

    def fake_run(cmd, **kwargs):
        calls.append((cmd, kwargs.get("input")))
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setattr("sum.setup.infrastructure.subprocess.run", fake_run)
    monkeypatch.setattr("sum.setup.ports.get_site_port", lambda slug, cfg: None)

    cleanup_site("acme", config)

    psql_calls = [call for call in calls if "psql" in call[0]]
    assert len(psql_calls) == 2
    assert psql_calls[0][0][-2:] == ["-v", f"db_name={config.get_db_name('acme')}"]
    assert psql_calls[0][1] == 'DROP DATABASE IF EXISTS :"db_name";'
    assert psql_calls[1][0][-2:] == ["-v", f"db_user={config.get_db_user('acme')}"]
    assert psql_calls[1][1] == 'DROP USER IF EXISTS :"db_user";'
