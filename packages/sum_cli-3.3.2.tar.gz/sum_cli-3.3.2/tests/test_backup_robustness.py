"""Regression tests for backup command robustness (SEC-03, H-03, H-05)."""

from __future__ import annotations

from importlib import import_module
from unittest.mock import MagicMock, patch

import pytest
from sum.system_config import ConfigurationError, reset_system_config

backup_module = import_module("sum.commands.backup")


@pytest.fixture(autouse=True)
def reset_config():
    reset_system_config()
    yield
    reset_system_config()


class TestBackupSlugValidation:
    """SEC-03: validate_site_slug() is called in run_backup()."""

    def test_rejects_empty_slug(self, capsys):
        result = backup_module.run_backup("")
        assert result == 1
        captured = capsys.readouterr()
        assert "must not be empty" in captured.out

    def test_rejects_uppercase_slug(self, capsys):
        result = backup_module.run_backup("UPPER")
        assert result == 1
        captured = capsys.readouterr()
        assert "Invalid site slug" in captured.out

    def test_rejects_slash_in_slug(self, capsys):
        result = backup_module.run_backup("../etc/passwd")
        assert result == 1
        captured = capsys.readouterr()
        assert "Invalid site slug" in captured.out

    def test_rejects_spaces_in_slug(self, capsys):
        result = backup_module.run_backup("my site")
        assert result == 1
        captured = capsys.readouterr()
        assert "Invalid site slug" in captured.out


class TestBackupRootCheck:
    """H-03: require_root_or_escalate() is called in run_backup()."""

    @patch("sum.commands.backup.require_root_or_escalate")
    @patch("sum.commands.backup.get_system_config")
    def test_root_check_called(self, mock_config, mock_root_check):
        mock_config.side_effect = ConfigurationError("no config")
        backup_module.run_backup("acme")
        mock_root_check.assert_called_once_with("backup")

    def test_root_check_called_before_config(self):
        """Root check happens before config loading (after validation)."""
        call_order = []

        def mock_root_check(name):
            call_order.append("root_check")
            return True

        def mock_validate(slug):
            call_order.append("validate_slug")

        def mock_config():
            call_order.append("get_config")
            raise ConfigurationError("stop")

        with (
            patch.object(backup_module, "require_root_or_escalate", mock_root_check),
            patch.object(backup_module, "validate_site_slug", mock_validate),
            patch.object(backup_module, "get_system_config", mock_config),
        ):
            backup_module.run_backup("test-site")

        # Call order: validate -> root_check -> get_config
        assert len(call_order) == 3
        assert call_order[0] == "validate_slug"
        assert call_order[1] == "root_check"
        assert call_order[2] == "get_config"


class TestBackupFullVerification:
    """H-05: Verify full backup exists before diff/incr backup."""

    @patch("sum.commands.backup.require_root_or_escalate")
    @patch("sum.commands.backup._check_storage_box_reachable")
    @patch("sum.commands.backup._check_backup_configured")
    @patch("sum.commands.backup.get_site_port", return_value=5433)
    @patch("sum.commands.backup.get_system_config")
    @patch("sum.commands.backup._run_pgbackrest")
    def test_diff_fails_without_full(
        self,
        mock_pgbackrest,
        mock_config,
        mock_port,
        mock_backup_cfg,
        mock_storage,
        mock_root,
        capsys,
    ):
        """Diff backup fails when no full backup exists."""
        mock_config.return_value = MagicMock()
        # Return info with no full backup
        info_result = MagicMock()
        info_result.stdout = '[{"backup": [{"type": "diff"}]}]'
        mock_pgbackrest.return_value = info_result

        result = backup_module.run_backup("acme", backup_type="diff")
        assert result == 1
        captured = capsys.readouterr()
        assert "No full backup exists" in captured.out

    @patch("sum.commands.backup.require_root_or_escalate")
    @patch("sum.commands.backup._check_storage_box_reachable")
    @patch("sum.commands.backup._check_backup_configured")
    @patch("sum.commands.backup.get_site_port", return_value=5433)
    @patch("sum.commands.backup.get_system_config")
    @patch("sum.commands.backup._run_pgbackrest")
    def test_diff_succeeds_with_full(
        self,
        mock_pgbackrest,
        mock_config,
        mock_port,
        mock_backup_cfg,
        mock_storage,
        mock_root,
        capsys,
    ):
        """Diff backup proceeds when full backup exists."""
        mock_config.return_value = MagicMock()

        # First call: info check (has full), second call: actual backup
        info_result = MagicMock()
        info_result.stdout = '[{"backup": [{"type": "full"}]}]'
        backup_result = MagicMock()
        backup_result.stdout = ""
        mock_pgbackrest.side_effect = [info_result, backup_result]

        result = backup_module.run_backup("acme", backup_type="diff")
        assert result == 0

    @patch("sum.commands.backup.require_root_or_escalate")
    @patch("sum.commands.backup._check_storage_box_reachable")
    @patch("sum.commands.backup._check_backup_configured")
    @patch("sum.commands.backup.get_site_port", return_value=5433)
    @patch("sum.commands.backup.get_system_config")
    @patch("sum.commands.backup._run_pgbackrest")
    def test_full_backup_skips_check(
        self,
        mock_pgbackrest,
        mock_config,
        mock_port,
        mock_backup_cfg,
        mock_storage,
        mock_root,
        capsys,
    ):
        """Full backup doesn't check for pre-existing full backup."""
        mock_config.return_value = MagicMock()
        backup_result = MagicMock()
        backup_result.stdout = ""
        mock_pgbackrest.return_value = backup_result

        result = backup_module.run_backup("acme", backup_type="full")
        assert result == 0
        # Only one call (the actual backup), no info check
        assert mock_pgbackrest.call_count == 1

    @patch("sum.commands.backup.require_root_or_escalate")
    @patch("sum.commands.backup._check_storage_box_reachable")
    @patch("sum.commands.backup._check_backup_configured")
    @patch("sum.commands.backup.get_site_port", return_value=5433)
    @patch("sum.commands.backup.get_system_config")
    @patch("sum.commands.backup._run_pgbackrest")
    def test_incr_fails_without_full(
        self,
        mock_pgbackrest,
        mock_config,
        mock_port,
        mock_backup_cfg,
        mock_storage,
        mock_root,
        capsys,
    ):
        """Incremental backup fails when no full backup exists."""
        mock_config.return_value = MagicMock()
        # Return info with no full backup
        info_result = MagicMock()
        info_result.stdout = '[{"backup": [{"type": "incr"}]}]'
        mock_pgbackrest.return_value = info_result

        result = backup_module.run_backup("acme", backup_type="incr")
        assert result == 1
        captured = capsys.readouterr()
        assert "No full backup exists" in captured.out

    @patch("sum.commands.backup.require_root_or_escalate")
    @patch("sum.commands.backup._check_storage_box_reachable")
    @patch("sum.commands.backup._check_backup_configured")
    @patch("sum.commands.backup.get_site_port", return_value=5433)
    @patch("sum.commands.backup.get_system_config")
    @patch("sum.commands.backup._run_pgbackrest")
    def test_incr_succeeds_with_full(
        self,
        mock_pgbackrest,
        mock_config,
        mock_port,
        mock_backup_cfg,
        mock_storage,
        mock_root,
        capsys,
    ):
        """Incremental backup proceeds when full backup exists."""
        mock_config.return_value = MagicMock()

        # First call: info check (has full), second call: actual backup
        info_result = MagicMock()
        info_result.stdout = '[{"backup": [{"type": "full"}]}]'
        backup_result = MagicMock()
        backup_result.stdout = ""
        mock_pgbackrest.side_effect = [info_result, backup_result]

        result = backup_module.run_backup("acme", backup_type="incr")
        assert result == 0
