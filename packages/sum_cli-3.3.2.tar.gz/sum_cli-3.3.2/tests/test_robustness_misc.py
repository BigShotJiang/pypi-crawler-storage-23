"""Regression tests for misc robustness fixes (H-09, H-15, H-19, SEC-07)."""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from sum.setup.scaffold import _is_binary_file
from sum.utils.project import _get_safe_parents, safe_rmtree


class TestSafeRmtreeContainment:
    """H-15 / HARDEN-07: safe_rmtree validates paths against known-safe parents."""

    def test_blocks_system_dirs(self):
        """Paths like /etc, /var, /home are refused when tmp_root=None."""
        for dangerous in [
            Path("/etc/something"),
            Path("/var/important"),
            Path("/home/user"),
        ]:
            with pytest.raises(RuntimeError, match="not under a known-safe parent"):
                safe_rmtree(dangerous, tmp_root=None, repo_root=None)

    def test_refuses_root(self):
        with pytest.raises(RuntimeError, match="not under a known-safe parent"):
            safe_rmtree(Path("/"), tmp_root=None, repo_root=None)

    def test_refuses_safe_parent_itself(self):
        """safe_rmtree(Path('/srv/sum')) must be rejected even though it's in the allowlist."""
        with pytest.raises(
            RuntimeError, match="Refusing to delete safe parent directory itself"
        ):
            safe_rmtree(Path("/srv/sum"), tmp_root=None, repo_root=None)

    def test_refuses_custom_parent_itself(self, tmp_path):
        """Deleting a custom allowed_parent directory itself is rejected."""
        with pytest.raises(
            RuntimeError, match="Refusing to delete safe parent directory itself"
        ):
            safe_rmtree(
                tmp_path,
                tmp_root=None,
                repo_root=None,
                allowed_parents=(tmp_path,),
            )

    def test_allows_srv_sum_paths(self):
        """Default safe parents include /srv/sum."""
        defaults = _get_safe_parents(None)
        assert any(
            Path("/srv/sum").resolve() == p for p in defaults
        ), f"/srv/sum not found in defaults: {defaults}"

    def test_allows_custom_parents(self, tmp_path):
        """Paths under custom allowed_parents are accepted."""
        target = tmp_path / "acme" / "tmp" / "build"
        target.mkdir(parents=True)
        (target / "file.txt").write_text("test")
        safe_rmtree(
            target,
            tmp_root=None,
            repo_root=None,
            allowed_parents=(tmp_path,),
        )
        assert not target.exists()

    def test_allows_tmp_path(self, tmp_path):
        """Paths under the system temp dir are allowed when tmp_root=None."""
        deep = tmp_path / "a" / "b" / "c"
        deep.mkdir(parents=True)
        (deep / "file.txt").write_text("test")
        # tmp_path is under /tmp, which is a default safe parent
        safe_rmtree(deep, tmp_root=None, repo_root=None)
        assert not deep.exists()

    def test_with_tmp_root_unchanged(self, tmp_path):
        """Existing behavior with tmp_root set is preserved."""
        contained = tmp_path / "child"
        contained.mkdir()
        (contained / "file.txt").write_text("test")
        safe_rmtree(contained, tmp_root=tmp_path, repo_root=None)
        assert not contained.exists()

    def test_with_tmp_root_rejects_outside(self, tmp_path):
        """tmp_root containment still works as before."""
        with pytest.raises(RuntimeError, match="outside tmp root"):
            safe_rmtree(Path("/srv/sum/acme"), tmp_root=tmp_path, repo_root=None)

    def test_git_guard_unchanged(self, tmp_path):
        """The .git guard still prevents deletion of git directories."""
        git_dir = tmp_path / ".git" / "objects"
        git_dir.mkdir(parents=True)
        with pytest.raises(RuntimeError, match=".git"):
            safe_rmtree(git_dir, tmp_root=None, repo_root=None)

    def test_repo_root_treated_as_safe_parent(self, tmp_path):
        """When repo_root is provided, its subtree is safe for cleanup."""
        repo = tmp_path / "repo"
        clients = repo / "clients" / "acme"
        clients.mkdir(parents=True)
        (clients / "file.txt").write_text("test")
        safe_rmtree(clients, tmp_root=None, repo_root=repo)
        assert not clients.exists()

    def test_repo_root_with_custom_parents(self, tmp_path):
        """repo_root is added alongside custom allowed_parents."""
        repo = tmp_path / "repo"
        target = repo / "clients" / "acme"
        target.mkdir(parents=True)
        (target / "file.txt").write_text("test")
        other = tmp_path / "other"
        other.mkdir()
        safe_rmtree(
            target,
            tmp_root=None,
            repo_root=repo,
            allowed_parents=(other,),
        )
        assert not target.exists()

    def test_custom_parents_are_resolved(self, tmp_path):
        """Custom allowed_parents with '..' components are resolved."""
        inner = tmp_path / "a" / "b"
        inner.mkdir(parents=True)
        target = inner / "child"
        target.mkdir()
        (target / "file.txt").write_text("test")
        # Pass unresolved parent containing '..'
        unresolved = tmp_path / "a" / "b" / ".." / "b"
        safe_rmtree(
            target,
            tmp_root=None,
            repo_root=None,
            allowed_parents=(unresolved,),
        )
        assert not target.exists()


class TestDomainPatternSafety:
    """H-09: get_site_domain uses .replace() not .format()."""

    def test_format_string_not_interpreted(self, tmp_path):
        """Verify {0.__class__} style attacks don't work in get_site_domain()."""
        from sum.system_config import SystemConfig

        # Create a minimal config file
        config_file = tmp_path / "config.yml"
        config_file.write_text("""
agency:
  name: TestAgency
staging:
  server: staging.example.com
  domain_pattern: "{slug}.example.com"
  base_dir: /srv/sum
production:
  server: prod.example.com
  ssh_host: prod-ssh.example.com
  base_dir: /srv/sum
templates:
  dir: /etc/sum/templates
  systemd: systemd.service.j2
  caddy: Caddyfile.j2
defaults:
  theme: theme_a
  deploy_user: deploy
  seed_profile: sage-stone
  postgres_port: 5432
infrastructure:
  postgres_version: "18"
  archive_timeout: 300
""")

        # Load the config
        config = SystemConfig.load(str(config_file))

        # Test normal slug works correctly
        result = config.get_site_domain("acme")
        assert result == "acme.example.com"

        # Format string attack should be treated as literal string, not interpreted
        result_attack = config.get_site_domain("{0.__class__}")
        assert result_attack == "{0.__class__}.example.com"

        # This demonstrates the fix: .replace() doesn't interpret format strings


class TestBinaryFileDetection:
    """H-19: Binary file detection for scaffold placeholder replacement."""

    def test_detects_binary_file(self, tmp_path):
        binary = tmp_path / "binary.dat"
        binary.write_bytes(b"header\x00binary\x00data")
        assert _is_binary_file(binary) is True

    def test_text_file_not_binary(self, tmp_path):
        text = tmp_path / "text.txt"
        text.write_text("hello world")
        assert _is_binary_file(text) is False

    def test_empty_file_not_binary(self, tmp_path):
        empty = tmp_path / "empty"
        empty.write_bytes(b"")
        assert _is_binary_file(empty) is False

    def test_nonexistent_file_treated_as_binary(self, tmp_path):
        assert _is_binary_file(tmp_path / "nope") is True


class TestConfigFilePermissions:
    """SEC-07: /etc/sum/config.yml must be written with 0o640 permissions."""

    def test_config_file_written_with_0o640_permissions(self, tmp_path):
        """Verify config file is written with 0o640 permissions."""
        # Test the actual file writing logic from setup.py
        import yaml

        config_data = {"test": "data"}
        config_file = tmp_path / "config.yml"

        # Replicate the logic from setup.py lines 192-196
        config_content = yaml.dump(config_data, default_flow_style=False)
        fd = os.open(config_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o640)
        try:
            os.write(fd, config_content.encode())
        finally:
            os.close(fd)

        # Verify file was created with 0o640 permissions
        assert config_file.exists()
        file_mode = config_file.stat().st_mode
        # Extract permission bits (last 9 bits)
        permissions = file_mode & 0o777
        assert permissions == 0o640, f"Expected 0o640, got {oct(permissions)}"


class TestFchmodTightensExistingPermissions:
    """Verify fchmod fixes permissions on pre-existing files."""

    def test_fchmod_tightens_existing_file_permissions(self, tmp_path):
        """Start with 0o644 and verify fchmod tightens to 0o640."""
        import stat

        target = tmp_path / "config.yml"
        target.write_text("old content")
        os.chmod(target, 0o644)  # Simulate old broad perms

        # Replicate the production write pattern from setup.py
        fd = os.open(str(target), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o640)
        os.fchmod(fd, 0o640)
        with os.fdopen(fd, "w") as f:
            f.write("new content")

        actual_mode = stat.S_IMODE(os.stat(target).st_mode)
        assert actual_mode == 0o640
