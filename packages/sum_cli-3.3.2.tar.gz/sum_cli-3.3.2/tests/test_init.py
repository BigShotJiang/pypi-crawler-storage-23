"""Tests for the refactored init command.

The init command now creates working sites at /srv/sum/<name>/ instead of
scaffolding to clients/<name>/. It requires sudo and provisions infrastructure.

Git settings are now per-site via --git-provider/--git-org or --no-git.
"""

from __future__ import annotations

from importlib import import_module
from typing import Any

import pytest
from sum.commands.init import run_init
from sum.setup.infrastructure import InfrastructureCheck
from sum.setup.site_orchestrator import SiteSetupResult
from sum.system_config import (
    AgencyConfig,
    DefaultsConfig,
    ProductionConfig,
    StagingConfig,
    SystemConfig,
    TemplatesConfig,
    reset_system_config,
)

init_module = import_module("sum.commands.init")


@pytest.fixture(autouse=True)
def mock_privilege_escalation(monkeypatch):
    """Mock privilege escalation to always succeed for tests.

    The privilege escalation module would try to re-exec with sudo,
    which we don't want in tests. Individual tests can override this.
    """
    # Mock require_root_or_escalate to just return True (simulating root)
    monkeypatch.setattr(init_module, "require_root_or_escalate", lambda cmd, **kw: True)


@pytest.fixture
def mock_infrastructure_check_pass(monkeypatch):
    """Mock infrastructure check that passes all prerequisites."""

    def fake_check():
        return InfrastructureCheck(
            has_sudo=True,
            has_postgres=True,
            has_gh_cli=True,
            has_git=True,
            has_systemctl=True,
            has_deploy_user=True,
            errors=[],
        )

    monkeypatch.setattr(init_module, "check_infrastructure", fake_check)
    return fake_check


@pytest.fixture
def mock_infrastructure_check_no_sudo(monkeypatch):
    """Mock infrastructure check that fails sudo requirement."""

    def fake_check():
        return InfrastructureCheck(
            has_sudo=False,
            has_postgres=True,
            has_gh_cli=True,
            has_git=True,
            has_systemctl=True,
            has_deploy_user=True,
            errors=["This command requires root privileges."],
        )

    monkeypatch.setattr(init_module, "check_infrastructure", fake_check)
    return fake_check


@pytest.fixture
def mock_system_config(monkeypatch, tmp_path):
    """Mock system config with temp directories.

    Note: Git settings are now per-site, not in system config.
    """
    config = SystemConfig(
        agency=AgencyConfig(name="testco"),
        staging=StagingConfig(
            server="test-staging",
            domain_pattern="{slug}.test.site",
            base_dir=str(tmp_path / "srv" / "sum"),
        ),
        production=ProductionConfig(
            server="test-prod",
            ssh_host="192.168.1.1",
            base_dir="/srv/prod",
        ),
        templates=TemplatesConfig(
            dir="/opt/infra",
            systemd="systemd/test.service",
            caddy="caddy/test.caddy",
        ),
        defaults=DefaultsConfig(
            theme="theme_a",
            deploy_user="deploy",
            seed_profile="sage-stone",
        ),
    )

    monkeypatch.setattr(init_module, "get_system_config", lambda: config)
    return config


@pytest.fixture(autouse=True)
def reset_config():
    """Reset config singleton before and after each test."""
    reset_system_config()
    yield
    reset_system_config()


class TestInitCommand:
    """Tests for run_init function."""

    def test_init_requires_sudo(
        self, monkeypatch, mock_infrastructure_check_no_sudo, capsys
    ):
        """Test that init fails when not running as root.

        When not running as root, require_root_or_escalate() attempts privilege
        escalation. We mock it to simulate failed escalation.
        """

        # Mock require_root_or_escalate to simulate failed escalation
        def mock_escalate(cmd_name, **kw):
            print("requires root privileges")
            raise SystemExit(1)

        monkeypatch.setattr(init_module, "require_root_or_escalate", mock_escalate)

        with pytest.raises(SystemExit) as exc_info:
            run_init("acme")

        assert exc_info.value.code == 1
        captured = capsys.readouterr()
        assert "requires root privileges" in captured.out

    def test_init_validates_site_name(self, monkeypatch, capsys):
        """Test that init validates the site name."""
        # Mock check_infrastructure to pass
        monkeypatch.setattr(
            init_module,
            "check_infrastructure",
            lambda: InfrastructureCheck(
                has_sudo=True,
                has_postgres=True,
                has_gh_cli=True,
                has_git=True,
                has_systemctl=True,
                has_deploy_user=True,
                errors=[],
            ),
        )

        # Invalid site name should fail
        result = run_init("Invalid Name With Spaces")
        assert result == 1

        captured = capsys.readouterr()
        # Should contain validation error
        assert "❌" in captured.out or "invalid" in captured.out.lower()

    def test_init_checks_existing_site(
        self,
        monkeypatch,
        mock_infrastructure_check_pass,
        mock_system_config,
        tmp_path,
        capsys,
    ):
        """Test that init fails if site already exists."""
        # Create the site directory to simulate existing site
        site_dir = tmp_path / "srv" / "sum" / "acme"
        site_dir.mkdir(parents=True)

        result = run_init("acme")
        assert result == 1

        captured = capsys.readouterr()
        assert "already exists" in captured.out

    def test_init_calls_orchestrator(
        self,
        monkeypatch,
        mock_infrastructure_check_pass,
        mock_system_config,
        tmp_path,
    ):
        """Test that init calls the site orchestrator with correct config."""
        captured_config: dict[str, Any] = {}

        def fake_setup_site(self, config):
            captured_config["config"] = config
            return SiteSetupResult(
                success=True,
                site_slug="acme",
                site_dir=tmp_path / "srv" / "sum" / "acme",
                app_dir=tmp_path / "srv" / "sum" / "acme" / "app",
                domain="acme.test.site",
                admin_url="https://acme.test.site/admin/",
                credentials_path=tmp_path / "srv" / "sum" / "acme" / ".credentials",
                repo_url=None,
                superuser_username="admin",
                superuser_password="generated123",
            )

        from sum.setup.site_orchestrator import SiteOrchestrator

        monkeypatch.setattr(SiteOrchestrator, "setup_site", fake_setup_site)

        # Use --no-git to skip git configuration
        result = run_init("acme", theme="theme_b", no_git=True)
        assert result == 0

        config = captured_config["config"]
        assert config.site_slug == "acme"
        assert config.theme_slug == "theme_b"
        assert config.git_config is None  # --no-git sets git_config to None

    def test_init_with_custom_superuser(
        self,
        monkeypatch,
        mock_infrastructure_check_pass,
        mock_system_config,
        tmp_path,
    ):
        """Test that init passes custom superuser username."""
        captured_config: dict[str, Any] = {}

        def fake_setup_site(self, config):
            captured_config["config"] = config
            return SiteSetupResult(
                success=True,
                site_slug="acme",
                site_dir=tmp_path / "srv" / "sum" / "acme",
                app_dir=tmp_path / "srv" / "sum" / "acme" / "app",
                domain="acme.test.site",
                admin_url="https://acme.test.site/admin/",
                credentials_path=tmp_path / "srv" / "sum" / "acme" / ".credentials",
                repo_url=None,
                superuser_username="customadmin",
                superuser_password="generated123",
            )

        from sum.setup.site_orchestrator import SiteOrchestrator

        monkeypatch.setattr(SiteOrchestrator, "setup_site", fake_setup_site)

        result = run_init("acme", superuser_username="customadmin", no_git=True)
        assert result == 0

        config = captured_config["config"]
        assert config.superuser_username == "customadmin"

    def test_init_handles_orchestrator_failure(
        self,
        monkeypatch,
        mock_infrastructure_check_pass,
        mock_system_config,
        capsys,
    ):
        """Test that init handles orchestrator failures gracefully."""
        from sum.exceptions import SetupError
        from sum.setup.site_orchestrator import SiteOrchestrator

        def fake_setup_site(self, config):
            raise SetupError("Database creation failed")

        monkeypatch.setattr(SiteOrchestrator, "setup_site", fake_setup_site)

        result = run_init("acme", no_git=True)
        assert result == 1

        captured = capsys.readouterr()
        assert "Database creation failed" in captured.out

    def test_init_with_github_git_config(
        self,
        monkeypatch,
        mock_infrastructure_check_pass,
        mock_system_config,
        tmp_path,
    ):
        """Test that init passes GitHub git config to orchestrator."""
        captured_config: dict[str, Any] = {}

        def fake_setup_site(self, config):
            captured_config["config"] = config
            return SiteSetupResult(
                success=True,
                site_slug="acme",
                site_dir=tmp_path / "srv" / "sum" / "acme",
                app_dir=tmp_path / "srv" / "sum" / "acme" / "app",
                domain="acme.test.site",
                admin_url="https://acme.test.site/admin/",
                credentials_path=tmp_path / "srv" / "sum" / "acme" / ".credentials",
                repo_url="https://github.com/test-org/acme",
                superuser_username="admin",
                superuser_password="generated123",
            )

        from sum.setup.site_orchestrator import SiteOrchestrator

        monkeypatch.setattr(SiteOrchestrator, "setup_site", fake_setup_site)

        result = run_init("acme", git_provider="github", git_org="test-org")
        assert result == 0

        config = captured_config["config"]
        assert config.git_config is not None
        assert config.git_config.provider == "github"
        assert config.git_config.org == "test-org"


class TestInitGitValidation:
    """Tests for init command git flag validation."""

    def test_init_requires_git_flags_or_no_git(
        self,
        monkeypatch,
        mock_infrastructure_check_pass,
        mock_system_config,
        capsys,
    ):
        """Test that init fails when neither git flags nor --no-git is provided."""
        result = run_init("acme")  # No git flags, no --no-git
        assert result == 1

        captured = capsys.readouterr()
        assert "Git provider required" in captured.out
        assert "--git-provider" in captured.out
        assert "--no-git" in captured.out

    def test_init_requires_git_org_with_provider(
        self,
        monkeypatch,
        mock_infrastructure_check_pass,
        mock_system_config,
        capsys,
    ):
        """Test that init fails when --git-provider but no --git-org."""
        result = run_init("acme", git_provider="github")  # No --git-org
        assert result == 1

        captured = capsys.readouterr()
        assert "Git organization required" in captured.out
        assert "--git-org" in captured.out

    def test_init_gitea_requires_url(
        self,
        monkeypatch,
        mock_infrastructure_check_pass,
        mock_system_config,
        capsys,
    ):
        """Test that init fails when --git-provider=gitea but no --gitea-url."""
        result = run_init("acme", git_provider="gitea", git_org="clients")
        assert result == 1

        captured = capsys.readouterr()
        assert "Gitea URL required" in captured.out
        assert "--gitea-url" in captured.out


class TestInitOutputFormat:
    """Tests for init command output formatting."""

    def test_init_outputs_site_summary(
        self,
        monkeypatch,
        mock_infrastructure_check_pass,
        mock_system_config,
        tmp_path,
        capsys,
    ):
        """Test that init outputs site information on success."""

        def fake_setup_site(self, config):
            return SiteSetupResult(
                success=True,
                site_slug="acme",
                site_dir=tmp_path / "srv" / "sum" / "acme",
                app_dir=tmp_path / "srv" / "sum" / "acme" / "app",
                domain="acme.test.site",
                admin_url="https://acme.test.site/admin/",
                credentials_path=tmp_path / "srv" / "sum" / "acme" / ".credentials",
                repo_url="https://github.com/testco-org/acme",
                superuser_username="admin",
                superuser_password="testpass123",
            )

        from sum.setup.site_orchestrator import SiteOrchestrator

        monkeypatch.setattr(SiteOrchestrator, "setup_site", fake_setup_site)

        result = run_init("acme", git_provider="github", git_org="testco-org")
        assert result == 0

        captured = capsys.readouterr()
        # Check for key output elements
        assert "acme.test.site" in captured.out
        assert "admin" in captured.out
        assert "testpass123" in captured.out
        assert "github.com" in captured.out  # Test assertion, not URL sanitization
