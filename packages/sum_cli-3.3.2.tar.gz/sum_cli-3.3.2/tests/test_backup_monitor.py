"""Tests for backup monitor email sending functions."""

from __future__ import annotations

import subprocess
from email.mime.text import MIMEText
from unittest.mock import MagicMock, patch

import pytest
from sum.setup.backup_monitor import (
    _describe_delivery_method,
    _send_alert_email,
    _send_via_sendmail,
    _send_via_smtp,
    run_backup_monitor,
    send_test_email,
)
from sum.system_config import (
    AlertsConfig,
    BackupsConfig,
    RetentionConfig,
    StorageBoxConfig,
)


@pytest.fixture
def sample_msg():
    """Create a sample MIMEText message for testing."""
    msg = MIMEText("Test body")
    msg["Subject"] = "Test Subject"
    msg["From"] = "sender@test.com"
    msg["To"] = "recipient@test.com"
    return msg


class TestSendViaSendmail:
    """Tests for _send_via_sendmail."""

    def test_success(self, sample_msg):
        with (
            patch(
                "sum.setup.backup_monitor.shutil.which",
                return_value="/usr/sbin/sendmail",
            ),
            patch("sum.setup.backup_monitor.subprocess.run") as mock_run,
        ):
            mock_run.return_value = MagicMock(returncode=0)
            assert _send_via_sendmail(sample_msg) is True
            mock_run.assert_called_once()
            args = mock_run.call_args
            assert args[0][0] == ["/usr/sbin/sendmail", "-t"]

    def test_uses_discovered_path(self, sample_msg):
        """sendmail binary is found via shutil.which, not hardcoded."""
        with (
            patch(
                "sum.setup.backup_monitor.shutil.which",
                return_value="/usr/bin/sendmail",
            ),
            patch("sum.setup.backup_monitor.subprocess.run") as mock_run,
        ):
            mock_run.return_value = MagicMock(returncode=0)
            _send_via_sendmail(sample_msg)
            args = mock_run.call_args
            assert args[0][0] == ["/usr/bin/sendmail", "-t"]

    def test_bad_returncode(self, sample_msg):
        with (
            patch(
                "sum.setup.backup_monitor.shutil.which",
                return_value="/usr/sbin/sendmail",
            ),
            patch("sum.setup.backup_monitor.subprocess.run") as mock_run,
        ):
            mock_run.return_value = MagicMock(returncode=1)
            assert _send_via_sendmail(sample_msg) is False

    def test_missing_binary(self, sample_msg):
        with patch("sum.setup.backup_monitor.shutil.which", return_value=None):
            assert _send_via_sendmail(sample_msg) is False

    def test_timeout(self, sample_msg):
        with (
            patch(
                "sum.setup.backup_monitor.shutil.which",
                return_value="/usr/sbin/sendmail",
            ),
            patch("sum.setup.backup_monitor.subprocess.run") as mock_run,
        ):
            mock_run.side_effect = subprocess.TimeoutExpired(cmd="sendmail", timeout=30)
            assert _send_via_sendmail(sample_msg) is False


class TestSendViaSmtp:
    """Tests for _send_via_smtp."""

    def test_plain_no_auth(self, sample_msg):
        with patch("sum.setup.backup_monitor.smtplib.SMTP") as mock_smtp_cls:
            mock_smtp = MagicMock()
            mock_smtp_cls.return_value.__enter__ = MagicMock(return_value=mock_smtp)
            mock_smtp_cls.return_value.__exit__ = MagicMock(return_value=False)

            assert _send_via_smtp(sample_msg, host="localhost", port=25) is True
            mock_smtp_cls.assert_called_once_with("localhost", 25, timeout=30)
            mock_smtp.starttls.assert_not_called()
            mock_smtp.login.assert_not_called()
            mock_smtp.send_message.assert_called_once_with(sample_msg)

    def test_starttls_with_auth(self, sample_msg):
        with patch("sum.setup.backup_monitor.smtplib.SMTP") as mock_smtp_cls:
            mock_smtp = MagicMock()
            mock_smtp_cls.return_value.__enter__ = MagicMock(return_value=mock_smtp)
            mock_smtp_cls.return_value.__exit__ = MagicMock(return_value=False)

            assert (
                _send_via_smtp(
                    sample_msg,
                    host="smtp.relay.com",
                    port=587,
                    username="user",
                    password="pass",
                    use_tls=True,
                )
                is True
            )
            mock_smtp.starttls.assert_called_once()
            mock_smtp.login.assert_called_once_with("user", "pass")

    def test_implicit_tls_port_465(self, sample_msg):
        with patch("sum.setup.backup_monitor.smtplib.SMTP_SSL") as mock_ssl_cls:
            mock_smtp = MagicMock()
            mock_ssl_cls.return_value.__enter__ = MagicMock(return_value=mock_smtp)
            mock_ssl_cls.return_value.__exit__ = MagicMock(return_value=False)

            assert (
                _send_via_smtp(
                    sample_msg,
                    host="smtp.relay.com",
                    port=465,
                    username="user",
                    password="secret",
                    use_tls=True,
                )
                is True
            )
            mock_ssl_cls.assert_called_once_with("smtp.relay.com", 465, timeout=30)
            mock_smtp.login.assert_called_once_with("user", "secret")

    def test_implicit_tls_port_465_even_without_use_tls(self, sample_msg):
        """Port 465 always uses SMTP_SSL, even if use_tls is False."""
        with patch("sum.setup.backup_monitor.smtplib.SMTP_SSL") as mock_ssl_cls:
            mock_smtp = MagicMock()
            mock_ssl_cls.return_value.__enter__ = MagicMock(return_value=mock_smtp)
            mock_ssl_cls.return_value.__exit__ = MagicMock(return_value=False)

            assert (
                _send_via_smtp(
                    sample_msg,
                    host="smtp.relay.com",
                    port=465,
                    use_tls=False,
                )
                is True
            )
            mock_ssl_cls.assert_called_once_with("smtp.relay.com", 465, timeout=30)

    def test_no_login_when_username_empty(self, sample_msg):
        with patch("sum.setup.backup_monitor.smtplib.SMTP") as mock_smtp_cls:
            mock_smtp = MagicMock()
            mock_smtp_cls.return_value.__enter__ = MagicMock(return_value=mock_smtp)
            mock_smtp_cls.return_value.__exit__ = MagicMock(return_value=False)

            _send_via_smtp(
                sample_msg,
                host="relay",
                port=587,
                username="",
                password="pass",
                use_tls=True,
            )
            mock_smtp.login.assert_not_called()

    def test_no_login_when_password_empty(self, sample_msg):
        with patch("sum.setup.backup_monitor.smtplib.SMTP") as mock_smtp_cls:
            mock_smtp = MagicMock()
            mock_smtp_cls.return_value.__enter__ = MagicMock(return_value=mock_smtp)
            mock_smtp_cls.return_value.__exit__ = MagicMock(return_value=False)

            _send_via_smtp(
                sample_msg,
                host="relay",
                port=587,
                username="user",
                password="",
                use_tls=True,
            )
            mock_smtp.login.assert_not_called()

    def test_connection_failure(self, sample_msg):
        with patch("sum.setup.backup_monitor.smtplib.SMTP") as mock_smtp_cls:
            mock_smtp_cls.side_effect = OSError("Connection refused")
            assert _send_via_smtp(sample_msg, host="bad-host", port=25) is False

    def test_refuses_credentials_without_tls(self, sample_msg):
        """Credentials must not be sent over plaintext connections."""
        result = _send_via_smtp(
            sample_msg,
            host="smtp.relay.com",
            port=587,
            username="user",
            password="secret",
            use_tls=False,
        )
        assert result is False


class TestSendAlertEmail:
    """Tests for _send_alert_email orchestrator."""

    def test_external_relay_path(self, tmp_path):
        pw_file = tmp_path / "password"
        pw_file.write_text("api_key\n")
        alerts = AlertsConfig(
            email="alerts@agency.com",
            smtp_host="smtp.resend.com",
            smtp_port=587,
            smtp_username="resend",
            smtp_password_file=str(pw_file),
            smtp_use_tls=True,
            from_address="backups@agency.com",
        )

        with patch("sum.setup.backup_monitor._send_via_smtp") as mock_smtp:
            mock_smtp.return_value = True
            result = _send_alert_email(alerts, "Test Subject", "Test Body")

        assert result is True
        mock_smtp.assert_called_once()
        call_kwargs = mock_smtp.call_args
        assert call_kwargs[1]["host"] == "smtp.resend.com"
        assert call_kwargs[1]["port"] == 587
        assert call_kwargs[1]["username"] == "resend"
        assert call_kwargs[1]["password"] == "api_key"
        assert call_kwargs[1]["use_tls"] is True

    def test_external_relay_no_sendmail_fallback(self, tmp_path):
        """External relay should NOT fall back to sendmail."""
        pw_file = tmp_path / "password"
        pw_file.write_text("key\n")
        alerts = AlertsConfig(
            email="a@b.com",
            smtp_host="smtp.relay.com",
            smtp_port=587,
            smtp_password_file=str(pw_file),
        )

        with (
            patch("sum.setup.backup_monitor._send_via_smtp") as mock_smtp,
            patch("sum.setup.backup_monitor._send_via_sendmail") as mock_sendmail,
        ):
            mock_smtp.return_value = False
            result = _send_alert_email(alerts, "Sub", "Body")

        assert result is False
        mock_sendmail.assert_not_called()

    def test_localhost_sendmail_success(self):
        alerts = AlertsConfig(email="a@b.com")

        with (
            patch("sum.setup.backup_monitor._send_via_sendmail") as mock_sendmail,
            patch("sum.setup.backup_monitor._send_via_smtp") as mock_smtp,
        ):
            mock_sendmail.return_value = True
            result = _send_alert_email(alerts, "Sub", "Body")

        assert result is True
        mock_sendmail.assert_called_once()
        mock_smtp.assert_not_called()

    def test_localhost_smtp_fallback(self):
        alerts = AlertsConfig(email="a@b.com")

        with (
            patch("sum.setup.backup_monitor._send_via_sendmail") as mock_sendmail,
            patch("sum.setup.backup_monitor._send_via_smtp") as mock_smtp,
        ):
            mock_sendmail.return_value = False
            mock_smtp.return_value = True
            result = _send_alert_email(alerts, "Sub", "Body")

        assert result is True
        mock_sendmail.assert_called_once()
        mock_smtp.assert_called_once()
        assert mock_smtp.call_args[1]["host"] == "localhost"
        assert mock_smtp.call_args[1]["port"] == 25

    def test_all_delivery_methods_fail(self):
        alerts = AlertsConfig(email="a@b.com")

        with (
            patch("sum.setup.backup_monitor._send_via_sendmail") as mock_sendmail,
            patch("sum.setup.backup_monitor._send_via_smtp") as mock_smtp,
        ):
            mock_sendmail.return_value = False
            mock_smtp.return_value = False
            result = _send_alert_email(alerts, "Sub", "Body")

        assert result is False

    def test_rejects_newline_in_from_address(self):
        """Header injection via from_address is blocked."""
        alerts = AlertsConfig(
            email="a@b.com",
            from_address="evil@bad.com\r\nBcc: victim@example.com",
        )
        with patch("sum.setup.backup_monitor._send_via_sendmail") as mock_sendmail:
            result = _send_alert_email(alerts, "Subject", "Body")
        assert result is False
        mock_sendmail.assert_not_called()

    def test_rejects_newline_in_email(self):
        """Header injection via email (To) is blocked."""
        alerts = AlertsConfig(email="evil@bad.com\nBcc: victim@example.com")
        with patch("sum.setup.backup_monitor._send_via_sendmail") as mock_sendmail:
            result = _send_alert_email(alerts, "Subject", "Body")
        assert result is False
        mock_sendmail.assert_not_called()

    def test_rejects_newline_in_subject(self):
        """Header injection via subject is blocked."""
        alerts = AlertsConfig(email="a@b.com")
        with patch("sum.setup.backup_monitor._send_via_sendmail") as mock_sendmail:
            result = _send_alert_email(alerts, "Bad\r\nBcc: victim@example.com", "Body")
        assert result is False
        mock_sendmail.assert_not_called()

    def test_message_uses_from_address(self):
        alerts = AlertsConfig(
            email="recipient@test.com",
            from_address="custom-sender@agency.com",
        )

        with patch("sum.setup.backup_monitor._send_via_sendmail") as mock_sendmail:
            mock_sendmail.return_value = True
            _send_alert_email(alerts, "Subject", "Body")

        msg = mock_sendmail.call_args[0][0]
        assert msg["From"] == "custom-sender@agency.com"
        assert msg["To"] == "recipient@test.com"


class TestRunBackupMonitorSmtpIntegration:
    """Integration test: run_backup_monitor exercises SMTP relay path."""

    def test_stale_backup_sends_via_external_smtp(self, tmp_path):
        """When a backup is stale and external SMTP is configured,
        _send_alert_email receives the full AlertsConfig."""
        alerts = AlertsConfig(
            email="alerts@agency.com",
            smtp_host="smtp.resend.com",
            smtp_port=587,
            smtp_use_tls=True,
        )
        backups = BackupsConfig(
            storage_box=StorageBoxConfig(
                host="u123.storagebox.de",
                user="u123",
                fingerprint="SHA256:xxxx",
            ),
            retention=RetentionConfig(),
            alerts=alerts,
        )

        mock_config = MagicMock()
        mock_config.backups = backups

        # One site with a stale backup (72 hours old)
        site_dir = tmp_path / "acme"
        site_dir.mkdir()
        import time

        stale_timestamp = int(time.time()) - (72 * 3600)
        (site_dir / "backup_status").write_text(str(stale_timestamp))

        mock_config.get_site_dir.return_value = site_dir

        with (
            patch(
                "sum.setup.backup_monitor.get_system_config",
                return_value=mock_config,
            ),
            patch(
                "sum.setup.backup_monitor.load_allocated_ports",
                return_value={"acme": 5433},
            ),
            patch("sum.setup.backup_monitor._send_alert_email") as mock_send,
        ):
            mock_send.return_value = True
            result = run_backup_monitor(send_alerts=True, verbose=False)

        assert result == 1  # stale backup = exit code 1
        mock_send.assert_called_once()
        sent_config = mock_send.call_args[0][0]
        assert isinstance(sent_config, AlertsConfig)
        assert sent_config.smtp_host == "smtp.resend.com"
        assert sent_config.email == "alerts@agency.com"


class TestDescribeDeliveryMethod:
    """Tests for _describe_delivery_method."""

    def test_external_starttls(self):
        alerts = AlertsConfig(
            email="a@b.com",
            smtp_host="smtp.resend.com",
            smtp_port=587,
            smtp_use_tls=True,
        )
        assert _describe_delivery_method(alerts) == "smtp.resend.com:587 (STARTTLS)"

    def test_external_implicit_tls(self):
        alerts = AlertsConfig(
            email="a@b.com",
            smtp_host="smtp.relay.com",
            smtp_port=465,
            smtp_use_tls=True,
        )
        assert _describe_delivery_method(alerts) == "smtp.relay.com:465 (implicit TLS)"

    def test_external_plain(self):
        alerts = AlertsConfig(
            email="a@b.com",
            smtp_host="smtp.relay.com",
            smtp_port=587,
            smtp_use_tls=False,
        )
        assert _describe_delivery_method(alerts) == "smtp.relay.com:587 (plain)"

    def test_localhost(self):
        alerts = AlertsConfig(email="a@b.com")
        assert _describe_delivery_method(alerts) == "local sendmail / localhost:25"

    def test_empty_smtp_host(self):
        alerts = AlertsConfig(email="a@b.com", smtp_host="")
        assert _describe_delivery_method(alerts) == "local sendmail / localhost:25"


class TestSendTestEmail:
    """Tests for send_test_email."""

    def _make_config(self, alerts=None):
        """Create a mock SystemConfig with optional alerts."""
        mock_config = MagicMock()
        if alerts is None:
            alerts = AlertsConfig(email="alerts@agency.com")
        mock_config.backups = BackupsConfig(
            storage_box=StorageBoxConfig(
                host="u123.storagebox.de",
                user="u123",
                fingerprint="SHA256:xxxx",
            ),
            retention=RetentionConfig(),
            alerts=alerts,
        )
        return mock_config

    def test_success_prints_delivery_info(self, capsys):
        mock_config = self._make_config()

        with (
            patch(
                "sum.setup.backup_monitor.get_system_config",
                return_value=mock_config,
            ),
            patch("sum.setup.backup_monitor._send_alert_email") as mock_send,
        ):
            mock_send.return_value = True
            result = send_test_email(verbose=False)

        assert result == 0
        output = capsys.readouterr().out
        assert "From:" in output
        assert "To:" in output
        assert "Via:" in output
        assert "Test email sent successfully" in output

    def test_failure_suggests_verbose(self, capsys):
        mock_config = self._make_config()

        with (
            patch(
                "sum.setup.backup_monitor.get_system_config",
                return_value=mock_config,
            ),
            patch("sum.setup.backup_monitor._send_alert_email") as mock_send,
        ):
            mock_send.return_value = False
            result = send_test_email(verbose=False)

        assert result == 1
        output = capsys.readouterr().out
        assert "Test email failed" in output
        assert "Run with -v" in output

    def test_failure_verbose_no_hint(self, capsys):
        """When verbose is True, don't suggest -v (already using it)."""
        mock_config = self._make_config()

        with (
            patch(
                "sum.setup.backup_monitor.get_system_config",
                return_value=mock_config,
            ),
            patch("sum.setup.backup_monitor._send_alert_email") as mock_send,
        ):
            mock_send.return_value = False
            result = send_test_email(verbose=True)

        assert result == 1
        output = capsys.readouterr().out
        assert "Test email failed" in output
        assert "Run with -v" not in output

    def test_no_backups_config(self, capsys):
        mock_config = MagicMock()
        mock_config.backups = None

        with patch(
            "sum.setup.backup_monitor.get_system_config",
            return_value=mock_config,
        ):
            result = send_test_email(verbose=False)

        assert result == 1
        output = capsys.readouterr().out
        assert "not configured" in output
        assert "sum-platform setup" in output

    def test_config_error(self, capsys):
        from sum.system_config import ConfigurationError

        with patch(
            "sum.setup.backup_monitor.get_system_config",
            side_effect=ConfigurationError("Config missing"),
        ):
            result = send_test_email(verbose=False)

        assert result == 1
        output = capsys.readouterr().out
        assert "Config missing" in output

    def test_verbose_enables_debug_logging(self):
        mock_config = self._make_config()
        import logging

        logger = logging.getLogger("sum.setup.backup_monitor")
        handlers_before = len(logger.handlers)
        level_before = logger.level

        with (
            patch(
                "sum.setup.backup_monitor.get_system_config",
                return_value=mock_config,
            ),
            patch("sum.setup.backup_monitor._send_alert_email") as mock_send,
        ):
            # Capture whether DEBUG was active during the send call
            mock_send.side_effect = lambda *a, **kw: (
                self._assert_debug_active(logger) or True
            )
            send_test_email(verbose=True)

        # Verify cleanup: handler removed and level restored
        assert len(logger.handlers) == handlers_before
        assert logger.level == level_before

    @staticmethod
    def _assert_debug_active(logger):
        import logging

        assert logger.level == logging.DEBUG
        assert any(isinstance(h, logging.StreamHandler) for h in logger.handlers)

    def test_uses_real_delivery_path(self):
        """send_test_email calls _send_alert_email with the AlertsConfig."""
        alerts = AlertsConfig(
            email="alerts@agency.com",
            smtp_host="smtp.resend.com",
            smtp_port=587,
            smtp_use_tls=True,
        )
        mock_config = self._make_config(alerts=alerts)

        with (
            patch(
                "sum.setup.backup_monitor.get_system_config",
                return_value=mock_config,
            ),
            patch("sum.setup.backup_monitor._send_alert_email") as mock_send,
        ):
            mock_send.return_value = True
            send_test_email(verbose=False)

        mock_send.assert_called_once()
        sent_alerts = mock_send.call_args[0][0]
        assert isinstance(sent_alerts, AlertsConfig)
        assert sent_alerts.smtp_host == "smtp.resend.com"

    def test_non_verbose_suppresses_transport_diagnostics(self, capsys):
        """Non-verbose mode should not emit transport-level log messages."""
        mock_config = self._make_config()

        with (
            patch(
                "sum.setup.backup_monitor.get_system_config",
                return_value=mock_config,
            ),
            patch("sum.setup.backup_monitor.smtplib.SMTP") as mock_smtp_cls,
            patch("sum.setup.backup_monitor.shutil.which", return_value=None),
        ):
            mock_smtp_cls.side_effect = OSError("Connection refused")
            send_test_email(verbose=False)

        captured = capsys.readouterr()
        # Transport details should NOT appear in non-verbose output
        assert "Connection refused" not in captured.out
        assert "Connection refused" not in captured.err
        # User-facing failure message should appear
        assert "Test email failed" in captured.out
        assert "Run with -v" in captured.out

    def test_verbose_shows_transport_diagnostics(self, capsys):
        """Verbose mode should surface transport-level debug messages."""
        mock_config = self._make_config()

        with (
            patch(
                "sum.setup.backup_monitor.get_system_config",
                return_value=mock_config,
            ),
            patch("sum.setup.backup_monitor.smtplib.SMTP") as mock_smtp_cls,
            patch("sum.setup.backup_monitor.shutil.which", return_value=None),
        ):
            mock_smtp_cls.side_effect = OSError("Connection refused")
            send_test_email(verbose=True)

        captured = capsys.readouterr()
        # Transport details SHOULD appear in verbose output
        assert "Connection refused" in captured.err
        # User-facing failure message should still appear
        assert "Test email failed" in captured.out
