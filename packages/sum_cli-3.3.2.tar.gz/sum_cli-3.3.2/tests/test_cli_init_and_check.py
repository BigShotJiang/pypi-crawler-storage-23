"""Tests for CLI init validation and check command.

NOTE: Tests for the old scaffold-to-clients init behavior have been removed
as the init command was refactored to create production sites at /srv/sum/
instead of scaffolding to clients/. See #1298.

The check command tests that don't depend on init remain here.
"""

from __future__ import annotations

import sys

from sum.commands.check import run_check
from sum.utils.project import validate_project_name


def test_validate_project_name_allows_hyphens_and_normalizes() -> None:
    """Test that project name validation handles hyphens correctly."""
    naming = validate_project_name("acme-kitchens")
    assert naming.slug == "acme-kitchens"
    assert naming.python_package == "acme_kitchens"


def test_check_fails_on_missing_required_env_vars(tmp_path, monkeypatch) -> None:
    """Test that check fails when required env vars from .env.example are missing."""
    monkeypatch.delenv("FOO", raising=False)

    # Create minimal fake project in tmp_path (outside monorepo context)
    project = tmp_path / "proj"
    project.mkdir()
    (project / "manage.py").write_text(
        'import os\nos.environ.setdefault("DJANGO_SETTINGS_MODULE", "dummy.settings")\n',
        encoding="utf-8",
    )
    (project / ".env.example").write_text("FOO=bar\n", encoding="utf-8")
    # No .env and no FOO in os.environ

    pkg = project / "dummy"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "settings.py").write_text('ROOT_URLCONF="dummy.urls"\n', encoding="utf-8")
    (pkg / "urls.py").write_text('# include("sum_core.ops.urls")\n', encoding="utf-8")

    monkeypatch.chdir(project)
    # Ensure the fake package is importable
    sys.path.insert(0, str(project))
    try:
        # This will fail due to missing env var (FOO) and possibly other issues
        # since we're outside monorepo context
        assert run_check() == 1
    finally:
        sys.path.remove(str(project))


def test_check_standalone_mode_fails_with_friendly_message(
    tmp_path, monkeypatch, capsys
) -> None:
    """
    Test that standalone mode (no monorepo detected) provides friendly error
    when sum_core is not installed.
    """
    # Create minimal project structure in tmp_path (isolated from monorepo)
    project = tmp_path / "standalone_proj"
    project.mkdir()
    (project / "manage.py").write_text(
        'import os\nos.environ.setdefault("DJANGO_SETTINGS_MODULE", "mysite.settings")\n',
        encoding="utf-8",
    )
    (project / ".env.example").write_text("SECRET_KEY=changeme\n", encoding="utf-8")
    (project / ".env").write_text("SECRET_KEY=test\n", encoding="utf-8")

    pkg = project / "mysite"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("", encoding="utf-8")
    (pkg / "settings.py").write_text('ROOT_URLCONF="mysite.urls"\n', encoding="utf-8")
    (pkg / "urls.py").write_text(
        "# no sum_core wiring\nurlpatterns = []\n", encoding="utf-8"
    )

    # Critical: ensure sum_core is NOT importable
    # We remove any paths that might contain sum_core
    original_path = sys.path.copy()
    sys.path = [p for p in sys.path if "core" not in p and "sum_core" not in p]

    # Also add project to path so settings can be imported
    sys.path.insert(0, str(project))

    monkeypatch.chdir(project)
    try:
        exit_code = run_check()
        captured = capsys.readouterr()

        # Should fail (exit code 1)
        assert exit_code == 1

        # Should contain friendly message about installing requirements
        assert (
            "Install requirements" in captured.out or "sum_core import" in captured.out
        )
    finally:
        sys.path = original_path


# NOTE: The following tests were removed as they depended on the old
# scaffold-to-clients init behavior which was replaced by production
# site creation in #1298:
# - test_init_creates_project_and_check_passes
# - test_cli_init_and_check_do_not_remove_theme_a
# - test_check_fails_when_theme_compiled_css_missing
# - test_check_fails_when_theme_slug_mismatch
