from __future__ import annotations

import subprocess
from pathlib import Path

import pytest
from sum.utils.environment import ExecutionMode
from sum.utils.validation import ProjectValidator, ValidationStatus


def _create_project(tmp_path: Path) -> Path:
    project_path = tmp_path / "project"
    project_path.mkdir()
    return project_path


def _create_venv(project_path: Path) -> None:
    venv_bin = project_path / ".venv" / "bin"
    venv_bin.mkdir(parents=True)
    (venv_bin / "python").write_text("", encoding="utf-8")


def _create_external_venv(site_path: Path) -> None:
    venv_bin = site_path / "venv" / "bin"
    venv_bin.mkdir(parents=True)
    (venv_bin / "python").write_text("", encoding="utf-8")


def test_check_venv_exists(tmp_path: Path) -> None:
    project_path = _create_project(tmp_path)
    validator = ProjectValidator(project_path, ExecutionMode.STANDALONE)

    result = validator.check_venv_exists()
    assert result.status is ValidationStatus.FAIL
    assert result.remediation

    _create_venv(project_path)
    result = validator.check_venv_exists()
    assert result.status is ValidationStatus.OK


def test_check_venv_exists_for_production_layout(tmp_path: Path) -> None:
    site_path = tmp_path / "acme"
    app_path = site_path / "app"
    app_path.mkdir(parents=True)
    (app_path / "manage.py").write_text("print('ok')", encoding="utf-8")

    validator = ProjectValidator(app_path, ExecutionMode.STANDALONE)
    result = validator.check_venv_exists()
    assert result.status is ValidationStatus.FAIL

    _create_external_venv(site_path)
    result = validator.check_venv_exists()
    assert result.status is ValidationStatus.OK


def test_check_packages_installed_skips_without_venv(tmp_path: Path) -> None:
    project_path = _create_project(tmp_path)
    validator = ProjectValidator(project_path, ExecutionMode.STANDALONE)

    result = validator.check_packages_installed()
    assert result.status is ValidationStatus.SKIP


def test_check_packages_installed_reports_missing_package(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    project_path = _create_project(tmp_path)
    _create_venv(project_path)
    validator = ProjectValidator(project_path, ExecutionMode.STANDALONE)

    calls = {"count": 0}

    def fake_run(cmd, capture_output=True, text=True):
        calls["count"] += 1
        return subprocess.CompletedProcess(cmd, 1 if calls["count"] == 2 else 0)

    monkeypatch.setattr("sum.utils.validation.subprocess.run", fake_run)

    result = validator.check_packages_installed()
    assert result.status is ValidationStatus.FAIL
    assert "wagtail" in result.message
    assert result.remediation


def test_check_env_local(tmp_path: Path) -> None:
    project_path = _create_project(tmp_path)
    validator = ProjectValidator(project_path, ExecutionMode.STANDALONE)

    result = validator.check_env_local()
    assert result.status is ValidationStatus.SKIP

    env_local = project_path / ".env.local"
    env_local.write_text("DJANGO_SUPERUSER_USERNAME=admin\n", encoding="utf-8")
    result = validator.check_env_local()
    assert result.status is ValidationStatus.OK


def test_check_migrations_applied(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    project_path = _create_project(tmp_path)
    _create_venv(project_path)
    validator = ProjectValidator(project_path, ExecutionMode.STANDALONE)

    class DummyExecutor:
        def __init__(
            self,
            project_path: Path,
            mode: ExecutionMode,
            python_path: Path | None = None,
        ) -> None:
            self.project_path = project_path
            self.mode = mode
            self.python_path = python_path

        def run_command(self, command, check=False):
            return subprocess.CompletedProcess(command, 0, stdout="", stderr="")

    monkeypatch.setattr("sum.utils.validation.DjangoCommandExecutor", DummyExecutor)
    result = validator.check_migrations_applied()
    assert result.status is ValidationStatus.OK


def test_check_homepage_exists_reports_missing(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    project_path = _create_project(tmp_path)
    _create_venv(project_path)
    validator = ProjectValidator(project_path, ExecutionMode.STANDALONE)

    class DummyExecutor:
        def __init__(
            self,
            project_path: Path,
            mode: ExecutionMode,
            python_path: Path | None = None,
        ) -> None:
            self.project_path = project_path
            self.mode = mode
            self.python_path = python_path

        def run_command(self, command, check=False):
            return subprocess.CompletedProcess(command, 0, stdout="blog", stderr="")

    monkeypatch.setattr("sum.utils.validation.DjangoCommandExecutor", DummyExecutor)
    result = validator.check_homepage_exists()
    assert result.status is ValidationStatus.FAIL
    assert result.remediation


def test_check_migrations_applied_uses_external_venv_python(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    site_path = tmp_path / "acme"
    app_path = site_path / "app"
    app_path.mkdir(parents=True)
    (app_path / "manage.py").write_text("print('ok')", encoding="utf-8")
    _create_external_venv(site_path)

    validator = ProjectValidator(app_path, ExecutionMode.STANDALONE)
    observed: dict[str, Path | None] = {"python_path": None}

    class DummyExecutor:
        def __init__(
            self,
            project_path: Path,
            mode: ExecutionMode,
            python_path: Path | None = None,
        ) -> None:
            observed["python_path"] = python_path

        def run_command(self, command, check=False):
            return subprocess.CompletedProcess(command, 0, stdout="", stderr="")

    monkeypatch.setattr("sum.utils.validation.DjangoCommandExecutor", DummyExecutor)
    result = validator.check_migrations_applied()
    assert result.status is ValidationStatus.OK
    assert observed["python_path"] == site_path / "venv" / "bin" / "python"
