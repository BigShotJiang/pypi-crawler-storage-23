"""Regression tests for .env parser (H-16)."""

from __future__ import annotations

import pytest
from sum.utils.validation import _parse_env_assignments


class TestEnvParserQuoteStripping:
    """H-16: Strip quotes and export prefix from .env values."""

    def test_strips_double_quotes(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('DATABASE_URL="postgres://localhost/db"\n')
        result = _parse_env_assignments(env_file)
        assert result["DATABASE_URL"] == "postgres://localhost/db"

    def test_strips_single_quotes(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("SECRET_KEY='my-secret-key'\n")
        result = _parse_env_assignments(env_file)
        assert result["SECRET_KEY"] == "my-secret-key"

    def test_strips_export_prefix(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("export MY_VAR=hello\n")
        result = _parse_env_assignments(env_file)
        assert result["MY_VAR"] == "hello"

    def test_strips_export_with_quotes(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text('export MY_VAR="hello world"\n')
        result = _parse_env_assignments(env_file)
        assert result["MY_VAR"] == "hello world"

    def test_unquoted_values_unchanged(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("MY_VAR=plain_value\n")
        result = _parse_env_assignments(env_file)
        assert result["MY_VAR"] == "plain_value"

    def test_empty_value(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("MY_VAR=\n")
        result = _parse_env_assignments(env_file)
        assert result["MY_VAR"] == ""

    def test_skips_comments(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("# comment\nMY_VAR=value\n")
        result = _parse_env_assignments(env_file)
        assert "MY_VAR" in result
        assert len(result) == 1

    def test_skips_empty_lines(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text("\n\nMY_VAR=value\n\n")
        result = _parse_env_assignments(env_file)
        assert result["MY_VAR"] == "value"

    def test_mismatched_quotes_preserved(self, tmp_path):
        """Mismatched quotes are not stripped."""
        env_file = tmp_path / ".env"
        env_file.write_text("MY_VAR=\"mixed'\n")
        result = _parse_env_assignments(env_file)
        assert result["MY_VAR"] == "\"mixed'"

    def test_nonexistent_file_returns_empty(self, tmp_path):
        result = _parse_env_assignments(tmp_path / "nonexistent")
        assert result == {}

    def test_multiple_entries(self, tmp_path):
        env_file = tmp_path / ".env"
        env_file.write_text(
            'DB_NAME="mydb"\n'
            "DB_HOST=localhost\n"
            "export DB_PORT=5432\n"
            "DB_PASS='secret'\n"
        )
        result = _parse_env_assignments(env_file)
        assert result["DB_NAME"] == "mydb"
        assert result["DB_HOST"] == "localhost"
        assert result["DB_PORT"] == "5432"
        assert result["DB_PASS"] == "secret"


class TestEnvParserEdgeCases:
    """Edge cases and negative tests for .env parser."""

    def test_value_containing_equals(self, tmp_path):
        """Values containing = should be preserved."""
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="value=with=equals"\n')
        result = _parse_env_assignments(env_file)
        assert result["KEY"] == "value=with=equals"

    def test_shell_metacharacters_treated_as_literal(self, tmp_path):
        """Shell metacharacters should be treated as literal values."""
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="$(whoami)"\n')
        result = _parse_env_assignments(env_file)
        # Should NOT be executed, should be literal
        assert result["KEY"] == "$(whoami)"

    def test_backticks_treated_as_literal(self, tmp_path):
        """Backticks should be treated as literal values."""
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=`id`\n")
        result = _parse_env_assignments(env_file)
        assert result["KEY"] == "`id`"

    def test_very_long_line(self, tmp_path):
        """Very long lines should be handled correctly."""
        env_file = tmp_path / ".env"
        long_value = "x" * 10000
        env_file.write_text(f'KEY="{long_value}"\n')
        result = _parse_env_assignments(env_file)
        assert result["KEY"] == long_value

    def test_empty_value_explicit(self, tmp_path):
        """KEY= (with no value) should result in empty string."""
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=\n")
        result = _parse_env_assignments(env_file)
        assert result["KEY"] == ""

    def test_empty_value_with_quotes(self, tmp_path):
        """KEY="" should result in empty string."""
        env_file = tmp_path / ".env"
        env_file.write_text('KEY=""\n')
        result = _parse_env_assignments(env_file)
        assert result["KEY"] == ""

    def test_hash_in_value_not_comment(self, tmp_path):
        """# in value should be treated as part of value, not comment."""
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="value#with#hash"\n')
        result = _parse_env_assignments(env_file)
        assert result["KEY"] == "value#with#hash"

    def test_unquoted_hash_in_value_includes_everything(self, tmp_path):
        """Unquoted value with # should include the # and everything after."""
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=value#rest\n")
        result = _parse_env_assignments(env_file)
        # The parser should take everything after = as the value
        assert result["KEY"] == "value#rest"

    def test_whitespace_in_quoted_value(self, tmp_path):
        """Whitespace should be preserved in quoted values."""
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="  spaces  "\n')
        result = _parse_env_assignments(env_file)
        assert result["KEY"] == "  spaces  "

    def test_newline_escape_not_interpreted(self, tmp_path):
        """\\n should not be interpreted as newline."""
        env_file = tmp_path / ".env"
        env_file.write_text(r'KEY="line1\nline2"' + "\n")
        result = _parse_env_assignments(env_file)
        # Should be literal backslash-n, not actual newline
        assert result["KEY"] == r"line1\nline2"

    def test_semicolon_in_value(self, tmp_path):
        """Semicolons should be treated as literal."""
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="value;with;semicolons"\n')
        result = _parse_env_assignments(env_file)
        assert result["KEY"] == "value;with;semicolons"

    def test_pipe_in_value(self, tmp_path):
        """Pipes should be treated as literal."""
        env_file = tmp_path / ".env"
        env_file.write_text('KEY="value|with|pipes"\n')
        result = _parse_env_assignments(env_file)
        assert result["KEY"] == "value|with|pipes"

    def test_permission_denied_raises(self, tmp_path):
        """PermissionError should propagate with a descriptive message."""
        env_file = tmp_path / ".env"
        env_file.write_text("KEY=value\n")
        env_file.chmod(0o000)
        try:
            with pytest.raises(PermissionError, match="permission denied"):
                _parse_env_assignments(env_file)
        finally:
            env_file.chmod(0o644)
