"""End-to-end tests for CLI entry point and full workflow.

These tests verify the INSTALLED CLI works correctly by running actual
subprocess commands. They catch real bugs like:
- GH-1262: Entry point naming conflict (sum vs sum-platform)
- Broken pyproject.toml entry point configuration
- Installation issues

These tests require: pip install -e cli/
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from pathlib import Path

try:
    import tomllib
except ImportError:
    import tomli as tomllib  # type: ignore[import-not-found]

import pytest
from click.testing import CliRunner
from sum.cli import cli

# =============================================================================
# Entry Point Configuration Tests (Static)
# =============================================================================


def test_pyproject_entry_point_is_sum_platform() -> None:
    """Verify pyproject.toml registers 'sum-platform', NOT 'sum'.

    This would have caught GH-1262 where the entry point was named 'sum'
    which conflicts with the Unix coreutils 'sum' checksum command.
    """
    pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
    assert pyproject_path.exists(), f"pyproject.toml not found at {pyproject_path}"

    with open(pyproject_path, "rb") as f:
        config = tomllib.load(f)

    scripts = config.get("project", {}).get("scripts", {})
    assert scripts, "No [project.scripts] section found in pyproject.toml"

    # MUST have sum-platform
    assert "sum-platform" in scripts, (
        f"Entry point 'sum-platform' not found in pyproject.toml. "
        f"Found: {list(scripts.keys())}"
    )

    # MUST NOT have 'sum' (conflicts with Unix coreutils)
    assert "sum" not in scripts, (
        "Entry point 'sum' found in pyproject.toml - this conflicts with "
        "Unix coreutils 'sum' command. Use 'sum-platform' instead."
    )

    # Verify it points to the right module
    assert (
        scripts["sum-platform"] == "sum.cli:cli"
    ), f"Entry point should be 'sum.cli:cli', got: {scripts['sum-platform']}"


def test_cli_prog_name_matches_entry_point() -> None:
    """Verify CLI prog_name matches the entry point name.

    The prog_name in Click's version_option must match the entry point
    so --version shows the correct command name.
    """
    cli_path = Path(__file__).parent.parent / "sum" / "cli.py"
    assert cli_path.exists(), f"cli.py not found at {cli_path}"

    content = cli_path.read_text()

    # Check prog_name is set to sum-platform (tolerate whitespace/quote style)
    pattern = r'prog_name\s*=\s*["\']sum-platform["\']'
    assert re.search(pattern, content), (
        "CLI prog_name must be 'sum-platform' to match entry point. "
        "Check @click.version_option in cli.py"
    )


# =============================================================================
# Installed Entry Point Tests (E2E)
# =============================================================================


def _cli_is_installed() -> bool:
    """Check if sum-platform CLI is installed and accessible."""
    return shutil.which("sum-platform") is not None


def _get_repo_root() -> Path:
    """Get the repository root directory."""
    return Path(__file__).parent.parent.parent


def _get_cli_env_for_discovery() -> dict[str, str]:
    """Get environment variables for CLI theme/boilerplate discovery.

    This ensures tests work regardless of CWD by explicitly setting
    the paths the CLI uses to find themes and boilerplate.
    """
    repo_root = _get_repo_root()
    env = os.environ.copy()
    env["SUM_THEME_PATH"] = str(repo_root / "themes")
    env["SUM_BOILERPLATE_PATH"] = str(repo_root / "boilerplate")
    return env


def _run_cli(
    *args: str,
    timeout: int = 30,
    env: dict[str, str] | None = None,
    cwd: Path | None = None,
) -> subprocess.CompletedProcess[str]:
    """Run sum-platform CLI command and return result.

    Args:
        *args: CLI arguments
        timeout: Command timeout in seconds
        env: Environment variables (defaults to env with theme/boilerplate paths)
        cwd: Working directory (defaults to repo root)
    """
    if env is None:
        env = _get_cli_env_for_discovery()
    if cwd is None:
        cwd = _get_repo_root()

    return subprocess.run(
        ["sum-platform", *args],
        capture_output=True,
        text=True,
        timeout=timeout,
        env=env,
        cwd=cwd,
    )


@pytest.mark.skipif(not _cli_is_installed(), reason="CLI not installed")
class TestInstalledEntryPoint:
    """Tests that require the CLI to be installed via pip install -e cli/"""

    def test_sum_platform_command_exists(self) -> None:
        """Verify sum-platform command is in PATH."""
        path = shutil.which("sum-platform")
        assert (
            path is not None
        ), "sum-platform command not found in PATH. Run: pip install -e cli/"

    def test_sum_platform_version(self) -> None:
        """Verify sum-platform --version works and shows correct name."""
        result = _run_cli("--version")

        assert result.returncode == 0, f"--version failed: {result.stderr}"
        assert (
            "sum-platform" in result.stdout
        ), f"Version output should show 'sum-platform', got: {result.stdout}"
        assert re.search(
            r"\d+\.\d+\.\d+", result.stdout
        ), f"Version output should contain version number, got: {result.stdout}"

    def test_sum_platform_help(self) -> None:
        """Verify sum-platform --help shows all commands."""
        result = _run_cli("--help")

        assert result.returncode == 0, f"--help failed: {result.stderr}"
        assert "init" in result.stdout, "Missing 'init' command in help"
        assert "check" in result.stdout, "Missing 'check' command in help"
        assert "setup" in result.stdout, "Missing 'setup' command in help"
        assert "themes" in result.stdout, "Missing 'themes' command in help"

    def test_sum_platform_themes_lists_theme_a(self) -> None:
        """Verify sum-platform themes shows available themes."""
        result = _run_cli("themes")

        assert result.returncode == 0, f"themes failed: {result.stderr}"
        assert (
            "theme_a" in result.stdout
        ), f"theme_a not found in themes output: {result.stdout}"

    def test_sum_platform_init_help(self) -> None:
        """Verify sum-platform init --help shows options."""
        result = _run_cli("init", "--help")

        assert result.returncode == 0, f"init --help failed: {result.stderr}"
        assert "--theme" in result.stdout, "Missing --theme option"
        # The --full option was removed in the refactor to production site creation
        # Now we have --no-git, --skip-systemd, --skip-caddy instead
        assert (
            "--no-git" in result.stdout or "skip" in result.stdout.lower()
        ), "Missing skip options"

    def test_sum_platform_identifies_correctly(self) -> None:
        """Verify CLI version output identifies as sum-platform.

        This confirms the installed CLI is our SUM Platform CLI and that
        the prog_name is set correctly. Entry point naming (sum-platform
        vs sum) is validated by test_pyproject_entry_point_is_sum_platform.
        """
        result = _run_cli("--version")

        assert result.returncode == 0, "CLI should handle --version"
        assert (
            "sum-platform" in result.stdout.lower()
        ), "Output should identify as sum-platform CLI"


# =============================================================================
# Full E2E Init Workflow Test
# =============================================================================
#
# NOTE: The init command was refactored in #1298 to create production sites
# at /srv/sum/<name>/ instead of scaffolding to clients/<name>/. The new
# init command requires root access and real infrastructure (Postgres, etc.).
#
# For production site E2E tests, see cli/tests/test_e2e_production.py which
# has proper skip conditions for non-root environments.
#
# The old tests below are kept for reference but skipped since the init
# command no longer supports scaffold-only mode.


# =============================================================================
# CLI Command Logic Tests (using CliRunner for fast unit testing)
# =============================================================================


class TestCLICommandLogic:
    """Fast unit tests for CLI command logic using CliRunner.

    These complement the E2E tests above - they're faster but don't test
    the actual installed entry point.
    """

    def test_version_shows_sum_platform(self) -> None:
        """Verify version output identifies as sum-platform."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])

        assert result.exit_code == 0
        assert "sum-platform" in result.output

    def test_help_lists_all_commands(self) -> None:
        """Verify help shows all expected commands."""
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])

        assert result.exit_code == 0
        for cmd in ["init", "check", "setup", "test-email", "themes"]:
            assert cmd in result.output, f"Missing command: {cmd}"

    def test_invalid_command_shows_error(self) -> None:
        """Verify invalid commands show helpful error."""
        runner = CliRunner()
        result = runner.invoke(cli, ["not-a-real-command"])

        assert result.exit_code == 2
        assert "No such command" in result.output
