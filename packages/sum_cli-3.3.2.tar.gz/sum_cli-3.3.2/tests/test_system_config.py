"""Tests for system configuration module."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from sum.system_config import (
    AgencyConfig,
    AlertsConfig,
    ConfigurationError,
    DefaultsConfig,
    ProductionConfig,
    StagingConfig,
    SystemConfig,
    TemplatesConfig,
    get_system_config,
    reset_system_config,
)


# Fixture for a complete valid config
@pytest.fixture
def valid_config_data():
    """Return a complete valid configuration dict.

    Note: Git settings are now per-site, not in system config.
    """
    return {
        "agency": {
            "name": "testco",
        },
        "staging": {
            "server": "staging-server",
            "domain_pattern": "{slug}.test.site",
            "base_dir": "/srv/test",
        },
        "production": {
            "server": "prod-server",
            "ssh_host": "192.168.1.1",
            "base_dir": "/srv/prod",
        },
        "templates": {
            "dir": "/opt/infra",
            "systemd": "systemd/test.service",
            "caddy": "caddy/test.caddy",
        },
        "defaults": {
            "theme": "theme_test",
            "deploy_user": "testuser",
            "seed_profile": "test-profile",
        },
    }


@pytest.fixture
def valid_config_file(tmp_path, valid_config_data):
    """Create a valid config file and return its path."""
    config_file = tmp_path / "config.yml"
    config_file.write_text(yaml.dump(valid_config_data))
    return config_file


@pytest.fixture(autouse=True)
def reset_config_singleton():
    """Reset the config singleton before each test."""
    reset_system_config()
    yield
    reset_system_config()


class TestAgencyConfig:
    """Tests for AgencyConfig dataclass."""

    def test_requires_name(self):
        with pytest.raises(TypeError):
            AgencyConfig()

    def test_with_name(self):
        config = AgencyConfig(name="acme")
        assert config.name == "acme"


class TestStagingConfig:
    """Tests for StagingConfig dataclass."""

    def test_requires_all_fields(self):
        with pytest.raises(TypeError):
            StagingConfig()

    def test_with_all_fields(self):
        config = StagingConfig(
            server="staging",
            domain_pattern="{slug}.example.com",
            base_dir="/srv/sites",
        )
        assert config.server == "staging"
        assert config.domain_pattern == "{slug}.example.com"
        assert config.base_dir == "/srv/sites"


class TestProductionConfig:
    """Tests for ProductionConfig dataclass."""

    def test_requires_all_fields(self):
        with pytest.raises(TypeError):
            ProductionConfig()

    def test_with_all_fields(self):
        config = ProductionConfig(
            server="prod-01",
            ssh_host="10.0.0.1",
            base_dir="/srv/sites",
        )
        assert config.server == "prod-01"
        assert config.ssh_host == "10.0.0.1"
        assert config.base_dir == "/srv/sites"


class TestTemplatesConfig:
    """Tests for TemplatesConfig dataclass."""

    def test_requires_all_fields(self):
        with pytest.raises(TypeError):
            TemplatesConfig()

    def test_with_all_fields(self):
        config = TemplatesConfig(
            dir="/opt/infra",
            systemd="systemd/gunicorn.service",
            caddy="caddy/site.caddy",
        )
        assert config.dir == "/opt/infra"
        assert config.systemd == "systemd/gunicorn.service"
        assert config.caddy == "caddy/site.caddy"

    def test_systemd_path_property(self):
        config = TemplatesConfig(
            dir="/opt/infra",
            systemd="systemd/gunicorn.service",
            caddy="caddy/site.caddy",
        )
        expected = Path("/opt/infra/systemd/gunicorn.service")
        assert config.systemd_path == expected

    def test_caddy_path_property(self):
        config = TemplatesConfig(
            dir="/opt/infra",
            systemd="systemd/gunicorn.service",
            caddy="caddy/site.caddy",
        )
        expected = Path("/opt/infra/caddy/site.caddy")
        assert config.caddy_path == expected


class TestDefaultsConfig:
    """Tests for DefaultsConfig dataclass."""

    def test_requires_all_fields(self):
        with pytest.raises(TypeError):
            DefaultsConfig()

    def test_with_all_fields(self):
        config = DefaultsConfig(
            theme="theme_a",
            deploy_user="deploy",
            seed_profile="sage-stone",
        )
        assert config.theme == "theme_a"
        assert config.deploy_user == "deploy"
        assert config.seed_profile == "sage-stone"


class TestSystemConfig:
    """Tests for SystemConfig dataclass."""

    def test_get_site_dir_staging(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        path = config.get_site_dir("acme", target="staging")
        assert path == Path("/srv/test/acme")

    def test_get_site_dir_prod(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        path = config.get_site_dir("acme", target="prod")
        assert path == Path("/srv/prod/acme")

    def test_get_site_domain_staging(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        domain = config.get_site_domain("acme", target="staging")
        assert domain == "acme.test.site"

    def test_get_site_domain_prod_raises(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        with pytest.raises(
            ValueError, match="Production domain must be explicitly specified"
        ):
            config.get_site_domain("acme", target="prod")

    def test_get_db_name(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        assert config.get_db_name("acme") == "sum_acme"

    def test_get_db_user(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        assert config.get_db_user("acme") == "sum_acme_user"

    def test_get_systemd_service_name(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        assert config.get_systemd_service_name("acme") == "sum-acme-gunicorn"

    def test_get_caddy_config_name(self, valid_config_file):
        config = SystemConfig.load(valid_config_file)
        assert config.get_caddy_config_name("acme") == "sum-acme.caddy"


class TestSystemConfigLoad:
    """Tests for SystemConfig.load() method."""

    def test_load_raises_when_no_file(self, tmp_path):
        with pytest.raises(ConfigurationError, match="Configuration file not found"):
            SystemConfig.load(tmp_path / "nonexistent.yml")

    def test_load_from_file(self, valid_config_file, valid_config_data):
        config = SystemConfig.load(valid_config_file)

        assert config._config_path == valid_config_file
        assert config.agency.name == "testco"
        assert config.staging.domain_pattern == "{slug}.test.site"
        assert config.staging.server == "staging-server"
        assert config.defaults.theme == "theme_test"

    def test_load_from_env_var(self, valid_config_file, monkeypatch):
        monkeypatch.setenv("SUM_CONFIG_PATH", str(valid_config_file))

        config = SystemConfig.load()
        assert config.agency.name == "testco"

    def test_load_empty_file_raises(self, tmp_path):
        config_file = tmp_path / "empty.yml"
        config_file.write_text("")

        with pytest.raises(ConfigurationError, match="Configuration file is empty"):
            SystemConfig.load(config_file)

    def test_load_missing_section_raises(self, tmp_path):
        config_file = tmp_path / "partial.yml"
        config_data = {
            "agency": {"name": "test"},
            # Missing: staging, production, templates, defaults
        }
        config_file.write_text(yaml.dump(config_data))

        with pytest.raises(ConfigurationError, match="Missing required sections"):
            SystemConfig.load(config_file)

    def test_load_invalid_yaml_raises(self, tmp_path):
        config_file = tmp_path / "invalid.yml"
        config_file.write_text("invalid: yaml: content:")

        with pytest.raises(ConfigurationError, match="Invalid YAML"):
            SystemConfig.load(config_file)


class TestGetSystemConfig:
    """Tests for get_system_config() singleton function."""

    def test_raises_without_config_file(self, tmp_path, monkeypatch):
        # Point to non-existent location
        monkeypatch.setenv("SUM_CONFIG_PATH", str(tmp_path / "nonexistent.yml"))

        with pytest.raises(ConfigurationError, match="Configuration file not found"):
            get_system_config()

    def test_returns_same_instance(self, valid_config_file, monkeypatch):
        monkeypatch.setenv("SUM_CONFIG_PATH", str(valid_config_file))

        config1 = get_system_config()
        config2 = get_system_config()
        assert config1 is config2

    def test_reload_returns_new_instance(self, valid_config_file, monkeypatch):
        monkeypatch.setenv("SUM_CONFIG_PATH", str(valid_config_file))

        config1 = get_system_config()
        config2 = get_system_config(reload=True)
        assert config1 is not config2

    def test_reset_clears_singleton(self, valid_config_file, monkeypatch):
        monkeypatch.setenv("SUM_CONFIG_PATH", str(valid_config_file))

        config1 = get_system_config()
        reset_system_config()
        config2 = get_system_config()
        assert config1 is not config2


class TestAlertsConfig:
    """Tests for AlertsConfig dataclass."""

    def test_requires_email(self):
        with pytest.raises(TypeError):
            AlertsConfig()

    def test_defaults(self):
        config = AlertsConfig(email="test@example.com")
        assert config.email == "test@example.com"
        assert config.smtp_host == "localhost"
        assert config.smtp_port == 25
        assert config.smtp_username == ""
        assert config.smtp_password_file == ""
        assert config.smtp_use_tls is False
        assert config.from_address == "backup-monitor@localhost"

    def test_has_external_smtp_localhost(self):
        assert not AlertsConfig(
            email="a@b.com", smtp_host="localhost"
        ).has_external_smtp

    def test_has_external_smtp_127(self):
        assert not AlertsConfig(
            email="a@b.com", smtp_host="127.0.0.1"
        ).has_external_smtp

    def test_has_external_smtp_ipv6_loopback(self):
        assert not AlertsConfig(email="a@b.com", smtp_host="::1").has_external_smtp

    def test_has_external_smtp_empty(self):
        assert not AlertsConfig(email="a@b.com", smtp_host="").has_external_smtp

    def test_has_external_smtp_uppercase_localhost(self):
        assert not AlertsConfig(
            email="a@b.com", smtp_host="LOCALHOST"
        ).has_external_smtp

    def test_has_external_smtp_trailing_dot(self):
        assert not AlertsConfig(
            email="a@b.com", smtp_host="localhost."
        ).has_external_smtp

    def test_has_external_smtp_whitespace(self):
        assert not AlertsConfig(
            email="a@b.com", smtp_host="  localhost  "
        ).has_external_smtp

    def test_has_external_smtp_external_host(self):
        assert AlertsConfig(
            email="a@b.com", smtp_host="smtp.resend.com"
        ).has_external_smtp

    def test_get_smtp_password_no_file(self):
        config = AlertsConfig(email="a@b.com")
        assert config.get_smtp_password() == ""

    def test_get_smtp_password_reads_file(self, tmp_path):
        pw_file = tmp_path / "password"
        pw_file.write_text("  my_secret_key  \n")
        config = AlertsConfig(email="a@b.com", smtp_password_file=str(pw_file))
        assert config.get_smtp_password() == "my_secret_key"

    def test_get_smtp_password_missing_file(self):
        config = AlertsConfig(email="a@b.com", smtp_password_file="/nonexistent/path")
        assert config.get_smtp_password() == ""

    def test_get_smtp_password_missing_file_logs_warning(self, caplog):
        config = AlertsConfig(email="a@b.com", smtp_password_file="/nonexistent/path")
        with caplog.at_level("WARNING"):
            config.get_smtp_password()
        assert "Cannot read SMTP password file" in caplog.text
        assert "/nonexistent/path" in caplog.text

    def test_get_smtp_password_warns_world_readable(self, tmp_path, caplog):
        pw_file = tmp_path / "password"
        pw_file.write_text("secret\n")
        pw_file.chmod(0o644)  # world-readable
        config = AlertsConfig(email="a@b.com", smtp_password_file=str(pw_file))
        with caplog.at_level("WARNING"):
            result = config.get_smtp_password()
        assert result == "secret"
        assert "world-readable" in caplog.text
        assert "chmod 600" in caplog.text

    def test_get_smtp_password_no_warning_restrictive_perms(self, tmp_path, caplog):
        pw_file = tmp_path / "password"
        pw_file.write_text("secret\n")
        pw_file.chmod(0o600)  # restrictive
        config = AlertsConfig(email="a@b.com", smtp_password_file=str(pw_file))
        with caplog.at_level("WARNING"):
            result = config.get_smtp_password()
        assert result == "secret"
        assert "world-readable" not in caplog.text

    def test_yaml_loading_email_only(self, valid_config_data, tmp_path):
        """AlertsConfig loads from YAML with only email field."""
        valid_config_data["backups"] = {
            "storage_box": {
                "host": "u123.storagebox.de",
                "user": "u123",
                "fingerprint": "SHA256:xxxx",
            },
            "retention": {"full_backups": 2, "diff_backups": 7},
            "alerts": {"email": "alerts@test.com"},
        }
        config_file = tmp_path / "config.yml"
        config_file.write_text(yaml.dump(valid_config_data))
        config = SystemConfig.load(config_file)
        assert config.backups is not None
        assert config.backups.alerts.email == "alerts@test.com"
        assert config.backups.alerts.smtp_host == "localhost"

    def test_yaml_loading_with_smtp(self, valid_config_data, tmp_path):
        """AlertsConfig loads from YAML with SMTP fields."""
        valid_config_data["backups"] = {
            "storage_box": {
                "host": "u123.storagebox.de",
                "user": "u123",
                "fingerprint": "SHA256:xxxx",
            },
            "retention": {"full_backups": 2, "diff_backups": 7},
            "alerts": {
                "email": "alerts@test.com",
                "smtp_host": "smtp.resend.com",
                "smtp_port": 587,
                "smtp_username": "resend",
                "smtp_password_file": "/etc/sum/smtp-password",
                "smtp_use_tls": True,
                "from_address": "backups@agency.com",
            },
        }
        config_file = tmp_path / "config.yml"
        config_file.write_text(yaml.dump(valid_config_data))
        config = SystemConfig.load(config_file)
        alerts = config.backups.alerts
        assert alerts.smtp_host == "smtp.resend.com"
        assert alerts.smtp_port == 587
        assert alerts.smtp_username == "resend"
        assert alerts.smtp_password_file == "/etc/sum/smtp-password"
        assert alerts.smtp_use_tls is True
        assert alerts.from_address == "backups@agency.com"
        assert alerts.has_external_smtp


class TestLoadSectionTypeValidation:
    """Tests for type validation in SystemConfig._load_section()."""

    def test_load_section_rejects_string_for_int(self, valid_config_data, tmp_path):
        """Quoted port number (string) on an int field raises ConfigurationError."""
        valid_config_data["defaults"]["postgres_port"] = "not_a_number"
        config_file = tmp_path / "config.yml"
        config_file.write_text(yaml.dump(valid_config_data))

        with pytest.raises(ConfigurationError, match="expects int, got str"):
            SystemConfig.load(config_file)

    def test_load_section_rejects_string_for_bool(self, valid_config_data, tmp_path):
        """String 'yes' on a bool field raises ConfigurationError."""
        valid_config_data["backups"] = {
            "storage_box": {
                "host": "u123.storagebox.de",
                "user": "u123",
                "fingerprint": "SHA256:xxxx",
            },
            "retention": {"full_backups": 2, "diff_backups": 7},
            "alerts": {
                "email": "alerts@test.com",
                "smtp_use_tls": "yes",
            },
        }
        config_file = tmp_path / "config.yml"
        config_file.write_text(yaml.dump(valid_config_data))

        with pytest.raises(ConfigurationError, match="expects bool, got str"):
            SystemConfig.load(config_file)

    def test_load_section_accepts_valid_types(self, valid_config_file):
        """All fields with correct types load without error."""
        config = SystemConfig.load(valid_config_file)
        assert config.agency.name == "testco"
        assert config.staging.server == "staging-server"
        assert config.defaults.theme == "theme_test"

    def test_load_section_error_message_format(self, valid_config_data, tmp_path):
        """Error message includes field name, expected type, and actual value."""
        valid_config_data["defaults"]["postgres_port"] = "invalid"
        config_file = tmp_path / "config.yml"
        config_file.write_text(yaml.dump(valid_config_data))

        with pytest.raises(ConfigurationError) as exc_info:
            SystemConfig.load(config_file)

        msg = str(exc_info.value)
        assert "postgres_port" in msg
        assert "int" in msg
        assert "str" in msg
        assert "'invalid'" in msg

    def test_load_section_auto_coerces_string_int(self, valid_config_data, tmp_path):
        """String that is a valid integer gets auto-coerced with a warning."""
        valid_config_data["defaults"]["postgres_port"] = "5432"
        config_file = tmp_path / "config.yml"
        config_file.write_text(yaml.dump(valid_config_data))

        config = SystemConfig.load(config_file)
        assert config.defaults.postgres_port == 5432
        assert isinstance(config.defaults.postgres_port, int)

    def test_load_section_auto_coerce_logs_warning(
        self, valid_config_data, tmp_path, caplog
    ):
        """Auto-coercion from str to int logs a warning."""
        valid_config_data["defaults"]["postgres_port"] = "5432"
        config_file = tmp_path / "config.yml"
        config_file.write_text(yaml.dump(valid_config_data))

        with caplog.at_level("WARNING"):
            SystemConfig.load(config_file)

        assert "auto-coercing" in caplog.text
        assert "postgres_port" in caplog.text

    def test_load_section_rejects_int_for_str(self, valid_config_data, tmp_path):
        """An int value on a str field raises ConfigurationError."""
        valid_config_data["agency"]["name"] = 12345
        config_file = tmp_path / "config.yml"
        config_file.write_text(yaml.dump(valid_config_data))

        with pytest.raises(ConfigurationError, match="expects str, got int"):
            SystemConfig.load(config_file)

    def test_load_section_rejects_bool_for_int(self, valid_config_data, tmp_path):
        """A bool value on an int field raises ConfigurationError."""
        valid_config_data["defaults"]["postgres_port"] = True
        config_file = tmp_path / "config.yml"
        config_file.write_text(yaml.dump(valid_config_data))

        with pytest.raises(ConfigurationError, match="expects int, got bool"):
            SystemConfig.load(config_file)

    def test_load_section_optional_field_accepts_none(self):
        """Optional fields accept None values."""
        config = SystemConfig._load_section(
            {"dir": "/opt", "systemd": "s.service", "caddy": "c.caddy"},
            TemplatesConfig,
            "templates",
        )
        assert config.pgbackrest_stanza is None

    def test_load_section_optional_field_accepts_value(self):
        """Optional fields accept valid values of the inner type."""
        config = SystemConfig._load_section(
            {
                "dir": "/opt",
                "systemd": "s.service",
                "caddy": "c.caddy",
                "pgbackrest_stanza": "pgbackrest/stanza.conf",
            },
            TemplatesConfig,
            "templates",
        )
        assert config.pgbackrest_stanza == "pgbackrest/stanza.conf"

    def test_load_section_full_valid_config_backward_compatible(
        self, valid_config_data, tmp_path
    ):
        """A fully valid existing config produces identical SystemConfig object."""
        valid_config_data["backups"] = {
            "storage_box": {
                "host": "u123.storagebox.de",
                "user": "u123",
                "fingerprint": "SHA256:xxxx",
                "port": 23,
            },
            "retention": {"full_backups": 2, "diff_backups": 7},
            "alerts": {
                "email": "alerts@test.com",
                "smtp_port": 587,
                "smtp_use_tls": True,
            },
        }
        valid_config_data["paths"] = {
            "port_range_min": 5433,
            "port_range_max": 5532,
        }
        config_file = tmp_path / "config.yml"
        config_file.write_text(yaml.dump(valid_config_data))

        config = SystemConfig.load(config_file)
        assert config.agency.name == "testco"
        assert config.backups.storage_box.port == 23
        assert config.backups.alerts.smtp_port == 587
        assert config.backups.alerts.smtp_use_tls is True
        assert config.paths.port_range_min == 5433
