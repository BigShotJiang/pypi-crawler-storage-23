"""Tests for per-site backup stanza pre-check (HARDEN-03)."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest
from sum.commands.backup import _check_backup_configured
from sum.exceptions import SetupError
from sum.system_config import reset_system_config


@pytest.fixture(autouse=True)
def reset_config():
    reset_system_config()
    yield
    reset_system_config()


@pytest.fixture
def mock_config(tmp_path):
    """Create a mock SystemConfig with backups configured."""
    config = MagicMock()
    config.backups = MagicMock()
    config.get_pgbackrest_config_dir.return_value = tmp_path
    return config


class TestBackupStanzaPreCheck:
    """HARDEN-03: _check_backup_configured validates per-site stanza file."""

    def test_backup_fails_without_stanza_file(self, mock_config, tmp_path):
        """Global config exists but per-site stanza file is missing."""
        with pytest.raises(SetupError, match="No pgBackRest stanza configured"):
            _check_backup_configured(mock_config, "acme")

    def test_backup_passes_with_stanza_file(self, mock_config, tmp_path):
        """Both global config and per-site stanza file present."""
        stanza_file = tmp_path / "acme.conf"
        stanza_file.write_text("[acme]\n")

        # Should not raise
        _check_backup_configured(mock_config, "acme")

    def test_backup_error_message_includes_path(self, mock_config, tmp_path):
        """Error message includes the expected stanza file path."""
        expected_path = tmp_path / "acme.conf"

        with pytest.raises(SetupError, match=str(expected_path)):
            _check_backup_configured(mock_config, "acme")

    def test_backup_fails_without_global_config(self):
        """Backups not configured at all still fails with global error."""
        config = MagicMock()
        config.backups = None

        with pytest.raises(SetupError, match="Backups not configured"):
            _check_backup_configured(config, "acme")
