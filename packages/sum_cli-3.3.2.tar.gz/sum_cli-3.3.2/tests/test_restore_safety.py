"""Regression tests for restore command safety (DATA-01, H-06)."""

from __future__ import annotations

from importlib import import_module
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from sum.exceptions import SetupError
from sum.setup.bare_metal_postgres import DEFAULT_PGBACKREST_WRAPPER, PGBACKREST_BINARY
from sum.system_config import reset_system_config

restore_module = import_module("sum.commands.restore")


@pytest.fixture(autouse=True)
def reset_config():
    reset_system_config()
    yield
    reset_system_config()


class TestPreRestoreProtection:
    """DATA-01: Protect pre-restore backup from destruction on retry."""

    def test_refuses_delete_when_main_data_missing(self, tmp_path):
        """If .pre-restore exists but main data doesn't, refuse to delete backup."""
        config = MagicMock()
        site_slug = "testsite"
        data_dir = tmp_path / site_slug
        backup_dir = tmp_path / f"{site_slug}.pre-restore"
        backup_dir.mkdir()
        # data_dir does NOT exist

        with patch.object(restore_module, "_get_data_dir", return_value=data_dir):
            with pytest.raises(SetupError, match="Pre-restore backup exists"):
                restore_module._backup_current_data(site_slug, config)

    def test_allows_delete_with_force_flag(self, tmp_path):
        """With --force, allows deleting pre-restore backup even without main data."""
        config = MagicMock()
        site_slug = "testsite"
        data_dir = tmp_path / site_slug
        backup_dir = tmp_path / f"{site_slug}.pre-restore"
        backup_dir.mkdir()
        # data_dir does NOT exist

        with (
            patch.object(restore_module, "_get_data_dir", return_value=data_dir),
            patch("subprocess.run") as mock_run,
        ):
            result = restore_module._backup_current_data(site_slug, config, force=True)
            assert result is None  # No data to back up
            assert not backup_dir.exists()  # Old backup was removed

            # Verify that the force flag allowed cleanup without data
            # chown command was called on the backup_dir before deletion
            assert mock_run.call_count >= 1
            chown_calls = [
                c for c in mock_run.call_args_list if "chown" in str(c[0][0])
            ]
            assert len(chown_calls) >= 1

    def test_safe_when_both_exist(self, tmp_path):
        """When both data and pre-restore exist, safe to remove old backup."""
        config = MagicMock()
        site_slug = "testsite"
        data_dir = tmp_path / site_slug
        data_dir.mkdir()
        (data_dir / "dummy").write_text("data")
        backup_dir = tmp_path / f"{site_slug}.pre-restore"
        backup_dir.mkdir()

        with (
            patch.object(restore_module, "_get_data_dir", return_value=data_dir),
            patch("subprocess.run"),
        ):
            result = restore_module._backup_current_data(site_slug, config)
            assert result == backup_dir
            # Data was moved to backup_dir, then an empty data_dir was recreated
            assert backup_dir.exists()  # Now contains the data
            assert (backup_dir / "dummy").exists()  # Moved file present


class TestRestoreSlugValidation:
    """SEC-03: validate_site_slug() is called in run_restore()."""

    def test_rejects_invalid_slug(self, capsys):
        result = restore_module.run_restore("../bad", use_latest=True)
        assert result == 1
        captured = capsys.readouterr()
        assert "Invalid site slug" in captured.out


class TestRestoreErrorMessages:
    """HARDEN-06: Error messages accurately reflect what happened during failure."""

    @patch("sum.commands.restore.require_root_or_escalate")
    @patch("sum.commands.restore._run_pgbackrest_info", return_value="backup info")
    @patch("sum.commands.restore._check_disk_space")
    @patch("sum.commands.restore._check_backup_configured")
    @patch("sum.commands.restore.get_site_port", return_value=5433)
    @patch("sum.commands.restore.get_system_config")
    def test_restore_error_with_successful_rollback(
        self,
        mock_config,
        mock_port,
        mock_backup_cfg,
        mock_disk,
        mock_info,
        mock_root,
        tmp_path,
        capsys,
    ):
        """When restore fails and rollback succeeds, message says 'original data'."""
        mock_config.return_value = MagicMock()
        backup_dir = tmp_path / "testsite.pre-restore"
        backup_dir.mkdir()

        def fake_restore_backup(*args, **kwargs):
            """Simulate successful rollback by removing backup_dir (moved to data_dir)."""
            backup_dir.rmdir()

        with (
            patch.object(restore_module, "_stop_cluster"),
            patch.object(
                restore_module,
                "_backup_current_data",
                return_value=backup_dir,
            ),
            patch.object(
                restore_module,
                "_run_pgbackrest_restore",
                side_effect=SetupError("pgBackRest restore failed"),
            ),
            patch.object(
                restore_module,
                "_restore_backup_data",
                side_effect=fake_restore_backup,
            ),
            patch.object(restore_module, "_start_cluster"),
        ):
            result = restore_module.run_restore(
                "testsite", use_latest=True, skip_confirm=True
            )

        assert result == 1
        captured = capsys.readouterr()
        assert "pgBackRest restore failed" in captured.out
        assert "Cluster restarted with original data" in captured.out

    @patch("sum.commands.restore.require_root_or_escalate")
    @patch("sum.commands.restore._run_pgbackrest_info", return_value="backup info")
    @patch("sum.commands.restore._check_disk_space")
    @patch("sum.commands.restore._check_backup_configured")
    @patch("sum.commands.restore.get_site_port", return_value=5433)
    @patch("sum.commands.restore.get_system_config")
    def test_restore_error_without_rollback(
        self,
        mock_config,
        mock_port,
        mock_backup_cfg,
        mock_disk,
        mock_info,
        mock_root,
        capsys,
    ):
        """When restore fails with no backup dir, no misleading 'restored' message."""
        mock_config.return_value = MagicMock()

        with (
            patch.object(restore_module, "_stop_cluster"),
            patch.object(
                restore_module,
                "_backup_current_data",
                return_value=None,  # No backup dir (data didn't exist)
            ),
            patch.object(
                restore_module,
                "_run_pgbackrest_restore",
                side_effect=SetupError("pgBackRest restore failed"),
            ),
            patch.object(restore_module, "_start_cluster"),
        ):
            result = restore_module.run_restore(
                "testsite", use_latest=True, skip_confirm=True
            )

        assert result == 1
        captured = capsys.readouterr()
        assert "pgBackRest restore failed" in captured.out
        assert "no rollback performed" in captured.out
        assert "original data" not in captured.out

    @patch("sum.commands.restore.require_root_or_escalate")
    @patch("sum.commands.restore._run_pgbackrest_info", return_value="backup info")
    @patch("sum.commands.restore._check_disk_space")
    @patch("sum.commands.restore._check_backup_configured")
    @patch("sum.commands.restore.get_site_port", return_value=5433)
    @patch("sum.commands.restore.get_system_config")
    def test_restore_error_rollback_failed_restart_succeeds(
        self,
        mock_config,
        mock_port,
        mock_backup_cfg,
        mock_disk,
        mock_info,
        mock_root,
        tmp_path,
        capsys,
    ):
        """When restore fails and rollback fails but restart succeeds, warn operator."""
        mock_config.return_value = MagicMock()
        backup_dir = tmp_path / "testsite.pre-restore"
        backup_dir.mkdir()

        # _restore_backup_data does NOT remove backup_dir (simulates failed move)
        with (
            patch.object(restore_module, "_stop_cluster"),
            patch.object(
                restore_module,
                "_backup_current_data",
                return_value=backup_dir,
            ),
            patch.object(
                restore_module,
                "_run_pgbackrest_restore",
                side_effect=SetupError("pgBackRest restore failed"),
            ),
            patch.object(restore_module, "_restore_backup_data"),
            patch.object(restore_module, "_start_cluster"),
        ):
            result = restore_module.run_restore(
                "testsite", use_latest=True, skip_confirm=True
            )

        assert result == 1
        captured = capsys.readouterr()
        assert "pgBackRest restore failed" in captured.out
        # Must NOT say "original data" — rollback failed
        assert "original data" not in captured.out
        assert "rollback failed" in captured.out

    @patch("sum.commands.restore.require_root_or_escalate")
    @patch("sum.commands.restore._run_pgbackrest_info", return_value="backup info")
    @patch("sum.commands.restore._check_disk_space")
    @patch("sum.commands.restore._check_backup_configured")
    @patch("sum.commands.restore.get_site_port", return_value=5433)
    @patch("sum.commands.restore.get_system_config")
    def test_restore_error_rollback_and_restart_failure(
        self,
        mock_config,
        mock_port,
        mock_backup_cfg,
        mock_disk,
        mock_info,
        mock_root,
        tmp_path,
        capsys,
    ):
        """When restore fails, rollback succeeds, and restart fails, all reported."""
        mock_config.return_value = MagicMock()
        backup_dir = tmp_path / "testsite.pre-restore"
        backup_dir.mkdir()

        def fake_restore_backup(*args, **kwargs):
            """Simulate successful rollback by removing backup_dir."""
            backup_dir.rmdir()

        with (
            patch.object(restore_module, "_stop_cluster"),
            patch.object(
                restore_module,
                "_backup_current_data",
                return_value=backup_dir,
            ),
            patch.object(
                restore_module,
                "_run_pgbackrest_restore",
                side_effect=SetupError("pgBackRest restore failed"),
            ),
            patch.object(
                restore_module,
                "_restore_backup_data",
                side_effect=fake_restore_backup,
            ),
            patch.object(
                restore_module,
                "_start_cluster",
                side_effect=SetupError("cluster start failed"),
            ),
            patch.object(
                restore_module,
                "_get_data_dir",
                return_value=tmp_path / "testsite",
            ),
        ):
            result = restore_module.run_restore(
                "testsite", use_latest=True, skip_confirm=True
            )

        assert result == 1
        captured = capsys.readouterr()
        assert "pgBackRest restore failed" in captured.out
        assert "Failed to restart cluster" in captured.out
        assert "original data restored" in captured.out
        assert "cluster start failed" in captured.out


class TestPitrClusterStartFailure:
    """Regression: PITR restore succeeds but cluster start fails — must rollback."""

    @patch("sum.commands.restore.require_root_or_escalate")
    @patch("sum.commands.restore._run_pgbackrest_info", return_value="backup info")
    @patch("sum.commands.restore._check_disk_space")
    @patch("sum.commands.restore._check_backup_configured")
    @patch("sum.commands.restore.get_site_port", return_value=5433)
    @patch("sum.commands.restore.get_system_config")
    def test_rollback_when_cluster_start_fails_after_restore(
        self,
        mock_config,
        mock_port,
        mock_backup_cfg,
        mock_disk,
        mock_info,
        mock_root,
        tmp_path,
        capsys,
    ):
        """When pgBackRest restore succeeds but cluster start fails, rollback occurs."""
        mock_config.return_value = MagicMock()
        backup_dir = tmp_path / "testsite.pre-restore"
        backup_dir.mkdir()

        restore_backup_called = False

        def fake_restore_backup(*args, **kwargs):
            nonlocal restore_backup_called
            restore_backup_called = True
            backup_dir.rmdir()

        with (
            patch.object(restore_module, "_stop_cluster"),
            patch.object(
                restore_module,
                "_backup_current_data",
                return_value=backup_dir,
            ),
            patch.object(
                restore_module,
                "_run_pgbackrest_restore",
                # Restore succeeds (no exception)
            ),
            patch.object(
                restore_module,
                "_start_cluster",
                side_effect=SetupError("recovery ended before configured target"),
            ),
            patch.object(
                restore_module,
                "_restore_backup_data",
                side_effect=fake_restore_backup,
            ),
            patch.object(
                restore_module,
                "_get_data_dir",
                return_value=tmp_path / "testsite",
            ),
            patch.object(
                restore_module,
                "_get_postgres_version",
                return_value="16",
            ),
        ):
            result = restore_module.run_restore(
                "testsite", use_latest=True, skip_confirm=True
            )

        assert result == 1
        assert (
            restore_backup_called
        ), "Rollback must be attempted when cluster start fails"
        captured = capsys.readouterr()
        assert "recovery ended before configured target" in captured.out

    @patch("sum.commands.restore.require_root_or_escalate")
    @patch("sum.commands.restore._run_pgbackrest_info", return_value="backup info")
    @patch("sum.commands.restore._check_disk_space")
    @patch("sum.commands.restore._check_backup_configured")
    @patch("sum.commands.restore.get_site_port", return_value=5433)
    @patch("sum.commands.restore.get_system_config")
    def test_rollback_succeeds_cluster_restarts_with_original_data(
        self,
        mock_config,
        mock_port,
        mock_backup_cfg,
        mock_disk,
        mock_info,
        mock_root,
        tmp_path,
        capsys,
    ):
        """After rollback from failed PITR start, cluster restarts with original data."""
        mock_config.return_value = MagicMock()
        backup_dir = tmp_path / "testsite.pre-restore"
        backup_dir.mkdir()

        start_call_count = 0

        def fake_restore_backup(*args, **kwargs):
            backup_dir.rmdir()

        def fake_start_cluster(*args, **kwargs):
            nonlocal start_call_count
            start_call_count += 1
            if start_call_count == 1:
                # First start (with PITR data) fails
                raise SetupError("recovery ended before configured target")
            # Second start (after rollback with original data) succeeds

        with (
            patch.object(restore_module, "_stop_cluster"),
            patch.object(
                restore_module,
                "_backup_current_data",
                return_value=backup_dir,
            ),
            patch.object(restore_module, "_run_pgbackrest_restore"),
            patch.object(
                restore_module,
                "_start_cluster",
                side_effect=fake_start_cluster,
            ),
            patch.object(
                restore_module,
                "_restore_backup_data",
                side_effect=fake_restore_backup,
            ),
        ):
            result = restore_module.run_restore(
                "testsite", use_latest=True, skip_confirm=True
            )

        assert result == 1
        captured = capsys.readouterr()
        assert "Cluster restarted with original data" in captured.out


class TestRestoreBackupVerification:
    """H-06: Verify backup exists before stopping cluster for restore."""

    @patch("sum.commands.restore.require_root_or_escalate")
    @patch("sum.commands.restore._run_pgbackrest_info")
    @patch("sum.commands.restore._check_disk_space")
    @patch("sum.commands.restore._check_backup_configured")
    @patch("sum.commands.restore.get_site_port", return_value=5433)
    @patch("sum.commands.restore.get_system_config")
    def test_restore_fails_when_no_backups(
        self,
        mock_config,
        mock_port,
        mock_backup_cfg,
        mock_disk,
        mock_info,
        mock_root,
        capsys,
    ):
        """Restore returns error when no backups are available."""
        mock_config.return_value = MagicMock()
        mock_info.return_value = ""  # Empty output = no backups

        result = restore_module.run_restore("acme", use_latest=True, skip_confirm=True)
        assert result == 1
        captured = capsys.readouterr()
        assert "No backups available" in captured.out


class TestPatchRestoreCommand:
    """Verify _patch_restore_command rewrites pgbackrest -> wrapper."""

    def test_patches_bare_pgbackrest(self, tmp_path: Path) -> None:
        """Replaces bare 'pgbackrest' in restore_command with wrapper path."""
        auto_conf = tmp_path / "postgresql.auto.conf"
        auto_conf.write_text(
            "# Recovery settings generated by pgBackRest restore\n"
            "restore_command = 'pgbackrest --stanza=acme archive-get %f \"%p\"'\n"
        )
        config = MagicMock()
        with patch.object(restore_module, "_get_data_dir", return_value=tmp_path):
            restore_module._patch_restore_command("acme", config)

        content = auto_conf.read_text()
        assert DEFAULT_PGBACKREST_WRAPPER in content
        assert "restore_command = 'pgbackrest " not in content

    def test_patches_absolute_pgbackrest(self, tmp_path: Path) -> None:
        """Replaces absolute path /usr/bin/pgbackrest with wrapper path."""
        auto_conf = tmp_path / "postgresql.auto.conf"
        auto_conf.write_text(
            "# Recovery settings generated by pgBackRest restore\n"
            f"restore_command = '{PGBACKREST_BINARY} --stanza=acme archive-get %f \"%p\"'\n"
        )
        config = MagicMock()
        with patch.object(restore_module, "_get_data_dir", return_value=tmp_path):
            restore_module._patch_restore_command("acme", config)

        content = auto_conf.read_text()
        assert DEFAULT_PGBACKREST_WRAPPER in content
        assert PGBACKREST_BINARY not in content

    def test_preserves_other_settings(self, tmp_path: Path) -> None:
        """Does not modify unrelated settings in postgresql.auto.conf."""
        auto_conf = tmp_path / "postgresql.auto.conf"
        auto_conf.write_text(
            "# Do not edit this file manually!\n"
            "primary_conninfo = 'host=10.0.0.1 port=5432'\n"
            "restore_command = 'pgbackrest --stanza=acme archive-get %f \"%p\"'\n"
            "recovery_target_time = '2024-01-15 14:30:00'\n"
        )
        config = MagicMock()
        with patch.object(restore_module, "_get_data_dir", return_value=tmp_path):
            restore_module._patch_restore_command("acme", config)

        content = auto_conf.read_text()
        assert "primary_conninfo = 'host=10.0.0.1 port=5432'" in content
        assert "recovery_target_time = '2024-01-15 14:30:00'" in content

    def test_noop_when_no_auto_conf(self, tmp_path: Path) -> None:
        """Does nothing when postgresql.auto.conf doesn't exist."""
        config = MagicMock()
        with patch.object(restore_module, "_get_data_dir", return_value=tmp_path):
            # Should not raise
            restore_module._patch_restore_command("acme", config)

    def test_noop_when_already_using_wrapper(self, tmp_path: Path) -> None:
        """Does nothing when restore_command already uses the wrapper."""
        auto_conf = tmp_path / "postgresql.auto.conf"
        original = (
            "restore_command = "
            f"'{DEFAULT_PGBACKREST_WRAPPER} --stanza=acme archive-get %f \"%p\"'\n"
        )
        auto_conf.write_text(original)
        config = MagicMock()
        with patch.object(restore_module, "_get_data_dir", return_value=tmp_path):
            restore_module._patch_restore_command("acme", config)

        assert auto_conf.read_text() == original

    def test_noop_when_no_restore_command(self, tmp_path: Path) -> None:
        """Does nothing when postgresql.auto.conf has no restore_command."""
        auto_conf = tmp_path / "postgresql.auto.conf"
        original = "# Do not edit this file manually!\nprimary_conninfo = 'foo'\n"
        auto_conf.write_text(original)
        config = MagicMock()
        with patch.object(restore_module, "_get_data_dir", return_value=tmp_path):
            restore_module._patch_restore_command("acme", config)

        assert auto_conf.read_text() == original
