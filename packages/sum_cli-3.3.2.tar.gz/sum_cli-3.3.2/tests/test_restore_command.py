"""Tests for restore command."""

from __future__ import annotations

from importlib import import_module
from unittest.mock import patch

import pytest
from sum.system_config import ConfigurationError, reset_system_config

restore_module = import_module("sum.commands.restore")


@pytest.fixture(autouse=True)
def reset_config():
    """Reset config singleton before and after each test."""
    reset_system_config()
    yield
    reset_system_config()


class TestValidateTimeFormat:
    """Tests for time format validation."""

    def test_valid_format(self):
        """Accepts valid YYYY-MM-DD HH:MM:SS format."""
        assert restore_module._validate_time_format("2024-01-15 14:30:00")
        assert restore_module._validate_time_format("2024-12-31 23:59:59")
        assert restore_module._validate_time_format("2024-01-01 00:00:00")

    def test_invalid_formats(self):
        """Rejects invalid formats."""
        assert not restore_module._validate_time_format("2024-01-15")
        assert not restore_module._validate_time_format("14:30:00")
        assert not restore_module._validate_time_format("2024-01-15T14:30:00")
        assert not restore_module._validate_time_format("2024/01/15 14:30:00")
        assert not restore_module._validate_time_format("Jan 15 2024 14:30:00")
        assert not restore_module._validate_time_format("")
        assert not restore_module._validate_time_format("invalid")

    def test_invalid_date_boundary_cases(self):
        """Rejects invalid dates and times."""
        # Invalid date (Feb 30th)
        assert not restore_module._validate_time_format("2024-02-30 00:00:00")

        # Invalid hour (25)
        assert not restore_module._validate_time_format("2024-01-01 25:00:00")

        # Invalid minute (60)
        assert not restore_module._validate_time_format("2024-01-01 00:60:00")

        # Invalid second (60)
        assert not restore_module._validate_time_format("2024-01-01 00:00:60")

        # Invalid month (13)
        assert not restore_module._validate_time_format("2024-13-01 00:00:00")

        # Invalid day (32)
        assert not restore_module._validate_time_format("2024-01-32 00:00:00")


class TestRestoreConfigError:
    """Tests for restore command handling of missing configuration."""

    def test_restore_fails_when_config_missing(self, monkeypatch, capsys):
        """restore returns exit code 1 when configuration file is missing."""

        def raise_config_error():
            raise ConfigurationError(
                "Configuration file not found: /etc/sum/config.yml"
            )

        monkeypatch.setattr(restore_module, "get_system_config", raise_config_error)
        monkeypatch.setattr(restore_module, "require_root_or_escalate", lambda _: True)

        result = restore_module.run_restore("testsite", use_latest=True)

        assert result == 1
        captured = capsys.readouterr()
        assert "Configuration file not found" in captured.out


class TestRestoreOptionValidation:
    """Tests for restore command option validation."""

    @pytest.fixture(autouse=True)
    def _mock_root(self, monkeypatch):
        monkeypatch.setattr(restore_module, "require_root_or_escalate", lambda _: True)
        monkeypatch.setattr(
            restore_module, "_check_backup_configured", lambda config, slug: None
        )

    def test_fails_with_both_time_and_latest(self, monkeypatch, capsys):
        """Fails when both --time and --latest specified."""
        from sum.system_config import (
            AgencyConfig,
            AlertsConfig,
            BackupsConfig,
            DefaultsConfig,
            ProductionConfig,
            RetentionConfig,
            StagingConfig,
            StorageBoxConfig,
            SystemConfig,
            TemplatesConfig,
        )

        config = SystemConfig(
            agency=AgencyConfig(name="testco"),
            staging=StagingConfig(
                server="staging",
                domain_pattern="{slug}.staging.test",
                base_dir="/tmp/test",
            ),
            production=ProductionConfig(
                server="prod",
                ssh_host="10.0.0.1",
                base_dir="/srv/prod",
            ),
            templates=TemplatesConfig(
                dir="/opt/infra",
                systemd="systemd/test.service",
                caddy="caddy/test.caddy",
            ),
            defaults=DefaultsConfig(
                theme="theme_a",
                deploy_user="deploy",
                seed_profile="sage-stone",
            ),
            backups=BackupsConfig(
                storage_box=StorageBoxConfig(
                    host="backup.example.com", user="u12345", fingerprint="abc123"
                ),
                retention=RetentionConfig(),
                alerts=AlertsConfig(email="alerts@example.com"),
            ),
        )

        monkeypatch.setattr(restore_module, "get_system_config", lambda: config)

        # Mock get_site_port to return a port (site uses managed PostgreSQL)
        with patch("sum.commands.restore.get_site_port", return_value=5433):
            result = restore_module.run_restore(
                "testsite",
                target_time="2024-01-15 14:30:00",
                use_latest=True,
            )

        assert result == 1
        captured = capsys.readouterr()
        assert "Cannot specify both" in captured.out

    def test_fails_with_neither_time_nor_latest(self, monkeypatch, capsys):
        """Fails when neither --time nor --latest specified."""
        from sum.system_config import (
            AgencyConfig,
            AlertsConfig,
            BackupsConfig,
            DefaultsConfig,
            ProductionConfig,
            RetentionConfig,
            StagingConfig,
            StorageBoxConfig,
            SystemConfig,
            TemplatesConfig,
        )

        config = SystemConfig(
            agency=AgencyConfig(name="testco"),
            staging=StagingConfig(
                server="staging",
                domain_pattern="{slug}.staging.test",
                base_dir="/tmp/test",
            ),
            production=ProductionConfig(
                server="prod",
                ssh_host="10.0.0.1",
                base_dir="/srv/prod",
            ),
            templates=TemplatesConfig(
                dir="/opt/infra",
                systemd="systemd/test.service",
                caddy="caddy/test.caddy",
            ),
            defaults=DefaultsConfig(
                theme="theme_a",
                deploy_user="deploy",
                seed_profile="sage-stone",
            ),
            backups=BackupsConfig(
                storage_box=StorageBoxConfig(
                    host="backup.example.com", user="u12345", fingerprint="abc123"
                ),
                retention=RetentionConfig(),
                alerts=AlertsConfig(email="alerts@example.com"),
            ),
        )

        monkeypatch.setattr(restore_module, "get_system_config", lambda: config)

        with patch("sum.commands.restore.get_site_port", return_value=5433):
            result = restore_module.run_restore("testsite")

        assert result == 1
        captured = capsys.readouterr()
        assert "Must specify either" in captured.out

    def test_fails_with_invalid_time_format(self, monkeypatch, capsys):
        """Fails with helpful message for invalid time format."""
        from sum.system_config import (
            AgencyConfig,
            AlertsConfig,
            BackupsConfig,
            DefaultsConfig,
            ProductionConfig,
            RetentionConfig,
            StagingConfig,
            StorageBoxConfig,
            SystemConfig,
            TemplatesConfig,
        )

        config = SystemConfig(
            agency=AgencyConfig(name="testco"),
            staging=StagingConfig(
                server="staging",
                domain_pattern="{slug}.staging.test",
                base_dir="/tmp/test",
            ),
            production=ProductionConfig(
                server="prod",
                ssh_host="10.0.0.1",
                base_dir="/srv/prod",
            ),
            templates=TemplatesConfig(
                dir="/opt/infra",
                systemd="systemd/test.service",
                caddy="caddy/test.caddy",
            ),
            defaults=DefaultsConfig(
                theme="theme_a",
                deploy_user="deploy",
                seed_profile="sage-stone",
            ),
            backups=BackupsConfig(
                storage_box=StorageBoxConfig(
                    host="backup.example.com", user="u12345", fingerprint="abc123"
                ),
                retention=RetentionConfig(),
                alerts=AlertsConfig(email="alerts@example.com"),
            ),
        )

        monkeypatch.setattr(restore_module, "get_system_config", lambda: config)

        with patch("sum.commands.restore.get_site_port", return_value=5433):
            result = restore_module.run_restore(
                "testsite",
                target_time="invalid-time",
            )

        assert result == 1
        captured = capsys.readouterr()
        assert "Invalid time format" in captured.out
        assert "YYYY-MM-DD HH:MM:SS" in captured.out


class TestRestoreNonManagedPostgres:
    """Tests for restore command with non-managed PostgreSQL sites."""

    @pytest.fixture(autouse=True)
    def _mock_root(self, monkeypatch):
        monkeypatch.setattr(restore_module, "require_root_or_escalate", lambda _: True)

    def test_fails_for_non_managed_site(self, monkeypatch, capsys):
        """Fails gracefully for sites without managed PostgreSQL."""
        from sum.system_config import (
            AgencyConfig,
            DefaultsConfig,
            ProductionConfig,
            StagingConfig,
            SystemConfig,
            TemplatesConfig,
        )

        config = SystemConfig(
            agency=AgencyConfig(name="testco"),
            staging=StagingConfig(
                server="staging",
                domain_pattern="{slug}.staging.test",
                base_dir="/tmp/test",
            ),
            production=ProductionConfig(
                server="prod",
                ssh_host="10.0.0.1",
                base_dir="/srv/prod",
            ),
            templates=TemplatesConfig(
                dir="/opt/infra",
                systemd="systemd/test.service",
                caddy="caddy/test.caddy",
            ),
            defaults=DefaultsConfig(
                theme="theme_a",
                deploy_user="deploy",
                seed_profile="sage-stone",
            ),
        )

        monkeypatch.setattr(restore_module, "get_system_config", lambda: config)

        # Mock get_site_port to return None (no managed PostgreSQL)
        with patch("sum.commands.restore.get_site_port", return_value=None):
            result = restore_module.run_restore("testsite", use_latest=True)

        assert result == 1
        captured = capsys.readouterr()
        assert "does not have a PostgreSQL cluster configured" in captured.out


class TestListBackups:
    """Tests for listing available backups."""

    def test_fails_for_non_managed_site(self, monkeypatch, capsys):
        """Fails gracefully for sites without managed PostgreSQL."""
        from sum.system_config import (
            AgencyConfig,
            AlertsConfig,
            BackupsConfig,
            DefaultsConfig,
            ProductionConfig,
            RetentionConfig,
            StagingConfig,
            StorageBoxConfig,
            SystemConfig,
            TemplatesConfig,
        )

        config = SystemConfig(
            agency=AgencyConfig(name="testco"),
            staging=StagingConfig(
                server="staging",
                domain_pattern="{slug}.staging.test",
                base_dir="/tmp/test",
            ),
            production=ProductionConfig(
                server="prod",
                ssh_host="10.0.0.1",
                base_dir="/srv/prod",
            ),
            templates=TemplatesConfig(
                dir="/opt/infra",
                systemd="systemd/test.service",
                caddy="caddy/test.caddy",
            ),
            defaults=DefaultsConfig(
                theme="theme_a",
                deploy_user="deploy",
                seed_profile="sage-stone",
            ),
            backups=BackupsConfig(
                storage_box=StorageBoxConfig(
                    host="backup.example.com", user="u12345", fingerprint="abc123"
                ),
                retention=RetentionConfig(),
                alerts=AlertsConfig(email="alerts@example.com"),
            ),
        )

        monkeypatch.setattr(restore_module, "get_system_config", lambda: config)

        with patch("sum.commands.restore.get_site_port", return_value=None):
            result = restore_module.run_list_backups("testsite")

        assert result == 1
        captured = capsys.readouterr()
        assert "does not have a PostgreSQL cluster configured" in captured.out

    def test_fails_when_config_missing(self, monkeypatch, capsys):
        """Fails when configuration is missing."""

        def raise_config_error():
            raise ConfigurationError("Configuration file not found")

        monkeypatch.setattr(restore_module, "get_system_config", raise_config_error)

        result = restore_module.run_list_backups("testsite")

        assert result == 1
        captured = capsys.readouterr()
        assert "Configuration file not found" in captured.out
