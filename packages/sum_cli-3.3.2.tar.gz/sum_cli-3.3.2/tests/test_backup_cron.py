"""Tests for backup cron schedule management."""

from __future__ import annotations

from unittest.mock import patch

import pytest
from sum.setup.backup_cron import (
    get_staggered_minute,
    install_backup_cron,
    remove_backup_cron,
)


@pytest.fixture
def temp_cron_file(tmp_path):
    """Create a temporary cron file."""
    cron_file = tmp_path / "sum-backups"
    with patch("sum.setup.backup_cron.CRON_FILE", cron_file):
        yield cron_file


class TestGetStaggeredMinute:
    """Tests for the staggered minute calculation."""

    def test_returns_int_between_0_and_59(self):
        """Minute is always in valid cron range."""
        for slug in ["acme", "beta", "gamma", "delta", "test-site-123"]:
            minute = get_staggered_minute(slug)
            assert 0 <= minute <= 59

    def test_same_slug_same_minute(self):
        """Same site slug always gets same minute."""
        assert get_staggered_minute("acme") == get_staggered_minute("acme")

    def test_different_slugs_likely_different(self):
        """Different slugs likely get different minutes."""
        # Not guaranteed but very unlikely to be all the same
        minutes = {get_staggered_minute(f"site{i}") for i in range(10)}
        assert len(minutes) > 1  # At least some variation


class TestInstallBackupCron:
    """Tests for installing backup cron entries."""

    def test_creates_cron_file_if_missing(self, temp_cron_file):
        """Creates cron file if it doesn't exist."""
        assert not temp_cron_file.exists()
        install_backup_cron("acme")
        assert temp_cron_file.exists()

    def test_adds_marker_comment(self, temp_cron_file):
        """Adds site marker comment."""
        install_backup_cron("acme")
        content = temp_cron_file.read_text()
        assert "# acme" in content

    def test_adds_full_backup_entry(self, temp_cron_file):
        """Adds Sunday full backup entry with bash pipefail wrapper."""
        install_backup_cron("acme")
        content = temp_cron_file.read_text()
        assert "--stanza=acme" in content
        assert "--type=full" in content
        assert "* * 0 root bash -o pipefail -c" in content
        assert "/usr/local/bin/pgbackrest-wrapper" in content

    def test_adds_diff_backup_entry(self, temp_cron_file):
        """Adds Mon-Sat differential backup entry with bash pipefail wrapper."""
        install_backup_cron("acme")
        content = temp_cron_file.read_text()
        assert "--stanza=acme" in content
        assert "--type=diff" in content
        assert "* * 1-6 root bash -o pipefail -c" in content
        assert "/usr/local/bin/pgbackrest-wrapper" in content

    def test_idempotent(self, temp_cron_file):
        """Installing twice doesn't duplicate entries."""
        install_backup_cron("acme")
        content1 = temp_cron_file.read_text()
        install_backup_cron("acme")
        content2 = temp_cron_file.read_text()
        assert content1 == content2

    def test_multiple_sites(self, temp_cron_file):
        """Can install entries for multiple sites."""
        install_backup_cron("acme")
        install_backup_cron("beta")
        content = temp_cron_file.read_text()
        assert "# acme" in content
        assert "# beta" in content
        assert "acme" in content
        assert "beta" in content

    def test_uses_site_dir_for_marker_file(self, temp_cron_file):
        """Uses provided site_dir for backup status marker."""
        install_backup_cron("acme", site_dir="/custom/path")
        content = temp_cron_file.read_text()
        assert "/custom/path/backup_status" in content

    def test_updates_marker_on_success(self, temp_cron_file):
        """Cron entry updates marker file on successful backup."""
        install_backup_cron("acme")
        content = temp_cron_file.read_text()
        # % must be escaped as \% in cron.d files
        assert "date +\\%s > " in content
        assert "backup_status" in content

    def test_no_nested_single_quotes_in_bash_c(self, temp_cron_file):
        """Values inside bash -c '...' must not be single-quoted."""
        install_backup_cron("acme")
        content = temp_cron_file.read_text()
        for line in content.splitlines():
            if "bash -o pipefail -c" not in line:
                continue
            # Extract the bash -c body: everything between the opening '
            # after "-c " and the next ' (which closes the body). Using
            # index() (first match) rather than rindex() so that quoted
            # values outside the body (e.g. q_marker) don't confuse the
            # parser.
            after_c = line.split("-c '", 1)[1]
            close_idx = after_c.index("'")
            inner = after_c[:close_idx]
            # Inner body must not contain single quotes (shlex.quote artifact)
            assert (
                "'" not in inner
            ), f"Nested single quote found in bash -c body: {inner!r}"

    def test_rejects_unsafe_config_path(self, temp_cron_file):
        """Config path with shell metacharacters is rejected."""
        from unittest.mock import MagicMock

        config = MagicMock()
        config.get_pgbackrest_config_dir.return_value = (
            "/etc/pgbackrest/conf.d; rm -rf /"
        )
        with pytest.raises(ValueError, match="Invalid config_path"):
            install_backup_cron("acme", config=config)


class TestRemoveBackupCron:
    """Tests for removing backup cron entries."""

    def test_removes_site_entries(self, temp_cron_file):
        """Removes all entries for a site."""
        install_backup_cron("acme")
        install_backup_cron("beta")
        remove_backup_cron("acme")
        content = temp_cron_file.read_text()
        assert "# acme" not in content
        assert "# beta" in content

    def test_removes_file_when_empty(self, temp_cron_file):
        """Removes cron file when last site is removed."""
        install_backup_cron("acme")
        remove_backup_cron("acme")
        assert not temp_cron_file.exists()

    def test_noop_if_file_missing(self, temp_cron_file):
        """No error if cron file doesn't exist."""
        remove_backup_cron("acme")  # Should not raise

    def test_noop_if_site_not_in_file(self, temp_cron_file):
        """No error if site not in cron file."""
        install_backup_cron("acme")
        content_before = temp_cron_file.read_text()
        remove_backup_cron("nonexistent")
        content_after = temp_cron_file.read_text()
        assert content_before == content_after

    def test_cron_removal_with_markers(self, temp_cron_file):
        """Marker-based removal removes entire block between start and end markers."""
        install_backup_cron("acme")
        install_backup_cron("beta")
        content = temp_cron_file.read_text()
        # Verify end markers exist (written by updated install)
        assert "# end acme" in content
        assert "# end beta" in content
        # Remove acme
        remove_backup_cron("acme")
        content = temp_cron_file.read_text()
        assert "# acme" not in content
        assert "# end acme" not in content
        assert "# beta" in content
        assert "# end beta" in content

    def test_cron_removal_without_markers(self, temp_cron_file):
        """Backward-compat: removal works on cron files without end markers."""
        # Manually write a legacy cron file (no end markers)
        legacy_content = (
            "# acme\n"
            "15 2 * * 0 root sudo -u postgres /usr/local/bin/pgbackrest-wrapper --stanza=acme backup --type=full\n"
            "15 2 * * 1-6 root sudo -u postgres /usr/local/bin/pgbackrest-wrapper --stanza=acme backup --type=diff\n"
            "# beta\n"
            "30 2 * * 0 root sudo -u postgres /usr/local/bin/pgbackrest-wrapper --stanza=beta backup --type=full\n"
            "30 2 * * 1-6 root sudo -u postgres /usr/local/bin/pgbackrest-wrapper --stanza=beta backup --type=diff\n"
        )
        temp_cron_file.write_text(legacy_content)
        remove_backup_cron("acme")
        content = temp_cron_file.read_text()
        assert "# acme" not in content
        assert "acme" not in content
        assert "# beta" in content
        assert "beta" in content

    def test_cron_removal_leaves_other_sites(self, temp_cron_file):
        """Removing one site's block does not affect other sites."""
        install_backup_cron("alpha")
        install_backup_cron("beta")
        install_backup_cron("gamma")
        remove_backup_cron("beta")
        content = temp_cron_file.read_text()
        assert "# alpha" in content
        assert "# end alpha" in content
        assert "# beta" not in content
        assert "# end beta" not in content
        assert "# gamma" in content
        assert "# end gamma" in content


class TestInstallBackupCronEndMarkers:
    """Tests for end marker generation in install."""

    def test_cron_install_writes_end_markers(self, temp_cron_file):
        """install_backup_cron writes an end-of-block marker after entries."""
        install_backup_cron("acme")
        content = temp_cron_file.read_text()
        lines = content.splitlines()
        # Find the marker positions
        start_idx = next(i for i, ln in enumerate(lines) if ln.strip() == "# acme")
        end_idx = next(i for i, ln in enumerate(lines) if ln.strip() == "# end acme")
        # End marker must come after start marker
        assert end_idx > start_idx
        # There should be cron entries between start and end
        between = lines[start_idx + 1 : end_idx]
        assert len(between) == 2  # full + diff entries
        for entry in between:
            assert entry.strip().split()[0].isdigit()  # starts with minute
