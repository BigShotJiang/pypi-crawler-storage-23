"""
Name: CLI Theme Init Tests
Path: cli/tests/test_theme_init.py
Purpose: Integration tests for theme initialization

NOTE: Tests for the old scaffold-to-clients init behavior have been removed
as the init command was refactored to create production sites at /srv/sum/
instead of scaffolding to clients/. See #1298.

Theme initialization is now tested via:
- test_init.py (mocked orchestrator tests for the new init command)
- test_scaffold.py (scaffold module tests for theme copying)
"""

from __future__ import annotations

# NOTE: The following tests were removed as they tested the old
# scaffold-to-clients init behavior which was replaced by production
# site creation in #1298:
# - test_init_with_theme_creates_theme_config
# - test_init_copies_theme_to_active_directory
# - test_init_with_invalid_theme_fails
# - test_init_default_theme_is_theme_a
# - test_init_includes_seed_showroom_command
# - test_init_settings_include_canonical_theme_override
# - test_init_fails_fast_when_theme_missing_compiled_css
