"""Tests for command handling of ConfigurationError.

Verifies that each command fails gracefully when configuration is missing,
with helpful error messages telling users what to do.
"""

from __future__ import annotations

from importlib import import_module

import pytest
from sum.system_config import ConfigurationError, reset_system_config

# Import the command modules
init_module = import_module("sum.commands.init")
update_module = import_module("sum.commands.update")
backup_module = import_module("sum.commands.backup")
promote_module = import_module("sum.commands.promote")


class FakeInfrastructureCheck:
    """Fake infrastructure check that passes all prerequisites."""

    has_sudo = True
    has_postgres = True
    has_gh_cli = True
    has_git = True
    has_systemctl = True
    errors: list[str] = []


def fake_check_infrastructure() -> FakeInfrastructureCheck:
    """Return a fake infrastructure check that passes."""
    return FakeInfrastructureCheck()


@pytest.fixture(autouse=True)
def reset_config():
    """Reset config singleton before and after each test."""
    reset_system_config()
    yield
    reset_system_config()


@pytest.fixture(autouse=True)
def mock_privilege_escalation(monkeypatch):
    """Mock privilege escalation to always succeed for tests.

    The privilege escalation module would try to re-exec with sudo,
    which we don't want in tests.
    """
    monkeypatch.setattr(init_module, "require_root_or_escalate", lambda cmd, **kw: True)
    monkeypatch.setattr(
        promote_module, "require_root_or_escalate", lambda cmd, **kw: True
    )


class TestInitConfigError:
    """Tests for init command handling of missing configuration."""

    def test_init_fails_when_config_missing(self, monkeypatch, capsys):
        """init returns exit code 1 when configuration file is missing."""

        def raise_config_error():
            raise ConfigurationError(
                "Configuration file not found: /etc/sum/config.yml\n\n"
                "The SUM CLI requires a configuration file.\n"
                "Create /etc/sum/config.yml with your agency settings.\n\n"
                "See docs/dev/cli/USER_GUIDE.md for the required format."
            )

        # Mock infrastructure check to pass so we reach the config check
        monkeypatch.setattr(
            init_module,
            "check_infrastructure",
            fake_check_infrastructure,
        )
        monkeypatch.setattr(init_module, "get_system_config", raise_config_error)

        result = init_module.run_init("testsite")

        assert result == 1
        captured = capsys.readouterr()
        assert "Configuration file not found" in captured.out
        assert "config.yml" in captured.out
        assert "USER_GUIDE" in captured.out

    def test_init_shows_path_to_missing_config(self, monkeypatch, capsys):
        """init error message includes the expected config path."""

        def raise_config_error():
            raise ConfigurationError(
                "Configuration file not found: /custom/path/config.yml"
            )

        monkeypatch.setattr(
            init_module,
            "check_infrastructure",
            fake_check_infrastructure,
        )
        monkeypatch.setattr(init_module, "get_system_config", raise_config_error)

        result = init_module.run_init("testsite")

        assert result == 1
        captured = capsys.readouterr()
        assert "/custom/path/config.yml" in captured.out


class TestUpdateConfigError:
    """Tests for update command handling of missing configuration."""

    def test_update_fails_when_config_missing(self, monkeypatch, capsys):
        """update returns exit code 1 when configuration file is missing."""

        def raise_config_error():
            raise ConfigurationError(
                "Configuration file not found: /etc/sum/config.yml"
            )

        monkeypatch.setattr(update_module, "get_system_config", raise_config_error)
        monkeypatch.setattr(update_module, "require_root_or_escalate", lambda _: True)

        result = update_module.run_update("testsite")

        assert result == 1
        captured = capsys.readouterr()
        assert "Configuration file not found" in captured.out

    def test_update_shows_config_path_in_error(self, monkeypatch, capsys):
        """update error shows which config file was expected."""

        def raise_config_error():
            raise ConfigurationError("Missing required sections in /etc/sum/config.yml")

        monkeypatch.setattr(update_module, "get_system_config", raise_config_error)
        monkeypatch.setattr(update_module, "require_root_or_escalate", lambda _: True)

        result = update_module.run_update("testsite", target="staging")

        assert result == 1
        captured = capsys.readouterr()
        assert "Missing required sections" in captured.out


class TestBackupConfigError:
    """Tests for backup command handling of missing configuration."""

    def test_backup_fails_when_config_missing(self, monkeypatch, capsys):
        """backup returns exit code 1 when configuration file is missing."""

        def raise_config_error():
            raise ConfigurationError(
                "Configuration file not found: /etc/sum/config.yml"
            )

        monkeypatch.setattr(backup_module, "get_system_config", raise_config_error)
        monkeypatch.setattr(backup_module, "require_root_or_escalate", lambda _: True)

        result = backup_module.run_backup("testsite")

        assert result == 1
        captured = capsys.readouterr()
        assert "Configuration file not found" in captured.out

    def test_backup_shows_invalid_yaml_error(self, monkeypatch, capsys):
        """backup shows YAML parsing errors clearly."""

        def raise_config_error():
            raise ConfigurationError(
                "Invalid YAML in configuration file /etc/sum/config.yml: "
                "expected '<document start>', but found '<scalar>'"
            )

        monkeypatch.setattr(backup_module, "get_system_config", raise_config_error)
        monkeypatch.setattr(backup_module, "require_root_or_escalate", lambda _: True)

        result = backup_module.run_backup("testsite")

        assert result == 1
        captured = capsys.readouterr()
        assert "Invalid YAML" in captured.out


class TestPromoteConfigError:
    """Tests for promote command handling of missing configuration."""

    def test_promote_fails_when_config_missing(self, monkeypatch, capsys):
        """promote returns exit code 1 when configuration file is missing."""

        def raise_config_error():
            raise ConfigurationError(
                "Configuration file not found: /etc/sum/config.yml"
            )

        monkeypatch.setattr(promote_module, "get_system_config", raise_config_error)
        monkeypatch.setattr(
            promote_module, "require_root_or_escalate", lambda *a, **kw: True
        )

        result = promote_module.run_promote(
            "testsite", domain="testsite.example.com", skip_confirm=True
        )

        assert result == 1
        captured = capsys.readouterr()
        assert "Configuration file not found" in captured.out

    def test_promote_shows_missing_section_error(self, monkeypatch, capsys):
        """promote shows which config sections are missing."""

        def raise_config_error():
            raise ConfigurationError(
                "Missing required sections in /etc/sum/config.yml: production, templates"
            )

        monkeypatch.setattr(promote_module, "get_system_config", raise_config_error)
        monkeypatch.setattr(
            promote_module, "require_root_or_escalate", lambda *a, **kw: True
        )

        result = promote_module.run_promote(
            "testsite", domain="testsite.example.com", skip_confirm=True
        )

        assert result == 1
        captured = capsys.readouterr()
        assert "Missing required sections" in captured.out
        assert "production" in captured.out


class TestPromoteSiteConfigErrors:
    """Tests for promote command handling of site-specific configuration errors."""

    def test_promote_fails_when_site_config_missing(
        self, monkeypatch, tmp_path, capsys
    ):
        """promote fails when site config is missing."""
        from sum.system_config import (
            AgencyConfig,
            DefaultsConfig,
            ProductionConfig,
            StagingConfig,
            SystemConfig,
            TemplatesConfig,
        )

        # Create a minimal system config
        config = SystemConfig(
            agency=AgencyConfig(name="testco"),
            staging=StagingConfig(
                server="staging",
                domain_pattern="{slug}.staging.test",
                base_dir=str(tmp_path),
            ),
            production=ProductionConfig(
                server="prod",
                ssh_host="10.0.0.1",
                base_dir="/srv/prod",
            ),
            templates=TemplatesConfig(
                dir="/opt/infra",
                systemd="systemd/test.service",
                caddy="caddy/test.caddy",
            ),
            defaults=DefaultsConfig(
                theme="theme_a",
                deploy_user="deploy",
                seed_profile="sage-stone",
            ),
        )

        monkeypatch.setattr(promote_module, "get_system_config", lambda: config)

        # Create site directory but no .sum/config.yml
        site_dir = tmp_path / "testsite"
        site_dir.mkdir()

        result = promote_module.run_promote("testsite", domain="testsite.example.com")

        assert result == 1
        captured = capsys.readouterr()
        assert "Site config not found" in captured.out

    def test_promote_fails_when_site_has_no_git(self, monkeypatch, tmp_path, capsys):
        """promote fails when site was created with --no-git."""
        import yaml
        from sum.system_config import (
            AgencyConfig,
            DefaultsConfig,
            ProductionConfig,
            StagingConfig,
            SystemConfig,
            TemplatesConfig,
        )

        config = SystemConfig(
            agency=AgencyConfig(name="testco"),
            staging=StagingConfig(
                server="staging",
                domain_pattern="{slug}.staging.test",
                base_dir=str(tmp_path),
            ),
            production=ProductionConfig(
                server="prod",
                ssh_host="10.0.0.1",
                base_dir="/srv/prod",
            ),
            templates=TemplatesConfig(
                dir="/opt/infra",
                systemd="systemd/test.service",
                caddy="caddy/test.caddy",
            ),
            defaults=DefaultsConfig(
                theme="theme_a",
                deploy_user="deploy",
                seed_profile="sage-stone",
            ),
        )

        monkeypatch.setattr(promote_module, "get_system_config", lambda: config)

        # Create site with config but no git
        site_dir = tmp_path / "testsite"
        site_dir.mkdir()
        config_dir = site_dir / ".sum"
        config_dir.mkdir()
        config_path = config_dir / "config.yml"

        site_config_data = {
            "site": {
                "slug": "testsite",
                "theme": "theme_a",
                "created": "2026-01-15T10:30:00",
            },
            "git": None,  # No git - created with --no-git
        }
        with open(config_path, "w") as f:
            yaml.dump(site_config_data, f)

        result = promote_module.run_promote("testsite", domain="testsite.example.com")

        assert result == 1
        captured = capsys.readouterr()
        assert "created with --no-git" in captured.out
        assert "Cannot promote" in captured.out


class TestAllCommandsConsistentBehavior:
    """Tests that all commands handle config errors consistently."""

    @pytest.mark.parametrize(
        "module,run_func,extra_kwargs",
        [
            (init_module, "run_init", {}),
            (update_module, "run_update", {}),
            (backup_module, "run_backup", {}),
            (promote_module, "run_promote", {"domain": "testsite.example.com"}),
        ],
    )
    def test_all_commands_return_nonzero_on_config_error(
        self, module, run_func, extra_kwargs, monkeypatch, capsys
    ):
        """All commands return non-zero exit code on config error."""

        def raise_config_error():
            raise ConfigurationError("Test configuration error")

        monkeypatch.setattr(module, "get_system_config", raise_config_error)

        # For init, we also need to mock infrastructure check
        if module is init_module:
            monkeypatch.setattr(
                module,
                "check_infrastructure",
                fake_check_infrastructure,
            )

        # update and backup require root before config
        if module in (update_module, backup_module):
            monkeypatch.setattr(module, "require_root_or_escalate", lambda _: True)

        run_fn = getattr(module, run_func)
        result = run_fn("testsite", **extra_kwargs)

        assert result != 0, f"{run_func} should return non-zero on config error"
        captured = capsys.readouterr()
        assert "Test configuration error" in captured.out

    @pytest.mark.parametrize(
        "module,run_func,extra_kwargs",
        [
            (init_module, "run_init", {}),
            (update_module, "run_update", {}),
            (backup_module, "run_backup", {}),
            (promote_module, "run_promote", {"domain": "testsite.example.com"}),
        ],
    )
    def test_all_commands_show_error_not_traceback(
        self, module, run_func, extra_kwargs, monkeypatch, capsys
    ):
        """Commands show user-friendly errors, not Python tracebacks."""

        def raise_config_error():
            raise ConfigurationError("User-friendly error message")

        monkeypatch.setattr(module, "get_system_config", raise_config_error)

        if module is init_module:
            monkeypatch.setattr(
                module,
                "check_infrastructure",
                fake_check_infrastructure,
            )

        if module in (update_module, backup_module):
            monkeypatch.setattr(module, "require_root_or_escalate", lambda _: True)

        run_fn = getattr(module, run_func)
        run_fn("testsite", **extra_kwargs)

        captured = capsys.readouterr()
        # Should not show Python internals
        assert "Traceback" not in captured.out
        assert "Traceback" not in captured.err
        # Should show the actual error message
        assert "User-friendly error message" in captured.out
