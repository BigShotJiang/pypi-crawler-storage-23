"""Tests for site configuration module."""

from __future__ import annotations

from datetime import datetime

import pytest
import yaml
from sum.site_config import GitConfig, SiteConfig, SiteConfigError


class TestGitConfig:
    """Tests for GitConfig dataclass."""

    def test_requires_provider_and_org(self):
        with pytest.raises(TypeError):
            GitConfig()

    def test_github_minimal(self):
        config = GitConfig(provider="github", org="acme-corp")
        assert config.provider == "github"
        assert config.org == "acme-corp"
        assert config.url is None
        assert config.ssh_port == 22
        assert config.token_env == "GITEA_TOKEN"

    def test_gitea_with_all_fields(self):
        config = GitConfig(
            provider="gitea",
            org="clients",
            url="https://gitea.example.com",
            ssh_port=2222,
            token_env="MY_GITEA_TOKEN",
        )
        assert config.provider == "gitea"
        assert config.org == "clients"
        assert config.url == "https://gitea.example.com"
        assert config.ssh_port == 2222
        assert config.token_env == "MY_GITEA_TOKEN"


class TestSiteConfig:
    """Tests for SiteConfig dataclass."""

    def test_requires_all_fields(self):
        with pytest.raises(TypeError):
            SiteConfig()

    def test_with_git_config(self):
        git = GitConfig(provider="github", org="acme")
        now = datetime.now()
        config = SiteConfig(slug="mysite", theme="theme_a", created=now, git=git)

        assert config.slug == "mysite"
        assert config.theme == "theme_a"
        assert config.created == now
        assert config.git is not None
        assert config.git.provider == "github"

    def test_without_git_config(self):
        now = datetime.now()
        config = SiteConfig(slug="mysite", theme="theme_a", created=now, git=None)

        assert config.slug == "mysite"
        assert config.git is None


class TestSiteConfigSave:
    """Tests for SiteConfig.save() method."""

    def test_save_creates_sum_directory(self, tmp_path):
        git = GitConfig(provider="github", org="acme")
        config = SiteConfig(
            slug="testsite",
            theme="theme_a",
            created=datetime(2026, 1, 15, 10, 30, 0),
            git=git,
        )

        config.save(tmp_path)

        config_dir = tmp_path / ".sum"
        assert config_dir.exists()
        assert (config_dir / "config.yml").exists()

    def test_save_github_config(self, tmp_path):
        git = GitConfig(provider="github", org="acme-corp")
        config = SiteConfig(
            slug="testsite",
            theme="theme_a",
            created=datetime(2026, 1, 15, 10, 30, 0),
            git=git,
        )

        config.save(tmp_path)

        config_path = tmp_path / ".sum" / "config.yml"
        with open(config_path) as f:
            data = yaml.safe_load(f)

        assert data["site"]["slug"] == "testsite"
        assert data["site"]["theme"] == "theme_a"
        assert data["site"]["created"] == "2026-01-15T10:30:00"
        assert data["git"]["provider"] == "github"
        assert data["git"]["org"] == "acme-corp"
        # GitHub config should not have gitea-specific fields
        assert "url" not in data["git"]
        assert "ssh_port" not in data["git"]

    def test_save_gitea_config(self, tmp_path):
        git = GitConfig(
            provider="gitea",
            org="clients",
            url="https://gitea.example.com",
            ssh_port=2222,
            token_env="MY_TOKEN",
        )
        config = SiteConfig(
            slug="testsite",
            theme="theme_a",
            created=datetime(2026, 1, 15, 10, 30, 0),
            git=git,
        )

        config.save(tmp_path)

        config_path = tmp_path / ".sum" / "config.yml"
        with open(config_path) as f:
            data = yaml.safe_load(f)

        assert data["git"]["provider"] == "gitea"
        assert data["git"]["org"] == "clients"
        assert data["git"]["url"] == "https://gitea.example.com"
        assert data["git"]["ssh_port"] == 2222
        assert data["git"]["token_env"] == "MY_TOKEN"

    def test_save_no_git_config(self, tmp_path):
        config = SiteConfig(
            slug="testsite",
            theme="theme_a",
            created=datetime(2026, 1, 15, 10, 30, 0),
            git=None,
        )

        config.save(tmp_path)

        config_path = tmp_path / ".sum" / "config.yml"
        with open(config_path) as f:
            data = yaml.safe_load(f)

        assert data["site"]["slug"] == "testsite"
        assert data["git"] is None


class TestSiteConfigLoad:
    """Tests for SiteConfig.load() method."""

    def test_load_raises_when_no_file(self, tmp_path):
        with pytest.raises(SiteConfigError, match="Site config not found"):
            SiteConfig.load(tmp_path)

    def test_load_github_config(self, tmp_path):
        config_dir = tmp_path / ".sum"
        config_dir.mkdir()
        config_path = config_dir / "config.yml"

        data = {
            "site": {
                "slug": "mysite",
                "theme": "theme_a",
                "created": "2026-01-15T10:30:00",
            },
            "git": {
                "provider": "github",
                "org": "acme-corp",
            },
        }
        with open(config_path, "w") as f:
            yaml.dump(data, f)

        config = SiteConfig.load(tmp_path)

        assert config.slug == "mysite"
        assert config.theme == "theme_a"
        assert config.created == datetime(2026, 1, 15, 10, 30, 0)
        assert config.git is not None
        assert config.git.provider == "github"
        assert config.git.org == "acme-corp"
        assert config.git.ssh_port == 22  # default

    def test_load_gitea_config(self, tmp_path):
        config_dir = tmp_path / ".sum"
        config_dir.mkdir()
        config_path = config_dir / "config.yml"

        data = {
            "site": {
                "slug": "mysite",
                "theme": "theme_a",
                "created": "2026-01-15T10:30:00",
            },
            "git": {
                "provider": "gitea",
                "org": "clients",
                "url": "https://gitea.example.com",
                "ssh_port": 2222,
                "token_env": "MY_TOKEN",
            },
        }
        with open(config_path, "w") as f:
            yaml.dump(data, f)

        config = SiteConfig.load(tmp_path)

        assert config.git is not None
        assert config.git.provider == "gitea"
        assert config.git.url == "https://gitea.example.com"
        assert config.git.ssh_port == 2222
        assert config.git.token_env == "MY_TOKEN"

    def test_load_no_git_config(self, tmp_path):
        config_dir = tmp_path / ".sum"
        config_dir.mkdir()
        config_path = config_dir / "config.yml"

        data = {
            "site": {
                "slug": "mysite",
                "theme": "theme_a",
                "created": "2026-01-15T10:30:00",
            },
            "git": None,
        }
        with open(config_path, "w") as f:
            yaml.dump(data, f)

        config = SiteConfig.load(tmp_path)

        assert config.slug == "mysite"
        assert config.git is None

    def test_roundtrip(self, tmp_path):
        """Test that save and load produce equivalent config."""
        original_git = GitConfig(
            provider="gitea",
            org="clients",
            url="https://gitea.example.com",
            ssh_port=2222,
            token_env="MY_TOKEN",
        )
        original = SiteConfig(
            slug="testsite",
            theme="theme_a",
            created=datetime(2026, 1, 15, 10, 30, 0),
            git=original_git,
        )

        original.save(tmp_path)
        loaded = SiteConfig.load(tmp_path)

        assert loaded.slug == original.slug
        assert loaded.theme == original.theme
        assert loaded.created == original.created
        assert loaded.git is not None
        assert loaded.git.provider == original_git.provider
        assert loaded.git.org == original_git.org
        assert loaded.git.url == original_git.url
        assert loaded.git.ssh_port == original_git.ssh_port
        assert loaded.git.token_env == original_git.token_env

    def test_load_invalid_yaml(self, tmp_path):
        """Test that invalid YAML raises SiteConfigError."""
        config_dir = tmp_path / ".sum"
        config_dir.mkdir()
        config_path = config_dir / "config.yml"
        config_path.write_text("invalid: yaml: content:")

        with pytest.raises(SiteConfigError, match="Invalid YAML"):
            SiteConfig.load(tmp_path)

    def test_load_empty_config(self, tmp_path):
        """Test that empty config raises SiteConfigError."""
        config_dir = tmp_path / ".sum"
        config_dir.mkdir()
        config_path = config_dir / "config.yml"
        config_path.write_text("")

        with pytest.raises(SiteConfigError, match="empty or not a mapping"):
            SiteConfig.load(tmp_path)

    def test_load_missing_site_section(self, tmp_path):
        """Test that missing site section raises SiteConfigError."""
        config_dir = tmp_path / ".sum"
        config_dir.mkdir()
        config_path = config_dir / "config.yml"
        config_path.write_text("git: null\n")

        with pytest.raises(SiteConfigError, match="Missing required field"):
            SiteConfig.load(tmp_path)

    def test_load_missing_site_slug(self, tmp_path):
        """Test that missing slug raises SiteConfigError."""
        config_dir = tmp_path / ".sum"
        config_dir.mkdir()
        config_path = config_dir / "config.yml"

        data = {"site": {"theme": "theme_a", "created": "2026-01-15T10:30:00"}}
        with open(config_path, "w") as f:
            yaml.dump(data, f)

        with pytest.raises(SiteConfigError, match="Missing required field"):
            SiteConfig.load(tmp_path)

    def test_load_invalid_datetime(self, tmp_path):
        """Test that invalid datetime raises SiteConfigError."""
        config_dir = tmp_path / ".sum"
        config_dir.mkdir()
        config_path = config_dir / "config.yml"

        data = {"site": {"slug": "test", "theme": "theme_a", "created": "not-a-date"}}
        with open(config_path, "w") as f:
            yaml.dump(data, f)

        with pytest.raises(SiteConfigError, match="Invalid datetime"):
            SiteConfig.load(tmp_path)

    def test_load_missing_git_provider(self, tmp_path):
        """Test that missing git provider raises SiteConfigError."""
        config_dir = tmp_path / ".sum"
        config_dir.mkdir()
        config_path = config_dir / "config.yml"

        data = {
            "site": {
                "slug": "test",
                "theme": "theme_a",
                "created": "2026-01-15T10:30:00",
            },
            "git": {"org": "acme"},  # Missing provider
        }
        with open(config_path, "w") as f:
            yaml.dump(data, f)

        with pytest.raises(SiteConfigError, match="Missing required git field"):
            SiteConfig.load(tmp_path)
