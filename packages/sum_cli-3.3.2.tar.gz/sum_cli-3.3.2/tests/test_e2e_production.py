# pyright: reportImplicitStringConcatenation=false
"""End-to-end tests for production site workflow.

These tests verify the CLI commands work correctly for creating and managing
production sites at /srv/sum/<name>/. They test the full workflow including:
- init: Create a production-ready site
- backup: Create database and media backups
- update: Pull code and restart service
- themes: List available themes

These tests require root access and a properly configured system config.
Run with: sudo -E pytest cli/tests/test_e2e_production.py -v

NOTE: These tests create real infrastructure (databases, systemd services, etc.)
and should only be run on staging/test systems, not production.
"""

from __future__ import annotations

import os
import secrets
import shutil
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING

import pytest

if TYPE_CHECKING:
    from collections.abc import Generator


# =============================================================================
# Test Configuration
# =============================================================================


def _is_root() -> bool:
    """Check if running as root."""
    return os.geteuid() == 0


def _has_system_config() -> bool:
    """Check if system config file exists."""
    return Path("/etc/sum/config.yml").exists()


def _cli_is_installed() -> bool:
    """Check if sum-platform CLI is installed."""
    return shutil.which("sum-platform") is not None


def _postgres_is_running() -> bool:
    """Check if PostgreSQL is running and accessible."""
    try:
        result = subprocess.run(
            ["sudo", "-u", "postgres", "psql", "-c", "SELECT 1;"],
            capture_output=True,
            timeout=10,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def _caddy_is_installed() -> bool:
    """Check if Caddy web server is installed."""
    return shutil.which("caddy") is not None


# Combined skip conditions
skip_if_not_production_ready = pytest.mark.skipif(
    not (_is_root() and _has_system_config() and _cli_is_installed()),
    reason="Requires root, system config, and installed CLI",
)

skip_if_no_postgres = pytest.mark.skipif(
    not _postgres_is_running(),
    reason="PostgreSQL not running or accessible",
)


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def unique_site_name() -> str:
    """Generate a unique site name for testing."""
    suffix = secrets.token_hex(4)
    return f"e2e-test-{suffix}"


@pytest.fixture
def cleanup_site(unique_site_name: str) -> Generator[str, None, None]:
    """Fixture that cleans up the test site after the test."""
    yield unique_site_name

    # Cleanup after test
    site_dir = Path(f"/srv/sum/{unique_site_name}")
    if site_dir.exists():
        # Stop service if running
        service_name = f"sum-{unique_site_name}"
        subprocess.run(
            ["systemctl", "stop", service_name],
            capture_output=True,
        )
        subprocess.run(
            ["systemctl", "disable", service_name],
            capture_output=True,
        )

        # Remove systemd service file
        service_file = Path(f"/etc/systemd/system/{service_name}.service")
        if service_file.exists():
            service_file.unlink()
            subprocess.run(["systemctl", "daemon-reload"], capture_output=True)

        # Remove Caddy config
        caddy_config = Path(f"/etc/caddy/sites/{unique_site_name}.caddy")
        if caddy_config.exists():
            caddy_config.unlink()
            subprocess.run(["systemctl", "reload", "caddy"], capture_output=True)

        # Drop database (use quoted identifiers for names with hyphens)
        db_name = f"sum_{unique_site_name}"
        subprocess.run(
            [
                "sudo",
                "-u",
                "postgres",
                "psql",
                "-c",
                f'DROP DATABASE IF EXISTS "{db_name}";',
            ],
            capture_output=True,
        )
        subprocess.run(
            [
                "sudo",
                "-u",
                "postgres",
                "psql",
                "-c",
                f'DROP USER IF EXISTS "{db_name}_user";',
            ],
            capture_output=True,
        )

        # Remove site directory
        shutil.rmtree(site_dir, ignore_errors=True)


def _run_cli(
    *args: str,
    timeout: int = 300,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    """Run sum-platform CLI command and return result."""
    if env is None:
        env = os.environ.copy()

    return subprocess.run(
        ["sum-platform", *args],
        capture_output=True,
        text=True,
        timeout=timeout,
        env=env,
    )


# =============================================================================
# Themes Command Tests
# =============================================================================


@skip_if_not_production_ready
class TestThemesCommand:
    """Tests for the themes command."""

    def test_themes_lists_available_themes(self) -> None:
        """Verify sum-platform themes shows available themes."""
        result = _run_cli("themes")

        assert result.returncode == 0, f"themes failed: {result.stderr}"
        assert (
            "theme_a" in result.stdout
        ), f"theme_a not found in output: {result.stdout}"

    def test_themes_shows_theme_details(self) -> None:
        """Verify sum-platform themes shows theme metadata."""
        result = _run_cli("themes")

        assert result.returncode == 0, f"themes failed: {result.stderr}"
        # Should show some indication of theme availability
        output = result.stdout.lower()
        assert "theme" in output or "available" in output


# =============================================================================
# Init Command Tests (Full E2E)
# =============================================================================


@skip_if_not_production_ready
@skip_if_no_postgres
class TestInitCommand:
    """End-to-end tests for the init command.

    These tests create real sites and verify the full workflow.
    """

    def test_init_creates_site_directory(self, cleanup_site: str) -> None:
        """Verify init creates the site directory structure."""
        site_name = cleanup_site

        result = _run_cli(
            "init",
            site_name,
            "--theme",
            "theme_a",
            "--no-git",
            "--skip-systemd",
            "--skip-caddy",
            timeout=300,
        )

        assert result.returncode == 0, (
            f"init failed with code {result.returncode}:\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )

        site_dir = Path(f"/srv/sum/{site_name}")
        assert site_dir.exists(), f"Site directory not created: {site_dir}"
        assert (site_dir / "app").exists(), "App directory not created"
        assert (site_dir / "venv").exists(), "Venv directory not created"
        assert (site_dir / "static").exists(), "Static directory not created"
        assert (site_dir / "media").exists(), "Media directory not created"
        assert (site_dir / "backups").exists(), "Backups directory not created"

    def test_init_creates_database(self, cleanup_site: str) -> None:
        """Verify init creates the PostgreSQL database."""
        site_name = cleanup_site
        db_name = f"sum_{site_name}"

        result = _run_cli(
            "init",
            site_name,
            "--theme",
            "theme_a",
            "--no-git",
            "--skip-systemd",
            "--skip-caddy",
            timeout=300,
        )

        assert result.returncode == 0, f"init failed: {result.stderr}"

        # Check database exists (use psql variable substitution to avoid SQL injection)
        db_check = subprocess.run(
            [
                "sudo",
                "-u",
                "postgres",
                "psql",
                "-tAc",
                "SELECT 1 FROM pg_database WHERE datname = :'dbname'",
                "-v",
                f"dbname={db_name}",
            ],
            capture_output=True,
            text=True,
        )
        assert "1" in db_check.stdout, f"Database {db_name} not created"

    def test_init_creates_env_file(self, cleanup_site: str) -> None:
        """Verify init creates the .env configuration file."""
        site_name = cleanup_site

        result = _run_cli(
            "init",
            site_name,
            "--theme",
            "theme_a",
            "--no-git",
            "--skip-systemd",
            "--skip-caddy",
            timeout=300,
        )

        assert result.returncode == 0, f"init failed: {result.stderr}"

        env_file = Path(f"/srv/sum/{site_name}/app/.env")
        assert env_file.exists(), ".env file not created in app directory"

        env_content = env_file.read_text()
        assert "DJANGO_SECRET_KEY=" in env_content, "DJANGO_SECRET_KEY not in .env"
        assert "DJANGO_DB_NAME=" in env_content, "DJANGO_DB_NAME not in .env"

    def test_init_creates_credentials_file(self, cleanup_site: str) -> None:
        """Verify init creates the credentials file."""
        site_name = cleanup_site

        result = _run_cli(
            "init",
            site_name,
            "--theme",
            "theme_a",
            "--no-git",
            "--skip-systemd",
            "--skip-caddy",
            timeout=300,
        )

        assert result.returncode == 0, f"init failed: {result.stderr}"

        creds_file = Path(f"/srv/sum/{site_name}/credentials.txt")
        assert creds_file.exists(), "credentials.txt not created"

        creds_content = creds_file.read_text()
        assert "Site:" in creds_content, "Site info not in credentials"
        assert "Admin URL:" in creds_content, "Admin URL not in credentials"
        assert "Superuser:" in creds_content, "Superuser info not in credentials"

    def test_init_seeds_content(self, cleanup_site: str) -> None:
        """Verify init seeds homepage content."""
        site_name = cleanup_site

        result = _run_cli(
            "init",
            site_name,
            "--theme",
            "theme_a",
            "--no-git",
            "--skip-systemd",
            "--skip-caddy",
            timeout=300,
        )

        assert result.returncode == 0, f"init failed: {result.stderr}"

        # Check that homepage has content via Django shell
        app_dir = Path(f"/srv/sum/{site_name}/app")
        venv_python = Path(f"/srv/sum/{site_name}/venv/bin/python")

        check_cmd = (
            "from home.models import HomePage; "
            "home = HomePage.objects.first(); "
            "print('HAS_CONTENT' if home and home.hero_headline else 'NO_CONTENT')"
        )

        check_result = subprocess.run(
            [str(venv_python), "manage.py", "shell", "-c", check_cmd],
            cwd=app_dir,
            capture_output=True,
            text=True,
            timeout=30,
        )

        assert (
            "HAS_CONTENT" in check_result.stdout
        ), f"Homepage not seeded properly: {check_result.stdout}"

    def test_init_rejects_duplicate_site(self, cleanup_site: str) -> None:
        """Verify init fails if site already exists."""
        site_name = cleanup_site

        # First init should succeed
        result1 = _run_cli(
            "init",
            site_name,
            "--theme",
            "theme_a",
            "--no-git",
            "--skip-systemd",
            "--skip-caddy",
            timeout=300,
        )
        assert result1.returncode == 0, f"First init failed: {result1.stderr}"

        # Second init should fail
        result2 = _run_cli(
            "init",
            site_name,
            "--theme",
            "theme_a",
            "--no-git",
            "--skip-systemd",
            "--skip-caddy",
            timeout=300,
        )
        assert result2.returncode != 0, "Second init should have failed"
        assert (
            "already exists" in result2.stdout.lower()
            or "already exists" in result2.stderr.lower()
        ), f"Expected 'already exists' error, got: {result2.stdout} {result2.stderr}"


# =============================================================================
# Backup Command Tests
# =============================================================================


@skip_if_not_production_ready
@skip_if_no_postgres
class TestBackupCommand:
    """End-to-end tests for the backup command."""

    def test_backup_creates_backup_file(self, cleanup_site: str) -> None:
        """Verify backup creates a backup archive."""
        site_name = cleanup_site

        # First create a site
        init_result = _run_cli(
            "init",
            site_name,
            "--theme",
            "theme_a",
            "--no-git",
            "--skip-systemd",
            "--skip-caddy",
            timeout=300,
        )
        assert init_result.returncode == 0, f"init failed: {init_result.stderr}"

        # Run backup
        backup_result = _run_cli("backup", site_name, timeout=120)

        assert backup_result.returncode == 0, (
            f"backup failed with code {backup_result.returncode}:\n"
            f"stdout: {backup_result.stdout}\n"
            f"stderr: {backup_result.stderr}"
        )

        # Check backup file exists
        backups_dir = Path(f"/srv/sum/{site_name}/backups")
        backup_files = list(backups_dir.glob("*.tar.gz"))
        assert len(backup_files) >= 1, f"No backup files created in {backups_dir}"

    def test_backup_includes_database(self, cleanup_site: str) -> None:
        """Verify backup includes database dump."""
        site_name = cleanup_site

        # Create site
        init_result = _run_cli(
            "init",
            site_name,
            "--theme",
            "theme_a",
            "--no-git",
            "--skip-systemd",
            "--skip-caddy",
            timeout=300,
        )
        assert init_result.returncode == 0, f"init failed: {init_result.stderr}"

        # Run backup
        backup_result = _run_cli("backup", site_name, timeout=120)
        assert backup_result.returncode == 0, f"backup failed: {backup_result.stderr}"

        # Extract and check backup contents
        backups_dir = Path(f"/srv/sum/{site_name}/backups")
        backup_file = list(backups_dir.glob("*.tar.gz"))[0]

        # List archive contents
        list_result = subprocess.run(
            ["tar", "-tzf", str(backup_file)],
            capture_output=True,
            text=True,
        )

        assert (
            "db.sql" in list_result.stdout or "database" in list_result.stdout.lower()
        ), f"Database dump not in backup: {list_result.stdout}"


# =============================================================================
# Update Command Tests
# =============================================================================


@skip_if_not_production_ready
@skip_if_no_postgres
class TestUpdateCommand:
    """End-to-end tests for the update command."""

    def test_update_runs_migrations(self, cleanup_site: str) -> None:
        """Verify update runs database migrations."""
        site_name = cleanup_site

        # Create site
        init_result = _run_cli(
            "init",
            site_name,
            "--theme",
            "theme_a",
            "--no-git",
            "--skip-systemd",
            "--skip-caddy",
            timeout=300,
        )
        assert init_result.returncode == 0, f"init failed: {init_result.stderr}"

        # Set up a local git remote for testing
        app_dir = Path(f"/srv/sum/{site_name}/app")

        # Initialize git if not already
        subprocess.run(
            ["git", "init"],
            cwd=app_dir,
            capture_output=True,
        )
        subprocess.run(
            ["git", "add", "."],
            cwd=app_dir,
            capture_output=True,
        )
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"],
            cwd=app_dir,
            capture_output=True,
        )

        # Run update (will skip git pull since no remote, but should run other steps)
        update_result = _run_cli(
            "update",
            site_name,
            "--skip-migrations",  # Skip to avoid needing actual changes
            timeout=120,
        )

        # Update may fail on git pull without remote, that's expected
        # The important thing is it doesn't crash
        assert update_result.returncode in (
            0,
            1,
        ), f"update crashed: {update_result.stderr}"


# =============================================================================
# CLI Error Handling Tests
# =============================================================================


@skip_if_not_production_ready
class TestCLIErrorHandling:
    """Tests for CLI error handling and edge cases."""

    def test_init_rejects_invalid_name(self) -> None:
        """Verify init rejects invalid site names."""
        result = _run_cli("init", "invalid name with spaces", timeout=30)

        assert result.returncode != 0, "Should reject invalid name"

    def test_init_help_shows_options(self) -> None:
        """Verify init --help shows available options."""
        result = _run_cli("init", "--help")

        assert result.returncode == 0, f"--help failed: {result.stderr}"
        assert "--theme" in result.stdout, "Missing --theme option"
        assert (
            "--no-git" in result.stdout or "skip" in result.stdout.lower()
        ), "Missing skip options"

    def test_backup_nonexistent_site_fails(self) -> None:
        """Verify backup fails gracefully for nonexistent site."""
        result = _run_cli("backup", "nonexistent-site-12345", timeout=30)

        assert result.returncode != 0, "Should fail for nonexistent site"
        assert (
            "not found" in result.stdout.lower()
            or "not found" in result.stderr.lower()
            or "error" in result.stderr.lower()
        ), f"Expected error message, got: {result.stdout} {result.stderr}"

    def test_update_nonexistent_site_fails(self) -> None:
        """Verify update fails gracefully for nonexistent site."""
        result = _run_cli("update", "nonexistent-site-12345", timeout=30)

        assert result.returncode != 0, "Should fail for nonexistent site"


# =============================================================================
# Integration Tests
# =============================================================================


@skip_if_not_production_ready
@skip_if_no_postgres
class TestFullWorkflow:
    """Full workflow integration tests."""

    def test_init_backup_workflow(self, cleanup_site: str) -> None:
        """Test complete init -> backup workflow."""
        site_name = cleanup_site

        # Step 1: Create site
        init_result = _run_cli(
            "init",
            site_name,
            "--theme",
            "theme_a",
            "--no-git",
            "--skip-systemd",
            "--skip-caddy",
            timeout=300,
        )
        assert init_result.returncode == 0, f"init failed: {init_result.stderr}"

        # Step 2: Verify site is accessible (check manage.py works)
        app_dir = Path(f"/srv/sum/{site_name}/app")
        venv_python = Path(f"/srv/sum/{site_name}/venv/bin/python")

        check_result = subprocess.run(
            [str(venv_python), "manage.py", "check"],
            cwd=app_dir,
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert (
            check_result.returncode == 0
        ), f"Django check failed: {check_result.stderr}"

        # Step 3: Create backup
        backup_result = _run_cli("backup", site_name, timeout=120)
        assert backup_result.returncode == 0, f"backup failed: {backup_result.stderr}"

        # Step 4: Verify backup exists
        backups_dir = Path(f"/srv/sum/{site_name}/backups")
        backup_files = list(backups_dir.glob("*.tar.gz"))
        assert len(backup_files) >= 1, "Backup not created"
