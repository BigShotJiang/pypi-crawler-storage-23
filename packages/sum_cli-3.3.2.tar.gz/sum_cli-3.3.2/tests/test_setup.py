"""Tests for setup command."""

from __future__ import annotations

from unittest.mock import patch

import pytest
import yaml
from click.testing import CliRunner


@pytest.fixture
def cli_runner():
    """Provide a Click CLI runner."""
    return CliRunner()


@pytest.fixture
def mock_root():
    """Mock os.geteuid to return 0 (root)."""
    with patch("os.geteuid", return_value=0):
        yield


@pytest.fixture
def mock_non_root():
    """Mock os.geteuid to return non-zero (not root)."""
    with patch("os.geteuid", return_value=1000):
        yield


class TestSetupCommand:
    """Tests for setup command."""

    def test_requires_root(self, cli_runner, mock_non_root):
        """Setup command should require root privileges."""
        from sum.commands.setup import setup

        result = cli_runner.invoke(setup)

        assert result.exit_code != 0
        assert "root privileges" in result.output or "sudo" in result.output

    def test_interactive_setup(self, cli_runner, mock_root, tmp_path):
        """Setup command creates config file with prompted values."""
        from sum.commands.setup import setup

        config_path = tmp_path / "config.yml"

        # Simulate user input for all prompts
        user_input = "\n".join(
            [
                "Acme Agency",  # Agency name
                "staging.acme.com",  # Staging hostname
                "{slug}.staging.acme.com",  # Staging domain pattern
                "/srv/sum",  # Staging base dir
                "prod.acme.com",  # Prod hostname
                "10.0.0.1",  # Prod SSH host
                "/srv/sum",  # Prod base dir
                "/opt/infra",  # Templates dir
                "systemd/gunicorn.service",  # Systemd template
                "caddy/site.caddy",  # Caddy template
                "theme_a",  # Default theme
                "starter",  # Seed profile
                "deploy",  # Deploy user
                "5432",  # Postgres port
                "n",  # Configure backup storage? No
            ]
        )

        with patch("sum.commands.setup.DEFAULT_CONFIG_PATH", config_path):
            result = cli_runner.invoke(setup, input=user_input)

        assert result.exit_code == 0
        assert config_path.exists()

        with open(config_path) as f:
            data = yaml.safe_load(f)

        assert data["agency"]["name"] == "Acme Agency"
        assert data["staging"]["server"] == "staging.acme.com"
        assert data["staging"]["domain_pattern"] == "{slug}.staging.acme.com"
        assert data["production"]["server"] == "prod.acme.com"
        assert data["production"]["ssh_host"] == "10.0.0.1"
        assert data["templates"]["dir"] == "/opt/infra"
        assert data["defaults"]["theme"] == "theme_a"
        assert data["defaults"]["postgres_port"] == 5432

    def test_overwrites_existing_with_confirmation(
        self, cli_runner, mock_root, tmp_path
    ):
        """Setup command prompts before overwriting existing config."""
        from sum.commands.setup import setup

        config_path = tmp_path / "config.yml"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text("existing: config\n")

        # First input is 'y' to confirm overwrite
        user_input = "\n".join(
            [
                "y",  # Confirm overwrite
                "New Agency",  # Agency name
                "new-staging.com",  # Staging hostname
                "{slug}.new-staging.com",  # Staging domain pattern
                "/srv/new",  # Staging base dir
                "new-prod.com",  # Prod hostname
                "10.0.0.2",  # Prod SSH host
                "/srv/new",  # Prod base dir
                "/opt/new-infra",  # Templates dir
                "systemd/new.service",  # Systemd template
                "caddy/new.caddy",  # Caddy template
                "theme_b",  # Default theme
                "full",  # Seed profile
                "admin",  # Deploy user
                "5433",  # Postgres port
                "n",  # Configure backup storage? No
            ]
        )

        with patch("sum.commands.setup.DEFAULT_CONFIG_PATH", config_path):
            result = cli_runner.invoke(setup, input=user_input)

        assert result.exit_code == 0

        with open(config_path) as f:
            data = yaml.safe_load(f)

        assert data["agency"]["name"] == "New Agency"

    def test_aborts_on_decline_overwrite(self, cli_runner, mock_root, tmp_path):
        """Setup command aborts if user declines to overwrite."""
        from sum.commands.setup import setup

        config_path = tmp_path / "config.yml"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text("existing: config\n")

        # 'n' to decline overwrite
        user_input = "n\n"

        with patch("sum.commands.setup.DEFAULT_CONFIG_PATH", config_path):
            result = cli_runner.invoke(setup, input=user_input)

        assert result.exit_code == 0  # SystemExit(0) is clean exit

        # Original config should be unchanged
        assert config_path.read_text() == "existing: config\n"

    def test_creates_parent_directory(self, cli_runner, mock_root, tmp_path):
        """Setup command creates parent directory if it doesn't exist."""
        from sum.commands.setup import setup

        config_path = tmp_path / "etc" / "sum" / "config.yml"

        user_input = "\n".join(
            [
                "Test Agency",
                "staging.test.com",
                "{slug}.staging.test.com",
                "/srv/sum",
                "prod.test.com",
                "10.0.0.1",
                "/srv/sum",
                "/opt/infra",
                "systemd/test.service",
                "caddy/test.caddy",
                "theme_a",
                "starter",
                "deploy",
                "5432",
                "n",  # Configure backup storage? No
            ]
        )

        with patch("sum.commands.setup.DEFAULT_CONFIG_PATH", config_path):
            result = cli_runner.invoke(setup, input=user_input)

        assert result.exit_code == 0
        assert config_path.exists()
        assert config_path.parent.exists()


class TestSetupSmtpRelay:
    """Tests for SMTP relay configuration in setup command."""

    # Common base inputs: agency through postgres port, then backup=yes + storage box + retention
    BASE_INPUTS = [
        "Agency",  # Agency name
        "staging.com",  # Staging hostname
        "{slug}.staging.com",  # Domain pattern
        "/srv/sum",  # Staging base dir
        "prod.com",  # Prod hostname
        "10.0.0.1",  # Prod SSH host
        "/srv/sum",  # Prod base dir
        "/opt/infra",  # Templates dir
        "systemd/test.service",  # Systemd template
        "caddy/test.caddy",  # Caddy template
        "theme_a",  # Default theme
        "starter",  # Seed profile
        "deploy",  # Deploy user
        "5432",  # Postgres port
        "y",  # Configure backup storage? Yes
        "u123.storagebox.de",  # Storage host
        "u123",  # Storage user
        "23",  # SFTP port
        "SHA256:xxxx",  # Fingerprint
        "/etc/sum/backup-key-rsa",  # SSH key path
        "2",  # Full backups to keep
        "7",  # Diff backups to keep
        "alerts@agency.com",  # Alert email
    ]

    def test_smtp_relay_opt_in(self, cli_runner, mock_root, tmp_path):
        """When user opts into SMTP relay, all fields are collected."""
        from sum.commands.setup import setup

        config_path = tmp_path / "config.yml"
        user_input = "\n".join(
            self.BASE_INPUTS
            + [
                "y",  # Configure external SMTP relay? Yes
                "smtp.resend.com",  # SMTP host
                "587",  # SMTP port
                "resend",  # SMTP username
                "/etc/sum/smtp-password",  # Password file
                "y",  # Use TLS? Yes
                "backups@agency.com",  # From address
            ]
        )

        with patch("sum.commands.setup.DEFAULT_CONFIG_PATH", config_path):
            result = cli_runner.invoke(setup, input=user_input)

        assert result.exit_code == 0

        with open(config_path) as f:
            data = yaml.safe_load(f)

        alerts = data["backups"]["alerts"]
        assert alerts["email"] == "alerts@agency.com"
        assert alerts["smtp_host"] == "smtp.resend.com"
        assert alerts["smtp_port"] == 587
        assert alerts["smtp_username"] == "resend"
        assert alerts["smtp_password_file"] == "/etc/sum/smtp-password"
        assert alerts["smtp_use_tls"] is True
        assert alerts["from_address"] == "backups@agency.com"

    def test_smtp_relay_opt_out(self, cli_runner, mock_root, tmp_path):
        """When user declines SMTP relay, only email is in alerts."""
        from sum.commands.setup import setup

        config_path = tmp_path / "config.yml"
        user_input = "\n".join(
            self.BASE_INPUTS
            + [
                "n",  # Configure external SMTP relay? No
            ]
        )

        with patch("sum.commands.setup.DEFAULT_CONFIG_PATH", config_path):
            result = cli_runner.invoke(setup, input=user_input)

        assert result.exit_code == 0

        with open(config_path) as f:
            data = yaml.safe_load(f)

        alerts = data["backups"]["alerts"]
        assert alerts == {"email": "alerts@agency.com"}
        assert "smtp_host" not in alerts


class TestSetupConfigStructure:
    """Tests for the structure of generated config file."""

    def test_config_has_no_git_section(self, cli_runner, mock_root, tmp_path):
        """Setup command should not create git config - that's per-site."""
        from sum.commands.setup import setup

        config_path = tmp_path / "config.yml"

        user_input = "\n".join(
            [
                "Agency",
                "staging.com",
                "{slug}.staging.com",
                "/srv/sum",
                "prod.com",
                "10.0.0.1",
                "/srv/sum",
                "/opt/infra",
                "systemd/test.service",
                "caddy/test.caddy",
                "theme_a",
                "starter",
                "deploy",
                "5432",
                "n",  # Configure backup storage? No
            ]
        )

        with patch("sum.commands.setup.DEFAULT_CONFIG_PATH", config_path):
            cli_runner.invoke(setup, input=user_input)

        with open(config_path) as f:
            data = yaml.safe_load(f)

        # Git config should NOT be in system config
        assert "git" not in data
        assert "git_provider" not in data.get("agency", {})
        assert "git_org" not in data.get("agency", {})
