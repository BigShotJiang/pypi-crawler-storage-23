# pyright: reportMissingImports=false, reportPrivateUsage=false, reportUnusedCallResult=false, reportUnknownMemberType=false, reportUnknownParameterType=false, reportMissingParameterType=false, reportUnknownVariableType=false, reportUnknownArgumentType=false, reportMissingModuleSource=false

"""Tests for GITEA_TOKEN detection in init and promote commands.

Verifies that:
- init warns (but does not fail) when GITEA_TOKEN is missing
- promote hard-errors when GITEA_TOKEN is missing
- Both commands auto-load tokens from tea config when available
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from sum.commands.init import run_init
from sum.commands.promote import run_promote


class TestInitGiteaTokenWarning:
    """init command warns when GITEA_TOKEN is missing for gitea provider."""

    @patch("sum.commands.init.require_root_or_escalate", return_value=True)
    @patch("sum.commands.init.detect_gitea_token", return_value=None)
    def test_warns_when_gitea_token_missing(self, mock_detect, mock_escalate, capsys):
        """Warning is printed when GITEA_TOKEN is not found."""
        # run_init will continue past the warning and fail later on
        # infrastructure checks, which is fine — we just verify the warning
        with patch("sum.commands.init.check_infrastructure") as mock_infra:
            mock_infra.return_value.errors = ["not a real server"]
            result = run_init(
                "testsite",
                git_provider="gitea",
                git_org="testorg",
                gitea_url="https://gitea.example.com",
            )

        assert result == 1  # fails on infra check
        captured = capsys.readouterr()
        assert "GITEA_TOKEN" in captured.err or "GITEA_TOKEN" in captured.out

    @patch("sum.commands.init.require_root_or_escalate", return_value=True)
    @patch("sum.commands.init.detect_gitea_token", return_value="found-token")
    def test_no_warning_when_gitea_token_present(
        self, mock_detect, mock_escalate, capsys
    ):
        """No warning when GITEA_TOKEN is detected."""
        with patch("sum.commands.init.check_infrastructure") as mock_infra:
            mock_infra.return_value.errors = ["not a real server"]
            result = run_init(
                "testsite",
                git_provider="gitea",
                git_org="testorg",
                gitea_url="https://gitea.example.com",
            )

        assert result == 1  # fails on infra check
        captured = capsys.readouterr()
        output = captured.err + captured.out
        assert "not found" not in output

    @patch("sum.commands.init.require_root_or_escalate", return_value=True)
    def test_no_warning_for_github_provider(self, mock_escalate, capsys):
        """No GITEA_TOKEN warning when using github provider."""
        with patch("sum.commands.init.check_infrastructure") as mock_infra:
            mock_infra.return_value.errors = ["not a real server"]
            result = run_init(
                "testsite",
                git_provider="github",
                git_org="testorg",
            )

        assert result == 1  # fails on infra check
        captured = capsys.readouterr()
        output = captured.err + captured.out
        assert "GITEA_TOKEN" not in output

    @patch("sum.commands.init.require_root_or_escalate", return_value=True)
    def test_no_warning_when_no_git(self, mock_escalate, capsys):
        """No GITEA_TOKEN warning when --no-git is used."""
        with patch("sum.commands.init.check_infrastructure") as mock_infra:
            mock_infra.return_value.errors = ["not a real server"]
            result = run_init(
                "testsite",
                no_git=True,
            )

        assert result == 1  # fails on infra check
        captured = capsys.readouterr()
        output = captured.err + captured.out
        assert "GITEA_TOKEN" not in output

    @patch("sum.commands.init.require_root_or_escalate", return_value=True)
    @patch("sum.commands.init.detect_gitea_token", return_value=None)
    def test_custom_token_env_in_warning(self, mock_detect, mock_escalate, capsys):
        """Warning uses custom gitea_token_env name."""
        with patch("sum.commands.init.check_infrastructure") as mock_infra:
            mock_infra.return_value.errors = ["not a real server"]
            run_init(
                "testsite",
                git_provider="gitea",
                git_org="testorg",
                gitea_url="https://gitea.example.com",
                gitea_token_env="MY_CUSTOM_TOKEN",
            )

        captured = capsys.readouterr()
        output = captured.err + captured.out
        assert "MY_CUSTOM_TOKEN" in output

    @patch("sum.commands.init.require_root_or_escalate", return_value=True)
    @patch("sum.commands.init.detect_gitea_token", return_value="found-token")
    def test_escalation_preserves_custom_token_env(self, mock_detect, mock_escalate):
        """require_root_or_escalate is called with token_env for sudo preservation."""
        with patch("sum.commands.init.check_infrastructure") as mock_infra:
            mock_infra.return_value.errors = ["not a real server"]
            run_init(
                "testsite",
                git_provider="gitea",
                git_org="testorg",
                gitea_url="https://gitea.example.com",
                gitea_token_env="MY_CUSTOM_TOKEN",
            )

        mock_escalate.assert_called_once_with("init", token_env="MY_CUSTOM_TOKEN")


class TestPromoteGiteaTokenError:
    """promote command hard-errors when GITEA_TOKEN is missing for gitea provider."""

    @patch("sum.commands.promote.detect_gitea_token", return_value=None)
    @patch("sum.commands.promote.get_system_config")
    @patch("sum.commands.promote.SiteConfig.load")
    def test_errors_when_gitea_token_missing(
        self, mock_site_config, mock_sys_config, mock_detect
    ):
        """Returns error code when GITEA_TOKEN is not found for gitea provider."""
        # Set up mock site config with gitea provider
        mock_config = MagicMock()
        mock_config.production.ssh_host = "prod.example.com"
        mock_sys_config.return_value = mock_config
        staging_dir = MagicMock()
        staging_dir.exists.return_value = True
        mock_config.get_site_dir.return_value = staging_dir

        mock_site = MagicMock()
        mock_site.git.provider = "gitea"
        mock_site.git.token_env = "GITEA_TOKEN"
        mock_site_config.return_value = mock_site

        result = run_promote("testsite", domain="test.example.com", skip_confirm=True)
        assert result == 1

    @patch("sum.commands.promote.detect_gitea_token", return_value="found-token")
    @patch("sum.commands.promote.get_system_config")
    @patch("sum.commands.promote.SiteConfig.load")
    @patch("sum.commands.promote._check_ssh_connectivity")
    @patch("sum.commands.promote.require_root_or_escalate", return_value=True)
    @patch("sum.commands.promote._backup_staging_db")
    def test_proceeds_when_gitea_token_present(
        self,
        mock_backup,
        mock_escalate,
        mock_ssh,
        mock_site_config,
        mock_sys_config,
        mock_detect,
    ):
        """Does not error when GITEA_TOKEN is detected for gitea provider."""
        mock_config = MagicMock()
        mock_config.production.ssh_host = "prod.example.com"
        mock_config.backups = None
        mock_sys_config.return_value = mock_config
        staging_dir = MagicMock()
        staging_dir.exists.return_value = True
        mock_config.get_site_dir.return_value = staging_dir

        mock_site = MagicMock()
        mock_site.git.provider = "gitea"
        mock_site.git.token_env = "GITEA_TOKEN"
        mock_site_config.return_value = mock_site

        # Let it fail later in the pipeline (backup step), that's fine
        from sum.exceptions import SetupError

        mock_backup.side_effect = SetupError("test bail out")

        result = run_promote("testsite", domain="test.example.com", skip_confirm=True)
        # It should get past the token check (and fail at backup, returning 1)
        assert result == 1
        # But it should NOT have an error message about GITEA_TOKEN
        mock_detect.assert_called_once()

    @patch("sum.commands.promote.get_system_config")
    @patch("sum.commands.promote.SiteConfig.load")
    @patch("sum.commands.promote._check_ssh_connectivity")
    @patch("sum.commands.promote.require_root_or_escalate", return_value=True)
    @patch("sum.commands.promote._backup_staging_db")
    def test_no_token_check_for_github_provider(
        self,
        mock_backup,
        mock_escalate,
        mock_ssh,
        mock_site_config,
        mock_sys_config,
    ):
        """No GITEA_TOKEN check when provider is github."""
        mock_config = MagicMock()
        mock_config.production.ssh_host = "prod.example.com"
        mock_config.backups = None
        mock_sys_config.return_value = mock_config
        staging_dir = MagicMock()
        staging_dir.exists.return_value = True
        mock_config.get_site_dir.return_value = staging_dir

        mock_site = MagicMock()
        mock_site.git.provider = "github"
        mock_site.git.token_env = "GITHUB_TOKEN"
        mock_site_config.return_value = mock_site

        from sum.exceptions import SetupError

        mock_backup.side_effect = SetupError("test bail out")

        result = run_promote("testsite", domain="test.example.com", skip_confirm=True)
        # Should get past the gitea check without issue
        assert result == 1
