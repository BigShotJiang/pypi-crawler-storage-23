"""Tests for per-command pre-flight check integration (PREFLT-02).

Verifies that each state-mutating command:
- Registers the correct pre-flight checks
- Blocks execution when required checks fail
- Respects --skip-preflight flag
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from sum.utils.preflight import CheckResult, CheckSeverity

# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────


def _make_fail_result():
    """Create a failing preflight result pair."""
    check = MagicMock()
    check.severity = CheckSeverity.REQUIRED
    check.name = "Fake"
    result = CheckResult.fail("boom")
    return [(check, result)]


def _make_pass_result():
    """Create a passing preflight result pair."""
    check = MagicMock()
    check.severity = CheckSeverity.REQUIRED
    check.name = "Fake"
    result = CheckResult.ok("ok")
    return [(check, result)]


# ──────────────────────────────────────────────────────────────────────────────
# init command tests
# ──────────────────────────────────────────────────────────────────────────────


class TestInitPreflight:
    """Tests for init command pre-flight integration."""

    @patch("sum.commands.init.require_root_or_escalate")
    @patch("sum.commands.init.validate_site_slug")
    @patch("sum.commands.init.PreflightRunner")
    def test_init_runs_preflight_checks(
        self, mock_runner_cls, mock_validate, mock_root
    ):
        """Init registers SystemConfigCheck in phase 1."""
        from sum.commands.init import run_init

        mock_runner = MagicMock()
        mock_runner_cls.return_value = mock_runner
        mock_runner.run.return_value = _make_fail_result()
        mock_runner_cls.format_results.return_value = ""
        mock_runner_cls.is_go.return_value = False

        result = run_init("test-site", no_git=True)
        assert result == 1
        # Phase 1 registers SystemConfigCheck (DiskSpaceCheck moved to phase 2)
        assert mock_runner.register.call_count >= 1

    @patch("sum.commands.init.require_root_or_escalate")
    @patch("sum.commands.init.validate_site_slug")
    @patch("sum.commands.init.PreflightRunner")
    def test_init_registers_gitea_token_check(
        self, mock_runner_cls, mock_validate, mock_root
    ):
        """Init registers GiteaTokenCheck when git_provider=gitea."""
        from sum.commands.init import run_init

        mock_runner = MagicMock()
        mock_runner_cls.return_value = mock_runner
        mock_runner.run.return_value = _make_fail_result()
        mock_runner_cls.format_results.return_value = ""
        mock_runner_cls.is_go.return_value = False

        result = run_init(
            "test-site", git_provider="gitea", git_org="org", gitea_url="https://x"
        )
        assert result == 1
        # Phase 1: SystemConfig + GiteaToken (DiskSpaceCheck moved to phase 2)
        assert mock_runner.register.call_count >= 2

    @patch("sum.commands.init.require_root_or_escalate")
    @patch("sum.commands.init.validate_site_slug")
    @patch("sum.commands.init.check_infrastructure")
    @patch("sum.commands.init.get_system_config")
    @patch("sum.commands.init.PreflightRunner")
    def test_init_phase2_registers_disk_space(
        self, mock_runner_cls, mock_config, mock_infra, mock_validate, mock_root
    ):
        """Init registers DiskSpaceCheck in phase 2."""
        from sum.commands.init import run_init

        config_obj = MagicMock()
        config_obj.staging.base_dir = "/srv/sum"
        config_obj.templates.systemd_path = None
        config_obj.templates.caddy_path = None
        mock_config.return_value = config_obj
        mock_infra.return_value = MagicMock(errors=[])

        # Two runner instances: phase 1 passes, phase 2 fails
        mock_runner1 = MagicMock()
        mock_runner2 = MagicMock()
        mock_runner_cls.side_effect = [mock_runner1, mock_runner2]
        mock_runner1.run.return_value = _make_pass_result()
        mock_runner2.run.return_value = _make_fail_result()
        mock_runner_cls.format_results.return_value = ""
        mock_runner_cls.is_go.side_effect = [True, False]

        result = run_init("test-site", no_git=True)
        assert result == 1
        # Phase 2 registers DiskSpaceCheck (at least 1 check)
        assert mock_runner2.register.call_count >= 1
        # Verify the registered check is a DiskSpaceCheck
        from sum.utils.preflight import DiskSpaceCheck

        registered_checks = [
            call[0][0] for call in mock_runner2.register.call_args_list
        ]
        assert any(isinstance(c, DiskSpaceCheck) for c in registered_checks)

    @patch("sum.commands.init.require_root_or_escalate")
    @patch("sum.commands.init.validate_site_slug")
    @patch("sum.commands.init.check_infrastructure")
    @patch("sum.commands.init.get_system_config")
    def test_init_skip_preflight(
        self, mock_config, mock_infra, mock_validate, mock_root
    ):
        """Init skips preflight when skip_preflight=True."""
        from sum.commands.init import run_init

        mock_config_obj = MagicMock()
        mock_config.return_value = mock_config_obj
        site_dir = MagicMock()
        site_dir.exists.return_value = True
        mock_config_obj.get_site_dir.return_value = site_dir

        mock_infra.return_value = MagicMock(errors=[])

        # Should NOT call PreflightRunner at all when skip_preflight=True
        with patch("sum.commands.init.PreflightRunner") as mock_runner_cls:
            result = run_init("test-site", no_git=True, skip_preflight=True)
            mock_runner_cls.assert_not_called()
            # Will fail at "site already exists" — that's expected, we just
            # verify preflight was skipped
            assert result == 1


# ──────────────────────────────────────────────────────────────────────────────
# promote command tests
# ──────────────────────────────────────────────────────────────────────────────


class TestPromotePreflight:
    """Tests for promote command pre-flight integration."""

    @patch("sum.commands.promote.require_root_or_escalate")
    @patch("sum.commands.promote.SiteConfig.load")
    @patch("sum.commands.promote.get_system_config")
    @patch("sum.commands.promote.validate_domain")
    @patch("sum.commands.promote.validate_site_slug")
    @patch("sum.commands.promote.PreflightRunner")
    def test_promote_runs_preflight_checks(
        self,
        mock_runner_cls,
        mock_validate_slug,
        mock_validate_domain,
        mock_config,
        mock_site_config,
        mock_root,
    ):
        """Promote registers SystemConfigCheck (phase 1) + SiteExists, PostgresCluster, SSH, etc. (phase 2)."""
        from sum.commands.promote import run_promote

        # Setup config mock
        config_obj = MagicMock()
        config_obj.production.ssh_host = "prod.example.com"
        config_obj.backups = None
        staging_dir = MagicMock()
        staging_dir.exists.return_value = True
        config_obj.get_site_dir.return_value = staging_dir
        mock_config.return_value = config_obj

        # Setup site config mock
        site_config_obj = MagicMock()
        site_config_obj.git = MagicMock()
        site_config_obj.git.provider = "github"
        mock_site_config.return_value = site_config_obj

        # Two runner instances: phase 1 passes, phase 2 fails
        mock_runner1 = MagicMock()
        mock_runner2 = MagicMock()
        mock_runner_cls.side_effect = [mock_runner1, mock_runner2]
        mock_runner1.run.return_value = _make_pass_result()
        mock_runner2.run.return_value = _make_fail_result()
        mock_runner_cls.format_results.return_value = ""
        mock_runner_cls.is_go.side_effect = [True, False]

        result = run_promote("test-site", domain="test.com")
        assert result == 1
        # Phase 1: SystemConfigCheck = 1
        assert mock_runner1.register.call_count == 1
        # Phase 2: SiteExists + PostgresCluster + SSH + DiskSpace = at least 4
        assert mock_runner2.register.call_count >= 4

    @patch("sum.commands.promote.SiteConfig.load")
    @patch("sum.commands.promote.get_system_config")
    @patch("sum.commands.promote.validate_domain")
    @patch("sum.commands.promote.validate_site_slug")
    def test_promote_skip_preflight(
        self,
        mock_validate_slug,
        mock_validate_domain,
        mock_config,
        mock_site_config,
    ):
        """Promote skips preflight when skip_preflight=True."""
        from sum.commands.promote import run_promote

        config_obj = MagicMock()
        staging_dir = MagicMock()
        staging_dir.exists.return_value = True
        config_obj.get_site_dir.return_value = staging_dir
        mock_config.return_value = config_obj

        site_config_obj = MagicMock()
        site_config_obj.git = MagicMock()
        site_config_obj.git.provider = "github"
        mock_site_config.return_value = site_config_obj

        with patch("sum.commands.promote.PreflightRunner") as mock_runner_cls:
            # dry_run=True to avoid the full promote flow
            result = run_promote(
                "test-site", domain="test.com", dry_run=True, skip_preflight=True
            )
            mock_runner_cls.assert_not_called()
            assert result == 0  # dry run succeeds


# ──────────────────────────────────────────────────────────────────────────────
# backup command tests
# ──────────────────────────────────────────────────────────────────────────────


class TestBackupPreflight:
    """Tests for backup command pre-flight integration."""

    @patch("sum.commands.backup.require_root_or_escalate")
    @patch("sum.commands.backup.get_system_config")
    @patch("sum.commands.backup.validate_site_slug")
    @patch("sum.commands.backup.PreflightRunner")
    def test_backup_runs_preflight_checks(
        self, mock_runner_cls, mock_validate, mock_config, mock_root
    ):
        """Backup registers SystemConfigCheck (phase 1) + SiteExists, PostgresCluster, etc. (phase 2)."""
        from sum.commands.backup import run_backup

        config_obj = MagicMock()
        config_obj.backups = MagicMock()
        config_obj.backups.cipher_pass_file = "/etc/sum/cipher.key"
        config_obj.get_pgbackrest_config_dir.return_value = MagicMock(
            __str__=lambda s: "/etc/pgbackrest/conf.d"
        )
        mock_config.return_value = config_obj

        # Two runner instances: phase 1 passes, phase 2 fails
        mock_runner1 = MagicMock()
        mock_runner2 = MagicMock()
        mock_runner_cls.side_effect = [mock_runner1, mock_runner2]
        mock_runner1.run.return_value = _make_pass_result()
        mock_runner2.run.return_value = _make_fail_result()
        mock_runner_cls.format_results.return_value = ""
        mock_runner_cls.is_go.side_effect = [True, False]

        result = run_backup("test-site")
        assert result == 1
        # Phase 1: SystemConfigCheck = 1
        assert mock_runner1.register.call_count == 1
        # Phase 2: SiteExists + PostgresCluster + DiskSpace + PgBackRestStanza + CipherPassFile = 5
        assert mock_runner2.register.call_count >= 4

    @patch("sum.commands.backup.require_root_or_escalate")
    @patch("sum.commands.backup.get_system_config")
    @patch("sum.commands.backup.validate_site_slug")
    @patch("sum.commands.backup.get_site_port")
    def test_backup_skip_preflight(
        self, mock_port, mock_validate, mock_config, mock_root
    ):
        """Backup skips preflight when skip_preflight=True."""
        from sum.commands.backup import run_backup

        config_obj = MagicMock()
        config_obj.backups = MagicMock()
        mock_config.return_value = config_obj
        mock_port.return_value = None  # No port = error, but preflight skipped

        with patch("sum.commands.backup.PreflightRunner") as mock_runner_cls:
            result = run_backup("test-site", skip_preflight=True)
            mock_runner_cls.assert_not_called()
            # Will fail at "no PostgreSQL cluster" — that's expected
            assert result == 1


# ──────────────────────────────────────────────────────────────────────────────
# restore command tests
# ──────────────────────────────────────────────────────────────────────────────


class TestRestorePreflight:
    """Tests for restore command pre-flight integration."""

    @patch("sum.commands.restore.require_root_or_escalate")
    @patch("sum.commands.restore.get_system_config")
    @patch("sum.commands.restore.validate_site_slug")
    @patch("sum.commands.restore.get_site_port")
    @patch("sum.commands.restore.PreflightRunner")
    def test_restore_runs_preflight_checks(
        self, mock_runner_cls, mock_port, mock_validate, mock_config, mock_root
    ):
        """Restore registers SystemConfigCheck (phase 1) + SiteExists, PostgresCluster, etc. (phase 2)."""
        from sum.commands.restore import run_restore

        config_obj = MagicMock()
        config_obj.backups = MagicMock()
        config_obj.backups.cipher_pass_file = "/etc/sum/cipher.key"
        config_obj.get_pgbackrest_config_dir.return_value = MagicMock(
            __str__=lambda s: "/etc/pgbackrest/conf.d"
        )
        mock_config.return_value = config_obj
        mock_port.return_value = 5433

        # Two runner instances: phase 1 passes, phase 2 fails
        mock_runner1 = MagicMock()
        mock_runner2 = MagicMock()
        mock_runner_cls.side_effect = [mock_runner1, mock_runner2]
        mock_runner1.run.return_value = _make_pass_result()
        mock_runner2.run.return_value = _make_fail_result()
        mock_runner_cls.format_results.return_value = ""
        mock_runner_cls.is_go.side_effect = [True, False]

        result = run_restore("test-site", use_latest=True)
        assert result == 1
        # Phase 1: SystemConfigCheck = 1
        assert mock_runner1.register.call_count == 1
        # Phase 2: SiteExists + PostgresCluster + PgBackRestStanza + CipherPassFile = 4
        assert mock_runner2.register.call_count >= 4

    @patch("sum.commands.restore.require_root_or_escalate")
    @patch("sum.commands.restore.get_system_config")
    @patch("sum.commands.restore.validate_site_slug")
    @patch("sum.commands.restore.get_site_port")
    @patch("sum.commands.restore._check_backup_configured")
    def test_restore_skip_preflight(
        self, mock_check_configured, mock_port, mock_validate, mock_config, mock_root
    ):
        """Restore skips preflight when skip_preflight=True."""
        from sum.commands.restore import run_restore

        config_obj = MagicMock()
        mock_config.return_value = config_obj
        mock_port.return_value = 5433

        with patch("sum.commands.restore.PreflightRunner") as mock_runner_cls:
            # Will proceed past preflight and fail at option validation
            run_restore(
                "test-site", use_latest=True, skip_preflight=True, skip_confirm=True
            )
            mock_runner_cls.assert_not_called()


# ──────────────────────────────────────────────────────────────────────────────
# update command tests
# ──────────────────────────────────────────────────────────────────────────────


class TestUpdatePreflight:
    """Tests for update command pre-flight integration."""

    @patch("sum.commands.update.require_root_or_escalate")
    @patch("sum.commands.update.get_system_config")
    @patch("sum.commands.update.validate_site_slug")
    @patch("sum.commands.update.PreflightRunner")
    def test_update_runs_preflight_checks(
        self, mock_runner_cls, mock_validate, mock_config, mock_root
    ):
        """Update registers SystemConfigCheck (phase 1) + SiteExistsCheck + PostgresClusterCheck (phase 2)."""
        from sum.commands.update import run_update

        config_obj = MagicMock()
        mock_config.return_value = config_obj

        # Two runner instances: phase 1 passes, phase 2 fails
        mock_runner1 = MagicMock()
        mock_runner2 = MagicMock()
        mock_runner_cls.side_effect = [mock_runner1, mock_runner2]
        mock_runner1.run.return_value = _make_pass_result()
        mock_runner2.run.return_value = _make_fail_result()
        mock_runner_cls.format_results.return_value = ""
        mock_runner_cls.is_go.side_effect = [True, False]

        result = run_update("test-site")
        assert result == 1
        # Phase 1: SystemConfigCheck = 1
        assert mock_runner1.register.call_count == 1
        # Phase 2: SiteExists + PostgresCluster = 2
        assert mock_runner2.register.call_count >= 2

    @patch("sum.commands.update.require_root_or_escalate")
    @patch("sum.commands.update.get_system_config")
    @patch("sum.commands.update.validate_site_slug")
    @patch("sum.commands.update.PreflightRunner")
    def test_update_registers_ssh_for_prod(
        self, mock_runner_cls, mock_validate, mock_config, mock_root
    ):
        """Update registers SSHConnectivityCheck when target=prod."""
        from sum.commands.update import run_update

        config_obj = MagicMock()
        config_obj.production.ssh_host = "prod.example.com"
        mock_config.return_value = config_obj

        # Two runner instances: phase 1 passes, phase 2 fails
        mock_runner1 = MagicMock()
        mock_runner2 = MagicMock()
        mock_runner_cls.side_effect = [mock_runner1, mock_runner2]
        mock_runner1.run.return_value = _make_pass_result()
        mock_runner2.run.return_value = _make_fail_result()
        mock_runner_cls.format_results.return_value = ""
        mock_runner_cls.is_go.side_effect = [True, False]

        result = run_update("test-site", target="prod")
        assert result == 1
        # Phase 1: SystemConfigCheck = 1
        assert mock_runner1.register.call_count == 1
        # Phase 2: SiteExists + PostgresCluster + SSHConnectivity = 3
        assert mock_runner2.register.call_count >= 2

    @patch("sum.commands.update.require_root_or_escalate")
    @patch("sum.commands.update.get_system_config")
    @patch("sum.commands.update.validate_site_slug")
    def test_update_skip_preflight(self, mock_validate, mock_config, mock_root):
        """Update skips preflight when skip_preflight=True."""
        from sum.commands.update import run_update

        config_obj = MagicMock()
        site_dir = MagicMock()
        site_dir.exists.return_value = False
        config_obj.get_site_dir.return_value = site_dir
        mock_config.return_value = config_obj

        with patch("sum.commands.update.PreflightRunner") as mock_runner_cls:
            result = run_update("test-site", skip_preflight=True)
            mock_runner_cls.assert_not_called()
            # Will fail at "site not found" — expected
            assert result == 1


# ──────────────────────────────────────────────────────────────────────────────
# destroy command tests
# ──────────────────────────────────────────────────────────────────────────────


class TestDestroyPreflight:
    """Tests for destroy command pre-flight integration."""

    @patch("sum.commands.destroy.require_root_or_escalate")
    @patch("sum.commands.destroy.get_system_config")
    @patch("sum.commands.destroy.validate_site_slug")
    @patch("sum.commands.destroy.PreflightRunner")
    def test_destroy_runs_preflight_with_recommended_severity(
        self, mock_runner_cls, mock_validate, mock_config, mock_root
    ):
        """Destroy registers SystemConfigCheck (phase 1) + SiteExistsCheck with RECOMMENDED severity (phase 2)."""
        from sum.commands.destroy import run_destroy

        config_obj = MagicMock()
        site_dir = MagicMock()
        site_dir.exists.return_value = False
        config_obj.get_site_dir.return_value = site_dir
        mock_config.return_value = config_obj

        # Two runner instances: phase 1 (SystemConfigCheck) passes, phase 2 (SiteExists) passes
        mock_runner1 = MagicMock()
        mock_runner2 = MagicMock()
        mock_runner_cls.side_effect = [mock_runner1, mock_runner2]
        mock_runner1.run.return_value = _make_pass_result()
        mock_runner2.run.return_value = _make_pass_result()
        mock_runner_cls.format_results.return_value = ""
        mock_runner_cls.is_go.return_value = True

        run_destroy("test-site", force=True)
        # Phase 1: SystemConfigCheck = 1
        assert mock_runner1.register.call_count == 1
        # Phase 2: SiteExistsCheck (RECOMMENDED) = 1
        assert mock_runner2.register.call_count == 1

        # Verify the phase 2 check has RECOMMENDED severity
        registered_check = mock_runner2.register.call_args_list[0][0][0]
        assert registered_check.severity == CheckSeverity.RECOMMENDED

    @patch("sum.commands.destroy.require_root_or_escalate")
    @patch("sum.commands.destroy.get_system_config")
    @patch("sum.commands.destroy.validate_site_slug")
    def test_destroy_skip_preflight(self, mock_validate, mock_config, mock_root):
        """Destroy skips preflight when skip_preflight=True."""
        from sum.commands.destroy import run_destroy

        config_obj = MagicMock()
        site_dir = MagicMock()
        site_dir.exists.return_value = False
        config_obj.get_site_dir.return_value = site_dir
        mock_config.return_value = config_obj

        with patch("sum.commands.destroy.PreflightRunner") as mock_runner_cls:
            result = run_destroy("test-site", force=True, skip_preflight=True)
            mock_runner_cls.assert_not_called()
            # Will fail at "site doesn't exist" — expected
            assert result == 1

    @patch("sum.commands.destroy.require_root_or_escalate")
    @patch("sum.commands.destroy.get_system_config")
    @patch("sum.commands.destroy.validate_site_slug")
    @patch("sum.commands.destroy.PreflightRunner")
    def test_destroy_recommended_does_not_block(
        self, mock_runner_cls, mock_validate, mock_config, mock_root
    ):
        """Destroy's RECOMMENDED check doesn't block even on failure."""
        from sum.commands.destroy import run_destroy

        config_obj = MagicMock()
        site_dir = MagicMock()
        site_dir.exists.return_value = False
        config_obj.get_site_dir.return_value = site_dir
        mock_config.return_value = config_obj

        # Phase 1 (SystemConfigCheck) passes
        mock_runner1 = MagicMock()
        mock_runner1.run.return_value = _make_pass_result()

        # Phase 2: Simulate RECOMMENDED failure — should NOT block
        mock_runner2 = MagicMock()
        check = MagicMock()
        check.severity = CheckSeverity.RECOMMENDED
        check.name = "SiteExists"
        fail_result = CheckResult.fail("site not found")
        mock_runner2.run.return_value = [(check, fail_result)]

        mock_runner_cls.side_effect = [mock_runner1, mock_runner2]
        mock_runner_cls.format_results.return_value = ""
        # is_go returns True for both (RECOMMENDED failures don't block)
        mock_runner_cls.is_go.return_value = True

        # Should proceed past preflight (then fail at "site not found")
        result = run_destroy("test-site", force=True)
        assert result == 1  # fails at site_dir.exists() check, not preflight


# ──────────────────────────────────────────────────────────────────────────────
# CLI integration: --skip-preflight flag tests
# ──────────────────────────────────────────────────────────────────────────────


class TestSkipPreflightFlag:
    """Tests that --skip-preflight is threaded from CLI to run_* functions."""

    def test_skip_preflight_flag_accepted(self):
        """The CLI group accepts --skip-preflight."""
        from click.testing import CliRunner
        from sum.cli import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["--skip-preflight", "--help"])
        assert result.exit_code == 0

    def test_skip_preflight_stored_in_context(self):
        """--skip-preflight stores True in ctx.obj."""
        from click.testing import CliRunner
        from sum.cli import cli

        runner = CliRunner()
        # Use a non-existent command to trigger an error, but the
        # context should still be set up
        result = runner.invoke(cli, ["--skip-preflight", "--version"])
        assert result.exit_code == 0
