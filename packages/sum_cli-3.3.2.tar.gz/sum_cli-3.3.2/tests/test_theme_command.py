# pyright: reportMissingImports=false, reportPrivateUsage=false, reportUnknownMemberType=false, reportUnknownParameterType=false, reportMissingParameterType=false, reportUnknownVariableType=false, reportUnusedCallResult=false, reportUnknownArgumentType=false, reportMissingModuleSource=false

"""Tests for the theme command group."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from sum.commands.theme import (
    run_theme_check,
    run_theme_list,
    run_theme_update,
    run_theme_versions,
)
from sum.exceptions import ThemeDowngradeError, ThemeNotFoundError, ThemeUpdateError
from sum.setup.remote_themes import (
    compare_versions,
    list_remote_themes,
    list_theme_versions,
)
from sum.setup.scaffold import install_theme, read_theme_lockfile


class TestCompareVersions:
    """Test version comparison function."""

    def test_equal_versions(self):
        assert compare_versions("1.0.0", "1.0.0") == 0

    def test_first_greater(self):
        assert compare_versions("2.0.0", "1.0.0") == 1

    def test_first_lesser(self):
        assert compare_versions("1.0.0", "2.0.0") == -1

    def test_minor_version_comparison(self):
        assert compare_versions("1.2.0", "1.1.0") == 1

    def test_patch_version_comparison(self):
        assert compare_versions("1.0.2", "1.0.1") == 1

    def test_handles_different_lengths(self):
        # 1.0 should be less than 1.0.1
        assert compare_versions("1.0", "1.0.1") == -1

    def test_semver_not_string_comparison(self):
        # 1.10.0 > 1.9.0 numerically
        assert compare_versions("1.10.0", "1.9.0") == 1


class TestListThemeVersions:
    """Test listing available theme versions."""

    def test_returns_empty_on_git_error(self):
        from subprocess import CalledProcessError

        with patch("sum.setup.remote_themes._run_git_command") as mock_git:
            mock_git.side_effect = CalledProcessError(1, "git")
            result = list_theme_versions("theme_a")
            assert result == []

    def test_returns_empty_on_no_tags(self):
        with patch("sum.setup.remote_themes._run_git_command") as mock_git:
            mock_result = MagicMock()
            mock_result.stdout = ""
            mock_git.return_value = mock_result
            result = list_theme_versions("theme_a")
            assert result == []

    def test_returns_versions_sorted_newest_first(self):
        with patch("sum.setup.remote_themes._run_git_command") as mock_git:
            mock_result = MagicMock()
            mock_result.stdout = (
                "abc123\trefs/tags/theme_a/v1.0.0\n"
                "def456\trefs/tags/theme_a/v2.0.0\n"
                "ghi789\trefs/tags/theme_a/v1.5.0\n"
            )
            mock_git.return_value = mock_result
            result = list_theme_versions("theme_a")
            assert result == ["2.0.0", "1.5.0", "1.0.0"]

    def test_validates_slug(self):
        with pytest.raises(ThemeNotFoundError, match="Invalid theme slug"):
            list_theme_versions("../invalid")


class TestListRemoteThemes:
    """Test listing remote themes."""

    def test_returns_empty_on_error(self):
        from subprocess import CalledProcessError

        with patch("sum.setup.remote_themes._run_git_command") as mock_git:
            mock_git.side_effect = CalledProcessError(1, "git")
            result = list_remote_themes()
            assert result == []

    def test_extracts_unique_slugs(self):
        with patch("sum.setup.remote_themes._run_git_command") as mock_git:
            mock_result = MagicMock()
            mock_result.stdout = (
                "abc123\trefs/tags/theme_a/v1.0.0\n"
                "def456\trefs/tags/theme_a/v2.0.0\n"
                "ghi789\trefs/tags/theme_b/v1.0.0\n"
            )
            mock_git.return_value = mock_result
            result = list_remote_themes()
            assert result == ["theme_a", "theme_b"]

    def test_returns_sorted(self):
        with patch("sum.setup.remote_themes._run_git_command") as mock_git:
            mock_result = MagicMock()
            mock_result.stdout = (
                "abc123\trefs/tags/zebra/v1.0.0\n" "def456\trefs/tags/alpha/v1.0.0\n"
            )
            mock_git.return_value = mock_result
            result = list_remote_themes()
            assert result == ["alpha", "zebra"]


class TestReadThemeLockfile:
    """Test reading theme lockfile."""

    def test_returns_none_when_missing(self, tmp_path):
        result = read_theme_lockfile(tmp_path)
        assert result is None

    def test_reads_basic_lockfile(self, tmp_path):
        sum_dir = tmp_path / ".sum"
        sum_dir.mkdir()
        lockfile = sum_dir / "theme.json"
        lockfile.write_text(
            json.dumps(
                {
                    "theme": "theme_a",
                    "original_version": "1.0.0",
                    "locked_at": "2024-01-01T00:00:00",
                }
            )
        )

        result = read_theme_lockfile(tmp_path)
        assert result is not None
        assert result.theme == "theme_a"
        assert result.original_version == "1.0.0"
        assert result.current_version is None

    def test_reads_updated_lockfile(self, tmp_path):
        sum_dir = tmp_path / ".sum"
        sum_dir.mkdir()
        lockfile = sum_dir / "theme.json"
        lockfile.write_text(
            json.dumps(
                {
                    "theme": "theme_a",
                    "original_version": "1.0.0",
                    "current_version": "1.2.0",
                    "locked_at": "2024-01-01T00:00:00",
                    "updated_at": "2024-02-01T00:00:00",
                    "update_history": [
                        {"version": "1.0.0", "at": "2024-01-01T00:00:00"},
                        {"version": "1.2.0", "at": "2024-02-01T00:00:00"},
                    ],
                }
            )
        )

        result = read_theme_lockfile(tmp_path)
        assert result is not None
        assert result.current_version == "1.2.0"
        assert len(result.update_history) == 2

    def test_returns_none_on_invalid_json(self, tmp_path):
        sum_dir = tmp_path / ".sum"
        sum_dir.mkdir()
        lockfile = sum_dir / "theme.json"
        lockfile.write_text("not json")

        result = read_theme_lockfile(tmp_path)
        assert result is None


class TestInstallTheme:
    """Test theme installation/update function."""

    def test_raises_when_already_at_version(self, tmp_path):
        # Create lockfile indicating current version
        sum_dir = tmp_path / ".sum"
        sum_dir.mkdir()
        lockfile = sum_dir / "theme.json"
        lockfile.write_text(
            json.dumps(
                {
                    "theme": "theme_a",
                    "original_version": "1.0.0",
                    "current_version": "1.0.0",
                    "locked_at": "2024-01-01T00:00:00",
                }
            )
        )

        with pytest.raises(ThemeUpdateError, match="already at version 1.0.0"):
            install_theme(tmp_path, "theme_a", "1.0.0")

    def test_allows_reinstall_with_force(self, tmp_path, monkeypatch):
        # Setup project with theme
        sum_dir = tmp_path / ".sum"
        sum_dir.mkdir()
        lockfile_path = sum_dir / "theme.json"
        lockfile_path.write_text(
            json.dumps(
                {
                    "theme": "theme_a",
                    "original_version": "1.0.0",
                    "current_version": "1.0.0",
                    "locked_at": "2024-01-01T00:00:00",
                }
            )
        )

        # Create mock theme source in cache
        # Cache layout: {cache}/slug/version/slug/
        monkeypatch.setattr(Path, "home", lambda: tmp_path / "home")
        cache_home = tmp_path / "home"
        cache_dir = (
            cache_home
            / ".cache"
            / "sum-platform"
            / "themes"
            / "theme_a"
            / "1.0.0"
            / "theme_a"
        )
        cache_dir.mkdir(parents=True)
        (cache_dir / "theme.json").write_text(
            json.dumps(
                {
                    "slug": "theme_a",
                    "name": "Theme A",
                    "description": "",
                    "version": "1.0.0",
                }
            )
        )
        (cache_dir / "templates" / "theme").mkdir(parents=True)
        (cache_dir / "templates" / "theme" / "base.html").write_text("<html></html>")
        (cache_dir / "static" / "theme_a" / "css").mkdir(parents=True)
        (cache_dir / "static" / "theme_a" / "css" / "main.css").write_text(
            "/* " + "x" * 6000 + " */"
        )

        # Create existing theme directory
        theme_dir = tmp_path / "theme" / "active"
        theme_dir.mkdir(parents=True)
        (theme_dir / "old_file.txt").write_text("old")

        result = install_theme(tmp_path, "theme_a", "1.0.0", force=True)
        assert result == "1.0.0"
        assert not (theme_dir / "old_file.txt").exists()  # Old files removed

    def test_raises_on_downgrade_without_flag(self, tmp_path, monkeypatch):
        # Setup lockfile with current version 2.0.0
        sum_dir = tmp_path / ".sum"
        sum_dir.mkdir()
        lockfile_path = sum_dir / "theme.json"
        lockfile_path.write_text(
            json.dumps(
                {
                    "theme": "theme_a",
                    "original_version": "1.0.0",
                    "current_version": "2.0.0",
                    "locked_at": "2024-01-01T00:00:00",
                }
            )
        )

        # Mock fetch to return a valid theme
        # Cache layout: {cache}/slug/version/slug/
        monkeypatch.setattr(Path, "home", lambda: tmp_path / "home")
        cache_home = tmp_path / "home"
        cache_dir = (
            cache_home
            / ".cache"
            / "sum-platform"
            / "themes"
            / "theme_a"
            / "1.0.0"
            / "theme_a"
        )
        cache_dir.mkdir(parents=True)
        (cache_dir / "theme.json").write_text(
            json.dumps(
                {
                    "slug": "theme_a",
                    "name": "Theme A",
                    "description": "",
                    "version": "1.0.0",
                }
            )
        )
        (cache_dir / "templates" / "theme").mkdir(parents=True)
        (cache_dir / "templates" / "theme" / "base.html").write_text("<html></html>")
        (cache_dir / "static" / "theme_a" / "css").mkdir(parents=True)
        (cache_dir / "static" / "theme_a" / "css" / "main.css").write_text(
            "/* " + "x" * 6000 + " */"
        )

        with pytest.raises(ThemeDowngradeError, match="Cannot downgrade"):
            install_theme(tmp_path, "theme_a", "1.0.0")

    def test_allows_downgrade_with_flag(self, tmp_path, monkeypatch):
        # Setup lockfile with current version 2.0.0
        sum_dir = tmp_path / ".sum"
        sum_dir.mkdir()
        lockfile_path = sum_dir / "theme.json"
        lockfile_path.write_text(
            json.dumps(
                {
                    "theme": "theme_a",
                    "original_version": "1.0.0",
                    "current_version": "2.0.0",
                    "locked_at": "2024-01-01T00:00:00",
                }
            )
        )

        # Mock fetch to return a valid theme
        # Cache layout: {cache}/slug/version/slug/
        monkeypatch.setattr(Path, "home", lambda: tmp_path / "home")
        cache_home = tmp_path / "home"
        cache_dir = (
            cache_home
            / ".cache"
            / "sum-platform"
            / "themes"
            / "theme_a"
            / "1.0.0"
            / "theme_a"
        )
        cache_dir.mkdir(parents=True)
        (cache_dir / "theme.json").write_text(
            json.dumps(
                {
                    "slug": "theme_a",
                    "name": "Theme A",
                    "description": "",
                    "version": "1.0.0",
                }
            )
        )
        (cache_dir / "templates" / "theme").mkdir(parents=True)
        (cache_dir / "templates" / "theme" / "base.html").write_text("<html></html>")
        (cache_dir / "static" / "theme_a" / "css").mkdir(parents=True)
        (cache_dir / "static" / "theme_a" / "css" / "main.css").write_text(
            "/* " + "x" * 6000 + " */"
        )

        # Create existing theme directory
        theme_dir = tmp_path / "theme" / "active"
        theme_dir.mkdir(parents=True)

        result = install_theme(tmp_path, "theme_a", "1.0.0", allow_downgrade=True)
        assert result == "1.0.0"

    def test_rolls_back_on_failure(self, tmp_path, monkeypatch):
        # Setup lockfile
        sum_dir = tmp_path / ".sum"
        sum_dir.mkdir()
        lockfile_path = sum_dir / "theme.json"
        lockfile_path.write_text(
            json.dumps(
                {
                    "theme": "theme_a",
                    "original_version": "1.0.0",
                    "locked_at": "2024-01-01T00:00:00",
                }
            )
        )

        # Create existing theme directory with content
        theme_dir = tmp_path / "theme" / "active"
        theme_dir.mkdir(parents=True)
        (theme_dir / "old_file.txt").write_text("precious content")
        (theme_dir / "theme.json").write_text('{"slug": "theme_a"}')

        # Mock fetch to return a theme that will fail validation (missing base.html)
        # Cache layout: {cache}/slug/version/slug/
        monkeypatch.setattr(Path, "home", lambda: tmp_path / "home")
        cache_home = tmp_path / "home"
        cache_dir = (
            cache_home
            / ".cache"
            / "sum-platform"
            / "themes"
            / "theme_a"
            / "2.0.0"
            / "theme_a"
        )
        cache_dir.mkdir(parents=True)
        (cache_dir / "theme.json").write_text(
            json.dumps(
                {
                    "slug": "theme_a",
                    "name": "Theme A",
                    "description": "",
                    "version": "2.0.0",
                }
            )
        )
        # Deliberately not creating templates/theme/base.html to cause validation failure

        with pytest.raises(ThemeUpdateError, match="validation failed"):
            install_theme(tmp_path, "theme_a", "2.0.0")

        # Verify rollback happened
        assert (theme_dir / "old_file.txt").exists()
        assert (theme_dir / "old_file.txt").read_text() == "precious content"


class TestRunThemeCheck:
    """Test the theme check command function."""

    def test_returns_error_when_no_lockfile(self, tmp_path, monkeypatch):
        (tmp_path / "manage.py").write_text("print('ok')", encoding="utf-8")
        monkeypatch.chdir(tmp_path)
        result = run_theme_check()
        assert result == 1

    def test_returns_success_when_up_to_date(self, tmp_path, monkeypatch, capsys):
        # Setup lockfile
        (tmp_path / "manage.py").write_text("print('ok')", encoding="utf-8")
        sum_dir = tmp_path / ".sum"
        sum_dir.mkdir()
        lockfile = sum_dir / "theme.json"
        lockfile.write_text(
            json.dumps(
                {
                    "theme": "theme_a",
                    "original_version": "1.0.0",
                    "locked_at": "2024-01-01T00:00:00",
                }
            )
        )
        monkeypatch.chdir(tmp_path)

        with patch("sum.commands.theme.get_latest_theme_tag", return_value="1.0.0"):
            result = run_theme_check()

        assert result == 0
        captured = capsys.readouterr()
        assert "Up to date" in captured.out

    def test_returns_success_when_update_available(self, tmp_path, monkeypatch, capsys):
        # Setup lockfile
        (tmp_path / "manage.py").write_text("print('ok')", encoding="utf-8")
        sum_dir = tmp_path / ".sum"
        sum_dir.mkdir()
        lockfile = sum_dir / "theme.json"
        lockfile.write_text(
            json.dumps(
                {
                    "theme": "theme_a",
                    "original_version": "1.0.0",
                    "locked_at": "2024-01-01T00:00:00",
                }
            )
        )
        monkeypatch.chdir(tmp_path)

        with patch("sum.commands.theme.get_latest_theme_tag", return_value="2.0.0"):
            result = run_theme_check()

        assert result == 0
        captured = capsys.readouterr()
        assert "Update available" in captured.out

    def test_resolves_lockfile_from_site_root(self, tmp_path, monkeypatch):
        site_root = tmp_path / "acme"
        app_dir = site_root / "app"
        (app_dir / ".sum").mkdir(parents=True)
        (app_dir / "manage.py").write_text("print('ok')", encoding="utf-8")
        lockfile = app_dir / ".sum" / "theme.json"
        lockfile.write_text(
            json.dumps(
                {
                    "theme": "theme_a",
                    "original_version": "1.0.0",
                    "locked_at": "2024-01-01T00:00:00",
                }
            )
        )
        monkeypatch.chdir(site_root)

        with patch("sum.commands.theme.get_latest_theme_tag", return_value="1.0.0"):
            result = run_theme_check()

        assert result == 0


class TestRunThemeVersions:
    """Test the theme versions command function."""

    def test_returns_error_when_no_versions(self, capsys):
        with patch("sum.commands.theme.list_theme_versions", return_value=[]):
            result = run_theme_versions("nonexistent")

        assert result == 1
        captured = capsys.readouterr()
        assert "No versions found" in captured.out

    def test_shows_versions(self, capsys):
        with patch(
            "sum.commands.theme.list_theme_versions",
            return_value=["2.0.0", "1.5.0", "1.0.0"],
        ):
            result = run_theme_versions("theme_a")

        assert result == 0
        captured = capsys.readouterr()
        assert "2.0.0 (latest)" in captured.out
        assert "1.5.0" in captured.out
        assert "1.0.0" in captured.out

    def test_shows_current_version_from_site_root(
        self, tmp_path, monkeypatch, capsys
    ) -> None:
        site_root = tmp_path / "acme"
        app_dir = site_root / "app"
        (app_dir / ".sum").mkdir(parents=True)
        (app_dir / "manage.py").write_text("print('ok')", encoding="utf-8")
        (app_dir / ".sum" / "theme.json").write_text(
            json.dumps(
                {
                    "theme": "theme_a",
                    "original_version": "1.0.0",
                    "current_version": "1.5.0",
                    "locked_at": "2024-01-01T00:00:00",
                }
            )
        )
        monkeypatch.chdir(site_root)

        with patch(
            "sum.commands.theme.list_theme_versions",
            return_value=["2.0.0", "1.5.0", "1.0.0"],
        ):
            result = run_theme_versions("theme_a")

        assert result == 0
        captured = capsys.readouterr()
        assert "You have: 1.5.0" in captured.out


class TestRunThemeList:
    """Test the theme list command function."""

    def test_lists_local_themes(self, tmp_path, monkeypatch, capsys):
        # Create local theme
        theme_dir = tmp_path / "themes" / "test_theme"
        theme_dir.mkdir(parents=True)
        (theme_dir / "theme.json").write_text(
            json.dumps(
                {
                    "slug": "test_theme",
                    "name": "Test Theme",
                    "description": "A test theme",
                    "version": "1.0.0",
                }
            )
        )
        monkeypatch.chdir(tmp_path)

        result = run_theme_list(remote=False)

        assert result == 0
        captured = capsys.readouterr()
        assert "test_theme" in captured.out
        assert "Test Theme" in captured.out

    def test_lists_remote_themes(self, capsys):
        with patch(
            "sum.commands.theme.list_remote_themes_with_versions",
            return_value={"theme_a": "1.0.0", "theme_b": "1.0.0"},
        ):
            result = run_theme_list(remote=True)

        assert result == 0
        captured = capsys.readouterr()
        assert "theme_a" in captured.out
        assert "theme_b" in captured.out
        assert "Remote themes" in captured.out


class TestRunThemeUpdate:
    """Test the theme update command function."""

    def test_returns_error_when_no_lockfile(self, tmp_path, monkeypatch):
        (tmp_path / "manage.py").write_text("print('ok')", encoding="utf-8")
        monkeypatch.chdir(tmp_path)
        result = run_theme_update()
        assert result == 1

    def test_returns_error_when_no_network(self, tmp_path, monkeypatch):
        (tmp_path / "manage.py").write_text("print('ok')", encoding="utf-8")
        # Setup lockfile
        sum_dir = tmp_path / ".sum"
        sum_dir.mkdir()
        lockfile = sum_dir / "theme.json"
        lockfile.write_text(
            json.dumps(
                {
                    "theme": "theme_a",
                    "original_version": "1.0.0",
                    "locked_at": "2024-01-01T00:00:00",
                }
            )
        )
        monkeypatch.chdir(tmp_path)

        with patch("sum.commands.theme.get_latest_theme_tag", return_value=None):
            result = run_theme_update()

        assert result == 1

    def test_uses_app_dir_when_run_from_site_root(self, tmp_path, monkeypatch) -> None:
        site_root = tmp_path / "acme"
        app_dir = site_root / "app"
        (app_dir / ".sum").mkdir(parents=True)
        (app_dir / "manage.py").write_text("print('ok')", encoding="utf-8")
        (app_dir / ".sum" / "theme.json").write_text(
            json.dumps(
                {
                    "theme": "theme_a",
                    "original_version": "1.0.0",
                    "locked_at": "2024-01-01T00:00:00",
                }
            )
        )
        monkeypatch.chdir(site_root)

        with (
            patch("sum.commands.theme.get_latest_theme_tag", return_value="2.0.0"),
            patch("sum.commands.theme.install_theme", return_value="2.0.0") as install,
        ):
            result = run_theme_update()

        assert result == 0
        install.assert_called_once_with(
            app_dir,
            "theme_a",
            "2.0.0",
            allow_downgrade=False,
            force=False,
        )
