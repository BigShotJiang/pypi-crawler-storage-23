# pyright: reportMissingImports=false, reportPrivateUsage=false, reportUnknownMemberType=false, reportUnknownParameterType=false, reportMissingParameterType=false, reportUnknownVariableType=false, reportUnusedCallResult=false, reportUnknownArgumentType=false, reportMissingModuleSource=false

"""Tests for privilege escalation utilities."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from sum.utils.privilege import (
    detect_gitea_token,
    escalate_with_sudo,
    find_cli_executable,
    get_preserved_env_vars,
    is_root,
    require_root_or_escalate,
)


class TestIsRoot:
    """Test root detection."""

    def test_is_root_returns_true_for_uid_0(self):
        """is_root returns True when euid is 0."""
        with patch("os.geteuid", return_value=0):
            assert is_root() is True

    def test_is_root_returns_false_for_non_root(self):
        """is_root returns False when euid is not 0."""
        with patch("os.geteuid", return_value=1000):
            assert is_root() is False


class TestFindCliExecutable:
    """Test CLI executable discovery."""

    def test_finds_from_sys_argv_if_absolute(self, tmp_path):
        """Finds CLI from sys.argv[0] when it's an absolute path."""
        fake_cli = tmp_path / "sum-platform"
        fake_cli.write_text("#!/bin/bash\necho test")

        with patch.object(sys, "argv", [str(fake_cli), "init"]):
            result = find_cli_executable()
            assert result == str(fake_cli.resolve())

    def test_finds_from_which(self):
        """Falls back to 'which' command."""
        with patch.object(sys, "argv", ["sum-platform", "init"]):
            with patch("shutil.which", return_value="/usr/local/bin/sum-platform"):
                result = find_cli_executable()
                assert result == "/usr/local/bin/sum-platform"

    def test_finds_from_pipx_location(self, tmp_path, monkeypatch):
        """Falls back to common pipx location."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        pipx_path = tmp_path / ".local" / "bin" / "sum-platform"
        pipx_path.parent.mkdir(parents=True)
        pipx_path.write_text("#!/bin/bash\necho test")

        with patch.object(sys, "argv", ["sum-platform", "init"]):
            with patch("shutil.which", return_value=None):
                result = find_cli_executable()
                assert result == str(pipx_path)

    def test_returns_none_when_not_found(self, tmp_path, monkeypatch):
        """Returns None when executable cannot be found."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        # Mock sys.executable to a location without sum-platform
        fake_python = tmp_path / "fake" / "bin" / "python"

        with patch.object(sys, "argv", ["sum-platform", "init"]):
            with patch("shutil.which", return_value=None):
                with patch.object(sys, "executable", str(fake_python)):
                    result = find_cli_executable()
                    assert result is None


class TestGetPreservedEnvVars:
    """Test environment variable preservation."""

    def test_auto_preserves_sum_prefixed_vars(self, monkeypatch):
        """Auto-preserves all SUM_* prefixed vars."""
        monkeypatch.setenv("SUM_THEME_PATH", "/themes")
        monkeypatch.setenv("SUM_CUSTOM_VAR", "value")
        monkeypatch.setenv("SUM_ANYTHING", "test")

        result = get_preserved_env_vars()

        assert "SUM_THEME_PATH" in result
        assert "SUM_CUSTOM_VAR" in result
        assert "SUM_ANYTHING" in result

    def test_preserves_default_git_tokens(self, monkeypatch):
        """Preserves GITEA_TOKEN and GITHUB_TOKEN by default."""
        monkeypatch.setenv("GITEA_TOKEN", "secret")
        monkeypatch.setenv("GITHUB_TOKEN", "ghp_xxx")

        result = get_preserved_env_vars()

        assert "GITEA_TOKEN" in result
        assert "GITHUB_TOKEN" in result

    def test_does_not_forward_arbitrary_token_vars(self, monkeypatch):
        """Does NOT forward arbitrary *_TOKEN vars like AWS_SESSION_TOKEN."""
        monkeypatch.setenv("AWS_SESSION_TOKEN", "sensitive")
        monkeypatch.setenv("CUSTOM_TOKEN", "abc123")

        result = get_preserved_env_vars()

        assert "AWS_SESSION_TOKEN" not in result
        assert "CUSTOM_TOKEN" not in result

    def test_forwards_explicit_token_env(self, monkeypatch):
        """Forwards a specific token var when passed via token_env."""
        monkeypatch.setenv("MY_GITEA_TOKEN", "my_secret")

        result = get_preserved_env_vars(token_env="MY_GITEA_TOKEN")

        assert "MY_GITEA_TOKEN" in result

    def test_preserves_essential_system_vars(self, monkeypatch):
        """Preserves PATH, HOME, and other essential vars when set."""
        monkeypatch.setenv("PATH", "/usr/bin")
        monkeypatch.setenv("HOME", "/home/user")
        monkeypatch.setenv("VIRTUAL_ENV", "/venv")

        result = get_preserved_env_vars()

        assert "PATH" in result
        assert "HOME" in result
        assert "VIRTUAL_ENV" in result

    def test_does_not_preserve_unset_vars(self, monkeypatch):
        """Does not include vars that aren't set."""
        monkeypatch.delenv("SUM_NONEXISTENT", raising=False)

        result = get_preserved_env_vars()

        assert "SUM_NONEXISTENT" not in result

    def test_sum_prefixed_token_included(self, monkeypatch):
        """SUM_* prefix overrides token exclusion (boundary test)."""
        monkeypatch.setenv("SUM_AWS_TOKEN", "value")

        result = get_preserved_env_vars()

        # SUM_ prefix should include it despite being a *_TOKEN var
        assert "SUM_AWS_TOKEN" in result


class TestEscalateWithSudo:
    """Test sudo escalation."""

    def test_returns_error_when_cli_not_found(self):
        """Returns error code when CLI executable not found."""
        with patch("sum.utils.privilege.find_cli_executable", return_value=None):
            result = escalate_with_sudo(["init", "mysite"])
            assert result == 1

    def test_runs_sudo_with_preserve_env(self, monkeypatch):
        """Runs sudo with --preserve-env for env vars (no values in args)."""
        monkeypatch.setenv("SUM_THEME_PATH", "/themes")

        mock_run = MagicMock()
        mock_run.return_value.returncode = 0

        with patch(
            "sum.utils.privilege.find_cli_executable",
            return_value="/usr/bin/sum-platform",
        ):
            with patch("subprocess.run", mock_run):
                result = escalate_with_sudo(["init", "mysite"])

                assert result == 0
                mock_run.assert_called_once()
                cmd = mock_run.call_args[0][0]
                assert cmd[0] == "sudo"
                # Env vars preserved via --preserve-env flag, not VAR=value in args
                preserve_args = [a for a in cmd if a.startswith("--preserve-env=")]
                assert len(preserve_args) == 1
                assert "SUM_THEME_PATH" in preserve_args[0]
                # Values must NOT appear in command args
                assert "/themes" not in str(cmd)
                assert "/usr/bin/sum-platform" in cmd
                assert "init" in cmd
                assert "mysite" in cmd

    def test_returns_subprocess_exit_code(self):
        """Returns the exit code from the subprocess."""
        mock_run = MagicMock()
        mock_run.return_value.returncode = 42

        with patch(
            "sum.utils.privilege.find_cli_executable",
            return_value="/usr/bin/sum-platform",
        ):
            with patch("subprocess.run", mock_run):
                result = escalate_with_sudo(["init"])
                assert result == 42


class TestRequireRootOrEscalate:
    """Test the require_root_or_escalate helper."""

    def test_returns_true_when_root(self):
        """Returns True when already running as root."""
        with patch("sum.utils.privilege.is_root", return_value=True):
            result = require_root_or_escalate("init")
            assert result is True

    def test_escalates_when_not_root(self):
        """Calls sys.exit with escalation result when not root."""
        with patch("sum.utils.privilege.is_root", return_value=False):
            with patch("sum.utils.privilege.escalate_with_sudo", return_value=0):
                with pytest.raises(SystemExit) as exc_info:
                    require_root_or_escalate("init")
                assert exc_info.value.code == 0

    def test_exits_with_error_on_escalation_failure(self):
        """Exits with error code when escalation fails."""
        with patch("sum.utils.privilege.is_root", return_value=False):
            with patch("sum.utils.privilege.escalate_with_sudo", return_value=1):
                with pytest.raises(SystemExit) as exc_info:
                    require_root_or_escalate("init")
                assert exc_info.value.code == 1


class TestDetectGiteaToken:
    """Test GITEA_TOKEN detection from environment and tea config."""

    def test_returns_token_from_environment(self, monkeypatch):
        """Returns token when present in environment."""
        monkeypatch.setenv("GITEA_TOKEN", "env-token-123")
        assert detect_gitea_token() == "env-token-123"

    def test_returns_token_from_custom_env_var(self, monkeypatch):
        """Returns token from a custom-named env var."""
        monkeypatch.setenv("MY_GITEA_TOKEN", "custom-token")
        assert detect_gitea_token(env_var="MY_GITEA_TOKEN") == "custom-token"

    def test_env_takes_precedence_over_tea_config(self, monkeypatch, tmp_path):
        """Environment variable takes precedence over tea config."""
        monkeypatch.setenv("GITEA_TOKEN", "env-token")

        tea_config = tmp_path / "config.yml"
        tea_config.write_text("logins:\n  - token: tea-token\n")

        result = detect_gitea_token(tea_config_path=tea_config)
        assert result == "env-token"

    def test_reads_token_from_tea_config(self, monkeypatch, tmp_path):
        """Falls back to tea config when env var is not set."""
        monkeypatch.delenv("GITEA_TOKEN", raising=False)

        tea_config = tmp_path / "config.yml"
        tea_config.write_text(
            "logins:\n"
            "  - name: gitea.example.com\n"
            "    url: https://gitea.example.com\n"
            "    token: tea-config-token-456\n"
        )

        result = detect_gitea_token(tea_config_path=tea_config)
        assert result == "tea-config-token-456"

    def test_injects_tea_token_into_env(self, monkeypatch, tmp_path):
        """When token is found in tea config, it's set in os.environ."""
        monkeypatch.delenv("GITEA_TOKEN", raising=False)

        tea_config = tmp_path / "config.yml"
        tea_config.write_text("logins:\n  - token: injected-token\n")

        detect_gitea_token(tea_config_path=tea_config)
        assert os.environ.get("GITEA_TOKEN") == "injected-token"

    def test_injects_into_custom_env_var(self, monkeypatch, tmp_path):
        """Injects tea config token into the custom env var name."""
        monkeypatch.delenv("MY_TOKEN", raising=False)

        tea_config = tmp_path / "config.yml"
        tea_config.write_text("logins:\n  - token: my-token\n")

        detect_gitea_token(env_var="MY_TOKEN", tea_config_path=tea_config)
        assert os.environ.get("MY_TOKEN") == "my-token"

    def test_returns_none_when_nothing_found(self, monkeypatch, tmp_path):
        """Returns None when token is not in env or tea config."""
        monkeypatch.delenv("GITEA_TOKEN", raising=False)

        # Point to non-existent config
        tea_config = tmp_path / "nonexistent" / "config.yml"
        result = detect_gitea_token(tea_config_path=tea_config)
        assert result is None

    def test_returns_none_for_empty_tea_config(self, monkeypatch, tmp_path):
        """Returns None when tea config exists but has no tokens."""
        monkeypatch.delenv("GITEA_TOKEN", raising=False)

        tea_config = tmp_path / "config.yml"
        tea_config.write_text("logins: []\n")

        result = detect_gitea_token(tea_config_path=tea_config)
        assert result is None

    def test_returns_none_for_invalid_yaml(self, monkeypatch, tmp_path):
        """Returns None when tea config is malformed YAML."""
        monkeypatch.delenv("GITEA_TOKEN", raising=False)

        tea_config = tmp_path / "config.yml"
        tea_config.write_text("{{invalid yaml: [")

        result = detect_gitea_token(tea_config_path=tea_config)
        assert result is None

    def test_returns_none_for_non_dict_yaml(self, monkeypatch, tmp_path):
        """Returns None when tea config YAML root is not a dict."""
        monkeypatch.delenv("GITEA_TOKEN", raising=False)

        tea_config = tmp_path / "config.yml"
        tea_config.write_text("- just\n- a\n- list\n")

        result = detect_gitea_token(tea_config_path=tea_config)
        assert result is None

    def test_skips_logins_without_token(self, monkeypatch, tmp_path):
        """Skips login entries that don't have a token field."""
        monkeypatch.delenv("GITEA_TOKEN", raising=False)

        tea_config = tmp_path / "config.yml"
        tea_config.write_text(
            "logins:\n"
            "  - name: no-token-server\n"
            "    url: https://gitea.example.com\n"
            "  - name: has-token\n"
            "    token: found-it\n"
        )

        result = detect_gitea_token(tea_config_path=tea_config)
        assert result == "found-it"

    def test_default_tea_config_path(self, monkeypatch, tmp_path):
        """Uses ~/.config/tea/config.yml by default."""
        monkeypatch.delenv("GITEA_TOKEN", raising=False)
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        tea_dir = tmp_path / ".config" / "tea"
        tea_dir.mkdir(parents=True)
        (tea_dir / "config.yml").write_text("logins:\n  - token: default-path-token\n")

        result = detect_gitea_token()
        assert result == "default-path-token"
