"""Tests for bare metal PostgreSQL provisioning."""

from __future__ import annotations

from pathlib import Path
from subprocess import CalledProcessError
from unittest.mock import MagicMock, patch

import pytest
from sum.exceptions import SetupError
from sum.setup.bare_metal_postgres import (
    _SAFE_PATH_RE,
    DEFAULT_PGBACKREST_WRAPPER,
    _configure_wal_archiving,
    _create_database_and_user,
    _create_postgres_cluster,
    _generate_pgbackrest_stanza_config,
    _init_pgbackrest_stanza,
    _is_port_conflict_error,
    _run_initial_backup,
    _safe_decode,
    _start_cluster,
    _verify_backup_ssh_key,
    _wait_for_postgres,
    cleanup_bare_metal_postgres,
    cleanup_pgbackrest_remote_state,
    install_pgbackrest_wrapper,
    setup_bare_metal_postgres,
    stop_bare_metal_postgres,
)
from sum.setup.infrastructure import SiteCredentials
from sum.system_config import (
    AgencyConfig,
    AlertsConfig,
    BackupsConfig,
    DefaultsConfig,
    ProductionConfig,
    RetentionConfig,
    StagingConfig,
    StorageBoxConfig,
    SystemConfig,
    TemplatesConfig,
    reset_system_config,
)


@pytest.fixture(autouse=True)
def reset_config():
    """Reset config singleton before and after each test."""
    reset_system_config()
    yield
    reset_system_config()


@pytest.fixture
def test_credentials():
    """Test database credentials."""
    return SiteCredentials(
        db_name="sum_testsite",
        db_user="sum_testsite_user",
        db_password="testpassword123",
        django_secret_key="testsecretkey",
        superuser_username="admin",
        superuser_email="admin@test.com",
        superuser_password="adminpass",
    )


@pytest.fixture
def test_config_with_backups(tmp_path):
    """System config with backups configured."""
    # Create mock SSH key file
    ssh_key = tmp_path / "backup-key-rsa"
    ssh_key.write_text("mock ssh private key")

    # Create mock cipher passphrase file
    cipher_pass_file = tmp_path / "cipher-passphrase"
    cipher_pass_file.write_text("DUMMY-TEST-PASSPHRASE-NOT-REAL")

    # Create mock template files
    templates_dir = tmp_path / "templates"
    templates_dir.mkdir()
    (templates_dir / "pgbackrest").mkdir()

    # Mock pgbackrest stanza template
    (templates_dir / "pgbackrest" / "stanza.conf.template").write_text(
        "[__SITE_SLUG__]\n"
        "pg1-path=/var/lib/postgresql/__POSTGRES_VERSION__/__SITE_SLUG__\n"
        "pg1-port=__POSTGRES_PORT__\n"
        "repo1-sftp-host=__STORAGE_BOX_HOST__"
    )

    return SystemConfig(
        agency=AgencyConfig(name="testco"),
        staging=StagingConfig(
            server="staging",
            domain_pattern="{slug}.staging.test",
            base_dir=str(tmp_path),
        ),
        production=ProductionConfig(
            server="prod",
            ssh_host="10.0.0.1",
            base_dir="/srv/prod",
        ),
        templates=TemplatesConfig(
            dir=str(templates_dir),
            systemd="systemd/test.service",
            caddy="caddy/test.caddy",
            pgbackrest_stanza="pgbackrest/stanza.conf.template",
        ),
        defaults=DefaultsConfig(
            theme="theme_a",
            deploy_user="deploy",
            seed_profile="sage-stone",
        ),
        backups=BackupsConfig(
            storage_box=StorageBoxConfig(
                host="backup.example.com",
                user="u12345",
                fingerprint="abc123def456",
                ssh_key=str(ssh_key),
            ),
            retention=RetentionConfig(full_backups=2, diff_backups=7),
            alerts=AlertsConfig(email="alerts@example.com"),
            cipher_pass_file=str(cipher_pass_file),
        ),
    )


@pytest.fixture
def test_config_no_backups(tmp_path):
    """System config without backups."""
    return SystemConfig(
        agency=AgencyConfig(name="testco"),
        staging=StagingConfig(
            server="staging",
            domain_pattern="{slug}.staging.test",
            base_dir=str(tmp_path),
        ),
        production=ProductionConfig(
            server="prod",
            ssh_host="10.0.0.1",
            base_dir="/srv/prod",
        ),
        templates=TemplatesConfig(
            dir="/opt/infra",
            systemd="systemd/test.service",
            caddy="caddy/test.caddy",
        ),
        defaults=DefaultsConfig(
            theme="theme_a",
            deploy_user="deploy",
            seed_profile="sage-stone",
        ),
    )


class TestSafeDecode:
    """Tests for _safe_decode helper (binary-safe pgBackRest output decoding)."""

    def test_decodes_valid_utf8(self):
        assert _safe_decode(b"hello world") == "hello world"

    def test_replaces_invalid_bytes(self):
        # 0x8f is not a valid UTF-8 start byte
        data = b"error at pos \x8f end"
        result = _safe_decode(data)
        assert "error at pos" in result
        assert "end" in result
        assert "\ufffd" in result  # replacement character

    def test_handles_none(self):
        assert _safe_decode(None) == ""

    def test_passes_through_str(self):
        assert _safe_decode("already a string") == "already a string"


class TestPgbackrestBinaryOutput:
    """Regression test: pgBackRest subprocess calls handle binary output."""

    def test_stanza_init_binary_stderr(self, test_config_with_backups):
        """_init_pgbackrest_stanza handles binary output in CalledProcessError."""
        with patch("subprocess.run") as mock_run:
            exc = CalledProcessError(1, "pgbackrest")
            exc.stdout = b"WAL data \x8f\x90\x91 compressed"
            exc.stderr = b""
            mock_run.side_effect = exc
            with pytest.raises(
                SetupError, match="Failed to initialize pgBackRest stanza"
            ):
                _init_pgbackrest_stanza("testsite", test_config_with_backups)

    def test_initial_backup_binary_stderr(self, test_config_with_backups):
        """_run_initial_backup handles binary output in CalledProcessError."""
        with patch("subprocess.run") as mock_run:
            exc = CalledProcessError(1, "pgbackrest")
            exc.stdout = b"\x00\x01\x02 binary garbage"
            exc.stderr = b""
            mock_run.side_effect = exc
            with pytest.raises(SetupError, match="Failed to run initial backup"):
                _run_initial_backup("testsite", test_config_with_backups)


class TestCreatePostgresCluster:
    """Tests for pg_createcluster."""

    def test_calls_pg_createcluster(self):
        """Calls pg_createcluster with correct arguments."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            _create_postgres_cluster("testsite", 5433, "18")

            mock_run.assert_called_once()
            call_args = mock_run.call_args[0][0]
            assert "pg_createcluster" in call_args
            assert "18" in call_args
            assert "testsite" in call_args
            assert "-p" in call_args
            assert "5433" in call_args
            assert "--start-conf=auto" in call_args

    def test_raises_on_failure(self):
        """Raises SetupError on pg_createcluster failure."""
        with patch("subprocess.run") as mock_run:
            mock_run.side_effect = CalledProcessError(
                1, "pg_createcluster", stderr="error"
            )
            with pytest.raises(SetupError, match="Failed to create PostgreSQL cluster"):
                _create_postgres_cluster("testsite", 5433, "18")


class TestConfigureWalArchiving:
    """Tests for WAL archiving configuration."""

    def test_adds_wal_config_to_postgresql_conf(self, tmp_path):
        """Calls _configure_wal_archiving() and asserts correct output."""
        # Create mock postgresql.conf at expected path
        conf_dir = tmp_path / "etc" / "postgresql" / "18" / "testsite"
        conf_dir.mkdir(parents=True)
        conf_file = conf_dir / "postgresql.conf"
        conf_file.write_text("# Original config\n")

        # Mock config with pgbackrest config dir
        pgbackrest_conf_dir = tmp_path / "etc" / "pgbackrest" / "conf.d"
        pgbackrest_conf_dir.mkdir(parents=True)
        mock_config = MagicMock()
        mock_config.get_pgbackrest_config_dir.return_value = pgbackrest_conf_dir

        with patch(
            "sum.setup.bare_metal_postgres.Path",
            side_effect=lambda x: (
                tmp_path / x.lstrip("/")
                if x.startswith("/etc/postgresql/")
                else Path(x)
            ),
        ):
            _configure_wal_archiving("testsite", "18", mock_config)

        final_content = conf_file.read_text()
        assert "wal_level = replica" in final_content
        assert "archive_mode = on" in final_content
        assert DEFAULT_PGBACKREST_WRAPPER in final_content
        assert "--config-include-path=" in final_content
        assert "--stanza=testsite" in final_content
        assert "archive-push %p" in final_content


class TestStartCluster:
    """Tests for cluster start."""

    def test_calls_pg_ctlcluster_start(self):
        """Calls pg_ctlcluster start with correct arguments."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            _start_cluster("testsite", "18")

            mock_run.assert_called_once()
            call_args = mock_run.call_args[0][0]
            assert "pg_ctlcluster" in call_args
            assert "18" in call_args
            assert "testsite" in call_args
            assert "start" in call_args

    def test_raises_on_failure(self):
        """Raises SetupError on pg_ctlcluster failure."""
        with patch("subprocess.run") as mock_run:
            mock_run.side_effect = CalledProcessError(
                1, "pg_ctlcluster", stderr="error"
            )
            with pytest.raises(SetupError, match="Failed to start PostgreSQL cluster"):
                _start_cluster("testsite", "18")


class TestWaitForPostgres:
    """Tests for postgres readiness check."""

    def test_uses_pg_isready(self):
        """Uses pg_isready with port argument."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            _wait_for_postgres(5433)

            call_args = mock_run.call_args[0][0]
            assert "pg_isready" in call_args
            assert "-p" in call_args
            assert "5433" in call_args

    def test_retries_until_ready(self):
        """Retries pg_isready until Postgres is ready."""
        with patch("subprocess.run") as mock_run, patch("time.sleep"):
            # Fail twice, then succeed
            mock_run.side_effect = [
                MagicMock(returncode=1),
                MagicMock(returncode=1),
                MagicMock(returncode=0),
            ]
            _wait_for_postgres(5433, timeout=10)

            assert mock_run.call_count == 3

    def test_raises_on_timeout(self):
        """Raises SetupError if Postgres doesn't become ready."""
        with (
            patch("subprocess.run") as mock_run,
            patch("time.sleep"),
            patch("time.time") as mock_time,
        ):
            # Simulate timeout
            mock_time.side_effect = [0, 0, 5, 10, 15]  # Exceed timeout
            mock_run.return_value.returncode = 1
            with pytest.raises(SetupError, match="did not become ready"):
                _wait_for_postgres(5433, timeout=10)


class TestCreateDatabaseAndUser:
    """Tests for database/user creation (SEC-01: psql -v stdin)."""

    def test_creates_user_and_database(self, test_credentials):
        """Creates user with password and database via psql -v stdin."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            _create_database_and_user("testsite", 5433, test_credentials)

            # Should be called twice: once for user, once for database
            assert mock_run.call_count == 2

            for call in mock_run.call_args_list:
                cmd = call[0][0]
                assert "sudo" in cmd
                assert "-u" in cmd
                assert "postgres" in cmd
                assert "psql" in cmd
                assert "-p" in cmd
                # Must use -v variable bindings, not -c
                assert "-v" in cmd
                assert "-c" not in cmd
                # Must use input= keyword (SQL via stdin)
                assert "input" in call[1]

    def test_password_not_in_command_args(self, test_credentials):
        """SEC-01: Password must not be visible in command arguments."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            _create_database_and_user("testsite", 5433, test_credentials)

            for call in mock_run.call_args_list:
                cmd = call[0][0]
                cmd_str = " ".join(str(c) for c in cmd)
                # SQL should be in stdin, not in command args
                assert "CREATE USER" not in cmd_str
                assert "CREATE DATABASE" not in cmd_str

    def test_raises_on_failure(self, test_credentials):
        """Raises SetupError on psql failure."""
        with patch("subprocess.run") as mock_run:
            mock_run.side_effect = CalledProcessError(1, "psql", stderr="error")
            with pytest.raises(SetupError, match="Failed to create database/user"):
                _create_database_and_user("testsite", 5433, test_credentials)


class TestVerifyBackupSshKey:
    """Tests for SSH key verification."""

    def test_succeeds_when_key_exists(self, test_config_with_backups):
        """Succeeds when SSH key exists."""
        # Should not raise
        _verify_backup_ssh_key(test_config_with_backups)

    def test_raises_when_key_missing(self, test_config_with_backups):
        """Raises SetupError when SSH key doesn't exist."""
        # Remove the SSH key
        ssh_key_path = Path(test_config_with_backups.backups.storage_box.ssh_key)
        ssh_key_path.unlink()

        with pytest.raises(SetupError, match="SSH key not found"):
            _verify_backup_ssh_key(test_config_with_backups)

    def test_skips_when_no_backups(self, test_config_no_backups):
        """Skips verification when backups not configured."""
        # Should not raise
        _verify_backup_ssh_key(test_config_no_backups)


class TestInstallPgbackrestWrapper:
    """Tests for pgbackrest wrapper script installation."""

    def test_creates_wrapper_script(self, tmp_path):
        """Wrapper script is created with correct content."""
        wrapper = tmp_path / "pgbackrest-wrapper"
        with patch("subprocess.run"):
            install_pgbackrest_wrapper(
                "/etc/sum/cipher-passphrase", wrapper_path=str(wrapper)
            )
        assert wrapper.exists()
        content = wrapper.read_text()
        assert content.startswith("#!/bin/sh\n")
        assert "PGBACKREST_REPO1_CIPHER_PASS" in content
        assert "/etc/sum/cipher-passphrase" in content
        assert 'exec /usr/bin/pgbackrest "$@"' in content
        # Uses shell built-in read, not cat
        assert "read -r PGBACKREST_REPO1_CIPHER_PASS" in content
        # Has readability guard
        assert 'test -r "$PASS_FILE"' in content
        # Single-line note in script comments
        assert "single line" in content

    def test_wrapper_is_750_root_postgres(self, tmp_path):
        """Wrapper script has 750 permissions and chown root:postgres."""
        wrapper = tmp_path / "pgbackrest-wrapper"
        with patch("subprocess.run") as mock_run:
            install_pgbackrest_wrapper(
                "/etc/sum/cipher-passphrase", wrapper_path=str(wrapper)
            )
        assert wrapper.stat().st_mode & 0o777 == 0o750
        # Verify chown was called with root:postgres
        chown_calls = [c for c in mock_run.call_args_list if "chown" in str(c)]
        assert len(chown_calls) == 1
        assert "root:postgres" in str(chown_calls[0])

    def test_wrapper_does_not_contain_passphrase(self, tmp_path):
        """Wrapper must not contain the actual passphrase, only the file path."""
        wrapper = tmp_path / "pgbackrest-wrapper"
        with patch("subprocess.run"):
            install_pgbackrest_wrapper(
                "/etc/sum/cipher-passphrase", wrapper_path=str(wrapper)
            )
        content = wrapper.read_text()
        # Should reference the file path, not contain a hardcoded passphrase
        assert "/etc/sum/cipher-passphrase" in content

    def test_atomic_write_no_temp_file_left(self, tmp_path):
        """Atomic write via os.replace — no .tmp file left after success."""
        wrapper = tmp_path / "pgbackrest-wrapper"
        with patch("subprocess.run"):
            install_pgbackrest_wrapper(
                "/etc/sum/cipher-passphrase", wrapper_path=str(wrapper)
            )
        assert wrapper.exists()
        assert not wrapper.with_suffix(".tmp").exists()


class TestGeneratePgbackrestStanzaConfig:
    """Tests for pgBackRest stanza config generation."""

    def test_creates_stanza_config(
        self, tmp_path, test_credentials, test_config_with_backups
    ):
        """Creates stanza config file."""
        # Create a real stanza dir in tmp_path
        stanza_dir = tmp_path / "pgbackrest" / "conf.d"
        stanza_dir.mkdir(parents=True)

        with (
            patch("subprocess.run") as mock_run,
            patch.object(
                test_config_with_backups,
                "get_pgbackrest_config_dir",
                return_value=stanza_dir,
            ),
        ):
            mock_run.return_value.returncode = 0

            _generate_pgbackrest_stanza_config(
                "testsite", 5433, test_credentials, test_config_with_backups
            )

        # Verify stanza file was created
        stanza_file = stanza_dir / "testsite.conf"
        assert stanza_file.exists()
        # Cipher passphrase must NOT appear in stanza config
        content = stanza_file.read_text()
        assert "cipher-pass" not in content.lower()
        assert "DUMMY-TEST-PASSPHRASE-NOT-REAL" not in content

    def test_skips_when_no_backups(self, test_credentials, test_config_no_backups):
        """Skips generation when backups not configured."""
        with patch("subprocess.run") as mock_run:
            _generate_pgbackrest_stanza_config(
                "testsite", 5433, test_credentials, test_config_no_backups
            )
            # Should not call subprocess for chown
            mock_run.assert_not_called()


class TestInitPgbackrestStanza:
    """Tests for stanza initialization."""

    def test_runs_stanza_create(self, test_config_with_backups):
        """Runs pgbackrest stanza-create via wrapper as postgres user."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            _init_pgbackrest_stanza("testsite", test_config_with_backups)

            call_args = mock_run.call_args[0][0]
            assert "sudo" in call_args
            assert "-u" in call_args
            assert "postgres" in call_args
            assert "pgbackrest-wrapper" in " ".join(call_args)
            assert "--stanza" in call_args
            assert "testsite" in call_args
            assert "stanza-create" in call_args

    def test_raises_on_failure(self, test_config_with_backups):
        """Raises SetupError on stanza-create failure."""
        with patch("subprocess.run") as mock_run:
            exc = CalledProcessError(1, "pgbackrest")
            exc.stdout = "error message"
            exc.stderr = ""
            mock_run.side_effect = exc
            with pytest.raises(
                SetupError, match="Failed to initialize pgBackRest stanza"
            ):
                _init_pgbackrest_stanza("testsite", test_config_with_backups)


class TestRunInitialBackup:
    """Tests for initial backup."""

    def test_runs_full_backup(self, test_config_with_backups):
        """Runs pgbackrest backup --type=full via wrapper as postgres user."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            _run_initial_backup("testsite", test_config_with_backups)

            call_args = mock_run.call_args[0][0]
            assert "sudo" in call_args
            assert "-u" in call_args
            assert "postgres" in call_args
            assert "pgbackrest-wrapper" in " ".join(call_args)
            assert "--stanza" in call_args
            assert "testsite" in call_args
            assert "--type=full" in call_args
            assert "backup" in call_args

    def test_raises_on_failure(self, test_config_with_backups):
        """Raises SetupError on backup failure."""
        with patch("subprocess.run") as mock_run:
            exc = CalledProcessError(1, "pgbackrest")
            exc.stdout = "error message"
            exc.stderr = ""
            mock_run.side_effect = exc
            with pytest.raises(SetupError, match="Failed to run initial backup"):
                _run_initial_backup("testsite", test_config_with_backups)


class TestStopBareMetalPostgres:
    """Tests for stopping clusters."""

    def test_calls_pg_ctlcluster_stop(self):
        """Calls pg_ctlcluster stop."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            stop_bare_metal_postgres("testsite", "18")

            call_args = mock_run.call_args[0][0]
            assert "pg_ctlcluster" in call_args
            assert "18" in call_args
            assert "testsite" in call_args
            assert "stop" in call_args


class TestCleanupBareMetalPostgres:
    """Tests for complete cluster cleanup."""

    def test_stops_and_drops_cluster(self):
        """Stops cluster and drops it with pg_dropcluster."""
        with (
            patch("subprocess.run") as mock_run,
            patch("sum.setup.bare_metal_postgres.deallocate_port"),
            patch("sum.setup.bare_metal_postgres.Path") as mock_path,
        ):
            mock_run.return_value.returncode = 0
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = False
            mock_path.return_value = mock_path_instance

            cleanup_bare_metal_postgres("testsite", "18")

            # Should call pg_ctlcluster stop and pg_dropcluster
            calls = [c[0][0] for c in mock_run.call_args_list]
            stop_call = [c for c in calls if "pg_ctlcluster" in c and "stop" in c]
            drop_call = [c for c in calls if "pg_dropcluster" in c]
            assert len(stop_call) == 1
            assert len(drop_call) == 1

    def test_deallocates_port(self):
        """Deallocates port after cleanup."""
        with (
            patch("subprocess.run") as mock_run,
            patch("sum.setup.bare_metal_postgres.deallocate_port") as mock_dealloc,
            patch("sum.setup.bare_metal_postgres.Path") as mock_path,
        ):
            mock_run.return_value.returncode = 0
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = False
            mock_path.return_value = mock_path_instance

            cleanup_bare_metal_postgres("testsite", "18")

            mock_dealloc.assert_called_once_with("testsite", None)

    def test_removes_stanza_config(self, tmp_path):
        """Removes pgBackRest stanza config file."""
        stanza_file = tmp_path / "testsite.conf"
        stanza_file.write_text("stanza config")

        mock_config = MagicMock()
        mock_config.get_pgbackrest_config_dir.return_value = tmp_path

        with (
            patch("subprocess.run") as mock_run,
            patch("sum.setup.bare_metal_postgres.deallocate_port"),
        ):
            mock_run.return_value.returncode = 0

            cleanup_bare_metal_postgres("testsite", "18", config=mock_config)

            # Stanza file should be removed
            assert not stanza_file.exists()


class TestSetupBareMetalPostgres:
    """Integration tests for full setup flow."""

    def test_allocates_port(self, test_credentials, test_config_no_backups):
        """Allocates a port for the cluster."""
        with (
            patch("subprocess.run") as mock_run,
            patch("sum.setup.bare_metal_postgres.allocate_port") as mock_alloc,
            patch("sum.setup.bare_metal_postgres.cleanup_bare_metal_postgres"),
        ):
            mock_run.return_value.returncode = 0
            mock_alloc.return_value = 5433

            port = setup_bare_metal_postgres(
                "testsite", test_credentials, test_config_no_backups
            )

            mock_alloc.assert_called_once_with("testsite", test_config_no_backups)
            assert port == 5433

    def test_cleans_up_on_failure(self, test_credentials, test_config_no_backups):
        """Cleans up on setup failure."""
        with (
            patch("subprocess.run") as mock_run,
            patch("sum.setup.bare_metal_postgres.allocate_port") as mock_alloc,
            patch(
                "sum.setup.bare_metal_postgres.cleanup_bare_metal_postgres"
            ) as mock_cleanup,
        ):
            mock_alloc.return_value = 5433
            mock_run.side_effect = CalledProcessError(
                1, "pg_createcluster", stderr="error"
            )

            with pytest.raises(SetupError):
                setup_bare_metal_postgres(
                    "testsite", test_credentials, test_config_no_backups
                )

            mock_cleanup.assert_called_once_with(
                "testsite", "18", test_config_no_backups
            )


class TestCleanupPgbackrestRemoteState:
    """Tests for pgBackRest remote state cleanup."""

    def test_stops_stanza_and_deletes(self, test_config_with_backups):
        """Runs pgbackrest stop then stanza-delete --force."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            cleanup_pgbackrest_remote_state("testsite", test_config_with_backups)

            assert mock_run.call_count == 2

            # First call: stop stanza
            stop_call = mock_run.call_args_list[0][0][0]
            assert "pgbackrest-wrapper" in " ".join(stop_call)
            assert "stop" in stop_call
            assert "testsite" in stop_call

            # Second call: stanza-delete --force
            delete_call = mock_run.call_args_list[1][0][0]
            assert "pgbackrest-wrapper" in " ".join(delete_call)
            assert "stanza-delete" in delete_call
            assert "--force" in delete_call
            assert "testsite" in delete_call

    def test_runs_as_postgres_user(self, test_config_with_backups):
        """Commands run as postgres user via sudo."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            cleanup_pgbackrest_remote_state("testsite", test_config_with_backups)

            for call_args in mock_run.call_args_list:
                cmd = call_args[0][0]
                assert cmd[0] == "sudo"
                assert "-u" in cmd
                assert "postgres" in cmd

    def test_includes_config_include_path(self, test_config_with_backups):
        """Passes --config-include-path from system config."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            cleanup_pgbackrest_remote_state("testsite", test_config_with_backups)

            for call_args in mock_run.call_args_list:
                cmd = call_args[0][0]
                config_path_args = [
                    a for a in cmd if a.startswith("--config-include-path=")
                ]
                assert len(config_path_args) == 1

    def test_best_effort_on_stop_failure(self, test_config_with_backups):
        """Continues with stanza-delete even if stop fails."""
        call_count = 0

        def side_effect(cmd, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise OSError("stop failed")
            return MagicMock(returncode=0)

        with patch("subprocess.run", side_effect=side_effect):
            # Should not raise
            cleanup_pgbackrest_remote_state("testsite", test_config_with_backups)

        assert call_count == 2  # Both stop and delete were attempted

    def test_best_effort_on_delete_failure(self, test_config_with_backups):
        """Does not raise if stanza-delete fails."""
        call_count = 0

        def side_effect(cmd, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                raise OSError("delete failed")
            return MagicMock(returncode=0)

        with patch("subprocess.run", side_effect=side_effect):
            # Should not raise (best-effort)
            cleanup_pgbackrest_remote_state("testsite", test_config_with_backups)

    def test_warns_on_nonzero_delete_returncode(self, test_config_with_backups, capsys):
        """Warns when stanza-delete exits non-zero instead of printing success."""
        call_count = 0

        def side_effect(cmd, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                # stanza-delete returns non-zero
                return MagicMock(returncode=1, stderr="stanza does not exist")
            return MagicMock(returncode=0)

        with patch("subprocess.run", side_effect=side_effect):
            cleanup_pgbackrest_remote_state("testsite", test_config_with_backups)

        captured = capsys.readouterr()
        assert "stanza-delete returned 1" in captured.out
        # Should NOT print success message
        assert "Cleaned up pgBackRest stanza metadata" not in captured.out

    def test_uses_default_path_without_config(self):
        """Uses default pgbackrest config path when no config."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            cleanup_pgbackrest_remote_state("testsite", config=None)

            cmd = mock_run.call_args_list[0][0][0]
            config_path_arg = [
                a for a in cmd if a.startswith("--config-include-path=")
            ][0]
            assert "/etc/pgbackrest/conf.d" in config_path_arg

    def test_strict_raises_on_nonzero_returncode(self, test_config_with_backups):
        """strict=True raises SetupError when stanza-delete exits non-zero."""
        call_count = 0

        def side_effect(cmd, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                return MagicMock(returncode=1, stderr="remote unreachable")
            return MagicMock(returncode=0)

        with patch("subprocess.run", side_effect=side_effect):
            with pytest.raises(SetupError, match="stanza-delete returned 1"):
                cleanup_pgbackrest_remote_state(
                    "testsite", test_config_with_backups, strict=True
                )

    def test_strict_raises_on_subprocess_error(self, test_config_with_backups):
        """strict=True raises SetupError when stanza-delete throws OSError."""
        call_count = 0

        def side_effect(cmd, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                raise OSError("wrapper not found")
            return MagicMock(returncode=0)

        with patch("subprocess.run", side_effect=side_effect):
            with pytest.raises(SetupError, match="wrapper not found"):
                cleanup_pgbackrest_remote_state(
                    "testsite", test_config_with_backups, strict=True
                )

    def test_strict_false_remains_best_effort(self, test_config_with_backups):
        """strict=False (default) does not raise on failure."""
        call_count = 0

        def side_effect(cmd, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                return MagicMock(returncode=1, stderr="remote unreachable")
            return MagicMock(returncode=0)

        with patch("subprocess.run", side_effect=side_effect):
            # Should NOT raise
            cleanup_pgbackrest_remote_state(
                "testsite", test_config_with_backups, strict=False
            )

    def test_error_includes_stdout_when_stderr_empty(self, test_config_with_backups):
        """Error message falls back to stdout when stderr is empty."""
        call_count = 0

        def side_effect(cmd, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 2:
                return MagicMock(
                    returncode=1, stderr="", stdout="P00  ERROR: repo missing"
                )
            return MagicMock(returncode=0)

        with patch("subprocess.run", side_effect=side_effect):
            with pytest.raises(SetupError, match="repo missing"):
                cleanup_pgbackrest_remote_state(
                    "testsite", test_config_with_backups, strict=True
                )


class TestCleanupBareMetalPostgresPurgeParam:
    """Tests for the purge_remote_backups parameter."""

    def test_purge_true_calls_remote_cleanup(self, test_config_with_backups):
        """purge_remote_backups=True calls cleanup_pgbackrest_remote_state."""
        with (
            patch("subprocess.run") as mock_run,
            patch("sum.setup.bare_metal_postgres.deallocate_port"),
            patch(
                "sum.setup.bare_metal_postgres.cleanup_pgbackrest_remote_state"
            ) as mock_remote,
        ):
            mock_run.return_value.returncode = 0
            cleanup_bare_metal_postgres(
                "testsite",
                "18",
                config=test_config_with_backups,
                purge_remote_backups=True,
            )

            mock_remote.assert_called_once_with(
                "testsite", test_config_with_backups, strict=False
            )

    def test_purge_false_skips_remote_cleanup(self, test_config_with_backups):
        """purge_remote_backups=False does NOT call cleanup_pgbackrest_remote_state."""
        with (
            patch("subprocess.run") as mock_run,
            patch("sum.setup.bare_metal_postgres.deallocate_port"),
            patch(
                "sum.setup.bare_metal_postgres.cleanup_pgbackrest_remote_state"
            ) as mock_remote,
        ):
            mock_run.return_value.returncode = 0
            cleanup_bare_metal_postgres(
                "testsite",
                "18",
                config=test_config_with_backups,
                purge_remote_backups=False,
            )

            mock_remote.assert_not_called()

    def test_purge_default_true(self, test_config_with_backups):
        """Default purge_remote_backups is True (for failed-init safety)."""
        with (
            patch("subprocess.run") as mock_run,
            patch("sum.setup.bare_metal_postgres.deallocate_port"),
            patch(
                "sum.setup.bare_metal_postgres.cleanup_pgbackrest_remote_state"
            ) as mock_remote,
        ):
            mock_run.return_value.returncode = 0
            # Call without explicit purge_remote_backups (should default to True)
            cleanup_bare_metal_postgres(
                "testsite", "18", config=test_config_with_backups
            )

            mock_remote.assert_called_once()

    def test_strict_purge_passes_strict_to_remote_cleanup(
        self, test_config_with_backups
    ):
        """strict_purge=True passes strict=True to cleanup_pgbackrest_remote_state."""
        with (
            patch("subprocess.run") as mock_run,
            patch("sum.setup.bare_metal_postgres.deallocate_port"),
            patch(
                "sum.setup.bare_metal_postgres.cleanup_pgbackrest_remote_state"
            ) as mock_remote,
        ):
            mock_run.return_value.returncode = 0
            cleanup_bare_metal_postgres(
                "testsite",
                "18",
                config=test_config_with_backups,
                purge_remote_backups=True,
                strict_purge=True,
            )

            mock_remote.assert_called_once_with(
                "testsite", test_config_with_backups, strict=True
            )

    def test_strict_purge_default_false(self, test_config_with_backups):
        """Default strict_purge is False (best-effort for failed-init retry)."""
        with (
            patch("subprocess.run") as mock_run,
            patch("sum.setup.bare_metal_postgres.deallocate_port"),
            patch(
                "sum.setup.bare_metal_postgres.cleanup_pgbackrest_remote_state"
            ) as mock_remote,
        ):
            mock_run.return_value.returncode = 0
            cleanup_bare_metal_postgres(
                "testsite",
                "18",
                config=test_config_with_backups,
                purge_remote_backups=True,
            )

            mock_remote.assert_called_once_with(
                "testsite", test_config_with_backups, strict=False
            )

    def test_purge_skipped_without_backups_config(self, test_config_no_backups):
        """Remote cleanup is skipped when backups are not configured."""
        with (
            patch("subprocess.run") as mock_run,
            patch("sum.setup.bare_metal_postgres.deallocate_port"),
            patch("sum.setup.bare_metal_postgres.Path") as mock_path,
            patch(
                "sum.setup.bare_metal_postgres.cleanup_pgbackrest_remote_state"
            ) as mock_remote,
        ):
            mock_run.return_value.returncode = 0
            mock_path_instance = MagicMock()
            mock_path_instance.exists.return_value = False
            mock_path.return_value = mock_path_instance

            cleanup_bare_metal_postgres(
                "testsite",
                "18",
                config=test_config_no_backups,
                purge_remote_backups=True,
            )

            # Should not call remote cleanup even with purge=True
            # because config.backups is None
            mock_remote.assert_not_called()

    def test_strict_purge_failure_deferred_until_after_local_cleanup(
        self, test_config_with_backups
    ):
        """Remote purge failure is deferred so local cleanup still runs."""
        with (
            patch("subprocess.run") as mock_run,
            patch("sum.setup.bare_metal_postgres.deallocate_port") as mock_dealloc,
            patch(
                "sum.setup.bare_metal_postgres.cleanup_pgbackrest_remote_state",
                side_effect=SetupError("SFTP unreachable"),
            ),
        ):
            mock_run.return_value.returncode = 0

            with pytest.raises(SetupError, match="SFTP unreachable"):
                cleanup_bare_metal_postgres(
                    "testsite",
                    "18",
                    config=test_config_with_backups,
                    purge_remote_backups=True,
                    strict_purge=True,
                )

            # Local cleanup must have run despite remote failure
            # pg_dropcluster was called (after the pg_ctlcluster stop call)
            drop_calls = [
                c for c in mock_run.call_args_list if "pg_dropcluster" in c[0][0]
            ]
            assert len(drop_calls) == 1
            # Port was deallocated
            mock_dealloc.assert_called_once()

    def test_strict_purge_failure_does_not_suppress_other_errors(
        self, test_config_with_backups
    ):
        """Deferred purge error is raised even if local cleanup also warns."""

        def run_side_effect(cmd, *args, **kwargs):
            if "pg_dropcluster" in cmd:
                from subprocess import CalledProcessError

                raise CalledProcessError(1, cmd, stderr="cluster not found")
            result = MagicMock()
            result.returncode = 0
            return result

        with (
            patch("subprocess.run", side_effect=run_side_effect),
            patch("sum.setup.bare_metal_postgres.deallocate_port"),
            patch(
                "sum.setup.bare_metal_postgres.cleanup_pgbackrest_remote_state",
                side_effect=SetupError("cipher passphrase missing"),
            ),
        ):
            with pytest.raises(SetupError, match="cipher passphrase missing"):
                cleanup_bare_metal_postgres(
                    "testsite",
                    "18",
                    config=test_config_with_backups,
                    purge_remote_backups=True,
                    strict_purge=True,
                )


class TestSafePathRegex:
    """SEC-10: _SAFE_PATH_RE rejects shell metacharacters in paths."""

    @pytest.mark.parametrize(
        "path",
        [
            "/etc/pgbackrest/conf.d",
            "/var/lib/pgbackrest",
            "/opt/pg-backup/conf.d",
            "/home/user/.config/pgbackrest",
        ],
    )
    def test_accepts_safe_paths(self, path: str) -> None:
        assert _SAFE_PATH_RE.match(path)

    @pytest.mark.parametrize(
        "path",
        [
            "/etc/pgbackrest; rm -rf /",
            "/tmp/$(whoami)",
            "/tmp/`id`",
            "/path with spaces",
            "/path'quoted",
            '/path"double',
            "/path&background",
            "/path|pipe",
        ],
    )
    def test_rejects_unsafe_paths(self, path: str) -> None:
        assert not _SAFE_PATH_RE.match(path)


class TestWaitForPostgresFileNotFound:
    """H-20: _wait_for_postgres raises SetupError on FileNotFoundError."""

    def test_raises_setup_error_on_file_not_found(self) -> None:
        """FileNotFoundError for missing pg_isready gives clear message."""
        with patch("subprocess.run") as mock_run:
            mock_run.side_effect = FileNotFoundError("pg_isready")

            with pytest.raises(SetupError, match="pg_isready not found"):
                _wait_for_postgres(5433, timeout=1)


class TestSqlInjectionPrevention:
    """SQL injection prevention for database/user creation."""

    def test_malicious_slug_rejected_before_sql(self):
        """Malicious SQL identifier should be rejected by validation."""
        from sum.setup.bare_metal_postgres import _validate_sql_identifier

        with pytest.raises(SetupError, match="Invalid db_name"):
            _validate_sql_identifier("test; DROP TABLE users--", "db_name")

    def test_sql_injection_via_credentials_blocked(self, test_credentials):
        """Malicious identifiers in credentials are rejected."""
        from sum.setup.bare_metal_postgres import _validate_sql_identifier

        # Test various SQL injection attempts
        malicious_names = [
            "test'; DROP TABLE users--",
            "test; DELETE FROM pg_database--",
            'test"; SELECT * FROM pg_shadow--',
            "test$(whoami)",
        ]

        for name in malicious_names:
            with pytest.raises(SetupError):
                _validate_sql_identifier(name, "db_name")

    def test_subprocess_never_called_with_bad_identifier(self, test_credentials):
        """_create_database_and_user rejects bad identifiers before subprocess."""
        # Create malicious credentials
        bad_creds = SiteCredentials(
            db_name="test; DROP TABLE users--",
            db_user="sum_testsite_user",
            db_password="testpassword123",
            django_secret_key="testsecretkey",
            superuser_username="admin",
            superuser_email="admin@test.com",
            superuser_password="adminpass",
        )

        with patch("subprocess.run") as mock_run:
            with pytest.raises(SetupError):
                _create_database_and_user("testsite", 5433, bad_creds)

            # Subprocess should NEVER be called
            mock_run.assert_not_called()


class TestIsPortConflictError:
    """Tests for port conflict error detection."""

    def test_detects_port_already_in_use(self):
        """Detects pg_createcluster 'port already in use' error."""
        exc = SetupError(
            "Failed to create PostgreSQL cluster:\nport 5433 already in use"
        )
        assert _is_port_conflict_error(exc) is True

    def test_detects_port_in_use(self):
        """Detects 'port in use' variant."""
        exc = SetupError("port 5433 is in use by another process")
        assert _is_port_conflict_error(exc) is True

    def test_ignores_unrelated_errors(self):
        """Returns False for non-port-related errors."""
        exc = SetupError("permission denied: cannot create cluster")
        assert _is_port_conflict_error(exc) is False

    def test_ignores_partial_match(self):
        """Returns False when only 'port' matches but not 'in use'/'already'."""
        exc = SetupError("invalid port number specified")
        assert _is_port_conflict_error(exc) is False


class TestPortRetryOnConflict:
    """Tests for retry logic when pg_createcluster fails with port conflict."""

    def test_port_retry_on_conflict(self, test_credentials, test_config_no_backups):
        """Retries with next port when pg_createcluster fails with port conflict."""
        call_count = 0

        def mock_subprocess_run(cmd, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            if isinstance(cmd, list) and "pg_createcluster" in cmd:
                # First pg_createcluster call fails with port conflict
                if call_count == 1:
                    raise CalledProcessError(
                        1,
                        "pg_createcluster",
                        stderr="Error: port 5433 already in use",
                    )
                # Second pg_createcluster call succeeds
                return MagicMock(returncode=0)
            # All other subprocess calls succeed
            return MagicMock(returncode=0)

        with (
            patch("subprocess.run", side_effect=mock_subprocess_run),
            patch("sum.setup.bare_metal_postgres.allocate_port") as mock_alloc,
            patch("sum.setup.bare_metal_postgres.deallocate_port") as mock_dealloc,
            patch("sum.setup.bare_metal_postgres.cleanup_bare_metal_postgres"),
        ):
            # First allocation returns 5433, second returns 5434
            mock_alloc.side_effect = [5433, 5434]

            port = setup_bare_metal_postgres(
                "testsite", test_credentials, test_config_no_backups
            )

            # Should have deallocated the conflicting port
            mock_dealloc.assert_called_once_with("testsite", test_config_no_backups)
            # Should have allocated twice (original + retry)
            assert mock_alloc.call_count == 2
            # Should return the retry port
            assert port == 5434

    def test_no_retry_on_non_port_error(self, test_credentials, test_config_no_backups):
        """Does NOT retry when pg_createcluster fails with a non-port error."""
        with (
            patch("subprocess.run") as mock_run,
            patch("sum.setup.bare_metal_postgres.allocate_port") as mock_alloc,
            patch("sum.setup.bare_metal_postgres.deallocate_port") as mock_dealloc,
            patch("sum.setup.bare_metal_postgres.cleanup_bare_metal_postgres"),
        ):
            mock_alloc.return_value = 5433
            mock_run.side_effect = CalledProcessError(
                1, "pg_createcluster", stderr="permission denied"
            )

            with pytest.raises(SetupError):
                setup_bare_metal_postgres(
                    "testsite", test_credentials, test_config_no_backups
                )

            # Should NOT have deallocated (no retry)
            mock_dealloc.assert_not_called()
