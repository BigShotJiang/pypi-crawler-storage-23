"""Tests for the destroy command.

Tests cover:
- Basic destroy flow with confirmation
- Force flag bypassing confirmation
- Purge backups flag with extra confirmation
- Non-existent site handling
- Partial cleanup on errors
- Edge cases (keyboard interrupt, mismatched confirmation)
- Integration with cleanup_bare_metal_postgres
"""

from __future__ import annotations

from importlib import import_module
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from sum.commands.destroy import DestroyError, run_destroy
from sum.system_config import (
    AgencyConfig,
    AlertsConfig,
    BackupsConfig,
    DefaultsConfig,
    InfrastructureConfig,
    ProductionConfig,
    RetentionConfig,
    StagingConfig,
    StorageBoxConfig,
    SystemConfig,
    TemplatesConfig,
    reset_system_config,
)

destroy_module = import_module("sum.commands.destroy")


@pytest.fixture(autouse=True)
def mock_privilege_escalation(monkeypatch):
    """Mock privilege escalation to always succeed for tests."""
    monkeypatch.setattr(destroy_module, "require_root_or_escalate", lambda cmd: True)


@pytest.fixture(autouse=True)
def reset_config():
    """Reset config singleton before and after each test."""
    reset_system_config()
    yield
    reset_system_config()


@pytest.fixture
def mock_system_config(monkeypatch, tmp_path):
    """Mock system config with temp directories."""
    config = SystemConfig(
        agency=AgencyConfig(name="testco"),
        staging=StagingConfig(
            server="test-staging",
            domain_pattern="{slug}.test.site",
            base_dir=str(tmp_path / "srv" / "sum"),
        ),
        production=ProductionConfig(
            server="test-prod",
            ssh_host="192.168.1.1",
            base_dir="/srv/prod",
        ),
        templates=TemplatesConfig(
            dir="/opt/infra",
            systemd="systemd/test.service",
            caddy="caddy/test.caddy",
        ),
        defaults=DefaultsConfig(
            theme="theme_a",
            deploy_user="deploy",
            seed_profile="sage-stone",
        ),
    )

    monkeypatch.setattr(destroy_module, "get_system_config", lambda: config)
    return config


@pytest.fixture
def mock_system_config_with_backups(monkeypatch, tmp_path):
    """Mock system config with backup infrastructure."""
    ssh_key = tmp_path / "backup-key-rsa"
    ssh_key.write_text("mock ssh key")

    config = SystemConfig(
        agency=AgencyConfig(name="testco"),
        staging=StagingConfig(
            server="test-staging",
            domain_pattern="{slug}.test.site",
            base_dir=str(tmp_path / "srv" / "sum"),
        ),
        production=ProductionConfig(
            server="test-prod",
            ssh_host="192.168.1.1",
            base_dir="/srv/prod",
        ),
        templates=TemplatesConfig(
            dir="/opt/infra",
            systemd="systemd/test.service",
            caddy="caddy/test.caddy",
        ),
        defaults=DefaultsConfig(
            theme="theme_a",
            deploy_user="deploy",
            seed_profile="sage-stone",
        ),
        infrastructure=InfrastructureConfig(postgres_version="17"),
        backups=BackupsConfig(
            storage_box=StorageBoxConfig(
                host="backup.example.com",
                user="u12345",
                fingerprint="abc123",
                ssh_key=str(ssh_key),
            ),
            retention=RetentionConfig(full_backups=2, diff_backups=7),
            alerts=AlertsConfig(email="alerts@example.com"),
        ),
    )

    monkeypatch.setattr(destroy_module, "get_system_config", lambda: config)
    return config


def _create_site_dir(config: SystemConfig, slug: str) -> Path:
    """Helper: create a minimal site directory structure for testing."""
    site_dir = config.get_site_dir(slug)
    site_dir.mkdir(parents=True, exist_ok=True)
    (site_dir / "app").mkdir(exist_ok=True)
    (site_dir / "static").mkdir(exist_ok=True)
    (site_dir / "media").mkdir(exist_ok=True)
    (site_dir / ".env").write_text("DJANGO_SECRET_KEY=test")
    return site_dir


class TestDestroyValidation:
    """Tests for pre-destroy validation."""

    def test_destroy_nonexistent_site_fails(self, mock_system_config, capsys):
        """Destroy fails with clear error for non-existent site."""
        result = run_destroy("nonexistent", force=True)
        assert result == 1

        captured = capsys.readouterr()
        assert "does not exist" in captured.out
        assert "nonexistent" in captured.out

    def test_destroy_error_inherits_setup_error(self):
        """DestroyError is a subclass of SetupError."""
        from sum.exceptions import SetupError

        assert issubclass(DestroyError, SetupError)


class TestDestroyConfirmation:
    """Tests for confirmation prompt behavior."""

    def test_destroy_prompts_for_confirmation(
        self, monkeypatch, mock_system_config, tmp_path
    ):
        """Destroy prompts user to type the slug to confirm."""
        _create_site_dir(mock_system_config, "acme")

        # User types wrong slug
        monkeypatch.setattr("builtins.input", lambda _: "wrong-slug")

        with patch("subprocess.run"):
            result = run_destroy("acme")

        assert result == 1

    def test_destroy_correct_confirmation_proceeds(
        self, monkeypatch, mock_system_config, tmp_path
    ):
        """Destroy proceeds when user types correct slug."""
        site_dir = _create_site_dir(mock_system_config, "acme")

        monkeypatch.setattr("builtins.input", lambda _: "acme")

        with (
            patch("subprocess.run"),
            patch.object(destroy_module, "get_site_port", return_value=None),
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            result = run_destroy("acme")

        assert result == 0
        assert not site_dir.exists()

    def test_destroy_force_skips_confirmation(self, mock_system_config, tmp_path):
        """--force skips confirmation prompt entirely."""
        site_dir = _create_site_dir(mock_system_config, "acme")

        with (
            patch("subprocess.run"),
            patch.object(destroy_module, "get_site_port", return_value=None),
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            result = run_destroy("acme", force=True)

        assert result == 0
        assert not site_dir.exists()

    def test_destroy_keyboard_interrupt_aborts(
        self, monkeypatch, mock_system_config, tmp_path
    ):
        """Ctrl+C during confirmation aborts gracefully."""
        _create_site_dir(mock_system_config, "acme")

        monkeypatch.setattr(
            "builtins.input", lambda _: (_ for _ in ()).throw(KeyboardInterrupt)
        )

        result = run_destroy("acme")
        assert result == 130

    def test_destroy_eof_aborts(self, monkeypatch, mock_system_config, tmp_path):
        """EOF during confirmation aborts gracefully."""
        _create_site_dir(mock_system_config, "acme")

        monkeypatch.setattr("builtins.input", lambda _: (_ for _ in ()).throw(EOFError))

        result = run_destroy("acme")
        assert result == 130


class TestDestroyPurgeBackups:
    """Tests for --purge-backups flag."""

    def test_purge_backups_requires_extra_confirmation(
        self, monkeypatch, mock_system_config_with_backups, tmp_path
    ):
        """--purge-backups requires typing 'DELETE BACKUPS'."""
        _create_site_dir(mock_system_config_with_backups, "acme")

        # First prompt: slug confirmation succeeds
        # Second prompt: backup deletion fails
        inputs = iter(["acme", "no"])
        monkeypatch.setattr("builtins.input", lambda _: next(inputs))

        result = run_destroy("acme", purge_backups=True)
        assert result == 1

    def test_purge_backups_correct_confirmation_proceeds(
        self, monkeypatch, mock_system_config_with_backups, tmp_path
    ):
        """Correct backup purge confirmation proceeds with deletion."""
        _create_site_dir(mock_system_config_with_backups, "acme")

        inputs = iter(["acme", "DELETE BACKUPS"])
        monkeypatch.setattr("builtins.input", lambda _: next(inputs))

        with (
            patch("subprocess.run"),
            patch.object(destroy_module, "get_site_port", return_value=5433),
            patch.object(destroy_module, "cleanup_bare_metal_postgres") as mock_cleanup,
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            result = run_destroy("acme", purge_backups=True)

        assert result == 0
        # cleanup_bare_metal_postgres should be called with purge flags
        mock_cleanup.assert_called_once()
        _, kwargs = mock_cleanup.call_args
        assert kwargs["purge_remote_backups"] is True
        assert kwargs["strict_purge"] is True

    def test_purge_backups_force_skips_both_confirmations(
        self, mock_system_config_with_backups, tmp_path
    ):
        """--force --purge-backups skips all confirmations."""
        _create_site_dir(mock_system_config_with_backups, "acme")

        with (
            patch("subprocess.run"),
            patch.object(destroy_module, "get_site_port", return_value=5433),
            patch.object(destroy_module, "cleanup_bare_metal_postgres") as mock_cleanup,
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            result = run_destroy("acme", force=True, purge_backups=True)

        assert result == 0
        mock_cleanup.assert_called_once()
        _, kwargs = mock_cleanup.call_args
        assert kwargs["purge_remote_backups"] is True
        assert kwargs["strict_purge"] is True


class TestDestroyManagedCluster:
    """Tests for destroying sites with managed PostgreSQL clusters."""

    def test_calls_cleanup_bare_metal_postgres(self, mock_system_config, tmp_path):
        """Uses cleanup_bare_metal_postgres for managed clusters."""
        _create_site_dir(mock_system_config, "acme")

        with (
            patch("subprocess.run"),
            patch.object(destroy_module, "get_site_port", return_value=5433),
            patch.object(destroy_module, "cleanup_bare_metal_postgres") as mock_cleanup,
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            result = run_destroy("acme", force=True)

        assert result == 0
        mock_cleanup.assert_called_once_with(
            "acme",
            "18",
            mock_system_config,
            purge_remote_backups=False,
            strict_purge=False,
        )

    def test_uses_config_postgres_version(
        self, mock_system_config_with_backups, tmp_path
    ):
        """Uses PostgreSQL version from infrastructure config."""
        _create_site_dir(mock_system_config_with_backups, "acme")

        with (
            patch("subprocess.run"),
            patch.object(destroy_module, "get_site_port", return_value=5433),
            patch.object(destroy_module, "cleanup_bare_metal_postgres") as mock_cleanup,
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            result = run_destroy("acme", force=True)

        assert result == 0
        # Should use version "17" from mock_system_config_with_backups
        args, kwargs = mock_cleanup.call_args
        assert args[1] == "17"

    def test_no_managed_cluster_drops_system_db(self, mock_system_config, tmp_path):
        """Falls back to system postgres when no managed cluster."""
        _create_site_dir(mock_system_config, "acme")

        with (
            patch("subprocess.run") as mock_run,
            patch.object(destroy_module, "get_site_port", return_value=None),
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            mock_run.return_value.returncode = 0
            result = run_destroy("acme", force=True)

        assert result == 0
        # Should have called psql to drop database
        psql_calls = [
            c
            for c in mock_run.call_args_list
            if any("psql" in str(arg) for arg in c[0][0])
        ]
        assert len(psql_calls) >= 1


class TestDestroySystemdCleanup:
    """Tests for systemd service cleanup during destroy."""

    def test_stops_systemd_service(self, mock_system_config, tmp_path):
        """Stops the systemd service."""
        _create_site_dir(mock_system_config, "acme")

        with (
            patch("subprocess.run") as mock_run,
            patch.object(destroy_module, "get_site_port", return_value=None),
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            mock_run.return_value.returncode = 0
            result = run_destroy("acme", force=True)

        assert result == 0

        # Find the systemctl stop call
        systemctl_calls = [
            c[0][0]
            for c in mock_run.call_args_list
            if "systemctl" in c[0][0] and "stop" in c[0][0]
        ]
        assert len(systemctl_calls) == 1
        assert "sum-acme-gunicorn" in systemctl_calls[0]

    def test_disables_and_removes_service(self, mock_system_config, tmp_path):
        """Disables service and removes service file."""
        _create_site_dir(mock_system_config, "acme")

        with (
            patch("subprocess.run") as mock_run,
            patch.object(destroy_module, "get_site_port", return_value=None),
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            mock_run.return_value.returncode = 0
            result = run_destroy("acme", force=True)

        assert result == 0

        # Find the systemctl disable call
        disable_calls = [
            c[0][0]
            for c in mock_run.call_args_list
            if "systemctl" in c[0][0] and "disable" in c[0][0]
        ]
        assert len(disable_calls) == 1

        # Find the daemon-reload call
        reload_calls = [
            c[0][0]
            for c in mock_run.call_args_list
            if "systemctl" in c[0][0] and "daemon-reload" in c[0][0]
        ]
        assert len(reload_calls) >= 1


class TestDestroyCaddyCleanup:
    """Tests for Caddy config cleanup during destroy."""

    def test_reloads_caddy_after_removal(self, mock_system_config, tmp_path):
        """Reloads Caddy after removing site config."""
        _create_site_dir(mock_system_config, "acme")

        with (
            patch("subprocess.run") as mock_run,
            patch.object(destroy_module, "get_site_port", return_value=None),
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            mock_run.return_value.returncode = 0
            result = run_destroy("acme", force=True)

        assert result == 0

        # Find caddy reload call
        caddy_reloads = [
            c[0][0]
            for c in mock_run.call_args_list
            if "systemctl" in c[0][0] and "reload" in c[0][0] and "caddy" in c[0][0]
        ]
        assert len(caddy_reloads) == 1


class TestDestroyDirectoryCleanup:
    """Tests for site directory removal."""

    def test_removes_site_directory(self, mock_system_config, tmp_path):
        """Removes the site directory tree."""
        site_dir = _create_site_dir(mock_system_config, "acme")
        assert site_dir.exists()

        with (
            patch("subprocess.run"),
            patch.object(destroy_module, "get_site_port", return_value=None),
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            result = run_destroy("acme", force=True)

        assert result == 0
        assert not site_dir.exists()

    def test_safety_check_prevents_unsafe_removal(self, monkeypatch, tmp_path, capsys):
        """Safety check prevents removing paths that don't contain the slug."""
        # Create a config pointing to a directory without the slug in path
        config = SystemConfig(
            agency=AgencyConfig(name="testco"),
            staging=StagingConfig(
                server="test-staging",
                domain_pattern="{slug}.test.site",
                base_dir=str(tmp_path),
            ),
            production=ProductionConfig(
                server="test-prod",
                ssh_host="192.168.1.1",
                base_dir="/srv/prod",
            ),
            templates=TemplatesConfig(
                dir="/opt/infra",
                systemd="systemd/test.service",
                caddy="caddy/test.caddy",
            ),
            defaults=DefaultsConfig(
                theme="theme_a",
                deploy_user="deploy",
                seed_profile="sage-stone",
            ),
        )
        monkeypatch.setattr(destroy_module, "get_system_config", lambda: config)

        # Create the site directory (slug IS in the path here for this test)
        site_dir = config.get_site_dir("acme")
        site_dir.mkdir(parents=True, exist_ok=True)

        with (
            patch("subprocess.run"),
            patch.object(destroy_module, "get_site_port", return_value=None),
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            result = run_destroy("acme", force=True)

        assert result == 0


class TestDestroyBestEffort:
    """Tests for best-effort cleanup behavior."""

    def test_continues_on_systemd_failure(self, mock_system_config, tmp_path, capsys):
        """Continues destroy even if systemd operations fail."""
        site_dir = _create_site_dir(mock_system_config, "acme")

        subprocess_calls = []

        def run_side_effect(cmd, *args, **kwargs):
            subprocess_calls.append(cmd)
            # Fail on systemctl commands, succeed on psql
            if cmd[0] == "systemctl":
                raise OSError("systemctl not available")
            result = MagicMock()
            result.returncode = 0
            return result

        with (
            patch("subprocess.run", side_effect=run_side_effect),
            patch.object(destroy_module, "get_site_port", return_value=None),
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            result = run_destroy("acme", force=True)

        # Should still succeed (warnings are non-fatal)
        assert result == 0
        assert not site_dir.exists()

        # Verify warning was output
        captured = capsys.readouterr()
        assert "systemctl" in captured.out or "systemd" in captured.out.lower()
        assert "warning" in captured.out.lower() or "failed" in captured.out.lower()

        # Verify cleanup continued despite systemd failure
        # Should have attempted systemctl, then moved on to other cleanup
        assert any("systemctl" in str(cmd) for cmd in subprocess_calls)

    def test_continues_on_postgres_cleanup_failure(
        self, mock_system_config, tmp_path, capsys
    ):
        """Continues destroy even if cleanup_bare_metal_postgres raises."""
        site_dir = _create_site_dir(mock_system_config, "acme")

        with (
            patch("subprocess.run"),
            patch.object(destroy_module, "get_site_port", return_value=5433),
            patch.object(
                destroy_module,
                "cleanup_bare_metal_postgres",
                side_effect=OSError("pg_dropcluster failed"),
            ),
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            result = run_destroy("acme", force=True)

        # Should still succeed (warnings are non-fatal) and continue cleanup
        assert result == 0
        assert not site_dir.exists()
        captured = capsys.readouterr()
        assert "pg_dropcluster failed" in captured.out

    def test_continues_on_backup_cron_failure(
        self, mock_system_config, tmp_path, capsys
    ):
        """Continues even when backup cron removal fails."""
        _create_site_dir(mock_system_config, "acme")

        with (
            patch("subprocess.run"),
            patch.object(destroy_module, "get_site_port", return_value=None),
            patch.object(
                destroy_module,
                "remove_backup_cron",
                side_effect=OSError("cron error"),
            ),
        ):
            result = run_destroy("acme", force=True)

        assert result == 0
        captured = capsys.readouterr()
        assert "cron error" in captured.out


class TestDestroyOutput:
    """Tests for destroy command output."""

    def test_outputs_success_message(self, mock_system_config, tmp_path, capsys):
        """Outputs success message when destroy completes cleanly."""
        _create_site_dir(mock_system_config, "acme")

        with (
            patch("subprocess.run"),
            patch.object(destroy_module, "get_site_port", return_value=None),
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            result = run_destroy("acme", force=True)

        assert result == 0
        captured = capsys.readouterr()
        assert "destroyed successfully" in captured.out

    def test_outputs_warning_summary_on_partial_cleanup(
        self, mock_system_config, tmp_path, capsys
    ):
        """Outputs warning summary when some cleanup steps fail."""
        _create_site_dir(mock_system_config, "acme")

        def run_side_effect(cmd, *args, **kwargs):
            if "disable" in cmd:
                raise OSError("disable failed")
            result = MagicMock()
            result.returncode = 0
            return result

        with (
            patch("subprocess.run", side_effect=run_side_effect),
            patch.object(destroy_module, "get_site_port", return_value=None),
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            result = run_destroy("acme", force=True)

        assert result == 0
        captured = capsys.readouterr()
        assert "warning" in captured.out.lower()

    def test_confirmation_shows_site_info(
        self, monkeypatch, mock_system_config, tmp_path, capsys
    ):
        """Confirmation prompt shows site details."""
        site_dir = _create_site_dir(mock_system_config, "acme")

        # Write a site config for richer output
        sum_dir = site_dir / ".sum"
        sum_dir.mkdir(exist_ok=True)
        (sum_dir / "config.yml").write_text(
            "site:\n  slug: acme\n  theme: theme_a\n  created: '2025-01-01T00:00:00'\n"
        )

        # User aborts
        monkeypatch.setattr("builtins.input", lambda _: "wrong")

        with patch("subprocess.run"):
            run_destroy("acme")

        captured = capsys.readouterr()
        assert "acme" in captured.out
        assert "theme_a" in captured.out

    def test_progress_steps_displayed(self, mock_system_config, tmp_path, capsys):
        """Progress steps are displayed during teardown."""
        _create_site_dir(mock_system_config, "acme")

        with (
            patch("subprocess.run"),
            patch.object(destroy_module, "get_site_port", return_value=None),
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            result = run_destroy("acme", force=True)

        assert result == 0
        captured = capsys.readouterr()
        # Should have step indicators
        assert "[1/" in captured.out
        assert "[6/" in captured.out  # Last step


class TestDestroyClickCommand:
    """Tests for the click command wiring."""

    def test_click_command_exists(self):
        """The destroy click command is registered."""
        from sum.commands.destroy import destroy

        assert callable(destroy)

    def test_click_command_has_force_flag(self):
        """The destroy command has --force flag."""
        import click
        from sum.commands.destroy import destroy

        if isinstance(destroy, click.BaseCommand):
            param_names = [p.name for p in destroy.params]
            assert "force" in param_names

    def test_click_command_has_purge_backups_flag(self):
        """The destroy command has --purge-backups flag."""
        import click
        from sum.commands.destroy import destroy

        if isinstance(destroy, click.BaseCommand):
            param_names = [p.name for p in destroy.params]
            assert "purge_backups" in param_names

    def test_destroy_registered_in_cli(self):
        """Destroy command is registered in main CLI group."""
        from sum.cli import cli

        command_names = list(cli.commands.keys())
        assert "destroy" in command_names


class TestDestroyParameterizedPsql:
    """Tests for SEC-02: parameterized psql in fallback DROP path."""

    def test_fallback_drop_uses_psql_v_pattern(self, mock_system_config, tmp_path):
        """Fallback DROP uses psql -v variable substitution, not f-strings."""
        _create_site_dir(mock_system_config, "acme")

        with (
            patch("subprocess.run") as mock_run,
            patch.object(destroy_module, "get_site_port", return_value=None),
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            mock_run.return_value.returncode = 0
            result = run_destroy("acme", force=True)

        assert result == 0

        # Find psql calls with -v flag
        psql_v_calls = [
            c
            for c in mock_run.call_args_list
            if (
                isinstance(c[0][0], list)
                and any("psql" in str(a) for a in c[0][0])
                and any("-v" in str(a) for a in c[0][0])
            )
        ]
        # Should have exactly 2 psql -v calls (DROP DB + DROP USER)
        assert len(psql_v_calls) == 2

        # Verify input uses parameterized SQL (:"var" pattern)
        for call in psql_v_calls:
            call_input = call[1].get("input", "")
            assert ':"' in call_input  # psql variable substitution

    def test_fallback_drop_no_fstring_sql(self, mock_system_config, tmp_path):
        """Fallback DROP does not use f-string SQL injection."""
        _create_site_dir(mock_system_config, "acme")

        with (
            patch("subprocess.run") as mock_run,
            patch.object(destroy_module, "get_site_port", return_value=None),
            patch.object(destroy_module, "remove_backup_cron"),
        ):
            mock_run.return_value.returncode = 0
            run_destroy("acme", force=True)

        # No psql call should use -c flag (which was the old f-string approach)
        psql_c_calls = [
            c
            for c in mock_run.call_args_list
            if (
                isinstance(c[0][0], list)
                and any("psql" in str(a) for a in c[0][0])
                and any(a == "-c" for a in c[0][0])
            )
        ]
        assert len(psql_c_calls) == 0


class TestDestroySlugValidation:
    """Tests for SEC-03: validate_site_slug in destroy command."""

    def test_rejects_invalid_slug(self, mock_system_config, capsys):
        """Destroy rejects invalid slugs before any operations."""
        result = run_destroy("INVALID!!!", force=True)
        assert result == 1

        captured = capsys.readouterr()
        assert "Invalid site slug" in captured.out

    def test_rejects_empty_slug(self, mock_system_config, capsys):
        """Destroy rejects empty slugs."""
        result = run_destroy("", force=True)
        assert result == 1

        captured = capsys.readouterr()
        assert "must not be empty" in captured.out

    def test_accepts_valid_slug(self, mock_system_config, capsys):
        """Destroy accepts valid slugs (may fail later at site check)."""
        result = run_destroy("valid-slug", force=True)
        assert result == 1  # Fails at "site dir doesn't exist"

        captured = capsys.readouterr()
        assert "does not exist" in captured.out  # Past validation
