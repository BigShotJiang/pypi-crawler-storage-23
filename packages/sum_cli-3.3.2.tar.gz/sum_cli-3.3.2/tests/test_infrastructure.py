"""Tests for infrastructure.py — .env escaping."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest
from sum.setup.infrastructure import SiteCredentials, escape_env_value, write_env_file

# ---------------------------------------------------------------------------
# escape_env_value unit tests
# ---------------------------------------------------------------------------


class TestEscapeEnvValue:
    """Unit tests for the escape_env_value helper."""

    def test_simple_alphanumeric(self):
        assert escape_env_value("abc123") == "'abc123'"

    def test_hash_escaped(self):
        # '#' starts a comment in unquoted .env values; single quotes protect it
        assert escape_env_value("before#after") == "'before#after'"

    def test_dollar_literal(self):
        # Single quotes prevent python-dotenv variable interpolation
        assert escape_env_value("price$100") == "'price$100'"

    def test_double_quote_in_single(self):
        # Double quotes are literal inside single-quoted values
        assert escape_env_value('say"hello"') == "'say\"hello\"'"

    def test_backslash_literal(self):
        # Single quotes pass backslash through literally
        assert escape_env_value("back\\slash") == "'back\\slash'"

    def test_backtick_literal(self):
        # Single quotes pass backtick through literally
        assert escape_env_value("run`cmd`") == "'run`cmd`'"

    def test_single_quote_triggers_double(self):
        # Single quote in value forces double-quote mode
        assert escape_env_value("it's") == '"it\'s"'

    def test_space_preserved(self):
        assert escape_env_value("space value") == "'space value'"

    def test_combined_special_chars(self):
        raw = 'a#b$c"d\\e`f'
        # No ', \n, \r so single quotes are used — everything literal
        expected = "'a#b$c\"d\\e`f'"
        assert escape_env_value(raw) == expected

    def test_newline_escaped(self):
        # \n forces double-quote mode with escape sequence
        assert escape_env_value("line1\nline2") == '"line1\\nline2"'

    def test_carriage_return_escaped(self):
        # \r forces double-quote mode with escape sequence
        assert escape_env_value("line1\rline2") == '"line1\\rline2"'

    def test_crlf_escaped(self):
        assert escape_env_value("line1\r\nline2") == '"line1\\r\\nline2"'

    def test_empty_string(self):
        assert escape_env_value("") == "''"


# ---------------------------------------------------------------------------
# write_env_file tests
# ---------------------------------------------------------------------------


def _make_credentials(**overrides) -> SiteCredentials:
    """Create SiteCredentials with sensible defaults and optional overrides."""
    defaults = dict(
        db_name="sum_testsite",
        db_user="sum_testsite",
        db_password="simplepass",
        django_secret_key="simplekey",
        superuser_username="admin",
        superuser_email="admin@example.com",
        superuser_password="adminpass",
        postgres_port=5432,
    )
    defaults.update(overrides)
    return SiteCredentials(**defaults)


def _mock_system_config(site_dir: Path):
    """Return a mock SystemConfig suitable for write_env_file."""
    config = MagicMock()
    config.get_site_domain.return_value = "testsite.example.com"
    config.get_site_dir.return_value = site_dir
    return config


class TestWriteEnvFileEscaping:
    """Tests that write_env_file correctly escapes special characters."""

    def test_escapes_special_chars_in_secret_key(self, tmp_path):
        """Secret key containing #, $, and " must parse correctly."""
        creds = _make_credentials(django_secret_key='key#with$special"chars')
        site_dir = tmp_path / "site"
        site_dir.mkdir()
        config = _mock_system_config(site_dir)

        env_path = write_env_file(site_dir, "testsite", creds, config=config)
        content = env_path.read_text()

        # Single quotes protect $, ", and # without any escaping
        assert "DJANGO_SECRET_KEY='key#with$special\"chars'" in content

    def test_escapes_special_chars_in_db_password(self, tmp_path):
        """DB password containing single quote must parse correctly."""
        creds = _make_credentials(db_password="it's a p@ss")
        site_dir = tmp_path / "site"
        site_dir.mkdir()
        config = _mock_system_config(site_dir)

        env_path = write_env_file(site_dir, "testsite", creds, config=config)
        content = env_path.read_text()

        # Single quote in value forces double-quote mode
        assert 'DJANGO_DB_PASSWORD="it\'s a p@ss"' in content

    def test_preserves_simple_values(self, tmp_path):
        """Alphanumeric credentials produce backward-compatible quoted output."""
        creds = _make_credentials(
            django_secret_key="abc123XYZ",
            db_password="simplepass99",
        )
        site_dir = tmp_path / "site"
        site_dir.mkdir()
        config = _mock_system_config(site_dir)

        env_path = write_env_file(site_dir, "testsite", creds, config=config)
        content = env_path.read_text()

        # Values should be single-quoted (literal, no escaping needed)
        assert "DJANGO_SECRET_KEY='abc123XYZ'" in content
        assert "DJANGO_DB_PASSWORD='simplepass99'" in content

    def test_non_credential_values_unquoted(self, tmp_path):
        """Non-credential values (paths, booleans, module names) stay unquoted."""
        creds = _make_credentials()
        site_dir = tmp_path / "site"
        site_dir.mkdir()
        config = _mock_system_config(site_dir)

        env_path = write_env_file(site_dir, "testsite", creds, config=config)
        content = env_path.read_text()

        # These should NOT be quoted
        assert "DJANGO_SETTINGS_MODULE=testsite.settings.production" in content
        assert "DJANGO_DEBUG=False" in content
        assert "DJANGO_DB_HOST=localhost" in content
        assert f"DJANGO_STATIC_ROOT={site_dir}/static" in content

    def test_dotenv_parseable(self, tmp_path):
        """Generated .env with tricky chars parses correctly via python-dotenv."""
        dotenv = pytest.importorskip("dotenv")

        creds = _make_credentials(
            django_secret_key='k#e$y"val',
            db_password="p`a\\ss",
        )
        site_dir = tmp_path / "site"
        site_dir.mkdir()
        config = _mock_system_config(site_dir)

        env_path = write_env_file(site_dir, "testsite", creds, config=config)
        parsed = dotenv.dotenv_values(env_path)

        assert parsed["DJANGO_SECRET_KEY"] == 'k#e$y"val'
        assert parsed["DJANGO_DB_PASSWORD"] == "p`a\\ss"

    def test_dotenv_parseable_with_newlines(self, tmp_path):
        """Credentials with newline/CR parse correctly via python-dotenv."""
        dotenv = pytest.importorskip("dotenv")

        creds = _make_credentials(
            db_password="pass\nword",
            django_secret_key="key\r\nval",
        )
        site_dir = tmp_path / "site"
        site_dir.mkdir()
        config = _mock_system_config(site_dir)

        env_path = write_env_file(site_dir, "testsite", creds, config=config)
        parsed = dotenv.dotenv_values(env_path)

        assert parsed["DJANGO_DB_PASSWORD"] == "pass\nword"
        assert parsed["DJANGO_SECRET_KEY"] == "key\r\nval"

    def test_file_permissions(self, tmp_path):
        """The .env file must be created with 0o600 permissions."""
        import stat

        creds = _make_credentials()
        site_dir = tmp_path / "site"
        site_dir.mkdir()
        config = _mock_system_config(site_dir)

        env_path = write_env_file(site_dir, "testsite", creds, config=config)
        mode = stat.S_IMODE(env_path.stat().st_mode)

        assert mode == 0o600
