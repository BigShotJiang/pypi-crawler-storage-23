"""Tests for fix_site_ownership.

Verifies that all site files are owned by deploy:www-data after init,
except .credentials which should be root:root 600.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest
from sum.exceptions import SetupError
from sum.setup.infrastructure import fix_site_ownership
from sum.system_config import (
    AgencyConfig,
    DefaultsConfig,
    ProductionConfig,
    StagingConfig,
    SystemConfig,
    TemplatesConfig,
    reset_system_config,
)


@pytest.fixture(autouse=True)
def reset_config():
    reset_system_config()
    yield
    reset_system_config()


@pytest.fixture
def test_config(tmp_path):
    """System config pointing to tmp_path for site directories."""
    return SystemConfig(
        agency=AgencyConfig(name="testco"),
        staging=StagingConfig(
            server="staging",
            domain_pattern="{slug}.test.site",
            base_dir=str(tmp_path / "srv" / "sum"),
        ),
        production=ProductionConfig(
            server="prod",
            ssh_host="10.0.0.1",
            base_dir="/srv/prod",
        ),
        templates=TemplatesConfig(
            dir="/opt/infra",
            systemd="systemd/test.service",
            caddy="caddy/test.caddy",
        ),
        defaults=DefaultsConfig(
            theme="theme_a",
            deploy_user="deploy",
            seed_profile="sage-stone",
        ),
    )


def _create_full_site(config: SystemConfig, slug: str) -> Path:
    """Create a realistic site directory structure."""
    site_dir = config.get_site_dir(slug)
    site_dir.mkdir(parents=True)
    (site_dir / "app").mkdir()
    (site_dir / "static").mkdir()
    (site_dir / "media").mkdir()
    (site_dir / "backups").mkdir()
    (site_dir / "venv").mkdir()
    (site_dir / ".sum").mkdir()
    (site_dir / ".env").write_text("DJANGO_SECRET_KEY=test")
    (site_dir / ".credentials").write_text("admin password: secret")
    return site_dir


class TestFixSiteOwnership:
    """Tests for fix_site_ownership function."""

    def test_chowns_entire_site_directory(self, test_config, tmp_path):
        """Chowns the entire site directory recursively to deploy:www-data."""
        site_dir = _create_full_site(test_config, "acme")

        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            fix_site_ownership("acme", test_config)

        # First call should chown the entire site directory
        first_call = mock_run.call_args_list[0]
        cmd = first_call[0][0]
        assert "chown" in cmd
        assert "-R" in cmd
        assert "deploy:www-data" in cmd
        assert str(site_dir) in cmd

    def test_locks_down_credentials_to_root(self, test_config, tmp_path):
        """Sets .credentials to root:root after the recursive chown."""
        _create_full_site(test_config, "acme")

        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            fix_site_ownership("acme", test_config)

        # Second call should chown .credentials to root:root
        second_call = mock_run.call_args_list[1]
        cmd = second_call[0][0]
        assert "chown" in cmd
        assert "root:root" in cmd
        assert ".credentials" in cmd[-1]

    def test_credentials_gets_600_permissions(self, test_config, tmp_path):
        """Credentials file gets restricted 600 permissions."""
        site_dir = _create_full_site(test_config, "acme")
        creds_path = site_dir / ".credentials"

        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            fix_site_ownership("acme", test_config)

        # Check that chmod was called on credentials
        assert creds_path.stat().st_mode & 0o777 == 0o600

    def test_skips_credentials_lockdown_when_no_credentials_file(
        self, test_config, tmp_path
    ):
        """Skips credentials lockdown when .credentials doesn't exist."""
        site_dir = _create_full_site(test_config, "acme")
        (site_dir / ".credentials").unlink()

        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            fix_site_ownership("acme", test_config)

        # Should only call chown once (the recursive one)
        assert mock_run.call_count == 1

    def test_raises_on_chown_failure(self, test_config, tmp_path):
        """Raises SetupError when chown fails."""
        _create_full_site(test_config, "acme")

        from subprocess import CalledProcessError

        with patch("subprocess.run") as mock_run:
            mock_run.side_effect = CalledProcessError(
                1, "chown", stderr=b"permission denied"
            )
            with pytest.raises(SetupError, match="Failed to fix site ownership"):
                fix_site_ownership("acme", test_config)

    def test_chowns_all_subdirectories_via_recursive(self, test_config, tmp_path):
        """Verifies that one recursive chown covers all subdirectories.

        Previously only app, static, media were chowned individually.
        Now a single recursive chown covers backups, venv, .sum, .env, etc.
        """
        site_dir = _create_full_site(test_config, "acme")

        with patch("subprocess.run") as mock_run:
            mock_run.return_value.returncode = 0
            fix_site_ownership("acme", test_config)

        # The recursive chown is the first call and targets the site root
        first_call_cmd = mock_run.call_args_list[0][0][0]
        assert first_call_cmd == [
            "chown",
            "-R",
            "deploy:www-data",
            str(site_dir),
        ]
