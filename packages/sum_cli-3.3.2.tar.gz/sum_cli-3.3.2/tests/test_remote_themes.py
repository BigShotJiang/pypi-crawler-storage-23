# pyright: reportMissingImports=false, reportPrivateUsage=false, reportUnknownMemberType=false, reportUnknownParameterType=false, reportMissingParameterType=false, reportUnknownVariableType=false, reportUnusedCallResult=false, reportUnknownArgumentType=false, reportMissingModuleSource=false

"""Tests for remote theme fetching functionality."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from sum.exceptions import ThemeNotFoundError
from sum.setup.remote_themes import (
    ThemeSpec,
    fetch_theme_from_repo,
    get_cache_dir,
    get_cached_theme,
    get_latest_theme_tag,
    parse_theme_spec,
    resolve_remote_theme,
)


class TestParseThemeSpec:
    """Test theme specification parsing."""

    def test_parse_simple_slug(self):
        spec = parse_theme_spec("theme_a")
        assert spec.slug == "theme_a"
        assert spec.version is None

    def test_parse_slug_with_version(self):
        spec = parse_theme_spec("theme_a@1.0.0")
        assert spec.slug == "theme_a"
        assert spec.version == "1.0.0"

    def test_parse_slug_with_v_prefix(self):
        spec = parse_theme_spec("theme_a@v1.0.0")
        assert spec.slug == "theme_a"
        assert spec.version == "1.0.0"

    def test_parse_strips_whitespace(self):
        spec = parse_theme_spec("  theme_a  ")
        assert spec.slug == "theme_a"
        assert spec.version is None

    def test_parse_strips_whitespace_with_version(self):
        spec = parse_theme_spec("  theme_a @ 1.0.0  ")
        assert spec.slug == "theme_a"
        assert spec.version == "1.0.0"

    def test_parse_empty_raises(self):
        with pytest.raises(ThemeNotFoundError, match="slug cannot be empty"):
            parse_theme_spec("")

    def test_parse_whitespace_only_raises(self):
        with pytest.raises(ThemeNotFoundError, match="slug cannot be empty"):
            parse_theme_spec("   ")

    def test_parse_empty_slug_with_at_raises(self):
        with pytest.raises(ThemeNotFoundError, match="slug cannot be empty"):
            parse_theme_spec("@1.0.0")

    def test_parse_empty_version_raises(self):
        with pytest.raises(ThemeNotFoundError, match="Version cannot be empty"):
            parse_theme_spec("theme_a@")

    def test_str_without_version(self):
        spec = ThemeSpec(slug="theme_a", version=None)
        assert str(spec) == "theme_a"

    def test_str_with_version(self):
        spec = ThemeSpec(slug="theme_a", version="1.0.0")
        assert str(spec) == "theme_a@1.0.0"

    def test_parse_rejects_directory_traversal(self):
        """Ensure slugs with path traversal attempts are rejected."""
        with pytest.raises(ThemeNotFoundError, match="Invalid theme slug"):
            parse_theme_spec("../../../etc/passwd")

    def test_parse_rejects_uppercase(self):
        """Slugs must be lowercase."""
        with pytest.raises(ThemeNotFoundError, match="Invalid theme slug"):
            parse_theme_spec("Theme_A")

    def test_parse_rejects_starting_with_number(self):
        """Slugs must start with a letter."""
        with pytest.raises(ThemeNotFoundError, match="Invalid theme slug"):
            parse_theme_spec("1theme")

    def test_parse_accepts_hyphens_and_underscores(self):
        """Slugs can contain hyphens and underscores after first char."""
        spec = parse_theme_spec("my-theme_v2")
        assert spec.slug == "my-theme_v2"


class TestGetCacheDir:
    """Test cache directory management."""

    def test_returns_path(self):
        cache_dir = get_cache_dir()
        assert isinstance(cache_dir, Path)

    def test_path_is_under_home(self):
        cache_dir = get_cache_dir()
        assert str(Path.home()) in str(cache_dir)

    def test_creates_directory(self, tmp_path, monkeypatch):
        # Patch Path.home to use tmp_path
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cache_dir = get_cache_dir()
        assert cache_dir.is_dir()


class TestGetCachedTheme:
    """Test cached theme detection."""

    def test_returns_none_when_not_cached(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        result = get_cached_theme("theme_a", "1.0.0")
        assert result is None

    def test_returns_path_when_cached(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cache_dir = get_cache_dir()
        # Cache layout: {cache}/slug/version/slug/
        theme_dir = cache_dir / "theme_a" / "1.0.0" / "theme_a"
        theme_dir.mkdir(parents=True)
        (theme_dir / "theme.json").write_text("{}")

        result = get_cached_theme("theme_a", "1.0.0")
        assert result == theme_dir

    def test_returns_none_without_manifest(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cache_dir = get_cache_dir()
        theme_dir = cache_dir / "theme_a" / "1.0.0"
        theme_dir.mkdir(parents=True)
        # No theme.json

        result = get_cached_theme("theme_a", "1.0.0")
        assert result is None


class TestGetLatestThemeTag:
    """Test finding latest theme tags from remote."""

    def test_returns_none_on_git_error(self):
        with patch("sum.setup.remote_themes._run_git_command") as mock_git:
            from subprocess import CalledProcessError

            mock_git.side_effect = CalledProcessError(1, "git")
            result = get_latest_theme_tag("theme_a")
            assert result is None

    def test_returns_none_on_empty_output(self):
        with patch("sum.setup.remote_themes._run_git_command") as mock_git:
            mock_result = MagicMock()
            mock_result.stdout = ""
            mock_git.return_value = mock_result
            result = get_latest_theme_tag("theme_a")
            assert result is None

    def test_parses_single_tag(self):
        with patch("sum.setup.remote_themes._run_git_command") as mock_git:
            mock_result = MagicMock()
            mock_result.stdout = "abc123\trefs/tags/theme_a/v1.0.0\n"
            mock_git.return_value = mock_result
            result = get_latest_theme_tag("theme_a")
            assert result == "1.0.0"

    def test_returns_latest_version(self):
        with patch("sum.setup.remote_themes._run_git_command") as mock_git:
            mock_result = MagicMock()
            mock_result.stdout = (
                "abc123\trefs/tags/theme_a/v1.0.0\n"
                "def456\trefs/tags/theme_a/v2.0.0\n"
                "ghi789\trefs/tags/theme_a/v1.5.0\n"
            )
            mock_git.return_value = mock_result
            result = get_latest_theme_tag("theme_a")
            assert result == "2.0.0"

    def test_handles_semver_correctly(self):
        with patch("sum.setup.remote_themes._run_git_command") as mock_git:
            mock_result = MagicMock()
            mock_result.stdout = (
                "abc123\trefs/tags/theme_a/v1.9.0\n"
                "def456\trefs/tags/theme_a/v1.10.0\n"
            )
            mock_git.return_value = mock_result
            result = get_latest_theme_tag("theme_a")
            # 1.10.0 > 1.9.0 numerically
            assert result == "1.10.0"


class TestFetchThemeFromRepo:
    """Test theme fetching from remote repository."""

    def test_uses_cache_when_available(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cache_dir = get_cache_dir()
        # Cache layout: {cache}/slug/version/slug/
        theme_dir = cache_dir / "theme_a" / "1.0.0" / "theme_a"
        theme_dir.mkdir(parents=True)
        (theme_dir / "theme.json").write_text('{"slug": "theme_a"}')

        result = fetch_theme_from_repo("theme_a", "1.0.0")
        assert result == theme_dir

    def test_raises_when_no_version_tags(self):
        with patch("sum.setup.remote_themes.get_latest_theme_tag", return_value=None):
            with pytest.raises(ThemeNotFoundError, match="No version tags found"):
                fetch_theme_from_repo("nonexistent_theme")

    def test_raises_on_clone_failure(self, tmp_path, monkeypatch):
        from subprocess import CalledProcessError

        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        with patch("sum.setup.remote_themes._run_git_command") as mock_git:
            mock_git.side_effect = CalledProcessError(
                1, "git", stderr="Could not find remote branch"
            )
            with pytest.raises(ThemeNotFoundError, match="not found"):
                fetch_theme_from_repo("theme_a", "1.0.0")


class TestResolveRemoteTheme:
    """Test the main entry point for remote theme resolution."""

    def test_parses_and_fetches(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cache_dir = get_cache_dir()
        # Cache layout: {cache}/slug/version/slug/
        theme_dir = cache_dir / "theme_a" / "1.0.0" / "theme_a"
        theme_dir.mkdir(parents=True)
        (theme_dir / "theme.json").write_text('{"slug": "theme_a"}')

        result = resolve_remote_theme("theme_a@1.0.0")
        assert result == theme_dir

    def test_fetches_latest_without_version(self, tmp_path, monkeypatch):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cache_dir = get_cache_dir()
        # Cache layout: {cache}/slug/version/slug/
        theme_dir = cache_dir / "theme_a" / "2.0.0" / "theme_a"
        theme_dir.mkdir(parents=True)
        (theme_dir / "theme.json").write_text('{"slug": "theme_a"}')

        with patch(
            "sum.setup.remote_themes.get_latest_theme_tag", return_value="2.0.0"
        ):
            result = resolve_remote_theme("theme_a")
            assert result == theme_dir


class TestIntegrationWithScaffold:
    """Test integration of remote themes with scaffold module."""

    def test_resolve_theme_dir_with_version_goes_remote(self, tmp_path, monkeypatch):
        """When version is specified, should go directly to remote."""
        from sum.setup.scaffold import _resolve_theme_dir

        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cache_dir = get_cache_dir()
        # Cache layout: {cache}/slug/version/slug/
        theme_dir = cache_dir / "theme_a" / "1.0.0" / "theme_a"
        theme_dir.mkdir(parents=True)
        manifest = {
            "slug": "theme_a",
            "name": "Theme A",
            "description": "Test",
            "version": "1.0.0",
        }
        (theme_dir / "theme.json").write_text(json.dumps(manifest))

        result = _resolve_theme_dir("theme_a@1.0.0", None)
        assert result == theme_dir

    def test_resolve_theme_dir_prefers_local(self, tmp_path, monkeypatch):
        """Without version, should prefer local themes over remote."""
        from sum.setup.scaffold import _resolve_theme_dir

        # Create local theme
        local_theme = tmp_path / "themes" / "theme_a"
        local_theme.mkdir(parents=True)
        manifest = {
            "slug": "theme_a",
            "name": "Theme A",
            "description": "Test",
            "version": "1.0.0",
        }
        (local_theme / "theme.json").write_text(json.dumps(manifest))

        # Change to tmp_path so ./themes/ is found
        monkeypatch.chdir(tmp_path)

        result = _resolve_theme_dir("theme_a", None)
        assert result == local_theme

    def test_resolve_theme_dir_falls_back_to_remote(self, tmp_path, monkeypatch):
        """When theme doesn't exist locally, should fall back to remote."""
        from sum.setup.scaffold import _resolve_theme_dir

        # Setup cache with remote theme
        # Cache layout: {cache}/slug/version/slug/
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cache_dir = get_cache_dir()
        theme_dir = cache_dir / "remote_theme" / "1.0.0" / "remote_theme"
        theme_dir.mkdir(parents=True)
        manifest = {
            "slug": "remote_theme",
            "name": "Remote Theme",
            "description": "Test",
            "version": "1.0.0",
        }
        (theme_dir / "theme.json").write_text(json.dumps(manifest))

        # Change to tmp_path where ./themes/remote_theme doesn't exist
        monkeypatch.chdir(tmp_path)

        # Mock get_latest_theme_tag to return version
        with patch(
            "sum.setup.remote_themes.get_latest_theme_tag", return_value="1.0.0"
        ):
            result = _resolve_theme_dir("remote_theme", None)
            assert result == theme_dir


class TestThemeSlugValidation:
    """Test theme slug validation for security."""

    def test_rejects_path_traversal_dots(self):
        with pytest.raises(ThemeNotFoundError, match="Invalid theme slug"):
            parse_theme_spec("..theme")

    def test_rejects_slashes(self):
        with pytest.raises(ThemeNotFoundError, match="Invalid theme slug"):
            parse_theme_spec("theme/subdir")

    def test_rejects_backslashes(self):
        with pytest.raises(ThemeNotFoundError, match="Invalid theme slug"):
            parse_theme_spec("theme\\subdir")

    def test_rejects_special_characters(self):
        with pytest.raises(ThemeNotFoundError, match="Invalid theme slug"):
            parse_theme_spec("theme$name")


class TestConfigurableRepoUrl:
    """Test configurable repository URL via environment variable."""

    def test_uses_default_when_not_set(self, monkeypatch):
        from sum.setup.remote_themes import (
            DEFAULT_SUM_THEMES_REPO,
            _get_themes_repo_url,
        )

        monkeypatch.delenv("SUM_THEMES_REPO", raising=False)
        assert _get_themes_repo_url() == DEFAULT_SUM_THEMES_REPO

    def test_uses_env_var_when_set(self, monkeypatch):
        from sum.setup.remote_themes import _get_themes_repo_url

        custom_url = "https://github.com/example/custom-themes.git"
        monkeypatch.setenv("SUM_THEMES_REPO", custom_url)
        assert _get_themes_repo_url() == custom_url


class TestTimeoutHandling:
    """Test timeout handling for git network operations."""

    def test_returns_none_on_timeout(self):
        from subprocess import TimeoutExpired

        with patch("sum.setup.remote_themes._run_git_command") as mock_git:
            mock_git.side_effect = TimeoutExpired("git", 120)
            result = get_latest_theme_tag("theme_a")
            assert result is None

    def test_fetch_raises_on_timeout(self, tmp_path, monkeypatch):
        from subprocess import TimeoutExpired

        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        with patch("sum.setup.remote_themes._run_git_command") as mock_git:
            mock_git.side_effect = TimeoutExpired("git", 120)
            with pytest.raises(ThemeNotFoundError, match="Timeout"):
                fetch_theme_from_repo("theme_a", "1.0.0")


class TestMissingThemeJson:
    """Test handling of themes missing theme.json."""

    def test_fetch_raises_when_theme_json_missing(self, tmp_path, monkeypatch):
        """Theme exists in checkout but missing theme.json should raise."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        # Create a mock for the git clone that creates a theme dir without theme.json
        def mock_run_git_command(args, cwd=None, check=True, timeout=None):
            if args[0] == "clone":
                # Extract the clone target path from args
                clone_path = Path(args[-1])
                clone_path.mkdir(parents=True)
                # Create theme directory but without theme.json
                # Repo structure: themes/{slug}/
                (clone_path / "themes" / "theme_a").mkdir(parents=True)
                mock_result = MagicMock()
                mock_result.stdout = ""
                mock_result.returncode = 0
                return mock_result
            elif args[0] == "sparse-checkout":
                mock_result = MagicMock()
                mock_result.stdout = ""
                mock_result.returncode = 0
                return mock_result
            raise ValueError(f"Unexpected git command: {args}")

        with patch(
            "sum.setup.remote_themes._run_git_command", side_effect=mock_run_git_command
        ):
            with pytest.raises(ThemeNotFoundError, match="missing theme.json"):
                fetch_theme_from_repo("theme_a", "1.0.0")
