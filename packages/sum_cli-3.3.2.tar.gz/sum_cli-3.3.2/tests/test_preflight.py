"""Tests for the pre-flight check framework."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner
from sum.cli import cli
from sum.utils.preflight import (
    CheckResult,
    CheckSeverity,
    CheckStatus,
    CipherPassFileCheck,
    DiskSpaceCheck,
    GiteaRepoCheck,
    GiteaTokenCheck,
    PgBackRestStanzaCheck,
    PostgresClusterCheck,
    PreflightCheck,
    PreflightRunner,
    SiteExistsCheck,
    SSHConnectivityCheck,
    SystemConfigCheck,
)

# ─── CheckResult dataclass ──────────────────────────────────────────────────


class TestCheckResult:
    def test_ok(self) -> None:
        r = CheckResult.ok("all good")
        assert r.status == CheckStatus.PASS
        assert r.message == "all good"
        assert r.fix_hint is None

    def test_fail(self) -> None:
        r = CheckResult.fail("broken", fix_hint="fix it")
        assert r.status == CheckStatus.FAIL
        assert r.message == "broken"
        assert r.fix_hint == "fix it"

    def test_warn(self) -> None:
        r = CheckResult.warn("heads up", fix_hint="maybe fix")
        assert r.status == CheckStatus.WARN
        assert r.fix_hint == "maybe fix"

    def test_skip(self) -> None:
        r = CheckResult.skip("not applicable")
        assert r.status == CheckStatus.SKIP

    def test_frozen(self) -> None:
        r = CheckResult.ok("test")
        with pytest.raises(AttributeError):
            r.status = CheckStatus.FAIL  # type: ignore[misc]


# ─── PreflightRunner ─────────────────────────────────────────────────────────


class _PassCheck(PreflightCheck):
    name = "pass-check"
    description = "Always passes"

    def check(self) -> CheckResult:
        return CheckResult.ok("passed")


class _FailCheck(PreflightCheck):
    name = "fail-check"
    description = "Always fails"

    def check(self) -> CheckResult:
        return CheckResult.fail("failed", fix_hint="do something")


class _WarnCheck(PreflightCheck):
    name = "warn-check"
    description = "Always warns"
    severity = CheckSeverity.RECOMMENDED

    def check(self) -> CheckResult:
        return CheckResult.warn("warning")


class _RecommendedFailCheck(PreflightCheck):
    """A RECOMMENDED check that returns FAIL — should not block."""

    name = "recommended-fail-check"
    description = "Recommended check that fails"
    severity = CheckSeverity.RECOMMENDED

    def check(self) -> CheckResult:
        return CheckResult.fail("failed but recommended")


class _ExplodingCheck(PreflightCheck):
    name = "exploding-check"
    description = "Raises an exception"

    def check(self) -> CheckResult:
        raise RuntimeError("boom")


class TestPreflightRunner:
    def test_empty_runner_is_go(self) -> None:
        runner = PreflightRunner()
        results = runner.run()
        assert results == []
        assert runner.is_go(results) is True

    def test_all_pass_is_go(self) -> None:
        runner = PreflightRunner()
        runner.register(_PassCheck())
        results = runner.run()
        assert len(results) == 1
        assert results[0][1].status == CheckStatus.PASS
        assert runner.is_go(results) is True

    def test_required_fail_is_no_go(self) -> None:
        runner = PreflightRunner()
        runner.register(_PassCheck())
        runner.register(_FailCheck())
        results = runner.run()
        assert runner.is_go(results) is False

    def test_recommended_fail_is_still_go(self) -> None:
        """RECOMMENDED check returning FAIL does not block."""
        runner = PreflightRunner()
        runner.register(_PassCheck())
        runner.register(_RecommendedFailCheck())
        results = runner.run()
        assert runner.is_go(results) is True

    def test_exception_becomes_fail(self) -> None:
        runner = PreflightRunner()
        runner.register(_ExplodingCheck())
        results = runner.run()
        assert results[0][1].status == CheckStatus.FAIL
        assert "boom" in results[0][1].message

    def test_format_results(self) -> None:
        runner = PreflightRunner()
        runner.register(_PassCheck())
        runner.register(_FailCheck())
        results = runner.run()
        output = runner.format_results(results)
        assert "pass-check" in output
        assert "fail-check" in output
        assert "Fix:" in output
        assert "─" in output

    def test_format_results_recommended_tag(self) -> None:
        runner = PreflightRunner()
        runner.register(_WarnCheck())
        results = runner.run()
        output = runner.format_results(results)
        assert "(recommended)" in output


# ─── SiteExistsCheck ─────────────────────────────────────────────────────────


class TestSiteExistsCheck:
    def test_site_exists(self, tmp_path: Path) -> None:
        site_dir = tmp_path / "mysite"
        site_dir.mkdir()
        check = SiteExistsCheck("mysite", base_dir=str(tmp_path))
        result = check.check()
        assert result.status == CheckStatus.PASS

    def test_site_missing(self, tmp_path: Path) -> None:
        check = SiteExistsCheck("nosite", base_dir=str(tmp_path))
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "nosite" in result.message


# ─── PostgresClusterCheck ────────────────────────────────────────────────────


class TestPostgresClusterCheck:
    @patch("sum.utils.preflight.subprocess.run")
    def test_cluster_online(self, mock_run: MagicMock) -> None:
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="18 mysite 5433 online postgres /var/lib/...\n",
        )
        check = PostgresClusterCheck("mysite")
        result = check.check()
        assert result.status == CheckStatus.PASS

    @patch("sum.utils.preflight.subprocess.run")
    def test_cluster_down(self, mock_run: MagicMock) -> None:
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="18 mysite 5433 down postgres /var/lib/...\n",
        )
        check = PostgresClusterCheck("mysite")
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "down" in result.message

    @patch("sum.utils.preflight.subprocess.run")
    def test_cluster_not_found(self, mock_run: MagicMock) -> None:
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="18 other 5432 online postgres /var/lib/...\n",
        )
        check = PostgresClusterCheck("mysite")
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "not found" in result.message

    @patch("sum.utils.preflight.subprocess.run", side_effect=FileNotFoundError)
    def test_pg_not_installed(self, mock_run: MagicMock) -> None:
        check = PostgresClusterCheck("mysite")
        result = check.check()
        assert result.status == CheckStatus.SKIP

    @patch("sum.utils.preflight.subprocess.run")
    def test_timeout(self, mock_run: MagicMock) -> None:
        import subprocess

        mock_run.side_effect = subprocess.TimeoutExpired(cmd="pg_lsclusters", timeout=5)
        check = PostgresClusterCheck("mysite")
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "timed out" in result.message


# ─── SystemConfigCheck ───────────────────────────────────────────────────────


class TestSystemConfigCheck:
    def test_config_exists(self, tmp_path: Path) -> None:
        cfg = tmp_path / "config.yml"
        cfg.write_text("agency:\n  name: test\n")
        check = SystemConfigCheck(config_path=cfg)
        result = check.check()
        assert result.status == CheckStatus.PASS

    def test_config_missing(self, tmp_path: Path) -> None:
        cfg = tmp_path / "nonexistent.yml"
        check = SystemConfigCheck(config_path=cfg)
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "not found" in result.message

    def test_config_env_override(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        cfg = tmp_path / "custom.yml"
        cfg.write_text("test: true\n")
        monkeypatch.setenv("SUM_CONFIG_PATH", str(cfg))
        check = SystemConfigCheck()  # no explicit path
        result = check.check()
        assert result.status == CheckStatus.PASS


# ─── SSHConnectivityCheck ────────────────────────────────────────────────────


class TestSSHConnectivityCheck:
    @patch("sum.utils.preflight.subprocess.run")
    def test_ssh_success(self, mock_run: MagicMock) -> None:
        mock_run.return_value = MagicMock(returncode=0)
        check = SSHConnectivityCheck("example.com")
        result = check.check()
        assert result.status == CheckStatus.PASS

    @patch("sum.utils.preflight.subprocess.run")
    def test_ssh_failure(self, mock_run: MagicMock) -> None:
        mock_run.return_value = MagicMock(returncode=255)
        check = SSHConnectivityCheck("example.com")
        result = check.check()
        assert result.status == CheckStatus.FAIL

    @patch("sum.utils.preflight.subprocess.run")
    def test_ssh_timeout(self, mock_run: MagicMock) -> None:
        import subprocess

        mock_run.side_effect = subprocess.TimeoutExpired(cmd="ssh", timeout=5)
        check = SSHConnectivityCheck("example.com", timeout=5)
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "timed out" in result.message

    @patch("sum.utils.preflight.subprocess.run", side_effect=FileNotFoundError)
    def test_ssh_not_found(self, mock_run: MagicMock) -> None:
        check = SSHConnectivityCheck("example.com")
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "ssh not found" in result.message

    @patch("sum.utils.preflight.subprocess.run")
    def test_custom_port(self, mock_run: MagicMock) -> None:
        mock_run.return_value = MagicMock(returncode=0)
        check = SSHConnectivityCheck("example.com", port=2222)
        result = check.check()
        assert result.status == CheckStatus.PASS
        call_args = mock_run.call_args[0][0]
        assert "-p" in call_args
        idx = call_args.index("-p")
        assert call_args[idx + 1] == "2222"

    @patch("sum.utils.preflight.subprocess.run")
    def test_ssh_flags_accept_new_and_devnull(self, mock_run: MagicMock) -> None:
        """Verify SSH uses StrictHostKeyChecking=accept-new and UserKnownHostsFile=/dev/null."""
        mock_run.return_value = MagicMock(returncode=0)
        check = SSHConnectivityCheck("example.com")
        check.check()
        call_args = mock_run.call_args[0][0]
        assert "StrictHostKeyChecking=accept-new" in call_args
        assert "UserKnownHostsFile=/dev/null" in call_args
        # Must NOT use StrictHostKeyChecking=no
        assert "StrictHostKeyChecking=no" not in call_args


# ─── GiteaTokenCheck ─────────────────────────────────────────────────────────


class TestGiteaTokenCheck:
    @patch("sum.utils.preflight.detect_gitea_token", return_value="abc123")
    def test_token_set(self, mock_detect: MagicMock) -> None:
        check = GiteaTokenCheck()
        result = check.check()
        assert result.status == CheckStatus.PASS
        mock_detect.assert_called_once_with(env_var="GITEA_TOKEN")

    @patch("sum.utils.preflight.detect_gitea_token", return_value=None)
    def test_token_missing(self, mock_detect: MagicMock) -> None:
        check = GiteaTokenCheck()
        result = check.check()
        assert result.status == CheckStatus.FAIL

    @patch("sum.utils.preflight.detect_gitea_token", return_value="")
    def test_token_empty(self, mock_detect: MagicMock) -> None:
        check = GiteaTokenCheck()
        result = check.check()
        assert result.status == CheckStatus.FAIL

    @patch("sum.utils.preflight.detect_gitea_token", return_value="abc123")
    def test_custom_env_var(self, mock_detect: MagicMock) -> None:
        check = GiteaTokenCheck(env_var="MY_TOKEN")
        result = check.check()
        assert result.status == CheckStatus.PASS
        assert "MY_TOKEN" in result.message
        mock_detect.assert_called_once_with(env_var="MY_TOKEN")

    @patch("sum.utils.preflight.detect_gitea_token", return_value=None)
    def test_custom_env_var_missing(self, mock_detect: MagicMock) -> None:
        check = GiteaTokenCheck(env_var="MY_TOKEN")
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "MY_TOKEN" in result.message


# ─── GiteaRepoCheck ──────────────────────────────────────────────────────────


class TestGiteaRepoCheck:
    @patch("sum.utils.preflight.urllib.request.urlopen")
    @patch("sum.utils.preflight.detect_gitea_token", return_value="testtoken")
    def test_repo_exists(self, mock_detect: MagicMock, mock_urlopen: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp
        check = GiteaRepoCheck("org", "repo")
        result = check.check()
        assert result.status == CheckStatus.PASS

    @patch("sum.utils.preflight.urllib.request.urlopen")
    @patch("sum.utils.preflight.detect_gitea_token", return_value="testtoken")
    def test_repo_not_found(
        self, mock_detect: MagicMock, mock_urlopen: MagicMock
    ) -> None:
        import urllib.error

        mock_urlopen.side_effect = urllib.error.HTTPError(
            url="", code=404, msg="Not Found", hdrs=None, fp=None  # type: ignore[arg-type]
        )
        check = GiteaRepoCheck("org", "repo")
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "not found" in result.message

    @patch("sum.utils.preflight.detect_gitea_token", return_value=None)
    def test_skip_without_token(self, mock_detect: MagicMock) -> None:
        check = GiteaRepoCheck("org", "repo")
        result = check.check()
        assert result.status == CheckStatus.SKIP

    @patch("sum.utils.preflight.urllib.request.urlopen")
    @patch("sum.utils.preflight.detect_gitea_token", return_value="testtoken")
    def test_api_error(self, mock_detect: MagicMock, mock_urlopen: MagicMock) -> None:
        import urllib.error

        mock_urlopen.side_effect = urllib.error.HTTPError(
            url="", code=500, msg="Server Error", hdrs=None, fp=None  # type: ignore[arg-type]
        )
        check = GiteaRepoCheck("org", "repo")
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "500" in result.message

    @patch("sum.utils.preflight.urllib.request.urlopen")
    @patch("sum.utils.preflight.detect_gitea_token", return_value="testtoken")
    def test_timeout(self, mock_detect: MagicMock, mock_urlopen: MagicMock) -> None:
        import urllib.error

        mock_urlopen.side_effect = urllib.error.URLError("timed out")
        check = GiteaRepoCheck("org", "repo")
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "timed out" in result.message

    @patch("sum.utils.preflight.urllib.request.urlopen")
    @patch("sum.utils.preflight.detect_gitea_token", return_value="testtoken")
    def test_custom_token_env(
        self, mock_detect: MagicMock, mock_urlopen: MagicMock
    ) -> None:
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.__enter__ = MagicMock(return_value=mock_resp)
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp
        check = GiteaRepoCheck("org", "repo", token_env="MY_TOKEN")
        result = check.check()
        assert result.status == CheckStatus.PASS
        mock_detect.assert_called_once_with(env_var="MY_TOKEN")

    @patch("sum.utils.preflight.detect_gitea_token", return_value=None)
    def test_custom_token_env_skip(self, mock_detect: MagicMock) -> None:
        check = GiteaRepoCheck("org", "repo", token_env="MY_TOKEN")
        result = check.check()
        assert result.status == CheckStatus.SKIP
        assert "MY_TOKEN" in result.message

    def test_invalid_url_fails(self) -> None:
        """FAIL early if Gitea URL is empty or not HTTP(S)."""
        check = GiteaRepoCheck("org", "repo", url="")
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "Invalid" in result.message

    def test_non_http_url_fails(self) -> None:
        """FAIL early if Gitea URL doesn't start with http/https."""
        check = GiteaRepoCheck("org", "repo", url="ftp://example.com")
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "Invalid" in result.message


# ─── CipherPassFileCheck ─────────────────────────────────────────────────────


class TestCipherPassFileCheck:
    def test_file_exists(self, tmp_path: Path) -> None:
        f = tmp_path / "cipher"
        f.write_text("DUMMY-TEST-PASSPHRASE-NOT-REAL")
        check = CipherPassFileCheck(path=str(f))
        result = check.check()
        assert result.status == CheckStatus.PASS

    def test_file_missing(self, tmp_path: Path) -> None:
        check = CipherPassFileCheck(path=str(tmp_path / "missing"))
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "not found" in result.message

    def test_file_empty(self, tmp_path: Path) -> None:
        f = tmp_path / "cipher"
        f.write_text("  \n")
        check = CipherPassFileCheck(path=str(f))
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "empty" in result.message


# ─── DiskSpaceCheck ──────────────────────────────────────────────────────────


class TestDiskSpaceCheck:
    def test_sufficient_space(self, tmp_path: Path) -> None:
        check = DiskSpaceCheck(path=str(tmp_path), min_gb=0.001)
        result = check.check()
        assert result.status == CheckStatus.PASS

    @patch("sum.utils.preflight.shutil.disk_usage")
    def test_insufficient_space(self, mock_usage: MagicMock, tmp_path: Path) -> None:
        mock_usage.return_value = MagicMock(free=100 * 1024 * 1024)  # 100 MB
        check = DiskSpaceCheck(path=str(tmp_path), min_gb=1.0)
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "free" in result.message.lower()

    def test_nonexistent_path_walks_up(self, tmp_path: Path) -> None:
        # Check a path that doesn't exist yet — should walk up to existing ancestor
        check = DiskSpaceCheck(
            path=str(tmp_path / "does" / "not" / "exist"), min_gb=0.001
        )
        result = check.check()
        assert result.status == CheckStatus.PASS


# ─── PgBackRestStanzaCheck ───────────────────────────────────────────────────


class TestPgBackRestStanzaCheck:
    def test_stanza_exists(self, tmp_path: Path) -> None:
        stanza = tmp_path / "mysite.conf"
        stanza.write_text("[mysite]\n")
        check = PgBackRestStanzaCheck("mysite", config_dir=str(tmp_path))
        result = check.check()
        assert result.status == CheckStatus.PASS

    def test_stanza_missing(self, tmp_path: Path) -> None:
        check = PgBackRestStanzaCheck("mysite", config_dir=str(tmp_path))
        result = check.check()
        assert result.status == CheckStatus.FAIL
        assert "not found" in result.message


# ─── CLI --skip-preflight flag ───────────────────────────────────────────────


class TestSkipPreflightFlag:
    def test_flag_propagates_to_context(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["--skip-preflight", "--help"])
        assert result.exit_code == 0

    def test_flag_default_false(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "skip-preflight" in result.output

    def test_flag_appears_in_help(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert "--skip-preflight" in result.output
        assert "Skip pre-flight checks" in result.output
