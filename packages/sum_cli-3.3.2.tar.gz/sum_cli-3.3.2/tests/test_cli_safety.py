"""
Name: CLI Safety Regression Tests
Path: cli/tests/test_cli_safety.py
Purpose: Explicit regression tests for CLI safety boundaries and immutability
Family: sum_cli tests
Dependencies: sum_cli

NOTE: The tests for init command scaffolding behavior have been removed
as the init command was refactored to create production sites at /srv/sum/
instead of scaffolding to clients/. See #1298.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from tests.utils.safe_cleanup import UnsafeDeleteError

pytestmark = pytest.mark.regression


def test_cleanup_guard_refuses_source_paths(request, isolated_theme_env) -> None:
    """Test that the cleanup guard prevents deleting source directories."""
    sandbox = request.node.cli_filesystem_sandbox
    theme_root = Path(isolated_theme_env["SUM_THEME_PATH"]) / "theme_a"
    boilerplate_root = Path(isolated_theme_env["SUM_BOILERPLATE_PATH"])

    with pytest.raises(UnsafeDeleteError):
        sandbox.safe_rmtree(theme_root)
    with pytest.raises(UnsafeDeleteError):
        sandbox.safe_rmtree(boilerplate_root)


# NOTE: The following tests were removed as they tested the old scaffold-to-clients
# behavior which was replaced by production site creation in #1298:
# - test_init_output_boundary_and_source_immutability
# - test_repeated_inits_do_not_corrupt_sources
