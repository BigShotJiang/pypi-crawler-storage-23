"""Tests for the promote command.

Tests cover:
- Dry-run mode previews steps
- Confirmation prompt behavior
- Domain validation rejects invalid input
- Site slug validation rejects invalid input
- Root privilege escalation is enforced
- Secure temp dir for backup transfer
- Git token sanitization after clone
- Rollback on partial failure
- Click command flags (--dry-run, --confirm, --domain)
"""

from __future__ import annotations

import subprocess
from importlib import import_module
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from sum.commands.promote import run_promote
from sum.exceptions import SetupError
from sum.system_config import (
    AgencyConfig,
    DefaultsConfig,
    ProductionConfig,
    StagingConfig,
    SystemConfig,
    TemplatesConfig,
    reset_system_config,
)

promote_module = import_module("sum.commands.promote")


@pytest.fixture(autouse=True)
def mock_privilege_escalation(monkeypatch):
    """Mock privilege escalation to always succeed for tests."""
    monkeypatch.setattr(
        promote_module, "require_root_or_escalate", lambda cmd, **kw: True
    )


@pytest.fixture(autouse=True)
def reset_config():
    """Reset config singleton before and after each test."""
    reset_system_config()
    yield
    reset_system_config()


@pytest.fixture
def mock_system_config(monkeypatch, tmp_path):
    """Mock system config with temp directories."""
    config = SystemConfig(
        agency=AgencyConfig(name="testco"),
        staging=StagingConfig(
            server="test-staging",
            domain_pattern="{slug}.test.site",
            base_dir=str(tmp_path / "srv" / "sum"),
        ),
        production=ProductionConfig(
            server="test-prod",
            ssh_host="192.168.1.1",
            base_dir="/srv/prod",
        ),
        templates=TemplatesConfig(
            dir="/opt/infra",
            systemd="systemd/test.service",
            caddy="caddy/test.caddy",
        ),
        defaults=DefaultsConfig(
            theme="theme_a",
            deploy_user="deploy",
            seed_profile="sage-stone",
        ),
    )

    monkeypatch.setattr(promote_module, "get_system_config", lambda: config)
    return config


def _create_staging_site(config: SystemConfig, slug: str) -> Path:
    """Helper: create a minimal staging site with git config."""
    site_dir = config.get_site_dir(slug, target="staging")
    site_dir.mkdir(parents=True, exist_ok=True)
    (site_dir / "app").mkdir(exist_ok=True)
    (site_dir / ".env").write_text("DJANGO_SECRET_KEY=test")

    # Create site config with git settings
    sum_dir = site_dir / ".sum"
    sum_dir.mkdir(exist_ok=True)
    (sum_dir / "config.yml").write_text(
        f"site:\n"
        f"  slug: {slug}\n"
        f"  theme: theme_a\n"
        f"  created: '2025-01-01T00:00:00'\n"
        f"git:\n"
        f"  provider: github\n"
        f"  org: testco\n"
        f"  token_env: GITHUB_TOKEN\n"
    )
    return site_dir


class TestPromoteValidation:
    """Tests for input validation in promote."""

    def test_rejects_invalid_domain(self, mock_system_config, capsys):
        """Invalid domain is rejected before any operations."""
        result = run_promote("acme", domain="not a domain!!!")
        assert result == 1

        captured = capsys.readouterr()
        assert "Invalid domain" in captured.out

    def test_rejects_empty_domain(self, mock_system_config, capsys):
        """Empty domain is rejected."""
        result = run_promote("acme", domain="")
        assert result == 1

        captured = capsys.readouterr()
        assert "must not be empty" in captured.out

    def test_rejects_invalid_site_slug(self, mock_system_config, capsys):
        """Invalid site slug is rejected before any operations."""
        result = run_promote("INVALID_SLUG!!!", domain="acme.example.com")
        assert result == 1

        captured = capsys.readouterr()
        assert "Invalid site slug" in captured.out

    def test_accepts_valid_domain(self, mock_system_config, capsys):
        """Valid domain passes validation (may fail later at staging check)."""
        result = run_promote("acme", domain="acme.example.com")
        # Will fail at "staging site not found" - but that means it passed validation
        assert result == 1
        captured = capsys.readouterr()
        assert "Staging site not found" in captured.out

    def test_nonexistent_staging_site(self, mock_system_config, capsys):
        """Non-existent staging site fails with clear error."""
        result = run_promote("acme", domain="acme.example.com")
        assert result == 1

        captured = capsys.readouterr()
        assert "Staging site not found" in captured.out


class TestPromoteDryRun:
    """Tests for --dry-run flag."""

    def test_dry_run_shows_preview(self, mock_system_config, tmp_path, capsys):
        """--dry-run shows planned steps without executing."""
        _create_staging_site(mock_system_config, "acme")

        result = run_promote("acme", domain="acme.example.com", dry_run=True)
        assert result == 0

        captured = capsys.readouterr()
        assert "Dry run" in captured.out
        assert "Backup staging database" in captured.out
        assert "No changes made" in captured.out

    def test_dry_run_does_not_execute(self, mock_system_config, tmp_path):
        """--dry-run does not call any subprocess commands."""
        _create_staging_site(mock_system_config, "acme")

        with patch("subprocess.run") as mock_run, patch("subprocess.Popen"):
            result = run_promote("acme", domain="acme.example.com", dry_run=True)

        assert result == 0
        # No subprocess calls should have been made
        mock_run.assert_not_called()

    def test_dry_run_lists_all_steps(self, mock_system_config, tmp_path, capsys):
        """--dry-run lists all 12 promote steps."""
        _create_staging_site(mock_system_config, "acme")

        run_promote("acme", domain="acme.example.com", dry_run=True)

        captured = capsys.readouterr()
        # Should list numbered steps
        assert " 1." in captured.out
        assert "12." in captured.out


class TestPromoteConfirmation:
    """Tests for confirmation prompt."""

    def test_prompts_for_confirmation(
        self, monkeypatch, mock_system_config, tmp_path, capsys
    ):
        """Promote prompts user to type the slug to confirm."""
        _create_staging_site(mock_system_config, "acme")

        monkeypatch.setattr("builtins.input", lambda _: "wrong-slug")

        result = run_promote("acme", domain="acme.example.com")
        assert result == 1

        captured = capsys.readouterr()
        assert "Confirmation did not match" in captured.out

    def test_correct_confirmation_proceeds(
        self, monkeypatch, mock_system_config, tmp_path
    ):
        """Correct confirmation allows promote to proceed."""
        _create_staging_site(mock_system_config, "acme")

        monkeypatch.setattr("builtins.input", lambda _: "acme")

        # Mock all the subprocess calls that happen during promote
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "/tmp/sum-promote-abcd1234\n"
        mock_result.stderr = ""

        with (
            patch("subprocess.run", return_value=mock_result),
            patch("subprocess.Popen") as mock_popen,
            patch.object(promote_module, "generate_password", return_value="testpw"),
            patch.object(promote_module, "generate_secret_key", return_value="testsk"),
            patch.object(
                promote_module,
                "get_git_provider_from_config",
                return_value=MagicMock(
                    get_clone_url=lambda org, slug: f"git@github.com:{org}/{slug}.git"
                ),
            ),
        ):
            # Mock Popen for pg_dump piped to gzip
            mock_pg_dump = MagicMock()
            mock_pg_dump.returncode = 0
            mock_pg_dump.stdout = MagicMock()
            mock_pg_dump.stderr = MagicMock()
            mock_pg_dump.stderr.read.return_value = b""
            mock_gzip = MagicMock()
            mock_gzip.communicate.return_value = (b"", b"")
            mock_gzip.returncode = 0
            mock_popen.side_effect = [mock_pg_dump, mock_gzip]

            result = run_promote("acme", domain="acme.example.com")

        # May fail at later stages, but not at confirmation
        # Exit code 0 or 1 acceptable (testing that confirmation passed, not full success)
        assert result in (0, 1)

    def test_skip_confirm_flag(self, monkeypatch, mock_system_config, tmp_path):
        """--confirm flag skips confirmation prompt."""
        _create_staging_site(mock_system_config, "acme")

        # Should NOT call input()
        def fail_input(_prompt):
            raise AssertionError("Should not prompt for confirmation")

        monkeypatch.setattr("builtins.input", fail_input)

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "/tmp/sum-promote-abcd1234\n"
        mock_result.stderr = ""

        with (
            patch("subprocess.run", return_value=mock_result),
            patch("subprocess.Popen") as mock_popen,
            patch.object(promote_module, "generate_password", return_value="testpw"),
            patch.object(promote_module, "generate_secret_key", return_value="testsk"),
            patch.object(
                promote_module,
                "get_git_provider_from_config",
                return_value=MagicMock(
                    get_clone_url=lambda org, slug: f"git@github.com:{org}/{slug}.git"
                ),
            ),
        ):
            mock_pg_dump = MagicMock()
            mock_pg_dump.returncode = 0
            mock_pg_dump.stdout = MagicMock()
            mock_pg_dump.stderr = MagicMock()
            mock_pg_dump.stderr.read.return_value = b""
            mock_gzip = MagicMock()
            mock_gzip.communicate.return_value = (b"", b"")
            mock_gzip.returncode = 0
            mock_popen.side_effect = [mock_pg_dump, mock_gzip]

            result = run_promote("acme", domain="acme.example.com", skip_confirm=True)

        # May fail at later stages, but not at confirmation
        # Exit code 0 or 1 acceptable (testing that confirmation was skipped, not full success)
        assert result in (0, 1)

    def test_keyboard_interrupt_aborts(self, monkeypatch, mock_system_config, tmp_path):
        """Ctrl+C during confirmation aborts gracefully."""
        _create_staging_site(mock_system_config, "acme")

        monkeypatch.setattr(
            "builtins.input", lambda _: (_ for _ in ()).throw(KeyboardInterrupt)
        )

        result = run_promote("acme", domain="acme.example.com")
        assert result == 130

    def test_eof_aborts(self, monkeypatch, mock_system_config, tmp_path):
        """EOF during confirmation aborts gracefully."""
        _create_staging_site(mock_system_config, "acme")

        monkeypatch.setattr("builtins.input", lambda _: (_ for _ in ()).throw(EOFError))

        result = run_promote("acme", domain="acme.example.com")
        assert result == 130


class TestPromoteSecureTempDir:
    """Tests for secure temp directory in backup transfer (SEC-04)."""

    def test_copy_backup_uses_mktemp(self, mock_system_config):
        """_copy_backup_to_prod creates a secure temp dir via mktemp."""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "/tmp/sum-promote-abcd1234\n"
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            result = promote_module._copy_backup_to_prod(
                Path("/staging/backups/test.sql.gz"), mock_system_config
            )

        # Should contain the mktemp-created directory
        assert "sum-promote-" in result
        assert result.endswith("test.sql.gz")

        # First call should be mktemp
        first_call = mock_run.call_args_list[0]
        assert "mktemp" in first_call[0][0]

        # Second call should be chmod 700
        second_call = mock_run.call_args_list[1]
        assert "chmod" in second_call[0][0]
        assert "700" in second_call[0][0]


class TestPromoteGitTokenSanitization:
    """Tests for git token sanitization after clone (SEC-05)."""

    def test_token_never_in_command_args(self, mock_system_config, tmp_path):
        """Token is piped via stdin, never appears in any process command args."""
        _create_staging_site(mock_system_config, "acme")

        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = (
                "ghp_faketoken123\n" if cmd == ["gh", "auth", "token"] else ""
            )
            return result

        mock_provider = MagicMock(
            get_clone_url=lambda org, slug: f"git@github.com:{org}/{slug}.git",
            get_repo_url=lambda org, slug: f"https://github.com/{org}/{slug}",
        )
        mock_git_config = MagicMock()
        mock_git_config.provider = "github"
        mock_git_config.org = "testco"

        with (
            patch("subprocess.run", side_effect=capture_run),
            patch.object(
                promote_module,
                "get_git_provider_from_config",
                return_value=mock_provider,
            ),
        ):
            promote_module._clone_repo_on_prod(
                "acme", mock_system_config, mock_git_config
            )

        # Token must NEVER appear in any command args (only in stdin)
        for call in calls:
            cmd_str = str(call["cmd"])
            if call["cmd"] != ["gh", "auth", "token"]:
                assert (
                    "ghp_faketoken123" not in cmd_str
                ), f"Token leaked into command args: {cmd_str}"

        # Token should be sent via stdin (input kwarg) exactly once
        stdin_calls = [
            c
            for c in calls
            if c["kwargs"].get("input") and "ghp_faketoken123" in c["kwargs"]["input"]
        ]
        assert len(stdin_calls) == 1, "Token should be piped via stdin exactly once"

    def test_remote_script_has_trap_cleanup(self, mock_system_config, tmp_path):
        """Remote script uses trap EXIT for unconditional ASKPASS cleanup."""
        _create_staging_site(mock_system_config, "acme")

        ssh_commands = []

        def capture_run(cmd, *args, **kwargs):
            if isinstance(cmd, list) and cmd[0] == "ssh":
                ssh_commands.append(cmd[-1])  # The remote script string
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = (
                "ghp_faketoken123\n" if cmd == ["gh", "auth", "token"] else ""
            )
            return result

        mock_provider = MagicMock(
            get_clone_url=lambda org, slug: f"git@github.com:{org}/{slug}.git",
            get_repo_url=lambda org, slug: f"https://github.com/{org}/{slug}",
        )
        mock_git_config = MagicMock()
        mock_git_config.provider = "github"
        mock_git_config.org = "testco"

        with (
            patch("subprocess.run", side_effect=capture_run),
            patch.object(
                promote_module,
                "get_git_provider_from_config",
                return_value=mock_provider,
            ),
        ):
            promote_module._clone_repo_on_prod(
                "acme", mock_system_config, mock_git_config
            )

        # First SSH command is the combined clone script
        assert len(ssh_commands) >= 1
        script = ssh_commands[0]

        # Script must include trap for unconditional cleanup
        assert "trap" in script, "Remote script must use trap for cleanup"
        assert "rm -f" in script, "Trap must remove ASKPASS file"
        assert "EXIT" in script, "Trap must fire on EXIT"

        # Script must include clone and set-url in the same call
        assert "git clone" in script
        assert "set-url" in script
        assert "git@github.com" in script

    def test_clone_failure_raises_setup_error(self, mock_system_config, tmp_path):
        """Clone failure raises SetupError with stderr details."""
        _create_staging_site(mock_system_config, "acme")

        def capture_run(cmd, *args, **kwargs):
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            if cmd == ["gh", "auth", "token"]:
                result.stdout = "ghp_faketoken123\n"
                return result
            # SSH call with the remote script → fail
            if isinstance(cmd, list) and cmd[0] == "ssh":
                raise subprocess.CalledProcessError(
                    128, cmd, stderr="fatal: repo not found"
                )
            result.stdout = ""
            return result

        mock_provider = MagicMock(
            get_clone_url=lambda org, slug: f"git@github.com:{org}/{slug}.git",
            get_repo_url=lambda org, slug: f"https://github.com/{org}/{slug}",
        )
        mock_git_config = MagicMock()
        mock_git_config.provider = "github"
        mock_git_config.org = "testco"

        with (
            patch("subprocess.run", side_effect=capture_run),
            patch.object(
                promote_module,
                "get_git_provider_from_config",
                return_value=mock_provider,
            ),
            pytest.raises(SetupError, match="clone"),
        ):
            promote_module._clone_repo_on_prod(
                "acme", mock_system_config, mock_git_config
            )


class TestPromoteSSHPreflight:
    """Tests for SSH preflight check before destructive operations."""

    def test_promote_ssh_preflight_unreachable(
        self, monkeypatch, mock_system_config, tmp_path, capsys
    ):
        """SSH failure to production host exits early with clear error."""
        _create_staging_site(mock_system_config, "acme")
        monkeypatch.setattr("builtins.input", lambda _: "acme")

        with patch(
            "subprocess.run",
            side_effect=subprocess.CalledProcessError(
                255, ["ssh"], stderr="Connection refused"
            ),
        ):
            result = run_promote("acme", domain="acme.example.com")

        assert result == 1
        captured = capsys.readouterr()
        assert "SSH connection" in captured.out
        assert "192.168.1.1" in captured.out

    def test_promote_ssh_preflight_timeout(
        self, monkeypatch, mock_system_config, tmp_path, capsys
    ):
        """SSH timeout to production host exits early with clean error."""
        _create_staging_site(mock_system_config, "acme")
        monkeypatch.setattr("builtins.input", lambda _: "acme")

        with patch(
            "subprocess.run",
            side_effect=subprocess.TimeoutExpired(["ssh"], 15),
        ):
            result = run_promote("acme", domain="acme.example.com")

        assert result == 1
        captured = capsys.readouterr()
        assert "timed out" in captured.out
        assert "192.168.1.1" in captured.out

    def test_promote_subprocess_error_messages_are_strings(self, mock_system_config):
        """Subprocess failures produce str error messages, not bytes literals."""
        # Trigger a CalledProcessError from _sync_media_to_prod with bytes stderr
        # to verify the error message doesn't contain b'...' literal representation
        staging_dir = _create_staging_site(mock_system_config, "acme")
        (staging_dir / "media").mkdir(exist_ok=True)

        with patch(
            "subprocess.run",
            side_effect=subprocess.CalledProcessError(
                1, ["rsync"], stderr=b"rsync: connection unexpectedly closed"
            ),
        ):
            with pytest.raises(SetupError) as exc_info:
                promote_module._sync_media_to_prod("acme", mock_system_config)

            error_msg = str(exc_info.value)
            # The error message should contain the text, not bytes literal
            assert "rsync" in error_msg
            assert (
                "b'" not in error_msg
            ), f"Error message contains bytes literal: {error_msg}"


class TestPromoteRollback:
    """Tests for rollback on partial failure."""

    def _run_promote_failing_at_step(
        self, monkeypatch, mock_system_config, fail_step_number
    ):
        """Helper: run promote that fails at a specific step number.

        Patches all step functions as no-ops except the target which raises.
        Returns (exit_code, subprocess_run_calls).
        """
        from contextlib import ExitStack

        _create_staging_site(mock_system_config, "acme")
        monkeypatch.setattr("builtins.input", lambda _: "acme")

        calls = []

        def mock_subprocess_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            result = MagicMock()
            result.returncode = 0
            result.stdout = ""
            result.stderr = ""
            return result

        # Map step numbers to function names
        step_functions = {
            1: "_backup_staging_db",
            2: "_copy_backup_to_prod",
            3: "_provision_prod_infrastructure",
            4: "_clone_repo_on_prod",
            5: "_setup_venv_on_prod",
            6: "_restore_db_on_prod",
            7: "_sync_media_to_prod",
            8: "_run_django_setup_on_prod",
            9: "_install_systemd_on_prod",
            10: "_configure_caddy_on_prod",
            11: "_start_service_on_prod",
            12: "_write_site_config_on_prod",
        }

        # Default return values for functions that return something
        step_defaults = {
            "_backup_staging_db": Path("/staging/backups/acme_promote.sql.gz"),
            "_copy_backup_to_prod": "/tmp/sum-promote-abcd1234/acme_promote.sql.gz",
            "_provision_prod_infrastructure": {
                "db_name": "acme",
                "db_user": "acme",
                "db_password": "pw",
                "secret_key": "sk",
                "db_port": "5433",
            },
        }

        target_fn = step_functions[fail_step_number]

        patches = [
            patch("subprocess.run", side_effect=mock_subprocess_run),
            patch.object(promote_module, "generate_password", return_value="testpw"),
            patch.object(promote_module, "generate_secret_key", return_value="testsk"),
            patch.object(
                promote_module,
                "get_git_provider_from_config",
                return_value=MagicMock(
                    get_clone_url=lambda org, slug: f"git@github.com:{org}/{slug}.git",
                    get_repo_url=lambda org, slug: f"https://github.com/{org}/{slug}",
                ),
            ),
        ]

        for fn_name in step_functions.values():
            if fn_name == target_fn:
                patches.append(
                    patch.object(
                        promote_module,
                        fn_name,
                        side_effect=SetupError(f"Step {fail_step_number} failed"),
                    )
                )
            else:
                patches.append(
                    patch.object(
                        promote_module,
                        fn_name,
                        return_value=step_defaults.get(fn_name),
                    )
                )

        with ExitStack() as stack:
            for p in patches:
                stack.enter_context(p)
            result = run_promote("acme", domain="acme.example.com")

        return result, calls

    def test_promote_rollback_on_db_restore_failure(
        self, monkeypatch, mock_system_config, capsys
    ):
        """Failure at step 6 (restore DB) triggers cleanup of steps 1-5."""
        result, calls = self._run_promote_failing_at_step(
            monkeypatch, mock_system_config, fail_step_number=6
        )

        assert result == 1
        captured = capsys.readouterr()
        assert "Step 6 failed" in captured.out
        assert "Cleaning up" in captured.out

    def test_promote_rollback_on_systemd_failure(
        self, monkeypatch, mock_system_config, capsys
    ):
        """Failure at step 9 (systemd) triggers cleanup including partial systemd state."""
        result, calls = self._run_promote_failing_at_step(
            monkeypatch, mock_system_config, fail_step_number=9
        )

        assert result == 1
        captured = capsys.readouterr()
        assert "Step 9 failed" in captured.out
        assert "Cleaning up" in captured.out

    def test_promote_rollback_on_caddy_failure(
        self, monkeypatch, mock_system_config, capsys
    ):
        """Failure at step 10 (Caddy) triggers full cleanup including systemd."""
        result, calls = self._run_promote_failing_at_step(
            monkeypatch, mock_system_config, fail_step_number=10
        )

        assert result == 1
        captured = capsys.readouterr()
        assert "Step 10 failed" in captured.out
        assert "Cleaning up" in captured.out

    def test_promote_cleanup_failure_shows_runbook(
        self, monkeypatch, mock_system_config, capsys
    ):
        """Failed cleanup prints a manual recovery runbook to stderr."""
        _create_staging_site(mock_system_config, "acme")

        # Return a non-zero exit code from cleanup subprocess calls
        failed_result = MagicMock()
        failed_result.returncode = 1
        failed_result.stderr = "Permission denied"
        failed_result.stdout = ""

        with patch(
            "subprocess.run",
            return_value=failed_result,
        ):
            promote_module._cleanup_prod_on_failure(
                ["provision_infra", "install_systemd", "configure_caddy"],
                "acme",
                mock_system_config,
            )

        captured = capsys.readouterr()
        assert "MANUAL RECOVERY REQUIRED" in captured.err
        assert "systemctl stop" in captured.err
        assert "pg_dropcluster" in captured.err
        assert "ports.json" in captured.err

    def test_promote_cleanup_does_not_mask_error(
        self, monkeypatch, mock_system_config, capsys
    ):
        """Original error always surfaces even when cleanup also fails."""
        _create_staging_site(mock_system_config, "acme")
        monkeypatch.setattr("builtins.input", lambda _: "acme")

        call_count = 0

        def mock_run(cmd, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            # SSH preflight succeeds (first call)
            if call_count == 1:
                result = MagicMock()
                result.returncode = 0
                result.stdout = ""
                result.stderr = ""
                return result
            # All other calls succeed
            result = MagicMock()
            result.returncode = 0
            result.stdout = "/tmp/sum-promote-abcd1234\n"
            result.stderr = ""
            return result

        with (
            patch("subprocess.run", side_effect=mock_run),
            patch("subprocess.Popen") as mock_popen,
            patch.object(promote_module, "generate_password", return_value="testpw"),
            patch.object(promote_module, "generate_secret_key", return_value="testsk"),
            patch.object(
                promote_module,
                "get_git_provider_from_config",
                return_value=MagicMock(
                    get_clone_url=lambda org, slug: f"git@github.com:{org}/{slug}.git",
                    get_repo_url=lambda org, slug: f"https://github.com/{org}/{slug}",
                ),
            ),
            patch.object(
                promote_module,
                "_provision_prod_infrastructure",
                return_value={
                    "db_name": "acme",
                    "db_user": "acme",
                    "db_password": "pw",
                    "secret_key": "sk",
                    "db_port": "5433",
                },
            ),
            patch.object(
                promote_module,
                "_restore_db_on_prod",
                side_effect=SetupError("Database restore exploded"),
            ),
            patch.object(
                promote_module,
                "_cleanup_prod_on_failure",
                wraps=promote_module._cleanup_prod_on_failure,
            ) as mock_cleanup,
        ):
            mock_pg_dump = MagicMock()
            mock_pg_dump.returncode = 0
            mock_pg_dump.stdout = MagicMock()
            mock_pg_dump.stderr = MagicMock()
            mock_pg_dump.stderr.read.return_value = b""
            mock_gzip = MagicMock()
            mock_gzip.communicate.return_value = (b"", b"")
            mock_gzip.returncode = 0
            mock_popen.side_effect = [mock_pg_dump, mock_gzip]

            result = run_promote("acme", domain="acme.example.com")

        # Original error must surface
        assert result == 1
        captured = capsys.readouterr()
        assert "Database restore exploded" in captured.out

        # Cleanup must have been called
        mock_cleanup.assert_called_once()


class TestPromoteSiteConfig:
    """Tests for writing site config on production."""

    def test_promote_writes_site_config(self, mock_system_config):
        """_write_site_config_on_prod sends correct YAML via SSH tee."""
        from datetime import datetime

        from sum.site_config import GitConfig, SiteConfig

        site_config = SiteConfig(
            slug="acme",
            theme="theme_a",
            created=datetime(2025, 1, 1),
            git=GitConfig(
                provider="github",
                org="testco",
                token_env="GITHUB_TOKEN",
            ),
        )

        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""
            return result

        with patch("subprocess.run", side_effect=capture_run):
            promote_module._write_site_config_on_prod(
                "acme", mock_system_config, site_config
            )

        # Should have 3 calls: mkdir, tee, chmod
        assert len(calls) == 3

        # First call: mkdir -p .sum
        assert "mkdir" in calls[0]["cmd"]
        assert ".sum" in " ".join(calls[0]["cmd"])

        # Second call: tee with YAML content
        assert "tee" in " ".join(calls[1]["cmd"])
        yaml_input = calls[1]["kwargs"]["input"]
        assert "slug: acme" in yaml_input
        assert "theme: theme_a" in yaml_input
        assert "provider: github" in yaml_input
        assert "org: testco" in yaml_input
        assert "token_env: GITHUB_TOKEN" in yaml_input

        # Third call: chmod 644
        assert "chmod" in calls[2]["cmd"]
        assert "644" in calls[2]["cmd"]

    def test_promote_site_config_matches_staging(self, mock_system_config, tmp_path):
        """YAML written by _write_site_config_on_prod can be parsed by SiteConfig.load()."""
        from datetime import datetime

        from sum.site_config import GitConfig, SiteConfig

        site_config = SiteConfig(
            slug="acme",
            theme="theme_a",
            created=datetime(2025, 1, 1),
            git=GitConfig(
                provider="github",
                org="testco",
                token_env="GITHUB_TOKEN",
            ),
        )

        captured_yaml = {}

        def capture_run(cmd, *args, **kwargs):
            if "tee" in " ".join(cmd):
                captured_yaml["content"] = kwargs.get("input", "")
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""
            return result

        with patch("subprocess.run", side_effect=capture_run):
            promote_module._write_site_config_on_prod(
                "acme", mock_system_config, site_config
            )

        # Write the captured YAML to disk and load it via SiteConfig.load()
        site_dir = tmp_path / "test-site"
        sum_dir = site_dir / ".sum"
        sum_dir.mkdir(parents=True)
        (sum_dir / "config.yml").write_text(captured_yaml["content"])

        loaded = SiteConfig.load(site_dir)
        assert loaded.slug == "acme"
        assert loaded.theme == "theme_a"
        assert loaded.created == datetime(2025, 1, 1)
        assert loaded.git is not None
        assert loaded.git.provider == "github"
        assert loaded.git.org == "testco"
        assert loaded.git.token_env == "GITHUB_TOKEN"


class TestPromoteClickCommand:
    """Tests for the click command wiring."""

    def test_click_command_exists(self):
        """The promote click command is registered."""
        from sum.commands.promote import promote

        assert callable(promote)

    def test_click_command_has_dry_run_flag(self):
        """The promote command has --dry-run flag."""
        import click
        from sum.commands.promote import promote

        if isinstance(promote, click.BaseCommand):
            param_names = [p.name for p in promote.params]
            assert "dry_run" in param_names

    def test_click_command_has_confirm_flag(self):
        """The promote command has --confirm flag."""
        import click
        from sum.commands.promote import promote

        if isinstance(promote, click.BaseCommand):
            param_names = [p.name for p in promote.params]
            assert "skip_confirm" in param_names

    def test_click_command_has_domain_option(self):
        """The promote command has --domain option."""
        import click
        from sum.commands.promote import promote

        if isinstance(promote, click.BaseCommand):
            param_names = [p.name for p in promote.params]
            assert "domain" in param_names

    def test_promote_registered_in_cli(self):
        """Promote command is registered in main CLI group."""
        from sum.cli import cli

        command_names = list(cli.commands.keys())
        assert "promote" in command_names


class TestPromoteIsolatedCluster:
    """Tests for isolated PostgreSQL cluster provisioning on production."""

    def test_promote_creates_isolated_cluster(self, mock_system_config):
        """pg_createcluster called with correct args via SSH."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            if isinstance(cmd, list) and cmd[0] == "ssh":
                if "python3" in cmd_str:
                    # Atomic port allocator returns port
                    result.stdout = "5433\n"
                elif "pg_lsclusters" in cmd_str:
                    result.stdout = ""  # No existing clusters
                elif "pg_isready" in cmd_str:
                    result.stdout = ""
                    result.returncode = 0
                else:
                    result.stdout = ""
            else:
                result.stdout = ""
            return result

        with patch("subprocess.run", side_effect=capture_run):
            port = promote_module._provision_remote_postgres("acme", mock_system_config)

        assert isinstance(port, int)
        assert port >= 5433

        # Find the pg_createcluster SSH call
        create_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list)
            and c["cmd"][0] == "ssh"
            and "pg_createcluster" in c["cmd"][-1]
        ]
        assert len(create_calls) == 1
        remote_cmd = create_calls[0]["cmd"][-1]
        assert "18" in remote_cmd
        assert "acme" in remote_cmd
        assert "--start-conf=auto" in remote_cmd

    def test_promote_allocates_remote_port(self, mock_system_config):
        """Port allocation uses atomic inline Python script via SSH under flock."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            # The atomic allocator outputs the port number to stdout
            if isinstance(cmd, list) and cmd[0] == "ssh" and "python3" in cmd_str:
                result.stdout = "5433\n"
            else:
                result.stdout = ""
            return result

        with patch("subprocess.run", side_effect=capture_run):
            port = promote_module._allocate_remote_port("acme", mock_system_config)

        assert port == 5433  # First port in default range

        # Should have a single SSH call with flock + python3
        flock_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list)
            and c["cmd"][0] == "ssh"
            and "flock" in " ".join(c["cmd"])
            and "python3" in " ".join(c["cmd"])
        ]
        assert len(flock_calls) == 1

        # Verify the inline script contains the right site_slug and ports file
        script_input = flock_calls[0]["kwargs"]["input"]
        assert "acme" in script_input
        assert "ports.json" in script_input

        # Verify flock is used
        cmd_str = " ".join(flock_calls[0]["cmd"])
        assert "flock" in cmd_str
        assert "sudo" in cmd_str

    def test_promote_idempotent_cluster(self, mock_system_config):
        """Existing cluster detected and reused (no pg_createcluster call)."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append(cmd)
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""

            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            if isinstance(cmd, list) and cmd[0] == "ssh":
                # pg_lsclusters: cluster already exists (checked first)
                if "pg_lsclusters" in cmd_str:
                    result.stdout = "18 acme 5433 online postgres\n"
                # Atomic port allocator (called for registry consistency)
                elif "python3" in cmd_str:
                    result.stdout = "5433\n"
                else:
                    result.stdout = ""
            else:
                result.stdout = ""
            return result

        with patch("subprocess.run", side_effect=capture_run):
            port = promote_module._provision_remote_postgres("acme", mock_system_config)

        assert port == 5433

        # pg_createcluster should NOT have been called
        all_cmds = [" ".join(c) if isinstance(c, list) else str(c) for c in calls]
        assert not any(
            "pg_createcluster" in c for c in all_cmds
        ), f"pg_createcluster should not be called for existing cluster, but got: {all_cmds}"

    def test_promote_env_has_allocated_port(self, mock_system_config):
        """Provisioned .env written with correct DJANGO_DB_PORT."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            if isinstance(cmd, list) and cmd[0] == "ssh":
                if "python3" in cmd_str:
                    # Atomic port allocator returns port
                    result.stdout = "5433\n"
                elif "pg_lsclusters" in cmd_str:
                    result.stdout = ""
                elif "pg_isready" in cmd_str:
                    result.stdout = ""
                    result.returncode = 0
                else:
                    result.stdout = ""
            else:
                result.stdout = ""
            return result

        with (
            patch("subprocess.run", side_effect=capture_run),
            patch.object(promote_module, "generate_password", return_value="testpw"),
            patch.object(promote_module, "generate_secret_key", return_value="testsk"),
        ):
            credentials = promote_module._provision_prod_infrastructure(
                "acme", "acme.example.com", mock_system_config
            )

        assert "db_port" in credentials
        db_port = int(credentials["db_port"])
        assert db_port >= 5433

        # Find the tee call that writes .env
        env_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list)
            and c["cmd"][0] == "ssh"
            and "tee" in str(c["cmd"])
            and ".env" in str(c["cmd"])
            and c["kwargs"].get("input")
            and "DJANGO_DB_PORT" in c["kwargs"]["input"]
        ]
        assert len(env_calls) == 1
        env_content = env_calls[0]["kwargs"]["input"]
        assert f"DJANGO_DB_PORT={db_port}" in env_content
        # Must NOT contain hardcoded 5432
        assert "DJANGO_DB_PORT=5432" not in env_content

    def test_promote_db_restore_uses_allocated_port(self, mock_system_config):
        """psql called with -p <port> for DB restore."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            result = MagicMock()
            result.returncode = 0
            result.stdout = ""
            result.stderr = ""
            return result

        with patch("subprocess.run", side_effect=capture_run):
            promote_module._restore_db_on_prod(
                "acme",
                "/tmp/sum-promote-abcd/acme_promote.sql.gz",
                mock_system_config,
                db_port=5433,
            )

        # Should have one SSH call with psql -p 5433
        ssh_calls = [
            c for c in calls if isinstance(c["cmd"], list) and c["cmd"][0] == "ssh"
        ]
        assert len(ssh_calls) == 1
        remote_cmd = ssh_calls[0]["cmd"][-1]
        assert "-p" in remote_cmd
        assert "5433" in remote_cmd
        assert "psql" in remote_cmd

    def test_promote_port_exhaustion(self, mock_system_config):
        """SetupError raised when all ports in range are allocated."""

        def capture_run(cmd, *args, **kwargs):
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            if isinstance(cmd, list) and cmd[0] == "ssh" and "python3" in cmd_str:
                # Simulate the remote script failing due to port exhaustion
                raise subprocess.CalledProcessError(
                    1,
                    cmd,
                    stderr="No available ports in range 5433-5532 on production. "
                    "Maximum of 100 PostgreSQL sites reached.",
                )
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""
            return result

        with (
            patch("subprocess.run", side_effect=capture_run),
            pytest.raises(SetupError, match="No available ports"),
        ):
            promote_module._allocate_remote_port("new-site", mock_system_config)

    def test_promote_cluster_creation_failure(self, mock_system_config):
        """SetupError raised when pg_createcluster fails on production."""

        def capture_run(cmd, *args, **kwargs):
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            if isinstance(cmd, list) and cmd[0] == "ssh":
                if "pg_lsclusters" in cmd_str:
                    result.stdout = ""  # No existing clusters
                elif "python3" in cmd_str:
                    # Atomic port allocator returns port
                    result.stdout = "5433\n"
                elif "pg_createcluster" in cmd_str:
                    raise subprocess.CalledProcessError(
                        1, cmd, stderr="Error: cluster already exists"
                    )
                else:
                    result.stdout = ""
            else:
                result.stdout = ""
            return result

        with (
            patch("subprocess.run", side_effect=capture_run),
            pytest.raises(SetupError, match="Failed to create PostgreSQL cluster"),
        ):
            promote_module._provision_remote_postgres("acme", mock_system_config)

    def test_promote_deallocate_remote_port(self, mock_system_config):
        """_deallocate_remote_port runs atomic inline script via SSH."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""
            return result

        with patch("subprocess.run", side_effect=capture_run):
            promote_module._deallocate_remote_port("acme", mock_system_config)

        # Should have a single SSH call with flock + python3
        flock_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list)
            and c["cmd"][0] == "ssh"
            and "flock" in " ".join(c["cmd"])
            and "python3" in " ".join(c["cmd"])
        ]
        assert len(flock_calls) == 1

        # Verify the inline script targets the right site_slug
        script_input = flock_calls[0]["kwargs"]["input"]
        assert "acme" in script_input
        assert "del ports[site_slug]" in script_input


class TestPromotePgBackRest:
    """Tests for pgBackRest configuration and backup cron on production."""

    @pytest.fixture
    def mock_system_config_with_backups(self, monkeypatch, tmp_path):
        """Mock system config with backups configured."""
        from sum.system_config import (
            AlertsConfig,
            BackupsConfig,
            InfrastructureConfig,
            RetentionConfig,
            StorageBoxConfig,
        )

        # Create a cipher pass file
        cipher_file = tmp_path / "cipher-pass"
        cipher_file.write_text("DUMMY-TEST-PASSPHRASE-NOT-REAL")

        # Create a pgbackrest stanza template
        template_dir = tmp_path / "templates"
        template_dir.mkdir()
        stanza_template = template_dir / "pgbackrest-stanza.conf"
        stanza_template.write_text(
            "[__SITE_SLUG__]\n"
            "pg1-path=/var/lib/postgresql/__POSTGRES_VERSION__/__SITE_SLUG__\n"
            "pg1-port=__POSTGRES_PORT__\n"
            "repo1-retention-full=__RETENTION_FULL__\n"
        )

        config = SystemConfig(
            agency=AgencyConfig(name="testco"),
            staging=StagingConfig(
                server="test-staging",
                domain_pattern="{slug}.test.site",
                base_dir=str(tmp_path / "srv" / "sum"),
            ),
            production=ProductionConfig(
                server="test-prod",
                ssh_host="192.168.1.1",
                base_dir="/srv/prod",
            ),
            templates=TemplatesConfig(
                dir=str(template_dir),
                systemd="systemd/test.service",
                caddy="caddy/test.caddy",
                pgbackrest_stanza="pgbackrest-stanza.conf",
            ),
            defaults=DefaultsConfig(
                theme="theme_a",
                deploy_user="deploy",
                seed_profile="sage-stone",
            ),
            infrastructure=InfrastructureConfig(
                postgres_version="18",
            ),
            backups=BackupsConfig(
                storage_box=StorageBoxConfig(
                    host="backup.example.com",
                    user="backup-user",
                    fingerprint="SHA256:test",
                    port=23,
                    ssh_key="/etc/sum/backup-key-rsa",
                    base_path="/backups",
                ),
                retention=RetentionConfig(full_backups=2, diff_backups=7),
                alerts=AlertsConfig(email="ops@example.com"),
                cipher_pass_file=str(cipher_file),
            ),
        )

        monkeypatch.setattr(promote_module, "get_system_config", lambda: config)
        return config

    def test_promote_configures_wal_archiving(self, mock_system_config_with_backups):
        """WAL archiving config appended to postgresql.conf via SSH sudo tee -a."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            # sudo grep for existing config returns 1 (not found)
            if isinstance(cmd, list) and cmd[0] == "ssh" and "grep" in cmd_str:
                result.returncode = 1
            # pg_isready succeeds
            elif isinstance(cmd, list) and cmd[0] == "ssh" and "pg_isready" in cmd_str:
                result.returncode = 0
            return result

        with patch("subprocess.run", side_effect=capture_run):
            promote_module._configure_remote_wal_archiving(
                "acme", 5433, mock_system_config_with_backups
            )

        # WAL idempotency check uses sudo grep
        grep_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list)
            and c["cmd"][0] == "ssh"
            and "grep" in " ".join(c["cmd"])
        ]
        assert len(grep_calls) == 1
        assert "sudo grep" in " ".join(grep_calls[0]["cmd"])

        # N2: WAL config appended via sudo tee -a (not printf)
        tee_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list)
            and c["cmd"][0] == "ssh"
            and "tee -a" in " ".join(c["cmd"])
        ]
        assert len(tee_calls) == 1
        assert "sudo tee" in " ".join(tee_calls[0]["cmd"])
        # WAL config piped via stdin
        wal_input = tee_calls[0]["kwargs"]["input"]
        assert "wal_level = replica" in wal_input
        assert "archive_mode = on" in wal_input
        assert "pgbackrest-wrapper" in wal_input
        assert "archive-push" in wal_input
        assert "acme" in wal_input

        # Cluster must be restarted after WAL config
        restart_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list)
            and c["cmd"][0] == "ssh"
            and "restart" in " ".join(c["cmd"])
        ]
        assert len(restart_calls) == 1

    def test_promote_creates_pgbackrest_stanza(self, mock_system_config_with_backups):
        """pgBackRest stanza config written with sudo and stanza-create run."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            # test -f for stanza file returns 1 (not found)
            if isinstance(cmd, list) and cmd[0] == "ssh" and "test -f" in cmd_str:
                result.returncode = 1
            # pgbackrest info returns 1 (stanza not initialised)
            elif isinstance(cmd, list) and cmd[0] == "ssh" and " info" in cmd_str:
                result.returncode = 1
            return result

        with patch("subprocess.run", side_effect=capture_run):
            promote_module._configure_remote_pgbackrest(
                "acme", 5433, mock_system_config_with_backups
            )

        # Should install pgbackrest wrapper via SSH (stdin-piped, atomic)
        wrapper_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list)
            and c["cmd"][0] == "ssh"
            and "pgbackrest-wrapper" in " ".join(c["cmd"])
            and "chmod 750" in " ".join(c["cmd"])
        ]
        assert len(wrapper_calls) == 1
        # Validate the wrapper script content piped via stdin
        wrapper_input = wrapper_calls[0]["kwargs"]["input"]
        assert wrapper_input.startswith("#!/bin/sh\n")
        assert "PGBACKREST_REPO1_CIPHER_PASS" in wrapper_input
        assert 'exec /usr/bin/pgbackrest "$@"' in wrapper_input
        # Uses shell built-in read and has readability guard
        assert "read -r PGBACKREST_REPO1_CIPHER_PASS" in wrapper_input
        assert 'test -r "$PASS_FILE"' in wrapper_input
        # Must NOT contain backslash-escaped quotes (shell-escaping bug)
        assert '\\"' not in wrapper_input

        # Should write stanza config via sudo tee (exclude wrapper tee and cron tee)
        tee_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list)
            and c["cmd"][0] == "ssh"
            and "sudo tee" in " ".join(c["cmd"])
            and "tee -a" not in " ".join(c["cmd"])
            and "pgbackrest-wrapper" not in " ".join(c["cmd"])
        ]
        assert len(tee_calls) == 1
        stanza_cmd = " ".join(tee_calls[0]["cmd"])
        assert "sudo mkdir" in stanza_cmd
        assert "sudo tee" in stanza_cmd
        assert "sudo chown" in stanza_cmd
        assert "sudo chmod" in stanza_cmd
        stanza_input = tee_calls[0]["kwargs"]["input"]
        assert "[acme]" in stanza_input
        assert "5433" in stanza_input
        # Cipher passphrase must NOT appear in stanza config (uses wrapper instead)
        assert "cipher-pass" not in stanza_input.lower()
        assert "DUMMY-TEST-PASSPHRASE-NOT-REAL" not in stanza_input

        # Should run stanza-create
        stanza_create_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list)
            and c["cmd"][0] == "ssh"
            and "stanza-create" in " ".join(c["cmd"])
        ]
        assert len(stanza_create_calls) == 1

    def test_promote_installs_backup_cron(self, mock_system_config_with_backups):
        """Backup cron entries installed on production via SSH with sudo."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            # sudo grep for existing cron entry returns 1 (not found)
            if isinstance(cmd, list) and cmd[0] == "ssh" and "grep" in cmd_str:
                result.returncode = 1
            return result

        with patch("subprocess.run", side_effect=capture_run):
            promote_module._install_remote_backup_cron(
                "acme", mock_system_config_with_backups
            )

        # Cron idempotency check uses sudo grep
        grep_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list)
            and c["cmd"][0] == "ssh"
            and "grep" in " ".join(c["cmd"])
        ]
        assert len(grep_calls) == 1
        assert "sudo grep" in " ".join(grep_calls[0]["cmd"])

        # Should append cron entries via sudo flock ... tee -a (N5: flock for concurrency)
        tee_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list)
            and c["cmd"][0] == "ssh"
            and "tee -a" in " ".join(c["cmd"])
        ]
        assert len(tee_calls) == 1
        tee_cmd_str = " ".join(tee_calls[0]["cmd"])
        assert "sudo flock" in tee_cmd_str
        assert "tee -a" in tee_cmd_str
        cron_input = tee_calls[0]["kwargs"]["input"]

        # Must contain site marker comment
        assert "# acme" in cron_input
        # Must have full backup on Sunday
        assert "* * 0" in cron_input
        assert "--type=full" in cron_input
        # Must have diff backup Mon-Sat
        assert "* * 1-6" in cron_input
        assert "--type=diff" in cron_input
        # Must use pgbackrest with config-include-path
        assert "pgbackrest" in cron_input
        assert "--config-include-path=" in cron_input
        # Must have logger for syslog
        assert "logger" in cron_input
        # Must use bash pipefail wrapper
        assert "bash -o pipefail" in cron_input
        # Must escape % for cron.d (cron interprets % as newline)
        assert "\\%s" in cron_input

    def test_promote_pgbackrest_idempotent(self, mock_system_config_with_backups):
        """All backup steps skip when already configured (idempotent)."""

        def capture_run(cmd, *args, **kwargs):
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            # sudo grep for WAL config / cron entry returns 0 (already exists)
            if isinstance(cmd, list) and cmd[0] == "ssh" and "grep" in cmd_str:
                result.returncode = 0
            # test -f for stanza file returns 0 (already exists)
            elif isinstance(cmd, list) and cmd[0] == "ssh" and "test -f" in cmd_str:
                result.returncode = 0
            # pgbackrest info returns 0 with backup data (already initialised)
            elif (
                isinstance(cmd, list)
                and cmd[0] == "ssh"
                and " info" in cmd_str
                and "--output=json" in cmd_str
            ):
                result.stdout = '[{"backup": [{"type": "full"}]}]'
            elif isinstance(cmd, list) and cmd[0] == "ssh" and " info" in cmd_str:
                result.returncode = 0
            return result

        calls = []

        def tracking_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            return capture_run(cmd, *args, **kwargs)

        with patch("subprocess.run", side_effect=tracking_run):
            # WAL archiving should skip
            promote_module._configure_remote_wal_archiving(
                "acme", 5433, mock_system_config_with_backups
            )
            wal_call_count = len(calls)

            # pgBackRest stanza should skip (file exists + stanza initialised)
            promote_module._configure_remote_pgbackrest(
                "acme", 5433, mock_system_config_with_backups
            )
            pgbackrest_call_count = len(calls) - wal_call_count

            # Initial backup should skip (backup exists)
            promote_module._run_remote_initial_backup(
                "acme", mock_system_config_with_backups
            )
            backup_call_count = len(calls) - wal_call_count - pgbackrest_call_count

            # Cron should skip
            promote_module._install_remote_backup_cron(
                "acme", mock_system_config_with_backups
            )
            cron_call_count = (
                len(calls) - wal_call_count - pgbackrest_call_count - backup_call_count
            )

        # WAL archiving: only the grep check (1 call)
        assert (
            wal_call_count == 1
        ), f"Expected 1 call for WAL idempotency check, got {wal_call_count}"
        # pgBackRest: wrapper install + test -f check + info check (3 calls)
        assert (
            pgbackrest_call_count == 3
        ), f"Expected 3 calls for pgBackRest (wrapper + idempotency checks), got {pgbackrest_call_count}"
        # Initial backup: info --output=json check (1 call)
        assert (
            backup_call_count == 1
        ), f"Expected 1 call for backup idempotency check, got {backup_call_count}"
        # Cron: only the grep check (1 call)
        assert (
            cron_call_count == 1
        ), f"Expected 1 call for cron idempotency check, got {cron_call_count}"

    def test_promote_stanza_create_failure(self, mock_system_config_with_backups):
        """Partial retry works: stanza file written but stanza-create fails."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            # Stanza file already exists (written on previous attempt)
            if isinstance(cmd, list) and cmd[0] == "ssh" and "test -f" in cmd_str:
                result.returncode = 0
            # Stanza NOT initialised (previous stanza-create failed)
            elif isinstance(cmd, list) and cmd[0] == "ssh" and " info" in cmd_str:
                result.returncode = 1
            # stanza-create succeeds on retry
            elif (
                isinstance(cmd, list) and cmd[0] == "ssh" and "stanza-create" in cmd_str
            ):
                result.returncode = 0
            return result

        with patch("subprocess.run", side_effect=capture_run):
            promote_module._configure_remote_pgbackrest(
                "acme", 5433, mock_system_config_with_backups
            )

        # Should NOT re-write stanza file (already exists)
        # Exclude wrapper install (which also uses tee)
        tee_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list)
            and c["cmd"][0] == "ssh"
            and "sudo tee" in " ".join(c["cmd"])
            and "tee -a" not in " ".join(c["cmd"])
            and "pgbackrest-wrapper" not in " ".join(c["cmd"])
        ]
        assert len(tee_calls) == 0, "Should not re-write stanza file"

        # Should still run stanza-create (stanza not initialised)
        stanza_create_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list)
            and c["cmd"][0] == "ssh"
            and "stanza-create" in " ".join(c["cmd"])
        ]
        assert len(stanza_create_calls) == 1

    def test_promote_dry_run_with_backups(
        self, mock_system_config_with_backups, tmp_path, capsys
    ):
        """Dry-run shows 14 steps when backups are configured."""
        _create_staging_site(mock_system_config_with_backups, "acme")

        result = run_promote("acme", domain="acme.example.com", dry_run=True)
        assert result == 0

        captured = capsys.readouterr()
        assert "14." in captured.out
        assert "pgBackRest" in captured.out
        assert "backup cron" in captured.out

    # ---- W1: Happy-path test for _run_remote_initial_backup ----

    def test_promote_runs_initial_backup(self, mock_system_config_with_backups):
        """Initial full backup runs when no existing backup is found."""
        calls = []

        def capture_run(cmd, *args, **kwargs):
            calls.append({"cmd": cmd, "kwargs": kwargs})
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            # pgbackrest info --output=json returns empty backup list
            if (
                isinstance(cmd, list)
                and cmd[0] == "ssh"
                and " info" in cmd_str
                and "--output=json" in cmd_str
            ):
                result.stdout = '[{"backup": []}]'
            return result

        with patch("subprocess.run", side_effect=capture_run):
            promote_module._run_remote_initial_backup(
                "acme", mock_system_config_with_backups
            )

        # Should issue a full backup command via SSH
        backup_calls = [
            c
            for c in calls
            if isinstance(c["cmd"], list)
            and c["cmd"][0] == "ssh"
            and "--type=full" in " ".join(c["cmd"])
            and "backup" in " ".join(c["cmd"])
        ]
        assert len(backup_calls) == 1
        backup_cmd = " ".join(backup_calls[0]["cmd"])
        assert "pgbackrest" in backup_cmd
        assert "--type=full" in backup_cmd
        assert "backup" in backup_cmd

    # ---- N2: Failure-path test for _run_remote_initial_backup ----

    def test_promote_initial_backup_failure(self, mock_system_config_with_backups):
        """CalledProcessError from backup SSH command raises SetupError."""

        def capture_run(cmd, *args, **kwargs):
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            # pgbackrest info --output=json returns empty backup list
            if (
                isinstance(cmd, list)
                and cmd[0] == "ssh"
                and " info" in cmd_str
                and "--output=json" in cmd_str
            ):
                result.stdout = '[{"backup": []}]'
            # Backup command fails
            elif (
                isinstance(cmd, list)
                and cmd[0] == "ssh"
                and "--type=full" in cmd_str
                and "backup" in cmd_str
            ):
                raise subprocess.CalledProcessError(
                    1, cmd, output="P00  ERROR: backup failed"
                )
            return result

        with (
            patch("subprocess.run", side_effect=capture_run),
            pytest.raises(SetupError, match="Failed to run initial backup"),
        ):
            promote_module._run_remote_initial_backup(
                "acme", mock_system_config_with_backups
            )

    # ---- N3: Timeout test for _provision_remote_postgres pg_isready loop ----

    def test_promote_pg_isready_timeout(self, mock_system_config_with_backups):
        """SetupError raised when pg_isready deadline is exceeded."""
        # Return a time that is already past the 60s deadline on the second call
        # (first call sets deadline = start + 60, second call > deadline)
        time_values = iter([100.0, 100.0, 200.0])

        def mock_time():
            return next(time_values, 200.0)

        def capture_run(cmd, *args, **kwargs):
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            if isinstance(cmd, list) and cmd[0] == "ssh":
                if "pg_lsclusters" in cmd_str:
                    result.stdout = ""  # No existing clusters
                elif "python3" in cmd_str:
                    result.stdout = "5433\n"  # Port allocation
                elif "pg_isready" in cmd_str:
                    result.returncode = 2  # Not ready
                    result.stdout = ""
                else:
                    result.stdout = ""
            else:
                result.stdout = ""
            return result

        with (
            patch("subprocess.run", side_effect=capture_run),
            patch.object(promote_module.time, "time", side_effect=mock_time),
            patch.object(promote_module.time, "sleep"),
            pytest.raises(SetupError, match="did not become ready within 60 seconds"),
        ):
            promote_module._provision_remote_postgres(
                "acme", mock_system_config_with_backups
            )

    # ---- N4: Error-path tests for backup functions ----

    def test_promote_configure_wal_archiving_failure(
        self, mock_system_config_with_backups
    ):
        """CalledProcessError from WAL archiving tee command raises SetupError."""

        def capture_run(cmd, *args, **kwargs):
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            # grep returns 1 (WAL not yet configured)
            if isinstance(cmd, list) and cmd[0] == "ssh" and "grep" in cmd_str:
                result.returncode = 1
            # tee -a fails (WAL config append)
            elif isinstance(cmd, list) and cmd[0] == "ssh" and "tee -a" in cmd_str:
                raise subprocess.CalledProcessError(1, cmd, stderr="Permission denied")
            return result

        with (
            patch("subprocess.run", side_effect=capture_run),
            pytest.raises(
                SetupError, match="Failed to configure WAL archiving on production"
            ),
        ):
            promote_module._configure_remote_wal_archiving(
                "acme", 5433, mock_system_config_with_backups
            )

    def test_promote_configure_pgbackrest_failure(
        self, mock_system_config_with_backups
    ):
        """CalledProcessError from stanza-create raises SetupError."""

        def capture_run(cmd, *args, **kwargs):
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            # Stanza file does not exist
            if isinstance(cmd, list) and cmd[0] == "ssh" and "test -f" in cmd_str:
                result.returncode = 1
            # Stanza not initialised
            elif isinstance(cmd, list) and cmd[0] == "ssh" and " info" in cmd_str:
                result.returncode = 1
            # tee for stanza config succeeds
            elif isinstance(cmd, list) and cmd[0] == "ssh" and "tee" in cmd_str:
                result.returncode = 0
            # stanza-create fails
            elif (
                isinstance(cmd, list) and cmd[0] == "ssh" and "stanza-create" in cmd_str
            ):
                raise subprocess.CalledProcessError(
                    1, cmd, output="P00  ERROR: [028]: stanza already exists"
                )
            return result

        with (
            patch("subprocess.run", side_effect=capture_run),
            pytest.raises(
                SetupError, match="Failed to create pgBackRest stanza on production"
            ),
        ):
            promote_module._configure_remote_pgbackrest(
                "acme", 5433, mock_system_config_with_backups
            )

    def test_promote_install_backup_cron_failure(self, mock_system_config_with_backups):
        """CalledProcessError from cron tee command raises SetupError."""

        def capture_run(cmd, *args, **kwargs):
            result = MagicMock()
            result.returncode = 0
            result.stderr = ""
            result.stdout = ""
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else str(cmd)
            # grep returns 1 (cron not yet configured)
            if isinstance(cmd, list) and cmd[0] == "ssh" and "grep" in cmd_str:
                result.returncode = 1
            # flock tee -a fails
            elif isinstance(cmd, list) and cmd[0] == "ssh" and "tee -a" in cmd_str:
                raise subprocess.CalledProcessError(1, cmd, stderr="Permission denied")
            return result

        with (
            patch("subprocess.run", side_effect=capture_run),
            pytest.raises(
                SetupError, match="Failed to install backup cron on production"
            ),
        ):
            promote_module._install_remote_backup_cron(
                "acme", mock_system_config_with_backups
            )
