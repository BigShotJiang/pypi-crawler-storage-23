"""Regression tests for update command robustness (SEC-03, H-03, H-04)."""

from __future__ import annotations

from importlib import import_module
from unittest.mock import MagicMock, patch

import pytest
from sum.system_config import ConfigurationError, reset_system_config

update_module = import_module("sum.commands.update")


@pytest.fixture(autouse=True)
def reset_config():
    reset_system_config()
    yield
    reset_system_config()


class TestUpdateSlugValidation:
    """SEC-03: validate_site_slug() is called in run_update()."""

    def test_rejects_empty_slug(self, capsys):
        result = update_module.run_update("")
        assert result == 1
        captured = capsys.readouterr()
        assert "must not be empty" in captured.out

    def test_rejects_path_traversal(self, capsys):
        result = update_module.run_update("../etc")
        assert result == 1
        captured = capsys.readouterr()
        assert "Invalid site slug" in captured.out


class TestUpdateRootCheck:
    """H-03: require_root_or_escalate() called for staging only."""

    @patch("sum.commands.update.require_root_or_escalate")
    @patch("sum.commands.update.get_system_config")
    def test_staging_requires_root(self, mock_config, mock_root):
        mock_config.side_effect = ConfigurationError("no config")
        update_module.run_update("acme", target="staging")
        mock_root.assert_called_once_with("update")

    @patch("sum.commands.update.require_root_or_escalate")
    @patch("sum.commands.update.get_system_config")
    def test_prod_does_not_require_root(self, mock_config, mock_root):
        """Production update via SSH doesn't need local root."""
        mock_config.side_effect = ConfigurationError("no config")
        update_module.run_update("acme", target="prod")
        mock_root.assert_not_called()


class TestRemoteSiteCheck:
    """H-04: Remote site existence check before prod update."""

    @patch("sum.commands.update.require_root_or_escalate")
    @patch("sum.commands.update.get_system_config")
    @patch("subprocess.run")
    def test_prod_update_checks_remote_dir(
        self, mock_subprocess, mock_config, mock_root, capsys
    ):
        """Production update fails if site dir doesn't exist on remote."""
        config = MagicMock()
        config.production.ssh_host = "prod.example.com"
        config.get_site_dir.return_value = MagicMock()
        config.get_site_dir.return_value.__truediv__ = MagicMock(
            return_value=MagicMock()
        )
        mock_config.return_value = config

        # SSH test -d fails (returncode=1)
        mock_subprocess.return_value = MagicMock(returncode=1)

        result = update_module.run_update("acme", target="prod")
        assert result == 1
        captured = capsys.readouterr()
        assert "Site directory not found on production" in captured.out
