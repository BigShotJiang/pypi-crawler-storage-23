"""Tests for git operations module."""

from __future__ import annotations

import os
import subprocess
from unittest.mock import MagicMock, patch

import pytest
from sum.setup.git_ops import GiteaProvider, GitHubProvider, get_git_provider
from sum.site_config import GitConfig


class TestGitHubProvider:
    """Tests for GitHubProvider class."""

    def test_name_property(self):
        provider = GitHubProvider(org="test-org")
        assert provider.name == "GitHub"

    def test_get_repo_url(self):
        provider = GitHubProvider(org="my-org")
        url = provider.get_repo_url("my-org", "my-repo")
        assert url == "https://github.com/my-org/my-repo"

    def test_get_clone_url(self):
        provider = GitHubProvider(org="my-org")
        url = provider.get_clone_url("my-org", "my-repo")
        assert url == "git@github.com:my-org/my-repo.git"

    def test_is_available_no_gh_cli(self):
        provider = GitHubProvider(org="test-org")
        with patch("shutil.which", return_value=None):
            assert provider.is_available() is False

    def test_is_available_gh_not_authenticated(self):
        provider = GitHubProvider(org="test-org")
        with patch("shutil.which", return_value="/usr/bin/gh"):
            with patch("subprocess.run") as mock_run:
                mock_run.return_value = MagicMock(returncode=1)
                assert provider.is_available() is False

                # Verify the correct command was executed
                mock_run.assert_called_once()
                args = mock_run.call_args[0][0]
                assert args == ["gh", "auth", "status"]

    def test_is_available_gh_authenticated(self):
        provider = GitHubProvider(org="test-org")
        with patch("shutil.which", return_value="/usr/bin/gh"):
            with patch("subprocess.run") as mock_run:
                mock_run.return_value = MagicMock(returncode=0)
                assert provider.is_available() is True


class TestGiteaProvider:
    """Tests for GiteaProvider class."""

    def test_name_property(self):
        provider = GiteaProvider(
            org="test-org",
            base_url="https://gitea.example.com",
        )
        assert provider.name == "Gitea"

    def test_get_repo_url(self):
        provider = GiteaProvider(
            org="my-org",
            base_url="https://gitea.example.com",
        )
        url = provider.get_repo_url("my-org", "my-repo")
        assert url == "https://gitea.example.com/my-org/my-repo"

    def test_get_clone_url_standard_port(self):
        """Test standard SSH clone URL with default port 22."""
        provider = GiteaProvider(
            org="my-org",
            base_url="https://gitea.example.com",
            ssh_port=22,
        )
        url = provider.get_clone_url("my-org", "my-repo")
        assert url == "git@gitea.example.com:my-org/my-repo.git"

    def test_get_clone_url_custom_port(self):
        """Test SSH clone URL with custom port uses ssh:// format."""
        provider = GiteaProvider(
            org="my-org",
            base_url="https://gitea.example.com",
            ssh_port=2222,
        )
        url = provider.get_clone_url("my-org", "my-repo")
        assert url == "ssh://git@gitea.example.com:2222/my-org/my-repo.git"

    def test_is_available_no_token(self, monkeypatch):
        monkeypatch.delenv("GITEA_TOKEN", raising=False)
        provider = GiteaProvider(
            org="test-org",
            base_url="https://gitea.example.com",
        )
        assert provider.is_available() is False

    def test_is_available_with_token(self, monkeypatch):
        monkeypatch.setenv("GITEA_TOKEN", "test-token")
        provider = GiteaProvider(
            org="test-org",
            base_url="https://gitea.example.com",
        )
        assert provider.is_available() is True

    def test_custom_token_env(self, monkeypatch):
        monkeypatch.setenv("MY_GITEA_TOKEN", "test-token")
        provider = GiteaProvider(
            org="test-org",
            base_url="https://gitea.example.com",
            token_env="MY_GITEA_TOKEN",
        )
        assert provider.is_available() is True


class TestGetGitProvider:
    """Tests for get_git_provider factory function."""

    def test_returns_github_provider(self):
        provider = get_git_provider(
            provider="github",
            org="test-org",
        )
        assert isinstance(provider, GitHubProvider)

    def test_returns_gitea_provider(self):
        provider = get_git_provider(
            provider="gitea",
            org="test-org",
            gitea_url="https://gitea.example.com",
        )
        assert isinstance(provider, GiteaProvider)

    def test_gitea_requires_url(self):
        with pytest.raises(ValueError, match="gitea_url required"):
            get_git_provider(
                provider="gitea",
                org="test-org",
            )

    def test_gitea_with_custom_ssh_port(self):
        provider = get_git_provider(
            provider="gitea",
            org="test-org",
            gitea_url="https://gitea.example.com",
            gitea_ssh_port=2222,
        )
        assert isinstance(provider, GiteaProvider)
        assert provider.ssh_port == 2222


class TestGitConfigIntegration:
    """Tests for GitConfig integration with providers."""

    def test_github_git_config(self):
        """Test creating provider from GitConfig for GitHub."""
        from sum.setup.git_ops import get_git_provider_from_config

        config = GitConfig(
            provider="github",
            org="test-org",
        )
        provider = get_git_provider_from_config(config)
        assert isinstance(provider, GitHubProvider)
        assert provider.org == "test-org"

    def test_gitea_git_config(self):
        """Test creating provider from GitConfig for Gitea."""
        from sum.setup.git_ops import get_git_provider_from_config

        config = GitConfig(
            provider="gitea",
            org="test-org",
            url="https://gitea.example.com",
            ssh_port=2222,
            token_env="MY_TOKEN",
        )
        provider = get_git_provider_from_config(config)
        assert isinstance(provider, GiteaProvider)
        assert provider.org == "test-org"
        assert provider.ssh_port == 2222
        assert provider.token_env == "MY_TOKEN"


class TestCreateInitialCommit:
    """Tests for create_initial_commit function."""

    def test_uses_fallback_git_identity(self, tmp_path):
        """Commit succeeds on a fresh system with no git identity configured."""
        from sum.setup.git_ops import create_initial_commit, init_git_repo

        init_git_repo(tmp_path)

        # Create a file so the commit is non-empty
        (tmp_path / "README.md").write_text("hello")

        # Remove any inherited git identity so we rely on the fallback
        env = {
            "HOME": str(tmp_path),
            "GIT_CONFIG_NOSYSTEM": "1",
            "PATH": os.environ["PATH"],
        }
        with patch.dict(os.environ, env, clear=True):
            create_initial_commit(tmp_path)

        # Verify commit was created with the fallback identity
        result = subprocess.run(
            ["git", "log", "--format=%an <%ae>", "-1"],
            cwd=tmp_path,
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "SUM Platform" in result.stdout
        assert "deploy@sum-platform.local" in result.stdout

    def test_init_git_repo_sets_main_branch(self, tmp_path):
        """init_git_repo creates repo with 'main' as default branch."""
        from sum.setup.git_ops import init_git_repo

        init_git_repo(tmp_path)

        result = subprocess.run(
            ["git", "branch", "--show-current"],
            cwd=tmp_path,
            capture_output=True,
            text=True,
        )
        assert result.stdout.strip() == "main"


class TestEnsureGitignore:
    """SEC-08: _ensure_gitignore protects .env before git add -A."""

    def test_creates_gitignore_with_env_patterns(self, tmp_path):
        """Creates .gitignore with .env patterns when none exists."""
        from sum.setup.git_ops import _ensure_gitignore

        _ensure_gitignore(tmp_path)

        gitignore = tmp_path / ".gitignore"
        assert gitignore.exists()
        content = gitignore.read_text()
        assert ".env" in content
        assert ".env.local" in content
        assert ".env.*.local" in content

    def test_appends_missing_patterns_to_existing(self, tmp_path):
        """Appends missing .env patterns to existing .gitignore."""
        from sum.setup.git_ops import _ensure_gitignore

        gitignore = tmp_path / ".gitignore"
        gitignore.write_text("*.pyc\n__pycache__/\n")

        _ensure_gitignore(tmp_path)

        content = gitignore.read_text()
        # Original content preserved
        assert "*.pyc" in content
        # New patterns added
        assert ".env" in content
        assert ".env.local" in content
        assert ".env.*.local" in content

    def test_noop_when_patterns_present(self, tmp_path):
        """Does nothing when all .env patterns already exist."""
        from sum.setup.git_ops import _ensure_gitignore

        original = "*.pyc\n.env\n.env.local\n.env.*.local\n"
        gitignore = tmp_path / ".gitignore"
        gitignore.write_text(original)

        _ensure_gitignore(tmp_path)

        assert gitignore.read_text() == original
