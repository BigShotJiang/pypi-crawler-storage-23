# pyright: reportMissingImports=false, reportPrivateUsage=false, reportUnknownMemberType=false, reportUnknownParameterType=false, reportMissingParameterType=false, reportUnknownVariableType=false, reportUnusedCallResult=false, reportUnknownArgumentType=false, reportMissingModuleSource=false

"""Tests for themes_registry module, focusing on resolve_theme_dir remote fallback."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest
from sum.exceptions import ThemeNotFoundError
from sum.themes_registry import resolve_theme_dir


class TestResolveThemeDirRemoteFallback:
    """Tests for remote theme fallback in resolve_theme_dir (lines 128-137)."""

    def test_remote_fallback_succeeds_when_local_not_found(self, tmp_path, monkeypatch):
        """Remote theme is fetched when local theme doesn't exist."""
        # Ensure no local theme exists
        monkeypatch.chdir(tmp_path)
        monkeypatch.delenv("SUM_THEME_PATH", raising=False)

        remote_theme_path = tmp_path / "cached" / "remote_theme"
        remote_theme_path.mkdir(parents=True)
        (remote_theme_path / "theme.json").write_text(
            json.dumps({"slug": "remote_theme", "name": "Remote", "version": "1.0.0"})
        )

        # Mock the module that gets imported inside the function
        mock_remote_themes = MagicMock()
        mock_remote_themes.resolve_remote_theme = MagicMock(
            return_value=remote_theme_path
        )

        with patch.dict("sys.modules", {"sum.setup.remote_themes": mock_remote_themes}):
            result = resolve_theme_dir("remote_theme")
            mock_remote_themes.resolve_remote_theme.assert_called_once_with(
                "remote_theme"
            )
            assert result == remote_theme_path

    def test_remote_fallback_handles_import_error(self, tmp_path, monkeypatch):
        """ImportError from remote_themes module is handled gracefully."""
        # Ensure no local theme exists
        monkeypatch.chdir(tmp_path)
        monkeypatch.delenv("SUM_THEME_PATH", raising=False)

        # Simulate ImportError by making the import fail
        with patch.dict("sys.modules", {"sum.setup.remote_themes": None}):
            with pytest.raises(ThemeNotFoundError, match="not found"):
                resolve_theme_dir("nonexistent_theme")

    def test_remote_fallback_handles_theme_not_found_error(self, tmp_path, monkeypatch):
        """ThemeNotFoundError from remote resolution is handled gracefully."""
        # Ensure no local theme exists
        monkeypatch.chdir(tmp_path)
        monkeypatch.delenv("SUM_THEME_PATH", raising=False)

        # Mock the module that gets imported inside the function
        mock_remote_themes = MagicMock()
        mock_remote_themes.resolve_remote_theme = MagicMock(
            side_effect=ThemeNotFoundError("Remote theme not found")
        )

        with patch.dict("sys.modules", {"sum.setup.remote_themes": mock_remote_themes}):
            with pytest.raises(ThemeNotFoundError, match="not found"):
                resolve_theme_dir("nonexistent_theme")

    def test_fetch_remote_false_skips_remote(self, tmp_path, monkeypatch):
        """When fetch_remote=False, remote fetching is skipped."""
        # Ensure no local theme exists
        monkeypatch.chdir(tmp_path)
        monkeypatch.delenv("SUM_THEME_PATH", raising=False)

        # Mock the module that gets imported inside the function
        mock_remote_themes = MagicMock()
        mock_remote_themes.resolve_remote_theme = MagicMock()

        with patch.dict("sys.modules", {"sum.setup.remote_themes": mock_remote_themes}):
            with pytest.raises(ThemeNotFoundError, match="not found"):
                resolve_theme_dir("nonexistent_theme", fetch_remote=False)
            # Should not call remote resolution
            mock_remote_themes.resolve_remote_theme.assert_not_called()

    def test_local_theme_preferred_over_remote(self, tmp_path, monkeypatch):
        """Local theme is used even when remote fetching is enabled."""
        monkeypatch.chdir(tmp_path)
        monkeypatch.delenv("SUM_THEME_PATH", raising=False)

        # Create local theme
        local_theme = tmp_path / "themes" / "my_theme"
        local_theme.mkdir(parents=True)
        (local_theme / "theme.json").write_text(
            json.dumps({"slug": "my_theme", "name": "My Theme", "version": "1.0.0"})
        )

        # Mock the module that gets imported inside the function
        mock_remote_themes = MagicMock()
        mock_remote_themes.resolve_remote_theme = MagicMock()

        with patch.dict("sys.modules", {"sum.setup.remote_themes": mock_remote_themes}):
            result = resolve_theme_dir("my_theme")
            # Should not call remote resolution since local exists
            mock_remote_themes.resolve_remote_theme.assert_not_called()
            assert result == local_theme

    def test_env_theme_path_preferred_over_remote(self, tmp_path, monkeypatch):
        """SUM_THEME_PATH theme is used over remote."""
        # Create theme at SUM_THEME_PATH
        env_theme = tmp_path / "env_themes" / "custom_theme"
        env_theme.mkdir(parents=True)
        (env_theme / "theme.json").write_text(
            json.dumps({"slug": "custom_theme", "name": "Custom", "version": "1.0.0"})
        )

        # Create the "other" directory before chdir
        other_dir = tmp_path / "other"
        other_dir.mkdir(parents=True)

        monkeypatch.setenv("SUM_THEME_PATH", str(tmp_path / "env_themes"))
        monkeypatch.chdir(other_dir)  # Different from theme path

        # Mock the module that gets imported inside the function
        mock_remote_themes = MagicMock()
        mock_remote_themes.resolve_remote_theme = MagicMock()

        with patch.dict("sys.modules", {"sum.setup.remote_themes": mock_remote_themes}):
            result = resolve_theme_dir("custom_theme")
            mock_remote_themes.resolve_remote_theme.assert_not_called()
            assert result == env_theme


class TestResolveThemeDirBasic:
    """Basic tests for resolve_theme_dir function."""

    def test_empty_slug_raises(self):
        """Empty slug raises ThemeNotFoundError."""
        with pytest.raises(ThemeNotFoundError, match="cannot be empty"):
            resolve_theme_dir("")

    def test_whitespace_slug_raises(self):
        """Whitespace-only slug raises ThemeNotFoundError."""
        with pytest.raises(ThemeNotFoundError, match="cannot be empty"):
            resolve_theme_dir("   ")

    def test_strips_whitespace(self, tmp_path, monkeypatch):
        """Slug whitespace is stripped before resolution."""
        monkeypatch.chdir(tmp_path)
        monkeypatch.delenv("SUM_THEME_PATH", raising=False)

        local_theme = tmp_path / "themes" / "test_theme"
        local_theme.mkdir(parents=True)
        (local_theme / "theme.json").write_text(
            json.dumps({"slug": "test_theme", "name": "Test", "version": "1.0.0"})
        )

        result = resolve_theme_dir("  test_theme  ")
        assert result == local_theme
