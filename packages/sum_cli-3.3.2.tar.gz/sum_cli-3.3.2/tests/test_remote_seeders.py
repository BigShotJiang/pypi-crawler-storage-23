# pyright: reportMissingImports=false, reportPrivateUsage=false, reportUnknownMemberType=false, reportUnknownParameterType=false, reportMissingParameterType=false, reportUnknownVariableType=false, reportUnusedCallResult=false, reportUnknownArgumentType=false, reportMissingModuleSource=false

"""Tests for remote seeders fetching functionality."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest
from sum.exceptions import SetupError
from sum.setup.remote_seeders import (
    fetch_seeders_from_repo,
    get_cached_seeders,
    get_content_path,
    get_seeders_cache_dir,
    resolve_seeders_path,
)


class TestGetSeedersCacheDir:
    """Test cache directory management."""

    def test_returns_path(self):
        cache_dir = get_seeders_cache_dir()
        assert isinstance(cache_dir, Path)
        assert "sum-platform" in str(cache_dir)
        assert "seeders" in str(cache_dir)

    def test_creates_directory(self, tmp_path, monkeypatch):
        """Cache directory is created if it doesn't exist."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        result = get_seeders_cache_dir()

        assert result.exists()
        assert result.is_dir()

    def test_raises_on_permission_error(self, tmp_path, monkeypatch):
        """SetupError is raised when directory cannot be created."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        with patch.object(Path, "mkdir", side_effect=OSError("Permission denied")):
            with pytest.raises(SetupError, match="Failed to create"):
                get_seeders_cache_dir()


class TestGetCachedSeeders:
    """Test cached seeders lookup."""

    def test_returns_none_when_not_cached(self, tmp_path, monkeypatch):
        """Returns None when seeders aren't in cache."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        result = get_cached_seeders("latest")

        assert result is None

    def test_returns_none_when_missing_init(self, tmp_path, monkeypatch):
        """Returns None when __init__.py is missing."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cache_dir = tmp_path / ".cache" / "sum-platform" / "seeders" / "latest"
        cache_dir.mkdir(parents=True)
        # Don't create __init__.py

        result = get_cached_seeders("latest")

        assert result is None

    def test_returns_path_when_valid(self, tmp_path, monkeypatch):
        """Returns path when seeders are properly cached."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cache_dir = tmp_path / ".cache" / "sum-platform" / "seeders" / "latest"
        cache_dir.mkdir(parents=True)
        (cache_dir / "__init__.py").write_text("# seeders")

        result = get_cached_seeders("latest")

        assert result == cache_dir


class TestGetContentPath:
    """Test content path retrieval."""

    def test_returns_none_when_not_cached(self, tmp_path, monkeypatch):
        """Returns None when content isn't cached."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        result = get_content_path("latest")

        assert result is None

    def test_returns_path_when_cached(self, tmp_path, monkeypatch):
        """Returns path when content is cached."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        content_dir = (
            tmp_path / ".cache" / "sum-platform" / "seeders" / "latest_content"
        )
        content_dir.mkdir(parents=True)

        result = get_content_path("latest")

        assert result == content_dir


class TestFetchSeedersFromRepo:
    """Test seeders fetching from repository."""

    def test_returns_cached_when_available(self, tmp_path, monkeypatch):
        """Returns cached seeders without network call."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cache_dir = tmp_path / ".cache" / "sum-platform" / "seeders" / "latest"
        cache_dir.mkdir(parents=True)
        (cache_dir / "__init__.py").write_text("# seeders")

        with patch("sum.setup.remote_seeders._run_git_command") as mock_git:
            result = fetch_seeders_from_repo("latest")

            mock_git.assert_not_called()
            assert result == cache_dir

    def test_raises_on_timeout(self, tmp_path, monkeypatch):
        """SetupError raised on network timeout."""
        import subprocess

        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        with patch(
            "sum.setup.remote_seeders._run_git_command",
            side_effect=subprocess.TimeoutExpired("git", 120),
        ):
            with pytest.raises(SetupError, match="Timeout"):
                fetch_seeders_from_repo("latest")

    def test_raises_on_git_failure(self, tmp_path, monkeypatch):
        """SetupError raised on git command failure."""
        import subprocess

        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        mock_error = subprocess.CalledProcessError(1, "git")
        mock_error.stderr = "fatal: Could not find remote branch"

        with patch(
            "sum.setup.remote_seeders._run_git_command",
            side_effect=mock_error,
        ):
            with pytest.raises(SetupError, match="Failed to fetch"):
                fetch_seeders_from_repo("latest")


class TestResolveSeedersPath:
    """Test main entry point for seeders resolution."""

    def test_resolves_to_cached_path(self, tmp_path, monkeypatch):
        """Resolves to cached seeders when available."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cache_dir = tmp_path / ".cache" / "sum-platform" / "seeders" / "latest"
        cache_dir.mkdir(parents=True)
        (cache_dir / "__init__.py").write_text("# seeders")

        result = resolve_seeders_path("latest")

        assert result == cache_dir

    def test_uses_specific_version(self, tmp_path, monkeypatch):
        """Resolves specific version when requested."""
        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        cache_dir = tmp_path / ".cache" / "sum-platform" / "seeders" / "v0.7.2"
        cache_dir.mkdir(parents=True)
        (cache_dir / "__init__.py").write_text("# seeders")

        result = resolve_seeders_path("v0.7.2")

        assert result == cache_dir
