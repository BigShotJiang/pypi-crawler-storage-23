"""Pydantic models for Strata Cloud Manager insights resources."""
