"""scm.models: Pydantic models for SCM resources."""
# scm/models/__init__.py

__all__ = ["AuthRequestModel"]

from .auth import AuthRequestModel
