"""HoxCore - A meta-manager for organizational objects."""

__version__ = '0.1.0'
__author__ = 'Salvador D. Escobedo'