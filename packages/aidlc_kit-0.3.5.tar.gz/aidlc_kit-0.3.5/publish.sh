#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

# Read version from pyproject.toml
VERSION=$(grep '^version' pyproject.toml | head -1 | sed 's/.*"\(.*\)"/\1/')
echo "Building aidlc-kit v${VERSION}"

# Verify __init__.py matches
INIT_VERSION=$(python3 -c "from src.aidlc_kit import __version__; print(__version__)")
if [ "$VERSION" != "$INIT_VERSION" ]; then
  echo "ERROR: pyproject.toml ($VERSION) != __init__.py ($INIT_VERSION)"
  exit 1
fi

# Verify CHANGELOG has this version
if ! grep -q "\[${VERSION}\]" CHANGELOG.md; then
  echo "ERROR: CHANGELOG.md missing entry for ${VERSION}"
  exit 1
fi

# Clean previous builds
rm -rf dist/ build/ src/*.egg-info

# Build
python3 -m build
echo ""
echo "Built:"
ls -lh dist/

# Confirm before publishing
echo ""
read -p "Publish v${VERSION} to PyPI? [y/N] " confirm
if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
  echo "Aborted."
  exit 0
fi

# Publish
twine upload dist/*

echo ""
echo "✓ aidlc-kit v${VERSION} published to PyPI"
echo "  https://pypi.org/project/aidlc-kit/${VERSION}/"
