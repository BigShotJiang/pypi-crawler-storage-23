# Code Elevation — Session Plan

> **Usage:** The AI fills this plan during the session and updates status as stages complete.
> If the session is interrupted, the next session reads this file to resume.

| Field | Value |
|-------|-------|
| **Intent** | (filled from intents/intent-primary.md) |
| **Started** | (date) |
| **Last Updated** | (date) |
| **Current Stage** | (number) |

---

## Progress

| # | Stage | Status | Artifacts |
|---|-------|--------|-----------|
| 0 | Pre-flight Check | ⬜ Pending | — |
| 1 | Static Analysis | ⬜ Pending | code-elevation/static_model.md |
| 2 | Dynamic Analysis | ⬜ Pending | code-elevation/dynamic_model.md |
{{#enterprise}}
| 3 | Technical Debt & Guardrails Gap Analysis | ⬜ Pending | code-elevation/technical_debt.md, code-elevation/guardrails_gap_analysis.md |
{{/enterprise}}

Status legend: ⬜ Pending · 🔄 In Progress · ✅ Done

---

## Scope Prioritization

(Filled during Pre-flight or Stage 1)

| Priority | Components |
|----------|------------|
| High (directly impacted) | |
| Medium (shared data/events) | |
| Out of scope | |

---

## Session Notes

(AI and team notes, interruptions, decisions to revisit)
