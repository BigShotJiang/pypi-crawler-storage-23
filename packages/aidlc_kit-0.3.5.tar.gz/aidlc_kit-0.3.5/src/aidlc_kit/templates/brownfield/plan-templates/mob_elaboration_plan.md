# Mob Elaboration — Session Plan

> **Usage:** The AI fills this plan during the session and updates status as phases complete.
> If the session is interrupted, the next session reads this file to resume.

| Field | Value |
|-------|-------|
| **Intent** | (filled from intents/intent-primary.md) |
| **Mode** | brownfield |
| **Started** | (date) |
| **Last Updated** | (date) |
| **Current Phase** | (number) |

---

## Progress

| # | Phase | Status | Artifacts |
|---|-------|--------|-----------|
| 0 | Pre-flight Check | ⬜ Pending | decisions/decision-log.md |
| 1 | Intent Clarification | ⬜ Pending | intents/intent-primary.md |
{{#enterprise}}
| 2 | Impact & Compatibility Analysis | ⬜ Pending | mob-elaboration/compatibility_impact.md, mob-elaboration/guardrails_remediation_triage.md |
{{/enterprise}}
| 3 | Story Generation | ⬜ Pending | mob-elaboration/user_stories.md |
| 4 | Unit Division | ⬜ Pending | mob-elaboration/unit_definitions.md |
{{#enterprise}}
| 5 | Risk, NFR & Guardrails Analysis | ⬜ Pending | mob-elaboration/nfrs.md, mob-elaboration/risk_register.md, mob-elaboration/guardrails_compliance_matrix.md |
{{/enterprise}}
{{#standard}}
| 5 | Risk, NFR & Guardrails Analysis | ⬜ Pending | mob-elaboration/nfrs.md, mob-elaboration/risk_register.md |
{{/standard}}
| 6 | Bolt Planning | ⬜ Pending | (this file, Bolt Plan section below) |

Status legend: ⬜ Pending · 🔄 In Progress · ✅ Done · ⏭️ Skipped (N/A)

---

## Bolt Plan

(Filled during Phase 6)

| Bolt | Unit | Stories | Dependencies | Estimated Duration | Status |
|------|------|---------|--------------|--------------------|--------|
| | | | | | |

---

## Session Notes

(AI and team notes, interruptions, decisions to revisit)
