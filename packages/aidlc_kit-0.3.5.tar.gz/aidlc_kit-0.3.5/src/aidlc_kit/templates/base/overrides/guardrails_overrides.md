# Guardrails Overrides — {{PROJECT_NAME}}

> Document any project-specific guardrail exceptions here. Each override must include justification, compensating controls, approval, and expiry. See EGS §12 for the full override process.

| Guardrail | Justification | Compensating Controls | Approved By | Expiry |
|-----------|---------------|----------------------|-------------|--------|
| | | | | |
