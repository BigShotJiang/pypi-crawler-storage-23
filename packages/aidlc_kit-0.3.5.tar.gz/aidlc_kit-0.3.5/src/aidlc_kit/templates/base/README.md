# {{PROJECT_NAME}} — AI-DLC Project

| Field | Value |
|-------|-------|
| Project | {{PROJECT_NAME}} |
| Mode | {{MODE}} |
| Platform | {{PLATFORM}} |
| Tier | {{TIER}} |
| Created | {{DATE}} |
{{#enterprise}}
| EGS Version | (updated during first session or after import) |
{{/enterprise}}
| Team | (list team members and roles) |
| Facilitator | (name) |

---

{{IDE_SETUP}}
## Folder Guide

| Folder | Purpose |
|--------|---------|
{{#enterprise}}
| `egs_definition.md` | Enterprise Guardrails Specification: your project's "constitution" |
{{/enterprise}}
| `intents/` | High-level feature descriptions that drive Mob Elaboration |
| `prompts/` | AI-DLC prompt templates (used automatically by IDE routers, or paste manually) |
{{#enterprise}}
| `mob-elaboration/` | Mob Elaboration outputs: plan, stories, compliance matrix |
| `mob-construction/` | Per-bolt outputs: domain model, logical design, code, compliance report |
| `code-elevation/` | (Brownfield) Code Elevation outputs: static/dynamic models, tech debt, gap analysis |
| `decisions/` | Decision log with traceability to guardrails |
| `overrides/` | Documented guardrail exceptions with compensating controls |
{{/enterprise}}
{{#standard}}
| `mob-elaboration/` | Mob Elaboration outputs: plan, stories, units, NFRs |
| `mob-construction/` | Per-bolt outputs: domain model, logical design, code |
| `code-elevation/` | (Brownfield) Code Elevation outputs: static/dynamic models, tech debt |
| `decisions/` | Decision log with architectural decisions |
{{/standard}}
| `completion/` | Completion prompts: bolt criteria, consistency check, intent consolidation |
| `plan-templates/` | Blank plan templates for Mob Elaboration and Mob Construction |
| `standards/` | Content validation rules, error handling, question format |
| `audit/` | Session audit log (actions, decisions, artifacts created) |
| `retrospectives/` | Post-session retrospective template |
| `intent-summaries/` | Cross-intent context summaries (populated by intent consolidation) |
| `extensions/` | Cross-cutting rules (e.g. security) enforced automatically by the AI. See `extensions/README.md` |
| `archive/` | Completed intents moved here for historical reference |

## Workflow

{{#enterprise}}
1. Import your org's EGS: `aidlc-kit import-egs <path>` (or skip — the AI will help you set one up)
2. Open your AI coding assistant and ask: "Start Mob Elaboration"
   (the AI will ask for your intent — or read it from `intents/intent-primary.md` if you wrote one ahead of time)
3. (Brownfield only) Run Code Elevation to analyze the existing codebase
4. Mob Elaboration breaks the intent into stories, units, and bolts
5. Start Mob Construction bolt by bolt
6. Between bolts: run a consistency check or validate bolt completion criteria
7. After all bolts: run intent consolidation, then archive to `archive/`
{{/enterprise}}
{{#standard}}
1. Open your AI coding assistant and ask: "Start Mob Elaboration"
   (the AI will ask for your intent — or read it from `intents/intent-primary.md` if you wrote one ahead of time)
2. (Brownfield only) Run Code Elevation to analyze the existing codebase
3. Mob Elaboration breaks the intent into stories, units, and bolts
4. Start Mob Construction bolt by bolt
5. Between bolts: run a consistency check or validate bolt completion criteria
6. After all bolts: run intent consolidation, then archive to `archive/`
{{/standard}}
