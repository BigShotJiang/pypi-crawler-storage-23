"""Tests for aidlc-kit scaffold."""

import os
import shutil
import tempfile
from pathlib import Path
from click.testing import CliRunner
from aidlc_kit.cli import main


def test_init_greenfield():
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "test-project")
        result = runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
        assert result.exit_code == 0
        docs = Path(target) / "aidlc-docs"
        assert docs.exists()
        assert (docs / "egs_definition.md").exists()
        assert (docs / "prompts" / "mob-elaboration.md").exists()
        assert (docs / "prompts" / "mob-construction.md").exists()
        assert (docs / "mob-construction" / "bolt-1").is_dir()
        assert not (docs / "code-elevation").exists()
        # Check README was rendered
        readme = (docs / "README.md").read_text()
        assert "test-project" in readme
        assert "greenfield" in readme


def test_init_brownfield():
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "legacy-app")
        result = runner.invoke(main, ["init", target, "--mode", "brownfield", "--platform", "aws"])
        assert result.exit_code == 0
        docs = Path(target) / "aidlc-docs"
        assert (docs / "prompts" / "code-elevation.md").exists()
        assert (docs / "prompts" / "mob-elaboration.md").exists()
        assert (docs / "code-elevation" / "guardrails_gap_analysis.md").exists()
        assert (docs / "mob-construction" / "bolt-b1").is_dir()


def test_init_current_dir():
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        result = runner.invoke(main, ["init", tmp, "--mode", "greenfield", "--platform", "aws"])
        assert result.exit_code == 0
        assert (Path(tmp) / "aidlc-docs" / "egs_definition.md").exists()


def test_init_refuses_overwrite():
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
        result = runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
        assert result.exit_code != 0
        assert "already exists" in result.output


def test_init_force_overwrite():
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
        result = runner.invoke(main, ["init", target, "--mode", "brownfield", "--platform", "aws", "--force"])
        assert result.exit_code == 0
        docs = Path(target) / "aidlc-docs"
        assert (docs / "code-elevation" / "guardrails_gap_analysis.md").exists()


def test_init_custom_name():
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        result = runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws", "--name", "Customer Portal"])
        assert result.exit_code == 0
        readme = (Path(target) / "aidlc-docs" / "README.md").read_text()
        assert "Customer Portal" in readme


def test_shared_artifacts_present():
    """Both modes should have the base artifacts."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        for mode in ("greenfield", "brownfield"):
            target = os.path.join(tmp, mode)
            runner.invoke(main, ["init", target, "--mode", mode, "--platform", "aws"])
            docs = Path(target) / "aidlc-docs"
            assert (docs / "egs_definition.md").exists(), f"{mode}: missing egs"
            assert (docs / "intents" / "intent-primary.md").exists(), f"{mode}: missing intent"
            assert (docs / "decisions" / "decision-log.md").exists(), f"{mode}: missing decisions"
            assert (docs / "overrides" / "guardrails_overrides.md").exists(), f"{mode}: missing overrides"
            assert (docs / "completion" / "bolt-completion-criteria.md").exists(), f"{mode}: missing completion"
            assert (docs / "archive").is_dir(), f"{mode}: missing archive"


def test_update_overwrites_kit_templates():
    """Update should overwrite kit-owned files that changed."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
        docs = Path(target) / "aidlc-docs"
        # Corrupt a kit-owned file
        prompt = docs / "prompts" / "mob-elaboration.md"
        prompt.write_text("corrupted")
        result = runner.invoke(main, ["update", target, "-y"])
        assert result.exit_code == 0
        assert "corrupted" not in prompt.read_text()
        assert "Updated" in result.output


def test_update_preserves_user_content():
    """Update must not touch intents, archive, or README."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "brownfield", "--platform", "aws", "--name", "My App"])
        docs = Path(target) / "aidlc-docs"
        # Write user content
        intent = docs / "intents" / "intent-primary.md"
        intent.write_text("My custom intent")
        readme_before = (docs / "README.md").read_text()
        runner.invoke(main, ["update", target, "-y"])
        assert intent.read_text() == "My custom intent"
        assert (docs / "README.md").read_text() == readme_before


def test_update_detects_mode():
    """Update should detect brownfield mode and copy brownfield templates."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "brownfield", "--platform", "aws"])
        # Corrupt a non-user-owned file so there's something to update
        (Path(target) / "aidlc-docs" / "prompts" / "code-elevation.md").write_text("old")
        result = runner.invoke(main, ["update", target, "-y"])
        assert result.exit_code == 0
        assert "brownfield" in result.output


def test_update_fails_without_init():
    """Update should fail if aidlc-docs/ doesn't exist."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        result = runner.invoke(main, ["update", tmp, "-y"])
        assert result.exit_code != 0
        assert "No aidlc-docs/" in result.output


def test_update_skips_unchanged():
    """Update right after init should report nothing to update."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
        result = runner.invoke(main, ["update", target, "-y"])
        assert result.exit_code == 0
        assert "up to date" in result.output


def test_update_confirms_before_overwrite():
    """Without --yes, update should ask per file and respect decline."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
        docs = Path(target) / "aidlc-docs"
        (docs / "prompts" / "mob-elaboration.md").write_text("old prompt")
        (docs / "prompts" / "mob-construction.md").write_text("old prompt2")
        # Decline first, accept second
        result = runner.invoke(main, ["update", target], input="n\ny\n")
        assert result.exit_code == 0
        assert "skipped" in result.output
        assert "Updated 1/2" in result.output


def test_archive_moves_artifacts():
    """Archive should move intent artifacts and reset workspace."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
        docs = Path(target) / "aidlc-docs"
        # Simulate user work
        (docs / "intents" / "intent-primary.md").write_text("# Intent: User Auth\n\nBuild auth.")
        (docs / "mob-elaboration" / "mob_elaboration_plan.md").write_text("plan content")
        (docs / "decisions" / "decision-log.md").write_text("decision content")
        result = runner.invoke(main, ["archive", target, "-y"])
        assert result.exit_code == 0
        # Archived folder exists
        archive_dirs = [p for p in (docs / "archive").iterdir() if p.is_dir()]
        assert len(archive_dirs) == 1
        assert "user-auth" in archive_dirs[0].name
        # Artifacts moved
        assert (archive_dirs[0] / "intents" / "intent-primary.md").read_text().startswith("# Intent: User Auth")
        assert (archive_dirs[0] / "mob-elaboration" / "mob_elaboration_plan.md").exists()
        assert (archive_dirs[0] / "decisions" / "decision-log.md").read_text() == "decision content"
        # Workspace reset with blank templates
        assert (docs / "intents" / "intent-primary.md").exists()
        assert "[Name]" in (docs / "intents" / "intent-primary.md").read_text()


def test_archive_custom_name():
    """Archive should use custom name when provided."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
        (Path(target) / "aidlc-docs" / "intents" / "intent-primary.md").write_text("real intent")
        result = runner.invoke(main, ["archive", target, "--name", "sprint-1", "-y"])
        assert result.exit_code == 0
        archive_dirs = [p for p in (Path(target) / "aidlc-docs" / "archive").iterdir() if p.is_dir()]
        assert "sprint-1" in archive_dirs[0].name


def test_archive_brownfield_includes_code_elevation():
    """Brownfield archive should include code-elevation artifacts."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "brownfield", "--platform", "aws"])
        docs = Path(target) / "aidlc-docs"
        (docs / "intents" / "intent-primary.md").write_text("# Intent: Migrate API\n")
        (docs / "code-elevation" / "guardrails_gap_analysis.md").write_text("gaps found")
        result = runner.invoke(main, ["archive", target, "-y"])
        assert result.exit_code == 0
        archive_dirs = [p for p in (docs / "archive").iterdir() if p.is_dir()]
        assert (archive_dirs[0] / "code-elevation" / "guardrails_gap_analysis.md").exists()
        # Reset: blank template restored
        assert (docs / "code-elevation" / "guardrails_gap_analysis.md").exists()


def test_archive_fails_empty_workspace():
    """Archive should fail if nothing to archive."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
        # Remove all content from archivable dirs to simulate empty
        docs = Path(target) / "aidlc-docs"
        for d in ("intents", "mob-elaboration", "mob-construction", "decisions", "retrospectives", "audit"):
            shutil.rmtree(docs / d)
            (docs / d).mkdir()
        result = runner.invoke(main, ["archive", target, "-y"])
        assert result.exit_code != 0
        assert "Nothing to archive" in result.output


def test_archive_confirms_before_action():
    """Without --yes, archive should ask for confirmation."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
        (Path(target) / "aidlc-docs" / "intents" / "intent-primary.md").write_text("real intent")
        result = runner.invoke(main, ["archive", target], input="n\n")
        assert result.exit_code != 0
        # Nothing archived
        assert not list((Path(target) / "aidlc-docs" / "archive").glob("*/"))


def test_check_clean_project():
    """Check on a freshly init'd project should flag unfilled intent and EGS."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
        result = runner.invoke(main, ["check", target])
        assert result.exit_code != 0
        assert "Intent not filled" in result.output
        assert "EGS not customized" in result.output


def test_check_filled_project():
    """Check should pass when intent and EGS are customized."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
        docs = Path(target) / "aidlc-docs"
        (docs / "intents" / "intent-primary.md").write_text("# Intent: Auth\n\nBuild auth.")
        (docs / "egs_definition.md").write_text(
            "# EGS — Acme Corp\n"
            "## Security Baseline\n## Compliance Constraints\n## Architectural Guardrails\n"
            "## Coding Standards\n## Operational Readiness\n## Cost Guardrails\n"
            "## AI/GenAI Guardrails\n## Reliability Guardrails\n"
            "## Performance Efficiency Guardrails\n## Sustainability Guardrails\n"
        )
        result = runner.invoke(main, ["check", target])
        assert result.exit_code == 0
        assert "No issues" in result.output


def test_check_missing_files():
    """Check should flag missing required files."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
        os.remove(Path(target) / "aidlc-docs" / "prompts" / "mob-elaboration.md")
        result = runner.invoke(main, ["check", target])
        assert "Missing: prompts/mob-elaboration.md" in result.output


def test_check_brownfield_validates_code_elevation():
    """Brownfield check should validate code-elevation files."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "brownfield", "--platform", "aws"])
        result = runner.invoke(main, ["check", target])
        assert "brownfield" in result.output
        # Should not flag missing code-elevation files (they exist from init)
        assert "Missing: prompts/code-elevation.md" not in result.output


def test_check_shows_plan_progress():
    """Check should report plan progress."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "proj")
        runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
        docs = Path(target) / "aidlc-docs"
        (docs / "intents" / "intent-primary.md").write_text("# Intent: Auth\n")
        (docs / "egs_definition.md").write_text("# EGS — Acme\n")
        plan = docs / "mob-elaboration" / "mob_elaboration_plan.md"
        # Copy plan template to artifact folder (simulates what the AI does)
        shutil.copy2(docs / "plan-templates" / "mob_elaboration_plan.md", plan)
        content = plan.read_text()
        content = content.replace("| 1 | Intent Clarification | ⬜ Pending", "| 1 | Intent Clarification | ✅ Done")
        content = content.replace("| 2 | Story Generation | ⬜ Pending", "| 2 | Story Generation | ✅ Done")
        plan.write_text(content)
        result = runner.invoke(main, ["check", target])
        assert "2 phase(s)/stage(s) completed" in result.output


# --- status tests ---

def test_status_fresh_project(tmp_path):
    """Status shows not-started state for a fresh project."""
    runner = CliRunner()
    target = str(tmp_path / "proj")
    runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws", "--name", "TestProj"])
    result = runner.invoke(main, ["status", target])
    assert result.exit_code == 0
    assert "TestProj" in result.output
    assert "greenfield" in result.output
    assert "not defined" in result.output
    assert "missing" in result.output or "not started" in result.output
    assert "0 entries" in result.output
    assert "Archives:   none" in result.output


def test_status_filled_project(tmp_path):
    """Status shows progress when intent is filled and plan has activity."""
    runner = CliRunner()
    target = str(tmp_path / "proj")
    runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws", "--name", "MyApp"])
    docs = tmp_path / "proj" / "aidlc-docs"
    # Fill intent
    intent = docs / "intents" / "intent-primary.md"
    intent.write_text("# Intent: Payment Gateway\n\nA payment gateway integration.")
    # Customize EGS
    egs = docs / "egs_definition.md"
    egs.write_text("# EGS for MyApp\nCustomized content.")
    # Add plan progress
    plan = docs / "mob-elaboration" / "mob_elaboration_plan.md"
    # Copy plan template to artifact folder (simulates what the AI does)
    shutil.copy2(docs / "plan-templates" / "mob_elaboration_plan.md", plan)
    content = plan.read_text()
    content = content.replace("| 1 | Intent Clarification | ⬜ Pending", "| 1 | Intent Clarification | ✅ Done")
    content = content.replace("| 2 | Story Generation | ⬜ Pending", "| 2 | Story Generation | 🔄 In Progress")
    plan.write_text(content)
    # Add a filled decision
    dlog = docs / "decisions" / "decision-log.md"
    dlog.write_text("# Log\n\n### Decision 001\n| Field | Detail |\n|---|---|\n| **Decision** | Use DynamoDB |\n\n### Decision 002\n| Field | Detail |\n|---|---|\n| **Decision** | Use Lambda |\n")
    result = runner.invoke(main, ["status", target])
    assert "Payment Gateway" in result.output
    assert "defined ✅" in result.output
    assert "customized ✅" in result.output
    assert "🔄" in result.output
    assert "2 entries" in result.output


def test_status_brownfield(tmp_path):
    """Status shows Code Elevation plan for brownfield projects."""
    runner = CliRunner()
    target = str(tmp_path / "proj")
    runner.invoke(main, ["init", target, "--mode", "brownfield", "--platform", "aws", "--name", "Legacy"])
    result = runner.invoke(main, ["status", target])
    assert "brownfield" in result.output
    assert "Code Elevation" in result.output


def test_status_with_archive(tmp_path):
    """Status shows archived intents."""
    runner = CliRunner()
    target = str(tmp_path / "proj")
    runner.invoke(main, ["init", target, "--mode", "greenfield", "--platform", "aws"])
    archive_dir = tmp_path / "proj" / "aidlc-docs" / "archive" / "old-intent-2026-01-01"
    archive_dir.mkdir(parents=True)
    result = runner.invoke(main, ["status", target])
    assert "1 (old-intent-2026-01-01)" in result.output
