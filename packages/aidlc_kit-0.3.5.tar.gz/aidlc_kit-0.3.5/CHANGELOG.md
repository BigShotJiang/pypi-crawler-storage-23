# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.3.5] - 2026-02-27

### Added
- Extensions install-on-demand model: extensions are now opt-in instead of scaffolded by default
- `extensions list`, `extensions install <name>`, `extensions remove <name>` CLI commands
- Extension registry (`registry.json`) with trigger-based suggestions during pre-flight
- `available.md` generated at scaffold time showing installable extensions
- `egs-init` command: creates an org-level EGS definition with a guided setup prompt
- `egs-definition.md` prompt template for enterprise projects (guided 10-category EGS walkthrough)
- Update check: CLI checks PyPI for newer versions on every run (atexit, cached 24h)
- 4 new IDE/agent integrations: crush, factory-droid, gemini-cli, iflow (24 total)
- Extension suggestion block in Mob Elaboration and Code Elevation prompts
- Mode-aware post-init message: brownfield says "Start Code Elevation", greenfield says "Start Mob Elaboration"
- Mode-aware router Session Start example
- `plan-templates/`, `standards/`, `audit/`, `intent-summaries/` added to scaffolded README Folder Guide

### Changed
- Extensions pre-flight simplified: removed Applicability Question (install = opt-in signal)
- EGS personalization flow: three paths (import via CLI, `egs-init`, or quick project-level setup)
- EGS overrides merged into single confirmation conversation
- Post-init message: collapsed "write intent" + "open IDE" into single step
- Scaffolded README workflow section: fully numbered per tier, no duplicate step numbers
- Main README: added `egs-init` and `extensions` to commands table, updated workflow section
- Update check now uses proper version comparison (`packaging.Version`) instead of string inequality

### Fixed
- Router tier bug (BUG-09): `tier` was passed as `overwrite` positionally to `_generate_ide_config`, causing standard projects to get enterprise routers with Setup section
- Scaffolded README: enterprise workflow had duplicate step number `2`

### Removed
- Placeholder scan block from all 5 prompts (was dead code)
- Extension Configuration section from `aidlc-state.md`

## [0.3.3] - 2026-02-25

### Added
- Security extensions with 14 OWASP-aligned rules organized by AI-DLC phase (design, build, ops)
- Extensions directory (`aidlc-docs/extensions/`) scaffolded by default with security extension
- Applicability question during pre-flight for extension opt-out
- Session Start welcome in router with dynamic state-based greeting
- Inline welcome methodology explainer in router (visible to AI without file reads)
- Structured question format (`standards/question-format.md`) with multiple-choice and adaptive delivery
- Contract-first API development in Mob Construction with conformance validation
- Code Elevation placeholder templates: `static_model.md`, `dynamic_model.md`, `technical_debt.md`
- Guardrails compliance report output path note in EGS section 11

### Fixed
- Cross-artifact consistency audit: 8 bugs fixed (BUG-01 through BUG-08)
- State file mode-aware rendering via `{{RITUAL_PROGRESS}}` placeholder
- EGS filename corrected from `enterprise_guardrails_spec.md` to `egs_definition.md`
- `design-artifacts/` path references corrected to actual scaffold paths
- Duplicate rule numbers renumbered in all 4 non-elevation prompts

## [0.3.0] - 2026-02-23

### Added
- Standard/enterprise tier system (`--tier standard|enterprise`)
- Router: Completion & Diagnostics section (consistency check, intent consolidation, bolt criteria, retrospective)
- IDE-aware README with `{{IDE_SETUP}}` section and router file table
- IDE-aware post-init output
- `PROJECT_CONTEXT.md` at repo root
- Install method: `pip install aidlc-kit` or `uvx aidlc-kit`

### Changed
- README prompts/ description: "used automatically by IDE routers, or paste manually"

## [0.2.0] - 2026-02-22

### Added
- Error handling framework (`standards/error-handling.md`) with 4 severity levels
- State tracking (`aidlc-state.md`) with prompt instructions and CLI integration
- Project complete detection: idle workspace after archive
- Init wizard mode with interactive numbered pickers
- EGS export/import (`export-egs`, `import-egs`) CLI commands
- 20 IDE/agent integrations with `--ide` flag
- Audit trail (`audit/audit-log.md`) with logging rules in all prompts
- Overconfidence prevention Session Rule in all 5 prompts
- Content validation (`standards/content-validation.md`)
- CLI `consistency` command (7-dimension structural check)
- Intent consolidation prompt and `intent-summaries/` directory
- Intent type field (feature/bugfix/maintenance)

### Changed
- IDE_CONFIGS refactored from boolean to string format types
- Construction plan paths changed to per-bolt `bolt-N/`
- Plan templates moved to `plan-templates/` folder

## [0.1.0] - 2026-02-21

### Added
- Initial release
- CLI commands: `init`, `check`, `status`, `update`, `archive`
- Greenfield and brownfield modes
- 5 platform variants (aws, azure, gcp, onprem, agnostic)
- Enterprise Guardrails Specification (EGS) v2.0 with 10 categories
- 5 prompt templates (Mob Elaboration, Mob Construction, Code Elevation, brownfield variants)
- Session retrospective wired into all prompts
- Bolt dependency declaration and verification
- Consistency check prompt (7-dimension cross-artifact audit)
- EGS personalization in pre-flight
- Guardrails overrides review in pre-flight
- Decision log with guardrail traceability
