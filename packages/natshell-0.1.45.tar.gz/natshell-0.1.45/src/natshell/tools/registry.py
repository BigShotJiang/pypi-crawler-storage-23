"""Tool registration, dispatch, and schema generation for the agent."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from natshell.tools.limits import ToolLimits

logger = logging.getLogger(__name__)

# Tools that are safe to use during plan generation (read-only + write_file for PLAN.md)
PLAN_SAFE_TOOLS: set[str] = {
    "read_file",
    "list_directory",
    "search_files",
    "natshell_help",
    "write_file",
    "git_tool",
    "fetch_url",
}


@dataclass
class ToolResult:
    """Result from a tool execution."""

    output: str = ""
    error: str = ""
    exit_code: int = 0
    truncated: bool = False

    def to_message_content(self) -> str:
        """Format for inclusion in the LLM conversation as a tool result."""
        parts = []
        if self.exit_code != 0:
            parts.append(f"Exit code: {self.exit_code}")
        if self.output:
            parts.append(f"{self.output}")
        if self.error:
            parts.append(f"stderr:\n{self.error}")
        if self.truncated:
            parts.append("[output was truncated]")
        return "\n".join(parts) if parts else "(no output)"


@dataclass
class ToolDefinition:
    """Schema definition for a tool, used to generate the LLM prompt."""

    name: str
    description: str
    parameters: dict[str, Any]  # JSON Schema object
    requires_confirmation: bool = False


# Type alias for tool handler functions
ToolHandler = Callable[..., Awaitable[ToolResult]]


class ToolRegistry:
    """Manages tool registration, schema generation, and dispatch."""

    def __init__(self) -> None:
        self._tools: dict[str, ToolHandler] = {}
        self._definitions: dict[str, ToolDefinition] = {}
        self.limits: ToolLimits = ToolLimits()

    def register(self, definition: ToolDefinition, handler: ToolHandler) -> None:
        """Register a tool with its definition and handler."""
        self._tools[definition.name] = handler
        self._definitions[definition.name] = definition
        logger.debug(f"Registered tool: {definition.name}")

    def get_tool_schemas(self, allowed: set[str] | None = None) -> list[dict[str, Any]]:
        """Generate OpenAI-compatible tool schemas for the LLM.

        Args:
            allowed: If provided, only include tools whose names are in this set.
        """
        schemas = []
        for defn in self._definitions.values():
            if allowed is not None and defn.name not in allowed:
                continue
            schemas.append(
                {
                    "type": "function",
                    "function": {
                        "name": defn.name,
                        "description": defn.description,
                        "parameters": defn.parameters,
                    },
                }
            )
        return schemas

    def get_definition(self, name: str) -> ToolDefinition | None:
        """Get a tool definition by name."""
        return self._definitions.get(name)

    async def execute(self, name: str, arguments: dict[str, Any]) -> ToolResult:
        """Execute a tool by name with the given arguments."""
        handler = self._tools.get(name)
        if handler is None:
            return ToolResult(
                output="",
                error=f"Unknown tool: {name}",
                exit_code=1,
            )

        try:
            return await handler(**arguments)
        except TypeError:
            # LLM may hallucinate wrong argument names (e.g. "param" instead
            # of "topic").  Attempt to remap values to the schema's expected
            # parameter names by position before giving up.
            remapped = self._remap_arguments(name, arguments)
            if remapped is not None:
                logger.warning(
                    "Tool %s: remapped bad arg names %s → %s",
                    name,
                    list(arguments.keys()),
                    list(remapped.keys()),
                )
                try:
                    return await handler(**remapped)
                except Exception as e:
                    logger.exception(f"Tool {name} raised an exception after remap")
                    return ToolResult(
                        output="",
                        error=f"Tool error: {type(e).__name__}: {e}",
                        exit_code=1,
                    )
            # Remap not possible — report the original TypeError with expected params
            defn = self._definitions.get(name)
            expected = list(defn.parameters.get("properties", {}).keys()) if defn else []
            return ToolResult(
                output="",
                error=f"Tool error: wrong arguments for {name}. "
                f"Got: {list(arguments.keys())}. "
                f"Expected: {expected}",
                exit_code=1,
            )
        except Exception as e:
            logger.exception(f"Tool {name} raised an exception")
            return ToolResult(
                output="",
                error=f"Tool error: {type(e).__name__}: {e}",
                exit_code=1,
            )

    def _remap_arguments(
        self,
        name: str,
        arguments: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Try to map LLM-provided argument values to the schema's expected
        parameter names by position.  Returns None if remapping isn't possible
        (e.g. argument count mismatch)."""
        defn = self._definitions.get(name)
        if defn is None:
            return None
        props = defn.parameters.get("properties", {})
        expected_keys = list(props.keys())
        provided_values = list(arguments.values())
        if len(provided_values) != len(expected_keys):
            return None
        return dict(zip(expected_keys, provided_values))

    @property
    def tool_names(self) -> list[str]:
        return list(self._tools.keys())


def create_default_registry() -> ToolRegistry:
    """Create a registry with all built-in tools registered."""
    from natshell.tools.edit_file import DEFINITION as EDIT_DEF
    from natshell.tools.edit_file import edit_file
    from natshell.tools.execute_shell import DEFINITION as EXEC_DEF
    from natshell.tools.execute_shell import execute_shell
    from natshell.tools.fetch_url import DEFINITION as FETCH_URL_DEF
    from natshell.tools.fetch_url import fetch_url
    from natshell.tools.git_tool import DEFINITION as GIT_DEF
    from natshell.tools.git_tool import git_tool
    from natshell.tools.list_directory import DEFINITION as LIST_DEF
    from natshell.tools.list_directory import list_directory
    from natshell.tools.natshell_help import DEFINITION as HELP_DEF
    from natshell.tools.natshell_help import natshell_help
    from natshell.tools.read_file import DEFINITION as READ_DEF
    from natshell.tools.read_file import read_file
    from natshell.tools.run_code import DEFINITION as RUN_CODE_DEF
    from natshell.tools.run_code import run_code
    from natshell.tools.search_files import DEFINITION as SEARCH_DEF
    from natshell.tools.search_files import search_files
    from natshell.tools.write_file import DEFINITION as WRITE_DEF
    from natshell.tools.write_file import write_file

    registry = ToolRegistry()
    registry.register(EXEC_DEF, execute_shell)
    registry.register(READ_DEF, read_file)
    registry.register(WRITE_DEF, write_file)
    registry.register(EDIT_DEF, edit_file)
    registry.register(LIST_DEF, list_directory)
    registry.register(SEARCH_DEF, search_files)
    registry.register(RUN_CODE_DEF, run_code)
    registry.register(GIT_DEF, git_tool)
    registry.register(HELP_DEF, natshell_help)
    registry.register(FETCH_URL_DEF, fetch_url)
    return registry
