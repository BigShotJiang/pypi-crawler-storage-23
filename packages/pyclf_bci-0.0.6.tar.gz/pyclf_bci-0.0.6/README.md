# pyclf
An implementation of various classifier for bci application.