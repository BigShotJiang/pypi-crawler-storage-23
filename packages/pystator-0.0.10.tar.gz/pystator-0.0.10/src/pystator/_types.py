"""Internal data types for PyStator FSM.

All frozen dataclasses that define the structure of the state machine:
State, Transition, TransitionResult, and supporting types.

These are the core value objects -- immutable definitions loaded from config.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pystator.errors import FSMError

# ---------------------------------------------------------------------------
# Name validation
# ---------------------------------------------------------------------------

_ALLOWED_NAME_CHARS = set(
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_."
)


def _validate_name(name: str, kind: str = "name") -> None:
    """Validate identifier: non-empty, starts with letter, only alnum/underscore/dot."""
    if not name:
        raise ValueError(f"{kind.capitalize()} cannot be empty")
    if not (name[0].isalpha() and all(c in _ALLOWED_NAME_CHARS for c in name)):
        raise ValueError(
            f"{kind.capitalize()} must start with a letter and contain only "
            f"letters, digits, underscores, and dots: {name}"
        )


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class StateType(str, Enum):
    """Classification of state behavior."""

    INITIAL = "initial"
    """The starting state of the machine. Exactly one required at root level."""

    STABLE = "stable"
    """A normal operating state that can transition to other states."""

    TERMINAL = "terminal"
    """An end state. No outbound transitions allowed."""

    ERROR = "error"
    """An error/fallback state for handling failures."""

    PARALLEL = "parallel"
    """A parallel (orthogonal) state containing independent regions."""

    CHOICE = "choice"
    """Pseudo-state: one entry, multiple guarded outs; resolved immediately."""


class HistoryType(str, Enum):
    """History pseudo-state type for compound states."""

    SHALLOW = "shallow"
    """Remember only the immediate child of the compound state."""

    DEEP = "deep"
    """Remember the full nested leaf state within the compound state."""


# ---------------------------------------------------------------------------
# Timeout
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Timeout:
    """Timeout configuration for automatic state transitions.

    Attributes:
        seconds: Duration in seconds before timeout triggers.
        destination: Target state to transition to on timeout.
    """

    seconds: float
    destination: str

    def __post_init__(self) -> None:
        if self.seconds <= 0:
            raise ValueError("Timeout seconds must be positive")
        if not self.destination:
            raise ValueError("Timeout destination cannot be empty")


# ---------------------------------------------------------------------------
# Region (parallel states)
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Region:
    """A region within a parallel (orthogonal) state.

    Each region is an independent sub-machine. All regions within a
    parallel state are active simultaneously.

    Attributes:
        name: Unique identifier for this region.
        initial: Initial state name within this region.
        states: State names that belong to this region.
        description: Human-readable description of this region.
    """

    name: str
    initial: str
    states: tuple[str, ...] = ()
    description: str = ""

    def __post_init__(self) -> None:
        _validate_name(self.name, "region name")
        if not self.initial:
            raise ValueError("Region must have an initial state")
        if self.states and self.initial not in self.states:
            raise ValueError(
                f"Region initial state '{self.initial}' must be in states list"
            )

    def contains(self, state_name: str) -> bool:
        """Check if this region contains the given state."""
        return state_name in self.states


# ---------------------------------------------------------------------------
# InvokeSpec (service invocation)
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class InvokeSpec:
    """Specification for an invoked service on a state.

    Attributes:
        id: Unique identifier for this service invocation.
        src: Service type or name (interpreted by the invoke adapter).
        on_done: Optional event name to emit when the service completes.
    """

    id: str
    src: str
    on_done: str | None = None


# ---------------------------------------------------------------------------
# CheckSpec (declarative guard check)
# ---------------------------------------------------------------------------

# Supported check operators
CHECK_OPS = frozenset(
    {"eq", "neq", "gt", "gte", "lt", "lte", "in", "not_in", "is_set", "is_null"}
)


@dataclass(frozen=True, slots=True)
class CheckSpec:
    """Declarative guard check -- structured field comparison.

    Evaluated directly by the guard evaluator, no registry needed.

    Attributes:
        field: Context key to check.
        op: Comparison operator (eq, neq, gt, gte, lt, lte, in, not_in, is_set, is_null).
        value: Comparison value (for single-value operators).
        values: Comparison values (for in/not_in operators).
    """

    field: str
    op: str
    value: Any = None
    values: tuple[Any, ...] = ()

    def __post_init__(self) -> None:
        if not self.field:
            raise ValueError("CheckSpec field cannot be empty")
        if self.op not in CHECK_OPS:
            raise ValueError(
                f"Unknown check operator '{self.op}'. "
                f"Supported: {', '.join(sorted(CHECK_OPS))}"
            )

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> CheckSpec:
        """Create from config dict: {field: ..., op: ..., value/values: ...}."""
        if not isinstance(config, dict) or "field" not in config or "op" not in config:
            raise ValueError(f"CheckSpec requires 'field' and 'op': {config}")
        return cls(
            field=config["field"],
            op=config["op"],
            value=config.get("value"),
            values=tuple(config.get("values", ())),
        )


# ---------------------------------------------------------------------------
# GuardSpec / ActionSpec
# ---------------------------------------------------------------------------

# Known effect types (closed vocabulary)
EFFECT_TYPES = frozenset(
    {"set", "timestamp", "increment", "decrement", "append", "clear"}
)


@dataclass(frozen=True, slots=True)
class GuardSpec:
    """Guard specification -- named function, inline expression, or declarative check.

    Exactly one of ``name``, ``expr``, or ``check`` must be set.

    Attributes:
        name: Guard function name (if using named guard).
        expr: Inline boolean expression (if using expression guard).
        check: Declarative field check (if using structured check).
        params: Optional parameters injected as ``_guard_params`` in context.
    """

    name: str | None = None
    expr: str | None = None
    check: CheckSpec | None = None
    params: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        set_count = sum(1 for x in (self.name, self.expr, self.check) if x is not None)
        if set_count == 0:
            raise ValueError("GuardSpec must have 'name', 'expr', or 'check'")
        if set_count > 1:
            raise ValueError("GuardSpec can only have one of 'name', 'expr', 'check'")

    @property
    def is_expression(self) -> bool:
        """True if this is an inline expression guard."""
        return self.expr is not None

    @property
    def is_check(self) -> bool:
        """True if this is a declarative field check."""
        return self.check is not None

    @property
    def has_params(self) -> bool:
        """True if this guard has parameters."""
        return bool(self.params)

    @classmethod
    def from_config(cls, config: str | dict[str, Any]) -> GuardSpec:
        """Create from config (string name, dict with expr/name/check)."""
        if isinstance(config, str):
            return cls(name=config)
        if isinstance(config, dict):
            if "expr" in config:
                return cls(expr=config["expr"])
            if "name" in config:
                return cls(name=config["name"], params=config.get("params", {}))
            if "check" in config:
                return cls(check=CheckSpec.from_config(config["check"]))
        raise ValueError(f"Invalid guard config: {config}")


def _normalize_effect_params(effect_type: str, value: Any) -> dict[str, Any]:
    """Normalize effect value from YAML into a params dict."""
    if effect_type == "set":
        if not isinstance(value, dict):
            raise ValueError(
                f"'set' effect requires a mapping, got {type(value).__name__}"
            )
        return dict(value)
    if effect_type in ("timestamp", "increment", "decrement", "clear"):
        if not isinstance(value, str):
            raise ValueError(f"'{effect_type}' effect requires a field name (string)")
        return {"field": value}
    if effect_type == "append":
        if not isinstance(value, dict) or "field" not in value or "value" not in value:
            raise ValueError("'append' effect requires {field: ..., value: ...}")
        return dict(value)
    raise ValueError(f"Unknown effect type: {effect_type}")


@dataclass(frozen=True, slots=True)
class ActionSpec:
    """Action specification -- named function, parameterized action, or declarative effect.

    For named functions: ``name`` is the function name in the action registry.
    For effects: ``effect`` is the effect type, ``name`` is ``_effect.<type>``,
    and ``params`` holds the effect data.

    Attributes:
        name: Action function name (or synthetic ``_effect.<type>`` for effects).
        params: Parameters for the action or effect data.
        effect: Effect type if this is a declarative effect (None for named functions).
    """

    name: str = ""
    params: dict[str, Any] = field(default_factory=dict)
    effect: str | None = None

    def __post_init__(self) -> None:
        if not self.name and not self.effect:
            raise ValueError("ActionSpec must have a 'name' or 'effect'")

    @property
    def is_effect(self) -> bool:
        """True if this is a declarative effect (not a named function)."""
        return self.effect is not None

    @property
    def has_params(self) -> bool:
        """True if this action has parameters."""
        return bool(self.params)

    @classmethod
    def from_config(cls, config: str | dict[str, Any]) -> ActionSpec:
        """Create from config (string name, dict with name+params, or effect dict)."""
        if isinstance(config, str):
            return cls(name=config)
        if isinstance(config, dict):
            if "name" in config:
                return cls(name=config["name"], params=config.get("params", {}))
            # Detect declarative effects
            for effect_type in EFFECT_TYPES:
                if effect_type in config:
                    params = _normalize_effect_params(effect_type, config[effect_type])
                    return cls(
                        name=f"_effect.{effect_type}",
                        params=params,
                        effect=effect_type,
                    )
        raise ValueError(f"Invalid action config: {config}")


# ---------------------------------------------------------------------------
# Delay parsing
# ---------------------------------------------------------------------------


def parse_delay(value: int | str) -> int:
    """Parse delay value to milliseconds.

    Args:
        value: Integer (ms) or string with unit (e.g., "5s", "10m", "1h").

    Returns:
        Delay in milliseconds.
    """
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        value = value.strip()
        if value.endswith("h"):
            return int(value[:-1]) * 3_600_000
        if value.endswith("m"):
            return int(value[:-1]) * 60_000
        if value.endswith("s"):
            return int(value[:-1]) * 1_000
        return int(value)
    raise ValueError(f"Invalid delay value: {value}")


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class State:
    """Immutable state definition in the FSM.

    Supports compound states (via initial_child) and parallel states (via regions).

    Attributes:
        name: Unique identifier for this state.
        type: Classification of state behavior.
        description: Human-readable description.
        parent: Parent state name for hierarchical states.
        initial_child: Default child state for compound states.
        regions: Region objects for parallel states.
        on_enter: Action specs to execute when entering.
        on_exit: Action specs to execute when exiting.
        invoke: Service invocations started on entry, stopped on exit.
        timeout: Timeout configuration for automatic transitions.
        group: Logical group name for visualization/organization.
        metadata: Additional user-defined metadata.
    """

    name: str
    type: StateType = StateType.STABLE
    description: str = ""
    parent: str | None = None
    initial_child: str | None = None
    regions: tuple[Region, ...] = ()
    on_enter: tuple[ActionSpec, ...] = ()
    on_exit: tuple[ActionSpec, ...] = ()
    invoke: tuple[InvokeSpec, ...] = ()
    timeout: Timeout | None = None
    group: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _validate_name(self.name, "state name")
        if self.type == StateType.PARALLEL and not self.regions:
            raise ValueError(
                f"Parallel state '{self.name}' must have at least one region"
            )
        if self.type != StateType.PARALLEL and self.regions:
            raise ValueError(f"Non-parallel state '{self.name}' cannot have regions")
        if self.regions:
            names = [r.name for r in self.regions]
            if len(names) != len(set(names)):
                raise ValueError(
                    f"Parallel state '{self.name}' has duplicate region names"
                )

    # -- convenience properties --

    @property
    def is_initial(self) -> bool:
        return self.type == StateType.INITIAL

    @property
    def is_terminal(self) -> bool:
        return self.type == StateType.TERMINAL

    @property
    def is_error(self) -> bool:
        return self.type == StateType.ERROR

    @property
    def is_parallel(self) -> bool:
        return self.type == StateType.PARALLEL

    @property
    def is_choice(self) -> bool:
        return self.type == StateType.CHOICE

    @property
    def has_timeout(self) -> bool:
        return self.timeout is not None

    @property
    def is_compound(self) -> bool:
        return self.initial_child is not None

    @property
    def is_leaf(self) -> bool:
        return not self.is_compound and not self.is_parallel

    @property
    def region_names(self) -> tuple[str, ...]:
        return tuple(r.name for r in self.regions)

    def get_region(self, name: str) -> Region | None:
        for region in self.regions:
            if region.name == name:
                return region
        return None


# ---------------------------------------------------------------------------
# Transition
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Transition:
    """Immutable transition definition between states.

    Attributes:
        trigger: Event name that triggers this transition.
        source: Set of valid source state names.
        dest: Target state name (may use "H(State)" or "H*(State)" for history).
        region: Optional region name for transitions within parallel states.
        guards: Guard specifications (named functions, expressions, or checks).
        actions: Action specifications (named functions or declarative effects).
        after: Delay in milliseconds before transition fires (for scheduling).
        internal: If True, skip exit/enter actions (internal/self-transition).
        auto: If True, this is an automatic (eventless) transition that fires
              when its source state is entered and guards pass.
        priority: Optional; lower value = higher priority. Same priority uses config order.
        description: Human-readable description.
        refs: Spec references for traceability (e.g., "AIDX C1.1", "JIRA-1234").
        metadata: Additional user-defined metadata.
    """

    trigger: str
    source: frozenset[str]
    dest: str
    region: str | None = None
    guards: tuple[GuardSpec, ...] = ()
    actions: tuple[ActionSpec, ...] = ()
    after: int | None = None
    internal: bool = False
    auto: bool = False
    priority: int | None = None
    description: str = ""
    refs: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.trigger:
            raise ValueError("Transition trigger cannot be empty")
        if not self.source:
            raise ValueError("Transition must have at least one source state")
        if not self.dest:
            raise ValueError("Transition destination cannot be empty")
        if self.after is not None and self.after < 0:
            raise ValueError("Transition delay must be non-negative")

    @property
    def is_region_transition(self) -> bool:
        """True if scoped to a specific parallel region."""
        return self.region is not None

    @property
    def is_delayed(self) -> bool:
        """True if this is a delayed transition."""
        return self.after is not None and self.after > 0

    @property
    def is_history_target(self) -> bool:
        """True if destination is a history pseudo-state (H(…) or H*(…))."""
        return self.dest.startswith("H(") or self.dest.startswith("H*(")

    @property
    def guard_names(self) -> tuple[str, ...]:
        """Named guard function names."""
        return tuple(g.name for g in self.guards if g.name is not None)

    @property
    def action_names(self) -> tuple[str, ...]:
        """Action function names."""
        return tuple(a.name for a in self.actions)

    @classmethod
    def from_single_source(
        cls,
        trigger: str,
        source: str,
        dest: str,
        *,
        region: str | None = None,
        guards: tuple[GuardSpec, ...] = (),
        actions: tuple[ActionSpec, ...] = (),
        after: int | None = None,
        internal: bool = False,
        auto: bool = False,
        description: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> Transition:
        """Create a transition with a single source state."""
        return cls(
            trigger=trigger,
            source=frozenset({source}),
            dest=dest,
            region=region,
            guards=guards,
            actions=actions,
            after=after,
            internal=internal,
            auto=auto,
            description=description,
            metadata=metadata or {},
        )

    def matches_source(self, state: str) -> bool:
        """True if the given state is a valid source for this transition."""
        return state in self.source

    def has_guards(self) -> bool:
        """True if this transition has any guards."""
        return len(self.guards) > 0

    def has_expression_guards(self) -> bool:
        """True if any guard is an inline expression (not a named guard)."""
        return any(g.is_expression for g in self.guards)


# ---------------------------------------------------------------------------
# TransitionResult
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class TransitionResult:
    """Immutable result of a transition computation.

    The FSM engine computes what SHOULD happen; callers persist state
    and execute actions.

    Attributes:
        success: Whether the transition was successful.
        source_state: The state before the transition attempt.
        target_state: The new state (None if failed).
        trigger: The event that triggered this transition.
        actions_to_execute: Transition action specs to run after persistence.
        on_exit_actions: Exit action specs from the source state.
        on_enter_actions: Entry action specs for the target state.
        error: Error details if transition failed.
        metadata: Additional context.
    """

    success: bool
    source_state: str
    target_state: str | None
    trigger: str
    actions_to_execute: tuple[ActionSpec, ...] = ()
    on_exit_actions: tuple[ActionSpec, ...] = ()
    on_enter_actions: tuple[ActionSpec, ...] = ()
    error: "FSMError | None" = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def all_action_specs(self) -> tuple[ActionSpec, ...]:
        """All action specs in execution order: exit -> transition -> enter."""
        return self.on_exit_actions + self.actions_to_execute + self.on_enter_actions

    @property
    def all_actions(self) -> tuple[str, ...]:
        """Action names in execution order."""
        return tuple(a.name for a in self.all_action_specs)

    @property
    def is_self_transition(self) -> bool:
        """True if source == target."""
        return self.success and self.source_state == self.target_state

    @property
    def state_changed(self) -> bool:
        """True if the state actually changed."""
        return self.success and self.source_state != self.target_state

    @classmethod
    def success_result(
        cls,
        source_state: str,
        target_state: str,
        trigger: str,
        actions: tuple[ActionSpec, ...] = (),
        on_exit: tuple[ActionSpec, ...] = (),
        on_enter: tuple[ActionSpec, ...] = (),
        metadata: dict[str, Any] | None = None,
    ) -> TransitionResult:
        """Create a successful transition result."""
        return cls(
            success=True,
            source_state=source_state,
            target_state=target_state,
            trigger=trigger,
            actions_to_execute=actions,
            on_exit_actions=on_exit,
            on_enter_actions=on_enter,
            metadata=metadata or {},
        )

    @classmethod
    def failure_result(
        cls,
        source_state: str,
        trigger: str,
        error: "FSMError",
        metadata: dict[str, Any] | None = None,
    ) -> TransitionResult:
        """Create a failed transition result."""
        return cls(
            success=False,
            source_state=source_state,
            target_state=None,
            trigger=trigger,
            error=error,
            metadata=metadata or {},
        )

    @classmethod
    def no_op_result(
        cls,
        current_state: str,
        trigger: str,
        metadata: dict[str, Any] | None = None,
    ) -> TransitionResult:
        """Create a no-op result (stay in same state, no actions)."""
        return cls(
            success=True,
            source_state=current_state,
            target_state=current_state,
            trigger=trigger,
            metadata=dict(metadata or {}, no_op=True, reason="no_matching_transition"),
        )
