"""API v1 routes."""

from __future__ import annotations

from pystator.api.routes.v1 import (
    auth,
    entities,
    machines,
    process,
    settings,
    templates,
)

__all__ = ["auth", "entities", "machines", "process", "settings", "templates"]
