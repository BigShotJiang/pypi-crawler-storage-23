"""Pydantic models for FSM configuration.

These models validate and parse YAML/JSON config into typed structures
before conversion to internal _types dataclasses.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

# -----------------------------------------------------------------------------
# Delay: int (ms) or str like "5s", "10m", "1h"
# -----------------------------------------------------------------------------

DelaySpec = int | str


# -----------------------------------------------------------------------------
# Meta
# -----------------------------------------------------------------------------


class MetaDef(BaseModel):
    """Top-level metadata."""

    version: str | None = None
    machine_name: str | None = None
    strict_mode: bool = True
    event_normalizer: Literal["lower", "upper"] | None = None
    description: str | None = None
    validate_context: bool = False

    model_config = {"extra": "allow"}


# -----------------------------------------------------------------------------
# Timeout (state)
# -----------------------------------------------------------------------------


class TimeoutDef(BaseModel):
    """Timeout configuration for a state."""

    seconds: float = Field(..., gt=0)
    destination: str


# -----------------------------------------------------------------------------
# Invoke item (state)
# -----------------------------------------------------------------------------


class InvokeItemDef(BaseModel):
    """Invoked service ref."""

    id: str
    src: str
    on_done: str | None = None


# -----------------------------------------------------------------------------
# Region (parallel state)
# -----------------------------------------------------------------------------


class RegionDef(BaseModel):
    """Region within a parallel state."""

    name: str = Field(..., pattern=r"^[a-zA-Z][a-zA-Z0-9_.]*$")
    initial: str
    states: list[str] = Field(default_factory=list)
    description: str = ""

    model_config = {"extra": "allow"}


# -----------------------------------------------------------------------------
# State definition
# -----------------------------------------------------------------------------


class StateDef(BaseModel):
    """State definition from config."""

    name: str = Field(..., pattern=r"^[a-zA-Z][a-zA-Z0-9_.]*$")
    type: Literal["initial", "stable", "terminal", "error", "parallel", "choice"] = (
        "stable"
    )
    description: str = ""
    parent: str | None = None
    initial_child: str | None = None
    regions: list[RegionDef] = Field(default_factory=list)
    on_enter: str | list[str | dict[str, Any]] = Field(
        default_factory=list, alias="on_enter"
    )
    on_exit: str | list[str | dict[str, Any]] = Field(
        default_factory=list, alias="on_exit"
    )
    invoke: list[InvokeItemDef] = Field(default_factory=list)
    timeout: TimeoutDef | None = None
    group: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"extra": "allow", "populate_by_name": True}

    @field_validator("on_enter", "on_exit", mode="before")
    @classmethod
    def _normalize_actions(cls, v: Any) -> list[str | dict[str, Any]]:
        if v is None:
            return []
        if isinstance(v, str):
            return [v]
        if isinstance(v, list):
            return list(v)
        return []


# -----------------------------------------------------------------------------
# Transition definition
# -----------------------------------------------------------------------------


class TransitionDef(BaseModel):
    """Transition definition from config.

    New fields:
        internal: If True, exit/enter actions are skipped (internal transition).
        auto: If True, this is an automatic (eventless) transition.
    """

    trigger: str | None = None
    source: str | list[str]
    dest: str
    region: str | None = None
    guards: list[str | dict[str, Any]] = Field(default_factory=list)
    actions: list[str | dict[str, Any]] = Field(default_factory=list)
    after: DelaySpec | None = None
    internal: bool = False
    auto: bool = False
    priority: int | None = None
    description: str = ""
    ref: str | None = None
    refs: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"extra": "allow"}

    @field_validator("guards", "actions", mode="before")
    @classmethod
    def _normalize_to_list(cls, v: Any) -> list[Any]:
        if v is None:
            return []
        if isinstance(v, str):
            return [v]
        if isinstance(v, dict):
            return [v]
        if isinstance(v, list):
            return list(v)
        return []

    @model_validator(mode="after")
    def trigger_or_after_or_auto(self) -> "TransitionDef":
        """Require either trigger, after, or auto."""
        has_trigger = bool(self.trigger and self.trigger.strip())
        has_after = self.after is not None
        if not has_trigger and not has_after and not self.auto:
            raise ValueError("Transition must have 'trigger', 'after', or 'auto: true'")
        return self


# -----------------------------------------------------------------------------
# Error policy, events (metadata)
# -----------------------------------------------------------------------------


class ErrorPolicyDef(BaseModel):
    """Error handling configuration."""

    default_fallback: str | None = None
    retry_attempts: int = Field(default=0, ge=0)

    model_config = {"extra": "allow"}


class StateVariableDef(BaseModel):
    """State variable definition (context contract for the machine)."""

    key: str
    type: str | None = None
    description: str | None = None
    default: Any = None
    required: bool = False

    model_config = {"extra": "allow"}


class EventItemDef(BaseModel):
    """Documented event (metadata only)."""

    name: str
    description: str | None = None
    payload: dict[str, Any] | None = None

    model_config = {"extra": "allow"}


# -----------------------------------------------------------------------------
# Root config
# -----------------------------------------------------------------------------


def _normalize_state_variable_item(item: Any) -> dict[str, Any]:
    """Normalize a state variable item (string or dict) to a dict for StateVariableDef."""
    if isinstance(item, str):
        return {"key": item}
    if isinstance(item, dict) and "key" in item:
        return item
    if isinstance(item, dict):
        return {"key": str(item.get("key", "")), **item}
    return {"key": str(item)}


class MachineConfig(BaseModel):
    """Root FSM configuration."""

    meta: MetaDef = Field(default_factory=MetaDef)
    groups: dict[str, Any] | None = None
    states: list[StateDef]
    transitions: list[TransitionDef]
    error_policy: ErrorPolicyDef | dict[str, Any] | None = None
    state_variables: list[StateVariableDef] | None = None
    events: list[EventItemDef] | list[dict[str, Any]] | None = None

    model_config = {"extra": "allow"}

    @field_validator("state_variables", mode="before")
    @classmethod
    def _normalize_state_variables(cls, v: Any) -> Any:
        """Accept list of strings (shorthand) or list of dicts; normalize to list of dicts."""
        if v is None:
            return None
        if not isinstance(v, list):
            return v
        return [_normalize_state_variable_item(item) for item in v]

    @field_validator("states")
    @classmethod
    def at_least_one_state(cls, v: list[StateDef]) -> list[StateDef]:
        if not v:
            raise ValueError("At least one state is required")
        return v

    @model_validator(mode="after")
    def _state_variable_keys_unique(self) -> "MachineConfig":
        """Ensure state_variable keys are unique."""
        if not self.state_variables:
            return self
        keys = [sv.key for sv in self.state_variables]
        if len(keys) != len(set(keys)):
            seen: set[str] = set()
            for k in keys:
                if k in seen:
                    raise ValueError(f"Duplicate state_variable key: {k!r}")
                seen.add(k)
        return self
