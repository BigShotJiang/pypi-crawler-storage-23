"""Shared config parsing helpers used by both the Pydantic and raw parsers."""

from __future__ import annotations

from typing import Any

from pystator._types import ActionSpec, GuardSpec, State, Transition

# ---------------------------------------------------------------------------
# Synthetic trigger generation
# ---------------------------------------------------------------------------


def implicit_trigger_for_after(source: str, after_ms: int) -> str:
    """Generate synthetic trigger for delayed transition with no explicit trigger."""
    return f"_after_{source}_{after_ms}_ms"


def auto_trigger(source: str) -> str:
    """Generate synthetic trigger for auto (eventless) transitions."""
    return f"_auto_{source}"


# ---------------------------------------------------------------------------
# Guard / action spec parsing
# ---------------------------------------------------------------------------


def parse_guard_specs(raw: Any) -> tuple[GuardSpec, ...]:
    """Parse guards field to tuple of GuardSpec."""
    items = normalize_to_list(raw)
    return tuple(
        GuardSpec.from_config(item) if isinstance(item, dict) else GuardSpec(name=item)
        for item in items
    )


def parse_action_specs(raw: Any) -> tuple[ActionSpec, ...]:
    """Parse actions/on_enter/on_exit field to tuple of ActionSpec."""
    items = normalize_to_list(raw)
    return tuple(
        (
            ActionSpec.from_config(item)
            if isinstance(item, dict)
            else ActionSpec(name=item)
        )
        for item in items
    )


def normalize_to_list(raw: Any) -> list[Any]:
    """Normalize a value to a list (handles None, str, dict, list)."""
    if raw is None:
        return []
    if isinstance(raw, str):
        return [raw]
    if isinstance(raw, dict):
        return [raw]
    if isinstance(raw, list):
        return list(raw)
    return []


# ---------------------------------------------------------------------------
# Wildcard expansion
# ---------------------------------------------------------------------------


def expand_wildcard_sources(
    states: dict[str, State],
    transitions: list[Transition],
) -> list[Transition]:
    """Expand wildcard source '*' to all non-terminal state names."""
    non_terminal = frozenset(
        name for name, state in states.items() if not state.is_terminal
    )
    if not non_terminal:
        return transitions

    expanded: list[Transition] = []
    for t in transitions:
        if t.source == frozenset({"*"}):
            expanded.append(
                Transition(
                    trigger=t.trigger,
                    source=non_terminal,
                    dest=t.dest,
                    region=t.region,
                    guards=t.guards,
                    actions=t.actions,
                    after=t.after,
                    internal=t.internal,
                    auto=t.auto,
                    priority=t.priority,
                    description=t.description,
                    refs=t.refs,
                    metadata=t.metadata,
                )
            )
        else:
            expanded.append(t)
    return expanded
