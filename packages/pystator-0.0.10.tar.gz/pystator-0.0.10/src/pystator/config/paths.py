"""Shared path-resolution helpers for PyStator configuration files."""

from __future__ import annotations

from pathlib import Path

_CONFIG_FILENAME = "pystator.cfg"
_MAX_PARENT_WALK = 5


def find_config_file(filename: str = _CONFIG_FILENAME) -> Path | None:
    """Locate a config file by searching standard locations.

    Search order (mirrors pycharter):
        1. Current working directory
        2. ``~/.pystator/``
        3. Project root (directory containing alembic.ini), then look for
           *filename* in that directory
    """
    # 1. Current working directory
    cwd_path = Path.cwd() / filename
    if cwd_path.exists():
        return cwd_path

    # 2. User home directory
    home_path = Path.home() / ".pystator" / filename
    if home_path.exists():
        return home_path

    # 3. Project root (where alembic.ini typically is)
    current = Path.cwd()
    for _ in range(_MAX_PARENT_WALK):
        alembic_path = current / "alembic.ini"
        if alembic_path.exists():
            config_path = current / filename
            if config_path.exists():
                return config_path
        current = current.parent

    return None
