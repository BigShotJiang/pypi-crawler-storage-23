"""PyStator -- Config-driven finite state machine for Python.

Config is the single source of truth. Python provides implementations.

Quick start:
    >>> from pystator import StateMachine
    >>>
    >>> machine = StateMachine.from_yaml("order_fsm.yaml")
    >>>
    >>> @machine.guard("is_valid")
    ... def is_valid(ctx):
    ...     return ctx.get("valid", False)
    >>>
    >>> @machine.action("notify")
    ... def notify(ctx):
    ...     send_email(ctx["email"], "State changed")
    >>>
    >>> # Stateless processing
    >>> result = machine.process("pending", "confirm", {"valid": True})
    >>>
    >>> # Or create a stateful instance
    >>> order = machine.create(context={"order_id": "123"})
    >>> order.send("confirm", valid=True)
"""

from __future__ import annotations

try:
    from importlib.metadata import version as _get_version

    __version__ = _get_version("pystator")
except Exception:
    __version__ = "2.0.0"

# Core types
from pystator._types import (
    EFFECT_TYPES,
    ActionSpec,
    CheckSpec,
    GuardSpec,
    HistoryType,
    Region,
    State,
    StateType,
    Timeout,
    Transition,
    TransitionResult,
)
from pystator.actions import ActionExecutor, ActionRegistry, ActionResult, ActionStatus

# Builtins
from pystator.builtins import builtin_registries, register_builtins

# Declarative features
from pystator.checks import evaluate_check
from pystator.context import TransitionContext
from pystator.effects import apply_effect

# Errors
from pystator.errors import (
    ActionNotFoundError,
    ConfigurationError,
    ErrorCode,
    ErrorPolicy,
    FSMError,
    GuardNotFoundError,
    GuardRejectedError,
    InvalidTransitionError,
    StaleVersionError,
    TerminalStateError,
    TimeoutExpiredError,
    UndefinedStateError,
    UndefinedTriggerError,
)

# Event
from pystator.event import Event

# Guards + Actions
from pystator.guards import (
    GUARD_PARAMS_KEY,
    GuardEvaluator,
    GuardRegistry,
    GuardResult,
    all_of,
    any_of,
    equals,
    greater_than,
    in_list,
    negate,
)

# Hooks
from pystator.hooks import (
    LoggingHook,
    MetricsCollector,
    TransitionHook,
    TransitionObserver,
)
from pystator.instance import EntitySession, EventRecorder, RecordedEvent
from pystator.lint import LintSeverity, LintWarning, lint

# Machine + Instance
from pystator.machine import StateMachine, StateMachineBuilder, check_timeout

# Orchestrator
from pystator.orchestrator import ContextValidatorFn, Orchestrator

# Sinks
from pystator.sinks import (
    EventSink,
    LoggingEventSink,
    LoggingMetricSink,
    MetricSink,
    configure_event_sink,
    configure_metric_sink,
    create_metric_action,
    create_publish_action,
)

# Stores
from pystator.stores import (
    AsyncStateStore,
    InMemoryStateStore,
    StateStore,
    StateStoreClient,
    VersionedStateStore,
)

# Optional store backends (may be None if dependencies are missing)
try:
    from pystator.stores.sqlalchemy import SQLAlchemyStateStore
except ImportError:
    SQLAlchemyStateStore = None  # type: ignore[assignment,misc]

try:
    from pystator.stores.redis import RedisStateStore
except ImportError:
    RedisStateStore = None  # type: ignore[assignment,misc]

# Parallel
from pystator._parallel import ParallelStateConfig

__all__ = [
    # Machine + Instance
    "StateMachine",
    "StateMachineBuilder",
    "EntitySession",
    "EventRecorder",
    "RecordedEvent",
    "check_timeout",
    # Core types
    "State",
    "StateType",
    "Transition",
    "TransitionResult",
    "Event",
    "GuardSpec",
    "ActionSpec",
    "CheckSpec",
    "EFFECT_TYPES",
    "Region",
    "Timeout",
    "ParallelStateConfig",
    "TransitionContext",
    # Errors
    "FSMError",
    "ConfigurationError",
    "InvalidTransitionError",
    "GuardRejectedError",
    "UndefinedStateError",
    "UndefinedTriggerError",
    "TerminalStateError",
    "GuardNotFoundError",
    "ActionNotFoundError",
    "TimeoutExpiredError",
    "StaleVersionError",
    "ErrorCode",
    # Builtins
    "register_builtins",
    "builtin_registries",
    # Declarative features
    "apply_effect",
    "evaluate_check",
    # Guards + Actions
    "GuardRegistry",
    "GuardEvaluator",
    "GuardResult",
    "all_of",
    "any_of",
    "equals",
    "greater_than",
    "in_list",
    "negate",
    "ActionRegistry",
    "ActionExecutor",
    "ActionResult",
    "ActionStatus",
    # Hooks
    "TransitionHook",
    "TransitionObserver",
    "LoggingHook",
    "MetricsCollector",
    # Lint
    "lint",
    "LintWarning",
    "LintSeverity",
    # Orchestrator
    "ContextValidatorFn",
    "Orchestrator",
    # Stores
    "StateStore",
    "AsyncStateStore",
    "StateStoreClient",
    "InMemoryStateStore",
    "SQLAlchemyStateStore",
    "RedisStateStore",
    "VersionedStateStore",
    # Sinks
    "EventSink",
    "MetricSink",
    "LoggingEventSink",
    "LoggingMetricSink",
    "configure_event_sink",
    "configure_metric_sink",
    "create_publish_action",
    "create_metric_action",
]
