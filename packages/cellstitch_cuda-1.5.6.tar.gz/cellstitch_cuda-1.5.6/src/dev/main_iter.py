import os.path
import tifffile
from cellstitch_cuda.pipeline import cellstitch_cuda

imgs = [
    r"E:\1_DATA\Rheenen\tvl_jr\11237\analysis\2025-12-19_2572192_CIS_2M_ColonNormal\2025Dec19_2572192_CIS_2M_ColonNormal_tilescan-1position-2\output.tif",
    r"E:\1_DATA\Rheenen\tvl_jr\11237\analysis\2026-01-29_2572194_1M_CIS_Colon\2026Jan29_2572194_1M_CIS_Colon_region-2\output.tif",
    r"E:\1_DATA\Rheenen\tvl_jr\11237\analysis\2026-01-29_2572194_1M_CIS_Colon\2026Jan29_2572194_1M_CIS_Colon_region-3\output.tif",
    r"E:\1_DATA\Rheenen\tvl_jr\11237\analysis\2025-12-19_2572192_CIS_2M_ColonNormal\2025Dec19_2572192_CIS_2M_ColonNormal_tilescan-1region-1\output.tif",
]

folders = [os.path.split(img)[0] for img in imgs]
for i, img in enumerate(imgs):
    masks = cellstitch_cuda(
        img,
        output_masks=True,
        verbose=True,
        seg_mode="cells",
        interpolation=False,
        n_jobs=-1,
        z_step=2,
        pixel_size=1/2.2,
        bleach_correct=False,
    )

    tifffile.imwrite(os.path.join(folders[i], "cellstitch_masks.tif"), masks)
