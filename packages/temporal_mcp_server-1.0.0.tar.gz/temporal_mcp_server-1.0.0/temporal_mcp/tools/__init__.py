"""Tool definitions for MCP server."""
