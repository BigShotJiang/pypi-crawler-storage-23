"""Tests for embedding provider layer."""
