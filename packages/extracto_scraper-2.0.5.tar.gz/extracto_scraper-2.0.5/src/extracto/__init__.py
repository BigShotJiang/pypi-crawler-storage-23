"""
Extracto
An AI-powered web scraper.
"""

from .config import CrawlerConfig
from .crawler_engine import CrawlerEngine

__all__ = ["CrawlerConfig", "CrawlerEngine"]
