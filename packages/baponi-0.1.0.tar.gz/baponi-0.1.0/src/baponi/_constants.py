"""Internal constants for the Baponi SDK."""

from __future__ import annotations

import re

VERSION = "0.1.0"
USER_AGENT = f"baponi-python/{VERSION}"
DEFAULT_BASE_URL = "https://api.baponi.ai"
EXECUTE_PATH = "/v1/sandbox/execute"

DEFAULT_TIMEOUT = 60.0
DEFAULT_MAX_RETRIES = 2
DEFAULT_CONNECT_TIMEOUT = 10.0
DEFAULT_EXECUTION_TIMEOUT = 30
EXECUTION_READ_BUFFER = 10.0  # seconds added to read timeout beyond execution timeout

SUPPORTED_LANGUAGES = frozenset({"python", "bash", "node", "ruby", "php", "deno", "bun"})
MAX_CODE_SIZE = 1_048_576  # 1 MB
MAX_TIMEOUT = 300
MIN_TIMEOUT = 1
MAX_THREAD_ID_LENGTH = 128
MAX_METADATA_KEYS = 10
MAX_METADATA_KEY_LENGTH = 40
MAX_METADATA_VALUE_LENGTH = 256

THREAD_ID_PATTERN = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$")
METADATA_KEY_PATTERN = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_.\-]*$")
