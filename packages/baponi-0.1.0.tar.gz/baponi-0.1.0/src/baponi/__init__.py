"""Baponi — sandboxed code execution for AI agents.

Quick start::

    from baponi import Baponi

    client = Baponi()  # reads BAPONI_API_KEY from env
    result = client.execute("print('Hello!')")
    print(result.stdout)  # Hello!
"""

from baponi._async_client import AsyncBaponi
from baponi._client import Baponi
from baponi._constants import VERSION
from baponi.exceptions import (
    APITimeoutError,
    APIValidationError,
    AuthenticationError,
    BaponiError,
    ForbiddenError,
    RateLimitError,
    ServerError,
    ThreadBusyError,
)
from baponi.types import SandboxResult

__version__ = VERSION

__all__ = [
    "APITimeoutError",
    "APIValidationError",
    "AsyncBaponi",
    "AuthenticationError",
    "Baponi",
    "BaponiError",
    "ForbiddenError",
    "RateLimitError",
    "SandboxResult",
    "ServerError",
    "ThreadBusyError",
]
