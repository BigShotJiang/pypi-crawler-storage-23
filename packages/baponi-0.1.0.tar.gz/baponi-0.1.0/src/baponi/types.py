"""Response types for the Baponi SDK."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class SandboxResult(BaseModel):
    """Result of a sandbox code execution.

    Returned for all successful API calls, including executions that exited
    with a non-zero exit code. Check ``success`` or ``exit_code`` to
    determine whether the code itself succeeded.
    """

    model_config = ConfigDict(frozen=True)

    success: bool
    stdout: str
    stderr: str
    exit_code: int
    duration_ms: int
    sandbox_overhead_ms: int
    network_egress_bytes: int
    storage_egress_bytes: int
    error: str | None = None
