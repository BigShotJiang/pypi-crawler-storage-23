# Baponi Python SDK

Sandboxed code execution for AI agents. Run Python, Node.js, Bash, Ruby, PHP, Deno, and Bun in secure, isolated containers with sub-20ms overhead.

## Installation

```bash
pip install baponi
```

With framework integrations:

```bash
pip install baponi[langchain]     # LangChain
pip install baponi[openai]        # OpenAI Agents SDK
pip install baponi[anthropic]     # Anthropic
pip install baponi[google]        # Google Gemini
pip install baponi[crewai]        # CrewAI
pip install baponi[all]           # All frameworks
```

## Quick Start

```python
from baponi import Baponi

client = Baponi()  # reads BAPONI_API_KEY from env
result = client.execute("print('Hello!')")
print(result.stdout)  # Hello!
```

## Async

```python
from baponi import AsyncBaponi

async with AsyncBaponi() as client:
    result = await client.execute("print('Hello!')")
    print(result.stdout)
```

## Supported Languages

```python
client.execute("print('Python')")
client.execute("echo 'Bash'", language="bash")
client.execute("console.log('Node')", language="node")
client.execute("puts 'Ruby'", language="ruby")
client.execute("echo 'PHP';", language="php")
client.execute("console.log('Deno')", language="deno")
client.execute("console.log('Bun')", language="bun")
```

## Persistent State

Pass a `thread_id` to persist files and installed packages across calls:

```python
client.execute("pip install pandas", language="bash", thread_id="analysis-session")
client.execute("""
import pandas as pd
df = pd.DataFrame({'x': [1, 2, 3]})
df.to_csv('/home/safesandy/data.csv', index=False)
print(df.describe())
""", thread_id="analysis-session")
```

## Framework Integrations

### LangChain

```python
from baponi.langchain import code_sandbox
from langchain.agents import create_react_agent

agent = create_react_agent(llm, tools=[code_sandbox])
```

### OpenAI Agents SDK

```python
from baponi.openai import code_sandbox
from agents import Agent

agent = Agent(name="coder", tools=[code_sandbox])
```

### Anthropic

```python
from baponi.anthropic import code_sandbox_tool, handle_tool_call
import anthropic

client = anthropic.Anthropic()
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    tools=[code_sandbox_tool],
    messages=[{"role": "user", "content": "Calculate fibonacci(10) in Python"}],
)

for block in response.content:
    if block.type == "tool_use":
        result = handle_tool_call(block.name, block.input)
        print(result)
```

### Google Gemini

```python
from baponi.google import code_sandbox
from google import genai

client = genai.Client()
chat = client.chats.create(
    model="gemini-2.5-flash",
    config={"tools": [code_sandbox]},
)
response = chat.send_message("Calculate pi to 100 digits")
```

### CrewAI

```python
from baponi.crewai import code_sandbox
from crewai import Agent

agent = Agent(role="Data Analyst", tools=[code_sandbox])
```

### Custom Configuration

All integrations support `create_code_sandbox()` for power users:

```python
from baponi.langchain import create_code_sandbox

sandbox = create_code_sandbox(
    api_key="sk-...",
    base_url="https://your-baponi-instance.com",
    thread_id="shared-session",        # Default thread for all calls
    timeout=120,                        # Default timeout
    metadata={"user_id": "usr_123"},   # Metadata on every call
)
```

## Error Handling

API errors and execution errors are separate concepts:

```python
from baponi import Baponi, AuthenticationError, RateLimitError

client = Baponi()

# API errors raise exceptions
try:
    result = client.execute("print(1)")
except AuthenticationError:
    print("Invalid API key")
except RateLimitError as e:
    print(f"Rate limited, retry after {e.retry_after}s")

# Execution errors return SandboxResult with success=False
result = client.execute("raise ValueError('oops')")
if not result.success:
    print(f"Code failed with exit code {result.exit_code}")
    print(f"stderr: {result.stderr}")
```

### Exception Hierarchy

| Exception | HTTP Status | Description |
|-----------|------------|-------------|
| `BaponiError` | — | Base exception for all API errors |
| `AuthenticationError` | 401 | Invalid or missing API key |
| `ForbiddenError` | 403 | Insufficient permissions |
| `RateLimitError` | 429 | Rate limit exceeded |
| `ThreadBusyError` | 409 | Thread already executing |
| `APITimeoutError` | 504 | Server-side timeout |
| `ServerError` | 500/503 | Server error |
| `APIValidationError` | 400 | Invalid request |

## Configuration

```python
from baponi import Baponi

# Self-hosted deployment
client = Baponi(
    api_key="sk-...",
    base_url="https://baponi.internal.company.com",
)

# Custom HTTP client (proxies, observability, custom TLS)
import httpx

http_client = httpx.Client(
    proxies="http://proxy.internal:8080",
    verify="/path/to/ca-bundle.crt",
)
client = Baponi(api_key="sk-...", http_client=http_client)

# Retry configuration
client = Baponi(
    api_key="sk-...",
    max_retries=0,    # Disable retries
    timeout=120.0,    # Connection timeout (not execution timeout)
)
```

## SandboxResult

```python
result = client.execute("print('hi')")

result.success              # bool — True if exit_code == 0
result.stdout               # str — standard output
result.stderr               # str — standard error
result.exit_code            # int — process exit code
result.duration_ms          # int — total execution time
result.sandbox_overhead_ms  # int — sandbox setup overhead
result.network_egress_bytes # int — bytes sent to network
result.storage_egress_bytes # int — bytes written to storage
result.error                # str | None — error message if failed
result.model_dump()         # dict — Pydantic serialization
```

## Coming Soon

- **Files API** — upload/download files to sandbox threads (`/v1/files/*`)
- **Web Tools API** — web search and fetch from within sandboxes (`/v1/web/search`, `/v1/web/fetch`)
