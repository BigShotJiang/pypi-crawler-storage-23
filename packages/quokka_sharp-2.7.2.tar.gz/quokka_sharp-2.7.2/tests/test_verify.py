# tests/test_veri.py
import pytest
import quokka_sharp as qk

# Import QASM snippets
from qasm_cases import (
    QASM_IDENTITY_1Q,
    QASM_X_1Q,
    QASM_BELL_2Q,
    QASM_CX_01_2Q,
    QASM_H_1Q,
)

VALID_RESULTS = ("True", "False", "TIMEOUT")


def write_qasm(tmp_path, name: str, content: str) -> str:
    """Write a QASM string into a temporary file and return its file path."""
    p = tmp_path / name
    p.write_text(content)
    return str(p)


def assert_valid_result(res):
    """Assert that verify() returned a valid status."""
    assert res in VALID_RESULTS, f"Unexpected verify() result: {res!r}"


@pytest.mark.parametrize(
    "name,qasm,basis,precons,postcons,expected",
    [
        # --- Deterministic True cases (stable sanity checks) ---

        # Identity on |0>: Z should hold (depending on your semantics).
        ("id_1q_pauli_Z_true", QASM_IDENTITY_1Q, "pauli", {0: "Z"}, {0: "Z"}, "True"),

        # --- Deterministic False case (depends on comp encoding) ---

        # X gate flips the computational basis state; pre==post should become false.
        ("x_1q_comp_same_state_false", QASM_X_1Q, "comp", {0: 1}, {0: 1}, "False"),

        # --- Smoke tests (only check that the call works + returns a valid status) ---

        ("h_1q_smoke", QASM_H_1Q, "pauli", {0: 1}, {0: "Z"}, None),
        ("cx_2q_smoke", QASM_CX_01_2Q, "comp", {0: 1, 1: 1}, {0: 1, 1: 1}, None),
        ("bell_2q_smoke", QASM_BELL_2Q, "pauli", {0: 1, 1: 1}, {0: 1}, None),

        # --- Invalid pre/post conditions (should raise) ---

        # Invalid basis-specific postcondition: pauli post must be I/X/Y/Z (here "A" is invalid)
        ("invalid_post_pauli_symbol", QASM_IDENTITY_1Q, "pauli", {0: 1}, {0: "A"}, "RAISE"),

        # Invalid computational postcondition type: comp expects 0/1, but gets "Z"
        ("invalid_post_comp_type", QASM_IDENTITY_1Q, "comp", {0: 1}, {0: "Z"}, "RAISE"),

        # Invalid precondition value: not in {0,1} / not a supported spec
        ("invalid_pre_value", QASM_IDENTITY_1Q, "comp", {0: 2}, {0: 1}, "RAISE"),

        # Invalid qubit index (out of range for 1-qubit circuit)
        ("invalid_index_out_of_range", QASM_IDENTITY_1Q, "comp", {1: 1}, {0: 1}, "RAISE"),

        # Invalid key type (qubit index should be int)
        ("invalid_index_type", QASM_IDENTITY_1Q, "comp", {"0": 1}, {0: 1}, "RAISE"),
    ],
)
def test_veri_cases(tmp_path, name, qasm, basis, precons, postcons, expected):
    """
    Parametrized test runner for multiple hand-crafted QASM circuits.

    expected semantics:
    - None: smoke test (must return a valid status)
    - "RAISE": must raise on invalid inputs
    - otherwise: must return exactly that status string
    """
    qasmfile = write_qasm(tmp_path, f"{name}.qasm", qasm)

    if expected == "RAISE":
        with pytest.raises((ValueError, AssertionError, TypeError, KeyError, IndexError)):
            qk.functionalities.verify(qasmfile, basis, precons, postcons)
        return

    res = qk.functionalities.verify(qasmfile, basis, precons, postcons)
    assert_valid_result(res)

    if expected is not None:
        assert res == expected


def test_veri_invalid_basis_returns_valid_status_or_raises(tmp_path):
    """
    Optional: test behavior on an invalid basis string.

    Depending on how you implemented verify(), it might:
    - raise an exception, or
    - treat unknown basis as 'pauli'/default, or
    - return False/TIMEOUT.

    This test is intentionally flexible.
    """
    qasmfile = write_qasm(tmp_path, "id_invalid_basis.qasm", QASM_IDENTITY_1Q)

    try:
        res = qk.functionalities.verify(qasmfile, "invalid_basis", {0: 1}, {0: "Z"})
    except Exception:
        return

    assert_valid_result(res)


def test_veri_missing_file_raises():
    """verify() should raise an exception if the QASM file does not exist."""
    with pytest.raises(Exception):
        qk.functionalities.verify("no_such_file.qasm", "pauli", {0: 1}, {0: "Z"})
