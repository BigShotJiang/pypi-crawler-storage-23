"""
Pipeline helper utilities for dlt pipelines.

This module provides common functionality for running dlt pipelines.

Usage:
    from dlt_utils import validate_refresh_args, filter_resources, print_resources
    from dlt_utils import get_configs_from_env, print_configs
"""
import logging
import os
from dataclasses import fields, is_dataclass
from typing import Any, Callable, Sequence, Type, TypeVar, get_type_hints

T = TypeVar('T')

logger = logging.getLogger(__name__)


def validate_refresh_args(
    refresh: str | None,
    resources_filter: list[str] | None,
) -> None:
    """
    Validate that refresh arguments are used correctly.

    Raises ValueError if drop_sources is used with a resource filter,
    as this would drop ALL tables but only reload selected resources.

    Args:
        refresh: The refresh mode ('drop_sources' or 'drop_resources').
        resources_filter: List of resources being loaded (None = all).

    Raises:
        ValueError: If drop_sources is used with a resource filter.
    """
    if refresh == "drop_sources" and resources_filter:
        raise ValueError(
            f"--refresh drop_sources cannot be used with --resources filter. "
            f"This would drop ALL tables but only reload selected resources. "
            f"Use --refresh drop_resources to only drop and rebuild specific resources, "
            f"or remove --resources to do a full rebuild of all resources."
        )


def filter_resources(
    available_resources: list[str],
    requested_resources: list[str] | None,
) -> list[str]:
    """
    Filter available resources based on requested resources.

    Args:
        available_resources: List of all available resource names.
        requested_resources: List of requested resources (None = all).

    Returns:
        List of valid resources to load.

    Raises:
        ValueError: If no valid resources are found.
    """
    if requested_resources is None:
        return available_resources

    valid_resources = [
        r for r in requested_resources if r in available_resources]

    if not valid_resources:
        raise ValueError(
            f"No valid resources found. "
            f"Requested: {requested_resources}. "
            f"Available: {available_resources}"
        )

    # Log any requested resources that weren't found
    invalid = set(requested_resources) - set(valid_resources)
    if invalid:
        logger.warning(f"Ignored invalid resources: {invalid}")

    return valid_resources


def print_resources(source: Any) -> None:
    """
    Print available resources from a dlt source and exit.

    Args:
        source: A dlt source object with a resources attribute.
    """
    available_resources = sorted(get_resource_names(source))

    print("\nAvailable resources:")
    print("-" * 40)
    for resource in available_resources:
        print(f"  - {resource}")
    print("-" * 40)
    print(f"\nTotal: {len(available_resources)} resources")


def get_resource_names(source: Any) -> list[str]:
    """
    Get list of resource names from a dlt source.

    Args:
        source: A dlt source object with a resources attribute.

    Returns:
        List of resource names.
    """
    return [r.name for r in source.resources.values()]


def mask_sensitive_value(value: str | None, show_chars: int = 2) -> str:
    """
    Mask a sensitive value (like API key) showing only first and middle characters.

    Args:
        value: The value to mask.
        show_chars: Number of characters to show at start and middle.

    Returns:
        Masked value like "ab..cd..***" or "N/A" if not set.
    """
    if not value:
        return "N/A"

    if len(value) < 6:
        return value[:1] + "***"

    mid = len(value) // 2
    return f"{value[:show_chars]}..{value[mid:mid+show_chars]}..***"


def cleanup_tombstones(
    pipeline: Any,
    resources: list[str],
    column_name: str = "_tt_is_tombstone",
) -> None:
    """
    Clean up tombstone records from tables after a successful pipeline run.

    Tombstones are placeholder records used to ensure delete-insert semantics
    work correctly for partitions that have no real data. After the pipeline
    completes, these tombstone records should be removed.

    Args:
        pipeline: A dlt pipeline object with sql_client() method.
        resources: List of resource/table names to clean tombstones from.
        column_name: The boolean column name that marks tombstone records.
                     Defaults to "_tt_is_tombstone".

    Example:
        # Clean up tombstones from all resources except 'customer'
        tombstone_resources = [r for r in sync_resources if r != "customer"]
        cleanup_tombstones(pipeline, tombstone_resources)

        # Clean up with a custom column name
        cleanup_tombstones(pipeline, ["my_table"], column_name="is_tombstone")
    """
    if not resources:
        logger.debug("No resources provided for tombstone cleanup")
        return

    with pipeline.sql_client() as sql_client:
        for resource_name in resources:
            table_name = sql_client.make_qualified_table_name(resource_name)
            delete_query = f"DELETE FROM {table_name} WHERE {column_name} = 1"

            try:
                sql_client.execute_sql(delete_query)
                logger.info(f"Cleaned up tombstone records from {table_name}")
            except Exception as e:
                # Table might not exist on first run or if resource wasn't selected
                logger.warning(
                    f"Could not clean tombstones from {table_name}: {e}"
                )


def get_configs_from_env(
    config_class: Type[T],
    prefix: str,
    *,
    start_index: int = 1,
) -> list[T]:
    """
    Load configurations from environment variables using a numbered pattern.

    Supports multiple configurations with pattern:
        {prefix}_1__FIELD_NAME, {prefix}_1__OTHER_FIELD
        {prefix}_2__FIELD_NAME, {prefix}_2__OTHER_FIELD

    The first field in the config class is used as the required field to detect
    if a configuration exists.

    Args:
        config_class: A dataclass or TypedDict class defining the configuration structure.
                      Field names are converted to UPPER_SNAKE_CASE for env var lookup.
        prefix: The base prefix for environment variables (e.g., "EASYFLEX__COMPANY").
        start_index: The starting index for numbered configs (default: 1).

    Returns:
        List of config instances populated from environment variables.

    Example:
        @dataclass
        class CompanyConfig:
            company_id: str
            api_key: str | None = None
            report_user_id: str | None = None

        # Reads from EASYFLEX__COMPANY_1__COMPANY_ID, EASYFLEX__COMPANY_1__API_KEY, etc.
        configs = get_configs_from_env(CompanyConfig, "EASYFLEX__COMPANY")
    """
    configs: list[T] = []

    # Get field information from the config class
    if is_dataclass(config_class):
        field_names = [f.name for f in fields(config_class)]
    else:
        # Assume TypedDict
        field_names = list(get_type_hints(config_class).keys())

    if not field_names:
        raise ValueError(f"Config class {config_class.__name__} has no fields")

    # First field is the required identifier field
    required_field = field_names[0]
    required_env_key = _to_env_key(required_field)

    i = start_index
    while True:
        env_prefix = f"{prefix}_{i}__"
        required_value = os.getenv(f"{env_prefix}{required_env_key}")

        if not required_value:
            break

        # Build config dict from environment variables
        config_dict = {}
        for field_name in field_names:
            env_key = _to_env_key(field_name)
            config_dict[field_name] = os.getenv(f"{env_prefix}{env_key}")

        configs.append(config_class(**config_dict))
        i += 1

    return configs


def _to_env_key(field_name: str) -> str:
    """Convert a field name to UPPER_SNAKE_CASE for environment variable lookup."""
    return field_name.upper()


def print_configs(
    configs: Sequence[Any],
    *,
    title: str = "Configured items",
    columns: list[tuple[str, str, int]] | None = None,
    sensitive_fields: list[str] | None = None,
    mask_func: Callable[[str | None], str] | None = None,
) -> None:
    """
    Print configurations in a formatted table.

    Args:
        configs: Sequence of dataclass instances to print.
        title: Title for the table header.
        columns: List of (field_name, header_label, width) tuples defining which
            fields to display and how. If None, all fields are shown with
            auto-generated headers.
        sensitive_fields: List of field names that contain sensitive data to mask. Uses
            auto-detection for dataclass fields with repr=False if not provided.
        mask_func: Function to mask sensitive values. If None, uses mask_sensitive_value
            which shows first and middle characters.

    Example:
        print_configs(
            companies,
            title="Configured companies",
            columns=[
                ("company_id", "Company ID", 20),
                ("report_user_id", "Report User ID", 20),
                ("api_key", "API Key", 20),
            ],
            sensitive_fields=["api_key"],
        )
    """
    if not configs:
        print(f"\nNo {title.lower()} found.")
        return

    # Auto-generate columns from dataclass fields if not provided
    if columns is None:
        if is_dataclass(configs[0]):
            field_names = [f.name for f in fields(configs[0])]
            columns = [
                (name, name.replace("_", " ").title(), 20)
                for name in field_names
            ]
        else:
            raise ValueError(
                "columns must be provided for non-dataclass configs"
            )

    auto_sensitive_fields: set[str] = set()
    if is_dataclass(configs[0]):
        auto_sensitive_fields = {
            f.name for f in fields(configs[0]) if not f.repr
        }

    if sensitive_fields is None:
        sensitive_fields = list(auto_sensitive_fields)
    else:
        sensitive_fields = list(set(sensitive_fields) | auto_sensitive_fields)

    # Use mask_sensitive_value as default mask function
    if mask_func is None:
        mask_func = mask_sensitive_value

    # Calculate total width
    index_width = 8
    total_width = index_width + sum(width for _, _, width in columns)

    # Print header
    print(f"\n{title}:")
    print("-" * total_width)

    header = f"{'Index':<{index_width}}"
    header += "".join(f"{label:<{width}}" for _, label, width in columns)
    print(header)

    print("-" * total_width)

    # Print rows
    for i, config in enumerate(configs, 1):
        row = f"{i:<{index_width}}"
        for field_name, _, width in columns:
            value = getattr(config, field_name, None)

            if field_name in sensitive_fields:
                display_value = mask_func(value)
            else:
                display_value = str(value) if value is not None else "N/A"

            row += f"{display_value:<{width}}"
        print(row)

    print("-" * total_width)
    print(f"\nTotal: {len(configs)} items")
