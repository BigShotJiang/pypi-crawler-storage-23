"""
Authentication utilities for dlt pipelines.

This module provides authentication helpers including OAuth2 client credentials
with proactive token refresh.
"""

import logging

import pendulum
from dlt.sources.helpers.rest_client.auth import OAuth2ClientCredentials

logger = logging.getLogger(__name__)

# Default buffer in seconds to refresh OAuth token before expiry
OAUTH_REFRESH_BUFFER_SECONDS = 120


class BufferedOAuth2ClientCredentials(OAuth2ClientCredentials):
    """
    OAuth2 client credentials auth with proactive refresh buffer.

    dlt refreshes just-in-time based on token expiry. This subclass refreshes
    earlier to avoid edge cases around network latency and clock skew.

    The buffer works by marking the token as expired earlier than its actual expiry time.
    For example, if a token has expires_in=3600 seconds (1 hour) and the buffer is 120
    seconds, the token will be refreshed after 3480 seconds (3600 - 120), giving a 
    120-second safety margin before actual expiry.

    Args:
        refresh_buffer_seconds: Seconds before actual expiry to refresh token (default: 120)
        forced_expires_in_seconds: Override the expires_in from token response (optional)

    Example:
        ```python
        from dlt_utils import BufferedOAuth2ClientCredentials

        # Use default 120-second buffer
        auth = BufferedOAuth2ClientCredentials(
            client_id="...",
            client_secret="...",
            token_url="https://..."
        )

        # Use custom 300-second buffer
        auth = BufferedOAuth2ClientCredentials(
            client_id="...",
            client_secret="...",
            token_url="https://...",
            refresh_buffer_seconds=300
        )
        ```
    """

    refresh_buffer_seconds: int = OAUTH_REFRESH_BUFFER_SECONDS
    forced_expires_in_seconds: int | None = None

    def __init__(
        self,
        *args: object,
        refresh_buffer_seconds: int = OAUTH_REFRESH_BUFFER_SECONDS,
        forced_expires_in_seconds: int | None = None,
        **kwargs: object,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.refresh_buffer_seconds = refresh_buffer_seconds
        self.forced_expires_in_seconds = forced_expires_in_seconds

    def is_token_expired(self) -> bool:
        return (
            self.token_expiry is None
            or pendulum.now().add(seconds=self.refresh_buffer_seconds)
            >= self.token_expiry
        )

    def obtain_token(self) -> None:
        super().obtain_token()
        if self.forced_expires_in_seconds is not None:
            self.token_expiry = pendulum.now().add(
                seconds=self.forced_expires_in_seconds
            )
        logger.debug(
            "OAuth token refreshed; expires_at=%s (buffer=%ss, forced_expires_in=%s)",
            self.token_expiry,
            self.refresh_buffer_seconds,
            self.forced_expires_in_seconds,
        )
