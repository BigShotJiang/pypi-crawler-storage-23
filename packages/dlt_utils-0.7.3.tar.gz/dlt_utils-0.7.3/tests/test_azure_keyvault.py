"""Tests for Azure Key Vault utilities."""
import json
import os
from unittest.mock import MagicMock, patch

import pytest


class TestAzureKeyVault:
    """Test cases for AzureKeyVault class."""

    @patch.dict(os.environ, {
        'AZURE_TENANT_ID': 'test-tenant-id',
        'AZURE_CLIENT_ID': 'test-client-id',
        'AZURE_CLIENT_SECRET': 'test-client-secret'
    })
    @patch('dlt_utils.azure_keyvault.SecretClient')
    @patch('dlt_utils.azure_keyvault.ClientSecretCredential')
    def test_init(self, mock_credential, mock_secret_client):
        """Test AzureKeyVault initialization."""
        from dlt_utils.azure_keyvault import AzureKeyVault
        
        kv = AzureKeyVault(
            keyvault_base_url='https://test-vault.vault.azure.net/',
            keyvault_secret_name='test-secret'
        )
        
        # Verify credential was created with correct parameters
        mock_credential.assert_called_once_with(
            tenant_id='test-tenant-id',
            client_id='test-client-id',
            client_secret='test-client-secret'
        )
        
        # Verify SecretClient was created
        mock_secret_client.assert_called_once()
        assert kv.KEYVAULT_BASE_URL == 'https://test-vault.vault.azure.net/'
        assert kv.KEYVAULT_SECRET_NAME == 'test-secret'

    @patch.dict(os.environ, {
        'AZURE_TENANT_ID': 'test-tenant-id',
        'AZURE_CLIENT_ID': 'test-client-id',
        'AZURE_CLIENT_SECRET': 'test-client-secret'
    })
    @patch('dlt_utils.azure_keyvault.SecretClient')
    @patch('dlt_utils.azure_keyvault.ClientSecretCredential')
    def test_get_secret(self, mock_credential, mock_secret_client):
        """Test getting a secret from Key Vault."""
        from dlt_utils.azure_keyvault import AzureKeyVault
        
        # Setup mock
        mock_secret = MagicMock()
        mock_secret.value = '{"key": "value"}'
        mock_secret_client.return_value.get_secret.return_value = mock_secret
        
        kv = AzureKeyVault(
            keyvault_base_url='https://test-vault.vault.azure.net/',
            keyvault_secret_name='test-secret'
        )
        result = kv.get_secret()
        
        # Verify get_secret was called with correct secret name
        kv.secret_client.get_secret.assert_called_once_with('test-secret')
        assert result == mock_secret

    @patch.dict(os.environ, {
        'AZURE_TENANT_ID': 'test-tenant-id',
        'AZURE_CLIENT_ID': 'test-client-id',
        'AZURE_CLIENT_SECRET': 'test-client-secret'
    })
    @patch('dlt_utils.azure_keyvault.SecretClient')
    @patch('dlt_utils.azure_keyvault.ClientSecretCredential')
    def test_update_secret_tags(self, mock_credential, mock_secret_client):
        """Test updating secret tags."""
        from dlt_utils.azure_keyvault import AzureKeyVault
        
        kv = AzureKeyVault(
            keyvault_base_url='https://test-vault.vault.azure.net/',
            keyvault_secret_name='test-secret'
        )
        tags = {'environment': 'test', 'version': '1.0'}
        kv.update_secret_tags(tags)
        
        # Verify update_secret_properties was called
        kv.secret_client.update_secret_properties.assert_called_once_with(
            'test-secret',
            tags=tags
        )

    @patch.dict(os.environ, {
        'AZURE_TENANT_ID': 'test-tenant-id',
        'AZURE_CLIENT_ID': 'test-client-id',
        'AZURE_CLIENT_SECRET': 'test-client-secret'
    })
    @patch('dlt_utils.azure_keyvault.SecretClient')
    @patch('dlt_utils.azure_keyvault.ClientSecretCredential')
    def test_set_secret(self, mock_credential, mock_secret_client):
        """Test setting a secret in Key Vault."""
        from dlt_utils.azure_keyvault import AzureKeyVault
        
        kv = AzureKeyVault(
            keyvault_base_url='https://test-vault.vault.azure.net/',
            keyvault_secret_name='test-secret'
        )
        secret_value = {'database': 'prod', 'password': 'secret123'}
        kv.set_secret(secret_value)
        
        # Verify set_secret was called with correct parameters
        kv.secret_client.set_secret.assert_called_once_with(
            'test-secret',
            json.dumps(secret_value),
            tags={}
        )

    @patch.dict(os.environ, {
        'AZURE_TENANT_ID': 'test-tenant-id',
        'AZURE_CLIENT_ID': 'test-client-id',
        'AZURE_CLIENT_SECRET': 'test-client-secret'
    })
    @patch('dlt_utils.azure_keyvault.SecretClient')
    @patch('dlt_utils.azure_keyvault.ClientSecretCredential')
    def test_multiple_keyvault_instances(self, mock_credential, mock_secret_client):
        """Test creating multiple AzureKeyVault instances with different configurations."""
        from dlt_utils.azure_keyvault import AzureKeyVault
        
        kv_dev = AzureKeyVault(
            keyvault_base_url='https://dev-vault.vault.azure.net/',
            keyvault_secret_name='dev-secret'
        )
        kv_prod = AzureKeyVault(
            keyvault_base_url='https://prod-vault.vault.azure.net/',
            keyvault_secret_name='prod-secret'
        )
        
        # Verify both instances have correct configurations
        assert kv_dev.KEYVAULT_BASE_URL == 'https://dev-vault.vault.azure.net/'
        assert kv_dev.KEYVAULT_SECRET_NAME == 'dev-secret'
        assert kv_prod.KEYVAULT_BASE_URL == 'https://prod-vault.vault.azure.net/'
        assert kv_prod.KEYVAULT_SECRET_NAME == 'prod-secret'


class TestAzureKeyVaultRequiredParameters:
    """Test AzureKeyVault behavior with required parameters."""

    @patch('dlt_utils.azure_keyvault.SecretClient')
    @patch('dlt_utils.azure_keyvault.ClientSecretCredential')
    def test_init_requires_keyvault_base_url(self, mock_credential, mock_secret_client):
        """Test that keyvault_base_url is required."""
        from dlt_utils.azure_keyvault import AzureKeyVault
        
        with pytest.raises(TypeError):
            AzureKeyVault(keyvault_secret_name='test-secret')

    @patch('dlt_utils.azure_keyvault.SecretClient')
    @patch('dlt_utils.azure_keyvault.ClientSecretCredential')
    def test_init_requires_keyvault_secret_name(self, mock_credential, mock_secret_client):
        """Test that keyvault_secret_name is required."""
        from dlt_utils.azure_keyvault import AzureKeyVault
        
        with pytest.raises(TypeError):
            AzureKeyVault(keyvault_base_url='https://test-vault.vault.azure.net/')

    @patch('dlt_utils.azure_keyvault.SecretClient')
    @patch('dlt_utils.azure_keyvault.ClientSecretCredential')
    def test_init_requires_both_parameters(self, mock_credential, mock_secret_client):
        """Test that both parameters are required."""
        from dlt_utils.azure_keyvault import AzureKeyVault
        
        with pytest.raises(TypeError):
            AzureKeyVault()
