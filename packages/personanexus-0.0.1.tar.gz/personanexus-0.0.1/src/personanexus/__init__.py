"""PersonaNexus - Define AI agent personalities in YAML, not code."""
__version__ = "0.0.1"
