# PersonaNexus

Define AI agent personalities in YAML, not code.

**Coming soon.** Full release with OCEAN/DISC personality frameworks, behavioral modes, mood states, and interaction protocols — compiled to system prompts for any LLM.

- 🌐 [personanexus.ai](https://personanexus.ai)
- 📦 [GitHub](https://github.com/jcrowan3/PersonaNexus)
- 🐦 [@PersonaNexus](https://x.com/PersonaNexus)
