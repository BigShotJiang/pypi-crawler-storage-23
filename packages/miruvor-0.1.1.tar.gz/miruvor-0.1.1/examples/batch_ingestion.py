"""Batch ingestion example for Miruvor SDK."""
import asyncio

from miruvor import AsyncMiruvorClient


async def batch_ingest_documents():
    """Ingest multiple documents efficiently."""
    async with AsyncMiruvorClient(
        api_key="your-api-key-here",
        token="your-jwt-token-here",
    ) as client:
        documents = [
            {
                "text": "User documentation: Getting started with the API",
                "tags": ["docs", "tutorial"],
                "metadata": {"category": "documentation", "priority": "high"},
            },
            {
                "text": "Meeting notes: Discussed project roadmap and milestones",
                "tags": ["meetings", "planning"],
                "metadata": {"category": "notes", "date": "2026-02-13"},
            },
            {
                "text": "Research paper: Neuromorphic computing advances",
                "tags": ["research", "ai"],
                "metadata": {"category": "research", "source": "arxiv"},
            },
        ]

        print(f"Batch storing {len(documents)} documents...")

        responses = await client.store_batch(documents, max_concurrent=10)

        print(f"\n✅ Stored {len(responses)} documents")
        avg_time = sum(r.storage_time_ms for r in responses) / len(responses)
        print(f"Average storage time: {avg_time:.2f}ms")
        print(f"Total synapses created: {sum(r.synapses_created for r in responses)}")

        print("\nRetrieving related memories...")
        results = await client.retrieve(
            query="What documentation is available?",
            top_k=10,
        )

        print(f"Found {results.num_results} related memories:")
        for i, memory in enumerate(results.results, 1):
            text = memory.data.get("text", "N/A")
            print(f"{i}. [{memory.score:.3f}] {text[:60]}...")


async def batch_ingest_with_llm_enhancement():
    """Ingest documents with LLM enhancement (async processing)."""
    async with AsyncMiruvorClient(
        api_key="your-api-key-here",
        token="your-jwt-token-here",
    ) as client:
        documents = [
            "Long article about machine learning...",
            "Research paper on neural networks...",
            "Tutorial on Python programming...",
        ]

        print(f"Ingesting {len(documents)} documents with LLM enhancement...")

        tasks = []
        for i, doc in enumerate(documents):
            priority = "urgent" if i == 0 else "normal"
            task = client.ingest(
                content=doc,
                priority=priority,
                metadata={"doc_index": i},
            )
            tasks.append(task)

        responses = await asyncio.gather(*tasks)

        print(f"\n✅ Queued {len(responses)} documents for processing")
        for i, resp in enumerate(responses, 1):
            print(f"{i}. Message ID: {resp.message_id} | Priority: {resp.priority}")


if __name__ == "__main__":
    print("=== Batch Store Example ===")
    asyncio.run(batch_ingest_documents())

    print("\n\n=== Batch Ingest with LLM Example ===")
    asyncio.run(batch_ingest_with_llm_enhancement())
