"""Async usage example for Miruvor SDK."""
import asyncio

from miruvor import AsyncMiruvorClient


async def main():
    """Run async example."""
    async with AsyncMiruvorClient(
        api_key="your-api-key-here",
        token="your-jwt-token-here",
    ) as client:
        print("Checking API health...")
        health = await client.health()
        print(f"Health: {health}")

        print("\nStoring memories concurrently...")
        memories = [
            {"text": "User prefers dark mode", "tags": ["preferences"]},
            {"text": "User is learning Python", "tags": ["skills"]},
            {"text": "User works on AI projects", "tags": ["work"]},
        ]

        responses = await client.store_batch(memories, max_concurrent=3)
        print(f"Stored {len(responses)} memories")
        for resp in responses:
            print(f"  - {resp.memory_id} ({resp.storage_time_ms:.2f}ms)")

        print("\nRetrieving memories...")
        results = await client.retrieve(
            query="What does the user like?",
            top_k=5,
        )
        print(f"Found {results.num_results} memories")
        for memory in results.results:
            print(
                f"  - Score: {memory.score:.3f} | "
                f"{memory.data.get('text', 'N/A')}"
            )

        print("\nIngesting document...")
        ingest_resp = await client.ingest(
            content="Long document content here...",
            priority="high",
        )
        print(f"Queued: {ingest_resp.message_id}")

    print("\n✅ Async example complete!")


if __name__ == "__main__":
    asyncio.run(main())
