"""Quickstart example for Miruvor SDK."""
from miruvor import MiruvorClient


def main():
    """Run quickstart example."""
    # Uses production by default. Set MIRUVOR_BASE_URL=http://localhost:8000 for dev.
    # Set MIRUVOR_API_KEY in env to avoid passing api_key.
    client = MiruvorClient(
        api_key="your-api-key-here",
        token="your-jwt-token-here",  # optional, for tenant-scoped ops
    )

    print("Checking API health...")
    health = client.health()
    print(f"Health: {health}")

    print("\nStoring memory...")
    store_response = client.store(
        text="The user prefers dark mode and uses Python for development",
        tags=["preferences", "user", "settings"],
        metadata={"source": "settings_page", "timestamp": "2026-02-13"},
    )
    print(f"Stored memory: {store_response.memory_id}")
    print(f"Storage time: {store_response.storage_time_ms:.2f}ms")
    print(f"Synapses created: {store_response.synapses_created}")

    print("\nStoring another memory...")
    store_response2 = client.store(
        text="The user is working on a neuromorphic computing project",
        tags=["project", "ai"],
        metadata={"category": "work"},
    )
    print(f"Stored memory: {store_response2.memory_id}")

    print("\nRetrieving memories...")
    retrieve_response = client.retrieve(
        query="What are the user's preferences?",
        top_k=5,
    )
    print(f"Found {retrieve_response.num_results} memories")
    print(f"Retrieval method: {retrieve_response.retrieval_method}")

    for i, memory in enumerate(retrieve_response.results, 1):
        print(f"\n{i}. Score: {memory.score:.3f}")
        print(f"   Memory ID: {memory.memory_id}")
        print(f"   Text: {memory.data.get('text', 'N/A')}")
        if "tags" in memory.data:
            print(f"   Tags: {', '.join(memory.data['tags'])}")

    print("\n\nIngesting document...")
    ingest_response = client.ingest(
        content="This is a long document about the user's project.",
        priority="normal",
        metadata={"type": "document", "source": "upload"},
    )
    print(f"Ingestion queued: {ingest_response.message_id}")
    print(f"Status: {ingest_response.status}")
    print(f"Priority: {ingest_response.priority}")

    client.close()
    print("\nQuickstart complete!")


if __name__ == "__main__":
    main()
