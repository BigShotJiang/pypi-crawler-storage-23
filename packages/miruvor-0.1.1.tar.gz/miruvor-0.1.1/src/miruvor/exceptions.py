"""Custom exceptions for Miruvor SDK."""
from typing import Any, Optional


class MiruvorError(Exception):
    """Base exception for Miruvor SDK."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response: Optional[Any] = None,
    ):
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(self.message)


class AuthenticationError(MiruvorError):
    """Raised when authentication fails (401)."""

    pass


class AuthorizationError(MiruvorError):
    """Raised when authorization fails (403)."""

    pass


class NotFoundError(MiruvorError):
    """Raised when resource not found (404)."""

    pass


class ValidationError(MiruvorError):
    """Raised when request validation fails (422)."""

    pass


class RateLimitError(MiruvorError):
    """Raised when rate limit exceeded (429)."""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response: Optional[Any] = None,
    ):
        super().__init__(message, status_code, response)
        self.retry_after = 60
        if response and hasattr(response, "headers"):
            try:
                self.retry_after = int(response.headers.get("Retry-After", 60))
            except (ValueError, TypeError):
                pass


class ServerError(MiruvorError):
    """Raised when server error occurs (5xx)."""

    pass
