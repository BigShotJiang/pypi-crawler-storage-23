"""Pytest fixtures for Miruvor tests."""
from typing import Any, Dict, Optional
from unittest.mock import Mock

import pytest


@pytest.fixture
def mock_store_response() -> Dict[str, Any]:
    """Mock successful store response."""
    return {
        "memory_id": "mem_123abc",
        "storage_time_ms": 15.5,
        "synapses_created": 42,
        "status": "success",
        "persistence_enabled": True,
        "caching_enabled": True,
    }


@pytest.fixture
def mock_ingest_response() -> Dict[str, Any]:
    """Mock successful ingest response."""
    return {
        "success": True,
        "message_id": "msg_456def",
        "memory_ids": [],
        "chunks_created": 0,
        "duplicates_skipped": 0,
        "consolidations": 0,
        "processing_time_ms": 0.0,
        "status": "queued",
        "priority": "normal",
        "message": "Message queued with priority: normal",
    }


@pytest.fixture
def mock_retrieve_response() -> Dict[str, Any]:
    """Mock successful retrieve response."""
    return {
        "query": "test query",
        "results": [
            {
                "memory_id": "mem_1",
                "score": 0.95,
                "data": {"text": "First result"},
            },
            {
                "memory_id": "mem_2",
                "score": 0.87,
                "data": {"text": "Second result"},
            },
        ],
        "retrieval_method": "pattern_completion_dense",
        "num_results": 2,
    }


@pytest.fixture
def mock_health_response() -> Dict[str, Any]:
    """Mock health check response."""
    return {
        "status": "healthy",
        "database": "connected",
        "redis": "connected",
    }


def create_mock_response(
    status_code: int,
    json_data: Dict[str, Any],
    headers: Optional[Dict[str, str]] = None,
) -> Mock:
    """Create a mock HTTP response."""
    mock_response = Mock()
    mock_response.status_code = status_code
    mock_response.json.return_value = json_data
    mock_response.text = str(json_data)
    mock_response.headers = headers or {}
    return mock_response
