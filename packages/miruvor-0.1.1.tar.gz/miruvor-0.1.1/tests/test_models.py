"""Tests for Pydantic model validation."""
import pytest
from pydantic import ValidationError

from miruvor.models import IngestRequest, Memory, StoreRequest


class TestStoreRequest:
    """Tests for StoreRequest validation."""

    def test_valid_store_request(self):
        """Test valid store request."""
        request = StoreRequest(
            text="Valid memory text",
            tags=["tag1", "tag2"],
            metadata={"key": "value"},
        )
        assert request.text == "Valid memory text"
        assert len(request.tags) == 2

    def test_empty_text_raises(self):
        """Test empty text raises validation error."""
        with pytest.raises(ValidationError, match="Text cannot be empty"):
            StoreRequest(text="")

    def test_whitespace_text_raises(self):
        """Test whitespace-only text raises validation error."""
        with pytest.raises(ValidationError, match="Text cannot be empty"):
            StoreRequest(text="   ")

    def test_text_too_long_raises(self):
        """Test text exceeding max length raises error."""
        with pytest.raises(ValidationError):
            StoreRequest(text="a" * 10001)

    def test_too_many_tags_raises(self):
        """Test more than 20 tags raises error."""
        with pytest.raises(ValidationError):
            StoreRequest(text="Test", tags=[f"tag{i}" for i in range(21)])

    def test_text_stripped(self):
        """Test text is automatically stripped."""
        request = StoreRequest(text="  Test  ")
        assert request.text == "Test"


class TestIngestRequest:
    """Tests for IngestRequest validation."""

    def test_valid_ingest_request(self):
        """Test valid ingest request."""
        request = IngestRequest(
            content="Document content",
            priority="high",
            metadata={"source": "upload"},
        )
        assert request.content == "Document content"
        assert request.priority == "high"

    def test_empty_content_raises(self):
        """Test empty content raises validation error."""
        with pytest.raises(ValueError, match="Content cannot be empty"):
            IngestRequest(content="")


class TestMemory:
    """Tests for Memory model."""

    def test_valid_memory(self):
        """Test valid memory object."""
        memory = Memory(
            memory_id="mem_123",
            score=0.95,
            data={"text": "Memory content"},
        )
        assert memory.memory_id == "mem_123"
        assert memory.score == 0.95
        assert memory.data["text"] == "Memory content"
