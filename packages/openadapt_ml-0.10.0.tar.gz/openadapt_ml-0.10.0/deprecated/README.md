# Deprecated WAA Legacy Materials

This folder contains legacy WAA automation files and documents that are no longer
part of the vanilla WAA workflow. They are retained for review only.

Use `docs/waa_vanilla_automation.md` and the scripts in `scripts/` for the
current vanilla automation flow.
