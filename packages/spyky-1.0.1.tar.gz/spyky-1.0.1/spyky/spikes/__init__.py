from ._despike import DeSpike

__all__ = ["DeSpike"]
