from ._read_spc import read_spc

__all__ = ["read_spc"]