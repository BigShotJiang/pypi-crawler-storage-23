import unittest
from cooptools import pandasHelpers as ph
import pandas as pd
import numpy as np
import datetime


class Test_Pandas(unittest.TestCase):

    def test__convert_pandas_data_columns_to_type__df_is_none(self):
        df = None
        column_definitions = {"a": int, "b": int, "c": int}

        converted = ph.convert_pandas_data_columns_to_type(df, column_type_definition=column_definitions)

        self.assertEqual(converted, None)

    def test__convert_pandas_data_columns_to_type__df_is_empty(self):
        df = pd.DataFrame()
        column_definitions = {"a": int, "b": int, "c": int}

        converted = ph.convert_pandas_data_columns_to_type(df, column_type_definition=column_definitions)

        self.assertEqual(converted.equals(df), True)

    def test__convert_pandas_data_columns_to_type__missing_columns(self):
        df = pd.DataFrame(data=[{'a': 1, 'b': 2}])
        column_definitions = {"a": int, "b": int, "c": int}

        converted = ph.convert_pandas_data_columns_to_type(df, column_type_definition=column_definitions)
        self.assertListEqual([x for x in converted.columns], ['a', 'b'])

    def test__convert_pandas_data_columns_to_type__too_many_columns(self):
        df = pd.DataFrame(data=[{'a': 1, 'b': 2, 'c':3, 'd':4}])
        column_definitions = {"a": int, "b": int, "c": int}

        converted = ph.convert_pandas_data_columns_to_type(df, column_type_definition=column_definitions)

        self.assertListEqual([x for x in converted.columns], ['a', 'b', 'c', 'd'])

    def test__convert_pandas_data_columns_to_type__int_dirty_values(self):
        df = pd.read_csv('./tests/testdata/ints_dirty.csv')
        column_definitions = {"my_int": int}

        self.assertRaises(ValueError, lambda: ph.convert_pandas_data_columns_to_type(df, column_type_definition=column_definitions))

    def test__convert_pandas_data_columns_to_type__int_clean_values(self):
        df = pd.read_csv('./tests/testdata/ints_clean.csv')
        column_definitions = {"my_int": np.int64}

        converted = ph.convert_pandas_data_columns_to_type(df, column_type_definition=column_definitions)

        self.assertIn(converted.dtypes['my_int'], [np.int8, np.int32, np.int64])

    def test__clean_a_dataframe__too_many_columns(self):
        df = pd.read_csv('./tests/testdata/dummy_data_clean.csv')
        column_definitions = {"my_clean_int": np.int64, "my_clean_str": str}

        converted = ph.clean_a_dataframe(df, column_type_definition=column_definitions)

        self.assertEqual(converted.dtypes['my_clean_int'], np.int64)
        self.assertTrue(pd.api.types.is_string_dtype(converted.dtypes['my_clean_str']))
        self.assertEqual([x for x in converted.columns], ['my_clean_int', 'my_clean_str'])

    def test__clean_a_dataframe__not_enough_columns__allow_partial__dont_fill_missing(self):
        df = pd.read_csv('./tests/testdata/dummy_data_clean.csv')
        column_definitions = {"my_clean_int": int,
                              "my_clean_str": str,
                              "my_clean_date": datetime.date,
                              "my_missing_column": np.int64}

        converted = ph.clean_a_dataframe(df, column_type_definition=column_definitions, allow_partial_columnset=True, fill_missing=False)

        self.assertIn(converted.dtypes['my_clean_int'], [np.int8, np.int32, np.int64])
        self.assertTrue(pd.api.types.is_string_dtype(converted.dtypes['my_clean_str']))
        self.assertEqual([x for x in converted.columns], ['my_clean_int', 'my_clean_str','my_clean_date'])

    def test__clean_a_dataframe__not_enough_columns__allow_partial__fill_missing(self):
        df = pd.read_csv('./tests/testdata/dummy_data_clean.csv')
        column_definitions = {"my_clean_int": int,
                              "my_clean_str": str,
                              "my_clean_date": datetime.date,
                              "my_missing_column": str}

        converted = ph.clean_a_dataframe(df, column_type_definition=column_definitions, allow_partial_columnset=True, fill_missing=True)

        self.assertIn(converted.dtypes['my_clean_int'], [np.int8, np.int32, np.int64])
        self.assertTrue(pd.api.types.is_string_dtype(converted.dtypes['my_clean_str']))
        self.assertEqual([x for x in converted.columns], ['my_clean_int', 'my_clean_str', 'my_clean_date', 'my_missing_column'])

    def test__clean_a_dataframe__not_enough_columns__dont_allow_partial(self):
        df = pd.read_csv('./tests/testdata/dummy_data_clean.csv')
        column_definitions = {"my_clean_int": np.int64, "my_clean_str": str, "my_clean_date": str,
                              "my_missing_column": np.int64}

        self.assertRaises(ph.PandasMissingColumnsException, lambda: ph.clean_a_dataframe(df, column_type_definition=column_definitions, allow_partial_columnset=False))

    def test__clean_a_dataframe__not_enough_columns__allow_partial__fill_missing__invalid_fill_type(self):
        df = pd.read_csv('./tests/testdata/dummy_data_clean.csv')
        column_definitions = {"my_clean_int": int,
                              "my_clean_str": str,
                              "my_clean_date": datetime.date,
                              "my_missing_column": int}

        self.assertRaises(ph.PandasFillColumnTypeException, lambda: ph.clean_a_dataframe(df, column_type_definition=column_definitions, allow_partial_columnset=True, fill_missing=True))

    def test__clean_a_dataframe__not_case_sensititve__matching_columns(self):
        df = pd.read_csv('./tests/testdata/dummy_data_clean.csv')
        column_definitions = {"My_Clean_Int": int,
                              "My_cLean_stR": str,
                              "my_clean_date": datetime.date}

        df = ph.clean_a_dataframe(df,
                               column_type_definition=column_definitions,
                               allow_partial_columnset=False,
                               fill_missing=False)

        self.assertEqual(list(df.columns), list(column_definitions.keys()))

    def test__convert_pandas_data_columns_to_type__currency_mixed_values(self):
        df = pd.read_csv('./tests/testdata/currency.csv')
        column_definitions = {"my_currency": float}

        converted = ph.convert_pandas_data_columns_to_type(df, column_type_definition=column_definitions)

        self.assertIn(converted.dtypes['my_currency'], [float])


class Test_IncludeRowsForAllDateIncrement(unittest.TestCase):

    def test__include_rows__drops_duplicate_bucketed_dates(self):
        # arrange -- three rows: two in the same hour (10:00 and 10:30) and one in a
        # different hour (11:00), so range spans two hours but hour-10 has two rows
        from cooptools.date_utils import DateIncrementType
        dt_10_00 = datetime.datetime(2024, 1, 1, 10, 0, 0)
        dt_10_30 = datetime.datetime(2024, 1, 1, 10, 30, 0)  # same hour as dt_10_00
        dt_11_00 = datetime.datetime(2024, 1, 1, 11, 0, 0)
        df = pd.DataFrame({
            'timestamp': [dt_10_00, dt_10_30, dt_11_00],
            'value': [1, 2, 3]
        })

        # act
        result = ph.include_rows_for_all_date_increment(
            df,
            datetime_column_name='timestamp',
            datetime_increment_type=DateIncrementType.HOUR
        )

        # assert -- EXPECTED TO FAIL before fix: drop_duplicates result not assigned,
        # so right_df retains both rows, causing duplicate date_calc values in merge
        data_rows = result.dropna(subset=['value'])
        bucketed = data_rows['date_calc']
        self.assertEqual(len(bucketed), len(bucketed.unique()),
                         "Duplicate bucketed dates found — drop_duplicates result not assigned")
