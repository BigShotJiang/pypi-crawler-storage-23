import unittest
from cooptools.version import Version


class Test_Version(unittest.TestCase):

    def test__version_gt__simple_major(self):
        # arrange / act / assert
        self.assertTrue(Version("2.0") > Version("1.0"))

    def test__version_lt__simple_major(self):
        self.assertTrue(Version("1.0") < Version("2.0"))

    def test__version_eq__equal(self):
        self.assertEqual(Version("1.5"), Version("1.5"))

    def test__version_gt__numeric_minor__nine_vs_ten(self):
        # arrange -- "1.9" should be LESS than "1.10" when parts are compared as integers
        v9 = Version("1.9")
        v10 = Version("1.10")

        # act / assert -- EXPECTED TO FAIL before fix: string comparison gives "9" > "10"
        self.assertTrue(v10 > v9)

    def test__version_lt__numeric_minor__nine_vs_ten(self):
        # arrange
        v9 = Version("1.9")
        v10 = Version("1.10")

        # act / assert -- EXPECTED TO FAIL before fix
        self.assertTrue(v9 < v10)

    def test__version_gt__not_symmetric(self):
        # arrange
        v1 = Version("1.0")
        v2 = Version("2.0")

        # act / assert
        self.assertFalse(v1 > v2)
        self.assertTrue(v2 > v1)

    def test__version_ge__equal_versions(self):
        v = Version("1.5")
        self.assertTrue(v >= Version("1.5"))

    def test__version_le__equal_versions(self):
        v = Version("1.5")
        self.assertTrue(v <= Version("1.5"))


if __name__ == "__main__":
    unittest.main()
