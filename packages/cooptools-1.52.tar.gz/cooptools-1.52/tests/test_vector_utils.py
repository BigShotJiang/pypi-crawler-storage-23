import unittest
import timeit
from cooptools.geometry_utils import vector_utils as vu


class Test_Absolute(unittest.TestCase):

    def test__absolute__positive_values_unchanged(self):
        # act -- EXPECTED TO FAIL before fix: abs(coord) uses loop index, not value
        result = vu.absolute((3.0, 4.0, 5.0))

        # assert
        self.assertEqual(result, (3.0, 4.0, 5.0))

    def test__absolute__negative_values_become_positive(self):
        # act -- EXPECTED TO FAIL before fix
        result = vu.absolute((-3.0, -4.0, 5.0))

        # assert
        self.assertEqual(result, (3.0, 4.0, 5.0))

    def test__absolute__mixed_values(self):
        # act -- EXPECTED TO FAIL before fix
        result = vu.absolute((-1.0, 0.0, 2.0))

        # assert
        self.assertEqual(result, (1.0, 0.0, 2.0))

    def test__absolute__2d_vector(self):
        # act -- EXPECTED TO FAIL before fix
        result = vu.absolute((-5.0, 3.0))

        # assert
        self.assertEqual(result, (5.0, 3.0))

    def test__absolute__all_zeros(self):
        # act
        result = vu.absolute((0.0, 0.0, 0.0))

        # assert -- zero absolute is zero regardless of bug (abs(0)==abs(index 0)==0 for first,
        # but abs(1)==1 != 0.0 for second element, so this also fails before fix)
        self.assertEqual(result, (0.0, 0.0, 0.0))


class Test_VectorLen_Performance(unittest.TestCase):

    def test__vector_len__correctness(self):
        # arrange
        vec = (3.0, 4.0)  # known: len = 5.0

        # act
        result = vu.vector_len(vec)

        # assert
        self.assertAlmostEqual(result, 5.0, places=6)

    def test__vector_len__performance_baseline(self):
        # arrange
        vec = (3.0, 4.0, 5.0)

        # act -- baseline timing; after numpy optimization expect significant improvement
        t = timeit.timeit(lambda: vu.vector_len(vec), number=100000)

        # assert -- very lenient; documents current pure-Python loop performance
        self.assertLess(t, 60.0)


if __name__ == "__main__":
    unittest.main()
