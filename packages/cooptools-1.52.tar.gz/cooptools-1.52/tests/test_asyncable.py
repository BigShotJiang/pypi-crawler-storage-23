import unittest
import threading
import time
from cooptools.asyncable import Asyncable


class Test_Asyncable(unittest.TestCase):

    def test__asyncable__callback_is_called_after_start(self):
        # arrange
        call_count = [0]
        def callback():
            call_count[0] += 1

        # act
        a = Asyncable(loop_callback=callback, loop_timeout_ms=10)
        a.start()
        time.sleep(0.1)
        a._async = False  # Force flag (bypass join since join hangs before fix)

        # assert
        self.assertGreater(call_count[0], 0)

    def test__asyncable__stop_completes_within_timeout(self):
        # arrange
        def callback():
            pass

        a = Asyncable(loop_callback=callback, loop_timeout_ms=10)
        a.start()
        time.sleep(0.05)

        # act -- wrap stop() in a thread with timeout so the test doesn't hang
        # EXPECTED TO FAIL before fix: _async_loop runs while True, join() never returns
        stop_thread = threading.Thread(target=a.stop, daemon=True)
        stop_thread.start()
        stop_thread.join(timeout=2.0)

        # assert -- if stop_thread is still alive, stop() is hanging
        self.assertFalse(
            stop_thread.is_alive(),
            "stop() is hanging — _async_loop never exits (while True without checking _async flag)"
        )

    def test__asyncable__stop_then_callback_no_longer_called(self):
        # arrange
        call_count = [0]
        def callback():
            call_count[0] += 1

        a = Asyncable(loop_callback=callback, loop_timeout_ms=10)
        a.start()
        time.sleep(0.05)

        # act -- stop with timeout guard (same as above to avoid hanging)
        stop_thread = threading.Thread(target=a.stop, daemon=True)
        stop_thread.start()
        stop_thread.join(timeout=2.0)

        if stop_thread.is_alive():
            # Bug present — force the flag so the rest of the test can proceed
            a._async = False
            self.skipTest("stop() hangs due to while True bug — skipping callback-stops assertion")

        count_at_stop = call_count[0]
        time.sleep(0.05)

        # assert -- after stop, callback should no longer be called
        self.assertEqual(call_count[0], count_at_stop)


if __name__ == "__main__":
    unittest.main()
