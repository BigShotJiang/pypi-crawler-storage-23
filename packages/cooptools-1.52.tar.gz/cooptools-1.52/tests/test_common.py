import unittest
from cooptools.common import *

class Test_Common(unittest.TestCase):

    def test__flat_lst_of_lst(self):
        # arrange
        n_lsts = 5
        lst_length = 10
        l_o_l = [[x for x in range(lst_length)] for y in range(n_lsts)]

        # act
        flat = flattened_list_of_lists(l_o_l)

        #assert
        self.assertEqual(len(flat), n_lsts * lst_length)


    def test__flat_lst_of_lst__unique(self):
        # arrange
        l_o_l = [
            [0, 1, 2],
            [2, 3, 4],
            [4, 5, 6]
        ]

        # act
        flat = flattened_list_of_lists(l_o_l, unique=True)

        # assert
        self.assertEqual(flat, [0, 1, 2, 3, 4, 5, 6])

    def test__all_indxs_in_lst(self):
        # arrange
        lst = [0, 1, 3, 7, 3, 1, 3, 2]

        # act
        idxs = all_indxs_in_lst(lst, 3)

        # assert
        self.assertEqual(idxs, [2, 4, 6])

    def test__all_indxs_in_lst__none(self):
        # arrange
        lst = [0, 1, 3, 7, 3, 1, 3, 2]

        # act
        idxs = all_indxs_in_lst(lst, 10)

        # assert
        self.assertEqual(idxs, [])


class TestCaseInsensitiveReplace(unittest.TestCase):
    def test_basic_replacement(self):
        self.assertEqual(case_insensitive_replace("Hello World", "world", "there"), "Hello there")

    def test_case_variations(self):
        self.assertEqual(case_insensitive_replace("Hello WoRLd", "world", "there"), "Hello there")
        self.assertEqual(case_insensitive_replace("WORLD world WoRlD", "world", "earth"), "earth earth earth")

    def test_no_match(self):
        self.assertEqual(case_insensitive_replace("Hello World", "mars", "there"), "Hello World")

    def test_partial_word(self):
        self.assertEqual(case_insensitive_replace("Hello Worlds", "world", "there"), "Hello theres")

    def test_multiple_occurrences(self):
        self.assertEqual(case_insensitive_replace("world WORLD WoRlD", "world", "earth"), "earth earth earth")

    def test_empty_string(self):
        self.assertEqual(case_insensitive_replace("", "world", "earth"), "")

    def test_replace_with_empty_string(self):
        self.assertEqual(case_insensitive_replace("Hello World", "world", ""), "Hello ")


class Test_ReplaceManyInStr(unittest.TestCase):

    def test__replace_many_in_str__replaces_single_key(self):
        # arrange
        raw = "hello world"
        replacements = {"world": "there"}

        # act
        result = replace_many_in_str(raw, replacements)

        # assert -- EXPECTED TO FAIL before fix (result not assigned in loop)
        self.assertEqual(result, "hello there")

    def test__replace_many_in_str__replaces_multiple_keys(self):
        # arrange
        raw = "hello world foo"
        replacements = {"world": "there", "foo": "bar"}

        # act
        result = replace_many_in_str(raw, replacements)

        # assert -- EXPECTED TO FAIL before fix
        self.assertEqual(result, "hello there bar")

    def test__replace_many_in_str__no_match_returns_original(self):
        # arrange
        raw = "hello world"
        replacements = {"xyz": "abc"}

        # act
        result = replace_many_in_str(raw, replacements)

        # assert
        self.assertEqual(result, "hello world")


class Test_BoundingBoxOfPoints(unittest.TestCase):

    def test__bounding_box_of_points__basic(self):
        # arrange
        pts = [(0, 0), (10, 5), (3, 8)]

        # act
        result = bounding_box_of_points(pts)

        # assert
        self.assertEqual(result, (0, 0, 10, 8))

    def test__bounding_box_of_points__negative_coords(self):
        # arrange
        pts = [(-3, -5), (7, 4)]

        # act
        result = bounding_box_of_points(pts)

        # assert
        self.assertEqual(result, (-3, -5, 10, 9))

    def test__bounding_box_of_points__single_point(self):
        # arrange
        pts = [(5, 7)]

        # act
        result = bounding_box_of_points(pts)

        # assert
        self.assertEqual(result, (5, 7, 0, 0))

    def test__bounding_box_of_points__performance_baseline(self):
        # arrange
        import timeit
        pts = [(i, i * 2) for i in range(10000)]

        # act -- baseline timing; after single-pass optimization expect <0.5s for 100 runs
        t = timeit.timeit(lambda: bounding_box_of_points(pts), number=100)

        # assert -- very lenient; documents current 4-pass performance
        self.assertLess(t, 30.0)


class Test_DuplicatesInList(unittest.TestCase):

    def test__duplicates_in_list__finds_duplicates(self):
        # arrange
        lst = [1, 2, 3, 2, 4, 3, 5]

        # act
        result = duplicates_in_list(lst)

        # assert
        self.assertEqual(sorted(result), [2, 3])

    def test__duplicates_in_list__no_duplicates(self):
        # arrange
        lst = [1, 2, 3, 4, 5]

        # act
        result = duplicates_in_list(lst)

        # assert
        self.assertEqual(result, [])

    def test__duplicates_in_list__performance_baseline(self):
        # arrange
        import timeit
        lst = list(range(500)) * 4  # 2000 items, each value appears 4 times

        # act -- baseline timing; after Counter optimization expect <0.5s for 50 runs
        t = timeit.timeit(lambda: duplicates_in_list(lst), number=50)

        # assert -- very lenient; documents current O(n^2) performance
        self.assertLess(t, 120.0)


class Test_AllIndxsInLst_Performance(unittest.TestCase):

    def test__all_indxs_in_lst__performance_baseline(self):
        # arrange
        import timeit
        lst = list(range(1000)) * 3  # 3000 items
        target = 500

        # act -- baseline timing; after enumerate optimization expect <0.1s for 1000 runs
        t = timeit.timeit(lambda: all_indxs_in_lst(lst, target), number=1000)

        # assert -- very lenient; documents current performance
        self.assertLess(t, 120.0)


if __name__ == "__main__":
    unittest.main()