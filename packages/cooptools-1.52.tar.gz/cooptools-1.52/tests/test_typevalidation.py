import unittest
from cooptools.typevalidation import int_tryParse, float_as_currency, datestamp_tryParse, float_parse


class Test_IntTryParse(unittest.TestCase):

    def test__int_tryparse__valid_int_string(self):
        self.assertEqual(int_tryParse("42"), 42)

    def test__int_tryparse__valid_int(self):
        self.assertEqual(int_tryParse(42), 42)

    def test__int_tryparse__valid_float_string(self):
        # int("3.7") raises ValueError, so should return None
        self.assertIsNone(int_tryParse("3.7"))

    def test__int_tryparse__invalid_string_returns_none(self):
        self.assertIsNone(int_tryParse("abc"))

    def test__int_tryparse__none_returns_none(self):
        self.assertIsNone(int_tryParse(None))

    def test__int_tryparse__negative_string(self):
        self.assertEqual(int_tryParse("-10"), -10)

    def test__int_tryparse__zero(self):
        self.assertEqual(int_tryParse(0), 0)


class Test_FloatAsCurrency(unittest.TestCase):

    def test__float_as_currency__basic_positive(self):
        self.assertEqual(float_as_currency(1234.5), "$1,234.50")

    def test__float_as_currency__zero(self):
        self.assertEqual(float_as_currency(0), "$0.00")

    def test__float_as_currency__negative(self):
        self.assertEqual(float_as_currency(-99.99), "$-99.99")

    def test__float_as_currency__two_decimal_places(self):
        # 1.1 has exact representation to check two-decimal formatting
        self.assertEqual(float_as_currency(1.1), "$1.10")

    def test__float_as_currency__large_number(self):
        self.assertEqual(float_as_currency(1000000.0), "$1,000,000.00")


class Test_FloatParse(unittest.TestCase):

    def test__float_parse__valid_string(self):
        self.assertEqual(float_parse("3.14"), 3.14)

    def test__float_parse__invalid_raises_value_error(self):
        self.assertRaises(ValueError, lambda: float_parse("not_a_float"))

    def test__float_parse__integer(self):
        self.assertEqual(float_parse(5), 5.0)


if __name__ == "__main__":
    unittest.main()
