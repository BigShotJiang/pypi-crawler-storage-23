import unittest
import datetime
from cooptools import date_utils
from cooptools.typevalidation import datestamp_tryParse


class Test_DateUtils_RelativeDates(unittest.TestCase):

    def test__yesterday__is_one_day_before_today(self):
        # arrange
        # use .date() to avoid sub-second drift from two separate today() calls
        t = date_utils.today().date()
        y = date_utils.yesterday().date()

        # act
        delta = t - y

        # assert
        self.assertEqual(delta.days, 1)

    def test__tomorrow__is_one_day_after_today(self):
        # arrange -- use .date() to avoid sub-second drift
        t = date_utils.today().date()
        tm = date_utils.tomorrow().date()

        # act
        delta = tm - t

        # assert
        self.assertEqual(delta.days, 1)

    def test__now__is_close_to_today(self):
        # arrange
        t = date_utils.today()
        n = date_utils.now()

        # act / assert -- now() and today() should be the same date
        self.assertEqual(t.date(), n.date())

    def test__today__remove_hrs_zeroes_hour(self):
        # act
        result = date_utils.today(remove_hrs=True, remove_min=True, remove_sec=True)

        # assert
        self.assertEqual(result.hour, 0)
        self.assertEqual(result.minute, 0)
        self.assertEqual(result.second, 0)


class Test_DatestampTryParse(unittest.TestCase):

    def test__datestamp_tryparse__basic_passthrough(self):
        # arrange
        val = datetime.datetime(2024, 6, 15, 10, 30, 45)

        # act
        result = datestamp_tryParse(val)

        # assert
        self.assertEqual(result, val)

    def test__datestamp_tryparse__remove_hrs_zeroes_hour(self):
        # arrange
        val = datetime.datetime(2024, 6, 15, 10, 30, 45)

        # act -- EXPECTED TO FAIL before fix: val.replace(...) result not assigned
        result = datestamp_tryParse(val, remove_hrs=True)

        # assert
        self.assertEqual(result.hour, 0)

    def test__datestamp_tryparse__remove_min_zeroes_minute(self):
        # arrange
        val = datetime.datetime(2024, 6, 15, 10, 30, 45)

        # act -- EXPECTED TO FAIL before fix
        result = datestamp_tryParse(val, remove_min=True)

        # assert
        self.assertEqual(result.minute, 0)

    def test__datestamp_tryparse__remove_sec_zeroes_second(self):
        # arrange
        val = datetime.datetime(2024, 6, 15, 10, 30, 45)

        # act -- EXPECTED TO FAIL before fix
        result = datestamp_tryParse(val, remove_sec=True)

        # assert
        self.assertEqual(result.second, 0)

    def test__datestamp_tryparse__remove_ms_zeroes_microsecond(self):
        # arrange -- remove_ms is the ONE case that currently works (result IS assigned)
        val = datetime.datetime(2024, 6, 15, 10, 30, 45, 123456)

        # act
        result = datestamp_tryParse(val, remove_ms=True)

        # assert
        self.assertEqual(result.microsecond, 0)

    def test__datestamp_tryparse__remove_day_does_not_raise_and_changes_day(self):
        # arrange
        val = datetime.datetime(2024, 6, 15, 10, 30, 45)

        # act -- EXPECTED TO FAIL before fix: val.replace(day=0) raises ValueError
        # (day=0 is invalid); after fix: val = val.replace(day=1)
        result = datestamp_tryParse(val, remove_day=True)

        # assert
        self.assertEqual(result.day, 1)

    def test__datestamp_tryparse__remove_month_does_not_raise_and_changes_month(self):
        # arrange
        val = datetime.datetime(2024, 6, 15, 10, 30, 45)

        # act -- EXPECTED TO FAIL before fix: val.replace(month=0) raises ValueError
        # (month=0 is invalid); after fix: val = val.replace(month=1)
        result = datestamp_tryParse(val, remove_month=True)

        # assert
        self.assertEqual(result.month, 1)

    def test__datestamp_tryparse__none_input_returns_none(self):
        # act
        result = datestamp_tryParse(None)

        # assert
        self.assertIsNone(result)


if __name__ == "__main__":
    unittest.main()
