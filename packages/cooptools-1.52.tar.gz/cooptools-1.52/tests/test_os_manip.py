import unittest
import os
import tempfile
import json
from cooptools import os_manip


class Test_FilesAtDir(unittest.TestCase):

    def test__files_at_dir__returns_files_in_directory(self):
        # arrange -- create a temp directory with known files
        with tempfile.TemporaryDirectory() as tmpdir:
            file1 = os.path.join(tmpdir, "a.txt")
            file2 = os.path.join(tmpdir, "b.txt")
            open(file1, 'w').close()
            open(file2, 'w').close()

            # act
            result = os_manip.files_at_dir(tmpdir)

            # assert
            self.assertEqual(len(result), 2)
            self.assertTrue(all(os.path.isfile(p) for p in result))

    def test__files_at_dir__empty_directory_returns_empty_list(self):
        # arrange
        with tempfile.TemporaryDirectory() as tmpdir:
            # act
            result = os_manip.files_at_dir(tmpdir)

            # assert
            self.assertEqual(result, [])

    def test__files_at_dir__returns_valid_paths(self):
        # arrange
        with tempfile.TemporaryDirectory() as tmpdir:
            fname = os.path.join(tmpdir, "test.txt")
            open(fname, 'w').close()

            # act
            result = os_manip.files_at_dir(tmpdir)

            # assert -- all returned paths should be absolute-like and exist
            for p in result:
                self.assertTrue(os.path.exists(p))


class Test_SaveJsonableData(unittest.TestCase):

    def test__save_jsonable_data__appends_json_extension_when_missing(self):
        # arrange
        with tempfile.TemporaryDirectory() as tmpdir:
            path_without_ext = os.path.join(tmpdir, "myfile")
            data = {"key": "value"}

            # act
            os_manip.save_jsonable_data(data, path_without_ext)

            # assert -- .json should have been appended
            self.assertTrue(os.path.exists(path_without_ext + ".json"))

    def test__save_jsonable_data__does_not_double_append_json_extension(self):
        # arrange
        with tempfile.TemporaryDirectory() as tmpdir:
            path_with_ext = os.path.join(tmpdir, "myfile.json")
            data = {"key": "value"}

            # act
            os_manip.save_jsonable_data(data, path_with_ext)

            # assert -- file exists at exact path, not at myfile.json.json
            self.assertTrue(os.path.exists(path_with_ext))
            self.assertFalse(os.path.exists(path_with_ext + ".json"))

    def test__save_jsonable_data__written_content_is_valid_json(self):
        # arrange
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "myfile.json")
            data = {"name": "test", "value": 42}

            # act
            os_manip.save_jsonable_data(data, path)

            # assert
            with open(path, 'r') as f:
                loaded = json.load(f)
            self.assertEqual(loaded["name"], "test")
            self.assertEqual(loaded["value"], 42)


if __name__ == "__main__":
    unittest.main()
