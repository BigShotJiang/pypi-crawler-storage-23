import unittest
import timeit
from cooptools.coopEnum import CoopEnum, CircleDirection
from enum import auto


class Test_CircleDirection(unittest.TestCase):

    def test__opposite__clockwise_returns_counterclockwise(self):
        # act -- EXPECTED TO FAIL before fix: truthy enum member check always True,
        # so COUNTERCLOCKWISE.opposite() also returns COUNTERCLOCKWISE
        result = CircleDirection.CLOCKWISE.opposite()

        # assert
        self.assertEqual(result, CircleDirection.COUNTERCLOCKWISE)

    def test__opposite__counterclockwise_returns_clockwise(self):
        # act -- EXPECTED TO FAIL before fix
        result = CircleDirection.COUNTERCLOCKWISE.opposite()

        # assert
        self.assertEqual(result, CircleDirection.CLOCKWISE)

    def test__opposite__is_symmetric(self):
        # arrange / act / assert
        self.assertEqual(CircleDirection.CLOCKWISE.opposite().opposite(), CircleDirection.CLOCKWISE)
        self.assertEqual(CircleDirection.COUNTERCLOCKWISE.opposite().opposite(), CircleDirection.COUNTERCLOCKWISE)


class Test_CoopEnum_HasValue(unittest.TestCase):

    def _make_enum(self):
        class Dummy(CoopEnum):
            A = 1
            B = 2
            C = 3
        return Dummy

    def test__has_value__true_for_existing_value(self):
        # arrange
        Dummy = self._make_enum()

        # act / assert
        self.assertTrue(Dummy.has_value(1))
        self.assertTrue(Dummy.has_value(2))

    def test__has_value__false_for_missing_value(self):
        # arrange
        Dummy = self._make_enum()

        # act / assert
        self.assertFalse(Dummy.has_value(99))
        self.assertFalse(Dummy.has_value(0))

    def test__has_value__performance_baseline(self):
        # arrange
        Dummy = self._make_enum()

        # act -- baseline timing; after frozenset optimization expect faster for repeated calls
        t = timeit.timeit(lambda: Dummy.has_value(2), number=10000)

        # assert -- very lenient; documents current set-rebuild-per-call performance
        self.assertLess(t, 10.0)


if __name__ == "__main__":
    unittest.main()
