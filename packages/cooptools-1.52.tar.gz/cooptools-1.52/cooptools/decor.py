import functools
import time
import logging
import inspect
from typing import Protocol, Dict
from typing_extensions import runtime_checkable

@runtime_checkable
class TimeableProtocol(Protocol):
    internally_tracked_times: Dict
    maxes: Dict
    mins: Dict
    avgs: Dict
    ns: Dict

TIMEABLE_LOOKUPATTR = "_timeable"

def try_handler(logger: logging.Logger = None):
    def wrapper(func):
        @functools.wraps(func)
        def wrapper_handler(*args, **kwargs):
            try:
                func(*args, **kwargs)
            except NotImplementedError as e:
                error = f"Inherited class should implement logic for {func.__name__}"
                logger.debug(error)
            except Exception as e:
                logger.exception(e)

        return wrapper_handler

    return wrapper


def update_ttc_values(ttc: TimeableProtocol, func_name: str, run_time: float):
    #update counter
    ttc.ns.setdefault(func_name, 0)
    ttc.ns[func_name] += 1

    # udpate overall runtime
    ttc.internally_tracked_times.setdefault(func_name, 0)
    ttc.internally_tracked_times[func_name] += run_time

    # update maxs
    ttc.maxes.setdefault(func_name, float('-inf'))
    if run_time > ttc.maxes[func_name]:
        ttc.maxes[func_name] = run_time

    # update mins
    ttc.mins.setdefault(func_name, float('inf'))
    if run_time < ttc.mins[func_name]:
        ttc.mins[func_name] = run_time

    # udpate avgs
    my_avg = ttc.internally_tracked_times[func_name] / ttc.ns[func_name]
    ttc.avgs[func_name] = my_avg


def timer(logger: logging.Logger = None,
          log_level: int = logging.DEBUG,
          time_tracking_class: TimeableProtocol = None):
    """Print the runtime of the decorated function"""

    if logger is None:
        logger = logging.getLogger(__name__)

    def wrap(func):

        @functools.wraps(func)
        def wrapper_timer(*args, **kwargs):
            # capture time
            start_time = time.perf_counter()  # 1
            value = func(*args, **kwargs)
            end_time = time.perf_counter()  # 2
            run_time = end_time - start_time  # 3

            ttc = None

            if time_tracking_class is not None:
                ttc = time_tracking_class
            elif len(args) > 0 and isinstance(args[0], TimeableProtocol):
                ttc = args[0]
            elif len(args) > 0 and hasattr(args[0], TIMEABLE_LOOKUPATTR):
                ttc =getattr(args[0], TIMEABLE_LOOKUPATTR)
            elif len(args) > 0:
                logger.warning(f"In \'{func.__name__}\', relying on the decorator to peek at each attr for and check if it has an attr of type"
                               f"TimeableProtocol is the slowest method. If possible, create an attr on the class"
                               f"with name {TIMEABLE_LOOKUPATTR} for faster evaluation")
                for attr_name in dir(args[0]):
                    # Use getattr with a default (e.g., None) to prevent AttributeError on properties
                    attr_value = getattr(args[0], attr_name, None)
                    if isinstance(attr_value, TimeableProtocol):
                        ttc = getattr(args[0], attr_name)
                        break

            if ttc is None:
                return value

            update_ttc_values(ttc, func_name=func.__name__, run_time=run_time)
            end_time2 = time.perf_counter()
            timer_runtime = end_time2 - end_time
            update_ttc_values(ttc, func_name=TIMEABLE_LOOKUPATTR, run_time=timer_runtime)

            logger.log(level=log_level, msg=f"Finished {func.__name__!r} in {run_time:.4f} secs")
            return value

        return wrapper_timer
    return wrap


def debug(func,
          logger: logging.Logger = None,
          log_level: int = logging.DEBUG,
          ):
    """Print the function signature and return value"""
    if logger is None:
        logger = logging.getLogger()

    @functools.wraps(func)
    def wrapper_debug(*args, **kwargs):
        args_repr = [repr(a) for a in args]  # 1
        kwargs_repr = [f"{k}={v!r}" for k, v in kwargs.items()]  # 2
        signature = ", ".join(args_repr + kwargs_repr)  # 3
        logger.log(level=log_level, msg=f"Caller {inspect.stack()[1][3]} is calling {func.__name__}({signature})")
        value = func(*args, **kwargs)
        logger.log(level=log_level, msg=f"{func.__name__!r} returned {value!r}")  # 4
        return value

    return wrapper_debug