from typing import Dict, Tuple, Union
import datetime
from cooptools.currency import USD
from dateutil.relativedelta import relativedelta
import cooptools.date_utils as du
from cooptools.finance import growth_projections as gps

class FutureValueProjector:
    def __init__(self):
        pass

    def project(
            present_value: USD,
            monthly_contributions: USD,
            start_year: int,
            start_mo: int,
            growth_rate: Union[float, Dict[float, Tuple[du.DateIncrementType, int]]],
            projected_months: int = None,
    ) -> Dict[datetime.date, gps.FutureValueProjection]:
        if projected_months is None:
            projected_months = 100

        ret = {}
        start_date = datetime.datetime(year=start_year, month=start_mo, day=1)
        for epoch_date in du.datetime_generator(
                start_date_time=start_date,
                end_date_time=start_date + relativedelta(months=projected_months),
                increment_type=du.DateIncrementType.MONTH
        ):
            _rate = gps._resolve_growth_rate(growth_rate=growth_rate,
                                             start_date=start_date,
                                             epoch_date=epoch_date)

            ret[epoch_date] = gps.FutureValueProjection(
                start_date=start_date,
                end_date=epoch_date,
                present_value=present_value,
                monthly_contributions=monthly_contributions,
                annual_growth_rate=_rate
            )

        return ret