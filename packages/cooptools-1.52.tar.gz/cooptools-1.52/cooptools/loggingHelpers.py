BASE_LOG_FORMAT = '%(name)s -- %(asctime)s : [%(levelname)s] %(message)s (%(filename)s lineno: %(lineno)d)'
COLOR_LOG_FORMAT = f'%(log_color)s%{BASE_LOG_FORMAT}'
