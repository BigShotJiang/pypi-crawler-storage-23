"""Statistical learning models for commerce analytics.

Provides standard business engines with pluggable backends:
    - inventory: EOQ, safety stock, reorder point, ABC classification (builtin + stockpyl)
    - forecasting: MA, ETS, Croston, seasonal decompose (builtin + statsforecast)
    - analytics: RFM segmentation, LTV, cohort retention (sklearn + polars)
    - optimization: LP/MIP solving (OR-Tools)
    - recommendations: collaborative + content-based filtering (implicit + lightfm)
    - anomaly: Z-score + IQR outlier detection (builtin + adtk)
    - basket: Association rules / co-occurrence analysis (builtin + mlxtend)
    - cashflow: Revenue/COGS/reorder cash flow projection (builtin)
    - scheduling: Greedy staff shift assignment (builtin + ortools)
    - markdown: Clearance discount optimization (stub)
    - promotion: Lift/cannibalization simulation (stub)
    - leadtime: Supplier reliability analysis (stub)
    - seasonal: Event-to-multiplier calendar (stub)

Usage:
    from platoon.learning.providers import get_provider, list_providers

    # Auto-select best available backend
    fc = get_provider("forecasting")
    result = fc.forecast(series, horizon=14)

    inv = get_provider("inventory")
    eoq = inv.eoq(demand=10000, ordering_cost=50, holding_cost=2)

    analytics = get_provider("analytics")
    rfm = analytics.rfm_segment(orders)

    # See what's available
    list_providers()
"""

# Import modules to trigger provider registration
from platoon.learning import inventory  # noqa: F401
from platoon.learning import forecasting  # noqa: F401
from platoon.learning import analytics  # noqa: F401
from platoon.learning import optimization  # noqa: F401
from platoon.learning import recommendations  # noqa: F401
from platoon.learning import anomaly  # noqa: F401
from platoon.learning import basket  # noqa: F401
from platoon.learning import cashflow  # noqa: F401
from platoon.learning import scheduling  # noqa: F401
from platoon.learning import markdown  # noqa: F401
from platoon.learning import promotion  # noqa: F401
from platoon.learning import leadtime  # noqa: F401
from platoon.learning import seasonal  # noqa: F401
from platoon.learning.providers import get_provider, list_providers  # noqa: F401
