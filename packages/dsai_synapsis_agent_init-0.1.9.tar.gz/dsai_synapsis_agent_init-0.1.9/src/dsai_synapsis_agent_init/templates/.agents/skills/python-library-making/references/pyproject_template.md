# Annotated `pyproject.toml` Templates

This document contains two variants of `pyproject.toml` used by the Python Library Making skill. Choose the appropriate template based on whether your package is **internal (Git dependency)** or **public (PyPI)**.

---

## Internal Library Template (Synapsis/Private)

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "{library_name}"                # MUST match folder name in src/ (hyphens allowed)
version = "0.1.0"                    # bump this when releasing
description = "Synapsis internal library for {library_name}"
requires-python = ">=3.8"
authors = [
    {name = "Synapsis Team", email = "team@synapsis.id"}
]
dependencies = [                     # specify runtime requirements
    # example: "requests>=2.28"
]

[project.optional-dependencies]
dev = [                              # development tools, not shipped
    "pytest>=7.0",
    "pytest-cov>=4.0",
    "black>=22.0",
    "ruff>=0.1.0",
]

[tool.hatch.build.targets.wheel]
packages = ["src/{package_folder}"]
```

### Notes
* `name` should follow PyPI naming rules (use hyphens); the corresponding folder in `src/` will use underscores.
* Do **not** include `license` or `readme` fields; internal packages do not require this metadata.
* Development dependencies (test, lint, formatting) go under `[project.optional-dependencies]` – consumer projects will not inherit them.
* Add `pyproject.toml` to `.gitignore` only if your pipeline requires temporary overrides (rare).

---

## Public Library Template (Open Source)

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "{library_name}"                # must match PyPI package name
version = "0.1.0"                    # bump before publishing
description = "A useful Python library"
readme = "README.md"                 # included in distribution
requires-python = ">=3.8"
authors = [
    {name = "Your Name", email = "your.email@example.com"}
]
license = {text = "MIT"}             # or other OSI-approved license
keywords = ["python", "library"]
classifiers = [                        # metadata for PyPI
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.8",
    "Programming Language :: Python :: 3.9",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
]
dependencies = [                     # runtime dependencies
    # example: "requests>=2.28"
]

[project.optional-dependencies]
dev = [                              # development/CI tools
    "pytest>=7.0",
    "pytest-cov>=4.0",
    "black>=22.0",
    "ruff>=0.1.0",
]

[project.urls]
Homepage = "https://github.com/yourusername/{library_name}"
Documentation = "https://github.com/yourusername/{library_name}"
Repository = "https://github.com/yourusername/{library_name}"

[tool.hatch.build.targets.wheel]
packages = ["src/{package_folder}"]
```

### Notes
* `readme` field includes the README in package metadata. Ensure README exists and is correct.
* Add license classifier appropriate for your chosen license.
* `project.urls` section is optional but improves PyPI listing.
* After publishing, update `version` for future releases and tag accordingly.

---

## How to Use these Templates
1. Copy the relevant template into your project’s `pyproject.toml`.
2. Replace `{library_name}` with your actual package name (hyphenated). The build backend will convert to underscores for folder names.
3. Add or update dependencies as needed.
4. Commit the file and proceed with the standard workflow.

For assistance, refer to the [Python packaging guide](https://packaging.python.org/) or ask the AI using this skill.
