# Library Setup Quick Checklist

1. uv init --lib <name>
2. Verify src/<name>/__init__.py exists
3. Export public API in __init__.py
4. Add to Git and push
5. Tag version with git tag v0.1.0
6. uv add git+ssh://... or uv build & uv publish
