# Synapsis DSAI Core Operational Rules

Use these rules to guide the entire lifecycle of a project, from initial brainstorming to final Git commits.

## 1. Project Creation Workflow
When starting a new project:
1. **Brainstorming:** Conduct a session with the user. Use the `brainstorming` skill.
2. **Technical Design:** Create all technical design documents. Use the `architecture-patterns` and `architecture-decision-records` skills.
3. **API Documentation:** Generate API documentation. Use the `api-documentation-generator` skill.
4. **PRD:** Create a Product Requirements Document. Use the `prd-generator` skill.
5. **Backlog:** Create and organize the project backlog. Use the `product-backlog-management` and `project-planner` skills.

## 2. Feature Development Workflow
When building a new feature:
1. **Brainstorming:** Re-sync with the user. Use the `brainstorming` skill.
2. **Context Review:** Read all technical design docs, API docs, PRDs, and backlog items.
3. **Branching:** Create a new branch based on the feature type (see Git Policy).
4. **Implementation:** Code using **SOLID** principles and always apply **TDD**. Use `test-driven-development` and relevant language skills.
5. **Testing:**
    - Create and run **Unit Tests**. Use `python-testing-patterns` or equivalent.
    - Create and run **Integration Tests**.
    - Create and run **E2E Tests**. Use `browser-automation` if applicable.
6. **Quality Control:** Perform a code review. Use `code-review-checklist` and `vibe-code-auditor`.
7. **Commit:** Commit changes following the Git Policy. Use `git-commit`.

## 3. Bugfix Workflow
When fixing a bug:
1. **Brainstorming:** Understand the issue with the user. Use `systematic-debugging`.
2. **Context Review:** Read relevant technical and product documentation.
3. **Branching:** Create a new branch based on the bugfix type (e.g., `fix/`).
4. **Verification (Pre-fix):** Run existing tests to confirm the failure.
5. **Implementation:** Fix code using **SOLID** and **TDD**. Ensure the fix is verified by a new test case.
6. **Testing:** Run all test suites (Unit, Integration, E2E) to ensure no regressions.
7. **Quality Control:** Perform a code review.
8. **Commit:** Commit changes following the Git Policy.

## 4. Git Policy & Workflow

### Commit Messages
- **Format:** [Conventional Commits](https://www.conventionalcommits.org/).
- **Language:** Consistent (Indonesian or English).
- **Types:**
    - `feat`: New feature.
    - `fix`: Bug fix.
    - `docs`: Documentation changes.
    - `style`: Formatting, no logic change.
    - `refactor`: Code change that neither fixes a bug nor adds a feature.
- **Example:** `feat: Menambahkan endpoint login user`

### Branch Naming
- **Format:** `type/ticket-id/description`
- **Example:** `feat/DS-102/add-login-api`

### Pre-commit Compliance
- **MANDATORY:** All hooks must pass before pushing.
- **Manual Check:** `uv run pre-commit run --all-files`.
- **Fixes:** If `conventional-pre-commit` fails, fix the message immediately.

## 5. Engineering Standards Mandate
- **SOLID:** Always prioritize clean abstractions.
- **TDD:** No production code without a failing test first.
- **Review:** Every significant change must be audited for structural flaws.
