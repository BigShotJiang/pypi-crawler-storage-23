"""
Synapsis DSAI Agent Initialization Tool.

A uv-based utility for initializing agent rules across Synapsis projects.
Distributes standardized template directories (.agent, .agents, .claude)
making them available to team members via uvx.

Modules:
    main: Core initialization logic and CLI entry point.

Usage:
    Via uvx CLI:
        uvx --from <repo> init_synapsis_agent_rules

    Direct:
        from dsai_synapsis_agent_init import main
        main.run()

Version: 0.1.0
Author: mufid hadi
"""

from dsai_synapsis_agent_init.main import run

__all__ = ["run"]
__version__ = "0.1.0"
