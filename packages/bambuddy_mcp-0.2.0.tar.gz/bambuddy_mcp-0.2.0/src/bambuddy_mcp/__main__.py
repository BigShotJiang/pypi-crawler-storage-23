"""Allow running as python -m bambuddy_mcp."""

from bambuddy_mcp.server import run

run()
