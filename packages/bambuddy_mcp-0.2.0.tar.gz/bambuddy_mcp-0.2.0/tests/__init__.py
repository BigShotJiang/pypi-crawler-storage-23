"""Tests for Bambuddy MCP Server."""
