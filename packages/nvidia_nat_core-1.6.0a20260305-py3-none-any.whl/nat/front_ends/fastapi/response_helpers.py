# SPDX-FileCopyrightText: Copyright (c) 2025-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import typing
from collections.abc import AsyncGenerator

from nat.data_models.api_server import Error
from nat.data_models.api_server import ErrorTypes
from nat.data_models.api_server import ResponseATIFStep
from nat.data_models.api_server import ResponseATIFTrajectory
from nat.data_models.api_server import ResponseIntermediateStep
from nat.data_models.api_server import ResponsePayloadOutput
from nat.data_models.api_server import ResponseSerializable
from nat.data_models.step_adaptor import StepAdaptorConfig
from nat.front_ends.fastapi.intermediate_steps_subscriber import pull_intermediate
from nat.front_ends.fastapi.intermediate_steps_subscriber import pull_intermediate_atif
from nat.front_ends.fastapi.step_adaptor import StepAdaptor
from nat.runtime.session import Session
from nat.utils.producer_consumer_queue import AsyncIOProducerConsumerQueue


async def generate_streaming_response_as_str(payload: typing.Any,
                                             *,
                                             session: Session,
                                             streaming: bool,
                                             step_adaptor: StepAdaptor = StepAdaptor(StepAdaptorConfig()),
                                             result_type: type | None = None,
                                             output_type: type | None = None) -> AsyncGenerator[str]:

    from nat.data_models.api_server import ChatResponseChunk

    try:
        async for item in generate_streaming_response(payload,
                                                      session=session,
                                                      streaming=streaming,
                                                      step_adaptor=step_adaptor,
                                                      result_type=result_type,
                                                      output_type=output_type):

            if (isinstance(item, ResponseSerializable)):
                yield item.get_stream_data()
            else:
                raise ValueError("Unexpected item type in stream. Expected ChatResponseSerializable, got: " +
                                 str(type(item)))

        # Emit OpenAI-compatible stream termination: a final chunk with finish_reason="stop" and [DONE] sentinel
        if output_type is ChatResponseChunk:
            yield ChatResponseChunk.create_streaming_chunk("", finish_reason="stop").get_stream_data()
            yield "data: [DONE]\n\n"
    except Exception as e:
        yield Error(code=ErrorTypes.WORKFLOW_ERROR, message=str(e), details=type(e).__name__).model_dump_json()


async def generate_streaming_response(payload: typing.Any,
                                      *,
                                      session: Session,
                                      streaming: bool,
                                      step_adaptor: StepAdaptor = StepAdaptor(StepAdaptorConfig()),
                                      result_type: type | None = None,
                                      output_type: type | None = None) -> AsyncGenerator[ResponseSerializable]:

    async with session.run(payload) as runner:

        q: AsyncIOProducerConsumerQueue[ResponseSerializable] = AsyncIOProducerConsumerQueue()

        # Start the intermediate stream
        intermediate_complete = await pull_intermediate(q, step_adaptor)

        async def pull_result():
            try:
                if session.workflow.has_streaming_output and streaming:
                    async for chunk in runner.result_stream(to_type=output_type):
                        await q.put(chunk)
                else:
                    result = await runner.result(to_type=result_type)
                    await q.put(runner.convert(result, output_type))

                await intermediate_complete.wait()
            finally:
                await q.close()

        try:
            task: asyncio.Task = asyncio.create_task(pull_result())

            async for item in q:
                if (isinstance(item, ResponseSerializable)):
                    yield item
                else:
                    yield ResponsePayloadOutput(payload=item)

            # Re-raise any exception from the producer so callers can handle it
            await task
        finally:
            await q.close()


async def generate_single_response(
    payload: typing.Any,
    session: Session,
    result_type: type | None = None,
) -> typing.Any:

    if not session.workflow.has_single_output:
        raise ValueError("Cannot get a single output value for streaming workflows")

    async with session.run(payload) as runner:
        return await runner.result(to_type=result_type)


async def generate_streaming_response_full(payload: typing.Any,
                                           *,
                                           session: Session,
                                           streaming: bool,
                                           result_type: type | None = None,
                                           output_type: type | None = None,
                                           filter_steps: str | None = None) -> AsyncGenerator[ResponseSerializable]:
    """
    Similar to generate_streaming_response but provides raw ResponseIntermediateStep objects
    without any step adaptor translations.
    """
    # Parse filter_steps into a set of allowed types if provided
    # Special case: if filter_steps is "none", suppress all steps
    allowed_types = None
    if filter_steps:
        if filter_steps.lower() == "none":
            allowed_types = set()  # Empty set means no steps allowed
        else:
            allowed_types = set(filter_steps.split(','))

    async with session.run(payload) as runner:
        q: AsyncIOProducerConsumerQueue[ResponseSerializable] = AsyncIOProducerConsumerQueue()

        # Start the intermediate stream without step adaptor
        intermediate_complete = await pull_intermediate(q, None)

        async def pull_result():
            try:
                if session.workflow.has_streaming_output and streaming:
                    async for chunk in runner.result_stream(to_type=output_type):
                        await q.put(chunk)
                else:
                    result = await runner.result(to_type=result_type)
                    await q.put(runner.convert(result, output_type))

                await intermediate_complete.wait()
            finally:
                await q.close()

        try:
            task: asyncio.Task = asyncio.create_task(pull_result())

            async for item in q:
                if (isinstance(item, ResponseIntermediateStep)):
                    if allowed_types is None or item.type in allowed_types:
                        yield item
                else:
                    yield ResponsePayloadOutput(payload=item)

            # Re-raise any exception from the producer so callers can handle it
            await task
        finally:
            await q.close()


async def generate_streaming_response_full_as_str(payload: typing.Any,
                                                  *,
                                                  session: Session,
                                                  streaming: bool,
                                                  result_type: type | None = None,
                                                  output_type: type | None = None,
                                                  filter_steps: str | None = None) -> AsyncGenerator[str]:
    """
    Similar to generate_streaming_response but converts the response to a string format.
    """
    try:
        async for item in generate_streaming_response_full(payload,
                                                           session=session,
                                                           streaming=streaming,
                                                           result_type=result_type,
                                                           output_type=output_type,
                                                           filter_steps=filter_steps):
            if (isinstance(item, ResponseIntermediateStep) or isinstance(item, ResponsePayloadOutput)):
                yield item.get_stream_data()
            else:
                raise ValueError("Unexpected item type in stream. Expected ChatResponseSerializable, got: " +
                                 str(type(item)))
    except Exception as e:
        yield Error(code=ErrorTypes.WORKFLOW_ERROR, message=str(e), details=type(e).__name__).model_dump_json()


async def generate_streaming_response_atif(payload: typing.Any,
                                           *,
                                           session: Session,
                                           streaming: bool,
                                           result_type: type | None = None,
                                           output_type: type | None = None) -> AsyncGenerator[ResponseSerializable]:
    """Stream ATIF steps by converting raw IntermediateSteps on-the-fly.

    Each yielded item is either a ``ResponseATIFStep`` (one per completed
    agent turn) or a ``ResponsePayloadOutput`` (the final workflow result).
    A ``ResponseATIFTrajectory`` summary is emitted at the very end.
    """
    from nat.utils.atif_converter import ATIFStreamConverter

    converter = ATIFStreamConverter()

    async with session.run(payload) as runner:
        q: AsyncIOProducerConsumerQueue[ResponseSerializable] = AsyncIOProducerConsumerQueue()

        intermediate_complete = await pull_intermediate_atif(q, converter)

        async def pull_result():
            try:
                if session.workflow.has_streaming_output and streaming:
                    async for chunk in runner.result_stream(to_type=output_type):
                        await q.put(chunk)
                else:
                    result = await runner.result(to_type=result_type)
                    await q.put(runner.convert(result, output_type))

                await intermediate_complete.wait()
            finally:
                await q.close()

        try:
            task: asyncio.Task = asyncio.create_task(pull_result())

            async for item in q:
                if isinstance(item, (ResponseATIFStep, ResponseATIFTrajectory)):
                    yield item
                elif isinstance(item, ResponseSerializable):
                    yield item
                else:
                    yield ResponsePayloadOutput(payload=item)

            await task
        finally:
            await q.close()


async def generate_streaming_response_atif_as_str(payload: typing.Any,
                                                  *,
                                                  session: Session,
                                                  streaming: bool,
                                                  result_type: type | None = None,
                                                  output_type: type | None = None) -> AsyncGenerator[str]:
    """String-serialized variant of ``generate_streaming_response_atif``."""
    try:
        async for item in generate_streaming_response_atif(payload,
                                                           session=session,
                                                           streaming=streaming,
                                                           result_type=result_type,
                                                           output_type=output_type):
            if isinstance(item, ResponseSerializable):
                yield item.get_stream_data()
            else:
                raise ValueError("Unexpected item type in ATIF stream: " + str(type(item)))
    except Exception as e:
        yield Error(code=ErrorTypes.WORKFLOW_ERROR, message=str(e), details=type(e).__name__).model_dump_json()
