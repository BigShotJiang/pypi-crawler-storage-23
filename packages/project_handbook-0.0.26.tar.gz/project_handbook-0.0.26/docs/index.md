# project-handbook-cli

`project-handbook` is an installable Python CLI distribution that provides the `ph` command.

Key principles:

- `ph` operates on a **handbook instance repo** (your Project Handbook repo) as data/templates/plans.
- The handbook root is detected by the presence of `.project-handbook/config.json` (created by `ph init`).
- `ph` MUST NOT execute repo-local Python scripts at runtime.

Most handbook content lives under `.project-handbook/` (sprints, features, releases, status, process assets, etc.).

If you’re setting up a new repo, start with:

- `ph init`
- `ph doctor`
- `ph onboarding`

Next:

- `Quick Start` for installation + initialization
- `Concepts` for root/scope/layout/post-hooks
- `Layout` for where files live on disk
- `Workflows` for end-to-end usage patterns
- `Deep Dives` for domain-specific guides (tasks, sprints, releases, decisions, validation, evidence)
