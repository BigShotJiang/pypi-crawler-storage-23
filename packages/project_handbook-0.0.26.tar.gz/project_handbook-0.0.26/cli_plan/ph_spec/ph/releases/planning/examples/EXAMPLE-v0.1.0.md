---
title: Release v0.1.0
type: release
version: v0.1.0
date: 2025-09-12
tags: [release]
links: []
---

Highlights
- Initial project-handbook scaffolding

Changes
- Added ADR and FDR templates
- Added feature sample skeleton
- Added execution phase with YAML tasks
- Added roadmap/status/release/process scaffolding

Links
- ADR-0001, features/feature-sample/changelog.md

