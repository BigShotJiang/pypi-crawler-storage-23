__version__ = "0.0.1"
__author__ = "anticipatorai"
__license__ = "Apache-2.0"