# SanerAI — AI Productivity Automation with Slack, Git & Remote Machines

[![PyPI](https://img.shields.io/pypi/v/sanerai.svg)](https://pypi.org/project/sanerai/) [![Python](https://img.shields.io/pypi/pyversions/sanerai.svg)](https://pypi.org/project/sanerai/) [![license](https://img.shields.io/pypi/l/sanerai.svg)](https://github.com/commandoperator/cmdop-sdk-python/blob/main/LICENSE)

![CMDOP Architecture](https://cmdop.com/images/architecture/vs-personal-agent.png)

SanerAI empowers developers with AI productivity through Slack automation Python scripts. Unlike alternatives such as Zapier, Make, n8n, and Slack Bolt, SanerAI specializes in git automation agent tasks and cross-tool workflow integration. Automate repetitive tasks and focus on core development with our Python-centric solution.

## Features

- Automate workflows across Slack, Git, and remote machines using Python.
- Integrate AI productivity tool chains for enhanced development cycles.
- Orchestrate cross-tool workflow integration for streamlined operations.
- Manage git automation agent tasks directly from Slack.
- Trigger complex actions with simple Slack commands.

## Use Cases

- Run AI tasks and post results directly to Slack
- Auto-commit and push changes on remote machines
- Get daily AI-generated summaries of machine activity

## Installation

```bash
pip install sanerai
```

## Quick Start

```python
from sanerai import SanerAI
import os

client = SanerAI.remote(api_key="cmdop_live_xxx")

client.do_and_notify(
    "Check disk usage and identify top 5 largest directories",
    os.environ["SLACK_WEBHOOK"],
)

summary = client.daily_summary()
print(summary)
```

## Links

- [CMDOP Homepage](https://cmdop.com)
- [Documentation](https://cmdop.com/docs/sdk/python/)
- [sanerai on PyPI](https://pypi.org/project/sanerai/)
- [GitHub](https://github.com/commandoperator/cmdop-sdk-python)
