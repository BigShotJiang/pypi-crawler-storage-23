"""
SanerAI — cross-tool productivity plugin.

Themed wrapper around the CMDOP Python SDK (cmdop).
Docs: https://cmdop.com/docs/sdk/python/
"""

from __future__ import annotations

from cmdop import CMDOPClient, AsyncCMDOPClient
from cmdop.exceptions import (
    CMDOPError,
    ConnectionError,
    AuthenticationError,
    TimeoutError,
)

__version__ = "2026.2.28"
__all__ = ["SanerAI", "AsyncSanerAI"]



class SanerAI(CMDOPClient):
    """SanerAI — cross-tool productivity plugin.

    Extends CMDOPClient with themed methods for cross-tool productivity and workflow integration.

    Example::

        client = SanerAI.remote(api_key="cmdop_live_xxx")
        # ... use themed methods below
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
    pass


class AsyncSanerAI(AsyncCMDOPClient):
    """Async variant of SanerAI.

    Example::

        async with AsyncSanerAI.remote(api_key="cmdop_live_xxx") as client:
            result = await client.agent.run("hello")
    """
    pass


# Re-export core SDK symbols for convenience
from cmdop import (  # noqa: F401, E402
    CMDOPClient,
    AsyncCMDOPClient,
)
