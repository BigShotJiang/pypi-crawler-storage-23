export enum AssignmentStatusEnum {
  NOT_FETCHED = -1,
  PULLED,
  SUBMITTED,
  FEEDBACK_AVAILABLE
}