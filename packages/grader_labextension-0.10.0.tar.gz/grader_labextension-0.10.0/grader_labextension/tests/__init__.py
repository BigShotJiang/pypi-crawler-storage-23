"""Python unit tests for grader_labextension."""
