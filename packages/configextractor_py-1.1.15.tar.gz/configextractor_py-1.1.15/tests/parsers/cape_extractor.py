"""Test CAPE extractor."""


# Format of CAPE parsers that are detected by library
def extract_config(data: bytes):
    """Represents the main function used by CAPE parsers."""
    return
