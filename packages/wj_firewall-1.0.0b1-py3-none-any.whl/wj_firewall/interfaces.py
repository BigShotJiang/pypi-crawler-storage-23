# ────────────────────────────────────────────────────────────────────────────────────────
#   interfaces.py
#   ─────────────
#
#   Detect macOS network interfaces by parsing ifconfig and networksetup output.
#
#   (c) 2026 WaterJuice — Released under the Unlicense; see LICENSE.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import logging
import re
import subprocess
from dataclasses import dataclass
from dataclasses import field

# ────────────────────────────────────────────────────────────────────────────────────────
#   Types
# ────────────────────────────────────────────────────────────────────────────────────────

log = logging.getLogger(__name__)


# ────────────────────────────────────────────────────────────────────────────────────────
@dataclass
class NetworkInterface:
    """
    Represents a macOS network interface.

    Attributes:
        name: Interface name (e.g. en0, lo0, utun4).
        description: Human-readable description (e.g. Wi-Fi, Tailscale).
        active: Whether the interface is currently up.
        addresses: IPv4 addresses assigned to this interface.
    """

    name: str
    description: str = ""
    active: bool = False
    addresses: list[str] = field(default_factory=lambda: list[str]())


# ────────────────────────────────────────────────────────────────────────────────────────
#   Functions
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def get_interfaces(
    keep_interfaces: set[str] | None = None,
) -> list[NetworkInterface]:
    """
    Detect macOS network interfaces by parsing ifconfig output.
    Returns a list of NetworkInterface objects in a logical display order:
    en* (physical) first, then bridge, loopback, tunnel interfaces, then rest.

    Interfaces in *keep_interfaces* are never filtered out, even if they
    would normally be hidden (e.g. a Tailscale utun that temporarily has
    no IP address).
    """
    try:
        result = subprocess.run(
            ["ifconfig"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            log.warning("ifconfig returned non-zero exit code: %d", result.returncode)
            return []
        interfaces = _parse_ifconfig_output(result.stdout)
    except (subprocess.SubprocessError, OSError) as e:
        log.error("Failed to run ifconfig: %s", e)
        return []

    # Get friendly names from networksetup (before filtering so we can
    # use them to decide which interfaces to keep).
    friendly_names = _get_friendly_names()
    for iface in interfaces:
        if iface.name in friendly_names:
            iface.description = friendly_names[iface.name]

    # Only show interfaces that have an IP address, are in the blocked
    # set, or are real standalone adapters without a cable.  This hides
    # phantom/idle system tunnels while keeping unplugged USB Ethernet
    # adapters visible so they can be pre-configured.
    #
    # Interfaces with a hardware port name but no IP are only kept if
    # they pass several filters for noise:
    #  - Not a Thunderbolt slot or inactive Wi-Fi
    #  - Not a ghost "Ethernet Adapter (enN)" left behind by a
    #    previously-connected USB adapter that macOS never cleaned up
    _BORING_PORT_PREFIXES = ("Thunderbolt", "Wi-Fi", "Ethernet Adapter")
    keep = keep_interfaces or set[str]()
    interfaces = [
        i
        for i in interfaces
        if i.addresses
        or i.name in keep
        or (
            i.name in friendly_names
            and not friendly_names[i.name].startswith(_BORING_PORT_PREFIXES)
        )
    ]

    # Add descriptions for well-known interfaces without one
    for iface in interfaces:
        if not iface.description:
            if any(_is_tailscale_address(a) for a in iface.addresses):
                iface.description = "Tailscale"

    return sorted(interfaces, key=_iface_sort_key)


# ────────────────────────────────────────────────────────────────────────────────────────
def _parse_ifconfig_output(output: str) -> list[NetworkInterface]:
    """
    Parse the output of ``ifconfig`` to extract interface details.
    Separated from get_interfaces() for testability.
    """
    interfaces: list[NetworkInterface] = []
    current_name: str | None = None
    current_active = False
    current_addresses: list[str] = []

    for line in output.splitlines():
        # Interface header line: "en0: flags=8863<UP,...> mtu 1500"
        header_match = re.match(r"^(\w+):\s+flags=\w+<([^>]*)>", line)
        if header_match:
            # Save previous interface
            if current_name is not None:
                interfaces.append(
                    NetworkInterface(
                        name=current_name,
                        active=current_active,
                        addresses=current_addresses,
                    )
                )
            current_name = header_match.group(1)
            flags = header_match.group(2).split(",")
            current_active = "UP" in flags
            current_addresses = []
            continue

        # IPv4 address line: "\tinet 192.168.1.5 netmask 0xffffff00 ..."
        # Point-to-point interfaces have: "\tinet 100.x.x.x --> 100.x.x.x netmask ..."
        inet_match = re.match(
            r"^\s+inet\s+(\d+\.\d+\.\d+\.\d+)\s+(?:-->\s+\S+\s+)?netmask\s+(0x[0-9a-fA-F]+)",
            line,
        )
        if inet_match and current_name is not None:
            addr = inet_match.group(1)
            prefix = _hex_mask_to_prefix(inet_match.group(2))
            current_addresses.append(f"{addr}/{prefix}")
            continue

        # IPv6 address line: "\tinet6 <addr> prefixlen <n> ..."
        # Skip link-local (fe80::) — every interface gets one automatically.
        inet6_match = re.match(r"^\s+inet6\s+(\S+)\s+prefixlen\s+(\d+)", line)
        if inet6_match and current_name is not None:
            addr = inet6_match.group(1)
            if not addr.startswith("fe80:"):
                prefix = inet6_match.group(2)
                current_addresses.append(f"{addr}/{prefix}")
            continue

        # Status line: "\tstatus: active" or "\tstatus: inactive"
        status_match = re.match(r"^\s+status:\s+(\w+)", line)
        if status_match and current_name is not None:
            current_active = status_match.group(1) == "active"

    # Don't forget the last interface
    if current_name is not None:
        interfaces.append(
            NetworkInterface(
                name=current_name,
                active=current_active,
                addresses=current_addresses,
            )
        )

    # Filter out virtual/internal interfaces that are not useful for firewall rules.
    skip_prefixes = ("gif", "stf", "anpi", "llw", "awdl", "ap", "ipsec", "lo", "bridge")
    interfaces = [i for i in interfaces if not i.name.startswith(skip_prefixes)]

    return interfaces


# ────────────────────────────────────────────────────────────────────────────────────────
def _hex_mask_to_prefix(hex_mask: str) -> int:
    """Convert a hex netmask (e.g. ``0xffffff00``) to a CIDR prefix length (e.g. 24)."""
    mask = int(hex_mask, 16)
    return bin(mask).count("1")


# ────────────────────────────────────────────────────────────────────────────────────────
def _is_tailscale_address(addr: str) -> bool:
    """
    Check if an IPv4 address is in the Tailscale CGNAT range (100.64.0.0/10).
    Tailscale assigns addresses in this range to all nodes.
    Accepts addresses with or without CIDR suffix (e.g. ``100.74.1.2/32``).
    """
    # Strip CIDR suffix and any IPv6 addresses.
    ip = addr.split("/")[0]
    parts = ip.split(".")
    if len(parts) != 4:
        return False
    try:
        first, second = int(parts[0]), int(parts[1])
    except ValueError:
        return False
    # 100.64.0.0/10 means first octet 100, second octet 64–127
    return first == 100 and 64 <= second <= 127


# ────────────────────────────────────────────────────────────────────────────────────────
def _iface_sort_key(iface: NetworkInterface) -> tuple[int, str]:
    """
    Sort key for display order: physical interfaces first, then bridge,
    loopback, tunnel interfaces, then everything else.
    """
    if iface.name.startswith("en"):
        return (0, iface.name)
    if iface.name.startswith("bridge"):
        return (1, iface.name)
    if iface.name.startswith("utun"):
        return (2, iface.name)
    return (3, iface.name)


# ────────────────────────────────────────────────────────────────────────────────────────
def _get_friendly_names() -> dict[str, str]:
    """
    Get human-readable names for interfaces using ``networksetup -listallhardwareports``.
    Returns a mapping of interface name to friendly name (e.g. en0 -> Wi-Fi).
    """
    try:
        result = subprocess.run(
            ["networksetup", "-listallhardwareports"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return {}
        return _parse_networksetup_output(result.stdout)
    except (subprocess.SubprocessError, OSError) as e:
        log.warning("Failed to run networksetup: %s", e)
        return {}


# ────────────────────────────────────────────────────────────────────────────────────────
def _parse_networksetup_output(output: str) -> dict[str, str]:
    """
    Parse the output of ``networksetup -listallhardwareports``.
    Separated for testability.

    Expected format::

        Hardware Port: Wi-Fi
        Device: en0
        Ethernet Address: ...
    """
    names: dict[str, str] = {}
    current_port: str | None = None

    for line in output.splitlines():
        port_match = re.match(r"^Hardware Port:\s+(.+)$", line)
        if port_match:
            current_port = port_match.group(1)
            continue

        device_match = re.match(r"^Device:\s+(\w+)$", line)
        if device_match and current_port is not None:
            names[device_match.group(1)] = current_port
            current_port = None

    return names
