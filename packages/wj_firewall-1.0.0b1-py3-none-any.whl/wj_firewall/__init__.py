# ────────────────────────────────────────────────────────────────────────────────────────
#   wj-firewall
#   ───────────
#
#   macOS PF (Packet Filter) firewall configuration tool.
#
#   (c) 2026 WaterJuice — Released under the Unlicense; see LICENSE.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Version
# ────────────────────────────────────────────────────────────────────────────────────────

from .version import VERSION_STR

__version__ = VERSION_STR
__all__ = ["__version__"]
