# ────────────────────────────────────────────────────────────────────────────────────────
#   pf_control.py
#   ─────────────
#
#   Controls PF via pfctl commands.  Uses sudo for privilege escalation
#   (appropriate for a terminal-based tool).
#
#   (c) 2026 WaterJuice — Released under the Unlicense; see LICENSE.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import logging
import os
import subprocess
from pathlib import Path

# ────────────────────────────────────────────────────────────────────────────────────────
#   Constants
# ────────────────────────────────────────────────────────────────────────────────────────

PFCTL = "/sbin/pfctl"
DEFAULT_PF_CONF = Path("/etc/pf.conf")
ANCHOR_NAME = "wj-firewall"
ANCHOR_PATH = Path("/etc/pf.anchors/wj-firewall")

log = logging.getLogger(__name__)

# ────────────────────────────────────────────────────────────────────────────────────────
#   Functions
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def prime_sudo() -> bool:
    """
    Prompt for the sudo password before entering curses mode.

    Runs ``sudo -v`` which validates (and caches) credentials.  Must be
    called while the terminal is in normal mode — not inside curses.
    Returns True if credentials were obtained successfully.
    """
    if os.geteuid() == 0:
        return True
    try:
        result = subprocess.run(
            ["sudo", "-v"],  # noqa: S603, S607
            timeout=120,
        )
        return result.returncode == 0
    except (subprocess.SubprocessError, OSError):
        return False


# ────────────────────────────────────────────────────────────────────────────────────────
def is_pf_enabled() -> bool:
    """
    Check if PF is currently enabled.
    Parses output of ``pfctl -s info``.  Requires root privileges
    (``/dev/pf`` is not world-readable on macOS).
    """
    ok, output = _run_privileged(f"{PFCTL} -s info")
    if not ok:
        log.error("Failed to check PF status: %s", output)
        return False
    for line in output.splitlines():
        if line.strip().startswith("Status:"):
            return "Enabled" in line
    return False


# ────────────────────────────────────────────────────────────────────────────────────────
def enable_pf() -> tuple[bool, str]:
    """
    Enable PF. Requires root privileges.
    Returns (success, message).
    """
    return _run_privileged(f"{PFCTL} -e")


# ────────────────────────────────────────────────────────────────────────────────────────
def reload_pf_conf(config_path: Path = DEFAULT_PF_CONF) -> tuple[bool, str]:
    """
    Reload the full PF configuration from the given file.
    Requires root privileges.  Returns (success, message).
    """
    return _run_privileged(f"{PFCTL} -f {config_path}")


# ────────────────────────────────────────────────────────────────────────────────────────
def reload_anchor(
    anchor: str = ANCHOR_NAME, path: Path = ANCHOR_PATH
) -> tuple[bool, str]:
    """
    Reload only the wj-firewall anchor from its anchor file.
    This is faster than reloading all of pf.conf and does not disturb
    other PF rules.  Returns (success, message).
    """
    return _run_privileged(f"{PFCTL} -a {anchor} -f {path}")


# ────────────────────────────────────────────────────────────────────────────────────────
def flush_states_on_interface(iface: str) -> tuple[bool, str]:
    """
    Flush all PF state entries associated with a given interface.

    Existing state entries bypass rule evaluation entirely, so after
    adding block rules for an interface we must flush its states —
    otherwise previously established connections continue to pass.
    """
    return _run_privileged(f"{PFCTL} -i {iface} -Fs")


# ────────────────────────────────────────────────────────────────────────────────────────
def write_file_privileged(content: str, path: Path) -> tuple[bool, str]:
    """
    Write *content* to *path* using elevated privileges.
    Returns (success, message).
    """
    # Escape single quotes and backslashes for the shell command.
    escaped = content.replace("\\", "\\\\").replace("'", "'\\''")
    command = f"printf '%s' '{escaped}' > {path}"
    return _run_privileged(command)


# ────────────────────────────────────────────────────────────────────────────────────────
def _run_privileged(command: str) -> tuple[bool, str]:
    """
    Run a shell command with root privileges.

    If already running as root, executes directly.  Otherwise uses ``sudo``.
    The caller should ensure ``prime_sudo()`` has been called recently so that
    sudo does not need to prompt for a password (which would interfere with
    curses).
    """
    if os.geteuid() == 0:
        shell_cmd = ["sh", "-c", command]
    else:
        shell_cmd = ["sudo", "sh", "-c", command]

    log.debug("Running privileged command: %s", command)

    try:
        result = subprocess.run(
            shell_cmd,  # noqa: S603
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            log.debug("Privileged command succeeded")
            # pfctl writes most output to stderr, so combine both streams.
            combined = (result.stdout + "\n" + result.stderr).strip()
            return True, combined
        error = result.stderr.strip() or result.stdout.strip()
        log.error("Privileged command failed: %s", error)
        return False, error
    except subprocess.TimeoutExpired:
        log.error("Privileged command timed out")
        return False, "Command timed out"
    except (subprocess.SubprocessError, OSError) as e:
        log.error("Failed to run privileged command: %s", e)
        return False, str(e)
