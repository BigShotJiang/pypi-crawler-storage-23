# ────────────────────────────────────────────────────────────────────────────────────────
#   rules.py
#   ────────
#
#   Data model — per-interface firewall state: which interfaces are blocked,
#   and which ports are allowed through on blocked interfaces.
#
#   (c) 2026 WaterJuice — Released under the Unlicense; see LICENSE.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

from dataclasses import dataclass
from dataclasses import field

# ────────────────────────────────────────────────────────────────────────────────────────
#   Types
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
@dataclass
class BlockedInterfaces:
    """
    Per-interface firewall state.

    ``interfaces`` tracks which interfaces have incoming traffic blocked.
    ``allowed_ports`` maps interface names to sets of port numbers that
    should be allowed through even when the interface is blocked.  Both
    TCP and UDP pass rules are generated for each allowed port.
    ``block_icmp`` tracks which blocked interfaces have ICMP blocked.
    By default, blocked interfaces allow ICMP through (ping, traceroute,
    PMTU discovery).  Adding an interface to ``block_icmp`` suppresses
    the ICMP pass rule.
    """

    interfaces: set[str] = field(default_factory=lambda: set[str]())
    allowed_ports: dict[str, set[int]] = field(
        default_factory=lambda: dict[str, set[int]]()
    )
    block_icmp: set[str] = field(default_factory=lambda: set[str]())

    # ── Blocked state ─────────────────────────────────────────────────

    # ────────────────────────────────────────────────────────────────────────────────────────
    def is_blocked(self, name: str) -> bool:
        """Check if an interface has incoming traffic blocked."""
        return name in self.interfaces

    # ────────────────────────────────────────────────────────────────────────────────────────
    def toggle(self, name: str) -> None:
        """Toggle the blocked state of an interface."""
        if name in self.interfaces:
            self.interfaces.discard(name)
            self.allowed_ports.pop(name, None)
            self.block_icmp.discard(name)
        else:
            self.interfaces.add(name)

    # ────────────────────────────────────────────────────────────────────────────────────────
    def set_blocked(self, name: str, *, blocked: bool) -> None:
        """Explicitly set the blocked state of an interface."""
        if blocked:
            self.interfaces.add(name)
        else:
            self.interfaces.discard(name)
            self.allowed_ports.pop(name, None)
            self.block_icmp.discard(name)

    # ── Allowed ports ─────────────────────────────────────────────────

    # ────────────────────────────────────────────────────────────────────────────────────────
    def get_allowed_ports(self, name: str) -> set[int]:
        """Return the set of allowed ports for an interface (empty if none)."""
        return self.allowed_ports.get(name, set())

    # ────────────────────────────────────────────────────────────────────────────────────────
    def add_allowed_port(self, name: str, port: int) -> None:
        """Add a port to the allowed set for an interface."""
        if name not in self.allowed_ports:
            self.allowed_ports[name] = set()
        self.allowed_ports[name].add(port)

    # ────────────────────────────────────────────────────────────────────────────────────────
    def remove_allowed_port(self, name: str, port: int) -> None:
        """Remove a port from the allowed set.  Cleans up empty entries."""
        if name in self.allowed_ports:
            self.allowed_ports[name].discard(port)
            if not self.allowed_ports[name]:
                del self.allowed_ports[name]

    # ────────────────────────────────────────────────────────────────────────────────────────
    def toggle_allowed_port(self, name: str, port: int) -> None:
        """Toggle a port in the allowed set for an interface."""
        if name in self.allowed_ports and port in self.allowed_ports[name]:
            self.remove_allowed_port(name, port)
        else:
            self.add_allowed_port(name, port)

    # ── ICMP ───────────────────────────────────────────────────────────

    # ────────────────────────────────────────────────────────────────────────────────────────
    def is_icmp_blocked(self, name: str) -> bool:
        """Check if ICMP is blocked on an interface."""
        return name in self.block_icmp

    # ────────────────────────────────────────────────────────────────────────────────────────
    def set_icmp_blocked(self, name: str, *, blocked: bool) -> None:
        """Explicitly set whether ICMP is blocked on an interface."""
        if blocked:
            self.block_icmp.add(name)
        else:
            self.block_icmp.discard(name)

    # ────────────────────────────────────────────────────────────────────────────────────────
    def toggle_icmp(self, name: str) -> None:
        """Toggle whether ICMP is blocked on an interface."""
        if name in self.block_icmp:
            self.block_icmp.discard(name)
        else:
            self.block_icmp.add(name)

    # ── Helpers ────────────────────────────────────────────────────────

    # ────────────────────────────────────────────────────────────────────────────────────────
    def has_exceptions(self, name: str) -> bool:
        """Check if a blocked interface has any non-default settings."""
        return bool(self.allowed_ports.get(name)) or name in self.block_icmp

    # ── Copy ──────────────────────────────────────────────────────────

    # ────────────────────────────────────────────────────────────────────────────────────────
    def copy(self) -> "BlockedInterfaces":
        """Return a deep copy."""
        return BlockedInterfaces(
            interfaces=set(self.interfaces),
            allowed_ports={k: set(v) for k, v in self.allowed_ports.items()},
            block_icmp=set(self.block_icmp),
        )
