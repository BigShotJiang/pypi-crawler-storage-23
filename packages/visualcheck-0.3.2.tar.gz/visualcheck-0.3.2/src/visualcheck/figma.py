from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import requests

from .baseline import baseline_path
from .utils import ensure_dir, slug


class FigmaError(RuntimeError):
    pass


# from decouple import config

def _get_token(cfg: dict) -> Optional[str]:
    fig = cfg.get("figma") or {}
    token_env = fig.get("token_env") or "FIGMA_TOKEN"
    # Prefer .env (python-decouple); fall back to common host env var OPENCLAW_FIGMA_TOKEN
    # and then to the direct environment variable if present.
    # return config(token_env, default=os.environ.get('OPENCLAW_FIGMA_TOKEN') or os.environ.get(token_env))
    return (
            os.getenv(token_env)
            or os.getenv("FIGMA_TOKEN")
    )


def _figma_headers(token: str) -> dict:
    return {"X-Figma-Token": token}


def _collect_node_name_map(token: str, file_key: str) -> Dict[str, str]:
    url = f"https://api.figma.com/v1/files/{file_key}"
    r = requests.get(url, headers=_figma_headers(token), timeout=30)
    if r.status_code != 200:
        return {}
    data = r.json()
    root = (data.get("document") or {})
    out: Dict[str, str] = {}

    def walk(node: dict) -> None:
        nid = node.get("id")
        name = node.get("name")
        if nid and name:
            out[name] = nid
        for ch in node.get("children") or []:
            walk(ch)

    walk(root)
    return out


def figma_frame_meta(cfg: dict, snapshot_id: str, view_id: str) -> Optional[dict]:
    fig = cfg.get("figma") or {}
    file_key = fig.get("file_key")
    frames = fig.get("frames") or []
    if not file_key:
        return None

    for fr in frames:
        if fr.get("id") != snapshot_id:
            continue
        if fr.get("view_id") and fr.get("view_id") != view_id:
            continue
        node_id = fr.get("node_id")
        if not node_id:
            continue
        return {
            "file_key": file_key,
            "node_id": node_id,
            "frame_id": fr.get("id"),
            "view_id": fr.get("view_id") or "figma",
            "frame_url": f"https://www.figma.com/file/{file_key}?node-id={node_id.replace(':', '-')}",
        }
    return None


def figma_sync_baselines(
    cfg: dict,
    *,
    force: bool = False,
    only_ids: Optional[Sequence[str]] = None,
    match_by_name: bool = False,
) -> dict:
    """Download configured Figma frame node_ids as PNG into figma baseline folder.

    Config:
      figma:
        token_env: FIGMA_TOKEN
        file_key: abcd...
        frames:
          - id: home
            node_id: 123:456
            view_id: desktop_1440x900   # optional

    If view_id is omitted, baseline is written under a special 'figma' view folder of that frame for all views.
    """

    fig = cfg.get("figma") or {}
    if not fig:
        return {"status": "SKIPPED", "reason": "figma section not configured"}

    token = _get_token(cfg)
    if not token:
        return {"status": "SKIPPED", "reason": "Figma token not found in env"}

    file_key = fig.get("file_key")
    frames = list(fig.get("frames") or [])
    if not file_key:
        return {"status": "SKIPPED", "reason": "figma.file_key missing"}
    if not frames and not match_by_name:
        return {"status": "SKIPPED", "reason": "figma.frames missing"}

    only = set(only_ids or [])
    if only:
        frames = [fr for fr in frames if fr.get("id") in only]

    if match_by_name:
        snapshot_ids = [p.get("id") for p in (cfg.get("pages") or []) if p.get("id")]
        for fl in cfg.get("flows") or []:
            flow_id = fl.get("id")
            for s in fl.get("snapshots") or []:
                sid = s.get("id")
                if flow_id and sid:
                    snapshot_ids.append(f"{flow_id}__{sid}")
        if only:
            snapshot_ids = [x for x in snapshot_ids if x in only]
        name_map = _collect_node_name_map(token, file_key)
        existing = {(fr.get("id"), fr.get("view_id") or "figma") for fr in frames}
        for sid in snapshot_ids:
            node_id = name_map.get(sid)
            if not node_id:
                continue
            key = (sid, "figma")
            if key in existing:
                continue
            frames.append({"id": sid, "node_id": node_id, "view_id": "figma"})

    if not frames:
        return {"status": "SKIPPED", "reason": "no figma frames selected"}

    downloaded = []
    skipped = []

    for fr in frames:
        snap_id = fr["id"]
        node_id = fr["node_id"]
        view_id = fr.get("view_id") or "figma"

        # request image URL
        url = f"https://api.figma.com/v1/images/{file_key}?ids={node_id}&format=png&scale=1"
        r = requests.get(url, headers=_figma_headers(token), timeout=30)
        if r.status_code != 200:
            skipped.append({"id": snap_id, "node_id": node_id, "reason": f"figma images api {r.status_code}"})
            continue
        data = r.json()
        img_url = (data.get("images") or {}).get(node_id)
        if not img_url:
            skipped.append({"id": snap_id, "node_id": node_id, "reason": "no image url"})
            continue

        ir = requests.get(img_url, timeout=60)
        if ir.status_code != 200:
            skipped.append({"id": snap_id, "node_id": node_id, "reason": f"download {ir.status_code}"})
            continue

        dest = baseline_path(cfg, "figma", view_id, snap_id)
        ensure_dir(dest.parent)
        if dest.exists() and not force:
            skipped.append({"id": snap_id, "dest": str(dest), "reason": "exists"})
            continue
        dest.write_bytes(ir.content)
        downloaded.append(
            {
                "id": snap_id,
                "dest": str(dest),
                "view_id": view_id,
                "node_id": node_id,
                "file_key": file_key,
                "frame_url": f"https://www.figma.com/file/{file_key}?node-id={node_id.replace(':', '-')}",
            }
        )

    return {
        "status": "OK",
        "force": force,
        "only_ids": sorted(only),
        "match_by_name": match_by_name,
        "downloaded": downloaded,
        "skipped": skipped,
    }
