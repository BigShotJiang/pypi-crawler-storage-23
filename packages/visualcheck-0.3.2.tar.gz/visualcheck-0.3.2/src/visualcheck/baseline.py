from __future__ import annotations

import shutil
from pathlib import Path
from typing import Optional, Tuple

from .utils import ensure_dir, slug


def baseline_root(cfg: dict) -> Path:
    # baselines live at repo root next to config
    root = Path(cfg["__root__"])
    return root / "visual_baseline" / cfg["project"] / cfg["suite"]


def run_root(cfg: dict, run_id: str) -> Path:
    root = Path(cfg["__root__"])
    return root / "test_report" / cfg["project"] / "visual_runs" / run_id


def baseline_path(cfg: dict, kind: str, view_id: str, snapshot_id: str) -> Path:
    return baseline_root(cfg) / kind / slug(view_id) / f"{slug(snapshot_id)}.png"


def resolve_baseline(cfg: dict, view_id: str, snapshot_id: str) -> Tuple[Optional[Path], str]:
    """Return (path, kind). kind is figma/runtime/none.

    Simple priority-driven behavior:
    - For each kind in cfg['baseline']['priority'] in order:
      - if kind == 'figma': check local figma baseline for snapshot_id
        - if missing, attempt a single best-effort figma_sync and re-check
        - also consider configured frame ids that match the view
        - if a figma PNG is present, return figma path directly
        - optional legacy mode can seed runtime from figma
      - else: check for existing baseline of that kind and return it
    - If none found: return (None, 'none')
    """
    priority = cfg["baseline"]["priority"]

    # Runtime-first optimization:
    # If runtime is the first priority and creation is allowed, do not consult
    # Figma when runtime is missing; caller will create runtime from current.
    if priority and priority[0] == "runtime":
        runtime_p = baseline_path(cfg, "runtime", view_id, snapshot_id)
        if runtime_p.exists():
            return runtime_p, "runtime"
        if cfg.get("baseline", {}).get("create_if_missing", False):
            return None, "none"

    for kind in priority:
        if kind != "figma":
            p = baseline_path(cfg, kind, view_id, snapshot_id)
            if p.exists():
                return p, kind

        else:
            # check direct snapshot id first
            p = baseline_path(cfg, "figma", view_id, snapshot_id)
            if not p.exists():
                # try a single best-effort sync to populate figma baselines
                try:
                    from .figma import figma_sync_baselines

                    figma_sync_baselines(cfg)
                except Exception:
                    pass
            # re-check by snapshot id
            p = baseline_path(cfg, "figma", view_id, snapshot_id)
            if p.exists():
                seed_from_figma = bool(cfg.get("baseline", {}).get("seed_runtime_from_figma", False))
                if seed_from_figma:
                    try:
                        runtime_p = baseline_path(cfg, "runtime", view_id, snapshot_id)
                        if not runtime_p.exists():
                            ensure_dir(runtime_p.parent)
                            shutil.copy2(p, runtime_p)
                    except Exception:
                        pass
                # If figma_authoritative, copy into runtime and return runtime path
                figma_auth = bool(cfg.get("baseline", {}).get("figma_authoritative", False))
                if figma_auth:
                    try:
                        runtime_p = baseline_path(cfg, "runtime", view_id, snapshot_id)
                        ensure_dir(runtime_p.parent)
                        shutil.copy2(p, runtime_p)
                        return runtime_p, "figma"
                    except Exception:
                        return p, "figma"

                return p, "figma"

            # if snapshot-named figma missing, check configured frame ids for this view
            fig_cfg = cfg.get("figma") or {}
            frames = fig_cfg.get("frames") or []
            for fr in frames:
                if fr.get("view_id") and fr.get("view_id") != view_id:
                    continue
                fid = fr.get("id")
                if not fid:
                    continue
                p2 = baseline_path(cfg, "figma", view_id, fid)
                if p2.exists():
                    seed_from_figma = bool(cfg.get("baseline", {}).get("seed_runtime_from_figma", False))
                    if seed_from_figma:
                        try:
                            runtime_p = baseline_path(cfg, "runtime", view_id, snapshot_id)
                            if not runtime_p.exists():
                                ensure_dir(runtime_p.parent)
                                shutil.copy2(p2, runtime_p)
                        except Exception:
                            pass

                    # respect figma_authoritative for frame-based matches too
                    figma_auth = bool(cfg.get("baseline", {}).get("figma_authoritative", False))
                    if figma_auth:
                        try:
                            runtime_p = baseline_path(cfg, "runtime", view_id, snapshot_id)
                            ensure_dir(runtime_p.parent)
                            shutil.copy2(p2, runtime_p)
                            return runtime_p, "figma"
                        except Exception:
                            return p2, "figma"

                    return p2, "figma"

    return None, "none"


def ensure_runtime_baseline(
    cfg: dict,
    view_id: str,
    snapshot_id: str,
    current_png: Path,
) -> Tuple[Optional[Path], str]:
    """Create runtime baseline if missing and allowed. Never overwrites."""
    p = baseline_path(cfg, "runtime", view_id, snapshot_id)
    if p.exists():
        return p, "runtime"

    if not cfg["baseline"].get("create_if_missing", False):
        return None, "none"

    ensure_dir(p.parent)
    shutil.copy2(current_png, p)
    return p, "runtime_created"


def approve_current_as_runtime(cfg: dict, env: str, run_id: str, force: bool = False) -> dict:
    rr = run_root(cfg, run_id)
    current_dir = rr / "current"
    if not current_dir.exists():
        raise FileNotFoundError(f"Current screenshots not found: {current_dir}")

    copied = []
    skipped = []

    for png in current_dir.rglob("*.png"):
        rel = png.relative_to(current_dir)
        # rel: view_id/snapshot_id.png
        parts = rel.parts
        if len(parts) < 2:
            continue
        view_id = parts[0]
        snapshot_id = Path(parts[-1]).stem
        dest = baseline_path(cfg, "runtime", view_id, snapshot_id)
        ensure_dir(dest.parent)
        if dest.exists() and not force:
            skipped.append({"dest": str(dest), "reason": "exists (use --force)"})
            continue
        shutil.copy2(png, dest)
        copied.append({"src": str(png), "dest": str(dest)})

    return {"env": env, "run_id": run_id, "copied": copied, "skipped": skipped}


def cleanup_visual_runs(cfg: dict, keep_last: int = 10, dry_run: bool = False) -> dict:
    runs_root = Path(cfg["__root__"]) / "test_report" / cfg["project"] / "visual_runs"
    if keep_last < 0:
        raise ValueError("keep_last must be >= 0")
    if not runs_root.exists():
        return {"runs_root": str(runs_root), "kept": [], "deleted": [], "dry_run": dry_run}

    run_dirs = [p for p in runs_root.iterdir() if p.is_dir()]
    # run ids are timestamp-like names, so lexical sort keeps timeline ordering
    run_dirs.sort(key=lambda p: p.name, reverse=True)

    kept = [str(p) for p in run_dirs[:keep_last]]
    remove = run_dirs[keep_last:]
    deleted = []

    for p in remove:
        if dry_run:
            deleted.append({"path": str(p), "status": "would_delete"})
            continue
        shutil.rmtree(p, ignore_errors=False)
        deleted.append({"path": str(p), "status": "deleted"})

    return {"runs_root": str(runs_root), "kept": kept, "deleted": deleted, "dry_run": dry_run}
