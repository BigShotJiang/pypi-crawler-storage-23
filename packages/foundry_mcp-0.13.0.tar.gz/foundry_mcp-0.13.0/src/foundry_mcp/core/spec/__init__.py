"""Spec operations package.

Re-exports the full public API so that all existing imports continue to work::

    from foundry_mcp.core.spec import load_spec, save_spec, ...

Sub-modules:
- ``_constants``: Shared constants
- ``io``: I/O functions (find, load, save, backup, list, diff, rollback)
- ``hierarchy``: Hierarchy operations (get/update node, phase CRUD, recalculate hours)
- ``templates``: Spec creation, assumptions, revisions, frontmatter
- ``analysis``: Read-only analysis (completeness checks, duplicate detection)
- ``_monolith``: Remaining spec operations (find-replace)
"""

from foundry_mcp.core.spec._constants import (
    CATEGORIES,
    COMPLEXITY_LEVELS,
    DEFAULT_BACKUP_PAGE_SIZE,
    DEFAULT_DIFF_MAX_RESULTS,
    DEFAULT_MAX_BACKUPS,
    FRONTMATTER_KEYS,
    MAX_BACKUP_PAGE_SIZE,
    TEMPLATE_DESCRIPTIONS,
    TEMPLATES,
    VERIFICATION_TYPES,
)
from foundry_mcp.core.spec._monolith import (
    # Find and replace
    find_replace_in_spec,
)
from foundry_mcp.core.spec.analysis import (
    # Analysis and validation
    check_spec_completeness,
    detect_duplicate_tasks,
)
from foundry_mcp.core.spec.hierarchy import (
    # Phase operations
    add_phase,
    add_phase_bulk,
    # Hierarchy/node functions
    get_node,
    move_phase,
    recalculate_actual_hours,
    remove_phase,
    update_node,
    update_phase_metadata,
)
from foundry_mcp.core.spec.io import (
    _apply_backup_retention,  # noqa: F401
    backup_spec,
    diff_specs,
    find_git_root,
    find_spec_file,
    find_specs_directory,
    generate_spec_id,
    list_spec_backups,
    list_specs,
    load_spec,
    resolve_spec_file,
    rollback_spec,
    save_spec,
)
from foundry_mcp.core.spec.templates import (
    # Assumptions and revisions
    add_assumption,
    # Constraints, risks, questions, success criteria
    add_constraint,
    add_question,
    add_revision,
    add_risk,
    add_success_criterion,
    # Spec creation
    create_spec,
    generate_spec_data,
    get_template_structure,
    list_assumptions,
    list_constraints,
    list_questions,
    list_risks,
    list_success_criteria,
    # Frontmatter and metadata
    update_frontmatter,
)

__all__ = [
    # Constants
    "CATEGORIES",
    "COMPLEXITY_LEVELS",
    "DEFAULT_BACKUP_PAGE_SIZE",
    "DEFAULT_DIFF_MAX_RESULTS",
    "DEFAULT_MAX_BACKUPS",
    "FRONTMATTER_KEYS",
    "MAX_BACKUP_PAGE_SIZE",
    "TEMPLATES",
    "TEMPLATE_DESCRIPTIONS",
    "VERIFICATION_TYPES",
    # I/O functions (from io.py)
    "backup_spec",
    "diff_specs",
    "find_git_root",
    "find_spec_file",
    "find_specs_directory",
    "generate_spec_id",
    "list_spec_backups",
    "list_specs",
    "load_spec",
    "resolve_spec_file",
    "rollback_spec",
    "save_spec",
    # Hierarchy/node functions
    "get_node",
    "update_node",
    # Spec creation
    "create_spec",
    "generate_spec_data",
    "get_template_structure",
    # Phase operations
    "add_phase",
    "add_phase_bulk",
    "move_phase",
    "remove_phase",
    "update_phase_metadata",
    # Frontmatter and metadata
    "update_frontmatter",
    # Assumptions and revisions
    "add_assumption",
    "add_revision",
    "list_assumptions",
    # Constraints, risks, questions, success criteria
    "add_constraint",
    "add_question",
    "add_risk",
    "add_success_criterion",
    "list_constraints",
    "list_questions",
    "list_risks",
    "list_success_criteria",
    # Analysis and validation
    "check_spec_completeness",
    "detect_duplicate_tasks",
    "recalculate_actual_hours",
    # Find and replace
    "find_replace_in_spec",
]
