"""Provides a simple greeting function that returns a friendly message.

The module defines a single function, `hello`, which returns the string
`'Hello from py_cq!'`. It can serve as a minimal example, placeholder, or
testing stub in larger applications."""


def hello() -> str:
    """Returns the greeting string `'Hello from py_cq!'`."""
    return "Hello from py_cq!"
