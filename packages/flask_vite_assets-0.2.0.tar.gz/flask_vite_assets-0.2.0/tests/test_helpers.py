"""Tests for vite_asset and vite_hmr_client helper functions."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock

import pytest
from markupsafe import Markup

from flask_vite_assets.helpers import vite_asset, vite_hmr_client


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write_manifest(static_folder: str, asset_name: str, file_path: str, css_files: list[str] | None = None) -> None:
    vite_dir = Path(static_folder) / ".vite"
    vite_dir.mkdir(parents=True, exist_ok=True)
    entry: dict = {"file": file_path}
    if css_files:
        entry["css"] = css_files
    (vite_dir / "manifest.json").write_text(json.dumps({asset_name: entry}))


# ---------------------------------------------------------------------------
# vite_asset — development mode
# ---------------------------------------------------------------------------


class TestViteAssetDev:
    def test_primary_dev_server(self, monkeypatch, app):
        """Uses primary Vite dev server when it is reachable."""
        app.config["DEBUG"] = True
        monkeypatch.setenv("VITE_DEV_SERVER", "http://localhost:5173")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        monkeypatch.setattr("requests.get", lambda url, timeout: mock_resp)

        with app.test_request_context():
            result = vite_asset("js/main.js")

        assert isinstance(result, Markup)
        assert "http://localhost:5173/static/js/main.js" in str(result)

    def test_alternate_dev_server(self, monkeypatch, app):
        """Falls back to port+1 when the primary dev server is unreachable."""
        app.config["DEBUG"] = True
        monkeypatch.setenv("VITE_DEV_SERVER", "http://localhost:5173")

        def fake_get(url: str, timeout: float):
            if "5173" in url:
                raise ConnectionError("refused")
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            return mock_resp

        monkeypatch.setattr("requests.get", fake_get)

        with app.test_request_context():
            result = vite_asset("js/main.js")

        assert isinstance(result, Markup)
        assert "http://localhost:5174/static/js/main.js" in str(result)

    def test_both_servers_fail_uses_manifest(self, monkeypatch, app, tmp_path):
        """Falls back to manifest when both dev servers are unreachable."""
        app.config["DEBUG"] = True
        monkeypatch.setenv("VITE_DEV_SERVER", "http://localhost:5173")
        monkeypatch.setattr("requests.get", lambda url, timeout: (_ for _ in ()).throw(ConnectionError("refused")))

        _write_manifest(str(tmp_path / "static"), "js/main.js", "assets/js/main.abc.js")

        with app.test_request_context():
            result = vite_asset("js/main.js")

        assert "assets/js/main.abc.js" in str(result)

    def test_flask_config_overrides_env_var(self, monkeypatch, app):
        """Flask config VITE_DEV_SERVER takes precedence over env var."""
        app.config["DEBUG"] = True
        app.config["VITE_DEV_SERVER"] = "http://custom:9000"
        monkeypatch.setenv("VITE_DEV_SERVER", "http://localhost:5173")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        monkeypatch.setattr("requests.get", lambda url, timeout: mock_resp)

        with app.test_request_context():
            result = vite_asset("js/main.js")

        assert "http://custom:9000/static/js/main.js" in str(result)


# ---------------------------------------------------------------------------
# vite_asset — production mode
# ---------------------------------------------------------------------------


class TestViteAssetProduction:
    def test_js_only_entry(self, app, tmp_path):
        """Returns a <script> tag for a JS-only manifest entry."""
        app.config["DEBUG"] = False
        _write_manifest(str(tmp_path / "static"), "js/main.js", "assets/js/main.abc.js")

        with app.test_request_context():
            result = vite_asset("js/main.js")

        s = str(result)
        assert 'script type="module"' in s
        assert "assets/js/main.abc.js" in s
        assert "<link" not in s

    def test_entry_with_css(self, app, tmp_path):
        """Returns <link> + <script> tags when the manifest entry includes CSS."""
        app.config["DEBUG"] = False
        _write_manifest(
            str(tmp_path / "static"),
            "js/main.js",
            "assets/js/main.abc.js",
            css_files=["assets/css/main.abc.css"],
        )

        with app.test_request_context():
            result = vite_asset("js/main.js")

        s = str(result)
        assert '<link rel="stylesheet"' in s
        assert "assets/css/main.abc.css" in s
        assert 'script type="module"' in s

    def test_missing_manifest_fallback(self, app, tmp_path):
        """Falls back to direct static URL when manifest is missing."""
        app.config["DEBUG"] = False
        # Ensure there is no manifest
        vite_dir = tmp_path / "static" / ".vite"
        if (vite_dir / "manifest.json").exists():
            (vite_dir / "manifest.json").unlink()

        with app.test_request_context():
            result = vite_asset("js/nonexistent.js")

        assert "static/js/nonexistent.js" in str(result)

    def test_corrupt_manifest_fallback(self, app, tmp_path):
        """Falls back to direct static URL when manifest JSON is corrupt."""
        app.config["DEBUG"] = False
        vite_dir = tmp_path / "static" / ".vite"
        vite_dir.mkdir(parents=True, exist_ok=True)
        (vite_dir / "manifest.json").write_text("{ not valid json }")

        with app.test_request_context():
            result = vite_asset("js/main.js")

        assert "static/js/main.js" in str(result)

    def test_missing_asset_key_fallback(self, app, tmp_path):
        """Falls back to direct static URL when the asset key is absent from manifest."""
        app.config["DEBUG"] = False
        _write_manifest(str(tmp_path / "static"), "js/other.js", "assets/js/other.abc.js")

        with app.test_request_context():
            result = vite_asset("js/main.js")

        assert "static/js/main.js" in str(result)

    def test_custom_manifest_path(self, app, tmp_path):
        """Respects VITE_MANIFEST_PATH config key."""
        app.config["DEBUG"] = False
        manifest_file = tmp_path / "custom_manifest.json"
        manifest_file.write_text(json.dumps({"js/main.js": {"file": "assets/js/main.xyz.js"}}))
        app.config["VITE_MANIFEST_PATH"] = str(manifest_file)

        with app.test_request_context():
            result = vite_asset("js/main.js")

        assert "assets/js/main.xyz.js" in str(result)

    def test_multiple_css_files(self, app, tmp_path):
        """Emits one <link> tag per CSS file in the manifest entry."""
        app.config["DEBUG"] = False
        _write_manifest(
            str(tmp_path / "static"),
            "js/main.js",
            "assets/js/main.abc.js",
            css_files=["assets/css/a.css", "assets/css/b.css"],
        )

        with app.test_request_context():
            result = vite_asset("js/main.js")

        s = str(result)
        assert s.count('<link rel="stylesheet"') == 2


# ---------------------------------------------------------------------------
# vite_hmr_client
# ---------------------------------------------------------------------------


class TestViteHmrClient:
    def test_returns_empty_in_production(self, app):
        """vite_hmr_client returns an empty string in production mode."""
        app.config["DEBUG"] = False

        with app.test_request_context():
            result = vite_hmr_client()

        assert result == ""

    def test_returns_script_tag_in_dev(self, monkeypatch, app):
        """Returns the HMR script tag when the dev server is reachable."""
        app.config["DEBUG"] = True
        monkeypatch.setenv("VITE_DEV_SERVER", "http://localhost:5173")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        monkeypatch.setattr("requests.get", lambda url, timeout: mock_resp)

        with app.test_request_context():
            result = vite_hmr_client()

        assert "@vite/client" in str(result)
        assert "http://localhost:5173" in str(result)

    def test_falls_back_to_alternate_port(self, monkeypatch, app):
        """Uses port+1 when the primary dev server is unreachable."""
        app.config["DEBUG"] = True
        monkeypatch.setenv("VITE_DEV_SERVER", "http://localhost:5173")

        def fake_get(url: str, timeout: float):
            if "5173" in url:
                raise ConnectionError("refused")
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            return mock_resp

        monkeypatch.setattr("requests.get", fake_get)

        with app.test_request_context():
            result = vite_hmr_client()

        assert "@vite/client" in str(result)
        assert "5174" in str(result)

    def test_returns_empty_when_both_servers_fail(self, monkeypatch, app):
        """Returns empty string when neither dev server is reachable."""
        app.config["DEBUG"] = True
        monkeypatch.setenv("VITE_DEV_SERVER", "http://localhost:5173")
        monkeypatch.setattr("requests.get", lambda url, timeout: (_ for _ in ()).throw(ConnectionError("refused")))

        with app.test_request_context():
            result = vite_hmr_client()

        assert result == ""

