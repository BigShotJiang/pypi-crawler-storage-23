"""Tests for the ViteAssets Flask extension."""

import os

import pytest
from flask import Flask

from flask_vite_assets import ViteAssets


def test_init_app_registers_globals(app):
    """init_app should add vite_asset and vite_hmr_client to jinja globals."""
    ext = ViteAssets()
    ext.init_app(app)

    assert "vite_asset" in app.jinja_env.globals
    assert "vite_hmr_client" in app.jinja_env.globals


def test_constructor_with_app_registers_globals():
    """Passing app to the constructor should register globals immediately."""
    _app = Flask(__name__)
    ViteAssets(_app)

    assert "vite_asset" in _app.jinja_env.globals
    assert "vite_hmr_client" in _app.jinja_env.globals


def test_extension_stored_on_app(app):
    """init_app should store itself in app.extensions."""
    ext = ViteAssets()
    ext.init_app(app)

    assert app.extensions["vite_assets"] is ext


def test_constructor_without_app_deferred_init():
    """Constructing without an app should not raise."""
    ext = ViteAssets()
    assert ext.app is None


def test_init_app_called_twice_is_safe(app):
    """Calling init_app twice on the same app should not raise."""
    ext = ViteAssets()
    ext.init_app(app)
    ext.init_app(app)  # second call should be harmless


def test_jinja_template_renders_vite_asset(app, tmp_path):
    """vite_asset should be callable from Jinja2 templates."""
    from flask import render_template_string

    ViteAssets(app)

    # Write a manifest so production mode works
    import json
    vite_dir = tmp_path / "static" / ".vite"
    vite_dir.mkdir(parents=True, exist_ok=True)
    manifest = {"js/main.js": {"file": "assets/js/main.abc.js"}}
    (vite_dir / "manifest.json").write_text(json.dumps(manifest))

    app.config["DEBUG"] = False
    app.config["VITE_MANIFEST_PATH"] = str(vite_dir / "manifest.json")

    with app.test_request_context():
        result = render_template_string('{{ vite_asset("js/main.js") }}')
        assert "assets/js/main.abc.js" in result


def test_jinja_template_renders_vite_hmr_client_empty_in_prod(app):
    """vite_hmr_client should return empty string in production."""
    from flask import render_template_string

    ViteAssets(app)
    app.config["DEBUG"] = False

    with app.test_request_context():
        result = render_template_string("{{ vite_hmr_client() }}")
        assert result.strip() == ""


class TestCacheBustingUrlFor:
    def test_static_url_gains_version_param(self, app):
        """url_for('static', ...) should append ?v=<mtime> for existing files."""
        import pathlib
        from flask import render_template_string

        ViteAssets(app)

        # Write a real file into the app's static folder so os.stat succeeds
        css_dir = pathlib.Path(app.static_folder) / "css"
        css_dir.mkdir(parents=True, exist_ok=True)
        (css_dir / "main.css").write_text("body {}")

        with app.test_request_context():
            result = render_template_string('{{ url_for("static", filename="css/main.css") }}')

        assert "css/main.css" in result
        assert "?v=" in result

    def test_static_url_no_version_for_missing_file(self, app):
        """url_for('static', ...) should not append ?v= when the file does not exist."""
        from flask import render_template_string

        ViteAssets(app)

        with app.test_request_context():
            result = render_template_string('{{ url_for("static", filename="css/nonexistent.css") }}')

        assert "css/nonexistent.css" in result
        assert "?v=" not in result

    def test_non_static_endpoint_unaffected(self, app):
        """url_for for non-static endpoints should not be modified."""
        from flask import render_template_string

        ViteAssets(app)

        @app.route("/hello")
        def hello():
            return "hi"

        with app.test_request_context():
            result = render_template_string('{{ url_for("hello") }}')

        assert result == "/hello"
        assert "?v=" not in result


