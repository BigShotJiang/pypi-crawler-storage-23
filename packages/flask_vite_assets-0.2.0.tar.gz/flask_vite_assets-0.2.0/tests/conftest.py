"""Pytest configuration and shared fixtures for flask-vite-assets tests."""

import pytest
from flask import Flask


@pytest.fixture()
def app(tmp_path):
    """Minimal Flask application for testing."""
    _app = Flask(__name__, static_folder=str(tmp_path / "static"))
    _app.config["TESTING"] = True
    _app.config["SECRET_KEY"] = "test-secret"

    # Create the static folder
    (tmp_path / "static").mkdir(exist_ok=True)

    return _app

