# Flask-Vite-Assets

A Flask extension that seamlessly integrates [Vite](https://vitejs.dev/) asset management into your Flask/Jinja2 templates, supporting both the Vite dev server (with HMR) and production manifest-based asset fingerprinting.

## Features

- 🔥 **Hot Module Replacement (HMR)** in development via the Vite dev server
- 📦 **Manifest-based asset fingerprinting** in production
- 🎨 **Automatic CSS injection** from the Vite manifest
- ⚡ **Cache-busting `url_for`** — static file URLs automatically gain a `?v=<mtime>` parameter so browsers always pick up the latest file after a deployment
- 🔌 **Flask extension pattern** with `init_app` support
- 🧩 **Zero-config defaults** with full configurability
- 🐍 **Typed** — ships with `py.typed`

## Installation

```bash
pip install flask-vite-assets
```

If you use the Vite dev server in development, also install `requests`:

```bash
pip install "flask-vite-assets[dev-server]"
```

## Quick start

### Application factory pattern

```python
from flask import Flask
from flask_vite_assets import ViteAssets

vite = ViteAssets()

def create_app():
    app = Flask(__name__)
    vite.init_app(app)
    return app
```

### Direct initialisation

```python
from flask import Flask
from flask_vite_assets import ViteAssets

app = Flask(__name__)
ViteAssets(app)
```

### Jinja2 templates

```html
<!DOCTYPE html>
<html>
<head>
    <!-- Injects <link> + <script> tags from the Vite manifest in production,
         or a <script> tag pointing at the Vite dev server in development -->
    {{ vite_asset("js/main.js") }}

    <!-- Cache-busting url_for: appends ?v=<mtime> to static file URLs so
         browsers always fetch the latest file after a deployment -->
    <link rel="stylesheet" href="{{ url_for('static', filename='css/extra.css') }}">
</head>
<body>
    ...
    <!-- Injects the Vite HMR client in development only (no-op in production) -->
    {{ vite_hmr_client() }}
</body>
</html>
```

## How it works

### Development mode (`DEBUG=True`)

1. The extension attempts to connect to the Vite dev server (default `http://localhost:5173`).
2. If the server is reachable it returns a `<script type="module">` tag pointing at the dev server, enabling HMR.
3. If the primary port is unavailable it automatically tries the next port (`5174`), which Vite uses when the preferred port is already occupied.
4. If neither server is reachable it falls back to the production manifest.

### Production mode (`DEBUG=False`)

1. Reads `<app.static_folder>/.vite/manifest.json`.
2. For each entry emits `<link rel="stylesheet">` tags for associated CSS files, then a `<script type="module">` tag for the JS bundle.
3. Falls back to serving the asset path directly if the manifest is missing or malformed.

## Configuration

All configuration is optional.

| Flask config key      | Environment variable | Default                                       | Description                                        |
|-----------------------|----------------------|-----------------------------------------------|----------------------------------------------------|
| `VITE_DEV_SERVER`     | `VITE_DEV_SERVER`    | `http://localhost:5173`                       | Base URL of the Vite dev server                    |
| `VITE_MANIFEST_PATH`  | —                    | `<app.static_folder>/.vite/manifest.json`     | Absolute path to the production Vite manifest      |

Flask config takes precedence over environment variables.

## Vite configuration

Point Vite's output at your Flask `static` folder and enable manifest generation:

```js
// vite.config.js
import { defineConfig } from "vite";

export default defineConfig({
  root: "resources",
  base: "/static/",
  build: {
    outDir: "../resources/static",
    manifest: true,
    rollupOptions: {
      input: "assets/js/main.js",
    },
  },
});
```

## Using the helpers directly

You can also call the helpers directly in Python code instead of going through the extension:

```python
from flask_vite_assets import vite_asset, vite_hmr_client
```

## License

MIT

