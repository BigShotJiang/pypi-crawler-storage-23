"""Flask extension class for Flask-Vite-Assets."""

from __future__ import annotations

import os

from flask import Flask

from flask_vite_assets.helpers import vite_asset, vite_hmr_client


class ViteAssets:
    """Flask extension that registers ``vite_asset`` and ``vite_hmr_client``
    as Jinja2 globals and installs a cache-busting ``url_for`` helper so they
    are available in every template without any extra imports.

    Usage — application factory pattern::

        from flask_vite_assets import ViteAssets

        vite = ViteAssets()

        def create_app():
            app = Flask(__name__)
            vite.init_app(app)
            return app

    Usage — direct initialisation::

        from flask import Flask
        from flask_vite_assets import ViteAssets

        app = Flask(__name__)
        ViteAssets(app)

    Configuration keys (all optional):

    ``VITE_DEV_SERVER``
        Base URL of the Vite dev server.  Defaults to
        ``http://localhost:5173``.  Can also be set via the environment
        variable of the same name.

    ``VITE_MANIFEST_PATH``
        Absolute path to the Vite ``manifest.json``.  Defaults to
        ``<app.static_folder>/.vite/manifest.json``.
    """

    def __init__(self, app: Flask | None = None) -> None:
        self.app = app
        if app is not None:
            self.init_app(app)

    def init_app(self, app: Flask) -> None:
        """Initialise the extension with *app*.

        Registers ``vite_asset`` and ``vite_hmr_client`` as Jinja2 globals
        so they are usable in all templates, e.g.::

            {{ vite_asset("js/main.js") }}
            {{ vite_hmr_client() }}

        Also registers a context processor that overrides the built-in
        ``url_for`` with a cache-busting version.  Static file URLs gain a
        ``?v=<mtime>`` query-string parameter so browsers always fetch the
        latest file after a deployment.
        """
        app.jinja_env.globals.update(
            vite_asset=vite_asset,
            vite_hmr_client=vite_hmr_client,
        )

        @app.context_processor
        def _vite_assets_context() -> dict:
            from flask import url_for as _flask_url_for

            def url_for(endpoint: str, **values: object) -> str:  # type: ignore[override]
                if endpoint == "static":
                    filename = values.get("filename")
                    if filename and app.static_folder:
                        file_path = os.path.join(app.static_folder, str(filename))
                        if os.path.exists(file_path):
                            values["v"] = int(os.stat(file_path).st_mtime)
                return _flask_url_for(endpoint, **values)

            return dict(url_for=url_for)

        # Store the extension on the app so it can be retrieved via
        # current_app.extensions["vite_assets"] if needed.
        app.extensions["vite_assets"] = self

