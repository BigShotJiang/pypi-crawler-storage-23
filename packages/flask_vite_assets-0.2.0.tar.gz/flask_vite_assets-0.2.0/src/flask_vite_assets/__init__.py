"""Flask-Vite-Assets: Flask extension for Vite asset management."""

from flask_vite_assets.extension import ViteAssets
from flask_vite_assets.helpers import vite_asset, vite_hmr_client

__all__ = ["ViteAssets", "vite_asset", "vite_hmr_client"]
__version__ = "0.1.0"

