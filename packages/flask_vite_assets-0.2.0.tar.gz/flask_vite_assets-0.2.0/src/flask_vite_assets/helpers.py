"""Core Vite asset helper functions for Flask templates."""

from __future__ import annotations

import json
import os

from flask import current_app, url_for
from markupsafe import Markup


def vite_asset(asset_name: str) -> Markup:
    """
    Return HTML tag(s) for a Vite-managed asset.

    In development mode (``DEBUG=True``) this first tries to proxy through the
    Vite dev server (default ``http://localhost:5173``, configurable via the
    ``VITE_DEV_SERVER`` environment variable or the Flask config key
    ``VITE_DEV_SERVER``).  If the dev server is unreachable the function falls
    back to reading the production manifest.

    In production mode the function reads Vite's ``manifest.json`` (located at
    ``<static_folder>/.vite/manifest.json`` by default, or overridden by the
    Flask config key ``VITE_MANIFEST_PATH``) and emits ``<link>`` tags for any
    associated CSS files followed by a ``<script type="module">`` tag for the
    JS bundle.

    Args:
        asset_name: Asset path as it appears in the Vite manifest
                    (e.g. ``"js/main.js"``).

    Returns:
        :class:`markupsafe.Markup` containing the necessary HTML tags.
    """
    is_dev: bool = current_app.config.get("DEBUG", False)
    dev_server: str = _get_dev_server()

    if is_dev:
        tag = _try_dev_server(asset_name, dev_server)
        if tag is not None:
            return tag

    return _production_tags(asset_name)


def vite_hmr_client() -> Markup | str:
    """
    Return the Vite HMR client ``<script>`` tag for development mode.

    Returns an empty string when ``DEBUG`` is ``False`` or when the Vite dev
    server cannot be reached.

    Returns:
        :class:`markupsafe.Markup` with the HMR script tag, or an empty string.
    """
    is_dev: bool = current_app.config.get("DEBUG", False)
    if not is_dev:
        return ""

    dev_server = _get_dev_server()
    return _try_hmr_client(dev_server)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _get_dev_server() -> str:
    """Return the configured Vite dev server URL."""
    # Flask config takes precedence, then environment variable, then default.
    return (
        current_app.config.get("VITE_DEV_SERVER")
        or os.environ.get("VITE_DEV_SERVER")
        or "http://localhost:5173"
    )


def _server_is_up(base_url: str) -> bool:
    """Return ``True`` if the Vite dev server at *base_url* is reachable."""
    try:
        import requests  # imported lazily so it is not required in production

        response = requests.get(f"{base_url}/static/@vite/client", timeout=0.1)
        return response.status_code == 200
    except Exception:
        return False


def _candidate_servers(primary: str) -> list[str]:
    """Return the list of dev servers to try, including the automatic fallback."""
    candidates = [primary]
    # Vite sometimes starts on the next port if the preferred one is busy.
    alt = primary.rstrip("/").rsplit(":", 1)
    if len(alt) == 2:
        try:
            alt_server = f"{alt[0]}:{int(alt[1]) + 1}"
            if alt_server != primary:
                candidates.append(alt_server)
        except ValueError:
            pass
    return candidates


def _try_dev_server(asset_name: str, dev_server: str) -> Markup | None:
    """Try each candidate dev server; return a Markup tag or None."""
    for server in _candidate_servers(dev_server):
        if _server_is_up(server):
            return Markup(f'<script type="module" src="{server}/static/{asset_name}"></script>')
    return None


def _try_hmr_client(dev_server: str) -> Markup | str:
    """Try each candidate dev server for the HMR client tag."""
    for server in _candidate_servers(dev_server):
        if _server_is_up(server):
            return Markup(f'<script type="module" src="{server}/static/@vite/client"></script>')
    return ""


def _manifest_path() -> str:
    """Return the absolute path to the Vite manifest file."""
    configured: str | None = current_app.config.get("VITE_MANIFEST_PATH")
    if configured:
        return configured
    # Default: <app.static_folder>/.vite/manifest.json
    static_folder = current_app.static_folder or ""
    return os.path.join(static_folder, ".vite", "manifest.json")


def _production_tags(asset_name: str) -> Markup:
    """Read the manifest and return CSS + JS tags for *asset_name*."""
    try:
        with open(_manifest_path()) as fh:
            manifest: dict = json.load(fh)

        entry = manifest[asset_name]
        file_path: str = entry["file"]
        css_files: list[str] = entry.get("css", [])

        parts: list[str] = [
            f'<link rel="stylesheet" href="{url_for("static", filename=css)}">'
            for css in css_files
        ]
        parts.append(f'<script type="module" src="{url_for("static", filename=file_path)}"></script>')
        return Markup("\n    ".join(parts))

    except (FileNotFoundError, KeyError, json.JSONDecodeError):
        # Graceful fallback: serve the asset directly.
        return Markup(f'<script type="module" src="{url_for("static", filename=asset_name)}"></script>')

