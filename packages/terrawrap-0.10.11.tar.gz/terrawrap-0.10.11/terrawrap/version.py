"""Place of record for the package version"""

__version__ = "0.10.11"
__git_hash__ = "ecfe5e8be77fa9d25b9c175684ca60a27d6bc5db"
