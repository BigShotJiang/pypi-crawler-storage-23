"""bsuite benchmarks for the Alberta Framework.

Bridges Alberta Framework learners (MultiHeadMLPLearner) to bsuite's
Agent ABC for standardized RL diagnostics. Treats bsuite environments
as continuing streams aligned with the Alberta Plan.
"""
