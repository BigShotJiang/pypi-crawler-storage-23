LoadPackage("QDistRnd");;
H := ReadMTXE("/Users/markwebster/Dropbox/QuantumComputing/dev/codeDistance-main/examples/tmp/20260303_211807.002810_13674611H.mtx",0)[3];;
DistRandStab(H,10000,1,9);