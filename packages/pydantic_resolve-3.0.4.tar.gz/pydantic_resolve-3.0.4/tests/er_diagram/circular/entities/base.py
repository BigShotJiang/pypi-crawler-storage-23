from pydantic_resolve.utils.er_diagram import base_entity

BaseEntity = base_entity()
