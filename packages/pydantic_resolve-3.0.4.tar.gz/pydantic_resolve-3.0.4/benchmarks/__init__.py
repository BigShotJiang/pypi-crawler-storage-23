"""
Pydantic-Resolve Benchmark Suite

Benchmark tests for measuring pydantic-resolve performance.
"""
