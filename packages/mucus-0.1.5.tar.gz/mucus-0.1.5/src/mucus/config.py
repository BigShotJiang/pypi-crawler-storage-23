import pathlib
import yaml


def path(filename='config.yaml'):
    return pathlib.Path().home().joinpath('.config', 'mucus', filename)


def load():
    try:
        with path().open('r') as f:
            return yaml.safe_load(f)
    except FileNotFoundError:
        return {}
