import random

import httpx

import mucus.deezer.stream
import mucus.data
import mucus.exception


class Auth(httpx.Auth):
    def __init__(self, sid=None, arl=None):
        if sid is None or arl is None:
            data = mucus.data.load('auth.yaml')
            try:
                if sid is None:
                    sid = data['sid']
                if arl is None:
                    arl = data['arl']
            except KeyError as e:
                raise mucus.exception.DeezerAuthError
        self.sid = sid
        self.arl = arl

    def auth_flow(self, request):
        request.headers['Cookie'] = f'sid={self.sid}; arl={self.arl}'
        yield request


class Client(httpx.Client):
    base_url = httpx.URL('https://www.deezer.com/ajax/')

    def __init__(self, auth=None):
        if auth is None:
            auth = Auth()
        super().__init__(auth=auth)
        self.data = UserData(self)

    def request(self, method, url, **kwargs):
        if url == 'deezer.getUserData':
            api_token = ''
        else:
            api_token = self.data.api_token

        kwargs['params'] = {
            'method': url,
            'input': 3,
            'api_version': '1.0',
            'api_token': api_token,
            'cid': random.randrange(0, 1000000000)
        }

        r = super().request(method, 'gw-light.php', **kwargs)
        if r.status_code != 200:
            raise mucus.exception.DeezerError(r.status_code)
        r = r.json()
        if r['error']:
            raise mucus.exception.DeezerError(r['error'])

        return r['results']

    def stream(self, song, format='FLAC'):
        return mucus.deezer.stream.Stream(song, self.data.license_token).stream(format)


class UserData:
    def __init__(self, client):
        self._api_token = ''
        self._data = client.post('deezer.getUserData')

    @property
    def api_token(self):
        return self._data['checkForm']

    @property
    def license_token(self):
        return self._data['USER']['OPTIONS']['license_token']
