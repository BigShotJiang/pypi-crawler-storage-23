import click

import mucus.command


class Command(mucus.command.Command):
    def __call__(self, player, **kwargs):
        if player.song is not None:
            click.echo(' '.join([
                click.style(player.song['ART_NAME'], fg='green'),
                click.style(player.song['SNG_TITLE'], fg='blue')
            ]))
