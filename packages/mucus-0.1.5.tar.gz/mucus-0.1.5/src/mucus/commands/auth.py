import click

import mucus.command
import mucus.data


class Command(mucus.command.Command):
    def __call__(self, command, **kwargs):
        if command['line'] == 'auth get':
            data = mucus.data.load('auth.yaml')
            sid, arl = data['sid'], data['arl']
            click.echo(f'{sid}:{arl}')
        elif command['line'].startswith('auth set '):
            sid, arl = command['line'].split(' ')[2].split(':')
            mucus.data.dump({'sid': sid, 'arl': arl}, 'auth.yaml')
