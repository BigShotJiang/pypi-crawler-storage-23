# Copyright 2026 Gaofeng Fan
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Schematic visualization for analogpy.

This module provides PDF schematic documentation generation from Circuit
and Testbench objects. It creates hierarchical PDF documents with:
- Table of contents with bookmarks
- Block diagrams for testbenches
- Component-level schematics for cells
- Searchable text

Dependencies (install with: pip install analogpy[visualization]):
- schemdraw: MIT license - schematic drawing
- reportlab: BSD license - PDF creation
- pypdf: BSD license - PDF manipulation

Usage:
    from analogpy.visualization import SchematicBook

    book = SchematicBook(title="My Design")
    book.add_testbench(tb)
    book.render("schematic.pdf")
"""

from .book import SchematicBook
from .config import SymbolStyle, LayoutHints, PortType, COLORS, LAYOUT
from .symbols import (
    SymbolRenderer,
    get_default_renderer,
    draw_cell_symbol,
    create_cell_symbol_standalone,
    create_cell_schematic,
    create_testbench_block_diagram,
    create_source_symbol_standalone,
    # Symbol registry
    SYMBOL_REGISTRY,
    get_symbols_by_category,
    get_all_categories,
    generate_symbol_image,
    generate_legend,
)

__all__ = [
    "SchematicBook",
    "SymbolStyle",
    "LayoutHints",
    "PortType",
    "COLORS",
    "LAYOUT",
    "SymbolRenderer",
    "get_default_renderer",
    "draw_cell_symbol",
    "create_cell_symbol_standalone",
    "create_cell_schematic",
    "create_testbench_block_diagram",
    "create_source_symbol_standalone",
    # Symbol registry
    "SYMBOL_REGISTRY",
    "get_symbols_by_category",
    "get_all_categories",
    "generate_symbol_image",
    "generate_legend",
]
