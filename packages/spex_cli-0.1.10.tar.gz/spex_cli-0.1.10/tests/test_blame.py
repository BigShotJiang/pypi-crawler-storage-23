import json
import pytest
import sys
from subprocess import run

from spex_cli.blame import parse_line_intervals, _compact
from spex_cli.constants import DECISION_ID_TRAILER

@pytest.fixture
def temp_spex_env(tmp_path):
    """Setup a temporary .spex directory structure"""
    spex_dir = tmp_path / ".spex"
    memory_dir = spex_dir / "memory"
    memory_dir.mkdir(parents=True)

    # Create empty memory files
    (memory_dir / "requirements.jsonl").touch()
    (memory_dir / "decisions.jsonl").touch()
    (memory_dir / "policies.jsonl").touch()
    (memory_dir / "apps.jsonl").touch()
    (memory_dir / "plans.jsonl").touch()

    # Initialize git repo for blame tests
    run(["git", "init"], cwd=tmp_path, capture_output=True)
    run(["git", "config", "user.email", "test@example.com"], cwd=tmp_path)
    run(["git", "config", "user.name", "test"], cwd=tmp_path)

    return tmp_path

def run_spex(cwd, args):
    """Run spex CLI with args"""
    res = run(["spex"] + args, cwd=cwd, capture_output=True, text=True)
    if res.stderr:
        print(f"SPEX STDERR: {res.stderr}", file=sys.stderr)
    return res

# --- Unit Tests ---

def test_parse_line_intervals():
    assert parse_line_intervals("10") == [(10, 10)]
    assert parse_line_intervals("10-20") == [(10, 20)]
    assert parse_line_intervals("1,5-10,15") == [(1, 1), (5, 10), (15, 15)]
    assert parse_line_intervals("") == []

    with pytest.raises(ValueError):
        parse_line_intervals("abc")


def test_parse_line_intervals_multi_dash():
    # "10-20-30" has two dashes; split('-') yields 3 parts → too many values to unpack
    with pytest.raises(ValueError):
        parse_line_intervals("10-20-30")


def test_parse_line_intervals_empty_comma_part():
    # double comma produces an empty string part → int("") raises ValueError
    with pytest.raises(ValueError):
        parse_line_intervals("1,,2")


def test_parse_line_intervals_reversed_range():
    # No validation that start <= end; the reversed tuple passes through silently
    result = parse_line_intervals("20-10")
    assert result == [(20, 10)]


def test_compact_strips_version_and_status():
    obj = {"id": "D1", "version": 1, "status": "active", "proposal": "Do X"}
    assert _compact(obj) == {"id": "D1", "proposal": "Do X"}


def test_compact_strips_none_values():
    obj = {"id": "D1", "proposal": None, "decisionClass": "tactical"}
    assert _compact(obj) == {"id": "D1", "decisionClass": "tactical"}


def test_compact_strips_empty_lists():
    obj = {"id": "D1", "satisfies": [], "decisionClass": "strategic"}
    assert _compact(obj) == {"id": "D1", "decisionClass": "strategic"}



# --- Integration Tests ---

def test_blame_basic(temp_spex_env):
    memory_dir = temp_spex_env / ".spex/memory"

    # 1. Add Requirement
    req_data = {
        "id": "FR-1", "version": 1, "status": "active",
        "createdAt": "2026-01-01", "author": "test",
        "type": "FR", "description": "Req 1"
    }
    with open(memory_dir / "requirements.jsonl", "w") as f:
        f.write(json.dumps(req_data) + "\n")

    # 2. Add Decision
    dec_data = {
        "id": "D1", "version": 1, "status": "active",
        "createdAt": "2026-01-01", "author": "test",
        "proposal": "Do thing", "decisionClass": "tactical",
        "satisfies": ["FR-1"]
    }
    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps(dec_data) + "\n")

    # 3. Commit with a decision-id trailer — no trace record needed
    app_file = temp_spex_env / "app.py"
    with open(app_file, "w") as f:
        f.write("print('hello')\n")

    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"Initial commit\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    # 4. Run blame
    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    assert res.returncode == 0

    output = json.loads(res.stdout)
    assert len(output) == 1
    assert output[0]["target"] == "app.py:1"
    assert len(output[0]["correlations"]) == 1
    corr = output[0]["correlations"][0]
    assert corr["decision"]["id"] == "D1"
    assert corr["requirements"][0]["id"] == "FR-1"

def test_blame_no_match(temp_spex_env):
    # Commit without a decision-id trailer
    app_file = temp_spex_env / "app.py"
    with open(app_file, "w") as f:
        f.write("print('no match')\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", "No decision trailer"], cwd=temp_spex_env)

    # No correlations because the commit carries no decision-id trailer
    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    output = json.loads(res.stdout)
    assert len(output[0]["correlations"]) == 0

def test_blame_multiple_targets(temp_spex_env):
    memory_dir = temp_spex_env / ".spex/memory"

    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({"id": "D1", "version": 1, "status": "active", "decisionClass": "tactical"}) + "\n")
        f.write(json.dumps({"id": "D2", "version": 1, "status": "active", "decisionClass": "tactical"}) + "\n")

    # Commit a.py with decision-id: D1 trailer
    with open(temp_spex_env / "a.py", "w") as f:
        f.write("a\n")
    run(["git", "add", "a.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"A\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    # Commit b.py with decision-id: D2 trailer
    with open(temp_spex_env / "b.py", "w") as f:
        f.write("b\n")
    run(["git", "add", "b.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"B\n\n{DECISION_ID_TRAILER}: D2"], cwd=temp_spex_env)

    res = run_spex(temp_spex_env, ["blame", "a.py", "b.py"])
    output = json.loads(res.stdout)
    assert len(output) == 2
    assert output[0]["target"] == "a.py"
    assert output[1]["target"] == "b.py"
    assert len(output[0]["correlations"]) == 1
    assert len(output[1]["correlations"]) == 1
    assert output[0]["correlations"][0]["decision"]["id"] == "D1"
    assert output[1]["correlations"][0]["decision"]["id"] == "D2"


def test_blame_deprecated_decision_excluded(temp_spex_env):
    """A commit whose decision-id points to a deprecated decision produces no correlation."""
    memory_dir = temp_spex_env / ".spex/memory"

    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({
            "id": "D-DEPR", "version": 1, "status": "deprecated",
            "decisionClass": "tactical"
        }) + "\n")

    app_file = temp_spex_env / "app.py"
    app_file.write_text("x = 1\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"Deprecated\n\n{DECISION_ID_TRAILER}: D-DEPR"], cwd=temp_spex_env)

    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    output = json.loads(res.stdout)
    assert output[0]["correlations"] == []


def test_blame_latest_version_active_decision(temp_spex_env):
    """When multiple versions exist, the highest-versioned active entry is returned."""
    memory_dir = temp_spex_env / ".spex/memory"

    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({"id": "D1", "version": 1, "status": "active", "proposal": "Old", "decisionClass": "tactical"}) + "\n")
        f.write(json.dumps({"id": "D1", "version": 2, "status": "active", "proposal": "New", "decisionClass": "tactical"}) + "\n")

    app_file = temp_spex_env / "app.py"
    app_file.write_text("x = 1\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"versioned\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    output = json.loads(res.stdout)
    corr = output[0]["correlations"][0]
    # version is stripped by _compact so we verify via proposal
    assert corr["decision"]["proposal"] == "New"


def test_blame_multiple_trailers_on_one_commit(temp_spex_env):
    """A commit with two decision-id trailers produces two correlations."""
    memory_dir = temp_spex_env / ".spex/memory"

    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({"id": "D1", "version": 1, "status": "active", "decisionClass": "tactical"}) + "\n")
        f.write(json.dumps({"id": "D2", "version": 1, "status": "active", "decisionClass": "tactical"}) + "\n")

    app_file = temp_spex_env / "app.py"
    app_file.write_text("x = 1\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(
        ["git", "commit", "-m", f"Multi\n\n{DECISION_ID_TRAILER}: D1\n{DECISION_ID_TRAILER}: D2"],
        cwd=temp_spex_env,
    )

    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    output = json.loads(res.stdout)
    dec_ids = {c["decision"]["id"] for c in output[0]["correlations"]}
    assert dec_ids == {"D1", "D2"}


def test_blame_decision_with_missing_requirement(temp_spex_env):
    """Decision referencing a non-existent requirement produces a correlation without that requirement."""
    memory_dir = temp_spex_env / ".spex/memory"

    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({
            "id": "D1", "version": 1, "status": "active",
            "decisionClass": "tactical", "satisfies": ["FR-MISSING"]
        }) + "\n")
    # requirements.jsonl stays empty

    app_file = temp_spex_env / "app.py"
    app_file.write_text("x = 1\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"Missing req\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    output = json.loads(res.stdout)
    corr = output[0]["correlations"][0]
    assert corr["decision"]["id"] == "D1"
    assert corr["requirements"] == []


def test_blame_decision_no_satisfies_key(temp_spex_env):
    """Decision without 'satisfies' key doesn't crash and produces an empty requirements list."""
    memory_dir = temp_spex_env / ".spex/memory"

    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({
            "id": "D1", "version": 1, "status": "active", "decisionClass": "strategic"
        }) + "\n")

    app_file = temp_spex_env / "app.py"
    app_file.write_text("x = 1\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"No satisfies\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    output = json.loads(res.stdout)
    corr = output[0]["correlations"][0]
    assert corr["requirements"] == []
    assert corr["policies"] == []


def test_blame_nonexistent_file_target(temp_spex_env):
    """Targeting a file that doesn't exist in the repo yields empty correlations without crashing."""
    res = run_spex(temp_spex_env, ["blame", "does_not_exist.py"])
    assert res.returncode == 0
    output = json.loads(res.stdout)
    assert output[0]["correlations"] == []


def test_blame_line_range_outside_file_bounds(temp_spex_env):
    """A line range beyond the file's end causes git blame to fail silently; no correlations returned."""
    memory_dir = temp_spex_env / ".spex/memory"
    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({"id": "D1", "version": 1, "status": "active", "decisionClass": "tactical"}) + "\n")

    app_file = temp_spex_env / "app.py"
    app_file.write_text("x = 1\n")  # only 1 line
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"One line\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    # Lines 100-200 don't exist; git blame should fail, returncode != 0 → empty commits
    res = run_spex(temp_spex_env, ["blame", "app.py:100-200"])
    assert res.returncode == 0
    output = json.loads(res.stdout)
    assert output[0]["correlations"] == []


def test_blame_compact_strips_fields_from_output(temp_spex_env):
    """The output decision object must not contain 'version' or 'status' fields."""
    memory_dir = temp_spex_env / ".spex/memory"
    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({
            "id": "D1", "version": 3, "status": "active",
            "decisionClass": "tactical", "proposal": "Do something"
        }) + "\n")

    app_file = temp_spex_env / "app.py"
    app_file.write_text("x = 1\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"Compact check\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    output = json.loads(res.stdout)
    decision = output[0]["correlations"][0]["decision"]
    assert "version" not in decision
    assert "status" not in decision
    assert decision["id"] == "D1"


def test_blame_shared_decision_across_targets(temp_spex_env):
    """The same decision referenced by two different files both get the correlation."""
    memory_dir = temp_spex_env / ".spex/memory"
    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({"id": "D1", "version": 1, "status": "active", "decisionClass": "tactical"}) + "\n")

    for name in ("a.py", "b.py"):
        (temp_spex_env / name).write_text("x = 1\n")
        run(["git", "add", name], cwd=temp_spex_env)
        run(["git", "commit", "-m", f"Commit {name}\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    res = run_spex(temp_spex_env, ["blame", "a.py", "b.py"])
    output = json.loads(res.stdout)
    assert output[0]["correlations"][0]["decision"]["id"] == "D1"
    assert output[1]["correlations"][0]["decision"]["id"] == "D1"


def test_blame_with_policies(temp_spex_env):  # noqa: keep before dedup tests
    """Decision satisfying a policy surfaces the policy object in the correlation."""
    memory_dir = temp_spex_env / ".spex/memory"

    with open(memory_dir / "policies.jsonl", "w") as f:
        f.write(json.dumps({
            "id": "P1", "version": 1, "status": "active", "title": "Security policy"
        }) + "\n")
    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({
            "id": "D1", "version": 1, "status": "active",
            "decisionClass": "tactical", "satisfiesPolicies": ["P1"]
        }) + "\n")

    app_file = temp_spex_env / "app.py"
    app_file.write_text("x = 1\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"Policy\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    output = json.loads(res.stdout)
    corr = output[0]["correlations"][0]
    assert len(corr["policies"]) == 1
    assert corr["policies"][0]["id"] == "P1"
    assert "version" not in corr["policies"][0]
    assert "status" not in corr["policies"][0]


# --- Deduplication tests ---

def test_blame_decision_deduped_across_commits(temp_spex_env):
    """Same decision-id on two commits → exactly one correlation entry, both hashes present."""
    memory_dir = temp_spex_env / ".spex/memory"
    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({"id": "D1", "version": 1, "status": "active", "decisionClass": "tactical"}) + "\n")

    # First commit: line 1
    app_file = temp_spex_env / "app.py"
    app_file.write_text("line1\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"First\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    # Second commit: add line 2 — now two different commits touch the file, both tagged D1
    app_file.write_text("line1\nline2\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"Second\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    # Blame the full range — git blame returns two lines, each owned by a different commit
    res = run_spex(temp_spex_env, ["blame", "app.py:1-2"])
    output = json.loads(res.stdout)
    correlations = output[0]["correlations"]

    # D1 must appear exactly once
    decision_ids = [c["decision"]["id"] for c in correlations]
    assert decision_ids.count("D1") == 1

    # Both commit hashes must be collected into the single entry
    assert len(correlations[0]["commitHashes"]) == 2


def test_blame_requirement_not_duplicated_within_decision(temp_spex_env):
    """If a decision's 'satisfies' list contains FR-1 twice, FR-1 must appear only once in output."""
    memory_dir = temp_spex_env / ".spex/memory"
    with open(memory_dir / "requirements.jsonl", "w") as f:
        f.write(json.dumps({"id": "FR-1", "version": 1, "status": "active", "type": "FR", "description": "R1"}) + "\n")
    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({
            "id": "D1", "version": 1, "status": "active",
            "decisionClass": "tactical", "satisfies": ["FR-1", "FR-1"]  # duplicate
        }) + "\n")

    app_file = temp_spex_env / "app.py"
    app_file.write_text("x = 1\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"Dup req\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    output = json.loads(res.stdout)
    req_ids = [r["id"] for r in output[0]["correlations"][0]["requirements"]]
    assert req_ids.count("FR-1") == 1, f"FR-1 appeared {req_ids.count('FR-1')} times, expected 1"


def test_blame_policy_not_duplicated_within_decision(temp_spex_env):
    """If a decision's 'satisfiesPolicies' contains P1 twice, P1 must appear only once in output."""
    memory_dir = temp_spex_env / ".spex/memory"
    with open(memory_dir / "policies.jsonl", "w") as f:
        f.write(json.dumps({"id": "P1", "version": 1, "status": "active", "title": "Sec"}) + "\n")
    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({
            "id": "D1", "version": 1, "status": "active",
            "decisionClass": "tactical", "satisfiesPolicies": ["P1", "P1"]  # duplicate
        }) + "\n")

    app_file = temp_spex_env / "app.py"
    app_file.write_text("x = 1\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"Dup pol\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    output = json.loads(res.stdout)
    pol_ids = [p["id"] for p in output[0]["correlations"][0]["policies"]]
    assert pol_ids.count("P1") == 1, f"P1 appeared {pol_ids.count('P1')} times, expected 1"


def test_blame_requirement_shared_across_decisions_appears_once_each(temp_spex_env):
    """FR-1 referenced by both D1 and D2 appears in each decision's requirements — but only once in each."""
    memory_dir = temp_spex_env / ".spex/memory"
    with open(memory_dir / "requirements.jsonl", "w") as f:
        f.write(json.dumps({"id": "FR-1", "version": 1, "status": "active", "type": "FR", "description": "R1"}) + "\n")
    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({"id": "D1", "version": 1, "status": "active", "decisionClass": "tactical", "satisfies": ["FR-1"]}) + "\n")
        f.write(json.dumps({"id": "D2", "version": 1, "status": "active", "decisionClass": "tactical", "satisfies": ["FR-1"]}) + "\n")

    app_file = temp_spex_env / "app.py"
    app_file.write_text("line1\nline2\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"D1 commit\n\n{DECISION_ID_TRAILER}: D1\n{DECISION_ID_TRAILER}: D2"], cwd=temp_spex_env)

    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    output = json.loads(res.stdout)
    correlations = output[0]["correlations"]

    # Two decisions, each has FR-1 exactly once in their own requirements list
    assert len(correlations) == 2
    for corr in correlations:
        req_ids = [r["id"] for r in corr["requirements"]]
        assert req_ids.count("FR-1") == 1


# --- Noise-line filtering tests ---

def test_is_noise_line_unit():
    """Unit tests for _is_noise_line across extensions, content types, and edge cases."""
    from spex_cli.blame import _is_noise_line

    # Empty lines are always noise
    assert _is_noise_line("", ".py") is True
    assert _is_noise_line("   ", ".py") is True
    assert _is_noise_line("\t", ".ts") is True
    assert _is_noise_line("", "") is True

    # Python
    assert _is_noise_line("import os", ".py") is True
    assert _is_noise_line("  import os", ".py") is True        # leading whitespace stripped
    assert _is_noise_line("from os import path", ".py") is True
    assert _is_noise_line("x = 1", ".py") is False
    assert _is_noise_line("# import os", ".py") is False       # comment, not an import

    # TypeScript
    assert _is_noise_line("import React from 'react'", ".tsx") is True
    assert _is_noise_line("require('lodash')", ".ts") is True
    assert _is_noise_line("const x = 1", ".ts") is False

    # Go
    assert _is_noise_line('import "fmt"', ".go") is True
    assert _is_noise_line("func main() {}", ".go") is False

    # Rust
    assert _is_noise_line("use std::collections::HashMap;", ".rs") is True
    assert _is_noise_line("fn main() {}", ".rs") is False

    # C / C++
    assert _is_noise_line("#include <stdio.h>", ".c") is True
    assert _is_noise_line('#include "myheader.h"', ".cpp") is True
    assert _is_noise_line("int main() {}", ".c") is False

    # PHP
    assert _is_noise_line("use App\\Models\\User;", ".php") is True
    assert _is_noise_line("require('config.php')", ".php") is True
    assert _is_noise_line("include_once('helpers.php')", ".php") is True
    assert _is_noise_line("echo 'hello';", ".php") is False

    # Swift
    assert _is_noise_line("import Foundation", ".swift") is True
    assert _is_noise_line("let x = 1", ".swift") is False

    # Unknown extension: only empty-line filtering, no import filtering
    assert _is_noise_line("import something", ".xyz") is False
    assert _is_noise_line("", ".xyz") is True


def test_blame_import_only_commit_not_surfaced(temp_spex_env):
    """A commit that adds only an import line must not appear in correlations.

    Commit A adds 'import os' (tagged D1). Commit B adds 'def foo(): pass'
    (no trailer). Blaming line 1 (the import) must yield no correlations.
    """
    memory_dir = temp_spex_env / ".spex/memory"
    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({
            "id": "D1", "version": 1, "status": "active", "decisionClass": "tactical"
        }) + "\n")

    app_file = temp_spex_env / "app.py"

    # Commit A: import only, tagged D1
    app_file.write_text("import os\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"Add import\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    # Commit B: add meaningful code, no trailer
    app_file.write_text("import os\ndef foo(): pass\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", "Add foo"], cwd=temp_spex_env)

    # Blame only line 1 — owned by commit A (the import)
    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    output = json.loads(res.stdout)
    assert output[0]["correlations"] == []


def test_blame_empty_line_commit_not_surfaced(temp_spex_env):
    """A commit that adds only a blank line must not appear in correlations."""
    memory_dir = temp_spex_env / ".spex/memory"
    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({
            "id": "D1", "version": 1, "status": "active", "decisionClass": "tactical"
        }) + "\n")

    app_file = temp_spex_env / "app.py"

    # Commit A: blank line only, tagged D1
    app_file.write_text("\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"Add blank\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    # Commit B: add meaningful code, no trailer
    app_file.write_text("\nx = 1\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", "Add x"], cwd=temp_spex_env)

    # Blame only line 1 — the blank line owned by commit A
    res = run_spex(temp_spex_env, ["blame", "app.py:1"])
    output = json.loads(res.stdout)
    assert output[0]["correlations"] == []


def test_blame_mixed_commit_still_surfaced(temp_spex_env):
    """A commit adding both an import and meaningful code must still be surfaced.

    The import line is filtered, but the meaningful line brings the same
    commit hash in — so the decision still correlates.
    """
    memory_dir = temp_spex_env / ".spex/memory"
    with open(memory_dir / "decisions.jsonl", "w") as f:
        f.write(json.dumps({
            "id": "D1", "version": 1, "status": "active", "decisionClass": "tactical"
        }) + "\n")

    app_file = temp_spex_env / "app.py"
    app_file.write_text("import os\nx = 1\n")
    run(["git", "add", "app.py"], cwd=temp_spex_env)
    run(["git", "commit", "-m", f"Mixed commit\n\n{DECISION_ID_TRAILER}: D1"], cwd=temp_spex_env)

    # Blame both lines — line 1 is noise but line 2 is meaningful
    res = run_spex(temp_spex_env, ["blame", "app.py:1-2"])
    output = json.loads(res.stdout)
    assert len(output[0]["correlations"]) == 1
    assert output[0]["correlations"][0]["decision"]["id"] == "D1"
