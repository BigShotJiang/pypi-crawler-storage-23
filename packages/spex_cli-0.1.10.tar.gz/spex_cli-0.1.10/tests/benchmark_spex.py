import time
import subprocess
import shutil
from pathlib import Path
import sys

SPEX_PATH = Path(".spex/scripts/spex.py").absolute()

def setup_benchmark_env(root_dir):
    spex_dir = root_dir / ".spex"
    memory_dir = spex_dir / "memory"
    memory_dir.mkdir(parents=True, exist_ok=True)
    
    for f in ["requirements.jsonl", "decisions.jsonl", "plans.jsonl", "traces.jsonl"]:
        (memory_dir / f).touch()
    return root_dir

def run_spex(cwd, args):
    cmd = [sys.executable, str(SPEX_PATH)] + args
    start = time.perf_counter()
    subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return time.perf_counter() - start

def benchmark_bulk_add(env_dir, count=1000):
    print(f"\n--- Benchmarking Bulk Add ({count} entries) ---")
    
    # 1. Add count requirements
    start_total = time.perf_counter()
    for i in range(count):
        run_spex(env_dir, [
            "requirement", "add",
            "--plan-id", "P-BENCH",
            "--type", "FR",
            "--description", f"Perf test req {i}",
            "--source", "bench",
            "--priority", "must-have",
            "--acceptance-criteria", "C"
        ])
    end_total = time.perf_counter()
    avg = (end_total - start_total) / count
    print(f"Total time for {count} requirements: {end_total - start_total:.2f}s")
    print(f"Average time per 'add': {avg*1000:.2f}ms")

    # 2. Add 1 decision (measures ID generation and file reading overhead)
    print("\n--- Measuring single 'add' with large file ---")
    duration = run_spex(env_dir, [
        "decision", "add",
        "--plan-id", "P-BENCH",
        "--proposal", "P",
        "--rationale", "R",
        "--alternatives", "A",
        "--satisfies", f"FR-{count:03d}",
        "--impact", "I"
    ])
    print(f"Decision add (with {count} existing reqs): {duration*1000:.2f}ms")

def main():
    root = Path("benchmark_tmp")
    if root.exists():
        shutil.rmtree(root)
    root.mkdir()
    
    try:
        env = setup_benchmark_env(root)
        
        # Test 100 entries
        benchmark_bulk_add(env, 100)
        
        # Test 1000 entries (if it's reasonably fast)
        benchmark_bulk_add(env, 1000)
        
    finally:
        shutil.rmtree(root)

if __name__ == "__main__":
    main()
