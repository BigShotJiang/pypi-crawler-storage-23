import json
import subprocess
import pytest


@pytest.fixture
def temp_spex_env(tmp_path):
    """Setup a temporary .spex directory structure"""
    spex_dir = tmp_path / ".spex"
    memory_dir = spex_dir / "memory"
    memory_dir.mkdir(parents=True)
    
    # Files
    req_file = memory_dir / "requirements.jsonl"
    dec_file = memory_dir / "decisions.jsonl"
    plan_file = memory_dir / "plans.jsonl"
    trace_file = memory_dir / "traces.jsonl"
    
    for f in [req_file, dec_file, plan_file, trace_file]:
        f.touch()
        
    # Set environment or change CWD for the script to pick up these paths
    # However, spex.py has hardcoded relative paths like ".spex/memory/..."
    # So we must run commands from the tmp_path
    return tmp_path

def run_spex(cwd, args):
    """Run spex CLI with args"""
    return subprocess.run(["spex"] + args, cwd=cwd, capture_output=True, text=True)

def test_requirement_add(temp_spex_env):
    res = run_spex(temp_spex_env, [
        "requirement", "add",
        "--plan-id", "P-1",
        "--type", "FR",
        "--description", "Test Req",
        "--source", "User",
        "--acceptance-criteria", "Criteria A"
    ])
    assert res.returncode == 0
    assert "✓ Added requirement FR-" in res.stdout
    
    # Extract ID from stdout
    req_id = res.stdout.split("Added requirement ")[1].split(" ")[0]
    
    # Verify file content
    req_file = temp_spex_env / ".spex/memory/requirements.jsonl"
    lines = req_file.read_text().strip().split('\n')
    assert len(lines) == 1
    data = json.loads(lines[0])
    assert data['id'] == req_id
    assert data['type'] == "FR"

def test_requirement_invalid_type(temp_spex_env):
    res = run_spex(temp_spex_env, [
        "requirement", "add",
        "--plan-id", "P-1",
        "--type", "INVALID",
        "--description", "Test",
        "--source", "User",
        "--acceptance-criteria", "Criteria"
    ])
    assert res.returncode != 0
    assert "invalid choice" in res.stderr

def test_decision_add(temp_spex_env):
    # First add a requirement to satisfy
    req_res = run_spex(temp_spex_env, [
        "requirement", "add", "--plan-id", "P-1", "--type", "FR",
        "--description", "R1", "--source", "U", "--acceptance-criteria", "C"
    ])
    req_id = req_res.stdout.split("Added requirement ")[1].split(" ")[0]
    
    res = run_spex(temp_spex_env, [
        "decision", "add",
        "--proposal", "Test Deco",
        "--rationale", "Because",
        "--alternatives", "None",
        "--satisfies", req_id,
        "--impact", '{"file": "main.py"}',
        "--decision-class", "tactical"
    ])
    assert res.returncode == 0
    assert "decision D" in res.stdout
    
    # Extract ID from stdout - format: "Added TACTICAL decision D-<uuid> (v1)"
    dec_id = res.stdout.split("decision ")[1].split(" ")[0]
    
    dec_file = temp_spex_env / ".spex/memory/decisions.jsonl"
    data = json.loads(dec_file.read_text().strip())
    assert data['id'] == dec_id
    assert data['satisfies'] == [req_id]

def test_decision_missing_requirement(temp_spex_env):
    res = run_spex(temp_spex_env, [
        "decision", "add",
        "--proposal", "Test",
        "--rationale", "R",
        "--alternatives", "A",
        "--satisfies", "NON-EXISTENT",
        "--impact", "I",
        "--decision-class", "tactical"
    ])
    assert res.returncode != 0
    assert "Error: Requirement 'NON-EXISTENT' does not exist" in res.stderr

def test_plan_add_and_update(temp_spex_env):
    # Add plan
    res = run_spex(temp_spex_env, ["plan", "add", "--feature-name", "F1", "--goal", "G1"])
    assert res.returncode == 0
    plan_id = res.stdout.split("Added plan ")[1].split(" ")[0]
    
    # Update status
    res = run_spex(temp_spex_env, ["plan", "update-status", "--id", plan_id, "--status", "approved"])
    assert res.returncode == 0
    assert "status: draft → approved" in res.stdout

def test_requirement_deprecate(temp_spex_env):
    req_res = run_spex(temp_spex_env, [
        "requirement", "add", "--plan-id", "P-1", "--type", "FR",
        "--description", "R1", "--source", "U", "--acceptance-criteria", "C"
    ])
    req_id = req_res.stdout.split("Added requirement ")[1].split(" ")[0]
    
    res = run_spex(temp_spex_env, [
        "requirement", "deprecate", "--id", req_id, "--reason", "No longer needed"
    ])
    assert res.returncode == 0
    assert f"✓ Deprecated requirement {req_id}" in res.stdout
    
    req_file = temp_spex_env / ".spex/memory/requirements.jsonl"
    lines = req_file.read_text().strip().split('\n')
    assert len(lines) == 2
    latest = json.loads(lines[1])
    assert latest['status'] == 'deprecated'
    assert latest['version'] == 2
    assert latest['deprecatedReason'] == "No longer needed"

def test_decision_deprecate(temp_spex_env):
    req_res = run_spex(temp_spex_env, ["requirement", "add", "--plan-id", "P-1", "--type", "FR", "--description", "R1", "--source", "U", "--acceptance-criteria", "C"])
    req_id = req_res.stdout.split("Added requirement ")[1].split(" ")[0]
    
    dec_res = run_spex(temp_spex_env, ["decision", "add", "--proposal", "P", "--rationale", "R", "--alternatives", "A", "--satisfies", req_id, "--impact", "I", "--decision-class", "tactical"])
    dec_id = dec_res.stdout.split("decision ")[1].split(" ")[0]
    
    res = run_spex(temp_spex_env, [
        "decision", "deprecate", "--id", dec_id, "--reason", "Obsolete approach"
    ])
    assert res.returncode == 0
    assert f"✓ Deprecated decision {dec_id}" in res.stdout
    
    dec_file = temp_spex_env / ".spex/memory/decisions.jsonl"
    lines = dec_file.read_text().strip().split('\n')
    latest = json.loads(lines[-1])
    assert latest['status'] == 'obsolete'
    assert latest['version'] == 2

def test_plan_deprecate(temp_spex_env):
    run_spex(temp_spex_env, ["plan", "add", "--feature-name", "F1", "--goal", "G1"])
    # We need to find the plan ID
    plan_file = temp_spex_env / ".spex/memory/plans.jsonl"
    plan_id = json.loads(plan_file.read_text().strip())['id']
    
    res = run_spex(temp_spex_env, ["plan", "deprecate", "--id", plan_id, "--reason", "Cancelled"])
    assert res.returncode == 0
    assert f"✓ Abandoned plan {plan_id}" in res.stdout
    
    lines = plan_file.read_text().strip().split('\n')
    latest = json.loads(lines[-1])
    assert latest['status'] == 'abandoned'

def test_orphaned_reference_warning(temp_spex_env):
    req_res = run_spex(temp_spex_env, ["requirement", "add", "--plan-id", "P-1", "--type", "FR", "--description", "R1", "--source", "U", "--acceptance-criteria", "C"])
    req_id = req_res.stdout.split("Added requirement ")[1].split(" ")[0]
    
    dec_res = run_spex(temp_spex_env, ["decision", "add", "--proposal", "P", "--rationale", "R", "--alternatives", "A", "--satisfies", req_id, "--impact", "I", "--decision-class", "tactical"])
    dec_id = dec_res.stdout.split("decision ")[1].split(" ")[0]
    
    res = run_spex(temp_spex_env, [
        "requirement", "deprecate", "--id", req_id, "--reason", "Warning test"
    ])
    assert res.returncode == 0
    assert f"⚠ Warning: Decision {dec_id} still references {req_id}" in res.stderr

def test_plan_update_status_extended(temp_spex_env):
    run_spex(temp_spex_env, ["plan", "add", "--feature-name", "F1", "--goal", "G1"])
    plan_file = temp_spex_env / ".spex/memory/plans.jsonl"
    plan_id = json.loads(plan_file.read_text().strip())['id']
    
    # Approve
    run_spex(temp_spex_env, ["plan", "update-status", "--id", plan_id, "--status", "approved"])
    # Complete
    run_spex(temp_spex_env, ["plan", "update-status", "--id", plan_id, "--status", "complete"])
    
    lines = plan_file.read_text().strip().split('\n')
    latest = json.loads(lines[-1])
    assert latest['status'] == 'complete'
    assert latest['approvedAt'] is not None
    assert latest['completedAt'] is not None

def test_deprecate_updates_all_versions_requirement(temp_spex_env):
    """Deprecating a requirement should mark ALL prior versions as deprecated"""
    req_file = temp_spex_env / ".spex/memory/requirements.jsonl"
    # Seed v1 and v2 of FR-001 (simulating a prior deprecate that only appended)
    with open(req_file, 'w') as f:
        f.write(json.dumps({'id': 'FR-001', 'version': 1, 'status': 'active', 'planId': 'P-1', 'type': 'FR', 'description': 'Original', 'source': 'U', 'acceptanceCriteria': 'C', 'createdAt': '2026-01-01', 'author': 'test'}) + '\n')
        f.write(json.dumps({'id': 'FR-001', 'version': 2, 'status': 'active', 'planId': 'P-1', 'type': 'FR', 'description': 'Updated', 'source': 'U', 'acceptanceCriteria': 'C', 'createdAt': '2026-01-02', 'author': 'test'}) + '\n')
        f.write(json.dumps({'id': 'FR-002', 'version': 1, 'status': 'active', 'planId': 'P-1', 'type': 'FR', 'description': 'Other', 'source': 'U', 'acceptanceCriteria': 'C', 'createdAt': '2026-01-01', 'author': 'test'}) + '\n')

    res = run_spex(temp_spex_env, [
        "requirement", "deprecate", "--id", "FR-001", "--reason", "Superseded", "--superseded-by", "FR-002"
    ])
    assert res.returncode == 0

    lines = req_file.read_text().strip().split('\n')
    entries = [json.loads(line) for line in lines]


    # ALL versions of FR-001 should be deprecated
    for e in entries:
        if e['id'] == 'FR-001':
            assert e['status'] == 'deprecated', f"FR-001 v{e['version']} should be deprecated"
            assert e['deprecatedReason'] == 'Superseded'
            assert e['supersededBy'] == 'FR-002'

    # FR-002 should remain active
    fr002 = [e for e in entries if e['id'] == 'FR-002']
    assert fr002[0]['status'] == 'active'


def test_deprecate_updates_all_versions_decision(temp_spex_env):
    """Deprecating a decision should mark ALL prior versions as obsolete"""
    req_file = temp_spex_env / ".spex/memory/requirements.jsonl"
    dec_file = temp_spex_env / ".spex/memory/decisions.jsonl"
    # Need a requirement for reference validation
    with open(req_file, 'w') as f:
        f.write(json.dumps({'id': 'FR-001', 'version': 1, 'status': 'active', 'planId': 'P-1', 'type': 'FR', 'description': 'R', 'source': 'U', 'acceptanceCriteria': 'C', 'createdAt': '2026-01-01', 'author': 'test'}) + '\n')
    # Seed v1 and v2 of D1
    with open(dec_file, 'w') as f:
        f.write(json.dumps({'id': 'D1', 'version': 1, 'status': 'active', 'proposal': 'P', 'rationale': 'R', 'alternatives': 'A', 'satisfies': ['FR-001'], 'satisfiesPolicies': [], 'impact': 'I', 'decisionClass': 'tactical', 'createdAt': '2026-01-01', 'author': 'test'}) + '\n')
        f.write(json.dumps({'id': 'D1', 'version': 2, 'status': 'active', 'proposal': 'P2', 'rationale': 'R', 'alternatives': 'A', 'satisfies': ['FR-001'], 'satisfiesPolicies': [], 'impact': 'I', 'decisionClass': 'tactical', 'createdAt': '2026-01-02', 'author': 'test'}) + '\n')
        f.write(json.dumps({'id': 'D2', 'version': 1, 'status': 'active', 'proposal': 'Other', 'rationale': 'R', 'alternatives': 'A', 'satisfies': ['FR-001'], 'satisfiesPolicies': [], 'impact': 'I', 'decisionClass': 'tactical', 'createdAt': '2026-01-01', 'author': 'test'}) + '\n')

    res = run_spex(temp_spex_env, [
        "decision", "deprecate", "--id", "D1", "--reason", "Replaced", "--superseded-by", "D2"
    ])
    assert res.returncode == 0

    lines = dec_file.read_text().strip().split('\n')
    entries = [json.loads(line) for line in lines]


    # ALL versions of D1 should be obsolete
    for e in entries:
        if e['id'] == 'D1':
            assert e['status'] == 'obsolete', f"D1 v{e['version']} should be obsolete"
            assert e['obsoleteReason'] == 'Replaced'
            assert e['supersededBy'] == 'D2'

    # D2 should remain active
    d2 = [e for e in entries if e['id'] == 'D2']
    assert d2[0]['status'] == 'active'


def test_trace_add_multi(temp_spex_env):
    """Test adding multiple commits to the same decision ID"""
    # 1. Add first commit
    run_spex(temp_spex_env, ["trace", "add", "--decision-id", "D1", "--commit-hash", "hash1"])
    
    # 2. Add second commit to same decision
    res = run_spex(temp_spex_env, ["trace", "add", "--decision-id", "D1", "--commit-hash", "hash2"])
    assert res.returncode == 0
    assert "Appended Commit hash2 to D1" in res.stdout
    
    # 3. Verify trace file
    trace_file = temp_spex_env / ".spex/memory/traces.jsonl"
    lines = trace_file.read_text().strip().split('\n')
    assert len(lines) == 2 # v1 and v2
    latest = json.loads(lines[-1])
    assert latest['decisionId'] == "D1"
    assert latest['commitHashes'] == ["hash1", "hash2"]
    assert latest['version'] == 2

def test_trace_add_duplicate(temp_spex_env):
    """Test adding the same commit twice to the same decision ID"""
    run_spex(temp_spex_env, ["trace", "add", "--decision-id", "D1", "--commit-hash", "hash1"])
    res = run_spex(temp_spex_env, ["trace", "add", "--decision-id", "D1", "--commit-hash", "hash1"])
    assert res.returncode == 0
    assert "⚠ Commit hash1 already traced to D1" in res.stdout
