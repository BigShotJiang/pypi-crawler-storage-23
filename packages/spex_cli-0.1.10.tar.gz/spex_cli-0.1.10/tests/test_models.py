from spex_cli.models import Requirement, Decision, Policy

def test_requirement_scope():
    req_data = {
        "id": "R-001",
        "version": 1,
        "status": "active",
        "createdAt": "2026-02-10T00:00:00Z",
        "author": "tester",
        "type": "FR",
        "description": "Functional requirement",
        "scope": ["app1", "app2"]
    }
    
    req = Requirement.from_dict(req_data)
    assert req.scope == ["app1", "app2"]
    
    # Check default
    req_data.pop("scope")
    req_default = Requirement.from_dict(req_data)
    assert req_default.scope == []

def test_decision_scope():
    dec_data = {
        "id": "D-001",
        "version": 1,
        "status": "active",
        "createdAt": "2026-02-10T00:00:00Z",
        "author": "tester",
        "decisionClass": "architectural",
        "proposal": "New architecture",
        "scope": ["core"]
    }
    
    dec = Decision.from_dict(dec_data)
    assert dec.scope == ["core"]
    
    # Check default
    dec_data.pop("scope")
    dec_default = Decision.from_dict(dec_data)
    assert dec_default.scope == []

def test_policy_scope():
    pol_data = {
        "id": "P-001",
        "version": 1,
        "status": "active",
        "createdAt": "2026-02-10T00:00:00Z",
        "author": "tester",
        "description": "Project policy",
        "scope": ["global"]
    }
    
    pol = Policy.from_dict(pol_data)
    assert pol.scope == ["global"]
    
    # Check default
    pol_data.pop("scope")
    pol_default = Policy.from_dict(pol_data)
    assert pol_default.scope == []

def test_to_dict_includes_scope():
    pol = Policy(
        id="P-001",
        version=1,
        status="active",
        createdAt="2026-02-10T00:00:00Z",
        author="tester",
        description="test",
        scope=["app1"]
    )
    d = pol.to_dict()
    assert "scope" in d
    assert d["scope"] == ["app1"]
