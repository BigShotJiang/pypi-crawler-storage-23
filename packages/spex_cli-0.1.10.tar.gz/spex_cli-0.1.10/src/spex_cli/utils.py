"""Shared utilities and error types for spex."""

import json
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional


class SpexError(Exception):
    """Base exception for spex errors."""


class ValidationError(SpexError):
    """Validation error."""


class ReferenceError(SpexError):
    """Reference integrity error."""


def run_jq(query: str, filepath: str) -> List[Dict[str, Any]]:
    """Run a jq query on a JSONL file and return parsed results."""
    if not Path(filepath).exists():
        return []
    try:
        result = subprocess.run(
            ['jq', '-c', query, filepath],
            capture_output=True,
            text=True,
            check=True,
        )
        return [json.loads(line) for line in result.stdout.splitlines() if line.strip()]
    except subprocess.CalledProcessError:
        return []
    except json.JSONDecodeError:
        return []


def get_latest_active_jq(entry_id: str, filepath: str) -> Optional[Dict[str, Any]]:
    """Return the latest active version of an entry by ID using jq."""
    query = f'select(.id == "{entry_id}" and (.status == "active" or .status == null))'
    entries = run_jq(query, filepath)
    if not entries:
        return None
    return max(entries, key=lambda e: e.get('version', 1))


def get_latest_jq(entry_id: str, filepath: str) -> Optional[Dict[str, Any]]:
    """Return the latest version of an entry by ID using jq (no status filter).

    Use for entity types whose statuses differ from 'active', e.g. plans
    (draft / approved / complete / abandoned).
    """
    query = f'select(.id == "{entry_id}")'
    entries = run_jq(query, filepath)
    if not entries:
        return None
    return max(entries, key=lambda e: e.get('version', 1))
