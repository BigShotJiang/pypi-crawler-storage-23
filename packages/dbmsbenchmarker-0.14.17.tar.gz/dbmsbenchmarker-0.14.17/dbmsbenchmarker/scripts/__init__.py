"""
The dbmsbenchmarker scripts
"""
__all__ = ["cli","dashboardcli","inspect"]
from .__version__ import __version__
