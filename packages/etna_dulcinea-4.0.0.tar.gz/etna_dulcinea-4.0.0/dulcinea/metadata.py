from importlib.metadata import version

__version__ = version("etna-dulcinea")
