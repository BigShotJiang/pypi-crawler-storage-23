import json
import os
import threading

_CACHE = None
_LOCK = threading.Lock()
_FETCHED = False

def _try_fetch_remote():
    global _CACHE, _FETCHED
    if _FETCHED:
        return
    try:
        import requests
        url = "https://coreupdates.meyankut.workers.dev/nowfycore_translations.pack.json"
        resp = requests.get(url, timeout=6)
        if resp.status_code == 200:
            data = resp.json()
            if isinstance(data, dict) and data:
                _CACHE = data
                _FETCHED = True
                return
    except Exception:
        pass
    _FETCHED = True

def _try_load_embedded():
    global _CACHE
    if _CACHE:
        return
    try:
        import importlib.resources as ir
        with ir.open_text("nowfycore", "nowfycore_translations.pack.json", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, dict) and data:
                _CACHE = data
                return
    except Exception:
        pass
    # Fallback: look up relative file next to this module (dev environment)
    try:
        here = os.path.dirname(__file__)
        fp = os.path.join(here, "nowfycore_translations.pack.json")
        if os.path.isfile(fp):
            with open(fp, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict) and data:
                    _CACHE = data
    except Exception:
        pass

def get_nowfy_translations():
    """Returns the Nowfy translations pack.

    Order:
    - Use embedded JSON if present in the package.
    - Otherwise, best-effort remote fetch with short timeout.
    - Fallback to empty dict.
    """
    global _CACHE
    with _LOCK:
        if not _CACHE:
            _try_load_embedded()
        if not _CACHE:
            _try_fetch_remote()
        return _CACHE or {}
