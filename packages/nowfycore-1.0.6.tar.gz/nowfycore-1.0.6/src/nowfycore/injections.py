def _safe_text(plugin, item):
    try:
        if hasattr(plugin, "_get_uitem_text"):
            return str(plugin._get_uitem_text(item) or "").strip().lower()
    except Exception:
        pass
    try:
        si = getattr(item, "settingItem", None)
        return str(getattr(si, "text", "") or "").strip().lower() if si else ""
    except Exception:
        return ""


def _safe_key(plugin, item):
    try:
        if hasattr(plugin, "_get_uitem_setting_key"):
            return str(plugin._get_uitem_setting_key(item) or "").strip()
    except Exception:
        pass
    try:
        return str(getattr(item, "settingKey", "") or "").strip()
    except Exception:
        return ""


def _safe_link_alias(item):
    try:
        la = str(getattr(item, "link_alias", "") or "").strip()
        if la:
            return la
        si = getattr(item, "settingItem", None)
        return str(getattr(si, "link_alias", "") or "").strip() if si else ""
    except Exception:
        return ""


def _safe_cb_name(item):
    try:
        cb = (
            getattr(item, "create_sub_fragment", None)
            or getattr(item, "createSubFragment", None)
            or getattr(item, "on_click", None)
            or getattr(item, "onClick", None)
            or getattr(item, "callback", None)
        )
        si = getattr(item, "settingItem", None)
        if cb is None and si is not None:
            cb = (
                getattr(si, "create_sub_fragment", None)
                or getattr(si, "createSubFragment", None)
                or getattr(si, "on_click", None)
                or getattr(si, "onClick", None)
                or getattr(si, "callback", None)
            )
        return str(getattr(cb, "__name__", "") or "").strip()
    except Exception:
        return ""


def inject_services_cards_custom(plugin, activity, items):
    """Compatibility injector: keep native rows, but register open-item map."""
    try:
        service_item_map = {}
        for i in range(items.size()):
            try:
                it = items.get(i)
                marker = str(getattr(it, "object2", "") or "")
                if marker == "__services_custom_cards__":
                    continue
                key = _safe_key(plugin, it)
                txt = _safe_text(plugin, it).replace(" ", "").replace(".", "")
                if key:
                    if key in ("nowfy_services_spotify", "nowfy_services_lastfm", "nowfy_services_statsfm"):
                        service_item_map[key] = it
                if "spotify" in txt:
                    service_item_map["spotify"] = it
                    service_item_map.setdefault("nowfy_services_spotify", it)
                elif "lastfm" in txt:
                    service_item_map["lastfm"] = it
                    service_item_map.setdefault("nowfy_services_lastfm", it)
                elif "statsfm" in txt:
                    service_item_map["statsfm"] = it
                    service_item_map.setdefault("nowfy_services_statsfm", it)
            except Exception:
                pass
        try:
            setattr(plugin, "_services_open_item_map", service_item_map)
        except Exception:
            pass
        return True
    except Exception:
        return False


def inject_home_services_entry_custom(plugin, activity, items):
    """Compatibility injector: keep native rows, but register home open-item map."""
    try:
        home_item_map = {}
        for i in range(items.size()):
            try:
                it = items.get(i)
                marker = str(getattr(it, "object2", "") or "")
                if marker in (
                    "__home_services_custom_entry__",
                    "__home_feature_cards_custom_entry__",
                    "__home_tail_cards_custom_entry__",
                    "__home_dotted_custom__",
                    "__home_about_custom__",
                    "__home_meta_custom__",
                ):
                    continue
                key = _safe_key(plugin, it)
                la = _safe_link_alias(it)
                txt = _safe_text(plugin, it)
                cb_name = _safe_cb_name(it)

                def _reg(slot):
                    home_item_map[slot] = it
                    if key:
                        home_item_map[key] = it
                    if la:
                        home_item_map[la] = it

                if key == "nowfy_home_services" or la == "nowfy_home_services" or cb_name == "create_services_subfragment":
                    _reg("nowfy_home_services")
                elif key == "nowfy_home_panel" or la == "nowfy_home_panel" or cb_name in ("create_nowfy_panel_subfragment", "create_core_subfragment"):
                    _reg("nowfy_home_panel")
                elif key == "nowfy_home_lab" or la == "nowfy_home_lab" or cb_name == "create_nowfy_lab_subfragment":
                    _reg("nowfy_home_lab")
                elif key == "nowfy_home_extended" or la == "nowfy_home_extended" or cb_name == "create_extended_subfragment":
                    _reg("nowfy_home_extended")
                elif key == "nowfy_home_themes" or la == "nowfy_home_themes" or cb_name == "create_themes_subfragment":
                    _reg("nowfy_home_themes")
                elif key == "nowfy_credit_dotted" or la == "nowfy_credit_dotted" or txt == "dotted plugins":
                    _reg("nowfy_credit_dotted")
                elif key == "nowfy_about_subfragment" or la == "nowfy_about_subfragment" or cb_name == "create_about_plugin_subfragment" or txt == "nowfy":
                    _reg("nowfy_about_subfragment")
            except Exception:
                pass
        try:
            setattr(plugin, "_home_open_item_map", home_item_map)
        except Exception:
            pass
        return True
    except Exception:
        return False


def inject_statsfm_profile_custom(plugin, activity, items):
    """Compatibility injector for StatsFM view rules without custom card rendering."""
    try:
        statsfm_user = str(plugin.get_setting("statsfm_username", "") or "").strip().lower().lstrip("@")
        statsfm_top_native_item = None
        remove_indices = []
        for i in range(items.size()):
            try:
                it = items.get(i)
                marker = str(getattr(it, "object2", "") or "")
                if marker in (
                    "__statsfm_profile_custom__",
                    "__statsfm_recent_blobs_custom__",
                    "__statsfm_logout_text_item__",
                    "__statsfm_top_tracks_custom__",
                    "__statsfm_top_genres_custom__",
                    "__statsfm_top_blocks_divider__",
                ):
                    remove_indices.append(i)
                    continue
                key = _safe_key(plugin, it)
                txt = _safe_text(plugin, it)
                if key == "nowfy_services_statsfm_top" or txt in ("statsfm top", "stats"):
                    statsfm_top_native_item = it
                    if not statsfm_user:
                        remove_indices.append(i)
            except Exception:
                pass
        for idx in reversed(sorted(set(remove_indices))):
            try:
                items.remove(idx)
            except Exception:
                pass
        try:
            setattr(plugin, "_statsfm_top_open_item", (statsfm_top_native_item if statsfm_user else None))
        except Exception:
            pass
        return True
    except Exception:
        return False
