CORE_SETTINGS_KEYS = [
    "plugin_lang",
    "nowfy_bootstrap_notice_enabled",
    "addon_cache_settings_enabled",
    "addon_bio_features_enabled",
    "addon_track_hub_enabled",
    "addon_nowcast_enabled",
    "addon_floatity_enabled",
    "core_enabled_optional_themes",
    "core_theme_spotlight_enabled",
    "core_theme_nowv_enabled",
    "core_show_theming_options",
]


def export_core_settings_from_plugin(plugin, keys=None):
    out = {}
    key_list = list(keys or CORE_SETTINGS_KEYS)
    for key in key_list:
        try:
            val = plugin.get_setting(key, None)
            if val is not None:
                out[str(key)] = val
        except Exception:
            pass
    return out


def import_core_settings_to_plugin(plugin, data):
    if not isinstance(data, dict):
        return 0
    applied = 0
    for key, value in data.items():
        try:
            plugin.set_setting(str(key), value)
            applied += 1
        except Exception:
            pass
    return applied
