default_app_config = "hidp_django_admin.apps.HidpDjangoAdminConfig"
