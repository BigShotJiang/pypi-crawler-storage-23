from django.apps import AppConfig


class HidpDjangoAdminConfig(AppConfig):
    name = "hidp_django_admin"
    label = "hidp_django_admin"
    verbose_name = "HIdP Django-admin"
