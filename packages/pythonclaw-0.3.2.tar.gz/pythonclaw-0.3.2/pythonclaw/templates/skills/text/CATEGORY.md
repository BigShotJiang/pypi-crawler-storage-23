---
name: text
description: Skills for text manipulation including counting characters, reversing strings, and changing case.
---
