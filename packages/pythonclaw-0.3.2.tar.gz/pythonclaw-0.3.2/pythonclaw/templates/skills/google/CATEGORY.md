---
name: google
description: Google Workspace skills — Gmail, Calendar, Drive, Contacts, Sheets, Docs via the gog CLI.
---
