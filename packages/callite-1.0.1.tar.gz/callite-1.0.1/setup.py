from setuptools import setup, find_packages

setup(
    name="callite",
    version="1.0.1",
    packages=find_packages(),

    # Metadata
    author="Emrah Gozcu",
    author_email="gozcu@gri.ai",
    description="Slim Redis RPC implementation",
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    url="https://github.com/gri-ai/callite",
    license="Proprietary",
    classifiers=[
        "License :: Other/Proprietary License"
    ],

    # Dependencies
    install_requires=[
        "redis>=5.0.3",
    ],

    # Optional dependencies
    extras_require={
        'dev': [
            'mypy>=1.9.0',
            'setuptools>=69.1.1',
        ],
        'mcp': [
            'mcp>=1.2.0',
        ],
    },

    # Console scripts
    entry_points={
        'console_scripts': [
            'mcp-callite-bridge=callite.mcp.bridge:main',
        ],
    },
)
