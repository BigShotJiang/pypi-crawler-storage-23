"""
Smoke tests for CLI modules — verify imports and basic functionality
of fixed CLI entry points.
"""

import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))


class TestCLIImports:
    """Verify all CLI modules can be imported without error."""

    def test_dotstar_cli_imports(self):
        from depth.dotstar.cli import main
        assert callable(main)

    def test_dotany_cli_imports(self):
        from truth.dotany.cli import main
        assert callable(main)

    def test_dotall_cli_imports(self):
        from truth.dotall.cli import main
        assert callable(main)

    def test_dotpluck_cli_imports(self):
        from shape.dotpluck.cli import main
        assert callable(main)

    @pytest.mark.xfail(reason="'collections' collides with Python stdlib; requires package restructuring")
    def test_dotrelate_cli_imports(self):
        from collections.dotrelate.cli import cli
        assert callable(cli)

    def test_dotget_cli_imports(self):
        from depth.dotget.cli import main
        assert callable(main)

    def test_dotpath_cli_imports(self):
        from depth.dotpath.cli import main
        assert callable(main)

    @pytest.mark.xfail(reason="dotselect uses bare 'from dotpath import ...' instead of 'from depth.dotpath import ...'")
    def test_dotselect_cli_imports(self):
        from depth.dotselect.cli import main
        assert callable(main)

    def test_dotexists_cli_imports(self):
        from truth.dotexists.cli import main
        assert callable(main)

    def test_dotequals_cli_imports(self):
        from truth.dotequals.cli import main
        assert callable(main)

    def test_dotquery_cli_imports(self):
        from truth.dotquery.cli import main
        assert callable(main)

    def test_dotmod_cli_imports(self):
        from shape.dotmod.cli import main
        assert callable(main)

    def test_dotbatch_cli_imports(self):
        from shape.dotbatch.cli import main
        assert callable(main)

    def test_dotpipe_cli_imports(self):
        from shape.dotpipe.cli import main
        assert callable(main)

    @pytest.mark.xfail(reason="'collections' collides with Python stdlib; requires package restructuring")
    def test_dotfilter_cli_imports(self):
        from collections.dotfilter.cli import main
        assert callable(main)


class TestDotanyCheck:
    """Test the new check() function in dotany."""

    def test_check_finds_matching_element(self):
        from truth.dotany.core import check
        data = {"users": [{"role": "admin"}, {"role": "user"}]}
        assert check(data, "users", {"role": "admin"}) is True

    def test_check_no_match(self):
        from truth.dotany.core import check
        data = {"users": [{"role": "admin"}, {"role": "user"}]}
        assert check(data, "users", {"role": "moderator"}) is False

    def test_check_string_coercion(self):
        from truth.dotany.core import check
        data = {"values": [1, 2, 3]}
        # String "1" should match integer 1 via string coercion
        assert check(data, "values", "1") is True

    def test_check_missing_path(self):
        from truth.dotany.core import check
        data = {"a": 1}
        assert check(data, "missing.path", "anything") is False

    def test_check_non_list_value(self):
        from truth.dotany.core import check
        data = {"status": "active"}
        assert check(data, "status", "active") is True
        assert check(data, "status", "inactive") is False

    def test_check_empty_list(self):
        from truth.dotany.core import check
        data = {"items": []}
        assert check(data, "items", "anything") is False

    def test_check_with_equals_string(self):
        """Test check with string value matching (CLI sends strings)."""
        from truth.dotany.core import check
        data = {"roles": ["admin", "user", "guest"]}
        assert check(data, "roles", "admin") is True
        assert check(data, "roles", "superadmin") is False


class TestDotallCheck:
    """Test the new check() function in dotall."""

    def test_check_all_match(self):
        from truth.dotall.core import check
        data = {"users": [{"role": "admin"}, {"role": "admin"}]}
        assert check(data, "users", {"role": "admin"}) is True

    def test_check_not_all_match(self):
        from truth.dotall.core import check
        data = {"users": [{"role": "admin"}, {"role": "user"}]}
        assert check(data, "users", {"role": "admin"}) is False

    def test_check_empty_list_vacuous_truth(self):
        from truth.dotall.core import check
        data = {"items": []}
        assert check(data, "items", "anything") is True

    def test_check_missing_path(self):
        from truth.dotall.core import check
        data = {"a": 1}
        assert check(data, "missing.path", "anything") is False

    def test_check_non_list_value(self):
        from truth.dotall.core import check
        data = {"status": "active"}
        assert check(data, "status", "active") is True
        assert check(data, "status", "inactive") is False

    def test_check_string_coercion(self):
        from truth.dotall.core import check
        data = {"values": [1, 1, 1]}
        # String "1" should match all integer 1s via string coercion
        assert check(data, "values", "1") is True

    def test_check_single_non_match_fails(self):
        from truth.dotall.core import check
        data = {"scores": [100, 100, 99]}
        assert check(data, "scores", "100") is False

    def test_check_all_strings_match(self):
        from truth.dotall.core import check
        data = {"statuses": ["active", "active", "active"]}
        assert check(data, "statuses", "active") is True


class TestPluckListImport:
    """Verify dotpluck CLI uses pluck_list correctly."""

    def test_pluck_list_exists(self):
        from shape.dotpluck.core import pluck_list
        assert callable(pluck_list)

    def test_pluck_list_basic(self):
        from shape.dotpluck.core import pluck_list
        data = {"user": {"name": "Alice", "age": 30}}
        result = pluck_list(data, "user.name", "user.age")
        assert result == ["Alice", 30]


class TestDotrelateUnionCommand:
    """Verify dotrelate union command is properly named."""

    @pytest.mark.xfail(reason="'collections' collides with Python stdlib; requires package restructuring")
    def test_union_command_name(self):
        from collections.dotrelate.cli import cli
        # Click groups expose commands dict
        assert "union" in cli.commands
        assert "union-command" not in cli.commands


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
