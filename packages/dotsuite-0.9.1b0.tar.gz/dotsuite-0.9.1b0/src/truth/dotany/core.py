from typing import Any, List
from depth.dotget.core import get

def any_match(collection: List[Any], path: str, value: Any) -> bool:
    """
    Checks if any document in the collection has the specified value at the given path.
    
    This is the existential quantifier for collections - returns True if at least one
    document in the collection has the specified value at the path.
    
    Args:
        collection: List of documents to check
        path: Dot notation path to check in each document
        value: Value to match against
        
    Returns:
        True if any document has the value at the path, False otherwise
        
    Examples:
        >>> users = [{"name": "Alice", "role": "admin"}, {"name": "Bob", "role": "user"}]
        >>> any_match(users, "role", "admin")
        True
        >>> any_match(users, "role", "moderator")
        False
    """
    if not collection:
        return False
    
    for doc in collection:
        try:
            if get(doc, path) == value:
                return True
        except (KeyError, IndexError, TypeError, AttributeError):
            # Path doesn't exist in this document, continue to next
            continue

    return False


def check(data: Any, path: str, equals: Any = None) -> bool:
    """
    Check if any element in the collection at `path` matches `equals`.

    This is a single-document convenience wrapper for CLI use.
    It extracts the collection at `path` from `data` using dotget,
    then checks whether any element equals `equals` (or, if elements
    are dicts, whether any element contains a value matching `equals`).

    Args:
        data: The source document
        path: Dot notation path to a collection within data
        equals: Value to compare against

    Returns:
        True if any element matches, False otherwise
    """
    try:
        collection = get(data, path)
    except (KeyError, IndexError, TypeError, AttributeError):
        return False

    if not isinstance(collection, list):
        return collection == equals

    for item in collection:
        if item == equals:
            return True
        # Also check string coercion for CLI string values
        if str(item) == str(equals):
            return True
    return False
