from .core import all_match

__all__ = ["all_match"]
__version__ = "0.1.0"
