# dotall

**Universal quantifier for collections**

Part of the Truth pillar, `dotall` checks if all items in a collection satisfy a condition.

## Overview

`dotall` implements the universal quantifier (∀) from mathematical logic, returning `True` if every item in a collection matches a specified value at a given path.

## Basic Usage

```python
from truth.dotall import all_match

users = [
    {"name": "Alice", "verified": True},
    {"name": "Bob", "verified": True},
    {"name": "Charlie", "verified": True}
]

# Check if all users are verified
all_verified = all_match(users, "verified", True)  # True

# Add an unverified user
users.append({"name": "David", "verified": False})
all_verified = all_match(users, "verified", True)  # False
```

## Nested Paths

Works with nested data structures:

```python
data = [
    {"user": {"status": {"active": True}}},
    {"user": {"status": {"active": True}}},
    {"user": {"status": {"active": True}}}
]

# Check if all users are active
all_active = all_match(data, "user.status.active", True)  # True
```

## Edge Cases

### Empty Collections (Vacuous Truth)
Returns `True` for empty collections (vacuous truth in logic):

```python
empty = []
result = all_match(empty, "any.path", "value")  # True
# "All items in an empty set satisfy any condition"
```

### Missing Paths
Items with missing paths are treated as non-matching:

```python
data = [
    {"name": "Alice", "age": 30},
    {"name": "Bob"}  # Missing age
]

# Bob doesn't have age field
all_age_30 = all_match(data, "age", 30)  # False
```

## Mathematical Properties

- **Vacuous truth**: Empty collections always return `True`
- **Universal quantification**: ∀x ∈ collection : predicate(x)
- **Dual of dotany**: `all` and `any` form a duality in boolean logic
- **De Morgan's laws**: `not(all(p))` ≡ `any(not(p))`

## Integration with dotquery

`dotall` is used internally by `dotquery` for collection queries:

```python
from truth.dotquery import Query

# These are equivalent:
q = Query("all users.verified equals true")
# vs
from truth.dotall import all_match
result = all_match(users, "verified", True)
```

## Real-World Examples

### Data Validation
```python
# Ensure all products have the expected status
products = [
    {"name": "Widget", "status": "available", "sku": "W001"},
    {"name": "Gadget", "status": "available", "sku": "G001"}
]

# All products must be available
valid = all_match(products, "status", "available")  # True
```

### Permission Checking
```python
# Check if all team members have the same access level
team = [
    {"name": "Alice", "access": "full"},
    {"name": "Bob", "access": "full"}
]

# All must have full access
all_full = all_match(team, "access", "full")  # True
```

## Command Line

`dotall` uses exit codes for boolean output: exit code `0` means all elements match, exit code `1` means at least one does not. The `--equals` flag is required to specify the value to compare against.

```bash
# Check if all elements in the collection at a path equal a value
echo '{"statuses": ["active", "active", "active"]}' | dotall statuses --equals active
echo $?  # 0 (all match)

echo '{"statuses": ["active", "inactive", "active"]}' | dotall statuses --equals active
echo $?  # 1 (not all match)

# Check against a YAML file
dotall users.verified --equals true data.yaml

# Read from a specific file
dotall items.status --equals complete data.json

# Use in shell conditionals
if echo '{"flags": [true, true, true]}' | dotall flags --equals true; then
    echo "All flags are true"
fi
```

Input is always parsed as YAML (which is a superset of JSON), so both JSON and YAML data work.

### Options

| Flag | Description |
|------|-------------|
| `path` | Dot notation path to a collection within the data. Required. |
| `--equals` | The value to check for equality. Required. |
| `data_file` | Path to a JSON or YAML data file, or `-` for stdin (default). |

### Exit Codes

| Code | Meaning |
|------|---------|
| `0` | All elements match the value (or the collection is empty -- vacuous truth) |
| `1` | At least one element does not match, or an error occurred |

## Related Tools

- **[dotany](dotany.md)** - Existential quantifier (at least one matches)
- **[dotexists](dotexists.md)** - Check path existence
- **[dotquery](dotquery.md)** - Complex boolean queries
- **[dotfilter](../collections/dotfilter.md)** - Filter collections