import petl
# from oaa.hooks.decorators import hook, OAAHookEvent

def fetch(connection=None, source=None, config=None, **kwargs):
    '''
    Fetch the data. This is the function that is called by oaa.

    '''
    # from oaa.settings import config
    import bpdb; bpdb.set_trace()  # noqa: E702
    table = config.sources[source.source].get_stream()

    return table
    # return petl.fromcsv(source.csv_filepath)
