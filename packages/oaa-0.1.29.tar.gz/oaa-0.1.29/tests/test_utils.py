import pytest
from oaa import utils
from oaa.app_runners.hris_single_source import HRISRunner
import petl
import logging
from oaa.settings import config as _config  # , SourceType
logging.basicConfig(log_level=logging.debug)
logger = logging.getLogger(__name__)


@pytest.fixture
def config():
    _config.update(SOURCE_MAPPING_FILEPATH='./tests/sample_mapping.csv')
    yield _config
    _config.reset()


@pytest.fixture
def record():
    obj = {
        'EMPL_ADDRESS1': 'number1',
        'EMPL_ADDRESS2': 'number2',
    }
    record = petl.Record(obj.values(), list(obj.keys()))
    yield record


def test_join_fields_with_none(record, config):
    """Verify that passing None values to join fields does ....
    :returns: TODO

    """
    options = {
            'options': ['\n', ['EMPL_ADDRESS1', None]]
    }

    func = utils.join_fields(options=options)

    assert func('hello', record) == 'number1'


def test_join_fields(record, config):
    """Verify that passing None values to join fields does ....
    :returns: TODO

    """
    options = {
            'options': ['\n', ['EMPL_ADDRESS1', 'EMPL_ADDRESS2']]
    }

    func = utils.join_fields(options=options)

    assert func('hello', record) == '\n'.join(['number1', 'number2'])


VALUES_TO_HASH = (
    ('EMPL_ADDRESS2', 'e9ee33815966ca513b249a589e6a7c4e8aca72995aaa153b631027f562e2f7ea'),  # noqa E501
    ('', 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'),
    (None, None),
)


@pytest.mark.parametrize('value_to_hash, hashed_value', VALUES_TO_HASH)
def test_func_name(value_to_hash, hashed_value):
    """ func_name
    do something with the value_to_hash, hashed_value parameter
    """

    hash_value_here = utils.make_hash()(value_to_hash)
    # print(hash_value_here)
    assert hash_value_here == hashed_value


DATE_VALUES_TO_CONVERT = (
    ('01-01-2025', '2025-01-01T00:00:00Z'),
    ('01/01/2025', '2025-01-01T00:00:00Z'),
    ('01-01-25', '2025-01-01T00:00:00Z'),
    ('01/01/25', '2025-01-01T00:00:00Z'),
    ('2025-01-25', '2025-01-25T00:00:00Z'),
    ('2025-01-25T15:00', '2025-01-25T15:00:00Z'),
)


@pytest.mark.parametrize('date_string,should_be_output_string', DATE_VALUES_TO_CONVERT)  # noqa E501
def test_date_convert(date_string, should_be_output_string):

    options = {
        'options': None
    }
    fieldname = 'EMPL_ADDRESS1'
    output_string = utils.date_convert(fieldname=fieldname,
                                       runner=HRISRunner(),
                                       options=options)(date_string)

    assert output_string == should_be_output_string


EMAILS_TO_TEST = (
    ('kajigga@gmail.com', 'kajigga@gmail.com'),
    ('kajigga+junk@gmail.com', 'kajigga+junk@gmail.com'),
    ('KAJIGGA@gmail.com', 'kajigga@gmail.com'),
    ('invalid@company-name.inv', 'invalid@company-name.inv'),
)


@pytest.mark.parametrize('email,should_be', EMAILS_TO_TEST)
def test_email_convert(email, should_be):
    assert utils.email_convert()(email) == should_be
