# import petl
import os
import pytest
from oaa.app_runners.custom_app import CustomAppRunner
from pathlib import Path

# test that a configuration can identify multiple DB sources (queries), pull
# that data into streams (petl.fromdb) and feed into OAA

BASE_DIR = Path(os.path.dirname(os.path.realpath(__file__)))


@pytest.fixture
def multi_db_stream_config(config):
    config.update(config_file=BASE_DIR / 'config-v2-sqlplus.yaml')

    return config


def test_config_app(multi_db_stream_config):
    config = multi_db_stream_config
    assert config.version == 'v2'
    assert config.app


@pytest.fixture
def env_set():
    os.environ['LD_LIBRARY_PATH'] = f'{os.environ.get("LD_LIBRARY_PATH", '')}:/usr/lib/oracle/10.2.0.5/client64/lib/'
    os.environ['LD_LIBRARY_PATH'] = f'{os.environ["LD_LIBRARY_PATH"]}:/usr/lib/oracle/10.2.0.5/client/lib/'
    os.environ['PATH'] = f'/usr/lib/oracle/10.2.0.5/client64/bin:{os.environ["PATH"]}'

    os.environ['DB_USERNAME'] = 'system'
    os.environ['DB_PASSWORD'] = 'oracle'
    os.environ['DB_SERVER'] = 'localhost'
    os.environ['DB_PORT'] = '1521'
    os.environ['DB_SERVICE_NAME'] = 'xe.oracle.docker'
    # os.environ['PATH'] = $HOME/bin:$PATH


@pytest.fixture
def runner(env_set, multi_db_stream_config):

    yield CustomAppRunner()


@pytest.mark.skip(reason="no way of currently testing this")
def test_fetch_module_list(runner):
    # from oaa.settings_v2 import VezaAPIConnection
    from oaa.settings import config
    source = config.sources['sqlplus']
    stream = source.get_stream()

    assert stream
    assert stream.nrows() >= 2
    # assert stream.nrows() == 15
