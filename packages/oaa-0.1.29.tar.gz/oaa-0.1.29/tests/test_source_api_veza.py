# import petl
import os
import pytest
from oaa.app_runners.custom_app import CustomAppRunner
from pathlib import Path

# test that a configuration can identify multiple DB sources (queries), pull
# that data into streams (petl.fromdb) and feed into OAA

BASE_DIR = Path(os.path.dirname(os.path.realpath(__file__)))


@pytest.fixture
def multi_db_stream_config(config):
    config.update(config_file=BASE_DIR / 'config-v2-veza-api.yaml')

    return config


def test_config_app(multi_db_stream_config):
    config = multi_db_stream_config
    # assert config.version == 'v2'
    assert config.app


@pytest.fixture
def runner(multi_db_stream_config):

    yield CustomAppRunner()


def test_fetch_module_list(runner):
    # from oaa.settings_v2 import VezaAPIConnection
    from oaa.settings import config
    source = config.sources['veza_query_list']
    stream = source.get_stream()

    assert stream
    assert stream.nrows() >= 2
    # assert stream.nrows() == 15


def test_fetch_api_dict(runner):
    from oaa.settings import config
    source = config.sources['veza_query_dict']
    assert id(source.stream) == id(source.stream)
    assert len(source.stream.fieldnames()) > 1

    assert source.stream
    assert source.stream.nrows() >= 1
