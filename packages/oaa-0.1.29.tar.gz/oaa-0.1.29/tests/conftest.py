import pytest
# import oaa
from oaa.settings import config as _config


@pytest.fixture
def config():

    _config.update()
    yield _config
    _config.reset()
