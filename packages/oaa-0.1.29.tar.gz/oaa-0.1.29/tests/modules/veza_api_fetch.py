import requests
from oaa.oaa_utils import get_oaa_client
from oaa.utils import simple_jinja_render


def fetch(connection, **kwargs):

    from oaa.settings import config

    client = get_oaa_client()

    kwargs.setdefault('num_pages', 1)

    method = getattr(client, f'api_{connection.method.lower()}')

    path = simple_jinja_render(connection.path,
                               {'connection': connection,
                                'config': config})
    response = method(path, params=connection.params)

    if connection.response_type == 'list':

        for r in response:
            yield r

    if connection.response_type == 'dict':
        yield response
