from oaa.hooks.decorators import hook, OAAHookEvent
# events include
# PRE_TRANSFORM = 'PRE_TRANSFORM'
# PRE_CREATE_OAA = 'PRE_CREATE_OAA'
# PRE_PUSH_OAA = 'PRE_PUSH_OAA'
# POST_PUSH_OAA = 'POST_PUSH_OAA'

@hook(event=OAAHookEvent.PRE_PUSH_OAA)
def hook_name(sources=None, **kwargs):

    '''
    hook_name is a hook for doing some custom thing at this point in the flow.
    '''
    # for board_rec in sources['boards'].records:
    import bpdb; bpdb.set_trace()  # noqa: E702
