import petl
from webapp.app.scim_filter_petl import compile_scim_filter

list_o_users = [
    {
        "userName": "bjensen",
        'displayName': 'Brian Jensen',
        "emails": [
            {"value": "personal@example.com", "type": "home"},
            {"value": "work_admin@example.com", "type": "work"},
            {"value": "other@test.org", "type": "other"}
        ]
    },
    {
        "userName": "ajensen",
        'displayName': 'Aaron Jensen',
        "emails": [
            {"value": "personal1@exomple.com", "type": "home"},
            {"value": "work_admin1@exomple.com", "type": "work"},
            {"value": "other1@test.org", "type": "other"}
        ]
    }
]


def test_filter_userName():
    """TODO: Docstring for test_filter_str.
    :returns: TODO

    """

    # query = 'emails[type eq "work" and value co "@example.com"] or ims[type eq "xmpp" and value co "@foo.com"]'
    # query = 'emails[type eq "work" and value co "@example.com"]'  # or ims[type eq "xmpp" and value co "@foo.com"]'
    query = 'userName eq "bjensen"'
    # query = 'userName eq "khansen" OR userName eq "khansen2"'

    filter_function_here = compile_scim_filter(query)
    assert filter_function_here
    assert callable(filter_function_here)

    stream = petl.fromdicts(list_o_users)
    stream = stream.select(filter_function_here)

    assert stream.nrows() == 1


def test_filter_complex():
    """TODO: Docstring for test_filter_str.
    :returns: TODO

    """

    # query = 'emails[type eq "work" and value co "@example.com"] or ims[type eq "xmpp" and value co "@foo.com"]'
    query = 'emails[type eq "work" and value co "@example.com"]'  # or ims[type eq "xmpp" and value co "@foo.com"]'
    # query = 'userName eq "bjensen"'
    # query = 'userName eq "khansen" OR userName eq "khansen2"'

    filter_function_here = compile_scim_filter(query)
    assert filter_function_here
    assert callable(filter_function_here)

    stream = petl.fromdicts(list_o_users)
    stream = stream.select(filter_function_here)

    assert stream.nrows() == 1


def test_filter_displayName():
    """TODO: Docstring for test_filter_str.
    :returns: TODO

    """

    # query = 'emails[type eq "work" and value co "@example.com"] or ims[type eq "xmpp" and value co "@foo.com"]'
    query = 'displayName co "Brian"'  # or ims[type eq "xmpp" and value co "@foo.com"]'
    # query = 'userName eq "bjensen"'
    # query = 'userName eq "khansen" OR userName eq "khansen2"'

    filter_function_here = compile_scim_filter(query)
    assert filter_function_here
    assert callable(filter_function_here)

    stream = petl.fromdicts(list_o_users)
    stream = stream.select(filter_function_here)

    assert stream.nrows() == 1

    import bpdb; bpdb.set_trace()  # noqa: E702
