import setuptools
from pathlib import Path
import os

BASE_DIR = Path(os.path.dirname(__file__))


def get_version():
    version_file = Path(os.path.dirname(__file__)) / 'version'
    with open(version_file, 'r') as _f:
        return _f.read()


def get_required(env=None):
    """TODO: Docstring for get_required.
    :returns: TODO

    """

    if not env:
        env = ''
    else:
        env = f'-{env}'

    # import bpdb; bpdb.set_trace()
    with open(BASE_DIR / f'./requirements/requirements{env}.txt', 'r') as _file:
        return [line.strip() for line in _file if line.strip() and not line.startswith("#")]  # noqa E501


setuptools.setup(
    # version=get_version(),
    packages=setuptools.find_namespace_packages(),
    install_requires=get_required(),
    extras_require={
        "mysql": ['pymysql'],
        "postgres": ['psycopg2-binary'],
        "pymssql": get_required('sqlserver'),
        "dev": get_required('dev'),
        "oracle": get_required('oracle'),
    },
    zip_safe=False
)
