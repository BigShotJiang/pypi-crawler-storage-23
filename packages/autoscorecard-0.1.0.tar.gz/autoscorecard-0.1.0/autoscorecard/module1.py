def greet(name):
    """返回一个问候语"""
    return f"Hello, {name}!"