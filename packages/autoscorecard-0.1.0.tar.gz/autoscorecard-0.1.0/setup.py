from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="autoscorecard",  # 包的名称，发布时必须是唯一的
    version="0.1.0",  # 版本号
    author="Your Name",
    author_email="your.email@example.com",
    description="一个简单的示例包",  # 简短描述
    long_description=long_description,  # 详细描述，通常从README读取
    long_description_content_type="text/markdown",
    url="https://github.com/Analyzers/autoscorecard",  # 项目主页或代码仓库
    packages=find_packages(),  # 自动发现所有包
    install_requires=[
        # 列出你的包所依赖的其他包，例如：
        # "requests",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",  # 指定支持的Python版本
)