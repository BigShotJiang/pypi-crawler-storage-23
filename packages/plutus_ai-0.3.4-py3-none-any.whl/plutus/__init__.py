"""Plutus — Autonomous AI agent with subprocess orchestration."""

__version__ = "0.3.2"
