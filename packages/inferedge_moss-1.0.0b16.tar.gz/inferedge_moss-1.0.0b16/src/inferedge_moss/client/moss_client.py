from __future__ import annotations

import asyncio
import os
import sys
from typing import Any, Dict, List, Optional

import httpx

from moss_core import (
    CLOUD_API_MANAGE_URL,
    ManageClient,
    DocumentInfo,
    GetDocumentsOptions,
    IndexInfo,
    IndexManager,
    MutationOptions,
    MutationResult,
    JobStatusResponse,
    QueryOptions,
    QueryResultDocumentInfo,
    SearchResult,
)

if sys.version_info < (3, 14):
    from ..services.embedding_service import EmbeddingService
else:
    EmbeddingService = None  # type: ignore


def _get_manage_url() -> str:
    """Manage URL, overridable via env for local development."""
    return os.getenv("MOSS_CLOUD_API_MANAGE_URL", CLOUD_API_MANAGE_URL)


def _get_query_url() -> str:
    """Query URL, derived from manage URL or overridable via env."""
    explicit = os.getenv("MOSS_CLOUD_QUERY_URL")
    if explicit:
        return explicit
    return _get_manage_url().replace("/v1/manage", "/query")


class MossClient:
    """
    Semantic search client for vector similarity operations.

    All mutations and reads go through the Rust ManageClient.
    Querying uses the local IndexManager when the index is loaded,
    otherwise falls back to the cloud query API.

    Example:
        ```python
        from inferedge_moss import MossClient, DocumentInfo

        client = MossClient("project-id", "project-key")

        docs = [DocumentInfo(id="1", text="Machine learning fundamentals")]
        result = await client.create_index("my-index", docs, "moss-minilm")

        await client.load_index("my-index")
        results = await client.query("my-index", "AI and neural networks")
        ```
    """

    DEFAULT_MODEL_ID = "moss-minilm"

    def __init__(self, project_id: str, project_key: str) -> None:
        self._project_id = project_id
        self._project_key = project_key
        manage_url = _get_manage_url()
        self._manage = ManageClient(project_id, project_key, manage_url)
        self._manager = IndexManager(project_id, project_key, manage_url)
        self._embedding_services: dict = {}

    # -- Mutations (via Rust ManageClient) --------------------------

    async def create_index(
        self,
        name: str,
        docs: List[DocumentInfo],
        model_id: Optional[str] = None,
    ) -> MutationResult:
        """Create a new index and populate it with documents."""
        resolved_model_id = self._resolve_model_id(docs, model_id)
        return await asyncio.to_thread(
            self._manage.create_index, name, docs, resolved_model_id,
        )

    async def add_docs(
        self,
        name: str,
        docs: List[DocumentInfo],
        options: Optional[MutationOptions] = None,
    ) -> MutationResult:
        """Add or update documents in an index."""
        return await asyncio.to_thread(
            self._manage.add_docs, name, docs, options,
        )

    async def delete_docs(
        self,
        name: str,
        doc_ids: List[str],
    ) -> MutationResult:
        """Delete documents from an index by their IDs."""
        return await asyncio.to_thread(
            self._manage.delete_docs, name, doc_ids,
        )

    async def get_job_status(self, job_id: str) -> JobStatusResponse:
        """Get the status of a bulk operation job."""
        return await asyncio.to_thread(self._manage.get_job_status, job_id)

    # -- Read operations (via Rust ManageClient) --------------------

    async def get_index(self, name: str) -> IndexInfo:
        """Get information about a specific index."""
        return await asyncio.to_thread(self._manage.get_index, name)

    async def list_indexes(self) -> List[IndexInfo]:
        """List all indexes with their information."""
        return await asyncio.to_thread(self._manage.list_indexes)

    async def delete_index(self, name: str) -> bool:
        """Delete an index and all its data."""
        return await asyncio.to_thread(self._manage.delete_index, name)

    async def get_docs(
        self,
        name: str,
        options: Optional[GetDocumentsOptions] = None,
    ) -> List[DocumentInfo]:
        """Retrieve documents from an index."""
        return await asyncio.to_thread(self._manage.get_docs, name, options)

    # -- Index loading & querying -----------------------------------

    async def load_index(
        self,
        name: str,
        auto_refresh: bool = False,
        polling_interval_in_seconds: int = 600,
    ) -> str:
        """
        Downloads an index from the cloud into memory for fast local querying.

        Without load_index(), query() falls back to the cloud API (~100-500ms).
        With load_index(), queries run entirely in-memory (~1-10ms).
        """
        try:
            result = await asyncio.to_thread(
                self._manager.load_index, name, auto_refresh, polling_interval_in_seconds,
            )
            if result.model.id != "custom" and sys.version_info < (3, 14):
                await self._get_embedding_service(result.model.id)
            return name
        except RuntimeError as e:
            raise RuntimeError(f"Failed to load index '{name}': {e}") from e

    async def unload_index(self, name: str) -> None:
        """Unload an index from memory."""
        try:
            await asyncio.to_thread(self._manager.unload_index, name)
        except RuntimeError as e:
            raise RuntimeError(f"Failed to unload index '{name}': {e}") from e

    async def query(
        self,
        name: str,
        query: str,
        options: Optional[QueryOptions] = None,
    ) -> SearchResult:
        """
        Perform a semantic similarity search.

        If the index is loaded locally (via load_index), queries run in-memory.
        Otherwise, falls back to the cloud query API.
        """
        is_loaded = await asyncio.to_thread(self._manager.has_index, name)

        if is_loaded:
            return await self._query_local(name, query, options)

        return await self._query_cloud(name, query, options)

    # -- Internal ---------------------------------------------------

    async def _query_local(
        self,
        name: str,
        query: str,
        options: Optional[QueryOptions],
    ) -> SearchResult:
        top_k = getattr(options, "top_k", None) or 5
        alpha = getattr(options, "alpha", None) or 0.8
        query_embedding = getattr(options, "embedding", None)

        if query_embedding is None:
            index_info = await asyncio.to_thread(self._manager.get_index_info, name)
            if index_info.model.id == "custom":
                raise ValueError(
                    "This index uses custom embeddings. "
                    "Query embeddings must be provided via QueryOptions.embedding."
                )
            embedding_service = await self._get_embedding_service(index_info.model.id)
            query_embedding = await embedding_service.create_embedding(query)
        else:
            query_embedding = list(query_embedding)

        return await asyncio.to_thread(
            self._manager.query, name, query, query_embedding, top_k, alpha,
        )

    async def _query_cloud(
        self,
        name: str,
        query: str,
        options: Optional[QueryOptions],
    ) -> SearchResult:
        """Fallback: query via the cloud API when the index is not loaded locally."""
        top_k = getattr(options, "top_k", None) or 10
        query_embedding = getattr(options, "embedding", None)

        request_body: Dict[str, Any] = {
            "query": query,
            "indexName": name,
            "projectId": self._project_id,
            "projectKey": self._project_key,
            "topK": top_k,
        }
        if query_embedding is not None:
            request_body["queryEmbedding"] = list(query_embedding)

        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    _get_query_url(),
                    headers={"Content-Type": "application/json"},
                    json=request_body,
                )
                if not response.is_success:
                    raise Exception(f"HTTP error! status: {response.status_code}")
                data = response.json()
        except httpx.RequestError as error:
            raise Exception(f"Cloud query request failed: {str(error)}")

        return self._dict_to_search_result(data)

    @staticmethod
    def _dict_to_search_result(data: dict) -> SearchResult:
        docs = [
            QueryResultDocumentInfo(
                id=d.get("id", ""),
                text=d.get("text", ""),
                metadata=d.get("metadata"),
                score=float(d.get("score", 0.0)),
            )
            for d in data.get("docs", [])
        ]
        return SearchResult(
            docs=docs,
            query=data.get("query", ""),
            index_name=data.get("indexName"),
            time_taken_ms=data.get("timeTakenMs"),
        )

    def _resolve_model_id(
        self,
        docs: List[DocumentInfo],
        model_id: Optional[str],
    ) -> str:
        if model_id is not None:
            return model_id
        has_embeddings = any(
            getattr(doc, "embedding", None) is not None for doc in docs
        )
        return "custom" if has_embeddings else self.DEFAULT_MODEL_ID

    async def _get_embedding_service(self, model_id: str) -> EmbeddingService:
        if sys.version_info >= (3, 14):
            raise RuntimeError(
                "Embedding service is not supported in Python 3.14. "
                "Please provide pre-computed embeddings via QueryOptions.embedding."
            )
        if model_id == "custom":
            raise ValueError(
                "Cannot create embedding service for 'custom' model. "
                "Custom embeddings must be provided."
            )
        if model_id not in self._embedding_services:
            embedding_service = EmbeddingService(
                model_id=model_id, normalize=True, quantized=False,
            )
            await embedding_service.load_model()
            self._embedding_services[model_id] = embedding_service
        return self._embedding_services[model_id]
