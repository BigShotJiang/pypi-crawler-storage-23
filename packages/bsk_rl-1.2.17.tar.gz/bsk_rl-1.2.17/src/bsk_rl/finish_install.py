"""Package install scripts."""


def pck_install():
    """Deprecated."""
    print("finish_install is no longer necessary.")
