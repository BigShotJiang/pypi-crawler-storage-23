# Copyright (c) 2025, VRAI Labs and/or its affiliates. All rights reserved.
#
# This software is licensed under the Apache License, Version 2.0 (the
# "License") as published by the Apache Software Foundation.
#
# You may not use this file except in compliance with the License. You may
# obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from __future__ import annotations

from typing import Optional, Protocol, TypeVar, Union, runtime_checkable

from supertokens_python.framework import BaseRequest
from supertokens_python.ingredients.emaildelivery import EmailDeliveryIngredient
from supertokens_python.ingredients.emaildelivery.types import (
    EmailDeliveryConfig,
    EmailDeliveryConfigWithService,
)
from supertokens_python.recipe.webauthn.interfaces.api import (
    APIInterface,
    TypeWebauthnEmailDeliveryInput,
)
from supertokens_python.recipe.webauthn.interfaces.recipe import RecipeInterface
from supertokens_python.types.base import UserContext
from supertokens_python.types.config import (
    BaseConfig,
    BaseNormalisedConfig,
    BaseNormalisedOverrideConfig,
    BaseOverrideableConfig,
    BaseOverrideConfig,
)
from supertokens_python.types.response import CamelCaseBaseModel

InterfaceType = TypeVar("InterfaceType")
"""Generic Type for use in `InterfaceOverride`"""


@runtime_checkable
class GetRelyingPartyId(Protocol):
    """
    Callable signature for `WebauthnConfig.get_relying_party_id`.
    """

    async def __call__(
        self,
        *,
        tenant_id: str,
        request: Optional[BaseRequest],
        user_context: UserContext,
    ) -> str: ...


@runtime_checkable
class NormalisedGetRelyingPartyId(Protocol):
    """
    Callable signature for `WebauthnNormalisedConfig.get_relying_party_id`.
    """

    async def __call__(
        self,
        *,
        tenant_id: str,
        request: Optional[BaseRequest],
        user_context: UserContext,
    ) -> str: ...


@runtime_checkable
class GetRelyingPartyName(Protocol):
    """
    Callable signature for `WebauthnConfig.get_relying_party_name`.
    """

    async def __call__(
        self,
        *,
        tenant_id: str,
        user_context: UserContext,
    ) -> str: ...


@runtime_checkable
class NormalisedGetRelyingPartyName(Protocol):
    """
    Callable signature for `WebauthnNormalisedConfig.get_relying_party_name`.
    """

    async def __call__(
        self,
        *,
        tenant_id: str,
        request: Optional[BaseRequest],
        user_context: UserContext,
    ) -> str: ...


@runtime_checkable
class GetOrigin(Protocol):
    """
    Callable signature for `WebauthnConfig.get_origin`.
    """

    async def __call__(
        self,
        *,
        tenant_id: str,
        request: Optional[BaseRequest],
        user_context: UserContext,
    ) -> str: ...


@runtime_checkable
class NormalisedGetOrigin(Protocol):
    """
    Callable signature for `WebauthnNormalisedConfig.get_origin`.
    """

    async def __call__(
        self,
        *,
        tenant_id: str,
        request: Optional[BaseRequest],
        user_context: UserContext,
    ) -> str: ...


@runtime_checkable
class GetEmailDeliveryConfig(Protocol):
    """
    Callable signature for `WebauthnNormalisedConfig.get_email_delivery_config`.
    """

    async def __call__(self) -> EmailDeliveryConfig[TypeWebauthnEmailDeliveryInput]: ...


@runtime_checkable
class NormalisedGetEmailDeliveryConfig(Protocol):
    """
    Callable signature for `WebauthnNormalisedConfig.get_email_delivery_config`.
    """

    def __call__(
        self,
    ) -> EmailDeliveryConfigWithService[TypeWebauthnEmailDeliveryInput]: ...


@runtime_checkable
class ValidateEmailAddress(Protocol):
    """
    Callable signature for `WebauthnConfig.validate_email_address`.
    """

    async def __call__(
        self, *, email: str, tenant_id: str, user_context: UserContext
    ) -> Optional[str]: ...


@runtime_checkable
class NormalisedValidateEmailAddress(Protocol):
    """
    Callable signature for `WebauthnNormalisedConfig.validate_email_address`.
    """

    async def __call__(
        self, *, email: str, tenant_id: str, user_context: UserContext
    ) -> Optional[str]: ...


@runtime_checkable
class InterfaceOverride(Protocol[InterfaceType]):
    """
    Callable signature for `WebauthnConfig.override.*`.
    """

    def __call__(
        self,
        original_implementation: InterfaceType,
    ) -> InterfaceType: ...


WebauthnOverrideConfig = BaseOverrideConfig[RecipeInterface, APIInterface]
NormalisedWebauthnOverrideConfig = BaseNormalisedOverrideConfig[
    RecipeInterface, APIInterface
]


class WebauthnOverrideableConfig(BaseOverrideableConfig):
    """Input config properties overrideable using the plugin config overrides"""

    get_relying_party_id: Optional[Union[str, GetRelyingPartyId]] = None
    get_relying_party_name: Optional[Union[str, GetRelyingPartyName]] = None
    get_origin: Optional[GetOrigin] = None
    email_delivery: Optional[EmailDeliveryConfig[TypeWebauthnEmailDeliveryInput]] = None
    validate_email_address: Optional[ValidateEmailAddress] = None


class WebauthnConfig(
    WebauthnOverrideableConfig,
    BaseConfig[RecipeInterface, APIInterface, WebauthnOverrideableConfig],
):
    def to_overrideable_config(self) -> WebauthnOverrideableConfig:
        """Create a `WebauthnOverrideableConfig` from the current config."""
        return WebauthnOverrideableConfig(**self.model_dump())

    def from_overrideable_config(
        self,
        overrideable_config: WebauthnOverrideableConfig,
    ) -> "WebauthnConfig":
        """
        Create a `WebauthnConfig` from a `WebauthnOverrideableConfig`.
        Not a classmethod since it needs to be used in a dynamic context within plugins.
        """
        return WebauthnConfig(
            **overrideable_config.model_dump(),
            override=self.override,
        )


class NormalisedWebauthnConfig(BaseNormalisedConfig[RecipeInterface, APIInterface]):
    get_relying_party_id: NormalisedGetRelyingPartyId
    get_relying_party_name: NormalisedGetRelyingPartyName
    get_origin: NormalisedGetOrigin
    get_email_delivery_config: NormalisedGetEmailDeliveryConfig
    validate_email_address: NormalisedValidateEmailAddress


class WebauthnIngredients(CamelCaseBaseModel):
    email_delivery: Optional[
        EmailDeliveryIngredient[TypeWebauthnEmailDeliveryInput]
    ] = None
