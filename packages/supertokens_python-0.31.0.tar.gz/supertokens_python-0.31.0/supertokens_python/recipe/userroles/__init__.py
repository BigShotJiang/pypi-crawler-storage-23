# Copyright (c) 2021, VRAI Labs and/or its affiliates. All rights reserved.
#
# This software is licensed under the Apache License, Version 2.0 (the
# "License") as published by the Apache Software Foundation.
#
# You may not use this file except in compliance with the License. You may
# obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.
from __future__ import annotations

from typing import TYPE_CHECKING, Optional, Union

from .recipe import PermissionClaim, UserRoleClaim, UserRolesRecipe
from .utils import InputOverrideConfig, UserRolesOverrideConfig

if TYPE_CHECKING:
    from supertokens_python.supertokens import RecipeInit


def init(
    skip_adding_roles_to_access_token: Optional[bool] = None,
    skip_adding_permissions_to_access_token: Optional[bool] = None,
    override: Union[UserRolesOverrideConfig, None] = None,
) -> RecipeInit:
    return UserRolesRecipe.init(
        skip_adding_roles_to_access_token,
        skip_adding_permissions_to_access_token,
        override,
    )


__all__ = [
    "InputOverrideConfig",  # deprecated, use `UserRolesOverrideConfig` instead
    "PermissionClaim",
    "UserRoleClaim",
    "UserRolesOverrideConfig",
    "UserRolesRecipe",
    "init",
]
