from abc import ABC


class BaseRecipeInterface(ABC): ...


class BaseAPIInterface(ABC): ...
