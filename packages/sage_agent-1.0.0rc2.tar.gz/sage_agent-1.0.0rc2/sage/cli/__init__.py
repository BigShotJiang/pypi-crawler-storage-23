"""CLI for Sage."""

from sage.cli.main import cli

__all__ = ["cli"]
