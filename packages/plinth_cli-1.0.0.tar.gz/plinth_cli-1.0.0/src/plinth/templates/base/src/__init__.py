"""{{ project_name }} source package."""
