"""Plinth: A high-performance CLI scaffolding tool for FastAPI."""

__version__ = "1.0.0"
