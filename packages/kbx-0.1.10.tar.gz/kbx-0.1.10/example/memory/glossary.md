---
title: Glossary
---

## Terms

- **FTS5** — SQLite full-text search extension
- **RRF** — Reciprocal Rank Fusion, combines multiple search rankings
- **MCP** — Model Context Protocol, for AI tool integration
