---
name: Alice Reed
type: person
role: Engineering Lead
team: Platform
aliases: [Alice, AR]
---

## About

Alice leads the platform team. Focus areas include API design and infrastructure.
