---
name: Feature Request
about: 새로운 기능을 제안해 주세요
title: "[Feature] "
labels: enhancement
---

## 기능 설명

<!-- 어떤 기능이 필요한지 설명해 주세요 -->

## 사용 시나리오

<!-- 이 기능이 어떤 상황에서 유용한지 -->

## 추가 정보

<!-- KUPID 포털의 관련 URL이나 스크린샷이 있다면 첨부해 주세요 -->
