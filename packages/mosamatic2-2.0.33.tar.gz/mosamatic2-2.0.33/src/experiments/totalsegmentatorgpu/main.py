from totalsegmentator.python_api import totalsegmentator

def main():
    totalsegmentator(input="D:\\Mosamatic\\TotalSegmentator\\patient1.nii.gz", output="D:\\Mosamatic\\TotalSegmentator\\output", fast=False)


if __name__ == '__main__':
    main()