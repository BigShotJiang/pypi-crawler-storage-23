BASE_DIR = 'D:\\SoftwareDevelopment\\GitHub\\mosamatic2\\mosamatic2\\src\\experiments\\boamosamatic'

MDR_PROJECT_ID = 'P000000420'       # PORSCH trial
MDR_COLLECTION_ID = 'C000000002'    # PORSCH trial CT scans

LOCAL_L3_DIR = 'D:\\Mosamatic\\NicoleHildebrand\\PORSCH\\L3'
LOCAL_ZIP_DIR = 'D:\\Mosamatic\\NicoleHildebrand\\PORSCH\\ZIP'
LOCAL_UNZIPPED_DIR = 'D:\\Mosamatic\\NicoleHildebrand\\PORSCH\\UNZIPPED'
LOCAL_SCAN_DIR = 'D:\\Mosamatic\\NicoleHildebrand\\PORSCH\\SCANS'
LOCAL_SCAN_NIFTI_DIR = 'D:\\Mosamatic\\NicoleHildebrand\\PORSCH\\SCANS_NIFTI'
LOCAL_SCAN_NIFTI_L3_DIR = 'D:\\Mosamatic\\NicoleHildebrand\\PORSCH\\SCANS_NIFTI_L3'