from setuptools import setup
with open('requirements.txt') as f:
    install_requires = f.read().splitlines()

print(install_requires)
setup(
    name='RadiomicsModellingSuite',
    version='0.0.5',
    author='AllisonNg067',
    author_email='allison.ng@uwa.edu.au',
    description='Details about the package',
    packages=['RadiomicsModellingSuite'],
    # packages=['RadiomicsModellingSuite', 'RadiomicsModellingSuite.config'],
    # package_data={
    #     'RadiomicsModellingSuite': ['config/rules.yml'],
    # },
    include_package_data=True,
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    install_requires=install_requires,
)