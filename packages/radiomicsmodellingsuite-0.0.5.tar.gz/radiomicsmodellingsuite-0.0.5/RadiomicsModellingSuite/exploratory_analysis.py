import matplotlib.pyplot as plt
import seaborn as sns
import os
import textwrap
import numpy as np
import pandas as pd

def initial_exploration(data, filename='initial_exploration.txt'):
    """
    Performs an initial exploration on the dataset and reports results to text file.
    Details include number of duplicate/null values, description of the data, data shape, column names, and number of columns with all same features across patients.
    
    Parameters:
    
    * data (pandas DataFrame): dataframe containing data
    
    * filename (str): name of file to save result to
    
    Output:
    
    * Text file with exploration of dataset. 
    """
    nulls = data.isnull().sum() #calculate number of missing values per column
    non_unique_columns = data.nunique().gt(1)

    false_columns = non_unique_columns[non_unique_columns].index.tolist()
    true_columns = [col for col in data.columns if col not in false_columns]
    # Print or use the result
    with open(filename, "w") as f:
        f.write("Data Head\n")
        f.write(str(data.head())) #first 5 rows
        f.write("\nData Describe\n")
        f.write(str(data.describe()))
        f.write("\nData Isnull\n")
        f.write(str(nulls)) #number of missing values per column
        if nulls[nulls != 0].empty: #write columns with missing values
            f.write('\nno missing values\n')
        else:
            f.write(f"\n{nulls[nulls != 0].index}")
        f.write("\nData Duplicated\n")
        f.write(str(data.duplicated().sum())) #check for duplicate data
        f.write("\nData Shape\n")
        f.write(str(data.shape)) #report data shape
        f.write("\nData Columns\n")
        f.write(str(data.columns)) #report column names
        f.write("\nNumber of Columns where Features are All the Same across Patients\n")
        f.write(str(len(true_columns)))
        f.write("\nNumber of Columns where Features Vary across Patients\n")
        f.write(str(len(false_columns)))

def visualise_target(data, plot_directory, survival, figure_size=(12,12), font_sizes={'title':30, 'axes_title':20, 'axes_tick':16}):
    """
    Visualises target variable
    
    Parameters:
    
    * data (pandas DataFrame): dataframe containing data
    
    * plot_directory (str): directory to save plots
    
    * survival (Boolean): If True, plot survival time
    
    * figure_size (tuple): figure size (width, height) in inches
    
    * font_sizes (dict): dictionary containing font sizes to use
    
    Output:
    
    * bar plot of target variable values
    """
    if not os.path.isdir(plot_directory):
    # if the directory is not present then create it
        os.makedirs(plot_directory)
    os.chdir(plot_directory)
    if not survival:
        target = [column for column in data.columns if "target" in column][0]
        target_name = target[7:]
        plt.figure(figsize=figure_size)
        sns.countplot(x=target, data=data)
    else:
        target = data['target_survival']
        target_name = 'Survival Time'
        plt.figure(figsize=figure_size)
        plt.hist(target, bins=30)
    plt.title(f'Distribution of {target_name}', fontsize=font_sizes['title'])
    plt.xlabel(target_name, fontsize=font_sizes['axes_title'])
    plt.xticks(size=font_sizes['axes_tick'])
    plt.ylabel('Count', fontsize=font_sizes['axes_title'])
    plt.yticks(size=font_sizes['axes_tick'])
    plt.savefig('target_distribution.png')
    plt.close() 
    os.chdir("..")

def visualise_numerical(data, plot_directory, target, target_name, survival, num_numerical=10, figure_size=(12,12), font_sizes={'title':30, 'axes_title':20, 'axes_tick':16}):
    """
    Visualises variables
    
    Parameters:
    
    * data (pandas DataFrame): dataframe containing data
    
    * plot_directory (str): directory to save plots
    
    * target (pandas Series): target
    
    * target_name (str): name of target
    
    * survival (boolean): Set to True if target is survival data
    
    * num_numerical (int): number of numerical vairables to visualise
    
    * figure_size (tuple): figure size (width, height) in inches

    * font_sizes (dict): dictionary containing font sizes to use

    Output:
    
    * histograms with kernel density estimate of numerical variable values
    
    * box plots of numerical variable values split according to target value
    
    * violin plots of numerical variable values split according to target value
    """
    if not os.path.isdir(plot_directory):
    # if the directory is not present then create it
        os.makedirs(plot_directory)
    os.chdir(plot_directory)
    
    numerical_columns = data.select_dtypes(include='float64').columns.tolist()  
    if not survival:
        combined_data = data.copy()
        combined_data.loc[:, target_name] = target.values
    for i, col in enumerate(numerical_columns, 1):
        col_format = col.replace("_", " ")
        if i > num_numerical:
            break
        plt.figure(figsize=figure_size)
        sns.histplot(data[col], kde=True)
        plt.title('\n'.join(textwrap.wrap(f'Distribution of {col_format}', 41)), fontsize=font_sizes['title'])
        plt.xlabel('\n'.join(textwrap.wrap(col_format, 41)), fontsize=font_sizes['axes_title'])
        plt.xticks(size=font_sizes['axes_tick'])
        plt.yticks(size=font_sizes['axes_tick'])
        plt.ylabel('Count', fontsize=font_sizes['axes_title'])
        plt.tight_layout()
        plt.savefig(f'{col}_hist.png')
        plt.close()
        if not survival:
            plt.figure(figsize=figure_size)
            sns.boxplot(x=target_name, y=col, data=combined_data)
            plt.title('\n'.join(textwrap.wrap(f'{col_format} by {target_name} status', 40)), fontsize=font_sizes['title'])
            plt.xlabel(target_name, fontsize=font_sizes['axes_title'])
            plt.ylabel('\n'.join(textwrap.wrap(col_format, 41)), fontsize=font_sizes['axes_title'])
            plt.savefig(f'{col}_boxplot.png')
            plt.close()

            plt.figure(figsize=figure_size)
            sns.violinplot(x=target_name, y=col, data=combined_data)
            plt.title('\n'.join(textwrap.wrap(f'{col_format} by {target_name} status', 40)), fontsize=font_sizes['title'])
            plt.xlabel(target_name, fontsize=font_sizes['axes_title'])
            plt.ylabel('\n'.join(textwrap.wrap(col_format, 41)), fontsize=font_sizes['axes_title'])
            plt.savefig(f'{col}_violin.png')
            plt.close()
    os.chdir("..")

def visualise_categorical(data, plot_directory, target_name, figure_size=(12,12), font_sizes={'title':30, 'axes_title':20, 'axes_tick':16}):
    """
    Visualises variables
    
    Parameters:
    
    * data (pandas DataFrame): dataframe containing data
    
    * plot_directory (str): directory to save plots

    * target_name (str): target name

    * figure_size (tuple): figure size (width, height) in inches
    
    * font_sizes (dict): dictionary containing font sizes to use

    Output:
    
    * bar plots of categorical variable values
    
    * bar plots of categorical variable values by target status
    """
    if not os.path.isdir(plot_directory):
    # if the directory is not present then create it
        os.makedirs(plot_directory)
    os.chdir(plot_directory)
    object_columns = data.select_dtypes(include='object').columns.tolist()  #obtain list of columns with string values
    for i, col in enumerate(object_columns, 1):
        col_format = col.replace("_", " ")
        plt.figure(figsize=figure_size)
        sns.countplot(x=col, data=data)
        plt.title(f'Distribution of {col_format}', fontsize=font_sizes['title'])
        plt.xlabel(col_format, fontsize=font_sizes['axes_title'])
        plt.xticks(size=font_sizes['axes_tick'])
        plt.ylabel('Count', fontsize=font_sizes['axes_title'])
        plt.yticks(size=font_sizes['axes_tick'])
        plt.savefig(f'{col}_distribution.png')
        plt.close()

        plt.figure(figsize=figure_size)
        sns.countplot(x=col, hue=target, data=data)
        plt.title(f'Distribution of {col_format} by {target_name} status', fontsize=font_sizes['title'])
        plt.xlabel(col_format, fontsize=font_sizes['axes_title'])
        plt.xticks(size=font_sizes['axes_tick'])
        plt.ylabel('Count', fontsize=font_sizes['axes_title'])
        plt.yticks(size=font_sizes['axes_tick'])
        plt.savefig(f'{col}_distribution_with_target.png')
    os.chdir("..")

def visualise_correlation(data, plot_directory, target, target_name, num_numerical=10, figure_size=(12,12), font_sizes={'title':30, 'axes_title':20, 'axes_tick':16}):
    """
    Visualises correlation matrix of numerical variables using numbered labels.
    
    Parameters:
    
    * data (pandas DataFrame): dataframe containing data
    
    * plot_directory (str): directory to save plots

    * target (pandas Series): target

    * target_name (str): name of target

    * num_numerical (int): number of numerical variables to visualise

    * figure_size (tuple): figure size (width, height) in inches.

    * font_sizes (dict): dictionary containing font sizes to use
    
    Output:
    
    * correlation matrix heatmap of numerical values with numbered labels
    
    * text file mapping numbers to original feature names
    """
    if not os.path.isdir(plot_directory):
        os.makedirs(plot_directory)
    os.chdir(plot_directory)

    selected_columns = np.random.choice(data.columns, size=min(num_numerical, len(data)), replace=False)
    selected_data = data[selected_columns]
    # Create mapping from numbers to original column names
    original_columns = selected_data.columns.tolist()
    numbered_columns = [f"F{i+1}" for i in range(len(original_columns))]
    mapping = dict(zip(numbered_columns, original_columns))
    # Save mapping to text file
    with open("feature_number_mapping_correlation.txt", "w") as f:
        for num, name in mapping.items():
            f.write(f"{num}: {name}\n")

    # Rename columns in the data
    selected_data.columns = numbered_columns
    # Plot correlation matrix
    plt.figure(figsize=(max(figure_size[0], len(numbered_columns) * 0.6), max(figure_size[1], len(numbered_columns)*0.6)))
    heatmap = sns.heatmap(selected_data.corr(), annot=True, cmap='coolwarm', fmt='.2f', cbar_kws={'label': 'Pearson Correlation'}, vmin=-1, vmax=1)
    # Format axis labels
    heatmap.set_xticklabels(heatmap.get_xticklabels(), rotation=45, ha='right', fontsize=font_sizes['axes_tick'])
    heatmap.set_yticklabels(heatmap.get_yticklabels(), rotation=0, fontsize=font_sizes['axes_tick'])
    # Set title and layout
    plt.title('Correlation Matrix', fontsize=font_sizes['title'])
    plt.tight_layout()
    # Save plot
    plt.savefig('correlation_matrix.png')
    plt.close()
    # Compute correlation with the target variable
    correlations = selected_data.corrwith(target.squeeze())
    # Create a bar plot
    plt.figure(figsize=figure_size)
    correlations.sort_values().plot(kind='bar')
    plt.xlabel('Correlation with Target', fontsize=font_sizes['axes_title'])
    plt.ylabel('Features', fontsize=font_sizes['axes_title'])
    plt.title(f'Feature Pearson Correlation with Target: {target_name}', fontsize=font_sizes['title'])
    plt.tight_layout()
    plt.savefig('target_correlation_plot.png')
    plt.close()
    os.chdir("..")


def visualise_variables(data, plot_directory, survival, num_numerical=10, figure_size=(12,12), font_sizes={'title':30, 'axes_title':20, 'axes_tick':16}):
    """
    Visualises variables
    
    Parameters:
    
    * data (pandas DataFrame): dataframe containing data
    
    * plot_directory (str): directory to save plots
    
    * survival (boolean): Set to True if target is survival data
    
    * num_numerical (int): number of numerical vairables to visualise
    
    * figure_size (tuple): figure size (width, height) in inches
    
    * font_sizes (dict): dictionary containing font sizes to use
    
    Output:
    
    * bar plot of target variable values
    
    * histograms with kernel density estimate of numerical variable values
    
    * box plots of numerical variable values split according to target value
    
    * violin plots of numerical variable values split according to target value
    
    * bar plots of categorical variable values
    
    * bar plots of categorical variable values by target status
    
    * correlation matrix heatmap of numerical values
    """
    visualise_target(data, plot_directory, survival, figure_size=figure_size, font_sizes=font_sizes)
    if survival:
        target = [column for column in data.columns if "target" in column]
        target_name = 'target'
    else:
        target = [[column for column in data.columns if "target" in column][0]]
        target_name = target[0]
        
    target = data[target]
    data = data.drop(columns=target, inplace=False)
    numerical_data = data.select_dtypes(include=['number'])      
    # Randomly select num_numerical columns
    selected_columns = np.random.choice(numerical_data.columns, size=min(num_numerical, len(numerical_data)), replace=False)
    # Create subset DataFrame
    numerical_data = data[selected_columns]
    visualise_numerical(numerical_data, plot_directory, target, target_name, survival, num_numerical=num_numerical, figure_size=figure_size, font_sizes=font_sizes)
    visualise_categorical(data, plot_directory, target_name, figure_size=figure_size, font_sizes=font_sizes)
    visualise_correlation(numerical_data, plot_directory, target, target_name, num_numerical=num_numerical, figure_size=figure_size, font_sizes=font_sizes)