from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.model_selection import KFold, cross_val_score, ParameterGrid
from sklearn.utils.class_weight import compute_class_weight
import numpy as np
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestClassifier
from . import latex_reporting as lr
from sklearn.tree import DecisionTreeClassifier, plot_tree
import xgboost as xgb
from lifelines import KaplanMeierFitter, CoxPHFitter, WeibullAFTFitter, LogNormalAFTFitter, LogLogisticAFTFitter
import pandas as pd
from lifelines.utils import k_fold_cross_validation, concordance_index
import itertools
import joblib
from itertools import zip_longest
import matplotlib.pyplot as plt
import pickle
import os

def cross_validate_grid_search(X, y, model, hyperparameters, scoring, author, n_splits=5, n_rounds=5, kind='sklearn', directory=".//logistic_regression_training", filename='cross_validation_report'):
  """
    Perform cross-validation to find the best hyperparameters for a given model
    
    Parameters: 
    
    * X (pandas DataFrame): features
    
    * y (pandas Series): target
    
    * model (sklearn model): model to use for cross-validation
    
    * hyperparameters (dict): Dictionary of lists of hyperparameter values to search over
    
    * scoring (str): scoring metric for cross-validation
    
    * author (str): name of the author for reporting
    
    * n_splits (int): number of splits for cross-validation
    
    * n_rounds (int): number of gradient boosting rounds
    
    * kind (str): type of model

    * directory (str): directory to save model and report
    
    * filename (str): filename to save report
    
    Returns:
    
    * best_params: best hyperparameters found during cross-validation

    Outputs:

    * cross-validation report as PDF and latex files
  """
  if kind.lower() == 'sklearn':
    # KFold split
    cv = KFold(n_splits=n_splits)
    # Initialize GridSearchCV with the LogisticRegression and parameter grid
    grid_search = GridSearchCV(estimator=model, param_grid=hyperparameters, scoring=scoring, cv=cv)

    # Fit the grid search to the training data
    grid_search.fit(X, y) 
  #cross_validation_report(author,  n_splits, scoring, hyperparameter_grid, best_hyperparameters, best_score, cv_results, filename='cross_validation_report')
    lr.cross_validation_report(author, n_splits, scoring, grid_search.param_grid, grid_search.best_params_, grid_search.best_score_, grid_search.cv_results_, directory=directory, filename=filename)
    return grid_search.best_params_
  elif kind.lower() == 'xgboost':
    train_data = xgb.DMatrix(X, label=y)
    grid = list(ParameterGrid(hyperparameters))
    best_score = np.inf
    cv_results_dict = {'params': []}
    for name in hyperparameters.keys():
      cv_results_dict.update({f'params_{name}': []})
    cv_results_dict.update({f'tree{i}_test_score_mean': [] for i in range(n_rounds)})
    cv_results_dict.update({f'tree{i}_test_score_std': [] for i in range(n_rounds)})
    for point in grid:
      # Perform cross-validation to find the best hyperparameters
      cv_results = xgb.cv(
          point,
          train_data,
          n_rounds,
          nfold=n_splits,
          metrics={scoring},
      seed=0,
      callbacks=[xgb.callback.EvaluationMonitor(show_stdv=True)]
  ) #cv_results has shape (n_rounds, 4)
      # print(cv_results)
      # print(cv_results.shape)
      if np.mean(cv_results[f'test-{scoring}-mean']) < best_score:
        best_params = point
        best_score = np.mean(cv_results[f'test-{scoring}-mean'])     
      #updating dictionary of cv results
      cv_results_dict['params'].append(point)
      for name in point.keys():
        cv_results_dict[f'params_{name}'].append(point[name])
      for i in range(n_rounds):
        cv_results_dict[f'tree{i}_test_score_mean'].append(cv_results[f'test-{scoring}-mean'][i])
        cv_results_dict[f'tree{i}_test_score_std'].append(cv_results[f'test-{scoring}-std'][i])
    lr.cross_validation_report(author, n_splits, scoring, hyperparameters, best_params, best_score, cv_results_dict, directory=directory, filename=filename)
    os.chdir("..")
    return best_params

def logistic_regression(X_train, y_train, cross_validate, hyperparameters, scoring, author, n_splits=5, random_state=42, directory=".//logistic_regression_training", cv_filename="logistic_regression_cross_validation_report", model_filename="logistic_regression_model"):
  """
    Train a logistic regression model on the provided training data.
    
    Parameters:
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * cross_validate (bool): If True, perform cross-validation to find the best hyperparameters
    
    * hyperparameters (dict): hyperparameters for the model if not cross-validating. If cross-validating, this should be a dictionary of lists of hyperparameter values to search over
    
    * scoring (str): scoring metric for cross-validation
    
    * author (str): name of the author for reporting
    
    * n_splits (int): number of splits for cross-validation
    
    * random_state (int): random state for reproducibility

    * directory (str): directory to save model and report
    
    * cv_filename (str): filename to save cross-validation report
    
    * model_filename (str): filename to save trained model
    
    Returns:
    
    * LR (LogisticRegression): trained logistic regression model
  """
  os.makedirs(directory, exist_ok=True)
  class_weights = compute_class_weight(class_weight='balanced', classes=np.unique(y_train), y=y_train)
  class_weights = dict(enumerate(class_weights))
  LR = LogisticRegression(random_state=random_state, solver='saga', max_iter=1000, class_weight=class_weights)
  if cross_validate:
    # Perform cross-validation to find the best hyperparameters
    best_hyperparameters = cross_validate_grid_search(X_train, y_train, LR, hyperparameters, scoring, author, n_splits=n_splits, directory=directory, filename=cv_filename)
    LR = LogisticRegression(random_state=random_state, max_iter=1000, solver='saga', **best_hyperparameters, class_weight=class_weights)
  else:
    # If not cross-validating, use the provided hyperparameters directly
    LR.set_params(**hyperparameters)
    os.chdir(directory)
  LR.fit(X_train, y_train)
  joblib.dump(LR, f'{model_filename}.joblib')
  os.chdir("..")
  return LR

def decision_tree_classification(X_train, y_train, cross_validate, hyperparameters, scoring, author, n_splits=5, random_state=42, directory=".//decision_tree_training", cv_filename="decision_tree_cross_validation_report", model_filename="decision_tree_model"):
  """
    Train a decision tree model on the provided training data.
    
    Parameters:
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * cross_validate (bool): If True, perform cross-validation to find the best hyperparameters
    
    * hyperparameters (dict): hyperparameters for the model if not cross-validating. If cross-validating, this should be a dictionary of lists of hyperparameter values to search over
    
    * scoring (str): scoring metric for cross-validation
    
    * author (str): name of the author for reporting
    
    * n_splits (int): number of splits for cross-validation
    
    * random_state (int): random state for reproducibility

    * directory (str): directory to save model and report
    
    * cv_filename (str): filename to save cross-validation report

    * model_filename (str): filename to save trained model
    
    Returns:
    
    * DT (DecisionTreeClassifier): trained decision tree model
  """
  os.makedirs(directory, exist_ok=True)
  class_weights = compute_class_weight(class_weight='balanced', classes=np.unique(y_train), y=y_train)
  class_weights = dict(enumerate(class_weights))
  DT = DecisionTreeClassifier(random_state=random_state, class_weight=class_weights)
  if cross_validate:
    # Perform cross-validation to find the best hyperparameters
    best_hyperparameters = cross_validate_grid_search(X_train, y_train, DT, hyperparameters, scoring, author, n_splits=n_splits, filename=cv_filename)
    DT = DecisionTreeClassifier(random_state=random_state, **best_hyperparameters)
  else:
    # If not cross-validating, use the provided hyperparameters directly
    DT.set_params(**hyperparameters)
    os.chdir(directory)
  DT.fit(X_train, y_train)

  # Make sure DT is your trained DecisionTreeClassifier and X_train is your training DataFrame
  plt.figure(figsize=(40, 30))  # Increase figure size for better layout
  plot_tree(DT,
            feature_names=list(X_train.columns),
            filled=True,
            fontsize=14)  # Increase font size for readability

  plt.savefig('decision_tree.png')
  plt.close()
  lr.decision_tree_structure_report(author, X_train, DT, 'decision_tree.png', filename='decision_tree_structure')
  joblib.dump(DT, f'{model_filename}.joblib')
  os.chdir("..")
  return DT

def svm_classification(X_train, y_train, cross_validate, hyperparameters, scoring, author, n_splits=5, random_state=42, directory=".//svm_training", cv_filename="svm_cross_validation_report", model_filename="svm_model"):
  """
    Train a support vector machine model on the provided training data.

        Parameters:
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * cross_validate (bool): If True, perform cross-validation to find the best hyperparameters
    
    * hyperparameters (dict): hyperparameters for the model if not cross-validating. If cross-validating, this should be a dictionary of lists of hyperparameter values to search over
    
    * scoring (str): scoring metric for cross-validation
    
    * author (str): name of the author for reporting
    
    * n_splits (int): number of splits for cross-validation
    
    * random_state (int): random state for reproducibility

    * directory (str): directory to save model and report
    
    * cv_filename (str): filename to save cross-validation report

    * model_filename (str): filename to save trained model
    
    Returns:
    
    * SVM (SVC): trained support vector machine model
  """
  os.makedirs(directory, exist_ok=True)
  class_weights = compute_class_weight(class_weight='balanced', classes=np.unique(y_train), y=y_train)
  class_weights = dict(enumerate(class_weights))
  SVM = SVC(random_state=random_state, class_weight=class_weights)
  if cross_validate:
    # Perform cross-validation to find the best hyperparameters
    best_hyperparameters = cross_validate_grid_search(X_train, y_train, SVM, hyperparameters, scoring, author, n_splits=n_splits, filename=cv_filename)
    SVM = SVC(random_state=random_state, **best_hyperparameters)
  else:
    # If not cross-validating, use the provided hyperparameters directly
    SVM.set_params(**hyperparameters)
    os.chdir(directory)
  SVM.fit(X_train, y_train)
  joblib.dump(SVM, f'{model_filename}.joblib')
  os.chdir("..")
  return SVM

def random_forest_classification(X_train, y_train, cross_validate, hyperparameters, scoring, author, n_splits=5, random_state=42, directory=".//random_forest_training", cv_filename="random_forest_cross_validation_report", model_filename="random_forest_model"):
  """
    Train a random forest model on the provided training data.

    Parameters:
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * cross_validate (bool): If True, perform cross-validation to find the best hyperparameters
    
    * hyperparameters (dict): hyperparameters for the model if not cross-validating. If cross-validating, this should be a dictionary of lists of hyperparameter values to search over
    
    * scoring (str): scoring metric for cross-validation
    
    * author (str): name of the author for reporting
    
    * n_splits (int): number of splits for cross-validation
    
    * random_state (int): random state for reproducibility

    * directory (str): directory to save model and report
    
    * cv_filename (str): filename to save cross-validation report

    * model_filename (str): filename to save trained model
    
    Returns:
    
    * RF (RandomForestClassifier): trained random forest model
  """
  os.makedirs(directory, exist_ok=True)
  class_weights = compute_class_weight(class_weight='balanced', classes=np.unique(y_train), y=y_train)
  class_weights = dict(enumerate(class_weights))
  RF = RandomForestClassifier(random_state=random_state, class_weight=class_weights)
  if cross_validate:
    # Perform cross-validation to find the best hyperparameters
    best_hyperparameters = cross_validate_grid_search(X_train, y_train, RF, hyperparameters, scoring, author, n_splits=n_splits, filename=cv_filename)
    RF = RandomForestClassifier(random_state=random_state, **best_hyperparameters)
  else:
    # If not cross-validating, use the provided hyperparameters directly
    RF.set_params(**hyperparameters)
    os.chdir(directory)
  RF.fit(X_train, y_train)
  joblib.dump(RF, f'{model_filename}.joblib')
  os.chdir("..")
  return RF

def xgboost_classification(X_train, y_train, cross_validate, hyperparameters, scoring, author, n_splits=5, num_round=100, random_state=42, directory=".//xgboost_training", cv_filename="xgboost_cross_validation_report", model_filename="xgboost_model"):
  """
    Train an XGBoost model on the provided training data.

    Parameters:
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * cross_validate (bool): If True, perform cross-validation to find the best hyperparameters
    
    * hyperparameters (dict): hyperparameters for the model if not cross-validating. If cross-validating, this should be a dictionary of lists of hyperparameter values to search over
    
    * scoring (str): scoring metric for cross-validation
    
    * author (str): name of the author for reporting
    
    * n_splits (int): number of splits for cross-validation
    
    * random_state (int): random state for reproducibility

    * directory (str): directory to save model and report
    
    * cv_filename (str): filename to save cross-validation report

    * model_filename (str): filename to save trained model

    Returns:
    
    * XGB (XGBClassifier): trained XGBoost model
  """
  os.makedirs(directory, exist_ok=True)
  XGB = xgb.XGBClassifier(random_state=random_state, use_label_encoder=False, eval_metric=scoring, scale_pos_weight=np.bincount(y_train)[0] / np.bincount(y_train)[1])
  if cross_validate:
    best_hyperparameters = cross_validate_grid_search(X_train, y_train, XGB, hyperparameters, scoring, author, n_splits=n_splits, n_rounds=num_round, kind='xgboost', filename=cv_filename)
    XGB.set_params(**best_hyperparameters)
  else:
    # If not cross-validating, use the provided hyperparameters directly
    XGB.set_params(**hyperparameters)
    os.chdir(directory)
  XGB.fit(X_train, y_train)
  joblib.dump(XGB, f'{model_filename}.joblib')
  os.chdir("..")
  return XGB

def lifelines_grid_search(params, df, author, scoring='concordance_index', n_splits=5, random_state=42, filename="cross_validation_report"):
  """
  Implement grid search

  Parameters:
  * params (dict): Dictionary of lists of hyperparameter values to search over
    
  * df (pandas DataFrame): features and target in single dataframe
    
  * author (str): author name
    
  * scoring (str): scoring metric for cross-validation
    
  * n_splits (int): number of splits for cross-validation
    
  * random_state (int): random state for cross validation split

  Returns:

  * best_params (dict): best hyperparameters found during cross-validation
  """
  
  best_score = -1*np.inf
  best_params = None
  cv_info = {'params': [], 'average_scores': []}
  trial = 1
  for penalizer, l1_ratio in itertools.product(params['penalizer'], params['l1_ratio']):
      cph = CoxPHFitter(penalizer=penalizer, l1_ratio=l1_ratio)
      scores = k_fold_cross_validation(cph, df, duration_col = 'target_survival', event_col = 'target_survival_status', scoring_method=scoring, k=n_splits, seed=random_state)
      avg_score = sum(scores) / len(scores)
      cv_info['params'].append({'penalizer': penalizer, 'l1_ratio': l1_ratio})
      cv_info[f'parameter_set_{trial}_scores'] = scores
      cv_info['average_scores'].append(avg_score)
      if avg_score > best_score:
          best_score = avg_score
          best_params = {'penalizer': penalizer, 'l1_ratio': l1_ratio}
      trial += 1
  lr.cross_validation_report(author, n_splits, scoring, params, best_params, best_score, cv_info, filename=filename)
  return best_params


def kaplan_meier_survival(X_train, y_train):
  """
    Train a Kaplan-Meier survival model on the provided training data.

    Parameters:

    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    Returns:
    
    * kaplan_models (dict): dictionary of Kaplan Meier models for each variable

    * kmf_full (KaplanMeierFitter): Kaplan Meier model for the full dataset

    * filenames (list): list of filenames of saved Kaplan Meier models
  """
  data = pd.concat([X_train, y_train], axis=1)
  kaplan_models = {}
  filenames = []
  for col in X_train.columns:
      kmf_low = KaplanMeierFitter()
      kmf_high = KaplanMeierFitter()
      if not col.startswith("categorical_"):    
        median = data[col].median()
        data_low = data[data[col] <= median]        
        data_high = data[data[col] > median]      
      else:
        data_low = data[data[col] == 0]
        data_high = data[data[col] == 1]
      kmf_low.fit(durations=data_low['target_survival'], event_observed=data_low['target_survival_status'])
      with open(f'kaplan_meier_low_{col}.pkl', 'wb') as file:
        pickle.dump(kmf_low, file)
      filenames.append(f'kaplan_meier_low_{col}.pkl')
      kmf_high.fit(durations=data_high['target_survival'], event_observed=data_high['target_survival_status'])
      with open(f'kaplan_meier_high_{col}.pkl', 'wb') as file:
        pickle.dump(kmf_high, file)
      filenames.append(f'kaplan_meier_high_{col}.pkl')
      kaplan_models[col] = (kmf_low, kmf_high)
  kmf_full = KaplanMeierFitter()
  kmf_full.fit(durations=data['target_survival'], event_observed=data['target_survival_status'])
  with open(f'kaplan_meier_full.pkl', 'wb') as file:
        pickle.dump(kmf_full, file)
  filenames.append('kaplan_meier_full.pkl')
  return kaplan_models, kmf_full, filenames

def survival_regression_models(X_train, y_train, X_test, y_test, author, cross_validate, hyperparameters, n_splits=5, filename="cross_validation_report", models={
  "CoxProportionalHazards": CoxPHFitter(),
        "WeibullAFTFitter": WeibullAFTFitter(),
        "LogNormalAFTFitter": LogNormalAFTFitter(),
        "LogLogisticAFTFitter": LogLogisticAFTFitter()
    }):
    """
    Fit various survival models to the training data.

    Parameters:
    
    * X_train (pandas DataFrame): features
    
    * y_train (pandas Series): target
    
    * X_test (pandas DataFrame): test features
    
    * y_test (pandas Series): test target
    
    * author (str): name of the author for reporting
    
    * cross_validate (bool): If True, perform cross-validation to find the best hyperparameters
    
    * hyperparameters (dict): hyperparameters for the model if not cross-validating. If cross-validating, this should be a dictionary of lists of hyperparameter values to search over
    
    * n_splits (int): number of cross validation folds
    
    * filename (str): filename to save cross validation results to
    
    * models (dict): dictionary of models to fit

    Returns:
    
    * trained_models (list[AFT Model]): list of trained AFT models
    
    * linear_predictors_train (pandas DataFrame): DataFrame of linear predictors for each model on the training data
    
    * linear_predictors_test (pandas DataFrame): DataFrame of linear predictors for each model on the test data
    """
    df = pd.concat([X_train, y_train], axis=1)
    trained_models = []
    linear_predictors_train = {}
    linear_predictors_test = {}
    for name, model in models.items():
        if cross_validate:
          best_hyperparameters = lifelines_grid_search(hyperparameters, df, author, n_splits=n_splits, filename=f'{name}_{filename}')
          model.penalizer = best_hyperparameters['penalizer']
          model.l1_ratio = best_hyperparameters['l1_ratio']
        else:
          model.penalizer = hyperparameters['penalizer']
          model.l1_ratio = hyperparameters['l1_ratio']
        model.fit(df, duration_col='target_survival', event_col='target_survival_status')
        with open(f'{name}.pkl', 'wb') as file:
          pickle.dump(model, file)
        trained_models.append((name, model))
        if 'cox' in name.lower():
          linear_predictors_train[name] = np.dot(X_train.values, model.params_.values)
          linear_predictors_test[name] = np.dot(X_test.values, model.params_.values)
        else:
          linear_predictors_train[name] = np.dot(np.c_[X_train.values, np.ones(X_train.shape[0])], model.params_.values[:-1])
          linear_predictors_test[name] = np.dot(np.c_[X_test.values, np.ones(X_test.shape[0])], model.params_.values[:-1])
    linear_predictors_train = pd.DataFrame(linear_predictors_train)
    linear_predictors_test = pd.DataFrame(linear_predictors_test)
    return trained_models, linear_predictors_train, linear_predictors_test