import numpy as np
import dicom2nifti
import six
from functools import partial
dicom2nifti.settings.disable_validate_slice_increment()
from pylatex import Document, Section, Subsection, Command, Table, Tabular, Figure, NoEscape, LongTable, Package
from pylatex.utils import NoEscape, bold, escape_latex
from . import string_formatting as sf
import inspect
import matplotlib
matplotlib.use("Agg")            # no need for X server
import matplotlib.pyplot as plt  # noqa
import pandas as pd
import seaborn as sns
import os

def get_arg_names(func):
    sig = inspect.signature(func)
    return [param.name for param in sig.parameters.values() if param.default is inspect.Parameter.empty]

def report_header(author, title):
    """
    Initialise the document with author and title and today's date as header

    Parameters:
    author (str): author name
    title (str): title

    Returns:
    doc (pylatex document): document with header
    """
    doc = Document()       
    doc.append(Command('title', title))
    doc.append(Command('author', author))
    doc.append(Command('date', NoEscape(r'\today')))
    doc.append(NoEscape(r'\maketitle'))
    return doc

def report_end(doc, filename, pdf=True):
    """
    Finalise the document by generating the PDF and TeX files.

    Parameters:
    doc (pylatex document): document to finalize
    filename (str): base filename (without extension)
    pdf (bool): whether to generate PDF

    Output:
    *.tex file
    *.pdf file if pdf=True
    """
    print("Starting PDF generation...")
    if pdf:
        doc.generate_pdf(filename, compiler='pdflatex', clean=False)
    doc.generate_tex(filename)
    print("PDF generation complete.")

def prospective_sample_size_binary_report(proportion, n_features, mean_absolute_prediction_error, margin_of_error, confidence_level, shrinkage, r_cs, optimism, sample_sizes, author, title='Sample Size Report', filename='sample_size_report'):
       """
       Code to report required sample size for a binary classification model.

       Parameters:
        proportion (float): anticipated outcome proportion
        n_features (integer): number of features, including polynomial transformations of features (candidate predictor variables)       
        mean_absolute_prediction_error (float): average error allowed in model's estimated outcome probability
        margin_of_error (float): margin of error for confidence interval
        confidence_level (float): level of confidence for confidence interval
        shrinkage (float): expected uniform shrinkage factor desired
        r_cs (float): Anticipated r^2 cs value. Ignored if r_nagelkerke specified instead
        r_nagelkerke (float): Anticipated r^2 nagelkerke value.
        sample_sizes (list): list of sample sizes obtained.
        author (str): author's name
        optimism (float): Desired optimism value
        title (str): Report title
       """
       doc = report_header(author, title)
       doc.append(f"The outcome proportion is {proportion}, and the number of features in the model is {n_features}.\n")
       doc.append(f"Anticipated Cox-Snell r^2 is {r_cs}.\n")
       doc.append(f"Sample size required for the {confidence_level*100}% confidence interval to have a maximum margin of error of {margin_of_error} is {sample_sizes[0]}.\n")
       doc.append(f"Sample size required for a mean absolute prediction error of {mean_absolute_prediction_error} is {sample_sizes[1]}.\n")
       doc.append(f"Sample size required for a shrinkage factor of {shrinkage} is {sample_sizes[2]}.\n")
       doc.append(f"Sample size required for an optimism of {optimism} for r^2 Nagelkerke is {sample_sizes[3]}.\n")
       doc.append(f"Therefore maximum sample size required is {max(sample_sizes)}.\n")
       doc.append(f"This corresponds to events per predictor of {max(sample_sizes)*proportion/n_features}.")
       report_end(doc, filename)

def prospective_num_features_binary_report(proportion, sample_size, mean_absolute_prediction_error, margin_of_error, confidence_level, shrinkage, r_cs, optimism, num_features, author, title='Sample Size Report', filename='num_features_report'):
    """
       Code to report required sample size for a binary classification model.

       Parameters:
        proportion (float): anticipated outcome proportion
        sample_size (integer): sample size       
        mean_absolute_prediction_error (float): average error allowed in model's estimated outcome probability
        margin_of_error (float): margin of error for confidence interval
        confidence_level (float): level of confidence for confidence interval
        shrinkage (float): expected uniform shrinkage factor desired
        r_cs (float): Anticipated r^2 cs value. Ignored if r_nagelkerke specified instead
        r_nagelkerke (float): Anticipated r^2 nagelkerke value.
        num_features (list): list of number of features obtained.
        author (str): author's name
        optimism (float): Desired optimism value
        title (str): Report title
    """
    doc = report_header(author, title)
    doc.append(f"The outcome proportion is {proportion}, and the sample size is {sample_size}.\n")
    doc.append(f"Anticipated Cox-Snell r^2 is {r_cs}.\n")
    doc.append(f"Number of features required for a mean absolute prediction error of {mean_absolute_prediction_error} is {num_features[0]}.\n")
    doc.append(f"Number of features required for a shrinkage factor of {shrinkage} is {num_features[1]}.\n")
    doc.append(f"Number of features required for an optimism of {optimism} for r^2 Nagelkerke is {num_features[2]}.\n")
    doc.append(f"Therefore minimum number of features required is {min(num_features)}.\n")
    doc.append(f"This corresponds to events per predictor of {sample_size*proportion/min(num_features)}.")
    report_end(doc, filename)

def create_latex_value_counts_table(label, content):
    """
    Creates a LaTeX table for value counts of a given Series.

    Parameters:
        label (str): The label for the table (e.g., the name of the column).
        content (pandas.Series): The Series containing the data to summarize.

    Returns:
        pylatex.Table: A LaTeX table containing the value counts.
    """
    counts = content.value_counts()
    table_wrapper = Table(position='htbp')
    table_wrapper.add_caption(f'Value counts for {sf.remove_camel_case(label)}.')

    tabular = Tabular("c|c")
    tabular.add_hline()
    tabular.add_row((bold("Value"), bold("Counts")))
    tabular.add_hline()

    for val, cnt in counts.items():
        tabular.add_row((val, cnt))

    tabular.add_hline()
    table_wrapper.append(tabular)
    return table_wrapper

def create_latex_text(text, label, content, numerical=True):
    """
    Creates latex text for a given Series

    Parameters:
        text (str): The text to append to.
        label (str): The label for the table (e.g., the name of the column).
        content (pandas.Series): The Series containing the data to summarize.
        numerical (bool): If True, report median and range of numerical acquisition parameters, otherwise report value counts.

    Returns:
        text: A LaTeX table containing the value counts.
    """
    if numerical: #report median and range of numerical acquisition parameters
        clean_content = content.dropna()

        median = np.median(clean_content)
        min = np.min(clean_content)
        max = np.max(clean_content)
        if min == max:
          text += (f"The {sf.remove_camel_case(label)} had a value of {min:.3f} for all patients.") 
        else:       
          text += (f"The {sf.remove_camel_case(label)} had a median value of {median:.3f} and range of values [{min:.3f}, {max:.3f}]. ")  # Write the label of the acquisition parameter
    else:        
        counts = content.value_counts()
        if label == 'AttenuationCorrectionMethod': #split attenuation correction method and remove excess commas
            formatted_counts = ', '.join([f"{parts[0]} | {parts[1]} (n={cnt})" for val, cnt in counts.items() for parts in [[p.strip() for p in val.split(',') if p.strip()]]])

        else:
          formatted_counts = ', '.join([f"{val} (n={cnt})" for val, cnt in counts.items()])
        if len(counts) == 1 or label == 'ImageDimensions': #format plurals correctly
          text += (f"The {sf.remove_camel_case(label)} used was {formatted_counts}. ")
        else:
          text += (f"The {sf.remove_camel_case(label)}s used include {formatted_counts}. ")
    return text

def latex_information_section(acquisition_df, numerical_keys):
    """
    Creates information section for latex file with summary of acquisition parameters

    Parameters:
        acquisition_df (pandas DataFrame): dataframe with acquisition parameters
        numerical_keys (list): list of keys with numerical values

    Returns:
        section: A LaTeX section containing the summary of acquisition parameters.
    """  

    section = Section('Information')
    text = ""

    text = ""
    for label, content in acquisition_df.items():
      if label == 'SeriesDescription':
         continue
      if not content.value_counts().empty:
        if label in numerical_keys:
          median = np.nanmedian(content)
          min = np.nanmin(content)
          max = np.nanmax(content)        
          text += (f"The {label} had a median value of {median} and range of values [{min}, {max}]. ")  # Write the label of the acquisition parameter
        else:
                     
          counts = content.value_counts()
          formatted_counts = ', '.join([f"{val} (n={cnt})" for val, cnt in counts.items()])
          text += (f"The {label} used include {formatted_counts}. ")

    section.append(text)
    return section

def latex_paragraphs_section(acquisition_df, paragraphs, numerical_keys):
   """
    Creates section for latex file with summary of acquisition parameters, divided into paragraphs for readability

    Parameters:
        acquisition_df (pandas DataFrame): dataframe with acquisition parameters
        paragraphs (list): list of lists containing keys in a given paragraph
        numerical_keys (list): list of keys with numerical values

    Output:
        section: A LaTeX section containing the summary of acquisition parameters divided into paragraphs according to paragraphs list.
    """  
   section = Section('Paragraphs')
   for paragraph in paragraphs: #loop through each paragraph
       paragraph_written = False
       paragraph_text = ""
       for label in paragraph: #loop through each label in the paragraph
          content = acquisition_df[label]
          if not content.value_counts().empty:
            paragraph_written = True
            paragraph_text = create_latex_text(paragraph_text, label, content, numerical=label in numerical_keys)
       if paragraph_written: #only add new line if something was written to the paragraph
          section.append(paragraph_text + "\n")
   return section

def latex_all_tables_section(acquisition_df, paragraphs):
  """
    Creates section for latex file where value counts are present in tables

    Parameters:
        acquisition_df (pandas DataFrame): dataframe with acquisition parameters
        paragraphs (list): list of lists containing keys in a given paragraph
        numerical_keys (list): list of keys with numerical values

    Output:
        section: A LaTeX section containing the value counts presented as tables
  """ 
  section = Section('All Tables')
  for label in [item for sublist in paragraphs for item in sublist]: #loop through each label in the paragraphs list
        content = acquisition_df[label]          
        if not content.value_counts().empty: #create table for each label if there is data
          table = create_latex_value_counts_table(label, content)
          section.append(table)        
          section.append(NoEscape(r'\vspace{0.5cm}')) #add a verticle space after each table
  return section

def latex_tables_section(acquisition_df, paragraphs, numerical_keys):
  """
    Creates section for latex file with summary of acquisition parameters, divided into paragraphs for readability and categorical values are present in tables

    Parameters:
        acquisition_df (pandas DataFrame): dataframe with acquisition parameters
        paragraphs (list): list of lists containing keys in a given paragraph
        numerical_keys (list): list of keys with numerical values

    Output:
        section: A LaTeX section containing the summary of acquisition parameters divided into paragraphs and categorical values presented as tables
    """  
  section = Section('Tables')
  for paragraph in paragraphs: #loop through each paragraph
    paragraph_written = False
    paragraph_text = ""
    for label in paragraph: #loop through each label in the paragraph
        content = acquisition_df[label]
        if not content.value_counts().empty:            
          if label in numerical_keys: #report median and range of numerical acquisition parameters
            paragraph_written = True
            paragraph_text = create_latex_text(paragraph_text, label, content, numerical=True)
          else: #otherwise create table for categorical values
            table = create_latex_value_counts_table(label, content)
            section.append(table)
            section.append(NoEscape(r'\vspace{0.5cm}'))
    if paragraph_written: #only add new line if something was written to the paragraph
      section.append(paragraph_text + "\n")
  return section

def latex_less_tables_section(acquisition_df, paragraphs, numerical_keys, max_string_length):
  """
    Creates section for latex file with summary of acquisition parameters, divided into paragraphs for readability and categorical values are present in tables

    Parameters:
        acquisition_df (pandas DataFrame): dataframe with acquisition parameters
        paragraphs (list): list of lists containing keys in a given paragraph
        numerical_keys (list): list of keys with numerical values
        max_string_length (int): maximum number of count values to write in a paragraph, if bigger than this maximum, 
                                 the paragraph will be written as a table instead

    Output:
        section: A LaTeX section containing the summary of acquisition parameters divided into paragraphs and categorical values presented as tables. Any tables shorter
        than max_string_length will be written as a paragraph instead of a table.
    """  
  section = Section('Less Tables')
  for paragraph in paragraphs: #loop through each paragraph
    paragraph_written = False
    paragraph_text = ""
    for label in paragraph: #loop through each label in the paragraph
        content = acquisition_df[label]
        if not content.value_counts().empty:       
          if label in numerical_keys or len(content.value_counts()) <= max_string_length: #check if label is numerical or if the number of unique values is less than max_string_length
            paragraph_written = True
            paragraph_text = create_latex_text(paragraph_text, label, content, numerical=label in numerical_keys)
          else:
            table = create_latex_value_counts_table(label, content)
            section.append(table)
            section.append(NoEscape(r'\vspace{0.5cm}'))
    if paragraph_written:
      section.append(paragraph_text + "\n")
  return section

def acquisition_latex(author, acquisition_df, paragraphs, numerical_keys, max_string_length = 3, sections=['Information', 'Paragraphs', 'all_tables', 'Tables', 'less_tables'], filename='acquisition'):
  """
    Saves acquisition parameters from the dataframe to latex file

    Parameters:
        author (str): author name
        acquisition_df (pandas DataFrame): dataframe with acquisition parameters
        paragraphs (list): list of lists containing keys in a given paragraph
        numerical_keys (list): list of keys with numerical values
        max_string_length (int): maximum number of count values to write in a paragraph, if bigger than this maximum, 
                                 the paragraph will be written as a table instead
        sections (list): list of sections to include in the latex file
        filename (list): filename to save tex file to

    Output:
        Latex file containing acquisition parameters
    """  
  doc = report_header(author, "Acquisition Parameters")
  sections_functions = {'information': latex_information_section, 'paragraphs': latex_paragraphs_section, 'all_tables': latex_all_tables_section, 'tables': latex_tables_section}
  sections_functions = {
    'information': partial(latex_information_section, acquisition_df=acquisition_df, numerical_keys=numerical_keys),
    'paragraphs': partial(latex_paragraphs_section, acquisition_df=acquisition_df, paragraphs=paragraphs, numerical_keys=numerical_keys),
    'all_tables': partial(latex_all_tables_section, acquisition_df=acquisition_df, paragraphs=paragraphs),
    'tables': partial(latex_tables_section, acquisition_df=acquisition_df, paragraphs=paragraphs, numerical_keys=numerical_keys),
    'less_tables': partial(latex_less_tables_section, acquisition_df=acquisition_df, paragraphs=paragraphs, numerical_keys=numerical_keys, max_string_length=max_string_length)
}
  for section in sections:
      section = section.lower()
      if section.lower() in sections_functions:
          doc.append(sections_functions[section]())

  report_end(doc, filename)

def processing_latex(author, procedure, default_arguments, arguments_dictionary, filename='image_preprocessing'):
    """
    Saves image processing procedure to latex file

    Parameters:
        author (str): author name
        acquisition_df (pandas DataFrame): dataframe with acquisition parameters
        paragraphs (list): list of lists containing keys in a given paragraph
        numerical_keys (list): list of keys with numerical values
        max_string_length (int): maximum number of count values to write in a paragraph, if bigger than this maximum, 
                                 the paragraph will be written as a table instead
        sections (list): list of sections to include in the latex file
        filename (list): filename to save tex file to

    Output:
        Latex file containing acquisition parameters
    """  
    doc = report_header(author, "Image Pre-processing Procedure")
    for step in procedure:
        process, *args = step
        section = Section(process.capitalize())
        text = ""
        if process in default_arguments and not args:
            args = default_arguments[process]
        if process == 'normalise' and len(args) == 1:
            text += (f"Z-score normalisation \n") #checks if Z-score normalisation was performed and reports that
        elif process == 'discretise' and isinstance(args[0], dict):
            args = args[0]
            if "num_bins" in args.keys():
                text += f"Gray-level discretisation performed with fixed number of bins.\n"
                num_bins = args['num_bins']
                text += (f"Number of bins: {num_bins}\n")
                # text += (f"Mean Bin Width: {np.nanmean(ranges/(num_bins-1)):.3f}")
            else:
                text += f"Gray-level discretisation performed with fixed bin width.\n"
                bin_width = args['bin_width']
                text += (f"Bin width: {bin_width}\n")
                # num_bins = np.ceil(ranges / bin_width).astype(int) + 1
                # text += (f"Mean number of bins: {np.nanmean(num_bins):.3f}\n")
        elif process == 'resample':
            text += (f"{arguments_dictionary[process]}{args[0].tolist()}\n") #writes the function applied and new voxel size formatted as a list
        else:
            text += (f"{arguments_dictionary[process]}{args}\n") #writes the function applied and arguments
        text += ("\n") #blank line for better readability
        section.append(text)
        doc.append(section)
    report_end(doc, filename)

def extraction_report(author, results, settings, labels=[1], filters=None, params=None, filename="radiomics_extraction"):
    doc = report_header(author, "Feature Extraction Report")
    text = ""
    if filters != None:
        items = list(six.iteritems(results['baseline']))
    else:
        items = list(six.iteritems(results))
        
    new_category = False
    sections_headers = ['Software Versions Used', 'Shape Features Extracted', 'First Order Features Extracted', 'GLCM Features Extracted', 'GLDM Features Extracted', 'GLRLM Features Extracted', 'GLSZM Features Extracted', 'NGTDM Features Extracted']
    section_num = 0
    sections = [Section(header) for header in sections_headers]
    for i, (key, value) in enumerate(items):
        section = sections[section_num]
        next_key = items[i + 1][0] if i + 1 < len(items) else []                    
        if filters is not None:
            key = key[9:]  #strip filter off the key
        if key.startswith(str(labels[0])):
            key = key[len(str(labels[0])) + 1:]  #strip segmentation label off header                   
            if "diagnostics_Versions_" in key:
                section.append(f"{key[21:]}: {value}\n")
                if "diagnostics_Versions_" not in next_key: #if current category finished, write the next category
                    doc.append(section)
                    section_num += 1
                    new_category = True
            elif "original_shape_" in key:
                section.append(f"{key[9:]}\n")
                if "original_shape_" not in next_key:  #if current category finished, write the next category
                    doc.append(section)
                    section_num += 1
                    new_category = True      
            elif "original_firstorder_" in key:
                section.append(f"{key[9:]}\n")
                if "original_firstorder_" not in next_key:  #if current category finished, write the next category
                    doc.append(section)
                    section_num += 1
                    new_category = True               
            elif "original_glcm_" in key:
                section.append(f"{key[9:]}\n")
                if "original_glcm_" not in next_key:  #if current category finished, write the next category
                    new_category = True
                    doc.append(section)
                    section_num += 1             
            elif "original_gldm_" in key:
                section.append(f"{key[9:]}\n")
                if "original_gldm_" not in next_key:  #if current category finished, write the next category
                    new_category = True
                    doc.append(section)
                    section_num += 1
            elif "original_glrlm_" in key:
                section.append(f"{key[9:]}\n")
                if "original_glrlm_" not in next_key:  #if current category finished, write the next category
                    new_category = True
                    doc.append(section)
                    section_num += 1
            elif "original_glszm_" in key:
                section.append(f"{key[9:]}\n")
                if "original_glszm_" not in next_key:  #if current category finished, write the next category
                    new_category = True
                    doc.append(section)
                    section_num += 1
            elif "original_ngtdm_" in key:
                section.append(f"{key[9:]}\n")
                if "original_ngtdm_" not in next_key: #break when all features have   
                    section_num += 1  
                    doc.append(section)                   
                    break             
    section = Section('Filters Used')
    if filters is not None:                  
        for key, value in six.iteritems(filters):
            section.append(f"{key}\n")
    else:
        section.append("No Filters were used\n")
    doc.append(section)
    section = Section("Configuration Parameters")
    
    for key, value in settings.items(): #write configuration parameters
        section.append(f"{key}: {value}\n")
    doc.append(section)
    report_end(doc, filename)

def selection_report(author, X_selected, args, filename="feature_selection"):
    doc = report_header(author, "Feature Selection Report")
    for key, value in args.items():
       doc.append(f"{key}: {value}\n")
    doc.append(f"Number of features remaining: {len(X_selected.columns)}\n")
    for col in X_selected.columns:
       doc.append(f"{col}\n")
    doc.append("\n")

    report_end(doc, filename)

def selection_pipeline_report(author, X, pipeline, directory = ".//feature_selection", filename='feature_selection_pipeline'):
    os.makedirs(directory, exist_ok=True)
    doc = report_header(author, "Feature Selection Pipeline Report")
    if 'columns_to_keep' in pipeline:
        doc.append("The following columns were kept after feature selection:\n")
        doc.append(f"{pipeline['columns_to_keep']}\n")
    pipeline = {key: pipeline[key] for key in pipeline if key.lower() != 'columns_to_keep'}
    for key in pipeline:
        section = Section(f'Filtering for Feature {key.capitalize()}')
        for func, params in pipeline[key]:
            args = params.get('args', ())
            kwargs = params.get('kwargs', {})
            arg_names = get_arg_names(func)[3:]
            section.append(f'Run `{func.__name__}` with kwargs={kwargs}.\n')
            if func.__name__ == 'filter_by_correlations' and 'num_features' in kwargs:
                section.append(f"Meeting correlation conditions was prioritised over retaining {kwargs['num_features']} features.\n")
            for name, arg in zip(arg_names, args):
                section.append(f"{name}: {arg}.\n")
        doc.append(section)
    section = Section('Features Extracted')
    section.append(f'{len(X.columns)} features were extracted.\n')
    for i, col in enumerate(X.columns):    
       section.append(f"{i+1}. {col}\n")
    doc.append(section)
    X_renamed = X.copy()
    X_renamed.columns = range(1, len(X.columns)+1)
    corr_matrix = X_renamed.corr()
    os.chdir(directory)
    plt.figure(figsize=(10,8))
    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', vmax=1, vmin=-1, square=True)
    plt.savefig('correlation_matrix.png', dpi=300)
    plt.close()
    with doc.create(Figure(position="htbp")) as pic:
            pic.add_image(
                "correlation_matrix.png",
                width=NoEscape(r'\textwidth')
            )
            pic.add_caption("Feature Correlation Matrix")
    
    report_end(doc, filename)

def rfe_report(author, feature_names, ranking, directory = ".//feature_selection", filename='rfe_report'):
    """
    Generates a LaTeX report for Recursive Feature Elimination (RFE) results.
    Parameters:
        author (str): Author of the report.
        feature_names (list): List of feature names.
        ranking (list): List of feature rankings from RFE.
        filename (str): Filename to save the report.
    """
    os.makedirs(directory, exist_ok=True)
    doc = report_header(author, "Recursive Feature Elimination (RFE) Report")
    doc.append(
        f"The ranking of all features is as follows:\n"
    )
    feature_names = [name for _, name in sorted(zip(ranking, feature_names))]
    for i, feature_name in enumerate(feature_names):
        doc.append(f"{i+1}. {feature_name}\n")
    os.chdir(directory)
    report_end(doc, filename)

def pca_report(author, pca_model, components, directory = ".//feature_selection", filename='pca_report'):
    os.makedirs(directory, exist_ok=True)
    # --- 1. Compute + save the cumulative explained variance plot ---
    explained_variance = pca_model.explained_variance_ratio_
    cum_var = np.cumsum(explained_variance)
    os.chdir(directory)
    plt.figure(figsize=(6,4))
    plt.plot(
        range(1, len(cum_var)+1),
        cum_var,
        marker='o', linestyle='-',
        color='C0'
    )
    plt.title("Cumulative Explained Variance Ratio\nby Principal Components")
    plt.xlabel("Number of Principal Components")
    plt.ylabel("Cumulative Explained Variance Ratio")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("pca_explained_variance.png", dpi=300)
    plt.close()  # free up memory
    # --- 2. Build the LaTeX report and insert the plot ---
    # Title block
    doc = report_header(author, "PCA Report")
    # Document the way you chose components
    if isinstance(components, float):
        doc.append(
            "The number of components was determined by an explained variance "
            f"ratio threshold of {components:.2f}.  "
            f"The fitted model retained {pca_model.n_components_} components.\n"
        )
    else:
        doc.append(
            "The number of components was set to a fixed value.\n"
            f"Number of components: {components}\n"
        )
    # Section with the figure
    with doc.create(Section("Explained Variance Analysis")):
        doc.append(
            "Below is the cumulative explained variance as a function of the "
            "number of principal components:"
        )

        with doc.create(Figure(position="htbp")) as pic:
            pic.add_image(
                "pca_explained_variance.png",
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption("Cumulative Explained Variance vs. Number of Components")
    report_end(doc, filename)


def cross_validation_report(author,  n_splits, scoring, hyperparameter_grid, best_hyperparameters, best_score, cv_results, directory = ".//model_training", filename='cross_validation_report'):
    """
    Generates a LaTeX report for cross-validation results.

    Parameters:
        author (str): Author of the report.
        grid_search (GridSearchCV() object): GridSearchCV object fitted to the data.
        n_splits (int): Number of splits used in cross-validation.
        filename (str): Name of the file to save the report.
    """
    os.makedirs(directory, exist_ok=True)
    os.chdir(directory)
    doc = report_header(author, "Cross-Validation Report")

    section = Section('Cross-Validation Summary')
    section.append(f"Cross-validation was performed using {n_splits} splits.\n")
    section.append(f"Grid search was used to find the best hyperparameters for the model.\n")
    section.append(f"Scoring metric used: {scoring}.\n")
    section.append(f"Grid: {hyperparameter_grid}.\n")
    doc.append(section)

    section = Section('Cross-Validation Results')
      # Get the best parameter(s) found by grid search
    section.append(f"Best parameter(s): {best_hyperparameters}.\n")

    
    section.append(f"Best cross-validated {scoring}: {best_score:.4f}.\n")
    for key, result in six.iteritems(cv_results):
        section.append(f"{key}: {result}\n")
    doc.append(section)
    
    report_end(doc, filename)

def decision_tree_structure_report(author, X, tree, tree_diagram, filename='decision_tree_structure'):
    """
    Report about the decision tree structure

    Parameters:
        author (str): Author of the report.
        tree (sklearn DecisionTreeClassifier): trained decision tree
        tree_diagram (str): name of image
        filename (str): filename to save report to
    """
    doc = report_header(author, "Decision Tree Structure")

    n_nodes = tree.tree_.node_count
    children_left = tree.tree_.children_left
    children_right = tree.tree_.children_right
    feature = tree.tree_.feature
    threshold = tree.tree_.threshold
    values = tree.tree_.value

    node_depth = np.zeros(shape=n_nodes, dtype=np.int64)
    is_leaves = np.zeros(shape=n_nodes, dtype=bool)
    stack = [(0, 0)]  # start with the root node id (0) and its depth (0)
    while len(stack) > 0:
        # `pop` ensures each node is only visited once
        node_id, depth = stack.pop()
        node_depth[node_id] = depth

        # If the left and right child of a node is not the same we have a split
        # node
        is_split_node = children_left[node_id] != children_right[node_id]
        # If a split node, append left and right children and depth to `stack`
        # so we can loop through them
        if is_split_node:
            stack.append((children_left[node_id], depth + 1))
            stack.append((children_right[node_id], depth + 1))
        else:
            is_leaves[node_id] = True

    doc.append(
        "The binary tree structure has {n} nodes and has "
        "the following tree structure:\n".format(n=n_nodes)
    )
    for i in range(n_nodes):
        if is_leaves[i]:
            doc.append(
                "{space}node={node} is a leaf node with value={value}.\n".format(
                    space=node_depth[i] * "\t", node=i, value=np.around(values[i], 3)
                )
            )
        else:
            doc.append(
                "{space}node={node} is a split node with value={value}: \n"
                .format(
                    space=node_depth[i] * "\t",
                    node=i,
                    left=children_left[i],
                    feature=X.columns[feature[i]],
                    threshold=threshold[i],
                    right=children_right[i],
                    value=np.around(values[i], 3),
                )
            )
            doc.append("\n")
            doc.append("go to node {left} if {feature} <= {threshold} \n".format(space=node_depth[i] * "\t",
                    node=i,
                    left=children_left[i],
                    feature=X.columns[feature[i]],
                    threshold=threshold[i],
                    right=children_right[i],
                    value=np.around(values[i], 3)))
            doc.append("\n")
            doc.append("else to node {right}.".format(space=node_depth[i] * "\t",
                    node=i,
                    left=children_left[i],
                    feature=X.columns[feature[i]],
                    threshold=threshold[i],
                    right=children_right[i],
                    value=np.around(values[i], 3)))
            doc.append("\n")
        doc.append("\n")
    with doc.create(Figure(position="htbp")) as pic:
            pic.add_image(
                tree_diagram,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption("Decision tree diagram.")
    report_end(doc, filename)

def calibration_report(author, calibration_results, calibration_curves, score_plots, evaluate_on_test=True, filename='calibration_report'):
    """
    Generates a LaTeX report for calibration results.

    Parameters:
        author (str): Author of the report.
        calibration_results (dict): Dictionary containing calibration results.
        calibration_curves (list): List of tuples containing calibration curves for each model
        score_plots (list): List of tuples containing score plots for each model
        evaluate_on_test (Boolean): If True, evaluate calibration on test data
        filename (str): Name of the file to save the report.
    """
    doc = report_header(author, "Calibration Report")

    section = Section('Calibration Metrics')
    calibration_metrics = [col for col in calibration_results.columns if col != 'Model']
    # Group metrics by base name (e.g., 'Expected/Observed')
    grouped_metrics = {}
    for metric in calibration_metrics:
        base_name = metric.replace(' Train', '').replace(' Test', '')
        grouped_metrics.setdefault(base_name, []).append(metric)

    section.append("Calibration was performed using the following results:\n")
    for base_metric, variants in grouped_metrics.items():
        if evaluate_on_test:
            with doc.create(Table(position='htbp')) as table:
                table.add_caption(f"Calibration was performed using the {base_metric} metrics.")
                tabular = Tabular("|c|c|c|")
                tabular.add_hline()
                tabular.add_row([bold("Model"), bold("Train Score"), bold("Test Score")])
                tabular.add_hline()
                for model in calibration_results['Model'].unique():
                    model_df = calibration_results[calibration_results['Model'] == model]
                    
                    column_name = base_metric + ' Train'
                    if column_name in model_df.columns:
                        value = model_df[column_name].iloc[0]
                        value =  value.item() if hasattr(value, 'item') else value
                        if pd.notnull(value):
                            train_score = value
                        else:
                            train_score = 'N/A'
                    else:
                        train_score = 'N/A'


                    column_name = base_metric + ' Test'
                    
                    if column_name in model_df.columns:
                        value = model_df[column_name].iloc[0]
                        value =  value.item() if hasattr(value, 'item') else value
                        if pd.notnull(value):
                            test_score = value
                        else:
                            test_score = 'N/A'
                    else:
                        test_score = 'N/A'
                    #train_score = model_df[base_metric + ' Train'].values[0] if (base_metric + ' Train' in model_df and not np.isnan(model_df[base_metric + ' Train'].values[0])) else 'N/A'
                    #test_score = model_df[base_metric + ' Test'].values[0] if (base_metric + ' Test' in model_df and  not np.isnan(model_df[base_metric + ' Test'].values[0])) else 'N/A'
                    tabular.add_row([model, train_score, test_score])
                    tabular.add_hline()
                table.append(tabular)
        else:
            with doc.create(Table(position='htbp')) as table:
                table.add_caption(f"Calibration was performed using the {base_metric} metrics.")
                tabular = Tabular("|c|c|")
                tabular.add_hline()
                tabular.add_row([bold("Model"), bold("Score")])
                tabular.add_hline()
                for model in calibration_results['Model'].unique():
                    model_df = calibration_results[calibration_results['Model'] == model]
                    
                    column_name = base_metric + ' Train'
                    if column_name in model_df.columns:
                        value = model_df[column_name].iloc[0]
                        value =  value.item() if hasattr(value, 'item') else value
                        if pd.notnull(value):
                            train_score = value
                        else:
                            train_score = 'N/A'
                    else:
                        train_score = 'N/A'
                    #train_score = model_df[base_metric + ' Train'].values[0] if (base_metric + ' Train' in model_df and not np.isnan(model_df[base_metric + ' Train'].values[0])) else 'N/A'
                    #test_score = model_df[base_metric + ' Test'].values[0] if (base_metric + ' Test' in model_df and  not np.isnan(model_df[base_metric + ' Test'].values[0])) else 'N/A'
                    tabular.add_row([model, train_score])
                    tabular.add_hline()
                table.append(tabular)
    doc.append(section)

    section = Section('Calibration Curves')
    section.append("The following calibration curves were generated:\n")
    for curves in calibration_curves:
        if evaluate_on_test:
            name, train_filename, test_filename, train_platt_filename, test_platt_filename, train_isotonic_filename, test_isotonic_filename = curves
        else:
            name, train_filename, train_platt_filename, train_isotonic_filename = curves
            test_filename = None
            test_platt_filename = None
            test_isotonic_filename = None
        if train_filename is not None:
            with doc.create(Figure(position='htbp')) as fig:
                fig.add_image(train_filename, width=NoEscape(r'0.8\textwidth'))
                fig.add_caption(f"Calibration curve for training data on {name}.")
        if test_filename is not None:
            with doc.create(Figure(position='htbp')) as fig:
                fig.add_image(test_filename, width=NoEscape(r'0.8\textwidth'))
                fig.add_caption(f"Calibration curve for test data on {name}.")
        if train_platt_filename is not None:
            with doc.create(Figure(position='htbp')) as fig:
                fig.add_image(train_platt_filename, width=NoEscape(r'0.8\textwidth'))
                fig.add_caption(f"Platt scaling calibration curve for training data on {name}.")
        if test_platt_filename is not None:
            with doc.create(Figure(position='htbp')) as fig:
                fig.add_image(test_platt_filename, width=NoEscape(r'0.8\textwidth'))
                fig.add_caption(f"Platt scaling calibration curve for test data on {name}.")
        if train_isotonic_filename is not None:
            with doc.create(Figure(position='htbp')) as fig:
                fig.add_image(train_isotonic_filename, width=NoEscape(r'0.8\textwidth'))
                fig.add_caption(f"Isotonic regression calibration curve for training data on {name}.")
        if test_isotonic_filename is not None:
            with doc.create(Figure(position='htbp')) as fig:
                fig.add_image(test_isotonic_filename, width=NoEscape(r'0.8\textwidth'))
                fig.add_caption(f"Isotonic regression calibration curve for test data on {name}.")
    doc.append(section)
    report_end(doc, filename)
    del doc

    doc = report_header(author, "Probability Plots")
    doc.append("The following plots of the model probability distributions were generated:\n")
    for plots in score_plots:
        if evaluate_on_test:
            name, train_density_filename, train_hist_filename, test_density_filename, test_hist_filename, train_platt_density_filename, train_platt_hist_filename, test_platt_density_filename, test_platt_hist_filename, train_isotonic_density_filename, train_isotonic_hist_filename, test_isotonic_density_filename, test_isotonic_hist_filename = plots
        else:
            name, train_density_filename, train_hist_filename, train_platt_density_filename, train_platt_hist_filename, train_isotonic_density_filename, train_isotonic_hist_filename = plots

        with doc.create(Figure(position='htbp')) as fig:
            fig.add_image(train_density_filename, width=NoEscape(r'0.8\textwidth'))
            fig.add_caption(f"Model Output Probability Distribution for training data on {name}.")
        with doc.create(Figure(position='htbp')) as fig:
            fig.add_image(train_hist_filename, width=NoEscape(r'0.8\textwidth'))
            fig.add_caption(f"Model Output Probability Histogram for training data on {name}.")
        with doc.create(Figure(position='htbp')) as fig:
            fig.add_image(train_platt_density_filename, width=NoEscape(r'0.8\textwidth'))
            fig.add_caption(f"Platt Scaling Model Output Probability Distribution for training data on {name}.")
        with doc.create(Figure(position='htbp')) as fig:
            fig.add_image(train_platt_hist_filename, width=NoEscape(r'0.8\textwidth'))
            fig.add_caption(f"Platt Scaling Model Output Probability Histogram for training data on {name}.")
        with doc.create(Figure(position='htbp')) as fig:
            fig.add_image(train_isotonic_density_filename, width=NoEscape(r'0.8\textwidth'))
            fig.add_caption(f"Isotonic regression Model Output Probability Distribution for training data on {name}.")
        with doc.create(Figure(position='htbp')) as fig:
            fig.add_image(train_isotonic_hist_filename, width=NoEscape(r'0.8\textwidth'))
            fig.add_caption(f"Isotonic regression Model Output Probability Histogram for training data on {name}.")
        if evaluate_on_test:
            with doc.create(Figure(position='htbp')) as fig:
                fig.add_image(test_density_filename, width=NoEscape(r'0.8\textwidth'))
                fig.add_caption(f"Model Output Probability Distribution for testing data on {name}.")
            with doc.create(Figure(position='htbp')) as fig:
                fig.add_image(test_hist_filename, width=NoEscape(r'0.8\textwidth'))
                fig.add_caption(f"Model Output Probability Histogram for testing data on {name}.")  
            with doc.create(Figure(position='htbp')) as fig:
                fig.add_image(test_platt_density_filename, width=NoEscape(r'0.8\textwidth'))
                fig.add_caption(f"Platt Scaling Model Output Probability Distribution for testing data on {name}.")
            with doc.create(Figure(position='htbp')) as fig:
                fig.add_image(test_platt_hist_filename, width=NoEscape(r'0.8\textwidth'))
                fig.add_caption(f"Platt Scaling Model Output Probability Histogram for testing data on {name}.")      
            with doc.create(Figure(position='htbp')) as fig:
                fig.add_image(test_isotonic_density_filename, width=NoEscape(r'0.8\textwidth'))
                fig.add_caption(f"Isotonic regression Model Output Probability Distribution for testing data on {name}.")
            with doc.create(Figure(position='htbp')) as fig:
                fig.add_image(test_isotonic_hist_filename, width=NoEscape(r'0.8\textwidth'))
                fig.add_caption(f"Isotonic regression Model Output Probability Histogram for testing data on {name}.")     
    report_end(doc, f'{filename}_probability_plots', pdf=False)
    

def threshold_evaluation_report(author, threshold_df, threshold_method, filename='threshold_evaluation'):
    """
    Generates a LaTeX report for threshold evaluation results.

    Parameters:
        author (str): Author of the report.
        threshold_df (pandas DataFrame): DataFrame containing threshold evaluation results.
        threshold_method (str): Method used for threshold evaluation.
        filename (str): Name of the file to save the report.
    """
    doc = report_header(author, "Threshold Evaluation Report")

    section = Section('Threshold Evaluation Summary')
    section.append(f"Threshold evaluation was performed using the {threshold_method} method.\n")
    doc.append(section)

    section = Section('Threshold Evaluation Results')
    with doc.create(Table(position='htbp')) as table:
        table.add_caption(f"Threshold Analyses for Models performed using the {threshold_method} method.")
        tabular = Tabular("|c|c|c|")
        tabular.add_hline()
        tabular.add_row([bold("Model"), bold('Best Score for Threshold'), bold('Threshold')])
        tabular.add_hline()
        for model in threshold_df['Model'].unique():
            model_df = threshold_df[threshold_df['Model'] == model]
            tabular.add_row([model, model_df['Best Score for Threshold'].values[0], model_df['Optimal Threshold'].values[0]])
            tabular.add_hline()
        table.append(tabular)

    report_end(doc, filename)

def decision_curve_report(author, results_df, decision_curves, time="", n_splits=None, n_iterations=None, n_bootstraps=None, confidence="", title='Decision Curve Analysis', filename='decision_curve_analysis'):
    """
    Generates a LaTeX report for decision curve analysis results.

    Parameters:
        author (str): Author of the report.
        results_df (pandas DataFrame): dataframe of results
        decision_curves (list): List of tuples containing decision curve plots for each model
        time (float): timepoint analysed for survival analysis
        n_splits (int): number of cross validation splits
        n_iterations (int): number of cross validation iterations
        n_bootstraps (int): number of bootstraps

        title (str): title of report
        filename (str): filename to save report
    """
    doc = report_header(author, title)

    section = Section('Decision Curve Analysis')
    if time == "":
        section.append("Decision curve analysis was performed using the following results:\n")
    else:
        section.append(f"Decision curve analysis was performed at time t = {time*100} days using the following results:\n")
        time = f"_{time}"
    if n_splits is not None and n_iterations is not None:
        section.append(f"Cross-validation was performed using {n_splits} splits and {n_iterations} iterations.\n")
    if n_bootstraps is not None:
        section.append(f"Bootstrapping was performed using {n_bootstraps} bootstrap samples.\n")
    if confidence != "":
        section.append(f"{confidence*100}% confidence intervals were plotted.")
    for model_name, decision_curve_train, decision_curve_test, decision_curve_train_overall, decision_curve_test_overall, decision_curve_train_untreated, decision_curve_test_untreated, adapt_train, adapt_test in decision_curves:
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                decision_curve_train,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption(f"Decision Curve Analysis for {model_name} (Train)")
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                decision_curve_test,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption(f"Decision Curve Analysis for {model_name} (Test)")
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                decision_curve_train_overall,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption(f"Overall Net Benefit for {model_name} (Train)")
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                decision_curve_test_overall,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption(f"Overall Net Benefit for {model_name} (Test)")
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                decision_curve_train_untreated,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption(f"Net Benefit Untreated for {model_name} (Train)")
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                decision_curve_test_untreated,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption(f"Net Benefit Untreated for {model_name} (Test)")
    doc.append(section)

    doc.append(NoEscape(r'\clearpage'))
    section = Section('Adapt Index Values')
    for model_name, decision_curve_train, decision_curve_test, decision_curve_train_overall, decision_curve_test_overall, decision_curve_train_untreated, decision_curve_test_untreated, adapt_train, adapt_test in decision_curves:
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                adapt_train,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption(f"ADAPT Index for {model_name} (Train)")
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                adapt_test,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption(f"ADAPT Index for {model_name} (Test)")
    doc.append(section)

    doc.append(NoEscape(r'\clearpage'))
    section = Section('Net Benefit Values')
    if confidence == "":
        net_benefit = ['Train Net Benefit Treated', 'Test Net Benefit Treated', 'Train Net Benefit Untreated', 'Test Net Benefit Untreated', 'Train Net Benefit Overall', 'Test Net Benefit Overall']
        for model in results_df['Model'].unique():
            model_df = results_df[results_df['Model'] == model]
            with doc.create(Table(position='htbp')) as table:
                table.add_caption(f"Net benefit for patients treated based on {model} risk predictions. This corresponds to the relative number of true positives found by the test.")
                tabular = Tabular("|c|c|c|")
                tabular.add_hline()
                tabular.add_row([bold(item) for item in ['Threshold', 'Train Net Benefit Treated', 'Test Net Benefit Treated']])
                tabular.add_hline()
                for index, row in model_df.iterrows():
                    net_benefit_values = row[net_benefit[0:2]]
                    formatted_values = [row['Threshold']]
                    for value in net_benefit_values:
                        if isinstance(value, (int, float)):
                            formatted_values.append(f'{value:.4f}')
                        else:
                            formatted_values.append(str(value))
                    tabular.add_row(formatted_values)
                    tabular.add_hline()
                table.append(tabular)
            with doc.create(Table(position='htbp')) as table:
                table.add_caption(f"Net benefit for patients untreated based on {model} risk predictions. This corresponds to the relative reduction in unnecessary treatments")
                tabular = Tabular("|c|c|c|")
                tabular.add_hline()
                tabular.add_row([bold(item) for item in ['Threshold', 'Train Net Benefit Untreated', 'Test Net Benefit Untreated']])
                tabular.add_hline()
                for index, row in model_df.iterrows():
                    net_benefit_values = row[net_benefit[2:4]]
                    formatted_values = [row['Threshold']]
                    for value in net_benefit_values:
                        if isinstance(value, (int, float)):
                            formatted_values.append(f'{value:.4f}')
                        else:
                            formatted_values.append(str(value))
                    tabular.add_row(formatted_values)
                    tabular.add_hline()
                table.append(tabular)
            with doc.create(Table(position='htbp')) as table:
                table.add_caption(f"Sum of net benefits for treated and untreated patients based on {model} risk predictions.")
                tabular = Tabular("|c|c|c|")
                tabular.add_hline()
                tabular.add_row([bold(item) for item in ['Threshold', 'Train Net Benefit Overall', 'Test Net Benefit Overall']])
                tabular.add_hline()
                for index, row in model_df.iterrows():
                    net_benefit_values = row[net_benefit[4:6]]
                    formatted_values = [row['Threshold']]
                    for value in net_benefit_values:
                        if isinstance(value, (int, float)):
                            formatted_values.append(f'{value:.4f}')
                        else:
                            formatted_values.append(str(value))
                    tabular.add_row(formatted_values)
                    tabular.add_hline()
                table.append(tabular)
    else:
        net_benefit = ['train mean net benefit treated', 'train mean net benefit untreated', 'train mean net benefit overall', 'train mean net benefit treat all', 'train mean net benefit treat none', 'train mean adapts', 'train mean adapts perfect', 'train mean adapts null', 'train lower net benefit treated', 
        'train lower net benefit untreated', 'train lower net benefit overall', 'train lower net benefit treat all', 'train lower net benefit treat none','train lower adapts','train lower adapts perfect','train lower adapts null','train upper net benefit treated','train upper net benefit untreated',
        'train upper net benefit overall','train upper net benefit treat all','train upper net benefit treat none','train upper adapts','train upper adapts perfect','train upper adapts null','test net benefit treated',
        'test net benefit untreated','test net benefit overall','test net benefit treat all','test net benefit treat none','test adapts','test adapts perfect','test adapts null']
        for model in results_df['Model'].unique():
            model_df = results_df[results_df['Model'] == model]
            with doc.create(Table(position='htbp')) as table:
                table.add_caption(f"Net benefit for patients treated based on {model} risk predictions. This corresponds to the relative number of true positives found by the test.")
                tabular = Tabular("|c|c|c|")
                tabular.add_hline()
                tabular.add_row([bold(item) for item in ['Threshold', 'Train Net Benefit Treated', 'Test Net Benefit Treated']])
                tabular.add_hline()
                for index, row in model_df.iterrows():
                    net_benefit_values = row[['train mean net benefit treated', 'test net benefit treated']]
                    net_benefit_values = [float(value) for value in net_benefit_values]
                    formatted_values = [row['Threshold']]
                    for i, value in enumerate(net_benefit_values):
                        if isinstance(value, int) or isinstance(value, float):                          
                            if i == 0:
                                formatted_values.append(f"{value:.4f} ({row['train lower net benefit treated']:.3f}, {row['train upper net benefit treated']:.3f})")
                            else:
                                formatted_values.append(f'{value:.4f}')
                        else:
                            formatted_values.append(str(value))
                    tabular.add_row(formatted_values)
                    tabular.add_hline()
                table.append(tabular)
            doc.append(NoEscape(r'\clearpage'))
            with doc.create(Table(position='htbp')) as table:
                table.add_caption(f"Net benefit for patients untreated based on {model} risk predictions. This corresponds to the relative reduction in unnecessary treatments")
                tabular = Tabular("|c|c|c|")
                tabular.add_hline()
                tabular.add_row([bold(item) for item in ['Threshold', 'Train Net Benefit Untreated', 'Test Net Benefit Untreated']])
                tabular.add_hline()
                for index, row in model_df.iterrows():
                    net_benefit_values = row[['train mean net benefit untreated', 'test net benefit untreated']]
                    net_benefit_values = [float(value) for value in net_benefit_values]
                    formatted_values = [row['Threshold']]
                    for i, value in enumerate(net_benefit_values):
                        if isinstance(value, int) or isinstance(value, float):   
                            if i == 0:
                                formatted_values.append(f"{value:.4f} ({row['train lower net benefit untreated']:.3f}, {row['train upper net benefit untreated']:.3f})")
                            else:
                                formatted_values.append(f'{value:.4f}')
                        else:
                            formatted_values.append(str(value))
                    tabular.add_row(formatted_values)
                    tabular.add_hline()
                table.append(tabular)
            doc.append(NoEscape(r'\clearpage'))
            with doc.create(Table(position='htbp')) as table:
                table.add_caption(f"Sum of net benefits for treated and untreated patients based on {model} risk predictions.")
                tabular = Tabular("|c|c|c|")
                tabular.add_hline()
                tabular.add_row([bold(item) for item in ['Threshold', 'Train Net Benefit Overall', 'Test Net Benefit Overall']])
                tabular.add_hline()
                for index, row in model_df.iterrows():
                    net_benefit_values = row[['train mean net benefit overall', 'test net benefit overall']]
                    net_benefit_values = [float(value) for value in net_benefit_values]
                    formatted_values = [row['Threshold']]
                    for i, value in enumerate(net_benefit_values):
                        if isinstance(value, int) or isinstance(value, float):   
                            if i == 0:
                                formatted_values.append(f"{value:.4f} ({row['train lower net benefit overall']:.3f}, {row['train upper net benefit overall']:.3f})")
                            else:
                                formatted_values.append(f'{value:.4f}')
                        else:
                            formatted_values.append(str(value))
                    tabular.add_row(formatted_values)
                    tabular.add_hline()
                table.append(tabular)
    report_end(doc, f'{filename}{time}')

def km_decision_curve_report(author, decision_curves, time, title='Decision Curve Analysis', filename='decision_curve_analysis'):
    """
    Generates a LaTeX report for decision curve analysis results.

    Parameters:
        author (str): Author of the report.
        decision_curves (list): List of tuples containing decision curve plots for each model
        time (float): timepoint analysed for survival analysis
        title (str): title of report
        filename (str): filename to save report
    """
    doc = report_header(author, f'{title} Train')

    section = Section('Decision Curve Analysis')
    section.append(f"Decision curve analysis was performed at {time} using the following results:\n")
    time = f"_{time}"
    for model_name, (decision_curve_train_low, decision_curve_test_low, decision_curve_train_high, decision_curve_test_high) in decision_curves.items():
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                decision_curve_train_low,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption(f"Decision Curve Analysis for {model_name} < median (Train)")
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                decision_curve_train_high,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption(f"Decision Curve Analysis for {model_name} > median (Train)")
    doc.append(section)
    report_end(doc, f'{filename}{time}_train')
    doc = report_header(author, f'{title} Test')

    section = Section('Decision Curve Analysis')
    section.append(f"Decision curve analysis was performed at {time} using the following results:\n")
    time = f"_{time}"
    for model_name, (decision_curve_train_low, decision_curve_test_low, decision_curve_train_high, decision_curve_test_high) in decision_curves.items():

        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                decision_curve_test_low,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption(f"Decision Curve Analysis for {model_name} < median (Test)")
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                decision_curve_test_high,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption(f"Decision Curve Analysis for {model_name} > median (Test)")
    doc.append(section)
    report_end(doc, f'{filename}{time}_test')

def binary_model_evaluation_report(author, results_df, cv_df, bootstrapped_df, bootstrap_plots, optimisms_df, metrics, num_coefficients, roc_train, roc_test, precision_recall_train, precision_recall_test, confusion_matrix_train, confusion_matrix_test, coefficient_plots, evaluate_on_test=True, generate_pdf=True, confidence=0.95, n_splits=5, title='Model Evaluation Report', filename='model_evaluation_results'):
    """
    Generates a LaTeX report for classification model evaluation results.

    Parameters:
        author (str): Author of the report.
        results_df (pandas DataFrame): DataFrame containing model evaluation results.
        cv_df (pandas DataFrame): DataFrame of cross-validation results.
        bootstrapped_df (pandas DataFrame): DataFrame containing bootstrap results.
        bootstrap_plots (dictionary): Dictionary of form {model_name: [[list of train boot plot filenames], [list of test boot plot filenames]]}
        optimisms_df (pandas DataFrame): dataframe of optimism corrected metrics and optimisms
        metrics (list): List of metrics to include in the report.
        num_coefficients (list): List of number of coefficients in model.
        roc_train (list): List of ROC curves for training data.
        generate_pdf (bool): If True, pdf is generated
        evaluate_on_test (bool): If True, model is evaluated on test set
        filename (str): Name of the file to save the report.
    """
    doc = report_header(author, title)
    doc.packages.append(Package('booktabs'))
    doc.preamble.append(NoEscape(r'\usepackage{float}'))
    section = Section('Model Evaluation Metrics')
    section.append("The following table summarizes the performance of different models:\n")
    section.append(f"The confidence interval is calculated at {confidence*100}% level.\n")
    section.append("The metrics are reported as mean (lower bound, upper bound) for both training and testing data.\n")
    
    for metric in metrics:
        metric_df = results_df.loc[:, [col for col in results_df.columns if metric in col or col == 'Model']]
        metric_bootstrapped_df = bootstrapped_df[bootstrapped_df['metric'] == metric]
        lower_percentile = (1 - confidence) / 2 * 100
        upper_percentile = (1 + confidence) / 2 * 100
        with doc.create(Table(position='H')) as table:
            table.add_caption(f"Model evaluation results for {metric}. ")
            table_layout = "|c|c" + ("|c" * (len(metric_df.columns) - 1)) + "|"
            tabular = Tabular(table_layout)
            tabular.add_hline()
            tabular.add_row([bold('Model')] + [bold(item) for item in metric_df.columns])
            tabular.add_hline()
            for index, row in metric_df.iterrows():
                row_list = list(row.values)
                
                row_list_copy = []
                model_bootstrap = metric_bootstrapped_df[metric_bootstrapped_df['model'] == index]
                lower_bound_train = model_bootstrap[f'{lower_percentile:.1f}%'].values[0]
                upper_bound_train = model_bootstrap[f'{upper_percentile:.1f}%'].values[0]
                row_list_copy.append(index)
                row_list_copy.append(f"{row_list[0]:.3f} ({lower_bound_train:.3f}, {upper_bound_train:.3f})")
                if evaluate_on_test:
                    lower_bound_test = model_bootstrap[f'{lower_percentile:.1f}%'].values[1]
                    upper_bound_test = model_bootstrap[f'{upper_percentile:.1f}%'].values[1]
                    row_list_copy.append(f"{row_list[1]:.3f} ({lower_bound_test:.3f}, {upper_bound_test:.3f})")                
                tabular.add_row(row_list_copy)
                tabular.add_hline()          
            table.append(tabular)
    doc.append(section)
    doc.append(NoEscape(r'\clearpage'))
    section = Section("Cross-Validation Results")
    for metric in metrics:
        metric_df = cv_df.loc[:, [col for col in cv_df.columns if metric in col or col == 'Model']]
        with doc.create(Table(position='H')) as table:
            table.add_caption(f"Cross-validated model evaluation results for {metric}. {n_splits} folds of cross-validation were performed.")
            table_layout = "|c" + ("|c" * (len(metric_df.columns) - 1)) + "|"
            tabular = Tabular(table_layout)
            tabular.add_hline()
            tabular.add_row([bold(item) for item in metric_df.columns])
            tabular.add_hline()
            for index, row in metric_df.iterrows():
                row_list = list(row.values)
                row_list_copy = []
                row_list_copy.append(row_list[0])
                row_list_copy.append(f"{row_list[1]:.3f}")
                row_list_copy.append(f"{row_list[2]:.3f}")                
                tabular.add_row(row_list_copy)
                tabular.add_hline()          
            table.append(tabular)
    doc.append(section)
    doc.append(NoEscape(r'\clearpage'))
    section = Section("Bootstrap Plots")
    for model_name, [train_plots,test_plots] in bootstrap_plots.items():
        for plot in train_plots:
            with doc.create(Figure(position='H')) as pic:
                pic.add_caption(f"Bootstrap plot on training data for {model_name}.")
                pic.add_image(
                    plot,
                    width=NoEscape(r'0.8\textwidth')
                )
        if evaluate_on_test:
            for plot in test_plots:
                with doc.create(Figure(position='H')) as pic:
                    pic.add_caption(f"Bootstrap plot on testing data for {model_name}.")
                    pic.add_image(
                        plot,
                        width=NoEscape(r'0.8\textwidth')
                    )
    doc.append(section)
    doc.append(NoEscape(r'\clearpage'))
    section = Section("Bootstrap Model Stability")
    for metric in metrics:
        metric_df = results_df.loc[:, [col for col in results_df.columns if metric in col or col == 'Model']]
        metric_bootstrapped_df = bootstrapped_df[bootstrapped_df['metric'] == metric]
        with doc.create(Table(position='H')) as table:
            table.add_caption(f"Metrics quantifying stability of the bootstrap for {metric}. ")
            table_layout = "|c|c|c|c|c|c|c|"
            tabular = Tabular(table_layout)
            tabular.add_hline()
            tabular.add_row([bold('Model'), bold('Set')] + [bold(item) for item in metric_bootstrapped_df.columns[-5:]])
            tabular.add_hline()
            for index, row in metric_bootstrapped_df.iterrows():
                row_list = list(row.values)
                row_list_copy = [row_list[0], row_list[2]] + [f'{item:.4f}' for item in row_list[-5:]]          
                tabular.add_row(row_list_copy)
                tabular.add_hline()          
            table.append(tabular)
    doc.append(section)
    doc.append(NoEscape(r'\clearpage'))
    section = Section("Optimism-Corrected Metrics")
    optimisms_df = optimisms_df.loc[:, [col for col in optimisms_df if 'Model' in col or 'Corrected' in col]]
    optimisms_df.columns = ['Model'] + [col[18:] for col in optimisms_df if 'Model' not in col]
    with doc.create(Table(position='H')) as table:
        table.add_caption('Optimism-Corrected Metrics obtained.')
        #table.append(NoEscape(optimisms_df.style.to_latex(clines="all;data",hrules=True)))
        table.append(NoEscape(optimisms_df.to_latex(index=False, escape=False)))
    doc.append(section)
    doc.append(NoEscape(r'\clearpage'))
    section = Section('Model Coefficients')
    df = results_df.index
    with doc.create(Table(position='H')) as table:
            table.add_caption(f"Number of coefficients in each model.")
            table_layout = "|c|c|"
            tabular = Tabular(table_layout)
            tabular.add_hline()
            tabular.add_row([bold('Model'), bold('Number of Coefficients')])
            tabular.add_hline()
            for i, n in enumerate(num_coefficients):
                model_name = df[i]
                row_list = [model_name, n]
                tabular.add_row(row_list)
                tabular.add_hline()
            table.append(tabular)
    doc.append(NoEscape(r'\clearpage'))
    for image in coefficient_plots:
        with doc.create(Figure(position='H')) as pic:
            pic.add_image(
                image[1],
                width=NoEscape(r'0.8\textwidth')
            )
            if 'dual' in image[1].lower():
                pic.add_caption(f"Model Dual Coefficients for {image[0]}")
            elif 'coefficients' in image[1].lower():
                pic.add_caption(f"Model Coefficients for {image[0]}")
            else:
                pic.add_caption(f"Model Feature Importances for {image[0]}")
    doc.append(section)
    doc.append(NoEscape(r'\clearpage'))

    section = Section('ROC Curves')
    section.append("The following ROC curves were generated for the training data:\n") 
    for model_name, roc_curve in roc_train:
        with doc.create(Figure(position='H')) as pic:
            pic.add_image(
                roc_curve,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption(f"ROC Curve for {model_name} on Training Data")
    doc.append(NoEscape(r'\clearpage'))
    section.append("The following ROC curves were generated for the testing data:\n")
    if evaluate_on_test:
        for model_name, roc_curve in roc_test:
            with doc.create(Figure(position='H')) as pic:
                pic.add_image(
                    roc_curve,
                    width=NoEscape(r'0.8\textwidth')
                )
                pic.add_caption(f"ROC Curve for {model_name} on Testing Data")
    doc.append(NoEscape(r'\clearpage'))
    doc.append(section)

    section = Section('Precision Recall Curves')
    section.append("The following Precision Recall curves were generated for the training data:\n") 
    for model_name, pr_curve in precision_recall_train:
        with doc.create(Figure(position='H')) as pic:
            pic.add_image(
                pr_curve,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption(f"Precision Recall Curve for {model_name} on Training Data")
    doc.append(NoEscape(r'\clearpage'))
    if evaluate_on_test:
        section.append("The following Precision Recall curves were generated for the testing data:\n")
        for model_name, pr_curve in precision_recall_test:
            with doc.create(Figure(position='H')) as pic:
                pic.add_image(
                    pr_curve,
                    width=NoEscape(r'0.8\textwidth')
                )
                pic.add_caption(f"Precision Recall Curve for {model_name} on Testing Data")
    doc.append(NoEscape(r'\clearpage'))
    doc.append(section)

    section = Section('Confusion Matrices')
    section.append("The following Confusion Matrices were generated for the training data:\n") 
    for model_name, cm in confusion_matrix_train:
        with doc.create(Figure(position='H')) as pic:
            pic.add_image(
                cm,
                width=NoEscape(r'0.8\textwidth')
            )
            pic.add_caption(f"Confusion Matrix for {model_name} on Training Data")
    doc.append(NoEscape(r'\clearpage'))
    if evaluate_on_test:
        section.append("The following Confusion Matrices were generated for the testing data:\n")
        for model_name, cm in confusion_matrix_test:
            with doc.create(Figure(position='H')) as pic:
                pic.add_image(
                    cm,
                    width=NoEscape(r'0.8\textwidth')
                )
                pic.add_caption(f"Confusion Matrix for {model_name} on Testing Data")
    doc.append(NoEscape(r'\clearpage'))
    doc.append(section)

    section = Section("DeLong's Test for AUCs")
    if evaluate_on_test:
        delong_test = ['DeLong Test Train Z-Score to Random Classifier', 'DeLong Test Train p-Value to Random Classifier', 'DeLong Test Test Z-Score to Random Classifier', 'DeLong Test Test p-Value to Random Classifier']
        with doc.create(Table(position='H')) as table:
            table.add_caption(f"DeLong's test comparing model AUCs to random classifier with AUC=0.5.")
            tabular = Tabular("|c|c|c|c|c|")
            tabular.add_hline()
            tabular.add_row([bold(item) for item in ['Model', 'Train Z-Score', 'Train p-Value', 'Test Z-Score', 'Test p-Value']])
            tabular.add_hline()
            for index, row in results_df.iterrows():
                delong_values = row[delong_test]
                formatted_values = [index]
                for value in delong_values:
                    if value == -np.inf:
                        formatted_values.append(r'-inf')
                    elif value == np.inf:
                        formatted_values.append(r'inf')
                    elif isinstance(value, (int, float)):
                        formatted_values.append(f'{value:.4f}')
                    else:
                        formatted_values.append(str(value))
                tabular.add_row(formatted_values)
                tabular.add_hline()
            table.append(tabular)
    else:
        delong_test = ['DeLong Test Train Z-Score to Random Classifier', 'DeLong Test Train p-Value to Random Classifier']
        with doc.create(Table(position='H')) as table:
            table.add_caption(f"DeLong's test comparing model AUCs to random classifier with AUC=0.5.")
            tabular = Tabular("|c|c|c|")
            tabular.add_hline()
            tabular.add_row([bold(item) for item in ['Model', 'Train Z-Score', 'Train p-Value']])
            tabular.add_hline()
            for index, row in results_df.iterrows():
                delong_values = row[delong_test]
                formatted_values = [index]
                for value in delong_values:
                    if value == -np.inf:
                        formatted_values.append(r'-inf')
                    elif value == np.inf:
                        formatted_values.append(r'inf')
                    elif isinstance(value, (int, float)):
                        formatted_values.append(f'{value:.4f}')
                    else:
                        formatted_values.append(str(value))
                tabular.add_row(formatted_values)
                tabular.add_hline()
            table.append(tabular)       
    doc.append(NoEscape(r'\clearpage'))
    doc.append(section)

    section = Section("Net Reclassification Index")
    if evaluate_on_test:
        nri = ["Train Net Reclassification Index to Random Classifier", "Test Net Reclassification Index to Random Classifier"]
        with doc.create(Table(position='H')) as table:
            table.add_caption(f"Net reclassification index comparing models to random classifier with probability of positive class = abundance.")
            tabular = Tabular("|c|c|c|")
            tabular.add_hline()
            tabular.add_row([bold(item) for item in ['Model', "Train Net Reclassification Index", "Test Net Reclassification Index"]])
            tabular.add_hline()
            for index, row in results_df.iterrows():
                nri_values = row[nri]
                formatted_values = [index]
                for value in nri_values:
                    if isinstance(value, (int, float)):
                        formatted_values.append(f'{value:.4f}')
                    else:
                        formatted_values.append(str(value))
                tabular.add_row(formatted_values)
                tabular.add_hline()
            table.append(tabular)
    else:
        nri = ["Train Net Reclassification Index to Random Classifier"]
        with doc.create(Table(position='H')) as table:
            table.add_caption(f"Net reclassification index comparing models to random classifier with probability of positive class = abundance.")
            tabular = Tabular("|c|c|")
            tabular.add_hline()
            tabular.add_row([bold(item) for item in ['Model', "Train Net Reclassification Index"]])
            tabular.add_hline()
            for index, row in results_df.iterrows():
                nri_values = row[nri]
                formatted_values = [index]
                for value in nri_values:
                    if isinstance(value, (int, float)):
                        formatted_values.append(f'{value:.4f}')
                    else:
                        formatted_values.append(str(value))
                tabular.add_row(formatted_values)
                tabular.add_hline()
            table.append(tabular)
    doc.append(NoEscape(r'\clearpage'))
    doc.append(section)

    section = Section("Decision Curve Analysis")
    subsection = Subsection("Net Benefit")
    if evaluate_on_test:
        net_benefit = ['Train Net Benefit Treated', 'Test Net Benefit Treated', 'Train Net Benefit Untreated', 'Test Net Benefit Untreated', 'Train Net Benefit Overall', 'Test Net Benefit Overall']
        with doc.create(Table(position='H')) as table:
            table.add_caption(f"Net benefit for patients treated based on model risk predictions.")
            tabular = Tabular("|c|c|c|")
            tabular.add_hline()
            tabular.add_row([bold(item) for item in ['Model', 'Train Net Benefit Treated', 'Test Net Benefit Treated']])
            tabular.add_hline()
            for index, row in results_df.iterrows():
                net_benefit_values = row[net_benefit[0:2]]
                formatted_values = [index]
                for value in net_benefit_values:
                    if isinstance(value, (int, float)):
                        formatted_values.append(f'{value:.4f}')
                    else:
                        formatted_values.append(str(value))
                tabular.add_row(formatted_values)
                tabular.add_hline()
            table.append(tabular)
        with doc.create(Table(position='H')) as table:
            table.add_caption(f"Net benefit for patients untreated based on model risk predictions.")
            tabular = Tabular("|c|c|c|")
            tabular.add_hline()
            tabular.add_row([bold(item) for item in ['Model', 'Train Net Benefit Untreated', 'Test Net Benefit Untreated']])
            tabular.add_hline()
            for index, row in results_df.iterrows():
                net_benefit_values = row[net_benefit[2:4]]
                formatted_values = [index]
                for value in net_benefit_values:
                    if isinstance(value, (int, float)):
                        formatted_values.append(f'{value:.4f}')
                    else:
                        formatted_values.append(str(value))
                tabular.add_row(formatted_values)
                tabular.add_hline()
            table.append(tabular)
        with doc.create(Table(position='H')) as table:
            table.add_caption(f"Sum of net benefits for treated and untreated patients based on model risk predictions.")
            tabular = Tabular("|c|c|c|")
            tabular.add_hline()
            tabular.add_row([bold(item) for item in ['Model', 'Train Net Benefit Overall', 'Test Net Benefit Overall']])
            tabular.add_hline()
            for index, row in results_df.iterrows():
                net_benefit_values = row[net_benefit[4:6]]
                formatted_values = [index]
                for value in net_benefit_values:
                    if isinstance(value, (int, float)):
                        formatted_values.append(f'{value:.4f}')
                    else:
                        formatted_values.append(str(value))
                tabular.add_row(formatted_values)
                tabular.add_hline()
            table.append(tabular)
        section.append(subsection)
        subsection = Subsection("ADAPT Index")
        adapt_index = ['Train ADAPT Index', 'Test ADAPT Index']
        with doc.create(Table(position='H')) as table:
            table.add_caption(f"ADAPT index for models.")
            tabular = Tabular("|c|c|c|")
            tabular.add_hline()
            tabular.add_row([bold(item) for item in ['Model', 'Train ADAPT Index', 'Test ADAPT Index']])
            tabular.add_hline()
            for index, row in results_df.iterrows():
                adapt_values = row[adapt_index]
                formatted_values = [index]
                for value in adapt_values:
                    if isinstance(value, (int, float)):
                        formatted_values.append(f'{value:.4f}')
                    else:
                        formatted_values.append(str(value))
                tabular.add_row(formatted_values)
                tabular.add_hline()
            table.append(tabular)
    else:
        net_benefit = ['Train Net Benefit Treated', 'Train Net Benefit Untreated', 'Train Net Benefit Overall']
        with doc.create(Table(position='H')) as table:
            table.add_caption(f"Net benefit for patients treated based on model risk predictions.")
            tabular = Tabular("|c|c|")
            tabular.add_hline()
            tabular.add_row([bold(item) for item in ['Model', 'Train Net Benefit Treated']])
            tabular.add_hline()
            for index, row in results_df.iterrows():
                net_benefit_values = row[net_benefit[0:1]]
                formatted_values = [index]
                for value in net_benefit_values:
                    if isinstance(value, (int, float)):
                        formatted_values.append(f'{value:.4f}')
                    else:
                        formatted_values.append(str(value))
                tabular.add_row(formatted_values)
                tabular.add_hline()
            table.append(tabular)
        with doc.create(Table(position='H')) as table:
            table.add_caption(f"Net benefit for patients untreated based on model risk predictions.")
            tabular = Tabular("|c|c|")
            tabular.add_hline()
            tabular.add_row([bold(item) for item in ['Model', 'Train Net Benefit Untreated']])
            tabular.add_hline()
            for index, row in results_df.iterrows():
                net_benefit_values = row[net_benefit[1:2]]
                formatted_values = [index]
                for value in net_benefit_values:
                    if isinstance(value, (int, float)):
                        formatted_values.append(f'{value:.4f}')
                    else:
                        formatted_values.append(str(value))
                tabular.add_row(formatted_values)
                tabular.add_hline()
            table.append(tabular)
        with doc.create(Table(position='H')) as table:
            table.add_caption(f"Sum of net benefits for treated and untreated patients based on model risk predictions.")
            tabular = Tabular("|c|c|")
            tabular.add_hline()
            tabular.add_row([bold(item) for item in ['Model', 'Train Net Benefit Overall']])
            tabular.add_hline()
            for index, row in results_df.iterrows():
                net_benefit_values = row[net_benefit[2:3]]
                formatted_values = [index]
                for value in net_benefit_values:
                    if isinstance(value, (int, float)):
                        formatted_values.append(f'{value:.4f}')
                    else:
                        formatted_values.append(str(value))
                tabular.add_row(formatted_values)
                tabular.add_hline()
            table.append(tabular)
        section.append(subsection)
        subsection = Subsection("ADAPT Index")
        adapt_index = ['Train ADAPT Index']
        with doc.create(Table(position='H')) as table:
            table.add_caption(f"ADAPT index for models.")
            tabular = Tabular("|c|c|")
            tabular.add_hline()
            tabular.add_row([bold(item) for item in ['Model', 'Train ADAPT Index']])
            tabular.add_hline()
            for index, row in results_df.iterrows():
                adapt_values = row[adapt_index]
                formatted_values = [index]
                for value in adapt_values:
                    if isinstance(value, (int, float)):
                        formatted_values.append(f'{value:.4f}')
                    else:
                        formatted_values.append(str(value))
                tabular.add_row(formatted_values)
                tabular.add_hline()
            table.append(tabular)
    doc.append(NoEscape(r'\clearpage'))
    section.append(subsection)
    doc.append(section)
    report_end(doc, filename, pdf=generate_pdf)

def model_explainability_lime_report(author, plots, filename='lime_model_explainability'):
    """
    Generates a LaTeX report for LIME model explainability results.

    Parameters:
        author (str): Author of the report.
        plots (list): List of plot file paths to include in the report.
        filename (str): Name of the file to save the report.
    """
    doc = report_header(author, f'LIME Model Explainability')
    section = Section("LIME Explanations")
    for plot in plots:
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                plot[1],
                width=NoEscape(r'\textwidth')
            )
            pic.add_caption(f"LIME explanation plot for {plot[0]}.")
    doc.append(section)
    report_end(doc, filename)

def model_explainability_survlime_report(author, plots, filename='survlime_model_explainability'):
    """
    Generates a LaTeX report for LIME model explainability results.

    Parameters:
        author (str): Author of the report.
        plots (list): List of plot file paths to include in the report.
        filename (str): Name of the file to save the report.
    """
    doc = report_header(author, f'LIME Model Explainability')
    for model_name in plots.keys():
        section = Section(f"LIME Explanations for {model_name}")
        for id, plot in plots[model_name]:
            with doc.create(Figure(position='htbp')) as pic:
                pic.add_image(
                    plot,
                    width=NoEscape(r'\textwidth')
                )
                if 'absolute' in plot:
                    pic.add_caption(f"LIME absolute feature importances for observation {id} and model {model_name}.")
                else:
                    pic.add_caption(f"LIME feature importances for observation {id} and model {model_name}.")
        doc.append(section)
    report_end(doc, filename)

def model_explainability_shap_report(author, interaction_plots, interaction_heatmaps, partial_dependence_plots, waterfall_plots, beeswarm_plots, decision_plots, force_plots, embedding_plots, heatmaps, filename='shap_model_explainability'):
    """
    Generates a LaTeX report for SHAP model explainability results.

    Parameters:
        author (str): Author of the report.
        interaction_plots (list): List of interaction plot file paths to include in the report.
        interaction_heatmaps (list): List of interaction heatmap file paths to include in the report.
        partial_dependence_plots (list): List of partial dependence plot file paths to include in the report.
        waterfall_plots (list): List of waterfall plot file paths to include in the report.
        beeswarm_plots (list): List of beeswarm plot file paths to include in the report.
        filename (str): Name of the file to save the report.
    """
    doc = report_header(author, f'SHAP Model Explainability')
    section = Section("Interaction Plots")
    for plot in interaction_plots:
        if len(plot) == 3:
            with doc.create(Figure(position='htbp')) as pic:
                pic.add_image(
                    plot[2],
                    width=NoEscape(r'\textwidth')
                )
                pic.add_caption(f"SHAP interaction plot for class {plot[1]} and model {plot[0]}.")
        else:
            with doc.create(Figure(position='htbp')) as pic:
                pic.add_image(
                    plot[1],
                    width=NoEscape(r'\textwidth')
                )
                pic.add_caption(f"SHAP interaction plot for model {plot[0]}.")
    doc.append(section)

    section = Section("Interaction Heatmaps")
    for heatmap in interaction_heatmaps:
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                heatmap[2],
                width=NoEscape(r'\textwidth')
            )
            pic.add_caption(f"SHAP interaction heatmap for class {heatmap[1]} and model {heatmap[0]}.")
    doc.append(section)

    section = Section("Waterfall Plots")
    for plot in waterfall_plots:
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                plot[1],
                width=NoEscape(r'\textwidth')
            )
            pic.add_caption(f"SHAP waterfall plot for model {plot[0]}.")
    doc.append(section)

    section = Section("Beeswarm Plots")
    for plot in beeswarm_plots:
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                plot[1],
                width=NoEscape(r'\textwidth')
            )
            pic.add_caption(f"SHAP beeswarm plot for model {plot[0]}.")
    doc.append(section)

    section = Section("Decision Plots")
    for plot in decision_plots:
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                plot[1],
                width=NoEscape(r'\textwidth')
            )
            pic.add_caption(f"SHAP decision plot for model {plot[0]}.")
    doc.append(section)

    section = Section("Force Plots")
    for plot in force_plots:
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                plot[1],
                width=NoEscape(r'\textwidth')
            )
            pic.add_caption(f"SHAP force plot for model {plot[0]}.")
    doc.append(section)

    section = Section("Heatmaps")
    for heatmap in heatmaps:
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                heatmap[1],
                width=NoEscape(r'\textwidth')
            )
            pic.add_caption(f"SHAP heatmap for model {heatmap[0]}.")
    doc.append(section)

    report_end(doc, filename)

    doc = report_header(author, f'SHAP Model Partial Dependence')
    for plot in partial_dependence_plots:
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                plot[2],
                width=NoEscape(r'\textwidth')
            )
            pic.add_caption(f"SHAP partial dependence plot for feature {plot[1]} and model {plot[0]}.")
    
    report_end(doc, f'{filename}_partial_dependence', pdf=False)

    doc = report_header(author, f'SHAP Model Embedding Plots')
    for plot in embedding_plots:
        with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                plot[2],
                width=NoEscape(r'\textwidth')
            )
            pic.add_caption(f"SHAP embedding plot for feature {plot[1]} and model {plot[0]}.")

    report_end(doc, f'{filename}_embedding', pdf=False)

def explain_tree_predictions_report(author, X, sample_ids, predictions, n_nodes, node_indicator, leaf_id, feature, threshold, filename='decision_tree_predictions'):
    """
    Report Explaining decision tree predictions

    Parameters:
    author (str): author name
    X (pandas DataFrame): features
    sample_ids (list): list of IDs to explain
    predictions (numpy array): list of predictions
    n_nodes (int): number of nodes in the tree
    node_indicator (scipy sparse matrix): indicator matrix indicating the nodes that each sample traverses through
    leaf_id (numpy array): index of the leaf node that each sample is predicted to reach
    feature (numpy array): features used for splitting each node
    threshold (numpy array): threshold values at each node
    filename (str): name of file
    """
    doc = report_header(author, f'Decision Tree Predictions Explanation')
    for sample_id in sample_ids:
        section = Section(f"Rules Used to Predict Sample {sample_id}")
        # obtain ids of the nodes `sample_id` goes through, i.e., row `sample_id`
        node_index = node_indicator.indices[
            node_indicator.indptr[sample_id] : node_indicator.indptr[sample_id + 1]
        ]
        for node_id in node_index:
            # continue to the next node if it is a leaf node
            if leaf_id[sample_id] == node_id:
                continue

            # check if value of the split feature for sample 0 is below threshold
            if X.iloc[sample_id, feature[node_id]] <= threshold[node_id]:
                threshold_sign = "<="
            else:
                threshold_sign = ">"

            section.append(
                "decision node {node} : {feature} = {value} "
                "{inequality} {threshold})\n".format(
                    node=node_id,
                    sample=sample_id,
                    feature=X.columns[feature[node_id]],
                    value=X.iloc[sample_id, feature[node_id]],
                    inequality=threshold_sign,
                    threshold=threshold[node_id],
                )
            )
        section.append(f'Final prediction: {predictions[sample_id]}')
        doc.append(section)
    
    if len(sample_ids) > 1:
        section = Section('Common Nodes Traced by All Samples Considered')
        # boolean array indicating the nodes both samples go through
        common_nodes = node_indicator.toarray()[sample_ids].sum(axis=0) == len(sample_ids)
        # obtain node ids using position in array
        common_node_id = np.arange(n_nodes)[common_nodes]

        section.append(
            "The following samples {samples} share the node(s) {nodes} in the tree.\n".format(
                samples=sample_ids, nodes=common_node_id
            )
        )
        section.append("This is {prop}% of all nodes.".format(prop=100 * len(common_node_id) / n_nodes))
        doc.append(section)
    
    report_end(doc, filename)

def kaplan_meier_model_report(author, plots, results, filename="kaplan_meier_evaluation"):
    """
    Generates a LaTeX report for kaplan meier model evaluation results.

    Parameters:
        author (str): Author of the report.
        model (lifelines model): fitted model
        X_train : array‐like, shape (n_samples, n_features): Feature matrix.
        y_train : array‐like, shape (n_samples,): Survival times.
        partial_effects_plots (dict): Dictionary of feature names and partial effects plots
        summary (pandas DataFrame): DataFrame containing model evaluation results.
        filename (str): Name of the file to save the report.
    
    """
    doc = report_header(author, f'Kaplan Meier Model Evaluation')
    section = Section("Kaplan Meier Curves")
    for feature, plot in plots.items():
        with doc.create(Figure(position='htbp')) as pic:
                pic.add_image(
                    plot,
                    width=NoEscape(r'\textwidth')
                )
                pic.add_caption(f"Kaplan-Meier curve for {feature}.")
    doc.append(section)

    section = Section("Evaluation Results")
    with doc.create(Table(position='htbp')) as table:
        table.add_caption(f"Median survival between groups")
        table_layout = "|c|c|c|"
        tabular = Tabular(table_layout)
        tabular.add_hline()
        tabular.add_row([bold('Feature'),bold('Median Survival Time'), bold('Median Survival Time')])
        tabular.add_row([bold(''),bold('Feature < Median'), bold('Feature > Median')])
        tabular.add_hline()

        for index, row in results.iterrows():
            row_list = list(row.values)
            tabular.add_row([row_list[0], row_list[2], row_list[3]])
            tabular.add_hline()
        table.append(tabular)
    with doc.create(Table(position='htbp')) as table:
        table.add_caption(f"p-value between feature groups. ")
        table_layout = "|c|c|"
        tabular = Tabular(table_layout)
        tabular.add_hline()
        tabular.add_row([bold('Feature'),bold('Log Rank Test p-value Between Groups')])
        tabular.add_hline()
        for index, row in results.iterrows():
            row_list = list(row.values)
            tabular.add_row([row_list[0], row_list[4]])
            tabular.add_hline()
        table.append(tabular)
    with doc.create(Table(position='htbp')) as table:
        table.add_caption(f"p-value between feature < median and full dataset.")
        table_layout = "|c|c|"
        tabular = Tabular(table_layout)
        tabular.add_hline()
        tabular.add_row([bold('Feature'),bold('Log Rank Test p-value')])
        tabular.add_hline()
        for index, row in results.iterrows():
            row_list = list(row.values)
            tabular.add_row([row_list[0], row_list[5]])
            tabular.add_hline()
        table.append(tabular)
    with doc.create(Table(position='htbp')) as table:
        table.add_caption(f"p-value between feature > median and full dataset.")
        table_layout = "|c|c|"
        tabular = Tabular(table_layout)
        tabular.add_hline()
        tabular.add_row([bold('Feature'),bold('Log Rank Test p-value')])
        tabular.add_hline()
        for index, row in results.iterrows():
            row_list = list(row.values)
            tabular.add_row([row_list[0], row_list[6]])
            tabular.add_hline()
        table.append(tabular)
    section.append("Model evaluation results")

    doc.append(section)
    report_end(doc, filename)

def kaplan_meier_calibration_report(author, df, n_bins, alpha=0.05, filename="kaplan_meier_calibration"):
    """
    Generates a LaTeX report for kaplan meier model calibrationresults.

    Parameters:
        author (str): Author of the report.
        df (pandas DataFrame): DataFrame containing model evaluation results.
        n_bins (int): number of bins used for evaluating calibration
        alpha (float): significance level
        filename (str): Name of the file to save the report.
    
    """
    doc = report_header(author, f'Kaplan Meier Model Calibration')
    section = Section("D-Calibration")
    p_values = df['p-Value']
    section.append(f"{n_bins} bins were used to test whether the survival function was uniformly distributed using the Pearson chi-square test.\n")
    section.append(f"P-values range between {min(p_values):.4f} and {max(p_values):.4f}.\n")
    for row in df.iterrows():
        if row[1]["p-Value"] < alpha:
            section.append(f"Model {row[1]['Model']} is significant when alpha = {alpha}.\n p={row[1]['p-Value']:.4f}\n")
    doc.append(section)
    report_end(doc, filename)

def survival_model_report(author, model, model_name, X_train, y_train, X_test, y_test, partial_effects_plots, summary, bootstrap_df, confidence, filename='cox_proportional_hazards_evaluation', proportional_hazard_significance=[0.05,0.05]):
    """
    Generates a LaTeX report for survival model evaluation results.

    Parameters:
        author (str): Author of the report.
        model (lifelines model): fitted model
        X_train : array‐like, shape (n_samples, n_features): Feature matrix.
        y_train : array‐like, shape (n_samples,): Survival times.
        X_test: array‐like, shape (n_samples, n_features): Feature matrix.
        y_test : array‐like, shape (n_samples,): Survival times.
        partial_effects_plots (dict): Dictionary of feature names and partial effects plots
        summary (pandas DataFrame): DataFrame containing model evaluation results.
        bootstrap_df (pandas DataFrame): DataFrame containing model evaluation results.
        confidence (float): confidence level
        filename (str): Name of the file to save the report.
    
    """
    doc = report_header(author, f'{model_name} Model Evaluation')
    if 'cox' in model_name.lower():
        section = Section("Feature Hazard Ratios")
        with doc.create(Figure(position='htbp')) as pic:
                pic.add_image(
                    f'{model_name}_coefficients.png',
                    width=NoEscape(r'\textwidth')
                )
                pic.add_caption(f"Hazard Ratios for covariates.")
        doc.append(section)
    else:
        section = Section("Accelerated Failure Rates")
        with doc.create(Figure(position='htbp')) as pic:
                pic.add_image(
                    f'{model_name}_coefficients.png',
                    width=NoEscape(r'\textwidth')
                )
                pic.add_caption(f"Accelerated failure rates for covariates.")
        doc.append(section)

    section = Section("Linear Predictor Distribution")
    with doc.create(Figure(position='htbp')) as pic:
            pic.add_image(
                f'{model_name}_LP_distribution.png',
                width=NoEscape(r'\textwidth')
            )
            pic.add_caption(f"Distribution of linear predictor values for training data.")

    section = Section("Partial Effects Plots")
    for variable, plot in partial_effects_plots.items():
        if variable == 'Linear Predictor Value':
            with doc.create(Figure(position='htbp')) as pic:
                pic.add_image(
                    plot,
                    width=NoEscape(r'\textwidth')
                )
                pic.add_caption(f"Effect of Varying the linear predictor value on survival curve.")
        else:
            with doc.create(Figure(position='htbp')) as pic:
                pic.add_image(
                    plot,
                    width=NoEscape(r'\textwidth')
                )
                pic.add_caption(f"Effect of Varying {variable} on survival curve.")

    doc.append(section)

    if 'cox' in model_name.lower():
        section = Section("Hazard Ratios")
        with doc.create(Table(position='htbp')) as table:
            table.add_caption(f"Hazard ratios for the model. The {confidence*100}% confidence interval for the hazard ratios is shown.")
            tabular = Tabular("|c|c|c|")
            tabular.add_hline()
            tabular.add_row([bold('Feature'), bold('Hazard Ratio'), bold('p')])
            tabular.add_hline()        
            for index, row in summary.iterrows():
                #print(row.columns)
                if confidence == 0.95:
                    ci_lower = f"{row['exp(coef) lower 95%']:.3f}"
                    ci_upper = f"{row['exp(coef) upper 95%']:.3f}"
                else:
                    ci_lower = f"{row[f'exp(coef) lower {confidence*100}%']:.3f}"
                    ci_upper = f"{row[f'exp(coef) upper {confidence*100}%']:.3f}"
                row_list = [row['covariate'], f"{row['exp(coef)']:.3f} [{ci_lower}, {ci_upper}]", f"{row['p']:.4f}"]
                tabular.add_row(row_list)
                tabular.add_hline()
            table.append(tabular)
        aic = model.AIC_partial_
        section = Section("Testing Proportional Hazards Assumption")
        rank_test = pd.read_csv('rank_test_proportional_hazards_assumption.csv')
        with doc.create(Table(position='htbp')) as table:
            table.add_caption(f"The rank test was used to determine if the feature obeyed proportional hazards assumption.")
            tabular = Tabular("|c|c|")
            tabular.add_hline()
            tabular.add_row([bold('Feature'), bold('p')])
            tabular.add_hline()
            for index, row in rank_test.iterrows():
                row_list = [row.iloc[0], row['p']]
                tabular.add_row(row_list)
                tabular.add_hline()
            table.append(tabular)

        km_test = pd.read_csv('km_test_proportional_hazards_assumption.csv')
        with doc.create(Table(position='htbp')) as table:
            table.add_caption(f"The KM test was used to determine if the feature obeyed proportional hazards assumption.")
            tabular = Tabular("|c|c|")
            tabular.add_hline()
            tabular.add_row([bold('Feature'), bold('p')])
            tabular.add_hline()

            for index, row in km_test.iterrows():
                row_list = [row.iloc[0], row['p']]
                tabular.add_row(row_list)
                tabular.add_hline()
            table.append(tabular)
    else:
        section = Section("Accelerated failure rates")
        with doc.create(Table(position='htbp')) as table:
            table.add_caption(f"Accelerated failure rates for the model. The {confidence*100}% confidence interval for the accelerated failure rates is shown.")
            tabular = Tabular("|c|c|c|")
            tabular.add_hline()
            tabular.add_row([bold('Feature'), bold('Accelerated Failure Rate'), bold('p')])
            tabular.add_hline()        
            for index, row in summary.iterrows():
                #print(row.columns)
                if confidence == 0.95:
                    ci_lower = f"{row['exp(coef) lower 95%']:.3f}"
                    ci_upper = f"{row['exp(coef) upper 95%']:.3f}"
                else:
                    ci_lower = f"{row[f'exp(coef) lower {confidence*100}%']:.3f}"
                    ci_upper = f"{row[f'exp(coef) upper {confidence*100}%']:.3f}"
                row_list = [row['covariate'], f"{row['exp(coef)']:.3f} [{ci_lower}, {ci_upper}]", f"{row['p']:.4f}"]
                tabular.add_row(row_list)
                tabular.add_hline()
            table.append(tabular)
        aic = model.AIC_

    section = Section("Model Evaluation Metrics")
    with doc.create(Table(position='htbp')) as table:
        table.add_caption(f"Model evaluation metrics.")
        tabular = Tabular("|c|c|c|c|c|")
        tabular.add_hline()
        tabular.add_row([bold('Log Likelihood Train'), bold('Log Likelihood Test'), bold('AIC'), bold('C Index Train'), bold('C Index Test')])
        tabular.add_hline()
        log_likelihood_train = model.score(pd.concat([X_train, y_train], axis=1))
        lower_ci = bootstrap_df[f'{(100 - confidence*100)/2:.1f}%']
        upper_ci = bootstrap_df[f'{(100 + confidence*100)/2:.1f}%']
        log_likelihood_test = model.score(pd.concat([X_test, y_test], axis=1))
        c_index_train = model.score(pd.concat([X_train, y_train], axis=1), scoring_method="concordance_index")
        c_index_test = model.score(pd.concat([X_test, y_test], axis=1), scoring_method="concordance_index")
        tabular.add_row([f'{log_likelihood_train:.3f} ({lower_ci.values[0]:.3f}, {upper_ci.values[0]:.3f})', f'{log_likelihood_test:.3f}', f'{aic:.3f} ({lower_ci.values[1]:.3f}, {upper_ci.values[1]:.3f})', f'{c_index_train:.3f} ({lower_ci.values[2]:.3f}, {upper_ci.values[2]:.3f})', f'{c_index_test:.3f}'])
        tabular.add_hline()
        table.append(tabular)
    doc.append(section)

    report_end(doc, filename)