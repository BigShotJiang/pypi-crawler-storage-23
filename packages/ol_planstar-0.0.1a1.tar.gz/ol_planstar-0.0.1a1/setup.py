"""
    Library setup file
"""

from setuptools import setup


def read_version() -> str:
    import os

    version_ns = {}
    here = os.path.abspath(os.path.dirname(__file__))
    version_path = os.path.join(here, "planstar", "_version.py")
    with open(version_path, "r", encoding="utf-8") as f:
        exec(f.read(), version_ns)
    return version_ns["__version__"]


def read_long_description() -> str:
    import os

    here = os.path.abspath(os.path.dirname(__file__))
    md_path = os.path.join(here, "docs", "planstar.md")
    with open(md_path, "r", encoding="utf-8") as f:
        return f.read()


setup(
    name="ol_planstar",
    include_package_data=False,
    version=read_version(),
    description="Placeholder release to reserve the ol_planstar namespace",
    # Temporarily disabled until package long description source exists.
    # long_description=read_long_description(),
    # long_description_content_type="text/markdown",
    url="https://cosmicfrog.com",
    author="Optilogic",
    packages=[],
    py_modules=[],
    license="MIT",
    install_requires=[],
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.11",
)
