"""UV boost module."""

from pimp_my_repo.core.boosts.uv.uv import UvBoost

__all__ = ["UvBoost"]
