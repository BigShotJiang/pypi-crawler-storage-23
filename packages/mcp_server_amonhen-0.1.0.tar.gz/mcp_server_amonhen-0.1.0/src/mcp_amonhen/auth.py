# Confidential and Proprietary
# Copyright (c) 2024-2026 AmonHen AI.
# All rights reserved.
# Unauthorized copying or distribution is strictly prohibited.

"""Auth0 Device Authorization Flow + token management for Amon Hen MCP."""

from __future__ import annotations

import json
import os
import sys
import time

import httpx
import keyring

AUTH0_DOMAIN = "dev-i72wyxkz0ecgxnnk.us.auth0.com"
AUTH0_CLIENT_ID = "3ICY4zJWDWK6PU5ff6hbXCb3JCnCK221"
AUTH0_AUDIENCE = "https://amonhen-api"
AUTH0_SCOPES = "openid profile email offline_access"

KEYRING_SERVICE = "amonhen-mcp"
KEYRING_USERNAME = "tokens"


def _store_tokens(access_token: str, refresh_token: str) -> None:
    """Persist tokens securely in the OS keychain."""
    data = json.dumps({
        "access_token": access_token,
        "refresh_token": refresh_token,
    })
    keyring.set_password(KEYRING_SERVICE, KEYRING_USERNAME, data)


def _load_tokens() -> dict | None:
    """Load stored tokens from the OS keychain."""
    raw = keyring.get_password(KEYRING_SERVICE, KEYRING_USERNAME)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return None


def _clear_tokens() -> None:
    """Remove stored tokens from the OS keychain."""
    try:
        keyring.delete_password(KEYRING_SERVICE, KEYRING_USERNAME)
    except keyring.errors.PasswordDeleteError:
        pass


def _decode_jwt_payload(token: str) -> dict | None:
    """Decode JWT payload without verification (for expiry check only)."""
    import base64

    parts = token.split(".")
    if len(parts) != 3:
        return None
    # Add padding
    payload_b64 = parts[1] + "=" * (4 - len(parts[1]) % 4)
    try:
        payload_bytes = base64.urlsafe_b64decode(payload_b64)
        return json.loads(payload_bytes)
    except Exception:
        return None


def _is_token_expired(token: str, buffer_seconds: int = 60) -> bool:
    """Check if a JWT is expired (with buffer)."""
    payload = _decode_jwt_payload(token)
    if not payload or "exp" not in payload:
        return True
    return time.time() >= payload["exp"] - buffer_seconds


def _refresh_access_token(refresh_token: str) -> dict:
    """Exchange a refresh token for a new access token."""
    resp = httpx.post(
        f"https://{AUTH0_DOMAIN}/oauth/token",
        data={
            "grant_type": "refresh_token",
            "client_id": AUTH0_CLIENT_ID,
            "refresh_token": refresh_token,
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    resp.raise_for_status()
    return resp.json()


def get_access_token() -> str | None:
    """Get a valid access token, refreshing if needed.

    Priority:
    1. AMONHEN_TOKEN env var (for CI/headless)
    2. Keyring-stored token (with auto-refresh)
    """
    # 1. Env var override
    env_token = os.environ.get("AMONHEN_TOKEN")
    if env_token:
        return env_token

    # 2. Keyring
    tokens = _load_tokens()
    if not tokens:
        return None

    access_token = tokens.get("access_token", "")
    refresh_token = tokens.get("refresh_token", "")

    if access_token and not _is_token_expired(access_token):
        return access_token

    if not refresh_token:
        _clear_tokens()
        return None

    try:
        new_tokens = _refresh_access_token(refresh_token)
        new_access = new_tokens["access_token"]
        new_refresh = new_tokens.get("refresh_token", refresh_token)
        _store_tokens(new_access, new_refresh)
        return new_access
    except Exception:
        _clear_tokens()
        return None


def login_interactive() -> None:
    """Run the Auth0 Device Authorization Flow interactively."""
    print("Requesting device code from Auth0...")

    resp = httpx.post(
        f"https://{AUTH0_DOMAIN}/oauth/device/code",
        data={
            "client_id": AUTH0_CLIENT_ID,
            "scope": AUTH0_SCOPES,
            "audience": AUTH0_AUDIENCE,
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )

    if resp.status_code != 200:
        print(f"Error requesting device code: {resp.status_code} {resp.text}", file=sys.stderr)
        sys.exit(1)

    data = resp.json()
    device_code = data["device_code"]
    user_code = data["user_code"]
    verification_uri = data["verification_uri_complete"]
    interval = data.get("interval", 5)
    expires_in = data.get("expires_in", 900)

    print()
    print(f"  Visit:  {verification_uri}")
    print(f"  Code:   {user_code}")
    print()
    print("Waiting for authorization...", end="", flush=True)

    deadline = time.time() + expires_in

    while time.time() < deadline:
        time.sleep(interval)

        token_resp = httpx.post(
            f"https://{AUTH0_DOMAIN}/oauth/token",
            data={
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "device_code": device_code,
                "client_id": AUTH0_CLIENT_ID,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

        if token_resp.status_code == 200:
            tokens = token_resp.json()
            _store_tokens(
                tokens["access_token"],
                tokens.get("refresh_token", ""),
            )
            print(" done!")
            print("Signed in successfully. Tokens stored in your OS keychain.")
            return

        error = token_resp.json().get("error", "")
        if error == "authorization_pending":
            print(".", end="", flush=True)
            continue
        elif error == "slow_down":
            interval += 5
            continue
        else:
            print(f"\nError: {token_resp.json().get('error_description', error)}", file=sys.stderr)
            sys.exit(1)

    print("\nDevice code expired. Please try again.", file=sys.stderr)
    sys.exit(1)


def logout() -> None:
    """Clear stored tokens."""
    _clear_tokens()
    print("Signed out. Tokens removed from keychain.")
