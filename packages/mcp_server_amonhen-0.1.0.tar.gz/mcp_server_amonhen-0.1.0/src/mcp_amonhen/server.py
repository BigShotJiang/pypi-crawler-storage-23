# Confidential and Proprietary
# Copyright (c) 2024-2026 AmonHen AI.
# All rights reserved.
# Unauthorized copying or distribution is strictly prohibited.

"""Amon Hen MCP Server — exposes advisory, projects, context, packs, and learning as tools."""

from __future__ import annotations

import json

from mcp.server.fastmcp import FastMCP

from mcp_amonhen.client import AmonHenClient

mcp = FastMCP(
    "Amon Hen",
    instructions="Project-scoped security & compliance advisory, grounded in your team's decisions and rules",
)

_client = AmonHenClient()


# ---------------------------------------------------------------------------
# Tools — Advisory
# ---------------------------------------------------------------------------

@mcp.tool()
async def advise(
    question: str,
    project_id: str | None = None,
    history: list[dict] | None = None,
) -> str:
    """Ask Amon Hen for project-scoped advisory.

    Provides security, compliance, and architecture guidance grounded in your
    project's rules, decisions, and knowledge base.

    Args:
        question: Your advisory question.
        project_id: Project UUID to scope the advice. Omit for general advisory.
        history: Optional conversation history as [{role, content}, ...].
    """
    result = await _client.advise(question, project_id, history)
    advice = result.get("advice", "")
    hints = result.get("follow_up_hints", [])
    parts = [advice]
    if hints:
        parts.append("\n\nSuggested follow-ups:")
        for h in hints:
            parts.append(f"  - {h}")
    return "\n".join(parts)


@mcp.tool()
async def gaap_advise(
    question: str,
    project_id: str,
    evidence_refs: list[str] | None = None,
) -> str:
    """Get GAAP-aware structured advisory from Amon Hen.

    Returns structured output with governing framework, standards touched,
    required facts, disclosure flags, and materiality notes.

    Args:
        question: Your GAAP-related question.
        project_id: Project UUID (required for GAAP context).
        evidence_refs: Optional list of evidence reference IDs.
    """
    result = await _client.gaap_advise(question, project_id, evidence_refs)
    output = result.get("output", result)
    return json.dumps(output, indent=2)


@mcp.tool()
async def legal_advise(
    question: str,
    project_id: str,
    jurisdiction: str,
    evidence_refs: list[str] | None = None,
) -> str:
    """Get legal decision-support advisory from Amon Hen.

    Returns structured output with governing authorities, legal principles,
    risk factors, compliance considerations, and contractual impacts.
    Always flags that counsel review is required.

    Args:
        question: Your legal question.
        project_id: Project UUID (required for legal context).
        jurisdiction: Jurisdiction code (e.g. "US", "EU", "UK").
        evidence_refs: Optional list of evidence reference IDs.
    """
    result = await _client.legal_advise(question, project_id, jurisdiction, evidence_refs)
    output = result.get("output", result)
    return json.dumps(output, indent=2)


# ---------------------------------------------------------------------------
# Tools — Projects
# ---------------------------------------------------------------------------

@mcp.tool()
async def list_projects() -> str:
    """List all Amon Hen projects you own or have access to.

    Returns project names, IDs, visibility, context counts, and your role.
    """
    projects = await _client.list_projects()
    if not projects:
        return "No projects found. Create one at https://app.amonhenai.com"
    lines = []
    for p in projects:
        name = p.get("name", "?")
        pid = p.get("id", "?")
        vis = p.get("visibility", "?")
        count = p.get("context_count", 0)
        role = p.get("role", "?")
        lines.append(f"- {name}  (id: {pid}, {vis}, {count} items, role: {role})")
    return "\n".join(lines)


@mcp.tool()
async def get_project(project_id: str) -> str:
    """Get detailed info about an Amon Hen project.

    Shows metadata, context item counts by type, applied starter packs,
    and project hierarchy.

    Args:
        project_id: The project UUID.
    """
    detail = await _client.get_project(project_id)
    return json.dumps(detail, indent=2, default=str)


# ---------------------------------------------------------------------------
# Tools — Context
# ---------------------------------------------------------------------------

@mcp.tool()
async def get_project_context(
    project_id: str,
    intent: str | None = None,
) -> str:
    """Fetch all rules, decisions, and knowledge for a project.

    Returns the full assembled context grouped by type (rules, decisions,
    code_context, notes). Use this at the start of a coding session to load
    project rules that must be enforced on every code change.

    Args:
        project_id: The project UUID.
        intent: Optional task description for vector-assisted retrieval.
    """
    result = await _client.get_context(project_id, intent=intent)
    return _format_context(result)


def _format_context(context_result: dict) -> str:
    """Format assembled context items as structured text grouped by type."""
    items = context_result.get("context", [])
    if not items:
        return "(No project context items found.)"

    buckets: dict[str, list[str]] = {
        "rule": [],
        "decision": [],
        "code_context": [],
        "note": [],
    }

    for item in items:
        item_type = item.get("item_type", "note")
        content = item.get("content", "")
        if item_type in buckets:
            buckets[item_type].append(content)

    sections = []

    if buckets["rule"]:
        sections.append("## RULES (absolute law — must be followed)")
        for i, r in enumerate(buckets["rule"], 1):
            sections.append(f"{i}. {r}")
        sections.append("")

    if buckets["decision"]:
        sections.append("## DECISIONS (committed team choices — apply, do not revisit)")
        for i, d in enumerate(buckets["decision"], 1):
            sections.append(f"{i}. {d}")
        sections.append("")

    if buckets["code_context"]:
        sections.append("## CODE CONTEXT (implementation patterns)")
        for i, c in enumerate(buckets["code_context"], 1):
            sections.append(f"{i}. {c}")
        sections.append("")

    if buckets["note"]:
        sections.append("## NOTES (observations and context)")
        for i, n in enumerate(buckets["note"], 1):
            sections.append(f"{i}. {n}")
        sections.append("")

    return "\n".join(sections)


@mcp.tool()
async def create_context(
    project_id: str,
    item_type: str,
    content: str,
    rationale: str | None = None,
) -> str:
    """Add a context item (rule, decision, note, or code_context) to a project.

    This enriches the project's knowledge base so future advisory responses
    are grounded in your team's actual decisions and conventions.

    Args:
        project_id: The project UUID.
        item_type: One of: rule, decision, note, code_context.
        content: The content of the context item.
        rationale: Optional explanation for why this item exists.
    """
    result = await _client.create_context(project_id, item_type, content, rationale)
    item_id = result.get("id", "unknown")
    return f"Created {item_type} (id: {item_id}) in project {project_id}."


# ---------------------------------------------------------------------------
# Tools — Starter Packs
# ---------------------------------------------------------------------------

@mcp.tool()
async def list_packs(project_id: str | None = None) -> str:
    """Browse available Amon Hen starter packs.

    Starter packs are curated sets of rules, decisions, and notes for
    specific domains (SAP, security, compliance, etc.).

    Args:
        project_id: Optional project UUID to see which packs are already applied.
    """
    result = await _client.list_packs(project_id)
    packs = result.get("packs", [])
    if not packs:
        return "No starter packs available."
    lines = []
    for p in packs:
        name = p.get("display_name", p.get("name", "?"))
        ver = p.get("version", "?")
        count = p.get("item_count", 0)
        applied = " [APPLIED]" if p.get("applied") else ""
        lines.append(f"- {name} v{ver} ({count} items){applied}")
    return "\n".join(lines)


@mcp.tool()
async def apply_pack(
    project_id: str,
    starter_pack_name: str,
    version: str = "1.0.0",
) -> str:
    """Apply a starter pack to a project.

    Imports all rules, decisions, and notes from the pack into the project's
    context. Idempotent — applying the same pack twice is a no-op.

    Args:
        project_id: The project UUID.
        starter_pack_name: Pack slug (e.g. "sap-software-sales-excellence-pack").
        version: Pack version (default "1.0.0").
    """
    result = await _client.apply_pack(project_id, starter_pack_name, version)
    count = result.get("items_inserted", 0)
    return f"Applied {starter_pack_name} v{version}: {count} items inserted."


# ---------------------------------------------------------------------------
# Tools — Learning
# ---------------------------------------------------------------------------

@mcp.tool()
async def list_pending_learning(project_id: str) -> str:
    """View draft learning proposals for a project.

    Learning proposals are knowledge items extracted from advisory conversations
    that await your approval before being added to the project context.

    Args:
        project_id: The project UUID.
    """
    result = await _client.list_pending_learning(project_id)
    proposals = result.get("proposals", [])
    if not proposals:
        return "No pending learning proposals."
    lines = []
    for p in proposals:
        pid = p.get("proposal_id", "?")
        q = p.get("question", "?")
        count = p.get("items_extracted", 0)
        lines.append(f"- Proposal {pid}: \"{q}\" ({count} items extracted)")
    return "\n".join(lines)


@mcp.tool()
async def approve_learning(proposal_id: str) -> str:
    """Approve a learning proposal, committing its items to the project context.

    Args:
        proposal_id: The proposal UUID to approve.
    """
    result = await _client.approve_learning(proposal_id)
    committed = result.get("items_committed", 0)
    commit_id = result.get("commit_id", "?")
    return f"Approved: {committed} items committed (commit {commit_id})."


# ---------------------------------------------------------------------------
# Resources — read-only context for Claude
# ---------------------------------------------------------------------------

@mcp.resource("amonhen://projects")
async def resource_projects() -> str:
    """List of all Amon Hen projects accessible to the current user."""
    return await list_projects()


@mcp.resource("amonhen://project/{project_id}/suggestions")
async def resource_suggestions(project_id: str) -> str:
    """AI-generated question suggestions for a project."""
    result = await _client.get_suggestions(project_id)
    suggestions = result.get("suggestions", [])
    if not suggestions:
        return "No suggestions available for this project."
    return "\n".join(f"- {s}" for s in suggestions)


@mcp.resource("amonhen://project/{project_id}/context")
async def resource_context(project_id: str) -> str:
    """Full project context (rules, decisions, code_context, notes)."""
    result = await _client.get_context(project_id)
    return _format_context(result)
