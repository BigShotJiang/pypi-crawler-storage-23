# Confidential and Proprietary
# Copyright (c) 2024-2026 AmonHen AI.
# All rights reserved.
# Unauthorized copying or distribution is strictly prohibited.

"""Amon Hen MCP Server — project-scoped advisory for Claude Code."""

from __future__ import annotations

import sys


def main() -> None:
    """CLI entry point for amonhen-mcp."""
    if len(sys.argv) > 1 and sys.argv[1] == "login":
        from mcp_amonhen.auth import login_interactive
        login_interactive()
    elif len(sys.argv) > 1 and sys.argv[1] == "logout":
        from mcp_amonhen.auth import logout
        logout()
    elif len(sys.argv) > 1 and sys.argv[1] == "serve":
        from mcp_amonhen.server import mcp
        mcp.run(transport="stdio")
    else:
        # Default: run as MCP server (stdio) — this is what Claude Code calls
        from mcp_amonhen.server import mcp
        mcp.run(transport="stdio")
