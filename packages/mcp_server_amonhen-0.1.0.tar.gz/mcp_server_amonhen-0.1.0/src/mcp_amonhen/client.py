# Confidential and Proprietary
# Copyright (c) 2024-2026 AmonHen AI.
# All rights reserved.
# Unauthorized copying or distribution is strictly prohibited.

"""Async HTTP client for the Amon Hen API.

Ported from vscode-amonhen/src/api/client.ts — same endpoints, same shapes.
"""

from __future__ import annotations

import os
from typing import Any

import httpx

from mcp_amonhen.auth import get_access_token

DEFAULT_API_URL = "https://amonhen.onrender.com"


class ApiError(Exception):
    def __init__(self, status: int, body: str, path: str) -> None:
        self.status = status
        self.body = body
        self.path = path
        super().__init__(f"API {status} on {path}: {body}")


class AmonHenClient:
    """Async HTTP client for Amon Hen REST API."""

    def __init__(self) -> None:
        self._base_url = os.environ.get("AMONHEN_API_URL", DEFAULT_API_URL).rstrip("/")

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json_body: dict | None = None,
        params: dict | None = None,
    ) -> Any:
        token = get_access_token()
        if not token:
            raise ApiError(401, "Not authenticated. Run: amonhen-mcp login", path)

        url = f"{self._base_url}{path}"
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.request(
                method,
                url,
                headers=headers,
                json=json_body,
                params=params,
            )

        if resp.status_code >= 400:
            raise ApiError(resp.status_code, resp.text, path)

        if resp.status_code == 204:
            return None

        return resp.json()

    # --- Projects ---

    async def list_projects(self) -> list[dict]:
        return await self._request("GET", "/v1/projects")

    async def get_project(self, project_id: str) -> dict:
        return await self._request("GET", f"/v1/projects/{project_id}")

    async def get_suggestions(self, project_id: str) -> dict:
        return await self._request("GET", f"/v1/projects/{project_id}/suggestions")

    async def get_context(
        self, project_id: str, intent: str | None = None
    ) -> dict:
        params = {"intent": intent} if intent else None
        return await self._request(
            "GET", f"/v1/projects/{project_id}/context", params=params
        )

    # --- Advisory ---

    async def advise(
        self,
        question: str,
        project_id: str | None = None,
        history: list[dict] | None = None,
    ) -> dict:
        body: dict[str, Any] = {"question": question, "project_id": project_id}
        if history:
            body["history"] = history
        return await self._request("POST", "/v1/advise", json_body=body)

    async def gaap_advise(
        self,
        question: str,
        project_id: str,
        evidence_refs: list[str] | None = None,
    ) -> dict:
        body: dict[str, Any] = {"project_id": project_id, "question": question}
        if evidence_refs:
            body["evidence_refs"] = evidence_refs
        return await self._request("POST", "/v1/gaap/advise", json_body=body)

    async def legal_advise(
        self,
        question: str,
        project_id: str,
        jurisdiction: str,
        evidence_refs: list[str] | None = None,
    ) -> dict:
        body: dict[str, Any] = {
            "project_id": project_id,
            "jurisdiction": jurisdiction,
            "question": question,
        }
        if evidence_refs:
            body["evidence_refs"] = evidence_refs
        return await self._request("POST", "/v1/legal/advise", json_body=body)

    # --- Context ---

    async def create_context(
        self,
        project_id: str,
        item_type: str,
        content: str,
        rationale: str | None = None,
    ) -> dict:
        body: dict[str, Any] = {
            "project_id": project_id,
            "item_type": item_type,
            "content": content,
        }
        if rationale:
            body["rationale"] = rationale
        return await self._request("POST", "/v1/context", json_body=body)

    # --- Starter Packs ---

    async def list_packs(self, project_id: str | None = None) -> dict:
        params = {"project_id": project_id} if project_id else None
        return await self._request("GET", "/v1/starter-packs", params=params)

    async def apply_pack(
        self, project_id: str, starter_pack_name: str, version: str
    ) -> dict:
        return await self._request(
            "POST",
            "/v1/starter-packs/apply",
            json_body={
                "project_id": project_id,
                "starter_pack_name": starter_pack_name,
                "version": version,
            },
        )

    # --- Learning ---

    async def list_pending_learning(self, project_id: str) -> dict:
        return await self._request(
            "GET", "/v1/learning/pending", params={"project_id": project_id}
        )

    async def approve_learning(self, proposal_id: str) -> dict:
        return await self._request(
            "POST",
            "/v1/learning/approve",
            json_body={"proposal_id": proposal_id},
        )
