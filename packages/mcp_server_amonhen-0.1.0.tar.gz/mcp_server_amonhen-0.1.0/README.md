# Amon Hen MCP Server

MCP server that brings Amon Hen's project-scoped advisory into Claude Code.

## Prerequisites

- Python 3.10+
- An Amon Hen account (sign up at https://amonhenai.com)

## Install

```bash
pip install mcp-server-amonhen
```

Or run directly with uvx (no install needed):

```bash
uvx mcp-server-amonhen
```

## Authenticate

Sign in via the Auth0 device flow:

```bash
amonhen-mcp login
```

This opens a browser for Auth0 authentication. Tokens are stored securely in your OS keychain.

To sign out:

```bash
amonhen-mcp logout
```

### Headless / CI

Set the `AMONHEN_TOKEN` environment variable with a valid JWT:

```bash
export AMONHEN_TOKEN="eyJhbGciOi..."
```

## Add to Claude Code

Add this to your Claude Code settings (`.claude/settings.json`):

```json
{
  "mcpServers": {
    "amonhen": {
      "command": "amonhen-mcp",
      "args": ["serve"]
    }
  }
}
```

Or with uvx:

```json
{
  "mcpServers": {
    "amonhen": {
      "command": "uvx",
      "args": ["mcp-server-amonhen"]
    }
  }
}
```

## Available Tools

| Tool | Description |
|------|-------------|
| `advise` | Ask a project-scoped advisory question |
| `gaap_advise` | GAAP-aware structured advisory |
| `legal_advise` | Legal decision-support advisory |
| `list_projects` | List your Amon Hen projects |
| `get_project` | Get detailed project info |
| `create_context` | Add a rule, decision, note, or code context |
| `list_packs` | Browse available starter packs |
| `apply_pack` | Apply a starter pack to a project |
| `list_pending_learning` | View draft learning proposals |
| `approve_learning` | Approve a learning proposal |

## Configuration

| Environment Variable | Default | Description |
|---------------------|---------|-------------|
| `AMONHEN_API_URL` | `https://amonhen.onrender.com` | API base URL |
| `AMONHEN_TOKEN` | — | JWT token (bypasses keychain auth) |

## Development

```bash
cd mcp-server-amonhen
pip install -e .

# Test with MCP Inspector
mcp dev src/mcp_amonhen/server.py

# Run as stdio server
amonhen-mcp serve
```
