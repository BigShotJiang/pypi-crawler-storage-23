---
title: Список изменений
---

# Список изменений

## 1.1.1

**Добавлено:**

- Новые классы для работы с файлами: `FSInputFile`, `BufferedInputFile`, `URLInputFile`. Подробнее — в [документации](learn/files.md).
- Поддержка отображения истории сообщений `display_history = True` при [добавлении пользователя](reference/Bot.md/#trueconf.Bot.add_participant_to_chat) в групповой чат или канал.
- Поддержка запроса и события для:
    - изменения роли в групповом чате или канале ([запрос](reference/Bot.md/#trueconf.Bot.change_participant_role), [уведомление](reference/Router.md/#trueconf.Router.changed_participant_role));
    - создания чата “Избранное” ([запрос](reference/Bot.md/#trueconf.Bot.create_favorites_chat), [уведомление](reference/Router.md/#trueconf.Router.created_favorites_chat)).
- Возможность отправки файлов с подписью (`caption`).
- Шорткат `.save_to_favorites()` для быстрого сохранения сообщения в чат "Избранное".
- Асинхронное свойство `await bot.me`, возвращающее `chat_id` чата "Избранное".

**Исправлено:**

- Стикеры, отправленные через `bot.send_sticker()`, отображались с фоном из-за некорректного MIME-типа.
- Метод `.remove_participant_from_chat()` не работал при указании неполного TrueConf ID.
- Ошибка при распаковке списка участников из-за некорректного алиаса.
- Иногда при получении токена с помощью `.from_credentials()` возникала ошибка `400 Bad Requests` при использовании цифрового (digit) пароля.

**Изменено:**

- Свойство `bot.server_name` стало асинхронным. Используйте его как `await bot.server_name`.

## 1.0.0

🎉 **Первый релиз!**

- Стабильная версия библиотеки python-trueconf-bot.
- Поддержка всех основных методов API TrueConf ChatBot.
- Псевдонимы и сочетания клавиш в стиле aiogram (message.answer, message.reply и т. д.).
- Асинхронная передача данных по протоколу WebSocket.
- Работа с файлами (отправка и загрузка).
- Документация: trueconf.github.io/python-trueconf-bot/
- PyPI: https://pypi.org/project/python-trueconf-bot/




