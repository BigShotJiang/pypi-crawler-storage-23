class PipelineException(Exception):
    pass
