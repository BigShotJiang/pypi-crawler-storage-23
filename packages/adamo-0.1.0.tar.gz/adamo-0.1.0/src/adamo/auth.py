"""Authenticate with the Adamo API and retrieve Zenoh connection config."""

from __future__ import annotations

from dataclasses import dataclass

import httpx

API_BASE = "https://q14iirks46.execute-api.eu-west-2.amazonaws.com"


@dataclass(frozen=True)
class ConnectionInfo:
    org: str
    quic_endpoint: str
    udp_endpoint: str
    wss_endpoint: str


def fetch_config_api_key(api_key: str, *, api_url: str = API_BASE) -> ConnectionInfo:
    """Fetch connection config using an API key (no user auth required)."""
    resp = httpx.get(
        f"{api_url}/api/keys/config",
        headers={"X-API-Key": api_key},
        timeout=10,
    )
    resp.raise_for_status()
    data = resp.json()
    return ConnectionInfo(
        org=data["org"],
        quic_endpoint=data["adamo_quic_url"],
        udp_endpoint=data["adamo_udp_url"],
        wss_endpoint=data["adamo_url"],
    )


async def fetch_config_api_key_async(
    api_key: str, *, api_url: str = API_BASE
) -> ConnectionInfo:
    """Async version of fetch_config_api_key."""
    async with httpx.AsyncClient() as client:
        resp = await client.get(
            f"{api_url}/api/keys/config",
            headers={"X-API-Key": api_key},
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()
    return ConnectionInfo(
        org=data["org"],
        quic_endpoint=data["adamo_quic_url"],
        udp_endpoint=data["adamo_udp_url"],
        wss_endpoint=data["adamo_url"],
    )


def fetch_config_token(
    token: str, *, org_id: str | None = None, api_url: str = API_BASE
) -> ConnectionInfo:
    """Fetch connection config using a Supabase JWT token."""
    params = {}
    if org_id:
        params["org_id"] = org_id
    resp = httpx.get(
        f"{api_url}/api/zenoh/endpoint",
        headers={"Authorization": f"Bearer {token}"},
        params=params,
        timeout=10,
    )
    resp.raise_for_status()
    data = resp.json()
    return ConnectionInfo(
        org=data["org_slug"],
        quic_endpoint=data["quic_endpoint"],
        udp_endpoint=data["udp_endpoint"],
        wss_endpoint=data["wss_endpoint"],
    )


async def fetch_config_token_async(
    token: str, *, org_id: str | None = None, api_url: str = API_BASE
) -> ConnectionInfo:
    """Async version of fetch_config_token."""
    params = {}
    if org_id:
        params["org_id"] = org_id
    async with httpx.AsyncClient() as client:
        resp = await client.get(
            f"{api_url}/api/zenoh/endpoint",
            headers={"Authorization": f"Bearer {token}"},
            params=params,
            timeout=10,
        )
        resp.raise_for_status()
        data = resp.json()
    return ConnectionInfo(
        org=data["org_slug"],
        quic_endpoint=data["quic_endpoint"],
        udp_endpoint=data["udp_endpoint"],
        wss_endpoint=data["wss_endpoint"],
    )
