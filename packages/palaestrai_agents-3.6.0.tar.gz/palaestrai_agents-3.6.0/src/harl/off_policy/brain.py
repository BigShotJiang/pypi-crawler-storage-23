from __future__ import annotations

import io

import logging
from abc import ABC, abstractmethod
from copy import deepcopy
from typing import TYPE_CHECKING, Sequence, Optional, List, Iterator

import numpy as np
import torch as T
from torch.optim import Adam

from harl.Networks.replaybuffer import ReplayBuffer
from palaestrai.agent import (
    Brain,
)
from palaestrai.agent import BrainDumper
from palaestrai.types import Box, Mode
from harl.common.action_type import ActionType
from harl.common.network import Actor, Critic


if TYPE_CHECKING:
    import torch.optim

LOG = logging.getLogger("palaestrai.agent.brain.OffPolicyBrain")


class OffPolicyBrain(Brain, ABC):
    """
    Implementation for general off-policy DRL algorithms.

    Parameters
    ----------
    replay_size : int
        Maximum length of replay buffer.
    fc_dims : Sequence[int] = (256, 256)
        Dimensions of the hidden layers of the agent's actor and critic
        networks. "fc" stands for "fully connected".
    gamma : float = 0.99
        Discount factor. (Always between 0 and 1.)
    tau : float = 0.005
        Interpolation factor in polyak averaging for target networks.
        Target networks are updated towards main networks according to:
        $$\theta_{\text{targ}} \leftarrow (1-\tau) \theta_{\text{targ}} +
        \tau \theta,$$
        where $\tau$ is polyak. (Always between 0 and 1, usually close to 0.)
    lr : float = 1e-3
        Learning rate (used for both policy and value learning).
    gradient_steps : int = -1
        The number of updates per learning iteration.

    batch_size : int = 100
        Minibatch size for SGD.
    update_after : int = 1000
        Number of env interactions to collect before starting to do
        gradient descent updates. Ensures replay buffer is full enough
        for useful updates.
    update_every : int = 50
        Number of env interactions that should elapse between
        gradient descent updates.
        Note: Regardless of how long you wait between updates, the ratio of
        environment interactions to gradient steps is locked to 1.
    pretrain_updates: int = 100
        Amount of updates for pretraining with behavior cloning using TD3+BC from the
        famous Fujimoto offline RL paper https://arxiv.org/pdf/2106.06860
    """

    def __init__(
        self,
        replay_size: int = int(1e6),
        fc_dims: Sequence[int] = (256, 256),
        gamma: float = 0.99,
        tau: float = 0.005,
        lr: float = 1e-3,
        gradient_steps: int = -1,
        batch_size: int = 100,
        update_after: int = 1000,
        update_every: int = 50,
        pretrain_updates: int = 100,
    ):
        super().__init__()

        # Action type, device, and state variables:
        self._action_type = ActionType.OTHER
        self._device = T.device("cuda" if T.cuda.is_available() else "cpu")
        self._step = 0
        self._previous_actions = None
        self._previous_objective = None
        self._previous_observations = None

        # These are our hyperparameters:
        self.replay_size = replay_size
        self._fc_dims = fc_dims
        self.gamma = gamma
        self.tau = tau
        self.lr = lr
        self.batch_size = batch_size
        self.update_after = update_after
        self.update_every = update_every
        self.gradient_steps = (
            gradient_steps if gradient_steps > 0 else self.update_every
        )

        # Models (actor, critic, etc.), as well as dimensions and scaling:
        self.actor: Optional[Actor] = None
        self.actor_target: Optional[Actor] = None
        self.critic: Optional[Critic] = None
        self.critic_target: Optional[Critic] = None

        # Replay buffer and optimizer:
        self.q_params: List[torch.nn.Parameter] = []
        self.replay_buffer: Optional[ReplayBuffer] = None
        self.critic_optimizer: Optional[torch.optim.Optimizer] = None
        self.actor_optimizer: Optional[torch.optim.Optimizer] = None

        self.pretrain_updates = pretrain_updates

        self._n_critics = 2
        self._n_updates = None
        self._update_loss_dict = None
        self._log_statistics: List[str] = []

    def setup(self):
        """Configures models (actor, critic, ...) and replay buffer."""
        assert len(self.sensors) > 0
        assert len(self.actuators) > 0
        self.memory.size_limit = 2  # We have our own memory, just need "done".

        # check for action type and set to type if matched
        if all(isinstance(actuator.space, Box) for actuator in self.actuators):
            self._action_type = ActionType.CONTINUOUS
        else:
            self._action_type = ActionType.OTHER
            LOG.error(
                self,
            )
            raise TypeError(
                f"{self} only supports continuous action spaces (Box)"
            )

        obs_dim = int(np.sum([np.prod(s.space.shape) for s in self.sensors]))

        if self._action_type == ActionType.CONTINUOUS:
            act_dim = int(
                np.sum([np.prod(a.space.shape) for a in self.actuators])
            )
        elif self._action_type == ActionType.DISCRETE:
            act_dim = self.actuators[0].space.n
        else:
            # We've already handled this, but just in case:
            raise TypeError(
                f"{self} requires exclusively Box or exclusively "
                f"Discrete action spaces; hybrid "
                f"is not yet supported, sorry.",
            )

        # Make sure that we do not overwrite an already loaded Brain
        # dump. The order in which the palaestrai.agent.Learner class
        # class us is important, because we can do offline training afterwards.

        model_none_dict = {
            "actor_is_none": False,
            "critic_is_none": False,
            "actor_target_is_none": False,
            "critic_target_is_none": False,
        }

        if self.actor is None:
            model_none_dict["actor_is_none"] = True
        if self.critic is None:
            model_none_dict["critic_is_none"] = True
        if self.actor_target is None:
            model_none_dict["actor_target_is_none"] = True
        if self.critic_target is None:
            model_none_dict["critic_target_is_none"] = True

        if all(model_none_dict.values()):
            self._init_models(obs_dim, act_dim)
        else:
            if any(model_none_dict.values()):
                LOG.warning(
                    "%s loaded only some models: %s", self, model_none_dict
                )

        self.actor_optimizer = Adam(self.actor.parameters(), lr=self.lr)
        self.critic_optimizer = Adam(self.critic.parameters(), lr=self.lr)

        self.replay_buffer = ReplayBuffer(
            state_dim=obs_dim,
            action_dim=act_dim,
            max_size=self.replay_size,
            device=self._device,
        )

        T.manual_seed(
            self.seed
        )  # cf. https://pytorch.org/docs/stable/notes/randomness.html

        self._n_updates = 0
        self._update_loss_dict = {}

    def _init_models(
        self,
        obs_dim: int,
        act_dim: int,
    ):
        assert self.actor is None
        assert self.critic is None
        assert self.actor_target is None
        assert self.critic_target is None

        self.actor = Actor(
            obs_dim=obs_dim,
            act_dim=act_dim,
            action_type=self._action_type,
            fc_dims=self._fc_dims,
        ).to(self._device)

        self.critic = Critic(
            obs_dim=obs_dim,
            act_dim=act_dim,
            fc_dims=self._fc_dims,
            n_critics=self._n_critics,
        ).to(self._device)
        self.actor_target = deepcopy(self.actor)
        self.actor_target.to(self._device)
        self.critic_target = deepcopy(self.critic)
        self.critic_target.to(self._device)
        self.actor_target.train(False)
        self.critic_target.train(False)

    def thinking(self, muscle_id, data_from_muscle):
        assert self.actor is not None
        assert self.critic is not None
        assert self.actor_target is not None
        assert self.critic_target is not None
        assert self.replay_buffer is not None

        update = None

        if data_from_muscle is None:  # Okay, happens during initialization
            update = io.BytesIO()
            T.save(self.actor, update)
            update.seek(0)
            LOG.info("%s sending initial actor model to muscle", self)
            LOG.debug(
                "%s send initial model with parameters: %s",
                self,
                self.actor.get_params(),
            )
            return update

        if self.mode != Mode.TRAIN:
            return update

        assert isinstance(data_from_muscle, tuple)
        assert len(data_from_muscle) == 2
        assert all(
            isinstance(datapoint_from_muscle, np.ndarray)
            for datapoint_from_muscle in data_from_muscle
        )

        if (
            self._previous_observations is not None
            and self._previous_actions is not None
            and self._previous_objective is not None
            # This is needed, because the None output (usually only first one)
            # as objective is stored
            # in memory as np.array([None])
            and (
                isinstance(self._previous_objective, float)
                or (
                    isinstance(self._previous_objective, np.ndarray)
                    and self._previous_objective.item() is not None
                )
            )
        ):
            self._step += 1
            self._remember(
                self._previous_observations,
                self._previous_actions,
                self._previous_objective,
                data_from_muscle[0],
                self.memory.tail(1).dones.item(),
            )
        self._previous_observations = data_from_muscle[0]
        self._previous_actions = data_from_muscle[1]
        try:
            self._previous_objective = self.memory.tail(1).objective.item()
        except ValueError as e:
            LOG.error(
                "%s: Got objective value '%s' from Memory, which is "
                "wrong: Need a 1D NumPy array. Substituting with 0.0, "
                "but this should be fixed. (%s)",
                self,
                self.memory.tail(1).objective,
                e,
            )

        if (
            self._step >= self.update_after
            and self._step % self.update_every == 0
            or (len(self.memory) > 0 and self.memory.tail(1).dones.item())
        ):
            try:
                update = self.update()
            except Exception as e:
                LOG.exception(
                    "%s could not update: %s.\n" "Actor: %s\n" "Critic: %s",
                    self,
                    e,
                    self.actor,
                    self.critic,
                )
        return update

    @abstractmethod
    def update_critic(self, state, actions, next_state, rewards, dones):
        pass

    @abstractmethod
    def update_actor(self, state, actions, next_state, rewards, dones):
        pass

    def update(self):
        assert (
            self.replay_buffer.size > 0
        ), "No trajectories given to learn from!"
        for statistic in self._log_statistics:
            self._update_loss_dict[statistic] = {}

        for update_iteration in range(self.gradient_steps):
            self._n_updates += 1

            data = self.replay_buffer.sample(self.batch_size)
            # self._check_device(data)

            state, actions, next_state, rewards, dones = data
            # Ensure rewards and dones are of shape (BATCH_SIZE, 1)
            rewards = T.reshape(rewards, shape=(-1, 1))
            dones = T.reshape(dones, shape=(-1, 1))

            self.update_critic(state, actions, next_state, rewards, dones)
            self.update_actor(state, actions, next_state, rewards, dones)

            # updated actor and critic target net by polyak
            self.update_target_nets(
                self.actor.parameters(), self.actor_target.parameters()
            )
            self.update_target_nets(
                self.critic.parameters(), self.critic_target.parameters()
            )

        LOG.debug(
            "%s send new model parameters: %s", self, self.actor.get_params()
        )

        LOG.info("%s updated", self)

        for k, v in self._update_loss_dict.items():
            self.add_statistics(k, v)

        bio = io.BytesIO()
        T.save(self.actor, bio)
        bio.seek(0)
        return bio

    def update_target_nets(
        self,
        params: Iterator[T.nn.Parameter],
        target_params: Iterator[T.nn.Parameter],
    ):
        with T.no_grad():
            for p, p_targ in zip(params, target_params):
                p_targ.data.copy_(
                    self.tau * p.data + (1 - self.tau) * p_targ.data
                )

    def store(self):
        algo_name = self.__class__.__name__.lower().replace("brain", "")
        bio = io.BytesIO()

        T.save(self.actor, bio)
        BrainDumper.store_brain_dump(bio, self._dumpers, f"{algo_name}_actor")

        bio.seek(0)
        bio.truncate(0)
        T.save(self.actor_target, bio)
        BrainDumper.store_brain_dump(
            bio, self._dumpers, f"{algo_name}_actor_target"
        )

        bio.seek(0)
        bio.truncate(0)
        T.save(self.critic, bio),
        BrainDumper.store_brain_dump(bio, self._dumpers, f"{algo_name}_critic")

        bio.seek(0)
        bio.truncate(0)
        T.save(self.critic_target, bio)
        BrainDumper.store_brain_dump(
            bio, self._dumpers, f"{algo_name}_critic_target"
        )

    def load(self):
        algo_name = self.__class__.__name__.lower().replace("brain", "")

        actor_dump = BrainDumper.load_brain_dump(
            self._dumpers, f"{algo_name}_actor"
        )
        actor_target_dump = BrainDumper.load_brain_dump(
            self._dumpers, f"{algo_name}_actor_target"
        )
        critic_dump = BrainDumper.load_brain_dump(
            self._dumpers, f"{algo_name}_critic"
        )
        critic_target_dump = BrainDumper.load_brain_dump(
            self._dumpers, f"{algo_name}_critic_target"
        )
        if any(
            [
                x is None
                for x in [
                    actor_dump,
                    actor_target_dump,
                    critic_dump,
                    critic_target_dump,
                ]
            ]
        ):
            LOG.warning(
                "%s: Got some nones (actor_dump: %s, actor_target_dump: %s, critic_dump: %s, critic_target_dump: %s)",
                self,
                type(actor_dump),
                type(actor_target_dump),
                type(critic_dump),
                type(critic_target_dump),
            )
            return  # Don't apply "None"s
        self.actor = T.load(
            actor_dump, weights_only=False, map_location=self._device
        )
        self.critic = T.load(
            critic_dump, weights_only=False, map_location=self._device
        )
        self.actor_target = T.load(
            actor_target_dump, weights_only=False, map_location=self._device
        )
        self.critic_target = T.load(
            critic_target_dump, weights_only=False, map_location=self._device
        )
        LOG.info("%s restored all of its Brain parts. Beware, Thebes!", self)

    def _remember(self, readings, actions, reward, next_state, done):
        state = np.array(readings)
        action = np.array(actions)
        try:
            self.replay_buffer.add(
                state=state,
                action=action,
                reward=reward,
                next_state=next_state,
                done=done,
            )
        except Exception as e:
            LOG.critical(
                "Brain(id=0x%x) could not add the following to the replay_buffer: "
                "state: %s, "
                "action: %s, "
                "reward: %s, "
                "next_state: %s, "
                "done: %s, "
                "because of: %s",
                id(self),
                str(state),
                str(action),
                str(reward),
                str(next_state),
                str(done),
                e,
            )
            raise

    def pretrain(self):
        sensor_readings = None
        for mmem in self.memory._data.values():
            for i in range(len(mmem.rewards) - 1):
                obs = np.array(
                    [x.value for x in mmem.sensor_readings[i]],
                    dtype=np.float64,
                )
                if i == 0:
                    sensor_readings = np.array([obs])
                else:
                    sensor_readings = np.concatenate(
                        (sensor_readings, np.array([obs])), axis=0
                    )
                acts = np.array(
                    [x.value for x in mmem.actuator_setpoints[i]],
                    dtype=np.float64,
                )
                reward = mmem.objective[i]
                nobs = np.array(
                    [x.value for x in mmem.sensor_readings[i + 1]],
                    dtype=np.float64,
                )
                done = mmem.dones[i]
                self.replay_buffer.add(obs, acts, nobs, reward, done)
        if sensor_readings is None:
            LOG.warning(
                "No sensor readings from replaying available for later normalization"
            )
        else:
            sensor_readings_T = sensor_readings.T
            mu, std_dev = np.mean(sensor_readings_T, axis=1), np.std(
                sensor_readings_T, axis=1
            )

            self.actor.feature_norm_mu = T.Tensor(mu)
            self.actor.feature_norm_std_dev = T.Tensor(std_dev)

            self.actor_target.feature_norm_mu = self.actor.feature_norm_mu
            self.actor_target.feature_norm_std_dev = (
                self.actor.feature_norm_std_dev
            )

        if self.pretrain_updates > 0:
            self._use_bc = True
            try:
                for i in range(self.pretrain_updates):
                    self.update()
                self.store()
                LOG.info("Initial updating done")
            except Exception as e:
                LOG.exception(
                    "%s could not update: %s.\n" "Actor: %s\n" "Critic: %s",
                    self,
                    e,
                    self.actor,
                    self.critic,
                )
            self._use_bc = False
        else:
            LOG.warning(
                "No actual pretraining updates are performed in replaying"
            )

    def get_seq(self) -> Optional[T.nn.Sequential]:
        assert self.actor is not None
        return self.actor.get_seq()

    def __repr__(self):
        return (
            f"{self.__class__}("
            f"fc_dims={self._fc_dims}, "
            f"replay_size={self.replay_size}, "
            f"update_after={self.update_after}, "
            f"update_every={self.update_every}, "
            f"batch_size={self.batch_size}, "
            f"lr={self.lr}, "
            f"gamma={self.gamma}, "
            f"tau={self.tau}, "
            ")"
        )

    def __str__(self):
        return repr(self)
