from typing import List, Tuple, Any, Optional

import numpy as np
import torch as T

from harl.common.utils import (
    transform_actions_for_actuators,
)
from harl.common.utils import (
    scale_action,
    unscale_action,
)
from harl.common.action_type import ActionType
from harl.common.network import Actor
from palaestrai.agent import (
    BrainDumper,
    ActuatorInformation,
    SensorInformation,
)
from palaestrai.agent import Muscle, LOG
from palaestrai.agent.util.information_utils import (
    concat_flattened_values,
)
from palaestrai.agent.util.space_value_utils import coerce_value_to_space
from palaestrai.types import Box
from palaestrai.types.mode import Mode
from palaestrai.util.dynaloader import load_with_params


class OffPolicyMuscle(Muscle):

    def __init__(
        self,
        start_steps: int = 10000,
        noise: str = "harl:GaussianNoise",
        noise_mu: float = 0.0,
        noise_std: float = 0.1,
        noise_theta: float = 0.15,
        is_squashed: bool = True,
    ):
        """
        Inference worker implementation of TD3.

        This muscle implements the rollout worker part of the TD3 algorithm.

        Parameters
        ----------
        start_steps : int = 10000
            Number of steps for uniform-random action selection,
            before running real policy. Helps exploration. The parameter is
            ignored in testing mode.
        noise : str = 'harl:GaussianNoise' | 'harl:OUNoise'
            Class for noise to apply on actions
        noise_mu : float = 0.0
            Mean of the respective Noise
        noise_std : float = 0.1
            Standard deviation of the respective Noise
        noise_theta : float = 0.15
            Theta parameter for the OUNoise
        is_squashed : bool = True
            Indicator for using squashing for the model output
        """
        super().__init__()
        self.start_steps = start_steps
        self.noise_mu = noise_mu
        self.noise_std = noise_std
        self.noise_theta = noise_theta
        self.is_squashed = is_squashed
        self.noise = noise

        self._actions_proposed = 0
        self._model: Optional[Actor] = None
        self._device = T.device("cuda" if T.cuda.is_available() else "cpu")
        self._noise = None

    def setup(self, *args, **kwargs):
        self._actions_proposed = 0

    def propose_actions(
        self,
        sensors: List[SensorInformation],
        actuators_available: List[ActuatorInformation],
    ) -> Tuple[List[ActuatorInformation], Any]:

        assert self._model is not None
        assert (
            any(
                isinstance(actuator.space, Box)
                for actuator in actuators_available
            )
            and self._model.action_type == ActionType.CONTINUOUS
        )
        self._actions_proposed += 1

        values = concat_flattened_values(sensors)

        if (
            self._actions_proposed < self.start_steps
            and self.mode == Mode.TRAIN
        ):
            unscaled_actions = np.array([])
            # During warm-up, we do not have a model,
            #   so we skip everything below and just return random actions
            for actuator in actuators_available:
                action = actuator.space.sample().flatten()
                unscaled_actions = np.concatenate((unscaled_actions, action))

            LOG.info("%s proposes random actions", self)
        else:
            _obs_tensor = T.tensor(
                values,
                dtype=T.float,
            ).to(self._device)

            LOG.debug(
                "%s: model parameters: %s", self, self._model.get_params()
            )
            LOG.debug("%s: model input: %s", self, _obs_tensor)

            output = self._model.act(
                _obs_tensor,
            )
            if self.is_squashed:
                unscaled_actions = transform_actions_for_actuators(
                    actions=output,
                    actuators=actuators_available,
                    transform_func=unscale_action,
                )
            else:
                unscaled_actions = transform_actions_for_actuators(
                    actions=output,
                    actuators=actuators_available,
                    transform_func=coerce_value_to_space,
                )

            LOG.debug("%s: model output: %s", self, unscaled_actions)

        scaled_actions = transform_actions_for_actuators(
            actions=unscaled_actions,
            actuators=actuators_available,
            transform_func=scale_action,
        )

        if self.mode == Mode.TRAIN and self.noise:
            if self._noise is None:
                self._noise = load_with_params(
                    self.noise,
                    {
                        "action_shape": scaled_actions.shape,
                        "mu": self.noise_mu,
                        "sigma": self.noise_std,
                        "theta": self.noise_theta,
                    },
                )
            assert self._noise is not None
            scaled_actions = np.clip(
                scaled_actions + self._noise.sample(), -1, 1
            )

        # This unscales the scaled actions and coerces and sets them into the actuators
        transform_actions_for_actuators(
            actions=scaled_actions,
            actuators=actuators_available,
            transform_func=unscale_action,
            coerce_and_set_values_to_info_objects=True,
        )

        LOG.debug(
            "%s: setpoints: %s",
            self,
            {actuator.uid: actuator.value for actuator in actuators_available},
        )

        LOG.info("%s proposes model actions", self)

        return (
            actuators_available,
            (values, scaled_actions),
        )

    def reset(self):
        if self._noise is not None:
            self._noise.reset()

    def update(self, update):
        if update is None:
            LOG.warning("%s cannot update without new data!", self)
            return
        self._load_model(update)

    def prepare_model(self):
        assert (
            self._model_loaders
        ), "Brain loaders are not set for preparing model"
        bio = BrainDumper.load_brain_dump(
            self._model_loaders, f"{__class__.__name__}_actor"
        )
        if bio is not None:
            try:
                self._load_model(bio)
            except Exception as e:
                LOG.exception(
                    f"{__class__.__name__}(id=0x%x, uid=%s) encountered error while "
                    "loading model: %s ",
                    id(self),
                    str(self.uid),
                    e,
                )
                raise

    def _load_model(self, model):
        self._model = T.load(
            model, weights_only=False, map_location=self._device
        )
        self._model.eval()
        LOG.debug(
            "%s loaded model with parameters: %s",
            self,
            self._model.get_params(),
        )

    def __str__(self):
        return repr(self)

    def __repr__(self):
        return (
            f"harl.{__class__.__name__}(uid={self.uid}, "
            f"start_steps={self.start_steps}, "
            f"device={self._device})"
        )
