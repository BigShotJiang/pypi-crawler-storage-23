from harl.td3.muscle import TD3Muscle


class DDPGMuscle(TD3Muscle):
    def __init__(self, start_steps: int = 10000, noise_std: float = 0.1):
        """
        Inference worker implementation of DDPG.

        This muscle implements the rollout worker part of the DDPG algorithm.

        Parameters
        ----------
        start_steps : int = 10000
            Number of steps for uniform-random action selection,
            before running real policy. Helps exploration. The parameter is
            ignored in testing mode.
        """
        super().__init__(start_steps=start_steps, noise_std=noise_std)
