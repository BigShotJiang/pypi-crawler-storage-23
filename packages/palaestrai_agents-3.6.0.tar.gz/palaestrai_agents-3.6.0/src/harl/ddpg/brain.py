from __future__ import annotations

from ..td3.brain import TD3Brain


class DDPGBrain(TD3Brain):
    """
    Learning implementation of DDPG.

    Specialization of TD3
    """

    def __init__(
        self,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)

        assert hasattr(self, "_target_policy_smoothing")
        self._n_critics = 1  # In DDPG, there is only one critic

    def setup(self):
        super().setup()
        # Noise is applied to the selected actions for computing the loss in TD3 but not in DDPG
        self._target_policy_smoothing = False
