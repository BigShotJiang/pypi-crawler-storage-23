import numpy as np


class OUNoise:
    def __init__(self, action_dim, mu, theta, sigma, **kwargs):
        self.action_shape = action_dim
        self.mu = mu
        self.theta = theta
        self.sigma = sigma
        self.state = None
        self.reset()

    def reset(self):
        """Reset the OU process to mean mu."""
        self.state = np.ones(self.action_shape) * self.mu

    def sample(self):
        """Generate the next noise value."""
        dx = self.theta * (
            self.mu - self.state
        ) + self.sigma * np.random.randn(*self.action_shape)
        self.state = self.state + dx
        return self.state
