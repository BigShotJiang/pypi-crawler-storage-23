import numpy as np


class GaussianNoise:
    def __init__(self, action_shape, mu, sigma, **kwargs):
        self.action_shape = action_shape
        self.mu = mu
        self.sigma = sigma

    def reset(self):
        pass

    def sample(self):
        """Generate the next noise value."""
        return self.mu + self.sigma * np.random.randn(*self.action_shape)
