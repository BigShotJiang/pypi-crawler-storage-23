from __future__ import annotations

from typing import Sequence, Any

import torch as T
import torch.nn as nn

from harl.common.action_type import ActionType


def mlp(
    sizes, activation, output_activation=nn.Identity, activate_final=False
):
    layers = []
    for j in range(len(sizes) - 1):
        act = activation if j < len(sizes) - 2 else output_activation
        layers += [nn.Linear(sizes[j], sizes[j + 1])]
        # The last layer has to be a Linear layer to be compatible with the NN2EQCDT algorithm,
        # so only add activation layers inbetween the Linear ones
        if not activate_final and j >= len(sizes) - 2:
            continue
        layers += [act()]
    return nn.Sequential(*layers)


class Actor(nn.Module):
    """
    An ANN actor

    Parameters
    ----------
    obs_dim : int
        Dimension of the observation space (e.g., product of sensor spaces)
    act_dim : int
        Dimension of the actuator/action space
    action_type: ActionType
        Enumerate value for the type of action space (e.g. continuous, discrete)
    fc_dims : List[int] = (256, 256)
        Dimensions of hidden layers ("fc" stands for "fully connected")
    activation : torch.nn.module = torch.nn.ReLU
        Activation function to use
    """

    def __init__(
        self,
        obs_dim: int,
        act_dim: int,
        action_type: ActionType,
        fc_dims: Sequence[int] = (256, 256),
        activation: Any = nn.ReLU,
        squash: bool = True,
    ):
        super().__init__()
        self.obs_dim = obs_dim
        self.act_dim = act_dim
        self.action_type = action_type
        self.squash = squash

        self.net = mlp(
            sizes=[obs_dim] + list(fc_dims) + [act_dim],
            activation=activation,
            output_activation=nn.Tanh if self.squash else activation,
            activate_final=self.squash,
        )

    def forward(self, obs):
        return self.net(obs)

    def get_seq(self) -> nn.Sequential:
        return self.net

    def act(self, obs):
        with T.no_grad():
            a = self.net(obs)
            return a.cpu().detach().numpy()

    def get_params(self):
        return {
            name: param.data for name, param in self.net.named_parameters()
        }


class Critic(nn.Module):
    """
    An ANN critic

    Parameters
    ----------
    obs_dim : int
        Dimension of the observation space (e.g., product of sensor spaces)
    act_dim : int
        Dimension of the actuator/action space
    fc_dims : List[int] = (256, 256)
        Dimensions of hidden layers ("fc" stands for "fully connected")
    activation : torch.nn.module = torch.nn.ReLU
        Activation function to use
    n_critics : int = 2
        Number of critic networks; in Twin delayed DDPG (TD3) there are 2
        critics
    """

    def __init__(
        self,
        obs_dim: int,
        act_dim: int,
        fc_dims: Sequence[int],
        activation: Any = nn.ReLU,
        n_critics: int = 2,
    ):
        super().__init__()
        self.n_critics = n_critics
        self.q_networks: list[nn.Module] = []
        for idx in range(n_critics):
            q_net = mlp([obs_dim + act_dim] + list(fc_dims) + [1], activation)
            self.add_module(f"qf{idx}", q_net)
            self.q_networks.append(q_net)

    def forward(
        self, obs: T.Tensor, actions: T.Tensor, only_first: bool = False
    ):
        with T.set_grad_enabled(True):
            features = obs.float().flatten(1, -1)
        qvalue_input = T.cat([features, actions], dim=1)
        if only_first:
            return self.q_networks[0](qvalue_input)
        else:
            return tuple(q_net(qvalue_input) for q_net in self.q_networks)
