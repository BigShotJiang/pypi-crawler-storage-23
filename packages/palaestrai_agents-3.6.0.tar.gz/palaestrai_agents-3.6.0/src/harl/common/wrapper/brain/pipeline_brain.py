import copy
from typing import List, Tuple, Any, Optional, Dict, Union

from harl.common.wrapper.brain.brain_post_processor import BrainPostProcessor
from harl.common.wrapper.brain.brain_pre_processor import BrainPreProcessor
from palaestrai.agent import (
    Brain,
)
from palaestrai.agent import LOG
from palaestrai.util.dynaloader import load_with_params


class PipelineBrain(Brain):
    def __init__(
        self,
        preprocessor_configs: Optional[List[Dict]] = None,
        brain_config: Optional[Dict] = None,
        postprocessor_configs: Optional[List[Dict]] = None,
    ):
        super().__init__()
        self._brains = None
        self._preprocessor_configs = preprocessor_configs
        self._brain_config = brain_config
        self._postprocessor_configs = postprocessor_configs

        self._preprocessors: Optional[List[BrainPreProcessor]] = None
        self._brain: Optional[Brain] = None
        self._postprocessors: Optional[List[BrainPostProcessor]] = None

        self._iteration: Optional[int] = None
        self._current_episode_action = None

        if self._preprocessor_configs is not None:
            self._preprocessors = self._load_objects(
                self._preprocessor_configs
            )
            assert self._preprocessors is not None
            assert all(
                isinstance(p, BrainPreProcessor) for p in self._preprocessors
            )
        if self._postprocessor_configs is not None:
            self._postprocessors = self._load_objects(
                self._postprocessor_configs
            )
            assert self._postprocessors is not None
            assert all(
                isinstance(p, BrainPostProcessor) for p in self._postprocessors
            )

        assert self._brain_config is not None
        self._brain = self._load_objects([self._brain_config])[0]
        assert self._brain is not None
        assert isinstance(self._brain, Brain)

    def _load_objects(
        self,
        configs: List[Dict],
    ):
        objects = []
        for config in configs:
            assert (
                "name" in config and "params" in config
            ), "A config must contain 'name' and 'params' mappings"
            LOG.info(
                "%s loads from config: %s",
                self,
                config,
            )
            obj = load_with_params(
                config["name"],
                config["params"],
            )
            objects.append(obj)
        return objects

    def setup(self, *args, **kwargs):
        self._iteration = 0

        self._setup_processors(self._preprocessors)

        self.set_for(
            obj=self._brain,
            seed=self.seed,
            sensors=self.sensors,
            actuators=self.actuators,
            dumpers=self._dumpers,
        )
        self._brain.setup()

        self._setup_processors(self._postprocessors)

    def _setup_processors(
        self,
        processors: Optional[
            List[Union[BrainPreProcessor, BrainPostProcessor]]
        ],
    ):
        if processors is not None:
            for processor in processors:
                processor.setup()

    def try_load_brain_dump(self):
        if self._preprocessors is not None:
            for preprocessor in self._preprocessors:
                self.set_for(
                    obj=preprocessor,
                    seed=self.seed,
                    sensors=self.sensors,
                    actuators=self.actuators,
                    dumpers=self._dumpers,
                )
                preprocessor.try_load_brain_dump()
        self._brain.try_load_brain_dump()
        if self._postprocessors is not None:
            for postprocessor in self._postprocessors:
                self.set_for(
                    obj=postprocessor,
                    seed=self.seed,
                    sensors=self.sensors,
                    actuators=self.actuators,
                    dumpers=self._dumpers,
                )
                postprocessor.try_load_brain_dump()

    def set_for(self, obj, seed, sensors, actuators, dumpers):
        obj._seed = seed
        obj._sensors = sensors
        obj._actuators = actuators
        obj._dumpers = dumpers

    def pretrain(self):
        self._brain.pretrain()

    def thinking(
        self,
        muscle_id: str,
        data_from_muscle: Any,
    ) -> Any:
        assert self._iteration is not None
        assert self._brain is not None

        preprocessor_updates, postprocessor_updates = None, None
        if data_from_muscle is not None:
            preprocessor_updates, postprocessor_updates, data_from_muscle = (
                data_from_muscle
            )

            if self._preprocessors is not None:
                data_from_muscle = copy.deepcopy(data_from_muscle)
                for i, preprocessor in enumerate(self._preprocessors):
                    preprocessor._iteration = self._iteration
                    preprocessor.mode = self.mode
                    preprocessor._memory = self.memory
                    assert preprocessor_updates is not None
                    preprocessor_updates[i] = preprocessor.update(
                        preprocessor_updates[i]
                    )
                    muscle_id, data_from_muscle = preprocessor.pre_process(
                        muscle_id=muscle_id,
                        data_from_muscle=data_from_muscle,
                    )
                    if hasattr(
                        self._brain, "_reward_preprocessor"
                    ) and hasattr(preprocessor, "normalise_objective"):
                        self._brain._reward_preprocessor = preprocessor
        elif self._preprocessors is not None:
            preprocessor_updates = [
                preprocessor.model for preprocessor in self._preprocessors
            ]

        self._brain.mode = self.mode
        self._brain._memory = self.memory
        potential_update = self._brain.thinking(
            muscle_id=muscle_id,
            data_from_muscle=data_from_muscle,
        )

        if data_from_muscle is not None:
            if self._postprocessors is not None:
                for i, postprocessor in enumerate(self._postprocessors):
                    postprocessor._iteration = self._iteration
                    postprocessor.mode = self.mode
                    postprocessor._memory = self.memory
                    assert postprocessor_updates is not None
                    postprocessor_updates[i] = postprocessor.update(
                        postprocessor_updates[i]
                    )
                    potential_update = postprocessor.post_process(
                        potential_update=potential_update,
                    )
        elif self._postprocessors is not None:
            postprocessor_updates = [
                postprocessor.model for postprocessor in self._postprocessors
            ]
        LOG.debug(
            "Preprocessor update: %s, postprocessor updates: %s, potential update: %s",
            preprocessor_updates,
            postprocessor_updates,
            potential_update,
        )

        if data_from_muscle is not None:
            self._iteration += 1
        return (preprocessor_updates, postprocessor_updates, potential_update)

    def store(self):
        if self._preprocessors is not None:
            for preprocessor in self._preprocessors:
                preprocessor.store()
        self._brain.store()
        if self._postprocessors is not None:
            for postprocessor in self._postprocessors:
                postprocessor.store()

    def pop_statistics(self) -> Dict[str, Any]:
        assert self._brain is not None
        return self._brain.pop_statistics()

    def __str__(self):
        return repr(self)

    def __repr__(self):
        return (
            f"harl.{__class__.__name__}(, "
            f"preprocessor_configs={self._preprocessor_configs}), "
            f"brain={self._brain}), "
            f"postprocessor_configs={self._postprocessor_configs}), "
            f"Preprocessors: {repr(self._preprocessors)}, ), "
            f"Brain: {repr(self._brain)})"
            f"Postprocessors: {repr(self._postprocessors)}, ), "
        )
