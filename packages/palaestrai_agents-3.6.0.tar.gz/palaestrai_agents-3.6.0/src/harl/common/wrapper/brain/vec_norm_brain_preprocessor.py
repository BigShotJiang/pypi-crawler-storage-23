from typing import Tuple, Optional, Any, List

import numpy as np

from harl.common.running_mean_std import RunningMeanStd
from harl.common.wrapper.brain.brain_pre_processor import BrainPreProcessor


class VecNormBrainPreprocessor(BrainPreProcessor):
    """
    This class implements a brain preprocessor which stores the RMS from the VecNormMusclePreprocessor
    and normalizes the rewards.

    """

    def __init__(
        self,
        normalise_objective: bool = True,
        clip_obs: float = 10.0,
        clip_reward: float = 10.0,
        epsilon: float = 1e-8,
        batch_size: int = 256,
        norm_objective_after: int = 10_000,
    ):
        super().__init__()
        self.normalise_objective = normalise_objective
        self.clip_obs = clip_obs
        self.clip_reward = clip_reward
        self.epsilon = epsilon
        self.batch_size = batch_size
        self.norm_objective_after = norm_objective_after

        self._objective_rms = None
        self._objectives: List[float] = []
        self._sensor_readings: List[np.ndarray] = []

    def setup(self):
        if self.model is None:
            self._model = RunningMeanStd(
                norm_epsilon=self.epsilon,
                clip_value=self.clip_obs,
            )

        if self._objective_rms is None:
            self._objective_rms = RunningMeanStd(
                norm_epsilon=self.epsilon,
                clip_value=self.clip_reward,
            )

    def pre_process(
        self,
        muscle_id: str,
        data_from_muscle: Any,
    ) -> Tuple[str, Any]:
        assert self.memory is not None
        assert self._objective_rms is not None

        if self.normalise_objective:
            objective = float(self.memory.tail(1).objective.item())
            self._objectives.append(objective)

            if (
                len(self._objectives) > 0
                and len(self._objectives) % self.batch_size == 0
            ) or self._iteration == self.norm_objective_after:
                self._objective_rms.update(np.array(self._objectives))
                self._objectives.clear()
            if self._iteration >= self.norm_objective_after:
                self.memory._data[muscle_id].objective[-1] = (
                    self._objective_rms.normalize(objective)
                )

        return muscle_id, data_from_muscle

    def update(self, update: Optional[Any] = None) -> Any:
        assert self.memory is not None

        self._sensor_readings.append(
            np.array(self.memory.tail(1).sensor_readings).flatten()
        )

        if (
            len(self._sensor_readings) > 0
            and len(self._sensor_readings) % self.batch_size == 0
        ):
            assert hasattr(self.model, "update")
            self.model.update(np.array(self._sensor_readings))
            self._sensor_readings.clear()

        return self.model

    def try_load_brain_dump(self):
        # TODO: Support loading of additional models
        super().load()

    def store(self, additional_models: Optional[List[Any]] = None):
        super().store(additional_models=[self._objective_rms])

    def calc_q_raw_est(self, target_q_mean, gamma):
        q_raw_est = target_q_mean * self.model.var + self.model.mean / (
            1.0 - gamma
        )
        return q_raw_est.tolist()
