from abc import ABC, abstractmethod
from typing import List, Tuple, Any, Optional

from palaestrai.agent import (
    SensorInformation,
    ActuatorInformation,
    LOG,
    Memory,
    BrainDumper,
)
from palaestrai.types import Mode


class BrainPreProcessor(ABC):
    def __init__(self):
        super().__init__()
        self._model: Any = None

        self._seed: int = -1
        self._name: str = ""
        self._memory: Optional[Memory] = None
        self.mode: Mode = Mode.TRAIN
        self._sensors: List[SensorInformation] = []
        self._actuators: List[ActuatorInformation] = []

        # Some IO object to which we can dump ourselves for a freeze:
        self._dumpers: List[BrainDumper] = list()

        self._storing_name = self.__class__.__name__.lower()
        self._model = None
        self._iteration: int = 0

    @property
    def model(self) -> Any:
        assert self._model is not None
        return self._model

    @property
    def seed(self) -> int:
        """Returns the random seed applicable for this brain instance."""
        return self._seed

    @property
    def sensors(self) -> List[SensorInformation]:
        """All sensors the Brain (and its Muscles) know about"""
        return self._sensors

    @property
    def actuators(self) -> List[ActuatorInformation]:
        """All actuators a Muscle can act with."""
        return self._actuators

    @property
    def memory(self) -> Optional[Memory]:
        """The Brain's memory"""
        return self._memory

    @abstractmethod
    def setup(self):
        pass

    @abstractmethod
    def pre_process(
        self,
        muscle_id: str,
        data_from_muscle: Any,
    ) -> Tuple[str, Any]:
        pass

    def update(self, update: Optional[Any] = None) -> Optional[Any]:
        if update is not None:
            self._model = update
        return self._model

    def store(self, additional_models: Optional[List[Any]] = None):
        self._store(self._model)

        if additional_models is not None:
            for model in additional_models:
                self._store(model)

    def _store(self, model):
        import io
        from palaestrai.agent.brain_dumper import BrainDumper

        bio = io.BytesIO()
        model.save(bio)
        BrainDumper.store_brain_dump(bio, self._dumpers, self._storing_name)

    def load(self):
        if self._model is None:
            return

        from palaestrai.agent.brain_dumper import BrainDumper

        try:
            bio = BrainDumper.load_brain_dump(
                self._dumpers, self._storing_name
            )
            if bio is not None:
                self._model.load(bio)
        except Exception as e:
            LOG.warning(
                f"Could not load model for %s: %s", self._storing_name, e
            )

    def try_load_brain_dump(self):
        self.load()
