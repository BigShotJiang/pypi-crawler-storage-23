from abc import ABC
from typing import List, Any, Optional

from palaestrai.agent import (
    ActuatorInformation,
    SensorInformation,
    Memory,
    BrainDumper,
)
from palaestrai.types import Mode


class BrainPostProcessor(ABC):
    def __init__(self):
        super().__init__()
        self._seed: int = -1
        self._name: str = ""
        self._memory = Memory()
        self.mode: Mode = Mode.TRAIN
        self._sensors: List[SensorInformation] = []
        self._actuators: List[ActuatorInformation] = []

        # Some IO object to which we can dump ourselves for a freeze:
        self._dumpers: List[BrainDumper] = list()

        self._storing_name = self.__class__.__name__.lower()
        self._model = None
        self._iteration: int = 0

    @property
    def model(self) -> Optional[Any]:
        return self._model

    @property
    def seed(self) -> int:
        """Returns the random seed applicable for this brain instance."""
        return self._seed

    @property
    def sensors(self) -> List[SensorInformation]:
        """All sensors the Brain (and its Muscles) know about"""
        return self._sensors

    @property
    def actuators(self) -> List[ActuatorInformation]:
        """All actuators a Muscle can act with."""
        return self._actuators

    @property
    def memory(self) -> Memory:
        """The Brain's memory"""
        return self._memory

    def setup(self):
        pass

    def post_process(self, potential_update: Any) -> Any:
        pass

    def update(self, update: Optional[Any] = None) -> Optional[Any]:
        if update is not None:
            self._model = update
        return self._model

    def store(self):
        import io
        import torch as T
        from palaestrai.agent.brain_dumper import BrainDumper

        self._storing_name = self.__class__.__name__.lower()
        bio = io.BytesIO()

        T.save(self._model, bio)
        BrainDumper.store_brain_dump(
            bio, self._dumpers, f"{self._storing_name}"
        )

    def try_load_brain_dump(self):
        pass
