from typing import List, Tuple, Any

import numpy as np

from harl.common.utils import unscale_action
from harl.common.wrapper.muscle.muscle_post_processor import (
    MusclePostProcessor,
)
from palaestrai.agent import (
    ActuatorInformation,
)
from palaestrai.agent.util.information_utils import (
    concat_flattened_values,
    coerce_and_set_values_to_info_objects,
)


class ActionNormPostprocessor(MusclePostProcessor):

    def __init__(
        self,
        squash: bool = True,
        unscale: bool = True,
    ):
        super().__init__()
        self.squash = squash
        self.unscale = unscale

    def post_process(
        self, setpoints: List[ActuatorInformation], data_for_brain: Any
    ) -> Tuple[List[ActuatorInformation], Any]:
        if data_for_brain is not None:
            assert (
                isinstance(data_for_brain, tuple) and len(data_for_brain) == 2
            )

        scaled_actions = np.array([])
        for actuator in setpoints:
            action = concat_flattened_values([actuator])
            if self.squash:
                action = np.tanh(action)
                scaled_actions = np.concatenate((scaled_actions, action))
            if self.unscale:
                action = unscale_action(action, actuator.space)
            coerce_and_set_values_to_info_objects(action, [actuator])

        return (
            setpoints,
            (
                (
                    data_for_brain[0],
                    scaled_actions if self.squash else data_for_brain[1],
                )
                if data_for_brain is not None
                else data_for_brain
            ),
        )
