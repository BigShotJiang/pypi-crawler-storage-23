from abc import ABC, abstractmethod
from typing import List, Tuple, Any, Optional

from palaestrai.agent import SensorInformation, ActuatorInformation
from palaestrai.types import Mode


class MusclePreProcessor(ABC):
    def __init__(self):
        super().__init__()
        self._model: Any = None
        self._mode: Optional[Mode] = None
        self._actions_proposed: Optional[int] = None
        self._current_episode_action: Optional[int] = None

    @property
    def model(self) -> Any:
        return self._model

    @property
    def mode(self) -> Mode:
        assert self._mode is not None
        return self._mode

    @abstractmethod
    def setup(self):
        pass

    def get_update(self) -> Any:
        return self._model

    def update(self, update):
        if update is not None and (
            self.model is None or self.mode == Mode.TRAIN
        ):
            self._model = update

    @abstractmethod
    def pre_process(
        self,
        sensors: List[SensorInformation],
        actuators_available: List[ActuatorInformation],
    ) -> Tuple[
        List[SensorInformation],
        List[ActuatorInformation],
    ]:
        pass

    def reset(self):
        self._model = None

    def teardown(self):
        self._model = None
