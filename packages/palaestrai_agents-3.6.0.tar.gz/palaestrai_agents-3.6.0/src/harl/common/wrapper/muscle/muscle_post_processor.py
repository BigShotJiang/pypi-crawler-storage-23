from abc import ABC, abstractmethod
from typing import List, Tuple, Any, Optional

from palaestrai.agent import ActuatorInformation
from palaestrai.types import Mode


class MusclePostProcessor(ABC):
    def __init__(self):
        super().__init__()
        self._model: Any = None
        self._mode: Optional[Mode] = None
        self._actions_proposed: Optional[int] = None
        self._current_episode_action: Optional[int] = None

    @abstractmethod
    def setup(self):
        pass

    def get_update(self) -> Any:
        return self._model

    def update(self, update):
        if update is not None:
            self._model = update

    @abstractmethod
    def post_process(
        self, setpoints: List[ActuatorInformation], data_for_brain: Any
    ) -> Tuple[List[ActuatorInformation], Any]:
        pass

    def reset(self):
        self._model = None

    def teardown(self):
        self._model = None
