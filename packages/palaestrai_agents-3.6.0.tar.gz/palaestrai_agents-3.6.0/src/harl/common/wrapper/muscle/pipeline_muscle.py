import copy
from typing import List, Tuple, Any, Optional, Dict

from harl.common.wrapper.muscle.muscle_post_processor import (
    MusclePostProcessor,
)
from harl.common.wrapper.muscle.muscle_pre_processor import MusclePreProcessor
from palaestrai.agent import (
    ActuatorInformation,
    SensorInformation,
)
from palaestrai.agent import Muscle, LOG
from palaestrai.util.dynaloader import load_with_params


class PipelineMuscle(Muscle):
    def __init__(
        self,
        preprocessor_configs: Optional[List[Dict]] = None,
        muscle_config: Optional[Dict] = None,
        postprocessor_configs: Optional[List[Dict]] = None,
    ):
        super().__init__()
        self._muscles = None
        self._preprocessor_configs = preprocessor_configs
        self._muscle_config = muscle_config
        self._postprocessor_configs = postprocessor_configs

        self._preprocessors: Optional[List[MusclePreProcessor]] = None
        self._muscle: Optional[Muscle] = None
        self._postprocessors: Optional[List[MusclePostProcessor]] = None

        self._actions_proposed: int = -1
        self._current_episode_action: int = -1

    def setup(self, *args, **kwargs):
        self._actions_proposed = 0
        self._current_episode_action = 0
        if self._preprocessor_configs is not None:
            self._preprocessors = self._load_objects(
                self._preprocessor_configs
            )
            assert self._preprocessors is not None
            assert all(
                isinstance(p, MusclePreProcessor) for p in self._preprocessors
            )
        if self._postprocessor_configs is not None:
            self._postprocessors = self._load_objects(
                self._postprocessor_configs
            )
            assert self._postprocessors is not None
            assert all(
                isinstance(p, MusclePostProcessor)
                for p in self._postprocessors
            )
        self._muscle = self._load_objects([self._muscle_config])[0]
        self._muscle._uid = self.uid
        assert self._muscle is not None
        assert isinstance(self._muscle, Muscle)

    def _load_objects(
        self,
        configs: List[Dict],
    ):
        objects = []
        for config in configs:
            assert (
                "name" in config and "params" in config
            ), "A config must contain 'name' and 'params' mappings"
            LOG.info(
                "%s loads from config: %s",
                self,
                config,
            )
            obj = load_with_params(
                config["name"],
                config["params"],
            )
            obj.setup()
            objects.append(obj)
        return objects

    def propose_actions(
        self,
        sensors: List[SensorInformation],
        actuators_available: List[ActuatorInformation],
    ) -> Tuple[List[ActuatorInformation], Any]:

        preprocessor_updates, postprocessor_updates = [], []

        if self._preprocessors is not None:
            sensors = copy.deepcopy(sensors)
            for preprocessor in self._preprocessors:
                preprocessor._actions_proposed = self._actions_proposed
                preprocessor._current_episode_action = (
                    self._current_episode_action
                )
                preprocessor._mode = self.mode
                sensors, actuators_available = preprocessor.pre_process(
                    sensors, actuators_available
                )
                preprocessor_updates.append(preprocessor.get_update())

        assert self._muscle is not None
        self._muscle._mode = self.mode
        data = self._muscle.propose_actions(sensors, actuators_available)
        data_for_brain = None
        if isinstance(data, tuple):
            setpoints, data_for_brain = data
        else:
            setpoints = data

        if self._postprocessors is not None:
            for postprocessor in self._postprocessors:
                postprocessor._actions_proposed = self._actions_proposed
                postprocessor._current_episode_action = (
                    self._current_episode_action
                )
                postprocessor._mode = self.mode
                setpoints, data_for_brain = postprocessor.post_process(
                    setpoints, data_for_brain
                )
                postprocessor_updates.append(postprocessor.get_update())

        self._actions_proposed += 1
        self._current_episode_action += 1

        return (
            setpoints,
            (
                preprocessor_updates,
                postprocessor_updates,
                data_for_brain,
            ),
        )

    def prepare_model(self):
        assert self._muscle is not None
        self._muscle.prepare_model()

    def update(self, update):
        assert self._muscle is not None
        LOG.info(
            "Update preprocessors %s, muscle %s and postprocessors %s",
            self._preprocessors,
            self._muscle,
            self._postprocessors,
        )
        preprocessor_updates, postprocessor_updates, muscle_update = update

        if (
            self._preprocessors is not None
            and preprocessor_updates is not None
        ):
            for preprocessor, update in zip(
                self._preprocessors, preprocessor_updates
            ):
                if preprocessor is not None:
                    LOG.debug(
                        "Update preprocessor %s with %s", preprocessor, update
                    )
                    preprocessor.update(update)

        LOG.debug("Update muscle %s with %s", self._muscle, update)
        if muscle_update is not None:
            self._muscle.update(muscle_update)

        if (
            self._postprocessors is not None
            and postprocessor_updates is not None
        ):
            for postprocessor, update in zip(
                self._postprocessors, preprocessor_updates
            ):
                if postprocessor is not None:
                    LOG.debug(
                        "Update postprocessors %s with %s",
                        postprocessor,
                        update,
                    )
                    postprocessor.update(update)

    def reset(self):
        assert self._muscle is not None
        self._muscle.reset()
        if self._preprocessors is not None:
            for preprocessor in self._preprocessors:
                preprocessor.reset()
        if self._postprocessors is not None:
            for postprocessor in self._postprocessors:
                postprocessor.reset()

        self._current_episode_action = 0

    def teardown(self):
        assert self._muscle is not None
        self._muscle.teardown()

    def __str__(self):
        return repr(self)

    def __repr__(self):
        return (
            f"harl.{__class__.__name__}(uid={self.uid}, "
            f"preprocessor_configs={self._preprocessor_configs}), "
            f"muscle={self._muscle}), "
            f"postprocessor_configs={self._postprocessor_configs}), "
            f"Preprocessors: {repr(self._preprocessors)}, ), "
            f"Muscle: {repr(self._muscle)})"
            f"Postprocessors: {repr(self._postprocessors)}, ), "
        )
