import logging
from typing import List, Tuple
from harl.common.wrapper.muscle.muscle_pre_processor import MusclePreProcessor
from palaestrai.agent import (
    ActuatorInformation,
    SensorInformation,
)
from palaestrai.agent.util.information_utils import (
    concat_flattened_values,
    coerce_and_set_values_to_info_objects,
)

LOG = logging.getLogger(__name__)


class VecNormMusclePreprocessor(MusclePreProcessor):
    """
    This class implements a muscle preprocessor which normalizes the sensor observations.

    It has to be used together with the VecNormMusclePreprocessor to store the running mean and std
    for the normalization.
    """

    def __init__(
        self,
    ):
        super().__init__()

    def pre_process(
        self,
        sensors: List[SensorInformation],
        actuators_available: List[ActuatorInformation],
    ) -> Tuple[
        List[SensorInformation],
        List[ActuatorInformation],
    ]:
        values = concat_flattened_values(sensors)

        # Initial default mean and var values for obs_rms should be
        # suitable for obs norm, so no delayed norm necessary
        values = self.model.normalize(values)
        try:
            coerce_and_set_values_to_info_objects(values, sensors)
        except Exception as e:
            LOG.error(
                "Coerce failed. Model: %s Sensors: %s", self.model, sensors
            )
            raise e
        return sensors, actuators_available
