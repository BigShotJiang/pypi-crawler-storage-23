import numpy as np


# Source: StableBaselines3
class RunningMeanStd:
    def __init__(
        self,
        epsilon: float = 1e-4,
        shape: tuple[int, ...] = (),
        norm_epsilon: float = 1e-8,
        clip_value: float = 10.0,
    ):
        """
        Calculates the running mean and std of a data stream
        https://en.wikipedia.org/wiki/Algorithms_for_calculating_variance#Parallel_algorithm

        :param epsilon: helps with arithmetic issues
        :param shape: the shape of the data stream's output
        """
        self.mean = np.zeros(shape, np.float64)
        self.var = np.ones(shape, np.float64)
        self.count = epsilon
        self.norm_epsilon = norm_epsilon
        self.clip_value = clip_value

    def copy(self) -> "RunningMeanStd":
        """
        :return: Return a copy of the current object.
        """
        new_object = RunningMeanStd(shape=self.mean.shape)
        new_object.mean = self.mean.copy()
        new_object.var = self.var.copy()
        new_object.count = float(self.count)
        return new_object

    def combine(self, other: "RunningMeanStd") -> None:
        """
        Combine stats from another ``RunningMeanStd`` object.

        :param other: The other object to combine with.
        """
        self.update_from_moments(other.mean, other.var, other.count)

    def update(self, arr: np.ndarray) -> None:
        batch_mean = np.mean(arr, axis=0)
        batch_var = np.var(arr, axis=0)
        batch_count = arr.shape[0]
        self.update_from_moments(batch_mean, batch_var, batch_count)

    def update_from_moments(
        self, batch_mean: np.ndarray, batch_var: np.ndarray, batch_count: float
    ) -> None:
        delta = batch_mean - self.mean
        tot_count = self.count + batch_count

        new_mean = self.mean + delta * batch_count / tot_count
        m_a = self.var * self.count
        m_b = batch_var * batch_count
        m_2 = (
            m_a
            + m_b
            + np.square(delta)
            * self.count
            * batch_count
            / (self.count + batch_count)
        )
        new_var = m_2 / (self.count + batch_count)

        new_count = batch_count + self.count

        self.mean = new_mean
        self.var = new_var
        self.count = new_count

    def normalize(self, value: np.ndarray) -> np.ndarray:
        return np.clip(
            (value - self.mean) / np.sqrt(self.var + self.norm_epsilon),
            -self.clip_value,
            self.clip_value,
        )

    def unnormalize(self, value: np.ndarray) -> np.ndarray:
        return (value * np.sqrt(self.var + self.norm_epsilon)) + self.mean

    def save(self, filename):
        np.savez(
            filename,
            mean=self.mean,
            var=self.var,
            count=self.count,
        )

    def load(self, filename):
        data = np.load(filename)
        self.mean = data["mean"]
        self.var = data["var"]
        self.count = data["count"]

    def __repr__(self):
        return (
            f"{self.__class__}("
            f"mean={self.mean}, "
            f"var={self.var}, "
            f"count={self.count}, "
            f")"
        )

    def __str__(self):
        return repr(self)
