# Source: https://stackoverflow.com/a/40977600
from typing import Callable, List

import numpy as np

from palaestrai.agent import ActuatorInformation
from palaestrai.agent.util.space_value_utils import (
    coerce_values_to_space_shapes,
    coerce_value_to_space,
)
from palaestrai.types import Box, Space


def transform_actions_for_actuators(
    actions: np.ndarray,
    actuators: List[ActuatorInformation],
    transform_func: Callable,
    coerce_and_set_values_to_info_objects=False,
):
    unscaled_actions = None

    fitted_outputs = coerce_values_to_space_shapes(
        actions,  # type: ignore[arg-type]
        [info_object.space for info_object in actuators],
    )
    for output, actuator in zip(fitted_outputs, actuators):
        assert hasattr(output, "flatten")
        output = transform_func(output.flatten(), actuator.space)
        if coerce_and_set_values_to_info_objects:
            actuator.value = (  # type: ignore[attr-defined]
                coerce_value_to_space(
                    output, actuator.space  # type: ignore[attr-defined]
                )
            )
        else:
            if unscaled_actions is None:
                unscaled_actions = np.array([])
            unscaled_actions = np.concatenate((unscaled_actions, output))

    return unscaled_actions


def scale_action(action: np.ndarray, space: Space) -> np.ndarray:
    """
    Rescale the action from [low, high] to [-1, 1]
    (no need for symmetric action space)

    :param action: Action to scale
    :return: Scaled action
    """
    assert isinstance(space, Box), "Spaces other than Box are not supported"
    box_space: Box = space
    low, high = box_space.low, box_space.high
    return 2.0 * ((action - low) / (high - low)) - 1.0


def unscale_action(
    scaled_action: np.ndarray,
    space: Space,
) -> np.ndarray:
    """
    Rescale the action from [-1, 1] to [low, high]
    (no need for symmetric action space)

    :param scaled_action: Action to un-scale
    """
    assert isinstance(space, Box), "Spaces other than Box are not supported"
    box_space: Box = space
    low, high = box_space.low, box_space.high
    return low + (0.5 * (scaled_action + 1.0) * (high - low))
