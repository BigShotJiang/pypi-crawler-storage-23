from typing import List, Tuple, Any, Optional

import numpy as np
import torch as T

from harl.common.action_type import ActionType
from harl.common.network import Actor
from palaestrai.agent import (
    BrainDumper,
    ActuatorInformation,
    SensorInformation,
)
from palaestrai.agent import Muscle, LOG
from palaestrai.agent.util.information_utils import (
    concat_flattened_values,
    coerce_and_set_values_to_info_objects,
)
from palaestrai.agent.util.space_value_utils import coerce_value_to_space
from palaestrai.types import Box
from palaestrai.types.mode import Mode
from palaestrai.util.dynaloader import load_with_params


class TD3Muscle(Muscle):

    def __init__(
        self,
        start_steps: int = 10000,
        noise: str = "harl:GaussianNoise",
        noise_mu: float = 0.0,
        noise_std: float = 0.1,
        noise_theta: float = 0.15,
        squash: bool = True,
    ):
        """
        Inference worker implementation of TD3.

        This muscle implements the rollout worker part of the TD3 algorithm.

        Parameters
        ----------
        start_steps : int = 10000
            Number of steps for uniform-random action selection,
            before running real policy. Helps exploration. The parameter is
            ignored in testing mode.
        noise : str = 'harl:GaussianNoise' | 'harl:OUNoise'
            Class for noise to apply on actions
        noise_mu : float = 0.0
            Mean of the respective Noise
        noise_std : float = 0.1
            Standard deviation of the respective Noise
        noise_theta : float = 0.15
            Theta parameter for the OUNoise
        squash : bool = True
            Indicator for using squashing (with tanh)
        """
        super().__init__()
        self._start_steps = start_steps
        self._noise = noise
        self._noise_mu = noise_mu
        self._noise_std = noise_std
        self._noise_theta = noise_theta
        self._squash = squash

        self._actions_proposed = 0
        self._model: Optional[Actor] = None
        self._device = T.device("cuda" if T.cuda.is_available() else "cpu")
        self.noise = None

    def setup(self, *args, **kwargs):
        self._actions_proposed = 0

    def propose_actions(
        self,
        sensors: List[SensorInformation],
        actuators_available: List[ActuatorInformation],
    ) -> Tuple[List[ActuatorInformation], Any]:

        assert self._model is not None
        assert (
            any(
                isinstance(actuator.space, Box)
                for actuator in actuators_available
            )
            and self._model.action_type == ActionType.CONTINUOUS
        )
        self._actions_proposed += 1

        values = concat_flattened_values(sensors)

        if (
            self._actions_proposed < self._start_steps
            and self.mode == Mode.TRAIN
        ):
            # During warm-up, we do not have a model,
            #   so we skip everything below and just return random actions
            for actuator in actuators_available:
                action = actuator.space.sample()

                value = coerce_value_to_space(action, actuator.space)
                actuator(value)

            LOG.info("%s proposes random actions", self)
            return (
                actuators_available,
                (values, concat_flattened_values(actuators_available)),
            )

        _obs_tensor = T.tensor(
            values,
            dtype=T.float,
        ).to(self._device)

        LOG.debug("%s: model parameters: %s", self, self._model.get_params())
        LOG.debug("%s: model input: %s", self, _obs_tensor)

        actions = self._model.act(
            _obs_tensor,
        )
        if self._squash:
            actions = np.tanh(actions)
        LOG.debug("%s: model output: %s", self, actions)

        if self.mode == Mode.TRAIN:
            if not self.noise:
                self.noise = load_with_params(
                    self._noise,
                    {
                        "action_shape": actions.shape,
                        "mu": self._noise_mu,
                        "sigma": self._noise_std,
                        "theta": self._noise_theta,
                    },
                )
            assert self.noise is not None
            actions += self.noise.sample()

        coerce_and_set_values_to_info_objects(actions, actuators_available)

        LOG.debug(
            "%s: setpoints: %s",
            self,
            {actuator.uid: actuator.value for actuator in actuators_available},
        )

        LOG.info("%s proposes model actions", self)

        return (
            actuators_available,
            (values, concat_flattened_values(actuators_available)),
        )

    def reset(self):
        if self.noise is not None:
            self.noise.reset()

    def update(self, update):
        if update is None:
            LOG.error("%s cannot update without new data!", self)
            return
        self._load_model(update)

    def prepare_model(self):
        assert (
            self._model_loaders
        ), "Brain loaders are not set for preparing model"
        bio = BrainDumper.load_brain_dump(
            self._model_loaders, f"{__class__.__name__}_actor"
        )
        if bio is not None:
            try:
                self._load_model(bio)
            except Exception as e:
                LOG.exception(
                    f"{__class__.__name__}(id=0x%x, uid=%s) encountered error while "
                    "loading model: %s ",
                    id(self),
                    str(self.uid),
                    e,
                )
                raise

    def _load_model(self, model):
        self._model = T.load(
            model, weights_only=False, map_location=self._device
        )
        self._model.eval()
        LOG.debug(
            "%s loaded model with parameters: %s",
            self,
            self._model.get_params(),
        )

    def __str__(self):
        return repr(self)

    def __repr__(self):
        return (
            f"harl.{__class__.__name__}(uid={self.uid}, "
            f"start_steps={self._start_steps}, "
            f"device={self._device})"
        )
