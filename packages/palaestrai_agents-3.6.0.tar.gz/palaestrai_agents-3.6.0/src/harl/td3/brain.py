from __future__ import annotations

import logging

import torch as T
from torch.nn import functional as F

from harl.off_policy.brain import OffPolicyBrain


LOG = logging.getLogger("palaestrai.agent.brain.TD3Brain")


class TD3Brain(OffPolicyBrain):
    """
    Learning implementation of TD3.

    Implementation based on `Stable Baselines 3
    <https://github.com/DLR-RM/stable-baselines3/tree/master>`_.

    Further reading:

    * OpenAI Spinning Up - Twin Delayed DDPG — https://spinningup.openai.com/en/latest/algorithms/td3.html
    * Addressing Function Approximation Error in Actor-Critic Methods — https://arxiv.org/pdf/1802.09477

    Parameters
    ----------
    policy_delay: int = 2

    target_policy_noise: float = 0.2

    target_noise_clip: float = 0.5

    bc_alpha: float = 2.5
        Alpha hyperparameter for the TD3+BC extension; only used for pretraining
    use_tdr: bool = False
        Indicates, if the twin TD-regularized actor-critic (TDR) method should be used.
        See https://arxiv.org/pdf/2311.03711 for more details.
    tdr_rho: float = 0.7
        TDR regularization factor. In (0,1) and values of $\rho \in [0.3, 0.5, 0.7]$ were
        generally good choices in the hyperparameter study from the original TDR paper
    """

    def __init__(
        self,
        policy_delay: int = 2,
        target_policy_noise: float = 0.2,
        target_noise_clip: float = 0.5,
        bc_alpha: float = 2.5,
        use_tdr: bool = False,
        tdr_rho: float = 0.7,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)

        self.policy_delay = policy_delay
        self.target_noise_clip = target_noise_clip
        self.target_policy_noise = target_policy_noise

        self.bc_alpha = bc_alpha

        self.use_tdr = use_tdr
        self.tdr_rho = tdr_rho

        self._target_policy_smoothing = None
        self._n_critics = 2  # This is used in _init_models, so it actually has to be init here
        self._use_bc = False

        self._log_statistics = [
            "critic_loss",
            "actor_loss",
            "target_q_values_mean",
            "target_q_values_std",
            "current_q1_mean",
            "q_raw_est",
        ]

        self._reward_preprocessor = None

    def setup(self):
        super().setup()
        self._target_policy_smoothing = True

    def compute_target_actions(
        self,
        actions: T.Tensor,
        next_state: T.Tensor,
    ) -> T.Tensor:
        assert self.actor_target is not None
        assert self._target_policy_smoothing is not None

        # Source: TD3 train from SB3, see https://github.com/DLR-RM/stable-baselines3/blob/master/stable_baselines3/td3/td3.py
        with T.no_grad():
            # Select action according to policy
            next_actions = self.actor_target(next_state)
            if self._target_policy_smoothing:
                # Add clipped noise to selected actions (This is only done in TD3 but not in DDPG)
                noise = actions.clone().data.normal_(
                    0, self.target_policy_noise
                )
                noise = noise.clamp(
                    -self.target_noise_clip, self.target_noise_clip
                )
                next_actions = (next_actions + noise).clamp(-1, 1)
        return next_actions

    def compute_target_q_values(
        self,
        state: T.Tensor,
        actions: T.Tensor,
        next_state: T.Tensor,
        rewards: T.Tensor,
        dones: T.Tensor,
    ) -> T.Tensor:
        assert self.critic_target is not None
        # Source: TD3 train from SB3, see https://github.com/DLR-RM/stable-baselines3/blob/master/stable_baselines3/td3/td3.py

        with T.no_grad():
            next_actions = self.compute_target_actions(actions, next_state)
            dones_gamma = (1 - dones) * self.gamma

            next_q_values = T.cat(
                self.critic_target(next_state, next_actions),
                dim=1,
            )
            if self.use_tdr:
                dt = (
                    rewards
                    + dones_gamma * next_q_values
                    - T.cat(
                        self.critic_target(state, actions),
                        dim=1,
                    )
                )
                idx = T.le(dt[:, 0], dt[:, 1]).long()  # Index for d0 <= d1
                next_q_value = T.gather(next_q_values, 1, idx.unsqueeze(1))

            else:
                # Compute the next Q-values: min over all critics targets
                next_q_value, _ = T.min(next_q_values, dim=1, keepdim=True)

            target_q_values = rewards + dones_gamma * next_q_value

        return target_q_values

    def compute_critic_loss(
        self,
        state: T.Tensor,
        actions: T.Tensor,
        next_state: T.Tensor,
        rewards: T.Tensor,
        dones: T.Tensor,
    ) -> T.Tensor:
        assert self.critic is not None
        assert self._update_loss_dict is not None

        target_q_values = self.compute_target_q_values(
            state, actions, next_state, rewards, dones
        )

        self._update_loss_dict["target_q_values_mean"][self._n_updates] = (
            float(target_q_values.mean().cpu().detach().numpy())
        )
        self._update_loss_dict["target_q_values_std"][self._n_updates] = float(
            target_q_values.std().cpu().detach().numpy()
        )
        if self._reward_preprocessor is not None and hasattr(
            self._reward_preprocessor, "calc_q_raw_est"
        ):
            self._update_loss_dict["q_raw_est"][self._n_updates] = (
                self._reward_preprocessor.calc_q_raw_est(
                    float(target_q_values.mean().cpu().detach().numpy()),
                    self.gamma,
                )
            )

        # Source: TD3 train from SB3,
        # see https://github.com/DLR-RM/stable-baselines3/blob/master/stable_baselines3/td3/td3.py
        # Get current Q-values estimates for each critic network
        current_q_values = self.critic(state, actions)

        self._update_loss_dict["current_q1_mean"][self._n_updates] = float(
            current_q_values[0].mean().cpu().detach().numpy()
        )

        critic_loss = sum(
            F.mse_loss(current_q, target_q_values)
            for current_q in current_q_values
        )
        assert isinstance(critic_loss, T.Tensor)

        return critic_loss

    def compute_actor_loss(
        self,
        state: T.Tensor,
        actions: T.Tensor,
        next_state: T.Tensor,
        rewards: T.Tensor,
        dones: T.Tensor,
    ) -> T.Tensor:
        assert self.actor is not None
        assert self.critic is not None

        pi = self.actor(state)
        Q = self.critic(state, pi, only_first=True)

        if self.use_tdr:
            di1 = Q - (
                rewards
                + (
                    (1 - dones)
                    * self.gamma
                    * self.critic(
                        next_state, self.actor(next_state), only_first=True
                    )
                )
            )
            Q -= self.tdr_rho * di1

        actor_loss = -Q.mean()  # Default actor loss for TD3
        if self._use_bc:
            lmbda = self.bc_alpha / Q.abs().mean().detach()
            # Actor loss for TD3+BC from https://github.com/sfujim/TD3_BC/blob/main/TD3_BC.py#L143
            actor_loss = lmbda * actor_loss + F.mse_loss(pi, actions)

        return actor_loss

    def update_critic(self, state, actions, next_state, rewards, dones):
        assert self.critic_optimizer is not None
        critic_loss = self.compute_critic_loss(
            state, actions, next_state, rewards, dones
        )

        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        LOG.debug(
            "%s has trained: loss_q = %f",
            self,
            critic_loss,
        )
        self._update_loss_dict["critic_loss"][self._n_updates] = float(
            critic_loss.cpu().detach().numpy()
        )

    def update_actor(self, state, actions, next_state, rewards, dones):
        assert self.actor_optimizer is not None
        # Delayed policy updates
        if self._n_updates % self.policy_delay == 0:
            # Run gradient ascent for actor
            actor_loss = self.compute_actor_loss(
                state, actions, next_state, rewards, dones
            )

            self.actor_optimizer.zero_grad()
            actor_loss.backward()
            self.actor_optimizer.step()

            LOG.debug(
                "%s has trained: loss_pi = %f",
                self,
                actor_loss,
            )
            self._update_loss_dict["actor_loss"][self._n_updates] = float(
                actor_loss.cpu().detach().numpy()
            )
