from typing import List, Any

import numpy as np
import torch

from palaestrai.agent import (
    BrainDumper,
    ActuatorInformation,
)
from palaestrai.agent import Muscle, LOG
from palaestrai.types import Box, Discrete
from harl.ppo.action_type import ActionType

from palaestrai.agent.util.information_utils import (
    concat_flattened_values,
    coerce_and_set_values_to_info_objects,
)


def set_setpoint_to_actuator(setpoint, actuator: ActuatorInformation):
    """Clip actions to make sure they are not higher than max or lower than min
    of allowed action space."""
    if isinstance(actuator.space, Box):
        box_space: Box = actuator.space
        _clipped_value: np.ndarray = np.clip(
            setpoint, box_space.low, box_space.high
        )
        setpoint = box_space.reshape_to_space(_clipped_value)
    elif not isinstance(actuator.space, Discrete):
        raise NotImplementedError(
            "Spaces other than Box and Discrete are currently not supported"
        )
    actuator(setpoint)


class PPOMuscle(Muscle):
    def __init__(self) -> None:
        super().__init__()

        self.actor = None
        self.critic = None

        self._device = torch.device(
            "cuda" if torch.cuda.is_available() else "cpu"
        )

    def setup(self) -> None:
        pass

    @torch.no_grad()
    def propose_actions(self, sensors, actuators_available):
        observation = torch.tensor(
            concat_flattened_values(sensors), dtype=torch.float
        ).to(self._device)
        with torch.no_grad():
            value = self.critic(observation)
        actions, logprob, _ = self.actor.act(observation)

        coerce_and_set_values_to_info_objects(
            np.array(actions.cpu()), actuators_available
        )

        return actuators_available, (
            actions,
            {"readings": observation, "probs": logprob, "vals": value},
        )

    def update(self, update: Any) -> None:
        if update is None:
            LOG.error("%s cannot update without new data!", self)
            return

        self.actor = update["actor"]
        self.critic = update["critic"]

        self.actor.to(self._device), self.critic.to(self._device)  # type: ignore

    def prepare_model(self) -> None:
        assert (
            self._model_loaders
        ), "Brain loaders are not set for preparing model"

        actor_bio = BrainDumper.load_brain_dump(
            self._model_loaders, "ppo_actor"
        )
        critic_bio = BrainDumper.load_brain_dump(
            self._model_loaders, "ppo_critic"
        )

        if actor_bio is not None and critic_bio is not None:
            try:
                self.actor = torch.load(
                    actor_bio, weights_only=False, map_location=self._device
                )
                if self.actor is not None:
                    self.actor.to(self._device)
                self.critic = torch.load(
                    critic_bio, weights_only=False, map_location=self._device
                )
                if self.critic is not None:
                    self.critic.to(self._device)
            except Exception as e:
                LOG.exception(
                    "PPOMuscle(id=0x%x, uid=%s) encountered error while "
                    "loading model: %s ",
                    id(self),
                    str(self.uid),
                    e,
                )
                raise

    def __repr__(self):
        pass
