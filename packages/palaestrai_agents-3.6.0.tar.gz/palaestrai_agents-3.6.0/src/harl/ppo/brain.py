from __future__ import annotations
from typing import Optional, Sequence, Any

import io
import torch as T
import numpy as np

from harl.ppo.network import (
    PPOMemory,
    ActorNetwork,
    CriticNetwork,
)
from palaestrai.agent import (
    Brain,
    BrainDumper,
    LOG,
)
from palaestrai.types import Box, Discrete
from .action_type import ActionType


class PPOBrain(Brain):
    """
    Implements the Proximal Policy Optimization (PPO) Algorithm.

    For details of the algorithm, see the original publication:
    Schulman, F. Wolski, P. Dhariwal, A. Radford, and O. Klimov,
    "Proximal policy optimization algorithms," arXiv.org,
    `<https://arxiv.org/abs/1707.06347>`_, arXiv:1707.06347 [cs.LG].

    Alternatively, the section on PPO in OpenAI's "Spinning Up in
    Deep Reinforcement Learning" documentation is also a way to understand
    the algorithm:
    `<https://spinningup.openai.com/en/latest/algorithms/ppo.html>`_

    Parameters
    ----------
    rollout_size : int = 96
        Training run each x timesteps.
    epochs : int = 50
        The number of updates per learning iteration.
    batch_size : int = 4
        Size of each batch.

    actor_lr : float = 3e-4
        The actor's learning rate.
    critic_lr : float = 1e-3
        The critic's learning rate.
    adam_eps : float = 1e-5
        The adam optimiser's epsilon parameter.
    fc_dims: Sequence[int] = (256, 256)
        Dimensions (amount of fully connected neurons) of the hidden layers
        in the agent's actor and critic networks.

    clip : float = 0.2
        Epsilon value of the clipping function.
    clip_vf : Optional[float] = None
        Clipping parameter for the value function. If None, no clipping
        is done.

    entropy_coef : float = 0.01
        Coefficient for the entropy term.
    vf_coef : float = 0.5
        Coefficient for the value function term.
    max_grad_norm : float = 0.5
        Maximum norm for gradient clipping.

    gamma : float = 0.99
        Factor by which to discount the worth of later rewards.
    gae_lambda : float = 0.95
        Lambda of the general advantage estimation.
    normalise_advantages : bool = True
        Whether to normalise advantages when computing them.
    annealing_total_updates : Optional[int] = None
        Number of total updates over which to anneal the learning rate to 0.
        If None, learning rate annealing is disabled.
    """

    def __init__(
        self,
        rollout_size: int = 96,
        epochs: int = 50,
        batch_size: int = 4,
        actor_lr: float = 3e-4,
        critic_lr: float = 1e-3,
        adam_eps: float = 1e-5,
        fc_dims: Sequence[int] = (256, 256),
        clip: float = 0.2,
        clip_vf: Optional[float] = None,
        entropy_coef: float = 0.01,
        vf_coef: float = 0.5,
        max_grad_norm: float = 0.5,
        gamma: float = 0.99,
        gae_lambda: float = 0.95,
        normalise_advantages: bool = True,
        annealing_total_updates: Optional[int] = None,
    ):
        super().__init__()

        self.rollout_size = rollout_size
        self.epochs = epochs
        self.batch_size = batch_size

        self.actor_lr = actor_lr
        self.critic_lr = critic_lr
        self.adam_eps = adam_eps
        self.fc_dims = fc_dims

        self.clip = clip
        self.clip_vf = clip_vf

        self.entropy_coef = entropy_coef
        self.vf_coef = vf_coef
        self.max_grad_norm = max_grad_norm

        self.gamma = gamma
        self.gae_lambda = gae_lambda
        self.normalise_advantages = normalise_advantages
        self.annealing_total_updates = annealing_total_updates

        self.actor: ActorNetwork | None = None
        self.critic: CriticNetwork | None = None

        self.step = 0
        self._action_type = ActionType.OTHER
        self._ppo_memory: PPOMemory
        self._device = T.device("cuda" if T.cuda.is_available() else "cpu")

    def setup(self):
        assert len(self.sensors) > 0
        assert len(self.actuators) > 0

        # check for action type and set to type if matched
        if all(isinstance(actuator.space, Box) for actuator in self.actuators):
            self._action_type = ActionType.CONTINUOUS
        elif all(
            isinstance(actuator.space, Discrete) for actuator in self.actuators
        ):
            self._action_type = ActionType.DISCRETE
        else:
            self._action_type = ActionType.OTHER
            LOG.error(
                self,
            )
            raise TypeError(
                f"{self} requires exclusively Box or exclusively "
                f"Discrete action spaces",
            )

        obs_dim = int(np.sum([np.prod(s.space.shape) for s in self.sensors]))

        if self._action_type == ActionType.CONTINUOUS:
            act_dim = int(
                np.sum([np.prod(a.space.shape) for a in self.actuators])
            )
        elif self._action_type == ActionType.DISCRETE:
            act_dim = [a.space.n for a in self.actuators]
        else:
            # We've already handled this, but just in case:
            raise TypeError(
                f"{self} requires exclusively Box or exclusively "
                f"Discrete action spaces; hybrid SAC "
                f"is not yet supported, sorry.",
            )

        model_none_dict = {
            "actor_is_none": False,
            "critic_is_none": False,
        }

        if self.actor is None:
            model_none_dict["actor_is_none"] = True
        if self.critic is None:
            model_none_dict["critic_is_none"] = True

        if all(model_none_dict.values()):
            self._init_models(obs_dim, act_dim)
        else:
            if any(model_none_dict.values()):
                LOG.warning(
                    "Only some models are loaded: " + str(model_none_dict)
                )

        self._ppo_memory = PPOMemory(
            self.batch_size,
            self.gamma,
            self.gae_lambda,
            self.normalise_advantages,
        )
        T.manual_seed(self.seed)

    def _init_models(
        self,
        obs_dim: int,
        act_dim: int,
    ):
        assert self.actor is None
        assert self.critic is None

        self.actor = ActorNetwork(
            obs_dim,
            act_dim,
            self._action_type,
            self.actor_lr,
            self.adam_eps,
            self.fc_dims,
        ).to(self._device)

        self.critic = CriticNetwork(
            obs_dim,
            self.critic_lr,
            self.adam_eps,
            self.fc_dims,
        ).to(self._device)

    def thinking(self, muscle_id, data_from_muscle: Any) -> Any:
        assert self.actor is not None
        assert self.critic is not None

        if data_from_muscle is None:
            return {"actor": self.actor, "critic": self.critic}

        action = data_from_muscle[0]
        state = data_from_muscle[1]["readings"]
        probs = data_from_muscle[1]["probs"]
        vals = data_from_muscle[1]["vals"]

        rewards = self.memory.tail(1).objective.item()
        done = self.memory.tail(1).dones.item()
        self._ppo_memory.store_memory(
            state=state,
            action=action,
            probs=probs,
            vals=vals,
            reward=rewards,
            done=done,
        )

        self.step += 1

        if self.step > 0 and self.step % self.rollout_size == 0:
            response = self._learn()
            self.store()
        else:
            response = None

        return response

    def _learn(self):
        self._update_loss_dict["actor_loss"] = {}
        self._update_loss_dict["critic_loss"] = {}

        if self.annealing_total_updates:
            self._anneal_learning_rate()

        advantage_arr, return_arr = (
            self._ppo_memory.compute_advantages_and_returns()
        )

        for epoch in range(self.epochs):
            (
                state_arr,
                action_arr,
                old_prob_arr,
                old_values_arr,
                batches,
            ) = self._ppo_memory.generate_batches()

            for batch in batches:
                self._n_updates += 1
                observations = T.tensor(
                    state_arr[batch], dtype=T.float32, device=self._device
                )
                actions = T.tensor(
                    action_arr[batch], dtype=T.float32, device=self._device
                )
                old_log_probs = T.tensor(
                    old_prob_arr[batch], dtype=T.float32, device=self._device
                )
                old_values = T.tensor(
                    old_values_arr[batch], dtype=T.float32, device=self._device
                )
                advantages = advantage_arr[batch].to(self._device)
                returns = return_arr[batch].to(self._device)

                _, log_prob, entropy = self.actor.act(observations, actions)
                values = self.critic(observations)

                ratio = (log_prob - old_log_probs).exp()

                policy_loss_1 = advantages * ratio
                policy_loss_2 = advantages * T.clamp(
                    ratio, 1 - self.clip, 1 + self.clip
                )
                policy_loss = -T.min(policy_loss_1, policy_loss_2).mean()

                if self.clip_vf:  # Clipping of the value function (cleanrl)
                    v_loss_unclipped = (values - returns) ** 2
                    v_clipped = old_values + T.clamp(
                        values - old_values,
                        -self.clip_vf,
                        self.clip_vf,
                    )
                    v_loss_clipped = (v_clipped - returns) ** 2
                    v_loss_max = T.max(v_loss_unclipped, v_loss_clipped)
                    values_loss = 0.5 * v_loss_max.mean()
                else:
                    values_loss = 0.5 * ((values - returns) ** 2).mean()

                entropy_loss = (
                    T.mean(entropy)
                    if entropy is not None
                    else -T.mean(-log_prob)
                )

                loss = (
                    policy_loss
                    + self.vf_coef * values_loss
                    - self.entropy_coef * entropy_loss
                )

                self.actor.optimiser.zero_grad()
                self.critic.optimiser.zero_grad()
                loss.backward()
                T.nn.utils.clip_grad_norm_(
                    self.actor.parameters(), self.max_grad_norm
                )
                T.nn.utils.clip_grad_norm_(
                    self.critic.parameters(), self.max_grad_norm
                )
                self.actor.optimiser.step()
                self.critic.optimiser.step()
                self._update_loss_dict["actor_loss"][self._n_updates] = float(
                    actor_loss.cpu().detach().numpy()
                )
                self._update_loss_dict["critic_loss"][self._n_updates] = float(
                    critic_loss.cpu().detach().numpy()
                )

        self.add_statistics(
            "actor_loss",
            self._update_loss_dict["actor_loss"],
        )
        self.add_statistics(
            "critic_loss",
            self._update_loss_dict["critic_loss"],
        )

        self._ppo_memory.clear_memory()
        return {"actor": self.actor, "critic": self.critic}

    def _anneal_learning_rate(
        self,
    ):
        updates = self.step / self.rollout_size
        frac = 1.0 - (updates - 1.0) / self.annealing_total_updates
        actor_lrnow = frac * self.actor.optimiser.param_groups[0]["lr"]
        critic_lrnow = frac * self.critic.optimiser.param_groups[0]["lr"]
        self.actor.optimiser.param_groups[0]["lr"] = actor_lrnow
        self.critic.optimiser.param_groups[0]["lr"] = critic_lrnow

    def load(self):
        actor_dump = BrainDumper.load_brain_dump(self._dumpers, "ppo_critic")
        critic_dump = BrainDumper.load_brain_dump(self._dumpers, "ppo_critic")
        if any(
            [
                x is None
                for x in [
                    actor_dump,
                    critic_dump,
                ]
            ]
        ):
            return  # Don't apply "None"s
        self.actor = T.load(
            actor_dump, weights_only=False, map_location=self._device
        )
        self.critic = T.load(
            critic_dump, weights_only=False, map_location=self._device
        )

    def store(self):
        bio = io.BytesIO()

        T.save(self.actor, bio)
        BrainDumper.store_brain_dump(bio, self._dumpers, "ppo_actor")

        bio.seek(0)
        bio.truncate(0)
        T.save(self.critic, bio)
        BrainDumper.store_brain_dump(bio, self._dumpers, "ppo_critic")

    def _remember(self, state, action, probs, vals, reward, done):
        assert self._ppo_memory is not None
        self._ppo_memory.store_memory(
            state=state,
            action=action,
            probs=probs,
            vals=vals,
            reward=reward,
            done=done,
        )
