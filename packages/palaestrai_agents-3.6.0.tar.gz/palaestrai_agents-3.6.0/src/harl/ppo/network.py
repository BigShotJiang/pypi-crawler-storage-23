from typing import Sequence

import numpy as np
import torch
from torch import nn
import torch.distributions.constraints
from torch.optim import Adam
from harl.ppo.action_type import ActionType
from palaestrai.agent import LOG

from torch.distributions.categorical import Categorical
from torch.distributions.normal import Normal


def layer_init(layer, std=np.sqrt(2), bias_const=0.0):
    torch.nn.init.orthogonal_(layer.weight, std)
    torch.nn.init.constant_(layer.bias, bias_const)
    return layer


def mlp(obs_dim, sizes, act_dim, std, activation, output_activation=None):
    layers = []
    sizes = [obs_dim] + list(sizes)
    for j in range(len(sizes) - 1):
        act = activation
        layers += [layer_init(nn.Linear(sizes[j], sizes[j + 1])), act()]
    if act_dim > 0:
        layers += [layer_init(nn.Linear(sizes[-1], act_dim), std=std)]
    if output_activation:
        layers += [output_activation()]
    return nn.Sequential(*layers)


class ActorNetwork(nn.Module):
    def __init__(
        self,
        obs_dim: int,
        act_dim: int,
        action_type: ActionType,
        lr: float = 3e-4,
        eps: float = 1e-5,
        fc_dims: Sequence[int] = (64, 64),
    ):
        super().__init__()
        self.action_type = action_type
        self.device = torch.device(
            "cuda:0" if torch.cuda.is_available() else "cpu"
        )
        if action_type == ActionType.DISCRETE:
            self.shared = mlp(obs_dim, fc_dims, 0, 0.01, nn.ReLU)
            self.policy_heads = nn.ModuleList(
                [nn.Linear(fc_dims[0], n) for n in range(act_dim)]
            )
            self.act_dim = act_dim
        elif action_type == ActionType.CONTINUOUS:
            self.actor_mean = mlp(
                obs_dim, fc_dims, act_dim, 0.01, nn.Tanh, nn.Tanh
            )
            self.actor_logstd = nn.Parameter(torch.ones(1, act_dim) * -0.5)

        self.optimiser = Adam(self.parameters(), lr=lr, eps=eps)

        self.to(self.device)

    def act(self, obs, action=None):
        if self.action_type == ActionType.DISCRETE:
            return self.act_discrete(obs, action)
        elif self.action_type == ActionType.CONTINUOUS:
            return self.act_continuous(obs, action)
        else:
            LOG.error(
                "Brain(id=0x%x) has received a wrong action type %s when initializing actor. Requires exclusively Box, or exclusively Discrete action spaces.",
                id(self),
                self.action_type,
            )
            raise TypeError

    def act_continuous(self, obs, action=None):
        action_mean = self.actor_mean(obs)
        action_logstd = self.actor_logstd.reshape(-1).expand_as(action_mean)
        action_std = torch.exp(action_logstd)
        probs = Normal(action_mean, action_std)

        if action is None:
            action = probs.rsample()

        log_prob = probs.log_prob(action)

        return action, log_prob.sum(-1), probs.entropy().sum(-1)

    def act_discrete(self, obs, actions=None):
        x = self.shared(obs)

        dists = []
        for head in self.policy_heads:
            logits = head(x)
            dists.append(Categorical(logits=logits))

        if actions != None:
            logprobs, entropies = [], []
            for i, dist in enumerate(dists):
                a_i = actions[:, i]
                logprobs.append(dist.log_prob(a_i))
                entropies.append(dist.entropy())

            logprobs = torch.stack(logprobs, dim=-1).sum(dim=-1)
            entropies = torch.stack(entropies, dim=-1).sum(dim=-1)
        else:
            actions = torch.stack([dist.sample() for dist in dists], dim=-1)

            logprobs = torch.stack(
                [dist.log_prob(a) for dist, a in zip(dists, actions.t())],
                dim=-1,
            ).sum(dim=-1)

            entropies = torch.stack(
                [dist.entropy() for dist in dists], dim=-1
            ).sum(dim=-1)

        return actions, logprobs, entropies


class CriticNetwork(nn.Module):
    def __init__(
        self,
        obs_dim: int,
        lr: float = 1e-3,
        eps: float = 1e-5,
        fc_dims: Sequence[int] = (64, 64),
    ):
        super().__init__()
        self.device = torch.device(
            "cuda:0" if torch.cuda.is_available() else "cpu"
        )
        self.critic = mlp(obs_dim, fc_dims, 1, 1.0, nn.Tanh)

        self.optimiser = Adam(self.critic.parameters(), lr=lr, eps=eps)
        self.to(self.device)

    def forward(self, observation):
        return self.critic(observation)


class PPOMemory:
    def __init__(
        self,
        batch_size: int,
        gamma: float = 0.99,
        gae_lambda: float = 0.95,
        normalise_advantages: bool = True,
    ):
        self.states: list = []
        self.probs: list = []
        self.vals: list = []
        self.actions: list = []
        self.rewards: list = []
        self.dones: list = []

        self.gamma = gamma
        self.gae_lambda = gae_lambda
        self.normalise_advantages = normalise_advantages

        self.batch_size = batch_size

    def generate_batches(self):
        n_states = len(self.states)
        batch_start = np.arange(0, n_states, self.batch_size)
        indices = np.arange(n_states, dtype=np.int64)
        np.random.shuffle(indices)
        batches = [indices[i : i + self.batch_size] for i in batch_start]
        return (
            np.array(self.states),
            np.array(self.actions),
            np.array(self.probs),
            np.array(self.vals),
            batches,
        )

    @torch.no_grad()
    def compute_advantages_and_returns(self):
        rewards, vals, dones = (
            np.array(self.rewards),
            np.array(self.vals).reshape(-1),
            np.array(self.dones),
        )

        advantages = np.zeros(len(rewards), dtype=np.float32)

        lastgaelam = 0

        for t in reversed(range(len(self.states))):
            if t == len(self.states) - 1:
                nextnonterminal = 1.0 - dones[-1]
                nextvalues = vals[-1]
            else:
                nextnonterminal = 1.0 - dones[t + 1]
                nextvalues = vals[t + 1]
            delta = (
                rewards[t]
                + self.gamma * nextvalues * nextnonterminal
                - vals[t]
            )
            advantages[t] = lastgaelam = (
                delta
                + self.gamma * self.gae_lambda * nextnonterminal * lastgaelam
            )

        if self.normalise_advantages:
            advantages = (advantages - advantages.mean()) / (
                advantages.std() + 1e-8
            )

        returns = advantages + vals

        return torch.from_numpy(advantages), torch.from_numpy(returns)

    def store_memory(self, state, action, probs, vals, reward, done):
        self.states.append(state.cpu())
        self.actions.append(action.cpu())
        self.probs.append(probs.cpu())
        self.vals.append(vals.cpu())
        self.rewards.append(reward)
        self.dones.append(done)

    def clear_memory(self):
        self.states = []
        self.probs = []
        self.actions = []
        self.rewards = []
        self.dones = []
        self.vals = []
