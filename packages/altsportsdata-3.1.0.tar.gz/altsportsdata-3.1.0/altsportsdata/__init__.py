"""
AltSportsData Python SDK — v3

Production-grade alternative sports data feed for prediction markets,
DFS platforms, and sportsbooks.

Quick start::

    pip install altsportsdata

    from altsportsdata import AltSportsData

    # Prediction market — probabilities for contract creation
    client = AltSportsData(api_key="key", odds_format="probability")
    wsl = client.get_league("wsl")
    probs = wsl.get_market_probabilities(event_id)

    # Sportsbook — American odds with auto-retry
    client = AltSportsData(api_key="key", odds_format="american")
    odds = client.get_moneylines(event_id)

    # DFS platform — matchups + props
    client = AltSportsData(api_key="key")
    matchups = client.get_matchups(event_id)

    # Async client (requires httpx)
    from altsportsdata import AsyncAltSportsData
    async with AsyncAltSportsData(api_key="key") as client:
        events = await client.list_events(league="wsl")

    # Settlement — structured grading for contract resolution
    result = client.get_settlement(event_id)

    # Odds conversion utility
    AltSportsData.convert(2.50, "decimal", "american")  # → 150.0

Docs: https://api.altsportsdata.com/public/docs
API:  https://api.altsportsdata.com/public/docs/swagger
"""

__version__ = "3.1.0"
__author__ = "AltSportsData"
__description__ = (
    "Production-grade alternative sports data feed — odds, events, "
    "futures, settlement for 30 leagues"
)

from .client import AltSportsData
from .async_client import AsyncAltSportsData
from .utils import ResultSet, OddsResult, Outcome, Matchup, as_dataframe
from .catalog import (
    Archetype,
    MarketInfo,
    LEAGUE_ARCHETYPES,
    LEAGUE_NAMES,
    MARKET_CATALOG,
    get_archetype,
    get_league_name,
    get_league_markets,
    get_market_info,
)
from .converters import (
    OddsFormat,
    convert_odds,
    convert_response,
    decimal_to_american,
    decimal_to_probability,
    decimal_to_fractional,
    american_to_decimal,
    probability_to_decimal,
    probability_to_american,
    fractional_to_decimal,
)
from .models import (
    # Enums
    SportType,
    OddType,
    EventStatus,
    MarketStatus,
    Settlement,
    PropSettlement,
    LapStatus,
    FutureType,
    ExactasType,
    OverUnderSubMarketType,
    SortOrder,
    # Core models
    Team,
    Athlete,
    RoundScore,
    # Event models
    EventResponse,
    EventListing,
    EventParticipant,
    EventRoundListing,
    EventRoundHeatListing,
    ScoresListing,
    TeamsListing,
    # Jai Alai
    JaiAlaiEvent,
    JaiAlaiOdds,
    ScoreDetail,
    SetDetail,
    TeamDetail,
    # Odds models
    EventWinnerOdd,
    FastestLapOdd,
    HeatOddsAthlete,
    HeatOddsEvent,
    HeatOddsRound,
    HeadToHead,
    PlayerEventParticipant,
    PlayerAthlete,
    PropBet,
    DreamTeam,
    DreamTeamTeam,
    ProjectionExacta,
    ExactasAthlete,
    OverUnderOdd,
    OverUnderGroup,
    MultiOverUnder,
    SelectionDto,
    # SGP
    SgpRequest,
    SgpResponse,
    # Futures
    FutureListing,
    FutureOdds,
    FutureOdd,
    FutureOddAthlete,
    # Sports
    SportsListing,
    # Jai Alai odds
    BaseSelection,
    MoneyLineGroup,
    EventWinnerMarket,
    SpreadSelection,
    SpreadGroup,
    TotalSetsSelection,
    TotalSetsGroup,
    MatchWinnerMarketType,
    SetOdds,
)
from .exceptions import (
    AltSportsDataError,
    AuthenticationError,
    ValidationError,
    RateLimitError,
    NotFoundError,
    PermissionError,
    ServerError,
    NetworkError,
    ConfigurationError,
    DataFormatError,
    RetryExhaustedError,
)

__all__ = [
    # Clients
    "AltSportsData",
    "AsyncAltSportsData",
    # DataFrame / tabular
    "ResultSet",
    "OddsResult",
    "Outcome",
    "Matchup",
    "as_dataframe",
    # Catalog / discovery
    "Archetype",
    "MarketInfo",
    "LEAGUE_ARCHETYPES",
    "LEAGUE_NAMES",
    "MARKET_CATALOG",
    "get_archetype",
    "get_league_name",
    "get_league_markets",
    "get_market_info",
    # Odds conversion
    "OddsFormat",
    "convert_odds",
    "convert_response",
    "decimal_to_american",
    "decimal_to_probability",
    "decimal_to_fractional",
    "american_to_decimal",
    "probability_to_decimal",
    "probability_to_american",
    "fractional_to_decimal",
    # Enums
    "SportType", "OddType", "EventStatus", "MarketStatus",
    "Settlement", "PropSettlement", "LapStatus", "FutureType",
    "ExactasType", "OverUnderSubMarketType", "SortOrder",
    # Core
    "Team", "Athlete", "RoundScore",
    # Events
    "EventResponse", "EventListing", "EventParticipant",
    "EventRoundListing", "EventRoundHeatListing", "ScoresListing", "TeamsListing",
    # Jai Alai
    "JaiAlaiEvent", "JaiAlaiOdds", "ScoreDetail", "SetDetail", "TeamDetail",
    # Odds
    "EventWinnerOdd", "FastestLapOdd", "HeatOddsAthlete", "HeatOddsEvent",
    "HeatOddsRound", "HeadToHead", "PlayerEventParticipant", "PlayerAthlete",
    "PropBet", "DreamTeam", "DreamTeamTeam", "ProjectionExacta", "ExactasAthlete",
    "OverUnderOdd", "OverUnderGroup", "MultiOverUnder", "SelectionDto",
    # SGP
    "SgpRequest", "SgpResponse",
    # Futures
    "FutureListing", "FutureOdds", "FutureOdd", "FutureOddAthlete",
    # Sports
    "SportsListing",
    # Jai Alai odds
    "BaseSelection", "MoneyLineGroup", "EventWinnerMarket",
    "SpreadSelection", "SpreadGroup", "TotalSetsSelection", "TotalSetsGroup",
    "MatchWinnerMarketType", "SetOdds",
    # Exceptions
    "AltSportsDataError", "AuthenticationError", "ValidationError",
    "RateLimitError", "NotFoundError", "PermissionError", "ServerError",
    "NetworkError", "ConfigurationError", "DataFormatError",
    "RetryExhaustedError",
]
