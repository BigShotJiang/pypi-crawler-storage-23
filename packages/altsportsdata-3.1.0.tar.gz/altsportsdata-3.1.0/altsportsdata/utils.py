"""
DataFrame & tabular output utilities.

Provides ResultSet (list with .df) and OddsResult (dict with .df)
for instant pandas DataFrame conversion — like Alpaca's bars.df pattern.

    events = client.list_events(status="upcoming")
    print(events)                  # clean table
    df = events.df                 # pandas DataFrame
    df.to_csv("events.csv")       # export

    odds = client.get_moneylines(event_id)
    print(odds)                    # clean table
    df = odds.df                   # pandas DataFrame

Pandas is optional. If not installed, .df raises a helpful ImportError.
All other features (clean printing, iteration, len) work without pandas.
"""

from typing import Any, Dict, List, Optional, Sequence, TypeVar, Generic, Iterator
import textwrap

T = TypeVar("T")


# ── Simple wrapper objects for beginners ─────────────────────────────────────


class Outcome:
    """
    A single outcome/player in an odds response.

    Simple dot-access — no dicts, no nesting::

        odds = client.get_moneylines(event_id)
        for player in odds:
            print(f"{player.name}: {player.odds}  ({player.probability}%)")

    Attributes:
        name: Athlete/team name (e.g. "Eli Tomac")
        odds: Decimal odds (e.g. 2.02)
        probability: Win probability as percentage (e.g. 49.4)
        settlement: "WIN", "LOSE", or None
        status: "OPEN", "CLOSED", etc.
        id: Outcome ID for placing bets
        position: Finishing position (if available)
    """

    __slots__ = ("name", "odds", "probability", "settlement", "status", "id", "position", "_raw")

    def __init__(self, raw: Dict[str, Any]):
        self._raw = raw
        ath = raw.get("athlete", {})
        if isinstance(ath, dict):
            self.name = f"{ath.get('firstName', '')} {ath.get('lastName', '')}".strip()
        elif isinstance(ath, str):
            self.name = ath
        else:
            self.name = str(ath) if ath else ""
        self.odds = raw.get("odds")
        self.probability = raw.get("probability")
        self.settlement = raw.get("settlement")
        self.status = raw.get("status")
        self.id = raw.get("outcomeId") or raw.get("id")
        self.position = raw.get("position")

    def __repr__(self) -> str:
        parts = [f"{self.name}"]
        if self.odds is not None:
            parts.append(f"odds={self.odds}")
        if self.probability is not None:
            parts.append(f"prob={self.probability}%")
        if self.settlement and self.settlement not in ("NOT_SET", None):
            parts.append(f"→ {self.settlement}")
        return f"Outcome({', '.join(parts)})"

    def __str__(self) -> str:
        line = f"{self.name}"
        if self.odds is not None:
            line += f"  odds={self.odds:.2f}"
        if self.probability is not None:
            line += f"  ({self.probability:.1f}%)"
        if self.settlement and self.settlement not in ("NOT_SET", None):
            line += f"  → {self.settlement}"
        return line

    def to_dict(self) -> Dict[str, Any]:
        """Convert to a plain dict."""
        return {
            "name": self.name, "odds": self.odds,
            "probability": self.probability,
            "settlement": self.settlement, "status": self.status,
            "id": self.id, "position": self.position,
        }


class Matchup:
    """
    A head-to-head matchup between two players.

    Simple dot-access::

        matchups = client.get_matchups(event_id)
        for m in matchups:
            print(f"{m.player1} ({m.odds1}) vs {m.player2} ({m.odds2})")

    Attributes:
        player1: First player name
        player2: Second player name
        odds1: First player's odds
        odds2: Second player's odds
        id: Matchup ID
        winner: Winner participant ID (if settled)
    """

    __slots__ = ("player1", "player2", "odds1", "odds2", "id", "winner",
                 "settlement1", "settlement2", "_raw")

    def __init__(self, raw: Dict[str, Any]):
        self._raw = raw
        p1 = raw.get("eventParticipant1", {})
        p2 = raw.get("eventParticipant2", {})
        a1 = p1.get("athlete", {}) if isinstance(p1, dict) else {}
        a2 = p2.get("athlete", {}) if isinstance(p2, dict) else {}
        self.player1 = f"{a1.get('firstName', '')} {a1.get('lastName', '')}".strip()
        self.player2 = f"{a2.get('firstName', '')} {a2.get('lastName', '')}".strip()
        self.odds1 = p1.get("odds") if isinstance(p1, dict) else None
        self.odds2 = p2.get("odds") if isinstance(p2, dict) else None
        self.settlement1 = p1.get("settlement") if isinstance(p1, dict) else None
        self.settlement2 = p2.get("settlement") if isinstance(p2, dict) else None
        self.id = raw.get("outcomeId") or raw.get("id")
        self.winner = raw.get("winnerParticipantId")

    def __repr__(self) -> str:
        return f"Matchup({self.player1} vs {self.player2})"

    def __str__(self) -> str:
        o1 = f" ({self.odds1:.2f})" if self.odds1 else ""
        o2 = f" ({self.odds2:.2f})" if self.odds2 else ""
        return f"{self.player1}{o1}  vs  {self.player2}{o2}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "player1": self.player1, "odds1": self.odds1,
            "player2": self.player2, "odds2": self.odds2,
            "id": self.id, "winner": self.winner,
        }

# Maximum column widths for table display
_MAX_COL_WIDTH = 40
_MAX_ROWS_DISPLAY = 50

# ── DataFrame helper ─────────────────────────────────────────────────────────


def _get_pandas():
    """Import pandas or raise helpful error."""
    try:
        import pandas as pd
        return pd
    except ImportError:
        raise ImportError(
            "pandas required for DataFrame output.\n"
            "Install with: pip install pandas\n"
            "Or: pip install altsportsdata[pandas]"
        )


def as_dataframe(data: Any, columns: Optional[List[str]] = None):
    """
    Convert any ASD response to a pandas DataFrame.

    Handles:
    - List of Pydantic models (EventListing, SportsListing, etc.)
    - List of dicts (get_markets() output)
    - Dict with list values (raw odds responses like {"eventWinner": [...]})
    - ResultSet and OddsResult objects

    Args:
        data: ASD response data
        columns: Optional column filter — only include these columns

    Returns:
        pandas.DataFrame

    Example::

        from altsportsdata.utils import as_dataframe

        events = client.list_events(status="upcoming")
        df = as_dataframe(events, columns=["name", "league", "start_date", "status"])
    """
    pd = _get_pandas()

    if isinstance(data, ResultSet):
        return data.df
    if isinstance(data, OddsResult):
        return data.df

    df = _to_df(data, pd)

    if columns and not df.empty:
        available = [c for c in columns if c in df.columns]
        if available:
            df = df[available]

    return df


def _to_df(data: Any, pd) -> "pd.DataFrame":
    """Internal conversion logic."""
    if isinstance(data, list):
        if not data:
            return pd.DataFrame()
        first = data[0]
        if hasattr(first, "model_dump"):
            rows = [_flatten_model(item) for item in data]
        elif isinstance(first, dict):
            rows = [_flatten_dict(item) for item in data]
        else:
            return pd.DataFrame(data)
        return pd.DataFrame(rows)

    elif isinstance(data, dict):
        # Odds response: {"eventWinner": [...], "headToHead": [...]}
        for key, val in data.items():
            if isinstance(val, list) and val:
                return _to_df(val, pd)
        # Single-level dict
        return pd.DataFrame([data])

    return pd.DataFrame()


def _flatten_model(obj) -> Dict[str, Any]:
    """Flatten a Pydantic model to a dict with snake_case keys, expanding nested athlete."""
    if hasattr(obj, "model_dump"):
        d = obj.model_dump()
    else:
        d = dict(obj) if hasattr(obj, "__iter__") else {"value": obj}
    result = _flatten_dict(d)
    # If sportType/league is missing, extract from ID prefix (e.g. "wsl:abc123" → "wsl")
    if not result.get("sportType") and result.get("id"):
        id_str = str(result["id"])
        if ":" in id_str:
            result["sportType"] = id_str.split(":")[0]
    return result


def _flatten_dict(d: Dict[str, Any]) -> Dict[str, Any]:
    """Flatten nested dicts for tabular output — expands athlete, team, etc."""
    flat = {}
    for k, v in d.items():
        if k == "athlete" and isinstance(v, dict):
            flat["athlete"] = f"{v.get('firstName', '')} {v.get('lastName', '')}".strip()
            if v.get("id"):
                flat["athlete_id"] = v["id"]
            if v.get("nationality"):
                flat["nationality"] = v["nationality"]
        elif k == "eventParticipant1" and isinstance(v, dict):
            a = v.get("athlete", {})
            flat["player1"] = f"{a.get('firstName', '')} {a.get('lastName', '')}".strip()
            flat["player1_odds"] = v.get("odds")
            flat["player1_settlement"] = v.get("settlement")
        elif k == "eventParticipant2" and isinstance(v, dict):
            a = v.get("athlete", {})
            flat["player2"] = f"{a.get('firstName', '')} {a.get('lastName', '')}".strip()
            flat["player2_odds"] = v.get("odds")
            flat["player2_settlement"] = v.get("settlement")
        elif isinstance(v, dict):
            # Skip deeply nested dicts (rounds, teams, etc.)
            continue
        elif isinstance(v, list):
            flat[k] = len(v) if v else 0
        elif isinstance(v, str) and len(v) > _MAX_COL_WIDTH:
            flat[k] = v[:_MAX_COL_WIDTH - 3] + "..."
        else:
            flat[k] = v
    return flat


# ── Clean table formatter (no pandas required) ──────────────────────────────


def _format_table(
    rows: List[Dict[str, Any]],
    columns: Optional[List[str]] = None,
    max_rows: int = _MAX_ROWS_DISPLAY,
    title: Optional[str] = None,
) -> str:
    """Format a list of dicts as a clean ASCII table."""
    if not rows:
        return "(empty)"

    # Determine columns
    if columns:
        cols = [c for c in columns if any(c in r for r in rows)]
    else:
        # Auto-detect: use all keys from first row, prioritize useful ones
        seen = []
        for r in rows[:5]:
            for k in r:
                if k not in seen:
                    seen.append(k)
        cols = seen

    if not cols:
        return "(no displayable columns)"

    # Calculate column widths
    widths = {}
    for c in cols:
        header_w = len(str(c))
        max_val_w = 0
        for r in rows[:max_rows]:
            val = r.get(c, "")
            max_val_w = max(max_val_w, len(_format_cell(val)))
        widths[c] = min(max(header_w, max_val_w), _MAX_COL_WIDTH)

    # Build table
    lines = []
    if title:
        lines.append(title)
        lines.append("")

    # Header
    header = "  ".join(str(c).ljust(widths[c]) for c in cols)
    lines.append(header)
    lines.append("  ".join("─" * widths[c] for c in cols))

    # Rows
    display_rows = rows[:max_rows]
    for r in display_rows:
        cells = []
        for c in cols:
            val = _format_cell(r.get(c, ""))
            if len(val) > widths[c]:
                val = val[: widths[c] - 2] + ".."
            cells.append(val.ljust(widths[c]))
        lines.append("  ".join(cells))

    if len(rows) > max_rows:
        lines.append(f"  ... and {len(rows) - max_rows} more rows")

    lines.append("")
    lines.append(f"  {len(rows)} rows × {len(cols)} columns")

    return "\n".join(lines)


def _format_cell(val: Any) -> str:
    """Format a single cell value for table display."""
    if val is None:
        return ""
    if isinstance(val, float):
        if val == int(val) and val < 1e6:
            return str(int(val))
        if abs(val) < 0.01:
            return f"{val:.6f}"
        return f"{val:.4f}" if abs(val) < 100 else f"{val:.2f}"
    if isinstance(val, list):
        return f"[{len(val)}]"
    return str(val)


# ── ResultSet — list with .df ────────────────────────────────────────────────


# Priority column orderings for different result types
_EVENT_COLUMNS = [
    "sportType", "name", "startDate", "eventStatus",
    "eventLocation", "id",
]
_EVENT_DISPLAY = ["league", "name", "start_date", "status", "location", "id"]

_MARKET_COLUMNS = [
    "league", "event_name", "status", "start_date",
    "market_count", "event_id",
]

_LEAGUE_COLUMNS = [
    "league_key", "name", "market_count", "market_types",
]

_ODDS_DISPLAY = [
    "athlete", "probability", "odds", "settlement", "status",
    "outcome_id",
]

_H2H_DISPLAY = [
    "player1", "player1_odds", "player2", "player2_odds",
    "player1_settlement", "player2_settlement",
]


class ResultSet(list):
    """
    List subclass with DataFrame support and clean table display.

    Behaves exactly like a regular list, but adds:

    - ``.df`` — pandas DataFrame (requires pandas)
    - ``print(results)`` — clean ASCII table
    - ``.to_csv(path)`` — export to CSV
    - ``.to_json()`` — serialize to JSON

    All list operations work normally: indexing, slicing, iteration, len().
    """

    def __init__(self, items=None, _display_columns=None, _title=None):
        super().__init__(items or [])
        self._display_columns = _display_columns
        self._title = _title

    @property
    def df(self):
        """
        Convert to pandas DataFrame.

        Returns a clean, flat DataFrame with snake_case column names.
        Nested objects (athlete, team) are flattened automatically.

        Raises ImportError if pandas is not installed.

        Example::

            events = client.list_events(status="upcoming")
            df = events.df
            print(df[["name", "sportType", "startDate"]])
        """
        pd = _get_pandas()
        if not self:
            return pd.DataFrame()

        first = self[0]
        if hasattr(first, "model_dump"):
            rows = [_flatten_model(item) for item in self]
        elif isinstance(first, dict):
            rows = [_flatten_dict(item) if isinstance(item, dict) else {"value": item} for item in self]
        else:
            return pd.DataFrame(list(self))

        df = pd.DataFrame(rows)

        # Rename to snake_case for common columns
        rename_map = {
            "sportType": "league",
            "startDate": "start_date",
            "endDate": "end_date",
            "eventStatus": "status",
            "eventLocation": "location",
            "eventLocationGroup": "location_group",
            "tourName": "tour",
            "tourYear": "tour_year",
            "eventNumber": "event_number",
            "outcomeId": "outcome_id",
            "updatedAt": "updated_at",
        }
        df = df.rename(columns={k: v for k, v in rename_map.items() if k in df.columns})

        return df

    def to_csv(self, path: str, **kwargs) -> None:
        """Export to CSV file. Requires pandas."""
        self.df.to_csv(path, index=False, **kwargs)

    def to_json(self, **kwargs) -> str:
        """Export to JSON string. Requires pandas."""
        return self.df.to_json(orient="records", **kwargs)

    def __str__(self) -> str:
        if not self:
            return "ResultSet(empty)"

        first = self[0]
        if hasattr(first, "model_dump"):
            rows = [_flatten_model(item) for item in self]
        elif isinstance(first, dict):
            rows = [_flatten_dict(item) if isinstance(item, dict) else {"value": item} for item in self]
        else:
            return f"ResultSet({len(self)} items)"

        return _format_table(
            rows,
            columns=self._display_columns,
            title=self._title,
        )

    def __repr__(self) -> str:
        if not self:
            return "ResultSet(empty)"

        # Summarize
        types = set()
        for item in self[:10]:
            if hasattr(item, "sportType") and item.sportType:
                types.add(item.sportType)
            elif isinstance(item, dict) and "league" in item:
                types.add(item["league"])

        type_str = ", ".join(sorted(types)[:5])
        if len(types) > 5:
            type_str += f" +{len(types)-5} more"

        return f"ResultSet({len(self)} items{f' | {type_str}' if type_str else ''})"


class OddsResult(dict):
    """
    Odds response with clean iteration, DataFrame support, and table display.

    **Beginner-friendly** — just iterate to get players/outcomes::

        odds = client.get_moneylines(event_id)
        for player in odds:
            print(f"{player.name}: {player.odds}  ({player.probability}%)")

    **Power user** — DataFrame and dict access still work::

        odds.df                         # pandas DataFrame
        odds["eventWinner"]             # raw API data
        print(odds)                     # clean table
        odds.to_csv("odds.csv")        # export

    Properties:
        .market_type — the market type key (e.g. "eventWinner", "headToHead")
        .players — list of Outcome objects (alias for list(odds))
        .df — pandas DataFrame
    """

    @property
    def market_type(self) -> Optional[str]:
        """The primary market type key in this response."""
        # Use dict.items() explicitly to avoid __iter__ override conflicts
        for k, v in dict.items(self):
            if isinstance(v, list) and not k.startswith("_"):
                return k
        return None

    # ── Beginner-friendly iteration ──────────────────────────────────

    def __iter__(self) -> Iterator:
        """
        Iterate over outcomes/matchups as simple objects.

        For eventWinner/podiums/etc → yields Outcome objects with .name, .odds, .probability
        For headToHead → yields Matchup objects with .player1, .player2, .odds1, .odds2

        Example::

            for player in client.get_moneylines(event_id):
                print(f"{player.name}: {player.odds}")
        """
        mtype = self._get_market_type()
        if not mtype:
            return dict.__iter__(self)  # fallback to normal dict iteration

        items = dict.__getitem__(self, mtype)
        if not items:
            return iter([])

        if mtype == "headToHead":
            return iter([Matchup(item) for item in items])
        else:
            return iter([Outcome(item) for item in items])

    def __len__(self) -> int:
        """Number of outcomes/matchups in the primary market."""
        mtype = self._get_market_type()
        if mtype:
            return len(dict.__getitem__(self, mtype))
        return dict.__len__(self)

    def _get_market_type(self) -> Optional[str]:
        """Internal market type lookup using explicit dict access."""
        for k, v in dict.items(self):
            if isinstance(v, list) and not k.startswith("_"):
                return k
        return None

    @property
    def players(self) -> List[Outcome]:
        """
        List of Outcome objects — each with .name, .odds, .probability.

        Example::

            odds = client.get_moneylines(event_id)
            top3 = odds.players[:3]
            for p in top3:
                print(f"{p.name}: {p.odds}")
        """
        mtype = self.market_type
        if not mtype or mtype == "headToHead":
            return []
        return [Outcome(item) for item in dict.__getitem__(self, mtype)]

    @property
    def matchups(self) -> List[Matchup]:
        """
        List of Matchup objects — each with .player1, .player2, .odds1, .odds2.

        Example::

            odds = client.get_matchups(event_id)
            for m in odds.matchups:
                print(f"{m.player1} vs {m.player2}")
        """
        items = dict.get(self, "headToHead", [])
        return [Matchup(item) for item in items]

    @property
    def df(self):
        """
        Convert the primary odds list to a pandas DataFrame.

        Automatically flattens nested athlete objects and renames
        columns to clean snake_case.
        """
        pd = _get_pandas()

        mtype = self._get_market_type()
        if not mtype:
            return pd.DataFrame([_flatten_dict(dict(dict.items(self)))])

        items = dict.__getitem__(self, mtype)
        if not items:
            return pd.DataFrame()

        rows = [_flatten_dict(item) if isinstance(item, dict) else {"value": item}
                for item in items]
        df = pd.DataFrame(rows)

        # Rename common columns
        rename_map = {
            "outcomeId": "outcome_id",
            "updatedAt": "updated_at",
            "winnerParticipantId": "winner_id",
        }
        df = df.rename(columns={k: v for k, v in rename_map.items() if k in df.columns})

        # Sort by odds if available
        if "odds" in df.columns:
            df = df.sort_values("odds", na_position="last").reset_index(drop=True)

        return df

    def to_csv(self, path: str, **kwargs) -> None:
        """Export to CSV file. Requires pandas."""
        self.df.to_csv(path, index=False, **kwargs)

    def __str__(self) -> str:
        mtype = self._get_market_type()
        if not mtype:
            return dict.__repr__(self)

        items = dict.__getitem__(self, mtype)
        if not items:
            return f"OddsResult({mtype}: empty)"

        rows = [_flatten_dict(item) if isinstance(item, dict) else {"value": item}
                for item in items]

        # Detect display columns based on market type
        if mtype == "headToHead":
            display_cols = _H2H_DISPLAY
        else:
            display_cols = _ODDS_DISPLAY

        return _format_table(
            rows,
            columns=display_cols,
            title=f"Market: {mtype}",
        )

    def __repr__(self) -> str:
        mtype = self._get_market_type()
        if mtype:
            items = dict.__getitem__(self, mtype)
            return f"OddsResult({mtype}: {len(items)} outcomes)"
        return f"OddsResult({dict.__len__(self)} keys)"
