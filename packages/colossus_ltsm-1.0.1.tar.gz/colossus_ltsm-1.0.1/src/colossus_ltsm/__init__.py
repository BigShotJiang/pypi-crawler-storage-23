"""Colossus LTSM package: Font conversion and visualization tools."""
__version__ = "1.0.1"
