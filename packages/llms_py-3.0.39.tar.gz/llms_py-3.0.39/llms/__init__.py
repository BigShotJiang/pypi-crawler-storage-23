# Import the main module content
from .main import main as main

__all__ = ["main"]
