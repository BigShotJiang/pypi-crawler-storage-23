"""GTA MCP Server - Global Trade Alert database integration."""

__version__ = "0.4.3"
