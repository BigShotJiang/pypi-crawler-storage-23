"""Shared test fixtures for GTA MCP tests."""

import pytest
