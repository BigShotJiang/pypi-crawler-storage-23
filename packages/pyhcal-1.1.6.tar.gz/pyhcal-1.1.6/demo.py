#%%
from pyhcal.calibrators import calibrator
from pyhcal import metrics
from pyhcal import figures
#%%
cal = calibrator('C:/Users/mfratki/Documents/Calibrations/Nemadji')
cal.load_model(0)

# %% Outlets

cal.get_outlets()

station_ids = ['S007-571', 'W28068001', 'S005-671', 'S008-051', 'S012-414']
reach_ids = [417]

df = cal.compare_simulated_observed(station_ids,reach_ids,'WT','h')
#

figures.contTimeseries(df.dropna(subset=['observed']),station_ids,'WT','degf')


#%% Mapping
cal.mapper.map_parameter('PERLND',
                         'PWAT-PARM2',
                         'LZSN')
cal.mapper.map_parameter('PERLND',
                         'PWAT-PARM2',
                         'LZSN',
                         weight_by_area=False)

cal.mapper.map_output('PERLND','PERO')

#%% Reports

# loading at catchment and watershed
cal.reports


# Total amount of constituent contributed from the landscape to channels

cal.model.reports.contributions('Q',630)


cal.model.reports.landcover_contributions('Q',417)



#%% Data

cal.dm.constituent_summary('Q','h')
cal.dm.reports.outlet_summary()

