"""Unit tests for nonlocal games functions."""
