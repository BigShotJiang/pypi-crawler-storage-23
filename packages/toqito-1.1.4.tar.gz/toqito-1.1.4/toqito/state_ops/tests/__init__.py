"""Testing operations of quantum states."""
