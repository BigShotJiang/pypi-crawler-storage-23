"""Tests for channels."""
