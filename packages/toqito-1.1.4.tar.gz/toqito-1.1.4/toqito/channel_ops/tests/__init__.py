"""Tests for channel_ops."""
