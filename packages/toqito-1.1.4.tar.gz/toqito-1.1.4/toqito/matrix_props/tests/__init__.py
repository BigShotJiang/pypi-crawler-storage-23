"""Test matrix properties."""
