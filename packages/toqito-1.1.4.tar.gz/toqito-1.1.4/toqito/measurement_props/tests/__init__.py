"""Tests for measurement_props."""
