"""Tests for measurement_ops."""
