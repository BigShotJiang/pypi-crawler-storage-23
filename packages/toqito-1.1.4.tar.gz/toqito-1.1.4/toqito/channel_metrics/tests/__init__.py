"""Tests for channel_metrics."""
