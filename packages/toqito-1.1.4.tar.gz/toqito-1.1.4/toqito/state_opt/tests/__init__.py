"""Tests for state optimizations scenarios."""
