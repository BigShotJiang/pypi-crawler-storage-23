"""Testing metrics on quantum states."""
