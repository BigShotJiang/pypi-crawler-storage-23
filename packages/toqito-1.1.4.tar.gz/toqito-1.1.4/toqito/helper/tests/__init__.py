"""Tests for helper."""
