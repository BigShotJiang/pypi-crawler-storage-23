"""Tests for channel_props."""
