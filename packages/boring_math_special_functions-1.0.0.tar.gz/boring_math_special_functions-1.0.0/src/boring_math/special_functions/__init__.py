# Copyright 2023-2026 Geoffrey R. Scheller
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Mathematical special functions
------------------------------

..admonition:: Module special_functions.float0

    +-------------+--------------------------------+--------------------+
    | Function    | Description                    | Type               |
    +=============+================================+====================+
    | ``exp0(x)`` | exponential function about x=0 | ``float -> float`` |
    +-------------+--------------------------------+--------------------+
    | ``sin0(x)`` | sine function about x=0        | ``float -> float`` |
    +-------------+--------------------------------+--------------------+
    | ``cos0(x)`` | cosine function about x=0      | ``float -> float`` |
    +-------------+--------------------------------+--------------------+
    | ``tan0(x)`` | tangent function about x=0     | ``float -> float`` |
    +-------------+--------------------------------+--------------------+

..admonition:: Module special_functions.complex0

    +-------------+--------------------------------+------------------------+
    | Function    | Description                    | Type                   |
    +=============+================================+========================+
    | ``exp0(z)`` | exponential function about z=0 | ``complex -> complex`` |
    +-------------+--------------------------------+------------------------+
    | ``sin0(z)`` | sine function about z=0        | ``complex -> complex`` |
    +-------------+--------------------------------+------------------------+
    | ``sin0(z)`` | cosine function about z=0      | ``complex -> complex`` |
    +-------------+--------------------------------+------------------------+
    | ``tan0(z)`` | tangent function about z=0     | ``complex -> complex`` |
    +-------------+--------------------------------+------------------------+

..admonition:: Module special_functions.float

    +------------+----------------------+--------------------+
    | Function   | Description          | Type               |
    +============+======================+====================+
    | ``exp(x)`` | exponential function | ``float -> float`` |
    +------------+----------------------+--------------------+
    | ``sin(x)`` | sine function        | ``float -> float`` |
    +------------+----------------------+--------------------+
    | ``cos(x)`` | cosine function      | ``float -> float`` |
    +------------+----------------------+--------------------+
    | ``tan(x)`` | tangent function     | ``float -> float`` |
    +------------+----------------------+--------------------+

..admonition:: Module special_functions.complex

    +------------+----------------------+------------------------+
    | Function   | Description          | Type                   |
    +============+======================+========================+
    | ``exp(z)`` | exponential function | ``complex -> complex`` |
    +------------+----------------------+------------------------+
    | ``sin(z)`` | sine function        | ``complex -> complex`` |
    +------------+----------------------+------------------------+
    | ``sin(z)`` | cosine function      | ``complex -> complex`` |
    +------------+----------------------+------------------------+
    | ``tan(z)`` | tangent function     | ``complex -> complex`` |
    +------------+----------------------+------------------------+

"""

__author__ = 'Geoffrey R. Scheller'
__copyright__ = 'Copyright (c) 2025-2026 Geoffrey R. Scheller'
__license__ = 'Apache License 2.0'
