# bitbucket - close_pull_request

**Toolkit**: `bitbucket`
**Method**: `close_pull_request`
**Source File**: `cloud_api_wrapper.py`
**Class**: `BitbucketCloudApi`

---

## Method Implementation

```python
    def close_pull_request(self, pr_id: str, message: str = None) -> Any:
        """
        Decline (close) a pull request without merging it.
        Parameters:
            pr_id (str): the pull request ID
            message (str, optional): Optional message explaining why the pull request is being declined
        Returns:
            The API response
        """
        # If a message is provided, add it as a comment before declining
        if message:
            self.add_pull_request_comment(pr_id=pr_id, content=message)
        
        # Decline the pull request using the built-in decline method
        response = self.repository.pullrequests.get(pr_id).decline()
        return normalize_response(response)
```

## Helper Methods

```python
Helper: add_pull_request_comment
    def add_pull_request_comment(self, pr_id: str, text: str) -> str:
        pass
```

```python
Helper: normalize_response
def normalize_response(response) -> Dict[str, Any]:
    """
    Normalize API response to dictionary format.
    Handles different response types from Bitbucket APIs.
    """
    if isinstance(response, dict):
        return response
    if hasattr(response, 'to_dict'):
        return response.to_dict()
    if hasattr(response, '__dict__'):
        return {k: v for k, v in response.__dict__.items()
                if isinstance(v, (str, int, float, bool, list, dict, type(None)))}
    return {"raw_response": str(response)}
```
