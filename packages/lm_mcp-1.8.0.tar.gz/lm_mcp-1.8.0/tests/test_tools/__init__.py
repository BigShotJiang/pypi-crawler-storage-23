# Description: Tests for MCP tool utilities.
# Description: Covers response formatting and error handling helpers.
