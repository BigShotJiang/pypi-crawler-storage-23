# Description: Tests for MCP prompts module.
# Description: Verifies pre-built workflow templates for LogicMonitor operations.
