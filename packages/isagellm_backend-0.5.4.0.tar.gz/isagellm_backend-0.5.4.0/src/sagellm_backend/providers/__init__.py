"""Providers 包初始化"""

from __future__ import annotations

from sagellm_backend.providers.cpu import CPUBackendProvider, create_cpu_backend

# Hardware providers (optional dependencies - check at init time)
try:
    from sagellm_backend.providers.cuda import CUDABackendProvider, create_cuda_backend

    _CUDA_AVAILABLE = True
except ImportError:
    _CUDA_AVAILABLE = False
    CUDABackendProvider = None  # type: ignore
    create_cuda_backend = None  # type: ignore

try:
    from sagellm_backend.providers.ascend import AscendBackendProvider, create_ascend_backend
    from sagellm_backend.providers.ascend_device_info import (
        get_device_count,
        get_device_properties,
        get_memory_info,
    )

    _ASCEND_AVAILABLE = True
except ImportError:
    _ASCEND_AVAILABLE = False
    AscendBackendProvider = None  # type: ignore
    create_ascend_backend = None  # type: ignore
    get_device_count = None  # type: ignore
    get_device_properties = None  # type: ignore
    get_memory_info = None  # type: ignore

# Domestic accelerator providers
try:
    from sagellm_backend.providers.kunlun import KunlunBackendProvider

    _KUNLUN_AVAILABLE = True
except ImportError:
    _KUNLUN_AVAILABLE = False
    KunlunBackendProvider = None  # type: ignore

try:
    from sagellm_backend.providers.dcu import DCUBackendProvider

    _DCU_AVAILABLE = True
except ImportError:
    _DCU_AVAILABLE = False
    DCUBackendProvider = None  # type: ignore

try:
    from sagellm_backend.providers.mthreads import MThreadsBackendProvider

    _MTHREADS_AVAILABLE = True
except ImportError:
    _MTHREADS_AVAILABLE = False
    MThreadsBackendProvider = None  # type: ignore

__all__ = [
    "CPUBackendProvider",
    "create_cpu_backend",
    # Hardware providers (may be None if not installed)
    "CUDABackendProvider",
    "create_cuda_backend",
    "AscendBackendProvider",
    "create_ascend_backend",
    "get_device_count",
    "get_device_properties",
    "get_memory_info",
    # Domestic accelerator providers
    "KunlunBackendProvider",
    "DCUBackendProvider",
    "MThreadsBackendProvider",
]
