"""Hygon DCU kernels module.

Provides optimized kernel wrappers for Hygon DCU devices using ROCm/HIP.
DCU kernels leverage ROCm's hipBLAS/rocBLAS and MIOpen just like AMD GPUs,
since Hygon DCU is ROCm-compatible.

Key kernels:
- GEMM/MatMul via hipBLAS (rocBLAS)
- Attention via MIOpen or flash-attention-rocm
- Normalization (RMSNorm, LayerNorm)
- Element-wise and fused operations

Wavefront size note:
  - Hygon gfx906 (Z100): wavefront size = 64
  - Hygon gfx908 (Z100L): wavefront size = 64
"""

from __future__ import annotations

from sagellm_backend.kernels.dcu.attention import DCUAttentionKernel
from sagellm_backend.kernels.dcu.matmul import DCUGemmKernel, DCUMatMulKernel

__all__ = [
    "DCUMatMulKernel",
    "DCUGemmKernel",
    "DCUAttentionKernel",
]
