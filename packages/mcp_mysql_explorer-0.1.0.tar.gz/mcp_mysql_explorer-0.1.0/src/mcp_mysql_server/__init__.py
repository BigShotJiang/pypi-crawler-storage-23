"""MCP MySQL Server — Let AI agents query MySQL databases via Model Context Protocol."""

__version__ = "0.1.0"
