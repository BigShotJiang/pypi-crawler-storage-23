from mcp_mysql_server.server import main

main()
