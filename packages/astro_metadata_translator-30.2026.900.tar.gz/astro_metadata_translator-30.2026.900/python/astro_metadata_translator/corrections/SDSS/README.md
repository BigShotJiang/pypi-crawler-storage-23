# Header Corrections for SDSS data

Files must be in YAML format with name of the form `<instrument>-<observation_id>.yaml`.
See the documentation in `astro_metadata_translator.fix_header`.
