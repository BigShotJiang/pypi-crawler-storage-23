.. rubric:: References

See the literature [#]_ [#]_ [#]_ for SuperNeuroMAT.

.. [#]  `SuperNeuro: A Fast and Scalable Simulator for Neuromorphic Computing <https://doi.org/10.1145/3589737.3606000>`_

.. [#]  `Neuromorphic Computing is Turing-Complete <https://doi.org/10.1145/3546790.3546806>`_

.. [#]  `Computational Complexity of Neuromorphic Algorithms <https://doi.org/10.1145/3477145.3477154>`_