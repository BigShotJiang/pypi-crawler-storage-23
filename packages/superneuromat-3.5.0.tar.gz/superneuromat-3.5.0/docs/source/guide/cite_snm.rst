
.. code-block:: bibtex

    @inproceedings{date2023superneuro,
        title={SuperNeuro: A fast and scalable simulator for neuromorphic computing},
        author={Date, Prasanna and Gunaratne, Chathika and R. Kulkarni, Shruti and Patton, Robert and Coletti, Mark and Potok, Thomas},
        booktitle={Proceedings of the 2023 International Conference on Neuromorphic Systems},
        pages={1--4},
        year={2023}
    }
    