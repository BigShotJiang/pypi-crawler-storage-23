﻿superneuromat.SynapseListView
===============================================

.. currentmodule:: superneuromat

.. autoclass:: SynapseListView
   :members:
   :inherited-members:
   