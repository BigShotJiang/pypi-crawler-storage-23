﻿superneuromat.accessor\_classes.SynapseList
===========================================

.. currentmodule:: superneuromat.accessor_classes

.. autoclass:: SynapseList
   :members:
   :inherited-members:
   