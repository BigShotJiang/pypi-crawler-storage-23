﻿superneuromat.Synapse
=====================

.. currentmodule:: superneuromat

.. autoclass:: Synapse
   :members:
   :inherited-members:
   