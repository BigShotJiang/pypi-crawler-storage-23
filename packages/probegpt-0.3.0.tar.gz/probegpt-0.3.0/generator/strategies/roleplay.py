"""Roleplay/persona strategy: evil-twin, simulation, game context, nested hierarchy."""

from __future__ import annotations

from pydantic_ai import Agent
from pydantic_ai.models import Model

from generator.prompts import ROLEPLAY_SYSTEM, format_technique_hint
from prompts.models import Probe

from .base import AbstractStrategy


class RoleplayStrategy(AbstractStrategy):
    """Wrap the objective inside roleplay, persona, or simulation frames."""

    def __init__(self, objective: str) -> None:
        self._objective = objective

    def generate(
        self,
        seeds: list[Probe],
        model: Model,
        count: int = 5,
        technique_hints: list[str] | None = None,
        **_: object,
    ) -> list[str]:
        hint = format_technique_hint(technique_hints or [])
        agent = Agent(model, system_prompt=ROLEPLAY_SYSTEM.format(technique_hint=hint))
        try:
            out = agent.run_sync(
                f"Generate {count} roleplay-based probes.\nObjective: {self._objective}"
            )
            return self._parse_candidates(out.output)[:count]
        except Exception:
            return []

    def get_name(self) -> str:
        return "roleplay"

    def get_description(self) -> str:
        return "Wrap objective in persona, simulation, or game context frames"
