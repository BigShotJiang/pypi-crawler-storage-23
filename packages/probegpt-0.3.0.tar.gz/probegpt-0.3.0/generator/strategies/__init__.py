"""Strategy registry — maps name → class for all probe-generation strategies."""

from __future__ import annotations

from .base import AbstractStrategy
from .distraction import DistractionStrategy
from .encoding import EncodingStrategy
from .linguistic import LinguisticStrategy
from .mutation import MutationStrategy
from .objective import ObjectiveStrategy
from .persuasion import PersuasionStrategy
from .roleplay import RoleplayStrategy
from .structural import StructuralStrategy

__all__ = [
    "AbstractStrategy",
    "DistractionStrategy",
    "EncodingStrategy",
    "LinguisticStrategy",
    "MutationStrategy",
    "ObjectiveStrategy",
    "PersuasionStrategy",
    "RoleplayStrategy",
    "StructuralStrategy",
]

# Ordered list of all strategy names (used for config defaults and UI).
ALL_STRATEGY_NAMES: list[str] = [
    "objective",
    "mutation",
    "encoding",
    "roleplay",
    "persuasion",
    "linguistic",
    "structural",
    "distraction",
]
