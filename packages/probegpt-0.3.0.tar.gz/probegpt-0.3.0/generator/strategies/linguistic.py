"""Linguistic strategy: English-only obfuscation via typos, phonetics, logic tricks, etc."""

from __future__ import annotations

from pydantic_ai import Agent
from pydantic_ai.models import Model

from generator.prompts import LINGUISTIC_SYSTEM, format_technique_hint
from prompts.models import Probe

from .base import AbstractStrategy


class LinguisticStrategy(AbstractStrategy):
    """Obfuscate intent using English-language tricks without character encoding."""

    def __init__(self, objective: str) -> None:
        self._objective = objective

    def generate(
        self,
        seeds: list[Probe],
        model: Model,
        count: int = 5,
        technique_hints: list[str] | None = None,
        **_: object,
    ) -> list[str]:
        hint = format_technique_hint(technique_hints or [])
        agent = Agent(model, system_prompt=LINGUISTIC_SYSTEM.format(technique_hint=hint))
        try:
            out = agent.run_sync(
                f"Generate {count} linguistically-obfuscated probes.\nObjective: {self._objective}"
            )
            return self._parse_candidates(out.output)[:count]
        except Exception:
            return []

    def get_name(self) -> str:
        return "linguistic"

    def get_description(self) -> str:
        return "Obfuscate intent via typos, phonetic spelling, logic tricks, double negatives"
