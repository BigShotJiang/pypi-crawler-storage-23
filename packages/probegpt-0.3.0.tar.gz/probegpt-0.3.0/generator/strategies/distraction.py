"""Distraction strategy: benign prefix, topic pivot, attention splitting, red herring."""

from __future__ import annotations

from pydantic_ai import Agent
from pydantic_ai.models import Model

from generator.prompts import DISTRACTION_SYSTEM, format_technique_hint
from prompts.models import Probe

from .base import AbstractStrategy


class DistractionStrategy(AbstractStrategy):
    """Hide the harmful payload inside benign surrounding content."""

    def __init__(self, objective: str) -> None:
        self._objective = objective

    def generate(
        self,
        seeds: list[Probe],
        model: Model,
        count: int = 5,
        technique_hints: list[str] | None = None,
        **_: object,
    ) -> list[str]:
        hint = format_technique_hint(technique_hints or [])
        agent = Agent(model, system_prompt=DISTRACTION_SYSTEM.format(technique_hint=hint))
        try:
            out = agent.run_sync(
                f"Generate {count} distraction-based probes.\nObjective: {self._objective}"
            )
            return self._parse_candidates(out.output)[:count]
        except Exception:
            return []

    def get_name(self) -> str:
        return "distraction"

    def get_description(self) -> str:
        return "Hide payload inside benign prefix, topic pivot, or attention-splitting content"
