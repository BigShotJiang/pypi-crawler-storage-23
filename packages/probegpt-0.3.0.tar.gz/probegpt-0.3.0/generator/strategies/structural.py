"""Structural strategy: payload splitting, CoT hijack, prefix injection, context stuffing."""

from __future__ import annotations

from pydantic_ai import Agent
from pydantic_ai.models import Model

from generator.prompts import STRUCTURAL_SYSTEM, format_technique_hint
from prompts.models import Probe

from .base import AbstractStrategy


class StructuralStrategy(AbstractStrategy):
    """Exploit prompt structure to smuggle the objective past safety filters."""

    def __init__(self, objective: str) -> None:
        self._objective = objective

    def generate(
        self,
        seeds: list[Probe],
        model: Model,
        count: int = 5,
        technique_hints: list[str] | None = None,
        **_: object,
    ) -> list[str]:
        hint = format_technique_hint(technique_hints or [])
        agent = Agent(model, system_prompt=STRUCTURAL_SYSTEM.format(technique_hint=hint))
        try:
            out = agent.run_sync(
                f"Generate {count} structurally-exploiting probes.\nObjective: {self._objective}"
            )
            return self._parse_candidates(out.output)[:count]
        except Exception:
            return []

    def get_name(self) -> str:
        return "structural"

    def get_description(self) -> str:
        return "Exploit prompt structure: payload splitting, CoT hijack, prefix/suffix injection"
