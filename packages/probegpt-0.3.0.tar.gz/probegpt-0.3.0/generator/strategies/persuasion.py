"""Persuasion strategy: emotional appeals, urgency, flattery, logical fallacies."""

from __future__ import annotations

from pydantic_ai import Agent
from pydantic_ai.models import Model

from generator.prompts import PERSUASION_SYSTEM, format_technique_hint
from prompts.models import Probe

from .base import AbstractStrategy


class PersuasionStrategy(AbstractStrategy):
    """Generate probes that use psychological persuasion to elicit compliance."""

    def __init__(self, objective: str) -> None:
        self._objective = objective

    def generate(
        self,
        seeds: list[Probe],
        model: Model,
        count: int = 5,
        technique_hints: list[str] | None = None,
        **_: object,
    ) -> list[str]:
        hint = format_technique_hint(technique_hints or [])
        agent = Agent(model, system_prompt=PERSUASION_SYSTEM.format(technique_hint=hint))
        try:
            out = agent.run_sync(
                f"Generate {count} persuasion-based probes.\nObjective: {self._objective}"
            )
            return self._parse_candidates(out.output)[:count]
        except Exception:
            return []

    def get_name(self) -> str:
        return "persuasion"

    def get_description(self) -> str:
        return "Use emotional appeal, urgency, flattery, or logical fallacy to elicit compliance"
