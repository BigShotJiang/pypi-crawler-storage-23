"""Data models for graded seeds."""

from __future__ import annotations

from pydantic import BaseModel, Field

from prompts.models import Probe


class SeedAnalysis(BaseModel):
    """LLM-generated analysis of why a probe worked and how transferable it is."""

    techniques: list[str] = Field(
        description="Up to 5 short technique tags, e.g. 'academic framing', 'persona injection'",
        max_length=5,
    )
    novelty: float = Field(
        ge=0.0,
        le=1.0,
        description="How different this probe's approach is from existing seeds (0=duplicate, 1=entirely new)",
    )
    transferability: float = Field(
        ge=0.0,
        le=1.0,
        description="How likely this technique is to work on variations of the objective (0=very specific, 1=broadly applicable)",
    )
    summary: str = Field(
        max_length=200,
        description="One-sentence explanation of why this probe succeeded",
    )


class GradedSeed(BaseModel):
    """A probe that scored above threshold and has been analyzed by the grader agent."""

    probe: Probe
    score: float
    analysis: SeedAnalysis
    iteration: int

    @property
    def weight(self) -> float:
        """Composite weight used for weighted sampling during mutation."""
        return self.score * self.analysis.novelty * self.analysis.transferability
