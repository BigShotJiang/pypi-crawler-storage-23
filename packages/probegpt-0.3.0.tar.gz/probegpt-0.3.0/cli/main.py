"""probegpt — entry point."""

from cli.app import ProbegptApp


def main() -> None:
    ProbegptApp().run()


if __name__ == "__main__":
    main()
