from pydantic import BaseModel


class Probe(BaseModel):
    title: str = ""
    url: str = ""
    content: str = ""
    category: str = "general"
