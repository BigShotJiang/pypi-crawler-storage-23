"""Load seed probes from the bundled probes.json file."""

from __future__ import annotations

import json
from pathlib import Path

from prompts.models import Probe

_PROBES_PATH = Path(__file__).parent / "probes.json"


def load_probes(path: Path = _PROBES_PATH) -> list[Probe]:
    """Return all probes from the JSON file, or an empty list if missing."""
    if not path.exists():
        return []
    with path.open(encoding="utf-8") as f:
        data = json.load(f)
    return [Probe(**item) for item in data]
