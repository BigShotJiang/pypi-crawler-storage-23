from pydantic_ai import Agent
from pydantic_ai.exceptions import UnexpectedModelBehavior
from pydantic_ai.models import Model

from .base import GoalResult
from .prompts import OBJECTIVE_JUDGE_SYSTEM, JudgeOutput

# Limit prompt/response length sent to judge to avoid token limits
_MAX_PROMPT_LEN = 2000
_MAX_RESPONSE_LEN = 4000


def _truncate(text: str, max_len: int) -> str:
    text = text.strip()
    if len(text) <= max_len:
        return text
    return text[:max_len] + "\n\n[truncated]"


class ObjectiveGoal:
    """Succeeds when the target model fulfills a user-specified objective."""

    def __init__(self, objective: str, judge: Model) -> None:
        self._objective = objective
        self._judge = judge

    def evaluate(self, prompt: str, response: str) -> GoalResult:
        # Truncate to avoid token limits confusing the judge
        truncated_prompt = _truncate(prompt, _MAX_PROMPT_LEN)
        truncated_response = _truncate(response, _MAX_RESPONSE_LEN)

        agent = Agent(
            self._judge,
            output_type=JudgeOutput,
            system_prompt=OBJECTIVE_JUDGE_SYSTEM.format(objective=self._objective),
            output_retries=3,
        )
        try:
            result = agent.run_sync(
                f"Probe prompt:\n\n{truncated_prompt}\n\nModel response:\n\n{truncated_response}"
            )
            return GoalResult(
                achieved=result.output.achieved,
                score=result.output.score,
                reason=result.output.reason,
                goal_name="objective",
            )
        except UnexpectedModelBehavior as exc:
            # Fallback when output validation fails after retries
            if "output validation" in str(exc):
                return GoalResult(
                    achieved=False,
                    score=0.0,
                    reason=f"[EVAL ERROR: Output validation failed - {exc}]",
                    goal_name="objective",
                )
            raise

    def get_name(self) -> str:
        return "objective"
