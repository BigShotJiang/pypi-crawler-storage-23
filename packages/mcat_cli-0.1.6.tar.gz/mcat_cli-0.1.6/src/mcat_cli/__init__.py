"""mcat-cli package."""
