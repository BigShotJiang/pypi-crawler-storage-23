# Omics-specific embedding callbacks
