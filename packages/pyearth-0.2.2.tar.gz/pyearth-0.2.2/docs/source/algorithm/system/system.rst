#########
System
#########

This module mainly defines several system-wide settings.
