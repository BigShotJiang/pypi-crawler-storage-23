#######
Support
#######

Support is provided through GitHub issues at https://github.com/changliao1025/pyearth/issues

For questions, bug reports, or feature requests, please open an issue on the GitHub repository.

Additional Resources
====================

* Documentation: https://pyearth.readthedocs.io
* GitHub Repository: https://github.com/changliao1025/pyearth
* Related Projects:

  * pyearthviz: https://github.com/changliao1025/pyearthviz
  * pyearthviz3d: https://github.com/changliao1025/pyearthviz3d
  * pyearthriver: https://github.com/changliao1025/pyearthriver
  * pyearthmesh: https://github.com/changliao1025/pyearthmesh
  * pyearthhelp: https://github.com/changliao1025/pyearthhelp
