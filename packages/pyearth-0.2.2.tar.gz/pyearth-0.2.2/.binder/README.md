# MyBinder Configuration

This directory contains configuration files for running PyEarth notebooks on MyBinder.

## Files:
- `environment.yml`: Conda environment specification with all required dependencies

## Usage:
Click the Binder badge in the main README to launch an interactive notebook environment.
