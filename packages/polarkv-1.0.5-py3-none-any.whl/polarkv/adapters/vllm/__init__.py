"""
PolarKV adapter for vLLM KV Connector

Usage:
    --kv-connector PolarKVCache
    --kv-connector-config '{
        "connector_path": "polarkv.adapters.vllm",
        "class_name": "PolarKVCache",
        "config_file": "/path/to/config.yaml"
    }'
"""

from polarkv.adapters.vllm.pdkp import PDKPConnector

PolarKVCache = PDKPConnector

__all__ = ["PolarKVCache", "PDKPConnector"]
