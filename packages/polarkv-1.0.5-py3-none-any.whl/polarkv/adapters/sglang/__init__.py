"""
PolarKV adapter for SGLang HiCache

Usage:
    --hicache-storage-backend-extra-config '{
        "backend_name": "polarkv",
        "module_path": "polarkv.adapters.sglang",
        "class_name": "PolarKVCache",
        "polarkv_config_file": "/path/to/config.yaml"
    }'
"""

from polarkv.adapters.sglang.pdkp import PDKPStore

PolarKVCache = PDKPStore

__all__ = ["PolarKVCache", "PDKPStore"]
