"""
PolarKV - Distributed KVCache storage backend for LLM inference

Supports both SGLang and vLLM frameworks.

Usage:
    # SGLang
    from polarkv.sglang import PDKPStore

    # vLLM
    from polarkv.vllm import PDKPConnector
"""

__version__ = "1.0.4"

__all__ = ["__version__"]
