"""Pydantic models for health check results."""

from __future__ import annotations

import enum
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class ComponentStatus(str, enum.Enum):
    """Tri-state health status for a component."""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


class HealthStatus(str, enum.Enum):
    """Overall system health status."""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


class ComponentHealth(BaseModel):
    """Health report for a single component."""

    name: str = Field(..., description="Unique component identifier, e.g. 'vectorstore.milvus'")
    status: ComponentStatus = Field(default=ComponentStatus.UNKNOWN)
    latency_ms: float = Field(default=0.0, description="Latency of the last health check in milliseconds")
    last_checked: Optional[datetime] = Field(default=None, description="UTC timestamp of last check")
    error: Optional[str] = Field(default=None, description="Error message if unhealthy")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Component-specific details")

    @property
    def is_healthy(self) -> bool:
        return self.status == ComponentStatus.HEALTHY


class SystemHealth(BaseModel):
    """Aggregated health report for the entire system."""

    status: HealthStatus = Field(default=HealthStatus.HEALTHY)
    components: List[ComponentHealth] = Field(default_factory=list)
    checked_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    version: str = Field(default="unknown")

    @property
    def unhealthy_components(self) -> List[ComponentHealth]:
        return [c for c in self.components if c.status == ComponentStatus.UNHEALTHY]

    @property
    def degraded_components(self) -> List[ComponentHealth]:
        return [c for c in self.components if c.status == ComponentStatus.DEGRADED]
