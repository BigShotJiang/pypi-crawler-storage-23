"""Health registry -- aggregated health monitoring with background checking.

Pattern mirrors :class:`agentfoundry.cancellation.RequestTracker`:
thread-safe singleton with ``threading.Lock`` guarding mutable state.
"""

from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timezone
from typing import Callable, Dict, List, Optional

from agentfoundry.health.models import (
    ComponentHealth,
    ComponentStatus,
    HealthStatus,
    SystemHealth,
)
from agentfoundry.health.protocol import HealthCheckable

logger = logging.getLogger(__name__)

# Type alias for status change callbacks.
# Signature: callback(previous_health, new_health)
StatusChangeCallback = Callable[[ComponentHealth, ComponentHealth], None]


class HealthRegistry:
    """Global registry of health-checkable components.

    Thread-safe singleton.  Instantiate freely -- all instances share state.
    """

    _instance: Optional[HealthRegistry] = None
    _init_lock = threading.Lock()

    def __new__(cls) -> HealthRegistry:
        with cls._init_lock:
            if cls._instance is None:
                inst = super().__new__(cls)
                inst._components: Dict[str, HealthCheckable] = {}
                inst._cache: Dict[str, ComponentHealth] = {}
                inst._callbacks: List[StatusChangeCallback] = []
                inst._lock = threading.Lock()
                inst._bg_thread: Optional[threading.Thread] = None
                inst._bg_stop = threading.Event()
                inst._bg_interval: float = 30.0
                inst._check_timeout: float = 5.0
                cls._instance = inst
            return cls._instance

    # ------------------------------------------------------------------
    # Component registration
    # ------------------------------------------------------------------

    def register(self, component: HealthCheckable, name: str | None = None) -> None:
        """Register a component for health monitoring.

        Args:
            component: Object implementing HealthCheckable.
            name: Override name.  Defaults to ``component.health_component_name``.
        """
        key = name or component.health_component_name
        with self._lock:
            self._components[key] = component
        logger.info("HealthRegistry: registered component '%s'", key)

    def unregister(self, name: str) -> None:
        """Remove a component from monitoring."""
        with self._lock:
            self._components.pop(name, None)
            self._cache.pop(name, None)
        logger.debug("HealthRegistry: unregistered component '%s'", name)

    # ------------------------------------------------------------------
    # Observer pattern for status change notifications
    # ------------------------------------------------------------------

    def on_status_change(self, callback: StatusChangeCallback) -> None:
        """Register a callback invoked when any component status changes.

        Callback signature: ``callback(previous: ComponentHealth, current: ComponentHealth)``
        Called from the background check thread.  Callbacks must be thread-safe
        and non-blocking.
        """
        with self._lock:
            self._callbacks.append(callback)

    def remove_callback(self, callback: StatusChangeCallback) -> None:
        """Remove a previously registered callback."""
        with self._lock:
            try:
                self._callbacks.remove(callback)
            except ValueError:
                pass

    def _notify(self, previous: ComponentHealth, current: ComponentHealth) -> None:
        """Fire status change callbacks.  Best-effort -- exceptions are logged."""
        with self._lock:
            cbs = list(self._callbacks)
        for cb in cbs:
            try:
                cb(previous, current)
            except Exception:
                logger.warning(
                    "HealthRegistry: callback %r raised an exception",
                    cb,
                    exc_info=True,
                )

    # ------------------------------------------------------------------
    # Health checking (on-demand)
    # ------------------------------------------------------------------

    def check_component(self, name: str, *, timeout: float | None = None) -> ComponentHealth:
        """Run a health check for a single registered component.

        Updates the cache and fires callbacks if status changed.
        """
        with self._lock:
            component = self._components.get(name)
        if component is None:
            return ComponentHealth(
                name=name,
                status=ComponentStatus.UNKNOWN,
                error=f"Component '{name}' is not registered",
                last_checked=datetime.now(timezone.utc),
            )
        t = timeout if timeout is not None else self._check_timeout
        health = component.check_health(timeout=t)
        self._update_cache(name, health)
        return health

    def check_all(self, *, timeout: float | None = None) -> SystemHealth:
        """Run health checks for all registered components and return aggregated result."""
        with self._lock:
            names = list(self._components.keys())

        results: List[ComponentHealth] = []
        for name in names:
            result = self.check_component(name, timeout=timeout)
            results.append(result)

        return self._aggregate(results)

    def get_cached_health(self) -> SystemHealth:
        """Return the most recently cached health for all components.

        If no background checks have run, returns UNKNOWN for all.
        """
        with self._lock:
            results = list(self._cache.values())
        return self._aggregate(results)

    def _update_cache(self, name: str, health: ComponentHealth) -> None:
        """Update the cache and fire callbacks if status changed."""
        with self._lock:
            previous = self._cache.get(name)
            self._cache[name] = health
        if previous is not None and previous.status != health.status:
            logger.info(
                "HealthRegistry: status change for '%s': %s -> %s",
                name,
                previous.status.value,
                health.status.value,
            )
            self._notify(previous, health)

    @staticmethod
    def _aggregate(results: List[ComponentHealth]) -> SystemHealth:
        """Compute overall system health from component results."""
        try:
            from agentfoundry import __version__
        except Exception:
            __version__ = "unknown"

        if not results:
            return SystemHealth(
                status=HealthStatus.HEALTHY,
                components=[],
                version=__version__,
            )

        has_unhealthy = any(c.status == ComponentStatus.UNHEALTHY for c in results)
        has_degraded = any(c.status == ComponentStatus.DEGRADED for c in results)

        if has_unhealthy:
            overall = HealthStatus.UNHEALTHY
        elif has_degraded:
            overall = HealthStatus.DEGRADED
        else:
            overall = HealthStatus.HEALTHY

        return SystemHealth(
            status=overall,
            components=results,
            checked_at=datetime.now(timezone.utc),
            version=__version__,
        )

    # ------------------------------------------------------------------
    # Background periodic checking
    # ------------------------------------------------------------------

    def start_background_checks(
        self,
        interval: float = 30.0,
        timeout: float = 5.0,
    ) -> None:
        """Start a daemon thread that periodically runs all health checks.

        Args:
            interval: Seconds between check cycles.
            timeout: Per-component check timeout.
        """
        with self._lock:
            if self._bg_thread is not None and self._bg_thread.is_alive():
                logger.info("HealthRegistry: background checks already running")
                return
            self._bg_interval = interval
            self._check_timeout = timeout
            self._bg_stop.clear()

        thread = threading.Thread(
            target=self._bg_loop,
            name="HealthRegistryBG",
            daemon=True,
        )
        with self._lock:
            self._bg_thread = thread
        thread.start()
        logger.info(
            "HealthRegistry: background checks started (interval=%.1fs, timeout=%.1fs)",
            interval,
            timeout,
        )

    def stop_background_checks(self) -> None:
        """Signal the background thread to stop."""
        self._bg_stop.set()
        with self._lock:
            t = self._bg_thread
        if t is not None:
            t.join(timeout=self._bg_interval + 2)
        logger.info("HealthRegistry: background checks stopped")

    def _bg_loop(self) -> None:
        """Background loop -- runs check_all periodically."""
        while not self._bg_stop.is_set():
            try:
                self.check_all(timeout=self._check_timeout)
            except Exception:
                logger.warning("HealthRegistry: background check cycle failed", exc_info=True)
            self._bg_stop.wait(timeout=self._bg_interval)

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @property
    def registered_components(self) -> List[str]:
        with self._lock:
            return list(self._components.keys())
