"""AgentFoundry exception hierarchy.

All public exceptions inherit from :class:`AgentFoundryError` so callers can
use a single ``except AgentFoundryError`` clause to catch any library error.

The intermediate classes also inherit from stdlib types (``ValueError``,
``RuntimeError``) to preserve backward compatibility with existing catch
clauses written before the custom hierarchy existed.
"""

__author__ = "Chris Steel"
__copyright__ = "Copyright 2025, Syntheticore Corporation"
__credits__ = ["Chris Steel"]
__date__ = "2/21/2025"
__license__ = "Syntheticore Confidential"
__version__ = "1.0"
__email__ = "csteel@syntheticore.com"
__status__ = "Production"


class AgentFoundryError(Exception):
    """Base exception for all AgentFoundry errors."""


class ConfigurationError(AgentFoundryError, ValueError):
    """Missing or invalid configuration."""


class ProviderError(AgentFoundryError, RuntimeError):
    """A backend provider (LLM, vector store, knowledge graph, etc.) failed."""


class VectorStoreError(ProviderError):
    """Vector-store–specific failure."""


class InitializationError(ProviderError):
    """A backend failed connectivity verification during initialization."""

    def __init__(self, component: str, message: str, cause: Exception | None = None):
        self.component = component
        full_msg = f"[{component}] {message}"
        super().__init__(full_msg)
        if cause:
            self.__cause__ = cause


class FatalInitializationError(BaseException):
    """A backend failed connectivity and the system cannot start.

    Inherits from BaseException (NOT Exception) so generic
    ``except Exception`` clauses cannot catch it.  Apps must
    catch it explicitly by name.
    """

    def __init__(self, component: str, message: str, cause: Exception | None = None):
        self.component = component
        full_msg = f"FATAL: [{component}] initialization failed — {message}"
        super().__init__(full_msg)
        if cause:
            self.__cause__ = cause
