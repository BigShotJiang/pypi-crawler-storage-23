import logging
from typing import Any
from carestack.fhir.fhir_dto import Base64Document, ProcessedDocumentResponse
from carestack.base.base_service import BaseService
from carestack.base.base_types import ClientConfig
from carestack.base.errors import EhrApiError
from carestack.common.enums import FHIR_ENDPOINTS


class FhirService(BaseService):
    def __init__(self, config: ClientConfig):
        super().__init__(config)
        self.logger = logging.getLogger(__name__)

    async def create_bundles(self, files: list[Base64Document]) -> ProcessedDocumentResponse:
        """
        Classifies one or more documents and generates a FHIR bundle from the result.

        This method sends base64 encoded documents to the classification service,
        which identifies the document type, extracts clinical data, and generates
        a FHIR-compliant bundle in a single operation.

        Args:
            files (list[Base64Document]): A list of documents to classify, each
                containing fileName, base64 data, and mimeType.

        Returns:
            ProcessedDocumentResponse: The generated FHIR-compliant bundle.

        Raises:
            EhrApiError: If no files are provided, or if the API call fails.
        """
        self.logger.info(f"Starting document classification for {len(files)} files.")
        if not files:
            raise EhrApiError("No files provided for classification.", 400)

        try:
            files_payload = [
                (Base64Document(**file) if isinstance(file, dict) else file).model_dump(by_alias=True) for file in files
            ]


            bundles = await self.post(
                FHIR_ENDPOINTS.GENERATE_FHIR_BUNDLE,
                {"files": files_payload},
                response_model=ProcessedDocumentResponse,
            )
            return bundles
        except EhrApiError as e:
            self.logger.error("API error during document classification: %s", e.message, exc_info=True)
            raise
        except Exception as error:
            self.logger.error("Unexpected error during document classification: %s", error, exc_info=True)
            raise EhrApiError(f"Failed to classify document: {error}", 500) from error
