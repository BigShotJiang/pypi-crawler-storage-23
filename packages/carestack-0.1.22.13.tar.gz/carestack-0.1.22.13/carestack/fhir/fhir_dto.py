from typing import Any, Dict, List
from pydantic import BaseModel, ConfigDict, Field


class Base64Document(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    file_name: str = Field(..., alias="fileName")
    data: str
    mime_type: str = Field(..., alias="mimeType")


class ProcessedDocument(BaseModel):
    type: str
    fhir: Dict[str, Any]


class ProcessedDocumentResponse(BaseModel):
    documents: List[ProcessedDocument]