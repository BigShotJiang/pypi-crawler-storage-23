import pytest

# Re-export fixtures from existing test helper module so pytest discovers them.
from carestack.common.config_test import client_config  # noqa: F401
