"""CLI for OpenArtemis — Claude-like, user-friendly design."""

import json
import logging
import os
import re
import subprocess
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from openartemis.config import load_config

load_config()

# Reduce harvester log noise so Rich output stays clean
logging.getLogger("openartemis").setLevel(logging.WARNING)

import questionary
import typer
from prompt_toolkit.key_binding.key_bindings import KeyBindings as PtKeyBindings
from prompt_toolkit.key_binding.key_bindings import merge_key_bindings
from prompt_toolkit.keys import Keys
from prompt_toolkit.styles import Style as PtStyle
from rich.console import Console

# Select prompts: only the pointed row (highlighted) gets the visible bar; "selected" = default-matched row, force plain so highlight follows pointer
_QUESTIONARY_SELECT_STYLE = PtStyle.from_dict({
    "highlighted": "bold fg:white bg:ansicyan",
    "selected": "noreverse",
    "pointer": "bold fg:ansicyan",
})
_QUESTIONARY_SELECT_OPTS = {
    "use_arrow_keys": True,
    "use_jk_keys": False,
    "instruction": "(Use arrow keys)",
    "style": _QUESTIONARY_SELECT_STYLE,
}


def _select_with_swapped_arrows(message: str, choices: list, default: str | None, **opts) -> str | None:
    """Run a questionary select but swap Up/Down key bindings (fixes inverted arrows on Windows/some terminals)."""
    q = questionary.select(message, choices=choices, default=default, **opts)
    kb = q.application.key_bindings
    up_handler = down_handler = None
    for b in kb.bindings:
        if b.keys == (Keys.Up,):
            up_handler = b.handler
        elif b.keys == (Keys.Down,):
            down_handler = b.handler
    if up_handler is not None and down_handler is not None:
        # Application key_bindings can be merged (read-only); prepend a swap layer so it takes precedence.
        swap_kb = PtKeyBindings()
        swap_kb.add(Keys.Up, eager=True)(down_handler)
        swap_kb.add(Keys.Down, eager=True)(up_handler)
        q.application.key_bindings = merge_key_bindings([swap_kb, kb])
    return q.ask()
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.tree import Tree

from openartemis.auth import (
    init_db,
    get_user_count,
    create_admin,
    reset_admin_password,
    get_session_user,
    create_session,
    revoke_session,
    login,
    redeem_invite_code,
    create_invite_code,
    create_chat_session,
    get_chat_sessions,
    get_chat_messages,
    search_chat_sessions,
    update_chat_session_title,
)
from openartemis.harvesters.social import SocialHarvester
from openartemis.harvesters.youtube import YouTubeHarvester
from openartemis.console_utils import chat_list_line as _chat_list_line
from openartemis.slash_commands import SLASH_REGISTRY, _register_builtins

app = typer.Typer(
    name="openartemis",
    help="Harvest transcripts from YouTube, TikTok, Instagram, and X. User-friendly, no coding required.",
    add_completion=False,
)
console = Console()

VALID_PLATFORMS = ["youtube", "tiktok", "instagram", "x"]


def _make_stream_callback(console: Console):
    """Return (callback, flush) for word-wrapped streamed output. Call flush() after send() returns."""
    buffer: list[str] = []
    width = getattr(console.size, "width", 80) or 80

    def callback(t: str) -> None:
        buffer.append(t)
        s = "".join(buffer)
        while s:
            if "\n" in s:
                idx = s.index("\n")
                line, s = s[:idx], s[idx + 1 :]
                console.print(line)
                buffer.clear()
                buffer.append(s)
                return
            if len(s) > width:
                chunk = s[: width + 1]
                last_space = chunk.rfind(" ")
                if last_space > 0:
                    line, s = s[:last_space], s[last_space + 1 :].lstrip()
                else:
                    line, s = s[:width], s[width:]
                console.print(line)
                buffer.clear()
                buffer.append(s)
                return
            return

    def flush() -> None:
        remainder = "".join(buffer)
        if remainder:
            console.print(remainder)
        buffer.clear()

    return callback, flush


WHISPER_MODELS = ["tiny", "base", "small", "medium", "large"]


def _welcome(chat: bool = False, model: str | None = None) -> None:
    """Print welcome banner."""
    try:
        from importlib.metadata import version
        ver = version("openartemis")
    except Exception:
        try:
            from openartemis import __version__
            ver = __version__
        except Exception:
            ver = "0.2.13"
    if chat:
        model_line = f"  Model: [cyan]{model or 'Artemis-1-Mini'}[/cyan] (type [bold]/model[/bold] to change)\n" if model else ""
        banner = f"""
[bold cyan]OpenArtemis[/bold cyan] — Chat with [bold]Artemis[/bold]  [dim]v{ver}[/dim]
{model_line}
  • Ask anything — Artemis will help
  • Say "research X" for in-depth answers
  • Type [bold]/[/bold] for menu • [bold]agent-status[/bold] or [bold]/agent-status[/bold] to check agent progress
"""
    else:
        banner = """
[bold cyan]OpenArtemis[/bold cyan] — Find videos and get their text

  • Search YouTube, TikTok, Instagram, X
  • Save as text files
"""
    console.print(Panel(banner.strip(), border_style="cyan", padding=(1, 2)))


def _run_harvest(
    query: str,
    platforms: list[str],
    max_results: int,
    out_dir: Path,
    youtube_api_key: str | None,
    scrapingdog_api_key: str | None,
    whisper_model: str,
) -> int:
    """Run the harvest pipeline. Returns total posts harvested."""
    total = 0
    out_dir = out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    transcriptapi_key = os.environ.get("TRANSCRIPTAPI_API_KEY")
    for platform in platforms:
        if platform == "youtube":
            if not youtube_api_key and not transcriptapi_key:
                console.print(
                    "[red]YouTube requires an API key.[/red] Set [bold]YOUTUBE_API_KEY[/bold] (Google) "
                    "or [bold]TRANSCRIPTAPI_API_KEY[/bold] (TranscriptAPI.com). Skipping YouTube."
                )
                continue
            harvester = YouTubeHarvester(
                api_key=youtube_api_key,
                scrapingdog_api_key=scrapingdog_api_key,
                transcriptapi_api_key=transcriptapi_key,
            )
        else:
            harvester = SocialHarvester(platform=platform)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task(f"Harvesting [cyan]{platform}[/cyan]...", total=None)
            count = 0
            for _ in harvester.harvest(
                query=query,
                max_results=max_results,
                out_dir=out_dir,
                whisper_model=whisper_model,
            ):
                count += 1
                total += 1
            progress.update(task, description=f"[green]✓[/green] {platform}: {count} posts")

    return total


def _interactive_mode() -> None:
    """Run in interactive mode — guided prompts for non-coders."""
    _welcome()

    try:
        query = questionary.text(
            "What would you like to find out?",
            default="",
            instruction="(e.g. mr beast, cooking tutorial, news clip)",
        ).ask()
        if not query or not query.strip():
            console.print(
                "[yellow]No query entered.[/yellow]\n"
                "[dim]Tip: Try again with something you'd like to find out about.[/dim]"
            )
            raise typer.Exit(1)

        platform_choices = [
            questionary.Choice("YouTube", value="youtube"),
            questionary.Choice("TikTok", value="tiktok"),
            questionary.Choice("Instagram", value="instagram"),
            questionary.Choice("X (Twitter)", value="x"),
        ]
        platforms = questionary.checkbox(
            "Which platforms do you want to search?",
            choices=platform_choices,
            default=["youtube"],  # YouTube selected by default (list of values, not Choice objects)
        ).ask()
        if not platforms:
            console.print("[yellow]No platforms selected. Exiting.[/yellow]")
            raise typer.Exit(1)

        max_results_str = questionary.text(
            "How many results per platform?",
            default="5",
        ).ask()
        try:
            max_results = int(max_results_str or "5")
        except ValueError:
            max_results = 5

        out_dir_str = questionary.path(
            "Where should we save the transcripts?",
            default="./transcripts",
        ).ask()
        out_dir = Path(out_dir_str or "./transcripts")

        youtube_api_key = os.environ.get("YOUTUBE_API_KEY")
        scrapingdog_api_key = os.environ.get("SCRAPINGDOG_API_KEY")

        if "youtube" in platforms and not youtube_api_key:
            youtube_api_key = questionary.password(
                "YouTube Data API key (get one at console.cloud.google.com):",
            ).ask()
            if not youtube_api_key:
                console.print("[yellow]YouTube skipped — no API key.[/yellow]")
                platforms = [p for p in platforms if p != "youtube"]

        console.print()
        console.print(Panel(
            f"[bold]Query:[/bold] {query}\n"
            f"[bold]Platforms:[/bold] {', '.join(platforms)}\n"
            f"[bold]Max results:[/bold] {max_results}\n"
            f"[bold]Output:[/bold] {out_dir}",
            title="Starting harvest",
            border_style="green",
        ))
        console.print()

        total = _run_harvest(
            query=query,
            platforms=platforms,
            max_results=max_results,
            out_dir=out_dir,
            youtube_api_key=youtube_api_key or None,
            scrapingdog_api_key=scrapingdog_api_key or None,
            whisper_model="base",
        )

        console.print()
        console.print(Panel(
            f"[bold green]Done![/bold green]\n\n"
            f"Harvested [bold]{total}[/bold] posts.\n"
            f"Saved to: [cyan]{out_dir}[/cyan]",
            title="Success",
            border_style="green",
        ))
    except (KeyboardInterrupt, EOFError):
        console.print("\n[yellow]Cancelled.[/yellow]")
        raise typer.Exit(0)


AGENT_OUTPUT_DIR = Path.home() / ".openartemis" / "agent_output"


def _agent_output_path(request: str) -> Path:
    """Generate output path for agent report."""
    safe = re.sub(r"[^\w\s-]", "", request)[:40].strip() or "task"
    safe = re.sub(r"[-\s]+", "_", safe)
    ts = datetime.now().strftime("%Y-%m-%d_%H-%M")
    return AGENT_OUTPUT_DIR / f"{ts}_{safe}.md"


def _run_agent_foreground(req: str) -> None:
    """Run agent in foreground with progress."""
    from openartemis.agent.agent_orchestrator import run_agent_mode

    output_path = _agent_output_path(req)
    status_log: list[str] = []
    max_log_lines = 3
    progress_ref = None
    task_id = None

    def on_status(s: str) -> None:
        status_log.append(s)
        if len(status_log) > max_log_lines:
            status_log.pop(0)
        if progress_ref is not None and task_id is not None:
            short = s[:55] + ("..." if len(s) > 55 else "")
            progress_ref.update(task_id, description=f"[dim]Agent: {short}[/dim]")

    try:
        console.print("[dim]This may take a while. You can leave it running.[/dim]\n")
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
            progress_ref = progress
            task_id = progress.add_task("Agent: Creating plan...", total=None)
            report = run_agent_mode(req, on_status=on_status, output_path=output_path)
            progress.update(task_id, description="[green]Done[/green]")
        if status_log:
            console.print("[dim]Recent:[/dim]")
            for line in status_log:
                console.print(f"  [dim]→ {line}[/dim]")
        console.print()
        console.print(Panel(Markdown(report or "(no output)"), title="[green]Agent Report[/green]", border_style="green"))
        console.print(f"[dim]Saved to {output_path}[/dim]")
        console.print("[dim]Workspace: ~/.openartemis/agent_workspace/[/dim]\n")
    except Exception as e:
        console.print(f"[red]Failed: {e}[/red]")


def _run_agent_background(req: str) -> None:
    """Run agent in background subprocess."""
    output_path = _agent_output_path(req)
    AGENT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    # Write pending marker
    (AGENT_OUTPUT_DIR / f"{output_path.name}.running").write_text(req, encoding="utf-8")
    cmd = [sys.executable, "-m", "openartemis", "agent-run", req, str(output_path)]
    if sys.platform == "win32":
        subprocess.Popen(
            cmd,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            cwd=os.getcwd(),
        )
    else:
        subprocess.Popen(
            cmd,
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            cwd=os.getcwd(),
        )
    console.print(Panel(
        f"[green]Agent started in background.[/green]\n\n"
        f"Results will be saved to:\n[cyan]{output_path}[/cyan]\n\n"
        f"Run [bold]openartemis agent-status[/bold] to check progress.",
        title="Background Task",
        border_style="green",
    ))


DECISIVE_BUILD_PLAN_PROMPT = """The user wants to build: {user_request}

Here is research about how to build it:
{research_report}

Commit to ONE stack only (e.g. "Vanilla Canvas in a single index.html", "Phaser 3 + Vite", "Pygame"). Do not list alternatives.
Output a short, concrete build plan:
1. State the chosen stack in one sentence.
2. List exact steps and the exact files to create (e.g. index.html, game.js, style.css). Use bullets or numbers.
Keep it concise and build-ready."""


def _get_decisive_build_plan(user_request: str, research_report: str) -> str:
    """One LLM call: turn research into a committed one-stack build plan with exact steps/files."""
    try:
        from openai import OpenAI
        from openartemis.config import resolve_artemis_model
        client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
        if not client.api_key:
            return research_report
        model = resolve_artemis_model("artemis-1")
        resp = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "user", "content": DECISIVE_BUILD_PLAN_PROMPT.format(
                    user_request=user_request,
                    research_report=(research_report or "")[:4000],
                )},
            ],
        )
        return (resp.choices[0].message.content or "").strip() or research_report
    except Exception:
        return research_report


def _ask_spec_questions() -> str:
    """Ask 2-3 build spec questions; return a short spec string to append to the request."""
    art = questionary.select(
        "Art style:",
        choices=[
            questionary.Choice("Simple shapes (rectangles/circles)", value="simple shapes"),
            questionary.Choice("Sprites/images", value="sprites"),
        ],
    ).ask() or "simple shapes"
    physics = questionary.select(
        "Physics feel:",
        choices=[
            questionary.Choice("Floatier (slower tap response)", value="floaty"),
            questionary.Choice("Snappier (quick response)", value="snappy"),
        ],
    ).ask() or "snappy"
    auto_open = questionary.confirm(
        "Auto-launch local server and open in browser when done?",
        default=True,
    ).ask()
    return f"Spec: Art style: {art}. Physics: {physics}. Auto-open in browser: {'yes' if auto_open else 'no'}."


def _chat_title_from_task(req: str) -> str:
    """Generate a short chat title from an agent task request."""
    s = req.strip()
    for prefix in ("make me ", "build ", "create ", "make ", "build me ", "create me "):
        if s.lower().startswith(prefix):
            s = s[len(prefix):].strip()
            break
    s = s[:40].strip() or "Agent task"
    return (s[0].upper() + s[1:]) + " request" if s else "Agent task request"


def _run_research_with_live(
    pipeline: Any,
    query: str,
    on_tool_call: Any = None,
    approve_phases: bool | None = None,
) -> str:
    """Run research pipeline with Live stage/progress/log display. Returns report or raises.
    If approve_phases is True (e.g. OPENARTEMIS_APPROVE_PHASES=1), runs in main thread and asks
    for confirmation after each phase (plan, gather)."""
    if approve_phases is None:
        approve_phases = os.environ.get("OPENARTEMIS_APPROVE_PHASES", "").strip().lower() in ("1", "true", "yes")
    state: dict = {
        "stage": "Planning…",
        "tasks_done": 0,
        "total_tasks": 0,
        "sources": 0,
        "log": [],
        "report": None,
        "done": False,
        "error": None,
    }

    def on_stage(s: str) -> None:
        state["stage"] = s

    def on_plan_done(n: int) -> None:
        state["total_tasks"] = n

    def on_task_done(_tid: int, sources_count: int) -> None:
        state["tasks_done"] = state.get("tasks_done", 0) + 1
        state["sources"] = sources_count

    def on_log(msg: str) -> None:
        ts = datetime.now().strftime("%H:%M:%S")
        state["log"] = (state.get("log") or []) + [(ts, msg)]
        state["log"] = state["log"][-12:]

    def approve_before_phase(phase: str) -> bool:
        return bool(questionary.confirm(f"Phase '{phase}' done. Continue to next phase?", default=True).ask())

    run_kw: dict[str, Any] = {
        "on_tool_call": on_tool_call,
        "on_stage": on_stage,
        "on_plan_done": on_plan_done,
        "on_task_done": on_task_done,
        "on_log": on_log,
    }
    if approve_phases:
        run_kw["approve_before_phase"] = approve_before_phase

    if approve_phases:
        try:
            return pipeline.run(query, **run_kw) or "(no report)"
        except Exception as e:
            raise
    else:
        def run_in_thread() -> None:
            try:
                state["report"] = pipeline.run(query, **run_kw)
            except Exception as e:
                state["error"] = e
            finally:
                state["done"] = True

        def render() -> Panel:
            stage = state.get("stage", "…")
            total = state.get("total_tasks") or 1
            done = state.get("tasks_done", 0)
            sources = state.get("sources", 0)
            phases = [
                "[green]Plan ✓[/green]" if stage != "Planning…" else "[bold]Planning…[/bold]",
                f"[green]Gather {done}/{total} ✓[/green]" if stage not in ("Planning…", "Gathering…") else (f"[bold]Gathering {done}/{total}[/bold]" if stage == "Gathering…" else "Gather"),
                "[green]Verify ✓[/green]" if stage not in ("Planning…", "Gathering…", "Verifying…") else ("[bold]Verifying…[/bold]" if stage == "Verifying…" else "Verify"),
                "[green]Synthesize ✓[/green]" if stage == "Done" else ("[bold]Synthesizing…[/bold]" if stage == "Synthesizing…" else "Synthesize"),
            ]
            phase_line = "  →  ".join(phases)
            src_line = f"[dim]{sources} sources scanned[/dim]" if sources else ""
            log_lines = state.get("log") or []
            log_text = "\n".join(f"  [dim]{ts}[/dim] {msg}" for ts, msg in log_lines[-6:])
            body = f"{phase_line}\n\n{src_line}\n\n[dim]Log:[/dim]\n{log_text or '  —'}"
            return Panel(body, title=f"[cyan]Deep Research[/cyan] — {stage}", border_style="cyan")

        thread = threading.Thread(target=run_in_thread, daemon=False)
        thread.start()
        try:
            with Live(render(), console=console, refresh_per_second=2) as live:
                while not state["done"]:
                    time.sleep(0.25)
                    live.update(render())
        except KeyboardInterrupt:
            state["error"] = KeyboardInterrupt()
        thread.join(timeout=0.5)
        if state.get("error"):
            raise state["error"]
        return state.get("report") or "(no report)"


def _ask_agent_workspace_path() -> Path | None:
    """Ask user where the project should live (pick folder or paste path). Returns resolved Path or None."""
    method = questionary.select(
        "Where should the project live?",
        choices=[
            questionary.Choice("Pick folder (navigate)", value="pick"),
            questionary.Choice("Paste folder path", value="paste"),
        ],
        default="pick",
    ).ask()
    if not method:
        return None
    path_str: str | None = None
    if method == "pick":
        path_str = questionary.path("Select folder:", only_directories=True).ask()
    else:
        path_str = questionary.text(
            "Paste folder path (e.g. C:\\Dev\\MyGame or ~/projects/myapp):"
        ).ask()
    if not path_str or not path_str.strip():
        return None
    resolved = Path(path_str.strip().expanduser()).resolve()
    if not resolved.exists():
        if questionary.confirm(f"Create folder at {resolved}?", default=True).ask():
            resolved.mkdir(parents=True, exist_ok=True)
        else:
            return None
    if not resolved.is_dir():
        console.print("[red]Path is not a directory.[/red]")
        return None
    return resolved


def _run_agent_mode_flow(session: Any = None) -> None:
    """Run Agent Mode: Plan, Agent, or Ask. If session is provided, set chat title when a task is run."""
    from openartemis.agent.agent_tools import set_agent_workspace

    workspace_path = _ask_agent_workspace_path()
    if workspace_path is None:
        console.print("[dim]Agent mode cancelled.[/dim]\n")
        return
    set_agent_workspace(workspace_path)
    console.print(f"[dim]Project folder: [cyan]{workspace_path}[/cyan][/dim]\n")

    agent_sub = questionary.select(
        "Agent Mode:",
        choices=[
            questionary.Choice("Plan — Figure out how to build it", value="plan"),
            questionary.Choice("Agent — Write code and run it", value="agent"),
            questionary.Choice("Ask — Ask questions about your code", value="ask"),
        ],
    ).ask()
    if agent_sub == "plan":
        req = questionary.text("What would you like to build?").ask()
        if req:
            from openartemis.agent import ResearchPipeline
            from openartemis.config import resolve_artemis_model
            pipeline = ResearchPipeline(
                youtube_api_key=os.environ.get("YOUTUBE_API_KEY"),
                scrapingdog_api_key=os.environ.get("SCRAPINGDOG_API_KEY"),
                transcriptapi_api_key=os.environ.get("TRANSCRIPTAPI_API_KEY"),
                model=resolve_artemis_model("artemis-1"),
                out_dir=Path("./detective_output"),
            )
            feedback_parts: list[str] = []
            while True:
                try:
                    query = f"How do I build: {req}"
                    if feedback_parts:
                        query += ". User feedback: " + "; ".join(feedback_parts)
                    report = _run_research_with_live(pipeline, query, on_tool_call=lambda n, a: None)
                    console.print("[green]Report ready.[/green]\n")
                    console.print(Panel(Markdown(report or "(no report)"), title="[green]Build Plan[/green]", border_style="green"))
                    decisive = _get_decisive_build_plan(req, report or "")
                    if decisive and decisive != (report or ""):
                        console.print(Panel(Markdown(decisive), title="[green]Build plan (committed stack)[/green]", border_style="green"))
                except Exception as e:
                    console.print(f"[red]Failed: {e}[/red]")
                    break
                if questionary.confirm("Does this plan work?", default=True).ask():
                    break
                fb = questionary.text("What would you like to change?").ask()
                feedback_parts.append(fb or "Please revise the plan.")
            # Plan approved — spec questions, then auto-switch to Agent
            if req:
                if session and getattr(session, "session_id", None):
                    update_chat_session_title(session.session_id, _chat_title_from_task(req))
                spec = _ask_spec_questions()
                req_with_spec = req + "\n\n" + spec
                allow = questionary.confirm("Agent needs access to its workspace to write and run code. Allow?", default=True).ask()
                if allow:
                    run_in_bg = questionary.confirm(
                        "Run in background? (You can close this and check results later)",
                        default=False,
                    ).ask()
                    if run_in_bg:
                        _run_agent_background(req_with_spec)
                    else:
                        _run_agent_foreground(req_with_spec)
        console.print()
    elif agent_sub == "agent":
        allow = questionary.confirm("Agent needs access to its workspace to write and run code. Allow?", default=True).ask()
        if allow:
            req = questionary.text("What would you like to build?").ask()
            if req:
                if session and getattr(session, "session_id", None):
                    update_chat_session_title(session.session_id, _chat_title_from_task(req))
                spec = _ask_spec_questions()
                req_with_spec = req + "\n\n" + spec
                run_in_bg = questionary.confirm(
                    "Run in background? (You can close this and check results later)",
                    default=False,
                ).ask()
                if run_in_bg:
                    _run_agent_background(req_with_spec)
                else:
                    _run_agent_foreground(req_with_spec)
        console.print()
    elif agent_sub == "ask":
        from openartemis.agent.agent_tools import get_agent_workspace, list_dir, read_file
        from openartemis.config import resolve_artemis_model
        from openai import OpenAI
        get_agent_workspace().mkdir(parents=True, exist_ok=True)
        q = questionary.text("Ask about your code (e.g. How do I start it?)").ask()
        if q:
            try:
                files = list_dir(".")
                ctx = f"Workspace contents:\n{files}\n\n"
                for f in ["index.html", "README.md", "package.json", "main.py"]:
                    try:
                        ctx += f"\n--- {f} ---\n{read_file(f)}\n"
                    except Exception:
                        pass
                client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
                resp = client.chat.completions.create(
                    model=resolve_artemis_model("artemis-1-mini"),
                    messages=[
                        {"role": "system", "content": "Answer the user's question about their code. Use the workspace context provided."},
                        {"role": "user", "content": f"Context:\n{ctx}\n\nQuestion: {q}"},
                    ],
                )
                ans = resp.choices[0].message.content or "(no answer)"
                console.print(Panel(Markdown(ans), title="[green]Answer[/green]", border_style="green"))
            except Exception as e:
                console.print(f"[red]Failed: {e}[/red]")
        console.print()


# Test-login gate: set OPENARTEMIS_ALLOW_TEST_LOGIN to this value to allow headless login
# via OPENARTEMIS_TEST_USER + OPENARTEMIS_TEST_PASSWORD (e.g. for Cursor agent to test).
_TEST_LOGIN_GATE = "cursor-agent-test"

def _try_test_login() -> dict | None:
    """If test-login env is set and gate matches, log in with TEST_USER/TEST_PASSWORD. Else None."""
    if os.environ.get("OPENARTEMIS_ALLOW_TEST_LOGIN") != _TEST_LOGIN_GATE:
        return None
    username = os.environ.get("OPENARTEMIS_TEST_USER", "").strip()
    password = os.environ.get("OPENARTEMIS_TEST_PASSWORD", "")
    if not username or not password:
        return None
    user = login(username, password)
    if not user:
        return None
    create_session(user["id"])
    return user


def _get_authenticated_user() -> dict:
    """Get current user. Returns user dict if authenticated, else runs auth flow."""
    init_db()
    user = get_session_user()
    if user and user.get("approved"):
        return user
    user = _try_test_login()
    if user:
        return user
    return _auth_flow()


def _get_user_no_prompt() -> dict | None:
    """Return current user if session or test-login exists. No interactive prompts."""
    init_db()
    user = get_session_user()
    if user and user.get("approved"):
        return user
    return _try_test_login()


def _auth_flow() -> dict:
    """Run login or invite-code flow. Returns user or exits. Loops on failure until success or Exit."""
    if get_user_count() == 0:
        return _create_first_admin()
    while True:
        choice = questionary.select(
            "Sign in:",
            choices=[
                questionary.Choice("Enter invite code", value="code"),
                questionary.Choice("Login", value="login"),
                questionary.Choice("Exit", value="exit"),
            ],
            **_QUESTIONARY_SELECT_OPTS,
        ).ask()
        if choice == "exit":
            raise typer.Exit(0)
        if choice == "code":
            user = _do_redeem_code()
            if user is not None:
                return user
            continue
        user = _do_login()
        if user is not None:
            return user


def _create_first_admin() -> dict:
    """Create first admin account. Re-prompts on validation failure until valid."""
    console.print(Panel("[bold]No users found. Create admin account.[/bold]", border_style="cyan"))
    console.print("[dim]Password must be at least 8 characters.[/dim]")
    while True:
        email = questionary.text("Admin email:", default="gamtrain400@gmail.com").ask() or "gamtrain400@gmail.com"
        username = questionary.text("Admin username:").ask()
        password = questionary.password("Admin password (min 8 chars):").ask()
        if not username or not password:
            console.print("[red]Username and password required.[/red]\n")
            continue
        if len(password) < 8:
            console.print("[red]Password must be at least 8 characters.[/red]\n")
            continue
        create_admin(email, username, password)
        from openartemis.auth.db import get_user_by_username
        user = get_user_by_username(username)
        if user:
            create_session(user["id"])
            console.print("[green]Admin account created.[/green]\n")
            return user
        console.print("[red]Account creation failed. Try again.[/red]\n")


def _do_redeem_code() -> dict | None:
    """Redeem invite code and create account. Returns user dict or None on failure (caller can retry)."""
    console.print("[dim]Email gamtrain400@gmail.com to request an invite code.[/dim]")
    console.print("[dim]Password must be at least 8 characters.[/dim]\n")
    code = questionary.text("Invite code:").ask()
    if not code or not code.strip():
        console.print("[red]Code required.[/red]\n")
        return None
    email = questionary.text("Email:").ask()
    username = questionary.text("Username:").ask()
    password = questionary.password("Password (min 8 chars):").ask()
    if not email or not username or not password:
        console.print("[red]All fields required.[/red]\n")
        return None
    user, err = redeem_invite_code(code, email, username, password)
    if user:
        create_session(user["id"])
        console.print(f"[green]Account created. Welcome, {username}![/green]\n")
        return user
    console.print(f"[red]{err}[/red]\n")
    return None


def _do_login() -> dict | None:
    """Handle login. Returns user dict or None on failure (caller can retry)."""
    username = questionary.text("Username:").ask()
    password = questionary.password("Password:").ask()
    if not username or not password:
        console.print("[red]Username and password required.[/red]\n")
        return None
    user = login(username, password)
    if not user:
        console.print("[red]Invalid credentials or account not yet approved.[/red]\n")
        return None
    create_session(user["id"])
    console.print(f"[green]Logged in as {username}[/green]\n")
    return user


def _chat_mode(user: dict) -> None:
    """Chat CLI — Artemis with research tools. Type / for mode menu."""
    from openartemis.config import load_config
    load_config()  # Ensure defaults applied (in case import order differed)
    openai_key = os.environ.get("OPENAI_API_KEY")
    if not openai_key:
        console.print(
            "[red]OPENAI_API_KEY required for chat.[/red] Set it in .env or your environment."
        )
        raise typer.Exit(1)

    from openartemis.chat import ChatSession

    def on_tool(name: str, args: dict) -> None:
        if name == "harvest_transcripts":
            q = args.get("query", "")
            p = args.get("platforms", ["youtube"])
            console.print(f"  [dim]→ Finding videos: [bold]{q}[/bold] on {', '.join(p)}[/dim]")
        elif name == "read_transcript":
            console.print(f"  [dim]→ Reading transcript...[/dim]")
        elif name == "brave_search":
            console.print(f"  [dim]→ Brave search: [bold]{args.get('q', '')}[/bold][/dim]")
        elif name == "fetch_webpage":
            console.print(f"  [dim]→ Fetching: [bold]{args.get('url', '')}[/bold][/dim]")
        elif name == "browse_webpage":
            console.print(f"  [dim]→ Browsing: [bold]{args.get('url', '')}[/bold][/dim]")

    is_admin = user.get("role") == "admin"
    session_id: int | None = None

    # No default= so no row gets "selected" style; pointer still starts at first choice
    choice = questionary.select(
        "Start:",
        choices=[
            questionary.Choice("New chat", value="new"),
            questionary.Choice("Continue previous chat", value="continue"),
        ],
        **_QUESTIONARY_SELECT_OPTS,
    ).ask()

    if choice == "continue":
        sessions_list = get_chat_sessions(user["id"], limit=15)
        if not sessions_list:
            console.print("[dim]No previous chats. Starting new chat.[/dim]\n")
            session_id = create_chat_session(user["id"])
            session = ChatSession(
                on_tool_call=on_tool,
                user_id=user["id"],
                is_admin=is_admin,
                session_id=session_id,
            )
        else:
            for s in sessions_list:
                console.print(_chat_list_line(s, console))
            sid_str = questionary.text("Chat number to load (or Enter for new):").ask()
            if sid_str and sid_str.strip().isdigit():
                sid = int(sid_str.strip())
                if any(s["id"] == sid for s in sessions_list):
                    session_id = sid
                    # Full context: load all persisted messages so the user sees the full chat when returning.
                    msgs = get_chat_messages(session_id)
                    session = ChatSession(
                        on_tool_call=on_tool,
                        user_id=user["id"],
                        is_admin=is_admin,
                        session_id=session_id,
                    )
                    session.messages = [{"role": "system", "content": session.messages[0]["content"]}]
                    for m in msgs:
                        msg = {"role": m["role"], "content": m.get("content", "")}
                        if m.get("tool_calls"):
                            msg["tool_calls"] = m["tool_calls"]
                        session.messages.append(msg)
                    session._last_persisted = len(session.messages)
                else:
                    session_id = create_chat_session(user["id"])
                    session = ChatSession(
                        on_tool_call=on_tool,
                        user_id=user["id"],
                        is_admin=is_admin,
                        session_id=session_id,
                    )
            else:
                session_id = create_chat_session(user["id"])
                session = ChatSession(
                    on_tool_call=on_tool,
                    user_id=user["id"],
                    is_admin=is_admin,
                    session_id=session_id,
                )
    else:
        session_id = create_chat_session(user["id"])
        session = ChatSession(
            on_tool_call=on_tool,
            user_id=user["id"],
            is_admin=is_admin,
            session_id=session_id,
        )

    _welcome(chat=True, model=session.model_display)

    current_mode = "chat"
    while True:
        try:
            prompt = "You:" if current_mode == "chat" else f"[{current_mode.title()}] You:"
            user_input = questionary.text(prompt, default="").ask()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[yellow]Bye.[/yellow]")
            raise typer.Exit(0)

        if not user_input or not user_input.strip():
            continue

        # Agent-status: treat as command, never send to chat (works with or without /)
        raw = user_input.strip()
        s = raw.lower().removeprefix("openartemis ").strip()
        # Strip questionary-style prompt prefix if present (e.g. "? You: agent-status")
        for prefix in ("? ", "you: ", "you:"):
            if s.startswith(prefix):
                s = s[len(prefix):].strip().lower()
                break
        s_nodash = s.replace("-", " ").replace("_", " ").strip()
        if s in ("agent-status", "agent status", "agentstatus") or s_nodash == "agent status":
            console.print("[dim]Checking agent status...[/dim]\n")
            _run_agent_status_continuous()
            continue

        # Slash command: extensible registry
        if user_input.strip().startswith("/"):
            cmd = user_input.strip().lower().split()[0] if user_input.strip().split() else user_input.strip().lower()
            _register_builtins()

            def _run_research_callback(query: str) -> None:
                from openartemis.agent import ResearchPipeline
                pipeline = ResearchPipeline(
                    youtube_api_key=os.environ.get("YOUTUBE_API_KEY"),
                    scrapingdog_api_key=os.environ.get("SCRAPINGDOG_API_KEY"),
                    transcriptapi_api_key=os.environ.get("TRANSCRIPTAPI_API_KEY"),
                    model=session.model,
                    out_dir=Path("./detective_output"),
                )
                def on_tool(name: str, args: dict) -> None:
                    if name == "harvest_transcripts":
                        console.print(f"  [dim]→ Harvesting: [bold]{args.get('query', '')}[/bold][/dim]")
                    elif name == "brave_search":
                        console.print(f"  [dim]→ Brave search: [bold]{args.get('q', '')}[/bold][/dim]")
                    elif name == "fetch_webpage":
                        console.print(f"  [dim]→ Fetching: [bold]{args.get('url', '')}[/bold][/dim]")
                    elif name == "browse_webpage":
                        console.print(f"  [dim]→ Browsing: [bold]{args.get('url', '')}[/bold][/dim]")
                try:
                    report = _run_research_with_live(pipeline, query, on_tool_call=on_tool)
                    console.print("[green]Report ready.[/green]\n")
                    console.print(Panel(Markdown(report or "(no report)"), title="[green]Research Report[/green]", border_style="green"))
                except Exception as e:
                    console.print(f"[red]Research failed: {e}[/red]\n")
                console.print()

            mode_state: dict[str, str] = {"current_mode": current_mode}
            slash_ctx: dict[str, Any] = {
                "user_input": user_input,
                "session": session,
                "user": user,
                "is_admin": is_admin,
                "mode_state": mode_state,
                "console": console,
                "run_agent": lambda: _run_agent_mode_flow(session=session),
                "run_research": _run_research_callback,
                "run_agent_status": _run_agent_status_continuous,
            }
            if cmd in SLASH_REGISTRY:
                try:
                    SLASH_REGISTRY[cmd](slash_ctx)
                except typer.Exit:
                    raise
                if "current_mode" in mode_state:
                    current_mode = mode_state["current_mode"]
                continue

            # Unknown slash or "/" only: show mode menu (no checked= so highlight follows pointer)
            _mode_choices = [
                    questionary.Choice("Continue chat", value="chat"),
                    questionary.Choice("Research mode (Artemis will use tools)", value="research"),
                    questionary.Choice("Agent Mode", value="agent"),
                    questionary.Choice("Find videos (guided)", value="harvest"),
                    questionary.Choice("Exit", value="exit"),
                ]
            mode_choice = _select_with_swapped_arrows(
                "Select mode:",
                _mode_choices,
                default=current_mode,
                **_QUESTIONARY_SELECT_OPTS,
            )

            if mode_choice == "exit":
                console.print("[yellow]Bye.[/yellow]")
                raise typer.Exit(0)
            current_mode = mode_choice
            if mode_choice == "harvest":
                try:
                    _interactive_mode()
                except Exception as e:
                    console.print(f"[red]Find videos failed: {e}[/red]")
                    console.print("[dim]You can try again or choose another mode.[/dim]\n")
                _welcome(chat=True)
                current_mode = "chat"
                continue
            if mode_choice == "agent":
                _run_agent_mode_flow(session=session)
                continue
            if mode_choice == "research":
                console.print("[green]Research mode.[/green] Ask Artemis to research something.\n")
            continue

        # User message
        console.print(Panel(user_input, title="[cyan]You[/cyan]", border_style="cyan"))
        num_msgs_before = len(session.messages)

        # Artemis response (streamed, word-wrapped)
        try:
            console.print("[green]Artemis:[/green] ", end="")
            stream_cb, stream_flush = _make_stream_callback(console)
            response = session.send(user_input, stream_callback=stream_cb)
            stream_flush()
            console.print()
            session.persist()
            # First exchange: name chat from context
            if num_msgs_before == 1 and session.session_id and (response or "").strip():
                try:
                    from openai import OpenAI
                    from openartemis.config import resolve_artemis_model
                    client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
                    r = client.chat.completions.create(
                        model=resolve_artemis_model("artemis-1-mini"),
                        messages=[
                            {"role": "user", "content": f"Generate a short chat title (max 6 words) for this exchange. User: {user_input[:150]}. Assistant: {(response or '')[:150]}. Reply with only the title, no quotes."},
                        ],
                    )
                    title = (r.choices[0].message.content or "").strip()[:80]
                    if title:
                        update_chat_session_title(session.session_id, title)
                except Exception:
                    pass
        except ValueError as e:
            console.print(f"[red]{e}[/red]")
            console.print()
            continue
        except Exception as e:
            err_msg = str(e)
            if "402" in err_msg or "insufficient" in err_msg.lower():
                console.print("[red]Something went wrong with credits. Please try again later.[/red]")
            elif "401" in err_msg or "authentication" in err_msg.lower():
                console.print("[red]Something went wrong. Check your settings and try again.[/red]")
            elif "rate" in err_msg.lower() or "429" in err_msg:
                console.print("[red]Too many requests. Please wait a moment and try again.[/red]")
            else:
                console.print("[red]Something went wrong. Try again or type /help.[/red]")
            console.print()
            continue
        if not response and num_msgs_before < len(session.messages):
            last_content = next((m.get("content") or "" for m in reversed(session.messages) if m.get("role") == "assistant"), "")
            if last_content:
                console.print(Markdown(last_content))
        if session.credits_used > 0 and not is_admin:
            console.print(f"  [dim][Credits used: {session.credits_used}][/dim]")
            from openartemis.config import get_max_credits
            max_credits = get_max_credits()
            if max_credits is not None and session.credits_used >= max_credits * 8 // 10:
                console.print(
                    f"  [yellow]Approaching credits cap ({session.credits_used}/{max_credits}). Set OPENARTEMIS_MAX_CREDITS to change.[/yellow]"
                )
            elif max_credits is None and session.credits_used >= 50:
                console.print(
                    "  [yellow]You've used many credits this session. Check your balance at transcriptapi.com[/yellow]"
                )
        console.print()


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context) -> None:
    """Chat with Artemis — uses research tools when you ask. Type / for menu."""
    if ctx.invoked_subcommand is not None:
        return
    while True:
        try:
            user = _get_authenticated_user()
            _chat_mode(user)
            break
        except typer.Exit:
            raise
        except Exception as e:
            err_msg = str(e)
            if "Windows console" in err_msg or "xterm" in err_msg.lower() or "NoConsoleScreenBuffer" in err_msg:
                console.print("[red]This terminal is not a Windows console.[/red]")
                console.print(
                    "[dim]Run OpenArtemis in [bold]cmd.exe[/bold] or [bold]Windows Terminal[/bold] "
                    "so menus and arrow keys work. In some environments use [bold]winpty[/bold].[/dim]"
                )
                raise typer.Exit(1)
            console.print(f"[red]Error: {e}[/red]")
            console.print("[dim]Returning to sign in.[/dim]\n")


@app.command(hidden=True)
def test_run() -> None:
    """Headless one-round chat test (for agent/CI). Uses session or OPENARTEMIS_TEST_* login."""
    user = _get_user_no_prompt()
    if not user:
        console.print(
            "[yellow]No session and no test login.[/yellow]\n"
            f"Log in once in a real terminal, or set [bold]OPENARTEMIS_ALLOW_TEST_LOGIN={_TEST_LOGIN_GATE}[/bold] "
            "with [bold]OPENARTEMIS_TEST_USER[/bold] and [bold]OPENARTEMIS_TEST_PASSWORD[/bold] to run this test."
        )
        raise typer.Exit(1)
    openai_key = os.environ.get("OPENAI_API_KEY")
    if not openai_key:
        console.print("[red]OPENAI_API_KEY required for chat.[/red]")
        raise typer.Exit(1)
    from openartemis.chat import ChatSession
    session_id = create_chat_session(user["id"])
    session = ChatSession(
        user_id=user["id"],
        is_admin=user.get("role") == "admin",
        session_id=session_id,
    )
    console.print("[dim]test-run: sending 'Hi', streaming response...[/dim]")
    try:
        response = session.send("Hi", stream_callback=lambda c: console.print(c, end=""))
        console.print()
        console.print(f"[green]test-run OK[/green] — response length: {len(response or '')} chars")
        session.persist()
    except Exception as e:
        console.print(f"[red]test-run failed: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def harvest() -> None:
    """Guided harvest — step-by-step transcript download."""
    _get_authenticated_user()
    _interactive_mode()


@app.command()
def investigate(
    prompt: str = typer.Argument(None, help="What to find out (e.g. 'Find everything about what happened to John Smith')"),
    openai_api_key: str | None = typer.Option(
        None,
        "--openai-api-key",
        envvar="OPENAI_API_KEY",
        help="OpenAI API key",
    ),
    model: str = typer.Option(
        "artemis-1-mini",
        "--model", "-m",
        help="Artemis model (Artemis-1-Mini or Artemis-1)",
    ),
    out_dir: Path = typer.Option(
        Path("./detective_output"),
        "--out-dir", "-o",
        help="Where to save transcripts and report",
        path_type=Path,
    ),
) -> None:
    """Artemis detective — tell it what to find, it harvests and researches for you."""
    user = _get_authenticated_user()
    if not prompt or not prompt.strip():
        _welcome()
        prompt = questionary.text(
            "What would you like Artemis to find out?",
            default="",
            instruction="(e.g. Find everything about what happened to [person name])",
        ).ask()
        if not prompt or not prompt.strip():
            console.print("[yellow]No prompt entered.[/yellow]")
            raise typer.Exit(1)

    if not openai_api_key:
        console.print(
            "[red]OpenAI API key required.[/red] Set [bold]OPENAI_API_KEY[/bold] or use [bold]--openai-api-key[/bold].\n"
            "[dim]Get a key at platform.openai.com — gpt-4o-mini is ~$0.15/1M input tokens.[/dim]"
        )
        raise typer.Exit(1)

    _welcome()
    console.print(Panel(
        f"[bold]Your request:[/bold] {prompt}\n\n"
        f"[dim]Artemis will search YouTube, TikTok, Instagram, X, read transcripts, and follow leads until it has answers.[/dim]",
        title="[cyan]Detective mode[/cyan]",
        border_style="cyan",
    ))
    console.print()

    from openartemis.agent import ResearchPipeline

    def on_tool(name: str, args: dict) -> None:
        if name == "harvest_transcripts":
            q = args.get("query", "")
            p = args.get("platforms", ["youtube"])
            console.print(f"  [dim]→ Finding videos: [bold]{q}[/bold] on {', '.join(p)}[/dim]")
        elif name == "read_transcript":
            console.print(f"  [dim]→ Reading transcript...[/dim]")
        elif name == "brave_search":
            console.print(f"  [dim]→ Brave search: [bold]{args.get('q', '')}[/bold][/dim]")
        elif name == "fetch_webpage":
            console.print(f"  [dim]→ Fetching: [bold]{args.get('url', '')}[/bold][/dim]")
        elif name == "browse_webpage":
            console.print(f"  [dim]→ Browsing: [bold]{args.get('url', '')}[/bold][/dim]")

    from openartemis.config import resolve_artemis_model
    pipeline = ResearchPipeline(
        openai_api_key=openai_api_key,
        youtube_api_key=os.environ.get("YOUTUBE_API_KEY"),
        scrapingdog_api_key=os.environ.get("SCRAPINGDOG_API_KEY"),
        transcriptapi_api_key=os.environ.get("TRANSCRIPTAPI_API_KEY"),
        model=resolve_artemis_model(model),
        out_dir=out_dir,
    )

    def _on_tool(name: str, args: dict) -> None:
        on_tool(name, args)
        if name == "harvest_transcripts" and user.get("role") != "admin":
            from openartemis.auth.db import log_usage
            log_usage(user["id"], 1, "investigate")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Artemis is researching...", total=None)
        report = pipeline.run(prompt, on_tool_call=_on_tool)
        progress.update(task, description="[green]✓[/green] Done")

    report_path = out_dir / "report.md"
    report_path.write_text(report, encoding="utf-8")

    console.print()
    console.print(Panel(
        f"[bold green]Report saved to:[/bold green] [cyan]{report_path}[/cyan]\n\n"
        f"[dim]Transcripts: {out_dir}[/dim]",
        title="Done",
        border_style="green",
    ))
    console.print()
    console.print(Panel(report[:2000] + ("..." if len(report) > 2000 else ""), title="Report preview", border_style="dim"))


@app.command()
def admin() -> None:
    """Admin panel — manage users, approve requests, view usage."""
    init_db()
    if get_user_count() == 0:
        console.print("[yellow]No users. Run openartemis first to create admin.[/yellow]")
        raise typer.Exit(1)
    user = get_session_user()
    if not user or user.get("role") != "admin":
        console.print("[bold]Admin login[/bold]")
        username = questionary.text("Username:").ask()
        password = questionary.password("Password:").ask()
        if not username or not password:
            raise typer.Exit(1)
        user = login(username, password)
        if not user or user.get("role") != "admin":
            console.print("[red]Admin access required.[/red]")
            raise typer.Exit(1)
        create_session(user["id"])
    _admin_loop(user)


def _admin_loop(admin_user: dict) -> None:
    """Admin menu loop."""
    from openartemis.auth.db import (
        list_users,
        revoke_user,
        create_user_direct,
        get_usage_by_user,
    )
    while True:
        choice = questionary.select(
            "Admin:",
            choices=[
                questionary.Choice("Generate invite code", value="invite"),
                questionary.Choice("List all users", value="users"),
                questionary.Choice("View usage (credits per user)", value="usage"),
                questionary.Choice("Create user (direct)", value="create"),
                questionary.Choice("Revoke user access", value="revoke"),
                questionary.Choice("Logout", value="logout"),
            ],
        ).ask()
        if choice == "logout":
            revoke_session()
            console.print("[green]Logged out.[/green]")
            raise typer.Exit(0)
        if choice == "invite":
            email = questionary.text("Email for code (optional):").ask() or None
            code, expires = create_invite_code(admin_user["id"], email)
            console.print(Panel(
                f"[bold green]Invite code:[/bold green] [cyan]{code}[/cyan]\n\n"
                f"Expires: {expires.strftime('%Y-%m-%d %H:%M')} UTC\n\n"
                f"[dim]Send this code to the user. They enter it at sign-in.[/dim]",
                title="Invite Code",
                border_style="green",
            ))
            console.print()
        elif choice == "users":
            users = list_users()
            for u in users:
                role = "[admin]" if u["role"] == "admin" else ""
                approved = "✓" if u["approved"] else "pending"
                console.print(f"  {u['id']}: {u['username']} {u['email']} {role} [{approved}]")
            console.print()
        elif choice == "usage":
            usage = get_usage_by_user()
            for u in usage:
                console.print(f"  {u['username']}: {u['total_credits']} credits")
            console.print()
        elif choice == "create":
            email = questionary.text("Email:").ask()
            username = questionary.text("Username:").ask()
            password = questionary.password("Password:").ask()
            if email and username and password:
                ok, msg = create_user_direct(email, username, password, approved=True)
                console.print(f"[green]{msg}[/green]" if ok else f"[red]{msg}[/red]")
            console.print()
        elif choice == "revoke":
            users = list_users()
            for u in users:
                if u["role"] != "admin":
                    console.print(f"  {u['id']}: {u['username']}")
            uid_str = questionary.text("User id to revoke:").ask()
            if uid_str:
                try:
                    uid = int(uid_str)
                    if revoke_user(uid):
                        console.print("[green]Revoked.[/green]")
                    else:
                        console.print("[red]Failed.[/red]")
                except ValueError:
                    console.print("[red]Invalid id.[/red]")
            console.print()


@app.command()
def agent(
    prompt: str = typer.Argument(..., help="What to build (e.g. 'Build a Flappy Bird game')"),
    background: bool = typer.Option(False, "--background", "-b", help="Run in background; check results later"),
) -> None:
    """Agent Mode — build things with AI. Runs until done; supports long tasks."""
    _get_authenticated_user()
    if background:
        _run_agent_background(prompt)
    else:
        _run_agent_foreground(prompt)


@app.command(hidden=True)
def agent_run(
    prompt: str = typer.Argument(...),
    output_path: str = typer.Argument(...),
) -> None:
    """Internal: run agent in background. Do not call directly."""
    load_config()
    from openartemis.agent.agent_orchestrator import run_agent_mode

    path = Path(output_path)
    running_marker = path.parent / f"{path.name}.running"
    try:
        run_agent_mode(prompt, output_path=path)
    except Exception as e:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f"# Error\n\n{str(e)}", encoding="utf-8")
    finally:
        if running_marker.exists():
            running_marker.unlink(missing_ok=True)


@app.command()
def artifacts(
    directory: str = typer.Option(
        "all",
        "--dir", "-d",
        help="Which dir: all, workspace, agent_output, detective_output",
    ),
    limit: int = typer.Option(20, "--limit", "-n", help="Max files to list per dir"),
    path: str = typer.Argument(None, help="Path to a file to show (relative to workspace or absolute)"),
) -> None:
    """List or show artifacts (workspace, agent_output, detective_output)."""
    from openartemis.agent.agent_tools import get_agent_workspace
    workspace = get_agent_workspace()
    agent_out = AGENT_OUTPUT_DIR
    detective_out = Path("./detective_output")
    dirs: list[tuple[str, Path]] = []
    if directory == "all":
        dirs = [("workspace", workspace), ("agent_output", agent_out), ("detective_output", detective_out)]
    elif directory == "workspace":
        dirs = [("workspace", workspace)]
    elif directory == "agent_output":
        dirs = [("agent_output", agent_out)]
    elif directory == "detective_output":
        dirs = [("detective_output", detective_out)]
    else:
        console.print("[yellow]Use --dir all|workspace|agent_output|detective_output[/yellow]")
        raise typer.Exit(1)
    if path:
        p = Path(path)
        if not p.is_absolute():
            p = (workspace / path).resolve()
        if not p.exists():
            console.print(f"[red]File not found: {p}[/red]")
            raise typer.Exit(1)
        if p.is_dir():
            console.print("[red]Path is a directory. Use list view (omit path).[/red]")
            raise typer.Exit(1)
        console.print(Panel(p.read_text(encoding="utf-8", errors="replace")[:50000], title=str(p), border_style="cyan"))
        return
    for label, base in dirs:
        if not base.exists():
            continue
        console.print(f"[bold]{label}[/bold] [dim]({base})[/dim]")
        files: list[Path] = []
        for f in base.rglob("*"):
            if f.is_file():
                files.append(f)
        files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
        for f in files[:limit]:
            try:
                mtime = datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
                rel = f.relative_to(base) if base in f.parents or f.parent == base else f.name
                console.print(f"  [cyan]{rel}[/cyan]  [dim]{mtime}[/dim]")
            except ValueError:
                console.print(f"  [cyan]{f.name}[/cyan]")
        if len(files) > limit:
            console.print(f"  [dim]... and {len(files) - limit} more[/dim]")
        console.print()


@app.command()
def export_bundle(
    report_path: str = typer.Argument(..., help="Path to agent report .md or checkpoint .checkpoint.json"),
    output_dir: str = typer.Option(None, "--output", "-o", help="Output folder (default: ./openartemis_bundle_<timestamp>)"),
) -> None:
    """Export a run as a reproducible bundle (prompt, plan, env names, re-run command)."""
    p = Path(report_path)
    if not p.exists():
        console.print(f"[red]Not found: {p}[/red]")
        raise typer.Exit(1)
    if p.suffix == ".json" and ".checkpoint" in p.stem:
        checkpoint_path = p
        output_md = p.parent / (p.stem.replace(".checkpoint", "") + ".md")
    else:
        output_md = p
        checkpoint_path = p.parent / (p.stem + ".checkpoint.json")
    try:
        data = json.loads(checkpoint_path.read_text(encoding="utf-8")) if checkpoint_path.exists() else {}
    except (json.JSONDecodeError, OSError):
        data = {}
    user_request = data.get("user_request", "")
    if not user_request and output_md.exists():
        first_line = output_md.read_text(encoding="utf-8", errors="replace").split("\n")[0]
        if first_line.startswith("# Agent Report — "):
            user_request = first_line.replace("# Agent Report — ", "").strip()
    if not user_request:
        user_request = "(unknown request)"
    out = Path(output_dir or f"./openartemis_bundle_{datetime.now().strftime('%Y%m%d_%H%M')}")
    out.mkdir(parents=True, exist_ok=True)
    (out / "prompt.txt").write_text(user_request, encoding="utf-8")
    (out / "env_vars.txt").write_text(
        "OPENAI_API_KEY\nOPENARTEMIS_PROFILE\nOPENARTEMIS_MAX_CREDITS\nOPENARTEMIS_MAX_TOKENS\n",
        encoding="utf-8",
    )
    if data.get("steps"):
        (out / "plan.json").write_text(json.dumps({"steps": data["steps"]}, indent=2), encoding="utf-8")
    prompt_preview = user_request[:200] + ("..." if len(user_request) > 200 else "")
    (out / "README.md").write_text(
        f"# OpenArtemis run bundle\n\nOriginal prompt: {prompt_preview}\n\n"
        "Re-run: `openartemis agent \"<prompt.txt content>\"`\n"
        "Resume from checkpoint: copy .checkpoint.json and .md to ~/.openartemis/agent_output/ then `openartemis agent-resume`\n",
        encoding="utf-8",
    )
    if output_md.exists():
        import shutil
        shutil.copy(output_md, out / "report.md")
    console.print(f"[green]Bundle written to {out}[/green]")
    console.print(f"  prompt.txt, env_vars.txt, README.md" + (", plan.json, report.md" if data.get("steps") else "") + "\n")


@app.command()
def agent_resume(
    checkpoint_file: str = typer.Argument(
        None,
        help="Path to .checkpoint.json (default: latest in ~/.openartemis/agent_output)",
    ),
) -> None:
    """Resume an agent run from its last checkpoint."""
    load_config()
    from openartemis.agent.agent_orchestrator import run_agent_mode

    AGENT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    checkpoints = sorted(AGENT_OUTPUT_DIR.glob("*.checkpoint.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not checkpoints:
        console.print("[yellow]No checkpoints found. Run an agent task first (it checkpoints after each step).[/yellow]")
        raise typer.Exit(1)
    if checkpoint_file:
        path = Path(checkpoint_file)
        if not path.exists():
            console.print(f"[red]Checkpoint file not found: {path}[/red]")
            raise typer.Exit(1)
    else:
        path = checkpoints[0]
        console.print(f"[dim]Using latest checkpoint: {path.name}[/dim]\n")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        console.print(f"[red]Invalid checkpoint: {e}[/red]")
        raise typer.Exit(1)
    user_request = data.get("user_request", "")
    if not user_request:
        console.print("[red]Checkpoint has no user_request.[/red]")
        raise typer.Exit(1)
    output_path = path.parent / (path.stem.replace(".checkpoint", "") + ".md")
    console.print(f"[dim]Resuming: {user_request[:60]}...[/dim]\n")
    try:
        report = run_agent_mode(user_request, output_path=output_path, resume_from_checkpoint=True)
        console.print(Panel(Markdown(report or "(no output)"), title="[green]Agent Report[/green]", border_style="green"))
        console.print(f"[dim]Saved to {output_path}[/dim]\n")
    except Exception as e:
        console.print(f"[red]Resume failed: {e}[/red]")
        raise typer.Exit(1)


def _agent_status_renderable():
    """Build current agent status as a Rich renderable (for one-shot or Live)."""
    AGENT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    running = list(AGENT_OUTPUT_DIR.glob("*.running"))
    completed = sorted(AGENT_OUTPUT_DIR.glob("*.md"), key=lambda p: p.stat().st_mtime, reverse=True)[:10]
    parts = []
    if running:
        parts.append("[yellow]Running:[/yellow]")
        for r in running:
            req = r.read_text(encoding="utf-8", errors="replace")[:60]
            parts.append(f"  • {req}...")
            status_file = r.parent / (r.name.replace(".running", ".status"))
            if status_file.exists():
                last = status_file.read_text(encoding="utf-8", errors="replace").strip()[:80]
                if last:
                    parts.append(f"    [dim]Last activity: {last}[/dim]")
        parts.append("")
    if completed:
        parts.append("[green]Recent results:[/green]")
        for p in completed:
            mtime = datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
            parts.append(f"  • {mtime} — [cyan]{p.name}[/cyan]")
        parts.append(f"\n[dim]Results: {AGENT_OUTPUT_DIR}[/dim]")
    elif not running:
        parts.append("[dim]No agent runs yet.[/dim]")
    return Panel("\n".join(parts), title="Agent status", border_style="cyan")


def _agent_tree_renderable() -> Tree:
    """Build a tree view: Goal -> Step 1, Step 2, ... from checkpoints and running jobs."""
    AGENT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    tree = Tree("[bold]Agent runs[/bold]")
    running = list(AGENT_OUTPUT_DIR.glob("*.running"))
    checkpoints = sorted(AGENT_OUTPUT_DIR.glob("*.checkpoint.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:10]
    for r in running:
        req = r.read_text(encoding="utf-8", errors="replace")[:50]
        branch = tree.add(f"[yellow]Running:[/yellow] {req}...")
        base = r.stem.replace(".running", "").replace(".md", "")
        ckp = r.parent / (base + ".checkpoint.json")
        if ckp.exists():
            try:
                data = json.loads(ckp.read_text(encoding="utf-8"))
                for s in (data.get("steps") or [])[:20]:
                    step_id = s.get("id", "?")
                    action = (s.get("action") or "")[:45]
                    branch.add(f"Step {step_id}: {action}...")
            except (json.JSONDecodeError, OSError):
                pass
    for cp in checkpoints:
        try:
            data = json.loads(cp.read_text(encoding="utf-8"))
            req = (data.get("user_request") or "")[:45]
            steps = data.get("steps") or []
            idx = data.get("step_index", 0)
            label = f"[green]{cp.stem.replace('.checkpoint', '')}[/green] — {req}..."
            branch = tree.add(label)
            for i, s in enumerate(steps[:15]):
                step_id = s.get("id", i + 1)
                action = (s.get("action") or "")[:40]
                done = "[green]✓[/green] " if i < idx else ""
                branch.add(f"{done}Step {step_id}: {action}...")
        except (json.JSONDecodeError, OSError):
            tree.add(f"[dim]{cp.name}[/dim]")
    if not running and not checkpoints:
        tree.add("[dim]No agent runs or checkpoints yet.[/dim]")
    return tree


def _run_agent_status_continuous() -> None:
    """Show agent status in a live-updating view until no tasks running or user stops."""
    AGENT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    running = list(AGENT_OUTPUT_DIR.glob("*.running"))
    if not running:
        console.print(_agent_status_renderable())
        return
    try:
        with Live(_agent_status_renderable(), console=console, refresh_per_second=0.5) as live:
            while True:
                time.sleep(2)
                running = list(AGENT_OUTPUT_DIR.glob("*.running"))
                live.update(_agent_status_renderable())
                if not running:
                    break
    except KeyboardInterrupt:
        pass
    console.print("[dim]Stopped watching.[/dim]\n")


@app.command()
def agent_status(
    tree: bool = typer.Option(False, "--tree", "-t", help="Show hierarchy (goal → steps) from checkpoints"),
) -> None:
    """Show recent agent runs and their status."""
    if tree:
        console.print(_agent_tree_renderable())
    else:
        console.print(_agent_status_renderable())


@app.command()
def reset_admin(
    username: str = typer.Argument(None, help="Admin username (default: first admin)"),
    password: str = typer.Option(..., "--password", "-p", prompt=True, hide_input=True),
) -> None:
    """Reset admin password (use when you forgot it). No login required."""
    from openartemis.auth.db import list_users
    init_db()
    if get_user_count() == 0:
        console.print("[yellow]No users. Run openartemis first to create admin.[/yellow]")
        return
    if not username:
        users = [u for u in list_users() if u.get("role") == "admin"]
        if not users:
            console.print("[red]No admin users found.[/red]")
            return
        username = users[0]["username"]
        console.print(f"[dim]Resetting password for admin: {username}[/dim]")
    ok, msg = reset_admin_password(username, password)
    if ok:
        console.print(f"[green]{msg}[/green]")
    else:
        console.print(f"[red]{msg}[/red]")


@app.command()
def logout() -> None:
    """Log out of current session."""
    revoke_session()
    console.print("[green]Logged out.[/green]")


@app.command()
def search(
    query: str = typer.Argument(..., help="Search chat history by title or message content"),
    limit: int = typer.Option(30, "--limit", "-n", help="Max sessions to return"),
) -> None:
    """Search chat sessions by title or message content."""
    user = _get_authenticated_user()
    sessions_list = search_chat_sessions(user["id"], query, limit=limit)
    if not sessions_list:
        console.print("[dim]No matching chats.[/dim]\n")
        return
    console.print(f"[bold]Chats matching \"{query}\"[/bold]\n")
    for s in sessions_list:
        console.print(_chat_list_line(s, console))
    console.print("[dim]Use /load <number> in chat to open a session.[/dim]\n")


@app.command()
def preflight(
    mode: str = typer.Option(
        None,
        "--mode", "-m",
        help="Check only this mode: chat, harvest, agent, research (default: all)",
    ),
) -> None:
    """Check environment and required env vars for chat, harvest, agent, and research."""
    from openartemis.preflight import run_preflight
    results = run_preflight(mode)
    table = Table(title="Preflight")
    table.add_column("Mode", style="cyan")
    table.add_column("Check", style="green")
    table.add_column("Status", style="bold")
    table.add_column("Detail", style="dim")
    for m, check_id, ok, msg in results:
        status = "[green]OK[/green]" if ok else "[red]MISSING[/red]"
        table.add_row(m, check_id, status, msg)
    console.print(table)
    failed = sum(1 for _, __, ok, _ in results if not ok)
    if failed:
        console.print(f"\n[yellow]{failed} check(s) missing or invalid. Set env vars or run [bold]openartemis config[/bold] for help.[/yellow]")
    else:
        console.print("\n[green]All checks passed.[/green]")


@app.command()
def config() -> None:
    """Show configuration help and required env vars."""
    _welcome()
    table = Table(title="Configuration")
    table.add_column("Variable", style="cyan")
    table.add_column("Required for", style="green")
    table.add_column("Where to get it", style="dim")
    table.add_row(
        "ffmpeg (system)",
        "TikTok, Instagram, X, Whisper audio",
        "winget install ffmpeg | brew install ffmpeg | apt install ffmpeg",
    )
    table.add_row(
        "YOUTUBE_API_KEY",
        "YouTube (Google API, if not using TranscriptAPI)",
        "Google Cloud Console → APIs & Services → YouTube Data API v3",
    )
    table.add_row(
        "TRANSCRIPTAPI_API_KEY",
        "YouTube search + transcripts (TranscriptAPI.com)",
        "transcriptapi.com — replaces Google API",
    )
    table.add_row(
        "SCRAPINGDOG_API_KEY",
        "YouTube transcripts (optional, if not using TranscriptAPI)",
        "scrapingdog.com",
    )
    table.add_row(
        "OPENAI_API_KEY",
        "Artemis chat (investigate command)",
        "platform.openai.com",
    )
    table.add_row(
        "BRAVE_SEARCH_API_KEY",
        "Web search in research (brave_search tool)",
        "search.brave.com — free tier available",
    )
    table.add_row(
        "OPENARTEMIS_MAX_CREDITS",
        "Per-session credits cap for non-admin (SaaS budget)",
        "e.g. 100 — admins have no cap",
    )
    table.add_row(
        "OPENARTEMIS_MAX_TOKENS",
        "Per-completion token cap (limits response length)",
        "e.g. 2048 or 4096 — reduces token usage for non-admin",
    )
    console.print(table)
    console.print("\n[dim]Set in your shell or use the corresponding --*-api-key flags[/dim]")


def main() -> None:
    """Entry point for openartemis command."""
    from openartemis.update_check import ensure_updated
    ensure_updated()
    app()


if __name__ == "__main__":
    main()
