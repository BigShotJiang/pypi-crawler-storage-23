"""Multi-agent pipeline — plan, run workers in parallel, verify, synthesize report (gather → filter → verify → synthesize → cite)."""

import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

from openartemis.agent.detective import DetectiveAgent
from openartemis.agent.orchestrator import create_plan
from openartemis.agent.worker import run_worker
from openartemis.retry import retry_with_backoff

VERIFY_PROMPT = """You are verifying and cross-checking research results from multiple workers.

The user asked: {user_request}

Worker results (each worker answered one sub-question):

{worker_results}

Your job:
1. Identify claims that appear in multiple sources (agreement).
2. Flag any conflicts between sources (e.g. different dates, contradictory facts).
3. Resolve or note conflicts: prefer the best-sourced claim or state "sources disagree: X vs Y".

Output a single text block with two sections:
## Verified findings
(Bullet points: claim [sources that support it]. Resolve conflicts here.)
## Conflicts resolved
(Short note on any conflicts and how you resolved them, or "None found.")

Do not invent information. Use only what is in the worker results."""

SYNTHESIS_PROMPT = """You are writing a final sourced report from verified research.

The user asked: {user_request}

Verified findings (already cross-checked):

{verified_text}

Write a single report with:
- **Executive summary** (2-4 sentences)
- **Key findings** — each finding must include inline citations like [1], [2] referring to the numbered Sources list
- **Conclusions**
- **Sources** — numbered list of URLs/sources cited in the report (match the [1], [2] numbers)

Rules:
- Every factual claim in Key findings must have a citation [N].
- Sources section must be numbered and match the citations.
- Be concise. Do not add information not present in the verified findings."""


class ResearchPipeline:
    """Multi-agent research: plan → parallel workers (gather) → verify → synthesize → cite."""

    def __init__(
        self,
        openai_api_key: str | None = None,
        youtube_api_key: str | None = None,
        scrapingdog_api_key: str | None = None,
        transcriptapi_api_key: str | None = None,
        model: str = "gpt-4o-mini",
        out_dir: Path | None = None,
        max_workers: int = 8,
    ):
        self.agent = DetectiveAgent(
            openai_api_key=openai_api_key,
            youtube_api_key=youtube_api_key or os.environ.get("YOUTUBE_API_KEY"),
            scrapingdog_api_key=scrapingdog_api_key or os.environ.get("SCRAPINGDOG_API_KEY"),
            transcriptapi_api_key=transcriptapi_api_key or os.environ.get("TRANSCRIPTAPI_API_KEY"),
            model=model,
            out_dir=out_dir or Path("./detective_output"),
        )
        self.client = OpenAI(api_key=openai_api_key or os.environ.get("OPENAI_API_KEY"))
        self.model = model
        from openartemis.config import get_profile_setting
        profile_workers = get_profile_setting("max_workers")
        self.max_workers = int(profile_workers) if profile_workers is not None else max_workers

    def run(
        self,
        user_request: str,
        on_tool_call: Callable[[str, dict], None] | None = None,
        on_stage: Callable[[str], None] | None = None,
        on_plan_done: Callable[[int], None] | None = None,
        on_task_done: Callable[[int, int], None] | None = None,
        on_log: Callable[[str], None] | None = None,
        approve_before_phase: Callable[[str], bool] | None = None,
    ) -> str:
        """Run full pipeline: plan → workers (parallel) → verify → synthesize. Returns final report.
        If approve_before_phase is set, it is called after plan and after gather with phase name;
        if it returns False, the run exits early with a partial result."""
        def _stage(s: str) -> None:
            if on_stage:
                on_stage(s)
        def _log(msg: str) -> None:
            if on_log:
                on_log(msg)

        _stage("Planning…")
        tasks = create_plan(user_request, model=self.model)
        if not tasks:
            return "Could not create a research plan. Please try rephrasing your request."
        if on_plan_done:
            on_plan_done(len(tasks))
        _log(f"Created {len(tasks)} sub-questions")
        if approve_before_phase and not approve_before_phase("plan"):
            return "Research stopped after plan (user chose not to continue)."
        _stage("Gathering…")

        worker_results: list[dict[str, Any]] = []
        total_sources_so_far = 0

        def run_one(task: dict) -> dict[str, Any]:
            def _run() -> dict[str, Any]:
                return run_worker(task, self.agent, on_tool_call=on_tool_call)
            return retry_with_backoff(
                _run,
                max_attempts=3,
                backoff_base=2.0,
                on_retry=lambda attempt, e: _log(f"Retry {attempt} for task {task.get('id')}: {e}") if on_log else None,
            )

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {executor.submit(run_one, t): t for t in tasks}
            for future in as_completed(futures):
                try:
                    result = future.result()
                    worker_results.append(result)
                    n_sources = len(result.get("sources", []))
                    total_sources_so_far += n_sources
                    if on_task_done:
                        on_task_done(result.get("task_id", 0), total_sources_so_far)
                    _log(f"Sub-question {result.get('task_id', '?')} done — {n_sources} sources")
                except Exception as e:
                    from openartemis.errors import classify_exception
                    task = futures[future]
                    err_type = classify_exception(e)
                    worker_results.append({
                        "task_id": task.get("id", 0),
                        "summary": f"[{err_type.value}] {e}",
                        "findings": [],
                        "sources": [],
                    })
                    if on_task_done:
                        on_task_done(task.get("id", 0), total_sources_so_far)
                    _log(f"Sub-question {task.get('id', '?')} error ({err_type.value}): {e}")

        # Sort by task_id for consistent ordering
        worker_results.sort(key=lambda r: r.get("task_id", 0))
        if approve_before_phase and not approve_before_phase("gather"):
            # Partial export: raw worker summaries
            parts = [f"## Partial (stopped after gather)\n\nUser asked: {user_request}\n"]
            for r in worker_results:
                parts.append(f"\n### Task {r.get('task_id')}\n{r.get('summary', '')}\n")
            return "\n".join(parts)

        _stage("Verifying…")
        _log("Cross-checking claims and resolving conflicts…")

        # Build text for verify step
        results_text = "\n\n---\n\n".join(
            f"Task {r['task_id']}:\n{r['summary']}\n\nFindings: {r.get('findings', [])}\nSources: {r.get('sources', [])}"
            for r in worker_results
        )

        # Verify: cross-check claims, resolve conflicts
        verify_resp = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You verify and cross-check research; resolve conflicts."},
                {"role": "user", "content": VERIFY_PROMPT.format(
                    user_request=user_request,
                    worker_results=results_text,
                )},
            ],
        )
        verified_text = (verify_resp.choices[0].message.content or "").strip()
        if not verified_text:
            verified_text = results_text

        _stage("Synthesizing…")
        _log("Writing sourced report…")

        # Synthesize: final report with inline citations [1], [2] and Sources list
        synthesis_resp = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You write sourced reports with inline citations and a numbered Sources list."},
                {"role": "user", "content": SYNTHESIS_PROMPT.format(
                    user_request=user_request,
                    verified_text=verified_text,
                )},
            ],
        )
        report = (synthesis_resp.choices[0].message.content or "").strip()
        try:
            from openartemis.self_eval import self_eval_enabled, score_report
            if self_eval_enabled():
                _log("Running self-eval rubric…")
                scores = score_report(report, user_request, model=self.model)
                if scores:
                    overall = scores.get("overall", 0)
                    _log(f"Self-eval: {overall}/5 overall — {scores.get('feedback', '')[:80]}")
                    report = report + f"\n\n---\n**Self-eval:** {overall}/5 overall (completeness {scores.get('completeness', 0)}, citations {scores.get('citations', 0)}, clarity {scores.get('clarity', 0)})."
        except Exception:
            pass
        _stage("Done")
        return report
