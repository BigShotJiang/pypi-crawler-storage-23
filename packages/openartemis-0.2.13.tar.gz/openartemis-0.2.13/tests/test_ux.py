"""
UX tests: slash commands and CLI entrypoints.
Run with: python -m unittest tests.test_ux -v
Or: python tests/test_ux.py
"""
from io import StringIO
import os
import sys
from pathlib import Path
from unittest import mock, TestCase

# Ensure package is importable
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rich.console import Console


def _make_slash_ctx(session=None, user=None, user_input="/help", is_admin=False):
    """Build a minimal slash context for testing handlers."""
    out = StringIO()
    console = Console(file=out, force_terminal=False, width=80)
    if user is None:
        user = {"id": 1, "role": "user", "approved": True}
    if session is None:
        from openartemis.chat import ChatSession
        session = ChatSession(user_id=user["id"], is_admin=is_admin, session_id=99)
        session.model_display = "Artemis-1-Mini"
    return {
        "user_input": user_input,
        "session": session,
        "user": user,
        "is_admin": is_admin,
        "mode_state": {},
        "console": console,
        "run_agent": lambda: None,
        "run_research": lambda q: None,
        "run_agent_status": lambda: None,
    }, out


class TestSlashCommands(TestCase):
    """Test slash command handlers with mock context."""

    def setUp(self):
        from openartemis.slash_commands import _register_builtins
        _register_builtins()

    def test_help_prints_commands(self):
        from openartemis.slash_commands import SLASH_REGISTRY
        ctx, out = _make_slash_ctx(user_input="/help")
        SLASH_REGISTRY["/help"](ctx)
        text = out.getvalue()
        self.assertTrue("Help" in text or "Commands" in text)
        self.assertIn("/history", text)
        self.assertIn("/load", text)
        self.assertIn("/research", text)

    def test_question_mark_alias_help(self):
        from openartemis.slash_commands import SLASH_REGISTRY
        ctx, out = _make_slash_ctx(user_input="/?")
        SLASH_REGISTRY["/?"](ctx)
        self.assertIn("/history", out.getvalue())

    def test_exit_raises(self):
        from openartemis.slash_commands import SLASH_REGISTRY
        import typer
        ctx, _ = _make_slash_ctx(user_input="/exit")
        with self.assertRaises(typer.Exit) as exc:
            SLASH_REGISTRY["/exit"](ctx)
        self.assertEqual(exc.exception.exit_code, 0)

    def test_history_empty(self):
        from openartemis.slash_commands import SLASH_REGISTRY
        ctx, out = _make_slash_ctx(user_input="/history")
        with mock.patch("openartemis.auth.get_chat_sessions", return_value=[]):
            SLASH_REGISTRY["/history"](ctx)
        text = out.getvalue()
        self.assertTrue("No chat history" in text or "history" in text.lower())

    def test_load_no_number(self):
        from openartemis.slash_commands import SLASH_REGISTRY
        ctx, out = _make_slash_ctx(user_input="/load")
        SLASH_REGISTRY["/load"](ctx)
        self.assertTrue("Usage" in out.getvalue() or "load" in out.getvalue().lower())

    def test_load_invalid_number(self):
        from openartemis.slash_commands import SLASH_REGISTRY
        ctx, out = _make_slash_ctx(user_input="/load abc")
        SLASH_REGISTRY["/load"](ctx)
        self.assertTrue("Usage" in out.getvalue() or "load" in out.getvalue().lower())

    def test_delete_no_number(self):
        from openartemis.slash_commands import SLASH_REGISTRY
        ctx, out = _make_slash_ctx(user_input="/delete")
        SLASH_REGISTRY["/delete"](ctx)
        self.assertTrue("Usage" in out.getvalue() or "delete" in out.getvalue().lower())

    def test_model_no_arg_shows_current(self):
        from openartemis.slash_commands import SLASH_REGISTRY
        ctx, out = _make_slash_ctx(user_input="/model")
        SLASH_REGISTRY["/model"](ctx)
        text = out.getvalue()
        self.assertTrue("Artemis" in text or "model" in text.lower())

    def test_model_invalid_arg(self):
        from openartemis.slash_commands import SLASH_REGISTRY
        ctx, out = _make_slash_ctx(user_input="/model BadModel")
        SLASH_REGISTRY["/model"](ctx)
        self.assertTrue("Artemis-1" in out.getvalue() or "Artemis-1-Mini" in out.getvalue())

    def test_harvest_no_url(self):
        from openartemis.slash_commands import SLASH_REGISTRY
        ctx, out = _make_slash_ctx(user_input="/harvest")
        SLASH_REGISTRY["/harvest"](ctx)
        self.assertTrue("URL" in out.getvalue() or "url" in out.getvalue().lower())

    def test_research_no_query(self):
        from openartemis.slash_commands import SLASH_REGISTRY
        ctx, out = _make_slash_ctx(user_input="/research")
        SLASH_REGISTRY["/research"](ctx)
        self.assertTrue("query" in out.getvalue().lower() or "research" in out.getvalue().lower())

    def test_save_writes_file(self):
        from openartemis.slash_commands import SLASH_REGISTRY
        ctx, out = _make_slash_ctx(user_input="/save")
        with mock.patch.dict(os.environ, {"HOME": os.path.expanduser("~")}, clear=False):
            SLASH_REGISTRY["/save"](ctx)
        self.assertTrue("saved" in out.getvalue().lower() or "session" in out.getvalue().lower())

    def test_export_writes_markdown(self):
        from openartemis.slash_commands import SLASH_REGISTRY
        ctx, out = _make_slash_ctx(user_input="/export")
        SLASH_REGISTRY["/export"](ctx)
        text = out.getvalue()
        self.assertTrue("Export" in text or "export" in text.lower() or "detective_output" in text)


class TestCLICommands(TestCase):
    """Test CLI entrypoints that don't require interactive prompts."""

    def test_preflight_runs(self):
        from typer.testing import CliRunner
        from openartemis.cli import app
        runner = CliRunner()
        result = runner.invoke(app, ["preflight"])
        self.assertEqual(result.exit_code, 0)
        out = result.output
        self.assertTrue("Preflight" in out or "chat" in out.lower() or "OK" in out or "MISSING" in out)

    def test_config_runs(self):
        from typer.testing import CliRunner
        from openartemis.cli import app
        runner = CliRunner()
        result = runner.invoke(app, ["config"])
        self.assertEqual(result.exit_code, 0)
        out = result.output
        self.assertTrue("Configuration" in out or "OPENAI" in out or "Variable" in out)

    def test_logout_runs(self):
        from typer.testing import CliRunner
        from openartemis.cli import app
        runner = CliRunner()
        result = runner.invoke(app, ["logout"])
        self.assertEqual(result.exit_code, 0)
        self.assertTrue("out" in result.output.lower() or "Logged" in result.output)

    def test_artifacts_list_runs(self):
        from typer.testing import CliRunner
        from openartemis.cli import app
        runner = CliRunner()
        result = runner.invoke(app, ["artifacts", "--dir", "all"])
        self.assertEqual(result.exit_code, 0)
        out = result.output.lower()
        self.assertTrue("workspace" in out or "agent_output" in out or "detective_output" in out)

    def test_artifacts_invalid_dir(self):
        from typer.testing import CliRunner
        from openartemis.cli import app
        runner = CliRunner()
        result = runner.invoke(app, ["artifacts", "--dir", "invalid"])
        self.assertEqual(result.exit_code, 1)
        out = result.output.lower()
        self.assertTrue("all" in out or "workspace" in out)


if __name__ == "__main__":
    import unittest
    unittest.main(verbosity=2)
