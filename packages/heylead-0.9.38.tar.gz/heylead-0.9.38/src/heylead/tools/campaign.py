"""Tool: campaign — Control campaign lifecycle (pause, resume, archive, delete, etc.).

Thin dispatcher that routes to existing run_* functions based on the action parameter.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


async def run_campaign(
    action: str,
    campaign_id: str = "",
    confirm: bool = False,
) -> str:
    """Control campaign lifecycle.

    Actions:
      pause          — Pause an active campaign
      resume         — Resume a paused campaign
      archive        — Archive a completed campaign
      delete         — Permanently delete a campaign (requires confirm=True)
      emergency_stop — Immediately pause ALL active campaigns
      retry_failed   — Reset error outreaches to pending

    Args:
        action: What to do: 'pause', 'resume', 'archive', 'delete', 'emergency_stop', 'retry_failed'.
        campaign_id: Which campaign to act on. Auto-selects if empty.
        confirm: Must be True for delete action. Safety guard.
    """
    action = action.lower().strip()

    if action == "pause":
        from .campaign_control import run_pause_campaign
        return await run_pause_campaign(campaign_id)

    if action == "resume":
        from .campaign_control import run_resume_campaign
        return await run_resume_campaign(campaign_id)

    if action == "archive":
        from .archive_campaign import run_archive_campaign
        return await run_archive_campaign(campaign_id)

    if action == "delete":
        from .delete_campaign import run_delete_campaign
        return await run_delete_campaign(campaign_id, confirm)

    if action == "emergency_stop":
        from .emergency_stop import run_emergency_stop
        return await run_emergency_stop()

    if action in ("retry_failed", "retry"):
        from .retry_failed import run_retry_failed
        return await run_retry_failed(campaign_id)

    return (
        f"Unknown action: '{action}'. Available actions:\n"
        "  'pause'          — Pause an active campaign\n"
        "  'resume'         — Resume a paused campaign\n"
        "  'archive'        — Archive a completed campaign\n"
        "  'delete'         — Permanently delete (requires confirm=True)\n"
        "  'emergency_stop' — Pause ALL active campaigns\n"
        "  'retry_failed'   — Reset error outreaches to pending"
    )
