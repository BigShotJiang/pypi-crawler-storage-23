# Bourgade

**Bourgade** (fr. "village") is a simple event bus for RabbitMQ, that moves
focus from RabbitMQ abstractions to good ol' events.

## Installation

To install Bourgade, use:

```bash
pip install bourgade
```

With Poetry, do:

```bash
poetry add bourgade
```

## License

**Bourgade** is licensed under MIT.

------------------
Copyright (c) 2026 Anatoly Frolov (anafro). All Rights Reserved.\
`contact@anafro.ru`
