"""Exceptions for the dobby SDK."""

from .tool import ApprovalRequired as ApprovalRequired
