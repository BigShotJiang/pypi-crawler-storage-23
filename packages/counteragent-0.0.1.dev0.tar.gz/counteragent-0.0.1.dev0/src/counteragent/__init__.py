"""CounterAgent - Agentic AI protocol & system security toolkit."""
