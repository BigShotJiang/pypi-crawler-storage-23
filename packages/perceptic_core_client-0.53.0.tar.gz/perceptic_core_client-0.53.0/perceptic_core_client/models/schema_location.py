from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="SchemaLocation")


@_attrs_define
class SchemaLocation:
    """
    Attributes:
        root_document_uri (str | Unset):
        pointer_to_location (list[str] | Unset):
    """

    root_document_uri: str | Unset = UNSET
    pointer_to_location: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        root_document_uri = self.root_document_uri

        pointer_to_location: list[str] | Unset = UNSET
        if not isinstance(self.pointer_to_location, Unset):
            pointer_to_location = self.pointer_to_location

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if root_document_uri is not UNSET:
            field_dict["rootDocumentURI"] = root_document_uri
        if pointer_to_location is not UNSET:
            field_dict["pointerToLocation"] = pointer_to_location

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        root_document_uri = d.pop("rootDocumentURI", UNSET)

        pointer_to_location = cast(list[str], d.pop("pointerToLocation", UNSET))

        schema_location = cls(
            root_document_uri=root_document_uri,
            pointer_to_location=pointer_to_location,
        )

        schema_location.additional_properties = d
        return schema_location

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
