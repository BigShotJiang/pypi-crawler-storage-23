from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.execution_trigger_reason import ExecutionTriggerReason
from ..types import UNSET, Unset

T = TypeVar("T", bound="ScheduleExecutionDto")


@_attrs_define
class ScheduleExecutionDto:
    """
    Attributes:
        execution_rid (str | Unset):
        schedule_rid (str | Unset):
        task_rid (str | Unset):
        triggered_at (datetime.datetime | Unset):
        reason (ExecutionTriggerReason | Unset):
        trigger_details (None | str | Unset):
    """

    execution_rid: str | Unset = UNSET
    schedule_rid: str | Unset = UNSET
    task_rid: str | Unset = UNSET
    triggered_at: datetime.datetime | Unset = UNSET
    reason: ExecutionTriggerReason | Unset = UNSET
    trigger_details: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        execution_rid = self.execution_rid

        schedule_rid = self.schedule_rid

        task_rid = self.task_rid

        triggered_at: str | Unset = UNSET
        if not isinstance(self.triggered_at, Unset):
            triggered_at = self.triggered_at.isoformat()

        reason: str | Unset = UNSET
        if not isinstance(self.reason, Unset):
            reason = self.reason.value

        trigger_details: None | str | Unset
        if isinstance(self.trigger_details, Unset):
            trigger_details = UNSET
        else:
            trigger_details = self.trigger_details

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if execution_rid is not UNSET:
            field_dict["executionRid"] = execution_rid
        if schedule_rid is not UNSET:
            field_dict["scheduleRid"] = schedule_rid
        if task_rid is not UNSET:
            field_dict["taskRid"] = task_rid
        if triggered_at is not UNSET:
            field_dict["triggeredAt"] = triggered_at
        if reason is not UNSET:
            field_dict["reason"] = reason
        if trigger_details is not UNSET:
            field_dict["triggerDetails"] = trigger_details

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        execution_rid = d.pop("executionRid", UNSET)

        schedule_rid = d.pop("scheduleRid", UNSET)

        task_rid = d.pop("taskRid", UNSET)

        _triggered_at = d.pop("triggeredAt", UNSET)
        triggered_at: datetime.datetime | Unset
        if isinstance(_triggered_at, Unset):
            triggered_at = UNSET
        else:
            triggered_at = isoparse(_triggered_at)

        _reason = d.pop("reason", UNSET)
        reason: ExecutionTriggerReason | Unset
        if isinstance(_reason, Unset):
            reason = UNSET
        else:
            reason = ExecutionTriggerReason(_reason)

        def _parse_trigger_details(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        trigger_details = _parse_trigger_details(d.pop("triggerDetails", UNSET))

        schedule_execution_dto = cls(
            execution_rid=execution_rid,
            schedule_rid=schedule_rid,
            task_rid=task_rid,
            triggered_at=triggered_at,
            reason=reason,
            trigger_details=trigger_details,
        )

        schedule_execution_dto.additional_properties = d
        return schedule_execution_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
