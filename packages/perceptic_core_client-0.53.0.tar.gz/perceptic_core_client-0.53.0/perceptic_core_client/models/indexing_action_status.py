from enum import Enum


class IndexingActionStatus(str, Enum):
    EXECUTING = "EXECUTING"
    FAILED = "FAILED"
    PENDING = "PENDING"
    SUCCEEDED = "SUCCEEDED"

    def __str__(self) -> str:
        return str(self.value)
