from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.managed_file_system_api_dto import ManagedFileSystemApiDto
    from ..models.remote_file_system_api_dto import RemoteFileSystemApiDto


T = TypeVar("T", bound="ListAllFileSystemsResponseFileSystems")


@_attrs_define
class ListAllFileSystemsResponseFileSystems:
    """ """

    additional_properties: dict[str, ManagedFileSystemApiDto | RemoteFileSystemApiDto] = _attrs_field(
        init=False, factory=dict
    )

    def to_dict(self) -> dict[str, Any]:
        from ..models.remote_file_system_api_dto import RemoteFileSystemApiDto

        field_dict: dict[str, Any] = {}
        for prop_name, prop in self.additional_properties.items():
            if isinstance(prop, RemoteFileSystemApiDto):
                field_dict[prop_name] = prop.to_dict()
            else:
                field_dict[prop_name] = prop.to_dict()

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.managed_file_system_api_dto import ManagedFileSystemApiDto
        from ..models.remote_file_system_api_dto import RemoteFileSystemApiDto

        d = dict(src_dict)
        list_all_file_systems_response_file_systems = cls()

        additional_properties = {}
        for prop_name, prop_dict in d.items():

            def _parse_additional_property(data: object) -> ManagedFileSystemApiDto | RemoteFileSystemApiDto:
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    componentsschemas_file_system_api_dto_type_0 = RemoteFileSystemApiDto.from_dict(data)

                    return componentsschemas_file_system_api_dto_type_0
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_file_system_api_dto_type_1 = ManagedFileSystemApiDto.from_dict(data)

                return componentsschemas_file_system_api_dto_type_1

            additional_property = _parse_additional_property(prop_dict)

            additional_properties[prop_name] = additional_property

        list_all_file_systems_response_file_systems.additional_properties = additional_properties
        return list_all_file_systems_response_file_systems

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> ManagedFileSystemApiDto | RemoteFileSystemApiDto:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: ManagedFileSystemApiDto | RemoteFileSystemApiDto) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
