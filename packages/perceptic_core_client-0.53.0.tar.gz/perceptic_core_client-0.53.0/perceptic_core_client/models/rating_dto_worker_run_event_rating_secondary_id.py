from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.worker_run_event_rating_secondary_id import WorkerRunEventRatingSecondaryId


T = TypeVar("T", bound="RatingDtoWorkerRunEventRatingSecondaryId")


@_attrs_define
class RatingDtoWorkerRunEventRatingSecondaryId:
    """
    Attributes:
        id (UUID | Unset):
        grade (float | Unset):
        written_feedback (str | Unset):
        secondary_id (WorkerRunEventRatingSecondaryId | Unset):
    """

    id: UUID | Unset = UNSET
    grade: float | Unset = UNSET
    written_feedback: str | Unset = UNSET
    secondary_id: WorkerRunEventRatingSecondaryId | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id: str | Unset = UNSET
        if not isinstance(self.id, Unset):
            id = str(self.id)

        grade = self.grade

        written_feedback = self.written_feedback

        secondary_id: dict[str, Any] | Unset = UNSET
        if not isinstance(self.secondary_id, Unset):
            secondary_id = self.secondary_id.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if grade is not UNSET:
            field_dict["grade"] = grade
        if written_feedback is not UNSET:
            field_dict["writtenFeedback"] = written_feedback
        if secondary_id is not UNSET:
            field_dict["secondaryId"] = secondary_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.worker_run_event_rating_secondary_id import WorkerRunEventRatingSecondaryId

        d = dict(src_dict)
        _id = d.pop("id", UNSET)
        id: UUID | Unset
        if isinstance(_id, Unset):
            id = UNSET
        else:
            id = UUID(_id)

        grade = d.pop("grade", UNSET)

        written_feedback = d.pop("writtenFeedback", UNSET)

        _secondary_id = d.pop("secondaryId", UNSET)
        secondary_id: WorkerRunEventRatingSecondaryId | Unset
        if isinstance(_secondary_id, Unset):
            secondary_id = UNSET
        else:
            secondary_id = WorkerRunEventRatingSecondaryId.from_dict(_secondary_id)

        rating_dto_worker_run_event_rating_secondary_id = cls(
            id=id,
            grade=grade,
            written_feedback=written_feedback,
            secondary_id=secondary_id,
        )

        rating_dto_worker_run_event_rating_secondary_id.additional_properties = d
        return rating_dto_worker_run_event_rating_secondary_id

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
