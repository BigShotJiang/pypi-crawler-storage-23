from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.image_detection_box_api_dto import ImageDetectionBoxApiDto


T = TypeVar("T", bound="BiotechAnalysisApiDto")


@_attrs_define
class BiotechAnalysisApiDto:
    """
    Attributes:
        raw_analysis (str | Unset):
        compound_data_present (bool | Unset):
        compounds (list[str] | Unset):
        development_stage (str | Unset):
        therapeutic_area (str | Unset):
        key_findings (list[str] | Unset):
        risks (list[str] | Unset):
        market_potential (str | Unset):
        confidence (float | Unset):
        reasoning (str | Unset):
        bounding_boxes (list[ImageDetectionBoxApiDto] | Unset):
        page_index (int | Unset):
        character_count (int | Unset):
    """

    raw_analysis: str | Unset = UNSET
    compound_data_present: bool | Unset = UNSET
    compounds: list[str] | Unset = UNSET
    development_stage: str | Unset = UNSET
    therapeutic_area: str | Unset = UNSET
    key_findings: list[str] | Unset = UNSET
    risks: list[str] | Unset = UNSET
    market_potential: str | Unset = UNSET
    confidence: float | Unset = UNSET
    reasoning: str | Unset = UNSET
    bounding_boxes: list[ImageDetectionBoxApiDto] | Unset = UNSET
    page_index: int | Unset = UNSET
    character_count: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        raw_analysis = self.raw_analysis

        compound_data_present = self.compound_data_present

        compounds: list[str] | Unset = UNSET
        if not isinstance(self.compounds, Unset):
            compounds = self.compounds

        development_stage = self.development_stage

        therapeutic_area = self.therapeutic_area

        key_findings: list[str] | Unset = UNSET
        if not isinstance(self.key_findings, Unset):
            key_findings = self.key_findings

        risks: list[str] | Unset = UNSET
        if not isinstance(self.risks, Unset):
            risks = self.risks

        market_potential = self.market_potential

        confidence = self.confidence

        reasoning = self.reasoning

        bounding_boxes: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.bounding_boxes, Unset):
            bounding_boxes = []
            for bounding_boxes_item_data in self.bounding_boxes:
                bounding_boxes_item = bounding_boxes_item_data.to_dict()
                bounding_boxes.append(bounding_boxes_item)

        page_index = self.page_index

        character_count = self.character_count

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if raw_analysis is not UNSET:
            field_dict["rawAnalysis"] = raw_analysis
        if compound_data_present is not UNSET:
            field_dict["compoundDataPresent"] = compound_data_present
        if compounds is not UNSET:
            field_dict["compounds"] = compounds
        if development_stage is not UNSET:
            field_dict["developmentStage"] = development_stage
        if therapeutic_area is not UNSET:
            field_dict["therapeuticArea"] = therapeutic_area
        if key_findings is not UNSET:
            field_dict["keyFindings"] = key_findings
        if risks is not UNSET:
            field_dict["risks"] = risks
        if market_potential is not UNSET:
            field_dict["marketPotential"] = market_potential
        if confidence is not UNSET:
            field_dict["confidence"] = confidence
        if reasoning is not UNSET:
            field_dict["reasoning"] = reasoning
        if bounding_boxes is not UNSET:
            field_dict["boundingBoxes"] = bounding_boxes
        if page_index is not UNSET:
            field_dict["pageIndex"] = page_index
        if character_count is not UNSET:
            field_dict["characterCount"] = character_count

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.image_detection_box_api_dto import ImageDetectionBoxApiDto

        d = dict(src_dict)
        raw_analysis = d.pop("rawAnalysis", UNSET)

        compound_data_present = d.pop("compoundDataPresent", UNSET)

        compounds = cast(list[str], d.pop("compounds", UNSET))

        development_stage = d.pop("developmentStage", UNSET)

        therapeutic_area = d.pop("therapeuticArea", UNSET)

        key_findings = cast(list[str], d.pop("keyFindings", UNSET))

        risks = cast(list[str], d.pop("risks", UNSET))

        market_potential = d.pop("marketPotential", UNSET)

        confidence = d.pop("confidence", UNSET)

        reasoning = d.pop("reasoning", UNSET)

        _bounding_boxes = d.pop("boundingBoxes", UNSET)
        bounding_boxes: list[ImageDetectionBoxApiDto] | Unset = UNSET
        if _bounding_boxes is not UNSET:
            bounding_boxes = []
            for bounding_boxes_item_data in _bounding_boxes:
                bounding_boxes_item = ImageDetectionBoxApiDto.from_dict(bounding_boxes_item_data)

                bounding_boxes.append(bounding_boxes_item)

        page_index = d.pop("pageIndex", UNSET)

        character_count = d.pop("characterCount", UNSET)

        biotech_analysis_api_dto = cls(
            raw_analysis=raw_analysis,
            compound_data_present=compound_data_present,
            compounds=compounds,
            development_stage=development_stage,
            therapeutic_area=therapeutic_area,
            key_findings=key_findings,
            risks=risks,
            market_potential=market_potential,
            confidence=confidence,
            reasoning=reasoning,
            bounding_boxes=bounding_boxes,
            page_index=page_index,
            character_count=character_count,
        )

        biotech_analysis_api_dto.additional_properties = d
        return biotech_analysis_api_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
