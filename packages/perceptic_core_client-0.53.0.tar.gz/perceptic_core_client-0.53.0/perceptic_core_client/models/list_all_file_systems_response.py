from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.list_all_file_systems_response_file_systems import ListAllFileSystemsResponseFileSystems


T = TypeVar("T", bound="ListAllFileSystemsResponse")


@_attrs_define
class ListAllFileSystemsResponse:
    """
    Attributes:
        file_systems (ListAllFileSystemsResponseFileSystems | Unset):
    """

    file_systems: ListAllFileSystemsResponseFileSystems | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        file_systems: dict[str, Any] | Unset = UNSET
        if not isinstance(self.file_systems, Unset):
            file_systems = self.file_systems.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if file_systems is not UNSET:
            field_dict["fileSystems"] = file_systems

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.list_all_file_systems_response_file_systems import ListAllFileSystemsResponseFileSystems

        d = dict(src_dict)
        _file_systems = d.pop("fileSystems", UNSET)
        file_systems: ListAllFileSystemsResponseFileSystems | Unset
        if isinstance(_file_systems, Unset):
            file_systems = UNSET
        else:
            file_systems = ListAllFileSystemsResponseFileSystems.from_dict(_file_systems)

        list_all_file_systems_response = cls(
            file_systems=file_systems,
        )

        list_all_file_systems_response.additional_properties = d
        return list_all_file_systems_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
