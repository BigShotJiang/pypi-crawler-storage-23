from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.query_workflow_response_result_type_0_item import QueryWorkflowResponseResultType0Item


T = TypeVar("T", bound="QueryWorkflowResponse")


@_attrs_define
class QueryWorkflowResponse:
    """
    Attributes:
        result (list[QueryWorkflowResponseResultType0Item] | None | Unset):
    """

    result: list[QueryWorkflowResponseResultType0Item] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        result: list[dict[str, Any]] | None | Unset
        if isinstance(self.result, Unset):
            result = UNSET
        elif isinstance(self.result, list):
            result = []
            for result_type_0_item_data in self.result:
                result_type_0_item = result_type_0_item_data.to_dict()
                result.append(result_type_0_item)

        else:
            result = self.result

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if result is not UNSET:
            field_dict["result"] = result

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.query_workflow_response_result_type_0_item import QueryWorkflowResponseResultType0Item

        d = dict(src_dict)

        def _parse_result(data: object) -> list[QueryWorkflowResponseResultType0Item] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                result_type_0 = []
                _result_type_0 = data
                for result_type_0_item_data in _result_type_0:
                    result_type_0_item = QueryWorkflowResponseResultType0Item.from_dict(result_type_0_item_data)

                    result_type_0.append(result_type_0_item)

                return result_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[QueryWorkflowResponseResultType0Item] | None | Unset, data)

        result = _parse_result(d.pop("result", UNSET))

        query_workflow_response = cls(
            result=result,
        )

        query_workflow_response.additional_properties = d
        return query_workflow_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
