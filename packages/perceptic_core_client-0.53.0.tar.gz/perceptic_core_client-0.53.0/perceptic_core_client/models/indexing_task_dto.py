from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.indexing_task_dto_settings import IndexingTaskDtoSettings
    from ..models.indexing_task_status import IndexingTaskStatus


T = TypeVar("T", bound="IndexingTaskDto")


@_attrs_define
class IndexingTaskDto:
    """
    Attributes:
        task_rid (str | Unset):
        indexer_rid (str | Unset):
        folder_uri (str | Unset):
        namespace (str | Unset):
        target_minimum_version (int | Unset):
        settings (IndexingTaskDtoSettings | Unset):
        created_at (datetime.datetime | Unset):
        status (IndexingTaskStatus | Unset):
    """

    task_rid: str | Unset = UNSET
    indexer_rid: str | Unset = UNSET
    folder_uri: str | Unset = UNSET
    namespace: str | Unset = UNSET
    target_minimum_version: int | Unset = UNSET
    settings: IndexingTaskDtoSettings | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    status: IndexingTaskStatus | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        task_rid = self.task_rid

        indexer_rid = self.indexer_rid

        folder_uri = self.folder_uri

        namespace = self.namespace

        target_minimum_version = self.target_minimum_version

        settings: dict[str, Any] | Unset = UNSET
        if not isinstance(self.settings, Unset):
            settings = self.settings.to_dict()

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        status: dict[str, Any] | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if task_rid is not UNSET:
            field_dict["taskRid"] = task_rid
        if indexer_rid is not UNSET:
            field_dict["indexerRid"] = indexer_rid
        if folder_uri is not UNSET:
            field_dict["folderUri"] = folder_uri
        if namespace is not UNSET:
            field_dict["namespace"] = namespace
        if target_minimum_version is not UNSET:
            field_dict["targetMinimumVersion"] = target_minimum_version
        if settings is not UNSET:
            field_dict["settings"] = settings
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.indexing_task_dto_settings import IndexingTaskDtoSettings
        from ..models.indexing_task_status import IndexingTaskStatus

        d = dict(src_dict)
        task_rid = d.pop("taskRid", UNSET)

        indexer_rid = d.pop("indexerRid", UNSET)

        folder_uri = d.pop("folderUri", UNSET)

        namespace = d.pop("namespace", UNSET)

        target_minimum_version = d.pop("targetMinimumVersion", UNSET)

        _settings = d.pop("settings", UNSET)
        settings: IndexingTaskDtoSettings | Unset
        if isinstance(_settings, Unset):
            settings = UNSET
        else:
            settings = IndexingTaskDtoSettings.from_dict(_settings)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _status = d.pop("status", UNSET)
        status: IndexingTaskStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = IndexingTaskStatus.from_dict(_status)

        indexing_task_dto = cls(
            task_rid=task_rid,
            indexer_rid=indexer_rid,
            folder_uri=folder_uri,
            namespace=namespace,
            target_minimum_version=target_minimum_version,
            settings=settings,
            created_at=created_at,
            status=status,
        )

        indexing_task_dto.additional_properties = d
        return indexing_task_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
