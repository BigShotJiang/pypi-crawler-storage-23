from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.indexing_schedule_dto import IndexingScheduleDto


T = TypeVar("T", bound="CreateIndexingScheduleResponse")


@_attrs_define
class CreateIndexingScheduleResponse:
    """
    Attributes:
        schedule_rid (str | Unset):
        schedule (IndexingScheduleDto | Unset):
    """

    schedule_rid: str | Unset = UNSET
    schedule: IndexingScheduleDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        schedule_rid = self.schedule_rid

        schedule: dict[str, Any] | Unset = UNSET
        if not isinstance(self.schedule, Unset):
            schedule = self.schedule.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if schedule_rid is not UNSET:
            field_dict["scheduleRid"] = schedule_rid
        if schedule is not UNSET:
            field_dict["schedule"] = schedule

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.indexing_schedule_dto import IndexingScheduleDto

        d = dict(src_dict)
        schedule_rid = d.pop("scheduleRid", UNSET)

        _schedule = d.pop("schedule", UNSET)
        schedule: IndexingScheduleDto | Unset
        if isinstance(_schedule, Unset):
            schedule = UNSET
        else:
            schedule = IndexingScheduleDto.from_dict(_schedule)

        create_indexing_schedule_response = cls(
            schedule_rid=schedule_rid,
            schedule=schedule,
        )

        create_indexing_schedule_response.additional_properties = d
        return create_indexing_schedule_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
