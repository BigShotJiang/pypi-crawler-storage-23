from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.worker_metadata_dto_input_schema import WorkerMetadataDtoInputSchema
    from ..models.worker_metadata_dto_response_schema import WorkerMetadataDtoResponseSchema


T = TypeVar("T", bound="WorkerMetadataDto")


@_attrs_define
class WorkerMetadataDto:
    """
    Attributes:
        version (str | Unset):
        description (str | Unset):
        input_schema (WorkerMetadataDtoInputSchema | Unset):
        response_schema (WorkerMetadataDtoResponseSchema | Unset):
    """

    version: str | Unset = UNSET
    description: str | Unset = UNSET
    input_schema: WorkerMetadataDtoInputSchema | Unset = UNSET
    response_schema: WorkerMetadataDtoResponseSchema | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        version = self.version

        description = self.description

        input_schema: dict[str, Any] | Unset = UNSET
        if not isinstance(self.input_schema, Unset):
            input_schema = self.input_schema.to_dict()

        response_schema: dict[str, Any] | Unset = UNSET
        if not isinstance(self.response_schema, Unset):
            response_schema = self.response_schema.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if version is not UNSET:
            field_dict["version"] = version
        if description is not UNSET:
            field_dict["description"] = description
        if input_schema is not UNSET:
            field_dict["inputSchema"] = input_schema
        if response_schema is not UNSET:
            field_dict["responseSchema"] = response_schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.worker_metadata_dto_input_schema import WorkerMetadataDtoInputSchema
        from ..models.worker_metadata_dto_response_schema import WorkerMetadataDtoResponseSchema

        d = dict(src_dict)
        version = d.pop("version", UNSET)

        description = d.pop("description", UNSET)

        _input_schema = d.pop("inputSchema", UNSET)
        input_schema: WorkerMetadataDtoInputSchema | Unset
        if isinstance(_input_schema, Unset):
            input_schema = UNSET
        else:
            input_schema = WorkerMetadataDtoInputSchema.from_dict(_input_schema)

        _response_schema = d.pop("responseSchema", UNSET)
        response_schema: WorkerMetadataDtoResponseSchema | Unset
        if isinstance(_response_schema, Unset):
            response_schema = UNSET
        else:
            response_schema = WorkerMetadataDtoResponseSchema.from_dict(_response_schema)

        worker_metadata_dto = cls(
            version=version,
            description=description,
            input_schema=input_schema,
            response_schema=response_schema,
        )

        worker_metadata_dto.additional_properties = d
        return worker_metadata_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
