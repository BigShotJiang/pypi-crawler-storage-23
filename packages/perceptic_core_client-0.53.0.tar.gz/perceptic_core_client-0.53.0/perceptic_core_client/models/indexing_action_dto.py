from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.action_type import ActionType
from ..models.indexing_action_status import IndexingActionStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="IndexingActionDto")


@_attrs_define
class IndexingActionDto:
    """
    Attributes:
        action_type (ActionType | Unset):
        target_uri (str | Unset):
        target_minimum_version (int | Unset):
        status (IndexingActionStatus | Unset):
        error_message (None | str | Unset):
        executed_at (datetime.datetime | None | Unset):
        reason (str | Unset):
    """

    action_type: ActionType | Unset = UNSET
    target_uri: str | Unset = UNSET
    target_minimum_version: int | Unset = UNSET
    status: IndexingActionStatus | Unset = UNSET
    error_message: None | str | Unset = UNSET
    executed_at: datetime.datetime | None | Unset = UNSET
    reason: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        action_type: str | Unset = UNSET
        if not isinstance(self.action_type, Unset):
            action_type = self.action_type.value

        target_uri = self.target_uri

        target_minimum_version = self.target_minimum_version

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        error_message: None | str | Unset
        if isinstance(self.error_message, Unset):
            error_message = UNSET
        else:
            error_message = self.error_message

        executed_at: None | str | Unset
        if isinstance(self.executed_at, Unset):
            executed_at = UNSET
        elif isinstance(self.executed_at, datetime.datetime):
            executed_at = self.executed_at.isoformat()
        else:
            executed_at = self.executed_at

        reason = self.reason

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if action_type is not UNSET:
            field_dict["actionType"] = action_type
        if target_uri is not UNSET:
            field_dict["targetUri"] = target_uri
        if target_minimum_version is not UNSET:
            field_dict["targetMinimumVersion"] = target_minimum_version
        if status is not UNSET:
            field_dict["status"] = status
        if error_message is not UNSET:
            field_dict["errorMessage"] = error_message
        if executed_at is not UNSET:
            field_dict["executedAt"] = executed_at
        if reason is not UNSET:
            field_dict["reason"] = reason

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _action_type = d.pop("actionType", UNSET)
        action_type: ActionType | Unset
        if isinstance(_action_type, Unset):
            action_type = UNSET
        else:
            action_type = ActionType(_action_type)

        target_uri = d.pop("targetUri", UNSET)

        target_minimum_version = d.pop("targetMinimumVersion", UNSET)

        _status = d.pop("status", UNSET)
        status: IndexingActionStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = IndexingActionStatus(_status)

        def _parse_error_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error_message = _parse_error_message(d.pop("errorMessage", UNSET))

        def _parse_executed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                executed_at_type_0 = isoparse(data)

                return executed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        executed_at = _parse_executed_at(d.pop("executedAt", UNSET))

        reason = d.pop("reason", UNSET)

        indexing_action_dto = cls(
            action_type=action_type,
            target_uri=target_uri,
            target_minimum_version=target_minimum_version,
            status=status,
            error_message=error_message,
            executed_at=executed_at,
            reason=reason,
        )

        indexing_action_dto.additional_properties = d
        return indexing_action_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
