from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.info_event import InfoEvent
    from ..models.progress_event import ProgressEvent
    from ..models.request_for_input_event import RequestForInputEvent


T = TypeVar("T", bound="GetWorkerEventsResponse")


@_attrs_define
class GetWorkerEventsResponse:
    """
    Attributes:
        events (list[InfoEvent | ProgressEvent | RequestForInputEvent] | Unset):
    """

    events: list[InfoEvent | ProgressEvent | RequestForInputEvent] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.info_event import InfoEvent
        from ..models.progress_event import ProgressEvent

        events: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.events, Unset):
            events = []
            for events_item_data in self.events:
                events_item: dict[str, Any]
                if isinstance(events_item_data, InfoEvent):
                    events_item = events_item_data.to_dict()
                elif isinstance(events_item_data, ProgressEvent):
                    events_item = events_item_data.to_dict()
                else:
                    events_item = events_item_data.to_dict()

                events.append(events_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if events is not UNSET:
            field_dict["events"] = events

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.info_event import InfoEvent
        from ..models.progress_event import ProgressEvent
        from ..models.request_for_input_event import RequestForInputEvent

        d = dict(src_dict)
        _events = d.pop("events", UNSET)
        events: list[InfoEvent | ProgressEvent | RequestForInputEvent] | Unset = UNSET
        if _events is not UNSET:
            events = []
            for events_item_data in _events:

                def _parse_events_item(data: object) -> InfoEvent | ProgressEvent | RequestForInputEvent:
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        componentsschemas_worker_event_type_0 = InfoEvent.from_dict(data)

                        return componentsschemas_worker_event_type_0
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        componentsschemas_worker_event_type_1 = ProgressEvent.from_dict(data)

                        return componentsschemas_worker_event_type_1
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    if not isinstance(data, dict):
                        raise TypeError()
                    componentsschemas_worker_event_type_2 = RequestForInputEvent.from_dict(data)

                    return componentsschemas_worker_event_type_2

                events_item = _parse_events_item(events_item_data)

                events.append(events_item)

        get_worker_events_response = cls(
            events=events,
        )

        get_worker_events_response.additional_properties = d
        return get_worker_events_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
