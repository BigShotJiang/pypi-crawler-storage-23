from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.biotech_analysis_api_dto import BiotechAnalysisApiDto


T = TypeVar("T", bound="BiotechAnalysisImageAnnotatedCitationApiDto")


@_attrs_define
class BiotechAnalysisImageAnnotatedCitationApiDto:
    """
    Attributes:
        analysis (BiotechAnalysisApiDto | Unset):
    """

    analysis: BiotechAnalysisApiDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        analysis: dict[str, Any] | Unset = UNSET
        if not isinstance(self.analysis, Unset):
            analysis = self.analysis.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if analysis is not UNSET:
            field_dict["analysis"] = analysis

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.biotech_analysis_api_dto import BiotechAnalysisApiDto

        d = dict(src_dict)
        _analysis = d.pop("analysis", UNSET)
        analysis: BiotechAnalysisApiDto | Unset
        if isinstance(_analysis, Unset):
            analysis = UNSET
        else:
            analysis = BiotechAnalysisApiDto.from_dict(_analysis)

        biotech_analysis_image_annotated_citation_api_dto = cls(
            analysis=analysis,
        )

        biotech_analysis_image_annotated_citation_api_dto.additional_properties = d
        return biotech_analysis_image_annotated_citation_api_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
