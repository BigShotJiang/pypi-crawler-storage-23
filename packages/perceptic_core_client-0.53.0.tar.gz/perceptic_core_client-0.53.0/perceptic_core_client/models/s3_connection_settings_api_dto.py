from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="S3ConnectionSettingsApiDto")


@_attrs_define
class S3ConnectionSettingsApiDto:
    """
    Attributes:
        region (str):
        access_key (str):
        secret_key (str):
        url (str):
        type_ (str | Unset):
    """

    region: str
    access_key: str
    secret_key: str
    url: str
    type_: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        region = self.region

        access_key = self.access_key

        secret_key = self.secret_key

        url = self.url

        type_ = self.type_

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "region": region,
                "accessKey": access_key,
                "secretKey": secret_key,
                "url": url,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        region = d.pop("region")

        access_key = d.pop("accessKey")

        secret_key = d.pop("secretKey")

        url = d.pop("url")

        type_ = d.pop("type", UNSET)

        s3_connection_settings_api_dto = cls(
            region=region,
            access_key=access_key,
            secret_key=secret_key,
            url=url,
            type_=type_,
        )

        s3_connection_settings_api_dto.additional_properties = d
        return s3_connection_settings_api_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
