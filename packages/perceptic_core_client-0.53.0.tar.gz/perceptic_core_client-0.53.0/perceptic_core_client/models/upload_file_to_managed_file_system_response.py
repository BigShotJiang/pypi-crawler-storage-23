from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="UploadFileToManagedFileSystemResponse")


@_attrs_define
class UploadFileToManagedFileSystemResponse:
    """
    Attributes:
        size_in_bytes (int | Unset):
    """

    size_in_bytes: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        size_in_bytes = self.size_in_bytes

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if size_in_bytes is not UNSET:
            field_dict["sizeInBytes"] = size_in_bytes

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        size_in_bytes = d.pop("sizeInBytes", UNSET)

        upload_file_to_managed_file_system_response = cls(
            size_in_bytes=size_in_bytes,
        )

        upload_file_to_managed_file_system_response.additional_properties = d
        return upload_file_to_managed_file_system_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
