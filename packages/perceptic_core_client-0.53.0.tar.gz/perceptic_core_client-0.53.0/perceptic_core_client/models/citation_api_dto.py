from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.biotech_analysis_image_annotated_citation_api_dto import BiotechAnalysisImageAnnotatedCitationApiDto
    from ..models.highlighted_text_citation_metadata_api_dto import HighlightedTextCitationMetadataApiDto
    from ..models.web_page_citation_metadata_api_dto import WebPageCitationMetadataApiDto


T = TypeVar("T", bound="CitationApiDto")


@_attrs_define
class CitationApiDto:
    """
    Attributes:
        id (str | Unset):
        input_uri (str | Unset):
        output_artifact_uri (None | str | Unset):
        metadata (BiotechAnalysisImageAnnotatedCitationApiDto | HighlightedTextCitationMetadataApiDto | Unset |
            WebPageCitationMetadataApiDto):
    """

    id: str | Unset = UNSET
    input_uri: str | Unset = UNSET
    output_artifact_uri: None | str | Unset = UNSET
    metadata: (
        BiotechAnalysisImageAnnotatedCitationApiDto
        | HighlightedTextCitationMetadataApiDto
        | Unset
        | WebPageCitationMetadataApiDto
    ) = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.highlighted_text_citation_metadata_api_dto import HighlightedTextCitationMetadataApiDto
        from ..models.web_page_citation_metadata_api_dto import WebPageCitationMetadataApiDto

        id = self.id

        input_uri = self.input_uri

        output_artifact_uri: None | str | Unset
        if isinstance(self.output_artifact_uri, Unset):
            output_artifact_uri = UNSET
        else:
            output_artifact_uri = self.output_artifact_uri

        metadata: dict[str, Any] | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, HighlightedTextCitationMetadataApiDto):
            metadata = self.metadata.to_dict()
        elif isinstance(self.metadata, WebPageCitationMetadataApiDto):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if input_uri is not UNSET:
            field_dict["inputUri"] = input_uri
        if output_artifact_uri is not UNSET:
            field_dict["outputArtifactUri"] = output_artifact_uri
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.biotech_analysis_image_annotated_citation_api_dto import (
            BiotechAnalysisImageAnnotatedCitationApiDto,
        )
        from ..models.highlighted_text_citation_metadata_api_dto import HighlightedTextCitationMetadataApiDto
        from ..models.web_page_citation_metadata_api_dto import WebPageCitationMetadataApiDto

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        input_uri = d.pop("inputUri", UNSET)

        def _parse_output_artifact_uri(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        output_artifact_uri = _parse_output_artifact_uri(d.pop("outputArtifactUri", UNSET))

        def _parse_metadata(
            data: object,
        ) -> (
            BiotechAnalysisImageAnnotatedCitationApiDto
            | HighlightedTextCitationMetadataApiDto
            | Unset
            | WebPageCitationMetadataApiDto
        ):
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_citation_metadata_api_dto_type_0 = HighlightedTextCitationMetadataApiDto.from_dict(
                    data
                )

                return componentsschemas_citation_metadata_api_dto_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_citation_metadata_api_dto_type_1 = WebPageCitationMetadataApiDto.from_dict(data)

                return componentsschemas_citation_metadata_api_dto_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            componentsschemas_citation_metadata_api_dto_type_2 = BiotechAnalysisImageAnnotatedCitationApiDto.from_dict(
                data
            )

            return componentsschemas_citation_metadata_api_dto_type_2

        metadata = _parse_metadata(d.pop("metadata", UNSET))

        citation_api_dto = cls(
            id=id,
            input_uri=input_uri,
            output_artifact_uri=output_artifact_uri,
            metadata=metadata,
        )

        citation_api_dto.additional_properties = d
        return citation_api_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
