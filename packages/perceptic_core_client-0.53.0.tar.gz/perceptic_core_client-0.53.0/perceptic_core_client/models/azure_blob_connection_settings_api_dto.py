from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="AzureBlobConnectionSettingsApiDto")


@_attrs_define
class AzureBlobConnectionSettingsApiDto:
    """
    Attributes:
        container (str):
        credential_name (str):
        credential_key (str):
        url (str):
        type_ (str | Unset):
    """

    container: str
    credential_name: str
    credential_key: str
    url: str
    type_: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        container = self.container

        credential_name = self.credential_name

        credential_key = self.credential_key

        url = self.url

        type_ = self.type_

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "container": container,
                "credentialName": credential_name,
                "credentialKey": credential_key,
                "url": url,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        container = d.pop("container")

        credential_name = d.pop("credentialName")

        credential_key = d.pop("credentialKey")

        url = d.pop("url")

        type_ = d.pop("type", UNSET)

        azure_blob_connection_settings_api_dto = cls(
            container=container,
            credential_name=credential_name,
            credential_key=credential_key,
            url=url,
            type_=type_,
        )

        azure_blob_connection_settings_api_dto.additional_properties = d
        return azure_blob_connection_settings_api_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
