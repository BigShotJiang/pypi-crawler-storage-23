from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.cron_trigger import CronTrigger
    from ..models.interval_trigger import IntervalTrigger
    from ..models.on_upload_trigger import OnUploadTrigger
    from ..models.update_indexing_schedule_request_indexing_settings_type_0 import (
        UpdateIndexingScheduleRequestIndexingSettingsType0,
    )


T = TypeVar("T", bound="UpdateIndexingScheduleRequest")


@_attrs_define
class UpdateIndexingScheduleRequest:
    """
    Attributes:
        name (None | str | Unset): Updated display name
        description (None | str | Unset): Updated description
        target_minimum_version (int | None | Unset): Updated minimum indexer version
        indexing_settings (None | Unset | UpdateIndexingScheduleRequestIndexingSettingsType0): Updated indexer-specific
            settings
        trigger (CronTrigger | IntervalTrigger | None | OnUploadTrigger | Unset): Updated trigger configuration
        enabled (bool | None | Unset): Updated enabled status
    """

    name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    target_minimum_version: int | None | Unset = UNSET
    indexing_settings: None | Unset | UpdateIndexingScheduleRequestIndexingSettingsType0 = UNSET
    trigger: CronTrigger | IntervalTrigger | None | OnUploadTrigger | Unset = UNSET
    enabled: bool | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.cron_trigger import CronTrigger
        from ..models.interval_trigger import IntervalTrigger
        from ..models.on_upload_trigger import OnUploadTrigger
        from ..models.update_indexing_schedule_request_indexing_settings_type_0 import (
            UpdateIndexingScheduleRequestIndexingSettingsType0,
        )

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        target_minimum_version: int | None | Unset
        if isinstance(self.target_minimum_version, Unset):
            target_minimum_version = UNSET
        else:
            target_minimum_version = self.target_minimum_version

        indexing_settings: dict[str, Any] | None | Unset
        if isinstance(self.indexing_settings, Unset):
            indexing_settings = UNSET
        elif isinstance(self.indexing_settings, UpdateIndexingScheduleRequestIndexingSettingsType0):
            indexing_settings = self.indexing_settings.to_dict()
        else:
            indexing_settings = self.indexing_settings

        trigger: dict[str, Any] | None | Unset
        if isinstance(self.trigger, Unset):
            trigger = UNSET
        elif isinstance(self.trigger, OnUploadTrigger):
            trigger = self.trigger.to_dict()
        elif isinstance(self.trigger, CronTrigger):
            trigger = self.trigger.to_dict()
        elif isinstance(self.trigger, IntervalTrigger):
            trigger = self.trigger.to_dict()
        else:
            trigger = self.trigger

        enabled: bool | None | Unset
        if isinstance(self.enabled, Unset):
            enabled = UNSET
        else:
            enabled = self.enabled

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if target_minimum_version is not UNSET:
            field_dict["targetMinimumVersion"] = target_minimum_version
        if indexing_settings is not UNSET:
            field_dict["indexingSettings"] = indexing_settings
        if trigger is not UNSET:
            field_dict["trigger"] = trigger
        if enabled is not UNSET:
            field_dict["enabled"] = enabled

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.cron_trigger import CronTrigger
        from ..models.interval_trigger import IntervalTrigger
        from ..models.on_upload_trigger import OnUploadTrigger
        from ..models.update_indexing_schedule_request_indexing_settings_type_0 import (
            UpdateIndexingScheduleRequestIndexingSettingsType0,
        )

        d = dict(src_dict)

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_target_minimum_version(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        target_minimum_version = _parse_target_minimum_version(d.pop("targetMinimumVersion", UNSET))

        def _parse_indexing_settings(data: object) -> None | Unset | UpdateIndexingScheduleRequestIndexingSettingsType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                indexing_settings_type_0 = UpdateIndexingScheduleRequestIndexingSettingsType0.from_dict(data)

                return indexing_settings_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UpdateIndexingScheduleRequestIndexingSettingsType0, data)

        indexing_settings = _parse_indexing_settings(d.pop("indexingSettings", UNSET))

        def _parse_trigger(data: object) -> CronTrigger | IntervalTrigger | None | OnUploadTrigger | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_schedule_trigger_type_0 = OnUploadTrigger.from_dict(data)

                return componentsschemas_schedule_trigger_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_schedule_trigger_type_1 = CronTrigger.from_dict(data)

                return componentsschemas_schedule_trigger_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_schedule_trigger_type_2 = IntervalTrigger.from_dict(data)

                return componentsschemas_schedule_trigger_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CronTrigger | IntervalTrigger | None | OnUploadTrigger | Unset, data)

        trigger = _parse_trigger(d.pop("trigger", UNSET))

        def _parse_enabled(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        enabled = _parse_enabled(d.pop("enabled", UNSET))

        update_indexing_schedule_request = cls(
            name=name,
            description=description,
            target_minimum_version=target_minimum_version,
            indexing_settings=indexing_settings,
            trigger=trigger,
            enabled=enabled,
        )

        update_indexing_schedule_request.additional_properties = d
        return update_indexing_schedule_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
