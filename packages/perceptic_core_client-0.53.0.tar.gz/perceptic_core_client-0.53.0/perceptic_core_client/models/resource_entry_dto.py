from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.resource_metadata_dto import ResourceMetadataDto


T = TypeVar("T", bound="ResourceEntryDto")


@_attrs_define
class ResourceEntryDto:
    """
    Attributes:
        resource_id (str | Unset):
        metadata (ResourceMetadataDto | Unset):
    """

    resource_id: str | Unset = UNSET
    metadata: ResourceMetadataDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        resource_id = self.resource_id

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if resource_id is not UNSET:
            field_dict["resourceId"] = resource_id
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.resource_metadata_dto import ResourceMetadataDto

        d = dict(src_dict)
        resource_id = d.pop("resourceId", UNSET)

        _metadata = d.pop("metadata", UNSET)
        metadata: ResourceMetadataDto | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = ResourceMetadataDto.from_dict(_metadata)

        resource_entry_dto = cls(
            resource_id=resource_id,
            metadata=metadata,
        )

        resource_entry_dto.additional_properties = d
        return resource_entry_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
