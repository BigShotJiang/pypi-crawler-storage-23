from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.rating_dto_worker_run_event_rating_secondary_id import RatingDtoWorkerRunEventRatingSecondaryId


T = TypeVar("T", bound="GetRunEventRatingResponse")


@_attrs_define
class GetRunEventRatingResponse:
    """
    Attributes:
        rating (RatingDtoWorkerRunEventRatingSecondaryId | Unset):
    """

    rating: RatingDtoWorkerRunEventRatingSecondaryId | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        rating: dict[str, Any] | Unset = UNSET
        if not isinstance(self.rating, Unset):
            rating = self.rating.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if rating is not UNSET:
            field_dict["rating"] = rating

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rating_dto_worker_run_event_rating_secondary_id import RatingDtoWorkerRunEventRatingSecondaryId

        d = dict(src_dict)
        _rating = d.pop("rating", UNSET)
        rating: RatingDtoWorkerRunEventRatingSecondaryId | Unset
        if isinstance(_rating, Unset):
            rating = UNSET
        else:
            rating = RatingDtoWorkerRunEventRatingSecondaryId.from_dict(_rating)

        get_run_event_rating_response = cls(
            rating=rating,
        )

        get_run_event_rating_response.additional_properties = d
        return get_run_event_rating_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
