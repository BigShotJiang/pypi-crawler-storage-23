from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.run_status_dto import RunStatusDto
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.get_worker_run_response_inputs import GetWorkerRunResponseInputs


T = TypeVar("T", bound="GetWorkerRunResponse")


@_attrs_define
class GetWorkerRunResponse:
    """
    Attributes:
        run_rid (str | Unset):
        status (RunStatusDto | Unset):
        started_by_user_id (str | Unset):
        created_at (datetime.datetime | Unset):
        inputs (GetWorkerRunResponseInputs | Unset):
    """

    run_rid: str | Unset = UNSET
    status: RunStatusDto | Unset = UNSET
    started_by_user_id: str | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    inputs: GetWorkerRunResponseInputs | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        run_rid = self.run_rid

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        started_by_user_id = self.started_by_user_id

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        inputs: dict[str, Any] | Unset = UNSET
        if not isinstance(self.inputs, Unset):
            inputs = self.inputs.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if run_rid is not UNSET:
            field_dict["runRid"] = run_rid
        if status is not UNSET:
            field_dict["status"] = status
        if started_by_user_id is not UNSET:
            field_dict["startedByUserId"] = started_by_user_id
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if inputs is not UNSET:
            field_dict["inputs"] = inputs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_worker_run_response_inputs import GetWorkerRunResponseInputs

        d = dict(src_dict)
        run_rid = d.pop("runRid", UNSET)

        _status = d.pop("status", UNSET)
        status: RunStatusDto | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = RunStatusDto(_status)

        started_by_user_id = d.pop("startedByUserId", UNSET)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _inputs = d.pop("inputs", UNSET)
        inputs: GetWorkerRunResponseInputs | Unset
        if isinstance(_inputs, Unset):
            inputs = UNSET
        else:
            inputs = GetWorkerRunResponseInputs.from_dict(_inputs)

        get_worker_run_response = cls(
            run_rid=run_rid,
            status=status,
            started_by_user_id=started_by_user_id,
            created_at=created_at,
            inputs=inputs,
        )

        get_worker_run_response.additional_properties = d
        return get_worker_run_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
