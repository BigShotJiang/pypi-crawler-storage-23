from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.orchestrator_status import OrchestratorStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.workflow_status import WorkflowStatus


T = TypeVar("T", bound="WorkflowStatusResponse")


@_attrs_define
class WorkflowStatusResponse:
    """
    Attributes:
        workflow_rid (str | Unset):
        orchestrator_status (OrchestratorStatus | Unset):
        workflow_status (None | Unset | WorkflowStatus):
    """

    workflow_rid: str | Unset = UNSET
    orchestrator_status: OrchestratorStatus | Unset = UNSET
    workflow_status: None | Unset | WorkflowStatus = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.workflow_status import WorkflowStatus

        workflow_rid = self.workflow_rid

        orchestrator_status: str | Unset = UNSET
        if not isinstance(self.orchestrator_status, Unset):
            orchestrator_status = self.orchestrator_status.value

        workflow_status: dict[str, Any] | None | Unset
        if isinstance(self.workflow_status, Unset):
            workflow_status = UNSET
        elif isinstance(self.workflow_status, WorkflowStatus):
            workflow_status = self.workflow_status.to_dict()
        else:
            workflow_status = self.workflow_status

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if workflow_rid is not UNSET:
            field_dict["workflowRid"] = workflow_rid
        if orchestrator_status is not UNSET:
            field_dict["orchestratorStatus"] = orchestrator_status
        if workflow_status is not UNSET:
            field_dict["workflowStatus"] = workflow_status

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.workflow_status import WorkflowStatus

        d = dict(src_dict)
        workflow_rid = d.pop("workflowRid", UNSET)

        _orchestrator_status = d.pop("orchestratorStatus", UNSET)
        orchestrator_status: OrchestratorStatus | Unset
        if isinstance(_orchestrator_status, Unset):
            orchestrator_status = UNSET
        else:
            orchestrator_status = OrchestratorStatus(_orchestrator_status)

        def _parse_workflow_status(data: object) -> None | Unset | WorkflowStatus:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                workflow_status_type_0 = WorkflowStatus.from_dict(data)

                return workflow_status_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | WorkflowStatus, data)

        workflow_status = _parse_workflow_status(d.pop("workflowStatus", UNSET))

        workflow_status_response = cls(
            workflow_rid=workflow_rid,
            orchestrator_status=orchestrator_status,
            workflow_status=workflow_status,
        )

        workflow_status_response.additional_properties = d
        return workflow_status_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
