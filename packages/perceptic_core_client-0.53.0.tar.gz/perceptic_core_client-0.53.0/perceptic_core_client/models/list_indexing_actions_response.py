from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.indexing_action_dto import IndexingActionDto


T = TypeVar("T", bound="ListIndexingActionsResponse")


@_attrs_define
class ListIndexingActionsResponse:
    """
    Attributes:
        actions (list[IndexingActionDto] | Unset):
        total_actions (int | Unset):
        next_offset (int | None | Unset):
        pending_count (int | Unset):
        executing_count (int | Unset):
        succeeded_count (int | Unset):
        failed_count (int | Unset):
        index_count (int | Unset):
        delete_count (int | Unset):
    """

    actions: list[IndexingActionDto] | Unset = UNSET
    total_actions: int | Unset = UNSET
    next_offset: int | None | Unset = UNSET
    pending_count: int | Unset = UNSET
    executing_count: int | Unset = UNSET
    succeeded_count: int | Unset = UNSET
    failed_count: int | Unset = UNSET
    index_count: int | Unset = UNSET
    delete_count: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        actions: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.actions, Unset):
            actions = []
            for actions_item_data in self.actions:
                actions_item = actions_item_data.to_dict()
                actions.append(actions_item)

        total_actions = self.total_actions

        next_offset: int | None | Unset
        if isinstance(self.next_offset, Unset):
            next_offset = UNSET
        else:
            next_offset = self.next_offset

        pending_count = self.pending_count

        executing_count = self.executing_count

        succeeded_count = self.succeeded_count

        failed_count = self.failed_count

        index_count = self.index_count

        delete_count = self.delete_count

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if actions is not UNSET:
            field_dict["actions"] = actions
        if total_actions is not UNSET:
            field_dict["totalActions"] = total_actions
        if next_offset is not UNSET:
            field_dict["nextOffset"] = next_offset
        if pending_count is not UNSET:
            field_dict["pendingCount"] = pending_count
        if executing_count is not UNSET:
            field_dict["executingCount"] = executing_count
        if succeeded_count is not UNSET:
            field_dict["succeededCount"] = succeeded_count
        if failed_count is not UNSET:
            field_dict["failedCount"] = failed_count
        if index_count is not UNSET:
            field_dict["indexCount"] = index_count
        if delete_count is not UNSET:
            field_dict["deleteCount"] = delete_count

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.indexing_action_dto import IndexingActionDto

        d = dict(src_dict)
        _actions = d.pop("actions", UNSET)
        actions: list[IndexingActionDto] | Unset = UNSET
        if _actions is not UNSET:
            actions = []
            for actions_item_data in _actions:
                actions_item = IndexingActionDto.from_dict(actions_item_data)

                actions.append(actions_item)

        total_actions = d.pop("totalActions", UNSET)

        def _parse_next_offset(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        next_offset = _parse_next_offset(d.pop("nextOffset", UNSET))

        pending_count = d.pop("pendingCount", UNSET)

        executing_count = d.pop("executingCount", UNSET)

        succeeded_count = d.pop("succeededCount", UNSET)

        failed_count = d.pop("failedCount", UNSET)

        index_count = d.pop("indexCount", UNSET)

        delete_count = d.pop("deleteCount", UNSET)

        list_indexing_actions_response = cls(
            actions=actions,
            total_actions=total_actions,
            next_offset=next_offset,
            pending_count=pending_count,
            executing_count=executing_count,
            succeeded_count=succeeded_count,
            failed_count=failed_count,
            index_count=index_count,
            delete_count=delete_count,
        )

        list_indexing_actions_response.additional_properties = d
        return list_indexing_actions_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
