from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.user_info_response import UserInfoResponse


T = TypeVar("T", bound="ListUsersResponse")


@_attrs_define
class ListUsersResponse:
    """Paginated list of users response

    Attributes:
        users (list[UserInfoResponse] | Unset): List of users
        total_count (int | Unset): Total count of users matching the query
        next_offset (int | None | Unset): Next offset for pagination, empty if no more results
    """

    users: list[UserInfoResponse] | Unset = UNSET
    total_count: int | Unset = UNSET
    next_offset: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        users: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.users, Unset):
            users = []
            for users_item_data in self.users:
                users_item = users_item_data.to_dict()
                users.append(users_item)

        total_count = self.total_count

        next_offset: int | None | Unset
        if isinstance(self.next_offset, Unset):
            next_offset = UNSET
        else:
            next_offset = self.next_offset

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if users is not UNSET:
            field_dict["users"] = users
        if total_count is not UNSET:
            field_dict["totalCount"] = total_count
        if next_offset is not UNSET:
            field_dict["nextOffset"] = next_offset

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_info_response import UserInfoResponse

        d = dict(src_dict)
        _users = d.pop("users", UNSET)
        users: list[UserInfoResponse] | Unset = UNSET
        if _users is not UNSET:
            users = []
            for users_item_data in _users:
                users_item = UserInfoResponse.from_dict(users_item_data)

                users.append(users_item)

        total_count = d.pop("totalCount", UNSET)

        def _parse_next_offset(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        next_offset = _parse_next_offset(d.pop("nextOffset", UNSET))

        list_users_response = cls(
            users=users,
            total_count=total_count,
            next_offset=next_offset,
        )

        list_users_response.additional_properties = d
        return list_users_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
