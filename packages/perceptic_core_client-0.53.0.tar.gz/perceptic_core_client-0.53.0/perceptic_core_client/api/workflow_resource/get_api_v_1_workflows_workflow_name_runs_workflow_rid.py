from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.workflow_status_response import WorkflowStatusResponse
from ...types import Response


def _get_kwargs(
    workflow_name: str,
    workflow_rid: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/workflows/{workflow_name}/runs/{workflow_rid}".format(
            workflow_name=quote(str(workflow_name), safe=""),
            workflow_rid=quote(str(workflow_rid), safe=""),
        ),
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> WorkflowStatusResponse | None:
    if response.status_code == 200:
        response_200 = WorkflowStatusResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[WorkflowStatusResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workflow_name: str,
    workflow_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[WorkflowStatusResponse]:
    """Get Workflow Status

    Args:
        workflow_name (str):
        workflow_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[WorkflowStatusResponse]
    """

    kwargs = _get_kwargs(
        workflow_name=workflow_name,
        workflow_rid=workflow_rid,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workflow_name: str,
    workflow_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> WorkflowStatusResponse | None:
    """Get Workflow Status

    Args:
        workflow_name (str):
        workflow_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        WorkflowStatusResponse
    """

    return sync_detailed(
        workflow_name=workflow_name,
        workflow_rid=workflow_rid,
        client=client,
    ).parsed


async def asyncio_detailed(
    workflow_name: str,
    workflow_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[WorkflowStatusResponse]:
    """Get Workflow Status

    Args:
        workflow_name (str):
        workflow_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[WorkflowStatusResponse]
    """

    kwargs = _get_kwargs(
        workflow_name=workflow_name,
        workflow_rid=workflow_rid,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workflow_name: str,
    workflow_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> WorkflowStatusResponse | None:
    """Get Workflow Status

    Args:
        workflow_name (str):
        workflow_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        WorkflowStatusResponse
    """

    return (
        await asyncio_detailed(
            workflow_name=workflow_name,
            workflow_rid=workflow_rid,
            client=client,
        )
    ).parsed
