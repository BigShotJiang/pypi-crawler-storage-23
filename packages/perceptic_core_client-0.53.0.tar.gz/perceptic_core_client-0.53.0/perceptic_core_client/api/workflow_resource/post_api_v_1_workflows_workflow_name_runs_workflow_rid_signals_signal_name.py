from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.send_workflow_signal_request import SendWorkflowSignalRequest
from ...models.send_workflow_signal_response import SendWorkflowSignalResponse
from ...types import Response


def _get_kwargs(
    workflow_name: str,
    workflow_rid: str,
    signal_name: str,
    *,
    body: SendWorkflowSignalRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/workflows/{workflow_name}/runs/{workflow_rid}/signals/{signal_name}".format(
            workflow_name=quote(str(workflow_name), safe=""),
            workflow_rid=quote(str(workflow_rid), safe=""),
            signal_name=quote(str(signal_name), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | SendWorkflowSignalResponse | None:
    if response.status_code == 200:
        response_200 = SendWorkflowSignalResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | SendWorkflowSignalResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workflow_name: str,
    workflow_rid: str,
    signal_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: SendWorkflowSignalRequest,
) -> Response[Any | SendWorkflowSignalResponse]:
    """Send Signal

    Args:
        workflow_name (str):
        workflow_rid (str):
        signal_name (str):
        body (SendWorkflowSignalRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | SendWorkflowSignalResponse]
    """

    kwargs = _get_kwargs(
        workflow_name=workflow_name,
        workflow_rid=workflow_rid,
        signal_name=signal_name,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workflow_name: str,
    workflow_rid: str,
    signal_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: SendWorkflowSignalRequest,
) -> Any | SendWorkflowSignalResponse | None:
    """Send Signal

    Args:
        workflow_name (str):
        workflow_rid (str):
        signal_name (str):
        body (SendWorkflowSignalRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | SendWorkflowSignalResponse
    """

    return sync_detailed(
        workflow_name=workflow_name,
        workflow_rid=workflow_rid,
        signal_name=signal_name,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    workflow_name: str,
    workflow_rid: str,
    signal_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: SendWorkflowSignalRequest,
) -> Response[Any | SendWorkflowSignalResponse]:
    """Send Signal

    Args:
        workflow_name (str):
        workflow_rid (str):
        signal_name (str):
        body (SendWorkflowSignalRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | SendWorkflowSignalResponse]
    """

    kwargs = _get_kwargs(
        workflow_name=workflow_name,
        workflow_rid=workflow_rid,
        signal_name=signal_name,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workflow_name: str,
    workflow_rid: str,
    signal_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: SendWorkflowSignalRequest,
) -> Any | SendWorkflowSignalResponse | None:
    """Send Signal

    Args:
        workflow_name (str):
        workflow_rid (str):
        signal_name (str):
        body (SendWorkflowSignalRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | SendWorkflowSignalResponse
    """

    return (
        await asyncio_detailed(
            workflow_name=workflow_name,
            workflow_rid=workflow_rid,
            signal_name=signal_name,
            client=client,
            body=body,
        )
    ).parsed
