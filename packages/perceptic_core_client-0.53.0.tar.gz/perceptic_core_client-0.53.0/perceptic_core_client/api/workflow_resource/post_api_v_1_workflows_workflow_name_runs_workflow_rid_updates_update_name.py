from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.invoke_workflow_update_request import InvokeWorkflowUpdateRequest
from ...models.invoke_workflow_update_response import InvokeWorkflowUpdateResponse
from ...types import Response


def _get_kwargs(
    workflow_name: str,
    workflow_rid: str,
    update_name: str,
    *,
    body: InvokeWorkflowUpdateRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/workflows/{workflow_name}/runs/{workflow_rid}/updates/{update_name}".format(
            workflow_name=quote(str(workflow_name), safe=""),
            workflow_rid=quote(str(workflow_rid), safe=""),
            update_name=quote(str(update_name), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | InvokeWorkflowUpdateResponse | None:
    if response.status_code == 200:
        response_200 = InvokeWorkflowUpdateResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | InvokeWorkflowUpdateResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workflow_name: str,
    workflow_rid: str,
    update_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: InvokeWorkflowUpdateRequest,
) -> Response[Any | InvokeWorkflowUpdateResponse]:
    """Invoke Update

    Args:
        workflow_name (str):
        workflow_rid (str):
        update_name (str):
        body (InvokeWorkflowUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | InvokeWorkflowUpdateResponse]
    """

    kwargs = _get_kwargs(
        workflow_name=workflow_name,
        workflow_rid=workflow_rid,
        update_name=update_name,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workflow_name: str,
    workflow_rid: str,
    update_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: InvokeWorkflowUpdateRequest,
) -> Any | InvokeWorkflowUpdateResponse | None:
    """Invoke Update

    Args:
        workflow_name (str):
        workflow_rid (str):
        update_name (str):
        body (InvokeWorkflowUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | InvokeWorkflowUpdateResponse
    """

    return sync_detailed(
        workflow_name=workflow_name,
        workflow_rid=workflow_rid,
        update_name=update_name,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    workflow_name: str,
    workflow_rid: str,
    update_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: InvokeWorkflowUpdateRequest,
) -> Response[Any | InvokeWorkflowUpdateResponse]:
    """Invoke Update

    Args:
        workflow_name (str):
        workflow_rid (str):
        update_name (str):
        body (InvokeWorkflowUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | InvokeWorkflowUpdateResponse]
    """

    kwargs = _get_kwargs(
        workflow_name=workflow_name,
        workflow_rid=workflow_rid,
        update_name=update_name,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workflow_name: str,
    workflow_rid: str,
    update_name: str,
    *,
    client: AuthenticatedClient | Client,
    body: InvokeWorkflowUpdateRequest,
) -> Any | InvokeWorkflowUpdateResponse | None:
    """Invoke Update

    Args:
        workflow_name (str):
        workflow_rid (str):
        update_name (str):
        body (InvokeWorkflowUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | InvokeWorkflowUpdateResponse
    """

    return (
        await asyncio_detailed(
            workflow_name=workflow_name,
            workflow_rid=workflow_rid,
            update_name=update_name,
            client=client,
            body=body,
        )
    ).parsed
