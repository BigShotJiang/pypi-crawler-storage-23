from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.start_execution_response import StartExecutionResponse
from ...types import Response


def _get_kwargs(
    task_rid: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/indexing/tasks/{task_rid}/execute".format(
            task_rid=quote(str(task_rid), safe=""),
        ),
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> StartExecutionResponse | None:
    if response.status_code == 200:
        response_200 = StartExecutionResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[StartExecutionResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    task_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[StartExecutionResponse]:
    """Start Execution

    Args:
        task_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[StartExecutionResponse]
    """

    kwargs = _get_kwargs(
        task_rid=task_rid,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    task_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> StartExecutionResponse | None:
    """Start Execution

    Args:
        task_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        StartExecutionResponse
    """

    return sync_detailed(
        task_rid=task_rid,
        client=client,
    ).parsed


async def asyncio_detailed(
    task_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[StartExecutionResponse]:
    """Start Execution

    Args:
        task_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[StartExecutionResponse]
    """

    kwargs = _get_kwargs(
        task_rid=task_rid,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    task_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> StartExecutionResponse | None:
    """Start Execution

    Args:
        task_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        StartExecutionResponse
    """

    return (
        await asyncio_detailed(
            task_rid=task_rid,
            client=client,
        )
    ).parsed
