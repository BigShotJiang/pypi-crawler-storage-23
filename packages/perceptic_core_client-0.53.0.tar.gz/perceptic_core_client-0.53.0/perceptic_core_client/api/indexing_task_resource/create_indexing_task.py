from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_indexing_task_request import CreateIndexingTaskRequest
from ...models.create_indexing_task_response import CreateIndexingTaskResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: CreateIndexingTaskRequest,
    dry_run: bool | Unset = False,
    freshness_minutes: int | Unset = 30,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["dryRun"] = dry_run

    params["freshnessMinutes"] = freshness_minutes

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/indexing/tasks",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | CreateIndexingTaskResponse | None:
    if response.status_code == 200:
        response_200 = CreateIndexingTaskResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | CreateIndexingTaskResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateIndexingTaskRequest,
    dry_run: bool | Unset = False,
    freshness_minutes: int | Unset = 30,
) -> Response[Any | CreateIndexingTaskResponse]:
    """Create Indexing Task

    Args:
        dry_run (bool | Unset):  Default: False.
        freshness_minutes (int | Unset):  Default: 30.
        body (CreateIndexingTaskRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CreateIndexingTaskResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        dry_run=dry_run,
        freshness_minutes=freshness_minutes,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateIndexingTaskRequest,
    dry_run: bool | Unset = False,
    freshness_minutes: int | Unset = 30,
) -> Any | CreateIndexingTaskResponse | None:
    """Create Indexing Task

    Args:
        dry_run (bool | Unset):  Default: False.
        freshness_minutes (int | Unset):  Default: 30.
        body (CreateIndexingTaskRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CreateIndexingTaskResponse
    """

    return sync_detailed(
        client=client,
        body=body,
        dry_run=dry_run,
        freshness_minutes=freshness_minutes,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateIndexingTaskRequest,
    dry_run: bool | Unset = False,
    freshness_minutes: int | Unset = 30,
) -> Response[Any | CreateIndexingTaskResponse]:
    """Create Indexing Task

    Args:
        dry_run (bool | Unset):  Default: False.
        freshness_minutes (int | Unset):  Default: 30.
        body (CreateIndexingTaskRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CreateIndexingTaskResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        dry_run=dry_run,
        freshness_minutes=freshness_minutes,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateIndexingTaskRequest,
    dry_run: bool | Unset = False,
    freshness_minutes: int | Unset = 30,
) -> Any | CreateIndexingTaskResponse | None:
    """Create Indexing Task

    Args:
        dry_run (bool | Unset):  Default: False.
        freshness_minutes (int | Unset):  Default: 30.
        body (CreateIndexingTaskRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CreateIndexingTaskResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            dry_run=dry_run,
            freshness_minutes=freshness_minutes,
        )
    ).parsed
