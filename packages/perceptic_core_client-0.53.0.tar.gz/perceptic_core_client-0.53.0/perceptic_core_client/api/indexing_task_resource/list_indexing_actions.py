from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.indexing_action_status import IndexingActionStatus
from ...models.list_indexing_actions_response import ListIndexingActionsResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    task_rid: str,
    *,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
    status: list[IndexingActionStatus] | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["offset"] = offset

    json_status: list[str] | Unset = UNSET
    if not isinstance(status, Unset):
        json_status = []
        for status_item_data in status:
            status_item = status_item_data.value
            json_status.append(status_item)

    params["status"] = json_status

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/indexing/tasks/{task_rid}/actions".format(
            task_rid=quote(str(task_rid), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ListIndexingActionsResponse | None:
    if response.status_code == 200:
        response_200 = ListIndexingActionsResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ListIndexingActionsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    task_rid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
    status: list[IndexingActionStatus] | Unset = UNSET,
) -> Response[ListIndexingActionsResponse]:
    """List Indexing Actions

    Args:
        task_rid (str):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.
        status (list[IndexingActionStatus] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListIndexingActionsResponse]
    """

    kwargs = _get_kwargs(
        task_rid=task_rid,
        limit=limit,
        offset=offset,
        status=status,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    task_rid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
    status: list[IndexingActionStatus] | Unset = UNSET,
) -> ListIndexingActionsResponse | None:
    """List Indexing Actions

    Args:
        task_rid (str):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.
        status (list[IndexingActionStatus] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListIndexingActionsResponse
    """

    return sync_detailed(
        task_rid=task_rid,
        client=client,
        limit=limit,
        offset=offset,
        status=status,
    ).parsed


async def asyncio_detailed(
    task_rid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
    status: list[IndexingActionStatus] | Unset = UNSET,
) -> Response[ListIndexingActionsResponse]:
    """List Indexing Actions

    Args:
        task_rid (str):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.
        status (list[IndexingActionStatus] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListIndexingActionsResponse]
    """

    kwargs = _get_kwargs(
        task_rid=task_rid,
        limit=limit,
        offset=offset,
        status=status,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    task_rid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
    status: list[IndexingActionStatus] | Unset = UNSET,
) -> ListIndexingActionsResponse | None:
    """List Indexing Actions

    Args:
        task_rid (str):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.
        status (list[IndexingActionStatus] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListIndexingActionsResponse
    """

    return (
        await asyncio_detailed(
            task_rid=task_rid,
            client=client,
            limit=limit,
            offset=offset,
            status=status,
        )
    ).parsed
