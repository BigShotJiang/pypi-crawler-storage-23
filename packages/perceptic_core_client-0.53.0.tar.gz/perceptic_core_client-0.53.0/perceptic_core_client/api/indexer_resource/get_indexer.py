from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_indexer_response import GetIndexerResponse
from ...types import Response


def _get_kwargs(
    indexer_rid: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/indexing/indexers/{indexer_rid}".format(
            indexer_rid=quote(str(indexer_rid), safe=""),
        ),
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetIndexerResponse | None:
    if response.status_code == 200:
        response_200 = GetIndexerResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[GetIndexerResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    indexer_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetIndexerResponse]:
    """Get Indexer

    Args:
        indexer_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetIndexerResponse]
    """

    kwargs = _get_kwargs(
        indexer_rid=indexer_rid,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    indexer_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> GetIndexerResponse | None:
    """Get Indexer

    Args:
        indexer_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetIndexerResponse
    """

    return sync_detailed(
        indexer_rid=indexer_rid,
        client=client,
    ).parsed


async def asyncio_detailed(
    indexer_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetIndexerResponse]:
    """Get Indexer

    Args:
        indexer_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetIndexerResponse]
    """

    kwargs = _get_kwargs(
        indexer_rid=indexer_rid,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    indexer_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> GetIndexerResponse | None:
    """Get Indexer

    Args:
        indexer_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetIndexerResponse
    """

    return (
        await asyncio_detailed(
            indexer_rid=indexer_rid,
            client=client,
        )
    ).parsed
