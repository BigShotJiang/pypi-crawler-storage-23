from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_worker_status_response import GetWorkerStatusResponse
from ...types import Response


def _get_kwargs(
    worker_id: str,
    run_rid: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/workers/{worker_id}/runs/{run_rid}/status".format(
            worker_id=quote(str(worker_id), safe=""),
            run_rid=quote(str(run_rid), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetWorkerStatusResponse | None:
    if response.status_code == 200:
        response_200 = GetWorkerStatusResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetWorkerStatusResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    worker_id: str,
    run_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetWorkerStatusResponse]:
    """Get Worker Run Status

    Args:
        worker_id (str): Unique identifier for a worker
        run_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWorkerStatusResponse]
    """

    kwargs = _get_kwargs(
        worker_id=worker_id,
        run_rid=run_rid,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    worker_id: str,
    run_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> GetWorkerStatusResponse | None:
    """Get Worker Run Status

    Args:
        worker_id (str): Unique identifier for a worker
        run_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWorkerStatusResponse
    """

    return sync_detailed(
        worker_id=worker_id,
        run_rid=run_rid,
        client=client,
    ).parsed


async def asyncio_detailed(
    worker_id: str,
    run_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetWorkerStatusResponse]:
    """Get Worker Run Status

    Args:
        worker_id (str): Unique identifier for a worker
        run_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWorkerStatusResponse]
    """

    kwargs = _get_kwargs(
        worker_id=worker_id,
        run_rid=run_rid,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    worker_id: str,
    run_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> GetWorkerStatusResponse | None:
    """Get Worker Run Status

    Args:
        worker_id (str): Unique identifier for a worker
        run_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWorkerStatusResponse
    """

    return (
        await asyncio_detailed(
            worker_id=worker_id,
            run_rid=run_rid,
            client=client,
        )
    ).parsed
