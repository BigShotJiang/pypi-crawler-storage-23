from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.post_worker_run_request import PostWorkerRunRequest
from ...models.post_worker_run_response import PostWorkerRunResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    worker_id: str,
    *,
    body: PostWorkerRunRequest,
    version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["version"] = version

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/workers/{worker_id}/runs".format(
            worker_id=quote(str(worker_id), safe=""),
        ),
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | PostWorkerRunResponse | None:
    if response.status_code == 200:
        response_200 = PostWorkerRunResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | PostWorkerRunResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    worker_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: PostWorkerRunRequest,
    version: str | Unset = UNSET,
) -> Response[Any | PostWorkerRunResponse]:
    """Post Worker Run

    Args:
        worker_id (str): Unique identifier for a worker
        version (str | Unset): The semantic version of the worker
        body (PostWorkerRunRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | PostWorkerRunResponse]
    """

    kwargs = _get_kwargs(
        worker_id=worker_id,
        body=body,
        version=version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    worker_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: PostWorkerRunRequest,
    version: str | Unset = UNSET,
) -> Any | PostWorkerRunResponse | None:
    """Post Worker Run

    Args:
        worker_id (str): Unique identifier for a worker
        version (str | Unset): The semantic version of the worker
        body (PostWorkerRunRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | PostWorkerRunResponse
    """

    return sync_detailed(
        worker_id=worker_id,
        client=client,
        body=body,
        version=version,
    ).parsed


async def asyncio_detailed(
    worker_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: PostWorkerRunRequest,
    version: str | Unset = UNSET,
) -> Response[Any | PostWorkerRunResponse]:
    """Post Worker Run

    Args:
        worker_id (str): Unique identifier for a worker
        version (str | Unset): The semantic version of the worker
        body (PostWorkerRunRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | PostWorkerRunResponse]
    """

    kwargs = _get_kwargs(
        worker_id=worker_id,
        body=body,
        version=version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    worker_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: PostWorkerRunRequest,
    version: str | Unset = UNSET,
) -> Any | PostWorkerRunResponse | None:
    """Post Worker Run

    Args:
        worker_id (str): Unique identifier for a worker
        version (str | Unset): The semantic version of the worker
        body (PostWorkerRunRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | PostWorkerRunResponse
    """

    return (
        await asyncio_detailed(
            worker_id=worker_id,
            client=client,
            body=body,
            version=version,
        )
    ).parsed
