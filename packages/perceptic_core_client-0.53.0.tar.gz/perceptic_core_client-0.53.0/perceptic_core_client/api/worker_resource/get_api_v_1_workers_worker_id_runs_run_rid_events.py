from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_worker_events_response import GetWorkerEventsResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    worker_id: str,
    run_rid: str,
    *,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/workers/{worker_id}/runs/{run_rid}/events".format(
            worker_id=quote(str(worker_id), safe=""),
            run_rid=quote(str(run_rid), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetWorkerEventsResponse | None:
    if response.status_code == 200:
        response_200 = GetWorkerEventsResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetWorkerEventsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    worker_id: str,
    run_rid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> Response[GetWorkerEventsResponse]:
    """Get Worker Run Events

    Args:
        worker_id (str): Unique identifier for a worker
        run_rid (str):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWorkerEventsResponse]
    """

    kwargs = _get_kwargs(
        worker_id=worker_id,
        run_rid=run_rid,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    worker_id: str,
    run_rid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> GetWorkerEventsResponse | None:
    """Get Worker Run Events

    Args:
        worker_id (str): Unique identifier for a worker
        run_rid (str):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWorkerEventsResponse
    """

    return sync_detailed(
        worker_id=worker_id,
        run_rid=run_rid,
        client=client,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    worker_id: str,
    run_rid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> Response[GetWorkerEventsResponse]:
    """Get Worker Run Events

    Args:
        worker_id (str): Unique identifier for a worker
        run_rid (str):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWorkerEventsResponse]
    """

    kwargs = _get_kwargs(
        worker_id=worker_id,
        run_rid=run_rid,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    worker_id: str,
    run_rid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> GetWorkerEventsResponse | None:
    """Get Worker Run Events

    Args:
        worker_id (str): Unique identifier for a worker
        run_rid (str):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWorkerEventsResponse
    """

    return (
        await asyncio_detailed(
            worker_id=worker_id,
            run_rid=run_rid,
            client=client,
            limit=limit,
            offset=offset,
        )
    ).parsed
