from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_worker_events_v2_response import GetWorkerEventsV2Response
from ...models.worker_v2_next_page_token import WorkerV2NextPageToken
from ...types import UNSET, Response, Unset


def _get_kwargs(
    worker_id: str,
    run_rid: str,
    *,
    limit: int | Unset = 50,
    next_page_token: WorkerV2NextPageToken | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    json_next_page_token: dict[str, Any] | Unset = UNSET
    if not isinstance(next_page_token, Unset):
        json_next_page_token = next_page_token.to_dict()
    if not isinstance(json_next_page_token, Unset):
        params.update(json_next_page_token)

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v2/workers/{worker_id}/runs/{run_rid}/events".format(
            worker_id=quote(str(worker_id), safe=""),
            run_rid=quote(str(run_rid), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetWorkerEventsV2Response | None:
    if response.status_code == 200:
        response_200 = GetWorkerEventsV2Response.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetWorkerEventsV2Response]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    worker_id: str,
    run_rid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    next_page_token: WorkerV2NextPageToken | Unset = UNSET,
) -> Response[GetWorkerEventsV2Response]:
    """Get Worker Run Events (v2)

     Returns worker events interleaved with user inputs as a single timeline. Pagination uses
    nextPageToken which contains offsets for both event types.

    Args:
        worker_id (str):
        run_rid (str):
        limit (int | Unset):  Default: 50.
        next_page_token (WorkerV2NextPageToken | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWorkerEventsV2Response]
    """

    kwargs = _get_kwargs(
        worker_id=worker_id,
        run_rid=run_rid,
        limit=limit,
        next_page_token=next_page_token,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    worker_id: str,
    run_rid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    next_page_token: WorkerV2NextPageToken | Unset = UNSET,
) -> GetWorkerEventsV2Response | None:
    """Get Worker Run Events (v2)

     Returns worker events interleaved with user inputs as a single timeline. Pagination uses
    nextPageToken which contains offsets for both event types.

    Args:
        worker_id (str):
        run_rid (str):
        limit (int | Unset):  Default: 50.
        next_page_token (WorkerV2NextPageToken | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWorkerEventsV2Response
    """

    return sync_detailed(
        worker_id=worker_id,
        run_rid=run_rid,
        client=client,
        limit=limit,
        next_page_token=next_page_token,
    ).parsed


async def asyncio_detailed(
    worker_id: str,
    run_rid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    next_page_token: WorkerV2NextPageToken | Unset = UNSET,
) -> Response[GetWorkerEventsV2Response]:
    """Get Worker Run Events (v2)

     Returns worker events interleaved with user inputs as a single timeline. Pagination uses
    nextPageToken which contains offsets for both event types.

    Args:
        worker_id (str):
        run_rid (str):
        limit (int | Unset):  Default: 50.
        next_page_token (WorkerV2NextPageToken | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWorkerEventsV2Response]
    """

    kwargs = _get_kwargs(
        worker_id=worker_id,
        run_rid=run_rid,
        limit=limit,
        next_page_token=next_page_token,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    worker_id: str,
    run_rid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    next_page_token: WorkerV2NextPageToken | Unset = UNSET,
) -> GetWorkerEventsV2Response | None:
    """Get Worker Run Events (v2)

     Returns worker events interleaved with user inputs as a single timeline. Pagination uses
    nextPageToken which contains offsets for both event types.

    Args:
        worker_id (str):
        run_rid (str):
        limit (int | Unset):  Default: 50.
        next_page_token (WorkerV2NextPageToken | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWorkerEventsV2Response
    """

    return (
        await asyncio_detailed(
            worker_id=worker_id,
            run_rid=run_rid,
            client=client,
            limit=limit,
            next_page_token=next_page_token,
        )
    ).parsed
