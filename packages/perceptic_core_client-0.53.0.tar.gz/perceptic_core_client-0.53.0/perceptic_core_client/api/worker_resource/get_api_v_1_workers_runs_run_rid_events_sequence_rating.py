from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_run_event_rating_response import GetRunEventRatingResponse
from ...types import Response


def _get_kwargs(
    run_rid: str,
    sequence: int,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/workers/runs/{run_rid}/events/{sequence}/rating".format(
            run_rid=quote(str(run_rid), safe=""),
            sequence=quote(str(sequence), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetRunEventRatingResponse | None:
    if response.status_code == 200:
        response_200 = GetRunEventRatingResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetRunEventRatingResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    run_rid: str,
    sequence: int,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetRunEventRatingResponse]:
    """Get Rating

    Args:
        run_rid (str):
        sequence (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetRunEventRatingResponse]
    """

    kwargs = _get_kwargs(
        run_rid=run_rid,
        sequence=sequence,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    run_rid: str,
    sequence: int,
    *,
    client: AuthenticatedClient | Client,
) -> GetRunEventRatingResponse | None:
    """Get Rating

    Args:
        run_rid (str):
        sequence (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetRunEventRatingResponse
    """

    return sync_detailed(
        run_rid=run_rid,
        sequence=sequence,
        client=client,
    ).parsed


async def asyncio_detailed(
    run_rid: str,
    sequence: int,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetRunEventRatingResponse]:
    """Get Rating

    Args:
        run_rid (str):
        sequence (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetRunEventRatingResponse]
    """

    kwargs = _get_kwargs(
        run_rid=run_rid,
        sequence=sequence,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    run_rid: str,
    sequence: int,
    *,
    client: AuthenticatedClient | Client,
) -> GetRunEventRatingResponse | None:
    """Get Rating

    Args:
        run_rid (str):
        sequence (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetRunEventRatingResponse
    """

    return (
        await asyncio_detailed(
            run_rid=run_rid,
            sequence=sequence,
            client=client,
        )
    ).parsed
