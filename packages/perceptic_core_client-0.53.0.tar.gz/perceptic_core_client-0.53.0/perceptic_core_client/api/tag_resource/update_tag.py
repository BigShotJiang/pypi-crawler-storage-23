from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.update_tag_request import UpdateTagRequest
from ...models.update_tag_response import UpdateTagResponse
from ...types import Response


def _get_kwargs(
    tag_rid: str,
    *,
    body: UpdateTagRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/v1/tags/{tag_rid}".format(
            tag_rid=quote(str(tag_rid), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | UpdateTagResponse | None:
    if response.status_code == 200:
        response_200 = UpdateTagResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | UpdateTagResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    tag_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateTagRequest,
) -> Response[Any | UpdateTagResponse]:
    """Update Tag

    Args:
        tag_rid (str):
        body (UpdateTagRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | UpdateTagResponse]
    """

    kwargs = _get_kwargs(
        tag_rid=tag_rid,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    tag_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateTagRequest,
) -> Any | UpdateTagResponse | None:
    """Update Tag

    Args:
        tag_rid (str):
        body (UpdateTagRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | UpdateTagResponse
    """

    return sync_detailed(
        tag_rid=tag_rid,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    tag_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateTagRequest,
) -> Response[Any | UpdateTagResponse]:
    """Update Tag

    Args:
        tag_rid (str):
        body (UpdateTagRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | UpdateTagResponse]
    """

    kwargs = _get_kwargs(
        tag_rid=tag_rid,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    tag_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateTagRequest,
) -> Any | UpdateTagResponse | None:
    """Update Tag

    Args:
        tag_rid (str):
        body (UpdateTagRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | UpdateTagResponse
    """

    return (
        await asyncio_detailed(
            tag_rid=tag_rid,
            client=client,
            body=body,
        )
    ).parsed
