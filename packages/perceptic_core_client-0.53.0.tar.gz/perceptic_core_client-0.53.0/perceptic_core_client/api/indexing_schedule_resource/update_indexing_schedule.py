from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.update_indexing_schedule_request import UpdateIndexingScheduleRequest
from ...models.update_indexing_schedule_response import UpdateIndexingScheduleResponse
from ...types import Response


def _get_kwargs(
    schedule_rid: str,
    *,
    body: UpdateIndexingScheduleRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/api/v1/indexing/schedules/{schedule_rid}".format(
            schedule_rid=quote(str(schedule_rid), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | UpdateIndexingScheduleResponse | None:
    if response.status_code == 200:
        response_200 = UpdateIndexingScheduleResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 409:
        response_409 = cast(Any, None)
        return response_409

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | UpdateIndexingScheduleResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    schedule_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateIndexingScheduleRequest,
) -> Response[Any | UpdateIndexingScheduleResponse]:
    """Update an indexing schedule

     Updates specific fields of an existing schedule. Only provided fields will be updated.

    Args:
        schedule_rid (str):
        body (UpdateIndexingScheduleRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | UpdateIndexingScheduleResponse]
    """

    kwargs = _get_kwargs(
        schedule_rid=schedule_rid,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    schedule_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateIndexingScheduleRequest,
) -> Any | UpdateIndexingScheduleResponse | None:
    """Update an indexing schedule

     Updates specific fields of an existing schedule. Only provided fields will be updated.

    Args:
        schedule_rid (str):
        body (UpdateIndexingScheduleRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | UpdateIndexingScheduleResponse
    """

    return sync_detailed(
        schedule_rid=schedule_rid,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    schedule_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateIndexingScheduleRequest,
) -> Response[Any | UpdateIndexingScheduleResponse]:
    """Update an indexing schedule

     Updates specific fields of an existing schedule. Only provided fields will be updated.

    Args:
        schedule_rid (str):
        body (UpdateIndexingScheduleRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | UpdateIndexingScheduleResponse]
    """

    kwargs = _get_kwargs(
        schedule_rid=schedule_rid,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    schedule_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateIndexingScheduleRequest,
) -> Any | UpdateIndexingScheduleResponse | None:
    """Update an indexing schedule

     Updates specific fields of an existing schedule. Only provided fields will be updated.

    Args:
        schedule_rid (str):
        body (UpdateIndexingScheduleRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | UpdateIndexingScheduleResponse
    """

    return (
        await asyncio_detailed(
            schedule_rid=schedule_rid,
            client=client,
            body=body,
        )
    ).parsed
