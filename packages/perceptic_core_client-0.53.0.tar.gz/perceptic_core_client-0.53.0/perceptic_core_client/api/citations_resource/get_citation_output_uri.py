from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_citation_output_uri_response import GetCitationOutputUriResponse
from ...types import Response


def _get_kwargs(
    citation_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/citations/{citation_id}/output-uri".format(
            citation_id=quote(str(citation_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetCitationOutputUriResponse | None:
    if response.status_code == 200:
        response_200 = GetCitationOutputUriResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetCitationOutputUriResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    citation_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetCitationOutputUriResponse]:
    """Get Citation Output Uri

    Args:
        citation_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetCitationOutputUriResponse]
    """

    kwargs = _get_kwargs(
        citation_id=citation_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    citation_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> GetCitationOutputUriResponse | None:
    """Get Citation Output Uri

    Args:
        citation_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetCitationOutputUriResponse
    """

    return sync_detailed(
        citation_id=citation_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    citation_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetCitationOutputUriResponse]:
    """Get Citation Output Uri

    Args:
        citation_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetCitationOutputUriResponse]
    """

    kwargs = _get_kwargs(
        citation_id=citation_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    citation_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> GetCitationOutputUriResponse | None:
    """Get Citation Output Uri

    Args:
        citation_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetCitationOutputUriResponse
    """

    return (
        await asyncio_detailed(
            citation_id=citation_id,
            client=client,
        )
    ).parsed
