from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_folder_request import CreateFolderRequest
from ...models.create_folder_response import CreateFolderResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    file_system_rid: str,
    *,
    body: CreateFolderRequest,
    parent: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["parent"] = parent

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/file-systems/{file_system_rid}/contents/folders".format(
            file_system_rid=quote(str(file_system_rid), safe=""),
        ),
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | CreateFolderResponse | None:
    if response.status_code == 200:
        response_200 = CreateFolderResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | CreateFolderResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateFolderRequest,
    parent: str | Unset = UNSET,
) -> Response[Any | CreateFolderResponse]:
    """Create Folder

    Args:
        file_system_rid (str):
        parent (str | Unset):
        body (CreateFolderRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CreateFolderResponse]
    """

    kwargs = _get_kwargs(
        file_system_rid=file_system_rid,
        body=body,
        parent=parent,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateFolderRequest,
    parent: str | Unset = UNSET,
) -> Any | CreateFolderResponse | None:
    """Create Folder

    Args:
        file_system_rid (str):
        parent (str | Unset):
        body (CreateFolderRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CreateFolderResponse
    """

    return sync_detailed(
        file_system_rid=file_system_rid,
        client=client,
        body=body,
        parent=parent,
    ).parsed


async def asyncio_detailed(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateFolderRequest,
    parent: str | Unset = UNSET,
) -> Response[Any | CreateFolderResponse]:
    """Create Folder

    Args:
        file_system_rid (str):
        parent (str | Unset):
        body (CreateFolderRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CreateFolderResponse]
    """

    kwargs = _get_kwargs(
        file_system_rid=file_system_rid,
        body=body,
        parent=parent,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateFolderRequest,
    parent: str | Unset = UNSET,
) -> Any | CreateFolderResponse | None:
    """Create Folder

    Args:
        file_system_rid (str):
        parent (str | Unset):
        body (CreateFolderRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CreateFolderResponse
    """

    return (
        await asyncio_detailed(
            file_system_rid=file_system_rid,
            client=client,
            body=body,
            parent=parent,
        )
    ).parsed
