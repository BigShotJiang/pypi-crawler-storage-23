from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.post_managed_file_system_upload_request import PostManagedFileSystemUploadRequest
from ...models.upload_file_overwrite import UploadFileOverwrite
from ...models.upload_file_to_managed_file_system_response import UploadFileToManagedFileSystemResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    file_system_rid: str,
    *,
    body: PostManagedFileSystemUploadRequest,
    overwrite: UploadFileOverwrite | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_overwrite: dict[str, Any] | Unset = UNSET
    if not isinstance(overwrite, Unset):
        json_overwrite = overwrite.to_dict()
    if not isinstance(json_overwrite, Unset):
        params.update(json_overwrite)

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/file-systems/{file_system_rid}/contents/upload".format(
            file_system_rid=quote(str(file_system_rid), safe=""),
        ),
        "params": params,
    }

    _kwargs["files"] = body.to_multipart()

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> UploadFileToManagedFileSystemResponse | None:
    if response.status_code == 200:
        response_200 = UploadFileToManagedFileSystemResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[UploadFileToManagedFileSystemResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: PostManagedFileSystemUploadRequest,
    overwrite: UploadFileOverwrite | Unset = UNSET,
) -> Response[UploadFileToManagedFileSystemResponse]:
    """Upload File

    Args:
        file_system_rid (str):
        overwrite (UploadFileOverwrite | Unset): Option to overwrite file if it already exists,
            effectively updating it
        body (PostManagedFileSystemUploadRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UploadFileToManagedFileSystemResponse]
    """

    kwargs = _get_kwargs(
        file_system_rid=file_system_rid,
        body=body,
        overwrite=overwrite,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: PostManagedFileSystemUploadRequest,
    overwrite: UploadFileOverwrite | Unset = UNSET,
) -> UploadFileToManagedFileSystemResponse | None:
    """Upload File

    Args:
        file_system_rid (str):
        overwrite (UploadFileOverwrite | Unset): Option to overwrite file if it already exists,
            effectively updating it
        body (PostManagedFileSystemUploadRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UploadFileToManagedFileSystemResponse
    """

    return sync_detailed(
        file_system_rid=file_system_rid,
        client=client,
        body=body,
        overwrite=overwrite,
    ).parsed


async def asyncio_detailed(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: PostManagedFileSystemUploadRequest,
    overwrite: UploadFileOverwrite | Unset = UNSET,
) -> Response[UploadFileToManagedFileSystemResponse]:
    """Upload File

    Args:
        file_system_rid (str):
        overwrite (UploadFileOverwrite | Unset): Option to overwrite file if it already exists,
            effectively updating it
        body (PostManagedFileSystemUploadRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UploadFileToManagedFileSystemResponse]
    """

    kwargs = _get_kwargs(
        file_system_rid=file_system_rid,
        body=body,
        overwrite=overwrite,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
    body: PostManagedFileSystemUploadRequest,
    overwrite: UploadFileOverwrite | Unset = UNSET,
) -> UploadFileToManagedFileSystemResponse | None:
    """Upload File

    Args:
        file_system_rid (str):
        overwrite (UploadFileOverwrite | Unset): Option to overwrite file if it already exists,
            effectively updating it
        body (PostManagedFileSystemUploadRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UploadFileToManagedFileSystemResponse
    """

    return (
        await asyncio_detailed(
            file_system_rid=file_system_rid,
            client=client,
            body=body,
            overwrite=overwrite,
        )
    ).parsed
