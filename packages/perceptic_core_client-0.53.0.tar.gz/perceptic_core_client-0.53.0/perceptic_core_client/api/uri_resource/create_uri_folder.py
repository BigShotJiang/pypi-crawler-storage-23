from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_folder_request import CreateFolderRequest
from ...models.create_folder_response import CreateFolderResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: CreateFolderRequest,
    uri: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["uri"] = uri

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/resources/folders",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | CreateFolderResponse | None:
    if response.status_code == 200:
        response_200 = CreateFolderResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | CreateFolderResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateFolderRequest,
    uri: str | Unset = UNSET,
) -> Response[Any | CreateFolderResponse]:
    """Create Folder

    Args:
        uri (str | Unset): The URI determines the FileSystem to create the Folder and the
            parent/path to place the folder
        body (CreateFolderRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CreateFolderResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        uri=uri,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateFolderRequest,
    uri: str | Unset = UNSET,
) -> Any | CreateFolderResponse | None:
    """Create Folder

    Args:
        uri (str | Unset): The URI determines the FileSystem to create the Folder and the
            parent/path to place the folder
        body (CreateFolderRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CreateFolderResponse
    """

    return sync_detailed(
        client=client,
        body=body,
        uri=uri,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateFolderRequest,
    uri: str | Unset = UNSET,
) -> Response[Any | CreateFolderResponse]:
    """Create Folder

    Args:
        uri (str | Unset): The URI determines the FileSystem to create the Folder and the
            parent/path to place the folder
        body (CreateFolderRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CreateFolderResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        uri=uri,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateFolderRequest,
    uri: str | Unset = UNSET,
) -> Any | CreateFolderResponse | None:
    """Create Folder

    Args:
        uri (str | Unset): The URI determines the FileSystem to create the Folder and the
            parent/path to place the folder
        body (CreateFolderRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CreateFolderResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            uri=uri,
        )
    ).parsed
