from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.upload_resource_response_v2 import UploadResourceResponseV2
from ...models.uri_file_upload_request import UriFileUploadRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: UriFileUploadRequest,
    overwrite: bool | Unset = UNSET,
    uri: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["overwrite"] = overwrite

    params["uri"] = uri

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v2/resources/upload",
        "params": params,
    }

    _kwargs["files"] = body.to_multipart()

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> UploadResourceResponseV2 | None:
    if response.status_code == 200:
        response_200 = UploadResourceResponseV2.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[UploadResourceResponseV2]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UriFileUploadRequest,
    overwrite: bool | Unset = UNSET,
    uri: str | Unset = UNSET,
) -> Response[UploadResourceResponseV2]:
    """Upload file and return the resulting URI

    Args:
        overwrite (bool | Unset):
        uri (str | Unset):
        body (UriFileUploadRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UploadResourceResponseV2]
    """

    kwargs = _get_kwargs(
        body=body,
        overwrite=overwrite,
        uri=uri,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: UriFileUploadRequest,
    overwrite: bool | Unset = UNSET,
    uri: str | Unset = UNSET,
) -> UploadResourceResponseV2 | None:
    """Upload file and return the resulting URI

    Args:
        overwrite (bool | Unset):
        uri (str | Unset):
        body (UriFileUploadRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UploadResourceResponseV2
    """

    return sync_detailed(
        client=client,
        body=body,
        overwrite=overwrite,
        uri=uri,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UriFileUploadRequest,
    overwrite: bool | Unset = UNSET,
    uri: str | Unset = UNSET,
) -> Response[UploadResourceResponseV2]:
    """Upload file and return the resulting URI

    Args:
        overwrite (bool | Unset):
        uri (str | Unset):
        body (UriFileUploadRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[UploadResourceResponseV2]
    """

    kwargs = _get_kwargs(
        body=body,
        overwrite=overwrite,
        uri=uri,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: UriFileUploadRequest,
    overwrite: bool | Unset = UNSET,
    uri: str | Unset = UNSET,
) -> UploadResourceResponseV2 | None:
    """Upload file and return the resulting URI

    Args:
        overwrite (bool | Unset):
        uri (str | Unset):
        body (UriFileUploadRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        UploadResourceResponseV2
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            overwrite=overwrite,
            uri=uri,
        )
    ).parsed
