API Reference
=============

.. toctree::
   :maxdepth: 2

   client
   config
   models
   rest
   websocket
   http
   errors
