"""Enable ``python -m agenticore`` execution."""

from agenticore.server import main

main()
