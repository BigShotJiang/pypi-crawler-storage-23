"""Report section generators."""
