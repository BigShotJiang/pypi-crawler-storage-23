class UnitIds:
    valid_unit_ids = [4969, 4973]
    last_unit_id = 161622
    test_unit_id = 4969

    last_ix_unit_id = 5044  # an index, not a unit id!


class SampleUnit:
    unit_id = 4969
    num_rooms = 8
    num_connections = 14
    num_edges = 17
