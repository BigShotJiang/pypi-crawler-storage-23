# /// script
# requires-python = ">=3.13"
# dependencies = [
#     "marimo>=0.19.0",
#     "pyzmq",
# ]
# ///

# NOTE: Use the command palette (cmd+shift+p) and search "marimo start in editor" to generate the live preview.

import marimo

__generated_with = "0.13.6"
app = marimo.App()


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    # Marimo Notebook Demo

    Marimo Notebooks are a newer tool that combine the best of scripts, Python notebooks, and Quarto notebooks/documents. Marimo notebooks have their own mini user-interface rather than embedding in Cursor/VSCode.

    But, unlike normal Python notebooks everything is all stored in a `.py` file which you can run like any other Python file e.g. `pixi run python yourmarimofile.py`.

    We've configured this project to let you start marimo and view it in a seperate browser if you prefer using

    `pixi run marimo file.py`

    Or you can use the VSCode extension but using the command palette (`cmd+shift+p`) and searching "marimo start in editor", which will open the marimo notebook preview in VSCode itself.
    """
    )
    return


@app.cell
def _():
    # Same cell as our Python notebook
    # This is a custom function we wrote save in src/lib/helpers.py
    from lib.helpers import hello_world

    hello_world()
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(
        r"""
    Cells are also *reactive* by default which means they track all the values that variables and code depend on. In this next cell, we create a radio-button and save it to the `radiogroup` variable.

    Then we can read the `radiogroup.value` attribute in the any code-cell below that and it will always auto-update to the latest value of which option was selected!
    """
    )
    return


@app.cell(hide_code=True)
def _():
    import marimo as mo

    radiogroup = mo.ui.radio(
        options={"one": 1, "two": 2, "three": 3},
        value="one",
        label="pick a number",
    )
    radiogroup
    return mo, radiogroup


@app.cell
def _(radiogroup):
    print("Watch this value react!")
    print(f"The value is {radiogroup.value}")
    return


@app.cell(hide_code=True)
def _():
    # Import some libraries
    import numpy as np
    import seaborn as sns
    import polars as pl

    # Set the path for saving figures
    from pathlib import Path

    figures_path = Path("./figures/")
    return np, pl, sns


@app.cell
def _(np, pl, radiogroup, sns):
    # Generate some random data
    x = np.random.randn(100)
    y = np.random.randn(100) * radiogroup.value
    df = pl.DataFrame({"x": x, "y": y})

    # Plot the data
    grid = sns.FacetGrid(df)
    grid.map(sns.scatterplot, "x", "y")

    # Customize the plot
    grid.set(
        title="I saved this plot to figures/demo.png!",
        xlim=(-3, 3),
        ylim=(-3, 3),
        xlabel="Some random numbers",
        ylabel="Some other random numbers",
    )
    return (df,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""Dataframes render interactively with mini-histograms""")
    return


@app.cell(hide_code=True)
def _(df, pl):
    df.select(pl.col("x").abs())
    return


@app.cell
def _(mo):
    mo.md(r""" """)
    return


if __name__ == "__main__":
    app.run()
