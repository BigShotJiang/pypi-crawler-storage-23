# This is a Python file that's designed to be run as a script
# You run it using the following command:
# `pixi run python code/demo.py`
#
# Or using the pre-configured pixi task:
# `pixi run demo`
import sys


def calc_age(age: int) -> tuple[int, int, int, int]:
    """Calculate the age of person in number of months, weeks, days, and minutes.

    Args:
        age (int): Age in years

    Returns:
        tuple[int, int, int, int]: Age in months, weeks, days, and minutes
    """
    return age * 12, age * 52, age * 365, age * 365 * 24 * 60


def main(name: str, age: int | None = None):
    """The main function of the demo.py script.

    Args:
        name (str): Name of the person
        age (int | None, optional): Age of the person. Defaults to None.
    """
    print(f"Hello from the demo.py script {name}!")
    if age:
        months, weeks, days, minutes = calc_age(age)
        print(
            f"Your age in:\n months: {months}\n weeks: {weeks}\n days: {days}\n minutes: {minutes}\n"
        )


if __name__ == "__main__":
    # sys.argv[] is a list of any arguments passed
    # sys.argv[0] is the name of the script
    name = sys.argv[1] if len(sys.argv) > 1 else ""
    age = int(sys.argv[2]) if len(sys.argv) > 2 else None
    main(name, age)
