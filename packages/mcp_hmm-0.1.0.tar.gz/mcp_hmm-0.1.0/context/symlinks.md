# Symlinks

I use symlinks in src/mcp_hmm pointing to notebooks so that they can be deployed to pypi and used as library. This way, I have a notebook-centric setup and take advantage of the ability to import reusable components directly from marimo notebooks.
