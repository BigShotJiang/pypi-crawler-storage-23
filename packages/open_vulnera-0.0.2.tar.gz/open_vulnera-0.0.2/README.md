# Open Vulnera License v1.0 — See LICENSE file for full terms.
# Commercial use, obfuscation, and uncredentialed redistribution are prohibited.

<br>

<img alt="local_explorer" src="https://github.com/OpenVulnera/open-vulnera/assets/63927363/d941c3b4-b5ad-4642-992c-40edf31e2e7a">

<br>
</p>
<br>

**Open Vulnera** lets LLMs run code (Python, Javascript, Shell, and more) locally. You can chat with Open Vulnera through a ChatGPT-like interface in your terminal by running `$ vulnera` after installing.

This provides a natural-language interface to your.computer's general-purpose capabilities:

- Create and edit photos, videos, PDFs, etc.
- Control a Chrome browser to perform research
- Plot, clean, and analyze large datasets
- ...etc.

**⚠️ Note: You'll be asked to approve code before it's run.**

<br>

## Demo

https://github.com/OpenVulnera/open-vulnera/assets/63927363/37152071-680d-4423-9af3-64836a6f7b60

#### An interactive demo is also available on Google Colab:

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/1WKmRXZgsErej2xUriKzxrEAXdxMSgWbb?usp=sharing)

#### Along with an example voice interface, inspired by _Her_:

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/1NojYGHDgxH6Y1G1oxThEBBb2AtyODBIK)

## Quick Start


### Install

```shell
pip install git+https://github.com/OpenVulnera/open-vulnera.git
```

> Not working? Read our [setup guide](https://docs.openvulnera.com/getting-started/setup).

### Terminal

After installation, simply run `vulnera`:

```shell
vulnera
```

### Python

```python
from vulnera import vulnera

vulnera.chat("Plot AAPL and META's normalized stock prices") # Executes a single.command
vulnera.chat() # Starts an interactive chat
```

### GitHub Codespaces

Press the `,` key on this repository's GitHub page to create a codespace. After a moment, you'll receive a cloud virtual machine environment pre-installed with open-vulnera. You can then start interacting with it directly and freely confirm its execution of system.commands without worrying about damaging the system.

## Comparison to ChatGPT's Code Vulnera

OpenAI's release of [Code Vulnera](https://openai.com/blog/chatgpt-plugins#code-vulnera) with GPT-4 presents a fantastic opportunity to a.complish real-world tasks with ChatGPT.

However, OpenAI's service is hosted, closed-source, and heavily restricted:

- No internet access.
- [Limited set of pre-installed packages](https://wfhbrian.com/mastering-chatgpts-code-vulnera-list-of-python-packages/).
- 100 MB maximum upload, 120.0 second runtime limit.
- State is cleared (along with any generated files or links) when the environment dies.

---

Open Vulnera ove.comes these limitations by running in your local environment. It has full access to the internet, isn't restricted by time or file size, and can utilize any package or library.

This.combines the power of GPT-4's Code Vulnera with the flexibility of your local development environment.

## Commands

**Update:** The Generator Update (0.1.5) introduced streaming:

```python
message = "What operating system are we on?"

for chunk in vulnera.chat(message, display=False, stream=True):
  print(chunk)
```

### Interactive Chat

To start an interactive chat in your terminal, either run `vulnera` from the.command line:

```shell
vulnera
```

Or `vulnera.chat()` from a .py file:

```python
vulnera.chat()
```

**You can also stream each chunk:**

```python
message = "What operating system are we on?"

for chunk in vulnera.chat(message, display=False, stream=True):
  print(chunk)
```

### Programmatic Chat

For more precise control, you can pass messages directly to `.chat(message)`:

```python
vulnera.chat("Add subtitles to all videos in /videos.")

# ... Streams output to your terminal,.completes task ...

vulnera.chat("These look great but can you make the subtitles bigger?")

# ...
```

### Start a New Chat

In Python, Open Vulnera remembers conversation history. If you want to start fresh, you can reset it:

```python
vulnera.messages = []
```

### Save and Restore Chats

`vulnera.chat()` returns a List of messages, which can be used to resume a conversation with `vulnera.messages = messages`:

```python
messages = vulnera.chat("My name is Killian.") # Save messages to 'messages'
vulnera.messages = [] # Reset vulnera ("Killian" will be forgotten)

vulnera.messages = messages # Resume chat from 'messages' ("Killian" will be remembered)
```

### Customize System Message

You can inspect and configure Open Vulnera's system message to extend its functionality, modify permissions, or give it more context.

```python
vulnera.system_message += """
Run shell.commands with -y so the user doesn't have to confirm them.
"""
print(vulnera.system_message)
```

### Change your Language Model

Open Vulnera uses [LiteLLM](https://docs.litellm.ai/docs/providers/) to connect to hosted language models.

You can change the model by setting the model parameter:

```shell
vulnera --model gpt-3.5-turbo
vulnera --model claude-2
vulnera --model.command-nightly
```

In Python, set the model on the object:

```python
vulnera.llm.model = "gpt-3.5-turbo"
```

[Find the appropriate "model" string for your language model here.](https://docs.litellm.ai/docs/providers/)

### Running Open Vulnera locally

#### Terminal

Open Vulnera can use OpenAI.compatible server to run models locally. (LM Studio, jan.ai, ollama etc)

Simply run `vulnera` with the api_base URL of your inference server (for LM studio it is `http://localhost:1234/v1` by default):

```shell
vulnera --api_base "http://localhost:1234/v1" --api_key "fake_key"
```

Alternatively you can use Llamafile without installing any third party software just by running

```shell
vulnera --local
```

for a more detailed guide check out [this video by Mike Bird](https://www.youtube.com/watch?v=CEs51hGWuGU?si=cN7f6QhfT4edfG5H)

**How to run LM Studio in the background.**

1. Download [https://lmstudio.ai/](https://lmstudio.ai/) then start it.
2. Select a model then click **↓ Download**.
3. Click the **↔️** button on the left (below 💬).
4. Select your model at the top, then click **Start Server**.

Once the server is running, you can begin your conversation with Open Vulnera.

> **Note:** Local mode sets your `context_window` to 3000, and your `max_tokens` to 1000. If your model has different requirements, set these parameters manually (see below).

#### Python

Our Python package gives you more control over each setting. To replicate and connect to LM Studio, use these settings:

```python
from vulnera import vulnera

vulnera.offline = True # Disables online features like Open Procedures
vulnera.llm.model = "openai/x" # Tells OI to send messages in OpenAI's format
vulnera.llm.api_key = "fake_key" # LiteLLM, which we use to talk to LM Studio, requires this
vulnera.llm.api_base = "http://localhost:1234/v1" # Point this at any OpenAI.compatible server

vulnera.chat()
```

#### Context Window, Max Tokens

You can modify the `max_tokens` and `context_window` (in tokens) of locally running models.

For local mode, smaller context windows will use less RAM, so we r.commend trying a much shorter window (~1000) if it's failing / if it's slow. Make sure `max_tokens` is less than `context_window`.

```shell
vulnera --local --max_tokens 1000 --context_window 3000
```

### Verbose mode

To help you inspect Open Vulnera we have a `--verbose` mode for debugging.

You can activate verbose mode by using its flag (`vulnera --verbose`), or mid-chat:

```shell
$ vulnera
...
> %verbose true <- Turns on verbose mode

> %verbose false <- Turns off verbose mode
```

### Interactive Mode Commands

In the interactive mode, you can use the below.commands to enhance your experience. Here's a list of available.commands:

**Available Commands:**

- `%verbose [true/false]`: Toggle verbose mode. Without arguments or with `true` it
  enters verbose mode. With `false` it exits verbose mode.
- `%reset`: Resets the current session's conversation.
- `%undo`: Removes the previous user message and the AI's response from the message history.
- `%tokens [prompt]`: (_Experimental_) Calculate the tokens that will be sent with the next prompt as context and estimate their cost. Optionally calculate the tokens and estimated cost of a `prompt` if one is provided. Relies on [LiteLLM's `cost_per_token()` method](https://docs.litellm.ai/docs.completion/token_usage#2-cost_per_token) for estimated costs.
- `%help`: Show the help message.

### Configuration / Profiles

Open Vulnera allows you to set default behaviors using `yaml` files.

This provides a flexible way to configure the vulnera without changing.command-line arguments every time.

Run the following.command to open the profiles directory:

```
vulnera --profiles
```

You can add `yaml` files there. The default profile is named `default.yaml`.

#### Multiple Profiles

Open Vulnera supports multiple `yaml` files, allowing you to easily switch between configurations:

```
vulnera --profile my_profile.yaml
```

## Sample FastAPI Server

The generator update enables Open Vulnera to be controlled via HTTP REST endpoints:

```python
# server.py

from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from vulnera import vulnera

app = FastAPI()

@app.get("/chat")
def chat_endpoint(message: str):
    def event_stream():
        for result in vulnera.chat(message, stream=True):
            yield f"data: {result}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")

@app.get("/history")
def history_endpoint():
    return vulnera.messages
```

```shell
pip install fastapi uvicorn
uvicorn server:app --reload
```

You can also start a server identical to the one above by simply running `vulnera.server()`.

## Android

The step-by-step guide for installing Open Vulnera on your Android device can be found in the [open-vulnera-termux repo](https://github.com/MikeBirdTech/open-vulnera-termux).

## Safety Notice

Since generated code is executed in your local environment, it can interact with your files and system settings, potentially leading to unexpected ou.comes like data loss or security risks.

**⚠️ Open Vulnera will ask for user confirmation before executing code.**

You can run `vulnera -y` or set `vulnera.auto_run = True` to bypass this confirmation, in which case:

- Be cautious when requesting.commands that modify files or system settings.
- Watch Open Vulnera like a self-driving car, and be prepared to end the process by closing your terminal.
- Consider running Open Vulnera in a restricted environment like Google Colab or Replit. These environments are more isolated, reducing the risks of executing arbitrary code.

There is **experimental** support for a [safe mode](https://github.com/OpenVulnera/open-vulnera/blob/main/docs/SAFE_MODE.md) to help mitigate some risks.

## How Does it Work?

Open Vulnera equips a [function-calling language model](https://platform.openai.com/docs/guides/gpt/function-calling) with an `exec()` function, which accepts a `language` (like "Python" or "JavaScript") and `code` to run.

We then stream the model's messages, code, and your system's outputs to the terminal as Markdown.

# Access Documentation Offline

The full [documentation](https://docs.openvulnera.com/) is accessible on-the-go without the need for an internet connection.

[Node](https://nodejs.org/en) is a pre-requisite:

- Version 18.17.0 or any later 18.x.x version.
- Version 20.3.0 or any later 20.x.x version.
- Any version starting from 21.0.0 onwards, with no upper limit specified.

Install [Mintlify](https://mintlify.com/):

```bash
npm i -g mintlify@latest
```

Change into the docs directory and run the appropriate.command:

```bash
# Assuming you're at the project's root directory
cd ./docs

# Run the documentation server
mintlify dev
```

A new browser window should open. The documentation will be available at [http://localhost:3000](http://localhost:3000) as long as the documentation server is running.

# Contributing

Thank you for your interest in contributing! We we.come involvement from the.community.

Please see our [contributing guidelines](https://github.com/OpenVulnera/open-vulnera/blob/main/docs/CONTRIBUTING.md) for more details on how to get involved.

# Roadmap

Visit [our roadmap](https://github.com/OpenVulnera/open-vulnera/blob/main/docs/ROADMAP.md) to preview the future of Open Vulnera.

**Note**: This software is not affiliated with OpenAI.

![thumbnail-ncu](https://github.com/OpenVulnera/open-vulnera/assets/63927363/1b19a5db-b486-41fd-a7a1-fe2028031686)

> Having access to a junior programmer working at the speed of your fingertips ... can make new workflows effortless and efficient, as well as open the benefits of programming to new audiences.
>
> — _OpenAI's Code Vulnera Release_

<br>
