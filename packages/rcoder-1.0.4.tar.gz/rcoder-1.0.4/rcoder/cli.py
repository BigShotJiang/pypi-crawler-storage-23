#!/usr/bin/env python3
"""
Rcoder 命令行工具
提供命令行界面，降低使用门槛
"""

import sys
import argparse
from rcoder.utils import (
    quick_setup, get_default_remote, validate_config,
    export_config, import_config, create_alias
)


def cli():
    """命令行入口函数"""
    parser = argparse.ArgumentParser(
        description='Rcoder - 远程代码执行与管理系统',
        epilog='示例: rcoder run "ls -la"'
    )
    
    # 子命令
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # setup 命令
    setup_parser = subparsers.add_parser('setup', help='快速设置向导')
    
    # run 命令
    run_parser = subparsers.add_parser('run', help='执行命令')
    run_parser.add_argument('cmd', help='要执行的命令')
    run_parser.add_argument('-s', '--server', help='服务器名称')
    run_parser.add_argument('-t', '--timeout', type=int, default=60, help='超时时间')
    
    # batch 命令
    batch_parser = subparsers.add_parser('batch', help='批量执行命令')
    batch_parser.add_argument('cmds', nargs='+', help='要执行的命令列表')
    batch_parser.add_argument('-s', '--server', help='服务器名称')
    batch_parser.add_argument('-t', '--timeout', type=int, default=60, help='超时时间')
    
    # ls 命令
    ls_parser = subparsers.add_parser('ls', help='列出目录内容')
    ls_parser.add_argument('path', nargs='?', default='.', help='目录路径')
    ls_parser.add_argument('-s', '--server', help='服务器名称')
    
    # cat 命令
    cat_parser = subparsers.add_parser('cat', help='查看文件内容')
    cat_parser.add_argument('file', help='文件路径')
    cat_parser.add_argument('-s', '--server', help='服务器名称')
    
    # status 命令
    status_parser = subparsers.add_parser('status', help='查看系统状态')
    status_parser.add_argument('-s', '--server', help='服务器名称')
    
    # config 命令
    config_parser = subparsers.add_parser('config', help='配置管理')
    config_parser.add_argument('action', choices=['validate', 'export', 'import', 'alias'], 
                              help='配置操作')
    config_parser.add_argument('file', nargs='?', help='导入的配置文件路径')
    
    # 解析参数
    args = parser.parse_args()
    
    # 处理命令
    if args.command == 'setup':
        quick_setup()
    
    elif args.command == 'run':
        try:
            remote = get_default_remote()
            result = remote.run(args.cmd, timeout=args.timeout)
            print(result)
        except Exception as e:
            print(f"❌ 执行命令失败: {e}")
            sys.exit(1)
    
    elif args.command == 'batch':
        try:
            remote = get_default_remote()
            results = remote.run_batch(args.cmds, timeout=args.timeout)
            for cmd, res in results.items():
                print(f"命令: {cmd}")
                print(f"结果: {res}")
                print('-' * 50)
        except Exception as e:
            print(f"❌ 批量执行命令失败: {e}")
            sys.exit(1)
    
    elif args.command == 'ls':
        try:
            remote = get_default_remote()
            result = remote.ls(args.path)
            print(result)
        except Exception as e:
            print(f"❌ 列出目录失败: {e}")
            sys.exit(1)
    
    elif args.command == 'cat':
        try:
            remote = get_default_remote()
            result = remote.cat(args.file)
            print(result)
        except Exception as e:
            print(f"❌ 查看文件失败: {e}")
            sys.exit(1)
    
    elif args.command == 'status':
        try:
            remote = get_default_remote()
            print("=== 系统状态 ===")
            print("主机名:")
            print(remote.hostname())
            print()
            print("运行时间:")
            print(remote.uptime())
            print()
            print("内存使用:")
            print(remote.free())
            print()
            print("磁盘使用:")
            print(remote.df())
            print()
            print("IP地址:")
            print(remote.ip())
        except Exception as e:
            print(f"❌ 获取系统状态失败: {e}")
            sys.exit(1)
    
    elif args.command == 'config':
        if args.action == 'validate':
            validate_config()
        elif args.action == 'export':
            export_config()
        elif args.action == 'import' and args.file:
            import_config(args.file)
        elif args.action == 'alias':
            create_alias()
        else:
            config_parser.print_help()
    
    else:
        parser.print_help()


def main():
    """主入口函数"""
    cli()

if __name__ == '__main__':
    main()
