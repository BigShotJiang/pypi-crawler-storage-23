import enum
import logging
import time
from collections.abc import Callable, Generator
from contextlib import contextmanager, suppress
from typing import Any, ClassVar, Literal, TypeVar, cast

from confluent_kafka import Consumer, KafkaError, KafkaException, Message, Producer
from pydantic import ValidationError

from tp_common.decorators.decorator_retry_sync import retry_sync
from tp_common.event_service.exceptions import EventMessageParseError
from tp_common.event_service.message_transformer import EventMessageTransformer
from tp_common.event_service.schemas import BaseEventMessage
from tp_common.kafka.connector import KafkaConnector

logger = logging.getLogger(__name__)

MessageT = TypeVar("MessageT", bound=BaseEventMessage)
EventEnumT = TypeVar("EventEnumT", bound=enum.Enum)

BASE_EVENT_TYPE_MAPPING: dict[str, str] = {
    "c": "create",
    "u": "update",
    "d": "delete",
    "r": "snapshot",
    "create": "create",
    "update": "update",
    "delete": "delete",
    "snapshot": "snapshot",
}


def event_type_mapping_for(enum_cls: type[enum.Enum]) -> dict[str, str]:
    """
    Маппинг для преобразования строки в член enum в сервисе.
    Базовые ключи (c, u, d, r, create, ...) + все значения enum_cls (для своих типов вроде change_name).
    """
    mapping = dict(BASE_EVENT_TYPE_MAPPING)
    for member in enum_cls:
        v = member.value if isinstance(member.value, str) else str(member.value)
        mapping[v.lower()] = v
    return mapping


class _PopMessage:
    """Контекст: при входе — pop(); при успешном выходе — commit()."""

    __slots__ = ("_event", "_timeout", "_message")

    def __init__(self, event: "BaseEvent[Any, Any]", timeout: float) -> None:
        self._event = event
        self._timeout = timeout
        self._message: Any = None

    def __enter__(self) -> Any:
        self._message = self._event._pop(timeout=self._timeout)
        return self._message

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> Literal[False]:
        if exc_type is None and self._message is not None:
            self._event._commit()
        return False


class BaseEvent[MessageT: BaseEventMessage, EventEnumT: enum.Enum]:
    SERVICE_NAME: ClassVar[str]
    EVENT_GROUP: ClassVar[enum.Enum]
    MESSAGE_CLASS: ClassVar[type[BaseEventMessage]]
    EVENT_TYPE_CLASS: ClassVar[type[enum.Enum]]

    _REQUIRED_EVENT_TYPES: ClassVar[dict[str, str]] = {
        "CREATE": "create",
        "UPDATE": "update",
        "DELETE": "delete",
    }

    def __init__(
        self,
        connector: KafkaConnector,
        log: logging.Logger,
        consumer_group: str | None = None,
        subscribe_to: list[EventEnumT] | None = None,
        retry_enabled: bool = True,
        schema_alert_interval_seconds: float = 600,
        schema_alert_callback: Callable[[str], None] | None = None,
    ) -> None:
        """Инициализация сервиса событий с подключением к Kafka.

        subscribe_to: если задан — из топика возвращаются только сообщения с типами
            из этого списка (например [UserEvent.CREATE, UserEvent.UPDATE]).
            Остальные сообщения коммитятся и пропускаются.
        retry_enabled: при True - повтор при ошибках Kafka/сети.
        schema_alert_interval_seconds: интервал повторных Critical-алертов при несовпадении схем (по умолчанию 10 мин).
        schema_alert_callback: опциональный callback при алерте (Sentry, Telegram и т.п.).
        """
        self.connector = connector
        self.consumer_group = consumer_group
        self.subscribe_to = subscribe_to

        self._consumer: Consumer | None = None
        self._producer: Producer | None = None

        self._is_auto_commit: bool = False
        self._last_message: Any | None = None

        self._retry_enabled = retry_enabled
        self._schema_alert_interval_seconds = schema_alert_interval_seconds
        self._schema_alert_callback = schema_alert_callback

        self.logger = log

        self._message_transformer = EventMessageTransformer(
            message_class=cast(type[MessageT], self.__class__.MESSAGE_CLASS),
            event_type_class=cast(type[EventEnumT], self.__class__.EVENT_TYPE_CLASS),
            logger=self.logger,
            service_name=self.__class__.__name__,
        )

    @property
    def retry_enabled(self) -> bool:
        return self._retry_enabled

    # --- Consumer / подписка ---

    def enable_auto_commit(self) -> None:
        """Включает автоматический commit после каждого прочитанного сообщения."""
        self._is_auto_commit = True

    def _topic(self) -> str:
        """Возвращает имя топика для данного сервиса и группы событий."""
        return f"events.{self.SERVICE_NAME}.public.{self.EVENT_GROUP.value}"

    @retry_sync(
        error_message="Ошибка подписки на топик: {e}",
        start_message="Подписка на топик Kafka",
    )
    def sub(self) -> None:
        """Подписывается на топик (с ретраями, если retry_enabled)."""
        self._get_consumer().subscribe([self._topic()])

    def unsub(self) -> None:
        """Отписывается от топика (корректный выход из группы). Вызывать при выходе из цикла/контекста."""
        if self._consumer is not None:
            with suppress(Exception):
                self._consumer.unsubscribe()

    def close(self) -> None:
        """Закрывает consumer и producer, освобождает соединения. При следующем sub()/publish() создадутся заново."""
        self._last_message = None
        if self._consumer is not None:
            with suppress(Exception):
                self._consumer.close()
            self._consumer = None
        if self._producer is not None:
            with suppress(Exception):
                self._producer.flush(timeout=10.0)
            self._producer = None

    @contextmanager
    def subscription(self) -> Generator[None]:
        """Контекст: при входе — подписка, при выходе — отписка и закрытие соединения (unsub + close)."""
        self.sub()
        try:
            yield
        finally:
            self.unsub()
            self.close()

    @retry_sync(
        start_message="Commit последнего сообщения в Kafka",
        error_message="Ошибка commit в Kafka: {e}",
    )
    def _commit(self) -> None:
        """Коммитит последнее прочитанное сообщение в Kafka (с ретраями, если retry_enabled).
        Логирует старт — видно коммит после успешной обработки сообщения.
        """
        if self._last_message:
            self._get_consumer().commit(self._last_message)

    @retry_sync(error_message="Ошибка commit в Kafka: {e}")
    def _commit_silent(self) -> None:
        """Коммитит без лога старта — для пропущенных по фильтру сообщений и auto_commit."""
        if self._last_message:
            self._get_consumer().commit(self._last_message)

    def pop(self, timeout: float = 60) -> "_PopMessage":
        """Контекст: при входе — чтение одного сообщения; при успешном выходе (без исключения и если message не None) — commit()."""
        return _PopMessage(self, timeout)

    def publish(
        self,
        message: MessageT,
        flush_timeout: float = 10.0,
    ) -> None:
        """Отправляет сообщение в топик; flush_timeout=0 для fire-and-forget.
        При retry_enabled повторяет отправку при ошибках доставки/Kafka.
        """
        value = message.model_dump_json().encode("utf-8")
        topic = self._topic()

        p = self._get_producer()
        p.produce(topic, value=value, on_delivery=self._on_delivery)
        if flush_timeout > 0:
            p.flush(timeout=flush_timeout)

    @retry_sync(
        start_message="Чтение сообщения из Kafka",
        error_message="Ошибка при чтении из Kafka: {e}",
    )
    def _pop(self, timeout: float = 60) -> MessageT | None:
        """Читает одно сообщение из топика, удовлетворяющее фильтру.
        Если сообщение не подходит по фильтру — коммитит и читает следующее (вечный цикл до подходящего или таймаута).
        При отсутствии сообщения за timeout или ошибке Kafka возвращает None.
        При ошибке парсинга — останавливает обработку.
        """
        while True:
            msg = self._get_consumer().poll(timeout=timeout)

            if msg is None:
                continue

            if msg.error():
                self.logger.warning("Ошибка Kafka при чтении: %s", msg.error())
                continue

            value = msg.value()
            if value is None:
                self.logger.warning("Получено сообщение с пустым value")
                continue

            self._last_message = msg

            if self._is_auto_commit:
                self.logger.debug("_is_auto_commit")
                self._commit_silent()

            try:
                parsed = self.message_from_value(value)
            except (ValidationError, TypeError, EventMessageParseError):
                self.logger.critical(
                    "Ошибка парсинга сообщения. Останавливаем обработку.",
                    exc_info=True,
                )
                self.unsub()
                self.close()
                self.run_schema_mismatch_alert_loop()
                return None

            if self._should_process_event(parsed.event):
                return parsed

            # Сообщение не подходит по фильтру — коммитим и читаем следующее
            self._commit_silent()

    # --- Producer / публикация ---

    @staticmethod
    def _on_delivery(err: KafkaError | None, msg: Message) -> None:
        """Callback при доставке сообщения в Kafka: логирует или пробрасывает ошибку."""
        if err:
            logger.error("Kafka delivery error: %s", err)
            raise KafkaException(err)

        logger.debug(
            "Kafka delivered: topic=%s partition=%s offset=%s",
            msg.topic(),
            msg.partition(),
            msg.offset(),
        )

    # --- Парсинг и сборка сообщений (делегирование в EventMessageTransformer) ---

    def message_from_value(self, value: bytes | str | dict[str, Any]) -> MessageT:
        """Полный пайплайн: value → RawEventPayload → MessageT; при ошибке валидации или нечитаемом value — исключение."""
        return self._message_transformer.message_from_value(value)

    def handle_schema_mismatch(self, exc: Exception | None = None) -> None:
        """
        Вызвать при несовпадении схем (ValidationError/TypeError из парсинга).
        Логирует Critical, отписывается, закрывает соединения, затем каждые
        schema_alert_interval_seconds логирует Critical и вызывает schema_alert_callback
        (бесконечный цикл до перезапуска процесса).
        """
        self.logger.critical(
            "Несовпадение схем. Останавливаем обработку.%s",
            "" if exc is None else f" {exc!s}",
            exc_info=exc is not None,
        )
        self.unsub()
        self.close()
        self.run_schema_mismatch_alert_loop()

    def run_schema_mismatch_alert_loop(self) -> None:
        """
        После остановки из-за несовпадения схем: каждые schema_alert_interval_seconds
        логирует Critical и вызывает schema_alert_callback (если задан). Использует
        параметры из __init__. Цикл бесконечный — процесс живёт только ради уведомлений.
        """
        msg = (
            "Схема сообщений не соответствует ожидаемой. "
            "Обработка событий остановлена. Требуется обновление схемы/развёртывание сервиса."
        )
        while True:
            self.logger.critical(msg)
            if self._schema_alert_callback:
                try:
                    self._schema_alert_callback(msg)
                except Exception as e:
                    self.logger.exception("Ошибка вызова alert_callback: %s", e)
            time.sleep(self._schema_alert_interval_seconds)

    def _should_process_event(
        self,
        event: EventEnumT | None,
        subscribe_to: list[EventEnumT] | None = None,
    ) -> bool:
        """Проверяет, нужно ли обрабатывать событие по фильтру subscribe_to.
        subscribe_to — список enum-членов (например [UserEvent.CREATE, UserEvent.UPDATE]).
        """
        effective_subscribe_to = (
            subscribe_to if subscribe_to is not None else self.subscribe_to
        )
        if effective_subscribe_to is None:
            return True
        if event is None:
            return False
        return event in set(effective_subscribe_to)

    # --- Внутренние (Kafka-коннекторы) ---

    def _get_consumer(self) -> Consumer:
        """Возвращает consumer; при первом вызове создаёт через connector."""
        if self.connector is None:
            raise ValueError("connector не задан, невозможно создать consumer")

        if not self.consumer_group or not str(self.consumer_group).strip():
            raise ValueError(
                "consumer_group должен быть непустой строкой для создания consumer"
            )

        if self._consumer is None:
            self.connector.set_logger(self.logger)
            self._consumer = self.connector.get_consumer(group_id=self.consumer_group)
        return self._consumer

    def _get_producer(self) -> Producer:
        """Возвращает producer; при первом вызове создаёт через connector."""
        if self._producer is None:
            self.connector.set_logger(self.logger)
            self._producer = self.connector.get_producer()
        return self._producer

    # --- Валидация наследников ---

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Проверяет наличие SERVICE_NAME, EVENT_GROUP, MESSAGE_CLASS, EVENT_TYPE_CLASS и обязательных полей."""
        super().__init_subclass__(**kwargs)

        # Проверка наличия обязательных атрибутов
        if not hasattr(cls, "SERVICE_NAME") or not isinstance(
            getattr(cls, "SERVICE_NAME", None), str
        ):
            raise TypeError(
                f"{cls.__name__} должен определить SERVICE_NAME (непустая строка)"
            )

        service_name = cls.SERVICE_NAME
        if not service_name or not service_name.strip():
            raise TypeError(
                f"{cls.__name__}.SERVICE_NAME не должен быть пустой строкой"
            )

        if not hasattr(cls, "EVENT_GROUP"):
            raise TypeError(f"{cls.__name__} должен определить EVENT_GROUP")

        if not hasattr(cls, "MESSAGE_CLASS"):
            raise TypeError(f"{cls.__name__} должен определить MESSAGE_CLASS")

        if not hasattr(cls, "EVENT_TYPE_CLASS"):
            raise TypeError(f"{cls.__name__} должен определить EVENT_TYPE_CLASS")

        # Проверка, что EVENT_TYPE_CLASS содержит обязательные поля create/update/delete
        event_type_cls = cls.EVENT_TYPE_CLASS
        if not isinstance(event_type_cls, type) or not issubclass(
            event_type_cls, enum.Enum
        ):
            raise TypeError(
                f"{cls.__name__}.EVENT_TYPE_CLASS должен быть подклассом enum.Enum"
            )
        for name, expected_value in BaseEvent._REQUIRED_EVENT_TYPES.items():
            if not hasattr(event_type_cls, name):
                raise TypeError(
                    f"{cls.__name__}.EVENT_TYPE_CLASS должен содержать поле {name}"
                )
            member = getattr(event_type_cls, name)
            actual_value = member.value if hasattr(member, "value") else member
            if actual_value != expected_value:
                raise TypeError(
                    f"{cls.__name__}.EVENT_TYPE_CLASS.{name} должен быть равен "
                    f"{expected_value!r}, получено {actual_value!r}"
                )
