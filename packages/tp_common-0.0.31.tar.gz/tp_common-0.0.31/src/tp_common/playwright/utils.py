import re


def proxy_to_playwright(proxy_str: str | None = None) -> dict:
    """
    Преобразует строку прокси в формате 'http://user:password@host:port'
    в словарь, подходящий для использования с Playwright.

    Args:
        proxy_str: Строка прокси в формате 'http://user:password@host:port'

    Returns:
        Словарь с настройками прокси для Playwright
    """
    if proxy_str is None:
        raise ValueError("Пришёл пустой прокси")
    # Регулярное выражение для разбора строки прокси
    pattern = r"^(?P<scheme>https?://)?(?:(?P<username>[^:]+):(?P<password>[^@]+)@)?(?P<host>[^:]+):(?P<port>\d+)$"

    match = re.match(pattern, proxy_str.strip())

    if not match:
        raise ValueError(f"Неверный формат строки прокси: {proxy_str}")

    groups = match.groupdict()

    # Формируем URL сервера
    scheme = groups["scheme"] or "http://"
    host = groups["host"]
    port = groups["port"]

    server = f"{scheme}{host}:{port}"

    # Создаем результат
    result = {"server": server}

    if groups["username"] and groups["password"]:
        result["username"] = groups["username"]
        result["password"] = groups["password"]

    return result
