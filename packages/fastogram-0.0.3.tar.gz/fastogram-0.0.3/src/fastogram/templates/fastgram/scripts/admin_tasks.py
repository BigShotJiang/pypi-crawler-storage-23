import asyncio


async def main() -> None:
    return None


if __name__ == "__main__":
    asyncio.run(main())
