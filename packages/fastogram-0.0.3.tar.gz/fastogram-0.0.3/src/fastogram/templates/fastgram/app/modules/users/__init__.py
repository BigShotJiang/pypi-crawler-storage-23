from app.modules.users.service import UserService

__all__ = ["UserService"]
