console.log("Telegram FastAPI Template");
