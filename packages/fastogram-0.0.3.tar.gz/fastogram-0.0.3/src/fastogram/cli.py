"""Fastogram CLI — create new FastAPI + Aiogram projects from the FastGram template."""

from __future__ import annotations

import re
import shutil
import sys
from pathlib import Path

# Template lives inside the package (bundled at pip install time)
_PACKAGE_ROOT = Path(__file__).resolve().parent
_TEMPLATE_DIR = _PACKAGE_ROOT / "templates" / "fastgram"


def _normalize_project_name(raw: str) -> str:
    """Convert user input to a valid project slug (e.g. 'My Bot' -> 'my-bot')."""
    s = raw.strip().lower().replace(" ", "-")
    s = re.sub(r"[^a-z0-9\-]", "", s)
    return s or "fastgram-app"


def _copy_and_customize(
    source: Path, dest: Path, project_slug: str
) -> None:
    """Copy template to dest, replacing placeholders with project_slug."""
    replacements = [
        ("fastgram", project_slug),  # pyproject name (hyphens OK)
        ("telegram-fastapi-template", project_slug),  # config / .env
    ]

    def replace_in_content(text: str) -> str:
        for old, new in replacements:
            text = text.replace(old, new)
        return text

    dest.mkdir(parents=True, exist_ok=True)
    for src_path in source.rglob("*"):
        if src_path.is_file():
            rel = src_path.relative_to(source)
            dest_path = dest / rel
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            content = src_path.read_text(encoding="utf-8", errors="replace")
            dest_path.write_text(
                replace_in_content(content), encoding="utf-8"
            )


def cmd_new(project_name: str | None = None, target_dir: str | None = None) -> int:
    """Create a new FastGram project."""
    if not _TEMPLATE_DIR.exists():
        print(
            "Error: Template not found. Reinstall fastogram or run sync_template.py.",
            file=sys.stderr,
        )
        return 1

    use_cwd = project_name == "." or project_name == ""
    base = Path(target_dir or ".").resolve()

    if use_cwd:
        dest = base
        slug = base.name or "fastgram-app"
    else:
        slug = _normalize_project_name(project_name or "fastgram-app")
        dest = base / slug

    if dest.exists() and any(dest.iterdir()):
        print(
            f"Error: Directory already exists and is not empty: {dest}",
            file=sys.stderr,
        )
        return 1

    _copy_and_customize(_TEMPLATE_DIR, dest, slug)

    print(f"Created project: {dest}")
    print()
    print("Next steps:")
    if not use_cwd:
        print(f"  cd {dest.name}")
    print("  uv sync")
    print("  # Edit .env with your TELEGRAM_BOT_TOKEN")
    print("  python manage.py setup")
    print("  python manage.py run --reload")
    return 0


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(
        prog="fastogram",
        description="Create new FastAPI + Aiogram projects from the FastGram template.",
    )
    subparsers = parser.add_subparsers(dest="command", help="Commands")

    new_parser = subparsers.add_parser("new", help="Create a new project")
    new_parser.add_argument(
        "project_name",
        nargs="?",
        default=".",
        help='Project name (e.g. my-bot). Use "." to scaffold in current directory',
    )
    new_parser.add_argument(
        "-d",
        "--dir",
        dest="target_dir",
        default=".",
        help="Directory to create the project in. Default: current directory",
    )

    args = parser.parse_args()
    if args.command == "new":
        sys.exit(cmd_new(args.project_name, args.target_dir))
    else:
        parser.print_help()
        print()
        print("Examples:")
        print("  fastogram new my-bot          # Create ./my-bot/")
        print("  fastogram new .               # Scaffold in current directory")
        print("  fastogram new my-bot -d ~/projects")
        sys.exit(0)
