#!/usr/bin/env python3
"""Sync FastGram template into the fastogram CLI package.

Run this after making changes to FastGram (architecture, bug fixes, etc.)
so that `fastogram new` uses the latest template.

Usage:
    From cli/FastoGram/:  uv run python scripts/sync_template.py
    Or:                   FASTGRAM_SOURCE=/path/to/FastGram uv run python scripts/sync_template.py

The script copies FastGram → src/fastogram/templates/fastgram/, excluding
.git, .venv, __pycache__, and other generated/sensitive files.
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path

# Paths
SCRIPT_DIR = Path(__file__).resolve().parent
CLI_ROOT = SCRIPT_DIR.parent
TEMPLATE_DEST = CLI_ROOT / "src" / "fastogram" / "templates" / "fastgram"
DEFAULT_SOURCE = CLI_ROOT.parent.parent / "FastGram"  # projects/FastGram when run from projects/cli/FastoGram

# Exclude patterns (any path segment containing these is skipped)
EXCLUDE = {
    ".git",
    ".venv",
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    "fastgram.egg-info",
    ".env",  # Never copy real .env
    ".cursor",
    "abouteme.md",
    "what.md",
    "DOCS_STEPS.md",
    ".mypy_cache",
    "htmlcov",
    ".coverage",
    ".eggs",
    "dist",
    "build",
}


def _should_skip(path: Path, source_root: Path) -> bool:
    rel = path.relative_to(source_root)
    for part in rel.parts:
        if part in EXCLUDE:
            return True
    return False


def sync(source: Path, dest: Path) -> None:
    if not source.exists():
        raise SystemExit(f"Source not found: {source}")
    if not source.is_dir():
        raise SystemExit(f"Source is not a directory: {source}")

    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)

    copied = 0
    for src_path in source.rglob("*"):
        if src_path.is_file() and not _should_skip(src_path, source):
            rel = src_path.relative_to(source)
            dest_path = dest / rel
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_path, dest_path)
            copied += 1

    print(f"Synced {copied} files from {source} → {dest}")


def main() -> None:
    source = Path(os.environ.get("FASTGRAM_SOURCE", str(DEFAULT_SOURCE)))
    sync(source, TEMPLATE_DEST)


if __name__ == "__main__":
    main()
