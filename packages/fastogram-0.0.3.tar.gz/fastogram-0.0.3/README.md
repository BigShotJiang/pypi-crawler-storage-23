# Fastogram

Opinionated FastAPI + Aiogram project generator — like `django-admin startproject` for FastGram.

## Installation

```bash
pip install fastogram
```

Or with uv:
```bash
uv add fastogram
```

## Usage

Create a new project:

```bash
fastogram new my-telegram-bot
```

This creates `my-telegram-bot/` with the full FastGram template. Then:

```bash
cd my-telegram-bot
uv sync
# Edit .env with your TELEGRAM_BOT_TOKEN
python manage.py setup
python manage.py run --reload
```

### Options

```bash
fastogram new my-bot              # Create ./my-bot/
fastogram new .                   # Scaffold in current directory (no subfolder)
fastogram new my-bot -d ~/code    # Create ~/code/my-bot/
```

---

## For maintainers: syncing the template

When you update FastGram (architecture changes, bug fixes, etc.), sync the template into the CLI so `pip install fastogram` users get the latest:

```bash
cd cli/FastoGram
python scripts/sync_template.py
```

Or with a custom FastGram path:

```bash
FASTGRAM_SOURCE=/path/to/FastGram python scripts/sync_template.py
```

The sync copies FastGram → `src/fastogram/templates/fastgram/`, excluding `.git`, `.venv`, and other generated files. Rebuild and publish a new fastogram release after syncing.

### Publishing to PyPI

```bash
# 1. Create .pypi-token with your PyPI API token (from pypi.org/manage/account/token/)
echo "pypi-your-token-here" > .pypi-token

# 2. Publish
make publish
```

`.pypi-token` is in `.gitignore` — it will never be committed.
