"""Interference scoring — measures how much models conflict during merging."""

from __future__ import annotations

from typing import Optional

import torch

from mergelens.models import InterferenceScore
from mergelens.compare.loader import ModelHandle, find_common_tensors
from mergelens.compare.metrics import cosine_similarity
from mergelens.utils.tensor_ops import compute_task_vector


def compute_interference(
    handles: list[ModelHandle],
    base_model: Optional[str] = None,
    device: str = "cpu",
) -> list[InterferenceScore]:
    """Compute per-layer interference scores.

    Interference = 1 - cosine_sim(merged_layer, weighted_avg_of_sources)
    Measures how much the merge deviates from simple averaging.

    For pre-merge prediction: uses task vector overlap to predict problematic layers.
    """
    if len(handles) < 2:
        return []

    base_handle = handles[0]
    model_handles = handles[1:] if len(handles) > 2 else handles

    common = find_common_tensors(handles)
    scores = []

    for name in common:
        tensors = [h.get_tensor(name) for h in handles]

        # Compute weighted average (equal weights)
        avg = torch.stack([t.float() for t in tensors]).mean(dim=0)

        # Interference per source
        contributions = {}
        for i, (h, t) in enumerate(zip(handles, tensors)):
            cos = cosine_similarity(t, avg)
            contributions[h.info.name] = round(cos, 4)

        # Task vector interference (if we have a clear base)
        if len(handles) >= 2:
            base_t = tensors[0].float()
            task_vecs = [t.float() - base_t for t in tensors[1:]]

            if len(task_vecs) >= 2 and task_vecs[0].numel() > 0:
                # Pairwise task vector cosine similarity
                tv_cos = cosine_similarity(task_vecs[0], task_vecs[1])
                # High similarity = low interference, negative = high interference
                interference = max(0.0, min(1.0, (1.0 - tv_cos) / 2.0))
            else:
                # Single task vector: use magnitude as proxy
                interference = 0.0
                for tv in task_vecs:
                    norm = torch.norm(tv).item()
                    base_norm = torch.norm(base_t).item()
                    if base_norm > 1e-10:
                        interference = max(interference, min(1.0, norm / base_norm))
        else:
            interference = max(0.0, 1.0 - cosine_similarity(tensors[0], tensors[1]))

        scores.append(InterferenceScore(
            layer_name=name,
            score=round(float(interference), 4),
            source_contributions=contributions,
        ))

    return scores
