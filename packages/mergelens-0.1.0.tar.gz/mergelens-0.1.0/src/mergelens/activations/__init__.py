"""Optional activation-based diagnostics (CKA similarity)."""
