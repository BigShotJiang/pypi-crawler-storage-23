"""gh-weekly-updates — auto-discover and summarise your weekly GitHub contributions."""
