from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='godmode-engine',  # 修改包名为防撞名的可用名称
    version='1.0.6',
    description='A highly optimized, commercial-grade 2D engine for AI single-prompt game generation.',
    long_description=long_description,
    long_description_content_type="text/markdown",
    author='Agentic Creator',
    author_email='nemetnagy205@gmail.com',
    url='https://github.com/godmode/godmode-engine',
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',
    install_requires=[
        'pygame-ce>=2.4.0',
        'numpy>=1.26.0'
    ]
)
