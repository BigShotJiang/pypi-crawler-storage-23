import numpy as np
import random

class ProceduralMaze:
    """
    随机 Prim 分形算法
    无限连缀爬塔网络地牢，绝不是基础的深搜直行。
    调用方式: `app.set_world(godmode.algorithms.ProceduralMaze(complexity="adaptive"))`
    """
    def __init__(self, complexity="adaptive", width=31, height=17):
        if complexity == "adaptive":
            pass 
        else:
            self.width = width if width % 2 != 0 else width + 1
            self.height = height if height % 2 != 0 else height + 1
            
        self.grid = None
        
    def generate(self, base_w, base_h):
        # 根据动态传入递增的长宽阶梯，生成无穷无尽规模的矩阵
        self.width = base_w if base_w % 2 != 0 else base_w + 1
        self.height = base_h if base_h % 2 != 0 else base_h + 1
        
        # 【算法突变】：抛弃长直回廊的 DFS，采用随机 Prim 算法 (Randomized Prim's algorithm)
        # Prim算法的数学特性是：它生成的树会有极高的“分支度(Branching Factor)”。
        # 它从中心向外如海绵或珊瑚般随机扩张，几乎没有完整的较长直路！
        # 每走 1~2 个格子就必定面临无数极具欺骗性的分叉短毛死胡同(False Paths)。
        # 这种“碎分形”网格矩阵能极大混淆人类的视线追踪能力，提供顶级的干扰抗性和硬核难度。
        
        self.grid = np.ones((self.height, self.width), dtype=int)
        
        start_x, start_y = 1, 1
        self.grid[start_y, start_x] = 0
        
        # 候选墙壁列表：(墙的 x, 墙的 y, 目标的 x, 目标的 y)
        walls = []
        for dx, dy in [(0, -2), (0, 2), (-2, 0), (2, 0)]:
            nx, ny = start_x + dx, start_y + dy
            if 0 < nx < self.width - 1 and 0 < ny < self.height - 1:
                walls.append((start_x + dx//2, start_y + dy//2, nx, ny))
                
        while walls:
            # Prim的核心逻辑：不追踪单线末端，而是从包含【所有历史路径】的边缘中随机向外伸展。
            # 这会导致大量的短小干扰分支遍布地图的每一个毛细血管。
            idx = random.randint(0, len(walls) - 1)
            wx, wy, nx, ny = walls.pop(idx)
            
            if self.grid[ny, nx] == 1:
                # 目标点是还没被染指的实心墙，打通它！
                self.grid[wy, wx] = 0  # 拆除横在中间的墙壁
                self.grid[ny, nx] = 0  # 占据新房间
                
                # 将新房间四面八方潜藏的隔离墙壁加入候选
                for dx, dy in [(0, -2), (0, 2), (-2, 0), (2, 0)]:
                    nnx, nny = nx + dx, ny + dy
                    if 0 < nnx < self.width - 1 and 0 < nny < self.height - 1:
                        if self.grid[nny, nnx] == 1:
                            walls.append((nx + dx//2, ny + dy//2, nnx, nny))

    def is_wall(self, tx, ty):
        if 0 <= tx < self.width and 0 <= ty < self.height:
            return self.grid[ty, tx] == 1
        return True
