import pygame
import sys
import math
import random
import os
from .vfx import Camera, ParticleSystem

class GodEngine:
    """
    神级宇宙渲染底座 (3A 级自适应框架)
    拥有全自动的 Letterbox 黑边 9:16 自适应防撕裂缩放（建议 422x750 尺寸），
    并带有多色泛光 Bloom 滤镜及自动热键防卡死退路 (Ctrl+P, Ctrl+Q)。
    
    使用方法与神级参数:
    app = GodEngine(title="标题", width=422, height=750, 
                    bg_color=(r,g,b), wall_color=(r,g,b), 
                    ground_color=(r,g,b), exit_color=(r,g,b))
    使用上述颜色参数（kwargs）大肆换皮！例如改成赛博粉、废土棕！
    """
    def __init__(self, title="GodMode Engine", theme="neon_abyss", width=422, height=750, **kwargs):
        pygame.init()
        pygame.font.init()
        # 逻辑基准宽高（渲染原始目标像素分辨率，绝不随拉伸改变）
        self.screen_w = width
        self.screen_h = height
        # 物理窗口当前真实宽高的拉伸缓存
        self.screen_current_w = width
        self.screen_current_h = height
        self.screen = pygame.display.set_mode((width, height), pygame.DOUBLEBUF | pygame.HWSURFACE | pygame.RESIZABLE)
        pygame.display.set_caption(title)
        
        # 导入中文字体兼容序列，为了极致的本地化展示
        font_fallbacks = "microsoftyahei,simhei,stsong,arial"
        self.font_large = pygame.font.SysFont(font_fallbacks, 56, bold=True)
        self.font_small = pygame.font.SysFont(font_fallbacks, 20)
        
        self.clock = pygame.time.Clock()
        self.surface = pygame.Surface((width, height))
        self.bloom_surf = pygame.Surface((width // 4, height // 4), pygame.SRCALPHA)
        self.is_running = True
        
        self.camera = Camera()
        self.vfx = ParticleSystem()
        
        self.world_generator = None
        self.player = None
        
        self.state = 0
        self.current_stage = 1
        
        # 如果没有传入特定的颜色配置，不再使用死板默认！强制开启随机色系变异！
        # 让每次裸奔 app = GodEngine() 都会遇到不重样的宇宙。
        has_colors = "bg_color" in kwargs or "wall_color" in kwargs
        if not has_colors:
            # 顶级 3A 商业化色彩主题库 (Themed palettes)，取代无脑数学随机，确保极致美学
            themes = [
                # 赛博之城 (Cyberpunk Night) - 暗紫底 + 荧光青终点
                {"bg": (8, 5, 15), "wall": (40, 20, 60), "ground": (15, 10, 25), "exit": (0, 255, 200)},
                # 鲜血废土 (Crimson Wasteland) - 暗红底 + 黄金终点
                {"bg": (15, 0, 0), "wall": (60, 10, 20), "ground": (20, 0, 5), "exit": (255, 200, 0)},
                # 剧毒沼泽 (Toxic Swamp) - 幽绿底 + 亮紫终点
                {"bg": (0, 10, 0), "wall": (10, 50, 20), "ground": (5, 20, 5), "exit": (255, 50, 255)},
                # 深海巨兽 (Deep Cthulhu) - 暗蓝底 + 炫彩红终点
                {"bg": (0, 5, 15), "wall": (10, 30, 60), "ground": (5, 15, 25), "exit": (255, 50, 100)},
                # 沙丘遗迹 (Golden Desert) - 琥珀底 + 天蓝终点
                {"bg": (15, 10, 0), "wall": (60, 40, 10), "ground": (25, 15, 0), "exit": (0, 200, 255)},
                # 蒸汽波 (Synthwave) - 品红底 + 亮青终点
                {"bg": (10, 0, 15), "wall": (50, 10, 60), "ground": (25, 5, 30), "exit": (0, 255, 255)},
                # 原初虚空 (Neon Abyss) - 灰暗底 + 鲜红终点
                {"bg": (5, 5, 8), "wall": (25, 20, 40), "ground": (10, 10, 15), "exit": (255, 50, 100)}
            ]
            t = random.choice(themes)
            self.bg_color = t["bg"]
            self.wall_color = t["wall"]
            self.ground_color = t["ground"]
            self.exit_color = t["exit"]
        else:
            self.bg_color = kwargs.get("bg_color", (5, 5, 8))
            self.wall_color = kwargs.get("wall_color", (25, 20, 40))
            self.ground_color = kwargs.get("ground_color", (10, 10, 15))
            self.exit_color = kwargs.get("exit_color", (255, 50, 100))
        
        self.maze_offset_x = 0
        self.maze_offset_y = 0
        
        # 弹窗提示文本与计时器
        self.toast_msg = ""
        self.toast_timer = 0

    def set_world(self, generator):
        self.world_generator = generator

    def bind_player(self, player):
        self.player = player

    def boot_level(self, diff_choice=None):
        if diff_choice is not None:
            self.state = 1
            # 选择初始起步段位 (初阶 1，进阶 6，地狱 12)
            if diff_choice == 1: self.current_stage = 1
            elif diff_choice == 2: self.current_stage = 6
            elif diff_choice == 3: self.current_stage = 12
        else:
            # 持续连战
            self.current_stage += 1
            
        pygame.mouse.set_visible(False)
        
        # 【无限地牢长宽膨胀公式】：伴随真实层数的提升，迷宫矩阵无尽扩张
        # 宽度每层加宽4单位，高度按9:16逼近递增加6单位
        w = 11 + (self.current_stage - 1) * 4
        h = 19 + (self.current_stage - 1) * 6
        self.world_generator.generate(w, h)
        
        # 核心逻辑：上帝视角的自适应全局缩放
        # 让矩阵的宽高根据屏幕分辨率自动计算出正确的格子像素大小 (tile_size)
        margin = 40
        avail_w = self.screen_w - margin * 2
        avail_h = self.screen_h - margin * 2
        
        tile_max_w = avail_w / self.world_generator.width
        tile_max_h = avail_h / self.world_generator.height
        new_tile_size = max(4, int(min(tile_max_w, tile_max_h)))
        
        self.player.tile_size = new_tile_size
        self.player.reset_pos(1, 1) # 重新计算位置大小
        
        self.exit_pos = (self.world_generator.width - 2, self.world_generator.height - 2)
        while self.world_generator.is_wall(self.exit_pos[0], self.exit_pos[1]):
            self.exit_pos = (self.exit_pos[0] - 1, self.exit_pos[1])
            
        ts = self.player.tile_size
        self.maze_surface = pygame.Surface((self.world_generator.width * ts, self.world_generator.height * ts))
        self.maze_surface.fill(self.wall_color)
        for y in range(self.world_generator.height):
            for x in range(self.world_generator.width):
                if not self.world_generator.grid[y, x]:
                    rect = pygame.Rect(x * ts, y * ts, ts, ts)
                    pygame.draw.rect(self.maze_surface, self.ground_color, rect)
                    
        # 计算将迷宫完美居中摆放的偏移量
        maze_pixel_w = self.world_generator.width * ts
        maze_pixel_h = self.world_generator.height * ts
        self.maze_offset_x = -(self.screen_w - maze_pixel_w) // 2
        self.maze_offset_y = -(self.screen_h - maze_pixel_h) // 2
        
        self.vfx.emit(self.screen_w/2, self.screen_h/2, self.exit_color, 100, size=10, life=1.0)
        self.camera.add_shake(20)

    def render_bloom(self):
        self.bloom_surf.fill((0, 0, 0, 0))
        pygame.transform.smoothscale(self.surface, self.bloom_surf.get_size(), self.bloom_surf)
        bloom_scaled = pygame.transform.smoothscale(self.bloom_surf, (self.screen_w, self.screen_h))
        self.surface.blit(bloom_scaled, (0, 0), special_flags=pygame.BLEND_RGB_ADD)

    def print_maze(self):
        # 护眼打印版：高分辨率白底黑线，可以输出给小孩子纸上画
        ts = 24
        pw = self.world_generator.width * ts
        ph = self.world_generator.height * ts
        print_surf = pygame.Surface((pw, ph))
        print_surf.fill((255, 255, 255))
        for y in range(self.world_generator.height):
            for x in range(self.world_generator.width):
                if self.world_generator.grid[y, x]:
                    rect = pygame.Rect(x * ts, y * ts, ts, ts)
                    pygame.draw.rect(print_surf, (20, 20, 20), rect)
        
        # 标记起点与终点位置
        pygame.draw.circle(print_surf, (50, 200, 50), (int(1.5*ts), int(1.5*ts)), ts//3)
        pygame.draw.circle(print_surf, (255, 50, 50), (int((self.exit_pos[0]+0.5)*ts), int((self.exit_pos[1]+0.5)*ts)), ts//3)
        
        file_name = f"maze_printable_{self.world_generator.width}x{self.world_generator.height}.png"
        pygame.image.save(print_surf, file_name)
        
        # 触发屏幕提示与系统层强视觉反馈（自动弹出看图器）
        self.toast_msg = f"已保存完美图版: {file_name}"
        self.toast_timer = 2.0
        
        # Win端小魔术：不仅存下来，直接调用用户的默认看图软件把它在屏幕上弹出来！防瞎眼必备。
        try:
            os.startfile(file_name)
        except Exception:
            pass

    def draw_menu(self):
        title1 = self.font_large.render("神级模式", True, (200, 240, 255))
        title2 = self.font_large.render("绝境迷宫", True, (200, 240, 255))
        text2 = self.font_small.render("按 1: 简单", True, (100, 255, 100))
        text3 = self.font_small.render("按 2: 普通", True, (255, 200, 100))
        text4 = self.font_small.render("按 3: 地狱", True, self.exit_color)
        
        w, h = self.screen_w // 2, self.screen_h // 2
        yo = math.sin(pygame.time.get_ticks() / 300.0) * 10
        self.surface.blit(title1, (w - title1.get_width()//2, h - 200 + yo))
        self.surface.blit(title2, (w - title2.get_width()//2, h - 140 + yo))
        self.surface.blit(text2, (w - text2.get_width()//2, h))
        self.surface.blit(text3, (w - text3.get_width()//2, h + 40))
        self.surface.blit(text4, (w - text4.get_width()//2, h + 80))
        
        text5 = self.font_small.render("[Ctrl+P] 护眼打印  |  [Ctrl+Q] 返回菜单", True, (150, 150, 150))
        self.surface.blit(text5, (w - text5.get_width()//2, h + 150))
        
        self.vfx.emit(w + random.randint(-80, 80), h + random.randint(-80, 80), (0, 150, 255), 1, size=4)

    def draw_play(self, cx, cy):
        self.surface.blit(self.maze_surface, (-cx, -cy))
        ts = self.player.tile_size
        ex, ey = self.exit_pos[0] * ts, self.exit_pos[1] * ts
        breath = abs(pygame.time.get_ticks() % 800 - 400) / 400.0
        pulse = 4 + int(breath * max(1, ts/4))
        pygame.draw.rect(self.surface, self.exit_color, 
                       (ex - cx + pulse, ey - cy + pulse, ts - pulse*2, ts - pulse*2), border_radius=4)
        self.player.draw(self.surface, cx, cy)

    def draw_ui(self):
        # 顶层状态栏展示：模式动态晋升与递增进度
        if self.state == 1:
            if self.current_stage < 6:
                diff_name = "难度:初级试炼"
                sub_level = self.current_stage
            elif self.current_stage < 12:
                diff_name = "难度:进阶挑战"
                sub_level = self.current_stage - 5
            elif self.current_stage < 20:
                diff_name = "难度:地狱绝境"
                sub_level = self.current_stage - 11
            else:
                diff_name = "难度:无尽深渊"
                sub_level = self.current_stage - 19
                
            status_text = self.font_small.render(f"{diff_name} | 第 {sub_level} 层", True, (200, 250, 200))
            self.screen.blit(status_text, (15, 15))

        # UI与Toast抽离到泛光渲染之后，防止被发光和模糊给污染
        if self.toast_timer > 0:
            toast_text = self.font_small.render(self.toast_msg, True, (255, 255, 255))
            bg_rect = pygame.Surface((toast_text.get_width() + 20, toast_text.get_height() + 10), pygame.SRCALPHA)
            bg_rect.fill((0, 0, 0, 220))
            bg_rect.blit(toast_text, (10, 5))
            self.screen.blit(bg_rect, (self.screen_current_w // 2 - bg_rect.get_width() // 2, 50))

    def ignite(self):
        # 防白痴/防AI过度精简机制：如果没有被主动注入世界和玩家，自动用神级默认类托底！
        if self.world_generator is None:
            from .algorithms import ProceduralMaze
            self.set_world(ProceduralMaze(complexity="adaptive"))
        if self.player is None:
            from .entities import NeonPlayer
            self.bind_player(NeonPlayer(juice_level="MAX"))
            
        while self.is_running:
            dt = self.clock.tick(60) / 1000.0
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.is_running = False
                if event.type == pygame.VIDEORESIZE:
                    # 动态捕获用户拉伸的窗口最新物理尺寸
                    self.screen_current_w = event.w
                    self.screen_current_h = event.h
                    self.screen = pygame.display.set_mode((self.screen_current_w, self.screen_current_h), 
                                                          pygame.DOUBLEBUF | pygame.HWSURFACE | pygame.RESIZABLE)
                
                if event.type == pygame.KEYDOWN:
                    mods = pygame.key.get_mods()
                    is_ctrl = bool(mods & pygame.KMOD_CTRL)
                    
                    if self.state == 0:
                        if event.key == pygame.K_1: self.boot_level(1)
                        elif event.key == pygame.K_2: self.boot_level(2)
                        elif event.key == pygame.K_3: self.boot_level(3)
                        elif (event.key == pygame.K_q and is_ctrl) or event.key == pygame.K_ESCAPE:
                            self.is_running = False
                    elif self.state == 1:
                        if (event.key == pygame.K_q and is_ctrl) or event.key == pygame.K_ESCAPE:
                            self.state = 0
                        elif event.key == pygame.K_p and is_ctrl:
                            self.print_maze()
                        elif event.key not in [pygame.K_LCTRL, pygame.K_RCTRL]:
                            # 将常规方向键下发给高级实体管理器，屏蔽单纯的CTRL键扰动
                            self.player.handle_keydown(event, self.world_generator, self.vfx, self.camera)
                            
                if event.type == pygame.KEYUP:
                    if self.state == 1:
                        self.player.handle_keyup(event)
            
            self.surface.fill(self.bg_color)
            self.vfx.update(dt)
            if self.toast_timer > 0:
                self.toast_timer -= dt
            
            if self.state == 0:
                self.draw_menu()
                self.vfx.draw(self.surface, 0, 0)
            else:
                keys = pygame.key.get_pressed()
                self.player.handle_input(keys, self.world_generator, self.vfx, self.camera)
                self.player.update(dt)
                
                # 直接将相机锚定在完美居中的全景偏移量上，不再跟随玩家（但保留震屏）
                tx = self.maze_offset_x
                ty = self.maze_offset_y
                cx, cy = self.camera.update(dt, tx, ty)
                
                if self.player.grid_x == self.exit_pos[0] and self.player.grid_y == self.exit_pos[1]:
                    px, py = self.player.get_screen_pos()
                    self.vfx.emit(px - tx, py - ty, self.exit_color, 80, size=15)
                    self.camera.add_shake(25)
                    # 走完不退出！无底洞向下攀升，难度体积自动扩张！
                    self.boot_level()
                
                self.draw_play(cx, cy)
                self.vfx.draw(self.surface, cx, cy)
            
            self.render_bloom()
            
            # 【终极防溢出渲染：计算等比缩放贴图 (Letterboxing) 到物理窗体区域】
            scale_ratio = min(self.screen_current_w / self.screen_w, self.screen_current_h / self.screen_h)
            new_w = int(self.screen_w * scale_ratio)
            new_h = int(self.screen_h * scale_ratio)
            scaled_surface = pygame.transform.smoothscale(self.surface, (new_w, new_h))
            
            # 计算居中留白 (黑边坐标)
            offset_x = (self.screen_current_w - new_w) // 2
            offset_y = (self.screen_current_h - new_h) // 2
            
            # 先给真实的物理窗口涂黑，然后将缩放后的游戏画面贴在居中位置
            self.screen.fill((0, 0, 0))
            self.screen.blit(scaled_surface, (offset_x, offset_y))
            
            self.draw_ui()  # 最后绘制UI防缩放模糊
            pygame.display.flip()
            
        pygame.quit()
        sys.exit()
