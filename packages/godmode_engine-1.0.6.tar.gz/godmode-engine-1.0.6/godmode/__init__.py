"""
GodMode Engine (godmode-engine) - The Ultimate AI-Native 2D Game Framework.
神级引擎：为大模型“一句话生成游戏”打造的顶级 2D 商业视觉底座库。

[快速启动代码 (Quick Start 15-lines!)]
import godmode
# 1. 唤醒神级引擎内置框架：支持各种瞎编背景色、墙壁色换皮
app = godmode.GodEngine(
    title="AI Labyrinth", 
    width=422, height=750,
    bg_color=(15, 0, 0),         # 自定义底色
    wall_color=(60, 10, 20),     # 自定义墙色
    ground_color=(20, 0, 5),     # 自定义地面色
    exit_color=(255, 200, 0)     # 自定义终点色
)
# 2. 注入自适应算法世界：目前提供顶级自适应迷宫
app.set_world(godmode.algorithms.ProceduralMaze(complexity="adaptive"))
# 3. 部署具有 DAS 高手感/拖尾特效的主角
app.bind_player(godmode.entities.NeonPlayer(glow_color=(0, 255, 200), juice_level="MAX"))
# 4. 点燃宇宙
if __name__ == "__main__":
    app.ignite()
"""
from .engine import GodEngine
from . import algorithms
from . import entities
from . import vfx

__all__ = ['GodEngine', 'algorithms', 'entities', 'vfx']
