import pygame

class NeonPlayer:
    """
    顶级果汁核心实体：主角方块拥有全局发光混合（RGB_ADD）与弹道发射特效
    调用方式：`NeonPlayer(glow_color=(r, g, b), juice_level="MAX")`
    使用 glow_color 来配合 engine 的背景打造属于你的极致颜色流！
    拥有超越普通单次检测的“DAS电竞平滑连按”操作手感。
    """
    def __init__(self, glow_color=(0, 255, 200), juice_level="MAX"):
        self.glow_color = glow_color
        self.juice_level = juice_level
        self.grid_x = 1
        self.grid_y = 1
        self.tile_size = 32
        self.x = self.grid_x * self.tile_size
        self.y = self.grid_y * self.tile_size
        self.target_x = self.x
        self.target_y = self.y
        self.speed = 30.0 # 提高动画追平速度
        
        # DAS (Delayed Auto Shift) 与 ARR (Auto Repeat Rate) 高级电竞操作手感参数
        self.das_delay = 0.15   # 首次按下后等待多久开始连发 (150ms)
        self.arr_rate = 0.05    # 连发开始后，每次滑动的间隔 (50ms)
        self.move_timer = 0.0
        self.current_direction = None

    def get_screen_pos(self):
        return self.x + self.tile_size/2, self.y + self.tile_size/2

    def reset_pos(self, x, y):
        self.grid_x, self.grid_y = x, y
        self.x = self.grid_x * self.tile_size
        self.y = self.grid_y * self.tile_size
        self.target_x = self.x
        self.target_y = self.y

    def try_move(self, dx, dy, maze, vfx, camera):
        new_gx = self.grid_x + dx
        new_gy = self.grid_y + dy
        if not maze.is_wall(new_gx, new_gy):
            self.grid_x = new_gx
            self.grid_y = new_gy
            self.target_x = self.grid_x * self.tile_size
            self.target_y = self.grid_y * self.tile_size
            if self.juice_level == "MAX":
                vfx.emit(self.x + self.tile_size/2, self.y + self.tile_size/2, self.glow_color, 2)
            return True
        else:
            if self.juice_level == "MAX" and dx == 0 and dy == 0:
                pass # 原点不变不震
            elif self.juice_level == "MAX" and self.move_timer <= 0:
                # 只在每次连发周期撞击时才触发一次震动，防止极散的视差
                camera.add_shake(4)
                vfx.emit(self.x + self.tile_size/2 + dx * 10, self.y + self.tile_size/2 + dy * 10, (150, 50, 50), 3)
            return False

    def handle_keydown(self, event, maze, vfx, camera):
        """处理单次立刻触发与覆盖按压"""
        dx, dy = 0, 0
        if event.key in [pygame.K_UP, pygame.K_w]: dy = -1
        elif event.key in [pygame.K_DOWN, pygame.K_s]: dy = 1
        elif event.key in [pygame.K_LEFT, pygame.K_a]: dx = -1
        elif event.key in [pygame.K_RIGHT, pygame.K_d]: dx = 1
        
        if dx != 0 or dy != 0:
            self.current_direction = (dx, dy)
            self.try_move(dx, dy, maze, vfx, camera)
            self.move_timer = self.das_delay # 启动 DAS 预摇延时

    def handle_keyup(self, event):
        """松开按键清除方向"""
        dx, dy = 0, 0
        if event.key in [pygame.K_UP, pygame.K_w]: dy = -1
        elif event.key in [pygame.K_DOWN, pygame.K_s]: dy = 1
        elif event.key in [pygame.K_LEFT, pygame.K_a]: dx = -1
        elif event.key in [pygame.K_RIGHT, pygame.K_d]: dx = 1
        if self.current_direction == (dx, dy):
            self.current_direction = None

    def handle_input(self, keys, maze, vfx, camera):
        """处理按住阶段的连发逻辑"""
        # 如果还在按着之前的方向，且冷却完毕，立刻触发连发
        if self.current_direction and self.move_timer <= 0:
            dx, dy = self.current_direction
            # 确认物理键盘依然被按压
            is_pressed = False
            if dx == -1 and (keys[pygame.K_LEFT] or keys[pygame.K_a]): is_pressed = True
            elif dx == 1 and (keys[pygame.K_RIGHT] or keys[pygame.K_d]): is_pressed = True
            elif dy == -1 and (keys[pygame.K_UP] or keys[pygame.K_w]): is_pressed = True
            elif dy == 1 and (keys[pygame.K_DOWN] or keys[pygame.K_s]): is_pressed = True
            
            if is_pressed:
                self.try_move(dx, dy, maze, vfx, camera)
                self.move_timer = self.arr_rate # 按 ARR 的速率高频发射

    def update(self, dt):
        if self.move_timer > 0:
            self.move_timer -= dt
        self.x += (self.target_x - self.x) * self.speed * dt
        self.y += (self.target_y - self.y) * self.speed * dt

    def draw(self, surface, cx, cy):
        rect = pygame.Rect(self.x - cx + 2, self.y - cy + 2, self.tile_size - 4, self.tile_size - 4)
        pygame.draw.rect(surface, self.glow_color, rect, border_radius=6)
        core_rect = pygame.Rect(self.x - cx + 8, self.y - cy + 8, self.tile_size - 16, self.tile_size - 16)
        pygame.draw.rect(surface, (255, 255, 255), core_rect, border_radius=2)
