"""Router registry for Plinth.

This file is auto-managed by Plinth. Manual edits may be overwritten.
Add your custom routers below the Plinth-managed section.
"""

from fastapi import APIRouter

# =============================================================================
# PLINTH-MANAGED ROUTERS - DO NOT EDIT MANUALLY
# Plinth will automatically append new module routers here
# =============================================================================
ROUTERS: list[APIRouter] = []

# =============================================================================
# CUSTOM ROUTERS - Add your own routers below
# =============================================================================
# Example:
# from src.api.v1.users import router as users_router
# ROUTERS.append(users_router)
