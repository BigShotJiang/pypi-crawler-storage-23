"""Entry point for running plinth as a module."""

from plinth.cli import app

if __name__ == "__main__":
    app()
