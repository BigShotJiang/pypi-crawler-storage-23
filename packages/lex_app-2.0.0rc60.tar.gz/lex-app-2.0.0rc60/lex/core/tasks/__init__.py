from lex.core.tasks.CeleryTaskDispatcher import CeleryTaskDispatcher

__all__ = ['CeleryTaskDispatcher']
