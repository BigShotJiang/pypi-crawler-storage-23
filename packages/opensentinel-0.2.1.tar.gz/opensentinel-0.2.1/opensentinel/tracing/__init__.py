"""Open Sentinel tracing and observability."""

from opensentinel.tracing.otel_tracer import SentinelTracer

__all__ = ["SentinelTracer"]
