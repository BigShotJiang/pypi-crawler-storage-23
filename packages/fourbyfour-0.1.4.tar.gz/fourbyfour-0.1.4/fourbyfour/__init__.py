"""
Fourbyfour SDK

Revenue workflows on autopilot.

Example:
    from fourbyfour import saas

    fbf = saas(api_key="sk_...", project_id="proj_...")

    # Track events → triggers workflows
    fbf.track("payment.failed", {
        "user_id": "u_123",
        "amount": 99.0,
        "currency": "USD",
        "plan": "Pro",
        "subscription_id": "sub_456",
        "billing_cycle": "monthly"
    })

    # Send context → helps optimize
    fbf.notify({
        "user_id": "u_123",
        "timezone": "Asia/Kolkata",
        "tier": "premium"
    })
"""

from .client import (
    AppsClient,
    EcommerceClient,
    EdtechClient,
    FintechClient,
    GamesClient,
    NotifyResult,
    SaaSClient,
    TrackResult,
    apps,
    ecommerce,
    edtech,
    fintech,
    games,
    saas,
)
from .errors import (
    AuthenticationError,
    ConflictError,
    ForbiddenError,
    FourbyfourError,
    InternalError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from .events import (
    AppsEventName,
    AppsFeatureUsed,
    AppsMilestoneReached,
    AppsPaymentFailed,
    AppsReviewRequested,
    AppsSubscriptionCanceled,
    AppsSubscriptionRenewed,
    AppsTrialEnding,
    AppsTrialStarted,
    AppsUserInactive,
    CartItem,
    EcommerceCartAbandoned,
    EcommerceEventName,
    EcommerceOrderDelivered,
    EcommerceOrderPlaced,
    EcommerceOrderShipped,
    EcommercePaymentFailed,
    EcommerceProductViewed,
    EcommerceRefundRequested,
    EcommerceReviewSubmitted,
    EcommerceWishlistAdded,
    EdtechCertificateEarned,
    EdtechCourseAbandoned,
    EdtechCourseEnrolled,
    EdtechEventName,
    EdtechLessonCompleted,
    EdtechPaymentFailed,
    EdtechQuizPassed,
    EdtechStreakAchieved,
    EdtechStreakBroken,
    FintechAccountDormant,
    FintechEventName,
    FintechGoalAchieved,
    FintechGoalCreated,
    FintechKycIncomplete,
    FintechPaymentDue,
    FintechPaymentFailed,
    FintechSpendUnusual,
    FintechTransactionFailed,
    GamesAchievementUnlocked,
    GamesBossFailed,
    GamesCurrencyLow,
    GamesEventName,
    GamesFriendInvited,
    GamesLevelCompleted,
    GamesPaymentFailed,
    GamesPlayerInactive,
    GamesStreakBroken,
    NpsSubmitted,
    PaymentFailed,
    ReferralSent,
    SaaSEventName,
    SaaSFeatureAdopted,
    SaaSNpsSubmitted,
    SaaSPaymentFailed,
    SaaSSubscriptionCanceled,
    SaaSSubscriptionDowngraded,
    SaaSSubscriptionUpgraded,
    SaaSTrialEnding,
    SaaSTrialStarted,
    SaaSUsageThreshold,
    UserContext,
    UserSignup,
    Vertical,
)

__version__ = "0.1.0"

__all__ = [
    # Factory functions
    "saas",
    "ecommerce",
    "fintech",
    "edtech",
    "games",
    "apps",
    # Client types
    "SaaSClient",
    "EcommerceClient",
    "FintechClient",
    "EdtechClient",
    "GamesClient",
    "AppsClient",
    # Result types
    "TrackResult",
    "NotifyResult",
    # Event types
    "Vertical",
    "UserContext",
    "SaaSEventName",
    "EcommerceEventName",
    "FintechEventName",
    "EdtechEventName",
    "GamesEventName",
    "AppsEventName",
    # Shared events
    "PaymentFailed",
    "UserSignup",
    "NpsSubmitted",
    "ReferralSent",
    # SaaS events
    "SaaSTrialStarted",
    "SaaSTrialEnding",
    "SaaSSubscriptionCanceled",
    "SaaSUsageThreshold",
    "SaaSPaymentFailed",
    "SaaSSubscriptionUpgraded",
    "SaaSSubscriptionDowngraded",
    "SaaSFeatureAdopted",
    "SaaSNpsSubmitted",
    # E-commerce events
    "CartItem",
    "EcommerceCartAbandoned",
    "EcommerceOrderPlaced",
    "EcommerceOrderShipped",
    "EcommerceOrderDelivered",
    "EcommercePaymentFailed",
    "EcommerceProductViewed",
    "EcommerceWishlistAdded",
    "EcommerceRefundRequested",
    "EcommerceReviewSubmitted",
    # Fintech events
    "FintechTransactionFailed",
    "FintechPaymentDue",
    "FintechAccountDormant",
    "FintechKycIncomplete",
    "FintechPaymentFailed",
    "FintechGoalCreated",
    "FintechGoalAchieved",
    "FintechSpendUnusual",
    # EdTech events
    "EdtechCourseEnrolled",
    "EdtechLessonCompleted",
    "EdtechCourseAbandoned",
    "EdtechCertificateEarned",
    "EdtechPaymentFailed",
    "EdtechStreakAchieved",
    "EdtechStreakBroken",
    "EdtechQuizPassed",
    # Games events
    "GamesPlayerInactive",
    "GamesLevelCompleted",
    "GamesCurrencyLow",
    "GamesAchievementUnlocked",
    "GamesPaymentFailed",
    "GamesStreakBroken",
    "GamesFriendInvited",
    "GamesBossFailed",
    # Apps events
    "AppsTrialStarted",
    "AppsTrialEnding",
    "AppsSubscriptionCanceled",
    "AppsUserInactive",
    "AppsFeatureUsed",
    "AppsPaymentFailed",
    "AppsReviewRequested",
    "AppsMilestoneReached",
    "AppsSubscriptionRenewed",
    # Errors
    "FourbyfourError",
    "ValidationError",
    "AuthenticationError",
    "ForbiddenError",
    "NotFoundError",
    "ConflictError",
    "RateLimitError",
    "InternalError",
]
