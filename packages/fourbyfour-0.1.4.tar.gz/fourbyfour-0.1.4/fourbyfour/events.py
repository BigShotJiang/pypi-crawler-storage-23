"""
Fourbyfour Event Schemas

Events are organized by vertical. Each event maps to a pre-built,
cross-org optimized workflow.

Two categories:
1. Revenue Recovery - high-intent, high-impact moments
2. Customer Lifecycle - engagement and growth moments
"""

from typing import Literal, TypedDict

from typing_extensions import NotRequired

# =============================================================================
# SHARED (Available in all verticals)
# =============================================================================

class PaymentFailed(TypedDict):
    user_id: str
    amount: float
    currency: str
    failure_reason: NotRequired[
        Literal['insufficient_funds', 'card_expired', 'card_declined', 'other']
    ]
    retry_count: NotRequired[int]
    payment_method: NotRequired[Literal['card', 'upi', 'bank_transfer', 'wallet']]


class UserSignup(TypedDict):
    user_id: str
    channel: NotRequired[Literal['organic', 'paid', 'referral', 'social']]
    referred_by: NotRequired[str]


class NpsSubmitted(TypedDict):
    user_id: str
    score: int  # 0-10
    feedback: NotRequired[str]
    category: NotRequired[Literal['promoter', 'passive', 'detractor']]


class ReferralSent(TypedDict):
    user_id: str
    referral_code: str
    channel: NotRequired[Literal['email', 'sms', 'link', 'social']]


# =============================================================================
# SAAS
# =============================================================================

class SaaSTrialStarted(TypedDict):
    user_id: str
    plan: str
    trial_days: int
    features: NotRequired[list[str]]


class SaaSTrialEnding(TypedDict):
    user_id: str
    plan: str
    days_remaining: int
    usage_percent: NotRequired[float]


class SaaSSubscriptionCanceled(TypedDict):
    user_id: str
    plan: str
    reason: NotRequired[
        Literal['too_expensive', 'not_using', 'missing_features', 'competitor', 'other']
    ]
    mrr: float
    tenure: NotRequired[int]  # months subscribed


class SaaSUsageThreshold(TypedDict):
    user_id: str
    plan: str
    resource: str  # 'seats', 'api_calls', 'storage', etc.
    usage_percent: float  # 80, 90, 100
    current_usage: float
    limit: float


class SaaSPaymentFailed(PaymentFailed):
    plan: str
    subscription_id: str
    billing_cycle: Literal['monthly', 'yearly']


class SaaSSubscriptionUpgraded(TypedDict):
    user_id: str
    from_plan: str
    to_plan: str
    new_mrr: float
    trigger: NotRequired[Literal['usage', 'feature_need', 'self_serve', 'sales']]


class SaaSSubscriptionDowngraded(TypedDict):
    user_id: str
    from_plan: str
    to_plan: str
    mrr_lost: float
    reason: NotRequired[str]


class SaaSFeatureAdopted(TypedDict):
    user_id: str
    feature: str
    plan: str
    usage_count: NotRequired[int]


class SaaSNpsSubmitted(NpsSubmitted):
    plan: str
    tenure: NotRequired[int]


# =============================================================================
# E-COMMERCE
# =============================================================================

class CartItem(TypedDict):
    id: str
    name: str
    price: float
    quantity: int
    image: NotRequired[str]
    category: NotRequired[str]


class EcommerceCartAbandoned(TypedDict):
    user_id: str
    cart_id: str
    items: list[CartItem]
    total: float
    currency: str
    abandoned_at: NotRequired[Literal['cart', 'checkout', 'payment']]


class ShippingAddress(TypedDict):
    city: str
    country: str


class EcommerceOrderPlaced(TypedDict):
    user_id: str
    order_id: str
    items: list[CartItem]
    total: float
    currency: str
    is_first_order: NotRequired[bool]
    shipping_address: NotRequired[ShippingAddress]


class EcommerceOrderShipped(TypedDict):
    user_id: str
    order_id: str
    tracking_id: NotRequired[str]
    carrier: NotRequired[str]
    estimated_delivery: NotRequired[str]


class EcommerceOrderDelivered(TypedDict):
    user_id: str
    order_id: str
    delivered_at: NotRequired[str]


class EcommercePaymentFailed(PaymentFailed):
    order_id: str
    items: list[CartItem]


class EcommerceProductViewed(TypedDict):
    user_id: str
    product_id: str
    product_name: str
    price: float
    category: NotRequired[str]
    view_count: NotRequired[int]


class EcommerceWishlistAdded(TypedDict):
    user_id: str
    product_id: str
    product_name: str
    price: float
    category: NotRequired[str]


class EcommerceRefundRequested(TypedDict):
    user_id: str
    order_id: str
    amount: float
    reason: NotRequired[
        Literal['damaged', 'wrong_item', 'not_as_described', 'changed_mind', 'other']
    ]
    items: list[CartItem]


class EcommerceReviewSubmitted(TypedDict):
    user_id: str
    order_id: str
    product_id: str
    rating: int  # 1-5
    has_text: NotRequired[bool]


# =============================================================================
# FINTECH
# =============================================================================

class FintechTransactionFailed(TypedDict):
    user_id: str
    transaction_id: str
    amount: float
    currency: str
    type: Literal['send', 'receive', 'withdraw', 'deposit']
    failure_reason: NotRequired[str]


class FintechPaymentDue(TypedDict):
    user_id: str
    amount: float
    currency: str
    due_date: str
    type: Literal['loan_emi', 'credit_card', 'bill', 'subscription']
    days_until_due: int


class FintechAccountDormant(TypedDict):
    user_id: str
    last_active_at: str
    days_since_active: int
    account_balance: NotRequired[float]


class FintechKycIncomplete(TypedDict):
    user_id: str
    step: Literal['identity', 'address', 'selfie', 'documents']
    started_at: NotRequired[str]
    percent_complete: NotRequired[float]


class FintechPaymentFailed(PaymentFailed):
    type: Literal['loan_emi', 'credit_card', 'bill', 'subscription']
    due_date: NotRequired[str]


class FintechGoalCreated(TypedDict):
    user_id: str
    goal_id: str
    goal_name: str
    target_amount: float
    target_date: NotRequired[str]
    category: NotRequired[Literal['savings', 'investment', 'emergency', 'purchase', 'other']]


class FintechGoalAchieved(TypedDict):
    user_id: str
    goal_id: str
    goal_name: str
    amount: float
    days_to_complete: NotRequired[int]


class FintechSpendUnusual(TypedDict):
    user_id: str
    transaction_id: str
    amount: float
    category: NotRequired[str]
    deviation: NotRequired[float]  # percentage above normal
    is_high_risk: NotRequired[bool]


# =============================================================================
# EDTECH
# =============================================================================

class EdtechCourseEnrolled(TypedDict):
    user_id: str
    course_id: str
    course_name: str
    price: NotRequired[float]
    is_free: NotRequired[bool]


class EdtechLessonCompleted(TypedDict):
    user_id: str
    course_id: str
    lesson_id: str
    progress_percent: float


class EdtechCourseAbandoned(TypedDict):
    user_id: str
    course_id: str
    course_name: str
    progress_percent: float
    last_active_at: str
    days_since_active: int


class EdtechCertificateEarned(TypedDict):
    user_id: str
    course_id: str
    course_name: str
    certificate_id: str


class EdtechPaymentFailed(PaymentFailed):
    course_id: NotRequired[str]
    subscription_plan: NotRequired[str]


class EdtechStreakAchieved(TypedDict):
    user_id: str
    streak_days: int
    milestone: NotRequired[bool]  # 7, 30, 100 days etc


class EdtechStreakBroken(TypedDict):
    user_id: str
    previous_streak: int
    last_active_at: str


class EdtechQuizPassed(TypedDict):
    user_id: str
    course_id: str
    quiz_id: str
    score: float
    passing_score: float
    attempts: NotRequired[int]


# =============================================================================
# GAMES
# =============================================================================

class GamesPlayerInactive(TypedDict):
    user_id: str
    last_played_at: str
    days_since_active: int
    level: NotRequired[int]
    total_playtime: NotRequired[int]  # minutes


class GamesLevelCompleted(TypedDict):
    user_id: str
    level: int
    score: NotRequired[int]
    time_spent: NotRequired[int]  # seconds
    stars: NotRequired[int]


class GamesCurrencyLow(TypedDict):
    user_id: str
    currency_type: Literal['coins', 'gems', 'energy', 'lives']
    current_balance: float
    last_purchase_at: NotRequired[str]


class GamesAchievementUnlocked(TypedDict):
    user_id: str
    achievement_id: str
    achievement_name: str
    rarity: NotRequired[Literal['common', 'rare', 'epic', 'legendary']]


class GamesPaymentFailed(PaymentFailed):
    item_id: NotRequired[str]
    item_type: NotRequired[Literal['iap', 'subscription', 'bundle']]


class GamesStreakBroken(TypedDict):
    user_id: str
    previous_streak: int
    last_played_at: str
    comeback_bonus: NotRequired[float]


class GamesFriendInvited(TypedDict):
    user_id: str
    invite_code: str
    channel: NotRequired[Literal['link', 'social', 'sms']]
    friend_joined: NotRequired[bool]


class GamesBossFailed(TypedDict):
    user_id: str
    boss_id: str
    boss_name: NotRequired[str]
    attempts: int
    level: int


# =============================================================================
# APPS (Paid Apps / Subscriptions)
# =============================================================================

class AppsTrialStarted(TypedDict):
    user_id: str
    plan: str
    trial_days: int
    platform: Literal['ios', 'android', 'web']


class AppsTrialEnding(TypedDict):
    user_id: str
    plan: str
    days_remaining: int
    sessions_in_trial: NotRequired[int]


class AppsSubscriptionCanceled(TypedDict):
    user_id: str
    plan: str
    reason: NotRequired[Literal['too_expensive', 'not_using', 'found_alternative', 'other']]
    platform: Literal['ios', 'android', 'web']


class AppsUserInactive(TypedDict):
    user_id: str
    last_active_at: str
    days_since_active: int
    plan: NotRequired[str]


class AppsFeatureUsed(TypedDict):
    user_id: str
    feature: str
    usage_count: int
    plan: NotRequired[str]


class AppsPaymentFailed(PaymentFailed):
    plan: str
    platform: Literal['ios', 'android', 'web']
    subscription_id: NotRequired[str]


class AppsReviewRequested(TypedDict):
    user_id: str
    platform: Literal['ios', 'android']
    app_version: str
    session_count: NotRequired[int]
    rating: NotRequired[int]


class AppsMilestoneReached(TypedDict):
    user_id: str
    milestone: str
    value: NotRequired[float]
    plan: NotRequired[str]


class AppsSubscriptionRenewed(TypedDict):
    user_id: str
    plan: str
    platform: Literal['ios', 'android', 'web']
    renewal_count: int
    mrr: float


# =============================================================================
# CONTEXT (for notify)
# =============================================================================

class UserContext(TypedDict, total=False):
    user_id: str  # Required

    # Delivery optimization
    timezone: str
    locale: str
    preferred_channel: Literal['email', 'sms', 'push', 'whatsapp', 'in_app']
    quiet_hours_start: int  # 0-23
    quiet_hours_end: int  # 0-23

    # User attributes
    tier: Literal['free', 'basic', 'premium', 'enterprise']
    plan: str
    platform: Literal['ios', 'android', 'web']

    # Engagement signals
    last_seen_at: str
    session_count: int
    engagement_score: Literal['low', 'medium', 'high']

    # Outcome feedback (helps optimize)
    converted: bool
    revenue: float
    ltv: float


# =============================================================================
# VERTICAL TYPE LITERALS
# =============================================================================

Vertical = Literal['saas', 'ecommerce', 'fintech', 'edtech', 'games', 'apps']

# Event name literals per vertical
SaaSEventName = Literal[
    'trial.started', 'trial.ending', 'subscription.canceled', 'usage.threshold',
    'payment.failed', 'subscription.upgraded', 'subscription.downgraded',
    'feature.adopted', 'nps.submitted', 'user.signup', 'referral.sent'
]

EcommerceEventName = Literal[
    'cart.abandoned', 'order.placed', 'order.shipped', 'order.delivered',
    'payment.failed', 'product.viewed', 'wishlist.added', 'refund.requested',
    'review.submitted', 'user.signup', 'referral.sent'
]

FintechEventName = Literal[
    'transaction.failed', 'payment.due', 'account.dormant', 'kyc.incomplete',
    'payment.failed', 'goal.created', 'goal.achieved', 'spend.unusual',
    'user.signup', 'referral.sent'
]

EdtechEventName = Literal[
    'course.enrolled', 'lesson.completed', 'course.abandoned', 'certificate.earned',
    'payment.failed', 'streak.achieved', 'streak.broken', 'quiz.passed',
    'user.signup', 'referral.sent'
]

GamesEventName = Literal[
    'player.inactive', 'level.completed', 'currency.low', 'achievement.unlocked',
    'payment.failed', 'streak.broken', 'friend.invited', 'boss.failed',
    'user.signup', 'referral.sent'
]

AppsEventName = Literal[
    'trial.started', 'trial.ending', 'subscription.canceled', 'user.inactive',
    'feature.used', 'payment.failed', 'review.requested', 'milestone.reached',
    'subscription.renewed', 'user.signup', 'referral.sent'
]
