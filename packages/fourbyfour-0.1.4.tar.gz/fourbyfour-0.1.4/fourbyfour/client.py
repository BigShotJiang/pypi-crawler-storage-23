"""
Fourbyfour SDK

Two functions. That's it.
- track(): Events that trigger workflows
- notify(): Context that helps optimize
"""

from dataclasses import dataclass
from typing import Any, Generic, Optional, TypeVar, Union

from .events import (
    # Apps
    AppsEventName,
    AppsFeatureUsed,
    AppsMilestoneReached,
    AppsPaymentFailed,
    AppsReviewRequested,
    AppsSubscriptionCanceled,
    AppsSubscriptionRenewed,
    AppsTrialEnding,
    AppsTrialStarted,
    AppsUserInactive,
    EcommerceCartAbandoned,
    # E-commerce
    EcommerceEventName,
    EcommerceOrderDelivered,
    EcommerceOrderPlaced,
    EcommerceOrderShipped,
    EcommercePaymentFailed,
    EcommerceProductViewed,
    EcommerceRefundRequested,
    EcommerceReviewSubmitted,
    EcommerceWishlistAdded,
    EdtechCertificateEarned,
    EdtechCourseAbandoned,
    EdtechCourseEnrolled,
    # EdTech
    EdtechEventName,
    EdtechLessonCompleted,
    EdtechPaymentFailed,
    EdtechQuizPassed,
    EdtechStreakAchieved,
    EdtechStreakBroken,
    FintechAccountDormant,
    # Fintech
    FintechEventName,
    FintechGoalAchieved,
    FintechGoalCreated,
    FintechKycIncomplete,
    FintechPaymentDue,
    FintechPaymentFailed,
    FintechSpendUnusual,
    FintechTransactionFailed,
    GamesAchievementUnlocked,
    GamesBossFailed,
    GamesCurrencyLow,
    # Games
    GamesEventName,
    GamesFriendInvited,
    GamesLevelCompleted,
    GamesPaymentFailed,
    GamesPlayerInactive,
    GamesStreakBroken,
    ReferralSent,
    # SaaS
    SaaSEventName,
    SaaSFeatureAdopted,
    SaaSNpsSubmitted,
    SaaSPaymentFailed,
    SaaSSubscriptionCanceled,
    SaaSSubscriptionDowngraded,
    SaaSSubscriptionUpgraded,
    SaaSTrialEnding,
    SaaSTrialStarted,
    SaaSUsageThreshold,
    UserContext,
    # Shared
    UserSignup,
    Vertical,
)
from .http import HttpClient

DEFAULT_BASE_URL = "https://api.fourbyfour.dev"

V = TypeVar("V", bound=Vertical)


# =============================================================================
# RESULT TYPES
# =============================================================================

@dataclass
class TrackResult:
    """Result of tracking an event."""
    event_id: str
    workflows_triggered: list[str]


@dataclass
class NotifyResult:
    """Result of sending context."""
    success: bool


# =============================================================================
# BASE CLIENT
# =============================================================================

class FourbyfourClient(Generic[V]):
    """
    Fourbyfour SDK client.

    Use vertical-specific factory functions instead:
    - saas()
    - ecommerce()
    - fintech()
    - edtech()
    - games()
    - apps()
    """

    def __init__(
        self,
        api_key: str,
        project_id: str,
        *,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        if not project_id:
            raise ValueError("project_id is required")

        self._project_id = project_id
        self._http = HttpClient(
            base_url=base_url or DEFAULT_BASE_URL,
            api_key=api_key,
            timeout=timeout,
        )

    def _track(self, event: str, payload: dict[str, Any]) -> TrackResult:
        """Internal track method."""
        response = self._http.post(
            f"/v1/projects/{self._project_id}/track",
            data={"event": event, **payload},
        )
        return TrackResult(
            event_id=response["event_id"],
            workflows_triggered=response["workflows_triggered"],
        )

    def notify(self, context: UserContext) -> NotifyResult:
        """
        Send context to help optimize delivery.

        Examples:
            # User preferences
            fbf.notify({
                "user_id": "u_123",
                "timezone": "Asia/Kolkata",
                "preferred_channel": "whatsapp",
                "tier": "premium"
            })

            # Feedback after conversion
            fbf.notify({
                "user_id": "u_123",
                "converted": True,
                "revenue": 99.0
            })
        """
        self._http.post(
            f"/v1/projects/{self._project_id}/notify",
            data=dict(context),
        )
        return NotifyResult(success=True)

    def close(self) -> None:
        """Close the client and release resources."""
        self._http.close()

    def __enter__(self) -> "FourbyfourClient[V]":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


# =============================================================================
# VERTICAL-SPECIFIC CLIENTS
# =============================================================================

# Type aliases for event payloads
SaaSPayload = Union[
    SaaSTrialStarted, SaaSTrialEnding, SaaSSubscriptionCanceled,
    SaaSUsageThreshold, SaaSPaymentFailed, SaaSSubscriptionUpgraded,
    SaaSSubscriptionDowngraded, SaaSFeatureAdopted, SaaSNpsSubmitted,
    UserSignup, ReferralSent
]

EcommercePayload = Union[
    EcommerceCartAbandoned, EcommerceOrderPlaced, EcommerceOrderShipped,
    EcommerceOrderDelivered, EcommercePaymentFailed, EcommerceProductViewed,
    EcommerceWishlistAdded, EcommerceRefundRequested, EcommerceReviewSubmitted,
    UserSignup, ReferralSent
]

FintechPayload = Union[
    FintechTransactionFailed, FintechPaymentDue, FintechAccountDormant,
    FintechKycIncomplete, FintechPaymentFailed, FintechGoalCreated,
    FintechGoalAchieved, FintechSpendUnusual, UserSignup, ReferralSent
]

EdtechPayload = Union[
    EdtechCourseEnrolled, EdtechLessonCompleted, EdtechCourseAbandoned,
    EdtechCertificateEarned, EdtechPaymentFailed, EdtechStreakAchieved,
    EdtechStreakBroken, EdtechQuizPassed, UserSignup, ReferralSent
]

GamesPayload = Union[
    GamesPlayerInactive, GamesLevelCompleted, GamesCurrencyLow,
    GamesAchievementUnlocked, GamesPaymentFailed, GamesStreakBroken,
    GamesFriendInvited, GamesBossFailed, UserSignup, ReferralSent
]

AppsPayload = Union[
    AppsTrialStarted, AppsTrialEnding, AppsSubscriptionCanceled,
    AppsUserInactive, AppsFeatureUsed, AppsPaymentFailed,
    AppsReviewRequested, AppsMilestoneReached, AppsSubscriptionRenewed,
    UserSignup, ReferralSent
]


class SaaSClient(FourbyfourClient["saas"]):  # type: ignore[valid-type]
    """SaaS client with typed events."""

    def track(self, event: SaaSEventName, payload: SaaSPayload) -> TrackResult:
        """
        Track a SaaS event. Triggers matching workflows.

        Examples:
            fbf.track("payment.failed", {
                "user_id": "u_123",
                "amount": 99.0,
                "currency": "USD",
                "plan": "Pro",
                "subscription_id": "sub_456",
                "billing_cycle": "monthly"
            })

            fbf.track("trial.started", {
                "user_id": "u_123",
                "plan": "Pro",
                "trial_days": 14
            })
        """
        return self._track(event, dict(payload))


class EcommerceClient(FourbyfourClient["ecommerce"]):  # type: ignore[valid-type]
    """E-commerce client with typed events."""

    def track(self, event: EcommerceEventName, payload: EcommercePayload) -> TrackResult:
        """
        Track an e-commerce event. Triggers matching workflows.

        Examples:
            fbf.track("cart.abandoned", {
                "user_id": "u_123",
                "cart_id": "cart_789",
                "items": [{"id": "sku_1", "name": "Shoes", "price": 99.0, "quantity": 1}],
                "total": 99.0,
                "currency": "USD"
            })
        """
        return self._track(event, dict(payload))


class FintechClient(FourbyfourClient["fintech"]):  # type: ignore[valid-type]
    """Fintech client with typed events."""

    def track(self, event: FintechEventName, payload: FintechPayload) -> TrackResult:
        """Track a fintech event. Triggers matching workflows."""
        return self._track(event, dict(payload))


class EdtechClient(FourbyfourClient["edtech"]):  # type: ignore[valid-type]
    """EdTech client with typed events."""

    def track(self, event: EdtechEventName, payload: EdtechPayload) -> TrackResult:
        """Track an EdTech event. Triggers matching workflows."""
        return self._track(event, dict(payload))


class GamesClient(FourbyfourClient["games"]):  # type: ignore[valid-type]
    """Games client with typed events."""

    def track(self, event: GamesEventName, payload: GamesPayload) -> TrackResult:
        """Track a games event. Triggers matching workflows."""
        return self._track(event, dict(payload))


class AppsClient(FourbyfourClient["apps"]):  # type: ignore[valid-type]
    """Apps client with typed events."""

    def track(self, event: AppsEventName, payload: AppsPayload) -> TrackResult:
        """Track an apps event. Triggers matching workflows."""
        return self._track(event, dict(payload))


# =============================================================================
# FACTORY FUNCTIONS
# =============================================================================

def saas(
    api_key: str,
    project_id: str,
    *,
    base_url: Optional[str] = None,
    timeout: float = 30.0,
) -> SaaSClient:
    """
    Create a SaaS client.

    Example:
        from fourbyfour import saas

        fbf = saas(api_key="sk_...", project_id="proj_...")

        fbf.track("payment.failed", {
            "user_id": "u_123",
            "amount": 99.0,
            "currency": "USD",
            "plan": "Pro",
            "subscription_id": "sub_456",
            "billing_cycle": "monthly"
        })
    """
    return SaaSClient(api_key, project_id, base_url=base_url, timeout=timeout)


def ecommerce(
    api_key: str,
    project_id: str,
    *,
    base_url: Optional[str] = None,
    timeout: float = 30.0,
) -> EcommerceClient:
    """
    Create an E-commerce client.

    Example:
        from fourbyfour import ecommerce

        fbf = ecommerce(api_key="sk_...", project_id="proj_...")

        fbf.track("cart.abandoned", {
            "user_id": "u_123",
            "cart_id": "cart_789",
            "items": [{"id": "sku_1", "name": "Shoes", "price": 99.0, "quantity": 1}],
            "total": 99.0,
            "currency": "USD"
        })
    """
    return EcommerceClient(api_key, project_id, base_url=base_url, timeout=timeout)


def fintech(
    api_key: str,
    project_id: str,
    *,
    base_url: Optional[str] = None,
    timeout: float = 30.0,
) -> FintechClient:
    """Create a Fintech client."""
    return FintechClient(api_key, project_id, base_url=base_url, timeout=timeout)


def edtech(
    api_key: str,
    project_id: str,
    *,
    base_url: Optional[str] = None,
    timeout: float = 30.0,
) -> EdtechClient:
    """Create an EdTech client."""
    return EdtechClient(api_key, project_id, base_url=base_url, timeout=timeout)


def games(
    api_key: str,
    project_id: str,
    *,
    base_url: Optional[str] = None,
    timeout: float = 30.0,
) -> GamesClient:
    """Create a Games client."""
    return GamesClient(api_key, project_id, base_url=base_url, timeout=timeout)


def apps(
    api_key: str,
    project_id: str,
    *,
    base_url: Optional[str] = None,
    timeout: float = 30.0,
) -> AppsClient:
    """Create an Apps client."""
    return AppsClient(api_key, project_id, base_url=base_url, timeout=timeout)


