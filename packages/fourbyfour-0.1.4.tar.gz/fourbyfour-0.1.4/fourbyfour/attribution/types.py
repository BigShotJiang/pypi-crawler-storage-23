from dataclasses import dataclass
from decimal import Decimal
from enum import Enum
from typing import Any, Optional


class ConversionType(str, Enum):
    PAYMENT_SUCCEEDED = "payment_succeeded"
    CHECKOUT_COMPLETED = "checkout_completed"
    SUBSCRIPTION_RENEWED = "subscription_renewed"
    TRIAL_CONVERTED = "trial_converted"
    UPGRADE_COMPLETED = "upgrade_completed"
    CUSTOM = "custom"


class AttributionSource(str, Enum):
    EMAIL = "email"
    SMS = "sms"
    PUSH = "push"
    WEBHOOK = "webhook"
    WORKFLOW = "workflow"
    DIRECT = "direct"


@dataclass
class TrackConversionResponse:
    conversion_id: str
    attribution_source: AttributionSource
    created_at: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TrackConversionResponse":
        return cls(
            conversion_id=data["conversion_id"],
            attribution_source=AttributionSource(data["attribution_source"]),
            created_at=data["created_at"],
        )


@dataclass
class Conversion:
    conversion_id: str
    tenant_id: str
    project_id: str
    user_id: str
    conversion_type: ConversionType
    revenue_amount: Decimal
    currency: str
    attribution_source: AttributionSource
    created_at: str
    event_id: Optional[str] = None
    notification_id: Optional[str] = None
    workflow_id: Optional[str] = None
    metadata: Optional[dict[str, Any]] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Conversion":
        return cls(
            conversion_id=data["conversion_id"],
            tenant_id=data["tenant_id"],
            project_id=data["project_id"],
            user_id=data["user_id"],
            conversion_type=ConversionType(data["conversion_type"]),
            revenue_amount=Decimal(str(data["revenue_amount"])),
            currency=data["currency"],
            attribution_source=AttributionSource(data["attribution_source"]),
            created_at=data["created_at"],
            event_id=data.get("event_id"),
            notification_id=data.get("notification_id"),
            workflow_id=data.get("workflow_id"),
            metadata=data.get("metadata"),
        )


@dataclass
class SourceRevenue:
    source: AttributionSource
    revenue: Decimal
    count: int
    percentage: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SourceRevenue":
        return cls(
            source=AttributionSource(data["source"]),
            revenue=Decimal(str(data["revenue"])),
            count=data["count"],
            percentage=data["percentage"],
        )


@dataclass
class TypeRevenue:
    conversion_type: ConversionType
    revenue: Decimal
    count: int
    percentage: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TypeRevenue":
        return cls(
            conversion_type=ConversionType(data["conversion_type"]),
            revenue=Decimal(str(data["revenue"])),
            count=data["count"],
            percentage=data["percentage"],
        )


@dataclass
class DailyRevenue:
    date: str
    revenue: Decimal
    count: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "DailyRevenue":
        return cls(
            date=data["date"],
            revenue=Decimal(str(data["revenue"])),
            count=data["count"],
        )


@dataclass
class RevenueReport:
    project_id: str
    start_date: str
    end_date: str
    total_revenue: Decimal
    currency: str
    conversion_count: int
    by_source: list[SourceRevenue]
    by_type: list[TypeRevenue]
    by_day: list[DailyRevenue]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RevenueReport":
        return cls(
            project_id=data["project_id"],
            start_date=data["start_date"],
            end_date=data["end_date"],
            total_revenue=Decimal(str(data["total_revenue"])),
            currency=data["currency"],
            conversion_count=data["conversion_count"],
            by_source=[SourceRevenue.from_dict(s) for s in data["by_source"]],
            by_type=[TypeRevenue.from_dict(t) for t in data["by_type"]],
            by_day=[DailyRevenue.from_dict(d) for d in data["by_day"]],
        )


@dataclass
class FunnelStats:
    workflow_id: str
    workflow_name: str
    trigger_count: int
    notification_sent_count: int
    conversion_count: int
    total_revenue: Decimal
    currency: str
    conversion_rate: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FunnelStats":
        return cls(
            workflow_id=data["workflow_id"],
            workflow_name=data["workflow_name"],
            trigger_count=data["trigger_count"],
            notification_sent_count=data["notification_sent_count"],
            conversion_count=data["conversion_count"],
            total_revenue=Decimal(str(data["total_revenue"])),
            currency=data["currency"],
            conversion_rate=data["conversion_rate"],
        )


@dataclass
class PaginatedConversions:
    data: list[Conversion]
    total: int
    limit: int
    offset: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PaginatedConversions":
        return cls(
            data=[Conversion.from_dict(c) for c in data["data"]],
            total=data["total"],
            limit=data["limit"],
            offset=data["offset"],
        )
