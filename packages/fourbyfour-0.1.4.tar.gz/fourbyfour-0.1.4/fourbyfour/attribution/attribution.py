from decimal import Decimal
from typing import Any, Optional, Union
from urllib.parse import urlencode

from ..http import HttpClient
from .types import (
    AttributionSource,
    Conversion,
    ConversionType,
    FunnelStats,
    PaginatedConversions,
    RevenueReport,
    TrackConversionResponse,
)


class Attribution:
    """Client for revenue attribution operations."""

    def __init__(self, http: HttpClient, project_id: str):
        self._http = http
        self._project_id = project_id

    @property
    def _base_path(self) -> str:
        return f"/projects/{self._project_id}"

    def track(
        self,
        user_id: str,
        conversion_type: ConversionType,
        revenue_amount: Union[Decimal, float],
        *,
        currency: str = "USD",
        event_id: Optional[str] = None,
        notification_id: Optional[str] = None,
        workflow_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> TrackConversionResponse:
        """Track a conversion event with revenue attribution."""
        data: dict[str, Any] = {
            "user_id": user_id,
            "conversion_type": conversion_type.value,
            "revenue_amount": float(revenue_amount),
            "currency": currency,
        }
        if event_id is not None:
            data["event_id"] = event_id
        if notification_id is not None:
            data["notification_id"] = notification_id
        if workflow_id is not None:
            data["workflow_id"] = workflow_id
        if metadata is not None:
            data["metadata"] = metadata

        response = self._http.post(f"{self._base_path}/attribution/track", data)
        return TrackConversionResponse.from_dict(response["conversion"])

    def get_report(
        self,
        *,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        currency: Optional[str] = None,
    ) -> RevenueReport:
        """Get revenue report with breakdowns by source, type, and day."""
        params = {}
        if start_date is not None:
            params["start_date"] = start_date
        if end_date is not None:
            params["end_date"] = end_date
        if currency is not None:
            params["currency"] = currency

        url = f"{self._base_path}/attribution/report"
        if params:
            url = f"{url}?{urlencode(params)}"

        response = self._http.get(url)
        return RevenueReport.from_dict(response["report"])

    def get_funnel_stats(
        self,
        workflow_id: Optional[str] = None,
    ) -> list[FunnelStats]:
        """Get funnel statistics for workflows showing conversion rates."""
        url = f"{self._base_path}/attribution/funnel"
        if workflow_id is not None:
            url = f"{url}?workflow_id={workflow_id}"

        response = self._http.get(url)
        return [FunnelStats.from_dict(f) for f in response["funnels"]]

    def list(
        self,
        *,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        user_id: Optional[str] = None,
        conversion_type: Optional[ConversionType] = None,
        source: Optional[AttributionSource] = None,
    ) -> PaginatedConversions:
        """List conversions with pagination and filtering."""
        params = {}
        if limit is not None:
            params["limit"] = str(limit)
        if offset is not None:
            params["offset"] = str(offset)
        if user_id is not None:
            params["user_id"] = user_id
        if conversion_type is not None:
            params["conversion_type"] = conversion_type.value
        if source is not None:
            params["source"] = source.value

        url = f"{self._base_path}/conversions"
        if params:
            url = f"{url}?{urlencode(params)}"

        response = self._http.get(url)
        return PaginatedConversions.from_dict(response)

    def get(self, conversion_id: str) -> Conversion:
        """Get a single conversion by ID."""
        response = self._http.get(f"{self._base_path}/conversions/{conversion_id}")
        return Conversion.from_dict(response["conversion"])
