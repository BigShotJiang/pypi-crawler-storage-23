from ..http import HttpClient
from .topics import Topics
from .types import ConsumeResponse, ProduceResponse, Record, Topic, TopicStats


class Stream:
    """Stream service client."""

    def __init__(self, http: HttpClient, project_id: str):
        self.topics = Topics(http, project_id)


__all__ = [
    "Stream",
    "Topics",
    "Topic",
    "ProduceResponse",
    "Record",
    "ConsumeResponse",
    "TopicStats",
]
