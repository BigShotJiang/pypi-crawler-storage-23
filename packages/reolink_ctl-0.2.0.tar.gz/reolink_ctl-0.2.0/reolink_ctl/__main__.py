"""Allow running as `python -m reolink_ctl`."""

from reolink_ctl.cli import main

main()
