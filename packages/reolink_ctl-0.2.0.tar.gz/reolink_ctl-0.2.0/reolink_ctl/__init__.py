"""reolink-ctl: CLI for Reolink camera control."""

__version__ = "0.2.0"
