"""Test suite for FastAPI MongoDB base package."""
