"""FastAPI MongoDB base package with models, schemas, and routers."""

from .core import exceptions

__all__ = ["exceptions"]
