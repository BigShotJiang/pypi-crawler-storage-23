"""Utility functions and helpers for fastapi-mongo-base."""
