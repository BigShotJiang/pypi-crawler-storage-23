from flask import request, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from . import auth_bp
from .services import (
    create_user,
    authenticate_user,
    request_password_reset,
    reset_password,
    update_user,
)


# =========================
# REGISTER
# =========================

@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json()

    if not data:
        return jsonify({"error": "Invalid JSON body"}), 400

    user, error = create_user(
        username=data.get("username"),
        password=data.get("password"),
    )

    if error:
        return jsonify({"error": error}), 400

    return jsonify({"message": "User created"}), 201


# =========================
# LOGIN
# =========================

@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json()

    if not data:
        return jsonify({"error": "Invalid JSON body"}), 400

    user = authenticate_user(
        username=data.get("username"),
        password=data.get("password"),
    )

    if not user:
        return jsonify({"error": "Invalid credentials"}), 401

    login_user(user)
    return jsonify({"message": "Logged in"}), 200


# =========================
# LOGOUT
# =========================

@auth_bp.route("/logout", methods=["POST"])
@login_required
def logout():
    logout_user()
    return jsonify({"message": "Logged out"}), 200


# =========================
# REQUEST PASSWORD RESET
# =========================

@auth_bp.route("/password-reset/request", methods=["POST"])
def password_reset_request():
    data = request.get_json()

    if not data or not data.get("username"):
        return jsonify({"error": "Username is required"}), 400

    token = request_password_reset(data.get("username"))

    # Pour éviter l'énumération d'utilisateurs,
    # on renvoie toujours le même message
    if token:
        return jsonify({
            "message": "Password reset token generated",
            "reset_token": token  # ⚠️ À retirer en production si email utilisé
        }), 200

    return jsonify({
        "message": "If the account exists, a reset token has been generated"
    }), 200


# =========================
# RESET PASSWORD
# =========================

@auth_bp.route("/password-reset/confirm", methods=["POST"])
def password_reset_confirm():
    data = request.get_json()

    if not data:
        return jsonify({"error": "Invalid request"}), 400

    success = reset_password(
        token=data.get("token"),
        new_password=data.get("new_password"),
    )

    if not success:
        return jsonify({"error": "Invalid or expired token"}), 400

    return jsonify({"message": "Password updated successfully"}), 200


# =========================
# UPDATE ACCOUNT (LOGGED USER)
# =========================

@auth_bp.route("/account/update", methods=["PUT"])
@login_required
def account_update():
    data = request.get_json()

    if not data:
        return jsonify({"error": "Invalid request"}), 400

    success, error = update_user(
        user=current_user,
        new_username=data.get("username"),
        new_password=data.get("password"),
    )

    if not success:
        return jsonify({"error": error}), 400

    return jsonify({"message": "Account updated successfully"}), 200
