"""MigratorXpress MCP Server - A Model Context Protocol server for MigratorXpress CLI tool."""

__version__ = "0.1.0"
