"""Serial helpers for NEnG SCPI instruments."""

from .scpi_serial import SCPISerial

__all__ = ["SCPISerial"]
