# neng-scpi-tools

Shared SCPI serial/WiFi communication tools and GUI widgets for NEnG instruments.

## Overview

This package provides the **common building blocks** used by all NEnG subproject
GUIs (temp-logger, bts7960-gui, etc.):

| Module | Description |
| ------ | ----------- |
| `neng_scpi_tools.myserial.scpi_serial` | USB CDC serial SCPI interface with auto-detect, locking, and cross-platform support |
| `neng_scpi_tools.myserial.scpi_universal` | Unified Serial + WiFi/TCP SCPI interface with automatic fallback |
| `neng_scpi_tools.connection_panel` | Reusable tkinter ConnectionPanel widget (USB/WiFi mode selector, discovery, connect/disconnect) |

## Installation

### For development (editable, from monorepo root)

```bash
pip install -e neng-scpi-tools/
```

### As a dependency of a subproject

```bash
# Install the shared tools + the subproject together
pip install -e neng-scpi-tools/
pip install -e TMP117/Python/temp-logger/
```

## Usage

```python
from neng_scpi_tools.connection_panel import ConnectionPanel
from neng_scpi_tools.myserial.scpi_serial import SCPISerial
from neng_scpi_tools.myserial.scpi_universal import SCPIUniversal
```

## Architecture

This package is the **single source of truth** for code that is shared across
multiple NEnG subprojects. Instead of copying files between subprojects (which
leads to drift and divergence), each subproject declares `neng-scpi-tools` as a
dependency and imports from it.

```txt
neng-controllers-platform/
├── neng-scpi-tools/          ← THIS PACKAGE (shared)
│   └── src/neng_scpi_tools/
│       ├── connection_panel.py
│       └── myserial/
│           ├── scpi_serial.py
│           └── scpi_universal.py
├── TMP117/Python/temp-logger/     ← depends on neng-scpi-tools
├── BTS7960/Python/bts7960-gui/    ← depends on neng-scpi-tools
└── ...
```

(c) 2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
