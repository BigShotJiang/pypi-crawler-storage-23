# References

1. [PDDL Resources](http://icaps-conference.org/ipc2008/deterministic/PddlResources.html), ICAPS Conference
2. Bryce, Daniel, and Olivier Buffet. "6th international planning competition: Uncertainty part." Proceedings of the 6th International Planning Competition (IPC’08) (2008).
