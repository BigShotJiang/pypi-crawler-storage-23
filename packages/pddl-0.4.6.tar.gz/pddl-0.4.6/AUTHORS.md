# Credits

## Maintainers

* [Marco Favorito](https://github.com/marcofavorito) <[marco.favorito@gmail.com](mailto:marco.favorito@gmail.com)>
* [Francesco Fuggitti](https://github.com/francescofuggitti) <[fuggitti@diag.uniroma1.it](mailto:fuggitti@diag.uniroma1.it)>

## Contributors

* [Christian Muise](http://www.haz.ca) <[christian.muise@gmail.com](mailto:christian.muise@gmail.com)>
