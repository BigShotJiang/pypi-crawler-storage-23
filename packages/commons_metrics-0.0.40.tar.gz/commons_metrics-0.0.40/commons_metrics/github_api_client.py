import requests
import base64
import time
from threading import Lock
from typing import List, Dict, Optional, Callable
import os
from .commons_repos_client import CommonsReposClient

class GitHubAPIClient:
    """
    Cliente para interactuar con la API de GitHub con rate limiting integrado.
    Controla automáticamente el TPS para no exceder los límites de GitHub:
    - GitHub App: 15000 req/hora (~4.17 TPS)
    - Personal Token: 5000 req/hora (~1.4 TPS)

    Incluye:
    - Rate limiting adaptativo (ajusta delays según uso)
    - Exponential backoff para errores 403/429
    - Optimización de requests en últimos 10 minutos antes de reset
    """

    # Variables de rate limiting compartidas entre instancias
    _base_delay = 0.24
    _current_delay = 0.24
    _last_request_time = 0
    _lock = Lock()
    _last_rate_check = 0
    _rate_check_interval = 10
    _request_count = 0
    _remaining_requests = None
    _limit = None
    _reset_time = None

    # Rate limit específico para Search API: 30 req/min = 1 req cada 2s
    _search_delay = 2.0
    _last_search_time = 0

    def __init__(self, token: str, owner: str = None, repo: str = None, enable_rate_limit: bool = True,
                 token_provider: Callable[[], str] = None):
        """
        Inicializa el cliente de GitHub API

        Args:
            token: Personal Access Token de GitHub
            owner: Dueño del repositorio (ej: 'grupobancolombia-innersource') - Opcional
            repo: Nombre del repositorio (ej: 'NU0066001_BDS_MOBILE_Lib') - Opcional
            enable_rate_limit: Si True, aplica rate limiting automático (por defecto True)
            token_provider: Función que retorna un token nuevo (para renovar tokens expirados de GitHub App)
        """
        self.token = token
        self.owner = owner
        self.repo = repo
        self.enable_rate_limit = enable_rate_limit
        self.token_provider = token_provider
        self.base_url = f"https://api.github.com/repos/{owner}/{repo}" if owner and repo else "https://api.github.com"
        self.headers = {
            "Authorization": f"token {token}",
            "Accept": "application/vnd.github.v3+json"
        }

        # Guardar token para rate limit
        self._token = token

    def refresh_token(self):
        """
        Renueva el token usando el token_provider.
        Útil cuando el token de GitHub App expira (después de 1 hora).

        Returns:
            True si se renovó el token, False si no hay token_provider
        """
        if not self.token_provider:
            return False

        try:
            new_token = self.token_provider()
            self.token = new_token
            self._token = new_token
            self.headers["Authorization"] = f"token {new_token}"
            print("🔄 Token de GitHub renovado exitosamente")
            return True
        except Exception as e:
            print(f"⚠️ Error renovando token de GitHub: {e}")
            return False

    def _check_rate_limit(self):
        """Obtiene el estado actual del rate limit desde GitHub y actualiza variables globales"""
        if not self._token:
            return None, None, None

        try:
            response = requests.get(
                "https://api.github.com/rate_limit",
                headers=self.headers
            )
            if response.status_code == 200:
                data = response.json()
                GitHubAPIClient._remaining_requests = data['rate']['remaining']
                GitHubAPIClient._limit = data['rate']['limit']
                GitHubAPIClient._reset_time = data['rate']['reset']
                return GitHubAPIClient._remaining_requests, GitHubAPIClient._limit, GitHubAPIClient._reset_time
        except Exception as e:
            print(f"Warning: No se pudo verificar rate limit: {e}")

        return None, None, None

    def _adjust_delay(self):
        """
        Ajusta el delay dinámicamente basado en el rate limit actual:
        - >90% usado y falta >10min: aumentar delay
        - <10min para reset: reducir delay a 10ms
        """
        remaining, limit, reset_time = self._check_rate_limit()

        if remaining is None or limit is None or reset_time is None:
            return

        usage_percent = ((limit - remaining) / limit) * 100
        time_to_reset = reset_time - time.time()
        minutes_to_reset = time_to_reset / 60

        # Estrategia 1: Cerca del límite (>90%) y falta >10min
        if usage_percent > 90 and minutes_to_reset > 10:
            # Aumentar delay progresivamente
            GitHubAPIClient._current_delay = GitHubAPIClient._base_delay * 2
            print(f"⚠️ Rate limit alto ({usage_percent:.1f}%). Aumentando delay a {GitHubAPIClient._current_delay:.2f}s")

        # Estrategia 2: Faltan <10min para reset
        elif minutes_to_reset < 10:
            # Reducir delay para aprovechar requests restantes
            GitHubAPIClient._current_delay = 0.01  # 10ms
            print(f"🚀 Quedan {minutes_to_reset:.1f}min para reset. Acelerando a {GitHubAPIClient._current_delay*1000:.0f}ms")

        # Normal: restaurar delay base
        else:
            GitHubAPIClient._current_delay = GitHubAPIClient._base_delay

    def _wait(self):
        """Espera el tiempo necesario antes de hacer el siguiente request"""
        with GitHubAPIClient._lock:
            # Verificar y ajustar delay cada N requests
            GitHubAPIClient._request_count += 1
            if GitHubAPIClient._request_count % GitHubAPIClient._rate_check_interval == 0:
                self._adjust_delay()

            current_time = time.time()
            time_since_last_request = current_time - GitHubAPIClient._last_request_time

            if time_since_last_request < GitHubAPIClient._current_delay:
                sleep_time = GitHubAPIClient._current_delay - time_since_last_request
                time.sleep(sleep_time)

            GitHubAPIClient._last_request_time = time.time()

    def _wait_for_search(self):
        """Espera el tiempo necesario entre llamadas al Search API (30 req/min)"""
        with GitHubAPIClient._lock:
            current_time = time.time()
            time_since_last_search = current_time - GitHubAPIClient._last_search_time

            if time_since_last_search < GitHubAPIClient._search_delay:
                sleep_time = GitHubAPIClient._search_delay - time_since_last_search
                time.sleep(sleep_time)

            GitHubAPIClient._last_search_time = time.time()

    def _request_with_backoff(self, method: str, url: str, max_retries: int = 5, **kwargs):
        """
        Hace un request con exponential backoff SOLO para errores de rate limit (403/429)

        Estrategia:
        - Si hay X-RateLimit-Reset header, espera hasta ese momento
        - Si no, usa exponential backoff: 2^attempt segundos (1s, 2s, 4s, 8s, 16s)
        - Máximo 5 reintentos

        Args:
            method: Método HTTP ('get', 'post', etc)
            url: URL del endpoint
            max_retries: Número máximo de reintentos (default: 5)
            **kwargs: Argumentos adicionales para requests

        Returns:
            Response object

        Raises:
            Exception: Si no es error de rate limit o se agotan los reintentos
        """
        request_func = getattr(requests, method.lower())

        for attempt in range(max_retries):
            if self.enable_rate_limit:
                self._wait()

            response = request_func(url, **kwargs)

            # Verificar si es específicamente un error de rate limit
            if response.status_code in [403, 429]:
                # Verificar que sea rate limit y no otro error 403
                if 'rate limit' in response.text.lower() or response.status_code == 429:
                    if attempt < max_retries - 1:
                        # Usar el reset_time global
                        reset_time = GitHubAPIClient._reset_time

                        if reset_time:
                            # Esperar hasta el reset (con 5 segundos extra de margen)
                            wait_time = reset_time - time.time() + 5
                            if wait_time > 0:
                                wait_minutes = wait_time / 60
                                print(f"⚠️ Rate limit alcanzado. Esperando {wait_minutes:.1f} minutos hasta reset...")
                                time.sleep(wait_time)
                                # Verificar rate limit actualizado después de esperar
                                self._check_rate_limit()
                            continue
                        else:
                            # Si no hay reset_time global, usar exponential backoff
                            # 1s, 2s, 4s, 8s, 16s (máx 60s)
                            wait_time = min(2 ** attempt, 60)
                            print(f"⚠️ Rate limit alcanzado. Esperando {wait_time}s (intento {attempt + 1}/{max_retries})...")
                            time.sleep(wait_time)
                            continue
                    else:
                        raise Exception(f"Rate limit excedido después de {max_retries} intentos")
                else:
                    # Es un 403 pero NO de rate limit - no reintentar
                    raise Exception(f"Error 403 (no rate limit): {response.text}")

            # Si es exitoso o cualquier otro error, retornar
            return response

        return response

    def get_directory_contents(self, path: str = "") -> List[Dict]:
        """
        Obtiene el contenido de un directorio en el repositorio

        Args:
            path: Ruta del directorio (ej: 'lib/atoms')

        Returns:
            Lista de diccionarios con información de archivos/carpetas
        """
        url = f"{self.base_url}/contents/{path}"
        response = self._request_with_backoff('get', url, headers=self.headers)

        if response.status_code == 200:
            return response.json()
        elif response.status_code == 404:
            return []
        else:
            raise Exception(f"Error getting directory contents: {response.status_code} - {response.text}")

    def get_file_content(self, path: str) -> Optional[str]:
        """
        Obtiene el contenido de un archivo

        Args:
            path: Ruta del archivo en el repositorio

        Returns:
            Contenido del archivo como string, o None si no existe
        """
        url = f"{self.base_url}/contents/{path}"
        response = self._request_with_backoff('get', url, headers=self.headers)

        if response.status_code == 200:
            content = response.json()
            if content.get('encoding') == 'base64':
                decoded_content = base64.b64decode(content['content']).decode('utf-8')
                return decoded_content
            return None
        elif response.status_code == 404:
            return None
        else:
            raise Exception(f"Error getting file content: {response.status_code} - {response.text}")

    def list_folders_in_directory(self, path: str) -> List[str]:
        """
        Lista solo las carpetas dentro de un directorio

        Args:
            path: Ruta del directorio

        Returns:
            Lista de nombres de carpetas
        """
        contents = self.get_directory_contents(path)
        folders = [
            item['name']
            for item in contents
            if item['type'] == 'dir'
        ]
        return folders

    def walk_directory(self, path: str = "", extension: str = None, exclude_patterns: List[str] = None) -> List[Dict]:
        """
        Recorre recursivamente un directorio y retorna todos los archivos

        Args:
            path: Ruta del directorio inicial
            extension: Extensión a filtrar (ej: '.ts', '.dart')
            exclude_patterns: Lista de patrones a excluir (ej: ['.spec.', '.test.', '.d.ts'])

        Returns:
            Lista de diccionarios con información de archivos encontrados
        """
        all_files = []
        exclude_patterns = exclude_patterns or []

        def should_exclude(filename: str) -> bool:
            return any(pattern in filename for pattern in exclude_patterns)

        def recurse_directory(current_path: str):
            contents = self.get_directory_contents(current_path)

            for item in contents:
                item_path = f"{current_path}/{item['name']}" if current_path else item['name']

                if item['type'] == 'file':
                    # Aplicar filtros de extensión y exclusión
                    if extension and not item['name'].endswith(extension):
                        continue
                    if should_exclude(item['name']):
                        continue

                    all_files.append({
                        'name': item['name'],
                        'path': item_path,
                        'url': item.get('url', ''),
                        'download_url': item.get('download_url', '')
                    })

                elif item['type'] == 'dir':
                    # Excluir directorios comunes que no contienen componentes
                    if item['name'] not in ['node_modules', 'dist', 'build', '.git', 'test', 'tests', '__pycache__']:
                        recurse_directory(item_path)

        recurse_directory(path)
        return all_files

    def search_code(self, query: str, per_page: int = 100) -> List[Dict]:
        """
        Busca código en GitHub usando la API de búsqueda.
        
        NOTA: La API de GitHub Search no garantiza un orden estable entre páginas
        cuando no se usa sort/order (y usarlos causa errores con ciertos tokens).
        Por eso, los resultados se deduplicán por una clave única (repo_id + path)
        para eliminar duplicados causados por el "deslizamiento" de páginas.

        Args:
            query: Query de búsqueda (ej: '"bds_mobile" in:file filename:pubspec.yaml')
            per_page: Número de resultados por página (máximo 100)

        Returns:
            Lista de diccionarios con información de archivos encontrados (sin duplicados)
        """
        all_results = []
        seen_keys = set()  # Deduplicación por repo_id + file_path
        page = 1
        max_page_retries = 3  # Reintentos por página ante errores

        while True:
            url = "https://api.github.com/search/code"
            params = {
                'q': query,
                'per_page': per_page,
                'page': page
            }

            # Respetar el rate limit de Search API (30 req/min)
            self._wait_for_search()
            response = self._request_with_backoff('get', url, headers=self.headers, params=params)

            if response.status_code == 200:
                data = response.json()
                total_count = data.get('total_count', 0)
                items = data.get('items', [])

                if not items:
                    break

                for item in items:
                    # Clave única: repo_id + path del archivo
                    repo_id = item.get('repository', {}).get('id', '')
                    file_path = item.get('path', '')
                    unique_key = f"{repo_id}:{file_path}"

                    if unique_key not in seen_keys:
                        seen_keys.add(unique_key)
                        all_results.append(item)

                # Advertir si se alcanza el límite de 1000 resultados de GitHub
                if len(seen_keys) >= 1000:
                    print(f"⚠️ AVISO: Se alcanzó el límite de 1000 resultados de GitHub Search para la query. "
                          f"Total reportado por GitHub: {total_count}. Datos posiblemente incompletos.")
                    break

                # Si hay menos items que per_page, es la última página
                if len(items) < per_page:
                    break

                page += 1
            else:
                # Si es 401, intentar renovar el token antes de reintentar
                if response.status_code == 401 and self.refresh_token():
                    print("🔄 Token renovado, reintentando búsqueda...")
                    self._wait_for_search()
                    response = self._request_with_backoff('get', url, headers=self.headers, params=params)
                    if response.status_code == 200:
                        data = response.json()
                        items = data.get('items', [])
                        if items:
                            for item in items:
                                repo_id = item.get('repository', {}).get('id', '')
                                file_path = item.get('path', '')
                                unique_key = f"{repo_id}:{file_path}"
                                if unique_key not in seen_keys:
                                    seen_keys.add(unique_key)
                                    all_results.append(item)
                            if len(items) >= per_page:
                                page += 1
                        continue

                # Reintentar la página con espera progresiva
                retry_success = False
                for retry in range(max_page_retries):
                    wait = GitHubAPIClient._search_delay * (retry + 2)
                    print(f"⚠️ Error {response.status_code} en página {page}. "
                          f"Reintentando en {wait:.0f}s ({retry + 1}/{max_page_retries})...")
                    time.sleep(wait)
                    self._wait_for_search()
                    response = self._request_with_backoff('get', url, headers=self.headers, params=params)
                    if response.status_code == 200:
                        retry_success = True
                        data = response.json()
                        items = data.get('items', [])
                        if items:
                            for item in items:
                                repo_id = item.get('repository', {}).get('id', '')
                                file_path = item.get('path', '')
                                unique_key = f"{repo_id}:{file_path}"
                                if unique_key not in seen_keys:
                                    seen_keys.add(unique_key)
                                    all_results.append(item)
                            if len(items) >= per_page:
                                page += 1
                        break

                if not retry_success:
                    if all_results:
                        print(f"⚠️ AVISO: Error persistente {response.status_code} en página {page}. "
                              f"Retornando {len(all_results)} resultados obtenidos.")
                    else:
                        raise Exception(f"Error searching code: {response.status_code} - {response.text}")
                    break

        return all_results

    def search_projects_with_bds(self, platform: str, design_system_name: str = None) -> List[Dict]:
        """
        Busca proyectos que usan el sistema de diseño BDS (mobile o web)

        Args:
            platform: 'mobile' o 'web'
            design_system_name: Nombre del paquete del sistema de diseño
                            Si no se proporciona, usa valores por defecto:
                            - mobile: "bds_mobile"
                            - web: "@bancolombia/design-system-web"

        Returns:
            Lista de proyectos con información del repositorio incluyendo la versión

        Raises:
            ValueError: Si platform no es 'mobile' o 'web'
        """
        # Validar plataforma
        if platform not in ['mobile', 'web']:
            raise ValueError(f"Platform debe ser 'mobile' o 'web', se recibió: {platform}")

        # Configurar valores según la plataforma
        if platform == 'mobile':
            config_file = 'pubspec.yaml'
            default_package_name = 'bds_mobile'
            extract_version_method = CommonsReposClient.extract_package_version_from_pubspec
        else:  # web
            config_file = 'package.json'
            default_package_name = '@bancolombia/design-system-web'
            extract_version_method = CommonsReposClient.extract_package_version_from_package_json

        # Usar nombre de paquete por defecto si no se proporciona
        package_name = design_system_name or default_package_name

        # Agregar filtro de organización si self.owner está definido
        org_filter = f" org:{self.owner}" if self.owner else ""
        query = f'"{package_name}" in:file filename:{config_file}{org_filter}'
        results = self.search_code(query)

        projects = []
        for item in results:
            # Obtener contenido del archivo de configuración para extraer la versión
            file_content = self._get_file_content_from_url(item['url'])
            version = extract_version_method(file_content, package_name)

            project_info = {
                'name': item['repository']['name'],
                'full_name': item['repository']['full_name'],
                'owner': item['repository']['owner']['login'],
                'repo_url': item['repository']['html_url'],
                'file_path': item['path'],
                'bds_version': version
            }
            projects.append(project_info)

        return projects

    def search_repositories(self, query: str, per_page: int = 100) -> List[Dict]:
        """
        Busca repositorios en GitHub usando la API de búsqueda.
        Resultados deduplicados por repo ID para evitar inconsistencias por paginación.

        Args:
            query: Query de búsqueda (ej: 'NU0296001 mobile in:name org:grupobancolombia-innersource')
            per_page: Número de resultados por página (máximo 100)

        Returns:
            Lista de diccionarios con información de repositorios encontrados (sin duplicados)
        """
        all_results = []
        seen_ids = set()
        page = 1
        max_page_retries = 3
        search_url = "https://api.github.com/search/repositories"

        while True:
            params = {
                'q': query,
                'per_page': per_page,
                'page': page
            }

            # Respetar el rate limit de Search API (30 req/min)
            self._wait_for_search()
            response = self._request_with_backoff('get', search_url, headers=self.headers, params=params)

            if response.status_code != 200:
                # Si es 401, intentar renovar el token antes de reintentar
                if response.status_code == 401 and self.refresh_token():
                    print("🔄 Token renovado, reintentando búsqueda de repositorios...")
                    self._wait_for_search()
                    response = self._request_with_backoff('get', search_url, headers=self.headers, params=params)
                    if response.status_code == 200:
                        data = response.json()
                        items = data.get('items', [])
                        if items:
                            for item in items:
                                repo_id = item.get('id', '')
                                if repo_id not in seen_ids:
                                    seen_ids.add(repo_id)
                                    all_results.append(item)
                            if len(items) >= per_page:
                                page += 1
                        continue

                # Reintentar la página
                retry_success = False
                for retry in range(max_page_retries):
                    wait = GitHubAPIClient._search_delay * (retry + 2)
                    print(f"⚠️ Error {response.status_code} en página {page}. "
                          f"Reintentando en {wait:.0f}s ({retry + 1}/{max_page_retries})...")
                    time.sleep(wait)
                    self._wait_for_search()
                    response = self._request_with_backoff('get', search_url, headers=self.headers, params=params)
                    if response.status_code == 200:
                        retry_success = True
                        break

                if not retry_success:
                    if all_results:
                        print(f"⚠️ AVISO: Error persistente {response.status_code} en página {page}. "
                              f"Retornando {len(all_results)} resultados obtenidos.")
                        break
                    else:
                        raise Exception(f"Error searching repositories: {response.status_code} - {response.text}")

            data = response.json()
            items = data.get('items', [])

            if not items:
                break

            for item in items:
                repo_id = item.get('id', '')
                if repo_id not in seen_ids:
                    seen_ids.add(repo_id)
                    all_results.append(item)

            # Verificar si hay más páginas
            if len(items) < per_page:
                break

            page += 1

        return all_results

    def _get_file_content_from_url(self, api_url: str) -> Optional[str]:
        """
        Obtiene el contenido de un archivo desde una URL de la API de GitHub

        Args:
            api_url: URL de la API de GitHub para el archivo

        Returns:
            Contenido del archivo como string, o None si no existe
        """
        response = self._request_with_backoff('get', api_url, headers=self.headers)

        if response.status_code == 200:
            content = response.json()
            if content.get('encoding') == 'base64':
                decoded_content = base64.b64decode(content['content']).decode('utf-8')
                return decoded_content
            return None
        return None