"""Slop-Mop: Quality gates for AI-assisted codebases."""

from importlib.metadata import version as _pkg_version

__version__ = _pkg_version("slopmop")
