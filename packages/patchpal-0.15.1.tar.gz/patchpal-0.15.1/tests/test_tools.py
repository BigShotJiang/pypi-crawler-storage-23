"""Tests for patchpal.tools module."""

import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture
def temp_repo(monkeypatch):
    """Create a temporary repository for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Resolve path to handle Windows short names (RUNNER~1) and macOS symlinks (/private)
        tmpdir_path = Path(tmpdir).resolve()

        # Create test files
        (tmpdir_path / "test.txt").write_text("Hello, World!")
        (tmpdir_path / "subdir").mkdir()
        (tmpdir_path / "subdir" / "file.py").write_text("print('test')")

        # Monkey-patch REPO_ROOT
        monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", tmpdir_path)

        # Disable permission prompts during tests
        monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "false")

        # Reset the cached permission manager so it picks up the new env var
        import patchpal.tools.common

        patchpal.tools.common._permission_manager = None

        # Reset operation counter before each test
        from patchpal.tools import reset_operation_counter

        reset_operation_counter()

        yield tmpdir_path


def test_read_file(temp_repo):
    """Test reading a file."""
    from patchpal.tools import read_file

    content = read_file("test.txt")
    assert content == "Hello, World!"


def test_read_file_in_subdir(temp_repo):
    """Test reading a file in a subdirectory."""
    from patchpal.tools import read_file

    content = read_file("subdir/file.py")
    assert content == "print('test')"


def test_read_file_not_found(temp_repo):
    """Test reading a non-existent file raises an error."""
    from patchpal.tools import read_file

    with pytest.raises(ValueError, match="File not found"):
        read_file("nonexistent.txt")


def test_read_lines_single_line(temp_repo):
    """Test reading a single line from a file."""
    from patchpal.tools import read_lines

    # Create a test file with multiple lines
    (temp_repo / "multiline.txt").write_text("Line 1\nLine 2\nLine 3\nLine 4\nLine 5")

    result = read_lines("multiline.txt", 3)
    assert "Line 3" in result
    assert "   3  Line 3" in result
    # Should not include other lines
    assert "Line 1" not in result
    assert "Line 2" not in result
    assert "Line 4" not in result


def test_read_lines_range(temp_repo):
    """Test reading a range of lines from a file."""
    from patchpal.tools import read_lines

    (temp_repo / "multiline.txt").write_text("Line 1\nLine 2\nLine 3\nLine 4\nLine 5")

    result = read_lines("multiline.txt", 2, 4)
    assert "Line 2" in result
    assert "Line 3" in result
    assert "Line 4" in result
    # Should not include lines outside range
    assert "Line 1" not in result
    assert "Line 5" not in result
    # Check line numbers
    assert "   2  Line 2" in result
    assert "   3  Line 3" in result
    assert "   4  Line 4" in result


def test_read_lines_entire_file(temp_repo):
    """Test reading all lines when range exceeds file length."""
    from patchpal.tools import read_lines

    (temp_repo / "small.txt").write_text("Line 1\nLine 2\nLine 3")

    result = read_lines("small.txt", 1, 100)
    assert "Line 1" in result
    assert "Line 2" in result
    assert "Line 3" in result
    # Should include note about truncation
    assert "file only has 3 lines" in result


def test_read_lines_invalid_range(temp_repo):
    """Test reading with invalid line numbers."""
    from patchpal.tools import read_lines

    (temp_repo / "test.txt").write_text("Line 1\nLine 2")

    # Start line less than 1
    with pytest.raises(ValueError, match="start_line must be >= 1"):
        read_lines("test.txt", 0)

    # End line less than start line
    with pytest.raises(ValueError, match="end_line.*must be >= start_line"):
        read_lines("test.txt", 5, 2)


def test_read_lines_beyond_file_end(temp_repo):
    """Test reading starting beyond file end."""
    from patchpal.tools import read_lines

    (temp_repo / "short.txt").write_text("Line 1\nLine 2")

    with pytest.raises(ValueError, match="exceeds file length"):
        read_lines("short.txt", 10)


def test_read_lines_file_not_found(temp_repo):
    """Test read_lines with non-existent file."""
    from patchpal.tools import read_lines

    with pytest.raises(ValueError, match="File not found"):
        read_lines("nonexistent.txt", 1, 5)


def test_read_lines_binary_file(temp_repo):
    """Test read_lines rejects binary files."""
    from patchpal.tools import read_lines

    # Create a binary file
    (temp_repo / "binary.bin").write_bytes(b"\x00\x01\x02\x03")

    with pytest.raises(ValueError, match="Cannot read binary file"):
        read_lines("binary.bin", 1, 5)


def test_read_file_json(temp_repo):
    """Test reading JSON files (application/json MIME type)."""
    from patchpal.tools import read_file

    # Create a JSON file
    json_content = '{"name": "test", "value": 123}'
    (temp_repo / "test.json").write_text(json_content)

    content = read_file("test.json")
    assert content == json_content


def test_read_file_xml(temp_repo):
    """Test reading XML files (application/xml MIME type)."""
    from patchpal.tools import read_file

    # Create an XML file
    xml_content = '<?xml version="1.0"?><root><item>test</item></root>'
    (temp_repo / "test.xml").write_text(xml_content)

    content = read_file("test.xml")
    assert content == xml_content


def test_read_file_pdf(temp_repo):
    """Test reading PDF files with text extraction."""
    from patchpal.tools import read_file

    # Create a minimal PDF with text
    try:
        import pymupdf

        doc = pymupdf.open()
        page = doc.new_page()
        page.insert_text((50, 50), "Hello from PDF")
        pdf_path = temp_repo / "test.pdf"
        doc.save(str(pdf_path))
        doc.close()

        content = read_file("test.pdf")
        assert "Hello from PDF" in content
    except ImportError:
        pytest.skip("pymupdf not available")


def test_read_file_docx(temp_repo):
    """Test reading DOCX files with text extraction."""
    from patchpal.tools import read_file

    # Create a minimal DOCX with text
    try:
        import docx

        doc = docx.Document()
        doc.add_paragraph("Hello from DOCX")
        doc.add_paragraph("Second paragraph")
        docx_path = temp_repo / "test.docx"
        doc.save(str(docx_path))

        content = read_file("test.docx")
        assert "Hello from DOCX" in content
        assert "Second paragraph" in content
    except ImportError:
        pytest.skip("python-docx not available")


def test_read_file_pptx(temp_repo):
    """Test reading PPTX files with text extraction."""
    from patchpal.tools import read_file

    # Create a minimal PPTX with text
    try:
        import pptx

        prs = pptx.Presentation()
        slide = prs.slides.add_slide(prs.slide_layouts[0])
        title = slide.shapes.title
        title.text = "Hello from PPTX"
        pptx_path = temp_repo / "test.pptx"
        prs.save(str(pptx_path))

        content = read_file("test.pptx")
        assert "Slide 1" in content
        assert "Hello from PPTX" in content
    except ImportError:
        pytest.skip("python-pptx not available")


def test_read_file_pdf_missing_library(temp_repo, monkeypatch):
    """Test reading PDF when pymupdf is not available."""
    from patchpal.tools import read_file

    # Create a fake PDF file
    pdf_path = temp_repo / "test.pdf"
    pdf_path.write_bytes(b"%PDF-1.4\nfake pdf content")

    # Mock pymupdf as unavailable
    import patchpal.tools.common

    monkeypatch.setattr(patchpal.tools.common, "PYMUPDF_AVAILABLE", False)

    with pytest.raises(ValueError, match="pymupdf not installed"):
        read_file("test.pdf")


def test_read_file_large_pdf_allowed(temp_repo):
    """Test that large PDFs are allowed (size check on extracted text, not binary)."""
    from patchpal.tools import read_file

    # Create a larger PDF (over MAX_FILE_SIZE binary, but small extracted text)
    try:
        import pymupdf

        doc = pymupdf.open()
        # Add pages with images or content to exceed MAX_FILE_SIZE (500KB default)
        # Each page with inserted text is small, so we need many pages
        for i in range(200):
            page = doc.new_page()
            page.insert_text((50, 50), f"Page {i + 1} content line 1")
            page.insert_text((50, 70), f"Page {i + 1} content line 2")

        pdf_path = temp_repo / "large.pdf"
        doc.save(str(pdf_path))
        doc.close()

        # PDFs don't have size check before extraction
        content = read_file("large.pdf")
        assert "Page 1 content" in content
        assert "Page 200 content" in content
    except ImportError:
        pytest.skip("pymupdf not available")


def test_read_file_large_text_blocked(temp_repo):
    """Test that large text files are still blocked by size limit."""
    from patchpal.tools import read_file

    # Create a large text file (over 500KB)
    large_content = "x" * (600 * 1024)  # 600KB
    (temp_repo / "large.txt").write_text(large_content)

    with pytest.raises(ValueError, match="File too large"):
        read_file("large.txt")


def test_code_structure_python(temp_repo):
    """Test code_structure on a Python file."""
    from patchpal.tools import code_structure

    # Create a Python file with classes and functions
    python_code = '''"""Module docstring."""

def helper_function(x, y):
    """Helper function."""
    return x + y

class MyClass:
    """Class docstring."""

    def __init__(self):
        self.value = 0

    def method_one(self, arg):
        """Method one."""
        return arg * 2

    def method_two(self):
        """Method two."""
        pass

def main():
    """Main function."""
    obj = MyClass()
    return obj.method_one(5)
'''
    (temp_repo / "example.py").write_text(python_code)

    result = code_structure("example.py")

    # Check file info is present
    assert "example.py" in result
    assert "lines" in result

    # Check classes are detected
    assert "Classes" in result
    assert "MyClass" in result

    # Check functions are detected
    assert "Functions" in result
    assert "helper_function" in result
    assert "main" in result

    # Check line numbers are present
    assert "Line" in result

    # Check helpful hint is present
    assert "read_lines" in result


def test_code_structure_max_symbols(temp_repo):
    """Test code_structure with max_symbols parameter."""
    from patchpal.tools import code_structure

    # Create a file with many functions
    functions = "\n\n".join([f"def func_{i}():\n    pass" for i in range(20)])
    (temp_repo / "many_funcs.py").write_text(functions)

    result = code_structure("many_funcs.py", max_symbols=5)

    # Should only show limited number of symbols
    assert "many_funcs.py" in result
    # Won't show all 20 functions due to limit


def test_code_structure_no_tree_sitter(temp_repo, monkeypatch):
    """Test code_structure gracefully handles missing tree-sitter."""
    # Mock tree-sitter as unavailable
    import patchpal.tools.code_analysis
    from patchpal.tools import code_structure

    monkeypatch.setattr(patchpal.tools.code_analysis, "TREE_SITTER_AVAILABLE", False)

    (temp_repo / "test.py").write_text("def foo(): pass")

    result = code_structure("test.py")

    # Should return fallback message
    assert "Tree-sitter not available" in result or "lines" in result


def test_code_structure_unsupported_language(temp_repo):
    """Test code_structure on unsupported file type."""
    from patchpal.tools import code_structure

    # Create a text file (unsupported language)
    (temp_repo / "data.txt").write_text("Just some text\nNot code")

    result = code_structure("data.txt")

    # Should return basic file info
    assert "data.txt" in result
    assert "lines" in result


def test_code_structure_nonexistent_file(temp_repo):
    """Test code_structure on nonexistent file."""
    import pytest

    from patchpal.tools import code_structure

    with pytest.raises(ValueError, match="File not found"):
        code_structure("nonexistent.py")


def test_apply_patch_existing_file(temp_repo):
    """Test applying a patch to an existing file."""
    from patchpal.tools import apply_patch

    result = apply_patch("test.txt", "New content!")
    assert "Successfully updated test.txt" in result
    assert (temp_repo / "test.txt").read_text() == "New content!"


def test_apply_patch_new_file(temp_repo):
    """Test creating a new file with apply_patch."""
    from patchpal.tools import apply_patch

    result = apply_patch("newfile.txt", "Brand new file")
    assert "Successfully updated newfile.txt" in result
    assert (temp_repo / "newfile.txt").read_text() == "Brand new file"


def test_apply_patch_in_new_subdir(temp_repo):
    """Test creating a file in a new subdirectory."""
    from patchpal.tools import apply_patch

    result = apply_patch("newdir/newfile.txt", "Content")
    assert "Successfully updated newdir/newfile.txt" in result
    assert (temp_repo / "newdir" / "newfile.txt").read_text() == "Content"


def test_apply_patch_shows_diff(temp_repo):
    """Test that apply_patch shows a diff."""
    from patchpal.tools import apply_patch

    result = apply_patch("test.txt", "Modified content")
    assert "Diff:" in result
    assert "-Hello, World!" in result
    assert "+Modified content" in result


def test_run_shell_success(temp_repo):
    """Test running a safe shell command."""
    from patchpal.tools import run_shell

    result = run_shell("echo 'Hello'")
    assert "Hello" in result


def test_run_shell_with_output(temp_repo):
    """Test running a shell command with output."""
    from patchpal.tools import run_shell

    result = run_shell("ls test.txt")
    assert "test.txt" in result


def test_run_shell_forbidden_commands(temp_repo):
    """Test that privilege escalation commands are blocked (platform-specific)."""
    import platform

    from patchpal.tools import run_shell

    # Only privilege escalation commands are blocked now (permission system handles the rest)
    if platform.system() == "Windows":
        forbidden_cmds = ["runas /user:Administrator cmd", "psexec -s cmd"]
    else:
        forbidden_cmds = ["sudo ls", "su root"]

    for cmd in forbidden_cmds:
        with pytest.raises(ValueError, match="Blocked dangerous command|Blocked command"):
            run_shell(cmd)


def test_run_shell_allow_sudo(temp_repo, monkeypatch):
    """Test that sudo can be allowed via PATCHPAL_ALLOW_SUDO."""
    import platform

    from patchpal.tools import run_shell

    # Set environment variable to allow sudo
    monkeypatch.setenv("PATCHPAL_ALLOW_SUDO", "true")

    # Need to reload the modules to pick up the new environment variable
    import importlib

    import patchpal.tools
    import patchpal.tools.common
    import patchpal.tools.shell_tools

    importlib.reload(patchpal.tools.common)
    importlib.reload(patchpal.tools.shell_tools)
    importlib.reload(patchpal.tools)

    # Re-patch REPO_ROOT after reload
    monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", temp_repo)

    if platform.system() != "Windows":
        # On Unix-like systems, sudo should now be allowed (will fail but not blocked)
        # We can't actually test sudo execution without root, but we can verify
        # it's not blocked by the FORBIDDEN check
        try:
            # This will fail with "sudo: a terminal is required" or similar
            # but NOT with "Blocked dangerous command"
            run_shell("sudo --version")
            # If it succeeds, that's fine too
        except ValueError as e:
            # Should not be blocked by our FORBIDDEN check
            assert "Blocked dangerous command" not in str(e)
            # Might fail for other reasons (e.g., sudo not installed in test env)
            assert "sudo" not in str(e).lower() or "not found" in str(e).lower()
    else:
        # On Windows, test runas
        try:
            run_shell("runas /?")
        except ValueError as e:
            assert "Blocked dangerous command" not in str(e)


def test_run_shell_complex_safe_command(temp_repo):
    """Test that complex but safe commands work."""
    from patchpal.tools import run_shell

    # Create a file first
    (temp_repo / "count.txt").write_text("line1\nline2\nline3")

    result = run_shell("wc -l count.txt")
    assert "3" in result or "count.txt" in result


def test_run_shell_dangerous_patterns_blocked(temp_repo, monkeypatch):
    """Test that dangerous patterns are blocked by default."""
    import platform

    from patchpal.tools import run_shell

    # Disable permission prompts for this test
    monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "false")

    # Need to reload the modules to pick up the new environment variable
    import importlib

    import patchpal.tools
    import patchpal.tools.common
    import patchpal.tools.shell_tools

    importlib.reload(patchpal.tools.common)
    importlib.reload(patchpal.tools.shell_tools)
    importlib.reload(patchpal.tools)

    # Re-patch REPO_ROOT after reload
    monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", temp_repo)

    # Platform-specific dangerous commands
    if platform.system() == "Windows":
        dangerous_cmds = [
            "echo test > \\\\.\\PhysicalDrive0",  # Writing to device
            "cat file | dd of=output",  # Piping to dd
            "echo test | shred",  # Piping to shred (NEW)
            "mkfs.ext4 /dev/sda1",  # Format filesystem (NEW)
            ":(){:|:&};:",  # Fork bomb (NEW)
        ]
    else:
        dangerous_cmds = [
            "rm -rf /tmp/test",
            "echo hello | dd of=/dev/null",
            "cat file > /dev/sda",
            "echo test | sudo tee /etc/test",  # Piping to sudo
            "cat secrets | shred",  # Piping to shred (NEW)
            "mkfs.ext4 /dev/sdb1",  # Format filesystem (NEW)
            ":(){:|:&};:",  # Fork bomb (NEW)
        ]

    for cmd in dangerous_cmds:
        with pytest.raises(ValueError, match="Blocked dangerous"):
            run_shell(cmd)


def test_run_shell_dangerous_patterns_allowed_with_sudo_flag(temp_repo, monkeypatch):
    """Test that dangerous patterns are allowed when PATCHPAL_ALLOW_SUDO=true."""
    from patchpal.tools import run_shell

    # Set environment variable to allow dangerous operations
    monkeypatch.setenv("PATCHPAL_ALLOW_SUDO", "true")
    monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "false")

    # Need to reload the modules to pick up the new environment variable
    import importlib

    import patchpal.tools
    import patchpal.tools.common
    import patchpal.tools.shell_tools

    importlib.reload(patchpal.tools.common)
    importlib.reload(patchpal.tools.shell_tools)
    importlib.reload(patchpal.tools)

    # Re-patch REPO_ROOT after reload
    monkeypatch.setattr("patchpal.tools.common.REPO_ROOT", temp_repo)

    # These commands should NOT be blocked by dangerous checks anymore
    # Test that previously blocked commands now execute (or fail for other reasons)
    try:
        # Test that commands with previously dangerous patterns are not blocked
        result = run_shell("echo 'test' > /dev/null")
        # Command should execute (redirecting to /dev/null always works)
        assert result is not None
    except ValueError as e:
        # Should NOT be blocked by dangerous pattern/token check
        assert "Blocked dangerous" not in str(e)


def test_check_path_validates_existence():
    """Test that _check_path validates file existence."""
    from patchpal.tools.common import _check_path

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir_path = Path(tmpdir).resolve()  # Resolve to handle symlinks (e.g., macOS /private)

        with patch("patchpal.tools.common.REPO_ROOT", tmpdir_path):
            # Test non-existent file with must_exist=True
            with pytest.raises(ValueError, match="File not found"):
                _check_path("nonexistent.txt", must_exist=True)

            # Test non-existent file with must_exist=False
            result = _check_path("nonexistent.txt", must_exist=False)
            assert result == tmpdir_path / "nonexistent.txt"


def test_web_fetch_success(monkeypatch):
    """Test fetching content from a URL."""
    from unittest.mock import Mock

    from patchpal.tools import web_fetch

    # Mock requests.get
    mock_response = Mock()
    mock_response.status_code = 200
    mock_response.headers = {"Content-Type": "text/html", "Content-Length": "100"}
    mock_response.encoding = "utf-8"
    mock_response.iter_content = lambda chunk_size: [
        b"<html><body><h1>Test</h1><p>Content</p></body></html>"
    ]

    mock_get = Mock(return_value=mock_response)
    monkeypatch.setattr("patchpal.tools.web_tools.requests.get", mock_get)

    # Disable permission prompts
    monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "false")

    # Reset operation counter
    from patchpal.tools import reset_operation_counter

    reset_operation_counter()

    result = web_fetch("https://example.com")
    assert "Test" in result
    assert "Content" in result


def test_web_fetch_invalid_url():
    """Test that invalid URLs are rejected."""
    from patchpal.tools import reset_operation_counter, web_fetch

    reset_operation_counter()

    with pytest.raises(ValueError, match="URL must start with"):
        web_fetch("not-a-url")


def test_web_fetch_content_too_large(monkeypatch):
    """Test that large content is rejected."""
    from unittest.mock import Mock

    from patchpal.tools import web_fetch

    # Mock a response with large content
    mock_response = Mock()
    mock_response.status_code = 200
    mock_response.headers = {"Content-Type": "text/plain", "Content-Length": str(10 * 1024 * 1024)}
    mock_response.encoding = "utf-8"

    mock_get = Mock(return_value=mock_response)
    monkeypatch.setattr("patchpal.tools.web_tools.requests.get", mock_get)

    # Disable permission prompts
    monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "false")

    from patchpal.tools import reset_operation_counter

    reset_operation_counter()

    with pytest.raises(ValueError, match="Content too large"):
        web_fetch("https://example.com")


def test_web_search_success(monkeypatch):
    """Test web search returns results."""
    from unittest.mock import MagicMock, Mock

    from patchpal.tools import web_search

    # Mock DDGS
    mock_ddgs_instance = MagicMock()
    mock_ddgs_instance.text.return_value = [
        {"title": "Result 1", "href": "https://example.com/1", "body": "Description 1"},
        {"title": "Result 2", "href": "https://example.com/2", "body": "Description 2"},
    ]
    mock_ddgs_instance.__enter__.return_value = mock_ddgs_instance
    mock_ddgs_instance.__exit__.return_value = None

    mock_ddgs_class = Mock(return_value=mock_ddgs_instance)
    monkeypatch.setattr("patchpal.tools.web_tools.DDGS", mock_ddgs_class)

    # Disable permission prompts
    monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "false")

    from patchpal.tools import reset_operation_counter

    reset_operation_counter()

    result = web_search("test query")
    assert "Result 1" in result
    assert "Result 2" in result
    assert "https://example.com/1" in result
    assert "Description 1" in result


def test_web_search_no_results(monkeypatch):
    """Test web search with no results."""
    from unittest.mock import MagicMock, Mock

    from patchpal.tools import web_search

    # Mock DDGS with empty results
    mock_ddgs_instance = MagicMock()
    mock_ddgs_instance.text.return_value = []
    mock_ddgs_instance.__enter__.return_value = mock_ddgs_instance
    mock_ddgs_instance.__exit__.return_value = None

    mock_ddgs_class = Mock(return_value=mock_ddgs_instance)
    monkeypatch.setattr("patchpal.tools.web_tools.DDGS", mock_ddgs_class)

    # Disable permission prompts
    monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "false")

    from patchpal.tools import reset_operation_counter

    reset_operation_counter()

    result = web_search("nonexistent query")
    assert "No search results found" in result


def test_web_search_limits_results(monkeypatch):
    """Test that web search respects max_results limit."""
    from unittest.mock import MagicMock, Mock

    from patchpal.tools import web_search

    # Mock DDGS with many results
    mock_results = [
        {"title": f"Result {i}", "href": f"https://example.com/{i}", "body": f"Desc {i}"}
        for i in range(20)
    ]
    mock_ddgs_instance = MagicMock()
    mock_ddgs_instance.text.return_value = mock_results[:3]  # Should only get 3 results
    mock_ddgs_instance.__enter__.return_value = mock_ddgs_instance
    mock_ddgs_instance.__exit__.return_value = None

    mock_ddgs_class = Mock(return_value=mock_ddgs_instance)
    monkeypatch.setattr("patchpal.tools.web_tools.DDGS", mock_ddgs_class)

    # Disable permission prompts
    monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "false")

    from patchpal.tools import reset_operation_counter

    reset_operation_counter()

    web_search("test", max_results=3)
    # Should call with max_results=3
    mock_ddgs_instance.text.assert_called_once_with("test", max_results=3)


def test_edit_file_success(temp_repo):
    """Test successfully editing a file."""
    from patchpal.tools import edit_file

    # Create a test file
    (temp_repo / "edit_test.txt").write_text("Hello World\nThis is a test\nGoodbye World")

    result = edit_file("edit_test.txt", "This is a test", "This is EDITED")
    assert "Successfully edited" in result

    # Verify the edit
    content = (temp_repo / "edit_test.txt").read_text()
    assert "This is EDITED" in content
    assert "This is a test" not in content


def test_edit_file_not_found(temp_repo):
    """Test editing with string not found."""
    from patchpal.tools import edit_file

    (temp_repo / "edit_test.txt").write_text("Hello World")

    with pytest.raises(ValueError, match="String not found"):
        edit_file("edit_test.txt", "Nonexistent", "Replaced")


def test_edit_file_multiple_matches(temp_repo):
    """Test editing with multiple occurrences."""
    from patchpal.tools import edit_file

    (temp_repo / "edit_test.txt").write_text("test\ntest\ntest")

    with pytest.raises(ValueError, match="appears 3 times"):
        edit_file("edit_test.txt", "test", "replaced")


def test_web_fetch_no_truncation(temp_repo, monkeypatch):
    """Test that web_fetch returns content without web-specific truncation.

    Note: Universal tool output truncation is now handled in agent.py, not in web_fetch itself.
    """
    from patchpal.tools import web_fetch

    # Disable permission requirement
    monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "false")

    # Create large content (200 chars) - should be returned in full from web_fetch
    large_content = "A" * 200

    # Mock requests.get
    mock_response = MagicMock()
    mock_response.headers = {"Content-Type": "text/plain", "Content-Length": "200"}
    mock_response.encoding = "utf-8"
    mock_response.raise_for_status = MagicMock()
    mock_response.iter_content = MagicMock(return_value=[large_content.encode("utf-8")])

    with patch("patchpal.tools.web_tools.requests.get", return_value=mock_response):
        result = web_fetch("http://example.com/large.txt", extract_text=False)

        # web_fetch no longer truncates - returns full content
        # Truncation is handled by universal limit in agent.py
        assert result == "A" * 200
        assert "WARNING" not in result  # No web-specific truncation warning


def test_web_fetch_no_truncation_needed(temp_repo, monkeypatch):
    """Test that web_fetch doesn't truncate when content is within limit."""
    from patchpal.tools import web_fetch

    # Disable permission requirement
    monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "false")

    # Create small content
    small_content = "Hello World"

    # Mock requests.get
    mock_response = MagicMock()
    mock_response.headers = {"Content-Type": "text/plain", "Content-Length": "11"}
    mock_response.encoding = "utf-8"
    mock_response.raise_for_status = MagicMock()
    mock_response.iter_content = MagicMock(return_value=[small_content.encode("utf-8")])

    with patch("patchpal.tools.web_tools.requests.get", return_value=mock_response):
        result = web_fetch("http://example.com/small.txt", extract_text=False)

        # Verify content was not truncated
        assert result == "Hello World"


@pytest.fixture
def todo_repo(monkeypatch, temp_repo):
    """Set up a temporary repository for TODO testing."""
    # Ensure PATCHPAL_DIR points to temp location
    todo_dir = temp_repo / ".patchpal"
    todo_dir.mkdir(exist_ok=True)
    monkeypatch.setattr("patchpal.tools.PATCHPAL_DIR", todo_dir)

    # Reset operation counter
    from patchpal.tools import reset_operation_counter, reset_session_todos

    reset_operation_counter()

    # Reset session todos for each test
    reset_session_todos()

    yield temp_repo


def test_todo_add_simple(todo_repo):
    """Test adding a simple TODO task."""
    from patchpal.tools import todo_add

    result = todo_add("Implement authentication")
    assert "✓ Added task #1" in result
    assert "Implement authentication" in result


def test_todo_add_with_details(todo_repo):
    """Test adding a TODO task with details."""
    from patchpal.tools import todo_add

    result = todo_add("Add login endpoint", details="Use JWT tokens with refresh mechanism")
    assert "✓ Added task #1" in result
    assert "Add login endpoint" in result
    assert "JWT tokens" in result


def test_todo_add_multiple_tasks(todo_repo):
    """Test adding multiple TODO tasks."""
    from patchpal.tools import todo_add

    result1 = todo_add("Task 1")
    result2 = todo_add("Task 2")
    result3 = todo_add("Task 3")

    assert "task #1" in result1
    assert "task #2" in result2
    assert "task #3" in result3


def test_todo_list_empty(todo_repo):
    """Test listing TODOs when list is empty."""
    from patchpal.tools import todo_list

    result = todo_list()
    assert "No tasks in TODO list" in result
    assert "todo_add()" in result


def test_todo_list_pending_only(todo_repo):
    """Test listing only pending tasks."""
    from patchpal.tools import todo_add, todo_complete, todo_list

    todo_add("Task 1")
    todo_add("Task 2")
    todo_add("Task 3")
    todo_complete(2)

    result = todo_list(show_completed=False)
    assert "Task 1" in result
    assert "Task 3" in result
    assert "Task 2" not in result  # Completed task should not appear
    assert "○ Task #1" in result
    assert "○ Task #3" in result


def test_todo_list_all_tasks(todo_repo):
    """Test listing all tasks including completed."""
    from patchpal.tools import todo_add, todo_complete, todo_list

    todo_add("Task 1")
    todo_add("Task 2")
    todo_complete(1)

    result = todo_list(show_completed=True)
    assert "Task 1" in result
    assert "Task 2" in result
    assert "✓ Task #1" in result  # Completed
    assert "○ Task #2" in result  # Pending


def test_todo_list_shows_details(todo_repo):
    """Test that todo_list shows task details."""
    from patchpal.tools import todo_add, todo_list

    todo_add("Implement auth", details="Use OAuth2 with PKCE flow\nHandle token refresh")

    result = todo_list()
    assert "Implement auth" in result
    assert "OAuth2" in result
    assert "token refresh" in result


def test_todo_list_shows_progress(todo_repo):
    """Test that todo_list shows progress summary."""
    from patchpal.tools import todo_add, todo_complete, todo_list

    todo_add("Task 1")
    todo_add("Task 2")
    todo_add("Task 3")
    todo_complete(1)
    todo_complete(2)

    result = todo_list(show_completed=True)
    assert "Summary:" in result
    assert "1 pending" in result
    assert "2 completed" in result
    assert "3 total" in result


def test_todo_list_all_completed(todo_repo):
    """Test listing when all tasks are completed."""
    from patchpal.tools import todo_add, todo_complete, todo_list

    todo_add("Task 1")
    todo_add("Task 2")
    todo_complete(1)
    todo_complete(2)

    result = todo_list(show_completed=False)
    assert "No pending tasks" in result
    assert "All tasks completed" in result
    assert "show_completed=True" in result


def test_todo_complete_success(todo_repo):
    """Test completing a TODO task."""
    from patchpal.tools import todo_add, todo_complete

    todo_add("Task to complete")
    result = todo_complete(1)

    assert "✓ Completed task #1" in result
    assert "Task to complete" in result
    assert "Progress: 1/1" in result


def test_todo_complete_shows_progress(todo_repo):
    """Test that todo_complete shows progress."""
    from patchpal.tools import todo_add, todo_complete

    todo_add("Task 1")
    todo_add("Task 2")
    todo_add("Task 3")

    result = todo_complete(2)
    assert "Progress: 1/3" in result


def test_todo_complete_nonexistent(todo_repo):
    """Test completing a nonexistent task."""
    from patchpal.tools import todo_add, todo_complete

    todo_add("Task 1")
    result = todo_complete(999)

    assert "Task #999 not found" in result
    assert "Available task IDs: [1]" in result


def test_todo_complete_already_completed(todo_repo):
    """Test completing an already completed task."""
    from patchpal.tools import todo_add, todo_complete

    todo_add("Task 1")
    todo_complete(1)

    result = todo_complete(1)
    assert "already completed" in result


def test_todo_update_description(todo_repo):
    """Test updating task description."""
    from patchpal.tools import todo_add, todo_update

    todo_add("Original description")
    result = todo_update(1, description="Updated description")

    assert "✓ Updated task #1" in result
    assert "Original description" in result
    assert "Updated description" in result


def test_todo_update_details(todo_repo):
    """Test updating task details."""
    from patchpal.tools import todo_add, todo_list, todo_update

    todo_add("Task 1", details="Old details")
    todo_update(1, details="New details with more information")

    result = todo_list()
    assert "New details with more information" in result
    assert "Old details" not in result


def test_todo_update_both_fields(todo_repo):
    """Test updating both description and details."""
    from patchpal.tools import todo_add, todo_update

    todo_add("Old task", details="Old details")
    result = todo_update(1, description="New task", details="New details")

    assert "✓ Updated task #1" in result
    assert "Old task" in result
    assert "New task" in result


def test_todo_update_no_fields(todo_repo):
    """Test updating without providing any fields."""
    from patchpal.tools import todo_add, todo_update

    todo_add("Task 1")
    result = todo_update(1)

    assert "Error: Must provide either description or details" in result


def test_todo_update_nonexistent(todo_repo):
    """Test updating a nonexistent task."""
    from patchpal.tools import todo_update

    result = todo_update(999, description="New description")
    assert "Task #999 not found" in result


def test_todo_remove_success(todo_repo):
    """Test removing a TODO task."""
    from patchpal.tools import todo_add, todo_remove

    todo_add("Task to remove")
    result = todo_remove(1)

    assert "✓ Removed task #1" in result
    assert "Task to remove" in result
    assert "0 task(s) remaining" in result


def test_todo_remove_with_remaining_tasks(todo_repo):
    """Test removing a task when others remain."""
    from patchpal.tools import todo_add, todo_list, todo_remove

    todo_add("Task 1")
    todo_add("Task 2")
    todo_add("Task 3")

    result = todo_remove(2)
    assert "✓ Removed task #2" in result
    assert "2 task(s) remaining" in result

    # Verify remaining tasks
    list_result = todo_list()
    assert "Task 1" in list_result
    assert "Task 3" in list_result
    assert "Task 2" not in list_result


def test_todo_remove_nonexistent(todo_repo):
    """Test removing a nonexistent task."""
    from patchpal.tools import todo_add, todo_remove

    todo_add("Task 1")
    result = todo_remove(999)

    assert "Task #999 not found" in result
    assert "Available task IDs: [1]" in result


def test_todo_clear_completed_only(todo_repo):
    """Test clearing only completed tasks."""
    from patchpal.tools import todo_add, todo_clear, todo_complete, todo_list

    todo_add("Task 1")
    todo_add("Task 2")
    todo_add("Task 3")
    todo_complete(1)
    todo_complete(3)

    result = todo_clear(completed_only=True)
    assert "✓ Cleared 2 completed task(s)" in result
    assert "1 pending task(s) remaining" in result

    # Verify only pending task remains
    list_result = todo_list()
    assert "Task 2" in list_result
    assert "Task 1" not in list_result
    assert "Task 3" not in list_result


def test_todo_clear_all_tasks(todo_repo):
    """Test clearing all tasks."""
    from patchpal.tools import todo_add, todo_clear, todo_complete, todo_list

    todo_add("Task 1")
    todo_add("Task 2")
    todo_complete(1)

    result = todo_clear(completed_only=False)
    assert "✓ Cleared all 2 task(s)" in result
    assert "TODO list is now empty" in result

    # Verify list is empty
    list_result = todo_list()
    assert "No tasks in TODO list" in list_result


def test_todo_clear_empty_list(todo_repo):
    """Test clearing when TODO list is already empty."""
    from patchpal.tools import todo_clear

    result = todo_clear()
    assert "TODO list is already empty" in result


def test_todo_clear_no_completed_tasks(todo_repo):
    """Test clearing completed tasks when none are completed."""
    from patchpal.tools import todo_add, todo_clear

    todo_add("Task 1")
    todo_add("Task 2")

    result = todo_clear(completed_only=True)
    assert "No completed tasks to clear" in result


def test_todo_persistence(todo_repo):
    """Test that TODO list persists across function calls."""
    from patchpal.tools import todo_add, todo_complete, todo_list

    # Add tasks
    todo_add("Task 1")
    todo_add("Task 2")

    # Complete one
    todo_complete(1)

    # Verify state persists
    result = todo_list(show_completed=True)
    assert "Task 1" in result
    assert "Task 2" in result
    assert "✓ Task #1" in result  # Should be completed


def test_todo_json_structure(todo_repo):
    """Test that TODO session storage has correct structure."""
    from patchpal.tools import todo_add
    from patchpal.tools.todo_tools import _load_todos

    todo_add("Test task", details="Test details")

    # Check the in-memory session storage structure
    data = _load_todos()

    assert "tasks" in data
    assert "next_id" in data
    assert len(data["tasks"]) == 1
    assert data["tasks"][0]["id"] == 1
    assert data["tasks"][0]["description"] == "Test task"
    assert data["tasks"][0]["details"] == "Test details"
    assert data["tasks"][0]["completed"] is False
    assert "created_at" in data["tasks"][0]


def test_todo_timestamps(todo_repo):
    """Test that TODO tasks have proper timestamps."""
    from datetime import datetime

    from patchpal.tools import todo_add, todo_complete, todo_list

    todo_add("Task with timestamp")
    todo_complete(1)

    result = todo_list(show_completed=True)
    # Should show created and completed times
    assert "Created:" in result
    assert "Completed:" in result
    # Should have year
    assert str(datetime.now().year) in result


# ============================================================================
# ask_user Tool Tests
# ============================================================================


def test_ask_user_simple_question(monkeypatch):
    """Test asking a simple question."""
    from patchpal.tools import ask_user, reset_operation_counter

    reset_operation_counter()

    # Mock prompt_toolkit.prompt to return an answer
    with patch("prompt_toolkit.prompt", return_value="Yes"):
        result = ask_user("Should we proceed?")
        assert result == "Yes"


def test_ask_user_with_options(monkeypatch):
    """Test asking a question with multiple choice options."""
    from patchpal.tools import ask_user, reset_operation_counter

    reset_operation_counter()

    # Mock user selecting option 1
    with patch("prompt_toolkit.prompt", return_value="1"):
        result = ask_user("Which database?", options=["PostgreSQL", "MySQL", "SQLite"])
        assert result == "PostgreSQL"


def test_ask_user_with_options_by_name(monkeypatch):
    """Test user typing option name directly."""
    from patchpal.tools import ask_user, reset_operation_counter

    reset_operation_counter()

    # Mock user typing the option name
    with patch("prompt_toolkit.prompt", return_value="MySQL"):
        result = ask_user("Which database?", options=["PostgreSQL", "MySQL", "SQLite"])
        assert result == "MySQL"


def test_ask_user_with_options_custom_answer(monkeypatch):
    """Test user providing custom answer when options are given."""
    from patchpal.tools import ask_user, reset_operation_counter

    reset_operation_counter()

    # Mock user typing a custom answer
    with patch("prompt_toolkit.prompt", return_value="MongoDB"):
        result = ask_user("Which database?", options=["PostgreSQL", "MySQL", "SQLite"])
        assert result == "MongoDB"


def test_ask_user_with_options_out_of_range(monkeypatch):
    """Test user selecting a number out of range."""
    from patchpal.tools import ask_user, reset_operation_counter

    reset_operation_counter()

    # Mock user entering invalid number
    with patch("prompt_toolkit.prompt", return_value="99"):
        result = ask_user("Which database?", options=["PostgreSQL", "MySQL", "SQLite"])
        # Should treat as custom answer
        assert result == "99"


def test_ask_user_audit_logging(monkeypatch, caplog):
    """Test that ask_user logs to audit log."""
    from patchpal.tools import ask_user, reset_operation_counter

    reset_operation_counter()

    with patch("prompt_toolkit.prompt", return_value="Test answer"):
        ask_user("Test question?")

        # Check audit logger was called (in real usage, would be in audit.log)
        # We can't easily verify the log file in tests, but we verify the function completes


def test_ask_user_long_question(monkeypatch):
    """Test asking a long question."""
    from patchpal.tools import ask_user, reset_operation_counter

    reset_operation_counter()

    long_question = (
        "This is a very long question that spans multiple lines and contains lots of details about what we're asking the user to decide on. "
        * 3
    )

    with patch("prompt_toolkit.prompt", return_value="Answer"):
        result = ask_user(long_question)
        assert result == "Answer"


def test_ask_user_empty_options_list(monkeypatch):
    """Test asking with empty options list."""
    from patchpal.tools import ask_user, reset_operation_counter

    reset_operation_counter()

    # Empty list should be treated as no options
    with patch("prompt_toolkit.prompt", return_value="Free form answer"):
        result = ask_user("What do you think?", options=[])
        assert result == "Free form answer"


def test_ask_user_with_markdown_code_block(monkeypatch):
    """Test that code blocks in questions are rendered properly."""
    from patchpal.tools import ask_user, reset_operation_counter

    reset_operation_counter()

    question_with_code = """Can you run this command?

```python
import os
print(os.environ.get('SSL_CERT_FILE'))
```
"""

    # Mock prompt to return an answer
    with patch("prompt_toolkit.prompt", return_value="Done"):
        result = ask_user(question_with_code)
        assert result == "Done"


# ============================================================================
# Flexible edit_file Matching Strategy Tests
# ============================================================================


def test_edit_file_with_wrong_indentation(temp_repo):
    """Test edit_file with flexible matching but proper indentation in new_string."""
    from patchpal.tools import edit_file

    # Create a Python file with proper indentation
    content = """def hello():
    if True:
        print("world")
        return 42
"""
    (temp_repo / "indent_test.py").write_text(content)

    # Search without indentation (flexible matching finds it),
    # but provide new_string WITH proper indentation (OpenCode behavior)
    result = edit_file("indent_test.py", 'print("world")', '        print("universe")')

    assert "Successfully edited" in result

    # Verify the edit preserved indentation (because we provided it in new_string)
    new_content = (temp_repo / "indent_test.py").read_text()
    assert '        print("universe")' in new_content  # 8 spaces preserved
    assert '        print("world")' not in new_content
    # Other lines should be unchanged
    assert "def hello():" in new_content
    assert "    if True:" in new_content


def test_edit_file_multiline_wrong_indentation(temp_repo):
    """Test edit_file with multi-line blocks - new_string must have proper indentation."""
    from patchpal.tools import edit_file

    content = """class MyClass:
    def process(self):
        if self.valid:
            result = self.compute()
            return result
        return None
"""
    (temp_repo / "multiline_test.py").write_text(content)

    # Search without proper indentation (flexible matching),
    # but provide replacement WITH proper indentation
    old_string = """if self.valid:
    result = self.compute()
    return result"""

    new_string = """        if self.valid:
            result = self.compute_new()
            return result"""

    result = edit_file("multiline_test.py", old_string, new_string)

    assert "Successfully edited" in result

    # Verify correct indentation (because we provided it in new_string)
    new_content = (temp_repo / "multiline_test.py").read_text()
    assert "        if self.valid:" in new_content
    assert "            result = self.compute_new()" in new_content
    assert "            return result" in new_content


def test_edit_file_whitespace_normalization(temp_repo):
    """Test edit_file handles extra whitespace in search string."""
    from patchpal.tools import edit_file

    content = """x = 42
y = 100
z = x + y
"""
    (temp_repo / "whitespace_test.py").write_text(content)

    # User provides with extra spaces (e.g., copied from terminal with weird formatting)
    old_string = "x    =    42"

    result = edit_file("whitespace_test.py", old_string, "x = 99")

    assert "Successfully edited" in result

    # Verify the edit worked
    new_content = (temp_repo / "whitespace_test.py").read_text()
    assert "x = 99" in new_content
    assert "x = 42" not in new_content


def test_edit_file_real_world_agent_scenario(temp_repo):
    """Test the actual scenario that failed before: editing agent.py with indentation issues."""
    from patchpal.tools import edit_file

    # Simulate content from agent.py around tool execution
    content = """                              )

                                  # Silently filter out invalid args (models sometimes hallucinate parameters)

                                  tool_result = tool_func(**filtered_args)
                              except Exception as e:
                                  tool_result = f"Error executing {tool_name}: {e}"
                                  print(f"\\033[1;31mX {tool_display}: {e}\\033[0m")

                      # Add tool result to messages"""

    (temp_repo / "agent_snippet.py").write_text(content)

    # What the LLM might provide (without correct indentation)
    old_string = """# Silently filter out invalid args (models sometimes hallucinate parameters)

                                  tool_result = tool_func(**filtered_args)"""

    new_string = """# Silently filter out invalid args (models sometimes hallucinate parameters)

                                  tool_result = tool_func(**filtered_args)

                                  # Display result for certain tools where the result contains important info
                                  if tool_name == "todo_add" and not isinstance(tool_result, Exception):
                                      # Extract and display the task number from the result
                                      print(f"\\033[2m{tool_result.split(':')[0]}\\033[0m", flush=True)"""

    result = edit_file("agent_snippet.py", old_string, new_string)

    assert "Successfully edited" in result

    # Verify the edit preserved original indentation
    new_content = (temp_repo / "agent_snippet.py").read_text()
    assert "                                  # Display result for certain tools" in new_content
    assert "tool_result.split" in new_content


def test_edit_file_code_without_indentation_prefers_line_match(temp_repo):
    """Test that code patterns without indentation prefer line-level matching over substring."""
    from patchpal.tools import edit_file

    content = """def calculate():
    result = compute()
    return result
"""
    (temp_repo / "code_test.py").write_text(content)

    # Search without indentation (flexible matching finds full line),
    # provide replacement WITH proper indentation
    old_string = "return result"
    new_string = "    return final_result"  # With proper indentation

    edit_file("code_test.py", old_string, new_string)

    new_content = (temp_repo / "code_test.py").read_text()
    assert "    return final_result" in new_content
    assert "result = compute()" in new_content  # Should not have changed this line


def test_edit_file_preserves_exact_match_when_possible(temp_repo):
    """Test that exact matches are still preferred when indentation is correct."""
    from patchpal.tools import edit_file

    content = """def hello():
    print("world")
"""
    (temp_repo / "exact_test.py").write_text(content)

    # With correct indentation, should use exact match
    old_string = '    print("world")'

    result = edit_file("exact_test.py", old_string, '    print("universe")')

    assert "Successfully edited" in result

    new_content = (temp_repo / "exact_test.py").read_text()
    assert '    print("universe")' in new_content


def test_edit_file_flexible_matching_error_message(temp_repo):
    """Test error message when string not found."""
    from patchpal.tools import edit_file

    (temp_repo / "test_error.py").write_text("def hello():\n    pass\n")

    # Try to find something that doesn't exist
    with pytest.raises(ValueError) as exc_info:
        edit_file("test_error.py", "goodbye()", "farewell()")

    error_msg = str(exc_info.value)
    assert "String not found" in error_msg
    assert "read_lines()" in error_msg  # Should suggest using read_lines()


def test_edit_file_matching_strategies_helper_functions(temp_repo):
    """Test the underlying matching strategy helper functions directly."""
    from patchpal.tools.file_editing import (
        _try_line_trimmed_match,
        _try_simple_match,
        _try_whitespace_normalized_match,
    )

    content = """def hello():
    print("world")
    return 42
"""

    # Test simple match
    assert _try_simple_match(content, 'print("world")') == 'print("world")'
    assert _try_simple_match(content, "nonexistent") is None

    # Test line trimmed match (should find with correct indentation AND trailing newline)
    match = _try_line_trimmed_match(content, 'print("world")')
    assert match == '    print("world")\n'  # Now preserves trailing newline

    # Test whitespace normalized match
    content2 = "x    =    42"
    match = _try_whitespace_normalized_match(content2, "x = 42")
    assert match == "x    =    42"


def test_edit_file_multiline_trimmed_match_helper(temp_repo):
    """Test line-trimmed matching with multi-line blocks."""
    from patchpal.tools.file_editing import _try_line_trimmed_match

    content = """class Test:
    def method(self):
        if True:
            do_something()
            return value
"""

    # Search without proper indentation
    search = """if True:
    do_something()
    return value"""

    match = _try_line_trimmed_match(content, search)
    # Should return with proper indentation (8 spaces) AND trailing newline
    assert match == "        if True:\n            do_something()\n            return value\n"


def test_edit_file_finds_match_with_strategy_order(temp_repo):
    """Test that strategies are tried in correct order."""
    from patchpal.tools.file_editing import _find_match_with_strategies

    # Scenario: content has both a substring and a full line
    # Should prefer full line match for code patterns
    content = """def calculate():
    result = process()  # result is important
    return result
"""

    # Without indentation, should match the full line not substring in comment
    match = _find_match_with_strategies(content, "return result")
    assert match == "    return result\n"  # Now includes trailing newline
    # Should prefer full line match for code patterns
    content = """def calculate():
    result = process()  # result is important
    return result
"""

    # Without indentation, should match the full line not substring in comment
    match = _find_match_with_strategies(content, "return result")
    assert match == "    return result\n"  # Now includes trailing newline
    # Should NOT match just "result" in the comment or variable name


def test_edit_file_preserves_trailing_newline(temp_repo):
    """Test that flexible matching preserves trailing newlines in matched blocks."""
    from patchpal.tools import edit_file

    # Test case 1: Match in middle of file (should preserve ONE trailing newline, not blank lines)
    content_middle = """def function1():
    print("hello")
    return 1

def function2():
    print("world")
    return 2
"""
    (temp_repo / "newline_test1.py").write_text(content_middle)

    # Edit a block in the middle - the matched block should include ONE trailing newline
    # but NOT the blank line that follows (blank line is not part of the function)
    old_string = """def function1():
    print("hello")
    return 1"""

    new_string = """def function1():
    print("modified")
    return 1"""

    edit_file("newline_test1.py", old_string, new_string)

    # Verify: the matched section gets replaced, preserving structure
    # The blank line should remain because it's between the two functions
    new_content = (temp_repo / "newline_test1.py").read_text()
    # After editing, there should still be a blank line between functions
    assert "\n\ndef function2():" in new_content
    assert 'print("modified")' in new_content

    # Test case 2: Match at end of file WITH trailing newline
    content_end_with = """def function():
    print("test")
    return True
"""
    (temp_repo / "newline_test2.py").write_text(content_end_with)

    old_string = 'print("test")\n    return True'
    new_string = 'print("modified")\n    return True'

    edit_file("newline_test2.py", old_string, new_string)

    new_content = (temp_repo / "newline_test2.py").read_text()
    # File should still end with newline
    assert new_content.endswith("\n")
    assert 'print("modified")' in new_content

    # Test case 3: Match at end of file WITHOUT trailing newline
    content_end_without = """def function():
    print("test")
    return False"""  # No trailing newline

    (temp_repo / "newline_test3.py").write_text(content_end_without)

    old_string = 'print("test")\n    return False'
    new_string = 'print("changed")\n    return False'

    edit_file("newline_test3.py", old_string, new_string)

    new_content = (temp_repo / "newline_test3.py").read_text()
    # File should NOT have trailing newline (preserving original)
    assert not new_content.endswith("\n")
    assert 'print("changed")' in new_content


def test_edit_file_auto_adjusts_indentation(temp_repo):
    """Test that edit_file automatically adjusts indentation of new_string to match matched_string."""
    from patchpal.tools import edit_file

    # Create a file with specific indentation (28 spaces for elif)
    content = """                            elif tool_name == "todo_add":
                                print(
                                    f"Adding TODO",
                                    flush=True,
                                )
"""
    (temp_repo / "indent_adjust_test.py").write_text(content)

    # Provide new_string with WRONG indentation (30 spaces)
    old_string = """elif tool_name == "todo_add":
    print(
        f"Adding TODO",
        flush=True,
    )"""

    new_string = """                              elif tool_name == "todo_add":
                                  print(
                                      f"Modified TODO",
                                      flush=True,
                                  )"""

    edit_file("indent_adjust_test.py", old_string, new_string)

    # Verify the indentation was AUTO-ADJUSTED to match original (28 spaces)
    new_content = (temp_repo / "indent_adjust_test.py").read_text()

    # Should have 28 spaces before elif (not 30)
    assert "                            elif tool_name" in new_content
    # Should have 32 spaces before print (not 34)
    assert "                                print(" in new_content
    # Content should be updated
    assert "Modified TODO" in new_content
    assert "Adding TODO" not in new_content


def test_web_fetch_pdf_extraction(monkeypatch):
    """Test fetching and extracting text from a PDF."""
    from unittest.mock import Mock

    from patchpal.tools import web_fetch
    from patchpal.tools.common import PYMUPDF_AVAILABLE

    if not PYMUPDF_AVAILABLE:
        pytest.skip("PyMuPDF not available")

    # Create a simple PDF in memory
    import io

    import pymupdf

    pdf_bytes = io.BytesIO()
    doc = pymupdf.open()
    page = doc.new_page()
    page.insert_text((72, 72), "Test PDF Content\nSecond Line")
    doc.save(pdf_bytes)
    doc.close()
    pdf_content = pdf_bytes.getvalue()

    # Mock requests.get
    mock_response = Mock()
    mock_response.status_code = 200
    mock_response.headers = {
        "Content-Type": "application/pdf",
        "Content-Length": str(len(pdf_content)),
    }
    mock_response.encoding = "utf-8"
    mock_response.iter_content = lambda chunk_size: [pdf_content]

    mock_get = Mock(return_value=mock_response)
    monkeypatch.setattr("patchpal.tools.web_tools.requests.get", mock_get)

    # Disable permission prompts
    monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "false")

    # Reset operation counter
    from patchpal.tools import reset_operation_counter

    reset_operation_counter()

    result = web_fetch("https://example.com/test.pdf")
    assert "Test PDF Content" in result
    assert "Second Line" in result


def test_web_fetch_pdf_without_pymupdf(monkeypatch):
    """Test PDF fetching when PyMuPDF is not available."""
    from unittest.mock import Mock

    from patchpal.tools import web_fetch

    # Mock PyMuPDF as unavailable in common module (where it's now checked)
    monkeypatch.setattr("patchpal.tools.common.PYMUPDF_AVAILABLE", False)

    # Mock PDF content
    pdf_content = b"%PDF-1.4\n%fake pdf content"

    # Mock requests.get
    mock_response = Mock()
    mock_response.status_code = 200
    mock_response.headers = {
        "Content-Type": "application/pdf",
        "Content-Length": str(len(pdf_content)),
    }
    mock_response.encoding = "utf-8"
    mock_response.iter_content = lambda chunk_size: [pdf_content]

    mock_get = Mock(return_value=mock_response)
    monkeypatch.setattr("patchpal.tools.web_tools.requests.get", mock_get)

    # Disable permission prompts
    monkeypatch.setenv("PATCHPAL_REQUIRE_PERMISSION", "false")

    # Reset operation counter
    from patchpal.tools import reset_operation_counter

    reset_operation_counter()

    result = web_fetch("https://example.com/test.pdf")
    # Should return error message when PyMuPDF is not available
    assert "PDF extraction not available" in result or "pymupdf not installed" in result
