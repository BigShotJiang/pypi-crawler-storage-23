from setuptools import setup, find_packages

setup(
    name="arjun0py",
    version="1.1.3",
    author="Arjun",
    description="Developer toolkit installer",
    packages=find_packages(),
    install_requires=[
        "rich",
        "pyfiglet",
        "colorama"
    ],
    entry_points={
        "console_scripts": [
            "arjun0py=arjun0py.main:run"
        ]
    },
    python_requires=">=3.8",
)