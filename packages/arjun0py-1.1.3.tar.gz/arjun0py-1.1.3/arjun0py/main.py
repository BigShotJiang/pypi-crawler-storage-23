import subprocess
import sys
import platform
from rich.console import Console
from rich.table import Table
from rich.progress import track
import pyfiglet

console = Console()

modules = [
    "requests","numpy","pandas","flask","fastapi","rich","colorama",
    "pyfiglet","matplotlib","scipy","beautifulsoup4","httpx","pillow",
    "pytest","sqlalchemy","uvicorn","jinja2","typer","click","pydantic"
]

def banner():
    text = pyfiglet.figlet_format("ARJUN0PY")
    console.print(f"[bold cyan]{text}[/bold cyan]")
    console.print("[bold green]Developer Toolkit by Arjun[/bold green]\n")

def system_info():
    table = Table(title="System Information")

    table.add_column("Property")
    table.add_column("Value")

    table.add_row("OS", platform.system())
    table.add_row("OS Version", platform.version())
    table.add_row("Python Version", platform.python_version())
    table.add_row("Machine", platform.machine())

    console.print(table)

def install_modules():
    console.print("\n[yellow]Installing developer modules...[/yellow]\n")

    for module in track(modules, description="Installing"):
        subprocess.call([sys.executable, "-m", "pip", "install", "--upgrade", module])

def run():
    banner()
    system_info()
    install_modules()

    console.print("\n[bold green]✔ Setup completed successfully[/bold green]")
    console.print("[bold magenta]Enjoy coding 🚀[/bold magenta]")