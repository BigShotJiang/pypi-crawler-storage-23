# -*- coding: utf-8 -*-
"""通用工具：浮点格式化等"""


def format_float(value: float, precision: int = 15) -> str:
    """格式化浮点数，去除末尾的零。"""
    formatted = f"{value:.{precision}g}"
    if "e" not in formatted.lower():
        formatted = formatted.rstrip("0").rstrip(".")
    return formatted
