# -*- coding: utf-8 -*-
"""命令行入口：check / parse / build，输出与组合位置可指定为同一目录。"""

import argparse
import sys
from pathlib import Path

from . import check as api_check
from . import parse as api_parse
from . import build as api_build


def main():
    ap = argparse.ArgumentParser(
        prog="pb-calibration",
        description="PB 标定文件：反序列化校验、解析为 YAML、从 YAML 组装为 .pb.txt。输出/组合目录可指定且一致。",
    )
    ap.add_argument("--templates", type=str, default=None, help="proto 模板目录（可选）")
    sub = ap.add_subparsers(dest="command", required=True)

    # 1. check：反序列化检查
    p_check = sub.add_parser("check", help="检查 pb.txt 是否存在格式问题（反序列化校验）")
    p_check.add_argument("--input", "-i", required=True, metavar="PB_FILE", help="输入的 .pb.txt 文件路径")
    p_check.set_defaults(func=_cmd_check)

    # 2. parse：解析为 yaml 到指定目录
    p_parse = sub.add_parser("parse", help="解析 pb.txt 为每个单独的 yaml 文件，输出到指定目录（与 build 输入一致）")
    p_parse.add_argument("--input", "-i", required=True, metavar="PB_FILE", help="输入的 .pb.txt 文件路径")
    p_parse.add_argument("--output", "-o", required=True, metavar="YAML_DIR", help="yaml 输出目录（与 build 时 -i 一致，可指定）")
    p_parse.set_defaults(func=_cmd_parse)

    # 3. build：从指定目录按顺序组装为 pb.txt
    p_build = sub.add_parser("build", help="按顺序将 yaml 目录中的文件组装成 pb.txt（输入目录与 parse 输出一致）")
    p_build.add_argument("--input", "-i", required=True, metavar="YAML_DIR", help="yaml 目录（与 parse 的 -o 一致，可指定）")
    p_build.add_argument("--output", "-o", required=True, metavar="PB_FILE", help="输出的 .pb.txt 文件路径")
    p_build.set_defaults(func=_cmd_build)

    args = ap.parse_args()
    return args.func(args)


def _cmd_check(args):
    ok, err = api_check(args.input, proto_templates_dir=args.templates)
    if ok:
        print("OK: 格式校验通过，pb.txt 可正常反序列化。")
        return 0
    print(f"ERROR: 格式问题 - {err}", file=sys.stderr)
    return 1


def _cmd_parse(args):
    pb_path = Path(args.input)
    if not pb_path.exists():
        print(f"ERROR: 输入文件不存在: {pb_path}", file=sys.stderr)
        return 1
    try:
        data, report = api_parse(
            str(pb_path),
            args.output,
            proto_templates_dir=args.templates,
        )
    except Exception as e:
        print(f"ERROR: 解析失败 - {e}", file=sys.stderr)
        return 1
    n_ext = len(data.get("extrinsics", []))
    n_int = len(data.get("intrinsics", []))
    print(f"OK: 已解析并输出到 {args.output}")
    print(f"  order_manifest.yaml, vehicle_info.yaml, vehicle_param.yaml")
    print(f"  extrinsics/*.yaml ({n_ext} 个), intrinsics/*.yaml ({n_int} 个)")
    has_missing = any(report.get(k) for k in ("vehicle_info", "vehicle_param", "extrinsics", "intrinsics"))
    if has_missing:
        print("  与模板对比存在缺项:", report)
    return 0


def _cmd_build(args):
    yaml_dir = Path(args.input)
    if not yaml_dir.is_dir():
        print(f"ERROR: 输入目录不存在或不是目录: {yaml_dir}", file=sys.stderr)
        return 1
    if not (yaml_dir / "order_manifest.yaml").exists():
        print(f"ERROR: 未找到 order_manifest.yaml: {yaml_dir}", file=sys.stderr)
        return 1
    try:
        api_build(
            str(yaml_dir),
            args.output,
            proto_templates_dir=args.templates,
        )
    except Exception as e:
        print(f"ERROR: 组装失败 - {e}", file=sys.stderr)
        return 1
    print(f"OK: 已按顺序组装并输出: {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
