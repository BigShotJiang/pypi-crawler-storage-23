"""Tests for pydantic-ai-quercle."""
