from __future__ import annotations

from .go import scan_go_file

__all__ = ["scan_go_file"]
