"""Skylos CI/CD integration - GitHub Actions workflows, PR review, quality gates."""
