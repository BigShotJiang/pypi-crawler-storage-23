# Fair trees: AUC-based decision tree classifier only
from fair_trees.tree._classes import (
    BaseDecisionTree,
    FairDecisionTreeClassifier,
)

__all__ = [
    "BaseDecisionTree",
    "FairDecisionTreeClassifier",
]
