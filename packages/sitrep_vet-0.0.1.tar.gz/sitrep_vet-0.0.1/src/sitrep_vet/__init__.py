"""SITREP.VET: Semantic transport protocol for bandwidth-constrained channels."""

__version__ = "0.0.1"
