# sitrep.vet

Semantic transport protocol for bandwidth-constrained channels.

Transmits 16-bit codebook coordinates instead of high-dimensional feature vectors — enabling real-time semantic communication over IoT, satellite, and tactical networks.

## Install

```bash
pip install sitrep.vet
```

## Status

This is a name reservation. The full package is in active development.

## Links

- Website: https://sitrep.vet
- Repository: https://github.com/astronolanX/SITREP.VET
