"""I/O modules for infoextract-cidoc."""
