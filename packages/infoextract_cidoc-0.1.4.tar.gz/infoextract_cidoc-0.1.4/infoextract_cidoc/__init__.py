"""infoextract-cidoc - Classful Ontology for Life-Events Information Extraction."""

__version__ = "0.1.0"
