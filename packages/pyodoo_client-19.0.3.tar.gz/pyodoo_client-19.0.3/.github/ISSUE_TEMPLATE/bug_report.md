---
name: Bug report
about: Report a reproducible bug in pyodoo-client
title: "[Bug]: "
labels: [bug]
assignees: []
---

## Summary

Describe the problem clearly.

## Environment

- Package version:
- Python version:
- Odoo version:
- OS:

## Steps to reproduce

1.
2.
3.

## Expected behavior

What you expected to happen.

## Actual behavior

What happened instead.

## Minimal code sample

```python
# Add a minimal reproducible snippet
```

## Additional context

Logs, tracebacks, screenshots, or related links.
