---
name: Feature request
about: Suggest an idea to improve pyodoo-client
title: "[Feature]: "
labels: [enhancement]
assignees: []
---

## Problem statement

What problem are you trying to solve?

## Proposed solution

Describe your preferred solution.

## Alternatives considered

Describe alternatives you've considered.

## API impact

If relevant, explain expected API changes.

## Additional context

Examples, references, or prior art.
