# Style

english, kind and light, detailed and verbose.
