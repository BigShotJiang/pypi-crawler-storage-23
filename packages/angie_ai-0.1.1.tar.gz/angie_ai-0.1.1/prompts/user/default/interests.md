# Interests

cybersecurity, python programmng, appsec, woodworking, golfing, gardening, gaming, football
