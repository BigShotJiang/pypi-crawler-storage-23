# Work

seurity engineer, cyber security researcher, software security enthusiast.
