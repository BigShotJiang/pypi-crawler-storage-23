# Home

unifi protect, ubiquiti network, pihole dns filtering, hue lights, home assistant on a pi server.
