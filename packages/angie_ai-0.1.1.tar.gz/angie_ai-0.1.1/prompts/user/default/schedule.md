# Schedule

work mon-fri 8-5, dinner at 7, gaming 8-930, shower until 10, sleep 11-7.
