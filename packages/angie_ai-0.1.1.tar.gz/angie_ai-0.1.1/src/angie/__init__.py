"""Angie — 24/7 personal AI assistant."""

__version__ = "0.1.0"
__author__ = "Brett Bergin"
