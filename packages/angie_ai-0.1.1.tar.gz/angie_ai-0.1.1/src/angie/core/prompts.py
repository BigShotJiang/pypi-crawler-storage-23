"""Prompt hierarchy manager.

Hierarchy:
    SYSTEM_PROMPT > ANGIE_PROMPT > AGENT_PROMPT    (for agent tasks)
    SYSTEM_PROMPT > ANGIE_PROMPT > USER_PROMPTS    (for user interactions)
"""

from __future__ import annotations

from pathlib import Path

from jinja2 import Environment, FileSystemLoader, StrictUndefined

from angie.config import get_settings


class PromptManager:
    """Loads, renders, and composes the prompt hierarchy."""

    def __init__(self, prompts_dir: str | None = None) -> None:
        settings = get_settings()
        self.prompts_dir = Path(prompts_dir or settings.prompts_dir)
        self.user_prompts_dir = Path(settings.user_prompts_dir)
        self._env = Environment(  # noqa: S701  # nosec B701 — markdown prompts, not HTML
            loader=FileSystemLoader([str(self.prompts_dir)]),
            undefined=StrictUndefined,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self._cache: dict[str, str] = {}

    def _render(self, template_name: str, context: dict | None = None) -> str:
        key = f"{template_name}:{context}"
        if key not in self._cache:
            template = self._env.get_template(template_name)
            self._cache[key] = template.render(**(context or {}))
        return self._cache[key]

    def _load_file(self, path: Path) -> str:
        return path.read_text(encoding="utf-8") if path.exists() else ""

    def get_system_prompt(self, context: dict | None = None) -> str:
        try:
            return self._render("system.md", context)
        except Exception:
            return self._load_file(self.prompts_dir / "system.md")

    def get_angie_prompt(self, context: dict | None = None) -> str:
        try:
            return self._render("angie.md", context)
        except Exception:
            return self._load_file(self.prompts_dir / "angie.md")

    def get_agent_prompt(self, agent_slug: str, context: dict | None = None) -> str:
        template_name = f"agents/{agent_slug}.md"
        try:
            return self._render(template_name, context)
        except Exception:
            path = self.prompts_dir / "agents" / f"{agent_slug}.md"
            return self._load_file(path)

    def compose_for_agent(
        self,
        agent_slug: str,
        context: dict | None = None,
        agent_instructions: str = "",
    ) -> str:
        """Compose: SYSTEM > ANGIE > AGENT_PROMPT/INSTRUCTIONS."""
        # Use inline instructions if provided, otherwise load from file
        agent_prompt = agent_instructions or self.get_agent_prompt(agent_slug, context)
        parts = [
            self.get_system_prompt(context),
            self.get_angie_prompt(context),
            agent_prompt,
        ]
        return "\n\n---\n\n".join(p for p in parts if p.strip())

    def compose_with_user_prompts(
        self,
        user_prompts: list[str],
        context: dict | None = None,
    ) -> str:
        """Compose: SYSTEM > ANGIE > pre-loaded user prompts (DB-backed)."""
        parts = [
            self.get_system_prompt(context),
            self.get_angie_prompt(context),
            *user_prompts,
        ]
        return "\n\n---\n\n".join(p for p in parts if p.strip())

    def invalidate_cache(self) -> None:
        self._cache.clear()


_manager: PromptManager | None = None


def get_prompt_manager() -> PromptManager:
    global _manager
    if _manager is None:
        _manager = PromptManager()
    return _manager


async def load_user_prompts_from_db(user_id: str) -> list[str]:
    """Load active user prompts from the database.

    Used by CLI commands to get DB-backed personalization.
    Returns an empty list if the DB is unavailable or no prompts exist.
    """
    import logging

    logger = logging.getLogger(__name__)
    try:
        from sqlalchemy import select

        from angie.db.session import get_session_factory
        from angie.models.prompt import Prompt, PromptType

        factory = get_session_factory()
        async with factory() as session:
            result = await session.execute(
                select(Prompt.content).where(
                    Prompt.user_id == user_id,
                    Prompt.type == PromptType.USER,
                    Prompt.is_active.is_(True),
                )
            )
            return [row[0] for row in result.all()]
    except Exception as exc:
        logger.debug("Could not load user prompts from DB: %s", exc)
        return []
