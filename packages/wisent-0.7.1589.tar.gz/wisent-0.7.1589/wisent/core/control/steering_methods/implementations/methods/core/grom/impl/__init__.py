"""GROM implementation details."""
