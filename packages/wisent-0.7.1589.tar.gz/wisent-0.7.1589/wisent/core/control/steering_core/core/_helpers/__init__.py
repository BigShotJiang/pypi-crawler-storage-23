"""Extracted helpers for files exceeding 300-line limit."""
