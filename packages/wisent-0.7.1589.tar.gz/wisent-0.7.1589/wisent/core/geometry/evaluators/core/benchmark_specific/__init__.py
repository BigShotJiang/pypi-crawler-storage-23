import os as _os
_base = _os.path.dirname(__file__)
for _root, _dirs, _files in _os.walk(_base):
    _dirs[:] = sorted(d for d in _dirs if not d.startswith((".", "_")))
    if _root != _base:
        __path__.append(_root)

"""Benchmark-specific evaluators for lm-eval tasks.

This module provides evaluation methods that match lm-eval's native approaches:
- Log likelihood evaluation for multiple-choice tasks
- Generation evaluation for text generation tasks
- Exact match evaluation for precise answer matching
- F1 evaluation for token-level comparison
- Perplexity evaluation for language modeling
- Coding evaluation for code generation tasks
"""

from .likelihood.log_likelihoods_evaluator import LogLikelihoodsEvaluator
from .generation_evaluator import GenerationEvaluator
from .exact_match_evaluator import ExactMatchEvaluator
from .f1_evaluator import F1Evaluator
from .likelihood.perplexity_evaluator import PerplexityEvaluator
from .coding.code_metrics.evaluator import CodingEvaluator
from .code.conala_evaluator import CoNaLaEvaluator

# MathEvaluator requires math_equivalence which is installed from GitHub
# Make it lazy to avoid import errors when not installed
try:
    from .math.math_evaluator import MathEvaluator
    _MATH_EVALUATOR_AVAILABLE = True
except ImportError:
    MathEvaluator = None
    _MATH_EVALUATOR_AVAILABLE = False

# Backward compatibility alias
DockerCodeEvaluator = CodingEvaluator

__all__ = [
    'LogLikelihoodsEvaluator',
    'GenerationEvaluator',
    'ExactMatchEvaluator',
    'F1Evaluator',
    'PerplexityEvaluator',
    'CodingEvaluator',
    'DockerCodeEvaluator',  # Backward compatibility
    'MathEvaluator',
    'CoNaLaEvaluator',
]
