"""
Example custom evaluators for various use cases.

These examples demonstrate how to create custom evaluators for:
- AI detection (GPTZero, RoBERTa detector, etc.)
- Writing quality
- Style matching
- Custom API integrations
"""

from wisent.core.evaluators.custom.examples.detectors import (
    GPTZeroEvaluator,
    create_gptzero_evaluator,
    RobertaDetectorEvaluator,
    create_roberta_detector_evaluator,
    DesklibDetectorEvaluator,
    create_desklib_detector_evaluator,
)
from wisent.core.evaluators.custom.examples.humanization import (
    HumanizationEvaluator,
    create_humanization_evaluator,
    HumanizationCoherentEvaluator,
    create_humanization_coherent_evaluator,
)

__all__ = [
    "GPTZeroEvaluator",
    "create_gptzero_evaluator",
    "HumanizationEvaluator",
    "create_humanization_evaluator",
    "HumanizationCoherentEvaluator",
    "create_humanization_coherent_evaluator",
    "RobertaDetectorEvaluator",
    "create_roberta_detector_evaluator",
    "DesklibDetectorEvaluator",
    "create_desklib_detector_evaluator",
]
