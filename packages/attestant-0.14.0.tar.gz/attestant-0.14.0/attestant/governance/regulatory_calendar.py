"""
Regulatory Calendar & Deadline Tracker.

Tracks upcoming compliance deadlines, filing dates, exam schedules,
and regulatory milestones relevant to AI systems in financial services.

Pre-loaded with major 2025-2027 deadlines including:
    - EU AI Act phased implementation
    - Colorado AI Act effective date
    - NYC Local Law 144 annual audit cycles
    - ECOA/Reg B periodic reporting
    - SR 11-7 annual validation cycles
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional


class DeadlineUrgency(Enum):
    """Urgency level of a regulatory deadline."""
    OVERDUE = "overdue"
    IMMEDIATE = "immediate"  # within 30 days
    UPCOMING = "upcoming"    # 31-90 days
    PLANNED = "planned"      # 91-365 days
    FUTURE = "future"        # more than 365 days


@dataclass
class RegulatoryDeadline:
    """A regulatory deadline or milestone.

    Attributes:
        name: Short name for the deadline.
        regulation: Which regulation this belongs to.
        deadline_date: When the deadline falls.
        description: What must be done by this date.
        recurring: Whether this deadline recurs (e.g. annual audit).
        recurrence_days: If recurring, how many days between occurrences.
        action_required: Specific action needed.
        responsible_party: Who is responsible (e.g. "deployer", "developer").
        notes: Additional context.
    """
    name: str
    regulation: str
    deadline_date: date
    description: str
    recurring: bool = False
    recurrence_days: int = 0
    action_required: str = ""
    responsible_party: str = ""
    notes: str = ""

    @property
    def days_until(self) -> int:
        return (self.deadline_date - date.today()).days

    @property
    def urgency(self) -> DeadlineUrgency:
        days = self.days_until
        if days < 0:
            return DeadlineUrgency.OVERDUE
        elif days <= 30:
            return DeadlineUrgency.IMMEDIATE
        elif days <= 90:
            return DeadlineUrgency.UPCOMING
        elif days <= 365:
            return DeadlineUrgency.PLANNED
        return DeadlineUrgency.FUTURE

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "regulation": self.regulation,
            "deadline_date": self.deadline_date.isoformat(),
            "days_until": self.days_until,
            "urgency": self.urgency.value,
            "description": self.description,
            "recurring": self.recurring,
            "recurrence_days": self.recurrence_days,
            "action_required": self.action_required,
            "responsible_party": self.responsible_party,
            "notes": self.notes,
        }


class RegulatoryCalendar:
    """Tracks regulatory deadlines and compliance milestones.

    Pre-loaded with major financial services AI regulation deadlines
    for 2025-2027. Custom deadlines can be added for institution-specific
    obligations.

    Usage::

        cal = RegulatoryCalendar()
        # Get all upcoming deadlines within 90 days
        upcoming = cal.upcoming(days=90)
        for d in upcoming:
            print(f"{d.urgency.value}: {d.name} - {d.deadline_date}")

        # Get overdue items
        overdue = cal.overdue()

        # Generate a full calendar report
        report = cal.generate_report()
    """

    _DEFAULT_DEADLINES: List[RegulatoryDeadline] = [
        # EU AI Act Implementation Timeline
        RegulatoryDeadline(
            name="EU AI Act - Prohibited AI Practices",
            regulation="EU AI Act",
            deadline_date=date(2025, 2, 2),
            description=(
                "Prohibition of unacceptable-risk AI systems "
                "(Article 5) takes effect."
            ),
            action_required="Ensure no prohibited AI practices are deployed.",
            responsible_party="deployer",
        ),
        RegulatoryDeadline(
            name="EU AI Act - GPAI Model Rules",
            regulation="EU AI Act",
            deadline_date=date(2025, 8, 2),
            description=(
                "Rules for general-purpose AI models (Chapter V) "
                "and governance framework take effect."
            ),
            action_required="Classify GPAI models and ensure transparency obligations.",
            responsible_party="developer",
        ),
        RegulatoryDeadline(
            name="EU AI Act - High-Risk AI Obligations",
            regulation="EU AI Act",
            deadline_date=date(2026, 8, 2),
            description=(
                "Full compliance required for high-risk AI systems "
                "(Articles 6-51). Risk management, data governance, "
                "technical documentation, transparency, human oversight, "
                "accuracy, robustness, and cybersecurity requirements."
            ),
            action_required=(
                "Complete conformity assessment, register in EU database, "
                "implement risk management system, compile technical "
                "documentation per Annex IV."
            ),
            responsible_party="developer and deployer",
            notes="This is the critical compliance milestone.",
        ),
        RegulatoryDeadline(
            name="EU AI Act - Existing High-Risk (Annex I)",
            regulation="EU AI Act",
            deadline_date=date(2027, 8, 2),
            description=(
                "High-risk AI systems listed in Annex I (e.g. medical "
                "devices, machinery) that were placed on market before "
                "Aug 2026 must comply."
            ),
            action_required="Retrofit existing Annex I systems to comply.",
            responsible_party="developer and deployer",
        ),

        # Colorado AI Act
        RegulatoryDeadline(
            name="Colorado AI Act - Effective Date",
            regulation="Colorado AI Act",
            deadline_date=date(2026, 2, 1),
            description=(
                "Colorado Artificial Intelligence Act (SB 24-205) "
                "takes effect. All obligations for developers and "
                "deployers of high-risk AI systems begin."
            ),
            action_required=(
                "Complete impact assessment, implement risk management "
                "programme, establish consumer notification processes, "
                "document human appeal mechanism."
            ),
            responsible_party="deployer",
        ),

        # NYC Local Law 144 (already effective, annual audit cycle)
        RegulatoryDeadline(
            name="NYC LL144 - Annual Bias Audit",
            regulation="NYC Local Law 144",
            deadline_date=date(2026, 7, 5),
            description=(
                "Annual independent bias audit required for all "
                "Automated Employment Decision Tools (AEDTs)."
            ),
            recurring=True,
            recurrence_days=365,
            action_required=(
                "Engage independent auditor, conduct bias audit, "
                "publish audit summary on employer website."
            ),
            responsible_party="deployer",
        ),

        # SR 11-7 Annual Validation Cycle
        RegulatoryDeadline(
            name="SR 11-7 - Annual Model Validation",
            regulation="SR 11-7 / OCC 2011-12",
            deadline_date=date(2026, 3, 31),
            description=(
                "Annual independent validation of high-risk and "
                "critical models per SR 11-7 §5."
            ),
            recurring=True,
            recurrence_days=365,
            action_required=(
                "Complete independent model validation, update model "
                "inventory, refresh challenger model benchmarks, "
                "report findings to MRM committee."
            ),
            responsible_party="model risk management",
        ),

        # ECOA/Reg B Periodic Requirements
        RegulatoryDeadline(
            name="ECOA - HMDA Annual Reporting",
            regulation="ECOA / Reg B",
            deadline_date=date(2026, 3, 1),
            description=(
                "Annual HMDA data submission to CFPB for prior "
                "calendar year lending data."
            ),
            recurring=True,
            recurrence_days=365,
            action_required=(
                "Submit HMDA Loan/Application Register to CFPB. "
                "Ensure demographic monitoring data is complete."
            ),
            responsible_party="compliance",
        ),

        # CFPB Fair Lending Examination
        RegulatoryDeadline(
            name="CFPB - Fair Lending Exam Prep",
            regulation="ECOA / Reg B",
            deadline_date=date(2026, 6, 30),
            description=(
                "Prepare for potential CFPB fair lending examination. "
                "Ensure all adverse action documentation, model "
                "documentation, and fairness analysis is current."
            ),
            recurring=True,
            recurrence_days=365,
            action_required=(
                "Review all model documentation, update fairness "
                "analysis reports, verify adverse action notice "
                "procedures, prepare examiner package."
            ),
            responsible_party="compliance",
        ),
    ]

    def __init__(self) -> None:
        self._deadlines: List[RegulatoryDeadline] = list(self._DEFAULT_DEADLINES)

    def add(self, deadline: RegulatoryDeadline) -> None:
        """Add a custom deadline."""
        self._deadlines.append(deadline)

    @property
    def deadlines(self) -> List[RegulatoryDeadline]:
        """All tracked deadlines, sorted by date."""
        return sorted(self._deadlines, key=lambda d: d.deadline_date)

    def upcoming(self, days: int = 90) -> List[RegulatoryDeadline]:
        """Get deadlines within the next N days."""
        today = date.today()
        cutoff = today + timedelta(days=days)
        return sorted(
            [d for d in self._deadlines
             if today <= d.deadline_date <= cutoff],
            key=lambda d: d.deadline_date,
        )

    def overdue(self) -> List[RegulatoryDeadline]:
        """Get overdue deadlines."""
        return sorted(
            [d for d in self._deadlines if d.days_until < 0],
            key=lambda d: d.deadline_date,
        )

    def by_regulation(self, regulation: str) -> List[RegulatoryDeadline]:
        """Get all deadlines for a specific regulation."""
        reg = regulation.lower()
        return sorted(
            [d for d in self._deadlines if reg in d.regulation.lower()],
            key=lambda d: d.deadline_date,
        )

    def by_urgency(self, urgency: DeadlineUrgency) -> List[RegulatoryDeadline]:
        """Get all deadlines with a specific urgency level."""
        return sorted(
            [d for d in self._deadlines if d.urgency == urgency],
            key=lambda d: d.deadline_date,
        )

    def generate_report(self) -> Dict[str, Any]:
        """Generate a full calendar report."""
        deadlines = self.deadlines

        by_urgency: Dict[str, List[Dict[str, Any]]] = {}
        for d in deadlines:
            by_urgency.setdefault(d.urgency.value, []).append(d.to_dict())

        by_regulation: Dict[str, List[Dict[str, Any]]] = {}
        for d in deadlines:
            by_regulation.setdefault(d.regulation, []).append(d.to_dict())

        return {
            "as_of_date": date.today().isoformat(),
            "total_deadlines": len(deadlines),
            "overdue_count": len(self.overdue()),
            "immediate_count": len(self.by_urgency(DeadlineUrgency.IMMEDIATE)),
            "upcoming_count": len(self.by_urgency(DeadlineUrgency.UPCOMING)),
            "by_urgency": by_urgency,
            "by_regulation": by_regulation,
            "all_deadlines": [d.to_dict() for d in deadlines],
        }
