"""
FairLens: Algorithmic Fairness Analysis for Regulated Industries

Detects proxy discrimination, computes disparate impact metrics,
searches for Less Discriminatory Alternatives (LDAs), and generates
per-applicant decision explanation reason codes for ML models across
lending, hiring, insurance, housing, healthcare, education, and more.

Quick start:
    fairlens analyze --model model.pkl --data data.csv \
        --protected race,sex,age --industry lending

Architecture:
    FairLens ingests trained ML models and their training data, traces
    feature influence through the provenance engine, identifies proxy
    variables correlated with protected attributes, and systematically
    searches for less discriminatory alternatives. Industry-specific
    regulatory frameworks provide statute references, reason code
    libraries, and analysis thresholds.
"""

__version__ = "0.1.0"

from .engine import (
    FairLensEngine,
    FairLensConfig,
    FairLensReport,
    Finding,
    FindingSeverity,
    ModelIdentity,
    compute_model_hash,
)
from .disparate_impact import (
    DisparateImpactAnalyzer,
    DisparateImpactResult,
    IntersectionalGroup,
    IntersectionalResult,
    GroupMetrics,
)
from .proxy_detection import (
    ProxyDetector,
    ProxyResult,
    CausalChainLink,
)
from .lda_search import (
    LDASearcher,
    LDACandidate,
    LDASearchSummary,
)
from .adverse_action import (
    AdverseActionGenerator,
    AdverseActionReason,
    ApplicantExplanation,
)
from .regulatory import (
    RegulatoryFramework,
    IndustryPreset,
    get_framework,
    list_frameworks,
)
from .model_adapter import (
    ModelAdapter,
    adapt_model,
    detect_framework,
)
# Alias for industry-agnostic usage
DecisionExplanationGenerator = AdverseActionGenerator

__all__ = [
    "__version__",
    "FairLensEngine",
    "FairLensConfig",
    "FairLensReport",
    "Finding",
    "FindingSeverity",
    "ModelIdentity",
    "compute_model_hash",
    "DisparateImpactAnalyzer",
    "DisparateImpactResult",
    "IntersectionalGroup",
    "IntersectionalResult",
    "GroupMetrics",
    "ProxyDetector",
    "ProxyResult",
    "CausalChainLink",
    "LDASearcher",
    "LDACandidate",
    "LDASearchSummary",
    "AdverseActionGenerator",
    "AdverseActionReason",
    "ApplicantExplanation",
    "DecisionExplanationGenerator",
    "RegulatoryFramework",
    "IndustryPreset",
    "get_framework",
    "list_frameworks",
    "ModelAdapter",
    "adapt_model",
    "detect_framework",
]
