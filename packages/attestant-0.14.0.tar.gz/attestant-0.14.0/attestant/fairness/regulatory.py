"""
FairLens regulatory framework registry: pluggable industry-specific
regulatory configurations with pre-built presets for lending, hiring,
insurance, housing, healthcare, education, and general-purpose use.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional


class IndustryPreset(Enum):
    LENDING = "lending"
    HIRING = "hiring"
    INSURANCE = "insurance"
    HOUSING = "housing"
    HEALTHCARE = "healthcare"
    EDUCATION = "education"
    GENERAL = "general"


@dataclass
class RegulatoryFramework:
    """Industry-specific regulatory configuration for bias analysis."""
    framework_id: str
    name: str
    description: str
    statute_references: List[str]
    protected_attributes: List[str]
    proxy_threshold: float
    four_fifths_threshold: float
    max_reasons: int
    reason_code_library: Dict[str, str]
    feature_mapping: Optional[Dict[str, List[str]]] = None
    monitoring_frequency: str = "quarterly"
    risk_tier: str = "high"
    threshold_justification: str = ""

    def get_statute_citation(self) -> str:
        """Return a formatted citation string for all statute references."""
        return "; ".join(self.statute_references)


_LENDING_FRAMEWORK = RegulatoryFramework(
    framework_id="lending",
    name="Fair Lending (ECOA / Reg B)",
    description="Fair lending compliance framework covering ECOA, Regulation B, and CFPB guidance for credit decisioning models.",
    statute_references=[
        "ECOA / Reg B (12 CFR 1002)",
        "CFPB Circular 2022-03 (Chatbots & Adverse Action)",
        "CFPB Circular 2023-03 (AI Adverse Action Specificity)",
        "Griggs v. Duke Power, 401 U.S. 424 (1971)",
        "FFIEC Adverse Action Model Form C-1",
        "12 CFR 1002.4(a)",
        "12 CFR 1002.6(a)",
        "12 CFR 1002.9(a)(2)",
        "SR 11-7 / OCC 2011-12 (Model Risk Management)",
        "MA AG v. Earnest Operations (2025) - AI fair lending",
    ],
    protected_attributes=["race", "color", "religion", "national_origin", "sex", "marital_status", "age"],
    proxy_threshold=0.50,
    four_fifths_threshold=0.80,
    max_reasons=4,
    reason_code_library={
        "A01": "Amount owed on accounts is too high",
        "A02": "Level of delinquency on accounts",
        "A03": "Too few bank revolving accounts",
        "A04": "Too many bank or national revolving accounts",
        "A05": "Too many accounts with balances",
        "A06": "Too many consumer finance company accounts",
        "A07": "Account payment history is too poor",
        "A08": "Too many accounts recently opened",
        "A09": "Too many inquiries last 12 months",
        "A10": "Too many accounts opened in last 12 months",
        "B01": "Proportion of balances to credit limits is too high on revolving accounts",
        "B02": "Number of revolving accounts with balances is too high",
        "B03": "Amount owed on revolving accounts is too high",
        "B04": "Time since most recent account opening is too short",
        "C01": "Too few accounts currently paid as agreed",
        "C02": "Time since delinquency is too recent or unknown",
        "C03": "Number of accounts with delinquency is too high",
        "C04": "Amount past due on accounts",
        "C05": "Presence of derogatory public records",
        "D01": "Length of time accounts have been established",
        "D02": "Time since most recent account opening is too short",
        "D03": "Length of time revolving accounts have been established",
        "E01": "Insufficient credit file information",
        "E02": "Not enough accounts with recent activity",
        "E03": "No recent revolving balances",
        "F01": "Income insufficient for amount of credit requested",
        "F02": "Excessive obligations in relation to income",
        "F03": "Unable to verify income",
        "G01": "Length of employment",
        "G02": "Length of time at current address",
        "H01": "Lack of recent installment loan information",
        "H02": "Lack of recent revolving account information",
        "H03": "No recent non-mortgage balance information",
        "I01": "Number of recent inquiries",
        "I02": "Number of established accounts",
    },
    feature_mapping={
        "credit_score": ["E01"],
        "fico": ["E01"],
        "credit_utilization": ["B01", "B03"],
        "utilization": ["B01"],
        "debt_to_income": ["F02"],
        "dti": ["F02"],
        "income": ["F01"],
        "annual_income": ["F01"],
        "monthly_income": ["F01"],
        "loan_amount": ["F01"],
        "amount_requested": ["F01"],
        "delinquency": ["A02", "C02"],
        "delinq": ["A02", "C02"],
        "past_due": ["C04"],
        "late_payment": ["A07"],
        "payment_history": ["A07"],
        "num_open_accounts": ["A08", "I02"],
        "open_accounts": ["A08"],
        "total_accounts": ["I02"],
        "recent_inquiries": ["A09", "I01"],
        "inquiries": ["A09", "I01"],
        "account_age": ["D01", "D03"],
        "credit_age": ["D01"],
        "length_of_credit": ["D01"],
        "employment_length": ["G01"],
        "emp_length": ["G01"],
        "years_employed": ["G01"],
        "revolving_balance": ["B03", "A01"],
        "total_balance": ["A01", "A05"],
        "balance": ["A01"],
        "public_records": ["C05"],
        "bankruptcy": ["C05"],
        "collections": ["C05"],
        "address_length": ["G02"],
        "months_at_address": ["G02"],
        "installment": ["H01"],
    },
    monitoring_frequency="monthly",
    risk_tier="high",
    threshold_justification=(
        "Four-fifths (80%) rule per Griggs v. Duke Power, 401 U.S. 424 "
        "(1971) and EEOC Uniform Guidelines on Employee Selection "
        "Procedures § 4D (1978). Proxy threshold 0.50 per CFPB "
        "Circular 2023-03 adverse action specificity standard."
    ),
)

_HIRING_FRAMEWORK = RegulatoryFramework(
    framework_id="hiring",
    name="Employment Selection (Title VII / EEOC)",
    description="Employment discrimination compliance framework covering Title VII, EEOC Uniform Guidelines, ADA, and ADEA for hiring and promotion models.",
    statute_references=[
        "Title VII of the Civil Rights Act (42 USC 2000e-2)",
        "EEOC Uniform Guidelines on Employee Selection Procedures (29 CFR 1607)",
        "Americans with Disabilities Act (ADA)",
        "Age Discrimination in Employment Act (ADEA)",
        "Griggs v. Duke Power, 401 U.S. 424 (1971)",
        "Ricci v. DeStefano, 557 U.S. 557 (2009)",
    ],
    protected_attributes=["race", "color", "religion", "sex", "national_origin", "age", "disability", "genetic_information"],
    proxy_threshold=0.50,
    four_fifths_threshold=0.80,
    max_reasons=5,
    reason_code_library={
        "HR01": "Insufficient relevant work experience",
        "HR02": "Education level does not meet minimum requirements",
        "HR03": "Required certification or license not held",
        "HR04": "Skills assessment score below threshold",
        "HR05": "Insufficient demonstrated technical proficiency",
        "HR06": "Work history gap exceeds acceptable duration",
        "HR07": "Reference check results unsatisfactory",
        "HR08": "Background verification incomplete or adverse",
        "HR09": "Interview performance below selection threshold",
        "HR10": "Language proficiency does not meet job requirements",
        "HR11": "Geographic availability does not match position requirements",
        "HR12": "Schedule availability does not meet operational needs",
        "HR13": "Required security clearance not obtainable",
        "HR14": "Physical requirements of position not met",
        "HR15": "Insufficient leadership or supervisory experience",
        "HR16": "Portfolio or work sample quality below standard",
        "HR17": "Cultural fit assessment below threshold",
        "HR18": "Salary expectations exceed approved range",
        "HR19": "Aptitude test score below minimum",
        "HR20": "Insufficient industry-specific knowledge",
    },
    feature_mapping={
        "years_experience": ["HR01"],
        "experience": ["HR01"],
        "work_experience": ["HR01"],
        "education_level": ["HR02"],
        "education": ["HR02"],
        "degree": ["HR02"],
        "certification": ["HR03"],
        "license": ["HR03"],
        "skills_score": ["HR04"],
        "skills": ["HR04"],
        "technical_score": ["HR05"],
        "technical": ["HR05"],
        "employment_gap": ["HR06"],
        "gap": ["HR06"],
        "reference_score": ["HR07"],
        "references": ["HR07"],
        "background_check": ["HR08"],
        "background": ["HR08"],
        "interview_score": ["HR09"],
        "interview": ["HR09"],
        "language_proficiency": ["HR10"],
        "language": ["HR10"],
        "availability": ["HR11", "HR12"],
        "schedule": ["HR12"],
        "clearance": ["HR13"],
        "security_clearance": ["HR13"],
        "physical_test": ["HR14"],
        "fitness": ["HR14"],
        "leadership_experience": ["HR15"],
        "leadership": ["HR15"],
        "portfolio_score": ["HR16"],
        "portfolio": ["HR16"],
        "culture_fit": ["HR17"],
        "salary_expectation": ["HR18"],
        "salary": ["HR18"],
        "aptitude_score": ["HR19"],
        "aptitude": ["HR19"],
        "industry_knowledge": ["HR20"],
    },
    monitoring_frequency="quarterly",
    risk_tier="high",
    threshold_justification=(
        "Four-fifths (80%) rule per Griggs v. Duke Power and EEOC "
        "Uniform Guidelines § 4D. Title VII applies to employment "
        "selection procedures including automated screening."
    ),
)

_INSURANCE_FRAMEWORK = RegulatoryFramework(
    framework_id="insurance",
    name="Insurance Underwriting (NAIC / State Unfair Discrimination)",
    description="Insurance underwriting and pricing compliance framework covering NAIC model laws, AI/ML guidance, and state unfair discrimination statutes.",
    statute_references=[
        "NAIC Unfair Trade Practices Model Law (Model 880)",
        "NAIC Model Bulletin on AI/ML in Insurance",
        "State unfair discrimination statutes",
        "Fair Credit Reporting Act (FCRA)",
        "McCarran-Ferguson Act",
    ],
    protected_attributes=["race", "color", "religion", "national_origin", "sex", "marital_status", "disability"],
    proxy_threshold=0.45,
    four_fifths_threshold=0.80,
    max_reasons=5,
    reason_code_library={
        "IN01": "Claims history frequency exceeds acceptable threshold",
        "IN02": "Claims severity exceeds acceptable threshold",
        "IN03": "Credit-based insurance score below minimum",
        "IN04": "Driving record does not meet underwriting standards",
        "IN05": "Property condition does not meet underwriting standards",
        "IN06": "Coverage territory risk classification",
        "IN07": "Insufficient prior insurance coverage history",
        "IN08": "Prior policy cancellation or non-renewal",
        "IN09": "Age of insured property exceeds acceptable range",
        "IN10": "Occupancy type does not meet underwriting criteria",
        "IN11": "Protection class does not meet minimum requirements",
        "IN12": "Loss ratio for class exceeds acceptable threshold",
        "IN13": "Medical history does not meet underwriting guidelines",
        "IN14": "Lifestyle risk factors exceed acceptable level",
        "IN15": "Financial stability indicators below threshold",
        "IN16": "Business classification risk exceeds acceptable level",
        "IN17": "Prior fraud indicator on file",
        "IN18": "Insufficient verifiable information provided",
        "IN19": "Catastrophe exposure exceeds capacity",
        "IN20": "Reinsurance requirements not met for risk class",
    },
    feature_mapping={
        "claims_history": ["IN01"],
        "claims_frequency": ["IN01"],
        "claims_severity": ["IN02"],
        "claim_amount": ["IN02"],
        "credit_insurance_score": ["IN03"],
        "insurance_score": ["IN03"],
        "driving_record": ["IN04"],
        "violations": ["IN04"],
        "accidents": ["IN04"],
        "property_condition": ["IN05"],
        "territory": ["IN06"],
        "location_risk": ["IN06"],
        "prior_coverage": ["IN07"],
        "coverage_history": ["IN07"],
        "cancellation": ["IN08"],
        "non_renewal": ["IN08"],
        "property_age": ["IN09"],
        "building_age": ["IN09"],
        "occupancy": ["IN10"],
        "occupancy_type": ["IN10"],
        "protection_class": ["IN11"],
        "fire_protection": ["IN11"],
        "loss_ratio": ["IN12"],
        "medical_history": ["IN13"],
        "health_history": ["IN13"],
        "lifestyle_risk": ["IN14"],
        "smoking": ["IN14"],
        "financial_stability": ["IN15"],
        "business_class": ["IN16"],
        "fraud_indicator": ["IN17"],
        "fraud_score": ["IN17"],
        "verification": ["IN18"],
        "catastrophe": ["IN19"],
        "cat_exposure": ["IN19"],
        "reinsurance": ["IN20"],
    },
    monitoring_frequency="semi-annually",
    risk_tier="high",
    threshold_justification=(
        "NAIC AI/ML Model Bulletin requires actuarial justification "
        "for disparate impact. Four-fifths threshold adapted from "
        "Griggs; proxy threshold 0.45 reflects state insurance "
        "commissioner guidance."
    ),
)

_HOUSING_FRAMEWORK = RegulatoryFramework(
    framework_id="housing",
    name="Fair Housing (FHA / HUD)",
    description="Fair housing compliance framework covering the Fair Housing Act, HUD regulations, and Supreme Court disparate impact standards for housing-related decisions.",
    statute_references=[
        "Fair Housing Act (42 USC 3601-3619)",
        "HUD Fair Housing Regulations (24 CFR 100)",
        "Texas Dep\'t of Housing v. Inclusive Communities Project, 576 U.S. 519 (2015)",
        "24 CFR 100.500 (Discriminatory Effect Standard)",
    ],
    protected_attributes=["race", "color", "religion", "sex", "familial_status", "national_origin", "disability"],
    proxy_threshold=0.45,
    four_fifths_threshold=0.80,
    max_reasons=4,
    reason_code_library={
        "HS01": "Income insufficient for requested unit or purchase price",
        "HS02": "Credit history does not meet screening criteria",
        "HS03": "Rental history references unsatisfactory",
        "HS04": "Employment verification incomplete or insufficient",
        "HS05": "Debt-to-income ratio exceeds program limits",
        "HS06": "Insufficient liquid assets for required down payment",
        "HS07": "Prior eviction history on record",
        "HS08": "Criminal background check findings",
        "HS09": "Occupancy standards exceeded for unit size",
        "HS10": "Source of income does not meet program requirements",
        "HS11": "Length of residency at prior address insufficient",
        "HS12": "Pet policy restrictions not met",
        "HS13": "Co-signer or guarantor requirement not satisfied",
        "HS14": "Application information could not be verified",
        "HS15": "Property appraisal below purchase price",
        "HS16": "Loan-to-value ratio exceeds program maximum",
        "HS17": "Flood zone determination affects eligibility",
        "HS18": "Title search revealed encumbrances",
        "HS19": "Environmental assessment findings",
        "HS20": "Property does not meet habitability standards",
    },
    feature_mapping={
        "income": ["HS01"],
        "annual_income": ["HS01"],
        "credit_history": ["HS02"],
        "credit_score": ["HS02"],
        "rental_history": ["HS03"],
        "rental_references": ["HS03"],
        "employment": ["HS04"],
        "employment_verification": ["HS04"],
        "debt_to_income": ["HS05"],
        "dti": ["HS05"],
        "liquid_assets": ["HS06"],
        "savings": ["HS06"],
        "down_payment": ["HS06"],
        "eviction": ["HS07"],
        "eviction_history": ["HS07"],
        "criminal_background": ["HS08"],
        "background_check": ["HS08"],
        "occupancy": ["HS09"],
        "household_size": ["HS09"],
        "income_source": ["HS10"],
        "residency_length": ["HS11"],
        "pet": ["HS12"],
        "cosigner": ["HS13"],
        "guarantor": ["HS13"],
        "verification": ["HS14"],
        "appraisal": ["HS15"],
        "property_value": ["HS15"],
        "loan_to_value": ["HS16"],
        "ltv": ["HS16"],
        "flood_zone": ["HS17"],
        "title": ["HS18"],
        "environmental": ["HS19"],
        "habitability": ["HS20"],
    },
    monitoring_frequency="quarterly",
    risk_tier="high",
    threshold_justification=(
        "Four-fifths (80%) rule adapted from Griggs for housing "
        "context. 42 U.S.C. § 3604 provides the substantive "
        "framework; HUD disparate impact rule (24 CFR 100.500) "
        "codifies burden-shifting analysis."
    ),
)

_HEALTHCARE_FRAMEWORK = RegulatoryFramework(
    framework_id="healthcare",
    name="Healthcare Nondiscrimination (ACA Section 1557)",
    description="Healthcare nondiscrimination compliance framework covering ACA Section 1557, Title VI, and Section 504 for clinical and administrative decision models.",
    statute_references=[
        "ACA Section 1557 (42 USC 18116)",
        "45 CFR Part 92 (Section 1557 Implementing Regulations)",
        "Title VI of the Civil Rights Act (42 USC 2000d)",
        "Rehabilitation Act Section 504",
        "HHS Office for Civil Rights Guidance on AI in Healthcare",
    ],
    protected_attributes=["race", "color", "national_origin", "sex", "age", "disability", "language"],
    proxy_threshold=0.40,
    four_fifths_threshold=0.80,
    max_reasons=5,
    reason_code_library={
        "HC01": "Clinical risk score does not meet treatment threshold",
        "HC02": "Prior authorization criteria not satisfied",
        "HC03": "Medical necessity criteria not demonstrated",
        "HC04": "Treatment not covered under current benefit plan",
        "HC05": "Step therapy requirements not completed",
        "HC06": "Specialist referral requirement not met",
        "HC07": "Frequency or duration limits reached for service",
        "HC08": "Out-of-network provider without qualifying exception",
        "HC09": "Experimental or investigational treatment classification",
        "HC10": "Concurrent review criteria not met",
        "HC11": "Discharge planning criteria satisfied",
        "HC12": "Rehabilitation progress benchmarks not met",
        "HC13": "Formulary tier restriction applies",
        "HC14": "Quantity limit exceeded for medication",
        "HC15": "Age-based screening guideline not met",
        "HC16": "Risk stratification score below intervention threshold",
        "HC17": "Social determinants of health risk factors identified",
        "HC18": "Care gap identified for preventive services",
        "HC19": "Readmission risk score exceeds threshold",
        "HC20": "Clinical pathway deviation requires review",
    },
    feature_mapping={
        "clinical_risk": ["HC01"],
        "risk_score": ["HC01"],
        "prior_auth": ["HC02"],
        "prior_authorization": ["HC02"],
        "medical_necessity": ["HC03"],
        "benefit_plan": ["HC04"],
        "coverage": ["HC04"],
        "step_therapy": ["HC05"],
        "referral": ["HC06"],
        "specialist_referral": ["HC06"],
        "frequency_limit": ["HC07"],
        "duration_limit": ["HC07"],
        "network": ["HC08"],
        "provider_network": ["HC08"],
        "experimental": ["HC09"],
        "investigational": ["HC09"],
        "concurrent_review": ["HC10"],
        "discharge": ["HC11"],
        "rehabilitation": ["HC12"],
        "rehab_progress": ["HC12"],
        "formulary": ["HC13"],
        "medication_tier": ["HC13"],
        "quantity_limit": ["HC14"],
        "screening": ["HC15"],
        "age_screening": ["HC15"],
        "risk_stratification": ["HC16"],
        "social_determinants": ["HC17"],
        "sdoh": ["HC17"],
        "care_gap": ["HC18"],
        "preventive": ["HC18"],
        "readmission_risk": ["HC19"],
        "readmission": ["HC19"],
        "clinical_pathway": ["HC20"],
    },
    monitoring_frequency="quarterly",
    risk_tier="high",
    threshold_justification=(
        "Section 1557 of the ACA prohibits discrimination in health "
        "programs. Proxy threshold 0.40 reflects heightened sensitivity "
        "for patient safety; four-fifths rule adapted from Griggs."
    ),
)

_EDUCATION_FRAMEWORK = RegulatoryFramework(
    framework_id="education",
    name="Educational Nondiscrimination (Title VI / Title IX)",
    description="Educational nondiscrimination compliance framework covering Title VI, Title IX, FERPA, and Supreme Court guidance for admissions and academic models.",
    statute_references=[
        "Title VI of the Civil Rights Act (42 USC 2000d)",
        "Title IX of the Education Amendments (20 USC 1681)",
        "Family Educational Rights and Privacy Act (FERPA)",
        "Students for Fair Admissions v. Harvard, 600 U.S. 181 (2023)",
    ],
    protected_attributes=["race", "color", "national_origin", "sex", "disability", "age"],
    proxy_threshold=0.45,
    four_fifths_threshold=0.80,
    max_reasons=5,
    reason_code_library={
        "ED01": "Academic performance metrics below admission threshold",
        "ED02": "Standardized test scores below minimum requirement",
        "ED03": "Prerequisite coursework requirements not satisfied",
        "ED04": "Application materials incomplete or unverifiable",
        "ED05": "Extracurricular or leadership profile below benchmark",
        "ED06": "Personal statement or essay evaluation below standard",
        "ED07": "Letters of recommendation insufficient or absent",
        "ED08": "Interview performance below selection threshold",
        "ED09": "Portfolio or audition evaluation below standard",
        "ED10": "Research experience insufficient for program level",
        "ED11": "Language proficiency requirements not met",
        "ED12": "Financial documentation incomplete for aid consideration",
        "ED13": "Enrollment capacity reached for selected program",
        "ED14": "Residency or domicile requirements not satisfied",
        "ED15": "Transfer credit evaluation below minimum",
        "ED16": "Grade point average below program threshold",
        "ED17": "Attendance record does not meet policy requirements",
        "ED18": "Disciplinary record review findings",
        "ED19": "Program-specific prerequisite skills not demonstrated",
        "ED20": "Cohort diversity metrics applied per institutional policy",
    },
    feature_mapping={
        "academic_performance": ["ED01"],
        "grades": ["ED01"],
        "test_scores": ["ED02"],
        "standardized_test": ["ED02"],
        "sat": ["ED02"],
        "act": ["ED02"],
        "gre": ["ED02"],
        "prerequisite": ["ED03"],
        "coursework": ["ED03"],
        "application": ["ED04"],
        "extracurricular": ["ED05"],
        "leadership": ["ED05"],
        "personal_statement": ["ED06"],
        "essay": ["ED06"],
        "recommendation": ["ED07"],
        "letters": ["ED07"],
        "interview_score": ["ED08"],
        "interview": ["ED08"],
        "portfolio": ["ED09"],
        "audition": ["ED09"],
        "research_experience": ["ED10"],
        "research": ["ED10"],
        "language": ["ED11"],
        "language_proficiency": ["ED11"],
        "financial_documentation": ["ED12"],
        "financial_aid": ["ED12"],
        "enrollment_capacity": ["ED13"],
        "residency": ["ED14"],
        "domicile": ["ED14"],
        "transfer_credits": ["ED15"],
        "transfer": ["ED15"],
        "gpa": ["ED16"],
        "grade_point": ["ED16"],
        "attendance": ["ED17"],
        "disciplinary": ["ED18"],
        "conduct": ["ED18"],
        "prerequisite_skills": ["ED19"],
        "diversity_metrics": ["ED20"],
    },
    monitoring_frequency="semi-annually",
    risk_tier="medium",
    threshold_justification=(
        "Title VI / Title IX prohibit discrimination in federally "
        "funded education. Four-fifths rule adapted from Griggs; "
        "proxy threshold 0.45 reflects OCR enforcement guidance."
    ),
)

_GENERAL_FRAMEWORK = RegulatoryFramework(
    framework_id="general",
    name="General Algorithmic Fairness (EU AI Act / Cross-Industry)",
    description="General-purpose algorithmic fairness framework based on EU AI Act requirements and cross-industry best practices for high-risk AI systems.",
    statute_references=[
        "EU AI Act Articles 9, 10, 13, 14",
        "Griggs v. Duke Power, 401 U.S. 424 (1971)",
        "OECD AI Principles",
        "NIST AI Risk Management Framework (AI RMF 1.0)",
    ],
    protected_attributes=["race", "color", "sex", "religion", "national_origin", "age", "disability"],
    proxy_threshold=0.50,
    four_fifths_threshold=0.80,
    max_reasons=5,
    reason_code_library={
        "GN01": "Primary decision factor score below threshold",
        "GN02": "Secondary decision factor score below threshold",
        "GN03": "Risk assessment score exceeds acceptable level",
        "GN04": "Eligibility criteria not satisfied",
        "GN05": "Verification requirements not met",
        "GN06": "Historical performance data insufficient",
        "GN07": "Input data quality below minimum standard",
        "GN08": "Automated screening threshold not met",
        "GN09": "Manual review override applied",
        "GN10": "Capacity or resource constraints applied",
        "GN11": "Geographic eligibility criteria not met",
        "GN12": "Temporal eligibility window not satisfied",
        "GN13": "Required documentation not provided",
        "GN14": "Third-party data source returned adverse information",
        "GN15": "Model confidence below minimum for automated decision",
        "GN16": "Anomaly detection flagged input for review",
        "GN17": "Policy rule exclusion applied",
        "GN18": "Aggregate risk score exceeds threshold",
        "GN19": "Comparative ranking below selection cutoff",
        "GN20": "Regulatory or compliance hold applied",
    },
    feature_mapping={
        "primary_score": ["GN01"],
        "main_score": ["GN01"],
        "secondary_score": ["GN02"],
        "risk_assessment": ["GN03"],
        "risk_score": ["GN03"],
        "eligibility": ["GN04"],
        "eligible": ["GN04"],
        "verification": ["GN05"],
        "identity_verification": ["GN05"],
        "historical_performance": ["GN06"],
        "performance": ["GN06"],
        "data_quality": ["GN07"],
        "completeness": ["GN07"],
        "screening": ["GN08"],
        "automated_screening": ["GN08"],
        "manual_override": ["GN09"],
        "override": ["GN09"],
        "capacity": ["GN10"],
        "resource": ["GN10"],
        "geographic": ["GN11"],
        "location": ["GN11"],
        "temporal": ["GN12"],
        "timing": ["GN12"],
        "documentation": ["GN13"],
        "documents": ["GN13"],
        "third_party": ["GN14"],
        "external_data": ["GN14"],
        "confidence": ["GN15"],
        "model_confidence": ["GN15"],
        "anomaly": ["GN16"],
        "outlier": ["GN16"],
        "policy_rule": ["GN17"],
        "policy": ["GN17"],
        "aggregate_risk": ["GN18"],
        "composite_score": ["GN18"],
        "comparative_ranking": ["GN19"],
        "ranking": ["GN19"],
        "compliance_hold": ["GN20"],
        "regulatory_hold": ["GN20"],
    },
    monitoring_frequency="quarterly",
    risk_tier="high",
    threshold_justification=(
        "EU AI Act Articles 9-10 require documented risk management "
        "and data governance. Four-fifths rule per Griggs and EEOC "
        "Uniform Guidelines; proxy threshold 0.50 is industry standard."
    ),
)

_FRAMEWORK_REGISTRY: Dict[IndustryPreset, RegulatoryFramework] = {
    IndustryPreset.LENDING: _LENDING_FRAMEWORK,
    IndustryPreset.HIRING: _HIRING_FRAMEWORK,
    IndustryPreset.INSURANCE: _INSURANCE_FRAMEWORK,
    IndustryPreset.HOUSING: _HOUSING_FRAMEWORK,
    IndustryPreset.HEALTHCARE: _HEALTHCARE_FRAMEWORK,
    IndustryPreset.EDUCATION: _EDUCATION_FRAMEWORK,
    IndustryPreset.GENERAL: _GENERAL_FRAMEWORK,
}


def get_framework(preset: IndustryPreset) -> RegulatoryFramework:
    """Retrieve the regulatory framework for an industry preset.

    Args:
        preset: An IndustryPreset enum value.

    Returns:
        The corresponding RegulatoryFramework.

    Raises:
        KeyError: If the preset has no registered framework.
    """
    if preset not in _FRAMEWORK_REGISTRY:
        raise KeyError(f"No framework registered for preset: {preset}")
    return _FRAMEWORK_REGISTRY[preset]


def list_frameworks() -> Dict[str, RegulatoryFramework]:
    """Return all registered frameworks keyed by their preset value string.

    Returns:
        Dict mapping preset value strings to RegulatoryFramework instances.
    """
    return {preset.value: fw for preset, fw in _FRAMEWORK_REGISTRY.items()}
