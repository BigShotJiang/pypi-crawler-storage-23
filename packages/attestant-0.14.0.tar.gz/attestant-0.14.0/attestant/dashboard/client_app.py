"""
Client-Facing Dashboard: Bank CRO/CCO Compliance Portal.

Shows a bank's compliance posture, model inventory, fairness results,
regulatory calendar, certifications, and active alerts.  Reads from
the Aurora PostgreSQL dashboard store (DashboardStore).

Authentication is enforced on all routes.  Users must be in the
tenant's allowlist (stored in ``dashboard_users`` table).  Login
is via email + password with bcrypt hashing, or via SSO (Cognito
OIDC/SAML federation) when configured.

Usage:
    DASH_WRITER_DSN=postgresql://... DASH_TENANT=acme python -m attestant.dashboard.client_app
    # Then open: http://localhost:5003

Requires Aurora PostgreSQL (DASH_WRITER_DSN).
"""

import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import tempfile
import time

import bcrypt
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from functools import wraps

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from flask import Flask, g, jsonify, render_template, render_template_string, request, Response, redirect, make_response

logger = logging.getLogger(__name__)

app = Flask(__name__)


class _ReverseProxied:
    """WSGI middleware that adjusts SCRIPT_NAME from X-Script-Name header.

    When behind nginx with a URL prefix (e.g. /client/), nginx sets
    X-Script-Name and strips the prefix. This middleware puts it back
    so Flask generates correct absolute URLs for redirects and links.
    """
    def __init__(self, wsgi_app):
        self.app = wsgi_app

    def __call__(self, environ, start_response):
        script_name = environ.get("HTTP_X_SCRIPT_NAME", "")
        if script_name:
            environ["SCRIPT_NAME"] = script_name
            path_info = environ.get("PATH_INFO", "")
            if path_info.startswith(script_name):
                environ["PATH_INFO"] = path_info[len(script_name):]
        # Trust X-Forwarded-Proto from nginx so request.scheme is correct
        forwarded_proto = environ.get("HTTP_X_FORWARDED_PROTO", "")
        if forwarded_proto in ("https", "http"):
            environ["wsgi.url_scheme"] = forwarded_proto
        return self.app(environ, start_response)


app.wsgi_app = _ReverseProxied(app.wsgi_app)


@app.after_request
def _fix_redirect_location(response):
    """Prepend SCRIPT_NAME to redirect Location headers."""
    if response.status_code in (301, 302, 303, 307, 308):
        location = response.headers.get("Location", "")
        if location.startswith("/") and not location.startswith(request.script_root + "/"):
            response.headers["Location"] = request.script_root + location
    return response


_DEFAULT_TENANT = os.environ.get("DASH_TENANT", "demo")

_store = None
_user_table_ready = False

_SESSION_SECRET = os.environ.get("CLIENT_SESSION_SECRET") or secrets.token_hex(32)

COGNITO_REGION = os.environ.get("COGNITO_REGION", "us-east-1")
COGNITO_USER_POOL_ID = os.environ.get("COGNITO_USER_POOL_ID", "")
COGNITO_CLIENT_ID = os.environ.get("COGNITO_CLIENT_ID", "")
COGNITO_DOMAIN = os.environ.get("COGNITO_DOMAIN", "")
COGNITO_CALLBACK_URL = os.environ.get("COGNITO_CALLBACK_URL", "")

GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "")
GOOGLE_CLIENT_SECRET = os.environ.get("GOOGLE_CLIENT_SECRET", "")
_GOOGLE_REDIRECT_URI_ENV = os.environ.get("GOOGLE_REDIRECT_URI", "")


def _google_redirect_uri():
    """Return the Google OAuth redirect URI, auto-detecting from request if not set."""
    if _GOOGLE_REDIRECT_URI_ENV:
        return _GOOGLE_REDIRECT_URI_ENV
    return request.host_url.rstrip("/") + request.script_root + "/auth/google/callback"

ATTESTANT_API_URL = os.environ.get("ATTESTANT_API_URL", "")

VALID_ROLES = ("admin", "manager", "analyst")

# ---------------------------------------------------------------------------
# Granular Permissions
# ---------------------------------------------------------------------------

from attestant.dashboard.dashdb import ALL_PERMISSIONS, ROLE_DEFAULTS
from attestant.dashboard import billing, email_service

PERMISSION_SECTION_MAP = {
    "view_compliance": "overview",
    "view_fairness": "riskmap",
    "view_models": "models",
    "view_pipelines": "pipelines",
    "view_alerts": "actions",
    "view_reports": "reports",
    "manage_users": None,
    "manage_permissions": "permissions",
    "export_data": None,
}


def _get_effective_permissions(tenant_id, user_email, user_role):
    store = _get_store()
    if store is None:
        return ROLE_DEFAULTS.get(user_role, ROLE_DEFAULTS["analyst"])
    user_row = store.get_user_by_email(tenant_id, user_email)
    if not user_row:
        return ROLE_DEFAULTS.get(user_role, ROLE_DEFAULTS["analyst"])
    db_perms = store.get_user_permissions(tenant_id, user_row["id"])
    if db_perms:
        defaults = ROLE_DEFAULTS.get(user_role, ROLE_DEFAULTS["analyst"])
        merged = dict(defaults)
        merged.update(db_perms)
        return merged
    return ROLE_DEFAULTS.get(user_role, ROLE_DEFAULTS["analyst"])


def require_permission(perm_name):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            user = getattr(request, "current_user", None)
            if not user:
                return jsonify({"error": "Unauthorized"}), 401
            if user["role"] == "admin":
                return f(*args, **kwargs)
            perms = _get_effective_permissions(
                g.tenant_id, user["email"], user["role"]
            )
            if not perms.get(perm_name, False):
                return jsonify({"error": "Insufficient permissions"}), 403
            return f(*args, **kwargs)
        return decorated
    return decorator


_AUTH_FAILURES: defaultdict = defaultdict(list)
_MAX_FAILURES = 5
_FAILURE_WINDOW = 300
_LOCKOUT_DURATION = 600


_egress_buffer: dict = {}  # {tenant_id: bytes_total}


@app.after_request
def _track_egress(response):
    tenant_id = getattr(g, "tenant_id", None)
    if tenant_id:
        length = response.content_length or 0
        if length > 0:
            _egress_buffer[tenant_id] = _egress_buffer.get(tenant_id, 0) + length
    return response


@app.after_request
def add_security_headers(response):
    """Add security headers to all responses."""
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://cdn.jsdelivr.net https://static.cloudflareinsights.com; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; "
        "img-src 'self' data: https://www.gstatic.com; "
        "connect-src 'self' https://cdn.jsdelivr.net"
    )
    return response


# ---------------------------------------------------------------------------
# Authentication System
# ---------------------------------------------------------------------------

def _is_rate_limited(ip: str) -> bool:
    now = time.monotonic()
    _AUTH_FAILURES[ip] = [t for t in _AUTH_FAILURES[ip] if now - t < _FAILURE_WINDOW]
    if len(_AUTH_FAILURES[ip]) >= _MAX_FAILURES:
        if now - _AUTH_FAILURES[ip][-1] < _LOCKOUT_DURATION:
            return True
        _AUTH_FAILURES[ip].clear()
    return False


def _record_auth_failure(ip: str) -> None:
    _AUTH_FAILURES[ip].append(time.monotonic())
    logger.warning("Failed client auth attempt from %s (attempt %d)", ip, len(_AUTH_FAILURES[ip]))


def _hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(rounds=12)).decode("utf-8")


def _notify_alert(store, tenant_id: str, alert: dict) -> None:
    severity = alert.get("severity", "info")
    prefs = store.get_notification_preferences(tenant_id)
    for pref in prefs:
        event_types = pref.get("event_types") or ["critical", "warning"]
        if isinstance(event_types, str):
            try:
                event_types = json.loads(event_types)
            except (ValueError, TypeError):
                event_types = ["critical", "warning"]
        if pref.get("email_enabled") and severity in event_types:
            tenant = store.get_tenant(tenant_id)
            tenant_name = tenant.get("name", tenant_id) if tenant else tenant_id
            email_service.send_alert_email(
                pref["email"],
                alert.get("title", "Alert"),
                severity,
                alert.get("description", ""),
                tenant_name,
            )


def _check_password(password: str, hashed: str) -> tuple:
    if hashed.startswith("$2b$") or hashed.startswith("$2a$"):
        return bcrypt.checkpw(password.encode("utf-8"), hashed.encode("utf-8")), False
    try:  # Legacy PBKDF2
        parts = hashed.split("$")
        if len(parts) != 3:
            return False, False
        _, salt, stored = parts
        h = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 260000)
        return h.hex() == stored, True
    except Exception as exc:
        logger.warning("Password verification error: %s", exc)
        return False, False


def _make_session_token(email: str, role: str, tenant_id: str = "") -> str:
    tid = tenant_id or _DEFAULT_TENANT
    payload = f"{email}|{role}|{tid}|{int(time.time())}"
    sig = hmac.new(
        _SESSION_SECRET.encode(), payload.encode(), hashlib.sha256
    ).hexdigest()
    return f"{payload}|{sig}"


def _validate_session_token(token: str):
    try:
        parts = token.rsplit("|", 1)
        if len(parts) != 2:
            return None
        payload, sig = parts
        expected = hmac.new(
            _SESSION_SECRET.encode(), payload.encode(), hashlib.sha256
        ).hexdigest()
        if not hmac.compare_digest(sig, expected):
            return None
        fields = payload.split("|")
        if len(fields) != 4:
            return None
        email, role, tenant_id, ts = fields
        ts_int = int(ts)
        if ts_int > int(time.time()) + 60:
            return None
        age = int(time.time()) - ts_int
        if age > 86400:
            return None
        g.tenant_id = tenant_id
        return {"email": email, "role": role, "tenant_id": tenant_id}
    except Exception as exc:
        logger.debug("Session token parse error: %s", exc)
        return None


def _get_current_user():
    cookie = request.cookies.get("attestant_client_session")
    if cookie:
        return _validate_session_token(cookie)
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return _validate_session_token(auth[7:])
    return None


def require_client_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        user = _get_current_user()
        if user:
            request.current_user = user
            if not getattr(g, 'tenant_id', None):
                g.tenant_id = _DEFAULT_TENANT
            return f(*args, **kwargs)

        accept = request.headers.get("Accept", "")
        is_ajax = request.headers.get("X-Requested-With") == "XMLHttpRequest"
        is_fetch = "application/json" in accept and "text/html" not in accept
        if not is_ajax and not is_fetch and "text/html" in accept:
            return redirect("/login")

        return jsonify({"error": "Unauthorized"}), 401
    return decorated


def require_role(*allowed_roles):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            user = getattr(request, "current_user", None)
            if not user:
                return jsonify({"error": "Unauthorized"}), 401
            if user["role"] not in allowed_roles:
                return jsonify({"error": "Insufficient permissions"}), 403
            return f(*args, **kwargs)
        return decorated
    return decorator


def _validate_email(email: str) -> bool:
    return bool(re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email))


def _get_store():
    """Lazily connect to Aurora PostgreSQL DashboardStore."""
    global _store
    if _store is not None:
        return _store
    try:
        from .dashdb import DashboardStore
        store = DashboardStore(
            writer_dsn=os.environ["DASH_WRITER_DSN"],
            reader_dsn=os.environ.get("DASH_READER_DSN"),
        )
        store.connect()
        store.ensure_schema()
        _store = store
        return _store
    except (KeyError, Exception) as e:
        logger.error(f"Failed to initialize dashboard store: {e}")
        return None


# ---------------------------------------------------------------------------
# API Key Authentication Middleware (for /v1/ programmatic endpoints)
# ---------------------------------------------------------------------------

@app.before_request
def _api_key_auth_middleware():
    """Authenticate /v1/ API requests via Bearer token against Aurora.

    Extracts the API key from the Authorization header, validates it
    against the api_keys table in Aurora PostgreSQL, and sets
    request.api_tenant_id and request.api_key_id for downstream use.

    Non-/v1/ routes (browser dashboard) are untouched.
    """
    if not request.path.startswith("/v1/"):
        return None

    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        return jsonify({"error": "API key required"}), 401

    key_value = auth_header[7:].strip()
    if not key_value:
        return jsonify({"error": "API key required"}), 401

    store = _get_store()
    if store is None:
        logger.error("Aurora unavailable during API key validation")
        return jsonify({"error": "Service unavailable"}), 503

    result = store.validate_api_key_detailed(key_value)

    if not result["valid"]:
        reason = result.get("reason", "invalid")
        logger.warning(
            "API key auth failed: reason=%s, path=%s, ip=%s",
            reason, request.path,
            request.headers.get("X-Forwarded-For", request.remote_addr),
        )
        return jsonify({"error": "Invalid or expired API key"}), 401

    request.api_tenant_id = result["tenant_id"]
    request.api_key_id = result["key_id"]
    return None


# ---------------------------------------------------------------------------
# /v1/ Programmatic API Endpoints (API key auth enforced by middleware)
# ---------------------------------------------------------------------------

@app.route("/v1/dashboard/sync", methods=["POST"])
def api_v1_dashboard_sync():
    """Sync pipeline results to dashboard via API key.

    Accepts compliance snapshots, model data, fairness results, pipeline
    stats, and alerts. All data is stored under the tenant_id derived
    from the API key — never from user input.
    """
    tenant_id = request.api_tenant_id
    key_id = request.api_key_id

    if not request.is_json:
        return jsonify({"error": "JSON body required"}), 400

    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Invalid JSON body"}), 400

    store = _get_store()
    if store is None:
        return jsonify({"error": "Service unavailable"}), 503

    synced = []

    billing.record_usage(store, tenant_id, "model_validations")

    try:
        if "compliance" in data:
            store.insert_compliance_snapshot(tenant_id, data["compliance"])
            synced.append("compliance")

        if "models" in data:
            for m in data["models"]:
                store.upsert_model_snapshot(tenant_id, m)
            synced.append("models")

        if "fairness" in data:
            for f_data in data["fairness"]:
                store.insert_fairness_snapshot(tenant_id, f_data)
            synced.append("fairness")

        if "alerts" in data:
            for a in data["alerts"]:
                store.insert_alert(tenant_id, a)
                _notify_alert(store, tenant_id, a)
            synced.append("alerts")

        if "pipeline" in data:
            store.insert_pipeline_stat(tenant_id, data["pipeline"])
            billing.record_usage(store, tenant_id, "pipeline_runs")
            synced.append("pipeline")

    except Exception as exc:
        logger.exception(
            "Sync failed: tenant=%s, api_key_id=%d, error=%s",
            tenant_id, key_id, exc,
        )
        return jsonify({"error": "Sync failed", "synced": synced}), 500

    logger.info(
        "Dashboard sync: tenant=%s, api_key_id=%d, synced=%s",
        tenant_id, key_id, synced,
    )

    return jsonify({
        "ok": True,
        "tenant_id": tenant_id,
        "synced": synced,
    })


@app.route("/v1/keys", methods=["GET"])
def api_v1_list_keys():
    """List API keys for the authenticated tenant."""
    tenant_id = request.api_tenant_id
    store = _get_store()
    if store is None:
        return jsonify({"error": "Service unavailable"}), 503
    keys = store.list_api_keys(tenant_id)
    for k in keys:
        for ts_field in ("created_at", "expires_at", "last_used_at"):
            if hasattr(k.get(ts_field), "isoformat"):
                k[ts_field] = k[ts_field].isoformat()
    return jsonify({"keys": keys})


@app.route("/v1/keys/<int:key_id>/revoke", methods=["POST"])
def api_v1_revoke_key(key_id):
    """Revoke an API key for the authenticated tenant."""
    tenant_id = request.api_tenant_id
    api_key_id = request.api_key_id
    store = _get_store()
    if store is None:
        return jsonify({"error": "Service unavailable"}), 503
    store.revoke_api_key(tenant_id, key_id)
    logger.info(
        "API key revoked: tenant=%s, revoked_key=%d, by_key=%d",
        tenant_id, key_id, api_key_id,
    )
    return jsonify({"ok": True})


@app.route("/api/api-keys")
@require_client_auth
def api_list_api_keys_session():
    """List API keys for the session-authenticated tenant (dashboard use)."""
    store = _get_store()
    if store is None:
        return jsonify({"keys": []})
    keys = store.list_api_keys(g.tenant_id)
    for k in keys:
        for ts_field in ("created_at", "expires_at", "last_used_at"):
            if hasattr(k.get(ts_field), "isoformat"):
                k[ts_field] = k[ts_field].isoformat()
    return jsonify({"keys": keys})


@app.route("/api/api-keys/<int:key_id>/revoke", methods=["POST"])
@require_client_auth
def api_revoke_api_key_session(key_id):
    """Revoke an API key via session auth (dashboard use)."""
    store = _get_store()
    if store is None:
        return jsonify({"error": "Service unavailable"}), 503
    store.revoke_api_key(g.tenant_id, key_id)
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# User-entered data (stored in Aurora client_user_data table)
# ---------------------------------------------------------------------------

_USER_DATA_SCHEMA = """
CREATE TABLE IF NOT EXISTS client_user_data (
    id BIGSERIAL PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    data_type TEXT NOT NULL,
    ref_id TEXT,
    payload TEXT NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
)
"""

_USER_DATA_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_cud_tenant_type ON client_user_data (tenant_id, data_type)",
    "CREATE INDEX IF NOT EXISTS idx_cud_ref ON client_user_data (tenant_id, data_type, ref_id)",
]


def _ensure_user_data_table():
    global _user_table_ready
    if _user_table_ready:
        return
    store = _get_store()
    if store is None:
        return
    try:
        store._write(_USER_DATA_SCHEMA)
        for idx_sql in _USER_DATA_INDEXES:
            store._write(idx_sql)
        _user_table_ready = True
    except Exception as e:
        logger.error("Failed to create client_user_data table: %s", e)


def _get_user_records(data_type, ref_id=None):
    store = _get_store()
    if store is None:
        return []
    _ensure_user_data_table()
    try:
        if ref_id:
            rows = store._read_dicts(
                "SELECT id, data_type, ref_id, payload, created_at, updated_at "
                "FROM client_user_data "
                "WHERE tenant_id = %s AND data_type = %s AND ref_id = %s "
                "ORDER BY created_at DESC",
                (g.tenant_id, data_type, ref_id),
            )
        else:
            rows = store._read_dicts(
                "SELECT id, data_type, ref_id, payload, created_at, updated_at "
                "FROM client_user_data "
                "WHERE tenant_id = %s AND data_type = %s "
                "ORDER BY created_at DESC",
                (g.tenant_id, data_type),
            )
        for r in rows:
            if isinstance(r.get("payload"), str):
                r["payload"] = json.loads(r["payload"])
            for k in ("created_at", "updated_at"):
                if hasattr(r.get(k), "isoformat"):
                    r[k] = r[k].isoformat()
        return rows
    except Exception as e:
        logger.error("Failed to read user records: %s", e)
        return []


def _save_user_record(data_type, ref_id, payload):
    store = _get_store()
    if store is None:
        return None
    _ensure_user_data_table()
    try:
        row = store._write_returning(
            "INSERT INTO client_user_data (tenant_id, data_type, ref_id, payload) "
            "VALUES (%s, %s, %s, %s) RETURNING id",
            (g.tenant_id, data_type, ref_id, json.dumps(payload)),
        )
        if isinstance(row, (list, tuple)):
            return row[0]
        return row
    except Exception as e:
        logger.error("Failed to save user record: %s", e)
        return None


def _delete_user_record(record_id):
    store = _get_store()
    if store is None:
        return False
    _ensure_user_data_table()
    try:
        store._write(
            "DELETE FROM client_user_data WHERE id = %s AND tenant_id = %s",
            (record_id, g.tenant_id),
        )
        return True
    except Exception as e:
        logger.error("Failed to delete user record: %s", e)
        return False


# ---------------------------------------------------------------------------
# Generated reports persistence (stored in Aurora generated_reports table)
# ---------------------------------------------------------------------------

_REPORTS_SCHEMA = """
CREATE TABLE IF NOT EXISTS generated_reports (
    id BIGSERIAL PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    report_type TEXT NOT NULL,
    title TEXT NOT NULL,
    model_id TEXT,
    content_md TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    section_count INTEGER NOT NULL DEFAULT 0,
    generated_by TEXT NOT NULL DEFAULT 'system',
    metadata TEXT NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
)
"""

_REPORTS_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_gr_tenant ON generated_reports (tenant_id, created_at DESC)",
    "CREATE INDEX IF NOT EXISTS idx_gr_type ON generated_reports (tenant_id, report_type)",
]

_reports_table_ready = False


def _ensure_reports_table():
    global _reports_table_ready
    if _reports_table_ready:
        return
    store = _get_store()
    if store is None:
        return
    try:
        store._write(_REPORTS_SCHEMA)
        for idx_sql in _REPORTS_INDEXES:
            store._write(idx_sql)
        _reports_table_ready = True
    except Exception as e:
        logger.error("Failed to create generated_reports table: %s", e)


def _save_report(report_type, title, content_md, section_count,
                 model_id=None, generated_by="system", meta=None):
    store = _get_store()
    if store is None:
        return None
    _ensure_reports_table()
    content_hash = hashlib.sha256(content_md.encode()).hexdigest()
    try:
        row = store._write_returning(
            "INSERT INTO generated_reports "
            "(tenant_id, report_type, title, model_id, content_md, "
            " content_hash, section_count, generated_by, metadata) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING id",
            (g.tenant_id, report_type, title, model_id, content_md,
             content_hash, section_count, generated_by,
             json.dumps(meta or {})),
        )
        if isinstance(row, (list, tuple)):
            return row[0]
        return row
    except Exception as e:
        logger.error("Failed to save report: %s", e)
        return None


def _get_report_history(limit=50):
    store = _get_store()
    if store is None:
        return []
    _ensure_reports_table()
    try:
        rows = store._read_dicts(
            "SELECT id, report_type, title, model_id, content_hash, "
            "section_count, generated_by, metadata, created_at "
            "FROM generated_reports "
            "WHERE tenant_id = %s ORDER BY created_at DESC LIMIT %s",
            (g.tenant_id, limit),
        )
        for r in rows:
            if isinstance(r.get("metadata"), str):
                r["metadata"] = json.loads(r["metadata"])
            if hasattr(r.get("created_at"), "isoformat"):
                r["created_at"] = r["created_at"].isoformat()
        return rows
    except Exception as e:
        logger.error("Failed to read report history: %s", e)
        return []


def _get_report_by_id(report_id):
    store = _get_store()
    if store is None:
        return None
    _ensure_reports_table()
    try:
        rows = store._read_dicts(
            "SELECT id, report_type, title, model_id, content_md, "
            "content_hash, section_count, generated_by, metadata, created_at "
            "FROM generated_reports "
            "WHERE id = %s AND tenant_id = %s",
            (report_id, g.tenant_id),
        )
        if not rows:
            return None
        r = rows[0]
        if isinstance(r.get("metadata"), str):
            r["metadata"] = json.loads(r["metadata"])
        if hasattr(r.get("created_at"), "isoformat"):
            r["created_at"] = r["created_at"].isoformat()
        return r
    except Exception as e:
        logger.error("Failed to read report: %s", e)
        return None


def _delete_report(report_id):
    store = _get_store()
    if store is None:
        return False
    _ensure_reports_table()
    try:
        store._write(
            "DELETE FROM generated_reports WHERE id = %s AND tenant_id = %s",
            (report_id, g.tenant_id),
        )
        return True
    except Exception as e:
        logger.error("Failed to delete report: %s", e)
        return False


# ---------------------------------------------------------------------------
# Empty data fallbacks (used when store unavailable or feature not configured)
# ---------------------------------------------------------------------------

def _demo_compliance():
    return {}


def _demo_compliance_history():
    return []


def _demo_models():
    return []


def _demo_fairness():
    return []


def _demo_regulatory_calendar():
    return {"deadlines": [], "milestones": [], "upcoming": []}


def _demo_certifications():
    return []


def _demo_pipeline_runs():
    return []


def _demo_alerts():
    return []


def _demo_attestations():
    return []


def _demo_exceptions():
    return {
        "total_exceptions": 0, "active_exceptions": 0,
        "pending_approval": 0, "approved": 0,
        "escalation_alerts": 0, "critical_escalations": 0,
        "exceptions": [], "escalations": [],
    }


def _demo_regulatory_changes():
    return []


def _apply_profile(snapshot: dict, profile_config: dict) -> dict:
    """Re-score a compliance snapshot using a custom weight profile."""
    reg_weights = profile_config.get("regulation_weights", {})
    reg_enabled = profile_config.get("regulation_enabled", {})
    bonus_weights = profile_config.get("bonus_weights", {})
    deductions = profile_config.get("finding_deductions", {"critical": 8.0, "warning": 3.0})
    crit_ded = float(deductions.get("critical", 8.0))
    warn_ded = float(deductions.get("warning", 3.0))

    total_deductions = 0.0
    scored_breakdowns = []
    for bd in (snapshot.get("breakdowns") or []):
        reg = bd.get("regulation", "")
        if not reg_enabled.get(reg, True):
            scored_breakdowns.append({**bd, "enabled": False, "weighted_deduction": 0})
            continue
        weight = float(reg_weights.get(reg, 1.0))
        crit = int(bd.get("critical_count", 0))
        warn = int(bd.get("warning_count", 0))
        raw = crit * crit_ded + warn * warn_ded
        weighted = raw * weight
        total_deductions += weighted
        scored_breakdowns.append({**bd, "enabled": True, "weight": weight, "weighted_deduction": round(weighted, 2)})

    total_bonuses = 0.0
    scored_bonuses = {}
    for name, earned in (snapshot.get("bonuses") or {}).items():
        multiplier = float(bonus_weights.get(name, 1.0))
        adjusted = float(earned) * multiplier
        total_bonuses += adjusted
        scored_bonuses[name] = round(adjusted, 2)

    raw_score = 100.0 - total_deductions + total_bonuses
    score = max(0.0, min(100.0, raw_score))

    if score >= 90:
        grade = "A"
    elif score >= 75:
        grade = "B"
    elif score >= 60:
        grade = "C"
    elif score >= 40:
        grade = "D"
    else:
        grade = "F"

    return {
        "score": round(score, 1),
        "grade": grade,
        "breakdowns": scored_breakdowns,
        "bonuses": scored_bonuses,
        "total_deductions": round(total_deductions, 2),
        "total_bonuses": round(total_bonuses, 2),
    }


# ---------------------------------------------------------------------------
# Login Page
# ---------------------------------------------------------------------------

_LOGIN_HTML = """<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Attestant &mdash; Client Login</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{--bg:#f1f5f9;--surface:#ffffff;--border:#e2e8f0;--text-1:#0f172a;--text-2:#64748b;--text-3:#94a3b8;--blue:#3b82f6;--red:#ef4444;--radius:8px}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',system-ui,sans-serif;background:var(--bg);color:var(--text-1);display:flex;align-items:center;justify-content:center;min-height:100vh;-webkit-font-smoothing:antialiased}
.login-card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:40px;width:380px;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,0.06)}
.logo{font-size:20px;font-weight:700;letter-spacing:-0.5px;margin-bottom:4px}
.logo-sub{font-size:12px;color:var(--text-3);margin-bottom:32px}
.field{margin-bottom:16px;text-align:left}
label{display:block;font-size:12px;font-weight:500;color:var(--text-2);margin-bottom:6px}
input{width:100%;height:40px;padding:0 12px;font-size:13px;font-family:inherit;background:var(--bg);border:1px solid var(--border);border-radius:var(--radius);color:var(--text-1);outline:none;transition:border-color 0.15s}
input:focus{border-color:var(--blue)}
button{width:100%;height:40px;margin-top:8px;font-size:13px;font-weight:600;font-family:inherit;background:var(--blue);color:#fff;border:none;border-radius:var(--radius);cursor:pointer;transition:opacity 0.15s}
button:hover{opacity:0.9}
.btn-sso{background:#1e293b;margin-top:12px}
.btn-google{background:#ffffff;color:#3c4043;border:1px solid var(--border);margin-top:12px;display:flex;align-items:center;justify-content:center;gap:10px;font-weight:500;transition:background 0.15s,box-shadow 0.15s}
.btn-google:hover{background:#f8f9fa;box-shadow:0 1px 3px rgba(0,0,0,0.08);opacity:1}
.btn-google svg{flex-shrink:0}
.divider{display:flex;align-items:center;margin:20px 0;color:var(--text-3);font-size:11px}
.divider::before,.divider::after{content:'';flex:1;border-top:1px solid var(--border)}
.divider span{padding:0 12px}
.error{color:var(--red);font-size:12px;margin-top:12px;display:none}
.setup-info{font-size:11px;color:var(--text-3);margin-top:20px;line-height:1.5}
</style>
</head><body>
<div class="login-card">
<div class="logo">Attestant</div>
<div class="logo-sub">Compliance Dashboard</div>
{% if google_login_url %}
<button class="btn-google" onclick="window.location='{{ google_login_url }}'">
<svg width="18" height="18" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59a14.5 14.5 0 0 1 0-9.18l-7.98-6.19a24.0 24.0 0 0 0 0 21.56l7.98-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
Sign in with Google
</button>
{% endif %}
{% if sso_url %}
<button class="btn-sso" onclick="window.location='{{ sso_url }}'">Sign in with SSO</button>
{% endif %}
{% if google_login_url or sso_url %}
<div class="divider"><span>or</span></div>
{% endif %}
<form method="POST" action="{{ request.script_root }}/login">
<div class="field"><label for="email">Email</label>
<input type="email" id="email" name="email" placeholder="you@yourbank.com" required autofocus></div>
<div class="field"><label for="password">Password</label>
<input type="password" id="password" name="password" placeholder="Enter password" required></div>
<button type="submit">Sign In</button>
</form>
<div class="divider"><span>or sign in with API key</span></div>
<form method="POST" action="{{ request.script_root }}/login/apikey">
<div class="field"><label for="api_key">API Key</label>
<input type="password" id="api_key" name="api_key" placeholder="pvt_live_..." required></div>
<button type="submit" style="background:#1e293b">Sign In with API Key</button>
</form>
<div class="error" id="err">{{ error_msg or 'Invalid credentials.' }}</div>
{% if first_setup %}
<div class="setup-info">No users configured yet. The first login will create an admin account.</div>
{% endif %}
</div>
<script>
if (location.search.includes('error=1')) document.getElementById('err').style.display='block';
if (location.search.includes('error=locked')) {
    var e = document.getElementById('err');
    e.textContent = 'Too many failed attempts. Try again later.';
    e.style.display = 'block';
}
if (location.search.includes('error=expired')) {
    var e = document.getElementById('err');
    e.textContent = 'Session expired. Please sign in again.';
    e.style.display = 'block';
}
if (location.search.includes('error=google')) {
    var e = document.getElementById('err');
    e.textContent = 'Google sign-in failed. Please try again.';
    e.style.display = 'block';
}
if (location.search.includes('error=noauth')) {
    var e = document.getElementById('err');
    e.textContent = 'Your Google account is not authorized for this tenant.';
    e.style.display = 'block';
}
if (location.search.includes('error=apikey')) {
    var e = document.getElementById('err');
    e.textContent = 'Invalid API key or key does not match this tenant.';
    e.style.display = 'block';
}
</script>
</body></html>"""


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        user = _get_current_user()
        if user:
            return redirect("/")

        store = _get_store()
        first_setup = False
        if store is not None:
            first_setup = store.count_users(_DEFAULT_TENANT) == 0

        sso_url = ""
        if COGNITO_DOMAIN and COGNITO_CLIENT_ID:
            callback = COGNITO_CALLBACK_URL or (request.host_url.rstrip("/") + request.script_root + "/auth/callback")
            sso_url = (
                f"https://{COGNITO_DOMAIN}/oauth2/authorize?"
                f"client_id={COGNITO_CLIENT_ID}&response_type=code&"
                f"scope=openid+email+profile&redirect_uri={callback}"
            )

        google_login_url = ""
        if GOOGLE_CLIENT_ID:
            google_login_url = request.script_root + "/auth/google/login"

        return render_template_string(
            _LOGIN_HTML,
            sso_url=sso_url,
            google_login_url=google_login_url,
            first_setup=first_setup,
            error_msg=None,
        )

    email = (request.form.get("email") or "").strip().lower()
    password = request.form.get("password", "")
    client_ip = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown")
    if "," in client_ip:
        client_ip = client_ip.split(",")[0].strip()

    if _is_rate_limited(client_ip):
        return redirect("/login?error=locked")

    if not email or not password:
        return redirect("/login?error=1")

    if not _validate_email(email):
        _record_auth_failure(client_ip)
        return redirect("/login?error=1")

    store = _get_store()

    if store is not None and store.count_users(_DEFAULT_TENANT) == 0:
        pw_hash = _hash_password(password)
        store.create_user(
            tenant_id=_DEFAULT_TENANT,
            email=email,
            password_hash=pw_hash,
            display_name=email.split("@")[0].replace(".", " ").title(),
            role="admin",
        )
        logger.info("First user created: %s as admin for tenant %s", email, _DEFAULT_TENANT)

    if store is None:
        return redirect("/login?error=1")

    user = store.get_user_by_email(_DEFAULT_TENANT, email)
    if not user or not user.get("password_hash"):
        bcrypt.checkpw(b"x", b"$2b$12$invalid.hash.padding.0000000000000000000000000000000000")
        _record_auth_failure(client_ip)
        return redirect("/login?error=1")

    is_valid, needs_rehash = _check_password(password, user["password_hash"])
    if not is_valid:
        _record_auth_failure(client_ip)
        return redirect("/login?error=1")
    if needs_rehash:
        store.update_password_hash(_DEFAULT_TENANT, email, _hash_password(password))

    store.record_login(_DEFAULT_TENANT, email)
    token = _make_session_token(email, user["role"])
    resp = make_response(redirect("/"))
    resp.set_cookie(
        "attestant_client_session", token,
        httponly=True, samesite="Lax",
        secure=request.scheme == "https",
        max_age=86400,
    )
    return resp


@app.route("/logout")
def logout():
    resp = make_response(redirect("/login"))
    resp.delete_cookie("attestant_client_session")
    return resp


_VALID_PLANS = {"starter", "professional", "growth", "enterprise"}
_VALID_INTERVALS = {"monthly", "annual"}


@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "GET":
        error = request.args.get("error", "")
        return render_template("signup.html", error=error)

    client_ip = request.headers.get("X-Forwarded-For", request.remote_addr or "")
    if "," in client_ip:
        client_ip = client_ip.split(",")[0].strip()
    if _is_rate_limited(client_ip):
        return redirect("/signup?error=Too+many+attempts.+Please+try+again+later.")

    email = request.form.get("email", "").strip().lower()
    password = request.form.get("password", "")
    confirm = request.form.get("confirm_password", "")
    company = request.form.get("company_name", "").strip()
    plan = request.form.get("plan", "starter")
    interval = request.form.get("interval", "monthly")

    if not re.match(r"^[^@]+@[^@]+\.[^@]+$", email):
        return redirect("/signup?error=Invalid+email+address")
    if len(password) < 8:
        return redirect("/signup?error=Password+must+be+at+least+8+characters")
    if password != confirm:
        return redirect("/signup?error=Passwords+do+not+match")
    if not company:
        return redirect("/signup?error=Company+name+is+required")
    if len(company) > 255:
        return redirect("/signup?error=Company+name+too+long")
    if plan not in _VALID_PLANS:
        return redirect("/signup?error=Invalid+plan+selected")
    if interval not in _VALID_INTERVALS:
        interval = "monthly"

    store = _get_store()
    if store is None:
        return redirect("/signup?error=Service+unavailable")

    slug = re.sub(r"[^a-z0-9-]", "", re.sub(r"\s+", "-", company.lower()))
    tenant_id = slug or "tenant"
    if store.get_tenant(tenant_id):
        tenant_id = f"{slug}-{secrets.token_hex(3)}"

    tenant_id_created = None
    try:
        store.create_tenant(tenant_id, company, tier=plan)
        tenant_id_created = tenant_id
        store.upsert_subscription(tenant_id, plan=plan, status="active")
        pw_hash = _hash_password(password)
        user_id = store.create_user(tenant_id, email, pw_hash, company, role="admin")
        if user_id is None:
            raise ValueError("Email already registered")
        api_key_result = store.create_api_key(tenant_id, "Default", created_by=email)
        key_value = api_key_result[0] if api_key_result else ""
    except Exception as exc:
        logger.error("Signup failed for %s: %s", email, exc)
        if tenant_id_created:
            try:
                store._write("DELETE FROM tenants WHERE tenant_id = %s", (tenant_id_created,))
            except Exception as cleanup_exc:
                logger.warning("Failed to cleanup orphaned tenant %s: %s", tenant_id_created, cleanup_exc)
        _record_auth_failure(client_ip)
        msg = "Email+already+registered" if "already registered" in str(exc) else "Signup+failed.+Please+try+again."
        return redirect(f"/signup?error={msg}")

    email_service.send_welcome_email(email, company, key_value)

    stripe_key = os.environ.get("STRIPE_SECRET_KEY", "")
    if plan == "starter" or not stripe_key:
        token = _make_session_token(email, "admin", tenant_id)
        resp = make_response(redirect("/"))
        resp.set_cookie(
            "attestant_client_session", token,
            httponly=True, samesite="Lax", max_age=86400,
            secure=request.is_secure,
        )
        return resp

    success_url = request.url_root.rstrip("/") + request.script_root + "/signup/success" + f"?tenant_id={tenant_id}&email={email}"
    cancel_url = request.url_root.rstrip("/") + request.script_root + "/signup?error=Payment+cancelled"
    checkout_url = billing.get_checkout_url(
        store, tenant_id, plan, interval, email, company, success_url, cancel_url
    )
    return redirect(checkout_url)


@app.route("/signup/success")
def signup_success():
    tenant_id = request.args.get("tenant_id", "")
    email = request.args.get("email", "")
    if not tenant_id or not email:
        return redirect("/login")
    store = _get_store()
    if store is None:
        return redirect("/login")
    user = store.get_user_by_email(tenant_id, email)
    if not user:
        logger.warning("signup_success: no user %s in tenant %s — possible hijack attempt", email, tenant_id)
        return redirect("/login")
    store.upsert_subscription(tenant_id, status="active")
    token = _make_session_token(email, user.get("role", "admin"), tenant_id)
    resp = make_response(redirect("/"))
    resp.set_cookie(
        "attestant_client_session", token,
        httponly=True, samesite="Lax", max_age=86400,
        secure=request.is_secure,
    )
    return resp


@app.route("/billing/webhook", methods=["POST"])
def billing_webhook():
    sig_header = request.headers.get("Stripe-Signature", "")
    store = _get_store()
    if store is None:
        return jsonify({"error": "Service unavailable"}), 503
    result = billing.handle_webhook(request.get_data(), sig_header, store)
    if "error" in result:
        return jsonify(result), 400
    return jsonify(result), 200


@app.route("/billing/portal")
@require_client_auth
def billing_portal():
    return_url = request.url_root.rstrip("/") + request.script_root + "/"
    store = _get_store()
    if store is None:
        return redirect(return_url)
    portal_url = billing.get_billing_portal_url(store, g.tenant_id, return_url)
    return redirect(portal_url)


@app.route("/api/billing/plan")
@require_client_auth
def api_billing_plan():
    store = _get_store()
    if store is None:
        return jsonify({"plan": "metered", "status": "active", "usage": {}, "period_end": None})
    sub = store.get_subscription(g.tenant_id)
    plan = sub["plan"] if sub else "metered"
    period = billing.current_billing_period()
    usage = store.get_usage_this_period(g.tenant_id, period)
    period_end = sub.get("current_period_end") if sub else None
    return jsonify({
        "plan": plan,
        "status": sub.get("status", "active") if sub else "active",
        "usage": usage,
        "period_end": period_end.isoformat() if period_end else None,
    })


@app.route("/api/billing/estimate")
@require_client_auth
def api_billing_estimate():
    store = _get_store()
    if store is None:
        return jsonify(billing.estimate_monthly_bill(None, g.tenant_id) if False else {
            "base": {"label": "Base fee", "qty": None, "cost": 199.0},
            "model_validations": {"label": "Model Validations", "qty": 0, "cost": 0.0, "rate": "$10.00/validation"},
            "pipeline_runs":     {"label": "Pipeline Runs",     "qty": 0, "cost": 0.0, "rate": "$2.00/run"},
            "storage_gb":        {"label": "Storage",           "qty": 0, "cost": 0.0, "rate": "$0.25/GB"},
            "egress_gb":         {"label": "Egress",            "qty": 0, "cost": 0.0, "rate": "$0.20/GB"},
            "total": 199.0,
        })
    return jsonify(billing.estimate_monthly_bill(store, g.tenant_id))


@app.route("/api/billing/monthly-breakdown")
@require_client_auth
@require_role("admin")
def api_billing_monthly_breakdown():
    store = _get_store()
    if store is None:
        return jsonify({"months": []}), 503
    months = store.get_usage_by_month(g.tenant_id, num_months=12)
    return jsonify({"months": months})


@app.route("/api/notifications/unread-count")
@require_client_auth
def api_notifications_unread_count():
    store = _get_store()
    if store is None:
        return jsonify({"count": 0})
    alerts = store.get_alerts(g.tenant_id, unresolved_only=True, limit=100)
    return jsonify({"count": len(alerts)})


@app.route("/login/apikey", methods=["POST"])
def login_apikey():
    """Authenticate via Attestant API key.

    Validates the key against the Attestant API server. If the key's
    tenant_id matches this dashboard's DASH_TENANT, the user is logged
    in as admin. If no dashboard user exists for the key's tenant, one
    is auto-created.
    """
    import urllib.request
    import urllib.error

    api_key = (request.form.get("api_key") or "").strip()
    if not api_key:
        return redirect("/login?error=apikey")

    client_ip = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown")
    if "," in client_ip:
        client_ip = client_ip.split(",")[0].strip()

    if _is_rate_limited(client_ip):
        return redirect("/login?error=locked")

    try:
        validate_url = f"{ATTESTANT_API_URL}/api/v1/auth/validate"
        req = urllib.request.Request(
            validate_url,
            method="POST",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
        )
        with urllib.request.urlopen(req, timeout=5.0) as resp:
            data = json.loads(resp.read().decode("utf-8"))

        key_tenant = data.get("tenant_id", "")
        if key_tenant != _DEFAULT_TENANT:
            logger.warning(
                "API key tenant mismatch: key=%s, dashboard=%s",
                key_tenant, _DEFAULT_TENANT,
            )
            _record_auth_failure(client_ip)
            return redirect("/login?error=apikey")

        # Key is valid and matches this tenant. Find or create a dashboard user.
        email = f"apikey-{key_tenant}@attestant.ai"
        store = _get_store()
        if store is not None:
            user = store.get_user_by_email(_DEFAULT_TENANT, email)
            if not user:
                store.create_user(
                    tenant_id=_DEFAULT_TENANT,
                    email=email,
                    password_hash=None,
                    display_name=f"{data.get('tier', 'professional').title()} API Key",
                    role="admin",
                )
                logger.info("Auto-created API key user for tenant %s", _DEFAULT_TENANT)
            store.record_login(_DEFAULT_TENANT, email)

        token = _make_session_token(email, "admin")
        resp = make_response(redirect("/"))
        resp.set_cookie(
            "attestant_client_session", token,
            httponly=True, samesite="Lax",
            secure=request.scheme == "https",
            max_age=86400,
        )
        return resp

    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            _record_auth_failure(client_ip)
            return redirect("/login?error=apikey")
        logger.exception("API key validation HTTP error: %s", exc)
        _record_auth_failure(client_ip)
        return redirect("/login?error=apikey")
    except urllib.error.URLError as exc:
        logger.exception("API key validation network error: %s", exc)
        return redirect("/login?error=apikey")
    except Exception:
        logger.exception("API key login failed")
        return redirect("/login?error=apikey")


@app.route("/auth/callback")
def sso_callback():
    """Handle Cognito OAuth2 callback."""
    code = request.args.get("code")
    if not code:
        return redirect("/login?error=1")

    if not COGNITO_DOMAIN or not COGNITO_CLIENT_ID:
        return redirect("/login?error=1")

    import urllib.request
    import urllib.parse

    callback = COGNITO_CALLBACK_URL or (request.host_url.rstrip("/") + "/auth/callback")
    token_url = f"https://{COGNITO_DOMAIN}/oauth2/token"
    data = urllib.parse.urlencode({
        "grant_type": "authorization_code",
        "client_id": COGNITO_CLIENT_ID,
        "code": code,
        "redirect_uri": callback,
    }).encode()

    try:
        req = urllib.request.Request(
            token_url, data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            token_data = json.loads(resp.read().decode())

        id_token = token_data.get("id_token", "")
        parts = id_token.split(".")
        if len(parts) != 3:
            return redirect("/login?error=1")

        import base64
        payload = parts[1] + "=" * (4 - len(parts[1]) % 4)
        claims = json.loads(base64.urlsafe_b64decode(payload))

        email = claims.get("email", "").lower()
        if not email:
            return redirect("/login?error=1")

        store = _get_store()
        if store is None:
            return redirect("/login?error=1")

        user = store.get_user_by_email(_DEFAULT_TENANT, email)
        if not user:
            logger.warning("SSO login denied: %s not in allowlist for %s", email, _DEFAULT_TENANT)
            return redirect("/login?error=1")

        store.record_login(_DEFAULT_TENANT, email)
        token = _make_session_token(email, user["role"])
        resp = make_response(redirect("/"))
        resp.set_cookie(
            "attestant_client_session", token,
            httponly=True, samesite="Lax",
            secure=request.scheme == "https",
            max_age=86400,
        )
        return resp

    except Exception:
        logger.exception("SSO callback failed")
        return redirect("/login?error=1")


# ---------------------------------------------------------------------------
# Google OAuth2
# ---------------------------------------------------------------------------

@app.route("/auth/google/login")
def google_login():
    """Redirect to Google's OAuth2 authorization endpoint."""
    if not GOOGLE_CLIENT_ID:
        return redirect("/login?error=1")

    import urllib.parse

    state = secrets.token_urlsafe(32)
    resp = make_response(redirect(
        "https://accounts.google.com/o/oauth2/v2/auth?"
        + urllib.parse.urlencode({
            "client_id": GOOGLE_CLIENT_ID,
            "redirect_uri": _google_redirect_uri(),
            "response_type": "code",
            "scope": "openid email profile",
            "access_type": "online",
            "state": state,
        })
    ))
    resp.set_cookie(
        "google_oauth_state", state,
        httponly=True, samesite="Lax",
        secure=request.scheme == "https",
        max_age=600,
    )
    return resp


@app.route("/auth/google/callback")
def google_callback():
    """Handle the Google OAuth2 callback.

    Exchanges the authorization code for tokens, fetches the user's email
    from Google's userinfo endpoint, then creates a session if the user
    is in the tenant's allowlist (or auto-creates an admin if this is the
    first user for the tenant).
    """
    code = request.args.get("code")
    state = request.args.get("state")
    error = request.args.get("error")

    if error:
        logger.warning("Google OAuth error response: %s", error)
        return redirect("/login?error=google")

    if not code:
        return redirect("/login?error=google")

    if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET:
        return redirect("/login?error=google")

    expected_state = request.cookies.get("google_oauth_state")
    if not expected_state or not state or not hmac.compare_digest(state, expected_state):
        logger.warning("Google OAuth CSRF state mismatch")
        return redirect("/login?error=google")

    import urllib.error
    import urllib.parse
    import urllib.request

    try:
        token_data = urllib.parse.urlencode({
            "code": code,
            "client_id": GOOGLE_CLIENT_ID,
            "client_secret": GOOGLE_CLIENT_SECRET,
            "redirect_uri": _google_redirect_uri(),
            "grant_type": "authorization_code",
        }).encode()

        token_req = urllib.request.Request(
            "https://oauth2.googleapis.com/token",
            data=token_data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        with urllib.request.urlopen(token_req, timeout=10) as token_resp:
            tokens = json.loads(token_resp.read().decode())

        access_token = tokens.get("access_token")
        if not access_token:
            logger.error("Google OAuth: no access_token in token response")
            return redirect("/login?error=google")

        userinfo_req = urllib.request.Request(
            "https://www.googleapis.com/oauth2/v3/userinfo",
            headers={"Authorization": f"Bearer {access_token}"},
        )
        with urllib.request.urlopen(userinfo_req, timeout=10) as ui_resp:
            userinfo = json.loads(ui_resp.read().decode())

        email = (userinfo.get("email") or "").strip().lower()
        if not email:
            logger.error("Google OAuth: no email in userinfo response")
            return redirect("/login?error=google")

        if not userinfo.get("email_verified", False):
            logger.warning("Google OAuth: email %s not verified", email)
            return redirect("/login?error=google")

        store = _get_store()
        if store is None:
            return redirect("/login?error=google")

        if store.count_users(_DEFAULT_TENANT) == 0:
            display_name = userinfo.get("name") or email.split("@")[0].replace(".", " ").title()
            store.create_user(
                tenant_id=_DEFAULT_TENANT,
                email=email,
                password_hash=None,
                display_name=display_name,
                role="admin",
            )
            logger.info("First user created via Google OAuth: %s as admin for tenant %s", email, _DEFAULT_TENANT)

        user = store.get_user_by_email(_DEFAULT_TENANT, email)
        if not user:
            logger.warning("Google OAuth login denied: %s not in allowlist for %s", email, _DEFAULT_TENANT)
            return redirect("/login?error=noauth")

        store.record_login(_DEFAULT_TENANT, email)
        token = _make_session_token(email, user["role"])
        resp = make_response(redirect("/"))
        resp.set_cookie(
            "attestant_client_session", token,
            httponly=True, samesite="Lax",
            secure=request.scheme == "https",
            max_age=86400,
        )
        resp.delete_cookie("google_oauth_state")
        return resp

    except urllib.error.URLError as e:
        logger.exception("Google OAuth network error: %s", e)
        return redirect("/login?error=google")
    except (json.JSONDecodeError, KeyError, ValueError) as e:
        logger.exception("Google OAuth response parsing error: %s", e)
        return redirect("/login?error=google")
    except Exception:
        logger.exception("Google OAuth callback failed")
        return redirect("/login?error=google")


# ---------------------------------------------------------------------------
# User Management API (admin/manager only)
# ---------------------------------------------------------------------------

@app.route("/api/users")
@require_client_auth
@require_permission("manage_users")
def api_users():
    store = _get_store()
    if store is None:
        return jsonify([])
    users = store.get_users(g.tenant_id)
    for u in users:
        u.pop("password_hash", None)
    return jsonify(users)


@app.route("/api/users", methods=["POST"])
@require_client_auth
@require_permission("manage_users")
def api_create_user():
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    data = request.json or {}
    email = (data.get("email") or "").strip().lower()
    role = data.get("role", "analyst")
    display_name = data.get("display_name", "")
    password = data.get("password", "")

    if not email or not _validate_email(email):
        return jsonify({"error": "Invalid email address"}), 400

    if role not in VALID_ROLES:
        return jsonify({"error": f"Invalid role. Must be one of: {', '.join(VALID_ROLES)}"}), 400

    current = request.current_user
    if role == "admin" and current["role"] != "admin":
        return jsonify({"error": "Only admins can create admin users"}), 403

    pw_hash = _hash_password(password) if password else None

    user_id = store.create_user(
        tenant_id=g.tenant_id,
        email=email,
        password_hash=pw_hash,
        display_name=display_name or email.split("@")[0].replace(".", " ").title(),
        role=role,
        invited_by=current["email"],
    )
    if user_id is None:
        return jsonify({"error": "User already exists"}), 409

    store.initialize_user_permissions(g.tenant_id, user_id, role)

    return jsonify({"id": user_id, "email": email, "role": role}), 201


@app.route("/api/users/<int:user_id>/role", methods=["PUT"])
@require_client_auth
@require_role("admin")
def api_update_user_role(user_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    data = request.json or {}
    role = data.get("role")
    if role not in VALID_ROLES:
        return jsonify({"error": f"Invalid role. Must be one of: {', '.join(VALID_ROLES)}"}), 400

    if role != "admin":
        users = store.get_users(g.tenant_id)
        target = next((u for u in users if u["id"] == user_id), None)
        if target and target.get("role") == "admin":
            active_admin_count = sum(
                1 for u in users
                if u.get("role") == "admin" and u.get("active", True)
            )
            if active_admin_count <= 1:
                return jsonify({"error": "Cannot demote the last admin for this tenant"}), 400

    store.update_user_role(g.tenant_id, user_id, role)
    store.delete_user_permissions(g.tenant_id, user_id)
    store.initialize_user_permissions(g.tenant_id, user_id, role)
    return jsonify({"ok": True})


@app.route("/api/users/<int:user_id>", methods=["DELETE"])
@require_client_auth
@require_role("admin")
def api_deactivate_user(user_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    users = store.get_users(g.tenant_id)
    target = next((u for u in users if u["id"] == user_id), None)
    if target and target.get("role") == "admin":
        active_admin_count = sum(
            1 for u in users
            if u.get("role") == "admin" and u.get("active", True)
        )
        if active_admin_count <= 1:
            return jsonify({"error": "Cannot remove the last admin for this tenant"}), 400

    store.deactivate_user(g.tenant_id, user_id)
    return jsonify({"ok": True})


@app.route("/api/users/<int:user_id>/reactivate", methods=["POST"])
@require_client_auth
@require_role("admin")
def api_reactivate_user(user_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    store.reactivate_user(g.tenant_id, user_id)
    return jsonify({"ok": True})


@app.route("/api/me")
@require_client_auth
def api_me():
    return jsonify(request.current_user)


@app.route("/api/me/password", methods=["PUT"])
@require_client_auth
def api_change_password():
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    data = request.json or {}
    current_password = data.get("current_password", "")
    new_password = data.get("new_password", "")

    if not current_password:
        return jsonify({"error": "Current password is required"}), 400

    if len(new_password) < 12:
        return jsonify({"error": "Password must be at least 12 characters"}), 400

    user = store.get_user_by_email(g.tenant_id, request.current_user["email"])
    if not user:
        return jsonify({"error": "User not found"}), 404

    if not user.get("password_hash") or not _check_password(current_password, user["password_hash"]):
        return jsonify({"error": "Current password is incorrect"}), 403

    pw_hash = _hash_password(new_password)
    store.update_user_password(g.tenant_id, user["id"], pw_hash)
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------
# Permission Management API
# ---------------------------------------------------------------------------

@app.route("/api/me/permissions")
@require_client_auth
def api_my_permissions():
    user = request.current_user
    perms = _get_effective_permissions(g.tenant_id, user["email"], user["role"])
    return jsonify(perms)


@app.route("/api/users/<int:user_id>/permissions")
@require_client_auth
@require_role("admin")
def api_get_user_permissions(user_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500
    perms = store.get_user_permissions(g.tenant_id, user_id)
    if not perms:
        users = store.get_users(g.tenant_id)
        target = next((u for u in users if u["id"] == user_id), None)
        if target:
            perms = ROLE_DEFAULTS.get(target["role"], ROLE_DEFAULTS["analyst"])
        else:
            return jsonify({"error": "User not found"}), 404
    return jsonify(perms)


@app.route("/api/users/<int:user_id>/permissions", methods=["PUT"])
@require_client_auth
@require_role("admin")
def api_update_user_permissions(user_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    data = request.json or {}
    permissions = data.get("permissions", {})

    if not isinstance(permissions, dict):
        return jsonify({"error": "permissions must be a dict"}), 400

    for key in permissions:
        if key not in ALL_PERMISSIONS:
            return jsonify({"error": f"Unknown permission: {key}"}), 400

    users = store.get_users(g.tenant_id)
    target = next((u for u in users if u["id"] == user_id), None)
    if not target:
        return jsonify({"error": "User not found"}), 404

    current_user = request.current_user
    current_user_row = store.get_user_by_email(g.tenant_id, current_user["email"])

    if current_user_row and current_user_row["id"] == user_id:
        if "manage_permissions" in permissions and not permissions["manage_permissions"]:
            return jsonify({"error": "Cannot remove manage_permissions from yourself"}), 400

    if "manage_permissions" in permissions and not permissions["manage_permissions"]:
        admins_with_perm = 0
        for u in users:
            if u["id"] == user_id:
                continue
            if not u.get("active", True):
                continue
            if u["role"] == "admin":
                u_perms = store.get_user_permissions(g.tenant_id, u["id"])
                has_perm = u_perms.get("manage_permissions", True) if u_perms else True
                if has_perm:
                    admins_with_perm += 1
        if admins_with_perm == 0:
            return jsonify({"error": "Cannot remove manage_permissions from the last admin with this permission"}), 400

    defaults = ROLE_DEFAULTS.get(target["role"], ROLE_DEFAULTS["analyst"])
    merged = dict(defaults)
    merged.update(permissions)

    store.set_user_permissions_bulk(
        g.tenant_id, user_id, merged,
        granted_by=current_user["email"],
    )
    return jsonify({"ok": True, "permissions": merged})


@app.route("/api/users/<int:user_id>/permissions/reset", methods=["POST"])
@require_client_auth
@require_role("admin")
def api_reset_user_permissions(user_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    users = store.get_users(g.tenant_id)
    target = next((u for u in users if u["id"] == user_id), None)
    if not target:
        return jsonify({"error": "User not found"}), 404

    store.delete_user_permissions(g.tenant_id, user_id)
    store.initialize_user_permissions(g.tenant_id, user_id, target["role"])
    defaults = ROLE_DEFAULTS.get(target["role"], ROLE_DEFAULTS["analyst"])
    return jsonify({"ok": True, "permissions": defaults})


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
@require_client_auth
def index():
    return render_template("client_dashboard.html", tenant_id=g.tenant_id)


@app.route("/health")
def health():
    return jsonify({"status": "healthy", "tenant": _DEFAULT_TENANT})


@app.route("/api/tenant-config")
@require_client_auth
def api_tenant_config():
    store = _get_store()
    if store is None:
        return jsonify({
            "tenant_id": g.tenant_id,
            "applicable_regulations": [],
            "jurisdictions": [],
            "state": "",
            "country": "US",
        })
    config = store.get_tenant_config(g.tenant_id)
    config["tenant_id"] = g.tenant_id
    return jsonify(config)


@app.route("/api/compliance")
@require_client_auth
@require_permission("view_compliance")
def api_compliance():
    store = _get_store()
    if store is None:
        return jsonify(_demo_compliance())
    data = store.get_latest_compliance(g.tenant_id)
    return jsonify(data or {})


@app.route("/api/compliance/history")
@require_client_auth
@require_permission("view_compliance")
def api_compliance_history():
    store = _get_store()
    if store is None:
        return jsonify(_demo_compliance_history())
    data = store.get_compliance_history(g.tenant_id, limit=30)
    return jsonify(data)


@app.route("/api/score-profiles")
@require_client_auth
@require_permission("view_compliance")
def api_score_profiles_list():
    store = _get_store()
    if store is None:
        return jsonify([])
    profiles = store.list_score_profiles(g.tenant_id)
    return jsonify(profiles)


@app.route("/api/score-profiles", methods=["POST"])
@require_client_auth
@require_permission("manage_permissions")
def api_score_profiles_create():
    store = _get_store()
    if store is None:
        return jsonify({"error": "No store"}), 503
    data = request.get_json(force=True) or {}
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"error": "name is required"}), 400
    description = (data.get("description") or "").strip()
    config = data.get("config") or {}
    try:
        profile = store.create_score_profile(
            g.tenant_id, name, description, config, request.current_user["email"]
        )
        return jsonify(profile), 201
    except Exception as e:
        if "duplicate key" in str(e).lower() or "unique" in str(e).lower():
            return jsonify({"error": f"A profile named '{name}' already exists"}), 409
        return jsonify({"error": str(e)}), 500


@app.route("/api/score-profiles/<int:pid>", methods=["PUT"])
@require_client_auth
@require_permission("manage_permissions")
def api_score_profiles_update(pid):
    store = _get_store()
    if store is None:
        return jsonify({"error": "No store"}), 503
    existing = store.get_score_profile(g.tenant_id, pid)
    if not existing:
        return jsonify({"error": "Not found"}), 404
    data = request.get_json(force=True) or {}
    name = (data.get("name") or "").strip()
    if not name:
        return jsonify({"error": "name is required"}), 400
    description = (data.get("description") or "").strip()
    config = data.get("config") or {}
    try:
        profile = store.update_score_profile(
            g.tenant_id, pid, name, description, config, request.current_user["email"]
        )
        return jsonify(profile)
    except Exception as e:
        if "duplicate key" in str(e).lower() or "unique" in str(e).lower():
            return jsonify({"error": f"A profile named '{name}' already exists"}), 409
        return jsonify({"error": str(e)}), 500


@app.route("/api/score-profiles/<int:pid>", methods=["DELETE"])
@require_client_auth
@require_permission("manage_permissions")
def api_score_profiles_delete(pid):
    store = _get_store()
    if store is None:
        return jsonify({"error": "No store"}), 503
    existing = store.get_score_profile(g.tenant_id, pid)
    if not existing:
        return jsonify({"error": "Not found"}), 404
    try:
        store.delete_score_profile(g.tenant_id, pid)
        return jsonify({"ok": True})
    except ValueError as e:
        return jsonify({"error": str(e)}), 409
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/score-profiles/<int:pid>/set-default", methods=["POST"])
@require_client_auth
@require_permission("manage_permissions")
def api_score_profiles_set_default(pid):
    store = _get_store()
    if store is None:
        return jsonify({"error": "No store"}), 503
    existing = store.get_score_profile(g.tenant_id, pid)
    if not existing:
        return jsonify({"error": "Not found"}), 404
    store.set_default_profile(g.tenant_id, pid)
    return jsonify({"ok": True})


@app.route("/api/score-profiles/<int:pid>/compute", methods=["POST"])
@require_client_auth
@require_permission("view_compliance")
def api_score_profiles_compute(pid):
    store = _get_store()
    if store is None:
        return jsonify({"error": "No store"}), 503
    profile = store.get_score_profile(g.tenant_id, pid)
    if not profile:
        return jsonify({"error": "Profile not found"}), 404
    snapshot = store.get_latest_compliance(g.tenant_id)
    if not snapshot:
        return jsonify({"error": "No compliance snapshot found"}), 404
    result = _apply_profile(snapshot, profile.get("config") or {})
    return jsonify(result)


@app.route("/api/check-catalog")
@require_client_auth
@require_permission("view_compliance")
def api_check_catalog():
    """Return the full compliance check catalog for UI rendering."""
    from attestant.compliance.base import CHECK_CATALOG
    return jsonify([
        {
            "id": c.id,
            "name": c.name,
            "description": c.description,
            "regulation": c.regulation,
            "regulation_label": c.regulation_label,
            "default_action": c.default_action,
            "default_enabled": c.default_enabled,
            "scope": c.scope,
            "regulation_citation": c.regulation_citation,
        }
        for c in CHECK_CATALOG
    ])


@app.route("/api/score-profiles/<int:pid>/clone", methods=["POST"])
@require_client_auth
@require_permission("manage_permissions")
def api_score_profiles_clone(pid):
    store = _get_store()
    if store is None:
        return jsonify({"error": "No store"}), 503
    existing = store.get_score_profile(g.tenant_id, pid)
    if not existing:
        return jsonify({"error": "Not found"}), 404
    data = request.get_json(force=True) or {}
    new_name = (data.get("name") or "").strip()
    if not new_name:
        new_name = existing["name"] + " (Copy)"
    try:
        profile = store.clone_score_profile(
            g.tenant_id, pid, new_name, request.current_user["email"]
        )
        return jsonify(profile), 201
    except Exception as e:
        if "duplicate key" in str(e).lower() or "unique" in str(e).lower():
            return jsonify({"error": f"A profile named '{new_name}' already exists"}), 409
        return jsonify({"error": str(e)}), 500


@app.route("/api/compliance-templates")
@require_client_auth
@require_permission("view_compliance")
def api_compliance_templates():
    store = _get_store()
    if store is None:
        return jsonify([])
    templates = store.list_compliance_templates()
    return jsonify(templates)


@app.route("/api/compliance-templates/<tid>/apply", methods=["POST"])
@require_client_auth
@require_permission("manage_permissions")
def api_compliance_template_apply(tid):
    """Create a new score profile from a template."""
    store = _get_store()
    if store is None:
        return jsonify({"error": "No store"}), 503
    template = store.get_compliance_template(tid)
    if not template:
        return jsonify({"error": "Template not found"}), 404
    data = request.get_json(force=True) or {}
    name = (data.get("name") or "").strip()
    if not name:
        name = template["name"]
    description = (data.get("description") or "").strip()
    if not description:
        description = template.get("description") or ""
    config = template["config"]
    if isinstance(config, str):
        config = json.loads(config)
    try:
        profile = store.create_score_profile(
            g.tenant_id, name, description, config, request.current_user["email"]
        )
        return jsonify(profile), 201
    except Exception as e:
        if "duplicate key" in str(e).lower() or "unique" in str(e).lower():
            return jsonify({"error": f"A profile named '{name}' already exists"}), 409
        return jsonify({"error": str(e)}), 500


@app.route("/api/model-profile-assignments")
@require_client_auth
@require_permission("view_compliance")
def api_model_profile_assignments():
    store = _get_store()
    if store is None:
        return jsonify([])
    assignments = store.list_model_profile_assignments(g.tenant_id)
    return jsonify(assignments)


@app.route("/api/model-profile-assignments/<model_id>", methods=["PUT"])
@require_client_auth
@require_permission("manage_permissions")
def api_model_profile_assignment_set(model_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "No store"}), 503
    data = request.get_json(force=True) or {}
    profile_id = data.get("profile_id")
    if not profile_id:
        return jsonify({"error": "profile_id is required"}), 400
    profile = store.get_score_profile(g.tenant_id, int(profile_id))
    if not profile:
        return jsonify({"error": "Profile not found"}), 404
    try:
        assignment = store.upsert_model_profile_assignment(
            g.tenant_id, model_id, int(profile_id), request.current_user["email"]
        )
        return jsonify(assignment)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/model-profile-assignments/<model_id>", methods=["DELETE"])
@require_client_auth
@require_permission("manage_permissions")
def api_model_profile_assignment_delete(model_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "No store"}), 503
    try:
        store.delete_model_profile_assignment(g.tenant_id, model_id)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/models", methods=["GET", "POST"])
@require_client_auth
@require_permission("view_models")
def api_models():
    store = _get_store()
    if request.method == "POST":
        if store is None:
            return jsonify({"error": "No database connection"}), 503
        body = request.get_json(force=True) or {}
        name = (body.get("name") or "").strip()
        if not name:
            return jsonify({"error": "name is required"}), 400
        import re as _re
        version = (body.get("version") or "1.0").strip()
        model_id = _re.sub(r"[^a-z0-9_-]", "_", name.lower()) + "-" + _re.sub(r"[^a-z0-9_-]", "_", version.lower())
        model = {
            "model_id": model_id,
            "name": name,
            "version": version,
            "domain": (body.get("domain") or "").strip(),
            "owner": (body.get("owner") or "").strip(),
            "tier": int(body.get("tier") or 3),
            "status": "development",
        }
        try:
            store.upsert_model_snapshot(g.tenant_id, model)
            return jsonify({"ok": True, "model_id": model_id})
        except Exception as exc:
            logger.error("Failed to create model: %s", exc)
            return jsonify({"error": "Failed to create model"}), 500
    if store is None:
        return jsonify(_demo_models())
    data = store.get_models(g.tenant_id)
    return jsonify(data)


@app.route("/api/models/<model_id>", methods=["PUT"])
@require_client_auth
@require_permission("view_models")
def api_update_model(model_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "No database connection"}), 503
    body = request.get_json(force=True)
    if not body:
        return jsonify({"error": "No data provided"}), 400
    ok = store.update_model(g.tenant_id, model_id, body)
    if not ok:
        return jsonify({"error": "No valid fields to update"}), 400
    return jsonify({"ok": True})


@app.route("/api/models/<model_id>/check-results")
@require_client_auth
@require_permission("view_compliance")
def api_model_check_results(model_id):
    """Return per-check compliance results for a model from the latest snapshot."""
    store = _get_store()
    if store is None:
        return jsonify([])
    tenant_id = g.tenant_id
    row = store._read_dict(
        "select check_results, last_validated from model_snapshots "
        "where tenant_id = %s and model_id = %s "
        "order by snapshot_at desc limit 1",
        (tenant_id, model_id)
    )
    run_at = None
    if row:
        results = row.get("check_results") or {}
        if isinstance(results, str):
            try:
                results = json.loads(results)
            except Exception:
                results = {}
        run_at = row.get("last_validated")
        if results:
            return jsonify([
                {"check_id": cid, "run_at": str(run_at) if run_at else None, **v}
                for cid, v in results.items()
            ])
    snap = store._read_dict(
        "select breakdowns from compliance_snapshots "
        "where tenant_id = %s order by snapshot_at desc limit 1",
        (tenant_id,)
    )
    if not snap:
        return jsonify([])
    bd_raw = snap.get("breakdowns") or []
    if isinstance(bd_raw, str):
        try:
            bd_raw = json.loads(bd_raw)
        except Exception:
            bd_raw = []
    reg_status = {}
    for bd in bd_raw:
        reg = (bd.get("regulation") or "").lower()
        if "sr" in reg:
            reg_status["sr117"] = "pass" if bd.get("passed") else "warning"
        elif "ecoa" in reg:
            reg_status["ecoa"] = "pass" if bd.get("passed") else "warning"
        elif "eu" in reg or "ai" in reg:
            reg_status["eu_ai_act"] = "pass" if bd.get("passed") else "warning"
    if not reg_status:
        return jsonify([])
    try:
        from attestant.compliance.base import CHECK_CATALOG
        out = []
        for check_def in CHECK_CATALOG:
            st = reg_status.get(check_def.regulation, "na")
            out.append({
                "check_id": check_def.id,
                "run_at": str(run_at) if run_at else None,
                "status": st,
                "na_reason": "Regulation not evaluated" if st == "na" else None,
                "findings": [],
            })
        return jsonify(out)
    except Exception:
        return jsonify([])


@app.route("/api/fairness")
@require_client_auth
@require_permission("view_fairness")
def api_fairness():
    store = _get_store()
    if store is None:
        return jsonify(_demo_fairness())
    models = store.get_models(g.tenant_id)
    results = []
    for m in models:
        f = store.get_latest_fairness(g.tenant_id, m["model_id"])
        if f:
            results.append(f)
    return jsonify(results)


@app.route("/api/calendar")
@require_client_auth
def api_calendar():
    if _get_store() is None:
        return jsonify(_demo_regulatory_calendar())
    from attestant.governance.regulatory_calendar import RegulatoryCalendar
    cal = RegulatoryCalendar()
    return jsonify(cal.generate_report())


@app.route("/api/certifications")
@require_client_auth
def api_certifications():
    store = _get_store()
    if store is None:
        return jsonify(_demo_certifications())
    data = store.get_certifications(g.tenant_id)
    return jsonify(data)


@app.route("/api/alerts")
@require_client_auth
@require_permission("view_alerts")
def api_alerts():
    store = _get_store()
    if store is None:
        return jsonify(_demo_alerts())
    data = store.get_alerts(g.tenant_id, unresolved_only=False)
    return jsonify(data)


@app.route("/api/alerts/<int:alert_id>/resolve", methods=["POST"])
@require_client_auth
@require_permission("view_alerts")
def api_resolve_alert(alert_id):
    """Resolve a specific alert."""
    store = _get_store()
    if store is None:
        return jsonify({"ok": True})
    store.resolve_alert(alert_id)
    return jsonify({"ok": True})


@app.route("/api/training-validations")
@require_client_auth
@require_permission("view_models")
def api_training_validations():
    """Return training validation results (pre-deployment)."""
    store = _get_store()
    if store is None:
        return jsonify([])

    try:
        rows = store._read_dicts(
            """
            SELECT DISTINCT ON (ms.model_id, ms.version)
                ms.model_id,
                ms.name AS model_name,
                ms.version AS model_version,
                ms.compliance_score,
                fs.has_disparate_impact,
                fs.statistically_significant,
                fs.worst_ratio,
                COALESCE(ms.last_validated, ms.snapshot_at) AS validated_at
            FROM model_snapshots ms
            LEFT JOIN LATERAL (
                SELECT has_disparate_impact, statistically_significant, worst_ratio
                FROM fairness_snapshots
                WHERE model_id = ms.model_id AND tenant_id = ms.tenant_id
                ORDER BY snapshot_at DESC LIMIT 1
            ) fs ON TRUE
            WHERE ms.tenant_id = %s
            ORDER BY ms.model_id, ms.version, ms.snapshot_at DESC
            LIMIT 100
            """,
            (g.tenant_id,)
        )

        results = []
        for row in rows:
            has_fairness_data = row.get('worst_ratio') is not None or row.get('has_disparate_impact') is not None
            fairness_pass = True
            if row.get('has_disparate_impact') and row.get('statistically_significant'):
                fairness_pass = False
            elif row.get('worst_ratio') is not None and row['worst_ratio'] < 0.80:
                fairness_pass = False

            approved = (row.get('compliance_score') or 0) >= 70 and fairness_pass

            results.append({
                'model_id': row['model_id'],
                'model_name': row['model_name'],
                'model_version': row['model_version'],
                'compliance_score': row.get('compliance_score'),
                'fairness_pass': fairness_pass,
                'has_fairness_data': has_fairness_data,
                'approved': approved,
                'validated_at': row['validated_at'].isoformat() if row.get('validated_at') else None,
            })

        return jsonify(results)
    except Exception as e:
        logger.exception("Failed to fetch training validations")
        return jsonify({"error": "Failed to load training validations", "code": "TRAINING_VALIDATIONS_ERROR"}), 500


@app.route("/api/models/<model_id>/feature-stats")
@require_client_auth
@require_permission("view_models")
def api_model_feature_stats(model_id):
    """Return the latest feature-level statistics for a model captured at validation time."""
    store = _get_store()
    if store is None:
        return jsonify(None)
    try:
        row = store._read_dict(
            """select feature_stats, feature_importance, prediction_stats,
                      protected_distributions, data_quality, snapshot_at
               from model_feature_stats
               where tenant_id = %s and model_id = %s
               order by snapshot_at desc limit 1""",
            (g.tenant_id, model_id),
        )
        if not row:
            return jsonify(None)
        return jsonify({
            "feature_stats":           row.get("feature_stats") or {},
            "feature_importance":      row.get("feature_importance") or [],
            "prediction_stats":        row.get("prediction_stats") or {},
            "protected_distributions": row.get("protected_distributions") or {},
            "data_quality":            row.get("data_quality") or {},
            "snapshot_at":             row["snapshot_at"].isoformat() if row.get("snapshot_at") else None,
        })
    except Exception:
        logger.exception("Failed to fetch feature stats for %s", model_id)
        return jsonify(None)


@app.route("/api/models/<model_id>/latest-dag")
@require_client_auth
@require_permission("view_models")
def api_model_latest_dag(model_id):
    """Return the latest HYDRA-32 DAG for a model (nodes + edges + stats)."""
    store = _get_store()
    if store is None:
        return jsonify(None)
    try:
        name_row = store._read_dict(
            "select name from model_snapshots where tenant_id = %s and model_id = %s",
            (g.tenant_id, model_id),
        )
        if not name_row:
            return jsonify(None)
        model_name = name_row["name"]

        ps_row = store._read_dict(
            """select provenance_pipeline_id, metadata
               from pipeline_stats
               where tenant_id = %s and pipeline_name = %s
                 and provenance_pipeline_id is not null
               order by completed_at desc limit 1""",
            (g.tenant_id, model_name),
        )
        if not ps_row or not ps_row.get("provenance_pipeline_id"):
            return jsonify(None)

        prov_pipeline_id = ps_row["provenance_pipeline_id"]
        ps_metadata = ps_row.get("metadata") or {}
        if isinstance(ps_metadata, str):
            try:
                ps_metadata = json.loads(ps_metadata)
            except (ValueError, TypeError):
                ps_metadata = {}

        nodes_raw = store._read_dicts(
            """select node_id, node_type, operation, column_name, is_protected
               from dag_nodes where pipeline_id = %s order by node_id""",
            (prov_pipeline_id,),
        )
        edges_raw = store._read_dicts(
            """select de.parent_node_id as source, de.child_node_id as target,
                      de.input_position as input_index
               from dag_edges de
               join dag_nodes dn on de.child_node_id = dn.node_id
               where dn.pipeline_id = %s""",
            (prov_pipeline_id,),
        )

        nodes_dict = {}
        for n in (nodes_raw or []):
            nodes_dict[str(n["node_id"])] = {
                "node_type": (n.get("node_type") or "").upper(),
                "operation": n.get("operation") or "",
                "column_name": n.get("column_name") or n.get("operation") or "",
                "is_protected": bool(n.get("is_protected")),
            }

        edges_list = [
            {
                "source": e["source"],
                "target": e["target"],
                "input_index": e.get("input_index") or 0,
            }
            for e in (edges_raw or [])
        ]

        target_ids = {e["target"] for e in edges_list}
        root_id = max(target_ids) if target_ids else (int(max(nodes_dict)) if nodes_dict else 0)

        source_nodes = [n for n in (nodes_raw or []) if (n.get("node_type") or "").upper() == "SOURCE"]
        protected_source_count = sum(1 for n in source_nodes if n.get("is_protected"))

        return jsonify({
            "nodes": nodes_dict,
            "edges": edges_list,
            "root_id": root_id,
            "stats": {
                "node_count": len(nodes_dict),
                "edge_count": len(edges_list),
                "protected_source_count": protected_source_count,
                "provenance_coverage": ps_metadata.get("provenance_coverage", 1.0),
            },
        })
    except Exception:
        logger.exception("Failed to fetch latest DAG for model %s", model_id)
        return jsonify(None)


@app.route("/api/inference-batches")
@require_client_auth
@require_permission("view_models")
def api_inference_batches():
    """Return production inference batch results (post-deployment monitoring)."""
    store = _get_store()
    if store is None:
        return jsonify([])

    try:
        rows = store._read_dicts(
            """
            SELECT
                ps.id,
                ps.pipeline_name,
                ps.case_count AS prediction_count,
                ps.last_used_at AS timestamp,
                ps.metadata
            FROM pipeline_stats ps
            WHERE ps.tenant_id = %s
              AND (ps.metadata->>'type' = 'INFERENCE'
                   OR ps.metadata->>'type' IS NULL)
            ORDER BY ps.last_used_at DESC
            LIMIT 100
            """,
            (g.tenant_id,)
        )

        # Pre-fetch fairness data keyed by model name prefix for DI ratio lookup
        fairness_rows = store._read_dicts(
            """
            SELECT fs.worst_ratio, ms.name AS model_name
            FROM fairness_snapshots fs
            JOIN model_snapshots ms ON fs.model_id = ms.model_id AND fs.tenant_id = ms.tenant_id
            WHERE fs.tenant_id = %s AND fs.worst_ratio IS NOT NULL
            ORDER BY fs.snapshot_at DESC
            """,
            (g.tenant_id,)
        )
        fairness_by_model = {}
        for fr in (fairness_rows or []):
            name = (fr.get('model_name') or '').lower()
            if name and name not in fairness_by_model:
                fairness_by_model[name] = fr['worst_ratio']

        results = []
        for row in rows:
            pipeline_id = row['id']

            agg = store._read_dict(
                """
                SELECT
                    COUNT(*) AS total,
                    SUM(CASE WHEN decision = 'approved' OR decision = '1' THEN 1 ELSE 0 END) AS approved
                FROM pipeline_row_results
                WHERE pipeline_id = %s AND tenant_id = %s
                """,
                (pipeline_id, g.tenant_id)
            )

            total_decisions = (agg['total'] if agg else 0) or 0
            approved_decisions = (agg['approved'] if agg else 0) or 0

            pipeline_name_lower = (row['pipeline_name'] or '').lower()
            worst_di = fairness_by_model.get(pipeline_name_lower)

            results.append({
                'batch_id': f"batch_{pipeline_id}",
                'model_name': row['pipeline_name'],
                'prediction_count': total_decisions or row.get('prediction_count', 0),
                'approval_count': approved_decisions,
                'flagged_count': max(0, total_decisions - approved_decisions),
                'worst_di_ratio': worst_di,
                'timestamp': row['timestamp'].isoformat() if row.get('timestamp') else None,
            })

        return jsonify(results)
    except Exception as e:
        logger.exception("Failed to fetch inference batches")
        return jsonify({"error": "Failed to load inference batches", "code": "INFERENCE_BATCHES_ERROR"}), 500


@app.route("/api/examiner-readiness")
@require_client_auth
@require_permission("view_compliance")
def api_examiner_readiness():
    """Composite examiner readiness score computed from existing compliance data."""
    store = _get_store()

    if store is None:
        return jsonify(_demo_examiner_readiness())

    tenant_id = g.tenant_id

    try:
        models = store.get_models(tenant_id)
        total_models = len(models)

        compliant_models = sum(
            1 for m in models if (m.get("compliance_score") or 0) >= 75
        )
        compliance_coverage = (compliant_models / total_models * 100) if total_models else 0

        doc_coverage = compliance_coverage

        fairness_rows = store._read_dicts(
            "select details from fairness_snapshots where tenant_id = %s "
            "order by snapshot_at desc limit 20",
            (tenant_id,),
        )
        fair_models = sum(
            1 for f in fairness_rows
            if not (f.get("details") or {}).get("critical_bias")
        )
        fairness_coverage = (fair_models / len(fairness_rows) * 100) if fairness_rows else 0

        recent = store._read_dict(
            "select count(*) as n from model_snapshots where tenant_id = %s "
            "and last_validated > now() - interval '90 days'",
            (tenant_id,),
        )
        monitoring_coverage = (
            (recent["n"] / total_models * 100) if total_models and recent else 0
        )

        overall_score = (
            compliance_coverage * 0.40
            + fairness_coverage * 0.25
            + monitoring_coverage * 0.20
            + doc_coverage * 0.15
        )

        grade = (
            "A" if overall_score >= 90
            else "B" if overall_score >= 75
            else "C" if overall_score >= 60
            else "D"
        )

        model_readiness = {}
        for m in models:
            mid = m.get("model_id") or m.get("name") or ""
            score = m.get("compliance_score") or 0
            ready = score >= 75
            sr117_gaps = max(0, int((100 - score) / 20)) if not ready else 0
            ecoa_gaps = max(0, int((100 - score) / 25)) if not ready else 0
            model_readiness[mid] = {
                "sr117": {"ready": ready, "gaps": sr117_gaps},
                "ecoa": {"ready": ready, "gaps": ecoa_gaps},
                "eu_ai_act": {"ready": False, "gaps": 3},
                "overall": grade if ready else "D",
                "overall_ready": ready,
            }

        eu_ai_act_gaps = [
            "Technical documentation not yet assessed for EU AI Act",
            "Conformity assessment not completed",
            "Risk management plan not uploaded",
        ]

        return jsonify({
            "overall": grade,
            "score": round(overall_score, 1),
            "components": [
                {"label": "Compliance Coverage", "score": round(compliance_coverage, 1), "weight": 40},
                {"label": "Fairness & Bias", "score": round(fairness_coverage, 1), "weight": 25},
                {"label": "Monitoring Currency", "score": round(monitoring_coverage, 1), "weight": 20},
                {"label": "Documentation", "score": round(doc_coverage, 1), "weight": 15},
            ],
            "model_readiness": model_readiness,
            "eu_ai_act_gaps": eu_ai_act_gaps,
            "gaps": {"eu_ai_act": eu_ai_act_gaps},
            "ready_count": compliant_models,
            "total_count": total_models,
        })
    except Exception:
        logger.exception("Examiner readiness computation failed")
        return jsonify(_demo_examiner_readiness())


def _demo_examiner_readiness():
    return {
        "overall": "coming_soon",
        "ready_count": 0,
        "total_count": 0,
        "checklist": [],
        "coming_soon": True,
    }


@app.route("/api/pipeline-runs")
@require_client_auth
@require_permission("view_pipelines")
def api_pipeline_runs():
    """Get pipeline execution history for this tenant."""
    store = _get_store()
    if store is None:
        return jsonify(_demo_pipeline_runs())
    data = store.get_pipeline_stats(tenant_id=g.tenant_id, limit=50)
    return jsonify(data)


@app.route("/api/pipeline-runs/<int:pipeline_id>/rename", methods=["PUT"])
@require_client_auth
@require_permission("view_pipelines")
def api_rename_pipeline(pipeline_id):
    """Rename a pipeline run for display purposes."""
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    data = request.json or {}
    display_name = (data.get("display_name") or "").strip()

    if not display_name:
        return jsonify({"error": "display_name is required"}), 400

    if len(display_name) > 255:
        return jsonify({"error": "display_name must be <= 255 characters"}), 400

    store.update_pipeline_display_name(g.tenant_id, pipeline_id, display_name)
    return jsonify({"ok": True, "display_name": display_name})


@app.route("/api/pipelines/<int:pipeline_id>/cases", methods=["GET"])
@require_client_auth
@require_permission("view_pipelines")
def api_get_pipeline_cases(pipeline_id):
    """Get all individual cases processed by a pipeline."""
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    cases = store.get_pipeline_row_results(g.tenant_id, pipeline_id, limit=1000)
    return jsonify({"cases": cases, "count": len(cases)})


TEMPLATE_MAP = {
    "sr117": "sr117",
    "eu_ai_act": "eu_ai_act",
    "ecoa": "ecoa",
    "model_card": "model_card",
    "nist_rmf": "nist_rmf",
    "gdpr": "gdpr",
}

REPORT_LABELS = {
    "examiner_package": "Examiner Package",
    "sr117": "SR 11-7 Model Validation",
    "ecoa": "ECOA Fair Lending",
    "eu_ai_act": "EU AI Act Conformity",
    "model_card": "Model Card",
    "nist_rmf": "NIST AI RMF",
    "gdpr": "GDPR Data Protection",
}


def _load_report_data(model_id=None):
    """Load compliance data from Aurora (or demo fallback).

    If model_id is provided, filters to that specific model.
    Returns (comp, models, fairness, certs, alerts).
    """
    store = _get_store()

    if store is None:
        return (_demo_compliance(), _demo_models(), _demo_fairness(),
                _demo_certifications(), _demo_alerts())

    comp = store.get_latest_compliance(g.tenant_id) or {}
    all_models = store.get_models(g.tenant_id)

    if model_id:
        models = [m for m in all_models if m.get("model_id") == model_id]
        if not models:
            models = all_models
    else:
        models = all_models

    fairness_list = []
    for m in models:
        f = store.get_latest_fairness(g.tenant_id, m["model_id"])
        if f:
            fairness_list.append(f)

    certs = store.get_certifications(g.tenant_id)
    alerts = store.get_alerts(g.tenant_id, unresolved_only=False)
    return comp, models, fairness_list, certs, alerts


@app.route("/api/reports/generate", methods=["POST"])
@require_client_auth
@require_permission("view_reports")
def api_generate_report():
    """Generate a compliance report, persist it, and return the content."""
    data = request.json or {}
    report_type = data.get("report_type") or data.get("type", "sr117")
    model_id = data.get("model_id")
    generated_by = data.get("generated_by", "dashboard_user")

    try:
        content = _generate_report_content(report_type, model_id=model_id)
        content_hash = hashlib.sha256(
            content["markdown"].encode()
        ).hexdigest()

        report_id = _save_report(
            report_type=report_type,
            title=content["title"],
            content_md=content["markdown"],
            section_count=content.get("section_count", 0),
            model_id=model_id,
            generated_by=generated_by,
            meta={
                "label": REPORT_LABELS.get(report_type, report_type),
                "tenant": g.tenant_id,
            },
        )

        return jsonify({
            "status": "ready",
            "type": report_type,
            "title": content["title"],
            "content": content["markdown"],
            "sections": content.get("section_count", 0),
            "content_hash": content_hash,
            "report_id": report_id,
            "id": report_id,
            "model_id": model_id,
        })
    except Exception as e:
        logger.error("Report generation failed: %s", e)
        return jsonify({
            "status": "error",
            "type": report_type,
            "message": str(e),
        }), 500


@app.route("/api/reports/history")
@require_client_auth
@require_permission("view_reports")
def api_report_history():
    """Return list of previously generated reports for this tenant."""
    limit = request.args.get("limit", 50, type=int)
    return jsonify(_get_report_history(limit=limit))


@app.route("/api/reports/<int:report_id>")
@require_client_auth
@require_permission("view_reports")
def api_get_report(report_id):
    """Retrieve a specific saved report by ID."""
    report = _get_report_by_id(report_id)
    if report is None:
        return jsonify({"error": "Report not found"}), 404
    return jsonify(report)


@app.route("/api/reports/<int:report_id>", methods=["DELETE"])
@require_client_auth
@require_permission("view_reports")
def api_delete_report(report_id):
    """Delete a saved report."""
    ok = _delete_report(report_id)
    return jsonify({"ok": ok})


@app.route("/api/reports/<int:report_id>/download/<fmt>")
@require_client_auth
@require_permission("view_reports")
def api_download_report(report_id, fmt):
    """Download a saved report as PDF, DOCX, or HTML.

    Uses the AutoDoc engine's built-in export backends.
    """
    report = _get_report_by_id(report_id)
    if report is None:
        return jsonify({"error": "Report not found"}), 404

    if fmt not in ("pdf", "docx", "html"):
        return jsonify({"error": "Format must be pdf, docx, or html"}), 400

    from attestant.docs.engine import DocumentReport, DocumentSection, TemplateType

    sections = []
    current_h2 = None
    for line in report["content_md"].split("\n"):
        if line.startswith("## "):
            if current_h2:
                sections.append(current_h2)
            current_h2 = DocumentSection(
                title=line[3:].strip(), content="", level=1
            )
        elif line.startswith("### ") and current_h2:
            current_h2.subsections.append(
                DocumentSection(title=line[4:].strip(), content="", level=2)
            )
        elif current_h2:
            target = (current_h2.subsections[-1]
                      if current_h2.subsections else current_h2)
            target.content += line + "\n"
        elif line.startswith("# "):
            pass
        else:
            if not sections and not current_h2:
                current_h2 = DocumentSection(
                    title="Report", content=line + "\n", level=1
                )
    if current_h2:
        sections.append(current_h2)

    rtype = report.get("report_type", "sr117")
    ttype_val = TEMPLATE_MAP.get(rtype, "sr11-7")
    try:
        ttype = TemplateType(ttype_val)
    except ValueError:
        ttype = TemplateType.SR117

    doc_report = DocumentReport(
        title=report["title"],
        template_type=ttype,
        sections=sections,
        metadata={
            "Institution": g.tenant_id.replace("_", " ").title(),
            "Generated": report.get("created_at", ""),
            "Report Type": REPORT_LABELS.get(rtype, rtype),
            "Content Hash": report.get("content_hash", ""),
        },
    )

    suffix = {"pdf": ".pdf", "docx": ".docx", "html": ".html"}[fmt]
    mime = {
        "pdf": "application/pdf",
        "docx": "application/vnd.openxmlformats-officedocument"
               ".wordprocessingml.document",
        "html": "text/html",
    }[fmt]

    safe_title = report["title"].replace(" ", "_").replace("/", "-")[:60]
    filename = f"{safe_title}{suffix}"

    try:
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            tmp_path = tmp.name

        doc_report.save(tmp_path)

        with open(tmp_path, "rb") as fh:
            data_bytes = fh.read()

        os.unlink(tmp_path)

        return Response(
            data_bytes,
            mimetype=mime,
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"',
            },
        )
    except ImportError as e:
        return jsonify({"error": str(e)}), 500
    except Exception as e:
        logger.error("Report download failed: %s", e, exc_info=True)
        return jsonify({"error": f"Export failed: {e}"}), 500


def _generate_report_content(report_type: str, model_id=None) -> dict:
    """Generate actual report content using AutoDoc or ExaminerPackage."""
    comp, models, fairness, certs, alerts = _load_report_data(
        model_id=model_id
    )

    if report_type == "examiner_package":
        return _generate_examiner_package(comp, models, fairness, certs,
                                          alerts)

    autodoc_type = TEMPLATE_MAP.get(report_type)
    if autodoc_type:
        return _generate_autodoc_report(autodoc_type, comp, models, fairness,
                                        model_id=model_id)

    return {
        "title": "Unknown Report Type",
        "markdown": f"Report type '{report_type}' is not supported.",
        "section_count": 0,
    }


def _build_report_markdown(template_type, m_data, fairlens_data,
                           dag_nodes, dag_edges, extra):
    """Build report markdown directly from collected DB data."""
    import time
    now = time.strftime("%B %d, %Y")

    model_name = m_data.get("model_name", "Unknown Model")
    version = m_data.get("version", "")
    domain = m_data.get("domain", "")
    tier = m_data.get("tier", "")
    institution = extra.get("institution_name", "Institution")
    score = extra.get("compliance_score")
    grade = extra.get("compliance_grade", "")
    total_findings = extra.get("total_findings", 0)
    critical_findings = extra.get("critical_findings", 0)
    score_str = f"{score:.1f}" if score is not None else "N/A"
    breakdowns = extra.get("breakdowns", [])

    fd = fairlens_data or {}
    has_di = fd.get("has_disparate_impact", False)
    worst_ratio = fd.get("worst_ratio")
    worst_group = fd.get("worst_group", "")
    prot_attrs = fd.get("protected_attributes", [])
    di_list = fd.get("disparate_impact", [])

    source_count = sum(1 for n in dag_nodes if n.get("type") == "SOURCE")
    protected_count = sum(1 for n in dag_nodes if n.get("is_protected"))
    pipeline_name = extra.get("pipeline_name", "")

    def _di_table():
        if not di_list:
            return "_No disparate impact data available._"
        rows = ["| Protected Attribute | Worst DI Ratio | Pass 4/5 Rule |",
                "|---------------------|---------------|---------------|"]
        for d in di_list:
            ratio = d.get("worst_ratio")
            ratio_str = f"{ratio:.3f}" if ratio is not None else "N/A"
            passes = "✓ Pass" if not d.get("has_disparate_impact") else "✗ Fail"
            rows.append(f"| {d.get('protected_attribute', '')} | {ratio_str} | {passes} |")
        return "\n".join(rows)

    def _breakdown_table():
        if not breakdowns:
            return "_No regulation breakdown available._"
        rows = ["| Regulation | Score | Grade |",
                "|------------|-------|-------|"]
        for b in breakdowns:
            bscore = b.get("score", b.get("value", ""))
            bscore_str = f"{bscore:.1f}" if isinstance(bscore, (int, float)) else str(bscore)
            rows.append(f"| {b.get('label', b.get('regulation', ''))} | {bscore_str} | {b.get('grade', '')} |")
        return "\n".join(rows)

    def _attrs_str():
        if not prot_attrs:
            return "_None recorded_"
        return ", ".join(str(a) for a in prot_attrs)

    status_line = "APPROVED" if critical_findings == 0 else "CONDITIONAL" if total_findings > 0 else "REVIEW REQUIRED"

    if template_type == "sr117":
        title = f"SR 11-7 Model Validation Report — {model_name}"
        md = f"""# {title}

**Institution:** {institution}
**Model:** {model_name} {f"v{version}" if version else ""}
**Date:** {now}
**Regulation:** Federal Reserve SR 11-7 / OCC Bulletin 2011-12
**Confidentiality:** Internal Use Only

---

## 1. Executive Summary

**Validation Status: {status_line}**

This report presents the independent validation of the **{model_name}** model in accordance with
Federal Reserve Supervisory Guidance on Model Risk Management (SR Letter 11-7, April 2011)
and OCC Bulletin 2011-12.

| Metric | Value |
|--------|-------|
| Compliance Score | {score_str} |
| Compliance Grade | {grade} |
| Total Findings | {total_findings} |
| Critical Findings | {critical_findings} |
| Disparate Impact Detected | {"Yes" if has_di else "No"} |
| Protected Attributes Monitored | {len(prot_attrs)} |

## 2. Model Purpose and Design

**Model Name:** {model_name}
**Version:** {version or "Not specified"}
**Domain:** {domain.title() if domain else "Not specified"}
**Risk Tier:** {(f"Tier {tier}" if isinstance(tier, int) else str(tier).upper()) if tier else "Not specified"}

The model supports credit and risk decisions within the {domain or "financial services"} domain.

## 3. Compliance Overview

{_breakdown_table()}

## 4. Fairness and Disparate Impact Analysis

**Protected Attributes:** {_attrs_str()}

{_di_table()}

{"**⚠ Disparate Impact Detected** — At least one protected group fails the four-fifths rule." if has_di else "**✓ No Disparate Impact** — All protected groups pass the four-fifths rule."}

## 5. Data Governance

**Data Lineage Nodes:** {len(dag_nodes)}
**Source Nodes:** {source_count}
**Protected Data Sources:** {protected_count}

{"Full data lineage is captured in the HYDRA-32 computation graph." if dag_nodes else "No computation graph available for this report."}

## 6. Ongoing Monitoring Plan

Monitoring cadence: **Quarterly** (minimum)

Monitored metrics:
- Model AUC and Precision/Recall
- Disparate impact ratios (four-fifths test)
- Population stability index (PSI > 0.25 triggers review)
- Feature distribution drift

**Re-validation Triggers:**
- Material model changes (algorithm, features, training data)
- Performance degradation beyond thresholds
- Annual re-validation (minimum)

## 7. Governance and Controls

Model risk is reported to the Board quarterly. All model changes are logged and require
re-validation assessment. Complete audit trail maintained including development documentation,
validation reports, monitoring results, and change logs.
"""

    elif template_type == "model_card":
        title = f"Model Card — {model_name}"
        md = f"""# {title}

**Version:** {version or "Not specified"}
**Date:** {now}
**Institution:** {institution}

---

## Model Overview

| Field | Value |
|-------|-------|
| Model Name | {model_name} |
| Version | {version or "N/A"} |
| Domain | {domain.title() if domain else "N/A"} |
| Risk Tier | {(f"Tier {tier}" if isinstance(tier, int) else str(tier).upper()) if tier else "N/A"} |
| Compliance Score | {score_str} |
| Compliance Grade | {grade} |

## Intended Use

This model is intended for use in {domain or "financial services"} contexts.
It should be used with human oversight and is not intended for use cases
significantly outside the training distribution.

## Performance Summary

| Metric | Value |
|--------|-------|
| Compliance Score | {score_str} |
| Total Findings | {total_findings} |
| Critical Findings | {critical_findings} |

{_breakdown_table()}

## Fairness Metrics

**Protected Attributes Monitored:** {_attrs_str()}

{_di_table()}

**Disparate Impact Status:** {"⚠ Detected — remediation required" if has_di else "✓ No disparate impact detected"}

## Limitations

- Model performance may degrade for populations underrepresented in training data
- Extreme economic conditions may violate stationarity assumptions
- Manual review recommended for applicants near decision boundaries

## Governance

This model is subject to ongoing monitoring and periodic re-validation.
All changes require MRM review before deployment.
"""

    elif template_type == "eu_ai_act":
        title = f"EU AI Act Conformity Assessment — {model_name}"
        md = f"""# {title}

**Institution:** {institution}
**Model:** {model_name} {f"v{version}" if version else ""}
**Date:** {now}
**Framework:** EU AI Act (Regulation 2024/1689)
**Confidentiality:** Internal Use Only

---

## 1. Executive Summary

This conformity assessment evaluates **{model_name}** against the EU Artificial Intelligence Act
(Regulation 2024/1689, entered into force August 2024).

| Assessment Area | Status |
|----------------|--------|
| Compliance Score | {score_str} |
| Critical Findings | {critical_findings} |
| Fairness (DI) | {"Non-compliant" if has_di else "Compliant"} |

## 2. Risk Classification

**Domain:** {domain.title() if domain else "Not specified"}

Systems used in credit scoring, creditworthiness assessment, and similar financial
decisions are classified as **High-Risk AI Systems** under Annex III of the EU AI Act,
subject to the full obligations of Chapter III, Section 2.

## 3. Technical Documentation (Article 11)

**Data Lineage Nodes:** {len(dag_nodes)}
**Source Nodes:** {source_count}
**Protected Data Sources:** {protected_count}

{"Computation graph available — full data lineage traceable." if dag_nodes else "Computation graph not available. Article 11 requires documentation of training data and data governance."}

## 4. Transparency and Information to Deployers (Article 13)

The system is capable of providing explanations for individual decisions, enabling
deployers to fulfil their transparency obligations to affected persons.

**Protected Attributes Monitored:** {_attrs_str()}

## 5. Human Oversight (Article 14)

The system is designed to be overseen by humans. Final decisions require human review
where the system output could significantly affect individuals.

## 6. Accuracy, Robustness and Cybersecurity (Article 15)

{_breakdown_table()}

## 7. Fairness and Non-Discrimination

{_di_table()}

{"**⚠ Disparate impact detected.** Recital 44 and Article 10 require training data to be representative and free of bias. Remediation required." if has_di else "**✓ No disparate impact detected.** Protected groups pass the four-fifths rule."}

## 8. Conformity Status

{"**NON-CONFORMANT** — Critical findings must be resolved before deployment in the EU." if critical_findings > 0 else "**CONFORMANT** — Model meets EU AI Act requirements subject to ongoing monitoring."}
"""

    elif template_type == "ecoa":
        title = f"ECOA Fair Lending Review — {model_name}"
        md = f"""# {title}

**Institution:** {institution}
**Model:** {model_name} {f"v{version}" if version else ""}
**Date:** {now}
**Regulation:** Equal Credit Opportunity Act (ECOA / 12 CFR 1002)
**Confidentiality:** Internal Use Only

---

## 1. Executive Summary

This fair lending review evaluates **{model_name}** for compliance with the Equal Credit
Opportunity Act (ECOA), Regulation B (12 CFR 1002), and CFPB supervisory guidance.

| Area | Status |
|------|--------|
| Compliance Score | {score_str} |
| Disparate Impact | {"⚠ Detected" if has_di else "✓ Not Detected"} |
| Critical Findings | {critical_findings} |

## 2. Protected Attribute Analysis

**Protected Bases Monitored:** {_attrs_str()}

ECOA prohibits discrimination based on race, color, religion, national origin, sex,
marital status, age, and receipt of public assistance.

## 3. Disparate Impact Analysis

{_di_table()}

{"**⚠ Disparate Impact Detected.** At least one protected group has an approval rate below 80% of the highest-approved group, failing the four-fifths rule." if has_di else "**✓ No Disparate Impact.** All protected groups pass the four-fifths rule (approval rate ≥ 80% of reference group)."}

{"**Worst-case ratio:** " + f"{worst_ratio:.3f}" + f" (group: {worst_group})" if worst_ratio is not None else ""}

## 4. Adverse Action Compliance

Per ECOA / Reg B § 1002.9, adverse action notices must include specific principal reasons.
The model supports generation of specific adverse action reason codes for denied applications.

## 5. Less Discriminatory Alternative (LDA) Analysis

When disparate impact is detected, institutions must evaluate whether a less discriminatory
alternative model exists with comparable predictive power. {"LDA analysis recommended." if has_di else "LDA analysis not required — no disparate impact detected."}

## 6. Regulatory Status

{_breakdown_table()}

{"**⚠ Remediation Required.** Resolve disparate impact findings before continued use." if has_di else "**✓ Fair Lending Compliant.** No disparate impact concerns identified."}
"""

    elif template_type == "nist_rmf":
        title = f"NIST AI Risk Management Framework — {model_name}"
        md = f"""# {title}

**Institution:** {institution}
**Model:** {model_name} {f"v{version}" if version else ""}
**Date:** {now}
**Framework:** NIST AI RMF (NIST AI 100-1, January 2023)
**Confidentiality:** Internal Use Only

---

## Overview

This assessment applies the NIST Artificial Intelligence Risk Management Framework (AI RMF 1.0)
to **{model_name}**, covering all four core functions: GOVERN, MAP, MEASURE, and MANAGE.

| NIST Core Function | Status |
|-------------------|--------|
| GOVERN | Policies in place |
| MAP | Risks identified |
| MEASURE | Score: {score_str} ({grade}) |
| MANAGE | Monitoring active |

---

## GOVERN

**Accountability and Transparency**

AI risk governance policies establish roles and responsibilities for model development,
validation, and oversight. Model risk is reported to senior leadership {"quarterly" if tier else "regularly"}.

**Trustworthy AI Characteristics Addressed:**
- Accountable: Audit trail maintained for all model versions
- Transparent: Explanations generated for individual decisions
- Fair: Protected attribute monitoring active ({_attrs_str()})

---

## MAP

**Risk Identification and Context**

**Domain:** {domain.title() if domain else "Not specified"}
**Risk Tier:** {(f"Tier {tier}" if isinstance(tier, int) else str(tier).upper()) if tier else "Not specified"}
**Deployment Context:** The model supports {domain or "financial"} decision-making.

**Identified Risks:**
- Disparate impact on protected groups: {"HIGH — detected" if has_di else "LOW — not detected"}
- Compliance findings: {total_findings} total, {critical_findings} critical

---

## MEASURE

**Risk Analysis and Assessment**

| Metric | Value |
|--------|-------|
| Compliance Score | {score_str} |
| Grade | {grade} |
| Total Findings | {total_findings} |
| Critical Findings | {critical_findings} |
| Protected Attributes Monitored | {len(prot_attrs)} |
| Disparate Impact | {"Detected" if has_di else "Not Detected"} |

{_breakdown_table()}

**Fairness Analysis:**

{_di_table()}

**Data Lineage:** {len(dag_nodes)} nodes, {source_count} source nodes, {protected_count} protected sources

---

## MANAGE

**Risk Response and Recovery**

- Ongoing monitoring: quarterly review of performance and fairness metrics
- Re-validation triggers: material changes, threshold breaches, annual schedule
- Incident response: escalation to MRM committee within 5 business days
- {"**Priority:** Resolve disparate impact findings immediately." if has_di else "No active remediation required."}
"""

    elif template_type == "gdpr":
        title = f"GDPR Data Protection Assessment — {model_name}"
        md = f"""# {title}

**Institution:** {institution}
**Model:** {model_name} {f"v{version}" if version else ""}
**Date:** {now}
**Regulation:** EU General Data Protection Regulation (GDPR / Regulation 2016/679)
**Confidentiality:** Internal Use Only

---

## 1. Executive Summary

This Data Protection Impact Assessment (DPIA) evaluates **{model_name}** for compliance
with GDPR, with particular focus on automated decision-making (Article 22) and
data minimisation (Article 5(1)(c)).

| Assessment Area | Status |
|----------------|--------|
| Compliance Score | {score_str} |
| Critical Findings | {critical_findings} |
| Protected Attributes Handling | {"Review required" if prot_attrs else "Not applicable"} |

## 2. Data Processing Basis

This model processes personal data for credit and risk assessment purposes.

**Legal basis:** Legitimate interest / contractual necessity (Article 6(1)(b)/(f))

**Special Category Data (Article 9):** {"Protected demographic attributes are monitored for fairness, not used as model inputs." if prot_attrs else "No special category data identified."}

**Protected Attributes Monitored (fairness only):** {_attrs_str()}

## 3. Automated Decision-Making (Article 22)

The model {"produces" if domain else "may produce"} decisions that significantly affect individuals.
Where Article 22 applies, the following safeguards are in place:

- Human oversight required for final decisions
- Right to explanation: adverse action reason codes generated per-applicant
- Right to contest: process documented in policy

## 4. Data Minimisation (Article 5(1)(c))

**Data Lineage Nodes:** {len(dag_nodes)}
**Source Nodes:** {source_count}

{"Full data lineage graph available — enabling verification of data minimisation." if dag_nodes else "Data lineage documentation recommended to demonstrate data minimisation compliance."}

## 5. Data Subject Rights

| Right | Mechanism |
|-------|-----------|
| Access (Art. 15) | Individual data export available |
| Rectification (Art. 16) | Data correction process in place |
| Erasure (Art. 17) | Retention schedule enforced |
| Explanation (Art. 22) | Per-applicant adverse action codes |

## 6. Technical Safeguards

- Access controls: role-based, tenant-isolated
- Audit logging: all model access and outputs logged
- Encryption: data encrypted at rest and in transit
- Retention: training data retained per schedule ({domain or "financial"} regulatory requirements)

## 7. Compliance Status

{_breakdown_table()}

{"**⚠ Remediation Required.** Resolve critical findings before EU deployment." if critical_findings > 0 else "**✓ GDPR Compliant.** No critical data protection findings identified."}
"""

    else:
        title = f"Compliance Report — {model_name}"
        md = f"# {title}\n\n_Report type '{template_type}' is not supported._\n"

    return title, md


def _generate_autodoc_report(template_type, comp, models, fairness,
                             model_id=None):
    """Generate a report using real data from the database."""
    m = {}
    if models:
        m = models[0]
        if model_id:
            for candidate in models:
                if candidate.get("model_id") == model_id:
                    m = candidate
                    break

    m_data = {
        "model_id": m.get("model_id", ""),
        "model_name": (m.get("name") or m.get("display_name")
                       or m.get("model_id", "Unknown Model")),
        "version": m.get("version", ""),
        "domain": m.get("domain", ""),
        "tier": m.get("tier", ""),
    }

    fairlens_data = None
    if fairness:
        target = fairness[0]
        if model_id:
            for f in fairness:
                if f.get("model_id") == model_id:
                    target = f
                    break

        prot_attrs = target.get("protected_attributes", [])
        if isinstance(prot_attrs, str):
            try:
                prot_attrs = json.loads(prot_attrs)
            except (json.JSONDecodeError, TypeError):
                prot_attrs = [prot_attrs] if prot_attrs else []

        details = target.get("details") or {}
        if isinstance(details, str):
            try:
                details = json.loads(details)
            except (json.JSONDecodeError, TypeError):
                details = {}

        has_di = target.get("has_disparate_impact", False)
        worst_ratio = target.get("worst_ratio")
        worst_group = target.get("worst_group")

        di_list = []
        if worst_ratio is not None:
            di_list.append({
                "protected_attribute": worst_group or "unknown",
                "worst_ratio": worst_ratio,
                "has_disparate_impact": has_di,
            })
        if isinstance(details, dict):
            for attr_detail in details.get("per_attribute", []):
                attr_name = attr_detail.get("attribute", "")
                if attr_name and attr_name != worst_group:
                    di_list.append({
                        "protected_attribute": attr_name,
                        "worst_ratio": attr_detail.get("worst_ratio"),
                        "has_disparate_impact": attr_detail.get(
                            "has_disparate_impact", False),
                    })

        fairlens_data = {
            "has_disparate_impact": has_di,
            "worst_ratio": worst_ratio,
            "worst_group": worst_group,
            "p_value": target.get("p_value"),
            "statistically_significant": target.get(
                "statistically_significant", False),
            "protected_attributes": prot_attrs,
            "disparate_impact": di_list,
        }

    dag_nodes = []
    dag_edges = []
    pipeline_name_for_extra = ""
    store = _get_store()
    if store is not None:
        try:
            pipeline_stats = store.get_pipeline_stats(
                tenant_id=g.tenant_id, limit=1)
            if pipeline_stats:
                ps = pipeline_stats[0]
                pipeline_name_for_extra = ps.get("pipeline_name", "")

                prov_ids = _resolve_provenance_ids(store, ps["pipeline_id"])
                prov_id = prov_ids[0]

                nodes_raw = store._read_dicts(
                    "SELECT node_id, node_type, operation, table_name, "
                    "column_name, pair_id, is_protected, metadata "
                    "FROM dag_nodes WHERE pipeline_id = %s ORDER BY node_id",
                    (prov_id,),
                )
                edges_raw = store._read_dicts(
                    "SELECT parent_node_id, child_node_id, input_position "
                    "FROM dag_edges de "
                    "JOIN dag_nodes dn ON de.child_node_id = dn.node_id "
                    "WHERE dn.pipeline_id = %s",
                    (prov_id,),
                )
                for n in nodes_raw:
                    ntype = (n.get("node_type") or "").upper()
                    is_source = ntype in ("SOURCE", "LEAF")
                    dag_nodes.append({
                        "id": n["node_id"],
                        "name": (n.get("column_name") or n.get("operation")
                                 or str(n["node_id"])),
                        "type": "SOURCE" if is_source else ntype,
                        "operation": n.get("operation", ""),
                        "table": n.get("table_name", ""),
                        "column": n.get("column_name", ""),
                        "is_protected": bool(n.get("is_protected")),
                    })
                for e in edges_raw:
                    dag_edges.append({
                        "source": e["parent_node_id"],
                        "target": e["child_node_id"],
                    })
        except Exception as exc:
            logger.warning("Failed to load DAG/pipeline data for report: %s",
                           exc)

    user_validations = (_get_user_records("model_validation", ref_id=model_id)
                        if model_id else [])
    last_validation = (user_validations[0]["payload"]
                       if user_validations else None)

    extra = {
        "compliance_score": comp.get("score"),
        "compliance_grade": comp.get("grade"),
        "breakdowns": comp.get("breakdowns", []),
        "total_findings": comp.get("total_findings", 0),
        "critical_findings": comp.get("critical_findings", 0),
        "model_count": len(models),
        "institution_name": g.tenant_id.replace("_", " ").title(),
        "pipeline_name": pipeline_name_for_extra,
    }
    if last_validation:
        extra["last_validated"] = last_validation.get("validated_at")
        extra["validated_by"] = last_validation.get("validated_by")
        extra["validation_type"] = last_validation.get("validation_type")

    title, markdown = _build_report_markdown(
        template_type, m_data, fairlens_data, dag_nodes, dag_edges, extra
    )
    section_count = sum(
        1 for line in markdown.split("\n") if line.startswith("## ")
    )
    return {
        "title": title,
        "markdown": markdown,
        "section_count": section_count,
    }


def _generate_examiner_package(comp, models, fairness, certs, alerts):
    """Generate an examiner-ready compliance package.

    Only uses real data from the database.  No fabricated content.
    """
    from attestant.examiner.package import ExaminerPackage

    pkg = ExaminerPackage(
        institution_name=g.tenant_id.replace("_", " ").title(),
        examination_type="comprehensive",
        prepared_by="Attestant Compliance Engine",
    )

    breakdowns = comp.get("breakdowns", []) if comp else []
    if isinstance(breakdowns, str):
        try:
            breakdowns = json.loads(breakdowns)
        except (json.JSONDecodeError, TypeError):
            breakdowns = []

    if breakdowns:
        pkg.add_compliance_results({
            "results": [{
                "regulation_name": b.get("regulation", "Unknown"),
                "passed": b.get("passed", False),
                "findings": [],
                "citations": [],
                "summary": {
                    "critical_count": b.get("critical_count", 0),
                    "warning_count": b.get("warning_count", 0),
                },
            } for b in breakdowns]
        })

    if models:
        pkg.add_model_inventory(models)

    for f in fairness:
        pkg.add_fairness_analysis(f)

    if certs:
        pkg.add_certifications({"certifications": certs})

    bundle = pkg.generate()

    lines = [
        f"# Examiner Package: {bundle['package_metadata']['institution_name']}",
        "",
        "**DRAFT - Auto-generated from pipeline data. Requires examiner review.**",
        "",
        f"**Examination Type:** {bundle['package_metadata']['examination_type']}",
        f"**Prepared By:** {bundle['package_metadata']['prepared_by']}",
        f"**Generated:** {bundle['package_metadata']['generated_at']}",
        f"**Completeness:** {bundle['package_metadata']['completeness_score']:.0%}",
        "",
    ]

    summary = bundle.get("summary", {})
    lines.append("## Package Summary")
    lines.append(f"- **Total Sections:** {summary.get('total_sections', 0)}")
    lines.append(f"- **Complete:** {summary.get('complete', 0)}")
    lines.append(f"- **Partial:** {summary.get('partial', 0)}")
    lines.append(f"- **Missing:** {summary.get('missing', 0)}")
    lines.append(f"- **Categories:** "
                 f"{', '.join(summary.get('categories_covered', []))}")
    lines.append("")

    for section in bundle.get("all_sections", []):
        lines.append(f"## {section['title']}")
        lines.append(f"**Category:** {section['category']} "
                     f"| **Status:** {section['status']}")
        if section.get("regulatory_refs"):
            lines.append(
                f"**References:** {', '.join(section['regulatory_refs'])}")

        content = section.get("content", {})
        if isinstance(content, dict) and content:
            _render_examiner_content(lines, content, section['title'])
        lines.append("")

    validation = bundle.get("validation", {})
    if validation.get("missing"):
        lines.append("## Missing Sections")
        for m in validation["missing"]:
            lines.append(f"- {m}")
        lines.append("")
    if validation.get("warnings"):
        lines.append("## Warnings")
        for w in validation["warnings"]:
            lines.append(f"- {w}")
        lines.append("")

    refs = bundle.get("regulatory_references", [])
    if refs:
        lines.append("## Regulatory References")
        for ref in refs:
            lines.append(f"- {ref}")
        lines.append("")

    return {
        "title": f"Examiner Package: {g.tenant_id.replace('_', ' ').title()}",
        "markdown": "\n".join(lines),
        "section_count": summary.get("total_sections", 0),
    }


def _render_examiner_content(lines, content, section_title):
    """Render examiner section content into markdown lines."""
    title_lower = section_title.lower()

    if "compliance" in title_lower:
        passed = content.get("passed")
        if passed is not None:
            lines.append(f"- **Passed:** {'Yes' if passed else 'No'}")
        s = content.get("summary", {})
        if s:
            for k, v in s.items():
                lines.append(f"- **{k}:** {v}")

    elif "model inventory" in title_lower:
        model_count = content.get("model_count", 0)
        lines.append(f"- **Models Under Governance:** {model_count}")
        for m in content.get("models", []):
            name = m.get("name") or m.get("model_id", "Unknown")
            status = m.get("status", "N/A")
            tier = m.get("tier", "N/A")
            lines.append(f"  - {name} (Status: {status}, Tier: {tier})")

    elif "fairness" in title_lower or "fairlens" in title_lower:
        has_di = content.get("has_disparate_impact")
        if has_di is not None:
            lines.append(
                f"- **Disparate Impact Detected:** {'Yes' if has_di else 'No'}")
        worst = content.get("worst_ratio")
        if worst is not None:
            lines.append(f"- **Worst DI Ratio:** {worst}")
        group = content.get("worst_group")
        if group:
            lines.append(f"- **Worst Group:** {group}")
        prot = content.get("protected_attributes", [])
        if isinstance(prot, str):
            try:
                prot = json.loads(prot)
            except (json.JSONDecodeError, TypeError):
                prot = [prot] if prot else []
        if prot:
            lines.append(
                f"- **Protected Attributes:** {', '.join(str(a) for a in prot)}")

    elif "certification" in title_lower:
        cs = content.get("certifications", [])
        for c in cs:
            ctype = c.get("cert_type", "Unknown")
            status = c.get("status", "N/A")
            lines.append(f"- {ctype}: {status}")

    else:
        for k, v in content.items():
            if isinstance(v, (str, int, float, bool)):
                lines.append(f"- **{k}:** {v}")
            elif isinstance(v, list) and len(v) <= 10:
                lines.append(f"- **{k}:** {len(v)} item(s)")
            elif isinstance(v, dict):
                lines.append(f"- **{k}:** (structured data)")


@app.route("/api/quick-wins")
@require_client_auth
def api_quick_wins():
    """Quick win recommendations from CRO features."""
    store = _get_store()
    if store is None:
        return jsonify(_demo_quick_wins())
    comp = store.get_latest_compliance(g.tenant_id)
    if not comp:
        return jsonify([])

    try:
        from attestant.compliance.cro_features import QuickWinRecommender
        from attestant.compliance.score import ComplianceScoreResult, ScoreBreakdown

        breakdowns_raw = comp.get("breakdowns", [])
        if isinstance(breakdowns_raw, str):
            breakdowns_raw = json.loads(breakdowns_raw)

        breakdowns = [
            ScoreBreakdown(
                regulation=bd.get("regulation", "Unknown"),
                weight=bd.get("weight", 1.0),
                critical_count=bd.get("critical_count", 0),
                warning_count=bd.get("warning_count", 0),
                info_count=bd.get("info_count", 0),
                raw_deduction=bd.get("raw_deduction", 0),
                weighted_deduction=bd.get("weighted_deduction", 0),
                passed=bd.get("passed", True),
            )
            for bd in breakdowns_raw
        ]

        top_risks = comp.get("top_risks", [])
        if isinstance(top_risks, str):
            top_risks = json.loads(top_risks)

        score_result = ComplianceScoreResult(
            score=comp.get("score", 0),
            grade=comp.get("grade", "F"),
            timestamp=datetime.now(timezone.utc),
            breakdowns=breakdowns,
            warning_findings=comp.get("warning_findings", 0),
            top_risks=top_risks,
        )

        bonuses = comp.get("bonuses_applied", comp.get("bonuses", {}))
        if isinstance(bonuses, str):
            bonuses = json.loads(bonuses)

        controls = {
            "has_monitoring": "Continuous Monitoring" in bonuses,
            "has_fairness_analysis": "FairLens Analysis" in bonuses,
            "has_decision_logging": "Decision Logging" in bonuses,
            "has_data_governance": "Data Governance" in bonuses,
            "has_model_inventory": "Model Inventory" in bonuses,
            "has_certifications": "Active Certifications" in bonuses,
        }

        recommender = QuickWinRecommender()
        wins = recommender.recommend(score_result, controls, max_recommendations=5)
        return jsonify([w.to_dict() for w in wins])
    except (ImportError, TypeError, KeyError, ValueError) as e:
        logger.error("Quick wins generation failed: %s", e, exc_info=True)
        return jsonify(_demo_quick_wins())


@app.route("/api/risk-heatmap")
@require_client_auth
@require_permission("view_fairness")
def api_risk_heatmap():
    """Risk heatmap data: regulation-by-model matrix."""
    store = _get_store()
    if store is None:
        return jsonify(_demo_risk_heatmap())

    try:
        models = store.get_models(g.tenant_id)
        if not models:
            return jsonify(_demo_risk_heatmap())

        tenant_config = store.get_tenant_config(g.tenant_id)
        applicable_regs = tenant_config.get("applicable_regulations", [])

        comp = store.get_latest_compliance(g.tenant_id) or {}
        breakdowns = comp.get("breakdowns", [])
        if isinstance(breakdowns, str):
            breakdowns = json.loads(breakdowns)

        alerts = store.get_alerts(g.tenant_id, unresolved_only=False)

        fairness_by_model = {}
        for m in models:
            f = store.get_latest_fairness(g.tenant_id, m["model_id"])
            if f:
                fairness_by_model[m["model_id"]] = f

        alert_index = {}
        for a in alerts:
            mid = a.get("model_id") or "__tenant__"
            reg = a.get("regulation", "Unknown")
            key = (mid, reg)
            if key not in alert_index:
                alert_index[key] = {"critical": 0, "warning": 0}
            if a.get("severity") == "critical":
                alert_index[key]["critical"] += 1
            else:
                alert_index[key]["warning"] += 1

        if applicable_regs:
            regulations = applicable_regs
        else:
            reg_set = set()
            for bd in breakdowns:
                reg_set.add(bd.get("regulation", "Unknown"))
            for a in alerts:
                r = a.get("regulation")
                if r:
                    reg_set.add(r)
            regulations = sorted(reg_set)

        if not regulations:
            domains = {m.get("domain", "") for m in models}
            if "lending" in domains or "finance" in domains:
                regulations = ["SR 11-7 / Model Risk", "ECOA / Fair Lending", "EU AI Act"]
            elif "employment" in domains:
                regulations = ["SR 11-7 / Model Risk", "ECOA / Fair Lending", "NYC Local Law 144"]
            elif "insurance" in domains:
                regulations = ["SR 11-7 / Model Risk", "ECOA / Fair Lending", "Colorado AI Regulation"]
            else:
                regulations = ["SR 11-7 / Model Risk", "ECOA / Fair Lending", "EU AI Act"]

        cells = {}
        all_models = []
        model_names = {}

        for m in models:
            mid = m["model_id"]
            all_models.append(mid)
            model_names[mid] = m.get("name", mid)
            cells[mid] = {}

            model_score = m.get("compliance_score")
            model_findings = m.get("finding_count", 0)
            val_overdue = m.get("validation_overdue", False)
            mon_overdue = m.get("monitoring_overdue", False)
            fair = fairness_by_model.get(mid)

            for reg in regulations:
                model_alerts = alert_index.get((mid, reg), {"critical": 0, "warning": 0})
                tenant_alerts = alert_index.get(("__tenant__", reg), {"critical": 0, "warning": 0})

                crits = model_alerts["critical"]
                warns = model_alerts["warning"]

                if crits == 0 and warns == 0 and tenant_alerts["critical"] == 0 and tenant_alerts["warning"] == 0:
                    bd_match = next((bd for bd in breakdowns if bd.get("regulation") == reg), None)
                    if bd_match:
                        tenant_crits = bd_match.get("critical_count", 0)
                        tenant_warns = bd_match.get("warning_count", 0)
                        if model_findings > 0 and tenant_crits > 0:
                            crits += 1
                        if model_findings > 0 and tenant_warns > 0:
                            warns += 1

                if "Fair Lending" in reg or "ECOA" in reg:
                    if fair:
                        if fair.get("has_disparate_impact") and fair.get("statistically_significant"):
                            crits += 1
                        elif fair.get("has_disparate_impact"):
                            warns += 1
                        ratio = fair.get("worst_ratio")
                        if ratio is not None and ratio < 0.80:
                            warns += 1

                if "SR 11-7" in reg or "Model Risk" in reg or "OCC" in reg:
                    if val_overdue:
                        warns += 1
                    if mon_overdue:
                        warns += 1
                    tier = m.get("tier", 3)
                    if tier == 1 and model_findings > 2:
                        crits += 1
                    elif model_findings > 0:
                        warns += 1

                if "EU AI Act" in reg:
                    tier = m.get("tier", 3)
                    if tier == 1 and (model_score is not None and model_score < 80):
                        warns += 1
                    if fair and fair.get("has_disparate_impact"):
                        warns += 1

                if "Colorado" in reg:
                    if fair and fair.get("has_disparate_impact") and fair.get("statistically_significant"):
                        warns += 1
                    if m.get("domain") in ("lending", "insurance", "employment"):
                        if model_score is not None and model_score < 85:
                            warns += 1

                if "NYC" in reg or "Local Law 144" in reg:
                    if m.get("domain") in ("employment", "lending"):
                        if fair and fair.get("has_disparate_impact"):
                            warns += 1

                score = 100
                if model_score is not None:
                    score = model_score
                score = max(0, score - crits * 15 - warns * 5)

                if crits >= 2:
                    risk = "critical"
                elif crits >= 1:
                    risk = "high"
                elif warns >= 2:
                    risk = "medium"
                else:
                    risk = "low"

                cells[mid][reg] = {
                    "risk_level": risk,
                    "score": round(score),
                    "critical_count": crits,
                    "warning_count": warns,
                }

        total = sum(len(v) for v in cells.values())
        return jsonify({
            "models": all_models,
            "model_names": model_names,
            "regulations": regulations,
            "cells": cells,
            "summary": {
                "total_cells": total,
                "critical_cells": sum(
                    1 for mid in cells for reg in cells[mid]
                    if cells[mid][reg]["risk_level"] == "critical"
                ),
                "high_cells": sum(
                    1 for mid in cells for reg in cells[mid]
                    if cells[mid][reg]["risk_level"] == "high"
                ),
            },
        })
    except (ImportError, TypeError, KeyError, ValueError, json.JSONDecodeError) as e:
        logger.error("Risk heatmap generation failed: %s", e, exc_info=True)
        return jsonify(_demo_risk_heatmap())


@app.route("/api/remediation-queue")
@require_client_auth
def api_remediation_queue():
    """Prioritized remediation queue from CRO features."""
    store = _get_store()
    if store is None:
        return jsonify(_demo_remediation_queue())

    try:
        alerts = store.get_alerts(g.tenant_id, unresolved_only=True)
        if not alerts:
            return jsonify(_demo_remediation_queue())

        from attestant.compliance.cro_features import _REGULATION_RISK
        items = []
        now = datetime.now(timezone.utc)

        for a in alerts:
            if a.get("resolved"):
                continue
            sev = a.get("severity", "info")
            reg = a.get("regulation", "")
            reg_risk = _REGULATION_RISK.get(reg, 1.0)
            sev_mult = 3.0 if sev == "critical" else 1.0
            deadline_days = {"ECOA / Reg B": 30, "SR 11-7 / OCC 2011-12": 60}.get(reg, 90)
            deadline_factor = max(0.5, 2.0 - (deadline_days / 60.0))
            priority_score = sev_mult * reg_risk * deadline_factor

            if priority_score >= 5:
                priority = "urgent"
            elif priority_score >= 3:
                priority = "high"
            elif priority_score >= 1.5:
                priority = "medium"
            else:
                priority = "low"

            items.append({
                "item_id": f"rem-{a.get('id', 0):03d}",
                "regulation": reg,
                "finding_description": a.get("title", ""),
                "remediation_action": a.get("description", "Review and address this finding"),
                "priority": priority,
                "priority_score": round(priority_score, 2),
                "severity": sev.upper(),
                "deadline": (now + timedelta(days=deadline_days)).isoformat(),
                "business_impact": (
                    "Potential enforcement action" if sev == "critical"
                    else "Compliance gap requiring attention"
                ),
                "affected_models": [a["model_id"]] if a.get("model_id") else [],
            })

        items.sort(key=lambda x: -x["priority_score"])
        return jsonify(items)
    except (ImportError, TypeError, KeyError, ValueError) as e:
        logger.error("Remediation queue generation failed: %s", e, exc_info=True)
        return jsonify(_demo_remediation_queue())


@app.route("/api/peer-comparison")
@require_client_auth
def api_peer_comparison():
    """Peer comparison benchmarks from CRO features."""
    store = _get_store()
    tier = request.args.get("tier", "mid")

    if store is None:
        return jsonify(_demo_peer_comparison())
    comp = store.get_latest_compliance(g.tenant_id)
    if not comp:
        return jsonify([])

    try:
        from attestant.compliance.cro_features import PeerBenchmark
        from attestant.compliance.score import ComplianceScoreResult, ScoreBreakdown

        breakdowns_raw = comp.get("breakdowns", [])
        if isinstance(breakdowns_raw, str):
            breakdowns_raw = json.loads(breakdowns_raw)

        breakdowns = [
            ScoreBreakdown(
                regulation=bd.get("regulation", "Unknown"),
                weight=bd.get("weight", 1.0),
                critical_count=bd.get("critical_count", 0),
                warning_count=bd.get("warning_count", 0),
                info_count=bd.get("info_count", 0),
                raw_deduction=bd.get("raw_deduction", 0),
                weighted_deduction=bd.get("weighted_deduction", 0),
                passed=bd.get("passed", True),
            )
            for bd in breakdowns_raw
        ]

        score_result = ComplianceScoreResult(
            score=comp.get("score", 0),
            grade=comp.get("grade", "F"),
            timestamp=datetime.now(timezone.utc),
            breakdowns=breakdowns,
        )

        benchmark = PeerBenchmark(institution_tier=tier)
        result = benchmark.compare(score_result)
        return jsonify(result.to_dict())
    except (ImportError, TypeError, KeyError, ValueError) as e:
        logger.error("Peer comparison failed: %s", e, exc_info=True)
        return jsonify(_demo_peer_comparison())


# ---------------------------------------------------------------------------
# New API endpoints: Attestations, Exceptions, Regulatory Changes
# ---------------------------------------------------------------------------

@app.route("/api/attestations", methods=["GET", "POST"])
@require_client_auth
@require_permission("view_compliance")
def api_attestations():
    """List or create model attestations backed by Aurora."""
    store = _get_store()
    tenant_id = g.tenant_id

    if request.method == "POST":
        if not request.is_json:
            return jsonify({"error": "JSON body required"}), 400
        body = request.json or {}
        model_id = (body.get("model_id") or "").strip()
        if not model_id:
            return jsonify({"error": "model_id is required"}), 400

        model_name = body.get("model_name") or model_id
        version = body.get("version")
        notes = body.get("notes")
        attested_by = request.current_user["email"]

        compliance_score = None
        if store:
            try:
                snap = store._read_dict(
                    "select score from compliance_snapshots where tenant_id = %s "
                    "order by snapshot_at desc limit 1",
                    (tenant_id,),
                )
                if snap:
                    compliance_score = snap["score"]
            except Exception:
                pass

            try:
                row = store.create_attestation(
                    tenant_id=tenant_id,
                    model_id=model_id,
                    model_name=model_name,
                    version=version,
                    attested_by=attested_by,
                    compliance_score=compliance_score,
                    notes=notes,
                )
                return jsonify({"ok": True, "attestation": row}), 201
            except Exception as e:
                logger.exception("Failed to create attestation")
                return jsonify({"error": "Failed to save attestation"}), 500

        return jsonify({"ok": True, "attestation": {
            "model_id": model_id, "attested_by": attested_by, "status": "active",
        }}), 201

    if store is None:
        return jsonify([])

    try:
        rows = store.get_attestations(tenant_id)
        for r in rows:
            if isinstance(r.get("attested_at"), datetime):
                r["attested_at"] = r["attested_at"].isoformat()
            if r.get("compliance_score") is not None:
                r["compliance_score"] = float(r["compliance_score"])
            # Remap fields to match UI contract
            r["model_version"] = r.get("version")
            r["created_at"] = r.get("attested_at")
            r["signed_at"] = r.get("attested_at")
            r["signed_by"] = r.get("attested_by") or "Attestant API"
            _status = (r.get("status") or "active").lower()
            r["approved"] = _status == "approved"
            r["blocked"] = _status in ("blocked", "blocked_by_gate")
            try:
                import json as _json
                _notes_raw = r.get("notes") or "{}"
                _notes_dict = _json.loads(_notes_raw) if isinstance(_notes_raw, str) else (_notes_raw or {})
            except Exception:
                _notes_dict = {}
            r["blocking_findings"] = _notes_dict.get("blocking_findings", [])
            r["warning_findings"] = _notes_dict.get("warning_findings", [])
        return jsonify(rows)
    except Exception:
        logger.exception("Failed to fetch attestations")
        return jsonify([])


@app.route("/api/attestations/sign", methods=["POST"])
@require_client_auth
@require_permission("view_compliance")
def api_sign_attestation():
    """Alias for POST /api/attestations — kept for frontend compatibility."""
    if not request.is_json:
        return jsonify({"error": "JSON body required"}), 400

    body = request.json or {}
    model_id = (body.get("model_id") or "").strip()
    if not model_id:
        return jsonify({"error": "model_id is required"}), 400

    store = _get_store()
    tenant_id = g.tenant_id
    attested_by = request.current_user["email"]
    model_name = body.get("model_name") or model_id
    version = body.get("version")
    notes = body.get("notes")

    compliance_score = None
    if store:
        try:
            snap = store._read_dict(
                "select score from compliance_snapshots where tenant_id = %s "
                "order by snapshot_at desc limit 1",
                (tenant_id,),
            )
            if snap:
                compliance_score = snap["score"]
        except Exception:
            pass

    if store:
        try:
            row = store.create_attestation(
                tenant_id=tenant_id,
                model_id=model_id,
                model_name=model_name,
                version=version,
                attested_by=attested_by,
                compliance_score=compliance_score,
                notes=notes,
            )
            if isinstance(row.get("attested_at"), datetime):
                row["attested_at"] = row["attested_at"].isoformat()
            if row.get("compliance_score") is not None:
                row["compliance_score"] = float(row["compliance_score"])
            return jsonify({"ok": True, "attestation": row})
        except Exception:
            logger.exception("Failed to sign attestation")
            return jsonify({"error": "Failed to save attestation"}), 500

    return jsonify({"ok": True, "attestation": {
        "model_id": model_id, "attested_by": attested_by, "status": "active",
    }})


@app.route("/api/exceptions", methods=["GET", "POST"])
@require_client_auth
@require_permission("view_compliance")
def api_exceptions():
    """List or create compliance exceptions backed by Aurora."""
    store = _get_store()
    tenant_id = g.tenant_id

    if request.method == "POST":
        if not request.is_json:
            return jsonify({"error": "JSON body required"}), 400
        body = request.json or {}
        model_id = (body.get("model_id") or "").strip()
        check_id = (body.get("check_id") or "").strip()
        justification = (body.get("justification") or "").strip()
        if not model_id or not check_id or not justification:
            return jsonify({"error": "model_id, check_id, and justification are required"}), 400

        approved_by = request.current_user["email"]

        if store:
            try:
                row = store.create_exception(
                    tenant_id=tenant_id,
                    model_id=model_id,
                    model_name=body.get("model_name"),
                    check_id=check_id,
                    check_label=body.get("check_label"),
                    regulation=body.get("regulation"),
                    severity=body.get("severity"),
                    justification=justification,
                    approved_by=approved_by,
                    expires_at=body.get("expires_at"),
                )
                for field in ("approved_at", "expires_at"):
                    if isinstance(row.get(field), datetime):
                        row[field] = row[field].isoformat()
                return jsonify({"ok": True, "exception": row}), 201
            except Exception:
                logger.exception("Failed to create exception")
                return jsonify({"error": "Failed to save exception"}), 500

        return jsonify({"ok": True, "exception": {
            "model_id": model_id, "check_id": check_id, "status": "active",
        }}), 201

    if store is None:
        return jsonify({
            "total_exceptions": 0, "active_exceptions": 0,
            "expired_exceptions": 0, "exceptions": [],
        })

    try:
        rows = store.get_exceptions(tenant_id)
        for r in rows:
            for field in ("approved_at", "expires_at"):
                if isinstance(r.get(field), datetime):
                    r[field] = r[field].isoformat()
            r["reason"] = r.get("justification", "")

        now = datetime.now(timezone.utc)
        active = [r for r in rows if r.get("status") == "active" and (
            r.get("expires_at") is None or r["expires_at"] > now.isoformat()
        )]
        expired = [r for r in rows if r.get("status") == "expired" or (
            r.get("expires_at") is not None and r["expires_at"] <= now.isoformat()
        )]

        return jsonify({
            "total_exceptions": len(rows),
            "active_exceptions": len(active),
            "expired_exceptions": len(expired),
            "exceptions": rows,
        })
    except Exception:
        logger.exception("Failed to fetch exceptions")
        return jsonify({
            "total_exceptions": 0, "active_exceptions": 0,
            "expired_exceptions": 0, "exceptions": [],
        })


@app.route("/api/exceptions/<int:exception_id>/approve", methods=["POST"])
@require_client_auth
@require_permission("view_compliance")
def api_approve_exception(exception_id):
    """Mark a compliance exception as approved."""
    store = _get_store()
    tenant_id = g.tenant_id

    if store is None:
        return jsonify({"ok": True, "exception_id": exception_id, "status": "approved"})

    try:
        store.set_exception_status(tenant_id, exception_id, "approved")
        return jsonify({"ok": True, "exception_id": exception_id, "status": "approved"})
    except Exception:
        logger.exception("Failed to approve exception %s", exception_id)
        return jsonify({"error": "Failed to approve exception"}), 500


_REGULATORY_CHANGES = [
    {
        "id": "rc-001",
        "title": "SR 11-7 Supplemental Guidance on AI/ML Models",
        "regulation": "SR 11-7",
        "type": "guidance",
        "status": "effective",
        "effective_date": "2024-01-15",
        "summary": "Federal Reserve clarifies model risk governance expectations for machine learning models, including explainability and ongoing monitoring requirements.",
        "impact": "high",
        "impact_level": "high",
        "action_required": "Review model documentation and monitoring cadence for ML models in production.",
    },
    {
        "id": "rc-002",
        "title": "EU AI Act — High-Risk AI Systems Compliance Deadline",
        "regulation": "EU AI Act",
        "type": "deadline",
        "status": "upcoming",
        "effective_date": "2026-08-02",
        "summary": "All high-risk AI systems deployed in the EU must achieve full compliance with EU AI Act requirements including conformity assessments and technical documentation.",
        "impact": "critical",
        "impact_level": "critical",
        "action_required": "Complete EU AI Act compliance assessment for all applicable models before deadline.",
    },
    {
        "id": "rc-003",
        "title": "CFPB Circular on AI Credit Decisioning",
        "regulation": "ECOA",
        "type": "circular",
        "status": "effective",
        "effective_date": "2023-09-19",
        "summary": "CFPB confirms that ECOA and Reg B adverse action notice requirements apply to AI-driven credit decisions. Creditors must provide specific reasons even when using complex models.",
        "impact": "high",
        "impact_level": "high",
        "action_required": "Ensure adverse action reason codes are generated for all AI credit decisions.",
    },
    {
        "id": "rc-004",
        "title": "OCC Model Risk Management Handbook Update",
        "regulation": "SR 11-7",
        "type": "handbook",
        "status": "upcoming",
        "effective_date": "2025-06-01",
        "summary": "OCC revising model risk management examination procedures to address generative AI and foundation models. Expanded scope of model inventory expectations.",
        "impact": "medium",
        "impact_level": "medium",
        "action_required": "Expand model inventory to include foundation models and third-party AI components.",
    },
    {
        "id": "rc-005",
        "title": "EU AI Act — GPAI Model Obligations",
        "regulation": "EU AI Act",
        "type": "deadline",
        "status": "effective",
        "effective_date": "2025-08-02",
        "summary": "General-purpose AI model providers must maintain technical documentation, comply with copyright law, and publish summaries of training data.",
        "impact": "medium",
        "impact_level": "medium",
        "action_required": "Assess any foundation models in use for GPAI compliance obligations.",
    },
]


@app.route("/api/regulatory-changes")
@require_client_auth
def api_regulatory_changes():
    """Return curated list of regulatory events and deadlines."""
    result = []
    for item in _REGULATORY_CHANGES:
        row = dict(item)
        if "effective_date" in row and "date" not in row:
            row["date"] = row["effective_date"]
        result.append(row)
    return jsonify(result)


# ---------------------------------------------------------------------------
# Remaining demo data helpers
# ---------------------------------------------------------------------------

def _demo_quick_wins():
    return []


def _demo_risk_heatmap():
    return {
        "models": [], "model_names": {}, "regulations": [], "cells": {},
        "summary": {"total_cells": 0, "critical_cells": 0, "high_cells": 0},
    }


def _demo_remediation_queue():
    return []


def _demo_peer_comparison():
    return {}


@app.route("/api/action-items")
@require_client_auth
def api_action_items():
    """Prioritized remediation action items -- what the CRO should do next."""
    store = _get_store()

    if store is None:
        alerts = [a for a in _demo_alerts() if not a.get("resolved")]
        models = _demo_models()
        fairness = _demo_fairness()
    else:
        alerts = store.get_alerts(g.tenant_id, unresolved_only=True)
        models = store.get_models(g.tenant_id)
        fairness_list = []
        for m in models:
            f = store.get_latest_fairness(g.tenant_id, m["model_id"])
            if f:
                fairness_list.append(f)
        fairness = fairness_list

    items = []

    for a in alerts:
        items.append({
            "priority": 1 if a["severity"] == "critical" else 2,
            "type": "alert",
            "title": a["title"],
            "description": a.get("description", ""),
            "source": a.get("source", ""),
            "model_id": a.get("model_id"),
            "regulation": a.get("regulation"),
            "severity": a["severity"],
            "alert_id": a.get("id"),
        })

    seen_blocked = set()
    for m in models:
        score = m.get("compliance_score")
        is_blocked = m.get("status") == "blocked" or (score is not None and score < 40)
        if is_blocked and m["model_id"] not in seen_blocked:
            seen_blocked.add(m["model_id"])
            display_name = m["name"].replace("_", " ").title()
            items.append({
                "priority": 1,
                "type": "deployment",
                "title": f"{display_name} v{m.get('version', '?')} blocked from production",
                "description": (
                    f"Compliance score {score}/100. Complete validation requirements before deployment."
                    if score is not None
                    else "Model has not completed compliance validation."
                ),
                "source": "DeploymentGate",
                "model_id": m["model_id"],
                "regulation": "SR 11-7 / OCC 2011-12",
                "severity": "critical",
            })

    for m in models:
        if m.get("validation_overdue"):
            items.append({
                "priority": 1 if m.get("tier") == 1 else 2,
                "type": "validation",
                "title": f"Schedule validation for {m['name']}",
                "description": f"Tier {m.get('tier', '?')} model validation overdue per SR 11-7.",
                "source": "ModelRegistry",
                "model_id": m["model_id"],
                "regulation": "SR 11-7 / OCC 2011-12",
                "severity": "critical" if m.get("tier") == 1 else "warning",
            })

    for f in fairness:
        if f.get("has_disparate_impact") and f.get("statistically_significant"):
            items.append({
                "priority": 1,
                "type": "fairness",
                "title": f"Remediate disparate impact in {f['model_id']}",
                "description": f"Selection rate ratio {f.get('worst_ratio', 0):.2f} for {f.get('worst_group', '?')} (p={f.get('p_value', 0):.3f}).",
                "source": "FairLens",
                "model_id": f["model_id"],
                "regulation": "ECOA / Reg B",
                "severity": "critical",
            })

    sev_order = {"critical": 0, "warning": 1, "info": 2}
    items.sort(key=lambda x: (x["priority"], sev_order.get(x["severity"], 3)))

    return jsonify(items)


def _resolve_provenance_ids(store, dashboard_pipeline_id):
    """Map a pipeline_stats.id to the corresponding pipeline_metadata pipeline_id(s).

    The dashboard dropdown uses pipeline_stats.id, but provenance tables
    (dag_nodes, dag_edges, row_values) use pipeline_metadata.pipeline_id.
    This resolves between the two via pipeline_name + tenant_id.
    """
    try:
        name_rows = store._read_dicts(
            "SELECT pipeline_name FROM pipeline_stats WHERE id = %s AND tenant_id = %s",
            (dashboard_pipeline_id, g.tenant_id),
        )
        if not name_rows:
            return [dashboard_pipeline_id]

        pipeline_name = name_rows[0]["pipeline_name"]

        prov_rows = store._read_dicts(
            "SELECT pipeline_id FROM pipeline_metadata "
            "WHERE pipeline_name = %s AND tenant_id = %s "
            "ORDER BY pipeline_id DESC",
            (pipeline_name, g.tenant_id),
        )
        if prov_rows:
            return [r["pipeline_id"] for r in prov_rows]
    except Exception as e:
        logger.warning("Failed to resolve provenance IDs for pipeline %s: %s",
                       dashboard_pipeline_id, e)

    return [dashboard_pipeline_id]


@app.route("/api/dag/<int:pipeline_id>")
@require_client_auth
def api_dag(pipeline_id):
    """Get DAG node/edge data for a specific pipeline run."""
    store = _get_store()

    if store is None:
        return jsonify(_demo_dag(pipeline_id))

    try:
        prov_ids = _resolve_provenance_ids(store, pipeline_id)
        prov_id = prov_ids[0]

        nodes_sql = """SELECT node_id, node_type, operation, table_name, column_name,
                              pair_id, is_protected, metadata
                       FROM dag_nodes WHERE pipeline_id = %s ORDER BY node_id"""
        edges_sql = """SELECT parent_node_id, child_node_id, input_position
                       FROM dag_edges de
                       JOIN dag_nodes dn ON de.child_node_id = dn.node_id
                       WHERE dn.pipeline_id = %s"""
        nodes_raw = store._read_dicts(nodes_sql, (prov_id,))
        edges_raw = store._read_dicts(edges_sql, (prov_id,))

        if not nodes_raw:
            return jsonify(_demo_dag(pipeline_id))

        nodes = {}
        for n in nodes_raw:
            nodes[str(n["node_id"])] = {
                "node_type": n["node_type"],
                "operation": n["operation"] or n.get("column_name", ""),
                "table": n.get("table_name"),
                "column": n.get("column_name"),
                "is_protected": n.get("is_protected", False),
            }

        edges = [{"source": e["parent_node_id"], "target": e["child_node_id"],
                  "input_index": e.get("input_position", 0)} for e in edges_raw]

        max_id = max(int(k) for k in nodes.keys()) if nodes else 0

        return jsonify({"nodes": nodes, "edges": edges, "root_id": max_id, "depth": 4})
    except Exception as e:
        logger.error("DAG query failed for pipeline %s: %s", pipeline_id, e)
        return jsonify(_demo_dag(pipeline_id))


def _demo_dag(pipeline_id):
    return {"nodes": {}, "edges": [], "root_id": 0, "depth": 0}


# ---------------------------------------------------------------------------
# Row-Values (Value-Level Lineage) Endpoints
# ---------------------------------------------------------------------------

def _demo_row_values_rows(pipeline_id):
    return []


def _demo_row_values_detail(pipeline_id, row_index):
    return []


@app.route("/api/row-values/<int:pipeline_id>/rows")
@require_client_auth
def api_row_values_rows(pipeline_id):
    """List available row indices with value-level data for a pipeline."""
    store = _get_store()
    if store is None:
        return jsonify({"rows": _demo_row_values_rows(pipeline_id)})

    try:
        prov_ids = _resolve_provenance_ids(store, pipeline_id)
        placeholders = ",".join(["%s"] * len(prov_ids))
        sql = (
            "SELECT row_index, COUNT(*) as value_count "
            "FROM row_values "
            f"WHERE pipeline_id IN ({placeholders}) AND tenant_id = %s "
            "GROUP BY row_index "
            "ORDER BY row_index "
            "LIMIT 500"
        )
        rows_raw = store._read_dicts(sql, tuple(prov_ids) + (g.tenant_id,))
        rows = []
        for r in rows_raw:
            rows.append({
                "row_index": r["row_index"],
                "label": None,
                "value_count": r["value_count"],
            })
        return jsonify({"rows": rows})
    except Exception as e:
        logger.error("row_values rows query failed for pipeline %s: %s", pipeline_id, e)
        return jsonify({"rows": _demo_row_values_rows(pipeline_id)})


@app.route("/api/row-values/<int:pipeline_id>/<int:row_index>")
@require_client_auth
def api_row_values_detail(pipeline_id, row_index):
    """Get all tracked values for a specific row in a pipeline."""
    store = _get_store()
    if store is None:
        return jsonify({"values": _demo_row_values_detail(pipeline_id, row_index)})

    try:
        prov_ids = _resolve_provenance_ids(store, pipeline_id)
        placeholders = ",".join(["%s"] * len(prov_ids))
        sql = (
            "SELECT fingerprint, node_operation, column_name, value, text_value "
            "FROM row_values "
            f"WHERE pipeline_id IN ({placeholders}) AND row_index = %s AND tenant_id = %s "
            "ORDER BY value_id"
        )
        rows_raw = store._read_dicts(sql, tuple(prov_ids) + (row_index, g.tenant_id))
        values = []
        for r in rows_raw:
            display_value = r.get("value")
            if display_value is None:
                display_value = r.get("text_value")
            values.append({
                "fingerprint": r["fingerprint"],
                "node_operation": r["node_operation"],
                "column_name": r.get("column_name"),
                "value": display_value,
            })
        return jsonify({"values": values})
    except Exception as e:
        logger.error("row_values detail query failed for pipeline %s row %s: %s",
                     pipeline_id, row_index, e)
        return jsonify({"values": _demo_row_values_detail(pipeline_id, row_index)})


@app.route("/api/row-values/<int:pipeline_id>/search")
@require_client_auth
def api_row_values_search(pipeline_id):
    """Search row-values for a specific applicant by row index or identifier column value."""
    store = _get_store()
    query = (request.args.get("q") or "").strip()
    if not query:
        return jsonify({"rows": []})

    if store is None:
        return jsonify({"rows": []})

    try:
        prov_ids = _resolve_provenance_ids(store, pipeline_id)
        placeholders = ",".join(["%s"] * len(prov_ids))
        rows = []

        if query.isdigit():
            row_idx = int(query)
            sql = (
                "SELECT row_index, COUNT(*) AS value_count "
                "FROM row_values "
                f"WHERE pipeline_id IN ({placeholders}) AND tenant_id = %s "
                "AND row_index = %s "
                "GROUP BY row_index"
            )
            rows_raw = store._read_dicts(sql, tuple(prov_ids) + (g.tenant_id, row_idx))
            for r in rows_raw:
                rows.append({
                    "row_index": r["row_index"],
                    "label": None,
                    "value_count": r["value_count"],
                })
        else:
            id_columns = (
                "applicant_id", "customer_id", "account_id", "loan_id",
                "borrower_id", "client_id", "member_id", "person_id",
                "ssn", "id", "application_id", "case_id",
            )
            col_placeholders = ",".join(["%s"] * len(id_columns))
            like_val = "%" + query + "%"
            sql = (
                "SELECT DISTINCT rv.row_index, sub.value_count "
                "FROM row_values rv "
                "JOIN ("
                "  SELECT row_index, COUNT(*) AS value_count "
                "  FROM row_values "
                f"  WHERE pipeline_id IN ({placeholders}) AND tenant_id = %s "
                "  GROUP BY row_index"
                ") sub ON sub.row_index = rv.row_index "
                f"WHERE rv.pipeline_id IN ({placeholders}) AND rv.tenant_id = %s "
                f"AND LOWER(rv.column_name) IN ({col_placeholders}) "
                "AND CAST(rv.value AS TEXT) ILIKE %s "
                "ORDER BY rv.row_index "
                "LIMIT 50"
            )
            params = (
                tuple(prov_ids) + (g.tenant_id,)
                + tuple(prov_ids) + (g.tenant_id,)
                + id_columns
                + (like_val,)
            )
            rows_raw = store._read_dicts(sql, params)
            for r in rows_raw:
                rows.append({
                    "row_index": r["row_index"],
                    "label": None,
                    "value_count": r["value_count"],
                })

        return jsonify({"rows": rows})
    except Exception as e:
        logger.error("row_values search failed for pipeline %s query %r: %s",
                     pipeline_id, query, e)
        return jsonify({"rows": []})


# ---------------------------------------------------------------------------
# User Data Upload Endpoints (stored in Aurora client_user_data table)
# ---------------------------------------------------------------------------

@app.route("/api/all-validations")
@require_client_auth
def api_all_validations():
    """All model validation records for this tenant."""
    return jsonify(_get_user_records("model_validation"))


@app.route("/api/models/<model_id>/validations", methods=["GET", "POST"])
@require_client_auth
def api_model_validations(model_id):
    """GET: list validation history for a model. POST: record a new validation event."""
    if request.method == "GET":
        rows = _get_user_records("model_validation", ref_id=model_id)
        result = []
        for r in rows:
            p = r.get("payload") or {}
            result.append({
                "id": r.get("id"),
                "validated_at": p.get("validated_at") or r.get("created_at"),
                "validator": p.get("validated_by") or p.get("validator", ""),
                "validation_type": p.get("validation_type", ""),
                "result": p.get("result", ""),
                "status": p.get("result") or p.get("status", ""),
                "notes": p.get("notes", ""),
                "created_at": r.get("created_at"),
            })
        return jsonify(result)
    if not request.is_json:
        return jsonify({"error": "JSON body required"}), 400
    data = request.json
    payload = {
        "validated_at": data.get("validated_at"),
        "validated_by": data.get("validated_by", ""),
        "validation_type": data.get("validation_type", "annual"),
        "next_due": data.get("next_due", ""),
        "validator_type": data.get("validator_type", "internal"),
        "notes": data.get("notes", ""),
    }
    if not payload["validated_at"] or not payload["validated_by"]:
        return jsonify({"error": "validated_at and validated_by are required"}), 400
    record_id = _save_user_record("model_validation", model_id, payload)
    if record_id is None:
        return jsonify({"error": "Failed to save — check Aurora connection"}), 500
    return jsonify({"ok": True, "id": record_id})


@app.route("/api/all-model-notes")
@require_client_auth
def api_all_model_notes():
    """All model notes for this tenant."""
    return jsonify(_get_user_records("model_note"))


@app.route("/api/models/<model_id>/notes", methods=["POST"])
@require_client_auth
def api_add_model_note(model_id):
    """Add a documentation note to a model."""
    if not request.is_json:
        return jsonify({"error": "JSON body required"}), 400
    data = request.json
    payload = {
        "author": data.get("author", "Dashboard User"),
        "content": data.get("content", ""),
        "category": data.get("category", "general"),
    }
    if not payload["content"]:
        return jsonify({"error": "content is required"}), 400
    record_id = _save_user_record("model_note", model_id, payload)
    if record_id is None:
        return jsonify({"error": "Failed to save — check Aurora connection"}), 500
    return jsonify({"ok": True, "id": record_id})


@app.route("/api/events")
@require_client_auth
def api_events_list():
    """List custom events/deadlines for this tenant."""
    return jsonify(_get_user_records("custom_event"))


@app.route("/api/events", methods=["POST"])
@require_client_auth
def api_add_event():
    """Add a custom event or deadline."""
    if not request.is_json:
        return jsonify({"error": "JSON body required"}), 400
    data = request.json
    payload = {
        "title": data.get("title", ""),
        "event_date": data.get("event_date", ""),
        "event_type": data.get("event_type", "deadline"),
        "description": data.get("description", ""),
    }
    if not payload["title"] or not payload["event_date"]:
        return jsonify({"error": "title and event_date are required"}), 400
    record_id = _save_user_record("custom_event", None, payload)
    if record_id is None:
        return jsonify({"error": "Failed to save — check Aurora connection"}), 500
    return jsonify({"ok": True, "id": record_id})


@app.route("/api/events/<int:event_id>", methods=["DELETE"])
@require_client_auth
def api_delete_event(event_id):
    """Delete a custom event."""
    return jsonify({"ok": _delete_user_record(event_id)})


@app.route("/api/remediation-updates")
@require_client_auth
def api_remediation_updates():
    """All remediation status updates for this tenant."""
    return jsonify(_get_user_records("remediation_update"))


@app.route("/api/remediation/<item_id>/update", methods=["POST"])
@require_client_auth
def api_update_remediation(item_id):
    """Record a remediation status update."""
    if not request.is_json:
        return jsonify({"error": "JSON body required"}), 400
    data = request.json
    payload = {
        "status": data.get("status", "in_progress"),
        "assigned_to": data.get("assigned_to", ""),
        "target_date": data.get("target_date", ""),
        "notes": data.get("notes", ""),
    }
    record_id = _save_user_record("remediation_update", item_id, payload)
    if record_id is None:
        return jsonify({"error": "Failed to save — check Aurora connection"}), 500
    return jsonify({"ok": True, "id": record_id})


@app.route("/api/user-data/<int:record_id>", methods=["DELETE"])
@require_client_auth
def api_delete_user_data(record_id):
    """Delete any user-entered record."""
    return jsonify({"ok": _delete_user_record(record_id)})


# ---------------------------------------------------------------------------
# Data Management endpoints
# ---------------------------------------------------------------------------

@app.route("/api/storage-summary")
@require_client_auth
def api_storage_summary():
    store = _get_store()
    if store is None:
        return jsonify({"error": "Service unavailable"}), 503
    summary = store.get_storage_summary(g.tenant_id)
    return jsonify(summary)


@app.route("/api/data/delete-alerts", methods=["POST"])
@require_client_auth
@require_role("admin")
def api_delete_alerts_bulk():
    store = _get_store()
    if store is None:
        return jsonify({"error": "Service unavailable"}), 503
    body = request.get_json(silent=True) or {}
    max_age_days = int(body.get("max_age_days", 30))
    include_unresolved = bool(body.get("include_unresolved", False))
    if max_age_days < 30:
        return jsonify({"error": "min age is 30 days"}), 400
    deleted = store.delete_alerts_bulk(g.tenant_id, max_age_days, include_unresolved)
    store.log_deletion(
        g.tenant_id, request.current_user["email"],
        "bulk_delete_alerts", "alert_log", None,
        deleted, {"max_age_days": max_age_days, "include_unresolved": include_unresolved},
    )
    return jsonify({"ok": True, "deleted": deleted})


@app.route("/api/data/delete-snapshots", methods=["POST"])
@require_client_auth
@require_role("admin")
def api_delete_snapshots_bulk():
    store = _get_store()
    if store is None:
        return jsonify({"error": "Service unavailable"}), 503
    body = request.get_json(silent=True) or {}
    max_age_days = int(body.get("max_age_days", 90))
    if max_age_days < 90:
        return jsonify({"error": "min age is 90 days"}), 400
    deleted = store.delete_snapshots_bulk(g.tenant_id, max_age_days)
    total = deleted.get("compliance", 0) + deleted.get("fairness", 0)
    store.log_deletion(
        g.tenant_id, request.current_user["email"],
        "bulk_delete_snapshots", "snapshots", None,
        total, {"max_age_days": max_age_days, "breakdown": deleted},
    )
    return jsonify({"ok": True, "deleted": deleted})


@app.route("/api/data/delete-pipeline-history", methods=["POST"])
@require_client_auth
@require_role("admin")
def api_delete_pipeline_history_bulk():
    store = _get_store()
    if store is None:
        return jsonify({"error": "Service unavailable"}), 503
    body = request.get_json(silent=True) or {}
    max_age_days = int(body.get("max_age_days", 30))
    if max_age_days < 30:
        return jsonify({"error": "min age is 30 days"}), 400
    deleted = store.delete_pipeline_history_bulk(g.tenant_id, max_age_days)
    store.log_deletion(
        g.tenant_id, request.current_user["email"],
        "bulk_delete_pipeline_history", "pipeline_row_results", None,
        deleted, {"max_age_days": max_age_days},
    )
    return jsonify({"ok": True, "deleted": deleted})


@app.route("/api/data/models/<model_id>", methods=["DELETE"])
@require_client_auth
@require_role("admin")
def api_delete_model_all_data(model_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Service unavailable"}), 503
    models = store.get_models(g.tenant_id)
    known_ids = {m.get("model_id") or m.get("name") for m in models}
    if model_id not in known_ids:
        return jsonify({"error": "Model not found"}), 404
    deleted = store.delete_model_all_data(g.tenant_id, model_id)
    total = sum(deleted.values())
    store.log_deletion(
        g.tenant_id, request.current_user["email"],
        "delete_model", "model", model_id,
        total, {"breakdown": deleted},
    )
    return jsonify({"ok": True, "deleted": deleted})


@app.route("/api/data/compliance-snapshots/<int:snapshot_id>", methods=["DELETE"])
@require_client_auth
@require_role("admin")
def api_delete_compliance_snapshot(snapshot_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Service unavailable"}), 503
    latest = store.get_latest_compliance(g.tenant_id)
    if latest and latest.get("id") == snapshot_id:
        return jsonify({"error": "Cannot delete latest compliance snapshot"}), 409
    deleted = store.delete_compliance_snapshot(g.tenant_id, snapshot_id)
    if deleted:
        store.log_deletion(
            g.tenant_id, request.current_user["email"],
            "delete_compliance_snapshot", "compliance_snapshots", str(snapshot_id),
            deleted, {},
        )
    return jsonify({"ok": True, "deleted": deleted})


@app.route("/api/data/deletion-history")
@require_client_auth
@require_role("admin")
def api_deletion_history():
    store = _get_store()
    if store is None:
        return jsonify({"history": []}), 503
    history = store.get_deletion_history(g.tenant_id)
    return jsonify({"history": history})


# ---------------------------------------------------------------------------
# Production error handlers — prevent stack trace leakage
# ---------------------------------------------------------------------------

@app.errorhandler(Exception)
def handle_exception(e):
    """Catch-all error handler to prevent stack trace leakage in production."""
    logger.exception("Unhandled exception: %s", e)
    accept = request.headers.get("Accept", "")
    if "application/json" in accept:
        return jsonify({"error": "Internal server error"}), 500
    return "Internal server error", 500


@app.errorhandler(404)
def handle_404(e):
    accept = request.headers.get("Accept", "")
    if "application/json" in accept:
        return jsonify({"error": "Not found"}), 404
    return "Not found", 404


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Attestant Client Dashboard")
    parser.add_argument("--port", default=5003, type=int)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    from attestant import __version__

    mode_label = "Aurora PostgreSQL"

    url = f"http://{args.host}:{args.port}"

    print()
    print("  Attestant Client Dashboard v" + __version__)
    print("  " + "=" * 44)
    print(f"  Tenant:     {_DEFAULT_TENANT}")
    print(f"  Mode:       {mode_label}")
    print(f"  Dashboard:  {url}")
    print()

    app.run(debug=args.debug, port=args.port, host=args.host)


@app.route("/.well-known/security.txt")
@app.route("/security.txt")
def security_txt():
    return ("Contact: security@attestant.ai\nPreferred-Languages: en\n",
            200, {"Content-Type": "text/plain"})


if __name__ == "__main__":
    main()
