"""
Aurora PostgreSQL read-optimized data store for Attestant dashboards.

Designed for heavy dashboard reads with:
- Separate reader/writer connection pools (Aurora read replicas)
- Denormalized snapshot tables refreshed periodically
- Tenant isolation for multi-client deployments
- Connection pooling via psycopg2 ThreadedConnectionPool

Schema is optimized for the two dashboard use cases:
1. Client dashboard: bank CRO sees their own compliance posture
2. Admin dashboard: founder monitors all tenants

Usage::

    store = DashboardStore(
        writer_dsn="postgresql://writer.cluster.rds.amazonaws.com/attestant",
        reader_dsn="postgresql://reader.cluster-ro.rds.amazonaws.com/attestant",
    )
    store.connect()
    store.ensure_schema()

    # Write path (goes to Aurora primary)
    store.upsert_tenant_snapshot(tenant_id, snapshot_data)

    # Read path (goes to Aurora read replica)
    data = store.get_tenant_overview(tenant_id)
"""

import hashlib
import json
import logging
import secrets
import time
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)

_cache: dict = {}
_cache_ts: dict = {}


def _cached(key: str, ttl: int, fn):
    now = time.monotonic()
    if key in _cache and (now - _cache_ts[key]) < ttl:
        return _cache[key]
    result = fn()
    _cache[key] = result
    _cache_ts[key] = now
    return result


class _NumpyEncoder(json.JSONEncoder):
    """JSON encoder that handles numpy types."""

    def default(self, obj):
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, (np.bool_,)):
            return bool(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, (date, datetime)):
            return obj.isoformat()
        return super().default(obj)


def _json_dumps(obj) -> str:
    """Serialize to JSON with numpy support."""
    return json.dumps(obj, cls=_NumpyEncoder)

# ---------------------------------------------------------------------------
# Schema DDL — executed once via ensure_schema()
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
-- Tenants (bank clients)
CREATE TABLE IF NOT EXISTS tenants (
    tenant_id       TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    tier            TEXT NOT NULL DEFAULT 'professional',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    active          BOOLEAN NOT NULL DEFAULT TRUE,
    config          JSONB DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_tenants_active ON tenants (active);

-- Compliance score snapshots (denormalized for fast reads)
CREATE TABLE IF NOT EXISTS compliance_snapshots (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    score           REAL NOT NULL,
    grade           TEXT NOT NULL,
    engines_evaluated INTEGER NOT NULL DEFAULT 0,
    critical_findings INTEGER NOT NULL DEFAULT 0,
    warning_findings  INTEGER NOT NULL DEFAULT 0,
    total_findings  INTEGER NOT NULL DEFAULT 0,
    top_risks       JSONB DEFAULT '[]',
    breakdowns      JSONB DEFAULT '[]',
    bonuses         JSONB DEFAULT '{}',
    trend           TEXT,
    snapshot_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_comp_snap_tenant
    ON compliance_snapshots (tenant_id, snapshot_at DESC);

-- Model inventory snapshots (denormalized)
CREATE TABLE IF NOT EXISTS model_snapshots (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    model_id        TEXT NOT NULL,
    name            TEXT NOT NULL,
    version         TEXT,
    tier            INTEGER NOT NULL DEFAULT 3,
    status          TEXT NOT NULL DEFAULT 'development',
    domain          TEXT,
    owner           TEXT,
    compliance_score REAL,
    last_validated  TIMESTAMPTZ,
    last_monitored  TIMESTAMPTZ,
    validation_overdue BOOLEAN DEFAULT FALSE,
    monitoring_overdue BOOLEAN DEFAULT FALSE,
    finding_count   INTEGER DEFAULT 0,
    snapshot_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    description     TEXT,
    model_type      TEXT,
    deployed_at     TIMESTAMPTZ,
    deployed_by     TEXT,
    tags            TEXT
);

CREATE INDEX IF NOT EXISTS idx_model_snap_tenant
    ON model_snapshots (tenant_id, snapshot_at DESC);
CREATE INDEX IF NOT EXISTS idx_model_snap_status
    ON model_snapshots (tenant_id, status);

-- Fairness analysis results (per model, per run)
CREATE TABLE IF NOT EXISTS fairness_snapshots (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    model_id        TEXT NOT NULL,
    has_disparate_impact BOOLEAN DEFAULT FALSE,
    worst_ratio     REAL,
    worst_group     TEXT,
    p_value         REAL,
    statistically_significant BOOLEAN DEFAULT FALSE,
    protected_attributes JSONB DEFAULT '[]',
    sample_size_warnings JSONB DEFAULT '[]',
    details         JSONB DEFAULT '{}',
    snapshot_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_fair_snap_tenant
    ON fairness_snapshots (tenant_id, snapshot_at DESC);

-- Certification status
CREATE TABLE IF NOT EXISTS certification_snapshots (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    cert_type       TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'not_started',
    issued_date     DATE,
    expiry_date     DATE,
    days_until_expiry INTEGER,
    snapshot_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_cert_snap_tenant
    ON certification_snapshots (tenant_id, snapshot_at DESC);

-- Alert / finding log
CREATE TABLE IF NOT EXISTS alert_log (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    severity        TEXT NOT NULL,
    source          TEXT NOT NULL,
    title           TEXT NOT NULL,
    description     TEXT,
    model_id        TEXT,
    regulation      TEXT,
    resolved        BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at     TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_alert_tenant
    ON alert_log (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_alert_unresolved
    ON alert_log (tenant_id, resolved, severity);

-- Pipeline execution stats (deduplicated by model version)
CREATE TABLE IF NOT EXISTS pipeline_stats (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    pipeline_name   TEXT,
    display_name    TEXT,
    model_hash      TEXT,
    status          TEXT NOT NULL,
    node_count      INTEGER DEFAULT 0,
    edge_count      INTEGER DEFAULT 0,
    case_count      INTEGER DEFAULT 0,
    duration_ms     INTEGER,
    started_at      TIMESTAMPTZ,
    completed_at    TIMESTAMPTZ,
    metadata        JSONB DEFAULT '{}',
    provenance_pipeline_id INTEGER,
    first_seen_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_used_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, pipeline_name, model_hash)
);

CREATE INDEX IF NOT EXISTS idx_pipeline_tenant
    ON pipeline_stats (tenant_id, last_used_at DESC);

CREATE INDEX IF NOT EXISTS idx_pipeline_prov
    ON pipeline_stats (tenant_id, provenance_pipeline_id)
    WHERE provenance_pipeline_id IS NOT NULL;

-- Individual cases processed by pipelines
CREATE TABLE IF NOT EXISTS pipeline_row_results (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    pipeline_id     BIGINT NOT NULL REFERENCES pipeline_stats(id) ON DELETE CASCADE,
    row_index       INTEGER NOT NULL,
    decision        TEXT,
    score           REAL,
    timestamp       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pipeline_rows
    ON pipeline_row_results (tenant_id, pipeline_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_pipeline_rows_timestamp
    ON pipeline_row_results (tenant_id, timestamp DESC);

CREATE TABLE IF NOT EXISTS model_feature_stats (
    id                      BIGSERIAL PRIMARY KEY,
    tenant_id               TEXT NOT NULL REFERENCES tenants(tenant_id),
    model_id                TEXT NOT NULL,
    snapshot_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    feature_stats           JSONB DEFAULT '{}',
    feature_importance      JSONB DEFAULT '[]',
    prediction_stats        JSONB DEFAULT '{}',
    protected_distributions JSONB DEFAULT '{}',
    data_quality            JSONB DEFAULT '{}',
    UNIQUE(tenant_id, model_id)
);

CREATE INDEX IF NOT EXISTS idx_model_feat_stats
    ON model_feature_stats (tenant_id, model_id, snapshot_at DESC);

-- System metrics (for admin dashboard)
CREATE TABLE IF NOT EXISTS system_metrics (
    id              BIGSERIAL PRIMARY KEY,
    metric_name     TEXT NOT NULL,
    metric_value    REAL NOT NULL,
    labels          JSONB DEFAULT '{}',
    recorded_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sys_metrics
    ON system_metrics (metric_name, recorded_at DESC);

CREATE TABLE IF NOT EXISTS dashboard_users (
    id              BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL,
    email           TEXT NOT NULL,
    password_hash   TEXT,
    display_name    TEXT NOT NULL DEFAULT '',
    role            TEXT NOT NULL DEFAULT 'analyst',
    active          BOOLEAN NOT NULL DEFAULT TRUE,
    invited_by      TEXT,
    last_login_at   TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, email)
);

CREATE INDEX IF NOT EXISTS idx_users_tenant
    ON dashboard_users (tenant_id, active);
CREATE INDEX IF NOT EXISTS idx_users_email
    ON dashboard_users (email);

CREATE TABLE IF NOT EXISTS user_permissions (
    id          BIGSERIAL PRIMARY KEY,
    tenant_id   TEXT NOT NULL,
    user_id     BIGINT NOT NULL REFERENCES dashboard_users(id) ON DELETE CASCADE,
    permission  TEXT NOT NULL,
    granted     BOOLEAN NOT NULL DEFAULT TRUE,
    granted_by  TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, user_id, permission)
);
CREATE INDEX IF NOT EXISTS idx_user_perms_tenant_user ON user_permissions (tenant_id, user_id);

CREATE TABLE IF NOT EXISTS api_keys (
    key_id          BIGSERIAL PRIMARY KEY,
    tenant_id       TEXT NOT NULL REFERENCES tenants(tenant_id),
    key_hash        TEXT NOT NULL UNIQUE,
    key_prefix      TEXT,
    key_name        TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'active',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at      TIMESTAMPTZ,
    last_used_at    TIMESTAMPTZ,
    created_by      TEXT
);

CREATE INDEX IF NOT EXISTS idx_api_keys_tenant ON api_keys (tenant_id);
CREATE INDEX IF NOT EXISTS idx_api_keys_hash ON api_keys (key_hash);
CREATE INDEX IF NOT EXISTS idx_api_keys_status ON api_keys (tenant_id, status);

CREATE TABLE IF NOT EXISTS subscriptions (
    id SERIAL PRIMARY KEY,
    tenant_id TEXT NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
    stripe_customer_id TEXT,
    stripe_subscription_id TEXT,
    plan TEXT NOT NULL DEFAULT 'starter',
    status TEXT NOT NULL DEFAULT 'active',
    current_period_start TIMESTAMPTZ,
    current_period_end TIMESTAMPTZ,
    cancel_at_period_end BOOLEAN DEFAULT FALSE,
    trial_end TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id)
);

CREATE TABLE IF NOT EXISTS usage_events (
    id SERIAL PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    billing_period INT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_usage_tenant_period
    ON usage_events(tenant_id, billing_period, event_type);

CREATE TABLE IF NOT EXISTS notification_preferences (
    id SERIAL PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    user_id INT NOT NULL REFERENCES dashboard_users(id) ON DELETE CASCADE,
    email_enabled BOOLEAN DEFAULT FALSE,
    slack_webhook_url TEXT,
    event_types JSONB DEFAULT '["critical","warning"]'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id, user_id)
);

CREATE TABLE IF NOT EXISTS score_profiles (
    id          BIGSERIAL PRIMARY KEY,
    tenant_id   TEXT NOT NULL REFERENCES tenants(tenant_id),
    name        TEXT NOT NULL,
    description TEXT DEFAULT '',
    is_default  BOOLEAN NOT NULL DEFAULT FALSE,
    config      JSONB NOT NULL DEFAULT '{}',
    created_by  TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_by  TEXT,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, name)
);
CREATE INDEX IF NOT EXISTS idx_score_profiles_tenant ON score_profiles (tenant_id);

CREATE TABLE IF NOT EXISTS model_profile_assignments (
    id BIGSERIAL PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    model_id TEXT NOT NULL,
    profile_id BIGINT NOT NULL REFERENCES score_profiles(id) ON DELETE CASCADE,
    assigned_by TEXT,
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, model_id)
);

CREATE TABLE IF NOT EXISTS compliance_templates (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    config JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS model_attestations (
    id BIGSERIAL PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    model_id TEXT NOT NULL,
    model_name TEXT,
    version TEXT,
    attested_by TEXT NOT NULL,
    attested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    compliance_score NUMERIC,
    status TEXT NOT NULL DEFAULT 'active',
    notes TEXT
);

CREATE INDEX IF NOT EXISTS idx_attestations_tenant
    ON model_attestations (tenant_id, attested_at DESC);
CREATE INDEX IF NOT EXISTS idx_attestations_model
    ON model_attestations (tenant_id, model_id);

CREATE TABLE IF NOT EXISTS compliance_exceptions (
    id BIGSERIAL PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    model_id TEXT NOT NULL,
    model_name TEXT,
    check_id TEXT NOT NULL,
    check_label TEXT,
    regulation TEXT,
    severity TEXT,
    justification TEXT NOT NULL,
    approved_by TEXT NOT NULL,
    approved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ,
    status TEXT NOT NULL DEFAULT 'active'
);

CREATE INDEX IF NOT EXISTS idx_exceptions_tenant
    ON compliance_exceptions (tenant_id, approved_at DESC);
CREATE INDEX IF NOT EXISTS idx_exceptions_model
    ON compliance_exceptions (tenant_id, model_id);

create table if not exists data_deletion_log (
    id              bigserial primary key,
    tenant_id       text not null,
    user_email      text not null,
    action          text not null,
    resource_type   text not null,
    resource_id     text,
    quantity_deleted integer not null default 0,
    details         jsonb default '{}',
    deleted_at      timestamptz not null default now()
);

create index if not exists idx_del_log_tenant
    on data_deletion_log (tenant_id, deleted_at desc)
"""

ALL_PERMISSIONS = [
    "view_compliance",
    "view_fairness",
    "view_models",
    "view_pipelines",
    "view_alerts",
    "view_reports",
    "manage_users",
    "manage_permissions",
    "export_data",
]

ROLE_DEFAULTS = {
    "admin": {
        "view_compliance": True,
        "view_fairness": True,
        "view_models": True,
        "view_pipelines": True,
        "view_alerts": True,
        "view_reports": True,
        "manage_users": True,
        "manage_permissions": True,
        "export_data": True,
    },
    "manager": {
        "view_compliance": True,
        "view_fairness": True,
        "view_models": True,
        "view_pipelines": True,
        "view_alerts": True,
        "view_reports": True,
        "manage_users": True,
        "manage_permissions": False,
        "export_data": True,
    },
    "analyst": {
        "view_compliance": True,
        "view_fairness": False,
        "view_models": True,
        "view_pipelines": False,
        "view_alerts": True,
        "view_reports": False,
        "manage_users": False,
        "manage_permissions": False,
        "export_data": False,
    },
}


class DashboardStore:
    """Aurora PostgreSQL read-optimized store for dashboards.

    Supports separate writer and reader connection strings for
    Aurora read replicas.  Falls back to writer DSN for reads
    if no reader DSN is provided (single-instance mode).
    """

    def __init__(
        self,
        writer_dsn: str,
        reader_dsn: Optional[str] = None,
        min_conn: int = 2,
        max_conn: int = 10,
    ):
        self.writer_dsn = writer_dsn
        self.reader_dsn = reader_dsn or writer_dsn
        self.min_conn = min_conn
        self.max_conn = max_conn
        self._writer_pool = None
        self._reader_pool = None

    def connect(self) -> None:
        """Create connection pools for writer and reader endpoints."""
        from psycopg2 import pool as pg_pool
        from psycopg2.extras import register_default_jsonb

        register_default_jsonb()

        self._writer_pool = pg_pool.ThreadedConnectionPool(
            self.min_conn, self.max_conn, self.writer_dsn,
        )
        if self.reader_dsn != self.writer_dsn:
            self._reader_pool = pg_pool.ThreadedConnectionPool(
                self.min_conn, self.max_conn, self.reader_dsn,
            )
        else:
            self._reader_pool = self._writer_pool

        logger.info("DashboardStore connected (writer + reader pools)")

    def disconnect(self) -> None:
        """Close all connection pools."""
        if self._writer_pool is not None:
            self._writer_pool.closeall()
        if self._reader_pool is not None and self._reader_pool is not self._writer_pool:
            self._reader_pool.closeall()
        self._writer_pool = None
        self._reader_pool = None

    def _writer_conn(self):
        if self._writer_pool is None:
            raise RuntimeError("DashboardStore is not connected. Call connect() first.")
        return self._writer_pool.getconn()

    def _reader_conn(self):
        if self._reader_pool is not None:
            return self._reader_pool.getconn()
        if self._writer_pool is not None:
            return self._writer_pool.getconn()
        raise RuntimeError("DashboardStore is not connected. Call connect() first.")

    def _writer_putconn(self, conn) -> None:
        if self._writer_pool is not None and conn is not None:
            self._writer_pool.putconn(conn)

    def _reader_putconn(self, conn) -> None:
        if self._reader_pool is not None and conn is not None:
            self._reader_pool.putconn(conn)
            return
        if self._writer_pool is not None and conn is not None:
            self._writer_pool.putconn(conn)

    def ensure_schema(self) -> None:
        """Create tables if they don't exist (idempotent)."""
        conn = self._writer_conn()
        try:
            with conn.cursor() as cur:
                for stmt in _SCHEMA_SQL.split(";"):
                    stmt = stmt.strip()
                    if not stmt or stmt.startswith("--"):
                        continue
                    try:
                        cur.execute(stmt)
                        conn.commit()
                    except Exception:
                        conn.rollback()
        finally:
            self._writer_putconn(conn)

        _migrations = [
            "ALTER TABLE pipeline_stats ADD COLUMN IF NOT EXISTS provenance_pipeline_id INTEGER",
            "ALTER TABLE pipeline_stats ADD COLUMN IF NOT EXISTS metadata JSONB DEFAULT '{}'",
            "ALTER TABLE pipeline_stats ADD COLUMN IF NOT EXISTS started_at TIMESTAMPTZ",
            "ALTER TABLE pipeline_stats ADD COLUMN IF NOT EXISTS duration_ms INTEGER",
            "ALTER TABLE pipeline_stats ADD COLUMN IF NOT EXISTS completed_at TIMESTAMPTZ",
            "ALTER TABLE model_snapshots ADD COLUMN IF NOT EXISTS description TEXT",
            "ALTER TABLE model_snapshots ADD COLUMN IF NOT EXISTS model_type TEXT",
            "ALTER TABLE model_snapshots ADD COLUMN IF NOT EXISTS deployed_at TIMESTAMPTZ",
            "ALTER TABLE model_snapshots ADD COLUMN IF NOT EXISTS deployed_by TEXT",
            "ALTER TABLE model_snapshots ADD COLUMN IF NOT EXISTS tags TEXT",
            "ALTER TABLE model_snapshots ADD COLUMN IF NOT EXISTS model_hash TEXT",
            "ALTER TABLE model_snapshots ADD COLUMN IF NOT EXISTS developer TEXT",
            "ALTER TABLE model_snapshots ADD COLUMN IF NOT EXISTS feature_count INTEGER",
            "ALTER TABLE model_snapshots ADD COLUMN IF NOT EXISTS protected_columns TEXT",
        ]
        for ddl in _migrations:
            conn2 = None
            try:
                conn2 = self._writer_conn()
                with conn2.cursor() as cur:
                    cur.execute(ddl)
                conn2.commit()
            except Exception as exc:
                logger.debug("Migration skipped (likely already applied): %s", exc)
                if conn2 is not None:
                    try:
                        conn2.rollback()
                    except Exception:
                        pass
            finally:
                if conn2 is not None:
                    self._writer_putconn(conn2)

        try:
            tenants = self._read_dicts(
                "SELECT tenant_id FROM tenants WHERE active = TRUE"
            )
            for t in tenants:
                count = self.backfill_user_permissions(t["tenant_id"])
                if count > 0:
                    logger.info(
                        "Backfilled permissions for %d user(s) in tenant %s",
                        count, t["tenant_id"],
                    )
        except Exception as e:
            logger.warning("Permission backfill skipped: %s", e)

        try:
            self._seed_compliance_templates()
        except Exception as e:
            logger.warning("Compliance template seeding skipped: %s", e)

    # -- Writer methods (Aurora primary) ------------------------------------

    @staticmethod
    def _adapt_params(params: tuple) -> tuple:
        """Convert numpy types and dicts to native Python for psycopg2."""
        adapted: List[Any] = []
        for p in params:
            if isinstance(p, (np.integer,)):
                adapted.append(int(p))
            elif isinstance(p, (np.floating,)):
                adapted.append(float(p))
            elif isinstance(p, (np.bool_,)):
                adapted.append(bool(p))
            elif isinstance(p, (dict, list)):
                adapted.append(_json_dumps(p))
            elif isinstance(p, np.ndarray):
                adapted.append(_json_dumps(p.tolist()))
            else:
                adapted.append(p)
        return tuple(adapted)

    def _write(self, sql: str, params: tuple = ()) -> None:
        params = self._adapt_params(params)
        conn = self._writer_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_putconn(conn)

    def _write_returning(self, sql: str, params: tuple = ()) -> Any:
        conn = self._writer_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                result = cur.fetchone()
            conn.commit()
            return result
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_putconn(conn)

    # -- Reader methods (Aurora read replica) --------------------------------

    def _read_one(self, sql: str, params: tuple = ()) -> Optional[tuple]:
        conn = self._reader_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return cur.fetchone()
        finally:
            self._reader_putconn(conn)

    def _read_all(self, sql: str, params: tuple = ()) -> List[tuple]:
        conn = self._reader_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return cur.fetchall()
        finally:
            self._reader_putconn(conn)

    def _read_dicts(self, sql: str, params: tuple = ()) -> List[Dict[str, Any]]:
        conn = self._reader_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                cols = [desc[0] for desc in cur.description]
                return [dict(zip(cols, row)) for row in cur.fetchall()]
        finally:
            self._reader_putconn(conn)

    def _read_dict(self, sql: str, params: tuple = ()) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(sql, params)
        return rows[0] if rows else None

    # -- Tenant management ---------------------------------------------------

    def upsert_tenant(self, tenant_id: str, name: str, tier: str = "professional",
                      config: Optional[Dict[str, Any]] = None) -> None:
        cfg = _json_dumps(config or {})
        self._write(
            """INSERT INTO tenants (tenant_id, name, tier, config)
               VALUES (%s, %s, %s, %s)
               ON CONFLICT (tenant_id) DO UPDATE
               SET name = EXCLUDED.name, tier = EXCLUDED.tier,
                   config = EXCLUDED.config""",
            (tenant_id, name, tier, cfg),
        )

    def get_tenant(self, tenant_id: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            "SELECT * FROM tenants WHERE tenant_id = %s AND active = TRUE",
            (tenant_id,),
        )
        return rows[0] if rows else None

    def get_tenant_config(self, tenant_id: str) -> Dict[str, Any]:
        rows = self._read_dicts(
            "SELECT config FROM tenants WHERE tenant_id = %s AND active = TRUE",
            (tenant_id,),
        )
        if not rows:
            return {}
        raw = rows[0].get("config", {})
        if isinstance(raw, str):
            return json.loads(raw)
        return raw or {}

    def get_all_tenants(self) -> List[Dict[str, Any]]:
        return self._read_dicts(
            "SELECT * FROM tenants WHERE active = TRUE ORDER BY name"
        )

    # -- Compliance snapshots ------------------------------------------------

    def insert_compliance_snapshot(self, tenant_id: str, data: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO compliance_snapshots
               (tenant_id, score, grade, engines_evaluated, critical_findings,
                warning_findings, total_findings, top_risks, breakdowns, bonuses, trend)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (
                tenant_id,
                data["score"], data["grade"], data.get("engines_evaluated", 0),
                data.get("critical_findings", 0), data.get("warning_findings", 0),
                data.get("total_findings", 0),
                _json_dumps(data.get("top_risks", [])),
                _json_dumps(data.get("breakdowns", [])),
                _json_dumps(data.get("bonuses_applied", {})),
                data.get("trend"),
            ),
        )

    def get_latest_compliance(self, tenant_id: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            """SELECT * FROM compliance_snapshots
               WHERE tenant_id = %s ORDER BY snapshot_at DESC LIMIT 1""",
            (tenant_id,),
        )
        return rows[0] if rows else None

    def get_compliance_history(self, tenant_id: str, limit: int = 30) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT score, grade, total_findings, critical_findings,
                      snapshot_at
               FROM compliance_snapshots
               WHERE tenant_id = %s ORDER BY snapshot_at DESC LIMIT %s""",
            (tenant_id, limit),
        )

    # -- Model snapshots -----------------------------------------------------

    def upsert_model_snapshot(self, tenant_id: str, model: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO model_snapshots
               (tenant_id, model_id, name, version, tier, status, domain, owner,
                compliance_score, last_validated, last_monitored,
                validation_overdue, monitoring_overdue, finding_count)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (
                tenant_id, model["model_id"], model["name"],
                model.get("version"), model.get("tier", 3),
                model.get("status", "development"), model.get("domain"),
                model.get("owner"), model.get("compliance_score"),
                model.get("last_validated"), model.get("last_monitored"),
                model.get("validation_overdue", False),
                model.get("monitoring_overdue", False),
                model.get("finding_count", 0),
            ),
        )

    def get_models(self, tenant_id: str) -> List[Dict[str, Any]]:
        rows = self._read_dicts(
            """SELECT DISTINCT ON (model_id)
                      model_id, name, version, tier, status, domain, owner,
                      compliance_score, last_validated, last_monitored,
                      validation_overdue, monitoring_overdue, finding_count,
                      snapshot_at, description, model_type,
                      deployed_at, deployed_by, tags,
                      model_hash, developer, feature_count, protected_columns
               FROM model_snapshots
               WHERE tenant_id = %s
               ORDER BY model_id, snapshot_at DESC""",
            (tenant_id,),
        )
        for row in rows:
            pc = row.get("protected_columns")
            if isinstance(pc, str):
                try:
                    row["protected_columns"] = json.loads(pc)
                except Exception:
                    row["protected_columns"] = []
        return rows

    def update_model(self, tenant_id: str, model_id: str,
                     updates: Dict[str, Any]) -> bool:
        allowed = {"name", "version", "tier", "status", "domain", "owner",
                   "description", "model_type", "deployed_at", "deployed_by",
                   "tags"}
        filtered = {k: v for k, v in updates.items() if k in allowed}
        if not filtered:
            return False
        set_parts = []
        vals = []
        for col, val in filtered.items():
            set_parts.append(f"{col} = %s")
            vals.append(val)
        vals.extend([tenant_id, model_id, tenant_id, model_id])
        self._write(
            f"""UPDATE model_snapshots SET {', '.join(set_parts)}
               WHERE tenant_id = %s AND model_id = %s
                 AND snapshot_at = (
                     SELECT MAX(snapshot_at) FROM model_snapshots
                     WHERE tenant_id = %s AND model_id = %s
                 )""",
            tuple(vals),
        )
        return True

    def approve_model(self, tenant_id: str, model_id: str,
                      approved_by: str) -> bool:
        self._write(
            """UPDATE model_snapshots SET status = 'approved'
               WHERE tenant_id = %s AND model_id = %s
                 AND snapshot_at = (
                     SELECT MAX(snapshot_at) FROM model_snapshots
                     WHERE tenant_id = %s AND model_id = %s
                 )""",
            (tenant_id, model_id, tenant_id, model_id),
        )
        return True

    # -- Model attestations --------------------------------------------------

    def get_attestations(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            "select id, model_id, model_name, version, attested_by, attested_at, "
            "compliance_score, status, notes from model_attestations "
            "where tenant_id = %s order by attested_at desc limit 50",
            (tenant_id,),
        )

    def create_attestation(
        self,
        tenant_id: str,
        model_id: str,
        model_name: Optional[str],
        version: Optional[str],
        attested_by: str,
        compliance_score: Optional[float],
        notes: Optional[str],
    ) -> Dict[str, Any]:
        row = self._write_returning(
            "insert into model_attestations "
            "(tenant_id, model_id, model_name, version, attested_by, compliance_score, notes) "
            "values (%s, %s, %s, %s, %s, %s, %s) "
            "returning id, model_id, model_name, version, attested_by, attested_at, "
            "compliance_score, status, notes",
            (tenant_id, model_id, model_name, version, attested_by, compliance_score, notes),
        )
        if row is None:
            raise RuntimeError("Attestation insert returned no row")
        keys = ["id", "model_id", "model_name", "version", "attested_by",
                "attested_at", "compliance_score", "status", "notes"]
        return dict(zip(keys, row))

    # -- Compliance exceptions ------------------------------------------------

    def get_exceptions(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            "select id, model_id, model_name, check_id, check_label, regulation, "
            "severity, justification, approved_by, approved_at, expires_at, status "
            "from compliance_exceptions where tenant_id = %s order by approved_at desc limit 100",
            (tenant_id,),
        )

    def create_exception(
        self,
        tenant_id: str,
        model_id: str,
        model_name: Optional[str],
        check_id: str,
        check_label: Optional[str],
        regulation: Optional[str],
        severity: Optional[str],
        justification: str,
        approved_by: str,
        expires_at: Optional[str],
    ) -> Dict[str, Any]:
        row = self._write_returning(
            "insert into compliance_exceptions "
            "(tenant_id, model_id, model_name, check_id, check_label, regulation, "
            "severity, justification, approved_by, expires_at) "
            "values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s) "
            "returning id, model_id, model_name, check_id, check_label, regulation, "
            "severity, justification, approved_by, approved_at, expires_at, status",
            (tenant_id, model_id, model_name, check_id, check_label, regulation,
             severity, justification, approved_by, expires_at),
        )
        if row is None:
            raise RuntimeError("Exception insert returned no row")
        keys = ["id", "model_id", "model_name", "check_id", "check_label", "regulation",
                "severity", "justification", "approved_by", "approved_at", "expires_at", "status"]
        return dict(zip(keys, row))

    def set_exception_status(self, tenant_id: str, exception_id: int, status: str) -> bool:
        self._write(
            "update compliance_exceptions set status = %s where id = %s and tenant_id = %s",
            (status, exception_id, tenant_id),
        )
        return True

    # -- Fairness snapshots --------------------------------------------------

    def insert_fairness_snapshot(self, tenant_id: str, data: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO fairness_snapshots
               (tenant_id, model_id, has_disparate_impact, worst_ratio,
                worst_group, p_value, statistically_significant,
                protected_attributes, sample_size_warnings, details)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (
                tenant_id, data["model_id"],
                data.get("has_disparate_impact", False),
                data.get("worst_ratio"), data.get("worst_group"),
                data.get("p_value"), data.get("statistically_significant", False),
                _json_dumps(data.get("protected_attributes", [])),
                _json_dumps(data.get("sample_size_warnings", [])),
                _json_dumps(data.get("details", {})),
            ),
        )

    def get_latest_fairness(self, tenant_id: str, model_id: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            """SELECT * FROM fairness_snapshots
               WHERE tenant_id = %s AND model_id = %s
               ORDER BY snapshot_at DESC LIMIT 1""",
            (tenant_id, model_id),
        )
        return rows[0] if rows else None

    def get_all_fairness(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT DISTINCT ON (model_id) *
               FROM fairness_snapshots
               WHERE tenant_id = %s
               ORDER BY model_id, snapshot_at DESC""",
            (tenant_id,),
        )

    # -- Certifications ------------------------------------------------------

    def upsert_certification(self, tenant_id: str, cert: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO certification_snapshots
               (tenant_id, cert_type, status, issued_date, expiry_date, days_until_expiry)
               VALUES (%s,%s,%s,%s,%s,%s)""",
            (
                tenant_id, cert["cert_type"], cert.get("status", "not_started"),
                cert.get("issued_date"), cert.get("expiry_date"),
                cert.get("days_until_expiry"),
            ),
        )

    def get_certifications(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT DISTINCT ON (cert_type)
                      cert_type, status, issued_date, expiry_date,
                      days_until_expiry, snapshot_at
               FROM certification_snapshots
               WHERE tenant_id = %s
               ORDER BY cert_type, snapshot_at DESC""",
            (tenant_id,),
        )

    # -- Alert log -----------------------------------------------------------

    def insert_alert(self, tenant_id: str, alert: Dict[str, Any]) -> int:
        row = self._write_returning(
            """INSERT INTO alert_log
               (tenant_id, severity, source, title, description, model_id, regulation)
               VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING id""",
            (
                tenant_id, alert["severity"], alert["source"],
                alert["title"], alert.get("description"),
                alert.get("model_id"), alert.get("regulation"),
            ),
        )
        return row[0] if row else 0

    def get_alerts(self, tenant_id: str, unresolved_only: bool = True,
                   limit: int = 50) -> List[Dict[str, Any]]:
        if unresolved_only:
            return self._read_dicts(
                """SELECT * FROM alert_log
                   WHERE tenant_id = %s AND resolved = FALSE
                   ORDER BY CASE severity
                       WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2
                   END, created_at DESC LIMIT %s""",
                (tenant_id, limit),
            )
        return self._read_dicts(
            """SELECT * FROM alert_log WHERE tenant_id = %s
               ORDER BY created_at DESC LIMIT %s""",
            (tenant_id, limit),
        )

    def resolve_alert(self, alert_id: int) -> None:
        self._write(
            "UPDATE alert_log SET resolved = TRUE, resolved_at = NOW() WHERE id = %s",
            (alert_id,),
        )

    # -- Pipeline stats (admin) ----------------------------------------------

    def insert_pipeline_stat(self, tenant_id: str, stat: Dict[str, Any]) -> None:
        self._write(
            """INSERT INTO pipeline_stats
               (tenant_id, pipeline_name, status, node_count, edge_count,
                duration_ms, provenance_pipeline_id, completed_at)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
            (
                tenant_id, stat.get("pipeline_name"), stat["status"],
                stat.get("node_count", 0), stat.get("edge_count", 0),
                stat.get("duration_ms"), stat.get("provenance_pipeline_id"),
                stat.get("completed_at"),
            ),
        )

    def get_pipeline_stats(self, tenant_id: Optional[str] = None,
                           limit: int = 100) -> List[Dict[str, Any]]:
        if tenant_id:
            return self._read_dicts(
                """SELECT ps.id AS pipeline_id, ps.id, ps.tenant_id, ps.pipeline_name,
                          ps.display_name, ps.model_hash, ps.status, ps.node_count, ps.edge_count,
                          COALESCE(
                              (SELECT COUNT(*) FROM pipeline_row_results pr
                               WHERE pr.pipeline_id = ps.id AND pr.tenant_id = ps.tenant_id),
                              ps.case_count, 0
                          ) AS case_count,
                          COALESCE(ps.last_used_at, ps.first_seen_at,
                              (SELECT MAX(pm.started_at) FROM pipeline_metadata pm
                               WHERE pm.pipeline_name = ps.pipeline_name
                               AND pm.tenant_id = ps.tenant_id)
                          ) AS last_used_at,
                          ps.first_seen_at
                   FROM pipeline_stats ps WHERE ps.tenant_id = %s
                   ORDER BY COALESCE(ps.last_used_at, ps.first_seen_at,
                       (SELECT MAX(pm.started_at) FROM pipeline_metadata pm
                        WHERE pm.pipeline_name = ps.pipeline_name
                        AND pm.tenant_id = ps.tenant_id)) DESC NULLS LAST
                   LIMIT %s""",
                (tenant_id, limit),
            )
        return self._read_dicts(
            """SELECT ps.id AS pipeline_id, ps.id, ps.tenant_id, ps.pipeline_name,
                      ps.display_name, ps.model_hash, ps.status, ps.node_count, ps.edge_count,
                      COALESCE(
                          (SELECT COUNT(*) FROM pipeline_row_results pr
                           WHERE pr.pipeline_id = ps.id AND pr.tenant_id = ps.tenant_id),
                          ps.case_count, 0
                      ) AS case_count,
                      COALESCE(ps.last_used_at, ps.first_seen_at,
                          (SELECT MAX(pm.started_at) FROM pipeline_metadata pm
                           WHERE pm.pipeline_name = ps.pipeline_name
                           AND pm.tenant_id = ps.tenant_id)
                      ) AS last_used_at,
                      ps.first_seen_at
               FROM pipeline_stats ps
               ORDER BY COALESCE(ps.last_used_at, ps.first_seen_at,
                   (SELECT MAX(pm.started_at) FROM pipeline_metadata pm
                    WHERE pm.pipeline_name = ps.pipeline_name
                    AND pm.tenant_id = ps.tenant_id)) DESC NULLS LAST
               LIMIT %s""",
            (limit,),
        )

    def update_pipeline_display_name(self, tenant_id: str, pipeline_id: int,
                                      display_name: str) -> bool:
        self._write(
            """UPDATE pipeline_stats SET display_name = %s, updated_at = NOW()
               WHERE id = %s AND tenant_id = %s""",
            (display_name, pipeline_id, tenant_id),
        )
        return True

    def get_dag_column_summary(self, provenance_pipeline_id: int) -> Dict[str, Any]:
        """Return feature/protected column breakdown for a pipeline's stored DAG.

        Columns are classified as:
          - feature_columns: non-protected source nodes (actual model inputs)
          - protected_columns: protected source nodes (fairness monitoring only)
          - protected_isolated: True if ALL protected nodes have zero outgoing edges
            (i.e., they influence no model computations — the correct ECOA pattern)
        """
        nodes = self._read_dicts(
            """SELECT dn.column_name, dn.node_type, dn.is_protected,
                      EXISTS(SELECT 1 FROM dag_edges de
                             WHERE de.parent_node_id = dn.node_id) AS has_outgoing_edges
               FROM dag_nodes dn
               WHERE dn.pipeline_id = %s
               ORDER BY dn.is_protected, dn.node_type, dn.node_id""",
            (provenance_pipeline_id,),
        )
        feature_columns = []
        protected_columns = []
        protected_isolated = True
        for n in nodes:
            name = n.get("column_name") or n.get("node_type") or "unknown"
            ntype = (n.get("node_type") or "").upper()
            if n.get("is_protected"):
                protected_columns.append(name)
                if n.get("has_outgoing_edges"):
                    protected_isolated = False
            elif ntype in ("SOURCE", "LEAF", ""):
                feature_columns.append(name)
        return {
            "feature_columns": feature_columns,
            "protected_columns": protected_columns,
            "total_nodes": len(nodes),
            "protected_isolated": protected_isolated,
        }

    def insert_or_update_pipeline(self, tenant_id: str, pipeline_name: str,
                                   display_name: str, model_hash: str,
                                   status: str = "completed",
                                   node_count: int = 0,
                                   edge_count: int = 0) -> Optional[int]:
        """Insert or update a pipeline. Returns pipeline_id."""
        result = self._read_dict(
            """INSERT INTO pipeline_stats
               (tenant_id, pipeline_name, display_name, model_hash, status,
                node_count, edge_count, case_count, first_seen_at, last_used_at)
               VALUES (%s, %s, %s, %s, %s, %s, %s, 0, NOW(), NOW())
               ON CONFLICT (tenant_id, pipeline_name, model_hash)
               DO UPDATE SET last_used_at = NOW(), updated_at = NOW()
               RETURNING id""",
            (tenant_id, pipeline_name, display_name, model_hash, status,
             node_count, edge_count),
        )
        return int(result["id"]) if result else None

    def add_pipeline_row_result(self, tenant_id: str, pipeline_id: int,
                                 row_index: int, decision: Optional[str] = None,
                                 score: Optional[float] = None) -> None:
        """Record an individual case result for a pipeline."""
        self._write(
            """INSERT INTO pipeline_row_results
               (tenant_id, pipeline_id, row_index, decision, score, timestamp)
               VALUES (%s, %s, %s, %s, %s, NOW())""",
            (tenant_id, pipeline_id, row_index, decision, score),
        )
        self._write(
            """UPDATE pipeline_stats SET case_count = case_count + 1
               WHERE id = %s AND tenant_id = %s""",
            (pipeline_id, tenant_id),
        )

    def get_pipeline_row_results(self, tenant_id: str, pipeline_id: int,
                                  limit: int = 100) -> List[Dict[str, Any]]:
        """Get all individual case results for a pipeline."""
        return self._read_dicts(
            """SELECT row_index, decision, score, timestamp
               FROM pipeline_row_results
               WHERE tenant_id = %s AND pipeline_id = %s
               ORDER BY timestamp DESC LIMIT %s""",
            (tenant_id, pipeline_id, limit),
        )

    # -- System metrics (admin) ----------------------------------------------

    def record_metric(self, name: str, value: float,
                      labels: Optional[Dict[str, str]] = None) -> None:
        self._write(
            """INSERT INTO system_metrics (metric_name, metric_value, labels)
               VALUES (%s, %s, %s)""",
            (name, value, _json_dumps(labels or {})),
        )

    def get_latest_metrics(self) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT DISTINCT ON (metric_name)
                      metric_name, metric_value, labels, recorded_at
               FROM system_metrics ORDER BY metric_name, recorded_at DESC"""
        )

    # -- Admin aggregates (read-heavy, hits read replica) --------------------

    def admin_tenant_summary(self) -> List[Dict[str, Any]]:
        return _cached("admin_tenant_summary", 600, self._admin_tenant_summary_impl)

    def _admin_tenant_summary_impl(self) -> List[Dict[str, Any]]:
        """Aggregate summary for admin dashboard — one row per tenant."""
        return self._read_dicts("""
            WITH storage AS (
                SELECT tenant_id, SUM(b) AS db_bytes FROM (
                    SELECT tenant_id, octet_length(cast(row_to_json(t) as text)) AS b FROM compliance_snapshots t
                    UNION ALL
                    SELECT tenant_id, octet_length(cast(row_to_json(t) as text)) FROM model_snapshots t
                    UNION ALL
                    SELECT tenant_id, octet_length(cast(row_to_json(t) as text)) FROM fairness_snapshots t
                    UNION ALL
                    SELECT tenant_id, octet_length(cast(row_to_json(t) as text)) FROM pipeline_stats t
                    UNION ALL
                    SELECT ps.tenant_id, octet_length(cast(row_to_json(pr) as text))
                        FROM pipeline_row_results pr JOIN pipeline_stats ps ON ps.id = pr.pipeline_id
                    UNION ALL
                    SELECT tenant_id, octet_length(cast(row_to_json(t) as text)) FROM alert_log t
                    UNION ALL
                    SELECT tenant_id, octet_length(cast(row_to_json(t) as text)) FROM certification_snapshots t
                    UNION ALL
                    SELECT tenant_id, octet_length(cast(row_to_json(t) as text)) FROM generated_reports t
                    UNION ALL
                    SELECT tenant_id, octet_length(cast(row_to_json(t) as text)) FROM model_feature_stats t
                    UNION ALL
                    SELECT tenant_id, octet_length(cast(row_to_json(t) as text)) FROM model_attestations t
                    UNION ALL
                    SELECT tenant_id, octet_length(cast(row_to_json(t) as text)) FROM row_values t
                    UNION ALL
                    SELECT tenant_id, octet_length(cast(row_to_json(t) as text)) FROM dag_nodes t
                    UNION ALL
                    SELECT tenant_id, octet_length(cast(row_to_json(t) as text)) FROM usage_events t
                ) s GROUP BY tenant_id
            )
            SELECT
                t.tenant_id, t.name, t.tier, t.created_at,
                cs.score AS compliance_score, cs.grade AS latest_grade,
                cs.critical_findings, cs.warning_findings,
                cs.trend, cs.latest_score_at,
                (SELECT COUNT(DISTINCT name) FROM model_snapshots ms
                 WHERE ms.tenant_id = t.tenant_id
                ) AS model_count,
                (SELECT COUNT(*) FROM alert_log a
                 WHERE a.tenant_id = t.tenant_id AND a.resolved = FALSE
                ) AS open_alerts,
                (SELECT COUNT(*) FROM pipeline_stats ps
                 WHERE ps.tenant_id = t.tenant_id
                   AND ps.last_used_at > NOW() - INTERVAL '24 hours'
                ) AS pipelines_24h,
                coalesce(st.db_bytes, 0) AS storage_bytes,
                (SELECT COUNT(*) FROM usage_events WHERE tenant_id = t.tenant_id) AS api_calls
            FROM tenants t
            LEFT JOIN LATERAL (
                SELECT score, grade, critical_findings, warning_findings, trend, snapshot_at AS latest_score_at
                FROM compliance_snapshots
                WHERE tenant_id = t.tenant_id
                ORDER BY snapshot_at DESC LIMIT 1
            ) cs ON TRUE
            LEFT JOIN storage st ON st.tenant_id = t.tenant_id
            WHERE t.active = TRUE AND t.tenant_id != '_platform_admin'
            ORDER BY cs.score ASC NULLS LAST
        """)

    def admin_system_health(self) -> Dict[str, Any]:
        return _cached("admin_system_health", 300, self._admin_system_health_impl)

    def _admin_system_health_impl(self) -> Dict[str, Any]:
        """System-wide health metrics for admin dashboard."""
        totals = self._read_one("""
            SELECT
                (SELECT COUNT(*) FROM tenants WHERE active = TRUE AND tenant_id != '_platform_admin'),
                (SELECT COUNT(DISTINCT model_id) FROM model_snapshots WHERE tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM alert_log WHERE resolved = FALSE AND tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM pipeline_stats
                 WHERE last_used_at > NOW() - INTERVAL '24 hours' AND tenant_id != '_platform_admin'),
                (SELECT AVG(score) FROM (
                    SELECT DISTINCT ON (tenant_id) score
                    FROM compliance_snapshots
                    WHERE tenant_id != '_platform_admin'
                    ORDER BY tenant_id, snapshot_at DESC
                ) recent),
                (SELECT COUNT(*) FROM alert_log WHERE resolved = FALSE AND severity = 'critical' AND tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM pipeline_stats WHERE tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM pipeline_stats WHERE status = 'completed' AND tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM pipeline_stats WHERE status = 'failed' AND tenant_id != '_platform_admin'),
                (SELECT AVG(duration_ms) FROM pipeline_stats WHERE status = 'completed' AND duration_ms IS NOT NULL AND tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM alert_log WHERE tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM alert_log WHERE resolved = TRUE AND tenant_id != '_platform_admin'),
                (SELECT last_used_at FROM pipeline_stats WHERE tenant_id != '_platform_admin' ORDER BY last_used_at DESC LIMIT 1),
                (SELECT snapshot_at FROM compliance_snapshots WHERE tenant_id != '_platform_admin' ORDER BY snapshot_at DESC LIMIT 1),
                (SELECT COUNT(DISTINCT model_id) FROM model_snapshots WHERE status = 'production' AND tenant_id != '_platform_admin'),
                (SELECT COUNT(DISTINCT model_id) FROM model_snapshots WHERE finding_count > 0 AND tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM fairness_snapshots WHERE has_disparate_impact = TRUE AND statistically_significant = TRUE),
                (SELECT COUNT(*) FROM (
                    SELECT DISTINCT ON (tenant_id) score
                    FROM compliance_snapshots
                    WHERE tenant_id != '_platform_admin'
                    ORDER BY tenant_id, snapshot_at DESC
                ) sub WHERE score < 60)
        """)
        if not totals:
            return {}

        tenant_count = totals[0] or 0
        total_models = totals[1] or 0
        open_alerts = totals[2] or 0
        pipelines_24h = totals[3] or 0
        avg_score = totals[4]
        critical_alerts = totals[5] or 0
        p_total = totals[6] or 0
        p_completed = totals[7] or 0
        p_failed = totals[8] or 0
        avg_dur = totals[9]
        t_alerts = totals[10] or 0
        r_alerts = totals[11] or 0

        table_row_counts = {}
        total_rows = 0
        try:
            counts_row = self._read_one("""
                SELECT
                    (SELECT COUNT(*) FROM tenants),
                    (SELECT COUNT(*) FROM compliance_snapshots),
                    (SELECT COUNT(*) FROM model_snapshots),
                    (SELECT COUNT(*) FROM fairness_snapshots),
                    (SELECT COUNT(*) FROM certification_snapshots),
                    (SELECT COUNT(*) FROM alert_log),
                    (SELECT COUNT(*) FROM pipeline_stats),
                    (SELECT COUNT(*) FROM system_metrics)
            """)
            table_names = [
                "tenants", "compliance_snapshots", "model_snapshots",
                "fairness_snapshots", "certification_snapshots", "alert_log",
                "pipeline_stats", "system_metrics",
            ]
            if counts_row:
                for i, tbl in enumerate(table_names):
                    cnt = counts_row[i] or 0
                    table_row_counts[tbl] = cnt
                    total_rows += cnt
        except Exception:
            pass

        return {
            "tenant_count": tenant_count,
            "total_models": total_models,
            "open_alerts": open_alerts,
            "pipelines_24h": pipelines_24h,
            "avg_compliance_score": round(avg_score, 1) if avg_score else None,
            "critical_alerts": critical_alerts,
            "pipelines_total": p_total,
            "pipeline_success_rate": round(p_completed / max(p_total, 1) * 100, 1),
            "pipeline_failure_rate": round(p_failed / max(p_total, 1) * 100, 1),
            "avg_pipeline_duration_ms": round(avg_dur, 1) if avg_dur else None,
            "total_alerts": t_alerts,
            "resolved_alerts": r_alerts,
            "alert_resolution_rate": round(r_alerts / max(t_alerts, 1) * 100, 1),
            "table_row_counts": table_row_counts,
            "total_rows": total_rows,
            "latest_pipeline_at": str(totals[12]) if totals[12] else None,
            "latest_compliance_at": str(totals[13]) if totals[13] else None,
            "models_in_production": totals[14] or 0,
            "models_with_findings": totals[15] or 0,
            "di_confirmed_count": totals[16] or 0,
            "tenants_below_c": totals[17] or 0,
        }

    # -- Platform-wide queries (admin) ---------------------------------------

    def get_all_models_platform(self) -> List[Dict[str, Any]]:
        return self._read_dicts("""
            SELECT DISTINCT ON (ms.tenant_id, ms.model_id)
                   ms.model_id, ms.tenant_id, ms.name, ms.version, ms.tier,
                   ms.status, ms.domain, ms.owner, ms.compliance_score,
                   ms.last_validated, ms.last_monitored,
                   ms.validation_overdue, ms.monitoring_overdue,
                   ms.finding_count, ms.snapshot_at,
                   t.name as tenant_name
            FROM model_snapshots ms
            JOIN tenants t ON ms.tenant_id = t.tenant_id
            WHERE t.active = TRUE AND t.tenant_id != '_platform_admin'
            ORDER BY ms.tenant_id, ms.model_id, ms.snapshot_at DESC
        """)

    def get_all_fairness_platform(self) -> List[Dict[str, Any]]:
        return self._read_dicts("""
            SELECT DISTINCT ON (fs.tenant_id, fs.model_id)
                   fs.*, t.name as tenant_name
            FROM fairness_snapshots fs
            JOIN tenants t ON fs.tenant_id = t.tenant_id
            WHERE t.active = TRUE AND t.tenant_id != '_platform_admin'
            ORDER BY fs.tenant_id, fs.model_id, fs.snapshot_at DESC
        """)

    def get_compliance_platform(self) -> Dict[str, Any]:
        tenant_scores = self._read_dicts("""
            SELECT DISTINCT ON (cs.tenant_id)
                   cs.tenant_id, t.name as tenant_name, t.tier,
                   cs.score, cs.grade, cs.critical_findings, cs.warning_findings,
                   cs.trend, cs.breakdowns, cs.top_risks, cs.snapshot_at
            FROM compliance_snapshots cs
            JOIN tenants t ON cs.tenant_id = t.tenant_id
            WHERE t.active = TRUE AND t.tenant_id != '_platform_admin'
            ORDER BY cs.tenant_id, cs.snapshot_at DESC
        """)
        scores = [t["score"] for t in tenant_scores if t["score"] is not None]
        return {
            "tenants": tenant_scores,
            "avg_score": round(sum(scores) / len(scores), 1) if scores else None,
            "min_score": min(scores) if scores else None,
            "max_score": max(scores) if scores else None,
            "grade_distribution": {
                "A": len([s for s in scores if s >= 90]),
                "B": len([s for s in scores if 75 <= s < 90]),
                "C": len([s for s in scores if 60 <= s < 75]),
                "D": len([s for s in scores if s < 60]),
            },
        }

    def get_pipeline_summary(self) -> Dict[str, Any]:
        totals = self._read_one("""
            SELECT
                (SELECT COUNT(*) FROM pipeline_stats WHERE tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM pipeline_stats WHERE status = 'completed' AND tenant_id != '_platform_admin'),
                (SELECT COUNT(*) FROM pipeline_stats WHERE status = 'failed' AND tenant_id != '_platform_admin'),
                (SELECT AVG(duration_ms) FROM pipeline_stats
                 WHERE status = 'completed' AND duration_ms IS NOT NULL AND tenant_id != '_platform_admin')
        """)
        total = totals[0] if totals else 0
        completed = totals[1] if totals else 0
        failed = totals[2] if totals else 0
        avg_dur = totals[3] if totals else None

        by_tenant = self._read_dicts("""
            SELECT ps.tenant_id, t.name as tenant_name,
                   COUNT(*) as total_runs,
                   SUM(CASE WHEN ps.status = 'completed' THEN 1 ELSE 0 END) as completed,
                   SUM(CASE WHEN ps.status = 'failed' THEN 1 ELSE 0 END) as failed,
                   ROUND(AVG(CASE WHEN ps.status = 'completed'
                             THEN ps.duration_ms END)::numeric, 0) as avg_duration_ms,
                   SUM(ps.node_count) as total_nodes,
                   SUM(ps.edge_count) as total_edges
            FROM pipeline_stats ps
            JOIN tenants t ON ps.tenant_id = t.tenant_id
            WHERE t.tenant_id != '_platform_admin'
            GROUP BY ps.tenant_id, t.name
            ORDER BY total_runs DESC
        """)
        by_pipeline = self._read_dicts("""
            SELECT pipeline_name,
                   COUNT(*) as run_count,
                   SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                   SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                   ROUND(AVG(CASE WHEN status = 'completed'
                             THEN duration_ms END)::numeric, 0) as avg_duration_ms
            FROM pipeline_stats
            WHERE tenant_id != '_platform_admin'
            GROUP BY pipeline_name
            ORDER BY run_count DESC
        """)
        return {
            "total_runs": total,
            "completed": completed,
            "failed": failed,
            "success_rate": round(completed / max(total, 1) * 100, 1),
            "avg_duration_ms": round(avg_dur, 1) if avg_dur else None,
            "by_tenant": by_tenant,
            "by_pipeline": by_pipeline,
        }

    def get_all_alerts_platform(self, limit: int = 50) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT a.id, a.tenant_id, t.name AS tenant_name, a.severity, a.source, a.title, a.model_id, a.created_at
               FROM alert_log a
               JOIN tenants t ON a.tenant_id = t.tenant_id
               WHERE a.resolved = FALSE AND a.tenant_id != '_platform_admin'
               ORDER BY CASE a.severity
                   WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2
               END, a.created_at DESC LIMIT %s""",
            (limit,),
        )

    # -- User management (authentication) ------------------------------------

    def get_user_by_email(self, tenant_id: str, email: str) -> Optional[Dict[str, Any]]:
        rows = self._read_dicts(
            """SELECT id, tenant_id, email, password_hash, display_name, role,
                      active, invited_by, last_login_at, created_at
               FROM dashboard_users
               WHERE tenant_id = %s AND email = %s AND active = TRUE""",
            (tenant_id, email),
        )
        return rows[0] if rows else None

    def update_password_hash(self, tenant_id: str, email: str, new_hash: str) -> None:
        self._write(
            "UPDATE dashboard_users SET password_hash = %s "
            "WHERE tenant_id = %s AND email = %s",
            (new_hash, tenant_id, email),
        )

    def get_users(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            """SELECT id, tenant_id, email, display_name, role,
                      active, invited_by, last_login_at, created_at
               FROM dashboard_users
               WHERE tenant_id = %s
               ORDER BY role, email""",
            (tenant_id,),
        )

    def create_user(self, tenant_id: str, email: str, password_hash: str,
                    display_name: str, role: str = "analyst",
                    invited_by: Optional[str] = None) -> Optional[int]:
        row = self._write_returning(
            """INSERT INTO dashboard_users
               (tenant_id, email, password_hash, display_name, role, invited_by)
               VALUES (%s, %s, %s, %s, %s, %s) RETURNING id""",
            (tenant_id, email, password_hash, display_name, role, invited_by),
        )
        return row[0] if row else None

    def update_user_role(self, tenant_id: str, user_id: int, role: str) -> bool:
        self._write(
            """UPDATE dashboard_users SET role = %s, updated_at = NOW()
               WHERE id = %s AND tenant_id = %s""",
            (role, user_id, tenant_id),
        )
        return True

    def deactivate_user(self, tenant_id: str, user_id: int) -> bool:
        self._write(
            """UPDATE dashboard_users SET active = FALSE, updated_at = NOW()
               WHERE id = %s AND tenant_id = %s""",
            (user_id, tenant_id),
        )
        return True

    def reactivate_user(self, tenant_id: str, user_id: int) -> bool:
        self._write(
            """UPDATE dashboard_users SET active = TRUE, updated_at = NOW()
               WHERE id = %s AND tenant_id = %s""",
            (user_id, tenant_id),
        )
        return True

    def record_login(self, tenant_id: str, email: str) -> None:
        self._write(
            """UPDATE dashboard_users SET last_login_at = NOW()
               WHERE tenant_id = %s AND email = %s""",
            (tenant_id, email),
        )

    def update_user_password(self, tenant_id: str, user_id: int,
                             password_hash: str) -> bool:
        self._write(
            """UPDATE dashboard_users SET password_hash = %s, updated_at = NOW()
               WHERE id = %s AND tenant_id = %s""",
            (password_hash, user_id, tenant_id),
        )
        return True

    def count_users(self, tenant_id: str) -> int:
        row = self._read_one(
            "SELECT COUNT(*) FROM dashboard_users WHERE tenant_id = %s AND active = TRUE",
            (tenant_id,),
        )
        return row[0] if row else 0

    # -- User Permissions ----------------------------------------------------

    def get_user_permissions(self, tenant_id: str, user_id: int) -> Dict[str, bool]:
        rows = self._read_dicts(
            "SELECT permission, granted FROM user_permissions "
            "WHERE tenant_id = %s AND user_id = %s",
            (tenant_id, user_id),
        )
        return {r["permission"]: r["granted"] for r in rows}

    def set_user_permissions_bulk(self, tenant_id: str, user_id: int,
                                  permissions: Dict[str, bool],
                                  granted_by: Optional[str] = None) -> None:
        conn = self._writer_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "DELETE FROM user_permissions "
                    "WHERE tenant_id = %s AND user_id = %s",
                    (tenant_id, user_id),
                )
                for perm, granted in permissions.items():
                    if perm not in ALL_PERMISSIONS:
                        continue
                    cur.execute(
                        "INSERT INTO user_permissions "
                        "(tenant_id, user_id, permission, granted, granted_by) "
                        "VALUES (%s, %s, %s, %s, %s)",
                        (tenant_id, user_id, perm, granted, granted_by),
                    )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_putconn(conn)

    def delete_user_permissions(self, tenant_id: str, user_id: int) -> None:
        self._write(
            "DELETE FROM user_permissions WHERE tenant_id = %s AND user_id = %s",
            (tenant_id, user_id),
        )

    def initialize_user_permissions(self, tenant_id: str, user_id: int,
                                     role: str) -> None:
        defaults = ROLE_DEFAULTS.get(role, ROLE_DEFAULTS["analyst"])
        self.set_user_permissions_bulk(tenant_id, user_id, defaults,
                                       granted_by="system")

    def backfill_user_permissions(self, tenant_id: str) -> int:
        users = self._read_dicts(
            "SELECT u.id, u.role FROM dashboard_users u "
            "WHERE u.tenant_id = %s AND u.active = TRUE "
            "AND NOT EXISTS ("
            "  SELECT 1 FROM user_permissions p "
            "  WHERE p.tenant_id = u.tenant_id AND p.user_id = u.id"
            ")",
            (tenant_id,),
        )
        for u in users:
            self.initialize_user_permissions(tenant_id, u["id"], u["role"])
        return len(users)

    # -- API Key Management --------------------------------------------------

    @staticmethod
    def _hash_api_key(key_value: str) -> str:
        return hashlib.sha256(key_value.encode()).hexdigest()

    def validate_api_key(self, key_value: str) -> Optional[Tuple[str, int]]:
        """Validate an API key and return (tenant_id, key_id) or None.

        Returns None for invalid, expired, or revoked keys.
        Updates last_used_at on successful validation.
        """
        if not key_value or not isinstance(key_value, str):
            return None
        key_hash = self._hash_api_key(key_value)
        row = self._read_one(
            "SELECT key_id, tenant_id FROM api_keys "
            "WHERE key_hash = %s AND status = 'active' "
            "AND (expires_at IS NULL OR expires_at > NOW())",
            (key_hash,),
        )
        if not row:
            return None
        key_id, tenant_id = row[0], row[1]
        self._write(
            "UPDATE api_keys SET last_used_at = NOW() WHERE key_id = %s",
            (key_id,),
        )
        return (tenant_id, key_id)

    def validate_api_key_detailed(self, key_value: str) -> Dict[str, Any]:
        """Validate an API key with detailed error information.

        Returns dict with:
          - valid=True, tenant_id, key_id on success
          - valid=False, reason="invalid"|"expired"|"revoked" on failure
        """
        if not key_value or not isinstance(key_value, str):
            return {"valid": False, "reason": "invalid"}
        key_hash = self._hash_api_key(key_value)
        row = self._read_dicts(
            "SELECT key_id AS id, tenant_id, status, expires_at "
            "FROM api_keys WHERE key_hash = %s",
            (key_hash,),
        )
        if not row:
            return {"valid": False, "reason": "invalid"}
        rec = row[0]
        if rec["status"] == "revoked":
            return {"valid": False, "reason": "revoked"}
        if rec["expires_at"] is not None:
            now = datetime.now(timezone.utc)
            exp = rec["expires_at"]
            if hasattr(exp, "tzinfo") and exp.tzinfo is None:
                from datetime import timezone as _tz
                exp = exp.replace(tzinfo=_tz.utc)
            if exp <= now:
                return {"valid": False, "reason": "expired"}
        if rec["status"] != "active":
            return {"valid": False, "reason": "invalid"}
        self._write(
            "UPDATE api_keys SET last_used_at = NOW() WHERE key_id = %s",
            (rec["id"],),
        )
        return {
            "valid": True,
            "tenant_id": rec["tenant_id"],
            "key_id": rec["id"],
        }

    def create_api_key(
        self,
        tenant_id: str,
        key_name: str,
        created_by: str,
        expires_at: Optional[datetime] = None,
    ) -> Tuple[str, int]:
        """Create a new API key. Returns (key_value, key_id).

        The key_value is returned exactly once and never stored.
        Only the SHA-256 hash is persisted.
        """
        key_secret = secrets.token_urlsafe(32)
        key_value = f"pvt_live_{key_secret}"
        key_prefix = key_value[:32]
        key_hash = self._hash_api_key(key_value)
        row = self._write_returning(
            "INSERT INTO api_keys "
            "(tenant_id, key_hash, key_prefix, key_name, status, created_by, expires_at) "
            "VALUES (%s, %s, %s, %s, 'active', %s, %s) RETURNING key_id",
            (tenant_id, key_hash, key_prefix, key_name, created_by, expires_at),
        )
        key_id = row[0]
        return (key_value, key_id)

    def list_api_keys(self, tenant_id: str) -> List[Dict[str, Any]]:
        """List all API keys for a tenant. Never returns key_value or key_hash."""
        return self._read_dicts(
            "SELECT key_id AS id, key_name, status, created_at, expires_at, "
            "last_used_at, created_by "
            "FROM api_keys WHERE tenant_id = %s "
            "ORDER BY created_at DESC",
            (tenant_id,),
        )

    def revoke_api_key(self, tenant_id: str, key_id: int) -> bool:
        """Revoke an API key. Idempotent."""
        self._write(
            "UPDATE api_keys SET status = 'revoked' "
            "WHERE key_id = %s AND tenant_id = %s",
            (key_id, tenant_id),
        )
        return True

    def rotate_api_key(
        self,
        tenant_id: str,
        key_id: int,
        created_by: str,
    ) -> Tuple[str, int]:
        """Revoke old key and create new key atomically. Returns (new_key_value, new_key_id)."""
        key_secret = secrets.token_urlsafe(32)
        new_key_value = f"pvt_live_{key_secret}"
        new_key_prefix = new_key_value[:16]
        new_key_hash = self._hash_api_key(new_key_value)
        conn = self._writer_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT key_name FROM api_keys "
                    "WHERE key_id = %s AND tenant_id = %s",
                    (key_id, tenant_id),
                )
                old = cur.fetchone()
                if not old:
                    raise ValueError(f"API key {key_id} not found for tenant {tenant_id}")
                key_name = old[0]
                cur.execute(
                    "UPDATE api_keys SET status = 'revoked' "
                    "WHERE key_id = %s AND tenant_id = %s",
                    (key_id, tenant_id),
                )
                cur.execute(
                    "INSERT INTO api_keys "
                    "(tenant_id, key_hash, key_prefix, key_name, status, created_by) "
                    "VALUES (%s, %s, %s, %s, 'active', %s) RETURNING key_id",
                    (tenant_id, new_key_hash, new_key_prefix, key_name, created_by),
                )
                new_key_id = cur.fetchone()[0]
            conn.commit()
            return (new_key_value, new_key_id)
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_putconn(conn)

    # -- Deployment Gate & Compliance (Unified Platform Features) -------------

    def _table_exists(self, table_name: str) -> bool:
        """Check if a table exists in the PostgreSQL schema."""
        rows = self._read_dicts(
            "SELECT 1 FROM information_schema.tables "
            "WHERE table_schema = 'public' AND table_name = %s",
            (table_name,),
        )
        return len(rows) > 0

    def get_deployment_gate_status(self) -> Dict[str, Any]:
        """Get deployment gate status across all models/tenants."""
        if not self._table_exists("deployment_decisions"):
            return {
                "total_deployments": 0,
                "approved": 0,
                "blocked": 0,
                "recent_decisions": [],
            }

        row = self._read_one(
            "SELECT COUNT(*) AS total, "
            "SUM(CASE WHEN deployment_approved = TRUE THEN 1 ELSE 0 END) AS approved, "
            "SUM(CASE WHEN deployment_approved = FALSE THEN 1 ELSE 0 END) AS blocked "
            "FROM deployment_decisions"
        )
        total = row[0] if row else 0
        approved = row[1] if row else 0
        blocked = row[2] if row else 0

        recent = self._read_dicts(
            "SELECT model_name, model_version, deployment_approved, "
            "blocking_findings_count, timestamp, attestation_id "
            "FROM deployment_decisions "
            "ORDER BY timestamp DESC LIMIT 20"
        )

        return {
            "total_deployments": total or 0,
            "approved": approved or 0,
            "blocked": blocked or 0,
            "approval_rate": round((approved or 0) / max(total or 0, 1) * 100, 1),
            "recent_decisions": recent,
        }

    def get_compliance_violations(self) -> Dict[str, Any]:
        """Get active compliance violations across all models."""
        if not self._table_exists("compliance_violations"):
            return {
                "violations": [],
                "total_count": 0,
                "critical_count": 0,
                "by_regulation": {},
            }

        violations = self._read_dicts(
            "SELECT model_name, model_version, violation_type, severity, "
            "regulation, description, created_at, resolved "
            "FROM compliance_violations "
            "WHERE resolved = FALSE "
            "ORDER BY CASE severity "
            "  WHEN 'critical' THEN 0 WHEN 'warning' THEN 1 ELSE 2 "
            "END, created_at DESC LIMIT 100"
        )

        total = len(violations)
        critical = sum(1 for v in violations if v.get("severity") == "critical")

        by_regulation: Dict[str, int] = {}
        for v in violations:
            reg = v.get("regulation", "unknown")
            by_regulation[reg] = by_regulation.get(reg, 0) + 1

        return {
            "violations": violations,
            "total_count": total,
            "critical_count": critical,
            "by_regulation": by_regulation,
        }

    def get_fairness_regression_trends(self) -> Dict[str, Any]:
        """Get fairness regression trends across model versions."""
        if not self._table_exists("fairness_regression"):
            return {"models": [], "degrading_count": 0}

        trends = self._read_dicts(
            "SELECT model_name, current_version, previous_version, "
            "disparate_impact_change, degradation_detected, created_at "
            "FROM fairness_regression "
            "ORDER BY created_at DESC LIMIT 50"
        )

        degrading = sum(1 for t in trends if t.get("degradation_detected") is True)

        return {
            "models": trends,
            "degrading_count": degrading,
            "total_comparisons": len(trends),
        }

    def get_model_lifecycle(self, model_name: str) -> Dict[str, Any]:
        """Get complete lifecycle view for a specific model."""
        if not self._table_exists("deployment_decisions"):
            return {
                "model_name": model_name,
                "versions": [],
                "fairness_trend": [],
            }

        versions = self._read_dicts(
            "SELECT model_version, deployment_approved, timestamp, "
            "blocking_findings_count, attestation_id "
            "FROM deployment_decisions "
            "WHERE model_name = %s "
            "ORDER BY timestamp DESC",
            (model_name,),
        )

        fairness_trend = []
        for v in versions:
            fairness_trend.append({
                "version": v["model_version"],
                "timestamp": v["timestamp"],
                "approved": v["deployment_approved"],
            })

        return {
            "model_name": model_name,
            "versions": versions,
            "fairness_trend": fairness_trend,
        }

    # -- Billing & Subscriptions ---------------------------------------------

    def create_tenant(self, tenant_id: str, name: str, tier: str = 'starter') -> None:
        self._write(
            "INSERT INTO tenants (tenant_id, name, tier) VALUES (%s, %s, %s) "
            "ON CONFLICT (tenant_id) DO UPDATE SET name = EXCLUDED.name, tier = EXCLUDED.tier",
            (tenant_id, name, tier),
        )

    def get_subscription(self, tenant_id: str) -> Optional[Dict[str, Any]]:
        return self._read_dict(
            "SELECT * FROM subscriptions WHERE tenant_id = %s",
            (tenant_id,),
        )

    def upsert_subscription(self, tenant_id: str, **fields) -> None:
        allowed = ['plan', 'status', 'stripe_customer_id', 'stripe_subscription_id',
                   'current_period_start', 'current_period_end', 'cancel_at_period_end', 'trial_end']
        updates = {k: v for k, v in fields.items() if k in allowed}
        if not updates:
            return
        set_clause = ', '.join(f"{k} = %s" for k in updates)
        set_clause += ', updated_at = NOW()'
        values = list(updates.values())
        self._write(
            f"INSERT INTO subscriptions (tenant_id, plan, status) VALUES (%s, %s, %s) "
            f"ON CONFLICT (tenant_id) DO UPDATE SET {set_clause}",
            tuple([tenant_id, updates.get('plan', 'starter'), updates.get('status', 'active')] + values),
        )

    def get_tenant_by_stripe_customer(self, stripe_customer_id: str) -> Optional[str]:
        row = self._read_dict(
            "SELECT tenant_id FROM subscriptions WHERE stripe_customer_id = %s",
            (stripe_customer_id,),
        )
        return row['tenant_id'] if row else None

    # -- Usage Tracking ------------------------------------------------------

    def increment_usage(self, tenant_id: str, event_type: str, billing_period: int, quantity: int = 1) -> None:
        self._write(
            "INSERT INTO usage_events (tenant_id, event_type, quantity, billing_period) VALUES (%s, %s, %s, %s)",
            (tenant_id, event_type, quantity, billing_period),
        )

    def get_usage_this_period(self, tenant_id: str, billing_period: int) -> Dict[str, int]:
        rows = self._read_dicts(
            "SELECT event_type, SUM(quantity) AS total FROM usage_events "
            "WHERE tenant_id = %s AND billing_period = %s GROUP BY event_type",
            (tenant_id, billing_period),
        )
        return {row['event_type']: row['total'] for row in rows}

    def get_usage_by_month(self, tenant_id: str, num_months: int = 12) -> List[Dict[str, Any]]:
        rows = self._read_dicts(
            """select billing_period, event_type, sum(quantity) as total
               from usage_events
               where tenant_id = %s
               group by billing_period, event_type
               order by billing_period desc
               limit %s""",
            (tenant_id, num_months * 10),
        )
        by_period: Dict[int, Dict[str, int]] = {}
        for r in rows:
            p = r["billing_period"]
            if p not in by_period:
                by_period[p] = {}
            by_period[p][r["event_type"]] = int(r["total"] or 0)
        result = []
        for period in sorted(by_period.keys(), reverse=True)[:num_months]:
            usage = by_period[period]
            mv  = usage.get("model_validations", 0)
            pr  = usage.get("pipeline_runs", 0)
            sgb = float(usage.get("storage_gb", 0))
            egb = float(usage.get("egress_gb", 0))
            base_cost = 199.0
            total = round(base_cost + mv * 10.0 + pr * 2.0 + sgb * 0.25 + egb * 0.20, 2)
            year  = period // 100
            month = period % 100
            result.append({
                "period": period,
                "period_label": datetime(year, month, 1).strftime("%B %Y"),
                "model_validations": mv,
                "pipeline_runs": pr,
                "storage_gb": round(sgb, 2),
                "egress_gb": round(egb, 2),
                "base_cost": base_cost,
                "total": total,
            })
        return result

    # -- Notification Preferences --------------------------------------------

    def get_notification_preferences(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            "SELECT np.*, u.email FROM notification_preferences np "
            "JOIN dashboard_users u ON u.id = np.user_id WHERE np.tenant_id = %s",
            (tenant_id,),
        )

    def upsert_notification_preferences(self, tenant_id: str, user_id: int, **fields) -> None:
        allowed = ['email_enabled', 'slack_webhook_url', 'event_types']
        updates = {k: v for k, v in fields.items() if k in allowed}
        if not updates:
            return
        set_clause = ', '.join(f"{k} = %s" for k in updates)
        set_clause += ', updated_at = NOW()'
        values = list(updates.values())
        self._write(
            f"INSERT INTO notification_preferences (tenant_id, user_id) VALUES (%s, %s) "
            f"ON CONFLICT (tenant_id, user_id) DO UPDATE SET {set_clause}",
            tuple([tenant_id, user_id] + values),
        )

    # -- Score Profiles ------------------------------------------------------

    def list_score_profiles(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            "SELECT * FROM score_profiles WHERE tenant_id = %s ORDER BY is_default DESC, name ASC",
            (tenant_id,),
        )

    def get_score_profile(self, tenant_id: str, profile_id: int) -> Optional[Dict[str, Any]]:
        return self._read_dict(
            "SELECT * FROM score_profiles WHERE tenant_id = %s AND id = %s",
            (tenant_id, profile_id),
        )

    def create_score_profile(self, tenant_id: str, name: str, description: str, config: dict, created_by: Optional[str]) -> Optional[Dict[str, Any]]:
        import json as _json
        conn = self._writer_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO score_profiles (tenant_id, name, description, config, created_by) "
                    "VALUES (%s, %s, %s, %s, %s) RETURNING *",
                    (tenant_id, name, description, _json.dumps(config), created_by),
                )
                cols = [desc[0] for desc in cur.description]
                row = cur.fetchone()
            conn.commit()
            return dict(zip(cols, row)) if row else None
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_putconn(conn)

    def update_score_profile(self, tenant_id: str, profile_id: int, name: str, description: str, config: dict, updated_by: str) -> Optional[Dict[str, Any]]:
        import json as _json
        conn = self._writer_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE score_profiles SET name=%s, description=%s, config=%s, updated_by=%s, updated_at=NOW() "
                    "WHERE tenant_id=%s AND id=%s RETURNING *",
                    (name, description, _json.dumps(config), updated_by, tenant_id, profile_id),
                )
                cols = [desc[0] for desc in cur.description]
                row = cur.fetchone()
            conn.commit()
            return dict(zip(cols, row)) if row else None
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_putconn(conn)

    def delete_score_profile(self, tenant_id: str, profile_id: int) -> None:
        prof = self.get_score_profile(tenant_id, profile_id)
        if prof and prof.get('is_default'):
            count = self._read_dict(
                "SELECT COUNT(*) AS cnt FROM score_profiles WHERE tenant_id=%s",
                (tenant_id,),
            )
            if count and count['cnt'] <= 1:
                raise ValueError("Cannot delete the only default profile")
        self._write(
            "DELETE FROM score_profiles WHERE tenant_id=%s AND id=%s",
            (tenant_id, profile_id),
        )

    def set_default_profile(self, tenant_id: str, profile_id: int) -> None:
        conn = self._writer_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE score_profiles SET is_default=FALSE WHERE tenant_id=%s",
                    (tenant_id,),
                )
                cur.execute(
                    "UPDATE score_profiles SET is_default=TRUE WHERE tenant_id=%s AND id=%s",
                    (tenant_id, profile_id),
                )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_putconn(conn)

    def get_default_score_profile(self, tenant_id: str) -> Optional[Dict[str, Any]]:
        return self._read_dict(
            "SELECT id, tenant_id, name, description, is_default, config, "
            "created_by, created_at, updated_by, updated_at "
            "FROM score_profiles "
            "WHERE tenant_id = %s AND is_default = TRUE "
            "LIMIT 1",
            (tenant_id,),
        )

    def clone_score_profile(self, tenant_id: str, profile_id: int,
                            new_name: str, cloned_by: Optional[str] = None) -> Optional[Dict[str, Any]]:
        source = self.get_score_profile(tenant_id, profile_id)
        if not source:
            raise ValueError(f"Profile {profile_id} not found")
        return self.create_score_profile(
            tenant_id=tenant_id,
            name=new_name,
            description=f"Cloned from {source['name']}",
            config=source['config'],
            created_by=cloned_by,
        )

    # -- Model Profile Assignments -------------------------------------------

    def list_model_profile_assignments(self, tenant_id: str) -> List[Dict[str, Any]]:
        return self._read_dicts(
            "SELECT mpa.id, mpa.tenant_id, mpa.model_id, mpa.profile_id, "
            "mpa.assigned_by, mpa.assigned_at, sp.name AS profile_name "
            "FROM model_profile_assignments mpa "
            "JOIN score_profiles sp ON sp.id = mpa.profile_id "
            "WHERE mpa.tenant_id = %s "
            "ORDER BY mpa.assigned_at DESC",
            (tenant_id,),
        )

    def get_model_profile_assignment(self, tenant_id: str,
                                     model_id: str) -> Optional[Dict[str, Any]]:
        return self._read_dict(
            "SELECT mpa.id, mpa.tenant_id, mpa.model_id, mpa.profile_id, "
            "mpa.assigned_by, mpa.assigned_at, sp.name AS profile_name, "
            "sp.config AS profile_config "
            "FROM model_profile_assignments mpa "
            "JOIN score_profiles sp ON sp.id = mpa.profile_id "
            "WHERE mpa.tenant_id = %s AND mpa.model_id = %s",
            (tenant_id, model_id),
        )

    def upsert_model_profile_assignment(self, tenant_id: str, model_id: str,
                                        profile_id: int,
                                        assigned_by: Optional[str] = None) -> Optional[Dict[str, Any]]:
        conn = self._writer_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO model_profile_assignments "
                    "(tenant_id, model_id, profile_id, assigned_by) "
                    "VALUES (%s, %s, %s, %s) "
                    "ON CONFLICT (tenant_id, model_id) DO UPDATE "
                    "SET profile_id = EXCLUDED.profile_id, "
                    "assigned_by = EXCLUDED.assigned_by, "
                    "assigned_at = NOW() "
                    "RETURNING id, tenant_id, model_id, profile_id, assigned_by, assigned_at",
                    (tenant_id, model_id, profile_id, assigned_by),
                )
                cols = [desc[0] for desc in cur.description]
                row = cur.fetchone()
            conn.commit()
            return dict(zip(cols, row)) if row else None
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_putconn(conn)

    def delete_model_profile_assignment(self, tenant_id: str,
                                        model_id: str) -> None:
        self._write(
            "DELETE FROM model_profile_assignments "
            "WHERE tenant_id = %s AND model_id = %s",
            (tenant_id, model_id),
        )

    # -- Compliance Templates ------------------------------------------------

    def list_compliance_templates(self) -> List[Dict[str, Any]]:
        return self._read_dicts(
            "SELECT id, name, description, config, created_at "
            "FROM compliance_templates ORDER BY name"
        )

    def get_compliance_template(self, template_id: str) -> Optional[Dict[str, Any]]:
        return self._read_dict(
            "SELECT id, name, description, config, created_at "
            "FROM compliance_templates WHERE id = %s",
            (template_id,),
        )

    def _seed_compliance_templates(self) -> None:
        """Seed built-in compliance templates if they don't exist."""
        templates = [
            {
                "id": "us_bank_lending",
                "name": "US Bank Lending",
                "description": "ECOA + SR 11-7 for US bank lending models. EU AI Act disabled.",
                "config": {
                    "version": "2.0",
                    "checks": {
                        "ecoa.protected_attributes": {"enabled": True, "action": "block"},
                        "ecoa.protected_influence": {"enabled": True, "action": "block"},
                        "ecoa.disparate_impact": {"enabled": True, "action": "block"},
                        "ecoa.intersectional_impact": {"enabled": True, "action": "block"},
                        "ecoa.adverse_action": {"enabled": True, "action": "block"},
                        "ecoa.adverse_action_completeness": {"enabled": True, "action": "warn"},
                        "ecoa.model_explainability": {"enabled": True, "action": "block"},
                        "ecoa.record_retention": {"enabled": True, "action": "warn"},
                        "ecoa.information_requests": {"enabled": True, "action": "warn"},
                        "ecoa.hmda_monitoring": {"enabled": True, "action": "warn"},
                        "ecoa.sogi_protection": {"enabled": True, "action": "warn"},
                        "ecoa.model_governance": {"enabled": True, "action": "warn"},
                        "ecoa.reason_specificity": {"enabled": True, "action": "warn"},
                        "sr117.model_inventory": {"enabled": True, "action": "warn"},
                        "sr117.model_tiering": {"enabled": True, "action": "warn"},
                        "sr117.validation": {"enabled": True, "action": "warn"},
                        "sr117.independent_validation": {"enabled": True, "action": "warn"},
                        "sr117.challenger_models": {"enabled": True, "action": "warn"},
                        "sr117.ongoing_monitoring": {"enabled": True, "action": "warn"},
                        "sr117.monitoring_frequency_alignment": {"enabled": True, "action": "warn"},
                        "sr117.change_management": {"enabled": True, "action": "warn"},
                        "sr117.data_governance": {"enabled": True, "action": "warn"},
                        "sr117.concentration_risk": {"enabled": True, "action": "warn"},
                        "sr117.use_limitations": {"enabled": True, "action": "warn"},
                        "sr117.vendor_models": {"enabled": True, "action": "block"},
                        "sr117.governance_controls": {"enabled": True, "action": "warn"},
                        "sr117.governance_framework": {"enabled": True, "action": "warn"},
                        "sr117.model_documentation": {"enabled": True, "action": "warn"}
                    },
                    "fairness": {
                        "enabled": True,
                        "four_fifths_threshold": 0.80,
                        "proxy_correlation_threshold": 0.50,
                        "run_lda_search": True,
                        "run_adverse_action": True,
                        "action_on_disparate_impact": "block"
                    },
                    "scoring": {
                        "critical_deduction": 8.0,
                        "warning_deduction": 3.0,
                        "grade_thresholds": {"A": 90, "B": 75, "C": 60, "D": 40}
                    },
                    "actions": {
                        "critical_default": "block",
                        "warning_default": "warn",
                        "info_default": "ignore"
                    },
                    "regulation_weights": {"ECOA / Reg B": 1.5, "SR 11-7": 1.3},
                    "regulation_enabled": {"ecoa": True, "sr117": True, "eu_ai_act": False}
                }
            },
            {
                "id": "eu_credit_scoring",
                "name": "EU Credit Scoring",
                "description": "All three regulations enabled for EU-based credit scoring models.",
                "config": {
                    "version": "2.0",
                    "checks": {
                        "ecoa.protected_attributes": {"enabled": True, "action": "block"},
                        "ecoa.protected_influence": {"enabled": True, "action": "block"},
                        "ecoa.disparate_impact": {"enabled": True, "action": "block"},
                        "ecoa.intersectional_impact": {"enabled": True, "action": "block"},
                        "ecoa.adverse_action": {"enabled": True, "action": "block"},
                        "ecoa.adverse_action_completeness": {"enabled": True, "action": "warn"},
                        "ecoa.model_explainability": {"enabled": True, "action": "block"},
                        "ecoa.record_retention": {"enabled": True, "action": "warn"},
                        "ecoa.information_requests": {"enabled": True, "action": "warn"},
                        "ecoa.hmda_monitoring": {"enabled": True, "action": "warn"},
                        "ecoa.sogi_protection": {"enabled": True, "action": "warn"},
                        "ecoa.model_governance": {"enabled": True, "action": "warn"},
                        "ecoa.reason_specificity": {"enabled": True, "action": "warn"},
                        "sr117.model_inventory": {"enabled": True, "action": "warn"},
                        "sr117.model_tiering": {"enabled": True, "action": "warn"},
                        "sr117.validation": {"enabled": True, "action": "block"},
                        "sr117.independent_validation": {"enabled": True, "action": "block"},
                        "sr117.challenger_models": {"enabled": True, "action": "warn"},
                        "sr117.ongoing_monitoring": {"enabled": True, "action": "warn"},
                        "sr117.monitoring_frequency_alignment": {"enabled": True, "action": "warn"},
                        "sr117.change_management": {"enabled": True, "action": "warn"},
                        "sr117.data_governance": {"enabled": True, "action": "warn"},
                        "sr117.concentration_risk": {"enabled": True, "action": "warn"},
                        "sr117.use_limitations": {"enabled": True, "action": "warn"},
                        "sr117.vendor_models": {"enabled": True, "action": "block"},
                        "sr117.governance_controls": {"enabled": True, "action": "warn"},
                        "sr117.governance_framework": {"enabled": True, "action": "warn"},
                        "sr117.model_documentation": {"enabled": True, "action": "warn"},
                        "eu_ai_act.risk_classification": {"enabled": True, "action": "block"},
                        "eu_ai_act.risk_management": {"enabled": True, "action": "block"},
                        "eu_ai_act.logging": {"enabled": True, "action": "warn"},
                        "eu_ai_act.traceability": {"enabled": True, "action": "warn"},
                        "eu_ai_act.human_oversight": {"enabled": True, "action": "block"},
                        "eu_ai_act.data_governance": {"enabled": True, "action": "warn"},
                        "eu_ai_act.technical_documentation": {"enabled": True, "action": "warn"},
                        "eu_ai_act.transparency": {"enabled": True, "action": "warn"},
                        "eu_ai_act.accuracy_robustness": {"enabled": True, "action": "warn"},
                        "eu_ai_act.cybersecurity": {"enabled": True, "action": "warn"},
                        "eu_ai_act.fundamental_rights_impact": {"enabled": True, "action": "block"},
                        "eu_ai_act.data_bias_representativeness": {"enabled": True, "action": "warn"},
                        "eu_ai_act.quality_management": {"enabled": True, "action": "warn"}
                    },
                    "fairness": {
                        "enabled": True,
                        "four_fifths_threshold": 0.80,
                        "proxy_correlation_threshold": 0.50,
                        "run_lda_search": True,
                        "run_adverse_action": True,
                        "action_on_disparate_impact": "block"
                    },
                    "scoring": {
                        "critical_deduction": 8.0,
                        "warning_deduction": 3.0,
                        "grade_thresholds": {"A": 90, "B": 75, "C": 60, "D": 40}
                    },
                    "actions": {
                        "critical_default": "block",
                        "warning_default": "warn",
                        "info_default": "ignore"
                    },
                    "regulation_weights": {"ECOA / Reg B": 1.5, "SR 11-7": 1.3, "EU AI Act": 1.2},
                    "regulation_enabled": {"ecoa": True, "sr117": True, "eu_ai_act": True}
                }
            },
            {
                "id": "risk_management_only",
                "name": "Risk Management Only",
                "description": "SR 11-7 only with fairness monitoring. No ECOA or EU AI Act checks.",
                "config": {
                    "version": "2.0",
                    "checks": {
                        "sr117.model_inventory": {"enabled": True, "action": "warn"},
                        "sr117.model_tiering": {"enabled": True, "action": "warn"},
                        "sr117.validation": {"enabled": True, "action": "warn"},
                        "sr117.independent_validation": {"enabled": True, "action": "warn"},
                        "sr117.challenger_models": {"enabled": True, "action": "warn"},
                        "sr117.ongoing_monitoring": {"enabled": True, "action": "warn"},
                        "sr117.monitoring_frequency_alignment": {"enabled": True, "action": "warn"},
                        "sr117.change_management": {"enabled": True, "action": "warn"},
                        "sr117.data_governance": {"enabled": True, "action": "warn"},
                        "sr117.concentration_risk": {"enabled": True, "action": "warn"},
                        "sr117.use_limitations": {"enabled": True, "action": "warn"},
                        "sr117.vendor_models": {"enabled": True, "action": "warn"},
                        "sr117.governance_controls": {"enabled": True, "action": "warn"},
                        "sr117.governance_framework": {"enabled": True, "action": "warn"},
                        "sr117.model_documentation": {"enabled": True, "action": "warn"}
                    },
                    "fairness": {
                        "enabled": True,
                        "four_fifths_threshold": 0.80,
                        "proxy_correlation_threshold": 0.50,
                        "run_lda_search": True,
                        "run_adverse_action": False,
                        "action_on_disparate_impact": "warn"
                    },
                    "scoring": {
                        "critical_deduction": 8.0,
                        "warning_deduction": 3.0,
                        "grade_thresholds": {"A": 90, "B": 75, "C": 60, "D": 40}
                    },
                    "actions": {
                        "critical_default": "warn",
                        "warning_default": "warn",
                        "info_default": "ignore"
                    },
                    "regulation_weights": {"SR 11-7": 1.3},
                    "regulation_enabled": {"ecoa": False, "sr117": True, "eu_ai_act": False}
                }
            },
            {
                "id": "eu_ai_act_only",
                "name": "EU AI Act Only",
                "description": "EU AI Act compliance checks only. For non-US AI systems.",
                "config": {
                    "version": "2.0",
                    "checks": {
                        "eu_ai_act.risk_classification": {"enabled": True, "action": "block"},
                        "eu_ai_act.risk_management": {"enabled": True, "action": "block"},
                        "eu_ai_act.logging": {"enabled": True, "action": "warn"},
                        "eu_ai_act.traceability": {"enabled": True, "action": "warn"},
                        "eu_ai_act.human_oversight": {"enabled": True, "action": "block"},
                        "eu_ai_act.data_governance": {"enabled": True, "action": "warn"},
                        "eu_ai_act.technical_documentation": {"enabled": True, "action": "warn"},
                        "eu_ai_act.transparency": {"enabled": True, "action": "warn"},
                        "eu_ai_act.accuracy_robustness": {"enabled": True, "action": "warn"},
                        "eu_ai_act.cybersecurity": {"enabled": True, "action": "warn"},
                        "eu_ai_act.fundamental_rights_impact": {"enabled": True, "action": "block"},
                        "eu_ai_act.data_bias_representativeness": {"enabled": True, "action": "warn"},
                        "eu_ai_act.quality_management": {"enabled": True, "action": "warn"}
                    },
                    "fairness": {
                        "enabled": True,
                        "four_fifths_threshold": 0.80,
                        "proxy_correlation_threshold": 0.50,
                        "run_lda_search": True,
                        "run_adverse_action": False,
                        "action_on_disparate_impact": "block"
                    },
                    "scoring": {
                        "critical_deduction": 8.0,
                        "warning_deduction": 3.0,
                        "grade_thresholds": {"A": 90, "B": 75, "C": 60, "D": 40}
                    },
                    "actions": {
                        "critical_default": "block",
                        "warning_default": "warn",
                        "info_default": "ignore"
                    },
                    "regulation_weights": {"EU AI Act": 1.2},
                    "regulation_enabled": {"ecoa": False, "sr117": False, "eu_ai_act": True}
                }
            },
            {
                "id": "strict_everything",
                "name": "Strict Everything",
                "description": "All checks enabled with block action. DI threshold 0.85. Maximum strictness.",
                "config": {
                    "version": "2.0",
                    "checks": {
                        "ecoa.protected_attributes": {"enabled": True, "action": "block"},
                        "ecoa.protected_influence": {"enabled": True, "action": "block"},
                        "ecoa.disparate_impact": {"enabled": True, "action": "block"},
                        "ecoa.intersectional_impact": {"enabled": True, "action": "block"},
                        "ecoa.adverse_action": {"enabled": True, "action": "block"},
                        "ecoa.adverse_action_completeness": {"enabled": True, "action": "block"},
                        "ecoa.model_explainability": {"enabled": True, "action": "block"},
                        "ecoa.record_retention": {"enabled": True, "action": "block"},
                        "ecoa.information_requests": {"enabled": True, "action": "block"},
                        "ecoa.hmda_monitoring": {"enabled": True, "action": "block"},
                        "ecoa.sogi_protection": {"enabled": True, "action": "block"},
                        "ecoa.model_governance": {"enabled": True, "action": "block"},
                        "ecoa.reason_specificity": {"enabled": True, "action": "block"},
                        "sr117.model_inventory": {"enabled": True, "action": "block"},
                        "sr117.model_tiering": {"enabled": True, "action": "block"},
                        "sr117.validation": {"enabled": True, "action": "block"},
                        "sr117.independent_validation": {"enabled": True, "action": "block"},
                        "sr117.challenger_models": {"enabled": True, "action": "block"},
                        "sr117.ongoing_monitoring": {"enabled": True, "action": "block"},
                        "sr117.monitoring_frequency_alignment": {"enabled": True, "action": "block"},
                        "sr117.change_management": {"enabled": True, "action": "block"},
                        "sr117.data_governance": {"enabled": True, "action": "block"},
                        "sr117.concentration_risk": {"enabled": True, "action": "block"},
                        "sr117.use_limitations": {"enabled": True, "action": "block"},
                        "sr117.vendor_models": {"enabled": True, "action": "block"},
                        "sr117.governance_controls": {"enabled": True, "action": "block"},
                        "sr117.governance_framework": {"enabled": True, "action": "block"},
                        "sr117.model_documentation": {"enabled": True, "action": "block"},
                        "eu_ai_act.risk_classification": {"enabled": True, "action": "block"},
                        "eu_ai_act.risk_management": {"enabled": True, "action": "block"},
                        "eu_ai_act.logging": {"enabled": True, "action": "block"},
                        "eu_ai_act.traceability": {"enabled": True, "action": "block"},
                        "eu_ai_act.human_oversight": {"enabled": True, "action": "block"},
                        "eu_ai_act.data_governance": {"enabled": True, "action": "block"},
                        "eu_ai_act.technical_documentation": {"enabled": True, "action": "block"},
                        "eu_ai_act.transparency": {"enabled": True, "action": "block"},
                        "eu_ai_act.accuracy_robustness": {"enabled": True, "action": "block"},
                        "eu_ai_act.cybersecurity": {"enabled": True, "action": "block"},
                        "eu_ai_act.fundamental_rights_impact": {"enabled": True, "action": "block"},
                        "eu_ai_act.data_bias_representativeness": {"enabled": True, "action": "block"},
                        "eu_ai_act.quality_management": {"enabled": True, "action": "block"}
                    },
                    "fairness": {
                        "enabled": True,
                        "four_fifths_threshold": 0.85,
                        "proxy_correlation_threshold": 0.40,
                        "run_lda_search": True,
                        "run_adverse_action": True,
                        "action_on_disparate_impact": "block"
                    },
                    "scoring": {
                        "critical_deduction": 10.0,
                        "warning_deduction": 5.0,
                        "grade_thresholds": {"A": 95, "B": 85, "C": 70, "D": 50}
                    },
                    "actions": {
                        "critical_default": "block",
                        "warning_default": "block",
                        "info_default": "warn"
                    },
                    "regulation_weights": {"ECOA / Reg B": 1.5, "SR 11-7": 1.3, "EU AI Act": 1.2},
                    "regulation_enabled": {"ecoa": True, "sr117": True, "eu_ai_act": True}
                }
            },
            {
                "id": "monitor_only",
                "name": "Monitor Only",
                "description": "All checks run but nothing blocks deployment. Everything set to warn.",
                "config": {
                    "version": "2.0",
                    "checks": {
                        "ecoa.protected_attributes": {"enabled": True, "action": "warn"},
                        "ecoa.protected_influence": {"enabled": True, "action": "warn"},
                        "ecoa.disparate_impact": {"enabled": True, "action": "warn"},
                        "ecoa.intersectional_impact": {"enabled": True, "action": "warn"},
                        "ecoa.adverse_action": {"enabled": True, "action": "warn"},
                        "ecoa.adverse_action_completeness": {"enabled": True, "action": "warn"},
                        "ecoa.model_explainability": {"enabled": True, "action": "warn"},
                        "ecoa.record_retention": {"enabled": True, "action": "warn"},
                        "ecoa.information_requests": {"enabled": True, "action": "warn"},
                        "ecoa.hmda_monitoring": {"enabled": True, "action": "warn"},
                        "ecoa.sogi_protection": {"enabled": True, "action": "warn"},
                        "ecoa.model_governance": {"enabled": True, "action": "warn"},
                        "ecoa.reason_specificity": {"enabled": True, "action": "warn"},
                        "sr117.model_inventory": {"enabled": True, "action": "warn"},
                        "sr117.model_tiering": {"enabled": True, "action": "warn"},
                        "sr117.validation": {"enabled": True, "action": "warn"},
                        "sr117.independent_validation": {"enabled": True, "action": "warn"},
                        "sr117.challenger_models": {"enabled": True, "action": "warn"},
                        "sr117.ongoing_monitoring": {"enabled": True, "action": "warn"},
                        "sr117.monitoring_frequency_alignment": {"enabled": True, "action": "warn"},
                        "sr117.change_management": {"enabled": True, "action": "warn"},
                        "sr117.data_governance": {"enabled": True, "action": "warn"},
                        "sr117.concentration_risk": {"enabled": True, "action": "warn"},
                        "sr117.use_limitations": {"enabled": True, "action": "warn"},
                        "sr117.vendor_models": {"enabled": True, "action": "warn"},
                        "sr117.governance_controls": {"enabled": True, "action": "warn"},
                        "sr117.governance_framework": {"enabled": True, "action": "warn"},
                        "sr117.model_documentation": {"enabled": True, "action": "warn"},
                        "eu_ai_act.risk_classification": {"enabled": True, "action": "warn"},
                        "eu_ai_act.risk_management": {"enabled": True, "action": "warn"},
                        "eu_ai_act.logging": {"enabled": True, "action": "warn"},
                        "eu_ai_act.traceability": {"enabled": True, "action": "warn"},
                        "eu_ai_act.human_oversight": {"enabled": True, "action": "warn"},
                        "eu_ai_act.data_governance": {"enabled": True, "action": "warn"},
                        "eu_ai_act.technical_documentation": {"enabled": True, "action": "warn"},
                        "eu_ai_act.transparency": {"enabled": True, "action": "warn"},
                        "eu_ai_act.accuracy_robustness": {"enabled": True, "action": "warn"},
                        "eu_ai_act.cybersecurity": {"enabled": True, "action": "warn"},
                        "eu_ai_act.fundamental_rights_impact": {"enabled": True, "action": "warn"},
                        "eu_ai_act.data_bias_representativeness": {"enabled": True, "action": "warn"},
                        "eu_ai_act.quality_management": {"enabled": True, "action": "warn"}
                    },
                    "fairness": {
                        "enabled": True,
                        "four_fifths_threshold": 0.80,
                        "proxy_correlation_threshold": 0.50,
                        "run_lda_search": True,
                        "run_adverse_action": True,
                        "action_on_disparate_impact": "warn"
                    },
                    "scoring": {
                        "critical_deduction": 8.0,
                        "warning_deduction": 3.0,
                        "grade_thresholds": {"A": 90, "B": 75, "C": 60, "D": 40}
                    },
                    "actions": {
                        "critical_default": "warn",
                        "warning_default": "warn",
                        "info_default": "ignore"
                    },
                    "regulation_weights": {"ECOA / Reg B": 1.5, "SR 11-7": 1.3, "EU AI Act": 1.2},
                    "regulation_enabled": {"ecoa": True, "sr117": True, "eu_ai_act": True}
                }
            },
        ]

        for t in templates:
            self._write(
                "INSERT INTO compliance_templates (id, name, description, config) "
                "VALUES (%s, %s, %s, %s) "
                "ON CONFLICT (id) DO NOTHING",
                (t["id"], t["name"], t["description"], json.dumps(t["config"])),
            )

    # -- Data retention cleanup ------------------------------------------------

    def cleanup_old_data(self) -> dict:
        counts = {}
        conn = self._writer_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "delete from alert_log where resolved = true and resolved_at < now() - interval '90 days'"
                )
                counts["alert_log"] = cur.rowcount
                cur.execute(
                    "delete from pipeline_row_results where timestamp < now() - interval '1 year'"
                )
                counts["pipeline_row_results"] = cur.rowcount
                cur.execute(
                    """delete from compliance_snapshots
                       where snapshot_at < now() - interval '2 years'
                       and id not in (
                           select distinct on (tenant_id, model_id) id
                           from compliance_snapshots
                           order by tenant_id, model_id, snapshot_at desc
                       )"""
                )
                counts["compliance_snapshots"] = cur.rowcount
            conn.commit()
        finally:
            self._writer_putconn(conn)
        return counts

    # -- Data Management (self-service deletion) --------------------------------

    def get_storage_summary(self, tenant_id: str) -> dict:
        row = self._read_one(
            """select
                (select count(*) from alert_log where tenant_id = %s),
                (select count(*) from compliance_snapshots where tenant_id = %s),
                (select count(*) from fairness_snapshots where tenant_id = %s),
                (select count(*) from pipeline_row_results where tenant_id = %s),
                (select count(*) from model_snapshots where tenant_id = %s),
                (select count(*) from model_attestations where tenant_id = %s),
                (select count(*) from compliance_exceptions where tenant_id = %s),
                (select count(*) from model_profile_assignments where tenant_id = %s),
                (select count(*) from data_deletion_log where tenant_id = %s)""",
            (tenant_id,) * 9,
        )
        if not row:
            return {}
        keys = [
            "alert_log", "compliance_snapshots", "fairness_snapshots",
            "pipeline_row_results", "model_snapshots", "model_attestations",
            "compliance_exceptions", "model_profile_assignments", "data_deletion_log",
        ]
        return {k: int(v) for k, v in zip(keys, row)}

    def delete_alerts_bulk(self, tenant_id: str, max_age_days: int,
                           include_unresolved: bool = False) -> int:
        sql = (
            "delete from alert_log where tenant_id = %s "
            "and created_at < now() - (%s || ' days')::interval"
        )
        params: tuple = (tenant_id, str(max_age_days))
        if not include_unresolved:
            sql += " and resolved = true"
        conn = self._writer_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                count = cur.rowcount
            conn.commit()
            return count
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_putconn(conn)

    def delete_snapshots_bulk(self, tenant_id: str, max_age_days: int) -> dict:
        conn = self._writer_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """delete from compliance_snapshots
                       where tenant_id = %s
                       and snapshot_at < now() - (%s || ' days')::interval
                       and id not in (
                           select distinct on (tenant_id) id
                           from compliance_snapshots
                           where tenant_id = %s
                           order by tenant_id, snapshot_at desc
                       )""",
                    (tenant_id, str(max_age_days), tenant_id),
                )
                compliance_count = cur.rowcount
                cur.execute(
                    """delete from fairness_snapshots
                       where tenant_id = %s
                       and snapshot_at < now() - (%s || ' days')::interval
                       and id not in (
                           select distinct on (tenant_id, model_id) id
                           from fairness_snapshots
                           where tenant_id = %s
                           order by tenant_id, model_id, snapshot_at desc
                       )""",
                    (tenant_id, str(max_age_days), tenant_id),
                )
                fairness_count = cur.rowcount
            conn.commit()
            return {"compliance": compliance_count, "fairness": fairness_count}
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_putconn(conn)

    def delete_pipeline_history_bulk(self, tenant_id: str, max_age_days: int) -> int:
        conn = self._writer_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "delete from pipeline_row_results where tenant_id = %s "
                    "and timestamp < now() - (%s || ' days')::interval",
                    (tenant_id, str(max_age_days)),
                )
                count = cur.rowcount
            conn.commit()
            return count
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_putconn(conn)

    def delete_model_all_data(self, tenant_id: str, model_id: str) -> dict:
        conn = self._writer_conn()
        counts: Dict[str, int] = {}
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "delete from compliance_exceptions where tenant_id = %s and model_id = %s",
                    (tenant_id, model_id),
                )
                counts["compliance_exceptions"] = cur.rowcount
                cur.execute(
                    "delete from model_attestations where tenant_id = %s and model_id = %s",
                    (tenant_id, model_id),
                )
                counts["model_attestations"] = cur.rowcount
                cur.execute(
                    "delete from model_profile_assignments where tenant_id = %s and model_id = %s",
                    (tenant_id, model_id),
                )
                counts["model_profile_assignments"] = cur.rowcount
                cur.execute(
                    "delete from fairness_snapshots where tenant_id = %s and model_id = %s",
                    (tenant_id, model_id),
                )
                counts["fairness_snapshots"] = cur.rowcount
                cur.execute(
                    "delete from model_feature_stats where tenant_id = %s and model_id = %s",
                    (tenant_id, model_id),
                )
                counts["model_feature_stats"] = cur.rowcount
                cur.execute(
                    "delete from model_snapshots where tenant_id = %s and model_id = %s",
                    (tenant_id, model_id),
                )
                counts["model_snapshots"] = cur.rowcount
                cur.execute(
                    "delete from alert_log where tenant_id = %s and model_id = %s",
                    (tenant_id, model_id),
                )
                counts["alert_log"] = cur.rowcount
            conn.commit()
            return counts
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_putconn(conn)

    def delete_compliance_snapshot(self, tenant_id: str, snapshot_id: int) -> int:
        conn = self._writer_conn()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    "delete from compliance_snapshots where id = %s and tenant_id = %s",
                    (snapshot_id, tenant_id),
                )
                count = cur.rowcount
            conn.commit()
            return count
        except Exception:
            conn.rollback()
            raise
        finally:
            self._writer_putconn(conn)

    def log_deletion(self, tenant_id: str, user_email: str, action: str,
                     resource_type: str, resource_id: Optional[str],
                     quantity: int, details: dict) -> None:
        self._write(
            """insert into data_deletion_log
               (tenant_id, user_email, action, resource_type, resource_id,
                quantity_deleted, details)
               values (%s, %s, %s, %s, %s, %s, %s)""",
            (tenant_id, user_email, action, resource_type, resource_id,
             quantity, json.dumps(details)),
        )

    def get_deletion_history(self, tenant_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        rows = self._read_dicts(
            """select id, user_email, action, resource_type, resource_id,
                      quantity_deleted, details, deleted_at
               from data_deletion_log
               where tenant_id = %s
               order by deleted_at desc
               limit %s""",
            (tenant_id, limit),
        )
        for r in rows:
            if hasattr(r.get("deleted_at"), "isoformat"):
                r["deleted_at"] = r["deleted_at"].isoformat()
        return rows
