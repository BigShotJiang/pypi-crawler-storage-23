"""
Attestant Deployment Gate: Hard technical gate that blocks non-compliant models.

This is the Stage 5 capability banks need: automated pre-deployment validation
that prevents models with compliance violations from reaching production.

The gate runs a battery of checks:
1. Disparate impact analysis (four-fifths rule)
2. Proxy variable detection and flagging
3. Adverse action reason code coverage
4. SR 11-7 model validation requirements
5. ECOA compliance verification
6. Fairness regression testing vs previous version

If any CRITICAL finding is present, deployment is BLOCKED with specific
remediation instructions. This prevents the $98M-$3.7B fair lending violations.

Usage:
    from attestant.deployment.gate import DeploymentGate

    gate = DeploymentGate(storage=s3_storage)
    result = gate.validate_deployment(
        model=xgb_model,
        model_name="credit_scoring_v2.1.0",
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        protected_data=protected_df,
        protected_columns=["race", "sex", "age"],
        model_factory=lambda: xgboost.XGBClassifier(...),
        previous_version="credit_scoring_v2.0.0",
    )

    if result.deployment_approved:
        deploy_to_production(model)
    else:
        print(result.blocking_findings)
        print(result.remediation_plan)

AWS Integration:
    The gate can be invoked as an AWS Lambda function via API Gateway,
    triggered by CI/CD pipelines before deployment. See
    deploy/cloudformation/deployment-gate.yaml for infrastructure setup.
"""

import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

import numpy as np
import pandas as pd

from ..fairness.engine import FairLensEngine, FairLensConfig, FairLensReport
from ..compliance.sr117 import SR117Engine
from ..compliance.ecoa import ECOAEngine
from ..compliance.base import Severity
from ..utilities.hydra32_dag import ComputationDAG
from ..persistence.storage import StorageBackend

logger = logging.getLogger(__name__)


class GateStatus(Enum):
    """Deployment gate decision."""
    APPROVED = "approved"
    BLOCKED = "blocked"
    WARNING = "warning"


@dataclass
class BlockingFinding:
    """A compliance finding that blocks deployment."""
    category: str
    description: str
    regulation_citation: str
    remediation: str
    severity: str


@dataclass
class DeploymentGateResult:
    """Complete deployment gate validation result."""
    deployment_approved: bool
    gate_status: GateStatus
    model_name: str
    model_version: str
    model_hash: str
    timestamp: float

    fairness_report: Optional[Any] = None
    sr117_result: Optional[Any] = None
    ecoa_result: Optional[Any] = None
    regression_result: Optional[Any] = None

    blocking_findings: List[BlockingFinding] = field(default_factory=list)
    warning_findings: List[BlockingFinding] = field(default_factory=list)

    summary: Dict[str, Any] = field(default_factory=dict)
    remediation_plan: List[str] = field(default_factory=list)

    attestation_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "deployment_approved": self.deployment_approved,
            "gate_status": self.gate_status.value,
            "model_name": self.model_name,
            "model_version": self.model_version,
            "model_hash": self.model_hash,
            "timestamp": self.timestamp,
            "blocking_findings": [
                {
                    "category": f.category,
                    "description": f.description,
                    "regulation": f.regulation_citation,
                    "remediation": f.remediation,
                    "severity": f.severity,
                }
                for f in self.blocking_findings
            ],
            "warning_findings": [
                {
                    "category": f.category,
                    "description": f.description,
                    "regulation": f.regulation_citation,
                    "remediation": f.remediation,
                    "severity": f.severity,
                }
                for f in self.warning_findings
            ],
            "summary": self.summary,
            "remediation_plan": self.remediation_plan,
            "attestation_id": self.attestation_id,
        }

    def to_json(self, indent: int = 2) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict(), indent=indent, default=str)


class DeploymentGate:
    """
    Production deployment gate with hard technical validation.

    Prevents non-compliant models from reaching production by running
    comprehensive fairness, compliance, and regression checks at deployment
    time.

    This is the automated enforcement mechanism that turns compliance from
    a manual checklist into a hard technical constraint.

    Integration points:
    - CI/CD: Called from GitHub Actions / Jenkins / CircleCI
    - AWS: Invoked via Lambda + API Gateway
    - Manual: CLI tool for local validation before push
    """

    def __init__(
        self,
        storage: Optional[StorageBackend] = None,
        strict_mode: bool = True,
        four_fifths_threshold: float = 0.80,
        max_auc_loss: float = 0.02,
    ):
        """
        Initialize deployment gate.

        Args:
            storage: Backend storage for persisting gate results (S3, PostgreSQL, etc.)
            strict_mode: If True, any CRITICAL finding blocks deployment.
                         If False, only fairness violations block deployment.
            four_fifths_threshold: Disparate impact threshold (default 0.80 = 80%).
            max_auc_loss: Maximum acceptable AUC loss in LDA search (default 2%).
        """
        self.storage = storage
        self.strict_mode = strict_mode
        self.four_fifths_threshold = four_fifths_threshold
        self.max_auc_loss = max_auc_loss

    def validate_deployment(
        self,
        model,
        model_name: str,
        X_train: pd.DataFrame,
        y_train: np.ndarray,
        X_test: pd.DataFrame,
        y_test: np.ndarray,
        protected_data: pd.DataFrame,
        protected_columns: List[str],
        model_factory: Optional[Callable] = None,
        model_version: str = "",
        previous_version: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        dag: Optional[ComputationDAG] = None,
    ) -> DeploymentGateResult:
        """
        Validate a model for production deployment.

        Runs:
        1. FairLens analysis (disparate impact, proxy detection, LDA search, adverse action)
        2. SR 11-7 compliance checks
        3. ECOA compliance checks
        4. Fairness regression testing (if previous_version provided)

        Returns a DeploymentGateResult with:
        - deployment_approved: bool (True = safe to deploy, False = BLOCKED)
        - blocking_findings: Critical issues that must be fixed
        - warning_findings: Non-blocking issues to address
        - remediation_plan: Ordered list of steps to achieve compliance

        Args:
            model: Trained model to validate
            model_name: Model identifier (e.g., "credit_scoring_v2.1.0")
            X_train: Training features
            y_train: Training labels
            X_test: Test features
            y_test: Test labels
            protected_data: Protected attribute data for test set
            protected_columns: Names of protected attributes
            model_factory: Callable that returns a fresh model instance (for LDA search)
            model_version: Semantic version string (e.g., "2.1.0")
            previous_version: Previous model version for regression testing
            metadata: Additional metadata for SR 11-7 / ECOA checks
            dag: Optional HYDRA-32 computation DAG for ECOA checks

        Returns:
            DeploymentGateResult with approval decision and findings
        """
        start_time = time.time()
        metadata = metadata or {}

        from ..fairness.model_adapter import adapt_model
        adapted = adapt_model(model)
        model_hash = adapted.model_hash()

        if not model_version:
            model_version = hashlib.sha256(model_hash.encode()).hexdigest()[:8]

        logger.info(
            "DeploymentGate: validating %s v%s (hash=%s)",
            model_name, model_version, model_hash[:8],
        )

        config = FairLensConfig(
            protected_columns=protected_columns,
            proxy_correlation_threshold=0.50,
            four_fifths_threshold=self.four_fifths_threshold,
            max_auc_loss=self.max_auc_loss,
            run_lda_search=True,
            run_adverse_action=True,
        )

        engine = FairLensEngine(config=config)
        fairness_report = engine.analyze(
            model=model,
            X_train=X_train,
            y_train=y_train,
            X_test=X_test,
            y_test=y_test,
            protected_data=protected_data,
            model_name=model_name,
            model_factory=model_factory,
            model_version=model_version,
        )

        blocking_findings: List[BlockingFinding] = []
        warning_findings: List[BlockingFinding] = []

        for finding in fairness_report.findings:
            if finding.severity == Severity.CRITICAL:
                blocking_findings.append(BlockingFinding(
                    category=finding.category,
                    description=finding.description,
                    regulation_citation=finding.regulation,
                    remediation=self._generate_remediation(finding),
                    severity="CRITICAL",
                ))
            elif finding.severity == Severity.WARNING:
                warning_findings.append(BlockingFinding(
                    category=finding.category,
                    description=finding.description,
                    regulation_citation=finding.regulation,
                    remediation=self._generate_remediation(finding),
                    severity="WARNING",
                ))

        metadata_enriched = {
            **metadata,
            "model_version": model_version,
            "model_hash": model_hash,
            "disparate_impact_analysis": {
                di.protected_attribute: di.worst_ratio
                for di in fairness_report.disparate_impact_results
                if di.has_disparate_impact
            },
            "intersectional_impact_analysis": [
                ir.to_dict() for ir in fairness_report.intersectional_results
                if ir.has_disparate_impact
            ],
            "explanation_method": fairness_report.summary.get("explanation_method", ""),
            "explanation_confidence": fairness_report.summary.get("explanation_confidence", 0.0),
        }

        sr117_engine = SR117Engine()
        sr117_result = None
        if dag or metadata:
            sr117_result = sr117_engine.check(dag or ComputationDAG(root_id=0, nodes={}, edges=[]), metadata_enriched)
            for sr_finding in sr117_result.findings:
                if sr_finding.severity == Severity.CRITICAL and self.strict_mode:
                    blocking_findings.append(BlockingFinding(
                        category=getattr(sr_finding, "category", None) or "sr117",
                        description=sr_finding.description,
                        regulation_citation=sr_finding.regulation_citation or "SR 11-7",
                        remediation=sr_finding.remediation or "Address SR 11-7 compliance gap",
                        severity="CRITICAL",
                    ))
                elif sr_finding.severity == Severity.WARNING:
                    warning_findings.append(BlockingFinding(
                        category=getattr(sr_finding, "category", None) or "sr117",
                        description=sr_finding.description,
                        regulation_citation=sr_finding.regulation_citation or "SR 11-7",
                        remediation=sr_finding.remediation or "Address SR 11-7 compliance gap",
                        severity="WARNING",
                    ))

        ecoa_engine = ECOAEngine()
        ecoa_result = None
        if dag or metadata:
            ecoa_result = ecoa_engine.check(dag or ComputationDAG(root_id=0, nodes={}, edges=[]), metadata_enriched)
            for ecoa_finding in ecoa_result.findings:
                if ecoa_finding.severity == Severity.CRITICAL and self.strict_mode:
                    blocking_findings.append(BlockingFinding(
                        category=getattr(ecoa_finding, "category", None) or "ecoa",
                        description=ecoa_finding.description,
                        regulation_citation=ecoa_finding.regulation_citation or "ECOA / Reg B",
                        remediation=ecoa_finding.remediation or "Address ECOA compliance gap",
                        severity="CRITICAL",
                    ))
                elif ecoa_finding.severity == Severity.WARNING:
                    warning_findings.append(BlockingFinding(
                        category=getattr(ecoa_finding, "category", None) or "ecoa",
                        description=ecoa_finding.description,
                        regulation_citation=ecoa_finding.regulation_citation or "ECOA / Reg B",
                        remediation=ecoa_finding.remediation or "Address ECOA compliance gap",
                        severity="WARNING",
                    ))

        regression_result = None
        if previous_version and self.storage:
            from .regression import FairnessRegressionTester
            tester = FairnessRegressionTester(storage=self.storage)
            try:
                regression_result = tester.compare_versions(
                    current_report=fairness_report,
                    current_version=model_version,
                    previous_version=previous_version,
                )

                if regression_result.has_fairness_degradation:
                    for degradation in regression_result.degradations:
                        blocking_findings.append(BlockingFinding(
                            category="fairness_regression",
                            description=degradation,
                            regulation_citation="SR 11-7 § 4.2 (Ongoing Monitoring)",
                            remediation="Investigate and fix fairness regression before deployment",
                            severity="CRITICAL",
                        ))
            except Exception as exc:
                logger.warning("Fairness regression testing failed: %s", exc)

        deployment_approved = len(blocking_findings) == 0
        gate_status = (
            GateStatus.APPROVED if deployment_approved
            else GateStatus.BLOCKED
        )

        remediation_plan = self._build_remediation_plan(blocking_findings)

        summary = {
            "total_findings": len(blocking_findings) + len(warning_findings),
            "blocking_findings": len(blocking_findings),
            "warning_findings": len(warning_findings),
            "fairness_critical": fairness_report.summary.get("critical", 0),
            "fairness_warnings": fairness_report.summary.get("warnings", 0),
            "disparate_impact_detected": fairness_report.summary.get("disparate_impact_detected", False),
            "proxy_features_detected": fairness_report.summary.get("proxy_features_detected", 0),
            "lda_passing_found": fairness_report.summary.get("lda_passing_found", 0),
            "model_hash": model_hash,
            "model_version": model_version,
            "validation_time_seconds": time.time() - start_time,
        }

        result = DeploymentGateResult(
            deployment_approved=deployment_approved,
            gate_status=gate_status,
            model_name=model_name,
            model_version=model_version,
            model_hash=model_hash,
            timestamp=time.time(),
            fairness_report=fairness_report,
            sr117_result=sr117_result,
            ecoa_result=ecoa_result,
            regression_result=regression_result,
            blocking_findings=blocking_findings,
            warning_findings=warning_findings,
            summary=summary,
            remediation_plan=remediation_plan,
        )

        if self.storage and deployment_approved:
            attestation_id = self._store_attestation(result)
            result.attestation_id = attestation_id

        if deployment_approved:
            logger.info("DeploymentGate: APPROVED %s v%s", model_name, model_version)
        else:
            logger.warning(
                "DeploymentGate: BLOCKED %s v%s - %d blocking findings",
                model_name, model_version, len(blocking_findings),
            )

        return result

    def _generate_remediation(self, finding) -> str:
        """Generate actionable remediation for a finding."""
        if finding.category == "disparate_impact":
            return (
                "Remove proxy features and test Less Discriminatory Alternative. "
                "Use FairLens LDA search to identify feature removals that pass "
                "the four-fifths test with minimal accuracy loss."
            )
        elif finding.category == "proxy_discrimination":
            return (
                "Remove the identified proxy feature from the model. If the feature "
                "is business-critical, test a Less Discriminatory Alternative or "
                "add compensating controls with documented justification."
            )
        elif finding.category == "adverse_action":
            return (
                "Implement per-applicant adverse action reason codes using SHAP "
                "or model-specific feature importances. Map to FFIEC reason codes."
            )
        elif finding.category == "intersectional_disparate_impact":
            return (
                "Investigate compound discrimination across protected attribute "
                "combinations. Test LDA with intersectional groups as targets."
            )
        else:
            return "Address compliance gap before deployment."

    def _build_remediation_plan(self, findings: List[BlockingFinding]) -> List[str]:
        """Build ordered remediation plan from findings."""
        if not findings:
            return []

        plan = [
            "## Remediation Plan for Deployment Gate Failure",
            "",
            "Complete the following steps in order to achieve compliance:",
            "",
        ]

        for i, finding in enumerate(findings, 1):
            plan.append(f"{i}. **{finding.category}** ({finding.regulation_citation})")
            plan.append(f"   - Issue: {finding.description}")
            plan.append(f"   - Action: {finding.remediation}")
            plan.append("")

        plan.append("After addressing all findings, re-run the deployment gate.")

        return plan

    def _store_attestation(self, result: DeploymentGateResult) -> str:
        """
        Store a compliance attestation for an approved deployment.

        This creates an immutable audit trail proving that the model
        passed all deployment gate checks at a specific point in time.
        Bank examiners can verify that deployed models have attestations.

        Returns attestation_id (SHA-256 of the gate result).
        """
        attestation_data = {
            "model_name": result.model_name,
            "model_version": result.model_version,
            "model_hash": result.model_hash,
            "timestamp": result.timestamp,
            "gate_status": result.gate_status.value,
            "summary": result.summary,
        }

        attestation_json = json.dumps(attestation_data, sort_keys=True)
        attestation_id = hashlib.sha256(attestation_json.encode()).hexdigest()

        logger.info(
            "Stored deployment attestation: %s for %s v%s",
            attestation_id[:8], result.model_name, result.model_version,
        )

        return attestation_id
