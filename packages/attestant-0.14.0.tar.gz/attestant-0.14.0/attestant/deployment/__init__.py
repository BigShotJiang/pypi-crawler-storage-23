"""
Attestant Deployment Gate: Production-ready Stage 5 capabilities.

Automated deployment validation that blocks non-compliant models from production.

Key components:
- DeploymentGate: Hard technical gate with fairness/compliance checks
- FairnessRegressionTester: Version-to-version fairness comparison
- Lambda Handler: AWS Lambda + API Gateway deployment

Usage:
    from attestant.deployment import DeploymentGate

    gate = DeploymentGate(storage=s3_storage)
    result = gate.validate_deployment(
        model=model,
        model_name="credit_scoring_v2",
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        protected_data=protected_df,
        protected_columns=["race", "sex", "age"],
    )

    if result.deployment_approved:
        deploy_to_production(model)
    else:
        print(result.blocking_findings)
"""

from .gate import DeploymentGate, DeploymentGateResult, GateStatus, BlockingFinding
from .regression import FairnessRegressionTester, FairnessRegressionResult, FairnessMetricChange

__all__ = [
    "DeploymentGate",
    "DeploymentGateResult",
    "GateStatus",
    "BlockingFinding",
    "FairnessRegressionTester",
    "FairnessRegressionResult",
    "FairnessMetricChange",
]
