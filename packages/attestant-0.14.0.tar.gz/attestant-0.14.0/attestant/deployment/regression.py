"""
Fairness Regression Testing: Detects fairness degradation across model versions.

Banks need to ensure that model updates don't make bias worse. This module
compares fairness metrics between the current model and the previous version,
flagging any degradation that would make the new model less fair.

Critical for SR 11-7 § 4.2 (Ongoing Monitoring) and CFPB expectations that
model retraining doesn't introduce new disparate impact.

Usage:
    from attestant.deployment.regression import FairnessRegressionTester

    tester = FairnessRegressionTester(storage=s3_storage)
    result = tester.compare_versions(
        current_report=fairness_report_v2,
        current_version="2.1.0",
        previous_version="2.0.0",
    )

    if result.has_fairness_degradation:
        print(result.degradations)
        # Block deployment
    else:
        print(result.improvements)
        # Allow deployment

The tester checks:
1. Disparate impact ratio changes (e.g., 0.82 → 0.76 is degradation)
2. New proxy features detected
3. Adverse action explanation quality
4. Intersectional disparate impact emergence
"""

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..persistence.storage import StorageBackend
from ..fairness.engine import FairLensReport

logger = logging.getLogger(__name__)


@dataclass
class FairnessMetricChange:
    """A change in a fairness metric between versions."""
    metric_name: str
    previous_value: float
    current_value: float
    change: float
    change_pct: float
    is_degradation: bool
    is_improvement: bool
    protected_attribute: Optional[str] = None


@dataclass
class FairnessRegressionResult:
    """Result of fairness regression testing."""
    current_version: str
    previous_version: str
    has_fairness_degradation: bool

    metric_changes: List[FairnessMetricChange] = field(default_factory=list)
    degradations: List[str] = field(default_factory=list)
    improvements: List[str] = field(default_factory=list)
    new_proxy_features: List[str] = field(default_factory=list)

    summary: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "current_version": self.current_version,
            "previous_version": self.previous_version,
            "has_fairness_degradation": self.has_fairness_degradation,
            "metric_changes": [
                {
                    "metric": m.metric_name,
                    "previous": m.previous_value,
                    "current": m.current_value,
                    "change": m.change,
                    "change_pct": m.change_pct,
                    "is_degradation": m.is_degradation,
                    "protected_attribute": m.protected_attribute,
                }
                for m in self.metric_changes
            ],
            "degradations": self.degradations,
            "improvements": self.improvements,
            "new_proxy_features": self.new_proxy_features,
            "summary": self.summary,
        }


class FairnessRegressionTester:
    """
    Tests for fairness degradation across model versions.

    Compares fairness metrics between current and previous model versions
    to ensure that model updates don't introduce or worsen bias.

    Degradation triggers (any of these blocks deployment):
    1. Disparate impact ratio drops by >2 percentage points
    2. New CRITICAL proxy features detected
    3. Intersectional disparate impact emerges where it didn't exist
    4. Adverse action explanation quality drops significantly
    """

    DEGRADATION_THRESHOLD = 0.02

    def __init__(self, storage: Optional[StorageBackend] = None):
        """
        Initialize regression tester.

        Args:
            storage: Backend storage for retrieving previous versions
        """
        self.storage = storage

    def compare_versions(
        self,
        current_report: FairLensReport,
        current_version: str,
        previous_version: str,
        previous_report: Optional[FairLensReport] = None,
    ) -> FairnessRegressionResult:
        """
        Compare fairness metrics between current and previous versions.

        Args:
            current_report: FairLens report for current version
            current_version: Version string for current model
            previous_version: Version string for previous model
            previous_report: Optional previous FairLens report (fetched from
                            storage if not provided)

        Returns:
            FairnessRegressionResult with degradation analysis
        """
        if previous_report is None and self.storage is None:
            raise ValueError(
                "Either previous_report or storage must be provided"
            )

        if previous_report is None:
            logger.info(
                "Fetching previous fairness report for %s from storage",
                previous_version,
            )
            previous_report = self._fetch_previous_report(previous_version)
            if previous_report is None:
                logger.warning(
                    "No previous report found for %s - skipping regression test",
                    previous_version,
                )
                return FairnessRegressionResult(
                    current_version=current_version,
                    previous_version=previous_version,
                    has_fairness_degradation=False,
                    summary={"skipped": "No previous report found"},
                )

        metric_changes: List[FairnessMetricChange] = []
        degradations: List[str] = []
        improvements: List[str] = []

        # Compare disparate impact ratios
        for curr_di in current_report.disparate_impact_results:
            prev_di = self._find_matching_di(
                curr_di.protected_attribute,
                previous_report.disparate_impact_results,
            )
            if prev_di is None:
                continue

            change = curr_di.worst_ratio - prev_di.worst_ratio
            change_pct = (change / prev_di.worst_ratio * 100) if prev_di.worst_ratio > 0 else 0

            is_degradation = change < -self.DEGRADATION_THRESHOLD
            is_improvement = change > self.DEGRADATION_THRESHOLD

            metric_changes.append(FairnessMetricChange(
                metric_name="disparate_impact_ratio",
                previous_value=prev_di.worst_ratio,
                current_value=curr_di.worst_ratio,
                change=change,
                change_pct=change_pct,
                is_degradation=is_degradation,
                is_improvement=is_improvement,
                protected_attribute=curr_di.protected_attribute,
            ))

            if is_degradation:
                degradations.append(
                    f"Disparate impact ratio for {curr_di.protected_attribute} "
                    f"degraded from {prev_di.worst_ratio:.2f} to {curr_di.worst_ratio:.2f} "
                    f"({change:.2f} change, {change_pct:.1f}%)"
                )
            elif is_improvement:
                improvements.append(
                    f"Disparate impact ratio for {curr_di.protected_attribute} "
                    f"improved from {prev_di.worst_ratio:.2f} to {curr_di.worst_ratio:.2f} "
                    f"({change:.2f} change, {change_pct:.1f}%)"
                )

        # Check for new critical proxy features
        prev_proxy_features = {
            p.feature_name
            for p in previous_report.proxy_results
            if p.is_high_risk
        }
        curr_proxy_features = {
            p.feature_name
            for p in current_report.proxy_results
            if p.is_high_risk
        }
        new_proxy_features = list(curr_proxy_features - prev_proxy_features)

        if new_proxy_features:
            degradations.append(
                f"New CRITICAL proxy features detected: {', '.join(new_proxy_features)}"
            )

        # Check for intersectional disparate impact emergence
        prev_had_intersectional = any(
            ir.has_disparate_impact
            for ir in previous_report.intersectional_results
        )
        curr_has_intersectional = any(
            ir.has_disparate_impact
            for ir in current_report.intersectional_results
        )

        if curr_has_intersectional and not prev_had_intersectional:
            degradations.append(
                "New intersectional disparate impact detected that wasn't "
                "present in previous version"
            )

        # Check explanation quality
        prev_confidence = previous_report.summary.get("explanation_confidence", 0.0)
        curr_confidence = current_report.summary.get("explanation_confidence", 0.0)
        confidence_change = curr_confidence - prev_confidence

        if confidence_change < -0.10:
            degradations.append(
                f"Explanation fidelity degraded from {prev_confidence:.1%} "
                f"to {curr_confidence:.1%} (drop of {-confidence_change:.1%})"
            )

        has_degradation = len(degradations) > 0

        summary = {
            "disparate_impact_changes": len([
                m for m in metric_changes
                if m.metric_name == "disparate_impact_ratio"
            ]),
            "degradations_found": len(degradations),
            "improvements_found": len(improvements),
            "new_proxy_features": len(new_proxy_features),
            "overall_fairness_trend": (
                "degraded" if has_degradation
                else "improved" if len(improvements) > 0
                else "stable"
            ),
        }

        return FairnessRegressionResult(
            current_version=current_version,
            previous_version=previous_version,
            has_fairness_degradation=has_degradation,
            metric_changes=metric_changes,
            degradations=degradations,
            improvements=improvements,
            new_proxy_features=new_proxy_features,
            summary=summary,
        )

    @staticmethod
    def _find_matching_di(protected_attr: str, di_results: List) -> Optional[Any]:
        """Find disparate impact result for a specific protected attribute."""
        for di in di_results:
            if di.protected_attribute == protected_attr:
                return di
        return None

    def _fetch_previous_report(self, version: str) -> Optional[FairLensReport]:
        """Fetch previous fairness report from storage.

        This is a placeholder - actual implementation would query the storage
        backend for the specific version's FairLens report.
        """
        logger.warning(
            "Storage-based report fetching not yet implemented. "
            "Pass previous_report directly to compare_versions()."
        )
        return None
