"""
Base Compliance Engine for Attestant Provenance DAGs.

Provides abstract base classes and result types for regulation-specific
compliance checks against computation DAGs produced by the Attestant system.

Each compliance engine inspects a ComputationDAG (and optional metadata)
and returns structured findings with regulatory citations and remediation
recommendations.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Set

from ..utilities.hydra32_dag import ComputationDAG


ENGINE_VERSION = "1.0.0"


# ---------------------------------------------------------------------------
# Check definition (Compliance Sandbox catalog entry)
# ---------------------------------------------------------------------------

@dataclass
class CheckDefinition:
    """A single compliance check entry in the unified catalog.

    Attributes:
        id: Dotted identifier, e.g. ``"ecoa.protected_attributes"``.
        name: Short human-readable title for the UI.
        description: Longer explanation of what the check verifies.
        regulation: Machine key for the regulation (``"ecoa"``, ``"sr117"``,
            ``"eu_ai_act"``).
        regulation_label: Display name for the regulation (e.g. ``"ECOA / Reg B"``).
        default_action: What happens when the check triggers: ``"block"``,
            ``"warn"``, or ``"ignore"``.
        default_enabled: Whether the check is on by default.
        scope: ``"model"`` for checks evaluating model predictions/outputs,
            ``"governance"`` for checks about org-level processes/documentation.
        regulation_citation: Specific regulation section reference
            (e.g. ``"ECOA § 202.4 / Reg B"``, ``"SR 11-7 §IV"``).
    """
    id: str
    name: str
    description: str
    regulation: str
    regulation_label: str
    default_action: str
    default_enabled: bool
    scope: str = "model"
    regulation_citation: str = ""


# ---------------------------------------------------------------------------
# Severity levels
# ---------------------------------------------------------------------------

class Severity(Enum):
    """Severity of a compliance finding."""
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"


# ---------------------------------------------------------------------------
# Finding
# ---------------------------------------------------------------------------

@dataclass
class ComplianceFinding:
    """A single finding produced by a compliance check.

    Attributes:
        severity: How severe the issue is (INFO / WARNING / CRITICAL).
        description: Human-readable explanation of the finding.
        regulation_citation: Specific regulation reference (e.g. "Article 12(1)").
        affected_nodes: List of DAG node IDs implicated in the finding.
        remediation: Recommended corrective action.
        check_id: Dot-namespaced check ID (e.g. "ecoa.protected_attributes").
    """
    severity: Severity
    description: str
    regulation_citation: str
    affected_nodes: List[int] = field(default_factory=list)
    remediation: str = ""
    check_id: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "check_id": self.check_id,
            "severity": self.severity.value,
            "description": self.description,
            "regulation_citation": self.regulation_citation,
            "affected_nodes": self.affected_nodes,
            "remediation": self.remediation,
        }


@dataclass
class CheckRunResult:
    """Result of running a single named compliance check.

    Attributes:
        check_id: Dot-namespaced check ID (e.g. "ecoa.protected_attributes").
        status: "pass" | "warning" | "critical" | "na" | "error"
        findings: Individual findings produced by this check.
        na_reason: Populated when status == "na" to explain why the check was skipped.
    """
    check_id: str
    status: str
    findings: List[ComplianceFinding] = field(default_factory=list)
    na_reason: str = ""


# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------

@dataclass
class ComplianceResult:
    """Aggregate result of running a single compliance engine.

    Attributes:
        passed: Whether the DAG passed all checks for this regulation.
        regulation_name: Short canonical name (e.g. "EU AI Act", "ECOA / Reg B").
        findings: Individual findings (may be empty if fully compliant).
        citations: All regulation citations referenced by the engine.
        remediation_recommendations: Top-level remediation suggestions.
        timestamp: When the check was executed (UTC).
        metadata: Arbitrary extra data produced by the engine.
    """
    passed: bool
    regulation_name: str
    findings: List[ComplianceFinding] = field(default_factory=list)
    citations: List[str] = field(default_factory=list)
    remediation_recommendations: List[str] = field(default_factory=list)
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.CRITICAL)

    @property
    def warning_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.WARNING)

    @property
    def info_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.INFO)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "regulation": self.regulation_name,
            "regulation_name": self.regulation_name,
            "findings": [f.to_dict() for f in self.findings],
            "citations": self.citations,
            "remediation_recommendations": self.remediation_recommendations,
            "timestamp": self.timestamp.isoformat(),
            "engine_version": ENGINE_VERSION,
            "metadata": self.metadata,
            "summary": {
                "critical": self.critical_count,
                "warning": self.warning_count,
                "info": self.info_count,
                "total": len(self.findings),
            },
        }


# ---------------------------------------------------------------------------
# Base engine
# ---------------------------------------------------------------------------

class BaseComplianceEngine(ABC):
    """Abstract base class for regulation-specific compliance engines.

    Subclasses must implement ``check`` which inspects a ``ComputationDAG``
    (and optional metadata dictionary) and returns a ``ComplianceResult``.
    """

    @property
    @abstractmethod
    def regulation_name(self) -> str:
        """Short canonical name for the regulation this engine covers."""
        ...

    @abstractmethod
    def check(
        self,
        dag: ComputationDAG,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ComplianceResult:
        """Run all compliance checks against *dag*.

        Args:
            dag: The computation DAG to audit.
            metadata: Optional context such as model type, deployment info,
                      organizational policies, etc.

        Returns:
            A ``ComplianceResult`` with pass/fail, findings, and citations.
        """
        ...

    # Class-level check map to be overridden by subclasses.
    # Maps check IDs (e.g. "ecoa.protected_attributes") to method names.
    _CHECK_MAP: Dict[str, str] = {}

    def run_checks(
        self,
        dag: ComputationDAG,
        metadata: Dict[str, Any],
        enabled_checks: Set[str],
    ) -> Dict[str, "CheckRunResult"]:
        """Run only the checks whose IDs are in *enabled_checks*.

        Each entry in ``_CHECK_MAP`` maps a check ID to the name of a method
        on the subclass.  The method is called with ``(dag, metadata)`` and
        must return one of:
          - ``None`` → check is N/A (not applicable for this model)
          - A ``ComplianceFinding`` or list thereof → check produced findings

        Status is derived from the maximum severity of all findings:
          - No findings (empty list) → "pass"
          - Highest severity is INFO → "pass"
          - Highest severity is WARNING → "warning"
          - Highest severity is CRITICAL → "critical"
          - Method raised an exception → "error"

        Args:
            dag: The computation DAG to audit.
            metadata: Context dictionary (model info, governance data, etc.).
            enabled_checks: Set of check IDs to run.  IDs not present in
                ``_CHECK_MAP`` are silently ignored.

        Returns:
            A dict keyed by check_id, each value a ``CheckRunResult``.
        """
        per_check: Dict[str, CheckRunResult] = {}
        for check_id, method_name in self._CHECK_MAP.items():
            if check_id not in enabled_checks:
                continue
            method = getattr(self, method_name, None)
            if method is None:
                continue
            try:
                result = method(dag, metadata)
                if result is None:
                    per_check[check_id] = CheckRunResult(
                        check_id=check_id,
                        status="na",
                    )
                else:
                    if isinstance(result, ComplianceFinding):
                        result_list = [result]
                    else:
                        result_list = [r for r in result if r is not None]
                    for f in result_list:
                        f.check_id = check_id
                    if any(f.severity == Severity.CRITICAL for f in result_list):
                        status = "critical"
                    elif any(f.severity == Severity.WARNING for f in result_list):
                        status = "warning"
                    else:
                        status = "pass"
                    per_check[check_id] = CheckRunResult(
                        check_id=check_id,
                        status=status,
                        findings=result_list,
                    )
            except Exception as exc:
                per_check[check_id] = CheckRunResult(
                    check_id=check_id,
                    status="error",
                    findings=[ComplianceFinding(
                        severity=Severity.WARNING,
                        description=f"Check {check_id} failed: {str(exc)}",
                        regulation_citation="",
                        check_id=check_id,
                    )],
                )
        return per_check

    def run_all_checks(
        self,
        dag: ComputationDAG,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ComplianceResult:
        """Alias for ``check`` -- runs all compliance checks against *dag*.

        Provided for consistency across engines.  Delegates to ``check``.
        """
        return self.check(dag, metadata)


# ---------------------------------------------------------------------------
# Report (aggregates multiple engines)
# ---------------------------------------------------------------------------

class ComplianceReport:
    """Aggregates results from multiple compliance engines into one report.

    Usage::

        report = ComplianceReport()
        report.add(eu_engine.check(dag, meta))
        report.add(ecoa_engine.check(dag, meta))
        print(report.summary())
    """

    def __init__(self) -> None:
        self.results: List[ComplianceResult] = []
        self.generated_at: datetime = datetime.now(timezone.utc)

    # -- mutators -----------------------------------------------------------

    def add(self, result: ComplianceResult) -> None:
        """Append a ``ComplianceResult`` to the report."""
        self.results.append(result)

    def run_engines(
        self,
        engines: List[BaseComplianceEngine],
        dag: ComputationDAG,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> "ComplianceReport":
        """Convenience: run every engine against *dag* and collect results.

        Returns *self* for chaining.
        """
        for engine in engines:
            self.add(engine.check(dag, metadata))
        return self

    # -- queries ------------------------------------------------------------

    @property
    def overall_passed(self) -> bool:
        """True only if every engine's result passed."""
        if not self.results:
            return True
        return all(r.passed for r in self.results)

    @property
    def total_findings(self) -> int:
        return sum(len(r.findings) for r in self.results)

    @property
    def total_critical(self) -> int:
        return sum(r.critical_count for r in self.results)

    @property
    def total_warnings(self) -> int:
        return sum(r.warning_count for r in self.results)

    @staticmethod
    def _dedup_flat(nested: List[List[str]]) -> List[str]:
        """Order-preserving deduplication of items across nested lists."""
        seen: Set[str] = set()
        out: List[str] = []
        for sublist in nested:
            for item in sublist:
                if item not in seen:
                    seen.add(item)
                    out.append(item)
        return out

    @property
    def all_citations(self) -> List[str]:
        """De-duplicated list of all citations across engines."""
        return self._dedup_flat([r.citations for r in self.results])

    @property
    def all_remediation_recommendations(self) -> List[str]:
        return self._dedup_flat([r.remediation_recommendations for r in self.results])

    # -- serialization ------------------------------------------------------

    def summary(self) -> Dict[str, Any]:
        """Produce a human-readable summary dictionary."""
        return {
            "overall_passed": self.overall_passed,
            "generated_at": self.generated_at.isoformat(),
            "engines_run": len(self.results),
            "total_findings": self.total_findings,
            "total_critical": self.total_critical,
            "total_warnings": self.total_warnings,
            "per_regulation": {
                r.regulation_name: {
                    "passed": r.passed,
                    "critical": r.critical_count,
                    "warning": r.warning_count,
                    "info": r.info_count,
                }
                for r in self.results
            },
            "all_citations": self.all_citations,
            "all_remediation_recommendations": self.all_remediation_recommendations,
        }

    def examiner_summary(self) -> Dict[str, Any]:
        """Produce a structured summary formatted for regulatory examiners.

        Returns a dictionary organized by the categories OCC / Fed
        examiners review during fair lending and model risk examinations:

        1. **model_risk** -- SR 11-7 compliance indicators
        2. **fair_lending** -- ECOA / Reg B compliance status
        3. **data_governance** -- data lineage and provenance findings
        4. **action_items** -- prioritised list of remediation steps

        This format maps directly to the OCC's Model Risk Management
        Handbook and the Fed's Consumer Compliance Examination Manual.
        """
        model_risk: List[Dict[str, Any]] = []
        fair_lending: List[Dict[str, Any]] = []
        data_governance: List[Dict[str, Any]] = []

        for r in self.results:
            for f in r.findings:
                entry = {
                    "severity": f.severity.value,
                    "regulation": r.regulation_name,
                    "citation": f.regulation_citation,
                    "description": f.description,
                    "remediation": f.remediation,
                }
                cit = f.regulation_citation.lower()
                reg = r.regulation_name.lower()
                if "sr 11-7" in cit or "occ 2011" in cit or "sr 11-7" in reg:
                    model_risk.append(entry)
                elif "1002" in cit or "1691" in cit or "ecoa" in cit:
                    fair_lending.append(entry)
                else:
                    data_governance.append(entry)

        # Build prioritised action items (CRITICAL first, then WARNING)
        action_items: List[Dict[str, str]] = []
        for r in self.results:
            for f in r.findings:
                if f.severity == Severity.CRITICAL and f.remediation:
                    action_items.append({
                        "priority": "immediate",
                        "regulation": f.regulation_citation,
                        "action": f.remediation,
                    })
        for r in self.results:
            for f in r.findings:
                if f.severity == Severity.WARNING and f.remediation:
                    action_items.append({
                        "priority": "scheduled",
                        "regulation": f.regulation_citation,
                        "action": f.remediation,
                    })

        # Build model inventory from engine metadata
        model_inventory: Dict[str, Any] = {}
        for r in self.results:
            if r.metadata:
                for key in ("model_id", "model_version", "model_hash",
                            "has_validation", "has_monitoring"):
                    if key in r.metadata and r.metadata[key]:
                        model_inventory[key] = r.metadata[key]

        return {
            "report_date": self.generated_at.isoformat(),
            "overall_status": "PASS" if self.overall_passed else "FAIL",
            "critical_findings": self.total_critical,
            "warning_findings": self.total_warnings,
            "model_risk": model_risk,
            "fair_lending": fair_lending,
            "data_governance": data_governance,
            "model_inventory": model_inventory,
            "action_items": action_items,
            "regulations_checked": [r.regulation_name for r in self.results],
        }

    def to_dict(self) -> Dict[str, Any]:
        """Full serialization of the report."""
        return {
            "overall_passed": self.overall_passed,
            "generated_at": self.generated_at.isoformat(),
            "results": [r.to_dict() for r in self.results],
            "summary": self.summary(),
        }


# ---------------------------------------------------------------------------
# Unified check catalog (all 41 checks across ECOA, SR 11-7, EU AI Act)
# ---------------------------------------------------------------------------

CHECK_CATALOG: List[CheckDefinition] = [
    # -----------------------------------------------------------------------
    # ECOA / Reg B  (13 checks)
    # -----------------------------------------------------------------------
    CheckDefinition(
        id="ecoa.protected_attributes",
        name="Protected Attribute Detection",
        description="Scans model for protected-class columns (race, sex, age, etc.)",
        regulation="ecoa",
        regulation_label="ECOA / Reg B",
        default_action="block",
        default_enabled=True,
        scope="model",
        regulation_citation="ECOA § 202.4 / Reg B",
    ),
    CheckDefinition(
        id="ecoa.protected_influence",
        name="Protected Attribute Influence",
        description="Measures how much of the DAG is downstream of protected data sources",
        regulation="ecoa",
        regulation_label="ECOA / Reg B",
        default_action="block",
        default_enabled=True,
        scope="model",
        regulation_citation="ECOA § 202.4 / Reg B",
    ),
    CheckDefinition(
        id="ecoa.disparate_impact",
        name="Disparate Impact Analysis",
        description="Checks if selection rates violate the 4/5 rule across protected groups",
        regulation="ecoa",
        regulation_label="ECOA / Reg B",
        default_action="block",
        default_enabled=True,
        scope="model",
        regulation_citation="ECOA § 202.14 / CFPB Circular 2022-03",
    ),
    CheckDefinition(
        id="ecoa.intersectional_impact",
        name="Intersectional Impact Analysis",
        description="Detects compound discrimination across multiple protected categories (2025 CFPB)",
        regulation="ecoa",
        regulation_label="ECOA / Reg B",
        default_action="block",
        default_enabled=True,
        scope="model",
        regulation_citation="ECOA § 202.14 / CFPB Circular 2022-03",
    ),
    CheckDefinition(
        id="ecoa.adverse_action",
        name="Adverse Action Notices",
        description="Validates 30-day notice window, reason completeness, and FFIEC code mapping",
        regulation="ecoa",
        regulation_label="ECOA / Reg B",
        default_action="block",
        default_enabled=True,
        scope="governance",
        regulation_citation="ECOA § 202.9 / Reg B",
    ),
    CheckDefinition(
        id="ecoa.adverse_action_completeness",
        name="Adverse Action Completeness",
        description="Validates all mandatory notice fields per Reg B Appendix C",
        regulation="ecoa",
        regulation_label="ECOA / Reg B",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="ECOA § 202.9 / Reg B",
    ),
    CheckDefinition(
        id="ecoa.model_explainability",
        name="Model Explainability",
        description="CFPB 2023-03: ensures no black-box models are used for credit decisions",
        regulation="ecoa",
        regulation_label="ECOA / Reg B",
        default_action="block",
        default_enabled=True,
        scope="model",
        regulation_citation="CFPB Circular 2023-03",
    ),
    CheckDefinition(
        id="ecoa.record_retention",
        name="Record Retention",
        description="Verifies 25-month minimum retention under 12 CFR 1002.12(a)",
        regulation="ecoa",
        regulation_label="ECOA / Reg B",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="ECOA § 202.12 / Reg B",
    ),
    CheckDefinition(
        id="ecoa.information_requests",
        name="Information Requests",
        description="Validates demographics collection rules vs HMDA requirements",
        regulation="ecoa",
        regulation_label="ECOA / Reg B",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="ECOA § 202.5 / Reg B",
    ),
    CheckDefinition(
        id="ecoa.hmda_monitoring",
        name="HMDA Monitoring",
        description="12 CFR 1002.13: race/ethnicity/sex collection compliance for reportable institutions",
        regulation="ecoa",
        regulation_label="ECOA / Reg B",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="ECOA § 202.13 / Reg B",
    ),
    CheckDefinition(
        id="ecoa.sogi_protection",
        name="SOGI Protection",
        description="Validates sexual orientation/gender identity protections under ECOA",
        regulation="ecoa",
        regulation_label="ECOA / Reg B",
        default_action="warn",
        default_enabled=True,
        scope="model",
        regulation_citation="ECOA § 202.4 / Reg B",
    ),
    CheckDefinition(
        id="ecoa.model_governance",
        name="Model Governance",
        description="Checks SR 11-7 validation date, monitoring plan, and model owner documentation",
        regulation="ecoa",
        regulation_label="ECOA / Reg B",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="SR 11-7 / OCC 2011-12",
    ),
    CheckDefinition(
        id="ecoa.reason_specificity",
        name="Reason Specificity",
        description="CFPB specificity validation for adverse action reason codes",
        regulation="ecoa",
        regulation_label="ECOA / Reg B",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="CFPB Circular 2023-03",
    ),
    # -----------------------------------------------------------------------
    # SR 11-7 / OCC 2011-12  (15 checks)
    # -----------------------------------------------------------------------
    CheckDefinition(
        id="sr117.model_inventory",
        name="Model Inventory",
        description="Validates model ID, version, hash, owner, and purpose documentation",
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="SR 11-7 §IV",
    ),
    CheckDefinition(
        id="sr117.model_tiering",
        name="Model Tiering",
        description="Verifies risk tier classification (critical/high/medium/low)",
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="SR 11-7 §III",
    ),
    CheckDefinition(
        id="sr117.validation",
        name="Model Validation",
        description="Checks validation date, independent validator, and backtesting results",
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="block",
        default_enabled=True,
        scope="model",
        regulation_citation="SR 11-7 §V",
    ),
    CheckDefinition(
        id="sr117.independent_validation",
        name="Independent Validation",
        description="Ensures validator independence, conceptual soundness, and outcomes analysis",
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="block",
        default_enabled=True,
        scope="governance",
        regulation_citation="SR 11-7 §V",
    ),
    CheckDefinition(
        id="sr117.challenger_models",
        name="Challenger Models",
        description="Requires benchmark models for critical/high-tier models",
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="warn",
        default_enabled=True,
        scope="model",
        regulation_citation="SR 11-7 §V",
    ),
    CheckDefinition(
        id="sr117.ongoing_monitoring",
        name="Ongoing Monitoring",
        description="Validates monitoring plan, frequency, and performance thresholds",
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="SR 11-7 §V",
    ),
    CheckDefinition(
        id="sr117.monitoring_frequency_alignment",
        name="Monitoring Frequency Alignment",
        description="Ensures monitoring frequency matches the model's risk tier",
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="SR 11-7 §V",
    ),
    CheckDefinition(
        id="sr117.change_management",
        name="Change Management",
        description="Checks change log and approval chain documentation",
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="SR 11-7 §VIII",
    ),
    CheckDefinition(
        id="sr117.data_governance",
        name="Data Governance",
        description="Validates training data description, hash, and DAG source completeness",
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="warn",
        default_enabled=True,
        scope="model",
        regulation_citation="SR 11-7 §VII",
    ),
    CheckDefinition(
        id="sr117.concentration_risk",
        name="Concentration Risk",
        description="Detects feature/datasource concentration when top 3 features exceed 75%",
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="warn",
        default_enabled=True,
        scope="model",
        regulation_citation="SR 11-7 §VII",
    ),
    CheckDefinition(
        id="sr117.use_limitations",
        name="Use Limitations",
        description="Checks model assumptions, limitations, and compensating controls",
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="SR 11-7 §VI",
    ),
    CheckDefinition(
        id="sr117.vendor_models",
        name="Vendor Models",
        description="Third-party model guidance: vendor identification and validation evidence",
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="block",
        default_enabled=True,
        scope="governance",
        regulation_citation="SR 11-7 §IV",
    ),
    CheckDefinition(
        id="sr117.governance_controls",
        name="Governance Controls",
        description="Validates escalation procedures for performance degradation",
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="SR 11-7 §VIII",
    ),
    CheckDefinition(
        id="sr117.governance_framework",
        name="Governance Framework",
        description="Checks MRM committee, board reporting, policies, and board approval",
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="SR 11-7 §VIII",
    ),
    CheckDefinition(
        id="sr117.model_documentation",
        name="Model Documentation",
        description="Ensures design document, testing results, and training data documentation",
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="SR 11-7 §VI",
    ),
    CheckDefinition(
        id="sr117.data_provenance",
        name="Data Provenance Coverage",
        description=(
            "SR 11-7 § 3.2 / OCC Handbook: verifies all model inputs are traceable "
            "via a HYDRA-32 computation DAG. Penalizes models with missing lineage."
        ),
        regulation="sr117",
        regulation_label="SR 11-7",
        default_action="warn",
        default_enabled=True,
        scope="model",
        regulation_citation="SR 11-7 §VII",
    ),
    # -----------------------------------------------------------------------
    # EU AI Act  (13 checks)
    # -----------------------------------------------------------------------
    CheckDefinition(
        id="eu_ai_act.risk_classification",
        name="Risk Classification",
        description="Identifies prohibited/high/limited/minimal risk per Article 5",
        regulation="eu_ai_act",
        regulation_label="EU AI Act",
        default_action="block",
        default_enabled=True,
        scope="model",
        regulation_citation="EU AI Act Art. 6",
    ),
    CheckDefinition(
        id="eu_ai_act.risk_management",
        name="Risk Management System",
        description="Article 9: validates risk management system requirements",
        regulation="eu_ai_act",
        regulation_label="EU AI Act",
        default_action="block",
        default_enabled=True,
        scope="governance",
        regulation_citation="EU AI Act Art. 9",
    ),
    CheckDefinition(
        id="eu_ai_act.logging",
        name="Automatic Logging",
        description="Article 12: tamper-evident logging, event types, and node provenance",
        regulation="eu_ai_act",
        regulation_label="EU AI Act",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="EU AI Act Art. 12",
    ),
    CheckDefinition(
        id="eu_ai_act.traceability",
        name="Traceability",
        description="Article 12(2): DAG depth, unique provenance, and tamper-evidence",
        regulation="eu_ai_act",
        regulation_label="EU AI Act",
        default_action="warn",
        default_enabled=True,
        scope="model",
        regulation_citation="EU AI Act Art. 12",
    ),
    CheckDefinition(
        id="eu_ai_act.human_oversight",
        name="Human Oversight",
        description="Article 14: human-in-the-loop/on-the-loop/in-command mode requirements",
        regulation="eu_ai_act",
        regulation_label="EU AI Act",
        default_action="block",
        default_enabled=True,
        scope="governance",
        regulation_citation="EU AI Act Art. 14",
    ),
    CheckDefinition(
        id="eu_ai_act.data_governance",
        name="Data Governance",
        description="Article 10: data source documentation and protected data flagging",
        regulation="eu_ai_act",
        regulation_label="EU AI Act",
        default_action="warn",
        default_enabled=True,
        scope="model",
        regulation_citation="EU AI Act Art. 10",
    ),
    CheckDefinition(
        id="eu_ai_act.technical_documentation",
        name="Technical Documentation",
        description="Article 11: risk-appropriate documentation completeness",
        regulation="eu_ai_act",
        regulation_label="EU AI Act",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="EU AI Act Art. 11",
    ),
    CheckDefinition(
        id="eu_ai_act.transparency",
        name="Transparency",
        description="Article 13: model type, purpose, and known limitations disclosure",
        regulation="eu_ai_act",
        regulation_label="EU AI Act",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="EU AI Act Art. 13",
    ),
    CheckDefinition(
        id="eu_ai_act.accuracy_robustness",
        name="Accuracy & Robustness",
        description="Article 15: accuracy targets, robustness testing, and adversarial testing",
        regulation="eu_ai_act",
        regulation_label="EU AI Act",
        default_action="warn",
        default_enabled=True,
        scope="model",
        regulation_citation="EU AI Act Art. 15",
    ),
    CheckDefinition(
        id="eu_ai_act.cybersecurity",
        name="Cybersecurity",
        description="Article 15(4): cybersecurity measures documentation",
        regulation="eu_ai_act",
        regulation_label="EU AI Act",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="EU AI Act Art. 15",
    ),
    CheckDefinition(
        id="eu_ai_act.fundamental_rights_impact",
        name="Fundamental Rights Impact",
        description="Article 27: FRIA (Fundamental Rights Impact Assessment) for high-risk AI",
        regulation="eu_ai_act",
        regulation_label="EU AI Act",
        default_action="block",
        default_enabled=True,
        scope="governance",
        regulation_citation="EU AI Act Art. 27",
    ),
    CheckDefinition(
        id="eu_ai_act.data_bias_representativeness",
        name="Data Bias & Representativeness",
        description="Article 10: training data bias and representativeness analysis",
        regulation="eu_ai_act",
        regulation_label="EU AI Act",
        default_action="warn",
        default_enabled=True,
        scope="model",
        regulation_citation="EU AI Act Art. 10",
    ),
    CheckDefinition(
        id="eu_ai_act.quality_management",
        name="Quality Management",
        description="Article 17: QMS, continuous improvement, and incident reporting",
        regulation="eu_ai_act",
        regulation_label="EU AI Act",
        default_action="warn",
        default_enabled=True,
        scope="governance",
        regulation_citation="EU AI Act Art. 17",
    ),
]
