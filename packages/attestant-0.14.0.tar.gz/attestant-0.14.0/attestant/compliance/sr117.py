"""
SR 11-7 / OCC 2011-12 (Model Risk Management) Compliance Engine.

Implements checks against the Federal Reserve's Supervisory Guidance on
Model Risk Management (SR Letter 11-7, April 2011) and the OCC's
companion Bulletin 2011-12.

Key provisions checked:
    § 3   Development & Implementation
    § 3.2 Data quality and relevance
    § 4   Model Validation
    § 4.1 Model inventory and documentation
    § 4.2 Ongoing monitoring and outcomes analysis
    § 4.3 Change management and governance
    § 5   Governance, Policies, and Controls

The engine inspects a HYDRA-32 ``ComputationDAG`` and optional metadata
to verify that the model governance requirements needed for OCC / Fed
examinations are satisfied.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ..utilities.hydra32_dag import ComputationDAG
from ..utilities.hydra32 import ProvenanceTracker as _PT
from .base import (
    BaseComplianceEngine,
    ComplianceFinding,
    ComplianceResult,
    Severity,
)


class SR117Engine(BaseComplianceEngine):
    """Compliance engine for SR 11-7 / OCC 2011-12 (Model Risk Management).

    Checks:
    1. **Model inventory** -- verifies model_id, version, hash, owner.
    2. **Validation evidence** -- checks for validation date, validator,
       and back-testing metrics.
    3. **Ongoing monitoring** -- verifies monitoring plan, frequency,
       and performance thresholds.
    4. **Change management** -- checks for change log and re-validation
       triggers.
    5. **Data governance** -- verifies training data documentation and
       lineage.
    6. **Governance & controls** -- checks for approval chain and
       escalation procedures.
    """

    _CHECK_MAP = {
        "sr117.model_inventory": "_check_model_inventory",
        "sr117.model_tiering": "_check_model_tiering",
        "sr117.validation": "_check_validation",
        "sr117.independent_validation": "_check_independent_validation",
        "sr117.challenger_models": "_check_challenger_models",
        "sr117.ongoing_monitoring": "_check_ongoing_monitoring",
        "sr117.monitoring_frequency_alignment": "_check_monitoring_frequency_alignment",
        "sr117.change_management": "_check_change_management",
        "sr117.data_governance": "_check_data_governance",
        "sr117.concentration_risk": "_check_concentration_risk",
        "sr117.use_limitations": "_check_use_limitations",
        "sr117.vendor_models": "_check_vendor_models",
        "sr117.governance_controls": "_check_governance_controls",
        "sr117.governance_framework": "_check_governance_framework",
        "sr117.model_documentation": "_check_model_documentation",
        "sr117.data_provenance": "_check_data_provenance",
    }

    @property
    def regulation_name(self) -> str:
        return "SR 11-7 / OCC 2011-12"

    def check(
        self,
        dag: ComputationDAG,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ComplianceResult:
        meta = metadata or {}
        findings: List[ComplianceFinding] = []
        citations: List[str] = []

        for _f in [
            self._check_model_inventory(dag, meta),
            self._check_model_tiering(dag, meta),
            self._check_validation(dag, meta),
            self._check_independent_validation(dag, meta),
            self._check_challenger_models(dag, meta),
            self._check_ongoing_monitoring(dag, meta),
            self._check_monitoring_frequency_alignment(dag, meta),
            self._check_change_management(dag, meta),
            self._check_data_governance(dag, meta),
            self._check_concentration_risk(dag, meta),
            self._check_use_limitations(dag, meta),
            self._check_vendor_models(dag, meta),
            self._check_governance_controls(dag, meta),
            self._check_governance_framework(dag, meta),
            self._check_model_documentation(dag, meta),
            self._check_data_provenance(dag, meta),
        ]:
            if _f is not None:
                findings.extend(_f)

        for f in findings:
            if f.regulation_citation and f.regulation_citation not in citations:
                citations.append(f.regulation_citation)

        passed = all(f.severity != Severity.CRITICAL for f in findings)

        from .base import ComplianceReport
        remediation_recs = ComplianceReport._dedup_flat(
            [[f.remediation] for f in findings if f.remediation]
        )

        return ComplianceResult(
            passed=passed,
            regulation_name=self.regulation_name,
            findings=findings,
            citations=citations,
            remediation_recommendations=remediation_recs,
            metadata={
                "model_id": meta.get("model_id", ""),
                "model_version": meta.get("model_version", ""),
                "model_hash": meta.get("model_hash", ""),
                "model_risk_tier": meta.get("model_risk_tier", ""),
                "has_validation": bool(meta.get("model_validation_date")),
                "has_monitoring": bool(meta.get("monitoring_plan")),
                "has_governance": bool(meta.get("mrm_committee_name")),
                "is_vendor_model": bool(meta.get("is_vendor_model")),
            },
        )

    # -- individual checks ---------------------------------------------------

    def _check_model_inventory(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """SR 11-7 § 4.1: Model inventory and documentation."""
        findings: List[ComplianceFinding] = []

        if not meta.get("model_id"):
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "No model identifier (model_id) recorded. SR 11-7 "
                    "requires a complete model inventory with unique "
                    "identifiers for each model in production."
                ),
                regulation_citation="SR 11-7 § 4.1",
                remediation=(
                    "Assign a stable, unique model_id and include it in "
                    "metadata. Use a format like 'LOAN_SCORING_v2'."
                ),
            ))

        if not meta.get("model_version"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No model version recorded. SR 11-7 requires version "
                    "tracking to distinguish between model iterations and "
                    "support change management."
                ),
                regulation_citation="SR 11-7 § 4.1",
                remediation=(
                    "Record a semantic version (e.g. '2.1.3') under "
                    "'model_version' in metadata."
                ),
            ))

        if not meta.get("model_hash"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No model hash (cryptographic fingerprint) recorded. "
                    "A model hash provides tamper-evident proof that the "
                    "model in production matches the validated model."
                ),
                regulation_citation="SR 11-7 § 4.1",
                remediation=(
                    "Compute a SHA-256 hash of the serialised model and "
                    "record it under 'model_hash' in metadata."
                ),
            ))

        if not meta.get("model_owner"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No model owner designated. SR 11-7 requires clear "
                    "accountability with a named model owner responsible "
                    "for performance and compliance."
                ),
                regulation_citation="SR 11-7 § 5",
                remediation=(
                    "Designate a model owner and record under 'model_owner'."
                ),
            ))

        if not meta.get("model_purpose"):
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    "No stated model purpose. Documenting the intended "
                    "use of the model (e.g. 'consumer credit underwriting') "
                    "is a core inventory requirement."
                ),
                regulation_citation="SR 11-7 § 3",
                remediation=(
                    "Record the model's intended purpose under 'model_purpose'."
                ),
            ))

        return findings

    def _check_validation(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """SR 11-7 § 4: Independent model validation."""
        findings: List[ComplianceFinding] = []

        if not meta.get("model_validation_date"):
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "No model validation date recorded. SR 11-7 requires "
                    "independent validation before a model is used for "
                    "decision-making. OCC examiners will request evidence "
                    "of validation during examinations."
                ),
                regulation_citation="SR 11-7 § 4",
                remediation=(
                    "Conduct independent model validation and record the "
                    "date under 'model_validation_date'."
                ),
            ))

        if not meta.get("model_validator"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No model validator identified. SR 11-7 requires that "
                    "validation be performed by staff independent of model "
                    "development, with appropriate expertise."
                ),
                regulation_citation="SR 11-7 § 4",
                remediation=(
                    "Record the validator's name and organisational unit "
                    "under 'model_validator' to demonstrate independence."
                ),
            ))

        if not meta.get("backtesting_results"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No back-testing results documented. SR 11-7 expects "
                    "outcomes analysis comparing model predictions to "
                    "actual outcomes as a core validation activity."
                ),
                regulation_citation="SR 11-7 § 4",
                remediation=(
                    "Perform back-testing and record results (e.g. AUC, "
                    "KS statistic, Brier score) under 'backtesting_results'."
                ),
            ))

        if not meta.get("stress_testing"):
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    "No stress testing documented. SR 11-7 recommends "
                    "sensitivity analysis and stress testing to understand "
                    "model behaviour under adverse conditions."
                ),
                regulation_citation="SR 11-7 § 4",
                remediation=(
                    "Conduct stress/sensitivity testing and record results."
                ),
            ))

        return findings

    def _check_ongoing_monitoring(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """SR 11-7 § 4.2: Ongoing monitoring."""
        findings: List[ComplianceFinding] = []

        if not meta.get("monitoring_plan"):
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "No ongoing monitoring plan documented. SR 11-7 "
                    "requires continuous monitoring of model performance "
                    "including fairness metrics, stability indicators, "
                    "and outcome tracking for models in production."
                ),
                regulation_citation="SR 11-7 § 4.2",
                remediation=(
                    "Document an ongoing monitoring plan that includes "
                    "performance metrics, fairness thresholds, monitoring "
                    "frequency, and escalation procedures."
                ),
            ))

        if not meta.get("monitoring_frequency"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No monitoring frequency specified. SR 11-7 expects "
                    "regular monitoring with defined intervals appropriate "
                    "to the model's risk tier."
                ),
                regulation_citation="SR 11-7 § 4.2",
                remediation=(
                    "Specify monitoring frequency (e.g. 'monthly', "
                    "'quarterly') under 'monitoring_frequency'."
                ),
            ))

        if not meta.get("performance_thresholds"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No performance thresholds defined. Degradation "
                    "thresholds that trigger re-validation or model "
                    "retirement should be documented and monitored."
                ),
                regulation_citation="SR 11-7 § 4.2",
                remediation=(
                    "Define performance thresholds (e.g. AUC drop > 5%, "
                    "DI ratio < 0.80) under 'performance_thresholds'."
                ),
            ))

        return findings

    def _check_change_management(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """SR 11-7 § 4.3: Change management."""
        findings: List[ComplianceFinding] = []

        if not meta.get("change_log"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No change log recorded. SR 11-7 requires "
                    "documentation of all material changes to the model, "
                    "including retraining, feature changes, and threshold "
                    "adjustments."
                ),
                regulation_citation="SR 11-7 § 4.3",
                remediation=(
                    "Maintain a change log that records what changed, "
                    "when, why, who approved it, and whether re-validation "
                    "was triggered."
                ),
            ))

        if not meta.get("approved_by"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No deployment approval recorded. SR 11-7 requires "
                    "governance sign-off before a model (or model change) "
                    "is deployed to production."
                ),
                regulation_citation="SR 11-7 § 5",
                remediation=(
                    "Record the approver's name and date under "
                    "'approved_by' and 'approval_date'."
                ),
            ))

        return findings

    def _check_data_governance(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """SR 11-7 § 3.2: Data quality and relevance."""
        findings: List[ComplianceFinding] = []

        if not meta.get("training_data_description"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No training data description provided. SR 11-7 "
                    "requires documentation of the data used for model "
                    "development, including its source, time period, "
                    "and known limitations."
                ),
                regulation_citation="SR 11-7 § 3.2",
                remediation=(
                    "Document the training data source, period, "
                    "population, and known limitations under "
                    "'training_data_description'."
                ),
            ))

        if not meta.get("training_data_hash"):
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    "No training data hash recorded. A cryptographic hash "
                    "of the training dataset enables tamper-evident "
                    "verification that the documented data matches what "
                    "was actually used."
                ),
                regulation_citation="SR 11-7 § 3.2",
                remediation=(
                    "Compute a SHA-256 hash of the training data and "
                    "record under 'training_data_hash'."
                ),
            ))

        # Check DAG provenance completeness
        source_count = len(list(dag.source_nodes))
        if source_count == 0:
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No data source nodes found in the computation DAG. "
                    "Data lineage is a core component of model "
                    "documentation under SR 11-7."
                ),
                regulation_citation="SR 11-7 § 3",
                remediation=(
                    "Ensure the computation DAG captures all data sources "
                    "with table and column metadata."
                ),
            ))

        # HYDRA-32 taint risk: flag undocumented proxy variables
        taint_risks = dag.column_taint_risks()
        documented_proxies = set(meta.get("documented_proxy_variables", []))
        undocumented = {
            col: risk for col, risk in taint_risks.items()
            if col not in documented_proxies
            and not any(n.column == col and n.is_protected for n in dag.source_nodes)
        }
        if undocumented:
            col_list = ", ".join(
                f"{col} (risk={risk:.2f})"
                for col, risk in sorted(
                    undocumented.items(), key=lambda x: x[1], reverse=True,
                )[:5]
            )
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    f"Undocumented taint-carrying columns detected: "
                    f"{col_list}. SR 11-7 § 3.2 requires documentation "
                    f"of all data inputs, including those that derive from "
                    f"protected attributes. These columns carry taint from "
                    f"protected data sources but are not listed in "
                    f"documented_proxy_variables."
                ),
                regulation_citation="SR 11-7 § 3.2",
                remediation=(
                    "Document all columns that derive from protected data "
                    "as proxy variables in 'documented_proxy_variables'. "
                    "Assess whether their inclusion is justified."
                ),
            ))

        return findings

    def _check_governance_controls(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """SR 11-7 § 5: Governance, policies, and controls."""
        findings: List[ComplianceFinding] = []

        if not meta.get("escalation_procedures"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No escalation procedures documented. SR 11-7 § 5 "
                    "requires clear escalation paths when model "
                    "performance degrades or compliance issues arise."
                ),
                regulation_citation="SR 11-7 § 5",
                remediation=(
                    "Document escalation procedures including trigger "
                    "conditions, responsible parties, and timelines."
                ),
            ))

        return findings

    # -- new checks (comprehensive SR 11-7 / OCC 2011-12 coverage) ---------

    def _check_model_tiering(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """SR 11-7 § 5: Model risk tiering framework.

        Models must be classified by risk level (critical/high/medium/low)
        based on materiality and complexity.  The tier drives the intensity
        of validation, monitoring, and governance required.
        """
        findings: List[ComplianceFinding] = []

        tier = (meta.get("model_risk_tier") or "").lower()
        valid_tiers = {"critical", "high", "medium", "low"}

        if not tier:
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No model risk tier assigned. SR 11-7 § 5 requires "
                    "classification by risk level based on materiality and "
                    "complexity to determine validation intensity."
                ),
                regulation_citation="SR 11-7 § 5",
                remediation=(
                    "Assign model_risk_tier (critical/high/medium/low) based "
                    "on materiality, complexity, and uncertainty."
                ),
            ))
        elif tier not in valid_tiers:
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    f"Invalid risk tier '{tier}'. Expected one of: "
                    f"{', '.join(sorted(valid_tiers))}."
                ),
                regulation_citation="SR 11-7 § 5",
                remediation=f"Use one of: {', '.join(sorted(valid_tiers))}.",
            ))

        return findings

    def _check_independent_validation(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """SR 11-7 § 4: Validator independence and coverage.

        Validators must be organisationally independent from model
        development and must cover conceptual soundness, ongoing
        monitoring, and outcomes analysis.
        """
        findings: List[ComplianceFinding] = []

        validator = meta.get("model_validator")
        developer = meta.get("model_developer")

        if validator and developer:
            if str(validator).lower() == str(developer).lower():
                findings.append(ComplianceFinding(
                    severity=Severity.CRITICAL,
                    description=(
                        "Validation performed by model developer. SR 11-7 "
                        "§ 4 explicitly requires independence from "
                        "development and use."
                    ),
                    regulation_citation="SR 11-7 § 4",
                    remediation=(
                        "Assign validation to staff independent from model "
                        "development."
                    ),
                ))

        if meta.get("model_validation_date") and not meta.get("validation_conceptual_soundness"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No conceptual soundness review documented. SR 11-7 "
                    "§ 4.1 requires validation to assess whether the "
                    "model's design is sound for its intended use."
                ),
                regulation_citation="SR 11-7 § 4.1",
                remediation=(
                    "Document conceptual soundness review covering model "
                    "theory, assumptions, and design appropriateness."
                ),
            ))

        if meta.get("model_validation_date") and not meta.get("validation_outcomes_analysis"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No outcomes analysis / backtesting documented. "
                    "SR 11-7 § 4 requires comparison of actual outcomes "
                    "with model predictions."
                ),
                regulation_citation="SR 11-7 § 4",
                remediation=(
                    "Conduct backtesting and document results (AUC, KS, "
                    "Brier score) under 'validation_outcomes_analysis'."
                ),
            ))

        return findings

    def _check_challenger_models(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """OCC Handbook § 3.2: Challenger / benchmark models.

        Critical and high-tier models should have a challenger model
        providing an alternative validation perspective.
        """
        findings: List[ComplianceFinding] = []

        tier = (meta.get("model_risk_tier") or "").lower()
        if tier in ("critical", "high"):
            if not meta.get("challenger_model_name"):
                findings.append(ComplianceFinding(
                    severity=Severity.INFO,
                    description=(
                        f"No challenger model documented for {tier}-tier "
                        f"model. OCC Comptroller's Handbook § 3.2 lists "
                        f"challenger/benchmark models as one possible validation "
                        f"technique — not a mandate. SR 11-7 does not require "
                        f"challenger models explicitly."
                    ),
                    regulation_citation="OCC Handbook § 3.2",
                    remediation=(
                        "Consider developing a challenger/benchmark model for "
                        "additional validation perspective. Record as "
                        "'challenger_model_name'."
                    ),
                ))

        return findings

    def _check_monitoring_frequency_alignment(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """SR 11-7 § 4.2: Monitoring frequency must match risk tier."""
        findings: List[ComplianceFinding] = []

        freq = (meta.get("monitoring_frequency") or "").lower()
        tier = (meta.get("model_risk_tier") or "").lower()

        if not freq or not tier:
            return findings

        freq_days = {
            "daily": 1, "weekly": 7, "monthly": 30,
            "quarterly": 90, "semiannual": 180, "annual": 365,
        }
        min_freq = {
            "critical": "monthly", "high": "quarterly",
            "medium": "quarterly", "low": "annual",
        }

        required = min_freq.get(tier)
        if required and freq in freq_days and required in freq_days:
            if freq_days[freq] > freq_days[required]:
                findings.append(ComplianceFinding(
                    severity=Severity.WARNING,
                    description=(
                        f"Monitoring frequency '{freq}' is less frequent "
                        f"than {tier}-tier minimum of '{required}'. "
                        f"SR 11-7 § 4.2 requires frequency commensurate "
                        f"with risk."
                    ),
                    regulation_citation="SR 11-7 § 4.2",
                    remediation=(
                        f"Increase monitoring frequency to at least "
                        f"'{required}'."
                    ),
                ))

        return findings

    def _check_concentration_risk(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """OCC Handbook § 2.2: Feature and data source concentration risk."""
        findings: List[ComplianceFinding] = []

        feature_importance = meta.get("feature_importance", {})
        if isinstance(feature_importance, dict) and len(feature_importance) >= 3:
            total = sum(feature_importance.values())
            if total > 0:
                sorted_imp = sorted(
                    feature_importance.values(), reverse=True
                )
                top3_pct = sum(sorted_imp[:3]) / total
                if top3_pct > 0.75:
                    findings.append(ComplianceFinding(
                        severity=Severity.WARNING,
                        description=(
                            f"Feature concentration risk: top 3 features "
                            f"account for {top3_pct:.0%} of model "
                            f"importance. High concentration creates "
                            f"fragility if dominant features drift."
                        ),
                        regulation_citation="OCC Handbook § 2.2",
                        remediation=(
                            "Evaluate feature diversification and document "
                            "concentration risk compensating controls."
                        ),
                    ))

        source_count = len(list(dag.source_nodes))
        if source_count == 1:
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    "Model uses a single data source. SR 11-7 § 3.2 "
                    "recommends assessing data source concentration risk."
                ),
                regulation_citation="SR 11-7 § 3.2",
                remediation=(
                    "Evaluate whether alternative data sources could "
                    "reduce concentration risk."
                ),
            ))

        return findings

    def _check_use_limitations(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """SR 11-7 § 3: Model assumptions, limitations, compensating controls."""
        findings: List[ComplianceFinding] = []

        if not meta.get("model_assumptions"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No model assumptions documented. SR 11-7 § 3 requires "
                    "identification of key assumptions (distributional, "
                    "statistical, operational)."
                ),
                regulation_citation="SR 11-7 § 3",
                remediation=(
                    "Document key assumptions: statistical distributions, "
                    "parameter stability, data stationarity."
                ),
            ))

        if not meta.get("model_limitations"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No model limitations documented. SR 11-7 § 3 requires "
                    "disclosure of known constraints and situations where "
                    "the model may not perform well."
                ),
                regulation_citation="SR 11-7 § 3",
                remediation=(
                    "Document known limitations: out-of-sample populations, "
                    "data quality issues, performance constraints."
                ),
            ))

        if not meta.get("compensating_controls"):
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    "No compensating controls documented. OCC 2011-12 "
                    "requires mitigating steps when model reliability "
                    "is questioned (output adjustments, use restrictions, "
                    "supplementary analysis)."
                ),
                regulation_citation="OCC 2011-12 § III.D",
                remediation=(
                    "Document compensating controls for each model "
                    "limitation."
                ),
            ))

        return findings

    def _check_vendor_models(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """Interagency Third-Party Guidance (2023): Vendor model risk.

        The bank remains responsible for vendor model risk.  Vendor models
        must be independently validated by the bank and monitored under SLA.
        """
        if not meta.get("is_vendor_model", False):
            return []  # N/A: vendor model checks only apply to third-party models

        findings: List[ComplianceFinding] = []

        if not meta.get("vendor_name"):
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "Third-party model used but vendor not identified. "
                    "Interagency Third-Party Guidance (2023) requires "
                    "banks to identify and assess all vendor relationships."
                ),
                regulation_citation="Interagency 3rd-Party Guidance (2023)",
                remediation="Record vendor name under 'vendor_name'.",
            ))

        if not meta.get("vendor_model_validation_evidence"):
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "No evidence that vendor model has been validated by "
                    "the bank. OCC 2011-12 requires independent validation "
                    "of all models in production, including vendor models."
                ),
                regulation_citation="OCC 2011-12 / SR 11-7 § 4",
                remediation=(
                    "Conduct independent validation of the vendor model "
                    "and document under 'vendor_model_validation_evidence'."
                ),
            ))

        if not meta.get("vendor_contract_terms"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No vendor contract terms documented. Contract should "
                    "require development evidence, validation data, and "
                    "incident notification."
                ),
                regulation_citation="Interagency 3rd-Party Guidance (2023)",
                remediation=(
                    "Document vendor contract requirements under "
                    "'vendor_contract_terms'."
                ),
            ))

        return findings

    def _check_governance_framework(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """SR 11-7 § 5: MRM committee, board reporting, policies.

        Governance through formal committees with board oversight, senior
        management participation, and defined charter.
        """
        findings: List[ComplianceFinding] = []

        if not meta.get("mrm_committee_name"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No Model Risk Management (MRM) Committee identified. "
                    "SR 11-7 § 5 requires governance through formal "
                    "committees with board oversight."
                ),
                regulation_citation="SR 11-7 § 5",
                remediation=(
                    "Establish formal MRM Committee with charter, "
                    "membership, and meeting schedule."
                ),
            ))

        if not meta.get("board_reporting_frequency"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No board-level model risk reporting frequency defined. "
                    "SR 11-7 § 5 requires board and senior management to "
                    "receive model risk reports at appropriate frequency."
                ),
                regulation_citation="SR 11-7 § 5",
                remediation=(
                    "Define board reporting frequency (typically quarterly) "
                    "under 'board_reporting_frequency'."
                ),
            ))

        tier = (meta.get("model_risk_tier") or "").lower()
        if tier in ("critical", "high") and not meta.get("board_approval_date"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    f"No board approval date recorded for {tier}-tier model. "
                    f"SR 11-7 § 5 requires the board to approve the MRM "
                    f"framework and policies — not individual model approvals. "
                    f"Board oversight of specific models occurs through risk "
                    f"reporting, not per-model approval gates."
                ),
                regulation_citation="SR 11-7 § 5",
                remediation=(
                    "If your institution's MRM policy requires individual board "
                    "approval for high-tier models, record the date under "
                    "'board_approval_date'."
                ),
            ))

        if not meta.get("model_policies_documentation"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No model risk management policies documented. "
                    "SR 11-7 § 5 requires written policies governing "
                    "development, validation, use, and monitoring."
                ),
                regulation_citation="SR 11-7 § 5",
                remediation=(
                    "Document MRM policies covering development standards, "
                    "validation framework, monitoring procedures, and "
                    "governance. Record under 'model_policies_documentation'."
                ),
            ))

        return findings

    def _check_model_documentation(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """SR 11-7 § 3-4: Model documentation completeness."""
        findings: List[ComplianceFinding] = []

        doc_checks = {
            "design_document": (
                Severity.WARNING,
                "No model design document. SR 11-7 § 3 requires "
                "documentation of model theory, assumptions, and "
                "methodology.",
                "SR 11-7 § 3",
            ),
            "testing_results": (
                Severity.WARNING,
                "No testing results documented. SR 11-7 § 4 requires "
                "evidence of in-sample and out-of-sample testing.",
                "SR 11-7 § 4",
            ),
            "training_data_documentation": (
                Severity.WARNING,
                "Training data not fully documented. SR 11-7 § 3.2 "
                "requires source, period, population, and known biases.",
                "SR 11-7 § 3.2",
            ),
        }

        for key, (severity, desc, citation) in doc_checks.items():
            if not meta.get(key):
                findings.append(ComplianceFinding(
                    severity=severity,
                    description=desc,
                    regulation_citation=citation,
                    remediation=(
                        f"Create and attach {key.replace('_', ' ')} to "
                        f"model record."
                    ),
                ))

        return findings

    def _check_data_provenance(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """SR 11-7 § 3.2 / OCC Handbook: HYDRA-32 data provenance coverage.

        Verifies that all model input features have traceable lineage in the
        computation DAG.  Models with zero or partial provenance receive
        escalating findings.  Full coverage (1.0) produces no finding.
        """
        findings: List[ComplianceFinding] = []

        coverage = meta.get("provenance_coverage")
        if coverage is None:
            feature_src_ids = {
                n.node_id for n in dag.nodes.values()
                if getattr(n, "node_type", None) is not None
                and n.node_type.name == "SOURCE"
                and not n.is_protected
            }
            connected_ids = {e.source_id for e in dag.edges}
            if feature_src_ids:
                coverage = len(feature_src_ids & connected_ids) / len(feature_src_ids)
            else:
                coverage = 0.0

        coverage = float(coverage)

        if coverage == 0.0:
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "No HYDRA-32 data provenance recorded. SR 11-7 § 3.2 requires "
                    "complete data lineage for all model inputs. Without a computation "
                    "DAG, examiners cannot verify the integrity of training data."
                ),
                regulation_citation="SR 11-7 § 3.2",
                remediation=(
                    "Wrap your pipeline with attestant.DAGTracker() to capture "
                    "end-to-end data lineage automatically."
                ),
            ))
        elif coverage < 0.50:
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    f"Partial data provenance: {coverage:.0%} of model input features "
                    f"have traceable lineage in the HYDRA-32 computation DAG. "
                    f"SR 11-7 § 3.2 expects complete data lineage for all inputs."
                ),
                regulation_citation="SR 11-7 § 3.2",
                remediation=(
                    "Extend DAGTracker wrapping to all data sources and transformation "
                    "steps to achieve full provenance coverage."
                ),
            ))
        elif coverage < 1.0:
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    f"Data provenance coverage is {coverage:.0%}. Some model input "
                    f"features are not fully traced in the HYDRA-32 DAG. Consider "
                    f"extending DAGTracker to remaining pipeline steps."
                ),
                regulation_citation="SR 11-7 § 3.2",
                remediation=(
                    "Wrap remaining data sources with attestant.DAGTracker() "
                    "to achieve 100% provenance coverage."
                ),
            ))

        # HYDRA-32 depth: assess model pipeline complexity
        max_depth = 0
        for node in dag.nodes.values():
            d = _PT.get_depth(node.provenance)
            if d > max_depth:
                max_depth = d
        if max_depth >= 6:
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    f"High derivation depth detected (max depth: {max_depth}). "
                    f"Deeply derived features increase model complexity and "
                    f"reduce explainability. SR 11-7 § 3 requires that model "
                    f"complexity be commensurate with intended use."
                ),
                regulation_citation="SR 11-7 § 3",
                remediation=(
                    "Review deeply derived features for necessity. Consider "
                    "simplifying the feature pipeline to reduce derivation "
                    "depth and improve model interpretability."
                ),
            ))

        return findings
