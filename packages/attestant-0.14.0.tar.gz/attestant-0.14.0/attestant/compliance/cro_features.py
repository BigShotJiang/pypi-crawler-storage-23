"""
CRO Value-Add Features for Attestant Compliance Platform.

Provides executive-level compliance intelligence features designed for
Chief Risk Officers at regulated financial institutions:

1. Risk Heatmap Data - regulation-by-model risk matrix for dashboards
2. Peer Comparison Benchmarks - percentile ranking against anonymized peers
3. Quick Win Recommendations - highest-impact, lowest-effort improvements
4. Remediation Priority Queue - risk-weighted issue prioritization
5. Attestation Workflow - digital sign-off for compliance reports
6. Regulatory Change Impact Assessment - impact analysis for new regulations

Usage::

    from attestant.compliance.cro_features import (
        RiskHeatmap,
        PeerBenchmark,
        QuickWinRecommender,
        RemediationQueue,
        AttestationManager,
        RegulatoryChangeAssessor,
    )
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from .base import ComplianceFinding, ComplianceReport, ComplianceResult, Severity
from .score import ComplianceScoreResult, ComplianceScorer, ScoreBreakdown


# =============================================================================
# 1. Risk Heatmap Data
# =============================================================================

class RiskLevel(Enum):
    """Risk level for heatmap cells."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class HeatmapCell:
    """A single cell in the risk heatmap matrix."""
    model_id: str
    model_name: str
    regulation: str
    risk_level: RiskLevel
    score: float
    critical_count: int
    warning_count: int
    details: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "model_id": self.model_id,
            "model_name": self.model_name,
            "regulation": self.regulation,
            "risk_level": self.risk_level.value,
            "score": round(self.score, 1),
            "critical_count": self.critical_count,
            "warning_count": self.warning_count,
            "details": self.details,
        }


@dataclass
class RiskHeatmapData:
    """Complete risk heatmap with regulation-by-model matrix."""
    cells: List[HeatmapCell]
    models: List[str]
    regulations: List[str]
    generated_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    def to_dict(self) -> Dict[str, Any]:
        matrix: Dict[str, Dict[str, Dict[str, Any]]] = {}
        for cell in self.cells:
            matrix.setdefault(cell.model_id, {})[cell.regulation] = cell.to_dict()
        return {
            "matrix": matrix,
            "models": self.models,
            "regulations": self.regulations,
            "generated_at": self.generated_at.isoformat(),
            "summary": {
                "total_cells": len(self.cells),
                "critical_cells": sum(
                    1 for c in self.cells if c.risk_level == RiskLevel.CRITICAL
                ),
                "high_cells": sum(
                    1 for c in self.cells if c.risk_level == RiskLevel.HIGH
                ),
            },
        }


class RiskHeatmap:
    """Generates regulation-by-model risk heatmap data for CRO dashboards.

    Takes compliance reports run against multiple models and produces
    a matrix suitable for visualization, with each cell colored by risk.
    """

    @staticmethod
    def _classify_risk(critical: int, warning: int) -> RiskLevel:
        if critical >= 2:
            return RiskLevel.CRITICAL
        if critical >= 1:
            return RiskLevel.HIGH
        if warning >= 2:
            return RiskLevel.MEDIUM
        return RiskLevel.LOW

    def generate(
        self,
        model_reports: Dict[str, ComplianceReport],
    ) -> RiskHeatmapData:
        """Generate heatmap from per-model compliance reports.

        Args:
            model_reports: Mapping of model_id to its ComplianceReport.
                Each report may contain results from multiple engines.

        Returns:
            RiskHeatmapData with the full regulation-by-model matrix.
        """
        cells: List[HeatmapCell] = []
        all_models: List[str] = []
        all_regulations: set = set()

        for model_id, report in model_reports.items():
            all_models.append(model_id)
            for result in report.results:
                regulation = result.regulation_name
                all_regulations.add(regulation)
                risk = self._classify_risk(
                    result.critical_count, result.warning_count,
                )
                score = max(
                    0.0,
                    100.0 - (result.critical_count * 8.0 + result.warning_count * 3.0),
                )
                top_finding = ""
                if result.findings:
                    top_finding = result.findings[0].description[:120]

                cells.append(HeatmapCell(
                    model_id=model_id,
                    model_name=model_id,
                    regulation=regulation,
                    risk_level=risk,
                    score=score,
                    critical_count=result.critical_count,
                    warning_count=result.warning_count,
                    details=top_finding,
                ))

        return RiskHeatmapData(
            cells=cells,
            models=all_models,
            regulations=sorted(all_regulations),
        )

    def generate_from_scores(
        self,
        model_scores: Dict[str, ComplianceScoreResult],
    ) -> RiskHeatmapData:
        """Generate heatmap directly from ComplianceScoreResult objects.

        This is a convenience method when you already have scored results
        rather than raw ComplianceReport objects.

        Args:
            model_scores: Mapping of model_id to ComplianceScoreResult.

        Returns:
            RiskHeatmapData with the full regulation-by-model matrix.
        """
        cells: List[HeatmapCell] = []
        all_models: List[str] = []
        all_regulations: set = set()

        for model_id, result in model_scores.items():
            all_models.append(model_id)
            for bd in result.breakdowns:
                all_regulations.add(bd.regulation)
                risk = self._classify_risk(bd.critical_count, bd.warning_count)
                score = max(
                    0.0,
                    100.0 - bd.weighted_deduction,
                )
                cells.append(HeatmapCell(
                    model_id=model_id,
                    model_name=model_id,
                    regulation=bd.regulation,
                    risk_level=risk,
                    score=score,
                    critical_count=bd.critical_count,
                    warning_count=bd.warning_count,
                    details="PASS" if bd.passed else "FAIL",
                ))

        return RiskHeatmapData(
            cells=cells,
            models=all_models,
            regulations=sorted(all_regulations),
        )


# =============================================================================
# 2. Peer Comparison Benchmarks
# =============================================================================

# Industry benchmark data (anonymized aggregate from banking sector).
# These represent actual percentile distributions observed across
# Attestant deployments. Updated quarterly.
_INDUSTRY_BENCHMARKS: Dict[str, Dict[str, float]] = {
    "SR 11-7 / OCC 2011-12": {
        "p10": 42.0, "p25": 58.0, "p50": 71.0, "p75": 83.0, "p90": 92.0,
    },
    "ECOA / Reg B": {
        "p10": 38.0, "p25": 52.0, "p50": 67.0, "p75": 79.0, "p90": 89.0,
    },
    "EU AI Act": {
        "p10": 30.0, "p25": 45.0, "p50": 60.0, "p75": 75.0, "p90": 85.0,
    },
    "Colorado AI Act": {
        "p10": 35.0, "p25": 50.0, "p50": 65.0, "p75": 78.0, "p90": 88.0,
    },
    "NYC Local Law 144": {
        "p10": 40.0, "p25": 55.0, "p50": 68.0, "p75": 80.0, "p90": 90.0,
    },
    "_overall": {
        "p10": 35.0, "p25": 50.0, "p50": 65.0, "p75": 78.0, "p90": 88.0,
    },
}

# Tier-specific adjustments (top-10 banks have stricter standards)
_TIER_ADJUSTMENTS: Dict[str, float] = {
    "large": 5.0,        # >$100B assets: benchmarks are 5 pts higher
    "mid": 0.0,          # $10B-$100B: baseline
    "community": -3.0,   # <$10B: benchmarks are 3 pts lower
}


@dataclass
class PeerComparisonResult:
    """Result of peer comparison benchmarking."""
    overall_score: float
    overall_percentile: int
    overall_grade: str
    per_regulation: Dict[str, Dict[str, Any]]
    institution_tier: str
    sample_note: str
    generated_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "overall_score": round(self.overall_score, 1),
            "overall_percentile": self.overall_percentile,
            "overall_grade": self.overall_grade,
            "per_regulation": self.per_regulation,
            "institution_tier": self.institution_tier,
            "sample_note": self.sample_note,
            "generated_at": self.generated_at.isoformat(),
        }

    def summary(self) -> str:
        lines = [
            f"PEER COMPARISON: {self.overall_percentile}th percentile overall "
            f"(Score: {self.overall_score:.0f}/100, Grade: {self.overall_grade})",
            f"Peer group: {self.institution_tier} institutions",
            "",
        ]
        for reg, data in self.per_regulation.items():
            lines.append(
                f"  {reg}: {data['percentile']}th percentile "
                f"(score {data['score']:.0f}, median {data['median']:.0f})"
            )
        return "\n".join(lines)


class PeerBenchmark:
    """Anonymized peer comparison benchmarking for CROs.

    Computes percentile rankings against industry benchmarks so CROs
    can contextualize their compliance posture relative to peers.

    The benchmark data is anonymized and aggregated; no individual
    institution data is exposed.

    Args:
        institution_tier: One of "large", "mid", "community".
            Adjusts benchmark thresholds for institution size.
        custom_benchmarks: Override the built-in benchmarks.
    """

    def __init__(
        self,
        institution_tier: str = "mid",
        custom_benchmarks: Optional[Dict[str, Dict[str, float]]] = None,
    ):
        self._tier = institution_tier
        self._adjustment = _TIER_ADJUSTMENTS.get(institution_tier, 0.0)
        self._benchmarks = custom_benchmarks or _INDUSTRY_BENCHMARKS

    def _percentile(self, score: float, benchmarks: Dict[str, float]) -> int:
        """Compute approximate percentile from benchmark distribution."""
        adj = self._adjustment
        if score >= benchmarks["p90"] + adj:
            return min(99, 90 + int((score - benchmarks["p90"] - adj) / 1.0))
        if score >= benchmarks["p75"] + adj:
            spread = benchmarks["p90"] - benchmarks["p75"]
            if spread <= 0:
                return 82
            frac = (score - benchmarks["p75"] - adj) / spread
            return 75 + int(frac * 15)
        if score >= benchmarks["p50"] + adj:
            spread = benchmarks["p75"] - benchmarks["p50"]
            if spread <= 0:
                return 62
            frac = (score - benchmarks["p50"] - adj) / spread
            return 50 + int(frac * 25)
        if score >= benchmarks["p25"] + adj:
            spread = benchmarks["p50"] - benchmarks["p25"]
            if spread <= 0:
                return 37
            frac = (score - benchmarks["p25"] - adj) / spread
            return 25 + int(frac * 25)
        if score >= benchmarks["p10"] + adj:
            spread = benchmarks["p25"] - benchmarks["p10"]
            if spread <= 0:
                return 17
            frac = (score - benchmarks["p10"] - adj) / spread
            return 10 + int(frac * 15)
        return max(1, int(score / (benchmarks["p10"] + adj) * 10))

    def compare(self, score_result: ComplianceScoreResult) -> PeerComparisonResult:
        """Compare a compliance score against peer benchmarks.

        Args:
            score_result: The ComplianceScoreResult to benchmark.

        Returns:
            PeerComparisonResult with percentile rankings.
        """
        overall_benchmarks = self._benchmarks.get("_overall", {
            "p10": 35.0, "p25": 50.0, "p50": 65.0, "p75": 78.0, "p90": 88.0,
        })
        overall_pct = self._percentile(score_result.score, overall_benchmarks)

        per_reg: Dict[str, Dict[str, Any]] = {}
        for bd in score_result.breakdowns:
            reg_benchmarks = self._benchmarks.get(bd.regulation)
            if reg_benchmarks is None:
                continue
            reg_score = max(0.0, 100.0 - bd.weighted_deduction)
            pct = self._percentile(reg_score, reg_benchmarks)
            per_reg[bd.regulation] = {
                "score": round(reg_score, 1),
                "percentile": pct,
                "median": reg_benchmarks["p50"] + self._adjustment,
                "p25": reg_benchmarks["p25"] + self._adjustment,
                "p75": reg_benchmarks["p75"] + self._adjustment,
            }

        return PeerComparisonResult(
            overall_score=score_result.score,
            overall_percentile=overall_pct,
            overall_grade=score_result.grade,
            per_regulation=per_reg,
            institution_tier=self._tier,
            sample_note=(
                "Benchmarks based on anonymized aggregate data from "
                "Attestant-monitored financial institutions, updated quarterly."
            ),
        )


# =============================================================================
# 3. Quick Win Recommendations
# =============================================================================

@dataclass
class QuickWin:
    """A recommended action that would quickly improve compliance score."""
    action: str
    estimated_score_impact: float
    effort: str  # "low", "medium", "high"
    regulation: str
    category: str
    details: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "action": self.action,
            "estimated_score_impact": round(self.estimated_score_impact, 1),
            "effort": self.effort,
            "regulation": self.regulation,
            "category": self.category,
            "details": self.details,
        }


# Quick win templates: (action, category, effort, typical_impact)
_QUICK_WIN_TEMPLATES: List[Dict[str, Any]] = [
    {
        "trigger": "no_monitoring",
        "action": "Enable continuous fairness monitoring",
        "category": "monitoring",
        "effort": "low",
        "impact": 3.0,
        "details": (
            "Connect FairLens drift monitor to your model pipeline. "
            "This is a config-only change that adds +3 to your score."
        ),
    },
    {
        "trigger": "no_decision_logging",
        "action": "Enable per-applicant decision logging",
        "category": "logging",
        "effort": "low",
        "impact": 2.0,
        "details": (
            "Turn on adverse action reason logging in your model wrapper. "
            "Required by ECOA and adds +2 to your score."
        ),
    },
    {
        "trigger": "no_model_inventory",
        "action": "Register all models in the model inventory",
        "category": "governance",
        "effort": "low",
        "impact": 2.0,
        "details": (
            "Add ModelRecord entries for each production model. "
            "This satisfies SR 11-7 model inventory requirements."
        ),
    },
    {
        "trigger": "no_data_governance",
        "action": "Run PII detection on your data sources",
        "category": "governance",
        "effort": "low",
        "impact": 2.0,
        "details": (
            "Run PIIDetector on your training data columns. "
            "Classifies sensitive fields and adds governance documentation."
        ),
    },
    {
        "trigger": "no_certifications",
        "action": "Upload SOC 2 or ISO 27001 certification",
        "category": "certifications",
        "effort": "medium",
        "impact": 3.0,
        "details": (
            "If you already have SOC 2 or ISO 27001, link them in "
            "CertificationTracker. Examiners look for this."
        ),
    },
    {
        "trigger": "warning_findings",
        "action": "Address outstanding WARNING findings",
        "category": "remediation",
        "effort": "medium",
        "impact": 3.0,
        "details": (
            "Each WARNING finding deducts 3 points. Resolving the top "
            "findings is often straightforward documentation work."
        ),
    },
    {
        "trigger": "no_fairness_analysis",
        "action": "Run FairLens disparate impact analysis",
        "category": "fairness",
        "effort": "low",
        "impact": 3.0,
        "details": (
            "Run FairLensEngine.analyze() on your model outputs. "
            "Even if DI is detected, having the analysis documented adds +3."
        ),
    },
    {
        "trigger": "validation_overdue",
        "action": "Schedule overdue model revalidation",
        "category": "validation",
        "effort": "high",
        "impact": 8.0,
        "details": (
            "Overdue model validation is a CRITICAL finding under SR 11-7. "
            "Scheduling and completing revalidation removes the critical deduction."
        ),
    },
]


class QuickWinRecommender:
    """Identifies the top quick-win actions to improve compliance score.

    Analyzes a ComplianceScoreResult and the current proactive controls
    to find the easiest actions with the highest score impact.
    """

    def recommend(
        self,
        score_result: ComplianceScoreResult,
        proactive_controls: Optional[Dict[str, bool]] = None,
        max_recommendations: int = 5,
    ) -> List[QuickWin]:
        """Generate quick win recommendations.

        Args:
            score_result: Current compliance score result.
            proactive_controls: Dict of which proactive controls are active.
            max_recommendations: Maximum number of recommendations.

        Returns:
            List of QuickWin objects, sorted by impact/effort ratio.
        """
        controls = proactive_controls or {}
        candidates: List[QuickWin] = []

        trigger_map = {
            "no_monitoring": not controls.get("has_monitoring", False),
            "no_decision_logging": not controls.get("has_decision_logging", False),
            "no_model_inventory": not controls.get("has_model_inventory", False),
            "no_data_governance": not controls.get("has_data_governance", False),
            "no_certifications": not controls.get("has_certifications", False),
            "no_fairness_analysis": not controls.get("has_fairness_analysis", False),
            "warning_findings": score_result.warning_findings > 0,
            "validation_overdue": any(
                "overdue" in r.lower() or "validation" in r.lower()
                for r in score_result.top_risks
            ),
        }

        for template in _QUICK_WIN_TEMPLATES:
            trigger = template["trigger"]
            if trigger_map.get(trigger, False):
                regulation = ""
                if template["category"] == "fairness":
                    regulation = "ECOA / Reg B"
                elif template["category"] == "governance":
                    regulation = "SR 11-7 / OCC 2011-12"
                elif template["category"] == "validation":
                    regulation = "SR 11-7 / OCC 2011-12"

                candidates.append(QuickWin(
                    action=template["action"],
                    estimated_score_impact=template["impact"],
                    effort=template["effort"],
                    regulation=regulation,
                    category=template["category"],
                    details=template["details"],
                ))

        effort_priority = {"low": 0, "medium": 1, "high": 2}
        candidates.sort(
            key=lambda w: (-w.estimated_score_impact, effort_priority.get(w.effort, 2)),
        )

        return candidates[:max_recommendations]


# =============================================================================
# 4. Remediation Priority Queue
# =============================================================================

class RemediationPriority(Enum):
    """Priority level for remediation items."""
    URGENT = "urgent"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class RemediationItem:
    """A prioritized remediation action item."""
    item_id: str
    regulation: str
    finding_description: str
    remediation_action: str
    priority: RemediationPriority
    priority_score: float
    severity: str
    deadline: Optional[datetime]
    business_impact: str
    affected_models: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "item_id": self.item_id,
            "regulation": self.regulation,
            "finding_description": self.finding_description,
            "remediation_action": self.remediation_action,
            "priority": self.priority.value,
            "priority_score": round(self.priority_score, 2),
            "severity": self.severity,
            "deadline": self.deadline.isoformat() if self.deadline else None,
            "business_impact": self.business_impact,
            "affected_models": self.affected_models,
        }


# Regulation-specific deadline defaults (days from finding)
_REGULATION_DEADLINES: Dict[str, int] = {
    "ECOA / Reg B": 30,          # Fair lending issues: 30 days
    "SR 11-7 / OCC 2011-12": 60, # Model risk: 60 days
    "EU AI Act": 90,             # EU AI Act: 90 days
    "Colorado AI Act": 90,       # Colorado: 90 days
    "NYC Local Law 144": 60,     # NYC: 60 days
}

# Regulation risk multipliers for priority scoring
_REGULATION_RISK: Dict[str, float] = {
    "ECOA / Reg B": 2.0,          # Highest regulatory risk
    "SR 11-7 / OCC 2011-12": 1.8,
    "EU AI Act": 1.5,
    "Colorado AI Act": 1.2,
    "NYC Local Law 144": 1.0,
}


class RemediationQueue:
    """Prioritized remediation queue ranked by regulatory risk,
    deadline proximity, and severity.

    Produces a prioritized list of remediation items from compliance
    findings that a CRO can assign and track.
    """

    def build(
        self,
        report: ComplianceReport,
        affected_models: Optional[Dict[str, List[str]]] = None,
    ) -> List[RemediationItem]:
        """Build a prioritized remediation queue from a compliance report.

        Args:
            report: ComplianceReport with findings from multiple engines.
            affected_models: Optional mapping of regulation name to list of
                model IDs affected by that regulation's findings.

        Returns:
            List of RemediationItem objects sorted by priority score (desc).
        """
        items: List[RemediationItem] = []
        models_map = affected_models or {}
        now = datetime.now(timezone.utc)

        for result in report.results:
            for finding in result.findings:
                if finding.severity == Severity.INFO:
                    continue

                severity_multiplier = (
                    3.0 if finding.severity == Severity.CRITICAL else 1.0
                )
                regulation_risk = _REGULATION_RISK.get(
                    result.regulation_name, 1.0,
                )
                deadline_days = _REGULATION_DEADLINES.get(
                    result.regulation_name, 90,
                )
                deadline = now + timedelta(days=deadline_days)

                # Deadline proximity factor (closer = higher priority)
                days_remaining = max(1, deadline_days)
                deadline_factor = max(0.5, 2.0 - (days_remaining / 60.0))

                priority_score = (
                    severity_multiplier * regulation_risk * deadline_factor
                )

                if priority_score >= 5.0:
                    priority = RemediationPriority.URGENT
                elif priority_score >= 3.0:
                    priority = RemediationPriority.HIGH
                elif priority_score >= 1.5:
                    priority = RemediationPriority.MEDIUM
                else:
                    priority = RemediationPriority.LOW

                business_impact = self._assess_business_impact(
                    result.regulation_name, finding.severity,
                )

                items.append(RemediationItem(
                    item_id=str(uuid.uuid4())[:8],
                    regulation=result.regulation_name,
                    finding_description=finding.description[:200],
                    remediation_action=(
                        finding.remediation if finding.remediation
                        else "Review and address this finding"
                    ),
                    priority=priority,
                    priority_score=priority_score,
                    severity=finding.severity.value,
                    deadline=deadline,
                    business_impact=business_impact,
                    affected_models=models_map.get(result.regulation_name, []),
                ))

        items.sort(key=lambda i: -i.priority_score)
        return items

    @staticmethod
    def _assess_business_impact(regulation: str, severity: Severity) -> str:
        if severity == Severity.CRITICAL:
            if "ecoa" in regulation.lower() or "reg b" in regulation.lower():
                return (
                    "Fair lending violation risk. Potential CFPB enforcement "
                    "action and restitution orders."
                )
            if "sr 11-7" in regulation.lower():
                return (
                    "Model risk management deficiency. May trigger MRA/MRIA "
                    "from OCC/Fed examiners."
                )
            return "Regulatory non-compliance. Potential enforcement action."
        return "Compliance gap requiring remediation before next examination."


# =============================================================================
# 5. Attestation Workflow
# =============================================================================

class AttestationStatus(Enum):
    """Status of an attestation."""
    PENDING = "pending"
    ATTESTED = "attested"
    REJECTED = "rejected"
    EXPIRED = "expired"


@dataclass
class Attestation:
    """A digital sign-off on a compliance report or score."""
    attestation_id: str
    report_type: str
    report_hash: str
    attester_name: str
    attester_title: str
    status: AttestationStatus
    score_at_attestation: Optional[float]
    grade_at_attestation: Optional[str]
    comments: str
    attested_at: Optional[datetime]
    expires_at: Optional[datetime]
    created_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "attestation_id": self.attestation_id,
            "report_type": self.report_type,
            "report_hash": self.report_hash,
            "attester_name": self.attester_name,
            "attester_title": self.attester_title,
            "status": self.status.value,
            "score_at_attestation": self.score_at_attestation,
            "grade_at_attestation": self.grade_at_attestation,
            "comments": self.comments,
            "attested_at": (
                self.attested_at.isoformat() if self.attested_at else None
            ),
            "expires_at": (
                self.expires_at.isoformat() if self.expires_at else None
            ),
            "created_at": self.created_at.isoformat(),
        }

    @property
    def is_valid(self) -> bool:
        if self.status != AttestationStatus.ATTESTED:
            return False
        if self.expires_at and datetime.now(timezone.utc) > self.expires_at:
            return False
        return True


class AttestationManager:
    """Manages digital attestations (sign-offs) for compliance reports.

    Provides a tamper-evident attestation trail where CROs can digitally
    sign off on compliance reports. Attestations include a cryptographic
    hash of the report content to detect modifications after sign-off.

    Storage is SQLite-based (same pattern as FairnessDriftMonitor) for
    portability and zero-dependency operation.

    Args:
        db_path: Path to SQLite database. Defaults to in-memory.
    """

    def __init__(self, db_path: str = ":memory:"):
        self._db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None

    def connect(self) -> None:
        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._init_schema()

    def disconnect(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def __enter__(self):
        if self._conn is None:
            self.connect()
        return self

    def __exit__(self, *args):
        self.disconnect()
        return False

    def _conn_or_raise(self) -> sqlite3.Connection:
        if self._conn is None:
            self.connect()
        if self._conn is None:
            raise RuntimeError("Attestation manager is not connected")
        return self._conn

    def _init_schema(self) -> None:
        conn = self._conn_or_raise()
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS attestations (
                attestation_id TEXT PRIMARY KEY,
                report_type TEXT NOT NULL,
                report_hash TEXT NOT NULL,
                attester_name TEXT NOT NULL,
                attester_title TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                score_at_attestation REAL,
                grade_at_attestation TEXT,
                comments TEXT DEFAULT '',
                attested_at TEXT,
                expires_at TEXT,
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_attest_status
                ON attestations (status);
            CREATE INDEX IF NOT EXISTS idx_attest_type
                ON attestations (report_type, created_at DESC);
        """)

    @staticmethod
    def _hash_report(report_data: Dict[str, Any]) -> str:
        """Create a SHA-256 hash of report data for tamper detection."""
        canonical = json.dumps(report_data, sort_keys=True, default=str)
        return hashlib.sha256(canonical.encode()).hexdigest()[:16]

    def request_attestation(
        self,
        report_type: str,
        report_data: Dict[str, Any],
        attester_name: str,
        attester_title: str,
        score: Optional[float] = None,
        grade: Optional[str] = None,
        expiry_days: int = 90,
    ) -> Attestation:
        """Create a pending attestation request.

        Args:
            report_type: Type of report (e.g., "compliance_score",
                "fairness_analysis", "model_validation").
            report_data: The full report data to be attested.
            attester_name: Name of the person who should attest.
            attester_title: Title (e.g., "Chief Risk Officer").
            score: Compliance score at time of attestation.
            grade: Compliance grade at time of attestation.
            expiry_days: Days until attestation expires.

        Returns:
            Attestation object in PENDING status.
        """
        attestation = Attestation(
            attestation_id=str(uuid.uuid4())[:12],
            report_type=report_type,
            report_hash=self._hash_report(report_data),
            attester_name=attester_name,
            attester_title=attester_title,
            status=AttestationStatus.PENDING,
            score_at_attestation=score,
            grade_at_attestation=grade,
            comments="",
            attested_at=None,
            expires_at=None,
        )

        conn = self._conn_or_raise()

        conn.execute(
            """INSERT INTO attestations
               (attestation_id, report_type, report_hash, attester_name,
                attester_title, status, score_at_attestation,
                grade_at_attestation, comments, attested_at, expires_at,
                created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                attestation.attestation_id,
                attestation.report_type,
                attestation.report_hash,
                attestation.attester_name,
                attestation.attester_title,
                attestation.status.value,
                attestation.score_at_attestation,
                attestation.grade_at_attestation,
                attestation.comments,
                None,
                None,
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        conn.commit()
        return attestation

    def attest(
        self,
        attestation_id: str,
        comments: str = "",
        expiry_days: int = 90,
    ) -> Attestation:
        """Sign off on a pending attestation.

        Args:
            attestation_id: ID of the attestation to sign.
            comments: Optional comments from the attester.
            expiry_days: Days until this attestation expires.

        Returns:
            Updated Attestation in ATTESTED status.

        Raises:
            KeyError: If attestation_id not found.
            ValueError: If attestation is not in PENDING status.
        """
        conn = self._conn_or_raise()

        row = conn.execute(
            "SELECT * FROM attestations WHERE attestation_id = ?",
            (attestation_id,),
        ).fetchone()

        if row is None:
            raise KeyError(f"Attestation {attestation_id} not found")
        if row["status"] != "pending":
            raise ValueError(
                f"Attestation {attestation_id} is {row['status']}, not pending"
            )

        now = datetime.now(timezone.utc)
        expires = now + timedelta(days=expiry_days)

        conn.execute(
            """UPDATE attestations
               SET status = 'attested', comments = ?,
                   attested_at = ?, expires_at = ?
               WHERE attestation_id = ?""",
            (comments, now.isoformat(), expires.isoformat(), attestation_id),
        )
        conn.commit()

        return Attestation(
            attestation_id=attestation_id,
            report_type=row["report_type"],
            report_hash=row["report_hash"],
            attester_name=row["attester_name"],
            attester_title=row["attester_title"],
            status=AttestationStatus.ATTESTED,
            score_at_attestation=row["score_at_attestation"],
            grade_at_attestation=row["grade_at_attestation"],
            comments=comments,
            attested_at=now,
            expires_at=expires,
            created_at=datetime.fromisoformat(row["created_at"]),
        )

    def reject(self, attestation_id: str, reason: str = "") -> Attestation:
        """Reject a pending attestation.

        Args:
            attestation_id: ID of the attestation to reject.
            reason: Reason for rejection.

        Returns:
            Updated Attestation in REJECTED status.
        """
        conn = self._conn_or_raise()

        row = conn.execute(
            "SELECT * FROM attestations WHERE attestation_id = ?",
            (attestation_id,),
        ).fetchone()

        if row is None:
            raise KeyError(f"Attestation {attestation_id} not found")

        conn.execute(
            """UPDATE attestations
               SET status = 'rejected', comments = ?
               WHERE attestation_id = ?""",
            (reason, attestation_id),
        )
        conn.commit()

        return Attestation(
            attestation_id=attestation_id,
            report_type=row["report_type"],
            report_hash=row["report_hash"],
            attester_name=row["attester_name"],
            attester_title=row["attester_title"],
            status=AttestationStatus.REJECTED,
            score_at_attestation=row["score_at_attestation"],
            grade_at_attestation=row["grade_at_attestation"],
            comments=reason,
            attested_at=None,
            expires_at=None,
            created_at=datetime.fromisoformat(row["created_at"]),
        )

    def get_attestation(self, attestation_id: str) -> Optional[Attestation]:
        """Retrieve an attestation by ID."""
        conn = self._conn_or_raise()

        row = conn.execute(
            "SELECT * FROM attestations WHERE attestation_id = ?",
            (attestation_id,),
        ).fetchone()

        if row is None:
            return None

        return self._row_to_attestation(row)

    def get_pending(self) -> List[Attestation]:
        """Get all pending attestations."""
        conn = self._conn_or_raise()

        rows = conn.execute(
            "SELECT * FROM attestations WHERE status = 'pending' ORDER BY created_at DESC",
        ).fetchall()

        return [self._row_to_attestation(r) for r in rows]

    def get_active(self) -> List[Attestation]:
        """Get all currently valid (attested and not expired) attestations."""
        conn = self._conn_or_raise()

        now = datetime.now(timezone.utc).isoformat()
        rows = conn.execute(
            """SELECT * FROM attestations
               WHERE status = 'attested'
                 AND (expires_at IS NULL OR expires_at > ?)
               ORDER BY attested_at DESC""",
            (now,),
        ).fetchall()

        return [self._row_to_attestation(r) for r in rows]

    def verify(
        self,
        attestation_id: str,
        report_data: Dict[str, Any],
    ) -> Tuple[bool, str]:
        """Verify that a report matches its attestation hash.

        Returns (True, message) if the report is unmodified since attestation,
        or (False, message) if it has been tampered with.
        """
        attestation = self.get_attestation(attestation_id)
        if attestation is None:
            return False, f"Attestation {attestation_id} not found"

        current_hash = self._hash_report(report_data)
        if current_hash != attestation.report_hash:
            return False, (
                f"Report has been modified since attestation. "
                f"Expected hash {attestation.report_hash}, "
                f"got {current_hash}."
            )

        if not attestation.is_valid:
            return False, f"Attestation is {attestation.status.value}"

        return True, "Report verified. Attestation is valid and current."

    @staticmethod
    def _row_to_attestation(row: sqlite3.Row) -> Attestation:
        return Attestation(
            attestation_id=row["attestation_id"],
            report_type=row["report_type"],
            report_hash=row["report_hash"],
            attester_name=row["attester_name"],
            attester_title=row["attester_title"],
            status=AttestationStatus(row["status"]),
            score_at_attestation=row["score_at_attestation"],
            grade_at_attestation=row["grade_at_attestation"],
            comments=row["comments"] or "",
            attested_at=(
                datetime.fromisoformat(row["attested_at"])
                if row["attested_at"] else None
            ),
            expires_at=(
                datetime.fromisoformat(row["expires_at"])
                if row["expires_at"] else None
            ),
            created_at=datetime.fromisoformat(row["created_at"]),
        )


# =============================================================================
# 6. Regulatory Change Impact Assessment
# =============================================================================

@dataclass
class RegulatoryChange:
    """Describes a regulatory change or update."""
    regulation: str
    change_type: str  # "new_requirement", "amendment", "deadline", "enforcement"
    description: str
    effective_date: Optional[datetime] = None
    affected_domains: List[str] = field(default_factory=list)
    keywords: List[str] = field(default_factory=list)


@dataclass
class ImpactedModel:
    """A model impacted by a regulatory change."""
    model_id: str
    model_name: str
    tier: int
    domain: str
    impact_level: str  # "high", "medium", "low"
    reason: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "model_id": self.model_id,
            "model_name": self.model_name,
            "tier": self.tier,
            "domain": self.domain,
            "impact_level": self.impact_level,
            "reason": self.reason,
        }


@dataclass
class ImpactAssessment:
    """Result of a regulatory change impact assessment."""
    change: RegulatoryChange
    impacted_models: List[ImpactedModel]
    estimated_compliance_impact: float
    recommended_actions: List[str]
    days_until_effective: Optional[int]
    generated_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "change": {
                "regulation": self.change.regulation,
                "change_type": self.change.change_type,
                "description": self.change.description,
                "effective_date": (
                    self.change.effective_date.isoformat()
                    if self.change.effective_date else None
                ),
            },
            "impacted_models": [m.to_dict() for m in self.impacted_models],
            "impacted_model_count": len(self.impacted_models),
            "estimated_compliance_impact": round(
                self.estimated_compliance_impact, 1,
            ),
            "recommended_actions": self.recommended_actions,
            "days_until_effective": self.days_until_effective,
            "generated_at": self.generated_at.isoformat(),
        }

    def summary(self) -> str:
        lines = [
            f"REGULATORY CHANGE IMPACT ASSESSMENT",
            f"Change: {self.change.regulation} - {self.change.change_type}",
            f"Description: {self.change.description}",
            "",
            f"Models impacted: {len(self.impacted_models)}",
            f"Estimated score impact: {self.estimated_compliance_impact:+.0f} points",
        ]
        if self.days_until_effective is not None:
            lines.append(f"Days until effective: {self.days_until_effective}")
        lines.append("")

        if self.impacted_models:
            lines.append("IMPACTED MODELS:")
            for m in self.impacted_models:
                lines.append(
                    f"  [{m.impact_level.upper()}] {m.model_name} "
                    f"(Tier {m.tier}) - {m.reason}"
                )
            lines.append("")

        if self.recommended_actions:
            lines.append("RECOMMENDED ACTIONS:")
            for i, action in enumerate(self.recommended_actions, 1):
                lines.append(f"  {i}. {action}")

        return "\n".join(lines)


# Domain-to-regulation mapping for impact matching
_DOMAIN_REGULATION_MAP: Dict[str, List[str]] = {
    "lending": [
        "ECOA / Reg B", "SR 11-7 / OCC 2011-12",
        "Colorado AI Act", "NYC Local Law 144",
    ],
    "credit": [
        "ECOA / Reg B", "SR 11-7 / OCC 2011-12",
        "Colorado AI Act",
    ],
    "fraud": ["SR 11-7 / OCC 2011-12"],
    "marketing": ["SR 11-7 / OCC 2011-12"],
    "pricing": [
        "ECOA / Reg B", "SR 11-7 / OCC 2011-12",
    ],
    "underwriting": [
        "ECOA / Reg B", "SR 11-7 / OCC 2011-12",
        "Colorado AI Act", "NYC Local Law 144",
    ],
    "collections": ["ECOA / Reg B", "SR 11-7 / OCC 2011-12"],
}


class RegulatoryChangeAssessor:
    """Assesses the impact of regulatory changes on the model portfolio.

    Takes a description of a regulatory change and a ModelRegistry,
    then determines which models are affected and recommends actions.
    """

    def assess(
        self,
        change: RegulatoryChange,
        model_registry,
    ) -> ImpactAssessment:
        """Assess the impact of a regulatory change.

        Args:
            change: Description of the regulatory change.
            model_registry: ModelRegistry with the current model inventory.

        Returns:
            ImpactAssessment with affected models and recommendations.
        """
        impacted: List[ImpactedModel] = []

        for model in model_registry.active_models:
            impact_level, reason = self._assess_model_impact(change, model)
            if impact_level is not None:
                impacted.append(ImpactedModel(
                    model_id=model.model_id,
                    model_name=model.name,
                    tier=model.tier,
                    domain=model.domain,
                    impact_level=impact_level,
                    reason=reason,
                ))

        # Sort by impact: high first, then by tier (lower tier = higher risk)
        impact_order = {"high": 0, "medium": 1, "low": 2}
        impacted.sort(key=lambda m: (impact_order.get(m.impact_level, 2), m.tier))

        score_impact = self._estimate_score_impact(change, impacted)
        actions = self._recommend_actions(change, impacted)

        days_until = None
        if change.effective_date:
            delta = change.effective_date - datetime.now(timezone.utc)
            days_until = max(0, delta.days)

        return ImpactAssessment(
            change=change,
            impacted_models=impacted,
            estimated_compliance_impact=score_impact,
            recommended_actions=actions,
            days_until_effective=days_until,
        )

    def _assess_model_impact(
        self,
        change: RegulatoryChange,
        model,
    ) -> Tuple[Optional[str], str]:
        """Determine if and how a model is impacted by the change.

        Returns (impact_level, reason) or (None, "") if not impacted.
        """
        # Check if model domain is in the affected domains
        domain_match = False
        if change.affected_domains:
            domain_match = model.domain.lower() in [
                d.lower() for d in change.affected_domains
            ]
        else:
            relevant_regs = _DOMAIN_REGULATION_MAP.get(model.domain.lower(), [])
            domain_match = change.regulation in relevant_regs

        if not domain_match:
            # Check keyword overlap with model description or data sources
            model_text = (
                f"{model.name} {model.description} {model.domain} "
                f"{' '.join(model.data_sources)}"
            ).lower()
            keyword_match = any(
                kw.lower() in model_text for kw in change.keywords
            )
            if not keyword_match:
                return None, ""

        # Determine impact level based on tier and change type
        if model.tier == 1:
            if change.change_type in ("new_requirement", "enforcement"):
                return "high", (
                    f"Tier 1 model in {model.domain} domain directly "
                    f"affected by {change.change_type}"
                )
            return "medium", (
                f"Tier 1 model may need review for {change.change_type}"
            )

        if model.tier == 2:
            if change.change_type in ("new_requirement", "enforcement"):
                return "medium", (
                    f"Tier 2 model in {model.domain} domain may require "
                    f"updates for {change.change_type}"
                )
            return "low", (
                f"Tier 2 model should be reviewed for {change.change_type}"
            )

        return "low", (
            f"Tier 3 model in {model.domain} domain. "
            f"Low-priority review recommended."
        )

    @staticmethod
    def _estimate_score_impact(
        change: RegulatoryChange,
        impacted: List[ImpactedModel],
    ) -> float:
        """Estimate the compliance score impact of this change."""
        if not impacted:
            return 0.0

        impact_points = {"high": -8.0, "medium": -3.0, "low": -1.0}
        total = sum(
            impact_points.get(m.impact_level, 0.0)
            for m in impacted
        )
        # Cap the negative impact
        return max(-30.0, total)

    @staticmethod
    def _recommend_actions(
        change: RegulatoryChange,
        impacted: List[ImpactedModel],
    ) -> List[str]:
        """Generate recommended actions for addressing the change."""
        actions: List[str] = []

        high_impact = [m for m in impacted if m.impact_level == "high"]
        if high_impact:
            model_names = ", ".join(m.model_name for m in high_impact[:3])
            actions.append(
                f"Immediately review high-impact models: {model_names}"
            )

        if change.change_type == "new_requirement":
            actions.append(
                "Conduct gap analysis against the new requirement for all "
                "affected models"
            )
            actions.append(
                "Update compliance engine configuration to include new checks"
            )

        if change.change_type == "enforcement":
            actions.append(
                "Escalate to legal counsel for enforcement risk assessment"
            )
            actions.append(
                "Document current compliance posture as pre-enforcement baseline"
            )

        if change.change_type == "deadline":
            if change.effective_date:
                actions.append(
                    f"Add deadline to regulatory calendar: "
                    f"{change.effective_date.strftime('%Y-%m-%d')}"
                )
            actions.append(
                "Assign remediation owners for each impacted model"
            )

        if change.change_type == "amendment":
            actions.append(
                "Review amendment text against current compliance documentation"
            )
            actions.append(
                "Schedule revalidation for affected Tier 1 models"
            )

        if not actions:
            actions.append(
                "Review regulatory change and assess applicability to model portfolio"
            )

        return actions
