"""
Examiner-Ready Package Generator.

Assembles a one-click regulatory examination bundle containing all
documentation, analysis results, and audit trails needed for:
    - OCC Model Risk Management examinations (SR 11-7)
    - CFPB Fair Lending examinations (ECOA / Reg B)
    - EU AI Act conformity assessments
    - State-level AI Act compliance reviews

The package organises outputs into examiner-familiar sections that map
to the OCC Comptroller's Handbook, FFIEC examination procedures, and
EU AI Act Annex IV documentation requirements.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


@dataclass
class ExaminerSection:
    """A section of the examiner package.

    Attributes:
        title: Section heading.
        category: Examination category (model_risk, fair_lending,
                  data_governance, ai_act, state_compliance).
        content: Structured content for this section.
        status: "complete", "partial", "missing".
        regulatory_refs: Which regulations this section satisfies.
    """
    title: str
    category: str
    content: Dict[str, Any] = field(default_factory=dict)
    status: str = "missing"
    regulatory_refs: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "category": self.category,
            "content": self.content,
            "status": self.status,
            "regulatory_refs": self.regulatory_refs,
        }


class ExaminerPackage:
    """Assembles an examiner-ready compliance package.

    Collects outputs from compliance engines, FairLens analysis,
    model cards, certifications, and data governance modules into
    a single structured package organised for regulatory examiners.

    Usage::

        pkg = ExaminerPackage(
            institution_name="Acme Bank",
            examination_type="fair_lending",
            prepared_by="Jane Smith, CCO",
        )

        # Add compliance results
        pkg.add_compliance_results(compliance_report.to_dict())

        # Add fairness analysis
        pkg.add_fairness_analysis(fairlens_report)

        # Add model inventory
        pkg.add_model_inventory(models)

        # Add certifications
        pkg.add_certifications(cert_tracker.to_dict())

        # Generate the package
        bundle = pkg.generate()
    """

    def __init__(
        self,
        institution_name: str = "",
        examination_type: str = "comprehensive",
        prepared_by: str = "",
    ) -> None:
        self.institution_name = institution_name
        self.examination_type = examination_type
        self.prepared_by = prepared_by
        self.sections: List[ExaminerSection] = []
        self.generated_at: datetime = datetime.now(timezone.utc)

    def add_section(self, section: ExaminerSection) -> None:
        """Add a section to the package."""
        self.sections.append(section)

    def add_compliance_results(
        self, report_dict: Dict[str, Any]
    ) -> None:
        """Add compliance engine results to the package."""
        results = report_dict.get("results", [])
        if not results and "overall_passed" in report_dict:
            results = [report_dict]

        for result in results:
            reg_name = result.get("regulation_name", result.get("regulation", ""))
            category = self._categorize_regulation(reg_name)

            self.sections.append(ExaminerSection(
                title=f"Compliance Assessment: {reg_name}",
                category=category,
                content={
                    "passed": result.get("passed", False),
                    "findings": result.get("findings", []),
                    "citations": result.get("citations", []),
                    "remediation": result.get("remediation_recommendations", []),
                    "summary": result.get("summary", {}),
                },
                status="complete" if result.get("findings") is not None else "missing",
                regulatory_refs=result.get("citations", []),
            ))

    def add_fairness_analysis(
        self, analysis: Dict[str, Any]
    ) -> None:
        """Add FairLens fairness analysis results."""
        self.sections.append(ExaminerSection(
            title="Algorithmic Fairness Analysis (FairLens)",
            category="fair_lending",
            content=analysis,
            status="complete" if analysis else "missing",
            regulatory_refs=[
                "12 CFR 1002.4(a)",
                "12 CFR 1002.6",
                "CFPB Circular 2023-03",
            ],
        ))

    def add_model_inventory(
        self, models: List[Dict[str, Any]]
    ) -> None:
        """Add model inventory for SR 11-7 §3 compliance."""
        self.sections.append(ExaminerSection(
            title="Model Inventory (SR 11-7 §3)",
            category="model_risk",
            content={
                "model_count": len(models),
                "models": models,
            },
            status="complete" if models else "missing",
            regulatory_refs=["SR 11-7 §3", "OCC 2011-12 §3"],
        ))

    def add_model_card(self, model_card: Dict[str, Any]) -> None:
        """Add a model card to the package."""
        name = model_card.get("model_details", {}).get("name", "Model")
        self.sections.append(ExaminerSection(
            title=f"Model Card: {name}",
            category="model_risk",
            content=model_card,
            status="complete",
            regulatory_refs=[
                "SR 11-7 §3",
                "EU AI Act Article 13 / Annex IV",
                "NIST AI RMF MAP 1.5",
            ],
        ))

    def add_certifications(
        self, cert_data: Dict[str, Any]
    ) -> None:
        """Add certification status to the package."""
        self.sections.append(ExaminerSection(
            title="Vendor Certifications & Attestations",
            category="data_governance",
            content=cert_data,
            status="complete" if cert_data.get("certifications") else "missing",
            regulatory_refs=[
                "OCC 2013-29",
                "Interagency Third-Party Guidance (2023)",
            ],
        ))

    def add_data_governance(
        self, governance_data: Dict[str, Any]
    ) -> None:
        """Add data governance information."""
        self.sections.append(ExaminerSection(
            title="Data Governance & Classification",
            category="data_governance",
            content=governance_data,
            status="complete" if governance_data else "missing",
            regulatory_refs=[
                "FFIEC IT Examination Handbook",
                "EU AI Act Article 10",
            ],
        ))

    def add_retention_report(
        self, retention_data: Dict[str, Any]
    ) -> None:
        """Add data retention policy report."""
        self.sections.append(ExaminerSection(
            title="Data Retention Policies",
            category="data_governance",
            content=retention_data,
            status="complete" if retention_data else "missing",
            regulatory_refs=[
                "12 CFR 1002.12(a)",
                "EU AI Act Article 12(2)",
                "EU AI Act Article 18(1)",
            ],
        ))

    def add_regulatory_calendar(
        self, calendar_data: Dict[str, Any]
    ) -> None:
        """Add regulatory calendar to the package."""
        self.sections.append(ExaminerSection(
            title="Regulatory Calendar & Upcoming Deadlines",
            category="data_governance",
            content=calendar_data,
            status="complete" if calendar_data else "missing",
            regulatory_refs=[],
        ))

    def _categorize_regulation(self, reg_name: str) -> str:
        """Map regulation name to examiner category."""
        lower = reg_name.lower()
        if "sr 11-7" in lower or "occ 2011" in lower:
            return "model_risk"
        elif "ecoa" in lower or "reg b" in lower or "1002" in lower:
            return "fair_lending"
        elif "eu ai" in lower:
            return "ai_act"
        elif "colorado" in lower or "nyc" in lower or "ll144" in lower:
            return "state_compliance"
        return "data_governance"

    @property
    def completeness_score(self) -> float:
        """Package completeness as a fraction (0.0-1.0)."""
        if not self.sections:
            return 0.0
        complete = sum(1 for s in self.sections if s.status == "complete")
        return complete / len(self.sections)

    @property
    def coverage_by_category(self) -> Dict[str, Dict[str, int]]:
        """Section counts by category and status."""
        coverage: Dict[str, Dict[str, int]] = {}
        for s in self.sections:
            cat = coverage.setdefault(s.category, {
                "complete": 0, "partial": 0, "missing": 0,
            })
            cat[s.status] = cat.get(s.status, 0) + 1
        return coverage

    # -- Required sections per examination type --------------------------

    _REQUIRED_SECTIONS: Dict[str, List[Dict[str, str]]] = {
        "fair_lending": [
            {"keyword": "fairness", "label": "Algorithmic Fairness Analysis"},
            {"keyword": "ecoa", "label": "ECOA Compliance Assessment"},
        ],
        "model_risk": [
            {"keyword": "sr 11-7", "label": "SR 11-7 Compliance Assessment"},
            {"keyword": "model card", "label": "Model Card Documentation"},
            {"keyword": "inventory", "label": "Model Inventory"},
        ],
        "comprehensive": [
            {"keyword": "fairness", "label": "Algorithmic Fairness Analysis"},
            {"keyword": "ecoa", "label": "ECOA Compliance Assessment"},
            {"keyword": "sr 11-7", "label": "SR 11-7 Compliance Assessment"},
            {"keyword": "model card", "label": "Model Card Documentation"},
        ],
        "ai_act": [
            {"keyword": "eu ai", "label": "EU AI Act Compliance Assessment"},
            {"keyword": "fairness", "label": "Algorithmic Fairness Analysis"},
        ],
        "state_compliance": [
            {"keyword": "colorado", "label": "Colorado AI Act Assessment"},
            {"keyword": "nyc", "label": "NYC LL144 Assessment"},
        ],
    }

    def validate_required_sections(self) -> Dict[str, Any]:
        """Validate that all required sections for the exam type are present.

        Returns a dict with ``complete`` (bool), ``present`` / ``missing``
        (lists of section labels), and ``warnings``.

        Bank examiners expect specific sections based on the examination
        type.  This method checks that the package has all required
        sections and flags any that are missing.
        """
        required = self._REQUIRED_SECTIONS.get(
            self.examination_type,
            self._REQUIRED_SECTIONS.get("comprehensive", []),
        )

        present: List[str] = []
        missing: List[str] = []
        warnings: List[str] = []

        for req in required:
            keyword = req["keyword"].lower()
            found = any(
                keyword in s.title.lower() and s.status == "complete"
                for s in self.sections
            )
            if found:
                present.append(req["label"])
            else:
                partial = any(
                    keyword in s.title.lower() and s.status == "partial"
                    for s in self.sections
                )
                if partial:
                    warnings.append(
                        f"{req['label']}: present but marked as partial"
                    )
                    present.append(req["label"])
                else:
                    missing.append(req["label"])

        complete = len(missing) == 0

        if not complete:
            warnings.append(
                f"Package is missing {len(missing)} required section(s) "
                f"for a '{self.examination_type}' examination"
            )

        return {
            "complete": complete,
            "examination_type": self.examination_type,
            "required_count": len(required),
            "present": present,
            "missing": missing,
            "warnings": warnings,
        }

    def generate(self) -> Dict[str, Any]:
        """Generate the complete examiner package."""
        sections_by_category: Dict[str, List[Dict[str, Any]]] = {}
        for s in self.sections:
            sections_by_category.setdefault(s.category, []).append(s.to_dict())

        all_refs: List[str] = []
        for s in self.sections:
            for ref in s.regulatory_refs:
                if ref not in all_refs:
                    all_refs.append(ref)

        validation = self.validate_required_sections()

        return {
            "package_metadata": {
                "institution_name": self.institution_name,
                "examination_type": self.examination_type,
                "prepared_by": self.prepared_by,
                "generated_at": self.generated_at.isoformat(),
                "completeness_score": round(self.completeness_score, 2),
            },
            "validation": validation,
            "coverage": self.coverage_by_category,
            "sections_by_category": sections_by_category,
            "all_sections": [s.to_dict() for s in self.sections],
            "regulatory_references": all_refs,
            "summary": {
                "total_sections": len(self.sections),
                "complete": sum(1 for s in self.sections if s.status == "complete"),
                "partial": sum(1 for s in self.sections if s.status == "partial"),
                "missing": sum(1 for s in self.sections if s.status == "missing"),
                "categories_covered": list(sections_by_category.keys()),
            },
        }
