"""
Persistence layer for HYDRA-32 DAG provenance.

Provides database storage for long-term audit trails with minimal performance impact.

Basic usage:
    from attestant import DAGTracker
    from attestant.persistence import create_storage

    # SQLite for testing
    storage = create_storage("./local.db")

    # S3 for production
    storage = create_storage("s3://my-bucket/provenance")

    # Run pipeline, then persist
    tracker = DAGTracker(pipeline_name="loan_scoring")
    # ... compute ...
    storage.connect()
    tracker.persist_to_storage(storage)
    storage.disconnect()

Reconstruct from database:
    from attestant.persistence import reconstruct_dag

    dag = reconstruct_dag(
        fingerprint=0x401B01,
        connection="sqlite:///provenance.db"
    )
    print(dag.has_protected)  # Cryptographic proof
"""

from .schema import init_database, get_schema_ddl
from .storage import PostgreSQLStorage, StorageBackend, StoredRowValue

def __getattr__(name):
    if name == "S3Storage":
        from .s3_storage import S3Storage
        return S3Storage
    if name == "DuckDBStorage":
        from .duckdb_storage import DuckDBStorage
        return DuckDBStorage
    if name == "HostedStorage":
        from .hosted_storage import HostedStorage
        return HostedStorage
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    # Setup
    'init_database',
    'get_schema_ddl',

    # Storage backends
    'PostgreSQLStorage',
    'StorageBackend',
    'StoredRowValue',
    'S3Storage',
    'DuckDBStorage',
    'HostedStorage',
]
