#!/usr/bin/env python3
import argparse
import gzip
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt

COLORS_2STATE = ["#FF6500", "#8BCA4C", "#C2E4BC", "#5DC9FA"]
COLORS_3STATE = ["#B3474B", "#E69F00", "#0072B2", "#CC79A7", "#FFB6EF", "#D55E00"]

def open_maybe_gzip(path):
  if path.endswith(".gz"):
    return gzip.open(path, "rt")
  return open(path, "rt")

def parse_args():
  p = argparse.ArgumentParser(description="Plot mean methylation state per cluster.")
  p.add_argument("-d", "--dsi_file", required=True, help="Input .dsi(.gz) file")
  p.add_argument("-c", "--cluster_file", required=True, help="Cluster TSV (chr pos cluster)")
  p.add_argument("-o", "--output", required=True, help="Output PNG filename")
  p.add_argument(
    "--states",
    "--num-classes",
    dest="num_classes",
    type=int,
    choices=[2, 3],
    default=2,
    help="DSI layout mode from pileup.py: 2 (4-state) or 3 (9-state). Default: 2",
  )
  p.add_argument("--svg", action="store_true", help="Also write SVG with same base name")
  return p.parse_args()

def load_clusters(path):
  clusters = {}
  with open(path, "r") as fh:
    for line in fh:
      if not line.strip():
        continue
      parts = line.rstrip("\n").split("\t")
      if len(parts) < 3:
        continue
      chrom, pos, cl = parts[0], parts[1], parts[2]
      try:
        cl = int(cl)
      except ValueError:
        continue
      clusters[(chrom, pos)] = cl
  return clusters

def main():
  args = parse_args()

  clusters = load_clusters(args.cluster_file)
  if not clusters:
    sys.stderr.write("No clusters found.\n")
    sys.exit(1)

  if args.num_classes == 2:
    feature_len = 4
    min_cols = 11
    labels = ["fully", "hemi_plus", "hemi_minus", "unmethylated"]
    colors = COLORS_2STATE
  else:
    feature_len = 6
    min_cols = 16
    labels = ["MM", "MU/UM", "UU", "HH", "HU/UH", "HM/MH"]
    colors = COLORS_3STATE

  sums = defaultdict(lambda: np.zeros(feature_len, dtype=float))
  counts = defaultdict(int)

  with open_maybe_gzip(args.dsi_file) as fh:
    for line in fh:
      if not line.strip():
        continue
      parts = line.rstrip("\n").split("\t")
      if len(parts) < min_cols:
        continue
      chrom, pos = parts[0], parts[1]
      key = (chrom, pos)
      if key not in clusters:
        continue

      try:
        total_cov = float(parts[3])
        if args.num_classes == 2:
          vals = np.array([float(parts[7]), float(parts[8]), float(parts[9]), float(parts[10])], dtype=float)
        else:
          mm = float(parts[7])
          mc = float(parts[8])
          cm = float(parts[9])
          cc = float(parts[10])
          hh = float(parts[11])
          hc = float(parts[12])
          ch = float(parts[13])
          mh = float(parts[14])
          hm = float(parts[15])
          vals = np.array([mm, mc + cm, cc, hh, hc + ch, mh + hm], dtype=float)
      except ValueError:
        continue

      if total_cov <= 0:
        continue

      vals = vals / total_cov
      cl = clusters[key]
      sums[cl] += vals
      counts[cl] += 1

  if not sums:
    sys.stderr.write("No matching CpGs between DSI and cluster file.\n")
    sys.exit(1)

  cluster_ids = sorted(sums.keys())
  means = np.vstack([sums[c] / counts[c] for c in cluster_ids])

  fig, ax = plt.subplots(figsize=(8, 5))
  x = np.arange(len(cluster_ids))

  bottom = np.zeros(len(cluster_ids))

  for i, label in enumerate(labels):
    ax.bar(x, means[:, i], bottom=bottom, color=colors[i], label=label)
    bottom += means[:, i]

  ax.set_xticks(x)
  ax.set_xticklabels([str(c) for c in cluster_ids])
  ax.set_xlabel("Cluster")
  ax.set_ylabel("Mean methylation (fraction)")
  ax.set_ylim(0, 1)
  ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1.0), borderaxespad=0.0, frameon=False)
  fig.tight_layout()

  fig.savefig(args.output, dpi=300)

  if args.svg:
    svg_path = Path(args.output).with_suffix(".svg")
    fig.savefig(svg_path)

if __name__ == "__main__":
  main()
