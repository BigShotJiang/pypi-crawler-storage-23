import torch
import torch.nn as nn

class HybridCNNTransformerModel(nn.Module):
    def __init__(
        self,
        input_channels,
        seq_len,
        num_classes,
        cnn_hidden=32,
        cnn_layers=2,
        transformer_layers=2,
        transformer_dim=64,
        transformer_heads=4,
        dropout=0.2
    ):
        super().__init__()
        # CNN part
        cnn_layers_list = []
        in_channels = input_channels
        for i in range(cnn_layers):
            cnn_layers_list.append(
                nn.Conv1d(in_channels, cnn_hidden, kernel_size=3, padding=1)
            )
            cnn_layers_list.append(nn.ReLU())
            cnn_layers_list.append(nn.BatchNorm1d(cnn_hidden))
            in_channels = cnn_hidden
        self.cnn = nn.Sequential(*cnn_layers_list)
        
        # Optional: a pooling layer (not strictly necessary if seq_len remains constant)
        # self.pool = nn.AdaptiveAvgPool1d(seq_len)

        # Transformer part with batch_first=True for warning-free and efficient training
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=cnn_hidden, 
            nhead=transformer_heads, 
            dim_feedforward=transformer_dim, 
            dropout=dropout,
            batch_first=True  # <--- important!
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=transformer_layers)
        
        # Classifier head
        self.head = nn.Sequential(
            nn.Flatten(),
            nn.Linear(seq_len * cnn_hidden, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, num_classes)
        )

    def forward(self, x):
        # x shape: (batch, channels, seq_len)
        x = self.cnn(x)
        # Transformer expects (batch, seq_len, features)
        x = x.permute(0, 2, 1)
        x = self.transformer(x)
        x = x.reshape(x.size(0), -1)  # flatten for linear head
        out = self.head(x)
        return out