from datetime import datetime
import os
import logging
import sys
from logging.handlers import QueueHandler, QueueListener
import pysam
import numpy as np
import time
import math
import multiprocessing as mp

# helper functions for encoding/parsing
_base_map = {"A": 0, "C": 1, "G": 2, "T": 3, "a": 0, "c": 1, "g": 2, "t": 3}


def encode_kmer_string(kmer):
    # returns numpy uint8 array of shape (L,)
    arr = np.zeros(len(kmer), dtype=np.uint8)
    for i, ch in enumerate(kmer):
        arr[i] = _base_map.get(ch, 4)  # unknown bases -> 4
    return arr


def parse_ipd_pw(s, length):
    # s expected as comma-separated string of floats; ensure length by resize if needed
    try:
        arr = np.fromstring(s, sep=",", dtype=np.float32)
    except Exception:
        arr = np.zeros(length, dtype=np.float32)
    if arr.size != length:
        arr = np.resize(arr, length)
    return arr


def extract_strand_from_id(cid):
    # try heuristics to extract '+' or '-' from id/cg_id
    try:
        third = str(cid).split("/")[-1]
        parts = third.split("_")
        if len(parts) >= 3 and parts[2] in ("+", "-"):
            return parts[2]
        if "|||" in str(cid):
            toks = str(cid).split("|||")
            for t in toks:
                if t in ("+", "-"):
                    return t
    except Exception:
        pass
    return "+"


def check_files_paths(input):
    if not os.path.exists(input):
        raise FileNotFoundError(f"Input file {input} does not exist.")
    

def has_all_required_tags(read, code2frames_arr):
    required_tags = ['fi', 'fp', 'ri', 'rp']
    missing = [tag for tag in required_tags if not read.has_tag(tag)] # completely missing tags
    empty = [tag for tag in required_tags if tag not in missing and len(np.array(read.get_tag(tag), dtype=int)) == 0] # tags there but empty (PacBio bug)
    if missing and empty:
        return missing, empty
    elif missing:
        return missing, []
    elif empty:
        return [], empty
    else:
        return [], []

def configure_worker_logger(log_level="ERROR", log_queue=None):
    """
    Configure a worker process logger to use a QueueHandler pointing to the main process log_queue.
    """
    if log_queue:
        queue_handler = QueueHandler(log_queue)
        root = logging.getLogger()
        root.handlers = []
        root.addHandler(queue_handler)
        level_map = {
            "OFF": logging.CRITICAL + 1,
            "ERROR": logging.ERROR,
            "WARN": logging.WARNING,
            "INFO": logging.INFO
        }
        root.setLevel(level_map[log_level])
        if log_level == "OFF":
            logging.disable(logging.CRITICAL)


def configure_main_logger(log_level="ERROR", log_file=None, log_queue=None):
    """
    Configure the root logger and set up a multiprocessing-safe QueueListener if log_queue is provided.
    """
    log_format = '%(asctime)s [%(levelname)s] %(message)s'
    level_map = {
        "OFF": logging.CRITICAL + 1,
        "ERROR": logging.ERROR,
        "WARN": logging.WARNING,
        "INFO": logging.INFO
    }
    level = level_map[log_level]
    handlers = [logging.StreamHandler(sys.stdout)] if not log_file else [logging.FileHandler(log_file)]
    if log_queue is not None:
        handler = handlers[0]
        listener = QueueListener(log_queue, handler)
        listener.start()
        # Set up root logger only with handler for QueueListener
        logging.basicConfig(handlers=[handler], level=level, format=log_format, force=True)
        return listener
    else:
        logging.basicConfig(level=level, format=log_format, handlers=handlers, force=True)
        if log_level == "OFF":
            logging.disable(logging.CRITICAL)
        return None

def print_process_info(message, log_level):
    """
    Always prints general process info to the shell unless log_level is OFF.
    """
    if log_level == "OFF":
        return
    now = time.strftime("%Y-%m-%d %H:%M:%S,%f")[:-3]
    print(f"{now} [INFO] {message}", file=sys.stdout, flush=True)  


def get_read_offsets(bam_path, chunk_size):
    offsets = []
    with pysam.AlignmentFile(bam_path, "rb") as bam:
        count = 0
        offsets.append(bam.tell())
        for read in bam:
            count += 1
            if count % chunk_size == 0:
                offsets.append(bam.tell())
    return offsets


def codecv1_to_frame2():
    code2frames = [0] * 256
    for i in range(0, 64):
        code2frames[i] = i

    frames = []
    for frame in range(64, 190 + 1, 2):
        frames.append(frame)
    for i in range(64, 128):
        code2frames[i] = frames[i - 64]

    frames = []
    for frame in range(192, 444 + 1, 4):
        frames.append(frame)
    for i in range(128, 192):
        code2frames[i] = frames[i - 128]

    frames = []
    for frame in range(448, 952 + 1, 8):
        frames.append(frame)
    for i in range(192, 256):
        code2frames[i] = frames[i - 192]

    return code2frames

code2frames = codecv1_to_frame2()



def get_total_reads(bam_path):
    with pysam.AlignmentFile(bam_path, "rb") as bam:
        return bam.count(until_eof=True)
    

def calculate_optimal_chunk_size(bam_path, threads, multiplier=4, log_level="ERROR"):
    total_reads = get_total_reads(bam_path)
    num_chunks = threads * multiplier
    chunk_size = math.ceil(total_reads / num_chunks)
    msg = f"Total reads: {total_reads}, Threads: {threads}, automatic chunks: {num_chunks}, Chunk size: {chunk_size}"
    # print_process_info(msg, log_level)
    logging.info(msg)
    return chunk_size

def zscore_normalization(signal):
    s_mean, s_std = np.mean(signal), np.std(signal)
    if s_std == 0.0:
        norm_signals = [0.] * len(signal)
    else:
        norm_signals = (signal - s_mean) / s_std
    return np.around(norm_signals, decimals=6)

def complement(seq):
    complement = {'A': 'T', 'C': 'G', 'G': 'C', 'T': 'A', 'N': 'N'}
    return ''.join(complement[base] for base in seq)


def extract_read_features(read, upstream_nt, downstream_nt, motif, code2frames_arr, synthetic_flip=False):
    """
    Extracts features from a single read.

    Returns:
        features (list)
        skipped_cpgs (int)
        low_value_reads_info (list of tuples): [(read_id, fn_values, rn_values)] for fn or rn < 5
        diff_reads_info (list of tuples): [(read_id, diff, fn_values, rn_values)] for |fn - rn| > 1
    """
    read_id = read.query_name
    chr_name = read.reference_name if not read.is_unmapped else 'Unmapped'
    strand = '-' if read.is_reverse else '+'

    features = []
    skipped_cpgs = 0
    low_value_reads_info = []
    diff_reads_info = []

    try:
        # Extract and decode tags
        fi_values = np.array(read.get_tag("fi"), dtype=int)
        fp_values = np.array(read.get_tag("fp"), dtype=int)
        ri_values = np.array(read.get_tag("ri"), dtype=int)
        rp_values = np.array(read.get_tag("rp"), dtype=int)
        fi_values_0 = code2frames_arr[fi_values]
        fp_values_0 = code2frames_arr[fp_values]
        ri_values_0 = code2frames_arr[ri_values]
        rp_values_0 = code2frames_arr[rp_values]

        fn_values = read.get_tag("fn")
        rn_values = read.get_tag("rn")
        diff = abs(fn_values - rn_values)

        # # Rule 1: Skip low fn/rn values (low-confidence kinetics)
        # if fn_values < 5 or rn_values < 5:
        #     low_value_reads_info.append((read_id, fn_values, rn_values))
        #     logging.warning(f"{read_id}: skipped due to fn or rn < 5 (fn={fn_values}, rn={rn_values}).")
        #     return [], 0, low_value_reads_info, diff_reads_info

        # # Rule 2: Skip reads with npass difference greater a certain threshold (1 is the maximal diff that can be true)
        # max_npass_diff_allowed = 1
        # if diff > max_npass_diff_allowed:
        #     diff_reads_info.append((read_id, diff, fn_values, rn_values))
        #     logging.warning(f"{read_id}: skipped due to fn/rn difference > {max_npass_diff_allowed} (fn={fn_values}, rn={rn_values}).")
        #     return [], 0, low_value_reads_info, diff_reads_info

        if len(fi_values_0) == 0 or len(fp_values_0) == 0 or len(ri_values_0) == 0 or len(rp_values_0) == 0:
            logging.warning(f"{read_id}: Empty kinetic tag arrays after decoding.")
            return [], 0, low_value_reads_info, diff_reads_info

        # Normalize
        N_fi_values = zscore_normalization(fi_values_0)
        N_fp_values = zscore_normalization(fp_values_0)
        N_ri_values = zscore_normalization(ri_values_0)
        N_rp_values = zscore_normalization(rp_values_0)

    except Exception as e:
        logging.warning(f"{read_id}: Exception during tag decoding: {e}")
        return [], 0, low_value_reads_info, diff_reads_info

    # Process sequence
    sequence = read.get_forward_sequence()
    seq_len = len(sequence)
    motif_length = len(motif)
    search_len = seq_len - motif_length + 1

    # test if the the number of bases equals the number of kinetic values
    # If not, there is a problem, probably with adapter removal
    if seq_len != len(N_fi_values):
        logging.warning(f"{read_id}: number of bases not equal to number of kinetic values stored in fi")
        return [], skipped_cpgs, low_value_reads_info, diff_reads_info
    
    if seq_len != len(N_fp_values):
        logging.warning(f"{read_id}: number of bases not equal to number of kinetic values stored in fp")
        return [], skipped_cpgs, low_value_reads_info, diff_reads_info

    if seq_len != len(N_ri_values):
        logging.warning(f"{read_id}: number of bases not equal to number of kinetic values stored in ri")
        return [], skipped_cpgs, low_value_reads_info, diff_reads_info

    if seq_len != len(N_rp_values):
        logging.warning(f"{read_id}: number of bases not equal to number of kinetic values stored in rp")
        return [], skipped_cpgs, low_value_reads_info, diff_reads_info

    # Swith for synthetically flipping the read (for checking hemimethylation assymetries)
    # flipping is achieved by reverse complementing the sequence and swapping forward/reverse kinetics
    # (imagine rotating the circular molecule in the sequencer by 180 degrees)
    if synthetic_flip:
        sequence = complement(sequence)[::-1]
        N_fi_values, N_ri_values = N_ri_values, N_fi_values
        N_fp_values, N_rp_values = N_rp_values, N_fp_values

    def build_feature(i):
        # forward strand indices
        fwd_start_idx = i - upstream_nt
        fwd_end_idx = i + downstream_nt + 1    # end-exclusive

        # When taking the reverse kmer from the forward sequence, the "direction" of the CpG dyad is reversed (C after G)
        # -> the slicing end index must use the upstream_nt -> then: reverse complement
        # For the reverse kinetics, we will use negative indexing -> end_index ends up as the left border
        # but the "direction" of the CpG dyad is forward (G after C) -> slicing end_index must also use the upstream_nt
        rev_start_idx = i + 1 - downstream_nt    # C on the minus-strand is shifted by 1 base pos
        rev_end_idx = i + 1 + upstream_nt + 1    # C on the minus-strand is shifted by 1 base pos; end-exclusive


        # skip CpGs dyads with kinetics not covered by the read
        if fwd_start_idx < 0 or fwd_end_idx > len(sequence):
            return []    
        elif rev_start_idx < 0 or rev_end_idx > len(sequence):
            return []        
        
        fwd_kmer = sequence[fwd_start_idx:fwd_end_idx]

        # Forward strand kinetics: same orientation as SEQ
        fi_vals = N_fi_values[fwd_start_idx:fwd_end_idx]
        fp_vals = N_fp_values[fwd_start_idx:fwd_end_idx]
        fi = ",".join(map(str, fi_vals))
        fp = ",".join(map(str, fp_vals))

        # Build reverse-complement kmer (polymerase direction on the opposite strand).
        rev_kmer = complement(sequence[rev_start_idx:rev_end_idx])[::-1]

        # reverse strand kinetics (stored last to first)
        L = len(N_ri_values)
        if rev_end_idx > L:
            return []
        idx = np.arange(rev_start_idx, rev_end_idx, dtype=int)[::-1]   # reversing -> [-end:-start]
        ri_vals = N_ri_values[-(idx + 1)]  # +1 because negative indexing starts with -1, not with 0
        rp_vals = N_rp_values[-(idx + 1)]

        ri = ",".join(map(str, ri_vals))
        rp = ",".join(map(str, rp_vals))

        return [
            [read_id, chr_name, strand, 'fwd', i, fwd_kmer, fi, fp, str(fn_values)],
            [read_id, chr_name, strand, 'rev', i, rev_kmer, ri, rp, str(rn_values)]
        ]

    for i in range(search_len):
        if sequence[i:i + motif_length] == motif:
            feature = build_feature(i)
            if feature:
                features.extend(feature)
            else:
                skipped_cpgs += 1

    return features, skipped_cpgs, low_value_reads_info, diff_reads_info


def get_features_from_reads(reads, upstream_nt, downstream_nt, motif, ndiff=0, synthetic_flip=False):
    code2frames_arr = np.array(code2frames)
    all_features = []
    skipped_reads = 0
    skipped_cpgs = 0
    missing_reads = []
    low_value_reads_info = []
    diff_reads_info = []
    empty_reads = []
    for read in reads:
        missing, empty = has_all_required_tags(read, code2frames_arr)
        if missing:
            missing_reads.append(read.query_name)
        if empty:
            empty_reads.append(read.query_name)
        if missing or empty:
            skipped_reads += 1
            continue
        features, cpgs, low_value_reads_info, diff_reads_info = extract_read_features(
            read,
            upstream_nt,
            downstream_nt,
            motif,
            code2frames_arr,
            synthetic_flip=synthetic_flip,
        )
        all_features.extend(features)
        skipped_cpgs += cpgs
    return all_features, skipped_reads, skipped_cpgs, missing_reads, empty_reads,low_value_reads_info, diff_reads_info




##############
def configure_main_logger(log_level="ERROR", log_file=None, log_queue=None):
    """
    Configure the root logger and set up a multiprocessing-safe QueueListener if log_queue is provided.
    """
    log_format = '%(asctime)s [%(levelname)s] %(message)s'
    level_map = {
        "OFF": logging.CRITICAL + 1,
        "ERROR": logging.ERROR,
        "WARN": logging.WARNING,
        "INFO": logging.INFO
    }
    level = level_map[log_level]
    handlers = [logging.StreamHandler(sys.stdout)] if not log_file else [logging.FileHandler(log_file)]
    if log_queue is not None:
        handler = handlers[0]
        listener = QueueListener(log_queue, handler)
        listener.start()
        # Set up root logger only with handler for QueueListener
        logging.basicConfig(handlers=[handler], level=level, format=log_format, force=True)
        return listener
    else:
        logging.basicConfig(level=level, format=log_format, handlers=handlers, force=True)
        if log_level == "OFF":
            logging.disable(logging.CRITICAL)
        return None
    
def calculate_optimal_chunk_size(bam_path, threads, multiplier=4, log_level="ERROR"):
    total_reads = get_total_reads(bam_path)
    num_chunks = threads * multiplier
    chunk_size = math.ceil(total_reads / num_chunks)
    msg = f"Total reads: {total_reads}, Threads: {threads}, automatic chunks: {num_chunks}, Chunk size: {chunk_size}"
    print_process_info(msg, log_level)
    logging.info(msg)
    return chunk_size

def get_read_offsets(bam_path, chunk_size):
    offsets = []
    with pysam.AlignmentFile(bam_path, "rb", check_sq=False) as bam:
        count = 0
        offsets.append(bam.tell())
        for read in bam:
            count += 1
            if count % chunk_size == 0:
                offsets.append(bam.tell())
    return offsets


def configure_worker_logger(log_level="ERROR", log_queue=None):
    """
    Configure a worker process logger to use a QueueHandler pointing to the main process log_queue.
    """
    if log_queue:
        queue_handler = QueueHandler(log_queue)
        root = logging.getLogger()
        root.handlers = []
        root.addHandler(queue_handler)
        level_map = {
            "OFF": logging.CRITICAL + 1,
            "ERROR": logging.ERROR,
            "WARN": logging.WARNING,
            "INFO": logging.INFO
        }
        root.setLevel(level_map[log_level])
        if log_level == "OFF":
            logging.disable(logging.CRITICAL)
