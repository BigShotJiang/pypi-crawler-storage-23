import os
import sys
import argparse
import json
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn import metrics
from tqdm import tqdm
import numpy as np
from .dataloader import ArrayDataset
from .hybrid_model import HybridCNNTransformerModel
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap


def parse_args():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description="Evaluate Hybrid CNN+Transformer model on test dataset.")

    parser.add_argument("--test_path", type=str, required=True,
                        help="Path to the test dataset directory containing .npz files.")
    parser.add_argument("--model_path", type=str, required=True,
                        help="Path to the trained model directory.")
    parser.add_argument("--model_file", type=str, default="best_model.pt",
                        help="Model file name (default: best_model.pt).")
    parser.add_argument("--datasets", type=str, default=["c", "mdC"],
                        help="Dataset labels to evaluate (default: c mdC).")      
    parser.add_argument("--label_map", type=str, default='{"c":0,"mdC":1}',
                        help="JSON mapping label->int (quote it on the shell).")
    parser.add_argument("--batch_size", type=int, default=200,
                        help="Batch size for DataLoader (default: 200).")
    parser.add_argument("--num_workers", type=int, default=0,
                        help="Number of workers for DataLoader (default: 0).")
    parser.add_argument("--out_file", type=str, default="confusion_matrix.svg",
                        help="Output filename for confusion matrix plot.")
    parser.add_argument("--col_min", type=str, default="#FFFFFF",
                        help="Minimum color for confusion matrix (default: #FFFFFF).")
    parser.add_argument("--col_max", type=str, default="#FFC000",
                        help="Maximum color for confusion matrix (default: #FFC000).")

    parser.add_argument("--cnn_hidden", type=int, default=128)
    parser.add_argument("--cnn_layers", type=int, default=4)
    parser.add_argument("--transformer_layers", type=int, default=6)
    parser.add_argument("--transformer_dim", type=int, default=256)
    parser.add_argument("--transformer_heads", type=int, default=8)
    parser.add_argument("--dropout", type=float, default=0.2)
    parser.add_argument("--seq_len", type=int, default=None,
                        help="Sequence length (default: inferred from data).")
    parser.add_argument("--input_channels", type=int, default=3,
                        help="Number of input channels (default: 3).")
    parser.add_argument("--num_classes", type=int, default=2,
                        help="Number of output classes (default: 2).")

    return parser.parse_args()


def load_npz_arrays(npz_path):
    data = np.load(npz_path, allow_pickle=True)
    ek = data["encode_kmer"]
    ipd = data["ipd"]
    pw = data["pw"]
    lab = data["label"]
    return ek, ipd, pw, lab


def gather_files_from_input_folder(folder_path):
    if not os.path.isdir(folder_path):
        raise ValueError(f"Input path is not a directory: {folder_path}")
    files = sorted([os.path.join(folder_path, f) for f in os.listdir(folder_path) if f.endswith(".npz")])
    return files


def parse_label_map(label_map_str):
    if label_map_str is None:
        return None
    lm = json.loads(label_map_str)
    if not isinstance(lm, dict):
        raise ValueError("label_map JSON must be an object/dict")
    return {str(k): int(v) for k, v in lm.items()}


def main():
    args = parse_args()

    # ---------------- GPU Check ----------------
    print("Is GPU available?:", torch.cuda.is_available())
    print("Device count:", torch.cuda.device_count())
    if torch.cuda.is_available():
        print("Using GPU:", torch.cuda.get_device_name(0), flush=True)
    else:
        print("No GPU available. Using CPU.", flush=True)

    # ---------------- Load Dataset ----------------
    print("Loading the data...")
    npz_files = gather_files_from_input_folder(args.test_path)
    if len(npz_files) == 0:
        print(f"No NPZ files found in input directory: {args.test_path}", file=sys.stderr)
        sys.exit(1)

    encode_kmer_list = []
    ipd_list = []
    pw_list = []
    labels_list = []

    for f in npz_files:
        ek, ipd, pw, lab = load_npz_arrays(f)
        ek = np.asarray(ek)
        ipd = np.asarray(ipd)
        pw = np.asarray(pw)
        lab = np.asarray(lab)
        if ek.ndim != 2 or ipd.ndim != 2 or pw.ndim != 2:
            print(f"File {f} does not contain 2D arrays for encode_kmer/ipd/pw.", file=sys.stderr)
            sys.exit(1)
        if lab.size == 0:
            print(f"File {f} has empty 'label' array.", file=sys.stderr)
            sys.exit(1)
        file_label = lab.flat[0]
        num_samples = ek.shape[0]
        labels_for_file = np.array([file_label] * num_samples, dtype=object)

        encode_kmer_list.append(ek)
        ipd_list.append(ipd)
        pw_list.append(pw)
        labels_list.append(labels_for_file)

    encode_kmer = np.concatenate(encode_kmer_list, axis=0)
    ipd = np.concatenate(ipd_list, axis=0)
    pw = np.concatenate(pw_list, axis=0)
    labels = np.concatenate(labels_list, axis=0)

    label_map = parse_label_map(args.label_map)
    if label_map is not None:
        labels_mapped = np.array([label_map[str(l)] for l in labels], dtype=int)
    else:
        unique_labels = sorted(set(labels.tolist()))
        label_map = {l: i for i, l in enumerate(unique_labels)}
        labels_mapped = np.array([label_map[l] for l in labels], dtype=int)

    test_dataset = ArrayDataset(encode_kmer, ipd, pw, labels_mapped)
    loader = DataLoader(
        test_dataset,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        pin_memory=True
    )
    print("Data loaded. Number of batches:", len(loader))

    # ---------------- Load Model ----------------
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    num_classes = args.num_classes
    seq_len = args.seq_len if args.seq_len is not None else encode_kmer.shape[1]

    model = HybridCNNTransformerModel(
        input_channels=args.input_channels,
        seq_len=seq_len,
        num_classes=num_classes,
        cnn_hidden=args.cnn_hidden,
        cnn_layers=args.cnn_layers,
        transformer_layers=args.transformer_layers,
        transformer_dim=args.transformer_dim,
        transformer_heads=args.transformer_heads,
        dropout=args.dropout
    )
    model_ckpt = torch.load(os.path.join(args.model_path, args.model_file), torch.device("cpu"))
    model.load_state_dict(model_ckpt)
    model = model.to(device)
    model.eval()

    # ---------------- Evaluation ----------------
    v_label_total, v_pred_total = [], []

    with torch.no_grad():
        for ek, ipd, pw, label in tqdm(loader, desc="Processing Batches", total=len(loader)):
            features = torch.stack([ek, ipd, pw], dim=1).to(device, non_blocking=True)
            y = label.to(device, non_blocking=True)
            logits = model(features)
            preds = logits.argmax(dim=1)
            v_label_total.extend(y.cpu().numpy())
            v_pred_total.extend(preds.cpu().numpy())

    print("len(v_pred_total):", len(v_pred_total))
    print("len(v_label_total):", len(v_label_total))

    # ---------------- Metrics ----------------
    acc = metrics.accuracy_score(v_label_total, v_pred_total)
    prec = metrics.precision_score(v_label_total, v_pred_total, average="macro", zero_division=0)
    rec = metrics.recall_score(v_label_total, v_pred_total, average="macro", zero_division=0)

    print(f"Accuracy:  {acc:.4f}")
    print(f"Precision: {prec:.4f}")
    print(f"Recall:    {rec:.4f}")

    # ---------------- Confusion Matrix ----------------
    try:
        dataset_labels = json.loads(args.datasets) if args.datasets else None
    except json.JSONDecodeError as exc:
        raise ValueError(f"Could not parse --datasets JSON list: {exc}") from exc

    if dataset_labels is None and label_map is not None:
        dataset_labels = [str(k) for k, _ in sorted(label_map.items(), key=lambda kv: kv[1])]

    label_order = sorted(set(v_label_total))
    if dataset_labels is None:
        dataset_labels = [str(l) for l in label_order]
    if len(dataset_labels) != len(label_order):
        dataset_labels = [str(l) for l in label_order]

    c = metrics.confusion_matrix(v_label_total, v_pred_total, labels=label_order)
    with np.errstate(divide="ignore", invalid="ignore"):
        c_normalized = c.astype("float") / c.sum(axis=1)[:, np.newaxis]
        c_normalized = np.nan_to_num(c_normalized)
    c_percent = c_normalized * 100.0
    df_cm = pd.DataFrame(
        c_percent, index=dataset_labels, columns=dataset_labels
    )

    plt.rcParams["font.size"] = 14
    cmap = LinearSegmentedColormap.from_list("user_min_max", [args.col_min, args.col_max])
    plt.figure(figsize=(6, 5))
    sns.heatmap(
        df_cm,
        annot=True,
        annot_kws={"size": 16},
        fmt=".1f",
        linewidths=0.5,
        cmap=cmap,
        vmin=0,
        vmax=100,
        cbar=True,
        xticklabels=dataset_labels,
        yticklabels=dataset_labels,
    )
    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")
    plt.title("Confusion Matrix (%)")
    plt.savefig(args.out_file, dpi=800, format="svg")
    print(f"Confusion matrix saved to {args.out_file}")

if __name__ == "__main__":
    main()
