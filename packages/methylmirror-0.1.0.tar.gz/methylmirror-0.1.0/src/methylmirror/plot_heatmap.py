# the script can be run with the following minimal command:
# python plot_heatmap_1.py /path/to/bamfile.bam NC_000021.9:34614918-34615347

# Or with optional arguments:
# python plot_heatmap_1.py /path/to/bamfile.bam NC_000021.9:34614918-34615347 \
#   --output_path /path/to/output.png \
#   --color_scheme_3 "#E69F00,#56B4E9,#009E73,#F0E442,#0072B2,#CC79A7" \
#   --min_percentage 0.2 \
#   --threshold 150 \
#   --show_readnames
#   --log_level debug

import argparse
import logging
import sys

import pysam
import numpy as np

import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from scipy.cluster.hierarchy import linkage, leaves_list  # for hierarchical clustering of the heatmap rows


def configure_logging(log_level="info"):
    if log_level == "off":
        logging.disable(logging.CRITICAL)
        return
    level_map = {
        "critical": logging.CRITICAL,
        "error": logging.ERROR,
        "warning": logging.WARNING,
        "info": logging.INFO,
        "debug": logging.DEBUG,
    }
    logging.basicConfig(
        level=level_map[log_level], format="%(asctime)s - %(levelname)s - %(message)s"
    )


"""
Helper functions to generate a CpG methylation status array from a read, originally copied from
modBam2entropyBam.py but modified to exclude CpG sites that are not present in the MM tag.
"""


def _get_cytosine_positions(sequence):
    """self-explanatory"""
    return np.array([i for i, base in enumerate(sequence) if base == "C"])


def _get_guanine_positions(sequence):
    """self-explanatory"""
    return np.array([i for i, base in enumerate(sequence) if base == "G"])


def _get_CpG_pos(cytosine_positions, guanine_positions):
    """looks for CpG positions in the read"""
    CpG_positions = cytosine_positions[
        np.isin(cytosine_positions + 1, guanine_positions)
    ]
    return CpG_positions


def _parse_delta_mm_string(mm_string):
    if not mm_string or "," not in mm_string:
        return np.array([], dtype=int)
    vals = [int(v) for v in mm_string.split(",")[1:] if v != ""]
    idx = np.cumsum(vals) + np.arange(len(vals))
    return np.array(idx, dtype=int)


def _get_indices_from_MM(read):
    """
    Reads the MM tag and converts it to the indices of cytosines (plus strand) or guanines
    (minus strand) with methylation information. Returns strand-specific numpy arrays.
    """
    if read.has_tag("MM") or read.has_tag("Mm"):
        MM_tag = read.get_tag("MM") if read.has_tag("MM") else read.get_tag("Mm")
        strand_strings = [s.strip() for s in MM_tag.split(";") if s.strip() != ""]
        plus_m = plus_h = minus_m = minus_h = None
        include_h = False
        for s in strand_strings:
            if s.startswith("C+m"):
                plus_m = s
            elif s.startswith("C+h"):
                plus_h = s
                include_h = True
            elif s.startswith("G-m"):
                minus_m = s
            elif s.startswith("G-h"):
                minus_h = s
                include_h = True
        plus_m_idxs = _parse_delta_mm_string(plus_m)
        plus_h_idxs = _parse_delta_mm_string(plus_h)
        minus_m_idxs = _parse_delta_mm_string(minus_m)
        minus_h_idxs = _parse_delta_mm_string(minus_h)
        return plus_m_idxs, plus_h_idxs, minus_m_idxs, minus_h_idxs, include_h
    return (
        np.array([], dtype=int),
        np.array([], dtype=int),
        np.array([], dtype=int),
        np.array([], dtype=int),
        False,
    )


def _get_predictions_from_ML(read, n_c_m, n_c_h, n_g_m, n_g_h, include_h):
    """
    Reads the ML tag, splits it into plus and minus strand and returns them as numpy arrays.
    """
    if (read.has_tag("MM") or read.has_tag("Mm")) and (
        read.has_tag("ML") or read.has_tag("Ml")
    ):
        ml_tag = read.get_tag("ML") if read.has_tag("ML") else read.get_tag("Ml")
        ml_tag = np.array(ml_tag)
        if include_h:
            expected = n_c_m + n_c_h + n_g_m + n_g_h
            if len(ml_tag) != expected:
                raise ValueError(
                    "Number of ML entries does not match MM tag entries"
                )
            plus_m = ml_tag[0:n_c_m]
            plus_h = ml_tag[n_c_m : n_c_m + n_c_h]
            minus_m = ml_tag[n_c_m + n_c_h : n_c_m + n_c_h + n_g_m]
            minus_h = ml_tag[n_c_m + n_c_h + n_g_m : expected]
        else:
            expected = n_c_m + n_g_m
            if len(ml_tag) != expected:
                raise ValueError(
                    "Number of ML entries does not match MM tag entries"
                )
            plus_m = ml_tag[0:n_c_m]
            plus_h = np.array([], dtype=int)
            minus_m = ml_tag[n_c_m : n_c_m + n_g_m]
            minus_h = np.array([], dtype=int)
        return plus_m, plus_h, minus_m, minus_h
    return (
        np.array([], dtype=int),
        np.array([], dtype=int),
        np.array([], dtype=int),
        np.array([], dtype=int),
    )


def _positions_above_cutoff(
    c_m_pos,
    c_h_pos,
    g_m_pos,
    g_h_pos,
    ml_plus_m,
    ml_plus_h,
    ml_minus_m,
    ml_minus_h,
    cutoff,
):
    """
    Takes only the CpG positions with a modification prediction greater than the cutoff specified (0-255).
    """
    plus_m_above = c_m_pos[ml_plus_m > cutoff] if ml_plus_m.size > 0 else np.array([], dtype=int)
    plus_h_above = c_h_pos[ml_plus_h > cutoff] if ml_plus_h.size > 0 else np.array([], dtype=int)
    minus_m_above = g_m_pos[ml_minus_m > cutoff] if ml_minus_m.size > 0 else np.array([], dtype=int)
    minus_h_above = g_h_pos[ml_minus_h > cutoff] if ml_minus_h.size > 0 else np.array([], dtype=int)
    return plus_m_above, plus_h_above, minus_m_above, minus_h_above


def generate_CpG_mod_status_array(read, cutoff):
    """
    Generates a numpy array storing the modification status of all CpG positions in the read.
    Returns 6 categories derived from plus/minus status:
    0: MM, 1: MC/CM, 2: CC, 3: HH, 4: HC/CH, 5: MH/HM
    """
    # After mapping, the sequence is in the orientation of the reference genome but the methylation
    # status tags are in the orientation of the original read.
    sequence = read.get_forward_sequence()
    if not sequence:  # If the read has no sequence, skip it. Adapted, do not change in modBam2entropyBam.py
        logging.warning(f"Read {read.query_name} has no sequence")
        return np.array([]), np.array([])

    # When the code is to be used only for Methylmirror modBam files, the following blocks could be
    # made much simpler by just assuming that every encoded position has plus and minus strand
    # information and is a CpG.
    cytosine_positions = _get_cytosine_positions(sequence)

    cytosine_positions = _get_cytosine_positions(sequence)  # get the positions of cytosines, guanines and CpG sites in the sequence
    guanine_positions = _get_guanine_positions(sequence)
    all_CpG_pos = _get_CpG_pos(cytosine_positions, guanine_positions)

    mm_c_m_idx, mm_c_h_idx, mm_g_m_idx, mm_g_h_idx, include_h = _get_indices_from_MM(
        read
    )
    if (
        mm_c_m_idx.size == 0
        and mm_g_m_idx.size == 0
        and mm_c_h_idx.size == 0
        and mm_g_h_idx.size == 0
    ):
        return np.array([]), np.array([])
    ml_plus_m, ml_plus_h, ml_minus_m, ml_minus_h = _get_predictions_from_ML(
        read,
        len(mm_c_m_idx),
        len(mm_c_h_idx),
        len(mm_g_m_idx),
        len(mm_g_h_idx),
        include_h,
    )

    c_m_pos = cytosine_positions[mm_c_m_idx] if len(mm_c_m_idx) else np.array([], dtype=int)
    c_h_pos = cytosine_positions[mm_c_h_idx] if len(mm_c_h_idx) else np.array([], dtype=int)
    g_m_pos = guanine_positions[mm_g_m_idx] if len(mm_g_m_idx) else np.array([], dtype=int)
    g_h_pos = guanine_positions[mm_g_h_idx] if len(mm_g_h_idx) else np.array([], dtype=int)
    all_pos_in_MM = (
        np.concatenate([c_m_pos, c_h_pos, g_m_pos - 1, g_h_pos - 1])
        if (c_m_pos.size + c_h_pos.size + g_m_pos.size + g_h_pos.size) > 0
        else np.array([], dtype=int)
    )
    boolean_cpgs_in_MM = np.isin(
        all_CpG_pos, all_pos_in_MM
    )  # create a boolean array to select only the CpG positions that are present in the MM tag
    CpGs_in_MM_tag = all_CpG_pos[
        boolean_cpgs_in_MM
    ]  # Get the positions of CpGs in MM tag. This will be used to create the overall array storing the hemimethylation information-

    # from the positions stored in the MM tag, select only those that have a prediction above the cutoff
    plus_m_above, plus_h_above, minus_m_above, minus_h_above = _positions_above_cutoff(
        c_m_pos,
        c_h_pos,
        g_m_pos,
        g_h_pos,
        ml_plus_m,
        ml_plus_h,
        ml_minus_m,
        ml_minus_h,
        cutoff,
    )

    if read.is_reverse:
        plus_m_above, minus_m_above = minus_m_above, plus_m_above
        plus_h_above, minus_h_above = minus_h_above, plus_h_above

    plus_h_bool = np.isin(CpGs_in_MM_tag, plus_h_above)
    plus_m_bool = np.isin(CpGs_in_MM_tag, plus_m_above)
    minus_h_bool = np.isin(CpGs_in_MM_tag, minus_h_above - 1)
    minus_m_bool = np.isin(CpGs_in_MM_tag, minus_m_above - 1)

    plus_status = np.where(plus_h_bool, 2, np.where(plus_m_bool, 1, 0))
    minus_status = np.where(minus_h_bool, 2, np.where(minus_m_bool, 1, 0))

    category = np.full(plus_status.shape, -1, dtype=int)
    category[(plus_status == 1) & (minus_status == 1)] = 0  # MM
    category[((plus_status == 1) & (minus_status == 0)) | ((plus_status == 0) & (minus_status == 1))] = 1  # MC/CM
    category[(plus_status == 0) & (minus_status == 0)] = 2  # CC
    category[(plus_status == 2) & (minus_status == 2)] = 3  # HH
    category[((plus_status == 2) & (minus_status == 0)) | ((plus_status == 0) & (minus_status == 2))] = 4  # HC/CH
    category[((plus_status == 1) & (minus_status == 2)) | ((plus_status == 2) & (minus_status == 1))] = 5  # MH/HM
    return category, CpGs_in_MM_tag


def generate_CpG_meth_status_array_2state(read, cutoff):
    """
    Generates a numpy array storing the hemimethylation status of all CpG positions in the read.
    0: unmethylated, 1: hemimethylated on (+), 2: hemimethylated on (-), 3: fully methylated
    """
    sequence = read.get_forward_sequence()
    if not sequence:
        logging.warning(f"Read {read.query_name} has no sequence")
        return np.array([]), np.array([])

    cytosine_positions = _get_cytosine_positions(sequence)
    guanine_positions = _get_guanine_positions(sequence)
    all_CpG_pos = _get_CpG_pos(cytosine_positions, guanine_positions)

    mm_c_m_idx, _, mm_g_m_idx, _, _ = _get_indices_from_MM(read)
    if mm_c_m_idx.size == 0 and mm_g_m_idx.size == 0:
        return np.array([]), np.array([])

    ml_plus_m, _, ml_minus_m, _ = _get_predictions_from_ML(
        read, len(mm_c_m_idx), 0, len(mm_g_m_idx), 0, False
    )

    c_m_pos = cytosine_positions[mm_c_m_idx] if len(mm_c_m_idx) else np.array([], dtype=int)
    g_m_pos = guanine_positions[mm_g_m_idx] if len(mm_g_m_idx) else np.array([], dtype=int)
    all_pos_in_MM = (
        np.concatenate((c_m_pos, g_m_pos - 1))
        if (c_m_pos.size + g_m_pos.size) > 0
        else np.array([], dtype=int)
    )
    boolean_cpgs_in_MM = np.isin(all_CpG_pos, all_pos_in_MM)
    CpGs_in_MM_tag = all_CpG_pos[boolean_cpgs_in_MM]

    c_pos_above, _, g_pos_above, _ = _positions_above_cutoff(
        c_m_pos,
        np.array([], dtype=int),
        g_m_pos,
        np.array([], dtype=int),
        ml_plus_m,
        np.array([], dtype=int),
        ml_minus_m,
        np.array([], dtype=int),
        cutoff,
    )
    boolean_CpGs_above_plus = np.isin(CpGs_in_MM_tag, c_pos_above)
    boolean_CpGs_above_minus = np.isin(CpGs_in_MM_tag, g_pos_above - 1)
    if read.is_reverse:
        boolean_CpGs_above_plus, boolean_CpGs_above_minus = (
            boolean_CpGs_above_minus,
            boolean_CpGs_above_plus,
        )

    meth_status_array = (boolean_CpGs_above_plus.astype(int) * 1) + (
        boolean_CpGs_above_minus.astype(int) * 2
    )
    return meth_status_array, CpGs_in_MM_tag


def process_bam_file(input, region, min_pct=0.1, cutoff=128, num_states=3):
    """
    Function to create a matrix with the CpG modification status of reads spanning the region.
    """

    bam = pysam.AlignmentFile(input, "rb")  # read the bam file
    reads = bam.fetch(region=region)  # create an iterator for the reads in the specified region

    # Get the start and end positions of the region. The format used to specify the region
    # (chr1:50-100) is interpreted as 1-based, closed interval by pysam
    # (https://pysam.readthedocs.io/en/latest/glossary.html#term-region).
    # Convert the numbers to pythons 0-based, half-open interval by subtracting 1 from the start position.
    region_start = int(region.split(":")[1].split("-")[0]) - 1
    region_end = int(region.split(":")[1].split("-")[1])

    # lists that will store the CpG positions, the methylation status and the names of the reads in the region
    list_of_genomic_cpg_pos_arrays = []
    list_of_meth_status_arrays = []
    read_names = []

    read_counter = 0

    # 1. Step: Get the methylation status and the genomic position of the CpG sites of reads in the region
    for read in reads:
        read_sequence = read.query_sequence

        # get the modification status and the base positions of CpG sites with modification information
        if num_states == 3:
            meth_status_array, CpGs_in_MM_tag = generate_CpG_mod_status_array(
                read, cutoff=cutoff
            )
        else:
            meth_status_array, CpGs_in_MM_tag = generate_CpG_meth_status_array_2state(
                read, cutoff=cutoff
            )

        # To really get the specified genomic positions, one have to take only those bases of the read
        # that align to the reference -> create a list of reference positions for all read bases
        reference_position_lookup = read.get_reference_positions(full_length=True)

        # The arrays generated by generate_CpG_*_status_array() are in the direction that was originally
        # spit out by the sequencer. reversed reads: reverse the hemimethylation_status_array and and the
        # CpG positions array and
        if read.is_reverse:
            # reverse the hemimethylation status array (which has the orientation of original sequencing)
            # as everything will be referenced to genomic positions; and reverse the CpG positions array
            meth_status_array = meth_status_array[::-1]
            CpGs_in_MM_tag_reversed = CpGs_in_MM_tag[::-1]

            # The CpG postions coming from generate_CpG_*_status_array() are pointing to the C of the CpG
            # on the strand that was originally spit out by the sequencer. The C on the other strand is in
            # position +1. Thus, for reversed reads, to get the start-based position of the CpG on the
            # complementary strand, we need to calculate (len(seq)-1)-(CpG_pos + 1). Len(seq)-1 is the last base of the read.
            CpG_in_MM_tag_comp_strand = len(read_sequence) - 1 - (CpGs_in_MM_tag_reversed + 1)

            # Use the reference position lookup to reference the CpG positions to genomic positions; we
            # need to keep Nones as NaN to create a boolean vector needed to slice the hemimethylation xm array.
            # This is achieved by specifying full_length=True in the get_reference_positions() method and dtype=float in np.array().
            CpGs_in_MM_genomic_pos = np.array(
                [reference_position_lookup[i] for i in CpG_in_MM_tag_comp_strand],
                dtype=float,
            )

        # non-reversed reads:
        else:
            # use the lookup to reference the CpG positions to genomic positions, keep Nones as NaN (explained in the block above).
            CpGs_in_MM_genomic_pos = np.array(
                [reference_position_lookup[i] for i in CpGs_in_MM_tag], dtype=float
            )

        # creates an array to slice the hemimethylation_status_array and the CpG position array to get the CpG sites that are in the region
        CpGs_in_region_boolean = (CpGs_in_MM_genomic_pos >= region_start) & (
            CpGs_in_MM_genomic_pos < region_end
        )

        # error handling for reads with no hemimethylation/CpG data (no CpG site in that read in that region).
        if len(meth_status_array) == 0:
            continue  # Skip if hemimethylation_status_array is empty

        # error handling for cases where the length of the slicing array is not the same as the hemimethylation status array.
        if len(CpGs_in_region_boolean) != len(meth_status_array):
            logging.error(
                f"read {read.query_name}: number of CpGs with hemimethylation information {len(meth_status_array)}, number of CpGs in the region {len(CpGs_in_region_boolean)}. --> This indicates that the script is not working as it should. Read skipped"
            )
            continue  # Skip if there is a size mismatch

        # Take only the data from CpG sites in the region by slicing with the CpGs_in_region_boolean array
        sliced_meth_status_array = meth_status_array[CpGs_in_region_boolean]
        sliced_CpG_in_MM_genomic_pos = CpGs_in_MM_genomic_pos[CpGs_in_region_boolean]

        # append the methylation status and the genomic postions of the CpG sites to the lists
        list_of_meth_status_arrays.append(sliced_meth_status_array)
        list_of_genomic_cpg_pos_arrays.append(sliced_CpG_in_MM_genomic_pos)
        read_names.append(read.query_name)

        read_counter += 1

    # Error handling: no reads or no CpG sites in the region
    if read_counter == 0:
        raise ValueError(f"No reads found in region {region}")
    if not any(arr.size > 0 for arr in list_of_meth_status_arrays):
        raise ValueError(f"{read_counter} reads found, but no CpG sites in region {region}")

    # 2. Step: Create the 2D-array/matrix for the heatmap

    # Check if all reads have the same CpG positions.
    # If so, there are no empty values in the heatmap/2D-array and the 2D-array can be created directly from the list of hemimethylatin status arrays.
    all_same = all(
        np.array_equal(list_of_genomic_cpg_pos_arrays[0], cpg)
        for cpg in list_of_genomic_cpg_pos_arrays
    )

    if all_same:
        bam.close()
        hemimeth_matrix = np.array(list_of_meth_status_arrays)
        heatmap_x_labels = list_of_genomic_cpg_pos_arrays[0]
    else:
        # get all occuring genomic cpg positions and filter for those that are found in > min_pct of the reads spanning that position
        all_occuring_positions = np.unique(np.concatenate(list_of_genomic_cpg_pos_arrays))
        # count how many reads supply data for each CpG
        counts = {pos: 0 for pos in all_occuring_positions}
        for arr in list_of_genomic_cpg_pos_arrays:
            for p in np.unique(arr):
                counts[p] += 1
        # for each CpG, get how many reads actually span that genomic position
        contig = region.split(":")[0]
        reads_spanning = {
            p: bam.count(contig, int(p), int(p) + 1) for p in all_occuring_positions
        }
        # keep CpGs present in >= min_pct of the reads that span that position
        filtered_positions = np.array(
            [
                p
                for p in all_occuring_positions
                if reads_spanning[p] > 0
                and counts[p] / reads_spanning[p] >= min_pct
            ]
        )

        bam.close()

        # create empty matrix only for filtered positions
        cpg_index_lookup = {pos: i for i, pos in enumerate(filtered_positions)}
        hemimeth_matrix = np.full(
            (len(read_names), len(filtered_positions)), -1, dtype=int
        )  # -1 will be: missing value (no data)

        empty_hemimeth_status_array_counter = 0
        reads_with_no_methylation_data = []
        # fill the 2D-matrix with the methylation status of the CpG sites
        for i, (pos_arr, meth_arr) in enumerate(
            zip(list_of_genomic_cpg_pos_arrays, list_of_meth_status_arrays)
        ):
            indices_2D_matrix = [
                cpg_index_lookup[p] for p in pos_arr if p in cpg_index_lookup
            ]
            indices_meth_arr = [
                i for i, p in enumerate(pos_arr) if p in cpg_index_lookup
            ]

            # count and skip reads with no methylation data for the filtered positions
            if len(indices_meth_arr) == 0:
                reads_with_no_methylation_data.append(read_names[i])
                empty_hemimeth_status_array_counter += 1
                continue

            if len(indices_2D_matrix) != len(indices_meth_arr):
                logging.error(
                    f"Warning: Read {read_names[i]} skipped: indices_meth_arr length {len(indices_meth_arr)}, indices_2D_matrix length {len(indices_2D_matrix)} -> The script is not working as it should."
                )
                continue

            # fill the 2D matrix with the methylation information of row i
            hemimeth_matrix[i, indices_2D_matrix] = meth_arr[indices_meth_arr]

        heatmap_x_labels = [
            str(int(p) + 1) for p in filtered_positions
        ]  # create 1-based labels of genomic positions of the 2D-matrix
        if empty_hemimeth_status_array_counter == 0:
            logging.info(
                f"\nIn the specified region, {len(read_names)} reads with {len(filtered_positions)} CpG positions (occurence >= min_pct) have been found.\n"
            )
        elif empty_hemimeth_status_array_counter == 1:
            logging.info(
                f"\nIn the specified region, {len(read_names)} reads with {len(filtered_positions)} CpG positions (occurence >= min_pct) have been found. Of these reads, {empty_hemimeth_status_array_counter} has no hemimethylation data in the filtered positions."
            )
            logging.info(
                f"Read with no methylation data: {', '.join(reads_with_no_methylation_data)}\n"
            )
        else:
            logging.info(
                f"\nIn the specified region, {len(read_names)} reads with {len(filtered_positions)} CpG positions (occurence >= min_pct) have been found. Of these reads, {empty_hemimeth_status_array_counter} have no hemimethylation data in the filtered positions."
            )
            logging.info(
                f"Reads with no methylation data: {', '.join(reads_with_no_methylation_data)}\n"
            )

    # filter out rows with all -1 values (missing values only)
    valid_rows = ~(hemimeth_matrix == -1).all(axis=1)
    hemimeth_matrix = hemimeth_matrix[valid_rows, :]
    read_names = [r for r, keep in zip(read_names, valid_rows) if keep]

    # Check if the hemimethylation_matrix is empty
    if (
        hemimeth_matrix.size == 0
        or hemimeth_matrix.shape[0] == 0
        or hemimeth_matrix.shape[1] == 0
    ):
        raise ValueError(
            "No valid CpG methylation data found for the specified region and filtering criteria."
        )

    return hemimeth_matrix, read_names, heatmap_x_labels


def plot_heatmap(
    hemimethylation_matrix,
    read_names,
    heatmap_x_labels,
    output_path=None,
    color_scheme_3=None,
    color_scheme_2=None,
    show_readnames=False,
    num_states=3,
):
    """
    Function to plot a heatmap from the CpG modification status matrix.
    """
    # TODO: with real data, test if row ordering gets better when empty values are set to e.g, -3 and fully methylated to e.g, 5

    # hierarchical clustering for row ordering
    Z = linkage(
        hemimethylation_matrix,
        method="average",  # I tested "average" and "ward" on a simulated lambda dataset; average was better. For testing it on real data, use "ward" and comment the metric line.
        metric="hamming",
        # optimal_ordering=True # Possible with method="average" but did not improve the look of the heatmap with the test dataset
    )
    sort_idx = leaves_list(Z)

    # sorting
    hemimethylation_matrix = hemimethylation_matrix[sort_idx, :]
    read_names = [read_names[i] for i in sort_idx]

    # if a specific color scheme was passed as argument: make cmap
    def _parse_color_scheme(color_scheme, expected_count, arg_name):
        color_names = [c.strip() for c in color_scheme.split(",") if c.strip()]
        if len(color_names) < expected_count:
            print(
                f"{arg_name} must include at least {expected_count} colors; got {len(color_names)}.",
                file=sys.stderr,
            )
            sys.exit(1)
        return color_names[:expected_count]

    if num_states == 3:
        if color_scheme_3:
            color_names = _parse_color_scheme(color_scheme_3, 6, "--color_scheme_3")
            # -1: no data (white), 0: MM, 1: MU/UM, 2: UU, 3: HH, 4: HU/UH, 5: HM/MH
            colors = ["white"] + color_names
        else:
            # default DSI 3-state color scheme (from plot_sample_summary.py 9-state palette)
            colors = [
                "white",
                "#B3474B",
                "#E69F00",
                "#0072B2",
                "#CC79A7",
                "#FFB6EF",
                "#D55E00",
            ]
        bounds = [-1.5, -0.5, 0.5, 1.5, 2.5, 3.5, 4.5, 5.5]
        cbar_ticks = [-1, 0, 1, 2, 3, 4, 5]
        cbar_labels = [
            "no data",
            "MM",
            "MU/UM",
            "UU",
            "HH",
            "HU/UH",
            "HM/MH",
        ]
        title = "CpG Modification Heatmap (6-category)"
    else:
        if color_scheme_2:
            color_names = _parse_color_scheme(color_scheme_2, 4, "--color_scheme_2")
            # -1: no data (white), 0: unmethylated, 1: hemi(+), 2: hemi(-), 3: fully methylated
            colors = ["white"] + color_names
        else:
            # default DSI 2-state color scheme (from plot_sample_summary.py)
            colors = ["white", "#5DC9FA", "#8BCA4C", "#C2E4BC", "#FF6500"]
        bounds = [-1.5, -0.5, 0.5, 1.5, 2.5, 3.5]
        cbar_ticks = [-1, 0, 1, 2, 3]
        cbar_labels = [
            "no data",
            "unmethylated",
            "hemimethylated on (+)",
            "hemimethylated on (-)",
            "fully methylated",
        ]
        title = "CpG Methylation Heatmap (2-state)"
    cmap = mcolors.ListedColormap(colors)
    norm = mcolors.BoundaryNorm(bounds, cmap.N)

    fig, ax = plt.subplots(
        figsize=(10, 10), constrained_layout=True
    )  # use constrained_layout so nothing gets cropped

    cax = ax.matshow(hemimethylation_matrix, cmap=cmap, norm=norm, aspect="auto")

    cbar = plt.colorbar(cax, ticks=cbar_ticks, boundaries=bounds)
    cbar.ax.set_yticklabels(cbar_labels)

    ax.set_xticks(np.arange(len(heatmap_x_labels)))
    ax.set_xticklabels(heatmap_x_labels, rotation=90)
    ax.xaxis.set_ticks_position("bottom")  # Move x-ticks to the bottom
    ax.xaxis.set_label_position("bottom")  # Move x-label to the bottom

    # read names as y-axis labels if set by argparse
    if show_readnames:
        ax.set_yticks(np.arange(len(read_names)))
        ax.set_yticklabels(read_names)

    plt.xlabel("Genomic Position of the CpG site")
    plt.ylabel("Reads")
    plt.title(title)

    if output_path:
        # bbox_inches='tight' ensures that the full figure (including labels) is saved
        plt.savefig(output_path, bbox_inches="tight")
        logging.info(f"{title} saved to {output_path}")
    else:
        plt.show()


def main():
    parser = argparse.ArgumentParser(
        description="Plot CpG Modification Heatmap from BAM file (2-state/3-state)"
    )
    parser.add_argument("--input", type=str, help="Path to the BAM file")
    parser.add_argument(
        "--region",
        type=str,
        help="Genomic region to analyze, e.g., NC_000021.9:1-1000 (1-based closed interval)",
    )  # example is phage lamda
    # parser.add_argument("--clustering_method", type=str, default="average", help="One of the clustering methods of scipy's linkage function for heatmap row ordering") # TODO maybe: add this to the function.
    parser.add_argument(
        "--output_path",
        type=str,
        default=None,
        help="Path to save the heatmap plot, e.g., outputfolder/heatmap.png. If not specified, the plot will be shown interactively",
    )
    parser.add_argument(
        "--color_scheme_3",
        type=str,
        default=None,
        help="Comma-separated list of colors for --num_states 3: six colors (MM, MU/UM, UU, HH, HU/UH, HM/MH). Missing values are displayed in white.",
    )
    parser.add_argument(
        "--color_scheme_2",
        type=str,
        default=None,
        help="Comma-separated list of colors for --num_states 2: four colors (unmethylated, hemi(+), hemi(-), fully). Missing values are displayed in white.",
    )
    parser.add_argument(
        "--num_states",
        type=int,
        default=3,
        choices=[2, 3],
        help="Number of states: 2 (4-state DSI, C+m/G-m) or 3 (6-category from C+m/C+h).",
    )
    parser.add_argument(
        "--min_percentage",
        type=float,
        default=0.1,
        help="Minimum fraction of reads that must contain a CpG for it to be included in the heatmap (default: 0.1)",
    )
    parser.add_argument(
        "--threshold",
        type=int,
        default=128,
        help="Modification likelihood threshold (0-255) for a base to be modified (default: 128).",
    )
    parser.add_argument(
        "--show_readnames",
        action="store_true",
        help="Show read names as y-axis labels in the heatmap.",
    )
    parser.add_argument(
        "--log_level",
        default="info",
        choices=["off", "critical", "error", "warning", "info", "debug"],
    )
    args = parser.parse_args()
    configure_logging(log_level=args.log_level)
    try:
        xm_array, read_names, heatmap_x_labels = process_bam_file(
            args.input,
            args.region,
            min_pct=args.min_percentage,
            cutoff=args.threshold,
            num_states=args.num_states,
        )
    except ValueError as e:
        parser.error(str(e))
    plot_heatmap(
        xm_array,
        read_names,
        heatmap_x_labels,
        args.output_path,
        color_scheme_3=args.color_scheme_3,
        color_scheme_2=args.color_scheme_2,
        show_readnames=args.show_readnames,
        num_states=args.num_states,
    )


if __name__ == "__main__":
    main()
