"""Console-script shims for running legacy module CLIs."""

import runpy


def _run(module_name: str) -> None:
    runpy.run_module(f"methylmirror.{module_name}", run_name="__main__")


def call_modification() -> None:
    from .call_modification import main

    main()


def extract_features() -> None:
    from .extract_features import main

    main()


def pileup() -> None:
    _run("pileup")


def train_hybrid() -> None:
    _run("train_hybrid")


def test() -> None:
    _run("test")


def plot_heatmap() -> None:
    _run("plot_heatmap")


def plot_region_summary() -> None:
    _run("plot_region_summary")


def plot_sample_summary() -> None:
    _run("plot_sample_summary")


def plot_kmer_kinetics() -> None:
    _run("plot_kmer_kinetics")


def cluster_positions() -> None:
    _run("cluster_positions")


def cluster_plot() -> None:
    _run("cluster_plot")
