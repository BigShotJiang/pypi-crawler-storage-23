#!/usr/bin/env python3
import os
import sys
import argparse
import logging
import json
import numpy as np
from tqdm import tqdm
from sklearn.model_selection import train_test_split
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from .hybrid_model import HybridCNNTransformerModel
from .dataloader import ArrayDataset

# Parse CLI early so we can configure logging before other actions
parser = argparse.ArgumentParser(description="Hybrid model training on NPZ datasets (directory input, new logging).")
parser.add_argument("-i", "--input", type=str, required=True,
                    help="Input directory containing .npz files for training (all .npz files in this folder will be used).")
parser.add_argument("--val_fraction", type=float, default=0.1,
                    help="Fraction of data to use for validation [default: 0.1]")
parser.add_argument("--random_seed", type=int, default=42, help="Random seed")
parser.add_argument("--batch_size", type=int, default=200)
parser.add_argument("--val_batch_size", type=int, default=100)
parser.add_argument("--epochs", type=int, default=50)
parser.add_argument("--lr", type=float, default=1e-4)
parser.add_argument("--weight_decay", type=float, default=1e-4)
parser.add_argument("--cnn_hidden", type=int, default=128)
parser.add_argument("--cnn_layers", type=int, default=4)
parser.add_argument("--transformer_layers", type=int, default=6)
parser.add_argument("--transformer_dim", type=int, default=256)
parser.add_argument("--transformer_heads", type=int, default=8)
parser.add_argument("--dropout", type=float, default=0.2)
parser.add_argument("--num_workers", type=int, default=4)
parser.add_argument("--early_stop_patience", type=int, default=5)
parser.add_argument("--model_dir", type=str, default="HybridModel_optimized")
parser.add_argument("--input_channels", type=int, default=3,
                    help="Number of input channels. Default 3.")
parser.add_argument("--num_classes", type=int, default=2,
                    help="Number of output classes. Default 2.")
parser.add_argument("--seq_len", type=int, default=21,
                    help="Sequence length. Default 21.")
parser.add_argument("--log-file", type=str, default=None,
                    help="Optional log file path. If not set logs go to stdout.")
parser.add_argument("--log-level", type=str, choices=["OFF", "ERROR", "WARN", "INFO"], default="INFO",
                    help="Log level. One of OFF, ERROR, WARN, INFO. Default INFO.")
parser.add_argument("--label_map", type=str, default=None,
                    help="Optional JSON string mapping label->int (quote it on the shell), e.g. '{\"dC\":0, \"mdC\":1}'")
args = parser.parse_args()

# Configure logging according to args
def setup_logging(log_file=None, log_level="INFO"):
    level_map = {
        "OFF": logging.CRITICAL + 1,
        "ERROR": logging.ERROR,
        "WARN": logging.WARNING,
        "INFO": logging.INFO
    }
    level = level_map.get(log_level, logging.INFO)
    log_format = "%(asctime)s [%(levelname)s] %(message)s"
    handlers = []
    if log_file:
        log_dir = os.path.dirname(log_file)
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)
        handlers.append(logging.FileHandler(log_file, mode="w"))
    handlers.append(logging.StreamHandler(sys.stdout))
    logging.basicConfig(level=level, format=log_format, handlers=handlers, force=True)
    if log_level == "OFF":
        logging.disable(logging.CRITICAL)

setup_logging(args.log_file, args.log_level)



# ============================================================
# NPZ I/O helpers for the new structure
# ============================================================
def load_npz_arrays(npz_path):
    data = np.load(npz_path, allow_pickle=True)
    # Only use encode_kmer, ipd, pw, label (label may be an array)
    ek = data["encode_kmer"]
    ipd = data["ipd"]
    pw = data["pw"]
    lab = data["label"]
    return ek, ipd, pw, lab


def gather_files_from_input_folder(folder_path):
    if not os.path.isdir(folder_path):
        logging.error(f"Input path is not a directory: {folder_path}")
        sys.exit(1)
    files = sorted([os.path.join(folder_path, f) for f in os.listdir(folder_path) if f.endswith(".npz")])
    return files


# ============================================================
# Training & evaluation (array-based loop)
# ============================================================
def train_epoch(model, loader, optimizer, criterion, device):
    model.train()
    total_loss = 0.0
    for ek, ipd, pw, label in tqdm(loader, desc="Training", leave=False):
        features = torch.stack([ek, ipd, pw], dim=1).to(device, non_blocking=True)
        y = label.to(device, non_blocking=True)
        optimizer.zero_grad()
        logits = model(features)
        loss = criterion(logits, y)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * y.size(0)
    return total_loss / len(loader.dataset)


def evaluate(model, loader, criterion, device, phase="Validation"):
    model.eval()
    total_loss = 0.0
    correct = 0
    with torch.no_grad():
        for ek, ipd, pw, label in tqdm(loader, desc=phase, leave=False):
            features = torch.stack([ek, ipd, pw], dim=1).to(device, non_blocking=True)
            y = label.to(device, non_blocking=True)
            logits = model(features)
            loss = criterion(logits, y)
            total_loss += loss.item() * y.size(0)
            preds = logits.argmax(dim=1)
            correct += (preds == y).sum().item()
    return total_loss / len(loader.dataset), correct / len(loader.dataset)


# ============================================================
# Helper to parse label mapping from CLI (JSON only)
# ============================================================
def parse_label_map(args):
    if args.label_map is not None:
        try:
            lm = json.loads(args.label_map)
            if not isinstance(lm, dict):
                raise ValueError("label_map JSON must be an object/dict")
            return {str(k): int(v) for k, v in lm.items()}
        except json.JSONDecodeError as e:
            raise ValueError(f"Could not parse --label_map JSON. Quote the JSON on the command line, e.g. --label_map '{{\"dC\":0,\"mdC\":1}}'. Error: {e}")
    return None


# ============================================================
# Main
# ============================================================
def main(parsed_args):
    logging.info("Starting training script.")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logging.info(f"Using device: {device}")

    # Collect npz files from input folder
    input_folder = parsed_args.input
    npz_files = gather_files_from_input_folder(input_folder)
    if len(npz_files) == 0:
        logging.error(f"No NPZ files found in input directory: {input_folder}")
        sys.exit(1)

    # Log count and filenames (English)
    filenames = [os.path.basename(p) for p in npz_files]
    logging.info(f"Found {len(npz_files)} NPZ files in '{input_folder}':")
    for name in filenames:
        logging.info(f"  - {name}")

    # Load arrays from files. For label, use the first entry of 'label' key for file-level label.
    encode_kmer_list = []
    ipd_list = []
    pw_list = []
    labels_list = []

    for f in npz_files:
        ek, ipd, pw, lab = load_npz_arrays(f)
        ek = np.asarray(ek)
        ipd = np.asarray(ipd)
        pw = np.asarray(pw)
        lab = np.asarray(lab)
        if ek.ndim != 2 or ipd.ndim != 2 or pw.ndim != 2:
            logging.error(f"File {f} does not contain 2D arrays for encode_kmer/ipd/pw. Found shapes: ek={ek.shape}, ipd={ipd.shape}, pw={pw.shape}")
            sys.exit(1)
        if lab.size == 0:
            logging.error(f"File {f} has empty 'label' array.")
            sys.exit(1)
        file_label = lab.flat[0]
        num_samples = ek.shape[0]
        labels_for_file = np.array([file_label] * num_samples, dtype=object)

        encode_kmer_list.append(ek)
        ipd_list.append(ipd)
        pw_list.append(pw)
        labels_list.append(labels_for_file)

        logging.info(f"Loaded {num_samples} samples from '{os.path.basename(f)}' with file-level label '{file_label}'.")

    # Concatenate across files
    encode_kmer = np.concatenate(encode_kmer_list, axis=0)
    ipd = np.concatenate(ipd_list, axis=0)
    pw = np.concatenate(pw_list, axis=0)
    labels = np.concatenate(labels_list, axis=0)
    logging.info(f"Total samples loaded: {len(labels)}")

    # Parse label mapping
    try:
        user_label_map = parse_label_map(parsed_args)
    except Exception as e:
        logging.error(str(e))
        sys.exit(1)

    # Map labels to integers
    if user_label_map is not None:
        label_map = user_label_map
        logging.info(f"Using user label mapping: {label_map}")
        labels_mapped = np.array([label_map[str(l)] for l in labels], dtype=int)
    else:
        unique_labels = sorted(set(labels.tolist()))
        label_map = {l: i for i, l in enumerate(unique_labels)}
        logging.info(f"Automatic label mapping: {label_map}")
        labels_mapped = np.array([label_map[l] for l in labels], dtype=int)

    # Balance classes by downsampling to min class size
    bincounts = np.bincount(labels_mapped)
    min_class = int(np.min(bincounts))
    logging.info(f"Counts per class before balancing: {bincounts.tolist()}")
    rng = np.random.default_rng(parsed_args.random_seed)
    idx_balanced = np.hstack([
        rng.choice(np.where(labels_mapped == lbl)[0], min_class, replace=False)
        for lbl in np.unique(labels_mapped)
    ])
    rng.shuffle(idx_balanced)
    encode_kmer = encode_kmer[idx_balanced]
    ipd = ipd[idx_balanced]
    pw = pw[idx_balanced]
    labels_mapped = labels_mapped[idx_balanced]
    bincounts_bal = np.bincount(labels_mapped)
    logging.info(f"Counts per class after balancing: {bincounts_bal.tolist()}")

    # Train/val split (stratified)
    train_idx, val_idx = train_test_split(
        np.arange(len(labels_mapped)), test_size=parsed_args.val_fraction, stratify=labels_mapped, random_state=parsed_args.random_seed
    )
    logging.info(f"Train/Val split: {len(train_idx)} / {len(val_idx)}")

    train_dataset = ArrayDataset(encode_kmer[train_idx], ipd[train_idx], pw[train_idx], labels_mapped[train_idx])
    val_dataset = ArrayDataset(encode_kmer[val_idx], ipd[val_idx], pw[val_idx], labels_mapped[val_idx])

    train_loader = DataLoader(train_dataset, batch_size=parsed_args.batch_size, shuffle=True,
                              num_workers=parsed_args.num_workers, pin_memory=True)
    val_loader = DataLoader(val_dataset, batch_size=parsed_args.val_batch_size, shuffle=False,
                            num_workers=max(0, parsed_args.num_workers // 2), pin_memory=True)


    # Model initialization using CLI args (fallback to inferred values)
    num_classes = parsed_args.num_classes if parsed_args.num_classes is not None else int(np.max(labels_mapped)) + 1
    seq_len = parsed_args.seq_len if parsed_args.seq_len is not None else encode_kmer.shape[1]

    input_channels = parsed_args.input_channels if parsed_args.input_channels is not None else 3
    model = HybridCNNTransformerModel(
        input_channels=input_channels,
        seq_len=seq_len,
        num_classes=num_classes,
        cnn_hidden=parsed_args.cnn_hidden,
        cnn_layers=parsed_args.cnn_layers,
        transformer_layers=parsed_args.transformer_layers,
        transformer_dim=parsed_args.transformer_dim,
        transformer_heads=parsed_args.transformer_heads,
        dropout=parsed_args.dropout
    ).to(device)

    optimizer = optim.AdamW(model.parameters(), lr=parsed_args.lr, weight_decay=parsed_args.weight_decay)
    criterion = nn.CrossEntropyLoss()

    os.makedirs(parsed_args.model_dir, exist_ok=True)
    best_val_loss = float("inf")
    patience_counter = 0

    logging.info(f"Training for up to {parsed_args.epochs} epochs...")
    for epoch in range(1, parsed_args.epochs + 1):
        logging.info(f"Epoch {epoch}/{parsed_args.epochs}")
        train_loss = train_epoch(model, train_loader, optimizer, criterion, device)
        val_loss, val_acc = evaluate(model, val_loader, criterion, device)
        logging.info(f"Epoch {epoch:03d}/{parsed_args.epochs} | Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f} | Val Acc: {val_acc:.4f}")

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            best_path = os.path.join(parsed_args.model_dir, "best_model.pt")
            torch.save(model.state_dict(), best_path)
            logging.info(f"Saved new best model → {best_path}")
        else:
            patience_counter += 1
            if patience_counter >= parsed_args.early_stop_patience:
                logging.info("Early stopping triggered.")
                break

    # Final evaluation on validation set
    logging.info("Loading best model for final evaluation...")
    model.load_state_dict(torch.load(os.path.join(parsed_args.model_dir, "best_model.pt")))
    test_loss, test_acc = evaluate(model, val_loader, criterion, device, phase="Final Test")
    logging.info(f"Final Test Results → Loss: {test_loss:.4f}, Accuracy: {test_acc:.4f}")
    logging.info("Training complete.")


if __name__ == "__main__":
    main(args)