#!/usr/bin/env python3
import argparse
import gzip
import sys

import numpy as np
from sklearn.cluster import MiniBatchKMeans

def open_maybe_gzip(path):
    if path.endswith(".gz"):
        return gzip.open(path, "rt")
    return open(path, "rt")

def parse_args():
    p = argparse.ArgumentParser(
        description="Cluster CpG positions from 2-state or 3-state pileup DSI output."
    )
    p.add_argument("-i", "--input", required=True, help="Input .dsi.gz file")
    p.add_argument("-o", "--output", required=True, help="Output TSV (chr position cluster)")
    p.add_argument("-n", "--n_cluster", type=int, default=3, help="Number of clusters (default: 3)")
    p.add_argument(
        "--states",
        "--num-classes",
        dest="num_classes",
        type=int,
        choices=[2, 3],
        default=2,
        help="DSI layout mode from pileup.py: 2 (4-state columns) or 3 (9-state columns). Default: 2",
    )
    p.add_argument("-c", "--min_coverage", type=float, default=5.0,
                   help="Minimum total coverage to include a row (default: 5)")
    p.add_argument("--random_state", type=int, default=42, help="Random seed (default: 42)")
    return p.parse_args()

def main():
    args = parse_args()

    if args.num_classes == 2:
        feature_idxs = [7, 8, 9, 10]
        min_columns = 11
    else:
        feature_idxs = [7, 8, 9, 10, 11, 12, 13, 14, 15]
        min_columns = 16

    chroms = []
    positions = []
    features = []

    with open_maybe_gzip(args.input) as fh:
        for line in fh:
            if not line.strip():
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) < min_columns:
                continue  # skip malformed
            chrom = parts[0]
            pos = parts[1]
            try:
                total_cov = float(parts[3])
                if total_cov <= 0:
                    continue
                cols = np.array([float(parts[i]) for i in feature_idxs], dtype=float)
            except ValueError:
                continue  # skip malformed

            if total_cov < args.min_coverage:
                continue

            # normalize by coverage
            cols = cols / total_cov

            chroms.append(chrom)
            positions.append(pos)
            features.append(cols)

    if not features:
        sys.stderr.write("No valid rows found after filtering.\n")
        sys.exit(1)

    X = np.vstack(features)

    model = MiniBatchKMeans(
        n_clusters=args.n_cluster,
        random_state=args.random_state,
        batch_size=10000
    )
    labels = model.fit_predict(X)

    with open(args.output, "w") as out:
        for chrom, pos, label in zip(chroms, positions, labels):
            out.write(f"{chrom}\t{pos}\t{label + 1}\n")  # clusters labeled 1..k

if __name__ == "__main__":
    main()
