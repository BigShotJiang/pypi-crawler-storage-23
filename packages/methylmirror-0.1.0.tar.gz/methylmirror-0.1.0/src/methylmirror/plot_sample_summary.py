import pandas as pd
import matplotlib.pyplot as plt
import argparse
import os
import sys


def _read_dsi(file_path, col_names):
    try:
        return pd.read_csv(file_path, sep="\t", compression="gzip", header=None, names=col_names)
    except EOFError:
        return pd.read_csv(file_path, sep="\t", header=None, names=col_names)


def summarize_file(file_path, num_reads=0, output_mode="nine"):
    if output_mode == "nine":
        col_names = [
            "chromosome",           # 0
            "position",             # 1
            "strand",               # 2
            "total coverage",       # 3
            "coverage methylated",  # 4
            "coverage unmethylated",# 5
            "locus type",           # 6
            "MM",                   # 7
            "MC",                   # 8
            "CM",                   # 9
            "CC",                   # 10
            "HH",                   # 11
            "HC",                   # 12
            "CH",                   # 13
            "MH",                   # 14
            "HM"                    # 15
        ]
    else:
        col_names = [
            "chromosome",           # 0
            "position",             # 1
            "strand",               # 2
            "total coverage",       # 3
            "coverage methylated",  # 4
            "coverage unmethylated",# 5
            "locus type",           # 6
            "fully",                # 7
            "hemi_plus",            # 8
            "hemi_minus",           # 9
            "unmethylated"          # 10
        ]
    df = _read_dsi(file_path, col_names)
    if num_reads > 0 and num_reads < len(df):
        df = df.sample(n=num_reads, random_state=42)

    if output_mode == "nine":
        cols = ["MM", "MC", "CM", "CC", "HH", "HC", "CH", "MH", "HM"]
        df[cols] = df[cols].apply(pd.to_numeric, errors="coerce")
        totals = {
            "MM": df["MM"].sum(),
            "MC/CM": (df["MC"] + df["CM"]).sum(),
            "CC": df["CC"].sum(),
            "HH": df["HH"].sum(),
            "HC/CH": (df["HC"] + df["CH"]).sum(),
            "MH/HM": (df["MH"] + df["HM"]).sum(),
        }
    else:
        cols = ["fully", "hemi_plus", "hemi_minus", "unmethylated"]
        df[cols] = df[cols].apply(pd.to_numeric, errors="coerce")
        totals = {c: df[c].sum() for c in cols}
    return totals


def _parse_color_scheme(color_scheme, expected_count, arg_name):
    color_names = [c.strip() for c in color_scheme.split(",") if c.strip()]
    if len(color_names) < expected_count:
        print(
            f"{arg_name} must include at least {expected_count} colors; got {len(color_names)}.",
            file=sys.stderr,
        )
        sys.exit(1)
    return color_names[:expected_count]


def plot_summary(percentage_df, sample_names, output_file, title, show_percent=True,
                 save_svg=False, svg_file=None, output_mode="nine", colors=None):
    if output_mode == "nine":
        if colors is None:
            colors = ["#B3474B", "#E69F00", "#0072B2", "#CC79A7", "#FFB6EF", "#D55E00"]
        stack_definitions = [
            ("MM", "MM"),
            ("MC/CM", "MU/UM"),
            ("CC", "UU"),
            ("HH", "HH"),
            ("HC/CH", "HU/UH"),
            ("MH/HM", "HM/MH"),
        ]
    else:
        if colors is None:
            colors = ["#FF6500", "#8BCA4C", "#C2E4BC", "#5DC9FA"]
        stack_definitions = [
            ("fully", "fully"),
            ("hemi_plus", "hemi_plus"),
            ("hemi_minus", "hemi_minus"),
            ("unmethylated", "unmethylated"),
        ]

    fig, ax = plt.subplots(figsize=(2.5 * len(sample_names), 7))
    bottom = [0] * len(sample_names)

    for (column_key, legend_label), color in zip(stack_definitions, colors):
        heights = percentage_df[column_key]
        bars = ax.bar(
            percentage_df.index,
            heights,
            bottom=bottom,
            label=legend_label,
            color=color
        )

        if show_percent:
            for j, (bar, h) in enumerate(zip(bars, heights)):
                if h > 1:
                    ax.text(
                        bar.get_x() + bar.get_width() / 2,
                        bottom[j] + h / 2,
                        f"{h:.1f}%",
                        ha="center",
                        va="center",
                        fontsize=9,
                        color="black",
                        fontweight="bold"
                    )

        bottom = [b + h for b, h in zip(bottom, heights)]

    ax.set_ylabel("Percentage of Reads (%)")
    ax.set_xlabel("Sample")
    ax.set_title(title)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.set_ylim(0, 100)
    ax.yaxis.set_ticks_position("left")
    ax.xaxis.set_ticks_position("bottom")
    ax.legend(
        title="Methylation State",
        loc="lower center",
        bbox_to_anchor=(0.5, -0.18),
        ncol=len(stack_definitions),
        frameon=False
    )

    plt.tight_layout()
    plt.savefig(output_file, dpi=300, bbox_inches="tight")
    if save_svg and svg_file is not None:
        plt.savefig(svg_file, format="svg", bbox_inches="tight")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(
        description="Stacked Frequency Summary Bar Plot Tool (2-state/3-state summary)"
    )
    parser.add_argument("-i", "--input", required=True, help="Comma-separated list of input .dsi.gz files")
    parser.add_argument("-o", "--output", required=True, help="Output image file (.png preferred)")
    parser.add_argument("--names", type=str, default=None,
                        help="Comma-separated sample names (must match number of input files)")
    parser.add_argument("--svg", action="store_true", help="Also save plot as SVG")
    parser.add_argument("-n", "--num_reads", type=int, default=0,
                        help="Number of random reads (lines) to use from each .dsi.gz file (default: 0 = all lines)")
    parser.add_argument("--title", type=str, help="Title of the plot",
                        default="Summarized Stacked Bar of Read Methylation States")
    parser.add_argument("--num-states", type=int, required=True,
                        help="Number of states: 2 (4-state DSI) or 3 (9-state DSI)")
    parser.add_argument(
        "--color_scheme_2",
        type=str,
        default=None,
        help="Comma-separated list of colors for --num-states 2: four colors (fully, hemi_plus, hemi_minus, unmethylated).",
    )
    parser.add_argument(
        "--color_scheme_3",
        type=str,
        default=None,
        help="Comma-separated list of colors for --num-states 3: six colors (MM, MU/UM, UU, HH, HU/UH, HM/MH).",
    )
    args = parser.parse_args()

    if args.num_states not in (2, 3):
        raise ValueError("--num-states must be 2 or 3.")

    input_files = [x.strip() for x in args.input.split(",") if x.strip()]
    if args.names:
        sample_names = [x.strip() for x in args.names.split(",") if x.strip()]
        if len(sample_names) != len(input_files):
            raise ValueError("Number of --names must match number of input files.")
    else:
        sample_names = [os.path.basename(f) for f in input_files]

    output_mode = "nine" if args.num_states == 3 else "four"
    if output_mode == "nine":
        cols = ["MM", "MC/CM", "CC", "HH", "HC/CH", "MH/HM"]
    else:
        cols = ["fully", "hemi_plus", "hemi_minus", "unmethylated"]
    colors = None
    if args.num_states == 2 and args.color_scheme_2:
        colors = _parse_color_scheme(args.color_scheme_2, 4, "--color_scheme_2")
    if args.num_states == 3 and args.color_scheme_3:
        colors = _parse_color_scheme(args.color_scheme_3, 6, "--color_scheme_3")

    summary_df = pd.DataFrame(columns=cols)
    for file_path in input_files:
        totals = summarize_file(file_path, num_reads=args.num_reads, output_mode=output_mode)
        summary_df.loc[len(summary_df)] = [totals[c] for c in cols]

    sum_reads = summary_df.sum(axis=1)
    sum_reads[sum_reads == 0] = 1
    percentage_df = summary_df.div(sum_reads, axis=0) * 100
    percentage_df.index = sample_names

    output_file = args.output
    base, ext = os.path.splitext(output_file)
    svg_file = base + ".svg" if args.svg else None
    plot_summary(
        percentage_df,
        sample_names,
        output_file,
        args.title,
        show_percent=True,
        save_svg=args.svg,
        svg_file=svg_file,
        output_mode=output_mode,
        colors=colors,
    )
    print(f"Saved plot as {output_file}")
    if args.svg:
        print(f"Saved plot as {svg_file}")

    output_no_pct = f"{base}_no_pct{ext}"
    svg_no_pct = f"{base}_no_pct.svg" if args.svg else None
    plot_summary(
        percentage_df,
        sample_names,
        output_no_pct,
        args.title,
        show_percent=False,
        save_svg=args.svg,
        svg_file=svg_no_pct,
        output_mode=output_mode,
        colors=colors,
    )
    print(f"Saved plot as {output_no_pct}")
    if args.svg:
        print(f"Saved plot as {svg_no_pct}")


if __name__ == "__main__":
    main()
