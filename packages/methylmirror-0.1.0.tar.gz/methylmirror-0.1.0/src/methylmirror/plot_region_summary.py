import argparse
import os
import sys

import matplotlib.pyplot as plt
import pandas as pd


def _read_dsi(file_path, col_names):
    try:
        return pd.read_csv(file_path, sep="\t", compression="gzip", header=None, names=col_names)
    except EOFError:
        return pd.read_csv(file_path, sep="\t", header=None, names=col_names)


def parse_bed(bed_path):
    regions = []
    with open(bed_path) as f:
        for line in f:
            if line.startswith("#") or line.strip() == "":
                continue
            fields = line.strip().split()
            if len(fields) < 3:
                continue
            chrom, start, stop = fields[:3]
            label = fields[3] if len(fields) > 3 else f"{chrom}_{start}_{stop}"
            regions.append((chrom, int(start), int(stop), label))
    return regions


def parse_region(region_str):
    chrom_part, coords = region_str.split(":")
    start_str, end_str = coords.split("-")
    return chrom_part, int(start_str), int(end_str)


def get_plot_config(num_states):
    if num_states == 2:
        col_names = [
            "chromosome",          # 0
            "position",            # 1
            "strand",              # 2
            "total coverage",      # 3
            "coverage methylated", # 4
            "coverage unmethylated",  # 5
            "locus type",          # 6
            "coverage MM",         # 7 (M:M)
            "coverage MU",         # 8 (M:U)
            "coverage UM",         # 9 (U:M)
            "coverage UU",         # 10 (U:U)
        ]
        order = ["coverage MM", "coverage MU", "coverage UM", "coverage UU"]
        labels = ["M:M", "M:U", "U:M", "U:U"]
        colors = ["#FF6500", "#8BCA4C", "#C2E4BC", "#5DC9FA"]
        return col_names, order, labels, colors

    if num_states == 3:
        col_names = [
            "chromosome",          # 0
            "position",            # 1
            "strand",              # 2
            "total coverage",      # 3
            "coverage methylated", # 4
            "coverage unmethylated",  # 5
            "locus type",          # 6
            "MM",                  # 7
            "MC",                  # 8
            "CM",                  # 9
            "CC",                  # 10
            "HH",                  # 11
            "HC",                  # 12
            "CH",                  # 13
            "MH",                  # 14
            "HM",                  # 15
        ]
        order = ["MM", "MC/CM", "CC", "HH", "HC/CH", "MH/HM"]
        labels = ["MM", "MU/UM", "UU", "HH", "HU/UH", "HM/MH"]
        colors = ["#B3474B", "#E69F00", "#0072B2", "#CC79A7", "#FFB6EF", "#D55E00"]
        return col_names, order, labels, colors

    raise ValueError("--num-states must be 2 or 3.")


def _parse_color_scheme(color_scheme, expected_count, arg_name):
    color_names = [c.strip() for c in color_scheme.split(",") if c.strip()]
    if len(color_names) < expected_count:
        print(
            f"{arg_name} must include at least {expected_count} colors; got {len(color_names)}.",
            file=sys.stderr,
        )
        sys.exit(1)
    return color_names[:expected_count]


def build_plot_data(df, num_states, order):
    if num_states == 2:
        df_sub = df[order].apply(pd.to_numeric, errors="coerce").fillna(0)
    else:
        df_sub = pd.DataFrame({
            "MM": pd.to_numeric(df["MM"], errors="coerce"),
            "MC/CM": pd.to_numeric(df["MC"], errors="coerce") + pd.to_numeric(df["CM"], errors="coerce"),
            "CC": pd.to_numeric(df["CC"], errors="coerce"),
            "HH": pd.to_numeric(df["HH"], errors="coerce"),
            "HC/CH": pd.to_numeric(df["HC"], errors="coerce") + pd.to_numeric(df["CH"], errors="coerce"),
            "MH/HM": pd.to_numeric(df["MH"], errors="coerce") + pd.to_numeric(df["HM"], errors="coerce"),
        }).fillna(0)
        df_sub = df_sub[order]
    return df_sub


def plot_region(df, chrom, start, stop, output_prefix, region_label, plot_title,
                num_states, order, labels, colors, save_svg=False):
    region_df = df[
        (df["chromosome"] == chrom)
        & (df["position"] >= start)
        & (df["position"] <= stop)
    ]
    if region_df.empty:
        print(f"No data for region {chrom}:{start}-{stop}, skipping.")
        return

    df_sub = build_plot_data(region_df, num_states, order)
    df_sub.index = range(len(df_sub))
    sum_reads = df_sub.sum(axis=1)
    sum_reads[sum_reads == 0] = 1
    df_pct = df_sub.div(sum_reads, axis=0) * 100

    fig, ax = plt.subplots(figsize=(10, 6))
    df_pct.plot(kind="bar", stacked=True, color=colors, width=1.0, ax=ax)

    plt.ylabel("Methylation [%]")
    plt.xlabel("CpGs")

    if region_label:
        full_title = f"{plot_title}\n{region_label}"
    else:
        full_title = plot_title
    plt.title(full_title)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.set_ylim(0, 100)
    ax.set_xticklabels([])

    handles = [plt.Rectangle((0, 0), 1, 1, color=color) for color in colors]
    ax.legend(
        handles,
        labels,
        title="Methylation State" if num_states == 3 else "Read Pair Type",
        loc="lower center",
        bbox_to_anchor=(0.5, -0.25),
        ncol=len(labels),
        frameon=False,
    )
    plt.tight_layout(rect=[0, 0.08, 1, 1])

    safe_label = "".join([c if c.isalnum() or c in "-._" else "_" for c in region_label])
    out_file = f"{output_prefix}_{safe_label}.png"
    plt.savefig(out_file, dpi=300)
    if save_svg:
        out_svg = f"{output_prefix}_{safe_label}.svg"
        plt.savefig(out_svg, format="svg")
        print(f"Saved: {out_svg}")
    plt.close()
    print(f"Saved: {out_file}")


def main():
    parser = argparse.ArgumentParser(
        description="Stacked Frequency Bar Plot Tool (2-state/3-state region summary)"
    )
    parser.add_argument("-i", "--input", required=True, help="Input .dsi.gz file")
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Output image file (e.g., .png) or prefix if using --regions",
    )
    parser.add_argument(
        "-r",
        "--regions",
        type=str,
        help="BED file (tab-separated, columns: chr, start, stop[, label]) for multiple regions",
    )
    parser.add_argument(
        "--region",
        type=str,
        help="Single region in the form chr:start-end (e.g., chr2:92198510-92199983)",
    )
    parser.add_argument("--svg", action="store_true", help="Also save plot(s) as SVG")
    parser.add_argument(
        "--title",
        type=str,
        default="Methylation Profile",
        help='Title of the plot (default: "Methylation Profile")',
    )
    parser.add_argument(
        "--num-states",
        type=int,
        required=True,
        help="Number of states: 2 (4-state DSI) or 3 (9-state DSI)",
    )
    parser.add_argument(
        "--color_scheme_2",
        type=str,
        default=None,
        help="Comma-separated list of colors for --num-states 2: four colors (M:M, M:U, U:M, U:U).",
    )
    parser.add_argument(
        "--color_scheme_3",
        type=str,
        default=None,
        help="Comma-separated list of colors for --num-states 3: six colors (MM, MC/CM, CC, HH, HC/CH, MH/HM).",
    )
    args = parser.parse_args()

    if args.num_states not in (2, 3):
        raise ValueError("--num-states must be 2 or 3.")

    if args.region and args.regions:
        raise ValueError("Use only one of --region or --regions.")

    col_names, order, labels, colors = get_plot_config(args.num_states)
    if args.num_states == 2 and args.color_scheme_2:
        colors = _parse_color_scheme(args.color_scheme_2, 4, "--color_scheme_2")
    if args.num_states == 3 and args.color_scheme_3:
        colors = _parse_color_scheme(args.color_scheme_3, 6, "--color_scheme_3")
    df = _read_dsi(args.input, col_names)

    if args.region:
        output_prefix = os.path.splitext(args.output)[0]
        chrom, start, stop = parse_region(args.region)
        plot_region(
            df,
            chrom,
            start,
            stop,
            output_prefix,
            args.region,
            args.title,
            args.num_states,
            order,
            labels,
            colors,
            save_svg=args.svg,
        )
    elif args.regions:
        output_prefix = os.path.splitext(args.output)[0]
        regions = parse_bed(args.regions)
        for chrom, start, stop, label in regions:
            plot_region(
                df,
                chrom,
                start,
                stop,
                output_prefix,
                label,
                args.title,
                args.num_states,
                order,
                labels,
                colors,
                save_svg=args.svg,
            )
    else:
        df_sub = build_plot_data(df, args.num_states, order)
        df_sub.index = range(len(df_sub))
        sum_reads = df_sub.sum(axis=1)
        sum_reads[sum_reads == 0] = 1
        df_pct = df_sub.div(sum_reads, axis=0) * 100

        fig, ax = plt.subplots(figsize=(10, 6))
        df_pct.plot(kind="bar", stacked=True, color=colors, width=1.0, ax=ax)

        plt.ylabel("Methylation [%]")
        plt.xlabel("CpGs")
        plt.title(args.title)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.set_ylim(0, 100)
        ax.set_xticklabels([])

        handles = [plt.Rectangle((0, 0), 1, 1, color=color) for color in colors]
        ax.legend(
            handles,
            labels,
            title="Methylation State" if args.num_states == 3 else "Read Pair Type",
            loc="lower center",
            bbox_to_anchor=(0.5, -0.25),
            ncol=len(labels),
            frameon=False,
        )
        plt.tight_layout(rect=[0, 0.08, 1, 1])
        plt.savefig(args.output, dpi=300)
        if args.svg:
            out_svg = os.path.splitext(args.output)[0] + ".svg"
            plt.savefig(out_svg, format="svg")
            print(f"Saved: {out_svg}")
        plt.close()
        print(f"Saved: {args.output}")


if __name__ == "__main__":
    main()
