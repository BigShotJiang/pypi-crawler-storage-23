#!/usr/bin/env python3
import argparse
import os
import numpy as np
import multiprocessing as mp
from tqdm import tqdm
from .utilities import *
import pysam
import math
import logging
import sys
import time
import shutil


def get_total_reads(bam_path):
    with pysam.AlignmentFile(bam_path, "rb", check_sq=False) as bam:
        return bam.count(until_eof=True)


def calculate_optimal_chunk_size(bam_path, threads, multiplier=4, log_level="ERROR"):
    total_reads = get_total_reads(bam_path)
    num_chunks = threads * multiplier
    chunk_size = math.ceil(total_reads / num_chunks)
    msg = f"Total reads: {total_reads}, Threads: {threads}, automatic chunks: {num_chunks}, Chunk size: {chunk_size}"
    print_process_info(msg, log_level)
    logging.info(msg)
    return chunk_size


def remove_tmp_dir(tmp_dir):
    if not os.path.exists(tmp_dir):
        return
    for f in os.listdir(tmp_dir):
        fpath = os.path.join(tmp_dir, f)
        try:
            os.remove(fpath)
        except Exception as e:
            print(f"Failed to remove file {f}: {e}")
    try:
        os.rmdir(tmp_dir)
        print(f"Removed temporary chunk directory: {tmp_dir}")
    except Exception as e:
        print(f"WARNING: Could not remove temporary directory: {tmp_dir} ({e})")


def _safe_max_str_len(arr):
    if arr.size == 0:
        return 0
    try:
        lengths = np.char.str_len(arr.astype(str))
        return int(lengths.max())
    except Exception:
        return max(len(str(x)) for x in arr.ravel())


def _scan_chunk_metadata(tmp_chunk_files):
    total_entries = 0
    kmer_len = 0
    max_label_len = 0
    max_cg_len = 0
    max_strand_len = 0

    for chunk_file in tqdm(tmp_chunk_files, desc="Scanning chunk metadata"):
        with np.load(chunk_file, allow_pickle=True) as data:
            enc = data["encode_kmer"]
            n = enc.shape[0]
            if n == 0:
                continue
            total_entries += n
            if kmer_len == 0:
                kmer_len = enc.shape[1]
            max_label_len = max(max_label_len, _safe_max_str_len(data["label"]))
            max_cg_len = max(max_cg_len, _safe_max_str_len(data["cg_id"]))
            max_strand_len = max(max_strand_len, _safe_max_str_len(data["strand"]))

    return total_entries, kmer_len, max_label_len, max_cg_len, max_strand_len


def process_chunk(args):
    (
        chunk_idx,
        input_bam,
        start_offset,
        end_offset,
        upstream_nt,
        downstream_nt,
        motif,
        label,
        log_level,
        log_queue,
        tmp_dir,
        ndiff,
        read_batch_size,
        feature_buffer_size,
    ) = args

    configure_worker_logger(log_level, log_queue)
    chunk_start = time.time()
    total_reads = 0
    batch_idx = 0

    def flush_chunk(part_idx, enc_list, ipd_list, pw_list, labels_list, cg_id_list, kmer_seq_list, strand_list):
        if len(enc_list) == 0:
            return None
        encode_kmer_arr = np.vstack(enc_list)  # shape (N, L)
        ipd_arr = np.vstack(ipd_list).astype(np.float32)
        pw_arr = np.vstack(pw_list).astype(np.float32)
        kmer_seq_arr = np.array(kmer_seq_list, dtype="<U1")
        labels_arr = np.array(labels_list, dtype=object)
        cg_id_arr = np.array(cg_id_list, dtype=object)
        strand_arr = np.array(strand_list, dtype=object)

        chunk_file = os.path.join(tmp_dir, f"chunk_{chunk_idx}_{part_idx}.npz")
        np.savez(
            chunk_file,
            encode_kmer=encode_kmer_arr,
            ipd=ipd_arr,
            pw=pw_arr,
            label=labels_arr,
            cg_id=cg_id_arr,
            kmer_seq=kmer_seq_arr,
            strand=strand_arr,
        )
        logging.info(f"Saved chunk {chunk_idx} part {part_idx} with {encode_kmer_arr.shape[0]} features to {chunk_file}")
        return encode_kmer_arr.shape[0]

    # Build columnar arrays for this chunk (efficient layout)
    enc_list = []
    ipd_list = []
    pw_list = []
    labels_list = []
    cg_id_list = []
    kmer_seq_list = []
    strand_list = []

    skipped_reads = 0
    skipped_cpgs = 0
    missing_reads = []
    empty_reads = []
    low_value_reads_info = []
    diff_reads_info = []
    total_features = 0
    part_idx = 0

    with pysam.AlignmentFile(input_bam, "rb", check_sq=False) as bam:
        bam.seek(start_offset)
        while True:
            batch = []
            while len(batch) < read_batch_size:
                if end_offset is not None and bam.tell() >= end_offset:
                    break
                try:
                    read = next(bam)
                except StopIteration:
                    break
                batch.append(read)
            if not batch:
                break
            total_reads += len(batch)
            print(f"Chunk {chunk_idx}: batch {batch_idx} reads {len(batch)}")
            batch_idx += 1

            # Extract features (pass ndiff to utilities)
            try:
                (
                    bam_features,
                    skipped_reads_batch,
                    skipped_cpgs_batch,
                    missing_reads_batch,
                    empty_reads_batch,
                    low_value_reads_batch,
                    diff_reads_batch,
                ) = get_features_from_reads(batch, upstream_nt, downstream_nt, motif, ndiff=ndiff)
            except TypeError:
                # Fallback in case get_features_from_reads has different signature
                try:
                    (
                        bam_features,
                        skipped_reads_batch,
                        skipped_cpgs_batch,
                        missing_reads_batch,
                        empty_reads_batch,
                        low_value_reads_batch,
                        diff_reads_batch,
                    ) = get_features_from_reads(batch, upstream_nt, downstream_nt, motif, ndiff)
                except TypeError:
                    (
                        bam_features,
                        skipped_reads_batch,
                        skipped_cpgs_batch,
                        missing_reads_batch,
                        empty_reads_batch,
                        low_value_reads_batch,
                        diff_reads_batch,
                    ) = get_features_from_reads(batch, upstream_nt, downstream_nt, motif)

            skipped_reads += skipped_reads_batch
            skipped_cpgs += skipped_cpgs_batch
            missing_reads.extend(missing_reads_batch)
            empty_reads.extend(empty_reads_batch)
            low_value_reads_info.extend(low_value_reads_batch)
            diff_reads_info.extend(diff_reads_batch)

            kmer_len = None
            for f in bam_features:
                # f is expected to be a tuple/list as in original script:
                # f[0]..f[4] parts for id, f[5]=kmer (string), f[6]=ipd (string), f[7]=pw (string), f[8]=n_pass (maybe)
                try:
                    cid = f"{f[0]}_{f[1]}_{f[2]}_{f[3]}_{f[4]}"
                    kmer = f[5]
                    ipd_s = f[6]
                    pw_s = f[7]
                except Exception:
                    # skip malformed
                    continue

                if not kmer:
                    # Skip empty kmers to keep arrays stackable
                    continue
                if kmer_len is None:
                    kmer_len = len(kmer)
                if len(kmer) != kmer_len:
                    logging.warning(
                        f"{cid}: Skipping kmer with length {len(kmer)} (expected {kmer_len})."
                    )
                    continue

                # encode and parse
                enc = encode_kmer_string(kmer)
                ipd_arr = parse_ipd_pw(ipd_s, kmer_len)
                pw_arr = parse_ipd_pw(pw_s, kmer_len)
                seq_chars = list(kmer)

                enc_list.append(enc)
                ipd_list.append(ipd_arr)
                pw_list.append(pw_arr)
                kmer_seq_list.append(seq_chars)
                labels_list.append(label)
                cg_id_list.append(cid)
                strand_list.append(extract_strand_from_id(cid))

                if len(enc_list) >= feature_buffer_size:
                    wrote = flush_chunk(part_idx, enc_list, ipd_list, pw_list, labels_list, cg_id_list, kmer_seq_list, strand_list)
                    if wrote is not None:
                        total_features += wrote
                    part_idx += 1
                    enc_list = []
                    ipd_list = []
                    pw_list = []
                    labels_list = []
                    cg_id_list = []
                    kmer_seq_list = []
                    strand_list = []

    if len(enc_list) > 0:
        wrote = flush_chunk(part_idx, enc_list, ipd_list, pw_list, labels_list, cg_id_list, kmer_seq_list, strand_list)
        if wrote is not None:
            total_features += wrote

    elapsed = time.time() - chunk_start
    print(f"Chunk {chunk_idx}: total reads {total_reads}, features {total_features}, time {elapsed:.2f}s")
    return (
        total_features,
        skipped_reads,
        skipped_cpgs,
        missing_reads,
        empty_reads,
        low_value_reads_info,
        diff_reads_info,
    )


def combine_npz_files(tmp_chunk_dir, output_npz, combine_tmpdir):
    """
    Combine chunk .npz files into a single final compressed .npz with keys:
      encode_kmer, ipd, pw, label, cg_id, kmer_seq, strand

    This version avoids loading all chunks into memory by:
      1) Scanning chunk files for total size and string lengths.
      2) Writing each field into on-disk memmaps.
      3) Saving the final compressed NPZ from memmaps.
    """
    tmp_chunk_files = sorted(
        [os.path.join(tmp_chunk_dir, f) for f in os.listdir(tmp_chunk_dir) if f.startswith("chunk_") and f.endswith(".npz")]
    )

    if len(tmp_chunk_files) == 0:
        logging.warning("No chunk files found to combine.")
        np.savez_compressed(
            output_npz,
            encode_kmer=np.zeros((0, 0), dtype=np.uint8),
            ipd=np.zeros((0, 0), dtype=np.float32),
            pw=np.zeros((0, 0), dtype=np.float32),
            label=np.array([], dtype=object),
            cg_id=np.array([], dtype=object),
            kmer_seq=np.zeros((0, 0), dtype="<U1"),
            strand=np.array([], dtype=object),
        )
        print(f"✅ Final compressed file saved: {output_npz} (empty)")
        return

    total_entries, kmer_len, max_label_len, max_cg_len, max_strand_len = _scan_chunk_metadata(tmp_chunk_files)
    if total_entries == 0:
        logging.warning("All chunk files contained zero entries.")
        np.savez_compressed(
            output_npz,
            encode_kmer=np.zeros((0, 0), dtype=np.uint8),
            ipd=np.zeros((0, 0), dtype=np.float32),
            pw=np.zeros((0, 0), dtype=np.float32),
            label=np.array([], dtype=object),
            cg_id=np.array([], dtype=object),
            kmer_seq=np.zeros((0, 0), dtype="<U1"),
            strand=np.array([], dtype=object),
        )
        print(f"✅ Final compressed file saved: {output_npz} (empty)")
        return

    os.makedirs(combine_tmpdir, exist_ok=True)
    label_dtype = f"<U{max(1, max_label_len)}"
    cg_dtype = f"<U{max(1, max_cg_len)}"
    strand_dtype = f"<U{max(1, max_strand_len)}"

    encode_kmer_mm = np.lib.format.open_memmap(
        os.path.join(combine_tmpdir, "encode_kmer.npy"),
        mode="w+",
        dtype=np.uint8,
        shape=(total_entries, kmer_len),
    )
    ipd_mm = np.lib.format.open_memmap(
        os.path.join(combine_tmpdir, "ipd.npy"),
        mode="w+",
        dtype=np.float32,
        shape=(total_entries, kmer_len),
    )
    pw_mm = np.lib.format.open_memmap(
        os.path.join(combine_tmpdir, "pw.npy"),
        mode="w+",
        dtype=np.float32,
        shape=(total_entries, kmer_len),
    )
    kmer_seq_mm = np.lib.format.open_memmap(
        os.path.join(combine_tmpdir, "kmer_seq.npy"),
        mode="w+",
        dtype="<U1",
        shape=(total_entries, kmer_len),
    )
    label_mm = np.lib.format.open_memmap(
        os.path.join(combine_tmpdir, "label.npy"),
        mode="w+",
        dtype=label_dtype,
        shape=(total_entries,),
    )
    cg_mm = np.lib.format.open_memmap(
        os.path.join(combine_tmpdir, "cg_id.npy"),
        mode="w+",
        dtype=cg_dtype,
        shape=(total_entries,),
    )
    strand_mm = np.lib.format.open_memmap(
        os.path.join(combine_tmpdir, "strand.npy"),
        mode="w+",
        dtype=strand_dtype,
        shape=(total_entries,),
    )

    offset = 0
    for chunk_file in tqdm(tmp_chunk_files, desc="Combining chunks"):
        with np.load(chunk_file, allow_pickle=True) as data:
            enc = data["encode_kmer"]
            n = enc.shape[0]
            if n == 0:
                continue
            end = offset + n
            encode_kmer_mm[offset:end] = enc
            ipd_mm[offset:end] = data["ipd"].astype(np.float32, copy=False)
            pw_mm[offset:end] = data["pw"].astype(np.float32, copy=False)
            kmer_seq_mm[offset:end] = data["kmer_seq"].astype("<U1", copy=False)
            label_mm[offset:end] = data["label"].astype(label_dtype, copy=False)
            cg_mm[offset:end] = data["cg_id"].astype(cg_dtype, copy=False)
            strand_mm[offset:end] = data["strand"].astype(strand_dtype, copy=False)
            offset = end

    if offset != total_entries:
        raise RuntimeError(f"Combine mismatch: expected {total_entries} entries, wrote {offset}")

    np.savez_compressed(
        output_npz,
        encode_kmer=encode_kmer_mm,
        ipd=ipd_mm,
        pw=pw_mm,
        label=label_mm,
        cg_id=cg_mm,
        kmer_seq=kmer_seq_mm,
        strand=strand_mm,
    )

    print(f"✅ Final compressed file saved: {output_npz} with {total_entries} entries")


def split_npz_into_train_test(npz_path, test_fraction, seed=None):
    """
    Split a combined NPZ file into train/test subsets and save them next to the
    original file. Files are named <original>_train.npz and <original>_test.npz.
    """
    if not 0 < test_fraction < 1:
        raise ValueError("test_fraction must be between 0 and 1 (exclusive)")

    base, ext = os.path.splitext(npz_path)
    train_path = f"{base}_train{ext}"
    test_path = f"{base}_test{ext}"

    with np.load(npz_path, allow_pickle=True) as data:
        arrays = {key: data[key] for key in data.files}

    total = arrays["encode_kmer"].shape[0]
    if total == 0:
        for path in (train_path, test_path):
            np.savez_compressed(path, **arrays)
        logging.info(f"Train/test split requested but no entries were present. Empty files saved to {train_path} and {test_path}.")
        return train_path, test_path, 0, 0

    rng = np.random.default_rng(seed)
    indices = np.arange(total)
    rng.shuffle(indices)

    test_count = int(round(total * test_fraction))
    test_count = min(max(test_count, 1), total - 1)
    test_idx = indices[:test_count]
    train_idx = indices[test_count:]

    def subset(arr, idx):
        return arr[idx]

    train_arrays = {key: subset(value, train_idx) for key, value in arrays.items()}
    test_arrays = {key: subset(value, test_idx) for key, value in arrays.items()}

    np.savez_compressed(train_path, **train_arrays)
    np.savez_compressed(test_path, **test_arrays)

    logging.info(
        f"Saved train/test splits with {len(train_idx)} and {len(test_idx)} entries to {train_path} / {test_path}"
    )
    return train_path, test_path, len(train_idx), len(test_idx)


def split_chunks_into_train_test(tmp_chunk_dir, output_npz, test_fraction, seed=None):
    """
    Split using chunk files on disk to avoid loading the full combined NPZ into memory.
    Produces <output>_train.npz and <output>_test.npz.
    """
    if not 0 < test_fraction < 1:
        raise ValueError("test_fraction must be between 0 and 1 (exclusive)")

    base, ext = os.path.splitext(output_npz)
    train_path = f"{base}_train{ext}"
    test_path = f"{base}_test{ext}"

    tmp_chunk_files = sorted(
        [os.path.join(tmp_chunk_dir, f) for f in os.listdir(tmp_chunk_dir) if f.startswith("chunk_") and f.endswith(".npz")]
    )
    if len(tmp_chunk_files) == 0:
        logging.warning("No chunk files found for train/test split.")
        for path in (train_path, test_path):
            np.savez_compressed(
                path,
                encode_kmer=np.zeros((0, 0), dtype=np.uint8),
                ipd=np.zeros((0, 0), dtype=np.float32),
                pw=np.zeros((0, 0), dtype=np.float32),
                label=np.array([], dtype=object),
                cg_id=np.array([], dtype=object),
                kmer_seq=np.zeros((0, 0), dtype="<U1"),
                strand=np.array([], dtype=object),
            )
        return train_path, test_path, 0, 0

    total_entries, _, _, _, _ = _scan_chunk_metadata(tmp_chunk_files)
    if total_entries == 0:
        logging.warning("All chunk files were empty for train/test split.")
        for path in (train_path, test_path):
            np.savez_compressed(
                path,
                encode_kmer=np.zeros((0, 0), dtype=np.uint8),
                ipd=np.zeros((0, 0), dtype=np.float32),
                pw=np.zeros((0, 0), dtype=np.float32),
                label=np.array([], dtype=object),
                cg_id=np.array([], dtype=object),
                kmer_seq=np.zeros((0, 0), dtype="<U1"),
                strand=np.array([], dtype=object),
            )
        return train_path, test_path, 0, 0

    test_count = int(round(total_entries * test_fraction))
    test_count = min(max(test_count, 1), total_entries - 1)

    rng = np.random.default_rng(seed)
    train_tmpdir = os.path.join(os.path.dirname(output_npz) or ".", "tmp_split_train")
    test_tmpdir = os.path.join(os.path.dirname(output_npz) or ".", "tmp_split_test")
    os.makedirs(train_tmpdir, exist_ok=True)
    os.makedirs(test_tmpdir, exist_ok=True)

    remaining_rows = total_entries
    remaining_test = test_count
    train_idx = 0
    test_idx = 0

    for chunk_file in tqdm(tmp_chunk_files, desc="Splitting chunks"):
        with np.load(chunk_file, allow_pickle=True) as data:
            enc = data["encode_kmer"]
            n = enc.shape[0]
            if n == 0:
                continue

            if remaining_rows == n:
                k_test = remaining_test
            else:
                k_test = int(round(n * remaining_test / remaining_rows))
            k_test = max(0, min(k_test, n, remaining_test))

            if k_test > 0:
                test_idx_arr = rng.choice(n, size=k_test, replace=False)
                test_mask = np.zeros(n, dtype=bool)
                test_mask[test_idx_arr] = True
            else:
                test_mask = np.zeros(n, dtype=bool)

            train_mask = ~test_mask

            if train_mask.any():
                np.savez(
                    os.path.join(train_tmpdir, f"chunk_{train_idx}.npz"),
                    encode_kmer=enc[train_mask],
                    ipd=data["ipd"][train_mask].astype(np.float32, copy=False),
                    pw=data["pw"][train_mask].astype(np.float32, copy=False),
                    label=data["label"][train_mask],
                    cg_id=data["cg_id"][train_mask],
                    kmer_seq=data["kmer_seq"][train_mask],
                    strand=data["strand"][train_mask],
                )
                train_idx += 1

            if test_mask.any():
                np.savez(
                    os.path.join(test_tmpdir, f"chunk_{test_idx}.npz"),
                    encode_kmer=enc[test_mask],
                    ipd=data["ipd"][test_mask].astype(np.float32, copy=False),
                    pw=data["pw"][test_mask].astype(np.float32, copy=False),
                    label=data["label"][test_mask],
                    cg_id=data["cg_id"][test_mask],
                    kmer_seq=data["kmer_seq"][test_mask],
                    strand=data["strand"][test_mask],
                )
                test_idx += 1

            remaining_rows -= n
            remaining_test -= k_test

    combine_tmp_train = os.path.join(os.path.dirname(output_npz) or ".", "combine_tmp_train")
    combine_tmp_test = os.path.join(os.path.dirname(output_npz) or ".", "combine_tmp_test")
    try:
        combine_npz_files(train_tmpdir, train_path, combine_tmp_train)
        combine_npz_files(test_tmpdir, test_path, combine_tmp_test)
    finally:
        shutil.rmtree(train_tmpdir, ignore_errors=True)
        shutil.rmtree(test_tmpdir, ignore_errors=True)
        shutil.rmtree(combine_tmp_train, ignore_errors=True)
        shutil.rmtree(combine_tmp_test, ignore_errors=True)

    train_total = total_entries - test_count
    return train_path, test_path, train_total, test_count


def extract_features(
    input_bam,
    output_path_or_dir,
    threads,
    motif,
    upstream_nt,
    downstream_nt,
    label,
    chunk_size,
    log_level,
    log_queue,
    ndiff,
    read_batch_size,
    feature_buffer_size,
    keep_chunks=False,
    split_fraction=None,
    split_seed=None,
):
    start_time = time.time()
    check_files_paths(input_bam)
    print("Step 1/5: preparing output paths and temp directories...")

    bam_basename = os.path.splitext(os.path.basename(input_bam))[0]

    # Determine whether the provided output is a final .npz file path or a base output folder.
    out_ext = os.path.splitext(output_path_or_dir)[1].lower()
    if out_ext == ".npz":
        # User provided a full output filename (possibly with path)
        output_npz = output_path_or_dir
        output_dir = os.path.dirname(output_npz) or "."
        os.makedirs(output_dir, exist_ok=True)
        output_tmpdir = os.path.join(output_dir, f"tmp_chunks_{bam_basename}")
    else:
        # Treat as base output folder (legacy behavior): create subfolder named after bam basename
        output_base_dir = output_path_or_dir
        output_dir = os.path.join(output_base_dir, bam_basename)
        os.makedirs(output_dir, exist_ok=True)
        output_tmpdir = os.path.join(output_dir, f"tmp_chunks_{bam_basename}")
        output_npz = os.path.join(output_dir, f"{bam_basename}.npz")

    os.makedirs(output_tmpdir, exist_ok=True)

    if chunk_size is None:
        print("Step 2/5: calculating chunk size...")
        chunk_size = calculate_optimal_chunk_size(
            input_bam, threads, multiplier=4, log_level=log_level
        )
    else:
        logging.info(f"Chunk size is predefined: {chunk_size}")

    print("Step 3/5: calculating read offsets...")
    logging.info("Calculating chunk offsets for parallel processing...")
    offsets = get_read_offsets(input_bam, chunk_size)

    chunk_args = []
    for i in range(len(offsets)):
        start_offset = offsets[i]
        end_offset = offsets[i + 1] if i + 1 < len(offsets) else None
        chunk_args.append(
            (
                i,
                input_bam,
                start_offset,
                end_offset,
                upstream_nt,
                downstream_nt,
                motif,
                label,
                log_level,
                log_queue,
                output_tmpdir,
                ndiff,
                read_batch_size,
                feature_buffer_size,
            )
        )

    logging.info(f"Starting {threads} parallel processes for chunk processing...")
    print("Step 4/5: processing chunks...")
    pool = mp.Pool(threads, initializer=configure_worker_logger, initargs=(log_level, log_queue))
    try:
        list(tqdm(pool.imap(process_chunk, chunk_args), total=len(chunk_args), desc="Processing chunks"))
    finally:
        pool.close()
        pool.join()

    combine_tmpdir = os.path.join(output_dir, f"combine_tmp_{bam_basename}")
    try:
        print("Step 5/5: combining chunks...")
        combine_npz_files(output_tmpdir, output_npz, combine_tmpdir)
    finally:
        if os.path.exists(combine_tmpdir):
            shutil.rmtree(combine_tmpdir, ignore_errors=True)

    if split_fraction is not None:
        try:
            print("Step 6: splitting train/test...")
            split_chunks_into_train_test(output_tmpdir, output_npz, split_fraction, seed=split_seed)
        except ValueError as exc:
            logging.error(f"Train/test split failed: {exc}")
            raise
        finally:
            if not keep_chunks:
                remove_tmp_dir(output_tmpdir)

    elapsed = time.time() - start_time
    logging.info(f"Feature extraction finished in {elapsed:.2f} seconds")
    print(f"Saved combined features to: {output_npz}")

    if split_fraction is None and not keep_chunks:
        remove_tmp_dir(output_tmpdir)


def main(argv=None):
    parser = argparse.ArgumentParser(description="Extract features from BAM and save as NPZ")
    parser.add_argument("-i", "--input", required=True, help="Input BAM file")
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Output NPZ file path (e.g. /path/to/file.npz) or base output folder. "
             "If a path ending with .npz is provided it will be used as final filename; "
             "otherwise a folder will be created named <output>/<bam_basename>/ and the final file will be placed there.",
    )
    parser.add_argument("-t", "--threads", type=int, default=4, help="Number of threads")
    parser.add_argument("-m", "--motif", type=str, default="CG", help="Motif to search for")
    parser.add_argument("-u", "--upstream_nt", type=int, default=10, help="Number of upstream nucleotides")
    parser.add_argument("-d", "--downstream_nt", type=int, default=10, help="Number of downstream nucleotides")
    parser.add_argument("--label", required=True, help="Label string for this BAM/class")
    parser.add_argument("-c", "--chunk-size", type=int, default=None, help="Number of reads per chunk (optional)")
    parser.add_argument("--log-level", choices=["OFF", "ERROR", "WARN", "INFO"], default="ERROR", help="Logging level")
    parser.add_argument("--log-file", type=str, default=None, help="If set, logs will be written to this file")
    parser.add_argument("--keep-chunks", action="store_true", help="Keep temporary chunk folder for debugging")

    # New filtering arguments:
    parser.add_argument(
        "--ndiff",
        type=int,
        default=0,
        help="Maximum allowed fn/rn difference to keep a read. Default 0 => no filtering based on fn/rn difference.",
    )
    parser.add_argument(
        "--read-batch-size",
        type=int,
        default=1000,
        help="Number of reads to process per batch inside each chunk to limit memory usage.",
    )
    parser.add_argument(
        "--feature-buffer-size",
        type=int,
        default=50000,
        help="Number of extracted features to buffer before flushing a part file.",
    )
    parser.add_argument(
        "--split-train-test",
        type=float,
        default=None,
        metavar="TEST_RATIO",
        help="If provided, split the final NPZ into train/test files with the given test ratio (0-1).",
    )
    parser.add_argument(
        "--split-seed",
        type=int,
        default=None,
        help="Random seed for the optional train/test split.",
    )

    args = parser.parse_args(argv)
    log_queue = mp.Manager().Queue() if args.log_file or args.log_level != "OFF" else None
    listener = configure_main_logger(args.log_level, args.log_file, log_queue=log_queue)
    logging.info(f"Command: {' '.join(sys.argv)}")

    try:
        extract_features(
            args.input,
            args.output,
            args.threads,
            args.motif,
            args.upstream_nt,
            args.downstream_nt,
            args.label,
            args.chunk_size,
            args.log_level,
            log_queue,
            args.ndiff,
            args.read_batch_size,
            args.feature_buffer_size,
            keep_chunks=args.keep_chunks,
            split_fraction=args.split_train_test,
            split_seed=args.split_seed,
        )
    finally:
        if listener:
            listener.stop()


if __name__ == "__main__":
    main()
