import torch
import os
import numpy as np
from torch.utils.data import Dataset
import time
from random import sample
import os
from tqdm import tqdm
import numpy as np
import pysam
import torch
from sklearn import preprocessing
from torch.utils.data import Dataset, DataLoader
from .utilities import *
# ============================================================
# Small helper dataset
# ============================================================
class ArrayDataset(Dataset):
    def __init__(self, encode_kmer_arr, ipd_arr, pw_arr, labels_arr):
        # Expect numpy arrays
        assert len(encode_kmer_arr) == len(ipd_arr) == len(pw_arr) == len(labels_arr), "Array length mismatch"
        self.encode_kmer = encode_kmer_arr
        self.ipd = ipd_arr
        self.pw = pw_arr
        self.labels = labels_arr
        self.lenghts = len(ipd_arr)
        

    def __len__(self):

        return self.lenghts

    def __getitem__(self, idx):
        ek = torch.from_numpy(self.encode_kmer[idx]).float()
        ipd = torch.from_numpy(self.ipd[idx]).float()
        pw = torch.from_numpy(self.pw[idx]).float()
        label = torch.tensor(self.labels[idx], dtype=torch.long)
        return ek, ipd, pw, label


def convert_data(input):
    encoding_dict = {'A': 0, 'T': 3, 'G': 2, 'C': 1, 'N': 4}
    encode = np.array([encoding_dict.get(x, 0) for x in input[1]])
    ipd = np.array([float(x) for x in input[2].split(",")], dtype=float)
    pw = np.array([float(x) for x in input[3].split(",")], dtype=float)
    npass = np.array([int(input[4])] * len(input[1]))

    return {
        "cg_id": input[0], "kmer_seq": input[1], 'encode_kmer': encode,
        'ipd': ipd, 'pw': pw, 'npass': npass
    }


class ChunkedMyDataset(Dataset):
    def __init__(self, features):
        self.features = features

    def __len__(self):
        return len(self.features)

    def __getitem__(self, index):
        key = self.features[index]
        dna = convert_data(key)
        cg_id = dna["cg_id"]
        kmer_seq = dna["kmer_seq"]
        encode_kmer = dna["encode_kmer"].astype(np.float64)
        ipd = dna["ipd"].astype(np.float64)
        pw = dna["pw"].astype(np.float64)
        npass = dna["npass"].astype(np.float64)

        return cg_id, kmer_seq, encode_kmer, ipd, pw, npass