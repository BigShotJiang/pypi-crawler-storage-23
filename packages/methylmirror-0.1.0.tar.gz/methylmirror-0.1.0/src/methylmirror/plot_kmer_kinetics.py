import argparse
import numpy as np
import matplotlib.pyplot as plt
import re
import os
import logging

def setup_logging(loglevel="INFO"):
    numeric_level = getattr(logging, loglevel.upper(), None)
    if not isinstance(numeric_level, int):
        raise ValueError(f'Invalid log level: {loglevel}')
    logging.basicConfig(
        level=numeric_level,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

def parse_region(region_string):
    m = re.match(r"^([^:]+)(?::(\d+)-(\d+))?$", region_string)
    if not m:
        raise ValueError(f"Region format must be chr or chr:start-end (got: {region_string})")
    chrom = m.group(1)
    start = int(m.group(2)) if m.group(2) else None
    end = int(m.group(3)) if m.group(3) else None
    return chrom, start, end

def region_mask(cg_ids, chrom, start, end):
    mask = []
    for s in cg_ids:
        toks = s.split("_")
        if len(toks) < 4:
            mask.append(False)
            continue
        chrom_this = toks[1]
        pos_this = toks[2]
        try:
            pos_this = int(pos_this)
        except:
            mask.append(False)
            continue
        if chrom != chrom_this:
            mask.append(False)
            continue
        if start is not None and int(pos_this) < start:
            mask.append(False)
            continue
        if end is not None and int(pos_this) > end:
            mask.append(False)
            continue
        mask.append(True)
    return np.array(mask, dtype=bool)

def mean_along_kmer(arr, max_entries=0):
    if max_entries > 0 and len(arr) > max_entries:
        arr = arr[:max_entries]
    arr = arr[~np.all(arr == 0, axis=1)]
    if len(arr) == 0:
        return np.zeros(arr.shape[1])
    return np.nanmean(arr, axis=0)

def main():
    parser = argparse.ArgumentParser(description="Plot mean IPD and PW per kmer position from (multiple) npz files.")
    parser.add_argument("-i", "--inputs", nargs="+", required=True, help="Input .npz files")
    parser.add_argument("--labels", nargs="+", default=None, help="Deprecated alias for legend labels; use --methylation-names")
    parser.add_argument(
        "--methylation-names",
        nargs="+",
        default=None,
        help="Legend names for each input (e.g., methylation conditions), default: filenames",
    )
    parser.add_argument("--max", type=int, default=0, help="Max entries per file (0=all)")
    parser.add_argument("--region", type=str, default=None, help="Region filter: chr or chr:start-end")
    parser.add_argument(
        "-o",
        "--output",
        type=str,
        default=None,
        help="Output prefix for saved plots (writes OUTPUT_ipd.png and OUTPUT_pw.png).",
    )
    parser.add_argument(
        "--outprefix",
        type=str,
        default=None,
        help="Deprecated alias of --output (kept for backward compatibility).",
    )
    parser.add_argument("--pdf", action="store_true", help="Also save plots as PDF")
    parser.add_argument("--svg", action="store_true", help="Also save plots as SVG")
    parser.add_argument("--loglevel", type=str, default="INFO", help="Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)")
    args = parser.parse_args()
    output_prefix = args.output or args.outprefix

    setup_logging(args.loglevel)

    # Legend labels: prefer --methylation-names, then legacy --labels, else derive from filenames.
    if args.methylation_names is not None:
        legend_labels = args.methylation_names
    elif args.labels is not None:
        legend_labels = args.labels
    else:
        legend_labels = [os.path.splitext(os.path.basename(f))[0] for f in args.inputs]
    assert len(legend_labels) == len(args.inputs), "--methylation-names/--labels must match number of inputs"

    region = None
    if args.region:
        try:
            region = parse_region(args.region)
            logging.info(f"Region filter set: {region}")
        except Exception as e:
            logging.error(f"Failed to parse region: {e}")
            raise

    # IPD Plot
    plt.figure(figsize=(8,5))
    for npzfile, label in zip(args.inputs, legend_labels):
        logging.info(f"Loading file: {npzfile}")
        try:
            data = np.load(npzfile, allow_pickle=True)
            ipd = data["ipd"]
            pw = data["pw"]
            cg_id = data["cg_id"]
            logging.debug(f"Loaded arrays from {npzfile}: ipd shape {ipd.shape}, pw shape {pw.shape}, cg_id length {len(cg_id)}")
            if region:
                mask = region_mask(cg_id, *region)
                ipd = ipd[mask]
                pw = pw[mask]
                logging.info(f"Applied region mask: {np.sum(mask)} entries kept from {len(mask)}")
            mean_ipd = mean_along_kmer(ipd, args.max)
            plt.plot(np.arange(1, len(mean_ipd)+1), mean_ipd, label=label)
            logging.info(f"Plotted mean IPD for {label}")
        except Exception as e:
            logging.error(f"Error processing file {npzfile}: {e}")
            continue
    plt.xlim(0, 22)
    plt.xticks(np.arange(1, 22, 1))
    plt.axvspan(10.5, 11.5, color='lightgrey', alpha=0.5, zorder=0)  # C
    plt.axvspan(11.5, 12.5, color='lightgrey', alpha=0.5, zorder=0)  # G
    plt.xlabel("Kmer Position")
    plt.ylabel("Mean IPD")
    plt.title("Mean IPD per Kmer Position")
    plt.legend(loc="center left", bbox_to_anchor=(1.02, 0.5), borderaxespad=0.0)
    plt.tight_layout(rect=[0, 0, 0.82, 1])
    if output_prefix:
        plt.savefig(f"{output_prefix}_ipd.png", dpi=150)
        logging.info(f"Saved IPD plot as {output_prefix}_ipd.png")
        if args.pdf:
            plt.savefig(f"{output_prefix}_ipd.pdf")
            logging.info(f"Saved IPD plot as {output_prefix}_ipd.pdf")
        if args.svg:
            plt.savefig(f"{output_prefix}_ipd.svg")
            logging.info(f"Saved IPD plot as {output_prefix}_ipd.svg")
    plt.show()

    # PW Plot
    plt.figure(figsize=(8,5))
    for npzfile, label in zip(args.inputs, legend_labels):
        logging.info(f"Loading file: {npzfile}")
        try:
            data = np.load(npzfile, allow_pickle=True)
            pw = data["pw"]
            cg_id = data["cg_id"]
            if region:
                mask = region_mask(cg_id, *region)
                pw = pw[mask]
                logging.info(f"Applied region mask: {np.sum(mask)} entries kept from {len(mask)}")
            mean_pw = mean_along_kmer(pw, args.max)
            plt.plot(np.arange(1, len(mean_pw)+1), mean_pw, label=label)
            logging.info(f"Plotted mean PW for {label}")
        except Exception as e:
            logging.error(f"Error processing file {npzfile}: {e}")
            continue
    plt.xlim(0, 22)
    plt.xticks(np.arange(1, 22, 1))
    plt.axvspan(10.5, 11.5, color='lightgrey', alpha=0.5, zorder=0)
    plt.axvspan(11.5, 12.5, color='lightgrey', alpha=0.5, zorder=0)
    plt.xlabel("Kmer Position")
    plt.ylabel("Mean PW")
    plt.title("Mean PW per Kmer Position")
    plt.legend(loc="center left", bbox_to_anchor=(1.02, 0.5), borderaxespad=0.0)
    plt.tight_layout(rect=[0, 0, 0.82, 1])
    if output_prefix:
        plt.savefig(f"{output_prefix}_pw.png", dpi=150)
        logging.info(f"Saved PW plot as {output_prefix}_pw.png")
        if args.pdf:
            plt.savefig(f"{output_prefix}_pw.pdf")
            logging.info(f"Saved PW plot as {output_prefix}_pw.pdf")
        if args.svg:
            plt.savefig(f"{output_prefix}_pw.svg")
            logging.info(f"Saved PW plot as {output_prefix}_pw.svg")
    plt.show()

if __name__ == "__main__":
    main()
