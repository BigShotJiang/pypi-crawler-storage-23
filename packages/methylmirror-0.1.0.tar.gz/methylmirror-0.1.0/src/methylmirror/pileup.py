#!/usr/bin/env python3
"""
Strand- and position-correct CpG pileup for modBAM/MM/ML with 5mC and 5hmC.
Aggregates MM/ML info across reads onto the reference CpG cytosine.

Output (9-state):
CC, CM, MC, MM, CH, HC, HH, MH, HM (plus strand first, minus strand second).
"""

import argparse
import gzip
import logging
import pysam
import numpy as np
from collections import defaultdict

try:
    from Bio import SeqIO
except ImportError:
    SeqIO = None


def find_cpgs_in_fasta(fasta):
    if not SeqIO:
        raise ImportError("Biopython erforderlich für --fasta!")
    cpg_dict = {}
    for rec in SeqIO.parse(fasta, "fasta"):
        seq = str(rec.seq).upper()
        c_list = [i for i in range(len(seq) - 1) if seq[i] == "C" and seq[i + 1] == "G"]
        cpg_dict[rec.id] = set(c_list)
    return cpg_dict


def _get_cytosine_positions(sequence):
    return np.array([i for i, base in enumerate(sequence) if base == "C"])


def _get_guanine_positions(sequence):
    return np.array([i for i, base in enumerate(sequence) if base == "G"])


def _get_CpG_pos(cytosine_positions, guanine_positions):
    return cytosine_positions[np.isin(cytosine_positions + 1, guanine_positions)]


def _parse_delta_mm_string(s):
    if not s or "," not in s:
        return np.array([], dtype=int)
    vals = [int(v) for v in s.split(",")[1:] if v != ""]
    idx = np.cumsum(vals) + np.arange(len(vals))
    return np.array(idx, dtype=int)


def _get_indices_from_MM(read):
    if read.has_tag("MM") or read.has_tag("Mm"):
        mm_tag = read.get_tag("MM") if read.has_tag("MM") else read.get_tag("Mm")
        strand_strings = [s.strip() for s in mm_tag.split(";") if s.strip() != ""]
        plus_m = plus_h = minus_m = minus_h = None
        include_h = False
        for s in strand_strings:
            if s.startswith("C+m"):
                plus_m = s
            elif s.startswith("C+h"):
                plus_h = s
                include_h = True
            elif s.startswith("G-m"):
                minus_m = s
            elif s.startswith("G-h"):
                minus_h = s
                include_h = True
        plus_m_idxs = _parse_delta_mm_string(plus_m)
        plus_h_idxs = _parse_delta_mm_string(plus_h)
        minus_m_idxs = _parse_delta_mm_string(minus_m)
        minus_h_idxs = _parse_delta_mm_string(minus_h)
        return plus_m_idxs, plus_h_idxs, minus_m_idxs, minus_h_idxs, include_h
    return (np.array([], dtype=int), np.array([], dtype=int),
            np.array([], dtype=int), np.array([], dtype=int), False)


def _get_predictions_from_ML(read, n_c_m, n_c_h, n_g_m, n_g_h, include_h):
    if (read.has_tag("MM") or read.has_tag("Mm")) and (read.has_tag("ML") or read.has_tag("Ml")):
        ml_tag = read.get_tag("ML") if read.has_tag("ML") else read.get_tag("Ml")
        ml_tag = np.array(ml_tag)
        if include_h:
            expected = n_c_m + n_c_h + n_g_m + n_g_h
            if len(ml_tag) != expected:
                raise ValueError("Number of ML entries does not match MM tag entries")
            plus_m = ml_tag[0:n_c_m]
            plus_h = ml_tag[n_c_m:n_c_m + n_c_h]
            minus_m = ml_tag[n_c_m + n_c_h:n_c_m + n_c_h + n_g_m]
            minus_h = ml_tag[n_c_m + n_c_h + n_g_m:expected]
        else:
            expected = n_c_m + n_g_m
            if len(ml_tag) != expected:
                raise ValueError("Number of ML entries does not match MM tag entries")
            plus_m = ml_tag[0:n_c_m]
            plus_h = np.array([], dtype=int)
            minus_m = ml_tag[n_c_m:n_c_m + n_g_m]
            minus_h = np.array([], dtype=int)
        return plus_m, plus_h, minus_m, minus_h
    return (np.array([], dtype=int), np.array([], dtype=int),
            np.array([], dtype=int), np.array([], dtype=int))


def _positions_above_cutoff(c_m_pos, c_h_pos, g_m_pos, g_h_pos,
                            ml_plus_m, ml_plus_h, ml_minus_m, ml_minus_h, cutoff):
    plus_m_above = c_m_pos[ml_plus_m > cutoff] if ml_plus_m.size > 0 else np.array([], dtype=int)
    plus_h_above = c_h_pos[ml_plus_h > cutoff] if ml_plus_h.size > 0 else np.array([], dtype=int)
    minus_m_above = g_m_pos[ml_minus_m > cutoff] if ml_minus_m.size > 0 else np.array([], dtype=int)
    minus_h_above = g_h_pos[ml_minus_h > cutoff] if ml_minus_h.size > 0 else np.array([], dtype=int)
    return plus_m_above, plus_h_above, minus_m_above, minus_h_above


def generate_CpG_mod_status_array(read, cutoff):
    sequence = read.get_forward_sequence() if hasattr(read, "get_forward_sequence") else read.query_sequence
    if not sequence:
        return np.array([]), np.array([]), np.array([])

    cytosine_positions = _get_cytosine_positions(sequence)
    guanine_positions = _get_guanine_positions(sequence)
    all_CpG_pos = _get_CpG_pos(cytosine_positions, guanine_positions)

    (mm_c_m_idx, mm_c_h_idx, mm_g_m_idx, mm_g_h_idx, include_h) = _get_indices_from_MM(read)
    if (mm_c_m_idx.size == 0 and mm_g_m_idx.size == 0 and
            mm_c_h_idx.size == 0 and mm_g_h_idx.size == 0):
        return np.array([]), np.array([]), np.array([])

    ml_plus_m, ml_plus_h, ml_minus_m, ml_minus_h = _get_predictions_from_ML(
        read, len(mm_c_m_idx), len(mm_c_h_idx), len(mm_g_m_idx), len(mm_g_h_idx), include_h
    )

    c_m_pos = cytosine_positions[mm_c_m_idx] if len(mm_c_m_idx) else np.array([], dtype=int)
    c_h_pos = cytosine_positions[mm_c_h_idx] if len(mm_c_h_idx) else np.array([], dtype=int)
    g_m_pos = guanine_positions[mm_g_m_idx] if len(mm_g_m_idx) else np.array([], dtype=int)
    g_h_pos = guanine_positions[mm_g_h_idx] if len(mm_g_h_idx) else np.array([], dtype=int)

    all_pos_in_MM = np.concatenate(
        [c_m_pos, c_h_pos, g_m_pos - 1, g_h_pos - 1]
    ) if (c_m_pos.size + c_h_pos.size + g_m_pos.size + g_h_pos.size) > 0 else np.array([], dtype=int)

    boolean_cpgs_in_MM = np.isin(all_CpG_pos, all_pos_in_MM)
    CpGs_in_MM_tag = all_CpG_pos[boolean_cpgs_in_MM]

    plus_m_above, plus_h_above, minus_m_above, minus_h_above = _positions_above_cutoff(
        c_m_pos, c_h_pos, g_m_pos, g_h_pos, ml_plus_m, ml_plus_h, ml_minus_m, ml_minus_h, cutoff
    )

    if read.is_reverse:
        plus_m_above, minus_m_above = minus_m_above, plus_m_above
        plus_h_above, minus_h_above = minus_h_above, plus_h_above

    plus_h_bool = np.isin(CpGs_in_MM_tag, plus_h_above)
    plus_m_bool = np.isin(CpGs_in_MM_tag, plus_m_above)
    minus_h_bool = np.isin(CpGs_in_MM_tag, minus_h_above - 1)
    minus_m_bool = np.isin(CpGs_in_MM_tag, minus_m_above - 1)

    plus_status = np.where(plus_h_bool, 2, np.where(plus_m_bool, 1, 0))
    minus_status = np.where(minus_h_bool, 2, np.where(minus_m_bool, 1, 0))

    return plus_status, minus_status, CpGs_in_MM_tag


def generate_CpG_meth_status_array_2state(read, cutoff):
    sequence = read.get_forward_sequence() if hasattr(read, "get_forward_sequence") else read.query_sequence
    if not sequence:
        return np.array([]), np.array([])

    cytosine_positions = _get_cytosine_positions(sequence)
    guanine_positions = _get_guanine_positions(sequence)
    all_CpG_pos = _get_CpG_pos(cytosine_positions, guanine_positions)

    mm_c_m_idx, _, mm_g_m_idx, _, _ = _get_indices_from_MM(read)
    if mm_c_m_idx.size == 0 and mm_g_m_idx.size == 0:
        return np.array([]), np.array([])

    ml_plus_m, _, ml_minus_m, _ = _get_predictions_from_ML(
        read, len(mm_c_m_idx), 0, len(mm_g_m_idx), 0, False
    )

    c_m_pos = cytosine_positions[mm_c_m_idx] if len(mm_c_m_idx) else np.array([], dtype=int)
    g_m_pos = guanine_positions[mm_g_m_idx] if len(mm_g_m_idx) else np.array([], dtype=int)
    all_pos_in_MM = np.concatenate((c_m_pos, g_m_pos - 1)) if (c_m_pos.size + g_m_pos.size) > 0 else np.array([], dtype=int)
    boolean_cpgs_in_MM = np.isin(all_CpG_pos, all_pos_in_MM)
    CpGs_in_MM_tag = all_CpG_pos[boolean_cpgs_in_MM]

    c_pos_above, _, g_pos_above, _ = _positions_above_cutoff(
        c_m_pos, np.array([], dtype=int), g_m_pos, np.array([], dtype=int),
        ml_plus_m, np.array([], dtype=int), ml_minus_m, np.array([], dtype=int), cutoff
    )
    boolean_CpGs_above_plus = np.isin(CpGs_in_MM_tag, c_pos_above)
    boolean_CpGs_above_minus = np.isin(CpGs_in_MM_tag, g_pos_above - 1)
    if read.is_reverse:
        boolean_CpGs_above_plus, boolean_CpGs_above_minus = boolean_CpGs_above_minus, boolean_CpGs_above_plus

    meth_status_array = (boolean_CpGs_above_plus.astype(int) * 1) + (boolean_CpGs_above_minus.astype(int) * 2)
    return meth_status_array, CpGs_in_MM_tag


def _status_to_key(plus_status, minus_status):
    mapping = {
        (0, 0): "CC",
        (0, 1): "CM",
        (1, 0): "MC",
        (1, 1): "MM",
        (0, 2): "CH",
        (2, 0): "HC",
        (2, 2): "HH",
        (1, 2): "MH",
        (2, 1): "HM",
    }
    return mapping[(plus_status, minus_status)]


def aggregate_per_cpg(bam_path, cpg_lookup, cutoff=128, progress_interval=100000):
    counts = {
        chrom: {
            pos: {
                "CC": 0, "CM": 0, "MC": 0, "MM": 0,
                "CH": 0, "HC": 0, "HH": 0, "MH": 0, "HM": 0,
            } for pos in cpg_lookup[chrom]
        } for chrom in cpg_lookup
    }
    stats = defaultdict(int)
    bam = pysam.AlignmentFile(bam_path, "rb")

    for read in bam.fetch(until_eof=True):
        stats["total_reads"] += 1
        if read.is_unmapped or read.is_secondary or read.is_supplementary:
            stats["skipped_reads"] += 1
            continue

        try:
            chrom = read.reference_name
            try:
                sequence = read.get_forward_sequence()
            except Exception:
                sequence = read.query_sequence
            reference_position_lookup = read.get_reference_positions(full_length=True)

            plus_status, minus_status, CpGs_in_MM_tag = generate_CpG_mod_status_array(read, cutoff)
            if CpGs_in_MM_tag.size == 0:
                continue

            if read.is_reverse:
                plus_status = plus_status[::-1]
                minus_status = minus_status[::-1]
                CpGs_in_MM_tag = CpGs_in_MM_tag[::-1]
                CpG_in_MM_tag_refidx = len(sequence) - 1 - (CpGs_in_MM_tag + 1)
                CpGs_in_MM_genomic_pos = np.array(
                    [reference_position_lookup[i] for i in CpG_in_MM_tag_refidx],
                    dtype=float
                )
            else:
                CpGs_in_MM_genomic_pos = np.array(
                    [reference_position_lookup[i] for i in CpGs_in_MM_tag],
                    dtype=float
                )

            good_mask = ~np.isnan(CpGs_in_MM_genomic_pos)
            if not np.any(good_mask):
                continue
            CpGs_in_MM_genomic_pos = CpGs_in_MM_genomic_pos[good_mask].astype(int)
            plus_status = plus_status[good_mask]
            minus_status = minus_status[good_mask]

            for refpos, ps, ms in zip(CpGs_in_MM_genomic_pos, plus_status, minus_status):
                if chrom in counts and refpos in counts[chrom]:
                    key = _status_to_key(int(ps), int(ms))
                    counts[chrom][refpos][key] += 1
                    stats[key] += 1

        except Exception:
            stats["reads_malformed"] += 1
            continue

        if stats["total_reads"] % progress_interval == 0:
            logging.info("Processed %d reads...", stats["total_reads"])

    bam.close()
    return counts, stats


def aggregate_per_cpg_2state(bam_path, cpg_lookup, cutoff=128, progress_interval=100000):
    counts = {
        chrom: {
            pos: {"fully": 0, "hemi_plus": 0, "hemi_minus": 0, "unmeth": 0}
            for pos in cpg_lookup[chrom]
        } for chrom in cpg_lookup
    }
    stats = defaultdict(int)
    bam = pysam.AlignmentFile(bam_path, "rb")

    for read in bam.fetch(until_eof=True):
        stats["total_reads"] += 1
        if read.is_unmapped or read.is_secondary or read.is_supplementary:
            stats["skipped_reads"] += 1
            continue

        try:
            chrom = read.reference_name
            try:
                sequence = read.get_forward_sequence()
            except Exception:
                sequence = read.query_sequence
            reference_position_lookup = read.get_reference_positions(full_length=True)

            meth_status_array, CpGs_in_MM_tag = generate_CpG_meth_status_array_2state(read, cutoff)
            if CpGs_in_MM_tag.size == 0:
                continue

            if read.is_reverse:
                meth_status_array = meth_status_array[::-1]
                CpGs_in_MM_tag = CpGs_in_MM_tag[::-1]
                CpG_in_MM_tag_refidx = len(sequence) - 1 - (CpGs_in_MM_tag + 1)
                CpGs_in_MM_genomic_pos = np.array(
                    [reference_position_lookup[i] for i in CpG_in_MM_tag_refidx],
                    dtype=float
                )
            else:
                CpGs_in_MM_genomic_pos = np.array(
                    [reference_position_lookup[i] for i in CpGs_in_MM_tag],
                    dtype=float
                )

            good_mask = ~np.isnan(CpGs_in_MM_genomic_pos)
            if not np.any(good_mask):
                continue
            CpGs_in_MM_genomic_pos = CpGs_in_MM_genomic_pos[good_mask].astype(int)
            meth_status_array = meth_status_array[good_mask]

            for refpos, status in zip(CpGs_in_MM_genomic_pos, meth_status_array):
                if chrom in counts and refpos in counts[chrom]:
                    d = counts[chrom][refpos]
                    if status == 3:
                        d["fully"] += 1
                        stats["fully"] += 1
                    elif status == 2:
                        d["hemi_minus"] += 1
                        stats["hemi_minus"] += 1
                    elif status == 1:
                        d["hemi_plus"] += 1
                        stats["hemi_plus"] += 1
                    elif status == 0:
                        d["unmeth"] += 1
                        stats["unmeth"] += 1

        except Exception:
            stats["reads_malformed"] += 1
            continue

        if stats["total_reads"] % progress_interval == 0:
            logging.info("Processed %d reads...", stats["total_reads"])

    bam.close()
    return counts, stats


def write_dsi_gz(outfile, counts):
    out_path = outfile if outfile.endswith(".dsi.gz") else outfile + ".dsi.gz"
    logging.info("Writing %s", out_path)
    n = 0
    with gzip.open(out_path, "wt") as fh:
        for chrom in sorted(counts):
           
            for pos0 in sorted(counts[chrom]):
                d = counts[chrom][pos0]
                total = sum(d.values())
                unmeth = d["CC"]
                methyl = total - unmeth
                pos1 = pos0 + 1
                row = [
                    str(chrom), str(pos1), "C", str(total), str(methyl), str(unmeth), "CG",
                    str(d["MM"]), str(d["MC"]),str(d["CM"]), str(d["CC"]), 
                    str(d["HH"]), str(d["HC"]),str(d["CH"]),
                    str(d["MH"]), str(d["HM"])
                ]
                fh.write("\t".join(row) + "\n")
                n += 1
    return out_path, n


def write_dsi_gz_2state(outfile, counts):
    out_path = outfile if outfile.endswith(".dsi.gz") else outfile + ".dsi.gz"
    logging.info("Writing %s", out_path)
    n = 0
    with gzip.open(out_path, "wt") as fh:
        for chrom in sorted(counts):
            for pos0 in sorted(counts[chrom]):
                d = counts[chrom][pos0]
                fully = d["fully"]
                hemi_plus = d["hemi_plus"]
                hemi_minus = d["hemi_minus"]
                unmeth = d["unmeth"]
                total = fully + hemi_plus + hemi_minus + unmeth
                methyl = fully + hemi_plus + hemi_minus
                pos1 = pos0 + 1
                row = [
                    str(chrom), str(pos1), "C", str(total), str(methyl), str(unmeth), "CG",
                    str(fully), str(hemi_plus), str(hemi_minus), str(unmeth),
                ]
                fh.write("\t".join(row) + "\n")
                n += 1
    return out_path, n


def write_stdout(counts):
    n = 0
    for chrom in sorted(counts):
        for pos0 in sorted(counts[chrom]):
            d = counts[chrom][pos0]
            total = sum(d.values())
            unmeth = d["CC"]
            methyl = total - unmeth
            pos1 = pos0 + 1
            row = [
                str(chrom), str(pos1), "C", str(total), str(methyl), str(unmeth), "CG",
                str(d["CC"]), str(d["CM"]), str(d["MC"]), str(d["MM"]),
                str(d["CH"]), str(d["HC"]), str(d["HH"]),
                str(d["MH"]), str(d["HM"]),
            ]
            print("\t".join(row))
            n += 1
    return n


def write_stdout_2state(counts):
    n = 0
    for chrom in sorted(counts):
        for pos0 in sorted(counts[chrom]):
            d = counts[chrom][pos0]
            fully = d["fully"]
            hemi_plus = d["hemi_plus"]
            hemi_minus = d["hemi_minus"]
            unmeth = d["unmeth"]
            total = fully + hemi_plus + hemi_minus + unmeth
            methyl = fully + hemi_plus + hemi_minus
            pos1 = pos0 + 1
            row = [
                str(chrom), str(pos1), "C", str(total), str(methyl), str(unmeth), "CG",
                str(fully), str(hemi_plus), str(hemi_minus), str(unmeth),
            ]
            print("\t".join(row))
            n += 1
    return n


def main():
    parser = argparse.ArgumentParser(
        description="Strand- und positionsrichtiges CpG-pileup aus modBAM (5mC/5hmC, 9-state)"
    )
    parser.add_argument("-i", "--input", required=True, help="Input BAM (.bam, indiziert)")
    parser.add_argument("-f", "--fasta", required=True, help="Referenz FASTA für CpG-Positionen")
    parser.add_argument("-o", "--output", default=None, help="Output .dsi.gz, sonst STDOUT")
    parser.add_argument("--threshold", "-t", type=int, default=128, help="ML cutoff (0-255, default 128)")
    parser.add_argument("--progress-interval", type=int, default=100000)
    parser.add_argument("--num-classes", type=int, required=True, help="2 -> 4-state, >=3 -> 9-state")
    parser.add_argument("--log-level", default="INFO", choices=["OFF", "ERROR", "WARN", "INFO"])
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level, logging.INFO),
        format="%(asctime)s [%(levelname)s] %(message)s"
    )
    logging.info("pileup.py started")

    cpg_lookup = find_cpgs_in_fasta(args.fasta)
    if args.num_classes >= 3:
        counts, stats = aggregate_per_cpg(
            args.input, cpg_lookup, cutoff=args.threshold, progress_interval=args.progress_interval
        )
        if args.output:
            write_dsi_gz(args.output, counts)
        else:
            write_stdout(counts)
        ncpgs = sum(len(v) for v in cpg_lookup.values())
        logging.info(
            "Reads: %d, CpGs: %d, CC: %d, CM: %d, MC: %d, MM: %d, CH: %d, HC: %d, HH: %d, MH: %d, HM: %d",
            stats["total_reads"], ncpgs,
            stats["CC"], stats["CM"], stats["MC"], stats["MM"],
            stats["CH"], stats["HC"], stats["HH"], stats["MH"], stats["HM"]
        )
    else:
        counts, stats = aggregate_per_cpg_2state(
            args.input, cpg_lookup, cutoff=args.threshold, progress_interval=args.progress_interval
        )
        if args.output:
            write_dsi_gz_2state(args.output, counts)
        else:
            write_stdout_2state(counts)
        ncpgs = sum(len(v) for v in cpg_lookup.values())
        logging.info(
            "Reads: %d, CpGs: %d, F: %d, H+: %d, H-: %d, U: %d",
            stats["total_reads"], ncpgs,
            stats["fully"], stats["hemi_plus"], stats["hemi_minus"], stats["unmeth"]
        )


if __name__ == "__main__":
    main()
