import argparse
import multiprocessing as mp
import logging
import array
import os
import torch
import sys
import shutil
from datetime import timedelta
from .hybrid_model import HybridCNNTransformerModel
from logging.handlers import QueueHandler, QueueListener
from .dataloader import ChunkedMyDataset
from torch.utils.data import DataLoader
from time import perf_counter
import logging
import time
import os
import subprocess
import pysam
import math
from tqdm import tqdm
import numpy as np
from collections import defaultdict
import re
from .utilities import *





def _get_prediction_features_from_model(
    loader,
    model_path,
    model_name,
    num_classes,
    seq_len,
    input_channels,
    cnn_hidden,
    cnn_layers,
    transformer_layers,
    transformer_dim,
    transformer_heads,
    dropout,
    mod_class_index_m,
    mod_class_index_h,
    show_progress=False,
):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = HybridCNNTransformerModel(
        input_channels=input_channels,  # encode_kmer, ipd, pw
        seq_len=seq_len,
        num_classes=num_classes,
        cnn_hidden=cnn_hidden,
        cnn_layers=cnn_layers,
        transformer_layers=transformer_layers,
        transformer_dim=transformer_dim,
        transformer_heads=transformer_heads,
        dropout=dropout,
    ).to(device := torch.device("cuda" if torch.cuda.is_available() else "cpu"))
    model1 = torch.load(os.path.join(os.path.join(model_path, model_name)), torch.device('cpu'))
    model.load_state_dict(model1)
    model = model.to(device)
    model.eval()
    include_h = num_classes >= 3
    ex_features = []
    iterator = loader
    if show_progress:
        iterator = tqdm(loader, desc="Processing Batches", total=len(loader))
    else:
        iterator = tqdm(loader, desc="Processing Batches", total=len(loader), disable=True)
    with torch.no_grad():
        for v_output in iterator:
            v_cg_id, v_kmer_seq, v_encode_kmer, v_ipd, v_pw, v_npass = v_output
            v_encode_kmer = v_encode_kmer.int()
            v_ipd = v_ipd.float()
            v_pw = v_pw.float()
            v_npass = v_npass.float()
            v_encode_kmer, v_ipd, v_pw, v_npass = v_encode_kmer.to(device), v_ipd.to(device), v_pw.to(device), v_npass.to(device)
            v_input_model = torch.stack([v_encode_kmer.float(), v_ipd, v_pw], dim=1)
            use_cuda = torch.cuda.is_available()
            v_pred1 = model(v_input_model)
            v_pred = torch.softmax(v_pred1, dim=1)
            if use_cuda:
                v_pred = v_pred.cpu().detach().numpy()
            for i in range(len(v_pred)):
                pred_m = float(v_pred[i][mod_class_index_m])
                pred_h = float(v_pred[i][mod_class_index_h]) if include_h else None
                read_id = "_".join(v_cg_id[i].split("_")[:-4]) # e.g., m64215e_251011_203933/68038/ccs_Unmapped_+_rev_1425 -> m64215e_251011_203933/68038/ccs
                ex_item = {
                    "key_ids": v_cg_id[i],
                    "read_id": read_id,
                    "pred_m": pred_m,
                }
                if include_h:
                    ex_item["pred_h"] = pred_h
                ex_features.append(ex_item)
    grouped_data = grouped("read_id", ex_features)
    return grouped_data
def grouped(key, items_list):
    matching_items = defaultdict(list)
    for item in items_list:
        matching_items[item.get(key)].append(item)
    return dict(matching_items)

def _get_cytosine_positions(read):
    """
    Returns all cytosine (C) positions in a sequence.
    """
    return np.where(np.array(list(read)) == 'C')[0]
def _get_cpgs_index_tsv(read_data):
    cpg_sites_in_read_fwd = []
    cpg_sites_in_read_rev = []
    # print("read_id is calling for finding cpgs...")
    for entry in read_data:
        cg_id = entry['key_ids']
        cg_parts = cg_id.rsplit("_", 2)  # Only split the last two parts: strand and index
        strand = cg_parts[-2]
        index = int(cg_parts[-1])
        cpg_info = {
            'cg_id': cg_id,
            'cpg_index': index,
            'pred_m': entry.get('pred_m', 0.0),
            'pred_h': entry.get('pred_h', 0.0)
        }
        if strand == 'fwd':
            cpg_sites_in_read_fwd.append(cpg_info)
        else:
            cpg_sites_in_read_rev.append(cpg_info)
   
    return cpg_sites_in_read_fwd, cpg_sites_in_read_rev
def _get_cytosine_guanine_positions_prediction_information(plus_seq, minus_seq):
    """
    Extracts CpG positions and prediction probabilities from model output.
    """
    posit_index_cytosine = [k['cpg_index'] for k in plus_seq]
    posit_index_guanine = [k['cpg_index']+1 for k in minus_seq]
    pred_m_plus = [int(np.clip(k['pred_m'] * 255, 0, 255)) for k in plus_seq]
    pred_h_plus = [int(np.clip(k['pred_h'] * 255, 0, 255)) for k in plus_seq]
    pred_m_minus = [int(np.clip(k['pred_m'] * 255, 0, 255)) for k in minus_seq]
    pred_h_minus = [int(np.clip(k['pred_h'] * 255, 0, 255)) for k in minus_seq]
    return (
        posit_index_cytosine,
        posit_index_guanine,
        pred_m_plus,
        pred_h_plus,
        pred_m_minus,
        pred_h_minus
    )
def create_new_ML_tag(plus_m_probs, plus_h_probs, minus_m_probs, minus_h_probs, include_h):
    """
    Combines modification probabilities into a single ML tag array.
    """
    if include_h:
        new_ML_tag = np.concatenate((plus_m_probs, plus_h_probs, minus_m_probs, minus_h_probs))
    else:
        new_ML_tag = np.concatenate((plus_m_probs, minus_m_probs))
    new_ML_tag = array.array("B", new_ML_tag)
    return new_ML_tag

def create_new_MM_tag(plus_strand, minus_strand, include_h):
    """
    Creates a new MM tag string from plus and minus strand data.
    """
    plus_m_strand_string = "C+m?," + ",".join(map(str, plus_strand))
    minus_m_strand_string = "G-m?," + ",".join(map(str, minus_strand))
    if include_h:
        plus_h_strand_string = "C+h?," + ",".join(map(str, plus_strand))
        minus_h_strand_string = "G-h?," + ",".join(map(str, minus_strand))
        new_MM_tag = ";".join([
            plus_m_strand_string,
            plus_h_strand_string,
            minus_m_strand_string,
            minus_h_strand_string
        ]) + ";"
    else:
        new_MM_tag = ";".join([plus_m_strand_string, minus_m_strand_string]) + ";"
    return new_MM_tag
def _get_G_positions(read):
    """
    Returns all guanine (G) positions in a sequence.
    """
    return np.where(np.array(list(read)) == 'G')[0]


def process_chunk(args):
    (
        chunk_idx,
        bam_path,
        start_offset,
        end_offset,
        upstream_nt,
        downstream_nt,
        motif,
        model_path,
        model_name,
        num_classes,
        seq_len,
        input_channels,
        cnn_hidden,
        cnn_layers,
        transformer_layers,
        transformer_dim,
        transformer_heads,
        dropout,
        mod_class_index_m,
        mod_class_index_h,
        output_tmpdir,
        log_level,
        log_queue,
    ) = args
    configure_worker_logger(log_level, log_queue)
    with pysam.AlignmentFile(bam_path, "rb", check_sq=False) as bam:
        bam.seek(start_offset)
        reads = []
        while True:
            if end_offset is not None and bam.tell() >= end_offset:
                break
            try:
                read = next(bam)
                reads.append(read)
            except StopIteration:
                break
    (
        features_bam,
        skipped_reads,
        skipped_cpgs,
        missing_reads,
        empty_reads,
        _low_value_reads,
        _diff_reads,
    ) = get_features_from_reads(reads, upstream_nt, downstream_nt, motif)
    features = [
        [f"{f[0]}_{f[1]}_{f[2]}_{f[3]}_{f[4]}", f[5], f[6], f[7], f[8]]
        for f in features_bam
    ]
    dataset = ChunkedMyDataset(features)
    loader = DataLoader(dataset, batch_size=200, shuffle=False, num_workers=0, pin_memory=False)
    grouped_features = _get_prediction_features_from_model(
        loader,
        model_path,
        model_name,
        num_classes,
        seq_len,
        input_channels,
        cnn_hidden,
        cnn_layers,
        transformer_layers,
        transformer_dim,
        transformer_heads,
        dropout,
        mod_class_index_m,
        mod_class_index_h,
        show_progress=False,
    )
    include_h = num_classes >= 3
    chunk_bam_path = os.path.join(output_tmpdir, f"chunk_{chunk_idx}.bam")
    with pysam.AlignmentFile(bam_path, "rb", check_sq=False) as bam_in, pysam.AlignmentFile(chunk_bam_path, "wb", header=bam_in.header) as bam_out:
        for read in bam_in:
            seq_name = read.query_name
            read_sequence = read.get_forward_sequence()
            try:
                cpgs_index_fwd_tsv, cpgs_index_rev_tsv = _get_cpgs_index_tsv(grouped_features[seq_name])
                (cytosine_positions_info_read,
                 guanine_positions_info_read,
                 plus_m_probs,
                 plus_h_probs,
                 minus_m_probs,
                 minus_h_probs) = _get_cytosine_guanine_positions_prediction_information(
                    cpgs_index_fwd_tsv,
                    cpgs_index_rev_tsv,
                )
                cytosine_positions_info_read = np.array(cytosine_positions_info_read)
                guanine_positions_info_read = np.array(guanine_positions_info_read)
                plus_m_probs = np.array(plus_m_probs)
                plus_h_probs = np.array(plus_h_probs)
                minus_m_probs = np.array(minus_m_probs)
                minus_h_probs = np.array(minus_h_probs)
                cytosine_positions = _get_cytosine_positions(read_sequence)
                G_positions = _get_G_positions(read_sequence)
                indices_of_processed_cpgs_fwd = np.searchsorted(cytosine_positions, cytosine_positions_info_read)
                MM_tag_distance_plus = np.diff(indices_of_processed_cpgs_fwd, prepend=-1) - 1
                indices_of_processed_cpgs_rev = np.searchsorted(G_positions, guanine_positions_info_read)
                MM_tag_distance_minus = np.diff(indices_of_processed_cpgs_rev, prepend=-1) - 1
                MM_tag = create_new_MM_tag(MM_tag_distance_plus, MM_tag_distance_minus, include_h)
                ML_tag = create_new_ML_tag(plus_m_probs, plus_h_probs, minus_m_probs, minus_h_probs, include_h)
                read.set_tag("MM", MM_tag)
                read.set_tag("ML", ML_tag)
                for tag in ["fi","fn","ri","rn","fp","rp","ac","bx","ma","sn","we","ws","qs","qe","bc","bq","cx","ql","qt","ls"]:
                    read.set_tag(tag, None)
                bam_out.write(read)
            except:
                continue
            
    return chunk_bam_path, skipped_reads, skipped_cpgs, missing_reads, empty_reads

def check_files_paths(input, model_path, model_name, bam_file, output):
    """
    Validates existence and permissions for all required input/output paths and files.
    """
    if not os.path.exists(output):
        os.makedirs(output)
    if not os.access(output, os.W_OK):
        logging.error(f"No write permission for output directory '{output}'.")
        sys.exit(1)
    if not os.path.exists(input):
        logging.error(f"Input path directory not found: {input}.")
        sys.exit(1)
    if not os.path.isfile(os.path.join(input, bam_file)):
        logging.error(f"Input file not found: {bam_file}.")
        sys.exit(1)
    if not os.path.exists(model_path):
        logging.error(f"Model path directory not found: {model_path}.")
        sys.exit(1)
    if not os.path.isfile(os.path.join(model_path, model_name)):
        logging.error(f"Model file not found: {model_name}.")
        sys.exit(1)
def configure_worker_logger(log_level="ERROR", log_queue=None):
    """
    Configure a worker process logger to use a QueueHandler pointing to the main process log_queue.
    """
    if log_queue:
        queue_handler = QueueHandler(log_queue)
        root = logging.getLogger()
        root.handlers = []
        root.addHandler(queue_handler)
        level_map = {
            "OFF": logging.CRITICAL + 1,
            "ERROR": logging.ERROR,
            "WARN": logging.WARNING,
            "INFO": logging.INFO
        }
        root.setLevel(level_map[log_level])
        if log_level == "OFF":
            logging.disable(logging.CRITICAL)

def configure_main_logger(log_level="ERROR", log_file=None, log_queue=None):
    """
    Configure the root logger and set up a multiprocessing-safe QueueListener if log_queue is provided.
    """
    log_format = '%(asctime)s [%(levelname)s] %(message)s'
    level_map = {
        "OFF": logging.CRITICAL + 1,
        "ERROR": logging.ERROR,
        "WARN": logging.WARNING,
        "INFO": logging.INFO
    }
    level = level_map[log_level]
    handlers = [logging.StreamHandler(sys.stdout)] if not log_file else [logging.FileHandler(log_file)]
    if log_queue is not None:
        handler = handlers[0]
        listener = QueueListener(log_queue, handler)
        listener.start()
        # Set up root logger only with handler for QueueListener
        logging.basicConfig(handlers=[handler], level=level, format=log_format, force=True)
        return listener
    else:
        logging.basicConfig(level=level, format=log_format, handlers=handlers, force=True)
        if log_level == "OFF":
            logging.disable(logging.CRITICAL)
        return None

def get_total_reads(bam_path):
    with pysam.AlignmentFile(bam_path, "rb", check_sq=False) as bam:
        return bam.count(until_eof=True)

def calculate_optimal_chunk_size(bam_path, threads, multiplier=4, log_level="ERROR"):
    total_reads = get_total_reads(bam_path)
    num_chunks = threads * multiplier
    chunk_size = math.ceil(total_reads / num_chunks)
    msg = f"Total reads: {total_reads}, Threads: {threads}, automatic chunks: {num_chunks}, Chunk size: {chunk_size}"
    print_process_info(msg, log_level)
    logging.info(msg)
    return chunk_size

def get_read_offsets(bam_path, chunk_size):
    offsets = []
    with pysam.AlignmentFile(bam_path, "rb", check_sq=False) as bam:
        count = 0
        offsets.append(bam.tell())
        for read in bam:
            count += 1
            if count % chunk_size == 0:
                offsets.append(bam.tell())
    return offsets
def call_modification(
    input,
    model_path,
    model_name,
    bam_file,
    output,
    output_file,
    threads,
    motif,
    upstream_nt,
    downstream_nt,
    num_classes=2,
    seq_len=21,
    input_channels=3,
    cnn_hidden=128,
    cnn_layers=4,
    transformer_layers=6,
    transformer_dim=256,
    transformer_heads=8,
    dropout=0.2,
    mod_class_index_m=1,
    mod_class_index_h=2,
    chunk_size=None,
    log_level="ERROR",
    log_queue=None,
    sort=True,
):
    start_time = time.time()
    check_files_paths(input, model_path, model_name, bam_file, output)
    bam_path = os.path.join(input, bam_file)
    # Extract the BAM filename without extension
    bam_basename = os.path.splitext(os.path.basename(bam_file))[0]


    # Create unique temporary directories per BAM file
    output_tmpdir = os.path.join(output, f"tmp_chunks_{bam_basename}")
    os.makedirs(output_tmpdir, exist_ok=True)
 
    

    if chunk_size is None:
        chunk_size = calculate_optimal_chunk_size(bam_path, threads, multiplier=4, log_level=log_level)
    else:
        msg = f"Chunk size is predefined: {chunk_size}"
        logging.info(msg)

    logging.info("Calculating chunk offsets for parallel processing...")
    offsets = get_read_offsets(bam_path, chunk_size)
    chunk_args = []
    for i in range(len(offsets)):
        start_offset = offsets[i]
        end_offset = offsets[i+1] if i+1 < len(offsets) else None
        chunk_args.append((
            i,
            bam_path,
            start_offset,
            end_offset,
            upstream_nt,
            downstream_nt,
            motif,
            model_path,
            model_name,
            num_classes,
            seq_len,
            input_channels,
            cnn_hidden,
            cnn_layers,
            transformer_layers,
            transformer_dim,
            transformer_heads,
            dropout,
            mod_class_index_m,
            mod_class_index_h,
            output_tmpdir,
            log_level,
            log_queue,
        ))
    msg = f"Starting {threads} parallel processes for writing chunk BAMs..."
    logging.info(msg)
    with mp.Pool(threads, initializer=configure_worker_logger, initargs=(log_level, log_queue)) as pool:
        chunk_results = list(tqdm(pool.imap(process_chunk, chunk_args), total=len(chunk_args), desc="Processing chunks"))
    
    chunk_bam_paths = [r[0] for r in chunk_results]
    total_skipped_reads = sum(r[1] for r in chunk_results)
    total_skipped_cpgs = sum(r[2] for r in chunk_results)
    all_missing_reads = [name for r in chunk_results for name in r[3]]
    all_empty_reads = [name for r in chunk_results for name in r[4]]
    
    logging.info("Merging temporary chunk BAMs to final output...")
    merged_bam = os.path.join(output, output_file)
    merge_cmd = ["samtools", "cat", "-o", merged_bam] + chunk_bam_paths
    subprocess.run(merge_cmd, check=True)
    if sort:
        logging.info("Sorting and indexing the merged BAM...")
        sorted_bam = merged_bam.replace(".bam", ".sorted.bam")
        subprocess.run(["samtools", "sort", "-@", str(threads), "-o", sorted_bam, merged_bam], check=True)
        subprocess.run(["samtools", "index", "-@", str(threads), sorted_bam], check=True)
        shutil.move(sorted_bam, merged_bam)
        shutil.move(sorted_bam + ".bai", merged_bam + ".bai")
    else:
        logging.info("Skipping sorting and indexing of the merged BAM...")
    logging.info("Cleaning up temporary files...")
    for path in chunk_bam_paths:
        os.unlink(path)
    shutil.rmtree(output_tmpdir)
    msg = f"Final BAM file written: {merged_bam}"
    logging.info(msg)
    msg = f"Total reads skipped due to missing or empty tags: {total_skipped_reads}"
    logging.info(msg)
    if all_missing_reads:
        logging.info(f"Skipped reads due to missing tags ({len(all_missing_reads)}): {', '.join(all_missing_reads)}")
    if all_empty_reads:
        logging.info(f"Skipped reads due to empty tags ({len(all_empty_reads)}): {', '.join(all_empty_reads)}")
    msg = f"Total CpGs skipped due to proximity to read ends: {total_skipped_cpgs}"
    logging.info(msg)
    elapsed = timedelta(seconds=int(time.time() - start_time))
    msg = f"Total processing time: {str(elapsed)}"
    logging.info(msg)

def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Modification caller for PacBio BAM files using Deep Learning.",
        epilog="Example: python call_modifications_from_bam.py -i ./input -m ./model -n model.pt -b input.bam -o ./output -f output.bam"
    )
    parser.add_argument("-i", "--input", required=True,
                        help="--input/-i INPUT_BAM_FILE e.g. path/to/input.aligned.bam")
    parser.add_argument("-m", "--model-path", required=True,
                        help="--model-path/-m MODEL_PATH e.g. path/to/model_best.pt")
    parser.add_argument("-o", "--output", required=True,
                        help="--output, -o OUTPUT_MOD_BAM e.g. output/path/to/mod.bam")
    # removed separate model-name, bam-file and output-file arguments; they are derived from the provided paths
    parser.add_argument("-t", "--threads", type=int, default=4,
                        help="Number of parallel processes (default: 4)")
    parser.add_argument("-M", "--motif", type=str, default="CG",
                        help="Motif to search for in sequences (default: CG)")
    parser.add_argument("-u", "--upstream-nt", type=int, default=10,
                        help="Number of nucleotides upstream of the motif (default: 10)")
    parser.add_argument("-d", "--downstream-nt", type=int, default=10,
                        help="Number of nucleotides downstream of the motif (default: 10)")
    parser.add_argument("--num-classes", type=int, default=2,
                        help="Number of model classes (default: 2).")
    parser.add_argument("--seq-len", type=int, default=21,
                        help="Sequence length (default: 21).")
    parser.add_argument("--input-channels", type=int, default=3,
                        help="Number of input channels (default: 3).")
    parser.add_argument("--cnn-hidden", type=int, default=128,
                        help="CNN hidden dimension (default: 128).")
    parser.add_argument("--cnn-layers", type=int, default=4,
                        help="Number of CNN layers (default: 4).")
    parser.add_argument("--transformer-layers", type=int, default=6,
                        help="Number of Transformer layers (default: 6).")
    parser.add_argument("--transformer-dim", type=int, default=256,
                        help="Transformer model dimension (default: 256).")
    parser.add_argument("--transformer-heads", type=int, default=8,
                        help="Number of Transformer heads (default: 8).")
    parser.add_argument("--dropout", type=float, default=0.2,
                        help="Dropout probability (default: 0.2).")
    parser.add_argument("--mod-class-index-m", type=int, default=1,
                        help="Class index for M in model outputs (default: 1).")
    parser.add_argument("--mod-class-index-h", type=int, default=2,
                        help="Class index for H in model outputs (default: 2).")
    parser.add_argument("-c", "--chunk-size", type=int, default=None,
                        help="Number of reads per chunk (optional, otherwise automatic)")
    parser.add_argument("--log-level", choices=["OFF", "ERROR", "WARN", "INFO"], default="ERROR",
                        help="Logging level: OFF, ERROR, WARN, or INFO (default: ERROR).")
    parser.add_argument("--log-file", type=str, default=None,
                        help="If set, logs will be written to this file instead of the shell.")
    parser.add_argument("--no-sort", action="store_true",
                        help="Skip sorting and indexing the output BAM.")

    args = parser.parse_args(argv)
    # Derive the original variables expected by the rest of the code from the new single-file arguments
    # input -> input dir + bam filename
    input_dir = os.path.dirname(args.input) or '.'
    bam_file = os.path.basename(args.input)
    # model-path -> model dir + model filename
    model_path_dir = os.path.dirname(args.model_path) or '.'
    model_name = os.path.basename(args.model_path)
    # output -> output dir + output filename
    output_dir = os.path.dirname(args.output) or '.'
    output_file = os.path.basename(args.output)

    # Set up logging queue for multiprocessing-safe logging
    log_queue = mp.Manager().Queue() if args.log_file or args.log_level != "OFF" else None
    listener = configure_main_logger(args.log_level, args.log_file, log_queue=log_queue)
    logging.info(f"Command: {' '.join(sys.argv)}")
    try:
        call_modification(
            input_dir,
            model_path_dir,
            model_name,
            bam_file,
            output_dir,
            output_file,
            args.threads,
            args.motif,
            args.upstream_nt,
            args.downstream_nt,
            args.num_classes,
            args.seq_len,
            args.input_channels,
            args.cnn_hidden,
            args.cnn_layers,
            args.transformer_layers,
            args.transformer_dim,
            args.transformer_heads,
            args.dropout,
            args.mod_class_index_m,
            args.mod_class_index_h,
            args.chunk_size,
            args.log_level,
            log_queue,
            sort=not args.no_sort,
        )
    finally:
        if listener:
            listener.stop()


if __name__ == "__main__":
    main()
