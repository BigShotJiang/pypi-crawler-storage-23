import torch

def Swish(x):

    value = x * torch.sigmoid(x)

    return value

