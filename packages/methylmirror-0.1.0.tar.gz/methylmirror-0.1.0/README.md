# MethylMirror 
<img src="images/MethylMirrorLogo.png" alt="MethylMirrorLogo" width="260" align="left">

<p align="justify">
MethylMirror is a toolbox designed to process and analyze PacBio CCS reads generated through Tet-assisted SMRT sequencing, enabling strand-specific detection of DNA methylation. At its core, MethylMirror employs a hybrid Convolutional Neural Network (CNN)–Transformer architecture to decode the kinetic footprint — defined as the combined Inter-Pulse Duration (IPD) and Pulse Width (PW) signals — across a defined k-mer surrounding a candidate modification site.

To generate a well-defined biochemical signature for model training and validation, we engineered a Tet3 stalling mutant that oxidizes 5-methyl-2′-deoxycytidine (5mdC) to a mixture of 5-hydroxymethyl-2′-deoxycytidine (5hmdC) and 5-formyl-2′-deoxycytidine (5fdC). A subsequent selective reduction step converts 5fdC into 5hmdC, thereby producing a homogeneous 5hmdC modification state specifically within the CpG context. In the framework of Tet-assisted SMRT sequencing, this chemically defined footprint corresponds to 5-carboxyldeoxycytosine (5caC), the oxidation product derived from 5-methylcytosine (5mC). In addition to a pre-trained model for 5caC and 5hmdC (based on the human genome), we also provide a strand-specific model for N6-methyladenine (6mA) in E. coli (dam methylation). We also provide the means to train your own model for MethylMirror (see below).

The output of MethylMirror is a modification-aware BAM file containing modification likelihoods encoded in the ML tag and modification positions encoded in the MM tag. Based on the predicted modification states at CpG sites, a strand-specific pileup file is generated that summarizes modification frequencies. This file is referred to as a DSI file, which reports the methylation or hydroxymethylation frequency per CpG sites.
</p>

Modifications are classified into four categories (in case of 5mC):

  - Fully methylated: both DNA strands are modified (e.g., 5mCpG/5mCpG)
  - Hemimethylated on the plus strand: only the forward strand is modified (e.g., 5mCpG/CpG)
  - Hemimethylated on the minus strand: only the reverse strand is modified (e.g., CpG/5mCpG)
  - Unmethylated: neither strand is modified (e.g., CpG/CpG)

If modifications are classified jointly into 5mC and 5hmC, CpG dyads are categorized into the following states:

  - Fully methylated: both DNA strands are modified in 5mC (MM) (e.g., 5mCpG/5mCpG)
  - Fully hydroxymethylated: both DNA strands are modified in 5hmC (HH) (e.g., 5hmCpG/5hmCpG)
  - Mixed oxidation states hemimethylated on the plus or minus strand (MH/HM) (e.g., 5mCpG/5hmCpG or 5hmCpG/5mCpG)
  - Hemimethylated on the plus or minus strand: (MU/UM) (e.g., 5mCpG/CpG or CpG/5mCpG)
  - Hemihydroxymethylated on the plus or minus strand: (HU/UH) (e.g., 5hmCpG/CpG or CpG/5hmCpG)
  - unmodified (UU): (e.g., CpG/CpG)



## Enviroment
Before installing MethylMirror use the following `mamba` command to set-up a proper enviroment.
```
mamba env create -f MethylMirrorEnv.yml
```



## Installation
MethylMirror can be installed via `mamba` or `pip`. Simply run:
```
mamba install bioconda::methylmirror
```
or

```
pip install methylmirror
```

## Extract features from SMRT sequencing

Before training, the data must be pre-processed by extracting kinetic signals from genomic DNA and converting them into meaningful features for both the forward and reverse strands. The extract_features.py script performs this step and outputs the processed features as an .npz file. HiFi reads kinetic information is generated from PacBio subreads using ccs tool as follows.
```
ccs --help

usage: ccs [options] [input.subreads.bam] [output.hifi.bam]

Generate PacBio HiFi (CCS) reads from subreads BAM files.

positional arguments:
  input.subreads.bam     Raw PacBio subreads BAM file
  output.hifi.bam        Output HiFi BAM file (CCS reads)

optional arguments:
  -h, --help             show this help message and exit
  --hifi-kinetics        Retain kinetic information (IPD/PW) 
                         in the output HiFi BAM file
  --num-threads N        Number of CPU threads to use
  --log-level LEVEL      Logging level (e.g., DEBUG, INFO, WARN, ERROR)
  --log-file FILE        Path to log file for runtime messages
  --report-json FILE     Write JSON report containing CCS statistics                        

```
```
methylmirror extract_features --help

usage: methylmirror extract_features [-h] -i INPUT -o OUTPUT -t THREADS 
                                     -m MOTIF -u UPSTREAM -d DOWNSTREAM 
                                     --label LABEL [-c CHUNK_SIZE]
                                     [--log-level LOG_LEVEL]
                                     [--log-file LOG_FILE]
                                     [--keep-chunks]
                                     [--read-batch-size READ_BATCH_SIZE]
                                     [--feature-buffer-size FEATURE_BUFFER_SIZE]
                                     [--split-train-test SPLIT_RATIO]
                                     [--split-seed SPLIT_SEED]

Extract kinetic features from a BAM file and generate NPZ dataset for MethylMirror.

required arguments:
  -i INPUT               Input BAM file path
  -o OUTPUT              Output NPZ file path
  -t THREADS             Number of threads for multiprocessing
  -m MOTIF               Motif to search for (e.g., CG)
  -u UPSTREAM            Number of upstream nucleotides
  -d DOWNSTREAM          Number of downstream nucleotides
  --label LABEL          Label string assigned to this BAM/class

optional arguments:
  -h, --help             show this help message and exit
  -c CHUNK_SIZE          Number of reads per chunk
  --log-level LOG_LEVEL  Logging level (DEBUG, INFO, WARNING, ERROR)
  --log-file LOG_FILE    Path to log file
  --keep-chunks          Keep temporary chunk directory for debugging
  --read-batch-size READ_BATCH_SIZE
                         Reads processed per batch inside each chunk 
                         (controls memory usage)
  --feature-buffer-size FEATURE_BUFFER_SIZE
                         Number of extracted features buffered before 
                         writing part file
  --split-train-test SPLIT_RATIO
                         Split final NPZ into train/test sets (ratio 0–1)
  --split-seed SPLIT_SEED
                         Random seed for train/test split
```
## Model Training

The CNN–Transformer model is a hybrid architecture that combines 1D convolutional layers and a Transformer encoder. The CNN layers extract local sequence patterns using convolutional filters, while the Transformer captures long-range dependencies through multi-head self-attention and feed-forward layers. The final classification is produced by flattening the features and applying a fully connected layer.

The model supports flexible output configurations and can be trained for binary (two-state) or multi-class (e.g., three-state) classification tasks.
```
methylmirror hybrid_train --help

usage: methylmirror hybrid_train [-h] -i INPUT
                                 [--val_fraction VAL_FRACTION]
                                 [--random_seed RANDOM_SEED]
                                 [--batch_size BATCH_SIZE]
                                 [--val_batch_size VAL_BATCH_SIZE]
                                 [--epochs EPOCHS]
                                 [--lr LR]
                                 [--weight_decay WEIGHT_DECAY]
                                 [--cnn_hidden CNN_HIDDEN]
                                 [--cnn_layers CNN_LAYERS]
                                 [--transformer_layers TRANSFORMER_LAYERS]
                                 [--transformer_dim TRANSFORMER_DIM]
                                 [--transformer_heads TRANSFORMER_HEADS]
                                 [--dropout DROPOUT]
                                 [--num_workers NUM_WORKERS]
                                 [--early_stop_patience EARLY_STOP_PATIENCE]
                                 [--model_dir MODEL_DIR]
                                 [--input_channels INPUT_CHANNELS]
                                 [--num_classes NUM_CLASSES]
                                 [--seq_len SEQ_LEN]
                                 [--log-file LOG_FILE]
                                 [--log-level {OFF,ERROR,WARN,INFO}]
                                 [--label_map LABEL_MAP]

Hybrid model training on NPZ datasets (directory input, new logging).

required arguments:
  -i INPUT, --input INPUT
                        Input directory containing .npz files for training.
                        All .npz files in this folder will be used.

optional arguments:
  -h, --help            show this help message and exit
  --val_fraction VAL_FRACTION
                        Fraction of data used for validation (default: 0.1)
  --random_seed RANDOM_SEED
                        Random seed (default: 42)
  --batch_size BATCH_SIZE
                        Training batch size (default: 200)
  --val_batch_size VAL_BATCH_SIZE
                        Validation batch size (default: 100)
  --epochs EPOCHS       Number of training epochs (default: 50)
  --lr LR               Learning rate (default: 1e-4)
  --weight_decay WEIGHT_DECAY
                        Weight decay (default: 1e-4)
  --cnn_hidden CNN_HIDDEN
                        CNN hidden dimension size (default: 128)
  --cnn_layers CNN_LAYERS
                        Number of CNN layers (default: 4)
  --transformer_layers TRANSFORMER_LAYERS
                        Number of Transformer encoder layers (default: 6)
  --transformer_dim TRANSFORMER_DIM
                        Transformer embedding dimension (default: 256)
  --transformer_heads TRANSFORMER_HEADS
                        Number of attention heads (default: 8)
  --dropout DROPOUT     Dropout rate (default: 0.2)
  --num_workers NUM_WORKERS
                        Number of DataLoader worker processes (default: 4)
  --early_stop_patience EARLY_STOP_PATIENCE
                        Early stopping patience in epochs (default: 5)
  --model_dir MODEL_DIR
                        Directory to save trained model (default: HybridModel_optimized)
  --input_channels INPUT_CHANNELS
                        Number of input channels (default: 3)
  --num_classes NUM_CLASSES
                        Number of output classes (default: 2)
  --seq_len SEQ_LEN     Sequence length (default: 21)
  --log-file LOG_FILE   Optional log file path (default: stdout)
  --log-level {OFF,ERROR,WARN,INFO}
                        Logging level (default: INFO)
  --label_map LABEL_MAP
                        Optional JSON string mapping label->int.
                        Quote it in the shell, e.g.
                        '{"dC":0, "mdC":1}'```

```

## DNA Modification Analysis
The DNA modification analysis with MethylMirror relises the IPD and PW values. Thus, when running your SMRTseq experiment, make sure to enable the recording of HiFi kinetics. 

### Call Modification


In the first step, MethylMirror anaylses the kinetic features and stores the modification in accordance with the [SAMtag specifications](https://samtools.github.io/hts-specs/SAMtags.pdf) using the `ML` (base modification probabilities) and `MM` (base modifications) tags.

```
call_modification --help

usage: call_modification.py [-h] -i INPUT -m MODEL_PATH -n MODEL_NAME -b BAM_FILE -o OUTPUT -f OUTPUT_FILE [-t THREADS] [-M MOTIF] [-u UPSTREAM_NT] [-d DOWNSTREAM_NT] [-c CHUNK_SIZE] [--log-level {OFF,ERROR,WARN,INFO}]
                            [--log-file LOG_FILE]

Modification caller for PacBio BAM files using Deep Learning.

optional arguments:
  -h, --help            show this help message and exit
  -i INPUT, --input INPUT
                        Path to the input folder containing the BAM file (e.g., ./input)
  -m MODEL_PATH, --model-path MODEL_PATH
                        Path to the model folder (e.g., ./model)
  -n MODEL_NAME, --model-name MODEL_NAME
                        Filename of the model (e.g., model.pt)
  -b BAM_FILE, --bam-file BAM_FILE
                        Input BAM filename (e.g., input.bam)
  -o OUTPUT, --output OUTPUT
                        Path to the output folder for results (e.g., ./output)
  -f OUTPUT_FILE, --output-file OUTPUT_FILE
                        Output filename (e.g., output.bam)
  -t THREADS, --threads THREADS
                        Number of parallel processes (default: 4)
  -M MOTIF, --motif MOTIF
                        Motif to search for in sequences (default: CG)
  -u UPSTREAM_NT, --upstream-nt UPSTREAM_NT
                        Number of nucleotides upstream of the motif (default: 10)
  -d DOWNSTREAM_NT, --downstream-nt DOWNSTREAM_NT
                        Number of nucleotides downstream of the motif (default: 10)
  -c CHUNK_SIZE, --chunk-size CHUNK_SIZE
                        Number of reads per chunk (optional, otherwise automatic)
  --log-level {OFF,ERROR,WARN,INFO}
                        Logging level: OFF, ERROR, WARN, or INFO (default: ERROR).
  --log-file LOG_FILE   If set, logs will be written to this file instead of the shell.

Example: python call_modifications_from_bam.py -i ./input -m ./model -n model.pt -b input.bam -o ./output -f output.bam
```
### Modification Pileup

```
pileup --help

usage: pileup.py [-h] --input_path INPUT_PATH --input_file INPUT_FILE --output_path OUTPUT_PATH --output_file OUTPUT_FILE [--threads THREADS] [--threshold THRESHOLD]

Call modification frequencies.

optional arguments:
  -h, --help            show this help message and exit
  --input_path INPUT_PATH
                        Path to input directory
  --input_file INPUT_FILE
                        Name of input BAM file
  --output_path OUTPUT_PATH
                        Path to output directory
  --output_file OUTPUT_FILE
                        Name of output file
  --threads THREADS     Number of threads for multiprocessing
  --threshold THRESHOLD
                        Threshold for methylation calling
```

The output of `MethylMirror pileup` is dsi-file double strand information (dsi), example: [example pileup file](example_files/example_pileup_file.dsi). The dsi file is supported by IGV and will present the methylation state of a given position as a stacked colored bar plot. Red = Fully methylated; dark green = Hemimethylated on the plus strand; light green = Hemimethylated on the minus strand; blue = Unmethylated. The dsi-file itself is a header-free tsv-file containing the following columns:

<table>
<tr>
  <td>1. chromosome</td> <td>chromosome name</td>
</tr>
<tr>
  <td>2. position</td> <td>position in the chromosome</td>
</tr>
<tr>
  <td>3. strand</td> <td> reference strand of the methylation info, in case of CpGs C = plus </td>
</tr>
<tr>
  <td>4. total coverage</td> <td> total number of reads e.g. 12</td>
</tr>
  <tr>
  <td>5. coverage methylated</td> <td>number of methylated reads e.g. 6</td>
</tr>
<tr>
  <td>6. coverage unmethylated</td> <td>number of unmethylated reads e.g. 6</td>
</tr>
<tr>
  <td>7. locus type</td> <td>motif of interest e.g. CG</td>
</tr>
<tr>
  <td>8. coverage fully methylated</td> <td>coverage of reads in a 5mCpG/5mCpG state e.g. 6</td>
</tr>
<tr>
  <td>9. coverage hemimethylated plus</td> <td>coverage of reads in a 5mCpG/CpG state e.g. 0</td>
</tr>
<tr>
  <td>10. coverage hemimethylated minus</td> <td>coverage of reads in a CpG/5mCpG state e.g. 0</td>
</tr>
<tr>
  <td>11. coverage unmethylated</td> <td>coverage of reads in a CpG/CpG state e.g. 6</td>
</tr>
</table>

### Plotting & Helper Functions
We also provide a series of helperfunction to plot and analyse the double strand data. This includes a four-state heatmap, summary bar plots, extracting & plotting the kinetic features.


#### Plot Four-State Heatmap
This function generates a four-state heat map to visualize DNA methylation patterns. It plots the methylation state of individual CpG sites across single DNA molecules within a specified genomic region. Each CpG is color-coded based on its methylation status, enabling clear interpretation of epigenetic variation at single-molecule resolution.

```
plot_CpG-hemi-heatmap.py --help
usage: plot_CpG-hemi-heatmap.py [-h] [--output_path OUTPUT_PATH] [--color_scheme COLOR_SCHEME] [--min_percentage MIN_PERCENTAGE] [--threshold THRESHOLD] [--show_readnames]
                                [--log_level {off,critical,error,warning,info,debug}]
                                bam_path region

Plot CpG Methylation Heatmap from BAM file

positional arguments:
  bam_path              Path to the BAM file
  region                Genomic region to analyze, e.g., NC_000021.9:1-1000 (1-based closed interval)

optional arguments:
  -h, --help            show this help message and exit
  --output_path OUTPUT_PATH
                        Path to save the heatmap plot, e.g., outputfolder/heatmap.png. If not specified, the plot will be shown interactively
  --color_scheme COLOR_SCHEME
                        Comma-separated list of four colors (for unmethylated, hemi(+), hemi(-), fully methylated), in a matplotlib-compatible format (e.g. 'deepskyblue,#77cc2c,#bae7b9,orangered'). Missing values are
                        displayed in white.
  --min_percentage MIN_PERCENTAGE
                        Minimum fraction of reads that must contain a CpG for it to be included in the heatmap (default: 0.1)
  --threshold THRESHOLD
                        Modification likelihood threshold (0-255) for a base to be modified (default: 128).
  --show_readnames      Show read names as y-axis labels in the heatmap.
  --log_level {off,critical,error,warning,info,debug}
```

#### Plot Sample Summary
```
plot_sample_summary.py --help
usage: plot_sample_summary.py [-h] -i INPUT -o OUTPUT [--region REGION] [-r REGIONS] [-n NAMES] [--title TITLE] [--svg]

Stacked Frequency Summary Bar Plot Tool (multi-sample, multi-region)

optional arguments:
  -h, --help            show this help message and exit
  -i INPUT, --input INPUT
                        Comma-separated list of input .dsi.gz files
  -o OUTPUT, --output OUTPUT
                        Output image file or prefix (e.g., .png or prefix for multi-region)
  --region REGION       Genomic region to plot, e.g., chr21:1-46709983
  -r REGIONS, --regions REGIONS
                        BED file (tab-separated, columns: chr, start, stop[, label]) for multiple regions
  -n NAMES, --names NAMES
                        Comma-separated list of sample names, corresponding to input files (optional)
  --title TITLE         Title of the plot
  --svg                 Also save plot(s) as SVG
```

#### Plot Region Summary
```
plot_region_summary.py --help
usage: plot_region_summary.py [-h] -i INPUT -o OUTPUT [-r REGIONS] [--svg] [--title TITLE]

Stacked Frequency Bar Plot Tool

optional arguments:
  -h, --help            show this help message and exit
  -i INPUT, --input INPUT
                        Input .dsi.gz file
  -o OUTPUT, --output OUTPUT
                        Output image file (e.g., .png) or prefix if using --regions
  -r REGIONS, --regions REGIONS
                        BED file (tab-separated, columns: chr, start, stop[, label]) for multiple regions
  --svg                 Also save plot(s) as SVG
  --title TITLE         Title of the plot (default: "Methylation Profile")
```

#### Plot Features
```
plot_kinetics_from_tsv.py --help
usage: plot_kinetics_from_tsv.py [-h] --input INPUT --output OUTPUT [--num_rows NUM_ROWS] [--log-file LOG_FILE] [--threads THREADS]

Plot mean IPD and PW values from TSV files.

optional arguments:
  -h, --help            show this help message and exit
  --input INPUT, -i INPUT
                        Path to the input folder containing numpy array files
  --output OUTPUT, -o OUTPUT
                        Path to the output folder to save the plots
  --num_rows NUM_ROWS, -n NUM_ROWS
                        Number of rows to use for the plot
  --log-file LOG_FILE, -l LOG_FILE
                        Path to the log file
  --threads THREADS, -t THREADS
                        Number of CPUs to use
```
