"""Django settings for OLDP (using django-configurations)"""

import os
from pathlib import Path

from configurations import Configuration, values
from django.contrib.messages import constants as message_constants
from django.utils.translation import gettext_lazy as _

from oldp.apps.courts.apps import CourtTypesDefault


class BaseConfiguration(Configuration):
    """Base configuration, all deployment configs (dev, prod, test, ...) inherits from this class."""

    DEBUG = False

    # Default primary key field type
    # https://docs.djangoproject.com/en/5.0/ref/settings/#default-auto-field

    DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

    # Make this unique, and don't share it with anybody.
    SECRET_KEY = "something_secret"

    SITE_NAME = values.Value("OLDP")
    SITE_EMAIL = values.Value("hello@openlegaldata.io")
    SITE_URL = values.Value("http://localhost:8000")
    SITE_TITLE = values.Value("Open Legal Data")
    SITE_ICON = values.Value("fa-balance-scale")
    SITE_TWITTER_URL = values.Value("https://twitter.com/openlegaldata")
    SITE_GITHUB_URL = values.Value("https://github.com/openlegaldata")
    SITE_LINKEDIN_URL = values.Value(
        "https://www.linkedin.com/company/open-legal-data/"
    )
    SITE_DISCORD_URL = values.Value("#discord")

    SITE_BLOG_URL = values.Value("//openlegaldata.io/blog")

    SITE_ID = 1

    INTERNAL_IPS = values.TupleValue(("127.0.0.1",))

    ALLOWED_HOSTS = values.ListValue(["127.0.0.1", "localhost"])

    CSRF_TRUSTED_ORIGINS = values.ListValue([])

    # Application definition
    INSTALLED_APPS = [
        # local apps
        "oldp.apps.accounts.apps.AccountsConfig",
        "oldp.apps.laws.apps.LawsConfig",
        "oldp.apps.homepage.apps.HomepageConfig",
        "oldp.apps.cases.apps.CasesConfig",
        "oldp.apps.topics.apps.TopicsConfig",
        "oldp.apps.processing.apps.ProcessingConfig",
        "oldp.apps.search.apps.SearchConfig",
        "oldp.apps.courts.apps.CourtsConfig",
        "oldp.apps.references.apps.ReferencesConfig",
        "oldp.apps.contact.apps.ContactConfig",
        "oldp.apps.annotations.apps.AnnotationsConfig",
        "oldp.apps.sources.apps.SourcesConfig",
        "oldp.apps.lib.apps.LibConfig",
        # third party apps
        # 'pipeline',  # build sass
        "compressor",
        "dal",
        "dal_select2",
        "haystack",
        # 'ckeditor',  # disable due to unfixed security issue
        "drf_yasg",
        "rest_framework",
        "rest_framework.authtoken",
        "django_filters",
        # 'envelope',  # contact form
        # 'tellme',  # feedback
        "widget_tweaks",  # forms
        "crispy_forms",
        "crispy_bootstrap4",
        "mathfilters",  # math filters for templates
        # 'bootstrapform',
        "allauth",
        "allauth.account",
        "allauth.socialaccount",
        # 'allauth.socialaccount.providers.google',
        # 'allauth.socialaccount.providers.github',
        # 'allauth.socialaccount.providers.twitter',
        # django internal
        "django.contrib.admin",
        "django.contrib.auth",
        "django.contrib.sites",
        "django.contrib.contenttypes",
        "django.contrib.sessions",
        "django.contrib.messages",
        "django.contrib.staticfiles",
        "django.contrib.flatpages",
        "django.contrib.sitemaps",
    ]

    CRISPY_ALLOWED_TEMPLATE_PACKS = "bootstrap4"

    CRISPY_TEMPLATE_PACK = "bootstrap4"

    # ############## PATHS ###############

    BASE_DIR = Path(os.path.abspath(__file__)).parent.parent

    PACKAGE_DIR = BASE_DIR / "oldp"
    APPS_DIR = PACKAGE_DIR / "apps"
    ASSETS_DIR = PACKAGE_DIR / "assets"
    WORKING_DIR = BASE_DIR / "workingdir"

    # Email settings
    DEFAULT_FROM_EMAIL = values.Value("no-reply@openlegaldata.io")
    EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
    EMAIL_HOST = values.Value("localhost")
    EMAIL_PORT = values.IntegerValue(25)
    EMAIL_USE_TLS = values.BooleanValue(False)
    EMAIL_HOST_USER = values.Value("")
    EMAIL_HOST_PASSWORD = values.Value("")

    MIDDLEWARE = [
        # Simplified static file serving.
        # https://warehouse.python.org/project/whitenoise/
        "whitenoise.middleware.WhiteNoiseMiddleware",
        "django.middleware.security.SecurityMiddleware",
        "django.contrib.sessions.middleware.SessionMiddleware",
        "django.middleware.locale.LocaleMiddleware",
        "oldp.apps.lib.apps.DomainLocaleMiddleware",
        "django.middleware.common.CommonMiddleware",
        "django.middleware.csrf.CsrfViewMiddleware",
        "django.contrib.auth.middleware.AuthenticationMiddleware",
        "django.contrib.messages.middleware.MessageMiddleware",
        "django.middleware.clickjacking.XFrameOptionsMiddleware",
        "django.contrib.flatpages.middleware.FlatpageFallbackMiddleware",
        # 'django.middleware.gzip.GZipMiddleware',
        # 'pipeline.middleware.MinifyHTMLMiddleware',
        "allauth.account.middleware.AccountMiddleware",
    ]

    ROOT_URLCONF = "oldp.urls"

    TEMPLATES = [
        {
            "BACKEND": "django.template.backends.django.DjangoTemplates",
            "DIRS": [PACKAGE_DIR / "assets/templates"],
            "APP_DIRS": True,
            "OPTIONS": {
                "context_processors": [
                    "django.template.context_processors.debug",
                    "django.template.context_processors.request",
                    "django.contrib.auth.context_processors.auth",
                    "django.contrib.messages.context_processors.messages",
                    "oldp.apps.lib.context_processors.global_context_processor",
                ],
            },
        },
    ]

    WSGI_APPLICATION = "oldp.wsgi.application"

    # Messages

    MESSAGE_LEVEL = message_constants.DEBUG
    MESSAGE_TAGS = {
        message_constants.DEBUG: "alert-info",
        message_constants.INFO: "alert-info",
        message_constants.SUCCESS: "alert-success",
        message_constants.WARNING: "alert-warning",
        message_constants.ERROR: "alert-danger",
    }

    # Password validation
    # https://docs.djangoproject.com/en/1.11/ref/settings/#auth-password-validators

    AUTH_PASSWORD_VALIDATORS = [
        {
            "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
        },
        {
            "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
        },
        {
            "NAME": "django.contrib.auth.password_validation.CommonPasswordValidator",
        },
        {
            "NAME": "django.contrib.auth.password_validation.NumericPasswordValidator",
        },
    ]

    AUTHENTICATION_BACKENDS = (
        # Needed to login by username in Django admin, regardless of `allauth`
        "django.contrib.auth.backends.ModelBackend",
        # `allauth` specific authentication methods, such as login by e-mail
        "allauth.account.auth_backends.AuthenticationBackend",
    )

    LOGIN_REDIRECT_URL = "/accounts/email/"
    # ACCOUNT_EMAIL_REQUIRED = True
    ACCOUNT_EMAIL_VERIFICATION = "mandatory"
    ACCOUNT_USERNAME_BLACKLIST = ["admin", "oldp", "openlegaldata"]
    ACCOUNT_USERNAME_MIN_LENGTH = 3

    ACCOUNT_SIGNUP_FIELDS = ["email*", "username*", "password1*", "password2*"]

    # Custom adapter for graceful email error handling
    ACCOUNT_ADAPTER = "oldp.apps.accounts.adapters.CustomAccountAdapter"

    # Internationalization
    # https://docs.djangoproject.com/en/5.0/topics/i18n/

    # Select language based on domain
    # https://7webpages.com/blog/switch-language-regarding-of-domain-in-django/

    # Set like this: DJANGO_LANGUAGES_DOMAINS="{'de.foo.com':'de','fr.foo.com':'fr'}"
    LANGUAGES_DOMAINS = values.DictValue(
        {
            "localhost:8000": "en",
            "oldp.local:8000": "en",
            "de.oldp.local:8000": "de",
            "127.0.0.1:8000": "de",
        }
    )

    LANGUAGE_CODE = "en"

    LANGUAGES = (
        ("en", _("English")),
        ("de", _("German")),
    )

    LOCALE_PATHS = (PACKAGE_DIR / "locale",)

    TIME_ZONE = "UTC"

    USE_I18N = True

    USE_L10N = True

    USE_TZ = True

    PAGINATE_BY = 50  # Items per page

    PAGINATE_UNTIL = 10  # Max. number of pages

    DATABASES = values.DatabaseURLValue("sqlite:///dev.db")

    # Caching

    # Cache time to live is 15 minutes.
    CACHE_DISABLE = values.BooleanValue(False)
    CACHE_TTL = 60 * 15
    CACHE_BACKEND = values.Value("file", environ_name="CACHE_BACKEND")

    # Honor the 'X-Forwarded-Proto' header for request.is_secure()
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")

    # Static files (CSS, JavaScript, Images)
    # https://docs.djangoproject.com/en/1.9/howto/static-files/
    STATIC_ROOT = PACKAGE_DIR / "assets/static-dist"
    STATIC_URL = "/static/"

    STATICFILES_FINDERS = (
        "django.contrib.staticfiles.finders.FileSystemFinder",
        "django.contrib.staticfiles.finders.AppDirectoriesFinder",
        "compressor.finders.CompressorFinder",
    )

    # Extra places for collectstatic to find static files.
    STATICFILES_DIRS = [PACKAGE_DIR / "assets/static"]

    # Set compress compilers
    COMPRESS_ENABLED = True
    COMPRESS_OFFLINE = True

    COMPRESS_PRECOMPILERS = [
        # SASS compiler
        ("text/x-scss", "sass {infile} {outfile}"),
        # ('text/x-scss', 'django_libsass.SassCompiler'),
    ]
    COMPRESS_OUTPUT_DIR = "cache"

    MEDIA_ROOT = BASE_DIR / "media"
    MEDIA_URL = "/media/"

    # Simplified static file serving.
    # https://warehouse.python.org/project/whitenoise/

    # STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'

    # Tellme feedback
    # TELLME_FEEDBACK_EMAIL = values.Value('hello@openlegaldata.io', environ_name='FEEDBACK_EMAIL')

    # CKEditor (wysiwyg)
    # disabled due to unfixed security issue

    # Elasticsearch
    ELASTICSEARCH_URL = values.Value(
        "http://localhost:9200/", environ_name="ELASTICSEARCH_URL"
    )
    ELASTICSEARCH_INDEX = values.Value("oldp", environ_name="ELASTICSEARCH_INDEX")

    HAYSTACK_CONNECTIONS = {
        "default": {
            "ENGINE": "oldp.apps.search.search_backend.SearchEngine",
            "URL": values.Value(
                "http://localhost:9200/", environ_name="ELASTICSEARCH_URL"
            ),
            "INDEX_NAME": values.Value("oldp", environ_name="ELASTICSEARCH_INDEX"),
            "TIMEOUT": 10,
            "KWARGS": {
                "retry_on_timeout": True,
                "max_retries": 1,
            },
        },
    }

    ELASTICSEARCH_INDEX_SETTINGS = {
        "settings": {
            "number_of_replicas": 0,
            "refresh_interval": "60s",
        }
    }

    # Logging
    LOGGING = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "console": {
                "format": "%(asctime)s %(levelname)-8s %(name)-12s %(message)s",
            },
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "formatter": "console",
            },
            "logfile": {
                "level": "DEBUG",
                "class": "logging.handlers.RotatingFileHandler",
                "filename": BASE_DIR / "logs/oldp.log",
                "maxBytes": 1024 * 1024 * 15,  # 15MB
                "backupCount": 10,
                "formatter": "console",
            },
            # Add Handler for Sentry for `warning` and above
            # 'sentry': {
            #     'level': 'WARNING',
            #     'class': 'raven.contrib.django.raven_compat.handlers.SentryHandler',
            # },
        },
        "loggers": {
            "": {  # root logger
                "level": "INFO",
                "handlers": ["console", "logfile"],
            },
            "oldp": {
                "level": "DEBUG",
            },
            "refex": {
                "level": "DEBUG",
            },
            "requests": {"level": "ERROR"},
            "elasticsearch": {"level": "ERROR"},
        },
    }

    # Test config
    #########################

    # Set false to exclude specific tests from test suite
    # TEST_MYSQL = False  # auto detection based on DB settings
    TEST_WITH_ES = values.BooleanValue(True)
    TEST_WITH_WEB = values.BooleanValue(True)
    TEST_WITH_SELENIUM = values.BooleanValue(False)

    ########################
    # Rest API framework
    ########################

    REST_FRAMEWORK = {
        # Use Django's standard `django.contrib.auth` permissions,
        # or allow read-only access for unauthenticated users.
        "DEFAULT_PERMISSION_CLASSES": [
            "rest_framework.permissions.DjangoModelPermissionsOrAnonReadOnly"
        ],
        "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.LimitOffsetPagination",
        "DEFAULT_FILTER_BACKENDS": (
            "django_filters.rest_framework.DjangoFilterBackend",
        ),
        "PAGE_SIZE": 50,
        "DEFAULT_RENDERER_CLASSES": (
            "rest_framework.renderers.JSONRenderer",
            "rest_framework.renderers.BrowsableAPIRenderer",
            "rest_framework_xml.renderers.XMLRenderer",
        ),
        # Auth
        "DEFAULT_AUTHENTICATION_CLASSES": (
            "oldp.apps.accounts.authentication.CombinedTokenAuthentication",
            "rest_framework.authentication.SessionAuthentication",
        ),
        "DEFAULT_THROTTLE_CLASSES": ("rest_framework.throttling.AnonRateThrottle",),
        "DEFAULT_THROTTLE_RATES": {
            "anon": "100/day",
            "user": "5000/hour",
        },
        "EXCEPTION_HANDLER": "oldp.api.exceptions.full_details_exception_handler",
    }

    SWAGGER_SETTINGS = {
        "SECURITY_DEFINITIONS": {
            "api_key": {"type": "apiKey", "in": "header", "name": "Authorization"}
        },
    }

    # Processing pipeline
    PROCESSING_STEPS = {
        "Case": [
            "oldp.apps.cases.processing.processing_steps.assign_court",
            "oldp.apps.cases.processing.processing_steps.extract_refs",
            "oldp.apps.cases.processing.processing_steps.generate_related",
            "oldp.apps.cases.processing.processing_steps.set_review_pending",
            "oldp.apps.cases.processing.processing_steps.set_review_accepted",
            "oldp.apps.cases.processing.processing_steps.set_review_rejected",
        ],
        "Law": [
            "oldp.apps.laws.processing.processing_steps.extract_refs",
            "oldp.apps.laws.processing.processing_steps.set_review_pending",
            "oldp.apps.laws.processing.processing_steps.set_review_accepted",
        ],
        "LawBook": [
            "oldp.apps.topics.processing.processing_steps.assign_topics_to_law_book",
            "oldp.apps.laws.processing.processing_steps.set_lawbook_review_pending",
            "oldp.apps.laws.processing.processing_steps.set_lawbook_review_accepted",
        ],
        "Court": [
            "oldp.apps.courts.processing.processing_steps.enrich_from_wikipedia",
            "oldp.apps.courts.processing.processing_steps.set_aliases",
            "oldp.apps.courts.processing.processing_steps.assign_jurisdiction",
            "oldp.apps.courts.processing.processing_steps.set_review_pending",
            "oldp.apps.courts.processing.processing_steps.set_review_accepted",
        ],
        "Reference": [
            "oldp.apps.references.processing.processing_steps.assign_refs",
        ],
    }

    # Courts
    COURT_JURISDICTIONS = {}
    COURT_LEVELS_OF_APPEAL = {}
    COURT_TYPES = CourtTypesDefault()

    # Case creation API validation settings
    # These settings control input validation for the case creation API endpoint
    CASE_CREATION_VALIDATION = {
        "content_min_length": 10,  # Minimum case content length
        "content_max_length": 10000000,  # Maximum case content length (10MB)
        "file_number_min_length": 1,  # Minimum file number length
        "file_number_max_length": 100,  # Maximum file number length
        "title_max_length": 255,  # Maximum title length
        "abstract_max_length": 50000,  # Maximum abstract length
        "court_name_max_length": 255,  # Maximum court name length
    }

    #######################
    # Setup methods
    #######################

    @classmethod
    def post_setup(cls):
        """Check database setup after settings are loaded"""
        # super(Base, cls).post_setup()

        if cls.DATABASES["default"]["ENGINE"] == "django.db.backends.mysql":
            # Force strict mode (MySQL only)
            # https://stackoverflow.com/questions/23022858/force-strict-sql-mode-in-django
            if "OPTIONS" not in cls.DATABASES["default"]:
                cls.DATABASES["default"]["OPTIONS"] = {}

            cls.DATABASES["default"]["OPTIONS"]["sql_mode"] = "traditional"
            # TODO Check this to handle "Incorrect string value" db error
            # cls.DATABASES['default']['OPTIONS']['charset'] = 'utf8mb4'

            cls.DATABASE_MYSQL = True
        else:
            cls.DATABASE_MYSQL = False

        # Dynamic cache configuration based on CACHE_BACKEND environment variable
        if cls.CACHE_BACKEND == "redis":
            cls.CACHES = {
                "default": {
                    "BACKEND": "django_redis.cache.RedisCache",
                    "LOCATION": values.Value(
                        "redis://127.0.0.1:6379/1", environ_name="REDIS_URL"
                    ),
                    "OPTIONS": {"CLIENT_CLASS": "django_redis.client.DefaultClient"},
                }
            }
        else:  # Default to file-based cache
            cls.CACHES = {
                "default": {
                    "BACKEND": "django.core.cache.backends.filebased.FileBasedCache",
                    "LOCATION": values.Value(
                        "/var/tmp/django_cache", environ_name="FILE_CACHE_LOCATION"
                    ),
                }
            }

        # Disable cache
        if cls.DEBUG and cls.CACHE_DISABLE:
            cls.CACHES["default"]["BACKEND"] = (
                "django.core.cache.backends.dummy.DummyCache"
            )

        # Overwrite log filename
        log_file = values.Value(default=None, environ_name="LOG_FILE")

        if (
            "handlers" in cls.LOGGING
            and "logfile" in cls.LOGGING["handlers"]
            and log_file
        ):
            cls.LOGGING["handlers"]["logfile"]["filename"] = os.path.join(
                cls.BASE_DIR, "logs", log_file
            )


class DevConfiguration(BaseConfiguration):
    """Development settings (debugging enabled)"""

    DEBUG = True

    ALLOWED_HOSTS = ["*"]

    COMPRESS_OFFLINE = False

    INSTALLED_APPS = BaseConfiguration.INSTALLED_APPS + [
        "debug_toolbar",
    ]

    MIDDLEWARE = BaseConfiguration.MIDDLEWARE + [
        "debug_toolbar.middleware.DebugToolbarMiddleware",
    ]


class TestConfiguration(BaseConfiguration):
    """Use these settings for unit testing"""

    DEBUG = True

    COMPRESS_OFFLINE = False
    COMPRESS_ENABLED = False
    COMPRESS_PRECOMPILERS = []  # Disable SCSS compilation in tests

    DATABASES = values.DatabaseURLValue("sqlite:///test.db")
    ELASTICSEARCH_INDEX = values.Value("oldp_test")

    # Control mocking: True = use mocks (default), False = use real ES
    MOCK_ES_TESTS = values.BooleanValue(True)

    # Enable ES tests by default (they now run with mocks)
    TEST_WITH_ES = values.BooleanValue(True)
    TEST_WITH_WEB = values.BooleanValue(False)
    TEST_WITH_SELENIUM = values.BooleanValue(False)

    @property
    def HAYSTACK_CONNECTIONS(self):
        """Configure Haystack to use mock or real Elasticsearch based on settings."""
        if self.MOCK_ES_TESTS:
            return {
                "default": {
                    "ENGINE": "oldp.apps.search.mock_backend.MockElasticsearchEngine",
                }
            }
        return {
            "default": {
                "ENGINE": "oldp.apps.search.search_backend.SearchEngine",
                "URL": "http://localhost:9200/",
                "INDEX_NAME": "oldp_test",
            }
        }

    # STATICFILES_STORAGE/STORAGES are mutually exclusive.
    # STATICFILES_STORAGE = 'django.contrib.staticfiles.storage.StaticFilesStorage'

    CACHE_DISABLE = True
    CACHES = {
        "default": {
            "BACKEND": "django.core.cache.backends.dummy.DummyCache",
        }
    }

    # Override logging to suppress expected logs during tests
    LOGGING = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "console": {
                "format": "%(asctime)s %(levelname)-8s %(name)-12s %(message)s",
            },
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "formatter": "console",
                "level": "CRITICAL",  # Only show critical errors in console
            },
        },
        "loggers": {
            "": {  # root logger - suppress all but critical
                "level": "CRITICAL",
                "handlers": ["console"],
            },
            "django": {"level": "CRITICAL"},
            "django.request": {"level": "CRITICAL"},
            "oldp": {"level": "CRITICAL"},
            "refex": {"level": "CRITICAL"},
            "haystack": {"level": "CRITICAL"},
            "elasticsearch": {"level": "CRITICAL"},
        },
    }

    @classmethod
    def post_setup(cls):
        """Override post_setup to skip LOGGING modification since it's a property"""
        # Handle DATABASE setup
        if cls.DATABASES["default"]["ENGINE"] == "django.db.backends.mysql":
            if "OPTIONS" not in cls.DATABASES["default"]:
                cls.DATABASES["default"]["OPTIONS"] = {}
            cls.DATABASES["default"]["OPTIONS"]["sql_mode"] = "traditional"
            cls.DATABASE_MYSQL = True
        else:
            cls.DATABASE_MYSQL = False

        # CACHES already set in TestConfiguration, no need to modify
        # LOGGING is a property in TestConfiguration, skip modification


class ProdConfiguration(BaseConfiguration):
    """Production settings (override default values with environment vars"""

    SECRET_KEY = values.SecretValue()

    DEBUG = False

    ALLOWED_HOSTS = values.ListValue(["de.openlegaldata.io", "localhost"])

    ADMINS = values.SingleNestedTupleValue()

    # Override logging to set INFO level for production
    @property
    def LOGGING(self):
        """Set log level to INFO for production to reduce verbosity"""
        config = super().LOGGING.copy()
        # Update oldp and refex loggers to INFO level instead of DEBUG
        config["loggers"]["oldp"]["level"] = "INFO"
        config["loggers"]["refex"]["level"] = "INFO"
        return config
