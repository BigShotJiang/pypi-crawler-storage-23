from django.apps import AppConfig


class ContactConfig(AppConfig):
    name = "oldp.apps.contact"
