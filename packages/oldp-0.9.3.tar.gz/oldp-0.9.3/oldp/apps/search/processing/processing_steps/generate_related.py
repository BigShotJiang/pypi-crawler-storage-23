import logging

logger = logging.getLogger(__name__)


class BaseGenerateRelated(object):
    pass
