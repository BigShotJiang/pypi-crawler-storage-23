from django.apps import AppConfig


class LawsConfig(AppConfig):
    name = "oldp.apps.laws"
