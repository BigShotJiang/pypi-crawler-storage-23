"""Law creation services."""

from oldp.apps.laws.services.law_creator import LawCreator
from oldp.apps.laws.services.lawbook_creator import LawBookCreator

__all__ = ["LawBookCreator", "LawCreator"]
