from oldp.apps.processing.processing_steps import BaseProcessingStep


class PostProcessingStep(BaseProcessingStep):
    def process(self, content):
        pass
