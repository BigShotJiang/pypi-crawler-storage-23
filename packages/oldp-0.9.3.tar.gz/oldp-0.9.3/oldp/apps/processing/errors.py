class ProcessingError(ValueError):
    pass
