from django.apps import AppConfig


class AnnotationsConfig(AppConfig):
    name = "oldp.apps.annotations"
