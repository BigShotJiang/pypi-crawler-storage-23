from django.apps import AppConfig


class SourcesConfig(AppConfig):
    name = "oldp.apps.sources"
