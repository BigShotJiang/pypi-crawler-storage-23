"""SELECT c.source_id, COUNT(*)
FROM cases_case.c
GROUP BY source_id

"""
