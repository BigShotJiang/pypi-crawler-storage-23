from __future__ import annotations

from datetime import datetime, timezone

import pytest

from tools.team_analytics_audit.analyzer import (
    TeamAnalyzer,
    _compute_trajectory,
    _gini,
    _iso_week,
    _top_dir,
)
from tools.team_analytics_audit.models import FileChange, RawCommit


def make_commit(
    hash_: str,
    author: str,
    email: str,
    subject: str = "feat: something",
    files: list[FileChange] | None = None,
    day: int = 15,
    hour: int = 10,
    parents: list[str] | None = None,
) -> RawCommit:
    ts = datetime(2026, 1, day, hour, 0, 0, tzinfo=timezone.utc)
    return RawCommit(
        hash=hash_,
        author_name=author,
        author_email=email,
        timestamp=ts,
        subject=subject,
        parent_hashes=parents or ["p1"],
        files_changed=files or [
            FileChange("src/main.py", 10, 2)
        ],
        is_merge=len(parents or ["p1"]) > 1,
    )


FIXTURE_COMMITS = [
    make_commit("a1", "Alice", "alice@ex.com", "feat: feature A", day=15),
    make_commit("a2", "Alice", "alice@ex.com", "fix: bug fix", day=16),
    make_commit("b1", "Bob", "bob@ex.com", "feat: feature B", day=15),
    make_commit("b2", "Bob", "bob@ex.com", "docs: update", day=17),
    make_commit("b3", "Bob", "bob@ex.com", "chore: cleanup", day=18),
]


class TestGiniIndex:
    def test_equal_distribution(self):
        result = _gini([10, 10, 10])
        assert result < 0.1

    def test_unequal_distribution(self):
        result = _gini([1, 1, 100])
        assert result > 0.5

    def test_single_contributor(self):
        result = _gini([50])
        assert result == 0.0

    def test_empty_list(self):
        result = _gini([])
        assert result == 0.0


class TestIsoWeek:
    def test_returns_iso_week_string(self):
        dt = datetime(2026, 1, 15, 0, 0, 0, tzinfo=timezone.utc)
        result = _iso_week(dt)
        assert result.startswith("2026-W")


class TestTopDir:
    def test_top_dir_nested(self):
        assert _top_dir("src/main/app.py") == "src"

    def test_top_dir_flat(self):
        assert _top_dir("README.md") == "README.md"

    def test_top_dir_root(self):
        result = _top_dir("file.py")
        assert result == "file.py"


class TestComputeTrajectory:
    def test_stable_with_single_week(self):
        result = _compute_trajectory({"2026-W01": 5})
        assert result == "stable"

    def test_stable_trajectory(self):
        weekly = {
            "2026-W01": 10,
            "2026-W02": 10,
            "2026-W03": 10,
            "2026-W04": 10,
        }
        result = _compute_trajectory(weekly)
        assert result == "stable"

    def test_accelerating_trajectory(self):
        weekly = {
            "2026-W01": 5,
            "2026-W02": 5,
            "2026-W03": 15,
            "2026-W04": 15,
        }
        result = _compute_trajectory(weekly)
        assert result == "accelerating"

    def test_decelerating_trajectory(self):
        weekly = {
            "2026-W01": 15,
            "2026-W02": 15,
            "2026-W03": 3,
            "2026-W04": 3,
        }
        result = _compute_trajectory(weekly)
        assert result == "decelerating"


class TestTeamAnalyzer:
    def setup_method(self):
        self.analyzer = TeamAnalyzer()
        self.period_start = datetime(2026, 1, 1, tzinfo=timezone.utc)
        self.period_end = datetime(2026, 1, 31, tzinfo=timezone.utc)

    def test_analyze_returns_team_audit_result(self):
        result = self.analyzer.analyze(
            commits=FIXTURE_COMMITS,
            repository_name="test-repo",
            period_start=self.period_start,
            period_end=self.period_end,
        )
        assert result.repository_name == "test-repo"
        assert result.total_commits == 5

    def test_analyze_produces_contributors(self):
        result = self.analyzer.analyze(
            commits=FIXTURE_COMMITS,
            repository_name="test-repo",
            period_start=self.period_start,
            period_end=self.period_end,
        )
        names = {c.name for c in result.contributors}
        assert "Alice" in names
        assert "Bob" in names

    def test_analyze_commit_counts(self):
        result = self.analyzer.analyze(
            commits=FIXTURE_COMMITS,
            repository_name="test-repo",
            period_start=self.period_start,
            period_end=self.period_end,
        )
        alice = next(
            c for c in result.contributors if c.name == "Alice"
        )
        bob = next(
            c for c in result.contributors if c.name == "Bob"
        )
        assert alice.commit_count == 2
        assert bob.commit_count == 3

    def test_analyze_empty_commits(self):
        result = self.analyzer.analyze(
            commits=[],
            repository_name="empty-repo",
            period_start=self.period_start,
            period_end=self.period_end,
        )
        assert result.total_commits == 0
        assert result.contributors == []

    def test_analyze_with_comparison(self):
        compare_commits = [
            make_commit("c1", "Alice", "alice@ex.com", day=5),
        ]
        result = self.analyzer.analyze(
            commits=FIXTURE_COMMITS,
            repository_name="test-repo",
            period_start=self.period_start,
            period_end=self.period_end,
            compare_commits=compare_commits,
        )
        assert result.velocity.comparison_delta is not None

    def test_analyze_without_comparison(self):
        result = self.analyzer.analyze(
            commits=FIXTURE_COMMITS,
            repository_name="test-repo",
            period_start=self.period_start,
            period_end=self.period_end,
        )
        assert result.velocity.comparison_delta is None

    def test_health_status_values(self):
        result = self.analyzer.analyze(
            commits=FIXTURE_COMMITS,
            repository_name="test-repo",
            period_start=self.period_start,
            period_end=self.period_end,
        )
        assert result.team_health.health_status in (
            "Healthy", "Needs Attention", "At Risk"
        )

    def test_velocity_trajectory_values(self):
        result = self.analyzer.analyze(
            commits=FIXTURE_COMMITS,
            repository_name="test-repo",
            period_start=self.period_start,
            period_end=self.period_end,
        )
        assert result.velocity.trajectory in (
            "accelerating", "stable", "decelerating"
        )

    def test_recommendations_not_empty(self):
        result = self.analyzer.analyze(
            commits=FIXTURE_COMMITS,
            repository_name="test-repo",
            period_start=self.period_start,
            period_end=self.period_end,
        )
        assert len(result.recommendations) > 0
