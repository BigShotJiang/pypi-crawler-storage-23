"""Unit tests for NotionClient."""

import json
import pytest
from unittest.mock import patch, MagicMock
from urllib.error import HTTPError

from tools.notion_hub.client import (
    NotionClient,
    NotionAPIError,
    MaxRetriesExceeded,
    MAX_RETRIES,
    NOTION_API_BASE,
)
from tools.notion_hub.config import NotionConfig


@pytest.fixture
def client() -> NotionClient:
    """Create a NotionClient for testing."""
    config = NotionConfig(api_key="ntn_test123")
    return NotionClient(config=config)


class TestNotionClient:
    """Tests for NotionClient."""

    def test_get_headers(self, client: NotionClient) -> None:
        """Test headers are correctly formatted."""
        headers = client._get_headers()
        assert headers["Authorization"] == "Bearer ntn_test123"
        assert "Notion-Version" in headers
        assert headers["Content-Type"] == "application/json"

    @patch("tools.notion_hub.client.urlopen")
    def test_make_request_success(
        self,
        mock_urlopen: MagicMock,
        client: NotionClient,
    ) -> None:
        """Test successful API request."""
        mock_response = MagicMock()
        mock_response.read.return_value = b'{"object": "page", "id": "123"}'
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_response

        result = client._make_request("GET", "/pages/123")

        assert result["object"] == "page"
        assert result["id"] == "123"

    @patch("tools.notion_hub.client.urlopen")
    def test_make_request_http_error(
        self,
        mock_urlopen: MagicMock,
        client: NotionClient,
    ) -> None:
        """Test HTTP error handling."""
        error_body = json.dumps({
            "object": "error",
            "code": "validation_error",
            "message": "Invalid property",
        }).encode()

        mock_error = HTTPError(
            url=f"{NOTION_API_BASE}/pages",
            code=400,
            msg="Bad Request",
            hdrs={},
            fp=MagicMock(),
        )
        mock_error.read = MagicMock(return_value=error_body)
        mock_urlopen.side_effect = mock_error

        with pytest.raises(NotionAPIError) as exc_info:
            client._make_request("POST", "/pages", {"data": "test"})

        assert exc_info.value.status_code == 400
        assert exc_info.value.code == "validation_error"

    @patch("tools.notion_hub.client.time.sleep")
    @patch("tools.notion_hub.client.urlopen")
    def test_retry_on_rate_limit(
        self,
        mock_urlopen: MagicMock,
        mock_sleep: MagicMock,
        client: NotionClient,
    ) -> None:
        """Test retry with exponential backoff on rate limit."""
        rate_limit_error = HTTPError(
            url=f"{NOTION_API_BASE}/pages",
            code=429,
            msg="Too Many Requests",
            hdrs={"Retry-After": "2"},
            fp=MagicMock(),
        )
        rate_limit_error.read = MagicMock(
            return_value=b'{"code": "rate_limited", "message": "Rate limited"}'
        )
        rate_limit_error.headers = {"Retry-After": "2"}

        mock_response = MagicMock()
        mock_response.read.return_value = b'{"object": "page", "id": "123"}'
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)

        mock_urlopen.side_effect = [rate_limit_error, mock_response]

        result = client._request_with_retry("GET", "/pages/123")

        assert result["id"] == "123"
        assert mock_sleep.called

    @patch("tools.notion_hub.client.time.sleep")
    @patch("tools.notion_hub.client.urlopen")
    def test_max_retries_exceeded(
        self,
        mock_urlopen: MagicMock,
        mock_sleep: MagicMock,
        client: NotionClient,
    ) -> None:
        """Test max retries exceeded raises exception."""
        rate_limit_error = HTTPError(
            url=f"{NOTION_API_BASE}/pages",
            code=429,
            msg="Too Many Requests",
            hdrs={},
            fp=MagicMock(),
        )
        rate_limit_error.read = MagicMock(
            return_value=b'{"code": "rate_limited", "message": "Rate limited"}'
        )
        rate_limit_error.headers = {}

        mock_urlopen.side_effect = [rate_limit_error] * MAX_RETRIES

        with pytest.raises(MaxRetriesExceeded):
            client._request_with_retry("GET", "/pages/123")

        assert mock_sleep.call_count == MAX_RETRIES

    @patch("tools.notion_hub.client.urlopen")
    def test_create_page(
        self,
        mock_urlopen: MagicMock,
        client: NotionClient,
    ) -> None:
        """Test page creation."""
        mock_response = MagicMock()
        mock_response.read.return_value = b'{"object": "page", "id": "page123", "url": "https://notion.so/page123"}'
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_response

        result = client.create_page(
            database_id="db123",
            properties={"Title": {"title": [{"text": {"content": "Test"}}]}},
        )

        assert result["id"] == "page123"

    @patch("tools.notion_hub.client.urlopen")
    def test_query_database(
        self,
        mock_urlopen: MagicMock,
        client: NotionClient,
    ) -> None:
        """Test database query."""
        mock_response = MagicMock()
        mock_response.read.return_value = b'{"object": "list", "results": [{"id": "page1"}]}'
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_response

        result = client.query_database(
            database_id="db123",
            filter_params={"property": "Status", "select": {"equals": "Active"}},
        )

        assert result["object"] == "list"
        assert len(result["results"]) == 1

    @patch("tools.notion_hub.client.urlopen")
    def test_list_databases(
        self,
        mock_urlopen: MagicMock,
        client: NotionClient,
    ) -> None:
        """Test listing databases."""
        mock_response = MagicMock()
        mock_response.read.return_value = b'{"object": "list", "results": [{"id": "db1"}, {"id": "db2"}]}'
        mock_response.__enter__ = MagicMock(return_value=mock_response)
        mock_response.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_response

        result = client.list_databases()

        assert len(result) == 2
        assert result[0]["id"] == "db1"
