"""Unit tests for dashboard server port file management."""

import os
from pathlib import Path
from unittest.mock import patch

import pytest

from tools.dashboard.server import (
    _remove_port_file,
    _write_port_file,
    start_dashboard_server,
    stop_dashboard_server,
    get_actual_port,
    get_websocket_port,
)


class TestWritePortFile:
    """Tests for _write_port_file."""

    def test_creates_port_file_with_correct_content(self, tmp_path):
        with patch("tools.dashboard.server.Path.cwd", return_value=tmp_path):
            _write_port_file(24282)

        port_file = tmp_path / ".optix_port"
        assert port_file.exists()
        assert port_file.read_text() == "24282"

    def test_writes_non_default_port(self, tmp_path):
        with patch("tools.dashboard.server.Path.cwd", return_value=tmp_path):
            _write_port_file(24290)

        port_file = tmp_path / ".optix_port"
        assert port_file.read_text() == "24290"

    def test_overwrites_existing_port_file(self, tmp_path):
        port_file = tmp_path / ".optix_port"
        port_file.write_text("99999")

        with patch("tools.dashboard.server.Path.cwd", return_value=tmp_path):
            _write_port_file(24285)

        assert port_file.read_text() == "24285"

    def test_survives_readonly_directory(self, tmp_path):
        readonly_dir = tmp_path / "readonly"
        readonly_dir.mkdir()
        readonly_dir.chmod(0o444)

        try:
            with patch("tools.dashboard.server.Path.cwd", return_value=readonly_dir):
                _write_port_file(24282)
        finally:
            readonly_dir.chmod(0o755)


class TestRemovePortFile:
    """Tests for _remove_port_file."""

    def test_removes_existing_port_file(self, tmp_path):
        port_file = tmp_path / ".optix_port"
        port_file.write_text("24282")

        with patch("tools.dashboard.server.Path.cwd", return_value=tmp_path):
            _remove_port_file()

        assert not port_file.exists()

    def test_noop_when_file_missing(self, tmp_path):
        with patch("tools.dashboard.server.Path.cwd", return_value=tmp_path):
            _remove_port_file()

    def test_survives_readonly_directory(self, tmp_path):
        readonly_dir = tmp_path / "readonly"
        readonly_dir.mkdir()
        port_file = readonly_dir / ".optix_port"
        port_file.write_text("24282")
        readonly_dir.chmod(0o444)

        try:
            with patch("tools.dashboard.server.Path.cwd", return_value=readonly_dir):
                _remove_port_file()
        finally:
            readonly_dir.chmod(0o755)


class TestStartDashboardServerPortFile:
    """Tests that start_dashboard_server writes a port file."""

    @pytest.fixture(autouse=True)
    def reset_server_globals(self):
        """Reset module globals before/after each test."""
        import tools.dashboard.server as mod
        orig_instance = mod._server_instance
        orig_thread = mod._server_thread
        orig_port = mod._actual_port
        orig_ws = mod._websocket_port
        mod._server_instance = None
        mod._server_thread = None
        mod._actual_port = None
        mod._websocket_port = None
        yield
        if mod._server_instance is not None:
            try:
                mod._server_instance.shutdown()
            except Exception:
                pass
        mod._server_instance = orig_instance
        mod._server_thread = orig_thread
        mod._actual_port = orig_port
        mod._websocket_port = orig_ws

    def test_start_writes_port_file(self, tmp_path):
        from config.defaults import DashboardConfig

        config = DashboardConfig(enabled=True, host="127.0.0.1", port=49152)

        with (
            patch("tools.dashboard.server.Path.cwd", return_value=tmp_path),
            patch("tools.dashboard.server._start_websocket_server"),
        ):
            thread = start_dashboard_server(config)

        assert thread is not None

        port_file = tmp_path / ".optix_port"
        assert port_file.exists()

        actual = get_actual_port()
        assert port_file.read_text() == str(actual)

    def test_start_disabled_does_not_write_port_file(self, tmp_path):
        from config.defaults import DashboardConfig

        config = DashboardConfig(enabled=False, host="127.0.0.1", port=24282)

        with patch("tools.dashboard.server.Path.cwd", return_value=tmp_path):
            thread = start_dashboard_server(config)

        assert thread is None
        assert not (tmp_path / ".optix_port").exists()


class TestStopDashboardServerPortFile:
    """Tests that stop_dashboard_server cleans up the port file."""

    @pytest.fixture(autouse=True)
    def reset_server_globals(self):
        import tools.dashboard.server as mod
        orig_instance = mod._server_instance
        orig_thread = mod._server_thread
        orig_port = mod._actual_port
        orig_ws = mod._websocket_port
        mod._server_instance = None
        mod._server_thread = None
        mod._actual_port = None
        mod._websocket_port = None
        yield
        mod._server_instance = orig_instance
        mod._server_thread = orig_thread
        mod._actual_port = orig_port
        mod._websocket_port = orig_ws

    def test_stop_removes_port_file(self, tmp_path):
        from config.defaults import DashboardConfig

        config = DashboardConfig(enabled=True, host="127.0.0.1", port=49152)

        with (
            patch("tools.dashboard.server.Path.cwd", return_value=tmp_path),
            patch("tools.dashboard.server._start_websocket_server"),
        ):
            start_dashboard_server(config)

        port_file = tmp_path / ".optix_port"
        assert port_file.exists()

        with patch("tools.dashboard.server.Path.cwd", return_value=tmp_path):
            stop_dashboard_server()

        assert not port_file.exists()
        assert get_actual_port() is None
        assert get_websocket_port() is None

    def test_stop_noop_when_not_running(self, tmp_path):
        with patch("tools.dashboard.server.Path.cwd", return_value=tmp_path):
            stop_dashboard_server()

        assert not (tmp_path / ".optix_port").exists()


class TestWebSocketInfo:
    """Tests for websocket info endpoint response structure."""

    @pytest.fixture(autouse=True)
    def reset_server_globals(self):
        import tools.dashboard.server as mod
        orig_port = mod._actual_port
        orig_ws = mod._websocket_port
        yield
        mod._actual_port = orig_port
        mod._websocket_port = orig_ws

    def test_websocket_url_uses_actual_port(self):
        import tools.dashboard.server as mod
        mod._actual_port = 24290
        mod._websocket_port = 24291

        assert get_websocket_port() == 24291
        assert get_actual_port() == 24290

    def test_websocket_port_is_http_plus_one(self, tmp_path):
        from config.defaults import DashboardConfig
        import tools.dashboard.server as mod

        config = DashboardConfig(enabled=True, host="127.0.0.1", port=49152)

        ws_called_with = {}

        def capture_ws(host, port):
            ws_called_with["host"] = host
            ws_called_with["port"] = port

        mod._server_instance = None
        mod._server_thread = None
        mod._actual_port = None
        mod._websocket_port = None

        with (
            patch("tools.dashboard.server.Path.cwd", return_value=tmp_path),
            patch("tools.dashboard.server._start_websocket_server", side_effect=capture_ws),
        ):
            thread = start_dashboard_server(config)

        try:
            assert thread is not None
            actual = get_actual_port()
            assert ws_called_with["port"] == actual + 1
        finally:
            if mod._server_instance is not None:
                mod._server_instance.shutdown()
            mod._server_instance = None
            mod._server_thread = None
            mod._actual_port = None
            mod._websocket_port = None

    def test_returns_none_when_not_running(self):
        import tools.dashboard.server as mod
        mod._actual_port = None
        mod._websocket_port = None

        assert get_websocket_port() is None
        assert get_actual_port() is None
