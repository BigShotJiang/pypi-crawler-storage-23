"""Unit tests for dashboard WebSocket server."""

import asyncio
import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from tools.dashboard.websocket import DashboardWebSocket
from tools.workflow.state import WorkflowStateManager


@pytest.fixture(autouse=True)
def reset_singleton():
    """Reset the DashboardWebSocket singleton between tests."""
    DashboardWebSocket._instance = None
    yield
    DashboardWebSocket._instance = None


@pytest.fixture()
def ws():
    return DashboardWebSocket()


@pytest.fixture(autouse=True)
def clear_workflows():
    manager = WorkflowStateManager()
    manager.clear_all()
    yield
    manager.clear_all()


class TestDashboardWebSocketSingleton:

    def test_is_singleton(self):
        a = DashboardWebSocket()
        b = DashboardWebSocket()
        assert a is b

    def test_initial_state(self, ws):
        assert ws._server is None
        assert ws._loop is None
        assert ws._thread is None
        assert ws.client_count == 0
        assert ws.is_running is False


class TestHandleMessagePing:

    @pytest.mark.asyncio
    async def test_ping_returns_pong(self, ws):
        mock_ws = AsyncMock()
        await ws._handle_message(json.dumps({"action": "ping"}), mock_ws)
        mock_ws.send.assert_called_once_with(json.dumps({"action": "pong"}))


class TestHandleMessageUnknown:

    @pytest.mark.asyncio
    async def test_unknown_action_returns_error(self, ws):
        mock_ws = AsyncMock()
        await ws._handle_message(json.dumps({"action": "unknown_thing"}), mock_ws)

        sent = json.loads(mock_ws.send.call_args[0][0])
        assert sent["action"] == "error"
        assert "Unknown action" in sent["message"]

    @pytest.mark.asyncio
    async def test_invalid_json_returns_error(self, ws):
        mock_ws = AsyncMock()
        await ws._handle_message("not json{{{", mock_ws)

        sent = json.loads(mock_ws.send.call_args[0][0])
        assert sent["action"] == "error"
        assert "Invalid JSON" in sent["message"]


class TestHandleMessageStopAudit:

    @pytest.mark.asyncio
    async def test_stop_without_workflow_id_returns_error(self, ws):
        mock_ws = AsyncMock()
        await ws._handle_message(json.dumps({"action": "stop_audit"}), mock_ws)

        sent = json.loads(mock_ws.send.call_args[0][0])
        assert sent["action"] == "error"
        assert "workflow_id is required" in sent["message"]

    @pytest.mark.asyncio
    async def test_stop_nonexistent_workflow(self, ws):
        mock_ws = AsyncMock()
        msg = json.dumps({"action": "stop_audit", "workflow_id": "nonexistent-id"})
        await ws._handle_message(msg, mock_ws)

        sent = json.loads(mock_ws.send.call_args[0][0])
        assert sent["action"] == "audit_stopped"
        assert sent["success"] is False
        assert "not found" in sent["message"].lower()

    @pytest.mark.asyncio
    async def test_stop_active_workflow(self, ws):
        manager = WorkflowStateManager()
        state, _ = manager.get_or_create(None, "security_audit")
        wf_id = state.continuation_id

        mock_ws = AsyncMock()
        msg = json.dumps({"action": "stop_audit", "workflow_id": wf_id})
        await ws._handle_message(msg, mock_ws)

        sent = json.loads(mock_ws.send.call_args[0][0])
        assert sent["action"] == "audit_stopped"
        assert sent["success"] is True
        assert sent["workflow_id"] == wf_id
        assert sent["audit_type"] == "security_audit"

    @pytest.mark.asyncio
    async def test_stop_already_cancelled_workflow(self, ws):
        manager = WorkflowStateManager()
        state, _ = manager.get_or_create(None, "security_audit")
        wf_id = state.continuation_id
        manager.cancel(wf_id)

        mock_ws = AsyncMock()
        msg = json.dumps({"action": "stop_audit", "workflow_id": wf_id})
        await ws._handle_message(msg, mock_ws)

        sent = json.loads(mock_ws.send.call_args[0][0])
        assert sent["action"] == "audit_stopped"
        assert sent["success"] is False
        assert "already cancelled" in sent["message"].lower()

    @pytest.mark.asyncio
    async def test_stop_finished_workflow(self, ws):
        manager = WorkflowStateManager()
        state, _ = manager.get_or_create(None, "a11y_audit")
        wf_id = state.continuation_id
        state.is_finished = True
        manager.save(state)

        mock_ws = AsyncMock()
        msg = json.dumps({"action": "stop_audit", "workflow_id": wf_id})
        await ws._handle_message(msg, mock_ws)

        sent = json.loads(mock_ws.send.call_args[0][0])
        assert sent["action"] == "audit_stopped"
        assert sent["success"] is False
        assert "already finished" in sent["message"].lower()

    @pytest.mark.asyncio
    async def test_stop_broadcasts_cancellation(self, ws):
        manager = WorkflowStateManager()
        state, _ = manager.get_or_create(None, "devops_audit")
        wf_id = state.continuation_id

        client_queue = asyncio.Queue()
        ws._clients.add(client_queue)

        mock_ws = AsyncMock()
        msg = json.dumps({"action": "stop_audit", "workflow_id": wf_id})
        await ws._handle_message(msg, mock_ws)

        broadcast_msg = json.loads(await asyncio.wait_for(client_queue.get(), timeout=1))
        assert broadcast_msg["action"] == "workflow_cancelled"
        assert broadcast_msg["workflow_id"] == wf_id
        assert broadcast_msg["audit_type"] == "devops_audit"
        assert "timestamp" in broadcast_msg


class TestBroadcast:

    @pytest.mark.asyncio
    async def test_broadcast_to_multiple_clients(self, ws):
        q1 = asyncio.Queue()
        q2 = asyncio.Queue()
        ws._clients.add(q1)
        ws._clients.add(q2)

        await ws.broadcast({"action": "test", "data": "hello"})

        msg1 = json.loads(await asyncio.wait_for(q1.get(), timeout=1))
        msg2 = json.loads(await asyncio.wait_for(q2.get(), timeout=1))
        assert msg1 == {"action": "test", "data": "hello"}
        assert msg2 == {"action": "test", "data": "hello"}

    @pytest.mark.asyncio
    async def test_broadcast_noop_with_no_clients(self, ws):
        await ws.broadcast({"action": "test"})

    @pytest.mark.asyncio
    async def test_broadcast_survives_bad_client(self, ws):
        good_q = asyncio.Queue()
        bad_q = MagicMock()
        bad_q.put = AsyncMock(side_effect=Exception("broken"))
        ws._clients.add(good_q)
        ws._clients.add(bad_q)

        await ws.broadcast({"action": "test"})

        msg = json.loads(await asyncio.wait_for(good_q.get(), timeout=1))
        assert msg["action"] == "test"


class TestWebSocketLifecycle:

    def test_stop_clears_state(self, ws):
        ws._clients.add(asyncio.Queue())
        ws._clients.add(asyncio.Queue())
        assert ws.client_count == 2

        ws.stop()

        assert ws.client_count == 0
        assert ws._server is None
        assert ws._loop is None
        assert ws._thread is None

    def test_stop_is_idempotent(self, ws):
        ws.stop()
        ws.stop()

    def test_client_count(self, ws):
        assert ws.client_count == 0
        ws._clients.add(asyncio.Queue())
        assert ws.client_count == 1
        ws._clients.add(asyncio.Queue())
        assert ws.client_count == 2


class TestWebSocketInfoEndpoint:

    def test_websocket_info_returns_correct_structure(self):
        import tools.dashboard.server as mod
        mod._actual_port = 24282
        mod._websocket_port = 24283

        try:
            from tools.dashboard.server import get_websocket_port, get_actual_port
            ws_port = get_websocket_port()
            http_port = get_actual_port()

            info = {
                "websocket_port": ws_port,
                "websocket_url": f"ws://127.0.0.1:{ws_port}" if ws_port else None,
                "http_port": http_port,
                "websocket_available": ws_port is not None,
            }

            assert info["websocket_port"] == 24283
            assert info["websocket_url"] == "ws://127.0.0.1:24283"
            assert info["http_port"] == 24282
            assert info["websocket_available"] is True
        finally:
            mod._actual_port = None
            mod._websocket_port = None

    def test_websocket_info_when_unavailable(self):
        import tools.dashboard.server as mod
        mod._actual_port = 24282
        mod._websocket_port = None

        try:
            from tools.dashboard.server import get_websocket_port, get_actual_port
            ws_port = get_websocket_port()
            http_port = get_actual_port()

            info = {
                "websocket_port": ws_port,
                "websocket_url": f"ws://127.0.0.1:{ws_port}" if ws_port else None,
                "http_port": http_port,
                "websocket_available": ws_port is not None,
            }

            assert info["websocket_url"] is None
            assert info["websocket_available"] is False
        finally:
            mod._actual_port = None
            mod._websocket_port = None

    def test_ws_port_is_http_port_plus_one(self, tmp_path):
        """Verify that start_dashboard_server calls _start_websocket_server with port+1."""
        from config.defaults import DashboardConfig
        import tools.dashboard.server as mod

        config = DashboardConfig(enabled=True, host="127.0.0.1", port=49152)

        captured = {}

        def capture_ws(host, port):
            captured["host"] = host
            captured["port"] = port

        orig = (mod._server_instance, mod._server_thread, mod._actual_port, mod._websocket_port)
        mod._server_instance = None
        mod._server_thread = None
        mod._actual_port = None
        mod._websocket_port = None

        try:
            with (
                patch("tools.dashboard.server.Path.cwd", return_value=tmp_path),
                patch("tools.dashboard.server._start_websocket_server", side_effect=capture_ws),
            ):
                thread = start_dashboard_server(config)

            assert thread is not None
            actual = get_actual_port()
            assert captured["port"] == actual + 1
            assert captured["host"] == "127.0.0.1"
        finally:
            if mod._server_instance is not None:
                mod._server_instance.shutdown()
            mod._server_instance, mod._server_thread, mod._actual_port, mod._websocket_port = orig


# Need these imports at module level for the last test class
from tools.dashboard.server import start_dashboard_server, get_actual_port
