import json
import os
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import pytest

from tools.team_analytics_audit.tool import TeamAnalyticsAuditTool

pytestmark = pytest.mark.integration


def _git(args: list[str], cwd: str) -> None:
    subprocess.run(
        ["git"] + args,
        cwd=cwd,
        capture_output=True,
        check=True,
    )


def _create_test_repo(tmpdir: str) -> str:
    _git(["init"], tmpdir)
    _git(["config", "user.name", "Alice"], tmpdir)
    _git(["config", "user.email", "alice@example.com"], tmpdir)

    for i in range(3):
        file_path = Path(tmpdir) / f"src/file_{i}.py"
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(f"# file {i}\n" * 10)
        _git(["add", "."], tmpdir)
        _git(
            [
                "commit",
                f"--date=2026-01-{15 + i}T10:00:00+00:00",
                "-m",
                f"feat: add file {i}",
            ],
            tmpdir,
        )

    env = os.environ.copy()
    env["GIT_AUTHOR_NAME"] = "Bob"
    env["GIT_AUTHOR_EMAIL"] = "bob@example.com"
    env["GIT_COMMITTER_NAME"] = "Bob"
    env["GIT_COMMITTER_EMAIL"] = "bob@example.com"

    for i in range(2):
        file_path = Path(tmpdir) / f"tests/test_{i}.py"
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(f"# test {i}\n" * 5)
        subprocess.run(
            ["git", "add", "."],
            cwd=tmpdir,
            capture_output=True,
            check=True,
            env=env,
        )
        subprocess.run(
            [
                "git",
                "commit",
                f"--date=2026-01-{17 + i}T14:00:00+00:00",
                "-m",
                f"test: add test {i}",
            ],
            cwd=tmpdir,
            capture_output=True,
            check=True,
            env=env,
        )

    return tmpdir


class TestTeamAnalyticsAuditIntegration:
    @pytest.fixture
    def repo(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            yield _create_test_repo(tmpdir)

    def test_full_audit_returns_response(self, repo):
        tool = TeamAnalyticsAuditTool()
        response = tool.execute(
            period="last_30_days",
            project_root_path=repo,
        )
        assert response is not None
        assert response.report_content != ""

    def test_full_audit_report_path(self, repo):
        tool = TeamAnalyticsAuditTool()
        response = tool.execute(
            period="last_30_days",
            project_root_path=repo,
        )
        assert response.report_path.endswith("TEAM_AUDIT_REPORT.md")
        assert repo in response.report_path

    def test_full_audit_consolidated_summary(self, repo):
        tool = TeamAnalyticsAuditTool()
        response = tool.execute(
            period="last_30_days",
            project_root_path=repo,
        )
        summary = response.consolidated_summary
        assert summary["total_commits"] == 5
        assert summary["active_contributors"] == 2
        assert summary["health_status"] in (
            "Healthy", "Needs Attention", "At Risk"
        )
        assert summary["trajectory"] in (
            "accelerating", "stable", "decelerating"
        )

    def test_full_audit_steps_executed(self, repo):
        tool = TeamAnalyticsAuditTool()
        response = tool.execute(
            period="last_30_days",
            project_root_path=repo,
        )
        assert len(response.steps_executed) == 7
        step_names = [s.name for s in response.steps_executed]
        assert "Collect" in step_names
        assert "Report" in step_names

    def test_author_filter(self, repo):
        tool = TeamAnalyticsAuditTool()
        response = tool.execute(
            period="last_30_days",
            author="Alice",
            project_root_path=repo,
        )
        summary = response.consolidated_summary
        assert summary["total_commits"] == 3
        assert "Alice" in response.report_content

    def test_team_members_filter(self, repo):
        tool = TeamAnalyticsAuditTool()
        response = tool.execute(
            period="last_30_days",
            team_members=["Bob"],
            project_root_path=repo,
        )
        summary = response.consolidated_summary
        assert summary["total_commits"] == 2

    def test_date_range_period(self, repo):
        tool = TeamAnalyticsAuditTool()
        from datetime import date, timedelta
        today = date.today()
        start = (today - timedelta(days=7)).strftime("%Y-%m-%d")
        end = today.strftime("%Y-%m-%d")
        response = tool.execute(
            period=f"{start}..{end}",
            project_root_path=repo,
        )
        assert response.consolidated_summary["total_commits"] >= 1

    def test_author_not_found_raises(self, repo):
        tool = TeamAnalyticsAuditTool()
        with pytest.raises(ValueError, match="author_not_found"):
            tool.execute(
                period="last_30_days",
                author="NonExistentUser",
                project_root_path=repo,
            )

    def test_no_git_repo_raises(self):
        tool = TeamAnalyticsAuditTool()
        with tempfile.TemporaryDirectory() as tmpdir:
            with pytest.raises(ValueError, match="no_git_repo"):
                tool.execute(project_root_path=tmpdir)

    def test_invalid_period_raises(self, repo):
        tool = TeamAnalyticsAuditTool()
        with pytest.raises(ValueError, match="invalid_period"):
            tool.execute(
                period="last_sprint",
                project_root_path=repo,
            )

    def test_file_write_instructions(self, repo):
        tool = TeamAnalyticsAuditTool()
        response = tool.execute(
            period="last_30_days",
            project_root_path=repo,
        )
        instructions = response.file_write_instructions
        assert instructions.target_path.endswith("TEAM_AUDIT_REPORT.md")
        assert instructions.overwrite_strategy == "overwrite"
        assert instructions.create_directory is True
        assert len(instructions.content) > 0

    def test_to_dict_is_json_serializable(self, repo):
        tool = TeamAnalyticsAuditTool()
        response = tool.execute(
            period="last_30_days",
            project_root_path=repo,
        )
        result = response.to_dict()
        serialized = json.dumps(result)
        assert len(serialized) > 0
