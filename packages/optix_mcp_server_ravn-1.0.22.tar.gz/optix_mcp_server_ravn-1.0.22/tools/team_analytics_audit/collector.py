from __future__ import annotations

import subprocess
from datetime import datetime, timezone
from pathlib import Path

from tools.team_analytics_audit.models import (
    FileChange,
    RawCommit,
)

GIT_TIMEOUT = 60
PRIMARY_FORMAT = "COMMIT|%H|%an|%ae|%aI|%s|%P"
BODY_FORMAT = "COMMIT|%H|%an|%ae|%b"
CO_AUTHOR_PREFIX = "co-authored-by:"


def _run_git(args: list[str], root: str) -> subprocess.CompletedProcess:
    result = subprocess.run(
        ["git", "-C", root] + args,
        capture_output=True,
        text=True,
        timeout=GIT_TIMEOUT,
    )
    return result


def _parse_file_changes(numstat_lines: list[str]) -> list[FileChange]:
    changes = []
    for line in numstat_lines:
        parts = line.split("\t")
        if len(parts) != 3:
            continue
        additions_str, deletions_str, file_path = parts
        is_binary = additions_str == "-"
        changes.append(
            FileChange(
                file_path=file_path,
                additions=0 if is_binary else int(additions_str),
                deletions=0 if is_binary else int(deletions_str),
                is_binary=is_binary,
            )
        )
    return changes


def _parse_primary_output(output: str) -> list[RawCommit]:
    commits = []
    current_header: list[str] | None = None
    current_files: list[str] = []

    for line in output.splitlines():
        if line.startswith("COMMIT|"):
            if current_header is not None:
                commits.append(
                    _build_commit(current_header, current_files)
                )
            parts = line.split("|", 6)
            current_header = parts
            current_files = []
        elif line.strip() and current_header is not None:
            current_files.append(line)

    if current_header is not None:
        commits.append(_build_commit(current_header, current_files))

    return commits


def _build_commit(
    parts: list[str], numstat_lines: list[str]
) -> RawCommit:
    hash_ = parts[1]
    author_name = parts[2]
    author_email = parts[3]
    timestamp_str = parts[4]
    subject = parts[5]
    parent_hashes = parts[6].split() if len(parts) > 6 and parts[6] else []

    timestamp = datetime.fromisoformat(timestamp_str)
    if timestamp.tzinfo is None:
        timestamp = timestamp.replace(tzinfo=timezone.utc)

    files_changed = _parse_file_changes(numstat_lines)
    is_merge = len(parent_hashes) > 1

    return RawCommit(
        hash=hash_,
        author_name=author_name,
        author_email=author_email,
        timestamp=timestamp,
        subject=subject,
        parent_hashes=parent_hashes,
        files_changed=files_changed,
        is_merge=is_merge,
    )


def _extract_co_authors(body_output: str) -> dict[str, list[str]]:
    co_authors_by_hash: dict[str, list[str]] = {}
    current_hash: str | None = None

    for line in body_output.splitlines():
        if line.startswith("COMMIT|"):
            parts = line.split("|", 4)
            current_hash = parts[1]
            co_authors_by_hash[current_hash] = []
        elif (
            current_hash is not None
            and line.lower().startswith(CO_AUTHOR_PREFIX)
        ):
            co_author = line[len(CO_AUTHOR_PREFIX):].strip()
            co_authors_by_hash[current_hash].append(co_author)

    return co_authors_by_hash


class GitDataCollector:
    def collect(
        self,
        root: str,
        since: datetime,
        until: datetime,
        author: str | None = None,
        team_members: list[str] | None = None,
    ) -> list[RawCommit]:
        self._verify_git_repo(root)

        since_str = since.strftime("%Y-%m-%dT%H:%M:%S")
        until_str = until.strftime("%Y-%m-%dT%H:%M:%S")

        primary_args = [
            "log",
            f"--format={PRIMARY_FORMAT}",
            "--numstat",
            f"--since={since_str}",
            f"--until={until_str}",
        ]
        result = _run_git(primary_args, root)
        if result.returncode != 0:
            raise RuntimeError(
                f"Git command failed: {result.stderr.strip()}"
            )

        commits = _parse_primary_output(result.stdout)

        body_args = [
            "log",
            f"--format={BODY_FORMAT}",
            f"--since={since_str}",
            f"--until={until_str}",
        ]
        body_result = _run_git(body_args, root)
        if body_result.returncode == 0:
            co_authors_map = _extract_co_authors(body_result.stdout)
            for commit in commits:
                commit.co_authors = co_authors_map.get(commit.hash, [])

        commits = self._apply_team_filter(commits, team_members)
        commits = self._apply_author_filter(commits, author)

        return commits

    def _verify_git_repo(self, root: str) -> None:
        result = _run_git(["rev-parse", "--git-dir"], root)
        if result.returncode != 0:
            raise ValueError("no_git_repo")

    def _apply_author_filter(
        self, commits: list[RawCommit], author: str | None
    ) -> list[RawCommit]:
        if not author:
            return commits
        author_lower = author.lower()
        filtered = [
            c for c in commits
            if author_lower in c.author_name.lower()
            or author_lower in c.author_email.lower()
        ]
        if not filtered:
            raise ValueError("author_not_found")
        return filtered

    def _apply_team_filter(
        self,
        commits: list[RawCommit],
        team_members: list[str] | None,
    ) -> list[RawCommit]:
        if not team_members:
            return commits
        members_lower = [m.lower() for m in team_members]
        return [
            c for c in commits
            if any(
                m in c.author_name.lower() or m in c.author_email.lower()
                for m in members_lower
            )
        ]
