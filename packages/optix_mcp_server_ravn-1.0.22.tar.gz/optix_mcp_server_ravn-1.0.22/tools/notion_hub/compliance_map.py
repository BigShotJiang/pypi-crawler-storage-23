"""CWE to Compliance framework mapping."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

CWE_COMPLIANCE_MAP: dict[str, dict[str, list[str]]] = {
    "CWE-89": {
        "SOC2": ["CC6.1", "CC6.6"],
        "PCI-DSS": ["6.5.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A03:2021"],
    },
    "CWE-79": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.7"],
        "HIPAA": ["164.312(e)(1)"],
        "OWASP": ["A03:2021"],
    },
    "CWE-78": {
        "SOC2": ["CC6.1", "CC6.6"],
        "PCI-DSS": ["6.5.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A03:2021"],
    },
    "CWE-77": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A03:2021"],
    },
    "CWE-94": {
        "SOC2": ["CC6.1", "CC6.6"],
        "PCI-DSS": ["6.5.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A03:2021"],
    },
    "CWE-287": {
        "SOC2": ["CC6.1", "CC6.2"],
        "PCI-DSS": ["8.1", "8.2"],
        "HIPAA": ["164.312(d)"],
        "OWASP": ["A07:2021"],
    },
    "CWE-306": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["8.1"],
        "HIPAA": ["164.312(d)"],
        "OWASP": ["A07:2021"],
    },
    "CWE-798": {
        "SOC2": ["CC6.1", "CC6.7"],
        "PCI-DSS": ["2.1", "6.5.3"],
        "HIPAA": ["164.312(d)"],
        "OWASP": ["A07:2021"],
    },
    "CWE-862": {
        "SOC2": ["CC6.1", "CC6.3"],
        "PCI-DSS": ["7.1", "7.2"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A01:2021"],
    },
    "CWE-863": {
        "SOC2": ["CC6.1", "CC6.3"],
        "PCI-DSS": ["7.1", "7.2"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A01:2021"],
    },
    "CWE-639": {
        "SOC2": ["CC6.3"],
        "PCI-DSS": ["7.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A01:2021"],
    },
    "CWE-327": {
        "SOC2": ["CC6.1", "CC6.7"],
        "PCI-DSS": ["3.4", "4.1"],
        "HIPAA": ["164.312(e)(2)"],
        "OWASP": ["A02:2021"],
    },
    "CWE-328": {
        "SOC2": ["CC6.7"],
        "PCI-DSS": ["3.4"],
        "HIPAA": ["164.312(e)(2)"],
        "OWASP": ["A02:2021"],
    },
    "CWE-330": {
        "SOC2": ["CC6.7"],
        "PCI-DSS": ["3.5"],
        "HIPAA": ["164.312(e)(2)"],
        "OWASP": ["A02:2021"],
    },
    "CWE-22": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.8"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A01:2021"],
    },
    "CWE-73": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.8"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A01:2021"],
    },
    "CWE-434": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.8"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A04:2021"],
    },
    "CWE-119": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.2"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A06:2021"],
    },
    "CWE-120": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.2"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A06:2021"],
    },
    "CWE-125": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.2"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A06:2021"],
    },
    "CWE-352": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.9"],
        "HIPAA": ["164.312(e)(1)"],
        "OWASP": ["A01:2021"],
    },
    "CWE-918": {
        "SOC2": ["CC6.1", "CC6.6"],
        "PCI-DSS": ["6.5.10"],
        "HIPAA": ["164.312(e)(1)"],
        "OWASP": ["A10:2021"],
    },
    "CWE-611": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A05:2021"],
    },
    "CWE-502": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A08:2021"],
    },
    "CWE-200": {
        "SOC2": ["CC6.1", "CC6.5"],
        "PCI-DSS": ["6.5.6"],
        "HIPAA": ["164.312(e)(1)"],
        "OWASP": ["A01:2021"],
    },
    "CWE-209": {
        "SOC2": ["CC6.5"],
        "PCI-DSS": ["6.5.6"],
        "HIPAA": ["164.312(e)(1)"],
        "OWASP": ["A01:2021"],
    },
    "CWE-532": {
        "SOC2": ["CC6.5"],
        "PCI-DSS": ["3.2"],
        "HIPAA": ["164.312(b)"],
        "OWASP": ["A09:2021"],
    },
    "CWE-312": {
        "SOC2": ["CC6.7"],
        "PCI-DSS": ["3.4", "4.1"],
        "HIPAA": ["164.312(e)(2)"],
        "OWASP": ["A02:2021"],
    },
    "CWE-319": {
        "SOC2": ["CC6.7"],
        "PCI-DSS": ["4.1"],
        "HIPAA": ["164.312(e)(1)"],
        "OWASP": ["A02:2021"],
    },
    "CWE-384": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.10"],
        "HIPAA": ["164.312(d)"],
        "OWASP": ["A07:2021"],
    },
    "CWE-614": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.10"],
        "HIPAA": ["164.312(d)"],
        "OWASP": ["A07:2021"],
    },
    "CWE-601": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.10"],
        "HIPAA": ["164.312(e)(1)"],
        "OWASP": ["A01:2021"],
    },
    "CWE-1236": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A03:2021"],
    },
    "CWE-20": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A03:2021"],
    },
    "CWE-116": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A03:2021"],
    },
    "CWE-838": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A03:2021"],
    },
    "CWE-269": {
        "SOC2": ["CC6.1", "CC6.3"],
        "PCI-DSS": ["7.1", "7.2"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A04:2021"],
    },
    "CWE-250": {
        "SOC2": ["CC6.3"],
        "PCI-DSS": ["7.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A04:2021"],
    },
    "CWE-732": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["7.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A04:2021"],
    },
    "CWE-276": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["7.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A04:2021"],
    },
    "CWE-426": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A08:2021"],
    },
    "CWE-427": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.1"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A08:2021"],
    },
    "CWE-1104": {
        "SOC2": ["CC6.6"],
        "PCI-DSS": ["6.2"],
        "HIPAA": ["164.308(a)(5)"],
        "OWASP": ["A06:2021"],
    },
    "CWE-937": {
        "SOC2": ["CC6.6"],
        "PCI-DSS": ["6.2"],
        "HIPAA": ["164.308(a)(5)"],
        "OWASP": ["A06:2021"],
    },
    "CWE-1035": {
        "SOC2": ["CC6.6"],
        "PCI-DSS": ["6.2"],
        "HIPAA": ["164.308(a)(5)"],
        "OWASP": ["A06:2021"],
    },
    "CWE-16": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["2.2"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A05:2021"],
    },
    "CWE-1188": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["2.2"],
        "HIPAA": ["164.312(a)(1)"],
        "OWASP": ["A05:2021"],
    },
    "CWE-1021": {
        "SOC2": ["CC6.1"],
        "PCI-DSS": ["6.5.1"],
        "HIPAA": ["164.312(e)(1)"],
        "OWASP": ["A05:2021"],
    },
}

CATEGORY_TO_CWE: dict[str, list[str]] = {
    "SQL Injection": ["CWE-89"],
    "Injection": ["CWE-89", "CWE-78", "CWE-77", "CWE-94"],
    "XSS": ["CWE-79"],
    "Cross-Site Scripting": ["CWE-79"],
    "Authentication": ["CWE-287", "CWE-306", "CWE-798"],
    "Authorization": ["CWE-862", "CWE-863", "CWE-639"],
    "Broken Access Control": ["CWE-862", "CWE-863", "CWE-639"],
    "Cryptography": ["CWE-327", "CWE-328", "CWE-330"],
    "Cryptographic Failures": ["CWE-327", "CWE-328", "CWE-330", "CWE-312", "CWE-319"],
    "Path Traversal": ["CWE-22", "CWE-73"],
    "File Upload": ["CWE-434"],
    "Buffer Overflow": ["CWE-119", "CWE-120", "CWE-125"],
    "Memory Safety": ["CWE-119", "CWE-120", "CWE-125"],
    "CSRF": ["CWE-352"],
    "SSRF": ["CWE-918"],
    "XXE": ["CWE-611"],
    "Deserialization": ["CWE-502"],
    "Information Disclosure": ["CWE-200", "CWE-209", "CWE-532"],
    "Sensitive Data Exposure": ["CWE-200", "CWE-312", "CWE-319"],
    "Session Management": ["CWE-384", "CWE-614"],
    "Open Redirect": ["CWE-601"],
    "Input Validation": ["CWE-20", "CWE-116"],
    "Privilege Escalation": ["CWE-269", "CWE-250"],
    "Insecure Permissions": ["CWE-732", "CWE-276"],
    "Dependency Vulnerability": ["CWE-1104", "CWE-937", "CWE-1035"],
    "Configuration": ["CWE-16", "CWE-1188"],
    "Security Misconfiguration": ["CWE-16", "CWE-1188", "CWE-1021"],
    "Hardcoded Credentials": ["CWE-798"],
    "Hardcoded Secrets": ["CWE-798"],
}

FRAMEWORKS = ["SOC2", "PCI-DSS", "HIPAA", "OWASP"]


@dataclass
class ComplianceControl:
    """Represents a compliance framework control."""

    control_id: str
    framework: str
    description: str
    status: str = "Not Reviewed"
    related_cwes: list[str] | None = None

    @classmethod
    def from_cwe(cls, cwe_id: str, framework: str, control_id: str) -> ComplianceControl:
        """Create control from CWE mapping."""
        descriptions = {
            "CC6.1": "Logical and Physical Access Security",
            "CC6.2": "Access Authentication and Authorization",
            "CC6.3": "Access Control Policies",
            "CC6.5": "Confidentiality Commitments",
            "CC6.6": "System Operations Security",
            "CC6.7": "Encryption and Key Management",
            "6.5.1": "Injection Flaws Prevention",
            "6.5.2": "Buffer Overflow Prevention",
            "6.5.3": "Insecure Cryptographic Storage",
            "6.5.6": "Information Leakage Prevention",
            "6.5.7": "Cross-Site Scripting Prevention",
            "6.5.8": "Improper Access Control",
            "6.5.9": "Cross-Site Request Forgery Prevention",
            "6.5.10": "Broken Authentication Prevention",
            "164.312(a)(1)": "Access Control",
            "164.312(b)": "Audit Controls",
            "164.312(d)": "Person or Entity Authentication",
            "164.312(e)(1)": "Transmission Security",
            "164.312(e)(2)": "Encryption",
            "164.308(a)(5)": "Security Awareness Training",
            "A01:2021": "Broken Access Control",
            "A02:2021": "Cryptographic Failures",
            "A03:2021": "Injection",
            "A04:2021": "Insecure Design",
            "A05:2021": "Security Misconfiguration",
            "A06:2021": "Vulnerable Components",
            "A07:2021": "Auth Failures",
            "A08:2021": "Software Integrity Failures",
            "A09:2021": "Security Logging Failures",
            "A10:2021": "Server-Side Request Forgery",
        }

        return cls(
            control_id=control_id,
            framework=framework,
            description=descriptions.get(control_id, f"{framework} Control {control_id}"),
            related_cwes=[cwe_id],
        )

    def calculate_status(
        self,
        findings: list[dict[str, Any]],
    ) -> str:
        """Calculate status based on related findings severity."""
        if not findings:
            return "Passing"

        severities = [f.get("severity", "info").lower() for f in findings]

        if "critical" in severities or "high" in severities:
            return "Failing"
        elif "medium" in severities or "low" in severities:
            return "At Risk"
        else:
            return "Passing"


def get_compliance_controls_for_cwe(cwe_id: str) -> list[ComplianceControl]:
    """Get all compliance controls mapped to a CWE."""
    controls = []

    normalized_cwe = cwe_id.upper()
    if not normalized_cwe.startswith("CWE-"):
        normalized_cwe = f"CWE-{normalized_cwe}"

    mapping = CWE_COMPLIANCE_MAP.get(normalized_cwe, {})

    for framework, control_ids in mapping.items():
        for control_id in control_ids:
            controls.append(
                ComplianceControl.from_cwe(normalized_cwe, framework, control_id)
            )

    return controls


def get_cwes_for_category(category: str) -> list[str]:
    """Get CWE IDs associated with a vulnerability category."""
    normalized = category.strip()

    if normalized in CATEGORY_TO_CWE:
        return CATEGORY_TO_CWE[normalized]

    lower = normalized.lower()
    for cat, cwes in CATEGORY_TO_CWE.items():
        if cat.lower() == lower:
            return cwes

    for cat, cwes in CATEGORY_TO_CWE.items():
        if lower in cat.lower() or cat.lower() in lower:
            return cwes

    return []


def get_all_controls_for_findings(
    findings: list[dict[str, Any]],
) -> dict[str, ComplianceControl]:
    """Get all compliance controls affected by a list of findings."""
    controls: dict[str, ComplianceControl] = {}

    for finding in findings:
        cwe_id = finding.get("cwe_id", finding.get("cwe", ""))
        category = finding.get("category", "")

        cwes_to_check = []
        if cwe_id:
            cwes_to_check.append(cwe_id)
        if category:
            cwes_to_check.extend(get_cwes_for_category(category))

        for cwe in cwes_to_check:
            for control in get_compliance_controls_for_cwe(cwe):
                key = f"{control.framework}:{control.control_id}"
                if key not in controls:
                    controls[key] = control
                    controls[key].related_cwes = []
                if cwe not in (controls[key].related_cwes or []):
                    controls[key].related_cwes = (controls[key].related_cwes or []) + [cwe]

    return controls
