"""Sync status tracking for Notion hub operations."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

SYNC_STATUS_DIR = ".optix/notion_sync"


@dataclass
class SyncStatus:
    """Tracks sync state for an audit."""

    audit_id: str
    notion_page_id: str | None = None
    notion_page_url: str | None = None
    sync_timestamp: datetime | None = None
    status: str = "pending"
    error: str | None = None
    steps_completed: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "audit_id": self.audit_id,
            "notion_page_id": self.notion_page_id,
            "notion_page_url": self.notion_page_url,
            "sync_timestamp": (
                self.sync_timestamp.isoformat() if self.sync_timestamp else None
            ),
            "status": self.status,
            "error": self.error,
            "steps_completed": self.steps_completed,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SyncStatus:
        """Create from dictionary."""
        timestamp = data.get("sync_timestamp")
        if timestamp and isinstance(timestamp, str):
            timestamp = datetime.fromisoformat(timestamp)

        return cls(
            audit_id=data["audit_id"],
            notion_page_id=data.get("notion_page_id"),
            notion_page_url=data.get("notion_page_url"),
            sync_timestamp=timestamp,
            status=data.get("status", "pending"),
            error=data.get("error"),
            steps_completed=data.get("steps_completed", []),
        )

    @classmethod
    def _get_status_path(cls, audit_id: str) -> Path:
        """Get path to status file for an audit."""
        return Path(SYNC_STATUS_DIR) / f"{audit_id}.json"

    @classmethod
    def load(cls, audit_id: str) -> SyncStatus | None:
        """Load sync status for an audit."""
        path = cls._get_status_path(audit_id)
        if not path.exists():
            return None

        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return cls.from_dict(data)
        except (json.JSONDecodeError, KeyError):
            return None

    def save(self) -> None:
        """Save sync status to file."""
        path = self._get_status_path(self.audit_id)
        path.parent.mkdir(parents=True, exist_ok=True)

        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)

    def mark_in_progress(self) -> None:
        """Mark sync as in progress."""
        self.status = "in_progress"
        self.sync_timestamp = datetime.now()
        self.error = None
        self.save()

    def mark_success(
        self,
        page_id: str | None = None,
        page_url: str | None = None,
    ) -> None:
        """Mark sync as successful."""
        self.status = "success"
        self.sync_timestamp = datetime.now()
        self.error = None
        if page_id:
            self.notion_page_id = page_id
        if page_url:
            self.notion_page_url = page_url
        self.save()

    def mark_failed(self, error: str) -> None:
        """Mark sync as failed."""
        self.status = "failed"
        self.sync_timestamp = datetime.now()
        self.error = error
        self.save()

    def add_completed_step(self, step: str) -> None:
        """Add a completed step."""
        if step not in self.steps_completed:
            self.steps_completed.append(step)
            self.save()

    @classmethod
    def list_all(cls) -> list[SyncStatus]:
        """List all sync statuses."""
        sync_dir = Path(SYNC_STATUS_DIR)
        if not sync_dir.exists():
            return []

        statuses = []
        for path in sync_dir.glob("*.json"):
            if path.name == "index.json":
                continue
            audit_id = path.stem
            status = cls.load(audit_id)
            if status:
                statuses.append(status)

        return sorted(
            statuses,
            key=lambda s: s.sync_timestamp or datetime.min,
            reverse=True,
        )

    @classmethod
    def get_or_create(cls, audit_id: str) -> SyncStatus:
        """Get existing status or create new one."""
        existing = cls.load(audit_id)
        if existing:
            return existing
        return cls(audit_id=audit_id)
