"""Severity enum for DevOps findings - reuses security_audit Severity."""

from tools.security_audit.severity import Severity

__all__ = ["Severity"]
