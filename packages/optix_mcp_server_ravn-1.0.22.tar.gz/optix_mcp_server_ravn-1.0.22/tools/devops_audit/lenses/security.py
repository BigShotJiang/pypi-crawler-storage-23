"""Security-First lens for DevOps audit."""

from tools.devops_audit.domains import DevOpsCategory, DevOpsLens
from tools.devops_audit.lenses.base import BaseLens, LensConfig, LensRule


class SecurityLens(BaseLens):
    """Security-First lens focusing on secrets, supply chain, CVEs, OWASP."""

    @property
    def lens_type(self) -> DevOpsLens:
        return DevOpsLens.SECURITY

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=DevOpsLens.SECURITY,
            display_name="Security-First",
            description="Focus on secrets, supply chain, CVEs, and OWASP patterns",
            docker_rules=[
                LensRule(
                    id="SEC-D001",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Hardcoded Secrets",
                    description="Detect hardcoded secrets in Dockerfile layers",
                    severity_default="critical",
                    check_guidance=[
                        "Search for ENV with passwords, tokens, API keys",
                        "Check COPY/ADD of .env, credentials, key files",
                        "Look for ARG with default secret values",
                    ],
                ),
                LensRule(
                    id="SEC-D002",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Root User Execution",
                    description="Container running as root user",
                    severity_default="high",
                    check_guidance=[
                        "Check for USER directive presence",
                        "Verify USER is not root or 0",
                        "Check if any RUN commands switch to root",
                    ],
                ),
                LensRule(
                    id="SEC-D003",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Unpinned Base Images",
                    description="Base images without version pinning",
                    severity_default="high",
                    check_guidance=[
                        "Check FROM statements for :latest or missing tags",
                        "Verify base image uses specific version tag or SHA",
                        "Look for mutable tags that can change unexpectedly",
                    ],
                ),
                LensRule(
                    id="SEC-D004",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Curl Pipe Bash Anti-Pattern",
                    description="Dangerous curl | bash patterns in RUN commands",
                    severity_default="critical",
                    check_guidance=[
                        "Search for curl | bash or wget | sh patterns",
                        "Check for piping downloaded scripts to shell",
                        "Identify unsigned/unverified script execution",
                    ],
                ),
            ],
            cicd_rules=[
                LensRule(
                    id="SEC-C001",
                    category=DevOpsCategory.CICD,
                    name="Exposed Secrets in Workflow",
                    description="Secrets exposed in logs or environment",
                    severity_default="critical",
                    check_guidance=[
                        "Check for echo/print of secret values",
                        "Look for secrets in run commands without masking",
                        "Verify secrets.* usage is protected",
                    ],
                ),
                LensRule(
                    id="SEC-C002",
                    category=DevOpsCategory.CICD,
                    name="Unpinned Actions",
                    description="Actions using @main/@master instead of SHA",
                    severity_default="high",
                    check_guidance=[
                        "Check actions using @main, @master, or @v1",
                        "Verify third-party actions use SHA pinning",
                        "Look for actions from unverified publishers",
                    ],
                ),
                LensRule(
                    id="SEC-C003",
                    category=DevOpsCategory.CICD,
                    name="pull_request_target Misuse",
                    description="Dangerous pull_request_target with checkout",
                    severity_default="critical",
                    check_guidance=[
                        "Check for pull_request_target event trigger",
                        "Verify no checkout of PR branch with secrets access",
                        "Look for workflow_run with insecure artifact handling",
                    ],
                ),
                LensRule(
                    id="SEC-C004",
                    category=DevOpsCategory.CICD,
                    name="Missing Permissions Block",
                    description="No explicit permissions defined",
                    severity_default="medium",
                    check_guidance=[
                        "Check for permissions block at workflow level",
                        "Verify permissions follow least-privilege principle",
                        "Look for write-all or overly permissive settings",
                    ],
                ),
            ],
            dependency_rules=[
                LensRule(
                    id="SEC-P001",
                    category=DevOpsCategory.DEPENDENCY,
                    name="Missing Lockfile",
                    description="No lockfile for reproducible builds",
                    severity_default="high",
                    check_guidance=[
                        "Check for package-lock.json or yarn.lock",
                        "Verify lockfile is committed to repo",
                        "Look for .gitignore excluding lockfiles",
                    ],
                ),
                LensRule(
                    id="SEC-P002",
                    category=DevOpsCategory.DEPENDENCY,
                    name="Wildcard Versions",
                    description="Wildcard or unbounded version ranges",
                    severity_default="high",
                    check_guidance=[
                        "Search for * or latest in version fields",
                        "Check for >= without upper bound",
                        "Look for unbounded caret ranges on 0.x packages",
                    ],
                ),
                LensRule(
                    id="SEC-P003",
                    category=DevOpsCategory.DEPENDENCY,
                    name="No Automated Updates",
                    description="No Dependabot or Renovate configured",
                    severity_default="medium",
                    check_guidance=[
                        "Check for .github/dependabot.yml",
                        "Look for renovate.json or renovate config",
                        "Verify automated security update configuration",
                    ],
                ),
                LensRule(
                    id="SEC-P004",
                    category=DevOpsCategory.DEPENDENCY,
                    name="Registry Token in Config",
                    description="Auth tokens in .npmrc or similar",
                    severity_default="critical",
                    check_guidance=[
                        "Search .npmrc for _authToken or _auth",
                        "Check for registry credentials in config files",
                        "Look for hardcoded tokens in package configs",
                    ],
                ),
            ],
        )
