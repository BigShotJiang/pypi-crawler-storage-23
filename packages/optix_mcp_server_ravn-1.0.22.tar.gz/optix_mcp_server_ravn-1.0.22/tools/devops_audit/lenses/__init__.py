"""DevOps Audit Lenses - Specialized audit focus variations.

Available lenses:
- security: Focus on secrets, supply chain, CVEs, OWASP
- performance: Focus on build times, caching, runner costs
- compliance: Focus on SOC2, PCI-DSS, audit trails
- multicloud: Focus on AWS/Azure/GCP patterns, IaC
- startup: Focus on quick wins, pragmatic defaults
- comprehensive: All checks (default)
"""

from typing import Optional, Union

from tools.devops_audit.domains import DevOpsLens
from tools.devops_audit.lenses.base import BaseLens, LensConfig, LensRule
from tools.devops_audit.lenses.compliance import ComplianceLens
from tools.devops_audit.lenses.comprehensive import ComprehensiveLens
from tools.devops_audit.lenses.multicloud import MultiCloudLens
from tools.devops_audit.lenses.performance import PerformanceLens
from tools.devops_audit.lenses.security import SecurityLens
from tools.devops_audit.lenses.startup import StartupLens

LENS_REGISTRY: dict[DevOpsLens, type[BaseLens]] = {
    DevOpsLens.SECURITY: SecurityLens,
    DevOpsLens.PERFORMANCE: PerformanceLens,
    DevOpsLens.COMPLIANCE: ComplianceLens,
    DevOpsLens.MULTICLOUD: MultiCloudLens,
    DevOpsLens.STARTUP: StartupLens,
    DevOpsLens.COMPREHENSIVE: ComprehensiveLens,
}


def get_lens(lens_type: Optional[Union[DevOpsLens, str]] = None) -> BaseLens:
    """Get a lens instance by type.

    Args:
        lens_type: Lens type enum, string, or None for default

    Returns:
        BaseLens instance for the specified type
    """
    if isinstance(lens_type, str):
        lens_type = DevOpsLens.from_string(lens_type)
    elif lens_type is None:
        lens_type = DevOpsLens.COMPREHENSIVE

    lens_class = LENS_REGISTRY.get(lens_type, ComprehensiveLens)
    return lens_class()


def get_lens_config(lens_type: Optional[Union[DevOpsLens, str]] = None) -> LensConfig:
    """Get the configuration for a lens.

    Args:
        lens_type: Lens type enum, string, or None for default

    Returns:
        LensConfig for the specified lens
    """
    return get_lens(lens_type).get_config()


def list_available_lenses() -> list[dict[str, str]]:
    """List all available lenses with descriptions.

    Returns:
        List of dicts with id, display_name, and description
    """
    return [
        {
            "id": lens.value,
            "display_name": lens.display_name,
            "description": lens.description,
        }
        for lens in DevOpsLens
    ]


__all__ = [
    "BaseLens",
    "LensConfig",
    "LensRule",
    "SecurityLens",
    "PerformanceLens",
    "ComplianceLens",
    "MultiCloudLens",
    "StartupLens",
    "ComprehensiveLens",
    "LENS_REGISTRY",
    "get_lens",
    "get_lens_config",
    "list_available_lenses",
]
