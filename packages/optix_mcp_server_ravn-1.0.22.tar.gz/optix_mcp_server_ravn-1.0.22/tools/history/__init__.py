"""History tracking module for audit persistence.

This module provides functionality to automatically persist audit results
to the .optix/history/ directory when audits complete, and read them back
for dashboard display.

Public Exports:
    HistoryManager: Manager class for saving audit snapshots to disk
    HistoryReader: Reader class for reading audit history from disk
"""

from tools.history.manager import HistoryManager
from tools.history.reader import HistoryReader

__all__ = ["HistoryManager", "HistoryReader"]
