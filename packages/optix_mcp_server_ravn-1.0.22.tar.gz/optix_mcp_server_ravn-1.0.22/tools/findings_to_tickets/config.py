import os
from dataclasses import dataclass


@dataclass
class LinearConfig:
    api_key: str

    @classmethod
    def from_env(cls) -> "LinearConfig | None":
        api_key = os.environ.get("OPTIX_LINEAR_API_KEY", "").strip()
        if not api_key:
            return None
        return cls(api_key=api_key)

    @classmethod
    def is_configured(cls) -> bool:
        return bool(os.environ.get("OPTIX_LINEAR_API_KEY", "").strip())


@dataclass
class JiraConfig:
    api_token: str
    user_email: str
    instance_url: str

    @classmethod
    def from_env(cls) -> "JiraConfig | None":
        api_token = os.environ.get("OPTIX_JIRA_API_TOKEN", "").strip()
        user_email = os.environ.get("OPTIX_JIRA_USER_EMAIL", "").strip()
        instance_url = os.environ.get("OPTIX_JIRA_INSTANCE_URL", "").strip()

        if not all([api_token, user_email, instance_url]):
            return None

        instance_url = instance_url.rstrip("/")

        if not instance_url.startswith("https://"):
            raise ValueError(
                "OPTIX_JIRA_INSTANCE_URL must use HTTPS protocol. "
                f"Got: {instance_url}"
            )

        return cls(
            api_token=api_token,
            user_email=user_email,
            instance_url=instance_url,
        )

    @classmethod
    def is_configured(cls) -> bool:
        return all([
            os.environ.get("OPTIX_JIRA_API_TOKEN", "").strip(),
            os.environ.get("OPTIX_JIRA_USER_EMAIL", "").strip(),
            os.environ.get("OPTIX_JIRA_INSTANCE_URL", "").strip(),
        ])


@dataclass
class NotionTicketConfig:
    api_key: str
    database_id: str

    @classmethod
    def from_env(cls) -> "NotionTicketConfig | None":
        api_key = os.environ.get("OPTIX_NOTION_API_KEY", "").strip()
        database_id = os.environ.get("OPTIX_NOTION_AUDIT_DB_ID", "").strip()

        if not all([api_key, database_id]):
            return None

        return cls(api_key=api_key, database_id=database_id)

    @classmethod
    def is_configured(cls) -> bool:
        return all([
            os.environ.get("OPTIX_NOTION_API_KEY", "").strip(),
            os.environ.get("OPTIX_NOTION_AUDIT_DB_ID", "").strip(),
        ])


def get_available_platforms() -> dict[str, bool]:
    return {
        "linear": LinearConfig.is_configured(),
        "jira": JiraConfig.is_configured(),
        "notion": NotionTicketConfig.is_configured(),
    }
