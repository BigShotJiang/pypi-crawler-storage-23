"""Base lens class and data structures for Security Audit lenses."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional

from tools.security_audit.domains import SecurityLens, SecurityStepDomain


@dataclass
class LensRule:
    """A single security audit rule within a lens.

    Attributes:
        id: Unique rule identifier (e.g., "SEC-B001")
        domain: Which security step domain this rule applies to
        name: Short name for the rule
        description: Detailed description of what this rule checks
        severity_default: Default severity level for findings
        check_guidance: List of specific checks to perform
    """

    id: str
    domain: SecurityStepDomain
    name: str
    description: str
    severity_default: str
    check_guidance: list[str] = field(default_factory=list)


@dataclass
class LensConfig:
    """Configuration for a security audit lens.

    Contains all rules organized by security step domain.
    """

    lens: SecurityLens
    display_name: str
    description: str
    reconnaissance_rules: list[LensRule] = field(default_factory=list)
    auth_rules: list[LensRule] = field(default_factory=list)
    input_rules: list[LensRule] = field(default_factory=list)
    owasp_rules: list[LensRule] = field(default_factory=list)
    dependency_rules: list[LensRule] = field(default_factory=list)
    compliance_rules: list[LensRule] = field(default_factory=list)

    def get_rules_for_domain(self, domain: SecurityStepDomain) -> list[LensRule]:
        """Get all rules applicable to a specific security domain.

        Args:
            domain: The security step domain

        Returns:
            List of rules for that domain
        """
        mapping = {
            SecurityStepDomain.RECONNAISSANCE: self.reconnaissance_rules,
            SecurityStepDomain.AUTH_AUTHZ: self.auth_rules,
            SecurityStepDomain.INPUT_VALIDATION: self.input_rules,
            SecurityStepDomain.OWASP_TOP_10: self.owasp_rules,
            SecurityStepDomain.DEPENDENCIES: self.dependency_rules,
            SecurityStepDomain.COMPLIANCE: self.compliance_rules,
        }
        return mapping.get(domain, [])

    def get_all_rules(self) -> list[LensRule]:
        """Get all rules across all domains.

        Returns:
            List of all rules in this lens configuration
        """
        return (
            self.reconnaissance_rules
            + self.auth_rules
            + self.input_rules
            + self.owasp_rules
            + self.dependency_rules
            + self.compliance_rules
        )

    def get_rule_ids(self) -> list[str]:
        """Get all rule IDs in this lens.

        Returns:
            List of rule ID strings
        """
        return [rule.id for rule in self.get_all_rules()]


class BaseLens(ABC):
    """Abstract base class for Security Audit lenses.

    Each lens provides a specialized perspective on security analysis.
    Subclasses must implement lens_type and get_config methods.
    """

    @property
    @abstractmethod
    def lens_type(self) -> SecurityLens:
        """Return the lens type enum value."""
        ...

    @abstractmethod
    def get_config(self) -> LensConfig:
        """Return the lens configuration with all rules."""
        ...

    def get_required_actions(self, domain: SecurityStepDomain) -> list[str]:
        """Get required actions for a specific domain based on lens rules.

        Args:
            domain: The security step domain

        Returns:
            List of required action strings
        """
        config = self.get_config()
        rules = config.get_rules_for_domain(domain)

        actions = []
        for rule in rules:
            actions.extend(rule.check_guidance)

        return actions if actions else [f"Perform {domain.display_name} analysis"]

    def get_rule_summary(self) -> dict[str, int]:
        """Get a summary of rules by domain.

        Returns:
            Dictionary mapping domain names to rule counts
        """
        config = self.get_config()
        return {
            "reconnaissance": len(config.reconnaissance_rules),
            "auth_authz": len(config.auth_rules),
            "input_validation": len(config.input_rules),
            "owasp_top_10": len(config.owasp_rules),
            "dependencies": len(config.dependency_rules),
            "compliance": len(config.compliance_rules),
            "total": len(config.get_all_rules()),
        }
