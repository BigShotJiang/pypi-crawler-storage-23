"""Security step domains and lens definitions for the 6-step audit workflow."""

from enum import Enum
from typing import Optional


class SecurityLens(str, Enum):
    """Available lenses for Security Audit.

    Each lens represents a specialized perspective for security analysis:
    - BACKEND: Senior Backend Engineer perspective
    - FRONTEND: Senior Frontend Engineer perspective
    - DEVSECOPS: DevSecOps Engineer perspective
    - COMPLIANCE: Compliance/Privacy Officer perspective
    - COMPREHENSIVE: Full team review (default)
    """

    BACKEND = "backend"
    FRONTEND = "frontend"
    DEVSECOPS = "devsecops"
    COMPLIANCE = "compliance"
    COMPREHENSIVE = "comprehensive"

    @classmethod
    def from_string(cls, value: Optional[str]) -> "SecurityLens":
        """Convert string to SecurityLens enum.

        Args:
            value: String lens name or None

        Returns:
            SecurityLens enum value, defaults to COMPREHENSIVE
        """
        if not value:
            return cls.COMPREHENSIVE
        normalized = value.lower().strip()
        for lens in cls:
            if lens.value == normalized:
                return lens
        return cls.COMPREHENSIVE

    @property
    def display_name(self) -> str:
        """Human-readable name for the lens."""
        names = {
            SecurityLens.BACKEND: "Backend Engineer",
            SecurityLens.FRONTEND: "Frontend Engineer",
            SecurityLens.DEVSECOPS: "DevSecOps",
            SecurityLens.COMPLIANCE: "Compliance",
            SecurityLens.COMPREHENSIVE: "Comprehensive",
        }
        return names.get(self, self.value.title())

    @property
    def description(self) -> str:
        """Description of what this lens focuses on."""
        descriptions = {
            SecurityLens.BACKEND: "Server-side security: SQL injection, auth flaws, API security, business logic",
            SecurityLens.FRONTEND: "Client-side security: XSS, CSRF, DOM security, client storage, JS bundles",
            SecurityLens.DEVSECOPS: "Pipeline security: secrets in code, dependencies, CI/CD, supply chain",
            SecurityLens.COMPLIANCE: "Regulatory: PII exposure, GDPR, HIPAA, PCI-DSS, data handling",
            SecurityLens.COMPREHENSIVE: "Full security review covering all perspectives",
        }
        return descriptions.get(self, "Security analysis")


class SecurityStepDomain(Enum):
    """Security domains for each audit step."""

    RECONNAISSANCE = "reconnaissance"
    AUTH_AUTHZ = "auth_authz"
    INPUT_VALIDATION = "input_validation"
    OWASP_TOP_10 = "owasp_top_10"
    DEPENDENCIES = "dependencies"
    COMPLIANCE = "compliance"

    @classmethod
    def for_step(cls, step_number: int) -> "SecurityStepDomain":
        """Get the security domain for a given step number.

        Args:
            step_number: Step number (1-6)

        Returns:
            SecurityStepDomain for that step

        Raises:
            ValueError: If step_number is not 1-6
        """
        step_map = {
            1: cls.RECONNAISSANCE,
            2: cls.AUTH_AUTHZ,
            3: cls.INPUT_VALIDATION,
            4: cls.OWASP_TOP_10,
            5: cls.DEPENDENCIES,
            6: cls.COMPLIANCE,
        }
        if step_number not in step_map:
            raise ValueError(f"Invalid step number: {step_number}. Must be 1-6.")
        return step_map[step_number]

    @property
    def display_name(self) -> str:
        """Human-readable name for the domain."""
        names = {
            SecurityStepDomain.RECONNAISSANCE: "Application Reconnaissance",
            SecurityStepDomain.AUTH_AUTHZ: "Authentication & Authorization",
            SecurityStepDomain.INPUT_VALIDATION: "Input Validation & Cryptography",
            SecurityStepDomain.OWASP_TOP_10: "OWASP Top 10 Review",
            SecurityStepDomain.DEPENDENCIES: "Dependencies & Configuration",
            SecurityStepDomain.COMPLIANCE: "Compliance & Remediation",
        }
        return names[self]
