"""Data models for the export_sarif tool."""

from dataclasses import dataclass
from pathlib import Path

from tools.generate_report.models import AuditLens


@dataclass
class SarifExportResponse:
    """Response from successful SARIF export."""

    success: bool
    sarif_file_path: Path
    findings_count: int
    lens: AuditLens
    message: str
    rules_count: int = 0

    def to_dict(self) -> dict:
        """Convert response to dictionary for MCP JSON response."""
        return {
            "success": self.success,
            "sarif_file_path": str(self.sarif_file_path),
            "findings_count": self.findings_count,
            "lens": self.lens.value,
            "message": self.message,
            "rules_count": self.rules_count,
        }


@dataclass
class SarifExportError:
    """Response from failed SARIF export."""

    success: bool = False
    error: str = ""
    error_type: str = "GeneralError"

    def to_dict(self) -> dict:
        """Convert error to dictionary for MCP JSON response."""
        return {
            "success": self.success,
            "error": self.error,
            "error_type": self.error_type,
        }
