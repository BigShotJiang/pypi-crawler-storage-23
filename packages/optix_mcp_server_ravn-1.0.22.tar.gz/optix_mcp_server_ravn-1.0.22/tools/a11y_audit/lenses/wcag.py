"""WCAG Compliance lens for Accessibility Audit.

Focuses on systematic WCAG 2.1/2.2 success criteria verification:
- Level A requirements
- Level AA requirements
- Specific criterion checking
"""

from tools.a11y_audit.domains import A11yLens, AccessibilityStepDomain
from tools.a11y_audit.lenses.base import BaseLens, LensConfig, LensRule


class WCAGLens(BaseLens):
    """WCAG Compliance Auditor perspective.

    Systematically verifies WCAG 2.1/2.2 success criteria,
    organized by principle and conformance level.
    """

    @property
    def lens_type(self) -> A11yLens:
        return A11yLens.WCAG

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=A11yLens.WCAG,
            display_name="WCAG Compliance",
            description="WCAG 2.1/2.2 success criteria verification",
            structure_rules=[
                LensRule(
                    id="WCAG-S001",
                    domain=AccessibilityStepDomain.STRUCTURE,
                    name="1.3.1 Info and Relationships",
                    description="Information structure conveyed programmatically",
                    wcag_criterion="1.3.1",
                    wcag_level="A",
                    severity_default="high",
                    check_guidance=[
                        "Verify headings use heading elements",
                        "Check lists use list markup",
                        "Verify tables have proper structure",
                        "Check form labels are associated",
                    ],
                ),
                LensRule(
                    id="WCAG-S002",
                    domain=AccessibilityStepDomain.STRUCTURE,
                    name="1.3.2 Meaningful Sequence",
                    description="Reading order is logical",
                    wcag_criterion="1.3.2",
                    wcag_level="A",
                    severity_default="high",
                    check_guidance=[
                        "Verify DOM order matches visual order",
                        "Check CSS doesn't create confusing order",
                    ],
                ),
            ],
            aria_rules=[
                LensRule(
                    id="WCAG-A001",
                    domain=AccessibilityStepDomain.ARIA_LABELS,
                    name="4.1.2 Name, Role, Value",
                    description="All UI components have accessible names",
                    wcag_criterion="4.1.2",
                    wcag_level="A",
                    severity_default="critical",
                    check_guidance=[
                        "Check all controls have accessible names",
                        "Verify roles are appropriate",
                        "Check states and values are exposed",
                    ],
                ),
                LensRule(
                    id="WCAG-A002",
                    domain=AccessibilityStepDomain.ARIA_LABELS,
                    name="4.1.3 Status Messages",
                    description="Status messages announced to assistive tech",
                    wcag_criterion="4.1.3",
                    wcag_level="AA",
                    severity_default="high",
                    check_guidance=[
                        "Check status messages use role='status'",
                        "Verify error messages are announced",
                        "Check loading states are communicated",
                    ],
                ),
            ],
            keyboard_rules=[
                LensRule(
                    id="WCAG-K001",
                    domain=AccessibilityStepDomain.KEYBOARD_NAV,
                    name="2.1.1 Keyboard",
                    description="All functionality keyboard accessible",
                    wcag_criterion="2.1.1",
                    wcag_level="A",
                    severity_default="critical",
                    check_guidance=[
                        "Verify all interactive elements focusable",
                        "Check all actions available via keyboard",
                        "Verify no mouse-only interactions",
                    ],
                ),
                LensRule(
                    id="WCAG-K002",
                    domain=AccessibilityStepDomain.KEYBOARD_NAV,
                    name="2.1.2 No Keyboard Trap",
                    description="Focus can always be moved away",
                    wcag_criterion="2.1.2",
                    wcag_level="A",
                    severity_default="critical",
                    check_guidance=[
                        "Check no component traps focus",
                        "Verify dialogs can be dismissed",
                    ],
                ),
                LensRule(
                    id="WCAG-K003",
                    domain=AccessibilityStepDomain.KEYBOARD_NAV,
                    name="2.4.1 Bypass Blocks",
                    description="Mechanism to skip repeated content",
                    wcag_criterion="2.4.1",
                    wcag_level="A",
                    severity_default="medium",
                    check_guidance=[
                        "Check for skip navigation links",
                        "Verify landmark regions present",
                    ],
                ),
            ],
            focus_rules=[
                LensRule(
                    id="WCAG-F001",
                    domain=AccessibilityStepDomain.FOCUS_MANAGEMENT,
                    name="2.4.3 Focus Order",
                    description="Focus order preserves meaning",
                    wcag_criterion="2.4.3",
                    wcag_level="A",
                    severity_default="high",
                    check_guidance=[
                        "Verify focus order is logical",
                        "Check focus returns after dialogs",
                    ],
                ),
                LensRule(
                    id="WCAG-F002",
                    domain=AccessibilityStepDomain.FOCUS_MANAGEMENT,
                    name="2.4.7 Focus Visible",
                    description="Focus indicator is visible",
                    wcag_criterion="2.4.7",
                    wcag_level="AA",
                    severity_default="critical",
                    check_guidance=[
                        "Check all elements have visible focus",
                        "Verify focus not hidden with CSS",
                    ],
                ),
            ],
            color_rules=[
                LensRule(
                    id="WCAG-C001",
                    domain=AccessibilityStepDomain.COLOR_CONTRAST,
                    name="1.4.1 Use of Color",
                    description="Color not sole means of conveying info",
                    wcag_criterion="1.4.1",
                    wcag_level="A",
                    severity_default="critical",
                    check_guidance=[
                        "Verify color-blind users can distinguish info",
                        "Check links have non-color identifier",
                    ],
                ),
                LensRule(
                    id="WCAG-C002",
                    domain=AccessibilityStepDomain.COLOR_CONTRAST,
                    name="1.4.3 Contrast (Minimum)",
                    description="Text has 4.5:1 contrast",
                    wcag_criterion="1.4.3",
                    wcag_level="AA",
                    severity_default="critical",
                    check_guidance=[
                        "Check normal text 4.5:1 ratio",
                        "Check large text 3:1 ratio",
                    ],
                ),
                LensRule(
                    id="WCAG-C003",
                    domain=AccessibilityStepDomain.COLOR_CONTRAST,
                    name="1.4.11 Non-text Contrast",
                    description="UI components have 3:1 contrast",
                    wcag_criterion="1.4.11",
                    wcag_level="AA",
                    severity_default="high",
                    check_guidance=[
                        "Check UI component boundaries visible",
                        "Verify graphical elements distinguishable",
                    ],
                ),
            ],
            semantic_rules=[
                LensRule(
                    id="WCAG-SM001",
                    domain=AccessibilityStepDomain.SEMANTIC_HTML,
                    name="1.1.1 Non-text Content",
                    description="All non-text content has alternatives",
                    wcag_criterion="1.1.1",
                    wcag_level="A",
                    severity_default="critical",
                    check_guidance=[
                        "Check images have alt text",
                        "Verify decorative images have null alt",
                        "Check complex images have descriptions",
                    ],
                ),
                LensRule(
                    id="WCAG-SM002",
                    domain=AccessibilityStepDomain.SEMANTIC_HTML,
                    name="2.4.6 Headings and Labels",
                    description="Headings and labels describe purpose",
                    wcag_criterion="2.4.6",
                    wcag_level="AA",
                    severity_default="medium",
                    check_guidance=[
                        "Verify headings describe content",
                        "Check form labels are descriptive",
                    ],
                ),
                LensRule(
                    id="WCAG-SM003",
                    domain=AccessibilityStepDomain.SEMANTIC_HTML,
                    name="3.1.1 Language of Page",
                    description="Page language is specified",
                    wcag_criterion="3.1.1",
                    wcag_level="A",
                    severity_default="medium",
                    check_guidance=[
                        "Check html lang attribute present",
                        "Verify lang value is valid",
                    ],
                ),
            ],
        )
