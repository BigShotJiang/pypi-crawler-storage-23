"""Accessibility audit tool for MCP server.

Provides a 6-step guided workflow for auditing frontend applications
for WCAG 2.1/2.2 compliance. Generates A11Y-AUDIT.MD reports with
findings organized by severity and WCAG criterion.

Supports specialized lens variations:
- screenreader: Screen Reader User perspective
- keyboard: Keyboard-Only User perspective
- visual: Visual Accessibility perspective
- wcag: WCAG Compliance Auditor perspective
- comprehensive: Full accessibility review (default)
"""

from tools.a11y_audit.domains import A11yLens, AccessibilityStepDomain
from tools.a11y_audit.finding import AccessibilityFinding
from tools.a11y_audit.lenses import (
    BaseLens,
    LensConfig,
    LensRule,
    get_lens,
    get_lens_config,
    list_available_lenses,
)
from tools.a11y_audit.report import A11yAuditReportGenerator
from tools.a11y_audit.severity import AccessibilitySeverity
from tools.a11y_audit.tool import AccessibilityAuditTool

__all__ = [
    "A11yLens",
    "AccessibilityAuditTool",
    "AccessibilityFinding",
    "AccessibilitySeverity",
    "AccessibilityStepDomain",
    "A11yAuditReportGenerator",
    "BaseLens",
    "LensConfig",
    "LensRule",
    "get_lens",
    "get_lens_config",
    "list_available_lenses",
]
