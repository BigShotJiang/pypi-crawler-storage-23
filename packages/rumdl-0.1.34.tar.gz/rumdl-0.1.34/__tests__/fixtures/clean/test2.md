# Another Test Document

This is a second clean markdown file for multi-path testing.

## Overview

Some content here.
