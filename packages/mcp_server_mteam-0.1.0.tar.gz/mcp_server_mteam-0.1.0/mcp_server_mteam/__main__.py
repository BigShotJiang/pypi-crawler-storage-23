"""Allow running as python -m mcp_server_mteam"""

from mcp_server_mteam.server import main

if __name__ == "__main__":
    main()
