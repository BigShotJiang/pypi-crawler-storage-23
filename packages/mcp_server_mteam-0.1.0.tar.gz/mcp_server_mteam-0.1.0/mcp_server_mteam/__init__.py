"""M-Team MCP Server - MCP tools for M-Team (馒头) private torrent tracker."""

from mcp_server_mteam.server import mcp

__all__ = ["mcp"]
