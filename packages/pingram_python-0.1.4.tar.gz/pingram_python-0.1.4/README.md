# Pingram Python SDK

Official Python SDK for Pingram. Send notifications via Email, SMS, Push, In-App, and more from your server-side Python code.

## Requirements

- Python 3.9+
- Dependencies: `httpx`, `pydantic`, `python-dateutil`, `typing-extensions` (installed automatically)

## Installation

```bash
pip install pingram-python
```

To install from source (e.g. from the [GitHub repo](https://github.com/notificationapi-com/serverless)):

```bash
pip install -e sdks/python
```

## Quick start

Use the **Pingram** client with your **API key**, then call `send()` or the namespaced APIs (`user`, `users`, `logs`, etc.).

```python
import asyncio
from pingram import Pingram, SenderPostBody, SenderPostBodyTo

async def main():
    # API key (e.g. pingram_sk_...) or JWT; optional region ("us" | "eu" | "ca")
    async with Pingram(api_key="pingram_sk_...") as client:
        # Send a notification
        body = SenderPostBody(
            notification_id="your_notification_id",
            to=SenderPostBodyTo(id="user_123"),
        )
        response = await client.send(sender_post_body=body)
        print(response)

        # Or use namespaced APIs (same as Node: client.user, client.users, client.logs, ...)
        # user = await client.user.user_get_user(account_id="...", user_id="...")
        # logs = await client.logs.logs_query_logs(...)

asyncio.run(main())
```

You can also pass a config dict: `Pingram({"api_key": "pingram_sk_...", "region": "eu"})`. For full API coverage, use `client.send`, `client.user`, `client.users`, `client.logs`, `client.templates`, `client.environments`, and the other APIs.

## Links

- [Documentation](https://www.pingram.io/docs/)
