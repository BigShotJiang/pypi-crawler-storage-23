from setuptools import setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='arcvexum',
    version='0.0.1',
    description='Namespace reservation for ARCVEXUM LLC',
    long_description=long_description,
    long_description_content_type="text/markdown",
)