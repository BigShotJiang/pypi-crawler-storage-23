from ._core import MarkdownToHtmlConverter, markdown, markdown_batch

Markdown = MarkdownToHtmlConverter

__all__ = [
    "MarkdownToHtmlConverter",
    "Markdown",
    "markdown",
    "markdown_batch",
]
