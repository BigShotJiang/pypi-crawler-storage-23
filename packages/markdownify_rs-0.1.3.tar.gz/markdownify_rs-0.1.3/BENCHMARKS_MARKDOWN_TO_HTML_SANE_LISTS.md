# Markdown-To-HTML Corpus Parity (Python-Markdown-Compatible Settings)

- Timestamp (UTC): 2026-02-22T06:07:30Z
- Corpus: `/tmp/test_markdowns`
- Files: 902
- Total bytes: 157,392,400
- Python-Markdown: `3.10.2`
- markdownify-rs: local `0.1.2`

## Settings Used

Python-Markdown:
- `extensions=['sane_lists']`

markdownify-rs:
- `extensions=['sane_lists']`
- `autolink=False`
- `tasklist=False`
- `strikethrough=False`
- `mode='python_compat'`

These settings intentionally exclude `legacy_em` and `md_in_html` from parity targeting.

## Parity Results

- Exact parity: `0/902` (`0.00%`)
- Normalized parity (whitespace + `<br>/<hr>` normalization): `433/902` (`48.00%`)
- Normalized + HTML entity unescape: `649/902` (`71.95%`)
- Normalized + unescape + attribute-insensitive tag compare: `684/902` (`75.83%`)
- Text-equivalent (tags differ, text stream same): `767/902` (`85.03%`)

Mismatch bucket counts (for non-normalized matches):
- `entity_only`: `216`
- `attr_only`: `35`
- `tag_shape_only`: `83`
- `structural_or_text`: `135`

## Speed Results

Best-of-2 full-corpus timing:
- Python-Markdown: `38.055308s`
- markdownify-rs (`markdown_batch`, `mode='python_compat'`): `4.441615s`
- Speedup (`python_compat`): `8.57x`
- markdownify-rs (`markdown_batch`, `mode='fast'`): `1.307566s`
- Speedup (`fast`): `29.10x`

Fast mode parity reference (same corpus/settings except `mode='fast'`):
- Normalized parity: `222/902`
- Normalized + unescape: `440/902`
- Normalized + unescape + attr-insensitive: `457/902`
- Text-equivalent: `517/902`
- Structural/text mismatches: `385`

## Interpretation

- `mode='python_compat'` preserves the current best-effort Python-Markdown compatibility behavior.
- `mode='fast'` restores a near-pure comrak path with significantly higher throughput.
- Entity and attribute differences still dominate remaining normalized mismatch counts.
- Remaining structural mismatches are concentrated in parser-level emphasis edge cases and malformed HTML handling on OCR-heavy documents.

## Optimization Rerun (Python-Compat Fast-Path Guards)

- Timestamp (UTC): 2026-02-22T07:04:00Z
- Corpus: `/tmp/test_markdowns`
- Files: 902
- Settings:
  - Python-Markdown: `extensions=['sane_lists']`
  - markdownify-rs: `extensions=['sane_lists']`, `autolink=False`, `tasklist=False`, `strikethrough=False`, `mode='python_compat'`

Parity snapshot (same corpus/settings, local normalizer used for this rerun):
- `mode='python_compat'`:
  - Normalized parity: `426/902`
  - Normalized + unescape: `625/902`
  - Attr-insensitive: `660/902`
  - Text-equivalent: `767/902`
  - Structural/text mismatches: `135`
- `mode='fast'` reference:
  - Normalized parity: `219/902`
  - Normalized + unescape: `428/902`
  - Attr-insensitive: `445/902`
  - Text-equivalent: `517/902`
  - Structural/text mismatches: `385`

Speed rerun (best-of-2 full corpus):
- Python-Markdown: `38.343619s`
- markdownify-rs (`mode='python_compat'`): `3.110057s`
- Speedup (`python_compat`): `12.33x` (up from `8.57x`)
- markdownify-rs (`mode='fast'`): `1.321666s`
- Speedup (`fast`): `29.01x` (previously `29.10x`)

Notes:
- This rerun used a local comparison script/normalizer; normalized buckets are not directly comparable to the earlier section’s exact normalizer.
- The high-value contract signal remained stable: text-equivalent and structural/text counts matched the prior report (`767` / `135` for `python_compat`, `517` / `385` for `fast`).
