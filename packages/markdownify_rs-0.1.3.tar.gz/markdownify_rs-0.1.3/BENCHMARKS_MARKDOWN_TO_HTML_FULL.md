# Markdown-To-HTML Parity And Speed

- Timestamp (UTC): 2026-02-21T18:14:56.055176+00:00
- Python-Markdown version: 3.10.2
- markdownify-rs version: 0.1.2 (local workspace)
- Corpus path: `/tmp/test_markdowns`
- Corpus docs used: 902
- Timing repeats: best-of-3

## Python-Markdown Extension Coverage

| Extension | Status | Notes |
| --- | --- | --- |
| `abbr` | yes | supported |
| `admonition` | yes | supported |
| `attr_list` | yes | supported |
| `codehilite` | yes | supported |
| `def_list` | yes | supported |
| `extra` | yes | supported |
| `fenced_code` | yes | supported |
| `footnotes` | yes | supported |
| `legacy_attrs` | yes | supported |
| `legacy_em` | yes | accepted, intentionally not parity-targeted |
| `md_in_html` | yes | accepted, intentionally not parity-targeted |
| `meta` | yes | supported |
| `nl2br` | yes | supported |
| `sane_lists` | yes | supported |
| `smarty` | yes | supported |
| `tables` | yes | supported |
| `toc` | yes | supported |
| `wikilinks` | yes | supported |

## Parity Summary

- Exact parity: 0/21 (0.00%)
- Normalized parity: 18/21 (85.71%)

| Case | Extensions | Exact | Normalized |
| --- | --- | --- | --- |
| basic | `(none)` | no | yes |
| lists | `(none)` | no | no |
| blockquote | `(none)` | no | yes |
| fenced_code | `fenced_code` | no | yes |
| tables | `tables` | no | yes |
| footnotes | `footnotes` | no | yes |
| def_list | `def_list` | no | yes |
| abbr | `abbr` | no | yes |
| admonition | `admonition` | no | yes |
| attr_list | `attr_list` | no | yes |
| codehilite | `codehilite` | no | yes |
| meta | `meta` | no | yes |
| nl2br | `nl2br` | no | yes |
| smarty | `smarty` | no | yes |
| toc | `toc` | no | yes |
| wikilinks | `wikilinks` | no | yes |
| md_in_html | `md_in_html` | no | no |
| legacy_attrs | `legacy_attrs` | no | yes |
| legacy_em | `legacy_em` | no | no |
| sane_lists | `sane_lists` | no | yes |
| extra | `extra` | no | yes |

### Parity Mismatches

#### lists (`(none)`)

Python-Markdown:
```html
<ul>
<li>one</li>
<li>
<p>two</p>
</li>
<li>
<p>three</p>
</li>
<li>four</li>
</ul>
```

markdownify-rs:
```html
<ul>
<li>one</li>
<li>two</li>
</ul>
<ol>
<li>three</li>
<li>four</li>
</ol>
```

#### md_in_html (`md_in_html`)

Python-Markdown:
```html
<div>
<p><strong>inside</strong></p>
</div>
```

markdownify-rs:
```html
<div markdown="1">**inside**</div>
```

#### legacy_em (`legacy_em`)

Python-Markdown:
```html
<p>foo<em>bar</em>baz</p>
```

markdownify-rs:
```html
<p>foo_bar_baz</p>
```

## Speed Summary

| Scenario | Extensions | Docs | Total bytes | Python time | Rust time | Python MiB/s | Rust MiB/s | Speedup (Py/Rs) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base | `(none)` | 902 | 157392400 | 39.084135s | 1.668956s | 3.840 | 89.937 | 23.42x |
| extra | `extra` | 902 | 157392400 | 53.250794s | 4.048408s | 2.819 | 37.077 | 13.15x |
| tables+footnotes | `tables,footnotes` | 902 | 157392400 | 48.460886s | 3.647157s | 3.097 | 41.156 | 13.29x |

## Notes

- Exact parity is strict string equality.
- Normalized parity ignores common whitespace and `<br>/<hr>` format differences.
- `md_in_html`, `legacy_em`, and some extension-specific edge cases are expected to diverge until further parser-level specialization is added.
- Rust timings use `markdown_batch` to include the parallelized conversion path.
