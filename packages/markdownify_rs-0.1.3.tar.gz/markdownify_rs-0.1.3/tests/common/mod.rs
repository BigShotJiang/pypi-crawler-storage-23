#![allow(dead_code)]

use std::collections::HashSet;

use markdownify_rs::{MarkdownConverter, Options, StripMode};

pub fn md(html: &str) -> String {
    md_with_options(html, |_| {})
}

pub fn md_with_options<F>(html: &str, f: F) -> String
where
    F: FnOnce(&mut Options),
{
    let mut options = Options::default();
    options.strip_document = StripMode::None;
    f(&mut options);
    MarkdownConverter::new(options).convert(html)
}

pub fn set_of(tags: &[&str]) -> HashSet<String> {
    tags.iter().map(|tag| tag.to_string()).collect()
}
