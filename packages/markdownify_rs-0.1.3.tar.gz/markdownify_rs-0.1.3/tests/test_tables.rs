mod common;

const TABLE: &str = r#"<table>
    <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Age</th>
    </tr>
    <tr>
        <td>Jill</td>
        <td>Smith</td>
        <td>50</td>
    </tr>
    <tr>
        <td>Eve</td>
        <td>Jackson</td>
        <td>94</td>
    </tr>
</table>"#;

const TABLE_WITH_HTML_CONTENT: &str = r#"<table>
    <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Age</th>
    </tr>
    <tr>
        <td><b>Jill</b></td>
        <td><i>Smith</i></td>
        <td><a href='#'>50</a></td>
    </tr>
    <tr>
        <td>Eve</td>
        <td>Jackson</td>
        <td>94</td>
    </tr>
</table>"#;

const TABLE_WITH_PARAGRAPHS: &str = r#"<table>
    <tr>
        <th>Firstname</th>
        <th><p>Lastname</p></th>
        <th>Age</th>
    </tr>
    <tr>
        <td><p>Jill</p></td>
        <td><p>Smith</p></td>
        <td><p>50</p></td>
    </tr>
    <tr>
        <td>Eve</td>
        <td>Jackson</td>
        <td>94</td>
    </tr>
</table>"#;

const TABLE_WITH_LINEBREAKS: &str = r#"<table>
    <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Age</th>
    </tr>
    <tr>
        <td>Jill</td>
        <td>Smith
        Jackson</td>
        <td>50</td>
    </tr>
    <tr>
        <td>Eve</td>
        <td>Jackson
        Smith</td>
        <td>94</td>
    </tr>
</table>"#;

const TABLE_WITH_HEADER_COLUMN: &str = r#"<table>
    <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Age</th>
    </tr>
    <tr>
        <th>Jill</th>
        <td>Smith</td>
        <td>50</td>
    </tr>
    <tr>
        <th>Eve</th>
        <td>Jackson</td>
        <td>94</td>
    </tr>
</table>"#;

const TABLE_HEAD_BODY: &str = r#"<table>
    <thead>
        <tr>
            <th>Firstname</th>
            <th>Lastname</th>
            <th>Age</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Jill</td>
            <td>Smith</td>
            <td>50</td>
        </tr>
        <tr>
            <td>Eve</td>
            <td>Jackson</td>
            <td>94</td>
        </tr>
    </tbody>
</table>"#;

const TABLE_HEAD_BODY_MISSING_HEAD: &str = r#"<table>
    <thead>
        <tr>
            <td>Firstname</td>
            <td>Lastname</td>
            <td>Age</td>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Jill</td>
            <td>Smith</td>
            <td>50</td>
        </tr>
        <tr>
            <td>Eve</td>
            <td>Jackson</td>
            <td>94</td>
        </tr>
    </tbody>
</table>"#;

const TABLE_HEAD_BODY_MULTIPLE_HEAD: &str = r#"<table>
    <thead>
        <tr>
            <td>Creator</td>
            <td>Editor</td>
            <td>Server</td>
        </tr>
        <tr>
            <td>Operator</td>
            <td>Manager</td>
            <td>Engineer</td>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Bob</td>
            <td>Oliver</td>
            <td>Tom</td>
        </tr>
        <tr>
            <td>Thomas</td>
            <td>Lucas</td>
            <td>Ethan</td>
        </tr>
    </tbody>
</table>"#;

const TABLE_MISSING_TEXT: &str = r#"<table>
    <thead>
        <tr>
            <th></th>
            <th>Lastname</th>
            <th>Age</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Jill</td>
            <td></td>
            <td>50</td>
        </tr>
        <tr>
            <td>Eve</td>
            <td>Jackson</td>
            <td>94</td>
        </tr>
    </tbody>
</table>"#;

const TABLE_MISSING_HEAD: &str = r#"<table>
    <tr>
        <td>Firstname</td>
        <td>Lastname</td>
        <td>Age</td>
    </tr>
    <tr>
        <td>Jill</td>
        <td>Smith</td>
        <td>50</td>
    </tr>
    <tr>
        <td>Eve</td>
        <td>Jackson</td>
        <td>94</td>
    </tr>
</table>"#;

const TABLE_BODY: &str = r#"<table>
    <tbody>
        <tr>
            <td>Firstname</td>
            <td>Lastname</td>
            <td>Age</td>
        </tr>
        <tr>
            <td>Jill</td>
            <td>Smith</td>
            <td>50</td>
        </tr>
        <tr>
            <td>Eve</td>
            <td>Jackson</td>
            <td>94</td>
        </tr>
    </tbody>
</table>"#;

const TABLE_WITH_CAPTION: &str = r#"TEXT<table>
    <caption>
        Caption
    </caption>
    <tbody><tr><td>Firstname</td>
            <td>Lastname</td>
            <td>Age</td>
        </tr>
    </tbody>
</table>"#;

const TABLE_WITH_COLSPAN: &str = r#"<table>
    <tr>
        <th colspan="2">Name</th>
        <th>Age</th>
    </tr>
    <tr>
        <td colspan="1">Jill</td>
        <td>Smith</td>
        <td>50</td>
    </tr>
    <tr>
        <td>Eve</td>
        <td>Jackson</td>
        <td>94</td>
    </tr>
</table>"#;

const TABLE_WITH_UNDEFINED_COLSPAN: &str = r#"<table>
    <tr>
        <th colspan="undefined">Name</th>
        <th>Age</th>
    </tr>
    <tr>
        <td colspan="-1">Jill</td>
        <td>Smith</td>
    </tr>
</table>"#;

const TABLE_WITH_COLSPAN_MISSING_HEAD: &str = r#"<table>
    <tr>
        <td colspan="2">Name</td>
        <td>Age</td>
    </tr>
    <tr>
        <td>Jill</td>
        <td>Smith</td>
        <td>50</td>
    </tr>
    <tr>
        <td>Eve</td>
        <td>Jackson</td>
        <td>94</td>
    </tr>
</table>"#;

#[test]
fn test_table() {
    assert_eq!(
        common::md(TABLE),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md(TABLE_WITH_HTML_CONTENT),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| **Jill** | *Smith* | [50](#) |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md(TABLE_WITH_PARAGRAPHS),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md(TABLE_WITH_LINEBREAKS),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| Jill | Smith Jackson | 50 |\n| Eve | Jackson Smith | 94 |\n\n"
    );
    assert_eq!(
        common::md(TABLE_WITH_HEADER_COLUMN),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md(TABLE_HEAD_BODY),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md(TABLE_HEAD_BODY_MULTIPLE_HEAD),
        "\n\n|  |  |  |\n| --- | --- | --- |\n| Creator | Editor | Server |\n| Operator | Manager | Engineer |\n| Bob | Oliver | Tom |\n| Thomas | Lucas | Ethan |\n\n"
    );
    assert_eq!(
        common::md(TABLE_HEAD_BODY_MISSING_HEAD),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md(TABLE_MISSING_TEXT),
        "\n\n|  | Lastname | Age |\n| --- | --- | --- |\n| Jill |  | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md(TABLE_MISSING_HEAD),
        "\n\n|  |  |  |\n| --- | --- | --- |\n| Firstname | Lastname | Age |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md(TABLE_BODY),
        "\n\n|  |  |  |\n| --- | --- | --- |\n| Firstname | Lastname | Age |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md(TABLE_WITH_CAPTION),
        "TEXT\n\nCaption\n\n|  |  |  |\n| --- | --- | --- |\n| Firstname | Lastname | Age |\n\n"
    );
    assert_eq!(
        common::md(TABLE_WITH_COLSPAN),
        "\n\n| Name | | Age |\n| --- | --- | --- |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md(TABLE_WITH_UNDEFINED_COLSPAN),
        "\n\n| Name | Age |\n| --- | --- |\n| Jill | Smith |\n\n"
    );
    assert_eq!(
        common::md(TABLE_WITH_COLSPAN_MISSING_HEAD),
        "\n\n|  |  |  |\n| --- | --- | --- |\n| Name | | Age |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
}

#[test]
fn test_table_infer_header() {
    assert_eq!(
        common::md_with_options(TABLE, |options| options.table_infer_header = true),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md_with_options(TABLE_WITH_HTML_CONTENT, |options| {
            options.table_infer_header = true
        }),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| **Jill** | *Smith* | [50](#) |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md_with_options(TABLE_WITH_PARAGRAPHS, |options| {
            options.table_infer_header = true
        }),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md_with_options(TABLE_WITH_LINEBREAKS, |options| {
            options.table_infer_header = true
        }),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| Jill | Smith Jackson | 50 |\n| Eve | Jackson Smith | 94 |\n\n"
    );
    assert_eq!(
        common::md_with_options(TABLE_WITH_HEADER_COLUMN, |options| {
            options.table_infer_header = true
        }),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md_with_options(TABLE_HEAD_BODY, |options| {
            options.table_infer_header = true
        }),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md_with_options(TABLE_HEAD_BODY_MULTIPLE_HEAD, |options| {
            options.table_infer_header = true
        }),
        "\n\n| Creator | Editor | Server |\n| --- | --- | --- |\n| Operator | Manager | Engineer |\n| Bob | Oliver | Tom |\n| Thomas | Lucas | Ethan |\n\n"
    );
    assert_eq!(
        common::md_with_options(TABLE_HEAD_BODY_MISSING_HEAD, |options| {
            options.table_infer_header = true
        }),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md_with_options(TABLE_MISSING_TEXT, |options| {
            options.table_infer_header = true
        }),
        "\n\n|  | Lastname | Age |\n| --- | --- | --- |\n| Jill |  | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md_with_options(TABLE_MISSING_HEAD, |options| {
            options.table_infer_header = true
        }),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md_with_options(TABLE_BODY, |options| { options.table_infer_header = true }),
        "\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md_with_options(TABLE_WITH_CAPTION, |options| {
            options.table_infer_header = true
        }),
        "TEXT\n\nCaption\n\n| Firstname | Lastname | Age |\n| --- | --- | --- |\n\n"
    );
    assert_eq!(
        common::md_with_options(TABLE_WITH_COLSPAN, |options| {
            options.table_infer_header = true
        }),
        "\n\n| Name | | Age |\n| --- | --- | --- |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
    assert_eq!(
        common::md_with_options(TABLE_WITH_UNDEFINED_COLSPAN, |options| {
            options.table_infer_header = true
        }),
        "\n\n| Name | Age |\n| --- | --- |\n| Jill | Smith |\n\n"
    );
    assert_eq!(
        common::md_with_options(TABLE_WITH_COLSPAN_MISSING_HEAD, |options| {
            options.table_infer_header = true
        }),
        "\n\n| Name | | Age |\n| --- | --- | --- |\n| Jill | Smith | 50 |\n| Eve | Jackson | 94 |\n\n"
    );
}
