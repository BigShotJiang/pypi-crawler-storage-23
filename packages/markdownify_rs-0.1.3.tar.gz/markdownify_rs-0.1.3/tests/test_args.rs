mod common;

use markdownify_rs::{StripMode, StripPreMode, markdownify};

#[test]
fn test_strip() {
    let text = common::md_with_options(
        r#"<a href="https://github.com/matthewwithanm">Some Text</a>"#,
        |options| {
            options.strip = Some(common::set_of(&["a"]));
        },
    );
    assert_eq!(text, "Some Text");
}

#[test]
fn test_do_not_strip() {
    let text = common::md_with_options(
        r#"<a href="https://github.com/matthewwithanm">Some Text</a>"#,
        |options| {
            options.strip = Some(common::set_of(&[]));
        },
    );
    assert_eq!(text, "[Some Text](https://github.com/matthewwithanm)");
}

#[test]
fn test_convert() {
    let text = common::md_with_options(
        r#"<a href="https://github.com/matthewwithanm">Some Text</a>"#,
        |options| {
            options.convert = Some(common::set_of(&["a"]));
        },
    );
    assert_eq!(text, "[Some Text](https://github.com/matthewwithanm)");
}

#[test]
fn test_do_not_convert() {
    let text = common::md_with_options(
        r#"<a href="https://github.com/matthewwithanm">Some Text</a>"#,
        |options| {
            options.convert = Some(common::set_of(&[]));
        },
    );
    assert_eq!(text, "Some Text");
}

#[test]
fn test_strip_document() {
    assert_eq!(markdownify("<p>Hello</p>"), "Hello");

    let text = common::md_with_options("<p>Hello</p>", |options| {
        options.strip_document = StripMode::LStrip;
    });
    assert_eq!(text, "Hello\n\n");

    let text = common::md_with_options("<p>Hello</p>", |options| {
        options.strip_document = StripMode::RStrip;
    });
    assert_eq!(text, "\n\nHello");

    let text = common::md_with_options("<p>Hello</p>", |options| {
        options.strip_document = StripMode::Strip;
    });
    assert_eq!(text, "Hello");

    let text = common::md_with_options("<p>Hello</p>", |options| {
        options.strip_document = StripMode::None;
    });
    assert_eq!(text, "\n\nHello\n\n");
}

#[test]
fn test_strip_pre() {
    assert_eq!(
        markdownify("<pre>  \n  \n  Hello  \n  \n  </pre>"),
        "```\n  Hello\n```"
    );
    let text = common::md_with_options("<pre>  \n  \n  Hello  \n  \n  </pre>", |options| {
        options.strip_document = StripMode::Strip;
        options.strip_pre = StripPreMode::Strip;
    });
    assert_eq!(text, "```\n  Hello\n```");
    let text = common::md_with_options("<pre>  \n  \n  Hello  \n  \n  </pre>", |options| {
        options.strip_document = StripMode::Strip;
        options.strip_pre = StripPreMode::StripOne;
    });
    assert_eq!(text, "```\n  \n  Hello  \n  \n```");
    let text = common::md_with_options("<pre>  \n  \n  Hello  \n  \n  </pre>", |options| {
        options.strip_document = StripMode::Strip;
        options.strip_pre = StripPreMode::None;
    });
    assert_eq!(text, "```\n  \n  \n  Hello  \n  \n  \n```");
}
