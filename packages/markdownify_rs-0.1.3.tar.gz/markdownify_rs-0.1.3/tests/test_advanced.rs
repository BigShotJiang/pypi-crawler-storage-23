mod common;

#[test]
fn test_chomp() {
    assert_eq!(common::md(" <b></b> "), "  ");
    assert_eq!(common::md(" <b> </b> "), "  ");
    assert_eq!(common::md(" <b>  </b> "), "  ");
    assert_eq!(common::md(" <b>   </b> "), "  ");
    assert_eq!(common::md(" <b>s </b> "), " **s**  ");
    assert_eq!(common::md(" <b> s</b> "), "  **s** ");
    assert_eq!(common::md(" <b> s </b> "), "  **s**  ");
    assert_eq!(common::md(" <b>  s  </b> "), "  **s**  ");
}

#[test]
fn test_nested() {
    let text = common::md("<p>This is an <a href=\"http://example.com/\">example link</a>.</p>");
    assert_eq!(
        text,
        "\n\nThis is an [example link](http://example.com/).\n\n"
    );
}

#[test]
fn test_ignore_comments() {
    let text = common::md("<!-- This is a comment -->");
    assert_eq!(text, "");
}

#[test]
fn test_ignore_comments_with_other_tags() {
    let text =
        common::md("<!-- This is a comment --><a href='http://example.com/'>example link</a>");
    assert_eq!(text, "[example link](http://example.com/)");
}

#[test]
fn test_code_with_tricky_content() {
    assert_eq!(common::md("<code>></code>"), "`>`");
    assert_eq!(
        common::md("<code>/home/</code><b>username</b>"),
        "`/home/`**username**"
    );
    assert_eq!(
        common::md("First line <code>blah blah<br />blah blah</code> second line"),
        "First line `blah blah  \nblah blah` second line"
    );
}

#[test]
fn test_special_tags() {
    assert_eq!(common::md("<!DOCTYPE html>"), "");
    assert_eq!(common::md("<![CDATA[foobar]]>"), "foobar");
}
