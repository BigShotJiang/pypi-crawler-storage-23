use markdownify_rs::markdown_utils::{
    TextPipelineStep, cascading_split_text, coalesce_small_chunks, filter_by_link_percentage,
    fix_newlines, fix_newlines_batch, link_percentage, link_percentage_batch, remove_large_tables,
    remove_large_tables_batch, remove_lines_with_substring, remove_lines_with_substring_batch,
    split_into_chunks, split_on_dividers, strip_data_uri_images, strip_html_and_contents,
    strip_html_and_contents_batch, strip_links_with_substring, strip_links_with_substring_batch,
    text_pipeline, text_pipeline_batch,
};

#[test]
fn test_split_on_dividers() {
    let text = "A\n-----\nB\n=====\nC\n";
    let chunks = split_on_dividers(text);
    assert_eq!(chunks, vec!["A", "B", "C"]);
}

#[test]
fn test_link_percentage() {
    let ratio = link_percentage("[a](b) plain");
    assert!((ratio - 0.5).abs() < 1e-9);
}

#[test]
fn test_strip_links_with_substring() {
    let text = "See [one](javascript:alert(1)) and [two](https://x.com).";
    let cleaned = strip_links_with_substring(text, "javascript");
    assert_eq!(cleaned, "See one and [two](https://x.com).");
}

#[test]
fn test_strip_links_with_substring_batch() {
    let docs = vec![
        "See [one](javascript:alert(1))".to_string(),
        "[two](https://x.com)".to_string(),
    ];
    let cleaned = strip_links_with_substring_batch(docs, "javascript");
    assert_eq!(
        cleaned,
        vec!["See one".to_string(), "[two](https://x.com)".to_string()]
    );
}

#[test]
fn test_remove_large_tables() {
    let text = "|a|b|\n|1|2|\ntext\n|a|b|c|\n|1|2|3|\n|4|5|6|\n";
    let cleaned = remove_large_tables(text, 4);
    assert_eq!(cleaned, "|a|b|\n|1|2|\ntext\n");
}

#[test]
fn test_remove_large_tables_batch() {
    let docs = vec![
        "|a|b|\n|1|2|\n".to_string(),
        "|a|b|c|\n|1|2|3|\n|4|5|6|\n".to_string(),
    ];
    let cleaned = remove_large_tables_batch(docs, 4);
    assert_eq!(cleaned, vec!["|a|b|\n|1|2|\n".to_string(), String::new()]);
}

#[test]
fn test_strip_html_and_contents() {
    let text = "before <div><span>x</span> y</div> after <br/> tail";
    let cleaned = strip_html_and_contents(text);
    assert_eq!(cleaned, "before  after  tail");
}

#[test]
fn test_strip_html_and_contents_batch() {
    let docs = vec!["a <div>x</div> b".to_string(), "c <br/> d".to_string()];
    let cleaned = strip_html_and_contents_batch(docs);
    assert_eq!(cleaned, vec!["a  b".to_string(), "c  d".to_string()]);
}

#[test]
fn test_strip_html_does_not_mispair_br_with_closing_b() {
    let text = "A <br>(7%) text </b> B";
    let cleaned = strip_html_and_contents(text);
    assert_eq!(cleaned, "A (7%) text  B");
}

#[test]
fn test_link_percentage_batch_and_filter() {
    let docs = vec![
        "[a](b) plain".to_string(),
        "plain".to_string(),
        "[x](y)".to_string(),
    ];
    let ratios = link_percentage_batch(docs.clone());
    assert!((ratios[0] - 0.5).abs() < 1e-9);
    assert_eq!(ratios[1], 0.0);
    assert_eq!(ratios[2], 1.0);

    let filtered = filter_by_link_percentage(docs, 0.5);
    assert_eq!(filtered, vec!["plain".to_string()]);
}

#[test]
fn test_remove_lines_with_substring() {
    let text = "keep\nremove me\nkeep too\n";
    assert_eq!(
        remove_lines_with_substring(text, "remove"),
        "keep\nkeep too"
    );
}

#[test]
fn test_remove_lines_with_substring_preserves_leading_empty_lines() {
    let text = "\n\nkeep\nremove me";
    assert_eq!(remove_lines_with_substring(text, "remove"), "\n\nkeep");
}

#[test]
fn test_remove_lines_with_substring_batch() {
    let docs = vec!["a\nx\nb".to_string(), "x\ny\nx\n".to_string()];
    let cleaned = remove_lines_with_substring_batch(docs, "x");
    assert_eq!(cleaned, vec!["a\nb".to_string(), "y".to_string()]);
}

#[test]
fn test_fix_newlines() {
    let text = "a\n\n\n\nb\n\nc";
    assert_eq!(fix_newlines(text), "a\n\nb\n\nc");
}

#[test]
fn test_fix_newlines_batch() {
    let docs = vec!["a\n\n\nb".to_string(), "x\n\ny".to_string()];
    let fixed = fix_newlines_batch(docs);
    assert_eq!(fixed, vec!["a\n\nb".to_string(), "x\n\ny".to_string()]);
}

#[test]
fn test_coalesce_small_chunks() {
    let chunks = vec!["a".to_string(), "bbb".to_string(), "cccc".to_string()];
    let merged = coalesce_small_chunks(chunks, 4);
    assert_eq!(merged, vec!["a\n\nbbb".to_string(), "cccc".to_string()]);
}

#[test]
fn test_split_into_chunks_headings() {
    let md = "# One\nA\n# Two\nB";
    let chunks = split_into_chunks(md, "headings");
    assert_eq!(chunks, vec!["# One\nA".to_string(), "# Two\nB".to_string()]);
}

#[test]
fn test_split_into_chunks_sections() {
    let md = "## Chapter 1\nA\n## Chapter 2\nB";
    let chunks = split_into_chunks(md, "sections");
    assert_eq!(
        chunks,
        vec!["## Chapter 1\nA".to_string(), "## Chapter 2\nB".to_string()]
    );
}

#[test]
fn test_split_into_chunks_brute() {
    let line = "a".repeat(3_000);
    let md = format!("{line}\n{line}\n{line}\n{line}");
    let chunks = split_into_chunks(&md, "brute");
    assert_eq!(chunks.len(), 2);
}

#[test]
fn test_split_into_chunks_lists() {
    let md = "- a\n  - b\n- c";
    let chunks = split_into_chunks(md, "lists");
    assert_eq!(chunks, vec!["- a\n  - b".to_string(), "- c".to_string()]);
}

#[test]
fn test_strip_data_uri_images() {
    let md = "x ![img](data:image/png;base64,abc) y [ok](http://a) [d]( data:image/jpeg;base64,z )";
    let cleaned = strip_data_uri_images(md);
    assert_eq!(cleaned, "x  y [ok](http://a) ");
}

#[test]
fn test_cascading_split_text() {
    let content = "# H1\nA\n# H2\nB";
    let chunks = cascading_split_text(content, &["headings".to_string()], 1, 1);
    assert_eq!(chunks, vec!["# H1\nA".to_string(), "# H2\nB".to_string()]);
}

#[test]
fn test_text_pipeline() {
    let steps = vec![
        TextPipelineStep::StripLinksWithSubstring {
            substring: "javascript".to_string(),
        },
        TextPipelineStep::RemoveLargeTables { max_cells: 4 },
        TextPipelineStep::FixNewlines,
    ];
    let text = "See [one](javascript:alert(1))\n\n\n|a|b|c|\n|1|2|3|\n|4|5|6|\n";
    let cleaned = text_pipeline(text, &steps);
    assert_eq!(cleaned, "See one\n\n");
}

#[test]
fn test_text_pipeline_batch() {
    let steps = vec![
        TextPipelineStep::StripLinksWithSubstring {
            substring: "javascript".to_string(),
        },
        TextPipelineStep::RemoveLinesWithSubstring {
            substring: "drop".to_string(),
        },
    ];
    let docs = vec![
        "keep\n[one](javascript:alert(1))".to_string(),
        "drop this\n[ok](https://x.com)".to_string(),
    ];
    let cleaned = text_pipeline_batch(docs, steps);
    assert_eq!(
        cleaned,
        vec!["keep\none".to_string(), "[ok](https://x.com)".to_string()]
    );
}
