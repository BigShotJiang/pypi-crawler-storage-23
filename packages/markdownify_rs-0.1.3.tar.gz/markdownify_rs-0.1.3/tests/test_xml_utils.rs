use markdownify_rs::xml_utils::*;

// ---------------------------------------------------------------------------
// strip_xml
// ---------------------------------------------------------------------------

#[test]
fn strip_xml_empty() {
    assert_eq!(strip_xml(""), "");
}

#[test]
fn strip_xml_no_xml() {
    assert_eq!(strip_xml("hello world"), "hello world");
}

#[test]
fn strip_xml_trims_prefix_and_suffix() {
    assert_eq!(
        strip_xml("  garbage <root>content</root> junk  "),
        "<root>content</root>"
    );
}

#[test]
fn strip_xml_already_clean() {
    assert_eq!(strip_xml("<tag>x</tag>"), "<tag>x</tag>");
}

#[test]
fn strip_xml_only_leading_garbage() {
    assert_eq!(strip_xml("stuff<tag>x</tag>"), "<tag>x</tag>");
}

#[test]
fn strip_xml_only_trailing_garbage() {
    assert_eq!(strip_xml("<tag>x</tag>stuff"), "<tag>x</tag>");
}

// ---------------------------------------------------------------------------
// remove_namespace_prefixes
// ---------------------------------------------------------------------------

#[test]
fn remove_ns_simple() {
    assert_eq!(
        remove_namespace_prefixes("<ns:root><ns:child>t</ns:child></ns:root>"),
        "<root><child>t</child></root>"
    );
}

#[test]
fn remove_ns_multiple_namespaces() {
    assert_eq!(
        remove_namespace_prefixes("<a:root><b:child>t</b:child></a:root>"),
        "<root><child>t</child></root>"
    );
}

#[test]
fn remove_ns_with_xmlns_decl() {
    let input = r#"<ns:root xmlns:ns="http://example.com"><ns:child>t</ns:child></ns:root>"#;
    let result = remove_namespace_prefixes(input);
    assert!(!result.contains("xmlns"));
    assert!(result.starts_with("<root"));
    assert!(result.contains("<child>t</child>"));
}

#[test]
fn remove_ns_noop_when_no_ns() {
    let input = "<root><child>t</child></root>";
    assert_eq!(remove_namespace_prefixes(input), input);
}

// ---------------------------------------------------------------------------
// parse_base_element
// ---------------------------------------------------------------------------

#[test]
fn parse_base_int() {
    assert_eq!(
        parse_base_element(Some("42"), false, true),
        XmlValue::Int(42)
    );
}

#[test]
fn parse_base_negative_int() {
    assert_eq!(
        parse_base_element(Some("-100"), false, true),
        XmlValue::Int(-100)
    );
}

#[test]
fn parse_base_float() {
    assert_eq!(
        parse_base_element(Some("3.14"), false, true),
        XmlValue::Float(3.14)
    );
}

#[test]
fn parse_base_string() {
    assert_eq!(
        parse_base_element(Some("hello"), false, true),
        XmlValue::String("hello".into())
    );
}

#[test]
fn parse_base_null_text() {
    assert_eq!(
        parse_base_element(Some("null"), false, true),
        XmlValue::Null
    );
    assert_eq!(
        parse_base_element(Some("NULL"), false, true),
        XmlValue::Null
    );
    assert_eq!(
        parse_base_element(Some("Null"), false, true),
        XmlValue::Null
    );
}

#[test]
fn parse_base_null_text_disabled() {
    assert_eq!(
        parse_base_element(Some("null"), false, false),
        XmlValue::String("null".into())
    );
}

#[test]
fn parse_base_empty_as_none() {
    assert_eq!(parse_base_element(Some(""), true, true), XmlValue::Null);
    assert_eq!(parse_base_element(Some("  "), true, true), XmlValue::Null);
    assert_eq!(parse_base_element(None, true, true), XmlValue::Null);
}

#[test]
fn parse_base_empty_as_empty_string() {
    assert_eq!(
        parse_base_element(Some(""), false, true),
        XmlValue::String(String::new())
    );
}

#[test]
fn parse_base_whitespace_trimmed() {
    assert_eq!(
        parse_base_element(Some("  hello  "), false, true),
        XmlValue::String("hello".into())
    );
}

#[test]
fn parse_base_large_int() {
    assert_eq!(
        parse_base_element(Some("9999999999"), false, true),
        XmlValue::Int(9999999999)
    );
}

// ---------------------------------------------------------------------------
// get_tag
// ---------------------------------------------------------------------------

#[test]
fn get_tag_simple() {
    let m = get_tag("<div>hello</div>", "div", false).unwrap();
    assert_eq!(m.content, "hello");
}

#[test]
fn get_tag_not_found() {
    assert!(get_tag("<div>hello</div>", "span", false).is_none());
}

#[test]
fn get_tag_empty_string() {
    assert!(get_tag("", "div", false).is_none());
}

#[test]
fn get_tag_with_attributes() {
    let m = get_tag(r#"<div class="main" id="root">content</div>"#, "div", true).unwrap();
    assert_eq!(m.content, "content");
    assert_eq!(m.attributes.get("class").unwrap(), "main");
    assert_eq!(m.attributes.get("id").unwrap(), "root");
}

#[test]
fn get_tag_returns_first_match() {
    let m = get_tag("<p>first</p><p>second</p>", "p", false).unwrap();
    assert_eq!(m.content, "first");
}

#[test]
fn get_tag_multiline() {
    let html = "<div>\n  <span>inner</span>\n</div>";
    let m = get_tag(html, "div", false).unwrap();
    assert!(m.content.contains("<span>inner</span>"));
}

#[test]
fn get_tag_single_quoted_attrs() {
    let m = get_tag("<div class='main'>content</div>", "div", true).unwrap();
    assert_eq!(m.attributes.get("class").unwrap(), "main");
}

// ---------------------------------------------------------------------------
// get_tags
// ---------------------------------------------------------------------------

#[test]
fn get_tags_multiple() {
    let results = get_tags("<p>a</p><p>b</p><p>c</p>", "p", false);
    assert_eq!(results.len(), 3);
    assert_eq!(results[0].content, "a");
    assert_eq!(results[1].content, "b");
    assert_eq!(results[2].content, "c");
}

#[test]
fn get_tags_empty() {
    let results = get_tags("<div>no p tags</div>", "p", false);
    assert!(results.is_empty());
}

#[test]
fn get_tags_with_attributes() {
    let html = r#"<a href="http://a.com">A</a><a href="http://b.com">B</a>"#;
    let results = get_tags(html, "a", true);
    assert_eq!(results.len(), 2);
    assert_eq!(results[0].attributes.get("href").unwrap(), "http://a.com");
    assert_eq!(results[1].content, "B");
}

#[test]
fn get_tags_from_empty() {
    assert!(get_tags("", "p", false).is_empty());
}

#[test]
fn get_tags_surrounding_text() {
    let html = "prefix <span>hello</span> middle <span>world</span> suffix";
    let results = get_tags(html, "span", false);
    assert_eq!(results.len(), 2);
    assert_eq!(results[0].content, "hello");
    assert_eq!(results[1].content, "world");
}

// ---------------------------------------------------------------------------
// object_to_xml
// ---------------------------------------------------------------------------

fn default_opts() -> ObjectToXmlOptions {
    ObjectToXmlOptions::default()
}

#[test]
fn o2x_simple_string() {
    let val = XmlValue::String("hello".into());
    assert_eq!(
        object_to_xml(&val, "root", &default_opts()),
        "<root>\n  hello\n</root>\n"
    );
}

#[test]
fn o2x_int() {
    let val = XmlValue::Int(42);
    assert_eq!(
        object_to_xml(&val, "root", &default_opts()),
        "<root>\n  42\n</root>\n"
    );
}

#[test]
fn o2x_float() {
    let val = XmlValue::Float(3.14);
    assert_eq!(
        object_to_xml(&val, "root", &default_opts()),
        "<root>\n  3.14\n</root>\n"
    );
}

#[test]
fn o2x_simple_dict() {
    let val = XmlValue::Dict(vec![
        ("name".into(), XmlValue::String("test".into())),
        ("count".into(), XmlValue::Int(5)),
    ]);
    let expected = "<root>\n  <name>\n    test\n  </name>\n  <count>\n    5\n  </count>\n</root>\n";
    assert_eq!(object_to_xml(&val, "root", &default_opts()), expected);
}

#[test]
fn o2x_simple_list() {
    let val = XmlValue::List(vec![
        XmlValue::String("a".into()),
        XmlValue::String("b".into()),
    ]);
    let result = object_to_xml(&val, "items", &default_opts());
    assert!(result.contains(r#"<li key="0">"#));
    assert!(result.contains(r#"<li key="1">"#));
    assert!(result.contains("a\n"));
    assert!(result.contains("b\n"));
}

#[test]
fn o2x_nested() {
    let val = XmlValue::Dict(vec![(
        "users".into(),
        XmlValue::List(vec![XmlValue::Dict(vec![
            ("name".into(), XmlValue::String("alice".into())),
            ("age".into(), XmlValue::Int(30)),
        ])]),
    )]);
    let result = object_to_xml(&val, "data", &default_opts());
    assert!(result.contains("<users>"));
    assert!(result.contains(r#"<li key="0">"#));
    assert!(result.contains("<name>"));
    assert!(result.contains("alice"));
    assert!(result.contains("<age>"));
    assert!(result.contains("30"));
}

#[test]
fn o2x_ignore_nulls() {
    let val = XmlValue::Dict(vec![
        ("present".into(), XmlValue::String("yes".into())),
        ("absent".into(), XmlValue::Null),
    ]);
    let result = object_to_xml(&val, "root", &default_opts());
    assert!(result.contains("<present>"));
    assert!(!result.contains("<absent>"));
}

#[test]
fn o2x_include_nulls() {
    let val = XmlValue::Dict(vec![
        ("present".into(), XmlValue::String("yes".into())),
        ("absent".into(), XmlValue::Null),
    ]);
    let mut opts = default_opts();
    opts.ignore_dict_nulls = false;
    let result = object_to_xml(&val, "root", &opts);
    assert!(result.contains("<absent>"));
}

#[test]
fn o2x_no_list_index() {
    let val = XmlValue::List(vec![XmlValue::String("x".into())]);
    let mut opts = default_opts();
    opts.include_list_index = false;
    let result = object_to_xml(&val, "root", &opts);
    assert!(result.contains("<li>"));
    assert!(!result.contains("key="));
}

#[test]
fn o2x_custom_list_item_tag() {
    let val = XmlValue::List(vec![XmlValue::String("x".into())]);
    let mut opts = default_opts();
    opts.list_item_tag = "item".to_string();
    let result = object_to_xml(&val, "root", &opts);
    assert!(result.contains("<item key=\"0\">"));
}

#[test]
fn o2x_custom_index_attr() {
    let val = XmlValue::List(vec![XmlValue::String("x".into())]);
    let mut opts = default_opts();
    opts.index_attr = "index".to_string();
    let result = object_to_xml(&val, "root", &opts);
    assert!(result.contains(r#"<li index="0">"#));
}

#[test]
fn o2x_custom_indent() {
    let val = XmlValue::Dict(vec![("k".into(), XmlValue::String("v".into()))]);
    let mut opts = default_opts();
    opts.indent_str = "\t".to_string();
    let result = object_to_xml(&val, "root", &opts);
    assert_eq!(result, "<root>\n\t<k>\n\t\tv\n\t</k>\n</root>\n");
}

// ---------------------------------------------------------------------------
// xml_to_object
// ---------------------------------------------------------------------------

fn default_xto_opts() -> XmlToObjectOptions {
    XmlToObjectOptions::default()
}

#[test]
fn x2o_simple_dict() {
    let xml = "<root><name>test</name><count>5</count></root>";
    let result = xml_to_object(xml, &default_xto_opts()).unwrap();
    assert_eq!(
        result,
        XmlValue::Dict(vec![
            ("name".into(), XmlValue::String("test".into())),
            ("count".into(), XmlValue::Int(5)),
        ])
    );
}

#[test]
fn x2o_simple_list() {
    let xml = r#"<items><li key="0">a</li><li key="1">b</li></items>"#;
    let result = xml_to_object(xml, &default_xto_opts()).unwrap();
    assert_eq!(
        result,
        XmlValue::List(vec![
            XmlValue::String("a".into()),
            XmlValue::String("b".into()),
        ])
    );
}

#[test]
fn x2o_list_auto_detect() {
    let xml = "<root><item>a</item><item>b</item><item>c</item></root>";
    let result = xml_to_object(xml, &default_xto_opts()).unwrap();
    assert_eq!(
        result,
        XmlValue::List(vec![
            XmlValue::String("a".into()),
            XmlValue::String("b".into()),
            XmlValue::String("c".into()),
        ])
    );
}

#[test]
fn x2o_list_sorts_by_index() {
    let xml = r#"<r><li key="2">c</li><li key="0">a</li><li key="1">b</li></r>"#;
    let result = xml_to_object(xml, &default_xto_opts()).unwrap();
    assert_eq!(
        result,
        XmlValue::List(vec![
            XmlValue::String("a".into()),
            XmlValue::String("b".into()),
            XmlValue::String("c".into()),
        ])
    );
}

#[test]
fn x2o_single_child_with_index() {
    let xml = r#"<root><li key="0">only</li></root>"#;
    let result = xml_to_object(xml, &default_xto_opts()).unwrap();
    assert_eq!(
        result,
        XmlValue::List(vec![XmlValue::String("only".into())])
    );
}

#[test]
fn x2o_nested_dict() {
    let xml = "<root><user><name>alice</name><age>30</age></user></root>";
    let result = xml_to_object(xml, &default_xto_opts()).unwrap();
    assert_eq!(
        result,
        XmlValue::Dict(vec![(
            "user".into(),
            XmlValue::Dict(vec![
                ("name".into(), XmlValue::String("alice".into())),
                ("age".into(), XmlValue::Int(30)),
            ])
        )])
    );
}

#[test]
fn x2o_leaf_int() {
    let xml = "<root>42</root>";
    assert_eq!(
        xml_to_object(xml, &default_xto_opts()).unwrap(),
        XmlValue::Int(42)
    );
}

#[test]
fn x2o_leaf_float() {
    let xml = "<root>3.14</root>";
    assert_eq!(
        xml_to_object(xml, &default_xto_opts()).unwrap(),
        XmlValue::Float(3.14)
    );
}

#[test]
fn x2o_leaf_null() {
    let xml = "<root>null</root>";
    assert_eq!(
        xml_to_object(xml, &default_xto_opts()).unwrap(),
        XmlValue::Null
    );
}

#[test]
fn x2o_empty_element() {
    let xml = "<root><empty></empty></root>";
    let opts = XmlToObjectOptions {
        parse_empty_tags_as_none: true,
        parse_null_text_as_none: true,
    };
    assert_eq!(
        xml_to_object(xml, &opts).unwrap(),
        XmlValue::Dict(vec![("empty".into(), XmlValue::Null)])
    );
}

#[test]
fn x2o_strips_surrounding_text() {
    let xml = "  garbage <root><k>v</k></root> more garbage";
    let result = xml_to_object(xml, &default_xto_opts()).unwrap();
    assert_eq!(
        result,
        XmlValue::Dict(vec![("k".into(), XmlValue::String("v".into()))])
    );
}

#[test]
fn x2o_removes_namespaces() {
    let xml = r#"<ns:root xmlns:ns="http://ex.com"><ns:key>val</ns:key></ns:root>"#;
    let result = xml_to_object(xml, &default_xto_opts()).unwrap();
    assert_eq!(
        result,
        XmlValue::Dict(vec![("key".into(), XmlValue::String("val".into()))])
    );
}

#[test]
fn x2o_duplicate_key_error() {
    let xml = "<root><a>1</a><b>2</b><a>3</a></root>";
    assert!(xml_to_object(xml, &default_xto_opts()).is_err());
}

#[test]
fn x2o_empty_document() {
    assert!(xml_to_object("", &default_xto_opts()).is_err());
}

// ---------------------------------------------------------------------------
// Round-trip: object_to_xml -> xml_to_object
// ---------------------------------------------------------------------------

#[test]
fn round_trip_simple_dict() {
    let val = XmlValue::Dict(vec![
        ("name".into(), XmlValue::String("test".into())),
        ("count".into(), XmlValue::Int(5)),
    ]);
    let xml = object_to_xml(&val, "root", &default_opts());
    let recovered = xml_to_object(&xml, &default_xto_opts()).unwrap();
    assert_eq!(recovered, val);
}

#[test]
fn round_trip_list() {
    let val = XmlValue::List(vec![
        XmlValue::String("a".into()),
        XmlValue::String("b".into()),
        XmlValue::String("c".into()),
    ]);
    let xml = object_to_xml(&val, "root", &default_opts());
    let recovered = xml_to_object(&xml, &default_xto_opts()).unwrap();
    assert_eq!(recovered, val);
}

#[test]
fn round_trip_nested() {
    let val = XmlValue::Dict(vec![
        ("title".into(), XmlValue::String("report".into())),
        (
            "items".into(),
            XmlValue::List(vec![
                XmlValue::Dict(vec![
                    ("name".into(), XmlValue::String("a".into())),
                    ("score".into(), XmlValue::Int(100)),
                ]),
                XmlValue::Dict(vec![
                    ("name".into(), XmlValue::String("b".into())),
                    ("score".into(), XmlValue::Int(200)),
                ]),
            ]),
        ),
    ]);
    let xml = object_to_xml(&val, "root", &default_opts());
    let recovered = xml_to_object(&xml, &default_xto_opts()).unwrap();
    assert_eq!(recovered, val);
}

#[test]
fn round_trip_ints_and_floats() {
    let val = XmlValue::Dict(vec![
        ("int_val".into(), XmlValue::Int(42)),
        ("float_val".into(), XmlValue::Float(3.14)),
        ("neg".into(), XmlValue::Int(-10)),
    ]);
    let xml = object_to_xml(&val, "root", &default_opts());
    let recovered = xml_to_object(&xml, &default_xto_opts()).unwrap();
    assert_eq!(recovered, val);
}

#[test]
fn round_trip_empty_list() {
    let val = XmlValue::Dict(vec![("items".into(), XmlValue::List(vec![]))]);
    let xml = object_to_xml(&val, "root", &default_opts());
    let opts = XmlToObjectOptions {
        parse_empty_tags_as_none: true,
        ..default_xto_opts()
    };
    // Empty list serializes as <items></items>, which parses as Null/empty
    let recovered = xml_to_object(&xml, &opts).unwrap();
    // An empty list becomes Null after round-trip (no children)
    assert_eq!(
        recovered,
        XmlValue::Dict(vec![("items".into(), XmlValue::Null)])
    );
}

#[test]
fn round_trip_single_item_list() {
    // Single item with key attr -> should still be detected as list
    let val = XmlValue::List(vec![XmlValue::String("only".into())]);
    let xml = object_to_xml(&val, "root", &default_opts());
    let recovered = xml_to_object(&xml, &default_xto_opts()).unwrap();
    assert_eq!(recovered, val);
}

#[test]
fn round_trip_deeply_nested() {
    let val = XmlValue::Dict(vec![(
        "level1".into(),
        XmlValue::Dict(vec![(
            "level2".into(),
            XmlValue::Dict(vec![("level3".into(), XmlValue::String("deep".into()))]),
        )]),
    )]);
    let xml = object_to_xml(&val, "root", &default_opts());
    let recovered = xml_to_object(&xml, &default_xto_opts()).unwrap();
    assert_eq!(recovered, val);
}
