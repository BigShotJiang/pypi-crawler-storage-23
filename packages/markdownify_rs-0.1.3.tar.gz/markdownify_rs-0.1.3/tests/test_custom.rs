use markdownify_rs::{MarkdownConverter, Options};

#[test]
fn test_custom_conversion_functions() {
    let mut converter = MarkdownConverter::new(Options::default());

    converter.register_converter("img", |conv, node, text, parent_tags| {
        format!("{}\n\n", conv.convert_img(node, text, parent_tags))
    });

    converter.register_converter("custom-tag", |_conv, _node, text, _parent_tags| {
        format!("convert_custom_tag(): {text}")
    });

    converter.register_converter("h1", |_conv, _node, text, _parent_tags| {
        format!("convert_h1: {text}")
    });

    converter.register_heading_converter(|_conv, n, _node, text, _parent_tags| {
        format!("convert_hN({n}): {text}")
    });

    assert_eq!(
        converter
            .convert(r#"<img src="/path/to/img.jpg" alt="Alt text" title="Optional title" />text"#),
        "![Alt text](/path/to/img.jpg \"Optional title\")\n\ntext"
    );
    assert_eq!(
        converter.convert(r#"<img src="/path/to/img.jpg" alt="Alt text" />text"#),
        "![Alt text](/path/to/img.jpg)\n\ntext"
    );
    assert_eq!(
        converter.convert("<custom-tag>text</custom-tag>"),
        "convert_custom_tag(): text"
    );
    assert_eq!(converter.convert("<h1>text</h1>"), "convert_h1: text");
    assert_eq!(converter.convert("<h3>text</h3>"), "convert_hN(3): text");
}
