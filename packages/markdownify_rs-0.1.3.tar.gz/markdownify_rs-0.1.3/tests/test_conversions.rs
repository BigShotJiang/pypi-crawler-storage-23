mod common;

use markdownify_rs::{ATX, ATX_CLOSED, BACKSLASH, HeadingStyle, NewlineStyle, SPACES, UNDERSCORE};

fn inline_tests(tag: &str, markup: &str) {
    assert_eq!(
        common::md(&format!("<{tag}>Hello</{tag}>")),
        format!("{markup}Hello{markup}")
    );
    assert_eq!(
        common::md(&format!("foo <{tag}>Hello</{tag}> bar")),
        format!("foo {markup}Hello{markup} bar")
    );
    assert_eq!(
        common::md(&format!("foo<{tag}> Hello</{tag}> bar")),
        format!("foo {markup}Hello{markup} bar")
    );
    assert_eq!(
        common::md(&format!("foo <{tag}>Hello </{tag}>bar")),
        format!("foo {markup}Hello{markup} bar")
    );
    let empty = common::md(&format!("foo <{tag}></{tag}> bar"));
    assert!(empty == "foo  bar" || empty == "foo bar");
}

#[test]
fn test_a() {
    assert_eq!(
        common::md(r#"<a href="https://google.com">Google</a>"#),
        "[Google](https://google.com)"
    );
    assert_eq!(
        common::md(r#"<a href="https://google.com">https://google.com</a>"#),
        "<https://google.com>"
    );
    assert_eq!(
        common::md(
            r#"<a href="https://community.kde.org/Get_Involved">https://community.kde.org/Get_Involved</a>"#
        ),
        "<https://community.kde.org/Get_Involved>"
    );
    assert_eq!(
        common::md_with_options(
            r#"<a href="https://community.kde.org/Get_Involved">https://community.kde.org/Get_Involved</a>"#,
            |options| options.autolinks = false
        ),
        r"[https://community.kde.org/Get\_Involved](https://community.kde.org/Get_Involved)"
    );
}

#[test]
fn test_a_spaces() {
    assert_eq!(
        common::md(r#"foo <a href="http://google.com">Google</a> bar"#),
        "foo [Google](http://google.com) bar"
    );
    assert_eq!(
        common::md(r#"foo<a href="http://google.com"> Google</a> bar"#),
        "foo [Google](http://google.com) bar"
    );
    assert_eq!(
        common::md(r#"foo <a href="http://google.com">Google </a>bar"#),
        "foo [Google](http://google.com) bar"
    );
    assert_eq!(
        common::md(r#"foo <a href="http://google.com"></a> bar"#),
        "foo  bar"
    );
}

#[test]
fn test_a_with_title() {
    let text = common::md(r#"<a href="http://google.com" title="The &quot;Goog&quot;">Google</a>"#);
    assert_eq!(text, r#"[Google](http://google.com "The \"Goog\"")"#);
    assert_eq!(
        common::md_with_options(
            r#"<a href="https://google.com">https://google.com</a>"#,
            |options| options.default_title = true
        ),
        r#"[https://google.com](https://google.com "https://google.com")"#
    );
}

#[test]
fn test_a_shortcut() {
    let text = common::md(r#"<a href="http://google.com">http://google.com</a>"#);
    assert_eq!(text, "<http://google.com>");
}

#[test]
fn test_a_no_autolinks() {
    assert_eq!(
        common::md_with_options(
            r#"<a href="https://google.com">https://google.com</a>"#,
            |options| options.autolinks = false
        ),
        "[https://google.com](https://google.com)"
    );
}

#[test]
fn test_a_in_code() {
    assert_eq!(
        common::md(r#"<code><a href="https://google.com">Google</a></code>"#),
        "`Google`"
    );
    assert_eq!(
        common::md(r#"<pre><a href="https://google.com">Google</a></pre>"#),
        "\n\n```\nGoogle\n```\n\n"
    );
}

#[test]
fn test_b() {
    assert_eq!(common::md("<b>Hello</b>"), "**Hello**");
}

#[test]
fn test_b_spaces() {
    assert_eq!(common::md("foo <b>Hello</b> bar"), "foo **Hello** bar");
    assert_eq!(common::md("foo<b> Hello</b> bar"), "foo **Hello** bar");
    assert_eq!(common::md("foo <b>Hello </b>bar"), "foo **Hello** bar");
    assert_eq!(common::md("foo <b></b> bar"), "foo  bar");
}

#[test]
fn test_blockquote() {
    assert_eq!(
        common::md("<blockquote>Hello</blockquote>"),
        "\n> Hello\n\n"
    );
    assert_eq!(
        common::md("<blockquote>\nHello\n</blockquote>"),
        "\n> Hello\n\n"
    );
    assert_eq!(
        common::md("<blockquote>&nbsp;Hello</blockquote>"),
        "\n> \u{00a0}Hello\n\n"
    );
}

#[test]
fn test_blockquote_with_nested_paragraph() {
    assert_eq!(
        common::md("<blockquote><p>Hello</p></blockquote>"),
        "\n> Hello\n\n"
    );
    assert_eq!(
        common::md("<blockquote><p>Hello</p><p>Hello again</p></blockquote>"),
        "\n> Hello\n>\n> Hello again\n\n"
    );
}

#[test]
fn test_blockquote_with_paragraph() {
    assert_eq!(
        common::md("<blockquote>Hello</blockquote><p>handsome</p>"),
        "\n> Hello\n\nhandsome\n\n"
    );
}

#[test]
fn test_blockquote_nested() {
    let text =
        common::md("<blockquote>And she was like <blockquote>Hello</blockquote></blockquote>");
    assert_eq!(text, "\n> And she was like\n> > Hello\n\n");
}

#[test]
fn test_br() {
    assert_eq!(common::md("a<br />b<br />c"), "a  \nb  \nc");
    assert_eq!(
        common::md_with_options("a<br />b<br />c", |options| {
            options.newline_style = NewlineStyle::Backslash;
        }),
        "a\\\nb\\\nc"
    );
    assert_eq!(
        common::md_with_options("<h1>foo<br />bar</h1>", |options| {
            options.heading_style = HeadingStyle::Atx;
        }),
        "\n\n# foo bar\n\n"
    );
    assert_eq!(
        common::md_with_options("<td>foo<br />bar</td>", |options| {
            options.heading_style = HeadingStyle::Atx;
        }),
        " foo bar |"
    );
}

#[test]
fn test_code() {
    inline_tests("code", "`");
    assert_eq!(
        common::md("<code>*this_should_not_escape*</code>"),
        "`*this_should_not_escape*`"
    );
    assert_eq!(
        common::md("<kbd>*this_should_not_escape*</kbd>"),
        "`*this_should_not_escape*`"
    );
    assert_eq!(
        common::md("<samp>*this_should_not_escape*</samp>"),
        "`*this_should_not_escape*`"
    );
    assert_eq!(
        common::md("<code><span>*this_should_not_escape*</span></code>"),
        "`*this_should_not_escape*`"
    );
    assert_eq!(
        common::md("<code>this  should\t\tnormalize</code>"),
        "`this should normalize`"
    );
    assert_eq!(
        common::md("<code><span>this  should\t\tnormalize</span></code>"),
        "`this should normalize`"
    );
    assert_eq!(common::md("<code>foo<b>bar</b>baz</code>"), "`foobarbaz`");
    assert_eq!(common::md("<kbd>foo<i>bar</i>baz</kbd>"), "`foobarbaz`");
    assert_eq!(
        common::md("<samp>foo<del> bar </del>baz</samp>"),
        "`foo bar baz`"
    );
    assert_eq!(
        common::md("<samp>foo <del>bar</del> baz</samp>"),
        "`foo bar baz`"
    );
    assert_eq!(
        common::md("<code>foo<em> bar </em>baz</code>"),
        "`foo bar baz`"
    );
    assert_eq!(
        common::md("<code>foo<code> bar </code>baz</code>"),
        "`foo bar baz`"
    );
    assert_eq!(
        common::md("<code>foo<strong> bar </strong>baz</code>"),
        "`foo bar baz`"
    );
    assert_eq!(
        common::md("<code>foo<s> bar </s>baz</code>"),
        "`foo bar baz`"
    );
    assert_eq!(
        common::md_with_options("<code>foo<sup>bar</sup>baz</code>", |options| {
            options.sup_symbol = "^".to_string();
        }),
        "`foobarbaz`"
    );
    assert_eq!(
        common::md_with_options("<code>foo<sub>bar</sub>baz</code>", |options| {
            options.sub_symbol = "^".to_string();
        }),
        "`foobarbaz`"
    );
    assert_eq!(common::md("foo<code>`bar`</code>baz"), "foo`` `bar` ``baz");
    assert_eq!(
        common::md("foo<code>``bar``</code>baz"),
        "foo``` ``bar`` ```baz"
    );
    assert_eq!(
        common::md("foo<code> `bar` </code>baz"),
        "foo `` `bar` `` baz"
    );
}

#[test]
fn test_dl() {
    assert_eq!(
        common::md("<dl><dt>term</dt><dd>definition</dd></dl>"),
        "\n\nterm\n:   definition\n\n"
    );
    assert_eq!(
        common::md("<dl><dt><p>te</p><p>rm</p></dt><dd>definition</dd></dl>"),
        "\n\nte rm\n:   definition\n\n"
    );
    assert_eq!(
        common::md("<dl><dt>term</dt><dd><p>definition-p1</p><p>definition-p2</p></dd></dl>"),
        "\n\nterm\n:   definition-p1\n\n    definition-p2\n\n"
    );
    assert_eq!(
        common::md(
            "<dl><dt>term</dt><dd><p>definition 1</p></dd><dd><p>definition 2</p></dd></dl>"
        ),
        "\n\nterm\n:   definition 1\n:   definition 2\n\n"
    );
    assert_eq!(
        common::md(
            "<dl><dt>term 1</dt><dd>definition 1</dd><dt>term 2</dt><dd>definition 2</dd></dl>"
        ),
        "\n\nterm 1\n:   definition 1\n\nterm 2\n:   definition 2\n\n"
    );
    assert_eq!(
        common::md(
            "<dl><dt>term</dt><dd><blockquote><p>line 1</p><p>line 2</p></blockquote></dd></dl>"
        ),
        "\n\nterm\n:   > line 1\n    >\n    > line 2\n\n"
    );
    assert_eq!(
        common::md(
            "<dl><dt>term</dt><dd><ol><li><p>1</p><ul><li>2a</li><li>2b</li></ul></li><li><p>3</p></li></ol></dd></dl>"
        ),
        "\n\nterm\n:   1. 1\n\n       * 2a\n       * 2b\n    2. 3\n\n"
    );
}

#[test]
fn test_del() {
    inline_tests("del", "~~");
}

#[test]
fn test_div_section_article() {
    for tag in ["div", "section", "article"] {
        assert_eq!(common::md(&format!("<{tag}>456</{tag}>")), "\n\n456\n\n");
        assert_eq!(
            common::md(&format!("123<{tag}>456</{tag}>789")),
            "123\n\n456\n\n789"
        );
        assert_eq!(
            common::md(&format!("123<{tag}>\n 456 \n</{tag}>789")),
            "123\n\n456\n\n789"
        );
        assert_eq!(
            common::md(&format!("123<{tag}><p>456</p></{tag}>789")),
            "123\n\n456\n\n789"
        );
        assert_eq!(
            common::md(&format!("123<{tag}>\n<p>456</p>\n</{tag}>789")),
            "123\n\n456\n\n789"
        );
        assert_eq!(
            common::md(&format!("123<{tag}><pre>4 5 6</pre></{tag}>789")),
            "123\n\n```\n4 5 6\n```\n\n789"
        );
        assert_eq!(
            common::md(&format!("123<{tag}>\n<pre>4 5 6</pre>\n</{tag}>789")),
            "123\n\n```\n4 5 6\n```\n\n789"
        );
        assert_eq!(
            common::md(&format!("123<{tag}>4\n5\n6</{tag}>789")),
            "123\n\n4\n5\n6\n\n789"
        );
        assert_eq!(
            common::md(&format!("123<{tag}>\n4\n5\n6\n</{tag}>789")),
            "123\n\n4\n5\n6\n\n789"
        );
        assert_eq!(
            common::md(&format!("123<{tag}>\n<p>\n4\n5\n6\n</p>\n</{tag}>789")),
            "123\n\n4\n5\n6\n\n789"
        );
        assert_eq!(
            common::md_with_options(&format!("<{tag}><h1>title</h1>body</{tag}>"), |options| {
                options.heading_style = ATX
            }),
            "\n\n# title\n\nbody\n\n"
        );
    }
}

#[test]
fn test_em() {
    inline_tests("em", "*");
}

#[test]
fn test_figcaption() {
    assert_eq!(
        common::md("TEXT<figure><figcaption>\nCaption\n</figcaption><span>SPAN</span></figure>"),
        "TEXT\n\nCaption\n\nSPAN"
    );
    assert_eq!(
        common::md("<figure><span>SPAN</span><figcaption>\nCaption\n</figcaption></figure>TEXT"),
        "SPAN\n\nCaption\n\nTEXT"
    );
}

#[test]
fn test_header_with_space() {
    assert_eq!(common::md("<h3>\n\nHello</h3>"), "\n\n### Hello\n\n");
    assert_eq!(
        common::md("<h3>Hello\n\n\nWorld</h3>"),
        "\n\n### Hello World\n\n"
    );
    assert_eq!(common::md("<h4>\n\nHello</h4>"), "\n\n#### Hello\n\n");
    assert_eq!(common::md("<h5>\n\nHello</h5>"), "\n\n##### Hello\n\n");
    assert_eq!(common::md("<h5>\n\nHello\n\n</h5>"), "\n\n##### Hello\n\n");
    assert_eq!(
        common::md("<h5>\n\nHello   \n\n</h5>"),
        "\n\n##### Hello\n\n"
    );
}

#[test]
fn test_h1() {
    assert_eq!(common::md("<h1>Hello</h1>"), "\n\nHello\n=====\n\n");
}

#[test]
fn test_h2() {
    assert_eq!(common::md("<h2>Hello</h2>"), "\n\nHello\n-----\n\n");
}

#[test]
fn test_hn() {
    assert_eq!(common::md("<h3>Hello</h3>"), "\n\n### Hello\n\n");
    assert_eq!(common::md("<h4>Hello</h4>"), "\n\n#### Hello\n\n");
    assert_eq!(common::md("<h5>Hello</h5>"), "\n\n##### Hello\n\n");
    assert_eq!(common::md("<h6>Hello</h6>"), "\n\n###### Hello\n\n");
    assert_eq!(common::md("<h10>Hello</h10>"), common::md("<h6>Hello</h6>"));
    assert_eq!(common::md("<h0>Hello</h0>"), common::md("<h1>Hello</h1>"));
    assert_eq!(common::md("<hx>Hello</hx>"), common::md("Hello"));
}

#[test]
fn test_hn_chained() {
    assert_eq!(
        common::md_with_options(
            "<h1>First</h1>\n<h2>Second</h2>\n<h3>Third</h3>",
            |options| options.heading_style = ATX
        ),
        "\n\n# First\n\n## Second\n\n### Third\n\n"
    );
    assert_eq!(
        common::md_with_options("X<h1>First</h1>", |options| options.heading_style = ATX),
        "X\n\n# First\n\n"
    );
    assert_eq!(
        common::md_with_options("X<h1>First</h1>", |options| options.heading_style =
            ATX_CLOSED),
        "X\n\n# First #\n\n"
    );
    assert_eq!(common::md("X<h1>First</h1>"), "X\n\nFirst\n=====\n\n");
}

#[test]
fn test_hn_nested_tag_heading_style() {
    assert_eq!(
        common::md_with_options("<h1>A <p>P</p> C </h1>", |options| options.heading_style =
            ATX_CLOSED),
        "\n\n# A P C #\n\n"
    );
    assert_eq!(
        common::md_with_options("<h1>A <p>P</p> C </h1>", |options| {
            options.heading_style = ATX
        }),
        "\n\n# A P C\n\n"
    );
}

#[test]
fn test_hn_nested_simple_tag() {
    let tag_to_markdown = [
        ("strong", "**strong**"),
        ("b", "**b**"),
        ("em", "*em*"),
        ("i", "*i*"),
        ("p", "p"),
        ("a", "a"),
        ("div", "div"),
        ("blockquote", "blockquote"),
    ];

    for (tag, markdown) in tag_to_markdown {
        assert_eq!(
            common::md(&format!("<h3>A <{tag}>{tag}</{tag}> B</h3>")),
            format!("\n\n### A {markdown} B\n\n")
        );
    }
}

#[test]
fn test_hn_nested_br() {
    assert_eq!(
        common::md_with_options("<h3>A <br>B</h3>", |options| {
            options.heading_style = ATX;
        }),
        "\n\n### A B\n\n"
    );
}

#[test]
fn test_hn_nested_img() {
    let cases = [
        ("", "", ""),
        ("alt='Alt Text'", "Alt Text", ""),
        (
            "alt='Alt Text' title='Optional title'",
            "Alt Text",
            " \"Optional title\"",
        ),
    ];
    for (attrs, markdown, title) in cases {
        let html = format!(r#"<h3>A <img src="/path/to/img.jpg" {attrs}/> B</h3>"#);
        let expected = if markdown.is_empty() {
            "\n\n### A B\n\n".to_string()
        } else {
            format!("\n\n### A {markdown} B\n\n")
        };
        assert_eq!(common::md(&html), expected);

        assert_eq!(
            common::md_with_options(&html, |options| {
                options.keep_inline_images_in = common::set_of(&["h3"]);
            }),
            format!("\n\n### A ![{markdown}](/path/to/img.jpg{title}) B\n\n")
        );
    }
}

#[test]
fn test_hn_atx_headings() {
    assert_eq!(
        common::md_with_options("<h1>Hello</h1>", |options| {
            options.heading_style = ATX;
        }),
        "\n\n# Hello\n\n"
    );
    assert_eq!(
        common::md_with_options("<h2>Hello</h2>", |options| {
            options.heading_style = ATX;
        }),
        "\n\n## Hello\n\n"
    );
}

#[test]
fn test_hn_atx_closed_headings() {
    assert_eq!(
        common::md_with_options("<h1>Hello</h1>", |options| {
            options.heading_style = ATX_CLOSED;
        }),
        "\n\n# Hello #\n\n"
    );
    assert_eq!(
        common::md_with_options("<h2>Hello</h2>", |options| {
            options.heading_style = ATX_CLOSED;
        }),
        "\n\n## Hello ##\n\n"
    );
}

#[test]
fn test_hn_newlines() {
    assert_eq!(
        common::md_with_options(
            "<h1>H1-1</h1>TEXT<h2>H2-2</h2>TEXT<h1>H1-2</h1>TEXT",
            |options| options.heading_style = ATX
        ),
        "\n\n# H1-1\n\nTEXT\n\n## H2-2\n\nTEXT\n\n# H1-2\n\nTEXT"
    );
    assert_eq!(
        common::md_with_options(
            "<h1>H1-1</h1>\n<p>TEXT</p>\n<h2>H2-2</h2>\n<p>TEXT</p>\n<h1>H1-2</h1>\n<p>TEXT</p>",
            |options| options.heading_style = ATX
        ),
        "\n\n# H1-1\n\nTEXT\n\n## H2-2\n\nTEXT\n\n# H1-2\n\nTEXT\n\n"
    );
}

#[test]
fn test_head() {
    assert_eq!(common::md("<head>head</head>"), "head");
}

#[test]
fn test_hr() {
    assert_eq!(common::md("Hello<hr>World"), "Hello\n\n---\n\nWorld");
    assert_eq!(common::md("Hello<hr />World"), "Hello\n\n---\n\nWorld");
    assert_eq!(
        common::md("<p>Hello</p>\n<hr>\n<p>World</p>"),
        "\n\nHello\n\n---\n\nWorld\n\n"
    );
}

#[test]
fn test_i() {
    assert_eq!(common::md("<i>Hello</i>"), "*Hello*");
}

#[test]
fn test_img() {
    assert_eq!(
        common::md(r#"<img src="/path/to/img.jpg" alt="Alt text" title="Optional title" />"#),
        r#"![Alt text](/path/to/img.jpg "Optional title")"#
    );
    assert_eq!(
        common::md(r#"<img src="/path/to/img.jpg" alt="Alt text" />"#),
        "![Alt text](/path/to/img.jpg)"
    );
}

#[test]
fn test_video() {
    assert_eq!(
        common::md(r#"<video src="/path/to/video.mp4" poster="/path/to/img.jpg">text</video>"#),
        r#"[![text](/path/to/img.jpg)](/path/to/video.mp4)"#
    );
    assert_eq!(
        common::md(r#"<video src="/path/to/video.mp4">text</video>"#),
        r#"[text](/path/to/video.mp4)"#
    );
    assert_eq!(
        common::md(r#"<video><source src="/path/to/video.mp4"/>text</video>"#),
        r#"[text](/path/to/video.mp4)"#
    );
    assert_eq!(
        common::md(r#"<video poster="/path/to/img.jpg">text</video>"#),
        r#"![text](/path/to/img.jpg)"#
    );
    assert_eq!(common::md("<video>text</video>"), "text");
}

#[test]
fn test_kbd() {
    inline_tests("kbd", "`");
}

#[test]
fn test_p() {
    assert_eq!(common::md("<p>hello</p>"), "\n\nhello\n\n");
    assert_eq!(common::md("<p><p>hello</p></p>"), "\n\nhello\n\n");
    assert_eq!(
        common::md("<p>123456789 123456789</p>"),
        "\n\n123456789 123456789\n\n"
    );
    assert_eq!(
        common::md("<p>123456789\n\n\n123456789</p>"),
        "\n\n123456789\n123456789\n\n"
    );
    assert_eq!(
        common::md_with_options("<p>123456789\n\n\n123456789</p>", |options| {
            options.wrap = true;
            options.wrap_width = Some(80);
        }),
        "\n\n123456789 123456789\n\n"
    );
    assert_eq!(
        common::md_with_options("<p>123456789\n\n\n123456789</p>", |options| {
            options.wrap = true;
            options.wrap_width = None;
        }),
        "\n\n123456789 123456789\n\n"
    );
    assert_eq!(
        common::md_with_options("<p>123456789 123456789</p>", |options| {
            options.wrap = true;
            options.wrap_width = Some(10);
        }),
        "\n\n123456789\n123456789\n\n"
    );
    assert_eq!(
        common::md_with_options(
            "<p><a href=\"https://example.com\">Some long link</a></p>",
            |options| {
                options.wrap = true;
                options.wrap_width = Some(10);
            }
        ),
        "\n\n[Some long\nlink](https://example.com)\n\n"
    );
    assert_eq!(
        common::md_with_options("<p>12345<br />67890</p>", |options| {
            options.wrap = true;
            options.wrap_width = Some(10);
            options.newline_style = BACKSLASH;
        }),
        "\n\n12345\\\n67890\n\n"
    );
    assert_eq!(
        common::md_with_options("<p>12345<br />67890</p>", |options| {
            options.wrap = true;
            options.wrap_width = Some(50);
            options.newline_style = BACKSLASH;
        }),
        "\n\n12345\\\n67890\n\n"
    );
    assert_eq!(
        common::md_with_options("<p>12345<br />67890</p>", |options| {
            options.wrap = true;
            options.wrap_width = Some(10);
            options.newline_style = SPACES;
        }),
        "\n\n12345  \n67890\n\n"
    );
    assert_eq!(
        common::md_with_options("<p>12345<br />67890</p>", |options| {
            options.wrap = true;
            options.wrap_width = Some(50);
            options.newline_style = SPACES;
        }),
        "\n\n12345  \n67890\n\n"
    );
    assert_eq!(
        common::md_with_options("<p>12345678901<br />12345</p>", |options| {
            options.wrap = true;
            options.wrap_width = Some(10);
            options.newline_style = BACKSLASH;
        }),
        "\n\n12345678901\\\n12345\n\n"
    );
    assert_eq!(
        common::md_with_options("<p>12345678901<br />12345</p>", |options| {
            options.wrap = true;
            options.wrap_width = Some(50);
            options.newline_style = BACKSLASH;
        }),
        "\n\n12345678901\\\n12345\n\n"
    );
    assert_eq!(
        common::md_with_options("<p>12345678901<br />12345</p>", |options| {
            options.wrap = true;
            options.wrap_width = Some(10);
            options.newline_style = SPACES;
        }),
        "\n\n12345678901  \n12345\n\n"
    );
    assert_eq!(
        common::md_with_options("<p>12345678901<br />12345</p>", |options| {
            options.wrap = true;
            options.wrap_width = Some(50);
            options.newline_style = SPACES;
        }),
        "\n\n12345678901  \n12345\n\n"
    );
    assert_eq!(
        common::md_with_options("<p>1234 5678 9012<br />67890</p>", |options| {
            options.wrap = true;
            options.wrap_width = Some(10);
            options.newline_style = BACKSLASH;
        }),
        "\n\n1234 5678\n9012\\\n67890\n\n"
    );
    assert_eq!(
        common::md_with_options("<p>1234 5678 9012<br />67890</p>", |options| {
            options.wrap = true;
            options.wrap_width = Some(10);
            options.newline_style = SPACES;
        }),
        "\n\n1234 5678\n9012  \n67890\n\n"
    );
    assert_eq!(
        common::md("First<p>Second</p><p>Third</p>Fourth"),
        "First\n\nSecond\n\nThird\n\nFourth"
    );
    assert_eq!(
        common::md_with_options("<p>&nbsp;x y</p>", |options| {
            options.wrap = true;
            options.wrap_width = Some(80);
        }),
        "\n\n\u{00a0}x y\n\n"
    );
}

#[test]
fn test_pre() {
    assert_eq!(
        common::md("<pre>test\n    foo\nbar</pre>"),
        "\n\n```\ntest\n    foo\nbar\n```\n\n"
    );
    assert_eq!(
        common::md("<pre><code>test\n    foo\nbar</code></pre>"),
        "\n\n```\ntest\n    foo\nbar\n```\n\n"
    );
    assert_eq!(
        common::md("<pre>*this_should_not_escape*</pre>"),
        "\n\n```\n*this_should_not_escape*\n```\n\n"
    );
    assert_eq!(
        common::md("<pre><span>*this_should_not_escape*</span></pre>"),
        "\n\n```\n*this_should_not_escape*\n```\n\n"
    );
    assert_eq!(
        common::md("<pre>\t\tthis  should\t\tnot  normalize</pre>"),
        "\n\n```\n\t\tthis  should\t\tnot  normalize\n```\n\n"
    );
    assert_eq!(
        common::md("<pre><span>\t\tthis  should\t\tnot  normalize</span></pre>"),
        "\n\n```\n\t\tthis  should\t\tnot  normalize\n```\n\n"
    );
    assert_eq!(
        common::md("<pre>foo<b>\nbar\n</b>baz</pre>"),
        "\n\n```\nfoo\nbar\nbaz\n```\n\n"
    );
    assert_eq!(
        common::md("<pre>foo<i>\nbar\n</i>baz</pre>"),
        "\n\n```\nfoo\nbar\nbaz\n```\n\n"
    );
    assert_eq!(
        common::md("<pre>foo\n<i>bar</i>\nbaz</pre>"),
        "\n\n```\nfoo\nbar\nbaz\n```\n\n"
    );
    assert_eq!(
        common::md("<pre>foo<i>\n</i>baz</pre>"),
        "\n\n```\nfoo\nbaz\n```\n\n"
    );
    assert_eq!(
        common::md("<pre>foo<del>\nbar\n</del>baz</pre>"),
        "\n\n```\nfoo\nbar\nbaz\n```\n\n"
    );
    assert_eq!(
        common::md("<pre>foo<em>\nbar\n</em>baz</pre>"),
        "\n\n```\nfoo\nbar\nbaz\n```\n\n"
    );
    assert_eq!(
        common::md("<pre>foo<code>\nbar\n</code>baz</pre>"),
        "\n\n```\nfoo\nbar\nbaz\n```\n\n"
    );
    assert_eq!(
        common::md("<pre>foo<strong>\nbar\n</strong>baz</pre>"),
        "\n\n```\nfoo\nbar\nbaz\n```\n\n"
    );
    assert_eq!(
        common::md("<pre>foo<s>\nbar\n</s>baz</pre>"),
        "\n\n```\nfoo\nbar\nbaz\n```\n\n"
    );
    assert_eq!(
        common::md_with_options("<pre>foo<sup>\nbar\n</sup>baz</pre>", |options| {
            options.sup_symbol = "^".to_string();
        }),
        "\n\n```\nfoo\nbar\nbaz\n```\n\n"
    );
    assert_eq!(
        common::md_with_options("<pre>foo<sub>\nbar\n</sub>baz</pre>", |options| {
            options.sub_symbol = "^".to_string();
        }),
        "\n\n```\nfoo\nbar\nbaz\n```\n\n"
    );
    assert_eq!(
        common::md_with_options("foo<pre>bar</pre>baz", |options| {
            options.sub_symbol = "^".to_string();
        }),
        "foo\n\n```\nbar\n```\n\nbaz"
    );
    assert_eq!(
        common::md_with_options("<p>foo</p>\n<pre>bar</pre>\n</p>baz</p>", |options| {
            options.sub_symbol = "^".to_string();
        }),
        "\n\nfoo\n\n```\nbar\n```\n\nbaz"
    );
}

#[test]
fn test_q() {
    assert_eq!(common::md("foo <q>quote</q> bar"), "foo \"quote\" bar");
    assert_eq!(
        common::md("foo <q cite=\"https://example.com\">quote</q> bar"),
        "foo \"quote\" bar"
    );
}

#[test]
fn test_script() {
    assert_eq!(
        common::md("foo <script>var foo=42;</script> bar"),
        "foo  bar"
    );
}

#[test]
fn test_style() {
    assert_eq!(
        common::md("foo <style>h1 { font-size: larger }</style> bar"),
        "foo  bar"
    );
}

#[test]
fn test_s() {
    inline_tests("s", "~~");
}

#[test]
fn test_samp() {
    inline_tests("samp", "`");
}

#[test]
fn test_strong() {
    assert_eq!(common::md("<strong>Hello</strong>"), "**Hello**");
}

#[test]
fn test_strong_em_symbol() {
    assert_eq!(
        common::md_with_options("<strong>Hello</strong>", |options| {
            options.strong_em_symbol = UNDERSCORE;
        }),
        "__Hello__"
    );
    assert_eq!(
        common::md_with_options("<b>Hello</b>", |options| {
            options.strong_em_symbol = UNDERSCORE;
        }),
        "__Hello__"
    );
    assert_eq!(
        common::md_with_options("<em>Hello</em>", |options| {
            options.strong_em_symbol = UNDERSCORE;
        }),
        "_Hello_"
    );
    assert_eq!(
        common::md_with_options("<i>Hello</i>", |options| {
            options.strong_em_symbol = UNDERSCORE;
        }),
        "_Hello_"
    );
}

#[test]
fn test_sub() {
    assert_eq!(common::md("<sub>foo</sub>"), "foo");
    assert_eq!(
        common::md_with_options("<sub>foo</sub>", |options| {
            options.sub_symbol = "~".to_string();
        }),
        "~foo~"
    );
    assert_eq!(
        common::md_with_options("<sub>foo</sub>", |options| {
            options.sub_symbol = "<sub>".to_string();
        }),
        "<sub>foo</sub>"
    );
}

#[test]
fn test_sup() {
    assert_eq!(common::md("<sup>foo</sup>"), "foo");
    assert_eq!(
        common::md_with_options("<sup>foo</sup>", |options| {
            options.sup_symbol = "^".to_string();
        }),
        "^foo^"
    );
    assert_eq!(
        common::md_with_options("<sup>foo</sup>", |options| {
            options.sup_symbol = "<sup>".to_string();
        }),
        "<sup>foo</sup>"
    );
}

#[test]
fn test_lang() {
    assert_eq!(
        common::md_with_options("<pre>test\n    foo\nbar</pre>", |options| {
            options.code_language = "python".to_string();
        }),
        "\n\n```python\ntest\n    foo\nbar\n```\n\n"
    );
    assert_eq!(
        common::md_with_options("<pre><code>test\n    foo\nbar</code></pre>", |options| {
            options.code_language = "javascript".to_string();
        }),
        "\n\n```javascript\ntest\n    foo\nbar\n```\n\n"
    );
}

#[test]
fn test_lang_callback() {
    fn callback(node: ego_tree::NodeRef<'_, scraper::node::Node>) -> Option<String> {
        let class_attr = node
            .value()
            .as_element()
            .and_then(|el| el.attr("class"))
            .unwrap_or("");
        class_attr
            .split_ascii_whitespace()
            .next()
            .map(|s| s.to_string())
    }

    assert_eq!(
        common::md_with_options(
            "<pre class=\"python\">test\n    foo\nbar</pre>",
            |options| {
                options.code_language_callback = Some(std::sync::Arc::new(callback));
            }
        ),
        "\n\n```python\ntest\n    foo\nbar\n```\n\n"
    );
    assert_eq!(
        common::md_with_options(
            "<pre class=\"javascript\"><code>test\n    foo\nbar</code></pre>",
            |options| {
                options.code_language_callback = Some(std::sync::Arc::new(callback));
            }
        ),
        "\n\n```javascript\ntest\n    foo\nbar\n```\n\n"
    );
    assert_eq!(
        common::md_with_options(
            "<pre class=\"javascript\"><code class=\"javascript\">test\n    foo\nbar</code></pre>",
            |options| {
                options.code_language_callback = Some(std::sync::Arc::new(callback));
            }
        ),
        "\n\n```javascript\ntest\n    foo\nbar\n```\n\n"
    );
}

#[test]
fn test_spaces() {
    assert_eq!(
        common::md("<p> a b </p> <p> c d </p>"),
        "\n\na b\n\nc d\n\n"
    );
    assert_eq!(common::md("<p> <i>a</i> </p>"), "\n\n*a*\n\n");
    assert_eq!(common::md("test <p> again </p>"), "test\n\nagain\n\n");
    assert_eq!(
        common::md("test <blockquote> text </blockquote> after"),
        "test\n> text\n\nafter"
    );
    assert_eq!(
        common::md(" <ol> <li> x </li> <li> y </li> </ol> "),
        "\n\n1. x\n2. y\n"
    );
    assert_eq!(
        common::md(" <ul> <li> x </li> <li> y </li> </ol> "),
        "\n\n* x\n* y\n"
    );
    assert_eq!(
        common::md("test <pre> foo </pre> bar"),
        "test\n\n```\n foo\n```\n\nbar"
    );
}
