mod common;

#[test]
fn test_asterisks() {
    assert_eq!(common::md("*hey*dude*"), r"\*hey\*dude\*");
    assert_eq!(
        common::md_with_options("*hey*dude*", |options| {
            options.escape_asterisks = false;
        }),
        "*hey*dude*"
    );
}

#[test]
fn test_underscore() {
    assert_eq!(common::md("_hey_dude_"), r"\_hey\_dude\_");
    assert_eq!(
        common::md_with_options("_hey_dude_", |options| {
            options.escape_underscores = false;
        }),
        "_hey_dude_"
    );
}

#[test]
fn test_xml_entities() {
    assert_eq!(
        common::md_with_options("&amp;", |options| {
            options.escape_misc = true;
        }),
        r"\&"
    );
}

#[test]
fn test_named_entities() {
    assert_eq!(common::md("&raquo;"), "\u{00bb}");
}

#[test]
fn test_hexadecimal_entities() {
    assert_eq!(common::md("&#x27;"), "'");
}

#[test]
fn test_single_escaping_entities() {
    assert_eq!(
        common::md_with_options("&amp;amp;", |options| {
            options.escape_misc = true;
        }),
        r"\&amp;"
    );
}

#[test]
fn test_misc() {
    assert_eq!(
        common::md_with_options(r"\*", |options| {
            options.escape_misc = true;
        }),
        r"\\\*"
    );
    assert_eq!(
        common::md_with_options("&lt;foo>", |options| {
            options.escape_misc = true;
        }),
        r"\<foo\>"
    );
    assert_eq!(
        common::md_with_options("# foo", |options| {
            options.escape_misc = true;
        }),
        r"\# foo"
    );
    assert_eq!(
        common::md_with_options("#5", |options| {
            options.escape_misc = true;
        }),
        "#5"
    );
    assert_eq!(
        common::md_with_options("5#", |options| {
            options.escape_misc = true;
        }),
        "5#"
    );
    assert_eq!(
        common::md_with_options("####### foo", |options| {
            options.escape_misc = true;
        }),
        r"####### foo"
    );
    assert_eq!(
        common::md_with_options("> foo", |options| {
            options.escape_misc = true;
        }),
        r"\> foo"
    );
    assert_eq!(
        common::md_with_options("~~foo~~", |options| {
            options.escape_misc = true;
        }),
        r"\~\~foo\~\~"
    );
    assert_eq!(
        common::md_with_options("foo\n===\n", |options| {
            options.escape_misc = true;
        }),
        "foo\n\\=\\=\\=\n"
    );
    assert_eq!(
        common::md_with_options("---\n", |options| {
            options.escape_misc = true;
        }),
        "\\---\n"
    );
    assert_eq!(
        common::md_with_options("- test", |options| {
            options.escape_misc = true;
        }),
        r"\- test"
    );
    assert_eq!(
        common::md_with_options("x - y", |options| {
            options.escape_misc = true;
        }),
        r"x \- y"
    );
    assert_eq!(
        common::md_with_options("test-case", |options| {
            options.escape_misc = true;
        }),
        "test-case"
    );
    assert_eq!(
        common::md_with_options("x-", |options| {
            options.escape_misc = true;
        }),
        "x-"
    );
    assert_eq!(
        common::md_with_options("-y", |options| {
            options.escape_misc = true;
        }),
        "-y"
    );
    assert_eq!(
        common::md_with_options("+ x\n+ y\n", |options| {
            options.escape_misc = true;
        }),
        "\\+ x\n\\+ y\n"
    );
    assert_eq!(
        common::md_with_options("`x`", |options| {
            options.escape_misc = true;
        }),
        r"\`x\`"
    );
    assert_eq!(
        common::md_with_options("[text](notalink)", |options| {
            options.escape_misc = true;
        }),
        r"\[text\](notalink)"
    );
    assert_eq!(
        common::md_with_options("<a href=\"link\">text]</a>", |options| {
            options.escape_misc = true;
        }),
        r"[text\]](link)"
    );
    assert_eq!(
        common::md_with_options("<a href=\"link\">[text]</a>", |options| {
            options.escape_misc = true;
        }),
        r"[\[text\]](link)"
    );
    assert_eq!(
        common::md_with_options("1. x", |options| {
            options.escape_misc = true;
        }),
        r"1\. x"
    );
    assert_eq!(
        common::md_with_options("<span>1.</span> x", |options| {
            options.escape_misc = true;
        }),
        r"1\. x"
    );
    assert_eq!(
        common::md_with_options(" 1. x", |options| {
            options.escape_misc = true;
        }),
        r" 1\. x"
    );
    assert_eq!(
        common::md_with_options("123456789. x", |options| {
            options.escape_misc = true;
        }),
        r"123456789\. x"
    );
    assert_eq!(
        common::md_with_options("1234567890. x", |options| {
            options.escape_misc = true;
        }),
        r"1234567890. x"
    );
    assert_eq!(
        common::md_with_options("A1. x", |options| {
            options.escape_misc = true;
        }),
        r"A1. x"
    );
    assert_eq!(
        common::md_with_options("1.2", |options| {
            options.escape_misc = true;
        }),
        r"1.2"
    );
    assert_eq!(
        common::md_with_options("not a number. x", |options| {
            options.escape_misc = true;
        }),
        r"not a number. x"
    );
    assert_eq!(
        common::md_with_options("1) x", |options| {
            options.escape_misc = true;
        }),
        r"1\) x"
    );
    assert_eq!(
        common::md_with_options("<span>1)</span> x", |options| {
            options.escape_misc = true;
        }),
        r"1\) x"
    );
    assert_eq!(
        common::md_with_options(" 1) x", |options| {
            options.escape_misc = true;
        }),
        r" 1\) x"
    );
    assert_eq!(
        common::md_with_options("123456789) x", |options| {
            options.escape_misc = true;
        }),
        r"123456789\) x"
    );
    assert_eq!(
        common::md_with_options("1234567890) x", |options| {
            options.escape_misc = true;
        }),
        r"1234567890) x"
    );
    assert_eq!(
        common::md_with_options("(1) x", |options| {
            options.escape_misc = true;
        }),
        r"(1) x"
    );
    assert_eq!(
        common::md_with_options("A1) x", |options| {
            options.escape_misc = true;
        }),
        r"A1) x"
    );
    assert_eq!(
        common::md_with_options("1)x", |options| {
            options.escape_misc = true;
        }),
        r"1)x"
    );
    assert_eq!(
        common::md_with_options("not a number) x", |options| {
            options.escape_misc = true;
        }),
        r"not a number) x"
    );
    assert_eq!(
        common::md_with_options("|not table|", |options| {
            options.escape_misc = true;
        }),
        r"\|not table\|"
    );
    assert_eq!(
        common::md_with_options(r"\ &lt;foo> &amp;amp; | ` `", |options| {
            options.escape_misc = false;
        }),
        r"\ <foo> &amp; | ` `"
    );
}
