mod common;

#[test]
fn test_single_tag() {
    assert_eq!(common::md("<span>Hello</span>"), "Hello");
}

#[test]
fn test_soup() {
    assert_eq!(common::md("<div><span>Hello</div></span>"), "\n\nHello\n\n");
}

#[test]
fn test_whitespace() {
    assert_eq!(common::md(" a  b \t\t c "), " a b c ");
    assert_eq!(common::md(" a  b \n\n c "), " a b\nc ");
}

#[test]
fn test_br_self_closing_after_non_self_closing_truncates() {
    assert_eq!(
        markdownify_rs::markdownify("<BR>one<br />two<br />three"),
        "  \none  "
    );
}

#[test]
fn test_br_self_closing_after_non_self_closing_with_endtag() {
    assert_eq!(
        markdownify_rs::markdownify("<br>one<br />two</br>three"),
        "  \none  \nthree"
    );
}

#[test]
fn test_html_top_level_space_runs_preserved() {
    assert_eq!(
        markdownify_rs::markdownify("<!DOCTYPE html><html>  <body><p>Hi</p></body></html>"),
        " \n\nHi"
    );
    assert_eq!(
        markdownify_rs::markdownify(
            "<!DOCTYPE html><html>  <head></head>   <body><p>Hi</p></body></html>"
        ),
        "  \n\nHi"
    );
}

#[test]
fn test_body_leading_space_runs_preserved_for_inline() {
    assert_eq!(
        markdownify_rs::markdownify(
            "<!DOCTYPE html><html><body>  <a href=\"x\">Hi</a></body></html>"
        ),
        " [Hi](x)"
    );
    assert_eq!(
        markdownify_rs::markdownify("<!DOCTYPE html><html><body>  <p>Hi</p></body></html>"),
        "Hi"
    );
}
