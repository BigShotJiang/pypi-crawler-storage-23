# Markdown-To-HTML Parity And Speed

- Timestamp (UTC): 2026-02-21T18:04:46.475462+00:00
- Python-Markdown version: 3.10.2
- markdownify-rs version: 0.1.2 (local workspace)
- Corpus path: `/tmp/test_markdowns`
- Corpus docs used: 500
- Timing repeats: best-of-3

## Python-Markdown Extension Coverage

| Extension | Status | Notes |
| --- | --- | --- |
| `abbr` | yes | supported |
| `admonition` | yes | supported |
| `attr_list` | yes | supported |
| `codehilite` | yes | supported |
| `def_list` | yes | supported |
| `extra` | yes | supported |
| `fenced_code` | yes | supported |
| `footnotes` | yes | supported |
| `legacy_attrs` | yes | supported |
| `legacy_em` | yes | supported |
| `md_in_html` | yes | supported |
| `meta` | yes | supported |
| `nl2br` | yes | supported |
| `sane_lists` | yes | supported |
| `smarty` | yes | supported |
| `tables` | yes | supported |
| `toc` | yes | supported |
| `wikilinks` | yes | supported |

## Parity Summary

- Exact parity: 0/21 (0.00%)
- Normalized parity: 18/21 (85.71%)

| Case | Extensions | Exact | Normalized |
| --- | --- | --- | --- |
| basic | `(none)` | no | yes |
| lists | `(none)` | no | no |
| blockquote | `(none)` | no | yes |
| fenced_code | `fenced_code` | no | yes |
| tables | `tables` | no | yes |
| footnotes | `footnotes` | no | yes |
| def_list | `def_list` | no | yes |
| abbr | `abbr` | no | yes |
| admonition | `admonition` | no | yes |
| attr_list | `attr_list` | no | yes |
| codehilite | `codehilite` | no | yes |
| meta | `meta` | no | yes |
| nl2br | `nl2br` | no | yes |
| smarty | `smarty` | no | yes |
| toc | `toc` | no | yes |
| wikilinks | `wikilinks` | no | yes |
| md_in_html | `md_in_html` | no | no |
| legacy_attrs | `legacy_attrs` | no | yes |
| legacy_em | `legacy_em` | no | no |
| sane_lists | `sane_lists` | no | yes |
| extra | `extra` | no | yes |

### Parity Mismatches

#### lists (`(none)`)

Python-Markdown:
```html
<ul>
<li>one</li>
<li>
<p>two</p>
</li>
<li>
<p>three</p>
</li>
<li>four</li>
</ul>
```

markdownify-rs:
```html
<ul>
<li>one</li>
<li>two</li>
</ul>
<ol>
<li>three</li>
<li>four</li>
</ol>
```

#### md_in_html (`md_in_html`)

Python-Markdown:
```html
<div>
<p><strong>inside</strong></p>
</div>
```

markdownify-rs:
```html
<div markdown="1">**inside**</div>
```

#### legacy_em (`legacy_em`)

Python-Markdown:
```html
<p>foo<em>bar</em>baz</p>
```

markdownify-rs:
```html
<p>foo_bar_baz</p>
```

## Speed Summary

| Scenario | Extensions | Docs | Total bytes | Python time | Rust time | Python MiB/s | Rust MiB/s | Speedup (Py/Rs) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| base | `(none)` | 500 | 82177779 | 20.082687s | 0.949574s | 3.902 | 82.533 | 21.15x |
| extra | `extra` | 500 | 82177779 | 28.303544s | 2.147928s | 2.769 | 36.487 | 13.18x |
| tables+footnotes | `tables,footnotes` | 500 | 82177779 | 25.795793s | 1.954699s | 3.038 | 40.094 | 13.20x |

## Notes

- Exact parity is strict string equality.
- Normalized parity ignores common whitespace and `<br>/<hr>` format differences.
- `md_in_html`, `legacy_em`, and some extension-specific edge cases are expected to diverge until further parser-level specialization is added.
- Rust timings use `markdown_batch` to include the parallelized conversion path.
