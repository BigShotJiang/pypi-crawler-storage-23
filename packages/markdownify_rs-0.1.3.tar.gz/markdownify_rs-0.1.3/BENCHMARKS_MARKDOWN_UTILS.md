# Markdown Utils Parity And Speed

- Timestamp (UTC): 2026-02-18T04:59:55.304981+00:00
- Python: 3.13.0
- Platform: macOS-26.2-arm64-arm-64bit-Mach-O
- Corpus: `/tmp/test_markdowns`
- Total markdown docs: 902
- Timing repeats per function: 1 (best-of-1)

## Results

| Category | Function | Parameters | Parity docs | Mismatch docs | Parity % | Python total | Rust total | Speedup (Py/Rs) |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| cleanup | link_percentage | `-` | 902/902 | 0 | 100.00% | 0.371410s | 0.115168s | 3.22x |
| cleanup | remove_large_tables | `max_cells=200` | 902/902 | 0 | 100.00% | 1.681929s | 0.161653s | 10.40x |
| cleanup | split_on_dividers | `-` | 902/902 | 0 | 100.00% | 0.339133s | 0.160096s | 2.12x |
| cleanup | strip_data_uri_images | `-` | 902/902 | 0 | 100.00% | 0.985127s | 0.138957s | 7.09x |
| cleanup | strip_html_and_contents | `-` | 864/902 | 38 | 95.79% | 32.071334s | 0.282375s | 113.58x |
| cleanup | strip_links_with_substring | `substring=javascript` | 902/902 | 0 | 100.00% | 0.368953s | 0.146188s | 2.52x |
| splitter | cascading_split_text | `how=headings,lists,bold,italic,brute;max_length=8000;coalesce_min=225` | 902/902 | 0 | 100.00% | 0.681902s | 0.316493s | 2.15x |
| splitter | coalesce_small_chunks | `min_size=225,input=headings_split` | 902/902 | 0 | 100.00% | 0.028764s | 0.133139s | 0.22x |
| splitter | split_into_chunks | `how=bold` | 902/902 | 0 | 100.00% | 0.371249s | 0.176968s | 2.10x |
| splitter | split_into_chunks | `how=brute` | 902/902 | 0 | 100.00% | 0.392919s | 0.182080s | 2.16x |
| splitter | split_into_chunks | `how=headings` | 902/902 | 0 | 100.00% | 0.497593s | 0.203786s | 2.44x |
| splitter | split_into_chunks | `how=italic` | 902/902 | 0 | 100.00% | 0.406505s | 0.179767s | 2.26x |
| splitter | split_into_chunks | `how=lists` | 902/902 | 0 | 100.00% | 0.530358s | 0.237815s | 2.23x |

## Notes

- Parity is exact equality, except float outputs use tolerance `1e-12`.
- Speedup uses total wall-clock time over the full corpus.
- `Speedup > 1.0x` means Rust is faster.
- `strip_html_and_contents` parity is expected to diverge on malformed HTML-like content after removing backtracking regex behavior.
