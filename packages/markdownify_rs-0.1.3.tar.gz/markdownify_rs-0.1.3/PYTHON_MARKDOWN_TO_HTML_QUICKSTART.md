# Python Markdown->HTML Quickstart

This quickstart documents the public Python markdown-to-HTML API exposed by `markdownify-rs`.

## Install

```bash
uv venv
uv pip install maturin
.venv/bin/maturin develop --features python
```

## Imports

```python
from markdownify_rs import markdown, markdown_batch, Markdown, MarkdownToHtmlConverter
```

`Markdown` is an alias for `MarkdownToHtmlConverter`.

## Core API

### `markdown(markdown_text, **kwargs) -> str`

Convert one markdown string to HTML.

### `markdown_batch(markdown_texts, **kwargs) -> list[str]`

Convert many markdown strings in parallel (Rust rayon backend).

### `MarkdownToHtmlConverter(**kwargs)`

Stateful converter with the same kwargs as `markdown(...)`.

Methods and properties:
- `convert(markdown_text: str) -> str`
- `convert_batch(markdown_texts: list[str]) -> list[str]`
- `reset() -> None` clears stored artifacts
- `meta -> dict[str, list[str]]` populated after `convert(...)` when `meta` extension is used
- `toc_tokens -> list[dict]` populated after `convert(...)` when `toc` processing runs  
  Each token has keys: `level`, `id`, `name`.

## Public kwargs

All kwargs below are accepted by:
- `markdown(...)`
- `markdown_batch(...)`
- `MarkdownToHtmlConverter(...)`

| kwarg | type | default | accepted values / behavior |
| --- | --- | --- | --- |
| `extensions` | `None \| str \| iterable[str]` | `[]` | Extension names are lowercased; `markdown.extensions.` prefix is stripped. |
| `extension_configs` | `None \| dict[str, dict[str, Any]]` | `{}` | Nested values are stringified (`str(...)`) before use. |
| `output_format` | `str` | `"xhtml"` | `"xhtml"`/`"xhtml1"` or `"html"`/`"html5"`. |
| `mode` | `str` | `"python_compat"` | `"python_compat"`/`"python-compat"`/`"python"`/`"compat"` or `"fast"`. |
| `tab_length` | `int` | `4` | Compatibility arg; currently accepted but not used by parser backend. |
| `lazy_ol` | `bool` | `True` | Compatibility arg; currently accepted but not used by parser backend. |
| `autolink` | `bool` | `False` | Enables comrak autolink behavior (GFM-ish). |
| `tasklist` | `bool` | `False` | Enables GitHub task list checkboxes. |
| `strikethrough` | `bool` | `False` | Enables `~~text~~` -> `<del>`. |

Unknown kwargs raise `ValueError`.

Legacy kwargs named `python_compat_*` raise `ValueError`; use `mode="python_compat"` or `mode="fast"`.

## Extension names

Extensions with implemented behavior:
- `abbr`
- `admonition`
- `attr_list`
- `codehilite`
- `def_list`
- `extra`
- `fenced_code`
- `footnotes`
- `meta`
- `nl2br`
- `sane_lists`
- `smarty`
- `tables`
- `toc`
- `wikilinks`

`extra` expands to:
- `abbr`, `attr_list`, `def_list`, `fenced_code`, `footnotes`, `md_in_html`, `tables`

Notes:
- `legacy_em`, `md_in_html`, and `legacy_attrs` are accepted by parity workflows but are not parity-targeted behavior.
- Unknown extension names are accepted but currently have no effect.

## `extension_configs` keys

Supported config keys by extension:

### `wikilinks`
- `base_url` (default: `"/"`)
- `end_url` (default: `"/"`)
- `html_class` (default: `"wikilink"`)

### `toc`
- `toc_class` (default: `"toc"`)
- `title` (default: unset)
- `slugify_unicode` (default: false; truthy strings: `1`, `true`, `yes`, `y`, `on`)

### `codehilite`
- `css_class` (default: `"codehilite"`)
- `lang_prefix` (default: `"language-"`)

## Examples

### Python-Markdown-compat mode (default)

```python
from markdownify_rs import markdown

html = markdown(
    "# Title\n\nText",
    extensions=["sane_lists", "toc"],
)
```

### Fast mode

```python
from markdownify_rs import markdown

html = markdown(
    "1) one\n2) two",
    extensions=["sane_lists"],
    mode="fast",
)
```

### GFM-like toggles

```python
from markdownify_rs import markdown

html = markdown(
    "Visit https://example.com\n\n- [ ] task\n\n~~old~~",
    autolink=True,
    tasklist=True,
    strikethrough=True,
)
```

### Stateful converter + artifacts

```python
from markdownify_rs import Markdown

md = Markdown(
    extensions=["meta", "toc"],
    extension_configs={"toc": {"title": "Contents"}},
)
html = md.convert("Title: Demo\n\n[TOC]\n\n# Intro")

print(md.meta)        # {"title": ["Demo"]}
print(md.toc_tokens)  # [{"level": 1, "id": "...", "name": "Intro"}]
```

