mod get_tag;
mod object_to_xml;
mod strip;
mod value;
mod xml_to_object;

pub use get_tag::{TagMatch, get_tag, get_tags};
pub use object_to_xml::{ObjectToXmlOptions, object_to_xml};
pub use strip::{remove_namespace_prefixes, strip_xml};
pub use value::XmlValue;
pub use xml_to_object::{XmlToObjectOptions, parse_base_element, xml_to_object};
