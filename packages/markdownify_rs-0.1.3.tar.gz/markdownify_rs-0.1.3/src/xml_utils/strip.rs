use once_cell::sync::Lazy;
use regex::Regex;

/// Trim any text before the first `<` and after the last `>`.
pub fn strip_xml(xml_string: &str) -> &str {
    if xml_string.is_empty() {
        return "";
    }
    let start = xml_string.find('<');
    let end = xml_string.rfind('>');
    match (start, end) {
        (Some(s), Some(e)) => &xml_string[s..=e],
        _ => xml_string,
    }
}

static RE_NS_PREFIX: Lazy<Regex> = Lazy::new(|| Regex::new(r"<(/?)(\w+:)").unwrap());
static RE_XMLNS: Lazy<Regex> = Lazy::new(|| Regex::new(r#"xmlns(?::\w+)?="[^"]+""#).unwrap());

/// Remove namespace prefixes from XML tags and xmlns declarations.
pub fn remove_namespace_prefixes(xml_string: &str) -> String {
    // Remove namespace prefixes in opening and closing tags
    let result = RE_NS_PREFIX.replace_all(xml_string, "<$1");
    // Remove xmlns declarations
    RE_XMLNS.replace_all(&result, "").to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_strip_xml_empty() {
        assert_eq!(strip_xml(""), "");
    }

    #[test]
    fn test_strip_xml_no_tags() {
        assert_eq!(strip_xml("hello world"), "hello world");
    }

    #[test]
    fn test_strip_xml_with_prefix() {
        assert_eq!(
            strip_xml("  hello <root>content</root> world  "),
            "<root>content</root>"
        );
    }

    #[test]
    fn test_strip_xml_normal() {
        assert_eq!(strip_xml("<root>content</root>"), "<root>content</root>");
    }

    #[test]
    fn test_strip_xml_leading_only() {
        assert_eq!(strip_xml("prefix <tag>hi</tag>"), "<tag>hi</tag>");
    }

    #[test]
    fn test_strip_xml_trailing_only() {
        assert_eq!(strip_xml("<tag>hi</tag> suffix"), "<tag>hi</tag>");
    }

    #[test]
    fn test_remove_namespace_simple() {
        assert_eq!(
            remove_namespace_prefixes("<ns:root><ns:child>text</ns:child></ns:root>"),
            "<root><child>text</child></root>"
        );
    }

    #[test]
    fn test_remove_namespace_with_xmlns() {
        let input = r#"<ns:root xmlns:ns="http://example.com"><ns:child>text</ns:child></ns:root>"#;
        let result = remove_namespace_prefixes(input);
        assert_eq!(result, "<root ><child>text</child></root>");
    }

    #[test]
    fn test_remove_namespace_multiple() {
        let input = "<a:root><b:child>text</b:child></a:root>";
        assert_eq!(
            remove_namespace_prefixes(input),
            "<root><child>text</child></root>"
        );
    }

    #[test]
    fn test_remove_namespace_no_namespace() {
        assert_eq!(
            remove_namespace_prefixes("<root><child>text</child></root>"),
            "<root><child>text</child></root>"
        );
    }
}
