/// A JSON-like value type for representing arbitrary data structures
/// that can be serialized to/from XML.
#[derive(Debug, Clone, PartialEq)]
pub enum XmlValue {
    Null,
    Int(i64),
    Float(f64),
    String(String),
    List(Vec<XmlValue>),
    /// Ordered key-value pairs (preserves insertion order like Python dicts).
    Dict(Vec<(String, XmlValue)>),
}

impl std::fmt::Display for XmlValue {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            XmlValue::Null => write!(f, ""),
            XmlValue::Int(i) => write!(f, "{i}"),
            XmlValue::Float(v) => {
                // Match Python's default float formatting
                if v.fract() == 0.0 && v.abs() < 1e16 {
                    write!(f, "{v:.1}")
                } else {
                    write!(f, "{v}")
                }
            }
            XmlValue::String(s) => write!(f, "{s}"),
            _ => write!(f, ""),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_display_int() {
        assert_eq!(XmlValue::Int(42).to_string(), "42");
        assert_eq!(XmlValue::Int(-1).to_string(), "-1");
        assert_eq!(XmlValue::Int(0).to_string(), "0");
    }

    #[test]
    fn test_display_float() {
        assert_eq!(XmlValue::Float(3.14).to_string(), "3.14");
        assert_eq!(XmlValue::Float(1.0).to_string(), "1.0");
    }

    #[test]
    fn test_display_string() {
        assert_eq!(XmlValue::String("hello".into()).to_string(), "hello");
    }

    #[test]
    fn test_display_null() {
        assert_eq!(XmlValue::Null.to_string(), "");
    }

    #[test]
    fn test_equality() {
        assert_eq!(XmlValue::Int(1), XmlValue::Int(1));
        assert_ne!(XmlValue::Int(1), XmlValue::Int(2));
        assert_eq!(
            XmlValue::Dict(vec![("a".into(), XmlValue::Int(1))]),
            XmlValue::Dict(vec![("a".into(), XmlValue::Int(1))]),
        );
    }
}
