use crate::xml_utils::XmlValue;

/// Options for `object_to_xml`.
#[derive(Debug, Clone)]
pub struct ObjectToXmlOptions {
    pub ignore_dict_nulls: bool,
    pub list_item_tag: String,
    pub include_list_index: bool,
    pub index_attr: String,
    pub indent_str: String,
}

impl Default for ObjectToXmlOptions {
    fn default() -> Self {
        Self {
            ignore_dict_nulls: true,
            list_item_tag: "li".to_string(),
            include_list_index: true,
            index_attr: "key".to_string(),
            indent_str: "  ".to_string(),
        }
    }
}

/// Convert an `XmlValue` to an indented XML string.
///
/// Mirrors the Python `object_to_xml` function byte-for-byte.
pub fn object_to_xml(obj: &XmlValue, root_tag: &str, options: &ObjectToXmlOptions) -> String {
    let mut buf = String::new();
    write_value(&mut buf, obj, root_tag, 0, options, None);
    buf
}

fn write_value(
    buf: &mut String,
    obj: &XmlValue,
    tag: &str,
    indent_level: usize,
    options: &ObjectToXmlOptions,
    index: Option<usize>,
) {
    // Opening tag with indentation
    for _ in 0..indent_level {
        buf.push_str(&options.indent_str);
    }
    buf.push('<');
    buf.push_str(tag);
    if options.include_list_index {
        if let Some(idx) = index {
            buf.push(' ');
            buf.push_str(&options.index_attr);
            buf.push_str("=\"");
            buf.push_str(&idx.to_string());
            buf.push('"');
        }
    }
    buf.push_str(">\n");

    match obj {
        XmlValue::String(s) => {
            for _ in 0..(indent_level + 1) {
                buf.push_str(&options.indent_str);
            }
            buf.push_str(s);
            buf.push('\n');
        }
        XmlValue::Int(i) => {
            for _ in 0..(indent_level + 1) {
                buf.push_str(&options.indent_str);
            }
            buf.push_str(&i.to_string());
            buf.push('\n');
        }
        XmlValue::Float(f) => {
            for _ in 0..(indent_level + 1) {
                buf.push_str(&options.indent_str);
            }
            // Match Python's default float formatting
            if f.fract() == 0.0 && f.abs() < 1e16 {
                buf.push_str(&format!("{f:.1}"));
            } else {
                buf.push_str(&f.to_string());
            }
            buf.push('\n');
        }
        XmlValue::Dict(entries) => {
            for (key, value) in entries {
                if options.ignore_dict_nulls && matches!(value, XmlValue::Null) {
                    continue;
                }
                write_value(buf, value, key, indent_level + 1, options, None);
            }
        }
        XmlValue::List(items) => {
            for (idx, item) in items.iter().enumerate() {
                write_value(
                    buf,
                    item,
                    &options.list_item_tag,
                    indent_level + 1,
                    options,
                    Some(idx),
                );
            }
        }
        XmlValue::Null => {
            // Empty element body (just open + close tags)
        }
    }

    // Closing tag
    for _ in 0..indent_level {
        buf.push_str(&options.indent_str);
    }
    buf.push_str("</");
    buf.push_str(tag);
    buf.push_str(">\n");
}

#[cfg(test)]
mod tests {
    use super::*;

    fn default_opts() -> ObjectToXmlOptions {
        ObjectToXmlOptions::default()
    }

    #[test]
    fn test_simple_string() {
        let val = XmlValue::String("hello".into());
        let result = object_to_xml(&val, "root", &default_opts());
        assert_eq!(result, "<root>\n  hello\n</root>\n");
    }

    #[test]
    fn test_simple_int() {
        let val = XmlValue::Int(42);
        let result = object_to_xml(&val, "root", &default_opts());
        assert_eq!(result, "<root>\n  42\n</root>\n");
    }

    #[test]
    fn test_simple_float() {
        let val = XmlValue::Float(3.14);
        let result = object_to_xml(&val, "root", &default_opts());
        assert_eq!(result, "<root>\n  3.14\n</root>\n");
    }

    #[test]
    fn test_simple_dict() {
        let val = XmlValue::Dict(vec![
            ("name".into(), XmlValue::String("test".into())),
            ("count".into(), XmlValue::Int(5)),
        ]);
        let result = object_to_xml(&val, "root", &default_opts());
        assert_eq!(
            result,
            "<root>\n  <name>\n    test\n  </name>\n  <count>\n    5\n  </count>\n</root>\n"
        );
    }

    #[test]
    fn test_simple_list() {
        let val = XmlValue::List(vec![
            XmlValue::String("a".into()),
            XmlValue::String("b".into()),
        ]);
        let result = object_to_xml(&val, "items", &default_opts());
        assert_eq!(
            result,
            "<items>\n  <li key=\"0\">\n    a\n  </li>\n  <li key=\"1\">\n    b\n  </li>\n</items>\n"
        );
    }

    #[test]
    fn test_nested_dict_list() {
        let val = XmlValue::Dict(vec![(
            "users".into(),
            XmlValue::List(vec![
                XmlValue::Dict(vec![
                    ("name".into(), XmlValue::String("alice".into())),
                    ("age".into(), XmlValue::Int(30)),
                ]),
                XmlValue::Dict(vec![
                    ("name".into(), XmlValue::String("bob".into())),
                    ("age".into(), XmlValue::Int(25)),
                ]),
            ]),
        )]);
        let result = object_to_xml(&val, "data", &default_opts());
        let expected = "\
<data>
  <users>
    <li key=\"0\">
      <name>
        alice
      </name>
      <age>
        30
      </age>
    </li>
    <li key=\"1\">
      <name>
        bob
      </name>
      <age>
        25
      </age>
    </li>
  </users>
</data>
";
        assert_eq!(result, expected);
    }

    #[test]
    fn test_ignore_nulls() {
        let val = XmlValue::Dict(vec![
            ("present".into(), XmlValue::String("yes".into())),
            ("absent".into(), XmlValue::Null),
        ]);
        let result = object_to_xml(&val, "root", &default_opts());
        assert_eq!(
            result,
            "<root>\n  <present>\n    yes\n  </present>\n</root>\n"
        );
    }

    #[test]
    fn test_include_nulls() {
        let val = XmlValue::Dict(vec![
            ("present".into(), XmlValue::String("yes".into())),
            ("absent".into(), XmlValue::Null),
        ]);
        let mut opts = default_opts();
        opts.ignore_dict_nulls = false;
        let result = object_to_xml(&val, "root", &opts);
        assert!(result.contains("<absent>"));
    }

    #[test]
    fn test_no_list_index() {
        let val = XmlValue::List(vec![XmlValue::String("x".into())]);
        let mut opts = default_opts();
        opts.include_list_index = false;
        let result = object_to_xml(&val, "root", &opts);
        assert_eq!(result, "<root>\n  <li>\n    x\n  </li>\n</root>\n");
    }

    #[test]
    fn test_custom_list_item_tag() {
        let val = XmlValue::List(vec![XmlValue::String("x".into())]);
        let mut opts = default_opts();
        opts.list_item_tag = "item".to_string();
        let result = object_to_xml(&val, "root", &opts);
        assert!(result.contains("<item key=\"0\">"));
    }

    #[test]
    fn test_custom_index_attr() {
        let val = XmlValue::List(vec![XmlValue::String("x".into())]);
        let mut opts = default_opts();
        opts.index_attr = "index".to_string();
        let result = object_to_xml(&val, "root", &opts);
        assert!(result.contains("<li index=\"0\">"));
    }
}
