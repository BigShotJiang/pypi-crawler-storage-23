use std::collections::HashMap;

use regex::Regex;
use scraper::{Html, Selector};

/// A matched tag with its inner content and optional attributes.
#[derive(Debug, Clone)]
pub struct TagMatch {
    pub content: String,
    pub attributes: HashMap<String, String>,
}

/// Extract the first occurrence of `<tag>...</tag>` from an HTML string.
///
/// When `return_attributes` is true, attributes are parsed from the opening tag.
/// Returns `None` if the tag is not found.
pub fn get_tag(html_string: &str, tag: &str, return_attributes: bool) -> Option<TagMatch> {
    // Try fast string scan first (avoids regex compilation)
    if let Some(m) = scan_first_tag(html_string, tag, return_attributes) {
        return Some(m);
    }
    // Fall back to scraper (html5ever) for malformed HTML
    get_tag_scraper(html_string, tag, return_attributes)
}

/// Extract all occurrences of `<tag>...</tag>` from an HTML string.
///
/// When `return_attributes` is true, attributes are parsed from the opening tag.
pub fn get_tags(html_string: &str, tag: &str, return_attributes: bool) -> Vec<TagMatch> {
    // Try fast string scan first
    let results = scan_all_tags(html_string, tag, return_attributes);
    if !results.is_empty() {
        return results;
    }
    // Fall back to scraper
    get_tags_scraper(html_string, tag, return_attributes)
}

// --- fast string-scan path (no regex compilation) ---

/// Find the first `<tag...>...</tag>` in the string via direct byte scanning.
/// Matches the Python regex `<{tag}([^>]*)>(.*?)</{tag}>` (DOTALL, non-greedy).
fn scan_first_tag(html: &str, tag: &str, return_attributes: bool) -> Option<TagMatch> {
    let close_tag = format!("</{tag}>");
    let open_prefix = format!("<{tag}");
    let bytes = html.as_bytes();
    let mut pos = 0;

    while pos < bytes.len() {
        // Find `<tag` (case-sensitive, matching the Python regex behavior)
        let open_start = match find_substr(bytes, open_prefix.as_bytes(), pos) {
            Some(i) => i,
            None => return None,
        };

        // The char right after `<tag` must be `>`, space, tab, newline, `/`, or end of string
        // This prevents matching `<table>` when searching for `<tab>`
        let after_tag = open_start + open_prefix.len();
        if after_tag < bytes.len() {
            let ch = bytes[after_tag];
            if ch != b'>' && ch != b' ' && ch != b'\t' && ch != b'\n' && ch != b'\r' && ch != b'/' {
                pos = after_tag;
                continue;
            }
        }

        // Find the closing `>` of the opening tag
        let open_end = match memchr_byte(b'>', bytes, after_tag) {
            Some(i) => i,
            None => return None,
        };

        let attrs_str = &html[after_tag..open_end];

        // Find the closing tag (non-greedy: first occurrence)
        let content_start = open_end + 1;
        let close_start = match find_substr(bytes, close_tag.as_bytes(), content_start) {
            Some(i) => i,
            None => {
                pos = content_start;
                continue;
            }
        };

        let content = html[content_start..close_start].to_string();
        let attributes = if return_attributes {
            parse_attributes(attrs_str)
        } else {
            HashMap::new()
        };

        return Some(TagMatch {
            content,
            attributes,
        });
    }

    None
}

/// Find all `<tag...>...</tag>` in the string via direct byte scanning.
fn scan_all_tags(html: &str, tag: &str, return_attributes: bool) -> Vec<TagMatch> {
    let close_tag = format!("</{tag}>");
    let open_prefix = format!("<{tag}");
    let bytes = html.as_bytes();
    let mut pos = 0;
    let mut results = Vec::new();

    while pos < bytes.len() {
        let open_start = match find_substr(bytes, open_prefix.as_bytes(), pos) {
            Some(i) => i,
            None => break,
        };

        let after_tag = open_start + open_prefix.len();
        if after_tag < bytes.len() {
            let ch = bytes[after_tag];
            if ch != b'>' && ch != b' ' && ch != b'\t' && ch != b'\n' && ch != b'\r' && ch != b'/' {
                pos = after_tag;
                continue;
            }
        }

        let open_end = match memchr_byte(b'>', bytes, after_tag) {
            Some(i) => i,
            None => break,
        };

        let attrs_str = &html[after_tag..open_end];
        let content_start = open_end + 1;

        let close_start = match find_substr(bytes, close_tag.as_bytes(), content_start) {
            Some(i) => i,
            None => {
                pos = content_start;
                continue;
            }
        };

        let content = html[content_start..close_start].to_string();
        let attributes = if return_attributes {
            parse_attributes(attrs_str)
        } else {
            HashMap::new()
        };

        results.push(TagMatch {
            content,
            attributes,
        });

        pos = close_start + close_tag.len();
    }

    results
}

/// Find the first occurrence of `needle` in `haystack` starting at `from`.
#[inline]
fn find_substr(haystack: &[u8], needle: &[u8], from: usize) -> Option<usize> {
    if needle.is_empty() || from + needle.len() > haystack.len() {
        return None;
    }
    haystack[from..]
        .windows(needle.len())
        .position(|w| w == needle)
        .map(|p| p + from)
}

/// Find the first occurrence of a single byte starting at `from`.
#[inline]
fn memchr_byte(byte: u8, haystack: &[u8], from: usize) -> Option<usize> {
    haystack[from..]
        .iter()
        .position(|&b| b == byte)
        .map(|p| p + from)
}

/// Parse HTML attributes from a string like ` class="foo" id="bar"`.
fn parse_attributes(attrs_str: &str) -> HashMap<String, String> {
    // Rust regex doesn't support backreferences, so we match both quote styles.
    // This regex is compiled once and cached (static lazy).
    static RE: once_cell::sync::Lazy<Regex> = once_cell::sync::Lazy::new(|| {
        Regex::new(r#"(\w+)\s*=\s*(?:"([^"]*)"|'([^']*)')"#).unwrap()
    });
    let mut map = HashMap::new();
    for caps in RE.captures_iter(attrs_str) {
        let key = caps.get(1).unwrap().as_str().to_string();
        // Group 2 is double-quoted value, group 3 is single-quoted value
        let value = caps
            .get(2)
            .or_else(|| caps.get(3))
            .map(|m| m.as_str())
            .unwrap_or("")
            .to_string();
        map.insert(key, value);
    }
    map
}

// --- scraper (html5ever) fallback ---

fn get_tag_scraper(html_string: &str, tag: &str, return_attributes: bool) -> Option<TagMatch> {
    let document = Html::parse_fragment(html_string);
    let selector = Selector::parse(tag).ok()?;
    let element = document.select(&selector).next()?;
    Some(element_to_tag_match(&element, return_attributes))
}

fn get_tags_scraper(html_string: &str, tag: &str, return_attributes: bool) -> Vec<TagMatch> {
    let document = Html::parse_fragment(html_string);
    let selector = match Selector::parse(tag) {
        Ok(s) => s,
        Err(_) => return vec![],
    };
    document
        .select(&selector)
        .map(|el| element_to_tag_match(&el, return_attributes))
        .collect()
}

fn element_to_tag_match(element: &scraper::ElementRef<'_>, return_attributes: bool) -> TagMatch {
    let content = element.inner_html();
    let attributes = if return_attributes {
        element
            .value()
            .attrs()
            .map(|(k, v)| (k.to_string(), v.to_string()))
            .collect()
    } else {
        HashMap::new()
    };
    TagMatch {
        content,
        attributes,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_get_tag_simple() {
        let html = "<div>hello</div>";
        let result = get_tag(html, "div", false).unwrap();
        assert_eq!(result.content, "hello");
        assert!(result.attributes.is_empty());
    }

    #[test]
    fn test_get_tag_not_found() {
        let html = "<div>hello</div>";
        assert!(get_tag(html, "span", false).is_none());
    }

    #[test]
    fn test_get_tag_with_attributes() {
        let html = r#"<div class="main" id="root">content</div>"#;
        let result = get_tag(html, "div", true).unwrap();
        assert_eq!(result.content, "content");
        assert_eq!(result.attributes.get("class").unwrap(), "main");
        assert_eq!(result.attributes.get("id").unwrap(), "root");
    }

    #[test]
    fn test_get_tag_multiline_content() {
        let html = "<div>\n  <p>inner</p>\n</div>";
        let result = get_tag(html, "div", false).unwrap();
        assert_eq!(result.content, "\n  <p>inner</p>\n");
    }

    #[test]
    fn test_get_tags_multiple() {
        let html = "<p>one</p><p>two</p><p>three</p>";
        let results = get_tags(html, "p", false);
        assert_eq!(results.len(), 3);
        assert_eq!(results[0].content, "one");
        assert_eq!(results[1].content, "two");
        assert_eq!(results[2].content, "three");
    }

    #[test]
    fn test_get_tags_empty() {
        let html = "<div>no paragraphs here</div>";
        let results = get_tags(html, "p", false);
        assert!(results.is_empty());
    }

    #[test]
    fn test_get_tags_with_attributes() {
        let html = r#"<a href="http://a.com">A</a><a href="http://b.com">B</a>"#;
        let results = get_tags(html, "a", true);
        assert_eq!(results.len(), 2);
        assert_eq!(results[0].attributes.get("href").unwrap(), "http://a.com");
        assert_eq!(results[1].attributes.get("href").unwrap(), "http://b.com");
    }

    #[test]
    fn test_get_tag_none_content() {
        // Empty string
        assert!(get_tag("", "div", false).is_none());
    }

    #[test]
    fn test_get_tag_single_quoted_attrs() {
        let html = "<div class='main'>content</div>";
        let result = get_tag(html, "div", true).unwrap();
        assert_eq!(result.attributes.get("class").unwrap(), "main");
    }

    #[test]
    fn test_get_tags_with_surrounding_text() {
        let html = "prefix <span>hello</span> middle <span>world</span> suffix";
        let results = get_tags(html, "span", false);
        assert_eq!(results.len(), 2);
        assert_eq!(results[0].content, "hello");
        assert_eq!(results[1].content, "world");
    }

    // Test that `<table>` isn't matched when searching for `<tab>`
    #[test]
    fn test_get_tag_no_prefix_match() {
        let html = "<table><tr><td>cell</td></tr></table>";
        assert!(get_tag(html, "tab", false).is_none());
    }

    #[test]
    fn test_get_tag_self_closing_ignored() {
        // Self-closing tags shouldn't match our open+close pattern
        let html = "<br/><p>text</p>";
        let result = get_tag(html, "p", false).unwrap();
        assert_eq!(result.content, "text");
    }
}
