use quick_xml::Reader;
use quick_xml::events::Event;

use crate::xml_utils::XmlValue;
use crate::xml_utils::strip::{remove_namespace_prefixes, strip_xml};

/// Options for `xml_to_object`.
#[derive(Debug, Clone)]
pub struct XmlToObjectOptions {
    pub parse_null_text_as_none: bool,
    pub parse_empty_tags_as_none: bool,
}

impl Default for XmlToObjectOptions {
    fn default() -> Self {
        Self {
            parse_null_text_as_none: true,
            parse_empty_tags_as_none: false,
        }
    }
}

/// Parse a leaf text value into an `XmlValue`.
///
/// Tries int, then float, then falls back to string. Empty/null handling
/// is controlled by the boolean flags.
pub fn parse_base_element(
    text: Option<&str>,
    parse_empty_tags_as_none: bool,
    parse_null_text_as_none: bool,
) -> XmlValue {
    let text = match text {
        None | Some("") => {
            return if parse_empty_tags_as_none {
                XmlValue::Null
            } else {
                XmlValue::String(String::new())
            };
        }
        Some(t) => t,
    };
    let trimmed = text.trim();
    if trimmed.is_empty() {
        return if parse_empty_tags_as_none {
            XmlValue::Null
        } else {
            XmlValue::String(String::new())
        };
    }
    if parse_null_text_as_none && trimmed.eq_ignore_ascii_case("null") {
        return XmlValue::Null;
    }
    // Try int first, then float
    if let Ok(i) = trimmed.parse::<i64>() {
        return XmlValue::Int(i);
    }
    if let Ok(f) = trimmed.parse::<f64>() {
        return XmlValue::Float(f);
    }
    XmlValue::String(trimmed.to_string())
}

/// Convert an XML string to an `XmlValue`.
///
/// Mirrors the Python `xml_to_object` function. Pre-processes the XML
/// by stripping surrounding non-XML text and removing namespace prefixes,
/// then parses with a lenient XML reader.
pub fn xml_to_object(xml_string: &str, options: &XmlToObjectOptions) -> Result<XmlValue, String> {
    let stripped = strip_xml(xml_string);
    let cleaned = remove_namespace_prefixes(stripped);

    let mut reader = Reader::from_str(&cleaned);
    reader.config_mut().trim_text(true);

    // Skip to the first start element (the root)
    loop {
        match reader.read_event() {
            Ok(Event::Start(ref e)) => {
                return parse_element(&mut reader, e, options);
            }
            Ok(Event::Empty(ref e)) => {
                // Self-closing root element with no children
                let _ = e; // no children
                return Ok(parse_base_element(
                    None,
                    options.parse_empty_tags_as_none,
                    options.parse_null_text_as_none,
                ));
            }
            Ok(Event::Eof) => {
                return Err("empty XML document".to_string());
            }
            Ok(_) => continue, // skip comments, processing instructions, etc.
            Err(e) => return Err(format!("XML parse error: {e}")),
        }
    }
}

/// A child element collected during parsing, before we decide if the
/// parent is a dict or a list.
struct ChildElement {
    tag_name: String,
    value: XmlValue,
    index_value: Option<IndexValue>,
}

#[derive(Clone)]
enum IndexValue {
    Int(i64),
    #[allow(dead_code)]
    Str(String),
}

/// Recursively parse an element that we've already consumed the `Start` event for.
fn parse_element(
    reader: &mut Reader<&[u8]>,
    _start: &quick_xml::events::BytesStart<'_>,
    options: &XmlToObjectOptions,
) -> Result<XmlValue, String> {
    let mut children: Vec<ChildElement> = Vec::new();
    let mut text_content: Option<String> = None;

    loop {
        match reader.read_event() {
            Ok(Event::Start(ref e)) => {
                let tag_name = local_name(e.name().as_ref());
                let index_value = extract_index_attr(e);
                let value = parse_element(reader, e, options)?;
                children.push(ChildElement {
                    tag_name,
                    value,
                    index_value,
                });
            }
            Ok(Event::Empty(ref e)) => {
                let tag_name = local_name(e.name().as_ref());
                let index_value = extract_index_attr(e);
                let value = parse_base_element(
                    None,
                    options.parse_empty_tags_as_none,
                    options.parse_null_text_as_none,
                );
                children.push(ChildElement {
                    tag_name,
                    value,
                    index_value,
                });
            }
            Ok(Event::Text(ref e)) => {
                let t = e.unescape().unwrap_or_default().to_string();
                if !t.is_empty() {
                    text_content = Some(t);
                }
            }
            Ok(Event::CData(ref e)) => {
                let t = String::from_utf8_lossy(e.as_ref()).to_string();
                if !t.is_empty() {
                    text_content = Some(t);
                }
            }
            Ok(Event::End(_)) => {
                // End of this element
                break;
            }
            Ok(Event::Eof) => {
                break;
            }
            Ok(_) => continue,
            Err(e) => return Err(format!("XML parse error: {e}")),
        }
    }

    // If no child elements, this is a leaf node
    if children.is_empty() {
        return Ok(parse_base_element(
            text_content.as_deref(),
            options.parse_empty_tags_as_none,
            options.parse_null_text_as_none,
        ));
    }

    // Determine if this should be a list or dict
    let child_tags: Vec<&str> = children.iter().map(|c| c.tag_name.as_str()).collect();
    let unique_tags: std::collections::HashSet<&str> = child_tags.iter().copied().collect();

    let is_list;

    if unique_tags.len() == 1 && child_tags.len() > 1 {
        // All children have the same tag name and there's more than one
        is_list = true;
    } else if child_tags.len() == 1 && children[0].index_value.is_some() {
        // Single child with key/index attribute
        is_list = true;
    } else if unique_tags.len() > 1 && unique_tags.len() < children.len() {
        // Multiple child tag types but with repeats - ambiguous
        return Err("Cannot parse XML with multiple child tags and repeats.".to_string());
    } else {
        is_list = false;
    }

    if is_list {
        let mut items_with_index: Vec<(Option<IndexValue>, XmlValue)> = children
            .into_iter()
            .map(|c| (c.index_value, c.value))
            .collect();

        // Sort only when all items have an integer index
        let all_int_index = items_with_index
            .iter()
            .all(|(idx, _)| matches!(idx, Some(IndexValue::Int(_))));

        if all_int_index {
            items_with_index.sort_by_key(|(idx, _)| match idx {
                Some(IndexValue::Int(i)) => *i,
                _ => 0,
            });
        }

        let items: Vec<XmlValue> = items_with_index.into_iter().map(|(_, v)| v).collect();
        Ok(XmlValue::List(items))
    } else {
        let mut entries: Vec<(String, XmlValue)> = Vec::new();
        for child in children {
            let key = child.tag_name;
            // Check for duplicate keys
            if entries.iter().any(|(k, _)| k == &key) {
                return Err(format!(
                    "Duplicate key '{key}' found in XML when not expecting a list."
                ));
            }
            entries.push((key, child.value));
        }
        Ok(XmlValue::Dict(entries))
    }
}

/// Extract the local name from a potentially namespace-prefixed tag name.
fn local_name(name: &[u8]) -> String {
    let name_str = std::str::from_utf8(name).unwrap_or("");
    // Remove namespace prefix if present
    name_str
        .rsplit_once(':')
        .map(|(_, local)| local)
        .unwrap_or(name_str)
        .to_string()
}

/// Try to extract a "key" or "index" attribute from an element.
fn extract_index_attr(e: &quick_xml::events::BytesStart<'_>) -> Option<IndexValue> {
    for attr_name in &[b"key".as_slice(), b"index".as_slice()] {
        for attr in e.attributes().flatten() {
            if attr.key.as_ref() == *attr_name {
                let val = String::from_utf8_lossy(attr.value.as_ref()).to_string();
                // Try to parse as int
                if let Ok(i) = val.parse::<i64>() {
                    return Some(IndexValue::Int(i));
                }
                return Some(IndexValue::Str(val));
            }
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    fn default_opts() -> XmlToObjectOptions {
        XmlToObjectOptions::default()
    }

    // --- parse_base_element tests ---

    #[test]
    fn test_parse_base_int() {
        assert_eq!(
            parse_base_element(Some("42"), false, true),
            XmlValue::Int(42)
        );
    }

    #[test]
    fn test_parse_base_negative_int() {
        assert_eq!(
            parse_base_element(Some("-7"), false, true),
            XmlValue::Int(-7)
        );
    }

    #[test]
    fn test_parse_base_float() {
        assert_eq!(
            parse_base_element(Some("3.14"), false, true),
            XmlValue::Float(3.14)
        );
    }

    #[test]
    fn test_parse_base_string() {
        assert_eq!(
            parse_base_element(Some("hello"), false, true),
            XmlValue::String("hello".into())
        );
    }

    #[test]
    fn test_parse_base_null_text() {
        assert_eq!(
            parse_base_element(Some("null"), false, true),
            XmlValue::Null
        );
        assert_eq!(
            parse_base_element(Some("NULL"), false, true),
            XmlValue::Null
        );
    }

    #[test]
    fn test_parse_base_null_text_disabled() {
        assert_eq!(
            parse_base_element(Some("null"), false, false),
            XmlValue::String("null".into())
        );
    }

    #[test]
    fn test_parse_base_empty_as_none() {
        assert_eq!(parse_base_element(Some(""), true, true), XmlValue::Null);
        assert_eq!(parse_base_element(Some("  "), true, true), XmlValue::Null);
        assert_eq!(parse_base_element(None, true, true), XmlValue::Null);
    }

    #[test]
    fn test_parse_base_empty_as_string() {
        assert_eq!(
            parse_base_element(Some(""), false, true),
            XmlValue::String(String::new())
        );
    }

    #[test]
    fn test_parse_base_whitespace_trimming() {
        assert_eq!(
            parse_base_element(Some("  hello  "), false, true),
            XmlValue::String("hello".into())
        );
    }

    // --- xml_to_object tests ---

    #[test]
    fn test_xml_to_object_simple_dict() {
        let xml = "<root><name>test</name><count>5</count></root>";
        let result = xml_to_object(xml, &default_opts()).unwrap();
        assert_eq!(
            result,
            XmlValue::Dict(vec![
                ("name".into(), XmlValue::String("test".into())),
                ("count".into(), XmlValue::Int(5)),
            ])
        );
    }

    #[test]
    fn test_xml_to_object_simple_list() {
        let xml = r#"<items><li key="0">a</li><li key="1">b</li></items>"#;
        let result = xml_to_object(xml, &default_opts()).unwrap();
        assert_eq!(
            result,
            XmlValue::List(vec![
                XmlValue::String("a".into()),
                XmlValue::String("b".into()),
            ])
        );
    }

    #[test]
    fn test_xml_to_object_nested() {
        let xml = "<root><user><name>alice</name><age>30</age></user></root>";
        let result = xml_to_object(xml, &default_opts()).unwrap();
        assert_eq!(
            result,
            XmlValue::Dict(vec![(
                "user".into(),
                XmlValue::Dict(vec![
                    ("name".into(), XmlValue::String("alice".into())),
                    ("age".into(), XmlValue::Int(30)),
                ])
            )])
        );
    }

    #[test]
    fn test_xml_to_object_list_auto_detect() {
        // Multiple children with same tag name -> list
        let xml = "<root><item>a</item><item>b</item><item>c</item></root>";
        let result = xml_to_object(xml, &default_opts()).unwrap();
        assert_eq!(
            result,
            XmlValue::List(vec![
                XmlValue::String("a".into()),
                XmlValue::String("b".into()),
                XmlValue::String("c".into()),
            ])
        );
    }

    #[test]
    fn test_xml_to_object_list_with_index_sorting() {
        let xml = r#"<root><li key="2">c</li><li key="0">a</li><li key="1">b</li></root>"#;
        let result = xml_to_object(xml, &default_opts()).unwrap();
        assert_eq!(
            result,
            XmlValue::List(vec![
                XmlValue::String("a".into()),
                XmlValue::String("b".into()),
                XmlValue::String("c".into()),
            ])
        );
    }

    #[test]
    fn test_xml_to_object_single_child_with_index_is_list() {
        let xml = r#"<root><li key="0">only</li></root>"#;
        let result = xml_to_object(xml, &default_opts()).unwrap();
        assert_eq!(
            result,
            XmlValue::List(vec![XmlValue::String("only".into())])
        );
    }

    #[test]
    fn test_xml_to_object_empty_element() {
        let xml = "<root><empty></empty></root>";
        let opts = XmlToObjectOptions {
            parse_empty_tags_as_none: true,
            parse_null_text_as_none: true,
        };
        let result = xml_to_object(xml, &opts).unwrap();
        assert_eq!(
            result,
            XmlValue::Dict(vec![("empty".into(), XmlValue::Null)])
        );
    }

    #[test]
    fn test_xml_to_object_with_prefix() {
        let xml = "  some garbage <root><key>val</key></root> more garbage";
        let result = xml_to_object(xml, &default_opts()).unwrap();
        assert_eq!(
            result,
            XmlValue::Dict(vec![("key".into(), XmlValue::String("val".into()))])
        );
    }

    #[test]
    fn test_xml_to_object_with_namespaces() {
        let xml = r#"<ns:root xmlns:ns="http://ex.com"><ns:key>val</ns:key></ns:root>"#;
        let result = xml_to_object(xml, &default_opts()).unwrap();
        assert_eq!(
            result,
            XmlValue::Dict(vec![("key".into(), XmlValue::String("val".into()))])
        );
    }

    #[test]
    fn test_xml_to_object_leaf_value() {
        let xml = "<root>42</root>";
        let result = xml_to_object(xml, &default_opts()).unwrap();
        assert_eq!(result, XmlValue::Int(42));
    }

    #[test]
    fn test_xml_to_object_duplicate_key_error() {
        // Different tag names but one repeats -> error
        let xml = "<root><a>1</a><b>2</b><a>3</a></root>";
        let result = xml_to_object(xml, &default_opts());
        assert!(result.is_err());
    }

    #[test]
    fn test_xml_to_object_float_value() {
        let xml = "<root>3.14</root>";
        let result = xml_to_object(xml, &default_opts()).unwrap();
        assert_eq!(result, XmlValue::Float(3.14));
    }

    #[test]
    fn test_xml_to_object_null_text() {
        let xml = "<root>null</root>";
        let result = xml_to_object(xml, &default_opts()).unwrap();
        assert_eq!(result, XmlValue::Null);
    }
}
