use std::borrow::Cow;
use std::collections::{HashMap, HashSet};
use std::sync::Arc;

use ego_tree::NodeRef;
use once_cell::sync::Lazy;
use rayon::prelude::*;
use regex::Regex;
use scraper::Html;
use scraper::node::Node;
use textwrap::{Options as WrapOptions, WordSeparator, WordSplitter};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum HeadingStyle {
    Atx,
    AtxClosed,
    Underlined,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum NewlineStyle {
    Spaces,
    Backslash,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum StripMode {
    LStrip,
    RStrip,
    Strip,
    None,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum StripPreMode {
    Strip,
    StripOne,
    None,
}

pub const ATX: HeadingStyle = HeadingStyle::Atx;
pub const ATX_CLOSED: HeadingStyle = HeadingStyle::AtxClosed;
pub const UNDERLINED: HeadingStyle = HeadingStyle::Underlined;
pub const SETEXT: HeadingStyle = HeadingStyle::Underlined;

pub const SPACES: NewlineStyle = NewlineStyle::Spaces;
pub const BACKSLASH: NewlineStyle = NewlineStyle::Backslash;

pub const ASTERISK: char = '*';
pub const UNDERSCORE: char = '_';

pub const LSTRIP: StripMode = StripMode::LStrip;
pub const RSTRIP: StripMode = StripMode::RStrip;
pub const STRIP: StripMode = StripMode::Strip;

pub const STRIP_ONE: StripPreMode = StripPreMode::StripOne;

pub type CodeLanguageCallback =
    Arc<dyn for<'a> Fn(NodeRef<'a, Node>) -> Option<String> + Send + Sync>;

pub type CustomConverter = Arc<
    dyn for<'a> Fn(&MarkdownConverter, NodeRef<'a, Node>, &str, &HashSet<String>) -> String
        + Send
        + Sync,
>;

pub type HeadingConverter = Arc<
    dyn for<'a> Fn(&MarkdownConverter, usize, NodeRef<'a, Node>, &str, &HashSet<String>) -> String
        + Send
        + Sync,
>;

#[derive(Clone)]
pub struct Options {
    pub autolinks: bool,
    pub bullets: String,
    pub code_language: String,
    pub code_language_callback: Option<CodeLanguageCallback>,
    pub convert: Option<HashSet<String>>,
    pub default_title: bool,
    pub escape_asterisks: bool,
    pub escape_underscores: bool,
    pub escape_misc: bool,
    pub heading_style: HeadingStyle,
    pub keep_inline_images_in: HashSet<String>,
    pub newline_style: NewlineStyle,
    pub strip: Option<HashSet<String>>,
    pub strip_document: StripMode,
    pub strip_pre: StripPreMode,
    pub strong_em_symbol: char,
    pub sub_symbol: String,
    pub sup_symbol: String,
    pub table_infer_header: bool,
    pub wrap: bool,
    pub wrap_width: Option<usize>,
}

impl Default for Options {
    fn default() -> Self {
        Self {
            autolinks: true,
            bullets: "*+-".to_string(),
            code_language: String::new(),
            code_language_callback: None,
            convert: None,
            default_title: false,
            escape_asterisks: true,
            escape_underscores: true,
            escape_misc: false,
            heading_style: HeadingStyle::Underlined,
            keep_inline_images_in: HashSet::new(),
            newline_style: NewlineStyle::Spaces,
            strip: None,
            strip_document: StripMode::Strip,
            strip_pre: StripPreMode::Strip,
            strong_em_symbol: ASTERISK,
            sub_symbol: String::new(),
            sup_symbol: String::new(),
            table_infer_header: false,
            wrap: false,
            wrap_width: Some(80),
        }
    }
}

#[derive(Default)]
pub struct MarkdownConverter {
    options: Options,
    custom_converters: HashMap<String, CustomConverter>,
    custom_heading: Option<HeadingConverter>,
}

impl MarkdownConverter {
    pub fn new(options: Options) -> Self {
        Self {
            options,
            custom_converters: HashMap::new(),
            custom_heading: None,
        }
    }

    pub fn options(&self) -> &Options {
        &self.options
    }

    pub fn options_mut(&mut self) -> &mut Options {
        &mut self.options
    }

    pub fn register_converter<F>(&mut self, tag_name: &str, converter: F)
    where
        F: for<'a> Fn(&MarkdownConverter, NodeRef<'a, Node>, &str, &HashSet<String>) -> String
            + Send
            + Sync
            + 'static,
    {
        let key = convert_fn_key(tag_name);
        self.custom_converters.insert(key, Arc::new(converter));
    }

    pub fn register_heading_converter<F>(&mut self, converter: F)
    where
        F: for<'a> Fn(
                &MarkdownConverter,
                usize,
                NodeRef<'a, Node>,
                &str,
                &HashSet<String>,
            ) -> String
            + Send
            + Sync
            + 'static,
    {
        self.custom_heading = Some(Arc::new(converter));
    }

    pub fn convert(&self, html: &str) -> String {
        let html = apply_br_quirk(html);
        let leading_prefix = leading_whitespace_prefix(html.as_ref());
        let trimmed = html
            .as_ref()
            .trim_start_matches(char::is_whitespace)
            .as_bytes();
        if !contains_ascii_case_insensitive(html.as_ref().as_bytes(), b"<table")
            && (starts_with_ascii_case_insensitive(trimmed, b"<td")
                || starts_with_ascii_case_insensitive(trimmed, b"<th"))
        {
            let wrapped = format!("<table><tr>{}</tr></table>", html);
            let fragment = Html::parse_fragment(&wrapped);
            let root = fragment.tree.root();
            if let Some(cell) = find_all(root, &["td", "th"]).into_iter().next() {
                let parent_tags = HashSet::new();
                return self.process_tag(cell, &parent_tags);
            }
        }

        let fragment = Html::parse_fragment(html.as_ref());
        if leading_prefix.is_empty() {
            return self.convert_dom(&fragment);
        }

        let mut options = self.options.clone();
        options.strip_document = StripMode::None;
        let converter = MarkdownConverter {
            options,
            custom_converters: self.custom_converters.clone(),
            custom_heading: self.custom_heading.clone(),
        };
        let mut output = converter.convert_dom(&fragment);
        let mut prefix_len = 0usize;
        for (idx, ch) in output.char_indices() {
            if ch.is_whitespace() {
                prefix_len = idx + ch.len_utf8();
            } else {
                break;
            }
        }
        let output_prefix = &output[..prefix_len];
        let common_len = common_prefix_len(&leading_prefix, output_prefix);
        let mut merged = String::with_capacity(
            output.len() - prefix_len + leading_prefix.len() + (output_prefix.len() - common_len),
        );
        merged.push_str(&leading_prefix);
        merged.push_str(&output_prefix[common_len..]);
        merged.push_str(&output[prefix_len..]);
        output = merged;
        self.convert_document(&output)
    }

    pub fn convert_dom(&self, dom: &Html) -> String {
        let parent_tags = HashSet::new();
        self.process_tag(dom.tree.root(), &parent_tags)
    }

    fn process_node(&self, node: NodeRef<'_, Node>, parent_tags: &HashSet<String>) -> String {
        match node.value() {
            Node::Text(_) | Node::ProcessingInstruction(_) => self.process_text(node, parent_tags),
            Node::Element(_) | Node::Document | Node::Fragment => {
                self.process_tag(node, parent_tags)
            }
            Node::Comment(comment) => {
                if let Some(cdata) = extract_cdata(comment) {
                    self.process_text_value(cdata, node, parent_tags)
                } else {
                    String::new()
                }
            }
            Node::Doctype(_) => String::new(),
        }
    }

    fn process_tag(&self, node: NodeRef<'_, Node>, parent_tags: &HashSet<String>) -> String {
        let tag_name = node_tag_name(node);
        let tag_name = tag_name.as_deref().unwrap_or("").to_ascii_lowercase();

        let should_remove_inside = should_remove_whitespace_inside(&tag_name);

        let children_to_convert: Vec<NodeRef<'_, Node>> = node
            .children()
            .filter(|child| !can_ignore(*child, should_remove_inside))
            .collect();

        let mut parent_tags_for_children = parent_tags.clone();
        if !tag_name.is_empty() {
            parent_tags_for_children.insert(tag_name.clone());
        }

        if is_heading_tag(&tag_name) || tag_name == "td" || tag_name == "th" {
            parent_tags_for_children.insert("_inline".to_string());
        }

        if matches!(tag_name.as_str(), "pre" | "code" | "kbd" | "samp") {
            parent_tags_for_children.insert("_noformat".to_string());
        }

        let mut child_strings: Vec<String> = children_to_convert
            .into_iter()
            .map(|child| self.process_node(child, &parent_tags_for_children))
            .filter(|s| !s.is_empty())
            .collect();

        if tag_name == "pre" || has_ancestor_tag(node, "pre") {
            // do not collapse newlines inside pre
        } else {
            let mut updated: Vec<String> = vec![String::new()];
            for child_string in child_strings.drain(..) {
                let (mut leading, content, trailing) = extract_newlines(&child_string);
                if !updated.last().unwrap().is_empty() && !leading.is_empty() {
                    let prev_trailing = updated.pop().unwrap();
                    let num_newlines =
                        std::cmp::min(2, std::cmp::max(prev_trailing.len(), leading.len()));
                    leading = "\n".repeat(num_newlines);
                }
                updated.push(leading);
                updated.push(content);
                updated.push(trailing);
            }
            child_strings = updated;
        }

        let mut text = child_strings.concat();

        if let Some(converted) = self.convert_tag(&tag_name, node, &text, parent_tags) {
            text = converted;
        }

        text
    }

    fn process_text(&self, node: NodeRef<'_, Node>, parent_tags: &HashSet<String>) -> String {
        let text = match node.value() {
            Node::Text(text) => text.text.to_string(),
            Node::ProcessingInstruction(pi) => pi.data.to_string(),
            _ => String::new(),
        };
        self.process_text_value(&text, node, parent_tags)
    }

    fn process_text_value(
        &self,
        text: &str,
        node: NodeRef<'_, Node>,
        parent_tags: &HashSet<String>,
    ) -> String {
        let mut text = text.to_string();
        if !parent_tags.contains("pre") {
            if self.options.wrap {
                text = RE_ALL_WHITESPACE.replace_all(&text, " ").to_string();
            } else {
                text = RE_NEWLINE_WHITESPACE.replace_all(&text, "\n").to_string();
                text = RE_WHITESPACE.replace_all(&text, " ").to_string();
            }
        }

        if !parent_tags.contains("_noformat") {
            text = self.escape(&text);
        }

        let prev = node.prev_sibling();
        let next = node.next_sibling();
        let parent = node.parent();
        let parent_name = parent.and_then(node_tag_name);

        if should_remove_whitespace_outside(prev)
            || (parent_name
                .as_deref()
                .map(should_remove_whitespace_inside)
                .unwrap_or(false)
                && prev.is_none())
        {
            text = lstrip_chars(&text, &[' ', '\t', '\r', '\n']);
        }

        if should_remove_whitespace_outside(next)
            || (parent_name
                .as_deref()
                .map(should_remove_whitespace_inside)
                .unwrap_or(false)
                && next.is_none())
        {
            text = rstrip_default(&text);
        }

        text
    }

    fn convert_tag(
        &self,
        tag_name: &str,
        node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> Option<String> {
        if !self.should_convert_tag(tag_name) {
            return None;
        }

        if !self.custom_converters.is_empty() {
            if let Some(custom) = self.custom_converters.get(&convert_fn_key(tag_name)) {
                return Some(custom(self, node, text, parent_tags));
            }
        }

        if let Some(level) = heading_level(tag_name) {
            if let Some(custom) = &self.custom_heading {
                return Some(custom(self, level, node, text, parent_tags));
            }
            return Some(self.convert_hn(level, node, text, parent_tags));
        }

        let converted = match tag_name {
            "[document]" => self.convert_document(text),
            "a" => self.convert_a(node, text, parent_tags),
            "b" => self.convert_b(node, text, parent_tags),
            "blockquote" => self.convert_blockquote(node, text, parent_tags),
            "br" => self.convert_br(node, text, parent_tags),
            "code" => self.convert_code(node, text, parent_tags),
            "del" => self.convert_del(node, text, parent_tags),
            "div" | "article" | "section" => self.convert_div(node, text, parent_tags),
            "em" => self.convert_em(node, text, parent_tags),
            "kbd" => self.convert_code(node, text, parent_tags),
            "dd" => self.convert_dd(node, text, parent_tags),
            "dl" => self.convert_div(node, text, parent_tags),
            "dt" => self.convert_dt(node, text, parent_tags),
            "hr" => self.convert_hr(node, text, parent_tags),
            "i" => self.convert_em(node, text, parent_tags),
            "img" => self.convert_img(node, text, parent_tags),
            "video" => self.convert_video(node, text, parent_tags),
            "ul" | "ol" => self.convert_list(node, text, parent_tags),
            "li" => self.convert_li(node, text, parent_tags),
            "p" => self.convert_p(node, text, parent_tags),
            "pre" => self.convert_pre(node, text, parent_tags),
            "q" => self.convert_q(node, text, parent_tags),
            "script" => self.convert_script(node, text, parent_tags),
            "style" => self.convert_style(node, text, parent_tags),
            "s" => self.convert_del(node, text, parent_tags),
            "strong" => self.convert_b(node, text, parent_tags),
            "samp" => self.convert_code(node, text, parent_tags),
            "sub" => self.convert_sub(node, text, parent_tags),
            "sup" => self.convert_sup(node, text, parent_tags),
            "table" => self.convert_table(node, text, parent_tags),
            "caption" => self.convert_caption(node, text, parent_tags),
            "figcaption" => self.convert_figcaption(node, text, parent_tags),
            "td" => self.convert_td(node, text, parent_tags),
            "th" => self.convert_th(node, text, parent_tags),
            "tr" => self.convert_tr(node, text, parent_tags),
            _ => return None,
        };

        Some(converted)
    }

    fn should_convert_tag(&self, tag: &str) -> bool {
        if let Some(strip) = &self.options.strip {
            !strip.contains(tag)
        } else if let Some(convert) = &self.options.convert {
            convert.contains(tag)
        } else {
            true
        }
    }

    fn escape(&self, text: &str) -> String {
        if text.is_empty() {
            return String::new();
        }

        let mut text = text.to_string();

        if self.options.escape_misc {
            text = RE_ESCAPE_MISC_CHARS.replace_all(&text, r"\$1").to_string();
            text = RE_ESCAPE_MISC_DASH.replace_all(&text, r"$1\$2").to_string();
            text = RE_ESCAPE_MISC_HASHES
                .replace_all(&text, r"$1\$2")
                .to_string();
            text = RE_ESCAPE_MISC_LIST_ITEMS
                .replace_all(&text, r"$1\$2")
                .to_string();
        }

        if self.options.escape_asterisks {
            text = text.replace('*', r"\*");
        }
        if self.options.escape_underscores {
            text = text.replace('_', r"\_");
        }

        text
    }

    fn underline(&self, text: &str, pad_char: char) -> String {
        let trimmed = text.trim_end();
        if trimmed.is_empty() {
            return String::new();
        }
        let len = trimmed.chars().count();
        format!("\n\n{}\n{}\n\n", trimmed, pad_char.to_string().repeat(len))
    }

    fn convert_document(&self, text: &str) -> String {
        match self.options.strip_document {
            StripMode::LStrip => text.trim_start_matches('\n').to_string(),
            StripMode::RStrip => text.trim_end_matches('\n').to_string(),
            StripMode::Strip => text.trim_matches('\n').to_string(),
            StripMode::None => text.to_string(),
        }
    }

    fn convert_a(
        &self,
        node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        if parent_tags.contains("_noformat") {
            return text.to_string();
        }

        let (prefix, suffix, inner) = chomp(text);
        if inner.is_empty() {
            return String::new();
        }

        let href = node_attr(node, "href").unwrap_or_default();
        let mut title = node_attr(node, "title").unwrap_or_default();

        if self.options.autolinks
            && inner.replace(r"\_", "_") == href
            && title.is_empty()
            && !self.options.default_title
        {
            return format!("<{}>", href);
        }

        if self.options.default_title && title.is_empty() {
            title = href.clone();
        }

        let title_part = if title.is_empty() {
            String::new()
        } else {
            format!(" \"{}\"", title.replace('"', r#"\""#))
        };

        if href.is_empty() {
            inner
        } else {
            format!("{prefix}[{inner}]({href}{title_part}){suffix}")
        }
    }

    fn convert_b(
        &self,
        _node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        let markup = self.options.strong_em_symbol.to_string().repeat(2);
        inline_wrap(text, parent_tags, &markup)
    }

    fn convert_blockquote(
        &self,
        _node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        let text = text.trim_matches(&[' ', '\t', '\r', '\n'][..]).to_string();
        if parent_tags.contains("_inline") {
            return format!(" {text} ");
        }
        if text.is_empty() {
            return "\n".to_string();
        }

        let indented = map_lines(&text, |line| {
            if line.is_empty() {
                ">".to_string()
            } else {
                format!("> {line}")
            }
        });

        format!("\n{indented}\n\n")
    }

    fn convert_br(
        &self,
        _node: NodeRef<'_, Node>,
        _text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        if parent_tags.contains("_inline") {
            return " ".to_string();
        }
        match self.options.newline_style {
            NewlineStyle::Backslash => "\\\n".to_string(),
            NewlineStyle::Spaces => "  \n".to_string(),
        }
    }

    fn convert_code(
        &self,
        _node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        if parent_tags.contains("_noformat") {
            return text.to_string();
        }

        let (prefix, suffix, inner) = chomp(text);
        if inner.is_empty() {
            return String::new();
        }

        let max_backticks = RE_BACKTICK_RUNS
            .find_iter(&inner)
            .map(|m| m.as_str().len())
            .max()
            .unwrap_or(0);
        let markup = "`".repeat(max_backticks + 1);
        let inner = if max_backticks > 0 {
            format!(" {inner} ")
        } else {
            inner
        };

        format!("{prefix}{markup}{inner}{markup}{suffix}")
    }

    fn convert_del(
        &self,
        _node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        inline_wrap(text, parent_tags, "~~")
    }

    fn convert_div(
        &self,
        _node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        if parent_tags.contains("_inline") {
            return format!(" {} ", text.trim());
        }
        let trimmed = text.trim();
        if trimmed.is_empty() {
            String::new()
        } else {
            format!("\n\n{trimmed}\n\n")
        }
    }

    fn convert_em(
        &self,
        _node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        let markup = self.options.strong_em_symbol.to_string();
        inline_wrap(text, parent_tags, &markup)
    }

    fn convert_dd(
        &self,
        _node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        let text = text.trim().to_string();
        if parent_tags.contains("_inline") {
            return format!(" {text} ");
        }
        if text.is_empty() {
            return "\n".to_string();
        }

        let indented = map_lines(&text, |line| {
            if line.is_empty() {
                String::new()
            } else {
                format!("    {line}")
            }
        });

        let rest = indented.chars().skip(1).collect::<String>();
        format!(":{}\n", rest)
    }

    fn convert_dt(
        &self,
        _node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        let mut text = text.trim().to_string();
        text = RE_ALL_WHITESPACE.replace_all(&text, " ").to_string();
        if parent_tags.contains("_inline") {
            return format!(" {text} ");
        }
        if text.is_empty() {
            return "\n".to_string();
        }
        format!("\n\n{text}\n")
    }

    fn convert_hn(
        &self,
        mut level: usize,
        _node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        if parent_tags.contains("_inline") {
            return text.to_string();
        }
        level = level.clamp(1, 6);

        let style = self.options.heading_style;
        let text = text.trim().to_string();
        if matches!(style, HeadingStyle::Underlined) && level <= 2 {
            let line = if level == 1 { '=' } else { '-' };
            return self.underline(&text, line);
        }

        let text = RE_ALL_WHITESPACE.replace_all(&text, " ").to_string();
        let hashes = "#".repeat(level);
        match style {
            HeadingStyle::AtxClosed => format!("\n\n{hashes} {text} {hashes}\n\n"),
            _ => format!("\n\n{hashes} {text}\n\n"),
        }
    }

    fn convert_hr(
        &self,
        _node: NodeRef<'_, Node>,
        _text: &str,
        _parent_tags: &HashSet<String>,
    ) -> String {
        "\n\n---\n\n".to_string()
    }

    pub fn convert_img(
        &self,
        node: NodeRef<'_, Node>,
        _text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        let alt = node_attr(node, "alt").unwrap_or_default();
        let src = node_attr(node, "src").unwrap_or_default();
        let title = node_attr(node, "title").unwrap_or_default();
        let title_part = if title.is_empty() {
            String::new()
        } else {
            format!(" \"{}\"", title.replace('"', r#"\""#))
        };

        if parent_tags.contains("_inline") {
            if let Some(parent) = node.parent().and_then(node_tag_name) {
                if !self.options.keep_inline_images_in.contains(&parent) {
                    return alt;
                }
            } else if !self.options.keep_inline_images_in.contains("") {
                return alt;
            }
        }

        format!("![{alt}]({src}{title_part})")
    }

    fn convert_video(
        &self,
        node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        if parent_tags.contains("_inline") {
            if let Some(parent) = node.parent().and_then(node_tag_name) {
                if !self.options.keep_inline_images_in.contains(&parent) {
                    return text.to_string();
                }
            } else if !self.options.keep_inline_images_in.contains("") {
                return text.to_string();
            }
        }

        let mut src = node_attr(node, "src").unwrap_or_default();
        if src.is_empty() {
            if let Some(found) = find_first_descendant_with_attr(node, "source", "src") {
                src = found;
            }
        }
        let poster = node_attr(node, "poster").unwrap_or_default();

        if !src.is_empty() && !poster.is_empty() {
            format!("[![{text}]({poster})]({src})")
        } else if !src.is_empty() {
            format!("[{text}]({src})")
        } else if !poster.is_empty() {
            format!("![{text}]({poster})")
        } else {
            text.to_string()
        }
    }

    fn convert_list(
        &self,
        node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        let mut before_paragraph = false;
        if let Some(next) = next_block_content_sibling(node) {
            let name = node_tag_name(next).unwrap_or_default();
            if name != "ul" && name != "ol" {
                before_paragraph = true;
            }
        }

        if parent_tags.contains("li") {
            return format!("\n{}", text.trim_end());
        }

        let mut output = format!("\n\n{text}");
        if before_paragraph {
            output.push('\n');
        }
        output
    }

    fn convert_li(
        &self,
        node: NodeRef<'_, Node>,
        text: &str,
        _parent_tags: &HashSet<String>,
    ) -> String {
        let text = text.trim().to_string();
        if text.is_empty() {
            return "\n".to_string();
        }

        let mut bullet = String::new();
        if let Some(list_node) = nearest_list_ancestor(node) {
            if node_tag_name(list_node).as_deref() == Some("ol") {
                let start = ordered_list_start(list_node).unwrap_or(1);
                let prev_count = count_list_items_before(list_node, node);
                bullet = format!("{}.", start + prev_count);
            }
        }

        if bullet.is_empty() {
            let mut depth = -1;
            let mut current = Some(node);
            while let Some(ref n) = current {
                if node_tag_name(*n).as_deref() == Some("ul") {
                    depth += 1;
                }
                current = n.parent();
            }
            let bullets = self.options.bullets.chars().collect::<Vec<char>>();
            let len = bullets.len() as isize;
            let idx = ((depth % len) + len) % len;
            bullet = bullets[idx as usize].to_string();
        }

        bullet.push(' ');
        let bullet_width = bullet.chars().count();
        let bullet_indent = " ".repeat(bullet_width);

        let indented = map_lines(&text, |line| {
            if line.is_empty() {
                String::new()
            } else {
                format!("{bullet_indent}{line}")
            }
        });

        let rest = indented.chars().skip(bullet_width).collect::<String>();
        format!("{bullet}{rest}\n")
    }

    fn convert_p(
        &self,
        _node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        if parent_tags.contains("_inline") {
            let trimmed = text.trim_matches(&[' ', '\t', '\r', '\n'][..]);
            return format!(" {trimmed} ");
        }

        let mut text = text.trim_matches(&[' ', '\t', '\r', '\n'][..]).to_string();
        if self.options.wrap {
            if let Some(width) = self.options.wrap_width {
                let lines: Vec<String> = text
                    .split('\n')
                    .map(|line| {
                        let line = lstrip_chars(line, &[' ', '\t', '\r', '\n']);
                        let line_no_trailing = line.trim_end_matches(char::is_whitespace);
                        let trailing = &line[line_no_trailing.len()..];
                        let wrapped = textwrap::fill(
                            &line,
                            WrapOptions::new(width)
                                .break_words(false)
                                .word_separator(WordSeparator::AsciiSpace)
                                .word_splitter(WordSplitter::NoHyphenation),
                        );
                        format!("{wrapped}{trailing}")
                    })
                    .collect();
                text = lines.join("\n");
            }
        }

        if text.is_empty() {
            String::new()
        } else {
            format!("\n\n{text}\n\n")
        }
    }

    fn convert_pre(
        &self,
        node: NodeRef<'_, Node>,
        text: &str,
        _parent_tags: &HashSet<String>,
    ) -> String {
        if text.is_empty() {
            return String::new();
        }

        let mut code_language = self.options.code_language.clone();
        if let Some(callback) = &self.options.code_language_callback {
            if let Some(result) = callback(node) {
                if !result.is_empty() {
                    code_language = result;
                }
            }
        }

        let mut text = text.to_string();
        match self.options.strip_pre {
            StripPreMode::Strip => {
                text = strip_pre(&text);
            }
            StripPreMode::StripOne => {
                text = strip1_pre(&text);
            }
            StripPreMode::None => {}
        }

        format!("\n\n```{code_language}\n{text}\n```\n\n")
    }

    fn convert_q(
        &self,
        _node: NodeRef<'_, Node>,
        text: &str,
        _parent_tags: &HashSet<String>,
    ) -> String {
        format!("\"{text}\"")
    }

    fn convert_script(
        &self,
        _node: NodeRef<'_, Node>,
        _text: &str,
        _parent_tags: &HashSet<String>,
    ) -> String {
        String::new()
    }

    fn convert_style(
        &self,
        _node: NodeRef<'_, Node>,
        _text: &str,
        _parent_tags: &HashSet<String>,
    ) -> String {
        String::new()
    }

    fn convert_sub(
        &self,
        _node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        inline_wrap(text, parent_tags, &self.options.sub_symbol)
    }

    fn convert_sup(
        &self,
        _node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        inline_wrap(text, parent_tags, &self.options.sup_symbol)
    }

    fn convert_table(
        &self,
        _node: NodeRef<'_, Node>,
        text: &str,
        _parent_tags: &HashSet<String>,
    ) -> String {
        format!("\n\n{}\n\n", text.trim())
    }

    fn convert_caption(
        &self,
        _node: NodeRef<'_, Node>,
        text: &str,
        _parent_tags: &HashSet<String>,
    ) -> String {
        format!("{}\n\n", text.trim())
    }

    fn convert_figcaption(
        &self,
        _node: NodeRef<'_, Node>,
        text: &str,
        _parent_tags: &HashSet<String>,
    ) -> String {
        format!("\n\n{}\n\n", text.trim())
    }

    fn convert_td(
        &self,
        node: NodeRef<'_, Node>,
        text: &str,
        _parent_tags: &HashSet<String>,
    ) -> String {
        let colspan = node_attr(node, "colspan")
            .and_then(parse_colspan)
            .unwrap_or(1);
        let cell = text.trim().replace('\n', " ");
        let mut out = String::new();
        out.push(' ');
        out.push_str(&cell);
        for _ in 0..colspan {
            out.push_str(" |");
        }
        out
    }

    fn convert_th(
        &self,
        node: NodeRef<'_, Node>,
        text: &str,
        parent_tags: &HashSet<String>,
    ) -> String {
        self.convert_td(node, text, parent_tags)
    }

    fn convert_tr(
        &self,
        node: NodeRef<'_, Node>,
        text: &str,
        _parent_tags: &HashSet<String>,
    ) -> String {
        let cells = find_all(node, &["td", "th"]);
        let is_first_row = previous_element_sibling(node).is_none();

        let is_headrow = cells
            .iter()
            .all(|cell| node_tag_name(*cell).as_deref() == Some("th"))
            || (node.parent().and_then(node_tag_name).as_deref() == Some("thead")
                && node
                    .parent()
                    .map(|p| find_all(p, &["tr"]).len() == 1)
                    .unwrap_or(false));

        let is_head_row_missing = (is_first_row
            && node.parent().and_then(node_tag_name).as_deref() != Some("tbody"))
            || (is_first_row
                && node.parent().and_then(node_tag_name).as_deref() == Some("tbody")
                && node
                    .parent()
                    .and_then(|p| p.parent())
                    .map(|p| find_all(p, &["thead"]).len() < 1)
                    .unwrap_or(true));

        let mut full_colspan = 0usize;
        for cell in &cells {
            let span = node_attr(*cell, "colspan")
                .and_then(parse_colspan)
                .unwrap_or(1);
            full_colspan += span;
        }
        let mut overline = String::new();
        let mut underline = String::new();

        if (is_headrow || (is_head_row_missing && self.options.table_infer_header)) && is_first_row
        {
            let dashes = vec!["---"; full_colspan].join(" | ");
            underline = format!("| {dashes} |\n");
        } else if (is_head_row_missing && !self.options.table_infer_header)
            || (is_first_row
                && (node.parent().and_then(node_tag_name).as_deref() == Some("table")
                    || (node.parent().and_then(node_tag_name).as_deref() == Some("tbody")
                        && node.parent().and_then(previous_element_sibling).is_none())))
        {
            let blanks = vec![""; full_colspan].join(" | ");
            let dashes = vec!["---"; full_colspan].join(" | ");
            overline = format!("| {blanks} |\n| {dashes} |\n");
        }

        format!("{overline}|{text}\n{underline}")
    }
}

pub fn markdownify(html: &str) -> String {
    MarkdownConverter::new(Options::default()).convert(html)
}

pub fn markdownify_batch(htmls: Vec<String>) -> Vec<String> {
    markdownify_batch_with_options(htmls, Options::default())
}

pub fn markdownify_batch_with_options(htmls: Vec<String>, options: Options) -> Vec<String> {
    htmls
        .into_par_iter()
        .map_init(
            || MarkdownConverter::new(options.clone()),
            |converter, html| converter.convert(&html),
        )
        .collect()
}

pub fn markdown_to_html(markdown: &str) -> String {
    markdown_to_html::markdown_to_html(markdown)
}

pub fn markdown_to_html_batch(markdowns: Vec<String>) -> Vec<String> {
    markdown_to_html::markdown_to_html_batch(markdowns)
}

pub mod markdown_to_html;
pub mod markdown_utils;
pub mod xml_utils;

#[cfg(feature = "python")]
mod python;

fn apply_br_quirk<'a>(html: &'a str) -> Cow<'a, str> {
    // NOTE: BeautifulSoup + html.parser has a quirk: if a non-self-closing
    // <br> appears before a self-closing <br/>/<br />, the later <br/>
    // is treated like an opening <br> tag whose contents run until the
    // <br> is closed (typically when its parent closes). markdownify then
    // drops those children. We emulate that behavior by removing the
    // content between the self-closing <br/> and the closing tag that
    // would end that implicit <br>. This is parity-first and can be
    // revisited for correctness once the baseline is stable.
    let bytes = html.as_bytes();
    let mut i = 0usize;
    let mut bare_br_count = 0usize;
    let mut dropping = false;
    let mut drop_start = 0usize;
    let mut drop_br_depth: Option<usize> = None;
    let mut last_keep = 0usize;
    let mut out: Option<String> = None;
    let mut raw_tag: Option<&'static [u8]> = None;

    #[derive(Copy, Clone)]
    struct StackEntry {
        name_start: usize,
        name_end: usize,
        is_br: bool,
    }

    let mut stack: Vec<StackEntry> = Vec::new();

    while i < bytes.len() {
        if let Some(tag) = raw_tag {
            if bytes[i] == b'<' && bytes.get(i + 1) == Some(&b'/') {
                let name_start = i + 2;
                if name_start + tag.len() <= bytes.len()
                    && eq_ignore_ascii_case(&bytes[name_start..name_start + tag.len()], tag)
                {
                    let mut j = name_start + tag.len();
                    while j < bytes.len() && bytes[j] != b'>' {
                        j += 1;
                    }
                    if j < bytes.len() {
                        if let Some(pos) = stack.iter().rposition(|entry| {
                            (entry.is_br && tag == b"br")
                                || (!entry.is_br
                                    && eq_ignore_ascii_case(
                                        &bytes[entry.name_start..entry.name_end],
                                        tag,
                                    ))
                        }) {
                            stack.truncate(pos);
                            stack.pop();
                        }
                        if dropping {
                            if let Some(depth) = drop_br_depth {
                                if stack.len() < depth {
                                    dropping = false;
                                    drop_br_depth = None;
                                    last_keep = i;
                                }
                            }
                        }
                        raw_tag = None;
                        i = j + 1;
                        continue;
                    }
                }
            }
            i += 1;
            continue;
        }

        if bytes[i] == b'<' {
            if bytes.get(i + 1) == Some(&b'!') {
                if bytes.get(i + 2) == Some(&b'-') && bytes.get(i + 3) == Some(&b'-') {
                    let mut j = i + 4;
                    while j + 2 < bytes.len() {
                        if bytes[j] == b'-' && bytes[j + 1] == b'-' && bytes[j + 2] == b'>' {
                            i = j + 3;
                            break;
                        }
                        j += 1;
                    }
                    if j + 2 >= bytes.len() {
                        break;
                    }
                    continue;
                }

                let mut j = i + 2;
                while j < bytes.len() && bytes[j] != b'>' {
                    j += 1;
                }
                if j < bytes.len() {
                    i = j + 1;
                    continue;
                }
                break;
            }

            if bytes.get(i + 1) == Some(&b'?') {
                let mut j = i + 2;
                while j < bytes.len() && bytes[j] != b'>' {
                    j += 1;
                }
                if j < bytes.len() {
                    i = j + 1;
                    continue;
                }
                break;
            }

            let tag_start = i;
            let mut j = i + 1;
            let mut is_end = false;
            if bytes.get(j) == Some(&b'/') {
                is_end = true;
                j += 1;
            }
            while j < bytes.len() && is_ascii_whitespace(bytes[j]) {
                j += 1;
            }
            let name_start = j;
            while j < bytes.len() && is_ascii_tag_char(bytes[j]) {
                j += 1;
            }
            let name = &bytes[name_start..j];

            let mut quote = 0u8;
            while j < bytes.len() {
                let b = bytes[j];
                if quote == 0 {
                    if b == b'\'' || b == b'"' {
                        quote = b;
                    } else if b == b'>' {
                        break;
                    }
                } else if b == quote {
                    quote = 0;
                }
                j += 1;
            }
            if j >= bytes.len() {
                break;
            }

            let mut k = j;
            while k > name_start && is_ascii_whitespace(bytes[k - 1]) {
                k -= 1;
            }
            let is_self_closing = !is_end && k > name_start && bytes[k - 1] == b'/';
            let is_void = is_void_tag(name);
            let tag_end = j + 1;

            if !is_end
                && (eq_ignore_ascii_case(name, b"script") || eq_ignore_ascii_case(name, b"style"))
                && !is_self_closing
                && !is_void
            {
                stack.push(StackEntry {
                    name_start,
                    name_end: j,
                    is_br: false,
                });
                raw_tag = if eq_ignore_ascii_case(name, b"script") {
                    Some(b"script")
                } else {
                    Some(b"style")
                };
                i = tag_end;
                continue;
            }

            if is_end {
                if eq_ignore_ascii_case(name, b"br") && bare_br_count > 0 {
                    bare_br_count -= 1;
                }

                if !name.is_empty() {
                    if let Some(pos) = stack.iter().rposition(|entry| {
                        if entry.is_br {
                            eq_ignore_ascii_case(name, b"br")
                        } else {
                            eq_ignore_ascii_case(&bytes[entry.name_start..entry.name_end], name)
                        }
                    }) {
                        stack.truncate(pos);
                        stack.pop();
                    }
                }

                if dropping {
                    if let Some(depth) = drop_br_depth {
                        if stack.len() < depth {
                            dropping = false;
                            drop_br_depth = None;
                            if eq_ignore_ascii_case(name, b"br") {
                                last_keep = tag_end;
                            } else {
                                last_keep = tag_start;
                            }
                        }
                    }
                }

                i = tag_end;
                continue;
            }

            if eq_ignore_ascii_case(name, b"br") {
                if is_self_closing {
                    if bare_br_count > 0 {
                        bare_br_count -= 1;
                        if !dropping {
                            dropping = true;
                            drop_start = tag_end;
                            let out = out.get_or_insert_with(|| String::with_capacity(html.len()));
                            out.push_str(&html[last_keep..drop_start]);
                            last_keep = drop_start;
                            stack.push(StackEntry {
                                name_start: 0,
                                name_end: 0,
                                is_br: true,
                            });
                            drop_br_depth = Some(stack.len());
                        } else {
                            stack.push(StackEntry {
                                name_start: 0,
                                name_end: 0,
                                is_br: true,
                            });
                        }
                    }
                } else {
                    bare_br_count += 1;
                }
            } else if !is_self_closing && !is_void && !name.is_empty() {
                stack.push(StackEntry {
                    name_start,
                    name_end: j,
                    is_br: false,
                });
            }

            i = tag_end;
            continue;
        }
        i += 1;
    }

    if dropping {
        if let Some(out) = out {
            return Cow::Owned(out);
        }
        return Cow::Borrowed(&html[..drop_start]);
    }

    if let Some(mut out) = out {
        out.push_str(&html[last_keep..]);
        return Cow::Owned(out);
    }

    Cow::Borrowed(html)
}

fn leading_whitespace_prefix(html: &str) -> String {
    // NOTE: BeautifulSoup's html.parser preserves leading whitespace-only
    // text nodes in a few places that html5ever drops. We reconstruct the
    // leading whitespace prefix (after markdownify normalization) so the
    // final output matches python-markdownify once strip_document is applied.
    let bytes = html.as_bytes();
    let mut i = 0usize;
    let mut depth = 0usize;
    let mut body_depth: Option<usize> = None;
    let mut body_leading = false;
    let mut text_start: Option<usize> = None;
    let mut prefix = String::new();
    let mut raw_tag: Option<&'static [u8]> = None;

    while i < bytes.len() {
        if let Some(tag) = raw_tag {
            if bytes[i] == b'<' && bytes.get(i + 1) == Some(&b'/') {
                let name_start = i + 2;
                if name_start + tag.len() <= bytes.len()
                    && eq_ignore_ascii_case(&bytes[name_start..name_start + tag.len()], tag)
                {
                    let mut j = name_start + tag.len();
                    while j < bytes.len() && bytes[j] != b'>' {
                        j += 1;
                    }
                    if j < bytes.len() {
                        if depth > 1 {
                            depth -= 1;
                        }
                        raw_tag = None;
                        i = j + 1;
                        continue;
                    }
                }
            }
            i += 1;
            continue;
        }

        if bytes[i] == b'<' {
            if bytes.get(i + 3) == Some(&b'-')
                && bytes.get(i + 2) == Some(&b'-')
                && bytes.get(i + 1) == Some(&b'!')
            {
                if let Some(start) = text_start.take() {
                    let segment = &bytes[start..i];
                    if depth == 1 && is_whitespace_only(segment) {
                        prefix.push_str(&normalize_whitespace_segment(segment));
                    }
                    if body_leading && body_depth == Some(depth) {
                        if is_whitespace_only(segment) {
                            prefix.push_str(&normalize_whitespace_segment(segment));
                        } else {
                            body_leading = false;
                        }
                    }
                }
                let mut j = i + 4;
                while j + 2 < bytes.len() {
                    if bytes[j] == b'-' && bytes[j + 1] == b'-' && bytes[j + 2] == b'>' {
                        i = j + 3;
                        break;
                    }
                    j += 1;
                }
                if j + 2 >= bytes.len() {
                    break;
                }
                continue;
            }

            if bytes.get(i + 1) == Some(&b'!') || bytes.get(i + 1) == Some(&b'?') {
                if let Some(start) = text_start.take() {
                    let segment = &bytes[start..i];
                    if depth == 1 && is_whitespace_only(segment) {
                        prefix.push_str(&normalize_whitespace_segment(segment));
                    }
                    if body_leading && body_depth == Some(depth) {
                        if is_whitespace_only(segment) {
                            prefix.push_str(&normalize_whitespace_segment(segment));
                        } else {
                            body_leading = false;
                        }
                    }
                }
                let mut j = i + 2;
                while j < bytes.len() && bytes[j] != b'>' {
                    j += 1;
                }
                if j < bytes.len() {
                    i = j + 1;
                    continue;
                }
                break;
            }

            let mut j = i + 1;
            let mut is_end = false;
            if bytes.get(j) == Some(&b'/') {
                is_end = true;
                j += 1;
            }
            while j < bytes.len() && is_ascii_whitespace(bytes[j]) {
                j += 1;
            }
            let name_start = j;
            while j < bytes.len() && is_ascii_tag_char(bytes[j]) {
                j += 1;
            }
            let name = &bytes[name_start..j];

            let next_is_block = !is_end && is_block_whitespace_stripping_tag(name);
            let next_should_count_body = is_end || !next_is_block;
            let at_body_depth = body_leading && body_depth == Some(depth);

            let mut quote = 0u8;
            while j < bytes.len() {
                let b = bytes[j];
                if quote == 0 {
                    if b == b'\'' || b == b'"' {
                        quote = b;
                    } else if b == b'>' {
                        break;
                    }
                } else if b == quote {
                    quote = 0;
                }
                j += 1;
            }
            if j >= bytes.len() {
                break;
            }
            let tag_end = j + 1;

            if let Some(start) = text_start.take() {
                let segment = &bytes[start..i];
                if depth == 1 && is_whitespace_only(segment) {
                    prefix.push_str(&normalize_whitespace_segment(segment));
                }
                if body_leading && body_depth == Some(depth) {
                    if is_whitespace_only(segment) {
                        if next_should_count_body {
                            prefix.push_str(&normalize_whitespace_segment(segment));
                        }
                    } else {
                        body_leading = false;
                    }
                }
            }

            let mut k = j;
            while k > name_start && is_ascii_whitespace(bytes[k - 1]) {
                k -= 1;
            }
            let is_self_closing = k > name_start && bytes[k - 1] == b'/';
            let is_void = is_void_tag(name);

            if !is_end {
                if eq_ignore_ascii_case(name, b"html") {
                    if depth == 0 {
                        depth = 1;
                    } else if !is_self_closing && !is_void {
                        depth += 1;
                    }
                } else if depth > 0 && !is_self_closing && !is_void {
                    depth += 1;
                }

                if eq_ignore_ascii_case(name, b"body") && !is_self_closing && !is_void {
                    body_depth = Some(depth);
                    body_leading = true;
                } else if at_body_depth && !is_leading_ignorable_tag(name, is_self_closing, is_void)
                {
                    let is_custom = name.iter().any(|&b| b == b'-');
                    if !is_custom || !is_empty_custom_element(bytes, name, tag_end) {
                        body_leading = false;
                    }
                }

                if depth > 0
                    && !is_self_closing
                    && (eq_ignore_ascii_case(name, b"script")
                        || eq_ignore_ascii_case(name, b"style"))
                {
                    raw_tag = if eq_ignore_ascii_case(name, b"script") {
                        Some(b"script")
                    } else {
                        Some(b"style")
                    };
                }
            } else {
                if eq_ignore_ascii_case(name, b"html") {
                    depth = 0;
                } else if depth > 1 {
                    depth -= 1;
                }
                if eq_ignore_ascii_case(name, b"body") {
                    body_depth = None;
                    body_leading = false;
                }
                if eq_ignore_ascii_case(name, b"script") || eq_ignore_ascii_case(name, b"style") {
                    raw_tag = None;
                }
            }

            i = j + 1;
            continue;
        }

        if text_start.is_none() {
            text_start = Some(i);
        }
        i += 1;
    }

    if let Some(start) = text_start {
        let segment = &bytes[start..];
        if depth == 1 && is_whitespace_only(segment) {
            prefix.push_str(&normalize_whitespace_segment(segment));
        }
        if body_leading && body_depth == Some(depth) && is_whitespace_only(segment) {
            prefix.push_str(&normalize_whitespace_segment(segment));
        }
    }

    prefix
}

fn is_empty_custom_element(bytes: &[u8], name: &[u8], mut i: usize) -> bool {
    while i < bytes.len() {
        if bytes[i] == b'<' {
            if bytes.get(i + 1) == Some(&b'!') {
                if bytes.get(i + 2) == Some(&b'-') && bytes.get(i + 3) == Some(&b'-') {
                    let mut j = i + 4;
                    while j + 2 < bytes.len() {
                        if bytes[j] == b'-' && bytes[j + 1] == b'-' && bytes[j + 2] == b'>' {
                            i = j + 3;
                            break;
                        }
                        j += 1;
                    }
                    if j + 2 >= bytes.len() {
                        return false;
                    }
                    continue;
                }
                return false;
            }

            if bytes.get(i + 1) == Some(&b'/') {
                let mut j = i + 2;
                while j < bytes.len() && is_ascii_whitespace(bytes[j]) {
                    j += 1;
                }
                let name_start = j;
                while j < bytes.len() && is_ascii_tag_char(bytes[j]) {
                    j += 1;
                }
                let close_name = &bytes[name_start..j];
                while j < bytes.len() && bytes[j] != b'>' {
                    j += 1;
                }
                if j >= bytes.len() {
                    return false;
                }
                return eq_ignore_ascii_case(close_name, name);
            }

            return false;
        }

        if !is_ascii_whitespace(bytes[i]) {
            return false;
        }
        i += 1;
    }
    false
}

fn is_whitespace_only(bytes: &[u8]) -> bool {
    if bytes.is_empty() {
        return false;
    }
    for &b in bytes {
        if is_ascii_whitespace(b) {
            continue;
        }
        return false;
    }
    true
}

fn normalize_whitespace_segment(segment: &[u8]) -> String {
    let raw = std::str::from_utf8(segment).unwrap_or("");
    let normalized = RE_NEWLINE_WHITESPACE.replace_all(raw, "\n");
    RE_WHITESPACE.replace_all(&normalized, " ").to_string()
}

fn common_prefix_len(a: &str, b: &str) -> usize {
    let mut len = 0usize;
    let mut a_iter = a.char_indices();
    let mut b_iter = b.char_indices();
    loop {
        match (a_iter.next(), b_iter.next()) {
            (Some((a_idx, a_ch)), Some((_b_idx, b_ch))) if a_ch == b_ch => {
                len = a_idx + a_ch.len_utf8();
            }
            _ => break,
        }
    }
    len
}

fn is_block_whitespace_stripping_tag(name: &[u8]) -> bool {
    if is_heading_tag_bytes(name) {
        return true;
    }
    eq_ignore_ascii_case(name, b"p")
        || eq_ignore_ascii_case(name, b"blockquote")
        || eq_ignore_ascii_case(name, b"article")
        || eq_ignore_ascii_case(name, b"div")
        || eq_ignore_ascii_case(name, b"section")
        || eq_ignore_ascii_case(name, b"ol")
        || eq_ignore_ascii_case(name, b"ul")
        || eq_ignore_ascii_case(name, b"li")
        || eq_ignore_ascii_case(name, b"dl")
        || eq_ignore_ascii_case(name, b"dt")
        || eq_ignore_ascii_case(name, b"dd")
        || eq_ignore_ascii_case(name, b"table")
        || eq_ignore_ascii_case(name, b"thead")
        || eq_ignore_ascii_case(name, b"tbody")
        || eq_ignore_ascii_case(name, b"tfoot")
        || eq_ignore_ascii_case(name, b"tr")
        || eq_ignore_ascii_case(name, b"td")
        || eq_ignore_ascii_case(name, b"th")
        || eq_ignore_ascii_case(name, b"pre")
}

fn is_leading_ignorable_tag(name: &[u8], is_self_closing: bool, is_void: bool) -> bool {
    if eq_ignore_ascii_case(name, b"script") || eq_ignore_ascii_case(name, b"style") {
        return true;
    }
    if (is_self_closing || is_void)
        && !eq_ignore_ascii_case(name, b"br")
        && !eq_ignore_ascii_case(name, b"hr")
        && !eq_ignore_ascii_case(name, b"img")
    {
        return true;
    }
    false
}

fn is_heading_tag_bytes(name: &[u8]) -> bool {
    if name.len() != 2 {
        return false;
    }
    let first = name[0].to_ascii_lowercase();
    let second = name[1];
    first == b'h' && matches!(second, b'1' | b'2' | b'3' | b'4' | b'5' | b'6')
}

#[cfg(test)]
mod leading_ws_tests {
    use super::leading_whitespace_prefix;

    #[test]
    fn preserves_html_then_body_whitespace_order() {
        let html = "<!DOCTYPE html><html>\n<body> <!--c--><h3>Hi</h3></body></html>";
        assert_eq!(leading_whitespace_prefix(html), "\n ");
    }

    #[test]
    fn preserves_whitespace_across_empty_custom_elements() {
        let html = "<html> <body> <x-foo><!--c--></x-foo> <x-bar><!--d--></x-bar> <div>Hi</div></body></html>";
        assert_eq!(leading_whitespace_prefix(html), "   ");
    }
}

#[cfg(test)]
mod batch_tests {
    use super::{MarkdownConverter, Options, markdownify_batch_with_options};

    #[test]
    fn batch_matches_single() {
        let options = Options::default();
        let htmls = vec![
            "<b>Hello</b>".to_string(),
            "<i>World</i>".to_string(),
            "<p>Para</p>".to_string(),
        ];
        let single = htmls
            .iter()
            .map(|html| MarkdownConverter::new(options.clone()).convert(html))
            .collect::<Vec<_>>();
        let batch = markdownify_batch_with_options(htmls, options);
        assert_eq!(batch, single);
    }
}

fn eq_ignore_ascii_case(left: &[u8], right: &[u8]) -> bool {
    if left.len() != right.len() {
        return false;
    }
    left.iter()
        .zip(right.iter())
        .all(|(a, b)| a.to_ascii_lowercase() == b.to_ascii_lowercase())
}

fn starts_with_ascii_case_insensitive(haystack: &[u8], needle: &[u8]) -> bool {
    if needle.len() > haystack.len() {
        return false;
    }
    eq_ignore_ascii_case(&haystack[..needle.len()], needle)
}

fn contains_ascii_case_insensitive(haystack: &[u8], needle: &[u8]) -> bool {
    if needle.is_empty() {
        return true;
    }
    if needle.len() > haystack.len() {
        return false;
    }
    let end = haystack.len() - needle.len();
    for i in 0..=end {
        if eq_ignore_ascii_case(&haystack[i..i + needle.len()], needle) {
            return true;
        }
    }
    false
}

fn is_ascii_whitespace(byte: u8) -> bool {
    matches!(byte, b' ' | b'\t' | b'\r' | b'\n' | 0x0c)
}

fn is_ascii_tag_char(byte: u8) -> bool {
    byte.is_ascii_alphanumeric() || byte == b':' || byte == b'-' || byte == b'_'
}

fn is_void_tag(name: &[u8]) -> bool {
    eq_ignore_ascii_case(name, b"area")
        || eq_ignore_ascii_case(name, b"base")
        || eq_ignore_ascii_case(name, b"br")
        || eq_ignore_ascii_case(name, b"col")
        || eq_ignore_ascii_case(name, b"embed")
        || eq_ignore_ascii_case(name, b"hr")
        || eq_ignore_ascii_case(name, b"img")
        || eq_ignore_ascii_case(name, b"input")
        || eq_ignore_ascii_case(name, b"link")
        || eq_ignore_ascii_case(name, b"meta")
        || eq_ignore_ascii_case(name, b"param")
        || eq_ignore_ascii_case(name, b"source")
        || eq_ignore_ascii_case(name, b"track")
        || eq_ignore_ascii_case(name, b"wbr")
}

fn convert_fn_key(tag_name: &str) -> String {
    RE_MAKE_CONVERT_FN_NAME
        .replace_all(&tag_name.to_ascii_lowercase(), "_")
        .to_string()
}

fn node_tag_name(node: NodeRef<'_, Node>) -> Option<String> {
    match node.value() {
        Node::Element(el) => Some(el.name().to_string()),
        Node::Document | Node::Fragment => Some("[document]".to_string()),
        _ => None,
    }
}

fn node_attr(node: NodeRef<'_, Node>, attr: &str) -> Option<String> {
    node.value()
        .as_element()
        .and_then(|el| el.attr(attr))
        .map(|v| v.to_string())
}

fn parse_colspan(value: String) -> Option<usize> {
    if value.chars().all(|c| c.is_ascii_digit()) {
        value.parse::<usize>().ok().map(|n| n.clamp(1, 1000))
    } else {
        None
    }
}

fn is_heading_tag(tag_name: &str) -> bool {
    heading_level(tag_name).is_some()
}

fn heading_level(tag_name: &str) -> Option<usize> {
    let mut chars = tag_name.chars();
    if chars.next()? != 'h' {
        return None;
    }
    let digits: String = chars.collect();
    if digits.is_empty() || !digits.chars().all(|c| c.is_ascii_digit()) {
        return None;
    }
    digits.parse::<usize>().ok()
}

fn should_remove_whitespace_inside(tag_name: &str) -> bool {
    if is_heading_tag(tag_name) {
        return true;
    }
    matches!(
        tag_name,
        "p" | "blockquote"
            | "article"
            | "div"
            | "section"
            | "ol"
            | "ul"
            | "li"
            | "dl"
            | "dt"
            | "dd"
            | "table"
            | "thead"
            | "tbody"
            | "tfoot"
            | "tr"
            | "td"
            | "th"
    )
}

fn should_remove_whitespace_outside(node: Option<NodeRef<'_, Node>>) -> bool {
    node.and_then(node_tag_name)
        .map(|name| should_remove_whitespace_inside(&name) || name == "pre")
        .unwrap_or(false)
}

fn is_block_content_element(node: NodeRef<'_, Node>) -> bool {
    match node.value() {
        Node::Element(_) => true,
        Node::Comment(_) | Node::Doctype(_) => false,
        Node::Text(text) => !text.text.trim().is_empty(),
        Node::ProcessingInstruction(pi) => !pi.data.trim().is_empty(),
        Node::Document | Node::Fragment => true,
    }
}

fn next_block_content_sibling(mut node: NodeRef<'_, Node>) -> Option<NodeRef<'_, Node>> {
    while let Some(next) = node.next_sibling() {
        if is_block_content_element(next) {
            return Some(next);
        }
        node = next;
    }
    None
}

fn can_ignore(node: NodeRef<'_, Node>, should_remove_inside: bool) -> bool {
    match node.value() {
        Node::Element(_) => false,
        Node::Comment(comment) => extract_cdata(comment).is_none(),
        Node::Doctype(_) => true,
        Node::Text(text) => {
            if !text.text.trim().is_empty() {
                false
            } else if should_remove_inside
                && (node.prev_sibling().is_none() || node.next_sibling().is_none())
            {
                true
            } else if should_remove_whitespace_outside(node.prev_sibling())
                || should_remove_whitespace_outside(node.next_sibling())
            {
                true
            } else {
                false
            }
        }
        Node::ProcessingInstruction(pi) => pi.data.trim().is_empty(),
        Node::Document | Node::Fragment => false,
    }
}

fn has_ancestor_tag(node: NodeRef<'_, Node>, tag: &str) -> bool {
    let mut current = node.parent();
    while let Some(node) = current {
        if node_tag_name(node).as_deref() == Some(tag) {
            return true;
        }
        current = node.parent();
    }
    false
}

fn previous_element_sibling(node: NodeRef<'_, Node>) -> Option<NodeRef<'_, Node>> {
    let mut current = node.prev_sibling();
    while let Some(sibling) = current {
        if sibling.value().is_element() {
            return Some(sibling);
        }
        current = sibling.prev_sibling();
    }
    None
}

fn nearest_list_ancestor(node: NodeRef<'_, Node>) -> Option<NodeRef<'_, Node>> {
    let mut current = node.parent();
    while let Some(n) = current {
        match node_tag_name(n).as_deref() {
            Some("ol") | Some("ul") => return Some(n),
            _ => {}
        }
        current = n.parent();
    }
    None
}

fn ordered_list_start(node: NodeRef<'_, Node>) -> Option<usize> {
    let value = node_attr(node, "start")?;
    if value.chars().all(|c| c.is_ascii_digit()) {
        value.parse::<usize>().ok()
    } else {
        None
    }
}

fn count_list_items_before(list_node: NodeRef<'_, Node>, target: NodeRef<'_, Node>) -> usize {
    let mut count = 0;
    for descendant in list_node.descendants() {
        if descendant == list_node {
            continue;
        }
        if node_tag_name(descendant).as_deref() == Some("li")
            && nearest_list_ancestor(descendant) == Some(list_node)
        {
            if descendant == target {
                break;
            }
            count += 1;
        }
    }
    count
}

fn find_all<'a>(node: NodeRef<'a, Node>, names: &[&str]) -> Vec<NodeRef<'a, Node>> {
    let mut out = Vec::new();
    for child in node.children() {
        if let Some(name) = node_tag_name(child) {
            if names.contains(&name.as_str()) {
                out.push(child);
            }
        }
        out.extend(find_all(child, names));
    }
    out
}

fn find_first_descendant_with_attr(
    node: NodeRef<'_, Node>,
    tag: &str,
    attr: &str,
) -> Option<String> {
    for child in node.children() {
        if node_tag_name(child).as_deref() == Some(tag) {
            if let Some(value) = node_attr(child, attr) {
                if !value.is_empty() {
                    return Some(value);
                }
            }
        }
        if let Some(found) = find_first_descendant_with_attr(child, tag, attr) {
            return Some(found);
        }
    }
    None
}

fn lstrip_chars(input: &str, chars: &[char]) -> String {
    input.trim_start_matches(|c| chars.contains(&c)).to_string()
}

fn rstrip_default(input: &str) -> String {
    input.trim_end_matches(char::is_whitespace).to_string()
}

fn chomp(text: &str) -> (String, String, String) {
    let prefix = if text.starts_with(' ') { " " } else { "" };
    let suffix = if text.ends_with(' ') { " " } else { "" };
    let inner = text.trim();
    (prefix.to_string(), suffix.to_string(), inner.to_string())
}

fn inline_wrap(text: &str, parent_tags: &HashSet<String>, markup: &str) -> String {
    if parent_tags.contains("_noformat") {
        return text.to_string();
    }
    let (prefix, suffix, inner) = chomp(text);
    if inner.is_empty() {
        return String::new();
    }

    let (markup_prefix, markup_suffix) = if markup.starts_with('<') && markup.ends_with('>') {
        (markup.to_string(), format!("</{}", &markup[1..]))
    } else {
        (markup.to_string(), markup.to_string())
    };

    format!("{prefix}{markup_prefix}{inner}{markup_suffix}{suffix}")
}

fn extract_cdata(comment: &str) -> Option<&str> {
    let rest = comment.strip_prefix("[CDATA[")?;
    rest.strip_suffix("]]")
}

fn map_lines<F>(text: &str, mut mapper: F) -> String
where
    F: FnMut(&str) -> String,
{
    let mut out = String::new();
    for (idx, line) in text.split('\n').enumerate() {
        if idx > 0 {
            out.push('\n');
        }
        out.push_str(&mapper(line));
    }
    out
}

fn extract_newlines(text: &str) -> (String, String, String) {
    let mut leading = 0usize;
    let bytes = text.as_bytes();
    while leading < bytes.len() && bytes[leading] == b'\n' {
        leading += 1;
    }
    let rest = &text[leading..];
    if rest.is_empty() || rest.chars().all(|c| c == '\n') {
        return (text.to_string(), String::new(), String::new());
    }

    let mut trailing = 0usize;
    let rest_bytes = rest.as_bytes();
    while trailing < rest_bytes.len() && rest_bytes[rest_bytes.len() - 1 - trailing] == b'\n' {
        trailing += 1;
    }

    let content = &rest[..rest.len() - trailing];
    (
        "\n".repeat(leading),
        content.to_string(),
        "\n".repeat(trailing),
    )
}

fn strip1_pre(text: &str) -> String {
    let text = RE_PRE_LSTRIP1.replace(text, "").to_string();
    RE_PRE_RSTRIP1.replace(&text, "").to_string()
}

fn strip_pre(text: &str) -> String {
    let text = RE_PRE_LSTRIP.replace(text, "").to_string();
    RE_PRE_RSTRIP.replace(&text, "").to_string()
}

static RE_WHITESPACE: Lazy<Regex> = Lazy::new(|| Regex::new(r"[\t ]+").unwrap());
static RE_ALL_WHITESPACE: Lazy<Regex> = Lazy::new(|| Regex::new(r"[\t \r\n]+").unwrap());
static RE_NEWLINE_WHITESPACE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"[\t \r\n]*[\r\n][\t \r\n]*").unwrap());
static RE_PRE_LSTRIP1: Lazy<Regex> = Lazy::new(|| Regex::new(r"^ *\n").unwrap());
static RE_PRE_RSTRIP1: Lazy<Regex> = Lazy::new(|| Regex::new(r"\n *$").unwrap());
static RE_PRE_LSTRIP: Lazy<Regex> = Lazy::new(|| Regex::new(r"^[ \n]*\n").unwrap());
static RE_PRE_RSTRIP: Lazy<Regex> = Lazy::new(|| Regex::new(r"[ \n]*$").unwrap());
static RE_MAKE_CONVERT_FN_NAME: Lazy<Regex> = Lazy::new(|| Regex::new(r"[\[\]:-]").unwrap());
static RE_ESCAPE_MISC_CHARS: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"(\]|\[|\\|&|<|`|>|~|=|\+|\|)").unwrap());
static RE_ESCAPE_MISC_DASH: Lazy<Regex> = Lazy::new(|| Regex::new(r"(\s|^)(-+(?:\s|$))").unwrap());
static RE_ESCAPE_MISC_HASHES: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"(\s|^)(#{1,6}(?:\s|$))").unwrap());
static RE_ESCAPE_MISC_LIST_ITEMS: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"((?:\s|^)[0-9]{1,9})([.)](?:\s|$))").unwrap());
static RE_BACKTICK_RUNS: Lazy<Regex> = Lazy::new(|| Regex::new(r"`+").unwrap());
