use std::borrow::Cow;
use std::collections::{HashMap, HashSet};

use comrak::{Options as ComrakOptions, markdown_to_html as comrak_markdown_to_html};
use once_cell::sync::Lazy;
use rayon::prelude::*;
use regex::{Captures, Regex};

static META_LINE_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"^([A-Za-z0-9_-][A-Za-z0-9_ -]*?)\s*:\s*(.*)$").expect("valid META_LINE_RE")
});
static ABBR_DEF_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"^\*\[([^\]]+)\]:\s*(.+?)\s*$").expect("valid ABBR_DEF_RE"));
static WIKILINK_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"\[\[([^\]\|]+?)(?:\|([^\]]+?))?\]\]").expect("valid WIKILINK_RE"));
static HEADING_ATTR_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"^(#{1,6}\s+.*?)(?:\s+\{([^{}]+)\})\s*$").expect("valid HEADING_ATTR_RE")
});
static ADMONITION_START_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r#"^([!?]{3})\s*([A-Za-z0-9_-]+)?(?:\s+"([^"]+)")?\s*$"#)
        .expect("valid ADMONITION_START_RE")
});
static TOC_MARKER_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"(?is)<p>\[\[?toc\]?\]</p>").expect("valid TOC_MARKER_RE"));
static PRE_CODE_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"(?is)<pre><code([^>]*)>(.*?)</code></pre>").expect("valid PRE_CODE_RE")
});
static PRE_CODE_WITH_LANG_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r#"(?is)<pre><code class="language-([^"]+)">(.*?)</code></pre>"#)
        .expect("valid PRE_CODE_WITH_LANG_RE")
});
static LANGUAGE_CLASS_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r#"(?i)\bclass\s*=\s*"([^"]*)""#).expect("valid LANGUAGE_CLASS_RE"));
static TAG_STRIP_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"(?is)<[^>]+>").expect("valid TAG_STRIP_RE"));
static FOOTNOTE_REF_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(
        r##"(?is)<sup class="footnote-ref"><a href="#fn-([^"]+)" id="fnref-([^"]+)" data-footnote-ref>([^<]+)</a></sup>"##,
    )
    .expect("valid FOOTNOTE_REF_RE")
});
static FOOTNOTE_ITEM_ID_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r#"(?is)<li id="fn-([^"]+)">"#).expect("valid FOOTNOTE_ITEM_ID_RE"));
static FOOTNOTE_BACKREF_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r##"(?is)<a href="#fnref-([^"]+)" class="footnote-backref"[^>]*>.*?</a>"##)
        .expect("valid FOOTNOTE_BACKREF_RE")
});
static FOOTNOTE_BACKREF_SPACE_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r#"(?is)<p>(.*?)\s(<a class="footnote-backref"[^>]*>)"#)
        .expect("valid FOOTNOTE_BACKREF_SPACE_RE")
});
static ATX_HEADING_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"^#{1,6}\s+").expect("valid ATX_HEADING_RE"));
static SETEXT_UNDERLINE_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"^[-=]{2,}\s*$").expect("valid SETEXT_UNDERLINE_RE"));
static BLOCK_BOUNDARY_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"^(?:>\s*|[*_-]{3,}\s*$|```|~~~|[ \t]{4,}|<[^>]+>)")
        .expect("valid BLOCK_BOUNDARY_RE")
});
static MALFORMED_LINK_DEST_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"\[([^\]\n]+)\]\(([^)\n]*\s[^)\n]*)\)").expect("valid MALFORMED_LINK_DEST_RE")
});
static ORDERED_INLINE_BULLET_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"^([ \t]*)(\d+\.)\s+([*+-]\s+.+)$").expect("valid ORDERED_INLINE_BULLET_RE")
});
static BULLET_LINE_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"^([ \t]*)([*+-])\s+(.+)$").expect("valid BULLET_LINE_RE"));
static BULLET_PREFIXED_NUMBERED_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"^([ \t]*)([*+-])\s+(\d+\.\s+.+)$").expect("valid BULLET_PREFIXED_NUMBERED_RE")
});
static NUMBERED_LINE_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"^([ \t]*)(\d+\.)\s+(.+)$").expect("valid NUMBERED_LINE_RE"));
static ENTITY_REF_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"&(?:#[0-9]+|#x[0-9A-Fa-f]+|[A-Za-z][A-Za-z0-9]+);").expect("valid ENTITY_REF_RE")
});
static ENTITY_TOKEN_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"MDRSENTITYTOKEN(\d+)X").expect("valid ENTITY_TOKEN_RE"));
static RAW_HTML_TOKEN_P_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"(?is)<p>\s*MDRSRAWHTMLTOKEN(\d+)X\s*</p>").expect("valid RAW_HTML_TOKEN_P_RE")
});
static RAW_HTML_TOKEN_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"MDRSRAWHTMLTOKEN(\d+)X").expect("valid RAW_HTML_TOKEN_RE"));

const LINK_DEST_SPACE_TOKEN: &str = "MDRSLINKDESTSPACETOKEN";
const ESC_TOKEN_DQUOTE: &str = "MDRSESCDQUOTETOKEN";
const ESC_TOKEN_DOLLAR: &str = "MDRSESCDOLLARTOKEN";
const ESC_TOKEN_PERCENT: &str = "MDRSESCPERCENTTOKEN";
const ESC_TOKEN_AMP: &str = "MDRSESCAMPTOKEN";
const ESC_TOKEN_SQUOTE: &str = "MDRSESCSQUOTETOKEN";
const ESC_TOKEN_COMMA: &str = "MDRSESCCOMMATOKEN";
const ESC_TOKEN_SLASH: &str = "MDRSESCSLASHTOKEN";
const ESC_TOKEN_COLON: &str = "MDRSESCCOLONTOKEN";
const ESC_TOKEN_SEMI: &str = "MDRSESCSEMITOKEN";
const ESC_TOKEN_LT: &str = "MDRSESCLTTOKEN";
const ESC_TOKEN_EQ: &str = "MDRSESCEQTOKEN";
const ESC_TOKEN_QMARK: &str = "MDRSESCQMARKTOKEN";
const ESC_TOKEN_AT: &str = "MDRSESCATTOKEN";
const ESC_TOKEN_CARET: &str = "MDRSESCCARETTOKEN";
const ESC_TOKEN_PIPE: &str = "MDRSESCPIPETOKEN";
const ESC_TOKEN_TILDE: &str = "MDRSESCTILDETOKEN";

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum OutputFormat {
    Html,
    Xhtml,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum MarkdownMode {
    Fast,
    #[default]
    PythonCompat,
}

#[derive(Clone, Debug)]
pub struct MarkdownToHtmlOptions {
    pub mode: MarkdownMode,
    pub extensions: HashSet<String>,
    pub extension_configs: HashMap<String, HashMap<String, String>>,
    pub output_format: OutputFormat,
    pub tab_length: usize,
    pub lazy_ol: bool,
    pub autolink: bool,
    pub tasklist: bool,
    pub strikethrough: bool,
}

impl Default for MarkdownToHtmlOptions {
    fn default() -> Self {
        Self {
            mode: MarkdownMode::PythonCompat,
            extensions: HashSet::new(),
            extension_configs: HashMap::new(),
            output_format: OutputFormat::Xhtml,
            tab_length: 4,
            lazy_ol: true,
            autolink: false,
            tasklist: false,
            strikethrough: false,
        }
    }
}

#[derive(Clone, Debug, Default)]
pub struct ConversionArtifacts {
    pub meta: HashMap<String, Vec<String>>,
    pub toc_tokens: Vec<TocToken>,
}

#[derive(Clone, Debug, Default)]
pub struct TocToken {
    pub level: usize,
    pub id: String,
    pub name: String,
}

#[derive(Clone, Debug, Default)]
struct AttrSpec {
    id: Option<String>,
    classes: Vec<String>,
    attrs: Vec<(String, String)>,
}

#[derive(Clone, Debug)]
struct AdmonitionBlock {
    placeholder: String,
    class_name: String,
    title: String,
    body_markdown: String,
}

#[derive(Clone, Debug)]
struct EntityToken {
    raw: String,
}

#[derive(Clone, Debug)]
struct RawHtmlToken {
    raw: String,
}

#[derive(Clone, Debug)]
struct WikilinkConfig {
    base_url: String,
    end_url: String,
    html_class: String,
}

impl Default for WikilinkConfig {
    fn default() -> Self {
        Self {
            base_url: "/".to_string(),
            end_url: "/".to_string(),
            html_class: "wikilink".to_string(),
        }
    }
}

#[derive(Clone, Debug)]
struct TocConfig {
    toc_class: String,
    title: Option<String>,
}

impl Default for TocConfig {
    fn default() -> Self {
        Self {
            toc_class: "toc".to_string(),
            title: None,
        }
    }
}

#[derive(Clone, Debug)]
struct CodeHiliteConfig {
    css_class: String,
    lang_prefix: String,
}

impl Default for CodeHiliteConfig {
    fn default() -> Self {
        Self {
            css_class: "codehilite".to_string(),
            lang_prefix: "language-".to_string(),
        }
    }
}

pub fn markdown_to_html(markdown: &str) -> String {
    markdown_to_html_with_options(markdown, MarkdownToHtmlOptions::default())
}

pub fn markdown_to_html_with_options(markdown: &str, options: MarkdownToHtmlOptions) -> String {
    markdown_to_html_with_artifacts(markdown, options).0
}

pub fn markdown_to_html_with_artifacts(
    markdown: &str,
    options: MarkdownToHtmlOptions,
) -> (String, ConversionArtifacts) {
    let extension_set = normalized_extensions(&options.extensions);
    let mut artifacts = ConversionArtifacts::default();

    if options.mode == MarkdownMode::Fast {
        let html = render_with_comrak(markdown, &options, &extension_set);
        return (
            normalize_output_format(&html, options.output_format),
            artifacts,
        );
    }

    let mut source = markdown.to_string();

    if extension_set.contains("meta") {
        let (without_meta, meta) = preprocess_meta(&source);
        source = without_meta;
        artifacts.meta = meta;
    }

    let mut raw_html_tokens = Vec::new();
    if source.contains('<') {
        let (rewritten_source, tokens) = preprocess_python_raw_html_blocks(&source);
        source = rewritten_source;
        raw_html_tokens = tokens;
    }

    if source.contains('[')
        && source.contains("](")
        && source.contains("://")
        && source.contains(' ')
    {
        source = preprocess_malformed_link_destinations(&source);
    }
    if source.contains('\\') {
        source = preprocess_python_backslash_escapes(&source);
    }
    // Python-Markdown does not parse `1)`-style ordered markers as lists,
    // treats bare marker lines (`-`, `*`, `+`) as plain text, and keeps
    // hanging ordered markers (`2.`) as plain text.
    source = preprocess_python_list_marker_compat(&source);
    // OCR-heavy corpora often contain broken mixed list continuations
    // (`2. - (A) ...` and `- 1. ...` followed by `2. ...`) that
    // Python-Markdown handles more permissively.
    if has_python_mixed_list_continuation_candidates(&source) {
        source = preprocess_python_mixed_list_continuations(&source);
    }
    // Python-Markdown does not allow list items to interrupt paragraphs
    // without a separating blank line. Apply a lightweight pre-pass so
    // comrak list parsing aligns more closely on OCR/PDF-derived corpora.
    source = preprocess_python_markdown_list_interruptions(
        &source,
        extension_set.contains("sane_lists"),
        true,
    );

    let mut entity_tokens = Vec::new();
    if source.contains('&') {
        let (rewritten_source, tokens) = preprocess_python_entity_references(&source);
        source = rewritten_source;
        entity_tokens = tokens;
    }

    let mut heading_attr_specs = Vec::new();
    if extension_set.contains("attr_list") {
        let (without_heading_attrs, attrs) = preprocess_heading_attr_lists(&source);
        source = without_heading_attrs;
        heading_attr_specs = attrs;
    }

    if extension_set.contains("wikilinks") {
        let cfg = wikilink_config(&options.extension_configs);
        source = preprocess_wikilinks(&source, &cfg);
    }

    let mut admonitions = Vec::new();
    if extension_set.contains("admonition") {
        let (without_admonitions, blocks) = preprocess_admonitions(&source);
        source = without_admonitions;
        admonitions = blocks;
    }

    let mut abbreviations = Vec::new();
    if extension_set.contains("abbr") {
        let (without_defs, defs) = preprocess_abbreviations(&source);
        source = without_defs;
        abbreviations = defs;
    }

    let mut html = render_with_comrak(&source, &options, &extension_set);

    if !admonitions.is_empty() {
        html = inject_admonitions(&html, &admonitions, &options, &extension_set);
    }

    let mut toc_tokens = Vec::new();
    if !heading_attr_specs.is_empty() || extension_set.contains("toc") {
        let toc_enabled = extension_set.contains("toc");
        let (updated_html, tokens) = rewrite_headings(
            &html,
            &heading_attr_specs,
            toc_enabled,
            &options.extension_configs,
        );
        html = updated_html;
        toc_tokens = tokens;
    }

    if extension_set.contains("toc") {
        let toc_cfg = toc_config(&options.extension_configs);
        let toc_html = build_toc_html(&toc_tokens, &toc_cfg);
        html = replace_toc_markers(&html, &toc_html);
    }

    if extension_set.contains("footnotes") {
        html = apply_python_markdown_footnote_shape(&html);
    }

    if extension_set.contains("codehilite")
        && !extension_set.contains("fenced_code")
        && !extension_set.contains("extra")
    {
        html = downgrade_fenced_code_blocks_without_fenced_code(&html);
    }

    if extension_set.contains("codehilite") {
        let cfg = codehilite_config(&options.extension_configs);
        html = apply_codehilite(&html, &cfg);
    }

    if !abbreviations.is_empty() {
        html = apply_abbreviations(&html, &abbreviations);
    }

    if extension_set.contains("smarty") {
        html = encode_smarty_entities(&html);
    }
    if html.contains("_______") {
        html = apply_python_underscore_run_emphasis(&html);
    }
    if html.contains("MDRSESC") {
        html = restore_python_backslash_escape_tokens(&html);
    }
    if html.contains(LINK_DEST_SPACE_TOKEN) {
        html = restore_malformed_link_destinations(&html);
    }
    if !entity_tokens.is_empty() {
        html = restore_python_entity_references(&html, &entity_tokens);
    }

    let mut final_html = normalize_output_format(&html, options.output_format);
    if !raw_html_tokens.is_empty() && final_html.contains("MDRSRAWHTMLTOKEN") {
        final_html = restore_python_raw_html_blocks(&final_html, &raw_html_tokens);
    }

    artifacts.toc_tokens = toc_tokens;
    (final_html, artifacts)
}

pub fn markdown_to_html_batch(markdowns: Vec<String>) -> Vec<String> {
    markdown_to_html_batch_with_options(markdowns, MarkdownToHtmlOptions::default())
}

pub fn markdown_to_html_batch_with_options(
    markdowns: Vec<String>,
    options: MarkdownToHtmlOptions,
) -> Vec<String> {
    markdowns
        .into_par_iter()
        .map_init(
            || options.clone(),
            |opts, text| markdown_to_html_with_options(&text, opts.clone()),
        )
        .collect()
}

fn normalized_extensions(extensions: &HashSet<String>) -> HashSet<String> {
    let mut out = HashSet::new();
    for ext in extensions {
        let mut key = ext.trim().to_ascii_lowercase();
        if let Some(stripped) = key.strip_prefix("markdown.extensions.") {
            key = stripped.to_string();
        }
        out.insert(key.clone());
        if key == "extra" {
            out.insert("abbr".to_string());
            out.insert("attr_list".to_string());
            out.insert("def_list".to_string());
            out.insert("fenced_code".to_string());
            out.insert("footnotes".to_string());
            out.insert("md_in_html".to_string());
            out.insert("tables".to_string());
        }
    }
    out
}

fn render_with_comrak(
    markdown: &str,
    options: &MarkdownToHtmlOptions,
    extension_set: &HashSet<String>,
) -> String {
    let mut comrak_options = ComrakOptions::default();

    comrak_options.extension.table = extension_set.contains("tables");
    comrak_options.extension.footnotes = extension_set.contains("footnotes");
    comrak_options.extension.description_lists = extension_set.contains("def_list");
    // These GFM-ish behaviors are exposed as explicit options so callers can
    // opt in while defaults stay Python-Markdown-compatible.
    comrak_options.extension.autolink = options.autolink;
    comrak_options.extension.tasklist = options.tasklist;
    comrak_options.extension.strikethrough = options.strikethrough;

    comrak_options.parse.smart = extension_set.contains("smarty");

    comrak_options.render.unsafe_ = true;
    comrak_options.render.hardbreaks = extension_set.contains("nl2br");
    comrak_options.render.width = 0;
    comrak_options.render.github_pre_lang = false;
    comrak_options.render.full_info_string = true;

    // Python-Markdown keeps tab length configurable; comrak does not expose
    // the same parser knob, so we preserve the value in our public API for
    // compatibility and leave rendering behavior deterministic.
    let _ = options.tab_length;
    let _ = options.lazy_ol;

    comrak_markdown_to_html(markdown, &comrak_options)
}

fn preprocess_meta(markdown: &str) -> (String, HashMap<String, Vec<String>>) {
    let mut out_lines = Vec::new();
    let mut meta = HashMap::<String, Vec<String>>::new();
    let mut iter = markdown.lines().peekable();
    let mut consumed_any = false;
    let mut current_key: Option<String> = None;

    while let Some(line) = iter.peek().copied() {
        if line.trim().is_empty() {
            let _ = iter.next();
            consumed_any = consumed_any || !meta.is_empty();
            break;
        }

        if let Some(caps) = META_LINE_RE.captures(line) {
            let key = caps
                .get(1)
                .map(|m| m.as_str().trim().to_ascii_lowercase())
                .unwrap_or_default();
            let value = caps.get(2).map(|m| m.as_str().trim()).unwrap_or("");
            meta.entry(key.clone()).or_default().push(value.to_string());
            current_key = Some(key);
            consumed_any = true;
            let _ = iter.next();
            continue;
        }

        if (line.starts_with(' ') || line.starts_with('\t')) && current_key.is_some() {
            let key = current_key.clone().unwrap_or_default();
            if let Some(values) = meta.get_mut(&key) {
                if let Some(last) = values.last_mut() {
                    let trimmed = line.trim();
                    if !last.is_empty() {
                        last.push('\n');
                    }
                    last.push_str(trimmed);
                }
            }
            consumed_any = true;
            let _ = iter.next();
            continue;
        }

        break;
    }

    if consumed_any {
        out_lines.extend(iter.map(str::to_string));
        (out_lines.join("\n"), meta)
    } else {
        (markdown.to_string(), HashMap::new())
    }
}

fn preprocess_abbreviations(markdown: &str) -> (String, Vec<(String, String)>) {
    let mut out = Vec::new();
    let mut defs = Vec::<(String, String)>::new();
    for line in markdown.lines() {
        if let Some(caps) = ABBR_DEF_RE.captures(line) {
            let abbr = caps.get(1).map(|m| m.as_str().trim()).unwrap_or("");
            let title = caps.get(2).map(|m| m.as_str().trim()).unwrap_or("");
            if !abbr.is_empty() && !title.is_empty() {
                defs.push((abbr.to_string(), title.to_string()));
                continue;
            }
        }
        out.push(line.to_string());
    }
    defs.sort_by(|a, b| b.0.len().cmp(&a.0.len()));
    (out.join("\n"), defs)
}

fn preprocess_malformed_link_destinations(markdown: &str) -> String {
    if !markdown.contains('[')
        || !markdown.contains("](")
        || !markdown.contains("://")
        || !markdown.contains(' ')
    {
        return markdown.to_string();
    }

    MALFORMED_LINK_DEST_RE
        .replace_all(markdown, |caps: &Captures<'_>| {
            let whole = caps.get(0).map(|m| m.as_str()).unwrap_or_default();
            let label = caps.get(1).map(|m| m.as_str()).unwrap_or_default();
            let dest = caps.get(2).map(|m| m.as_str()).unwrap_or_default();

            // Python-Markdown is permissive with malformed destinations (for
            // example embedded spaces). Keep the markdown shape but replace
            // spaces with a token so comrak still parses it as a link.
            if !dest.contains("://") {
                return whole.to_string();
            }
            if dest.contains('"') || dest.contains('\'') {
                return whole.to_string();
            }
            if dest.trim_start().starts_with('<') {
                return whole.to_string();
            }
            if !dest.contains(' ') {
                return whole.to_string();
            }

            format!("[{}]({})", label, dest.replace(' ', LINK_DEST_SPACE_TOKEN))
        })
        .into_owned()
}

fn restore_malformed_link_destinations(html: &str) -> String {
    html.replace(LINK_DEST_SPACE_TOKEN, " ")
}

fn preprocess_python_backslash_escapes(markdown: &str) -> String {
    let bytes = markdown.as_bytes();
    let mut out = String::with_capacity(markdown.len());
    let mut i = 0usize;
    let mut segment_start = 0usize;
    let mut changed = false;

    while i < bytes.len() {
        if bytes[i] != b'\\' {
            i += 1;
            continue;
        }

        let run_start = i;
        while i < bytes.len() && bytes[i] == b'\\' {
            i += 1;
        }
        let run_len = i - run_start;

        if i < bytes.len()
            && run_len % 2 == 1
            && let Some(token) = token_for_escaped_punct(bytes[i])
        {
            out.push_str(&markdown[segment_start..run_start]);
            for _ in 0..(run_len - 1) {
                out.push('\\');
            }
            out.push_str(token);
            i += 1;
            segment_start = i;
            changed = true;
        }
    }

    if !changed {
        return markdown.to_string();
    }

    out.push_str(&markdown[segment_start..]);
    out
}

fn token_for_escaped_punct(punct: u8) -> Option<&'static str> {
    match punct {
        b'"' => Some(ESC_TOKEN_DQUOTE),
        b'$' => Some(ESC_TOKEN_DOLLAR),
        b'%' => Some(ESC_TOKEN_PERCENT),
        b'&' => Some(ESC_TOKEN_AMP),
        b'\'' => Some(ESC_TOKEN_SQUOTE),
        b',' => Some(ESC_TOKEN_COMMA),
        b'/' => Some(ESC_TOKEN_SLASH),
        b':' => Some(ESC_TOKEN_COLON),
        b';' => Some(ESC_TOKEN_SEMI),
        b'<' => Some(ESC_TOKEN_LT),
        b'=' => Some(ESC_TOKEN_EQ),
        b'?' => Some(ESC_TOKEN_QMARK),
        b'@' => Some(ESC_TOKEN_AT),
        b'^' => Some(ESC_TOKEN_CARET),
        b'|' => Some(ESC_TOKEN_PIPE),
        b'~' => Some(ESC_TOKEN_TILDE),
        _ => None,
    }
}

fn restore_python_backslash_escape_tokens(html: &str) -> String {
    html.replace(ESC_TOKEN_DQUOTE, "\\\"")
        .replace(ESC_TOKEN_DOLLAR, "\\$")
        .replace(ESC_TOKEN_PERCENT, "\\%")
        .replace(ESC_TOKEN_AMP, "\\&amp;")
        .replace(ESC_TOKEN_SQUOTE, "\\'")
        .replace(ESC_TOKEN_COMMA, "\\,")
        .replace(ESC_TOKEN_SLASH, "\\/")
        .replace(ESC_TOKEN_COLON, "\\:")
        .replace(ESC_TOKEN_SEMI, "\\;")
        .replace(ESC_TOKEN_LT, "\\&lt;")
        .replace(ESC_TOKEN_EQ, "\\=")
        .replace(ESC_TOKEN_QMARK, "\\?")
        .replace(ESC_TOKEN_AT, "\\@")
        .replace(ESC_TOKEN_CARET, "\\^")
        .replace(ESC_TOKEN_PIPE, "\\|")
        .replace(ESC_TOKEN_TILDE, "\\~")
}

fn preprocess_python_entity_references(markdown: &str) -> (String, Vec<EntityToken>) {
    if !markdown.contains('&') {
        return (markdown.to_string(), Vec::new());
    }

    let mut tokens = Vec::<EntityToken>::new();
    let rewritten = ENTITY_REF_RE
        .replace_all(markdown, |caps: &Captures<'_>| {
            let raw = caps.get(0).map(|m| m.as_str()).unwrap_or_default();
            let idx = tokens.len();
            tokens.push(EntityToken {
                raw: raw.to_string(),
            });
            format!("MDRSENTITYTOKEN{idx}X")
        })
        .into_owned();
    (rewritten, tokens)
}

fn restore_python_entity_references(html: &str, tokens: &[EntityToken]) -> String {
    let mut out = String::with_capacity(html.len() + 64);
    let bytes = html.as_bytes();
    let mut i = 0usize;
    let mut skip_depth = 0usize;

    while i < bytes.len() {
        if bytes[i] == b'<' {
            let start = i;
            while i < bytes.len() && bytes[i] != b'>' {
                i += 1;
            }
            if i < bytes.len() {
                i += 1;
            }
            let tag = &html[start..i];
            update_skip_depth(tag, &mut skip_depth);
            out.push_str(&replace_entity_tokens(tag, tokens, false));
            continue;
        }

        let start = i;
        while i < bytes.len() && bytes[i] != b'<' {
            i += 1;
        }
        let text = &html[start..i];
        out.push_str(&replace_entity_tokens(text, tokens, skip_depth > 0));
    }

    out
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum RawHtmlStartKind {
    BlockTag,
    EmptyBlock,
}

fn preprocess_python_raw_html_blocks(markdown: &str) -> (String, Vec<RawHtmlToken>) {
    if markdown.is_empty() {
        return (String::new(), Vec::new());
    }

    let lines: Vec<&str> = markdown.lines().collect();
    let trailing_newline = markdown.ends_with('\n');
    let mut out = Vec::<String>::with_capacity(lines.len());
    let mut tokens = Vec::<RawHtmlToken>::new();
    let mut in_fence = false;
    let mut i = 0usize;

    while i < lines.len() {
        let line = lines[i];
        let trimmed_start = line.trim_start();

        if is_fence_delimiter(trimmed_start) {
            in_fence = !in_fence;
            out.push(line.to_string());
            i += 1;
            continue;
        }
        if in_fence {
            out.push(line.to_string());
            i += 1;
            continue;
        }

        let Some(start_kind) = python_raw_html_block_start_kind(line) else {
            out.push(line.to_string());
            i += 1;
            continue;
        };

        let mut raw_lines = Vec::<String>::new();
        raw_lines.push(line.to_string());
        i += 1;

        if start_kind == RawHtmlStartKind::BlockTag {
            let mut stack = Vec::<String>::new();
            update_python_raw_html_stack(line, &mut stack);

            while !stack.is_empty() && i < lines.len() {
                let next = lines[i];
                raw_lines.push(next.to_string());
                update_python_raw_html_stack(next, &mut stack);
                i += 1;
            }
        }

        let token = format!("MDRSRAWHTMLTOKEN{}X", tokens.len());
        tokens.push(RawHtmlToken {
            raw: raw_lines.join("\n"),
        });
        out.push(token);
    }

    let mut rewritten = out.join("\n");
    if trailing_newline {
        rewritten.push('\n');
    }
    (rewritten, tokens)
}

fn restore_python_raw_html_blocks(html: &str, tokens: &[RawHtmlToken]) -> String {
    let replaced_paragraphs = RAW_HTML_TOKEN_P_RE
        .replace_all(html, |caps: &Captures<'_>| {
            let idx = caps
                .get(1)
                .and_then(|m| m.as_str().parse::<usize>().ok())
                .unwrap_or(usize::MAX);
            tokens
                .get(idx)
                .map(|token| token.raw.clone())
                .unwrap_or_else(|| {
                    caps.get(0)
                        .map(|m| m.as_str().to_string())
                        .unwrap_or_default()
                })
        })
        .into_owned();

    RAW_HTML_TOKEN_RE
        .replace_all(&replaced_paragraphs, |caps: &Captures<'_>| {
            let idx = caps
                .get(1)
                .and_then(|m| m.as_str().parse::<usize>().ok())
                .unwrap_or(usize::MAX);
            tokens
                .get(idx)
                .map(|token| token.raw.clone())
                .unwrap_or_else(|| {
                    caps.get(0)
                        .map(|m| m.as_str().to_string())
                        .unwrap_or_default()
                })
        })
        .into_owned()
}

fn python_raw_html_block_start_kind(line: &str) -> Option<RawHtmlStartKind> {
    let indent = leading_indent_width(line);
    if indent > 3 {
        return None;
    }

    let trimmed = line.trim_start();
    if trimmed.is_empty() || !trimmed.starts_with('<') {
        return None;
    }

    if trimmed.starts_with("<!--")
        || trimmed.starts_with("<!")
        || trimmed.starts_with("<?")
        || trimmed.starts_with("</>")
    {
        return Some(RawHtmlStartKind::EmptyBlock);
    }

    let Some((token_start, token_end)) = first_complete_tag_bounds(trimmed) else {
        return None;
    };
    if token_start != 0 {
        return None;
    }

    let token = &trimmed[token_start..=token_end];
    let parsed = parse_html_tag_token(token)?;
    match parsed {
        HtmlTagToken::Start { tag, self_closing } => {
            if !is_python_markdown_block_level_tag(&tag) {
                return None;
            }
            if self_closing {
                Some(RawHtmlStartKind::EmptyBlock)
            } else {
                Some(RawHtmlStartKind::BlockTag)
            }
        }
        HtmlTagToken::End { .. } => None,
        HtmlTagToken::Other => Some(RawHtmlStartKind::EmptyBlock),
    }
}

fn update_python_raw_html_stack(line: &str, stack: &mut Vec<String>) {
    let mut cursor = 0usize;
    while cursor < line.len() {
        let Some(start_rel) = line[cursor..].find('<') else {
            break;
        };
        let start = cursor + start_rel;
        let Some(end_rel) = line[start..].find('>') else {
            break;
        };
        let end = start + end_rel;
        let token = &line[start..=end];

        match parse_html_tag_token(token) {
            Some(HtmlTagToken::Start { tag, self_closing }) => {
                if !self_closing {
                    stack.push(tag);
                }
            }
            Some(HtmlTagToken::End { tag }) => {
                if let Some(pos) = stack.iter().rposition(|open| open == &tag) {
                    stack.truncate(pos);
                }
            }
            _ => {}
        }
        cursor = end + 1;
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum HtmlTagToken {
    Start { tag: String, self_closing: bool },
    End { tag: String },
    Other,
}

fn parse_html_tag_token(token: &str) -> Option<HtmlTagToken> {
    if !token.starts_with('<') || !token.ends_with('>') || token.len() < 3 {
        return None;
    }

    let inner = token[1..token.len() - 1].trim();
    if inner.is_empty() {
        return Some(HtmlTagToken::Other);
    }
    if inner.starts_with("!--") || inner.starts_with('!') || inner.starts_with('?') {
        return Some(HtmlTagToken::Other);
    }

    if let Some(name_source) = inner.strip_prefix('/') {
        return parse_html_tag_name(name_source).map(|tag| HtmlTagToken::End { tag });
    }

    let tag = parse_html_tag_name(inner)?;
    let self_closing = inner.ends_with('/') || tag == "hr";
    Some(HtmlTagToken::Start { tag, self_closing })
}

fn parse_html_tag_name(input: &str) -> Option<String> {
    let mut chars = input.chars();
    let first = chars.next()?;
    if !first.is_ascii_alphabetic() {
        return None;
    }

    let mut end = first.len_utf8();
    for ch in chars {
        if ch.is_ascii_alphanumeric() || ch == '-' || ch == '_' || ch == ':' {
            end += ch.len_utf8();
            continue;
        }
        break;
    }
    Some(input[..end].to_ascii_lowercase())
}

fn first_complete_tag_bounds(text: &str) -> Option<(usize, usize)> {
    let start = text.find('<')?;
    let end_rel = text[start..].find('>')?;
    Some((start, start + end_rel))
}

fn is_python_markdown_block_level_tag(tag: &str) -> bool {
    matches!(
        tag,
        "address"
            | "article"
            | "aside"
            | "blockquote"
            | "details"
            | "div"
            | "dl"
            | "fieldset"
            | "figcaption"
            | "figure"
            | "footer"
            | "form"
            | "h1"
            | "h2"
            | "h3"
            | "h4"
            | "h5"
            | "h6"
            | "header"
            | "hgroup"
            | "hr"
            | "main"
            | "menu"
            | "nav"
            | "ol"
            | "p"
            | "pre"
            | "section"
            | "table"
            | "ul"
            | "canvas"
            | "colgroup"
            | "dd"
            | "body"
            | "dt"
            | "group"
            | "html"
            | "iframe"
            | "li"
            | "legend"
            | "math"
            | "map"
            | "noscript"
            | "output"
            | "object"
            | "option"
            | "progress"
            | "script"
            | "style"
            | "summary"
            | "tbody"
            | "td"
            | "textarea"
            | "tfoot"
            | "th"
            | "thead"
            | "tr"
            | "video"
            | "center"
    )
}

fn replace_entity_tokens(segment: &str, tokens: &[EntityToken], escape: bool) -> String {
    ENTITY_TOKEN_RE
        .replace_all(segment, |caps: &Captures<'_>| {
            let idx = caps
                .get(1)
                .and_then(|m| m.as_str().parse::<usize>().ok())
                .unwrap_or(usize::MAX);
            let Some(token) = tokens.get(idx) else {
                return caps
                    .get(0)
                    .map(|m| m.as_str().to_string())
                    .unwrap_or_default();
            };
            if escape {
                escape_html_text(&token.raw)
            } else {
                token.raw.clone()
            }
        })
        .into_owned()
}

fn apply_python_underscore_run_emphasis(html: &str) -> String {
    let mut out = String::with_capacity(html.len() + 64);
    let bytes = html.as_bytes();
    let mut i = 0usize;
    let mut skip_depth = 0usize;

    while i < bytes.len() {
        if bytes[i] == b'<' {
            let start = i;
            while i < bytes.len() && bytes[i] != b'>' {
                i += 1;
            }
            if i < bytes.len() {
                i += 1;
            }
            let tag = &html[start..i];
            update_skip_depth(tag, &mut skip_depth);
            out.push_str(tag);
            continue;
        }

        let start = i;
        while i < bytes.len() && bytes[i] != b'<' {
            i += 1;
        }
        let text = &html[start..i];
        if skip_depth == 0 {
            out.push_str(&rewrite_python_underscore_runs_in_text(text));
        } else {
            out.push_str(text);
        }
    }

    out
}

fn rewrite_python_underscore_runs_in_text(text: &str) -> String {
    let mut out = String::with_capacity(text.len() + 16);
    let mut chars = text.char_indices().peekable();

    while let Some((_, ch)) = chars.next() {
        if ch != '_' {
            out.push(ch);
            continue;
        }

        let mut run_len = 1usize;
        while let Some((_, next_ch)) = chars.peek() {
            if *next_ch == '_' {
                run_len += 1;
                let _ = chars.next();
            } else {
                break;
            }
        }
        if run_len < 7 {
            for _ in 0..run_len {
                out.push('_');
            }
            continue;
        }

        let emphasis_groups = run_len / 7;
        let remainder = run_len % 7;
        for _ in 0..emphasis_groups {
            out.push_str("<strong><em>_</em></strong>");
        }
        for _ in 0..remainder {
            out.push('_');
        }
    }

    out
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ListContextKind {
    Blank,
    Paragraph,
    Listish,
    BlockBoundary,
}

fn preprocess_python_markdown_list_interruptions(
    markdown: &str,
    sane_lists: bool,
    shallow_sublists: bool,
) -> String {
    if markdown.is_empty() {
        return String::new();
    }

    let mut out = Vec::<Cow<'_, str>>::new();
    let trailing_newline = markdown.ends_with('\n');
    let mut in_fence = false;
    let mut prev_kind = ListContextKind::Blank;
    let mut prev_blank = true;
    let mut in_list_block = false;
    let mut last_list_kind: Option<ListKind> = None;
    let mut last_list_indent = 0usize;
    let mut last_bullet_marker: Option<u8> = None;
    let mut changed = false;

    for line in markdown.lines() {
        let trimmed_start = line.trim_start();
        let trimmed = line.trim();

        if is_fence_delimiter(trimmed_start) {
            in_fence = !in_fence;
            out.push(Cow::Borrowed(line));
            prev_kind = ListContextKind::BlockBoundary;
            prev_blank = false;
            in_list_block = false;
            last_list_kind = None;
            last_bullet_marker = None;
            continue;
        }

        if in_fence {
            out.push(Cow::Borrowed(line));
            if trimmed.is_empty() {
                prev_kind = ListContextKind::Blank;
                prev_blank = true;
            } else {
                prev_kind = ListContextKind::BlockBoundary;
                prev_blank = false;
            }
            in_list_block = false;
            last_list_kind = None;
            last_bullet_marker = None;
            continue;
        }

        if let Some(parsed) = parse_leading_list_marker(line) {
            let mut current_line = Cow::Borrowed(line);
            let mut marker = parsed.marker;
            let mut kind = parsed.kind;
            let mut indent = parsed.indent;
            let mut escaped = false;

            if sane_lists && shallow_sublists && in_list_block && indent > 0 && indent < 4 {
                if let Some(last_kind) = last_list_kind {
                    if kind == last_kind {
                        let dropped = drop_leading_indent(current_line.as_ref(), indent);
                        if dropped != current_line.as_ref() {
                            changed = true;
                        }
                        current_line = Cow::Owned(dropped);
                        if let Some(reparsed) = parse_leading_list_marker(current_line.as_ref()) {
                            marker = reparsed.marker;
                            kind = reparsed.kind;
                            indent = reparsed.indent;
                        }
                    } else if !prev_blank && kind != last_kind {
                        current_line =
                            Cow::Owned(escape_leading_list_marker(current_line.as_ref(), marker));
                        escaped = true;
                        changed = true;
                    }
                }
            }

            if !escaped
                && sane_lists
                && in_list_block
                && !prev_blank
                && matches!(last_list_kind, Some(last_kind) if kind != last_kind)
                && indent <= last_list_indent + 3
            {
                current_line =
                    Cow::Owned(escape_leading_list_marker(current_line.as_ref(), marker));
                escaped = true;
                changed = true;
            }

            if !escaped && prev_kind == ListContextKind::Paragraph && !in_list_block {
                current_line =
                    Cow::Owned(escape_leading_list_marker(current_line.as_ref(), marker));
                escaped = true;
                changed = true;
            }

            if !escaped
                && sane_lists
                && in_list_block
                && matches!(kind, ListKind::Bullet)
                && matches!(last_list_kind, Some(ListKind::Bullet))
                && let (Some(prev_marker), ListMarker::Bullet { idx, byte }) =
                    (last_bullet_marker, marker)
                && byte != prev_marker
            {
                current_line = Cow::Owned(replace_char_at(
                    current_line.as_ref(),
                    idx,
                    prev_marker as char,
                ));
                changed = true;
                if let Some(reparsed) = parse_leading_list_marker(current_line.as_ref()) {
                    marker = reparsed.marker;
                    kind = reparsed.kind;
                    indent = reparsed.indent;
                }
            }

            out.push(current_line);

            if escaped {
                prev_kind = ListContextKind::Paragraph;
                prev_blank = false;
            } else {
                prev_kind = ListContextKind::Listish;
                prev_blank = false;
                in_list_block = true;
                last_list_kind = Some(kind);
                last_list_indent = indent;
                last_bullet_marker = match marker {
                    ListMarker::Bullet { byte, .. } => Some(byte),
                    ListMarker::Ordered { .. } => None,
                };
            }
        } else {
            out.push(Cow::Borrowed(line));
            let had_blank_before = prev_blank;
            prev_kind = classify_line_context(trimmed_start, trimmed);
            if trimmed.is_empty() {
                prev_blank = true;
            } else {
                prev_blank = false;
            }

            if in_list_block && !trimmed.is_empty() {
                if prev_kind == ListContextKind::BlockBoundary {
                    in_list_block = false;
                    last_list_kind = None;
                    last_bullet_marker = None;
                } else if had_blank_before && leading_indent_width(line) < 2 {
                    in_list_block = false;
                    last_list_kind = None;
                    last_bullet_marker = None;
                }
            }
            if !in_list_block && prev_kind == ListContextKind::Paragraph {
                last_list_kind = None;
                last_bullet_marker = None;
            }
        }
    }

    if !changed {
        return markdown.to_string();
    }

    let mut merged = String::with_capacity(markdown.len() + 32);
    for (idx, line) in out.iter().enumerate() {
        merged.push_str(line.as_ref());
        if idx + 1 < out.len() {
            merged.push('\n');
        }
    }
    if trailing_newline {
        merged.push('\n');
    }
    merged
}

fn preprocess_python_list_marker_compat(markdown: &str) -> String {
    if markdown.is_empty() {
        return String::new();
    }
    if !markdown.contains(')')
        && !markdown.contains('.')
        && !markdown.contains('-')
        && !markdown.contains('*')
        && !markdown.contains('+')
    {
        return markdown.to_string();
    }

    let mut out = Vec::<Cow<'_, str>>::new();
    let trailing_newline = markdown.ends_with('\n');
    let mut in_fence = false;
    let mut changed = false;

    for line in markdown.lines() {
        let trimmed_start = line.trim_start();

        if is_fence_delimiter(trimmed_start) {
            in_fence = !in_fence;
            out.push(Cow::Borrowed(line));
            continue;
        }
        if in_fence {
            out.push(Cow::Borrowed(line));
            continue;
        }

        if let Some(punct_idx) = parse_leading_hanging_ordered_marker(line) {
            out.push(Cow::Owned(escape_char_at(line, punct_idx)));
            changed = true;
            continue;
        }

        if let Some(punct_idx) = parse_leading_ordered_paren_marker(line) {
            out.push(Cow::Owned(escape_char_at(line, punct_idx)));
            changed = true;
            continue;
        }

        if let Some(punct_idx) = parse_bullet_prefixed_ordered_paren_marker(line) {
            out.push(Cow::Owned(escape_char_at(line, punct_idx)));
            changed = true;
            continue;
        }

        if let Some(marker_idx) = parse_leading_bare_bullet_marker(line) {
            out.push(Cow::Owned(escape_char_at(line, marker_idx)));
            changed = true;
            continue;
        }

        out.push(Cow::Borrowed(line));
    }

    if !changed {
        return markdown.to_string();
    }

    let mut merged = String::with_capacity(markdown.len() + 16);
    for (idx, line) in out.iter().enumerate() {
        merged.push_str(line.as_ref());
        if idx + 1 < out.len() {
            merged.push('\n');
        }
    }
    if trailing_newline {
        merged.push('\n');
    }
    merged
}

fn has_python_mixed_list_continuation_candidates(markdown: &str) -> bool {
    for line in markdown.lines() {
        if is_ordered_inline_bullet_candidate(line) || is_bullet_prefixed_numbered_candidate(line) {
            return true;
        }
    }
    false
}

fn is_ordered_inline_bullet_candidate(line: &str) -> bool {
    let bytes = line.as_bytes();
    let mut i = 0usize;

    while i < bytes.len() && (bytes[i] == b' ' || bytes[i] == b'\t') {
        i += 1;
    }
    if i >= bytes.len() || !bytes[i].is_ascii_digit() {
        return false;
    }
    while i < bytes.len() && bytes[i].is_ascii_digit() {
        i += 1;
    }
    if i >= bytes.len() || bytes[i] != b'.' {
        return false;
    }
    i += 1;

    if i >= bytes.len() || !bytes[i].is_ascii_whitespace() {
        return false;
    }
    while i < bytes.len() && bytes[i].is_ascii_whitespace() {
        i += 1;
    }
    if i >= bytes.len() || !matches!(bytes[i], b'*' | b'+' | b'-') {
        return false;
    }
    i += 1;

    if i >= bytes.len() || !bytes[i].is_ascii_whitespace() {
        return false;
    }
    while i < bytes.len() && bytes[i].is_ascii_whitespace() {
        i += 1;
    }

    i < bytes.len()
}

fn is_bullet_prefixed_numbered_candidate(line: &str) -> bool {
    let bytes = line.as_bytes();
    let mut i = 0usize;

    while i < bytes.len() && (bytes[i] == b' ' || bytes[i] == b'\t') {
        i += 1;
    }
    if i >= bytes.len() || !matches!(bytes[i], b'*' | b'+' | b'-') {
        return false;
    }
    i += 1;

    if i >= bytes.len() || !bytes[i].is_ascii_whitespace() {
        return false;
    }
    while i < bytes.len() && bytes[i].is_ascii_whitespace() {
        i += 1;
    }
    if i >= bytes.len() || !bytes[i].is_ascii_digit() {
        return false;
    }
    while i < bytes.len() && bytes[i].is_ascii_digit() {
        i += 1;
    }
    if i >= bytes.len() || bytes[i] != b'.' {
        return false;
    }
    i += 1;

    if i >= bytes.len() || !bytes[i].is_ascii_whitespace() {
        return false;
    }
    while i < bytes.len() && bytes[i].is_ascii_whitespace() {
        i += 1;
    }

    i < bytes.len()
}

fn preprocess_python_mixed_list_continuations(markdown: &str) -> String {
    if markdown.is_empty() {
        return String::new();
    }
    if !has_python_mixed_list_continuation_candidates(markdown) {
        return markdown.to_string();
    }

    let lines: Vec<&str> = markdown.lines().collect();
    let trailing_newline = markdown.ends_with('\n');
    let mut out = Vec::<Cow<'_, str>>::with_capacity(lines.len() + 8);
    let mut in_fence = false;
    let mut i = 0usize;
    let mut changed = false;

    while i < lines.len() {
        let line = lines[i];
        let trimmed_start = line.trim_start();

        if is_fence_delimiter(trimmed_start) {
            in_fence = !in_fence;
            out.push(Cow::Borrowed(line));
            i += 1;
            continue;
        }
        if in_fence {
            out.push(Cow::Borrowed(line));
            i += 1;
            continue;
        }

        if let Some(caps) = ORDERED_INLINE_BULLET_RE.captures(line) {
            let indent = caps.get(1).map(|m| m.as_str()).unwrap_or_default();
            let ordered_marker = caps.get(2).map(|m| m.as_str()).unwrap_or_default();
            let nested_bullet = caps.get(3).map(|m| m.as_str()).unwrap_or_default();
            out.push(Cow::Owned(format!("{indent}{ordered_marker}")));
            out.push(Cow::Owned(format!("{indent}    {nested_bullet}")));
            changed = true;
            i += 1;
            while i < lines.len() {
                let next = lines[i];
                if next.trim().is_empty() {
                    out.push(Cow::Borrowed(next));
                    i += 1;
                    break;
                }
                if let Some(next_caps) = BULLET_LINE_RE.captures(next) {
                    let next_indent_len = next_caps.get(1).map(|m| m.as_str().len()).unwrap_or(0);
                    if next_indent_len <= indent.len() {
                        let marker = next_caps.get(2).map(|m| m.as_str()).unwrap_or_default();
                        let body = next_caps.get(3).map(|m| m.as_str()).unwrap_or_default();
                        out.push(Cow::Owned(format!("{indent}    {marker} {body}")));
                        i += 1;
                        continue;
                    }
                }
                break;
            }
            continue;
        }

        if let Some(caps) = BULLET_PREFIXED_NUMBERED_RE.captures(line) {
            let indent = caps.get(1).map(|m| m.as_str()).unwrap_or_default();
            out.push(Cow::Borrowed(line));
            i += 1;
            while i < lines.len() {
                let next = lines[i];
                if next.trim().is_empty() {
                    out.push(Cow::Borrowed(next));
                    i += 1;
                    break;
                }
                if let Some(next_caps) = NUMBERED_LINE_RE.captures(next) {
                    let next_indent_len = next_caps.get(1).map(|m| m.as_str().len()).unwrap_or(0);
                    if next_indent_len <= indent.len() {
                        let marker = next_caps.get(2).map(|m| m.as_str()).unwrap_or_default();
                        let body = next_caps.get(3).map(|m| m.as_str()).unwrap_or_default();
                        out.push(Cow::Owned(format!("{indent}    {marker} {body}")));
                        changed = true;
                        i += 1;
                        continue;
                    }
                }
                break;
            }
            continue;
        }

        out.push(Cow::Borrowed(line));
        i += 1;
    }

    if !changed {
        return markdown.to_string();
    }

    let mut merged = String::with_capacity(markdown.len() + 32);
    for (idx, line) in out.iter().enumerate() {
        merged.push_str(line.as_ref());
        if idx + 1 < out.len() {
            merged.push('\n');
        }
    }
    if trailing_newline {
        merged.push('\n');
    }
    merged
}

fn parse_leading_ordered_paren_marker(line: &str) -> Option<usize> {
    let bytes = line.as_bytes();
    let mut i = 0usize;
    while i < bytes.len() && (bytes[i] == b' ' || bytes[i] == b'\t') {
        i += 1;
    }
    if i >= bytes.len() || !bytes[i].is_ascii_digit() {
        return None;
    }
    let mut j = i + 1;
    while j < bytes.len() && bytes[j].is_ascii_digit() {
        j += 1;
    }
    if j >= bytes.len() || bytes[j] != b')' {
        return None;
    }
    if j + 1 < bytes.len() && !bytes[j + 1].is_ascii_whitespace() {
        return None;
    }
    Some(j)
}

fn parse_leading_hanging_ordered_marker(line: &str) -> Option<usize> {
    let bytes = line.as_bytes();
    let mut i = 0usize;

    while i < bytes.len() && (bytes[i] == b' ' || bytes[i] == b'\t') {
        i += 1;
    }
    if i >= bytes.len() || !bytes[i].is_ascii_digit() {
        return None;
    }

    let mut j = i + 1;
    while j < bytes.len() && bytes[j].is_ascii_digit() {
        j += 1;
    }
    if j >= bytes.len() || !matches!(bytes[j], b'.' | b')') {
        return None;
    }

    let mut k = j + 1;
    while k < bytes.len() {
        if !bytes[k].is_ascii_whitespace() {
            return None;
        }
        k += 1;
    }

    Some(j)
}

fn parse_leading_bare_bullet_marker(line: &str) -> Option<usize> {
    let bytes = line.as_bytes();
    let mut i = 0usize;
    while i < bytes.len() && (bytes[i] == b' ' || bytes[i] == b'\t') {
        i += 1;
    }
    if i >= bytes.len() {
        return None;
    }
    if !matches!(bytes[i], b'-' | b'+' | b'*') {
        return None;
    }
    if i + 1 != bytes.len() {
        return None;
    }
    Some(i)
}

fn parse_bullet_prefixed_ordered_paren_marker(line: &str) -> Option<usize> {
    let bytes = line.as_bytes();
    let mut i = 0usize;
    while i < bytes.len() && (bytes[i] == b' ' || bytes[i] == b'\t') {
        i += 1;
    }
    if i >= bytes.len() || !matches!(bytes[i], b'-' | b'+' | b'*') {
        return None;
    }
    i += 1;
    if i >= bytes.len() || !bytes[i].is_ascii_whitespace() {
        return None;
    }
    while i < bytes.len() && bytes[i].is_ascii_whitespace() {
        i += 1;
    }
    if i >= bytes.len() || !bytes[i].is_ascii_digit() {
        return None;
    }
    while i < bytes.len() && bytes[i].is_ascii_digit() {
        i += 1;
    }
    if i >= bytes.len() || bytes[i] != b')' {
        return None;
    }
    if i + 1 >= bytes.len() || !bytes[i + 1].is_ascii_whitespace() {
        return None;
    }
    Some(i)
}

fn escape_char_at(line: &str, idx: usize) -> String {
    let mut s = String::with_capacity(line.len() + 1);
    s.push_str(&line[..idx]);
    s.push('\\');
    s.push(line.as_bytes()[idx] as char);
    s.push_str(&line[idx + 1..]);
    s
}

fn replace_char_at(line: &str, idx: usize, ch: char) -> String {
    let mut s = String::with_capacity(line.len());
    s.push_str(&line[..idx]);
    s.push(ch);
    s.push_str(&line[idx + 1..]);
    s
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ListMarker {
    Bullet { idx: usize, byte: u8 },
    Ordered { punct_idx: usize },
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ListKind {
    Bullet,
    Ordered,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct ParsedListMarker {
    marker: ListMarker,
    kind: ListKind,
    indent: usize,
}

fn parse_leading_list_marker(line: &str) -> Option<ParsedListMarker> {
    let bytes = line.as_bytes();
    let mut i = 0usize;

    while i < bytes.len() && (bytes[i] == b' ' || bytes[i] == b'\t') {
        i += 1;
    }
    if i >= bytes.len() {
        return None;
    }

    if matches!(bytes[i], b'*' | b'+' | b'-') {
        if i + 1 < bytes.len() && bytes[i + 1].is_ascii_whitespace() {
            return Some(ParsedListMarker {
                marker: ListMarker::Bullet {
                    idx: i,
                    byte: bytes[i],
                },
                kind: ListKind::Bullet,
                indent: i,
            });
        }
        return None;
    }

    if bytes[i].is_ascii_digit() {
        let mut j = i + 1;
        while j < bytes.len() && bytes[j].is_ascii_digit() {
            j += 1;
        }
        if j < bytes.len()
            && matches!(bytes[j], b'.' | b')')
            && j + 1 < bytes.len()
            && bytes[j + 1].is_ascii_whitespace()
        {
            return Some(ParsedListMarker {
                marker: ListMarker::Ordered { punct_idx: j },
                kind: ListKind::Ordered,
                indent: i,
            });
        }
    }

    None
}

fn drop_leading_indent(line: &str, indent: usize) -> String {
    let mut cut = 0usize;
    let bytes = line.as_bytes();
    while cut < indent && cut < bytes.len() && (bytes[cut] == b' ' || bytes[cut] == b'\t') {
        cut += 1;
    }
    line[cut..].to_string()
}

fn leading_indent_width(line: &str) -> usize {
    let mut i = 0usize;
    let bytes = line.as_bytes();
    while i < bytes.len() && (bytes[i] == b' ' || bytes[i] == b'\t') {
        i += 1;
    }
    i
}

fn escape_leading_list_marker(line: &str, marker: ListMarker) -> String {
    match marker {
        ListMarker::Bullet { idx, byte } => {
            let mut s = String::with_capacity(line.len() + 1);
            s.push_str(&line[..idx]);
            s.push('\\');
            s.push(byte as char);
            s.push_str(&line[idx + 1..]);
            s
        }
        ListMarker::Ordered { punct_idx } => {
            let mut s = String::with_capacity(line.len() + 1);
            s.push_str(&line[..punct_idx]);
            s.push('\\');
            s.push(line.as_bytes()[punct_idx] as char);
            s.push_str(&line[punct_idx + 1..]);
            s
        }
    }
}

fn classify_line_context(trimmed_start: &str, trimmed: &str) -> ListContextKind {
    if trimmed.is_empty() {
        return ListContextKind::Blank;
    }
    if parse_leading_list_marker(trimmed_start).is_some() {
        return ListContextKind::Listish;
    }
    if ATX_HEADING_RE.is_match(trimmed_start) || SETEXT_UNDERLINE_RE.is_match(trimmed) {
        return ListContextKind::BlockBoundary;
    }
    if BLOCK_BOUNDARY_RE.is_match(trimmed_start) {
        return ListContextKind::BlockBoundary;
    }
    ListContextKind::Paragraph
}

fn is_fence_delimiter(trimmed_start: &str) -> bool {
    trimmed_start.starts_with("```") || trimmed_start.starts_with("~~~")
}

fn preprocess_heading_attr_lists(markdown: &str) -> (String, Vec<AttrSpec>) {
    let mut out = Vec::new();
    let mut specs = Vec::new();
    for line in markdown.lines() {
        if let Some(caps) = HEADING_ATTR_RE.captures(line) {
            let head = caps.get(1).map(|m| m.as_str()).unwrap_or(line);
            let attrs = caps.get(2).map(|m| m.as_str()).unwrap_or("");
            out.push(head.to_string());
            specs.push(parse_attr_spec(attrs));
        } else {
            out.push(line.to_string());
        }
    }
    (out.join("\n"), specs)
}

fn preprocess_wikilinks(markdown: &str, cfg: &WikilinkConfig) -> String {
    WIKILINK_RE
        .replace_all(markdown, |caps: &Captures<'_>| {
            let page = caps
                .get(1)
                .map(|m| m.as_str().trim())
                .unwrap_or_default()
                .to_string();
            let label = caps
                .get(2)
                .map(|m| m.as_str().trim())
                .filter(|s| !s.is_empty())
                .unwrap_or(page.as_str());

            let mut href = String::new();
            href.push_str(&cfg.base_url);
            href.push_str(&page.replace(' ', "_"));
            href.push_str(&cfg.end_url);

            let class_attr = if cfg.html_class.is_empty() {
                String::new()
            } else {
                format!(" class=\"{}\"", escape_attr(&cfg.html_class))
            };

            format!(
                "<a{class_attr} href=\"{}\">{}</a>",
                escape_attr(&href),
                escape_html_text(label)
            )
        })
        .into_owned()
}

fn preprocess_admonitions(markdown: &str) -> (String, Vec<AdmonitionBlock>) {
    let lines: Vec<&str> = markdown.lines().collect();
    let mut out = Vec::new();
    let mut blocks = Vec::new();
    let mut i = 0usize;

    while i < lines.len() {
        let line = lines[i];
        let Some(caps) = ADMONITION_START_RE.captures(line) else {
            out.push(line.to_string());
            i += 1;
            continue;
        };

        let class_name = caps
            .get(2)
            .map(|m| m.as_str().trim().to_ascii_lowercase())
            .filter(|s| !s.is_empty())
            .unwrap_or_else(|| "note".to_string());
        let title = caps
            .get(3)
            .map(|m| m.as_str().trim().to_string())
            .unwrap_or_else(|| sentence_case(&class_name));

        i += 1;
        let mut body_lines = Vec::new();
        while i < lines.len() {
            let line = lines[i];
            if line.starts_with("    ") {
                body_lines.push(line[4..].to_string());
                i += 1;
                continue;
            }
            if line.starts_with('\t') {
                body_lines.push(line[1..].to_string());
                i += 1;
                continue;
            }
            if line.trim().is_empty()
                && i + 1 < lines.len()
                && (lines[i + 1].starts_with("    ") || lines[i + 1].starts_with('\t'))
            {
                body_lines.push(String::new());
                i += 1;
                continue;
            }
            break;
        }

        let placeholder = format!("MDRS_ADMONITION_{}_PLACEHOLDER", blocks.len());
        blocks.push(AdmonitionBlock {
            placeholder: placeholder.clone(),
            class_name,
            title,
            body_markdown: body_lines.join("\n"),
        });
        out.push(placeholder);
    }

    (out.join("\n"), blocks)
}

fn inject_admonitions(
    html: &str,
    blocks: &[AdmonitionBlock],
    options: &MarkdownToHtmlOptions,
    extension_set: &HashSet<String>,
) -> String {
    let mut out = html.to_string();
    let mut nested_set = extension_set.clone();
    nested_set.remove("admonition");

    for block in blocks {
        let inner = render_with_comrak(&block.body_markdown, options, &nested_set)
            .trim()
            .to_string();
        let replacement = format!(
            "<div class=\"admonition {}\">\n<p class=\"admonition-title\">{}</p>\n{}\n</div>",
            escape_attr(&block.class_name),
            escape_html_text(&block.title),
            inner
        );
        let paragraph_marker = format!("<p>{}</p>", block.placeholder);
        out = out.replace(&paragraph_marker, &replacement);
        out = out.replace(&block.placeholder, &replacement);
    }
    out
}

fn rewrite_headings(
    html: &str,
    attr_specs: &[AttrSpec],
    toc_enabled: bool,
    extension_configs: &HashMap<String, HashMap<String, String>>,
) -> (String, Vec<TocToken>) {
    let mut out = String::with_capacity(html.len() + 128);
    let bytes = html.as_bytes();
    let mut i = 0usize;
    let mut last_written = 0usize;
    let mut slug_counts = HashMap::<String, usize>::new();
    let mut toc_tokens = Vec::new();
    let mut heading_idx = 0usize;
    let slugify_unicode = extension_configs
        .get("toc")
        .and_then(|cfg| cfg.get("slugify_unicode"))
        .map(|v| parse_bool(v))
        .unwrap_or(false);

    while i + 4 < bytes.len() {
        let is_open_heading = bytes[i] == b'<'
            && (bytes[i + 1] == b'h' || bytes[i + 1] == b'H')
            && (b'1'..=b'6').contains(&bytes[i + 2]);
        if !is_open_heading {
            i += 1;
            continue;
        }

        let level = (bytes[i + 2] - b'0') as usize;
        let mut open_end = i + 3;
        while open_end < bytes.len() && bytes[open_end] != b'>' {
            open_end += 1;
        }
        if open_end >= bytes.len() {
            break;
        }

        let attrs = html[i + 3..open_end].to_string();
        let close_tag = format!("</h{level}>");
        let body_start = open_end + 1;
        let Some(close_rel) = html[body_start..].find(&close_tag) else {
            i = body_start;
            continue;
        };
        let close_start = body_start + close_rel;
        let close_end = close_start + close_tag.len();
        let body_html = &html[body_start..close_start];

        out.push_str(&html[last_written..i]);

        let spec = attr_specs.get(heading_idx);
        heading_idx += 1;

        let title_text = decode_basic_entities(strip_tags(body_html).trim());
        let mut heading_id = extract_attr_value(&attrs, "id");
        if heading_id.is_none() {
            if let Some(spec_id) = spec.and_then(|s| s.id.clone()) {
                heading_id = Some(spec_id);
            } else if toc_enabled {
                let slug = unique_slug(slugify(&title_text, slugify_unicode), &mut slug_counts);
                heading_id = Some(slug);
            }
        }

        let mut attrs_out = attrs;
        if let Some(spec) = spec {
            if !spec.classes.is_empty() && !has_attr(&attrs_out, "class") {
                attrs_out.push_str(&format!(
                    " class=\"{}\"",
                    escape_attr(&spec.classes.join(" "))
                ));
            }
            for (k, v) in &spec.attrs {
                if !has_attr(&attrs_out, k) {
                    attrs_out.push_str(&format!(" {}=\"{}\"", k, escape_attr(v)));
                }
            }
        }

        if let Some(id) = &heading_id {
            if !has_attr(&attrs_out, "id") {
                attrs_out.push_str(&format!(" id=\"{}\"", escape_attr(id)));
            }
            if toc_enabled {
                toc_tokens.push(TocToken {
                    level,
                    id: id.clone(),
                    name: title_text.clone(),
                });
            }
        }

        out.push_str(&format!("<h{level}{attrs_out}>"));
        out.push_str(body_html);
        out.push_str(&close_tag);

        last_written = close_end;
        i = close_end;
    }

    if last_written < html.len() {
        out.push_str(&html[last_written..]);
    }

    (out, toc_tokens)
}

fn build_toc_html(tokens: &[TocToken], cfg: &TocConfig) -> String {
    if tokens.is_empty() {
        return String::new();
    }

    let base_level = tokens.first().map(|t| t.level).unwrap_or(1);
    let relative_depth = |level: usize| -> usize {
        if level <= base_level {
            1
        } else {
            (level - base_level) + 1
        }
    };

    let mut out = String::new();
    out.push_str(&format!("<div class=\"{}\">", escape_attr(&cfg.toc_class)));
    if let Some(title) = &cfg.title {
        out.push_str(&format!(
            "\n<span class=\"toctitle\">{}</span>",
            escape_html_text(title)
        ));
    }

    let first = &tokens[0];
    let mut depth = 1usize;
    out.push_str("\n<ul>");
    out.push_str(&format!(
        "\n<li><a href=\"#{}\">{}</a>",
        escape_attr(&first.id),
        escape_html_text(&first.name)
    ));

    for token in tokens.iter().skip(1) {
        let target_depth = relative_depth(token.level);
        if target_depth > depth {
            while depth < target_depth {
                out.push_str("\n<ul>");
                depth += 1;
            }
            out.push_str(&format!(
                "\n<li><a href=\"#{}\">{}</a>",
                escape_attr(&token.id),
                escape_html_text(&token.name)
            ));
            continue;
        }

        out.push_str("</li>");
        while depth > target_depth {
            out.push_str("\n</ul></li>");
            depth -= 1;
        }
        out.push_str(&format!(
            "\n<li><a href=\"#{}\">{}</a>",
            escape_attr(&token.id),
            escape_html_text(&token.name)
        ));
    }

    out.push_str("</li>");
    while depth > 1 {
        out.push_str("\n</ul></li>");
        depth -= 1;
    }
    out.push_str("\n</ul>\n</div>");
    out
}

fn replace_toc_markers(html: &str, toc_html: &str) -> String {
    TOC_MARKER_RE.replace_all(html, toc_html).into_owned()
}

fn apply_codehilite(html: &str, cfg: &CodeHiliteConfig) -> String {
    PRE_CODE_RE
        .replace_all(html, |caps: &Captures<'_>| {
            let attrs = caps.get(1).map(|m| m.as_str()).unwrap_or("");
            let body = caps.get(2).map(|m| m.as_str()).unwrap_or("");
            let rewritten_attrs = rewrite_lang_prefix(attrs, &cfg.lang_prefix);
            format!(
                "<div class=\"{}\"><pre><code{}>{}</code></pre></div>",
                escape_attr(&cfg.css_class),
                rewritten_attrs,
                body
            )
        })
        .into_owned()
}

fn downgrade_fenced_code_blocks_without_fenced_code(html: &str) -> String {
    PRE_CODE_WITH_LANG_RE
        .replace_all(html, |caps: &Captures<'_>| {
            let lang = caps.get(1).map(|m| m.as_str()).unwrap_or("");
            let body = caps
                .get(2)
                .map(|m| m.as_str())
                .unwrap_or("")
                .trim_end_matches('\n');
            let mut code = String::new();
            code.push_str(lang);
            if !body.is_empty() {
                code.push('\n');
                code.push_str(body);
            }
            format!("<p><code>{}</code></p>", escape_html_text(&code))
        })
        .into_owned()
}

fn apply_python_markdown_footnote_shape(html: &str) -> String {
    let mut out = html.replace(
        "<section class=\"footnotes\" data-footnotes>",
        "<div class=\"footnote\">\n<hr />",
    );
    out = out.replace("</section>", "</div>");

    out = FOOTNOTE_REF_RE
        .replace_all(&out, |caps: &Captures<'_>| {
            let ref_id = caps.get(2).map(|m| m.as_str()).unwrap_or_default();
            let foot_id = caps.get(1).map(|m| m.as_str()).unwrap_or_default();
            let number = caps.get(3).map(|m| m.as_str()).unwrap_or_default();
            format!(
                "<sup id=\"fnref:{ref_id}\"><a class=\"footnote-ref\" href=\"#fn:{foot_id}\">{number}</a></sup>"
            )
        })
        .into_owned();

    out = FOOTNOTE_ITEM_ID_RE
        .replace_all(&out, |caps: &Captures<'_>| {
            let id = caps.get(1).map(|m| m.as_str()).unwrap_or_default();
            format!("<li id=\"fn:{id}\">")
        })
        .into_owned();

    out = FOOTNOTE_BACKREF_RE
        .replace_all(&out, |caps: &Captures<'_>| {
            let id = caps.get(1).map(|m| m.as_str()).unwrap_or_default();
            let note_num = id.split('-').next().unwrap_or(id);
            format!(
                "<a class=\"footnote-backref\" href=\"#fnref:{id}\" title=\"Jump back to footnote {note_num} in the text\">&#8617;</a>"
            )
        })
        .into_owned();

    FOOTNOTE_BACKREF_SPACE_RE
        .replace_all(&out, |caps: &Captures<'_>| {
            let body = caps.get(1).map(|m| m.as_str()).unwrap_or_default();
            let anchor = caps.get(2).map(|m| m.as_str()).unwrap_or_default();
            format!("<p>{body}&#160;{anchor}")
        })
        .into_owned()
}

fn rewrite_lang_prefix(attrs: &str, lang_prefix: &str) -> String {
    if lang_prefix == "language-" {
        return attrs.to_string();
    }
    LANGUAGE_CLASS_RE
        .replace(attrs, |caps: &Captures<'_>| {
            let classes = caps.get(1).map(|m| m.as_str()).unwrap_or("");
            let rewritten = classes.replace("language-", lang_prefix);
            format!("class=\"{}\"", escape_attr(&rewritten))
        })
        .to_string()
}

fn apply_abbreviations(html: &str, abbreviations: &[(String, String)]) -> String {
    let mut out = String::with_capacity(html.len() + 64);
    let mut i = 0usize;
    let bytes = html.as_bytes();
    let mut skip_depth = 0usize;

    while i < bytes.len() {
        if bytes[i] == b'<' {
            let start = i;
            while i < bytes.len() && bytes[i] != b'>' {
                i += 1;
            }
            if i < bytes.len() {
                i += 1;
            }
            let tag = &html[start..i];
            update_skip_depth(tag, &mut skip_depth);
            out.push_str(tag);
            continue;
        }

        let start = i;
        while i < bytes.len() && bytes[i] != b'<' {
            i += 1;
        }
        let text = &html[start..i];
        if skip_depth == 0 {
            out.push_str(&replace_abbreviations_in_text(text, abbreviations));
        } else {
            out.push_str(text);
        }
    }

    out
}

fn replace_abbreviations_in_text(text: &str, abbreviations: &[(String, String)]) -> String {
    let mut current = text.to_string();
    for (abbr, title) in abbreviations {
        if abbr.is_empty() {
            continue;
        }
        let mut replaced = String::with_capacity(current.len());
        let mut idx = 0usize;
        while let Some(found) = current[idx..].find(abbr) {
            let start = idx + found;
            let end = start + abbr.len();
            if !is_word_boundary(&current, start, end) {
                replaced.push_str(&current[idx..end]);
                idx = end;
                continue;
            }
            replaced.push_str(&current[idx..start]);
            replaced.push_str(&format!(
                "<abbr title=\"{}\">{}</abbr>",
                escape_attr(title),
                escape_html_text(abbr)
            ));
            idx = end;
        }
        replaced.push_str(&current[idx..]);
        current = replaced;
    }
    current
}

fn is_word_boundary(text: &str, start: usize, end: usize) -> bool {
    let prev_ok = text[..start]
        .chars()
        .next_back()
        .map(|c| !is_word_char(c))
        .unwrap_or(true);
    let next_ok = text[end..]
        .chars()
        .next()
        .map(|c| !is_word_char(c))
        .unwrap_or(true);
    prev_ok && next_ok
}

fn is_word_char(c: char) -> bool {
    c.is_alphanumeric() || c == '_'
}

fn update_skip_depth(tag: &str, depth: &mut usize) {
    let lower = tag.to_ascii_lowercase();
    let starts = lower.starts_with("<pre")
        || lower.starts_with("<code")
        || lower.starts_with("<script")
        || lower.starts_with("<style");
    let ends = lower.starts_with("</pre")
        || lower.starts_with("</code")
        || lower.starts_with("</script")
        || lower.starts_with("</style");
    if starts && !lower.starts_with("</") {
        *depth += 1;
    } else if ends && *depth > 0 {
        *depth -= 1;
    }
}

fn parse_attr_spec(raw: &str) -> AttrSpec {
    let mut spec = AttrSpec::default();
    for token in split_attr_tokens(raw) {
        if let Some(id) = token.strip_prefix('#') {
            if !id.is_empty() {
                spec.id = Some(id.to_string());
            }
            continue;
        }
        if let Some(class) = token.strip_prefix('.') {
            if !class.is_empty() {
                spec.classes.push(class.to_string());
            }
            continue;
        }
        if let Some((key, value)) = token.split_once('=') {
            let key = key.trim();
            if !key.is_empty() {
                spec.attrs
                    .push((key.to_string(), trim_wrapped_quotes(value.trim())));
            }
            continue;
        }
        let key = token.trim();
        if !key.is_empty() {
            spec.attrs.push((key.to_string(), key.to_string()));
        }
    }
    spec
}

fn split_attr_tokens(raw: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let mut buf = String::new();
    let mut quote = None::<char>;

    for ch in raw.chars() {
        if let Some(q) = quote {
            buf.push(ch);
            if ch == q {
                quote = None;
            }
            continue;
        }

        if ch == '"' || ch == '\'' {
            quote = Some(ch);
            buf.push(ch);
            continue;
        }

        if ch.is_whitespace() {
            if !buf.trim().is_empty() {
                tokens.push(buf.trim().to_string());
            }
            buf.clear();
            continue;
        }
        buf.push(ch);
    }

    if !buf.trim().is_empty() {
        tokens.push(buf.trim().to_string());
    }

    tokens
}

fn trim_wrapped_quotes(value: &str) -> String {
    let mut chars = value.chars();
    let first = chars.next();
    let last = value.chars().next_back();
    if matches!(
        (first, last),
        (Some('"'), Some('"')) | (Some('\''), Some('\''))
    ) && value.len() >= 2
    {
        value[1..value.len() - 1].to_string()
    } else {
        value.to_string()
    }
}

fn has_attr(attrs: &str, key: &str) -> bool {
    let key = key.to_ascii_lowercase();
    let needle = format!("{key}=");
    attrs.to_ascii_lowercase().contains(&needle)
}

fn extract_attr_value(attrs: &str, key: &str) -> Option<String> {
    let key_lower = key.to_ascii_lowercase();
    let lower = attrs.to_ascii_lowercase();
    let needle = format!("{key_lower}=\"");
    let start = lower.find(&needle)?;
    let value_start = start + needle.len();
    let rem = &attrs[value_start..];
    let end_rel = rem.find('"')?;
    Some(rem[..end_rel].to_string())
}

fn slugify(text: &str, allow_unicode: bool) -> String {
    let mut out = String::new();
    let mut prev_dash = false;
    for ch in text.chars() {
        let ch = ch.to_ascii_lowercase();
        let keep = ch.is_ascii_alphanumeric() || ch == '_' || ch == '-';
        let space_like = ch.is_whitespace() || ch == '-';
        if keep {
            out.push(ch);
            prev_dash = false;
        } else if allow_unicode && ch.is_alphanumeric() {
            out.push(ch);
            prev_dash = false;
        } else if space_like && !prev_dash && !out.is_empty() {
            out.push('-');
            prev_dash = true;
        }
    }
    while out.ends_with('-') {
        let _ = out.pop();
    }
    if out.is_empty() {
        "section".to_string()
    } else {
        out
    }
}

fn unique_slug(base: String, counts: &mut HashMap<String, usize>) -> String {
    let count = counts.entry(base.clone()).or_insert(0usize);
    if *count == 0 {
        *count += 1;
        base
    } else {
        let out = format!("{}_{}", base, *count);
        *count += 1;
        out
    }
}

fn strip_tags(html: &str) -> String {
    TAG_STRIP_RE.replace_all(html, "").into_owned()
}

fn decode_basic_entities(text: &str) -> String {
    text.replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
}

fn encode_smarty_entities(html: &str) -> String {
    html.replace('“', "&ldquo;")
        .replace('”', "&rdquo;")
        .replace('‘', "&lsquo;")
        .replace('’', "&rsquo;")
        .replace('–', "&ndash;")
        .replace('—', "&mdash;")
        .replace('…', "&hellip;")
}

fn normalize_output_format(html: &str, format: OutputFormat) -> String {
    match format {
        OutputFormat::Xhtml => html.to_string(),
        OutputFormat::Html => html
            .replace("<br />", "<br>")
            .replace("<hr />", "<hr>")
            .replace(" />", ">"),
    }
}

fn parse_bool(raw: &str) -> bool {
    matches!(
        raw.trim().to_ascii_lowercase().as_str(),
        "1" | "true" | "yes" | "y" | "on"
    )
}

fn sentence_case(input: &str) -> String {
    let mut chars = input.chars();
    let Some(first) = chars.next() else {
        return String::new();
    };
    let mut out = first.to_ascii_uppercase().to_string();
    out.push_str(chars.as_str());
    out
}

fn wikilink_config(extension_configs: &HashMap<String, HashMap<String, String>>) -> WikilinkConfig {
    let mut cfg = WikilinkConfig::default();
    if let Some(raw) = extension_configs.get("wikilinks") {
        if let Some(v) = raw.get("base_url") {
            cfg.base_url = v.clone();
        }
        if let Some(v) = raw.get("end_url") {
            cfg.end_url = v.clone();
        }
        if let Some(v) = raw.get("html_class") {
            cfg.html_class = v.clone();
        }
    }
    cfg
}

fn toc_config(extension_configs: &HashMap<String, HashMap<String, String>>) -> TocConfig {
    let mut cfg = TocConfig::default();
    if let Some(raw) = extension_configs.get("toc") {
        if let Some(v) = raw.get("toc_class") {
            cfg.toc_class = v.clone();
        }
        if let Some(v) = raw.get("title") {
            let value = v.trim();
            if !value.is_empty() {
                cfg.title = Some(value.to_string());
            }
        }
    }
    cfg
}

fn codehilite_config(
    extension_configs: &HashMap<String, HashMap<String, String>>,
) -> CodeHiliteConfig {
    let mut cfg = CodeHiliteConfig::default();
    if let Some(raw) = extension_configs.get("codehilite") {
        if let Some(v) = raw.get("css_class") {
            cfg.css_class = v.clone();
        }
        if let Some(v) = raw.get("lang_prefix") {
            cfg.lang_prefix = v.clone();
        }
    }
    cfg
}

fn escape_attr(text: &str) -> String {
    text.replace('&', "&amp;")
        .replace('"', "&quot;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
}

fn escape_html_text(text: &str) -> String {
    text.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
}

#[cfg(test)]
mod tests {
    use super::{
        MarkdownMode, MarkdownToHtmlOptions, OutputFormat, markdown_to_html,
        markdown_to_html_with_artifacts, markdown_to_html_with_options,
    };
    use std::collections::{HashMap, HashSet};

    fn options_with_extensions(exts: &[&str]) -> MarkdownToHtmlOptions {
        let mut extensions = HashSet::new();
        for ext in exts {
            extensions.insert((*ext).to_string());
        }
        MarkdownToHtmlOptions {
            extensions,
            ..Default::default()
        }
    }

    fn fast_options_with_extensions(exts: &[&str]) -> MarkdownToHtmlOptions {
        let mut opts = options_with_extensions(exts);
        opts.mode = MarkdownMode::Fast;
        opts
    }

    #[test]
    fn basic_markdown_renders() {
        let html = markdown_to_html("# Hello\n\nWorld");
        assert!(html.contains("<h1>Hello</h1>"));
        assert!(html.contains("<p>World</p>"));
    }

    #[test]
    fn tables_extension_renders_table() {
        let md = "| a | b |\n| - | - |\n| 1 | 2 |";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["tables"]));
        assert!(html.contains("<table>"));
    }

    #[test]
    fn footnotes_extension_renders_footnotes() {
        let md = "Test[^1]\n\n[^1]: Note";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["footnotes"]));
        assert!(html.contains("footnote"));
    }

    #[test]
    fn attr_list_on_headings_adds_id() {
        let md = "# Title {#custom-id}\n";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["attr_list"]));
        assert!(html.contains("id=\"custom-id\""));
    }

    #[test]
    fn toc_generates_ids_and_inserts_marker() {
        let mut opts = options_with_extensions(&["toc"]);
        opts.output_format = OutputFormat::Html;
        let md = "[TOC]\n\n# One\n\n## Two";
        let html = markdown_to_html_with_options(md, opts);
        assert!(html.contains("<div class=\"toc\">"));
        assert!(html.contains("href=\"#one\""));
        assert!(html.contains("href=\"#two\""));
    }

    #[test]
    fn meta_extension_collects_meta() {
        let md = "Title: Doc\nTags: A, B\n\n# Heading";
        let (html, artifacts) =
            markdown_to_html_with_artifacts(md, options_with_extensions(&["meta"]));
        assert!(html.contains("<h1>Heading</h1>"));
        assert_eq!(artifacts.meta.get("title"), Some(&vec!["Doc".to_string()]));
    }

    #[test]
    fn admonition_extension_builds_block() {
        let md = "!!! note \"Heads up\"\n    Be careful.";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["admonition"]));
        assert!(html.contains("class=\"admonition note\""));
        assert!(html.contains("Heads up"));
    }

    #[test]
    fn wikilinks_extension_generates_anchors() {
        let md = "See [[My Page]].";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["wikilinks"]));
        assert!(html.contains("href=\"/My_Page/\""));
    }

    #[test]
    fn codehilite_wraps_blocks() {
        let mut opts = options_with_extensions(&["codehilite", "fenced_code"]);
        opts.extension_configs = HashMap::from([(
            "codehilite".to_string(),
            HashMap::from([("css_class".to_string(), "highlight".to_string())]),
        )]);
        let md = "```python\nprint('x')\n```";
        let html = markdown_to_html_with_options(md, opts);
        assert!(html.contains("<div class=\"highlight\">"));
    }

    #[test]
    fn toc_uses_nested_lists_by_heading_level() {
        let md = "[TOC]\n\n# One\n\n## Two";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["toc"]));
        assert!(html.contains("<li><a href=\"#one\">One</a>"));
        assert!(html.contains("</a>\n<ul>"));
        assert!(html.contains("<li><a href=\"#two\">Two</a></li>"));
    }

    #[test]
    fn footnotes_match_python_markdown_shape() {
        let md = "Footnote[^1]\n\n[^1]: detail";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["footnotes"]));
        assert!(html.contains("<div class=\"footnote\">"));
        assert!(
            html.contains(
                "<sup id=\"fnref:1\"><a class=\"footnote-ref\" href=\"#fn:1\">1</a></sup>"
            )
        );
        assert!(html.contains("<li id=\"fn:1\">"));
        assert!(html.contains("detail&#160;<a class=\"footnote-backref\""));
    }

    #[test]
    fn codehilite_without_fenced_code_keeps_python_markdown_behavior() {
        let md = "```python\nprint('x')\n```";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["codehilite"]));
        assert!(html.contains("<p><code>python"));
        assert!(!html.contains("<div class=\"codehilite\">"));
    }

    #[test]
    fn legacy_attrs_is_ignored() {
        let md = "# Legacy {#old}";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["legacy_attrs"]));
        assert!(html.contains("<h1>Legacy {#old}</h1>"));
    }

    #[test]
    fn smarty_outputs_named_entities() {
        let md = "\"quoted\" -- text...";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["smarty"]));
        assert!(html.contains("&ldquo;quoted&rdquo;"));
        assert!(html.contains("&ndash;"));
        assert!(html.contains("&hellip;"));
    }

    #[test]
    fn gfm_toggles_default_off_for_python_markdown_compat() {
        let md = "Visit https://example.com\n\n- [ ] item\n\n~~gone~~";
        let html = markdown_to_html_with_options(md, MarkdownToHtmlOptions::default());
        assert!(!html.contains("<a href=\"https://example.com\">"));
        assert!(!html.contains("<input"));
        assert!(!html.contains("<del>"));
    }

    #[test]
    fn gfm_toggles_can_be_enabled_explicitly() {
        let md = "Visit https://example.com\n\n- [ ] item\n\n~~gone~~";
        let opts = MarkdownToHtmlOptions {
            autolink: true,
            tasklist: true,
            strikethrough: true,
            ..Default::default()
        };
        let html = markdown_to_html_with_options(md, opts);
        assert!(html.contains("<a href=\"https://example.com\">https://example.com</a>"));
        assert!(html.contains("<input"));
        assert!(html.contains("<del>gone</del>"));
    }

    #[test]
    fn python_compat_backslash_escapes_in_default_mode() {
        let md = r"S\&H and A\|B";
        let html = markdown_to_html_with_options(md, MarkdownToHtmlOptions::default());
        assert!(html.contains(r"S\&amp;H"));
        assert!(html.contains(r"A\|B"));
    }

    #[test]
    fn fast_mode_uses_comrak_backslash_behavior() {
        let md = r"S\&H and A\|B";
        let opts = MarkdownToHtmlOptions {
            mode: MarkdownMode::Fast,
            ..Default::default()
        };
        let html = markdown_to_html_with_options(md, opts);
        assert!(html.contains("S&amp;H"));
        assert!(html.contains("A|B"));
        assert!(!html.contains(r"S\&amp;H"));
    }

    #[test]
    fn python_compat_malformed_links_in_default_mode() {
        let md = "[x](https://www WATERPLAN.COM/)";
        let html = markdown_to_html_with_options(md, MarkdownToHtmlOptions::default());
        assert!(html.contains("<a href=\"https://www WATERPLAN.COM/\">x</a>"));
    }

    #[test]
    fn fast_mode_uses_comrak_malformed_link_behavior() {
        let md = "[x](https://www WATERPLAN.COM/)";
        let opts = MarkdownToHtmlOptions {
            mode: MarkdownMode::Fast,
            ..Default::default()
        };
        let html = markdown_to_html_with_options(md, opts);
        assert!(html.contains("[x](https://www WATERPLAN.COM/)"));
    }

    #[test]
    fn python_compat_hanging_list_markers_in_default_mode() {
        let md = "1. a\n2.\nb\n3. c";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert!(
            html.contains("<li>a\n2.\nb</li>"),
            "unexpected html: {html}"
        );
        assert!(html.contains("<li>c</li>"), "unexpected html: {html}");
    }

    #[test]
    fn fast_mode_uses_comrak_hanging_list_behavior() {
        let md = "1. a\n2.\nb\n3. c";
        let opts = fast_options_with_extensions(&["sane_lists"]);
        let html = markdown_to_html_with_options(md, opts);
        assert!(html.contains("<li></li>"), "unexpected html: {html}");
        assert!(html.contains("<p>b\n3. c</p>"), "unexpected html: {html}");
    }

    #[test]
    fn python_compat_underscore_emphasis_in_default_mode() {
        let md = "x _______ y";
        let html = markdown_to_html_with_options(md, MarkdownToHtmlOptions::default());
        assert!(
            html.contains("<strong><em>_</em></strong>"),
            "unexpected html: {html}"
        );
    }

    #[test]
    fn fast_mode_uses_comrak_underscore_behavior() {
        let md = "x _______ y";
        let opts = MarkdownToHtmlOptions {
            mode: MarkdownMode::Fast,
            ..Default::default()
        };
        let html = markdown_to_html_with_options(md, opts);
        assert!(html.contains("_______"), "unexpected html: {html}");
        assert!(
            !html.contains("<strong><em>_</em></strong>"),
            "unexpected html: {html}"
        );
    }

    #[test]
    fn python_compat_entity_references_in_default_mode() {
        let md = "A &#x26; B and `&#x26;`";
        let html = markdown_to_html_with_options(md, MarkdownToHtmlOptions::default());
        assert!(html.contains("A &#x26; B"), "unexpected html: {html}");
        assert!(
            html.contains("<code>&amp;#x26;</code>"),
            "unexpected html: {html}"
        );
    }

    #[test]
    fn fast_mode_uses_comrak_entity_behavior() {
        let md = "A &#x26; B";
        let opts = MarkdownToHtmlOptions {
            mode: MarkdownMode::Fast,
            ..Default::default()
        };
        let html = markdown_to_html_with_options(md, opts);
        assert!(html.contains("A &amp; B"), "unexpected html: {html}");
        assert!(!html.contains("&#x26;"), "unexpected html: {html}");
    }

    #[test]
    fn python_compat_raw_html_blocks_in_default_mode() {
        let md = "<table>\n<tr><td>x</td\n\n**BOLD**\ntail\n</table>";
        let html = markdown_to_html_with_options(md, MarkdownToHtmlOptions::default());
        assert!(
            html.contains("<table>\n<tr><td>x</td\n\n**BOLD**\ntail\n</table>"),
            "unexpected html: {html}"
        );
        assert!(
            !html.contains("<strong>BOLD</strong>"),
            "unexpected html: {html}"
        );
    }

    #[test]
    fn fast_mode_uses_comrak_raw_html_behavior() {
        let md = "<table>\n<tr><td>x</td\n\n**BOLD**\ntail\n</table>";
        let opts = MarkdownToHtmlOptions {
            mode: MarkdownMode::Fast,
            ..Default::default()
        };
        let html = markdown_to_html_with_options(md, opts);
        assert!(
            html.contains("<strong>BOLD</strong>"),
            "unexpected html: {html}"
        );
    }

    #[test]
    fn lists_do_not_interrupt_paragraphs_without_blank_line() {
        let md = "Intro\n- one\n- two";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert!(
            html.contains("<p>Intro\n- one\n- two</p>"),
            "unexpected html: {html}"
        );
        assert!(!html.contains("<ul>"), "unexpected html: {html}");
    }

    #[test]
    fn fast_mode_allows_list_interruption() {
        let md = "Intro\n- one\n- two";
        let opts = fast_options_with_extensions(&["sane_lists"]);
        let html = markdown_to_html_with_options(md, opts);
        assert!(html.contains("<ul>"), "unexpected html: {html}");
        assert!(
            !html.contains("<p>Intro\n- one\n- two</p>"),
            "unexpected html: {html}"
        );
    }

    #[test]
    fn ordered_paren_markers_follow_python_markdown_behavior() {
        let md = "1) one\n2) two";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert!(!html.contains("<ol>"), "unexpected html: {html}");
        assert!(
            html.contains("<p>1) one\n2) two</p>"),
            "unexpected html: {html}"
        );
    }

    #[test]
    fn fast_mode_parses_ordered_paren_markers_as_lists() {
        let md = "1) one\n2) two";
        let opts = fast_options_with_extensions(&["sane_lists"]);
        let html = markdown_to_html_with_options(md, opts);
        assert!(html.contains("<ol>"), "unexpected html: {html}");
        assert!(html.contains("<li>one</li>"), "unexpected html: {html}");
    }

    #[test]
    fn bullet_prefixed_ordered_paren_markers_stay_text() {
        let md = "- 1) one\n- 2) two";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert!(html.contains("<ul>"), "unexpected html: {html}");
        assert!(!html.contains("<ol>"), "unexpected html: {html}");
        assert!(html.contains("1) one"), "unexpected html: {html}");
        assert!(html.contains("2) two"), "unexpected html: {html}");
    }

    #[test]
    fn bare_list_markers_stay_text_with_python_compat_lists() {
        let md = "-\n*\n+";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert!(!html.contains("<ul>"), "unexpected html: {html}");
        assert!(html.contains("<p>-\n*\n+</p>"), "unexpected html: {html}");
    }

    #[test]
    fn bare_list_markers_with_trailing_space_remain_lists() {
        let md = "- \n";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert!(html.contains("<ul>"), "unexpected html: {html}");
        assert!(html.contains("<li></li>"), "unexpected html: {html}");
    }

    #[test]
    fn mixed_bullet_markers_stay_in_single_list() {
        let md = "- one\n- two\n\n* three";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert_eq!(html.matches("<ul>").count(), 1, "unexpected html: {html}");
        assert!(
            html.contains("<li>\n<p>three</p>\n</li>"),
            "unexpected html: {html}"
        );
    }

    #[test]
    fn ordered_item_with_inline_bullet_continues_nested_bullets() {
        let md = "1. Intro\n2. - (A) First\n- (B) Second\n- (C) Third";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert!(html.contains("<ol>"), "unexpected html: {html}");
        assert!(
            html.contains("<li>(A) First</li>"),
            "unexpected html: {html}"
        );
        assert!(
            html.contains("<li>(B) Second</li>"),
            "unexpected html: {html}"
        );
        assert!(
            html.contains("<li>(C) Third</li>"),
            "unexpected html: {html}"
        );
    }

    #[test]
    fn bullet_prefixed_numbered_lines_keep_numbered_continuation() {
        let md = "- 1. One\n2. Two\n3. Three";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert!(html.contains("<ol>"), "unexpected html: {html}");
        assert!(html.contains("<li>One</li>"), "unexpected html: {html}");
        assert!(html.contains("<li>Two</li>"), "unexpected html: {html}");
        assert!(html.contains("<li>Three</li>"), "unexpected html: {html}");
    }

    #[test]
    fn lists_still_follow_headings_without_blank_line() {
        let md = "# Title\n- one\n- two";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert!(html.contains("<h1>Title</h1>"));
        assert!(html.contains("<ul>"));
    }

    #[test]
    fn table_like_lines_with_inline_bullets_stay_plain_text() {
        let md = "| Members | * Karen\n* Dayle\n* Tala |";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert!(
            html.contains("<p>| Members | * Karen\n* Dayle\n* Tala |</p>"),
            "unexpected html: {html}"
        );
        assert!(!html.contains("<ul>"), "unexpected html: {html}");
    }

    #[test]
    fn sane_lists_mixed_types_without_blank_stay_text() {
        let md = "- item:\n1. one\n2. two";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert!(html.contains("<ul>"), "unexpected html: {html}");
        assert!(!html.contains("<ol>"), "unexpected html: {html}");
        assert!(html.contains("1. one"), "unexpected html: {html}");
        assert!(html.contains("2. two"), "unexpected html: {html}");
    }

    #[test]
    fn sane_lists_mixed_types_with_blank_split_lists() {
        let md = "- item:\n\n1. one\n2. two";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert!(html.contains("<ul>"), "unexpected html: {html}");
        assert!(html.contains("<ol>"), "unexpected html: {html}");
    }

    #[test]
    fn sane_lists_shallow_indented_bullets_become_siblings() {
        let md = "* top\n  * sub\n* next";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert!(html.contains("<li>top</li>"), "unexpected html: {html}");
        assert!(html.contains("<li>sub</li>"), "unexpected html: {html}");
        assert!(html.contains("<li>next</li>"), "unexpected html: {html}");
        assert!(!html.contains("<li>top<ul>"), "unexpected html: {html}");
    }

    #[test]
    fn sane_lists_blank_line_shallow_indented_bullets_stay_siblings() {
        let md = "* top\n\n  * sub";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert!(
            !html.contains("<li>\n<p>top</p>\n<ul>"),
            "unexpected html: {html}"
        );
        assert!(
            html.contains("<li>\n<p>top</p>\n</li>"),
            "unexpected html: {html}"
        );
        assert!(
            html.contains("<li>\n<p>sub</p>\n</li>"),
            "unexpected html: {html}"
        );
    }

    #[test]
    fn fast_mode_uses_comrak_shallow_sublists_behavior() {
        let md = "* top\n\n  * sub";
        let opts = fast_options_with_extensions(&["sane_lists"]);
        let html = markdown_to_html_with_options(md, opts);
        assert!(
            html.contains("<li>\n<p>top</p>\n<ul>"),
            "unexpected html: {html}"
        );
    }

    #[test]
    fn sane_lists_four_space_indent_allows_nested_lists() {
        let md = "* top\n    * sub\n* next";
        let html = markdown_to_html_with_options(md, options_with_extensions(&["sane_lists"]));
        assert!(html.contains("<li>top"), "unexpected html: {html}");
        assert!(
            html.contains("<ul>\n<li>sub</li>\n</ul>"),
            "unexpected html: {html}"
        );
        assert!(html.contains("<li>sub</li>"), "unexpected html: {html}");
    }
}
