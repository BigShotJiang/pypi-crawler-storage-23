#![allow(unsafe_op_in_unsafe_fn)]

use std::collections::HashSet;

use pyo3::ToPyObject;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::{PyAny, PyBool, PyDict, PyFloat, PyInt, PyList, PyString, PyTuple};

use crate::xml_utils::{self, ObjectToXmlOptions, TagMatch, XmlToObjectOptions, XmlValue};
use crate::{
    HeadingStyle, MarkdownConverter, NewlineStyle, Options, StripMode, StripPreMode,
    markdown_to_html, markdown_utils, markdownify_batch_with_options,
};

// ---------------------------------------------------------------------------
// Markdownify bindings (existing)
// ---------------------------------------------------------------------------

#[pyclass(name = "MarkdownConverter")]
struct PyMarkdownConverter {
    inner: MarkdownConverter,
}

#[pymethods]
impl PyMarkdownConverter {
    #[new]
    #[pyo3(signature = (**kwargs))]
    fn new(kwargs: Option<Bound<'_, PyDict>>) -> PyResult<Self> {
        let options = options_from_kwargs(kwargs)?;
        Ok(Self {
            inner: MarkdownConverter::new(options),
        })
    }

    fn convert(&self, py: Python<'_>, html: &str) -> String {
        py.allow_threads(|| self.inner.convert(html))
    }
}

#[pyfunction(name = "markdownify")]
#[pyo3(signature = (html, **kwargs))]
fn markdownify(py: Python<'_>, html: &str, kwargs: Option<Bound<'_, PyDict>>) -> PyResult<String> {
    let options = options_from_kwargs(kwargs)?;
    Ok(py.allow_threads(|| markdownify_with_options(html, options)))
}

#[pyfunction(name = "markdownify_batch")]
#[pyo3(signature = (html_list, **kwargs))]
fn markdownify_batch(
    py: Python<'_>,
    html_list: Vec<String>,
    kwargs: Option<Bound<'_, PyDict>>,
) -> PyResult<Vec<String>> {
    let options = options_from_kwargs(kwargs)?;
    Ok(py.allow_threads(|| markdownify_batch_with_options(html_list, options)))
}

fn markdownify_with_options(html: &str, options: Options) -> String {
    MarkdownConverter::new(options).convert(html)
}

// ---------------------------------------------------------------------------
// Markdown -> HTML bindings
// ---------------------------------------------------------------------------

#[pyclass(name = "MarkdownToHtmlConverter")]
struct PyMarkdownToHtmlConverter {
    options: markdown_to_html::MarkdownToHtmlOptions,
    meta: std::collections::HashMap<String, Vec<String>>,
    toc_tokens: Vec<markdown_to_html::TocToken>,
}

#[pymethods]
impl PyMarkdownToHtmlConverter {
    #[new]
    #[pyo3(signature = (**kwargs))]
    fn new(kwargs: Option<Bound<'_, PyDict>>) -> PyResult<Self> {
        Ok(Self {
            options: markdown_to_html_options_from_kwargs(kwargs)?,
            meta: std::collections::HashMap::new(),
            toc_tokens: Vec::new(),
        })
    }

    fn convert(&mut self, py: Python<'_>, markdown_text: &str) -> String {
        let (html, artifacts) = py.allow_threads(|| {
            markdown_to_html::markdown_to_html_with_artifacts(markdown_text, self.options.clone())
        });
        self.meta = artifacts.meta;
        self.toc_tokens = artifacts.toc_tokens;
        html
    }

    fn convert_batch(&self, py: Python<'_>, markdown_texts: Vec<String>) -> Vec<String> {
        py.allow_threads(|| {
            markdown_to_html::markdown_to_html_batch_with_options(
                markdown_texts,
                self.options.clone(),
            )
        })
    }

    fn reset(&mut self) {
        self.meta.clear();
        self.toc_tokens.clear();
    }

    #[getter]
    fn meta(&self, py: Python<'_>) -> PyResult<PyObject> {
        let dict = PyDict::new_bound(py);
        for (k, values) in &self.meta {
            let list = PyList::empty_bound(py);
            for value in values {
                list.append(value)?;
            }
            dict.set_item(k, list)?;
        }
        Ok(dict.unbind().into())
    }

    #[getter]
    fn toc_tokens(&self, py: Python<'_>) -> PyResult<PyObject> {
        let list = PyList::empty_bound(py);
        for token in &self.toc_tokens {
            let item = PyDict::new_bound(py);
            item.set_item("level", token.level)?;
            item.set_item("id", &token.id)?;
            item.set_item("name", &token.name)?;
            list.append(item)?;
        }
        Ok(list.unbind().into())
    }
}

#[pyfunction(name = "markdown")]
#[pyo3(signature = (markdown_text, **kwargs))]
fn py_markdown_to_html(
    py: Python<'_>,
    markdown_text: &str,
    kwargs: Option<Bound<'_, PyDict>>,
) -> PyResult<String> {
    let options = markdown_to_html_options_from_kwargs(kwargs)?;
    Ok(
        py.allow_threads(|| {
            markdown_to_html::markdown_to_html_with_options(markdown_text, options)
        }),
    )
}

#[pyfunction(name = "markdown_batch")]
#[pyo3(signature = (markdown_texts, **kwargs))]
fn py_markdown_to_html_batch(
    py: Python<'_>,
    markdown_texts: Vec<String>,
    kwargs: Option<Bound<'_, PyDict>>,
) -> PyResult<Vec<String>> {
    let options = markdown_to_html_options_from_kwargs(kwargs)?;
    Ok(py.allow_threads(|| {
        markdown_to_html::markdown_to_html_batch_with_options(markdown_texts, options)
    }))
}

fn markdown_to_html_options_from_kwargs(
    kwargs: Option<Bound<'_, PyDict>>,
) -> PyResult<markdown_to_html::MarkdownToHtmlOptions> {
    let mut options = markdown_to_html::MarkdownToHtmlOptions::default();
    let mut extensions = std::collections::HashSet::<String>::new();
    let mut extension_configs =
        std::collections::HashMap::<String, std::collections::HashMap<String, String>>::new();

    if let Some(kwargs) = kwargs {
        for (key, value) in kwargs {
            let key: String = key.extract()?;
            if key.starts_with("python_compat_") {
                return Err(PyValueError::new_err(
                    "python_compat_* options were removed; use mode='python_compat' or mode='fast'",
                ));
            }
            match key.as_str() {
                "extensions" => {
                    if value.is_none() {
                        extensions.clear();
                    } else if value.is_instance_of::<PyString>() {
                        let ext: String = value.extract()?;
                        extensions.insert(normalize_markdown_extension_name(&ext));
                    } else {
                        for item in value.iter()? {
                            let item = item?;
                            let ext: String = item.extract()?;
                            extensions.insert(normalize_markdown_extension_name(&ext));
                        }
                    }
                }
                "extension_configs" => {
                    if value.is_none() {
                        extension_configs.clear();
                    } else {
                        let dict = value.downcast::<PyDict>().map_err(|_| {
                            PyValueError::new_err("extension_configs must be a dict")
                        })?;

                        for (ext_key, raw_cfg) in dict {
                            let ext: String = ext_key.extract()?;
                            let ext_name = normalize_markdown_extension_name(&ext);
                            let cfg = raw_cfg.downcast::<PyDict>().map_err(|_| {
                                PyValueError::new_err("each extension config value must be a dict")
                            })?;
                            let mut parsed = std::collections::HashMap::new();
                            for (cfg_key, cfg_value) in cfg {
                                let cfg_key: String = cfg_key.extract()?;
                                let cfg_val: String = cfg_value.str()?.extract()?;
                                parsed.insert(cfg_key, cfg_val);
                            }
                            extension_configs.insert(ext_name, parsed);
                        }
                    }
                }
                "output_format" => {
                    let raw: String = value.extract()?;
                    options.output_format = parse_markdown_output_format(&raw)?;
                }
                "mode" => {
                    let raw: String = value.extract()?;
                    options.mode = parse_markdown_mode(&raw)?;
                }
                "tab_length" => options.tab_length = value.extract()?,
                "lazy_ol" => options.lazy_ol = value.extract()?,
                "autolink" => options.autolink = value.extract()?,
                "tasklist" => options.tasklist = value.extract()?,
                "strikethrough" => options.strikethrough = value.extract()?,
                _ => {
                    return Err(PyValueError::new_err(format!(
                        "unknown markdown option: {key}"
                    )));
                }
            }
        }
    }

    options.extensions = extensions;
    options.extension_configs = extension_configs;
    Ok(options)
}

fn normalize_markdown_extension_name(name: &str) -> String {
    let lowered = name.trim().to_ascii_lowercase();
    if let Some(stripped) = lowered.strip_prefix("markdown.extensions.") {
        stripped.to_string()
    } else {
        lowered
    }
}

fn parse_markdown_output_format(value: &str) -> PyResult<markdown_to_html::OutputFormat> {
    match value.trim().to_ascii_lowercase().as_str() {
        "html" | "html5" => Ok(markdown_to_html::OutputFormat::Html),
        "xhtml" | "xhtml1" => Ok(markdown_to_html::OutputFormat::Xhtml),
        _ => Err(PyValueError::new_err(
            "invalid output_format (expected 'html' or 'xhtml')",
        )),
    }
}

fn parse_markdown_mode(value: &str) -> PyResult<markdown_to_html::MarkdownMode> {
    match value.trim().to_ascii_lowercase().as_str() {
        "fast" => Ok(markdown_to_html::MarkdownMode::Fast),
        "python_compat" | "python-compat" | "python" | "compat" => {
            Ok(markdown_to_html::MarkdownMode::PythonCompat)
        }
        _ => Err(PyValueError::new_err(
            "invalid mode (expected 'fast' or 'python_compat')",
        )),
    }
}

// ---------------------------------------------------------------------------
// markdown_utils bindings
// ---------------------------------------------------------------------------

#[pyfunction(name = "split_into_chunks")]
#[pyo3(signature = (markdown, how="sections"))]
fn py_split_into_chunks(py: Python<'_>, markdown: &str, how: &str) -> Vec<String> {
    py.allow_threads(|| markdown_utils::split_into_chunks(markdown, how))
}

#[pyfunction(name = "split_into_chunks_batch")]
#[pyo3(signature = (markdown_list, how="sections"))]
fn py_split_into_chunks_batch(
    py: Python<'_>,
    markdown_list: Vec<String>,
    how: &str,
) -> Vec<Vec<String>> {
    py.allow_threads(|| markdown_utils::split_into_chunks_batch(markdown_list, how))
}

#[pyfunction(name = "coalesce_small_chunks")]
#[pyo3(signature = (chunks, min_size=125))]
fn py_coalesce_small_chunks(py: Python<'_>, chunks: Vec<String>, min_size: usize) -> Vec<String> {
    py.allow_threads(|| markdown_utils::coalesce_small_chunks(chunks, min_size))
}

#[pyfunction(name = "cascading_split_text")]
#[pyo3(signature = (content, how, max_length=8_000, coalesce_min=225))]
fn py_cascading_split_text(
    py: Python<'_>,
    content: &str,
    how: Vec<String>,
    max_length: usize,
    coalesce_min: usize,
) -> Vec<String> {
    py.allow_threads(|| {
        markdown_utils::cascading_split_text(content, &how, max_length, coalesce_min)
    })
}

#[pyfunction(name = "cascading_split_text_batch")]
#[pyo3(signature = (contents, how, max_length=8_000, coalesce_min=225))]
fn py_cascading_split_text_batch(
    py: Python<'_>,
    contents: Vec<String>,
    how: Vec<String>,
    max_length: usize,
    coalesce_min: usize,
) -> Vec<Vec<String>> {
    py.allow_threads(|| {
        markdown_utils::cascading_split_text_batch(contents, how, max_length, coalesce_min)
    })
}

#[pyfunction(name = "split_on_dividers")]
fn py_split_on_dividers(py: Python<'_>, markdown: &str) -> Vec<String> {
    py.allow_threads(|| markdown_utils::split_on_dividers(markdown))
}

#[pyfunction(name = "link_percentage")]
fn py_link_percentage(py: Python<'_>, chunk: &str) -> f64 {
    py.allow_threads(|| markdown_utils::link_percentage(chunk))
}

#[pyfunction(name = "link_percentage_batch")]
fn py_link_percentage_batch(py: Python<'_>, chunks: Vec<String>) -> Vec<f64> {
    py.allow_threads(|| markdown_utils::link_percentage_batch(chunks))
}

#[pyfunction(name = "filter_by_link_percentage")]
#[pyo3(signature = (chunks, threshold=0.5))]
fn py_filter_by_link_percentage(
    py: Python<'_>,
    chunks: Vec<String>,
    threshold: f64,
) -> Vec<String> {
    py.allow_threads(|| markdown_utils::filter_by_link_percentage(chunks, threshold))
}

#[pyfunction(name = "strip_links_with_substring")]
fn py_strip_links_with_substring(py: Python<'_>, text: &str, substring: &str) -> String {
    py.allow_threads(|| markdown_utils::strip_links_with_substring(text, substring))
}

#[pyfunction(name = "strip_links_with_substring_batch")]
fn py_strip_links_with_substring_batch(
    py: Python<'_>,
    texts: Vec<String>,
    substring: &str,
) -> Vec<String> {
    py.allow_threads(|| markdown_utils::strip_links_with_substring_batch(texts, substring))
}

#[pyfunction(name = "remove_large_tables")]
#[pyo3(signature = (text, max_cells=400))]
fn py_remove_large_tables(py: Python<'_>, text: &str, max_cells: usize) -> String {
    py.allow_threads(|| markdown_utils::remove_large_tables(text, max_cells))
}

#[pyfunction(name = "remove_large_tables_batch")]
#[pyo3(signature = (texts, max_cells=400))]
fn py_remove_large_tables_batch(
    py: Python<'_>,
    texts: Vec<String>,
    max_cells: usize,
) -> Vec<String> {
    py.allow_threads(|| markdown_utils::remove_large_tables_batch(texts, max_cells))
}

#[pyfunction(name = "strip_html_and_contents")]
fn py_strip_html_and_contents(py: Python<'_>, text: &str) -> String {
    py.allow_threads(|| markdown_utils::strip_html_and_contents(text))
}

#[pyfunction(name = "strip_html_and_contents_batch")]
fn py_strip_html_and_contents_batch(py: Python<'_>, texts: Vec<String>) -> Vec<String> {
    py.allow_threads(|| markdown_utils::strip_html_and_contents_batch(texts))
}

#[pyfunction(name = "remove_lines_with_substring")]
fn py_remove_lines_with_substring(py: Python<'_>, text: &str, substring: &str) -> String {
    py.allow_threads(|| markdown_utils::remove_lines_with_substring(text, substring))
}

#[pyfunction(name = "remove_lines_with_substring_batch")]
fn py_remove_lines_with_substring_batch(
    py: Python<'_>,
    texts: Vec<String>,
    substring: &str,
) -> Vec<String> {
    py.allow_threads(|| markdown_utils::remove_lines_with_substring_batch(texts, substring))
}

#[pyfunction(name = "fix_newlines")]
fn py_fix_newlines(py: Python<'_>, text: &str) -> String {
    py.allow_threads(|| markdown_utils::fix_newlines(text))
}

#[pyfunction(name = "fix_newlines_batch")]
fn py_fix_newlines_batch(py: Python<'_>, texts: Vec<String>) -> Vec<String> {
    py.allow_threads(|| markdown_utils::fix_newlines_batch(texts))
}

#[pyfunction(name = "strip_data_uri_images")]
fn py_strip_data_uri_images(py: Python<'_>, markdown: &str) -> String {
    py.allow_threads(|| markdown_utils::strip_data_uri_images(markdown))
}

#[pyfunction(name = "text_pipeline_batch")]
#[pyo3(signature = (texts, steps))]
fn py_text_pipeline_batch(
    py: Python<'_>,
    texts: Vec<String>,
    steps: &Bound<'_, PyAny>,
) -> PyResult<Vec<String>> {
    let parsed_steps = parse_text_pipeline_steps(steps)?;
    Ok(py.allow_threads(|| markdown_utils::text_pipeline_batch(texts, parsed_steps)))
}

fn parse_text_pipeline_steps(
    steps: &Bound<'_, PyAny>,
) -> PyResult<Vec<markdown_utils::TextPipelineStep>> {
    let mut out = Vec::new();
    for item in steps.iter()? {
        out.push(parse_text_pipeline_step(&item?)?);
    }
    Ok(out)
}

fn parse_text_pipeline_step(step: &Bound<'_, PyAny>) -> PyResult<markdown_utils::TextPipelineStep> {
    if let Ok(name) = step.extract::<String>() {
        return parse_text_pipeline_step_named(&name, None);
    }

    if let Ok(tuple) = step.downcast::<PyTuple>() {
        if tuple.len() != 2 {
            return Err(PyValueError::new_err(
                "pipeline tuple steps must be (name, params)",
            ));
        }
        let name: String = tuple.get_item(0)?.extract()?;
        let params = tuple.get_item(1)?;
        return parse_text_pipeline_step_named(&name, Some(&params));
    }

    if let Ok(list) = step.downcast::<PyList>() {
        if list.len() != 2 {
            return Err(PyValueError::new_err(
                "pipeline list steps must be [name, params]",
            ));
        }
        let name: String = list.get_item(0)?.extract()?;
        let params = list.get_item(1)?;
        return parse_text_pipeline_step_named(&name, Some(&params));
    }

    if let Ok(dict) = step.downcast::<PyDict>() {
        let Some(name_item) = dict.get_item("name")? else {
            return Err(PyValueError::new_err(
                "pipeline dict steps must include a 'name' key",
            ));
        };
        let name: String = name_item.extract()?;
        let params = dict.get_item("params")?;
        return parse_text_pipeline_step_named(&name, params.as_ref());
    }

    Err(PyValueError::new_err(
        "each pipeline step must be a str, tuple(name, params), list[name, params], or dict",
    ))
}

fn parse_text_pipeline_step_named(
    name: &str,
    params: Option<&Bound<'_, PyAny>>,
) -> PyResult<markdown_utils::TextPipelineStep> {
    let params_dict = as_pipeline_params_dict(name, params)?;
    match name {
        "strip_links_with_substring" => {
            ensure_pipeline_keys(name, params_dict.as_ref(), &["substring"])?;
            let substring = required_pipeline_str(name, params_dict.as_ref(), "substring")?;
            Ok(markdown_utils::TextPipelineStep::StripLinksWithSubstring { substring })
        }
        "remove_large_tables" => {
            ensure_pipeline_keys(name, params_dict.as_ref(), &["max_cells"])?;
            let max_cells = optional_pipeline_usize(params_dict.as_ref(), "max_cells", 400)?;
            Ok(markdown_utils::TextPipelineStep::RemoveLargeTables { max_cells })
        }
        "strip_html_and_contents" => {
            ensure_no_pipeline_params(name, params_dict.as_ref())?;
            Ok(markdown_utils::TextPipelineStep::StripHtmlAndContents)
        }
        "fix_newlines" => {
            ensure_no_pipeline_params(name, params_dict.as_ref())?;
            Ok(markdown_utils::TextPipelineStep::FixNewlines)
        }
        "remove_lines_with_substring" => {
            ensure_pipeline_keys(name, params_dict.as_ref(), &["substring"])?;
            let substring = required_pipeline_str(name, params_dict.as_ref(), "substring")?;
            Ok(markdown_utils::TextPipelineStep::RemoveLinesWithSubstring { substring })
        }
        "strip_data_uri_images" => {
            ensure_no_pipeline_params(name, params_dict.as_ref())?;
            Ok(markdown_utils::TextPipelineStep::StripDataUriImages)
        }
        _ => Err(PyValueError::new_err(format!(
            "unknown text pipeline step: {name}"
        ))),
    }
}

fn as_pipeline_params_dict<'py>(
    step_name: &str,
    params: Option<&Bound<'py, PyAny>>,
) -> PyResult<Option<Bound<'py, PyDict>>> {
    match params {
        None => Ok(None),
        Some(params) if params.is_none() => Ok(None),
        Some(params) => params
            .downcast::<PyDict>()
            .map(|dict| Some(dict.clone()))
            .map_err(|_| {
                PyValueError::new_err(format!(
                    "pipeline step '{step_name}' expects params as a dict"
                ))
            }),
    }
}

fn ensure_no_pipeline_params(step_name: &str, params: Option<&Bound<'_, PyDict>>) -> PyResult<()> {
    if let Some(params) = params {
        if !params.is_empty() {
            return Err(PyValueError::new_err(format!(
                "pipeline step '{step_name}' does not take params"
            )));
        }
    }
    Ok(())
}

fn ensure_pipeline_keys(
    step_name: &str,
    params: Option<&Bound<'_, PyDict>>,
    allowed: &[&str],
) -> PyResult<()> {
    if let Some(params) = params {
        for (key, _) in params.iter() {
            let key: String = key.extract()?;
            if !allowed.iter().any(|allowed_key| key == *allowed_key) {
                return Err(PyValueError::new_err(format!(
                    "pipeline step '{step_name}' does not support param '{key}'"
                )));
            }
        }
    }
    Ok(())
}

fn required_pipeline_str(
    step_name: &str,
    params: Option<&Bound<'_, PyDict>>,
    key: &str,
) -> PyResult<String> {
    let params = params.ok_or_else(|| {
        PyValueError::new_err(format!(
            "pipeline step '{step_name}' requires param '{key}'"
        ))
    })?;
    let value = params.get_item(key)?.ok_or_else(|| {
        PyValueError::new_err(format!(
            "pipeline step '{step_name}' requires param '{key}'"
        ))
    })?;
    value.extract().map_err(|_| {
        PyValueError::new_err(format!(
            "pipeline step '{step_name}' param '{key}' must be a string"
        ))
    })
}

fn optional_pipeline_usize(
    params: Option<&Bound<'_, PyDict>>,
    key: &str,
    default: usize,
) -> PyResult<usize> {
    let Some(params) = params else {
        return Ok(default);
    };
    let Some(value) = params.get_item(key)? else {
        return Ok(default);
    };
    value
        .extract()
        .map_err(|_| PyValueError::new_err(format!("pipeline param '{key}' must be an integer")))
}

fn options_from_kwargs(kwargs: Option<Bound<'_, PyDict>>) -> PyResult<Options> {
    let mut options = Options::default();
    let mut strip_set: Option<HashSet<String>> = None;
    let mut convert_set: Option<HashSet<String>> = None;

    if let Some(kwargs) = kwargs {
        for (key, value) in kwargs {
            let key: String = key.extract()?;
            match key.as_str() {
                "autolinks" => options.autolinks = value.extract()?,
                "bullets" => options.bullets = value.extract()?,
                "code_language" => options.code_language = value.extract()?,
                "code_language_callback" => {
                    return Err(PyValueError::new_err(
                        "code_language_callback is not supported in the Python bindings",
                    ));
                }
                "convert" => {
                    if value.is_none() {
                        convert_set = None;
                    } else {
                        convert_set = Some(extract_str_set(&value)?);
                    }
                }
                "default_title" => options.default_title = value.extract()?,
                "escape_asterisks" => options.escape_asterisks = value.extract()?,
                "escape_underscores" => options.escape_underscores = value.extract()?,
                "escape_misc" => options.escape_misc = value.extract()?,
                "heading_style" => {
                    let raw: String = value.extract()?;
                    options.heading_style = parse_heading_style(&raw)?;
                }
                "keep_inline_images_in" => {
                    options.keep_inline_images_in = extract_str_set(&value)?;
                }
                "newline_style" => {
                    let raw: String = value.extract()?;
                    options.newline_style = parse_newline_style(&raw)?;
                }
                "strip" => {
                    if value.is_none() {
                        strip_set = None;
                    } else {
                        strip_set = Some(extract_str_set(&value)?);
                    }
                }
                "strip_document" => {
                    if value.is_none() {
                        options.strip_document = StripMode::None;
                    } else {
                        let raw: String = value.extract()?;
                        options.strip_document = parse_strip_document(&raw)?;
                    }
                }
                "strip_pre" => {
                    if value.is_none() {
                        options.strip_pre = StripPreMode::None;
                    } else {
                        let raw: String = value.extract()?;
                        options.strip_pre = parse_strip_pre(&raw)?;
                    }
                }
                "strong_em_symbol" => {
                    let raw: String = value.extract()?;
                    let mut chars = raw.chars();
                    let ch = chars.next().ok_or_else(|| {
                        PyValueError::new_err("strong_em_symbol must be non-empty")
                    })?;
                    options.strong_em_symbol = ch;
                }
                "sub_symbol" => options.sub_symbol = value.extract()?,
                "sup_symbol" => options.sup_symbol = value.extract()?,
                "table_infer_header" => options.table_infer_header = value.extract()?,
                "wrap" => options.wrap = value.extract()?,
                "wrap_width" => {
                    if value.is_none() {
                        options.wrap_width = None;
                    } else {
                        let width: usize = value.extract()?;
                        options.wrap_width = Some(width);
                    }
                }
                _ => {
                    return Err(PyValueError::new_err(format!("unknown option: {key}")));
                }
            }
        }
    }

    if strip_set.is_some() && convert_set.is_some() {
        return Err(PyValueError::new_err(
            "You may specify either tags to strip or tags to convert, but not both.",
        ));
    }
    options.strip = strip_set;
    options.convert = convert_set;

    Ok(options)
}

fn extract_str_set(value: &Bound<'_, PyAny>) -> PyResult<HashSet<String>> {
    if value.is_instance_of::<PyString>() {
        return Err(PyValueError::new_err(
            "expected an iterable of strings, got a string",
        ));
    }
    let mut set = HashSet::new();
    for item in value.iter()? {
        let item = item?;
        let s: String = item.extract()?;
        set.insert(s.to_ascii_lowercase());
    }
    Ok(set)
}

fn parse_heading_style(value: &str) -> PyResult<HeadingStyle> {
    match value.to_ascii_lowercase().as_str() {
        "atx" => Ok(HeadingStyle::Atx),
        "atx_closed" => Ok(HeadingStyle::AtxClosed),
        "underlined" | "setext" => Ok(HeadingStyle::Underlined),
        _ => Err(PyValueError::new_err("invalid heading_style")),
    }
}

fn parse_newline_style(value: &str) -> PyResult<NewlineStyle> {
    match value.to_ascii_lowercase().as_str() {
        "spaces" => Ok(NewlineStyle::Spaces),
        "backslash" => Ok(NewlineStyle::Backslash),
        _ => Err(PyValueError::new_err("invalid newline_style")),
    }
}

fn parse_strip_document(value: &str) -> PyResult<StripMode> {
    match value.to_ascii_lowercase().as_str() {
        "lstrip" => Ok(StripMode::LStrip),
        "rstrip" => Ok(StripMode::RStrip),
        "strip" => Ok(StripMode::Strip),
        _ => Err(PyValueError::new_err("invalid strip_document")),
    }
}

fn parse_strip_pre(value: &str) -> PyResult<StripPreMode> {
    match value.to_ascii_lowercase().as_str() {
        "strip" => Ok(StripPreMode::Strip),
        "strip_one" => Ok(StripPreMode::StripOne),
        _ => Err(PyValueError::new_err("invalid strip_pre")),
    }
}

// ---------------------------------------------------------------------------
// xml_utils bindings
// ---------------------------------------------------------------------------

#[pyfunction(name = "get_tag")]
#[pyo3(signature = (html_string, tag, return_attributes=false))]
fn py_get_tag(
    py: Python<'_>,
    html_string: &str,
    tag: &str,
    return_attributes: bool,
) -> PyResult<PyObject> {
    let result = py.allow_threads(|| xml_utils::get_tag(html_string, tag, return_attributes));
    match result {
        None => Ok(py.None()),
        Some(m) => tag_match_to_py(py, &m, return_attributes),
    }
}

#[pyfunction(name = "get_tags")]
#[pyo3(signature = (html_string, tag, return_attributes=false))]
fn py_get_tags(
    py: Python<'_>,
    html_string: &str,
    tag: &str,
    return_attributes: bool,
) -> PyResult<PyObject> {
    let results = py.allow_threads(|| xml_utils::get_tags(html_string, tag, return_attributes));
    let list = PyList::empty_bound(py);
    for m in &results {
        if return_attributes {
            let dict = PyDict::new_bound(py);
            dict.set_item("content", &m.content)?;
            let attrs = PyDict::new_bound(py);
            for (k, v) in &m.attributes {
                attrs.set_item(k, v)?;
            }
            dict.set_item("attributes", attrs)?;
            list.append(dict)?;
        } else {
            list.append(&m.content)?;
        }
    }
    Ok(list.unbind().into())
}

#[pyfunction(name = "strip_xml")]
fn py_strip_xml(py: Python<'_>, xml_string: &str) -> String {
    py.allow_threads(|| xml_utils::strip_xml(xml_string).to_string())
}

#[pyfunction(name = "remove_namespace_prefixes")]
fn py_remove_namespace_prefixes(py: Python<'_>, xml_string: &str) -> String {
    py.allow_threads(|| xml_utils::remove_namespace_prefixes(xml_string))
}

#[pyfunction(name = "object_to_xml")]
#[pyo3(signature = (
    obj,
    root_tag,
    ignore_dict_nulls=true,
    list_item_tag="li",
    include_list_index=true,
    index_attr="key",
    indent_str="  ",
))]
fn py_object_to_xml(
    py: Python<'_>,
    obj: &Bound<'_, PyAny>,
    root_tag: &str,
    ignore_dict_nulls: bool,
    list_item_tag: &str,
    include_list_index: bool,
    index_attr: &str,
    indent_str: &str,
) -> PyResult<String> {
    let value = xml_value_from_pyany(obj)?;
    let options = ObjectToXmlOptions {
        ignore_dict_nulls,
        list_item_tag: list_item_tag.to_string(),
        include_list_index,
        index_attr: index_attr.to_string(),
        indent_str: indent_str.to_string(),
    };
    let root_tag = root_tag.to_string();
    Ok(py.allow_threads(|| xml_utils::object_to_xml(&value, &root_tag, &options)))
}

#[pyfunction(name = "xml_to_object")]
#[pyo3(signature = (xml_string, parse_null_text_as_none=true, parse_empty_tags_as_none=false))]
fn py_xml_to_object(
    py: Python<'_>,
    xml_string: &str,
    parse_null_text_as_none: bool,
    parse_empty_tags_as_none: bool,
) -> PyResult<PyObject> {
    let options = XmlToObjectOptions {
        parse_null_text_as_none,
        parse_empty_tags_as_none,
    };
    let xml_string = xml_string.to_string();
    let result = py.allow_threads(|| xml_utils::xml_to_object(&xml_string, &options));
    match result {
        Ok(value) => xml_value_to_pyobject(py, &value),
        Err(e) => Err(PyValueError::new_err(e)),
    }
}

#[pyfunction(name = "parse_base_element")]
#[pyo3(signature = (elem_text, parse_empty_tags_as_none=false, parse_null_text_as_none=true))]
fn py_parse_base_element(
    py: Python<'_>,
    elem_text: Option<&str>,
    parse_empty_tags_as_none: bool,
    parse_null_text_as_none: bool,
) -> PyResult<PyObject> {
    let value =
        xml_utils::parse_base_element(elem_text, parse_empty_tags_as_none, parse_null_text_as_none);
    xml_value_to_pyobject(py, &value)
}

// --- Conversion helpers ---

fn tag_match_to_py(py: Python<'_>, m: &TagMatch, return_attributes: bool) -> PyResult<PyObject> {
    if return_attributes {
        let dict = PyDict::new_bound(py);
        dict.set_item("content", &m.content)?;
        let attrs = PyDict::new_bound(py);
        for (k, v) in &m.attributes {
            attrs.set_item(k, v)?;
        }
        dict.set_item("attributes", attrs)?;
        Ok(dict.unbind().into())
    } else {
        Ok(m.content.clone().to_object(py))
    }
}

fn xml_value_from_pyany(obj: &Bound<'_, PyAny>) -> PyResult<XmlValue> {
    if obj.is_none() {
        return Ok(XmlValue::Null);
    }
    // Check bool before int (Python bool is a subclass of int)
    if obj.is_instance_of::<PyBool>() {
        let b: bool = obj.extract()?;
        return Ok(XmlValue::String(
            if b { "True" } else { "False" }.to_string(),
        ));
    }
    if obj.is_instance_of::<PyInt>() {
        let i: i64 = obj.extract()?;
        return Ok(XmlValue::Int(i));
    }
    if obj.is_instance_of::<PyFloat>() {
        let f: f64 = obj.extract()?;
        return Ok(XmlValue::Float(f));
    }
    if obj.is_instance_of::<PyString>() {
        let s: String = obj.extract()?;
        return Ok(XmlValue::String(s));
    }
    if obj.is_instance_of::<PyDict>() {
        let dict = obj.downcast::<PyDict>()?;
        let mut entries = Vec::new();
        for (k, v) in dict {
            let key: String = k.extract()?;
            let val = xml_value_from_pyany(&v)?;
            entries.push((key, val));
        }
        return Ok(XmlValue::Dict(entries));
    }
    // Try as iterable (list, tuple, etc.)
    if let Ok(iter) = obj.iter() {
        let mut items = Vec::new();
        for item in iter {
            items.push(xml_value_from_pyany(&item?)?);
        }
        return Ok(XmlValue::List(items));
    }
    // Fallback: convert to string
    let s: String = obj.str()?.extract()?;
    Ok(XmlValue::String(s))
}

fn xml_value_to_pyobject(py: Python<'_>, value: &XmlValue) -> PyResult<PyObject> {
    match value {
        XmlValue::Null => Ok(py.None()),
        XmlValue::Int(i) => Ok(i.to_object(py)),
        XmlValue::Float(f) => Ok(f.to_object(py)),
        XmlValue::String(s) => Ok(s.to_object(py)),
        XmlValue::List(items) => {
            let list = PyList::empty_bound(py);
            for item in items {
                list.append(xml_value_to_pyobject(py, item)?)?;
            }
            Ok(list.unbind().into())
        }
        XmlValue::Dict(entries) => {
            let dict = PyDict::new_bound(py);
            for (k, v) in entries {
                dict.set_item(k, xml_value_to_pyobject(py, v)?)?;
            }
            Ok(dict.unbind().into())
        }
    }
}

// ---------------------------------------------------------------------------
// Module registration
// ---------------------------------------------------------------------------

#[pymodule]
fn _core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Markdownify
    m.add_function(wrap_pyfunction!(markdownify, m)?)?;
    m.add_function(wrap_pyfunction!(markdownify_batch, m)?)?;
    m.add_class::<PyMarkdownConverter>()?;

    // Markdown -> HTML
    m.add_function(wrap_pyfunction!(py_markdown_to_html, m)?)?;
    m.add_function(wrap_pyfunction!(py_markdown_to_html_batch, m)?)?;
    m.add_class::<PyMarkdownToHtmlConverter>()?;

    // markdown_utils
    m.add_function(wrap_pyfunction!(py_split_into_chunks, m)?)?;
    m.add_function(wrap_pyfunction!(py_split_into_chunks_batch, m)?)?;
    m.add_function(wrap_pyfunction!(py_coalesce_small_chunks, m)?)?;
    m.add_function(wrap_pyfunction!(py_cascading_split_text, m)?)?;
    m.add_function(wrap_pyfunction!(py_cascading_split_text_batch, m)?)?;
    m.add_function(wrap_pyfunction!(py_split_on_dividers, m)?)?;
    m.add_function(wrap_pyfunction!(py_link_percentage, m)?)?;
    m.add_function(wrap_pyfunction!(py_link_percentage_batch, m)?)?;
    m.add_function(wrap_pyfunction!(py_filter_by_link_percentage, m)?)?;
    m.add_function(wrap_pyfunction!(py_strip_links_with_substring, m)?)?;
    m.add_function(wrap_pyfunction!(py_strip_links_with_substring_batch, m)?)?;
    m.add_function(wrap_pyfunction!(py_remove_large_tables, m)?)?;
    m.add_function(wrap_pyfunction!(py_remove_large_tables_batch, m)?)?;
    m.add_function(wrap_pyfunction!(py_strip_html_and_contents, m)?)?;
    m.add_function(wrap_pyfunction!(py_strip_html_and_contents_batch, m)?)?;
    m.add_function(wrap_pyfunction!(py_remove_lines_with_substring, m)?)?;
    m.add_function(wrap_pyfunction!(py_remove_lines_with_substring_batch, m)?)?;
    m.add_function(wrap_pyfunction!(py_fix_newlines, m)?)?;
    m.add_function(wrap_pyfunction!(py_fix_newlines_batch, m)?)?;
    m.add_function(wrap_pyfunction!(py_strip_data_uri_images, m)?)?;
    m.add_function(wrap_pyfunction!(py_text_pipeline_batch, m)?)?;

    m.add("ATX", "atx")?;
    m.add("ATX_CLOSED", "atx_closed")?;
    m.add("UNDERLINED", "underlined")?;
    m.add("SETEXT", "underlined")?;

    m.add("SPACES", "spaces")?;
    m.add("BACKSLASH", "backslash")?;

    m.add("ASTERISK", "*")?;
    m.add("UNDERSCORE", "_")?;

    m.add("LSTRIP", "lstrip")?;
    m.add("RSTRIP", "rstrip")?;
    m.add("STRIP", "strip")?;
    m.add("STRIP_ONE", "strip_one")?;

    // xml_utils
    m.add_function(wrap_pyfunction!(py_get_tag, m)?)?;
    m.add_function(wrap_pyfunction!(py_get_tags, m)?)?;
    m.add_function(wrap_pyfunction!(py_strip_xml, m)?)?;
    m.add_function(wrap_pyfunction!(py_remove_namespace_prefixes, m)?)?;
    m.add_function(wrap_pyfunction!(py_object_to_xml, m)?)?;
    m.add_function(wrap_pyfunction!(py_xml_to_object, m)?)?;
    m.add_function(wrap_pyfunction!(py_parse_base_element, m)?)?;

    Ok(())
}
