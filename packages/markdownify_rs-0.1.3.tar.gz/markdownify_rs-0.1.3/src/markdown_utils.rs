use once_cell::sync::Lazy;
use rayon::prelude::*;
use regex::Regex;

static SECTION_START_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(
        r"(?i)^\s*#{1,6}\s*(?:(?:Chapter|Section|Division|Article|Part|Appendix)\b|\d+(?:\.\d+)+|§|\([A-Za-z0-9]+\)|\[[A-Za-z0-9]+\]|[A-Za-z0-9]+\)).*$",
    )
    .expect("valid SECTION_START_RE")
});

static STATUTE_SECTION_START_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(
        r"(?i)^\s*(?:§{1,2}\s*\d[0-9A-Za-z]*(?:-\d[0-9A-Za-z]*)*(?:\.\d[0-9A-Za-z]*)?\s*[.:]|SECTION\s+\d[0-9A-Za-z]*(?:-\d[0-9A-Za-z]*)*(?:\.\d[0-9A-Za-z]*)?\s*[.:])",
    )
    .expect("valid STATUTE_SECTION_START_RE")
});

static NUMBERED_SECTION_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"^\d+\.\d+[A-Za-z]?\s+[A-Z]").expect("valid NUMBERED_SECTION_RE"));

static BULLET_RE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"^([ \t]*)(?:[-+*]|\d+[.)]|[A-Za-z][.)]|[IVXLCDM]+\.[ \t]|\([A-Za-z]+\))[ \t]+")
        .expect("valid BULLET_RE")
});

static STRIP_SINGLE_TAG_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"(?i)<[^>]+?>").expect("valid STRIP_SINGLE_TAG_RE"));

static SENTENCE_BOUNDARY_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"[.!?]\s+[A-Z]").expect("valid SENTENCE_BOUNDARY_RE"));

#[derive(Debug, Clone, PartialEq, Eq)]
struct LinkMatch {
    start: usize,
    end: usize,
    text_start: usize,
    text_end: usize,
    url_start: usize,
    url_end: usize,
}

#[derive(Debug, Clone, PartialEq)]
pub enum TextPipelineStep {
    StripLinksWithSubstring { substring: String },
    RemoveLargeTables { max_cells: usize },
    StripHtmlAndContents,
    FixNewlines,
    RemoveLinesWithSubstring { substring: String },
    StripDataUriImages,
}

pub fn strip_data_uri_images(markdown: &str) -> String {
    let links = find_markdown_links(markdown);
    if links.is_empty() {
        return markdown.to_string();
    }

    let bytes = markdown.as_bytes();
    let mut out = String::with_capacity(markdown.len());
    let mut last = 0usize;

    for link in &links {
        let url = &markdown[link.url_start..link.url_end];
        if !starts_with_data_image(url) {
            continue;
        }

        let remove_start = if link.start > 0 && bytes[link.start - 1] == b'!' {
            link.start - 1
        } else {
            link.start
        };

        if remove_start > last {
            out.push_str(&markdown[last..remove_start]);
        }
        last = link.end;
    }

    if last == 0 {
        return markdown.to_string();
    }

    out.push_str(&markdown[last..]);
    out
}

pub fn strip_html_and_contents(text: &str) -> String {
    if text.is_empty() {
        return String::new();
    }

    // Use a deterministic parser path to avoid regex backtracking explosions
    // and malformed matches like `<br> ... </b>` swallowing large spans.
    let without_pairs = remove_paired_tags(text);
    STRIP_SINGLE_TAG_RE
        .replace_all(&without_pairs, "")
        .into_owned()
}

pub fn strip_html_and_contents_batch(texts: Vec<String>) -> Vec<String> {
    texts
        .into_par_iter()
        .map(|text| strip_html_and_contents(&text))
        .collect()
}

pub fn split_on_dividers(markdown: &str) -> Vec<String> {
    let mut chunks = Vec::new();
    let mut current: Vec<&str> = Vec::new();

    for line in markdown.lines() {
        if is_divider_line(line) {
            if !current.is_empty() {
                let chunk = current.join("\n");
                chunks.push(chunk.trim_end().to_string());
                current.clear();
            }
        } else {
            current.push(line);
        }
    }

    if !current.is_empty() {
        let chunk = current.join("\n");
        chunks.push(chunk.trim_end().to_string());
    }

    chunks
}

pub fn link_percentage(chunk: &str) -> f64 {
    if chunk.is_empty() {
        return 0.0;
    }
    let total_chars = char_count(chunk);
    if total_chars == 0 {
        return 0.0;
    }

    let link_chars: usize = find_markdown_links(chunk)
        .iter()
        .map(|m| char_count(&chunk[m.start..m.end]))
        .sum();

    link_chars as f64 / total_chars as f64
}

pub fn link_percentage_batch(chunks: Vec<String>) -> Vec<f64> {
    chunks
        .into_par_iter()
        .map(|chunk| link_percentage(&chunk))
        .collect()
}

pub fn filter_by_link_percentage(chunks: Vec<String>, threshold: f64) -> Vec<String> {
    if chunks.len() < 512 {
        return chunks
            .into_iter()
            .filter(|chunk| link_percentage(chunk) < threshold)
            .collect();
    }

    let scores: Vec<f64> = chunks
        .par_iter()
        .map(|chunk| link_percentage(chunk))
        .collect();
    chunks
        .into_iter()
        .zip(scores)
        .filter_map(|(chunk, score)| (score < threshold).then_some(chunk))
        .collect()
}

pub fn strip_links_with_substring(text: &str, substring: &str) -> String {
    let links = find_markdown_links(text);
    if links.is_empty() {
        return text.to_string();
    }

    let mut out = String::with_capacity(text.len());
    let mut last = 0usize;

    for link in &links {
        out.push_str(&text[last..link.start]);
        let url = &text[link.url_start..link.url_end];
        if url.contains(substring) {
            out.push_str(&text[link.text_start..link.text_end]);
        } else {
            out.push_str(&text[link.start..link.end]);
        }
        last = link.end;
    }

    out.push_str(&text[last..]);
    out
}

pub fn strip_links_with_substring_batch(texts: Vec<String>, substring: &str) -> Vec<String> {
    let substring = substring.to_string();
    texts
        .into_par_iter()
        .map(|text| strip_links_with_substring(&text, &substring))
        .collect()
}

pub fn remove_large_tables(text: &str, max_cells: usize) -> String {
    let lines: Vec<&str> = text.split_inclusive('\n').collect();
    if lines.is_empty() {
        return String::new();
    }

    let mut out: Vec<&str> = Vec::with_capacity(lines.len());
    let mut i = 0usize;

    while i < lines.len() {
        if is_table_line_fragment(lines[i]) {
            let start = i;
            let mut cells = 0usize;

            while i < lines.len() && is_table_line_fragment(lines[i]) {
                let line_no_newline = lines[i].strip_suffix('\n').unwrap_or(lines[i]);
                cells += line_no_newline.matches('|').count().saturating_sub(1);
                i += 1;
            }

            if cells <= max_cells {
                out.extend_from_slice(&lines[start..i]);
            }
        } else {
            out.push(lines[i]);
            i += 1;
        }
    }

    out.concat()
}

pub fn remove_large_tables_batch(texts: Vec<String>, max_cells: usize) -> Vec<String> {
    texts
        .into_par_iter()
        .map(|text| remove_large_tables(&text, max_cells))
        .collect()
}

pub fn remove_lines_with_substring(text: &str, substring: &str) -> String {
    if substring.is_empty() {
        return String::new();
    }
    let has_substring = text.contains(substring);

    let mut out = String::with_capacity(text.len());
    let mut wrote_line = false;

    for line in text.lines() {
        if has_substring && line.contains(substring) {
            continue;
        }
        if wrote_line {
            out.push('\n');
        }
        out.push_str(line);
        wrote_line = true;
    }

    out
}

pub fn remove_lines_with_substring_batch(texts: Vec<String>, substring: &str) -> Vec<String> {
    let substring = substring.to_string();
    texts
        .into_par_iter()
        .map(|text| remove_lines_with_substring(&text, &substring))
        .collect()
}

pub fn fix_newlines(text: &str) -> String {
    if !text.contains("\n\n\n") {
        return text.to_string();
    }

    let bytes = text.as_bytes();
    let mut out = String::with_capacity(text.len());
    let mut i = 0usize;

    while i < bytes.len() {
        if bytes[i] == b'\n' {
            let start = i;
            while i < bytes.len() && bytes[i] == b'\n' {
                i += 1;
            }
            if i - start >= 3 {
                out.push_str("\n\n");
            } else {
                out.push_str(&text[start..i]);
            }
            continue;
        }

        let start = i;
        while i < bytes.len() && bytes[i] != b'\n' {
            i += 1;
        }
        out.push_str(&text[start..i]);
    }

    out
}

pub fn fix_newlines_batch(texts: Vec<String>) -> Vec<String> {
    texts
        .into_par_iter()
        .map(|text| fix_newlines(&text))
        .collect()
}

pub fn text_pipeline(text: &str, steps: &[TextPipelineStep]) -> String {
    let mut current = text.to_string();
    for step in steps {
        current = match step {
            TextPipelineStep::StripLinksWithSubstring { substring } => {
                strip_links_with_substring(&current, substring)
            }
            TextPipelineStep::RemoveLargeTables { max_cells } => {
                remove_large_tables(&current, *max_cells)
            }
            TextPipelineStep::StripHtmlAndContents => strip_html_and_contents(&current),
            TextPipelineStep::FixNewlines => fix_newlines(&current),
            TextPipelineStep::RemoveLinesWithSubstring { substring } => {
                remove_lines_with_substring(&current, substring)
            }
            TextPipelineStep::StripDataUriImages => strip_data_uri_images(&current),
        };
    }
    current
}

pub fn text_pipeline_batch(texts: Vec<String>, steps: Vec<TextPipelineStep>) -> Vec<String> {
    if steps.is_empty() {
        return texts;
    }

    texts
        .into_par_iter()
        .map(|text| {
            let mut current = text;
            for step in &steps {
                current = match step {
                    TextPipelineStep::StripLinksWithSubstring { substring } => {
                        strip_links_with_substring(&current, substring)
                    }
                    TextPipelineStep::RemoveLargeTables { max_cells } => {
                        remove_large_tables(&current, *max_cells)
                    }
                    TextPipelineStep::StripHtmlAndContents => strip_html_and_contents(&current),
                    TextPipelineStep::FixNewlines => fix_newlines(&current),
                    TextPipelineStep::RemoveLinesWithSubstring { substring } => {
                        remove_lines_with_substring(&current, substring)
                    }
                    TextPipelineStep::StripDataUriImages => strip_data_uri_images(&current),
                };
            }
            current
        })
        .collect()
}

pub fn coalesce_small_chunks(chunks: Vec<String>, min_size: usize) -> Vec<String> {
    if chunks.is_empty() {
        return Vec::new();
    }

    let mut merged = Vec::with_capacity(chunks.len());
    let mut i = 0usize;

    while i < chunks.len() {
        let mut accumulated = chunks[i].clone();
        let mut j = i + 1;

        while char_count(&accumulated) < min_size && j < chunks.len() {
            accumulated = format!("{}\n\n{}", accumulated.trim_end(), chunks[j].trim_start());
            j += 1;
        }

        merged.push(accumulated);
        i = j;
    }

    merged
}

pub fn split_into_chunks(markdown: &str, how: &str) -> Vec<String> {
    if how == "lists" {
        return split_lists_indent(markdown, 8_000);
    }

    let lines: Vec<&str> = markdown.lines().collect();
    let mut out: Vec<String> = Vec::new();
    let mut current: Vec<&str> = Vec::new();
    let mut current_length = 0usize;
    let max_len = 5_000usize;

    for line in &lines {
        if how == "sections" && is_section_heading(line) && !current.is_empty() {
            out.push(join_and_trim(&current));
            current.clear();
            current.push(line);
            current_length = char_count(line);
        } else if how == "statute_sections"
            && STATUTE_SECTION_START_RE.is_match(line)
            && !current.is_empty()
        {
            out.push(join_and_trim(&current));
            current.clear();
            current.push(line);
            current_length = char_count(line);
        } else if how == "headings" && is_heading_any(line) && !current.is_empty() {
            out.push(join_and_trim(&current));
            current.clear();
            current.push(line);
            current_length = char_count(line);
        } else if is_exact_heading_level(how, line) && !current.is_empty() {
            out.push(join_and_trim(&current));
            current.clear();
            current.push(line);
            current_length = char_count(line);
        } else if how == "links" && line_starts_with_markdown_link(line) && !current.is_empty() {
            out.push(join_and_trim(&current));
            current.clear();
            current.push(line);
            current_length = char_count(line);
        } else if how == "bold" && line.trim().starts_with("**") {
            out.push(join_and_trim(&current));
            current.clear();
            current.push(line);
            current_length = char_count(line);
        } else if how == "italic" && line.trim().starts_with('*') {
            out.push(join_and_trim(&current));
            current.clear();
            current.push(line);
            current_length = char_count(line);
        } else if how == "numbering" && NUMBERED_SECTION_RE.is_match(line) && !current.is_empty() {
            out.push(join_and_trim(&current));
            current.clear();
            current.push(line);
            current_length = char_count(line);
        } else if how == "brute" && current_length > max_len {
            out.push(join_and_trim(&current));
            current.clear();
            current.push(line);
            current_length = char_count(line);
        } else {
            current.push(line);
            current_length += char_count(line);
        }
    }

    if !current.is_empty() {
        out.push(join_and_trim(&current));
    }

    if how == "brute" {
        let mut final_out = Vec::new();
        for chunk in out {
            if char_count(&chunk) <= max_len * 2 {
                final_out.push(chunk);
            } else {
                final_out.extend(brute_split_oversized(&chunk, max_len));
            }
        }
        out = final_out;
    }

    out.into_iter().filter(|chunk| !chunk.is_empty()).collect()
}

pub fn split_into_chunks_batch(markdown_list: Vec<String>, how: &str) -> Vec<Vec<String>> {
    let how = how.to_string();
    markdown_list
        .into_par_iter()
        .map(|markdown| split_into_chunks(&markdown, &how))
        .collect()
}

pub fn cascading_split_text(
    content: &str,
    how: &[String],
    max_length: usize,
    coalesce_min: usize,
) -> Vec<String> {
    let mut working = vec![content.to_string()];

    for step in how {
        let mut next = Vec::new();
        for chunk in working {
            if char_count(&chunk) <= max_length {
                next.push(chunk);
            } else {
                let split = split_into_chunks(&chunk, step);
                next.extend(coalesce_small_chunks(split, coalesce_min));
            }
        }
        working = next;
    }

    working
}

pub fn cascading_split_text_batch(
    contents: Vec<String>,
    how: Vec<String>,
    max_length: usize,
    coalesce_min: usize,
) -> Vec<Vec<String>> {
    contents
        .into_par_iter()
        .map(|content| cascading_split_text(&content, &how, max_length, coalesce_min))
        .collect()
}

fn join_and_trim(lines: &[&str]) -> String {
    lines.join("\n").trim().to_string()
}

fn char_count(s: &str) -> usize {
    s.chars().count()
}

fn is_section_heading(line: &str) -> bool {
    SECTION_START_RE.is_match(line)
}

fn is_heading_any(line: &str) -> bool {
    let trimmed = line.trim_start();
    let bytes = trimmed.as_bytes();
    let mut hashes = 0usize;
    while hashes < bytes.len() && bytes[hashes] == b'#' {
        hashes += 1;
    }
    if !(1..=6).contains(&hashes) {
        return false;
    }
    bytes.get(hashes) == Some(&b' ')
}

fn is_heading_level(line: &str, level: usize) -> bool {
    let trimmed = line.trim_start();
    let bytes = trimmed.as_bytes();
    if bytes.len() <= level {
        return false;
    }
    if !bytes[..level].iter().all(|b| *b == b'#') {
        return false;
    }
    if bytes.get(level) == Some(&b'#') {
        return false;
    }
    bytes.get(level) == Some(&b' ')
}

fn is_exact_heading_level(how: &str, line: &str) -> bool {
    match how {
        "heading1" => is_heading_level(line, 1),
        "heading2" => is_heading_level(line, 2),
        "heading3" => is_heading_level(line, 3),
        "heading4" => is_heading_level(line, 4),
        "heading5" => is_heading_level(line, 5),
        "heading6" => is_heading_level(line, 6),
        _ => false,
    }
}

fn split_lists_indent(markdown: &str, max_chars: usize) -> Vec<String> {
    let lines: Vec<&str> = markdown.lines().collect();
    let bullets = find_bullets(&lines);
    split_on_indent(&lines, &bullets, max_chars)
}

fn find_bullets(lines: &[&str]) -> Vec<(usize, usize)> {
    let mut out = Vec::new();
    for (idx, line) in lines.iter().enumerate() {
        if let Some(captures) = BULLET_RE.captures(line) {
            let indent_group = captures.get(1).map(|m| m.as_str()).unwrap_or("");
            let indent = expandtabs_width(indent_group, 4);
            out.push((idx, indent));
        }
    }
    out
}

fn split_on_indent(lines: &[&str], bullets: &[(usize, usize)], max_chars: usize) -> Vec<String> {
    if bullets.is_empty() {
        return vec![lines.join("\n").trim_end().to_string()];
    }

    let min_indent = bullets.iter().map(|(_, indent)| *indent).min().unwrap_or(0);
    let starts: Vec<usize> = bullets
        .iter()
        .filter_map(|(line_no, indent)| (*indent == min_indent).then_some(*line_no))
        .collect();

    let mut chunks = Vec::new();
    for (idx, start) in starts.iter().enumerate() {
        let end = starts.get(idx + 1).copied().unwrap_or(lines.len());
        let block = &lines[*start..end];
        let text = block.join("\n").trim_end().to_string();

        if char_count(&text) > max_chars {
            let sub_bullets: Vec<(usize, usize)> = bullets
                .iter()
                .filter_map(|(line_no, indent)| {
                    (*start < *line_no && *line_no < end && *indent > min_indent)
                        .then(|| (line_no - start, *indent))
                })
                .collect();
            if !sub_bullets.is_empty() {
                chunks.extend(split_on_indent(block, &sub_bullets, max_chars));
                continue;
            }
        }
        chunks.push(text);
    }

    chunks
}

fn brute_split_oversized(text: &str, max_len: usize) -> Vec<String> {
    if char_count(text) <= max_len * 2 {
        return vec![text.to_string()];
    }

    let sentences = split_on_sentence_boundaries(text);
    let mut result = Vec::new();
    let mut current: Vec<&str> = Vec::new();
    let mut current_len = 0usize;

    for sentence in &sentences {
        let sentence_len = char_count(sentence);
        if current_len + sentence_len + 1 > max_len && !current.is_empty() {
            let chunk = current.join(" ");
            if char_count(&chunk) > max_len * 2 {
                result.extend(split_on_words(&chunk, max_len));
            } else {
                result.push(chunk);
            }
            current.clear();
            current.push(sentence);
            current_len = sentence_len;
        } else {
            current.push(sentence);
            current_len += sentence_len + 1;
        }
    }

    if !current.is_empty() {
        let chunk = current.join(" ");
        if char_count(&chunk) > max_len * 2 {
            result.extend(split_on_words(&chunk, max_len));
        } else {
            result.push(chunk);
        }
    }

    result
}

fn split_on_words(text: &str, max_len: usize) -> Vec<String> {
    if char_count(text) <= max_len * 2 {
        return vec![text.to_string()];
    }

    let words: Vec<&str> = text.split_whitespace().collect();
    let mut result = Vec::new();
    let mut current: Vec<&str> = Vec::new();
    let mut current_len = 0usize;

    for word in &words {
        let word_len = char_count(word);
        if current_len + word_len + 1 > max_len && !current.is_empty() {
            let chunk = current.join(" ");
            if char_count(&chunk) > max_len * 2 {
                result.extend(split_on_chars(&chunk, max_len));
            } else {
                result.push(chunk);
            }
            current.clear();
            current.push(word);
            current_len = word_len;
        } else {
            current.push(word);
            current_len += word_len + 1;
        }
    }

    if !current.is_empty() {
        let chunk = current.join(" ");
        if char_count(&chunk) > max_len * 2 {
            result.extend(split_on_chars(&chunk, max_len));
        } else {
            result.push(chunk);
        }
    }

    result
}

fn split_on_chars(text: &str, max_len: usize) -> Vec<String> {
    if max_len == 0 {
        return vec![text.to_string()];
    }
    let mut out = Vec::new();
    let mut current = String::new();
    let mut current_len = 0usize;

    for ch in text.chars() {
        current.push(ch);
        current_len += 1;
        if current_len >= max_len {
            out.push(current);
            current = String::new();
            current_len = 0;
        }
    }
    if !current.is_empty() {
        out.push(current);
    }
    out
}

fn split_on_sentence_boundaries(text: &str) -> Vec<&str> {
    let mut out = Vec::new();
    let mut last = 0usize;

    for m in SENTENCE_BOUNDARY_RE.find_iter(text) {
        let punct_end = m.start() + 1;
        let mut next_start = punct_end;
        while next_start < text.len() {
            let mut chars = text[next_start..].chars();
            let ch = match chars.next() {
                Some(ch) => ch,
                None => break,
            };
            if ch.is_whitespace() {
                next_start += ch.len_utf8();
            } else {
                break;
            }
        }
        out.push(&text[last..punct_end]);
        last = next_start;
    }

    out.push(&text[last..]);
    out
}

fn line_starts_with_markdown_link(line: &str) -> bool {
    match line.as_bytes().first() {
        Some(b'[') => parse_markdown_link_at(line, 0).is_some(),
        _ => false,
    }
}

fn starts_with_data_image(url: &str) -> bool {
    let trimmed = url.trim_start();
    trimmed
        .get(..10)
        .map(|prefix| prefix.eq_ignore_ascii_case("data:image"))
        .unwrap_or(false)
}

fn is_table_line(line: &str) -> bool {
    line.trim_start_matches([' ', '\t']).starts_with('|')
}

fn is_table_line_fragment(fragment: &str) -> bool {
    let line = fragment.strip_suffix('\n').unwrap_or(fragment);
    is_table_line(line)
}

fn is_divider_line(line: &str) -> bool {
    let trimmed = line.trim();
    if trimmed.chars().count() < 5 {
        return false;
    }
    let mut chars = trimmed.chars();
    let first = match chars.next() {
        Some(ch @ ('=' | '-')) => ch,
        _ => return false,
    };
    chars.all(|ch| ch == first)
}

fn expandtabs_width(input: &str, tabsize: usize) -> usize {
    let mut width = 0usize;
    for ch in input.chars() {
        if ch == '\t' {
            let remainder = width % tabsize;
            width += if remainder == 0 {
                tabsize
            } else {
                tabsize - remainder
            };
        } else {
            width += 1;
        }
    }
    width
}

fn find_markdown_links(text: &str) -> Vec<LinkMatch> {
    let bytes = text.as_bytes();
    let mut links = Vec::new();
    let mut i = 0usize;

    while i < bytes.len() {
        let offset = match bytes[i..].iter().position(|b| *b == b'[') {
            Some(offset) => offset,
            None => break,
        };
        let start = i + offset;
        if let Some(link_match) = parse_markdown_link_at(text, start) {
            i = link_match.end;
            links.push(link_match);
        } else {
            i = start + 1;
        }
    }

    links
}

fn parse_markdown_link_at(text: &str, start: usize) -> Option<LinkMatch> {
    let bytes = text.as_bytes();
    if *bytes.get(start)? != b'[' {
        return None;
    }

    let mut i = start + 1;
    let mut bracket_depth = 1usize;
    while i < bytes.len() {
        match bytes[i] {
            b'[' => bracket_depth += 1,
            b']' => {
                bracket_depth -= 1;
                if bracket_depth == 0 {
                    break;
                }
            }
            _ => {}
        }
        i += 1;
    }
    if bracket_depth != 0 || i >= bytes.len() {
        return None;
    }
    let text_end = i;

    let open_paren = i + 1;
    if *bytes.get(open_paren)? != b'(' {
        return None;
    }

    let mut j = open_paren + 1;
    let mut paren_depth = 1usize;
    while j < bytes.len() {
        match bytes[j] {
            b'(' => paren_depth += 1,
            b')' => {
                paren_depth -= 1;
                if paren_depth == 0 {
                    break;
                }
            }
            _ => {}
        }
        j += 1;
    }
    if paren_depth != 0 || j >= bytes.len() {
        return None;
    }

    Some(LinkMatch {
        start,
        end: j + 1,
        text_start: start + 1,
        text_end,
        url_start: open_paren + 1,
        url_end: j,
    })
}

fn remove_paired_tags(text: &str) -> String {
    let mut stack: Vec<(String, usize)> = Vec::new();
    let mut ranges: Vec<(usize, usize)> = Vec::new();
    let bytes = text.as_bytes();
    let mut i = 0usize;

    while i < bytes.len() {
        if bytes[i] != b'<' {
            i += 1;
            continue;
        }
        let close = match bytes[i + 1..].iter().position(|b| *b == b'>') {
            Some(offset) => i + 1 + offset,
            None => break,
        };

        let tag = &text[i..=close];
        if let Some((name, is_closing, is_self_closing)) = parse_tag_name(tag) {
            if !is_closing && !is_self_closing {
                stack.push((name, i));
            } else if is_closing {
                if let Some(idx) = stack.iter().rposition(|(open_name, _)| *open_name == name) {
                    let start = stack[idx].1;
                    stack.truncate(idx);
                    ranges.push((start, close + 1));
                }
            }
        }

        i = close + 1;
    }

    if ranges.is_empty() {
        return text.to_string();
    }

    ranges.sort_by_key(|(start, _)| *start);
    let mut merged: Vec<(usize, usize)> = Vec::with_capacity(ranges.len());
    for (start, end) in ranges {
        if let Some(last) = merged.last_mut() {
            if start <= last.1 {
                if end > last.1 {
                    last.1 = end;
                }
            } else {
                merged.push((start, end));
            }
        } else {
            merged.push((start, end));
        }
    }

    let mut out = String::with_capacity(text.len());
    let mut last = 0usize;
    for (start, end) in merged {
        if start > last {
            out.push_str(&text[last..start]);
        }
        last = end;
    }
    out.push_str(&text[last..]);
    out
}

fn parse_tag_name(tag: &str) -> Option<(String, bool, bool)> {
    let trimmed = tag.trim();
    if !trimmed.starts_with('<') || !trimmed.ends_with('>') {
        return None;
    }
    if trimmed.starts_with("<!--")
        || trimmed.starts_with("<!")
        || trimmed.starts_with("<?")
        || trimmed.starts_with("<%")
    {
        return None;
    }

    let is_closing = trimmed.starts_with("</");
    let is_self_closing = trimmed.ends_with("/>");

    let mut content = if is_closing {
        trimmed.trim_start_matches("</")
    } else {
        trimmed.trim_start_matches('<')
    };
    content = content.trim_end_matches('>');
    content = content.trim_end_matches('/');
    content = content.trim_start();

    let mut name = String::new();
    for ch in content.chars() {
        if ch.is_ascii_alphanumeric() || ch == '-' || ch == '_' || ch == ':' {
            name.push(ch.to_ascii_lowercase());
        } else {
            break;
        }
    }
    if name.is_empty() {
        return None;
    }

    Some((name, is_closing, is_self_closing))
}
