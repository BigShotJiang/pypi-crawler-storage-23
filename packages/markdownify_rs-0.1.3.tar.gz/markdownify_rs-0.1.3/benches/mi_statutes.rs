use std::env;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::path::PathBuf;
use std::time::Duration;

use criterion::{BenchmarkId, Criterion, Throughput, black_box, criterion_group, criterion_main};
use markdownify_rs::{MarkdownConverter, Options};
use serde_json::Value;

fn dataset_path() -> PathBuf {
    dotenvy::dotenv().ok();
    env::var("MARKDOWNIFY_BENCH_PATH")
        .map(PathBuf::from)
        .unwrap_or_default()
}

fn load_html(path: &PathBuf) -> Vec<String> {
    let file =
        File::open(path).unwrap_or_else(|_| panic!("failed to open dataset at {}", path.display()));
    let reader = BufReader::new(file);
    let mut html = Vec::new();
    for line in reader.lines() {
        let line = line.expect("failed to read line");
        let value: Value = serde_json::from_str(&line).expect("invalid json line");
        let content = value
            .get("content")
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();
        html.push(content);
    }
    html
}

fn bench_mi_statutes(c: &mut Criterion) {
    let path = dataset_path();
    if path.as_os_str().is_empty() || !path.exists() {
        eprintln!("benchmark dataset not found (set MARKDOWNIFY_BENCH_PATH in .env or env)",);
        return;
    }

    let html = load_html(&path);
    if html.is_empty() {
        eprintln!("dataset at {} contained no records", path.display());
        return;
    }

    let total_bytes: usize = html.iter().map(|s| s.len()).sum();
    let (max_idx, max_len) = html
        .iter()
        .enumerate()
        .map(|(idx, s)| (idx, s.len()))
        .max_by_key(|(_, len)| *len)
        .unwrap();

    let converter = MarkdownConverter::new(Options::default());

    let mut group = c.benchmark_group("mi_statutes");
    group.warm_up_time(Duration::from_secs(1));
    group.measurement_time(Duration::from_secs(6));
    group.sample_size(10);
    group.throughput(Throughput::Bytes(total_bytes as u64));
    group.bench_function(BenchmarkId::new("convert_all", html.len()), |b| {
        b.iter(|| {
            for doc in &html {
                black_box(converter.convert(doc));
            }
        });
    });

    let largest = &html[max_idx];
    group.throughput(Throughput::Bytes(max_len as u64));
    group.bench_function(BenchmarkId::new("convert_largest", max_len), |b| {
        b.iter(|| {
            black_box(converter.convert(largest));
        });
    });
    group.finish();
}

criterion_group!(benches, bench_mi_statutes);
criterion_main!(benches);
