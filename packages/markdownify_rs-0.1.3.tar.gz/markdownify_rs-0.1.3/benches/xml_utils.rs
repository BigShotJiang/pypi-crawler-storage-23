use criterion::{Criterion, black_box, criterion_group, criterion_main};
use markdownify_rs::xml_utils::*;

fn build_medium_value() -> XmlValue {
    let mut users = Vec::new();
    for i in 0..50 {
        users.push(XmlValue::Dict(vec![
            ("name".into(), XmlValue::String(format!("user_{i}"))),
            ("age".into(), XmlValue::Int(20 + i)),
            ("score".into(), XmlValue::Float(95.5 + i as f64 * 0.1)),
            (
                "email".into(),
                XmlValue::String(format!("user_{i}@example.com")),
            ),
        ]));
    }
    XmlValue::Dict(vec![("users".into(), XmlValue::List(users))])
}

fn bench_strip_xml(c: &mut Criterion) {
    let input = "  some prefix text <root><child>text content here</child><other>more stuff</other></root> some suffix text ";
    c.bench_function("strip_xml", |b| {
        b.iter(|| black_box(strip_xml(black_box(input))))
    });
}

fn bench_remove_namespace_prefixes(c: &mut Criterion) {
    let input = r#"<ns:root xmlns:ns="http://example.com"><ns:child>text</ns:child><ns:other attr="val">more</ns:other></ns:root>"#;
    c.bench_function("remove_namespace_prefixes", |b| {
        b.iter(|| black_box(remove_namespace_prefixes(black_box(input))))
    });
}

fn bench_object_to_xml(c: &mut Criterion) {
    let value = build_medium_value();
    let options = ObjectToXmlOptions::default();

    c.bench_function("object_to_xml_medium", |b| {
        b.iter(|| black_box(object_to_xml(black_box(&value), "data", &options)))
    });
}

fn bench_xml_to_object(c: &mut Criterion) {
    let value = build_medium_value();
    let options_ser = ObjectToXmlOptions::default();
    let xml = object_to_xml(&value, "data", &options_ser);
    let options = XmlToObjectOptions::default();

    c.bench_function("xml_to_object_medium", |b| {
        b.iter(|| black_box(xml_to_object(black_box(&xml), &options)))
    });
}

fn bench_get_tag(c: &mut Criterion) {
    let html = "<html><body><div class='main'><p>Hello world</p><p>Second paragraph</p></div><footer>end</footer></body></html>";

    c.bench_function("get_tag", |b| {
        b.iter(|| black_box(get_tag(black_box(html), "p", false)))
    });

    c.bench_function("get_tags", |b| {
        b.iter(|| black_box(get_tags(black_box(html), "p", true)))
    });
}

criterion_group!(
    benches,
    bench_strip_xml,
    bench_remove_namespace_prefixes,
    bench_object_to_xml,
    bench_xml_to_object,
    bench_get_tag,
);
criterion_main!(benches);
