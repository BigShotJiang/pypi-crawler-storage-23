#!/usr/bin/env python3
"""
Generate parity and speed report for markdownify_rs markdown->HTML conversion.

Compares against Python-Markdown.
"""

from __future__ import annotations

import argparse
import pkgutil
import re
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import markdown as py_markdown
import markdownify_rs

NON_PARITY_EXTENSIONS = {"md_in_html", "legacy_em"}


@dataclass
class ParityCase:
    name: str
    markdown_text: str
    kwargs: dict


@dataclass
class ParityRow:
    name: str
    extensions: str
    exact: bool
    normalized: bool
    py_output: str
    rs_output: str


@dataclass
class SpeedRow:
    scenario: str
    extensions: list[str]
    docs: int
    total_bytes: int
    py_seconds: float
    rs_seconds: float
    py_mib_s: float
    rs_mib_s: float
    speedup: float


def normalize_html_output(text: str) -> str:
    normalized = text.replace("\r\n", "\n").strip()
    normalized = re.sub(r">\s+<", "><", normalized)
    normalized = normalized.replace("<br>", "<br />")
    normalized = normalized.replace("<hr>", "<hr />")
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return normalized


def extension_name_list() -> list[str]:
    import markdown.extensions as md_ext

    names = sorted(m.name for m in pkgutil.iter_modules(md_ext.__path__))
    return names


def default_parity_cases() -> list[ParityCase]:
    return [
        ParityCase("basic", "# Hello\n\nThis is **bold** and *italic*.", {}),
        ParityCase("lists", "- one\n- two\n\n1. three\n2. four", {}),
        ParityCase("blockquote", "> Quoted\n>\n> line", {}),
        ParityCase("fenced_code", "```python\nprint('x')\n```", {"extensions": ["fenced_code"]}),
        ParityCase(
            "tables",
            "| a | b |\n| - | - |\n| 1 | 2 |",
            {"extensions": ["tables"]},
        ),
        ParityCase(
            "footnotes",
            "Footnote[^1]\n\n[^1]: detail",
            {"extensions": ["footnotes"]},
        ),
        ParityCase(
            "def_list",
            "Term\n: Definition",
            {"extensions": ["def_list"]},
        ),
        ParityCase(
            "abbr",
            "*[HTML]: HyperText Markup Language\n\nHTML is common.",
            {"extensions": ["abbr"]},
        ),
        ParityCase(
            "admonition",
            "!!! note \"Heads up\"\n    body",
            {"extensions": ["admonition"]},
        ),
        ParityCase(
            "attr_list",
            "# Title {#custom .hero data-x=1}",
            {"extensions": ["attr_list"]},
        ),
        ParityCase(
            "codehilite",
            "```python\nprint('x')\n```",
            {"extensions": ["codehilite"]},
        ),
        ParityCase("meta", "Title: Demo\nAuthor: Me\n\n# Body", {"extensions": ["meta"]}),
        ParityCase(
            "nl2br",
            "line one\nline two",
            {"extensions": ["nl2br"]},
        ),
        ParityCase(
            "smarty",
            "\"quoted\" -- text...",
            {"extensions": ["smarty"]},
        ),
        ParityCase(
            "toc",
            "[TOC]\n\n# One\n\n## Two",
            {"extensions": ["toc"]},
        ),
        ParityCase(
            "wikilinks",
            "See [[My Page]].",
            {"extensions": ["wikilinks"]},
        ),
        ParityCase(
            "md_in_html",
            "<div markdown=\"1\">**inside**</div>",
            {"extensions": ["md_in_html"]},
        ),
        ParityCase(
            "legacy_attrs",
            "# Legacy {#old}",
            {"extensions": ["legacy_attrs"]},
        ),
        ParityCase(
            "legacy_em",
            "foo_bar_baz",
            {"extensions": ["legacy_em"]},
        ),
        ParityCase(
            "sane_lists",
            "1. one\n2. two\n\n- bullet",
            {"extensions": ["sane_lists"]},
        ),
        ParityCase(
            "extra",
            "*[HTTP]: HyperText Transfer Protocol\n\n# H {#x}\n\n|a|b|\n|-|-|\n|1|2|",
            {"extensions": ["extra"]},
        ),
    ]


def evaluate_parity(cases: list[ParityCase]) -> list[ParityRow]:
    rows: list[ParityRow] = []
    for case in cases:
        py_out = py_markdown.markdown(case.markdown_text, **case.kwargs)
        rs_out = markdownify_rs.markdown(case.markdown_text, **case.kwargs)
        rows.append(
            ParityRow(
                name=case.name,
                extensions=",".join(case.kwargs.get("extensions", [])) or "(none)",
                exact=py_out == rs_out,
                normalized=normalize_html_output(py_out) == normalize_html_output(rs_out),
                py_output=py_out,
                rs_output=rs_out,
            )
        )
    return rows


def load_corpus_docs(corpus_dir: Path, max_files: int | None) -> list[str]:
    docs: list[str] = []
    if corpus_dir.exists():
        for idx, path in enumerate(sorted(corpus_dir.rglob("*.md"))):
            if max_files is not None and idx >= max_files:
                break
            docs.append(path.read_text(encoding="utf-8", errors="replace"))
    if docs:
        return docs

    # fallback synthetic corpus
    base = default_parity_cases()
    for _ in range(250):
        for case in base:
            docs.append(case.markdown_text)
    return docs


def bytes_total(docs: list[str]) -> int:
    return sum(len(doc.encode("utf-8")) for doc in docs)


def mib_per_s(total_bytes: int, seconds: float) -> float:
    if seconds <= 0:
        return 0.0
    return (total_bytes / (1024 * 1024)) / seconds


def bench_once_py(docs: list[str], kwargs: dict) -> float:
    start = time.perf_counter()
    for doc in docs:
        py_markdown.markdown(doc, **kwargs)
    return time.perf_counter() - start


def bench_once_rs(docs: list[str], kwargs: dict) -> float:
    start = time.perf_counter()
    markdownify_rs.markdown_batch(docs, **kwargs)
    return time.perf_counter() - start


def bench_best_of(docs: list[str], kwargs: dict, repeats: int) -> tuple[float, float]:
    py_samples = [bench_once_py(docs, kwargs) for _ in range(repeats)]
    rs_samples = [bench_once_rs(docs, kwargs) for _ in range(repeats)]
    return min(py_samples), min(rs_samples)


def benchmark_scenarios(docs: list[str], repeats: int) -> list[SpeedRow]:
    scenarios = [
        ("base", []),
        ("extra", ["extra"]),
        ("tables+footnotes", ["tables", "footnotes"]),
    ]
    total = bytes_total(docs)
    rows: list[SpeedRow] = []
    for name, exts in scenarios:
        kwargs = {"extensions": exts} if exts else {}
        py_seconds, rs_seconds = bench_best_of(docs, kwargs, repeats)
        rows.append(
            SpeedRow(
                scenario=name,
                extensions=exts,
                docs=len(docs),
                total_bytes=total,
                py_seconds=py_seconds,
                rs_seconds=rs_seconds,
                py_mib_s=mib_per_s(total, py_seconds),
                rs_mib_s=mib_per_s(total, rs_seconds),
                speedup=(py_seconds / rs_seconds) if rs_seconds else float("inf"),
            )
        )
    return rows


def probe_extension_support(ext_names: list[str]) -> list[tuple[str, bool, str]]:
    rows: list[tuple[str, bool, str]] = []
    for ext in ext_names:
        if ext in NON_PARITY_EXTENSIONS:
            rows.append((ext, True, "accepted, intentionally not parity-targeted"))
            continue

        sample = "# Sample\n\ntext"
        if ext == "abbr":
            sample = "*[API]: Application Programming Interface\n\nAPI"
        elif ext == "admonition":
            sample = "!!! note\n    x"
        elif ext == "attr_list":
            sample = "# Heading {#x}"
        elif ext == "codehilite":
            sample = "```python\nprint('x')\n```"
        elif ext == "def_list":
            sample = "Term\n: Def"
        elif ext == "footnotes":
            sample = "Ref[^1]\n\n[^1]: note"
        elif ext == "meta":
            sample = "Title: X\n\n# Y"
        elif ext == "nl2br":
            sample = "a\nb"
        elif ext == "tables":
            sample = "|a|b|\n|-|-|\n|1|2|"
        elif ext == "toc":
            sample = "[TOC]\n\n# A"
        elif ext == "wikilinks":
            sample = "See [[A]]."

        try:
            markdownify_rs.markdown(sample, extensions=[ext])
            rows.append((ext, True, "supported"))
        except Exception as exc:  # noqa: BLE001
            rows.append((ext, False, f"error: {exc}"))
    return rows


def write_report(
    report_path: Path,
    corpus_dir: Path,
    docs_used: int,
    repeats: int,
    ext_support: list[tuple[str, bool, str]],
    parity_rows: list[ParityRow],
    speed_rows: list[SpeedRow],
) -> None:
    now = datetime.now(timezone.utc).isoformat()
    exact_count = sum(1 for row in parity_rows if row.exact)
    norm_count = sum(1 for row in parity_rows if row.normalized)
    total_cases = len(parity_rows)

    lines: list[str] = []
    lines.append("# Markdown-To-HTML Parity And Speed")
    lines.append("")
    lines.append(f"- Timestamp (UTC): {now}")
    lines.append(f"- Python-Markdown version: {py_markdown.__version__}")
    lines.append("- markdownify-rs version: 0.1.2 (local workspace)")
    lines.append(f"- Corpus path: `{corpus_dir}`")
    lines.append(f"- Corpus docs used: {docs_used}")
    lines.append(f"- Timing repeats: best-of-{repeats}")
    lines.append("")
    lines.append("## Python-Markdown Extension Coverage")
    lines.append("")
    lines.append("| Extension | Status | Notes |")
    lines.append("| --- | --- | --- |")
    for name, ok, note in ext_support:
        lines.append(f"| `{name}` | {'yes' if ok else 'no'} | {note} |")
    lines.append("")
    lines.append("## Parity Summary")
    lines.append("")
    lines.append(f"- Exact parity: {exact_count}/{total_cases} ({(exact_count / total_cases) * 100:.2f}%)")
    lines.append(
        f"- Normalized parity: {norm_count}/{total_cases} ({(norm_count / total_cases) * 100:.2f}%)"
    )
    lines.append("")
    lines.append("| Case | Extensions | Exact | Normalized |")
    lines.append("| --- | --- | --- | --- |")
    for row in parity_rows:
        lines.append(
            f"| {row.name} | `{row.extensions}` | {'yes' if row.exact else 'no'} | "
            f"{'yes' if row.normalized else 'no'} |"
        )

    mismatches = [row for row in parity_rows if not row.normalized]
    if mismatches:
        lines.append("")
        lines.append("### Parity Mismatches")
        lines.append("")
        for row in mismatches:
            lines.append(f"#### {row.name} (`{row.extensions}`)")
            lines.append("")
            lines.append("Python-Markdown:")
            lines.append("```html")
            lines.append(row.py_output.strip())
            lines.append("```")
            lines.append("")
            lines.append("markdownify-rs:")
            lines.append("```html")
            lines.append(row.rs_output.strip())
            lines.append("```")
            lines.append("")

    lines.append("## Speed Summary")
    lines.append("")
    lines.append(
        "| Scenario | Extensions | Docs | Total bytes | Python time | Rust time | "
        "Python MiB/s | Rust MiB/s | Speedup (Py/Rs) |"
    )
    lines.append("| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |")
    for row in speed_rows:
        lines.append(
            f"| {row.scenario} | `{','.join(row.extensions) or '(none)'}` | {row.docs} | "
            f"{row.total_bytes} | {row.py_seconds:.6f}s | {row.rs_seconds:.6f}s | "
            f"{row.py_mib_s:.3f} | {row.rs_mib_s:.3f} | {row.speedup:.2f}x |"
        )

    lines.append("")
    lines.append("## Notes")
    lines.append("")
    lines.append("- Exact parity is strict string equality.")
    lines.append("- Normalized parity ignores common whitespace and `<br>/<hr>` format differences.")
    lines.append(
        "- `md_in_html`, `legacy_em`, and some extension-specific edge cases are expected to diverge until further parser-level specialization is added."
    )
    lines.append("- Rust timings use `markdown_batch` to include the parallelized conversion path.")

    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--corpus-dir",
        type=Path,
        default=Path("/tmp/test_markdowns"),
        help="Directory containing markdown files for speed benchmarks.",
    )
    parser.add_argument(
        "--report",
        type=Path,
        default=Path("BENCHMARKS_MARKDOWN_TO_HTML.md"),
        help="Markdown report output path.",
    )
    parser.add_argument(
        "--repeats",
        type=int,
        default=3,
        help="Timing repeats per scenario (best-of-N).",
    )
    parser.add_argument(
        "--max-files",
        type=int,
        default=500,
        help="Cap number of docs loaded from corpus.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.repeats < 1:
        raise SystemExit("--repeats must be >= 1")
    max_files = args.max_files if args.max_files and args.max_files > 0 else None

    ext_names = extension_name_list()
    support = probe_extension_support(ext_names)
    parity_rows = evaluate_parity(default_parity_cases())
    docs = load_corpus_docs(args.corpus_dir, max_files)
    speed_rows = benchmark_scenarios(docs, args.repeats)

    write_report(
        report_path=args.report,
        corpus_dir=args.corpus_dir,
        docs_used=len(docs),
        repeats=args.repeats,
        ext_support=support,
        parity_rows=parity_rows,
        speed_rows=speed_rows,
    )

    print(f"Wrote report: {args.report}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
