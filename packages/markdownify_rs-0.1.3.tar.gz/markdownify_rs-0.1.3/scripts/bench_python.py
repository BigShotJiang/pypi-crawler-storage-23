#!/usr/bin/env python3
import argparse
import ast
import csv
import json
import os
import sys
import time
from importlib import import_module
from importlib.metadata import version as pkg_version
from pathlib import Path


def load_dotenv() -> None:
    env_path = Path(__file__).resolve().parents[1] / ".env"
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip("'").strip('"')
        if key and key not in os.environ:
            os.environ[key] = value


def dataset_path(path_arg: str | None) -> Path | None:
    load_dotenv()
    if path_arg:
        return Path(path_arg)
    path = os.environ.get("MARKDOWNIFY_BENCH_PATH")
    if path:
        return Path(path)
    return None


def extract_html(row: dict, html_col: str, json_col: str) -> str | None:
    html = row.get(html_col) if html_col else None
    if html:
        return html

    json_blob = row.get(json_col) if json_col else None
    if not json_blob:
        return None

    data = None
    try:
        data = json.loads(json_blob)
    except Exception:
        try:
            data = ast.literal_eval(json_blob)
        except Exception:
            return None

    if not isinstance(data, dict):
        return None

    html = data.get("html") or data.get("content")
    if not html and isinstance(data.get("data"), dict):
        nested = data.get("data")
        html = nested.get("html") or nested.get("content")
    return html


def load_html_jsonl(path: Path, encoding: str) -> list[str]:
    html: list[str] = []
    with path.open("r", encoding=encoding) as f:
        for line in f:
            obj = json.loads(line)
            html.append(obj.get("content", ""))
    return html


def load_html_csv(
    path: Path,
    encoding: str,
    html_col: str,
    json_col: str,
) -> list[str]:
    html: list[str] = []
    try:
        csv.field_size_limit(1024 * 1024 * 64)
    except Exception:
        pass
    with path.open("r", encoding=encoding, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            doc = extract_html(row, html_col, json_col)
            if doc:
                html.append(doc)
    return html


def load_html(path: Path, fmt: str, encoding: str, html_col: str, json_col: str) -> list[str]:
    if fmt == "csv":
        return load_html_csv(path, encoding, html_col, json_col)
    return load_html_jsonl(path, encoding)


def bytes_total(html: list[str]) -> int:
    return sum(len(doc.encode("utf-8")) for doc in html)


def bench_all(converter, html: list[str]) -> float:
    start = time.perf_counter()
    for doc in html:
        converter.convert(doc)
    end = time.perf_counter()
    return end - start


def bench_one(converter, doc: str) -> float:
    start = time.perf_counter()
    converter.convert(doc)
    end = time.perf_counter()
    return end - start


def bench_batch(batch_fn, html: list[str]) -> float:
    start = time.perf_counter()
    batch_fn(html)
    end = time.perf_counter()
    return end - start


def mib_per_s(total_bytes: int, seconds: float) -> float:
    return (total_bytes / (1024 * 1024)) / seconds if seconds else 0.0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--path", default=None, help="Path to dataset.")
    parser.add_argument(
        "--format",
        default="jsonl",
        choices=["jsonl", "csv"],
        help="Dataset format (jsonl or csv).",
    )
    parser.add_argument("--encoding", default="utf-8")
    parser.add_argument("--csv-html-column", default="html")
    parser.add_argument("--csv-json-column", default="value")
    parser.add_argument(
        "--module",
        default="markdownify",
        help="Python module to import (default: markdownify)",
    )
    parser.add_argument(
        "--dist-name",
        default=None,
        help="Distribution name for version lookup (defaults to module name)",
    )
    parser.add_argument(
        "--label",
        default=None,
        help="Label to print for this run",
    )
    parser.add_argument(
        "--no-batch",
        action="store_true",
        help="Skip batch benchmark even if the module supports it.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    path = dataset_path(args.path)
    if path is None or not path.exists():
        print(
            "dataset not found (set MARKDOWNIFY_BENCH_PATH in .env or env, or pass --path)",
            file=sys.stderr,
        )
        return 1

    html = load_html(
        path,
        args.format,
        args.encoding,
        args.csv_html_column,
        args.csv_json_column,
    )
    if not html:
        print(f"dataset at {path} contained no records", file=sys.stderr)
        return 1

    total_bytes = bytes_total(html)
    max_doc = max(html, key=len)
    max_bytes = len(max_doc.encode("utf-8"))

    module = import_module(args.module)
    converter = module.MarkdownConverter()
    batch_fn = getattr(module, "markdownify_batch", None)

    # Warm up
    for doc in html[:3]:
        converter.convert(doc)

    all_seconds = bench_all(converter, html)
    max_seconds = bench_one(converter, max_doc)
    batch_seconds = None
    if batch_fn is not None and not args.no_batch:
        batch_seconds = bench_batch(batch_fn, html)

    dist_name = args.dist_name or args.module
    label = args.label or args.module
    print(f"label: {label}")
    print(f"python_version: {sys.version.split()[0]}")
    print(f"package: {dist_name}")
    print(f"package_version: {pkg_version(dist_name)}")
    print(f"docs: {len(html)}")
    print(f"total_bytes: {total_bytes}")
    print(f"largest_bytes: {max_bytes}")
    print(f"convert_all_seconds: {all_seconds:.6f}")
    print(f"convert_all_mib_s: {mib_per_s(total_bytes, all_seconds):.3f}")
    if batch_seconds is not None:
        print(f"convert_all_batch_seconds: {batch_seconds:.6f}")
        print(f"convert_all_batch_mib_s: {mib_per_s(total_bytes, batch_seconds):.3f}")
    print(f"convert_largest_seconds: {max_seconds:.6f}")
    print(f"convert_largest_mib_s: {mib_per_s(max_bytes, max_seconds):.3f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
