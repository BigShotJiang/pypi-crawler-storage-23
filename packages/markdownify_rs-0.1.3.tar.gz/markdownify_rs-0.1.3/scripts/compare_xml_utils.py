#!/usr/bin/env python3
"""
Cross-validation: compare Rust xml_utils output against Python xml_utils output.

Usage:
    python scripts/compare_xml_utils.py
"""
import sys
import traceback

sys.path.insert(0, ".")

from xml_utils import (
    get_tag as py_get_tag,
    get_tags as py_get_tags,
    strip_xml as py_strip_xml,
    remove_namespace_prefixes as py_remove_ns,
    object_to_xml as py_object_to_xml,
    xml_to_object as py_xml_to_object,
    parse_base_element as py_parse_base_element,
)

from markdownify_rs import (
    get_tag as rs_get_tag,
    get_tags as rs_get_tags,
    strip_xml as rs_strip_xml,
    remove_namespace_prefixes as rs_remove_ns,
    object_to_xml as rs_object_to_xml,
    xml_to_object as rs_xml_to_object,
    parse_base_element as rs_parse_base_element,
)


passed = 0
failed = 0


def check(name: str, py_result, rs_result):
    global passed, failed
    if py_result == rs_result:
        passed += 1
    else:
        failed += 1
        print(f"MISMATCH [{name}]")
        print(f"  Python: {py_result!r}")
        print(f"  Rust:   {rs_result!r}")


# ---------------------------------------------------------------------------
# strip_xml
# ---------------------------------------------------------------------------

def test_strip_xml():
    cases = [
        "",
        "hello world",
        "  garbage <root>content</root> junk  ",
        "<tag>x</tag>",
        "prefix <tag>hi</tag>",
        "<tag>hi</tag> suffix",
        "  \n  <a><b>c</b></a>  \n  ",
    ]
    for i, c in enumerate(cases):
        check(f"strip_xml[{i}]", py_strip_xml(c), rs_strip_xml(c))


# ---------------------------------------------------------------------------
# remove_namespace_prefixes
# ---------------------------------------------------------------------------

def test_remove_namespace_prefixes():
    cases = [
        "<ns:root><ns:child>text</ns:child></ns:root>",
        '<ns:root xmlns:ns="http://example.com"><ns:child>text</ns:child></ns:root>',
        "<a:root><b:child>text</b:child></a:root>",
        "<root><child>text</child></root>",
        '<root xmlns="http://default.ns"><child>t</child></root>',
    ]
    for i, c in enumerate(cases):
        check(f"remove_ns[{i}]", py_remove_ns(c), rs_remove_ns(c))


# ---------------------------------------------------------------------------
# parse_base_element
# ---------------------------------------------------------------------------

def test_parse_base_element():
    cases = [
        (None, False, True),
        (None, True, True),
        ("", False, True),
        ("", True, True),
        ("  ", True, True),
        ("42", False, True),
        ("-7", False, True),
        ("3.14", False, True),
        ("hello", False, True),
        ("null", False, True),
        ("NULL", False, True),
        ("null", False, False),
        ("  hello  ", False, True),
    ]
    for i, (text, empty_none, null_none) in enumerate(cases):
        py_result = py_parse_base_element(text, empty_none, null_none)
        rs_result = rs_parse_base_element(text, empty_none, null_none)
        check(f"parse_base_element[{i}]", py_result, rs_result)


# ---------------------------------------------------------------------------
# get_tag
# ---------------------------------------------------------------------------

def test_get_tag():
    cases = [
        ("<div>hello</div>", "div", False),
        ("<div>hello</div>", "span", False),
        ("", "div", False),
        ('<div class="main" id="root">content</div>', "div", True),
        ("<p>first</p><p>second</p>", "p", False),
        ("<div>\n  <span>inner</span>\n</div>", "div", False),
    ]
    for i, (html, tag, attrs) in enumerate(cases):
        py_result = py_get_tag(html, tag, attrs)
        rs_result = rs_get_tag(html, tag, attrs)
        check(f"get_tag[{i}]", py_result, rs_result)


# ---------------------------------------------------------------------------
# get_tags
# ---------------------------------------------------------------------------

def test_get_tags():
    cases = [
        ("<p>a</p><p>b</p><p>c</p>", "p", False),
        ("<div>no p tags</div>", "p", False),
        ('<a href="http://a.com">A</a><a href="http://b.com">B</a>', "a", True),
        ("", "p", False),
        ("prefix <span>hello</span> middle <span>world</span> suffix", "span", False),
    ]
    for i, (html, tag, attrs) in enumerate(cases):
        py_result = py_get_tags(html, tag, attrs)
        rs_result = rs_get_tags(html, tag, attrs)
        check(f"get_tags[{i}]", py_result, rs_result)


# ---------------------------------------------------------------------------
# object_to_xml
# ---------------------------------------------------------------------------

def test_object_to_xml():
    cases = [
        # (obj, root_tag, kwargs)
        ("hello", "root", {}),
        (42, "root", {}),
        (3.14, "root", {}),
        ({"name": "test", "count": 5}, "root", {}),
        (["a", "b", "c"], "items", {}),
        (
            {"users": [{"name": "alice", "age": 30}, {"name": "bob", "age": 25}]},
            "data",
            {},
        ),
        ({"present": "yes", "absent": None}, "root", {}),
        (["x"], "root", {"include_list_index": False}),
        (["x"], "root", {"list_item_tag": "item"}),
        (["x"], "root", {"index_attr": "index"}),
    ]
    for i, (obj, root_tag, kwargs) in enumerate(cases):
        py_result = py_object_to_xml(obj, root_tag, **kwargs)
        rs_result = rs_object_to_xml(obj, root_tag, **kwargs)
        check(f"object_to_xml[{i}]", py_result, rs_result)


# ---------------------------------------------------------------------------
# xml_to_object
# ---------------------------------------------------------------------------

def test_xml_to_object():
    cases = [
        # (xml, kwargs)
        ("<root><name>test</name><count>5</count></root>", {}),
        ('<items><li key="0">a</li><li key="1">b</li></items>', {}),
        ("<root><item>a</item><item>b</item><item>c</item></root>", {}),
        ('<r><li key="2">c</li><li key="0">a</li><li key="1">b</li></r>', {}),
        ('<root><li key="0">only</li></root>', {}),
        ("<root><user><name>alice</name><age>30</age></user></root>", {}),
        ("<root>42</root>", {}),
        ("<root>3.14</root>", {}),
        ("<root>null</root>", {}),
        (
            "<root><empty></empty></root>",
            {"parse_empty_tags_as_none": True},
        ),
    ]
    for i, (xml, kwargs) in enumerate(cases):
        try:
            py_result = py_xml_to_object(xml, **kwargs)
        except Exception:
            py_result = "ERROR"
        try:
            rs_result = rs_xml_to_object(xml, **kwargs)
        except Exception:
            rs_result = "ERROR"
        check(f"xml_to_object[{i}]", py_result, rs_result)


# ---------------------------------------------------------------------------
# Round-trip: object_to_xml -> xml_to_object
# ---------------------------------------------------------------------------

def test_round_trip():
    objects = [
        {"name": "test", "count": 5},
        {"title": "report", "items": [{"name": "a", "score": 100}, {"name": "b", "score": 200}]},
        ["alpha", "beta", "gamma"],
    ]
    for i, obj in enumerate(objects):
        xml_py = py_object_to_xml(obj, "root")
        xml_rs = rs_object_to_xml(obj, "root")
        check(f"round_trip_xml[{i}]", xml_py, xml_rs)

        recovered_py = py_xml_to_object(xml_py)
        recovered_rs = rs_xml_to_object(xml_rs)
        check(f"round_trip_obj[{i}]", recovered_py, recovered_rs)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    global passed, failed

    test_strip_xml()
    test_remove_namespace_prefixes()
    test_parse_base_element()
    test_get_tag()
    test_get_tags()
    test_object_to_xml()
    test_xml_to_object()
    test_round_trip()

    print(f"\n{'='*50}")
    print(f"Passed: {passed}")
    print(f"Failed: {failed}")
    print(f"{'='*50}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
