#!/usr/bin/env python3
"""
Benchmark markdown utility functions:
- Python reference implementations from full-text-search
- Rust implementations exposed via markdownify_rs.markdown_utils

Writes a markdown report with timing and speedup summary.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import platform
import sys
import time
import types
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from markdownify_rs import markdown_utils as rs_utils


@dataclass
class BenchCase:
    category: str
    name: str
    iterations: int
    py_fn: Callable[[], Any]
    rs_fn: Callable[[], Any]


def load_fts_ingest_modules(fts_repo: Path):
    """Load ingest modules directly from source to avoid heavy package imports."""
    src_root = fts_repo / "src" / "full_text_search"
    ingest_root = src_root / "ingest"

    if not ingest_root.exists():
        raise FileNotFoundError(f"Ingest source not found: {ingest_root}")

    full_pkg = types.ModuleType("full_text_search")
    full_pkg.__path__ = [str(src_root)]  # type: ignore[attr-defined]
    sys.modules["full_text_search"] = full_pkg

    ingest_pkg = types.ModuleType("full_text_search.ingest")
    ingest_pkg.__path__ = [str(ingest_root)]  # type: ignore[attr-defined]
    sys.modules["full_text_search.ingest"] = ingest_pkg

    def load_module(module_name: str, module_path: Path):
        spec = importlib.util.spec_from_file_location(module_name, module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load module spec: {module_name} from {module_path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        return module

    common = load_module("full_text_search.ingest.common", ingest_root / "common.py")
    ingest_markdown = load_module(
        "full_text_search.ingest.ingest_markdown", ingest_root / "ingest_markdown.py"
    )
    return common, ingest_markdown


def load_jsonl_contents(path: Path, max_docs: int) -> list[str]:
    docs: list[str] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            content = record.get("content")
            if isinstance(content, str) and content.strip():
                docs.append(content)
            if len(docs) >= max_docs:
                break
    return docs


def build_synthetic_docs(n: int) -> list[str]:
    base = (
        "# Chapter 1\n"
        "See [js](javascript:alert(1)) and [ok](https://example.com).\n"
        "-----\n"
        "<div><span>drop me</span></div>\n"
        "| col1 | col2 |\n"
        "| ---- | ---- |\n"
        "| a    | b    |\n"
        "| c    | d    |\n"
        "![img](data:image/png;base64,AAAABBBB)\n"
        "[inline]( data:image/jpeg;base64,CCCC )\n"
        "## Section 1.01\n"
        "- Item one\n"
        "  - Nested item\n"
        "## Section 1.02\n"
        "text text text.\n"
    )
    return [f"{base}\n# Synthetic {i}\n{'x' * 1500}" for i in range(n)]


def run_timed(fn: Callable[[], Any], iterations: int) -> tuple[float, Any]:
    fn()  # warmup
    start = time.perf_counter()
    result = None
    for _ in range(iterations):
        result = fn()
    elapsed = time.perf_counter() - start
    return elapsed, result


def roughly_equal(a: Any, b: Any) -> bool:
    if isinstance(a, float) and isinstance(b, float):
        return abs(a - b) <= 1e-9
    return a == b


def format_duration(seconds: float) -> str:
    if seconds < 1.0:
        return f"{seconds * 1000:.2f} ms"
    return f"{seconds:.4f} s"


def write_markdown_report(
    report_path: Path,
    dataset_path: Path,
    docs_count: int,
    cleanup_docs_count: int,
    max_docs: int,
    synthetic_docs: int,
    rows: list[dict[str, Any]],
) -> None:
    now = datetime.now(timezone.utc).isoformat()
    py_ver = platform.python_version()
    machine = platform.platform()

    lines: list[str] = []
    lines.append("# Markdown Utils Benchmark")
    lines.append("")
    lines.append(f"- Timestamp (UTC): {now}")
    lines.append(f"- Python: {py_ver}")
    lines.append(f"- Platform: {machine}")
    lines.append(f"- Dataset: `{dataset_path}`")
    lines.append(f"- Source docs loaded: {docs_count} (max_docs={max_docs})")
    lines.append(f"- Synthetic docs added for cleanup tests: {synthetic_docs}")
    lines.append(f"- Cleanup benchmark doc count: {cleanup_docs_count}")
    lines.append("")
    lines.append("## Results")
    lines.append("")
    lines.append(
        "| Category | Case | Iterations | Python | Rust | Speedup (Py/Rs) | Result match |"
    )
    lines.append("| --- | --- | ---: | ---: | ---: | ---: | --- |")

    for row in rows:
        lines.append(
            f"| {row['category']} | {row['name']} | {row['iterations']} | "
            f"{row['py_seconds']:.6f}s | {row['rs_seconds']:.6f}s | "
            f"{row['speedup']:.2f}x | {row['match']} |"
        )

    lines.append("")
    lines.append("## Notes")
    lines.append("")
    lines.append("- Benchmarks are wall-clock timings with one warmup call per case.")
    lines.append("- `Result match` indicates exact equality (or tight float tolerance).")
    lines.append(
        "- Cleanup benchmarks include synthetic docs to ensure link/table/html/data-uri workloads are exercised."
    )

    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--fts-repo",
        type=Path,
        default=Path("/Users/benjamin/Desktop/repos/full-text-search"),
        help="Path to full-text-search repository.",
    )
    parser.add_argument(
        "--dataset",
        type=Path,
        default=Path("/Users/benjamin/Desktop/repos/full-text-search/data/pa_statutes.jsonl"),
        help="JSONL dataset path with `content` field.",
    )
    parser.add_argument(
        "--max-docs",
        type=int,
        default=200,
        help="Maximum source docs to load from dataset.",
    )
    parser.add_argument(
        "--synthetic-docs",
        type=int,
        default=64,
        help="Synthetic docs appended for cleanup benchmarks.",
    )
    parser.add_argument(
        "--report",
        type=Path,
        default=Path("BENCHMARKS_MARKDOWN_UTILS.md"),
        help="Markdown report output path.",
    )
    args = parser.parse_args()

    if not args.dataset.exists():
        raise SystemExit(f"Dataset not found: {args.dataset}")
    if not args.fts_repo.exists():
        raise SystemExit(f"full-text-search repo not found: {args.fts_repo}")

    common, ingest_markdown = load_fts_ingest_modules(args.fts_repo)
    docs = load_jsonl_contents(args.dataset, args.max_docs)
    if not docs:
        raise SystemExit("No docs loaded from dataset.")

    cleanup_docs = docs + build_synthetic_docs(args.synthetic_docs)
    steps = ["headings", "lists", "bold", "italic", "brute"]
    cleanup_pipeline_steps = [
        ("strip_links_with_substring", {"substring": "javascript"}),
        ("strip_links_with_substring", {"substring": "codes_display"}),
        ("remove_large_tables", {"max_cells": 200}),
        ("remove_lines_with_substring", {"substring": "<span id="}),
        ("fix_newlines", {}),
    ]

    # Precomputed chunk inputs for coalesce benchmark.
    pre_chunks = [ingest_markdown.split_into_chunks(doc, how="headings") for doc in docs]

    def py_cascade_doc(text: str) -> list[str]:
        chunks = [text]
        for step in steps:
            next_chunks: list[str] = []
            for chunk in chunks:
                if len(chunk) <= 8000:
                    next_chunks.append(chunk)
                else:
                    split = ingest_markdown.split_into_chunks(chunk, how=step)
                    next_chunks.extend(common.coalesce_small_chunks(split, min_size=225))
            chunks = next_chunks
        return chunks

    def py_cleanup_pipeline_doc(text: str) -> str:
        out = text
        out = ingest_markdown.strip_links_with_substring(out, "javascript")
        out = ingest_markdown.strip_links_with_substring(out, "codes_display")
        out = ingest_markdown.remove_large_tables(out, 200)
        out = ingest_markdown.remove_lines_with_substring(out, "<span id=")
        out = ingest_markdown.fix_newlines(out)
        return out

    cases: list[BenchCase] = [
        BenchCase(
            category="splitters",
            name="split_into_chunks(sections)",
            iterations=1,
            py_fn=lambda: sum(
                len(ingest_markdown.split_into_chunks(doc, how="sections")) for doc in docs
            ),
            rs_fn=lambda: sum(len(rs_utils.split_into_chunks(doc, how="sections")) for doc in docs),
        ),
        BenchCase(
            category="splitters",
            name="split_into_chunks_batch(sections)",
            iterations=1,
            py_fn=lambda: sum(
                len(ingest_markdown.split_into_chunks(doc, how="sections")) for doc in docs
            ),
            rs_fn=lambda: sum(
                len(chunks)
                for chunks in rs_utils.split_into_chunks_batch(docs, how="sections")
            ),
        ),
        BenchCase(
            category="splitters",
            name="split_into_chunks(brute)",
            iterations=1,
            py_fn=lambda: sum(
                len(ingest_markdown.split_into_chunks(doc, how="brute")) for doc in docs
            ),
            rs_fn=lambda: sum(len(rs_utils.split_into_chunks(doc, how="brute")) for doc in docs),
        ),
        BenchCase(
            category="splitters",
            name="split_into_chunks(lists)",
            iterations=1,
            py_fn=lambda: sum(
                len(ingest_markdown.split_into_chunks(doc, how="lists")) for doc in docs
            ),
            rs_fn=lambda: sum(len(rs_utils.split_into_chunks(doc, how="lists")) for doc in docs),
        ),
        BenchCase(
            category="splitters",
            name="coalesce_small_chunks(min_size=225)",
            iterations=2,
            py_fn=lambda: sum(len(common.coalesce_small_chunks(ch, min_size=225)) for ch in pre_chunks),
            rs_fn=lambda: sum(len(rs_utils.coalesce_small_chunks(ch, min_size=225)) for ch in pre_chunks),
        ),
        BenchCase(
            category="splitters",
            name="cascading_split_text(headings->lists->bold->italic->brute)",
            iterations=1,
            py_fn=lambda: sum(len(py_cascade_doc(doc)) for doc in docs),
            rs_fn=lambda: sum(
                len(
                    rs_utils.cascading_split_text(
                        doc,
                        how=steps,
                        max_length=8000,
                        coalesce_min=225,
                    )
                )
                for doc in docs
            ),
        ),
        BenchCase(
            category="splitters",
            name="cascading_split_text_batch(headings->lists->bold->italic->brute)",
            iterations=1,
            py_fn=lambda: sum(len(py_cascade_doc(doc)) for doc in docs),
            rs_fn=lambda: sum(
                len(chunks)
                for chunks in rs_utils.cascading_split_text_batch(
                    docs,
                    how=steps,
                    max_length=8000,
                    coalesce_min=225,
                )
            ),
        ),
        BenchCase(
            category="cleanup",
            name="strip_links_with_substring('javascript')",
            iterations=2,
            py_fn=lambda: sum(
                len(ingest_markdown.strip_links_with_substring(doc, "javascript"))
                for doc in cleanup_docs
            ),
            rs_fn=lambda: sum(
                len(rs_utils.strip_links_with_substring(doc, "javascript"))
                for doc in cleanup_docs
            ),
        ),
        BenchCase(
            category="cleanup",
            name="strip_links_with_substring_batch('javascript')",
            iterations=2,
            py_fn=lambda: sum(
                len(ingest_markdown.strip_links_with_substring(doc, "javascript"))
                for doc in cleanup_docs
            ),
            rs_fn=lambda: sum(
                len(doc)
                for doc in rs_utils.strip_links_with_substring_batch(
                    cleanup_docs, "javascript"
                )
            ),
        ),
        BenchCase(
            category="cleanup",
            name="remove_large_tables(max_cells=200)",
            iterations=2,
            py_fn=lambda: sum(
                len(ingest_markdown.remove_large_tables(doc, 200)) for doc in cleanup_docs
            ),
            rs_fn=lambda: sum(
                len(rs_utils.remove_large_tables(doc, max_cells=200)) for doc in cleanup_docs
            ),
        ),
        BenchCase(
            category="cleanup",
            name="remove_large_tables_batch(max_cells=200)",
            iterations=2,
            py_fn=lambda: sum(
                len(ingest_markdown.remove_large_tables(doc, 200)) for doc in cleanup_docs
            ),
            rs_fn=lambda: sum(
                len(doc)
                for doc in rs_utils.remove_large_tables_batch(
                    cleanup_docs, max_cells=200
                )
            ),
        ),
        BenchCase(
            category="cleanup",
            name="split_on_dividers",
            iterations=2,
            py_fn=lambda: sum(len(ingest_markdown.split_on_dividers(doc)) for doc in cleanup_docs),
            rs_fn=lambda: sum(len(rs_utils.split_on_dividers(doc)) for doc in cleanup_docs),
        ),
        BenchCase(
            category="cleanup",
            name="link_percentage",
            iterations=2,
            py_fn=lambda: sum(ingest_markdown.link_percentage(doc) for doc in cleanup_docs),
            rs_fn=lambda: sum(rs_utils.link_percentage(doc) for doc in cleanup_docs),
        ),
        BenchCase(
            category="cleanup",
            name="link_percentage_batch",
            iterations=2,
            py_fn=lambda: sum(ingest_markdown.link_percentage(doc) for doc in cleanup_docs),
            rs_fn=lambda: sum(rs_utils.link_percentage_batch(cleanup_docs)),
        ),
        BenchCase(
            category="cleanup",
            name="filter_by_link_percentage(threshold=0.5)",
            iterations=2,
            py_fn=lambda: sum(
                len(doc)
                for doc in cleanup_docs
                if ingest_markdown.link_percentage(doc) < 0.5
            ),
            rs_fn=lambda: sum(
                len(doc)
                for doc in rs_utils.filter_by_link_percentage(
                    cleanup_docs, threshold=0.5
                )
            ),
        ),
        BenchCase(
            category="cleanup",
            name="strip_html_and_contents",
            iterations=2,
            py_fn=lambda: sum(
                len(ingest_markdown.strip_html_and_contents(doc)) for doc in cleanup_docs
            ),
            rs_fn=lambda: sum(len(rs_utils.strip_html_and_contents(doc)) for doc in cleanup_docs),
        ),
        BenchCase(
            category="cleanup",
            name="strip_html_and_contents_batch",
            iterations=2,
            py_fn=lambda: sum(
                len(ingest_markdown.strip_html_and_contents(doc)) for doc in cleanup_docs
            ),
            rs_fn=lambda: sum(
                len(doc) for doc in rs_utils.strip_html_and_contents_batch(cleanup_docs)
            ),
        ),
        BenchCase(
            category="cleanup",
            name="remove_lines_with_substring('<span id=')",
            iterations=2,
            py_fn=lambda: sum(
                len(ingest_markdown.remove_lines_with_substring(doc, "<span id="))
                for doc in cleanup_docs
            ),
            rs_fn=lambda: sum(
                len(rs_utils.remove_lines_with_substring(doc, "<span id="))
                for doc in cleanup_docs
            ),
        ),
        BenchCase(
            category="cleanup",
            name="remove_lines_with_substring_batch('<span id=')",
            iterations=2,
            py_fn=lambda: sum(
                len(ingest_markdown.remove_lines_with_substring(doc, "<span id="))
                for doc in cleanup_docs
            ),
            rs_fn=lambda: sum(
                len(doc)
                for doc in rs_utils.remove_lines_with_substring_batch(
                    cleanup_docs, "<span id="
                )
            ),
        ),
        BenchCase(
            category="cleanup",
            name="fix_newlines",
            iterations=2,
            py_fn=lambda: sum(len(ingest_markdown.fix_newlines(doc)) for doc in cleanup_docs),
            rs_fn=lambda: sum(len(rs_utils.fix_newlines(doc)) for doc in cleanup_docs),
        ),
        BenchCase(
            category="cleanup",
            name="fix_newlines_batch",
            iterations=2,
            py_fn=lambda: sum(len(ingest_markdown.fix_newlines(doc)) for doc in cleanup_docs),
            rs_fn=lambda: sum(len(doc) for doc in rs_utils.fix_newlines_batch(cleanup_docs)),
        ),
        BenchCase(
            category="cleanup",
            name="strip_data_uri_images",
            iterations=2,
            py_fn=lambda: sum(
                len(ingest_markdown.strip_data_uri_images(doc)) for doc in cleanup_docs
            ),
            rs_fn=lambda: sum(len(rs_utils.strip_data_uri_images(doc)) for doc in cleanup_docs),
        ),
        BenchCase(
            category="cleanup",
            name="text_pipeline_batch(javascript/codes_display/tables/lines/newlines)",
            iterations=2,
            py_fn=lambda: sum(len(py_cleanup_pipeline_doc(doc)) for doc in cleanup_docs),
            rs_fn=lambda: sum(
                len(doc)
                for doc in rs_utils.text_pipeline_batch(
                    cleanup_docs,
                    steps=cleanup_pipeline_steps,
                )
            ),
        ),
    ]

    print("=" * 80)
    print("Benchmarking markdown utils: Python(full-text-search) vs Rust(markdownify-rs)")
    print("=" * 80)
    print(f"Dataset: {args.dataset}")
    print(f"Source docs: {len(docs)}")
    print(f"Cleanup docs: {len(cleanup_docs)}")
    print()

    rows: list[dict[str, Any]] = []
    for case in cases:
        py_seconds, py_result = run_timed(case.py_fn, case.iterations)
        rs_seconds, rs_result = run_timed(case.rs_fn, case.iterations)
        speedup = py_seconds / rs_seconds if rs_seconds > 0 else float("inf")
        matches = roughly_equal(py_result, rs_result)

        print(f"[{case.category}] {case.name}")
        print(f"  Python: {format_duration(py_seconds)}")
        print(f"  Rust:   {format_duration(rs_seconds)}")
        print(f"  Speedup: {speedup:.2f}x")
        print(f"  Result match: {matches}")
        print()

        rows.append(
            {
                "category": case.category,
                "name": case.name,
                "iterations": case.iterations,
                "py_seconds": py_seconds,
                "rs_seconds": rs_seconds,
                "speedup": speedup,
                "match": "yes" if matches else "no",
            }
        )

    write_markdown_report(
        report_path=args.report,
        dataset_path=args.dataset,
        docs_count=len(docs),
        cleanup_docs_count=len(cleanup_docs),
        max_docs=args.max_docs,
        synthetic_docs=args.synthetic_docs,
        rows=rows,
    )

    print(f"Wrote report: {args.report}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
