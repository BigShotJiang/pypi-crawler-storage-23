#!/usr/bin/env python3
import argparse
import csv
import ast
import json
import sys
import time
from pathlib import Path

try:
    from rapidfuzz.distance import Levenshtein
except ImportError:  # pragma: no cover - defensive
    Levenshtein = None

from markdownify import MarkdownConverter as PyMarkdownConverter
from markdownify_rs import MarkdownConverter as RsMarkdownConverter


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compare markdownify outputs for HTML stored in CSV rows.",
    )
    parser.add_argument("path", help="Path to CSV file.")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--threshold", type=float, default=0.0)
    parser.add_argument("--dump-dir", default=None)
    parser.add_argument("--max-dumps", type=int, default=None)
    parser.add_argument("--html-column", default="html")
    parser.add_argument("--json-column", default="value")
    parser.add_argument("--url-column", default="url")
    parser.add_argument("--encoding", default="utf-8")
    return parser.parse_args()


def normalized_distance(a: str, b: str) -> float:
    if a == b:
        return 0.0
    max_len = max(len(a), len(b))
    if max_len == 0:
        return 0.0
    return Levenshtein.distance(a, b) / max_len


def extract_html(row: dict, html_col: str, json_col: str) -> tuple[str | None, dict | None]:
    html = row.get(html_col) if html_col else None
    if html:
        return html, None

    json_blob = row.get(json_col) if json_col else None
    if not json_blob:
        return None, None
    data = None
    try:
        data = json.loads(json_blob)
    except Exception:
        try:
            data = ast.literal_eval(json_blob)
        except Exception:
            return None, None

    if not isinstance(data, dict):
        return None, None

    html = data.get("html") or data.get("content")
    if not html and isinstance(data.get("data"), dict):
        nested = data.get("data")
        html = nested.get("html") or nested.get("content")

    return html, data


def main() -> int:
    if Levenshtein is None:
        print("rapidfuzz is required: uv pip install rapidfuzz", file=sys.stderr)
        return 1

    args = parse_args()
    path = Path(args.path)
    if not path.exists():
        print(f"CSV not found: {path}", file=sys.stderr)
        return 1

    dump_dir = Path(args.dump_dir) if args.dump_dir else None
    if dump_dir is not None:
        dump_dir.mkdir(parents=True, exist_ok=True)

    rs_converter = RsMarkdownConverter()
    py_converter = PyMarkdownConverter()

    matches = 0
    mismatches = 0
    processed = 0
    dumps = 0
    start = time.perf_counter()

    try:
        csv.field_size_limit(1024 * 1024 * 64)
    except Exception:
        pass

    with path.open("r", encoding=args.encoding, newline="") as f:
        reader = csv.DictReader(f)
        for idx, row in enumerate(reader, 1):
            if args.limit is not None and processed >= args.limit:
                break

            html, data = extract_html(row, args.html_column, args.json_column)
            if not html:
                continue

            url = row.get(args.url_column) or (data.get("url") if data else None) or f"row {idx}"
            processed += 1

            rs_out = rs_converter.convert(html)
            py_out = py_converter.convert(html)

            if rs_out == py_out:
                matches += 1
                continue

            mismatches += 1
            dist = normalized_distance(rs_out, py_out)
            if dist >= args.threshold:
                print(f"mismatch  dist={dist:.6f}  {url}")
                if dump_dir is not None and (args.max_dumps is None or dumps < args.max_dumps):
                    safe_idx = str(idx).zfill(6)
                    (dump_dir / f"{safe_idx}_url.txt").write_text(str(url) + "\n", encoding="utf-8")
                    (dump_dir / f"{safe_idx}_rs.md").write_text(rs_out, encoding="utf-8")
                    (dump_dir / f"{safe_idx}_py.md").write_text(py_out, encoding="utf-8")
                    dumps += 1

    elapsed = time.perf_counter() - start
    rate = processed / elapsed if elapsed else 0.0
    print("distance_method: rapidfuzz-levenshtein")
    print(f"matches: {matches}")
    print(f"mismatches: {mismatches}")
    print(f"processed: {processed}")
    print(f"elapsed_seconds: {elapsed:.3f}")
    print(f"docs_per_second: {rate:.2f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
