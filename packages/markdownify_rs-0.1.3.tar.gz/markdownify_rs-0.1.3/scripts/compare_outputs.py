#!/usr/bin/env python3
import argparse
import json
import os
import sys
import time
from pathlib import Path

try:
    from rapidfuzz.distance import Levenshtein
except ImportError:  # pragma: no cover - defensive
    Levenshtein = None

from markdownify import MarkdownConverter as PyMarkdownConverter
from markdownify_rs import MarkdownConverter as RsMarkdownConverter


def load_dotenv() -> None:
    env_path = Path(__file__).resolve().parents[1] / ".env"
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip("'").strip('"')
        if key and key not in os.environ:
            os.environ[key] = value


def dataset_path() -> Path | None:
    load_dotenv()
    path = os.environ.get("MARKDOWNIFY_BENCH_PATH")
    if path:
        return Path(path)
    return None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compare markdownify outputs for each document.",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Optional max number of documents to process.",
    )
    parser.add_argument(
        "--show-matches",
        action="store_true",
        help="Print lines for matching outputs too.",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.0,
        help="Only report mismatches with normalized distance >= threshold.",
    )
    parser.add_argument(
        "--dump-dir",
        default=None,
        help="Directory to write outputs for mismatches above threshold.",
    )
    parser.add_argument(
        "--max-dumps",
        type=int,
        default=None,
        help="Maximum number of mismatches to dump to disk.",
    )
    return parser.parse_args()


def normalized_distance(a: str, b: str) -> float:
    if a == b:
        return 0.0
    max_len = max(len(a), len(b))
    if max_len == 0:
        return 0.0
    return Levenshtein.distance(a, b) / max_len


def main() -> int:
    args = parse_args()
    path = dataset_path()
    if path is None or not path.exists():
        print(
            "dataset not found (set MARKDOWNIFY_BENCH_PATH in .env or env)",
            file=sys.stderr,
        )
        return 1

    if Levenshtein is None:
        print("rapidfuzz is required: uv pip install rapidfuzz", file=sys.stderr)
        return 1

    print("distance_method: rapidfuzz-levenshtein")

    rs_converter = RsMarkdownConverter()
    py_converter = PyMarkdownConverter()

    matches = 0
    mismatches = 0

    start = time.perf_counter()
    processed = 0
    dump_dir = Path(args.dump_dir) if args.dump_dir else None
    if dump_dir is not None:
        dump_dir.mkdir(parents=True, exist_ok=True)

    dumps = 0
    with path.open("r", encoding="utf-8") as f:
        for idx, line in enumerate(f, 1):
            if args.limit is not None and idx > args.limit:
                break
            obj = json.loads(line)
            html = obj.get("content", "")
            url = obj.get("url", f"line {idx}")
            processed += 1

            rs_out = rs_converter.convert(html)
            py_out = py_converter.convert(html)

            if rs_out == py_out:
                matches += 1
                if args.show_matches:
                    print(f"match  {url}")
                continue

            mismatches += 1
            dist = normalized_distance(rs_out, py_out)
            if dist >= args.threshold:
                print(f"mismatch  dist={dist:.6f}  {url}")
                if dump_dir is not None and (args.max_dumps is None or dumps < args.max_dumps):
                    safe_idx = str(idx).zfill(4)
                    (dump_dir / f"{safe_idx}_url.txt").write_text(url + "\n", encoding="utf-8")
                    (dump_dir / f"{safe_idx}_rs.md").write_text(rs_out, encoding="utf-8")
                    (dump_dir / f"{safe_idx}_py.md").write_text(py_out, encoding="utf-8")
                    dumps += 1

    elapsed = time.perf_counter() - start
    rate = processed / elapsed if elapsed else 0.0
    print(f"matches: {matches}")
    print(f"mismatches: {mismatches}")
    print(f"processed: {processed}")
    print(f"elapsed_seconds: {elapsed:.3f}")
    print(f"docs_per_second: {rate:.2f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
