#!/usr/bin/env python3
"""
Parity test for markdownify_rs.markdown_utils against Python implementations
from full-text-search ingest utilities.

Default corpus: /tmp/test_markdowns/*.md
"""

from __future__ import annotations

import argparse
import importlib.util
import sys
import types
from pathlib import Path

from markdownify_rs import markdown_utils as rs_utils


def load_fts_ingest_modules(fts_repo: Path):
    src_root = fts_repo / "src" / "full_text_search"
    ingest_root = src_root / "ingest"

    if not ingest_root.exists():
        raise FileNotFoundError(f"Ingest source not found: {ingest_root}")

    full_pkg = types.ModuleType("full_text_search")
    full_pkg.__path__ = [str(src_root)]  # type: ignore[attr-defined]
    sys.modules["full_text_search"] = full_pkg

    ingest_pkg = types.ModuleType("full_text_search.ingest")
    ingest_pkg.__path__ = [str(ingest_root)]  # type: ignore[attr-defined]
    sys.modules["full_text_search.ingest"] = ingest_pkg

    def load_module(module_name: str, module_path: Path):
        spec = importlib.util.spec_from_file_location(module_name, module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load module spec: {module_name} from {module_path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        return module

    common = load_module("full_text_search.ingest.common", ingest_root / "common.py")
    ingest_markdown = load_module(
        "full_text_search.ingest.ingest_markdown", ingest_root / "ingest_markdown.py"
    )
    return common, ingest_markdown


def iter_markdown_files(root: Path):
    for path in sorted(root.rglob("*.md")):
        yield path


def assert_equal(name: str, file_path: Path, py_result, rs_result):
    if py_result != rs_result:
        raise AssertionError(
            f"Mismatch in {name} for {file_path}\n"
            f"python={repr(py_result)[:800]}\n"
            f"rust={repr(rs_result)[:800]}"
        )


def assert_float_close(name: str, file_path: Path, py_value: float, rs_value: float, tol: float = 1e-12):
    if abs(py_value - rs_value) > tol:
        raise AssertionError(
            f"Mismatch in {name} for {file_path}: python={py_value}, rust={rs_value}, tol={tol}"
        )


def py_cascading_split_text(content: str, steps: list[str], ingest_markdown, common, max_len: int, coalesce_min: int) -> list[str]:
    chunks = [content]
    for step in steps:
        next_chunks: list[str] = []
        for chunk in chunks:
            if len(chunk) <= max_len:
                next_chunks.append(chunk)
            else:
                split = ingest_markdown.split_into_chunks(chunk, how=step)
                next_chunks.extend(common.coalesce_small_chunks(split, min_size=coalesce_min))
        chunks = next_chunks
    return chunks


def py_text_pipeline(content: str, steps: list[tuple[str, dict[str, object]]], ingest_markdown) -> str:
    out = content
    for name, params in steps:
        if name == "strip_links_with_substring":
            out = ingest_markdown.strip_links_with_substring(out, str(params["substring"]))
        elif name == "remove_large_tables":
            out = ingest_markdown.remove_large_tables(out, int(params.get("max_cells", 400)))
        elif name == "strip_html_and_contents":
            out = ingest_markdown.strip_html_and_contents(out)
        elif name == "fix_newlines":
            out = ingest_markdown.fix_newlines(out)
        elif name == "remove_lines_with_substring":
            out = ingest_markdown.remove_lines_with_substring(out, str(params["substring"]))
        elif name == "strip_data_uri_images":
            out = ingest_markdown.strip_data_uri_images(out)
        else:
            raise ValueError(f"unsupported pipeline step: {name}")
    return out


def run_parity(
    corpus_dir: Path,
    fts_repo: Path,
    max_files: int | None,
):
    common, ingest_markdown = load_fts_ingest_modules(fts_repo)

    how_values = [
        "headings",
        "sections",
        "statute_sections",
        "lists",
        "links",
        "bold",
        "italic",
        "brute",
        "numbering",
        "heading1",
        "heading2",
        "heading3",
        "heading4",
        "heading5",
        "heading6",
    ]

    cascade_steps = ["headings", "lists", "bold", "italic", "brute"]

    total = 0
    for path in iter_markdown_files(corpus_dir):
        if max_files is not None and total >= max_files:
            break

        text = path.read_text(encoding="utf-8", errors="replace")

        # cleanup primitives
        assert_equal(
            "split_on_dividers",
            path,
            ingest_markdown.split_on_dividers(text),
            rs_utils.split_on_dividers(text),
        )
        assert_float_close(
            "link_percentage",
            path,
            ingest_markdown.link_percentage(text),
            rs_utils.link_percentage(text),
        )
        assert_equal(
            "link_percentage_batch",
            path,
            [ingest_markdown.link_percentage(text)],
            rs_utils.link_percentage_batch([text]),
        )
        assert_equal(
            "filter_by_link_percentage(0.5)",
            path,
            [text] if ingest_markdown.link_percentage(text) < 0.5 else [],
            rs_utils.filter_by_link_percentage([text], threshold=0.5),
        )
        assert_equal(
            "strip_links_with_substring(javascript)",
            path,
            ingest_markdown.strip_links_with_substring(text, "javascript"),
            rs_utils.strip_links_with_substring(text, "javascript"),
        )
        assert_equal(
            "strip_links_with_substring(/viewer)",
            path,
            ingest_markdown.strip_links_with_substring(text, "/viewer"),
            rs_utils.strip_links_with_substring(text, "/viewer"),
        )
        assert_equal(
            "strip_links_with_substring_batch(javascript)",
            path,
            [ingest_markdown.strip_links_with_substring(text, "javascript")],
            rs_utils.strip_links_with_substring_batch([text], "javascript"),
        )
        assert_equal(
            "remove_large_tables(200)",
            path,
            ingest_markdown.remove_large_tables(text, 200),
            rs_utils.remove_large_tables(text, max_cells=200),
        )
        assert_equal(
            "remove_large_tables(400)",
            path,
            ingest_markdown.remove_large_tables(text, 400),
            rs_utils.remove_large_tables(text, max_cells=400),
        )
        assert_equal(
            "remove_large_tables_batch(200)",
            path,
            [ingest_markdown.remove_large_tables(text, 200)],
            rs_utils.remove_large_tables_batch([text], max_cells=200),
        )
        assert_equal(
            "strip_html_and_contents",
            path,
            ingest_markdown.strip_html_and_contents(text),
            rs_utils.strip_html_and_contents(text),
        )
        assert_equal(
            "strip_html_and_contents_batch",
            path,
            [ingest_markdown.strip_html_and_contents(text)],
            rs_utils.strip_html_and_contents_batch([text]),
        )
        assert_equal(
            "remove_lines_with_substring(span id)",
            path,
            ingest_markdown.remove_lines_with_substring(text, "<span id="),
            rs_utils.remove_lines_with_substring(text, "<span id="),
        )
        assert_equal(
            "remove_lines_with_substring_batch(span id)",
            path,
            [ingest_markdown.remove_lines_with_substring(text, "<span id=")],
            rs_utils.remove_lines_with_substring_batch([text], "<span id="),
        )
        assert_equal(
            "fix_newlines",
            path,
            ingest_markdown.fix_newlines(text),
            rs_utils.fix_newlines(text),
        )
        assert_equal(
            "fix_newlines_batch",
            path,
            [ingest_markdown.fix_newlines(text)],
            rs_utils.fix_newlines_batch([text]),
        )
        assert_equal(
            "strip_data_uri_images",
            path,
            ingest_markdown.strip_data_uri_images(text),
            rs_utils.strip_data_uri_images(text),
        )

        # split foundations
        for how in how_values:
            py_chunks = ingest_markdown.split_into_chunks(text, how=how)
            rs_chunks = rs_utils.split_into_chunks(text, how=how)
            assert_equal(f"split_into_chunks({how})", path, py_chunks, rs_chunks)

            # coalesce parity from that split output
            assert_equal(
                f"coalesce_small_chunks({how})",
                path,
                common.coalesce_small_chunks(py_chunks, min_size=225),
                rs_utils.coalesce_small_chunks(rs_chunks, min_size=225),
            )

        # cascading parity
        py_cascade = py_cascading_split_text(
            text,
            cascade_steps,
            ingest_markdown,
            common,
            max_len=8000,
            coalesce_min=225,
        )
        rs_cascade = rs_utils.cascading_split_text(
            text,
            how=cascade_steps,
            max_length=8000,
            coalesce_min=225,
        )
        assert_equal("cascading_split_text", path, py_cascade, rs_cascade)

        pipeline_steps = [
            ("strip_links_with_substring", {"substring": "javascript"}),
            ("strip_links_with_substring", {"substring": "codes_display"}),
            ("remove_large_tables", {"max_cells": 200}),
            ("remove_lines_with_substring", {"substring": "<span id="}),
            ("fix_newlines", {}),
        ]
        py_pipeline = py_text_pipeline(text, pipeline_steps, ingest_markdown)
        rs_pipeline = rs_utils.text_pipeline_batch([text], steps=pipeline_steps)[0]
        assert_equal("text_pipeline_batch", path, py_pipeline, rs_pipeline)

        total += 1
        if total % 50 == 0:
            print(f"validated {total} files...")

    return total


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--corpus-dir",
        type=Path,
        default=Path("/tmp/test_markdowns"),
        help="Directory containing markdown files to validate.",
    )
    parser.add_argument(
        "--fts-repo",
        type=Path,
        default=Path("/Users/benjamin/Desktop/repos/full-text-search"),
        help="Path to full-text-search repo.",
    )
    parser.add_argument(
        "--max-files",
        type=int,
        default=None,
        help="Optional cap for debugging; default validates all files.",
    )
    args = parser.parse_args()

    if not args.corpus_dir.exists():
        raise SystemExit(f"Corpus directory not found: {args.corpus_dir}")
    if not args.fts_repo.exists():
        raise SystemExit(f"full-text-search repo not found: {args.fts_repo}")

    total = run_parity(args.corpus_dir, args.fts_repo, args.max_files)
    print(f"PASS: parity validated on {total} markdown files")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
