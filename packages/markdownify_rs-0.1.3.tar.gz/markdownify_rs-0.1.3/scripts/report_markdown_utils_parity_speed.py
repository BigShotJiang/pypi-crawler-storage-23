#!/usr/bin/env python3
"""
Report per-function parity and speedup for markdown_utils ports.

Compares Python implementations from full-text-search ingest utilities against
Rust implementations exposed via markdownify_rs.markdown_utils.
"""

from __future__ import annotations

import argparse
import importlib.util
import platform
import sys
import time
import types
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from markdownify_rs import markdown_utils as rs_utils


def load_fts_ingest_modules(fts_repo: Path):
    src_root = fts_repo / "src" / "full_text_search"
    ingest_root = src_root / "ingest"

    if not ingest_root.exists():
        raise FileNotFoundError(f"Ingest source not found: {ingest_root}")

    full_pkg = types.ModuleType("full_text_search")
    full_pkg.__path__ = [str(src_root)]  # type: ignore[attr-defined]
    sys.modules["full_text_search"] = full_pkg

    ingest_pkg = types.ModuleType("full_text_search.ingest")
    ingest_pkg.__path__ = [str(ingest_root)]  # type: ignore[attr-defined]
    sys.modules["full_text_search.ingest"] = ingest_pkg

    def load_module(module_name: str, module_path: Path):
        spec = importlib.util.spec_from_file_location(module_name, module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load module spec: {module_name} from {module_path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        return module

    common = load_module("full_text_search.ingest.common", ingest_root / "common.py")
    ingest_markdown = load_module(
        "full_text_search.ingest.ingest_markdown", ingest_root / "ingest_markdown.py"
    )
    return common, ingest_markdown


def iter_markdown_files(root: Path):
    for path in sorted(root.rglob("*.md")):
        yield path


def float_equal(a: float, b: float, tol: float = 1e-12) -> bool:
    return abs(a - b) <= tol


def output_equal(a: Any, b: Any) -> bool:
    if isinstance(a, float) and isinstance(b, float):
        return float_equal(a, b)
    return a == b


def py_cascading_split_text(
    content: str,
    steps: list[str],
    ingest_markdown,
    common,
    max_len: int,
    coalesce_min: int,
) -> list[str]:
    chunks = [content]
    for step in steps:
        next_chunks: list[str] = []
        for chunk in chunks:
            if len(chunk) <= max_len:
                next_chunks.append(chunk)
            else:
                split = ingest_markdown.split_into_chunks(chunk, how=step)
                next_chunks.extend(common.coalesce_small_chunks(split, min_size=coalesce_min))
        chunks = next_chunks
    return chunks


def py_text_pipeline(content: str, ingest_markdown, steps: list[tuple[str, dict[str, object]]]) -> str:
    out = content
    for name, params in steps:
        if name == "strip_links_with_substring":
            out = ingest_markdown.strip_links_with_substring(out, str(params["substring"]))
        elif name == "remove_large_tables":
            out = ingest_markdown.remove_large_tables(out, int(params.get("max_cells", 400)))
        elif name == "strip_html_and_contents":
            out = ingest_markdown.strip_html_and_contents(out)
        elif name == "fix_newlines":
            out = ingest_markdown.fix_newlines(out)
        elif name == "remove_lines_with_substring":
            out = ingest_markdown.remove_lines_with_substring(out, str(params["substring"]))
        elif name == "strip_data_uri_images":
            out = ingest_markdown.strip_data_uri_images(out)
        else:
            raise ValueError(f"unsupported pipeline step: {name}")
    return out


@dataclass
class Case:
    category: str
    name: str
    params: str
    py_fn: Callable[[str, int], Any]
    rs_fn: Callable[[str, int], Any]


@dataclass
class CaseResult:
    category: str
    name: str
    params: str
    parity_docs: int
    mismatch_docs: int
    total_docs: int
    parity_pct: float
    py_seconds: float
    rs_seconds: float
    speedup: float


def time_total(fn: Callable[[str, int], Any], docs: list[str], repeats: int) -> float:
    samples: list[float] = []
    for _ in range(repeats):
        start = time.perf_counter()
        for idx, doc in enumerate(docs):
            fn(doc, idx)
        samples.append(time.perf_counter() - start)
    return min(samples)


def evaluate_case(case: Case, docs: list[str], repeats: int) -> CaseResult:
    parity_docs = 0
    mismatch_docs = 0

    for idx, doc in enumerate(docs):
        py_out = case.py_fn(doc, idx)
        rs_out = case.rs_fn(doc, idx)
        if output_equal(py_out, rs_out):
            parity_docs += 1
        else:
            mismatch_docs += 1

    py_seconds = time_total(case.py_fn, docs, repeats)
    rs_seconds = time_total(case.rs_fn, docs, repeats)
    speedup = py_seconds / rs_seconds if rs_seconds > 0 else float("inf")

    total_docs = len(docs)
    parity_pct = (parity_docs / total_docs) * 100 if total_docs else 0.0
    return CaseResult(
        category=case.category,
        name=case.name,
        params=case.params,
        parity_docs=parity_docs,
        mismatch_docs=mismatch_docs,
        total_docs=total_docs,
        parity_pct=parity_pct,
        py_seconds=py_seconds,
        rs_seconds=rs_seconds,
        speedup=speedup,
    )


def write_report(
    report_path: Path,
    corpus_dir: Path,
    total_docs: int,
    repeats: int,
    rows: list[CaseResult],
) -> None:
    now = datetime.now(timezone.utc).isoformat()
    py_ver = platform.python_version()
    machine = platform.platform()

    lines: list[str] = []
    lines.append("# Markdown Utils Parity And Speed")
    lines.append("")
    lines.append(f"- Timestamp (UTC): {now}")
    lines.append(f"- Python: {py_ver}")
    lines.append(f"- Platform: {machine}")
    lines.append(f"- Corpus: `{corpus_dir}`")
    lines.append(f"- Total markdown docs: {total_docs}")
    lines.append(f"- Timing repeats per function: {repeats} (best-of-{repeats})")
    lines.append("")
    lines.append("## Results")
    lines.append("")
    lines.append(
        "| Category | Function | Parameters | Parity docs | Mismatch docs | Parity % | Python total | Rust total | Speedup (Py/Rs) |"
    )
    lines.append("| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |")

    for row in rows:
        lines.append(
            f"| {row.category} | {row.name} | `{row.params}` | "
            f"{row.parity_docs}/{row.total_docs} | {row.mismatch_docs} | "
            f"{row.parity_pct:.2f}% | {row.py_seconds:.6f}s | {row.rs_seconds:.6f}s | "
            f"{row.speedup:.2f}x |"
        )

    lines.append("")
    lines.append("## Notes")
    lines.append("")
    lines.append("- Parity is exact equality, except float outputs use tolerance `1e-12`.")
    lines.append("- Speedup uses total wall-clock time over the full corpus.")
    lines.append("- `Speedup > 1.0x` means Rust is faster.")
    lines.append("- `strip_html_and_contents` parity is expected to diverge on malformed HTML-like content after removing backtracking regex behavior.")

    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--corpus-dir",
        type=Path,
        default=Path("/tmp/test_markdowns"),
        help="Directory containing markdown files to validate.",
    )
    parser.add_argument(
        "--fts-repo",
        type=Path,
        default=Path("/Users/benjamin/Desktop/repos/full-text-search"),
        help="Path to full-text-search repository.",
    )
    parser.add_argument(
        "--report",
        type=Path,
        default=Path("BENCHMARKS_MARKDOWN_UTILS.md"),
        help="Markdown report output path.",
    )
    parser.add_argument(
        "--repeats",
        type=int,
        default=3,
        help="Timing repeats per function (best-of-N).",
    )
    parser.add_argument(
        "--max-files",
        type=int,
        default=None,
        help="Optional cap for number of markdown docs to include.",
    )
    args = parser.parse_args()

    if not args.corpus_dir.exists():
        raise SystemExit(f"Corpus directory not found: {args.corpus_dir}")
    if not args.fts_repo.exists():
        raise SystemExit(f"full-text-search repo not found: {args.fts_repo}")
    if args.repeats < 1:
        raise SystemExit("--repeats must be >= 1")
    if args.max_files is not None and args.max_files < 1:
        raise SystemExit("--max-files must be >= 1")

    common, ingest_markdown = load_fts_ingest_modules(args.fts_repo)
    docs: list[str] = []
    for i, p in enumerate(iter_markdown_files(args.corpus_dir)):
        if args.max_files is not None and i >= args.max_files:
            break
        docs.append(p.read_text(encoding="utf-8", errors="replace"))
    if not docs:
        raise SystemExit("No markdown files found in corpus.")

    cascade_steps = ["headings", "lists", "bold", "italic", "brute"]
    cleanup_pipeline_steps = [
        ("strip_links_with_substring", {"substring": "javascript"}),
        ("strip_links_with_substring", {"substring": "codes_display"}),
        ("remove_large_tables", {"max_cells": 200}),
        ("remove_lines_with_substring", {"substring": "<span id="}),
        ("fix_newlines", {}),
    ]

    # Use precomputed split inputs so this row measures coalesce itself.
    coalesce_inputs = [ingest_markdown.split_into_chunks(doc, how="headings") for doc in docs]

    def coalesce_py(_: str, idx: int):
        return common.coalesce_small_chunks(coalesce_inputs[idx], min_size=225)

    def coalesce_rs(_: str, idx: int):
        return rs_utils.coalesce_small_chunks(coalesce_inputs[idx], min_size=225)

    cases: list[Case] = [
        Case(
            category="splitter",
            name="split_into_chunks",
            params="how=headings",
            py_fn=lambda d, _: ingest_markdown.split_into_chunks(d, how="headings"),
            rs_fn=lambda d, _: rs_utils.split_into_chunks(d, how="headings"),
        ),
        Case(
            category="splitter",
            name="split_into_chunks",
            params="how=lists",
            py_fn=lambda d, _: ingest_markdown.split_into_chunks(d, how="lists"),
            rs_fn=lambda d, _: rs_utils.split_into_chunks(d, how="lists"),
        ),
        Case(
            category="splitter",
            name="split_into_chunks",
            params="how=bold",
            py_fn=lambda d, _: ingest_markdown.split_into_chunks(d, how="bold"),
            rs_fn=lambda d, _: rs_utils.split_into_chunks(d, how="bold"),
        ),
        Case(
            category="splitter",
            name="split_into_chunks",
            params="how=italic",
            py_fn=lambda d, _: ingest_markdown.split_into_chunks(d, how="italic"),
            rs_fn=lambda d, _: rs_utils.split_into_chunks(d, how="italic"),
        ),
        Case(
            category="splitter",
            name="split_into_chunks",
            params="how=brute",
            py_fn=lambda d, _: ingest_markdown.split_into_chunks(d, how="brute"),
            rs_fn=lambda d, _: rs_utils.split_into_chunks(d, how="brute"),
        ),
        Case(
            category="splitter",
            name="coalesce_small_chunks",
            params="min_size=225,input=headings_split",
            py_fn=coalesce_py,
            rs_fn=coalesce_rs,
        ),
        Case(
            category="splitter",
            name="cascading_split_text",
            params="how=headings,lists,bold,italic,brute;max_length=8000;coalesce_min=225",
            py_fn=lambda d, _: py_cascading_split_text(
                d,
                steps=cascade_steps,
                ingest_markdown=ingest_markdown,
                common=common,
                max_len=8000,
                coalesce_min=225,
            ),
            rs_fn=lambda d, _: rs_utils.cascading_split_text(
                d,
                how=cascade_steps,
                max_length=8000,
                coalesce_min=225,
            ),
        ),
        Case(
            category="cleanup",
            name="split_on_dividers",
            params="-",
            py_fn=lambda d, _: ingest_markdown.split_on_dividers(d),
            rs_fn=lambda d, _: rs_utils.split_on_dividers(d),
        ),
        Case(
            category="cleanup",
            name="link_percentage",
            params="-",
            py_fn=lambda d, _: ingest_markdown.link_percentage(d),
            rs_fn=lambda d, _: rs_utils.link_percentage(d),
        ),
        Case(
            category="cleanup",
            name="link_percentage_batch",
            params="-",
            py_fn=lambda d, _: ingest_markdown.link_percentage(d),
            rs_fn=lambda d, _: rs_utils.link_percentage_batch([d])[0],
        ),
        Case(
            category="cleanup",
            name="filter_by_link_percentage",
            params="threshold=0.5",
            py_fn=lambda d, _: [d] if ingest_markdown.link_percentage(d) < 0.5 else [],
            rs_fn=lambda d, _: rs_utils.filter_by_link_percentage([d], threshold=0.5),
        ),
        Case(
            category="cleanup",
            name="strip_links_with_substring",
            params="substring=javascript",
            py_fn=lambda d, _: ingest_markdown.strip_links_with_substring(d, "javascript"),
            rs_fn=lambda d, _: rs_utils.strip_links_with_substring(d, "javascript"),
        ),
        Case(
            category="cleanup",
            name="strip_links_with_substring_batch",
            params="substring=javascript",
            py_fn=lambda d, _: ingest_markdown.strip_links_with_substring(d, "javascript"),
            rs_fn=lambda d, _: rs_utils.strip_links_with_substring_batch([d], "javascript")[0],
        ),
        Case(
            category="cleanup",
            name="remove_large_tables",
            params="max_cells=200",
            py_fn=lambda d, _: ingest_markdown.remove_large_tables(d, 200),
            rs_fn=lambda d, _: rs_utils.remove_large_tables(d, max_cells=200),
        ),
        Case(
            category="cleanup",
            name="remove_large_tables_batch",
            params="max_cells=200",
            py_fn=lambda d, _: ingest_markdown.remove_large_tables(d, 200),
            rs_fn=lambda d, _: rs_utils.remove_large_tables_batch([d], max_cells=200)[0],
        ),
        Case(
            category="cleanup",
            name="strip_html_and_contents",
            params="-",
            py_fn=lambda d, _: ingest_markdown.strip_html_and_contents(d),
            rs_fn=lambda d, _: rs_utils.strip_html_and_contents(d),
        ),
        Case(
            category="cleanup",
            name="strip_html_and_contents_batch",
            params="-",
            py_fn=lambda d, _: ingest_markdown.strip_html_and_contents(d),
            rs_fn=lambda d, _: rs_utils.strip_html_and_contents_batch([d])[0],
        ),
        Case(
            category="cleanup",
            name="remove_lines_with_substring",
            params="substring=<span id=",
            py_fn=lambda d, _: ingest_markdown.remove_lines_with_substring(d, "<span id="),
            rs_fn=lambda d, _: rs_utils.remove_lines_with_substring(d, "<span id="),
        ),
        Case(
            category="cleanup",
            name="remove_lines_with_substring_batch",
            params="substring=<span id=",
            py_fn=lambda d, _: ingest_markdown.remove_lines_with_substring(d, "<span id="),
            rs_fn=lambda d, _: rs_utils.remove_lines_with_substring_batch([d], "<span id=")[0],
        ),
        Case(
            category="cleanup",
            name="fix_newlines",
            params="-",
            py_fn=lambda d, _: ingest_markdown.fix_newlines(d),
            rs_fn=lambda d, _: rs_utils.fix_newlines(d),
        ),
        Case(
            category="cleanup",
            name="fix_newlines_batch",
            params="-",
            py_fn=lambda d, _: ingest_markdown.fix_newlines(d),
            rs_fn=lambda d, _: rs_utils.fix_newlines_batch([d])[0],
        ),
        Case(
            category="cleanup",
            name="strip_data_uri_images",
            params="-",
            py_fn=lambda d, _: ingest_markdown.strip_data_uri_images(d),
            rs_fn=lambda d, _: rs_utils.strip_data_uri_images(d),
        ),
        Case(
            category="cleanup",
            name="text_pipeline_batch",
            params="strip_links(javascript,codes_display)->remove_large_tables(200)->remove_lines(<span id=)->fix_newlines",
            py_fn=lambda d, _: py_text_pipeline(
                d,
                ingest_markdown=ingest_markdown,
                steps=cleanup_pipeline_steps,
            ),
            rs_fn=lambda d, _: rs_utils.text_pipeline_batch([d], steps=cleanup_pipeline_steps)[0],
        ),
    ]

    rows: list[CaseResult] = []
    for i, case in enumerate(cases, 1):
        print(f"[{i}/{len(cases)}] {case.category}/{case.name} ({case.params})")
        rows.append(evaluate_case(case, docs, args.repeats))

    rows.sort(key=lambda r: (r.category, r.name, r.params))
    write_report(
        report_path=args.report,
        corpus_dir=args.corpus_dir,
        total_docs=len(docs),
        repeats=args.repeats,
        rows=rows,
    )
    print(f"Wrote report: {args.report}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
