#!/usr/bin/env python3
"""
Benchmark xml_utils: Rust (markdownify_rs) vs Python (bs4 + lxml).

Usage:
    python scripts/bench_xml_utils.py
"""
import sys
import time

# --- Python (bs4/lxml) implementations -----------------------------------------------

sys.path.insert(0, ".")
from xml_utils import (
    get_tag as py_get_tag,
    get_tags as py_get_tags,
    strip_xml as py_strip_xml,
    remove_namespace_prefixes as py_remove_ns,
    object_to_xml as py_object_to_xml,
    xml_to_object as py_xml_to_object,
)

# --- Rust implementations via markdownify_rs -----------------------------------------

from markdownify_rs import (
    get_tag as rs_get_tag,
    get_tags as rs_get_tags,
    strip_xml as rs_strip_xml,
    remove_namespace_prefixes as rs_remove_ns,
    object_to_xml as rs_object_to_xml,
    xml_to_object as rs_xml_to_object,
)


def bench(label: str, fn, args, iterations: int = 1000) -> float:
    """Warm up, then time `iterations` calls. Returns seconds."""
    for _ in range(min(10, iterations)):
        fn(*args)
    start = time.perf_counter()
    for _ in range(iterations):
        fn(*args)
    elapsed = time.perf_counter() - start
    us_per = elapsed / iterations * 1e6
    print(f"  {label:>40s}: {elapsed:.4f}s  ({iterations} iters, {us_per:.1f} us/iter)")
    return elapsed


def build_test_obj(n: int) -> dict:
    """Build a nested dict/list structure with approximately n nodes."""
    return {
        "users": [
            {"name": f"user_{i}", "age": 20 + i, "score": 95.5 + i * 0.1}
            for i in range(n)
        ]
    }


def main() -> int:
    print("=" * 70)
    print("xml_utils benchmark: Rust (markdownify_rs) vs Python (bs4+lxml)")
    print("=" * 70)

    # --- strip_xml ---
    print("\n--- strip_xml ---")
    strip_input = "  garbage " + "<root><child>text</child></root>" * 50 + " junk  "
    t_py = bench("Python strip_xml", py_strip_xml, (strip_input,), 10000)
    t_rs = bench("Rust   strip_xml", rs_strip_xml, (strip_input,), 10000)
    print(f"  {'speedup':>40s}: {t_py / t_rs:.1f}x")

    # --- remove_namespace_prefixes ---
    print("\n--- remove_namespace_prefixes ---")
    ns_input = '<ns:root xmlns:ns="http://example.com">' + "<ns:child>text</ns:child>" * 50 + "</ns:root>"
    t_py = bench("Python remove_ns", py_remove_ns, (ns_input,), 5000)
    t_rs = bench("Rust   remove_ns", rs_remove_ns, (ns_input,), 5000)
    print(f"  {'speedup':>40s}: {t_py / t_rs:.1f}x")

    # --- get_tag ---
    print("\n--- get_tag ---")
    html_input = "<html><body>" + "<div><p>paragraph text here</p></div>" * 50 + "</body></html>"
    t_py = bench("Python get_tag", py_get_tag, (html_input, "p"), 2000)
    t_rs = bench("Rust   get_tag", rs_get_tag, (html_input, "p"), 2000)
    print(f"  {'speedup':>40s}: {t_py / t_rs:.1f}x")

    # --- get_tags ---
    print("\n--- get_tags ---")
    t_py = bench("Python get_tags", py_get_tags, (html_input, "p"), 2000)
    t_rs = bench("Rust   get_tags", rs_get_tags, (html_input, "p"), 2000)
    print(f"  {'speedup':>40s}: {t_py / t_rs:.1f}x")

    # --- object_to_xml (small) ---
    print("\n--- object_to_xml (10 items) ---")
    obj_small = build_test_obj(10)
    t_py = bench("Python object_to_xml", py_object_to_xml, (obj_small, "data"), 5000)
    t_rs = bench("Rust   object_to_xml", rs_object_to_xml, (obj_small, "data"), 5000)
    print(f"  {'speedup':>40s}: {t_py / t_rs:.1f}x")

    # --- object_to_xml (medium) ---
    print("\n--- object_to_xml (100 items) ---")
    obj_medium = build_test_obj(100)
    t_py = bench("Python object_to_xml", py_object_to_xml, (obj_medium, "data"), 1000)
    t_rs = bench("Rust   object_to_xml", rs_object_to_xml, (obj_medium, "data"), 1000)
    print(f"  {'speedup':>40s}: {t_py / t_rs:.1f}x")

    # --- object_to_xml (large) ---
    print("\n--- object_to_xml (1000 items) ---")
    obj_large = build_test_obj(1000)
    t_py = bench("Python object_to_xml", py_object_to_xml, (obj_large, "data"), 100)
    t_rs = bench("Rust   object_to_xml", rs_object_to_xml, (obj_large, "data"), 100)
    print(f"  {'speedup':>40s}: {t_py / t_rs:.1f}x")

    # --- xml_to_object (small) ---
    print("\n--- xml_to_object (10 items) ---")
    xml_small = rs_object_to_xml(obj_small, "data")
    t_py = bench("Python xml_to_object", py_xml_to_object, (xml_small,), 5000)
    t_rs = bench("Rust   xml_to_object", rs_xml_to_object, (xml_small,), 5000)
    print(f"  {'speedup':>40s}: {t_py / t_rs:.1f}x")

    # --- xml_to_object (medium) ---
    print("\n--- xml_to_object (100 items) ---")
    xml_medium = rs_object_to_xml(obj_medium, "data")
    t_py = bench("Python xml_to_object", py_xml_to_object, (xml_medium,), 1000)
    t_rs = bench("Rust   xml_to_object", rs_xml_to_object, (xml_medium,), 1000)
    print(f"  {'speedup':>40s}: {t_py / t_rs:.1f}x")

    # --- xml_to_object (large) ---
    print("\n--- xml_to_object (1000 items) ---")
    xml_large = rs_object_to_xml(obj_large, "data")
    t_py = bench("Python xml_to_object", py_xml_to_object, (xml_large,), 100)
    t_rs = bench("Rust   xml_to_object", rs_xml_to_object, (xml_large,), 100)
    print(f"  {'speedup':>40s}: {t_py / t_rs:.1f}x")

    print("\n" + "=" * 70)
    print("Done.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
