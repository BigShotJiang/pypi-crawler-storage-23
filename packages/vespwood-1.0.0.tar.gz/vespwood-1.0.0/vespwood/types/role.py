from typing import Literal

type Role = Literal["system", "user", "assistant"]