from typing import Any


type PreparedArgs = dict[str, Any]