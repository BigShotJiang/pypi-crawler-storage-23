type ToolObject = dict # TODO: Change to TypedDict

type ToolsList = list[ToolObject | str]