"""Allow running as `python -m git_spreader`."""

from git_spreader.cli import app

app()
