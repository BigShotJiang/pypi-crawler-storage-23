"""
Pattern loader for error explanation system.

This module handles loading and validation of error patterns,
separating concerns from the main ErrorExplainer class.
"""

from __future__ import annotations

import functools
from typing import Callable, List, Optional
from .models import ErrorPattern
from .patterns import load_default_patterns
from .exceptions import ExplanationError

PatternProvider = Callable[[], List[ErrorPattern]]
_PATTERN_PROVIDERS: List[PatternProvider] = []


def register_pattern_provider(provider: PatternProvider) -> None:
    """Register a custom error pattern provider."""
    if not callable(provider):
        raise TypeError("provider must be callable")
    _PATTERN_PROVIDERS.append(provider)


def get_pattern_providers() -> List[PatternProvider]:
    """Return registered pattern providers."""
    return list(_PATTERN_PROVIDERS)


class PatternLoader:
    """
    Handles loading of error patterns with caching.
    
    Responsibilities:
    - Load patterns from various sources
    - Cache loaded patterns
    - Provide pattern access
    """
    
    def __init__(self) -> None:
        """Initialize pattern loader."""
        self._patterns_cache: List[ErrorPattern] = []
        self._loaded = False
    
    @functools.lru_cache(maxsize=1)
    def load_patterns(self) -> List[ErrorPattern]:
        """
        Load error patterns for matching exceptions (cached).
        
        Returns:
            List of ErrorPattern objects
            
        Raises:
            ExplanationError: If patterns cannot be loaded
            
        Note:
            Results are cached using functools.lru_cache for performance.
        """
        if self._loaded:
            return self._patterns_cache
        
        try:
            patterns = load_default_patterns()
            for provider in get_pattern_providers():
                provided = provider()
                if provided:
                    patterns.extend(provided)

            self._patterns_cache = patterns
            self._loaded = True
            return self._patterns_cache
        except Exception as e:
            raise ExplanationError(
                f"Не удалось загрузить паттерны ошибок: {e}",
                original_error=e
            ) from e
    def get_patterns(self) -> List[ErrorPattern]:
        """
        Get loaded patterns (loads if not already loaded).
        
        Returns:
            List of ErrorPattern objects
        """
        if not self._loaded:
            return self.load_patterns()
        return self._patterns_cache
    
    def reload_patterns(self) -> List[ErrorPattern]:
        """
        Force reload of patterns.
        
        Returns:
            List of ErrorPattern objects
        """
        self._loaded = False
        return self.load_patterns()


class PatternMatcher:
    """
    Handles pattern matching logic.
    
    Responsibilities:
    - Match exceptions to patterns
    - Rank pattern matches
    - Handle matching errors gracefully
    """
    
    def __init__(self, patterns: List[ErrorPattern]):
        """
        Initialize pattern matcher.
        
        Args:
            patterns: List of patterns to match against
        """
        self.patterns = patterns
    
    def find_match(self, exception: Exception) -> Optional[ErrorPattern]:
        """
        Find the best matching pattern for the given exception.
        
        Args:
            exception: The exception to match
            
        Returns:
            Matching ErrorPattern or None if no match found
            
        Note:
            Returns None instead of raising to allow fallback explanation.
        """
        try:
            for pattern in self.patterns:
                if pattern.matches(exception):
                    return pattern
            return None
        except Exception:
            # Pattern matching is explicitly best-effort: callers fall back
            # to generic explanations when matching fails.
            return None
    
    def find_all_matches(self, exception: Exception) -> List[ErrorPattern]:
        """
        Find all matching patterns for the given exception.
        
        Args:
            exception: The exception to match
            
        Returns:
            List of matching ErrorPattern objects (may be empty)
        """
        matches = []
        try:
            for pattern in self.patterns:
                if pattern.matches(exception):
                    matches.append(pattern)
        except Exception:
            # Best-effort behavior mirrors find_match() to keep API stable.
            return []
        return matches
