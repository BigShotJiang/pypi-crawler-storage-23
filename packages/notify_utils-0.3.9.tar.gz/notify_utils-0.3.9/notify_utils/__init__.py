"""
notify-utils

Biblioteca Python para análise de preços de e-commerce: parsing, validação, cálculo de descontos
reais e detecção de promoções falsas através de análise estatística de histórico.

Módulos principais:
- models: Modelos de dados (Product, Price, PriceHistory, etc)
- parser: Normalização de strings de preços
- discount: Cálculo de descontos e validação de promoções reais
- statistics: Análise estatística (média, mediana, tendências)
- validators: Validações de preço, data, moeda
- notifiers: Notificações Discord (opcional)
- parsers: Parsers de lojas específicas (Nike, Maze, etc)
"""

# Models - Estruturas de dados fundamentais
from .models import (
    Product,
    Price,
    PriceHistory,
    ProductWithCurrentPriceAndOldPrice,
    ProductWithPriceHistory,
    DiscountResult,
    HistoryDiscountResult,
    DiscountInfo,
    PriceTrend,
    PriceComparisonStatus,
    PriceAction,
    PriceAdditionStrategy,
    PriceComparisonResult,
    Coupon,
    ResponseData
)

# Parser - Normalização de preços
from .parser import parse_price

# Discount - Cálculo de descontos
from .discount import (
    calculate_discount_percentage,
    calculate_discount_absolute,
    is_real_discount,
    calculate_discount_from_history,
    get_discount_info,
    get_best_discount_from_history
)

# Statistics - Análise estatística
from .statistics import (
    calculate_mean,
    calculate_median,
    get_min_max,
    filter_by_period,
    filter_by_period_range,
    calculate_volatility,
    calculate_price_trend,
    calculate_price_statistics,
    days_since_most_recent_price,
    get_recommended_period
)

# Notifiers - Notificações Discord (opcional)
from .notifiers import (
    DiscordEmbedBuilder,
    format_price,
    format_price_history,
    get_unique_prices
)

# Parsers - Parsers de lojas específicas (Nike, Maze, Beleza na Web, Sephora, Magalu, New Era, Havan, KaBuM!)
from .parsers import (
    StoresParserInterface,
    StoresParserEnum,
    ParserFactory,
    ParserError,
    NikeAPIGatewayJSONParser,
    MazeAPIJSONParser,
    BelezaNaWebHTMLParser,
    SephoraAPIJSONParser,
    NewEraAPIJSONParser,
    MagazineLuizaHTMLParser,
    HavanHTMLParser,
    KabumAPIJSONParser
)

__version__ = "0.3.8"
__all__ = [
    # ========== MODELS ==========
    "Product",
    "Price",
    "PriceHistory",
    "ProductWithCurrentPriceAndOldPrice",
    "ProductWithPriceHistory",
    "DiscountResult",
    "HistoryDiscountResult",
    "DiscountInfo",
    "PriceTrend",
    "Coupon",
    "ResponseData",

    # ========== ENUMS ==========
    # Price Comparison
    "PriceComparisonStatus",
    "PriceAction",
    "PriceAdditionStrategy",
    "PriceComparisonResult",

    # ========== PARSER ==========
    "parse_price",

    # ========== DISCOUNT ==========
    "calculate_discount_percentage",
    "calculate_discount_absolute",
    "is_real_discount",
    "calculate_discount_from_history",
    "get_discount_info",
    "get_best_discount_from_history",

    # ========== STATISTICS ==========
    "calculate_mean",
    "calculate_median",
    "get_min_max",
    "filter_by_period",
    "filter_by_period_range",
    "calculate_volatility",
    "calculate_price_trend",
    "calculate_price_statistics",
    "days_since_most_recent_price",
    "get_recommended_period",

    # ========== NOTIFIERS ==========
    "DiscordEmbedBuilder",
    "format_price",
    "format_price_history",
    "get_unique_prices",

    # ========== STORE PARSERS ==========
    "StoresParserInterface",
    "StoresParserEnum",
    "ParserFactory",
    "ParserError",
    "NikeAPIGatewayJSONParser",
    "MazeAPIJSONParser",
    "BelezaNaWebHTMLParser",
    "SephoraAPIJSONParser",
    "NewEraAPIJSONParser",
    "MagazineLuizaHTMLParser",
    "HavanHTMLParser",
    "KabumAPIJSONParser",
]
