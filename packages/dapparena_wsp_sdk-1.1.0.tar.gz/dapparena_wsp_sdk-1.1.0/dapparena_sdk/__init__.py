"""DappArena WSP SDK v1.1.0 — WorldLand Scholar Protocol

Slice 1: A2A v2, Orchestrator, BaseAgent
Slice 2: MCP, RAG, LLM Router, Security
"""

__version__ = "1.1.0"
