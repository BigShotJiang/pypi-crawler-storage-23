"""BaseAgentV2 — WSP 에이전트 추상 기본 클래스 (S1-05)

Task 기반 handle_task() 인터페이스를 정의합니다.
기존 DappArena SDK의 BaseAgent(chat 기반)와 구분됩니다.
"""

from __future__ import annotations

import logging
import time
from abc import ABC, abstractmethod

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .a2a.agent_card import agent_card_router, register_agent_card
from .a2a.models import AgentCard, Artifact, Task, TaskState
from .a2a.server import register_agent, router as a2a_router

logger = logging.getLogger("dapparena_sdk.base_agent")


class BaseAgentV2(ABC):
    """WSP 에이전트 기본 클래스.

    개발자는 이 클래스를 상속하고 handle_task()를 구현합니다.

    Example:
        class CheolsuAgent(BaseAgentV2):
            async def handle_task(self, task: Task) -> Task:
                # LLM으로 연구 수행
                result = await self.llm_call(task.message)
                task.artifacts.append(Artifact(
                    name="research_summary",
                    mime_type="application/json",
                    data=result,
                ))
                return task
    """

    def __init__(
        self,
        name: str,
        description: str = "",
        port: int = 8080,
        skills: list[str] | None = None,
        host: str = "0.0.0.0",
    ):
        self.name = name
        self.description = description
        self.port = port
        self.skills = skills or []
        self.host = host
        self._start_time = time.time()

    @abstractmethod
    async def handle_task(self, task: Task) -> Task:
        """Task를 처리하고 결과 Task를 반환합니다.

        Args:
            task: 입력 Task (message + 이전 단계 artifacts)

        Returns:
            처리 완료된 Task (artifacts 추가됨)
        """
        ...

    def get_agent_card(self) -> AgentCard:
        """에이전트 능력 명세를 반환합니다."""
        return AgentCard(
            name=self.name,
            description=self.description,
            url=f"http://{self.host}:{self.port}",
            skills=self.skills,
        )

    def _create_app(self) -> FastAPI:
        """FastAPI 앱을 구성합니다."""
        app = FastAPI(title=f"WSP Agent: {self.name}", version="1.0.0")

        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # 에이전트 등록
        register_agent(self)
        register_agent_card(self)

        # 라우터 포함
        app.include_router(a2a_router)
        app.include_router(agent_card_router)

        # 헬스체크
        @app.get("/health")
        async def health():
            return JSONResponse(content={
                "status": "online",
                "agent_name": self.name,
                "uptime_seconds": round(time.time() - self._start_time, 1),
            })

        return app

    def run(self, host: str | None = None, port: int | None = None) -> None:
        """에이전트 서버를 시작합니다.

        Args:
            host: 바인딩 호스트 (기본: self.host)
            port: 바인딩 포트 (기본: self.port)
        """
        _host = host or self.host
        _port = port or self.port
        app = self._create_app()
        logger.info(f"🚀 {self.name} 에이전트 시작: http://{_host}:{_port}")
        uvicorn.run(app, host=_host, port=_port, log_level="info")
