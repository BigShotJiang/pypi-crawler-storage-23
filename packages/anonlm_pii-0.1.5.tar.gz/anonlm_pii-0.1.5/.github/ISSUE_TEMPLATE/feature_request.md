---
name: Feature request
about: Suggest an improvement
labels: enhancement
---

## Problem statement

## Proposed solution

## Alternatives considered

## Additional context
