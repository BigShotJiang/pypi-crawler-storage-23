## Summary

## Changes

## Testing
- [ ] `ruff check .`
- [ ] `ruff format --check .`
- [ ] `mypy src`
- [ ] `pytest`

## Benchmark impact

## Checklist
- [ ] Documentation updated (if needed)
- [ ] Changelog updated (if needed)
