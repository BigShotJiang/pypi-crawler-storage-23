# Code of Conduct

## Our Pledge

We as members, contributors, and leaders pledge to make participation in our
community a harassment-free experience for everyone.

## Our Standards

Examples of behavior that contributes to a positive environment include:
- Being respectful and constructive in communication.
- Accepting feedback gracefully.
- Prioritizing the project's best interests and user safety.

Examples of unacceptable behavior include:
- Harassment, intimidation, or discrimination.
- Personal attacks or inflammatory language.
- Publishing others' private information without explicit permission.

## Enforcement Responsibilities

Project maintainers are responsible for clarifying and enforcing standards.

## Scope

This Code of Conduct applies within project spaces and in public spaces when
an individual is officially representing the project.

## Enforcement

Report incidents privately to the maintainers through security/contact channels
listed in `SECURITY.md`.

## Attribution

This document is adapted from the Contributor Covenant, version 2.1.
