"""
Building Simulation repository with database CRUD operations
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2019 - 2025 Concordia CERC group
Project Coder Koa Wells kekoa.wells@concordia.ca
"""
import datetime
import logging
from pathlib import Path
from sqlalchemy import select, update, delete
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session, selectinload

from cerc_persistence.models import BuildingSimulationModel
from cerc_persistence.models import CityModel
from cerc_persistence.models import BuildingModel
from cerc_persistence.repository import Repository

class BuildingSimulationRepository(Repository):
  """
  BuildingSimulation(Repository) class
  """
  _instance = None

  def __init__(self, dotenv_path: Path, app_env: str):
    super().__init__(dotenv_path, app_env)

  def __new__(cls, dotenv_path, app_env):
    """
    Implemented for a singleton pattern
    """
    if cls._instance is None:
      cls._instance = super(BuildingSimulationRepository, cls).__new__(cls)
    return cls._instance

  def insert(self,
             building_id: int,
             retrofit_scenario: str,
             energy_simulation_source: str,
             energy_simulation: dict,
             co2_emissions: dict,
             costs: dict):
    """
    Inserts a new building simulation into the database
    :param building_id: id of the building of which the building simulation is associated
    :param retrofit_scenario: Retrofit scenario applied to the building
    :param energy_simulation_source: Source of the energy simulation such as EnergyPlus, INSEL, etc.
    :param energy_simulation: Energy simulation result
    :param co2_emissions: Co2 emissions simulation result
    :param costs: Cost simulation result
    :return: int
    """
    building_simulation = self.get_by_building_id_and_retrofit_scenario(building_id, retrofit_scenario)
    if building_simulation:
      logging.error(f'cerc_persistence:Building simulation {building_simulation} already exists')
      raise SQLAlchemyError(f'A building simulation associated to the building with the id {building_id} and the retrofit'
                            f'scenario {retrofit_scenario } already exists in the database')
    try:
      building_simulation = BuildingSimulationModel(building_id,
                                                    retrofit_scenario,
                                                    energy_simulation_source,
                                                    energy_simulation,
                                                    co2_emissions,
                                                    costs)
      with Session(self.engine) as session:
        session.add(building_simulation)
        session.flush()
        session.commit()
        session.refresh(building_simulation)
        return building_simulation.id
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:An error occurred while building simulation %s', err)
      raise SQLAlchemyError from err

  def update(self,
             building_name: str,
             city_name: str,
             retrofit_scenario: str,
             energy_simulation_source: str,
             energy_simulation: dict,
             co2_emissions: dict,
             costs: dict):
    """
    Updates a building simulation that corresponds to a specific city name, building name, and retrofit scenario:
    :param building_name: name of the building who's building simulation should be updated
    :param city_name: name of the city who owns the building
    :param retrofit_scenario: Retrofit scenario applied to the building
    :param energy_simulation_source: Updated source of the energy simulation such as EnergyPlus, INSEL, etc.
    :param energy_simulation: Updated energy simulation result
    :param co2_emissions: Updated CO2 emissions simulation result
    :param costs: Updated cost simulation result
    :return: None
    """
    updated_values = {'updated': datetime.datetime.now()}
    if energy_simulation_source:
      updated_values['energy_simulation_source'] = energy_simulation_source
    if energy_simulation:
      updated_values['energy_simulation'] = energy_simulation
    if co2_emissions:
      updated_values['co2_emissions'] = co2_emissions
    if costs:
      updated_values['costs'] = costs

    try:
      with Session(self.engine) as session:
        query =  select(BuildingModel).join(CityModel, CityModel.id == CityModel.id).where(
          CityModel.name == city_name, BuildingModel.name == building_name)
        building = session.execute(query).scalar_one_or_none()
        statement = update(BuildingSimulationModel).where(BuildingSimulationModel.building_id == building.id,
                                                          BuildingSimulationModel.retrofit_scenario == retrofit_scenario).values(updated_values)
        session.execute(statement)
        session.commit()
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while updating building simulation %s', err)
      raise SQLAlchemyError from err

  def delete(self, city_name: str, building_name: str, retrofit_scenario: str):
    """
    Delete building simulation that corresponds with building_id and retrofit scenario
    :param city_name: name of the city who owns the building
    :param building_name: name of the building of which the building simulation is associated
    :param retrofit_scenario: Retrofit scenario applied to the building
    :return: None
    """
    try:
      with Session(self.engine) as session:
        subquery = select(BuildingModel.id
                          ).join(BuildingModel.city
                          ).where(CityModel.name == city_name, BuildingModel.name == building_name)
        statement = delete(BuildingSimulationModel).where(BuildingSimulationModel.id._in(subquery),
                                                          BuildingSimulationModel.retrofit_scenario == retrofit_scenario)
        session.execute(statement)
        session.commit()
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while deleting building simulation %s', err)
      raise SQLAlchemyError from err

  def get_by_building_id_and_retrofit_scenario(self, building_id, retrofit_scenario):
    """
    Fetch building simulation result by building_id and retrofit_scenario
    :param building_id: id of the building of which the simulation result is associated
    :param retrofit_scenario: Retrofit scenario applied to the building
    :return: [BuildingSimulationModel] or None
    """
    try:
      with Session(self.engine) as session:
        query = select(BuildingSimulationModel).where(
          BuildingSimulationModel.building_id == building_id,
          BuildingSimulationModel.retrofit_scenario == retrofit_scenario)
        building_simulation = session.execute(query).scalar_one_or_none()
        return building_simulation
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while fetching building simulation by building id and retrofit scenario: %s', err)
      raise SQLAlchemyError from err

  def get_multiple_by_city_name(self, city_name: str):
    """
    Fetch building simulations result by city_name
    :param city_name: name of the city who owns the building simulations
    :return: [BuildingSimulation] or None
    """
    try:
      with Session(self.engine) as session:
        query = select(CityModel).where(CityModel.name == city_name).options(
          selectinload(CityModel.buildings).
          selectinload(BuildingModel.building_simulations))
        city = session.execute(query).scalar_one_or_none()
        if not city:
          return None
        building_simulations = [
          building_simulation
          for building in city.buildings or []
          for building_simulation in (building.building_simulations or [])
        ]
        return building_simulations
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while fetching building simulation by building id and retrofit scenario: %s', err)
      raise SQLAlchemyError from err