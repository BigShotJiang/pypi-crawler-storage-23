"""
Building repository with database CRUD operations
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2019 - 2025 Concordia CERC group
Project Coder Koa Wells kekoa.wells@concordia.ca
"""
import datetime
import logging
from pathlib import Path
from sqlalchemy import select, update, delete
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session, selectinload, contains_eager
from hub.city_model_structure.building import Building as HubBuilding

from cerc_persistence.models import BuildingModel
from cerc_persistence.models import CityModel
from cerc_persistence.repository import Repository


class BuildingRepository(Repository):
  """
  Building(Repository) class
  """
  _instance = None
  def __init__(self, dotenv_path: Path, app_env: str):
    super().__init__(dotenv_path, app_env)

  def __new__(cls, dotenv_path, app_env):
    """
    Implemented for a singleton pattern
    """
    if cls._instance is None:
      cls._instance = super(BuildingRepository, cls).__new__(cls)
    return cls._instance

  def insert(self, city_id: int, hub_city_name:str, partition_id: str, hub_building: HubBuilding):
    """
    Inserts a new building into the database
    :param city_id: id of the city partition that owns the building
    :param hub_city_name: name of city where the building belongs from the cerc-hub
    :param partition_id: id of the partition that owns the building
    :param hub_building: a cerc-hub Building object whose data will be inserted
    :return: int
    """
    building = self.get_by_name_and_city_id(hub_building.name, city_id)
    if building:
      logging.error(f'cerc_persistence:Building {building} already exists')
      raise Exception(f'Building {hub_building.name} already exists')
    try:
      building = BuildingModel(city_id, hub_city_name, partition_id, hub_building)
      with Session(self.engine) as session:
        session.add(building)
        session.flush()
        session.commit()
        session.refresh(building)
      return building.id
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:An error occurred while creating building %s', err)
      raise SQLAlchemyError from err

  def update(self, city_name: str, building_name: str, aliases: list[str], year_of_construction: int, function: str, usage: str):
    """
    Updates an existing building in the database
    :param city_name: name of the city that owns the building
    :param building_name: name of the building to update
    :param aliases: updated aliases of the building
    :param year_of_construction: updated year of the construction
    :param function: updated function of the building
    :param usage: updated usage of the building
    :return: None
    """
    updated_values = {'updated': datetime.datetime.now()}
    if aliases:
      updated_values['aliases'] = aliases
    if year_of_construction:
      updated_values['year_of_construction'] = year_of_construction
    if function:
      updated_values['function'] = function
    if usage:
      updated_values['usage'] = usage

    try:
      with Session(self.engine) as session:
        query = select(CityModel).where(CityModel.name == city_name)
        city_id = session.execute(query).scalar_one_or_none().id
        statement = update(BuildingModel).where(BuildingModel.city_id == city_id,
                                                BuildingModel.name == building_name).values(updated_values)
        session.execute(statement)
        session.commit()
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while updating building %s', err)
      raise SQLAlchemyError from err

  def delete(self, city_name: int, building_name: str):
    """
    Deletes an existing building from the database
    :param city_name: The name of the city that owns the building
    :param building_name: The name of the building to delete
    :return: None
    """
    try:
      with Session(self.engine) as session:
        query = select(CityModel).where(CityModel.name == city_name)
        city_id = session.execute(query).scalar_one_or_none().id
        statement = delete(BuildingModel).where(BuildingModel.city_id == city_id, BuildingModel.name == building_name)
        session.execute(statement)
        session.commit()
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while deleting building %s', err)
      raise SQLAlchemyError from err

  def get_by_name_and_city_id(self, building_name, city_id):
    """
    Fetch building by building_name and city_id from the database
    :param building_name: The name of the building to fetch
    :param city_id: id of the city that owns the buildings
    :return: BuildingModel or None
    """
    try:
      with Session(self.engine) as session:
        query = select(BuildingModel).where(BuildingModel.name == building_name, BuildingModel.city_id == city_id)
        building = session.execute(query).scalar_one_or_none()
        return building
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while fetching building by name and city name: %s', err)
      raise SQLAlchemyError from err

  def get_by_name_and_city_name(self, building_name, city_name):
    """
    Fetch building by city name and building name
    :param building_name: The name of the building to fetch
    :param city_name: The name of the city that owns the building
    :return: BuildingModel or None
    """
    try:
      with (Session(self.engine) as session):
        query =  select(BuildingModel).join(CityModel, BuildingModel.city_id == CityModel.id).where(
          CityModel.name == city_name, BuildingModel.name == building_name)
        building = session.execute(query).scalar_one_or_none()
        return building
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while fetching building by name and city name: %s', err)
      raise SQLAlchemyError from err

  def get_multiple_by_names_and_city_name(self, building_names: list[str], city_name: str):
    """
    Fetch buildings by their names
    :param building_names: List of building names to fetch
    :param city_name: The name of the city that owns the buildings
    :return: [BuildingModel] or None
    """
    try:
      with Session(self.engine) as session:
        query = select(BuildingModel).join(CityModel, CityModel.id == CityModel.id).where(
          CityModel.name == city_name, BuildingModel.name.in_(building_names))
        buildings = session.execute(query).scalars().all()
        return buildings
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while fetching multiple buildings by name and city name: %s', err)
      raise SQLAlchemyError from err

  def get_multiple_by_city_name(self, city_name: str):
    """
    Fetch buildings by the name of the city that owns them
    :param city_name: The name of the city that owns the buildings
    :return: [BuildingModel] or None
    """
    try:
      with Session(self.engine) as session:
        query = select(CityModel).where(CityModel.name == city_name).options(selectinload(CityModel.buildings))
        city = session.execute(query).scalar_one_or_none()
        if not city:
          return None
        buildings = city.buildings
        return buildings
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while fetching multiple buildings by city name: %s', err)
      raise SQLAlchemyError from err

  def get_multiple_with_simulations_by_city_name_and_building_ids(self, city_name: str, building_ids: list):
    """
    Fetch buildings by city name and building ids. This function additionally comes with the corresponding
    building simulations.
    :param city_name: The name of the city that owns the buildings
    :param building_ids: List of building ids
    """
    try:
      with Session(self.engine) as session:
        query = (
          select(BuildingModel)
          .join(BuildingModel.city)
          .join(BuildingModel.building_simulations)
          .where(
            CityModel.name == city_name,
            BuildingModel.id.in_(building_ids)
          )
          .options(
            contains_eager(BuildingModel.building_simulations)
          )
        )
        buildings = session.execute(query, {"city_name": city_name, "building_ids": building_ids}).scalars().unique().all()
      return buildings
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while fetching buildings with simulations by building ids and city name'
                    ' simulation by building id and retrofit scenario: %s', err)
      raise SQLAlchemyError from err
