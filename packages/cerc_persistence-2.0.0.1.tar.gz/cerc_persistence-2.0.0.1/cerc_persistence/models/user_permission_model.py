"""
Model representation of User Permissions
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2019 - 2025 Concordia CERC group
Project Coder Koa Wells kekoa.wells@concordia.ca
"""
import datetime
from sqlalchemy import Integer, Sequence, ForeignKey, DateTime
from sqlalchemy.orm import relationship, Mapped, mapped_column

from cerc_persistence.configuration import Models

class UserPermissionModel(Models):
  """
  UserPermissionModel(Models) class
  """
  __tablename__ = 'user_permission'
  id:Mapped[int] = mapped_column(Integer, Sequence('permissions_id_seq'), primary_key=True)
  user_id:Mapped[int] = mapped_column(Integer, ForeignKey('user.id'), nullable=False)
  city_id:Mapped[int] = mapped_column(Integer, ForeignKey('city.id'), nullable=False)
  created:Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.now)
  updated:Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.now)

  user = relationship("UserModel", back_populates="user_permissions")

  def __init__(self, user_id, city_id):
    super().__init__()
    self.user_id = user_id
    self.city_id = city_id
