"""
Model representation of building simulations including energy simulations, co2 emissions simulations, and costs simulations
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2019 - 2025 Concordia CERC group
Project Coder Koa Wells kekoa.wells@concordia.ca
"""
import datetime
from sqlalchemy import Column, Integer, String, Sequence, ForeignKey, DateTime
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.orm import relationship, Mapped, mapped_column

from cerc_persistence.configuration import Models


class BuildingSimulationModel(Models):
  """
  BuildingSimulationModel(Models) class
  """
  __tablename__ = 'building_simulation'
  id: Mapped[int] = mapped_column(Integer, Sequence('building_simulation_id_seq'), primary_key=True)
  building_id: Mapped[int] = mapped_column(Integer, ForeignKey('building.id'), nullable=False)
  retrofit_scenario: Mapped[str] = mapped_column(String, nullable=False)
  energy_simulation_source: Mapped[str] = mapped_column(String, nullable=True)
  energy_simulation: Mapped[dict] = mapped_column(JSON, nullable=True)
  co2_emissions: Mapped[dict] = mapped_column(JSON, nullable=True)
  costs: Mapped[dict] = mapped_column(JSON, nullable=True)
  created: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.now)
  updated: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.now)

  building = relationship("BuildingModel", back_populates="building_simulations")

  def __init__(self, building_id, retrofit_scenario, energy_simulation_source, energy_simulation, co2_emissions, costs):
    super().__init__()
    self.building_id = building_id
    self.retrofit_scenario = retrofit_scenario
    self.energy_simulation_source = energy_simulation_source
    self.energy_simulation = energy_simulation
    self.co2_emissions = co2_emissions
    self.costs = costs
