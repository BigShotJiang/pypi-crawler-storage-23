"""
Model representation of a City
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2022 Concordia CERC group
Project Coder Peter Yefi peteryefi@gmail.com
Contributor Koa Wells kekoa.wells@concordia.ca
"""
import datetime
from sqlalchemy import Integer, String, Sequence, DateTime
from sqlalchemy.orm import relationship, Mapped, mapped_column
from geoalchemy2 import Geometry

from cerc_persistence.configuration import Models

class CityModel(Models):
  """
  CityModel(Models) class
  """
  __tablename__ = 'city'
  id: Mapped[int] = mapped_column(Integer, Sequence('city_id_seq'), primary_key=True)
  name: Mapped[str] = mapped_column(String, nullable=False)
  location: Mapped[str] = mapped_column(Geometry('POINT', srid=4326), nullable=False)
  description: Mapped[str] = mapped_column(String, nullable=True)
  created: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.now)
  updated: Mapped[datetime.datetime] = mapped_column(DateTime, default=datetime.datetime.now)

  buildings = relationship('BuildingModel', back_populates='city')

  def __init__(self, name, location, description):
    super().__init__()
    self.name = name
    self.location = location
    self.description = description
    self.created = datetime.datetime.now()
    self.updated = datetime.datetime.now()
