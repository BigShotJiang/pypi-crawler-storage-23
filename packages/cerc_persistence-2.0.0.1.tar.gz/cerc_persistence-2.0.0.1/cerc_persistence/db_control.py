"""
DBControl acts as intermediary class for using the database CRUD functions 
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2019 - 2025 Concordia CERC group
Project Coder Peter Yefi peteryefi@gmail.com
Code Contributor Koa Wells kekoa.wells@concordia.ca
"""
from pathlib import Path
from geoalchemy2 import WKTElement
from sqlalchemy import text
from hub.city_model_structure.building import Building as HubBuilding

from cerc_persistence.repository import Repository
from cerc_persistence.models import UserRoles
from cerc_persistence.configuration import Models
from cerc_persistence.repositories.user_repository import UserRepository
from cerc_persistence.repositories.user_permission_repository import UserPermissionRepository
from cerc_persistence.repositories.city_repository import CityRepository
from cerc_persistence.repositories.building_repository import BuildingRepository
from cerc_persistence.repositories.building_simulation_repository import BuildingSimulationRepository


class DBControl:
  """
  DBFactory class
  """
  def __init__(self, dotenv_path: Path, app_env: str):
    """
    Initializes the repositories used for accessing the CRUD functions by the DBControl class    
    :param dotenv_path: path to the .env file
    :param app_env: name of the application environment (PROD or TEST)
    """
    self._dotenv_path = dotenv_path
    self._app_env = app_env
    self._user = UserRepository(self._dotenv_path, self._app_env)
    self._user_permission = UserPermissionRepository(self._dotenv_path, self._app_env)
    self._city = CityRepository(self._dotenv_path, self._app_env)
    self._building = BuildingRepository(self._dotenv_path, self._app_env)
    self._building_simulation = BuildingSimulationRepository(self._dotenv_path, self._app_env)

  def initialize_database(self):
    """
    Creates database tables 
    :return: None
    """
    repository = Repository(self._dotenv_path, self._app_env)
    # ensure that postgis gets installed
    with repository.engine.begin() as conn:
      conn.execute(text("CREATE EXTENSION IF NOT EXISTS postgis"))

    # Create the tables using the models
    Models.metadata.create_all(bind=repository.engine)

  def purge_database(self):
    """
    Purges all database tables, sequences, and extensions
    :return: None
    """
    repository = Repository(self._dotenv_path, self._app_env)
    Models.metadata.drop_all(bind=repository.engine)
    # drops all sequences and extensions
    with repository.engine.connect() as conn:
      conn.execute(text("""
                        SELECT 'DROP SEQUENCE IF EXISTS "' || sequence_schema || '"."' || sequence_name || '" CASCADE;'
                        FROM information_schema.sequences
                        WHERE sequence_schema = 'public';
                        """))

  def persist_city(self, name: str, location: WKTElement, description: str):
    """
    Persists city into the database
    :param name: name of the city
    :param location: location of the city
    :param description: description of the city
    :return: int
    """
    city_id = self._city.insert(name, location, description)
    return city_id

  def persist_building(self, city_id: int, hub_city_name: str, partition_id: str, building: HubBuilding):
    """
    Persists building into the database
    :param city_id: id of the city
    :param hub_city_name: name assigned to the city by the cerc-hub package based on location
    :param partition_id: id of the city partition that owns the building
    :param building: cerc-hub Building containing pertinent data to persist the building
    :return: int
    """
    building_id = self._building.insert(city_id, hub_city_name, partition_id, building)
    return building_id

  def persist_building_simulation(self, building_id: int,
                                  retrofit_scenario: str,
                                  energy_simulation_source: str,
                                  energy_simulation: dict,
                                  co2_emissions: dict,
                                  costs: dict):
    """
    Persists a new building simulation into the database
    :param building_id: id of the building of which the building simulation is associated
    :param retrofit_scenario: Retrofit scenario applied to the building
    :param energy_simulation_source: Source of the energy simulation such as EnergyPlus, INSEL, etc.
    :param energy_simulation: Energy simulation result
    :param co2_emissions: Co2 emissions simulation result
    :param costs: Cost simulation result
    :return: int
    """
    building_simulation_id = self._building_simulation.insert(building_id,
                                                              retrofit_scenario,
                                                              energy_simulation_source,
                                                              energy_simulation,
                                                              co2_emissions,
                                                              costs)
    return building_simulation_id

  def persist_user(self, username: str, password: str, role: UserRoles):
    """
    Persists user into the database
    :param username: username of the user
    :param password: password of the user
    :param role: role of the user
    :return: int
    """
    user_id = self._user.insert(username, password, role)
    return user_id

  def persist_user_permission(self, user_id: int, city_id: int):
    """
    Persists user permission into the database
    :param user_id: id of the user of which the user permission is associated
    :param city_id: id of the city for which the user has permission to access
    :return: int
    """
    user_permission_id = self._user_permission.insert(user_id, city_id)
    return user_permission_id

  def get_city_by_name(self, name: str):
    """
    Fetch city from the database by name
    :param name: name of the city
    :return: CityModel or None
    """
    city = self._city.get_by_name(name)
    return city

  def get_cities_by_city_ids(self, city_ids):
    """
    Fetch multiple cities from the database from a list of city_ids
    :param city_ids: list of city ids
    """
    cities = self._city.get_multiple_by_city_ids(city_ids)
    return cities

  def get_building_by_name_and_city_name(self, name: str, city_name: str):
    """
    Fetch building from the database by name and city name
    :param name: name of the building
    :param city_name: name of the city that owns the building
    """
    building = self._building.get_by_name_and_city_name(name, city_name)
    return building

  def get_buildings_by_city_name(self, city_name: str):
    """
    Fetch buildings from the database by city_name
    :param city_name: name of the city who owns the building(s)
    :return: [BuildingModel] or None
    """
    buildings = self._building.get_multiple_by_city_name(city_name)
    return buildings

  def get_building_simulations_by_city_name(self, city_name: str):
    """
    Fetch building simulations from the database by city_name
    :param city_name: name of the city who owns the building_simulation(s)
    :return: [BuildingSimulationModel] or None
    """
    building_simulations = self._building_simulation.get_multiple_by_city_name(city_name)
    return building_simulations

  def get_buildings_with_simulations_by_city_name_and_building_ids(self, city_name: str, building_ids: list):
    """
    Fetch buildings and their associated building simulations from the database by city_name and building_ids
    :param city_name: name of the city who owns the buildings
    :param building_ids: list of building ids
    """
    buildings = self._building.get_multiple_with_simulations_by_city_name_and_building_ids(city_name, building_ids)
    return buildings

  def get_user_by_username(self, username: str):
    """
    Fetch user from the database by username
    :param username: username of the user
    """
    user = self._user.get_by_username(username)
    return user

  def get_user_by_username_and_password(self, username: str, password: str):
    """
    Fetch user from the database by username and password
    :param username: username of the user
    :param password: password of the user
    """
    user = self._user.get_by_username_and_password(username, password)
    return user

  def get_user_permissions_by_user_id(self, user_id: int):
    """
    Fetch user permissions from the database by user_id
    :param user_id: id of the user
    """
    user_permissions = self._user_permission.get_multiple_by_user_id(user_id)
    return user_permissions
