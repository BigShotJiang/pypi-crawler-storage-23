"""Demo application for DataPresentation with multiple callbacks."""

import panel as pn

from callbacks import (
    bar_chart,
    heatmap_plot,
    histogram_plot,
    parametric_curve,
    scatter_plot,
    spiral_plot,
    wave_function,
)
from holoviz_utils.dataviz import DataPresentation

# Enable Panel extension
pn.extension()

# Create DataPresentation instance with all callback functions
dp = DataPresentation(
    dm_funcs=[
        wave_function,
        bar_chart,
        spiral_plot,
        scatter_plot,
        parametric_curve,
        histogram_plot,
        heatmap_plot,
    ],
    title="# Interactive Data Visualization Explorer",
    introduction="""
    Welcome to the interactive visualization explorer! This demo showcases multiple
    types of plots with dynamic controls. Each visualization updates in real-time
    as you adjust the parameters below.

    Explore trigonometric functions, statistical distributions, parametric curves,
    and more. All visualizations are powered by HoloViews and Panel.
    """,
    conclusion="""
    ## Summary

    This demo demonstrates the power of combining:
    - **Type-annotated functions** with parameter bounds
    - **Automatic widget generation** from function signatures
    - **Real-time interactive visualizations** with HoloViews DynamicMaps
    - **Clean layouts** using Panel

    Try creating your own callback functions with parameter annotations to build
    custom interactive visualizations!
    """,
)

# Serve the application
if __name__ == "__main__":
    pn.serve(dp.view, port=5006, show=True)
