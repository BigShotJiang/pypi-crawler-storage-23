"""HoloViz utilities package."""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("holoviz-utils")
except PackageNotFoundError:
    __version__ = "unknown"
