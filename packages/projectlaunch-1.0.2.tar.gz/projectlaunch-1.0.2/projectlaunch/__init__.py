"""
ProjectLaunch - Simple GitHub Push Tool
"""

__version__ = "1.0.2"
__author__ = "ProjectLaunch Contributors"

from projectlaunch.core import GitPusher

__all__ = ["GitPusher"]
