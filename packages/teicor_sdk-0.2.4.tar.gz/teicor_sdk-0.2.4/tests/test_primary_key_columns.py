from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import Mock


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from teicor_sdk import TeicorClient, TeicorSdkError  # noqa: E402


class PrimaryKeyColumnsTestCase(unittest.TestCase):
    def _client(self) -> TeicorClient:
        return TeicorClient(
            base_url="http://example.test",
            team_slug="team-a",
            app_slug="app-a",
            service_token="token",
        )

    def test_create_column_can_set_primary_key(self) -> None:
        client = self._client()
        client.runtime_request = Mock(
            side_effect=[
                {"id": "col_123", "name": "External ID"},
                {"table_id": "tbl_1", "column_id": "col_123"},
            ]
        )

        payload = client.create_column(
            table_id="tbl_1",
            name="External ID",
            column_type="single_line_text",
            set_as_primary_key=True,
        )

        self.assertEqual(payload["id"], "col_123")
        self.assertEqual(client.runtime_request.call_count, 2)
        client.runtime_request.assert_any_call(
            method="POST",
            runtime_path="tables/tbl_1/columns",
            payload={
                "table_id": "tbl_1",
                "name": "External ID",
                "type": "single_line_text",
                "config": None,
            },
        )
        client.runtime_request.assert_any_call(
            method="PATCH",
            runtime_path="tables/tbl_1/primary-key",
            payload={"column_id": "col_123"},
        )

    def test_create_column_set_primary_key_requires_created_id(self) -> None:
        client = self._client()
        client.runtime_request = Mock(return_value={"name": "External ID"})

        with self.assertRaises(TeicorSdkError):
            client.create_column(
                table_id="tbl_1",
                name="External ID",
                column_type="single_line_text",
                set_as_primary_key=True,
            )

        self.assertEqual(client.runtime_request.call_count, 1)

    def test_update_column_can_set_primary_key(self) -> None:
        client = self._client()
        client.runtime_request = Mock(
            side_effect=[
                {"id": "col_123", "name": "External ID"},
                {"table_id": "tbl_1", "column_id": "col_123"},
            ]
        )

        payload = client.update_column(
            table_id="tbl_1",
            column_id="col_123",
            name="External ID",
            set_as_primary_key=True,
        )

        self.assertEqual(payload["id"], "col_123")
        self.assertEqual(client.runtime_request.call_count, 2)
        client.runtime_request.assert_any_call(
            method="PATCH",
            runtime_path="tables/tbl_1/columns/col_123",
            payload={"name": "External ID"},
        )
        client.runtime_request.assert_any_call(
            method="PATCH",
            runtime_path="tables/tbl_1/primary-key",
            payload={"column_id": "col_123"},
        )


if __name__ == "__main__":
    unittest.main()
