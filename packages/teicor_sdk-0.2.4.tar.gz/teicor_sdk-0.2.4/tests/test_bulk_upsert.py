from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import Mock


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from teicor_sdk import TeicorClient, TeicorSdkError  # noqa: E402


class BulkUpsertTestCase(unittest.TestCase):
    def _client(self) -> TeicorClient:
        return TeicorClient(
            base_url="http://example.test",
            team_slug="team-a",
            app_slug="app-a",
            service_token="token",
        )

    def test_upsert_records_bulk_defaults_to_overwrite(self) -> None:
        client = self._client()
        client.create_records_bulk = Mock(
            return_value={"created": 2, "updated": 1}
        )

        payload = client.upsert_records_bulk(
            table_id="tbl_1",
            records=[{"col_a": "x"}],
        )

        self.assertEqual(payload, {"created": 2, "updated": 1})
        client.create_records_bulk.assert_called_once_with(
            table_id="tbl_1",
            records=[{"col_a": "x"}],
            on_conflict="overwrite",
        )

    def test_upsert_records_bulk_accepts_conflict_policy(self) -> None:
        client = self._client()
        client.create_records_bulk = Mock(
            return_value={"created": 1, "updated": 0}
        )

        payload = client.upsert_records_bulk(
            table_id="tbl_1",
            records=[{"col_a": "x"}],
            conflict_policy="keep_both",
        )

        self.assertEqual(payload, {"created": 1, "updated": 0})
        client.create_records_bulk.assert_called_once_with(
            table_id="tbl_1",
            records=[{"col_a": "x"}],
            on_conflict="keep_both",
        )

    def test_upsert_records_bulk_rejects_invalid_policy(self) -> None:
        client = self._client()
        client.create_records_bulk = Mock()

        with self.assertRaises(TeicorSdkError):
            client.upsert_records_bulk(
                table_id="tbl_1",
                records=[{"col_a": "x"}],
                conflict_policy="invalid",
            )

        client.create_records_bulk.assert_not_called()


if __name__ == "__main__":
    unittest.main()
