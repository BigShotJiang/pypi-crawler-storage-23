from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import Mock


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from teicor_sdk import (  # noqa: E402
    QuerySyncSummary,
    TableSyncSummary,
    TeicorClient,
)


class SyncSummariesTestCase(unittest.TestCase):
    def _client(self) -> TeicorClient:
        return TeicorClient(
            base_url="http://example.test",
            team_slug="team-a",
            app_slug="app-a",
            service_token="token",
        )

    def test_sync_queries_filters_query_ids_and_returns_typed_summary(
        self,
    ) -> None:
        client = self._client()
        client.list_queries = Mock(
            return_value=[
                {"id": "q-1", "updated_at": "2026-02-22T00:00:01Z"},
                {"id": "q-2", "updated_at": "2026-02-22T00:00:02Z"},
            ]
        )
        client.get_query_data = Mock(
            return_value={
                "unchanged": False,
                "source_watermark": "wm-q-1",
            }
        )

        summary = client.sync_queries(
            state={"last_sync_at": "", "query_watermarks": {}},
            query_ids=["q-1"],
            include_all=True,
            persist_state=False,
        )

        self.assertIsInstance(summary, QuerySyncSummary)
        self.assertTrue(summary.first_sync)
        self.assertEqual(summary.changed_query_count, 1)
        self.assertEqual(summary.checked_query_data_count, 1)
        self.assertEqual(summary.queries_with_data_changes, 1)
        self.assertEqual(
            summary.state_patch["query_watermarks"],
            {"q-1": "wm-q-1"},
        )

        client.get_query_data.assert_called_once_with(
            "q-1", if_newer_than_watermark=None
        )

    def test_sync_tables_filters_table_ids_and_returns_typed_summary(
        self,
    ) -> None:
        client = self._client()
        client.list_tables = Mock(
            return_value=[
                {"id": "t-1", "updated_at": "2026-02-22T01:00:01Z"},
                {"id": "t-2", "updated_at": "2026-02-22T01:00:02Z"},
            ]
        )
        client.get_table_sync_status = Mock(
            return_value={
                "has_changes": False,
                "source_watermark": "wm-t-1",
            }
        )
        client.list_records = Mock(return_value=[])

        summary = client.sync_tables(
            state={"tables_last_sync_at": "", "table_watermarks": {}},
            table_ids=["t-1"],
            persist_state=False,
        )

        self.assertIsInstance(summary, TableSyncSummary)
        self.assertTrue(summary.first_sync)
        self.assertEqual(summary.changed_table_count, 1)
        self.assertEqual(summary.checked_table_status_count, 1)
        self.assertEqual(summary.tables_with_data_changes, 0)
        self.assertEqual(summary.records_synced, 0)
        self.assertEqual(
            summary.state_patch["table_watermarks"],
            {"t-1": "wm-t-1"},
        )

        client.get_table_sync_status.assert_called_once_with(
            "t-1", if_newer_than_watermark=None
        )
        client.list_records.assert_not_called()


if __name__ == "__main__":
    unittest.main()
