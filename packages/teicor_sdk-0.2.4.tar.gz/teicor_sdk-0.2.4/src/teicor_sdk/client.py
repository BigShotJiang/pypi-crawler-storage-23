from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Callable
from urllib.parse import urlencode
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


class TeicorSdkError(RuntimeError):
    """Base SDK exception."""


class TeicorApiError(TeicorSdkError):
    """Raised when Teicor API responds with an error status code."""

    def __init__(
        self,
        *,
        status_code: int,
        detail: str,
        request_id: str | None = None,
        response_body: str | None = None,
    ):
        self.status_code = status_code
        self.detail = detail
        self.request_id = request_id
        self.response_body = response_body
        message = f"HTTP {status_code}: {detail}"
        if request_id:
            message = f"{message} (request_id={request_id})"
        super().__init__(message)


@dataclass(frozen=True)
class TeicorContext:
    team_id: int
    team_slug: str
    runtime_proxy_base_url: str
    runtime_api_base_url: str
    runtime_access_mode: str
    core_state_url: str
    app_slug: str


@dataclass(frozen=True)
class QuerySyncSummary:
    first_sync: bool
    changed_query_count: int
    checked_query_data_count: int
    queries_with_data_changes: int
    state_patch: dict[str, Any]


@dataclass(frozen=True)
class TableSyncSummary:
    first_sync: bool
    changed_table_count: int
    checked_table_status_count: int
    tables_with_data_changes: int
    records_synced: int
    state_patch: dict[str, Any]


class TeicorClient:
    """SDK for installed Teicor apps.

    Auth headers:
    - Authorization: Bearer <service_token>
    - X-Teicor-App-Slug: <app_slug>
    """

    SDK_VERSION = "0.2.4"
    COLUMN_TYPES = (
        "link",
        "lookup",
        "rollup",
        "single_line_text",
        "long_text",
        "checkbox",
        "date",
        "number",
        "percent",
        "created_time",
        "last_modified_time",
        "autonumber",
    )
    FILTER_OPS = (
        "eq",
        "contains",
        "gt",
        "gte",
        "lt",
        "lte",
        "is_empty",
        "is_not_empty",
    )

    def __init__(
        self,
        *,
        base_url: str,
        team_slug: str,
        app_slug: str,
        service_token: str,
        timeout_seconds: int = 20,
    ):
        self.base_url = base_url.rstrip("/")
        self.team_slug = team_slug
        self.app_slug = app_slug
        self.service_token = service_token
        self.timeout_seconds = timeout_seconds

    def _headers(self, include_json_content_type: bool) -> dict[str, str]:
        headers = {
            "Accept": "application/json",
            "Authorization": f"Bearer {self.service_token}",
            "X-Teicor-App-Slug": self.app_slug,
            "User-Agent": f"teicor-sdk-python/{self.SDK_VERSION}",
        }
        if include_json_content_type:
            headers["Content-Type"] = "application/json"
        return headers

    @staticmethod
    def _to_json(raw: str) -> Any:
        if not raw:
            return {}
        return json.loads(raw)

    def _request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        query: dict[str, Any] | None = None,
    ) -> Any:
        url = f"{self.base_url}{path}"
        if query:
            encoded: dict[str, str] = {}
            for key, value in query.items():
                if value is None:
                    continue
                if isinstance(value, (dict, list)):
                    encoded[key] = json.dumps(value)
                else:
                    encoded[key] = str(value)
            if encoded:
                url = f"{url}?{urlencode(encoded)}"
        body: bytes | None = None
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")

        req = Request(
            url=url,
            method=method.upper(),
            data=body,
            headers=self._headers(
                include_json_content_type=payload is not None
            ),
        )
        try:
            with urlopen(req, timeout=self.timeout_seconds) as res:
                raw = res.read().decode("utf-8") if res.readable() else "{}"
                return self._to_json(raw)
        except HTTPError as exc:
            raw = exc.read().decode("utf-8") if hasattr(exc, "read") else ""
            detail = raw or f"HTTP {exc.code}"
            try:
                parsed = self._to_json(raw)
                if isinstance(parsed, dict) and isinstance(
                    parsed.get("detail"), str
                ):
                    detail = str(parsed["detail"])
            except (
                json.JSONDecodeError,
                TypeError,
                AttributeError,
                ValueError,
                TeicorSdkError,
            ):
                pass
            request_id = (
                exc.headers.get("X-Request-ID") if exc.headers else None
            )
            raise TeicorApiError(
                status_code=int(exc.code),
                detail=detail,
                request_id=request_id,
                response_body=raw or None,
            ) from exc
        except URLError as exc:
            raise TeicorSdkError(
                f"Network error calling Teicor API: {exc}"
            ) from exc
        except TimeoutError as exc:
            raise TeicorSdkError("Timed out calling Teicor API") from exc
        except json.JSONDecodeError as exc:
            raise TeicorSdkError(
                f"Invalid JSON response from Teicor API: {exc}"
            ) from exc

    def get_context(self) -> TeicorContext:
        payload = self._request(
            "GET",
            (f"/v1/teams/{self.team_slug}/context/"),
        )
        if not isinstance(payload, dict):
            raise TeicorSdkError("Invalid context response")
        team = payload.get("team") or {}
        app = payload.get("app") or {}
        runtime_access = payload.get("runtime_access") or {}
        runtime_proxy_base_url = str(
            payload.get("runtime_proxy_base_url")
            or runtime_access.get("runtime_proxy_base_url")
            or ""
        )
        runtime_api_base_url = str(
            payload.get("runtime_api_base_url")
            or runtime_access.get("runtime_api_base_url")
            or ""
        )
        runtime_access_mode = str(
            payload.get("runtime_access_mode")
            or runtime_access.get("mode")
            or "proxy"
        )
        return TeicorContext(
            team_id=int(team.get("id", 0)),
            team_slug=str(team.get("slug", self.team_slug)),
            runtime_proxy_base_url=runtime_proxy_base_url,
            runtime_api_base_url=runtime_api_base_url,
            runtime_access_mode=runtime_access_mode,
            core_state_url=str(payload.get("core_state_url", "")),
            app_slug=str(app.get("slug", self.app_slug)),
        )

    def get_core_state(self) -> dict[str, Any]:
        payload = self._request(
            "GET",
            (f"/v1/teams/{self.team_slug}/core/state/"),
        )
        if not isinstance(payload, dict):
            raise TeicorSdkError("Invalid core state response")
        return dict(payload.get("state") or {})

    def set_core_state(self, state: dict[str, Any]) -> dict[str, Any]:
        payload = self._request(
            "PUT",
            (f"/v1/teams/{self.team_slug}/core/state/"),
            {"state": state},
        )
        if not isinstance(payload, dict):
            raise TeicorSdkError("Invalid core state response")
        return dict(payload.get("state") or {})

    def patch_core_state(self, patch: dict[str, Any]) -> dict[str, Any]:
        payload = self._request(
            "PATCH",
            (f"/v1/teams/{self.team_slug}/core/state/"),
            {"state": patch},
        )
        if not isinstance(payload, dict):
            raise TeicorSdkError("Invalid core state response")
        return dict(payload.get("state") or {})

    def runtime_request(
        self,
        *,
        method: str,
        runtime_path: str,
        payload: dict[str, Any] | None = None,
        query: dict[str, Any] | None = None,
    ) -> Any:
        safe_path = (runtime_path or "").strip().lstrip("/")
        if safe_path.startswith("api/"):
            safe_path = safe_path[4:]
        if safe_path.startswith("runtime/"):
            safe_path = safe_path[8:]
        return self._request(
            method,
            (f"/v1/teams/{self.team_slug}/runtime/{safe_path}"),
            payload,
            query,
        )

    # ---------- Schemas ----------
    def list_schemas(self) -> list[str]:
        payload = self.runtime_request(method="GET", runtime_path="schemas")
        return list(payload.get("schemas") or [])

    def create_schema(self, schema_name: str) -> dict[str, Any]:
        return self.runtime_request(
            method="POST",
            runtime_path="schemas",
            payload={"schema_name": schema_name},
        )

    def update_schema(
        self, schema_name: str, *, new_schema_name: str
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="PATCH",
            runtime_path=f"schemas/{schema_name}",
            payload={"new_schema_name": new_schema_name},
        )

    def delete_schema(self, schema_name: str) -> dict[str, Any]:
        return self.runtime_request(
            method="DELETE",
            runtime_path=f"schemas/{schema_name}",
        )

    # ---------- Tables ----------
    def list_tables(
        self, *, updated_since: str | None = None
    ) -> list[dict[str, Any]]:
        payload = self.runtime_request(
            method="GET",
            runtime_path="tables",
            query={"updated_since": updated_since},
        )
        if isinstance(payload, list):
            return [x for x in payload if isinstance(x, dict)]
        return []

    def get_table(self, table_id: str) -> dict[str, Any]:
        return self.runtime_request(
            method="GET",
            runtime_path=f"tables/{table_id}",
        )

    def create_table(
        self,
        *,
        name: str,
        schema_name: str = "public",
        is_private: bool = False,
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="POST",
            runtime_path="tables",
            payload={
                "name": name,
                "schema_name": schema_name,
                "is_private": is_private,
            },
        )

    def update_table(self, table_id: str, *, name: str) -> dict[str, Any]:
        return self.runtime_request(
            method="PATCH",
            runtime_path=f"tables/{table_id}",
            payload={"name": name},
        )

    def delete_table(self, table_id: str) -> dict[str, Any]:
        return self.runtime_request(
            method="DELETE",
            runtime_path=f"tables/{table_id}",
        )

    def get_table_sync_status(
        self,
        table_id: str,
        *,
        if_newer_than_watermark: str | None = None,
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="GET",
            runtime_path=f"tables/{table_id}/sync-status",
            query={
                "if_newer_than_watermark": if_newer_than_watermark,
            },
        )

    def get_primary_key(self, table_id: str) -> dict[str, Any]:
        return self.runtime_request(
            method="GET",
            runtime_path=f"tables/{table_id}/primary-key",
        )

    def update_primary_key(
        self, *, table_id: str, column_id: str | None
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="PATCH",
            runtime_path=f"tables/{table_id}/primary-key",
            payload={"column_id": column_id},
        )

    # ---------- Columns ----------
    def list_columns(self, table_id: str) -> list[dict[str, Any]]:
        payload = self.runtime_request(
            method="GET",
            runtime_path=f"tables/{table_id}/columns",
        )
        if isinstance(payload, list):
            return [x for x in payload if isinstance(x, dict)]
        return []

    def create_column(
        self,
        *,
        table_id: str,
        name: str,
        column_type: str,
        config: dict[str, Any] | None = None,
        set_as_primary_key: bool = False,
    ) -> dict[str, Any]:
        created = self.runtime_request(
            method="POST",
            runtime_path=f"tables/{table_id}/columns",
            payload={
                "table_id": table_id,
                "name": name,
                "type": column_type,
                "config": config,
            },
        )
        if set_as_primary_key:
            created_column_id = str(created.get("id") or "").strip()
            if not created_column_id:
                raise TeicorSdkError(
                    "create_column response missing id; cannot set primary key"
                )
            self.update_primary_key(
                table_id=table_id,
                column_id=created_column_id,
            )
        return created

    def update_column(
        self,
        *,
        table_id: str,
        column_id: str,
        name: str | None = None,
        config: dict[str, Any] | None = None,
        set_as_primary_key: bool = False,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if config is not None:
            payload["config"] = config
        updated = self.runtime_request(
            method="PATCH",
            runtime_path=f"tables/{table_id}/columns/{column_id}",
            payload=payload,
        )
        if set_as_primary_key:
            self.update_primary_key(table_id=table_id, column_id=column_id)
        return updated

    def delete_column(
        self, *, table_id: str, column_id: str
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="DELETE",
            runtime_path=f"tables/{table_id}/columns/{column_id}",
        )

    # ---------- Records ----------
    def list_records(
        self,
        *,
        table_id: str,
        limit: int | None = None,
        offset: int | None = None,
        filter_expr: dict[str, Any] | None = None,
        sort: list[dict[str, Any]] | None = None,
        fields: list[str] | str | None = None,
        response_format: str | None = None,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        query: dict[str, Any] = {
            "limit": limit,
            "offset": offset,
            "filter": filter_expr,
            "sort": sort,
            "format": response_format,
        }
        if isinstance(fields, list):
            query["fields"] = fields
        elif isinstance(fields, str):
            query["fields"] = fields

        return self.runtime_request(
            method="GET",
            runtime_path=f"tables/{table_id}/records",
            query=query,
        )

    def find_record(
        self,
        *,
        table_id: str,
        filter_expr: dict[str, Any],
        sort: list[dict[str, Any]] | None = None,
        fields: list[str] | str | None = None,
    ) -> dict[str, Any] | None:
        payload = self.list_records(
            table_id=table_id,
            limit=1,
            offset=0,
            filter_expr=filter_expr,
            sort=sort,
            fields=fields,
            response_format="object",
        )
        if isinstance(payload, list):
            return payload[0] if payload else None
        records = payload.get("records") if isinstance(payload, dict) else None
        if isinstance(records, list) and records:
            first = records[0]
            if isinstance(first, dict):
                return first
        return None

    def create_record(
        self,
        *,
        table_id: str,
        data: dict[str, Any],
        fields: list[str] | str | None = None,
        response_format: str | None = None,
        on_conflict: str | None = None,
    ) -> dict[str, Any]:
        query: dict[str, Any] = {
            "format": response_format,
            "on_conflict": on_conflict,
        }
        if isinstance(fields, list):
            query["fields"] = fields
        elif isinstance(fields, str):
            query["fields"] = fields

        return self.runtime_request(
            method="POST",
            runtime_path=f"tables/{table_id}/records",
            payload={"data": data},
            query=query,
        )

    def update_record(
        self,
        *,
        table_id: str,
        record_id: str,
        data: dict[str, Any],
        fields: list[str] | str | None = None,
        response_format: str | None = None,
    ) -> dict[str, Any]:
        query: dict[str, Any] = {"format": response_format}
        if isinstance(fields, list):
            query["fields"] = fields
        elif isinstance(fields, str):
            query["fields"] = fields

        return self.runtime_request(
            method="PATCH",
            runtime_path=f"tables/{table_id}/records/{record_id}",
            payload={"data": data},
            query=query,
        )

    def delete_record(
        self, *, table_id: str, record_id: str
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="DELETE",
            runtime_path=f"tables/{table_id}/records/{record_id}",
        )

    def create_records_bulk(
        self,
        *,
        table_id: str,
        records: list[dict[str, Any]],
        on_conflict: str | None = None,
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="POST",
            runtime_path=f"tables/{table_id}/records/bulk",
            payload={"records": [{"data": r} for r in records]},
            query={"on_conflict": on_conflict},
        )

    def upsert_records_bulk(
        self,
        *,
        table_id: str,
        records: list[dict[str, Any]],
        conflict_policy: str = "overwrite",
    ) -> dict[str, Any]:
        """Bulk upsert convenience helper.

        This helper uses the runtime bulk-create endpoint with `on_conflict`
        semantics.

        - `overwrite` (default): update existing rows that conflict on
          primary-key uniqueness, otherwise insert.
        - `error`: fail on conflict.
        - `keep_both`: preserve existing row and insert a non-conflicting row
          when possible.
        """

        normalized_policy = str(conflict_policy or "overwrite").strip().lower()
        if normalized_policy not in ("overwrite", "error", "keep_both"):
            raise TeicorSdkError(
                "conflict_policy must be one of: overwrite, error, keep_both"
            )

        return self.create_records_bulk(
            table_id=table_id,
            records=records,
            on_conflict=normalized_policy,
        )

    def delete_records_bulk(
        self, *, table_id: str, record_ids: list[str]
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="POST",
            runtime_path=f"tables/{table_id}/records/bulk-delete",
            payload={"record_ids": record_ids},
        )

    # ---------- Queries ----------
    def list_queries(
        self,
        *,
        group_id: str | None = None,
        include_all: bool = False,
        updated_since: str | None = None,
    ) -> list[dict[str, Any]]:
        payload = self.runtime_request(
            method="GET",
            runtime_path="queries",
            query={
                "group_id": group_id,
                "all": include_all,
                "updated_since": updated_since,
            },
        )
        if isinstance(payload, list):
            return [item for item in payload if isinstance(item, dict)]
        return []

    def get_query(self, query_id: str) -> dict[str, Any]:
        return self.runtime_request(
            method="GET",
            runtime_path=f"queries/{query_id}",
        )

    def execute_query(self, query_id: str) -> dict[str, Any]:
        return self.runtime_request(
            method="POST",
            runtime_path=f"queries/{query_id}/execute",
        )

    def get_query_data(
        self,
        query_id: str,
        *,
        if_newer_than_watermark: str | None = None,
    ) -> dict[str, Any]:
        return self.runtime_request(
            method="GET",
            runtime_path=f"queries/{query_id}/data",
            query={
                "if_newer_than_watermark": if_newer_than_watermark,
            },
        )

    def sync_queries(
        self,
        *,
        state: dict[str, Any] | None = None,
        query_ids: list[str] | None = None,
        group_id: str | None = None,
        include_all: bool = True,
        persist_state: bool = False,
        on_query_result: (
            Callable[[dict[str, Any], dict[str, Any]], None] | None
        ) = None,
    ) -> QuerySyncSummary:
        current_state = dict(state or self.get_core_state())
        last_sync_at_raw = current_state.get("last_sync_at")
        last_sync_at = (
            str(last_sync_at_raw).strip()
            if isinstance(last_sync_at_raw, str)
            else ""
        )
        updated_since = last_sync_at or None

        raw_query_watermarks = current_state.get("query_watermarks")
        query_watermarks = (
            dict(raw_query_watermarks)
            if isinstance(raw_query_watermarks, dict)
            else {}
        )

        changed_queries = self.list_queries(
            group_id=group_id,
            include_all=include_all,
            updated_since=updated_since,
        )
        if query_ids:
            allowed_query_ids = {str(value) for value in query_ids if value}
            changed_queries = [
                query
                for query in changed_queries
                if str(query.get("id") or "") in allowed_query_ids
            ]

        latest_updated_at = last_sync_at or None
        checked_count = 0
        changed_count = 0
        for query in changed_queries:
            query_id_value = query.get("id")
            if not query_id_value:
                continue
            query_id = str(query_id_value)
            previous_watermark = query_watermarks.get(query_id)

            result = self.get_query_data(
                query_id,
                if_newer_than_watermark=(
                    str(previous_watermark)
                    if isinstance(previous_watermark, str)
                    else None
                ),
            )
            checked_count += 1
            if result.get("unchanged") is not True:
                changed_count += 1

            source_watermark = result.get("source_watermark")
            if isinstance(source_watermark, str) and source_watermark:
                query_watermarks[query_id] = source_watermark

            if on_query_result is not None:
                on_query_result(query, result)

            updated_at = query.get("updated_at")
            if (
                isinstance(updated_at, str)
                and updated_at
                and (
                    latest_updated_at is None or updated_at > latest_updated_at
                )
            ):
                latest_updated_at = updated_at

        state_patch = {
            "last_sync_at": latest_updated_at,
            "query_watermarks": query_watermarks,
        }
        if persist_state:
            self.patch_core_state(state_patch)

        return QuerySyncSummary(
            first_sync=(updated_since is None),
            changed_query_count=len(changed_queries),
            checked_query_data_count=checked_count,
            queries_with_data_changes=changed_count,
            state_patch=state_patch,
        )

    def sync_tables(
        self,
        *,
        state: dict[str, Any] | None = None,
        table_ids: list[str] | None = None,
        records_page_size: int = 200,
        persist_state: bool = False,
        on_table_records: (
            Callable[[dict[str, Any], list[dict[str, Any]]], None] | None
        ) = None,
    ) -> TableSyncSummary:
        if records_page_size < 1:
            raise TeicorSdkError("records_page_size must be >= 1")

        current_state = dict(state or self.get_core_state())
        last_sync_at_raw = current_state.get("tables_last_sync_at")
        tables_last_sync_at = (
            str(last_sync_at_raw).strip()
            if isinstance(last_sync_at_raw, str)
            else ""
        )
        updated_since = tables_last_sync_at or None

        raw_table_watermarks = current_state.get("table_watermarks")
        table_watermarks = (
            dict(raw_table_watermarks)
            if isinstance(raw_table_watermarks, dict)
            else {}
        )

        changed_tables = self.list_tables(updated_since=updated_since)
        if table_ids:
            allowed_table_ids = {str(value) for value in table_ids if value}
            changed_tables = [
                table
                for table in changed_tables
                if str(table.get("id") or "") in allowed_table_ids
            ]

        latest_updated_at = tables_last_sync_at or None
        checked_status_count = 0
        synced_table_count = 0
        total_records_synced = 0

        for table in changed_tables:
            table_id_value = table.get("id")
            if not table_id_value:
                continue
            table_id = str(table_id_value)

            previous_watermark = table_watermarks.get(table_id)
            status = self.get_table_sync_status(
                table_id,
                if_newer_than_watermark=(
                    str(previous_watermark)
                    if isinstance(previous_watermark, str)
                    else None
                ),
            )
            checked_status_count += 1

            source_watermark = status.get("source_watermark")
            if isinstance(source_watermark, str) and source_watermark:
                table_watermarks[table_id] = source_watermark

            if bool(status.get("has_changes")):
                synced_table_count += 1
                offset = 0
                while True:
                    page = self.list_records(
                        table_id=table_id,
                        limit=records_page_size,
                        offset=offset,
                    )
                    records: list[dict[str, Any]]
                    if isinstance(page, list):
                        records = [x for x in page if isinstance(x, dict)]
                    elif isinstance(page, dict):
                        maybe = page.get("records")
                        if isinstance(maybe, list):
                            records = [x for x in maybe if isinstance(x, dict)]
                        else:
                            records = []
                    else:
                        records = []

                    if on_table_records is not None and records:
                        on_table_records(table, records)

                    batch_size = len(records)
                    total_records_synced += batch_size
                    if batch_size < records_page_size:
                        break
                    offset += batch_size

            updated_at = table.get("updated_at")
            if (
                isinstance(updated_at, str)
                and updated_at
                and (
                    latest_updated_at is None or updated_at > latest_updated_at
                )
            ):
                latest_updated_at = updated_at

        state_patch = {
            "tables_last_sync_at": latest_updated_at,
            "table_watermarks": table_watermarks,
        }
        if persist_state:
            self.patch_core_state(state_patch)

        return TableSyncSummary(
            first_sync=(updated_since is None),
            changed_table_count=len(changed_tables),
            checked_table_status_count=checked_status_count,
            tables_with_data_changes=synced_table_count,
            records_synced=total_records_synced,
            state_patch=state_patch,
        )
