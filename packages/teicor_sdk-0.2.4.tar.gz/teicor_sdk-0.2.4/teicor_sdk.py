"""Legacy single-file compatibility shim.

Prefer installing the package from PyPI:
    teicor-sdk
"""

from __future__ import annotations

from pathlib import Path
import runpy


_CLIENT_PATH = (
    Path(__file__).resolve().parent / "src" / "teicor_sdk" / "client.py"
)
_exports = runpy.run_path(str(_CLIENT_PATH))

TeicorApiError = _exports["TeicorApiError"]
TeicorContext = _exports["TeicorContext"]
QuerySyncSummary = _exports["QuerySyncSummary"]
TableSyncSummary = _exports["TableSyncSummary"]
TeicorClient = _exports["TeicorClient"]
TeicorSdkError = _exports["TeicorSdkError"]
