from dataclasses import dataclass
from typing import Optional


@dataclass
class LogEntry:
    timestamp: str
    caller: str
    workspace: str
    module: str
    operation: str
    ok: bool = True
    item_id: Optional[str] = None
    item_title: Optional[str] = None
    args: Optional[dict] = None

    def to_dict(self) -> dict:
        d: dict = {
            "timestamp": self.timestamp,
            "caller": self.caller,
            "workspace": self.workspace,
            "module": self.module,
            "operation": self.operation,
            "ok": self.ok,
        }
        if self.item_id is not None:
            d["item_id"] = self.item_id
        if self.item_title is not None:
            d["item_title"] = self.item_title
        if self.args:
            d["args"] = self.args
        return d

    def matches(self, query: str) -> bool:
        """Case-insensitive substring match across searchable fields."""
        q = query.lower()
        return any(
            q in (field or "").lower()
            for field in [
                self.item_title,
                self.item_id,
                self.module,
                self.operation,
                self.caller,
                self.workspace,
            ]
        )

    @classmethod
    def from_dict(cls, d: dict) -> "LogEntry":
        return cls(
            timestamp=d.get("timestamp", ""),
            caller=d.get("caller", ""),
            workspace=d.get("workspace", ""),
            module=d.get("module", ""),
            operation=d.get("operation", ""),
            ok=d.get("ok", True),
            item_id=d.get("item_id"),
            item_title=d.get("item_title"),
            args=d.get("args"),
        )
