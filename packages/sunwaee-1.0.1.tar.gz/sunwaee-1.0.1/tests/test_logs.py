import json
from datetime import datetime, timezone
from pathlib import Path

import pytest

from sunwaee.cli import app
from sunwaee.modules.logs.model import LogEntry
from .conftest import ok, err


# ---------------------------------------------------------------------------
# LogEntry model
# ---------------------------------------------------------------------------

def test_log_entry_to_dict_full():
    e = LogEntry(
        timestamp="2026-03-02T10:00:00+00:00",
        caller="api",
        workspace="personal",
        module="notes",
        operation="create",
        ok=True,
        item_id="abc-123",
        item_title="My Note",
    )
    d = e.to_dict()
    assert d["timestamp"] == "2026-03-02T10:00:00+00:00"
    assert d["caller"] == "api"
    assert d["workspace"] == "personal"
    assert d["module"] == "notes"
    assert d["operation"] == "create"
    assert d["ok"] is True
    assert d["item_id"] == "abc-123"
    assert d["item_title"] == "My Note"


def test_log_entry_to_dict_omits_none_optionals():
    e = LogEntry(
        timestamp="2026-03-02T10:00:00+00:00",
        caller="human",
        workspace="personal",
        module="tasks",
        operation="delete",
    )
    d = e.to_dict()
    assert "item_id" not in d
    assert "item_title" not in d


def test_log_entry_from_dict_roundtrip():
    original = LogEntry(
        timestamp="2026-03-02T10:00:00+00:00",
        caller="sun",
        workspace="work",
        module="tasks",
        operation="complete",
        ok=True,
        item_id="xyz-789",
        item_title="Finish docs",
    )
    restored = LogEntry.from_dict(original.to_dict())
    assert restored.timestamp == original.timestamp
    assert restored.caller == original.caller
    assert restored.workspace == original.workspace
    assert restored.module == original.module
    assert restored.operation == original.operation
    assert restored.ok == original.ok
    assert restored.item_id == original.item_id
    assert restored.item_title == original.item_title


def test_log_entry_from_dict_missing_fields_use_defaults():
    e = LogEntry.from_dict({})
    assert e.timestamp == ""
    assert e.caller == ""
    assert e.ok is True
    assert e.item_id is None
    assert e.item_title is None


def test_log_entry_matches_item_title():
    e = LogEntry("ts", "human", "personal", "notes", "create", item_title="My Important Note")
    assert e.matches("important")
    assert e.matches("IMPORTANT")
    assert not e.matches("task")


def test_log_entry_matches_item_id():
    e = LogEntry("ts", "human", "personal", "notes", "create", item_id="abc-123-def")
    assert e.matches("abc-123")
    assert not e.matches("xyz")


def test_log_entry_matches_module():
    e = LogEntry("ts", "human", "personal", "tasks", "create")
    assert e.matches("tasks")
    assert not e.matches("notes")


def test_log_entry_matches_operation():
    e = LogEntry("ts", "human", "personal", "notes", "delete")
    assert e.matches("delete")
    assert not e.matches("create")


def test_log_entry_matches_caller():
    e = LogEntry("ts", "api", "personal", "notes", "create")
    assert e.matches("api")
    assert not e.matches("sun")


def test_log_entry_matches_workspace():
    e = LogEntry("ts", "human", "work", "notes", "create")
    assert e.matches("work")
    assert not e.matches("personal")


def test_log_entry_no_match():
    e = LogEntry("ts", "human", "personal", "notes", "create", item_title="My Note")
    assert not e.matches("zzznomatch")


def test_log_entry_args_in_dict():
    e = LogEntry("ts", "api", "personal", "notes", "list", args={"results": 5, "query": "python"})
    d = e.to_dict()
    assert d["args"] == {"results": 5, "query": "python"}


def test_log_entry_empty_args_omitted():
    e = LogEntry("ts", "api", "personal", "notes", "list", args={})
    assert "args" not in e.to_dict()


def test_log_entry_args_restored_from_dict():
    e = LogEntry.from_dict({"timestamp": "ts", "caller": "api", "workspace": "w",
                            "module": "notes", "operation": "list",
                            "args": {"results": 3}})
    assert e.args == {"results": 3}


# ---------------------------------------------------------------------------
# Audit integration: commands write log entries
# ---------------------------------------------------------------------------

def _today_logs_dir(tmp_path: Path, workspace: str = "personal") -> Path:
    now = datetime.now(timezone.utc)
    return (
        tmp_path / "workspaces" / workspace / "logs"
        / str(now.year)
        / f"{now.month:02d}"
        / f"{now.day:02d}"
    )


def _read_today_entries(tmp_path: Path, workspace: str = "personal") -> list[dict]:
    log_file = _today_logs_dir(tmp_path, workspace) / "logs.jsonl"
    if not log_file.exists():
        return []
    return [json.loads(line) for line in log_file.read_text().splitlines() if line.strip()]


def test_note_create_writes_log(runner, ws, env):
    runner.invoke(app, ["note", "create", "--title", "Logged Note", "--body", "x", "--workspace", "personal"])
    entries = _read_today_entries(env)
    assert any(e["module"] == "notes" and e["operation"] == "create" and e["item_title"] == "Logged Note" for e in entries)


def test_note_edit_writes_log(runner, ws, env):
    runner.invoke(app, ["note", "create", "--title", "Edit me", "--body", "x", "--workspace", "personal"])
    runner.invoke(app, ["note", "edit", "Edit me", "--body", "updated", "--workspace", "personal"])
    entries = _read_today_entries(env)
    assert any(e["module"] == "notes" and e["operation"] == "edit" for e in entries)


def test_note_delete_writes_log(runner, ws, env):
    runner.invoke(app, ["note", "create", "--title", "Delete me", "--body", "x", "--workspace", "personal"])
    runner.invoke(app, ["note", "delete", "Delete me", "--confirm", "--workspace", "personal"])
    entries = _read_today_entries(env)
    assert any(e["module"] == "notes" and e["operation"] == "delete" and e["item_title"] == "Delete me" for e in entries)


def test_task_create_writes_log(runner, ws, env):
    runner.invoke(app, ["task", "create", "--title", "My Task", "--workspace", "personal"])
    entries = _read_today_entries(env)
    assert any(e["module"] == "tasks" and e["operation"] == "create" and e["item_title"] == "My Task" for e in entries)


def test_task_edit_writes_log(runner, ws, env):
    runner.invoke(app, ["task", "create", "--title", "Edit task", "--workspace", "personal"])
    runner.invoke(app, ["task", "edit", "Edit task", "--title", "Edited task", "--workspace", "personal"])
    entries = _read_today_entries(env)
    assert any(e["module"] == "tasks" and e["operation"] == "edit" for e in entries)


def test_task_complete_writes_log(runner, ws, env):
    runner.invoke(app, ["task", "create", "--title", "Complete me", "--workspace", "personal"])
    runner.invoke(app, ["task", "complete", "Complete me", "--workspace", "personal"])
    entries = _read_today_entries(env)
    assert any(e["module"] == "tasks" and e["operation"] == "complete" and e["item_title"] == "Complete me" for e in entries)


def test_task_uncomplete_writes_log(runner, ws, env):
    runner.invoke(app, ["task", "create", "--title", "Reset me", "--workspace", "personal"])
    runner.invoke(app, ["task", "complete", "Reset me", "--workspace", "personal"])
    runner.invoke(app, ["task", "uncomplete", "Reset me", "--workspace", "personal"])
    entries = _read_today_entries(env)
    assert any(e["module"] == "tasks" and e["operation"] == "uncomplete" for e in entries)


def test_task_delete_writes_log(runner, ws, env):
    runner.invoke(app, ["task", "create", "--title", "Drop me", "--workspace", "personal"])
    runner.invoke(app, ["task", "delete", "Drop me", "--confirm", "--workspace", "personal"])
    entries = _read_today_entries(env)
    assert any(e["module"] == "tasks" and e["operation"] == "delete" and e["item_title"] == "Drop me" for e in entries)


def test_workspace_create_writes_log(runner, env):
    runner.invoke(app, ["workspace", "create", "newws"])
    entries = _read_today_entries(env, workspace="newws")
    assert any(e["module"] == "workspaces" and e["operation"] == "create" for e in entries)


def test_workspace_set_default_writes_log(runner, ws, env):
    runner.invoke(app, ["workspace", "set-default", "personal"])
    entries = _read_today_entries(env)
    assert any(e["module"] == "workspaces" and e["operation"] == "set-default" for e in entries)


def test_workspace_delete_writes_log(runner, ws, env):
    runner.invoke(app, ["workspace", "create", "todelete"])
    runner.invoke(app, ["workspace", "delete", "todelete", "--confirm"])
    # log was written before rmtree, file is gone — check personal ws which still exists
    # the log was written to todelete/logs, which is now deleted; verify no crash occurred
    result = runner.invoke(app, ["workspace", "list"])
    assert result.exit_code == 0


def test_note_list_writes_log(runner, ws, env):
    runner.invoke(app, ["note", "list", "--workspace", "personal"])
    entries = _read_today_entries(env)
    assert any(e["module"] == "notes" and e["operation"] == "list" for e in entries)


def test_note_list_log_stores_args(runner, ws, env):
    runner.invoke(app, ["note", "create", "--title", "X", "--workspace", "personal"])
    runner.invoke(app, ["note", "list", "--query", "x", "--workspace", "personal"])
    entries = _read_today_entries(env)
    list_entry = next(e for e in entries if e["module"] == "notes" and e["operation"] == "list")
    assert list_entry["args"]["query"] == "x"
    assert "results" in list_entry["args"]


def test_task_list_writes_log(runner, ws, env):
    runner.invoke(app, ["task", "list", "--workspace", "personal"])
    entries = _read_today_entries(env)
    assert any(e["module"] == "tasks" and e["operation"] == "list" for e in entries)


def test_task_list_log_stores_args(runner, ws, env):
    runner.invoke(app, ["task", "create", "--title", "T", "--workspace", "personal"])
    runner.invoke(app, ["task", "list", "--status", "todo", "--workspace", "personal"])
    entries = _read_today_entries(env)
    list_entry = next(e for e in entries if e["module"] == "tasks" and e["operation"] == "list")
    assert list_entry["args"]["status"] == "todo"
    assert "results" in list_entry["args"]


def test_log_list_writes_log(runner, ws, env):
    runner.invoke(app, ["log", "list", "--workspace", "personal"])
    entries = _read_today_entries(env)
    assert any(e["module"] == "logs" and e["operation"] == "list" for e in entries)


def test_log_list_log_stores_args(runner, ws, env):
    runner.invoke(app, ["log", "list", "--module", "notes", "--workspace", "personal"])
    entries = _read_today_entries(env)
    list_entry = next(e for e in entries if e["module"] == "logs" and e["operation"] == "list")
    assert list_entry["args"]["module"] == "notes"
    assert "results" in list_entry["args"]


def test_log_entry_has_caller_field(runner, ws, env):
    runner.invoke(app, ["note", "create", "--title", "Caller check", "--body", "x", "--workspace", "personal"])
    entries = _read_today_entries(env)
    matching = [e for e in entries if e.get("item_title") == "Caller check"]
    assert matching
    assert matching[0]["caller"] == "api"


# ---------------------------------------------------------------------------
# log list
# ---------------------------------------------------------------------------

def test_log_list_empty(runner, env):
    # no workspace created, no logs written — must return empty
    data = ok(runner.invoke(app, ["log", "list", "--workspace", "personal"]))
    assert data == []


def test_log_list_returns_todays_entries(runner, ws):
    runner.invoke(app, ["note", "create", "--title", "Listed", "--body", "x", "--workspace", "personal"])
    data = ok(runner.invoke(app, ["log", "list", "--workspace", "personal"]))
    assert any(e["item_title"] == "Listed" for e in data)


def test_log_list_entry_fields(runner, ws):
    runner.invoke(app, ["note", "create", "--title", "Fields check", "--body", "x", "--workspace", "personal"])
    data = ok(runner.invoke(app, ["log", "list", "--workspace", "personal"]))
    entry = next(e for e in data if e.get("item_title") == "Fields check")
    assert "timestamp" in entry
    assert "caller" in entry
    assert "module" in entry
    assert "operation" in entry
    assert "ok" in entry


def test_log_list_filter_by_module(runner, ws):
    runner.invoke(app, ["note", "create", "--title", "A note", "--body", "x", "--workspace", "personal"])
    runner.invoke(app, ["task", "create", "--title", "A task", "--workspace", "personal"])
    data = ok(runner.invoke(app, ["log", "list", "--workspace", "personal", "--module", "notes"]))
    assert all(e["module"] == "notes" for e in data)


def test_log_list_filter_by_operation(runner, ws):
    runner.invoke(app, ["note", "create", "--title", "Op filter", "--body", "x", "--workspace", "personal"])
    runner.invoke(app, ["note", "edit", "Op filter", "--body", "new", "--workspace", "personal"])
    data = ok(runner.invoke(app, ["log", "list", "--workspace", "personal", "--operation", "create"]))
    assert all(e["operation"] == "create" for e in data)


def test_log_list_filter_by_caller(runner, ws):
    runner.invoke(app, ["note", "create", "--title", "Caller filter", "--body", "x", "--workspace", "personal"])
    data = ok(runner.invoke(app, ["log", "list", "--workspace", "personal", "--caller", "api"]))
    assert all(e["caller"] == "api" for e in data)


def test_log_list_with_date_today(runner, ws):
    runner.invoke(app, ["note", "create", "--title", "Date filter", "--body", "x", "--workspace", "personal"])
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    data = ok(runner.invoke(app, ["log", "list", "--workspace", "personal", "--date", today]))
    assert any(e.get("item_title") == "Date filter" for e in data)


def test_log_list_with_date_no_entries(runner, ws):
    data = ok(runner.invoke(app, ["log", "list", "--workspace", "personal", "--date", "2000-01-01"]))
    assert data == []


def test_log_list_with_month(runner, ws):
    runner.invoke(app, ["note", "create", "--title", "Month filter", "--body", "x", "--workspace", "personal"])
    month = datetime.now(timezone.utc).strftime("%Y-%m")
    data = ok(runner.invoke(app, ["log", "list", "--workspace", "personal", "--month", month]))
    assert any(e.get("item_title") == "Month filter" for e in data)


def test_log_list_with_all(runner, ws):
    runner.invoke(app, ["note", "create", "--title", "All logs", "--body", "x", "--workspace", "personal"])
    data = ok(runner.invoke(app, ["log", "list", "--workspace", "personal", "--all"]))
    assert any(e.get("item_title") == "All logs" for e in data)


def test_log_list_limit(runner, ws):
    for i in range(5):
        runner.invoke(app, ["note", "create", "--title", f"Note {i}", "--body", "x", "--workspace", "personal"])
    data = ok(runner.invoke(app, ["log", "list", "--workspace", "personal", "--limit", "2"]))
    assert len(data) <= 2


def test_log_list_sorted_newest_first(runner, ws):
    runner.invoke(app, ["note", "create", "--title", "First", "--body", "x", "--workspace", "personal"])
    runner.invoke(app, ["note", "create", "--title", "Second", "--body", "x", "--workspace", "personal"])
    data = ok(runner.invoke(app, ["log", "list", "--workspace", "personal"]))
    timestamps = [e["timestamp"] for e in data]
    assert timestamps == sorted(timestamps, reverse=True)


def test_log_list_multiple_date_flags_error(runner, ws):
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    month = datetime.now(timezone.utc).strftime("%Y-%m")
    e = err(runner.invoke(app, ["log", "list", "--date", today, "--month", month, "--workspace", "personal"]))
    assert e["code"] == "VALIDATION_ERROR"


def test_log_list_invalid_date_format(runner, ws):
    e = err(runner.invoke(app, ["log", "list", "--date", "not-a-date", "--workspace", "personal"]))
    assert e["code"] == "VALIDATION_ERROR"


def test_log_list_invalid_month_format(runner, ws):
    e = err(runner.invoke(app, ["log", "list", "--month", "2026/03", "--workspace", "personal"]))
    assert e["code"] == "VALIDATION_ERROR"


def test_log_list_all_workspaces(runner, ws):
    runner.invoke(app, ["note", "create", "--title", "WS log", "--body", "x", "--workspace", "personal"])
    data = ok(runner.invoke(app, ["log", "list"]))
    assert any(e.get("item_title") == "WS log" for e in data)
    assert all("workspace" in e for e in data)


def test_log_list_query_by_item_title(runner, ws):
    runner.invoke(app, ["note", "create", "--title", "Queryable Note", "--body", "x", "--workspace", "personal"])
    runner.invoke(app, ["task", "create", "--title", "Unrelated Task", "--workspace", "personal"])
    data = ok(runner.invoke(app, ["log", "list", "--query", "queryable", "--workspace", "personal"]))
    assert len(data) >= 1
    assert all("queryable" in (e.get("item_title") or "").lower() for e in data)


def test_log_list_query_by_module(runner, ws):
    runner.invoke(app, ["note", "create", "--title", "A note", "--body", "x", "--workspace", "personal"])
    runner.invoke(app, ["task", "create", "--title", "A task", "--workspace", "personal"])
    data = ok(runner.invoke(app, ["log", "list", "--query", "notes", "--workspace", "personal"]))
    assert all(e["module"] == "notes" for e in data)


def test_log_list_query_no_match(runner, ws):
    runner.invoke(app, ["note", "create", "--title", "Something", "--body", "x", "--workspace", "personal"])
    data = ok(runner.invoke(app, ["log", "list", "--query", "zzznomatch", "--workspace", "personal"]))
    assert data == []
