from sklearn.model_selection import train_test_split
import pandas as pd
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from sklearn.preprocessing import LabelEncoder
import numpy as np
import os
from . import feature_selection as fs

def one_hot_encode(data, column):
    """
    Performs one hot encoding on a given column in the dataset
    
    Parameters:
    
    * data (pandas DataFrame): dataframe containing data
    
    * column (str): name of column to one hot encode
    
    Returns:
    
    * encoded (pandas DataFrame): dataframe with column one hot encoded
    """
    encoded = data.copy()
    categories = list(data[column].unique()) #obtain list of categories present
    for category in categories: #loop through each category
        encoded[f'categorical_{category}'] = (data[column] == category).astype(int) #create a column where all values in the column equal to the category are stored as 1
    encoded.drop(columns=[column], inplace=True) #drop the categorical column
    return encoded


def encode_categorical(data, positive=None, negative=None):
    """
    Encodes categorical values
    
    Parameters:
    
    * data (pandas DataFrame): dataframe containing data
    
    * positive (str): name of positive class
    
    * negative (str): name of negative class
    
    Returns:
    
    * encoded (pandas DataFrame): dataframe with categorical columns encoded
    """
    encoded = data.copy()
    object_columns = data.select_dtypes(include='object').columns.tolist()  #obtain list of columns with string values
    for column in object_columns: #loop through each column
        if "target" in column and positive is not None and negative is not None: #map positive and negative class to 0 in target column
            encoded[column] = encoded[column].map({positive: 1, negative: 0})
        elif "target" in column and positive is not None:
            encoded[column] = encoded[column].map({positive: 1}).fillna(0) #map positive class to 1 and all other values to 0 in target column
        elif len(encoded[column].unique()) == 2: #use label encoder if only 2 categories
            label_encoder = LabelEncoder()
            encoded[f'categorical_{column}'] = label_encoder.fit_transform(data[column])
            encoded = encoded.drop(columns=[column]) #drop the original column
        else: #otherwise, one hot encode the column
            encoded = one_hot_encode(encoded, column)
    return encoded

def format_survival(data, survival_time, survival_status, survival_censor):
    """
    Formats survival data for analysis

    Parameters:
    
    * data (pandas DataFrame): dataframe with data
    
    * survival_time (str): column name containing survival times
    
    * survival_status (str): column name containing survival status

    * survival_censor (str): column name containing censorship status

    Returns:
    
    * formatted (pandas DataFrame): dataframe containing formatted survival data
    """
    formatted = data.copy()
    

    formatted['target_survival_status'] = np.where(data[survival_censor] != 'Not Available', 0, 1)
    formatted['target_survival'] = np.where(data[survival_censor] == 'Not Available',
                                        data[survival_time], data[survival_censor])
    formatted['target_survival'] = pd.to_numeric(formatted['target_survival'], errors='coerce')
    formatted['target_survival'] = formatted['target_survival']/100
    formatted.drop(columns=[survival_time, survival_status, survival_censor], inplace=True)
    return formatted

def survival_to_binary(data, time_threshold=None, quantile_threshold=None, filename="survival_threshold.txt"):
    """
    Converts survival data to binary classification based on time or quantile threshold

    Parameters:
    
    * data (pandas DataFrame): dataframe with survival data
    
    * time_threshold (float): time threshold for classification
    
    * quantile_threshold (float): quantile threshold for classification
    
    * filename (str): filename to save threshold information

    Returns:
    
    * binary_data (pandas DataFrame): dataframe containing binary survival data
    """
    binary_data = data.copy()

    if time_threshold is not None:
        threshold = time_threshold
    elif quantile_threshold is not None:
        threshold = binary_data['target_survival'].quantile(quantile_threshold)
    else:
        raise ValueError("Either time_threshold or quantile_threshold must be provided.")
    # Drop censored observations where target_survival is less than the threshold
    binary_data = binary_data[~((binary_data['target_survival_status'] == 0) & (binary_data['target_survival'] < threshold))]
    binary_data['target_survival_binary'] = (binary_data['target_survival'] <= threshold).astype(int)
    with open('survival_threshold.txt', 'w') as f:
        f.write(f"Survival threshold used for binary classification: {threshold*100} days.\n")
        if quantile_threshold is not None:
            f.write(f"This corresponds to the {quantile_threshold*100}th percentile of survival times.\n")
            f.write("This quantile threshold was used to define the survival cutoff.\n")
        else:
            f.write(f"The time threshold was used to define the survival cutoff.\n")
            f.write(f'This corresponds to the {np.mean(binary_data["target_survival"] <= threshold)*100}th percentile of survival times.\n')
    return binary_data

def format_columns(data, plot_directory, filter=False, filename="prefix_code_mapping.txt"):
    """
    Formats column names to use a code rather than a long string
    
    Parameters:
    
    * data (pandas DataFrame): dataframe containing data
    
    * plot_directory (str): directory to save plots
    
    * filter (Boolean): set to True if images have been filtered before feature extraction
    
    * filename (str): filename to save codes to
    
    Returns:
    
    * data (pandas DataFrame): dataframe containing data

    Output:
    
    * text file explaining the name of the codes
    """
    if not os.path.isdir(plot_directory):
    # if the directory is not present then create it
        os.makedirs(plot_directory)
    os.chdir(plot_directory)
    # Extract original column names
    # data = data.iloc[:, :10]
    original_columns = data.columns

    # Dictionary to store prefix to code mapping
    prefix_to_code = {}
    transformed_columns = []
    scan_codes = {}
    filter_codes = {}
    segmentation_codes = {}
    
    # Generate short codes and transform column names
    for i, col in enumerate(original_columns):
        
        if 'target' in col:
            transformed_columns.append(col)
            continue
        if 'clinical' in col:
            if 'categorical' in col:
                transformed_columns.append(col[21:])
            else:
                transformed_columns.append(col[9:])
            continue
        full_code = ""
        parts = col.split('_')   
        scan = parts[0]
        # scans.add(scan)
        if filter:
            prefix = '_'.join(parts[:3])
            filter_name = parts[1]
            segmentation_label = parts[2]
            feature_name = '_'.join(parts[4:])
        else:
            prefix = '_'.join(parts[:2])
            segmentation_label = parts[1]
            feature_name = '_'.join(parts[3:])
        
        if filter:
            elements = [scan, filter_name, segmentation_label]
            code_dictionaries = [scan_codes, filter_codes, segmentation_codes]
        else:
            elements = [scan, segmentation_label]
            code_dictionaries = [scan_codes, segmentation_codes]
        for element, code_dictionary in zip(elements, code_dictionaries):
            code, code_dictionary = update_code_dictionaries(element,code_dictionary)
            full_code += code
        transformed_columns.append(f"{full_code}_{feature_name}")
    # # Update DataFrame column names
    data.columns = transformed_columns
    # # Save the mapping to a text file
    with open(filename, "w") as f:
        f.write("First number is scan type.\n")
        if filter:
            headings = ["Scan Type:\n", "Filter:\n", "Segmentation Label:\n"]
            f.write("Second number is filter.\n")
            
        else:
            headings = ["Scan Type:\n", "Segmentation Label:\n"]
        f.write("Last number(s) is segmentation label specified in nifti segmentation file.\n")
        f.write("\n")
        for heading, code_dictionary in zip(headings, code_dictionaries):
            if heading == "Segmentation Label:\n":
                continue
            f.write(heading)            
            for prefix, code in code_dictionary.items():
                f.write(f"{code}: {prefix}\n")
            f.write("\n")
    os.chdir("..")
    return data

def rename_categorical_columns(data):
    """
    Renames categorical columns to have 'categorical_' prefix

    Parameters:
    data (pandas DataFrame): dataframe containing data

    Returns:
    data (pandas DataFrame): dataframe with renamed categorical columns
    """
    for col in data.columns:
        if data[col].dtype in ['object', 'category'] and 'target' not in col:
            data = data.rename(columns={col: f'categorical_{col}'})
    return data

def update_code_dictionaries(element,code_dictionary):
    """
   Updates dictionaries containing code values for each element
    
    Parameters:
    
    * element (str): element
    
    * code_dictionary (dict): dictionary of code values for each element
    
    Returns:
    
    * code (str): a number corresponding to the element
    
    * code_dictionary (dict): updated code dictionary
    """
    if element not in code_dictionary: #update code dictionary if element is missing
        try: #convert element to integer if it is numerical, otherwise number the element according to how many elements are in the dictionary already
            element_num = int(element)
        except ValueError:
            element_num = len(code_dictionary)
        
        code_dictionary[element] = f"{element_num:02d}"
    else: #otherwise get the code for given element
        element_num = code_dictionary[element]
    code = code_dictionary[element]
    return code, code_dictionary

def prepare_splits(target, X, y, test_size=0.2, random_state=42, biological_covariates = None, stratify=False, smote=False):
    """
    Prepare train and test data set
    
    Parameters:  
    
    * target (str): name of target column
    
    * X (pandas DataFrame): features
    
    * y (pandas Series): target
    
    * test_size (float): proportion of data reserved for testing
    
    * random_state (int): random state for train test split
    
    * biological_covariates (list): list of column headings for biological correlates
    
    * stratify (bool): If True, stratify by target variable and specified biological correlates

    * smote (bool): If True, perform SMOTE

    Returns:

    * X_train (pandas DataFrame): training features
    
    * X_test (pandas DataFrame): testing features
    
    * y_train (pandas Series): training target
    
    * y_test (pandas Series): testing target
    """
    if biological_covariates is None and stratify:
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=random_state, stratify=y)
    elif biological_covariates is not None and stratify:
        stratify_columns = biological_covariates + [target]
        data = pd.concat([X, y], axis=1)
        stratify_labels = data[stratify_columns].astype(str).agg('_'.join, axis=1)
        X_train, X_test, y_train, y_test = train_test_split(data, y, test_size=test_size, random_state=random_state, stratify=stratify_labels)
        X_train = X_train.drop(target, axis=1)
        X_test = X_test.drop(target, axis=1)
    elif not stratify:
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=random_state)
    if smote:
        X_train = X_train.drop(columns=['ID'])
        X_resampled, y_train = SMOTE(random_state=random_state).fit_resample(X_train, y_train)
        X_train = pd.DataFrame(X_resampled, columns=X_train.columns)
    return X_train, X_test, y_train, y_test

def prepare_train_test(data, target, test_size=0.2, train_id=None, test_id=None, random_state=42, biological_covariates = None, stratify=False, smote=False):
    """
    Prepare train and test data set
    
    Parameters:  
    
    * data (pandas DataFrame): features + target
    
    * target_name (str): name of target column
    
    * test_size (float): proportion of data reserved for testing
    
    * train_id (list or array): list of IDs selected for previous training set
    
    * test_id (list or array): list of IDs selected for previous testing set
    
    * random_state (int): random state for train test split
    
    * biological_covariates (list): list of column headings for biological correlates
    
    * stratify (bool): If True, stratify by target variable and specified biological correlates

    * smote (bool): If True, perform SMOTE

    Returns:
    
    * X_train (pandas DataFrame): training features
    
    * X_test (pandas DataFrame): testing features
    
    * y_train (pandas Series): training target

    * y_test (pandas Series): testing target
    """
    X = data.drop(columns=target, axis=1)
    y = data.loc[:, target]
    if train_id is not None and test_id is not None:
        X_train = X[X['ID'].isin(train_id)].copy()
        X_test = X[X['ID'].isin(test_id)].copy()
        y_train = y[y.index.isin(X_train.index)].copy()
        y_test = y[y.index.isin(X_test.index)].copy()
        X_remaining = X[~(X['ID'].isin(train_id) | X['ID'].isin(test_id))]
        y_remaining = y[y.index.isin(X_remaining.index)]
        if not X_remaining.empty:
            X_train_extra, X_test_extra, y_train_extra, y_test_extra = prepare_splits(target, X_remaining, y_remaining, test_size=test_size, random_state=random_state, biological_covariates = biological_covariates, stratify=stratify, smote=smote)
            X_train = pd.concat([X_train, X_train_extra], ignore_index=True)
            X_test = pd.concat([X_test, X_test_extra], ignore_index=True)
            y_train = pd.concat([y_train, y_train_extra], ignore_index=True)
            y_test = pd.concat([y_test, y_test_extra], ignore_index=True)
    else:
        X_train, X_test, y_train, y_test = prepare_splits(target, X, y, test_size=test_size, random_state=random_state, biological_covariates = biological_covariates, stratify=stratify, smote=smote)
    return X_train, X_test, y_train, y_test

def normalise_data(X_train, X_test):
    """
    Normalises data with scaler fitted to X_train
    
    Parameters:  
    
    * X_train (pandas DataFrame): training features

    * X_test (pandas DataFrame): testing features

    Returns:
    
    * X_train (pandas DataFrame): normalised training features

    * X_test (pandas DataFrame): normalised testing features
    """
    scaler = StandardScaler()
    if 'ID' in X_train.columns:
        X_train_scaled = X_train.drop(columns=['ID'])
        X_test_scaled = X_test.drop(columns=['ID'])
    else:
        X_train_scaled = X_train.copy()
        X_test_scaled = X_test.copy()
    X_train_scaled = scaler.fit_transform(X_train_scaled) 
    X_test_scaled = scaler.transform(X_test_scaled)
    X_train_scaled = pd.DataFrame(X_train_scaled, columns=[col for col in X_train.columns if col != 'ID'], index=X_train.index)
    X_test_scaled = pd.DataFrame(X_test_scaled, columns=[col for col in X_test.columns if col != 'ID'], index=X_test.index)
    if 'ID' in X_train.columns:
        X_train_scaled['ID'] = X_train['ID']
        X_test_scaled['ID'] = X_test['ID']
    unnormalise_categorical(X_train_scaled, X_test_scaled)
    return X_train_scaled, X_test_scaled

def unnormalise_categorical(X_train, X_test):
    """
    Unnormalises categorical columns, ie fixes them back to be 0 and 1
    
    Parameters:  
    
    * X_train (pandas DataFrame): training features

    * X_test (pandas DataFrame): testing features

    Returns:
    
    * X_train (pandas DataFrame): fixed training features

    * X_test (pandas DataFrame): fixed testing features
    """
    for col in X_train.columns:
        if 'categorical' in col:
            train_data = list(X_train[col])
            test_data = list(X_test[col])
            train_data = [1 if item == max(train_data) else 0 for item in train_data]
            test_data = [1 if item == max(test_data) else 0 for item in test_data]
            X_train[col] = train_data
            X_test[col] = test_data
    return X_train, X_test

def combine_dataframes(dataframes_list):
    """
    Prepare train and test data set
    
    Parameters:  

    * dataframes_list (list): list of dataframes

    Returns:
    
    * combined_df (pandas DataFrame): combined data
    """
    appended_df_list = [] #initialise list of dfs with patient_id and segmentation
    for i, X in enumerate(dataframes_list):
        X = X.reset_index(drop=True)
        X = pd.concat([X, pd.DataFrame({
            'patient_id': range(1, len(X) + 1),
            'segmentation': [i + 1] * len(X)
        })], axis=1)
        appended_df_list.append(X)

    # Combine the dataframes
    combined_df = pd.concat(appended_df_list)
    # Sort to alternate rows by patient and segmentation
    combined_df.sort_values(by=['patient_id', 'segmentation'], inplace=True)
    return combined_df


def prepare_data(feature_file_path, filter=True, positive=None, negative=None):
    """
    Prepares data 
    
    Parameters:
    
    * feature_file_path (str): File path name for feature file

    * filter (bool): If True, filters are applied

    * positive (str): Name of positive class. Defaults to None

    * negative (str): Name of negative class. Defaults to None

    Returns:

    * data_encoded (pandas DataFrame): DataFrame of features
    """
    data = pd.read_csv(feature_file_path)
    data_encoded = data.drop(columns=['ID'])
    data_encoded = data_encoded.dropna()
    data_encoded = format_columns(data_encoded, ".\\exploratory_plots", filter=filter) #format columns to have shorter column name
    data_encoded = encode_categorical(data_encoded, positive=positive, negative=negative) #formats categorical columns
    data_encoded = fs.remove_constant_columns(data_encoded)
    data_encoded['ID'] = data['ID']
    return data_encoded