import yaml
from setuptools import setup

with open('requirements.yaml', 'r') as f:
    reqs = yaml.safe_load(f)['dependencies']

setup(
    name='RadiomicsModellingSuite',
    version='1.0',
    packages=['RadiomicsModellingSuite'],
    install_requires=reqs,
)