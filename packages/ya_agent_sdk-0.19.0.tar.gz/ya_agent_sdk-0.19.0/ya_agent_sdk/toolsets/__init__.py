"""Toolsets for ya-agent-sdk.

This module provides:
- BaseTool: Abstract base class for individual tools
- BaseToolset: Abstract base class for toolsets with instruction support
- Toolset: Container for tools with hooks and HITL support
- InstructableToolset: Protocol for toolsets that provide instructions
- BrowserUseToolset: Browser automation via Chrome DevTools Protocol
"""

from ya_agent_sdk.toolsets.base import (
    BaseTool,
    BaseToolset,
    InstructableToolset,
    Instruction,
    UserInputPreprocessResult,
    resolve_instruction,
    resolve_instructions,
)
from ya_agent_sdk.toolsets.browser_use import BrowserUseSettings, BrowserUseToolset
from ya_agent_sdk.toolsets.core.base import (
    CallMetadata,
    GlobalHooks,
    GlobalPostHookFunc,
    GlobalPreHookFunc,
    HookableToolsetTool,
    PostHookFunc,
    PreHookFunc,
    Toolset,
    UserInteraction,
)

__all__ = [
    "BaseTool",
    "BaseToolset",
    "BrowserUseSettings",
    "BrowserUseToolset",
    "CallMetadata",
    "GlobalHooks",
    "GlobalPostHookFunc",
    "GlobalPreHookFunc",
    "HookableToolsetTool",
    "InstructableToolset",
    "Instruction",
    "PostHookFunc",
    "PreHookFunc",
    "Toolset",
    "UserInputPreprocessResult",
    "UserInteraction",
    "resolve_instruction",
    "resolve_instructions",
]
