"""MCP server for Gemini CUA agent.

This folder is named 'mcp_server' instead of 'mcp' to avoid shadowing the 'mcp' package.
"""

