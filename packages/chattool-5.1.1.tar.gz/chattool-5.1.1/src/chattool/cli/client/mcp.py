import click
import sys
from chattool.mcp.server import mcp

@click.group()
def cli():
    """MCP Server Management Tools."""
    pass

@cli.command(context_settings={"ignore_unknown_options": True})
@click.option("--transport", "-t", default="stdio", type=click.Choice(["stdio", "http"]), help="Transport mode: stdio (default) or http")
@click.option("--host", default="127.0.0.1", help="Host for HTTP server")
@click.option("--port", default=8000, help="Port for HTTP server")
def start(transport, host, port):
    """Run the MCP server directly.
    
    Examples:
    
        chattool mcp start                   # Run with stdio (default)
        chattool mcp start --transport http  # Run with HTTP on localhost:8000
    """
    if mcp is None:
        click.echo("Error: MCP server is not available. Please install 'fastmcp' (requires Python >= 3.10).", err=True)
        sys.exit(1)
    mcp.run(transport=transport, host=host, port=port)

@cli.command()
def info():
    """Inspect the MCP server capabilities."""
    if mcp is None:
        click.echo("Error: MCP server is not available. Please install 'fastmcp' (requires Python >= 3.10).", err=True)
        sys.exit(1)

    # Since we can't import fastmcp.cli.inspect easily, we'll just print basic info from our instance
    click.echo(f"MCP Server: {mcp.name}")
    click.echo("\nTools:")
    # Better approach: Just print the static list since we defined it in server.py
    tools = [
        "dns_list_domains", "dns_get_records", "dns_add_record", 
        "dns_delete_record", "dns_ddns_update", "dns_cert_update"
    ]
    for t in tools:
        click.echo(f"  - {t}")
