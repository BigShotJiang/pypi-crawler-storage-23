from .main import cli as main_cli

__all__ = [
    "main_cli",
]
