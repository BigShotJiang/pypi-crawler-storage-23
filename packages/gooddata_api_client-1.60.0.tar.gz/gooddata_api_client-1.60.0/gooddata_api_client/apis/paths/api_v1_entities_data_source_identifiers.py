from gooddata_api_client.paths.api_v1_entities_data_source_identifiers.get import ApiForget


class ApiV1EntitiesDataSourceIdentifiers(
    ApiForget,
):
    pass
