from gooddata_api_client.paths.api_v1_entities_themes.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_themes.post import ApiForpost


class ApiV1EntitiesThemes(
    ApiForget,
    ApiForpost,
):
    pass
