from gooddata_api_client.paths.api_v1_layout_data_sources_data_source_id_physical_model.get import ApiForget
from gooddata_api_client.paths.api_v1_layout_data_sources_data_source_id_physical_model.put import ApiForput


class ApiV1LayoutDataSourcesDataSourceIdPhysicalModel(
    ApiForget,
    ApiForput,
):
    pass
