from gooddata_api_client.paths.api_v1_layout_users_user_id_permissions.get import ApiForget
from gooddata_api_client.paths.api_v1_layout_users_user_id_permissions.put import ApiForput


class ApiV1LayoutUsersUserIdPermissions(
    ApiForget,
    ApiForput,
):
    pass
