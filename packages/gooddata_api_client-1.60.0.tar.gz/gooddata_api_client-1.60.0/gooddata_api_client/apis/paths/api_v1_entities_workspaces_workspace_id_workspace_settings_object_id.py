from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_workspace_settings_object_id.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_workspace_settings_object_id.put import ApiForput
from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_workspace_settings_object_id.delete import ApiFordelete
from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_workspace_settings_object_id.patch import ApiForpatch


class ApiV1EntitiesWorkspacesWorkspaceIdWorkspaceSettingsObjectId(
    ApiForget,
    ApiForput,
    ApiFordelete,
    ApiForpatch,
):
    pass
