from gooddata_api_client.paths.api_v1_layout_workspaces.get import ApiForget
from gooddata_api_client.paths.api_v1_layout_workspaces.put import ApiForput


class ApiV1LayoutWorkspaces(
    ApiForget,
    ApiForput,
):
    pass
