from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_filter_contexts_object_id.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_filter_contexts_object_id.put import ApiForput
from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_filter_contexts_object_id.delete import ApiFordelete
from gooddata_api_client.paths.api_v1_entities_workspaces_workspace_id_filter_contexts_object_id.patch import ApiForpatch


class ApiV1EntitiesWorkspacesWorkspaceIdFilterContextsObjectId(
    ApiForget,
    ApiForput,
    ApiFordelete,
    ApiForpatch,
):
    pass
