from gooddata_api_client.paths.api_v1_actions_data_sources_data_source_id_scan.post import ApiForpost


class ApiV1ActionsDataSourcesDataSourceIdScan(
    ApiForpost,
):
    pass
