from gooddata_api_client.paths.api_v1_entities_workspaces.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_workspaces.post import ApiForpost


class ApiV1EntitiesWorkspaces(
    ApiForget,
    ApiForpost,
):
    pass
