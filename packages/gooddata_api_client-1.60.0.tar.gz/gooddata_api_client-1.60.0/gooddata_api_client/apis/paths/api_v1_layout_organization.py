from gooddata_api_client.paths.api_v1_layout_organization.get import ApiForget
from gooddata_api_client.paths.api_v1_layout_organization.put import ApiForput


class ApiV1LayoutOrganization(
    ApiForget,
    ApiForput,
):
    pass
