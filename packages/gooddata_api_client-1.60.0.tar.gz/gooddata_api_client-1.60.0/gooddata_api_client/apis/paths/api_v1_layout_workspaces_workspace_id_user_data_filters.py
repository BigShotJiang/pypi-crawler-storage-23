from gooddata_api_client.paths.api_v1_layout_workspaces_workspace_id_user_data_filters.get import ApiForget
from gooddata_api_client.paths.api_v1_layout_workspaces_workspace_id_user_data_filters.put import ApiForput


class ApiV1LayoutWorkspacesWorkspaceIdUserDataFilters(
    ApiForget,
    ApiForput,
):
    pass
