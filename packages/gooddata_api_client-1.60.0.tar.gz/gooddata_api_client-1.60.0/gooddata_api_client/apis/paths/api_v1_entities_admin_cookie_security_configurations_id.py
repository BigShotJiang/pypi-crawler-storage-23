from gooddata_api_client.paths.api_v1_entities_admin_cookie_security_configurations_id.get import ApiForget
from gooddata_api_client.paths.api_v1_entities_admin_cookie_security_configurations_id.put import ApiForput
from gooddata_api_client.paths.api_v1_entities_admin_cookie_security_configurations_id.patch import ApiForpatch


class ApiV1EntitiesAdminCookieSecurityConfigurationsId(
    ApiForget,
    ApiForput,
    ApiForpatch,
):
    pass
