import csv
import io
import random
import string
import time
import boto3
from datetime import datetime
from botocore.config import Config

__version__ = '0.1.0'


class aurora_to_rs:
    """Lean Aurora PostgreSQL -> S3 -> Redshift loader using psycopg2 copy_expert.

    Sample:
        loader = aurora_to_rs(
            region_name='ap-south-1', s3_bucket='my-bucket',
            redshift_c=redshift_conn, postgres_engine=pg_engine,
            iam_role_arn='arn:aws:iam::123456:role/MY_ROLE'
        )
        loader.delete_and_insert('SELECT * FROM tran.alloc_au WHERE dt>=current_date-1',
                                 'tran.alloc_au', "dt>=current_date-1")
    """

    def __init__(self, region_name, s3_bucket, redshift_c, postgres_engine,
                 iam_role_arn=None, aws_access_key_id=None, aws_secret_access_key=None):
        self.region_name = region_name
        self.s3_bucket = s3_bucket
        self.redshift_c = redshift_c
        self.postgres_engine = postgres_engine
        self.iam_role_arn = iam_role_arn
        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key

        boto_config = Config(
            region_name=region_name,
            retries={'max_attempts': 10, 'mode': 'adaptive'},
            max_pool_connections=100, connect_timeout=60, read_timeout=300
        )
        if aws_access_key_id and aws_secret_access_key:
            self.s3 = boto3.resource('s3', region_name=region_name,
                                     aws_access_key_id=aws_access_key_id,
                                     aws_secret_access_key=aws_secret_access_key,
                                     config=boto_config)
        else:
            self.s3 = boto3.resource('s3', region_name=region_name, config=boto_config)

    # ✦✦ Internal: timestamp helper ✦✦ #
    def _ts(self):
        return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    # ✦✦ Internal: credentials fragment for COPY command ✦✦ #
    def _credentials(self):
        if self.aws_access_key_id and self.aws_secret_access_key:
            return f"ACCESS_KEY_ID '{self.aws_access_key_id}' SECRET_ACCESS_KEY '{self.aws_secret_access_key}'"
        if self.iam_role_arn:
            return f"IAM_ROLE '{self.iam_role_arn}'"
        raise ValueError("Either AWS credentials or IAM role ARN required")

    # ✦✦ Internal: S3 upload with retry ✦✦ #
    def _s3_put(self, key, body):
        for attempt in range(5):
            try:
                self.s3.Object(self.s3_bucket, key).put(Body=body)
                return
            except Exception as e:
                if attempt < 4 and any(err in str(e) for err in ['SSL', 'EOF', 'Connection']):
                    print(f"[{self._ts()}] S3 retry {attempt+1}/5: {str(e)[:100]}")
                    time.sleep(2 ** attempt)
                    continue
                raise

    # ✦✦ Internal: S3 cleanup ✦✦ #
    def _s3_delete(self, key):
        try:
            self.s3.Object(self.s3_bucket, key).delete()
        except Exception:
            pass

    # ✦✦ Step 1: Stream from Aurora to S3 via copy_expert ✦✦ #
    def _stream_to_s3(self, source_sql, label=''):
        """COPY from Aurora -> BytesIO -> S3. Returns (s3_key, columns_csv, row_count)."""
        t0 = time.time()
        print(f"[{self._ts()}] [{label}] Streaming from Aurora...")

        raw_conn = self.postgres_engine.raw_connection()
        raw_cur = raw_conn.cursor()
        buf = io.BytesIO()
        raw_cur.copy_expert(f"COPY ({source_sql}) TO STDOUT WITH CSV HEADER NULL 'NULL'", buf)
        raw_cur.close()
        raw_conn.close()
        buf.seek(0)

        size_mb = len(buf.getvalue()) / (1024 * 1024)
        print(f"[{self._ts()}] [{label}] {size_mb:.1f} MB streamed in {int(time.time()-t0)}s")

        if buf.getvalue().strip() == b'':
            return None, None, 0

        header_line = buf.readline().decode('utf-8').strip()
        header_cols = next(csv.reader([header_line]))
        columns = ','.join(c.replace('/', '_').replace('.', '_').replace('-', '_') for c in header_cols)
        row_count = buf.getvalue().count(b'\n') - 1
        buf.seek(0)

        s3_key = ''.join(random.choices(string.ascii_letters + string.digits, k=12)) + '.csv'
        self._s3_put(s3_key, buf.getvalue())
        print(f"[{self._ts()}] [{label}] S3 upload done in {int(time.time()-t0)}s ({row_count:,} rows)")
        return s3_key, columns, row_count

    # ✦✦ Step 2: Redshift COPY from S3 ✦✦ #
    def _redshift_copy(self, dest, s3_key, columns):
        """COPY from S3 into Redshift table."""
        copy_sql = f"""
            COPY {dest} ({columns})
            FROM 's3://{self.s3_bucket}/{s3_key}'
            {self._credentials()}
            CSV IGNOREHEADER 1 NULL AS 'NULL' REGION '{self.region_name}';
        """
        self.redshift_c.cursor().execute(copy_sql)

    # ✦✦ Public: copy_expert_upload ✦✦ #
    def copy_expert_upload(self, source_sql, dest):
        """Stream Aurora -> S3 -> Redshift COPY. Returns row_count.

        Sample:
            rows = loader.copy_expert_upload(
                "SELECT * FROM tran.alloc_au WHERE dt >= current_date-1",
                "tran.alloc_au"
            )
        """
        s3_key = None
        try:
            t0 = time.time()
            s3_key, columns, row_count = self._stream_to_s3(source_sql, label=dest)
            if row_count == 0:
                print(f"[{self._ts()}] [{dest}] Empty result, nothing to load")
                return 0
            self._redshift_copy(dest, s3_key, columns)
            print(f"[{self._ts()}] [{dest}] COPY done. Total={int(time.time()-t0)}s, Rows={row_count:,}")
            return row_count
        except Exception as e:
            print(f"[{self._ts()}] [{dest}] copy_expert_upload error: {e}")
            raise
        finally:
            if s3_key:
                self._s3_delete(s3_key)

    # ✦✦ Public: delete_and_insert ✦✦ #
    def delete_and_insert(self, source_sql, dest_table, filter_cond,
                          min_timestamp=None, timestamp_col=None):
        """DELETE matching rows from Redshift, then COPY new data from Aurora.

        Sample:
            loader.delete_and_insert(
                "SELECT * FROM tran.shipment_au WHERE create_datetime >= current_date-3",
                "tran.shipment_au", "create_datetime >= current_date-3",
                min_timestamp='2026-02-19 00:00:00', timestamp_col='create_datetime'
            )
        """
        s3_key = None
        cursor = self.redshift_c.cursor()
        try:
            s3_key, columns, row_count = self._stream_to_s3(source_sql, label=dest_table)

            cursor.execute("BEGIN;")
            cursor.execute(f"DELETE FROM {dest_table} WHERE {filter_cond};")
            print(f"[{self._ts()}] [{dest_table}] Deleted by filter_cond")

            if min_timestamp is not None and timestamp_col is not None:
                cursor.execute(f"DELETE FROM {dest_table} WHERE {timestamp_col} >= '{min_timestamp}';")
                print(f"[{self._ts()}] [{dest_table}] Deleted by min_timestamp={min_timestamp}")

            if row_count > 0:
                self._redshift_copy(dest_table, s3_key, columns)

            cursor.execute("COMMIT;")
            print(f"[{self._ts()}] [{dest_table}] delete_and_insert done ({row_count:,} rows)")
            return row_count
        except Exception as e:
            cursor.execute("ROLLBACK;")
            print(f"[{self._ts()}] [{dest_table}] delete_and_insert error: {e}")
            raise
        finally:
            cursor.close()
            if s3_key:
                self._s3_delete(s3_key)

    # ✦✦ Public: upsert (truncate+load or staging-based) ✦✦ #
    def upsert(self, source_sql, dest_table, upsert_columns, clear_dest_table=False):
        """Upsert Aurora data into Redshift via copy_expert.

        clear_dest_table=True  -> TRUNCATE + COPY (fast full refresh)
        clear_dest_table=False -> COPY to staging -> DELETE+INSERT (incremental upsert)

        NULL-safe: uses (col=col OR (col IS NULL AND col IS NULL)) for key matching.

        Sample:
            loader.upsert("SELECT * FROM master.mrp_au", "master.mrp_au",
                          ['item', 'loc'], clear_dest_table=True)
        """
        s3_key = None
        staging = dest_table + '_stgg'
        cursor = self.redshift_c.cursor()
        try:
            s3_key, columns, row_count = self._stream_to_s3(source_sql, label=dest_table)

            if clear_dest_table:
                cursor.execute("BEGIN;")
                cursor.execute(f"TRUNCATE TABLE {dest_table};")
                print(f"[{self._ts()}] [{dest_table}] Truncated")
                if row_count > 0:
                    self._redshift_copy(dest_table, s3_key, columns)
                cursor.execute("COMMIT;")
                print(f"[{self._ts()}] [{dest_table}] upsert (truncate) done ({row_count:,} rows)")
            else:
                # Load into staging, then atomic delete+insert
                cursor.execute(f"DROP TABLE IF EXISTS {staging}; CREATE TABLE {staging} AS SELECT * FROM {dest_table} WHERE 1=0;")
                if row_count > 0:
                    self._redshift_copy(staging, s3_key, columns)

                where_parts = []
                for col in upsert_columns:
                    c = col.replace('"', '')
                    where_parts.append(f"({dest_table}.{c} = {staging}.{c} OR ({dest_table}.{c} IS NULL AND {staging}.{c} IS NULL))")

                cursor.execute("BEGIN;")
                if row_count > 0:
                    cursor.execute(f"DELETE FROM {dest_table} USING {staging} WHERE {' AND '.join(where_parts)};")
                    cursor.execute(f"INSERT INTO {dest_table} SELECT * FROM {staging};")
                cursor.execute("COMMIT;")
                print(f"[{self._ts()}] [{dest_table}] upsert (staging) done ({row_count:,} rows)")

            return row_count
        except Exception as e:
            cursor.execute("ROLLBACK;")
            print(f"[{self._ts()}] [{dest_table}] upsert error: {e}")
            raise
        finally:
            try:
                cursor.execute(f"DROP TABLE IF EXISTS {staging};")
            except Exception:
                pass
            if s3_key:
                self._s3_delete(s3_key)
