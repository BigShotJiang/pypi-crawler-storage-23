import typing

TtsProvider = typing.Union[typing.Literal["vertex", "baseten"], typing.Any]
