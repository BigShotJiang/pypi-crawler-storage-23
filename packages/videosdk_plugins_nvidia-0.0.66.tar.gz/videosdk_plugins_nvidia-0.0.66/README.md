# VideoSDK Nvidia Plugin

Agent Framework plugin for STT and TTS services from Nvidia.

## Installation

```bash
pip install videosdk-plugins-nvidia
```