"""
Schwab SDK - Market Data Module
Handles all market data endpoints.
"""

from typing import Optional, Dict, Any, List, Union

from .enums import (
    ContractType, Strategy, StrikeRange, ExpirationMonth, OptionType,
    Entitlement, PeriodType, FrequencyType, QuoteField, MoverIndex,
    MoverSort, MoverFrequency, MarketID, Projection,
)
from ._utils import coerce_enum, normalize_date, to_epoch_millis
from .exceptions import raise_for_schwab_status


class Market:
    """
    Module for market data endpoints (sync).

    Includes:
    - Quotes (single and multiple)
    - Option Chains
    - Price History
    - Movers
    - Market Hours
    - Instruments
    """

    def __init__(self, client):
        """
        Initializes the Market module.

        Args:
            client: Instance of the main client
        """
        self.client = client
        self.base_url = client.market_base_url

    # ===== QUOTES =====

    def get_quotes(
        self,
        symbols: Union[str, List[str]],
        fields: Union[str, List[str], None] = None,
        indicative: Optional[bool] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Retrieves quotes for multiple symbols.

        GET /quotes?symbols=...

        Args:
            symbols: Single symbol (str) or list of symbols (List[str]).
                     Example: "AAPL" or ["AAPL", "BAC", "$SPX", "/ESH23", "EUR/USD"]
            fields: Optional list of field groups to return. Available values:
                    "quote", "fundamental", "extended", "reference", "regular", "all".
                    Default: all (full response).
            indicative: Include indicative symbol quotes for ETFs (e.g., $ABC.IV).
            params: Additional query parameters

        Returns:
            JSON response with quotes for the requested symbols
        """
        endpoint = f"{self.base_url}/quotes"
        query_params = _build_quotes_params(symbols, fields, indicative, params)
        response = self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    def get_quote(
        self,
        symbol: str,
        fields: Union[str, List[str], None] = None,
        indicative: Optional[bool] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Retrieves a quote for a specific symbol.

        GET /{symbol_id}/quotes

        Args:
            symbol: Instrument symbol (e.g., "AAPL")
            fields: Optional list of field groups to return. Available values:
                    "quote", "fundamental", "extended", "reference", "regular", "all".
                    Default: all (full response).
            indicative: Include indicative symbol quotes for ETFs (e.g., $ABC.IV).
            params: Additional query parameters

        Returns:
            JSON response with the quote for the specific symbol
        """
        endpoint = f"{self.base_url}/{symbol}/quotes"
        query_params = _build_quote_params(fields, indicative, params)
        response = self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    # ===== OPTION CHAINS =====

    def get_option_chain(
        self,
        symbol: str,
        contract_type: Optional[str] = None,
        strike_count: Optional[int] = None,
        include_underlying_quote: Optional[bool] = None,
        strategy: Optional[str] = None,
        interval: Optional[float] = None,
        strike: Optional[float] = None,
        range_type: Optional[str] = None,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        volatility: Optional[float] = None,
        underlying_price: Optional[float] = None,
        interest_rate: Optional[float] = None,
        days_to_expiration: Optional[int] = None,
        exp_month: Optional[str] = None,
        option_type: Optional[str] = None,
        entitlement: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Retrieves an option chain for a symbol.

        GET /chains

        Args:
            symbol: Underlying asset symbol (required)
            contract_type: Contract Type. Available values: CALL, PUT, ALL
            strike_count: The Number of strikes to return above or below the at-the-money price
            include_underlying_quote: Underlying quotes to be included (boolean)
            strategy: OptionChain strategy. Default is SINGLE. Available values: SINGLE, ANALYTICAL, COVERED, VERTICAL, CALENDAR, STRANGLE, STRADDLE, BUTTERFLY, CONDOR, DIAGONAL, COLLAR, ROLL
            interval: Strike interval for spread strategy chains (see strategy param)
            strike: Strike Price
            range_type: Range(ITM/NTM/OTM etc.)
            from_date: From date (pattern: yyyy-MM-dd)
            to_date: To date (pattern: yyyy-MM-dd)
            volatility: Volatility to use in calculations. Applies only to ANALYTICAL strategy chains
            underlying_price: Underlying price to use in calculations. Applies only to ANALYTICAL strategy chains
            interest_rate: Interest rate to use in calculations. Applies only to ANALYTICAL strategy chains
            days_to_expiration: Days to expiration to use in calculations. Applies only to ANALYTICAL strategy chains
            exp_month: Expiration month. Available values: JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC, ALL
            option_type: Option Type
            entitlement: Applicable only if its retail token, entitlement of client PP-PayingPro, NP-NonPro and PN-NonPayingPro. Available values: PN, NP, PP
            params: Additional query parameters

        Returns:
            JSON response with the option chain
        """
        endpoint = f"{self.base_url}/chains"
        query_params = _build_option_chain_params(
            symbol, contract_type, strike_count, include_underlying_quote,
            strategy, interval, strike, range_type, from_date, to_date,
            volatility, underlying_price, interest_rate, days_to_expiration,
            exp_month, option_type, entitlement, params,
        )
        response = self.client._request("GET", endpoint, params=query_params, timeout=15)
        raise_for_schwab_status(response)
        return response.json()

    def get_expiration_chain(self, symbol: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Retrieves the option expiration chain for a symbol.

        GET /expirationchain

        Args:
            symbol: Underlying asset symbol

        Returns:
            JSON response with option expiration dates
        """
        endpoint = f"{self.base_url}/expirationchain"
        query_params = {"symbol": symbol}
        if params:
            query_params.update(params)
        response = self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    # ===== PRICE HISTORY =====

    def get_price_history(
        self,
        symbol: str,
        periodType: str = "month",
        period: int = 1,
        frequencyType: str = "daily",
        frequency: int = 1,
        startDate: Union[int, str, None] = None,
        endDate: Union[int, str, None] = None,
        need_extended_hours_data: Optional[bool] = None,
        need_previous_close: Optional[bool] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Retrieves price history for a symbol.

        GET /pricehistory

        Args:
            symbol: Instrument symbol
            periodType: Period type (day, month, year, ytd)
            period: Number of periods
            frequencyType: Frequency type (minute, daily, weekly, monthly)
            frequency: Specific frequency
            startDate: Start date — epoch millis (int), datetime, date, or "YYYY-MM-DD" string
            endDate: End date — epoch millis (int), datetime, date, or "YYYY-MM-DD" string
            need_extended_hours_data: If True, return extended hours data. Default is True.
            need_previous_close: If True, return the previous close price and date.
            params: Additional query parameters

        Returns:
            JSON response with price history (candles)
        """
        endpoint = f"{self.base_url}/pricehistory"
        query_params = _build_price_history_params(
            symbol, periodType, period, frequencyType, frequency,
            startDate, endDate, need_extended_hours_data, need_previous_close, params,
        )
        response = self.client._request("GET", endpoint, params=query_params, timeout=15)
        raise_for_schwab_status(response)
        return response.json()

    # ===== MOVERS =====

    def get_movers(self, symbol_id: str, sort: Optional[str] = None, frequency: Optional[int] = None, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Retrieves movers for a specific index.

        GET /movers/{symbol_id}

        Args:
            symbol_id: Index Symbol (required). Available values: $DJI, $COMPX, $SPX,
                       NYSE, NASDAQ, OTCBB, INDEX_ALL, EQUITY_ALL, OPTION_ALL,
                       OPTION_PUT, OPTION_CALL
            sort: Sort by a particular attribute. Available values:
                  VOLUME, TRADES, PERCENT_CHANGE_UP, PERCENT_CHANGE_DOWN
            frequency: Frequency in minutes. Available values: 0, 1, 5, 10, 30, 60.
                       Default: 0 (real-time snapshot)
            params: Additional query parameters

        Returns:
            JSON response with top 10 movers (screeners) for the index
        """
        validated_id = coerce_enum(symbol_id, MoverIndex, "symbol_id")
        endpoint = f"{self.base_url}/movers/{validated_id}"
        query_params = _build_movers_params(sort, frequency, params)
        response = self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    # ===== MARKET HOURS =====

    def get_markets(
        self,
        markets: Optional[List[str]] = None,
        date: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Retrieves hours for different markets.

        GET /markets

        Args:
            markets: List of market IDs to query. Available values:
                     "equity", "option", "bond", "future", "forex".
                     If None, returns hours for all markets.
            date: Date for which to return market hours (YYYY-MM-DD).
                  Accepts values up to one year from today.
            params: Additional query parameters

        Returns:
            JSON response with hours for the specified markets
        """
        endpoint = f"{self.base_url}/markets"
        query_params: Dict[str, Any] = dict(params or {})

        if markets:
            validated = [coerce_enum(m, MarketID, "markets") for m in markets]
            query_params["markets"] = ",".join(validated)

        effective_date = date or query_params.get("date")
        if effective_date:
            query_params["date"] = normalize_date(effective_date, mode="date_only")

        response = self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    def get_market_hours(
        self,
        market_id: str,
        date: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Retrieves hours for a specific market.

        GET /markets/{market_id}

        Args:
            market_id: Market ID. Available values: equity, option, bond, future, forex
            date: Date for which to return market hours (YYYY-MM-DD).
                  Valid range: today to 1 year from today. Defaults to current day.
            params: Additional query parameters

        Returns:
            JSON response with hours for the specific market
        """
        market_id = coerce_enum(market_id, MarketID, "market_id")
        endpoint = f"{self.base_url}/markets/{market_id}"
        query_params: Dict[str, Any] = dict(params or {})
        effective_date = date or query_params.get("date")
        if effective_date:
            query_params["date"] = normalize_date(effective_date, mode="date_only")

        response = self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    # ===== INSTRUMENTS =====

    def get_instruments(
        self,
        symbols: Union[str, List[str]],
        projection: str = "symbol-search",
        extra_params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Retrieves instruments by symbols and projection.

        GET /instruments

        Args:
            symbols: Single symbol or list of symbols
            projection: Search type. Available values: symbol-search, symbol-regex,
                        desc-search, desc-regex, search, fundamental.
                        Default: symbol-search
            extra_params: Additional query parameters

        Returns:
            JSON response with instrument information
        """
        endpoint = f"{self.base_url}/instruments"
        query_params = _build_instruments_params(symbols, projection, extra_params)
        response = self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    def get_instrument_by_cusip(self, cusip_id: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Retrieves an instrument by specific CUSIP.

        GET /instruments/{cusip_id}

        Args:
            cusip_id: Instrument CUSIP

        Returns:
            JSON response with the specific instrument information
        """
        endpoint = f"{self.base_url}/instruments/{cusip_id}"
        response = self.client._request("GET", endpoint, params=params or {}, timeout=10)
        raise_for_schwab_status(response)
        return response.json()


# ---------------------------------------------------------------------------
# Async variant
# ---------------------------------------------------------------------------

class AsyncMarket:
    """
    Module for market data endpoints (async).
    """

    def __init__(self, client):
        self.client = client
        self.base_url = client.market_base_url

    async def get_quotes(
        self,
        symbols: Union[str, List[str]],
        fields: Union[str, List[str], None] = None,
        indicative: Optional[bool] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/quotes"
        query_params = _build_quotes_params(symbols, fields, indicative, params)
        response = await self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    async def get_quote(
        self,
        symbol: str,
        fields: Union[str, List[str], None] = None,
        indicative: Optional[bool] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/{symbol}/quotes"
        query_params = _build_quote_params(fields, indicative, params)
        response = await self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    async def get_option_chain(
        self,
        symbol: str,
        contract_type: Optional[str] = None,
        strike_count: Optional[int] = None,
        include_underlying_quote: Optional[bool] = None,
        strategy: Optional[str] = None,
        interval: Optional[float] = None,
        strike: Optional[float] = None,
        range_type: Optional[str] = None,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        volatility: Optional[float] = None,
        underlying_price: Optional[float] = None,
        interest_rate: Optional[float] = None,
        days_to_expiration: Optional[int] = None,
        exp_month: Optional[str] = None,
        option_type: Optional[str] = None,
        entitlement: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/chains"
        query_params = _build_option_chain_params(
            symbol, contract_type, strike_count, include_underlying_quote,
            strategy, interval, strike, range_type, from_date, to_date,
            volatility, underlying_price, interest_rate, days_to_expiration,
            exp_month, option_type, entitlement, params,
        )
        response = await self.client._request("GET", endpoint, params=query_params, timeout=15)
        raise_for_schwab_status(response)
        return response.json()

    async def get_expiration_chain(self, symbol: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/expirationchain"
        query_params = {"symbol": symbol}
        if params:
            query_params.update(params)
        response = await self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    async def get_price_history(
        self,
        symbol: str,
        periodType: str = "month",
        period: int = 1,
        frequencyType: str = "daily",
        frequency: int = 1,
        startDate: Union[int, str, None] = None,
        endDate: Union[int, str, None] = None,
        need_extended_hours_data: Optional[bool] = None,
        need_previous_close: Optional[bool] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/pricehistory"
        query_params = _build_price_history_params(
            symbol, periodType, period, frequencyType, frequency,
            startDate, endDate, need_extended_hours_data, need_previous_close, params,
        )
        response = await self.client._request("GET", endpoint, params=query_params, timeout=15)
        raise_for_schwab_status(response)
        return response.json()

    async def get_movers(self, symbol_id: str, sort: Optional[str] = None, frequency: Optional[int] = None, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        validated_id = coerce_enum(symbol_id, MoverIndex, "symbol_id")
        endpoint = f"{self.base_url}/movers/{validated_id}"
        query_params = _build_movers_params(sort, frequency, params)
        response = await self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    async def get_markets(
        self,
        markets: Optional[List[str]] = None,
        date: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/markets"
        query_params: Dict[str, Any] = dict(params or {})
        if markets:
            validated = [coerce_enum(m, MarketID, "markets") for m in markets]
            query_params["markets"] = ",".join(validated)
        effective_date = date or query_params.get("date")
        if effective_date:
            query_params["date"] = normalize_date(effective_date, mode="date_only")
        response = await self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    async def get_market_hours(
        self,
        market_id: str,
        date: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        market_id = coerce_enum(market_id, MarketID, "market_id")
        endpoint = f"{self.base_url}/markets/{market_id}"
        query_params: Dict[str, Any] = dict(params or {})
        effective_date = date or query_params.get("date")
        if effective_date:
            query_params["date"] = normalize_date(effective_date, mode="date_only")
        response = await self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    async def get_instruments(
        self,
        symbols: Union[str, List[str]],
        projection: str = "symbol-search",
        extra_params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/instruments"
        query_params = _build_instruments_params(symbols, projection, extra_params)
        response = await self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    async def get_instrument_by_cusip(self, cusip_id: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/instruments/{cusip_id}"
        response = await self.client._request("GET", endpoint, params=params or {}, timeout=10)
        raise_for_schwab_status(response)
        return response.json()


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _validate_fields(fields: Union[str, List[str], None]) -> Optional[str]:
    """Validate and normalize the fields parameter. Accepts str or list."""
    if not fields:
        return None
    if isinstance(fields, str):
        # "quote,fundamental" or "quote"
        items = [f.strip() for f in fields.split(",") if f.strip()]
    else:
        items = list(fields)
    validated = [coerce_enum(f, QuoteField, "fields") for f in items]
    return ",".join(validated)


def _build_quotes_params(
    symbols: Union[str, List[str]],
    fields: Union[str, List[str], None],
    indicative: Optional[bool],
    params: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    if isinstance(symbols, list):
        symbol_string = ",".join(symbols)
    else:
        symbol_string = symbols
    query_params: Dict[str, Any] = {"symbols": symbol_string}
    validated_fields = _validate_fields(fields)
    if validated_fields:
        query_params["fields"] = validated_fields
    if indicative is not None:
        query_params["indicative"] = str(indicative).lower()
    if params:
        query_params.update(params)
    return query_params


def _build_quote_params(
    fields: Union[str, List[str], None],
    indicative: Optional[bool],
    params: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    query_params: Dict[str, Any] = {}
    validated_fields = _validate_fields(fields)
    if validated_fields:
        query_params["fields"] = validated_fields
    if indicative is not None:
        query_params["indicative"] = str(indicative).lower()
    if params:
        query_params.update(params)
    return query_params


def _build_movers_params(
    sort: Optional[str],
    frequency: Optional[int],
    params: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    query_params: Dict[str, Any] = {}
    if sort:
        query_params['sort'] = coerce_enum(sort, MoverSort, "sort")
    if frequency is not None:
        query_params['frequency'] = int(coerce_enum(frequency, MoverFrequency, "frequency"))
    if params:
        query_params.update(params)
    return query_params


def _build_option_chain_params(
    symbol, contract_type, strike_count, include_underlying_quote,
    strategy, interval, strike, range_type, from_date, to_date,
    volatility, underlying_price, interest_rate, days_to_expiration,
    exp_month, option_type, entitlement, params,
):
    query_params = {"symbol": symbol}
    if contract_type:
        query_params["contractType"] = coerce_enum(contract_type, ContractType, "contract_type")
    if strike_count is not None:
        query_params["strikeCount"] = strike_count
    if include_underlying_quote is not None:
        query_params["includeUnderlyingQuote"] = include_underlying_quote
    if strategy:
        query_params["strategy"] = coerce_enum(strategy, Strategy, "strategy")
    if interval is not None:
        query_params["interval"] = interval
    if strike is not None:
        query_params["strike"] = strike
    if range_type:
        query_params["range"] = coerce_enum(range_type, StrikeRange, "range_type")
    if volatility is not None:
        query_params["volatility"] = volatility
    if underlying_price is not None:
        query_params["underlyingPrice"] = underlying_price
    if interest_rate is not None:
        query_params["interestRate"] = interest_rate
    if days_to_expiration is not None:
        query_params["daysToExpiration"] = days_to_expiration
    if exp_month:
        query_params["expMonth"] = coerce_enum(exp_month, ExpirationMonth, "exp_month")
    if option_type:
        query_params["optionType"] = coerce_enum(option_type, OptionType, "option_type")
    if entitlement:
        query_params["entitlement"] = coerce_enum(entitlement, Entitlement, "entitlement")
    if from_date:
        query_params["fromDate"] = normalize_date(from_date, mode="date_only")
    if to_date:
        query_params["toDate"] = normalize_date(to_date, mode="date_only")
    if params:
        query_params.update(params)
    return query_params


def _build_price_history_params(
    symbol, periodType, period, frequencyType, frequency,
    startDate, endDate, need_extended_hours_data, need_previous_close, params,
):
    query_params: Dict[str, Any] = {
        "symbol": symbol,
        "periodType": coerce_enum(periodType, PeriodType, "periodType"),
        "period": period,
        "frequencyType": coerce_enum(frequencyType, FrequencyType, "frequencyType"),
        "frequency": frequency,
    }
    if startDate is not None:
        query_params["startDate"] = to_epoch_millis(startDate)
    if endDate is not None:
        query_params["endDate"] = to_epoch_millis(endDate)
    if need_extended_hours_data is not None:
        query_params["needExtendedHoursData"] = need_extended_hours_data
    if need_previous_close is not None:
        query_params["needPreviousClose"] = need_previous_close
    if params:
        query_params.update(params)
    return query_params


def _build_instruments_params(
    symbols: Union[str, List[str]],
    projection: Optional[str],
    extra_params: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    if isinstance(symbols, list):
        symbol_string = ",".join(symbols)
    else:
        symbol_string = symbols
    params: Dict[str, Any] = {"symbol": symbol_string}
    if projection:
        params["projection"] = coerce_enum(projection, Projection, "projection")
    if extra_params:
        params.update(extra_params)
    return params
