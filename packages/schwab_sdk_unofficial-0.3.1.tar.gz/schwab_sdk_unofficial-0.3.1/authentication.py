"""
Schwab SDK - Authentication Handler
Handles the full OAuth flow with Schwab API.
"""

import logging
import webbrowser
from typing import Optional, Dict, Any
from urllib.parse import urlencode
import httpx

try:
    from .callback import CallbackServer
    from .token_handler import TokenHandler
    from .exceptions import (
        SchwabAPIError,
        SchwabAuthenticationError,
        SchwabTokenExpiredError,
        raise_for_schwab_status,
    )
except ImportError:
    from callback import CallbackServer
    from token_handler import TokenHandler
    from exceptions import (
        SchwabAPIError,
        SchwabAuthenticationError,
        SchwabTokenExpiredError,
        raise_for_schwab_status,
    )

logger = logging.getLogger(__name__)


class Authentication:
    """
    Handles OAuth authentication with Schwab API.

    - Builds authorization URL
    - Starts callback server to receive authorization code
    - Exchanges code for tokens
    - Integrates with TokenHandler for persistent handling
    """

    def __init__(self, client_id: str, client_secret: str, redirect_uri: str, token_handler: TokenHandler):
        """
        Initializes the Authentication handler.

        Args:
            client_id: Schwab application Client ID
            client_secret: Schwab application Client Secret
            redirect_uri: OAuth redirect URI (must match the callback server)
            token_handler: TokenHandler instance for token management
        """
        self.client_id = client_id
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri
        self.token_handler = token_handler

        # Schwab OAuth URLs
        self.auth_url_base = "https://api.schwabapi.com/v1/oauth/authorize"
        self.token_url = "https://api.schwabapi.com/v1/oauth/token"

        # Callback server
        self.callback_server: Optional[CallbackServer] = None

        # Last login state
        self.last_login_result: Optional[Dict[str, Any]] = None

    def login(self, timeout: int = 300, auto_open_browser: bool = True, callback_port: Optional[int] = None) -> bool:
        """
        Executes the full OAuth flow to obtain tokens.

        First checks whether valid tokens already exist before starting the flow.

        Args:
            timeout: Maximum time in seconds to wait for the callback (default: 300)
            auto_open_browser: If True, automatically opens the browser (default: True)
            callback_port: Override the port for the callback server (default: extracted from redirect_uri)

        Returns:
            True if authentication succeeded, False otherwise
        """
        # Check if we already have valid tokens
        if self.token_handler.has_valid_token():
            logger.info("You already have valid tokens; login is not necessary")
            return True

        logger.info("Starting OAuth authentication flow...")

        try:
            # 1. Start callback server
            if not self._start_callback_server(callback_port=callback_port):
                return False

            # 2. Build authorization URL and open browser
            auth_url = self._build_auth_url()
            logger.info("Authorization URL: %s", auth_url)

            if auto_open_browser:
                logger.info("Opening browser automatically...")
                webbrowser.open(auth_url)
            else:
                logger.info("Please open the URL above in your browser")

            # 3. Wait for callback with authorization code
            logger.info("Waiting for callback (timeout: %ds)...", timeout)
            callback_result = self.callback_server.wait(timeout)

            # 4. Stop callback server
            self._stop_callback_server()

            # 5. Process callback result
            if not callback_result:
                logger.warning("Timeout waiting for authorization callback")
                return False

            # Parameters are inside the "params" key
            params = callback_result.get("params", {})

            if params.get("error"):
                error = params["error"]
                error_desc = params.get("error_description", "")
                logger.error("OAuth error: %s - %s", error, error_desc)
                return False

            # 6. Extract authorization code
            auth_code = params.get("code")
            if not auth_code:
                logger.error("Authorization code not received in the callback")
                logger.debug("Callback received: %s", callback_result)
                return False

            logger.info("Authorization code received, exchanging for tokens...")

            # 7. Exchange code for tokens
            self._exchange_code_for_tokens(auth_code)
            logger.info("Authentication completed successfully!")
            return True

        except SchwabAPIError as e:
            logger.error("Authentication failed: [%d] %s", e.status_code, e.message)
            if e.correl_id:
                logger.error("Schwab-Client-CorrelId: %s", e.correl_id)
            self._stop_callback_server()
            return False
        except Exception as e:
            logger.error("Error during authentication: %s", e)
            self._stop_callback_server()
            return False

    def _build_auth_url(self) -> str:
        """
        Builds Schwab's authorization URL.

        Returns:
            Full authorization URL
        """
        params = {
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "response_type": "code",
            "scope": "api"  # Scope required by Schwab
        }

        return f"{self.auth_url_base}?{urlencode(params)}"

    def _start_callback_server(self, callback_port: Optional[int] = None) -> bool:
        """
        Starts the callback server to receive the authorization code.

        Args:
            callback_port: Override port (default: extracted from redirect_uri)

        Returns:
            True if the server started successfully, False otherwise
        """
        try:
            # Extract information from redirect_uri to configure the server
            # Example: https://127.0.0.1:8443/callback -> host=127.0.0.1, port 8443
            import urllib.parse
            parsed = urllib.parse.urlparse(self.redirect_uri)
            host = parsed.hostname or "127.0.0.1"
            port = callback_port or parsed.port or (443 if parsed.scheme == 'https' else 80)
            path = parsed.path or "/callback"

            # Initialize callback server with full configuration
            self.callback_server = CallbackServer(
                host=host,
                port=port,
                path=path,
                force_https=True,
                adhoc_ssl=True,
            )

            # Start the server (does not return a boolean; raises an exception if it fails)
            self.callback_server.start()

            logger.info("Callback server started at https://%s:%d%s", host, port, path)
            return True

        except Exception as e:
            logger.error("Error starting callback server: %s", e)
            return False

    def _stop_callback_server(self) -> None:
        """
        Stops the callback server.
        """
        if self.callback_server:
            try:
                self.callback_server.shutdown()
                logger.info("Callback server stopped")
            except Exception as e:
                logger.error("Error stopping callback server: %s", e)
            finally:
                self.callback_server = None

    def _exchange_code_for_tokens(self, auth_code: str) -> bool:
        """
        Exchanges the authorization code for access and refresh tokens.

        Uses Basic auth (Base64-encoded client_id:client_secret) per the
        Schwab OAuth documentation (Step 2).

        Args:
            auth_code: Authorization code received from the callback

        Returns:
            True if the exchange was successful.

        Raises:
            SchwabAuthenticationError: If token exchange fails (401, 403, etc.)
            SchwabAPIError: If the server returns any other error status.
        """
        import base64

        payload = {
            "grant_type": "authorization_code",
            "code": auth_code,
            "redirect_uri": self.redirect_uri,
        }

        # Basic auth per Schwab OAuth docs (Step 2)
        credentials = f"{self.client_id}:{self.client_secret}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": f"Basic {encoded_credentials}",
        }

        try:
            logger.info("Exchanging authorization code for tokens...")

            response = httpx.post(
                self.token_url,
                data=payload,
                headers=headers,
                timeout=15,
            )

            # Raise typed exception for non-2xx responses
            raise_for_schwab_status(response)

            token_data = response.json()

            # Extract tokens
            access_token = token_data.get("access_token")
            refresh_token = token_data.get("refresh_token")
            expires_in = token_data.get("expires_in", 1800)  # Default 30 min

            if not access_token or not refresh_token:
                raise SchwabAuthenticationError(
                    "Incomplete token response: missing access_token or refresh_token",
                    status_code=response.status_code,
                    response=response,
                )

            # Save tokens using TokenHandler
            self.token_handler.save_tokens(access_token, refresh_token, expires_in)

            logger.info("Tokens saved successfully")
            return True

        except SchwabAPIError:
            raise
        except httpx.HTTPError as e:
            raise SchwabAuthenticationError(
                f"Network error exchanging tokens: {e}",
                status_code=0,
            ) from e

    def get_auth_url(self) -> str:
        """
        Returns the Schwab authorization URL.

        Use this when handling the OAuth callback with your own endpoint
        instead of the built-in callback server.

        Flow::

            auth_url = client.get_auth_url()
            # Redirect user to auth_url or open in browser
            # Your endpoint receives ?code={CODE}&session={SESSION_ID}
            # URL-decode the code (e.g. '%40' -> '@') before passing it
            client.exchange_code(auth_code)

        Returns:
            Full authorization URL
        """
        return self._build_auth_url()

    def exchange_code(self, auth_code: str) -> bool:
        """
        Exchange an authorization code for access and refresh tokens (sync).

        Use this when handling the OAuth callback with your own endpoint.
        The code must be URL-decoded before passing it (e.g. '%40' -> '@').

        Args:
            auth_code: Authorization code from the callback query string.

        Returns:
            True if tokens were obtained and saved.

        Raises:
            SchwabAuthenticationError: If token exchange fails.
            SchwabAPIError: If the server returns an error status.
        """
        return self._exchange_code_for_tokens(auth_code)

    async def async_exchange_code(self, auth_code: str) -> bool:
        """
        Exchange an authorization code for access and refresh tokens (async).

        Use this with FastAPI or any async framework. The code must be
        URL-decoded before passing it (e.g. '%40' -> '@').

        Args:
            auth_code: Authorization code from the callback query string.

        Returns:
            True if tokens were obtained and saved.

        Raises:
            SchwabAuthenticationError: If token exchange fails.
            SchwabAPIError: If the server returns an error status.
        """
        import base64

        payload = {
            "grant_type": "authorization_code",
            "code": auth_code,
            "redirect_uri": self.redirect_uri,
        }

        # Basic auth per Schwab OAuth docs (Step 2)
        credentials = f"{self.client_id}:{self.client_secret}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": f"Basic {encoded_credentials}",
        }

        try:
            logger.info("Exchanging authorization code for tokens (async)...")

            async with httpx.AsyncClient() as http:
                response = await http.post(
                    self.token_url,
                    data=payload,
                    headers=headers,
                    timeout=15,
                )

            # Raise typed exception for non-2xx responses
            raise_for_schwab_status(response)

            token_data = response.json()

            # Extract tokens
            access_token = token_data.get("access_token")
            refresh_token = token_data.get("refresh_token")
            expires_in = token_data.get("expires_in", 1800)  # Default 30 min

            if not access_token or not refresh_token:
                raise SchwabAuthenticationError(
                    "Incomplete token response: missing access_token or refresh_token",
                    status_code=response.status_code,
                    response=response,
                )

            # Save tokens using TokenHandler (non-blocking)
            await self.token_handler.async_save_tokens(access_token, refresh_token, expires_in)

            logger.info("Tokens saved successfully (async)")
            return True

        except SchwabAPIError:
            raise
        except httpx.HTTPError as e:
            raise SchwabAuthenticationError(
                f"Network error exchanging tokens: {e}",
                status_code=0,
            ) from e

    def is_authenticated(self) -> bool:
        """
        Checks if the user is authenticated with valid tokens.

        Returns:
            True if there are valid tokens, False otherwise
        """
        return self.token_handler.has_valid_token()

    def get_access_token(self) -> Optional[str]:
        """
        Gets the current access token.

        Returns:
            Valid access token or None if unavailable
        """
        return self.token_handler.get_access_token()

    def logout(self) -> None:
        """
        Signs out by deleting all tokens.
        """
        logger.info("Signing out...")
        self.token_handler._clear_tokens()
        logger.info("Session closed successfully")

    def __del__(self):
        """
        Destructor to ensure the callback server is closed.
        """
        self._stop_callback_server()
