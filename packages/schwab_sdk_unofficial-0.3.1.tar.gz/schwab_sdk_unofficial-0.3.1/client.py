"""
Schwab SDK - Client Principal
Main classes that orchestrate all SDK modules.

Provides two client classes:
- ``Client``      – synchronous, backed by ``httpx.Client``
- ``AsyncClient`` – asynchronous, backed by ``httpx.AsyncClient``
"""

import asyncio
import logging
import time
from typing import Optional, TYPE_CHECKING
import httpx

try:
    from .token_handler import TokenHandler
    from .authentication import Authentication
    from .exceptions import (
        SchwabAPIError,
        SchwabAuthenticationError,
        SchwabRateLimitError,
        SchwabServerError,
        raise_for_schwab_status,
    )
except ImportError:
    # Fallback for direct testing
    from token_handler import TokenHandler
    from authentication import Authentication
    from exceptions import (
        SchwabAPIError,
        SchwabAuthenticationError,
        SchwabRateLimitError,
        SchwabServerError,
        raise_for_schwab_status,
    )

# Forward declarations for type hints
if TYPE_CHECKING:
    try:
        from .accounts import Accounts, AsyncAccounts
        from .orders import Orders, AsyncOrders
        from .market import Market, AsyncMarket
        from .streaming import Streaming, AsyncStreaming
    except ImportError:
        from accounts import Accounts, AsyncAccounts
        from orders import Orders, AsyncOrders
        from market import Market, AsyncMarket
        from streaming import Streaming, AsyncStreaming

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Shared constants
# ---------------------------------------------------------------------------

TRADER_BASE_URL = "https://api.schwabapi.com/trader/v1"
MARKET_BASE_URL = "https://api.schwabapi.com/marketdata/v1"


# ---------------------------------------------------------------------------
# Sync Client
# ---------------------------------------------------------------------------

class Client:
    """
    Main Schwab SDK client (synchronous).

    Provides access to all functionality:
    - client.account.* - Account, transactions, and preferences endpoints
    - client.orders.* - Order endpoints
    - client.market.* - Market data endpoints
    - client.streaming.* - WebSocket streaming

    Usage::

        client = Client(client_id, client_secret, redirect_uri)
        client.login()  # Only if there are no valid tokens

        # Use submodules
        accounts = client.account.get_accounts()
        quote = client.market.get_quote("AAPL")
        client.orders.place_order(account_hash, order_data)
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        redirect_uri: str = "https://localhost:8080/callback",
        token_path: Optional[str] = None,
        encryption_key: Optional[str] = None,
        persist: bool = True,
    ):
        """
        Initializes the Schwab SDK client.

        Args:
            client_id: Schwab application Client ID
            client_secret: Schwab application Client Secret
            redirect_uri: OAuth redirect URI (default: https://localhost:8080/callback)
            token_path: Path to token file (default: "schwab_tokens.json")
            encryption_key: Optional passphrase for AES-256-GCM encryption of tokens at rest.
                           When provided, tokens saved to disk are encrypted.
                           Requires the 'cryptography' package.
            persist: If True (default), tokens are saved to and loaded from disk.
                    If False, tokens only live in memory.
        """
        self.client_id = client_id
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri

        # Schwab API base URLs
        self.trader_base_url = TRADER_BASE_URL
        self.market_base_url = MARKET_BASE_URL

        # Initialize core components
        self.token_handler = TokenHandler(
            client_id, client_secret, redirect_uri,
            token_path=token_path,
            encryption_key=encryption_key,
            persist=persist,
        )
        self.authentication = Authentication(client_id, client_secret, redirect_uri, self.token_handler)

        # Configure callback for automatic re-login when refresh token expires
        self.token_handler.on_refresh_token_expired = self._handle_refresh_token_expired

        # Persistent HTTP client (connection pooling)
        self._http = httpx.Client(follow_redirects=True)

        # Initialize submodules (lazy loading to avoid circular imports)
        self._account_module: Optional['Accounts'] = None
        self._orders_module: Optional['Orders'] = None
        self._market_module: Optional['Market'] = None
        self._streaming_module: Optional['Streaming'] = None

        # Auto-login if there are no valid tokens
        self._auto_authenticate()

    @property
    def account(self) -> 'Accounts':
        """
        Access to the accounts, transactions, and preferences module.

        Returns:
            Instance of the Accounts module
        """
        if self._account_module is None:
            try:
                from .accounts import Accounts
            except ImportError:
                from accounts import Accounts
            self._account_module = Accounts(self)
        return self._account_module

    @property
    def orders(self) -> 'Orders':
        """
        Access to the orders module.

        Returns:
            Instance of the Orders module
        """
        if self._orders_module is None:
            try:
                from .orders import Orders
            except ImportError:
                from orders import Orders
            self._orders_module = Orders(self)
        return self._orders_module

    @property
    def market(self) -> 'Market':
        """
        Access to the market data module.

        Returns:
            Instance of the Market module
        """
        if self._market_module is None:
            try:
                from .market import Market
            except ImportError:
                from market import Market
            self._market_module = Market(self)
        return self._market_module

    @property
    def streaming(self) -> 'Streaming':
        """
        Access to the WebSocket streaming module.

        Returns:
            Instance of the Streaming module
        """
        if self._streaming_module is None:
            try:
                from .streaming import Streaming
            except ImportError:
                from streaming import Streaming
            self._streaming_module = Streaming(self)
        return self._streaming_module

    def login(self, timeout: int = 300, auto_open_browser: bool = True, callback_port: Optional[int] = None) -> bool:
        """
        Executes the OAuth authentication flow.

        Args:
            timeout: Maximum time to wait for the callback (default: 300s)
            auto_open_browser: Open browser automatically (default: True)
            callback_port: Override the port for the callback server (default: extracted from redirect_uri)

        Returns:
            True if authentication succeeded, False otherwise
        """
        return self.authentication.login(timeout, auto_open_browser, callback_port=callback_port)

    def get_auth_url(self) -> str:
        """
        Returns the Schwab authorization URL.

        Use this when handling the OAuth callback with your own endpoint
        instead of the built-in callback server::

            auth_url = client.get_auth_url()
            # Redirect user to auth_url
            # Your endpoint receives ?code={CODE}
            client.exchange_code(code)

        Returns:
            Full authorization URL
        """
        return self.authentication.get_auth_url()

    def exchange_code(self, auth_code: str) -> bool:
        """
        Exchange an authorization code for tokens.

        Use this when handling the OAuth callback with your own endpoint.
        The code must be URL-decoded (e.g. '%40' -> '@').

        Args:
            auth_code: Authorization code from the callback query string.

        Returns:
            True if tokens were obtained and saved.

        Raises:
            SchwabAuthenticationError: If token exchange fails.
        """
        return self.authentication.exchange_code(auth_code)

    def has_valid_token(self) -> bool:
        """
        Checks whether there are valid access tokens.

        Returns:
            True if tokens are valid, False otherwise
        """
        return self.token_handler.has_valid_token()

    def refresh_token(self) -> bool:
        """
        Automatically refreshes the access token.

        Automatic rotation is handled internally every 29 minutes.
        This method is primarily informational.

        Returns:
            True if there are valid tokens or refresh succeeded, False otherwise
        """
        if self.has_valid_token():
            return True
        return self.token_handler.refresh_token_now()

    def refresh_token_now(self) -> bool:
        """
        Forces an immediate access token refresh.

        Returns:
            True if the refresh succeeded, False otherwise
        """
        return self.token_handler.refresh_token_now()

    def logout(self) -> None:
        """
        Signs out by deleting all tokens.
        """
        self.authentication.logout()

    def get_access_token(self) -> Optional[str]:
        """
        Retrieves the current access token for use in requests.

        Returns:
            Valid access token or None if unavailable
        """
        return self.token_handler.get_access_token()

    def get_auth_headers(self) -> dict:
        """
        Retrieves authentication headers for API requests.

        Returns:
            Dict with Authorization headers, or an empty dict if no token
        """
        token = self.get_access_token()
        if token:
            return {
                "Authorization": f"Bearer {token}"
            }
        return {}

    def _request(
        self,
        method: str,
        url: str,
        *,
        params: Optional[dict] = None,
        json: Optional[dict] = None,
        headers: Optional[dict] = None,
        timeout: int = 15,
        max_retries: int = 3,
        backoff_factor: float = 0.5,
    ) -> httpx.Response:
        """
        Performs an HTTP request with:
        - Automatic Authorization headers
        - Token refresh on 401 (once)
        - Retries with backoff for 429/5xx

        Returns:
            httpx.Response
        """
        # Merge headers
        req_headers = {**self.get_auth_headers(), **(headers or {})}

        def _send() -> httpx.Response:
            return self._http.request(
                method=method.upper(),
                url=url,
                params=params,
                json=json,
                headers=req_headers,
                timeout=timeout,
            )

        last_exc: Optional[Exception] = None
        attempt = 0
        while attempt < max_retries:
            try:
                resp = _send()
                # Handle 401: try refresh once and retry immediately
                if resp.status_code == 401:
                    try:
                        if self.refresh_token_now() and self.get_access_token():
                            req_headers = {**self.get_auth_headers(), **(headers or {})}
                            resp = _send()
                            if resp.status_code != 401:
                                return resp
                    except Exception:
                        pass
                    # If still 401, return response for caller to handle
                    return resp

                # Retries for 429 and 5xx
                if resp.status_code in (429, 500, 502, 503, 504):
                    sleep_s = backoff_factor * (2 ** attempt)
                    time.sleep(sleep_s)
                    attempt += 1
                    continue
                return resp
            except httpx.RequestError as e:
                last_exc = e
                sleep_s = backoff_factor * (2 ** attempt)
                time.sleep(sleep_s)
                attempt += 1

        # If we exhausted retries and had an exception, re-raise; otherwise, send once more
        if last_exc:
            raise last_exc
        # Unlikely case: no exception but nothing returned
        return _send()

    def is_authenticated(self) -> bool:
        """
        Checks whether the client is authenticated.

        Returns:
            True if authenticated, False otherwise
        """
        return self.authentication.is_authenticated()

    def _auto_authenticate(self) -> None:
        """
        Attempts automatic authentication if there are no valid tokens.
        """
        if not self.has_valid_token():
            logger.info("No valid tokens found. Use client.login() to authenticate.")
        else:
            logger.info("Client authenticated with valid tokens")

    def _handle_refresh_token_expired(self) -> None:
        """
        Callback executed when the refresh token expires.

        Notifies the user that re-login is required.
        """
        logger.warning("Refresh token expired. Please run client.login() to re-authenticate.")

    def __enter__(self):
        """
        Context manager entry.
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Context manager exit - clean up resources.
        """
        self._http.close()
        if hasattr(self, 'token_handler'):
            self.token_handler.cleanup()

    def __del__(self):
        """
        Destructor - clean up resources.
        """
        if hasattr(self, '_http'):
            try:
                self._http.close()
            except Exception:
                pass
        if hasattr(self, 'token_handler'):
            self.token_handler.cleanup()

    def __repr__(self) -> str:
        """
        String representation of the client.
        """
        status = "authenticated" if self.is_authenticated() else "not authenticated"
        return f"SchwabClient(client_id='{self.client_id[:8]}...', status='{status}')"


# ---------------------------------------------------------------------------
# Async Client
# ---------------------------------------------------------------------------

class AsyncClient:
    """
    Async Schwab SDK client.

    Provides access to all async functionality:
    - client.account.* - Account, transactions, and preferences endpoints
    - client.orders.* - Order endpoints
    - client.market.* - Market data endpoints
    - client.streaming.* - WebSocket streaming (async)

    Usage::

        async with AsyncClient(client_id, client_secret, redirect_uri) as client:
            accounts = await client.account.get_accounts()
            quote = await client.market.get_quote("AAPL")
            await client.orders.place_order(account_hash, order_data)
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        redirect_uri: str = "https://localhost:8080/callback",
        token_path: Optional[str] = None,
        encryption_key: Optional[str] = None,
        persist: bool = True,
    ):
        """
        Initializes the async Schwab SDK client.

        Args:
            client_id: Schwab application Client ID
            client_secret: Schwab application Client Secret
            redirect_uri: OAuth redirect URI (default: https://localhost:8080/callback)
            token_path: Path to token file (default: "schwab_tokens.json")
            encryption_key: Optional passphrase for AES-256-GCM encryption of tokens at rest.
            persist: If True (default), tokens are saved to and loaded from disk.
                    If False, tokens only live in memory.
        """
        self.client_id = client_id
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri

        # Schwab API base URLs
        self.trader_base_url = TRADER_BASE_URL
        self.market_base_url = MARKET_BASE_URL

        # Initialize core components
        self.token_handler = TokenHandler(
            client_id, client_secret, redirect_uri,
            token_path=token_path,
            encryption_key=encryption_key,
            persist=persist,
        )
        self.authentication = Authentication(client_id, client_secret, redirect_uri, self.token_handler)

        # Configure callback for automatic re-login when refresh token expires
        self.token_handler.on_refresh_token_expired = self._handle_refresh_token_expired

        # Persistent async HTTP client (connection pooling)
        self._http = httpx.AsyncClient(follow_redirects=True)

        # Initialize submodules (lazy loading)
        self._account_module: Optional['AsyncAccounts'] = None
        self._orders_module: Optional['AsyncOrders'] = None
        self._market_module: Optional['AsyncMarket'] = None
        self._streaming_module: Optional['AsyncStreaming'] = None

    @property
    def account(self) -> 'AsyncAccounts':
        """Access to the async accounts module."""
        if self._account_module is None:
            try:
                from .accounts import AsyncAccounts
            except ImportError:
                from accounts import AsyncAccounts
            self._account_module = AsyncAccounts(self)
        return self._account_module

    @property
    def orders(self) -> 'AsyncOrders':
        """Access to the async orders module."""
        if self._orders_module is None:
            try:
                from .orders import AsyncOrders
            except ImportError:
                from orders import AsyncOrders
            self._orders_module = AsyncOrders(self)
        return self._orders_module

    @property
    def market(self) -> 'AsyncMarket':
        """Access to the async market data module."""
        if self._market_module is None:
            try:
                from .market import AsyncMarket
            except ImportError:
                from market import AsyncMarket
            self._market_module = AsyncMarket(self)
        return self._market_module

    @property
    def streaming(self) -> 'AsyncStreaming':
        """Access to the async WebSocket streaming module."""
        if self._streaming_module is None:
            try:
                from .streaming import AsyncStreaming
            except ImportError:
                from streaming import AsyncStreaming
            self._streaming_module = AsyncStreaming(self)
        return self._streaming_module

    async def login(self, timeout: int = 300, auto_open_browser: bool = True) -> bool:
        """
        Executes the OAuth authentication flow (non-blocking).

        Runs the callback server and browser flow in a thread so the
        event loop is not blocked.

        Args:
            timeout: Maximum time to wait for the callback (default: 300s)
            auto_open_browser: Open browser automatically (default: True)

        Returns:
            True if authentication succeeded, False otherwise
        """
        return await asyncio.to_thread(
            self.authentication.login, timeout, auto_open_browser
        )

    def get_auth_url(self) -> str:
        """
        Returns the Schwab authorization URL.

        Use when handling the callback with your own endpoint::

            auth_url = client.get_auth_url()
            # Your endpoint receives ?code={CODE}
            await client.exchange_code(code)
        """
        return self.authentication.get_auth_url()

    async def exchange_code(self, auth_code: str) -> bool:
        """
        Exchange an authorization code for tokens (async).

        Non-blocking — safe for FastAPI and other async frameworks.
        The code must be URL-decoded (e.g. '%40' -> '@').

        Args:
            auth_code: Authorization code from the callback query string.

        Returns:
            True if tokens were obtained and saved.

        Raises:
            SchwabAuthenticationError: If token exchange fails.
        """
        return await self.authentication.async_exchange_code(auth_code)

    async def logout(self) -> None:
        """Signs out by deleting all tokens (non-blocking)."""
        await self.token_handler._async_clear_tokens()
        logger.info("Session closed successfully")

    def has_valid_token(self) -> bool:
        """Checks whether there are valid access tokens."""
        return self.token_handler.has_valid_token()

    async def refresh_token_now(self) -> bool:
        """Forces an immediate async access token refresh."""
        return await self.token_handler.async_refresh_token_now()

    def get_access_token(self) -> Optional[str]:
        """Retrieves the current access token."""
        return self.token_handler.get_access_token()

    def get_auth_headers(self) -> dict:
        """Retrieves authentication headers for API requests."""
        token = self.get_access_token()
        if token:
            return {"Authorization": f"Bearer {token}"}
        return {}

    async def _request(
        self,
        method: str,
        url: str,
        *,
        params: Optional[dict] = None,
        json: Optional[dict] = None,
        headers: Optional[dict] = None,
        timeout: int = 15,
        max_retries: int = 3,
        backoff_factor: float = 0.5,
    ) -> httpx.Response:
        """
        Performs an async HTTP request with:
        - Automatic Authorization headers
        - Token refresh on 401 (once)
        - Retries with backoff for 429/5xx

        Returns:
            httpx.Response
        """
        req_headers = {**self.get_auth_headers(), **(headers or {})}

        async def _send() -> httpx.Response:
            return await self._http.request(
                method=method.upper(),
                url=url,
                params=params,
                json=json,
                headers=req_headers,
                timeout=timeout,
            )

        last_exc: Optional[Exception] = None
        attempt = 0
        while attempt < max_retries:
            try:
                resp = await _send()
                # Handle 401: try async refresh once and retry
                if resp.status_code == 401:
                    try:
                        if await self.refresh_token_now() and self.get_access_token():
                            req_headers = {**self.get_auth_headers(), **(headers or {})}
                            resp = await _send()
                            if resp.status_code != 401:
                                return resp
                    except Exception:
                        pass
                    return resp

                # Retries for 429 and 5xx
                if resp.status_code in (429, 500, 502, 503, 504):
                    sleep_s = backoff_factor * (2 ** attempt)
                    await asyncio.sleep(sleep_s)
                    attempt += 1
                    continue
                return resp
            except httpx.RequestError as e:
                last_exc = e
                sleep_s = backoff_factor * (2 ** attempt)
                await asyncio.sleep(sleep_s)
                attempt += 1

        if last_exc:
            raise last_exc
        return await _send()

    def is_authenticated(self) -> bool:
        """Checks whether the client is authenticated."""
        return self.authentication.is_authenticated()

    def _handle_refresh_token_expired(self) -> None:
        """Callback executed when the refresh token expires."""
        logger.warning("Refresh token expired. Please re-authenticate.")

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit - clean up resources."""
        await self._http.aclose()
        if hasattr(self, 'token_handler'):
            self.token_handler.cleanup()

    def __repr__(self) -> str:
        status = "authenticated" if self.is_authenticated() else "not authenticated"
        return f"AsyncSchwabClient(client_id='{self.client_id[:8]}...', status='{status}')"
