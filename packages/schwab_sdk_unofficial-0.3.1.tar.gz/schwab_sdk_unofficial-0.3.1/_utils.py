"""
Schwab SDK - Internal Utilities

Shared helpers for enum coercion, date normalization, and parameter building.
"""

import re
from datetime import date, datetime, timedelta
from enum import Enum, IntEnum
from typing import Optional, Tuple, Type, Union


def coerce_enum(value: Union[str, Enum], enum_class: Type[Enum], param_name: str) -> str:
    """
    Accept a str or enum member and return the API-ready string value.

    Performs case-insensitive matching for StrEnum types. For IntEnum,
    validates that the integer value is a valid member.

    Args:
        value: Raw value (str, enum member, or int for IntEnum).
        enum_class: The Enum class to validate against.
        param_name: Parameter name for error messages.

    Returns:
        The validated API string value.

    Raises:
        ValueError: If the value is not a valid member.
    """
    if isinstance(value, enum_class):
        return str(value.value)

    if issubclass(enum_class, IntEnum):
        try:
            return str(enum_class(int(value)).value)
        except (ValueError, KeyError):
            valid = ", ".join(str(m.value) for m in enum_class)
            raise ValueError(
                f"Invalid {param_name}: {value!r}. Valid values: {valid}"
            )

    # StrEnum: case-insensitive lookup by value, then by member name
    s = str(value).strip()
    for member in enum_class:
        if s.upper() == str(member.value).upper():
            return str(member.value)
    for member in enum_class:
        if s.upper() == member.name.upper():
            return str(member.value)

    valid = ", ".join(str(m.value) for m in enum_class)
    raise ValueError(
        f"Invalid {param_name}: {value!r}. Valid values: {valid}"
    )


def normalize_date(date_str: Optional[str], *, is_end: bool = False, mode: str = "iso") -> Optional[str]:
    """
    Normalize a date string.

    Args:
        date_str: Date string to normalize, or None.
        is_end: If True and mode="iso", use 23:59:59 timestamp.
        mode: "iso" appends timestamp for short dates (accounts/orders),
              "date_only" strips any timestamp (market data).

    Returns:
        Normalized date string or None.
    """
    if not date_str:
        return None
    s = str(date_str).strip()

    if mode == "date_only":
        if "T" in s and len(s) >= 10:
            return s[:10]
        return s

    # mode == "iso": append timestamp to bare YYYY-MM-DD
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        return f"{s}T23:59:59.000Z" if is_end else f"{s}T00:00:00.000Z"
    return s


def normalize_date_range(
    from_date: Optional[str],
    to_date: Optional[str],
    *,
    default_days: Optional[int] = None,
) -> Tuple[Optional[str], Optional[str]]:
    """
    Normalize a from/to date pair for API queries.

    Consolidates _normalize_transaction_dates() and _normalize_order_dates().

    Args:
        from_date: Start date (YYYY-MM-DD or ISO).
        to_date: End date (YYYY-MM-DD or ISO).
        default_days: If both dates are None, default to a range of this
                      many days ending now. None means no default (return None, None).

    Returns:
        Tuple of (start_normalized, end_normalized).
    """
    start_norm = normalize_date(from_date, is_end=False) if from_date else None
    end_norm = normalize_date(to_date, is_end=True) if to_date else None

    if not start_norm and not end_norm:
        if default_days is not None:
            to_dt = datetime.now()
            from_dt = to_dt - timedelta(days=default_days)
            start_norm = from_dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")
            end_norm = to_dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")
        return start_norm, end_norm

    if start_norm and not end_norm:
        m = re.match(r"(\d{4}-\d{2}-\d{2})", start_norm)
        base = m.group(1) if m else start_norm[:10]
        end_norm = f"{base}T23:59:59.000Z"
    elif end_norm and not start_norm:
        m = re.match(r"(\d{4}-\d{2}-\d{2})", end_norm)
        base = m.group(1) if m else end_norm[:10]
        start_norm = f"{base}T00:00:00.000Z"

    return start_norm, end_norm


def to_epoch_millis(value) -> int:
    """
    Convert a value to epoch milliseconds for the Schwab API.

    Accepts:
        - int/float: treated as epoch millis already (returned as-is)
        - datetime: converted to epoch millis
        - date: converted to epoch millis at midnight UTC
        - str: parsed as YYYY-MM-DD or ISO format, then converted

    Returns:
        Epoch milliseconds as int.
    """
    if isinstance(value, (int, float)):
        return int(value)
    if isinstance(value, datetime):
        return int(value.timestamp() * 1000)
    if isinstance(value, date):
        return int(datetime(value.year, value.month, value.day).timestamp() * 1000)
    if isinstance(value, str):
        s = value.strip()
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
            dt = datetime.strptime(s, "%Y-%m-%d")
            return int(dt.timestamp() * 1000)
        try:
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
            return int(dt.timestamp() * 1000)
        except ValueError:
            pass
    raise ValueError(f"Cannot convert {value!r} to epoch milliseconds")
