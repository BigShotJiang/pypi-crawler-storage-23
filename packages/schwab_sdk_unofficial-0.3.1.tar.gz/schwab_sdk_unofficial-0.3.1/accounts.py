"""
Schwab SDK - Accounts Module
Handles account endpoints, transactions, and user preferences.
"""

from typing import Optional, Dict, Any, List

from .enums import AccountField, TransactionType
from ._utils import coerce_enum, normalize_date_range
from .exceptions import raise_for_schwab_status


# ---------------------------------------------------------------------------
# Shared param builders (used by both sync and async classes)
# ---------------------------------------------------------------------------

def _build_accounts_params(
    fields: Optional[List[str]],
    params: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    query_params: Dict[str, Any] = dict(params or {})
    if fields:
        validated = [coerce_enum(f, AccountField, "fields") for f in fields]
        query_params["fields"] = ",".join(validated)
    return query_params


def _build_transaction_params(
    from_date,
    to_date,
    transaction_types: Optional[List[str]],
    symbol: Optional[str],
    filters: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    params: Dict[str, Any] = {}
    start_norm, end_norm = normalize_date_range(from_date, to_date)
    if start_norm:
        params['startDate'] = start_norm
    if end_norm:
        params['endDate'] = end_norm
    if transaction_types:
        validated = [coerce_enum(t, TransactionType, "transaction_types") for t in transaction_types]
        params['types'] = ','.join(validated)
    if symbol:
        params['symbol'] = symbol
    if filters:
        params.update(filters)
    return params


class Accounts:
    """
    Module for account-related endpoints (sync).

    Includes:
    - Account information (numbers, balances, positions)
    - Transactions
    - User preferences
    """

    def __init__(self, client):
        """
        Initializes the Accounts module.

        Args:
            client: Instance of the main client
        """
        self.client = client
        self.base_url = client.trader_base_url

    def get_account_numbers(self) -> Dict[str, Any]:
        """
        Gets a list of account numbers and their encrypted values.

        GET /accounts/accountNumbers

        Returns:
            JSON response with accountNumber and accountHash for each account
        """
        endpoint = f"{self.base_url}/accounts/accountNumbers"
        response = self.client._request("GET", endpoint, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    def get_accounts(
        self,
        fields: Optional[List[str]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Retrieves balances and positions for all linked accounts.

        GET /accounts

        Args:
            fields: Additional fields to include. Available values: "positions".
                    Balances are displayed by default.
            params: Additional query parameters

        Returns:
            JSON response with complete information for all accounts
        """
        endpoint = f"{self.base_url}/accounts"
        query_params = _build_accounts_params(fields, params)
        response = self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    def get_account_by_id(
        self,
        account_hash: str,
        fields: Optional[List[str]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Retrieves balance and positions for a specific account.

        GET /accounts/{accountNumber}

        Args:
            account_hash: Encrypted account identifier (hashValue)
            fields: Additional fields to include. Available values: "positions".
                    Balances are displayed by default.
            params: Additional query parameters

        Returns:
            JSON response with information for the specified account
        """
        endpoint = f"{self.base_url}/accounts/{account_hash}"
        query_params = _build_accounts_params(fields, params)
        response = self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    def find_account(self, last_4_digits: str) -> Optional[Dict[str, Any]]:
        """
        Finds an account by the last 4 digits of the account number.

        Helper method that fetches all accounts and filters by the last 4 digits.

        Args:
            last_4_digits: Last 4 digits of the account number

        Returns:
            Information for the matched account, or None if not found
        """
        # Get account numbers
        account_numbers = self.get_account_numbers()
        # Look for an account whose number ends with the specified digits
        for account_info in account_numbers:
            account_number = account_info.get("accountNumber", "")
            if account_number.endswith(last_4_digits):
                # Retrieve full information for this account
                account_hash = account_info.get("hashValue", account_number)
                return self.get_account_by_id(account_hash)
        return None

    def get_transactions(
        self,
        account_hash: str,
        from_date: str = None,
        to_date: str = None,
        transaction_types: Optional[List[str]] = None,
        symbol: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Retrieves all transactions for a specific account.

        GET /accounts/{accountNumber}/transactions

        Args:
            account_hash: Encrypted account identifier (hashValue)
            from_date: Start date in short format 'YYYY-MM-DD' or ISO UTC 'YYYY-MM-DDTHH:MM:SS.ffffffZ'
            to_date: End date in short format 'YYYY-MM-DD' or ISO UTC 'YYYY-MM-DDTHH:MM:SS.ffffffZ'
            transaction_types: List of transaction types to filter by. Available values:
                TRADE, RECEIVE_AND_DELIVER, DIVIDEND_OR_INTEREST, ACH_RECEIPT,
                ACH_DISBURSEMENT, CASH_RECEIPT, CASH_DISBURSEMENT, ELECTRONIC_FUND,
                WIRE_OUT, WIRE_IN, JOURNAL, MEMORANDUM, MARGIN_CALL, MONEY_MARKET,
                SMA_ADJUSTMENT
            symbol: Only return transactions for this symbol.
            filters: Additional optional query filters

        Returns:
            JSON response with the account's transactions
        """
        endpoint = f"{self.base_url}/accounts/{account_hash}/transactions"
        params = _build_transaction_params(from_date, to_date, transaction_types, symbol, filters)
        response = self.client._request("GET", endpoint, params=params, timeout=15)
        raise_for_schwab_status(response)
        return response.json()

    def get_transaction(self, account_hash: str, transaction_id: str) -> Dict[str, Any]:
        """
        Retrieves specific information for a transaction.

        GET /accounts/{accountNumber}/transactions/{transactionId}

        Args:
            account_hash: Encrypted account identifier (hashValue)
            transaction_id: ID of the specific transaction

        Returns:
            JSON response with information for the specific transaction
        """
        endpoint = f"{self.base_url}/accounts/{account_hash}/transactions/{transaction_id}"
        response = self.client._request("GET", endpoint, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    def get_user_preferences(self) -> Dict[str, Any]:
        """
        Retrieves preference information for the authenticated user.

        GET /userPreference

        This includes streaming-related data such as:
        - schwabClientCustomerId
        - schwabClientCorrelId
        - SchwabClientChannel
        - SchwabClientFunctionId

        Returns:
            JSON response with the user's preferences
        """
        endpoint = f"{self.base_url}/userPreference"
        response = self.client._request("GET", endpoint, timeout=10)
        raise_for_schwab_status(response)
        return response.json()


# ---------------------------------------------------------------------------
# Async variant
# ---------------------------------------------------------------------------

class AsyncAccounts:
    """
    Module for account-related endpoints (async).
    """

    def __init__(self, client):
        self.client = client
        self.base_url = client.trader_base_url

    async def get_account_numbers(self) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/accounts/accountNumbers"
        response = await self.client._request("GET", endpoint, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    async def get_accounts(
        self,
        fields: Optional[List[str]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/accounts"
        query_params = _build_accounts_params(fields, params)
        response = await self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    async def get_account_by_id(
        self,
        account_hash: str,
        fields: Optional[List[str]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/accounts/{account_hash}"
        query_params = _build_accounts_params(fields, params)
        response = await self.client._request("GET", endpoint, params=query_params, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    async def find_account(self, last_4_digits: str) -> Optional[Dict[str, Any]]:
        account_numbers = await self.get_account_numbers()
        for account_info in account_numbers:
            account_number = account_info.get("accountNumber", "")
            if account_number.endswith(last_4_digits):
                account_hash = account_info.get("hashValue", account_number)
                return await self.get_account_by_id(account_hash)
        return None

    async def get_transactions(
        self,
        account_hash: str,
        from_date: str = None,
        to_date: str = None,
        transaction_types: Optional[List[str]] = None,
        symbol: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/accounts/{account_hash}/transactions"
        params = _build_transaction_params(from_date, to_date, transaction_types, symbol, filters)
        response = await self.client._request("GET", endpoint, params=params, timeout=15)
        raise_for_schwab_status(response)
        return response.json()

    async def get_transaction(self, account_hash: str, transaction_id: str) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/accounts/{account_hash}/transactions/{transaction_id}"
        response = await self.client._request("GET", endpoint, timeout=10)
        raise_for_schwab_status(response)
        return response.json()

    async def get_user_preferences(self) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/userPreference"
        response = await self.client._request("GET", endpoint, timeout=10)
        raise_for_schwab_status(response)
        return response.json()
