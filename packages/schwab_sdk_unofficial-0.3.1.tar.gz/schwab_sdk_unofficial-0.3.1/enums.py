"""
Schwab SDK - Enums

All API parameter and response enums as StrEnum (Python 3.11+) with fallback
for 3.9+. Values match the Schwab API exactly. Enums are ``str`` subclasses
so they can be passed directly where a ``str`` is expected (backward compatible).
"""

import sys

if sys.version_info >= (3, 11):
    from enum import StrEnum, IntEnum
else:
    from enum import Enum, IntEnum

    class StrEnum(str, Enum):
        """str + Enum fallback for Python < 3.11."""
        pass


# ═══════════════════════════════════════════════════════════════════════════
# Market Data — Request Parameters
# ═══════════════════════════════════════════════════════════════════════════

class ContractType(StrEnum):
    """Option chain contract type filter."""
    CALL = "CALL"
    PUT = "PUT"
    ALL = "ALL"


class Strategy(StrEnum):
    """Option chain strategy."""
    SINGLE = "SINGLE"
    ANALYTICAL = "ANALYTICAL"
    COVERED = "COVERED"
    VERTICAL = "VERTICAL"
    CALENDAR = "CALENDAR"
    STRANGLE = "STRANGLE"
    STRADDLE = "STRADDLE"
    BUTTERFLY = "BUTTERFLY"
    CONDOR = "CONDOR"
    DIAGONAL = "DIAGONAL"
    COLLAR = "COLLAR"
    ROLL = "ROLL"


class StrikeRange(StrEnum):
    """Option chain strike range filter. Values are API abbreviations."""
    IN_THE_MONEY = "ITM"
    NEAR_THE_MONEY = "NTM"
    OUT_OF_THE_MONEY = "OTM"
    STRIKES_ABOVE_MARKET = "SAK"
    STRIKES_BELOW_MARKET = "SBK"
    STRIKES_NEAR_MARKET = "SNK"
    ALL = "ALL"


class ExpirationMonth(StrEnum):
    """Option chain expiration month filter."""
    JAN = "JAN"
    FEB = "FEB"
    MAR = "MAR"
    APR = "APR"
    MAY = "MAY"
    JUN = "JUN"
    JUL = "JUL"
    AUG = "AUG"
    SEP = "SEP"
    OCT = "OCT"
    NOV = "NOV"
    DEC = "DEC"
    ALL = "ALL"


class OptionType(StrEnum):
    """Option type filter for option chains."""
    STANDARD = "STANDARD"
    NON_STANDARD = "NON_STANDARD"
    ALL = "ALL"


class Entitlement(StrEnum):
    """Retail token entitlement level."""
    PN = "PN"   # NonPayingPro
    NP = "NP"   # NonPro
    PP = "PP"   # PayingPro


class PeriodType(StrEnum):
    """Price history period type."""
    DAY = "day"
    MONTH = "month"
    YEAR = "year"
    YTD = "ytd"


class FrequencyType(StrEnum):
    """Price history frequency type."""
    MINUTE = "minute"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"


class QuoteField(StrEnum):
    """
    Quote field groups for GET /quotes.

    Send comma-separated values or omit for full response (default: all).
    """
    QUOTE = "quote"
    FUNDAMENTAL = "fundamental"
    EXTENDED = "extended"
    REFERENCE = "reference"
    REGULAR = "regular"
    ALL = "all"


class MoverIndex(StrEnum):
    """Index symbols for GET /movers/{symbol_id}."""
    DJI = "$DJI"
    COMPX = "$COMPX"
    SPX = "$SPX"
    NYSE = "NYSE"
    NASDAQ = "NASDAQ"
    OTCBB = "OTCBB"
    INDEX_ALL = "INDEX_ALL"
    EQUITY_ALL = "EQUITY_ALL"
    OPTION_ALL = "OPTION_ALL"
    OPTION_PUT = "OPTION_PUT"
    OPTION_CALL = "OPTION_CALL"


class MoverSort(StrEnum):
    """Movers sort attribute. Also used as screener sortField."""
    VOLUME = "VOLUME"
    TRADES = "TRADES"
    PERCENT_CHANGE_UP = "PERCENT_CHANGE_UP"
    PERCENT_CHANGE_DOWN = "PERCENT_CHANGE_DOWN"
    AVERAGE_PERCENT_VOLUME = "AVERAGE_PERCENT_VOLUME"


class MoverFrequency(IntEnum):
    """Movers frequency (minutes). 0 = real-time snapshot."""
    ZERO = 0
    ONE = 1
    FIVE = 5
    TEN = 10
    THIRTY = 30
    SIXTY = 60


class MoverDirection(StrEnum):
    """Direction of price movement in movers response."""
    UP = "up"
    DOWN = "down"


class MarketID(StrEnum):
    """Market IDs for GET /markets and GET /markets/{market_id}."""
    EQUITY = "equity"
    OPTION = "option"
    BOND = "bond"
    FUTURE = "future"
    FOREX = "forex"


class Projection(StrEnum):
    """Instrument search projection type."""
    SYMBOL_SEARCH = "symbol-search"
    SYMBOL_REGEX = "symbol-regex"
    DESC_SEARCH = "desc-search"
    DESC_REGEX = "desc-regex"
    SEARCH = "search"
    FUNDAMENTAL = "fundamental"


# ═══════════════════════════════════════════════════════════════════════════
# Market Data — Response Enums
# ═══════════════════════════════════════════════════════════════════════════

class AssetMainType(StrEnum):
    """Primary asset type returned in API responses and streaming data."""
    BOND = "BOND"
    EQUITY = "EQUITY"
    ETF = "ETF"
    EXTENDED = "EXTENDED"
    FOREX = "FOREX"
    FUTURE = "FUTURE"
    FUTURE_OPTION = "FUTURE_OPTION"
    FUNDAMENTAL = "FUNDAMENTAL"
    INDEX = "INDEX"
    INDICATOR = "INDICATOR"
    MUTUAL_FUND = "MUTUAL_FUND"
    OPTION = "OPTION"
    UNKNOWN = "UNKNOWN"


class AssetSubType(StrEnum):
    """Asset sub-type returned in API responses and streaming data."""
    ADR = "ADR"    # American Depositary Receipt
    CEF = "CEF"    # Closed-End Fund
    COE = "COE"    # Common Equity
    ETF = "ETF"    # Exchange-Traded Fund
    ETN = "ETN"    # Exchange-Traded Note
    GDR = "GDR"    # Global Depositary Receipt
    OEF = "OEF"    # Open-End Fund
    PRF = "PRF"    # Preferred Stock
    RGT = "RGT"    # Right
    UIT = "UIT"    # Unit Investment Trust
    WAR = "WAR"    # Warrant


class QuoteType(StrEnum):
    """Quote type returned in equity/ETF quotes."""
    NBBO = "NBBO"


class SecurityStatus(StrEnum):
    """Security status in quote responses."""
    NORMAL = "Normal"
    UNKNOWN = "Unknown"
    HALTED = "Halted"
    CLOSED = "Closed"


class Exchange(StrEnum):
    """
    Exchange single-character codes returned in reference.exchange
    and streaming field 13 (Exchange ID).
    """
    AMEX = "A"               # NYSE American (AMEX)
    INDICATOR = ":"          # Indicator (realtime only)
    NASDAQ = "Q"
    NYSE = "N"
    NYSE_ARCA = "P"          # Pacific
    OPR = "o"                # Options
    OTC_MARKETS = "9"        # Pink Sheets
    INDEX = "0"
    XCME = "@"               # CME futures
    GFT = "T"                # Forex
    MUTUAL_FUND = "3"
    NASDAQ_OTCBB = "U"       # OTCBB (uppercase per API doc)


class MICId(StrEnum):
    """
    Market Identifier Codes (ISO 10383) returned in quote data.

    Used in askMICId, bidMICId, lastMICId fields.
    """
    XNYS = "XNYS"           # New York Stock Exchange
    XNAS = "XNAS"           # NASDAQ
    ARCX = "ARCX"           # NYSE Arca
    XADF = "XADF"           # FINRA ADF (Alternative Display Facility)
    MEMX = "MEMX"           # Members Exchange
    IEGX = "IEGX"           # Investors Exchange (IEX)
    EDGX = "EDGX"           # Cboe EDGX Exchange
    BATS = "BATS"           # Cboe BZX Exchange
    IEXG = "IEXG"           # IEX Group
    EPRL = "EPRL"           # MIAX Pearl Equities


class ExchangeName(StrEnum):
    """
    Human-readable exchange names returned in reference.exchangeName.
    """
    NASDAQ = "NASDAQ"
    NYSE = "NYSE"
    NYSE_ARCA = "NYSE Arca"
    OPR = "OPR"
    OTC_MARKETS = "OTC Markets"
    INDEX = "Index"
    XCME = "XCME"
    GFT = "GFT"
    MUTUAL_FUND = "Mutual Fund"
    NASDAQ_OTCBB = "Nasdaq OTCBB"


class OtcMarketTier(StrEnum):
    """OTC market tier for OTC-traded securities."""
    OTCQX = "QX"             # Best Market
    OTCQB = "QB"             # Venture Market
    PINK_CURRENT = "PC"      # Pink Current Information
    EXPERT_MARKET = "EM"     # Expert Market


class OptionContractChar(StrEnum):
    """Single-character contract type in option reference data."""
    CALL = "C"
    PUT = "P"


class OptionSettlementType(StrEnum):
    """Option settlement type in reference data."""
    PM = "P"                 # PM settlement (standard)
    AM = "A"                 # AM settlement


class OptionExpirationType(StrEnum):
    """UV expiration type in option reference data."""
    STANDARD = "S"
    WEEKLY = "W"
    QUARTERLY = "Q"
    MINI = "M"
    REDUCED_VALUE = "R"


class DividendFrequency(IntEnum):
    """Dividend frequency in fundamental data (divFreq field)."""
    NONE = 0
    ANNUAL = 1
    SEMI_ANNUAL = 2
    QUARTERLY = 4
    MONTHLY = 12


class FundStrategy(StrEnum):
    """Fund strategy for ETF fundamentals (fundStrategy field)."""
    ACTIVE = "A"
    PASSIVE = "P"


# ═══════════════════════════════════════════════════════════════════════════
# Orders — Request & Response
# ═══════════════════════════════════════════════════════════════════════════

class OrderType(StrEnum):
    """Order type for placing and querying orders."""
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP = "STOP"
    STOP_LIMIT = "STOP_LIMIT"
    TRAILING_STOP = "TRAILING_STOP"
    CABINET = "CABINET"
    NON_MARKETABLE = "NON_MARKETABLE"
    MARKET_ON_CLOSE = "MARKET_ON_CLOSE"
    EXERCISE = "EXERCISE"
    TRAILING_STOP_LIMIT = "TRAILING_STOP_LIMIT"
    NET_DEBIT = "NET_DEBIT"
    NET_CREDIT = "NET_CREDIT"
    NET_ZERO = "NET_ZERO"
    LIMIT_ON_CLOSE = "LIMIT_ON_CLOSE"


class Duration(StrEnum):
    """Order duration / time-in-force."""
    DAY = "DAY"
    GOOD_TILL_CANCEL = "GOOD_TILL_CANCEL"
    FILL_OR_KILL = "FILL_OR_KILL"
    IMMEDIATE_OR_CANCEL = "IMMEDIATE_OR_CANCEL"
    END_OF_WEEK = "END_OF_WEEK"
    END_OF_MONTH = "END_OF_MONTH"
    NEXT_END_OF_MONTH = "NEXT_END_OF_MONTH"


class Session(StrEnum):
    """Trading session for orders."""
    NORMAL = "NORMAL"
    AM = "AM"
    PM = "PM"
    SEAMLESS = "SEAMLESS"


class OrderStatus(StrEnum):
    """Order status values for filtering and responses."""
    AWAITING_PARENT_ORDER = "AWAITING_PARENT_ORDER"
    AWAITING_CONDITION = "AWAITING_CONDITION"
    AWAITING_STOP_CONDITION = "AWAITING_STOP_CONDITION"
    AWAITING_MANUAL_REVIEW = "AWAITING_MANUAL_REVIEW"
    ACCEPTED = "ACCEPTED"
    AWAITING_UR_OUT = "AWAITING_UR_OUT"
    PENDING_ACTIVATION = "PENDING_ACTIVATION"
    QUEUED = "QUEUED"
    WORKING = "WORKING"
    REJECTED = "REJECTED"
    PENDING_CANCEL = "PENDING_CANCEL"
    CANCELED = "CANCELED"
    PENDING_REPLACE = "PENDING_REPLACE"
    REPLACED = "REPLACED"
    FILLED = "FILLED"
    EXPIRED = "EXPIRED"
    NEW = "NEW"
    AWAITING_RELEASE_TIME = "AWAITING_RELEASE_TIME"
    PENDING_ACKNOWLEDGEMENT = "PENDING_ACKNOWLEDGEMENT"
    PENDING_RECALL = "PENDING_RECALL"
    UNKNOWN = "UNKNOWN"


class EquityInstruction(StrEnum):
    """Instruction for equity order legs."""
    BUY = "BUY"
    SELL = "SELL"
    SELL_SHORT = "SELL_SHORT"
    BUY_TO_COVER = "BUY_TO_COVER"


class OptionInstruction(StrEnum):
    """Instruction for option order legs."""
    BUY_TO_OPEN = "BUY_TO_OPEN"
    SELL_TO_CLOSE = "SELL_TO_CLOSE"
    SELL_TO_OPEN = "SELL_TO_OPEN"
    BUY_TO_CLOSE = "BUY_TO_CLOSE"


class AssetType(StrEnum):
    """Asset type for order placement (instrument.assetType in order legs)."""
    EQUITY = "EQUITY"
    OPTION = "OPTION"


class OrderStrategyType(StrEnum):
    """Order strategy type (single, conditional, etc.)."""
    SINGLE = "SINGLE"
    CANCEL = "CANCEL"
    RECALL = "RECALL"
    PAIR = "PAIR"
    FLATTEN = "FLATTEN"
    TWO_DAY_SWAP = "TWO_DAY_SWAP"
    BLAST_ALL = "BLAST_ALL"
    OCO = "OCO"
    TRIGGER = "TRIGGER"


class ComplexOrderStrategyType(StrEnum):
    """Complex order strategy type for multi-leg orders (complexOrderStrategyType)."""
    NONE = "NONE"
    COVERED = "COVERED"
    VERTICAL = "VERTICAL"
    BACK_RATIO = "BACK_RATIO"
    CALENDAR = "CALENDAR"
    DIAGONAL = "DIAGONAL"
    STRADDLE = "STRADDLE"
    STRANGLE = "STRANGLE"
    COLLAR_SYNTHETIC = "COLLAR_SYNTHETIC"
    BUTTERFLY = "BUTTERFLY"
    CONDOR = "CONDOR"
    IRON_CONDOR = "IRON_CONDOR"
    VERTICAL_ROLL = "VERTICAL_ROLL"
    COLLAR_WITH_STOCK = "COLLAR_WITH_STOCK"
    DOUBLE_DIAGONAL = "DOUBLE_DIAGONAL"
    UNBALANCED_BUTTERFLY = "UNBALANCED_BUTTERFLY"
    UNBALANCED_VERTICAL_ROLL = "UNBALANCED_VERTICAL_ROLL"
    UNBALANCED_CONDOR = "UNBALANCED_CONDOR"
    CUSTOM = "CUSTOM"


class RequestedDestination(StrEnum):
    """Order routing destination (requestedDestination)."""
    INET = "INET"
    ECN_ARCA = "ECN_ARCA"
    CBOE = "CBOE"
    AMEX = "AMEX"
    PHLX = "PHLX"
    ISE = "ISE"
    BOX = "BOX"
    NASDAQ = "NASDAQ"
    BATS = "BATS"
    C2 = "C2"
    AUTO = "AUTO"


class PriceLinkBasis(StrEnum):
    """Price link basis for stop/limit price calculations (stopPriceLinkBasis, priceLinkBasis)."""
    MANUAL = "MANUAL"
    BASE = "BASE"
    TRIGGER = "TRIGGER"
    LAST = "LAST"
    BID = "BID"
    ASK = "ASK"
    ASK_BID = "ASK_BID"
    MARK = "MARK"
    AVERAGE = "AVERAGE"


class PriceLinkType(StrEnum):
    """Price link type for trailing stops (stopPriceLinkType, priceLinkType)."""
    VALUE = "VALUE"
    PERCENT = "PERCENT"
    TICK = "TICK"


class StopType(StrEnum):
    """Stop price type (stopType)."""
    STANDARD = "STANDARD"
    BID = "BID"
    ASK = "ASK"
    LAST = "LAST"
    MARK = "MARK"


class TaxLotMethod(StrEnum):
    """Tax lot selection method (taxLotMethod)."""
    FIFO = "FIFO"
    LIFO = "LIFO"
    HIGH_COST = "HIGH_COST"
    LOW_COST = "LOW_COST"
    AVERAGE_COST = "AVERAGE_COST"
    SPECIFIC_LOT = "SPECIFIC_LOT"
    LOSS_HARVESTER = "LOSS_HARVESTER"


class OrderLegType(StrEnum):
    """Order leg asset type in responses (orderLegType)."""
    EQUITY = "EQUITY"
    OPTION = "OPTION"
    INDEX = "INDEX"
    MUTUAL_FUND = "MUTUAL_FUND"
    CASH_EQUIVALENT = "CASH_EQUIVALENT"
    FIXED_INCOME = "FIXED_INCOME"
    CURRENCY = "CURRENCY"


class PositionEffect(StrEnum):
    """Position effect for option orders (positionEffect)."""
    OPENING = "OPENING"
    CLOSING = "CLOSING"
    AUTOMATIC = "AUTOMATIC"


class QuantityType(StrEnum):
    """Quantity type for orders (quantityType)."""
    ALL_SHARES = "ALL_SHARES"
    DOLLARS = "DOLLARS"
    SHARES = "SHARES"


class DivCapGains(StrEnum):
    """Dividend/capital gains reinvestment preference (divCapGains)."""
    REINVEST = "REINVEST"
    PAYOUT = "PAYOUT"


class SpecialInstruction(StrEnum):
    """Special order instructions (specialInstruction)."""
    ALL_OR_NONE = "ALL_OR_NONE"
    DO_NOT_REDUCE = "DO_NOT_REDUCE"
    ALL_OR_NONE_DO_NOT_REDUCE = "ALL_OR_NONE_DO_NOT_REDUCE"


class ActivityType(StrEnum):
    """Order activity type (activityType)."""
    EXECUTION = "EXECUTION"
    ORDER_ACTION = "ORDER_ACTION"


class ExecutionType(StrEnum):
    """Execution type in order activity (executionType)."""
    FILL = "FILL"


class AdvancedOrderType(StrEnum):
    """Advanced order type in preview orders (advancedOrderType)."""
    NONE = "NONE"


class SettlementInstruction(StrEnum):
    """Settlement instruction (settlementInstruction)."""
    REGULAR = "REGULAR"


class OrderValidationSeverity(StrEnum):
    """Validation severity in order preview results (originalSeverity, overrideSeverity)."""
    ACCEPT = "ACCEPT"


class CommissionFeeType(StrEnum):
    """Commission/fee value type in preview orders (commissionAndFee type)."""
    COMMISSION = "COMMISSION"


# ═══════════════════════════════════════════════════════════════════════════
# Accounts
# ═══════════════════════════════════════════════════════════════════════════

class AccountInstrumentType(StrEnum):
    """Instrument type in account position responses (instrument.type)."""
    SWEEP_VEHICLE = "SWEEP_VEHICLE"
    CASH_EQUIVALENT = "CASH_EQUIVALENT"
    EQUITY = "EQUITY"
    OPTION = "OPTION"
    MUTUAL_FUND = "MUTUAL_FUND"
    FIXED_INCOME = "FIXED_INCOME"
    INDEX = "INDEX"
    CURRENCY = "CURRENCY"
    COLLECTIVE_INVESTMENT = "COLLECTIVE_INVESTMENT"


class AccountField(StrEnum):
    """Additional fields for account queries."""
    POSITIONS = "positions"


class TransactionType(StrEnum):
    """Transaction types for GET /accounts/{id}/transactions."""
    TRADE = "TRADE"
    RECEIVE_AND_DELIVER = "RECEIVE_AND_DELIVER"
    DIVIDEND_OR_INTEREST = "DIVIDEND_OR_INTEREST"
    ACH_RECEIPT = "ACH_RECEIPT"
    ACH_DISBURSEMENT = "ACH_DISBURSEMENT"
    CASH_RECEIPT = "CASH_RECEIPT"
    CASH_DISBURSEMENT = "CASH_DISBURSEMENT"
    ELECTRONIC_FUND = "ELECTRONIC_FUND"
    WIRE_OUT = "WIRE_OUT"
    WIRE_IN = "WIRE_IN"
    JOURNAL = "JOURNAL"
    MEMORANDUM = "MEMORANDUM"
    MARGIN_CALL = "MARGIN_CALL"
    MONEY_MARKET = "MONEY_MARKET"
    SMA_ADJUSTMENT = "SMA_ADJUSTMENT"


class TransactionStatus(StrEnum):
    """Transaction status in transaction responses (status)."""
    VALID = "VALID"


class TransactionSubAccount(StrEnum):
    """Sub-account type in transaction responses (subAccount)."""
    CASH = "CASH"


class TransactionActivityType(StrEnum):
    """Activity type in transaction responses (activityType). Distinct from order ActivityType."""
    ACTIVITY_CORRECTION = "ACTIVITY_CORRECTION"


class UserType(StrEnum):
    """User type in transaction responses (user.type)."""
    ADVISOR_USER = "ADVISOR_USER"


# ═══════════════════════════════════════════════════════════════════════════
# Streaming
# ═══════════════════════════════════════════════════════════════════════════

class StreamService(StrEnum):
    """WebSocket streaming service names."""
    ADMIN = "ADMIN"
    LEVELONE_EQUITIES = "LEVELONE_EQUITIES"
    LEVELONE_OPTIONS = "LEVELONE_OPTIONS"
    LEVELONE_FUTURES = "LEVELONE_FUTURES"
    LEVELONE_FUTURES_OPTIONS = "LEVELONE_FUTURES_OPTIONS"
    LEVELONE_FOREX = "LEVELONE_FOREX"
    NASDAQ_BOOK = "NASDAQ_BOOK"
    NYSE_BOOK = "NYSE_BOOK"
    OPTIONS_BOOK = "OPTIONS_BOOK"
    CHART_EQUITY = "CHART_EQUITY"
    CHART_FUTURES = "CHART_FUTURES"
    SCREENER_EQUITY = "SCREENER_EQUITY"
    SCREENER_OPTION = "SCREENER_OPTION"
    ACCT_ACTIVITY = "ACCT_ACTIVITY"


class StreamCommand(StrEnum):
    """WebSocket streaming commands."""
    LOGIN = "LOGIN"
    LOGOUT = "LOGOUT"
    SUBS = "SUBS"
    UNSUBS = "UNSUBS"
    ADD = "ADD"
    VIEW = "VIEW"


class StreamResponseCode(IntEnum):
    """Streaming WebSocket response codes."""
    SUCCESS = 0
    LOGIN_DENIED = 3
    UNKNOWN_FAILURE = 9
    SERVICE_NOT_AVAILABLE = 11
    CLOSE_CONNECTION = 12
    REACHED_SYMBOL_LIMIT = 19
    STREAM_CONN_NOT_FOUND = 20
    BAD_COMMAND_FORMAT = 21
    FAILED_COMMAND_SUBS = 22
    FAILED_COMMAND_UNSUBS = 23
    FAILED_COMMAND_ADD = 24
    FAILED_COMMAND_VIEW = 25
    SUCCEEDED_COMMAND_SUBS = 26
    SUCCEEDED_COMMAND_UNSUBS = 27
    SUCCEEDED_COMMAND_ADD = 28
    SUCCEEDED_COMMAND_VIEW = 29
    STOP_STREAMING = 30
