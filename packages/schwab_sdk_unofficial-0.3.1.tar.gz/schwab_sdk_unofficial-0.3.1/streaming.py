"""
Schwab SDK - Streaming

Admin (connect/login/logout), utilities (subscribe/add/unsubscribe/view),
callbacks (on_data/on_response/on_notify), and basic resubscription.

Provides two classes:
- ``Streaming``      – sync, backed by ``websocket-client``
- ``AsyncStreaming``  – async, backed by ``websockets``
"""

import asyncio
import json
import logging
import threading
import time
from typing import Any, Callable, Dict, List, Optional

from .enums import StreamService, StreamCommand
from ._utils import coerce_enum

try:
    import websocket  # websocket-client
except Exception:  # pragma: no cover
    websocket = None  # type: ignore

try:
    import websockets  # async websockets library
except Exception:  # pragma: no cover
    websockets = None  # type: ignore

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Default fields per streaming service (replaces 28 hardcoded occurrences)
# ---------------------------------------------------------------------------

_DEFAULT_FIELDS: Dict[str, List[int]] = {
    StreamService.LEVELONE_EQUITIES: [0, 1, 2, 3, 4, 5, 8, 10, 18, 42, 33, 34, 35],
    StreamService.LEVELONE_OPTIONS: [0, 2, 3, 4, 8, 16, 17, 18, 20, 28, 29, 30, 31, 37, 44],
    StreamService.LEVELONE_FUTURES: [0, 1, 2, 3, 4, 5, 8, 12, 13, 18, 19, 20, 24, 33],
    StreamService.LEVELONE_FUTURES_OPTIONS: [0, 1, 2, 3, 4, 5, 8, 12, 13, 17, 18, 19, 23, 24, 25, 29],
    StreamService.LEVELONE_FOREX: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 15, 16, 17, 20, 21, 27, 28, 29],
    StreamService.NASDAQ_BOOK: [0, 1, 2, 3],
    StreamService.NYSE_BOOK: [0, 1, 2, 3],
    StreamService.OPTIONS_BOOK: [0, 1, 2, 3],
    StreamService.CHART_EQUITY: [0, 1, 2, 3, 4, 5, 6, 7],
    StreamService.CHART_FUTURES: [0, 1, 2, 3, 4, 5, 6],
    StreamService.SCREENER_EQUITY: [0, 1, 2, 3, 4],
    StreamService.SCREENER_OPTION: [0, 1, 2, 3, 4],
    StreamService.ACCT_ACTIVITY: [0, 1, 2, 3],
}


# ---------------------------------------------------------------------------
# Sync Streaming (websocket-client)
# ---------------------------------------------------------------------------

class Streaming:
    """
    WebSocket Streaming client for Schwab (sync).

    - ADMIN: connect/login/logout
    - Common utilities: subscribe/add/unsubscribe/view
    - Callbacks: on_data/on_response/on_notify
    - Resubscription after reconnect
    """

    STREAM_URL = "wss://stream.schwabapi.com/v1/ws"

    def __init__(self, client) -> None:
        self.client = client

        # WebSocket
        self._ws: Optional[websocket.WebSocketApp] = None  # type: ignore
        self._thread: Optional[threading.Thread] = None
        self._should_run = False
        self._connected_event = threading.Event()

        # Callbacks
        self._on_data: Optional[Callable[[Dict[str, Any]], None]] = None
        self._on_response: Optional[Callable[[Dict[str, Any]], None]] = None
        self._on_notify: Optional[Callable[[Dict[str, Any]], None]] = None

        # State
        self._is_logged_in = False
        self._subscriptions: List[Dict[str, Any]] = []  # history of SUBS/ADD/VIEW commands
        self._last_login_payload: Optional[Dict[str, Any]] = None
        self._request_counter: int = 1

        # Streamer info (dynamic from userPreference)
        self._streamer_url: Optional[str] = None
        self._schwab_client_customer_id: Optional[str] = None
        self._schwab_client_correl_id: Optional[str] = None
        self._schwab_client_channel: Optional[str] = None
        self._schwab_client_function_id: Optional[str] = None

    # ============================ Streamer info ==============================
    def _ensure_streamer_info(self) -> None:
        if self._streamer_url and self._schwab_client_customer_id and self._schwab_client_channel and self._schwab_client_function_id:
            return

        try:
            prefs = self.client.account.get_user_preferences()
        except Exception:
            # Try to refresh and retry once
            if hasattr(self.client, "refresh_token_now"):
                try:
                    self.client.refresh_token_now()
                except Exception:
                    pass
            prefs = self.client.account.get_user_preferences()

        _parse_streamer_info(self, prefs)

    # ========================= Callback registration =========================
    def on_data(self, callback: Callable[[Dict[str, Any]], None]) -> None:
        self._on_data = callback

    def on_response(self, callback: Callable[[Dict[str, Any]], None]) -> None:
        self._on_response = callback

    def on_notify(self, callback: Callable[[Dict[str, Any]], None]) -> None:
        self._on_notify = callback

    # =============================== Connection ==============================
    def connect(self) -> None:
        if websocket is None:
            raise RuntimeError("The websocket-client library is not installed. 'pip install websocket-client'")

        if self._ws is not None:
            return

        self._should_run = True
        # Ensure streamer info and dynamic URL
        self._ensure_streamer_info()

        self._ws = websocket.WebSocketApp(
            self._streamer_url or self.STREAM_URL,
            on_open=self._on_open,
            on_close=self._on_close,
            on_error=self._on_error,
            on_message=self._on_message,
        )

        def _runner() -> None:
            while self._should_run:
                try:
                    self._ws.run_forever(ping_interval=20, ping_timeout=10)  # type: ignore
                except Exception:
                    pass
                if self._should_run:
                    time.sleep(2)  # simple backoff before retrying

        self._thread = threading.Thread(target=_runner, daemon=True)
        self._thread.start()

    def wait_until_connected(self, timeout: float = 10.0) -> bool:
        """Wait until the socket is open or timeout expires."""
        return self._connected_event.wait(timeout)

    def login(
        self,
        authorization: Optional[str] = None,
        *,
        customer_id: Optional[str] = None,
        correl_id: Optional[str] = None,
        channel: Optional[str] = None,
        function_id: Optional[str] = None,
    ) -> None:
        # Prepare authorization: use current access token if not provided
        if authorization is None:
            token = self.client.get_access_token()
            if not token:
                # Try immediate refresh and then obtain token again
                try:
                    refreshed = False
                    if hasattr(self.client, "refresh_token_now"):
                        refreshed = bool(self.client.refresh_token_now())
                    if not refreshed and hasattr(self.client, "refresh_token"):
                        refreshed = bool(self.client.refresh_token())
                    if refreshed:
                        token = self.client.get_access_token()
                except Exception:
                    token = None
            if not token:
                raise RuntimeError("No access token for streaming. Run client.login() to authenticate.")
            # WS LOGIN requires Authorization without 'Bearer' prefix
            authorization = token

        # Allow pulling customer/correl from userPreference if missing
        if not (customer_id and correl_id and channel and function_id):
            # Use cached streamer info
            self._ensure_streamer_info()
            customer_id = customer_id or self._schwab_client_customer_id
            correl_id = correl_id or self._schwab_client_correl_id
            channel = channel or self._schwab_client_channel
            function_id = function_id or self._schwab_client_function_id

        payload = {
            "requests": [
                {
                    "service": "ADMIN",
                    "requestid": str(self._request_counter),
                    "command": "LOGIN",
                    "SchwabClientCustomerId": customer_id,
                    "SchwabClientCorrelId": correl_id,
                    "parameters": {
                        "Authorization": authorization,
                        "SchwabClientChannel": channel,
                        "SchwabClientFunctionId": function_id,
                    },
                }
            ]
        }
        self._request_counter += 1

        self._last_login_payload = payload
        # Ensure the connection is open
        if not self.wait_until_connected(10.0):
            raise RuntimeError("WebSocket did not connect within the expected time")
        self._send(payload)

    def logout(self, *, customer_id: Optional[str] = None, correl_id: Optional[str] = None) -> None:
        if not self._is_logged_in:
            return
        rid = str(self._request_counter)
        self._request_counter += 1
        payload = {
            "requests": [
                {
                    "service": "ADMIN",
                    "requestid": rid,
                    "command": "LOGOUT",
                    "SchwabClientCustomerId": customer_id or self._schwab_client_customer_id or "",
                    "SchwabClientCorrelId": correl_id or self._schwab_client_correl_id or "",
                    "parameters": {},
                }
            ]
        }
        self._send(payload)
        self._is_logged_in = False

    # ================================ Utilities ===============================
    def subscribe(self, service: str, keys: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        service = coerce_enum(service, StreamService, "service")
        self._common_request(StreamCommand.SUBS, service, keys, fields, request_id)

    def add(self, service: str, keys: List[str], request_id: Optional[str] = None) -> None:
        service = coerce_enum(service, StreamService, "service")
        self._common_request(StreamCommand.ADD, service, keys, None, request_id)

    def unsubscribe(self, service: str, keys: List[str], request_id: Optional[str] = None) -> None:
        service = coerce_enum(service, StreamService, "service")
        self._common_request(StreamCommand.UNSUBS, service, keys, None, request_id)

    def view(self, service: str, fields: List[int], request_id: Optional[str] = None) -> None:
        service = coerce_enum(service, StreamService, "service")
        self._common_request(StreamCommand.VIEW, service, [], fields, request_id)

    # =========================== Helpers per service ==========================
    # LEVELONE_EQUITIES
    def equities_subscribe(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.LEVELONE_EQUITIES]
        self._common_request(StreamCommand.SUBS, StreamService.LEVELONE_EQUITIES, symbols, fields, request_id)

    def equities_add(self, symbols: List[str], request_id: Optional[str] = None) -> None:
        self._common_request(StreamCommand.ADD, StreamService.LEVELONE_EQUITIES, symbols, None, request_id)

    def equities_unsubscribe(self, symbols: List[str], request_id: Optional[str] = None) -> None:
        self._common_request(StreamCommand.UNSUBS, StreamService.LEVELONE_EQUITIES, symbols, None, request_id)

    def equities_view(self, fields: List[int], request_id: Optional[str] = None) -> None:
        self._common_request(StreamCommand.VIEW, StreamService.LEVELONE_EQUITIES, [], fields, request_id)

    # LEVELONE_OPTIONS
    def options_subscribe(self, option_keys: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.LEVELONE_OPTIONS]
        self._common_request(StreamCommand.SUBS, StreamService.LEVELONE_OPTIONS, option_keys, fields, request_id)

    def options_add(self, option_keys: List[str], request_id: Optional[str] = None) -> None:
        self._common_request(StreamCommand.ADD, StreamService.LEVELONE_OPTIONS, option_keys, None, request_id)

    def options_unsubscribe(self, option_keys: List[str], request_id: Optional[str] = None) -> None:
        self._common_request(StreamCommand.UNSUBS, StreamService.LEVELONE_OPTIONS, option_keys, None, request_id)

    def options_view(self, fields: List[int], request_id: Optional[str] = None) -> None:
        self._common_request(StreamCommand.VIEW, StreamService.LEVELONE_OPTIONS, [], fields, request_id)

    # LEVELONE_FUTURES
    def futures_subscribe(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.LEVELONE_FUTURES]
        self._common_request(StreamCommand.SUBS, StreamService.LEVELONE_FUTURES, symbols, fields, request_id)

    def futures_add(self, symbols: List[str], request_id: Optional[str] = None) -> None:
        self._common_request(StreamCommand.ADD, StreamService.LEVELONE_FUTURES, symbols, None, request_id)

    def futures_unsubscribe(self, symbols: List[str], request_id: Optional[str] = None) -> None:
        self._common_request(StreamCommand.UNSUBS, StreamService.LEVELONE_FUTURES, symbols, None, request_id)

    def futures_view(self, fields: List[int], request_id: Optional[str] = None) -> None:
        self._common_request(StreamCommand.VIEW, StreamService.LEVELONE_FUTURES, [], fields, request_id)

    # LEVELONE_FUTURES_OPTIONS
    def futures_options_subscribe(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.LEVELONE_FUTURES_OPTIONS]
        self._common_request(StreamCommand.SUBS, StreamService.LEVELONE_FUTURES_OPTIONS, symbols, fields, request_id)

    def futures_options_add(self, symbols: List[str], request_id: Optional[str] = None) -> None:
        self._common_request(StreamCommand.ADD, StreamService.LEVELONE_FUTURES_OPTIONS, symbols, None, request_id)

    def futures_options_unsubscribe(self, symbols: List[str], request_id: Optional[str] = None) -> None:
        self._common_request(StreamCommand.UNSUBS, StreamService.LEVELONE_FUTURES_OPTIONS, symbols, None, request_id)

    def futures_options_view(self, fields: List[int], request_id: Optional[str] = None) -> None:
        self._common_request(StreamCommand.VIEW, StreamService.LEVELONE_FUTURES_OPTIONS, [], fields, request_id)

    # LEVELONE_FOREX
    def forex_subscribe(self, pairs: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.LEVELONE_FOREX]
        self._common_request(StreamCommand.SUBS, StreamService.LEVELONE_FOREX, pairs, fields, request_id)

    def forex_add(self, pairs: List[str], request_id: Optional[str] = None) -> None:
        self._common_request(StreamCommand.ADD, StreamService.LEVELONE_FOREX, pairs, None, request_id)

    def forex_unsubscribe(self, pairs: List[str], request_id: Optional[str] = None) -> None:
        self._common_request(StreamCommand.UNSUBS, StreamService.LEVELONE_FOREX, pairs, None, request_id)

    def forex_view(self, fields: List[int], request_id: Optional[str] = None) -> None:
        self._common_request(StreamCommand.VIEW, StreamService.LEVELONE_FOREX, [], fields, request_id)

    # ===== BOOK (NYSE/NASDAQ/OPTIONS) =====
    def nasdaq_book(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.NASDAQ_BOOK]
        self._common_request(StreamCommand.SUBS, StreamService.NASDAQ_BOOK, symbols, fields, request_id)

    def nyse_book(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.NYSE_BOOK]
        self._common_request(StreamCommand.SUBS, StreamService.NYSE_BOOK, symbols, fields, request_id)

    def options_book(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.OPTIONS_BOOK]
        self._common_request(StreamCommand.SUBS, StreamService.OPTIONS_BOOK, symbols, fields, request_id)

    # ===== CHART (EQUITY/FUTURES) =====
    def chart_equity(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.CHART_EQUITY]
        self._common_request(StreamCommand.SUBS, StreamService.CHART_EQUITY, symbols, fields, request_id)

    def chart_futures(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.CHART_FUTURES]
        self._common_request(StreamCommand.SUBS, StreamService.CHART_FUTURES, symbols, fields, request_id)

    # ===== SCREENER (EQUITY/OPTION) =====
    def screener_equity(self, keys: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.SCREENER_EQUITY]
        self._common_request(StreamCommand.SUBS, StreamService.SCREENER_EQUITY, keys, fields, request_id)

    def screener_options(self, keys: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.SCREENER_OPTION]
        self._common_request(StreamCommand.SUBS, StreamService.SCREENER_OPTION, keys, fields, request_id)

    # ===== ACCT_ACTIVITY =====
    def account_activity(self, fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.ACCT_ACTIVITY]
        # Obtain account hash if not cached
        account_hash = getattr(self.client, "_account_hash", None)
        if not account_hash:
            try:
                accounts = self.client.account.get_account_numbers()
                if isinstance(accounts, list) and accounts:
                    account_hash = (
                        accounts[0].get("accountHash")
                        or accounts[0].get("hashValue")
                        or accounts[0].get("hash")
                    )
                    self.client._account_hash = account_hash
            except Exception:
                account_hash = None
        if not account_hash:
            raise RuntimeError("Could not obtain account hash for ACCT_ACTIVITY")
        self._common_request(StreamCommand.SUBS, StreamService.ACCT_ACTIVITY, [account_hash], fields, request_id)

    # ===== UNSUBSCRIBE helper per service =====
    def unsubscribe_service(self, service: str, keys: List[str], request_id: Optional[str] = None) -> None:
        service = coerce_enum(service, StreamService, "service")
        self._common_request(StreamCommand.UNSUBS, service, keys, None, request_id)

    def _common_request(
        self,
        command: str,
        service: str,
        keys: List[str],
        fields: Optional[List[int]] = None,
        request_id: Optional[str] = None,
    ) -> None:
        rid = request_id or str(self._request_counter)
        self._request_counter += 1

        # Ensure streamer IDs
        self._ensure_streamer_info()

        # Per-request correl id
        correl = f"{service.lower()}_{int(time.time()*1000)}"
        params: Dict[str, Any] = {"keys": ",".join(keys) if keys else ""}
        if fields is not None:
            params["fields"] = ",".join(map(str, fields))

        payload: Dict[str, Any] = {
            "requests": [
                {
                    "service": service,
                    "command": command,
                    "requestid": rid,
                    "SchwabClientCustomerId": self._schwab_client_customer_id,
                    "SchwabClientCorrelId": correl,
                    "parameters": params,
                }
            ]
        }

        self._subscriptions.append(payload)
        self._send(payload)

    # ================================ Internals ================================
    def _send(self, payload: Dict[str, Any]) -> None:
        msg = json.dumps(payload, separators=(",", ":"))
        if self._ws is None:
            raise RuntimeError("WebSocket not connected. Call connect() first.")
        try:
            self._ws.send(msg)  # type: ignore
        except Exception as e:
            raise RuntimeError(f"Error sending WS message: {e}")

    def _on_open(self, _ws) -> None:
        self._connected_event.set()
        if self._last_login_payload:
            try:
                self._send(self._last_login_payload)
            except Exception:
                pass

    def _on_close(self, _ws, *_args) -> None:
        self._is_logged_in = False
        self._connected_event.clear()

    def _on_error(self, _ws, error) -> None:
        if self._on_response:
            try:
                self._on_response({"service": "SYSTEM", "command": "ERROR", "content": {"message": str(error)}})
            except Exception:
                pass

    def _on_message(self, _ws, message: str) -> None:
        _dispatch_message(self, message)

    # ============================== Option Symbol Helper =============================
    @staticmethod
    def create_option_symbol(symbol: str, expiration: str, option_type: str, strike_price: float) -> str:
        """
        Creates a Schwab option symbol from individual components.

        Args:
            symbol: Underlying symbol (e.g., "AAPL")
            expiration: Expiration date in format "YYYY-MM-DD" (e.g., "2025-10-03")
            option_type: Option type "C" for Call or "P" for Put
            strike_price: Strike price (e.g., 257.5)

        Returns:
            Formatted option symbol for Schwab streaming (e.g., "AAPL  251219C00200000")
        """
        return _create_option_symbol(symbol, expiration, option_type, strike_price)

    # ============================== Resubscription =============================
    def _resubscribe_all(self) -> None:
        for payload in list(self._subscriptions):
            try:
                self._send(payload)
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Async Streaming (websockets)
# ---------------------------------------------------------------------------

class AsyncStreaming:
    """
    Async WebSocket Streaming client for Schwab.

    Uses the ``websockets`` library for async I/O.

    Usage::

        async with AsyncClient(...) as client:
            ws = client.streaming
            ws.on_data(my_handler)
            await ws.connect()
            await ws.login()
            await ws.equities_subscribe(["AAPL", "MSFT"])
            # keep running...
    """

    STREAM_URL = "wss://stream.schwabapi.com/v1/ws"

    def __init__(self, client) -> None:
        self.client = client

        # WebSocket
        self._ws = None  # websockets connection
        self._receive_task: Optional[asyncio.Task] = None
        self._should_run = False
        self._connected_event = asyncio.Event()

        # Callbacks
        self._on_data: Optional[Callable[[Dict[str, Any]], None]] = None
        self._on_response: Optional[Callable[[Dict[str, Any]], None]] = None
        self._on_notify: Optional[Callable[[Dict[str, Any]], None]] = None

        # State
        self._is_logged_in = False
        self._subscriptions: List[Dict[str, Any]] = []
        self._last_login_payload: Optional[Dict[str, Any]] = None
        self._request_counter: int = 1

        # Streamer info
        self._streamer_url: Optional[str] = None
        self._schwab_client_customer_id: Optional[str] = None
        self._schwab_client_correl_id: Optional[str] = None
        self._schwab_client_channel: Optional[str] = None
        self._schwab_client_function_id: Optional[str] = None

    # ============================ Streamer info ==============================
    async def _ensure_streamer_info(self) -> None:
        if self._streamer_url and self._schwab_client_customer_id and self._schwab_client_channel and self._schwab_client_function_id:
            return

        try:
            prefs = await self.client.account.get_user_preferences()
        except Exception:
            if hasattr(self.client, "refresh_token_now"):
                try:
                    await self.client.refresh_token_now()
                except Exception:
                    pass
            prefs = await self.client.account.get_user_preferences()

        _parse_streamer_info(self, prefs)

    # ========================= Callback registration =========================
    def on_data(self, callback: Callable[[Dict[str, Any]], None]) -> None:
        self._on_data = callback

    def on_response(self, callback: Callable[[Dict[str, Any]], None]) -> None:
        self._on_response = callback

    def on_notify(self, callback: Callable[[Dict[str, Any]], None]) -> None:
        self._on_notify = callback

    # =============================== Connection ==============================
    async def connect(self) -> None:
        if websockets is None:
            raise RuntimeError("The websockets library is not installed. 'pip install websockets'")

        if self._ws is not None:
            return

        self._should_run = True
        await self._ensure_streamer_info()

        url = self._streamer_url or self.STREAM_URL
        self._ws = await websockets.connect(url, ping_interval=20, ping_timeout=10)
        self._connected_event.set()

        # Start receive loop
        self._receive_task = asyncio.create_task(self._receive_loop())

        # Re-login if we had a previous session
        if self._last_login_payload:
            await self._send(self._last_login_payload)

    async def _receive_loop(self) -> None:
        """Background task that reads messages from the WebSocket."""
        try:
            async for message in self._ws:
                _dispatch_message(self, message)
        except Exception:
            self._is_logged_in = False
            self._connected_event.clear()
            # Reconnect if desired
            if self._should_run:
                await asyncio.sleep(2)
                self._ws = None
                try:
                    await self.connect()
                except Exception:
                    pass

    async def wait_until_connected(self, timeout: float = 10.0) -> bool:
        """Wait until the socket is open or timeout expires."""
        try:
            await asyncio.wait_for(self._connected_event.wait(), timeout=timeout)
            return True
        except asyncio.TimeoutError:
            return False

    async def login(
        self,
        authorization: Optional[str] = None,
        *,
        customer_id: Optional[str] = None,
        correl_id: Optional[str] = None,
        channel: Optional[str] = None,
        function_id: Optional[str] = None,
    ) -> None:
        if authorization is None:
            token = self.client.get_access_token()
            if not token:
                try:
                    refreshed = False
                    if hasattr(self.client, "refresh_token_now"):
                        refreshed = bool(await self.client.refresh_token_now())
                    if refreshed:
                        token = self.client.get_access_token()
                except Exception:
                    token = None
            if not token:
                raise RuntimeError("No access token for streaming. Authenticate first.")
            authorization = token

        if not (customer_id and correl_id and channel and function_id):
            await self._ensure_streamer_info()
            customer_id = customer_id or self._schwab_client_customer_id
            correl_id = correl_id or self._schwab_client_correl_id
            channel = channel or self._schwab_client_channel
            function_id = function_id or self._schwab_client_function_id

        payload = {
            "requests": [
                {
                    "service": "ADMIN",
                    "requestid": str(self._request_counter),
                    "command": "LOGIN",
                    "SchwabClientCustomerId": customer_id,
                    "SchwabClientCorrelId": correl_id,
                    "parameters": {
                        "Authorization": authorization,
                        "SchwabClientChannel": channel,
                        "SchwabClientFunctionId": function_id,
                    },
                }
            ]
        }
        self._request_counter += 1
        self._last_login_payload = payload

        if not await self.wait_until_connected(10.0):
            raise RuntimeError("WebSocket did not connect within the expected time")
        await self._send(payload)

    async def logout(self, *, customer_id: Optional[str] = None, correl_id: Optional[str] = None) -> None:
        if not self._is_logged_in:
            return
        rid = str(self._request_counter)
        self._request_counter += 1
        payload = {
            "requests": [
                {
                    "service": "ADMIN",
                    "requestid": rid,
                    "command": "LOGOUT",
                    "SchwabClientCustomerId": customer_id or self._schwab_client_customer_id or "",
                    "SchwabClientCorrelId": correl_id or self._schwab_client_correl_id or "",
                    "parameters": {},
                }
            ]
        }
        await self._send(payload)
        self._is_logged_in = False

    async def disconnect(self) -> None:
        """Close the WebSocket connection."""
        self._should_run = False
        if self._receive_task and not self._receive_task.done():
            self._receive_task.cancel()
        if self._ws:
            await self._ws.close()
            self._ws = None
        self._connected_event.clear()

    # ================================ Utilities ===============================
    async def subscribe(self, service: str, keys: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        service = coerce_enum(service, StreamService, "service")
        await self._common_request(StreamCommand.SUBS, service, keys, fields, request_id)

    async def add(self, service: str, keys: List[str], request_id: Optional[str] = None) -> None:
        service = coerce_enum(service, StreamService, "service")
        await self._common_request(StreamCommand.ADD, service, keys, None, request_id)

    async def unsubscribe(self, service: str, keys: List[str], request_id: Optional[str] = None) -> None:
        service = coerce_enum(service, StreamService, "service")
        await self._common_request(StreamCommand.UNSUBS, service, keys, None, request_id)

    async def view(self, service: str, fields: List[int], request_id: Optional[str] = None) -> None:
        service = coerce_enum(service, StreamService, "service")
        await self._common_request(StreamCommand.VIEW, service, [], fields, request_id)

    # =========================== Helpers per service ==========================
    async def equities_subscribe(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.LEVELONE_EQUITIES]
        await self._common_request(StreamCommand.SUBS, StreamService.LEVELONE_EQUITIES, symbols, fields, request_id)

    async def equities_add(self, symbols: List[str], request_id: Optional[str] = None) -> None:
        await self._common_request(StreamCommand.ADD, StreamService.LEVELONE_EQUITIES, symbols, None, request_id)

    async def equities_unsubscribe(self, symbols: List[str], request_id: Optional[str] = None) -> None:
        await self._common_request(StreamCommand.UNSUBS, StreamService.LEVELONE_EQUITIES, symbols, None, request_id)

    async def equities_view(self, fields: List[int], request_id: Optional[str] = None) -> None:
        await self._common_request(StreamCommand.VIEW, StreamService.LEVELONE_EQUITIES, [], fields, request_id)

    async def options_subscribe(self, option_keys: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.LEVELONE_OPTIONS]
        await self._common_request(StreamCommand.SUBS, StreamService.LEVELONE_OPTIONS, option_keys, fields, request_id)

    async def options_add(self, option_keys: List[str], request_id: Optional[str] = None) -> None:
        await self._common_request(StreamCommand.ADD, StreamService.LEVELONE_OPTIONS, option_keys, None, request_id)

    async def options_unsubscribe(self, option_keys: List[str], request_id: Optional[str] = None) -> None:
        await self._common_request(StreamCommand.UNSUBS, StreamService.LEVELONE_OPTIONS, option_keys, None, request_id)

    async def options_view(self, fields: List[int], request_id: Optional[str] = None) -> None:
        await self._common_request(StreamCommand.VIEW, StreamService.LEVELONE_OPTIONS, [], fields, request_id)

    async def futures_subscribe(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.LEVELONE_FUTURES]
        await self._common_request(StreamCommand.SUBS, StreamService.LEVELONE_FUTURES, symbols, fields, request_id)

    async def futures_add(self, symbols: List[str], request_id: Optional[str] = None) -> None:
        await self._common_request(StreamCommand.ADD, StreamService.LEVELONE_FUTURES, symbols, None, request_id)

    async def futures_unsubscribe(self, symbols: List[str], request_id: Optional[str] = None) -> None:
        await self._common_request(StreamCommand.UNSUBS, StreamService.LEVELONE_FUTURES, symbols, None, request_id)

    async def futures_view(self, fields: List[int], request_id: Optional[str] = None) -> None:
        await self._common_request(StreamCommand.VIEW, StreamService.LEVELONE_FUTURES, [], fields, request_id)

    async def futures_options_subscribe(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.LEVELONE_FUTURES_OPTIONS]
        await self._common_request(StreamCommand.SUBS, StreamService.LEVELONE_FUTURES_OPTIONS, symbols, fields, request_id)

    async def futures_options_add(self, symbols: List[str], request_id: Optional[str] = None) -> None:
        await self._common_request(StreamCommand.ADD, StreamService.LEVELONE_FUTURES_OPTIONS, symbols, None, request_id)

    async def futures_options_unsubscribe(self, symbols: List[str], request_id: Optional[str] = None) -> None:
        await self._common_request(StreamCommand.UNSUBS, StreamService.LEVELONE_FUTURES_OPTIONS, symbols, None, request_id)

    async def futures_options_view(self, fields: List[int], request_id: Optional[str] = None) -> None:
        await self._common_request(StreamCommand.VIEW, StreamService.LEVELONE_FUTURES_OPTIONS, [], fields, request_id)

    async def forex_subscribe(self, pairs: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.LEVELONE_FOREX]
        await self._common_request(StreamCommand.SUBS, StreamService.LEVELONE_FOREX, pairs, fields, request_id)

    async def forex_add(self, pairs: List[str], request_id: Optional[str] = None) -> None:
        await self._common_request(StreamCommand.ADD, StreamService.LEVELONE_FOREX, pairs, None, request_id)

    async def forex_unsubscribe(self, pairs: List[str], request_id: Optional[str] = None) -> None:
        await self._common_request(StreamCommand.UNSUBS, StreamService.LEVELONE_FOREX, pairs, None, request_id)

    async def forex_view(self, fields: List[int], request_id: Optional[str] = None) -> None:
        await self._common_request(StreamCommand.VIEW, StreamService.LEVELONE_FOREX, [], fields, request_id)

    async def nasdaq_book(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.NASDAQ_BOOK]
        await self._common_request(StreamCommand.SUBS, StreamService.NASDAQ_BOOK, symbols, fields, request_id)

    async def nyse_book(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.NYSE_BOOK]
        await self._common_request(StreamCommand.SUBS, StreamService.NYSE_BOOK, symbols, fields, request_id)

    async def options_book(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.OPTIONS_BOOK]
        await self._common_request(StreamCommand.SUBS, StreamService.OPTIONS_BOOK, symbols, fields, request_id)

    async def chart_equity(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.CHART_EQUITY]
        await self._common_request(StreamCommand.SUBS, StreamService.CHART_EQUITY, symbols, fields, request_id)

    async def chart_futures(self, symbols: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.CHART_FUTURES]
        await self._common_request(StreamCommand.SUBS, StreamService.CHART_FUTURES, symbols, fields, request_id)

    async def screener_equity(self, keys: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.SCREENER_EQUITY]
        await self._common_request(StreamCommand.SUBS, StreamService.SCREENER_EQUITY, keys, fields, request_id)

    async def screener_options(self, keys: List[str], fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.SCREENER_OPTION]
        await self._common_request(StreamCommand.SUBS, StreamService.SCREENER_OPTION, keys, fields, request_id)

    async def account_activity(self, fields: Optional[List[int]] = None, request_id: Optional[str] = None) -> None:
        if fields is None:
            fields = _DEFAULT_FIELDS[StreamService.ACCT_ACTIVITY]
        account_hash = getattr(self.client, "_account_hash", None)
        if not account_hash:
            try:
                accounts = await self.client.account.get_account_numbers()
                if isinstance(accounts, list) and accounts:
                    account_hash = (
                        accounts[0].get("accountHash")
                        or accounts[0].get("hashValue")
                        or accounts[0].get("hash")
                    )
                    self.client._account_hash = account_hash
            except Exception:
                account_hash = None
        if not account_hash:
            raise RuntimeError("Could not obtain account hash for ACCT_ACTIVITY")
        await self._common_request(StreamCommand.SUBS, StreamService.ACCT_ACTIVITY, [account_hash], fields, request_id)

    async def unsubscribe_service(self, service: str, keys: List[str], request_id: Optional[str] = None) -> None:
        service = coerce_enum(service, StreamService, "service")
        await self._common_request(StreamCommand.UNSUBS, service, keys, None, request_id)

    async def _common_request(
        self,
        command: str,
        service: str,
        keys: List[str],
        fields: Optional[List[int]] = None,
        request_id: Optional[str] = None,
    ) -> None:
        rid = request_id or str(self._request_counter)
        self._request_counter += 1

        await self._ensure_streamer_info()

        correl = f"{service.lower()}_{int(time.time()*1000)}"
        params: Dict[str, Any] = {"keys": ",".join(keys) if keys else ""}
        if fields is not None:
            params["fields"] = ",".join(map(str, fields))

        payload: Dict[str, Any] = {
            "requests": [
                {
                    "service": service,
                    "command": command,
                    "requestid": rid,
                    "SchwabClientCustomerId": self._schwab_client_customer_id,
                    "SchwabClientCorrelId": correl,
                    "parameters": params,
                }
            ]
        }

        self._subscriptions.append(payload)
        await self._send(payload)

    # ================================ Internals ================================
    async def _send(self, payload: Dict[str, Any]) -> None:
        msg = json.dumps(payload, separators=(",", ":"))
        if self._ws is None:
            raise RuntimeError("WebSocket not connected. Call connect() first.")
        try:
            await self._ws.send(msg)
        except Exception as e:
            raise RuntimeError(f"Error sending WS message: {e}")

    async def _resubscribe_all(self) -> None:
        for payload in list(self._subscriptions):
            try:
                await self._send(payload)
            except Exception:
                pass

    @staticmethod
    def create_option_symbol(symbol: str, expiration: str, option_type: str, strike_price: float) -> str:
        return _create_option_symbol(symbol, expiration, option_type, strike_price)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _parse_streamer_info(obj, prefs) -> None:
    """Parse streamer info from user preferences into obj attributes."""
    streamer_info = None
    if isinstance(prefs, dict):
        si = prefs.get("streamerInfo") or prefs.get("streamerinfo")
        if isinstance(si, list) and si:
            streamer_info = si[0]
        elif isinstance(si, dict):
            streamer_info = si
    if streamer_info and isinstance(streamer_info, dict):
        obj._streamer_url = streamer_info.get("streamerSocketUrl") or prefs.get("streamerSocketUrl")
    else:
        obj._streamer_url = prefs.get("streamerSocketUrl") if isinstance(prefs, dict) else None

    obj._schwab_client_customer_id = (
        prefs.get("schwabClientCustomerId") if isinstance(prefs, dict) else None
    ) or (streamer_info.get("schwabClientCustomerId") if isinstance(streamer_info, dict) else None)
    obj._schwab_client_correl_id = (
        (prefs.get("schwabClientCorrelId") if isinstance(prefs, dict) else None)
        or (streamer_info.get("schwabClientCorrelId") if isinstance(streamer_info, dict) else None)
        or f"correl_{int(time.time()*1000)}"
    )
    obj._schwab_client_channel = (
        (prefs.get("SchwabClientChannel") if isinstance(prefs, dict) else None)
        or (streamer_info.get("SchwabClientChannel") if isinstance(streamer_info, dict) else None)
        or "N9"
    )
    obj._schwab_client_function_id = (
        (prefs.get("SchwabClientFunctionId") if isinstance(prefs, dict) else None)
        or (streamer_info.get("SchwabClientFunctionId") if isinstance(streamer_info, dict) else None)
        or "APIAPP"
    )

    if not obj._streamer_url:
        obj._streamer_url = obj.STREAM_URL


def _dispatch_message(obj, message: str) -> None:
    """Dispatch a raw WS message to the appropriate callbacks on obj.

    Handles three message types per the Schwab Streamer API:
    - ``{"response": [...]}`` — command responses (login, subs confirmations)
    - ``{"notify": [...]}`` — heartbeat notifications
    - ``{"data": [...]}`` — streaming market data
    """
    try:
        data = json.loads(message)
    except Exception:
        return

    if not isinstance(data, dict):
        return

    # 1. Streaming market data
    if "data" in data and isinstance(data["data"], list):
        for item in data["data"]:
            if obj._on_data:
                obj._on_data(item)
        return

    # 2. Heartbeat notifications
    if "notify" in data:
        if obj._on_notify:
            obj._on_notify(data)
        return

    # 3. Command responses (login, subs, unsubs, add, view, logout)
    if "response" in data and isinstance(data["response"], list):
        for item in data["response"]:
            service = str(item.get("service", "")).upper()
            command = str(item.get("command", "")).upper()

            if service == "ADMIN" and command == "LOGIN":
                code = item.get("content", {}).get("code")
                if code == 0:
                    obj._is_logged_in = True
                    if hasattr(obj, '_resubscribe_all'):
                        result = obj._resubscribe_all()
                        if asyncio.iscoroutine(result):
                            asyncio.ensure_future(result)

            if obj._on_response:
                obj._on_response(item)
        return


def _create_option_symbol(symbol: str, expiration: str, option_type: str, strike_price: float) -> str:
    """Create a Schwab-format option symbol."""
    exp_parts = expiration.split("-")
    if len(exp_parts) != 3:
        raise ValueError("Expiration must be in YYYY-MM-DD format")

    year = exp_parts[0][-2:]
    month = exp_parts[1]
    day = exp_parts[2]
    exp_formatted = f"{year}{month}{day}"

    option_type = option_type.upper()
    if option_type not in ["C", "P"]:
        raise ValueError("Option type must be 'C' for Call or 'P' for Put")

    strike_whole = int(strike_price)
    strike_decimal = int((strike_price - strike_whole) * 1000)
    strike_formatted = f"{strike_whole:05d}{strike_decimal:03d}"

    return f"{symbol:<6}{exp_formatted}{option_type}{strike_formatted}"
