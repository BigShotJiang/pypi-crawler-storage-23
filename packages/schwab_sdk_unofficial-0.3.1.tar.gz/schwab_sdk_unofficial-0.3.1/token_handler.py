"""
Schwab SDK - Token Handler
Handles automatic rotation of access and refresh tokens.
"""

import asyncio
import json
import logging
import os
import base64
import threading
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
import httpx

try:
    from .exceptions import (
        SchwabAPIError,
        SchwabAuthenticationError,
        SchwabTokenExpiredError,
        raise_for_schwab_status,
    )
except ImportError:
    from exceptions import (
        SchwabAPIError,
        SchwabAuthenticationError,
        SchwabTokenExpiredError,
        raise_for_schwab_status,
    )

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    _HAS_CRYPTO = True
except ImportError:
    _HAS_CRYPTO = False

logger = logging.getLogger(__name__)


class TokenHandler:
    """
    Manages access and refresh tokens with automatic rotation.

    - Automatic rotation of access token every 29 minutes
    - Automatic rotation of refresh token every 6 days 23 hours
    - Manual refresh available
    - Robust error handling
    """

    def __init__(self, client_id: str, client_secret: str, redirect_uri: str, token_path: Optional[str] = None, encryption_key: Optional[str] = None, persist: bool = True):
        """
        Initialize the TokenHandler.

        Args:
            client_id: Schwab application Client ID
            client_secret: Schwab application Client Secret
            redirect_uri: Redirect URI for OAuth
            token_path: Path to token file (default: "schwab_tokens.json")
            encryption_key: Optional passphrase for AES-256-GCM encryption of tokens at rest.
                           If provided, tokens are encrypted before saving to disk.
                           If not provided, tokens are stored as plain JSON (default).
            persist: If True (default), tokens are saved to and loaded from disk.
                    If False, tokens only live in memory (useful for DB-backed storage).
        """
        self.client_id = client_id
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri

        # Encryption
        self._encryption_key = encryption_key
        if encryption_key and not _HAS_CRYPTO:
            raise ImportError(
                "Token encryption requires the 'cryptography' package. "
                "Install it with: pip install cryptography"
            )

        # Schwab URLs
        self.token_url = "https://api.schwabapi.com/v1/oauth/token"

        # Tokens and metadata
        self.access_token: Optional[str] = None
        self.refresh_token: Optional[str] = None
        self.access_token_expires_at: Optional[datetime] = None
        self.refresh_token_expires_at: Optional[datetime] = None

        # Persistence
        self._persist = persist
        self.token_file = token_path or "schwab_tokens.json"

        # Threading for auto-refresh (sync)
        self._refresh_timer: Optional[threading.Timer] = None
        self._refresh_token_timer: Optional[threading.Timer] = None
        self._lock = threading.RLock()

        # Async lock for async refresh
        self._async_lock = asyncio.Lock()

        # Callback for re-login when the refresh token expires
        self.on_refresh_token_expired = None

        # Auto-refresh retry tracking
        self._auto_refresh_failures = 0

        # Load existing tokens if present
        if self._persist:
            self.load_tokens()

    def save_tokens(self, access_token: str, refresh_token: str, expires_in: int = 1800) -> None:
        """
        Persist tokens securely.

        Args:
            access_token: Access token
            refresh_token: Refresh token
            expires_in: Seconds until the access token expires (default 1800 = 30 min)
        """
        with self._lock:
            self.access_token = access_token
            self.refresh_token = refresh_token

            # Compute expiration timestamps
            now = datetime.now()
            self.access_token_expires_at = now + timedelta(seconds=expires_in)
            # Refresh token expires in ~7 days; schedule at 6d 23h to be safe
            self.refresh_token_expires_at = now + timedelta(days=6, hours=23)

            # Persist to disk
            token_data = {
                "access_token": access_token,
                "refresh_token": refresh_token,
                "access_token_expires_at": self.access_token_expires_at.isoformat(),
                "refresh_token_expires_at": self.refresh_token_expires_at.isoformat()
            }

            if self._persist:
                try:
                    if self._encryption_key:
                        self._save_encrypted(token_data)
                    else:
                        with open(self.token_file, 'w') as f:
                            json.dump(token_data, f, indent=2)
                except Exception as e:
                    logger.error("Error saving tokens: %s", e)

            # Schedule auto-refresh
            self._schedule_auto_refresh()

    async def async_save_tokens(self, access_token: str, refresh_token: str, expires_in: int = 1800) -> None:
        """Non-blocking version of save_tokens() for async contexts."""
        await asyncio.to_thread(self.save_tokens, access_token, refresh_token, expires_in)

    def load_tokens(self) -> bool:
        """
        Load existing tokens from disk.

        Automatically detects whether the token file is encrypted or plain JSON.

        Returns:
            True if valid tokens were loaded, False otherwise
        """
        if not self._persist or not os.path.exists(self.token_file):
            return False

        try:
            with open(self.token_file, 'r') as f:
                raw_data = json.load(f)

            # Auto-detect encrypted format
            if self._is_encrypted_format(raw_data):
                if not self._encryption_key:
                    logger.warning("Token file is encrypted but no encryption_key was provided")
                    return False
                token_data = self._load_encrypted(raw_data)
            else:
                token_data = raw_data

            with self._lock:
                self.access_token = token_data.get("access_token")
                self.refresh_token = token_data.get("refresh_token")

                # Parse expiration timestamps
                if token_data.get("access_token_expires_at"):
                    self.access_token_expires_at = datetime.fromisoformat(
                        token_data["access_token_expires_at"]
                    )

                if token_data.get("refresh_token_expires_at"):
                    self.refresh_token_expires_at = datetime.fromisoformat(
                        token_data["refresh_token_expires_at"]
                    )

                # Verify the refresh token is still valid
                if self.refresh_token_expires_at and datetime.now() >= self.refresh_token_expires_at:
                    logger.warning("Refresh token expired, clearing tokens")
                    self._clear_tokens()
                    return False

            # Schedule auto-refresh if we have valid tokens
            if self.refresh_token:
                self._schedule_auto_refresh()
                return True

            return False

        except Exception as e:
            logger.error("Error loading tokens: %s", e)
            return False

    def has_valid_token(self) -> bool:
        """
        Check if we have a valid access token.

        Returns:
            True if the access token is valid, False otherwise
        """
        if not self.access_token or not self.access_token_expires_at:
            return False

        # Consider valid if more than 1 minute remains before expiry
        return datetime.now() < (self.access_token_expires_at - timedelta(minutes=1))

    def get_access_token(self) -> Optional[str]:
        """
        Get the current access token (without automatic refresh).

        Returns:
            Access token if valid, None otherwise
        """
        if self.has_valid_token():
            return self.access_token
        return None

    def refresh_token_now(self) -> bool:
        """
        Immediately refresh the access token using the refresh token.

        Returns:
            True if the refresh succeeded, False if no refresh token.

        Raises:
            SchwabTokenExpiredError: If the refresh token is expired or invalid.
            SchwabAuthenticationError: If authentication fails for other reasons.
        """
        if not self.refresh_token:
            logger.warning("No refresh token available")
            return False

        return self._refresh_access_token()

    async def async_refresh_token_now(self) -> bool:
        """
        Immediately refresh the access token using the refresh token (async version).

        Returns:
            True if the refresh succeeded, False if no refresh token.

        Raises:
            SchwabTokenExpiredError: If the refresh token is expired or invalid.
            SchwabAuthenticationError: If authentication fails for other reasons.
        """
        if not self.refresh_token:
            logger.warning("No refresh token available")
            return False

        return await self._async_refresh_access_token()

    def _refresh_access_token(self) -> bool:
        """
        Refresh the access token using grant_type=refresh_token.

        Uses Basic auth (Base64-encoded client_id:client_secret) per the
        Schwab OAuth documentation (Step 4).

        Returns:
            True if successful.

        Raises:
            SchwabTokenExpiredError: If the refresh token is expired or invalid.
            SchwabAuthenticationError: If authentication fails for other reasons.
        """
        if not self.refresh_token:
            return False

        payload = {
            "grant_type": "refresh_token",
            "refresh_token": self.refresh_token,
        }

        # Basic auth per Schwab OAuth docs (Step 4)
        credentials = f"{self.client_id}:{self.client_secret}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": f"Basic {encoded_credentials}",
        }

        try:
            response = httpx.post(
                self.token_url,
                data=payload,
                headers=headers,
                timeout=10,
            )

            if response.status_code == 200:
                token_data = response.json()

                # Save new tokens
                self.save_tokens(
                    access_token=token_data["access_token"],
                    refresh_token=token_data.get("refresh_token", self.refresh_token),
                    expires_in=token_data.get("expires_in", 1800),
                )

                logger.info("Access token refreshed successfully")
                return True

            # Check for expired/invalid refresh token
            try:
                error_data = response.json() if response.content else {}
                error = error_data.get("error", "")
                error_desc = error_data.get("error_description", "")
            except Exception:
                error, error_desc = "", ""

            if error in ("invalid_grant", "invalid_client"):
                logger.error("Refresh token expired or invalid (%s), re-login required", error)
                self._clear_tokens()
                if self.on_refresh_token_expired:
                    self.on_refresh_token_expired()
                raise SchwabTokenExpiredError(
                    error_desc or f"Refresh token invalid ({error})",
                    status_code=response.status_code,
                    response=response,
                )

            # Other HTTP errors — use typed exception factory
            raise_for_schwab_status(response)
            return False  # unreachable, but satisfies type checker

        except SchwabAPIError:
            raise
        except httpx.HTTPError as e:
            raise SchwabAuthenticationError(
                f"Network error refreshing token: {e}",
                status_code=0,
            ) from e
        except Exception as e:
            logger.error("Unexpected error refreshing token: %s", e)
            raise

    async def _async_refresh_access_token(self) -> bool:
        """
        Refresh the access token asynchronously using grant_type=refresh_token.

        Uses Basic auth (Base64-encoded client_id:client_secret) per the
        Schwab OAuth documentation (Step 4).

        Returns:
            True if successful.

        Raises:
            SchwabTokenExpiredError: If the refresh token is expired or invalid.
            SchwabAuthenticationError: If authentication fails for other reasons.
        """
        if not self.refresh_token:
            return False

        async with self._async_lock:
            payload = {
                "grant_type": "refresh_token",
                "refresh_token": self.refresh_token,
            }

            # Basic auth per Schwab OAuth docs (Step 4)
            credentials = f"{self.client_id}:{self.client_secret}"
            encoded_credentials = base64.b64encode(credentials.encode()).decode()
            headers = {
                "Content-Type": "application/x-www-form-urlencoded",
                "Authorization": f"Basic {encoded_credentials}",
            }

            try:
                async with httpx.AsyncClient() as http:
                    response = await http.post(
                        self.token_url,
                        data=payload,
                        headers=headers,
                        timeout=10,
                    )

                if response.status_code == 200:
                    token_data = response.json()

                    # Save new tokens (non-blocking)
                    await self.async_save_tokens(
                        access_token=token_data["access_token"],
                        refresh_token=token_data.get("refresh_token", self.refresh_token),
                        expires_in=token_data.get("expires_in", 1800),
                    )

                    logger.info("Access token refreshed successfully (async)")
                    return True

                # Check for expired/invalid refresh token
                try:
                    error_data = response.json() if response.content else {}
                    error = error_data.get("error", "")
                    error_desc = error_data.get("error_description", "")
                except Exception:
                    error, error_desc = "", ""

                if error in ("invalid_grant", "invalid_client"):
                    logger.error("Refresh token expired or invalid (%s), re-login required", error)
                    await self._async_clear_tokens()
                    if self.on_refresh_token_expired:
                        self.on_refresh_token_expired()
                    raise SchwabTokenExpiredError(
                        error_desc or f"Refresh token invalid ({error})",
                        status_code=response.status_code,
                        response=response,
                    )

                # Other HTTP errors — use typed exception factory
                raise_for_schwab_status(response)
                return False  # unreachable

            except SchwabAPIError:
                raise
            except httpx.HTTPError as e:
                raise SchwabAuthenticationError(
                    f"Network error refreshing token: {e}",
                    status_code=0,
                ) from e
            except Exception as e:
                logger.error("Unexpected error refreshing token (async): %s", e)
                raise

    def _schedule_auto_refresh(self) -> None:
        """
        Schedule automatic token rotation.
        """
        with self._lock:
            # Cancel existing timers
            if self._refresh_timer:
                self._refresh_timer.cancel()
            if self._refresh_token_timer:
                self._refresh_token_timer.cancel()

            if not self.access_token_expires_at or not self.refresh_token_expires_at:
                return

            now = datetime.now()

            # Schedule access token refresh (29 minutes from now)
            access_refresh_seconds = 29 * 60  # 29 minutes
            if self.access_token_expires_at > now:
                # If the current token hasn't expired, compute remaining time - 1 minute buffer
                time_until_expires = (self.access_token_expires_at - now).total_seconds()
                access_refresh_seconds = max(60, time_until_expires - 60)  # Minimum 1 minute

            self._refresh_timer = threading.Timer(access_refresh_seconds, self._auto_refresh_access_token)
            self._refresh_timer.daemon = True
            self._refresh_timer.start()

            # Schedule refresh token handler (6 days 23 hours from creation)
            refresh_token_seconds = (self.refresh_token_expires_at - now).total_seconds()
            if refresh_token_seconds > 0:
                self._refresh_token_timer = threading.Timer(refresh_token_seconds, self._auto_refresh_refresh_token)
                self._refresh_token_timer.daemon = True
                self._refresh_token_timer.start()

            logger.info(
                "Auto-refresh scheduled: access token in %.1f min, refresh token in %.1f hours",
                access_refresh_seconds / 60,
                refresh_token_seconds / 3600,
            )

    _MAX_RETRY_ATTEMPTS = 5
    _RETRY_INTERVAL = 60  # seconds

    def _auto_refresh_access_token(self) -> None:
        """
        Callback for automatic access token refresh every 29 minutes.

        On success, save_tokens() → _schedule_auto_refresh() handles the next timer.
        On transient failure, retries with increasing backoff up to _MAX_RETRY_ATTEMPTS,
        then falls back to the normal 29-min interval.
        """
        logger.info("Running automatic access token refresh...")
        try:
            self._refresh_access_token()
            # save_tokens() → _schedule_auto_refresh() already scheduled next timer
            self._auto_refresh_failures = 0
        except SchwabTokenExpiredError:
            logger.warning("Refresh token expired during auto-refresh; re-login required")
            # on_refresh_token_expired callback already called inside _refresh_access_token
        except Exception as e:
            self._auto_refresh_failures += 1
            if self._auto_refresh_failures <= self._MAX_RETRY_ATTEMPTS:
                delay = self._RETRY_INTERVAL * self._auto_refresh_failures
                logger.warning(
                    "Auto-refresh failed (%s); retrying in %ds (attempt %d/%d)",
                    e, delay, self._auto_refresh_failures, self._MAX_RETRY_ATTEMPTS,
                )
            else:
                delay = 29 * 60
                logger.warning(
                    "Auto-refresh failed %d times (%s); retrying in 29 min",
                    self._auto_refresh_failures, e,
                )
            with self._lock:
                self._refresh_timer = threading.Timer(delay, self._auto_refresh_access_token)
                self._refresh_timer.daemon = True
                self._refresh_timer.start()

    def _auto_refresh_refresh_token(self) -> None:
        """
        Callback when the refresh token is about to expire.
        Triggers re-login if a callback is configured.
        """
        logger.warning("Refresh token expiring; re-login required")
        self._clear_tokens()

        if self.on_refresh_token_expired:
            self.on_refresh_token_expired()

    def _clear_tokens(self) -> None:
        """
        Clear all tokens and cancel timers.
        """
        with self._lock:
            self.access_token = None
            self.refresh_token = None
            self.access_token_expires_at = None
            self.refresh_token_expires_at = None

            # Cancel timers
            if self._refresh_timer:
                self._refresh_timer.cancel()
                self._refresh_timer = None
            if self._refresh_token_timer:
                self._refresh_token_timer.cancel()
                self._refresh_token_timer = None

            # Remove token file
            if self._persist:
                try:
                    if os.path.exists(self.token_file):
                        os.remove(self.token_file)
                except Exception as e:
                    logger.error("Error deleting token file: %s", e)

    async def _async_clear_tokens(self) -> None:
        """Non-blocking version of _clear_tokens() for async contexts."""
        await asyncio.to_thread(self._clear_tokens)

    # ========================= Encryption Helpers =========================

    def _derive_key(self, passphrase: str, salt: bytes) -> bytes:
        """
        Derive a 256-bit AES key from a passphrase using PBKDF2-HMAC-SHA256.

        Args:
            passphrase: User-provided encryption key
            salt: Random salt bytes

        Returns:
            32-byte derived key
        """
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100_000,
        )
        return kdf.derive(passphrase.encode("utf-8"))

    def _save_encrypted(self, token_data: Dict[str, Any]) -> None:
        """
        Encrypt token data with AES-256-GCM and save to disk.

        File format: {"encrypted": true, "salt": "...", "nonce": "...", "ciphertext": "..."}
        """
        salt = os.urandom(16)
        key = self._derive_key(self._encryption_key, salt)
        aesgcm = AESGCM(key)
        nonce = os.urandom(12)  # 96-bit nonce for GCM

        plaintext = json.dumps(token_data).encode("utf-8")
        ciphertext = aesgcm.encrypt(nonce, plaintext, None)

        # ciphertext includes the 16-byte tag appended by AESGCM
        encrypted_payload = {
            "encrypted": True,
            "salt": base64.b64encode(salt).decode("ascii"),
            "nonce": base64.b64encode(nonce).decode("ascii"),
            "ciphertext": base64.b64encode(ciphertext).decode("ascii"),
        }

        with open(self.token_file, 'w') as f:
            json.dump(encrypted_payload, f, indent=2)

    def _load_encrypted(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Decrypt an encrypted token file.

        Args:
            raw_data: The parsed JSON content with encrypted fields

        Returns:
            Decrypted token data dict
        """
        salt = base64.b64decode(raw_data["salt"])
        nonce = base64.b64decode(raw_data["nonce"])
        ciphertext = base64.b64decode(raw_data["ciphertext"])

        key = self._derive_key(self._encryption_key, salt)
        aesgcm = AESGCM(key)

        plaintext = aesgcm.decrypt(nonce, ciphertext, None)
        return json.loads(plaintext.decode("utf-8"))

    @staticmethod
    def _is_encrypted_format(data: Dict[str, Any]) -> bool:
        """
        Check if a loaded JSON dict is in encrypted format.

        Returns:
            True if the data has the encrypted marker
        """
        return isinstance(data, dict) and data.get("encrypted") is True

    def cleanup(self) -> None:
        """
        Clean up resources (timers) when the object is destroyed.
        """
        if self._refresh_timer:
            self._refresh_timer.cancel()
        if self._refresh_token_timer:
            self._refresh_token_timer.cancel()

    def __del__(self):
        """
        Destructor to clean up resources.
        """
        self.cleanup()
