# callback.py – HTTPS OAuth callback server (FastAPI + uvicorn)
# with simple production mode and customizable Success/Error HTML pages.
#
# Features:
# - HTTPS required by default (PEM files or adhoc SSL for dev).
# - Single server backend: uvicorn.
# - One-shot flow: start() -> wait(timeout) -> shutdown().
# - Returns a dict to the caller; serves JSON when Accept: application/json or ?format=json.
# - Bridge page to capture tokens from URL fragment (#) and POST them as JSON.
# - Custom HTML pages for success and error (file paths); robust fallback if files missing.
# - Does NOT signal completion while showing the bridge page (prevents early return).
# - CLI flags for PEM/adhoc and custom success/error HTML paths.

from __future__ import annotations

import argparse
import datetime
import ipaddress
import json
import logging
import os
import tempfile
import threading
import time
from typing import Any, Dict, Optional

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID


# ------------------------- Defaults (HTML fallbacks) -------------------------

_HTML_OK_FALLBACK = """<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Authentication completed</title>
    <style>body{font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif;margin:2rem;line-height:1.5}</style>
  </head>
  <body>
    <h1>Credentials received successfully</h1>
    <p>You can now close this window.</p>
  </body>
</html>"""

_HTML_ERROR_FALLBACK = """<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Authentication error</title>
    <style>body{font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif;margin:2rem;line-height:1.5}</style>
  </head>
  <body>
    <h1>Authentication could not be completed</h1>
    <p>Close this window and try again.</p>
  </body>
</html>"""

_HTML_FRAGMENT_BRIDGE = """<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Finalizing sign-in...</title>
    <style>body{font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif;margin:2rem;line-height:1.5}</style>
  </head>
  <body>
    <h1>Processing data...</h1>
    <p>If this page does not close automatically, you can close it now.</p>
    <script>
      (function(){
        try {
          var hash = window.location.hash || "";
          if (hash.startsWith("#")) hash = hash.substring(1);
          var params = {};
          if (hash.length > 0) {
            hash.split("&").forEach(function(kv){
              var p = kv.split("=");
              if (p.length === 2) params[decodeURIComponent(p[0])] = decodeURIComponent(p[1]);
            });
          }
          if (Object.keys(params).length > 0) {
            fetch(window.location.pathname, {
              method: 'POST',
              headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
              body: JSON.stringify({ fragment_params: params })
            }).then(function(){
              // Optionally update UI; the server response may not replace this page due to fetch()
              document.body.innerHTML = '<h1>Data sent. You can close this window.</h1>';
            }).catch(function(){
              document.body.innerHTML = '<h1>The data could not be sent automatically.</h1><p>Please close this window and try again.</p>';
            });
          }
        } catch (e) { /* ignore */ }
      })();
    </script>
  </body>
</html>"""


# --------------------------------- Server ------------------------------------

class CallbackServer:
    """
    OAuth callback server with customizable HTML pages.

    Flow: start() -> wait() -> shutdown().

    wait() returns a dict like:
        {
          "params": {...},
          "method": "GET" | "POST",
          "path": "/callback",
          "received_at": <epoch_seconds>
        }
    """

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 8080,
        path: str = "/callback",
        *,
        # TLS selection
        ssl_cert: Optional[str] = None,
        ssl_key: Optional[str] = None,
        adhoc_ssl: bool = False,
        force_https: bool = True,
        # Custom HTML pages
        success_html_path: Optional[str] = None,
        error_html_path: Optional[str] = None,
        # Logging
        logger: Optional[logging.Logger] = None,
    ) -> None:
        self.host = host
        self.port = int(port)
        self.path = "/" + path.strip("/") if path else "/callback"
        self.ssl_cert = ssl_cert
        self.ssl_key = ssl_key
        self.adhoc_ssl = adhoc_ssl
        self.force_https = force_https

        # Logger
        self.log = logger or logging.getLogger("callback")
        if not self.log.handlers:
            h = logging.StreamHandler()
            fmt = logging.Formatter("[%(levelname)s] %(message)s")
            h.setFormatter(fmt)
            self.log.addHandler(h)
            self.log.setLevel(logging.INFO)

        # HTTPS constraints
        if self.force_https:
            if not (self.adhoc_ssl or (self.ssl_cert and self.ssl_key)):
                raise RuntimeError("HTTPS is required: use adhoc_ssl=True or provide ssl_cert and ssl_key")

        # FastAPI app and internals
        self._app = FastAPI()
        self._result: Optional[Dict[str, Any]] = None
        self._event = threading.Event()
        self._uvicorn_server: Optional[uvicorn.Server] = None
        self._server_thread: Optional[threading.Thread] = None
        self._adhoc_cert_file: Optional[str] = None
        self._adhoc_key_file: Optional[str] = None

        # Load optional custom HTML files
        self._success_html = self._load_optional_html(success_html_path, kind="success")
        self._error_html = self._load_optional_html(error_html_path, kind="error")

        # Routes
        self._app.add_api_route(self.path, self._handle_callback, methods=["GET", "POST"])
        self._app.add_api_route("/health", self._health, methods=["GET"])

    # ------------------------- Public lifecycle methods -------------------------

    def start(self) -> None:
        """Start the server in a background thread."""
        certfile = self.ssl_cert
        keyfile = self.ssl_key

        if self.force_https and self.adhoc_ssl and not (certfile and keyfile):
            certfile, keyfile = self._generate_adhoc_cert()
            self._adhoc_cert_file = certfile
            self._adhoc_key_file = keyfile

        config = uvicorn.Config(
            app=self._app,
            host=self.host,
            port=self.port,
            ssl_certfile=certfile if self.force_https else None,
            ssl_keyfile=keyfile if self.force_https else None,
            log_level="warning",
        )
        self._uvicorn_server = uvicorn.Server(config)
        self._server_thread = threading.Thread(target=self._uvicorn_server.run, daemon=True)
        self._server_thread.start()

        scheme = "https" if self.force_https else "http"
        self.log.info(f"Starting uvicorn on {scheme}://{self.host}:{self.port}{self.path}")

    def wait(self, timeout: Optional[float] = 180.0) -> Optional[Dict[str, Any]]:
        """Block until a valid callback (success/error) is received or timeout expires. Return dict or None."""
        signaled = self._event.wait(timeout=timeout)
        return self._result if signaled else None

    def shutdown(self) -> None:
        """Stop the server."""
        try:
            if self._uvicorn_server is not None:
                self._uvicorn_server.should_exit = True
            if self._server_thread is not None:
                self._server_thread.join(timeout=3.0)
        finally:
            # Clean up adhoc cert temp files
            for path in (self._adhoc_cert_file, self._adhoc_key_file):
                if path:
                    try:
                        os.unlink(path)
                    except OSError:
                        pass
            self._adhoc_cert_file = None
            self._adhoc_key_file = None

    # ------------------------------- Internals ---------------------------------

    def _load_optional_html(self, path: Optional[str], *, kind: str) -> Optional[str]:
        """Try to read an HTML file; return content or None if not provided or cannot be read."""
        if not path:
            return None
        try:
            if not os.path.isfile(path):
                raise FileNotFoundError(f"File not found: {path}")
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
                self.log.info(f"Loaded {kind} HTML from: {path}")
                return content
        except Exception as e:
            self.log.error(f"Could not load {kind} HTML ('{path}'): {e}. Using fallback.")
            return None

    @staticmethod
    def _wants_json(request: Request) -> bool:
        acc = (request.headers.get("accept", "") or "").lower()
        return ("application/json" in acc) or (request.query_params.get("format") == "json")

    @staticmethod
    def _has_tokenish(params: Dict[str, Any]) -> bool:
        tokenish = ("code", "access_token", "id_token", "refresh_token")
        return any(k in params and params.get(k) for k in tokenish)

    @staticmethod
    def _generate_adhoc_cert() -> tuple[str, str]:
        """Generate a self-signed certificate and write to temp PEM files. Returns (certfile, keyfile)."""
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, "localhost"),
        ])
        now = datetime.datetime.now(datetime.timezone.utc)
        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now)
            .not_valid_after(now + datetime.timedelta(days=1))
            .add_extension(
                x509.SubjectAlternativeName([
                    x509.DNSName("localhost"),
                    x509.IPAddress(ipaddress.IPv4Address("127.0.0.1")),
                ]),
                critical=False,
            )
            .sign(key, hashes.SHA256())
        )

        cert_fd, cert_path = tempfile.mkstemp(suffix=".pem", prefix="schwab_cert_")
        key_fd, key_path = tempfile.mkstemp(suffix=".pem", prefix="schwab_key_")
        try:
            os.write(cert_fd, cert.public_bytes(serialization.Encoding.PEM))
            os.close(cert_fd)
            os.write(key_fd, key.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.TraditionalOpenSSL,
                serialization.NoEncryption(),
            ))
            os.close(key_fd)
        except Exception:
            os.close(cert_fd)
            os.close(key_fd)
            os.unlink(cert_path)
            os.unlink(key_path)
            raise

        return cert_path, key_path

    async def _health(self) -> PlainTextResponse:
        return PlainTextResponse("OK")

    async def _handle_callback(self, request: Request):
        # If already completed once: keep idempotent behavior (show OK page or JSON ok)
        if self._event.is_set():
            if self._wants_json(request):
                return JSONResponse(content={"ok": True})
            return HTMLResponse(content=self._success_html or _HTML_OK_FALLBACK)

        # Merge params from GET, POST (form), JSON (incl. fragment_params)
        params: Dict[str, Any] = {}

        # Query params (GET)
        for k in request.query_params.keys():
            vals = request.query_params.getlist(k)
            params[k] = vals if len(vals) > 1 else request.query_params.get(k)

        # POST body: branch on Content-Type (Starlette can't read both form and json from same body)
        if request.method == "POST":
            content_type = (request.headers.get("content-type") or "").lower()
            if "application/json" in content_type:
                try:
                    body = await request.json()
                except Exception:
                    body = {}
                if isinstance(body, dict):
                    frag = body.get("fragment_params")
                    if isinstance(frag, dict):
                        for k, v in frag.items():
                            params.setdefault(k, v)
                    for k, v in body.items():
                        if k != "fragment_params":
                            params.setdefault(k, v)
            else:
                form = await request.form()
                for k in form.keys():
                    vals = form.getlist(k)
                    params[k] = vals if len(vals) > 1 else form.get(k)

        # Determine status
        is_error = "error" in params and params.get("error")
        has_tokenish = self._has_tokenish(params)

        # If no tokens and no explicit error -> show bridge (do not signal completion yet)
        if not is_error and not has_tokenish:
            if self._wants_json(request):
                return JSONResponse(content={"ok": False, "pending": True, "hint": "Awaiting fragment POST or query params"})
            return HTMLResponse(content=_HTML_FRAGMENT_BRIDGE)

        # Success or error -> record result and signal
        self._result = {
            "params": params,
            "method": request.method,
            "path": request.url.path,
            "received_at": int(time.time()),
        }
        self._event.set()

        # Choose representation
        if self._wants_json(request):
            return JSONResponse(content={"ok": True, **self._result})

        # Serve custom HTML (with fallback) per status
        if is_error:
            html = self._error_html or _HTML_ERROR_FALLBACK
        else:
            html = self._success_html or _HTML_OK_FALLBACK

        return HTMLResponse(content=html)


# -------------------------- Convenience top-level API -------------------------

def run_callback_server(
    host: str = "127.0.0.1",
    port: int = 8080,
    path: str = "/callback",
    *,
    timeout: float = 180.0,
    ssl_cert: Optional[str] = None,
    ssl_key: Optional[str] = None,
    adhoc_ssl: bool = False,
    force_https: bool = True,
    success_html_path: Optional[str] = None,
    error_html_path: Optional[str] = None,
    logger: Optional[logging.Logger] = None,
) -> Optional[Dict[str, Any]]:
    """
    Start the server, wait for exactly one result (success or error), then shut it down.
    Return a dict or None if the timeout elapses.
    """
    srv = CallbackServer(
        host=host,
        port=port,
        path=path,
        ssl_cert=ssl_cert,
        ssl_key=ssl_key,
        adhoc_ssl=adhoc_ssl,
        force_https=force_https,
        success_html_path=success_html_path,
        error_html_path=error_html_path,
        logger=logger,
    )
    srv.start()
    try:
        return srv.wait(timeout=timeout)
    finally:
        srv.shutdown()


# ----------------------------------- CLI -------------------------------------

def _cli() -> None:
    parser = argparse.ArgumentParser(description="Run an HTTPS OAuth callback server (FastAPI + uvicorn).")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind (default: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=8080, help="Port to bind (default: 8080)")
    parser.add_argument("--path", default="callback", help="Callback path (default: callback)")
    parser.add_argument("--timeout", type=float, default=180.0, help="Seconds to wait for a callback before exit")

    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--adhoc-ssl", action="store_true", help="Use adhoc self-signed certificate")
    mode.add_argument("--ssl-cert", default=None, help="Path to SSL certificate (PEM) for HTTPS")
    parser.add_argument("--ssl-key", default=None, help="Path to SSL private key (PEM) for HTTPS (required if --ssl-cert)")

    # Custom HTML paths
    parser.add_argument("--success-html", default=None, help="Path to custom Success HTML file")
    parser.add_argument("--error-html", default=None, help="Path to custom Error HTML file")

    args = parser.parse_args()

    # Simple validation for PEM pair if chosen
    if args.ssl_cert and not args.ssl_key:
        parser.error("--ssl-key is required when using --ssl-cert")

    # Normalize path
    path = "/" + args.path.strip("/")

    print(f"[callback.py] Starting on https://{args.host}:{args.port}{path}")

    res = run_callback_server(
        host=args.host,
        port=args.port,
        path=path,
        timeout=args.timeout,
        ssl_cert=args.ssl_cert,
        ssl_key=args.ssl_key,
        adhoc_ssl=args.adhoc_ssl,
        force_https=True,
        success_html_path=args.success_html,
        error_html_path=args.error_html,
    )

    if res is None:
        print("[callback.py] Timeout waiting for callback.")
    else:
        print(json.dumps(res, ensure_ascii=False))


if __name__ == "__main__":
    _cli()
