"""Tests for schwab_sdk.token_handler module."""

import json
import os
from datetime import datetime, timedelta
from unittest.mock import MagicMock, patch, AsyncMock

import httpx
import pytest

from schwab_sdk.token_handler import TokenHandler
from schwab_sdk.exceptions import (
    SchwabTokenExpiredError,
    SchwabAuthenticationError,
)


def _make_handler(tmp_path, encryption_key=None, load=False):
    """Create a TokenHandler with a temp file path."""
    token_path = str(tmp_path / "tokens.json")
    with patch.object(TokenHandler, "load_tokens", return_value=False):
        handler = TokenHandler(
            "test-client-id", "test-secret", "https://localhost/callback",
            token_path=token_path,
            encryption_key=encryption_key,
        )
    return handler


# ===== save_tokens =====

class TestSaveTokens:
    def test_sets_in_memory_state(self, tmp_path):
        h = _make_handler(tmp_path)
        with patch.object(h, "_schedule_auto_refresh"):
            h.save_tokens("at-1", "rt-1", 1800)
        assert h.access_token == "at-1"
        assert h.refresh_token == "rt-1"
        assert h.access_token_expires_at is not None
        assert h.refresh_token_expires_at is not None

    def test_writes_json_to_disk(self, tmp_path):
        h = _make_handler(tmp_path)
        with patch.object(h, "_schedule_auto_refresh"):
            h.save_tokens("at-1", "rt-1", 1800)
        assert os.path.exists(h.token_file)
        with open(h.token_file) as f:
            data = json.load(f)
        assert data["access_token"] == "at-1"
        assert data["refresh_token"] == "rt-1"

    def test_schedules_refresh(self, tmp_path):
        h = _make_handler(tmp_path)
        with patch.object(h, "_schedule_auto_refresh") as mock_sched:
            h.save_tokens("at-1", "rt-1")
        mock_sched.assert_called_once()

    def test_custom_expires_in(self, tmp_path):
        h = _make_handler(tmp_path)
        with patch.object(h, "_schedule_auto_refresh"):
            h.save_tokens("at", "rt", expires_in=3600)
        # Should expire in about 1 hour
        diff = (h.access_token_expires_at - datetime.now()).total_seconds()
        assert 3500 < diff < 3700


# ===== load_tokens =====

class TestLoadTokens:
    def test_file_not_exists(self, tmp_path):
        h = _make_handler(tmp_path)
        assert h.load_tokens() is False

    def test_valid_json(self, tmp_path):
        h = _make_handler(tmp_path)
        now = datetime.now()
        token_data = {
            "access_token": "at",
            "refresh_token": "rt",
            "access_token_expires_at": (now + timedelta(minutes=25)).isoformat(),
            "refresh_token_expires_at": (now + timedelta(days=6)).isoformat(),
        }
        with open(h.token_file, "w") as f:
            json.dump(token_data, f)
        with patch.object(h, "_schedule_auto_refresh"):
            result = h.load_tokens()
        assert result is True
        assert h.access_token == "at"
        assert h.refresh_token == "rt"

    def test_expired_refresh_token_clears(self, tmp_path):
        h = _make_handler(tmp_path)
        now = datetime.now()
        token_data = {
            "access_token": "at",
            "refresh_token": "rt",
            "access_token_expires_at": (now + timedelta(minutes=25)).isoformat(),
            "refresh_token_expires_at": (now - timedelta(hours=1)).isoformat(),
        }
        with open(h.token_file, "w") as f:
            json.dump(token_data, f)
        with patch.object(h, "_clear_tokens"):
            result = h.load_tokens()
        assert result is False

    def test_corrupt_json_returns_false(self, tmp_path):
        h = _make_handler(tmp_path)
        with open(h.token_file, "w") as f:
            f.write("not json{{{")
        result = h.load_tokens()
        assert result is False

    def test_no_refresh_token_returns_false(self, tmp_path):
        h = _make_handler(tmp_path)
        token_data = {"access_token": "at"}
        with open(h.token_file, "w") as f:
            json.dump(token_data, f)
        result = h.load_tokens()
        assert result is False


# ===== has_valid_token =====

class TestHasValidToken:
    def test_no_token(self, tmp_path):
        h = _make_handler(tmp_path)
        assert h.has_valid_token() is False

    def test_expired_token(self, tmp_path):
        h = _make_handler(tmp_path)
        h.access_token = "at"
        h.access_token_expires_at = datetime.now() - timedelta(minutes=5)
        assert h.has_valid_token() is False

    def test_about_to_expire(self, tmp_path):
        h = _make_handler(tmp_path)
        h.access_token = "at"
        h.access_token_expires_at = datetime.now() + timedelta(seconds=30)
        assert h.has_valid_token() is False

    def test_valid_token(self, tmp_path):
        h = _make_handler(tmp_path)
        h.access_token = "at"
        h.access_token_expires_at = datetime.now() + timedelta(minutes=10)
        assert h.has_valid_token() is True

    def test_no_expires_at(self, tmp_path):
        h = _make_handler(tmp_path)
        h.access_token = "at"
        h.access_token_expires_at = None
        assert h.has_valid_token() is False


# ===== get_access_token =====

class TestGetAccessToken:
    def test_valid_returns_token(self, tmp_path):
        h = _make_handler(tmp_path)
        h.access_token = "at-123"
        h.access_token_expires_at = datetime.now() + timedelta(minutes=10)
        assert h.get_access_token() == "at-123"

    def test_invalid_returns_none(self, tmp_path):
        h = _make_handler(tmp_path)
        assert h.get_access_token() is None


# ===== _refresh_access_token =====

class TestRefreshAccessToken:
    @patch("schwab_sdk.token_handler.httpx.post")
    def test_200_saves_tokens(self, mock_post, tmp_path):
        h = _make_handler(tmp_path)
        h.refresh_token = "rt-old"
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {
            "access_token": "at-new",
            "refresh_token": "rt-new",
            "expires_in": 1800,
        }
        mock_post.return_value = resp
        with patch.object(h, "save_tokens") as mock_save:
            result = h._refresh_access_token()
        assert result is True
        mock_save.assert_called_once_with(access_token="at-new", refresh_token="rt-new", expires_in=1800)

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_invalid_grant_raises_token_expired(self, mock_post, tmp_path):
        h = _make_handler(tmp_path)
        h.refresh_token = "rt-old"
        resp = MagicMock()
        resp.status_code = 401
        resp.content = b'{"error":"invalid_grant"}'
        resp.json.return_value = {"error": "invalid_grant", "error_description": "expired"}
        resp.headers = {}
        resp.text = '{"error":"invalid_grant"}'
        resp.reason_phrase = "Unauthorized"
        mock_post.return_value = resp
        with patch.object(h, "_clear_tokens"):
            with pytest.raises(SchwabTokenExpiredError):
                h._refresh_access_token()

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_invalid_client_raises_token_expired(self, mock_post, tmp_path):
        h = _make_handler(tmp_path)
        h.refresh_token = "rt"
        resp = MagicMock()
        resp.status_code = 401
        resp.content = b'{"error":"invalid_client"}'
        resp.json.return_value = {"error": "invalid_client"}
        resp.headers = {}
        resp.text = '{"error":"invalid_client"}'
        resp.reason_phrase = "Unauthorized"
        mock_post.return_value = resp
        with patch.object(h, "_clear_tokens"):
            with pytest.raises(SchwabTokenExpiredError):
                h._refresh_access_token()

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_on_refresh_token_expired_callback(self, mock_post, tmp_path):
        h = _make_handler(tmp_path)
        h.refresh_token = "rt"
        callback = MagicMock()
        h.on_refresh_token_expired = callback
        resp = MagicMock()
        resp.status_code = 401
        resp.content = b'{"error":"invalid_grant"}'
        resp.json.return_value = {"error": "invalid_grant"}
        resp.headers = {}
        resp.text = '{"error":"invalid_grant"}'
        resp.reason_phrase = "Unauthorized"
        mock_post.return_value = resp
        with patch.object(h, "_clear_tokens"):
            with pytest.raises(SchwabTokenExpiredError):
                h._refresh_access_token()
        callback.assert_called_once()

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_network_error_raises_auth_error(self, mock_post, tmp_path):
        h = _make_handler(tmp_path)
        h.refresh_token = "rt"
        mock_post.side_effect = httpx.ConnectError("refused")
        with pytest.raises(SchwabAuthenticationError, match="Network error"):
            h._refresh_access_token()

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_basic_auth_header(self, mock_post, tmp_path):
        import base64
        h = _make_handler(tmp_path)
        h.refresh_token = "rt"
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {"access_token": "at", "expires_in": 1800}
        mock_post.return_value = resp
        with patch.object(h, "save_tokens"):
            h._refresh_access_token()
        call_headers = mock_post.call_args.kwargs.get("headers") or mock_post.call_args[1].get("headers")
        expected = base64.b64encode(b"test-client-id:test-secret").decode()
        assert call_headers["Authorization"] == f"Basic {expected}"

    def test_no_refresh_token_returns_false(self, tmp_path):
        h = _make_handler(tmp_path)
        h.refresh_token = None
        assert h._refresh_access_token() is False

    def test_refresh_token_now_no_token(self, tmp_path):
        h = _make_handler(tmp_path)
        h.refresh_token = None
        assert h.refresh_token_now() is False


# ===== _async_refresh_access_token =====

class TestAsyncRefreshAccessToken:
    @pytest.mark.asyncio
    async def test_200_saves(self, tmp_path):
        h = _make_handler(tmp_path)
        h.refresh_token = "rt"
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {"access_token": "at-async", "expires_in": 1800}

        mock_http = AsyncMock()
        mock_http.post.return_value = resp
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=None)

        with patch("schwab_sdk.token_handler.httpx.AsyncClient", return_value=mock_http):
            with patch.object(h, "async_save_tokens", new_callable=AsyncMock) as mock_save:
                result = await h._async_refresh_access_token()
        assert result is True
        mock_save.assert_called_once()

    @pytest.mark.asyncio
    async def test_invalid_grant_raises(self, tmp_path):
        h = _make_handler(tmp_path)
        h.refresh_token = "rt"
        resp = MagicMock()
        resp.status_code = 401
        resp.content = b'{"error":"invalid_grant"}'
        resp.json.return_value = {"error": "invalid_grant"}
        resp.headers = {}
        resp.text = '{"error":"invalid_grant"}'
        resp.reason_phrase = "Unauthorized"

        mock_http = AsyncMock()
        mock_http.post.return_value = resp
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=None)

        with patch("schwab_sdk.token_handler.httpx.AsyncClient", return_value=mock_http):
            with patch.object(h, "_async_clear_tokens", new_callable=AsyncMock):
                with pytest.raises(SchwabTokenExpiredError):
                    await h._async_refresh_access_token()

    @pytest.mark.asyncio
    async def test_no_refresh_token(self, tmp_path):
        h = _make_handler(tmp_path)
        h.refresh_token = None
        result = await h._async_refresh_access_token()
        assert result is False

    @pytest.mark.asyncio
    async def test_async_refresh_token_now_no_token(self, tmp_path):
        h = _make_handler(tmp_path)
        h.refresh_token = None
        result = await h.async_refresh_token_now()
        assert result is False


# ===== Encryption =====

class TestEncryption:
    def test_round_trip(self, tmp_path):
        h = _make_handler(tmp_path, encryption_key="my-secret-key")
        with patch.object(h, "_schedule_auto_refresh"):
            h.save_tokens("at-enc", "rt-enc", 1800)
        # Verify encrypted format
        with open(h.token_file) as f:
            raw = json.load(f)
        assert raw.get("encrypted") is True
        assert "ciphertext" in raw

        # Load back
        with patch.object(h, "_schedule_auto_refresh"):
            result = h.load_tokens()
        assert result is True
        assert h.access_token == "at-enc"
        assert h.refresh_token == "rt-enc"

    def test_wrong_key_fails(self, tmp_path):
        h1 = _make_handler(tmp_path, encryption_key="key-1")
        with patch.object(h1, "_schedule_auto_refresh"):
            h1.save_tokens("at", "rt", 1800)

        h2 = _make_handler(tmp_path, encryption_key="key-2")
        h2.token_file = h1.token_file
        result = h2.load_tokens()
        assert result is False

    def test_encrypted_without_key_returns_false(self, tmp_path):
        h1 = _make_handler(tmp_path, encryption_key="my-key")
        with patch.object(h1, "_schedule_auto_refresh"):
            h1.save_tokens("at", "rt", 1800)

        h2 = _make_handler(tmp_path)  # no encryption key
        h2.token_file = h1.token_file
        result = h2.load_tokens()
        assert result is False


# ===== _clear_tokens =====

class TestClearTokens:
    def test_clears_memory(self, tmp_path):
        h = _make_handler(tmp_path)
        h.access_token = "at"
        h.refresh_token = "rt"
        h._clear_tokens()
        assert h.access_token is None
        assert h.refresh_token is None
        assert h.access_token_expires_at is None
        assert h.refresh_token_expires_at is None

    def test_cancels_timers(self, tmp_path):
        h = _make_handler(tmp_path)
        timer1 = MagicMock()
        timer2 = MagicMock()
        h._refresh_timer = timer1
        h._refresh_token_timer = timer2
        h._clear_tokens()
        timer1.cancel.assert_called_once()
        timer2.cancel.assert_called_once()
        assert h._refresh_timer is None
        assert h._refresh_token_timer is None

    def test_deletes_file(self, tmp_path):
        h = _make_handler(tmp_path)
        with open(h.token_file, "w") as f:
            f.write("{}")
        assert os.path.exists(h.token_file)
        h._clear_tokens()
        assert not os.path.exists(h.token_file)


# ===== _auto_refresh_access_token =====

class TestAutoRefresh:
    @patch("schwab_sdk.token_handler.httpx.post")
    def test_success_reschedules(self, mock_post, tmp_path):
        """Successful auto-refresh calls save_tokens which schedules next timer."""
        h = _make_handler(tmp_path)
        h.refresh_token = "rt"
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {"access_token": "at", "expires_in": 1800}
        mock_post.return_value = resp
        with patch.object(h, "save_tokens") as mock_save:
            h._auto_refresh_access_token()
            mock_save.assert_called_once()
        assert h._auto_refresh_failures == 0

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_token_expired_logged(self, mock_post, tmp_path):
        h = _make_handler(tmp_path)
        h.refresh_token = "rt"
        resp = MagicMock()
        resp.status_code = 401
        resp.content = b'{"error":"invalid_grant"}'
        resp.json.return_value = {"error": "invalid_grant"}
        resp.headers = {}
        resp.text = '{"error":"invalid_grant"}'
        resp.reason_phrase = "Unauthorized"
        mock_post.return_value = resp
        with patch.object(h, "_clear_tokens"):
            h._auto_refresh_access_token()  # Should not raise

    def test_auto_refresh_refresh_token(self, tmp_path):
        h = _make_handler(tmp_path)
        callback = MagicMock()
        h.on_refresh_token_expired = callback
        with patch.object(h, "_clear_tokens"):
            h._auto_refresh_refresh_token()
        callback.assert_called_once()


# ===== cleanup =====

class TestCleanup:
    def test_cancels_timers(self, tmp_path):
        h = _make_handler(tmp_path)
        timer1 = MagicMock()
        timer2 = MagicMock()
        h._refresh_timer = timer1
        h._refresh_token_timer = timer2
        h.cleanup()
        timer1.cancel.assert_called_once()
        timer2.cancel.assert_called_once()

    def test_cleanup_with_no_timers(self, tmp_path):
        h = _make_handler(tmp_path)
        h._refresh_timer = None
        h._refresh_token_timer = None
        h.cleanup()  # Should not raise


# ===== _is_encrypted_format =====

class TestIsEncryptedFormat:
    def test_encrypted_true(self):
        assert TokenHandler._is_encrypted_format({"encrypted": True, "ciphertext": "..."}) is True

    def test_not_encrypted(self):
        assert TokenHandler._is_encrypted_format({"access_token": "at"}) is False

    def test_non_dict(self):
        assert TokenHandler._is_encrypted_format("not a dict") is False


# ===== persist=False =====

class TestPersistFalse:
    def test_no_file_written_on_save(self, tmp_path):
        token_path = str(tmp_path / "tokens.json")
        h = TokenHandler(
            "cid", "secret", "https://localhost/callback",
            token_path=token_path, persist=False,
        )
        with patch.object(h, "_schedule_auto_refresh"):
            h.save_tokens("at-1", "rt-1", 1800)
        assert not os.path.exists(token_path)

    def test_tokens_in_memory(self, tmp_path):
        token_path = str(tmp_path / "tokens.json")
        h = TokenHandler(
            "cid", "secret", "https://localhost/callback",
            token_path=token_path, persist=False,
        )
        with patch.object(h, "_schedule_auto_refresh"):
            h.save_tokens("at-mem", "rt-mem", 1800)
        assert h.access_token == "at-mem"
        assert h.refresh_token == "rt-mem"
        assert h.access_token_expires_at is not None

    def test_load_returns_false(self, tmp_path):
        token_path = str(tmp_path / "tokens.json")
        # Write a file that would normally load
        with open(token_path, "w") as f:
            json.dump({"access_token": "at", "refresh_token": "rt"}, f)
        h = TokenHandler(
            "cid", "secret", "https://localhost/callback",
            token_path=token_path, persist=False,
        )
        assert h.access_token is None  # not loaded from disk

    def test_clear_no_file_delete(self, tmp_path):
        token_path = str(tmp_path / "tokens.json")
        with open(token_path, "w") as f:
            f.write("{}")
        h = TokenHandler(
            "cid", "secret", "https://localhost/callback",
            token_path=token_path, persist=False,
        )
        with patch.object(h, "_schedule_auto_refresh"):
            h.save_tokens("at", "rt")
        h._clear_tokens()
        assert h.access_token is None
        # File should still exist since persist=False doesn't touch disk
        assert os.path.exists(token_path)
