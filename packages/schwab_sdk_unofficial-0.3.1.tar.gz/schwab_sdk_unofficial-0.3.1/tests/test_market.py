"""Tests for schwab_sdk.market module."""

import pytest
from unittest.mock import MagicMock, AsyncMock

from schwab_sdk.market import (
    Market, AsyncMarket,
    _validate_fields, _build_quotes_params, _build_quote_params,
    _build_movers_params, _build_option_chain_params,
    _build_price_history_params, _build_instruments_params,
)
from schwab_sdk.exceptions import SchwabNotFoundError
from tests.conftest import make_mock_response


# ===== _validate_fields =====

class TestValidateFields:
    def test_none_returns_none(self):
        assert _validate_fields(None) is None

    def test_empty_string_returns_none(self):
        assert _validate_fields("") is None

    def test_empty_list_returns_none(self):
        assert _validate_fields([]) is None

    def test_single_string(self):
        assert _validate_fields("quote") == "quote"

    def test_comma_separated_string(self):
        result = _validate_fields("quote,fundamental")
        assert "quote" in result
        assert "fundamental" in result

    def test_list_of_fields(self):
        result = _validate_fields(["quote", "extended"])
        assert "quote" in result
        assert "extended" in result

    def test_invalid_field_raises(self):
        with pytest.raises(ValueError):
            _validate_fields(["invalid_field"])


# ===== _build_quotes_params =====

class TestBuildQuotesParams:
    def test_single_symbol(self):
        result = _build_quotes_params("AAPL", None, None, None)
        assert result["symbols"] == "AAPL"

    def test_list_symbols(self):
        result = _build_quotes_params(["AAPL", "MSFT"], None, None, None)
        assert result["symbols"] == "AAPL,MSFT"

    def test_with_fields(self):
        result = _build_quotes_params("AAPL", ["quote"], None, None)
        assert result["fields"] == "quote"

    def test_with_indicative(self):
        result = _build_quotes_params("AAPL", None, True, None)
        assert result["indicative"] == "true"

    def test_indicative_false(self):
        result = _build_quotes_params("AAPL", None, False, None)
        assert result["indicative"] == "false"

    def test_extra_params(self):
        result = _build_quotes_params("AAPL", None, None, {"extra": "val"})
        assert result["extra"] == "val"


# ===== _build_quote_params =====

class TestBuildQuoteParams:
    def test_empty(self):
        result = _build_quote_params(None, None, None)
        assert result == {}

    def test_with_fields(self):
        result = _build_quote_params("quote", None, None)
        assert result["fields"] == "quote"

    def test_with_indicative(self):
        result = _build_quote_params(None, True, None)
        assert result["indicative"] == "true"


# ===== _build_movers_params =====

class TestBuildMoversParams:
    def test_empty(self):
        result = _build_movers_params(None, None, None)
        assert result == {}

    def test_sort(self):
        result = _build_movers_params("VOLUME", None, None)
        assert result["sort"] == "VOLUME"

    def test_frequency(self):
        result = _build_movers_params(None, 5, None)
        assert result["frequency"] == 5

    def test_invalid_sort_raises(self):
        with pytest.raises(ValueError):
            _build_movers_params("INVALID", None, None)

    def test_invalid_frequency_raises(self):
        with pytest.raises(ValueError):
            _build_movers_params(None, 99, None)


# ===== _build_option_chain_params =====

class TestBuildOptionChainParams:
    def test_minimal(self):
        result = _build_option_chain_params(
            "AAPL", None, None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None,
        )
        assert result["symbol"] == "AAPL"
        assert len(result) == 1

    def test_contract_type(self):
        result = _build_option_chain_params(
            "AAPL", "CALL", None, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None,
        )
        assert result["contractType"] == "CALL"

    def test_strategy(self):
        result = _build_option_chain_params(
            "AAPL", None, None, None, "VERTICAL", None, None, None,
            None, None, None, None, None, None, None, None, None, None,
        )
        assert result["strategy"] == "VERTICAL"

    def test_date_normalization(self):
        result = _build_option_chain_params(
            "AAPL", None, None, None, None, None, None, None,
            "2024-03-15", "2024-06-15", None, None, None, None, None, None, None, None,
        )
        assert result["fromDate"] == "2024-03-15"
        assert result["toDate"] == "2024-06-15"

    def test_strike_count(self):
        result = _build_option_chain_params(
            "AAPL", None, 10, None, None, None, None, None,
            None, None, None, None, None, None, None, None, None, None,
        )
        assert result["strikeCount"] == 10

    def test_range_type(self):
        result = _build_option_chain_params(
            "AAPL", None, None, None, None, None, None, "ITM",
            None, None, None, None, None, None, None, None, None, None,
        )
        assert result["range"] == "ITM"

    def test_all_params(self):
        result = _build_option_chain_params(
            "AAPL", "CALL", 5, True, "SINGLE", 2.5, 150.0, "ITM",
            "2024-01-01", "2024-12-31", 0.3, 150.0, 0.05, 30,
            "JAN", "STANDARD", "NP", {"custom": "val"},
        )
        assert result["symbol"] == "AAPL"
        assert result["contractType"] == "CALL"
        assert result["strikeCount"] == 5
        assert result["includeUnderlyingQuote"] is True
        assert result["strategy"] == "SINGLE"
        assert result["interval"] == 2.5
        assert result["strike"] == 150.0
        assert result["range"] == "ITM"
        assert result["volatility"] == 0.3
        assert result["underlyingPrice"] == 150.0
        assert result["interestRate"] == 0.05
        assert result["daysToExpiration"] == 30
        assert result["expMonth"] == "JAN"
        assert result["optionType"] == "STANDARD"
        assert result["entitlement"] == "NP"
        assert result["custom"] == "val"

    def test_invalid_contract_type_raises(self):
        with pytest.raises(ValueError):
            _build_option_chain_params(
                "AAPL", "INVALID", None, None, None, None, None, None,
                None, None, None, None, None, None, None, None, None, None,
            )


# ===== _build_price_history_params =====

class TestBuildPriceHistoryParams:
    def test_defaults(self):
        result = _build_price_history_params(
            "AAPL", "month", 1, "daily", 1, None, None, None, None, None,
        )
        assert result["symbol"] == "AAPL"
        assert result["periodType"] == "month"
        assert result["frequencyType"] == "daily"

    def test_with_epoch_dates(self):
        result = _build_price_history_params(
            "AAPL", "day", 1, "minute", 1, 1700000000000, 1700100000000, None, None, None,
        )
        assert result["startDate"] == 1700000000000
        assert result["endDate"] == 1700100000000

    def test_with_string_dates(self):
        result = _build_price_history_params(
            "AAPL", "day", 1, "minute", 1, "2024-01-15", "2024-01-20", None, None, None,
        )
        assert isinstance(result["startDate"], int)
        assert isinstance(result["endDate"], int)

    def test_extended_hours(self):
        result = _build_price_history_params(
            "AAPL", "day", 1, "minute", 1, None, None, True, None, None,
        )
        assert result["needExtendedHoursData"] is True

    def test_previous_close(self):
        result = _build_price_history_params(
            "AAPL", "day", 1, "minute", 1, None, None, None, True, None,
        )
        assert result["needPreviousClose"] is True

    def test_invalid_period_type_raises(self):
        with pytest.raises(ValueError):
            _build_price_history_params(
                "AAPL", "invalid", 1, "daily", 1, None, None, None, None, None,
            )


# ===== _build_instruments_params =====

class TestBuildInstrumentsParams:
    def test_single_symbol(self):
        result = _build_instruments_params("AAPL", "symbol-search", None)
        assert result["symbol"] == "AAPL"
        assert result["projection"] == "symbol-search"

    def test_list_symbols(self):
        result = _build_instruments_params(["AAPL", "MSFT"], "symbol-search", None)
        assert result["symbol"] == "AAPL,MSFT"

    def test_extra_params(self):
        result = _build_instruments_params("AAPL", "fundamental", {"key": "val"})
        assert result["key"] == "val"

    def test_invalid_projection_raises(self):
        with pytest.raises(ValueError):
            _build_instruments_params("AAPL", "INVALID", None)


# ===== Sync Market =====

class TestMarket:
    def setup_method(self):
        self.client = MagicMock()
        self.client.market_base_url = "https://api.schwabapi.com/marketdata/v1"
        self.market = Market(self.client)

    def test_get_quotes(self):
        resp = make_mock_response(200, {"AAPL": {"lastPrice": 150.0}})
        self.client._request.return_value = resp
        result = self.market.get_quotes("AAPL")
        assert "AAPL" in result

    def test_get_quotes_multiple(self):
        resp = make_mock_response(200, {"AAPL": {}, "MSFT": {}})
        self.client._request.return_value = resp
        result = self.market.get_quotes(["AAPL", "MSFT"])
        assert "AAPL" in result

    def test_get_quote(self):
        resp = make_mock_response(200, {"lastPrice": 150.0})
        self.client._request.return_value = resp
        result = self.market.get_quote("AAPL")
        assert "lastPrice" in result

    def test_get_option_chain(self):
        resp = make_mock_response(200, {"callExpDateMap": {}})
        self.client._request.return_value = resp
        result = self.market.get_option_chain("AAPL")
        assert "callExpDateMap" in result

    def test_get_option_chain_with_params(self):
        resp = make_mock_response(200, {})
        self.client._request.return_value = resp
        self.market.get_option_chain("AAPL", contract_type="CALL", strategy="SINGLE")
        self.client._request.assert_called_once()

    def test_get_expiration_chain(self):
        resp = make_mock_response(200, {"expirationList": []})
        self.client._request.return_value = resp
        result = self.market.get_expiration_chain("AAPL")
        assert "expirationList" in result

    def test_get_price_history(self):
        resp = make_mock_response(200, {"candles": []})
        self.client._request.return_value = resp
        result = self.market.get_price_history("AAPL")
        assert "candles" in result

    def test_get_movers(self):
        resp = make_mock_response(200, {"screeners": []})
        self.client._request.return_value = resp
        result = self.market.get_movers("$SPX")
        assert "screeners" in result

    def test_get_movers_with_sort(self):
        resp = make_mock_response(200, {})
        self.client._request.return_value = resp
        self.market.get_movers("$DJI", sort="VOLUME", frequency=5)
        self.client._request.assert_called_once()

    def test_get_markets(self):
        resp = make_mock_response(200, {"equity": {}})
        self.client._request.return_value = resp
        result = self.market.get_markets()
        assert "equity" in result

    def test_get_markets_with_list(self):
        resp = make_mock_response(200, {})
        self.client._request.return_value = resp
        self.market.get_markets(markets=["equity", "option"])
        self.client._request.assert_called_once()

    def test_get_markets_with_date(self):
        resp = make_mock_response(200, {})
        self.client._request.return_value = resp
        self.market.get_markets(date="2024-03-15")
        self.client._request.assert_called_once()

    def test_get_market_hours(self):
        resp = make_mock_response(200, {"equity": {}})
        self.client._request.return_value = resp
        result = self.market.get_market_hours("equity")
        assert "equity" in result

    def test_get_instruments(self):
        resp = make_mock_response(200, {"instruments": []})
        self.client._request.return_value = resp
        result = self.market.get_instruments("AAPL")
        assert "instruments" in result

    def test_get_instruments_list(self):
        resp = make_mock_response(200, {})
        self.client._request.return_value = resp
        self.market.get_instruments(["AAPL", "MSFT"])
        self.client._request.assert_called_once()

    def test_get_instrument_by_cusip(self):
        resp = make_mock_response(200, {"cusip": "037833100"})
        self.client._request.return_value = resp
        result = self.market.get_instrument_by_cusip("037833100")
        assert result["cusip"] == "037833100"

    def test_error_propagation(self):
        resp = make_mock_response(404, {"message": "not found"})
        self.client._request.return_value = resp
        with pytest.raises(SchwabNotFoundError):
            self.market.get_quote("INVALID")


# ===== Async Market =====

class TestAsyncMarket:
    def setup_method(self):
        self.client = MagicMock()
        self.client.market_base_url = "https://api.schwabapi.com/marketdata/v1"
        self.client._request = AsyncMock()
        self.market = AsyncMarket(self.client)

    @pytest.mark.asyncio
    async def test_get_quotes(self):
        resp = make_mock_response(200, {"AAPL": {}})
        self.client._request.return_value = resp
        result = await self.market.get_quotes("AAPL")
        assert "AAPL" in result

    @pytest.mark.asyncio
    async def test_get_quote(self):
        resp = make_mock_response(200, {"lastPrice": 150.0})
        self.client._request.return_value = resp
        result = await self.market.get_quote("AAPL")
        assert "lastPrice" in result

    @pytest.mark.asyncio
    async def test_get_option_chain(self):
        resp = make_mock_response(200, {})
        self.client._request.return_value = resp
        result = await self.market.get_option_chain("AAPL")
        assert isinstance(result, dict)

    @pytest.mark.asyncio
    async def test_get_expiration_chain(self):
        resp = make_mock_response(200, {})
        self.client._request.return_value = resp
        result = await self.market.get_expiration_chain("AAPL")
        assert isinstance(result, dict)

    @pytest.mark.asyncio
    async def test_get_price_history(self):
        resp = make_mock_response(200, {"candles": []})
        self.client._request.return_value = resp
        result = await self.market.get_price_history("AAPL")
        assert "candles" in result

    @pytest.mark.asyncio
    async def test_get_movers(self):
        resp = make_mock_response(200, {})
        self.client._request.return_value = resp
        result = await self.market.get_movers("$SPX")
        assert isinstance(result, dict)

    @pytest.mark.asyncio
    async def test_get_markets(self):
        resp = make_mock_response(200, {})
        self.client._request.return_value = resp
        result = await self.market.get_markets()
        assert isinstance(result, dict)

    @pytest.mark.asyncio
    async def test_get_market_hours(self):
        resp = make_mock_response(200, {})
        self.client._request.return_value = resp
        result = await self.market.get_market_hours("equity")
        assert isinstance(result, dict)

    @pytest.mark.asyncio
    async def test_get_instruments(self):
        resp = make_mock_response(200, {})
        self.client._request.return_value = resp
        result = await self.market.get_instruments("AAPL")
        assert isinstance(result, dict)

    @pytest.mark.asyncio
    async def test_get_instrument_by_cusip(self):
        resp = make_mock_response(200, {"cusip": "037833100"})
        self.client._request.return_value = resp
        result = await self.market.get_instrument_by_cusip("037833100")
        assert result["cusip"] == "037833100"
