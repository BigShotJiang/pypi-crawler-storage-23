"""Tests for schwab_sdk.client module."""

import asyncio
from unittest.mock import MagicMock, AsyncMock, patch, PropertyMock

import httpx
import pytest

from schwab_sdk.client import Client, AsyncClient, TRADER_BASE_URL, MARKET_BASE_URL


def _make_client(**kwargs):
    """Create a Client with mocked internals to avoid real I/O."""
    with patch("schwab_sdk.client.TokenHandler") as MockTH, \
         patch("schwab_sdk.client.Authentication") as MockAuth, \
         patch("schwab_sdk.client.httpx.Client"):
        th = MockTH.return_value
        th.has_valid_token.return_value = kwargs.get("valid_token", False)
        th.get_access_token.return_value = kwargs.get("access_token", "fake-token")
        th.load_tokens.return_value = False
        th.refresh_token_now.return_value = True
        th.cleanup = MagicMock()
        th.on_refresh_token_expired = None

        auth = MockAuth.return_value
        auth.is_authenticated.return_value = kwargs.get("valid_token", False)
        auth.login.return_value = True

        c = Client("client-id", "client-secret")
        return c


def _make_async_client(**kwargs):
    """Create an AsyncClient with mocked internals."""
    with patch("schwab_sdk.client.TokenHandler") as MockTH, \
         patch("schwab_sdk.client.Authentication") as MockAuth, \
         patch("schwab_sdk.client.httpx.AsyncClient"):
        th = MockTH.return_value
        th.has_valid_token.return_value = kwargs.get("valid_token", False)
        th.get_access_token.return_value = kwargs.get("access_token", "fake-token")
        th.load_tokens.return_value = False
        th.async_refresh_token_now = AsyncMock(return_value=True)
        th.cleanup = MagicMock()
        th._async_clear_tokens = AsyncMock()
        th.on_refresh_token_expired = None

        auth = MockAuth.return_value
        auth.is_authenticated.return_value = kwargs.get("valid_token", False)

        c = AsyncClient("client-id", "client-secret")
        return c


# ===== Properties =====

class TestClientProperties:
    def test_base_urls(self):
        c = _make_client()
        assert c.trader_base_url == TRADER_BASE_URL
        assert c.market_base_url == MARKET_BASE_URL

    def test_account_property_lazy(self):
        c = _make_client()
        assert c._account_module is None
        acct = c.account
        assert acct is not None
        assert c._account_module is acct
        # Cached
        assert c.account is acct

    def test_orders_property_lazy(self):
        c = _make_client()
        assert c._orders_module is None
        orders = c.orders
        assert orders is not None
        assert c.orders is orders

    def test_market_property_lazy(self):
        c = _make_client()
        assert c._market_module is None
        market = c.market
        assert market is not None
        assert c.market is market

    def test_streaming_property_lazy(self):
        c = _make_client()
        assert c._streaming_module is None
        streaming = c.streaming
        assert streaming is not None
        assert c.streaming is streaming


# ===== Auth headers =====

class TestAuthHeaders:
    def test_with_token(self):
        c = _make_client(access_token="my-token")
        c.token_handler.has_valid_token.return_value = True
        headers = c.get_auth_headers()
        assert headers["Authorization"] == "Bearer my-token"

    def test_without_token(self):
        c = _make_client()
        c.token_handler.get_access_token.return_value = None
        headers = c.get_auth_headers()
        assert headers == {}


# ===== Delegation =====

class TestClientDelegation:
    def test_login_delegates(self):
        c = _make_client()
        c.login()
        c.authentication.login.assert_called_once()

    def test_logout_delegates(self):
        c = _make_client()
        c.logout()
        c.authentication.logout.assert_called_once()

    def test_exchange_code_delegates(self):
        c = _make_client()
        c.exchange_code("auth-code-123")
        c.authentication.exchange_code.assert_called_once_with("auth-code-123")

    def test_get_auth_url_delegates(self):
        c = _make_client()
        c.get_auth_url()
        c.authentication.get_auth_url.assert_called_once()

    def test_has_valid_token(self):
        c = _make_client(valid_token=True)
        assert c.has_valid_token() is True

    def test_is_authenticated(self):
        c = _make_client(valid_token=True)
        assert c.is_authenticated() is True

    def test_get_access_token(self):
        c = _make_client(access_token="tok")
        assert c.get_access_token() == "tok"

    def test_refresh_token_when_valid(self):
        c = _make_client(valid_token=True)
        assert c.refresh_token() is True

    def test_refresh_token_now(self):
        c = _make_client()
        c.refresh_token_now()
        c.token_handler.refresh_token_now.assert_called_once()


# ===== _request (sync) =====

class TestSyncRequest:
    def test_200_direct_return(self):
        c = _make_client(access_token="tok")
        mock_resp = MagicMock(status_code=200)
        c._http.request.return_value = mock_resp
        resp = c._request("GET", "https://api.test/data")
        assert resp.status_code == 200

    @patch("schwab_sdk.client.time.sleep")
    def test_401_refresh_retry(self, mock_sleep):
        c = _make_client(access_token="tok")
        resp_401 = MagicMock(status_code=401)
        resp_200 = MagicMock(status_code=200)
        c._http.request.side_effect = [resp_401, resp_200]
        c.token_handler.refresh_token_now.return_value = True
        c.token_handler.has_valid_token.return_value = True
        resp = c._request("GET", "https://api.test/data")
        assert resp.status_code == 200

    @patch("schwab_sdk.client.time.sleep")
    def test_401_refresh_fails_returns_401(self, mock_sleep):
        c = _make_client(access_token="tok")
        resp_401 = MagicMock(status_code=401)
        c._http.request.return_value = resp_401
        c.token_handler.refresh_token_now.return_value = False
        resp = c._request("GET", "https://api.test/data")
        assert resp.status_code == 401

    @patch("schwab_sdk.client.time.sleep")
    def test_429_retry_with_backoff(self, mock_sleep):
        c = _make_client(access_token="tok")
        resp_429 = MagicMock(status_code=429)
        resp_200 = MagicMock(status_code=200)
        c._http.request.side_effect = [resp_429, resp_429, resp_200]
        resp = c._request("GET", "https://api.test/data", max_retries=3)
        assert resp.status_code == 200
        assert mock_sleep.call_count == 2

    @patch("schwab_sdk.client.time.sleep")
    def test_5xx_retry(self, mock_sleep):
        c = _make_client(access_token="tok")
        resp_500 = MagicMock(status_code=500)
        resp_200 = MagicMock(status_code=200)
        c._http.request.side_effect = [resp_500, resp_200]
        resp = c._request("GET", "https://api.test/data")
        assert resp.status_code == 200

    @patch("schwab_sdk.client.time.sleep")
    def test_max_retries_exhausted_final_attempt(self, mock_sleep):
        c = _make_client(access_token="tok")
        resp_500 = MagicMock(status_code=500)
        resp_200 = MagicMock(status_code=200)
        # 3 retries return 500, then final attempt returns 200
        c._http.request.side_effect = [resp_500, resp_500, resp_500, resp_200]
        resp = c._request("GET", "https://api.test/data", max_retries=3)
        assert resp.status_code == 200

    @patch("schwab_sdk.client.time.sleep")
    def test_request_error_retry_then_reraise(self, mock_sleep):
        c = _make_client(access_token="tok")
        c._http.request.side_effect = httpx.ConnectError("refused")
        with pytest.raises(httpx.ConnectError):
            c._request("GET", "https://api.test/data", max_retries=2)
        assert mock_sleep.call_count == 2


# ===== Context managers =====

class TestContextManagers:
    def test_sync_context_manager(self):
        c = _make_client()
        with c as client:
            assert client is c
        c._http.close.assert_called()

    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        c = _make_async_client()
        c._http.aclose = AsyncMock()
        async with c as client:
            assert client is c
        c._http.aclose.assert_called()


# ===== __repr__ =====

class TestRepr:
    def test_sync_repr_not_authenticated(self):
        c = _make_client(valid_token=False)
        assert "not authenticated" in repr(c)

    def test_sync_repr_authenticated(self):
        c = _make_client(valid_token=True)
        assert "authenticated" in repr(c)
        assert "client-i" in repr(c)

    def test_async_repr(self):
        c = _make_async_client(valid_token=False)
        assert "AsyncSchwabClient" in repr(c)


# ===== AsyncClient specifics =====

class TestAsyncClientProperties:
    def test_account_property_lazy(self):
        c = _make_async_client()
        assert c._account_module is None
        acct = c.account
        assert acct is not None

    def test_orders_property_lazy(self):
        c = _make_async_client()
        orders = c.orders
        assert orders is not None

    def test_market_property_lazy(self):
        c = _make_async_client()
        market = c.market
        assert market is not None

    def test_streaming_property_lazy(self):
        c = _make_async_client()
        streaming = c.streaming
        assert streaming is not None


class TestAsyncClientDelegation:
    def test_has_valid_token(self):
        c = _make_async_client(valid_token=True)
        assert c.has_valid_token() is True

    def test_get_access_token(self):
        c = _make_async_client(access_token="async-tok")
        assert c.get_access_token() == "async-tok"

    def test_get_auth_headers(self):
        c = _make_async_client(access_token="tok")
        c.token_handler.has_valid_token.return_value = True
        headers = c.get_auth_headers()
        assert "Authorization" in headers


class TestAsyncRequest:
    @pytest.mark.asyncio
    @patch("schwab_sdk.client.asyncio.sleep", new_callable=AsyncMock)
    async def test_200_direct(self, mock_sleep):
        c = _make_async_client(access_token="tok")
        mock_resp = MagicMock(status_code=200)
        c._http.request = AsyncMock(return_value=mock_resp)
        resp = await c._request("GET", "https://api.test/data")
        assert resp.status_code == 200

    @pytest.mark.asyncio
    @patch("schwab_sdk.client.asyncio.sleep", new_callable=AsyncMock)
    async def test_401_refresh_retry(self, mock_sleep):
        c = _make_async_client(access_token="tok")
        resp_401 = MagicMock(status_code=401)
        resp_200 = MagicMock(status_code=200)
        c._http.request = AsyncMock(side_effect=[resp_401, resp_200])
        c.token_handler.async_refresh_token_now = AsyncMock(return_value=True)
        c.token_handler.has_valid_token.return_value = True
        resp = await c._request("GET", "https://api.test/data")
        assert resp.status_code == 200

    @pytest.mark.asyncio
    @patch("schwab_sdk.client.asyncio.sleep", new_callable=AsyncMock)
    async def test_429_retry(self, mock_sleep):
        c = _make_async_client(access_token="tok")
        resp_429 = MagicMock(status_code=429)
        resp_200 = MagicMock(status_code=200)
        c._http.request = AsyncMock(side_effect=[resp_429, resp_200])
        resp = await c._request("GET", "https://api.test/data")
        assert resp.status_code == 200

    @pytest.mark.asyncio
    @patch("schwab_sdk.client.asyncio.sleep", new_callable=AsyncMock)
    async def test_request_error_reraise(self, mock_sleep):
        c = _make_async_client(access_token="tok")
        c._http.request = AsyncMock(side_effect=httpx.ConnectError("refused"))
        with pytest.raises(httpx.ConnectError):
            await c._request("GET", "https://api.test/data", max_retries=2)
