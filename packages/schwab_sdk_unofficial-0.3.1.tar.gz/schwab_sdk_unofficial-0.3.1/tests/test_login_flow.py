"""
Integration tests: full login flow with real token refresh.

Uses real TokenHandler and Authentication objects (not mocked),
with only HTTP calls mocked. Verifies the end-to-end cycle:

  login → tokens saved → access expired → refresh → new tokens
"""

import json
import os
import threading
from datetime import datetime, timedelta
from unittest.mock import MagicMock, AsyncMock, patch

import httpx
import pytest

from schwab_sdk.token_handler import TokenHandler
from schwab_sdk.authentication import Authentication
from schwab_sdk.client import Client, AsyncClient
from schwab_sdk.exceptions import (
    SchwabTokenExpiredError,
    SchwabAuthenticationError,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_mock_response(status_code=200, json_data=None, headers=None, url="https://api.schwabapi.com/test"):
    """Minimal mock httpx.Response."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.headers = httpx.Headers(headers or {})
    resp.url = httpx.URL(url)
    resp.reason_phrase = "OK" if status_code < 400 else "Error"
    resp.text = json.dumps(json_data) if json_data else ""
    resp.content = resp.text.encode() if resp.text else b""
    if json_data is not None:
        resp.json.return_value = json_data
    else:
        resp.json.side_effect = Exception("No JSON body")
    elapsed = MagicMock()
    elapsed.total_seconds.return_value = 0.1
    resp.elapsed = elapsed
    return resp

def _make_token_handler(tmp_path, persist=True, encryption_key=None):
    """Create a real TokenHandler pointing at a temp file."""
    token_path = str(tmp_path / "tokens.json")
    with patch.object(TokenHandler, "_schedule_auto_refresh"):
        handler = TokenHandler(
            "test-client-id",
            "test-secret",
            "https://localhost:8080/callback",
            token_path=token_path,
            encryption_key=encryption_key,
            persist=persist,
        )
    return handler


def _make_auth(tmp_path, persist=True):
    """Create a real Authentication backed by a real TokenHandler."""
    handler = _make_token_handler(tmp_path, persist=persist)
    auth = Authentication(
        "test-client-id", "test-secret",
        "https://localhost:8080/callback", handler,
    )
    return auth, handler


def _token_response(access="at-new", refresh="rt-new", expires_in=1800):
    """Build a mock 200 token response."""
    return make_mock_response(200, {
        "access_token": access,
        "refresh_token": refresh,
        "expires_in": expires_in,
    })


def _invalid_grant_response():
    """Build a mock 401 invalid_grant response."""
    resp = MagicMock()
    resp.status_code = 401
    resp.content = b'{"error":"invalid_grant","error_description":"Token expired"}'
    resp.json.return_value = {"error": "invalid_grant", "error_description": "Token expired"}
    resp.headers = {}
    resp.text = '{"error":"invalid_grant","error_description":"Token expired"}'
    resp.reason_phrase = "Unauthorized"
    return resp


# ===========================================================================
# 1. Full login → code exchange → tokens persisted
# ===========================================================================

class TestLoginToTokensPersisted:
    """Login flow end-to-end: callback → code exchange → tokens on disk."""

    @patch("schwab_sdk.authentication.webbrowser.open")
    @patch("schwab_sdk.authentication.httpx.post")
    def test_login_saves_tokens_to_disk(self, mock_post, mock_browser, tmp_path):
        auth, handler = _make_auth(tmp_path)

        # Simulate Schwab token endpoint response
        mock_post.return_value = _token_response("at-login", "rt-login", 1800)

        # Simulate callback server returning an auth code
        mock_server = MagicMock()
        mock_server.wait.return_value = {"params": {"code": "auth-code-abc"}}

        with patch.object(auth, "_start_callback_server", return_value=True):
            auth.callback_server = mock_server
            with patch.object(auth, "_stop_callback_server"):
                with patch.object(handler, "_schedule_auto_refresh"):
                    result = auth.login()

        assert result is True
        assert handler.access_token == "at-login"
        assert handler.refresh_token == "rt-login"
        assert handler.access_token_expires_at is not None

        # Verify file was written
        assert os.path.exists(handler.token_file)
        with open(handler.token_file) as f:
            data = json.load(f)
        assert data["access_token"] == "at-login"
        assert data["refresh_token"] == "rt-login"

    @patch("schwab_sdk.authentication.webbrowser.open")
    @patch("schwab_sdk.authentication.httpx.post")
    def test_login_with_persist_false_no_file(self, mock_post, mock_browser, tmp_path):
        auth, handler = _make_auth(tmp_path, persist=False)

        mock_post.return_value = _token_response("at-mem", "rt-mem")

        mock_server = MagicMock()
        mock_server.wait.return_value = {"params": {"code": "code123"}}

        with patch.object(auth, "_start_callback_server", return_value=True):
            auth.callback_server = mock_server
            with patch.object(auth, "_stop_callback_server"):
                with patch.object(handler, "_schedule_auto_refresh"):
                    result = auth.login()

        assert result is True
        assert handler.access_token == "at-mem"
        assert handler.refresh_token == "rt-mem"
        assert not os.path.exists(handler.token_file)


# ===========================================================================
# 2. Tokens → expire → refresh → new tokens
# ===========================================================================

class TestAccessTokenExpiredThenRefresh:
    """Access token expires, refresh_token_now() obtains new tokens."""

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_refresh_after_expiry(self, mock_post, tmp_path):
        handler = _make_token_handler(tmp_path)

        # Simulate tokens that were saved during login
        with patch.object(handler, "_schedule_auto_refresh"):
            handler.save_tokens("at-old", "rt-old", 1800)

        assert handler.has_valid_token() is True

        # Force access token to be expired
        handler.access_token_expires_at = datetime.now() - timedelta(minutes=5)
        assert handler.has_valid_token() is False
        assert handler.get_access_token() is None

        # Refresh endpoint returns new tokens
        mock_post.return_value = _token_response("at-refreshed", "rt-refreshed", 1800)

        with patch.object(handler, "_schedule_auto_refresh"):
            result = handler.refresh_token_now()

        assert result is True
        assert handler.access_token == "at-refreshed"
        assert handler.refresh_token == "rt-refreshed"
        assert handler.has_valid_token() is True

        # Verify new tokens persisted to disk
        with open(handler.token_file) as f:
            data = json.load(f)
        assert data["access_token"] == "at-refreshed"

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_refresh_preserves_old_refresh_token_when_absent(self, mock_post, tmp_path):
        """If Schwab doesn't return a new refresh_token, keep the old one."""
        handler = _make_token_handler(tmp_path)
        with patch.object(handler, "_schedule_auto_refresh"):
            handler.save_tokens("at-old", "rt-keep-me", 1800)

        handler.access_token_expires_at = datetime.now() - timedelta(minutes=1)

        # Response without refresh_token
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = {"access_token": "at-new", "expires_in": 1800}
        mock_post.return_value = resp

        with patch.object(handler, "_schedule_auto_refresh"):
            handler.refresh_token_now()

        assert handler.access_token == "at-new"
        assert handler.refresh_token == "rt-keep-me"


# ===========================================================================
# 3. Refresh token expired → callback → re-login required
# ===========================================================================

class TestRefreshTokenExpiredTriggersRelogin:

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_invalid_grant_clears_and_fires_callback(self, mock_post, tmp_path):
        handler = _make_token_handler(tmp_path)
        with patch.object(handler, "_schedule_auto_refresh"):
            handler.save_tokens("at-old", "rt-expired", 1800)

        relogin_called = MagicMock()
        handler.on_refresh_token_expired = relogin_called

        mock_post.return_value = _invalid_grant_response()

        with pytest.raises(SchwabTokenExpiredError):
            handler.refresh_token_now()

        # Tokens should be cleared
        assert handler.access_token is None
        assert handler.refresh_token is None

        # Callback must have fired
        relogin_called.assert_called_once()

        # File should be deleted
        assert not os.path.exists(handler.token_file)

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_auto_refresh_catches_expired_gracefully(self, mock_post, tmp_path):
        """_auto_refresh_access_token must NOT raise; it logs instead."""
        handler = _make_token_handler(tmp_path)
        handler.refresh_token = "rt-expired"
        handler.on_refresh_token_expired = MagicMock()

        mock_post.return_value = _invalid_grant_response()

        with patch.object(handler, "_clear_tokens"):
            handler._auto_refresh_access_token()  # Should not raise


# ===========================================================================
# 4. Client._request: 401 → auto-refresh → retry succeeds
# ===========================================================================

class TestClientRequestAutoRefresh:
    """Client._request refreshes token on 401 and retries."""

    def test_401_triggers_refresh_and_retry(self, tmp_path):
        with patch.object(TokenHandler, "load_tokens", return_value=False):
            with patch.object(TokenHandler, "_schedule_auto_refresh"):
                client = Client.__new__(Client)
                client.client_id = "cid"
                client.client_secret = "secret"
                client.redirect_uri = "https://localhost:8080/callback"
                client.trader_base_url = "https://api.schwabapi.com/trader/v1"
                client.market_base_url = "https://api.schwabapi.com/marketdata/v1"
                client.token_handler = _make_token_handler(tmp_path)
                client.authentication = MagicMock()
                client._http = MagicMock()

        # Give handler tokens
        with patch.object(client.token_handler, "_schedule_auto_refresh"):
            client.token_handler.save_tokens("at-stale", "rt-valid", 1800)

        # First call returns 401, after refresh the second call returns 200
        resp_401 = MagicMock(spec=httpx.Response)
        resp_401.status_code = 401

        resp_200 = MagicMock(spec=httpx.Response)
        resp_200.status_code = 200
        resp_200.json.return_value = {"data": "ok"}

        call_count = 0

        def fake_request(**kwargs):
            nonlocal call_count
            call_count += 1
            if call_count <= 1:
                return resp_401
            return resp_200

        client._http.request = MagicMock(side_effect=fake_request)

        # Mock refresh_token_now to simulate successful refresh
        new_token = "at-fresh"
        def do_refresh():
            client.token_handler.access_token = new_token
            client.token_handler.access_token_expires_at = datetime.now() + timedelta(minutes=29)
            return True

        with patch.object(client.token_handler, "refresh_token_now", side_effect=do_refresh):
            with patch.object(client.token_handler, "_schedule_auto_refresh"):
                response = client._request("GET", "https://api.schwabapi.com/trader/v1/test")

        assert response.status_code == 200
        assert call_count >= 2  # at least 1 retry after refresh


# ===========================================================================
# 5. Full cycle: login → save → load from disk → still valid
# ===========================================================================

class TestLoginThenReloadFromDisk:
    """Simulate app restart: save tokens, create new handler, load from disk."""

    @patch("schwab_sdk.authentication.httpx.post")
    @patch("schwab_sdk.authentication.webbrowser.open")
    def test_tokens_survive_restart(self, mock_browser, mock_post, tmp_path):
        # First session: login
        auth1, handler1 = _make_auth(tmp_path)
        mock_post.return_value = _token_response("at-session1", "rt-session1", 1800)

        mock_server = MagicMock()
        mock_server.wait.return_value = {"params": {"code": "code-xyz"}}

        with patch.object(auth1, "_start_callback_server", return_value=True):
            auth1.callback_server = mock_server
            with patch.object(auth1, "_stop_callback_server"):
                with patch.object(handler1, "_schedule_auto_refresh"):
                    auth1.login()

        assert os.path.exists(handler1.token_file)
        token_file = handler1.token_file

        # Second session: new handler loading from the same file
        with patch.object(TokenHandler, "_schedule_auto_refresh"):
            handler2 = TokenHandler(
                "test-client-id", "test-secret",
                "https://localhost:8080/callback",
                token_path=token_file,
            )

        assert handler2.access_token == "at-session1"
        assert handler2.refresh_token == "rt-session1"
        assert handler2.has_valid_token() is True


# ===========================================================================
# 6. Full cycle: login → save encrypted → reload with correct key
# ===========================================================================

class TestLoginWithEncryption:

    @patch("schwab_sdk.authentication.httpx.post")
    @patch("schwab_sdk.authentication.webbrowser.open")
    def test_encrypted_tokens_round_trip(self, mock_browser, mock_post, tmp_path):
        handler = _make_token_handler(tmp_path, encryption_key="my-secret")
        auth = Authentication(
            "test-client-id", "test-secret",
            "https://localhost:8080/callback", handler,
        )

        mock_post.return_value = _token_response("at-enc", "rt-enc", 1800)

        mock_server = MagicMock()
        mock_server.wait.return_value = {"params": {"code": "code-enc"}}

        with patch.object(auth, "_start_callback_server", return_value=True):
            auth.callback_server = mock_server
            with patch.object(auth, "_stop_callback_server"):
                with patch.object(handler, "_schedule_auto_refresh"):
                    result = auth.login()

        assert result is True

        # Verify file is encrypted
        with open(handler.token_file) as f:
            raw = json.load(f)
        assert raw.get("encrypted") is True

        # Reload with same key
        with patch.object(TokenHandler, "_schedule_auto_refresh"):
            handler2 = TokenHandler(
                "test-client-id", "test-secret",
                "https://localhost:8080/callback",
                token_path=handler.token_file,
                encryption_key="my-secret",
            )
        assert handler2.access_token == "at-enc"
        assert handler2.refresh_token == "rt-enc"


# ===========================================================================
# 7. Async: exchange_code → refresh → new tokens
# ===========================================================================

class TestAsyncLoginAndRefresh:

    @pytest.mark.asyncio
    async def test_async_exchange_code_then_refresh(self, tmp_path):
        handler = _make_token_handler(tmp_path)
        auth = Authentication(
            "test-client-id", "test-secret",
            "https://localhost:8080/callback", handler,
        )

        # 1) Async code exchange
        token_resp = _token_response("at-async", "rt-async", 1800)
        mock_http = AsyncMock()
        mock_http.post.return_value = token_resp
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=None)

        with patch("schwab_sdk.authentication.httpx.AsyncClient", return_value=mock_http):
            with patch.object(handler, "_schedule_auto_refresh"):
                result = await auth.async_exchange_code("code-async")

        assert result is True
        assert handler.access_token == "at-async"
        assert handler.refresh_token == "rt-async"

        # 2) Force expiry, then async refresh
        handler.access_token_expires_at = datetime.now() - timedelta(minutes=1)
        assert handler.has_valid_token() is False

        refresh_resp = MagicMock()
        refresh_resp.status_code = 200
        refresh_resp.json.return_value = {
            "access_token": "at-async-refreshed",
            "refresh_token": "rt-async-refreshed",
            "expires_in": 1800,
        }

        mock_http2 = AsyncMock()
        mock_http2.post.return_value = refresh_resp
        mock_http2.__aenter__ = AsyncMock(return_value=mock_http2)
        mock_http2.__aexit__ = AsyncMock(return_value=None)

        with patch("schwab_sdk.token_handler.httpx.AsyncClient", return_value=mock_http2):
            with patch.object(handler, "_schedule_auto_refresh"):
                result = await handler.async_refresh_token_now()

        assert result is True
        assert handler.access_token == "at-async-refreshed"
        assert handler.refresh_token == "rt-async-refreshed"
        assert handler.has_valid_token() is True

    @pytest.mark.asyncio
    async def test_async_refresh_expired_raises(self, tmp_path):
        handler = _make_token_handler(tmp_path)
        with patch.object(handler, "_schedule_auto_refresh"):
            handler.save_tokens("at", "rt-expired", 1800)

        callback = MagicMock()
        handler.on_refresh_token_expired = callback

        mock_http = AsyncMock()
        mock_http.post.return_value = _invalid_grant_response()
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=None)

        with patch("schwab_sdk.token_handler.httpx.AsyncClient", return_value=mock_http):
            with pytest.raises(SchwabTokenExpiredError):
                await handler.async_refresh_token_now()

        assert handler.access_token is None
        callback.assert_called_once()


# ===========================================================================
# 8. Multiple refresh cycles
# ===========================================================================

class TestMultipleRefreshCycles:
    """Simulate several consecutive refresh cycles without re-login."""

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_three_consecutive_refreshes(self, mock_post, tmp_path):
        handler = _make_token_handler(tmp_path)
        with patch.object(handler, "_schedule_auto_refresh"):
            handler.save_tokens("at-0", "rt-0", 1800)

        for i in range(1, 4):
            # Expire the current access token
            handler.access_token_expires_at = datetime.now() - timedelta(seconds=1)
            assert handler.has_valid_token() is False

            mock_post.return_value = _token_response(f"at-{i}", f"rt-{i}", 1800)

            with patch.object(handler, "_schedule_auto_refresh"):
                result = handler.refresh_token_now()

            assert result is True
            assert handler.access_token == f"at-{i}"
            assert handler.refresh_token == f"rt-{i}"
            assert handler.has_valid_token() is True

        # Verify final state on disk
        with open(handler.token_file) as f:
            data = json.load(f)
        assert data["access_token"] == "at-3"
        assert data["refresh_token"] == "rt-3"


# ===========================================================================
# 9. Login already authenticated (skip flow)
# ===========================================================================

class TestLoginSkipsWhenAuthenticated:

    def test_skip_when_tokens_valid(self, tmp_path):
        handler = _make_token_handler(tmp_path)
        with patch.object(handler, "_schedule_auto_refresh"):
            handler.save_tokens("at-valid", "rt-valid", 1800)

        auth = Authentication(
            "test-client-id", "test-secret",
            "https://localhost:8080/callback", handler,
        )

        # Should return True without starting callback server
        result = auth.login()
        assert result is True
        # Tokens unchanged
        assert handler.access_token == "at-valid"


# ===========================================================================
# 10. Network error during refresh
# ===========================================================================

class TestRefreshNetworkError:

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_network_error_raises_auth_error(self, mock_post, tmp_path):
        handler = _make_token_handler(tmp_path)
        with patch.object(handler, "_schedule_auto_refresh"):
            handler.save_tokens("at", "rt", 1800)

        handler.access_token_expires_at = datetime.now() - timedelta(minutes=1)
        mock_post.side_effect = httpx.ConnectError("Connection refused")

        with pytest.raises(SchwabAuthenticationError, match="Network error"):
            handler.refresh_token_now()

        # Tokens should NOT be cleared on network error (transient)
        assert handler.refresh_token == "rt"


# ===========================================================================
# 11. Auto-refresh retry on transient error
# ===========================================================================

class TestAutoRefreshRetry:

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_auto_refresh_retries_on_transient_error(self, mock_post, tmp_path):
        """Transient failure reschedules with short delay."""
        handler = _make_token_handler(tmp_path)
        handler.refresh_token = "rt-valid"
        handler._auto_refresh_failures = 0

        mock_post.side_effect = httpx.ConnectError("Connection refused")

        with patch("threading.Timer") as mock_timer:
            timer_instance = MagicMock()
            mock_timer.return_value = timer_instance
            handler._auto_refresh_access_token()

        # Should schedule a retry with short delay (60s * 1 = 60s)
        mock_timer.assert_called_once_with(60, handler._auto_refresh_access_token)
        timer_instance.start.assert_called_once()
        assert handler._auto_refresh_failures == 1

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_auto_refresh_caps_retries(self, mock_post, tmp_path):
        """After N failures, falls back to 29-min interval."""
        handler = _make_token_handler(tmp_path)
        handler.refresh_token = "rt-valid"
        handler._auto_refresh_failures = 5  # Already at max

        mock_post.side_effect = httpx.ConnectError("Connection refused")

        with patch("threading.Timer") as mock_timer:
            timer_instance = MagicMock()
            mock_timer.return_value = timer_instance
            handler._auto_refresh_access_token()

        # Should fall back to 29-min interval
        mock_timer.assert_called_once_with(29 * 60, handler._auto_refresh_access_token)
        assert handler._auto_refresh_failures == 6

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_auto_refresh_resets_counter_on_success(self, mock_post, tmp_path):
        """Failure counter resets after successful refresh."""
        handler = _make_token_handler(tmp_path)
        handler._auto_refresh_failures = 3

        with patch.object(handler, "_schedule_auto_refresh"):
            handler.save_tokens("at-old", "rt-valid", 1800)

        mock_post.return_value = _token_response("at-new", "rt-new", 1800)

        with patch.object(handler, "_schedule_auto_refresh"):
            handler._auto_refresh_access_token()

        assert handler._auto_refresh_failures == 0
        assert handler.access_token == "at-new"

    @patch("schwab_sdk.token_handler.httpx.post")
    def test_auto_refresh_no_double_timer(self, mock_post, tmp_path):
        """Only ONE timer is running after successful auto-refresh (no double-fire)."""
        handler = _make_token_handler(tmp_path)
        with patch.object(handler, "_schedule_auto_refresh"):
            handler.save_tokens("at-old", "rt-valid", 1800)

        mock_post.return_value = _token_response("at-new", "rt-new", 1800)

        # Track all Timer creations
        timers_created = []
        original_timer = threading.Timer

        def tracking_timer(*args, **kwargs):
            t = original_timer(*args, **kwargs)
            timers_created.append(t)
            return t

        with patch("threading.Timer", side_effect=tracking_timer):
            handler._auto_refresh_access_token()

        # _schedule_auto_refresh creates timers (access + refresh token).
        # The old bug would create an extra timer in _auto_refresh_access_token itself.
        # With the fix, only _schedule_auto_refresh creates timers.
        # Count access token timers (targeting _auto_refresh_access_token)
        access_timers = [
            t for t in timers_created
            if t.function == handler._auto_refresh_access_token
        ]
        assert len(access_timers) == 1, (
            f"Expected exactly 1 access token timer, got {len(access_timers)}"
        )


# ===========================================================================
# 12. load_tokens thread safety
# ===========================================================================

class TestLoadTokensThreadSafe:

    def test_load_tokens_thread_safe(self, tmp_path):
        """Concurrent load/save doesn't corrupt state."""
        handler = _make_token_handler(tmp_path)

        # Write initial tokens to disk
        with patch.object(handler, "_schedule_auto_refresh"):
            handler.save_tokens("at-initial", "rt-initial", 1800)

        errors = []

        def save_loop():
            for i in range(20):
                try:
                    with patch.object(handler, "_schedule_auto_refresh"):
                        handler.save_tokens(f"at-save-{i}", f"rt-save-{i}", 1800)
                except Exception as e:
                    errors.append(e)

        def load_loop():
            for _ in range(20):
                try:
                    handler.load_tokens()
                except Exception as e:
                    errors.append(e)

        t1 = threading.Thread(target=save_loop)
        t2 = threading.Thread(target=load_loop)
        t1.start()
        t2.start()
        t1.join(timeout=10)
        t2.join(timeout=10)

        assert not errors, f"Concurrent access errors: {errors}"
        # After all operations, handler should have consistent state
        assert handler.access_token is not None
        assert handler.refresh_token is not None


# ===========================================================================
# 13. 401 retry skips when no token after refresh
# ===========================================================================

class TestRetrySkipsWhenNoTokenAfterRefresh:

    def test_401_retry_skips_when_no_token_after_refresh(self, tmp_path):
        """If refresh 'succeeds' but get_access_token() returns None, don't retry."""
        with patch.object(TokenHandler, "load_tokens", return_value=False):
            with patch.object(TokenHandler, "_schedule_auto_refresh"):
                client = Client.__new__(Client)
                client.client_id = "cid"
                client.client_secret = "secret"
                client.redirect_uri = "https://localhost:8080/callback"
                client.trader_base_url = "https://api.schwabapi.com/trader/v1"
                client.market_base_url = "https://api.schwabapi.com/marketdata/v1"
                client.token_handler = _make_token_handler(tmp_path)
                client.authentication = MagicMock()
                client._http = MagicMock()

        # Give handler tokens
        with patch.object(client.token_handler, "_schedule_auto_refresh"):
            client.token_handler.save_tokens("at-stale", "rt-valid", 1800)

        resp_401 = MagicMock(spec=httpx.Response)
        resp_401.status_code = 401

        call_count = 0

        def fake_request(**kwargs):
            nonlocal call_count
            call_count += 1
            return resp_401

        client._http.request = MagicMock(side_effect=fake_request)

        # refresh_token_now returns True but tokens are expired (get_access_token returns None)
        def do_refresh():
            client.token_handler.access_token = "at-new"
            # But set expiry in the past so get_access_token() returns None
            client.token_handler.access_token_expires_at = datetime.now() - timedelta(minutes=5)
            return True

        with patch.object(client.token_handler, "refresh_token_now", side_effect=do_refresh):
            response = client._request("GET", "https://api.schwabapi.com/trader/v1/test")

        assert response.status_code == 401
        # Should only have been called once — no retry since get_access_token() returned None
        assert call_count == 1
