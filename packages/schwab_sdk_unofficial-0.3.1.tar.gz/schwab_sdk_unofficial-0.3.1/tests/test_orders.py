"""Tests for schwab_sdk.orders module."""

import pytest
from unittest.mock import MagicMock, AsyncMock

import httpx

from schwab_sdk.orders import (
    Orders, AsyncOrders,
    _extract_order_id_from_location,
    _build_order_result,
    _build_error_result,
)
from schwab_sdk.exceptions import SchwabValidationError, SchwabServerError
from tests.conftest import make_mock_response


# ===== _extract_order_id_from_location =====

class TestExtractOrderId:
    def test_standard_location(self):
        loc = "https://api.schwabapi.com/trader/v1/accounts/hash/orders/12345"
        assert _extract_order_id_from_location(loc) == "12345"

    def test_none_returns_none(self):
        assert _extract_order_id_from_location(None) is None

    def test_empty_returns_none(self):
        assert _extract_order_id_from_location("") is None

    def test_trailing_slash(self):
        loc = "https://api.schwabapi.com/trader/v1/accounts/hash/orders/12345/"
        result = _extract_order_id_from_location(loc)
        assert result == "12345"

    def test_no_orders_path_falls_back(self):
        loc = "https://example.com/something/67890"
        result = _extract_order_id_from_location(loc)
        assert result == "67890"


# ===== _build_order_result =====

class TestBuildOrderResult:
    def test_success_200(self):
        resp = make_mock_response(200, [{"orderId": "123"}])
        result = _build_order_result(resp, method="GET")
        assert result["success"] is True
        assert result["status_code"] == 200
        assert result["data"] == [{"orderId": "123"}]

    def test_success_201_with_location(self):
        resp = make_mock_response(
            201, {},
            headers={"Location": "https://api.schwabapi.com/trader/v1/accounts/h/orders/99"},
            text="",
        )
        resp.json.return_value = {}
        resp.text = ""
        result = _build_order_result(resp, method="POST")
        assert result["success"] is True
        assert result["order_id"] == "99"

    def test_success_204_empty_body(self):
        resp = make_mock_response(204, None, text="")
        resp.json.side_effect = Exception("no body")
        resp.text = ""
        result = _build_order_result(resp, method="DELETE")
        assert result["success"] is True

    def test_error_400_raises(self):
        resp = make_mock_response(400, {"message": "bad request"})
        with pytest.raises(SchwabValidationError):
            _build_order_result(resp, method="POST")

    def test_error_500_raises(self):
        resp = make_mock_response(500, {"message": "server error"})
        with pytest.raises(SchwabServerError):
            _build_order_result(resp, method="GET")

    def test_params_included(self):
        resp = make_mock_response(200, [])
        result = _build_order_result(resp, method="GET", params={"key": "val"})
        assert result["params"] == {"key": "val"}

    def test_order_id_passed_through(self):
        resp = make_mock_response(200, {"orderId": "123"})
        result = _build_order_result(resp, method="GET", order_id="123")
        assert result["order_id"] == "123"


# ===== _build_error_result =====

class TestBuildErrorResult:
    def test_basic_error(self):
        exc = httpx.ConnectError("Connection refused")
        result = _build_error_result(exc, "https://api.test/orders", method="GET")
        assert result["success"] is False
        assert result["status_code"] == 0
        assert "Connection refused" in result["error_message"]

    def test_with_params(self):
        exc = httpx.ConnectError("timeout")
        result = _build_error_result(exc, "url", method="POST", params={"a": 1})
        assert result["params"] == {"a": 1}

    def test_with_order_id(self):
        exc = httpx.ConnectError("err")
        result = _build_error_result(exc, "url", method="DELETE", order_id="456")
        assert result["order_id"] == "456"


# ===== Order Builders =====

class TestOrderBuilders:
    def test_build_limit_order_happy(self):
        order = Orders.build_limit_order("AAPL", 10, 150.0)
        assert order["orderType"] == "LIMIT"
        assert order["price"] == 150.0
        assert order["orderLegCollection"][0]["quantity"] == 10
        assert order["orderLegCollection"][0]["instruction"] == "BUY"
        assert order["orderLegCollection"][0]["instrument"]["symbol"] == "AAPL"

    def test_build_limit_order_sell(self):
        order = Orders.build_limit_order("MSFT", 5, 300.0, instruction="SELL")
        assert order["orderLegCollection"][0]["instruction"] == "SELL"

    def test_build_limit_order_zero_qty_raises(self):
        with pytest.raises(ValueError, match="quantity"):
            Orders.build_limit_order("AAPL", 0, 150.0)

    def test_build_limit_order_negative_qty_raises(self):
        with pytest.raises(ValueError, match="quantity"):
            Orders.build_limit_order("AAPL", -1, 150.0)

    def test_build_limit_order_zero_price_raises(self):
        with pytest.raises(ValueError, match="price"):
            Orders.build_limit_order("AAPL", 10, 0)

    def test_build_limit_order_invalid_instruction_raises(self):
        with pytest.raises(ValueError):
            Orders.build_limit_order("AAPL", 10, 150.0, instruction="INVALID")

    def test_build_market_order_happy(self):
        order = Orders.build_market_order("AAPL", 10)
        assert order["orderType"] == "MARKET"
        assert "price" not in order
        assert order["orderLegCollection"][0]["quantity"] == 10

    def test_build_market_order_zero_qty_raises(self):
        with pytest.raises(ValueError, match="quantity"):
            Orders.build_market_order("AAPL", 0)

    def test_build_bracket_order_happy(self):
        order = Orders.build_bracket_order("AAPL", 10, 150.0, 160.0, 140.0)
        assert order["orderStrategyType"] == "TRIGGER"
        assert order["price"] == 150.0
        children = order["childOrderStrategies"]
        assert len(children) == 1
        assert children[0]["orderStrategyType"] == "OCO"
        assert len(children[0]["childOrderStrategies"]) == 2

    def test_build_bracket_order_zero_qty_raises(self):
        with pytest.raises(ValueError, match="quantity"):
            Orders.build_bracket_order("AAPL", 0, 150.0, 160.0, 140.0)

    def test_build_bracket_order_zero_entry_raises(self):
        with pytest.raises(ValueError, match="entry_price"):
            Orders.build_bracket_order("AAPL", 10, 0, 160.0, 140.0)

    def test_build_bracket_order_zero_take_profit_raises(self):
        with pytest.raises(ValueError, match="take_profit"):
            Orders.build_bracket_order("AAPL", 10, 150.0, 0, 140.0)

    def test_build_bracket_order_zero_stop_loss_raises(self):
        with pytest.raises(ValueError, match="stop_loss"):
            Orders.build_bracket_order("AAPL", 10, 150.0, 160.0, 0)

    def test_async_orders_delegates_builders(self):
        assert AsyncOrders.build_limit_order is Orders.build_limit_order
        assert AsyncOrders.build_market_order is Orders.build_market_order
        assert AsyncOrders.build_bracket_order is Orders.build_bracket_order


# ===== Sync Orders =====

class TestOrders:
    def setup_method(self):
        self.client = MagicMock()
        self.client.trader_base_url = "https://api.schwabapi.com/trader/v1"
        self.orders = Orders(self.client)

    def test_get_orders_default_dates(self):
        resp = make_mock_response(200, [{"orderId": "1"}])
        self.client._request.return_value = resp
        result = self.orders.get_orders("hash1")
        assert result["success"] is True

    def test_place_order_201(self):
        resp = make_mock_response(
            201, {},
            headers={"Location": "https://api.schwabapi.com/trader/v1/accounts/h/orders/555"},
            text="",
        )
        resp.json.return_value = {}
        resp.text = ""
        self.client._request.return_value = resp
        result = self.orders.place_order("hash1", {"orderType": "MARKET"})
        assert result["success"] is True
        assert result["order_id"] == "555"

    def test_cancel_order(self):
        resp = make_mock_response(200, {})
        self.client._request.return_value = resp
        result = self.orders.cancel_order("hash1", "123")
        assert result["success"] is True

    def test_replace_order(self):
        resp = make_mock_response(201, {}, headers={
            "Location": "https://api.schwabapi.com/trader/v1/accounts/h/orders/999"
        }, text="")
        resp.json.return_value = {}
        resp.text = ""
        self.client._request.return_value = resp
        result = self.orders.replace_order("hash1", "123", {"orderType": "LIMIT"})
        assert result["success"] is True
        assert result["original_order_id"] == "123"

    def test_get_all_orders(self):
        resp = make_mock_response(200, [])
        self.client._request.return_value = resp
        result = self.orders.get_all_orders()
        assert result["success"] is True

    def test_preview_order(self):
        resp = make_mock_response(200, {"preview": True})
        self.client._request.return_value = resp
        result = self.orders.preview_order("hash1", {"orderType": "LIMIT"})
        assert result["success"] is True

    def test_get_order(self):
        resp = make_mock_response(200, {"orderId": "123"})
        self.client._request.return_value = resp
        result = self.orders.get_order("hash1", "123")
        assert result["success"] is True
        assert result["order_id"] == "123"

    def test_network_error_returns_error_result(self):
        self.client._request.side_effect = httpx.ConnectError("refused")
        result = self.orders.get_orders("hash1")
        assert result["success"] is False
        assert "refused" in result["error_message"]

    def test_place_order_network_error(self):
        self.client._request.side_effect = httpx.ConnectError("timeout")
        result = self.orders.place_order("hash1", {})
        assert result["success"] is False

    def test_replace_order_network_error(self):
        self.client._request.side_effect = httpx.ConnectError("err")
        result = self.orders.replace_order("hash1", "123", {})
        assert result["success"] is False
        assert result["original_order_id"] == "123"

    def test_get_orders_with_status(self):
        resp = make_mock_response(200, [])
        self.client._request.return_value = resp
        result = self.orders.get_orders("hash1", status="FILLED")
        assert result["success"] is True

    def test_get_orders_with_max_results(self):
        resp = make_mock_response(200, [])
        self.client._request.return_value = resp
        result = self.orders.get_orders("hash1", max_results=10)
        assert result["success"] is True


# ===== Async Orders =====

class TestAsyncOrders:
    def setup_method(self):
        self.client = MagicMock()
        self.client.trader_base_url = "https://api.schwabapi.com/trader/v1"
        self.client._request = AsyncMock()
        self.orders = AsyncOrders(self.client)

    @pytest.mark.asyncio
    async def test_get_orders(self):
        resp = make_mock_response(200, [])
        self.client._request.return_value = resp
        result = await self.orders.get_orders("hash1")
        assert result["success"] is True

    @pytest.mark.asyncio
    async def test_place_order(self):
        resp = make_mock_response(201, {}, headers={
            "Location": "https://api.schwabapi.com/trader/v1/accounts/h/orders/777"
        }, text="")
        resp.json.return_value = {}
        resp.text = ""
        self.client._request.return_value = resp
        result = await self.orders.place_order("hash1", {})
        assert result["success"] is True
        assert result["order_id"] == "777"

    @pytest.mark.asyncio
    async def test_cancel_order(self):
        resp = make_mock_response(200, {})
        self.client._request.return_value = resp
        result = await self.orders.cancel_order("hash1", "123")
        assert result["success"] is True

    @pytest.mark.asyncio
    async def test_replace_order(self):
        resp = make_mock_response(200, {})
        self.client._request.return_value = resp
        result = await self.orders.replace_order("hash1", "123", {})
        assert result["success"] is True
        assert result["original_order_id"] == "123"

    @pytest.mark.asyncio
    async def test_get_all_orders(self):
        resp = make_mock_response(200, [])
        self.client._request.return_value = resp
        result = await self.orders.get_all_orders()
        assert result["success"] is True

    @pytest.mark.asyncio
    async def test_preview_order(self):
        resp = make_mock_response(200, {})
        self.client._request.return_value = resp
        result = await self.orders.preview_order("hash1", {})
        assert result["success"] is True

    @pytest.mark.asyncio
    async def test_get_order(self):
        resp = make_mock_response(200, {"orderId": "123"})
        self.client._request.return_value = resp
        result = await self.orders.get_order("hash1", "123")
        assert result["success"] is True

    @pytest.mark.asyncio
    async def test_network_error(self):
        self.client._request.side_effect = httpx.ConnectError("err")
        result = await self.orders.place_order("hash1", {})
        assert result["success"] is False

    @pytest.mark.asyncio
    async def test_replace_order_network_error(self):
        self.client._request.side_effect = httpx.ConnectError("err")
        result = await self.orders.replace_order("hash1", "123", {})
        assert result["success"] is False
        assert result["original_order_id"] == "123"
