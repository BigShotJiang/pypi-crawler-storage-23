"""Tests for schwab_sdk.streaming module."""

import json
from unittest.mock import MagicMock, AsyncMock, patch, call

import pytest

from schwab_sdk.streaming import (
    Streaming, AsyncStreaming,
    _create_option_symbol, _parse_streamer_info, _dispatch_message,
    _DEFAULT_FIELDS,
)
from schwab_sdk.enums import StreamService, StreamCommand


# ===== _create_option_symbol =====

class TestCreateOptionSymbol:
    def test_call_format(self):
        result = _create_option_symbol("AAPL", "2025-10-03", "C", 257.5)
        assert result.startswith("AAPL")
        assert "C" in result
        assert "00257500" in result
        assert "251003" in result

    def test_put_format(self):
        result = _create_option_symbol("MSFT", "2025-12-19", "P", 200.0)
        assert "P" in result
        assert "00200000" in result

    def test_short_symbol_padded(self):
        result = _create_option_symbol("F", "2025-01-17", "C", 10.0)
        # Symbol should be padded to 6 chars
        assert len(result.split("2")[0].rstrip()) <= 6

    def test_fractional_strike(self):
        result = _create_option_symbol("AAPL", "2025-06-20", "C", 150.5)
        assert "00150500" in result

    def test_static_method_on_streaming(self):
        result = Streaming.create_option_symbol("AAPL", "2025-10-03", "C", 257.5)
        assert "AAPL" in result


# ===== _parse_streamer_info =====

class TestParseStreamerInfo:
    def test_flat_prefs(self):
        obj = MagicMock()
        obj._streamer_url = None
        obj._schwab_client_customer_id = None
        obj._schwab_client_correl_id = None
        obj._schwab_client_channel = None
        obj._schwab_client_function_id = None

        prefs = {
            "streamerInfo": [
                {
                    "streamerSocketUrl": "wss://stream.example.com",
                    "schwabClientCustomerId": "cust-1",
                    "schwabClientCorrelId": "corr-1",
                    "schwabClientChannel": "channel-1",
                    "schwabClientFunctionId": "func-1",
                }
            ]
        }
        _parse_streamer_info(obj, prefs)
        assert obj._streamer_url == "wss://stream.example.com"
        assert obj._schwab_client_customer_id == "cust-1"

    def test_nested_dict_prefs(self):
        obj = MagicMock()
        obj._streamer_url = None
        obj._schwab_client_customer_id = None
        obj._schwab_client_correl_id = None
        obj._schwab_client_channel = None
        obj._schwab_client_function_id = None

        prefs = {
            "streamerInfo": {
                "streamerSocketUrl": "wss://stream.example.com",
                "schwabClientCustomerId": "cust-2",
                "schwabClientCorrelId": "corr-2",
                "schwabClientChannel": "channel-2",
                "schwabClientFunctionId": "func-2",
            }
        }
        _parse_streamer_info(obj, prefs)
        assert obj._schwab_client_customer_id == "cust-2"

    def test_missing_streamer_info_defaults(self):
        obj = MagicMock()
        obj._streamer_url = None
        obj._schwab_client_customer_id = None
        obj._schwab_client_correl_id = None
        obj._schwab_client_channel = None
        obj._schwab_client_function_id = None

        _parse_streamer_info(obj, {})
        # Should not raise; values remain as set by mock


# ===== _dispatch_message =====

class TestDispatchMessage:
    def test_data_message(self):
        obj = MagicMock()
        obj._on_data = MagicMock()
        obj._on_response = None
        obj._on_notify = None
        obj._is_logged_in = True

        msg = json.dumps({"data": [{"service": "LEVELONE_EQUITIES", "content": []}]})
        _dispatch_message(obj, msg)
        obj._on_data.assert_called_once()

    def test_notify_message(self):
        obj = MagicMock()
        obj._on_data = None
        obj._on_response = None
        obj._on_notify = MagicMock()
        obj._is_logged_in = True

        msg = json.dumps({"notify": [{"heartbeat": "1234"}]})
        _dispatch_message(obj, msg)
        obj._on_notify.assert_called_once()

    def test_response_message(self):
        obj = MagicMock()
        obj._on_data = None
        obj._on_response = MagicMock()
        obj._on_notify = None
        obj._is_logged_in = False
        obj._subscriptions = []
        obj._resubscribe_all = MagicMock()

        msg = json.dumps({"response": [{"service": "ADMIN", "command": "LOGIN", "content": {"code": 0}}]})
        _dispatch_message(obj, msg)
        obj._on_response.assert_called_once()

    def test_login_success_sets_logged_in(self):
        obj = MagicMock()
        obj._on_data = None
        obj._on_response = None
        obj._on_notify = None
        obj._is_logged_in = False
        obj._subscriptions = []

        msg = json.dumps({"response": [{"service": "ADMIN", "command": "LOGIN", "content": {"code": 0}}]})
        _dispatch_message(obj, msg)
        assert obj._is_logged_in is True

    def test_login_fail_does_not_set_logged_in(self):
        obj = MagicMock()
        obj._on_data = None
        obj._on_response = None
        obj._on_notify = None
        obj._is_logged_in = False

        msg = json.dumps({"response": [{"service": "ADMIN", "command": "LOGIN", "content": {"code": 3}}]})
        _dispatch_message(obj, msg)
        assert obj._is_logged_in is False


# ===== Default fields =====

class TestDefaultFields:
    def test_all_services_have_defaults(self):
        expected_services = [
            StreamService.LEVELONE_EQUITIES, StreamService.LEVELONE_OPTIONS,
            StreamService.LEVELONE_FUTURES, StreamService.LEVELONE_FUTURES_OPTIONS,
            StreamService.LEVELONE_FOREX,
            StreamService.NASDAQ_BOOK, StreamService.NYSE_BOOK, StreamService.OPTIONS_BOOK,
            StreamService.CHART_EQUITY, StreamService.CHART_FUTURES,
            StreamService.SCREENER_EQUITY, StreamService.SCREENER_OPTION,
            StreamService.ACCT_ACTIVITY,
        ]
        for svc in expected_services:
            assert svc in _DEFAULT_FIELDS
            assert isinstance(_DEFAULT_FIELDS[svc], list)
            assert len(_DEFAULT_FIELDS[svc]) > 0


# ===== Sync Streaming =====

class TestStreaming:
    def setup_method(self):
        self.client = MagicMock()
        self.client.get_access_token.return_value = "fake-token"
        self.client.account.get_user_preferences.return_value = {
            "streamerInfo": [{
                "streamerSocketUrl": "wss://stream.example.com",
                "schwabClientCustomerId": "cust",
                "schwabClientCorrelId": "corr",
                "schwabClientChannel": "chan",
                "schwabClientFunctionId": "func",
            }]
        }
        self.streaming = Streaming(self.client)

    def test_callback_registration(self):
        cb = MagicMock()
        self.streaming.on_data(cb)
        assert self.streaming._on_data is cb

        cb2 = MagicMock()
        self.streaming.on_response(cb2)
        assert self.streaming._on_response is cb2

        cb3 = MagicMock()
        self.streaming.on_notify(cb3)
        assert self.streaming._on_notify is cb3

    @patch("schwab_sdk.streaming.websocket")
    def test_connect_creates_ws(self, mock_ws_module):
        mock_ws_module.WebSocketApp = MagicMock()
        self.streaming.connect()
        assert self.streaming._ws is not None
        assert self.streaming._should_run is True

    @patch("schwab_sdk.streaming.websocket", None)
    def test_connect_no_library_raises(self):
        with pytest.raises(RuntimeError, match="websocket-client"):
            self.streaming.connect()

    def test_connect_already_connected(self):
        self.streaming._ws = MagicMock()
        self.streaming.connect()  # Should be a no-op

    def test_login_builds_payload(self):
        self.streaming._ws = MagicMock()
        self.streaming._connected_event.set()
        self.streaming.login()
        assert self.streaming._last_login_payload is not None
        payload = self.streaming._last_login_payload
        req = payload["requests"][0]
        assert req["service"] == "ADMIN"
        assert req["command"] == "LOGIN"
        assert req["parameters"]["Authorization"] == "fake-token"

    def test_login_no_token_raises(self):
        self.client.get_access_token.return_value = None
        self.client.refresh_token_now.return_value = False
        self.streaming._ws = MagicMock()
        self.streaming._connected_event.set()
        with pytest.raises(RuntimeError, match="No access token"):
            self.streaming.login()

    def test_logout_when_not_logged_in(self):
        self.streaming._is_logged_in = False
        self.streaming.logout()  # Should be a no-op

    def test_logout_sends_payload(self):
        self.streaming._is_logged_in = True
        self.streaming._ws = MagicMock()
        self.streaming._schwab_client_customer_id = "cust"
        self.streaming._schwab_client_correl_id = "corr"
        self.streaming.logout()
        assert self.streaming._is_logged_in is False

    def test_subscribe(self):
        self.streaming._ws = MagicMock()
        self.streaming._schwab_client_customer_id = "cust"
        self.streaming.subscribe("LEVELONE_EQUITIES", ["AAPL", "MSFT"])
        assert len(self.streaming._subscriptions) == 1

    def test_add(self):
        self.streaming._ws = MagicMock()
        self.streaming._schwab_client_customer_id = "cust"
        self.streaming.add("LEVELONE_EQUITIES", ["GOOG"])
        assert len(self.streaming._subscriptions) == 1

    def test_unsubscribe(self):
        self.streaming._ws = MagicMock()
        self.streaming._schwab_client_customer_id = "cust"
        self.streaming.unsubscribe("LEVELONE_EQUITIES", ["AAPL"])
        assert len(self.streaming._subscriptions) == 1

    def test_view(self):
        self.streaming._ws = MagicMock()
        self.streaming._schwab_client_customer_id = "cust"
        self.streaming.view("LEVELONE_EQUITIES", [0, 1, 2])
        assert len(self.streaming._subscriptions) == 1

    def test_equities_subscribe_default_fields(self):
        self.streaming._ws = MagicMock()
        self.streaming._schwab_client_customer_id = "cust"
        self.streaming.equities_subscribe(["AAPL"])
        payload = self.streaming._subscriptions[-1]
        params = payload["requests"][0]["parameters"]
        assert "fields" in params

    def test_options_subscribe(self):
        self.streaming._ws = MagicMock()
        self.streaming._schwab_client_customer_id = "cust"
        self.streaming.options_subscribe(["AAPL_OPT"])
        assert len(self.streaming._subscriptions) >= 1

    def test_futures_subscribe(self):
        self.streaming._ws = MagicMock()
        self.streaming._schwab_client_customer_id = "cust"
        self.streaming.futures_subscribe(["/ESH25"])
        assert len(self.streaming._subscriptions) >= 1

    def test_forex_subscribe(self):
        self.streaming._ws = MagicMock()
        self.streaming._schwab_client_customer_id = "cust"
        self.streaming.forex_subscribe(["EUR/USD"])
        assert len(self.streaming._subscriptions) >= 1

    def test_nasdaq_book(self):
        self.streaming._ws = MagicMock()
        self.streaming._schwab_client_customer_id = "cust"
        self.streaming.nasdaq_book(["AAPL"])
        assert len(self.streaming._subscriptions) >= 1

    def test_chart_equity(self):
        self.streaming._ws = MagicMock()
        self.streaming._schwab_client_customer_id = "cust"
        self.streaming.chart_equity(["AAPL"])
        assert len(self.streaming._subscriptions) >= 1

    def test_screener_equity(self):
        self.streaming._ws = MagicMock()
        self.streaming._schwab_client_customer_id = "cust"
        self.streaming.screener_equity(["KEY1"])
        assert len(self.streaming._subscriptions) >= 1

    def test_account_activity_cached_hash(self):
        self.streaming._ws = MagicMock()
        self.streaming._schwab_client_customer_id = "cust"
        self.client._account_hash = "cached-hash"
        self.streaming.account_activity()
        assert len(self.streaming._subscriptions) >= 1

    def test_account_activity_lookup(self):
        self.streaming._ws = MagicMock()
        self.streaming._schwab_client_customer_id = "cust"
        # Use spec to avoid auto-creating _account_hash
        self.client.configure_mock(**{"_account_hash": None})
        self.client.account.get_account_numbers.return_value = [
            {"accountHash": "hash-from-api"}
        ]
        self.streaming.account_activity()
        assert len(self.streaming._subscriptions) >= 1

    def test_account_activity_no_hash_raises(self):
        self.streaming._ws = MagicMock()
        self.streaming._schwab_client_customer_id = "cust"
        self.client.configure_mock(**{"_account_hash": None})
        self.client.account.get_account_numbers.return_value = []
        with pytest.raises(RuntimeError, match="account hash"):
            self.streaming.account_activity()

    def test_send_not_connected_raises(self):
        self.streaming._ws = None
        with pytest.raises(RuntimeError, match="not connected"):
            self.streaming._send({"test": True})

    def test_on_open_sets_event(self):
        self.streaming._on_open(None)
        assert self.streaming._connected_event.is_set()

    def test_on_close_clears(self):
        self.streaming._is_logged_in = True
        self.streaming._connected_event.set()
        self.streaming._on_close(None)
        assert self.streaming._is_logged_in is False
        assert not self.streaming._connected_event.is_set()

    def test_on_error_calls_response_callback(self):
        cb = MagicMock()
        self.streaming._on_response = cb
        self.streaming._on_error(None, "test error")
        cb.assert_called_once()

    def test_resubscribe_all(self):
        self.streaming._ws = MagicMock()
        self.streaming._subscriptions = [{"requests": [{"test": True}]}]
        self.streaming._resubscribe_all()
        self.streaming._ws.send.assert_called()


# ===== Async Streaming =====

class TestAsyncStreaming:
    def setup_method(self):
        self.client = MagicMock()
        self.client.get_access_token.return_value = "fake-token"
        self.client.account = MagicMock()
        self.client.account.get_user_preferences = AsyncMock(return_value={
            "streamerInfo": [{
                "streamerSocketUrl": "wss://stream.example.com",
                "schwabClientCustomerId": "cust",
                "schwabClientCorrelId": "corr",
                "schwabClientChannel": "chan",
                "schwabClientFunctionId": "func",
            }]
        })
        self.streaming = AsyncStreaming(self.client)

    def test_callback_registration(self):
        cb = MagicMock()
        self.streaming.on_data(cb)
        assert self.streaming._on_data is cb

    @pytest.mark.asyncio
    async def test_connect_no_library_raises(self):
        with patch("schwab_sdk.streaming.websockets", None):
            with pytest.raises(RuntimeError, match="websockets"):
                await self.streaming.connect()

    @pytest.mark.asyncio
    async def test_connect_already_connected(self):
        self.streaming._ws = MagicMock()
        await self.streaming.connect()  # Should be a no-op

    @pytest.mark.asyncio
    async def test_login_builds_payload(self):
        self.streaming._ws = AsyncMock()
        self.streaming._connected_event.set()
        await self.streaming.login()
        assert self.streaming._last_login_payload is not None

    @pytest.mark.asyncio
    async def test_subscribe(self):
        self.streaming._ws = AsyncMock()
        self.streaming._schwab_client_customer_id = "cust"
        await self.streaming.subscribe("LEVELONE_EQUITIES", ["AAPL"])
        assert len(self.streaming._subscriptions) >= 1

    @pytest.mark.asyncio
    async def test_equities_subscribe(self):
        self.streaming._ws = AsyncMock()
        self.streaming._schwab_client_customer_id = "cust"
        await self.streaming.equities_subscribe(["AAPL"])
        assert len(self.streaming._subscriptions) >= 1
