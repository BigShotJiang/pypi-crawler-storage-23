"""Tests for schwab_sdk.accounts module."""

import pytest
from unittest.mock import MagicMock, AsyncMock

from schwab_sdk.accounts import (
    Accounts, AsyncAccounts,
    _build_accounts_params, _build_transaction_params,
)
from schwab_sdk.exceptions import SchwabNotFoundError
from tests.conftest import make_mock_response


# ===== _build_accounts_params =====

class TestBuildAccountsParams:
    def test_none_fields(self):
        result = _build_accounts_params(None, None)
        assert result == {}

    def test_empty_fields(self):
        result = _build_accounts_params([], None)
        assert result == {}

    def test_positions_field(self):
        result = _build_accounts_params(["positions"], None)
        assert result["fields"] == "positions"

    def test_invalid_field_raises(self):
        with pytest.raises(ValueError):
            _build_accounts_params(["invalid_field"], None)

    def test_extra_params_merged(self):
        result = _build_accounts_params(None, {"extra": "value"})
        assert result["extra"] == "value"

    def test_fields_with_extra_params(self):
        result = _build_accounts_params(["positions"], {"extra": "val"})
        assert result["fields"] == "positions"
        assert result["extra"] == "val"


# ===== _build_transaction_params =====

class TestBuildTransactionParams:
    def test_all_none(self):
        result = _build_transaction_params(None, None, None, None, None)
        assert result == {}

    def test_date_range(self):
        result = _build_transaction_params("2024-01-01", "2024-01-31", None, None, None)
        assert "startDate" in result
        assert "endDate" in result

    def test_transaction_types(self):
        result = _build_transaction_params(None, None, ["TRADE", "DIVIDEND_OR_INTEREST"], None, None)
        assert "types" in result
        assert "TRADE" in result["types"]
        assert "DIVIDEND_OR_INTEREST" in result["types"]

    def test_invalid_transaction_type_raises(self):
        with pytest.raises(ValueError):
            _build_transaction_params(None, None, ["INVALID_TYPE"], None, None)

    def test_symbol_param(self):
        result = _build_transaction_params(None, None, None, "AAPL", None)
        assert result["symbol"] == "AAPL"

    def test_filters_merged(self):
        result = _build_transaction_params(None, None, None, None, {"custom": "val"})
        assert result["custom"] == "val"


# ===== Sync Accounts =====

class TestAccounts:
    def setup_method(self):
        self.client = MagicMock()
        self.client.trader_base_url = "https://api.schwabapi.com/trader/v1"
        self.accounts = Accounts(self.client)

    def test_get_account_numbers(self):
        resp = make_mock_response(200, [{"accountNumber": "1234", "hashValue": "hash1"}])
        self.client._request.return_value = resp
        result = self.accounts.get_account_numbers()
        assert result == [{"accountNumber": "1234", "hashValue": "hash1"}]
        self.client._request.assert_called_once()

    def test_get_accounts_no_fields(self):
        resp = make_mock_response(200, [{"accountNumber": "1234"}])
        self.client._request.return_value = resp
        result = self.accounts.get_accounts()
        assert isinstance(result, list)

    def test_get_accounts_with_positions(self):
        resp = make_mock_response(200, [{"accountNumber": "1234", "positions": []}])
        self.client._request.return_value = resp
        result = self.accounts.get_accounts(fields=["positions"])
        call_args = self.client._request.call_args
        assert "positions" in str(call_args)

    def test_get_account_by_id(self):
        resp = make_mock_response(200, {"accountNumber": "1234"})
        self.client._request.return_value = resp
        result = self.accounts.get_account_by_id("hash1")
        assert result["accountNumber"] == "1234"

    def test_get_account_by_id_error(self):
        resp = make_mock_response(404, {"message": "not found"})
        self.client._request.return_value = resp
        with pytest.raises(SchwabNotFoundError):
            self.accounts.get_account_by_id("bad-hash")

    def test_find_account_found(self):
        numbers_resp = make_mock_response(200, [
            {"accountNumber": "12345678", "hashValue": "hash1"},
            {"accountNumber": "99991234", "hashValue": "hash2"},
        ])
        account_resp = make_mock_response(200, {"accountNumber": "99991234"})
        self.client._request.side_effect = [numbers_resp, account_resp]
        result = self.accounts.find_account("1234")
        assert result["accountNumber"] == "99991234"

    def test_find_account_not_found(self):
        numbers_resp = make_mock_response(200, [
            {"accountNumber": "12345678", "hashValue": "hash1"},
        ])
        self.client._request.return_value = numbers_resp
        result = self.accounts.find_account("9999")
        assert result is None

    def test_find_account_empty_list(self):
        numbers_resp = make_mock_response(200, [])
        self.client._request.return_value = numbers_resp
        result = self.accounts.find_account("1234")
        assert result is None

    def test_get_transactions(self):
        resp = make_mock_response(200, [{"type": "TRADE"}])
        self.client._request.return_value = resp
        result = self.accounts.get_transactions("hash1")
        assert isinstance(result, list)

    def test_get_transactions_with_filters(self):
        resp = make_mock_response(200, [])
        self.client._request.return_value = resp
        self.accounts.get_transactions(
            "hash1",
            from_date="2024-01-01",
            to_date="2024-01-31",
            transaction_types=["TRADE"],
            symbol="AAPL",
        )
        self.client._request.assert_called_once()

    def test_get_transaction(self):
        resp = make_mock_response(200, {"transactionId": "t1"})
        self.client._request.return_value = resp
        result = self.accounts.get_transaction("hash1", "t1")
        assert result["transactionId"] == "t1"

    def test_get_user_preferences(self):
        resp = make_mock_response(200, {"schwabClientCustomerId": "cust1"})
        self.client._request.return_value = resp
        result = self.accounts.get_user_preferences()
        assert result["schwabClientCustomerId"] == "cust1"


# ===== Async Accounts =====

class TestAsyncAccounts:
    def setup_method(self):
        self.client = MagicMock()
        self.client.trader_base_url = "https://api.schwabapi.com/trader/v1"
        self.client._request = AsyncMock()
        self.accounts = AsyncAccounts(self.client)

    @pytest.mark.asyncio
    async def test_get_account_numbers(self):
        resp = make_mock_response(200, [{"accountNumber": "1234"}])
        self.client._request.return_value = resp
        result = await self.accounts.get_account_numbers()
        assert isinstance(result, list)

    @pytest.mark.asyncio
    async def test_get_accounts(self):
        resp = make_mock_response(200, [])
        self.client._request.return_value = resp
        result = await self.accounts.get_accounts()
        assert isinstance(result, list)

    @pytest.mark.asyncio
    async def test_get_account_by_id(self):
        resp = make_mock_response(200, {"accountNumber": "1234"})
        self.client._request.return_value = resp
        result = await self.accounts.get_account_by_id("hash1")
        assert result["accountNumber"] == "1234"

    @pytest.mark.asyncio
    async def test_find_account_found(self):
        numbers_resp = make_mock_response(200, [
            {"accountNumber": "99991234", "hashValue": "hash1"},
        ])
        account_resp = make_mock_response(200, {"accountNumber": "99991234"})
        self.client._request.side_effect = [numbers_resp, account_resp]
        result = await self.accounts.find_account("1234")
        assert result is not None

    @pytest.mark.asyncio
    async def test_find_account_not_found(self):
        numbers_resp = make_mock_response(200, [])
        self.client._request.return_value = numbers_resp
        result = await self.accounts.find_account("9999")
        assert result is None

    @pytest.mark.asyncio
    async def test_get_transactions(self):
        resp = make_mock_response(200, [])
        self.client._request.return_value = resp
        result = await self.accounts.get_transactions("hash1")
        assert isinstance(result, list)

    @pytest.mark.asyncio
    async def test_get_transaction(self):
        resp = make_mock_response(200, {"transactionId": "t1"})
        self.client._request.return_value = resp
        result = await self.accounts.get_transaction("hash1", "t1")
        assert result["transactionId"] == "t1"

    @pytest.mark.asyncio
    async def test_get_user_preferences(self):
        resp = make_mock_response(200, {"data": "prefs"})
        self.client._request.return_value = resp
        result = await self.accounts.get_user_preferences()
        assert result["data"] == "prefs"

    @pytest.mark.asyncio
    async def test_error_propagates(self):
        resp = make_mock_response(401, {"message": "unauthorized"})
        self.client._request.return_value = resp
        from schwab_sdk.exceptions import SchwabAuthenticationError
        with pytest.raises(SchwabAuthenticationError):
            await self.accounts.get_accounts()
