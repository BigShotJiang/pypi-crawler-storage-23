"""Tests for schwab_sdk._utils module."""

import re
from datetime import date, datetime
from enum import IntEnum

import pytest

from schwab_sdk._utils import coerce_enum, normalize_date, normalize_date_range, to_epoch_millis
from schwab_sdk.enums import (
    ContractType, MoverFrequency, PeriodType, FrequencyType,
    MoverSort, AccountField, Strategy,
)


# ===== coerce_enum =====

class TestCoerceEnum:
    def test_str_exact_value(self):
        assert coerce_enum("CALL", ContractType, "ct") == "CALL"

    def test_str_case_insensitive(self):
        assert coerce_enum("call", ContractType, "ct") == "CALL"
        assert coerce_enum("Call", ContractType, "ct") == "CALL"

    def test_enum_member(self):
        assert coerce_enum(ContractType.PUT, ContractType, "ct") == "PUT"

    def test_str_by_member_name(self):
        # ExpirationMonth.JAN has value "JAN" and name "JAN" — both match
        from schwab_sdk.enums import ExpirationMonth
        assert coerce_enum("JAN", ExpirationMonth, "m") == "JAN"

    def test_str_invalid_raises_valueerror(self):
        with pytest.raises(ValueError, match="Invalid ct"):
            coerce_enum("INVALID", ContractType, "ct")

    def test_int_enum_valid(self):
        assert coerce_enum(5, MoverFrequency, "freq") == "5"

    def test_int_enum_member(self):
        assert coerce_enum(MoverFrequency.SIXTY, MoverFrequency, "freq") == "60"

    def test_int_enum_string_coercion(self):
        assert coerce_enum("10", MoverFrequency, "freq") == "10"

    def test_int_enum_invalid_raises(self):
        with pytest.raises(ValueError, match="Invalid freq"):
            coerce_enum(99, MoverFrequency, "freq")

    def test_period_type_lowercase(self):
        assert coerce_enum("day", PeriodType, "pt") == "day"
        assert coerce_enum("DAY", PeriodType, "pt") == "day"

    def test_whitespace_stripped(self):
        assert coerce_enum("  CALL  ", ContractType, "ct") == "CALL"

    def test_strategy_values(self):
        assert coerce_enum("VERTICAL", Strategy, "s") == "VERTICAL"
        assert coerce_enum("single", Strategy, "s") == "SINGLE"

    def test_account_field_positions(self):
        assert coerce_enum("positions", AccountField, "f") == "positions"


# ===== normalize_date =====

class TestNormalizeDate:
    def test_none_returns_none(self):
        assert normalize_date(None) is None

    def test_empty_returns_none(self):
        assert normalize_date("") is None

    def test_iso_mode_bare_date_start(self):
        assert normalize_date("2024-01-15") == "2024-01-15T00:00:00.000Z"

    def test_iso_mode_bare_date_end(self):
        assert normalize_date("2024-01-15", is_end=True) == "2024-01-15T23:59:59.000Z"

    def test_iso_mode_already_iso(self):
        iso = "2024-01-15T12:30:00.000Z"
        assert normalize_date(iso) == iso

    def test_date_only_mode_bare(self):
        assert normalize_date("2024-01-15", mode="date_only") == "2024-01-15"

    def test_date_only_mode_strips_timestamp(self):
        assert normalize_date("2024-01-15T12:30:00.000Z", mode="date_only") == "2024-01-15"

    def test_whitespace_stripped(self):
        assert normalize_date("  2024-01-15  ") == "2024-01-15T00:00:00.000Z"


# ===== normalize_date_range =====

class TestNormalizeDateRange:
    def test_both_none_no_default(self):
        assert normalize_date_range(None, None) == (None, None)

    def test_both_none_with_default_days(self):
        start, end = normalize_date_range(None, None, default_days=60)
        assert start is not None and end is not None
        assert "T" in start and "T" in end

    def test_only_from_date(self):
        start, end = normalize_date_range("2024-01-15", None)
        assert start == "2024-01-15T00:00:00.000Z"
        assert end == "2024-01-15T23:59:59.000Z"

    def test_only_to_date(self):
        start, end = normalize_date_range(None, "2024-03-20")
        assert start == "2024-03-20T00:00:00.000Z"
        assert end == "2024-03-20T23:59:59.000Z"

    def test_both_provided(self):
        start, end = normalize_date_range("2024-01-01", "2024-12-31")
        assert start == "2024-01-01T00:00:00.000Z"
        assert end == "2024-12-31T23:59:59.000Z"

    def test_already_iso_passthrough(self):
        s = "2024-01-01T08:00:00.000Z"
        e = "2024-01-31T17:00:00.000Z"
        start, end = normalize_date_range(s, e)
        assert start == s
        assert end == e


# ===== to_epoch_millis =====

class TestToEpochMillis:
    def test_int_passthrough(self):
        assert to_epoch_millis(1700000000000) == 1700000000000

    def test_float_truncated(self):
        assert to_epoch_millis(1700000000000.5) == 1700000000000

    def test_datetime(self):
        dt = datetime(2024, 1, 15, 12, 0, 0)
        result = to_epoch_millis(dt)
        assert isinstance(result, int)
        assert result > 0

    def test_date(self):
        d = date(2024, 1, 15)
        result = to_epoch_millis(d)
        assert isinstance(result, int)
        assert result > 0

    def test_string_date(self):
        result = to_epoch_millis("2024-01-15")
        assert isinstance(result, int)
        assert result > 0

    def test_string_iso(self):
        result = to_epoch_millis("2024-01-15T12:00:00+00:00")
        assert isinstance(result, int)

    def test_invalid_raises(self):
        with pytest.raises(ValueError, match="Cannot convert"):
            to_epoch_millis([1, 2, 3])

    def test_invalid_string_raises(self):
        with pytest.raises(ValueError, match="Cannot convert"):
            to_epoch_millis("not-a-date")
