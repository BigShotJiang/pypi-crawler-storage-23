"""Tests for schwab_sdk.authentication module."""

import base64
from unittest.mock import MagicMock, AsyncMock, patch

import httpx
import pytest

from schwab_sdk.authentication import Authentication
from schwab_sdk.exceptions import SchwabAuthenticationError, SchwabAPIError
from tests.conftest import make_mock_response


def _make_auth(mock_token_handler=None, valid_token=False):
    th = mock_token_handler or MagicMock()
    if mock_token_handler is None:
        th.has_valid_token.return_value = valid_token
        th.save_tokens = MagicMock()
        th.async_save_tokens = AsyncMock()
    return Authentication("test-client-id", "test-secret", "https://localhost:8080/callback", th)


# ===== _build_auth_url =====

class TestBuildAuthUrl:
    def test_contains_required_params(self):
        auth = _make_auth()
        url = auth._build_auth_url()
        assert "client_id=test-client-id" in url
        assert "redirect_uri=" in url
        assert "response_type=code" in url
        assert "scope=api" in url
        assert url.startswith("https://api.schwabapi.com/v1/oauth/authorize?")

    def test_get_auth_url_delegates(self):
        auth = _make_auth()
        assert auth.get_auth_url() == auth._build_auth_url()


# ===== login =====

class TestLogin:
    def test_already_authenticated(self):
        auth = _make_auth(valid_token=True)
        assert auth.login() is True

    @patch("schwab_sdk.authentication.webbrowser.open")
    def test_happy_path(self, mock_browser):
        th = MagicMock()
        th.has_valid_token.return_value = False
        th.save_tokens = MagicMock()
        auth = _make_auth(th)

        mock_server = MagicMock()
        mock_server.wait.return_value = {
            "params": {"code": "auth-code-123"},
            "method": "GET",
        }

        with patch.object(auth, "_start_callback_server", return_value=True):
            auth.callback_server = mock_server
            with patch.object(auth, "_exchange_code_for_tokens", return_value=True):
                with patch.object(auth, "_stop_callback_server"):
                    result = auth.login()
        assert result is True

    @patch("schwab_sdk.authentication.webbrowser.open")
    def test_timeout_returns_false(self, mock_browser):
        th = MagicMock()
        th.has_valid_token.return_value = False
        auth = _make_auth(th)

        mock_server = MagicMock()
        mock_server.wait.return_value = None

        with patch.object(auth, "_start_callback_server", return_value=True):
            auth.callback_server = mock_server
            with patch.object(auth, "_stop_callback_server"):
                result = auth.login()
        assert result is False

    @patch("schwab_sdk.authentication.webbrowser.open")
    def test_callback_error(self, mock_browser):
        th = MagicMock()
        th.has_valid_token.return_value = False
        auth = _make_auth(th)

        mock_server = MagicMock()
        mock_server.wait.return_value = {
            "params": {"error": "access_denied", "error_description": "user denied"},
        }

        with patch.object(auth, "_start_callback_server", return_value=True):
            auth.callback_server = mock_server
            with patch.object(auth, "_stop_callback_server"):
                result = auth.login()
        assert result is False

    @patch("schwab_sdk.authentication.webbrowser.open")
    def test_no_code_in_callback(self, mock_browser):
        th = MagicMock()
        th.has_valid_token.return_value = False
        auth = _make_auth(th)

        mock_server = MagicMock()
        mock_server.wait.return_value = {"params": {}}

        with patch.object(auth, "_start_callback_server", return_value=True):
            auth.callback_server = mock_server
            with patch.object(auth, "_stop_callback_server"):
                result = auth.login()
        assert result is False

    def test_callback_server_start_fails(self):
        th = MagicMock()
        th.has_valid_token.return_value = False
        auth = _make_auth(th)
        with patch.object(auth, "_start_callback_server", return_value=False):
            result = auth.login()
        assert result is False

    @patch("schwab_sdk.authentication.webbrowser.open")
    def test_schwab_api_error_during_login(self, mock_browser):
        th = MagicMock()
        th.has_valid_token.return_value = False
        auth = _make_auth(th)

        mock_server = MagicMock()
        mock_server.wait.return_value = {"params": {"code": "code123"}}

        with patch.object(auth, "_start_callback_server", return_value=True):
            auth.callback_server = mock_server
            with patch.object(auth, "_exchange_code_for_tokens", side_effect=SchwabAPIError("err", status_code=500)):
                with patch.object(auth, "_stop_callback_server"):
                    result = auth.login()
        assert result is False

    @patch("schwab_sdk.authentication.webbrowser.open")
    def test_generic_exception_during_login(self, mock_browser):
        th = MagicMock()
        th.has_valid_token.return_value = False
        auth = _make_auth(th)

        mock_server = MagicMock()
        mock_server.wait.return_value = {"params": {"code": "code123"}}

        with patch.object(auth, "_start_callback_server", return_value=True):
            auth.callback_server = mock_server
            with patch.object(auth, "_exchange_code_for_tokens", side_effect=RuntimeError("boom")):
                with patch.object(auth, "_stop_callback_server"):
                    result = auth.login()
        assert result is False

    @patch("schwab_sdk.authentication.webbrowser.open")
    def test_browser_not_opened_when_disabled(self, mock_browser):
        th = MagicMock()
        th.has_valid_token.return_value = False
        auth = _make_auth(th)

        mock_server = MagicMock()
        mock_server.wait.return_value = None

        with patch.object(auth, "_start_callback_server", return_value=True):
            auth.callback_server = mock_server
            with patch.object(auth, "_stop_callback_server"):
                auth.login(auto_open_browser=False)
        mock_browser.assert_not_called()


# ===== _exchange_code_for_tokens =====

class TestExchangeCodeForTokens:
    @patch("schwab_sdk.authentication.httpx.post")
    def test_happy_path(self, mock_post):
        th = MagicMock()
        auth = _make_auth(th)
        resp = make_mock_response(200, {
            "access_token": "at-123",
            "refresh_token": "rt-456",
            "expires_in": 1800,
        })
        mock_post.return_value = resp
        result = auth._exchange_code_for_tokens("code-abc")
        assert result is True
        th.save_tokens.assert_called_once_with("at-123", "rt-456", 1800)

    @patch("schwab_sdk.authentication.httpx.post")
    def test_basic_auth_header(self, mock_post):
        th = MagicMock()
        auth = _make_auth(th)
        resp = make_mock_response(200, {
            "access_token": "at", "refresh_token": "rt", "expires_in": 1800,
        })
        mock_post.return_value = resp
        auth._exchange_code_for_tokens("code")
        call_headers = mock_post.call_args.kwargs.get("headers") or mock_post.call_args[1].get("headers")
        expected = base64.b64encode(b"test-client-id:test-secret").decode()
        assert call_headers["Authorization"] == f"Basic {expected}"

    @patch("schwab_sdk.authentication.httpx.post")
    def test_missing_access_token_raises(self, mock_post):
        auth = _make_auth()
        resp = make_mock_response(200, {"refresh_token": "rt"})
        mock_post.return_value = resp
        with pytest.raises(SchwabAuthenticationError, match="missing access_token"):
            auth._exchange_code_for_tokens("code")

    @patch("schwab_sdk.authentication.httpx.post")
    def test_401_raises(self, mock_post):
        auth = _make_auth()
        resp = make_mock_response(401, {"message": "unauthorized"})
        mock_post.return_value = resp
        with pytest.raises(SchwabAuthenticationError):
            auth._exchange_code_for_tokens("code")

    @patch("schwab_sdk.authentication.httpx.post")
    def test_network_error_raises_auth_error(self, mock_post):
        auth = _make_auth()
        mock_post.side_effect = httpx.ConnectError("refused")
        with pytest.raises(SchwabAuthenticationError, match="Network error"):
            auth._exchange_code_for_tokens("code")


# ===== async_exchange_code =====

class TestAsyncExchangeCode:
    @pytest.mark.asyncio
    async def test_happy_path(self):
        th = MagicMock()
        th.async_save_tokens = AsyncMock()
        auth = _make_auth(th)
        resp = make_mock_response(200, {
            "access_token": "at-async",
            "refresh_token": "rt-async",
            "expires_in": 1800,
        })

        mock_http = AsyncMock()
        mock_http.post.return_value = resp
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=None)

        with patch("schwab_sdk.authentication.httpx.AsyncClient", return_value=mock_http):
            result = await auth.async_exchange_code("code-abc")
        assert result is True
        th.async_save_tokens.assert_called_once()

    @pytest.mark.asyncio
    async def test_missing_token_raises(self):
        auth = _make_auth()
        resp = make_mock_response(200, {"access_token": "at"})

        mock_http = AsyncMock()
        mock_http.post.return_value = resp
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=None)

        with patch("schwab_sdk.authentication.httpx.AsyncClient", return_value=mock_http):
            with pytest.raises(SchwabAuthenticationError, match="missing"):
                await auth.async_exchange_code("code")

    @pytest.mark.asyncio
    async def test_network_error(self):
        auth = _make_auth()

        mock_http = AsyncMock()
        mock_http.post.side_effect = httpx.ConnectError("refused")
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=None)

        with patch("schwab_sdk.authentication.httpx.AsyncClient", return_value=mock_http):
            with pytest.raises(SchwabAuthenticationError, match="Network error"):
                await auth.async_exchange_code("code")


# ===== Other methods =====

class TestAuthenticationMisc:
    def test_exchange_code_delegates(self):
        auth = _make_auth()
        with patch.object(auth, "_exchange_code_for_tokens", return_value=True) as mock_exc:
            result = auth.exchange_code("my-code")
        assert result is True
        mock_exc.assert_called_once_with("my-code")

    def test_is_authenticated(self):
        th = MagicMock()
        th.has_valid_token.return_value = True
        auth = Authentication("test-client-id", "test-secret", "https://localhost:8080/callback", th)
        assert auth.is_authenticated() is True

    def test_get_access_token(self):
        th = MagicMock()
        th.get_access_token.return_value = "token-123"
        auth = _make_auth(th)
        assert auth.get_access_token() == "token-123"

    def test_logout(self):
        th = MagicMock()
        auth = _make_auth(th)
        auth.logout()
        th._clear_tokens.assert_called_once()

    def test_stop_callback_server_when_none(self):
        auth = _make_auth()
        auth.callback_server = None
        auth._stop_callback_server()  # Should not raise
