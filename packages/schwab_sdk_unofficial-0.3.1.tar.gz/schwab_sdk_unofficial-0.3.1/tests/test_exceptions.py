"""Tests for schwab_sdk.exceptions module."""

import json
from unittest.mock import MagicMock

import pytest

from schwab_sdk.exceptions import (
    SchwabAPIError,
    SchwabValidationError,
    SchwabAuthenticationError,
    SchwabForbiddenError,
    SchwabNotFoundError,
    SchwabRateLimitError,
    SchwabServerError,
    SchwabTokenExpiredError,
    SchwabParameterError,
    raise_for_schwab_status,
    _extract_error_details,
    _format_source,
)


# ===== Hierarchy =====

class TestExceptionHierarchy:
    def test_api_error_is_exception(self):
        assert issubclass(SchwabAPIError, Exception)

    def test_validation_is_api_error(self):
        assert issubclass(SchwabValidationError, SchwabAPIError)

    def test_authentication_is_api_error(self):
        assert issubclass(SchwabAuthenticationError, SchwabAPIError)

    def test_forbidden_is_api_error(self):
        assert issubclass(SchwabForbiddenError, SchwabAPIError)

    def test_not_found_is_api_error(self):
        assert issubclass(SchwabNotFoundError, SchwabAPIError)

    def test_rate_limit_is_api_error(self):
        assert issubclass(SchwabRateLimitError, SchwabAPIError)

    def test_server_is_api_error(self):
        assert issubclass(SchwabServerError, SchwabAPIError)

    def test_token_expired_is_authentication(self):
        assert issubclass(SchwabTokenExpiredError, SchwabAuthenticationError)

    def test_parameter_error_is_value_error(self):
        assert issubclass(SchwabParameterError, ValueError)

    def test_parameter_error_not_api_error(self):
        assert not issubclass(SchwabParameterError, SchwabAPIError)


# ===== SchwabAPIError attributes =====

class TestSchwabAPIErrorAttributes:
    def test_basic_construction(self):
        exc = SchwabAPIError("test message", status_code=400)
        assert exc.status_code == 400
        assert exc.message == "test message"
        assert exc.correl_id is None
        assert exc.errors == []
        assert exc.response is None

    def test_full_construction(self):
        resp = MagicMock()
        exc = SchwabAPIError(
            "err",
            status_code=500,
            correl_id="abc-123",
            errors=[{"detail": "oops"}],
            response=resp,
        )
        assert exc.correl_id == "abc-123"
        assert exc.errors == [{"detail": "oops"}]
        assert exc.response is resp

    def test_str_format(self):
        exc = SchwabAPIError("bad request", status_code=400)
        assert str(exc) == "[400] bad request"

    def test_default_status_code(self):
        exc = SchwabAPIError("no status")
        assert exc.status_code == 0


# ===== _extract_error_details =====

class TestExtractErrorDetails:
    def _make_response(self, json_body=None, text="", headers=None):
        resp = MagicMock()
        resp.headers = headers or {}
        resp.text = text
        resp.reason_phrase = "Error"
        if json_body is not None:
            resp.json.return_value = json_body
        else:
            resp.json.side_effect = Exception("no json")
        return resp

    def test_schwab_errors_format(self):
        body = {"errors": [{"detail": "Missing header", "source": {"header": "Authorization"}}]}
        resp = self._make_response(json_body=body, headers={"Schwab-Client-CorrelId": "corr-1"})
        details = _extract_error_details(resp)
        assert "Missing header" in details["message"]
        assert "header: Authorization" in details["message"]
        assert details["correl_id"] == "corr-1"
        assert len(details["errors"]) == 1

    def test_fallback_message_key(self):
        resp = self._make_response(json_body={"message": "Something went wrong"})
        details = _extract_error_details(resp)
        assert details["message"] == "Something went wrong"

    def test_fallback_error_key(self):
        resp = self._make_response(json_body={"error": "invalid_grant"})
        details = _extract_error_details(resp)
        assert details["message"] == "invalid_grant"

    def test_non_json_fallback(self):
        resp = self._make_response(text="Server error")
        details = _extract_error_details(resp)
        assert details["message"] == "Server error"

    def test_lowercase_correl_id_header(self):
        resp = self._make_response(
            json_body={"message": "err"},
            headers={"schwab-client-correlid": "lower-corr"},
        )
        details = _extract_error_details(resp)
        assert details["correl_id"] == "lower-corr"

    def test_multiple_errors_joined(self):
        body = {"errors": [{"detail": "Error 1"}, {"detail": "Error 2"}]}
        resp = self._make_response(json_body=body)
        details = _extract_error_details(resp)
        assert "Error 1" in details["message"]
        assert "Error 2" in details["message"]
        assert ";" in details["message"]

    def test_error_without_detail(self):
        body = {"errors": [{"title": "Bad Request"}]}
        resp = self._make_response(json_body=body)
        details = _extract_error_details(resp)
        assert "Bad Request" in details["message"]

    def test_source_with_parameter(self):
        body = {"errors": [{"detail": "Invalid", "source": {"parameter": "symbol"}}]}
        resp = self._make_response(json_body=body)
        details = _extract_error_details(resp)
        assert "param: symbol" in details["message"]

    def test_source_with_pointer_list(self):
        body = {"errors": [{"detail": "Invalid", "source": {"pointer": ["/a", "/b"]}}]}
        resp = self._make_response(json_body=body)
        details = _extract_error_details(resp)
        assert "fields:" in details["message"]

    def test_source_with_pointer_string(self):
        body = {"errors": [{"detail": "Invalid", "source": {"pointer": "/data/id"}}]}
        resp = self._make_response(json_body=body)
        details = _extract_error_details(resp)
        assert "field: /data/id" in details["message"]


# ===== _format_source =====

class TestFormatSource:
    def test_empty_source(self):
        assert _format_source({}) == ""

    def test_header_source(self):
        assert _format_source({"header": "Auth"}) == "header: Auth"

    def test_multiple_fields(self):
        result = _format_source({"header": "H", "parameter": "P"})
        assert "header: H" in result
        assert "param: P" in result


# ===== raise_for_schwab_status =====

class TestRaiseForSchwabStatus:
    def _make_resp(self, code, json_body=None, headers=None):
        resp = MagicMock()
        resp.status_code = code
        resp.headers = headers or {}
        resp.text = json.dumps(json_body) if json_body else ""
        resp.reason_phrase = "Error"
        resp.content = resp.text.encode() if resp.text else b""
        if json_body is not None:
            resp.json.return_value = json_body
        else:
            resp.json.side_effect = Exception("no json")
        return resp

    def test_2xx_does_not_raise(self):
        for code in (200, 201, 204, 299):
            raise_for_schwab_status(self._make_resp(code))

    def test_400_raises_validation(self):
        with pytest.raises(SchwabValidationError) as exc_info:
            raise_for_schwab_status(self._make_resp(400, {"message": "bad"}))
        assert exc_info.value.status_code == 400

    def test_401_raises_authentication(self):
        with pytest.raises(SchwabAuthenticationError):
            raise_for_schwab_status(self._make_resp(401, {"message": "unauthorized"}))

    def test_403_raises_forbidden(self):
        with pytest.raises(SchwabForbiddenError):
            raise_for_schwab_status(self._make_resp(403, {"message": "forbidden"}))

    def test_404_raises_not_found(self):
        with pytest.raises(SchwabNotFoundError):
            raise_for_schwab_status(self._make_resp(404, {"message": "not found"}))

    def test_429_raises_rate_limit(self):
        with pytest.raises(SchwabRateLimitError):
            raise_for_schwab_status(self._make_resp(429, {"message": "rate limited"}))

    def test_500_raises_server(self):
        with pytest.raises(SchwabServerError):
            raise_for_schwab_status(self._make_resp(500, {"message": "internal"}))

    def test_502_raises_server(self):
        with pytest.raises(SchwabServerError):
            raise_for_schwab_status(self._make_resp(502))

    def test_503_raises_server(self):
        with pytest.raises(SchwabServerError):
            raise_for_schwab_status(self._make_resp(503))

    def test_504_raises_server(self):
        with pytest.raises(SchwabServerError):
            raise_for_schwab_status(self._make_resp(504))

    def test_unknown_code_raises_api_error(self):
        with pytest.raises(SchwabAPIError):
            raise_for_schwab_status(self._make_resp(418, {"message": "teapot"}))
