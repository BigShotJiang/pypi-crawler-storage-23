"""Tests for schwab_sdk.enums module."""

import pytest

from schwab_sdk.enums import (
    ContractType, Strategy, PeriodType, FrequencyType, QuoteField,
    MoverFrequency, MoverSort, MoverIndex, MarketID, Projection,
    OrderType, Duration, Session, EquityInstruction, AssetType,
    StreamService, StreamCommand, StreamResponseCode,
    DividendFrequency, AccountField, TransactionType,
    StrikeRange, ExpirationMonth, OptionType, Entitlement,
)


class TestStrEnumBehavior:
    def test_str_instance(self):
        assert isinstance(ContractType.CALL, str)
        assert isinstance(PeriodType.DAY, str)

    def test_usable_in_fstrings(self):
        assert f"type={ContractType.CALL}" == "type=CALL"

    def test_equality_with_str(self):
        assert ContractType.CALL == "CALL"
        assert PeriodType.DAY == "day"

    def test_str_value(self):
        assert str(ContractType.CALL.value) == "CALL"


class TestIntEnumBehavior:
    def test_int_instance(self):
        assert isinstance(MoverFrequency.ZERO, int)
        assert isinstance(DividendFrequency.QUARTERLY, int)

    def test_mover_frequency_values(self):
        assert MoverFrequency.ZERO == 0
        assert MoverFrequency.ONE == 1
        assert MoverFrequency.FIVE == 5
        assert MoverFrequency.TEN == 10
        assert MoverFrequency.THIRTY == 30
        assert MoverFrequency.SIXTY == 60

    def test_dividend_frequency_values(self):
        assert DividendFrequency.NONE == 0
        assert DividendFrequency.ANNUAL == 1
        assert DividendFrequency.QUARTERLY == 4
        assert DividendFrequency.MONTHLY == 12

    def test_stream_response_codes(self):
        assert StreamResponseCode.SUCCESS == 0
        assert StreamResponseCode.LOGIN_DENIED == 3
        assert StreamResponseCode.STOP_STREAMING == 30


class TestSpecificValues:
    def test_contract_type(self):
        assert ContractType.CALL.value == "CALL"
        assert ContractType.PUT.value == "PUT"
        assert ContractType.ALL.value == "ALL"

    def test_period_type(self):
        assert PeriodType.DAY.value == "day"
        assert PeriodType.MONTH.value == "month"
        assert PeriodType.YEAR.value == "year"
        assert PeriodType.YTD.value == "ytd"

    def test_frequency_type(self):
        assert FrequencyType.MINUTE.value == "minute"
        assert FrequencyType.DAILY.value == "daily"

    def test_order_type(self):
        assert OrderType.MARKET.value == "MARKET"
        assert OrderType.LIMIT.value == "LIMIT"
        assert OrderType.STOP.value == "STOP"
        assert OrderType.STOP_LIMIT.value == "STOP_LIMIT"

    def test_mover_index(self):
        assert MoverIndex.DJI.value == "$DJI"
        assert MoverIndex.SPX.value == "$SPX"

    def test_market_id(self):
        assert MarketID.EQUITY.value == "equity"
        assert MarketID.OPTION.value == "option"

    def test_projection(self):
        assert Projection.SYMBOL_SEARCH.value == "symbol-search"
        assert Projection.FUNDAMENTAL.value == "fundamental"

    def test_stream_service(self):
        assert StreamService.LEVELONE_EQUITIES.value == "LEVELONE_EQUITIES"
        assert StreamService.ACCT_ACTIVITY.value == "ACCT_ACTIVITY"

    def test_stream_command(self):
        assert StreamCommand.LOGIN.value == "LOGIN"
        assert StreamCommand.SUBS.value == "SUBS"

    def test_equity_instruction(self):
        assert EquityInstruction.BUY.value == "BUY"
        assert EquityInstruction.SELL.value == "SELL"
        assert EquityInstruction.SELL_SHORT.value == "SELL_SHORT"
        assert EquityInstruction.BUY_TO_COVER.value == "BUY_TO_COVER"

    def test_account_field(self):
        assert AccountField.POSITIONS.value == "positions"

    def test_strike_range(self):
        assert StrikeRange.IN_THE_MONEY.value == "ITM"
        assert StrikeRange.ALL.value == "ALL"
