"""Tests for schwab_sdk.callback module."""

import json
import os
import threading
import time
from unittest.mock import MagicMock, patch

import pytest
from starlette.testclient import TestClient

from schwab_sdk.callback import (
    CallbackServer,
    _HTML_OK_FALLBACK,
    _HTML_ERROR_FALLBACK,
    _HTML_FRAGMENT_BRIDGE,
    run_callback_server,
    _cli,
)


# ===== __init__ validation =====

class TestCallbackServerInit:
    def test_https_without_ssl_raises(self):
        with pytest.raises(RuntimeError, match="HTTPS is required"):
            CallbackServer(force_https=True, adhoc_ssl=False)

    def test_path_normalization(self):
        srv = CallbackServer(path="callback", force_https=False)
        assert srv.path == "/callback"

    def test_path_normalization_slashes(self):
        srv = CallbackServer(path="/callback/", force_https=False)
        assert srv.path == "/callback"

    def test_empty_path(self):
        srv = CallbackServer(path="", force_https=False)
        assert srv.path == "/callback"

    def test_valid_http_config(self):
        srv = CallbackServer(force_https=False)
        assert srv.host == "127.0.0.1"
        assert srv.port == 8080
        assert srv.force_https is False

    def test_valid_adhoc_ssl(self):
        srv = CallbackServer(adhoc_ssl=True, force_https=True)
        assert srv.adhoc_ssl is True

    def test_valid_cert_ssl(self):
        srv = CallbackServer(ssl_cert="/tmp/cert.pem", ssl_key="/tmp/key.pem", force_https=True)
        assert srv.ssl_cert == "/tmp/cert.pem"


# ===== _handle_callback via Starlette test client =====

class TestHandleCallback:
    def setup_method(self):
        self.srv = CallbackServer(force_https=False)
        self.test_client = TestClient(self.srv._app)

    def test_get_with_code(self):
        resp = self.test_client.get("/callback?code=abc123")
        assert resp.status_code == 200
        assert self.srv._result is not None
        assert self.srv._result["params"]["code"] == "abc123"
        assert self.srv._event.is_set()

    def test_get_with_error(self):
        resp = self.test_client.get("/callback?error=access_denied&error_description=denied")
        assert resp.status_code == 200
        assert self.srv._result is not None
        assert self.srv._result["params"]["error"] == "access_denied"

    def test_get_no_params_shows_bridge(self):
        resp = self.test_client.get("/callback")
        assert resp.status_code == 200
        assert "Processing data" in resp.text
        assert not self.srv._event.is_set()

    def test_post_with_json_fragment(self):
        resp = self.test_client.post(
            "/callback",
            json={"fragment_params": {"access_token": "tok123"}},
        )
        assert resp.status_code == 200
        assert self.srv._result is not None
        assert self.srv._result["params"]["access_token"] == "tok123"

    def test_json_response_mode(self):
        resp = self.test_client.get(
            "/callback?code=abc",
            headers={"Accept": "application/json"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["ok"] is True

    def test_idempotent_second_request(self):
        self.test_client.get("/callback?code=abc123")
        assert self.srv._event.is_set()
        # Second request should be idempotent
        resp = self.test_client.get("/callback?code=xyz")
        assert resp.status_code == 200

    def test_post_form_data(self):
        resp = self.test_client.post(
            "/callback",
            data={"code": "form-code-123"},
        )
        assert resp.status_code == 200
        assert self.srv._result["params"]["code"] == "form-code-123"

    def test_error_html_shown(self):
        resp = self.test_client.get("/callback?error=server_error")
        assert resp.status_code == 200
        assert "could not be completed" in resp.text

    def test_pending_json_response(self):
        resp = self.test_client.get(
            "/callback",
            headers={"Accept": "application/json"},
        )
        data = resp.json()
        assert data["ok"] is False
        assert data["pending"] is True

    def test_format_json_query_param(self):
        resp = self.test_client.get("/callback?code=abc&format=json")
        data = resp.json()
        assert data["ok"] is True


# ===== _has_tokenish =====

class TestHasTokenish:
    def test_with_code(self):
        assert CallbackServer._has_tokenish({"code": "abc"}) is True

    def test_with_access_token(self):
        assert CallbackServer._has_tokenish({"access_token": "tok"}) is True

    def test_without_tokens(self):
        assert CallbackServer._has_tokenish({"other": "val"}) is False

    def test_empty_code(self):
        assert CallbackServer._has_tokenish({"code": ""}) is False

    def test_none_code(self):
        assert CallbackServer._has_tokenish({"code": None}) is False


# ===== wait =====

class TestWait:
    def test_event_set_returns_result(self):
        srv = CallbackServer(force_https=False)
        srv._result = {"params": {"code": "abc"}}
        srv._event.set()
        result = srv.wait(timeout=1.0)
        assert result is not None
        assert result["params"]["code"] == "abc"

    def test_timeout_returns_none(self):
        srv = CallbackServer(force_https=False)
        result = srv.wait(timeout=0.1)
        assert result is None


# ===== _load_optional_html =====

class TestLoadOptionalHtml:
    def test_none_path(self):
        srv = CallbackServer(force_https=False)
        assert srv._load_optional_html(None, kind="success") is None

    def test_valid_file(self, tmp_path):
        html_file = tmp_path / "success.html"
        html_file.write_text("<h1>Success</h1>")
        srv = CallbackServer(force_https=False)
        result = srv._load_optional_html(str(html_file), kind="success")
        assert result == "<h1>Success</h1>"

    def test_file_not_found(self):
        srv = CallbackServer(force_https=False)
        result = srv._load_optional_html("/nonexistent/file.html", kind="error")
        assert result is None

    def test_custom_success_html_used(self, tmp_path):
        html_file = tmp_path / "custom_success.html"
        html_file.write_text("<h1>Custom Success</h1>")
        srv = CallbackServer(
            force_https=False,
            success_html_path=str(html_file),
        )
        assert srv._success_html == "<h1>Custom Success</h1>"

    def test_custom_error_html_used(self, tmp_path):
        html_file = tmp_path / "custom_error.html"
        html_file.write_text("<h1>Custom Error</h1>")
        srv = CallbackServer(
            force_https=False,
            error_html_path=str(html_file),
        )
        assert srv._error_html == "<h1>Custom Error</h1>"


# ===== Health endpoint =====

class TestHealthEndpoint:
    def test_health(self):
        srv = CallbackServer(force_https=False)
        client = TestClient(srv._app)
        resp = client.get("/health")
        assert resp.status_code == 200


# ===== shutdown =====

class TestShutdown:
    def test_shutdown_no_server(self):
        srv = CallbackServer(force_https=False)
        srv.shutdown()  # Should not raise

    def test_shutdown_uvicorn(self):
        srv = CallbackServer(force_https=False)
        mock_server = MagicMock()
        mock_server.should_exit = False
        mock_thread = MagicMock()
        srv._uvicorn_server = mock_server
        srv._server_thread = mock_thread
        srv.shutdown()
        assert mock_server.should_exit is True
        mock_thread.join.assert_called_once_with(timeout=3.0)

    def test_shutdown_cleans_up_adhoc_files(self, tmp_path):
        srv = CallbackServer(force_https=False)
        cert = tmp_path / "cert.pem"
        key = tmp_path / "key.pem"
        cert.write_text("CERT")
        key.write_text("KEY")
        srv._adhoc_cert_file = str(cert)
        srv._adhoc_key_file = str(key)
        srv.shutdown()
        assert not cert.exists()
        assert not key.exists()
        assert srv._adhoc_cert_file is None
        assert srv._adhoc_key_file is None

    def test_shutdown_missing_adhoc_files_no_error(self):
        srv = CallbackServer(force_https=False)
        srv._adhoc_cert_file = "/nonexistent/cert.pem"
        srv._adhoc_key_file = "/nonexistent/key.pem"
        srv.shutdown()  # Should not raise
        assert srv._adhoc_cert_file is None


# ===== _generate_adhoc_cert =====

class TestGenerateAdhocCert:
    def test_generates_valid_pem_files(self):
        cert_path, key_path = CallbackServer._generate_adhoc_cert()
        try:
            assert os.path.isfile(cert_path)
            assert os.path.isfile(key_path)
            with open(cert_path) as f:
                assert "BEGIN CERTIFICATE" in f.read()
            with open(key_path) as f:
                assert "BEGIN RSA PRIVATE KEY" in f.read()
        finally:
            os.unlink(cert_path)
            os.unlink(key_path)


# ===== start() =====

class TestStart:
    def test_start_http(self):
        srv = CallbackServer(force_https=False)
        with patch("uvicorn.Server") as MockServer:
            mock_instance = MagicMock()
            MockServer.return_value = mock_instance
            srv.start()
            MockServer.assert_called_once()
            config = MockServer.call_args[0][0]
            assert config.ssl_certfile is None
            assert config.ssl_keyfile is None
            assert srv._uvicorn_server is mock_instance
            assert srv._server_thread is not None
            srv._server_thread.join(timeout=1.0)

    def test_start_https_adhoc(self):
        srv = CallbackServer(adhoc_ssl=True, force_https=True)
        with patch("uvicorn.Server") as MockServer, \
             patch.object(CallbackServer, "_generate_adhoc_cert", return_value=("/tmp/c.pem", "/tmp/k.pem")):
            mock_instance = MagicMock()
            MockServer.return_value = mock_instance
            srv.start()
            config = MockServer.call_args[0][0]
            assert config.ssl_certfile == "/tmp/c.pem"
            assert config.ssl_keyfile == "/tmp/k.pem"
            assert srv._adhoc_cert_file == "/tmp/c.pem"
            assert srv._adhoc_key_file == "/tmp/k.pem"
            srv._server_thread.join(timeout=1.0)

    def test_start_https_with_certs(self):
        srv = CallbackServer(ssl_cert="/my/cert.pem", ssl_key="/my/key.pem", force_https=True)
        with patch("uvicorn.Server") as MockServer:
            mock_instance = MagicMock()
            MockServer.return_value = mock_instance
            srv.start()
            config = MockServer.call_args[0][0]
            assert config.ssl_certfile == "/my/cert.pem"
            assert config.ssl_keyfile == "/my/key.pem"
            assert srv._adhoc_cert_file is None
            srv._server_thread.join(timeout=1.0)


# ===== handler edge cases =====

class TestHandleCallbackEdgeCases:
    def setup_method(self):
        self.srv = CallbackServer(force_https=False)
        self.test_client = TestClient(self.srv._app)

    def test_idempotent_json_response(self):
        self.test_client.get("/callback?code=abc123")
        resp = self.test_client.get(
            "/callback",
            headers={"Accept": "application/json"},
        )
        data = resp.json()
        assert data["ok"] is True
        assert "params" not in data  # idempotent returns just {"ok": true}

    def test_multi_value_query_params(self):
        resp = self.test_client.get("/callback?code=abc&tag=a&tag=b")
        assert resp.status_code == 200
        assert self.srv._result["params"]["tag"] == ["a", "b"]

    def test_post_json_invalid_body(self):
        resp = self.test_client.post(
            "/callback",
            content=b"not-json",
            headers={"Content-Type": "application/json"},
        )
        assert resp.status_code == 200
        # invalid JSON -> empty body -> no tokens -> bridge page
        assert "Processing data" in resp.text

    def test_post_json_non_dict_body(self):
        resp = self.test_client.post(
            "/callback",
            content=b'"just a string"',
            headers={"Content-Type": "application/json"},
        )
        assert resp.status_code == 200
        assert "Processing data" in resp.text

    def test_post_json_extra_keys(self):
        resp = self.test_client.post(
            "/callback",
            json={"fragment_params": {"code": "x"}, "extra": "val"},
        )
        assert resp.status_code == 200
        assert self.srv._result["params"]["code"] == "x"
        assert self.srv._result["params"]["extra"] == "val"

    def test_post_json_fragment_not_dict(self):
        resp = self.test_client.post(
            "/callback",
            json={"fragment_params": "not-a-dict", "code": "abc"},
        )
        assert resp.status_code == 200
        assert self.srv._result["params"]["code"] == "abc"


# ===== run_callback_server =====

class TestRunCallbackServer:
    def test_returns_result(self):
        with patch.object(CallbackServer, "start"), \
             patch.object(CallbackServer, "wait", return_value={"params": {"code": "x"}}), \
             patch.object(CallbackServer, "shutdown"):
            result = run_callback_server(force_https=False, timeout=1.0)
            assert result == {"params": {"code": "x"}}

    def test_returns_none_on_timeout(self):
        with patch.object(CallbackServer, "start"), \
             patch.object(CallbackServer, "wait", return_value=None), \
             patch.object(CallbackServer, "shutdown"):
            result = run_callback_server(force_https=False, timeout=0.1)
            assert result is None

    def test_shutdown_called_on_exception(self):
        with patch.object(CallbackServer, "start"), \
             patch.object(CallbackServer, "wait", side_effect=RuntimeError("boom")), \
             patch.object(CallbackServer, "shutdown") as mock_shutdown:
            with pytest.raises(RuntimeError, match="boom"):
                run_callback_server(force_https=False)
            mock_shutdown.assert_called_once()


# ===== CLI =====

class TestCli:
    def test_cli_adhoc_ssl(self, capsys):
        with patch("schwab_sdk.callback.run_callback_server", return_value={"params": {"code": "ok"}}) as mock_run:
            with patch("sys.argv", ["callback", "--adhoc-ssl"]):
                _cli()
            mock_run.assert_called_once()
            kwargs = mock_run.call_args[1]
            assert kwargs["adhoc_ssl"] is True
            assert kwargs["force_https"] is True
            out = capsys.readouterr().out
            assert '"code": "ok"' in out

    def test_cli_ssl_cert(self, capsys):
        with patch("schwab_sdk.callback.run_callback_server", return_value=None) as mock_run:
            with patch("sys.argv", ["callback", "--ssl-cert", "/c.pem", "--ssl-key", "/k.pem"]):
                _cli()
            kwargs = mock_run.call_args[1]
            assert kwargs["ssl_cert"] == "/c.pem"
            assert kwargs["ssl_key"] == "/k.pem"
            out = capsys.readouterr().out
            assert "Timeout" in out

    def test_cli_missing_ssl_key(self):
        with patch("sys.argv", ["callback", "--ssl-cert", "/c.pem"]):
            with pytest.raises(SystemExit):
                _cli()

    def test_cli_custom_params(self):
        with patch("schwab_sdk.callback.run_callback_server", return_value=None) as mock_run:
            with patch("sys.argv", [
                "callback", "--adhoc-ssl",
                "--host", "0.0.0.0", "--port", "9999",
                "--path", "oauth", "--timeout", "60",
                "--success-html", "/s.html", "--error-html", "/e.html",
            ]):
                _cli()
            kwargs = mock_run.call_args[1]
            assert kwargs["host"] == "0.0.0.0"
            assert kwargs["port"] == 9999
            assert kwargs["path"] == "/oauth"
            assert kwargs["timeout"] == 60.0
            assert kwargs["success_html_path"] == "/s.html"
            assert kwargs["error_html_path"] == "/e.html"
