"""
Schwab SDK - Orders Module
Handles all endpoints related to orders.
"""

import re
from typing import Optional, Dict, Any
import httpx

from .enums import (
    OrderStatus, OrderType, Duration, Session, EquityInstruction,
    AssetType, OrderStrategyType,
)
from ._utils import coerce_enum, normalize_date_range
from .exceptions import raise_for_schwab_status


class Orders:
    """
    Module for endpoints related to orders (sync).

    Includes functionality to:
    - Retrieve existing orders
    - Place new orders
    - Cancel orders
    - Replace orders
    - Order preview

    All methods that create/modify orders extract the order_id
    from the Location header and add it to the JSON response.
    """

    def __init__(self, client):
        """
        Initializes the Orders module.

        Args:
            client: Instance of the main client
        """
        self.client = client
        self.base_url = client.trader_base_url

    def get_orders(
        self,
        account_hash: str,
        from_entered_time: str = None,
        to_entered_time: str = None,
        status: Optional[str] = None,
        max_results: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Retrieves all orders for a specific account.

        GET /accounts/{accountNumber}/orders
        """
        start_norm, end_norm = normalize_date_range(from_entered_time, to_entered_time, default_days=60)

        endpoint = f"{self.base_url}/accounts/{account_hash}/orders"
        params = {
            'fromEnteredTime': start_norm,
            'toEnteredTime': end_norm,
        }
        if status:
            params['status'] = coerce_enum(status, OrderStatus, "status")
        if max_results is not None:
            params['maxResults'] = max_results
        try:
            response = self.client._request("GET", endpoint, params=params, timeout=30)
            return _build_order_result(response, method='GET', params=params)
        except httpx.RequestError as e:
            return _build_error_result(e, endpoint, method='GET', params=params)

    def place_order(self, account_hash: str, order_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Places a new order for a specific account.

        POST /accounts/{accountNumber}/orders
        """
        endpoint = f"{self.base_url}/accounts/{account_hash}/orders"
        headers = {"Content-Type": "application/json"}
        try:
            response = self.client._request("POST", endpoint, json=order_data, headers=headers, timeout=15)
            return _build_order_result(response, method='POST')
        except httpx.RequestError as e:
            return _build_error_result(e, endpoint, method='POST')

    def get_order(self, account_hash: str, order_id: str) -> Dict[str, Any]:
        """
        Retrieves a specific order by its ID.

        GET /accounts/{accountNumber}/orders/{orderId}
        """
        endpoint = f"{self.base_url}/accounts/{account_hash}/orders/{order_id}"
        try:
            response = self.client._request("GET", endpoint, timeout=10)
            return _build_order_result(response, method='GET', order_id=order_id)
        except httpx.RequestError as e:
            return _build_error_result(e, endpoint, method='GET', order_id=order_id)

    def cancel_order(self, account_hash: str, order_id: str) -> Dict[str, Any]:
        """
        Cancels a specific order.

        DELETE /accounts/{accountNumber}/orders/{orderId}
        """
        endpoint = f"{self.base_url}/accounts/{account_hash}/orders/{order_id}"
        try:
            response = self.client._request("DELETE", endpoint, timeout=10)
            return _build_order_result(response, method='DELETE', order_id=order_id)
        except httpx.RequestError as e:
            return _build_error_result(e, endpoint, method='DELETE', order_id=order_id)

    def replace_order(self, account_hash: str, order_id: str, new_order_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Replaces an existing order with new information.

        PUT /accounts/{accountNumber}/orders/{orderId}
        """
        endpoint = f"{self.base_url}/accounts/{account_hash}/orders/{order_id}"
        headers = {"Content-Type": "application/json"}
        try:
            response = self.client._request("PUT", endpoint, json=new_order_data, headers=headers, timeout=15)
            result = _build_order_result(response, method='PUT')
            result['original_order_id'] = order_id
            return result
        except httpx.RequestError as e:
            r = _build_error_result(e, endpoint, method='PUT')
            r['original_order_id'] = order_id
            return r

    def get_all_orders(
        self,
        from_entered_time: str = None,
        to_entered_time: str = None,
        status: Optional[str] = None,
        max_results: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Retrieves all orders for all accounts.

        GET /orders
        """
        start_norm, end_norm = normalize_date_range(from_entered_time, to_entered_time, default_days=60)

        endpoint = f"{self.base_url}/orders"
        params = {
            'fromEnteredTime': start_norm,
            'toEnteredTime': end_norm,
        }
        if status:
            params['status'] = coerce_enum(status, OrderStatus, "status")
        if max_results is not None:
            params['maxResults'] = max_results
        try:
            response = self.client._request("GET", endpoint, params=params, timeout=30)
            return _build_order_result(response, method='GET', params=params)
        except httpx.RequestError as e:
            return _build_error_result(e, endpoint, method='GET', params=params)

    def preview_order(self, account_hash: str, order_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Previews an order without placing it.

        POST /accounts/{accountNumber}/previewOrder
        """
        endpoint = f"{self.base_url}/accounts/{account_hash}/previewOrder"
        headers = {"Content-Type": "application/json"}
        try:
            response = self.client._request("POST", endpoint, json=order_data, headers=headers, timeout=15)
            return _build_order_result(response, method='POST')
        except httpx.RequestError as e:
            return _build_error_result(e, endpoint, method='POST')

    # ===== Helpers to build common orders =====
    @staticmethod
    def build_limit_order(symbol: str, quantity: int, price: float, instruction: str = "BUY") -> Dict[str, Any]:
        if quantity <= 0:
            raise ValueError(f"quantity must be > 0, got {quantity}")
        if price <= 0:
            raise ValueError(f"price must be > 0, got {price}")
        validated_instruction = coerce_enum(instruction, EquityInstruction, "instruction")
        return {
            "orderType": OrderType.LIMIT.value,
            "session": Session.NORMAL.value,
            "duration": Duration.DAY.value,
            "orderStrategyType": OrderStrategyType.SINGLE.value,
            "orderLegCollection": [
                {
                    "instruction": validated_instruction,
                    "quantity": quantity,
                    "instrument": {"symbol": symbol, "assetType": AssetType.EQUITY.value},
                }
            ],
            "price": price,
        }

    @staticmethod
    def build_market_order(symbol: str, quantity: int, instruction: str = "BUY") -> Dict[str, Any]:
        if quantity <= 0:
            raise ValueError(f"quantity must be > 0, got {quantity}")
        validated_instruction = coerce_enum(instruction, EquityInstruction, "instruction")
        return {
            "orderType": OrderType.MARKET.value,
            "session": Session.NORMAL.value,
            "duration": Duration.DAY.value,
            "orderStrategyType": OrderStrategyType.SINGLE.value,
            "orderLegCollection": [
                {
                    "instruction": validated_instruction,
                    "quantity": quantity,
                    "instrument": {"symbol": symbol, "assetType": AssetType.EQUITY.value},
                }
            ],
        }

    @staticmethod
    def build_bracket_order(symbol: str, quantity: int, entry_price: float, take_profit_price: float, stop_loss_price: float) -> Dict[str, Any]:
        if quantity <= 0:
            raise ValueError(f"quantity must be > 0, got {quantity}")
        if entry_price <= 0:
            raise ValueError(f"entry_price must be > 0, got {entry_price}")
        if take_profit_price <= 0:
            raise ValueError(f"take_profit_price must be > 0, got {take_profit_price}")
        if stop_loss_price <= 0:
            raise ValueError(f"stop_loss_price must be > 0, got {stop_loss_price}")
        return {
            "orderType": OrderType.LIMIT.value,
            "session": Session.NORMAL.value,
            "duration": Duration.DAY.value,
            "orderStrategyType": OrderStrategyType.TRIGGER.value,
            "orderLegCollection": [
                {
                    "instruction": EquityInstruction.BUY.value,
                    "quantity": quantity,
                    "instrument": {"symbol": symbol, "assetType": AssetType.EQUITY.value},
                }
            ],
            "price": entry_price,
            "childOrderStrategies": [
                {
                    "orderStrategyType": OrderStrategyType.OCO.value,
                    "childOrderStrategies": [
                        {
                            "orderType": OrderType.LIMIT.value,
                            "session": Session.NORMAL.value,
                            "duration": Duration.DAY.value,
                            "orderStrategyType": OrderStrategyType.SINGLE.value,
                            "orderLegCollection": [
                                {
                                    "instruction": EquityInstruction.SELL.value,
                                    "quantity": quantity,
                                    "instrument": {"symbol": symbol, "assetType": AssetType.EQUITY.value},
                                }
                            ],
                            "price": take_profit_price,
                        },
                        {
                            "orderType": OrderType.STOP.value,
                            "session": Session.NORMAL.value,
                            "duration": Duration.DAY.value,
                            "orderStrategyType": OrderStrategyType.SINGLE.value,
                            "orderLegCollection": [
                                {
                                    "instruction": EquityInstruction.SELL.value,
                                    "quantity": quantity,
                                    "instrument": {"symbol": symbol, "assetType": AssetType.EQUITY.value},
                                }
                            ],
                            "stopPrice": stop_loss_price,
                        },
                    ],
                }
            ],
        }


# ---------------------------------------------------------------------------
# Async variant
# ---------------------------------------------------------------------------

class AsyncOrders:
    """
    Module for endpoints related to orders (async).
    """

    def __init__(self, client):
        self.client = client
        self.base_url = client.trader_base_url

    async def get_orders(
        self,
        account_hash: str,
        from_entered_time: str = None,
        to_entered_time: str = None,
        status: Optional[str] = None,
        max_results: Optional[int] = None,
    ) -> Dict[str, Any]:
        start_norm, end_norm = normalize_date_range(from_entered_time, to_entered_time, default_days=60)
        endpoint = f"{self.base_url}/accounts/{account_hash}/orders"
        params = {'fromEnteredTime': start_norm, 'toEnteredTime': end_norm}
        if status:
            params['status'] = coerce_enum(status, OrderStatus, "status")
        if max_results is not None:
            params['maxResults'] = max_results
        try:
            response = await self.client._request("GET", endpoint, params=params, timeout=30)
            return _build_order_result(response, method='GET', params=params)
        except httpx.RequestError as e:
            return _build_error_result(e, endpoint, method='GET', params=params)

    async def place_order(self, account_hash: str, order_data: Dict[str, Any]) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/accounts/{account_hash}/orders"
        headers = {"Content-Type": "application/json"}
        try:
            response = await self.client._request("POST", endpoint, json=order_data, headers=headers, timeout=15)
            return _build_order_result(response, method='POST')
        except httpx.RequestError as e:
            return _build_error_result(e, endpoint, method='POST')

    async def get_order(self, account_hash: str, order_id: str) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/accounts/{account_hash}/orders/{order_id}"
        try:
            response = await self.client._request("GET", endpoint, timeout=10)
            return _build_order_result(response, method='GET', order_id=order_id)
        except httpx.RequestError as e:
            return _build_error_result(e, endpoint, method='GET', order_id=order_id)

    async def cancel_order(self, account_hash: str, order_id: str) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/accounts/{account_hash}/orders/{order_id}"
        try:
            response = await self.client._request("DELETE", endpoint, timeout=10)
            return _build_order_result(response, method='DELETE', order_id=order_id)
        except httpx.RequestError as e:
            return _build_error_result(e, endpoint, method='DELETE', order_id=order_id)

    async def replace_order(self, account_hash: str, order_id: str, new_order_data: Dict[str, Any]) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/accounts/{account_hash}/orders/{order_id}"
        headers = {"Content-Type": "application/json"}
        try:
            response = await self.client._request("PUT", endpoint, json=new_order_data, headers=headers, timeout=15)
            result = _build_order_result(response, method='PUT')
            result['original_order_id'] = order_id
            return result
        except httpx.RequestError as e:
            r = _build_error_result(e, endpoint, method='PUT')
            r['original_order_id'] = order_id
            return r

    async def get_all_orders(
        self,
        from_entered_time: str = None,
        to_entered_time: str = None,
        status: Optional[str] = None,
        max_results: Optional[int] = None,
    ) -> Dict[str, Any]:
        start_norm, end_norm = normalize_date_range(from_entered_time, to_entered_time, default_days=60)
        endpoint = f"{self.base_url}/orders"
        params = {'fromEnteredTime': start_norm, 'toEnteredTime': end_norm}
        if status:
            params['status'] = coerce_enum(status, OrderStatus, "status")
        if max_results is not None:
            params['maxResults'] = max_results
        try:
            response = await self.client._request("GET", endpoint, params=params, timeout=30)
            return _build_order_result(response, method='GET', params=params)
        except httpx.RequestError as e:
            return _build_error_result(e, endpoint, method='GET', params=params)

    async def preview_order(self, account_hash: str, order_data: Dict[str, Any]) -> Dict[str, Any]:
        endpoint = f"{self.base_url}/accounts/{account_hash}/previewOrder"
        headers = {"Content-Type": "application/json"}
        try:
            response = await self.client._request("POST", endpoint, json=order_data, headers=headers, timeout=15)
            return _build_order_result(response, method='POST')
        except httpx.RequestError as e:
            return _build_error_result(e, endpoint, method='POST')

    # Static helpers — delegate to the sync class
    build_limit_order = staticmethod(Orders.build_limit_order)
    build_market_order = staticmethod(Orders.build_market_order)
    build_bracket_order = staticmethod(Orders.build_bracket_order)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _extract_order_id_from_location(location_header: Optional[str]) -> Optional[str]:
    """Extract order_id from a Location header."""
    if not location_header:
        return None
    try:
        match = re.search(r'/orders/([^/]+)(?:/.*)?$', location_header)
        if match:
            return match.group(1)
        segments = location_header.rstrip('/').split('/')
        if len(segments) > 0:
            return segments[-1]
    except Exception:
        pass
    return None


def _build_order_result(response: httpx.Response, *, method: str, params=None, order_id=None) -> Dict[str, Any]:
    """Build a standardized result dict from an httpx response."""
    result: Dict[str, Any] = {
        'status_code': response.status_code,
        'success': 200 <= response.status_code < 300,
        'headers': dict(response.headers),
        'url': str(response.url),
        'elapsed_seconds': response.elapsed.total_seconds(),
        'method': method,
    }
    if params is not None:
        result['params'] = params
    if order_id is not None:
        result['order_id'] = order_id

    if result['success']:
        try:
            schwab_data = response.json() if response.text else {}
        except Exception:
            schwab_data = {} if method != 'GET' else []
        result['data'] = schwab_data

        extracted_id = _extract_order_id_from_location(response.headers.get("Location") or response.headers.get("location"))
        if extracted_id:
            result['order_id'] = extracted_id
    else:
        try:
            error_data = response.json() if response.text else {}
        except Exception:
            error_data = {'error': response.text or 'No error details'}
        result['data'] = error_data
        result['error_message'] = f"{response.status_code} {response.reason_phrase} for url: {response.url}"
        raise_for_schwab_status(response)

    return result


def _build_error_result(exc: httpx.RequestError, endpoint: str, *, method: str, params=None, order_id=None) -> Dict[str, Any]:
    """Build a standardized error result dict from an httpx exception."""
    result: Dict[str, Any] = {
        'status_code': 0,
        'success': False,
        'headers': {},
        'url': endpoint,
        'elapsed_seconds': 0,
        'method': method,
        'data': {'error': str(exc)},
        'error_message': str(exc),
    }
    if params is not None:
        result['params'] = params
    if order_id is not None:
        result['order_id'] = order_id
    return result
