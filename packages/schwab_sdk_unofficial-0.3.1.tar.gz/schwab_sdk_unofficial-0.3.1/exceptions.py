"""
Schwab SDK - Custom Exceptions

Provides a hierarchy of specific, actionable exceptions for Schwab API errors.
Each exception carries the HTTP status code, Schwab's error message (from the
response body), the ``Schwab-Client-CorrelId`` for support tracking, and the
raw ``httpx.Response`` for advanced inspection.

Usage::

    from schwab_sdk import SchwabAPIError, SchwabNotFoundError

    try:
        client.account.get_account_by_id("invalid-hash")
    except SchwabNotFoundError as e:
        print(f"Not found: {e.message}")
        print(f"Correlation ID: {e.correl_id}")  # for Schwab support
    except SchwabAPIError as e:
        print(f"API error {e.status_code}: {e.message}")
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _extract_error_details(response) -> Dict[str, Any]:
    """
    Extract structured error information from a Schwab API response.

    Schwab error format (from official docs)::

        {
          "errors": [
            {
              "id": "uuid",
              "status": "400",
              "title": "Bad Request",
              "detail": "Missing header",
              "source": {"header": "Authorization"}
            }
          ]
        }

    Returns:
        Dict with keys: message (str), errors (list of raw error dicts),
        correl_id (str or None).
    """
    # Extract Schwab-Client-CorrelId from response headers
    correl_id = None
    try:
        correl_id = (
            response.headers.get("Schwab-Client-CorrelId")
            or response.headers.get("schwab-client-correlid")
        )
    except Exception:
        pass

    errors_raw: List[Dict[str, Any]] = []
    message = ""

    try:
        body = response.json()
        if isinstance(body, dict):
            # Format: {"errors": [{...}, ...]}  — official Schwab format
            if "errors" in body and isinstance(body["errors"], list):
                errors_raw = body["errors"]
                parts = []
                for e in errors_raw:
                    if isinstance(e, dict):
                        msg = e.get("detail") or e.get("title") or e.get("message")
                        # Append source context if available
                        source = e.get("source")
                        if msg and source and isinstance(source, dict):
                            source_info = _format_source(source)
                            if source_info:
                                msg = f"{msg} ({source_info})"
                        if msg:
                            parts.append(str(msg))
                        else:
                            parts.append(str(e))
                    else:
                        parts.append(str(e))
                if parts:
                    message = "; ".join(parts)
            # Fallback formats
            if not message:
                if "message" in body:
                    message = str(body["message"])
                elif "error" in body:
                    message = str(body["error"])
            if not message:
                message = str(body)
    except Exception:
        message = response.text or response.reason_phrase or "Unknown error"

    return {
        "message": message,
        "errors": errors_raw,
        "correl_id": correl_id,
    }


def _format_source(source: Dict[str, Any]) -> str:
    """Format the error source field into a readable string."""
    parts = []
    if "header" in source:
        parts.append(f"header: {source['header']}")
    if "parameter" in source:
        parts.append(f"param: {source['parameter']}")
    if "pointer" in source:
        pointers = source["pointer"]
        if isinstance(pointers, list):
            parts.append(f"fields: {', '.join(pointers)}")
        else:
            parts.append(f"field: {pointers}")
    return "; ".join(parts)


# ---------------------------------------------------------------------------
# Base exception
# ---------------------------------------------------------------------------

class SchwabAPIError(Exception):
    """
    Base exception for all Schwab API errors.

    Attributes:
        status_code: HTTP status code returned by the API.
        message:     Human-readable error message (from the response body when
                     available, otherwise from the HTTP reason phrase).
        correl_id:   Schwab-Client-CorrelId header for support tracking.
        errors:      Raw list of error dicts from the Schwab response body.
        response:    The raw ``httpx.Response`` object for advanced users.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 0,
        correl_id: Optional[str] = None,
        errors: Optional[List[Dict[str, Any]]] = None,
        response: Optional[Any] = None,
    ) -> None:
        self.status_code = status_code
        self.message = message
        self.correl_id = correl_id
        self.errors = errors or []
        self.response = response
        super().__init__(f"[{status_code}] {message}")


# ---------------------------------------------------------------------------
# Specific exceptions (ordered by status code)
# ---------------------------------------------------------------------------

class SchwabValidationError(SchwabAPIError):
    """400 Bad Request — invalid parameters or malformed request body."""


class SchwabAuthenticationError(SchwabAPIError):
    """401 Unauthorized — access token is missing, invalid, or expired."""


class SchwabForbiddenError(SchwabAPIError):
    """403 Forbidden — valid credentials but insufficient permissions."""


class SchwabNotFoundError(SchwabAPIError):
    """404 Not Found — the requested resource does not exist."""


class SchwabRateLimitError(SchwabAPIError):
    """429 Too Many Requests — API rate limit exceeded (after retries)."""


class SchwabServerError(SchwabAPIError):
    """5xx Server Error — Schwab-side failure (after retries)."""


class SchwabTokenExpiredError(SchwabAuthenticationError):
    """Refresh token has expired and a full re-login is required."""


class SchwabParameterError(ValueError):
    """Client-side parameter validation error (distinct from HTTP 400)."""


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

# Maps HTTP status codes to exception classes.
_STATUS_MAP: Dict[int, type] = {
    400: SchwabValidationError,
    401: SchwabAuthenticationError,
    403: SchwabForbiddenError,
    404: SchwabNotFoundError,
    429: SchwabRateLimitError,
    500: SchwabServerError,
    502: SchwabServerError,
    503: SchwabServerError,
    504: SchwabServerError,
}


def raise_for_schwab_status(response) -> None:
    """
    Inspect an ``httpx.Response`` and raise the appropriate
    :class:`SchwabAPIError` subclass if the status code indicates a failure.

    Does nothing for 2xx responses. Extracts the ``Schwab-Client-CorrelId``
    header, error details, and source context from the response.
    """
    code = response.status_code
    if 200 <= code < 300:
        return  # success — nothing to do

    details = _extract_error_details(response)
    exc_cls = _STATUS_MAP.get(code, SchwabAPIError)
    raise exc_cls(
        details["message"],
        status_code=code,
        correl_id=details["correl_id"],
        errors=details["errors"],
        response=response,
    )
