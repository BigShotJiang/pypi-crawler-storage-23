# Re-exported from features.py for cleaner import paths
from clinops.temporal.features import CohortAligner

__all__ = ["CohortAligner"]
