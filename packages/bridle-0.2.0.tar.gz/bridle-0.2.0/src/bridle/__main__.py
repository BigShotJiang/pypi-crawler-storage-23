from bridle import main

main()
