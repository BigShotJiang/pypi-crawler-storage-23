# Conjecturing Machine
A Machine that makes conjectures.
```bash
  echo '[{"role": "user", "content": "I have a question..."}]' \
    | uvx conjecturing-machine \
        --provider-api-key=sk-ant-api... \
        --github-token=ghp_... 
```
Or:
```bash
  pip install conjecturing-machine
```
Then:
```Python
  # Python
  import conjecturing_machine
```
