"""EvalGate SDK utilities."""
