"""Deprecated: Use voicerun_completions streaming types instead."""

from typing import Any, TypeAlias, Union
from dataclasses import dataclass

from .response import ChatCompletionResponse
from .messages import ToolCall


@dataclass
class AssistantMessageDeltaChunk:
    """Deprecated: Use voicerun_completions instead."""
    content: str

    @property
    def type(self) -> str:
        return "content_delta"


@dataclass
class AssistantMessageSentenceChunk:
    """Deprecated: Use voicerun_completions instead."""
    sentence: str

    @property
    def type(self) -> str:
        return "content_sentence"


@dataclass
class ToolCallChunk:
    """Deprecated: Use voicerun_completions instead."""
    tool_call: ToolCall

    @property
    def type(self) -> str:
        return "tool_call"


@dataclass
class FinishReasonChunk:
    """Deprecated: Use voicerun_completions instead."""
    finish_reason: str

    @property
    def type(self) -> str:
        return "finish_reason"


@dataclass
class UsageChunk:
    """Deprecated: Use voicerun_completions instead."""
    usage: dict[str, Any]

    @property
    def type(self) -> str:
        return "usage"


@dataclass
class FinalResponseChunk:
    """Deprecated: Use voicerun_completions instead."""
    response: ChatCompletionResponse

    @property
    def type(self) -> str:
        return "response"


ChatCompletionChunk: TypeAlias = Union[AssistantMessageDeltaChunk, ToolCallChunk, FinishReasonChunk, UsageChunk, FinalResponseChunk]
"""Deprecated: Use voicerun_completions instead."""
