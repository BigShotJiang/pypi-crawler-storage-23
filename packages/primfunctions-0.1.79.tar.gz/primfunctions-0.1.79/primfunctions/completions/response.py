"""Deprecated: Use voicerun_completions response types instead."""

from typing import Any, Optional
from dataclasses import dataclass

from .messages import AssistantMessage


@dataclass
class ChatCompletionResponse:
    """Deprecated: Use voicerun_completions instead."""
    message: AssistantMessage
    finish_reason: str
    usage: Optional[dict[str, Any]] = None
