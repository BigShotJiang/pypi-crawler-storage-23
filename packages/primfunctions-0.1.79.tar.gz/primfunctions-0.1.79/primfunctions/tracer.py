"""Tracer proxy for VoiceRun handler code.

Usage (from handler code):
    from primfunctions.tracer import tracer

    @tracer.tool
    def fetch_user(user_id: str) -> dict:
        ...

    @tracer.tool(name="lookup", description="Look up a record")
    def lookup_record(record_id: str) -> dict:
        ...

When running locally, decorated functions run unchanged.
When running in the sandbox, the implementation is swapped
to create OpenInference trace spans.
"""

import asyncio
import functools


class Tracer:
    def __init__(self):
        self._impl = None

    def tool(self, wrapped_function=None, /, *, name=None, description=None, parameters=None):
        """Decorator that marks a function as a traced tool.

        Can be used with or without arguments:
            @tracer.tool
            @tracer.tool(name="my-tool")
        """
        def decorator(fn):
            if self._impl:
                return self._impl.tool(fn, name=name, description=description, parameters=parameters)

            # No-op: return function unchanged
            @functools.wraps(fn)
            def sync_wrapper(*args, **kwargs):
                return fn(*args, **kwargs)

            @functools.wraps(fn)
            async def async_wrapper(*args, **kwargs):
                return await fn(*args, **kwargs)

            return async_wrapper if asyncio.iscoroutinefunction(fn) else sync_wrapper

        if wrapped_function is not None:
            # Called as @tracer.tool without arguments
            return decorator(wrapped_function)

        # Called as @tracer.tool(...) with arguments
        return decorator


tracer = Tracer()
