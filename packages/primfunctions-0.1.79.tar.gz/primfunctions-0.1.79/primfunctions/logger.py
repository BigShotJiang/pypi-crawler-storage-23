"""Logger proxy for VoiceRun handler code.

Usage (from handler code):
    from primfunctions.logger import logger

    logger.info("Lead qualified")
    logger.error("Payment failed", {"order_id": "123"})

When running locally, logs are printed to the console.
When running in the sandbox, the implementation is swapped
to emit LogEvents and trace spans.
"""


class Logger:
    def __init__(self):
        self._impl = None

    def info(self, message, attributes=None):
        if self._impl:
            self._impl.info(message, attributes)
        else:
            print(f"[info] {message}")

    def warn(self, message, attributes=None):
        if self._impl:
            self._impl.warn(message, attributes)
        else:
            print(f"[warn] {message}")

    def error(self, message, attributes=None):
        if self._impl:
            self._impl.error(message, attributes)
        else:
            print(f"[error] {message}")

    def debug(self, message, attributes=None):
        if self._impl:
            self._impl.debug(message, attributes)
        else:
            print(f"[debug] {message}")


logger = Logger()
