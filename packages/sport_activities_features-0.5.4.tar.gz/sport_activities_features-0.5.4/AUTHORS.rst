=======
Credits
=======

Maintainers
-----------

* Iztok Fister, Jr.

Contributors (alphabetically)
-----------------------------

* Dušan Fister
* Nejc Graj
* Rok Kukovec
* Tadej Lahovnik
* Zala Lahovnik
* Luka Lukač
* Miha Mirt
* Luka Pečnik
* Špela Pečnik
* Alen Rajšp
