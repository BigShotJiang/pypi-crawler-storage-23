"""Platform detection and setup for ai-engineering.

Detects GitHub, Azure DevOps, and SonarCloud/SonarQube from
repository markers and provides guided credential onboarding.
"""

from __future__ import annotations
