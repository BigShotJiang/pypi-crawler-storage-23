"""Shared git operations for ai-engineering.

Provides common git helpers used by workflows, gates, and maintenance.
"""
