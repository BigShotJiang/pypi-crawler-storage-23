"""Installer package for ai-engineering framework."""

from __future__ import annotations
