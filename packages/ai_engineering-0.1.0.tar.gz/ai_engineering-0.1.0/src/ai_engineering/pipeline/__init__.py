"""Pipeline compliance package for ai-engineering."""

from __future__ import annotations
