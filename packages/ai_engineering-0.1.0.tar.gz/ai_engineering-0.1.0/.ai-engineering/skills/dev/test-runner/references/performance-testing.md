# Performance Testing

## k6 Load Test

```javascript
import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  stages: [
    { duration: '30s', target: 20 },   // Ramp up
    { duration: '1m', target: 20 },    // Steady state
    { duration: '30s', target: 0 },    // Ramp down
  ],
  thresholds: {
    http_req_duration: ['p(95)<500'],  // 95% under 500ms
    http_req_failed: ['rate<0.01'],    // <1% errors
  },
};

export default function () {
  const res = http.get('http://localhost:3000/api/users');
  check(res, {
    'status is 200': (r) => r.status === 200,
    'response time < 200ms': (r) => r.timings.duration < 200,
  });
  sleep(1);
}
```

## Test Types

### Stress Test
```javascript
export const options = {
  stages: [
    { duration: '2m', target: 100 },
    { duration: '5m', target: 100 },
    { duration: '2m', target: 200 },
    { duration: '5m', target: 200 },
    { duration: '2m', target: 0 },
  ],
};
```

### Spike Test
```javascript
export const options = {
  stages: [
    { duration: '10s', target: 10 },
    { duration: '1m', target: 10 },
    { duration: '10s', target: 200 },  // Spike
    { duration: '3m', target: 200 },
    { duration: '10s', target: 10 },
    { duration: '3m', target: 10 },
  ],
};
```

## Thresholds Reference

```javascript
thresholds: {
  http_req_duration: ['p(95)<500', 'p(99)<1000'],
  http_req_failed: ['rate<0.01'],
  http_reqs: ['rate>100'],
  'http_req_duration{name:login}': ['p(95)<200'],
}
```

## Quick Reference

| Metric | Description |
|--------|-------------|
| `http_req_duration` | Response time |
| `http_req_failed` | Failed requests rate |
| `p(95)` | 95th percentile |

| Test Type | Purpose |
|-----------|---------|
| Load | Normal expected load |
| Stress | Find breaking point |
| Spike | Sudden traffic surge |
| Soak | Long duration stability |
