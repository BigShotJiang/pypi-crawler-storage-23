# Agent to Skill Map — Spec 021

## Coverage

- Agents: 14
- Skills: 44
- Skill categories: 6 (`workflows`, `dev`, `review`, `docs`, `govern`, `quality`)

## Mapping

| Agent | Referenced Skills |
|-------|-------------------|
| `architect` | `skills/dev/data-modeling/SKILL.md`, `skills/dev/refactor/SKILL.md`, `skills/docs/explain/SKILL.md`, `skills/review/architecture/SKILL.md` |
| `code-simplifier` | `skills/dev/code-review/SKILL.md`, `skills/dev/refactor/SKILL.md` |
| `debugger` | `skills/dev/debug/SKILL.md`, `skills/dev/test-strategy/SKILL.md`, `skills/docs/explain/SKILL.md` |
| `devops-engineer` | `skills/dev/cicd-generate/SKILL.md`, `skills/dev/deps-update/SKILL.md` |
| `docs-writer` | `skills/docs/changelog/SKILL.md`, `skills/docs/prompt-design/SKILL.md`, `skills/docs/simplify/SKILL.md`, `skills/docs/writer/SKILL.md` |
| `governance-steward` | `skills/govern/accept-risk/SKILL.md`, `skills/govern/adaptive-standards/SKILL.md`, `skills/govern/contract-compliance/SKILL.md`, `skills/govern/create-agent/SKILL.md`, `skills/govern/create-skill/SKILL.md`, `skills/govern/create-spec/SKILL.md`, `skills/govern/delete-agent/SKILL.md`, `skills/govern/delete-skill/SKILL.md`, `skills/govern/integrity-check/SKILL.md`, `skills/govern/ownership-audit/SKILL.md`, `skills/govern/renew-risk/SKILL.md`, `skills/govern/resolve-risk/SKILL.md` |
| `navigator` | `skills/docs/explain/SKILL.md`, `skills/govern/contract-compliance/SKILL.md` |
| `orchestrator` | `skills/dev/multi-agent/SKILL.md`, `skills/workflows/cleanup/SKILL.md`, `skills/workflows/pre-implementation/SKILL.md`, `skills/workflows/self-improve/SKILL.md` |
| `platform-auditor` | `skills/dev/multi-agent/SKILL.md`, `skills/govern/contract-compliance/SKILL.md`, `skills/govern/integrity-check/SKILL.md`, `skills/govern/ownership-audit/SKILL.md`, `skills/quality/audit-code/SKILL.md`, `skills/quality/docs-audit/SKILL.md`, `skills/quality/install-check/SKILL.md`, `skills/quality/release-gate/SKILL.md`, `skills/quality/sbom/SKILL.md`, `skills/quality/test-gap-analysis/SKILL.md`, `skills/review/architecture/SKILL.md`, `skills/review/container-security/SKILL.md`, `skills/review/dast/SKILL.md`, `skills/review/security/SKILL.md`, `skills/workflows/self-improve/SKILL.md` |
| `pr-reviewer` | `skills/dev/code-review/SKILL.md`, `skills/review/security/SKILL.md` |
| `principal-engineer` | `skills/dev/code-review/SKILL.md`, `skills/dev/refactor/SKILL.md`, `skills/dev/test-strategy/SKILL.md`, `skills/review/performance/SKILL.md`, `skills/review/security/SKILL.md` |
| `quality-auditor` | `skills/quality/audit-code/SKILL.md`, `skills/quality/release-gate/SKILL.md`, `skills/quality/test-gap-analysis/SKILL.md` |
| `security-reviewer` | `skills/dev/deps-update/SKILL.md`, `skills/quality/sbom/SKILL.md`, `skills/review/container-security/SKILL.md`, `skills/review/dast/SKILL.md`, `skills/review/data-security/SKILL.md`, `skills/review/security/SKILL.md` |
| `verify-app` | `skills/dev/debug/SKILL.md`, `skills/dev/migration/SKILL.md`, `skills/dev/test-strategy/SKILL.md`, `skills/govern/contract-compliance/SKILL.md`, `skills/govern/integrity-check/SKILL.md`, `skills/quality/install-check/SKILL.md`, `skills/workflows/acho/SKILL.md`, `skills/workflows/commit/SKILL.md`, `skills/workflows/pr/SKILL.md` |

## Orphan Check

- Orphan skills: 0
