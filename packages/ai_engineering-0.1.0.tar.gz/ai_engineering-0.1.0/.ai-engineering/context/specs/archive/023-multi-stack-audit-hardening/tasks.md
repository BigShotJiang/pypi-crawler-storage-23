---
spec: "023"
total: 55
completed: 55
last_session: "2026-02-26"
next_session: "done"
---

# Tasks — Multi-Stack Expansion + Audit-Driven Hardening

## Phase 0: Scaffold [S]

- [x] 0.1 Create branch `feat/023-multi-stack-audit-hardening`
- [x] 0.2 Scaffold spec files (spec.md, plan.md, tasks.md)
- [x] 0.3 Update `_active.md` to point to spec-023

## Phase 1: Stack Standards Expansion [L] ║

- [x] 1.1 Create `stacks/typescript.md`
- [x] 1.2 Create `stacks/react.md`
- [x] 1.3 Create `stacks/react-native.md`
- [x] 1.4 Create `stacks/nestjs.md`
- [x] 1.5 Create `stacks/astro.md`
- [x] 1.6 Create `stacks/rust.md`
- [x] 1.7 Create `stacks/node.md`
- [x] 1.8 Create `stacks/bash-powershell.md`
- [x] 1.9 Update `stacks/nextjs.md` — add TS base reference

## Phase 2: Cross-Cutting Standards [M] ║

- [x] 2.1 Create `stacks/azure.md`
- [x] 2.2 Create `stacks/infrastructure.md`
- [x] 2.3 Create `stacks/database.md`

## Phase 3: Behavioral Hardening [L]

- [x] 3.1 Add 3 behavioral patterns to `skills-schema.md`
- [x] 3.2 Add 3 behavioral baselines to `core.md`
- [x] 3.3 Improve `agents/devops-engineer.md`
- [x] 3.4 Improve `agents/architect.md`
- [x] 3.5 Improve `agents/security-reviewer.md`
- [x] 3.6 Improve `agents/orchestrator.md`
- [x] 3.7 Improve `agents/principal-engineer.md`
- [x] 3.8 Improve `agents/test-master.md`
- [x] 3.9 Improve `skills/dev/cicd-generate/SKILL.md`
- [x] 3.10 Improve `skills/dev/deps-update/SKILL.md`
- [x] 3.11 Improve `skills/review/security/SKILL.md`
- [x] 3.12 Expand `delivery-platform-patterns.md`
- [x] 3.13 Expand `language-framework-patterns.md`
- [x] 3.14 Expand `database-patterns.md`
- [x] 3.15 Expand `api-design-patterns.md`
- [x] 3.16 Expand `platform-detect.md`
- [x] 3.17 Expand `git-helpers.md`

## Phase 4: New Agents + Skills [L]

- [x] 4.1 Create `agents/infrastructure-engineer.md`
- [x] 4.2 Create `agents/database-engineer.md`
- [x] 4.3 Create `agents/frontend-specialist.md`
- [x] 4.4 Create `agents/api-designer.md`
- [x] 4.5 Create `skills/dev/api-design/SKILL.md`
- [x] 4.6 Create `skills/dev/infrastructure/SKILL.md`
- [x] 4.7 Create `skills/review/accessibility/SKILL.md`
- [x] 4.8 Create `skills/dev/database-ops/SKILL.md`

## Phase 5: Registration + Integrity [L]

- [x] 5.1 Update `manifest.yml`
- [x] 5.2 Create template mirrors for new agents
- [x] 5.3 Create template mirrors for new skills
- [x] 5.4 Create template mirrors for new standards
- [x] 5.5 Register new agents in instruction files
- [x] 5.6 Register new skills in instruction files
- [x] 5.7 Add new stack standards to instruction files
- [x] 5.8 Create Claude Code command wrappers for new agents
- [x] 5.9 Create Claude Code command wrappers for new skills
- [x] 5.10 Create Copilot prompt wrappers
- [x] 5.11 Update `product-contract.md`
- [x] 5.12 Update CHANGELOG.md
- [x] 5.13 Cross-reference from related content
- [x] 5.14 Update token inventory table
- [x] 5.15 Run integrity-check
