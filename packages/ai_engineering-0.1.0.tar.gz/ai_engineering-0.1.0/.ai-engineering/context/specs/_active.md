---
active: null
updated: "2026-02-27"
---

# Active Spec

No active spec — ready for `/create-spec`.

## Quick Resume

No spec in progress.
