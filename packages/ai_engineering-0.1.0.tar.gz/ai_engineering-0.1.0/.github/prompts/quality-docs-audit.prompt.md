---
description: "Documentation health audit for governance content; use for weekly maintenance, pre-release doc review, or content compaction."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/quality/docs-audit/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
