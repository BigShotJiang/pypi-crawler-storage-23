---
description: "Audit, update, and validate project dependencies for security and compatibility; use when addressing vulnerabilities, outdated packages, or version bumps."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/dev/deps-update/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
