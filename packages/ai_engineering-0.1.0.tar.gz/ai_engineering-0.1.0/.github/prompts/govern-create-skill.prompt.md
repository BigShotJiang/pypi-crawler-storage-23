---
description: "Author and register a new skill: canonical file, mirror, instruction files, counters, changelog."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/govern/create-skill/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
