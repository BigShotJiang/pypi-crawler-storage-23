---
description: "Systematic bug diagnosis using reproduce-isolate-identify-fix-test cycle; use when investigating unexpected behavior, test failures, or runtime errors."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/dev/debug/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
