---
description: "Design database schemas, plan safe migrations, optimize queries, and manage data lifecycle with rollback procedures."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/dev/database-ops/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
