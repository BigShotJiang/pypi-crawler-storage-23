---
description: "Transform codebase knowledge into polished open-source documentation (README, CONTRIBUTING, docs/ site, Wiki) using benefit-first language."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/docs/writer/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
