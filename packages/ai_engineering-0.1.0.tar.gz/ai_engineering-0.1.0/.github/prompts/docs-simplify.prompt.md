---
description: "Simplify governance/docs content while preserving intent, constraints, and auditability."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/docs/simplify/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
