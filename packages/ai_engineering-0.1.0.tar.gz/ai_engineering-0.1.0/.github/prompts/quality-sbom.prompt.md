---
description: "CycloneDX software bill of materials generation; use for release preparation, compliance audit, or supply chain review."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/quality/sbom/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
