---
description: "Aggregated GO/NO-GO release readiness gate; use before version tagging or merge-to-main to verify all quality dimensions pass."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/quality/release-gate/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
