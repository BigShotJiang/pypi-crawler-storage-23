---
description: "Post-install/update validation for ai-engineering; use after install, update, or environment setup to confirm operational readiness."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/quality/install-check/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
