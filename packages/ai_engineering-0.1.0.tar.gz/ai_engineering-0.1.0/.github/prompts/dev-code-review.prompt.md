---
description: "Deep code review covering security, quality, performance, and maintainability; use for PR reviews, pre-merge validation, or code audits."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/dev/code-review/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
