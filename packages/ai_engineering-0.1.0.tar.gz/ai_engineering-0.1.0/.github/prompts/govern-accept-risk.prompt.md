---
description: "Record time-limited risk acceptance with severity classification, follow-up action, and audit trail."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/govern/accept-risk/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
