---
description: "Run SonarCloud/SonarQube quality gate locally before push; silently skips when SONAR_TOKEN is not configured."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/dev/sonar-gate/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
