---
description: "Validate ownership boundaries, updater safety, decision-store integrity, and audit-log consistency."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/govern/ownership-audit/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
