---
description: "Execute governed PR workflow: stage, commit, push, create pull request with auto-complete squash merge."
mode: "agent"
---

Before executing, verify these preconditions:

1. Current branch is NOT `main` or `master` (abort with warning if so).
2. Working tree has staged or unstaged changes, or commits ahead of remote (abort if nothing to push/PR).
3. Active spec is read from `.ai-engineering/context/specs/_active.md`.

Read and execute the skill defined in `.ai-engineering/skills/workflows/pr/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
