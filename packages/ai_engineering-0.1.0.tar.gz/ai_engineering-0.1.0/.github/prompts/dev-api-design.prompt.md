---
description: "Design and review APIs using contract-first approach with OpenAPI specification, versioning strategy, and backward compatibility analysis."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/dev/api-design/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
