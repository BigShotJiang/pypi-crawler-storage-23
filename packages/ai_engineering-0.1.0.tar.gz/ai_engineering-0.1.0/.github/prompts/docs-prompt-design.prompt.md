---
description: "Advanced prompt engineering for crafting AI interactions using framework selection, blending strategies, and quality validation."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/docs/prompt-design/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
