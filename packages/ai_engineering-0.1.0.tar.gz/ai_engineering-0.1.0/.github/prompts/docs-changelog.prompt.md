---
description: "Generate user-friendly changelogs and GitHub release notes from git history using Keep a Changelog format and benefit-first language."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/docs/changelog/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
