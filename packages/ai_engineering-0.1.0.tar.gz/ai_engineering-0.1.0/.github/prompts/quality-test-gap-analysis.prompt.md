---
description: "Capability-to-test risk mapping; use before release or after refactoring to identify untested critical paths and coverage gaps."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/quality/test-gap-analysis/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
