---
description: "Design test strategy covering what to test, test tiers, and meaningful coverage; use when planning tests for new features, bug fixes, or refactoring."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/dev/test-strategy/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
