---
description: "Safely remove an agent: check dependents, clean all registration points, update counters."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/govern/delete-agent/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
