---
description: "Generate stack-aware CI/CD workflow files from installed stacks and enforcement checks; use when setting up or modernizing CI/CD pipelines."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/dev/cicd-generate/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
