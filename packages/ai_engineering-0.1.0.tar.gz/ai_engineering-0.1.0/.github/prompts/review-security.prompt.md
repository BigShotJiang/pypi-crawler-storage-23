---
description: "Perform comprehensive security review covering OWASP risks, secrets, injection, and dependency vulnerabilities; use for pre-release audits or incident response."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/review/security/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
