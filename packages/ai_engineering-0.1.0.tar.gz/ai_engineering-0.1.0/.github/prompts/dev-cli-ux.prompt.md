---
description: "Agent-first CLI design: JSON envelope output, Rich human UX, progress indicators, and dual-mode routing."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/dev/cli-ux/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
