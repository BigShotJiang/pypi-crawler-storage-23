---
description: "Run dynamic security scans with OWASP ZAP and Nuclei against live staging environments; use for post-deploy or pre-release verification."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/review/dast/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
