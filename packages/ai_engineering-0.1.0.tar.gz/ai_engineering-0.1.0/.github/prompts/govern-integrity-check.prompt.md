---
description: "Validate governance content integrity: cross-references, mirrors, counters, frontmatter, manifest."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/govern/integrity-check/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
