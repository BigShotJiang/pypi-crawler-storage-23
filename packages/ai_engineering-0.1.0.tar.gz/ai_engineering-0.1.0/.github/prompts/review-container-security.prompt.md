---
description: "Scan container images with Trivy for CVEs, misconfigurations, and secrets; use before container promotion or deployment."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/review/container-security/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
