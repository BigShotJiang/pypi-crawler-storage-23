---
description: "Write and run tests across languages and frameworks; use for unit, integration, E2E testing, coverage analysis, and test strategy."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/dev/test-runner/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
