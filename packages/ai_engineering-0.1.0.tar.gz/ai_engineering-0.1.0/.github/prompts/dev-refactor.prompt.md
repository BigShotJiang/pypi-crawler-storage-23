---
description: "Improve internal code structure without changing external behavior; use when addressing code smells, duplication, or excessive complexity."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/dev/refactor/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
