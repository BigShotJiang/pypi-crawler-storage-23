---
description: "SonarQube-like quality gate assessment; use before merge or release to evaluate coverage, duplication, complexity, and security."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/quality/audit-code/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
