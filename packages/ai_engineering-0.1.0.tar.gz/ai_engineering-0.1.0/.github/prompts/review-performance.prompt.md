---
description: "Profile and optimize performance bottlenecks with evidence-based measurement; use when diagnosing slow operations or high resource usage."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/review/performance/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
