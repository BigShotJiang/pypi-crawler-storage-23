---
description: "Coordinate multiple agent personas in parallel or sequence using Task tool patterns; use for full-spectrum audits, cross-cutting reviews, or batch operations."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/dev/multi-agent/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
