---
description: "Analyze software architecture for dependencies, coupling, cohesion, and tech debt; use for design decisions and brownfield assessment."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/review/architecture/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
