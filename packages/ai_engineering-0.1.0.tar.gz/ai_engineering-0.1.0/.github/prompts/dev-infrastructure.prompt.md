---
description: "Design and generate Infrastructure as Code (Terraform, Bicep) with plan-before-apply safety, state management, and deployment configuration."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/dev/infrastructure/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
