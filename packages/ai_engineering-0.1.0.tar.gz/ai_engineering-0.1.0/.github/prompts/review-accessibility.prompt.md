---
description: "Review frontend code for WCAG 2.1 AA compliance: semantic HTML, ARIA patterns, keyboard navigation, color contrast, and screen reader support."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/review/accessibility/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
