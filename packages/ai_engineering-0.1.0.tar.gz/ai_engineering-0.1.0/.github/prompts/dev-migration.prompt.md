---
description: "Plan and execute safe, reversible migrations for schemas, APIs, data formats, and breaking changes; use when evolving contracts or data structures."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/dev/migration/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
