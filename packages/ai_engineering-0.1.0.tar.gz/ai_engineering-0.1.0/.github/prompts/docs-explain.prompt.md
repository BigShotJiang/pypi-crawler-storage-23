---
description: "Feynman-style layered explanations of code, concepts, patterns, and architecture with 3-tier depth control and codebase-anchored examples."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/docs/explain/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
