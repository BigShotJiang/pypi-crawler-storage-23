---
description: "Create a new spec before non-trivial work: branch, scaffold spec/plan/tasks, activate, commit."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/govern/create-spec/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
