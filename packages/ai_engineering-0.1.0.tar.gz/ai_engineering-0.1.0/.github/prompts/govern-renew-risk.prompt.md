---
description: "Extend a risk acceptance before expiry with mandatory justification (max 2 renewals)."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/govern/renew-risk/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
