---
description: "Close a risk acceptance after remediation: mark as remediated, log audit event, verify gates."
mode: "agent"
---

Read and execute the skill defined in `.ai-engineering/skills/govern/resolve-risk/SKILL.md`.

Follow the complete procedure. Do not skip steps. Apply all governance notes.
