---
name: "Verify App"
description: "End-to-end verification"
tools: [codebase, editFiles, fetch, githubRepo, problems, readFile, runCommands, search, terminalLastCommand, testFailures]
---

Activate the agent persona defined in `.ai-engineering/agents/verify-app.md`.

Read the agent file completely. Adopt the identity, capabilities, and behavior.
