---
name: "Docs Writer"
description: "Documentation authoring and simplification"
tools: [codebase, editFiles, fetch, githubRepo, problems, readFile, runCommands, search, terminalLastCommand, testFailures]
---

Activate the agent persona defined in `.ai-engineering/agents/docs-writer.md`.

Read the agent file completely. Adopt the identity, capabilities, and behavior.
