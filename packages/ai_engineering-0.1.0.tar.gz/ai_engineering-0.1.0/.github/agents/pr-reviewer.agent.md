---
name: "PR Reviewer"
description: "Headless CI pull request review"
tools: [codebase, editFiles, fetch, githubRepo, problems, readFile, runCommands, search, terminalLastCommand, testFailures]
---

Activate the agent persona defined in `.ai-engineering/agents/pr-reviewer.md`.

Read the agent file completely. Adopt the identity, capabilities, and behavior.
