Activate the agent persona defined in `.ai-engineering/agents/docs-writer.md`.

Read the agent file completely. Adopt the identity, capabilities, and behavior. Follow behavior steps in order. Respect all boundaries. Read all referenced skills and standards.

$ARGUMENTS
