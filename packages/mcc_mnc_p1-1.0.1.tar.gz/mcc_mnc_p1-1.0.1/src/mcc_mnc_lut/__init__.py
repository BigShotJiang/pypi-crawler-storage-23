__all__ = [
    'p1_mnc',
    'p1_mcc',
    'p1_msisdn',
    'p1_msisdnext',
    'p1_ispc',
    'p1_sanc',
    'p1_cc2',
    'p1_cntr',
    'p1_terr',
]
