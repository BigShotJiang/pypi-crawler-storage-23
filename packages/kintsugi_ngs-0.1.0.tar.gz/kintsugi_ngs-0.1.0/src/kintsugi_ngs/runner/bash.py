from typing_extensions import final
from kintsugi_ngs.core.runner import RunnerBase
import subprocess
import os

@final
class BashRunner(RunnerBase):
    def run(self, command: str):
       subprocess.call(command, shell = True)

    def checkpoint_exists(self, checkpoint: str) -> bool:
        if checkpoint == "":
            return False
        return os.path.isfile(checkpoint + ".txt")

    def generate_checkpoint(self, checkpoint: str):
        with open(checkpoint + ".txt", 'w') as file:
            file.write("")
