from typing import TypeVar, Any, Type, Dict

T = TypeVar("T")

def filter_by_type(d: Dict[str, Any], t: Type[T]) -> Dict[str, T]:
    return {k: v for k, v in d.items() if isinstance(v, t)}

def flatten_dict(d: Dict[str, Any], parent_key: str = "", sep: str = ".") -> Dict[str, Any]:
    items = {}
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.update(flatten_dict(v, new_key, sep))
        elif k != "outdir":
            items[new_key] = v
    return items

def dict_as_strings(d: Dict[str, Any]) -> Dict[str, str]:
    return {key: str(value) for key, value in d.items()}
