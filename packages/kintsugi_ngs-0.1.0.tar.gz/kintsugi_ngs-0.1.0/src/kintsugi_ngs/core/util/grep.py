from typing import Annotated
from pydantic import BaseModel, StringConstraints

# Basic limitation to consider the input to be a grep pattern
GrepPattern = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1)]

class GrepModel(BaseModel):
    pattern: GrepPattern
