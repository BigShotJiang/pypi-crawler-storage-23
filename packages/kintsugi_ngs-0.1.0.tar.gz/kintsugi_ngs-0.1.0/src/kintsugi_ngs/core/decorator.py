from pydantic import BaseModel
from abc import ABC, abstractmethod
from typing_extensions import final

class DecoratorBase(BaseModel, ABC):

    @property
    @abstractmethod
    def pre(self) -> str:
        pass

    @property
    @abstractmethod
    def post(self) -> str:
        pass

    def apply(self, template: str) -> str:
        return self.pre + template + self.post

@final
class Decorator(DecoratorBase):
    before: str
    after: str

    @property
    def pre(self):
        return self.before

    @property
    def post(self):
        return self.after
