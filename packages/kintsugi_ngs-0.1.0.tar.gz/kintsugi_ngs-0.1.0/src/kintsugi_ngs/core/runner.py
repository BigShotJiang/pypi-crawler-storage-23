from abc import ABC, abstractmethod
from typing import List, Self, TypeVar, Dict, Type, Callable, Tuple
from kintsugi_ngs.core.command import ArgsModel, Out
from kintsugi_ngs.core.decorator import DecoratorBase
from pydantic import BaseModel
import os

# TODO: these should implement railrod methods of Result

class RunnerBase(BaseModel, ABC):
    name: str

    @abstractmethod
    def run(self, command: str):
       pass

    @abstractmethod
    def checkpoint_exists(self, checkpoint: str) -> bool:
        pass

    @abstractmethod
    def generate_checkpoint(self, checkpoint: str):
        pass

Run = TypeVar("Run", bound = RunnerBase)

class PipelineStep(BaseModel):
    command: ArgsModel
    runner: RunnerBase
    decorators: List[DecoratorBase] = list()
    checkpoint: str = ""
    force: bool = False

    def run(self):
        if self.force or not self.runner.checkpoint_exists(self.checkpoint):
            self.runner.run(self.command.generate(self.decorators))

    def validate_output(self):
        self.command.validate_output()

    def generate_checkpoint(self):
        self.runner.generate_checkpoint(self.checkpoint)

class Pipeline:

    def __init__(self, steps: List[Tuple[str, PipelineStep]]):
        self.__steps: List[Tuple[str, PipelineStep]] = steps

    def run(self):
        for name, step in self.__steps:
            step.run()
            step.validate_output()
            step.generate_checkpoint()

    def dump(self):
        dump: str = ""
        for name, step in self.__steps:
            dump += (step.command.generate() + os.linesep)
        return dump

class PipelineBuilder:

    def __init__(self):
        self.__steps: Dict[str, Callable[[Self], PipelineStep]] = dict()
        self.__order: List[str] = list()
        self.__buildDict: Dict[str, PipelineStep] = dict()
        self.__buildList: List[str] = list()

    def add_step(self, name: str, step: Callable[[Self], PipelineStep]) -> Self:
        self.__steps[name] = step
        self.__order += [name]
        return self

    def build(self) -> Pipeline:
        pipeline: List[Tuple[str, PipelineStep]] = list()
        for name in self.__order:
            step = self.__steps[name](self)
            self.__buildList.append(name)
            self.__buildDict[name] = step
            pipeline.append((name, step))
        # clear the builder
        self.__buildList = list()
        self.__buildDict = dict()
        # return the pipeline
        return Pipeline(pipeline)

    def get_step(self, name: str, args_type: Type[ArgsModel[Out]]) -> ArgsModel[Out]:
        command = self.__buildDict[name].command
        if isinstance(command, args_type):
            return command
        raise

    def get_out(self, name: str, args_type: Type[ArgsModel[Out]]) -> Out:
        return self.get_step(name, args_type).out


def step(pipeline: PipelineBuilder, name: str, args_type: Type[ArgsModel[Out]]) -> ArgsModel:
    return pipeline.get_step(name, args_type)

def out(pipeline: PipelineBuilder, name: str, args_type: Type[ArgsModel[Out]]) -> Out:
    return pipeline.get_out(name, args_type)
