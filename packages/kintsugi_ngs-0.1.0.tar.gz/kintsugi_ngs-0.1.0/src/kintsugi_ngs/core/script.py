from abc import ABC, abstractmethod
from kintsugi_ngs.core.runner import Pipeline
from pathlib import Path
from importlib.machinery import ModuleSpec
from types import ModuleType
from typing import Type
import importlib
import importlib.util
from importlib.abc import Loader
import sys

# TODO: should add methods for loading a yaml config and initializing said config file
# This would probably need to be integrated down to the Commands and include some auxiliary
# information from the individual PipelineSteps (at least the name of the step).

class ScriptBase(ABC):

    @property
    @abstractmethod
    def _pipeline(self) -> Pipeline:
        pass

    def run(self):
        self._pipeline.run()

    def dump(self) -> str:
        return self._pipeline.dump()


def load_script(script: Path) -> ScriptBase:
    try:
        module_name = "script"
        # 1. Create a module specification (spec) from the file path
        spec: ModuleSpec|None = importlib.util.spec_from_file_location(module_name, script)
        # 2. Create a new module object based on that spec
        module: ModuleType
        if isinstance(spec, ModuleSpec):
            module = importlib.util.module_from_spec(spec)
            # 3. (Optional but Recommended) Add module to sys.modules
            # This allows the module to handle its own internal imports correctly
            sys.modules[module_name] = module
            # 4. Execute the module in its own namespace to populate it
            loader: Loader|None = spec.loader
            if isinstance(loader, Loader):
                loader.exec_module(module)
                # 5. Retrieve and return the class
                cls: Type[ScriptBase] = getattr(module, "Script")
                return cls()
            else:
                raise Exception("Module loader not found.")
        else:
            raise Exception("Module object failed to load.")
    except ModuleNotFoundError as e:
        print(f"Module {script} doesn't exist.")
        raise e
    except AttributeError as e:
        print(f"Function 'run' doesn't exist in {script}.")
        raise e
    except TypeError as e:
        print(f"Error: {e}")
        raise e
