from abc import ABC, abstractmethod
from typing_extensions import Dict
from pydantic import BaseModel, FilePath, DirectoryPath, computed_field
from jinja2 import Template
from typing import Literal, Any, TypeVar, Generic, List
from pathlib import Path
from kintsugi_ngs.core.util import utils
from kintsugi_ngs.core.decorator import DecoratorBase

# To specify that the text inputs may be nothing (an empty string).
FilePathOrNone = FilePath|Literal[""]
DirectoryPathOrNone = DirectoryPath|Literal["."]

# General inputs and outputs that we expect to gleam from a step.
# Given a UNIX environment, these will be files.
FileDict = Dict[str, FilePathOrNone]

# Class to define the outputs of the an ArgsModel invocation
class OutputModel(BaseModel, ABC):
    pass

Out = TypeVar("Out", bound = OutputModel)

# General base method to tell our models that they need to generate a string to execute
class ArgsModel(BaseModel, ABC, Generic[Out]):
    outdir: DirectoryPathOrNone = "."

    @property
    @abstractmethod
    def name(self) -> str:
        pass

    @property
    @abstractmethod
    def template(self) -> str:
        pass

    @property
    def data(self) -> Dict:
        return self.model_dump()

    @computed_field
    @property
    def inputs(self) -> FileDict:
        return ArgsModel.filter_inputs(self.flatten)

    @property
    @abstractmethod
    def outputs(self) -> FileDict:
        pass

    @property
    @abstractmethod
    def out(self) -> Out:
        pass

    @abstractmethod
    def validate_output(self) -> Out:
        pass

    def generate(self, decorators: List[DecoratorBase] = list()) -> str:
        template = Template(self.template)
        data = self.data
        template_str = template.render(**data)
        for decorator in decorators[::-1]:
            template_str = decorator.apply(template_str)
        return template_str

    @property
    def flatten(self) -> Dict[str, Any]:
        return utils.flatten_dict(self.data)

    @property
    def flatten_as_strings(self) -> Dict[str, str]:
        return utils.dict_as_strings(self.flatten)

    @staticmethod
    def filter_inputs(kvs: Dict[str, Any]) -> FileDict:
        return utils.filter_by_type(kvs, Path)

    def get_file_stem(self, file: FilePathOrNone) -> str:
        return str(Path(file).stem).split(".")[0]

Args = TypeVar("Args", bound = ArgsModel)
