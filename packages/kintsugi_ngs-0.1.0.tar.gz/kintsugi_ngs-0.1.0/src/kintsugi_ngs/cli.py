import typer
from pathlib import Path
from kintsugi_ngs.core.script import load_script
from rich.console import Console
from rich.syntax import Syntax

app = typer.Typer()

@app.command()
def run(script: Path):
    load_script(script).run()

@app.command()
def dump(script: Path, lang: str = "bash", theme: str = "monokai", line_numbers: bool = True):
    dump = load_script(script).dump()
    console = Console()
    syntax = Syntax(dump, lang, theme = theme, line_numbers = line_numbers)
    console.print(syntax)

# @app.command()
# def main(config: str, wd: str = "", dry: bool = False, clean: bool = False):
#     if wd != "":
#         os.chdir(wd)
#     with open(config, 'r') as f:
#         data = yaml.safe_load(f)
#     script = ""
#     fastqc = FastQCArgs.model_validate(data)
#     console.print(fastqc.flatten)
#     console.print(fastqc.inputs)
#     console.print(fastqc.outputs)
#     cutadapt = CutadaptArgs.model_construct(
#         files = (fastqc.outputs["data1"], fastqc.outputs["data2"]),
#         outdir = fastqc.outdir
#     )
#     script = fastqc.generate() + os.linesep + cutadapt.generate()

if __name__ == "__main__":
    app()
