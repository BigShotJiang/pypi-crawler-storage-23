from pydantic import model_validator, computed_field
from typing_extensions import final
from kintsugi_ngs.core.command import ArgsModel, OutputModel, FilePathOrNone, FileDict
from typing import Dict, Self
import os
from pathlib import Path

@final
class FastQCOut(OutputModel):
    report1: FilePathOrNone
    data1: FilePathOrNone
    report2: FilePathOrNone
    data2: FilePathOrNone

@final
class FastQCArgs(ArgsModel[FastQCOut]):
    files: tuple[FilePathOrNone, FilePathOrNone] = ("", "")
    threads: int = 1

    @property
    def name(self) -> str:
        return "fastqc"

    def validate_output(self) -> FastQCOut:
        out = self.outputs
        return FastQCOut(
            report1 = out["report1"],
            data1 = out["data1"],
            report2 = out["report2"],
            data2 = out["data2"]
        )


    @model_validator(mode = 'after')
    def validate_fastqc(self) -> Self:
        # TODO
        return self

    @computed_field
    @property
    def one_file(self) -> bool:
        return self.files[1] == ""

    @property
    def outputs(self) -> FileDict:
        stem1: str = str(self.outdir) + os.sep + self.get_file_stem(self.files[0])
        report1: str = stem1 + "_fastqc.html"
        data1: str = stem1 + "_fastqc.gz"
        report2: FilePathOrNone = ""
        data2: FilePathOrNone = ""
        if not self.one_file:
            stem2: str = str(self.outdir) + os.sep + self.get_file_stem(self.files[1])
            report2 = Path(stem2 + "_fastqc.html")
            data2 = Path(stem2 + "_fastqc.gz")
        return {
            "report1": Path(report1),
            "data1": Path(data1),
            "report2": report2,
            "data2": data2
        }

    @property
    def template(self) -> str:
        if self.one_file:
            return "fastqc {{file1}} -t {{threads}} --outdir={{outdir}}"
        return "fastqc {{file1}} -t {{threads}} --outdir={{outdir}}" + os.linesep + "fastqc {{file2}} -t {{threads}} --outdir={{outdir}}"

    @property
    def data(self) -> Dict:
        ret_dict: Dict = {
            "threads": self.threads,
            "outdir": self.outdir,
            "file1": self.files[0],
            "file2": self.files[1]
        }
        return ret_dict

    @property
    def out(self) -> FastQCOut:
        out = self.outputs
        return FastQCOut.model_construct(
           report1 = out["report1"],
           data1 = out["data1"],
           report2 = out["report2"],
           data2 = out["data2"]
        )
