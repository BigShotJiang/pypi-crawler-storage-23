from typing_extensions import final
from typing import Dict
from pydantic import computed_field
from kintsugi_ngs.core.command import ArgsModel, OutputModel, FilePathOrNone, FileDict
import os
from pathlib import Path

@final
class CutadaptOut(OutputModel):
    output1: FilePathOrNone
    output2: FilePathOrNone

@final
class CutadaptArgs(ArgsModel[CutadaptOut]):
    files: tuple[FilePathOrNone, FilePathOrNone] = ("", "")
    threads: int = 1
    minimum: int = 10
    quality: int = 20
    adapter: tuple[str, str] = ("", "")
    suffix: str = "trimmed"

    @property
    def name(self) -> str:
        return "cutadapt"

    @computed_field
    @property
    def one_file(self) -> bool:
        return self.files[1] == ""

    @computed_field
    @property
    def one_adapter(self) -> bool:
        return self.adapter[1] == ""

    def validate_output(self) -> CutadaptOut:
        out = self.outputs
        return CutadaptOut.model_construct(
            output1 = out["output1"],
            output2 = out["output2"]
        )

    @property
    def template(self) -> str:
        template: str = "cutadapt -j {{threads}} -m {{minimum}} "
        if self.one_file:
            template += "{{file1}} "
        else:
            template += "{{file1}} {{file2}} "
        if self.one_adapter:
            template += "-a {{adapter1}} "
        else:
            template += "-a {{adapter1}} -A {{adapter2}} "
        if self.one_file:
            template += "-o {{output}}"
        else:
            template += "-o {{output1}} -p {{output2}}"

        return template

    @property
    def data(self) -> Dict:
        outputs = self.outputs
        ret_dict: Dict = {
            "threads": self.threads,
            "minimum": self.minimum,
            "quality": self.quality,
            "file1": self.files[0],
            "file2": self.files[1],
            "output1": outputs["output1"],
            "output2": outputs["output2"],
            "adapter1": self.adapter[0],
            "adapter2": self.adapter[1]
        }

        return ret_dict

    @property
    def outputs(self) -> FileDict:
        stem1: str = str(self.outdir) + os.sep + self.get_file_stem(self.files[0])
        output1: str = stem1 + "_" + self.suffix + ".fastq.gz"
        output2: FilePathOrNone = ""
        if not self.one_file:
            stem2: str = str(self.outdir) + os.sep + self.get_file_stem(self.files[1])
            output2 = Path(stem2 + "_" + self.suffix + ".fastq.gz")
        return {
            "output1": Path(output1),
            "output2": output2
        }

    @property
    def out(self) -> CutadaptOut:
        out = self.outputs
        return CutadaptOut.model_construct(
            output1 = out["output1"],
            output2 = out["output2"]
        )
