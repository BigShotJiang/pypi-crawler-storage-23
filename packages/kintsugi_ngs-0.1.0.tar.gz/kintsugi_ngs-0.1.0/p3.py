from typing import final
from kintsugi_ngs.commands.fastqc import FastQCArgs
from kintsugi_ngs.commands.cutadapt import CutadaptArgs
from kintsugi_ngs.core.runner import PipelineBuilder, PipelineStep, Pipeline, out, step
from kintsugi_ngs.runner.bash import BashRunner
from kintsugi_ngs.core.script import ScriptBase
# import yaml
import os
from pathlib import Path

@final
class Script(ScriptBase):
    @property
    def _pipeline(self) -> Pipeline:
        runner: BashRunner = BashRunner(name = "bash")
        data_dir: str = "/x1/hugen2072-2026s/p3/"
        scratch_dir = os.environ["SLURM_SCRATCH"]
        home_dir = os.environ["SLURM_SUBMIT_DIR"]

        # toy data set
        fastq1: Path = Path(data_dir + "toy_1.fastq.gz")
        fastq2: Path = Path(data_dir + "toy_2.fastq.gz")
        reference: str = ""

        # production data
        fastq1: Path = Path(data_dir + "toy_1.fastq.gz")
        fastq2: Path = Path(data_dir + "toy_2.fastq.gz")
        reference: str = ""

        return (
            PipelineBuilder()
                .add_step(
                    name = "pre-cut qc",
                    step = lambda pipeline: (
                        PipelineStep(
                            command = FastQCArgs.model_construct(
                                files = (fastq1, fastq2)
                            ),
                            runner = runner
                        )
                    )
                )
                .add_step(
                    name = "trim adapters",
                    step = lambda pipeline: (
                        PipelineStep(
                            command = CutadaptArgs.model_construct(
                                files = (
                                    out(pipeline, "pre-cut qc", FastQCArgs).data1,
                                    out(pipeline, "pre-cut qc", FastQCArgs).data2
                                ),
                                adapter = ("AGATCGGAAGAG", "AGATCGGAAGAG"),
                                outdir = step(pipeline, "pre-cut qc", FastQCArgs).outdir
                            ),
                            runner = runner
                        )
                    )
                )
                .add_step(
                    name = "post-cut qc",
                    step = lambda pipeline: (
                        PipelineStep(
                            command = FastQCArgs.model_construct(
                                files = (
                                    out(pipeline, "trim adapters", CutadaptArgs).output1,
                                    out(pipeline, "trim adapters", CutadaptArgs).output2
                                )
                            ),
                            runner = runner
                        )
                    )
                )
                .build()
            )
