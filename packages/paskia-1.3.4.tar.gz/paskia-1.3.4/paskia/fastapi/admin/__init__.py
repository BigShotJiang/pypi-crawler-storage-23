from paskia.fastapi.admin.adminapp import app

__all__ = ["app"]
