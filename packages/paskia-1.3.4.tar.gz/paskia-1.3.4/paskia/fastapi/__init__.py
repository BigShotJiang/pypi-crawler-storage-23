from paskia.fastapi.mainapp import app

__all__ = ["app"]
