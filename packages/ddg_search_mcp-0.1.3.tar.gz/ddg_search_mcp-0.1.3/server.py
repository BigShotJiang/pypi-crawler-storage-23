"""
LLM-optimized web search MCP server.

Design principles:
- Content is cleaned, deduplicated, and truncated to maximize signal/token ratio
- Metadata is structured so the LLM can cite sources precisely
- Parallel fetching with aggressive timeouts keeps latency low
- Noise (nav, ads, boilerplate, JS, CSS) is stripped before returning
- Results are ranked: pages with extractable content come before snippet-only fallbacks
"""

import asyncio
import hashlib
import re
import unicodedata
from urllib.parse import urlparse

import httpx
import trafilatura
from bs4 import BeautifulSoup
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("web-search")

# ── Constants ────────────────────────────────────────────────────────────────

DDG_HTML_URL = "https://html.duckduckgo.com/html/"
DDG_LITE_URL = "https://lite.duckduckgo.com/lite/"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/122.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
}

MAX_CONTENT_CHARS = 6000   # per page — sweet spot for GPT/Claude context efficiency
MAX_SNIPPET_CHARS = 400    # fallback snippet limit
PAGE_FETCH_TIMEOUT = 8.0   # seconds — drop slow pages fast
SEARCH_TIMEOUT = 12.0
MAX_RESULTS_CAP = 10

# Domains that reliably block bots or return useless content — skip fetching them
SKIP_FETCH_DOMAINS = {
    "youtube.com", "youtu.be", "twitter.com", "x.com", "instagram.com",
    "facebook.com", "linkedin.com", "tiktok.com", "reddit.com",
    "jstor.org", "researchgate.net", "academia.edu",
}

# ── Text utilities ───────────────────────────────────────────────────────────

def _normalize(text: str) -> str:
    """Unicode-normalize and collapse whitespace."""
    text = unicodedata.normalize("NFKC", text)
    text = re.sub(r"\s{3,}", "\n\n", text)
    text = re.sub(r" {2,}", " ", text)
    return text.strip()


def _dedupe_lines(text: str) -> str:
    """Remove duplicate or near-duplicate lines (catches boilerplate repetition)."""
    seen: set[str] = set()
    out: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            out.append("")
            continue
        # Hash normalized lowercase version for fuzzy dedup
        key = hashlib.md5(re.sub(r"\W+", "", stripped.lower()).encode()).hexdigest()
        if key not in seen:
            seen.add(key)
            out.append(line)
    return "\n".join(out)


def _clean_content(raw: str) -> str:
    """Full cleaning pipeline: normalize → dedupe → trim."""
    text = _normalize(raw)
    text = _dedupe_lines(text)
    # Strip lines that are clearly navigation/UI artifacts
    lines = [
        l for l in text.splitlines()
        if not re.match(
            r"^\s*(share|tweet|follow us|subscribe|sign up|log in|cookie|privacy policy"
            r"|terms of service|all rights reserved|©|\d+ comments?)\s*$",
            l, re.IGNORECASE
        )
    ]
    return "\n".join(lines).strip()


def _domain(url: str) -> str:
    try:
        return urlparse(url).netloc.removeprefix("www.")
    except Exception:
        return url


def _should_skip_fetch(url: str) -> bool:
    d = _domain(url)
    return any(d == skip or d.endswith("." + skip) for skip in SKIP_FETCH_DOMAINS)


# ── Page fetcher ─────────────────────────────────────────────────────────────

async def _fetch_page(client: httpx.AsyncClient, url: str) -> tuple[str, bool]:
    """
    Returns (content, is_full_extract).
    is_full_extract=True means we got real article text; False means empty/failed.
    """
    if _should_skip_fetch(url):
        return "", False

    try:
        resp = await client.get(
            url,
            timeout=PAGE_FETCH_TIMEOUT,
            follow_redirects=True,
            headers=HEADERS,
        )
        if resp.status_code != 200:
            return "", False

        ct = resp.headers.get("content-type", "")
        if "text/html" not in ct:
            return "", False

        # trafilatura: best-in-class boilerplate removal
        extracted = trafilatura.extract(
            resp.text,
            include_comments=False,
            include_tables=True,
            no_fallback=False,
            favor_precision=True,   # prefer precision over recall — less noise
        )

        if not extracted or len(extracted.strip()) < 100:
            return "", False

        cleaned = _clean_content(extracted)
        return cleaned[:MAX_CONTENT_CHARS], True

    except (httpx.TimeoutException, httpx.ConnectError):
        return "", False
    except Exception:
        return "", False


# ── DuckDuckGo search ────────────────────────────────────────────────────────

async def _ddg_search(client: httpx.AsyncClient, query: str, num: int) -> list[dict]:
    """
    Scrape DuckDuckGo. Uses lite as primary (more bot-friendly),
    falls back to html endpoint if lite fails.
    Returns list of {title, url, snippet}.
    """
    for endpoint, parser in [
        (DDG_LITE_URL, _parse_lite),
        (DDG_HTML_URL, _parse_html),
    ]:
        try:
            resp = await client.post(
                endpoint,
                data={"q": query, "kl": "us-en"},
                headers=HEADERS,
                timeout=SEARCH_TIMEOUT,
            )
            if resp.status_code not in (200, 202):
                continue

            results = parser(resp.text, num)
            if results:
                return results

        except Exception:
            continue

    return []


def _parse_lite(html: str, num: int) -> list[dict]:
    """Parse DuckDuckGo lite results page."""
    soup = BeautifulSoup(html, "html.parser")
    results = []

    # Lite layout: result rows are <tr> with a <a> link and a snippet td
    for row in soup.select("tr"):
        a = row.select_one("a[href]")
        if not a:
            continue
        href = a.get("href", "")
        if not href.startswith("http") or "duckduckgo.com" in href:
            continue

        title = a.get_text(strip=True)
        snippet_td = row.find_next_sibling("tr")
        snippet = ""
        if snippet_td:
            snippet = snippet_td.get_text(strip=True)[:MAX_SNIPPET_CHARS]

        results.append({"title": title, "url": href, "snippet": snippet})
        if len(results) >= num:
            break

    return results


def _parse_html(html: str, num: int) -> list[dict]:
    """Parse DuckDuckGo HTML results page."""
    soup = BeautifulSoup(html, "html.parser")
    results = []

    links = soup.select("a.result__a")
    snippets = soup.select(".result__snippet")

    for i, a in enumerate(links):
        href = a.get("href", "")
        if not href.startswith("http") or "duckduckgo.com" in href:
            continue

        title = a.get_text(strip=True)
        snippet = snippets[i].get_text(strip=True)[:MAX_SNIPPET_CHARS] if i < len(snippets) else ""

        results.append({"title": title, "url": href, "snippet": snippet})
        if len(results) >= num:
            break

    return results


# ── MCP Tool ─────────────────────────────────────────────────────────────────

@mcp.tool()
async def web_search(query: str, num_results: int = 5) -> str:
    """Search the web and return clean, LLM-ready content from each result.

    Performs a DuckDuckGo search, then concurrently fetches and extracts the
    main content from each result page — stripping ads, nav, and boilerplate.
    Results are formatted for direct use in LLM reasoning and citation.

    Pages that cannot be fetched fall back to the search snippet.
    Results are sorted: full extracts first, snippet-only fallbacks last.

    Args:
        query: Natural language search query
        num_results: Number of results to return (1-10, default 5)
    """
    num_results = max(1, min(MAX_RESULTS_CAP, num_results))

    async with httpx.AsyncClient(headers=HEADERS) as client:
        # 1. Get search results
        results = await _ddg_search(client, query, num_results)

        if not results:
            return "No results found. DuckDuckGo may be temporarily unavailable."

        # 2. Fetch all pages concurrently
        fetch_tasks = [_fetch_page(client, r["url"]) for r in results]
        page_data = await asyncio.gather(*fetch_tasks)

    # 3. Assemble output — full extracts first, then snippet fallbacks
    full_results = []
    fallback_results = []

    for result, (content, is_full) in zip(results, page_data):
        title   = result["title"]
        url     = result["url"]
        domain  = _domain(url)
        snippet = result["snippet"]

        if is_full:
            entry = (
                f"### [{title}]({url})\n"
                f"**Source:** {domain}\n\n"
                f"{content}"
            )
            full_results.append(entry)
        else:
            body = snippet if snippet else "_Page content unavailable._"
            entry = (
                f"### [{title}]({url})\n"
                f"**Source:** {domain} _(snippet only)_\n\n"
                f"{body}"
            )
            fallback_results.append(entry)

    ordered = full_results + fallback_results

    header = (
        f"## Search Results for: `{query}`\n"
        f"{len(full_results)} full extracts · "
        f"{len(fallback_results)} snippet-only · "
        f"{len(ordered)} total\n\n"
    )

    return header + "\n\n---\n\n".join(ordered)


if __name__ == "__main__":
    mcp.run(transport="stdio")