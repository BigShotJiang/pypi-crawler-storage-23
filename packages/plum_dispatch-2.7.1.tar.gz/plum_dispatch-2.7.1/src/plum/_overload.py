__all__ = ["overload", "get_overloads"]

from typing_extensions import get_overloads, overload
