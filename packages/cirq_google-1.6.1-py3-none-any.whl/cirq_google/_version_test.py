# pylint: disable=wrong-or-nonexistent-copyright-notice
import cirq_google


def test_version():
    assert cirq_google.__version__ == "1.6.1"
