from .modified_checker import find_differences as find
from pathlib import Path
import argparse
parser = argparse.ArgumentParser(description="tool to check for modifications")
parser.add_argument("folder", help="Name of folder to scan.")
parser.add_argument("-e","--exclude", nargs="+", required= False, default=[], help = "file suffixes to exclude (seperate by spaces)")
args=parser.parse_args()
folder = Path(args.folder)
new, deleted, modified = find(folder)
def return_values():
    for change_type in [new, deleted, modified]:
        for change in change_type.copy():
            print(change, change.name)
            if change.suffix in args.exclude:
                change_type.remove(change)
    print(f"\033[31mDeleted Files: {[file.name for file in deleted]}\033[0m")
    print(f"\033[32mAdded Files: {[file.name for file in new]}\033[0m")
    print(f"\033[33mModified Files: {[file.name for file in modified]}\033[0m")