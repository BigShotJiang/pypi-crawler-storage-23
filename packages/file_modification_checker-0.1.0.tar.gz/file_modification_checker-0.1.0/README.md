# Modification Checking Tool

## 0.1.0

### Installing and Importing
> **Installing**
Use:
```bash
pip install file_modfication_checker
```
>**Importing**
Use:
```python
import file_modfication_checker
```
### Command Usage
> **How To Use**
Usage:
```bash
mcheck <folder> [OPTIONS]
```
Arguments:
<folder>           Name of folder to check

Options:
-e, --exclude.     File types to ignore

> **Result**
- Red Text: files that were deleted
- Green Text: files that were added
- Yellow Text: files that were modified