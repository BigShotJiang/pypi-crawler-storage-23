import logging
import mimetypes
import os
from io import BytesIO
from pathlib import Path
from typing import Any, cast
from urllib.parse import quote

import httpx
import mammoth
from arcade_mcp_server import Context
from arcade_mcp_server.exceptions import ToolExecutionError
from docx import Document
from markdownify import markdownify
from msgraph.generated.models.drive_item import DriveItem

from arcade_microsoft_utils.client import get_client
from arcade_microsoft_utils.drive_utils import (
    _ensure_download_size_under_limit as _ensure_download_size_under_limit_generic,
)
from arcade_microsoft_utils.exceptions import (
    ConflictError,
    ConversionError,
    DocumentLockedError,
    SizeLimitExceededError,
    UnsupportedFileTypeError,
)

logger = logging.getLogger(__name__)

DOCX_MIME_TYPE = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
MAX_UPLOAD_BYTES = 4 * 1024 * 1024
_DEFAULT_MAX_DOWNLOAD_MB = 20
GRAPH_BASE_URL_DEFAULT = "https://graph.microsoft.com/v1.0"
_ALLOWED_CONFLICT_BEHAVIORS = {"fail", "rename", "replace"}


def _get_graph_base_url() -> str:
    base_url = os.getenv("ARCADE_MICROSOFT_GRAPH_BASE_URL", GRAPH_BASE_URL_DEFAULT)
    return base_url.rstrip("/")


def _normalize_docx_title(title: str) -> str:
    normalized = title.strip()
    if not normalized:
        raise ToolExecutionError("Title is required.")

    while normalized.lower().endswith(".docx"):
        normalized = normalized[:-5].strip()

    if not normalized:
        raise ToolExecutionError("Title is required.")

    return f"{normalized}.docx"


def _normalize_conflict_behavior(conflict_behavior: str | None) -> str | None:
    if conflict_behavior is None:
        return None
    normalized = conflict_behavior.strip().lower()
    if not normalized or normalized not in _ALLOWED_CONFLICT_BEHAVIORS:
        raise ToolExecutionError("conflict_behavior must be one of: fail, rename, replace.")
    return normalized


def _require_non_empty(value: str, label: str) -> str:
    normalized = value.strip()
    if not normalized:
        raise ToolExecutionError(f"{label} is required.")
    return normalized


def _ensure_text_content(value: str) -> None:
    if not value or not value.strip():
        raise ToolExecutionError("Text content is required.")


def _is_docx_drive_item(item: DriveItem) -> bool:
    if item.file and item.file.mime_type:
        return item.file.mime_type == DOCX_MIME_TYPE
    if item.name:
        return item.name.lower().endswith(".docx")
    return False


def _describe_drive_item_file_type(item: DriveItem) -> str:
    mime_type = None
    if item.file and item.file.mime_type:
        mime_type = item.file.mime_type
        extension = mimetypes.guess_extension(mime_type)
        if extension:
            return extension
        return mime_type

    if item.name:
        suffix = Path(item.name).suffix
        if suffix:
            return suffix.lower()

    return mime_type or "unknown"


def _ensure_docx_drive_item(item: DriveItem) -> None:
    if not _is_docx_drive_item(item):
        raise UnsupportedFileTypeError(_describe_drive_item_file_type(item))


def _ensure_download_size_under_limit(item: DriveItem) -> None:
    """Check the drive item's reported size against the Word download limit.

    Configurable via ARCADE_DOCX_MAX_DOWNLOAD_MB (default: 20 MB).
    """
    _ensure_download_size_under_limit_generic(
        item, env_var="ARCADE_DOCX_MAX_DOWNLOAD_MB", default_mb=_DEFAULT_MAX_DOWNLOAD_MB
    )


def _ensure_payload_under_limit(payload: bytes) -> None:
    """Ensure payload is below the 4MB simple upload limit."""
    if len(payload) >= MAX_UPLOAD_BYTES:
        raise SizeLimitExceededError()


def _format_author(display_name: str | None) -> str:
    """Format the author string for document metadata."""
    if display_name:
        return f"{display_name} (using Arcade.dev)"
    return "Arcade.dev"


def _build_docx_bytes(text_content: str | None = None, author_name: str | None = None) -> bytes:
    document = Document()
    author = _format_author(author_name)
    document.core_properties.author = author
    document.core_properties.last_modified_by = author
    if text_content:
        for line in text_content.splitlines():
            document.add_paragraph(line)
    buffer = BytesIO()
    document.save(buffer)
    return buffer.getvalue()


def _append_text_to_docx(
    doc_bytes: bytes, text_content: str, author_name: str | None = None
) -> bytes:
    document = Document(BytesIO(doc_bytes))
    document.core_properties.last_modified_by = _format_author(author_name)
    for line in text_content.splitlines():
        document.add_paragraph(line)
    buffer = BytesIO()
    document.save(buffer)
    return buffer.getvalue()


def _extract_docx_text(doc_bytes: bytes) -> str:
    document = Document(BytesIO(doc_bytes))
    return "\n".join(paragraph.text for paragraph in document.paragraphs)


def _convert_docx_bytes(doc_bytes: bytes) -> tuple[str, str]:
    try:
        result = mammoth.convert_to_html(BytesIO(doc_bytes))
        html = result.value
        return markdownify(html), "markdown"
    except Exception:
        try:
            return _extract_docx_text(doc_bytes), "text"
        except Exception as exc:
            raise ConversionError() from exc


def _build_drive_base_url(drive_id: str | None) -> str:
    base_url = _get_graph_base_url()
    if drive_id:
        return f"{base_url}/drives/{drive_id}"
    return f"{base_url}/me/drive"


async def _get_user_display_name(context: Context) -> str | None:
    """Fetch the current user's display name from Microsoft Graph."""
    try:
        client = get_client(context.get_auth_token_or_empty())
        user = await client.me.get()
        if user and user.display_name:
            return cast(str, user.display_name)
    except Exception:
        logger.debug("Failed to fetch user display name", exc_info=True)
    return None


async def _get_drive_item(context: Context, item_id: str, drive_id: str | None = None) -> DriveItem:
    client = get_client(context.get_auth_token_or_empty())
    if not drive_id:
        drive = await client.me.drive.get()
        if not drive or not drive.id:
            raise ToolExecutionError("Drive not found for the current user.")
        drive_id = cast(str, drive.id)

    response = await client.drives.by_drive_id(drive_id).items.by_drive_item_id(item_id).get()
    if not response:
        raise ToolExecutionError("Drive or document not found. Verify the item_id and drive_id.")
    return cast(DriveItem, response)


def _build_item_url(item_id: str, drive_id: str | None = None) -> str:
    return f"{_build_drive_base_url(drive_id)}/items/{item_id}"


def _build_upload_url(
    title: str,
    folder_id: str | None,
    drive_id: str | None = None,
    conflict_behavior: str | None = None,
) -> str:
    encoded_title = quote(title)
    base_url = _build_drive_base_url(drive_id)
    if folder_id:
        url = f"{base_url}/items/{folder_id}:/{encoded_title}:/content"
    else:
        url = f"{base_url}/root:/{encoded_title}:/content"

    normalized_conflict_behavior = _normalize_conflict_behavior(conflict_behavior)
    if normalized_conflict_behavior:
        encoded_behavior = quote(normalized_conflict_behavior, safe="")
        url = f"{url}?@microsoft.graph.conflictBehavior={encoded_behavior}"

    return url


async def _download_drive_item_content(
    context: Context, item_id: str, drive_id: str | None = None
) -> bytes:
    # The Graph SDK doesn't expose streaming /content responses cleanly, so we use raw HTTP here.
    url = f"{_build_item_url(item_id, drive_id)}/content"
    async with httpx.AsyncClient(follow_redirects=True) as http_client:
        response = await http_client.get(
            url,
            headers={
                "Authorization": f"Bearer {context.get_auth_token_or_empty()}",
            },
        )
        response.raise_for_status()
    return response.content


async def _upload_drive_item_content(
    context: Context, url: str, payload: bytes, etag: str | None = None
) -> dict[str, Any]:
    # The Graph SDK doesn't support simple byte uploads to /content endpoints, so use raw HTTP.
    headers = {
        "Authorization": f"Bearer {context.get_auth_token_or_empty()}",
        "Content-Type": DOCX_MIME_TYPE,
    }
    if etag:
        headers["If-Match"] = etag

    async with httpx.AsyncClient() as http_client:
        response = await http_client.put(
            url,
            headers=headers,
            content=payload,
        )
        if response.status_code == 423:
            raise DocumentLockedError()
        if response.status_code == 412:
            raise ConflictError()
        response.raise_for_status()
    return cast(dict[str, Any], response.json())
