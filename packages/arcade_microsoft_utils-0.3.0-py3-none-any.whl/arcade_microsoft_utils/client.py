import datetime
from typing import Any

from azure.core.credentials import AccessToken, TokenCredential
from msgraph import GraphServiceClient

DEFAULT_SCOPE = "https://graph.microsoft.com/.default"


class StaticTokenCredential(TokenCredential):
    """Implementation of TokenCredential protocol to be provided to the MSGraph SDK client."""

    def __init__(self, token: str):
        self._token = token

    def get_token(self, *scopes: str, **kwargs: Any) -> AccessToken:
        # The MS Graph SDK requires an expiry.  We hardcode 1 hour because
        # this credential is only used within a single tool invocation — the
        # Arcade Engine validates and refreshes the OAuth token before each
        # call, so the token will never actually be held this long.
        expires_on = int(datetime.datetime.now(datetime.timezone.utc).timestamp()) + 3600
        return AccessToken(self._token, expires_on)


def get_client(token: str) -> GraphServiceClient:
    """Create and return a MSGraph SDK client, given the provided token."""
    token_credential = StaticTokenCredential(token)

    return GraphServiceClient(token_credential, scopes=[DEFAULT_SCOPE])
