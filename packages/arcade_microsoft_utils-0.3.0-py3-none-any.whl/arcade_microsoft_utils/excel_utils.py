"""Excel utilities for Microsoft toolkits.

Provides helpers for:
- Sparse dict parsing and validation (same format as Google Sheets)
- Column letter/index conversion
- Range address computation
- Contiguous range patch splitting (avoids data loss on update)
- XLSX file creation with openpyxl
- Worksheet name-to-ID resolution
- Graph API batch request execution
"""

import json
import logging
import os
from collections.abc import Awaitable
from dataclasses import dataclass
from io import BytesIO
from typing import Any, Callable, TypeVar

import httpx
from msgraph import GraphServiceClient
from openpyxl import Workbook

from arcade_microsoft_utils.exceptions import (
    DocumentLockedError,
    FileAlreadyExistsError,
    MicrosoftToolExecutionError,
    SizeLimitExceededError,
    WorksheetNotFoundError,
)

# Type alias for the sparse dict format (same as Google Sheets)
# {row_number: {column_letter: value}}
SheetData = dict[int, dict[str, Any]]

XLSX_MIME_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
MAX_UPLOAD_BYTES = 4 * 1024 * 1024
GRAPH_BASE_URL_DEFAULT = "https://graph.microsoft.com/v1.0"
MAX_BATCH_REQUESTS = 20
MAX_BOUNDING_BOX_CELLS = 500_000  # Safety cap for single-PATCH bounding box

# HTTP timeout defaults (seconds) — tuned per operation type
DEFAULT_TIMEOUT = 30.0  # Metadata GETs, worksheet ops, single-cell updates
BATCH_TIMEOUT = 60.0  # Batch requests (multiple sub-requests)
UPLOAD_TIMEOUT = 120.0  # File uploads (network-dependent)


def _get_graph_base_url() -> str:
    """Get the Graph API base URL (supports override via env var for testing)."""
    base_url = os.getenv("ARCADE_MICROSOFT_GRAPH_BASE_URL", GRAPH_BASE_URL_DEFAULT)
    return base_url.rstrip("/")


# ---------------------------------------------------------------------------
# Filename helpers
# ---------------------------------------------------------------------------


def _normalize_xlsx_filename(filename: str) -> str:
    """Normalize filename to ensure .xlsx extension."""
    filename = filename.strip()
    if not filename:
        raise MicrosoftToolExecutionError("Filename cannot be empty.")
    if not filename.lower().endswith(".xlsx"):
        filename = f"{filename}.xlsx"
    return filename


# ---------------------------------------------------------------------------
# Column letter <-> index conversion
# ---------------------------------------------------------------------------


def _col_letter_to_index(col: str) -> int:
    """Convert column letter(s) to 1-based index (A=1, B=2, ..., Z=26, AA=27)."""
    col = col.upper()
    result = 0
    for char in col:
        result = result * 26 + (ord(char) - ord("A") + 1)
    return result


def _col_index_to_letter(idx: int) -> str:
    """Convert 1-based index to column letter(s) (1=A, 2=B, ..., 26=Z, 27=AA)."""
    result: list[str] = []
    while idx > 0:
        idx, remainder = divmod(idx - 1, 26)
        result.append(chr(ord("A") + remainder))
    return "".join(reversed(result))


# ---------------------------------------------------------------------------
# Cell address helpers
# ---------------------------------------------------------------------------


def _cell_address(column: str, row: int) -> str:
    """Build cell address from column letter(s) and row number."""
    column = column.strip().upper()
    if not column.isalpha():
        raise MicrosoftToolExecutionError(
            f"Invalid column '{column}'. Column must be letters only (e.g., 'A', 'BC')."
        )
    if row < 1:
        raise MicrosoftToolExecutionError(f"Invalid row {row}. Row must be a positive integer.")
    return f"{column}{row}"


def _compute_range_address(start_col: str, start_row: int, max_cols: int, max_rows: int) -> str:
    """Compute an Excel range address from start position and dimensions.

    Args:
        start_col: Starting column letter (e.g., 'A').
        start_row: Starting row number (1-indexed).
        max_cols: Number of columns to include.
        max_rows: Number of rows to include.

    Returns:
        Range address string (e.g., 'A1:CV1000').
    """
    start_col_idx = _col_letter_to_index(start_col)
    end_col_idx = start_col_idx + max_cols - 1
    end_row = start_row + max_rows - 1
    end_col = _col_index_to_letter(end_col_idx)
    return f"{start_col}{start_row}:{end_col}{end_row}"


def _parse_range_address(address: str) -> tuple[str, int, str, int]:
    """Parse a range address like 'Sheet1!A1:D10' or 'A1:D10' into components.

    Returns:
        Tuple of (start_col, start_row, end_col, end_row).
    """
    # Strip sheet name prefix if present
    if "!" in address:
        address = address.split("!")[1]

    if ":" in address:
        start_part, end_part = address.split(":")
    else:
        start_part = address
        end_part = address

    start_col, start_row = _split_cell_ref(start_part)
    end_col, end_row = _split_cell_ref(end_part)
    return start_col, start_row, end_col, end_row


def _split_cell_ref(cell_ref: str) -> tuple[str, int]:
    """Split a cell reference like 'A1' into column letters and row number.

    Handles absolute references (e.g., '$A$1') by stripping '$' first.
    """
    cell_ref = cell_ref.replace("$", "")
    col = ""
    row_str = ""
    for char in cell_ref:
        if char.isalpha():
            col += char
        else:
            row_str += char
    if not col or not row_str:
        raise MicrosoftToolExecutionError(f"Invalid cell reference: '{cell_ref}'")
    return col.upper(), int(row_str)


# ---------------------------------------------------------------------------
# Sparse dict parsing and validation
# ---------------------------------------------------------------------------


def _parse_sparse_dict(json_str: str) -> SheetData:
    """Parse a JSON string into sparse dict format.

    Expected format (same as Google Sheets):
        {"1": {"A": "Name", "B": "Age"}, "2": {"A": "Alice", "B": 30}}

    Returns:
        Dict mapping row numbers (int) to column dicts.
    """
    try:
        data = json.loads(json_str)
    except json.JSONDecodeError as e:
        raise MicrosoftToolExecutionError(f"Invalid JSON data: {e}")

    if not isinstance(data, dict):
        raise MicrosoftToolExecutionError(
            "Data must be a dictionary mapping row numbers to column values. "
            'Expected format: {"1": {"A": "value", "B": 123}, "2": {...}}'
        )

    result: SheetData = {}
    for row_key, columns in data.items():
        try:
            row_num = int(row_key)
        except ValueError:
            raise MicrosoftToolExecutionError(
                f"Invalid row key '{row_key}'. Row keys must be numeric strings (e.g., '1', '23')."
            )

        if row_num < 1:
            raise MicrosoftToolExecutionError(
                f"Invalid row number {row_num}. Rows must be positive integers."
            )

        if not isinstance(columns, dict):
            raise MicrosoftToolExecutionError(
                f"Row {row_num} must map to a dictionary of column values."
            )

        validated_cols: dict[str, Any] = {}
        for col_key, value in columns.items():
            col_letter = col_key.strip().upper()
            if not col_letter.isalpha():
                raise MicrosoftToolExecutionError(
                    f"Invalid column key '{col_key}'. Column keys must be letters (e.g., 'A', 'BC')."
                )
            validated_cols[col_letter] = value

        result[row_num] = validated_cols

    return result


# ---------------------------------------------------------------------------
# Contiguous range grouping for sparse updates
# ---------------------------------------------------------------------------


def _group_contiguous(indices: list[int]) -> list[list[int]]:
    """Group a sorted list of integers into contiguous sublists.

    Example: [1, 2, 3, 7, 8] -> [[1, 2, 3], [7, 8]]
    """
    if not indices:
        return []
    groups: list[list[int]] = [[indices[0]]]
    for i in range(1, len(indices)):
        if indices[i] == indices[i - 1] + 1:
            groups[-1].append(indices[i])
        else:
            groups.append([indices[i]])
    return groups


@dataclass
class RangePatch:
    """A contiguous range PATCH payload for the MS Graph API."""

    address: str  # e.g., "A1:C3"
    formulas: list[list[Any]]  # Dense 2D array for this contiguous block


def _sparse_dict_to_range_patches(
    data: SheetData,
) -> list[RangePatch]:
    """Convert sparse dict format to minimal contiguous range patches.

    Splits the data into minimal contiguous blocks — the same strategy
    Google Sheets uses in SheetDataInputToValueRangesConverter.

    Algorithm:
        1. For each row, group specified columns into contiguous segments
        2. Group rows with matching column segments into contiguous row blocks
        3. Emit a RangePatch for each contiguous block

    Returns:
        List of RangePatch objects, each covering a minimal contiguous range.
    """
    if not data:
        return []

    # Map (start_col_idx, end_col_idx) -> { row_num: [values across columns] }
    segment_to_rows: dict[tuple[int, int], dict[int, list[Any]]] = {}

    for row_num in sorted(data.keys()):
        cols_dict = data[row_num]
        col_indices = sorted(_col_letter_to_index(col) for col in cols_dict)
        if not col_indices:
            continue

        contiguous_col_groups = _group_contiguous(col_indices)
        for group in contiguous_col_groups:
            start_idx = group[0]
            end_idx = group[-1]
            row_values = [cols_dict.get(_col_index_to_letter(ci)) for ci in group]
            key = (start_idx, end_idx)
            if key not in segment_to_rows:
                segment_to_rows[key] = {}
            segment_to_rows[key][row_num] = row_values

    patches: list[RangePatch] = []
    for (start_col_idx, end_col_idx), rows_map in segment_to_rows.items():
        sorted_rows = sorted(rows_map.keys())
        row_groups = _group_contiguous(sorted_rows)
        for rg in row_groups:
            start_row = rg[0]
            end_row = rg[-1]
            start_col = _col_index_to_letter(start_col_idx)
            end_col = _col_index_to_letter(end_col_idx)
            address = f"{start_col}{start_row}:{end_col}{end_row}"
            formulas = [rows_map[r] for r in rg]
            patches.append(RangePatch(address=address, formulas=formulas))

    return patches


def _sparse_dict_to_bounding_box_patch(data: SheetData) -> RangePatch:
    """Convert sparse dict to a single bounding-box RangePatch.

    Builds a 2D formulas array covering the bounding box of all specified
    cells.  Unspecified cells within the box are set to ``None`` (JSON
    ``null``), which instructs the Graph API to leave them unchanged.

    Per the Microsoft Graph "Update range" docs:
        "The ``null`` input is to instruct the API to ignore the cell
         for that particular input."
    See: https://learn.microsoft.com/en-us/graph/api/range-update

    This approach sends a **single PATCH** request regardless of how many
    non-contiguous regions the sparse dict contains, eliminating the
    partial-batch-failure problem that exists when updates are split
    across multiple batch requests.

    Args:
        data: Parsed sparse dict ``{row_number: {column_letter: value}}``.
              Must be non-empty.

    Returns:
        A single RangePatch covering the entire bounding box.

    Raises:
        MicrosoftToolExecutionError: If there are no actual cell values
            (all rows have empty column dicts) or the bounding box
            exceeds ``MAX_BOUNDING_BOX_CELLS``.
    """
    # Collect all column indices across all rows
    all_col_indices: set[int] = set()
    for cols in data.values():
        for col_letter in cols:
            all_col_indices.add(_col_letter_to_index(col_letter))

    if not all_col_indices:
        raise MicrosoftToolExecutionError("No valid cells found in the data.")

    # Compute bounding box (only rows that have actual cell values)
    populated_rows = sorted(r for r, cols in data.items() if cols)
    min_row = populated_rows[0]
    max_row = populated_rows[-1]

    min_col_idx = min(all_col_indices)
    max_col_idx = max(all_col_indices)

    num_rows = max_row - min_row + 1
    num_cols = max_col_idx - min_col_idx + 1
    box_size = num_rows * num_cols
    if box_size > MAX_BOUNDING_BOX_CELLS:
        raise MicrosoftToolExecutionError(
            f"Update bounding box too large ({num_rows} rows x {num_cols} cols "
            f"= {box_size:,} cells, limit is {MAX_BOUNDING_BOX_CELLS:,}). "
            f"Split the update into smaller regions."
        )

    # Build 2D formulas array: real values at specified positions, None elsewhere
    formulas: list[list[Any]] = []
    for row in range(min_row, max_row + 1):
        row_data = data.get(row, {})
        row_values: list[Any] = []
        for col_idx in range(min_col_idx, max_col_idx + 1):
            col_letter = _col_index_to_letter(col_idx)
            if col_letter in row_data:
                row_values.append(row_data[col_letter])
            else:
                row_values.append(None)  # null = skip this cell
        formulas.append(row_values)

    start_col = _col_index_to_letter(min_col_idx)
    end_col = _col_index_to_letter(max_col_idx)
    address = f"{start_col}{min_row}:{end_col}{max_row}"

    return RangePatch(address=address, formulas=formulas)


# ---------------------------------------------------------------------------
# XLSX file creation
# ---------------------------------------------------------------------------


def _build_xlsx_bytes(initial_data: str | None = None) -> bytes:
    """Create a new Excel workbook as bytes.

    Args:
        initial_data: Optional JSON string in sparse dict format.

    Returns:
        Bytes of the .xlsx file.
    """
    wb = Workbook()
    ws = wb.active

    if initial_data:
        data = _parse_sparse_dict(initial_data)
        for row_num, columns in data.items():
            for col_letter, value in columns.items():
                col_idx = _col_letter_to_index(col_letter)
                ws.cell(row=row_num, column=col_idx, value=value)

    buffer = BytesIO()
    try:
        wb.save(buffer)
        return buffer.getvalue()
    finally:
        buffer.close()


def _ensure_xlsx_payload_under_limit(payload: bytes, limit_mb: int = 4) -> None:
    """Raise SizeLimitExceededError if payload exceeds limit."""
    if len(payload) > limit_mb * 1024 * 1024:
        raise SizeLimitExceededError()


# ---------------------------------------------------------------------------
# Drive ID resolution
# ---------------------------------------------------------------------------


async def _get_user_drive_id(client: GraphServiceClient) -> str:
    """Get the current user's default drive ID.

    The msgraph SDK's ``client.me.drive`` builder does not expose ``.items``,
    so SDK calls that need to access drive items must go through
    ``client.drives.by_drive_id(drive_id).items...``.  This helper fetches
    the drive ID with a single GET to ``/me/drive``.

    Returns:
        The drive ID string.
    """
    drive = await client.me.drive.get()
    if not drive or not drive.id:
        raise MicrosoftToolExecutionError("Drive not found for the current user.")
    return drive.id


def _items_builder(client: GraphServiceClient, item_id: str, drive_id: str) -> Any:
    """Return the DriveItem request builder for the given item.

    Always uses ``client.drives.by_drive_id(...).items.by_drive_item_id(...)``
    which is the only SDK path that exposes the full DriveItem API surface
    (workbook, content, etc.).
    """
    return client.drives.by_drive_id(drive_id).items.by_drive_item_id(item_id)


# ---------------------------------------------------------------------------
# Worksheet deletion error helpers
# ---------------------------------------------------------------------------


def _is_last_worksheet_error(exc: httpx.HTTPStatusError) -> bool:
    """Check if an HTTP 400 error indicates a last-worksheet deletion attempt.

    The Graph API returns a 400 when trying to delete the last visible
    worksheet. This function inspects the response body to distinguish
    that specific condition from other 400 errors (malformed request,
    invalid ID, etc.).

    Known Graph API responses for this case:
    - ``{"error": {"code": "InvalidOperation", "message": "This operation is not permitted for the current object."}}``
    - Messages containing "last worksheet" or "at least one visible worksheet"
    """
    if exc.response.status_code != 400:
        return False
    try:
        error_obj = exc.response.json().get("error", {})
        error_code = error_obj.get("code", "").lower()
        error_msg = error_obj.get("message", "").lower()
    except Exception:
        return False
    # Match on known error code returned by Graph API
    if error_code == "invalidoperation":
        return True
    # Match on known message variants
    return "last worksheet" in error_msg or "at least one visible worksheet" in error_msg


# ---------------------------------------------------------------------------
# Worksheet listing & name -> ID resolution
# ---------------------------------------------------------------------------


async def _list_worksheets(
    token: str,
    item_id: str,
    drive_id: str | None = None,
    session_id: str | None = None,
) -> list[dict[str, Any]]:
    """List worksheets in a workbook via the Graph REST API.

    When *session_id* is provided the ``workbook-session-id`` header is
    included, ensuring the response reflects any mutations made within
    that session (avoids stale reads after add/rename/delete).

    Returns:
        List of worksheet dicts, each containing at least ``id``, ``name``,
        ``position``, and ``visibility``.
    """
    base = _build_drive_base_path(drive_id)
    path = f"{base}/items/{item_id}/workbook/worksheets"
    resp = await _graph_request(token, "GET", path, session_id=session_id)
    worksheets: list[dict[str, Any]] = resp.get("value", [])
    return worksheets


async def _resolve_worksheet_id(
    client: GraphServiceClient,
    item_id: str,
    worksheet_name: str | None,
    drive_id: str | None = None,
    *,
    token: str | None = None,
    session_id: str | None = None,
) -> str:
    """Resolve a worksheet name to its ID for safe use in API paths.

    Worksheet names may contain spaces, hyphens, quotes, and other special
    characters that cause issues with URL encoding and range address syntax.
    By resolving to the worksheet ID upfront, we avoid all encoding problems.

    When *token* is provided the listing is done via ``_graph_request`` with
    the optional *session_id*, which avoids stale reads after recent
    worksheet mutations.  When *token* is ``None`` the SDK is used (legacy
    path, no session awareness).

    Args:
        client: GraphServiceClient instance.
        item_id: DriveItem ID of the workbook.
        worksheet_name: Worksheet name, or None for the first worksheet (position 0).
        drive_id: Optional drive ID for shared items.
        token: Bearer token — enables session-aware listing via REST.
        session_id: Optional Excel session ID for consistent reads.

    Returns:
        The worksheet ID (opaque string safe for URL paths).

    Raises:
        WorksheetNotFoundError: If the named worksheet does not exist.
    """
    if token is not None:
        resolved_drive_id = drive_id or await _get_user_drive_id(client)
        ws_list = await _list_worksheets(token, item_id, resolved_drive_id, session_id)
    else:
        resolved_drive_id = drive_id or await _get_user_drive_id(client)
        sdk_result = await _items_builder(
            client, item_id, resolved_drive_id
        ).workbook.worksheets.get()
        ws_list = [
            {"id": ws.id, "name": ws.name or "", "position": ws.position or 0}
            for ws in (sdk_result.value if sdk_result and sdk_result.value else [])
        ]

    if not ws_list:
        raise MicrosoftToolExecutionError("No worksheets found in workbook.")

    if worksheet_name is None:
        sorted_ws = sorted(ws_list, key=lambda ws: ws.get("position", 0))
        return str(sorted_ws[0]["id"])

    # Case-insensitive name match
    available_names: list[str] = []
    for ws in ws_list:
        name = ws.get("name", "")
        available_names.append(name)
        if name.lower() == worksheet_name.lower():
            return str(ws["id"])

    raise WorksheetNotFoundError(worksheet_name, available_names)


async def _resolve_worksheet_name_and_id(
    client: GraphServiceClient,
    item_id: str,
    worksheet_name: str | None,
    drive_id: str | None = None,
    *,
    token: str | None = None,
    session_id: str | None = None,
) -> tuple[str, str]:
    """Resolve worksheet name and ID together.

    When *token* is provided the listing is done via ``_graph_request`` with
    the optional *session_id*, which avoids stale reads after recent
    worksheet mutations.

    Returns:
        Tuple of (worksheet_name, worksheet_id).
    """
    if token is not None:
        resolved_drive_id = drive_id or await _get_user_drive_id(client)
        ws_list = await _list_worksheets(token, item_id, resolved_drive_id, session_id)
    else:
        resolved_drive_id = drive_id or await _get_user_drive_id(client)
        sdk_result = await _items_builder(
            client, item_id, resolved_drive_id
        ).workbook.worksheets.get()
        ws_list = [
            {"id": ws.id, "name": ws.name or "", "position": ws.position or 0}
            for ws in (sdk_result.value if sdk_result and sdk_result.value else [])
        ]

    if not ws_list:
        raise MicrosoftToolExecutionError("No worksheets found in workbook.")

    if worksheet_name is None:
        sorted_ws = sorted(ws_list, key=lambda ws: ws.get("position", 0))
        first = sorted_ws[0]
        return first.get("name") or "Sheet1", str(first["id"])

    available_names: list[str] = []
    for ws in ws_list:
        name = ws.get("name", "")
        available_names.append(name)
        if name.lower() == worksheet_name.lower():
            return name or worksheet_name, str(ws["id"])

    raise WorksheetNotFoundError(worksheet_name, available_names)


# ---------------------------------------------------------------------------
# Graph API URL helpers
# ---------------------------------------------------------------------------


def _build_drive_base_path(drive_id: str | None) -> str:
    """Build the Graph API drive base path (relative, for use in batch requests)."""
    if drive_id:
        return f"/drives/{drive_id}"
    return "/me/drive"


def _build_workbook_worksheets_path(
    item_id: str, worksheet_id: str, drive_id: str | None = None
) -> str:
    """Build the workbook worksheets path for a specific worksheet."""
    base = _build_drive_base_path(drive_id)
    return f"{base}/items/{item_id}/workbook/worksheets/{worksheet_id}"


# ---------------------------------------------------------------------------
# Graph API batch requests
# ---------------------------------------------------------------------------


async def _execute_batch(
    token: str,
    requests: list[dict[str, Any]],
    http_client: httpx.AsyncClient | None = None,
) -> list[dict[str, Any]]:
    """Execute a batch of Graph API requests in a single HTTP call.

    Args:
        token: Bearer token for authentication.
        requests: List of batch request dicts, each with 'id', 'method', 'url',
                  and optionally 'headers' and 'body'.
        http_client: Optional shared httpx client for connection pooling.
                     If not provided, a new client is created and closed per call.

    Returns:
        List of response dicts, each with 'id', 'status', and 'body'.
    """
    base_url = _get_graph_base_url()

    async def _do(client: httpx.AsyncClient) -> list[dict[str, Any]]:
        response = await client.post(
            f"{base_url}/$batch",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            json={"requests": requests},
            timeout=BATCH_TIMEOUT,
        )
        response.raise_for_status()
        data: list[dict[str, Any]] = response.json().get("responses", [])
        return data

    if http_client is not None:
        return await _do(http_client)
    async with httpx.AsyncClient() as client:
        return await _do(client)


def _build_batch_request(
    request_id: str,
    method: str,
    url: str,
    session_id: str | None = None,
    body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a single request entry for a Graph API $batch call."""
    req: dict[str, Any] = {
        "id": request_id,
        "method": method,
        "url": url,
    }
    headers: dict[str, str] = {}
    if session_id:
        headers["workbook-session-id"] = session_id
    if body is not None:
        headers["Content-Type"] = "application/json"
        req["body"] = body
    if headers:
        req["headers"] = headers
    return req


def _get_batch_response(responses: list[dict[str, Any]], request_id: str) -> dict[str, Any]:
    """Extract a specific response from batch results by request ID."""
    for resp in responses:
        if resp.get("id") == request_id:
            return resp
    raise MicrosoftToolExecutionError(f"Missing response for batch request '{request_id}'.")


# ---------------------------------------------------------------------------
# Range response -> sparse dict conversion
# ---------------------------------------------------------------------------


def _range_response_to_sparse_dict(
    body: dict[str, Any],
    start_col: str,
    start_row: int,
) -> dict[str, dict[str, dict[str, Any]]]:
    """Convert a Graph API range response body to sparse dict format.

    The response body contains 'formulas' and 'text' 2D arrays.
    We convert to: {row_str: {col_letter: {userEnteredValue, formattedValue}}}

    Empty cells (where both formula and text are empty) are omitted.
    """
    formulas = body.get("formulas", [])
    texts = body.get("text", [])
    values = body.get("values", [])

    start_col_idx = _col_letter_to_index(start_col)
    result: dict[str, dict[str, dict[str, Any]]] = {}

    for row_offset, formula_row in enumerate(formulas):
        row_num = start_row + row_offset
        text_row = texts[row_offset] if row_offset < len(texts) else []
        value_row = values[row_offset] if row_offset < len(values) else []

        for col_offset, formula_val in enumerate(formula_row):
            text_val = text_row[col_offset] if col_offset < len(text_row) else ""
            raw_val = value_row[col_offset] if col_offset < len(value_row) else ""

            # Skip empty cells
            is_empty = (
                (formula_val == "" or formula_val is None)
                and (text_val == "" or text_val is None)
                and (raw_val == "" or raw_val is None)
            )
            if is_empty:
                continue

            col_letter = _col_index_to_letter(start_col_idx + col_offset)
            row_key = str(row_num)

            if row_key not in result:
                result[row_key] = {}

            result[row_key][col_letter] = {
                "userEnteredValue": formula_val if formula_val not in ("", None) else raw_val,
                "formattedValue": text_val
                if text_val not in ("", None)
                else str(raw_val)
                if raw_val not in ("", None)
                else "",
            }

    return result


# ---------------------------------------------------------------------------
# Single Graph API request helpers
# ---------------------------------------------------------------------------


async def _graph_request(
    token: str,
    method: str,
    path: str,
    session_id: str | None = None,
    body: dict[str, Any] | None = None,
    http_client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    """Make a single Graph API request.

    Args:
        token: Bearer token.
        method: HTTP method (GET, POST, PATCH, DELETE).
        path: Relative API path (e.g., '/me/drive/items/{id}').
        session_id: Optional Excel session ID.
        body: Optional JSON body.
        http_client: Optional shared httpx client for connection pooling.
                     If not provided, a new client is created and closed per call.

    Returns:
        Response body as dict (empty dict for 204 No Content).
    """
    base_url = _get_graph_base_url()
    url = f"{base_url}{path}"

    headers: dict[str, str] = {
        "Authorization": f"Bearer {token}",
    }
    if session_id:
        headers["workbook-session-id"] = session_id
    if body is not None:
        headers["Content-Type"] = "application/json"

    async def _do(client: httpx.AsyncClient) -> dict[str, Any]:
        response = await client.request(
            method=method,
            url=url,
            headers=headers,
            json=body if body is not None else None,
            timeout=DEFAULT_TIMEOUT,
        )
        response.raise_for_status()
        if response.status_code == 204:
            return {}
        result: dict[str, Any] = response.json()
        return result

    if http_client is not None:
        return await _do(http_client)
    async with httpx.AsyncClient() as client:
        return await _do(client)


async def _upload_xlsx_content(
    token: str,
    upload_path: str,
    payload: bytes,
    filename: str = "",
    http_client: httpx.AsyncClient | None = None,
) -> dict[str, Any]:
    """Upload XLSX file content to OneDrive via PUT.

    Args:
        token: Bearer token.
        upload_path: Relative API path for the upload endpoint.
        payload: Raw XLSX bytes.
        filename: Original filename (used in error messages).
        http_client: Optional shared httpx client for connection pooling.
                     If not provided, a new client is created and closed per call.

    Returns:
        DriveItem response dict.
    """
    base_url = _get_graph_base_url()
    url = f"{base_url}{upload_path}"

    async def _do(client: httpx.AsyncClient) -> dict[str, Any]:
        response = await client.put(
            url,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": XLSX_MIME_TYPE,
            },
            content=payload,
            timeout=UPLOAD_TIMEOUT,
        )
        if response.status_code == 409:
            raise FileAlreadyExistsError(filename)
        if response.status_code == 423:
            raise DocumentLockedError()
        response.raise_for_status()
        result: dict[str, Any] = response.json()
        return result

    if http_client is not None:
        return await _do(http_client)
    async with httpx.AsyncClient() as client:
        return await _do(client)


logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Excel session management
# ---------------------------------------------------------------------------

T = TypeVar("T")


async def _create_excel_session(
    client: GraphServiceClient,
    item_id: str,
    drive_id: str | None = None,
    persist_changes: bool = True,
) -> str:
    """Create a new Excel workbook session via the SDK.

    Args:
        client: GraphServiceClient instance.
        item_id: DriveItem ID of the workbook.
        drive_id: Optional drive ID for shared items.
        persist_changes: If True, changes are saved to the workbook.

    Returns:
        Session ID string.
    """
    from msgraph.generated.drives.item.items.item.workbook.create_session.create_session_post_request_body import (
        CreateSessionPostRequestBody,
    )

    request_body = CreateSessionPostRequestBody(persist_changes=persist_changes)

    resolved_drive_id = drive_id or await _get_user_drive_id(client)
    result = await _items_builder(client, item_id, resolved_drive_id).workbook.create_session.post(
        request_body
    )

    if not result or not result.id:
        raise MicrosoftToolExecutionError("Failed to create Excel session.")

    return str(result.id)


async def _close_excel_session(
    client: GraphServiceClient,
    item_id: str,
    session_id: str,
    drive_id: str | None = None,
) -> None:
    """Close an Excel workbook session. Best-effort: silently ignores errors.

    Note: Tools intentionally do NOT call this after each invocation.
    Sessions are returned to the agent for reuse across multiple calls,
    and Microsoft auto-expires idle sessions after ~5 minutes.
    This function exists for explicit cleanup when needed.
    """
    from kiota_abstractions.base_request_configuration import RequestConfiguration

    try:
        config: RequestConfiguration = RequestConfiguration()
        config.headers.add("workbook-session-id", session_id)

        resolved_drive_id = drive_id or await _get_user_drive_id(client)
        await _items_builder(client, item_id, resolved_drive_id).workbook.close_session.post(
            request_configuration=config
        )
    except Exception:
        # Session may already be expired — safe to ignore
        logger.debug("Failed to close Excel session %s (may already be expired)", session_id)


async def _ensure_excel_session(
    client: GraphServiceClient,
    item_id: str,
    session_id: str | None,
    drive_id: str | None = None,
) -> str:
    """Ensure a valid session exists, creating one if needed."""
    if session_id:
        return session_id
    return await _create_excel_session(client, item_id, drive_id)


def _is_session_expired_error(exc: Exception) -> bool:
    """Detect whether an exception indicates an expired Excel session."""
    if isinstance(exc, httpx.HTTPStatusError):
        status = exc.response.status_code
        if status == 404:
            return True
        if status == 409:
            try:
                body = exc.response.json()
                error_code = body.get("error", {}).get("code", "")
            except Exception:
                return False
            else:
                return "InvalidSession" in error_code
    exc_str = str(exc).lower()
    if "invalidsession" in exc_str:
        return True
    # Graph API batch responses use "The target session is invalid." and
    # direct responses may use "session expired".  Cover both patterns.
    return "session" in exc_str and ("expired" in exc_str or "invalid" in exc_str)


async def _execute_with_session_retry(
    client: GraphServiceClient,
    item_id: str,
    session_id: str | None,
    drive_id: str | None,
    operation: Callable[[str], Awaitable[T]],
) -> tuple[T, str]:
    """Execute an operation with automatic session expiry recovery.

    If the operation fails due to an expired session, creates a new
    session and retries once. The agent never sees the failure.

    Args:
        client: GraphServiceClient instance.
        item_id: DriveItem ID of the workbook.
        session_id: Optional existing session ID.
        drive_id: Optional drive ID for shared items.
        operation: Async callable that receives a session_id and performs the API call.

    Returns:
        Tuple of (operation_result, session_id).
    """
    sid = await _ensure_excel_session(client, item_id, session_id, drive_id)
    try:
        result = await operation(sid)
    except Exception as exc:
        if _is_session_expired_error(exc):
            sid = await _create_excel_session(client, item_id, drive_id)
            result = await operation(sid)
            return result, sid
        raise
    else:
        return result, sid
