import asyncio
import contextlib
import os
from pathlib import Path
from typing import Any, Callable, Literal, TypedDict, cast
from urllib.parse import urlparse

import httpx
from arcade_mcp_server import Context
from arcade_mcp_server.exceptions import RetryableToolError, ToolExecutionError
from kiota_abstractions.base_request_configuration import RequestConfiguration
from msgraph.generated.drives.item.items.item.children.children_request_builder import (
    ChildrenRequestBuilder,
)
from msgraph.generated.models.drive_item import DriveItem

from arcade_microsoft_utils.exceptions import (
    ConflictError,
    DocumentLockedError,
    DownloadSizeLimitExceededError,
)

# Constants for resumable uploads
SIMPLE_UPLOAD_MAX_BYTES = 4 * 1024 * 1024  # 4 MB - max for simple PUT /content
CHUNK_SIZE_MIN = 320 * 1024  # 320 KB - minimum chunk size (must be multiple of this)
CHUNK_SIZE_DEFAULT = 5 * 1024 * 1024  # 5 MB - recommended for stable connections
CHUNK_SIZE_MAX = 10 * 1024 * 1024  # 10 MB - max chunk size
GRAPH_BASE_URL_DEFAULT = "https://graph.microsoft.com/v1.0"


def _get_max_download_bytes(env_var: str, default_mb: int) -> int:
    """Return the maximum download size in bytes.

    Args:
        env_var: Name of the environment variable that overrides the default.
        default_mb: Default limit in megabytes when the env var is unset or invalid.
    """
    raw = os.environ.get(env_var, "")
    if raw.strip():
        try:
            return int(raw) * 1024 * 1024
        except ValueError:
            pass
    return default_mb * 1024 * 1024


def _ensure_download_size_under_limit(
    item: DriveItem,
    env_var: str,
    default_mb: int,
) -> None:
    """Check the drive item's reported size against a configurable download limit.

    Args:
        item: The DriveItem whose size to check.
        env_var: Environment variable name that overrides the default limit.
        default_mb: Default limit in megabytes.

    Raises:
        DownloadSizeLimitExceededError: If the file exceeds the limit.
    """
    file_size = item.size
    if file_size is None:
        return  # size unknown — proceed optimistically
    max_bytes = _get_max_download_bytes(env_var, default_mb)
    if file_size > max_bytes:
        raise DownloadSizeLimitExceededError(
            file_size_mb=file_size / (1024 * 1024),
            limit_mb=max_bytes / (1024 * 1024),
            env_var=env_var,
        )


def _get_graph_base_url() -> str:
    """Get Graph API base URL, honoring environment variable override."""
    base_url = os.getenv("ARCADE_MICROSOFT_GRAPH_BASE_URL", GRAPH_BASE_URL_DEFAULT)
    return base_url.rstrip("/")


def _maybe_raise_locked_error(exc: Exception) -> None:
    error_code = None
    message = None

    error_obj = getattr(exc, "error", None)
    if error_obj is not None:
        if isinstance(error_obj, dict):
            error_code = error_obj.get("code")
            message = error_obj.get("message")
        else:
            error_code = getattr(error_obj, "code", None)
            message = getattr(error_obj, "message", None)

    if not message:
        message = str(exc)

    message_lower = message.lower()
    if (error_code == "notAllowed" and "locked" in message_lower) or (
        "resource you are attempting to access is locked" in message_lower
    ):
        raise DocumentLockedError() from exc


def _normalize_next_link(odata_next_link: str | None) -> str | None:
    if not odata_next_link:
        return None
    parsed = urlparse(odata_next_link)
    if parsed.scheme and parsed.netloc:
        return odata_next_link
    return None


async def _get_root_item_id(client: Any, drive_id: str) -> str:
    root_item = await client.drives.by_drive_id(drive_id).root.get()
    if not root_item or not root_item.id:
        raise ToolExecutionError("Root folder not found for the current drive.")
    return cast(str, root_item.id)


async def _get_drive_item(client: Any, drive_id: str, item_id: str) -> DriveItem:
    item = await client.drives.by_drive_id(drive_id).items.by_drive_item_id(item_id).get()
    if not item:
        raise ToolExecutionError("Item not found. Verify the item_id.")
    return cast(DriveItem, item)


def _has_extension(name: str) -> bool:
    suffix = Path(name).suffix
    return bool(suffix and suffix != ".")


def _normalize_copy_name(item: DriveItem, new_name: str | None) -> str | None:
    if new_name is None or _has_extension(new_name):
        return new_name

    if not item.name:
        return new_name

    original_suffix = Path(item.name).suffix
    if not original_suffix or original_suffix == ".":
        return new_name

    return f"{new_name}{original_suffix}"


def _build_copy_payload(destination_folder_id: str | None, new_name: str | None) -> dict[str, Any]:
    payload: dict[str, Any] = {}

    if destination_folder_id is not None:
        normalized_destination = destination_folder_id.strip()
        if not normalized_destination:
            raise ToolExecutionError("destination_folder_id must be a non-empty string.")
        payload["parentReference"] = {"id": normalized_destination}

    if new_name is not None:
        normalized_name = new_name.strip()
        if not normalized_name:
            raise ToolExecutionError("new_name must be a non-empty string.")
        payload["name"] = normalized_name

    return payload


async def _fetch_children(
    client: Any,
    drive_id: str,
    folder_id: str,
    limit: int,
    next_token: str | None = None,
) -> tuple[list[DriveItem], str | None]:
    children_builder = (
        client.drives.by_drive_id(drive_id).items.by_drive_item_id(folder_id).children
    )

    if next_token:
        response = await children_builder.with_url(next_token).get()
    else:
        request_configuration = RequestConfiguration(
            query_parameters=ChildrenRequestBuilder.ChildrenRequestBuilderGetQueryParameters(
                top=limit,
            )
        )
        response = await children_builder.get(request_configuration)

    if not response or not response.value:
        return [], None

    return response.value, _normalize_next_link(response.odata_next_link)


async def _name_exists_in_folder(
    client: Any,
    drive_id: str,
    folder_id: str,
    name: str,
    max_items: int = 1000,
) -> bool:
    remaining = max_items
    next_token: str | None = None
    while remaining > 0:
        page_limit = min(200, remaining)
        items, next_token = await _fetch_children(
            client=client,
            drive_id=drive_id,
            folder_id=folder_id,
            limit=page_limit,
            next_token=next_token,
        )
        if not items:
            return False
        for item in items:
            if item.name and item.name == name:
                return True
            remaining -= 1
            if remaining <= 0:
                break
        if not next_token:
            return False
    return False


def _resolve_destination_folder_id(
    source_item: DriveItem, fallback_root_id: str, destination_folder_id: str | None
) -> str:
    if destination_folder_id:
        return destination_folder_id
    parent_reference = source_item.parent_reference
    if parent_reference and parent_reference.id:
        return parent_reference.id
    return fallback_root_id


async def _handle_copy_server_error(
    client: Any,
    drive_id: str,
    source_item: DriveItem,
    destination_folder_id: str | None,
    normalized_name: str | None,
    response: httpx.Response,
) -> None:
    root_id = await _get_root_item_id(client, drive_id)
    destination_id = _resolve_destination_folder_id(
        source_item=source_item,
        fallback_root_id=root_id,
        destination_folder_id=destination_folder_id,
    )
    conflict_name = normalized_name or source_item.name
    if conflict_name and await _name_exists_in_folder(
        client, drive_id, destination_id, conflict_name
    ):
        message = (
            f"A file named '{conflict_name}' already exists in the destination folder. "
            "Provide a different new_name or destination_folder_id."
        )
        raise ToolExecutionError(message)

    message = "Microsoft Graph error: general exception while processing."
    error_body = response.text.strip()
    if error_body:
        message = f"{message} Details: {error_body}"
    raise RetryableToolError(
        message=message,
        developer_message=f"Status: {response.status_code}. Body: {response.text}",
    )


async def _get_copy_status_internal(
    context: Context, operation_url: str
) -> tuple[str, str | None, str | None]:
    parsed = urlparse(operation_url)
    include_auth_header = "tempauth=" not in parsed.query
    if include_auth_header:
        headers = {"Authorization": f"Bearer {context.get_auth_token_or_empty()}"}
    else:
        headers = None

    async with httpx.AsyncClient(follow_redirects=True) as http_client:
        response = await http_client.get(operation_url, headers=headers)
        if response.status_code == 202:
            return "in_progress", None, None
        response.raise_for_status()

    payload = response.json()
    status = payload.get("status")
    if status == "completed":
        return "completed", payload.get("resourceId"), None
    if status == "failed":
        return "failed", None, payload.get("error", {}).get("message")
    return "in_progress", None, None


async def _poll_copy_operation(
    context: Context,
    operation_url: str,
    drive_id: str,
    client: Any,
    serialize_item: Callable[[DriveItem], dict[str, Any]],
) -> dict[str, Any]:
    for _ in range(5):
        status, resource_id, error_message = await _get_copy_status_internal(context, operation_url)
        if status == "completed" and resource_id:
            item = (
                await client.drives.by_drive_id(drive_id).items.by_drive_item_id(resource_id).get()
            )
            if not item:
                return {
                    "status": "completed",
                    "item_id": resource_id,
                    "message": "Item successfully copied.",
                }
            return {
                "status": "completed",
                "item": serialize_item(item),
                "message": "Item successfully copied.",
            }
        if status == "failed":
            return {
                "status": "failed",
                "operation_url": operation_url,
                "message": error_message or "Copy operation failed.",
            }
        await asyncio.sleep(2)

    return {
        "status": "in_progress",
        "operation_url": operation_url,
        "message": "Copy operation still in progress. Use get_copy_status to check later.",
    }


# =============================================================================
# Resumable Upload Infrastructure
# =============================================================================


class UploadSessionInfo(TypedDict):
    """Information returned when creating an upload session."""

    upload_url: str
    expiration_datetime: str


class UploadSessionStatus(TypedDict):
    """Status of an upload session."""

    next_expected_ranges: list[str]
    expiration_datetime: str | None


class ChunkUploadResult(TypedDict, total=False):
    """Result of uploading a single chunk."""

    completed: bool
    next_expected_ranges: list[str]
    item: dict[str, Any] | None


def _align_chunk_size(chunk_size: int) -> int:
    """Align chunk size to be a multiple of 320 KB (required by Graph API).

    Args:
        chunk_size: Desired chunk size in bytes.

    Returns:
        Chunk size aligned to 320 KB boundary, clamped to min/max limits.
    """
    # Clamp to valid range
    chunk_size = max(CHUNK_SIZE_MIN, min(chunk_size, CHUNK_SIZE_MAX))
    # Round down to nearest multiple of 320 KB
    return (chunk_size // CHUNK_SIZE_MIN) * CHUNK_SIZE_MIN


async def _create_upload_session(
    token: str,
    parent_item_id: str,
    filename: str,
    drive_id: str | None = None,
    conflict_behavior: Literal["fail", "rename", "replace"] = "fail",
) -> UploadSessionInfo:
    """Create a resumable upload session for a file.

    Args:
        token: OAuth access token.
        parent_item_id: ID of the parent folder where the file will be created.
        filename: Name of the file to create (e.g., "presentation.pptx").
        drive_id: Drive ID for SharePoint; None for user's OneDrive.
        conflict_behavior: How to handle name conflicts:
            - "fail": Return error if file exists
            - "rename": Auto-rename to avoid conflict
            - "replace": Overwrite existing file

    Returns:
        UploadSessionInfo with upload_url and expiration_datetime.

    Raises:
        ToolExecutionError: If session creation fails.
    """
    base_url = _get_graph_base_url()

    # Build URL: "root" sentinel uses /root:/{name}:/ path form;
    # real folder IDs use /items/{id}:/{name}:/ form.
    if parent_item_id == "root":
        path_segment = f"root:/{filename}:/createUploadSession"
    else:
        path_segment = f"items/{parent_item_id}:/{filename}:/createUploadSession"

    if drive_id:
        url = f"{base_url}/drives/{drive_id}/{path_segment}"
    else:
        url = f"{base_url}/me/drive/{path_segment}"

    # Map conflict_behavior to @microsoft.graph.conflictBehavior
    conflict_map = {"fail": "fail", "rename": "rename", "replace": "replace"}
    request_body = {"item": {"@microsoft.graph.conflictBehavior": conflict_map[conflict_behavior]}}

    async with httpx.AsyncClient() as http_client:
        response = await http_client.post(
            url,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            json=request_body,
        )

        if response.status_code == 409:
            raise ToolExecutionError(
                f"A file named '{filename}' already exists. "
                "Use conflict_behavior='rename' or 'replace' to handle this."
            )

        if response.status_code >= 400:
            raise ToolExecutionError(
                f"Failed to create upload session: {response.status_code} - {response.text}"
            )

        data = response.json()

    return UploadSessionInfo(
        upload_url=data["uploadUrl"],
        expiration_datetime=data.get("expirationDateTime", ""),
    )


async def _upload_chunk(
    upload_url: str,
    chunk: bytes,
    start_byte: int,
    total_size: int,
) -> ChunkUploadResult:
    """Upload a single chunk to an upload session.

    Args:
        upload_url: The upload URL from the session.
        chunk: The bytes to upload.
        start_byte: Starting byte position (0-indexed).
        total_size: Total file size in bytes.

    Returns:
        ChunkUploadResult with completion status and next ranges or final item.

    Raises:
        RetryableToolError: On transient server errors (5xx).
        ToolExecutionError: On client errors or session issues.
    """
    end_byte = start_byte + len(chunk) - 1
    content_range = f"bytes {start_byte}-{end_byte}/{total_size}"

    async with httpx.AsyncClient() as http_client:
        response = await http_client.put(
            upload_url,
            headers={
                "Content-Length": str(len(chunk)),
                "Content-Range": content_range,
            },
            content=chunk,
        )

        # Handle various response codes
        if response.status_code == 202:
            # Upload accepted, more chunks needed
            data = response.json()
            return ChunkUploadResult(
                completed=False,
                next_expected_ranges=data.get("nextExpectedRanges", []),
            )

        if response.status_code in (200, 201):
            # Upload complete - response contains the DriveItem
            # We return the raw dict; caller can deserialize if needed
            return ChunkUploadResult(
                completed=True,
                next_expected_ranges=[],
                item=response.json(),
            )

        if response.status_code == 404:
            raise ToolExecutionError(
                "Upload session expired or not found. Create a new session and retry."
            )

        if response.status_code == 409:
            raise ToolExecutionError(
                "Upload session conflict. The file may have been modified. "
                "Create a new session and retry."
            )

        if response.status_code == 416:
            # Range not satisfiable - need to query session for correct position
            raise RetryableToolError(
                message="Chunk range not accepted. Query session status and retry.",
                developer_message=f"416 Range Not Satisfiable: {response.text}",
            )

        if response.status_code >= 500:
            raise RetryableToolError(
                message="Server error during chunk upload. Retrying...",
                developer_message=f"Server error {response.status_code}: {response.text}",
            )

        raise ToolExecutionError(
            f"Unexpected error during chunk upload: {response.status_code} - {response.text}"
        )


async def _get_upload_session_status(upload_url: str) -> UploadSessionStatus:
    """Query an upload session for its current status.

    Use this to determine where to resume an interrupted upload.

    Args:
        upload_url: The upload URL from the session.

    Returns:
        UploadSessionStatus with next_expected_ranges and expiration info.

    Raises:
        ToolExecutionError: If session is expired or not found.
    """
    async with httpx.AsyncClient() as http_client:
        response = await http_client.get(upload_url)

        if response.status_code == 404:
            raise ToolExecutionError("Upload session expired or not found.")

        response.raise_for_status()
        data = response.json()

    return UploadSessionStatus(
        next_expected_ranges=data.get("nextExpectedRanges", []),
        expiration_datetime=data.get("expirationDateTime"),
    )


async def _cancel_upload_session(upload_url: str) -> bool:
    """Cancel an upload session.

    Args:
        upload_url: The upload URL from the session.

    Returns:
        True if session was successfully cancelled, False if already gone.
    """
    async with httpx.AsyncClient() as http_client:
        response = await http_client.delete(upload_url)
        # 204 = success, 404 = already gone (both are fine)
        return response.status_code in (204, 404)


def _parse_next_offset(next_ranges: list[str], fallback: int) -> int:
    """Parse next offset from nextExpectedRanges or use fallback."""
    if next_ranges:
        # Parse the next expected range (format: "start-end" or "start-")
        return int(next_ranges[0].split("-")[0])
    return fallback


async def _upload_chunk_with_retry(
    upload_url: str,
    content: bytes,
    offset: int,
    aligned_chunk_size: int,
    total_size: int,
    max_retries: int,
) -> tuple[dict[str, Any] | None, int]:
    """Upload a chunk with retry logic.

    Returns:
        Tuple of (completed_item or None, next_offset).
        If completed_item is not None, upload is finished.
    """
    chunk_end = min(offset + aligned_chunk_size, total_size)
    chunk = content[offset:chunk_end]
    retries = 0

    while True:
        try:
            result = await _upload_chunk(
                upload_url=upload_url,
                chunk=chunk,
                start_byte=offset,
                total_size=total_size,
            )
        except RetryableToolError:
            retries += 1
            if retries >= max_retries:
                raise
            # Exponential backoff: 1s, 2s, 4s
            await asyncio.sleep(2 ** (retries - 1))

            # Query session to get correct position and recalculate chunk
            status = await _get_upload_session_status(upload_url)
            if status["next_expected_ranges"]:
                offset = int(status["next_expected_ranges"][0].split("-")[0])
                chunk_end = min(offset + aligned_chunk_size, total_size)
                chunk = content[offset:chunk_end]
        else:
            if result["completed"]:
                return result.get("item") or {}, offset

            next_offset = _parse_next_offset(result.get("next_expected_ranges", []), chunk_end)
            return None, next_offset


async def _upload_chunks_to_session(
    upload_url: str,
    content: bytes,
    chunk_size: int = CHUNK_SIZE_DEFAULT,
    max_retries: int = 3,
) -> dict[str, Any]:
    """Upload content to an existing upload session URL in chunks.

    Handles chunking, retry with exponential backoff, and session cleanup
    on failure. This is the core upload loop used by both create and update
    resumable upload flows.

    Args:
        upload_url: The upload URL from a created session.
        content: File content as bytes.
        chunk_size: Size of each chunk (will be aligned to 320 KB multiple).
        max_retries: Maximum retries per chunk on transient errors.

    Returns:
        The completed DriveItem as a dictionary.

    Raises:
        ToolExecutionError: On non-recoverable errors.
        RetryableToolError: If max retries exceeded.
    """
    total_size = len(content)
    aligned_chunk_size = _align_chunk_size(chunk_size)

    try:
        offset = 0
        result: dict[str, Any] = {}
        while offset < total_size:
            completed_item, offset = await _upload_chunk_with_retry(
                upload_url=upload_url,
                content=content,
                offset=offset,
                aligned_chunk_size=aligned_chunk_size,
                total_size=total_size,
                max_retries=max_retries,
            )
            if completed_item is not None:
                result = completed_item
                break
    except Exception:
        # On any failure, try to cancel the session to clean up
        with contextlib.suppress(Exception):
            await _cancel_upload_session(upload_url)
        raise
    return result


async def _resumable_upload(
    token: str,
    parent_item_id: str,
    filename: str,
    content: bytes,
    drive_id: str | None = None,
    chunk_size: int = CHUNK_SIZE_DEFAULT,
    conflict_behavior: Literal["fail", "rename", "replace"] = "fail",
    max_retries: int = 3,
) -> dict[str, Any]:
    """Upload a file using resumable upload session with automatic chunking.

    Handles:
    - Session creation
    - Chunked upload with proper Content-Range headers
    - Retry on transient failures with exponential backoff
    - Progress tracking via server-side nextExpectedRanges

    Args:
        token: OAuth access token.
        parent_item_id: ID of the parent folder.
        filename: Name of the file to create.
        content: File content as bytes.
        drive_id: Drive ID for SharePoint; None for user's OneDrive.
        chunk_size: Size of each chunk (will be aligned to 320 KB multiple).
        conflict_behavior: How to handle name conflicts.
        max_retries: Maximum retries per chunk on transient errors.

    Returns:
        The created DriveItem as a dictionary.

    Raises:
        ToolExecutionError: On non-recoverable errors.
        RetryableToolError: If max retries exceeded.
    """
    session = await _create_upload_session(
        token=token,
        parent_item_id=parent_item_id,
        filename=filename,
        drive_id=drive_id,
        conflict_behavior=conflict_behavior,
    )
    return await _upload_chunks_to_session(
        upload_url=session["upload_url"],
        content=content,
        chunk_size=chunk_size,
        max_retries=max_retries,
    )


async def _simple_upload(
    token: str,
    parent_item_id: str,
    filename: str,
    content: bytes,
    content_type: str,
    drive_id: str | None = None,
    conflict_behavior: Literal["fail", "rename", "replace"] = "fail",
) -> dict[str, Any]:
    """Upload a small file (≤4MB) using simple PUT to /content endpoint.

    Args:
        token: OAuth access token.
        parent_item_id: ID of the parent folder.
        filename: Name of the file to create.
        content: File content as bytes (must be ≤4MB).
        content_type: MIME type of the content.
        drive_id: Drive ID for SharePoint; None for user's OneDrive.
        conflict_behavior: How to handle name conflicts.

    Returns:
        The created DriveItem as a dictionary.

    Raises:
        ToolExecutionError: On errors.
    """
    base_url = _get_graph_base_url()

    # Map conflict behavior to query parameter
    conflict_param = f"@microsoft.graph.conflictBehavior={conflict_behavior}"

    # Build URL: "root" sentinel uses /root:/{name}:/ path form;
    # real folder IDs use /items/{id}:/{name}:/ form.
    if parent_item_id == "root":
        path_segment = f"root:/{filename}:/content"
    else:
        path_segment = f"items/{parent_item_id}:/{filename}:/content"

    if drive_id:
        url = f"{base_url}/drives/{drive_id}/{path_segment}?{conflict_param}"
    else:
        url = f"{base_url}/me/drive/{path_segment}?{conflict_param}"

    async with httpx.AsyncClient() as http_client:
        response = await http_client.put(
            url,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": content_type,
            },
            content=content,
        )

        if response.status_code == 409:
            raise ToolExecutionError(
                f"A file named '{filename}' already exists. "
                "Use conflict_behavior='rename' or 'replace' to handle this."
            )

        if response.status_code >= 400:
            raise ToolExecutionError(
                f"Failed to upload file: {response.status_code} - {response.text}"
            )

        result: dict[str, Any] = response.json()
        return result


async def _smart_upload(
    token: str,
    parent_item_id: str,
    filename: str,
    content: bytes,
    content_type: str,
    drive_id: str | None = None,
    conflict_behavior: Literal["fail", "rename", "replace"] = "fail",
    chunk_size: int = CHUNK_SIZE_DEFAULT,
) -> dict[str, Any]:
    """Intelligently upload a file using simple or resumable upload based on size.

    - Files ≤ 4MB: Uses simple upload (single PUT request)
    - Files > 4MB: Uses resumable upload (chunked)

    Args:
        token: OAuth access token.
        parent_item_id: ID of the parent folder.
        filename: Name of the file to create.
        content: File content as bytes.
        content_type: MIME type of the content.
        drive_id: Drive ID for SharePoint; None for user's OneDrive.
        conflict_behavior: How to handle name conflicts.
        chunk_size: Chunk size for resumable uploads (aligned to 320 KB).

    Returns:
        The created DriveItem as a dictionary.
    """
    if len(content) <= SIMPLE_UPLOAD_MAX_BYTES:
        return await _simple_upload(
            token=token,
            parent_item_id=parent_item_id,
            filename=filename,
            content=content,
            content_type=content_type,
            drive_id=drive_id,
            conflict_behavior=conflict_behavior,
        )
    else:
        return await _resumable_upload(
            token=token,
            parent_item_id=parent_item_id,
            filename=filename,
            content=content,
            drive_id=drive_id,
            chunk_size=chunk_size,
            conflict_behavior=conflict_behavior,
        )


# =============================================================================
# Unified Upload Helper
# =============================================================================


async def _create_upload_session_for_existing_item(
    token: str,
    item_id: str,
    drive_id: str | None = None,
    conflict_behavior: Literal["fail", "rename", "replace"] = "replace",
) -> UploadSessionInfo:
    """Create a resumable upload session for replacing an existing file.

    Uses the ``/items/{item_id}/createUploadSession`` endpoint (no filename in
    the path), which tells Graph to overwrite the content of the specified item.

    Args:
        token: OAuth access token.
        item_id: ID of the existing file to replace.
        drive_id: Drive ID for SharePoint; None for user's OneDrive.
        conflict_behavior: Typically "replace" for updates.

    Returns:
        UploadSessionInfo with upload_url and expiration_datetime.

    Raises:
        ToolExecutionError: If session creation fails.
    """
    base_url = _get_graph_base_url()
    if drive_id:
        url = f"{base_url}/drives/{drive_id}/items/{item_id}/createUploadSession"
    else:
        url = f"{base_url}/me/drive/items/{item_id}/createUploadSession"

    conflict_map = {"fail": "fail", "rename": "rename", "replace": "replace"}
    request_body = {"item": {"@microsoft.graph.conflictBehavior": conflict_map[conflict_behavior]}}

    async with httpx.AsyncClient() as http_client:
        response = await http_client.post(
            url,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            json=request_body,
        )

        if response.status_code == 404:
            raise ToolExecutionError(
                "File not found. Verify the item_id (and drive_id for SharePoint)."
            )

        if response.status_code == 423:
            raise DocumentLockedError()

        if response.status_code >= 400:
            raise ToolExecutionError(
                f"Failed to create upload session: {response.status_code} - {response.text}"
            )

        data = response.json()

    return UploadSessionInfo(
        upload_url=data["uploadUrl"],
        expiration_datetime=data.get("expirationDateTime", ""),
    )


async def _smart_upload_content(
    token: str,
    content: bytes,
    content_type: str,
    # --- Create mode (new file): provide filename ---
    filename: str | None = None,
    parent_item_id: str | None = None,  # None = root folder
    # --- Update mode (existing file): provide item_id ---
    item_id: str | None = None,
    etag: str | None = None,
    # --- Common ---
    drive_id: str | None = None,
    conflict_behavior: Literal["fail", "rename", "replace"] = "fail",
    chunk_size: int = CHUNK_SIZE_DEFAULT,
) -> dict[str, Any]:
    """Unified upload helper that handles both create and update, with automatic
    selection of simple vs resumable upload based on file size.

    **Create mode** (filename is set):
        - ≤4MB: Simple PUT to ``/items/{parent}:/{filename}:/content`` (or ``root:`` if no parent)
        - >4MB: Resumable upload via upload session

    **Update mode** (item_id is set):
        - ≤4MB: Simple PUT to ``/items/{item_id}/content`` with ``If-Match`` etag
        - >4MB: Pre-flight etag verification, then resumable upload.
          Note: Microsoft Graph does not support ``If-Match`` on upload sessions,
          so concurrency protection for large file updates is **best-effort**
          (the etag is verified before the upload begins, but a narrow race
          window exists).

    Args:
        token: OAuth access token.
        content: File content as bytes.
        content_type: MIME type (e.g. PPTX_MIME_TYPE).
        filename: Filename for create mode (mutually exclusive with item_id).
        parent_item_id: Parent folder ID for create mode; None = drive root.
        item_id: Existing item ID for update mode (mutually exclusive with filename).
        etag: ETag for optimistic concurrency (update mode only).
        drive_id: Drive ID for SharePoint; None for user's OneDrive.
        conflict_behavior: How to handle name conflicts.
        chunk_size: Chunk size for resumable uploads.

    Returns:
        The created/updated DriveItem as a dictionary.

    Raises:
        ToolExecutionError: On validation or non-recoverable upload errors.
        ConflictError: When etag does not match (412).
        DocumentLockedError: When file is locked (423).
    """
    is_create = filename is not None
    is_update = item_id is not None

    if is_create == is_update:
        raise ToolExecutionError(
            "Exactly one of 'filename' (create) or 'item_id' (update) must be provided."
        )

    use_simple = len(content) <= SIMPLE_UPLOAD_MAX_BYTES

    if is_create:
        return await _smart_upload_content_create(
            token=token,
            content=content,
            content_type=content_type,
            filename=cast(str, filename),
            parent_item_id=parent_item_id,
            drive_id=drive_id,
            conflict_behavior=conflict_behavior,
            chunk_size=chunk_size,
            use_simple=use_simple,
        )
    else:
        return await _smart_upload_content_update(
            token=token,
            content=content,
            content_type=content_type,
            item_id=cast(str, item_id),
            etag=etag,
            drive_id=drive_id,
            chunk_size=chunk_size,
            use_simple=use_simple,
        )


async def _smart_upload_content_create(
    token: str,
    content: bytes,
    content_type: str,
    filename: str,
    parent_item_id: str | None,
    drive_id: str | None,
    conflict_behavior: Literal["fail", "rename", "replace"],
    chunk_size: int,
    use_simple: bool,
) -> dict[str, Any]:
    """Create-mode upload: new file into a folder.

    For ≤4MB uses simple PUT; for >4MB uses resumable upload.
    When no parent_item_id is given, uses "root" as the parent.
    """
    if use_simple:
        return await _simple_upload(
            token=token,
            parent_item_id=parent_item_id or "root",
            filename=filename,
            content=content,
            content_type=content_type,
            drive_id=drive_id,
            conflict_behavior=conflict_behavior,
        )
    else:
        return await _resumable_upload(
            token=token,
            parent_item_id=parent_item_id or "root",
            filename=filename,
            content=content,
            drive_id=drive_id,
            chunk_size=chunk_size,
            conflict_behavior=conflict_behavior,
        )


async def _smart_upload_content_update(
    token: str,
    content: bytes,
    content_type: str,
    item_id: str,
    etag: str | None,
    drive_id: str | None,
    chunk_size: int,
    use_simple: bool,
) -> dict[str, Any]:
    """Update-mode upload: replace content of an existing file.

    For ≤4MB uses simple PUT with If-Match etag.
    For >4MB performs a best-effort etag check, then resumable upload.
    """
    base_url = _get_graph_base_url()
    if drive_id:
        item_url = f"{base_url}/drives/{drive_id}/items/{item_id}/content"
    else:
        item_url = f"{base_url}/me/drive/items/{item_id}/content"

    if use_simple:
        # Simple PUT with If-Match for optimistic concurrency
        headers: dict[str, str] = {
            "Authorization": f"Bearer {token}",
            "Content-Type": content_type,
        }
        if etag:
            headers["If-Match"] = etag

        async with httpx.AsyncClient() as http_client:
            response = await http_client.put(item_url, headers=headers, content=content)

            if response.status_code == 423:
                raise DocumentLockedError()
            if response.status_code == 412:
                raise ConflictError()
            if response.status_code >= 400:
                raise ToolExecutionError(
                    f"Failed to upload content: {response.status_code} - {response.text}"
                )
            return cast(dict[str, Any], response.json())
    else:
        # Resumable upload for large files.
        # Best-effort concurrency: verify etag before starting the session.
        # Graph does not support If-Match on upload sessions, so there is a
        # narrow race window between the check and the first chunk upload.
        if etag:
            await _verify_etag(token=token, item_id=item_id, etag=etag, drive_id=drive_id)

        session = await _create_upload_session_for_existing_item(
            token=token,
            item_id=item_id,
            drive_id=drive_id,
            conflict_behavior="replace",
        )
        return await _upload_chunks_to_session(
            upload_url=session["upload_url"],
            content=content,
            chunk_size=chunk_size,
        )


async def _verify_etag(
    token: str,
    item_id: str,
    etag: str,
    drive_id: str | None = None,
) -> None:
    """Pre-flight etag check: fetch item metadata and verify the etag matches.

    This provides best-effort concurrency protection for resumable uploads
    where the Graph API does not support If-Match on the upload session.

    Raises:
        ConflictError: If the current etag does not match.
        ToolExecutionError: If the item cannot be fetched.
    """
    base_url = _get_graph_base_url()
    if drive_id:
        url = f"{base_url}/drives/{drive_id}/items/{item_id}?$select=id,eTag"
    else:
        url = f"{base_url}/me/drive/items/{item_id}?$select=id,eTag"

    async with httpx.AsyncClient() as http_client:
        response = await http_client.get(
            url,
            headers={"Authorization": f"Bearer {token}"},
        )

        if response.status_code == 404:
            raise ToolExecutionError("File not found. Verify item_id and drive_id.")
        if response.status_code >= 400:
            raise ToolExecutionError(
                f"Failed to verify file state: {response.status_code} - {response.text}"
            )

        data = response.json()

    current_etag = data.get("eTag") or data.get("etag")
    if current_etag and current_etag != etag:
        raise ConflictError()
