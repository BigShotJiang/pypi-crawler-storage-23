sphinx\_source\_tree module
===========================

.. automodule:: sphinx_source_tree
   :members:
   :undoc-members:
   :show-inheritance:
