
Package
=======

.. toctree::
   :maxdepth: 20

   sphinx_source_tree

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
