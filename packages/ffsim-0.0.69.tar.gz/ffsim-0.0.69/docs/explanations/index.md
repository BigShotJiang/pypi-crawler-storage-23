# Explanations

```{toctree}
:maxdepth: 1

state-vectors-and-gates
hamiltonians
orbital-rotation
double-factorized
diag-coulomb-hamiltonian
lucj
protocols
qubit-gate-decompositions
```
