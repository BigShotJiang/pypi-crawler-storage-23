"""Integration adapters for external frameworks."""
