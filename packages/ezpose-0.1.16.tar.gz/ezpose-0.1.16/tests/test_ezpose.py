import pytest
import numpy as np
from ezpose import SE3, SO3
from scipy.spatial.transform import Rotation


def setup_function():
    global pose_single, pose_multiple
    pose_single = SE3.random()
    pose_multiple = SE3.random(10)


def is_SO3(rot: SO3):
    assert np.testing.assert_array_equal(
        rot.as_matrix() @ rot.as_matrix().T, np.eye(3)
    )


def is_SE3(pose: SE3):
    identity = pose @ pose.inv()
    np.testing.assert_almost_equal(identity.as_matrix(), np.eye(4))


def is_SE3_multiple(poses: SE3):
    identities = poses @ poses.inv()
    answer = np.eye(4)[None, ...].repeat(len(poses), axis=0)
    np.testing.assert_almost_equal(identities.as_matrix(), answer)


def test_SE3_multiply():
    is_SE3(pose_single @ pose_single)
    is_SE3_multiple(pose_single @ pose_multiple)
    is_SE3_multiple(pose_multiple @ pose_multiple)


def test_SO3_generation():
    xyzw = SO3.random().as_quat()
    rot = SO3.from_xyzw(xyzw)
    assert isinstance(rot, SO3)
    wxyz = rot.as_wxyz()
    xyzw2 = np.roll(wxyz, shift=-1)
    np.testing.assert_almost_equal(xyzw, xyzw2)


def test_SO3_from_euler_returns_SO3():
    rot = SO3.from_euler("xyz", [0.1, 0.2, 0.3])
    assert isinstance(rot, SO3)
    assert hasattr(rot, "as_wxyz")


def test_SO3_from_quat_returns_SO3():
    rot = SO3.from_quat([0.0, 0.0, 0.0, 1.0])
    assert isinstance(rot, SO3)
    assert hasattr(rot, "as_wxyz")


def test_SO3_identity_returns_SO3():
    rot = SO3.identity()
    assert isinstance(rot, SO3)
    assert hasattr(rot, "as_wxyz")


def test_SO3_matmul_rotation_returns_SO3():
    r1 = SO3.from_euler("xyz", [0.1, 0.2, 0.3])
    r2 = SO3.from_euler("xyz", [0.3, 0.1, 0.2])
    out = r1 @ r2
    assert isinstance(out, SO3)
    assert hasattr(out, "as_wxyz")


def test_SE3_accepts_scipy_rotation_and_normalizes_to_SO3():
    scipy_rot = Rotation.from_euler("xyz", [0.1, 0.2, 0.3])
    pose = SE3(rot=scipy_rot, trans=[1.0, 2.0, 3.0])
    assert isinstance(pose.rot, SO3)
    assert hasattr(pose.rot, "as_wxyz")


def test_SE3_default_constructor_uses_SO3():
    pose = SE3()
    assert isinstance(pose.rot, SO3)
    assert hasattr(pose.rot, "as_wxyz")


def test_equal():
    T = SE3.random()
    assert T == T
    T = SE3.random(10)
    assert all(T == T)
