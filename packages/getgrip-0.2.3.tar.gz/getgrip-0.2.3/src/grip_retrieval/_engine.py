"""Multi-signal text retrieval pipeline."""

import re
import math
import time
import numpy as np
from collections import defaultdict

# ─── Porter Stemmer (dependency-free, Martin Porter 1980) ─────────────────────

_STEM_CACHE = {}


def _porter_stem(word):
    """Minimal Porter stemmer — covers steps 1-3 (highest-value suffix rules)."""
    if len(word) <= 2:
        return word
    cached = _STEM_CACHE.get(word)
    if cached is not None:
        return cached

    w = word

    # Step 1a: plurals
    if w.endswith('sses'):
        w = w[:-2]
    elif w.endswith('ies'):
        w = w[:-2]  # ies → i
    elif w.endswith('ss'):
        pass
    elif w.endswith('s') and len(w) > 3:
        w = w[:-1]

    # Helper: count consonant-vowel sequences (measure)
    def _m(stem):
        """Count VC sequences in stem."""
        vowels = set('aeiou')
        n, prev_v = 0, False
        for ch in stem:
            is_v = ch in vowels or (ch == 'y' and not prev_v)
            if prev_v and not is_v:
                n += 1
            prev_v = is_v
        return n

    def _has_vowel(stem):
        vowels = set('aeiou')
        for i, ch in enumerate(stem):
            if ch in vowels or (ch == 'y' and i > 0):
                return True
        return False

    # Step 1b: -eed, -ed, -ing
    if w.endswith('eed'):
        base = w[:-3]
        if _m(base) > 0:
            w = w[:-1]  # eed → ee
    elif w.endswith('ed'):
        base = w[:-2]
        if _has_vowel(base):
            w = base
            # fixups
            if w.endswith(('at', 'bl', 'iz')):
                w += 'e'
            elif len(w) >= 2 and w[-1] == w[-2] and w[-1] not in 'lsz':
                w = w[:-1]
    elif w.endswith('ing'):
        base = w[:-3]
        if _has_vowel(base):
            w = base
            if w.endswith(('at', 'bl', 'iz')):
                w += 'e'
            elif len(w) >= 2 and w[-1] == w[-2] and w[-1] not in 'lsz':
                w = w[:-1]

    # Step 1c: y → i when stem has vowel
    if w.endswith('y') and len(w) > 2 and _has_vowel(w[:-1]):
        w = w[:-1] + 'i'

    # Step 2: double suffixes (only highest-value ones)
    _step2 = [
        ('ational', 'ate'), ('tional', 'tion'), ('enci', 'ence'),
        ('anci', 'ance'), ('izer', 'ize'), ('isation', 'ize'),
        ('ization', 'ize'), ('ation', 'ate'), ('ator', 'ate'),
        ('alism', 'al'), ('iveness', 'ive'), ('fulness', 'ful'),
        ('ousli', 'ous'), ('ousn', 'ous'),
        ('alli', 'al'), ('entli', 'ent'), ('eli', 'e'),
        ('iviti', 'ive'), ('biliti', 'ble'),
    ]
    for suffix, repl in _step2:
        if w.endswith(suffix):
            base = w[:-len(suffix)]
            if _m(base) > 0:
                w = base + repl
            break

    # Step 3: -icate, -ative, -alize, -iciti, -ical, -ful, -ness
    _step3 = [
        ('icate', 'ic'), ('ative', ''), ('alize', 'al'),
        ('iciti', 'ic'), ('ical', 'ic'), ('ful', ''), ('ness', ''),
    ]
    for suffix, repl in _step3:
        if w.endswith(suffix):
            base = w[:-len(suffix)]
            if _m(base) > 0:
                w = base + repl
            break

    # Step 4: remove final suffixes (m > 1)
    _step4 = [
        'al', 'ance', 'ence', 'er', 'ic', 'able', 'ible', 'ant',
        'ement', 'ment', 'ent', 'ism', 'ate', 'iti', 'ous', 'ive', 'ize',
    ]
    for suffix in _step4:
        if w.endswith(suffix):
            base = w[:-len(suffix)]
            if _m(base) > 1:
                # Special: -ion requires s or t before it
                w = base
            break
    # Special: -ion (sion/tion only)
    if w.endswith('ion'):
        base = w[:-3]
        if _m(base) > 1 and len(base) > 0 and base[-1] in 'st':
            w = base

    # Step 5a: remove trailing 'e'
    if w.endswith('e'):
        base = w[:-1]
        m_base = _m(base)
        if m_base > 1:
            w = base
        elif m_base == 1:
            # Don't remove if stem ends CVC where C is not w/x/y
            if len(base) >= 3:
                vowels = set('aeiou')
                c1 = base[-1] not in vowels and base[-1] != 'y'
                v = base[-2] in vowels or (base[-2] == 'y' and len(base) > 3)
                c0 = base[-3] not in vowels
                if not (c0 and v and c1 and base[-1] not in 'wxy'):
                    w = base

    # Step 5b: -ll → -l when m > 1
    if w.endswith('ll') and _m(w[:-1]) > 1:
        w = w[:-1]

    _STEM_CACHE[word] = w
    return w


# ─── State ────────────────────────────────────────────────────────────────────
_postings_idx = {}      # term -> np.int32 array of doc indices
_postings_tf = {}       # term -> np.float32 array of TF values
_doc_len = None         # np.float32 (N,)
_idf = {}               # term -> float IDF
_doc_ids = []           # index -> BEIR doc_id string
_doc_texts = {}         # doc_id -> lowered full text (for fine scoring)
_doc_titles = {}        # doc_id -> lowered title
_N = 0
_avgdl = 1.0
_indexed = False

_TOKEN_RE = re.compile(r'[a-z0-9]+')

_STOP = frozenset({
    'a', 'an', 'and', 'are', 'as', 'at', 'be', 'been', 'being', 'but', 'by',
    'can', 'could', 'did', 'do', 'does', 'for', 'from', 'had', 'has', 'have',
    'he', 'her', 'him', 'his', 'how', 'i', 'if', 'in', 'into', 'is', 'it',
    'its', 'may', 'me', 'might', 'my', 'no', 'not', 'of', 'on', 'or', 'our',
    'shall', 'she', 'should', 'so', 'some', 'such', 'than', 'that', 'the',
    'their', 'them', 'then', 'there', 'these', 'they', 'this', 'those', 'to',
    'us', 'very', 'was', 'we', 'were', 'what', 'when', 'where', 'which',
    'while', 'who', 'whom', 'why', 'will', 'with', 'would', 'you', 'your',
})


def _tokenize(text):
    """Tokenize + Porter stem. Stems are cached for speed."""
    raw = _TOKEN_RE.findall(text.lower())
    return [_porter_stem(t) if t.isalpha() else t for t in raw]


def _tokenize_raw(text):
    """Tokenize WITHOUT stemming (for fine-scoring string searches)."""
    return _TOKEN_RE.findall(text.lower())


# ─── Indexing ─────────────────────────────────────────────────────────────────

def index_corpus(corpus):
    """
    Index a BEIR corpus for RT pipeline retrieval.
    corpus: {doc_id: {"title": str, "text": str}}
    """
    global _postings_idx, _postings_tf, _doc_len, _idf
    global _doc_ids, _doc_texts, _doc_titles, _N, _avgdl, _indexed

    _N = len(corpus)
    _doc_ids = list(corpus.keys())

    t0 = time.time()
    print(f"    RT indexing {_N:,} documents...", end="", flush=True)

    # Single pass: tokenize, build posting lists, store texts
    post_build = defaultdict(list)   # term -> [(doc_idx, tf), ...]
    _doc_len = np.zeros(_N, dtype=np.float32)
    _doc_texts = {}
    _doc_titles = {}
    _id_to_idx = {}

    for i, doc_id in enumerate(_doc_ids):
        doc = corpus[doc_id]
        title = doc.get("title", "")
        text = doc.get("text", "")
        full = (title + " " + text).strip()

        _doc_texts[doc_id] = full.lower()
        _doc_titles[doc_id] = title.lower()
        _id_to_idx[doc_id] = i

        tokens = _tokenize(full)
        _doc_len[i] = len(tokens)

        from collections import Counter
        tf = Counter(tokens)
        for term, count in tf.items():
            post_build[term].append((i, count))

        if (i + 1) % 500_000 == 0:
            print(f" {i + 1:,}...", end="", flush=True)

    _avgdl = float(np.mean(_doc_len)) if _N > 0 else 1.0

    # Convert posting lists to numpy arrays + compute IDF
    _postings_idx = {}
    _postings_tf = {}
    _idf = {}

    for term, pairs in post_build.items():
        arr = np.array(pairs, dtype=np.int32)
        _postings_idx[term] = arr[:, 0].copy()
        _postings_tf[term] = arr[:, 1].astype(np.float32)
        df = len(pairs)
        _idf[term] = math.log((_N - df + 0.5) / (df + 0.5) + 1.0)

    del post_build

    elapsed = time.time() - t0
    n_terms = len(_idf)
    total_postings = sum(len(v) for v in _postings_idx.values())
    print(f" done ({elapsed:.1f}s, {n_terms:,} terms, {total_postings:,} postings)")

    _indexed = True


# ─── Stage 1: Broad Scoring (vectorized IDF overlap) ─────────────────────────

# BM25 parameters for Stage 1 base score
_K1 = 1.2
_B = 0.75

def _broad_score(query_tokens, top_n=500):
    """
    Vectorized IDF scoring across all posting lists.
    Returns top-N (doc_idx, base_score) pairs.
    """
    scores = np.zeros(_N, dtype=np.float64)
    hit_counts = np.zeros(_N, dtype=np.int32)

    substantive = [t for t in set(query_tokens) if t not in _STOP and len(t) >= 2]
    if not substantive:
        substantive = list(set(query_tokens))[:5]

    for term in substantive:
        if term not in _postings_idx:
            continue

        idx = _postings_idx[term]
        tf = _postings_tf[term]
        dl = _doc_len[idx]
        idf = _idf.get(term, 0.0)

        # BM25-style TF normalization for base score
        tf_norm = (tf * (_K1 + 1.0)) / (tf + _K1 * (1.0 - _B + _B * dl / _avgdl))
        scores[idx] += idf * tf_norm
        hit_counts[idx] += 1

    # Boost: docs matching more query terms get a multiplicative bonus
    n_subst = max(len(substantive), 1)
    multi_match = hit_counts.astype(np.float64) / n_subst
    # Quadratic coverage bonus (from demo_rt_cores.py scoring)
    scores *= (0.5 + 0.5 * multi_match)

    # Top-N via argpartition
    n_nonzero = int(np.count_nonzero(scores))
    if n_nonzero == 0:
        return []

    k = min(top_n, n_nonzero, _N)
    if k < _N:
        top_idx = np.argpartition(-scores, k)[:k]
    else:
        top_idx = np.arange(_N)
    top_idx = top_idx[np.argsort(-scores[top_idx])]

    return [(int(i), float(scores[i])) for i in top_idx if scores[i] > 0]


# ─── Stage 2: Multi-Signal Fine Scoring ──────────────────────────────────────

def _fine_score(query_tokens, candidates, raw_tokens=None):
    """
    Multi-signal rescoring on top candidates.
    Adapted from demo_rt_cores.py rescore_candidates().

    Applies phrase, compound, density, absence-penalty, all-present signals
    on top of the Stage 1 base score.

    query_tokens: stemmed tokens (for IDF lookup)
    raw_tokens: unstemmed tokens (for phrase/compound/density string search)
    """
    # Raw tokens for string-match signals (phrase, compound, density)
    raw = raw_tokens if raw_tokens is not None else query_tokens

    # Build substantive token list (stemmed for IDF, raw for content search)
    substantive = []
    for tok in set(query_tokens):
        if tok in _STOP or len(tok) < 2:
            continue
        idf = _idf.get(tok, 8.0)
        if idf > 0.3:
            substantive.append((tok, idf))
    if not substantive:
        return candidates  # Return base scores as-is

    # Raw substantive tokens for content.count() — need the unstemmed forms
    raw_substantive = []
    for tok in set(raw):
        if tok not in _STOP and len(tok) >= 2:
            raw_substantive.append(tok)

    total_idf = sum(idf for _, idf in substantive) or 1.0

    # Build phrases from RAW tokens (Signal 4) — exact string match in content
    phrases = []
    for i in range(len(raw) - 1):
        if raw[i] not in _STOP and raw[i + 1] not in _STOP:
            phrases.append(raw[i] + ' ' + raw[i + 1])

    # Build compounds from RAW tokens (Signal 3)
    compounds = []
    for i in range(len(raw) - 1):
        if raw[i] not in _STOP and raw[i + 1] not in _STOP:
            compounds.append(raw[i] + '_' + raw[i + 1])

    scored = []
    for doc_idx, base_score in candidates:
        doc_id = _doc_ids[doc_idx]
        content = _doc_texts.get(doc_id, "")
        title = _doc_titles.get(doc_id, "")

        bonus = 0.0

        # ── Signal 2b: Content density (raw tokens in raw content) ────
        for tok in raw_substantive:
            count = content.count(tok)
            if count > 1:
                idf = _idf.get(_porter_stem(tok), 8.0) if tok.isalpha() else 8.0
                bonus += (idf / total_idf) * math.log1p(count) * 0.3

        # ── Signal 3: Compound token match (raw) ─────────────────────
        for c in compounds:
            if c in content:
                bonus += 0.5

        # ── Signal 4: Phrase bonus (raw) ──────────────────────────────
        for p in phrases:
            if p in content:
                bonus += 0.4

        # ── Title match (raw tokens for string match) ─────────────────
        if title:
            for tok in raw_substantive:
                if tok in title:
                    idf = _idf.get(_porter_stem(tok), 8.0) if tok.isalpha() else 8.0
                    bonus += min(idf * 0.1, 1.0)

        # ── Signal 5b: Absence penalty (raw in raw content) ────
        if len(raw_substantive) >= 2:
            # Use stemmed IDF to find rarest, but raw token for content check
            rarest_raw = max(raw_substantive,
                             key=lambda t: _idf.get(_porter_stem(t), 8.0) if t.isalpha() else 8.0)
            if rarest_raw not in content:
                bonus *= 0.5

        # ── Signal 6: All-present bonus (raw in raw content) ──────────
        all_present = all(tok in content for tok in raw_substantive)
        if all_present and len(raw_substantive) >= 2:
            bonus += 0.3

        scored.append((doc_idx, base_score + bonus))

    return scored


# ─── Retrieval ────────────────────────────────────────────────────────────────

def retrieve(query, top_k=100):
    """
    RT pipeline retrieval: Stage 1 (broad) + Stage 2 (fine).

    Returns: [{"doc_id": str, "score": float}, ...]
    """
    if not _indexed:
        return []

    query_tokens = _tokenize(query)        # stemmed (for BM25 posting lists)
    raw_tokens = _tokenize_raw(query)      # unstemmed (for fine-scoring string match)
    if not query_tokens:
        return []

    # Stage 1: Vectorized broad scoring (BM25-like base, all posting lists)
    broad_candidates = _broad_score(query_tokens, top_n=500)
    if not broad_candidates:
        return []

    # Stage 2: Multi-signal fine scoring on top candidates
    fine_candidates = _fine_score(query_tokens, broad_candidates, raw_tokens=raw_tokens)

    # Sort by final score
    fine_candidates.sort(key=lambda x: -x[1])

    return [{"doc_id": _doc_ids[idx], "score": float(s)}
            for idx, s in fine_candidates[:top_k] if s > 0]
