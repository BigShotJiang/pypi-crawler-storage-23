from __future__ import annotations

"""Source manager — single source of truth for what's indexed.

Owns the corpus via SQLite. Handles persistence and re-indexing.
SQLite instead of pickle: crash-safe, not executable, stdlib.
"""

import hashlib
import json
import sqlite3
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from . import _engine as _rt

from .models import Source

MAX_CHUNKS = 500_000  # Safe for 16GB RAM with RT pipeline


class SourceManager:
    """Manages ingested sources, corpus, and index lifecycle."""

    def __init__(self, data_dir: Optional[str] = None, chunk_limit: int = MAX_CHUNKS,
                 preserve_learning: bool = False):
        """
        Args:
            data_dir: Where to store corpus.db and sources.json.
            chunk_limit: Maximum allowed chunks (from license tier).
            preserve_learning: If True, co-occurrence and remember data
                survive chunk deletion (licensed tier behavior).
        """
        if data_dir is None:
            data_dir = str(Path(__file__).resolve().parent.parent / "_data")
        self._data_dir = Path(data_dir)
        self._chunk_limit = chunk_limit
        self._preserve_learning = preserve_learning
        self._data_dir.mkdir(parents=True, exist_ok=True)

        # Sources manifest (human-readable JSON)
        self.sources: dict[str, dict] = {}

        # SQLite corpus store
        self._db = sqlite3.connect(
            str(self._data_dir / "corpus.db"),
            check_same_thread=False,
        )
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("""
            CREATE TABLE IF NOT EXISTS chunks (
                doc_id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                text TEXT NOT NULL,
                source_name TEXT NOT NULL,
                source_file TEXT NOT NULL,
                line INTEGER
            )
        """)
        self._db.execute("""
            CREATE TABLE IF NOT EXISTS remembered (
                query_hash TEXT PRIMARY KEY,
                query_text TEXT NOT NULL,
                top_doc_ids TEXT NOT NULL,
                confidence TEXT NOT NULL,
                hit_count INTEGER DEFAULT 1,
                last_used TEXT NOT NULL
            )
        """)
        self._db.commit()

        # Expander is set externally by server.py after construction
        self._expander = None

        self._load_state()

    # ─── Persistence ─────────────────────────────────────────────────────

    def _sources_path(self) -> Path:
        return self._data_dir / "sources.json"

    def _load_state(self):
        """Restore sources manifest and rebuild index from SQLite in background."""
        sp = self._sources_path()
        if sp.exists():
            try:
                self.sources = json.loads(sp.read_text(encoding="utf-8"))
            except Exception:
                self.sources = {}

        # Rebuild index in background so server starts accepting requests immediately
        corpus = self._get_corpus_dict()
        if corpus:
            self._indexing = True
            t = threading.Thread(target=self._background_index, args=(corpus,), daemon=True)
            t.start()

    def _background_index(self, corpus: dict):
        """Index corpus in background thread."""
        try:
            n = len(corpus)
            print(f"  Background indexing {n:,} chunks...")
            t0 = time.time()
            _rt.index_corpus(corpus)
            elapsed = time.time() - t0
            print(f"  Background indexing complete: {n:,} chunks in {elapsed:.1f}s")
        except Exception as e:
            print(f"  Background indexing failed: {e}")
        finally:
            self._indexing = False

    def _save_sources(self):
        """Persist sources manifest to JSON."""
        self._sources_path().write_text(
            json.dumps(self.sources, indent=2), encoding="utf-8"
        )

    def _get_corpus_dict(self) -> dict[str, dict]:
        """Load full corpus from SQLite as {doc_id: {"title", "text"}}."""
        rows = self._db.execute("SELECT doc_id, title, text FROM chunks").fetchall()
        return {row[0]: {"title": row[1], "text": row[2]} for row in rows}

    # ─── Mutations ───────────────────────────────────────────────────────

    @property
    def chunk_limit(self) -> int:
        return self._chunk_limit

    def add_chunks(
        self,
        source_name: str,
        source_type: str,
        source_path: str,
        chunks: list[dict],
    ) -> dict:
        """Add chunks from a source. Triggers re-index.

        chunks: list of {"doc_id", "title", "text", "source_file", "line", ...}
        Returns: {"chunks": N, "files": N, "index_time_ms": N}
        Raises: ValueError if chunk limit would be exceeded.
        """
        # Enforce chunk limit
        current = self.total_chunks
        if current + len(chunks) > self._chunk_limit:
            raise ValueError(
                f"Chunk limit exceeded: {current:,} + {len(chunks):,} = "
                f"{current + len(chunks):,} > {self._chunk_limit:,} limit. "
                f"Upgrade at https://getgrip.dev/pricing"
            )

        files_seen = set()

        self._db.executemany(
            "INSERT OR REPLACE INTO chunks (doc_id, title, text, source_name, source_file, line) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            [
                (
                    c["doc_id"],
                    c.get("title", ""),
                    c["text"],
                    source_name,
                    c.get("source_file", source_path),
                    c.get("line"),
                )
                for c in chunks
            ],
        )
        self._db.commit()

        for c in chunks:
            sf = c.get("source_file", "")
            if sf:
                files_seen.add(sf)

        n_files = len(files_seen) or 1

        self.sources[source_name] = {
            "type": source_type,
            "path": source_path,
            "chunks": len(chunks),
            "files": n_files,
            "ingested_at": datetime.now(timezone.utc).isoformat(),
        }

        t0 = time.time()
        self.rebuild_index()
        index_ms = (time.time() - t0) * 1000

        self._save_sources()

        return {"chunks": len(chunks), "files": n_files, "index_time_ms": index_ms}

    def remove_source(self, name: str) -> dict:
        """Remove a source and its chunks. Triggers re-index.

        If preserve_learning is False (free tier), also clears co-occurrence
        and remembered data for the removed chunks. If True (licensed tier),
        learned data persists — this is the core paid feature.

        Returns: {"removed": 1, "chunks_removed": N}
        """
        if name not in self.sources:
            return {"removed": 0, "chunks_removed": 0}

        # Count before delete
        row = self._db.execute(
            "SELECT COUNT(*) FROM chunks WHERE source_name = ?", (name,)
        ).fetchone()
        n_removed = row[0] if row else 0

        # Free tier: also clear learned data when chunks are deleted
        if not self._preserve_learning:
            self._db.execute("DELETE FROM remembered")
            self._db.execute("DELETE FROM cooccurrence")

        self._db.execute("DELETE FROM chunks WHERE source_name = ?", (name,))
        self._db.commit()

        del self.sources[name]

        if self.total_chunks > 0:
            # Free tier: skip co-occurrence rebuild (keep it cleared)
            # Licensed tier: merge co-occurrence (preserve old + add remaining)
            self.rebuild_index(skip_learning=not self._preserve_learning)
        else:
            self._reset_rt_index()

        self._save_sources()

        return {"removed": 1, "chunks_removed": n_removed}

    def remove_all(self) -> dict:
        """Clear everything. Returns: {"removed": N, "chunks_removed": N}"""
        n_sources = len(self.sources)

        row = self._db.execute("SELECT COUNT(*) FROM chunks").fetchone()
        n_chunks = row[0] if row else 0

        self._db.execute("DELETE FROM chunks")

        # Free tier: also clear learned data
        if not self._preserve_learning:
            self._db.execute("DELETE FROM remembered")
            self._db.execute("DELETE FROM cooccurrence")

        self._db.commit()

        self.sources.clear()
        self._reset_rt_index()
        self._save_sources()

        return {"removed": n_sources, "chunks_removed": n_chunks}

    def _reset_rt_index(self):
        """Reset the RT pipeline to empty state."""
        _rt._indexed = False
        _rt._postings_idx.clear()
        _rt._postings_tf.clear()
        _rt._idf.clear()
        _rt._doc_ids.clear()
        _rt._doc_texts.clear()
        _rt._doc_titles.clear()
        _rt._N = 0

    # ─── Queries ─────────────────────────────────────────────────────────

    def get_sources(self) -> list[Source]:
        """List all sources with stats."""
        result = []
        for name, info in self.sources.items():
            result.append(Source(
                name=name,
                type=info["type"],
                path=info["path"],
                chunks=info["chunks"],
                files=info["files"],
                ingested_at=info["ingested_at"],
            ))
        return result

    def get_chunk_text(self, doc_id: str) -> str:
        """Get the text content of a chunk."""
        row = self._db.execute(
            "SELECT text FROM chunks WHERE doc_id = ?", (doc_id,)
        ).fetchone()
        return row[0] if row else ""

    def get_chunk_meta(self, doc_id: str) -> dict:
        """Get metadata (source_name, source_file, line) for a chunk."""
        row = self._db.execute(
            "SELECT source_name, source_file, line FROM chunks WHERE doc_id = ?",
            (doc_id,),
        ).fetchone()
        if not row:
            return {}
        return {"source_name": row[0], "source_file": row[1], "line": row[2]}

    @property
    def total_chunks(self) -> int:
        row = self._db.execute("SELECT COUNT(*) FROM chunks").fetchone()
        return row[0] if row else 0

    @property
    def total_sources(self) -> int:
        return len(self.sources)

    @property
    def indexing(self) -> bool:
        """True if an indexing operation is in progress."""
        return getattr(self, "_indexing", False)

    # ─── Index ───────────────────────────────────────────────────────────

    def rebuild_index(self, skip_learning: bool = False):
        """Rebuild the RT pipeline index from SQLite corpus.

        Args:
            skip_learning: If True, skip co-occurrence rebuild (free tier
                after delete — keep learning data cleared).
        """
        self._indexing = True
        try:
            n = self.total_chunks
            if n > MAX_CHUNKS:
                print(f"  WARNING: {n:,} chunks exceeds recommended max "
                      f"({MAX_CHUNKS:,}). Consider removing sources or "
                      f"increasing RAM.")

            corpus = self._get_corpus_dict()
            if corpus:
                _rt.index_corpus(corpus)

            # Rebuild co-occurrence graph for query expansion
            if not skip_learning and self._expander is not None:
                self._expander.build_from_corpus(
                    self._db, merge=self._preserve_learning
                )
        finally:
            self._indexing = False

    # ─── Remember / Recall ────────────────────────────────────────────

    def remember(self, query: str, top_doc_ids: list[str], confidence: str):
        """Store a successful query. Only called on HIGH confidence."""
        query_hash = self._hash_query(query)
        now = datetime.now(timezone.utc).isoformat()
        doc_ids_json = json.dumps(top_doc_ids)

        existing = self._db.execute(
            "SELECT hit_count FROM remembered WHERE query_hash = ?",
            (query_hash,),
        ).fetchone()

        if existing:
            self._db.execute(
                "UPDATE remembered SET hit_count = hit_count + 1, "
                "last_used = ?, top_doc_ids = ?, confidence = ? "
                "WHERE query_hash = ?",
                (now, doc_ids_json, confidence, query_hash),
            )
        else:
            self._db.execute(
                "INSERT INTO remembered "
                "(query_hash, query_text, top_doc_ids, confidence, hit_count, last_used) "
                "VALUES (?, ?, ?, ?, 1, ?)",
                (query_hash, query, doc_ids_json, confidence, now),
            )
        self._db.commit()

    def recall(self, query: str) -> tuple[list[str], int]:
        """Check if a similar query was asked before.

        Returns (list of remembered doc_ids, hit_count).
        Matching: tokenize query, sort stems, hash.
        """
        query_hash = self._hash_query(query)
        row = self._db.execute(
            "SELECT top_doc_ids, hit_count FROM remembered WHERE query_hash = ?",
            (query_hash,),
        ).fetchone()

        if row:
            doc_ids = json.loads(row[0])
            return doc_ids, row[1]
        return [], 0

    def _hash_query(self, query: str) -> str:
        """Normalize: lowercase, tokenize, sort stems, hash."""
        tokens = _rt._tokenize(query)
        # Sort for order-independence ("heap overflow bluetooth" == "bluetooth heap overflow")
        normalized = " ".join(sorted(set(tokens)))
        return hashlib.sha256(normalized.encode()).hexdigest()[:16]

    @property
    def memory_warning(self) -> str | None:
        """Return warning string if corpus exceeds recommended size."""
        n = self.total_chunks
        if n > MAX_CHUNKS:
            return (f"Corpus ({n:,} chunks) exceeds recommended max "
                    f"({MAX_CHUNKS:,}). Performance may degrade.")
        return None
