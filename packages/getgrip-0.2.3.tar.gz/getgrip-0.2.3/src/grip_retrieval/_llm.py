#!/usr/bin/env python3
"""
MULTI-LLM BACKEND - Unified Interface for Any LLM
==================================================

One interface, any model:
- Ollama (local)
- OpenAI (GPT-4, GPT-3.5)
- Anthropic (Claude)
- Groq (fast inference)

Usage:
    from grip_retrieval._llm import get_llm, LLMResponse

    # Auto-detect available backend
    llm = get_llm()

    # Or specify
    llm = get_llm("ollama", model="qwen2.5-coder:32b")
    llm = get_llm("openai", model="gpt-4")
    llm = get_llm("anthropic", model="claude-3-sonnet")
    llm = get_llm("groq", model="llama-3.1-70b")

    # Query (same interface for all)
    response = llm.generate("What is kmalloc?", context="...")
    print(response.text)
    print(f"Tokens: {response.tokens_used}, Latency: {response.latency_ms}ms")

    # Streaming
    for chunk in llm.stream("Explain mutex_lock"):
        print(chunk, end="", flush=True)

"""

import os
import time
import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, Iterator, List, Dict, Any
from pathlib import Path

# Optional imports - graceful degradation
OLLAMA_AVAILABLE = False
OPENAI_AVAILABLE = False
ANTHROPIC_AVAILABLE = False
GROQ_AVAILABLE = False
LLAMA_CPP_AVAILABLE = False

try:
    import requests
    OLLAMA_AVAILABLE = True  # Ollama uses requests
except ImportError:
    pass

try:
    from llama_cpp import Llama
    LLAMA_CPP_AVAILABLE = True
except ImportError:
    pass

try:
    import openai
    OPENAI_AVAILABLE = True
except ImportError:
    pass

try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    pass

try:
    from groq import Groq
    GROQ_AVAILABLE = True
except ImportError:
    pass


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class LLMResponse:
    """Unified response from any LLM."""
    text: str
    model: str
    backend: str
    tokens_used: int
    latency_ms: float
    finish_reason: str = "complete"
    raw_response: Any = None


@dataclass
class LLMConfig:
    """Configuration for LLM backend."""
    backend: str
    model: str
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    temperature: float = 0.3
    max_tokens: int = 1000
    timeout: int = 120


# =============================================================================
# ABSTRACT BASE
# =============================================================================

class LLMBackend(ABC):
    """Abstract base class for LLM backends."""

    def __init__(self, config: LLMConfig):
        self.config = config
        self.total_tokens = 0
        self.total_requests = 0

    @property
    def backend_name(self) -> str:
        """Get the backend name."""
        return self.config.backend

    @property
    def model(self) -> str:
        """Get the model name."""
        return self.config.model

    @abstractmethod
    def generate(self, prompt: str, system: Optional[str] = None,
                context: Optional[str] = None) -> LLMResponse:
        """Generate a response from the LLM."""
        pass

    @abstractmethod
    def stream(self, prompt: str, system: Optional[str] = None,
              context: Optional[str] = None) -> Iterator[str]:
        """Stream a response from the LLM."""
        pass

    def build_prompt(self, prompt: str, system: Optional[str] = None,
                    context: Optional[str] = None) -> str:
        """Build full prompt with system and context."""
        parts = []
        if system:
            parts.append(f"System: {system}\n")
        if context:
            parts.append(f"Context:\n{context}\n")
        parts.append(f"User: {prompt}")
        return "\n".join(parts)

    def get_stats(self) -> Dict[str, Any]:
        """Get usage statistics."""
        return {
            "backend": self.config.backend,
            "model": self.config.model,
            "total_tokens": self.total_tokens,
            "total_requests": self.total_requests,
        }


# =============================================================================
# OLLAMA BACKEND (Local)
# =============================================================================

class OllamaBackend(LLMBackend):
    """Ollama backend for local models."""

    DEFAULT_URL = "http://localhost:11434"

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        if not OLLAMA_AVAILABLE:
            raise ImportError(
                "requests package not installed. Run: pip install requests"
            )
        self.base_url = config.base_url or self.DEFAULT_URL

    def generate(self, prompt: str, system: Optional[str] = None,
                context: Optional[str] = None) -> LLMResponse:
        """Generate using Ollama API."""
        t0 = time.perf_counter()
        self.total_requests += 1

        full_prompt = self.build_prompt(prompt, system, context)

        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.config.model,
                    "prompt": full_prompt,
                    "stream": False,
                    "options": {
                        "temperature": self.config.temperature,
                        "num_predict": self.config.max_tokens,
                    }
                },
                timeout=self.config.timeout
            )

            if response.status_code == 200:
                data = response.json()
                text = data.get("response", "")
                tokens = data.get("eval_count", len(text) // 4)
                self.total_tokens += tokens

                return LLMResponse(
                    text=text,
                    model=self.config.model,
                    backend="ollama",
                    tokens_used=tokens,
                    latency_ms=(time.perf_counter() - t0) * 1000,
                    finish_reason=data.get("done_reason", "complete"),
                    raw_response=data
                )
            else:
                return LLMResponse(
                    text=f"Error: {response.status_code} - {response.text}",
                    model=self.config.model,
                    backend="ollama",
                    tokens_used=0,
                    latency_ms=(time.perf_counter() - t0) * 1000,
                    finish_reason="error"
                )
        except requests.exceptions.ConnectionError:
            return LLMResponse(
                text="Error: Cannot connect to Ollama. Is it running?",
                model=self.config.model,
                backend="ollama",
                tokens_used=0,
                latency_ms=(time.perf_counter() - t0) * 1000,
                finish_reason="error"
            )
        except Exception as e:
            return LLMResponse(
                text=f"Error: {e}",
                model=self.config.model,
                backend="ollama",
                tokens_used=0,
                latency_ms=(time.perf_counter() - t0) * 1000,
                finish_reason="error"
            )

    def stream(self, prompt: str, system: Optional[str] = None,
              context: Optional[str] = None) -> Iterator[str]:
        """Stream using Ollama API."""
        self.total_requests += 1
        full_prompt = self.build_prompt(prompt, system, context)

        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.config.model,
                    "prompt": full_prompt,
                    "stream": True,
                    "options": {
                        "temperature": self.config.temperature,
                        "num_predict": self.config.max_tokens,
                    }
                },
                stream=True,
                timeout=self.config.timeout
            )

            for line in response.iter_lines():
                if line:
                    data = json.loads(line)
                    chunk = data.get("response", "")
                    if chunk:
                        yield chunk
                    if data.get("done"):
                        self.total_tokens += data.get("eval_count", 0)
                        break
        except Exception as e:
            yield f"Error: {e}"

    @staticmethod
    def list_models() -> List[str]:
        """List available Ollama models."""
        try:
            response = requests.get("http://localhost:11434/api/tags", timeout=5)
            if response.status_code == 200:
                return [m["name"] for m in response.json().get("models", [])]
        except:
            pass
        return []


# =============================================================================
# OPENAI BACKEND
# =============================================================================

class OpenAIBackend(LLMBackend):
    """OpenAI API backend (GPT-4, GPT-3.5)."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        if not OPENAI_AVAILABLE:
            raise ImportError("openai package not installed. Run: pip install openai")

        api_key = config.api_key or os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OpenAI API key required. Set OPENAI_API_KEY env var.")

        self.client = openai.OpenAI(api_key=api_key)

    def generate(self, prompt: str, system: Optional[str] = None,
                context: Optional[str] = None) -> LLMResponse:
        """Generate using OpenAI API."""
        t0 = time.perf_counter()
        self.total_requests += 1

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        if context:
            messages.append({"role": "system", "content": f"Context:\n{context}"})
        messages.append({"role": "user", "content": prompt})

        try:
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )

            text = response.choices[0].message.content
            tokens = response.usage.total_tokens if response.usage else len(text) // 4
            self.total_tokens += tokens

            return LLMResponse(
                text=text,
                model=self.config.model,
                backend="openai",
                tokens_used=tokens,
                latency_ms=(time.perf_counter() - t0) * 1000,
                finish_reason=response.choices[0].finish_reason,
                raw_response=response
            )
        except Exception as e:
            return LLMResponse(
                text=f"Error: {e}",
                model=self.config.model,
                backend="openai",
                tokens_used=0,
                latency_ms=(time.perf_counter() - t0) * 1000,
                finish_reason="error"
            )

    def stream(self, prompt: str, system: Optional[str] = None,
              context: Optional[str] = None) -> Iterator[str]:
        """Stream using OpenAI API."""
        self.total_requests += 1

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        if context:
            messages.append({"role": "system", "content": f"Context:\n{context}"})
        messages.append({"role": "user", "content": prompt})

        try:
            stream = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
                stream=True,
            )

            for chunk in stream:
                if chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content
        except Exception as e:
            yield f"Error: {e}"


# =============================================================================
# ANTHROPIC BACKEND
# =============================================================================

class AnthropicBackend(LLMBackend):
    """Anthropic API backend (Claude)."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        if not ANTHROPIC_AVAILABLE:
            raise ImportError("anthropic package not installed. Run: pip install anthropic")

        api_key = config.api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError("Anthropic API key required. Set ANTHROPIC_API_KEY env var.")

        self.client = anthropic.Anthropic(api_key=api_key)

    def generate(self, prompt: str, system: Optional[str] = None,
                context: Optional[str] = None) -> LLMResponse:
        """Generate using Anthropic API."""
        t0 = time.perf_counter()
        self.total_requests += 1

        full_system = system or "You are a helpful assistant."
        if context:
            full_system += f"\n\nContext:\n{context}"

        try:
            response = self.client.messages.create(
                model=self.config.model,
                max_tokens=self.config.max_tokens,
                system=full_system,
                messages=[{"role": "user", "content": prompt}]
            )

            text = response.content[0].text
            tokens = response.usage.input_tokens + response.usage.output_tokens
            self.total_tokens += tokens

            return LLMResponse(
                text=text,
                model=self.config.model,
                backend="anthropic",
                tokens_used=tokens,
                latency_ms=(time.perf_counter() - t0) * 1000,
                finish_reason=response.stop_reason,
                raw_response=response
            )
        except Exception as e:
            return LLMResponse(
                text=f"Error: {e}",
                model=self.config.model,
                backend="anthropic",
                tokens_used=0,
                latency_ms=(time.perf_counter() - t0) * 1000,
                finish_reason="error"
            )

    def stream(self, prompt: str, system: Optional[str] = None,
              context: Optional[str] = None) -> Iterator[str]:
        """Stream using Anthropic API."""
        self.total_requests += 1

        full_system = system or "You are a helpful assistant."
        if context:
            full_system += f"\n\nContext:\n{context}"

        try:
            with self.client.messages.stream(
                model=self.config.model,
                max_tokens=self.config.max_tokens,
                system=full_system,
                messages=[{"role": "user", "content": prompt}]
            ) as stream:
                for text in stream.text_stream:
                    yield text
        except Exception as e:
            yield f"Error: {e}"


# =============================================================================
# GROQ BACKEND (Fast inference)
# =============================================================================

class GroqBackend(LLMBackend):
    """Groq API backend (fast inference)."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        if not GROQ_AVAILABLE:
            raise ImportError("groq package not installed. Run: pip install groq")

        api_key = config.api_key or os.environ.get("GROQ_API_KEY")
        if not api_key:
            raise ValueError("Groq API key required. Set GROQ_API_KEY env var.")

        self.client = Groq(api_key=api_key)

    def generate(self, prompt: str, system: Optional[str] = None,
                context: Optional[str] = None) -> LLMResponse:
        """Generate using Groq API."""
        t0 = time.perf_counter()
        self.total_requests += 1

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        if context:
            messages.append({"role": "system", "content": f"Context:\n{context}"})
        messages.append({"role": "user", "content": prompt})

        try:
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )

            text = response.choices[0].message.content
            tokens = response.usage.total_tokens if response.usage else len(text) // 4
            self.total_tokens += tokens

            return LLMResponse(
                text=text,
                model=self.config.model,
                backend="groq",
                tokens_used=tokens,
                latency_ms=(time.perf_counter() - t0) * 1000,
                finish_reason=response.choices[0].finish_reason,
                raw_response=response
            )
        except Exception as e:
            return LLMResponse(
                text=f"Error: {e}",
                model=self.config.model,
                backend="groq",
                tokens_used=0,
                latency_ms=(time.perf_counter() - t0) * 1000,
                finish_reason="error"
            )

    def stream(self, prompt: str, system: Optional[str] = None,
              context: Optional[str] = None) -> Iterator[str]:
        """Stream using Groq API."""
        self.total_requests += 1

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        if context:
            messages.append({"role": "system", "content": f"Context:\n{context}"})
        messages.append({"role": "user", "content": prompt})

        try:
            stream = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
                stream=True,
            )

            for chunk in stream:
                if chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content
        except Exception as e:
            yield f"Error: {e}"


# =============================================================================
# LOCAL BACKEND (Built-in, no setup)
# =============================================================================

class LocalLLMBackend(LLMBackend):
    """Built-in LLM backend using llama-cpp-python. Zero setup."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        if not LLAMA_CPP_AVAILABLE:
            raise ImportError(
                "llama-cpp-python is required for the built-in model.\n"
                "Install with: pip install llama-cpp-python"
            )
        from .grip_local_llm import LocalBackend
        self._local = LocalBackend()

    def generate(self, prompt: str, system: Optional[str] = None,
                context: Optional[str] = None) -> LLMResponse:
        t0 = time.perf_counter()
        self.total_requests += 1
        result = self._local.generate(prompt, system=system, context=context)
        tokens = result.get("tokens_used", 0)
        self.total_tokens += tokens
        return LLMResponse(
            text=result["text"],
            model=result.get("model", "qwen2.5-1.5b-instruct"),
            backend="local",
            tokens_used=tokens,
            latency_ms=(time.perf_counter() - t0) * 1000,
            finish_reason=result.get("finish_reason", "stop"),
        )

    def stream(self, prompt: str, system: Optional[str] = None,
              context: Optional[str] = None) -> Iterator[str]:
        self.total_requests += 1
        yield from self._local.stream(prompt, system=system, context=context)


# =============================================================================
# FACTORY FUNCTION
# =============================================================================

# Default models for each backend
DEFAULT_MODELS = {
    "local": "qwen2.5-1.5b-instruct",
    "ollama": "qwen2.5-coder:32b",
    "openai": "gpt-4o",
    "anthropic": "claude-3-5-sonnet-20241022",
    "groq": "llama-3.3-70b-versatile",
}


def get_available_backends() -> List[str]:
    """Get list of available backends."""
    available = []
    if LLAMA_CPP_AVAILABLE:
        available.append("local")
    if OLLAMA_AVAILABLE:
        # Check if Ollama is actually running
        try:
            import requests
            r = requests.get("http://localhost:11434/api/tags", timeout=2)
            if r.status_code == 200:
                available.append("ollama")
        except:
            pass
    if OPENAI_AVAILABLE and os.environ.get("OPENAI_API_KEY"):
        available.append("openai")
    if ANTHROPIC_AVAILABLE and os.environ.get("ANTHROPIC_API_KEY"):
        available.append("anthropic")
    if GROQ_AVAILABLE and os.environ.get("GROQ_API_KEY"):
        available.append("groq")
    return available


def get_llm(backend: Optional[str] = None, model: Optional[str] = None,
           **kwargs) -> LLMBackend:
    """
    Get an LLM backend instance.

    Args:
        backend: "ollama", "openai", "anthropic", "groq", or None for auto-detect
        model: Model name, or None for default
        **kwargs: Additional config options (temperature, max_tokens, api_key, etc.)

    Returns:
        LLMBackend instance ready to use

    Example:
        llm = get_llm()  # Auto-detect
        llm = get_llm("ollama", model="llama3:8b")
        llm = get_llm("openai", model="gpt-4", temperature=0.7)
    """
    # Auto-detect if no backend specified
    if backend is None:
        available = get_available_backends()
        if not available:
            raise RuntimeError("No LLM backends available. Install ollama or set API keys.")
        backend = available[0]

    # Get default model if not specified
    if model is None:
        model = DEFAULT_MODELS.get(backend, "default")

    # Build config
    config = LLMConfig(
        backend=backend,
        model=model,
        api_key=kwargs.get("api_key"),
        base_url=kwargs.get("base_url"),
        temperature=kwargs.get("temperature", 0.3),
        max_tokens=kwargs.get("max_tokens", 1000),
        timeout=kwargs.get("timeout", 120),
    )

    # Create backend
    if backend == "local":
        return LocalLLMBackend(config)
    elif backend == "ollama":
        return OllamaBackend(config)
    elif backend == "openai":
        return OpenAIBackend(config)
    elif backend == "anthropic":
        return AnthropicBackend(config)
    elif backend == "groq":
        return GroqBackend(config)
    else:
        raise ValueError(f"Unknown backend: {backend}")


# =============================================================================
# CLI DEMO
# =============================================================================

def main():
    """Demo the LLM backends."""
    print("=" * 60)
    print("MULTI-LLM BACKEND")
    print("=" * 60)

    # Check available backends
    available = get_available_backends()
    print(f"\nAvailable backends: {available}")

    if not available:
        print("\nNo backends available!")
        print("- For Ollama: ollama serve")
        print("- For OpenAI: export OPENAI_API_KEY=...")
        print("- For Anthropic: export ANTHROPIC_API_KEY=...")
        print("- For Groq: export GROQ_API_KEY=...")
        return

    # Get default LLM
    llm = get_llm()
    print(f"\nUsing: {llm.config.backend} / {llm.config.model}")

    # Test generation
    print("\n" + "-" * 60)
    print("Testing generation...")
    response = llm.generate(
        "What is 2+2? Answer in one word.",
        system="You are a helpful assistant. Be concise."
    )
    print(f"Response: {response.text}")
    print(f"Tokens: {response.tokens_used}, Latency: {response.latency_ms:.0f}ms")

    # Test streaming
    print("\n" + "-" * 60)
    print("Testing streaming...")
    print("Response: ", end="", flush=True)
    for chunk in llm.stream("Count from 1 to 5."):
        print(chunk, end="", flush=True)
    print()

    # Stats
    print("\n" + "-" * 60)
    print("Stats:", llm.get_stats())


if __name__ == "__main__":
    main()
