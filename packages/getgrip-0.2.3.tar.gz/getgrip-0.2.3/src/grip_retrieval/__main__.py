"""Allow running as: python -m grip_retrieval"""


def main():
    import uvicorn
    from .server import app  # noqa: F401
    uvicorn.run(app, host="0.0.0.0", port=7878)


if __name__ == "__main__":
    main()
