"""LLM answer generation with confidence-aware prompting."""

from typing import Optional

from ._llm import get_llm, LLMBackend


_SYSTEM_PROMPT = (
    "You are a retrieval-augmented assistant. Answer using ONLY the provided sources.\n"
    "Cite each claim with [1], [2], etc. If the sources don't contain the answer, say so."
)

_CONFIDENCE_MODIFIERS = {
    "HIGH": "",
    "MEDIUM": "\nThe retrieval system has moderate confidence. Qualify uncertain claims.",
    "LOW": (
        "\nIMPORTANT: The retrieval system has LOW confidence. "
        "Clearly state uncertainty. Do NOT make definitive claims."
    ),
}


class AnswerEngine:
    """LLM wrapper with confidence-aware prompting."""

    def __init__(self):
        self.llm: Optional[LLMBackend] = None
        self._provider: Optional[str] = None
        self._model: Optional[str] = None

    @property
    def configured(self) -> bool:
        return self.llm is not None

    @property
    def provider(self) -> Optional[str]:
        return self._provider

    @property
    def model(self) -> Optional[str]:
        return self._model

    def configure(
        self,
        provider: str,
        model: Optional[str] = None,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        **kwargs,
    ):
        """Configure the LLM backend.

        provider: ollama, openai, anthropic, groq
        """
        self.llm = get_llm(
            backend=provider,
            model=model,
            api_key=api_key,
            base_url=base_url,
            **kwargs,
        )
        self._provider = provider
        self._model = model or self.llm.model

    def generate_answer(
        self,
        query: str,
        results: list[dict],
        confidence: str,
        cmd_context: Optional[str] = None,
    ) -> tuple[str, list[str]]:
        """Generate an answer from search results.

        Args:
            query: The user's question.
            results: List of {"text", "source", "title", "score", ...}.
            confidence: "HIGH", "MEDIUM", or "LOW".
            cmd_context: Recent command outputs from CMD mode (optional).

        Returns:
            (answer_text, sources_cited)
        """
        if not self.llm:
            return "LLM not configured. Use POST /config to set up a provider.", []

        if not results:
            return "I don't have information about that in the indexed sources.", []

        # Build sources block
        sources_block = []
        source_labels = []
        for i, r in enumerate(results, 1):
            source_path = r.get("source", r.get("title", "unknown"))
            line = r.get("line")
            label = f"{source_path}:{line}" if line else source_path
            source_labels.append(label)
            sources_block.append(f"[{i}] {label}: {r['text']}")

        sources_text = "\n\n".join(sources_block)

        # Build system prompt with confidence modifier
        modifier = _CONFIDENCE_MODIFIERS.get(confidence, "")
        system = _SYSTEM_PROMPT + modifier + f"\n\nSources:\n{sources_text}"

        # Append recent command outputs if available
        if cmd_context:
            system += f"\n\nRecent terminal commands:\n{cmd_context}"

        # Generate
        response = self.llm.generate(query, system=system)
        answer = response.text

        # Extract cited sources (find [N] references in the answer)
        cited = []
        for i, label in enumerate(source_labels, 1):
            if f"[{i}]" in answer:
                cited.append(label)

        return answer, cited
