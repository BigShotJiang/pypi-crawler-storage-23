"""Pydantic request/response models for GRIP API."""

from typing import Optional
from pydantic import BaseModel, Field


# ─── Requests ────────────────────────────────────────────────────────────────

class IngestRequest(BaseModel):
    paths: list[str] = Field(..., description="File paths, directory paths, or git URLs to ingest")
    name: Optional[str] = Field(None, description="Source name (auto-generated if omitted)")


class ConfigRequest(BaseModel):
    provider: str = Field(..., description="LLM provider: ollama, openai, anthropic, groq")
    model: Optional[str] = Field(None, description="Model name (provider default if omitted)")
    api_key: Optional[str] = Field(None, description="API key (env var fallback)")
    base_url: Optional[str] = Field(None, description="Custom base URL for provider")
    temperature: float = Field(0.3, ge=0.0, le=2.0)
    max_tokens: int = Field(1000, ge=1, le=32000)


class QueryRequest(BaseModel):
    q: str = Field(..., description="Search query")
    top_k: int = Field(5, ge=1, le=100, description="Number of results")
    answer: bool = Field(False, description="Generate LLM answer from results")
    sources: Optional[list[str]] = Field(None, description="Filter to specific source names")
    session_id: Optional[str] = Field(None, description="Session ID for multi-turn context (omit for stateless)")
    offset: int = Field(0, ge=0, description="Skip first N results (pagination)")


# ─── Response Components ─────────────────────────────────────────────────────

class SearchResult(BaseModel):
    chunk_id: str
    text: str
    score: float
    source: str
    line: Optional[int] = None
    title: str = ""


class Source(BaseModel):
    name: str
    type: str  # "file", "directory", "git"
    path: str
    chunks: int
    files: int
    ingested_at: str  # ISO 8601


# ─── Responses ───────────────────────────────────────────────────────────────

class IngestResponse(BaseModel):
    sources_added: int
    chunks: int
    files: int
    index_time_ms: float


class ConfigResponse(BaseModel):
    provider: str
    model: str
    status: str = "configured"


class QueryResponse(BaseModel):
    query: str
    results: list[SearchResult]
    answer: Optional[str] = None
    confidence: str  # HIGH, MEDIUM, LOW, NONE
    latency_ms: float
    sources_cited: list[str] = []
    session_id: Optional[str] = None
    expanded_query: Optional[str] = None
    remembered: bool = False


class SourcesResponse(BaseModel):
    sources: list[Source]


class DeleteResponse(BaseModel):
    removed: int
    chunks_removed: int


class StatsResponse(BaseModel):
    version: str
    uptime_seconds: float
    total_chunks: int
    chunk_limit: int
    total_sources: int
    total_queries: int
    avg_query_ms: float
    llm_configured: bool
    reranker_available: bool
    tier: str = "free"
    indexing: bool = False
    memory_warning: Optional[str] = None


class HealthResponse(BaseModel):
    status: str  # "ready", "indexing", "empty"
    chunks: int
    tier: str = "free"


class ErrorResponse(BaseModel):
    error: str
    detail: str
