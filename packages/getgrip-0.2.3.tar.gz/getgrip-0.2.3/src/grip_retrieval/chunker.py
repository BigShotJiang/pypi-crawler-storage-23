"""File reading and chunking for GRIP.

Reads files, splits into ~500-token chunks with ~50-token overlap at paragraph
boundaries. Supports 30+ file formats including PDF, Word, Excel, PowerPoint,
email, images (OCR), and all code/text files.
"""

import hashlib
import os
import re
import subprocess
from pathlib import Path
from typing import Optional

from .readers import ALL_EXTENSIONS as TEXT_EXTENSIONS
from .readers import read_file

# Directories to skip
SKIP_DIRS = frozenset({
    ".git", "__pycache__", "node_modules", ".venv", "venv", ".tox",
    ".mypy_cache", ".pytest_cache", "dist", "build", ".eggs",
})

# Sentence boundary pattern
_SENTENCE_RE = re.compile(r'(?<=[.!?])\s+')


def _file_hash(path: str) -> str:
    """Short hash of file path for doc_id namespacing."""
    return hashlib.md5(path.encode()).hexdigest()[:8]


def _estimate_tokens(text: str) -> int:
    """Cheap token estimate: word count."""
    return len(text.split())


def chunk_text(
    text: str,
    target_tokens: int = 500,
    overlap_tokens: int = 50,
) -> list[dict]:
    """Split text into chunks at paragraph boundaries.

    Each chunk: {"text": str, "char_start": int, "line_start": int}
    """
    if not text.strip():
        return []

    # Split on double-newline (paragraphs)
    paragraphs = re.split(r'\n\s*\n', text)
    if not paragraphs:
        return []

    chunks = []
    current_parts: list[str] = []
    current_tokens = 0
    chunk_char_start = 0
    char_pos = 0

    # Track line numbers
    line_at_char = _build_line_map(text)

    for para in paragraphs:
        para = para.strip()
        if not para:
            char_pos += 2  # skip blank
            continue

        para_tokens = _estimate_tokens(para)

        # If single paragraph exceeds max, split by sentences
        if para_tokens > target_tokens * 1.5 and not current_parts:
            sentence_chunks = _split_long_paragraph(para, target_tokens, overlap_tokens)
            for sc in sentence_chunks:
                sc_start = text.find(sc["text"], char_pos)
                if sc_start < 0:
                    sc_start = char_pos
                chunks.append({
                    "text": sc["text"],
                    "char_start": sc_start,
                    "line_start": line_at_char(sc_start),
                })
            char_pos = text.find(para, char_pos)
            if char_pos >= 0:
                char_pos += len(para)
            continue

        # Would adding this paragraph exceed target?
        if current_parts and current_tokens + para_tokens > target_tokens:
            # Emit current chunk
            chunk_text_str = "\n\n".join(current_parts)
            chunks.append({
                "text": chunk_text_str,
                "char_start": chunk_char_start,
                "line_start": line_at_char(chunk_char_start),
            })

            # Overlap: keep last part if it's small enough
            if current_parts and _estimate_tokens(current_parts[-1]) <= overlap_tokens:
                overlap_part = current_parts[-1]
                current_parts = [overlap_part]
                current_tokens = _estimate_tokens(overlap_part)
                # char_start stays approximate
                chunk_char_start = text.find(overlap_part, chunk_char_start)
                if chunk_char_start < 0:
                    chunk_char_start = char_pos
            else:
                current_parts = []
                current_tokens = 0
                chunk_char_start = text.find(para, char_pos if char_pos >= 0 else 0)
                if chunk_char_start < 0:
                    chunk_char_start = char_pos

        if not current_parts:
            found = text.find(para, max(char_pos, 0))
            if found >= 0:
                chunk_char_start = found

        current_parts.append(para)
        current_tokens += para_tokens

        # Advance char_pos past this paragraph
        found = text.find(para, max(char_pos, 0))
        if found >= 0:
            char_pos = found + len(para)

    # Emit final chunk
    if current_parts:
        chunk_text_str = "\n\n".join(current_parts)
        chunks.append({
            "text": chunk_text_str,
            "char_start": chunk_char_start,
            "line_start": line_at_char(chunk_char_start),
        })

    return chunks


def _split_long_paragraph(text: str, target_tokens: int, overlap_tokens: int) -> list[dict]:
    """Split a long paragraph by sentences."""
    sentences = _SENTENCE_RE.split(text)
    chunks = []
    current = []
    current_tokens = 0

    for sent in sentences:
        sent_tokens = _estimate_tokens(sent)
        if current and current_tokens + sent_tokens > target_tokens:
            chunks.append({"text": " ".join(current)})
            # Overlap: keep last sentence
            if current and _estimate_tokens(current[-1]) <= overlap_tokens:
                current = [current[-1]]
                current_tokens = _estimate_tokens(current[-1])
            else:
                current = []
                current_tokens = 0
        current.append(sent)
        current_tokens += sent_tokens

    if current:
        chunks.append({"text": " ".join(current)})

    return chunks


def _build_line_map(text: str):
    """Return a function: char_offset -> line_number (1-based)."""
    line_starts = [0]
    for i, ch in enumerate(text):
        if ch == '\n':
            line_starts.append(i + 1)

    def lookup(char_offset: int) -> int:
        # Binary search for the line
        lo, hi = 0, len(line_starts) - 1
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if line_starts[mid] <= char_offset:
                lo = mid
            else:
                hi = mid - 1
        return lo + 1  # 1-based

    return lookup


def chunk_file(file_path: str, source_name: str) -> list[dict]:
    """Chunk a single file into doc entries.

    Returns: [{"doc_id", "title", "text", "source_file", "line"}, ...]
    """
    text, fmt = read_file(file_path)
    if not text.strip():
        return []

    fhash = _file_hash(file_path)
    filename = Path(file_path).name
    raw_chunks = chunk_text(text)

    docs = []
    for idx, chunk in enumerate(raw_chunks):
        doc_id = f"{fhash}:{filename}:{idx}"
        docs.append({
            "doc_id": doc_id,
            "title": filename,
            "text": chunk["text"],
            "source_file": file_path,
            "source_name": source_name,
            "line": chunk["line_start"],
        })

    return docs


def chunk_directory(dir_path: str, source_name: str) -> list[dict]:
    """Walk a directory tree and chunk all supported files.

    Skips .git/, __pycache__/, node_modules/, hidden dirs.
    """
    all_docs = []
    file_count = 0

    for root, dirs, files in os.walk(dir_path):
        # Prune skipped directories
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]

        for fname in sorted(files):
            ext = Path(fname).suffix.lower()
            if ext not in TEXT_EXTENSIONS:
                continue

            fpath = os.path.join(root, fname)
            try:
                docs = chunk_file(fpath, source_name)
                if docs:
                    all_docs.extend(docs)
                    file_count += 1
            except Exception:
                continue  # Skip unreadable files

    return all_docs


def clone_and_chunk(
    git_url: str,
    source_name: str,
    clone_dir: Optional[str] = None,
) -> tuple[str, list[dict]]:
    """Clone a git repo and chunk it.

    Returns: (clone_path, docs)
    """
    if clone_dir is None:
        # Default to _repos/ in parent of grip_retrieval
        base = Path(__file__).resolve().parent.parent / "_repos"
        base.mkdir(exist_ok=True)
        # Derive dir name from URL
        repo_name = git_url.rstrip("/").split("/")[-1]
        if repo_name.endswith(".git"):
            repo_name = repo_name[:-4]
        clone_path = str(base / repo_name)
    else:
        clone_path = clone_dir

    if not os.path.exists(clone_path):
        subprocess.run(
            ["git", "clone", "--depth=1", git_url, clone_path],
            check=True,
            capture_output=True,
        )

    docs = chunk_directory(clone_path, source_name)
    return clone_path, docs
