from __future__ import annotations

"""Session tracking for multi-turn conversation continuity.

Detects continuation queries ("tell me more", "what about X") and injects
context from prior exchanges so follow-up queries produce relevant results.
"""

import re
import time
import uuid
from dataclasses import dataclass, field


# CamelCase identifiers or backtick-quoted terms
_SYMBOL_RE = re.compile(r'`([^`]+)`|(?<!\w)([A-Z][a-z]+(?:[A-Z][a-z]+)+)(?!\w)')

# Continuation patterns
_CONTINUATION_PHRASES = [
    "tell me more",
    "elaborate",
    "explain further",
    "go on",
    "continue",
    "what else",
    "anything else",
    "more details",
    "expand on",
]

_CONTINUATION_STARTS = [
    "what about",
    "how about",
    "and the",
    "and what",
    "but what",
    "what if",
]


@dataclass
class SessionContext:
    last_query: str = ""
    last_answer: str = ""
    topic_tokens: list[str] = field(default_factory=list)
    symbols: list[str] = field(default_factory=list)
    created_at: float = 0.0
    last_used: float = 0.0


class SessionManager:
    """Track conversation sessions for multi-turn context injection."""

    def __init__(self, ttl_seconds: int = 3600):
        self._sessions: dict[str, SessionContext] = {}
        self._ttl = ttl_seconds

    def get_or_create(self, session_id: str | None) -> tuple[str, SessionContext]:
        """Get existing session or create new one. Returns (session_id, context)."""
        if session_id and session_id in self._sessions:
            ctx = self._sessions[session_id]
            ctx.last_used = time.time()
            return session_id, ctx

        sid = session_id or uuid.uuid4().hex[:12]
        now = time.time()
        ctx = SessionContext(created_at=now, last_used=now)
        self._sessions[sid] = ctx
        return sid, ctx

    def is_continuation(self, query: str, session_id: str) -> bool:
        """Detect if query is a continuation of a prior exchange.

        Patterns:
          - Known continuation phrases ("tell me more", "elaborate", etc.)
          - Short "why"/"how" queries (< 5 words)
          - Query shares >50% tokens with last query
        """
        ctx = self._sessions.get(session_id)
        if not ctx or not ctx.last_query:
            return False

        q_lower = query.lower().strip()

        # Check known continuation phrases
        for phrase in _CONTINUATION_PHRASES:
            if phrase in q_lower:
                return True

        # Check continuation starts
        for start in _CONTINUATION_STARTS:
            if q_lower.startswith(start):
                return True

        # Short why/how queries
        words = q_lower.split()
        if len(words) < 5 and words and words[0] in ("why", "how"):
            return True

        # Token overlap > 50% with last query
        last_tokens = set(ctx.last_query.lower().split())
        current_tokens = set(words)
        if last_tokens and current_tokens:
            overlap = len(last_tokens & current_tokens)
            smaller = min(len(last_tokens), len(current_tokens))
            if smaller > 0 and overlap / smaller > 0.5:
                return True

        return False

    def expand_query(self, session_id: str, query: str) -> str:
        """Expand continuation query with session context.

        Injects topic tokens from last query + symbols from last answer.
        """
        ctx = self._sessions.get(session_id)
        if not ctx:
            return query

        context_terms = []

        # Add topic tokens from last query (nouns/entities — anything > 3 chars)
        for t in ctx.topic_tokens:
            if t.lower() not in query.lower():
                context_terms.append(t)

        # Add symbols from last answer (CamelCase, backtick terms)
        for s in ctx.symbols[:3]:
            if s.lower() not in query.lower():
                context_terms.append(s)

        if context_terms:
            return " ".join(context_terms) + " " + query
        return query

    def update(
        self,
        session_id: str,
        query: str,
        results: list,
        answer: str | None,
    ):
        """Store exchange results in session for future continuation."""
        ctx = self._sessions.get(session_id)
        if not ctx:
            return

        ctx.last_query = query
        ctx.last_answer = answer or ""
        ctx.last_used = time.time()

        # Extract topic tokens: words > 3 chars, not common stop words
        words = query.split()
        ctx.topic_tokens = [
            w for w in words
            if len(w) > 3 and w.lower() not in {
                "what", "about", "more", "tell", "from", "with",
                "that", "this", "have", "does", "they", "them",
                "there", "their", "which", "where", "when",
            }
        ][:5]

        # Extract symbols from answer (CamelCase + backtick-quoted)
        ctx.symbols = []
        if answer:
            for match in _SYMBOL_RE.finditer(answer):
                sym = match.group(1) or match.group(2)
                if sym and sym not in ctx.symbols:
                    ctx.symbols.append(sym)
                if len(ctx.symbols) >= 5:
                    break

    def cleanup(self):
        """Remove sessions older than TTL."""
        now = time.time()
        expired = [
            sid for sid, ctx in self._sessions.items()
            if now - ctx.last_used > self._ttl
        ]
        for sid in expired:
            del self._sessions[sid]
