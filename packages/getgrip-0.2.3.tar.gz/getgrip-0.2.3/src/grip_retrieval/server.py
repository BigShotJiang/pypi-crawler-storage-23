"""GRIP Retrieval — FastAPI server.

8 endpoints:
  POST /ingest     — add files, directories, or git repos
  POST /config     — configure LLM provider
  POST /query      — search + optional LLM answer (costs money if LLM configured)
  GET  /search     — search only, no LLM (safe, free, idempotent)
  GET  /sources    — list indexed sources
  DELETE /sources  — remove sources
  GET  /stats      — server metrics
  GET  /health     — lightweight readiness check for orchestrators

Run:
  python -m grip_retrieval.server
  # or: uvicorn grip_retrieval.server:app --host 0.0.0.0 --port 7878
"""
from __future__ import annotations

import math
import os
import re
import subprocess
import sys
import time

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse

from . import _engine as _rt

from . import __version__
from .models import (
    ConfigRequest, ConfigResponse,
    DeleteResponse,
    HealthResponse,
    IngestRequest, IngestResponse,
    QueryRequest, QueryResponse,
    SearchResult,
    SourcesResponse,
    StatsResponse,
)
from .chunker import chunk_file, chunk_directory, clone_and_chunk
from .source_manager import SourceManager
from .answer_engine import AnswerEngine
from .query_expander import QueryExpander
from .sessions import SessionManager


# ─── App ─────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="GRIP",
    version=__version__,
    description="Make any data searchable with cited answers.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Globals ─────────────────────────────────────────────────────────────────

_source_mgr: SourceManager = None  # type: ignore[assignment]
_answer_eng: AnswerEngine = None   # type: ignore[assignment]
_expander: QueryExpander = None    # type: ignore[assignment]
_sessions: SessionManager = None   # type: ignore[assignment]
_reranker = None  # Optional cross-encoder
_reranker_available = False
_local_llm_available = False
_license_tier = "free"
_license_chunks = 10_000

_start_time = time.time()
_query_count = 0
_query_total_ms = 0.0


# ─── Startup ─────────────────────────────────────────────────────────────────

@app.on_event("startup")
def _startup():
    global _source_mgr, _answer_eng, _expander, _sessions, _reranker, _reranker_available
    global _license_tier, _license_chunks, _local_llm_available

    # ── License validation ────────────────────────────────────────
    chunk_limit = 10_000  # Free tier default
    preserve_learning = False
    _license_tier = "free"

    try:
        from ._license import validate_license, print_license_status, FREE_TIER_CHUNKS
        license_info = validate_license()
        print_license_status(license_info)
        if license_info.valid and license_info.tier != "free":
            chunk_limit = license_info.chunks
            preserve_learning = True
            _license_tier = license_info.tier
        elif license_info.error:
            print(f"  WARNING: {license_info.error} — running as free tier")
            chunk_limit = FREE_TIER_CHUNKS
        else:
            chunk_limit = FREE_TIER_CHUNKS
    except ImportError:
        # No cryptography installed — free tier
        free_limit = int(os.environ.get("GRIP_FREE_CHUNK_LIMIT", "10000"))
        chunk_limit = free_limit
        print(f"  GRIP Free — {chunk_limit:,} chunk limit")
        print(f"  Upgrade: https://getgrip.dev/pricing")

    _license_chunks = chunk_limit

    # ── Data directory ────────────────────────────────────────────
    data_dir = os.environ.get("GRIP_DATA_DIR")

    _source_mgr = SourceManager(
        data_dir=data_dir,
        chunk_limit=chunk_limit,
        preserve_learning=preserve_learning,
    )
    _answer_eng = AnswerEngine()

    # Query expansion via co-occurrence graph
    _expander = QueryExpander(_source_mgr._db)
    _source_mgr._expander = _expander

    # Session tracking for multi-turn queries
    _sessions = SessionManager(ttl_seconds=3600)

    # Try to load cross-encoder reranker (optional)
    try:
        from sentence_transformers import CrossEncoder
        _reranker = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")
        _reranker_available = True
        print("  Reranker loaded (cross-encoder/ms-marco-MiniLM-L-6-v2)")
    except ImportError:
        print("  Reranker not available (pip install sentence-transformers for better quality)")
    except Exception as e:
        print(f"  Reranker failed to load: {e}")

    # Auto-configure local LLM if llama-cpp available and no other LLM set
    try:
        from ._llm import LLAMA_CPP_AVAILABLE
        if LLAMA_CPP_AVAILABLE:
            _local_llm_available = True
            from .grip_local_llm import model_exists
            if model_exists():
                _answer_eng.configure(provider="local")
                print("  Built-in LLM loaded (Qwen2.5-1.5B)")
            else:
                print("  Built-in LLM available (model downloads on first Ask)")
    except Exception:
        pass


# ─── Confidence Heuristic (no reranker) ─────────────────────────────────────

def _compute_confidence_heuristic(scores: list[float]) -> str:
    """Percentile-based confidence from RT pipeline scores.

    Uses relative gap and spread — adapts to any corpus automatically.
    No magic thresholds tied to absolute score ranges.
    """
    if not scores:
        return "NONE"
    if len(scores) < 2:
        return "LOW"

    top = scores[0]
    if top <= 0:
        return "LOW"

    gap = scores[0] - scores[1]
    tail_idx = min(9, len(scores) - 1)
    spread = scores[0] - scores[tail_idx]

    # Relative gap: how much does #1 stand out from #2?
    relative_gap = gap / max(top, 0.01)

    # Score concentration: is there a clear winner or a flat distribution?
    relative_spread = spread / max(top, 0.01)

    if relative_gap > 0.3 and relative_spread > 0.5:
        return "HIGH"
    elif relative_gap > 0.1:
        return "MEDIUM"
    else:
        return "LOW"


def _compute_confidence_reranker(scores: list[float]) -> str:
    """Confidence from cross-encoder reranker scores."""
    import numpy as np
    from ._confidence import compute_confidence
    arr = np.array(scores, dtype=np.float64)
    m = compute_confidence(arr)
    return m.level


# ─── Helpers ─────────────────────────────────────────────────────────────────

_GIT_URL_RE = re.compile(r'^(https?://|git@).+\.git$|^https?://github\.com/.+/.+$')


def _detect_path_type(path: str) -> str:
    """Classify a path as 'git', 'directory', or 'file'."""
    if _GIT_URL_RE.match(path):
        return "git"
    if os.path.isdir(path):
        return "directory"
    if os.path.isfile(path):
        return "file"
    # Could be a git URL without .git suffix
    if path.startswith(("http://", "https://", "git@")):
        return "git"
    raise HTTPException(status_code=404, detail=f"Path not found: {path}")


def _do_search(
    q: str,
    top_k: int,
    offset: int = 0,
    original_q: str | None = None,
) -> tuple[list[SearchResult], str, float, str | None, bool]:
    """Core search logic shared by POST /query and GET /search.

    Args:
        q: The query to search (may be session-expanded).
        original_q: The raw user query before session/expansion rewriting.
                    Used for remember/recall so the hash is stable.

    Returns: (results, confidence, latency_ms, expanded_query_or_None, remembered)
    """
    t0 = time.time()

    if not _rt._indexed:
        return [], "NONE", 0.0, None, False

    # ── Query expansion ───────────────────────────────────────────
    expanded_q = None
    search_q = q
    if _expander and _expander.ready:
        candidate = _expander.expand(q)
        if candidate != q:
            expanded_q = candidate
            search_q = candidate

    # ── Stage 1: RT pipeline retrieval ────────────────────────────
    raw_top_k = top_k + offset
    if _reranker_available:
        raw_top_k = max(200, top_k + offset)

    rt_results = _rt.retrieve(search_q, top_k=raw_top_k)
    if not rt_results:
        return [], "NONE", (time.time() - t0) * 1000, expanded_q, False

    # ── Auto-boost remembered results ─────────────────────────────
    recall_q = original_q or q
    remembered_ids, hit_count = _source_mgr.recall(recall_q)
    remembered = bool(remembered_ids)
    if remembered_ids:
        # Scale boost with hit count: 10% base, grows with use, caps at 25%
        boost = min(1.05 + 0.05 * math.log2(hit_count + 1), 1.25)
        remembered_set = set(remembered_ids)
        for r in rt_results:
            if r["doc_id"] in remembered_set:
                r["score"] *= boost

    # ── Stage 2: Rerank if available ──────────────────────────────
    if _reranker_available and _reranker is not None:
        pairs = []
        for r in rt_results:
            doc_text = _source_mgr.get_chunk_text(r["doc_id"])
            pairs.append((q, doc_text[:2000]))

        ce_scores = _reranker.predict(pairs, batch_size=64, show_progress_bar=False)

        # Sort by cross-encoder score
        scored = list(zip(rt_results, ce_scores))
        scored.sort(key=lambda x: -x[1])
        rt_results = [{"doc_id": s[0]["doc_id"], "score": float(s[1])} for s in scored]

        confidence = _compute_confidence_reranker(
            [float(s[1]) for s in scored[:min(20, len(scored))]]
        )
    else:
        confidence = _compute_confidence_heuristic(
            [r["score"] for r in rt_results[:min(20, len(rt_results))]]
        )

    # ── Pagination: apply offset then top_k ───────────────────────
    paginated = rt_results[offset:offset + top_k]

    # Build response results
    results = []
    for r in paginated:
        doc_id = r["doc_id"]
        meta = _source_mgr.get_chunk_meta(doc_id)
        text = _source_mgr.get_chunk_text(doc_id)
        results.append(SearchResult(
            chunk_id=doc_id,
            text=text[:1000],  # Truncate for response
            score=round(r["score"], 4),
            source=meta.get("source_file", "unknown"),
            line=meta.get("line"),
            title=_rt._doc_titles.get(doc_id, ""),
        ))

    latency_ms = (time.time() - t0) * 1000
    return results, confidence, latency_ms, expanded_q, remembered


# ─── Endpoints ───────────────────────────────────────────────────────────────

@app.post("/ingest", response_model=IngestResponse)
def ingest(req: IngestRequest):
    """Ingest files, directories, or git repos into the search index."""
    total_chunks = 0
    total_files = 0
    sources_added = 0
    total_index_ms = 0.0

    for i, path in enumerate(req.paths):
        ptype = _detect_path_type(path)

        # Auto-generate source name
        if req.name and len(req.paths) == 1:
            source_name = req.name
        else:
            source_name = req.name or os.path.basename(path.rstrip("/\\"))
            if len(req.paths) > 1:
                source_name = f"{source_name}_{i}"

        try:
            if ptype == "git":
                clone_path, chunks = clone_and_chunk(path, source_name)
                actual_path = clone_path
            elif ptype == "directory":
                chunks = chunk_directory(path, source_name)
                actual_path = path
            else:
                chunks = chunk_file(path, source_name)
                actual_path = path

            if not chunks:
                continue

            result = _source_mgr.add_chunks(source_name, ptype, actual_path, chunks)
            total_chunks += result["chunks"]
            total_files += result["files"]
            total_index_ms += result["index_time_ms"]
            sources_added += 1

        except HTTPException:
            raise
        except ValueError as e:
            # Chunk limit exceeded
            raise HTTPException(status_code=429, detail=str(e))
        except subprocess.CalledProcessError:
            raise HTTPException(status_code=502, detail=f"Git clone failed for: {path}")
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Ingest failed for {path}: {e}")

    return IngestResponse(
        sources_added=sources_added,
        chunks=total_chunks,
        files=total_files,
        index_time_ms=round(total_index_ms, 1),
    )


@app.post("/config", response_model=ConfigResponse)
def config(req: ConfigRequest):
    """Configure the LLM provider for answer generation."""
    try:
        _answer_eng.configure(
            provider=req.provider,
            model=req.model,
            api_key=req.api_key,
            base_url=req.base_url,
            temperature=req.temperature,
            max_tokens=req.max_tokens,
        )
    except (ImportError, ValueError, RuntimeError) as e:
        raise HTTPException(status_code=400, detail=str(e))

    return ConfigResponse(
        provider=req.provider,
        model=_answer_eng.model or "default",
    )


@app.post("/query", response_model=QueryResponse)
def query(req: QueryRequest):
    """Search with optional LLM answer generation.

    Use this when answer=true (triggers LLM call, may cost money).
    Use GET /search for free, safe, search-only queries.
    """
    global _query_count, _query_total_ms

    # ── Session handling ──────────────────────────────────────────
    sid = None
    actual_q = req.q
    if _sessions and req.session_id:
        sid, ctx = _sessions.get_or_create(req.session_id)
        if _sessions.is_continuation(req.q, sid):
            actual_q = _sessions.expand_query(sid, req.q)

    results, confidence, latency_ms, expanded_q, remembered = _do_search(
        actual_q, req.top_k, offset=req.offset, original_q=req.q
    )
    _query_count += 1

    answer = None
    sources_cited: list[str] = []

    if req.answer:
        if not _answer_eng.configured:
            raise HTTPException(
                status_code=400,
                detail="LLM not configured. Call POST /config first.",
            )
        if not results:
            answer = "I don't have information about that in the indexed sources."
        else:
            result_dicts = [
                {
                    "text": r.text,
                    "source": r.source,
                    "title": r.title,
                    "line": r.line,
                    "score": r.score,
                }
                for r in results
            ]
            # Include recent CMD history so LLM can reference command outputs
            cmd_context = None
            if _cmd_history:
                recent = _cmd_history[-5:]
                lines = []
                for h in recent:
                    lines.append(f"$ {h['cmd']}")
                    if h["stdout"]:
                        lines.append(h["stdout"][:500])
                    if h["stderr"]:
                        lines.append(f"(stderr: {h['stderr'][:200]})")
                cmd_context = "\n".join(lines)

            answer, sources_cited = _answer_eng.generate_answer(
                req.q, result_dicts, confidence, cmd_context=cmd_context
            )

    # ── Auto-remember on HIGH confidence ──────────────────────────
    if confidence == "HIGH" and results:
        _source_mgr.remember(
            req.q, [r.chunk_id for r in results[:5]], confidence
        )

    # ── Update session ────────────────────────────────────────────
    if _sessions and sid:
        _sessions.update(sid, req.q, results, answer)
        _sessions.cleanup()

    total_ms = latency_ms
    _query_total_ms += total_ms

    return QueryResponse(
        query=req.q,
        results=results,
        answer=answer,
        confidence=confidence,
        latency_ms=round(total_ms, 1),
        sources_cited=sources_cited,
        session_id=sid,
        expanded_query=expanded_q,
        remembered=remembered,
    )


@app.get("/search", response_model=QueryResponse)
def search(
    q: str = Query(..., description="Search query"),
    top_k: int = Query(5, ge=1, le=100, description="Number of results"),
    offset: int = Query(0, ge=0, description="Skip first N results (pagination)"),
):
    """Search only — no LLM, free, safe, idempotent.

    Equivalent to POST /query with answer=false.
    """
    global _query_count, _query_total_ms

    results, confidence, latency_ms, expanded_q, remembered = _do_search(
        q, top_k, offset=offset
    )
    _query_count += 1
    _query_total_ms += latency_ms

    return QueryResponse(
        query=q,
        results=results,
        answer=None,
        confidence=confidence,
        latency_ms=round(latency_ms, 1),
        sources_cited=[],
        expanded_query=expanded_q,
        remembered=remembered,
    )


@app.get("/sources", response_model=SourcesResponse)
def list_sources():
    """List all indexed sources."""
    return SourcesResponse(sources=_source_mgr.get_sources())


@app.delete("/sources", response_model=DeleteResponse)
def delete_sources(name: str = Query(None, description="Source name to remove (omit to remove all)")):
    """Remove a source or all sources."""
    if name:
        result = _source_mgr.remove_source(name)
    else:
        result = _source_mgr.remove_all()
    return DeleteResponse(**result)


@app.get("/stats", response_model=StatsResponse)
def stats():
    """Server metrics."""
    avg_ms = (_query_total_ms / _query_count) if _query_count > 0 else 0.0
    return StatsResponse(
        version=__version__,
        uptime_seconds=round(time.time() - _start_time, 1),
        total_chunks=_source_mgr.total_chunks,
        chunk_limit=_source_mgr.chunk_limit,
        total_sources=_source_mgr.total_sources,
        total_queries=_query_count,
        avg_query_ms=round(avg_ms, 1),
        llm_configured=_answer_eng.configured,
        reranker_available=_reranker_available,
        tier=_license_tier,
        indexing=_source_mgr.indexing,
        memory_warning=_source_mgr.memory_warning,
    )


@app.get("/health", response_model=HealthResponse)
def health():
    """Lightweight readiness probe for orchestrators.

    Returns 200 when ready, 503 when indexing.
    """
    if _source_mgr.indexing:
        return JSONResponse(
            status_code=503,
            content={"status": "indexing", "chunks": _source_mgr.total_chunks, "tier": _license_tier},
        )

    status = "ready" if _source_mgr.total_chunks > 0 else "empty"
    return HealthResponse(status=status, chunks=_source_mgr.total_chunks, tier=_license_tier)


@app.get("/formats")
def get_formats():
    """List all file formats GRIP can search on this system."""
    from .readers import get_supported_formats
    formats = get_supported_formats()
    supported = [ext for ext, s in formats.items() if s.startswith("supported")]
    needs = {ext: s for ext, s in formats.items() if not s.startswith("supported")}
    return JSONResponse(content={
        "supported_count": len(supported),
        "supported": sorted(supported),
        "needs_install_count": len(needs),
        "needs_install": needs,
    })


@app.get("/licenses")
def get_licenses():
    """Return third-party license notices."""
    from pathlib import Path
    # Check multiple locations: PyInstaller bundle, project root, package dir
    for candidate in [
        Path(getattr(sys, '_MEIPASS', ''), 'THIRD_PARTY_LICENSES'),
        Path(__file__).resolve().parent.parent / 'THIRD_PARTY_LICENSES',
        Path(__file__).resolve().parent.parent.parent / 'THIRD_PARTY_LICENSES',
        Path(os.getcwd()) / 'THIRD_PARTY_LICENSES',
        Path(os.getcwd()) / 'pypi' / 'THIRD_PARTY_LICENSES',
    ]:
        if candidate.exists():
            return HTMLResponse(
                content="<pre style='font-family:monospace;background:#0a0a0f;color:#e0e0e0;"
                "padding:40px;margin:0;min-height:100vh'>"
                + candidate.read_text(encoding='utf-8').replace('&', '&amp;').replace('<', '&lt;')
                + "</pre>",
            )
    return JSONResponse(
        status_code=404,
        content={"detail": "THIRD_PARTY_LICENSES file not found"},
    )


# ─── Directory Browser ────────────────────────────────────────────────────────

@app.get("/browse")
def browse(path: str = Query("", description="Directory to list")):
    """List directories for the folder browser UI."""
    import platform

    if not path:
        # Return filesystem roots
        if platform.system() == "Windows":
            import string
            drives = []
            for letter in string.ascii_uppercase:
                drive = f"{letter}:\\"
                if os.path.exists(drive):
                    drives.append({"name": drive, "path": drive})
            return {"path": "", "parent": "", "dirs": drives}
        else:
            return {"path": "/", "parent": "/", "dirs": [
                {"name": d, "path": f"/{d}"}
                for d in sorted(os.listdir("/"))
                if os.path.isdir(f"/{d}") and not d.startswith(".")
            ]}

    path = os.path.abspath(path)
    if not os.path.isdir(path):
        raise HTTPException(status_code=404, detail=f"Not a directory: {path}")

    parent = os.path.dirname(path)
    try:
        entries = sorted(os.listdir(path))
    except PermissionError:
        raise HTTPException(status_code=403, detail=f"Permission denied: {path}")

    dirs = []
    for entry in entries:
        if entry.startswith("."):
            continue
        full = os.path.join(path, entry)
        if os.path.isdir(full):
            dirs.append({"name": entry, "path": full})

    return {"path": path, "parent": parent, "dirs": dirs}


# ─── Command Execution (CMD mode) ────────────────────────────────────────────

# Store recent command outputs so the LLM can reference them
_cmd_history: list[dict] = []
_CMD_HISTORY_MAX = 20


def _get_packages_dir() -> str:
    """Return the user-writable packages directory."""
    grip_home = os.environ.get("GRIP_DATA_DIR") or os.path.join(
        os.path.expanduser("~"), ".grip"
    )
    return os.path.join(grip_home, "packages")


@app.post("/exec")
def exec_command(req: dict):
    """Execute a shell command (CMD mode). Localhost only.

    Body: {"cmd": "pip install requests"}
    Returns: {"cmd": "...", "stdout": "...", "stderr": "...", "exit_code": 0}
    """
    import shlex
    import platform

    cmd = req.get("cmd", "").strip()
    if not cmd:
        raise HTTPException(status_code=400, detail="No command provided")

    # Auto-redirect pip install to packages dir
    pkg_dir = _get_packages_dir()
    os.makedirs(pkg_dir, exist_ok=True)
    if cmd.startswith("pip install") and "--target" not in cmd:
        cmd = cmd.replace("pip install", f'pip install --target "{pkg_dir}"', 1)

    try:
        shell = platform.system() == "Windows"
        result = subprocess.run(
            cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=120,
            cwd=os.path.expanduser("~"),
        )

        entry = {
            "cmd": cmd,
            "stdout": result.stdout[-4000:] if result.stdout else "",
            "stderr": result.stderr[-2000:] if result.stderr else "",
            "exit_code": result.returncode,
        }

        _cmd_history.append(entry)
        if len(_cmd_history) > _CMD_HISTORY_MAX:
            _cmd_history.pop(0)

        return entry

    except subprocess.TimeoutExpired:
        return {"cmd": cmd, "stdout": "", "stderr": "Command timed out (120s limit)", "exit_code": -1}
    except Exception as e:
        return {"cmd": cmd, "stdout": "", "stderr": str(e), "exit_code": -1}


@app.get("/cmd-history")
def cmd_history():
    """Return recent command history for LLM context."""
    return {"history": _cmd_history}


# ─── Web UI ──────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
def landing():
    """Full web UI — search, ingest, ask, manage sources."""
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>GRIP</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ font-family: 'SF Mono', 'Fira Code', monospace; background: #0a0a0f; color: #e0e0e0; }}
  .container {{ max-width: 900px; margin: 0 auto; padding: 40px 20px; }}
  h1 {{ font-size: 2em; margin-bottom: 4px; color: #fff; }}
  .subtitle {{ color: #888; margin-bottom: 30px; font-size: 0.9em; }}
  .stats {{ color: #00ff88; font-size: 0.85em; margin-bottom: 20px; }}

  /* Source panel */
  .source-panel {{ margin-bottom: 16px; background: #12121f; border: 1px solid #222;
    border-radius: 6px; padding: 12px; }}
  .source-panel-header {{ display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }}
  .source-panel-header h3 {{ font-size: 13px; color: #888; margin: 0; }}
  .source-chips {{ display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 8px; }}
  .source-chip {{ display: inline-flex; align-items: center; gap: 4px; padding: 4px 10px;
    background: #1a1a2e; border: 1px solid #333; border-radius: 16px;
    font-size: 12px; color: #00ff88; cursor: default; }}
  .source-chip .count {{ font-size: 10px; color: #00aa55; }}
  .source-chip .remove {{ color: #ff4444; cursor: pointer; margin-left: 4px; font-weight: bold; }}
  .source-chip .remove:hover {{ color: #ff8888; }}
  .source-badge {{ font-size: 11px; color: #555; margin-bottom: 8px; }}
  .source-badge .hl {{ color: #00ff88; }}
  .add-row {{ display: flex; gap: 6px; margin-top: 6px; }}
  .add-row input {{ flex: 1; padding: 6px 10px; background: #1a1a2e; border: 1px solid #333;
    border-radius: 4px; color: #e0e0e0; font-family: inherit; font-size: 12px; }}
  .add-row input:focus {{ border-color: #00ff88; outline: none; }}
  .add-btn {{ padding: 6px 12px; background: #333; color: #e0e0e0; border: none;
    border-radius: 4px; cursor: pointer; font-family: inherit; font-size: 12px; }}
  .add-btn:hover {{ background: #444; }}
  .browse-btn {{ padding: 6px 12px; background: #1a1a3e; color: #8888ff; border: 1px solid #6666cc;
    border-radius: 4px; cursor: pointer; font-family: inherit; font-size: 12px; }}
  .browse-btn:hover {{ background: #2a2a4e; }}

  /* Browse modal */
  .modal-overlay {{ display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0,0,0,0.7); z-index: 1000; justify-content: center; align-items: center; }}
  .modal {{ background: #12121f; border: 1px solid #333; border-radius: 8px; width: 500px;
    max-height: 70vh; display: flex; flex-direction: column; }}
  .modal-header {{ display: flex; justify-content: space-between; align-items: center;
    padding: 12px 16px; border-bottom: 1px solid #222; }}
  .modal-header h3 {{ margin: 0; font-size: 14px; color: #fff; }}
  .modal-close {{ background: none; border: none; color: #888; font-size: 18px; cursor: pointer; }}
  .modal-close:hover {{ color: #fff; }}
  .modal-path {{ padding: 8px 16px; font-size: 12px; color: #00ff88; background: #0a0a14;
    border-bottom: 1px solid #222; word-break: break-all; display: flex; align-items: center; gap: 8px; }}
  .modal-path .up-btn {{ background: #333; border: none; color: #e0e0e0; padding: 2px 8px;
    border-radius: 3px; cursor: pointer; font-size: 11px; }}
  .modal-path .up-btn:hover {{ background: #444; }}
  .modal-body {{ overflow-y: auto; flex: 1; padding: 4px 0; }}
  .dir-item {{ display: flex; align-items: center; gap: 8px; padding: 8px 16px; cursor: pointer;
    font-size: 13px; color: #e0e0e0; }}
  .dir-item:hover {{ background: #1a1a2e; }}
  .dir-icon {{ color: #ffaa00; }}
  .modal-footer {{ padding: 10px 16px; border-top: 1px solid #222; display: flex; gap: 8px;
    justify-content: flex-end; }}
  .modal-footer .select-btn {{ padding: 6px 16px; background: #00ff88; color: #000; border: none;
    border-radius: 4px; cursor: pointer; font-weight: bold; font-family: inherit; font-size: 12px; }}
  .modal-footer .select-btn:hover {{ background: #00cc6a; }}

  /* Search */
  .search-box {{ display: flex; gap: 8px; margin-bottom: 20px; }}
  #query {{ flex: 1; padding: 12px 16px; font-size: 16px; font-family: inherit;
    background: #1a1a2e; border: 1px solid #333; border-radius: 6px; color: #fff; outline: none; }}
  #query:focus {{ border-color: #00ff88; }}
  #search-btn {{ padding: 12px 24px; background: #00ff88; color: #000; border: none;
    border-radius: 6px; font-family: inherit; font-weight: bold; cursor: pointer; font-size: 14px; }}
  #search-btn:hover {{ background: #00cc6a; }}

  .latency {{ display: inline-block; background: #1a1a2e; padding: 4px 10px;
    border-radius: 4px; font-size: 13px; margin-bottom: 16px; }}
  .latency .ms {{ color: #00ff88; font-weight: bold; }}
  .confidence-badge {{ display: inline-block; padding: 3px 8px; border-radius: 4px;
    font-size: 11px; font-weight: bold; margin-left: 8px; }}
  .confidence-HIGH {{ background: #0a2a15; color: #00ff88; border: 1px solid #00ff88; }}
  .confidence-MEDIUM {{ background: #2a2a0a; color: #ffaa00; border: 1px solid #ffaa00; }}
  .confidence-LOW {{ background: #2a0a0a; color: #ff4444; border: 1px solid #ff4444; }}
  .confidence-NONE {{ background: #1a1a2e; color: #555; border: 1px solid #333; }}

  .indicator {{ display: inline-block; padding: 3px 8px; border-radius: 4px;
    font-size: 11px; margin-left: 8px; }}
  .indicator-expand {{ background: #1a1a3e; color: #8888ff; border: 1px solid #6666cc; }}
  .indicator-remember {{ background: #2a1a2a; color: #cc88ff; border: 1px solid #aa66dd; }}
  .indicator-session {{ background: #1a2a2a; color: #88dddd; border: 1px solid #66bbbb; }}
  #search-indicators {{ margin-bottom: 8px; min-height: 18px; }}
  .session-bar {{ display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }}

  /* Results */
  .result {{ background: #12121f; border: 1px solid #222; border-radius: 6px;
    padding: 14px 16px; margin-bottom: 10px; }}
  .result-file {{ color: #00aaff; font-size: 13px; margin-bottom: 6px; }}
  .result-line {{ color: #666; font-size: 12px; }}
  .result-content {{ font-size: 13px; color: #ccc; white-space: pre-wrap;
    max-height: 120px; overflow: hidden; line-height: 1.5; }}
  .result-score {{ float: right; color: #888; font-size: 12px; }}
  .result:hover {{ border-color: #00ff88; }}
  #results {{ min-height: 100px; }}
  .empty {{ color: #555; text-align: center; padding: 40px; }}

  /* Chat */
  .chat-section {{ margin-top: 30px; padding-top: 20px; border-top: 1px solid #222; }}
  .chat-section h2 {{ font-size: 1.1em; margin-bottom: 12px; color: #fff; }}
  .chat-config {{ display: flex; gap: 8px; align-items: center; margin-bottom: 8px; flex-wrap: wrap; }}
  .chat-config label {{ font-size: 12px; color: #888; }}
  .chat-config select, .chat-config input {{ padding: 6px 10px; background: #1a1a2e;
    border: 1px solid #333; border-radius: 4px; color: #e0e0e0; font-family: inherit; font-size: 12px; }}
  .chat-config select:focus, .chat-config input:focus {{ border-color: #00ff88; outline: none; }}
  .chat-config .sep {{ color: #333; }}
  #llm-status {{ font-size: 11px; }}
  .llm-ok {{ color: #00ff88; }}
  .llm-none {{ color: #ff8800; }}
  #terminal {{ background: #0c0c14; border: 1px solid #333; border-radius: 6px;
    height: 400px; overflow-y: auto; padding: 12px; font-size: 13px; line-height: 1.6; }}
  #terminal::-webkit-scrollbar {{ width: 6px; }}
  #terminal::-webkit-scrollbar-thumb {{ background: #333; border-radius: 3px; }}
  .term-user {{ color: #00ff88; margin-bottom: 2px; }}
  .term-user .prompt {{ color: #00ff88; font-weight: bold; }}
  .term-meta {{ color: #555; font-size: 11px; margin-bottom: 4px; }}
  .term-meta .hl {{ color: #00ff88; }}
  .term-response {{ color: #ddd; white-space: pre-wrap; word-wrap: break-word;
    margin-bottom: 8px; padding-left: 8px; border-left: 2px solid #222; }}
  .term-divider {{ border: none; border-top: 1px solid #1a1a2e; margin: 8px 0; }}
  .chat-input-row {{ display: flex; gap: 8px; margin-top: 8px; }}
  #chat-input {{ flex: 1; padding: 10px 14px; font-size: 14px; font-family: inherit;
    background: #0c0c14; border: 1px solid #333; border-radius: 6px; color: #00ff88; outline: none; }}
  #chat-input:focus {{ border-color: #00ff88; }}
  #chat-btn {{ padding: 10px 18px; background: #ff8800; color: #000; border: none;
    border-radius: 6px; font-family: inherit; font-weight: bold; cursor: pointer; font-size: 13px; }}
  #chat-btn:hover {{ background: #cc6e00; }}
  .clear-btn {{ padding: 10px 14px; background: #333; color: #e0e0e0; border: none;
    border-radius: 6px; font-family: inherit; font-size: 13px; cursor: pointer; }}
  .clear-btn:hover {{ background: #444; }}

  /* CMD mode */
  .mode-toggle {{ padding: 10px 14px; border: none; border-radius: 6px;
    font-family: inherit; font-weight: bold; cursor: pointer; font-size: 11px; }}
  .mode-ask {{ background: #ff8800; color: #000; }}
  .mode-cmd {{ background: #00ff88; color: #000; }}
  .term-cmd {{ color: #00ff88; margin-bottom: 2px; }}
  .term-cmd .prompt {{ color: #00ff88; font-weight: bold; }}
  .term-stdout {{ color: #ccc; white-space: pre-wrap; word-wrap: break-word;
    margin-bottom: 4px; font-size: 12px; }}
  .term-stderr {{ color: #ff8844; white-space: pre-wrap; word-wrap: break-word;
    margin-bottom: 4px; font-size: 12px; }}
  .term-exit {{ color: #555; font-size: 11px; margin-bottom: 4px; }}
  #chat-input.cmd-mode {{ color: #00ff88; border-color: #00aa55; }}
  #chat-input.cmd-mode:focus {{ border-color: #00ff88; }}
  #chat-btn.cmd-active {{ background: #00ff88; color: #000; }}
  #chat-btn.cmd-active:hover {{ background: #00cc6a; }}

  .footer {{ margin-top: 40px; color: #444; font-size: 12px; text-align: center; }}
</style>
</head>
<body>
<div class="container">
  <h1>GRIP</h1>
  <div class="subtitle">Make any data searchable. Get cited answers.</div>
  <div class="stats" id="stats">Loading...</div>

  <div class="source-panel">
    <div class="source-panel-header">
      <h3>Sources</h3>
      <span id="source-badge" class="source-badge"></span>
    </div>
    <div class="source-chips" id="source-chips"></div>
    <div class="add-row">
      <input type="text" id="ingest-path" placeholder="File path, directory, or https://github.com/user/repo">
      <button class="browse-btn" onclick="openBrowser()">Browse</button>
      <button class="add-btn" onclick="doIngest()">+ Add Source</button>
      <span id="ingest-status" style="color:#888;font-size:11px;align-self:center;"></span>
    </div>
  </div>

  <div class="search-box">
    <input type="text" id="query" placeholder="Search..." autofocus>
    <button id="search-btn" onclick="doSearch()">Search</button>
  </div>

  <div class="latency" id="latency" style="display:none">
    <span class="ms" id="ms">0</span>ms
    <span class="confidence-badge" id="confidence-badge"></span>
  </div>
  <div id="search-indicators"></div>

  <div id="results"><div class="empty">Add a source and start searching</div></div>

  <div class="chat-section">
    <h2>Ask about your data</h2>
    <div class="session-bar">
      <span class="indicator indicator-session" id="session-pill" style="display:none"></span>
      <button class="add-btn" id="new-session-btn" onclick="newSession()" style="display:none;font-size:11px;padding:3px 8px;">New session</button>
    </div>
    <div class="chat-config">
      <label>Provider</label>
      <select id="llm-provider">
        {'<option value="local">Built-in (no setup)</option>' if _local_llm_available else ''}
        <option value="ollama">Ollama (local)</option>
        <option value="openai">OpenAI</option>
        <option value="anthropic">Anthropic</option>
        <option value="groq">Groq</option>
      </select>
      <label>Model</label>
      <input type="text" id="llm-model" placeholder="(default)" style="width:160px;">
      <label>API Key</label>
      <input type="password" id="llm-key" placeholder="(env var)" style="width:140px;">
      <button class="add-btn" onclick="doConfig()">Configure</button>
      <span id="llm-status" class="llm-none">not configured</span>
    </div>
    <div id="terminal"><div style="color:#555">grip&gt; Ready. Add sources, search, then ask questions.</div></div>
    <div class="chat-input-row">
      <input type="text" id="chat-input" placeholder="grip&gt; ask a question...">
      <button id="chat-btn" onclick="handleInput()">Ask</button>
      <button id="mode-btn" class="mode-toggle mode-ask" onclick="toggleMode()">CMD</button>
      <button class="clear-btn" onclick="clearChat()">Clear</button>
    </div>
  </div>

  <div class="footer" id="footer">
    GRIP v{__version__}
  </div>
</div>

<!-- Browse modal -->
<div class="modal-overlay" id="browse-modal">
  <div class="modal">
    <div class="modal-header">
      <h3>Select Folder</h3>
      <button class="modal-close" onclick="closeBrowser()">&times;</button>
    </div>
    <div class="modal-path">
      <button class="up-btn" onclick="browseUp()">Up</button>
      <span id="browse-current-path">/</span>
    </div>
    <div class="modal-body" id="browse-list"></div>
    <div class="modal-footer">
      <button class="add-btn" onclick="closeBrowser()">Cancel</button>
      <button class="select-btn" onclick="selectBrowsed()">Select This Folder</button>
    </div>
  </div>
</div>

<script>
// ── State ──
let allSources = [];
let chatSessionId = 'session_' + Math.random().toString(36).substring(2, 10);
let browsePath = '';
let cmdMode = false;

// ── Mode toggle ──
function toggleMode() {{
  cmdMode = !cmdMode;
  const btn = document.getElementById('mode-btn');
  const chatBtn = document.getElementById('chat-btn');
  const input = document.getElementById('chat-input');
  if (cmdMode) {{
    btn.textContent = 'ASK';
    btn.className = 'mode-toggle mode-cmd';
    chatBtn.textContent = 'Run';
    chatBtn.className = 'cmd-active';
    chatBtn.style.background = '#00ff88';
    chatBtn.style.color = '#000';
    input.className = 'cmd-mode';
    input.placeholder = '$ type a command...';
    input.style.color = '#00ff88';
    input.style.borderColor = '#00aa55';
  }} else {{
    btn.textContent = 'CMD';
    btn.className = 'mode-toggle mode-ask';
    chatBtn.textContent = 'Ask';
    chatBtn.className = '';
    chatBtn.style.background = '#ff8800';
    chatBtn.style.color = '#000';
    input.className = '';
    input.placeholder = 'grip> ask a question...';
    input.style.color = '#00ff88';
    input.style.borderColor = '#333';
  }}
  input.focus();
}}

function handleInput() {{
  if (cmdMode) {{
    doExec();
  }} else {{
    doChat();
  }}
}}

// ── CMD execution ──
async function doExec() {{
  const cmd = document.getElementById('chat-input').value.trim();
  if (!cmd) return;

  const term = document.getElementById('terminal');
  document.getElementById('chat-input').value = '';

  // Command line
  const cmdLine = document.createElement('div');
  cmdLine.className = 'term-cmd';
  cmdLine.innerHTML = '<span class="prompt">$</span> ' + escapeHtml(cmd);
  term.appendChild(cmdLine);

  // Running indicator
  const runLine = document.createElement('div');
  runLine.className = 'term-meta';
  runLine.textContent = 'running...';
  term.appendChild(runLine);
  term.scrollTop = term.scrollHeight;

  try {{
    const res = await fetch('/exec', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{cmd}})
    }});
    const data = await res.json();

    runLine.remove();

    if (data.stdout) {{
      const out = document.createElement('div');
      out.className = 'term-stdout';
      out.textContent = data.stdout;
      term.appendChild(out);
    }}
    if (data.stderr) {{
      const err = document.createElement('div');
      err.className = 'term-stderr';
      err.textContent = data.stderr;
      term.appendChild(err);
    }}

    const exitLine = document.createElement('div');
    exitLine.className = 'term-exit';
    exitLine.textContent = data.exit_code === 0 ? 'done' : 'exit code: ' + data.exit_code;
    term.appendChild(exitLine);

  }} catch(e) {{
    runLine.textContent = 'Error: ' + e.message;
    runLine.style.color = '#ff4444';
  }}

  const hr = document.createElement('hr');
  hr.className = 'term-divider';
  term.appendChild(hr);
  term.scrollTop = term.scrollHeight;
  document.getElementById('chat-input').focus();
}}

// ── Browse modal ──
function openBrowser() {{
  document.getElementById('browse-modal').style.display = 'flex';
  browseNavigate('');
}}

function closeBrowser() {{
  document.getElementById('browse-modal').style.display = 'none';
}}

function browseUp() {{
  const cur = document.getElementById('browse-current-path').textContent;
  fetch('/browse?path=' + encodeURIComponent(cur))
    .then(r => r.json())
    .then(data => {{
      if (data.parent && data.parent !== data.path) {{
        browseNavigate(data.parent);
      }} else {{
        browseNavigate('');
      }}
    }});
}}

function selectBrowsed() {{
  const cur = browsePath;
  if (cur) {{
    document.getElementById('ingest-path').value = cur;
  }}
  closeBrowser();
}}

async function browseNavigate(path) {{
  const list = document.getElementById('browse-list');
  list.innerHTML = '<div style="color:#888;padding:12px">Loading...</div>';

  try {{
    const res = await fetch('/browse?path=' + encodeURIComponent(path));
    const data = await res.json();
    if (!res.ok) {{
      list.innerHTML = '<div style="color:#ff4444;padding:12px">' + escapeHtml(data.detail || 'Error') + '</div>';
      return;
    }}

    browsePath = data.path || '';
    document.getElementById('browse-current-path').textContent = data.path || '(drives)';

    if (data.dirs.length === 0) {{
      list.innerHTML = '<div style="color:#555;padding:12px">Empty folder</div>';
      return;
    }}

    list.innerHTML = data.dirs.map(d =>
      '<div class="dir-item" onclick="browseNavigate(\\\'' +
      d.path.replace(/\\\\/g, '\\\\\\\\').replace(/'/g, "\\\\'") +
      '\\\')"><span class="dir-icon">&#128193;</span>' + escapeHtml(d.name) + '</div>'
    ).join('');
  }} catch(e) {{
    list.innerHTML = '<div style="color:#ff4444;padding:12px">Error: ' + escapeHtml(e.message) + '</div>';
  }}
}}

function escapeHtml(s) {{
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}}

// ── Load sources + stats ──
async function loadState() {{
  try {{
    const [srcRes, statRes, fmtRes] = await Promise.all([
      fetch('/sources'), fetch('/stats'), fetch('/formats')
    ]);
    allSources = (await srcRes.json()).sources;
    const st = await statRes.json();
    const fmt = await fmtRes.json();

    let statsText = st.total_chunks.toLocaleString() + ' chunks indexed | ' +
      st.total_sources + ' sources | ' +
      st.total_queries + ' queries | ' +
      'uptime ' + Math.round(st.uptime_seconds) + 's';
    if (st.indexing) {{
      statsText = 'Indexing previous data... | ' + statsText;
    }}
    if (st.memory_warning) {{
      statsText += ' | ' + st.memory_warning;
    }}
    document.getElementById('stats').textContent = statsText;

    // Auto-refresh while indexing
    if (st.indexing) {{
      setTimeout(loadState, 2000);
    }}

    document.getElementById('footer').innerHTML =
      'GRIP v' + st.version +
      ' | ' + fmt.supported_count + ' file types' +
      (st.reranker_available ? ' + reranker' : '') +
      (st.llm_configured ? ' + LLM' : '') +
      ' | <a href=\"/licenses\" target=\"_blank\" style=\"color:#555;text-decoration:none\">licenses</a>';

    if (st.llm_configured) {{
      document.getElementById('llm-status').className = 'llm-ok';
      document.getElementById('llm-status').textContent = 'configured';
    }}

    renderSources();
  }} catch(e) {{
    document.getElementById('stats').textContent = 'Error loading: ' + e.message;
  }}
}}

function renderSources() {{
  const container = document.getElementById('source-chips');
  container.innerHTML = '';
  if (allSources.length === 0) {{
    document.getElementById('source-badge').innerHTML = 'No sources. Add files, directories, or git repos.';
    return;
  }}

  const totalChunks = allSources.reduce((s, src) => s + src.chunks, 0);
  document.getElementById('source-badge').innerHTML =
    '<span class="hl">' + allSources.length + '</span> sources (<span class="hl">' +
    totalChunks.toLocaleString() + ' chunks</span>)';

  allSources.forEach(src => {{
    const chip = document.createElement('span');
    chip.className = 'source-chip';
    chip.innerHTML = escapeHtml(src.name) +
      ' <span class="count">' + src.chunks.toLocaleString() + '</span>' +
      ' <span class="remove" title="Remove source" onclick="removeSource(\\\'' +
      escapeHtml(src.name).replace(/'/g, "\\\\'") + '\\\')">&times;</span>';
    container.appendChild(chip);
  }});
}}

// ── Ingest ──
async function doIngest() {{
  const path = document.getElementById('ingest-path').value.trim();
  if (!path) return;
  const st = document.getElementById('ingest-status');
  st.textContent = 'Ingesting...';
  st.style.color = '#888';

  try {{
    const res = await fetch('/ingest', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{paths: [path]}})
    }});
    const data = await res.json();
    if (res.ok) {{
      st.style.color = '#00ff88';
      st.textContent = data.chunks + ' chunks from ' + data.files + ' files (' +
        Math.round(data.index_time_ms) + 'ms)';
      document.getElementById('ingest-path').value = '';
      loadState();
    }} else {{
      st.style.color = '#ff4444';
      st.textContent = data.detail || data.error || 'Error';
    }}
  }} catch(e) {{
    st.style.color = '#ff4444';
    st.textContent = 'Error: ' + e.message;
  }}
}}

async function removeSource(name) {{
  if (!confirm('Remove source "' + name + '" and all its chunks?')) return;
  await fetch('/sources?name=' + encodeURIComponent(name), {{method: 'DELETE'}});
  loadState();
}}

// ── Search ──
async function doSearch() {{
  const q = document.getElementById('query').value.trim();
  if (!q) return;

  document.getElementById('search-btn').textContent = '...';
  try {{
    const res = await fetch('/search?q=' + encodeURIComponent(q) + '&top_k=10');
    const data = await res.json();

    document.getElementById('latency').style.display = 'inline-block';
    document.getElementById('ms').textContent = Math.round(data.latency_ms);

    const badge = document.getElementById('confidence-badge');
    badge.textContent = data.confidence;
    badge.className = 'confidence-badge confidence-' + data.confidence;

    // Show expansion/remembered indicators
    const indicators = document.getElementById('search-indicators');
    let indHtml = '';
    if (data.expanded_query) {{
      indHtml += '<span class="indicator indicator-expand">expanded: ' +
        escapeHtml(data.expanded_query) + '</span>';
    }}
    if (data.remembered) {{
      indHtml += '<span class="indicator indicator-remember">remembered query</span>';
    }}
    indicators.innerHTML = indHtml;

    const div = document.getElementById('results');
    if (!data.results || !data.results.length) {{
      div.innerHTML = '<div class="empty">No results</div>';
      return;
    }}

    div.innerHTML = data.results.map(r => `
      <div class="result">
        <div class="result-file">
          ${{escapeHtml(r.source.replace(/\\\\/g, '/').split('/').slice(-3).join('/'))}}
          ${{r.line ? '<span class="result-line">:' + r.line + '</span>' : ''}}
          <span class="result-score">${{r.score.toFixed(2)}}</span>
        </div>
        <div class="result-content">${{escapeHtml(r.text.substring(0, 400))}}</div>
      </div>
    `).join('');
  }} catch(e) {{
    document.getElementById('results').innerHTML =
      '<div class="empty" style="color:#ff4444">Error: ' + escapeHtml(e.message) + '</div>';
  }} finally {{
    document.getElementById('search-btn').textContent = 'Search';
  }}
}}

document.getElementById('query').addEventListener('keydown', e => {{
  if (e.key === 'Enter') doSearch();
}});

// ── LLM Config ──
async function doConfig() {{
  const provider = document.getElementById('llm-provider').value;
  const model = document.getElementById('llm-model').value.trim() || null;
  const apiKey = document.getElementById('llm-key').value.trim() || null;
  const status = document.getElementById('llm-status');

  try {{
    const res = await fetch('/config', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{provider, model, api_key: apiKey}})
    }});
    const data = await res.json();
    if (res.ok) {{
      status.className = 'llm-ok';
      status.textContent = data.provider + '/' + data.model;
    }} else {{
      status.className = 'llm-none';
      status.textContent = data.detail || 'Error';
    }}
  }} catch(e) {{
    status.className = 'llm-none';
    status.textContent = 'Error: ' + e.message;
  }}
}}

// ── Chat (Ask) ──
async function doChat() {{
  const q = document.getElementById('chat-input').value.trim();
  if (!q) return;

  const term = document.getElementById('terminal');
  document.getElementById('chat-input').value = '';
  document.getElementById('chat-btn').disabled = true;

  // User line
  const userLine = document.createElement('div');
  userLine.className = 'term-user';
  userLine.innerHTML = '<span class="prompt">you&gt;</span> ' + escapeHtml(q);
  term.appendChild(userLine);

  // Meta line
  const metaLine = document.createElement('div');
  metaLine.className = 'term-meta';
  metaLine.textContent = 'searching + generating answer...';
  term.appendChild(metaLine);

  // Response block
  const respBlock = document.createElement('div');
  respBlock.className = 'term-response';
  term.appendChild(respBlock);
  term.scrollTop = term.scrollHeight;

  try {{
    const res = await fetch('/query', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{q, top_k: 5, answer: true, session_id: chatSessionId}})
    }});
    const data = await res.json();

    if (!res.ok) {{
      metaLine.innerHTML = '<span style="color:#ff4444">' + escapeHtml(data.detail || data.error) + '</span>';
      respBlock.textContent = 'Configure an LLM provider above to get answers.';
    }} else {{
      // Update session ID from server response
      if (data.session_id) {{
        chatSessionId = data.session_id;
        const pill = document.getElementById('session-pill');
        pill.textContent = 'session: ' + chatSessionId;
        pill.style.display = 'inline-block';
        document.getElementById('new-session-btn').style.display = 'inline-block';
      }}

      let metaHtml =
        '<span class="hl">' + data.results.length + ' chunks</span> | ' +
        '<span class="hl">' + Math.round(data.latency_ms) + 'ms</span> | ' +
        'confidence: <span class="hl">' + data.confidence + '</span>';
      if (data.expanded_query) {{
        metaHtml += ' | <span style="color:#8888ff">expanded</span>';
      }}
      if (data.remembered) {{
        metaHtml += ' | <span style="color:#cc88ff">remembered</span>';
      }}
      metaLine.innerHTML = metaHtml;

      if (data.answer) {{
        respBlock.textContent = data.answer;
      }} else {{
        respBlock.textContent = data.results.length > 0
          ? 'Found ' + data.results.length + ' results. Configure LLM for an answer.'
          : 'No results found.';
      }}

      if (data.sources_cited && data.sources_cited.length) {{
        const citeLine = document.createElement('div');
        citeLine.className = 'term-meta';
        citeLine.innerHTML = 'cited: ' + data.sources_cited.map(s =>
          '<span class="hl">' + escapeHtml(s.split('/').slice(-2).join('/')) + '</span>'
        ).join(', ');
        term.appendChild(citeLine);
      }}
    }}
  }} catch(e) {{
    respBlock.textContent = 'Error: ' + e.message;
  }}

  // Divider
  const hr = document.createElement('hr');
  hr.className = 'term-divider';
  term.appendChild(hr);
  term.scrollTop = term.scrollHeight;

  document.getElementById('chat-btn').disabled = false;
  document.getElementById('chat-input').focus();
}}

function newSession() {{
  chatSessionId = 'session_' + Math.random().toString(36).substring(2, 10);
  document.getElementById('session-pill').textContent = 'session: ' + chatSessionId;
  const term = document.getElementById('terminal');
  const note = document.createElement('div');
  note.className = 'term-meta';
  note.innerHTML = '<span class="hl">new session started</span>';
  term.appendChild(note);
  const hr = document.createElement('hr');
  hr.className = 'term-divider';
  term.appendChild(hr);
  term.scrollTop = term.scrollHeight;
}}

function clearChat() {{
  chatSessionId = 'session_' + Math.random().toString(36).substring(2, 10);
  document.getElementById('session-pill').style.display = 'none';
  document.getElementById('new-session-btn').style.display = 'none';
  document.getElementById('terminal').innerHTML =
    '<div style="color:#555">grip&gt; Ready. Add sources, search, then ask questions.</div>';
  document.getElementById('chat-input').focus();
}}

document.getElementById('chat-input').addEventListener('keydown', e => {{
  if (e.key === 'Enter') handleInput();
}});

document.getElementById('ingest-path').addEventListener('keydown', e => {{
  if (e.key === 'Enter') doIngest();
}});

loadState();
</script>
</body>
</html>"""


# ─── Error handlers ──────────────────────────────────────────────────────────

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.detail, "detail": exc.detail},
    )


@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={"error": "internal_error", "detail": str(exc)},
    )


# ─── Main ────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=7878)
