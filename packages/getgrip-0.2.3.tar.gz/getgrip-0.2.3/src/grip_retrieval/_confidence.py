"""
Confidence scoring for retrieval results.

Analyzes reranker score distributions to detect when retrieval
may have missed. Expands candidate pool and re-reranks when
confidence is low.

Usage:
  from grip_retrieval._confidence import GuardedRetriever

  guard = GuardedRetriever(pipeline, reranker, doc_texts)
  results = guard.retrieve(query, top_k=10)
  # results.confidence: "HIGH" | "MEDIUM" | "LOW"
  # results.expanded: bool
"""

import math
import time
import numpy as np
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple


# ─── Confidence Thresholds ────────────────────────────────────────────────────

# Cross-encoder scores are roughly calibrated: >4 is strong match, <0 is weak.
# These thresholds were tuned on BEIR SciFact + NFCorpus + FiQA.

_TOP_SCORE_HIGH = 5.0       # Top score above this → likely found the right doc
_TOP_SCORE_LOW = 2.0        # Top score below this → probably missed

_GAP_HIGH = 2.0             # Gap between #1 and #2 above this → clear winner
_GAP_LOW = 0.5              # Gap below this → ambiguous

_ENTROPY_HIGH = 0.80        # Normalized entropy above this → too uniform (0-1 scale)
_VARIANCE_LOW = 1.0         # Variance of top-20 below this → too uniform

# Top-5 spread: gap between rank-1 and rank-5 scores. When top scores are
# tightly clustered (many docs score similarly), it signals broad relevance
# without a specific match — common false alarm in domains like finance/medical.
# FiQA diagnostic: false HIGH median=2.62, true HIGH median=4.54.
_TOP5_SPREAD_LOW = 3.5

# Expansion stages
_EXPANSION_STAGES = [200, 500, 1000]


# ─── Data Structures ─────────────────────────────────────────────────────────

@dataclass
class ConfidenceMetrics:
    """Score distribution metrics from reranker output."""
    top_score: float = 0.0
    second_score: float = 0.0
    score_gap: float = 0.0
    top20_mean: float = 0.0
    top20_std: float = 0.0
    top20_entropy: float = 0.0
    level: str = "LOW"  # HIGH, MEDIUM, LOW
    reason: str = ""


@dataclass
class GuardedResult:
    """Retrieval result with confidence metadata."""
    results: List[Dict] = field(default_factory=list)
    confidence: ConfidenceMetrics = field(default_factory=ConfidenceMetrics)
    expanded: bool = False
    candidate_pool: int = 200
    expansion_stages_tried: int = 0
    latency_ms: float = 0.0


# ─── Confidence Computation ──────────────────────────────────────────────────

def compute_confidence(scores: np.ndarray) -> ConfidenceMetrics:
    """
    Compute confidence metrics from an array of reranker scores.

    Args:
        scores: numpy array of cross-encoder scores, sorted descending.

    Returns:
        ConfidenceMetrics with level = HIGH/MEDIUM/LOW.
    """
    m = ConfidenceMetrics()

    if len(scores) < 2:
        m.level = "LOW"
        m.reason = "insufficient_candidates"
        return m

    m.top_score = float(scores[0])
    m.second_score = float(scores[1])
    m.score_gap = m.top_score - m.second_score

    # Top-20 statistics (or all if fewer)
    top_n = min(20, len(scores))
    top_scores = scores[:top_n]
    m.top20_mean = float(np.mean(top_scores))
    m.top20_std = float(np.std(top_scores))

    # Normalized entropy of top-20 (0 = one dominant, 1 = perfectly uniform)
    # Use softmax to convert scores to probability distribution, then
    # compute entropy relative to maximum possible entropy (log N).
    # This isolates uniformity from score magnitude.
    shifted = top_scores - top_scores.max()  # for numerical stability
    exp_scores = np.exp(shifted)
    probs = exp_scores / exp_scores.sum()
    raw_entropy = float(-np.sum(probs * np.log(probs + 1e-12)))
    max_entropy = math.log(top_n)  # entropy of uniform distribution
    m.top20_entropy = raw_entropy / max_entropy if max_entropy > 0 else 0.0

    # Decision logic: multiple signals vote
    high_votes = 0
    low_votes = 0
    reasons = []

    # Signal 1: Top score absolute value
    # Weight +1 (not +2) so LOW requires corroboration from other signals.
    # This prevents domains with generally lower scores (FiQA: finance) from
    # over-classifying as LOW on top_score alone.
    # FiQA diagnostic: false LOW top_score median=1.08, true LOW median=0.73.
    if m.top_score >= _TOP_SCORE_HIGH:
        high_votes += 2
    elif m.top_score <= _TOP_SCORE_LOW:
        low_votes += 1
        reasons.append(f"top_score={m.top_score:.2f}<{_TOP_SCORE_LOW}")

    # Signal 2: Score gap
    if m.score_gap >= _GAP_HIGH:
        high_votes += 1
    elif m.score_gap <= _GAP_LOW:
        low_votes += 1
        reasons.append(f"gap={m.score_gap:.2f}<{_GAP_LOW}")

    # Signal 3: Normalized entropy (high = uniform = bad)
    if m.top20_entropy >= _ENTROPY_HIGH:
        low_votes += 1
        reasons.append(f"norm_entropy={m.top20_entropy:.2f}>{_ENTROPY_HIGH}")

    # Signal 4: Variance (low variance = uniform = bad)
    if m.top20_std < _VARIANCE_LOW:
        low_votes += 1
        reasons.append(f"std={m.top20_std:.2f}<{_VARIANCE_LOW}")

    # Signal 5: Top-5 concentration — catches "broad relevance" false HIGHs.
    # When top_score is high but top-5 are tightly clustered, many docs are
    # equally relevant — suggests generic match, not specific. Only fires
    # when top_score already triggered high votes (prevents double-counting).
    # FiQA diagnostic: false HIGH spread median=2.62, true HIGH median=4.54.
    if m.top_score >= _TOP_SCORE_HIGH:
        top5 = scores[:min(5, len(scores))]
        top5_spread = float(top5[0] - top5[-1]) if len(top5) >= 5 else float('inf')
        if top5_spread < _TOP5_SPREAD_LOW:
            low_votes += 1
            reasons.append(f"top5_spread={top5_spread:.2f}<{_TOP5_SPREAD_LOW}")

    # Classify
    if low_votes >= 3:
        m.level = "LOW"
    elif high_votes >= 2 and low_votes == 0:
        m.level = "HIGH"
    elif low_votes >= 2:
        m.level = "LOW"
    else:
        m.level = "MEDIUM"

    m.reason = "; ".join(reasons) if reasons else "ok"
    return m


# ─── Guarded Retriever ───────────────────────────────────────────────────────

class GuardedRetriever:
    """
    Wraps an RT pipeline + reranker with confidence detection and adaptive expansion.

    When the reranker score distribution indicates low confidence (uniform scores,
    weak top score, small gap), the retriever expands the candidate pool
    and re-reranks to recover chunks that the initial retrieval missed.
    """

    def __init__(self, rt_pipeline, reranker, doc_texts, max_expansion=1000):
        """
        Args:
            rt_pipeline: Module with retrieve(query, top_k) returning
                         [{"doc_id": str, "score": float}, ...]
            reranker: CrossEncoder with predict(pairs, batch_size) method.
            doc_texts: Dict[str, str] mapping doc_id to document text.
            max_expansion: Maximum candidate pool size (default 1000).
        """
        self._rt = rt_pipeline
        self._reranker = reranker
        self._doc_texts = doc_texts
        self._max_expansion = max_expansion

        # Build expansion stages up to max
        self._stages = [s for s in _EXPANSION_STAGES if s <= max_expansion]
        if not self._stages or self._stages[-1] < max_expansion:
            self._stages.append(max_expansion)

    def retrieve(self, query: str, top_k: int = 10) -> GuardedResult:
        """
        Confidence-aware retrieval with adaptive expansion.

        Returns GuardedResult with results, confidence level, and metadata.
        """
        t0 = time.time()
        result = GuardedResult()

        for stage_idx, pool_size in enumerate(self._stages):
            # Stage 1: Get candidates from pre-filter
            rt_candidates = self._rt.retrieve(query, top_k=pool_size)
            if not rt_candidates:
                result.latency_ms = (time.time() - t0) * 1000
                return result

            # Stage 2: Rerank with cross-encoder
            pairs = []
            for c in rt_candidates:
                doc_id = c["doc_id"]
                doc_text = self._doc_texts.get(doc_id, "")
                pairs.append((query, doc_text[:2000]))

            scores = self._reranker.predict(
                pairs, batch_size=64, show_progress_bar=False
            )
            scores_arr = np.array(scores, dtype=np.float64)

            # Sort descending
            sort_idx = np.argsort(-scores_arr)
            sorted_scores = scores_arr[sort_idx]

            # Compute confidence
            confidence = compute_confidence(sorted_scores)

            # Build sorted results
            sorted_results = []
            for i in sort_idx:
                sorted_results.append({
                    "doc_id": rt_candidates[i]["doc_id"],
                    "score": float(scores_arr[i]),
                    "prefilter_score": rt_candidates[i].get("score", 0.0),
                })

            result.results = sorted_results[:top_k]
            result.confidence = confidence
            result.candidate_pool = pool_size
            result.expansion_stages_tried = stage_idx + 1

            # If confidence is HIGH or MEDIUM, we're done
            if confidence.level != "LOW":
                break

            # If this is the last stage, we're done regardless
            if stage_idx >= len(self._stages) - 1:
                break

            # Otherwise, expand and try again
            result.expanded = True

        result.latency_ms = (time.time() - t0) * 1000
        return result

    def retrieve_with_fallback(
        self, query: str, top_k: int = 10,
        bm25_fallback=None
    ) -> GuardedResult:
        """
        Retrieve with optional BM25 hybrid fallback.

        When confidence is LOW even after expansion, and a BM25 fallback
        is provided, merge BM25 results into the candidate pool and re-rerank.

        Args:
            query: Search query.
            top_k: Number of results to return.
            bm25_fallback: Optional callable(query, top_k) returning
                          [{"doc_id": str, "score": float}, ...].
        """
        result = self.retrieve(query, top_k=top_k)

        # If confidence is not LOW, or no fallback, return as-is
        if result.confidence.level != "LOW" or bm25_fallback is None:
            return result

        # BM25 fallback: get additional candidates
        t0 = time.time()
        bm25_results = bm25_fallback(query, top_k=200)
        if not bm25_results:
            return result

        # Merge: collect doc_ids we already have
        seen = {r["doc_id"] for r in result.results}

        # Get ALL candidates from the last expansion stage (before top_k truncation)
        # Re-retrieve at max pool size to get the full set
        rt_candidates = self._rt.retrieve(query, top_k=self._max_expansion)
        seen_full = {c["doc_id"] for c in rt_candidates}

        # Add BM25 candidates not already in the pool
        new_candidates = [
            c for c in bm25_results if c["doc_id"] not in seen_full
        ]

        if not new_candidates:
            return result  # BM25 found nothing new

        # Rerank the new candidates
        pairs = []
        for c in new_candidates:
            doc_text = self._doc_texts.get(c["doc_id"], "")
            pairs.append((query, doc_text[:2000]))

        new_scores = self._reranker.predict(
            pairs, batch_size=64, show_progress_bar=False
        )

        # Merge all reranked results
        all_results = list(result.results)  # Keep existing
        for i, c in enumerate(new_candidates):
            all_results.append({
                "doc_id": c["doc_id"],
                "score": float(new_scores[i]),
                "prefilter_score": c.get("score", 0.0),
                "source": "bm25_fallback",
            })

        # Re-sort and re-compute confidence
        all_results.sort(key=lambda x: -x["score"])
        all_scores = np.array([r["score"] for r in all_results], dtype=np.float64)
        new_confidence = compute_confidence(all_scores)

        result.results = all_results[:top_k]
        result.confidence = new_confidence
        result.candidate_pool += len(new_candidates)
        result.latency_ms += (time.time() - t0) * 1000
        return result


# ─── Standalone Analysis Utilities ────────────────────────────────────────────

def analyze_score_distribution(scores: List[float]) -> Dict:
    """
    Analyze a list of reranker scores and return confidence metrics as dict.
    Useful for offline analysis of existing results.
    """
    arr = np.array(sorted(scores, reverse=True), dtype=np.float64)
    m = compute_confidence(arr)
    return {
        "level": m.level,
        "top_score": m.top_score,
        "second_score": m.second_score,
        "score_gap": m.score_gap,
        "top20_mean": m.top20_mean,
        "top20_std": m.top20_std,
        "top20_entropy": m.top20_entropy,
        "reason": m.reason,
    }


def batch_confidence_report(query_scores: Dict[str, List[float]]) -> Dict:
    """
    Analyze confidence across many queries.

    Args:
        query_scores: {query_text: [score1, score2, ...]} from reranker.

    Returns:
        {"high": N, "medium": N, "low": N, "low_queries": [...]}
    """
    counts = {"HIGH": 0, "MEDIUM": 0, "LOW": 0}
    low_queries = []

    for query, scores in query_scores.items():
        analysis = analyze_score_distribution(scores)
        level = analysis["level"]
        counts[level] += 1
        if level == "LOW":
            low_queries.append({
                "query": query,
                "top_score": analysis["top_score"],
                "score_gap": analysis["score_gap"],
                "reason": analysis["reason"],
            })

    return {
        "high": counts["HIGH"],
        "medium": counts["MEDIUM"],
        "low": counts["LOW"],
        "total": sum(counts.values()),
        "low_pct": counts["LOW"] / max(sum(counts.values()), 1) * 100,
        "low_queries": low_queries,
    }


# ─── Self-Test ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("Recall Guard — confidence detection self-test")
    print()

    # Test 1: Clear winner (HIGH confidence)
    scores_high = np.array([8.5, 3.2, 2.1, 1.8, 1.5, 1.2, 0.8, 0.5,
                            0.3, 0.1, -0.2, -0.5, -0.8, -1.0, -1.2,
                            -1.5, -1.8, -2.0, -2.2, -2.5])
    m = compute_confidence(scores_high)
    print(f"  Test HIGH: level={m.level}, top={m.top_score:.1f}, "
          f"gap={m.score_gap:.1f}, entropy={m.top20_entropy:.2f}")
    assert m.level == "HIGH", f"Expected HIGH, got {m.level}"

    # Test 2: Uniform scores (LOW confidence)
    scores_low = np.array([1.1, 1.0, 0.95, 0.92, 0.90, 0.88, 0.86,
                           0.85, 0.84, 0.83, 0.82, 0.81, 0.80, 0.79,
                           0.78, 0.77, 0.76, 0.75, 0.74, 0.73])
    m = compute_confidence(scores_low)
    print(f"  Test LOW:  level={m.level}, top={m.top_score:.1f}, "
          f"gap={m.score_gap:.2f}, entropy={m.top20_entropy:.2f}")
    assert m.level == "LOW", f"Expected LOW, got {m.level}"

    # Test 3: Moderate (MEDIUM confidence)
    scores_med = np.array([4.5, 3.8, 2.5, 1.5, 0.8, 0.3, -0.2, -0.5,
                           -0.8, -1.0, -1.2, -1.5, -1.8, -2.0, -2.2,
                           -2.5, -2.8, -3.0, -3.2, -3.5])
    m = compute_confidence(scores_med)
    print(f"  Test MED:  level={m.level}, top={m.top_score:.1f}, "
          f"gap={m.score_gap:.2f}, entropy={m.top20_entropy:.2f}")
    assert m.level in ("MEDIUM", "HIGH", "LOW"), f"Expected MEDIUM/HIGH/LOW, got {m.level}"

    # Test 4: Very weak scores (LOW confidence)
    scores_weak = np.array([-1.5, -1.6, -1.7, -1.8, -1.9, -2.0, -2.1,
                            -2.2, -2.3, -2.4, -2.5, -2.6, -2.7, -2.8,
                            -2.9, -3.0, -3.1, -3.2, -3.3, -3.4])
    m = compute_confidence(scores_weak)
    print(f"  Test WEAK: level={m.level}, top={m.top_score:.1f}, "
          f"gap={m.score_gap:.2f}, entropy={m.top20_entropy:.2f}")
    assert m.level == "LOW", f"Expected LOW, got {m.level}"

    print()
    print("  All self-tests passed.")
