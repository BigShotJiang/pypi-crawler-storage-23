from __future__ import annotations

"""Query expansion via corpus co-occurrence graph.

Builds a PMI-based co-occurrence graph at index time. At query time, expands
terms that have low posting-list coverage with their strongest co-occurring
neighbors. Bridges vocabulary mismatch ("auth" -> "login password credential").
"""

import hashlib
import math
import sqlite3
from collections import Counter, defaultdict

from . import _engine as _rt


class QueryExpander:
    """Expand queries using corpus co-occurrence statistics."""

    def __init__(self, db: sqlite3.Connection):
        self._db = db
        self._db.execute("""
            CREATE TABLE IF NOT EXISTS cooccurrence (
                term1 TEXT NOT NULL,
                term2 TEXT NOT NULL,
                pmi REAL NOT NULL,
                PRIMARY KEY (term1, term2)
            )
        """)
        self._db.execute(
            "CREATE INDEX IF NOT EXISTS idx_cooccurrence_term1 "
            "ON cooccurrence (term1)"
        )
        self._db.commit()
        self._ready = self._has_data()

    @property
    def ready(self) -> bool:
        return self._ready

    def _has_data(self) -> bool:
        row = self._db.execute(
            "SELECT COUNT(*) FROM cooccurrence"
        ).fetchone()
        return (row[0] if row else 0) > 0

    def build_from_corpus(self, db: sqlite3.Connection, merge: bool = False):
        """Build co-occurrence graph from all chunks in SQLite.

        Sliding window (size=8) over every chunk.
        Count co-occurrences, compute PMI.
        Store top-8 neighbors per term.

        Args:
            merge: If True, INSERT OR REPLACE new edges without deleting
                existing ones first. Existing edges from previously deleted
                sources survive — this is the licensed tier behavior.
                If False, clear and rebuild from scratch (default).
        """
        import time
        t0 = time.time()

        rows = db.execute("SELECT text FROM chunks").fetchall()
        if not rows:
            return

        print("    Building co-occurrence graph...", end="", flush=True)

        # Count term frequencies and co-occurrences
        term_count: Counter = Counter()
        pair_count: Counter = Counter()
        total_windows = 0
        window_size = 8

        for (text,) in rows:
            tokens = _rt._tokenize(text)
            # Deduplicate within each window to avoid inflating PMI
            for i in range(len(tokens)):
                window = list(set(tokens[i:i + window_size]))
                total_windows += 1
                for t in window:
                    term_count[t] += 1
                # Count pairs within window
                for j in range(len(window)):
                    for k in range(j + 1, len(window)):
                        a, b = window[j], window[k]
                        if a > b:
                            a, b = b, a
                        pair_count[(a, b)] += 1

        if total_windows == 0:
            return

        # Compute PMI and store top-8 neighbors per term
        # PMI = log(P(a,b) / (P(a) * P(b)))
        # P(a) = term_count[a] / total_windows
        # P(a,b) = pair_count[(a,b)] / total_windows
        neighbors: dict[str, list[tuple[float, str]]] = defaultdict(list)

        min_cooccur = 3  # Minimum co-occurrence count for reliability
        for (a, b), count in pair_count.items():
            if count < min_cooccur:
                continue
            p_ab = count / total_windows
            p_a = term_count[a] / total_windows
            p_b = term_count[b] / total_windows
            if p_a == 0 or p_b == 0:
                continue
            pmi = math.log(p_ab / (p_a * p_b))
            if pmi > 0:  # Only positive associations
                neighbors[a].append((pmi, b))
                neighbors[b].append((pmi, a))

        # Keep top-8 per term, write to SQLite
        # merge=False (free/default): clear and rebuild from scratch
        # merge=True (licensed): preserve existing edges, add/update new ones
        if not merge:
            self._db.execute("DELETE FROM cooccurrence")

        batch = []
        for term, nbrs in neighbors.items():
            nbrs.sort(reverse=True)
            for pmi, neighbor in nbrs[:8]:
                batch.append((term, neighbor, pmi))

        self._db.executemany(
            "INSERT OR REPLACE INTO cooccurrence (term1, term2, pmi) "
            "VALUES (?, ?, ?)",
            batch,
        )
        self._db.commit()
        self._ready = True

        elapsed = time.time() - t0
        print(f" done ({elapsed:.1f}s, {len(neighbors):,} terms, "
              f"{len(batch):,} edges)")

    def expand(self, query: str, postings: dict | None = None) -> str:
        """Expand query terms not in posting lists.

        For each query token:
          - If token has postings (df >= 3): keep as-is
          - If token has NO postings (or df < 3): look up co-occurrence
            neighbors, append up to 3 highest-PMI neighbors.

        Returns expanded query string.
        """
        if not self._ready:
            return query

        if postings is None:
            postings = _rt._postings_idx

        tokens = _rt._tokenize(query)
        if not tokens:
            return query

        expansions = []
        for token in tokens:
            idx = postings.get(token)
            df = len(idx) if idx is not None else 0
            if df >= 3:
                continue  # Token has good coverage, no expansion needed

            # Look up co-occurrence neighbors
            rows = self._db.execute(
                "SELECT term2, pmi FROM cooccurrence "
                "WHERE term1 = ? ORDER BY pmi DESC LIMIT 3",
                (token,),
            ).fetchall()

            for term2, _pmi in rows:
                if term2 not in _rt._STOP and term2 not in tokens:
                    expansions.append(term2)

        if expansions:
            return query + " " + " ".join(expansions)
        return query
