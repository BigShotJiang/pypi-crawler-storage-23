"""GRIP license validation.

Validates Ed25519-signed license keys from the GRIP_LICENSE_KEY env var.
No network call. No phone-home. Fully air-gapped.

Usage::

    from grip_retrieval._license import validate_license

    info = validate_license()  # reads GRIP_LICENSE_KEY
    print(info.tier)           # "team"
    print(info.chunks)         # 500_000
    print(info.valid)          # True
"""
from __future__ import annotations

import os
import json
import base64
from datetime import datetime, timezone
from dataclasses import dataclass
from typing import Optional

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from cryptography.hazmat.primitives import serialization
    _HAS_CRYPTO = True
except ImportError:
    _HAS_CRYPTO = False


# ═══════════════════════════════════════════════════════════════════════
# Embedded public key (Ed25519)
# ═══════════════════════════════════════════════════════════════════════

PUBLIC_KEY_PEM = """
-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAAq9pVHjQK+O0mUkxVm+dj+mxBPLeQ6mRZBv/EpNYpfo=
-----END PUBLIC KEY-----
""".strip()

# ═══════════════════════════════════════════════════════════════════════

# Chunk limits per tier (must match keygen)
TIER_CHUNKS = {
    "personal": 100_000,
    "team": 500_000,
    "professional": 5_000_000,
    "enterprise": 25_000_000,
    "accelerated": 100_000_000,
}

# Free tier (no key required)
FREE_TIER_CHUNKS = 10_000


@dataclass
class LicenseInfo:
    """License validation result."""
    valid: bool
    tier: str
    chunks: int
    customer: str
    issued: str
    expires: str
    key_id: str
    expired: bool
    days_remaining: int
    error: Optional[str] = None


def _free_license() -> LicenseInfo:
    """Return a free-tier license when no key is set."""
    return LicenseInfo(
        valid=True,
        tier="free",
        chunks=FREE_TIER_CHUNKS,
        customer="",
        issued="",
        expires="",
        key_id="free",
        expired=False,
        days_remaining=999999,
        error=None,
    )


def _invalid_license(error: str) -> LicenseInfo:
    """Return an invalid license that falls back to free tier limits."""
    return LicenseInfo(
        valid=False,
        tier="free",
        chunks=FREE_TIER_CHUNKS,
        customer="",
        issued="",
        expires="",
        key_id="",
        expired=False,
        days_remaining=0,
        error=error,
    )


def _load_public_key() -> Ed25519PublicKey:
    """Load the embedded public key."""
    if not _HAS_CRYPTO:
        raise ImportError("pip install cryptography")
    return serialization.load_pem_public_key(PUBLIC_KEY_PEM.encode())


def validate_key(key_string: str) -> LicenseInfo:
    """Validate a GRIP license key string.

    Returns LicenseInfo with valid=True on success,
    or valid=False with error message on failure.
    Always returns a LicenseInfo -- never raises.
    """
    try:
        # Check prefix
        if not key_string.startswith("GRIP-"):
            return _invalid_license("Not a GRIP license key")

        body = key_string[5:]
        parts = body.rsplit(".", 1)
        if len(parts) != 2:
            return _invalid_license("Malformed key")

        payload_b64, sig_b64 = parts

        # Decode
        payload_bytes = base64.urlsafe_b64decode(payload_b64 + "==")
        signature = base64.urlsafe_b64decode(sig_b64 + "==")

        # Verify signature
        public_key = _load_public_key()
        try:
            public_key.verify(signature, payload_bytes)
        except Exception:
            return _invalid_license("Invalid signature")

        # Parse payload
        payload = json.loads(payload_bytes)

        # Validate fields
        for field in ("v", "tier", "chunks", "customer", "issued", "expires", "key_id"):
            if field not in payload:
                return _invalid_license(f"Missing field: {field}")

        # Check expiry
        expiry = datetime.strptime(payload["expires"], "%Y-%m-%d").replace(tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        expired = expiry < now
        days_remaining = max(0, (expiry - now).days)

        # Validate tier chunk count matches (prevent tampering)
        tier = payload["tier"]
        if tier in TIER_CHUNKS and payload["chunks"] != TIER_CHUNKS[tier]:
            return _invalid_license("Chunk limit mismatch")

        return LicenseInfo(
            valid=not expired,
            tier=tier,
            chunks=payload["chunks"],
            customer=payload["customer"],
            issued=payload["issued"],
            expires=payload["expires"],
            key_id=payload["key_id"],
            expired=expired,
            days_remaining=days_remaining,
            error="License expired" if expired else None,
        )

    except Exception as e:
        return _invalid_license(f"Validation error: {str(e)}")


def validate_license() -> LicenseInfo:
    """Read GRIP_LICENSE_KEY from environment and validate.

    No key set -> free tier (10,000 chunks).
    Valid key  -> tier limits apply.
    Invalid/expired key -> free tier + error message.

    This is the main entry point. Call on startup.
    """
    key = os.environ.get("GRIP_LICENSE_KEY", "").strip()

    if not key:
        return _free_license()

    return validate_key(key)


def enforce_chunk_limit(current_chunks: int, license_info: Optional[LicenseInfo] = None) -> bool:
    """Check if adding another chunk would exceed the limit.

    Returns True if under limit, False if at/over limit.
    """
    if license_info is None:
        license_info = validate_license()

    return current_chunks < license_info.chunks


def print_license_status(license_info: Optional[LicenseInfo] = None) -> None:
    """Print license status on engine startup."""
    if license_info is None:
        license_info = validate_license()

    if license_info.tier == "free":
        if license_info.error:
            print(f"  WARNING: {license_info.error}")
            print(f"  Running in free tier ({FREE_TIER_CHUNKS:,} chunks)")
        else:
            print(f"  GRIP Free — {FREE_TIER_CHUNKS:,} chunk limit")
            print(f"  Upgrade: https://getgrip.dev/pricing")
    elif license_info.expired:
        print(f"  WARNING: License expired ({license_info.expires})")
        print(f"  Falling back to free tier ({FREE_TIER_CHUNKS:,} chunks)")
        print(f"  Renew: https://getgrip.dev/pricing")
    else:
        print(f"  GRIP {license_info.tier.title()} — {license_info.chunks:,} chunks")
        print(f"  Licensed to: {license_info.customer}")
        print(f"  Expires: {license_info.expires} ({license_info.days_remaining} days)")
