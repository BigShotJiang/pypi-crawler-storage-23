"""
GRIP Universal Document Reader
================================

Extract searchable text from ANY file on someone's computer.
Every format a lawyer, researcher, student, or business owner has.

Each reader is independent — if a library isn't installed, that
format is skipped gracefully. The more you install, the more you
can search.

Install tiers:
  pip install getgrip                  → text, code, CSV, PDF, epub, email
  pip install getgrip[docs]            → + Word, Excel, PowerPoint, RTF, Outlook .msg
  pip install getgrip[ocr]             → + image OCR (scanned docs, photos)
  pip install getgrip[all]             → everything

License audit: All dependencies are MIT/BSD/Apache-2.0.
No GPL or AGPL dependencies. EPUB uses pure stdlib (zipfile + HTML parsing).
Outlook .msg uses olefile (BSD-2) instead of extract-msg (GPL-3).

Supported formats (30+):
  Documents:  .pdf .docx .doc .rtf .odt .epub .pages
  Spreadsheets: .xlsx .xls .csv .tsv .ods
  Presentations: .pptx .ppt .odp
  Email:      .eml .msg .mbox
  Images/OCR: .png .jpg .jpeg .tiff .bmp .gif .webp
  Data:       .json .xml .yaml .yml .toml
  Text:       .txt .md .log .ini .cfg
  Code:       .py .js .ts .java .c .cpp .go .rs .rb .sh .sql .html .css
  Archives:   .zip (searches inside zip files)
"""

import csv
import email
import io
import json
import os
import re
import zipfile
from pathlib import Path
from typing import Tuple, Optional


# ══════════════════════════════════════════════════════════════════════
#  DEPENDENCY DETECTION — check once at import time
# ══════════════════════════════════════════════════════════════════════

def _available(module_name: str) -> bool:
    try:
        __import__(module_name)
        return True
    except ImportError:
        return False

HAS_PYPDF     = _available("pypdf")
HAS_DOCX      = _available("docx")       # python-docx
HAS_OPENPYXL  = _available("openpyxl")
HAS_PPTX      = _available("pptx")       # python-pptx
HAS_STRIPRTF  = _available("striprtf")
HAS_ODF       = _available("odf")        # odfpy
HAS_RAPIDOCR  = _available("rapidocr")
HAS_PILLOW    = _available("PIL")
HAS_YAML      = _available("yaml")       # pyyaml
HAS_TOML      = _available("tomllib") or _available("toml")
HAS_XLRD      = _available("xlrd")       # legacy .xls
HAS_OLEFILE   = _available("olefile")    # legacy .doc, .ppt, .msg
HAS_XML       = True                      # built-in xml.etree
HAS_MBOX      = True                      # built-in mailbox


# ══════════════════════════════════════════════════════════════════════
#  SUPPORTED EXTENSIONS — what GRIP will index
# ══════════════════════════════════════════════════════════════════════

# Always supported (plain text, built-in Python)
TEXT_EXTENSIONS = frozenset({
    ".txt", ".md", ".log", ".ini", ".cfg", ".csv", ".tsv",
    ".json", ".xml", ".yaml", ".yml",
    ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".c", ".cpp", ".hpp",
    ".h", ".go", ".rs", ".rb", ".sh", ".bash", ".zsh", ".fish",
    ".sql", ".html", ".htm", ".css", ".scss", ".less",
    ".swift", ".kt", ".scala", ".r", ".m", ".pl", ".lua",
    ".toml", ".env", ".gitignore", ".dockerfile",
    ".tex", ".bib",   # LaTeX
    ".srt", ".vtt",   # Subtitles
})

# Supported with optional dependencies
DOCUMENT_EXTENSIONS = frozenset({
    ".pdf",
    ".docx", ".doc",
    ".xlsx", ".xls",
    ".pptx", ".ppt",
    ".rtf",
    ".odt", ".ods", ".odp",
    ".epub",
    ".eml", ".msg", ".mbox",
})

# OCR (images with text in them)
IMAGE_EXTENSIONS = frozenset({
    ".png", ".jpg", ".jpeg", ".tiff", ".tif",
    ".bmp", ".gif", ".webp",
})

# Archives (search inside)
ARCHIVE_EXTENSIONS = frozenset({
    ".zip",
})

# Combined — everything GRIP can potentially index
ALL_EXTENSIONS = TEXT_EXTENSIONS | DOCUMENT_EXTENSIONS | IMAGE_EXTENSIONS | ARCHIVE_EXTENSIONS


# ══════════════════════════════════════════════════════════════════════
#  INDIVIDUAL FORMAT READERS
#  Each returns (text, format_name) or ("", "error_reason")
# ══════════════════════════════════════════════════════════════════════

# ── PDF ──────────────────────────────────────────────────────────────

def read_pdf(path: str) -> Tuple[str, str]:
    """Extract text from PDF. Falls back to OCR for scanned PDFs."""
    if not HAS_PYPDF:
        return "", "needs: pip install pypdf"

    from pypdf import PdfReader
    try:
        reader = PdfReader(path)
        pages = []
        for i, page in enumerate(reader.pages):
            text = page.extract_text() or ""
            if text.strip():
                pages.append(f"[Page {i+1}]\n{text}")

        full_text = "\n\n".join(pages)

        # If PDF has very little text, it's probably scanned → try OCR
        if len(full_text.strip()) < 50 and HAS_RAPIDOCR and HAS_PILLOW:
            ocr_text = _ocr_pdf(path)
            if len(ocr_text) > len(full_text):
                return ocr_text, "pdf+ocr"

        return full_text, "pdf"
    except Exception as e:
        return "", f"pdf_error: {e}"


def _ocr_pdf(path: str) -> str:
    """OCR a scanned PDF by converting pages to images."""
    try:
        from pypdf import PdfReader
        from PIL import Image
        from rapidocr import RapidOCR

        ocr = RapidOCR()
        # pypdf can extract images from pages
        reader = PdfReader(path)
        all_text = []

        for i, page in enumerate(reader.pages):
            for image_obj in page.images:
                try:
                    img_data = image_obj.data
                    img = Image.open(io.BytesIO(img_data))
                    result = ocr(img)
                    if result and result.txts:
                        all_text.append(f"[Page {i+1}]\n" + "\n".join(result.txts))
                except Exception:
                    continue

        return "\n\n".join(all_text)
    except Exception:
        return ""


# ── Word (.docx) ────────────────────────────────────────────────────

def read_docx(path: str) -> Tuple[str, str]:
    """Extract text from Word .docx files including tables."""
    if not HAS_DOCX:
        return "", "needs: pip install python-docx"

    from docx import Document
    try:
        doc = Document(path)
        parts = []

        # Paragraphs
        for para in doc.paragraphs:
            text = para.text.strip()
            if text:
                # Preserve heading structure
                if para.style and para.style.name.startswith("Heading"):
                    level = para.style.name.replace("Heading ", "").strip()
                    parts.append(f"{'#' * int(level) if level.isdigit() else '#'} {text}")
                else:
                    parts.append(text)

        # Tables (critical for legal docs, invoices, reports)
        for table in doc.tables:
            table_text = _extract_table(table)
            if table_text:
                parts.append(table_text)

        return "\n\n".join(parts), "docx"
    except Exception as e:
        return "", f"docx_error: {e}"


def _extract_table(table) -> str:
    """Convert a docx table to readable text."""
    rows = []
    for row in table.rows:
        cells = [cell.text.strip() for cell in row.cells]
        if any(cells):  # skip empty rows
            rows.append(" | ".join(cells))
    return "\n".join(rows)


# ── Legacy Word (.doc) ──────────────────────────────────────────────

def read_doc(path: str) -> Tuple[str, str]:
    """Extract text from legacy .doc files."""
    # Try antiword first (if installed on system)
    try:
        import subprocess
        result = subprocess.run(
            ["antiword", path],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout, "doc"
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # Fallback: olefile can extract some text
    if HAS_OLEFILE:
        try:
            import olefile
            ole = olefile.OleFileIO(path)
            if ole.exists("WordDocument"):
                # Extract raw text stream
                stream = ole.openstream("WordDocument").read()
                # Rough text extraction from binary
                text = stream.decode("latin-1", errors="ignore")
                # Filter to printable chars
                text = re.sub(r'[^\x20-\x7E\n\r\t]', ' ', text)
                text = re.sub(r' {3,}', '\n', text)
                ole.close()
                if len(text.strip()) > 20:
                    return text.strip(), "doc"
            ole.close()
        except Exception:
            pass

    return "", "needs: antiword or pip install olefile"


# ── Excel (.xlsx) ───────────────────────────────────────────────────

def read_xlsx(path: str) -> Tuple[str, str]:
    """Extract all data from Excel spreadsheets."""
    if not HAS_OPENPYXL:
        return "", "needs: pip install openpyxl"

    from openpyxl import load_workbook
    try:
        wb = load_workbook(path, read_only=True, data_only=True)
        parts = []

        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            rows = []
            for row in ws.iter_rows(values_only=True):
                cells = [str(c) if c is not None else "" for c in row]
                if any(c.strip() for c in cells):
                    rows.append(" | ".join(cells))

            if rows:
                parts.append(f"[Sheet: {sheet_name}]\n" + "\n".join(rows))

        wb.close()
        return "\n\n".join(parts), "xlsx"
    except Exception as e:
        return "", f"xlsx_error: {e}"


# ── Legacy Excel (.xls) ────────────────────────────────────────────

def read_xls(path: str) -> Tuple[str, str]:
    """Extract data from legacy .xls files."""
    if not HAS_XLRD:
        return "", "needs: pip install xlrd"

    import xlrd
    try:
        wb = xlrd.open_workbook(path)
        parts = []
        for sheet in wb.sheets():
            rows = []
            for rx in range(sheet.nrows):
                cells = [str(sheet.cell_value(rx, cx)) for cx in range(sheet.ncols)]
                if any(c.strip() for c in cells):
                    rows.append(" | ".join(cells))
            if rows:
                parts.append(f"[Sheet: {sheet.name}]\n" + "\n".join(rows))
        return "\n\n".join(parts), "xls"
    except Exception as e:
        return "", f"xls_error: {e}"


# ── PowerPoint (.pptx) ─────────────────────────────────────────────

def read_pptx(path: str) -> Tuple[str, str]:
    """Extract text from PowerPoint presentations."""
    if not HAS_PPTX:
        return "", "needs: pip install python-pptx"

    from pptx import Presentation
    try:
        prs = Presentation(path)
        parts = []

        for i, slide in enumerate(prs.slides, 1):
            slide_texts = []
            for shape in slide.shapes:
                if shape.has_text_frame:
                    for para in shape.text_frame.paragraphs:
                        text = para.text.strip()
                        if text:
                            slide_texts.append(text)

                # Tables in slides
                if shape.has_table:
                    for row in shape.table.rows:
                        cells = [cell.text.strip() for cell in row.cells]
                        if any(cells):
                            slide_texts.append(" | ".join(cells))

            # Speaker notes (often contain the real content)
            if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
                notes = slide.notes_slide.notes_text_frame.text.strip()
                if notes:
                    slide_texts.append(f"[Notes] {notes}")

            if slide_texts:
                parts.append(f"[Slide {i}]\n" + "\n".join(slide_texts))

        return "\n\n".join(parts), "pptx"
    except Exception as e:
        return "", f"pptx_error: {e}"


# ── CSV / TSV ──────────────────────────────────────────────────────

def read_csv_file(path: str) -> Tuple[str, str]:
    """Read CSV/TSV into searchable text with headers as context."""
    try:
        ext = Path(path).suffix.lower()
        delimiter = '\t' if ext == '.tsv' else ','

        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            # Sniff delimiter
            sample = f.read(4096)
            f.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample)
                delimiter = dialect.delimiter
            except csv.Error:
                pass

            reader = csv.reader(f, delimiter=delimiter)
            rows = list(reader)

        if not rows:
            return "", "csv_empty"

        # First row is usually headers
        headers = rows[0] if rows else []
        parts = []

        if len(rows) <= 200:
            # Small file: include everything
            for i, row in enumerate(rows):
                if any(cell.strip() for cell in row):
                    parts.append(" | ".join(row))
        else:
            # Large file: include headers + every row, but cap at reasonable size
            parts.append("Headers: " + " | ".join(headers))
            parts.append(f"({len(rows)-1} rows)")
            for row in rows[1:5001]:  # Cap at 5000 data rows
                if any(cell.strip() for cell in row):
                    parts.append(" | ".join(row))
            if len(rows) > 5001:
                parts.append(f"[...{len(rows)-5001} more rows truncated]")

        return "\n".join(parts), "csv"
    except Exception as e:
        return "", f"csv_error: {e}"


# ── RTF ────────────────────────────────────────────────────────────

def read_rtf(path: str) -> Tuple[str, str]:
    """Extract text from Rich Text Format files."""
    if not HAS_STRIPRTF:
        return "", "needs: pip install striprtf"

    from striprtf.striprtf import rtf_to_text
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            rtf_content = f.read()
        text = rtf_to_text(rtf_content)
        return text, "rtf"
    except Exception as e:
        return "", f"rtf_error: {e}"


# ── Email (.eml) ───────────────────────────────────────────────────

def read_eml(path: str) -> Tuple[str, str]:
    """Extract text from email .eml files (built-in, no dependencies)."""
    try:
        with open(path, 'rb') as f:
            msg = email.message_from_binary_file(f)

        parts = []

        # Headers
        for header in ['From', 'To', 'Cc', 'Subject', 'Date']:
            val = msg.get(header, '')
            if val:
                parts.append(f"{header}: {val}")

        # Body
        if msg.is_multipart():
            for part in msg.walk():
                ctype = part.get_content_type()
                if ctype == 'text/plain':
                    payload = part.get_payload(decode=True)
                    if payload:
                        charset = part.get_content_charset() or 'utf-8'
                        parts.append(payload.decode(charset, errors='replace'))
                elif ctype == 'text/html':
                    payload = part.get_payload(decode=True)
                    if payload:
                        charset = part.get_content_charset() or 'utf-8'
                        html = payload.decode(charset, errors='replace')
                        parts.append(_strip_html(html))
        else:
            payload = msg.get_payload(decode=True)
            if payload:
                charset = msg.get_content_charset() or 'utf-8'
                text = payload.decode(charset, errors='replace')
                if msg.get_content_type() == 'text/html':
                    text = _strip_html(text)
                parts.append(text)

        return "\n\n".join(parts), "eml"
    except Exception as e:
        return "", f"eml_error: {e}"


# ── Outlook .msg ───────────────────────────────────────────────────

def read_msg(path: str) -> Tuple[str, str]:
    """Extract text from Outlook .msg files using olefile (BSD-2)."""
    if not HAS_OLEFILE:
        return "", "needs: pip install olefile"

    import olefile
    try:
        ole = olefile.OleFileIO(path)
        parts = []

        # Standard MAPI property streams in .msg files
        _MSG_FIELDS = [
            ("From", "__substg1.0_0C1F001F"),      # sender
            ("To", "__substg1.0_0E04001F"),          # to
            ("Cc", "__substg1.0_0E03001F"),          # cc
            ("Subject", "__substg1.0_0037001F"),     # subject
            ("Date", "__substg1.0_0039001F"),         # client submit time
        ]

        for label, stream_name in _MSG_FIELDS:
            try:
                if ole.exists(stream_name):
                    val = ole.openstream(stream_name).read().decode('utf-16-le', errors='replace').strip('\x00').strip()
                    if val:
                        parts.append(f"{label}: {val}")
            except Exception:
                continue

        # Body — try Unicode first, then ASCII
        body = ""
        for stream in ("__substg1.0_1000001F", "__substg1.0_1000001E"):
            try:
                if ole.exists(stream):
                    raw = ole.openstream(stream).read()
                    enc = 'utf-16-le' if stream.endswith("1F") else 'utf-8'
                    body = raw.decode(enc, errors='replace').strip('\x00').strip()
                    if body:
                        break
            except Exception:
                continue

        if body:
            parts.append(body)

        ole.close()

        if not parts:
            return "", "msg_empty"
        return "\n\n".join(parts), "msg"
    except Exception as e:
        return "", f"msg_error: {e}"


# ── Mailbox (.mbox) ───────────────────────────────────────────────

def read_mbox(path: str) -> Tuple[str, str]:
    """Extract text from mbox mail archives (built-in)."""
    import mailbox
    try:
        mbox = mailbox.mbox(path)
        parts = []

        for i, msg in enumerate(mbox):
            if i >= 5000:  # Cap at 5000 messages
                parts.append(f"[...truncated at 5000 messages]")
                break

            msg_parts = []
            subject = msg.get('Subject', '(no subject)')
            sender = msg.get('From', '')
            date = msg.get('Date', '')
            msg_parts.append(f"From: {sender} | Subject: {subject} | Date: {date}")

            if msg.is_multipart():
                for part in msg.walk():
                    if part.get_content_type() == 'text/plain':
                        payload = part.get_payload(decode=True)
                        if payload:
                            msg_parts.append(payload.decode('utf-8', errors='replace'))
            else:
                payload = msg.get_payload(decode=True)
                if payload:
                    msg_parts.append(payload.decode('utf-8', errors='replace'))

            parts.append("\n".join(msg_parts))

        mbox.close()
        return "\n\n---\n\n".join(parts), "mbox"
    except Exception as e:
        return "", f"mbox_error: {e}"


# ── EPUB ───────────────────────────────────────────────────────────

def read_epub(path: str) -> Tuple[str, str]:
    """Extract text from EPUB ebooks. Pure stdlib — no dependencies.

    EPUB files are ZIP archives containing XHTML content files.
    We read the OPF manifest to find content docs in spine order,
    then strip HTML to get the text.
    """
    try:
        import xml.etree.ElementTree as ET

        parts = []
        with zipfile.ZipFile(path, 'r') as zf:
            # 1. Find the OPF file from META-INF/container.xml
            opf_path = None
            try:
                container = zf.read("META-INF/container.xml").decode('utf-8', errors='replace')
                root = ET.fromstring(container)
                # Namespace-agnostic search for rootfile
                for elem in root.iter():
                    if elem.tag.endswith("rootfile"):
                        opf_path = elem.get("full-path")
                        break
            except Exception:
                pass

            # 2. If no OPF found, look for any .opf file
            if not opf_path:
                for name in zf.namelist():
                    if name.endswith(".opf"):
                        opf_path = name
                        break

            # 3. Parse OPF to get content files in reading order
            content_files = []
            if opf_path:
                opf_dir = opf_path.rsplit("/", 1)[0] + "/" if "/" in opf_path else ""
                try:
                    opf_data = zf.read(opf_path).decode('utf-8', errors='replace')
                    opf_root = ET.fromstring(opf_data)

                    # Build id→href map from manifest
                    id_to_href = {}
                    for elem in opf_root.iter():
                        if elem.tag.endswith("}item") or elem.tag == "item":
                            media = elem.get("media-type", "")
                            if "html" in media or "xml" in media:
                                item_id = elem.get("id", "")
                                href = elem.get("href", "")
                                if item_id and href:
                                    id_to_href[item_id] = opf_dir + href

                    # Get spine order
                    for elem in opf_root.iter():
                        if elem.tag.endswith("}itemref") or elem.tag == "itemref":
                            idref = elem.get("idref", "")
                            if idref in id_to_href:
                                content_files.append(id_to_href[idref])
                except Exception:
                    pass

            # 4. Fallback: just grab all .xhtml/.html files
            if not content_files:
                content_files = sorted(
                    n for n in zf.namelist()
                    if n.endswith(('.xhtml', '.html', '.htm'))
                    and 'META-INF' not in n
                )

            # 5. Extract text from each content file
            for cf in content_files:
                try:
                    html = zf.read(cf).decode('utf-8', errors='replace')
                    text = _strip_html(html)
                    if text.strip():
                        parts.append(text)
                except Exception:
                    continue

        if not parts:
            return "", "epub_empty"
        return "\n\n".join(parts), "epub"
    except Exception as e:
        return "", f"epub_error: {e}"


# ── OpenDocument (.odt, .ods, .odp) ────────────────────────────────

def read_odf(path: str) -> Tuple[str, str]:
    """Extract text from LibreOffice/OpenDocument files."""
    if not HAS_ODF:
        return "", "needs: pip install odfpy"

    from odf import text as odf_text
    from odf.opendocument import load
    try:
        doc = load(path)
        parts = []

        # Walk all text elements
        for element in doc.getElementsByType(odf_text.P):
            text_content = _odf_element_text(element)
            if text_content.strip():
                parts.append(text_content)

        ext = Path(path).suffix.lower()
        return "\n\n".join(parts), ext.lstrip(".")
    except Exception as e:
        return "", f"odf_error: {e}"


def _odf_element_text(element) -> str:
    """Recursively extract text from ODF XML element."""
    result = []
    if element.childNodes:
        for child in element.childNodes:
            if hasattr(child, 'data'):
                result.append(child.data)
            elif hasattr(child, 'childNodes'):
                result.append(_odf_element_text(child))
    return "".join(result)


# ── Images (OCR) ──────────────────────────────────────────────────

def read_image(path: str) -> Tuple[str, str]:
    """OCR text from images. Pure Python — no Tesseract binary needed."""
    if not HAS_RAPIDOCR:
        # Fallback: try pytesseract if available
        try:
            from PIL import Image
            import pytesseract
            img = Image.open(path)
            text = pytesseract.image_to_string(img)
            return text, "ocr-tesseract"
        except ImportError:
            return "", "needs: pip install rapidocr   (or pytesseract + Tesseract)"
        except Exception:
            return "", "ocr_error"

    try:
        from rapidocr import RapidOCR
        ocr = RapidOCR()
        result = ocr(path)
        if result and result.txts:
            return "\n".join(result.txts), "ocr"
        return "", "ocr_no_text"
    except Exception as e:
        return "", f"ocr_error: {e}"


# ── JSON ───────────────────────────────────────────────────────────

def read_json(path: str) -> Tuple[str, str]:
    """Extract searchable text from JSON files."""
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        # Flatten JSON into searchable text
        texts = []
        _flatten_json(data, texts)
        return "\n".join(texts), "json"
    except Exception as e:
        return "", f"json_error: {e}"


def _flatten_json(obj, texts, prefix=""):
    """Recursively flatten JSON into key: value lines."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            _flatten_json(v, texts, f"{prefix}{k}: " if not prefix else f"{prefix}.{k}: ")
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            _flatten_json(item, texts, f"{prefix}[{i}] ")
    else:
        val = str(obj)
        if val.strip():
            texts.append(f"{prefix}{val}" if prefix else val)


# ── XML ────────────────────────────────────────────────────────────

def read_xml(path: str) -> Tuple[str, str]:
    """Extract text content from XML files."""
    import xml.etree.ElementTree as ET
    try:
        tree = ET.parse(path)
        root = tree.getroot()
        texts = []
        _extract_xml_text(root, texts)
        return "\n".join(texts), "xml"
    except Exception as e:
        return "", f"xml_error: {e}"


def _extract_xml_text(element, texts):
    """Recursively extract text from XML elements."""
    if element.text and element.text.strip():
        tag = element.tag.split("}")[-1] if "}" in element.tag else element.tag
        texts.append(f"{tag}: {element.text.strip()}")
    if element.tail and element.tail.strip():
        texts.append(element.tail.strip())
    for child in element:
        _extract_xml_text(child, texts)


# ── YAML ───────────────────────────────────────────────────────────

def read_yaml(path: str) -> Tuple[str, str]:
    """Extract text from YAML files."""
    if not HAS_YAML:
        # Fall back to reading as text
        return _read_text(path)

    try:
        import yaml
        with open(path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        if data:
            texts = []
            _flatten_json(data, texts)  # Same logic works for YAML
            return "\n".join(texts), "yaml"
        return _read_text(path)
    except Exception:
        return _read_text(path)


# ── TOML ───────────────────────────────────────────────────────────

def read_toml(path: str) -> Tuple[str, str]:
    """Extract text from TOML files."""
    try:
        import tomllib  # Python 3.11+
        with open(path, 'rb') as f:
            data = tomllib.load(f)
    except ImportError:
        try:
            import toml
            with open(path, 'r', encoding='utf-8') as f:
                data = toml.load(f)
        except ImportError:
            return _read_text(path)
    except Exception:
        return _read_text(path)

    texts = []
    _flatten_json(data, texts)
    return "\n".join(texts), "toml"


# ── ZIP (search inside) ───────────────────────────────────────────

def read_zip(path: str) -> Tuple[str, str]:
    """Extract text from files inside a ZIP archive."""
    try:
        texts = []
        with zipfile.ZipFile(path, 'r') as zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                ext = Path(info.filename).suffix.lower()
                if ext in TEXT_EXTENSIONS:
                    try:
                        data = zf.read(info.filename)
                        text = data.decode('utf-8', errors='replace')
                        if text.strip():
                            texts.append(f"[{info.filename}]\n{text}")
                    except Exception:
                        continue

        return "\n\n".join(texts), "zip"
    except Exception as e:
        return "", f"zip_error: {e}"


# ── Subtitle files (.srt, .vtt) ───────────────────────────────────

def read_subtitle(path: str) -> Tuple[str, str]:
    """Extract dialogue text from subtitle files."""
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            content = f.read()

        # Strip timestamps and sequence numbers
        lines = content.split('\n')
        text_lines = []
        for line in lines:
            line = line.strip()
            # Skip empty, numbers, timestamps
            if not line:
                continue
            if line.isdigit():
                continue
            if re.match(r'^\d{2}:\d{2}', line):
                continue
            if line.startswith('WEBVTT'):
                continue
            # Strip HTML tags from subtitles
            line = re.sub(r'<[^>]+>', '', line)
            if line:
                text_lines.append(line)

        return "\n".join(text_lines), Path(path).suffix.lstrip(".")
    except Exception:
        return _read_text(path)


# ══════════════════════════════════════════════════════════════════════
#  HELPER FUNCTIONS
# ══════════════════════════════════════════════════════════════════════

def _strip_html(html: str) -> str:
    """Remove HTML tags and decode entities. No dependencies."""
    import html as html_module
    # Remove script/style blocks
    text = re.sub(r'<(script|style)[^>]*>.*?</\1>', '', html, flags=re.DOTALL | re.IGNORECASE)
    # Remove tags
    text = re.sub(r'<[^>]+>', ' ', text)
    # Decode entities
    text = html_module.unescape(text)
    # Collapse whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def _read_text(path: str) -> Tuple[str, str]:
    """Read plain text file with encoding fallback."""
    p = Path(path)
    try:
        text = p.read_text(encoding='utf-8')
        return text, p.suffix.lstrip(".")
    except UnicodeDecodeError:
        try:
            text = p.read_text(encoding='latin-1')
            return text, p.suffix.lstrip(".")
        except Exception:
            return "", "encoding_error"
    except Exception:
        return "", "read_error"


# ══════════════════════════════════════════════════════════════════════
#  MAIN ROUTER — replaces read_file() in chunker.py
# ══════════════════════════════════════════════════════════════════════

# Dispatch table: extension → reader function
_READERS = {
    # Documents
    ".pdf":   read_pdf,
    ".docx":  read_docx,
    ".doc":   read_doc,
    ".xlsx":  read_xlsx,
    ".xls":   read_xls,
    ".pptx":  read_pptx,
    # Legacy PPT — same approach as .doc
    ".rtf":   read_rtf,
    ".epub":  read_epub,
    ".odt":   read_odf,
    ".ods":   read_odf,
    ".odp":   read_odf,

    # Email
    ".eml":   read_eml,
    ".msg":   read_msg,
    ".mbox":  read_mbox,

    # Structured data
    ".csv":   read_csv_file,
    ".tsv":   read_csv_file,
    ".json":  read_json,
    ".xml":   read_xml,
    ".yaml":  read_yaml,
    ".yml":   read_yaml,
    ".toml":  read_toml,

    # Images (OCR)
    ".png":   read_image,
    ".jpg":   read_image,
    ".jpeg":  read_image,
    ".tiff":  read_image,
    ".tif":   read_image,
    ".bmp":   read_image,
    ".gif":   read_image,
    ".webp":  read_image,

    # Subtitles
    ".srt":   read_subtitle,
    ".vtt":   read_subtitle,

    # Archives
    ".zip":   read_zip,
}


def read_file(path: str) -> Tuple[str, str]:
    """
    Universal file reader. Drop-in replacement for chunker.read_file().

    Reads ANY supported file format and returns extracted text.

    Returns:
        (text, format_name) — text is the extracted content,
        format_name identifies what was detected/used.
    """
    ext = Path(path).suffix.lower()

    # Check dispatch table first
    reader = _READERS.get(ext)
    if reader:
        return reader(path)

    # HTML — strip tags
    if ext in ('.html', '.htm'):
        text, fmt = _read_text(path)
        if text:
            return _strip_html(text), "html"
        return text, fmt

    # All other text-like files
    if ext in TEXT_EXTENSIONS:
        return _read_text(path)

    return "", "unsupported"


# ══════════════════════════════════════════════════════════════════════
#  DIAGNOSTICS — what can GRIP read on this system?
# ══════════════════════════════════════════════════════════════════════

def get_supported_formats() -> dict:
    """Return dict of format → status (supported / needs X)."""
    status = {}

    # Always supported
    for ext in TEXT_EXTENSIONS:
        status[ext] = "supported"

    # Document formats
    status[".pdf"]  = "supported" if HAS_PYPDF else "needs: pip install pypdf"
    status[".docx"] = "supported" if HAS_DOCX else "needs: pip install python-docx"
    status[".doc"]  = "supported (basic)" if HAS_OLEFILE else "needs: antiword or pip install olefile"
    status[".xlsx"] = "supported" if HAS_OPENPYXL else "needs: pip install openpyxl"
    status[".xls"]  = "supported" if HAS_XLRD else "needs: pip install xlrd"
    status[".pptx"] = "supported" if HAS_PPTX else "needs: pip install python-pptx"
    status[".rtf"]  = "supported" if HAS_STRIPRTF else "needs: pip install striprtf"
    status[".epub"] = "supported"  # pure stdlib (zip + html parsing)
    status[".odt"]  = "supported" if HAS_ODF else "needs: pip install odfpy"
    status[".ods"]  = "supported" if HAS_ODF else "needs: pip install odfpy"
    status[".odp"]  = "supported" if HAS_ODF else "needs: pip install odfpy"

    # Email
    status[".eml"]  = "supported"  # built-in
    status[".msg"]  = "supported" if HAS_OLEFILE else "needs: pip install olefile"
    status[".mbox"] = "supported"  # built-in

    # OCR
    ocr_status = "supported" if HAS_RAPIDOCR else "needs: pip install rapidocr"
    for ext in IMAGE_EXTENSIONS:
        status[ext] = ocr_status

    status[".zip"] = "supported"

    return status


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "--formats":
        formats = get_supported_formats()
        supported = [ext for ext, s in sorted(formats.items()) if s.startswith("supported")]
        needs = [(ext, s) for ext, s in sorted(formats.items()) if not s.startswith("supported")]
        print(f"\nReady to search ({len(supported)} formats):")
        print("  " + "  ".join(supported))
        if needs:
            print(f"\nInstall to unlock ({len(needs)} more):")
            for ext, s in needs:
                print(f"  {ext:8s} -> {s}")
    elif len(sys.argv) > 1:
        path = sys.argv[1]
        print(f"Reading: {path}")
        text, fmt = read_file(path)
        print(f"Format: {fmt}")
        print(f"Length: {len(text)} chars")
        print(f"Preview: {text[:500]}")
    else:
        print("GRIP Universal Document Reader")
        print("  python readers.py --formats        Show supported formats")
        print("  python readers.py /path/to/file     Test reading a file")
