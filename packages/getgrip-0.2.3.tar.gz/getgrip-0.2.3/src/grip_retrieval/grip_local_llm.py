"""
GRIP Built-in LLM Backend — Zero Setup
=======================================

Auto-downloads a small, free model on first use. No Ollama,
no API keys, no configuration needed.

Model: Qwen2.5-1.5B-Instruct (Q4_K_M quantization)
Size:  1.12 GB download (one-time)
License: Apache 2.0 (free for commercial use)
Speed: ~10-20 tokens/sec on CPU (fast enough for RAG answers)

Usage:
    from grip_local_llm import LocalBackend, ensure_model

    # Auto-download model if needed
    model_path = ensure_model()

    # Create backend
    backend = LocalBackend(model_path)

    # Generate
    response = backend.generate(
        "What does this function do?",
        context="def authenticate(token): ..."
    )
    print(response.text)
"""

import os
import sys
import time
import json
from pathlib import Path
from typing import Optional, Iterator

# ── Config ───────────────────────────────────────────────────────────────────

MODEL_REPO = "Qwen/Qwen2.5-1.5B-Instruct-GGUF"
MODEL_FILE = "qwen2.5-1.5b-instruct-q4_k_m.gguf"
MODEL_SIZE_GB = 1.12
MODEL_DIR = Path.home() / ".grip" / "models"

DOWNLOAD_URL = (
    f"https://huggingface.co/{MODEL_REPO}/resolve/main/{MODEL_FILE}"
)


# ── Model Download ───────────────────────────────────────────────────────────

def get_model_path() -> Path:
    """Return expected model path."""
    return MODEL_DIR / MODEL_FILE


def model_exists() -> bool:
    """Check if model is already downloaded."""
    p = get_model_path()
    return p.exists() and p.stat().st_size > 100_000_000  # >100MB sanity check


def ensure_model(callback=None) -> Path:
    """
    Ensure the model file exists, downloading if necessary.

    Args:
        callback: Optional function(bytes_downloaded, total_bytes) for progress

    Returns:
        Path to the GGUF model file
    """
    if model_exists():
        return get_model_path()

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    model_path = get_model_path()
    tmp_path = model_path.with_suffix(".tmp")

    print(f"\n{'='*60}")
    print(f"  GRIP — Downloading built-in AI model (one-time)")
    print(f"  Model: Qwen2.5-1.5B-Instruct ({MODEL_SIZE_GB} GB)")
    print(f"  Saving to: {MODEL_DIR}")
    print(f"{'='*60}\n")

    try:
        # Try huggingface_hub first (better resume support)
        try:
            from huggingface_hub import hf_hub_download
            print("Downloading via Hugging Face Hub...")
            downloaded = hf_hub_download(
                repo_id=MODEL_REPO,
                filename=MODEL_FILE,
                local_dir=str(MODEL_DIR),
                local_dir_use_symlinks=False,
            )
            print(f"\nDownload complete: {downloaded}")
            return Path(downloaded)
        except ImportError:
            pass

        # Fallback to urllib (always available)
        import urllib.request
        import shutil

        print(f"Downloading from {DOWNLOAD_URL}")
        print("This may take a few minutes on a typical connection...\n")

        req = urllib.request.Request(DOWNLOAD_URL)
        req.add_header("User-Agent", "GRIP-Retrieval/0.2.2")

        with urllib.request.urlopen(req) as response:
            total = int(response.headers.get("Content-Length", 0))
            downloaded = 0
            chunk_size = 1024 * 1024  # 1MB chunks

            with open(tmp_path, "wb") as f:
                while True:
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)

                    if callback:
                        callback(downloaded, total)
                    elif total > 0:
                        pct = downloaded / total * 100
                        mb_done = downloaded / 1024 / 1024
                        mb_total = total / 1024 / 1024
                        bar = "█" * int(pct // 2) + "░" * (50 - int(pct // 2))
                        print(
                            f"\r  [{bar}] {pct:.1f}% "
                            f"({mb_done:.0f}/{mb_total:.0f} MB)",
                            end="", flush=True
                        )

        print("\n")

        # Rename tmp → final (atomic on most filesystems)
        tmp_path.rename(model_path)
        print(f"Model saved to: {model_path}")
        return model_path

    except Exception as e:
        # Clean up partial download
        if tmp_path.exists():
            tmp_path.unlink()
        raise RuntimeError(
            f"Failed to download model: {e}\n"
            f"You can manually download it from:\n"
            f"  {DOWNLOAD_URL}\n"
            f"And place it at:\n"
            f"  {model_path}"
        ) from e


def delete_model():
    """Delete the downloaded model to free disk space."""
    p = get_model_path()
    if p.exists():
        p.unlink()
        print(f"Deleted: {p}")
    else:
        print("No model found to delete.")


# ── Backend ──────────────────────────────────────────────────────────────────

class LocalBackend:
    """
    Built-in LLM backend using llama-cpp-python.

    Loads the model once, then generates answers from retrieved context.
    Runs entirely on CPU. No GPU required.
    """

    def __init__(self, model_path: Optional[str] = None, n_ctx: int = 4096,
                 n_threads: Optional[int] = None):
        """
        Initialize the local LLM.

        Args:
            model_path: Path to GGUF file. None = auto-download default model.
            n_ctx: Context window size (4096 is good for RAG)
            n_threads: CPU threads to use (None = auto-detect)
        """
        try:
            from llama_cpp import Llama
        except ImportError:
            raise ImportError(
                "llama-cpp-python is required for the built-in model.\n"
                "Install with: pip install llama-cpp-python\n"
                "Or use Ollama/OpenAI instead."
            )

        if model_path is None:
            model_path = str(ensure_model())

        if not Path(model_path).exists():
            raise FileNotFoundError(f"Model not found: {model_path}")

        print(f"Loading model: {Path(model_path).name}...")
        t0 = time.perf_counter()

        self.llm = Llama(
            model_path=model_path,
            n_ctx=n_ctx,
            n_threads=n_threads or self._default_threads(),
            n_gpu_layers=0,  # CPU only — GPU users should use Ollama
            verbose=False,
        )

        load_time = time.perf_counter() - t0
        print(f"Model loaded in {load_time:.1f}s")

        self.total_tokens = 0
        self.total_requests = 0

    @staticmethod
    def _default_threads() -> int:
        """Use half of available CPU cores."""
        import multiprocessing
        return max(2, multiprocessing.cpu_count() // 2)

    def generate(self, prompt: str, system: Optional[str] = None,
                 context: Optional[str] = None,
                 temperature: float = 0.3,
                 max_tokens: int = 512) -> dict:
        """
        Generate a response.

        Args:
            prompt: User question
            system: System prompt (optional)
            context: Retrieved chunks to answer from (optional)
            temperature: Creativity (0.0-1.0, lower = more focused)
            max_tokens: Max response length

        Returns:
            dict with 'text', 'tokens_used', 'latency_ms'
        """
        t0 = time.perf_counter()
        self.total_requests += 1

        messages = []

        # System prompt optimized for RAG
        sys_prompt = system or (
            "You are a helpful assistant. Answer questions based on the "
            "provided context. If the context doesn't contain enough "
            "information to answer, say so clearly. Be concise."
        )
        messages.append({"role": "system", "content": sys_prompt})

        # Add context as a system message
        if context:
            messages.append({
                "role": "system",
                "content": f"Context (retrieved from user's files):\n\n{context}"
            })

        messages.append({"role": "user", "content": prompt})

        try:
            response = self.llm.create_chat_completion(
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )

            text = response["choices"][0]["message"]["content"]
            tokens = response.get("usage", {}).get("total_tokens", 0)
            self.total_tokens += tokens

            return {
                "text": text,
                "model": "qwen2.5-1.5b-instruct (built-in)",
                "backend": "local",
                "tokens_used": tokens,
                "latency_ms": (time.perf_counter() - t0) * 1000,
                "finish_reason": response["choices"][0].get("finish_reason", "stop"),
            }

        except Exception as e:
            return {
                "text": f"Error: {e}",
                "model": "qwen2.5-1.5b-instruct (built-in)",
                "backend": "local",
                "tokens_used": 0,
                "latency_ms": (time.perf_counter() - t0) * 1000,
                "finish_reason": "error",
            }

    def stream(self, prompt: str, system: Optional[str] = None,
               context: Optional[str] = None,
               temperature: float = 0.3,
               max_tokens: int = 512) -> Iterator[str]:
        """Stream a response token by token."""
        self.total_requests += 1

        messages = []
        sys_prompt = system or (
            "You are a helpful assistant. Answer questions based on the "
            "provided context. If the context doesn't contain enough "
            "information to answer, say so clearly. Be concise."
        )
        messages.append({"role": "system", "content": sys_prompt})

        if context:
            messages.append({
                "role": "system",
                "content": f"Context (retrieved from user's files):\n\n{context}"
            })

        messages.append({"role": "user", "content": prompt})

        try:
            stream = self.llm.create_chat_completion(
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=True,
            )

            for chunk in stream:
                delta = chunk["choices"][0].get("delta", {})
                content = delta.get("content", "")
                if content:
                    yield content

        except Exception as e:
            yield f"Error: {e}"

    def get_stats(self) -> dict:
        return {
            "backend": "local",
            "model": "qwen2.5-1.5b-instruct-q4_k_m",
            "total_tokens": self.total_tokens,
            "total_requests": self.total_requests,
        }


# ── Integration with GRIP's existing _llm.py ────────────────────────────────
#
# To add this as a backend option in GRIP, add to _llm.py:
#
#   1. In the imports section:
#      LLAMA_CPP_AVAILABLE = False
#      try:
#          from llama_cpp import Llama
#          LLAMA_CPP_AVAILABLE = True
#      except ImportError:
#          pass
#
#   2. Add "local" to DEFAULT_MODELS:
#      DEFAULT_MODELS = {
#          "local": "qwen2.5-1.5b-instruct",  # Built-in, auto-downloads
#          "ollama": "qwen2.5-coder:32b",
#          ...
#      }
#
#   3. In get_available_backends(), add at the TOP (highest priority):
#      if LLAMA_CPP_AVAILABLE:
#          available.insert(0, "local")
#
#   4. In get_llm() factory, add:
#      elif backend == "local":
#          from .grip_local_llm import LocalBackend
#          return LocalBackend()
#
#   5. In server.py _startup(), auto-configure if no backend available:
#      if not _answer_eng and LLAMA_CPP_AVAILABLE:
#          from .grip_local_llm import LocalBackend
#          _local_llm = LocalBackend()
#
# The web UI dropdown would get a new option:
#   "Built-in (no setup)" alongside Ollama/OpenAI/Anthropic/Groq
#
# ─────────────────────────────────────────────────────────────────────────────


if __name__ == "__main__":
    """Quick test."""
    print("Testing GRIP built-in LLM...\n")

    # Ensure model exists
    model_path = ensure_model()

    # Load
    backend = LocalBackend(str(model_path))

    # Test RAG-style generation
    print("\n" + "=" * 60)
    print("Test: RAG-style question answering")
    print("=" * 60)

    context = """
    def authenticate_user(token: str) -> bool:
        '''Validate JWT token against the user database.'''
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
            user_id = payload.get('user_id')
            return User.objects.filter(id=user_id, is_active=True).exists()
        except jwt.ExpiredSignatureError:
            return False
        except jwt.InvalidTokenError:
            return False
    """

    response = backend.generate(
        "What does the authenticate_user function do?",
        context=context
    )

    print(f"\nAnswer: {response['text']}")
    print(f"Tokens: {response['tokens_used']}")
    print(f"Latency: {response['latency_ms']:.0f}ms")

    # Test streaming
    print("\n" + "=" * 60)
    print("Test: Streaming")
    print("=" * 60)
    print("\nAnswer: ", end="", flush=True)
    for chunk in backend.stream(
        "Explain this function in one sentence.",
        context=context
    ):
        print(chunk, end="", flush=True)
    print("\n")

    # Test "I don't know"
    print("=" * 60)
    print("Test: No relevant context")
    print("=" * 60)

    response = backend.generate(
        "What is the database migration strategy?",
        context="def calculate_tax(amount): return amount * 0.08"
    )
    print(f"\nAnswer: {response['text']}")

    print(f"\nStats: {backend.get_stats()}")
