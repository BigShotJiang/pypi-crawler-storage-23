# GRIP

**A retrieval engine that learns your vocabulary, remembers what works, and knows when it doesn't have an answer.**

No embedding models. No vector databases. No API keys. Just `pip install getgrip`.

## Try it in 60 seconds

```bash
pip install getgrip
getgrip                          # starts server on localhost:7878
```

```bash
# Ingest your code
curl -X POST localhost:7878/ingest \
  -H "Content-Type: application/json" \
  -d '{"paths": ["/path/to/your/code"]}'

# Search
curl "localhost:7878/search?q=authentication+handler&top_k=5"
```

Open `http://localhost:7878` for the web UI.

## What makes GRIP different

| Feature | GRIP | Vector DB + Embeddings |
|---------|------|----------------------|
| Setup time | `pip install getgrip` | Model download + DB setup + API keys |
| Cold start | < 2 seconds | Minutes (model loading) |
| Search latency | < 5ms | 50-200ms |
| Learns your data | Yes (co-occurrence) | No |
| Remembers queries | Yes (auto-reinforce) | No |
| Confidence scoring | HIGH/MEDIUM/LOW/NONE | Score number |
| Works offline | Yes | Depends |
| Dependencies | 4 (fastapi, uvicorn, pydantic, numpy) | 10-30+ |

## Features

- **Co-occurrence expansion** — learns term relationships from your data without external models
- **Auto-remember** — reinforces successful queries, persists across restarts
- **Session context** — conversational memory across interactions
- **Confidence scoring** — returns HIGH/MEDIUM/LOW/NONE so your app knows when to say "I don't know"
- **Plugin architecture** — GitHub repos, local files, multiple LLM providers
- **8 API endpoints** + directory browser + web UI — ingest, search, query, config, sources, stats, health
- **Fully offline** — no cloud dependency, air-gapped operation

## Benchmarks

**BEIR (industry standard):** 0.464 NDCG@10 across 6 datasets, 21,708 queries — no neural components, no GPU. Optional cross-encoder reranker (`getgrip[rerank]`) bumps this to ~0.58.

**Scaling:** 1K to 39M documents, streaming R^2 = 0.999. Queries under 10ms on typical corpora.

**Real-world accuracy (3,000 queries):**
- Linux Kernel: 98.7%
- Wikipedia: 98.5%
- Project Gutenberg: 95.4%
- **Combined: 97.5%**

## Docker

```bash
docker run -d -p 7878:7878 \
  -v grip-data:/data \
  -v /your/code:/code \
  griphub/grip:free
```

## Optional extras

```bash
pip install getgrip[pdf]      # PDF parsing
pip install getgrip[rerank]   # Cross-encoder reranking
pip install getgrip[llm]      # LLM-powered answers (OpenAI, Anthropic, Ollama, Groq)
pip install getgrip[all]      # Everything
```

## Pricing

| Tier | Chunks | Price |
|------|--------|-------|
| Free | 10,000 | $0 |
| Personal | 100,000 | $499/year |
| Team | 500,000 | $1,499/year |
| Professional | 5,000,000 | $4,999/year |

All tiers include all features. Licensed tiers preserve learning data across deletions.

**Website:** [getgrip.dev](https://getgrip.dev)
