"""Unified vetting orchestrator for the public API.

This module provides `vet_candidate`, the main entry point for running
a complete vetting pipeline on a transit candidate.

For batch processing, custom check selection, or pipeline extensibility,
use `VettingPipeline` directly from `tess_vetter.api.pipeline`.

Novelty: standard (orchestration of established vetting checks)

References:
    [1] Coughlin et al. 2016, ApJS 224, 12 (2016ApJS..224...12C)
        Kepler DR24 Robovetter methodology
    [2] Thompson et al. 2018, ApJS 235, 38 (2018ApJS..235...38T)
        Kepler DR25 vetting pipeline architecture
    [3] Guerrero et al. 2021, ApJS 254, 39 (2021ApJS..254...39G)
        TESS TOI catalog vetting procedures
"""

from __future__ import annotations

import warnings
from dataclasses import asdict
from typing import TYPE_CHECKING, Any, TypedDict, cast

from tess_vetter.api.contracts import (
    callable_input_schema_from_signature,
    model_output_schema,
)
from tess_vetter.api.references import (
    COUGHLIN_2016,
    GUERRERO_2021,
    THOMPSON_2018,
    cite,
    cites,
)
from tess_vetter.api.types import (
    Candidate,
    LightCurve,
    StellarParams,
    TPFStamp,
)
from tess_vetter.validation.result_schema import (
    VettingBundleResult as SchemaVettingBundleResult,
)

if TYPE_CHECKING:
    from tess_vetter.api.pipeline import PipelineConfig

# Module-level references for programmatic access (generated from central registry)
REFERENCES = [ref.to_dict() for ref in [COUGHLIN_2016, THOMPSON_2018, GUERRERO_2021]]


class PipelineConfigProvenance(TypedDict):
    """Provenance-safe serialized pipeline configuration."""

    timeout_seconds: float | None
    random_seed: int | None
    emit_warnings: bool
    fail_fast: bool
    extra_params: dict[str, Any]


class VetManySummaryRow(TypedDict):
    """Stable boundary row payload for vet_many summary output."""

    candidate_index: int
    period_days: float
    t0_btjd: float
    duration_hours: float
    depth_ppm: float
    n_ok: int
    n_skipped: int
    n_error: int
    flags_top: list[str]
    runtime_ms: float | None


def _pipeline_config_provenance(config: PipelineConfig) -> PipelineConfigProvenance:
    """Serialize effective pipeline config into provenance-safe primitives."""
    data = asdict(config)
    data["extra_params"] = dict(data.get("extra_params", {}))
    return cast(PipelineConfigProvenance, data)


@cites(
    cite(COUGHLIN_2016, "tiered Robovetter methodology"),
    cite(THOMPSON_2018, "DR25 vetting pipeline architecture"),
    cite(GUERRERO_2021, "TESS TOI vetting procedures context"),
)
def vet_candidate(
    lc: LightCurve,
    candidate: Candidate,
    *,
    stellar: StellarParams | None = None,
    tpf: TPFStamp | None = None,
    network: bool = False,
    ra_deg: float | None = None,
    dec_deg: float | None = None,
    tic_id: int | None = None,
    preset: str = "default",
    checks: list[str] | None = None,
    context: dict[str, Any] | None = None,
    pipeline_config: PipelineConfig | None = None,
) -> SchemaVettingBundleResult:
    """Run vetting checks on a transit candidate.

    This is a convenience wrapper around VettingPipeline for single-candidate
    vetting. For batch processing or custom check selection, use VettingPipeline
    directly.

    Args:
        lc: Light curve data.
        candidate: Transit candidate with ephemeris.
        stellar: Optional stellar parameters.
        tpf: Optional TPF data for pixel-level checks.
        network: Whether to allow network access for catalog checks.
        ra_deg: Right ascension in degrees.
        dec_deg: Declination in degrees.
        tic_id: TIC identifier.
        preset: Registry preset to use when `checks` is None.
            - "default": current default check set (V01-V15 subset + V11b)
            - "extended": default set plus additional metrics-only diagnostics (V16+)
        checks: Optional list of check IDs to run. If None, runs all registered.
        context: Additional context for checks.
        pipeline_config: Optional PipelineConfig forwarded to VettingPipeline.

    Returns:
        SchemaVettingBundleResult with all check results.

    Example:
        >>> from tess_vetter.api import (
        ...     LightCurve, Ephemeris, Candidate, vet_candidate
        ... )
        >>> import numpy as np
        >>> lc = LightCurve(
        ...     time=np.linspace(0, 27, 1000),
        ...     flux=np.ones(1000),
        ...     flux_err=np.ones(1000) * 0.001,
        ... )
        >>> eph = Ephemeris(period_days=3.5, t0_btjd=1.0, duration_hours=2.0)
        >>> candidate = Candidate(ephemeris=eph)
        >>> result = vet_candidate(lc, candidate, network=False)
        >>> print(f"Ran {len(result.results)} checks")

    Novelty: standard

    References:
        [1] Coughlin et al. 2016, ApJS 224, 12 (2016ApJS..224...12C)
            Kepler Robovetter tiered architecture
        [2] Thompson et al. 2018, ApJS 235, 38 (2018ApJS..235...38T)
            Section 3: Check execution ordering and aggregation
    """
    from tess_vetter.api.pipeline import PipelineConfig, VettingPipeline
    from tess_vetter.domain.detection import TransitCandidate
    from tess_vetter.validation.register_defaults import (
        register_all_defaults,
        register_extended_defaults,
    )
    from tess_vetter.validation.registry import CheckRegistry

    # Create registry with preset checks.
    #
    # Important: callers (e.g., astro-arc-tess) often pass an explicit `checks=[...]`
    # list. The registry must still include those IDs, so preset selection must not
    # depend on `checks is None`.
    registry = CheckRegistry()
    if str(preset).lower() == "extended":
        register_extended_defaults(registry)
    else:
        register_all_defaults(registry)

    # Convert public API types to internal types
    lc_internal = lc.to_internal(tic_id=tic_id or 0)

    # Convert Candidate to TransitCandidate
    # Use depth if provided, otherwise default to a small depth for metrics-only mode
    depth = candidate.depth if candidate.depth is not None else 0.001
    # Use a default SNR of 0.0 - this is metrics-only mode
    snr = 0.0

    candidate_internal = TransitCandidate(
        period=candidate.ephemeris.period_days,
        t0=candidate.ephemeris.t0_btjd,
        duration_hours=candidate.ephemeris.duration_hours,
        depth=depth,
        snr=snr,
    )

    # Create and run pipeline
    effective_pipeline_config = pipeline_config or PipelineConfig()
    pipeline = VettingPipeline(
        checks=checks,
        registry=registry,
        config=effective_pipeline_config,
    )
    bundle = pipeline.run(
        lc_internal,
        candidate_internal,
        stellar=stellar,
        tpf=tpf,
        network=network,
        ra_deg=ra_deg,
        dec_deg=dec_deg,
        tic_id=tic_id,
        context=context,
    )
    bundle.provenance["pipeline_config"] = _pipeline_config_provenance(
        effective_pipeline_config
    )
    return bundle


@cites(
    cite(COUGHLIN_2016, "tiered Robovetter methodology"),
    cite(THOMPSON_2018, "DR25 vetting pipeline architecture"),
    cite(GUERRERO_2021, "TESS TOI vetting procedures context"),
)
def vet_many(
    lc: LightCurve,
    candidates: list[Candidate],
    *,
    stellar: StellarParams | None = None,
    tpf: TPFStamp | None = None,
    network: bool = False,
    ra_deg: float | None = None,
    dec_deg: float | None = None,
    tic_id: int | None = None,
    preset: str = "default",
    checks: list[str] | None = None,
    context: dict[str, Any] | None = None,
    pipeline_config: PipelineConfig | None = None,
) -> tuple[list[SchemaVettingBundleResult], list[VetManySummaryRow]]:
    """Run vetting for multiple candidates against one light curve.

    This is the common workflow-building primitive for researchers:
    run multiple candidate ephemerides (or multi-planet candidates) on the same
    light curve and get both full bundles and a compact summary table.
    """
    from tess_vetter.api.pipeline import PipelineConfig, VettingPipeline
    from tess_vetter.domain.detection import TransitCandidate
    from tess_vetter.validation.register_defaults import (
        register_all_defaults,
        register_extended_defaults,
    )
    from tess_vetter.validation.registry import CheckRegistry

    registry = CheckRegistry()
    if str(preset).lower() == "extended":
        register_extended_defaults(registry)
    else:
        register_all_defaults(registry)

    lc_internal = lc.to_internal(tic_id=tic_id or 0)

    candidates_internal: list[TransitCandidate] = []
    for c in candidates:
        depth = c.depth if c.depth is not None else 0.001
        candidates_internal.append(
            TransitCandidate(
                period=c.ephemeris.period_days,
                t0=c.ephemeris.t0_btjd,
                duration_hours=c.ephemeris.duration_hours,
                depth=depth,
                snr=0.0,
            )
        )

    effective_pipeline_config = pipeline_config or PipelineConfig()
    pipeline = VettingPipeline(
        checks=checks,
        registry=registry,
        config=effective_pipeline_config,
    )
    bundles, summary = pipeline.run_many(
        lc_internal,
        candidates_internal,
        stellar=stellar,
        tpf=tpf,
        network=network,
        ra_deg=ra_deg,
        dec_deg=dec_deg,
        tic_id=tic_id,
        context=context,
    )
    config_provenance = _pipeline_config_provenance(effective_pipeline_config)
    for bundle in bundles:
        bundle.provenance["pipeline_config"] = dict(config_provenance)
    return (bundles, cast(list[VetManySummaryRow], summary))


# Legacy wrapper for backward compatibility with 'enabled' parameter
def _vet_candidate_legacy(
    lc: LightCurve,
    candidate: Candidate,
    *,
    stellar: StellarParams | None = None,
    tpf: TPFStamp | None = None,
    enabled: set[str] | None = None,
    config: dict[str, dict[str, Any]] | None = None,
    policy_mode: str = "metrics_only",
    network: bool = False,
    ra_deg: float | None = None,
    dec_deg: float | None = None,
    tic_id: int | None = None,
    context: dict[str, Any] | None = None,
) -> SchemaVettingBundleResult:
    """Legacy vet_candidate with deprecated parameters."""
    if policy_mode != "metrics_only":
        warnings.warn(
            "`policy_mode` is deprecated and ignored; tess-vetter always returns metrics-only "
            "results. Move interpretation/policy decisions to astro-arc-tess validation (tess-validate).",
            category=FutureWarning,
            stacklevel=2,
        )
    if config is not None:
        warnings.warn(
            "`config` parameter is deprecated. Use VettingPipeline with PipelineConfig for advanced "
            "configuration.",
            category=FutureWarning,
            stacklevel=2,
        )

    # Convert enabled set to checks list
    checks_list = list(enabled) if enabled is not None else None

    return vet_candidate(
        lc,
        candidate,
        stellar=stellar,
        tpf=tpf,
        network=network,
        ra_deg=ra_deg,
        dec_deg=dec_deg,
        tic_id=tic_id,
        checks=checks_list,
        context=context,
    )


VET_CANDIDATE_CALL_SCHEMA = callable_input_schema_from_signature(vet_candidate)
VET_CANDIDATE_OUTPUT_SCHEMA = model_output_schema(SchemaVettingBundleResult)
VET_MANY_CALL_SCHEMA = callable_input_schema_from_signature(vet_many)
VET_MANY_SUMMARY_ROW_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "candidate_index": {"type": "integer"},
        "period_days": {"type": "number"},
        "t0_btjd": {"type": "number"},
        "duration_hours": {"type": "number"},
        "depth_ppm": {"type": "number"},
        "n_ok": {"type": "integer"},
        "n_skipped": {"type": "integer"},
        "n_error": {"type": "integer"},
        "flags_top": {"type": "array", "items": {"type": "string"}},
        "runtime_ms": {"type": ["number", "null"]},
    },
    "required": [
        "candidate_index",
        "period_days",
        "t0_btjd",
        "duration_hours",
        "depth_ppm",
        "n_ok",
        "n_skipped",
        "n_error",
        "flags_top",
        "runtime_ms",
    ],
    "additionalProperties": False,
}
VET_MANY_OUTPUT_SCHEMA: dict[str, Any] = {
    "type": "array",
    "prefixItems": [
        {
            "type": "array",
            "items": VET_CANDIDATE_OUTPUT_SCHEMA,
        },
        {
            "type": "array",
            "items": VET_MANY_SUMMARY_ROW_SCHEMA,
        },
    ],
    "items": False,
    "minItems": 2,
    "maxItems": 2,
}
