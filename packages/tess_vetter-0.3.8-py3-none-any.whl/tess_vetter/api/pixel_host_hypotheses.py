"""Pixel host hypothesis scoring API surface (host-facing).

This module provides a stable facade for the lightweight PRF-lite host
hypothesis scoring types and thresholds.
"""

from __future__ import annotations

from tess_vetter.compute.pixel_host_hypotheses import (  # noqa: F401
    FLIP_RATE_MIXED_THRESHOLD,
    FLIP_RATE_UNSTABLE_THRESHOLD,
    MARGIN_RESOLVE_THRESHOLD,
    HypothesisScore,
)

__all__ = [
    "HypothesisScore",
    "MARGIN_RESOLVE_THRESHOLD",
    "FLIP_RATE_MIXED_THRESHOLD",
    "FLIP_RATE_UNSTABLE_THRESHOLD",
]
