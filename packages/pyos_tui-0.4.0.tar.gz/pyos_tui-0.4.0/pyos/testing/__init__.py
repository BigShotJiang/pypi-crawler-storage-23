from .harness import MockScreen, HarnessApplication


def PtyHarness(*args, **kwargs):
    from .pty_harness import PtyHarness as _PtyHarness
    return _PtyHarness(*args, **kwargs)


__all__ = ["MockScreen", "HarnessApplication", "PtyHarness"]
