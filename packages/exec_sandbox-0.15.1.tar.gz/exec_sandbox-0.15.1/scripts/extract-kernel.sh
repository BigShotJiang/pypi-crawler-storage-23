#!/bin/bash
# Build custom kernel and initramfs for QEMU microVM
#
# Orchestrates kernel build (build-kernel.sh) and initramfs creation
# (build-initramfs.sh). The custom kernel has all boot-critical drivers
# built-in (CONFIG_MODULES=n), eliminating module loading entirely.
#
# Usage:
#   ./scripts/extract-kernel.sh              # Build for current arch
#   ./scripts/extract-kernel.sh x86_64       # Build for x86_64
#   ./scripts/extract-kernel.sh aarch64      # Build for aarch64
#   ./scripts/extract-kernel.sh all          # Build for both

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
OUTPUT_DIR="$REPO_ROOT/images/dist"
ALPINE_VERSION="${ALPINE_VERSION:?ALPINE_VERSION must be set (exported by root Makefile)}"

detect_arch() {
    case "$(uname -m)" in
        x86_64|amd64) echo "x86_64" ;;
        aarch64|arm64) echo "aarch64" ;;
        *) echo "Unsupported arch: $(uname -m)" >&2; exit 1 ;;
    esac
}

# =============================================================================
# Cache helpers - content-addressable build caching via .hash sidecar files
# =============================================================================

# Get kernel package version from Alpine's package index (without running Docker)
# This ensures cache invalidation when Alpine updates the kernel package
get_kernel_version() {
    local arch=$1
    local apk_arch
    case "$arch" in
        x86_64)  apk_arch="x86_64" ;;
        aarch64) apk_arch="aarch64" ;;
    esac
    curl -sf "https://dl-cdn.alpinelinux.org/alpine/v${ALPINE_VERSION}/main/${apk_arch}/APKINDEX.tar.gz" 2>/dev/null \
        | tar -xzO APKINDEX 2>/dev/null \
        | grep -A1 "^P:linux-virt$" \
        | grep "^V:" \
        | cut -d: -f2 \
        || echo "unknown"
}

# Compute hash for kernel inputs (Alpine version + arch + kernel version + config fragment + build script)
compute_kernel_hash() {
    local arch=$1
    local kernel_ver
    kernel_ver=$(get_kernel_version "$arch")
    (
        echo "alpine=$ALPINE_VERSION arch=$arch kernel=$kernel_ver"
        cat "$REPO_ROOT/images/kernel/exec-sandbox.config"
        cat "$SCRIPT_DIR/build-kernel.sh"
    ) | sha256sum | cut -d' ' -f1
}

# Compute hash for initramfs inputs (tiny-init binary + build script)
# With CONFIG_MODULES=n, no kernel modules in initramfs — hash doesn't depend on kernel version.
compute_initramfs_hash() {
    local arch=$1
    (
        echo "arch=$arch"
        # Include tiny-init binary hash (if it exists)
        sha256sum "$OUTPUT_DIR/tiny-init-$arch" 2>/dev/null || echo "tiny-init-not-built"
        cat "$SCRIPT_DIR/build-initramfs.sh" 2>/dev/null || true
    ) | sha256sum | cut -d' ' -f1
}

# Check if output is up-to-date (hash matches)
cache_hit() {
    local output_file=$1
    local current_hash=$2
    local hash_file="${output_file}.hash"

    if [ -f "$output_file" ] && [ -f "$hash_file" ]; then
        local cached_hash
        cached_hash=$(cat "$hash_file" 2>/dev/null || echo "")
        [ "$cached_hash" = "$current_hash" ]
    else
        return 1
    fi
}

# Save hash after successful build
save_hash() {
    local output_file=$1
    local hash=$2
    echo "$hash" > "${output_file}.hash"
}

# =============================================================================
# Build functions
# =============================================================================

extract_for_arch() {
    local target_arch=$1
    local vmlinuz_file="$OUTPUT_DIR/vmlinuz-$target_arch"
    local initramfs_file="$OUTPUT_DIR/initramfs-$target_arch"

    # Check cache separately for kernel and initramfs
    local kernel_hash initramfs_hash
    kernel_hash=$(compute_kernel_hash "$target_arch")
    initramfs_hash=$(compute_initramfs_hash "$target_arch")

    local need_kernel=false need_initramfs=false

    if ! cache_hit "$vmlinuz_file" "$kernel_hash"; then
        need_kernel=true
    fi

    if ! cache_hit "$initramfs_file" "$initramfs_hash"; then
        need_initramfs=true
    fi

    # vmlinux (uncompressed ELF for PVH direct boot) has no .hash sidecar —
    # it's derived from vmlinuz and only matters for x86_64. If vmlinuz is
    # cached but vmlinux is missing (e.g. first build after adding PVH support,
    # or a prior build that failed extraction), we must still run extraction.
    local need_vmlinux=false
    if [ "$target_arch" = "x86_64" ] && [ ! -f "$OUTPUT_DIR/vmlinux-x86_64" ]; then
        need_vmlinux=true
    fi

    if [ "$need_kernel" = false ] && [ "$need_initramfs" = false ] && [ "$need_vmlinux" = false ]; then
        echo "Kernel up-to-date: $target_arch (cache hit)"
        return 0
    fi

    mkdir -p "$OUTPUT_DIR"

    # Build custom kernel if needed (build-kernel.sh handles its own caching internally,
    # but we also track the hash here for the outer cache layer)
    if [ "$need_kernel" = true ]; then
        "$SCRIPT_DIR/build-kernel.sh" "$target_arch"
        save_hash "$vmlinuz_file" "$kernel_hash"
    fi

    # Extract uncompressed vmlinux for PVH direct boot (x86_64 only, ~50ms faster).
    #
    # vmlinux is the raw ELF kernel extracted from the compressed vmlinuz
    # (bzImage). QEMU's -kernel flag with microvm/PVH uses it to skip the
    # real-mode boot stub, saving ~50ms per VM boot.
    #
    # Extraction runs when:
    #   - vmlinux is missing (first build, or prior build failed extraction)
    #   - vmlinuz was freshly rebuilt (kernel version changed)
    # When both vmlinuz and vmlinux exist and vmlinuz is unchanged, skip.
    #
    # aarch64 does not use vmlinux — Image (flat binary) is loaded directly
    # by QEMU's -kernel flag without a PVH entry point.
    #
    # Failure is fatal: vmlinux is not optional for x86_64. No fallback to
    # vmlinuz — that would silently degrade boot latency.
    if [ "$target_arch" = "x86_64" ]; then
        local vmlinux_file="$OUTPUT_DIR/vmlinux-x86_64"
        if [ ! -f "$vmlinux_file" ] || [ "$need_kernel" = true ]; then
            echo "Extracting vmlinux for PVH boot..."
            if ! "$SCRIPT_DIR/extract-vmlinux.sh" "$vmlinuz_file" > "$vmlinux_file"; then
                echo "ERROR: vmlinux extraction failed for x86_64" >&2
                rm -f "$vmlinux_file"
                return 1
            fi
            chmod 644 "$vmlinux_file"
            # Verify PVH note (XEN_ELFNOTE_PHYS32_ENTRY) — the ELF note that
            # tells QEMU/KVM where to jump for PVH boot. Without it, QEMU
            # falls back to real-mode boot, negating the latency win.
            # Uses Docker because readelf is not installed on macOS hosts.
            if ! docker run --rm -v "$OUTPUT_DIR:/output" --platform linux/amd64 \
                "alpine:$ALPINE_VERSION" sh -c "apk add --no-cache binutils >/dev/null 2>&1 && readelf -n /output/vmlinux-x86_64 2>/dev/null | grep -q Xen"; then
                echo "ERROR: vmlinux lacks PVH note for x86_64" >&2
                rm -f "$vmlinux_file"
                return 1
            fi
            echo "vmlinux-x86_64: PVH note verified ($(du -h "$vmlinux_file" | cut -f1))"
        else
            echo "vmlinux up-to-date: x86_64 (cache hit)"
        fi
    fi

    # Build initramfs if needed
    if [ "$need_initramfs" = true ]; then
        # Build minimal initramfs: tiny-init + device nodes only.
        # With CONFIG_MODULES=n, all drivers are built-in — no modules needed.
        "$SCRIPT_DIR/build-initramfs.sh" "$target_arch" "$OUTPUT_DIR"
        save_hash "$initramfs_file" "$initramfs_hash"
    fi

    # Report what was built
    if [ "$need_kernel" = true ] || [ "$need_initramfs" = true ]; then
        local vmlinuz_size initramfs_size
        vmlinuz_size=$(du -h "$vmlinuz_file" | cut -f1)
        initramfs_size=$(du -h "$initramfs_file" | cut -f1)
        echo "Extracted: vmlinuz-$target_arch ($vmlinuz_size), initramfs-$target_arch ($initramfs_size)"
    fi
}

main() {
    local target="${1:-$(detect_arch)}"

    # Check Docker is available
    if ! command -v docker >/dev/null 2>&1; then
        echo "Docker is required" >&2
        exit 1
    fi

    if [ "$target" = "all" ]; then
        extract_for_arch "x86_64"
        extract_for_arch "aarch64"
    else
        extract_for_arch "$target"
    fi
}

main "$@"
