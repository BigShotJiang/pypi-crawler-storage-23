import{b as r}from"./CJ8w6Ajr.js";var e=4;function a(o){return r(o,e)}export{a as c};
