# /epic-init — DEPRECATED

> **This skill has been replaced by `/task-init`.**
>
> Use `/task-init` instead. It supports all beads types:
> - `epic` / `feature` — full flow (PRD, RFC, CONTEXT, PLAN, ACTIVE)
> - `bug` / `task` / `chore` — simplified flow (BRIEF, ACTIVE)

When this skill is invoked, immediately redirect to `/task-init`.
