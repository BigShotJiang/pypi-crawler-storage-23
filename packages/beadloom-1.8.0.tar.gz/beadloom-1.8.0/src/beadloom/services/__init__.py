"""Services layer — CLI and MCP server entry points."""
