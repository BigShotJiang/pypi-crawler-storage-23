"""Beadloom - Context Oracle + Doc Sync Engine for AI-assisted development."""

__version__ = "1.8.0"
