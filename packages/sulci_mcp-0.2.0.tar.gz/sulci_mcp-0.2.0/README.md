# sulci-mcp-server

MCP server for [Sulci](https://sulci.xyz) — the universal AI context layer. Gives any MCP-compatible AI tool access to your cross-tool knowledge store.

## Installation

```bash
pip install sulci-mcp-server
```

Or run directly:

```bash
uvx sulci-mcp
```

## Quick Start

### stdio (default — Claude Desktop, Claude Code)

```bash
sulci-mcp
```

### Streamable HTTP (Cursor, VS Code Copilot, Windsurf, etc.)

```bash
sulci-mcp --transport streamable-http
```

This starts an HTTP server on `http://127.0.0.1:8000/mcp`.

### With authentication

```bash
export SULCI_API_KEY=your-secret-key
sulci-mcp --transport streamable-http
```

Clients must send `Authorization: Bearer your-secret-key` header. When `SULCI_API_KEY` is unset, no auth is required (dev mode).

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `SULCI_MCP_TRANSPORT` | `stdio` | Transport: `stdio` or `streamable-http` |
| `SULCI_MCP_HOST` | `127.0.0.1` | HTTP bind address |
| `SULCI_MCP_PORT` | `8000` | HTTP port |
| `SULCI_API_KEY` | *(empty)* | Bearer token for HTTP auth (empty = no auth) |
| `SULCI_DATA_DIR` | `~/.sulci` | Knowledge store directory |
| `SULCI_LLM_PROVIDER` | `openai` | LLM for extraction: `openai` or `anthropic` |
| `OPENAI_API_KEY` | | Required if using OpenAI provider |
| `ANTHROPIC_API_KEY` | | Required if using Anthropic provider |

CLI flags (`--transport`, `--host`, `--port`) override environment variables.

## Tools Provided

- **query_context** — Semantic search across your knowledge
- **add_knowledge** — Store facts, decisions, preferences
- **record_interaction** — Extract knowledge from conversations
- **list_knowledge** — Browse stored knowledge
- **delete_knowledge** — Remove a knowledge atom
- **list_conflicts** — View contradictions between atoms
- **resolve_conflict** — Pick a winner in a conflict
- **verification_queue** — Review atoms that need re-verification

## Connection Guide

See [docs/CONNECTION_GUIDE.md](https://github.com/jaimelopez/sulci/blob/main/docs/CONNECTION_GUIDE.md) for copy-pasteable config for Claude Desktop, Claude Code, Cursor, VS Code Copilot, Windsurf, and Continue.dev.
