"""Sulci MCP Server — tools and resources for AI coding assistants.

Compatible with any MCP client: Claude Desktop, Claude Code, OpenCode, and others.
"""

import argparse
import json
import logging
import os

from mcp.server.fastmcp import FastMCP
from sulci_core.config import get_config
from sulci_core.exceptions import QuotaExceededError
from sulci_core.extractor import KnowledgeExtractor
from sulci_core.intelligence import IntelligenceEngine
from sulci_core.models import AtomType, ConflictStatus, ContextQueryResult, KnowledgeAtom
from sulci_core.quotas import QuotaService
from sulci_core.store import KnowledgeStore

from sulci_mcp.formatters import format_atom_brief, format_atom_detailed, format_context_results

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Source tool identifier — configurable via SULCI_MCP_SOURCE env var.
# Defaults to "mcp" but can be set to "claude_mcp", "opencode_mcp", etc.
# for tracking which client contributed knowledge.
_SOURCE_TOOL = os.environ.get("SULCI_MCP_SOURCE", "mcp")


def _detect_project() -> str | None:
    """Auto-detect project name from CWD indicators."""
    from pathlib import Path

    cwd = Path(os.getcwd())

    # Check package.json
    pkg_json = cwd / "package.json"
    if pkg_json.exists():
        try:
            data = json.loads(pkg_json.read_text())
            name = data.get("name")
            if name:
                return name.lstrip("@").replace("/", "-")
        except (json.JSONDecodeError, OSError):
            pass

    # Check pyproject.toml
    pyproject = cwd / "pyproject.toml"
    if pyproject.exists():
        try:
            text = pyproject.read_text()
            for line in text.splitlines():
                if line.strip().startswith("name"):
                    # Parse name = "value"
                    _, _, val = line.partition("=")
                    val = val.strip().strip('"').strip("'")
                    if val:
                        return val
        except OSError:
            pass

    # Check .git directory — use folder name
    if (cwd / ".git").exists():
        return cwd.name

    return None


mcp = FastMCP(
    "Sulci",
    instructions="Universal AI context layer — access your cross-tool knowledge",
)

# Global state
_store: KnowledgeStore | None = None
_extractor: KnowledgeExtractor | None = None
_intelligence: IntelligenceEngine | None = None
_quotas: QuotaService | None = None
_initialized = False
_cloud_mode = False  # True when SULCI_API_URL is set — routes all store calls to REST API


def _apply_persisted_settings(config) -> None:
    """Load settings.json from data dir and apply to config (same as API server)."""
    import contextlib

    settings_path = config.data_dir / "settings.json"
    if not settings_path.exists():
        return
    try:
        raw = settings_path.read_text()
        if config.encryption_enabled:
            with contextlib.suppress(Exception):
                from sulci_core.encryption import EncryptionManager

                enc = EncryptionManager(config.data_dir)
                raw = enc.decrypt(raw)
        settings = json.loads(raw)
        for key in ("llm_provider", "anthropic_api_key", "openai_api_key", "anthropic_model", "openai_model"):
            if key in settings and settings[key]:
                setattr(config, key, settings[key])
        logger.info("Loaded persisted LLM settings from %s", settings_path)
    except (json.JSONDecodeError, OSError, AttributeError) as e:
        logger.warning("Failed to load settings.json: %s", e)


async def _ensure_initialized():
    """Lazy initialization of core services. Skipped in cloud mode."""
    global _store, _extractor, _intelligence, _quotas, _initialized, _cloud_mode
    if _initialized:
        return
    config = get_config()
    if config.api_url:
        # Cloud mode: route all store calls to the remote REST API
        _cloud_mode = True
        _initialized = True
        logger.info("Sulci MCP server initialized in cloud mode → %s", config.api_url)
        return
    _apply_persisted_settings(config)
    _store = KnowledgeStore(config)
    await _store.initialize()
    _extractor = KnowledgeExtractor(config, _store)
    _intelligence = IntelligenceEngine(config, _store)
    _quotas = QuotaService(config, _store.session_factory)
    _initialized = True
    logger.info("Sulci MCP server initialized")


async def _call_api(method: str, path: str, **kwargs) -> dict:
    """Call the Sulci API — cloud (SULCI_API_URL) or local (localhost)."""
    import httpx

    config = get_config()
    if config.api_url:
        base = config.api_url.rstrip("/")
        token = config.api_token
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        connect_err_msg = f"Cannot reach Sulci cloud at {base}. Check SULCI_API_URL."
    else:
        base = f"http://localhost:{config.api_port}"
        headers = {}
        if config.api_key:
            headers["Authorization"] = f"Bearer {config.api_key}"
        connect_err_msg = "Sulci API not running. Start it with `make dev-api` or `sulci-start`."

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.request(method, f"{base}{path}", headers=headers, **kwargs)
            if resp.status_code == 204:
                return {}
            if resp.status_code >= 400:
                return {"error": f"API returned {resp.status_code}: {resp.text[:200]}"}
            return resp.json()
    except httpx.ConnectError:
        return {"error": connect_err_msg}
    except Exception as e:
        return {"error": str(e)}


# --- Tools ---


@mcp.tool()
async def query_context(query: str, limit: int = 10, project: str | None = None) -> str:
    """Retrieve relevant knowledge from your cross-tool context.

    Use this to find information from previous conversations across all AI tools.
    Returns the most relevant knowledge atoms ranked by relevance.
    Automatically detects the current project from the working directory.

    Args:
        query: What to search for (natural language)
        limit: Maximum number of results (default 10)
        project: Filter by project (auto-detected from CWD if not set)
    """
    await _ensure_initialized()
    if project is None:
        project = _detect_project()
    if _cloud_mode:
        result = await _call_api("POST", "/api/v1/context/query", json={"query": query, "limit": limit, "project": project})
        if "error" in result:
            return f"Error: {result['error']}"
        results = result.get("results", [])
        if not results:
            return "No relevant context found."
        header = f"Relevant context from previous interactions (project: {project}):" if project else "Relevant context from previous interactions:"
        lines = [header]
        for i, r in enumerate(results, 1):
            atom = r.get("atom", {})
            score = r.get("relevance_score", 0.0)
            confidence = atom.get("confidence", 0.5)
            confidence_label = "high" if confidence >= 0.8 else "medium" if confidence >= 0.5 else "low"
            projects = atom.get("projects", [])
            scope = f"[{', '.join(projects)}]" if projects else "[global]"
            lines.append(f"{i}. [{atom.get('atom_type', 'fact')}] {scope} {atom.get('content', '')} (relevance: {score:.2f}, {confidence_label} confidence)")
        return "\n".join(lines)
    try:
        await _quotas.check_context_queries()
    except QuotaExceededError as e:
        return f"Quota exceeded: {e}"
    try:
        results = await _intelligence.query_relevant(query, limit=limit, project=project)
        results = await _intelligence.resolve_conflicts(results)
    except Exception as e:
        logger.warning("Vector search failed, falling back to SQL listing: %s", e)
        # Fallback: return recent atoms instead of crashing
        atoms = await _store.list_atoms(limit=limit, project=project)
        results = [ContextQueryResult(atom=a, relevance_score=0.5, vector_similarity=0.5) for a in atoms]
    await _quotas.increment_context_queries()
    return format_context_results(results, project=project)


@mcp.tool()
async def add_knowledge(
    content: str,
    atom_type: str = "fact",
    subject: str | None = None,
    predicate: str | None = None,
    object_value: str | None = None,
    tags: str = "",
    projects: str = "",
    source: str = "",
) -> str:
    """Store a new piece of knowledge in your cross-tool context.

    Use this to save important information, decisions, or preferences
    that should be available across all AI tools.

    Args:
        content: Human-readable description of the knowledge
        atom_type: Type: fact, decision, preference, entity, relationship, context, instruction
        subject: Main entity or topic (optional)
        predicate: Property or relationship (optional)
        object_value: Value or target (optional)
        tags: Comma-separated tags (optional)
        projects: Comma-separated project names (empty = global, auto-detected from CWD)
        source: Source tool identifier (default: uses SULCI_MCP_SOURCE env var or "mcp")
    """
    await _ensure_initialized()
    if not _cloud_mode:
        try:
            await _quotas.check_atoms()
        except QuotaExceededError as e:
            return f"Quota exceeded: {e}"
    tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []
    proj_list = [p.strip() for p in projects.split(",") if p.strip()] if projects else []
    if not proj_list:
        detected = _detect_project()
        if detected and atom_type not in ("preference", "instruction"):
            proj_list = [detected]

    source_tool = source.strip() if source else _SOURCE_TOOL

    if _cloud_mode:
        payload = {
            "atom_type": atom_type,
            "content": content,
            "source_tool": source_tool,
            "tags": tag_list,
            "projects": proj_list,
        }
        if subject:
            payload["subject"] = subject
        if predicate:
            payload["predicate"] = predicate
        if object_value:
            payload["object"] = object_value
        result = await _call_api("POST", "/api/v1/knowledge", json=payload)
        if "error" in result:
            return f"Error: {result['error']}"
        atom_id = result.get("id", "?")
        return f"Knowledge stored (id: {atom_id})\n\nContent: {result.get('content', content)}"

    atom = KnowledgeAtom(
        atom_type=AtomType(atom_type),
        content=content,
        subject=subject,
        predicate=predicate,
        object=object_value,
        source_tool=source_tool,
        tags=tag_list,
        projects=proj_list,
    )
    stored = await _store.add_atom(atom)
    return f"Knowledge stored (id: {stored.id})\n\n{format_atom_detailed(stored)}"


@mcp.tool()
async def record_interaction(
    conversation_json: str,
    source: str = "",
    project: str | None = None,
) -> str:
    """Record a conversation and extract knowledge from it.

    Use this to process a conversation transcript and automatically
    extract structured knowledge atoms.

    Args:
        conversation_json: JSON array of message objects with "role" and "content" fields
        source: Source tool identifier (default: uses SULCI_MCP_SOURCE env var or "mcp")
        project: Project name for scoping (auto-detected from CWD if not set)
    """
    await _ensure_initialized()
    if project is None:
        project = _detect_project()
    try:
        messages = json.loads(conversation_json)
    except json.JSONDecodeError:
        return "Error: Invalid JSON. Provide an array of {role, content} objects."

    if not isinstance(messages, list):
        return "Error: Expected a JSON array of messages."

    if _cloud_mode:
        result = await _call_api(
            "POST", "/api/v1/interactions",
            json={"messages": messages, "source_tool": source or _SOURCE_TOOL, "project": project},
        )
        if "error" in result:
            return f"Error: {result['error']}"
        atom_ids = result.get("extracted_atom_ids", [])
        count = len(atom_ids)
        if count == 0:
            return "No new knowledge extracted from this conversation."
        return f"Extracted {count} knowledge atom(s) from interaction."

    try:
        await _quotas.check_extractions()
    except QuotaExceededError as e:
        return f"Quota exceeded: {e}"

    atoms = await _extractor.extract_from_messages(messages, source_tool=source or _SOURCE_TOOL, project=project)
    if not atoms:
        return "No new knowledge extracted from this conversation."

    await _quotas.increment_extractions()

    lines = [f"Extracted {len(atoms)} knowledge atom(s):"]
    for atom in atoms:
        lines.append(f"  - {format_atom_brief(atom)}")
    return "\n".join(lines)


@mcp.tool()
async def list_knowledge(
    atom_type: str | None = None,
    limit: int = 20,
    project: str | None = None,
) -> str:
    """Browse your stored knowledge.

    Args:
        atom_type: Filter by type (fact/decision/preference/entity/relationship/context/instruction)
        limit: Maximum results (default 20)
        project: Filter by project (auto-detected from CWD if not set)
    """
    await _ensure_initialized()
    if project is None:
        project = _detect_project()

    if _cloud_mode:
        qs = f"?limit={limit}"
        if atom_type:
            qs += f"&atom_type={atom_type}"
        if project:
            qs += f"&project={project}"
        result = await _call_api("GET", f"/api/v1/knowledge{qs}")
        if isinstance(result, dict) and "error" in result:
            return f"Error: {result['error']}"
        atoms = result if isinstance(result, list) else []
        if not atoms:
            return "No knowledge atoms found."
        lines = [f"Found {len(atoms)} knowledge atom(s):"]
        for a in atoms:
            projects = a.get("projects", [])
            scope = f"[{', '.join(projects)}]" if projects else "[global]"
            lines.append(f"\n[{a.get('atom_type', '?')}] {scope} {a.get('content', '')}")
            lines.append(f"  ID: {a.get('id', '?')} | Confidence: {a.get('confidence', 0):.2f}")
            lines.append("---")
        return "\n".join(lines)

    at = AtomType(atom_type) if atom_type else None
    # Preferences and instructions are global — don't filter by project
    effective_project = None if at in (AtomType.PREFERENCE, AtomType.INSTRUCTION) else project
    atoms = await _store.list_atoms(atom_type=at, limit=limit, project=effective_project)
    if not atoms:
        return "No knowledge atoms found."

    lines = [f"Found {len(atoms)} knowledge atom(s):"]
    for atom in atoms:
        lines.append(f"\n{format_atom_detailed(atom)}")
        lines.append("---")
    return "\n".join(lines)


@mcp.tool()
async def delete_knowledge(atom_id: str) -> str:
    """Delete a knowledge atom by ID.

    Args:
        atom_id: The ID of the knowledge atom to delete
    """
    await _ensure_initialized()
    if _cloud_mode:
        result = await _call_api("DELETE", f"/api/v1/knowledge/{atom_id}")
        if isinstance(result, dict) and "error" in result:
            return f"Error: {result['error']}"
        return f"Knowledge atom {atom_id} deleted."
    deleted = await _store.delete_atom(atom_id)
    if deleted:
        return f"Knowledge atom {atom_id} deleted."
    return f"Knowledge atom {atom_id} not found."


@mcp.tool()
async def list_conflicts(status: str | None = None) -> str:
    """List knowledge conflicts that need resolution.

    Conflicts are detected when atoms contradict each other (same subject+predicate
    with different values, or high semantic similarity with different content).

    Args:
        status: Filter by status: open, resolved, dismissed (default: open)
    """
    await _ensure_initialized()
    conflict_status = ConflictStatus(status) if status else ConflictStatus.OPEN
    if _cloud_mode:
        result = await _call_api("GET", f"/api/v1/conflicts?status={conflict_status.value}")
        if isinstance(result, dict) and "error" in result:
            return f"Error: {result['error']}"
        conflicts_data = result if isinstance(result, list) else []
        if not conflicts_data:
            return f"No {conflict_status.value} conflicts found."
        lines = [f"Found {len(conflicts_data)} {conflict_status.value} conflict(s):"]
        for c in conflicts_data:
            cid = c.get("id", "?")[:8]
            lines.append(f"\nConflict {cid}... ({c.get('conflict_type', '?')})")
            lines.append(f"  Description: {c.get('description', '')}")
            if c.get("atom_a"):
                lines.append(f"  Atom A: [{c['atom_a'].get('atom_type', '?')}] {c['atom_a'].get('content', '')}")
            if c.get("atom_b"):
                lines.append(f"  Atom B: [{c['atom_b'].get('atom_type', '?')}] {c['atom_b'].get('content', '')}")
            lines.append(f"  Status: {c.get('status', '?')}")
        return "\n".join(lines)
    conflicts = await _store.list_conflicts(status=conflict_status, limit=20)
    if not conflicts:
        return f"No {conflict_status.value} conflicts found."

    lines = [f"Found {len(conflicts)} {conflict_status.value} conflict(s):"]
    for c in conflicts:
        atom_a = await _store.get_atom(c.atom_a_id)
        atom_b = await _store.get_atom(c.atom_b_id)
        lines.append(f"\nConflict {c.id[:8]}... ({c.conflict_type.value})")
        lines.append(f"  Description: {c.description}")
        if atom_a:
            lines.append(f"  Atom A: [{atom_a.atom_type.value}] {atom_a.content}")
        if atom_b:
            lines.append(f"  Atom B: [{atom_b.atom_type.value}] {atom_b.content}")
        lines.append(f"  Status: {c.status.value}")
    return "\n".join(lines)


@mcp.tool()
async def resolve_conflict(conflict_id: str, winner_id: str) -> str:
    """Resolve a knowledge conflict by choosing a winner.

    The losing atom will be deactivated. Use list_conflicts to see open conflicts.

    Args:
        conflict_id: ID of the conflict to resolve
        winner_id: ID of the atom to keep (the winner)
    """
    await _ensure_initialized()
    if _cloud_mode:
        result = await _call_api("POST", f"/api/v1/conflicts/{conflict_id}/resolve", json={"winner_id": winner_id})
        if isinstance(result, dict) and "error" in result:
            return f"Error: {result['error']}"
        return f"Conflict resolved. Winner: {winner_id}. Loser deactivated."
    conflict = await _store.resolve_conflict(conflict_id, winner_id)
    if not conflict:
        return f"Conflict {conflict_id} not found."
    return f"Conflict resolved. Winner: {winner_id}. Loser deactivated."


@mcp.tool()
async def verification_queue(limit: int = 10) -> str:
    """Get knowledge atoms that need verification.

    Returns atoms that have never been verified or whose verification has expired.

    Args:
        limit: Maximum number of atoms to return (default 10)
    """
    await _ensure_initialized()
    if _cloud_mode:
        result = await _call_api("GET", f"/api/v1/verification/queue?limit={limit}")
        if isinstance(result, dict) and "error" in result:
            return f"Error: {result['error']}"
        atoms = result.get("atoms", []) if isinstance(result, dict) else []
        if not atoms:
            return "No atoms need verification."
        lines = [f"Verification queue ({len(atoms)} atom(s)):"]
        for a in atoms:
            projects = a.get("projects", [])
            scope = f"[{', '.join(projects)}]" if projects else "[global]"
            lines.append(f"\n[{a.get('atom_type', '?')}] {scope} {a.get('content', '')}")
            lines.append(f"  ID: {a.get('id', '?')} | Status: {a.get('verification_status', '?')}")
        return "\n".join(lines)
    atoms = await _store.get_verification_queue(limit=limit)
    if not atoms:
        return "No atoms need verification."

    lines = [f"Verification queue ({len(atoms)} atom(s)):"]
    for atom in atoms:
        status = atom.verification_status.value
        verified = atom.verified_at.isoformat() if atom.verified_at else "never"
        lines.append(f"\n{format_atom_brief(atom)}")
        lines.append(f"  ID: {atom.id} | Verified: {verified} | Status: {status}")
    return "\n".join(lines)


@mcp.tool()
async def calendar_today() -> str:
    """Get today's calendar events.

    Returns a formatted list of today's events from Google Calendar.
    Requires Google Calendar to be connected via the Sulci dashboard.
    """
    result = await _call_api("GET", "/api/v1/integrations/calendar/today")
    if "error" in result:
        return f"Error: {result['error']}"
    events = result.get("events", [])
    if not events:
        return "No events scheduled for today."
    lines = [f"Today's events ({result.get('count', len(events))}):"]
    for ev in events:
        summary = ev.get("summary", "(No title)")
        start = ev.get("start", {}).get("dateTime") or ev.get("start", {}).get("date", "")
        end = ev.get("end", {}).get("dateTime") or ev.get("end", {}).get("date", "")
        location = ev.get("location", "")
        line = f"  - {summary} | {start} → {end}"
        if location:
            line += f" | {location}"
        lines.append(line)
    return "\n".join(lines)


@mcp.tool()
async def calendar_list_events(days: int = 7) -> str:
    """List upcoming calendar events.

    Args:
        days: Number of days ahead to look (default 7, max 30)
    """
    result = await _call_api("GET", f"/api/v1/integrations/calendar/upcoming?days={min(days, 30)}")
    if "error" in result:
        return f"Error: {result['error']}"
    events = result.get("events", [])
    if not events:
        return f"No events in the next {days} days."
    lines = [f"Upcoming events ({result.get('count', len(events))}, next {days} days):"]
    for ev in events:
        summary = ev.get("summary", "(No title)")
        start = ev.get("start", {}).get("dateTime") or ev.get("start", {}).get("date", "")
        end = ev.get("end", {}).get("dateTime") or ev.get("end", {}).get("date", "")
        location = ev.get("location", "")
        line = f"  - {summary} | {start} → {end}"
        if location:
            line += f" | {location}"
        lines.append(line)
    return "\n".join(lines)


@mcp.tool()
async def calendar_create_event(
    title: str,
    start_time: str,
    end_time: str,
    description: str | None = None,
    attendees: str = "",
) -> str:
    """Create a new Google Calendar event.

    Args:
        title: Event title
        start_time: Start time in ISO 8601 format (e.g. 2026-02-24T10:00:00-05:00)
        end_time: End time in ISO 8601 format
        description: Optional event description
        attendees: Comma-separated email addresses (optional)
    """
    payload: dict = {
        "title": title,
        "start_time": start_time,
        "end_time": end_time,
    }
    if description:
        payload["description"] = description
    if attendees:
        payload["attendees"] = [e.strip() for e in attendees.split(",") if e.strip()]

    result = await _call_api("POST", "/api/v1/integrations/calendar/create", json=payload)
    if "error" in result:
        return f"Error creating event: {result['error']}"

    event_id = result.get("id", "")
    link = result.get("htmlLink", "")
    return f"Event created: {title}\n  ID: {event_id}\n  Link: {link}"


# --- Slack tools ---


@mcp.tool()
async def slack_post_message(channel: str, text: str) -> str:
    """Post a message to a Slack channel.

    Args:
        channel: Channel name or ID (e.g. "general" or "C01234567")
        text: Message text to post
    """
    result = await _call_api("POST", "/api/v1/integrations/slack/post", json={"channel": channel, "text": text})
    if "error" in result:
        return f"Error: {result['error']}"
    return f"Message posted to {result.get('channel', channel)} (ts: {result.get('ts', '')})"


@mcp.tool()
async def slack_search_messages(query: str, limit: int = 10) -> str:
    """Search Slack messages.

    Args:
        query: Search query
        limit: Max results (default 10)
    """
    result = await _call_api("GET", f"/api/v1/integrations/slack/search?query={query}&limit={limit}")
    if "error" in result:
        return f"Error: {result['error']}"
    messages = result.get("messages", [])
    if not messages:
        return f"No Slack messages found for: {query}"
    lines = [f"Found {len(messages)} message(s):"]
    for m in messages:
        lines.append(f"  - [{m.get('channel', '?')}] {m.get('user', '?')}: {m.get('text', '')[:200]}")
        if m.get("permalink"):
            lines.append(f"    {m['permalink']}")
    return "\n".join(lines)


@mcp.tool()
async def slack_list_channels() -> str:
    """List accessible Slack channels."""
    result = await _call_api("GET", "/api/v1/integrations/slack/channels")
    if "error" in result:
        return f"Error: {result['error']}"
    channels = result.get("channels", [])
    if not channels:
        return "No channels found."
    lines = [f"Slack channels ({len(channels)}):"]
    for c in channels:
        member = " (member)" if c.get("is_member") else ""
        lines.append(f"  - {c.get('name', '?')} (ID: {c.get('id', '?')}, {c.get('num_members', 0)} members){member}")
    return "\n".join(lines)


# --- Gmail tools ---


@mcp.tool()
async def gmail_search(query: str, limit: int = 5) -> str:
    """Search Gmail messages.

    Args:
        query: Gmail search query (same syntax as Gmail search bar)
        limit: Max results (default 5)
    """
    result = await _call_api("GET", f"/api/v1/integrations/gmail/search?query={query}&limit={limit}")
    if "error" in result:
        return f"Error: {result['error']}"
    emails = result.get("emails", [])
    if not emails:
        return f"No emails found for: {query}"
    lines = [f"Found {len(emails)} email(s):"]
    for e in emails:
        lines.append(f"  - [{e.get('date', '')}] From: {e.get('from', '')}")
        lines.append(f"    Subject: {e.get('subject', '(no subject)')}")
        lines.append(f"    {e.get('snippet', '')[:150]}")
        lines.append(f"    ID: {e.get('id', '')}")
    return "\n".join(lines)


@mcp.tool()
async def gmail_read(message_id: str) -> str:
    """Read a specific email by ID.

    Args:
        message_id: Gmail message ID (from gmail_search results)
    """
    result = await _call_api("GET", f"/api/v1/integrations/gmail/read/{message_id}")
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [
        f"From: {result.get('from', '')}",
        f"To: {result.get('to', '')}",
        f"Date: {result.get('date', '')}",
        f"Subject: {result.get('subject', '')}",
        "",
        result.get("body", "(empty)"),
    ]
    return "\n".join(lines)


@mcp.tool()
async def gmail_send(to: str, subject: str, body: str) -> str:
    """Send an email via Gmail.

    Args:
        to: Recipient email address
        subject: Email subject
        body: Email body text
    """
    result = await _call_api(
        "POST", "/api/v1/integrations/gmail/send", json={"to": to, "subject": subject, "body": body}
    )
    if "error" in result:
        return f"Error sending email: {result['error']}"
    return f"Email sent to {to}\n  Subject: {subject}\n  ID: {result.get('id', '')}"


# --- Google Docs tools ---


@mcp.tool()
async def gdocs_search(query: str, limit: int = 5) -> str:
    """Search Google Docs by title.

    Args:
        query: Search query for document titles
        limit: Max results (default 5)
    """
    result = await _call_api("GET", f"/api/v1/integrations/gdocs/search?query={query}&limit={limit}")
    if "error" in result:
        return f"Error: {result['error']}"
    docs = result.get("docs", [])
    if not docs:
        return f"No docs found for: {query}"
    lines = [f"Found {len(docs)} doc(s):"]
    for d in docs:
        lines.append(f"  - {d.get('name', '?')} (modified: {d.get('modified', '')})")
        lines.append(f"    ID: {d.get('id', '')} | {d.get('link', '')}")
    return "\n".join(lines)


@mcp.tool()
async def gdocs_read(document_id: str) -> str:
    """Read a Google Doc's content.

    Args:
        document_id: Google Docs document ID
    """
    result = await _call_api("GET", f"/api/v1/integrations/gdocs/read/{document_id}")
    if "error" in result:
        return f"Error: {result['error']}"
    return f"# {result.get('title', 'Untitled')}\n\n{result.get('content', '(empty)')}"


@mcp.tool()
async def gdocs_create(title: str, content: str) -> str:
    """Create a new Google Doc.

    Args:
        title: Document title
        content: Document text content
    """
    result = await _call_api("POST", "/api/v1/integrations/gdocs/create", json={"title": title, "content": content})
    if "error" in result:
        return f"Error creating doc: {result['error']}"
    return f"Doc created: {result.get('title', title)}\n  ID: {result.get('id', '')}\n  Link: {result.get('link', '')}"


@mcp.tool()
async def list_projects() -> str:
    """List all projects in your knowledge store with atom counts.

    Use this to discover the exact project names before calling
    list_knowledge, query_context, or add_knowledge with a project filter.
    """
    await _ensure_initialized()
    if _cloud_mode:
        result = await _call_api("GET", "/api/v1/projects")
        if isinstance(result, dict) and "error" in result:
            return f"Error: {result['error']}"
        projects_data = result if isinstance(result, list) else []
        if not projects_data:
            return "No projects found."
        lines = [f"Projects ({len(projects_data)}):"]
        for p in projects_data:
            lines.append(f"  - {p.get('name', '?')} (type: {p.get('project_type', '?')})")
        return "\n".join(lines)
    projects = await _store.list_projects_full()
    if not projects:
        atom_projects = await _store.list_projects()
        if not atom_projects:
            return "No projects found."
        lines = ["Projects (from atom tags):"]
        for name in atom_projects:
            lines.append(f"  - {name}")
        return "\n".join(lines)

    lines = [f"Projects ({len(projects)}):"]
    for p in projects:
        lines.append(f"  - {p.name} (type: {p.project_type.value})")
    return "\n".join(lines)


@mcp.tool()
async def rename_project(old_name: str, new_name: str) -> str:
    """Rename a project and update all atom references.

    Args:
        old_name: Current project name
        new_name: New project name
    """
    await _ensure_initialized()
    if _cloud_mode:
        result = await _call_api("PUT", f"/api/v1/projects/{old_name}", json={"name": new_name})
        if isinstance(result, dict) and "error" in result:
            return f"Error: {result['error']}"
        return f"Project renamed from '{old_name}' to '{new_name}'. All atom references updated."
    project = await _store.get_project(old_name)
    if not project:
        return f"Error: Project '{old_name}' not found."
    existing = await _store.get_project(new_name)
    if existing:
        return f"Error: Project '{new_name}' already exists."
    project.name = new_name
    await _store.rename_project(old_name, project)
    return f"Project renamed from '{old_name}' to '{new_name}'. All atom references updated."


# --- Resources ---


@mcp.resource("sulci://stats")
async def stats_resource() -> str:
    """Current Sulci knowledge store statistics."""
    await _ensure_initialized()
    if _cloud_mode:
        result = await _call_api("GET", "/api/v1/stats")
        if isinstance(result, dict) and "error" in result:
            return f"Error: {result['error']}"
        return json.dumps(result, indent=2)
    stats = await _store.get_stats()
    return json.dumps(stats, indent=2)


@mcp.resource("sulci://recent")
async def recent_resource() -> str:
    """Recently updated knowledge atoms."""
    await _ensure_initialized()
    if _cloud_mode:
        result = await _call_api("GET", "/api/v1/knowledge?limit=10")
        if isinstance(result, dict) and "error" in result:
            return f"Error: {result['error']}"
        atoms = result if isinstance(result, list) else []
        if not atoms:
            return "No knowledge atoms yet."
        lines = []
        for a in atoms:
            projects = a.get("projects", [])
            scope = f"[{', '.join(projects)}]" if projects else "[global]"
            lines.append(f"[{a.get('atom_type', '?')}] {scope} {a.get('content', '')}")
        return "\n".join(lines)
    atoms = await _store.list_atoms(limit=10)
    lines = []
    for atom in atoms:
        lines.append(format_atom_brief(atom))
    return "\n".join(lines) if lines else "No knowledge atoms yet."


@mcp.resource("sulci://session-brief")
async def session_brief_resource() -> str:
    """Persistent memory brief for the current session.

    Returns your preferences, instructions, recent decisions, key facts,
    and entities for the current project. Designed to give AI coding
    assistants persistent context across sessions — read this at the
    start of any new session to pick up where you left off.
    """
    await _ensure_initialized()
    project = _detect_project()
    if _cloud_mode:
        qs = "?format=text"
        if project:
            qs += f"&project={project}"
        import httpx
        config = get_config()
        base = config.api_url.rstrip("/")
        token = config.api_token
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.get(f"{base}/api/v1/context/session-brief{qs}", headers=headers)
                if resp.status_code >= 400:
                    return f"Error fetching session brief: {resp.status_code}"
                return resp.text
        except Exception as e:
            return f"Error: {e}"
    brief = await _store.get_session_brief(project=project)

    lines = []
    header = "Session brief"
    if project:
        header += f" for project: {project}"
    lines.append(f"# {header}\n")

    if brief["preferences"]:
        lines.append("## Your Preferences")
        for p in brief["preferences"]:
            lines.append(f"- {p}")
        lines.append("")

    if brief["instructions"]:
        lines.append("## Standing Instructions")
        for i in brief["instructions"]:
            lines.append(f"- {i}")
        lines.append("")

    if brief["recent_decisions"]:
        lines.append("## Recent Decisions")
        for d in brief["recent_decisions"]:
            lines.append(f"- {d}")
        lines.append("")

    if brief["recent_facts"]:
        lines.append("## Key Facts")
        for f in brief["recent_facts"]:
            lines.append(f"- {f}")
        lines.append("")

    if brief["key_entities"]:
        lines.append("## Key Entities")
        for e in brief["key_entities"]:
            lines.append(f"- **{e['name']}**: {e['detail']}")
        lines.append("")

    if brief["open_conflicts"] > 0:
        lines.append(f"*{brief['open_conflicts']} open conflict(s) need resolution.*\n")

    if not any(
        [
            brief["preferences"],
            brief["instructions"],
            brief["recent_decisions"],
            brief["recent_facts"],
            brief["key_entities"],
        ]
    ):
        lines.append("No knowledge stored yet. Start a conversation and Sulci will remember it.")

    return "\n".join(lines)


def _run_http(host: str, port: int, api_key: str) -> None:
    """Run the MCP server with streamable-http transport."""
    import uvicorn

    from sulci_mcp.auth import BearerTokenMiddleware

    app = mcp.streamable_http_app()

    if api_key:
        app = BearerTokenMiddleware(app, api_key=api_key)
        logger.info("Bearer token auth enabled for MCP HTTP transport")
    else:
        logger.info("No SULCI_API_KEY set — MCP HTTP running without auth (dev mode)")

    logger.info("Sulci MCP server (streamable-http) → http://%s:%d/mcp", host, port)

    uvicorn.run(app, host=host, port=port)


def _generate_key(write_env: bool) -> None:
    """Generate a new API key and optionally append it to .env."""
    from sulci_mcp.auth import generate_key

    key = generate_key()
    print(f"\nGenerated API key:\n\n  SULCI_API_KEY={key}\n")

    if write_env:
        from pathlib import Path

        env_path = Path.cwd() / ".env"
        # Append or update
        if env_path.exists():
            content = env_path.read_text()
            if "SULCI_API_KEY=" in content:
                lines = content.splitlines()
                lines = [f"SULCI_API_KEY={key}" if line.startswith("SULCI_API_KEY=") else line for line in lines]
                env_path.write_text("\n".join(lines) + "\n")
                print(f"  Updated SULCI_API_KEY in {env_path}")
            else:
                with env_path.open("a") as f:
                    f.write(f"\nSULCI_API_KEY={key}\n")
                print(f"  Appended to {env_path}")
        else:
            env_path.write_text(f"SULCI_API_KEY={key}\n")
            print(f"  Created {env_path}")
    else:
        print("  Add to your environment or run with --write-env to save to .env")


def main():
    """Run the MCP server — stdio (default) or streamable-http."""
    config = get_config()

    parser = argparse.ArgumentParser(description="Sulci MCP Server")
    parser.add_argument(
        "--transport",
        choices=["stdio", "streamable-http"],
        default=config.mcp_transport,
        help="Transport type (default: from SULCI_MCP_TRANSPORT or stdio)",
    )
    parser.add_argument(
        "--host",
        default=config.mcp_host,
        help="HTTP host (default: from SULCI_MCP_HOST or 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=config.mcp_port,
        help="HTTP port (default: from SULCI_MCP_PORT or 8000)",
    )
    parser.add_argument(
        "--generate-key",
        action="store_true",
        help="Generate a random API key and exit",
    )
    parser.add_argument(
        "--write-env",
        action="store_true",
        help="Write generated key to .env file (use with --generate-key)",
    )
    args = parser.parse_args()

    if args.generate_key:
        _generate_key(write_env=args.write_env)
        return

    if args.transport == "streamable-http":
        _run_http(args.host, args.port, config.api_key)
    else:
        logger.info("Sulci MCP server (stdio)")
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
