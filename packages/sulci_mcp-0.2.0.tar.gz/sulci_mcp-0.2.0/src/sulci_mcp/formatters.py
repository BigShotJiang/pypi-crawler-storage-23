"""Format knowledge atoms for LLM consumption."""

from sulci_core.models import ContextQueryResult, KnowledgeAtom


def format_atom_brief(atom: KnowledgeAtom) -> str:
    """Format a single atom as a brief one-liner."""
    scope = f"[{', '.join(atom.projects)}]" if atom.projects else "[global]"
    parts = [f"[{atom.atom_type.value}]", scope, atom.content]
    if atom.source_tool:
        parts.append(f"(via {atom.source_tool})")
    return " ".join(parts)


def format_atom_detailed(atom: KnowledgeAtom) -> str:
    """Format a single atom with full details."""
    lines = [
        f"ID: {atom.id}",
        f"Type: {atom.atom_type.value}",
        f"Content: {atom.content}",
    ]
    if atom.subject:
        lines.append(f"Subject: {atom.subject}")
    if atom.predicate:
        lines.append(f"Predicate: {atom.predicate}")
    if atom.object:
        lines.append(f"Object: {atom.object}")
    lines.append(f"Confidence: {atom.confidence:.2f}")
    if atom.source_tool:
        lines.append(f"Source: {atom.source_tool}")
    if atom.tags:
        lines.append(f"Tags: {', '.join(atom.tags)}")
    scope = ", ".join(atom.projects) if atom.projects else "global"
    lines.append(f"Scope: {scope}")
    lines.append(f"Updated: {atom.updated_at.isoformat()}")
    return "\n".join(lines)


def format_context_results(results: list[ContextQueryResult], project: str | None = None) -> str:
    """Format context query results for injection into an LLM prompt."""
    if not results:
        return "No relevant context found."

    header = "Relevant context from previous interactions"
    if project:
        header += f" (project: {project})"
    lines = [f"{header}:"]
    for i, result in enumerate(results, 1):
        atom = result.atom
        confidence = "high" if atom.confidence >= 0.8 else "medium" if atom.confidence >= 0.5 else "low"
        scope = f"[{', '.join(atom.projects)}]" if atom.projects else "[global]"
        lines.append(
            f"{i}. [{atom.atom_type.value}] {scope} {atom.content} "
            f"(relevance: {result.relevance_score:.2f}, {confidence} confidence)"
        )
    return "\n".join(lines)
