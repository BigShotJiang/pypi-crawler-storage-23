"""Bearer token authentication middleware for MCP HTTP transport."""

import json
import secrets


def generate_key() -> str:
    """Generate a cryptographically random API key.

    Returns a URL-safe base64 token (43 chars, ~256 bits of entropy).
    """
    return secrets.token_urlsafe(32)


class BearerTokenMiddleware:
    """ASGI middleware that requires Bearer token auth when an API key is configured.

    Behavior:
    - api_key empty → pass through (dev mode, no auth required)
    - api_key set → require Authorization: Bearer <key> header
    - Non-HTTP scopes (e.g. lifespan) pass through unconditionally

    Token verification is handled by `verify_token()` — override this method
    to support multiple keys, DB-backed tokens, or scoped permissions.
    """

    def __init__(self, app, api_key: str = ""):
        self.app = app
        self.api_key = api_key

    def verify_token(self, token: str) -> bool:
        """Check if a token is valid. Override for DB-backed auth."""
        return secrets.compare_digest(token, self.api_key)

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or not self.api_key:
            return await self.app(scope, receive, send)

        headers = dict(scope.get("headers", []))
        auth = headers.get(b"authorization", b"").decode()

        token = auth[7:] if auth.startswith("Bearer ") else auth

        if not self.verify_token(token):
            body = json.dumps({"detail": "Invalid or missing API key"}).encode()
            await send(
                {
                    "type": "http.response.start",
                    "status": 401,
                    "headers": [
                        [b"content-type", b"application/json"],
                        [b"content-length", str(len(body)).encode()],
                    ],
                }
            )
            await send(
                {
                    "type": "http.response.body",
                    "body": body,
                }
            )
            return

        return await self.app(scope, receive, send)
