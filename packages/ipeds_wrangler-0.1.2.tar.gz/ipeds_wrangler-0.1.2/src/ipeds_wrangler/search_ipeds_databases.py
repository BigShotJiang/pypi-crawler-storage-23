# Import modules
from pathlib import Path
import platformdirs
import os
import pandas as pd

# Define search function
def search_ipeds_databases(search_term, ipeds_database_path=None):
    """
    Search the most recent IPEDS vartable for a given search term.
    
    Args:
        search_term: String to search for in varName, varTitle, and longDescription columns.
        ipeds_database_path: Path to folder containing IPEDS CSV files. 
                           If None, defaults to Desktop/ipeds_databases (as in download_ipeds_databases).
                           Can be a string or Path object. Supports ~ for home directory.
    
    Returns:
        pd.DataFrame with TableName, varName, varTitle, DataType, and longDescription search matches
    """
    
    # Set default path if none provided
    if ipeds_database_path is None:
        desktop_path = platformdirs.user_desktop_dir()
        ipeds_database_path = Path(desktop_path) / "ipeds_databases"
    else:
        # Convert to Path object and expand user home directory if needed
        ipeds_database_path = Path(ipeds_database_path).expanduser()
    
    # Verify directory exists
    if not ipeds_database_path.exists():
        raise FileNotFoundError(f"Directory not found: {ipeds_database_path}")
    
    # Identify the most recent vartable CSV file
    vartable_files = [f for f in os.listdir(ipeds_database_path) if f.startswith("vartable") and f.endswith(".csv")]
    
    if not vartable_files:
        raise FileNotFoundError(f"No vartable CSV files found in {ipeds_database_path}")
    
    most_recent_vartable = max(vartable_files, key=lambda x: int(x.replace("vartable", "").replace(".csv", "")))

    # Read in the most recent IPEDS vartable to pd.DataFrame
    vartable_path = ipeds_database_path / most_recent_vartable
    vartable = pd.read_csv(vartable_path)

    # Filter to rows where search_term appears in varName, varTitle, or longDescription cols
    search_term_lower = search_term.lower()
    vartable = vartable[
        vartable['varName'].str.lower().str.contains(search_term_lower, na=False) |
        vartable['varTitle'].str.lower().str.contains(search_term_lower, na=False) |
        vartable['longDescription'].str.lower().str.contains(search_term_lower, na=False)
    ]

    # Select key columns for output
    output_cols = ['TableName', 'varName', 'varTitle', 'DataType', 'longDescription']
    search_results = vartable[output_cols].reset_index(drop=True)
    
    return search_results

if __name__ == "__main__":
    search_ipeds_databases()