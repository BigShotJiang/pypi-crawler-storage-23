# Import modules
from pathlib import Path
import platformdirs
import os
import pandas as pd

# Define benchmark function
def wrangle_ipeds_benchmarking_data(input_unitid, ipeds_database_path=None):
    """
    Wrangle IPEDS benchmarking data for a given school (input_unitid).

    Args:
        input_unitid (str or int): UNITID of the institution for which to identify peers.
        ipeds_database_path: Path to folder containing IPEDS CSV files.
                            If None, defaults to Desktop/ipeds_databases (as in download_ipeds_databases).
                            Can be a string or Path object. Supports ~ for home directory.
    
    Returns:
        ipeds_peers_df (pd.DataFrame): DataFrame containing UNITID and institution name for peer schools.
    """
    # Set default path if none provided
    if ipeds_database_path is None:
        desktop_path = platformdirs.user_desktop_dir()
        ipeds_database_path = Path(desktop_path) / "ipeds_databases"
    else:
        # Convert to Path object and expand user home directory if needed
        ipeds_database_path = Path(ipeds_database_path).expanduser()
    
    # Verify directory exists
    if not ipeds_database_path.exists():
        raise FileNotFoundError(f"IPEDS database directory not found: {ipeds_database_path}")
    
    # Identify the most recent HD CSV file
    hd_files = [f for f in os.listdir(ipeds_database_path) if f.startswith("HD") and f.endswith(".csv")]
    
    if not hd_files:
        raise FileNotFoundError(f"No IPEDS HD CSV files found in {ipeds_database_path}")
    
    most_recent_hd = max(hd_files, key=lambda x: int(x.replace("HD", "").replace(".csv", "")))

    # Read in the most recent IPEDS HD table to pd.DataFrame
    hd_path = ipeds_database_path / most_recent_hd
    hd_df = pd.read_csv(hd_path)

    # Subset to the input UNITID
    hd_df['UNITID'] = hd_df['UNITID'].astype(str)
    hd_ds = hd_df[hd_df['UNITID'] == str(input_unitid)]

    # If no matching UNITID found, raise an error
    if hd_ds.empty:
        raise ValueError(f"The UNITID {input_unitid} does not appear in {most_recent_hd}")
    
    # Define peers based on whether the UNITID submitted a CCG to IPEDS or not
    if hd_ds['DFRCUSCG'].item() == 1:
        print(f"{hd_ds['INSTNM'].item()} submitted a custom comparison group for IPEDS benchmarking. Gathering data for custom-defined peers...")

        # Get UNITIDs for CCG benchmark peers
        ccg_files = [f for f in os.listdir(ipeds_database_path) if f.startswith("CUSTOMCGIDS") and f.endswith(".csv")]
        most_recent_ccg = max(ccg_files, key=lambda x: int(x.replace("CUSTOMCGIDS", "").replace(".csv", "")))
        ccg_path = ipeds_database_path / most_recent_ccg
        ccg_df = pd.read_csv(ccg_path)
        ccg_df['UNITID'] = ccg_df['UNITID'].astype(str)
        ccg_df = ccg_df[ccg_df['UNITID'] == str(input_unitid)]
        benchmark_peers = ccg_df['CGUNITID'].astype(str).unique().tolist()

    else:
        print(f"{hd_ds['INSTNM'].item()} did not submit a custom comparison group for IPEDS benchmarking. Gathering data for NCES-defined peers...")

        # Get UNITIDs for DFRCGID benchmark peers
        dfrcgid = hd_ds['DFRCGID'].item()
        benchmark_peers = hd_df[hd_df['DFRCGID'] == dfrcgid]
        benchmark_peers = benchmark_peers['UNITID'].unique().tolist()
    
    print(f"Wrangling IPEDS data for {len(benchmark_peers)} peer institutions...")
    
    # Loop over data CSV data files, subset to peers, and merge into a single DataFrame
    csv_data_files = [f for f in os.listdir(ipeds_database_path)
                      if f.endswith(".csv")
                      and not f.startswith("valuesets")
                      and not f.startswith("vartable")
                      and not f.startswith("CUSTOMCGIDS")]
    
    # Initialize an empty df
    ipeds_peers_df = None
    
    # Files are organized by year, with different variables represented in each file.
    # Loop over years of each file type (e.g. HD2020, HD2021, HD2022, HD2023, HD2024).
    # Append years for trend analyses (e.g. FTE2020, FTE2021, FTE2022, FTE2023, FTE2024).
    # Merge (joining by UNITID) to create a wide DataFrame with all available features.
    for csv_file in csv_data_files:
        csv_path = ipeds_database_path / csv_file
        df = pd.read_csv(csv_path)
        # Convert all column names to uppercase
        df.columns = df.columns.str.upper()
        # Convert to string type to match input_unitid and ensure consistent merging
        df['UNITID'] = df['UNITID'].astype(str)
        df_peers = df[(df['UNITID'] == str(input_unitid)) | (df['UNITID'].isin(benchmark_peers))].copy()
        # For all cols except UNITID and INSTNM, append the year from the file name
        year_suffix = csv_file[-8:-4]  # Extract year from file name (e.g. HD2021 -> 2021)
        df_peers.columns = [col if col in ('UNITID', 'INSTNM') else f"{col}{year_suffix}" for col in df_peers.columns]
        
        # Merge by UNITID to create a wide DataFrame with all vars for benchmark peers
        if ipeds_peers_df is not None:
            # Get columns that don't already exist (except UNITID for merging)
            existing_cols = set(ipeds_peers_df.columns)
            new_cols = ['UNITID'] + [col for col in df_peers.columns if col not in existing_cols]
            
            # Only merge if there are new columns to add
            if len(new_cols) > 1:  # More than just UNITID
                df_peers_subset = df_peers[new_cols]
                ipeds_peers_df = pd.merge(ipeds_peers_df, df_peers_subset, on='UNITID', how='outer')
        else:
            ipeds_peers_df = df_peers
    
    # Clean up the final DataFrame
    ipeds_peers_df = ipeds_peers_df.dropna(axis=1, how='all') # Drop any empty columns
    ipeds_peers_df = ipeds_peers_df.drop_duplicates() # Drop any duplicate rows
    ipeds_peers_df = ipeds_peers_df.loc[:, ~ipeds_peers_df.columns.duplicated()] # Drop any duplicate columns

    # Reorder columns to have UNITID, INSTNM, then features ordered by date
    cols = ipeds_peers_df.columns.tolist()
    ordered_cols = ['UNITID', 'INSTNM'] + [col for col in cols if col not in ['UNITID', 'INSTNM']]
    ordered_cols = ['UNITID', 'INSTNM'] + sorted([col for col in ordered_cols if col not in ['UNITID', 'INSTNM']], key=lambda x: x[-4:])
    ipeds_peers_df = ipeds_peers_df[ordered_cols]

    # Print a summary for the final DataFrame
    num_peers = ipeds_peers_df['UNITID'].nunique() - 1  # Exclude the input institution
    num_features = ipeds_peers_df.shape[1] - 2  # Exclude UNITID, INSTNM
    print(f"Success! Wrangled data for {num_peers} peer institutions. Output includes {num_features} features for benchmarking.")
    
    return ipeds_peers_df

if __name__ == "__main__":
    wrangle_ipeds_benchmarking_data()