# ipeds_wrangler/__init__.py

"""
ipeds_wrangler - a Python package for wrangling IPEDS data
"""

from .download_ipeds_databases import download_ipeds_databases
from .search_ipeds_databases import search_ipeds_databases
from .wrangle_ipeds_benchmarking_data import wrangle_ipeds_benchmarking_data

__version__ = "0.1.2"
__all__ = ['download_ipeds_databases', 'search_ipeds_databases', 'wrangle_ipeds_benchmarking_data']

def describe():
    """Print the package description."""
    description = (
        "ipeds_wrangler\n"
        f"version: {__version__}\n"
        "a Python package for wrangling IPEDS data"
    )
    print(description)