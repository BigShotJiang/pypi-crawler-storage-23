# Import modules
import os
from pathlib import Path
import platformdirs
import requests
from bs4 import BeautifulSoup
import zipfile
from access_parser import AccessParser
import pandas as pd
from typing import Optional

# Define download function
def download_ipeds_databases(
        access_url = "https://nces.ed.gov/ipeds/use-the-data/download-access-database",
        complete_data_files_url = "https://nces.ed.gov/ipeds/datacenter/DataFiles.aspx?year=-1",
        download_directory = "ipeds_databases") -> Optional[Path]:
    """
    Download and parse IPEDS databases from NCES.
    
    Args:
        access_url: IPEDS URL for downloading Access databases
        complete_data_files_url: IPEDS URL for downloading complete data files, which may not be available in Access format yet
        download_directory: Name of directory to create on Desktop for downloads
    
    Returns:
        Path to download directory if successful, None if error
    """
    # Parse access_url to find .zip files for Access databases
    try:
        response = requests.get(access_url)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"Error accessing {access_url}: {e}")
        return
    soup = BeautifulSoup(response.content, 'html.parser')

    # Make accdb_url_list to contain all .zip URLs for the .accdb files
    accdb_url_list = []

    # Find all .zip links and append them to the list
    for link in soup.find_all('a', href=True):
        href = link['href']
        if href.endswith('.zip'):
            # Make a full URL if link is relative
            if not href.startswith(('http://', 'https://')):
                full_zip_url = requests.compat.urljoin(access_url, href)
            else:
                full_zip_url = href
            accdb_url_list.append(full_zip_url)
    
    # Select the first 5 in the URLs list to get the 5 most recent Access databases
    # This may not include the most recent year though, if data are not available in .accdb format
    accdb_url_list = accdb_url_list[:5]

    # Parse complete_data_files_url to find .zip files for the most recent year available
    try:
        response = requests.get(complete_data_files_url)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"Error accessing {complete_data_files_url}: {e}")
        return
    soup = BeautifulSoup(response.content, 'html.parser')

    # Make cdf_url_list to contain all .zip URLs for complete data files
    # Example: https://nces.ed.gov/ipeds/data-generator?year=2024&tableName=HD2024&HasRV=0&type=csv&t=639076312259486782
    cdf_url_list = []

    # Find all .zip links and append them to the list
    for link in soup.find_all('a', href=True):
        href = link['href']
        # Include only CSVs and exclude junk like SAS, Stata, etc.
        if href.__contains__('type=csv'):
            # Make a full URL if link is relative
            if not href.startswith(('http://', 'https://')):
                full_zip_url = requests.compat.urljoin(complete_data_files_url, href)
            else:
                full_zip_url = href
            # Add explicit .zip extension to the URL
            full_zip_url = full_zip_url + ".zip" if not full_zip_url.endswith('.zip') else full_zip_url
            cdf_url_list.append(full_zip_url)
    
    # Subset cdf_url_list to get the most recent available year
    years = set()
    for url in cdf_url_list:
        if 'year=' in url:
            year_part = url.split('year=')[1].split('&')[0]
            if year_part.isdigit():
                years.add(int(year_part))
    if years:
        most_recent_year = max(years)
        cdf_url_list = [url for url in cdf_url_list if f'year={most_recent_year}' in url]
    
    # Subset cdf_url_list to get key_files only
    key_files = ['HD', 'DRVIC', 'DRVADM', 'DRVEF', 'DRVC', 'DRVGR', 'DRVF', 'DRVHR', 'CUSTOMCGIDS']
    cdf_url_list = [url for url in cdf_url_list if any(key in url for key in key_files)]
    
    # Combine URLs lists to create zip_url_list
    zip_url_list = accdb_url_list + cdf_url_list

    # Download .zip files
    try:
        # Get Desktop path and create Path object
        desktop_path = platformdirs.user_desktop_dir()
        download_directory_path = Path(desktop_path) / download_directory

        # Create the download directory if it does not already exist
        os.makedirs(download_directory_path, exist_ok=True)
        print(f"Downloading IPEDS databases to {download_directory_path}...")

    except Exception as e:
        print(f"Error creating download directory: {e}")

    for zip_url in zip_url_list:
        try:
            # Define filepath for each .zip file
            zip_filename = os.path.basename(zip_url)
            filepath = os.path.join(download_directory_path, zip_filename)

            # Skip downloading existing .zip files
            if os.path.exists(filepath):
                continue
            else:
                zip_response = requests.get(zip_url, stream=True)
                zip_response.raise_for_status()
                with open(filepath, 'wb') as f:
                    for chunk in zip_response.iter_content(chunk_size=8192):
                        f.write(chunk)

        # Display any errors
        except requests.exceptions.RequestException as e:
            print(f"Error downloading {zip_url}: {e}")
        except Exception as e:
            print(f"Error downloading {zip_url}: {e}")

    # Extract .accdb files and .csv from .zip files
    print(f"Extracting IPEDS .accdb files and .csv files from .zip files...")
    for filename in sorted(os.listdir(download_directory_path)):
        if filename.endswith(".zip"):
            zip_filepath = os.path.join(download_directory_path, filename)
            try:
                with zipfile.ZipFile(zip_filepath, 'r') as zip_ref:
                    for member in zip_ref.namelist():
                        # Ignoring directories, extract only .accdb files and .csv files
                        if not member.endswith('/') and (member.endswith('.accdb') or member.endswith('.csv')):
                            # Do not create subdirectories
                            base_filename = os.path.basename(member)
                            # Handle potential root directories (empty string)
                            if base_filename:
                                # Uppercase (e.g. hd2024.csv to HD2024.csv) for consistency
                                if base_filename.endswith('.csv'):
                                    name, ext = os.path.splitext(base_filename)
                                    base_filename = name.upper() + ext
                                source = zip_ref.open(member)
                                target_path = os.path.join(download_directory_path, base_filename)
                                # Write file content to the target path
                                with open(target_path, "wb") as target:
                                    target.write(source.read())

            # Display any errors
            except zipfile.BadZipFile:
                print(f"Error extracting {filename}: Not a valid .zip file.")
            except Exception as e:
                print(f"Error extracting {filename}: {e}")
        
    # Parse key tables from .accdb files
    print(f"Parsing key tables from IPEDS .accdb files to .csv format...")
    key_tables = ['HD', 'DRVIC', 'DRVADM', 'DRVEF', 'DRVC', 'DRVGR', 'DRVF', 'DRVHR', 'CUSTOMCGIDS', 'valuesets', 'vartable']
    for filename in sorted(os.listdir(download_directory_path)):
        if filename.endswith('.accdb'):
            try:
                # Identify each database
                db_filepath = os.path.join(download_directory_path, filename)
                db = AccessParser(db_filepath)
                # Loop through the tables in the db and parse key_tables
                for table_name in db.catalog.keys():
                    if any(table_name.startswith(key) for key in key_tables):
                        parsed_table_data = db.parse_table(table_name)
                        # Convert to pandas DataFrame format
                        df = pd.DataFrame(parsed_table_data)
                        # Write to .csv
                        output_filepath = os.path.join(download_directory_path, f"{table_name}.csv")
                        df.to_csv(output_filepath, index=False, encoding='utf-8')
            except Exception as e:
                print(f"Error parsing {filename}: {e}")

    # Final print statement to confirm files were downloaded, extracted, and parsed
    print(f"Success! IPEDS data are ready for wrangling.")

if __name__ == "__main__":
    download_ipeds_databases()