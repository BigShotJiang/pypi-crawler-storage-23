"""Tests for feature selection module."""
