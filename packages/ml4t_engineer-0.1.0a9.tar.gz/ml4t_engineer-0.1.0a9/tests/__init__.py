"""Test suite for QuantLab-TA."""
