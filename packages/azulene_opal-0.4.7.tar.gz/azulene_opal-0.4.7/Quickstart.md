# Opal Quick Start Guide: 

This guide walks you through a **complete working example** of using Opal to submit and monitor an `Absolute Binding Free Energy` job using a protein and ligand file.

You will learn how to:

a. Install `azulene-opal` from PyPI  
b. Log in via the CLI  
c. Place your protein + ligand files in the correct location  
d. Submit an `absolute_binding` job (including automatic file upload)  
e. Check job status and retrieve results  

---

## Create and activate a virtual environment (optional)

### For conda
```bash
conda create -n opal-env python=3.11 -y
conda activate opal-env
```

### For Python
```bash
# Create a virtual environment
python -m venv opal-env

# Activate the environment on Windows
opal-env\Scripts\activate

# Activate the environment on macOS / Linux
source opal-env/bin/activate
```

---

## a. Install `azulene-opal` from PyPI

```bash
pip install azulene-opal
```

Confirm installation:

```bash
python -m opal.main --help
```

---

## b. Log in using the CLI

Run:

```bash
python -m opal.main login
```

The CLI will securely prompt you:

```
Your email: example@gmail.com
Your password: **********
```

After this, Opal stores your auth tokens locally so you don’t need to log in again.

---

## c. Place your protein and ligand files

For this example, we place the files in a folder named `examples`:

```
examples/
  t4_lysozyme.pdb
  toluene.sdf
```

The file paths will be:

* `examples/t4_lysozyme.pdb`
* `examples/toluene.sdf`

The CLI will automatically detect these as **local files**, upload them to Opal, and replace the paths with storage URLs.

---

## d. Submit an `absolute_binding` job

The job type is:

```
absolute_binding
```

The required parameters are:

```json
{
  "pdb_file": "",
  "ligand_file": ""
}
```

### **Example 1: Using the sample files**

**Using Python**
```bash
from opal import jobs

# These are extremely short runs of 0.1ns---real runs would be at least several nanoseconds.
result = jobs.submit(
    job_type="absolute_binding",
    input_data={
        "pdb_file": "./examples/data/t4_lysozyme.pdb",
        "ligand_file": "./examples/data/toluene.sdf",
        "protocol_repeats": 1,
        "complex_prod_length": 0.1,
        "solvent_prod_length": 0.1,
        "complex_equil_length": 0.02,
        "solvent_equil_length": 0.02
    }
)

print(result)
```


**Using CLI**
```bash
# Submit an absolute_binding job (CMD)
python -m opal.main jobs submit --job-type absolute_binding --input-data "{\"pdb_file\": \"./examples/data/t4_lysozyme.pdb\", \"ligand_file\": \"./examples/data/toluene.sdf\"}"

# Submit an absolute_binding job (Git Bash / WSL / Linux / macOS)
python -m opal.main jobs submit --job-type absolute_binding --input-data '{"pdb_file": "./examples/data/t4_lysozyme.pdb", "ligand_file": "./examples/data/toluene.sdf"}'

# Submit an absolute_binding job (Powershell)
python -m opal.main jobs submit --job-type absolute_binding --input-data '{\"pdb_file\": \"./examples/data/t4_lysozyme.pdb\", \"ligand_file\": \"./examples/data/toluene.sdf\"}'

```


You should see something like:

```
📤 Uploading local files...
✅ Job submitted successfully
{
  "job_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
  "status": "submitted",
  "message": "Job submitted successfully"
}
```

### **Example 2: Absolute Binding Free Energy (Ligand Already in PDB)**

This example runs an absolute_binding job using:
- A protein PDB file
- A ligand inside the PDB file
- A SMILES string for the ligand
- Shortened equilibration & production lengths
- Only 1 protocol repeat

**Python Example**

```bash
from opal import auth, jobs

# 1. Log in (Only if you haven't logged in)
auth.login(email="your@email.com", password="yourpassword")

# 2. Submit the job
input_data = {
    "pdb_file": "./examples/data/fkb_model_0_2.pdb",
    "ligand_smiles": "CS(=O)C",
    "protocol_repeats": 1,
    "ligand_in_pdb_file": True,
    "complex_prod_length": 0.1,
    "solvent_prod_length": 0.1,
    "complex_equil_length": 0.02,
    "solvent_equil_length": 0.02
}

result = jobs.submit(
    job_type="absolute_binding",
    input_data=input_data
)

print(result)
```


**CLI Example**

Login with:
```bash
python -m opal.main login 
```

Then
```bash
python -m opal.main jobs submit \
  --job-type absolute_binding \
  --input-data "{
      \"pdb_file\": \"./examples/data/fkb_model_0_2.pdb\",
      \"ligand_smiles\": \"CS(=O)C\",
      \"protocol_repeats\": 1,
      \"ligand_in_pdb_file\": true,
      \"complex_prod_length\": 0.1,
      \"solvent_prod_length\": 0.1,
      \"complex_equil_length\": 0.02,
      \"solvent_equil_length\": 0.02
  }"
```


### **Example 3: Using your own files**

```bash
python -m opal.main jobs submit \
  --job-type absolute_binding \
  --input-data '{"pdb_file": "path/to/your_protein.pdb", "ligand_file": "path/to/your_ligand.sdf"}'
```

Replace the paths with your actual file locations.

---

## e. Submit an `Absolute Aqueous Solvation Free Energy` job

The job type is:

```text
aqueous_solvation
````

The required parameters are:

```json
{
  "smiles": ""
}
```

### **Example: Using a simple SMILES (`CCO`)**

**Using CLI**

```bash
# Submit an aqueous_solvation job (CMD)
python -m opal.main jobs submit --job-type aqueous_solvation --input-data "{\"smiles\": \"CCO\"}"

# Submit an aqueous_solvation job (Git Bash / WSL / Linux / macOS)
python -m opal.main jobs submit --job-type aqueous_solvation --input-data '{"smiles": "CCO"}'

# Submit an aqueous_solvation job (Powershell)
python -m opal.main jobs submit --job-type aqueous_solvation --input-data '{\"smiles\": \"CCO\"}'
```

**Using Python**

```python
from opal import jobs

result = jobs.submit(
    job_type="aqueous_solvation",
    input_data={
        "smiles": "CCO"
    }
)

print(result)
```

You should see something like:

```text
✅ Job submitted successfully
{
  "job_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
  "status": "submitted",
  "message": "Job submitted successfully"
}
```


## f. Other useful commands

### **1. List your jobs**

Last 5 jobs (default):

```bash
python -m opal.main jobs get-jobs
```

All jobs:

```bash
python -m opal.main jobs get-jobs --all
```

Filter by job type and status:

```bash
python -m opal.main jobs get-jobs \
  --job-type absolute_binding \
  --status completed
```

Filter by date:

```bash
python -m opal.main jobs get-jobs \
  --start-date 2025-12-01T00:00:00Z \
  --end-date   2025-12-05T00:00:00Z
```

---

### **2. Check a specific job**

```bash
python -m opal.main jobs get --job-id YOUR_JOB_ID
```

This returns:

* job status
* input data
* results (if completed)
* timestamps
* any error messages

---

### **3. Poll running jobs**

```bash
python -m opal.main jobs check-running-jobs
```

Use this to check on running jobs.

---

### **4. Cancel a job**

```bash
python -m opal.main jobs cancel --job-id YOUR_JOB_ID
```

Only works if the job is still running.

---

## Next

Now that you’ve successfully installed Opal, logged in, uploaded files, and run your first
`absolute_binding` job, here are some next steps to explore:

### Explore More Job Types
Try other supported job types such as:
- `Generate Conformers
`
- `Aqueous Reaction Free Energy`
- `Relative Free Energy`
- batch submissions

You can discover all available options using:
```bash
python -m opal.main jobs get-job-types
```

For more details and examples, see:

- [README.md](README.md)
- [API_Reference.md](API_Reference.md)
- [Job_Types.md](Job_Types.md)



**All Rights Reserved**
