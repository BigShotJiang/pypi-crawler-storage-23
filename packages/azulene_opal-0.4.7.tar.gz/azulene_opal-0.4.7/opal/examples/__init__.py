"""Example molecule files for testing Opal jobs."""

from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"

# T4 lysozyme co-crystallized with benzene (PDB 4W52)
T4_LYSOZYME_BENZENE_PDB = DATA_DIR / "4W52_t4_lysozyme_benzene.pdb"
# Benzene bound pose extracted from 4W52 — use as ligand_file for ABFE/RBFE
BENZENE_BOUND_SDF = DATA_DIR / "benzene_bound_pose.sdf"
TOLUENE_SDF = DATA_DIR / "toluene.sdf"
FKB_MODEL_PDB = DATA_DIR / "fkb_model_0_2.pdb"
INPUT_DMSO = DATA_DIR / "input_dmso.txt"


def get_example_path(filename: str) -> Path:
    """Return the full path to an example data file.

    Usage:
        from opal.examples import get_example_path
        pdb = get_example_path("4W52_t4_lysozyme_benzene.pdb")
    """
    path = DATA_DIR / filename
    if not path.exists():
        available = [f.name for f in DATA_DIR.iterdir() if f.is_file()]
        raise FileNotFoundError(
            f"Example file '{filename}' not found. Available: {available}"
        )
    return path
