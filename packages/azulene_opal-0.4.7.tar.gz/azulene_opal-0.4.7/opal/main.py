"""Typer CLI entrypoint."""

import typer
from opal import auth, jobs

app = typer.Typer(help="</> Opal CLI - Submit and manage Azulene Opal jobs via a command line interface")

# Register auth commands
app.command("login")(auth.login_cli)
app.command("logout")(auth.logout_cli)
app.command("whoami")(auth.whoami_cli)

# Create sub-app for jobs
jobs_app = typer.Typer(help="Job commands (submit, cancel, get, etc.)")
jobs_app.command("submit", help="Submit a new job to the backend")(jobs.submit_cli)
jobs_app.command("cancel", help="Cancel a running job by job ID")(jobs.cancel_cli)
jobs_app.command("get", help="Get detailed information about a specific job by ID")(jobs.get_cli)
jobs_app.command("get-jobs", help="List all submitted jobs for the current user")(jobs.get_jobs_cli)
jobs_app.command("check-running-jobs", help="Poll all running jobs and update their statuses")(jobs.check_running_jobs_cli)
jobs_app.command("check-health", help="Check the health/status of the backend job system")(jobs.check_health_cli)
jobs_app.command("get-job-types", help="Get the list of available job types")(jobs.get_job_types_cli)
jobs_app.command("submit-batch-jobs", help="Submit a batch of jobs for a given job_type")(jobs.submit_batch_jobs_cli)
jobs_app.command("get-result", help="Get just the results of a completed job")(jobs.get_result_cli)
jobs_app.command("wait", help="Wait for a job to complete, then print results")(jobs.wait_cli)
jobs_app.command("relative-binding", help="Calculate relative binding free energy between two ligands")(jobs.relative_binding_cli)
jobs_app.command("predict-solubility", help="Predict aqueous solubility (logS) for a molecule")(jobs.predict_solubility_cli)

# Mount it under `opal jobs ...`
app.add_typer(jobs_app, name="jobs")

def main():
    app()

if __name__ == "__main__":
    main()


