# Submit, cancel, get, poll
import os
import json
import time
from pathlib import Path
import httpx
import typer
from opal import config, auth
from opal.auth import SUPABASE_ANON_KEY, SUPABASE_URL
from opal.storage_helpers import _has_local_files, _transform_input_files, _upload_local_file_to_storage, _build_storage_key
from rich import print as rprint
from typing import Any, Dict, List, Optional, Union
# ---------------------
# Internal
# ---------------------

def _stringify_paths(obj):
    """Recursively convert Path objects to strings for JSON serialization."""
    if isinstance(obj, Path):
        return str(obj)
    if isinstance(obj, dict):
        return {k: _stringify_paths(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_stringify_paths(v) for v in obj]
    return obj


def _auth_headers():
    try:
        token = config.get_access_token()
    except config.TokenExpiredException:
        # Token expired: try to refresh
        token = auth.refresh_session()
    except config.NotLoggedInException:
        # Not logged in: handle as you wish
        raise Exception("You are not logged in. Please run `opal login`.")

    return {
        "Authorization": f"Bearer {token}",
        "apikey": SUPABASE_ANON_KEY,
        "Content-Type": "application/json"
    }


def _get_token_only() -> str:
    try:
        token = config.get_access_token()
    except config.TokenExpiredException:
        token = auth.refresh_session()
    except config.NotLoggedInException:
        raise Exception("You are not logged in. Please run `opal login`.")
    return token


def _get_user() -> dict:
    url = f"{SUPABASE_URL}/auth/v1/user"
    r = httpx.get(url, headers=_auth_headers(), timeout=60)
    if r.status_code == 200:
        return r.json()
    else:
        raise Exception(f"Failed to fetch user info: {r.text}")

# ---------------------
# Python API functions
# ---------------------

def check_health():
    """
    Library function.
    Returns:
      {"ok": True, "data": {...}} on success
      {"ok": False, "status_code": int, "error": str} on failure
    """
    url = f"{SUPABASE_URL}/functions/v1/check-health"
    r = httpx.get(url, headers=_auth_headers(), timeout=60)
    if r.status_code == 200:
        return {"ok": True, "data": r.json()}
    else:
        return {"ok": False, "status_code": r.status_code, "error": r.text}


def check_health_cli():
    """CLI wrapper for `check_health`."""
    result = check_health()
    if result.get("ok"):
        rprint("[green]✅ Health check passed[/green]")
        rprint(result["data"])
    else:
        rprint("[red]❌ Health check failed:[/red]", result.get("error"), f"(status {result.get('status_code')})")

def submit(
    job_type: str,
    input_data,
):
    """
    Library function to submit a job.

    Args:
      job_type: e.g. "process_txt"
      input_data: JSON string or dict

    Returns:
      {"ok": True, "data": {...}} on success
      {"ok": False, "status_code": int, "error": str} on HTTP failure
      {"ok": False, "error": str, "stage": "auth" | "file_handling"} on local failures
    """
    submit_url = f"{SUPABASE_URL}/functions/v1/submit-job"

    # Parse JSON string or accept dict
    parsed_input = json.loads(input_data) if isinstance(input_data, str) else input_data

    # Convert any Path objects to strings so JSON serialization works
    parsed_input = _stringify_paths(parsed_input)

    # First path: if no local files detected, just submit
    if not _has_local_files(parsed_input):
        r = httpx.post(
            submit_url,
            headers=_auth_headers(),
            json={
                "job_type": job_type,
                "input_data": parsed_input,
            },
            timeout=60,
        )
        if r.status_code == 200:
            return {"ok": True, "data": r.json()}
        else:
            return {"ok": False, "status_code": r.status_code, "error": r.text}

    # Second path: we do have local files --> fetch token & user once, upload, then submit
    try:
        token = _get_token_only()   # reuse your existing helper
        user = _get_user()          # calls /auth/v1/user once
        user_id = user.get("id")
    except Exception as e:
        return {"ok": False, "error": str(e), "stage": "auth"}

    try:
        transformed = _transform_input_files(parsed_input, token=token, user_id=user_id)
    except Exception as e:
        return {"ok": False, "error": str(e), "stage": "file_handling"}

    # Build headers without re-fetching token (use the one we already have)
    headers = {
        "Authorization": f"Bearer {token}",
        "apikey": SUPABASE_ANON_KEY,
        "Content-Type": "application/json",
    }

    r = httpx.post(
        submit_url,
        headers=headers,
        json={
            "job_type": job_type,
            "input_data": transformed,
        },
        timeout=60,
    )
    if r.status_code == 200:
        return {"ok": True, "data": r.json()}
    else:
        return {"ok": False, "status_code": r.status_code, "error": r.text}


def submit_cli(
    job_type: str = typer.Option(..., "--job-type", help="e.g., process_txt"),
    input_data: str = typer.Option(..., "--input-data", help='JSON string like \'{"file_url": "C:/path/to.txt"}\''),
):
    """CLI wrapper for `submit`."""
    result = submit(job_type=job_type, input_data=input_data)

    if result.get("ok"):
        rprint("[green]✅ Job submitted successfully[/green]")
        rprint(result["data"])
    else:
        stage = result.get("stage")
        if stage == "auth":
            rprint(f"[red]❌ Auth error during job submission:[/red] {result.get('error')}")
        elif stage == "file_handling":
            rprint(f"[red]❌ File handling failed:[/red] {result.get('error')}")
        else:
            rprint("[red]❌ Job submission failed:[/red]", result.get("error"), f"(status {result.get('status_code')})")


def submit_batch_jobs(
    job_type: str,
    input_data: List[Union[Dict[str, Any], str]],
) -> Dict[str, Any]:
    """
    Submit a batch of jobs for a given job_type.

    Args:
        job_type:
            The job_type to use for every job (e.g. "absolute_solvation_energy_aqueous").
        input_data:
            A list where each element is a single job's input_data.
            Each element is exactly what you'd normally pass into submit(..., input_data=...):
              - a dict (preferred), or
              - a JSON string.

    Returns:
        {"ok": True, "results": [ { "index": i, "input": <input>, "response": <submit_result> }, ... ]}
    """
    results: List[Dict[str, Any]] = []

    for idx, inp in enumerate(input_data):
        try:
            single_result = submit(job_type=job_type, input_data=inp)
        except Exception as e:
            single_result = {"ok": False, "error": f"Exception during submit: {e}"}

        results.append(
            {
                "index": idx,
                "input": inp,
                "response": single_result,
            }
        )

    return {"ok": True, "results": results}


def submit_batch_jobs_cli(
    job_type: str = typer.Option(
        ...,
        "--job-type",
        help='Job type to submit (e.g. "generate_conformers").',
    ),
    input_data: str = typer.Option(
        ...,
        "--input-data",
        help="JSON list of per-job input_data, e.g. "
             '\'[{"smiles": "CCO", "num_conformers": 2}, {"smiles": "CCCO", "num_conformers": 5}]\'',
    ),
):
    """
    CLI wrapper for submit_batch_jobs.

    Example:

      python -m opal.main jobs submit-batch-jobs \\
        --job-type generate_conformers \\
        --input-data '[{"smiles": "CCO", "num_conformers": 2}, {"smiles": "CCCO"}, "num_conformers": 5]'
    """
    try:
        parsed = json.loads(input_data)
    except Exception as e:
        rprint(f"[red]❌ Failed to parse --input-data JSON:[/red] {e}")
        raise typer.Exit(code=1)

    if not isinstance(parsed, list):
        rprint("[red]❌ --input-data must be a JSON list (array) of per-job inputs.[/red]")
        raise typer.Exit(code=1)

    result = submit_batch_jobs(job_type=job_type, input_data=parsed)

    if not result.get("ok"):
        rprint(f"[red]❌ Batch submission failed:[/red] {result.get('error')}")
        raise typer.Exit(code=1)

    batch_results = result.get("results", [])
    total = len(batch_results)
    successes = sum(1 for r in batch_results if r["response"].get("ok"))
    failures = total - successes

    rprint(
        f"[green]✅ Batch submission complete.[/green] "
        f"Total jobs: {total}, successes: {successes}, failures: {failures} \n"
        # f"Results: \n {batch_results}"
    )

    # print job IDs if present in each response
    for item in batch_results:
        idx = item["index"]
        resp = item["response"]

        if resp.get("ok") and isinstance(resp.get("data"), dict):
            data = resp["data"]
            job_id = data.get("job_id")
            run_call = data.get("run_job_call_id")
            status = data.get("status")
            msg = data.get("message")

            rprint(
                f"  - [{idx}] job_id={job_id} | status={status} | message={msg} "
            )
        else:
            err = resp.get("error", "Unknown error")
            rprint(f"  - [{idx}] [red]FAILED[/red]: {err}")

def get_jobs(
    limit: Optional[int] = None,
    all_jobs: bool = False,
    job_type: Optional[str] = None,
    status: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
):
    """
    Library function to fetch jobs.

    Args:
        limit: Optional[int]
            Max number of jobs to return. If None, the default is 5.
            Ignored if all_jobs is True.
        all_jobs: bool
            If True, request all matching jobs (no limit).
        job_type: Optional[str]
            Filter by job_type (e.g. "generate_conformers").
        status: Optional[str]
            Filter by job status ("completed", "failed", "running")
        start_date: Optional[str]
            Filter by created_at >= start_date (DateTime string).
        end_date: Optional[str]
            Filter by created_at <= end_date (DateTime string).

    Returns:
        {"ok": True, "data": [...]} on success
        {"ok": False, "status_code": int, "error": str} on failure
    """
    url = f"{SUPABASE_URL}/functions/v1/get-jobs"

    params: dict[str, str] = {}

    if all_jobs:
        params["all"] = "true"
    elif limit is not None:
        params["limit"] = str(limit)

    if job_type:
        params["job_type"] = job_type

    if status:
        params["status"] = status

    if start_date:
        params["start_date"] = start_date

    if end_date:
        params["end_date"] = end_date

    r = httpx.get(url, headers=_auth_headers(), params=params or None, timeout=60)
    if r.status_code == 200:
        return {"ok": True, "data": r.json()}
    else:
        return {"ok": False, "status_code": r.status_code, "error": r.text}


def get_jobs_cli(
    limit: Optional[int] = typer.Option(
        None,
        "--limit",
        help="Number of jobs to fetch (default 5). Ignored if --all is set.",
    ),
    all_jobs: bool = typer.Option(
        False,
        "--all",
        help="Fetch all jobs (ignore limit).",
    ),
    job_type: Optional[str] = typer.Option(
        None,
        "--job-type",
        help='Filter by job_type, e.g. "generate_conformers".',
    ),
    status: Optional[str] = typer.Option(
        None,
        "--status",
        help='Filter by job status: "completed", "failed", "running".',
    ),
    start_date: Optional[str] = typer.Option(
        None,
        "--start-date",
        help="Filter by created_at >= this datetime (e.g. 2025-12-01T00:00:00Z).",
    ),
    end_date: Optional[str] = typer.Option(
        None,
        "--end-date",
        help="Filter by created_at <= this datetime (e.g. 2025-12-05T00:00:00Z).",
    ),
):
    """
    CLI wrapper for `get_jobs`.

    Examples:
      opal jobs get-jobs                    ---> last 5 jobs
      opal jobs get-jobs --all              ---> all jobs
      opal jobs get-jobs --limit 10         ---> last 10 jobs
      opal jobs get-jobs --job-type generate_conformers --status completed
      opal jobs get-jobs --start-date 2025-12-01T00:00:00Z --end-date 2025-12-05T00:00:00Z
    """
    result = get_jobs(
        limit=limit,
        all_jobs=all_jobs,
        job_type=job_type,
        status=status,
        start_date=start_date,
        end_date=end_date,
    )

    if result.get("ok"):
        rprint("[blue]📋 Jobs:[/blue]")
        rprint(result["data"])
    else:
        rprint(
            "[red]❌ Failed to fetch jobs:[/red]",
            result.get("error"),
            f"(status {result.get('status_code')})",
        )

def get(job_id: str):
    """
    Library: get a single job by ID.
    """
    url = f"{SUPABASE_URL}/functions/v1/get-job/{job_id}"
    r = httpx.get(url, headers=_auth_headers(), timeout=60)
    if r.status_code == 200:
        return {"ok": True, "data": r.json()}
    else:
        return {"ok": False, "status_code": r.status_code, "error": r.text}


def get_cli(
    job_id: str = typer.Option(..., "--job-id", help="Job ID to fetch"),
):
    """CLI wrapper for `get`."""
    result = get(job_id=job_id)
    if result.get("ok"):
        rprint("[blue]📄 Job Info:[/blue]")
        rprint(result["data"])
    else:
        rprint("[red]❌ Failed to fetch job:[/red]", result.get("error"), f"(status {result.get('status_code')})")


def get_result(job_id: str):
    """
    Library function to get just the results of a completed job.

    Fetches the job by ID and returns the results field directly.
    If the job is still running, returns a status indicator instead.

    Args:
        job_id: The job ID to fetch results for.

    Returns:
        {"ok": True, "status": "completed", "results": {...}} when done
        {"ok": True, "status": "running"} when still running
        {"ok": True, "status": "failed", "error": str} when job failed
        {"ok": True, "status": "cancelled"} when job was cancelled
        {"ok": False, ...} on fetch failure

    The results dict varies by job type. Common fields:

        predict_solubility:
            predicted_logS (float) — predicted aqueous solubility

        relative_binding:
            ddg_binding (float) — relative binding free energy in kcal/mol
            results_file (dict) — download_url and size for full output archive

        absolute_binding:
            dg_binding (float) — absolute binding free energy in kcal/mol
            results_file (dict) — download_url and size for full output archive

        aqueous_solvation / nonaqueous_solvation:
            dg_solvation (float) — solvation free energy in kcal/mol

        generate_conformers:
            conformers (list) — generated 3D conformer coordinates

    All completed jobs may include:
        results_file (dict) — {"download_url": str, "size_bytes": int}
            if keep_dirs=True was set at submission time
    """
    response = get(job_id)
    if not response.get("ok"):
        return response

    job = response["data"]
    status = job.get("status", "unknown")

    if status == "completed":
        return {"ok": True, "status": "completed", "results": job.get("results")}
    elif status == "failed":
        return {"ok": True, "status": "failed", "error": job.get("error_message", "Unknown error")}
    elif status == "cancelled":
        return {"ok": True, "status": "cancelled"}
    else:
        return {"ok": True, "status": status}


def get_result_cli(
    job_id: str = typer.Option(..., "--job-id", help="Job ID to fetch results for"),
):
    """Get the results of a completed job."""
    result = get_result(job_id=job_id)
    if not result.get("ok"):
        rprint("[red]Failed to fetch job:[/red]", result.get("error"), f"(status {result.get('status_code')})")
        raise typer.Exit(code=1)

    status = result.get("status")
    if status == "completed":
        rprint("[green]Job completed[/green]")
        rprint(json.dumps(result["results"], indent=2))
    elif status == "failed":
        rprint("[red]Job failed:[/red]", result.get("error"))
        raise typer.Exit(code=1)
    elif status == "cancelled":
        rprint("[yellow]Job was cancelled[/yellow]")
        raise typer.Exit(code=1)
    else:
        rprint(f"[yellow]Job status: {status}[/yellow]")


def wait(
    job_id: str,
    poll_interval: float = 5.0,
    timeout: Optional[float] = None,
):
    """
    Library function to wait for a job to complete.

    Polls the job status until it reaches a terminal state
    (completed, failed, or cancelled).

    Args:
        job_id: The job ID to wait for.
        poll_interval: Seconds between polls (default 5).
        timeout: Max seconds to wait. None means wait forever.

    Returns:
        {"ok": True, "status": "completed", "results": {...}} when done
        {"ok": True, "status": "failed", "error": str} when job failed
        {"ok": True, "status": "cancelled"} when job was cancelled
        {"ok": False, "error": "timeout"} if timeout exceeded
        {"ok": False, ...} on fetch failure
    """
    start = time.time()
    while True:
        response = get(job_id)
        if not response.get("ok"):
            return response

        job = response["data"]
        status = job.get("status", "unknown")

        if status == "completed":
            return {"ok": True, "status": "completed", "results": job.get("results")}
        elif status == "failed":
            return {"ok": True, "status": "failed", "error": job.get("error_message", "Unknown error")}
        elif status == "cancelled":
            return {"ok": True, "status": "cancelled"}

        if timeout is not None and (time.time() - start) >= timeout:
            return {"ok": False, "error": "timeout", "last_status": status}

        time.sleep(poll_interval)


def wait_cli(
    job_id: str = typer.Option(..., "--job-id", help="Job ID to wait for"),
    poll_interval: float = typer.Option(5.0, "--poll-interval", help="Seconds between status checks"),
    timeout: Optional[float] = typer.Option(None, "--timeout", help="Max seconds to wait (default: no limit)"),
):
    """Wait for a job to complete, then print the results."""
    rprint(f"Waiting for job {job_id}...")
    result = wait(job_id=job_id, poll_interval=poll_interval, timeout=timeout)

    if not result.get("ok"):
        if result.get("error") == "timeout":
            rprint(f"[yellow]Timed out after {timeout}s. Last status: {result.get('last_status')}[/yellow]")
        else:
            rprint("[red]Failed to fetch job:[/red]", result.get("error"), f"(status {result.get('status_code')})")
        raise typer.Exit(code=1)

    status = result.get("status")
    if status == "completed":
        rprint("[green]Job completed[/green]")
        rprint(json.dumps(result["results"], indent=2))
    elif status == "failed":
        rprint("[red]Job failed:[/red]", result.get("error"))
        raise typer.Exit(code=1)
    elif status == "cancelled":
        rprint("[yellow]Job was cancelled[/yellow]")
        raise typer.Exit(code=1)


def cancel(job_id: str):
    """
    Library: cancel a job by ID.
    """
    url = f"{SUPABASE_URL}/functions/v1/cancel-job/{job_id}"
    r = httpx.delete(url, headers=_auth_headers(), timeout=60)
    if r.status_code == 200:
        return {"ok": True, "data": r.json()}
    else:
        return {"ok": False, "status_code": r.status_code, "error": r.text}


def cancel_cli(
    job_id: str = typer.Option(..., "--job-id", help="Job ID to cancel"),
):
    """CLI wrapper for `cancel`."""
    result = cancel(job_id=job_id)
    if result.get("ok"):
        rprint("[yellow]⚠️ Job cancelled[/yellow]")
        rprint(result["data"])
    else:
        rprint("[red]❌ Failed to cancel job:[/red]", result.get("error"), f"(status {result.get('status_code')})")


def check_running_jobs():
    """
    Library: poll running jobs.
    """
    url = f"{SUPABASE_URL}/functions/v1/poll-modal-results"
    r = httpx.post(url, headers=_auth_headers(), timeout=60)
    if r.status_code == 200:
        return {"ok": True, "data": r.json()}
    else:
        return {"ok": False, "status_code": r.status_code, "error": r.text}


def check_running_jobs_cli():
    """CLI wrapper for `check_running_jobs`."""
    result = check_running_jobs()
    if result.get("ok"):
        rprint("[green]🔁 Polling complete[/green]")
        rprint(result["data"])
    else:
        rprint("[red]❌ Polling failed:[/red]", result.get("error"), f"(status {result.get('status_code')})")


def get_job_types():
    """
    Library: get available job types.
    """
    url = f"{SUPABASE_URL}/functions/v1/get-func-defs"
    r = httpx.get(url, headers=_auth_headers(), timeout=60)
    if r.status_code == 200:
        return {"ok": True, "data": r.json()}
    else:
        return {"ok": False, "status_code": r.status_code, "error": r.text}


def get_job_types_cli():
    """CLI wrapper for `get_job_types`."""
    result = get_job_types()
    if result.get("ok"):
        rprint("[cyan]📦 Available job types (from function constant):[/cyan]")
        rprint(result["data"])
    else:
        rprint("[red]❌ Failed to get job types:[/red]", result.get("error"), f"(status {result.get('status_code')})")


def relative_binding(
    smiles_a: str,
    smiles_b: str,
    pdb_file: str,
    ligand_file_a: Optional[str] = None,
    ligand_file_b: Optional[str] = None,
    ligand_in_pdb_file_a: bool = False,
    ligand_in_pdb_file_b: bool = False,
    protonate: bool = False,
    ph: float = 7.0,
    equil_length: float = 0.08,
    prod_length: float = 0.4,
    platform: str = "CUDA",
    protocol_repeats: int = 3,
    keep_dirs: bool = True,
):
    """
    Library function to calculate relative binding free energy.

    Calculates the DDG of binding between two ligands to a protein.

    Args:
        smiles_a: SMILES string of ligand A
        smiles_b: SMILES string of ligand B
        pdb_file: Path to protein PDB file (local file or URL)
        ligand_file_a: Path to ligand A structure file (SDF recommended)
        ligand_file_b: Path to ligand B structure file (SDF recommended)
        ligand_in_pdb_file_a: If True, ligand A coordinates come from the protein PDB
        ligand_in_pdb_file_b: If True, ligand B coordinates come from the protein PDB
        protonate: Protonate ligands at given pH
        ph: pH for protonation
        equil_length: Equilibration length in ns
        prod_length: Production length in ns
        platform: OpenMM compute platform
        protocol_repeats: Number of protocol repeats
        keep_dirs: Whether to keep and upload result directories

    Returns:
        {"ok": True, "data": {...}} on success
        {"ok": False, ...} on failure
    """
    input_data = {
        "smiles_a": smiles_a,
        "smiles_b": smiles_b,
        "pdb_file": pdb_file,
        "protonate": protonate,
        "ph": ph,
        "equil_length": equil_length,
        "prod_length": prod_length,
        "platform": platform,
        "protocol_repeats": protocol_repeats,
        "keep_dirs": keep_dirs,
    }
    if ligand_file_a:
        input_data["ligand_file_a"] = ligand_file_a
    if ligand_file_b:
        input_data["ligand_file_b"] = ligand_file_b
    if ligand_in_pdb_file_a:
        input_data["ligand_in_pdb_file_a"] = True
    if ligand_in_pdb_file_b:
        input_data["ligand_in_pdb_file_b"] = True

    return submit(job_type="relative_binding", input_data=input_data)


def relative_binding_cli(
    smiles_a: str = typer.Option(..., "--smiles-a", help="SMILES string of ligand A"),
    smiles_b: str = typer.Option(..., "--smiles-b", help="SMILES string of ligand B"),
    pdb_file: str = typer.Option(..., "--pdb-file", help="Path to protein PDB file"),
    ligand_file_a: Optional[str] = typer.Option(None, "--ligand-file-a", help="Path to ligand A structure file (SDF recommended)"),
    ligand_file_b: Optional[str] = typer.Option(None, "--ligand-file-b", help="Path to ligand B structure file (SDF recommended)"),
    ligand_in_pdb_file_a: bool = typer.Option(False, "--ligand-in-pdb-a", help="Ligand A coordinates are in the protein PDB"),
    ligand_in_pdb_file_b: bool = typer.Option(False, "--ligand-in-pdb-b", help="Ligand B coordinates are in the protein PDB"),
    protonate: bool = typer.Option(False, "--protonate", help="Protonate ligands at given pH"),
    ph: float = typer.Option(7.0, "--ph", help="pH for protonation"),
    equil_length: float = typer.Option(0.08, "--equil-length", help="Equilibration length in ns"),
    prod_length: float = typer.Option(0.4, "--prod-length", help="Production length in ns"),
    platform: str = typer.Option("CUDA", "--platform", help="OpenMM compute platform"),
    protocol_repeats: int = typer.Option(3, "--protocol-repeats", help="Number of protocol repeats"),
    keep_dirs: bool = typer.Option(True, "--keep-dirs", help="Keep and upload result directories"),
):
    """Calculate relative binding free energy between two ligands."""
    result = relative_binding(
        smiles_a=smiles_a,
        smiles_b=smiles_b,
        pdb_file=pdb_file,
        ligand_file_a=ligand_file_a,
        ligand_file_b=ligand_file_b,
        ligand_in_pdb_file_a=ligand_in_pdb_file_a,
        ligand_in_pdb_file_b=ligand_in_pdb_file_b,
        protonate=protonate,
        ph=ph,
        equil_length=equil_length,
        prod_length=prod_length,
        platform=platform,
        protocol_repeats=protocol_repeats,
        keep_dirs=keep_dirs,
    )
    if result.get("ok"):
        rprint("[green]Relative binding free energy job submitted[/green]")
        rprint(result["data"])
    else:
        rprint("[red]Job submission failed:[/red]", result.get("error"), f"(status {result.get('status_code')})")


def predict_solubility(smiles: str):
    """
    Library function to predict aqueous solubility for a single molecule.

    Submits a predict_solubility job and returns the result.

    Args:
        smiles: SMILES string of the molecule

    Returns:
        {"ok": True, "data": {...}} on success
        {"ok": False, ...} on failure
    """
    return submit(job_type="predict_solubility", input_data={"smiles": smiles})


def predict_solubility_cli(
    smiles: str = typer.Option(..., "--smiles", help="SMILES string of the molecule to predict solubility for"),
):
    """Predict aqueous solubility (logS) for a molecule."""
    result = predict_solubility(smiles=smiles)
    if result.get("ok"):
        rprint("[green]✅ Solubility prediction submitted[/green]")
        rprint(result["data"])
    else:
        rprint("[red]❌ Prediction failed:[/red]", result.get("error"), f"(status {result.get('status_code')})")
