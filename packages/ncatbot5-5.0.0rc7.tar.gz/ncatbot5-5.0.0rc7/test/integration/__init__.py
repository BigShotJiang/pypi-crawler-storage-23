"""Integration tests for NcatBot."""
