"""
CachiBot utilities.
"""

from cachibot.utils.markdown import strip_markdown

__all__ = ["strip_markdown"]
