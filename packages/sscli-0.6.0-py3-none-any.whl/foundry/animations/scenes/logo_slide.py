"""
Logo slide animation: The Foundry logo slides into view.
"""

from ..animation import Animation, AnimationConfig
from ..assets import RAW_LOGO
from ..components import render_base_background, render_stars
from ..core import FRAME_HEIGHT, FRAME_WIDTH, Canvas
from ..engine.frame_buffer import FrameBuffer
from ..engine.state import AnimationState, ScenePhase


class LogoSlideAnimation(Animation):
    """
    Logo slide animation: Large logo slides from the top or side.
    """

    def __init__(self, duration: float = 1.5):
        super().__init__(AnimationConfig(duration=duration))

    def _update_impl(self, dt: float, state: AnimationState) -> AnimationState:
        return state.with_updates(scene_phase=ScenePhase.LOGO_SLIDE)

    def render(self, frame_buffer: FrameBuffer, state: AnimationState) -> None:
        # 1. Background layer
        bg_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        render_stars(bg_canvas, count=15)
        render_base_background(bg_canvas, tree_growth=0.5, grass_wind=state.grass_wind)
        frame_buffer.add_layer("background", bg_canvas.buffer)

        # 2. Logo layer
        logo_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        progress = self.get_progress()

        # Slide effect: move from right to center
        center_x = (FRAME_WIDTH - len(RAW_LOGO[0])) // 2
        start_x = FRAME_WIDTH
        current_x = int(start_x - (start_x - center_x) * progress)

        y_pos = 4
        logo_canvas.draw_sprite(RAW_LOGO, current_x, y_pos, style="bold cyan")

        frame_buffer.add_layer("logo", logo_canvas.buffer)
