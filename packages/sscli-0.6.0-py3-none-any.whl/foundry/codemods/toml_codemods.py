"""
Concrete TOML codemods for pyproject.toml modifications.
All preserve formatting, comments, and ensure safe transformations.
"""

import re
from pathlib import Path
from typing import Any, Optional
import tomlkit

from foundry.codemods.base import TomlTransformer, ModificationResult


def extract_package_name(dep_string: str) -> str:
    """
    Extract package name from a dependency specification.
    Handles version specifiers, extras, and other markers.
    
    Examples:
        "requests>=2.28.0" -> "requests"
        "django[postgres]>=4.0" -> "django"
        "pytest ~= 7.0" -> "pytest"
    """
    # Remove everything after '[' (extras) or any version operator
    # Split on version operators: >=, <=, ==, !=, ~=, >, <, [
    match = re.match(r'^([a-zA-Z0-9._-]+)', dep_string.strip())
    if match:
        return match.group(1)
    return dep_string.strip()


class AddPythonDependencyCM(TomlTransformer):
    """Add one or more Python dependencies to pyproject.toml safely."""

    def __init__(
        self,
        dependencies: list[str],
        version: str = "*",
        section: str = "dependencies"
    ) -> None:
        """
        Args:
            dependencies: List of package names to add
            version: Version spec (default: "*" for any version)
            section: Section to add to (default: "dependencies" for setuptools)
        """
        self.dependencies = dependencies
        self.version = version
        self.section = section

    def transform(self, doc: Any) -> Any:
        """Add dependencies to [project.dependencies] or [tool.poetry.dependencies]."""
        # Try [project.dependencies] first (setuptools/modern)
        if "project" in doc:
            if "dependencies" not in doc["project"]:
                doc["project"]["dependencies"] = tomlkit.array()
            deps = doc["project"]["dependencies"]
            for dep in self.dependencies:
                # Check if already exists (case-insensitive, ignoring version specs)
                dep_name = extract_package_name(dep).lower()
                if not any(extract_package_name(str(d)).lower() == dep_name for d in deps):
                    # Only add version if version doesn't start with operator and isn't "*"
                    if self.version == "*":
                        version_str = ""
                    elif self.version[0] in "<>=!":
                        version_str = self.version
                    else:
                        version_str = ">=" + self.version
                    deps.append(f"{dep}{version_str}")
            return doc

        # Fall back to [tool.poetry.dependencies]
        if "tool" not in doc:
            doc["tool"] = tomlkit.table()

        tool = doc["tool"]
        if "poetry" not in tool:
            tool["poetry"] = tomlkit.table()

        poetry = tool["poetry"]
        if "dependencies" not in poetry:
            poetry["dependencies"] = tomlkit.table()

        deps = poetry["dependencies"]

        for dep in self.dependencies:
            if dep not in deps:
                deps[dep] = self.version

        return doc


class RemovePythonDependencyCM(TomlTransformer):
    """Remove one or more Python dependencies from pyproject.toml."""

    def __init__(self, dependencies: list[str]) -> None:
        """
        Args:
            dependencies: List of package names to remove
        """
        self.dependencies = dependencies

    def transform(self, doc: Any) -> Any:
        """Remove dependencies from [project.dependencies] or [tool.poetry.dependencies]."""
        # Try [project.dependencies] first (setuptools/modern)
        if "project" in doc and "dependencies" in doc["project"]:
            deps = doc["project"]["dependencies"]
            # Use list comprehension to safely remove
            doc["project"]["dependencies"] = [
                d for d in deps
                if not any(dep.lower() in d.lower() for dep in self.dependencies)
            ]

        # Also try [tool.poetry.dependencies]
        if "tool" in doc and "poetry" in doc["tool"]:
            if "dependencies" in doc["tool"]["poetry"]:
                deps = doc["tool"]["poetry"]["dependencies"]
                for dep in self.dependencies:
                    if dep in deps:
                        del deps[dep]

        return doc


class RemoveToolSectionsCM(TomlTransformer):
    """Remove entire [tool.XXX] sections from TOML document."""

    def __init__(self, tool_names: list[str]) -> None:
        """
        Args:
            tool_names: List of tool section names to remove (e.g., ["mypy", "ruff"])
        """
        self.tool_names = tool_names

    def transform(self, doc: Any) -> Any:
        """Remove tool sections and associated dependencies."""
        if "tool" not in doc:
            return doc

        tool = doc["tool"]

        # Remove sections
        for tool_name in self.tool_names:
            if tool_name in tool:
                del tool[tool_name]

        # Also remove from dependencies if present
        if "poetry" in tool and "dependencies" in tool["poetry"]:
            deps = tool["poetry"]["dependencies"]
            for tool_name in self.tool_names:
                if tool_name in deps:
                    del deps[tool_name]

        return doc


class UpdateValueCM(TomlTransformer):
    """Update a value at a specific TOML path."""

    def __init__(
        self,
        path: list[str],
        new_value: Any,
        create_missing: bool = False
    ) -> None:
        """
        Args:
            path: Path like ["tool", "poetry", "version"]
            new_value: Value to set
            create_missing: If True, create missing sections
        """
        self.path = path
        self.new_value = new_value
        self.create_missing = create_missing

    def transform(self, doc: Any) -> Any:
        """Update value at path."""
        try:
            current = self.navigate_path(doc, self.path[:-1], self.create_missing)
            if current is not None:
                current[self.path[-1]] = self.new_value
        except (KeyError, TypeError):
            if self.create_missing:
                current = self.navigate_path(doc, self.path[:-1], True)
                if current is not None:
                    current[self.path[-1]] = self.new_value

        return doc


class AddPythonVersionCM(TomlTransformer):
    """Set minimum Python version requirement in pyproject.toml."""

    def __init__(self, min_version: str) -> None:
        """
        Args:
            min_version: Version spec like "^3.11" or ">=3.10"
        """
        self.min_version = min_version

    def transform(self, doc: Any) -> Any:
        """Update python dependency to minimum version."""
        # Try [project] first (modern)
        if "project" in doc and "requires-python" in doc["project"]:
            current = str(doc["project"]["requires-python"])
            if self._is_more_restrictive(current, self.min_version):
                doc["project"]["requires-python"] = self.min_version
            return doc

        # Try [tool.poetry.dependencies]
        if "tool" in doc and "poetry" in doc["tool"]:
            deps = doc["tool"]["poetry"].get("dependencies", {})
            if "python" in deps:
                current = str(deps["python"])
                if self._is_more_restrictive(current, self.min_version):
                    deps["python"] = self.min_version

        return doc

    @staticmethod
    def _is_more_restrictive(current: str, new: str) -> bool:
        """Simple comparison logic for version specs."""
        # Basic implementation for caret versions: "^3.11" > "^3.10"
        if "^" in current and "^" in new:
            try:
                c_ver = current.replace("^", "").strip()
                n_ver = new.replace("^", "").strip()
                c_parts = tuple(map(int, c_ver.split(".")))
                n_parts = tuple(map(int, n_ver.split(".")))
                return n_parts > c_parts
            except (ValueError, AttributeError):
                return False
        return False


class IdempotentAddDependencyCM(TomlTransformer):
    """Add dependencies idempotently (safe to run multiple times)."""

    def __init__(
        self,
        dependencies: list[str],
        version: str = "*"
    ) -> None:
        """
        Args:
            dependencies: List of package names to add
            version: Version spec (default: "*" for any version)
        """
        self.dependencies = dependencies
        self.version = version

    def transform(self, doc: Any) -> Any:
        """Add dependencies only if not already present."""
        # Try [project.dependencies] first (setuptools/modern)
        if "project" in doc and "dependencies" in doc["project"]:
            deps = doc["project"]["dependencies"]
            for dep in self.dependencies:
                # Check if already exists (case-insensitive, ignoring version specs)
                dep_name = extract_package_name(dep).lower()
                exists = any(
                    extract_package_name(str(d)).lower() == dep_name
                    for d in deps
                )
                if not exists:
                    # Only add version if version doesn't start with operator and isn't "*"
                    if self.version == "*":
                        version_str = ""
                    elif self.version[0] in "<>=!":
                        version_str = self.version
                    else:
                        version_str = ">=" + self.version
                    deps.append(f"{dep}{version_str}")
            return doc

        # Fall back to [tool.poetry.dependencies]
        if "tool" not in doc:
            doc["tool"] = tomlkit.table()

        tool = doc["tool"]
        if "poetry" not in tool:
            tool["poetry"] = tomlkit.table()

        poetry = tool["poetry"]
        if "dependencies" not in poetry:
            poetry["dependencies"] = tomlkit.table()

        deps = poetry["dependencies"]

        for dep in self.dependencies:
            if dep not in deps:
                deps[dep] = self.version

        return doc
