"""
JavaScript/TypeScript codemods using ast-grep for safe AST-based transformations.

Provides language-aware code modifications for JavaScript, TypeScript, and Astro files:
- Import injection (idempotent)
- JSX component injection
- Route definition injection
- Function call injection
- CSS/SCSS variable injection

Uses ast-grep for fast, declarative pattern matching and transformations.
"""

from pathlib import Path
from typing import Optional, Dict, List
import subprocess
import json
import tempfile

from foundry.codemods.base import BaseCodemod, ModificationResult
from foundry.constants import console


class JsCodemod(BaseCodemod):
    """
    Base class for ast-grep based JavaScript/TypeScript code transformations.
    Uses declarative YAML rules for pattern matching and code generation.
    """

    def apply(self, path: Path) -> ModificationResult:
        """Apply JavaScript code transformation using ast-grep."""
        print(f"DEBUG: JsCodemod.apply called on {path}")
        if not path.exists():
            return ModificationResult(
                success=False,
                error=f"File not found: {path}"
            )

        try:
            # 1/0  # DEBUG
            # Try ast-grep first
            rule = self.get_rule()
            if rule:
                result = self._apply_ast_grep(path, rule)
                if result.success:
                    return result
                
                # Check if it was because ast-grep was missing
                err_lower = (result.error or "").lower()
                if "ast-grep not found" in err_lower or "not found in path" in err_lower:
                    print("DEBUG: TRIGGERING FALLBACK")
                    return self._apply_string_based(path)
                
                return result
            else:
                # Fallback to string-based injection
                return self._apply_string_based(path)

        except Exception as e:
            return ModificationResult(
                success=False,
                error=f"{self.__class__.__name__}: {str(e)}"
            )

    def get_rule(self) -> Optional[Dict]:
        """
        Return ast-grep rule definition.
        Override in subclasses.
        
        Returns:
            Dict with 'rule', 'replace', and 'constrains' keys
        """
        raise NotImplementedError

    def _apply_ast_grep(self, path: Path, rule: Dict) -> ModificationResult:
        """Apply transformation using ast-grep CLI."""
        try:
            # Write rule to temporary YAML file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
                self._write_yaml_rule(f, rule)
                rule_file = f.name

            original_content = path.read_text(encoding="utf-8")

            try:
                # Run ast-grep with rule
                cmd = [
                    'ast-grep', 'scan',
                    '--pattern', rule['rule'],
                    '--replace', rule.get('replace', ''),
                    str(path)
                ]

                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=10
                )

                # Check if ast-grep made changes
                modified_content = path.read_text(encoding="utf-8")

                if modified_content != original_content:
                    return ModificationResult(
                        success=True,
                        modified_path=path,
                        changes_made=1
                    )
                else:
                    return ModificationResult(
                        success=True,
                        modified_path=path,
                        changes_made=0
                    )

            finally:
                Path(rule_file).unlink(missing_ok=True)

        except subprocess.TimeoutExpired:
            return ModificationResult(
                success=False,
                error="ast-grep execution timeout"
            )
        except FileNotFoundError:
            return ModificationResult(
                success=False,
                error="ast-grep not found in PATH"
            )

    def _apply_string_based(self, path: Path) -> ModificationResult:
        """
        Fallback string-based transformation.
        Override in subclasses for safety-aware string injection.
        """
        return ModificationResult(
            success=False,
            error="ast-grep not available and no fallback implemented"
        )

    @staticmethod
    def _write_yaml_rule(f, rule: Dict) -> None:
        """Write ast-grep YAML rule to file."""
        f.write("rule:\n")
        f.write(f"  pattern: {rule['rule']}\n")
        if 'replace' in rule:
            f.write(f"  replace: {rule['replace']}\n")


class InjectImportCodemod(JsCodemod):
    """
    Add an import statement to JavaScript/TypeScript file without duplicates.
    Handles both ES6 and CommonJS imports.
    
    Examples:
        import { useState } from 'react'
        import React from 'react'
        import * as path from 'path'
        const fs = require('fs')
    """

    def __init__(
        self,
        module: str,
        names: Optional[List[str]] = None,
        import_type: str = "esm"
    ):
        """
        Args:
            module: Module to import from (e.g., 'react')
            names: Specific names to import (e.g., ['useState', 'useEffect']).
                   If None, imports default export.
            import_type: 'esm' for ES6 or 'cjs' for CommonJS
        """
        self.module = module
        self.names = names or []
        self.import_type = import_type

    def get_rule(self) -> Optional[Dict]:
        """Return ast-grep rule for import injection."""
        if self.import_type == "esm":
            if self.names:
                names_str = ", ".join(self.names)
                pattern = f"import {{{names_str}}} from '{self.module}'"
                replace = f"import {{{names_str}}} from '{self.module}'"
            else:
                pattern = f"import * from '{self.module}'"
                replace = f"import * from '{self.module}'"
        else:
            const_name = self.names[0] if self.names else "module"
            pattern = f"const {const_name} = require('{self.module}')"
            replace = f"const {const_name} = require('{self.module}')"

        return {
            "rule": pattern,
            "replace": replace
        }

    def _apply_string_based(self, path: Path) -> ModificationResult:
        """Fallback string-based import injection."""
        try:
            content = path.read_text(encoding="utf-8")

            # Build import statement
            if self.import_type == "esm":
                if self.names:
                    import_stmt = f"import {{ {', '.join(self.names)} }} from '{self.module}';"
                else:
                    import_stmt = f"import * from '{self.module}';"
            else:
                const_name = self.names[0] if self.names else "module"
                import_stmt = f"const {const_name} = require('{self.module}');"

            # Check for duplicates
            if import_stmt in content:
                return ModificationResult(
                    success=True,
                    modified_path=path,
                    changes_made=0
                )

            # Insert after existing imports
            lines = content.split('\n')
            insert_idx = 0

            for i, line in enumerate(lines):
                if line.strip().startswith(('import ', 'const ', 'require(')):
                    insert_idx = i + 1

            lines.insert(insert_idx, import_stmt)
            path.write_text('\n'.join(lines), encoding="utf-8")

            return ModificationResult(
                success=True,
                modified_path=path,
                changes_made=1
            )

        except Exception as e:
            return ModificationResult(
                success=False,
                error=f"String-based injection failed: {str(e)}"
            )


class InjectRouteCodemod(JsCodemod):
    """
    Add a route definition to React/Astro application.
    Handles both React Router and Astro file-based routing.
    
    Examples for React:
        <Route path="/dashboard" element={<Dashboard />} />
        
    Examples for Astro:
        export const routes = [
          { path: '/about', component: About }
        ]
    """

    def __init__(
        self,
        path_pattern: str,
        component: str,
        framework: str = "react"
    ):
        """
        Args:
            path_pattern: URL path (e.g., '/dashboard')
            component: Component name (e.g., 'Dashboard')
            framework: 'react' or 'astro'
        """
        self.path_pattern = path_pattern
        self.component = component
        self.framework = framework

    def get_rule(self) -> Optional[Dict]:
        """Return ast-grep rule for route injection."""
        if self.framework == "react":
            pattern = f"<Route path=\"{self.path_pattern}\" element={{<{self.component} />}} />"
            replace = pattern
        else:
            # Astro uses file-based routing
            pattern = f"path: '{self.path_pattern}'"
            replace = pattern

        return {
            "rule": pattern,
            "replace": replace
        }

    def _apply_string_based(self, path: Path) -> ModificationResult:
        """Fallback string-based route injection."""
        try:
            content = path.read_text(encoding="utf-8")

            if self.framework == "react":
                route_def = f'<Route path="{self.path_pattern}" element={{<{self.component} />}} />'

                # Check for duplicate
                if f'path="{self.path_pattern}"' in content:
                    return ModificationResult(
                        success=True,
                        modified_path=path,
                        changes_made=0
                    )

                # Find routes section and inject
                if '<Routes>' in content:
                    insertion_point = content.rfind('</Routes>')
                    if insertion_point != -1:
                        # Add route before closing tag
                        modified = (
                            content[:insertion_point] +
                            '\n    ' + route_def + '\n  ' +
                            content[insertion_point:]
                        )
                        path.write_text(modified, encoding="utf-8")
                        return ModificationResult(
                            success=True,
                            modified_path=path,
                            changes_made=1
                        )

            elif self.framework == "astro":
                route_def = f"{{ path: '{self.path_pattern}', component: {self.component} }}"

                # Check for duplicate
                if f"path: '{self.path_pattern}'" in content:
                    return ModificationResult(
                        success=True,
                        modified_path=path,
                        changes_made=0
                    )

                # Find routes array and inject
                if 'routes' in content and '[' in content:
                    insertion_point = content.rfind(']')
                    if insertion_point != -1:
                        modified = (
                            content[:insertion_point] +
                            ',\n  ' + route_def +
                            content[insertion_point:]
                        )
                        path.write_text(modified, encoding="utf-8")
                        return ModificationResult(
                            success=True,
                            modified_path=path,
                            changes_made=1
                        )

            return ModificationResult(
                success=False,
                error="Could not find route insertion point"
            )

        except Exception as e:
            return ModificationResult(
                success=False,
                error=f"String-based route injection failed: {str(e)}"
            )


class InjectCallCodemod(JsCodemod):
    """
    Add a function or method call to JavaScript initialization code.
    
    Examples:
        app.use(cors());
        await app.listen(3000);
    """

    def __init__(
        self,
        call_statement: str,
        target_function: Optional[str] = None
    ):
        """
        Args:
            call_statement: Full call statement to inject
            target_function: Function to inject into (e.g., 'main')
        """
        self.call_statement = call_statement
        self.target_function = target_function

    def get_rule(self) -> Optional[Dict]:
        """Return ast-grep rule for call injection."""
        pattern = self.call_statement
        return {
            "rule": pattern,
            "replace": pattern
        }

    def _apply_string_based(self, path: Path) -> ModificationResult:
        """Fallback string-based call injection."""
        try:
            content = path.read_text(encoding="utf-8")

            # Check for duplicate
            if self.call_statement in content:
                return ModificationResult(
                    success=True,
                    modified_path=path,
                    changes_made=0
                )

            # If target function specified, inject into it
            if self.target_function:
                # Simple heuristic: find function and inject before closing brace
                func_pattern = f"function {self.target_function}()"
                if func_pattern in content or f"const {self.target_function} = " in content:
                    # Find the function body
                    start = content.find(func_pattern)
                    if start != -1:
                        # Find opening brace
                        brace_start = content.find('{', start)
                        # Find closing brace (naive)
                        brace_end = content.rfind('}')
                        if brace_end > brace_start:
                            modified = (
                                content[:brace_end] +
                                f"\n  {self.call_statement}\n" +
                                content[brace_end:]
                            )
                            path.write_text(modified, encoding="utf-8")
                            return ModificationResult(
                                success=True,
                                modified_path=path,
                                changes_made=1
                            )

            # If no target, just inject at end
            path.write_text(content + f"\n{self.call_statement}\n", encoding="utf-8")
            return ModificationResult(
                success=True,
                modified_path=path,
                changes_made=1
            )

        except Exception as e:
            return ModificationResult(
                success=False,
                error=f"String-based call injection failed: {str(e)}"
            )


class InjectConstantCodemod(JsCodemod):
    """
    Add a module-level constant or configuration variable to JS/TS.
    
    Examples:
        const API_URL = process.env.API_URL;
        const COLORS = { primary: '#007bff' };
    """

    def __init__(
        self,
        name: str,
        value: str
    ):
        """
        Args:
            name: Constant name (e.g., 'API_URL')
            value: Value expression (e.g., 'process.env.API_URL')
        """
        self.name = name
        self.value = value

    def get_rule(self) -> Optional[Dict]:
        """Return ast-grep rule for constant injection."""
        pattern = f"const {self.name} = {self.value}"
        return {
            "rule": pattern,
            "replace": pattern
        }

    def _apply_string_based(self, path: Path) -> ModificationResult:
        """Fallback string-based constant injection."""
        try:
            content = path.read_text(encoding="utf-8")
            const_stmt = f"const {self.name} = {self.value};"

            # Check for duplicate
            if f"const {self.name}" in content or f"{self.name} =" in content:
                return ModificationResult(
                    success=True,
                    modified_path=path,
                    changes_made=0
                )

            # Insert after imports
            lines = content.split('\n')
            insert_idx = 0

            for i, line in enumerate(lines):
                if line.strip().startswith('import ') or line.strip().startswith('const '):
                    insert_idx = i + 1

            lines.insert(insert_idx, const_stmt)
            path.write_text('\n'.join(lines), encoding="utf-8")

            return ModificationResult(
                success=True,
                modified_path=path,
                changes_made=1
            )

        except Exception as e:
            return ModificationResult(
                success=False,
                error=f"String-based constant injection failed: {str(e)}"
            )
