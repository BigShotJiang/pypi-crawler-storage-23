"""
Base classes for all codemods (configuration modifications).
Provides abstract interface and common utilities for safe transformations.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional
import copy


@dataclass
class ModificationResult:
    """Result of a codemod execution."""
    success: bool
    modified_path: Optional[Path] = None
    error: Optional[str] = None
    changes_made: int = 0
    rollback: bool = False

    def __str__(self) -> str:
        if self.success:
            return f"✓ {self.modified_path.name} ({self.changes_made} changes)"
        else:
            return f"✗ {self.error}"


class BaseCodemod(ABC):
    """Abstract base for all configuration/code modifications."""

    @abstractmethod
    def apply(self, path: Path) -> ModificationResult:
        """
        Apply transformation to file at path.

        Args:
            path: Path to file to modify

        Returns:
            ModificationResult with success status

        Raises:
            FileNotFoundError: If path doesn't exist
            ValueError: If transformation is invalid
        """
        raise NotImplementedError

    def validate(self, before: str, after: str) -> bool:
        """
        Validate transformation was safe.
        Override in subclasses for custom validation.

        Args:
            before: Original file content
            after: Modified file content

        Returns:
            True if transformation is valid
        """
        return True


class TomlTransformer(BaseCodemod):
    """
    Base class for TOML document transformations.
    Uses tomlkit for formatting preservation and safety.
    """

    def apply(self, path: Path) -> ModificationResult:
        """Apply TOML transformation with rollback support."""
        try:
            import tomlkit

            if not path.exists():
                return ModificationResult(
                    success=False,
                    error=f"File not found: {path}"
                )

            # Read original content
            original_content = path.read_text(encoding="utf-8")

            try:
                # Parse TOML document
                doc = tomlkit.parse(original_content)
            except Exception as e:
                return ModificationResult(
                    success=False,
                    error=f"Failed to parse TOML: {str(e)}"
                )

            # Apply transformation
            try:
                doc = self.transform(doc)
            except Exception as e:
                return ModificationResult(
                    success=False,
                    error=f"Transformation failed: {str(e)}"
                )

            # Serialize back
            try:
                modified_content = tomlkit.dumps(doc)
            except Exception as e:
                return ModificationResult(
                    success=False,
                    error=f"Failed to serialize TOML: {str(e)}"
                )

            # Validate
            if not self.validate(original_content, modified_content):
                return ModificationResult(
                    success=False,
                    error="Transformation validation failed"
                )

            # Write to file
            path.write_text(modified_content, encoding="utf-8")

            # Count changes
            changes_made = 1 if modified_content != original_content else 0

            return ModificationResult(
                success=True,
                modified_path=path,
                changes_made=changes_made
            )

        except Exception as e:
            return ModificationResult(
                success=False,
                error=f"{self.__class__.__name__}: {str(e)}",
                rollback=True
            )

    @abstractmethod
    def transform(self, doc: Any) -> Any:
        """
        Transform TOML document.
        Override in subclasses.

        Args:
            doc: tomlkit.Document

        Returns:
            Modified tomlkit.Document
        """
        raise NotImplementedError

    def navigate_path(
        self,
        doc: Any,
        path: list[str],
        create: bool = True
    ) -> Optional[Any]:
        """
        Navigate to nested path in document, optionally creating missing sections.

        Args:
            doc: tomlkit.Document
            path: List like ["tool", "poetry", "dependencies"]
            create: If True, create missing sections

        Returns:
            Value at path, or None if path doesn't exist and create=False
        """
        try:
            import tomlkit

            current = doc
            for key in path:
                if key not in current:
                    if not create:
                        return None
                    current[key] = tomlkit.table()
                current = current[key]

            return current
        except Exception:
            return None


class CodemodPipeline:
    """Execute multiple codemods in sequence with error handling and rollback."""

    def __init__(self) -> None:
        self.codemods: list[BaseCodemod] = []
        self.results: list[ModificationResult] = []

    def add(self, codemod: BaseCodemod) -> "CodemodPipeline":
        """Add codemod to pipeline (fluent API)."""
        self.codemods.append(codemod)
        return self

    def execute(self, path: Path, dry_run: bool = False) -> bool:
        """
        Execute all codemods in sequence.
        Rolls back on any error.

        Args:
            path: Path to file to modify
            dry_run: If True, simulate without writing

        Returns:
            True if all codemods succeeded, False otherwise
        """
        if not path.exists():
            print(f"   ✗ File not found: {path}")
            return False

        # Save original content for rollback
        original_content = path.read_text(encoding="utf-8")

        try:
            for i, codemod in enumerate(self.codemods):
                result = codemod.apply(path)
                self.results.append(result)

                if not result.success:
                    raise RuntimeError(f"Codemod {i+1} failed: {result.error}")

            return True

        except Exception as e:
            # Rollback on error
            if not dry_run:
                path.write_text(original_content, encoding="utf-8")
            print(f"   ✗ Pipeline failed, rolled back: {e}")
            return False

    def get_summary(self) -> str:
        """Get human-readable summary of results."""
        total = len(self.results)
        successful = sum(1 for r in self.results if r.success)
        changes = sum(r.changes_made for r in self.results if r.success)

        return (
            f"Pipeline: {successful}/{total} codemods succeeded, "
            f"{changes} total changes"
        )
