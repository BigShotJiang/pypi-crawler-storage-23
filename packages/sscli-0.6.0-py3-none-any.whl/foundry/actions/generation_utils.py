from pathlib import Path
from rich.panel import Panel
from foundry.constants import console, TIER_HIERARCHY, PRICING_URL
from foundry.telemetry import log_event
from foundry.auth import get_current_license_info

# Re-exports from split modules
from foundry.actions.metadata import (
    inject_metadata,
    validate_and_fix_pyproject,
    disable_linters,
    regenerate_poetry_lock,
    apply_landing_blueprint,
)
from foundry.actions.features import (
    setup_secrets,
    inject_features,
)


def check_tier_access(template_name: str, required_tier: str) -> bool:
    """Check if the user has the required tier for a template.
    
    For ALPHA users, also checks per-template access grants.
    """
    from foundry.utils import is_internal_dev
    if is_internal_dev():
        return True
        
    user_info = get_current_license_info()
    user_tier = user_info.get("tier", "free")
    user_id = user_info.get("user_id")

    # Check tier hierarchy first
    if TIER_HIERARCHY.get(user_tier, 0) < TIER_HIERARCHY.get(required_tier.lower(), 0):
        console.print(
            Panel(
                f"[bold red]Access Denied[/bold red]\n\n"
                f"The template [cyan]{template_name}[/cyan] requires a [bold yellow]{required_tier.upper()}[/bold yellow] license.\n"
                f"Your current tier is: [bold white]{user_tier.upper()}[/bold white].\n\n"
                f"Upgrade your license at: [link={PRICING_URL}]{PRICING_URL}[/link]",
                title="License Requirement",
                border_style="red",
            )
        )
        log_event(
            "GENERATE_FORBIDDEN", f"Template: {template_name}, User Tier: {user_tier}"
        )
        return False
    return True

