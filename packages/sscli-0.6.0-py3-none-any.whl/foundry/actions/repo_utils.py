import shutil
import subprocess
from pathlib import Path
from foundry.auth import get_access_token, get_current_license_info
from foundry.constants import console, TEMPLATES_DIR
from foundry.utils import is_internal_dev
from rich.panel import Panel

def download_template(template_name, template_info, target_path):
    """Clones or copies the template to the target path.

    SECURITY: Re-verifies GitHub auth AND license server membership on every
    download attempt, not just at initial login. Prevents access after revocation.
    """
    # Local template fallback for internal development
    local_template_path = TEMPLATES_DIR / template_name
    if is_internal_dev() and local_template_path.exists():
        console.print("   - Using local template from development environment...")
        try:
            shutil.copytree(local_template_path, target_path, dirs_exist_ok=False)
            return True
        except FileExistsError:
            console.print(f"[red]Error: {target_path.name} already exists![/red]")
            return False
    else:
        # SECURITY: Re-verify GitHub auth + license server membership before download
        license_info = get_current_license_info(verify=True)
        if license_info.get("tier", "free") == "free" and not license_info.get("authorized", False):
            console.print("[red]✗ Access Denied:[/red] Valid license required to download templates.")
            console.print("  Run [bold]sscli login[/bold] to authenticate.")
            return False

        # Remote template: Clone from GitHub with authentication
        repo_url = template_info.get("repo")
        if not repo_url:
            console.print(f"[red]Error: No repository found for template '{template_name}'[/red]")
            return False

        token = get_access_token()
        if not token:
            console.print("[red]✗ GitHub authentication required.[/red] Run [bold]sscli login[/bold].")
            return False
        auth_url = repo_url.replace("https://", f"https://{token}@")

        console.print("   - Downloading template from Seed & Source...")
        result = subprocess.run(
            ["git", "clone", "--depth", "1", auth_url, str(target_path)],
            capture_output=True, text=True
        )

        if result.returncode != 0:
            handle_clone_error(result.stderr)
            return False

        # Remove template git history
        if (target_path / ".git").exists():
            shutil.rmtree(target_path / ".git")
        return True

def initialize_github_repo(target_path: Path, config: dict):
    """Initializes a local git repo and creates a remote on GitHub using 'gh' CLI."""
    repo_name = config.get("name")
    repo_desc = config.get("description")
    repo_vis = config.get("visibility", "private")
    
    console.print(f"   - Initializing GitHub repository: [cyan]{repo_name}[/cyan] ({repo_vis})...")
    
    try:
        # Check if gh is authenticated
        auth_check = subprocess.run(["gh", "auth", "status"], capture_output=True, text=True)
        if auth_check.returncode != 0:
            console.print("   [yellow]⚠️  'gh' CLI is not authenticated. Skipping automatic repository creation.[/yellow]")
            console.print("   [yellow]   Run 'gh auth login' and try again later or manage the repo manually.[/yellow]")
            return False

        # 1. Initialize local git
        subprocess.run(["git", "init", "-b", "main"], cwd=str(target_path), check=True, capture_output=True)
        
        # 2. Add all files
        subprocess.run(["git", "add", "."], cwd=str(target_path), check=True, capture_output=True)
        
        # 3. Initial commit
        subprocess.run(["git", "commit", "-m", "feat: initial bootstrap from Seed & Source"], 
                       cwd=str(target_path), check=True, capture_output=True)
        
        # 4. Create remote repo using gh CLI
        cmd = [
            "gh", "repo", "create", repo_name,
            f"--{repo_vis}",
            "--description", repo_desc,
            "--source", ".",
            "--remote", "origin",
            "--push"
        ]
        
        result = subprocess.run(cmd, cwd=str(target_path), capture_output=True, text=True)
        
        if result.returncode == 0:
            console.print(f"   [green]✓ Successfully created and pushed to GitHub![/green]")
            return True
        else:
            console.print(f"   [red]✗ Failed to create GitHub repository:[/red] {result.stderr.strip()}")
            return False
            
    except Exception as e:
        console.print(f"   [red]✗ Error during GitHub initialization:[/red] {e}")
        return False

def handle_clone_error(stderr):
    """Provides helpful feedback for Git clone failures."""
    console.print("[bold red]Download Error:[/bold red]")
    if "403" in stderr or "401" in stderr:
        console.print(Panel(
            "[bold yellow]Organization Access Required[/bold yellow]\n\n"
            "It looks like your GitHub token doesn't have access to the private repository.\n"
            "1. Go to your [bold]GitHub Settings -> Applications -> Authorized OAuth Apps[/bold].\n"
            "2. Find 'Seed & Source License'.\n"
            "3. Ensure access is [bold]GRANTED[/bold] for the 'seed-source' organization.",
            title="Access Denied", border_style="red"
        ))
    else:
        console.print(f"Error Message: {stderr}")
