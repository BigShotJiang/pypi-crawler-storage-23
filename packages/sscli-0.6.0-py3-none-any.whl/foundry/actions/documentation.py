import questionary
from questionary import Choice
from foundry.constants import TEMPLATES_DIR, console, QUESTIONARY_STYLE
from rich.markdown import Markdown


def run_view_docs(interactive: bool = False):
    docs_path = TEMPLATES_DIR / "docs"
    if not docs_path.exists():
        console.print("[red]No docs folder found![/red]")
        return

    doc_files = list(docs_path.glob("**/*.md")) + list((TEMPLATES_DIR).glob("*.md"))

    if interactive:
        doc_choices = [Choice(f.name, value=f.name, description=f"View {f.name}") for f in doc_files]
        doc_choices.append("Back")
        doc_choice = questionary.select(
            "Select document to view:", 
            choices=doc_choices,
            style=questionary.Style(QUESTIONARY_STYLE)
        ).ask()

        if doc_choice == "Back":
            return

        selected_path = next((f for f in doc_files if f.name == doc_choice), None)
        if selected_path:
            _render_doc(selected_path)
    else:
        # Non-interactive list
        console.print("[bold]Available Documentation:[/bold]")
        for f in doc_files:
            console.print(f" - {f.name} ({f.relative_to(TEMPLATES_DIR)})")


def _render_doc(path):
    with open(path, "r", encoding="utf-8") as f:
        md = Markdown(f.read())
        console.print(md)
