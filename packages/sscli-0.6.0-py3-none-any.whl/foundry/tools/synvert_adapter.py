"""
Synvert Adapter - Python bridge to Synvert Ruby AST transformations

This module provides a bridge between Python stack-cli and Synvert Ruby rewriters.
Synvert is an AST-aware code transformation tool for Ruby, providing robust
alternatives to fragile string-based code injection.

References:
- Synvert: https://synvert.net/
- Repo: https://github.com/synvert-hq/synvert-core-ruby
"""

import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional, Any
from foundry.constants import console


class SynvertAdapter:
    """
    Bridge between Python stack-cli and Synvert Ruby rewriters.
    
    Handles:
    - Ruby environment checking
    - Synvert gem installation verification
    - Inline rewriter execution
    - Output parsing and validation
    """
    
    def __init__(self, project_path: Path):
        """
        Initialize Synvert adapter for a Rails project.
        
        Args:
            project_path: Path to Rails project root
            
        Raises:
            RuntimeError: If Ruby 3.0+ or synvert-core gem not available
        """
        self.project_path = project_path
        self.ruby_version = self._check_ruby()
        self._verify_synvert_gem()
    
    def _check_ruby(self) -> str:
        """
        Check Ruby version and return version string.
        
        Returns:
            Ruby version string (e.g., "ruby 3.2.0")
            
        Raises:
            RuntimeError: If Ruby not installed or too old
        """
        try:
            result = subprocess.run(
                ["ruby", "-v"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode != 0:
                raise RuntimeError("Ruby not installed or not in PATH")
            
            version_str = result.stdout.strip()
            # Parse version: "ruby 3.2.0 (2022-12-25 revision abc123)"
            parts = version_str.split()
            if len(parts) >= 2:
                version_num = parts[1]
                major = int(version_num.split(".")[0])
                if major < 3:
                    raise RuntimeError(
                        f"Ruby 3.0+ required, found {version_num}"
                    )
            
            return version_str
        except FileNotFoundError:
            raise RuntimeError(
                "Ruby not found. Please install Ruby 3.0 or later."
            )
        except Exception as e:
            raise RuntimeError(f"Ruby check failed: {str(e)}")
    
    def _verify_synvert_gem(self) -> None:
        """
        Verify synvert-core gem is installed.
        
        Raises:
            RuntimeError: If gem not installed
        """
        try:
            result = subprocess.run(
                ["gem", "list", "synvert-core"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            if "synvert-core" not in result.stdout:
                console.print(
                    "[yellow]Warning: synvert-core gem not found. "
                    "Installing...[/yellow]"
                )
                # Try to install it
                install_result = subprocess.run(
                    ["gem", "install", "synvert-core", "-q"],
                    capture_output=True,
                    text=True,
                    timeout=60
                )
                
                if install_result.returncode != 0:
                    raise RuntimeError(
                        f"Failed to install synvert-core: "
                        f"{install_result.stderr}"
                    )
        except Exception as e:
            raise RuntimeError(f"Synvert gem verification failed: {str(e)}")
    
    def inline_rewrite(
        self,
        rewriter_code: str,
        file_pattern: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Execute inline Synvert rewriter code against project.
        
        Args:
            rewriter_code: Ruby code defining a Synvert::Rewriter class
            file_pattern: Optional file glob pattern to limit scope
                         (e.g., "routes.rb", "models/*.rb")
        
        Returns:
            Dict with keys:
            - success: bool - Whether transformation succeeded
            - stdout: str - Synvert output
            - stderr: str - Error output if any
            - changed_files: List[str] - Files modified
            - error_message: Optional[str] - Human-readable error
        """
        rewriter_file = self.project_path / ".synvert_tmp_rewriter.rb"
        
        try:
            # Write rewriter to temp file
            rewriter_file.write_text(rewriter_code, encoding="utf-8")
            
            # Build synvert command
            cmd = ["synvert", "--run", str(rewriter_file), "."]
            
            # Execute synvert in project directory
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=str(self.project_path),
                timeout=30
            )
            
            success = result.returncode == 0
            changed_files = self._parse_changed_files(
                result.stdout,
                success
            )
            
            return {
                "success": success,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "changed_files": changed_files,
                "error_message": None if success else result.stderr,
                "rewriter_code": rewriter_code  # Add this for transparency/testing
            }
        
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "stdout": "",
                "stderr": "Synvert execution timed out (>30s)",
                "changed_files": [],
                "error_message": "Synvert execution timed out",
                "rewriter_code": rewriter_code
            }
        
        except Exception as e:
            return {
                "success": False,
                "stdout": "",
                "stderr": str(e),
                "changed_files": [],
                "error_message": f"Synvert execution failed: {str(e)}",
                "rewriter_code": rewriter_code
            }
        
        finally:
            # Clean up temp file
            if rewriter_file.exists():
                try:
                    rewriter_file.unlink()
                except Exception:
                    pass
    
    def _parse_changed_files(self, output: str, success: bool) -> List[str]:
        """
        Parse synvert output to extract changed file paths.
        
        Args:
            output: Synvert stdout/stderr output
            success: Whether synvert execution succeeded
            
        Returns:
            List of file paths that were modified
        """
        changed = []
        
        if not output or not success:
            return changed
        
        # Synvert output patterns:
        # "modify" or "modified" lines typically contain file paths
        for line in output.split("\n"):
            line_lower = line.lower()
            
            # Look for lines with file modifications
            if ("modify" in line_lower or "modified" in line_lower or
                "changed" in line_lower):
                # Extract filename from line
                # Typical formats:
                # "  modify: config/routes.rb"
                # "modify app/models/user.rb"
                parts = line.split()
                for part in parts:
                    if part.endswith(".rb"):
                        changed.append(part.strip())
                        break
        
        return changed
    
    def add_webhook_routes(
        self,
        namespace: str = "webhooks",
        route_specs: Optional[List[tuple]] = None
    ) -> Dict[str, Any]:
        """
        Add webhook namespace to config/routes.rb using Synvert.
        
        Args:
            namespace: Namespace name (e.g., 'webhooks', 'api/v1/webhooks')
            route_specs: List of (method, path, controller) tuples
                        Default: [('post', 'shopify', 'webhooks/shopify#handle')]
        
        Returns:
            Result dict from inline_rewrite()
        """
        if route_specs is None:
            route_specs = [("post", "shopify", "webhooks/shopify#handle")]
        
        # Build routes body
        routes_lines = []
        for method, path, controller in route_specs:
            routes_lines.append(
                f"    {method} '{path}', to: '{controller}'"
            )
        
        routes_body = "\n".join(routes_lines)
        
        # Build Synvert rewriter
        rewriter = f'''
Synvert::Rewriter.new 'rails', 'add_{namespace.replace("/", "_")}_routes' do
  configure parser: Synvert::RUBY_PARSER

  within_files 'config/routes.rb' do
    unless_exist_node '.send [message=namespace] [arguments.first.value={namespace}]' do
      append %{{
  namespace :{namespace} do
{routes_body}
  end
}}
    end
  end
end
'''.strip()
        
        return self.inline_rewrite(rewriter)
    
    def add_model_association(
        self,
        model_name: str,
        association_type: str,
        target: str,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Add association to Rails model using Synvert.
        
        Args:
            model_name: Model class name (e.g., 'Order', 'User')
            association_type: 'has_many', 'belongs_to', 'has_one'
            target: Target association name (e.g., 'items', 'tenant')
            **kwargs: Additional association options
                     (class_name, dependent, foreign_key, etc.)
        
        Returns:
            Result dict from inline_rewrite()
        """
        model_file = model_name[0].lower() + model_name[1:]
        
        # Build association arguments
        assoc_args_parts = []
        for key, value in kwargs.items():
            if value is True:
                assoc_args_parts.append(f"{key}: true")
            elif value is False:
                assoc_args_parts.append(f"{key}: false")
            elif isinstance(value, str):
                assoc_args_parts.append(f"{key}: '{value}'")
            else:
                assoc_args_parts.append(f"{key}: {value}")
        
        assoc_args = ", " + ", ".join(assoc_args_parts) if assoc_args_parts else ""
        
        rewriter = f'''
Synvert::Rewriter.new 'rails', 'add_{association_type}_association' do
  configure parser: Synvert::RUBY_PARSER

  within_files 'app/models/{model_file}.rb' do
    with_node '.class [name={model_name}]' do
      unless_exist_node '.send [message={association_type}] [arguments.first.value=:{target}]' do
        append %{{  {association_type} :{target}{assoc_args}}}
      end
    end
  end
end
'''.strip()
        
        return self.inline_rewrite(rewriter)
    
    def validate_ruby_syntax(self, file_path: Path) -> Dict[str, Any]:
        """
        Validate Ruby file syntax after transformation.
        
        Args:
            file_path: Path to Ruby file to validate
            
        Returns:
            Dict with:
            - valid: bool - Syntax is valid
            - error: str - Error message if invalid
        """
        try:
            result = subprocess.run(
                ["ruby", "-c", str(file_path)],
                capture_output=True,
                text=True,
                timeout=5,
                cwd=str(self.project_path)
            )
            
            return {
                "valid": result.returncode == 0,
                "error": result.stderr if result.returncode != 0 else None
            }
        except Exception as e:
            return {
                "valid": False,
                "error": str(e)
            }
