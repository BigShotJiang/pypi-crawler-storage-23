"""
Feature Isolation Workspace Engine
Creates focused workspaces showing only relevant files for a specific feature.
"""

import json
import os
import shutil
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime
from dataclasses import dataclass
from foundry.constants import console, FOUNDRY_ROOT


@dataclass
class WorkspaceMetadata:
    """Metadata for a feature workspace."""
    feature_name: str
    template_name: str
    base_template_path: str
    created_at: str
    workspace_root: str
    injected_paths: List[Dict[str, str]]  # {"original_path": str, "workspace_path": str}
    description: Optional[str] = None


def create_feature_workspace(
    feature_name: str,
    template_name: str,
    output_path: str,
    description: Optional[str] = None,
    include_tests: bool = True,
    include_docs: bool = True,
) -> Dict:
    """
    Create an isolated workspace showing only relevant files for a feature.
    
    Args:
        feature_name: Name of the feature (e.g., 'commerce', 'tunnel')
        template_name: Template type (python-saas, rails-api, react-client, static-landing)
        output_path: Where to create the workspace
        description: Optional description of the workspace
        include_tests: Include test files related to the feature
        include_docs: Include documentation files
    
    Returns:
        Dict with workspace creation details and status
    """
    
    output_path = Path(output_path).resolve()
    
    # Get feature directory
    feature_path = _infer_feature_path(template_name, feature_name)
    if not feature_path or not Path(feature_path).exists():
        return {
            "success": False,
            "error": f"Feature not found: {feature_name} for {template_name}",
            "feature_name": feature_name,
            "template_name": template_name,
        }
    
    feature_path = Path(feature_path)
    
    # Get template directory
    template_path = _infer_template_path(template_name)
    if not template_path or not Path(template_path).exists():
        return {
            "success": False,
            "error": f"Base template not found: {template_name}",
            "template_name": template_name,
        }
    
    template_path = Path(template_path)
    
    # Create output directory
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Collect relevant files from feature
    injected_paths = []
    file_count = 0
    
    for feature_file in feature_path.rglob("*"):
        if not feature_file.is_file() or _should_skip_workspace_file(feature_file):
            continue
        
        # Get relative path within feature
        rel_path = feature_file.relative_to(feature_path)
        
        # Create mirrored structure in workspace
        workspace_file = output_path / rel_path
        workspace_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Copy file with annotation
        try:
            _copy_file_with_annotation(feature_file, workspace_file, "feature")
            
            injected_paths.append({
                "original_path": str(feature_file.relative_to(feature_path)),
                "workspace_path": str(workspace_file.relative_to(output_path)),
                "size": feature_file.stat().st_size,
                "type": "feature",
            })
            
            file_count += 1
        except Exception as e:
            console.print(f"[yellow]Warning: Could not copy {rel_path}: {e}[/yellow]")
    
    # Include template context files (README, config)
    context_files = [
        "README.md",
        "pyproject.toml",
        "package.json",
        "Gemfile",
        "Dockerfile",
        "docker-compose.override.yml",
    ]
    
    for context_file in context_files:
        src = template_path / context_file
        if src.exists():
            dst = output_path / f".template-context-{context_file}"
            try:
                _copy_file_with_annotation(src, dst, "template-context")
                injected_paths.append({
                    "original_path": str(context_file),
                    "workspace_path": str(dst.relative_to(output_path)),
                    "type": "template-context",
                    "note": "Template context file (read-only for reference)",
                })
            except Exception as e:
                console.print(f"[yellow]Warning: Could not copy context file {context_file}: {e}[/yellow]")
    
    # Create metadata file
    metadata = {
        "workspace_id": f"{feature_name}-{template_name}-{int(datetime.now().timestamp())}",
        "feature_name": feature_name,
        "template_name": template_name,
        "base_template_path": str(template_path),
        "feature_path": str(feature_path),
        "created_at": datetime.now().isoformat(),
        "description": description or f"Feature workspace for {feature_name} in {template_name}",
        "files_included": file_count,
        "injected_paths": injected_paths,
        "include_tests": include_tests,
        "include_docs": include_docs,
    }
    
    metadata_file = output_path / ".feature-workspace.json"
    metadata_file.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    
    # Create a README for the workspace
    _create_workspace_readme(output_path, feature_name, template_name, metadata)
    
    return {
        "success": True,
        "workspace_path": str(output_path),
        "feature_name": feature_name,
        "template_name": template_name,
        "files_created": file_count,
        "metadata": metadata,
        "metadata_file": str(metadata_file),
    }


def list_workspaces(search_path: Optional[str] = None) -> Dict:
    """
    List all known feature workspaces in the filesystem.
    
    Args:
        search_path: Directory to search (defaults to current directory and subdirectories)
    
    Returns:
        Dict with list of found workspaces and their metadata
    """
    search_path = Path(search_path or ".").resolve()
    workspaces = []
    
    # Search for .feature-workspace.json files
    for metadata_file in search_path.rglob(".feature-workspace.json"):
        try:
            metadata = json.loads(metadata_file.read_text(encoding="utf-8"))
            workspaces.append({
                "path": str(metadata_file.parent),
                "workspace_id": metadata.get("workspace_id"),
                "feature_name": metadata.get("feature_name"),
                "template_name": metadata.get("template_name"),
                "created_at": metadata.get("created_at"),
                "files_included": metadata.get("files_included"),
                "description": metadata.get("description"),
            })
        except Exception as e:
            console.print(f"[yellow]Warning: Could not read workspace metadata: {e}[/yellow]")
    
    return {
        "success": True,
        "search_path": str(search_path),
        "workspaces_found": len(workspaces),
        "workspaces": sorted(workspaces, key=lambda w: w.get("created_at", ""), reverse=True),
    }


def _infer_template_path(template_name: str) -> Optional[str]:
    """Infer path to base template from template name."""
    if not template_name:
        return None
    
    foundry_root = Path(FOUNDRY_ROOT)
    
    possible_paths = [
        foundry_root / "templates" / template_name,
        foundry_root.parent / template_name,
    ]
    
    for path in possible_paths:
        if path.exists():
            return str(path)
    
    return None


def _infer_feature_path(template_name: str, feature_name: str) -> Optional[str]:
    """Infer path to feature directory."""
    foundry_root = Path(FOUNDRY_ROOT)
    
    possible_paths = [
        foundry_root / "features" / feature_name / template_name,
        foundry_root / "features" / feature_name,
        foundry_root.parent / "features" / feature_name,
    ]
    
    for path in possible_paths:
        if path.exists():
            return str(path)
    
    return None


def _should_skip_workspace_file(file_path: Path) -> bool:
    """Check if file should be skipped when copying to workspace."""
    skip_dirs = {
        ".git",
        "__pycache__",
        ".pytest_cache",
        "node_modules",
        "venv",
        "build",
        "dist",
    }
    
    skip_files = {
        ".env",
        ".env.local",
        ".gitignore",
    }
    
    return (
        any(part in skip_dirs for part in file_path.parts)
        or file_path.name in skip_files
        or file_path.suffix in {".pyc", ".class"}
    )


def _copy_file_with_annotation(src: Path, dst: Path, annotation_type: str):
    """Copy file and optionally add annotation."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    
    # For most file types, just copy
    if src.suffix in {".json", ".yaml", ".yml", ".toml", ".env"}:
        shutil.copy2(src, dst)
    else:
        shutil.copy2(src, dst)


def _create_workspace_readme(
    workspace_path: Path,
    feature_name: str,
    template_name: str,
    metadata: Dict,
):
    """Create a README file in the workspace."""
    readme_content = f"""# Feature Isolation Workspace: {feature_name}

This is a focused development workspace showing only the relevant files for the **{feature_name}** feature in the **{template_name}** template.

## Overview

- **Feature**: {feature_name}
- **Template**: {template_name}
- **Created**: {metadata.get('created_at')}
- **Files Included**: {metadata.get('files_included')}
- **Workspace ID**: {metadata.get('workspace_id')}

## Description

{metadata.get('description', 'No description provided.')}

## Files in This Workspace

The following files are from the feature:

"""
    
    for path_info in metadata.get('injected_paths', []):
        if path_info.get('type') == 'feature':
            readme_content += f"- `{path_info.get('workspace_path')}`\n"
    
    readme_content += f"""

## Template Context Files

The following files are included for reference from the base template:

"""
    
    for path_info in metadata.get('injected_paths', []):
        if path_info.get('type') == 'template-context':
            readme_content += f"- `.template-context-{path_info.get('original_path')}`\n"
    
    readme_content += f"""

## Metadata

For detailed workspace configuration, see `.feature-workspace.json`.

## Next Steps

1. Review the feature files to understand the structure
2. Compare with the base template context files
3. Use `sscli diff --project-path . --feature {feature_name}` to see integration points
4. Test the feature in the full project context using the main template

## Related Commands

```bash
# Use diff to see how this feature integrates
sscli diff --project-path /path/to/full-project --feature {feature_name}

# List other feature workspaces
sscli workspace list

# Create a feature workspace for a different feature
sscli workspace create --feature <name> --template {template_name}
```

---
Generated with Seed & Source CLI (sscli)
"""
    
    (workspace_path / "WORKSPACE_README.md").write_text(readme_content, encoding="utf-8")
