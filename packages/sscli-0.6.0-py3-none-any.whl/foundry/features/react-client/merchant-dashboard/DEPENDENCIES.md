# Merchant Dashboard - Dependencies

## Core Dependencies

The Merchant Dashboard requires the following packages to be installed in your React project:

### Required Packages
- **React** 18.0.0+ - Core React library
- **React Router** 6.0.0+ - Client-side routing
- **React Query** 3.0.0+ (or TanStack Query 4.0.0+) - Server state management & caching
- **Tailwind CSS** 3.0.0+ - Utility-first CSS framework
- **axios** - HTTP client for API requests

### Optional Enhancements
- **recharts** - For advanced dashboard analytics visualizations
- **framer-motion** - For smooth animations and transitions
- **zustand** - For lightweight client state management

## Installation

If your React project was generated with `sscli new react-client`, these dependencies are pre-installed.

To verify installation:
```bash
npm list react react-router-dom react-query tailwindcss axios
```

## Environment Variables

Set these in your `.env` file:

```
VITE_API_BASE_URL=http://localhost:3000/api/v1
VITE_DASHBOARD_ENABLED=true
```

## Backend Requirements

The Merchant Dashboard integrates with your backend API. Ensure the following endpoints are implemented:

- **GET** `/api/v1/orders` - Retrieve paginated orders
- **GET** `/api/v1/merchant/stats` - Get analytics metrics
- **GET** `/api/v1/webhooks/activity` - Retrieve webhook audit log
- **GET** `/api/v1/merchant/config` - Get merchant settings
- **POST** `/api/v1/merchant/config` - Update merchant settings

See PHASE_1_AUDIT_REPORT.md for detailed endpoint specifications.
