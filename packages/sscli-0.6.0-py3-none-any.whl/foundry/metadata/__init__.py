"""
Metadata tracking system for Seed & Source CLI.

This module provides tools for tracking project metadata, including template
version, sscli version, features enabled, and user modifications.
"""

from foundry.metadata.metadata_tracker import (
    ProjectMetadata,
    MetadataTracker,
    UpgradeRecord,
    ModificationRecord,
)

__all__ = [
    "ProjectMetadata",
    "MetadataTracker",
    "UpgradeRecord",
    "ModificationRecord",
]
