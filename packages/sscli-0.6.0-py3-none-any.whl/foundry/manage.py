import os
from dotenv import load_dotenv
from foundry.cli import app

# Load environment variables from .env file if it exists
load_dotenv()

if __name__ == "__main__":
    app()
