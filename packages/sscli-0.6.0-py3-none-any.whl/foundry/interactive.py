import questionary
from questionary import Choice
from foundry.actions.explore import run_explore
from foundry.actions.generator import run_generator
from foundry.actions.validation import run_smoke_tests
from foundry.actions.account_info import account_info_menu
from foundry.actions.development import dev_tools_menu
from foundry.auth import get_current_license_info, login_flow
from foundry.constants import console, QUESTIONARY_STYLE
from foundry.animations.assets import FOUNDRY_BANNER
from foundry.utils import is_internal_dev
from foundry.interactive_utils import manage_config_menu, pause


# Animation Imports - only for animated experience command
try:
    from foundry.animations import InteractiveAnimationEngine
    HAS_ANIMATIONS = True
except Exception:
    HAS_ANIMATIONS = False


def run_animated_experience():
    """Proxy to the actual animated experience implementation."""
    from foundry.animated_experience import run_animated_experience as _run
    _run()


def interactive_menu():
    """Interactive menu with animated logo and synchronized auth checking."""
    
    # Try to show animated logo intro
    if HAS_ANIMATIONS:
        try:
            from foundry.animations import (AnimationSequence, InteractiveAnimationEngine)
            from foundry.animations.scenes import (LogoRevealAnimation,
                                                   LogoStaticAnimation,
                                                   LogoDisperseAnimation)
            from typing import cast, List
            from foundry.animations.base import Animation
            
            engine = InteractiveAnimationEngine(fps=60, console=console)
            
            # Play intro animation sequence
            try:
                intro = AnimationSequence(
                    cast(List[Animation], [
                        LogoRevealAnimation(duration=1.2),
                        LogoStaticAnimation(duration=1.0),
                        LogoDisperseAnimation(duration=2.0),
                    ])
                )
                engine.play(intro)
            except KeyboardInterrupt:
                console.print("[yellow]Goodbye![/yellow]")
                return
            except Exception:
                # Fallback to static banner if animation fails
                console.print(FOUNDRY_BANNER)
        except Exception:
            # Animations not available, show static banner
            console.print(FOUNDRY_BANNER)
    else:
        # Animations not available, show static banner
        console.print(FOUNDRY_BANNER)
    
    # Get current auth info
    auth_info = get_current_license_info()

    while True:
        # Build menu choices based on auth status
        base_choices = [
            Choice("🔍 Explore Templates", value="explore"),
            Choice("✨ Generate New Project", value="generate"),
            Choice("⚙️  Manage Stack Configuration", value="config"),
            Choice("� Observability & Insights", value="observability"),
            Choice("🧪 Feature Verification & Testing", value="verification"),
            Choice("�🔍 Run System Validation (Smoke Tests)", value="validation"),
        ]

        # Add development tools only in internal dev mode
        if is_internal_dev():
            base_choices.append(Choice("🛠️  Development Tools", value="dev_tools"))

        # Add auth option if not authenticated
        if auth_info.get("tier") == "free":
            base_choices.insert(0, Choice("🔐 Login to Unlock PRO Features", value="login"))
        else:
            base_choices.insert(0, Choice(f"👤 Account ({auth_info.get('tier', 'free').upper()})", value="account"))

        base_choices.append("Exit")

        choice = questionary.select(
            "What would you like to do?",
            choices=base_choices,
            style=questionary.Style(QUESTIONARY_STYLE)
        ).ask()
        
        # Map choice values back to original strings for handler logic
        if choice == "explore":
            choice = "Explore Templates"
        elif choice == "generate":
            choice = "Generate New Project"
        elif choice == "config":
            choice = "Manage Stack Configuration"
        elif choice == "observability":
            choice = "Observability & Insights"
        elif choice == "verification":
            choice = "Feature Verification & Testing"
        elif choice == "validation":
            choice = "Run System Validation (Smoke Tests)"
        elif choice == "dev_tools":
            choice = "Development Tools"
        elif choice == "login":
            choice = "🔐 Login to Unlock PRO Features"
        elif choice == "account":
            choice = f"👤 Account ({auth_info.get('tier', 'free').upper()})"

        if choice == "🔐 Login to Unlock PRO Features":
            try:
                if login_flow():
                    # Refresh auth info after login
                    auth_info = get_current_license_info()
                    console.print("\n[green]✓ Authentication successful![/green]\n")
                else:
                    console.print("\n[yellow]⚠️  Authentication was not completed.[/yellow]\n")
            except Exception as e:
                console.print(f"\n[red]✗ Authentication failed:[/red] {e}\n")
        elif choice == f"👤 Account ({auth_info.get('tier', 'free').upper()})":
            # Show account info with refresh/logout options
            logged_out = not account_info_menu(auth_info)
            if logged_out:
                # User logged out, restart the menu
                auth_info = get_current_license_info()
                continue
        elif choice == "Explore Templates":
            run_explore()
            pause()
        elif choice == "Generate New Project":
            run_generator()
            pause()
        elif choice == "Observability & Insights":
            from foundry.actions.observability_interactive import observability_menu
            observability_menu()
            pause()
        elif choice == "Feature Verification & Testing":
            from foundry.actions.verification_interactive import verification_menu
            verification_menu()
            pause()
        elif choice == "Manage Stack Configuration":
            manage_config_menu()
        elif choice == "Run System Validation (Smoke Tests)":
            run_smoke_tests()
            pause()
        elif choice == "Development Tools":
            dev_tools_menu()

        else:
            console.print("[yellow]Goodbye![/yellow]")
            break

