"""Git hook installation for gjalla."""

from .installer import (
    install_hook,
    install_post_commit_hook,
    install_hooks,
    is_gjalla_installed,
    HookInstallResult,
    HooksInstallResult,
    InstallStatus,
)

__all__ = [
    "install_hook",
    "install_post_commit_hook",
    "install_hooks",
    "is_gjalla_installed",
    "HookInstallResult",
    "HooksInstallResult",
    "InstallStatus",
]
