import importlib


settings_module = importlib.import_module("gjalla_precommit.config.settings")


def test_settings_load_no_args(home_dir):
    settings = settings_module.Settings.load()
    assert settings.api_url == "https://gjalla.io"
    assert settings.api_key == ""
