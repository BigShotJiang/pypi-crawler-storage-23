"""Platform-specific Gasoline binary for win32-x64."""

__version__ = "0.7.8"
