from dataclasses import dataclass, asdict
from enum import Enum


class AcqState(Enum):
    """Enumeration for acquisition state.
    
    Attributes:
        ADDED (int): Acquisition has been added to server but is not
            configured yet.
        CONFIGURED (int): Acquisition has been configured and is ready
            to be started.
        RUNNING (int): Acquisition is running.
        STOP (int): Acquisition has been stopped because:
        
            - Expected number of samples have been acquired or
            - User stopped it before completion.
        ERROR (int): An error occured during acquisition, error property
            of status shall give more information.
    """
    ADDED       = 0
    CONFIGURED  = 1
    RUNNING     = 2
    STOP        = 3
    ERROR       = 4
    
class AcqError(Enum):
    """Enumeration for acquisition error.
    
    Attributes:
        NONE (int): No error.
        TOO_MUCH_MISSED (int): In case of filter counter, too much
            missed samples have been detected.
        XCP_CONN_LOST (int): XCP connection has been lost between the
            DAnCE server (acting as XCP master) and the XCP slave.
    """
    NONE            = 0
    TOO_MUCH_MISSED = 1
    XCP_CONN_LOST   = 2

@dataclass(frozen=True)
class AcqStatus:
    """Acquisition status.
    
    Attributes:
        state (AcqState): Acquisition state.
        error (AcqError): Acquisition error if any.
        total_samples (int): Total number of samples received by server.
        overflow_samples (int): Number of samples dropped after queue
            has been filled.
        start_left_samples (int): Number of samples dropped before
            starting to keep them.
        filtered_out_samples (int): Number of samples dropped by filter.
        missed_samples (int): Number of samples detected as unsent by
            device.
        potential_loss (int): Tell if some sent samples may have not
            reach the server.
    """
    
    state: AcqState
    error: AcqError
    total_samples: int
    overflow_samples: int
    start_left_samples: int
    filtered_out_samples: int
    missed_samples: int
    potential_loss: bool
