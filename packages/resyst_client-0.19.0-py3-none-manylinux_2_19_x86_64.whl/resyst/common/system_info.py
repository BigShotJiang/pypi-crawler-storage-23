from dataclasses import dataclass

@dataclass(frozen=True)
class SystemInfo:
    """System information

    Attributes:
        free_memory (int): Free memory in MB.
        serial_number (str): serial number of the Real-Time device.
    """

    free_memory: int
    serial_number: str
