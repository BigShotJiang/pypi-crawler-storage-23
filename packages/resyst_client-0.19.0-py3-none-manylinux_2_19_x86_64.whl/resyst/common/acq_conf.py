from dataclasses import dataclass
from typing import Optional
from enum import Enum


class FilterAction(Enum):
    """Enumeration for filter action. When boolean filter signal is set
    in acquisition cnofiguration, only SKIP action is allowed. When
    uint32 counter signal is set, all enumeration are allowed and
    determine what server shall do in case of detected missed
    samples.
    
    Attributes:
        SKIP (int): Detected missed sample is simply skipped.
        EMPTY (int): Detected missed sample is replaced by an empty
            sample (0 for numeric value and empty string).
        BAD (int): Detected missed sample is replaced by an bad sample
            (NaN for numeric value, max value for integer type and empty
            string).
        PREV (int): Detected missed sample is replaced by previous valid
            sample.
        NEXT (int): Detected missed sample is replaced by next valid
        sample.
    """
    SKIP    = 0
    EMPTY   = 1
    BAD     = 2
    PREV    = 3
    NEXT    = 4

@dataclass(frozen=True)
class AcqConf:
    """Acquisition configuration.
    
    Attributes:
        name (str): Name of the acquisition.
        signal_paths (list[str]): Signal paths from which to acquire
            values.
        nbp (int): Number of samples to acquire.
        stream (bool): Tell if continue acquisition when queue is full
            (True) or not (False).
        decimation (int): Decimation of acquisition, 1 meaning get all
            sample.
        filter_path (Optional[str]): Filter signal path for filtering
            samples. If a boolean signal is given, non-zero value tells
            server to keep the sample, if uint32 counter signal is
            given, increment of one tells server to keep the sample and
            higher increment tell the server to replace the missed
            sample according to this configuration filter_action.
            Increment higher strictly higher than 4 puts the acquisition
            in TOO_MUCH_MISSED error and stops it.
        start_path (Optional[str]): Start signal path for starting
            keeping samples.
        start_pre_samples (int): Number of already acquired sample to
            keep when start is triggered.
        filter_action (FilterAction): Filter action tell what to do when
            sample are detected as missed, check enumeration
            documentation for details.
    """

    name: str
    signal_paths: list[str]
    nbp: int = 100000
    decimation: int = 1
    stream: bool = False
    filter_path: Optional[str] = None
    start_path: Optional[str] = None
    start_pre_samples: int = 0
    filter_action: FilterAction = FilterAction.SKIP

    def to_strs(self):
        stream_str = 'STREAM ' if self.stream else ''
        strs = [
            'SRC ' + ' '.join([f'"{x}"' for x in self.signal_paths]),
            f'NSAMPLES {stream_str}{self.nbp}',
            f'SAMPLRATE {self.decimation}'
        ]
        if self.filter_path is not None:
            strs.append(
                f'FILTER {self.filter_action.name}'
                f' "{self.filter_path}"')
        if self.filter_path is not None:
            strs.append(
                f'START "{self.start_path}" {self.start_pre_samples}')
        return strs
