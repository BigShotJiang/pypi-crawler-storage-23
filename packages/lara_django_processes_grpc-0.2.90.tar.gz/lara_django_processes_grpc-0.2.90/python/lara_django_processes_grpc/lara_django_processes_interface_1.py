"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_processes high_level_interface *

:details: lara_django_processes high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_processes
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: - 
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_processes_grpc.v1.lara_django_processes_pb2 as lara_django_processes_pb2
import lara_django_processes_grpc.v1.lara_django_processes_pb2_grpc as lara_django_processes_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, export_file, import_file, id_cache, update_image

import  lara_django_processes_grpc.lara_django_processes_data_model as processes_dm 



#_________________  ExtraData  ______________________


class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_processes_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )
        
        self.extradata_client = lara_django_processes_pb2_grpc.ExtraDataControllerStub(channel)

        # self.extradata_full_client = lara_django_processes_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  extradata:  list[processes_dm.ExtraData] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[processes_dm.ExtraData]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # extradataclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_processes_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving extradataclass_id: {e}")
        # for extradata in extradatas:
        #     extradata.namespace = self.namespace_id
        #     extradata.extradata_class = extradataclass_id

        try:
            create_coroutines = ( self.extradata_client.Create(lara_django_processes_pb2.ExtraDataRequest(**extradata.model_dump())) for extradata in extradata )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.extradata_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating extradata: {e}")

    @export_file
    async def retrieve(
        self, 
        extradata_id: str = None,
        extradata_name: str = None,
        #extradata_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ExtraData]:
        filter_list = []
        results_list = []
        if  extradata_id is not None:
            try:
                res =  await self.extradata_client.Retrieve(
                    lara_django_processes_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving extradata_id: {e}")

        if extradata_name is not None:
            filter_list.append({"name": extradata_name})
        # if extradata_name_full is not None:
        #     filter_list.append({"name_full": extradata_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.extradata_client.List(
                        lara_django_processes_pb2.ExtraDataListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ processes_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving extradata_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          extradata_name: str = None,
                          extradata_name_full: str = None,
                          iri: str = None,) -> str:
        if extradata_name is not None:
            filter_dict = {"name": extradata_name}
        elif extradata_name_full is not None:
            filter_dict = {"name_full": extradata_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.extradata_client.List(
                    lara_django_processes_pb2.ExtraDataListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving extradata_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].extradata_id
            else:
                raise ValueError(f"Error retrieving extradata_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_processes_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(
                lara_django_processes_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(
                lara_django_processes_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_processes_pb2.ExtraDataFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, extradata : processes_dm.ExtraData = None) -> None:
        try:
            await self.extradata_client.Update(
                lara_django_processes_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating extradata_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.extradata_client.Destroy(lara_django_processes_pb2.ExtraDataDestroyRequest(extradata_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting extradata_id: {e}")

#_________________  MethodClass  ______________________


class MethodClassInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.methodclass_class_client = (
        #     lara_django_processes_pb2_grpc.MethodclassclassByIRIControllerStub(channel)
        # )
        
        self.methodclass_client = lara_django_processes_pb2_grpc.MethodclassControllerStub(channel)

        # self.methodclass_full_client = lara_django_processes_pb2_grpc.MethodclassFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  methodclasses:  list[processes_dm.MethodClass] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[processes_dm.MethodClass]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # methodclassclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if methodclass_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.methodclass_class_client.Retrieve(
        #         lara_django_processes_pb2.MethodclassclassRetrieveRequest(iri=methodclass_class_iri)
        #     )
        #     methodclassclass_id = res.methodclassclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving methodclassclass_id: {e}")
        # for methodclass in methodclasss:
        #     methodclass.namespace = self.namespace_id
        #     methodclass.methodclass_class = methodclassclass_id

        try:
            create_coroutines = ( self.methodclass_client.Create(lara_django_processes_pb2.MethodclassRequest(**methodclass.model_dump())) for methodclass in methodclasses )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.methodclass_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating methodclass: {e}")

    @export_file
    async def retrieve(
        self, 
        methodclass_id: str = None,
        methodclass_name: str = None,
        #methodclass_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.MethodClass]:
        filter_list = []
        results_list = []
        if  methodclass_id is not None:
            try:
                res =  await self.methodclass_client.Retrieve(
                    lara_django_processes_pb2.MethodclassRetrieveRequest(methodclass_id=methodclass_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.MethodClass(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving methodclass_id: {e}")

        if methodclass_name is not None:
            filter_list.append({"name": methodclass_name})
        # if methodclass_name_full is not None:
        #     filter_list.append({"name_full": methodclass_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.methodclass_client.List(
                        lara_django_processes_pb2.MethodclassListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ processes_dm.MethodClass(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving methodclass_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          methodclass_name: str = None,
                          methodclass_name_full: str = None,
                          iri: str = None,) -> str:
        if methodclass_name is not None:
            filter_dict = {"name": methodclass_name}
        elif methodclass_name_full is not None:
            filter_dict = {"name_full": methodclass_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.methodclass_client.List(
                    lara_django_processes_pb2.MethodclassListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving methodclass_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].methodclass_id
            else:
                raise ValueError(f"Error retrieving methodclass_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.methodclass_client.List(lara_django_processes_pb2.MethodclassListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.methodclass_client.List(
                lara_django_processes_pb2.MethodclassListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.methodclass_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.methodclass_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.methodclass_full_client.List(
                lara_django_processes_pb2.MethodclassFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.methodclass_full_client.List(
                lara_django_processes_pb2.MethodclassFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, methodclass : processes_dm.MethodClass = None) -> None:
        try:
            await self.methodclass_client.Update(
                lara_django_processes_pb2.MethodclassRequest(**methodclass.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating methodclass_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.methodclass_client.Destroy(lara_django_processes_pb2.MethodclassDestroyRequest(methodclass_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting methodclass_id: {e}")

#_________________  Method  ______________________


class MethodInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.method_class_client = (
        #     lara_django_processes_pb2_grpc.MethodclassByIRIControllerStub(channel)
        # )
        
        self.method_client = lara_django_processes_pb2_grpc.MethodControllerStub(channel)

        # self.method_full_client = lara_django_processes_pb2_grpc.MethodFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  methods:  list[processes_dm.Method] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[processes_dm.Method]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # methodclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if method_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.method_class_client.Retrieve(
        #         lara_django_processes_pb2.MethodclassRetrieveRequest(iri=method_class_iri)
        #     )
        #     methodclass_id = res.methodclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving methodclass_id: {e}")
        # for method in methods:
        #     method.namespace = self.namespace_id
        #     method.method_class = methodclass_id

        try:
            create_coroutines = ( self.method_client.Create(lara_django_processes_pb2.MethodRequest(**method.model_dump())) for method in methods )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.method_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating method: {e}")

    @export_file
    async def retrieve(
        self, 
        method_id: str = None,
        method_name: str = None,
        #method_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.Method]:
        filter_list = []
        results_list = []
        if  method_id is not None:
            try:
                res =  await self.method_client.Retrieve(
                    lara_django_processes_pb2.MethodRetrieveRequest(method_id=method_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.Method(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving method_id: {e}")

        if method_name is not None:
            filter_list.append({"name": method_name})
        # if method_name_full is not None:
        #     filter_list.append({"name_full": method_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.method_client.List(
                        lara_django_processes_pb2.MethodListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ processes_dm.Method(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving method_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          method_name: str = None,
                          method_name_full: str = None,
                          iri: str = None,) -> str:
        if method_name is not None:
            filter_dict = {"name": method_name}
        elif method_name_full is not None:
            filter_dict = {"name_full": method_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.method_client.List(
                    lara_django_processes_pb2.MethodListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving method_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].method_id
            else:
                raise ValueError(f"Error retrieving method_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.method_client.List(lara_django_processes_pb2.MethodListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.method_client.List(
                lara_django_processes_pb2.MethodListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.method_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.method_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.method_full_client.List(
                lara_django_processes_pb2.MethodFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.method_full_client.List(
                lara_django_processes_pb2.MethodFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, method : processes_dm.Method = None) -> None:
        try:
            await self.method_client.Update(
                lara_django_processes_pb2.MethodRequest(**method.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating method_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.method_client.Destroy(lara_django_processes_pb2.MethodDestroyRequest(method_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting method_id: {e}")

#_________________  Procedure  ______________________


class ProcedureInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.procedure_class_client = (
        #     lara_django_processes_pb2_grpc.ProcedureclassByIRIControllerStub(channel)
        # )
        
        self.procedure_client = lara_django_processes_pb2_grpc.ProcedureControllerStub(channel)

        # self.procedure_full_client = lara_django_processes_pb2_grpc.ProcedureFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  procedures:  list[processes_dm.Procedure] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[processes_dm.Procedure]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # procedureclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if procedure_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.procedure_class_client.Retrieve(
        #         lara_django_processes_pb2.ProcedureclassRetrieveRequest(iri=procedure_class_iri)
        #     )
        #     procedureclass_id = res.procedureclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving procedureclass_id: {e}")
        # for procedure in procedures:
        #     procedure.namespace = self.namespace_id
        #     procedure.procedure_class = procedureclass_id

        try:
            create_coroutines = ( self.procedure_client.Create(lara_django_processes_pb2.ProcedureRequest(**procedure.model_dump())) for procedure in procedures )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.procedure_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating procedure: {e}")

    @export_file
    async def retrieve(
        self, 
        procedure_id: str = None,
        procedure_name: str = None,
        #procedure_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.Procedure]:
        filter_list = []
        results_list = []
        if  procedure_id is not None:
            try:
                res =  await self.procedure_client.Retrieve(
                    lara_django_processes_pb2.ProcedureRetrieveRequest(procedure_id=procedure_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.Procedure(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving procedure_id: {e}")

        if procedure_name is not None:
            filter_list.append({"name": procedure_name})
        # if procedure_name_full is not None:
        #     filter_list.append({"name_full": procedure_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.procedure_client.List(
                        lara_django_processes_pb2.ProcedureListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ processes_dm.Procedure(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving procedure_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          procedure_name: str = None,
                          procedure_name_full: str = None,
                          iri: str = None,) -> str:
        if procedure_name is not None:
            filter_dict = {"name": procedure_name}
        elif procedure_name_full is not None:
            filter_dict = {"name_full": procedure_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.procedure_client.List(
                    lara_django_processes_pb2.ProcedureListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving procedure_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].procedure_id
            else:
                raise ValueError(f"Error retrieving procedure_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.procedure_client.List(lara_django_processes_pb2.ProcedureListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.procedure_client.List(
                lara_django_processes_pb2.ProcedureListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.procedure_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.procedure_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.procedure_full_client.List(
                lara_django_processes_pb2.ProcedureFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.procedure_full_client.List(
                lara_django_processes_pb2.ProcedureFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, procedure : processes_dm.Procedure = None) -> None:
        try:
            await self.procedure_client.Update(
                lara_django_processes_pb2.ProcedureRequest(**procedure.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating procedure_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.procedure_client.Destroy(lara_django_processes_pb2.ProcedureDestroyRequest(procedure_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting procedure_id: {e}")

#_________________  Process  ______________________


class ProcessInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.process_class_client = (
        #     lara_django_processes_pb2_grpc.ProcessclassByIRIControllerStub(channel)
        # )
        
        self.process_client = lara_django_processes_pb2_grpc.ProcessControllerStub(channel)

        # self.process_full_client = lara_django_processes_pb2_grpc.ProcessFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  processes:  list[processes_dm.Process] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[processes_dm.Process]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # processclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if process_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.process_class_client.Retrieve(
        #         lara_django_processes_pb2.ProcessclassRetrieveRequest(iri=process_class_iri)
        #     )
        #     processclass_id = res.processclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving processclass_id: {e}")
        # for process in processs:
        #     process.namespace = self.namespace_id
        #     process.process_class = processclass_id

        try:
            create_coroutines = ( self.process_client.Create(lara_django_processes_pb2.ProcessRequest(**process.model_dump())) for process in processes )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.process_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating process: {e}")

    @export_file
    async def retrieve(
        self, 
        process_id: str = None,
        process_name: str = None,
        #process_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.Process]:
        filter_list = []
        results_list = []
        if  process_id is not None:
            try:
                res =  await self.process_client.Retrieve(
                    lara_django_processes_pb2.ProcessRetrieveRequest(process_id=process_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.Process(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving process_id: {e}")

        if process_name is not None:
            filter_list.append({"name": process_name})
        # if process_name_full is not None:
        #     filter_list.append({"name_full": process_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.process_client.List(
                        lara_django_processes_pb2.ProcessListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ processes_dm.Process(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving process_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          process_name: str = None,
                          process_name_full: str = None,
                          iri: str = None,) -> str:
        if process_name is not None:
            filter_dict = {"name": process_name}
        elif process_name_full is not None:
            filter_dict = {"name_full": process_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.process_client.List(
                    lara_django_processes_pb2.ProcessListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving process_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].process_id
            else:
                raise ValueError(f"Error retrieving process_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.process_client.List(lara_django_processes_pb2.ProcessListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.process_client.List(
                lara_django_processes_pb2.ProcessListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.process_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.process_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.process_full_client.List(
                lara_django_processes_pb2.ProcessFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.process_full_client.List(
                lara_django_processes_pb2.ProcessFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, process : processes_dm.Process = None) -> None:
        try:
            await self.process_client.Update(
                lara_django_processes_pb2.ProcessRequest(**process.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating process_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.process_client.Destroy(lara_django_processes_pb2.ProcessDestroyRequest(process_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting process_id: {e}")

#_________________  MethodInstance  ______________________


class MethodInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.methodinstance_class_client = (
        #     lara_django_processes_pb2_grpc.MethodinstanceclassByIRIControllerStub(channel)
        # )
        
        self.methodinstance_client = lara_django_processes_pb2_grpc.MethodinstanceControllerStub(channel)

        # self.methodinstance_full_client = lara_django_processes_pb2_grpc.MethodinstanceFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  methodinstances:  list[processes_dm.MethodInstance] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[processes_dm.MethodInstance]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # methodinstanceclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if methodinstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.methodinstance_class_client.Retrieve(
        #         lara_django_processes_pb2.MethodinstanceclassRetrieveRequest(iri=methodinstance_class_iri)
        #     )
        #     methodinstanceclass_id = res.methodinstanceclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving methodinstanceclass_id: {e}")
        # for methodinstance in methodinstances:
        #     methodinstance.namespace = self.namespace_id
        #     methodinstance.methodinstance_class = methodinstanceclass_id

        try:
            create_coroutines = ( self.methodinstance_client.Create(lara_django_processes_pb2.MethodinstanceRequest(**methodinstance.model_dump())) for methodinstance in methodinstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.methodinstance_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating methodinstance: {e}")

    @export_file
    async def retrieve(
        self, 
        methodinstance_id: str = None,
        methodinstance_name: str = None,
        #methodinstance_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.MethodInstance]:
        filter_list = []
        results_list = []
        if  methodinstance_id is not None:
            try:
                res =  await self.methodinstance_client.Retrieve(
                    lara_django_processes_pb2.MethodinstanceRetrieveRequest(methodinstance_id=methodinstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.MethodInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving methodinstance_id: {e}")

        if methodinstance_name is not None:
            filter_list.append({"name": methodinstance_name})
        # if methodinstance_name_full is not None:
        #     filter_list.append({"name_full": methodinstance_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.methodinstance_client.List(
                        lara_django_processes_pb2.MethodinstanceListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ processes_dm.MethodInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving methodinstance_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          methodinstance_name: str = None,
                          methodinstance_name_full: str = None,
                          iri: str = None,) -> str:
        if methodinstance_name is not None:
            filter_dict = {"name": methodinstance_name}
        elif methodinstance_name_full is not None:
            filter_dict = {"name_full": methodinstance_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.methodinstance_client.List(
                    lara_django_processes_pb2.MethodinstanceListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving methodinstance_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].methodinstance_id
            else:
                raise ValueError(f"Error retrieving methodinstance_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.methodinstance_client.List(lara_django_processes_pb2.MethodinstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.methodinstance_client.List(
                lara_django_processes_pb2.MethodinstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.methodinstance_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.methodinstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.methodinstance_full_client.List(
                lara_django_processes_pb2.MethodinstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.methodinstance_full_client.List(
                lara_django_processes_pb2.MethodinstanceFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, methodinstance : processes_dm.MethodInstance = None) -> None:
        try:
            await self.methodinstance_client.Update(
                lara_django_processes_pb2.MethodinstanceRequest(**methodinstance.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating methodinstance_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.methodinstance_client.Destroy(lara_django_processes_pb2.MethodinstanceDestroyRequest(methodinstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting methodinstance_id: {e}")

#_________________  ProcedureInstance  ______________________


class ProcedureInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.procedureinstance_class_client = (
        #     lara_django_processes_pb2_grpc.ProcedureinstanceclassByIRIControllerStub(channel)
        # )
        
        self.procedureinstance_client = lara_django_processes_pb2_grpc.ProcedureinstanceControllerStub(channel)

        # self.procedureinstance_full_client = lara_django_processes_pb2_grpc.ProcedureinstanceFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  procedureinstances:  list[processes_dm.ProcedureInstance] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[processes_dm.ProcedureInstance]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # procedureinstanceclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if procedureinstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.procedureinstance_class_client.Retrieve(
        #         lara_django_processes_pb2.ProcedureinstanceclassRetrieveRequest(iri=procedureinstance_class_iri)
        #     )
        #     procedureinstanceclass_id = res.procedureinstanceclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving procedureinstanceclass_id: {e}")
        # for procedureinstance in procedureinstances:
        #     procedureinstance.namespace = self.namespace_id
        #     procedureinstance.procedureinstance_class = procedureinstanceclass_id

        try:
            create_coroutines = ( self.procedureinstance_client.Create(lara_django_processes_pb2.ProcedureinstanceRequest(**procedureinstance.model_dump())) for procedureinstance in procedureinstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.procedureinstance_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating procedureinstance: {e}")

    @export_file
    async def retrieve(
        self, 
        procedureinstance_id: str = None,
        procedureinstance_name: str = None,
        #procedureinstance_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ProcedureInstance]:
        filter_list = []
        results_list = []
        if  procedureinstance_id is not None:
            try:
                res =  await self.procedureinstance_client.Retrieve(
                    lara_django_processes_pb2.ProcedureinstanceRetrieveRequest(procedureinstance_id=procedureinstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ProcedureInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving procedureinstance_id: {e}")

        if procedureinstance_name is not None:
            filter_list.append({"name": procedureinstance_name})
        # if procedureinstance_name_full is not None:
        #     filter_list.append({"name_full": procedureinstance_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.procedureinstance_client.List(
                        lara_django_processes_pb2.ProcedureinstanceListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ processes_dm.ProcedureInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving procedureinstance_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          procedureinstance_name: str = None,
                          procedureinstance_name_full: str = None,
                          iri: str = None,) -> str:
        if procedureinstance_name is not None:
            filter_dict = {"name": procedureinstance_name}
        elif procedureinstance_name_full is not None:
            filter_dict = {"name_full": procedureinstance_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.procedureinstance_client.List(
                    lara_django_processes_pb2.ProcedureinstanceListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving procedureinstance_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].procedureinstance_id
            else:
                raise ValueError(f"Error retrieving procedureinstance_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.procedureinstance_client.List(lara_django_processes_pb2.ProcedureinstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.procedureinstance_client.List(
                lara_django_processes_pb2.ProcedureinstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.procedureinstance_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.procedureinstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.procedureinstance_full_client.List(
                lara_django_processes_pb2.ProcedureinstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.procedureinstance_full_client.List(
                lara_django_processes_pb2.ProcedureinstanceFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, procedureinstance : processes_dm.ProcedureInstance = None) -> None:
        try:
            await self.procedureinstance_client.Update(
                lara_django_processes_pb2.ProcedureinstanceRequest(**procedureinstance.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating procedureinstance_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.procedureinstance_client.Destroy(lara_django_processes_pb2.ProcedureinstanceDestroyRequest(procedureinstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting procedureinstance_id: {e}")

#_________________  ProcedureInstanceStepClass  ______________________


class ProcedureInstanceStepClassInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.procedureinstancestepclass_class_client = (
        #     lara_django_processes_pb2_grpc.ProcedureinstancestepclassclassByIRIControllerStub(channel)
        # )
        
        self.procedureinstancestepclass_client = lara_django_processes_pb2_grpc.ProcedureinstancestepclassControllerStub(channel)

        # self.procedureinstancestepclass_full_client = lara_django_processes_pb2_grpc.ProcedureinstancestepclassFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  procedureinstancestepclasses:  list[processes_dm.ProcedureInstanceStepClass] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[processes_dm.ProcedureInstanceStepClass]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # procedureinstancestepclassclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if procedureinstancestepclass_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.procedureinstancestepclass_class_client.Retrieve(
        #         lara_django_processes_pb2.ProcedureinstancestepclassclassRetrieveRequest(iri=procedureinstancestepclass_class_iri)
        #     )
        #     procedureinstancestepclassclass_id = res.procedureinstancestepclassclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving procedureinstancestepclassclass_id: {e}")
        # for procedureinstancestepclass in procedureinstancestepclasss:
        #     procedureinstancestepclass.namespace = self.namespace_id
        #     procedureinstancestepclass.procedureinstancestepclass_class = procedureinstancestepclassclass_id

        try:
            create_coroutines = ( self.procedureinstancestepclass_client.Create(lara_django_processes_pb2.ProcedureinstancestepclassRequest(**procedureinstancestepclass.model_dump())) for procedureinstancestepclass in procedureinstancestepclasses )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.procedureinstancestepclass_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating procedureinstancestepclass: {e}")

    @export_file
    async def retrieve(
        self, 
        procedureinstancestepclass_id: str = None,
        procedureinstancestepclass_name: str = None,
        #procedureinstancestepclass_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ProcedureInstanceStepClass]:
        filter_list = []
        results_list = []
        if  procedureinstancestepclass_id is not None:
            try:
                res =  await self.procedureinstancestepclass_client.Retrieve(
                    lara_django_processes_pb2.ProcedureinstancestepclassRetrieveRequest(procedureinstancestepclass_id=procedureinstancestepclass_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ProcedureInstanceStepClass(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving procedureinstancestepclass_id: {e}")

        if procedureinstancestepclass_name is not None:
            filter_list.append({"name": procedureinstancestepclass_name})
        # if procedureinstancestepclass_name_full is not None:
        #     filter_list.append({"name_full": procedureinstancestepclass_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.procedureinstancestepclass_client.List(
                        lara_django_processes_pb2.ProcedureinstancestepclassListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ processes_dm.ProcedureInstanceStepClass(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving procedureinstancestepclass_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          procedureinstancestepclass_name: str = None,
                          procedureinstancestepclass_name_full: str = None,
                          iri: str = None,) -> str:
        if procedureinstancestepclass_name is not None:
            filter_dict = {"name": procedureinstancestepclass_name}
        elif procedureinstancestepclass_name_full is not None:
            filter_dict = {"name_full": procedureinstancestepclass_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.procedureinstancestepclass_client.List(
                    lara_django_processes_pb2.ProcedureinstancestepclassListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving procedureinstancestepclass_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].procedureinstancestepclass_id
            else:
                raise ValueError(f"Error retrieving procedureinstancestepclass_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.procedureinstancestepclass_client.List(lara_django_processes_pb2.ProcedureinstancestepclassListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.procedureinstancestepclass_client.List(
                lara_django_processes_pb2.ProcedureinstancestepclassListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.procedureinstancestepclass_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.procedureinstancestepclass_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.procedureinstancestepclass_full_client.List(
                lara_django_processes_pb2.ProcedureinstancestepclassFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.procedureinstancestepclass_full_client.List(
                lara_django_processes_pb2.ProcedureinstancestepclassFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, procedureinstancestepclass : processes_dm.ProcedureInstanceStepClass = None) -> None:
        try:
            await self.procedureinstancestepclass_client.Update(
                lara_django_processes_pb2.ProcedureinstancestepclassRequest(**procedureinstancestepclass.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating procedureinstancestepclass_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.procedureinstancestepclass_client.Destroy(lara_django_processes_pb2.ProcedureinstancestepclassDestroyRequest(procedureinstancestepclass_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting procedureinstancestepclass_id: {e}")

#_________________  ProcedureInstanceStep  ______________________


class ProcedureInstanceStepInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.procedureinstancestep_class_client = (
        #     lara_django_processes_pb2_grpc.ProcedureinstancestepclassByIRIControllerStub(channel)
        # )
        
        self.procedureinstancestep_client = lara_django_processes_pb2_grpc.ProcedureinstancestepControllerStub(channel)

        # self.procedureinstancestep_full_client = lara_django_processes_pb2_grpc.ProcedureinstancestepFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  procedureinstancesteps:  list[processes_dm.ProcedureInstanceStep] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[processes_dm.ProcedureInstanceStep]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # procedureinstancestepclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if procedureinstancestep_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.procedureinstancestep_class_client.Retrieve(
        #         lara_django_processes_pb2.ProcedureinstancestepclassRetrieveRequest(iri=procedureinstancestep_class_iri)
        #     )
        #     procedureinstancestepclass_id = res.procedureinstancestepclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving procedureinstancestepclass_id: {e}")
        # for procedureinstancestep in procedureinstancesteps:
        #     procedureinstancestep.namespace = self.namespace_id
        #     procedureinstancestep.procedureinstancestep_class = procedureinstancestepclass_id

        try:
            create_coroutines = ( self.procedureinstancestep_client.Create(lara_django_processes_pb2.ProcedureinstancestepRequest(**procedureinstancestep.model_dump())) for procedureinstancestep in procedureinstancesteps )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.procedureinstancestep_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating procedureinstancestep: {e}")

    @export_file
    async def retrieve(
        self, 
        procedureinstancestep_id: str = None,
        procedureinstancestep_name: str = None,
        #procedureinstancestep_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ProcedureInstanceStep]:
        filter_list = []
        results_list = []
        if  procedureinstancestep_id is not None:
            try:
                res =  await self.procedureinstancestep_client.Retrieve(
                    lara_django_processes_pb2.ProcedureinstancestepRetrieveRequest(procedureinstancestep_id=procedureinstancestep_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ProcedureInstanceStep(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving procedureinstancestep_id: {e}")

        if procedureinstancestep_name is not None:
            filter_list.append({"name": procedureinstancestep_name})
        # if procedureinstancestep_name_full is not None:
        #     filter_list.append({"name_full": procedureinstancestep_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.procedureinstancestep_client.List(
                        lara_django_processes_pb2.ProcedureinstancestepListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ processes_dm.ProcedureInstanceStep(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving procedureinstancestep_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          procedureinstancestep_name: str = None,
                          procedureinstancestep_name_full: str = None,
                          iri: str = None,) -> str:
        if procedureinstancestep_name is not None:
            filter_dict = {"name": procedureinstancestep_name}
        elif procedureinstancestep_name_full is not None:
            filter_dict = {"name_full": procedureinstancestep_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.procedureinstancestep_client.List(
                    lara_django_processes_pb2.ProcedureinstancestepListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving procedureinstancestep_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].procedureinstancestep_id
            else:
                raise ValueError(f"Error retrieving procedureinstancestep_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.procedureinstancestep_client.List(lara_django_processes_pb2.ProcedureinstancestepListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.procedureinstancestep_client.List(
                lara_django_processes_pb2.ProcedureinstancestepListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.procedureinstancestep_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.procedureinstancestep_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.procedureinstancestep_full_client.List(
                lara_django_processes_pb2.ProcedureinstancestepFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.procedureinstancestep_full_client.List(
                lara_django_processes_pb2.ProcedureinstancestepFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, procedureinstancestep : processes_dm.ProcedureInstanceStep = None) -> None:
        try:
            await self.procedureinstancestep_client.Update(
                lara_django_processes_pb2.ProcedureinstancestepRequest(**procedureinstancestep.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating procedureinstancestep_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.procedureinstancestep_client.Destroy(lara_django_processes_pb2.ProcedureinstancestepDestroyRequest(procedureinstancestep_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting procedureinstancestep_id: {e}")

#_________________  ProcedureInstanceMoveStep  ______________________


class ProcedureInstanceMoveStepInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.procedureinstancemovestep_class_client = (
        #     lara_django_processes_pb2_grpc.ProcedureinstancemovestepclassByIRIControllerStub(channel)
        # )
        
        self.procedureinstancemovestep_client = lara_django_processes_pb2_grpc.ProcedureinstancemovestepControllerStub(channel)

        # self.procedureinstancemovestep_full_client = lara_django_processes_pb2_grpc.ProcedureinstancemovestepFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  procedureinstancemovesteps:  list[processes_dm.ProcedureInstanceMoveStep] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[processes_dm.ProcedureInstanceMoveStep]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # procedureinstancemovestepclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if procedureinstancemovestep_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.procedureinstancemovestep_class_client.Retrieve(
        #         lara_django_processes_pb2.ProcedureinstancemovestepclassRetrieveRequest(iri=procedureinstancemovestep_class_iri)
        #     )
        #     procedureinstancemovestepclass_id = res.procedureinstancemovestepclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving procedureinstancemovestepclass_id: {e}")
        # for procedureinstancemovestep in procedureinstancemovesteps:
        #     procedureinstancemovestep.namespace = self.namespace_id
        #     procedureinstancemovestep.procedureinstancemovestep_class = procedureinstancemovestepclass_id

        try:
            create_coroutines = ( self.procedureinstancemovestep_client.Create(lara_django_processes_pb2.ProcedureinstancemovestepRequest(**procedureinstancemovestep.model_dump())) for procedureinstancemovestep in procedureinstancemovesteps )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.procedureinstancemovestep_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating procedureinstancemovestep: {e}")

    @export_file
    async def retrieve(
        self, 
        procedureinstancemovestep_id: str = None,
        procedureinstancemovestep_name: str = None,
        #procedureinstancemovestep_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ProcedureInstanceMoveStep]:
        filter_list = []
        results_list = []
        if  procedureinstancemovestep_id is not None:
            try:
                res =  await self.procedureinstancemovestep_client.Retrieve(
                    lara_django_processes_pb2.ProcedureinstancemovestepRetrieveRequest(procedureinstancemovestep_id=procedureinstancemovestep_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ProcedureInstanceMoveStep(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving procedureinstancemovestep_id: {e}")

        if procedureinstancemovestep_name is not None:
            filter_list.append({"name": procedureinstancemovestep_name})
        # if procedureinstancemovestep_name_full is not None:
        #     filter_list.append({"name_full": procedureinstancemovestep_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.procedureinstancemovestep_client.List(
                        lara_django_processes_pb2.ProcedureinstancemovestepListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ processes_dm.ProcedureInstanceMoveStep(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving procedureinstancemovestep_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          procedureinstancemovestep_name: str = None,
                          procedureinstancemovestep_name_full: str = None,
                          iri: str = None,) -> str:
        if procedureinstancemovestep_name is not None:
            filter_dict = {"name": procedureinstancemovestep_name}
        elif procedureinstancemovestep_name_full is not None:
            filter_dict = {"name_full": procedureinstancemovestep_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.procedureinstancemovestep_client.List(
                    lara_django_processes_pb2.ProcedureinstancemovestepListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving procedureinstancemovestep_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].procedureinstancemovestep_id
            else:
                raise ValueError(f"Error retrieving procedureinstancemovestep_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.procedureinstancemovestep_client.List(lara_django_processes_pb2.ProcedureinstancemovestepListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.procedureinstancemovestep_client.List(
                lara_django_processes_pb2.ProcedureinstancemovestepListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.procedureinstancemovestep_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.procedureinstancemovestep_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.procedureinstancemovestep_full_client.List(
                lara_django_processes_pb2.ProcedureinstancemovestepFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.procedureinstancemovestep_full_client.List(
                lara_django_processes_pb2.ProcedureinstancemovestepFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, procedureinstancemovestep : processes_dm.ProcedureInstanceMoveStep = None) -> None:
        try:
            await self.procedureinstancemovestep_client.Update(
                lara_django_processes_pb2.ProcedureinstancemovestepRequest(**procedureinstancemovestep.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating procedureinstancemovestep_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.procedureinstancemovestep_client.Destroy(lara_django_processes_pb2.ProcedureinstancemovestepDestroyRequest(procedureinstancemovestep_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting procedureinstancemovestep_id: {e}")

#_________________  ProcessInstance  ______________________


class ProcessInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, default_namespace_uri : str = None) -> None:
        self.default_namespace_uri = None
        self.default_namespace_id = None

        if default_namespace_uri is not None:
            self.default_namespace_uri = default_namespace_uri
        
        self.namespace_if = base_if.NamespaceInterface(channel)

        # self.processinstance_class_client = (
        #     lara_django_processes_pb2_grpc.ProcessinstanceclassByIRIControllerStub(channel)
        # )
        
        self.processinstance_client = lara_django_processes_pb2_grpc.ProcessinstanceControllerStub(channel)

        # self.processinstance_full_client = lara_django_processes_pb2_grpc.ProcessinstanceFullControllerStub(
        #     channel
        # )

    @import_file(relation_resolver=lambda x: x)
    async def create(self,  processinstances:  list[processes_dm.ProcessInstance] = None,  ids_only: bool = False, namespace_uri: str = None) -> Union[list[str], list[processes_dm.ProcessInstance]]:
        # TODO: only retrieve default_namespace_id if not already retrieved and namespace_uri is None
        self.namespace_id = None
        # processinstanceclass_id = None
        if namespace_uri is None and self.default_namespace_uri is not None:
            namespace_uri = self.default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            self.namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logging.error(f"Error retrieving namespace_id: {e}")
        
        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if processinstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.processinstance_class_client.Retrieve(
        #         lara_django_processes_pb2.ProcessinstanceclassRetrieveRequest(iri=processinstance_class_iri)
        #     )
        #     processinstanceclass_id = res.processinstanceclass_id 
        # except Exception as e:
        #     logging.error(f"Error retrieving processinstanceclass_id: {e}")
        # for processinstance in processinstances:
        #     processinstance.namespace = self.namespace_id
        #     processinstance.processinstance_class = processinstanceclass_id

        try:
            create_coroutines = ( self.processinstance_client.Create(lara_django_processes_pb2.ProcessinstanceRequest(**processinstance.model_dump())) for processinstance in processinstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.processinstance_id for item in res]
            else:
                return res

        except Exception as e:
            logging.error(f"Error creating processinstance: {e}")

    @export_file
    async def retrieve(
        self, 
        processinstance_id: str = None,
        processinstance_name: str = None,
        #processinstance_name_full: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ProcessInstance]:
        filter_list = []
        results_list = []
        if  processinstance_id is not None:
            try:
                res =  await self.processinstance_client.Retrieve(
                    lara_django_processes_pb2.ProcessinstanceRetrieveRequest(processinstance_id=processinstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ProcessInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logging.error(f"Error retrieving processinstance_id: {e}")

        if processinstance_name is not None:
            filter_list.append({"name": processinstance_name})
        # if processinstance_name_full is not None:
        #     filter_list.append({"name_full": processinstance_name_full})
        if filter_dict is not None:
            filter_list.append(filter_dict)

        for filter_dict in filter_list:
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.processinstance_client.List(
                        lara_django_processes_pb2.ProcessinstanceListRequest(), metadata=metadata
                      )
                if raw:
                      results_list += res.results
                else:
                    # a queue could be used here to speed up the retrieval
                    results = res.results
                    results_list += [ processes_dm.ProcessInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
            except Exception as e:
                logging.error(f"Error retrieving processinstance_name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self, 
                          processinstance_name: str = None,
                          processinstance_name_full: str = None,
                          iri: str = None,) -> str:
        if processinstance_name is not None:
            filter_dict = {"name": processinstance_name}
        elif processinstance_name_full is not None:
            filter_dict = {"name_full": processinstance_name_full}
        elif iri is not None:
            filter_dict = {"iri": iri}
            metadata = (("filters", (json.dumps(filter_dict))),)
            try:
                res = await self.processinstance_client.List(
                    lara_django_processes_pb2.ProcessinstanceListRequest(), metadata=metadata
                )
                results = res.results
            except Exception as e:
                logging.error(f"Error retrieving processinstance_name: {e}")
            if len(results) > 0 and len(results) < 2:
                return results[0].processinstance_id
            else:
                raise ValueError(f"Error retrieving processinstance_id - no or too many results found.")
            
        
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        if filter_dict is None:
            res = await self.processinstance_client.List(lara_django_processes_pb2.ProcessinstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.processinstance_client.List(
                lara_django_processes_pb2.ProcessinstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.processinstance_id for item in res.results]
        else:
            return res.results
            

    async def list_full(self, filter_dict: dict = None) :
        if self.processinstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.processinstance_full_client.List(
                lara_django_processes_pb2.ProcessinstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.processinstance_full_client.List(
                lara_django_processes_pb2.ProcessinstanceFullListRequest(), metadata=metadata
            )

    @import_file(relation_resolver=lambda x: x)
    # @update_image
    # @update_file
    async def update(self, processinstance : processes_dm.ProcessInstance = None) -> None:
        try:
            await self.processinstance_client.Update(
                lara_django_processes_pb2.ProcessinstanceRequest(**processinstance.model_dump()
            ))
        except Exception as e:
            logging.error(f"Error updating processinstance_id: {e}")

    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)
    
        try:
            delete_coroutines = ( self.processinstance_client.Destroy(lara_django_processes_pb2.ProcessinstanceDestroyRequest(processinstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)
            
        except Exception as e:
            logging.error(f"Error deleting processinstance_id: {e}")

