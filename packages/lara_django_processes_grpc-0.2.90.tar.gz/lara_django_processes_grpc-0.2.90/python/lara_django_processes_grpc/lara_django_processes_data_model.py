from __future__ import annotations 

import re
import sys
from datetime import (
    date,
    datetime,
    time
)
from decimal import Decimal 
from enum import Enum 
from typing import (
    Any,
    ClassVar,
    Dict,
    List,
    Literal,
    Optional,
    Union
)

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    RootModel,
    field_validator
)


metamodel_version = "None"
version = "None"


class ConfiguredBaseModel(BaseModel):
    model_config = ConfigDict(
        validate_assignment = True,
        validate_default = True,
        extra = "forbid",
        arbitrary_types_allowed = True,
        use_enum_values = True,
        strict = False,
    )
    pass




class LinkMLMeta(RootModel):
    root: Dict[str, Any] = {}
    model_config = ConfigDict(frozen=True)

    def __getattr__(self, key:str):
        return getattr(self.root, key)

    def __getitem__(self, key:str):
        return self.root[key]

    def __setitem__(self, key:str, value):
        self.root[key] = value

    def __contains__(self, key:str) -> bool:
        return key in self.root


linkml_meta = LinkMLMeta({'default_prefix': 'lara',
     'default_range': 'string',
     'id': 'https://w3id.org/lara/lara_django_processes',
     'imports': ['linkml:types'],
     'name': 'lara_django_processes',
     'prefixes': {'lara': {'prefix_prefix': 'lara',
                           'prefix_reference': 'http://w3id.org/lara/'},
                  'linkml': {'prefix_prefix': 'linkml',
                             'prefix_reference': 'https://w3id.org/linkml/'},
                  'oso': {'prefix_prefix': 'oso',
                          'prefix_reference': 'http://w3id.org/oso/'}},
     'source_file': 'lara_django_processes_schema.yaml',
     'types': {'FileField': {'base': 'str',
                             'description': 'A file field',
                             'from_schema': 'https://w3id.org/lara/lara_django_processes',
                             'name': 'FileField',
                             'uri': 'https://w3id.org/lara/FileField'},
               'ImageField': {'base': 'str',
                              'description': 'An image field',
                              'from_schema': 'https://w3id.org/lara/lara_django_processes',
                              'name': 'ImageField',
                              'uri': 'https://w3id.org/lara/ImageField'},
               'JSON': {'base': 'string',
                        'description': 'A JSON object',
                        'from_schema': 'https://w3id.org/lara/lara_django_processes',
                        'name': 'JSON',
                        'repr': 'dict',
                        'uri': 'https://json.org'},
               'UUID': {'base': 'str',
                        'description': 'A UUID',
                        'from_schema': 'https://w3id.org/lara/lara_django_processes',
                        'name': 'UUID',
                        'pattern': '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$',
                        'uri': 'https://datatracker.ietf.org/doc/html/rfc9562'}}} )


class Polymer(ConfiguredBaseModel):
    """
    <class 'lara_django_substances.models.Polymer'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class DeviceSetupInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_material_store.models.device_models.DeviceSetupInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class ExternalResource(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.ExternalResource'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class MixtureInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_substances_store.models.MixtureInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class Location(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Location'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class Tag(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Tag'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class ItemStatus(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.ItemStatus'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class Mixture(ConfiguredBaseModel):
    """
    <class 'lara_django_substances.models.Mixture'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class DeviceSetup(ConfiguredBaseModel):
    """
    <class 'lara_django_material.models.DeviceSetup'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class LabwareInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_material_store.models.labware_models.LabwareInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class Labware(ConfiguredBaseModel):
    """
    <class 'lara_django_material.models.Labware'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class SampleSet(ConfiguredBaseModel):
    """
    <class 'lara_django_samples.models.SampleSet'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class Substance(ConfiguredBaseModel):
    """
    <class 'lara_django_substances.models.Substance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class Group(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.Group'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class PartInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_material_store.models.part_models.PartInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class Namespace(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Namespace'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class MediaType(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.MediaType'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class Entity(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.Entity'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class OrganismInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_organisms_store.models.OrganismInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class PolymerInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_substances_store.models.PolymerInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class DataType(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.DataType'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class Organism(ConfiguredBaseModel):
    """
    <class 'lara_django_organisms.models.Organism'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class DeviceInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_material_store.models.device_models.DeviceInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class Part(ConfiguredBaseModel):
    """
    <class 'lara_django_material.models.Part'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class Sample(ConfiguredBaseModel):
    """
    <class 'lara_django_samples.models.Sample'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class Device(ConfiguredBaseModel):
    """
    <class 'lara_django_material.models.Device'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class SubstanceInstance(ConfiguredBaseModel):
    """
    <class 'lara_django_substances_store.models.SubstanceInstance'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    pass


class ExtraData(ConfiguredBaseModel):
    """
    \" This class can be used to extend the process data, by extra information,
        e.g.,   ...
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/ExtraData',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    extradata_id: Optional[str] = Field(None, description="""ExtraData - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'extradata_id',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:processes/ExtraData/extradata_id'} })
    data_type: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'data_type',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:base/DataType'} })
    namespace: str = Field(..., description="""namespace of data""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""Human readable display name or title of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ExtraData/name_display'} })
    name: Optional[str] = Field(None, description="""name of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ExtraData/name'} })
    name_full: Optional[str] = Field(None, description="""full name of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name_full',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:processes/ExtraData/name_full'} })
    version: Optional[str] = Field(None, description="""version of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ExtraData/version'} })
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of all data (JSON and XML)""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha256',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:processes/ExtraData/hash_sha256'} })
    data_json: Optional[dict] = Field(None, description="""generic JSON field""", json_schema_extra = { "linkml_meta": {'alias': 'data_json',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:processes/ExtraData/data_json'} })
    media_type: Optional[str] = Field(None, description="""IANA media type of extra data file""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['ExtraData',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:base/MediaType'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ExtraData/iri'} })
    url: Optional[str] = Field(None, description="""Universal Resource Locator - this can be used to link the data to external locations""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:processes/ExtraData/url'} })
    datetime_created: Optional[str] = Field(None, description="""date and time when data was created""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_created',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:processes/ExtraData/datetime_created'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ExtraData/datetime_last_modified'} })
    description: Optional[str] = Field(None, description="""description of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ExtraData/description'} })
    image: Optional[str] = Field(None, description="""location room map rel. path/filename to image""", json_schema_extra = { "linkml_meta": {'alias': 'image',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:processes/ExtraData/image'} })
    file: Optional[str] = Field(None, description="""rel. path/filename""", json_schema_extra = { "linkml_meta": {'alias': 'file',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:processes/ExtraData/file'} })


class MethodClass(ConfiguredBaseModel):
    """
    \" classes for methods Absorption ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/MethodClass',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    methodclass_id: Optional[str] = Field(None, description="""MethodClass - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'methodclass_id',
         'domain_of': ['MethodClass'],
         'slot_uri': 'lara:processes/MethodClass/methodclass_id'} })
    name: str = Field(..., description="""name of the method class, """, json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/MethodClass/name'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/MethodClass/iri'} })
    description: Optional[str] = Field(None, description="""description""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/MethodClass/description'} })


class Method(ConfiguredBaseModel):
    """
    \" Def. Method: A process by which a task is completed;
        a way of doing something (followed by the adposition of, to or for before the purpose of the process).
        E.g. method chromatography.HPLC , GC, NMR, PCR, ...
        This is a generic method representation, for a concrete Method in a particular lab, see MethodInstance
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/Method',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    namespace: Optional[str] = Field(None, description="""namespace of method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""human readable name of the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/Method/name_display'} })
    name: Optional[str] = Field(None, description="""name of the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/Method/name'} })
    uri: Optional[str] = Field(None, description="""Uniform Resource Identifier to locate method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'uri',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Method/uri'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Method/iri'} })
    pid: Optional[str] = Field(None, description="""Persistent Identifier [PID/handle URI](https://www.handle.net/)""", json_schema_extra = { "linkml_meta": {'alias': 'pid',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Method/pid'} })
    pac_id: Optional[str] = Field(None, description="""Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.""", json_schema_extra = { "linkml_meta": {'alias': 'pac_id',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:processes/Method/pac_id'} })
    version: Optional[str] = Field(None, description="""maj.min.patch version of this method/procedure/process, e.g. 0.2.3""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Method/version'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/Method/datetime_last_modified'} })
    parameters: Optional[dict] = Field(None, description="""method/procedure/process parameters""", json_schema_extra = { "linkml_meta": {'alias': 'parameters',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Method/parameters'} })
    icon: Optional[str] = Field(None, description="""XML/SVG icon / symbol of the method""", json_schema_extra = { "linkml_meta": {'alias': 'icon',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Method/icon'} })
    media_type: Optional[str] = Field(None, description="""file type of method file""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['ExtraData',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:base/MediaType'} })
    description: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/Method/description'} })
    remarks: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Method/remarks'} })
    method_id: Optional[str] = Field(None, description="""Method - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'method_id',
         'domain_of': ['Method'],
         'slot_uri': 'lara:processes/Method/method_id'} })
    method_class: Optional[str] = Field(None, description="""class of the method""", json_schema_extra = { "linkml_meta": {'alias': 'method_class',
         'domain_of': ['Method'],
         'slot_uri': 'lara:processes/MethodClass'} })
    method_json: Optional[dict] = Field(None, description="""Method JSON representation""", json_schema_extra = { "linkml_meta": {'alias': 'method_json',
         'domain_of': ['Method', 'MethodInstance'],
         'slot_uri': 'lara:processes/Method/method_json'} })
    substances: Optional[List[str]] = Field(None, description="""Substance classes used, e.g. for chemical synthesis,""", json_schema_extra = { "linkml_meta": {'alias': 'substances',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:substances/Substance'} })
    polymers: Optional[List[str]] = Field(None, description="""Polymer classes used """, json_schema_extra = { "linkml_meta": {'alias': 'polymers',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:substances/Polymer'} })
    mixtures: Optional[List[str]] = Field(None, description="""Substance Mixture Classes used in the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'mixtures',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:substances/Mixture'} })
    parts: Optional[List[str]] = Field(None, description="""Part classes used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'parts',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:material/Part'} })
    devices: Optional[List[str]] = Field(None, description="""Devices classes used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'devices',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:material/Device'} })
    device_setups: Optional[List[str]] = Field(None, description="""DeviceSetup classes used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'device_setups',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:material/DeviceSetup'} })
    labware: Optional[List[str]] = Field(None, description="""Labware classes""", json_schema_extra = { "linkml_meta": {'alias': 'labware',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:material/Labware'} })
    organisms: Optional[List[str]] = Field(None, description="""Organisms class used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'organisms',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:organisms/Organism'} })
    samples: Optional[List[str]] = Field(None, description="""Samples used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'samples',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:samples/Sample'} })
    sample_sets: Optional[List[str]] = Field(None, description="""SampleSets used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'sample_sets',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:samples/SampleSet'} })
    creators: Optional[List[str]] = Field(None, description="""creators of method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'creators',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:people/Entity'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:base/ExternalResource'} })
    data_extra: Optional[List[str]] = Field(None, description="""extra data""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ExtraData'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Tag'} })


class MethodsSubset(ConfiguredBaseModel):
    """
    \" A subset of methods, e.g. all methods for a certain lab, or all methods for a certain project, ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/MethodsSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/MethodsSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/MethodsSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['MethodsSubset',
                       'ProceduresSubset',
                       'ProcessesSubset',
                       'MethodInstancesSubset',
                       'ProcedureInstancesSubset',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['MethodsSubset',
                       'ProceduresSubset',
                       'ProcessesSubset',
                       'MethodInstancesSubset',
                       'ProcedureInstancesSubset',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/MethodsSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/MethodsSubset/datetime_last_modified'} })
    methodssubset_id: Optional[str] = Field(None, description="""MethodsSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'methodssubset_id',
         'domain_of': ['MethodsSubset'],
         'slot_uri': 'lara:processes/MethodsSubset/methodssubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Tag'} })
    methods: Optional[List[str]] = Field(None, description="""all methods of a subset""", json_schema_extra = { "linkml_meta": {'alias': 'methods',
         'domain_of': ['MethodsSubset', 'Container'],
         'slot_uri': 'lara:processes/Method'} })


class OrderedMethodsSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between MethodsSubset and Method.
        This class can be used to store the order of methods in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/OrderedMethodsSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    orderedmethodssubset_id: Optional[str] = Field(None, description="""OrderedMethodsSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedmethodssubset_id',
         'domain_of': ['OrderedMethodsSubset', 'OrderedMethodInstancesSubset'],
         'slot_uri': 'lara:processes/OrderedMethodsSubset/orderedmethodssubset_id'} })
    method: str = Field(..., description="""method in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'method',
         'domain_of': ['OrderedMethodsSubset'],
         'slot_uri': 'lara:processes/Method'} })
    methods_subset: str = Field(..., description="""subset of methods""", json_schema_extra = { "linkml_meta": {'alias': 'methods_subset',
         'domain_of': ['OrderedMethodsSubset'],
         'slot_uri': 'lara:processes/MethodsSubset'} })
    order: int = Field(..., description="""order of method in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedMethodsSubset',
                       'OrderedProceduresSubset',
                       'OrderedProcedures',
                       'OrderedProcessesSubset',
                       'OrderedMethodInstancesSubset',
                       'OrderedProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'OrderedProcedureInstances',
                       'OrderedProcessInstancesSubset'],
         'slot_uri': 'lara:processes/OrderedMethodsSubset/order'} })


class Procedure(ConfiguredBaseModel):
    """
    \" A procedure is a (defined) sequence of actions leading to a certain result,
        e.g. the sequence of gradient steps in an HPLC measurement,
             a sequence of transfer steps on a liquid handler, an enzyme assay ...
        This is a generic Procedure representation, for a concrete Procedure in a particular lab, see MethodInstance
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/Procedure',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    namespace: Optional[str] = Field(None, description="""namespace of method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""human readable name of the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/Procedure/name_display'} })
    name: Optional[str] = Field(None, description="""name of the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/Procedure/name'} })
    uri: Optional[str] = Field(None, description="""Uniform Resource Identifier to locate method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'uri',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Procedure/uri'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Procedure/iri'} })
    pid: Optional[str] = Field(None, description="""Persistent Identifier [PID/handle URI](https://www.handle.net/)""", json_schema_extra = { "linkml_meta": {'alias': 'pid',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Procedure/pid'} })
    pac_id: Optional[str] = Field(None, description="""Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.""", json_schema_extra = { "linkml_meta": {'alias': 'pac_id',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:processes/Procedure/pac_id'} })
    version: Optional[str] = Field(None, description="""maj.min.patch version of this method/procedure/process, e.g. 0.2.3""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Procedure/version'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/Procedure/datetime_last_modified'} })
    parameters: Optional[dict] = Field(None, description="""method/procedure/process parameters""", json_schema_extra = { "linkml_meta": {'alias': 'parameters',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Procedure/parameters'} })
    icon: Optional[str] = Field(None, description="""XML/SVG icon / symbol of the method""", json_schema_extra = { "linkml_meta": {'alias': 'icon',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Procedure/icon'} })
    media_type: Optional[str] = Field(None, description="""file type of method file""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['ExtraData',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:base/MediaType'} })
    description: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/Procedure/description'} })
    remarks: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Procedure/remarks'} })
    procedure_id: Optional[str] = Field(None, description="""Procedure - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_id',
         'domain_of': ['Procedure'],
         'slot_uri': 'lara:processes/Procedure/procedure_id'} })
    procedure_class: Optional[str] = Field(None, description="""class of the procedure""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_class',
         'domain_of': ['Procedure'],
         'slot_uri': 'lara:processes/MethodClass'} })
    procedure_txt: Optional[str] = Field(None, description="""Procedure text representation, e.g. SOP, python code, R-script, ...""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_txt',
         'domain_of': ['Procedure'],
         'slot_uri': 'lara:processes/Procedure/procedure_txt'} })
    procedure_json: Optional[dict] = Field(None, description="""Procedure JSON representation""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_json',
         'domain_of': ['Procedure', 'ProcedureInstance'],
         'slot_uri': 'lara:processes/Procedure/procedure_json'} })
    procedure_file: Optional[str] = Field(None, description="""rel. path/filename to procedures""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_file',
         'domain_of': ['Procedure', 'ProcedureInstance'],
         'slot_uri': 'lara:processes/Procedure/procedure_file'} })
    substances: Optional[List[str]] = Field(None, description="""Substance classes used, e.g. for chemical synthesis,""", json_schema_extra = { "linkml_meta": {'alias': 'substances',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:substances/Substance'} })
    polymers: Optional[List[str]] = Field(None, description="""Polymer classes used """, json_schema_extra = { "linkml_meta": {'alias': 'polymers',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:substances/Polymer'} })
    mixtures: Optional[List[str]] = Field(None, description="""Substance Mixture Classes used in the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'mixtures',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:substances/Mixture'} })
    parts: Optional[List[str]] = Field(None, description="""Part classes used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'parts',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:material/Part'} })
    devices: Optional[List[str]] = Field(None, description="""Devices classes used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'devices',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:material/Device'} })
    device_setups: Optional[List[str]] = Field(None, description="""DeviceSetup classes used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'device_setups',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:material/DeviceSetup'} })
    labware: Optional[List[str]] = Field(None, description="""Labware classes""", json_schema_extra = { "linkml_meta": {'alias': 'labware',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:material/Labware'} })
    organisms: Optional[List[str]] = Field(None, description="""Organisms class used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'organisms',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:organisms/Organism'} })
    samples: Optional[List[str]] = Field(None, description="""Samples used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'samples',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:samples/Sample'} })
    sample_sets: Optional[List[str]] = Field(None, description="""SampleSets used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'sample_sets',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:samples/SampleSet'} })
    creators: Optional[List[str]] = Field(None, description="""creators of method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'creators',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:people/Entity'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:base/ExternalResource'} })
    data_extra: Optional[List[str]] = Field(None, description="""extra data""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ExtraData'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Tag'} })


class ProceduresSubset(ConfiguredBaseModel):
    """
    \" A subset of procedures, e.g. all procedures for a certain lab, or all procedures for a certain project, ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/ProceduresSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProceduresSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProceduresSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['MethodsSubset',
                       'ProceduresSubset',
                       'ProcessesSubset',
                       'MethodInstancesSubset',
                       'ProcedureInstancesSubset',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['MethodsSubset',
                       'ProceduresSubset',
                       'ProcessesSubset',
                       'MethodInstancesSubset',
                       'ProcedureInstancesSubset',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProceduresSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProceduresSubset/datetime_last_modified'} })
    proceduressubset_id: Optional[str] = Field(None, description="""ProceduresSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'proceduressubset_id',
         'domain_of': ['ProceduresSubset'],
         'slot_uri': 'lara:processes/ProceduresSubset/proceduressubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Tag'} })
    procedures: Optional[List[str]] = Field(None, description="""all procedures of a subset""", json_schema_extra = { "linkml_meta": {'alias': 'procedures',
         'domain_of': ['ProceduresSubset', 'Process', 'Container'],
         'slot_uri': 'lara:processes/Procedure'} })


class OrderedProceduresSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between ProceduresSubset and Procedure.
        This class can be used to store the order of procedures in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/OrderedProceduresSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    orderedproceduressubset_id: Optional[str] = Field(None, description="""OrderedProceduresSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedproceduressubset_id',
         'domain_of': ['OrderedProceduresSubset', 'OrderedProcedureInstancesSubset'],
         'slot_uri': 'lara:processes/OrderedProceduresSubset/orderedproceduressubset_id'} })
    procedure: str = Field(..., description="""procedure in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'procedure',
         'domain_of': ['OrderedProceduresSubset', 'OrderedProcedures'],
         'slot_uri': 'lara:processes/Procedure'} })
    procedures_subset: str = Field(..., description="""subset of procedures""", json_schema_extra = { "linkml_meta": {'alias': 'procedures_subset',
         'domain_of': ['OrderedProceduresSubset'],
         'slot_uri': 'lara:processes/ProceduresSubset'} })
    order: int = Field(..., description="""order of procedure in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedMethodsSubset',
                       'OrderedProceduresSubset',
                       'OrderedProcedures',
                       'OrderedProcessesSubset',
                       'OrderedMethodInstancesSubset',
                       'OrderedProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'OrderedProcedureInstances',
                       'OrderedProcessInstancesSubset'],
         'slot_uri': 'lara:processes/OrderedProceduresSubset/order'} })


class Process(ConfiguredBaseModel):
    """
    \" A process is a combination of various procedures and decisions,
        e.g. a robot process, a fermentation process, ....
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/Process',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    namespace: Optional[str] = Field(None, description="""namespace of method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""human readable name of the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/Process/name_display'} })
    name: Optional[str] = Field(None, description="""name of the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/Process/name'} })
    uri: Optional[str] = Field(None, description="""Uniform Resource Identifier to locate method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'uri',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Process/uri'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Process/iri'} })
    pid: Optional[str] = Field(None, description="""Persistent Identifier [PID/handle URI](https://www.handle.net/)""", json_schema_extra = { "linkml_meta": {'alias': 'pid',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Process/pid'} })
    pac_id: Optional[str] = Field(None, description="""Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.""", json_schema_extra = { "linkml_meta": {'alias': 'pac_id',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:processes/Process/pac_id'} })
    version: Optional[str] = Field(None, description="""maj.min.patch version of this method/procedure/process, e.g. 0.2.3""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Process/version'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/Process/datetime_last_modified'} })
    parameters: Optional[dict] = Field(None, description="""method/procedure/process parameters""", json_schema_extra = { "linkml_meta": {'alias': 'parameters',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Process/parameters'} })
    icon: Optional[str] = Field(None, description="""XML/SVG icon / symbol of the method""", json_schema_extra = { "linkml_meta": {'alias': 'icon',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Process/icon'} })
    media_type: Optional[str] = Field(None, description="""file type of method file""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['ExtraData',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:base/MediaType'} })
    description: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/Process/description'} })
    remarks: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/Process/remarks'} })
    process_id: Optional[str] = Field(None, description="""Process - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'process_id',
         'domain_of': ['Process'],
         'slot_uri': 'lara:processes/Process/process_id'} })
    process_class: Optional[str] = Field(None, description="""class of the process""", json_schema_extra = { "linkml_meta": {'alias': 'process_class',
         'domain_of': ['Process'],
         'slot_uri': 'lara:processes/MethodClass'} })
    process_json: Optional[dict] = Field(None, description="""Process JSON representation""", json_schema_extra = { "linkml_meta": {'alias': 'process_json',
         'domain_of': ['Process', 'ProcessInstance'],
         'slot_uri': 'lara:processes/Process/process_json'} })
    process_file: Optional[str] = Field(None, description="""rel. path/filename to processes""", json_schema_extra = { "linkml_meta": {'alias': 'process_file',
         'domain_of': ['Process', 'ProcessInstance'],
         'slot_uri': 'lara:processes/Process/process_file'} })
    substances: Optional[List[str]] = Field(None, description="""Substance classes used, e.g. for chemical synthesis,""", json_schema_extra = { "linkml_meta": {'alias': 'substances',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:substances/Substance'} })
    polymers: Optional[List[str]] = Field(None, description="""Polymer classes used """, json_schema_extra = { "linkml_meta": {'alias': 'polymers',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:substances/Polymer'} })
    mixtures: Optional[List[str]] = Field(None, description="""Substance Mixture Classes used in the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'mixtures',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:substances/Mixture'} })
    parts: Optional[List[str]] = Field(None, description="""Part classes used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'parts',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:material/Part'} })
    devices: Optional[List[str]] = Field(None, description="""Devices classes used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'devices',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:material/Device'} })
    device_setups: Optional[List[str]] = Field(None, description="""DeviceSetup classes used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'device_setups',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:material/DeviceSetup'} })
    labware: Optional[List[str]] = Field(None, description="""Labware classes""", json_schema_extra = { "linkml_meta": {'alias': 'labware',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:material/Labware'} })
    organisms: Optional[List[str]] = Field(None, description="""Organisms class used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'organisms',
         'domain_of': ['Method', 'Procedure', 'Process'],
         'slot_uri': 'lara:organisms/Organism'} })
    samples: Optional[List[str]] = Field(None, description="""Samples used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'samples',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:samples/Sample'} })
    sample_sets: Optional[List[str]] = Field(None, description="""SampleSets used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'sample_sets',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:samples/SampleSet'} })
    creators: Optional[List[str]] = Field(None, description="""creators of method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'creators',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:people/Entity'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:base/ExternalResource'} })
    data_extra: Optional[List[str]] = Field(None, description="""extra data""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ExtraData'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Tag'} })
    procedures: Optional[List[str]] = Field(None, description="""all procedures of a process""", json_schema_extra = { "linkml_meta": {'alias': 'procedures',
         'domain_of': ['ProceduresSubset', 'Process', 'Container'],
         'slot_uri': 'lara:processes/Procedure'} })


class OrderedProcedures(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between Process and Procedure.
        This class can be used to store the order of procedures in a process
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/OrderedProcedures',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    orderedprocedures_id: Optional[str] = Field(None, description="""OrderedProcedures - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedprocedures_id',
         'domain_of': ['OrderedProcedures'],
         'slot_uri': 'lara:processes/OrderedProcedures/orderedprocedures_id'} })
    procedure: str = Field(..., description="""procedure in the process""", json_schema_extra = { "linkml_meta": {'alias': 'procedure',
         'domain_of': ['OrderedProceduresSubset', 'OrderedProcedures'],
         'slot_uri': 'lara:processes/Procedure'} })
    process: str = Field(..., description="""process""", json_schema_extra = { "linkml_meta": {'alias': 'process',
         'domain_of': ['OrderedProcedures', 'OrderedProcessesSubset'],
         'slot_uri': 'lara:processes/Process'} })
    order: int = Field(..., description="""order of procedure in process""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedMethodsSubset',
                       'OrderedProceduresSubset',
                       'OrderedProcedures',
                       'OrderedProcessesSubset',
                       'OrderedMethodInstancesSubset',
                       'OrderedProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'OrderedProcedureInstances',
                       'OrderedProcessInstancesSubset'],
         'slot_uri': 'lara:processes/OrderedProcedures/order'} })


class ProcessesSubset(ConfiguredBaseModel):
    """
    \" A subset of processes, e.g. all processes for a certain lab, or all processes for a certain project, ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/ProcessesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessesSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessesSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['MethodsSubset',
                       'ProceduresSubset',
                       'ProcessesSubset',
                       'MethodInstancesSubset',
                       'ProcedureInstancesSubset',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['MethodsSubset',
                       'ProceduresSubset',
                       'ProcessesSubset',
                       'MethodInstancesSubset',
                       'ProcedureInstancesSubset',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessesSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessesSubset/datetime_last_modified'} })
    processessubset_id: Optional[str] = Field(None, description="""ProcessesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'processessubset_id',
         'domain_of': ['ProcessesSubset'],
         'slot_uri': 'lara:processes/ProcessesSubset/processessubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Tag'} })
    processes: Optional[List[str]] = Field(None, description="""all processes of a subset""", json_schema_extra = { "linkml_meta": {'alias': 'processes',
         'domain_of': ['ProcessesSubset'],
         'slot_uri': 'lara:processes/Process'} })


class OrderedProcessesSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between ProcessesSubset and Process.
        This class can be used to store the order of processes in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/OrderedProcessesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    orderedprocessessubset_id: Optional[str] = Field(None, description="""OrderedProcessesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedprocessessubset_id',
         'domain_of': ['OrderedProcessesSubset'],
         'slot_uri': 'lara:processes/OrderedProcessesSubset/orderedprocessessubset_id'} })
    process: str = Field(..., description="""process in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'process',
         'domain_of': ['OrderedProcedures', 'OrderedProcessesSubset'],
         'slot_uri': 'lara:processes/Process'} })
    processes_subset: str = Field(..., description="""subset of processes""", json_schema_extra = { "linkml_meta": {'alias': 'processes_subset',
         'domain_of': ['OrderedProcessesSubset'],
         'slot_uri': 'lara:processes/ProcessesSubset'} })
    order: int = Field(..., description="""order of process in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedMethodsSubset',
                       'OrderedProceduresSubset',
                       'OrderedProcedures',
                       'OrderedProcessesSubset',
                       'OrderedMethodInstancesSubset',
                       'OrderedProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'OrderedProcedureInstances',
                       'OrderedProcessInstancesSubset'],
         'slot_uri': 'lara:processes/OrderedProcessesSubset/order'} })


class MethodInstance(ConfiguredBaseModel):
    """
    \" A process by which a task is completed;
        a way of doing something (followed by the adposition of, to or for before the purpose of the process).
        E.g. chromatography.HPLC, GC, NMR, PCR, ...
        This is concrete instance of a method
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/MethodInstance',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    namespace: Optional[str] = Field(None, description="""namespace of method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""human readable name of the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/MethodInstance/name_display'} })
    name: Optional[str] = Field(None, description="""name of the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/MethodInstance/name'} })
    uri: Optional[str] = Field(None, description="""Uniform Resource Identifier to locate method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'uri',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/MethodInstance/uri'} })
    version: Optional[str] = Field(None, description="""maj.min.patch version of this method/procedure/process, e.g. 0.2.3""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/MethodInstance/version'} })
    datetime_start: Optional[str] = Field(None, description="""date and time when the Method/Produre/Process was started""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_start',
         'domain_of': ['MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/MethodInstance/datetime_start'} })
    datetime_end: Optional[str] = Field(None, description="""date and time when the Method/Produre/Process was finished""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_end',
         'domain_of': ['MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/MethodInstance/datetime_end'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when the Method/Produre/Process was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/MethodInstance/datetime_last_modified'} })
    parameters: Optional[dict] = Field(None, description="""method/procedure/process parameters""", json_schema_extra = { "linkml_meta": {'alias': 'parameters',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/MethodInstance/parameters'} })
    status: Optional[str] = Field(None, description="""state of the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'status',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:base/ItemStatus'} })
    icon: Optional[str] = Field(None, description="""XML/SVG icon / symbol of the method""", json_schema_extra = { "linkml_meta": {'alias': 'icon',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/MethodInstance/icon'} })
    media_type: Optional[str] = Field(None, description="""file type of method file""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['ExtraData',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:base/MediaType'} })
    description: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/MethodInstance/description'} })
    remarks: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/MethodInstance/remarks'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/MethodInstance/iri'} })
    pid: Optional[str] = Field(None, description="""Persitent Identifier [PID/handle URI](https://www.handle.net/)""", json_schema_extra = { "linkml_meta": {'alias': 'pid',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/MethodInstance/pid'} })
    methodinstance_id: Optional[str] = Field(None, description="""MethodInstance - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'methodinstance_id',
         'domain_of': ['MethodInstance'],
         'slot_uri': 'lara:processes/MethodInstance/methodinstance_id'} })
    method_base: Optional[str] = Field(None, description="""reference method = referring method class, like chromatography.HPLC""", json_schema_extra = { "linkml_meta": {'alias': 'method_base',
         'domain_of': ['MethodInstance'],
         'slot_uri': 'lara:processes/Method'} })
    method_json: Optional[dict] = Field(None, description="""Method JSON representation""", json_schema_extra = { "linkml_meta": {'alias': 'method_json',
         'domain_of': ['Method', 'MethodInstance'],
         'slot_uri': 'lara:processes/MethodInstance/method_json'} })
    substance_instances: Optional[List[str]] = Field(None, description="""S e.g. for chemical synthesis,""", json_schema_extra = { "linkml_meta": {'alias': 'substance_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:substances-store/SubstanceInstance'} })
    polymer_instances: Optional[List[str]] = Field(None, description="""Polymers used e.g. for sequencing """, json_schema_extra = { "linkml_meta": {'alias': 'polymer_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:substances-store/PolymerInstance'} })
    mixture_instances: Optional[List[str]] = Field(None, description="""Mixture instances used""", json_schema_extra = { "linkml_meta": {'alias': 'mixture_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:substances-store/MixtureInstance'} })
    part_instances: Optional[List[str]] = Field(None, description="""Part instances used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'part_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:material_store/PartInstance'} })
    labware_instances: Optional[List[str]] = Field(None, description="""Labware instances used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'labware_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:material_store/LabwareInstance'} })
    device_instances: Optional[List[str]] = Field(None, description="""Devices used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'device_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:material_store/DeviceInstance'} })
    device_setup_instances: Optional[List[str]] = Field(None, description="""DeviceSetup instances used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'device_setup_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:material_store/DeviceSetupInstance'} })
    organism_instances: Optional[List[str]] = Field(None, description="""Organism instances used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'organism_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:organisms-store/OrganismInstance'} })
    samples: Optional[List[str]] = Field(None, description="""Samples used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'samples',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:samples/Sample'} })
    sample_sets: Optional[List[str]] = Field(None, description="""SampleSets used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'sample_sets',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:samples/SampleSet'} })
    creators: Optional[List[str]] = Field(None, description="""creators of method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'creators',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:people/Entity'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:base/ExternalResource'} })
    data_extra: Optional[List[str]] = Field(None, description="""e.g. manual""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ExtraData'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Tag'} })


class MethodInstancesSubset(ConfiguredBaseModel):
    """
    \" A subset of method instances, e.g. all method instances for a certain lab, or all method instances for a certain project, ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/MethodInstancesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/MethodInstancesSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/MethodInstancesSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['MethodsSubset',
                       'ProceduresSubset',
                       'ProcessesSubset',
                       'MethodInstancesSubset',
                       'ProcedureInstancesSubset',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['MethodsSubset',
                       'ProceduresSubset',
                       'ProcessesSubset',
                       'MethodInstancesSubset',
                       'ProcedureInstancesSubset',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/MethodInstancesSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/MethodInstancesSubset/datetime_last_modified'} })
    methodinstancessubset_id: Optional[str] = Field(None, description="""MethodInstancesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'methodinstancessubset_id',
         'domain_of': ['MethodInstancesSubset'],
         'slot_uri': 'lara:processes/MethodInstancesSubset/methodinstancessubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Tag'} })
    method_instances: Optional[List[str]] = Field(None, description="""all method instances of a subset""", json_schema_extra = { "linkml_meta": {'alias': 'method_instances',
         'domain_of': ['MethodInstancesSubset'],
         'slot_uri': 'lara:processes/MethodInstance'} })


class OrderedMethodInstancesSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between MethodInstancesSubset and MethodInstance.
        This class can be used to store the order of method instances in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/OrderedMethodInstancesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    orderedmethodssubset_id: Optional[str] = Field(None, description="""OrderedMethodInstancesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedmethodssubset_id',
         'domain_of': ['OrderedMethodsSubset', 'OrderedMethodInstancesSubset'],
         'slot_uri': 'lara:processes/OrderedMethodInstancesSubset/orderedmethodssubset_id'} })
    method_instance: str = Field(..., description="""method instance in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'method_instance',
         'domain_of': ['OrderedMethodInstancesSubset'],
         'slot_uri': 'lara:processes/MethodInstance'} })
    method_instances_subset: str = Field(..., description="""subset of method instances""", json_schema_extra = { "linkml_meta": {'alias': 'method_instances_subset',
         'domain_of': ['OrderedMethodInstancesSubset'],
         'slot_uri': 'lara:processes/MethodInstancesSubset'} })
    order: int = Field(..., description="""order of method instance in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedMethodsSubset',
                       'OrderedProceduresSubset',
                       'OrderedProcedures',
                       'OrderedProcessesSubset',
                       'OrderedMethodInstancesSubset',
                       'OrderedProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'OrderedProcedureInstances',
                       'OrderedProcessInstancesSubset'],
         'slot_uri': 'lara:processes/OrderedMethodInstancesSubset/order'} })


class ProcedureInstance(ConfiguredBaseModel):
    """
    \" A procedure is a (defined) sequence of actions leading to a certain result,
        e.g. the sequence of gradient steps in an HPLC measurement,
             a sequence of transfer steps on a liquid handler, an enzyme assay ...
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/ProcedureInstance',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    namespace: Optional[str] = Field(None, description="""namespace of method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""human readable name of the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstance/name_display'} })
    name: Optional[str] = Field(None, description="""name of the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstance/name'} })
    uri: Optional[str] = Field(None, description="""Uniform Resource Identifier to locate method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'uri',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstance/uri'} })
    version: Optional[str] = Field(None, description="""maj.min.patch version of this method/procedure/process, e.g. 0.2.3""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstance/version'} })
    datetime_start: Optional[str] = Field(None, description="""date and time when the Method/Produre/Process was started""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_start',
         'domain_of': ['MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstance/datetime_start'} })
    datetime_end: Optional[str] = Field(None, description="""date and time when the Method/Produre/Process was finished""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_end',
         'domain_of': ['MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstance/datetime_end'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when the Method/Produre/Process was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstance/datetime_last_modified'} })
    parameters: Optional[dict] = Field(None, description="""method/procedure/process parameters""", json_schema_extra = { "linkml_meta": {'alias': 'parameters',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstance/parameters'} })
    status: Optional[str] = Field(None, description="""state of the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'status',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:base/ItemStatus'} })
    icon: Optional[str] = Field(None, description="""XML/SVG icon / symbol of the method""", json_schema_extra = { "linkml_meta": {'alias': 'icon',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstance/icon'} })
    media_type: Optional[str] = Field(None, description="""file type of method file""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['ExtraData',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:base/MediaType'} })
    description: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstance/description'} })
    remarks: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstance/remarks'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstance/iri'} })
    pid: Optional[str] = Field(None, description="""Persitent Identifier [PID/handle URI](https://www.handle.net/)""", json_schema_extra = { "linkml_meta": {'alias': 'pid',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstance/pid'} })
    procedureinstance_id: Optional[str] = Field(None, description="""ProcedureInstance - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'procedureinstance_id',
         'domain_of': ['ProcedureInstance'],
         'slot_uri': 'lara:processes/ProcedureInstance/procedureinstance_id'} })
    procedure_base: Optional[str] = Field(None, description="""reference to abstract procedure""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_base',
         'domain_of': ['ProcedureInstance'],
         'slot_uri': 'lara:processes/Procedure'} })
    procedure_json: Optional[dict] = Field(None, description="""Procedure JSON representation""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_json',
         'domain_of': ['Procedure', 'ProcedureInstance'],
         'slot_uri': 'lara:processes/ProcedureInstance/procedure_json'} })
    procedure_file: Optional[str] = Field(None, description="""rel. path/filename to procedures""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_file',
         'domain_of': ['Procedure', 'ProcedureInstance'],
         'slot_uri': 'lara:processes/ProcedureInstance/procedure_file'} })
    substance_instances: Optional[List[str]] = Field(None, description="""S e.g. for chemical synthesis,""", json_schema_extra = { "linkml_meta": {'alias': 'substance_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:substances-store/SubstanceInstance'} })
    polymer_instances: Optional[List[str]] = Field(None, description="""Polymers used e.g. for sequencing """, json_schema_extra = { "linkml_meta": {'alias': 'polymer_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:substances-store/PolymerInstance'} })
    mixture_instances: Optional[List[str]] = Field(None, description="""Mixture instances used""", json_schema_extra = { "linkml_meta": {'alias': 'mixture_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:substances-store/MixtureInstance'} })
    part_instances: Optional[List[str]] = Field(None, description="""Part instances used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'part_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:material_store/PartInstance'} })
    labware_instances: Optional[List[str]] = Field(None, description="""Labware instances used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'labware_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:material_store/LabwareInstance'} })
    device_instances: Optional[List[str]] = Field(None, description="""Devices used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'device_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:material_store/DeviceInstance'} })
    device_setup_instances: Optional[List[str]] = Field(None, description="""DeviceSetup instances used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'device_setup_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:material_store/DeviceSetupInstance'} })
    organism_instances: Optional[List[str]] = Field(None, description="""Organism instances used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'organism_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:organisms-store/OrganismInstance'} })
    samples: Optional[List[str]] = Field(None, description="""Samples used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'samples',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:samples/Sample'} })
    sample_sets: Optional[List[str]] = Field(None, description="""SampleSets used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'sample_sets',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:samples/SampleSet'} })
    creators: Optional[List[str]] = Field(None, description="""creators of method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'creators',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:people/Entity'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:base/ExternalResource'} })
    data_extra: Optional[List[str]] = Field(None, description="""e.g. manual""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ExtraData'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Tag'} })


class ProcedureInstancesSubset(ConfiguredBaseModel):
    """
    \" A subset of procedure instances, e.g. all procedure instances for a certain lab, or all procedure instances for a certain project, ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/ProcedureInstancesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstancesSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstancesSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['MethodsSubset',
                       'ProceduresSubset',
                       'ProcessesSubset',
                       'MethodInstancesSubset',
                       'ProcedureInstancesSubset',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['MethodsSubset',
                       'ProceduresSubset',
                       'ProcessesSubset',
                       'MethodInstancesSubset',
                       'ProcedureInstancesSubset',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstancesSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstancesSubset/datetime_last_modified'} })
    procedureinstancessubset_id: Optional[str] = Field(None, description="""ProcedureInstancesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'procedureinstancessubset_id',
         'domain_of': ['ProcedureInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstancesSubset/procedureinstancessubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Tag'} })
    procedure_instances: Optional[List[str]] = Field(None, description="""all procedure instances of a subset""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_instances',
         'domain_of': ['ProcedureInstancesSubset', 'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstance'} })


class OrderedProcedureInstancesSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between ProcedureInstancesSubset and ProcedureInstance.
        This class can be used to store the order of procedure instances in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/OrderedProcedureInstancesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    orderedproceduressubset_id: Optional[str] = Field(None, description="""OrderedProcedureInstancesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedproceduressubset_id',
         'domain_of': ['OrderedProceduresSubset', 'OrderedProcedureInstancesSubset'],
         'slot_uri': 'lara:processes/OrderedProcedureInstancesSubset/orderedproceduressubset_id'} })
    procedure_instance: str = Field(..., description="""procedure instance in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_instance',
         'domain_of': ['OrderedProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'OrderedProcedureInstances'],
         'slot_uri': 'lara:processes/ProcedureInstance'} })
    procedure_instances_subset: str = Field(..., description="""subset of procedure instances""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_instances_subset',
         'domain_of': ['OrderedProcedureInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstancesSubset'} })
    order: int = Field(..., description="""order of procedure instance in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedMethodsSubset',
                       'OrderedProceduresSubset',
                       'OrderedProcedures',
                       'OrderedProcessesSubset',
                       'OrderedMethodInstancesSubset',
                       'OrderedProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'OrderedProcedureInstances',
                       'OrderedProcessInstancesSubset'],
         'slot_uri': 'lara:processes/OrderedProcedureInstancesSubset/order'} })


class ProcedureInstanceStepClass(ConfiguredBaseModel):
    """
    \" Class / Type of a step in a procedure instance, e.g., operation, move, transfer, decision, computation ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/ProcedureInstanceStepClass',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    procedureinstancestepclass_id: Optional[str] = Field(None, description="""ProcedureInstanceStepClass - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'procedureinstancestepclass_id',
         'domain_of': ['ProcedureInstanceStepClass'],
         'slot_uri': 'lara:processes/ProcedureInstanceStepClass/procedureinstancestepclass_id'} })
    name: str = Field(..., description="""name of step class, e.g. move, transfer, decision, computation ...""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstanceStepClass/name'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstanceStepClass/iri'} })
    description: Optional[str] = Field(None, description="""description of step class""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstanceStepClass/description'} })


class ProcedureInstanceStep(ConfiguredBaseModel):
    """
    \" Step in a procedure instance. This can be used to track the execution of a procedure instance,
        e.g. in a lab, or in a simulation.
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/ProcedureInstanceStep',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    procedureinstancestep_id: Optional[str] = Field(None, description="""ProcedureInstanceStep - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'procedureinstancestep_id',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:processes/ProcedureInstanceStep/procedureinstancestep_id'} })
    name: Optional[str] = Field(None, description="""name of the step""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstanceStep/name'} })
    step_class: Optional[str] = Field(None, description="""class of the step""", json_schema_extra = { "linkml_meta": {'alias': 'step_class',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:processes/ProcedureInstanceStepClass'} })
    datetime_start: Optional[str] = Field(None, description="""start datetime of step""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_start',
         'domain_of': ['MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstanceStep/datetime_start'} })
    datetime_end: Optional[str] = Field(None, description="""end datetime of step""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_end',
         'domain_of': ['MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstanceStep/datetime_end'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstanceStep/datetime_last_modified'} })
    procedure_instance: Optional[str] = Field(None, description="""reference to procedure instance""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_instance',
         'domain_of': ['OrderedProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'OrderedProcedureInstances'],
         'slot_uri': 'lara:processes/ProcedureInstance'} })
    part_instance: Optional[str] = Field(None, description="""reference to part instance""", json_schema_extra = { "linkml_meta": {'alias': 'part_instance',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:material_store/PartInstance'} })
    device_instance: Optional[str] = Field(None, description="""reference to device instance""", json_schema_extra = { "linkml_meta": {'alias': 'device_instance',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:material_store/DeviceInstance'} })
    device_setup_instance: Optional[str] = Field(None, description="""reference to device setup instance""", json_schema_extra = { "linkml_meta": {'alias': 'device_setup_instance',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:material_store/DeviceSetupInstance'} })
    labware_instance: Optional[str] = Field(None, description="""reference to labware instance""", json_schema_extra = { "linkml_meta": {'alias': 'labware_instance',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:material_store/LabwareInstance'} })
    organism_instance: Optional[str] = Field(None, description="""reference to organism instance""", json_schema_extra = { "linkml_meta": {'alias': 'organism_instance',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:organisms-store/OrganismInstance'} })
    sample: Optional[str] = Field(None, description="""reference to sample""", json_schema_extra = { "linkml_meta": {'alias': 'sample',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:samples/Sample'} })
    sample_set: Optional[str] = Field(None, description="""reference to sample set""", json_schema_extra = { "linkml_meta": {'alias': 'sample_set',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:samples/SampleSet'} })
    parameters: Optional[dict] = Field(None, description="""method/procedure/process parameters""", json_schema_extra = { "linkml_meta": {'alias': 'parameters',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstanceStep/parameters'} })
    simulation: bool = Field(..., description="""is this a simulation step?""", json_schema_extra = { "linkml_meta": {'alias': 'simulation',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:processes/ProcedureInstanceStep/simulation'} })
    order: int = Field(..., description="""order of step in procedure instance""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedMethodsSubset',
                       'OrderedProceduresSubset',
                       'OrderedProcedures',
                       'OrderedProcessesSubset',
                       'OrderedMethodInstancesSubset',
                       'OrderedProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'OrderedProcedureInstances',
                       'OrderedProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstanceStep/order'} })


class ProcedureInstanceMoveStep(ConfiguredBaseModel):
    """
    \" ProcedureInstanceMoveStep(procedureinstancestep_id, name, step_class, datetime_start, datetime_end, datetime_last_modified, procedure_instance, part_instance, device_instance, device_setup_instance, labware_instance, organism_instance, sample, sample_set, parameters, simulation, order, procedureinstancestep_ptr, procedureinstancemovestep_id, location_start, location_end) \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/ProcedureInstanceMoveStep',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    procedureinstancestep_id: Optional[str] = Field(None, description="""ProcedureInstanceMoveStep - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'procedureinstancestep_id',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:processes/ProcedureInstanceMoveStep/procedureinstancestep_id'} })
    name: Optional[str] = Field(None, description="""name of the step""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstanceMoveStep/name'} })
    step_class: Optional[str] = Field(None, description="""class of the step""", json_schema_extra = { "linkml_meta": {'alias': 'step_class',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:processes/ProcedureInstanceStepClass'} })
    datetime_start: Optional[str] = Field(None, description="""start datetime of step""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_start',
         'domain_of': ['MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstanceMoveStep/datetime_start'} })
    datetime_end: Optional[str] = Field(None, description="""end datetime of step""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_end',
         'domain_of': ['MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstanceMoveStep/datetime_end'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstanceMoveStep/datetime_last_modified'} })
    procedure_instance: Optional[str] = Field(None, description="""reference to procedure instance""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_instance',
         'domain_of': ['OrderedProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'OrderedProcedureInstances'],
         'slot_uri': 'lara:processes/ProcedureInstance'} })
    part_instance: Optional[str] = Field(None, description="""reference to part instance""", json_schema_extra = { "linkml_meta": {'alias': 'part_instance',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:material_store/PartInstance'} })
    device_instance: Optional[str] = Field(None, description="""reference to device instance""", json_schema_extra = { "linkml_meta": {'alias': 'device_instance',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:material_store/DeviceInstance'} })
    device_setup_instance: Optional[str] = Field(None, description="""reference to device setup instance""", json_schema_extra = { "linkml_meta": {'alias': 'device_setup_instance',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:material_store/DeviceSetupInstance'} })
    labware_instance: Optional[str] = Field(None, description="""reference to labware instance""", json_schema_extra = { "linkml_meta": {'alias': 'labware_instance',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:material_store/LabwareInstance'} })
    organism_instance: Optional[str] = Field(None, description="""reference to organism instance""", json_schema_extra = { "linkml_meta": {'alias': 'organism_instance',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:organisms-store/OrganismInstance'} })
    sample: Optional[str] = Field(None, description="""reference to sample""", json_schema_extra = { "linkml_meta": {'alias': 'sample',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:samples/Sample'} })
    sample_set: Optional[str] = Field(None, description="""reference to sample set""", json_schema_extra = { "linkml_meta": {'alias': 'sample_set',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:samples/SampleSet'} })
    parameters: Optional[dict] = Field(None, description="""method/procedure/process parameters""", json_schema_extra = { "linkml_meta": {'alias': 'parameters',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstanceMoveStep/parameters'} })
    simulation: bool = Field(..., description="""is this a simulation step?""", json_schema_extra = { "linkml_meta": {'alias': 'simulation',
         'domain_of': ['ProcedureInstanceStep', 'ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:processes/ProcedureInstanceMoveStep/simulation'} })
    order: int = Field(..., description="""order of step in procedure instance""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedMethodsSubset',
                       'OrderedProceduresSubset',
                       'OrderedProcedures',
                       'OrderedProcessesSubset',
                       'OrderedMethodInstancesSubset',
                       'OrderedProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'OrderedProcedureInstances',
                       'OrderedProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcedureInstanceMoveStep/order'} })
    procedureinstancestep_ptr: str = Field(..., json_schema_extra = { "linkml_meta": {'alias': 'procedureinstancestep_ptr',
         'domain_of': ['ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:processes/ProcedureInstanceStep'} })
    procedureinstancemovestep_id: Optional[str] = Field(None, description="""ProcedureInstanceMoveStep - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'procedureinstancemovestep_id',
         'domain_of': ['ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:processes/ProcedureInstanceMoveStep/procedureinstancemovestep_id'} })
    location_start: Optional[str] = Field(None, description="""location of step start""", json_schema_extra = { "linkml_meta": {'alias': 'location_start',
         'domain_of': ['ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:base/Location'} })
    location_end: Optional[str] = Field(None, description="""location of step end""", json_schema_extra = { "linkml_meta": {'alias': 'location_end',
         'domain_of': ['ProcedureInstanceMoveStep'],
         'slot_uri': 'lara:base/Location'} })


class ProcessInstance(ConfiguredBaseModel):
    """
    \" A process is a combination of various procedures and decisions,
        e.g. a robot process, a fermentation process, ....
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/ProcessInstance',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    namespace: Optional[str] = Field(None, description="""namespace of method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""human readable name of the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessInstance/name_display'} })
    name: Optional[str] = Field(None, description="""name of the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessInstance/name'} })
    uri: Optional[str] = Field(None, description="""Uniform Resource Identifier to locate method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'uri',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcessInstance/uri'} })
    version: Optional[str] = Field(None, description="""maj.min.patch version of this method/procedure/process, e.g. 0.2.3""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcessInstance/version'} })
    datetime_start: Optional[str] = Field(None, description="""date and time when the Method/Produre/Process was started""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_start',
         'domain_of': ['MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcessInstance/datetime_start'} })
    datetime_end: Optional[str] = Field(None, description="""date and time when the Method/Produre/Process was finished""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_end',
         'domain_of': ['MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcessInstance/datetime_end'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when the Method/Produre/Process was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessInstance/datetime_last_modified'} })
    parameters: Optional[dict] = Field(None, description="""method/procedure/process parameters""", json_schema_extra = { "linkml_meta": {'alias': 'parameters',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcessInstance/parameters'} })
    status: Optional[str] = Field(None, description="""state of the method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'status',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:base/ItemStatus'} })
    icon: Optional[str] = Field(None, description="""XML/SVG icon / symbol of the method""", json_schema_extra = { "linkml_meta": {'alias': 'icon',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcessInstance/icon'} })
    media_type: Optional[str] = Field(None, description="""file type of method file""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['ExtraData',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:base/MediaType'} })
    description: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessInstance/description'} })
    remarks: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'remarks',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcessInstance/remarks'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcessInstance/iri'} })
    pid: Optional[str] = Field(None, description="""Persitent Identifier [PID/handle URI](https://www.handle.net/)""", json_schema_extra = { "linkml_meta": {'alias': 'pid',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcessInstance/pid'} })
    processinstance_id: Optional[str] = Field(None, description="""ProcessInstance - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'processinstance_id',
         'domain_of': ['ProcessInstance'],
         'slot_uri': 'lara:processes/ProcessInstance/processinstance_id'} })
    process_base: Optional[str] = Field(None, description="""reference to abstract process""", json_schema_extra = { "linkml_meta": {'alias': 'process_base',
         'domain_of': ['ProcessInstance'],
         'slot_uri': 'lara:processes/Process'} })
    process_json: Optional[dict] = Field(None, description="""Process JSON representation""", json_schema_extra = { "linkml_meta": {'alias': 'process_json',
         'domain_of': ['Process', 'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcessInstance/process_json'} })
    process_file: Optional[str] = Field(None, description="""rel. path/filename to processes""", json_schema_extra = { "linkml_meta": {'alias': 'process_file',
         'domain_of': ['Process', 'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcessInstance/process_file'} })
    substance_instances: Optional[List[str]] = Field(None, description="""S e.g. for chemical synthesis,""", json_schema_extra = { "linkml_meta": {'alias': 'substance_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:substances-store/SubstanceInstance'} })
    polymer_instances: Optional[List[str]] = Field(None, description="""Polymers used e.g. for sequencing """, json_schema_extra = { "linkml_meta": {'alias': 'polymer_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:substances-store/PolymerInstance'} })
    mixture_instances: Optional[List[str]] = Field(None, description="""Mixture instances used""", json_schema_extra = { "linkml_meta": {'alias': 'mixture_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:substances-store/MixtureInstance'} })
    part_instances: Optional[List[str]] = Field(None, description="""Part instances used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'part_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:material_store/PartInstance'} })
    labware_instances: Optional[List[str]] = Field(None, description="""Labware instances used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'labware_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:material_store/LabwareInstance'} })
    device_instances: Optional[List[str]] = Field(None, description="""Devices used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'device_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:material_store/DeviceInstance'} })
    device_setup_instances: Optional[List[str]] = Field(None, description="""DeviceSetup instances used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'device_setup_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:material_store/DeviceSetupInstance'} })
    organism_instances: Optional[List[str]] = Field(None, description="""Organism instances used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'organism_instances',
         'domain_of': ['MethodInstance', 'ProcedureInstance', 'ProcessInstance'],
         'slot_uri': 'lara:organisms-store/OrganismInstance'} })
    samples: Optional[List[str]] = Field(None, description="""Samples used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'samples',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:samples/Sample'} })
    sample_sets: Optional[List[str]] = Field(None, description="""SampleSets used in this method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'sample_sets',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:samples/SampleSet'} })
    creators: Optional[List[str]] = Field(None, description="""creators of method/procedure/process""", json_schema_extra = { "linkml_meta": {'alias': 'creators',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:people/Entity'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:base/ExternalResource'} })
    data_extra: Optional[List[str]] = Field(None, description="""e.g. manual""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['Method',
                       'Procedure',
                       'Process',
                       'MethodInstance',
                       'ProcedureInstance',
                       'ProcessInstance'],
         'slot_uri': 'lara:processes/ExtraData'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Tag'} })
    procedure_instances: Optional[List[str]] = Field(None, description="""all procedures of a process""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_instances',
         'domain_of': ['ProcedureInstancesSubset', 'ProcessInstance'],
         'slot_uri': 'lara:processes/ProcedureInstance'} })


class OrderedProcedureInstances(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between ProcessInstance and ProcedureInstance.
        This class can be used
        to store the order of procedure instances in a process instance
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/OrderedProcedureInstances',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    orderedprocedureinstances_id: Optional[str] = Field(None, description="""OrderedProcedureInstances - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedprocedureinstances_id',
         'domain_of': ['OrderedProcedureInstances'],
         'slot_uri': 'lara:processes/OrderedProcedureInstances/orderedprocedureinstances_id'} })
    process_instance: str = Field(..., description="""process instance""", json_schema_extra = { "linkml_meta": {'alias': 'process_instance',
         'domain_of': ['OrderedProcedureInstances', 'OrderedProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessInstance'} })
    procedure_instance: str = Field(..., description="""procedure instance in the process instance""", json_schema_extra = { "linkml_meta": {'alias': 'procedure_instance',
         'domain_of': ['OrderedProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'OrderedProcedureInstances'],
         'slot_uri': 'lara:processes/ProcedureInstance'} })
    order: int = Field(..., description="""order of procedure instance in process instance""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedMethodsSubset',
                       'OrderedProceduresSubset',
                       'OrderedProcedures',
                       'OrderedProcessesSubset',
                       'OrderedMethodInstancesSubset',
                       'OrderedProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'OrderedProcedureInstances',
                       'OrderedProcessInstancesSubset'],
         'slot_uri': 'lara:processes/OrderedProcedureInstances/order'} })


class ProcessInstancesSubset(ConfiguredBaseModel):
    """
    \" A subset of process instances, e.g. all process instances for a certain lab, or all process instances for a certain project, ... \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/ProcessInstancesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessInstancesSubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessInstancesSubset/name'} })
    entity: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['MethodsSubset',
                       'ProceduresSubset',
                       'ProcessesSubset',
                       'MethodInstancesSubset',
                       'ProcedureInstancesSubset',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:people/Entity'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['MethodsSubset',
                       'ProceduresSubset',
                       'ProcessesSubset',
                       'MethodInstancesSubset',
                       'ProcedureInstancesSubset',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:people/Group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData',
                       'MethodClass',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStepClass',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessInstancesSubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessInstancesSubset/datetime_last_modified'} })
    processinstancessubset_id: Optional[str] = Field(None, description="""ProcessInstancesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'processinstancessubset_id',
         'domain_of': ['ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessInstancesSubset/processinstancessubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['Method',
                       'MethodsSubset',
                       'Procedure',
                       'ProceduresSubset',
                       'Process',
                       'ProcessesSubset',
                       'MethodInstance',
                       'MethodInstancesSubset',
                       'ProcedureInstance',
                       'ProcedureInstancesSubset',
                       'ProcessInstance',
                       'ProcessInstancesSubset'],
         'slot_uri': 'lara:base/Tag'} })
    process_instances: Optional[List[str]] = Field(None, description="""all process instances of a subset""", json_schema_extra = { "linkml_meta": {'alias': 'process_instances',
         'domain_of': ['ProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessInstance'} })


class OrderedProcessInstancesSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between ProcessInstancesSubset and ProcessInstance.
        This class can be used to store the order of process instances in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:processes/OrderedProcessInstancesSubset',
         'from_schema': 'https://w3id.org/lara/lara_django_processes'})

    orderedprocessinstancessubset_id: Optional[str] = Field(None, description="""OrderedProcessInstancesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedprocessinstancessubset_id',
         'domain_of': ['OrderedProcessInstancesSubset'],
         'slot_uri': 'lara:processes/OrderedProcessInstancesSubset/orderedprocessinstancessubset_id'} })
    process_instance: str = Field(..., description="""process instance in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'process_instance',
         'domain_of': ['OrderedProcedureInstances', 'OrderedProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessInstance'} })
    process_instances_subset: str = Field(..., description="""subset of process instances""", json_schema_extra = { "linkml_meta": {'alias': 'process_instances_subset',
         'domain_of': ['OrderedProcessInstancesSubset'],
         'slot_uri': 'lara:processes/ProcessInstancesSubset'} })
    order: int = Field(..., description="""order of process instance in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedMethodsSubset',
                       'OrderedProceduresSubset',
                       'OrderedProcedures',
                       'OrderedProcessesSubset',
                       'OrderedMethodInstancesSubset',
                       'OrderedProcedureInstancesSubset',
                       'ProcedureInstanceStep',
                       'ProcedureInstanceMoveStep',
                       'OrderedProcedureInstances',
                       'OrderedProcessInstancesSubset'],
         'slot_uri': 'lara:processes/OrderedProcessInstancesSubset/order'} })


class Container(ConfiguredBaseModel):
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_processes',
         'tree_root': True})

    extradatas: Optional[List[ExtraData]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'extradatas', 'domain_of': ['Container']} })
    methodclasss: Optional[List[MethodClass]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'methodclasss', 'domain_of': ['Container']} })
    methods: Optional[List[Method]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'methods', 'domain_of': ['MethodsSubset', 'Container']} })
    methodssubsets: Optional[List[MethodsSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'methodssubsets', 'domain_of': ['Container']} })
    orderedmethodssubsets: Optional[List[OrderedMethodsSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedmethodssubsets', 'domain_of': ['Container']} })
    procedures: Optional[List[Procedure]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'procedures',
         'domain_of': ['ProceduresSubset', 'Process', 'Container']} })
    proceduressubsets: Optional[List[ProceduresSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'proceduressubsets', 'domain_of': ['Container']} })
    orderedproceduressubsets: Optional[List[OrderedProceduresSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedproceduressubsets', 'domain_of': ['Container']} })
    processs: Optional[List[Process]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'processs', 'domain_of': ['Container']} })
    orderedproceduress: Optional[List[OrderedProcedures]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedproceduress', 'domain_of': ['Container']} })
    processessubsets: Optional[List[ProcessesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'processessubsets', 'domain_of': ['Container']} })
    orderedprocessessubsets: Optional[List[OrderedProcessesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedprocessessubsets', 'domain_of': ['Container']} })
    methodinstances: Optional[List[MethodInstance]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'methodinstances', 'domain_of': ['Container']} })
    methodinstancessubsets: Optional[List[MethodInstancesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'methodinstancessubsets', 'domain_of': ['Container']} })
    orderedmethodinstancessubsets: Optional[List[OrderedMethodInstancesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedmethodinstancessubsets', 'domain_of': ['Container']} })
    procedureinstances: Optional[List[ProcedureInstance]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'procedureinstances', 'domain_of': ['Container']} })
    procedureinstancessubsets: Optional[List[ProcedureInstancesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'procedureinstancessubsets', 'domain_of': ['Container']} })
    orderedprocedureinstancessubsets: Optional[List[OrderedProcedureInstancesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedprocedureinstancessubsets', 'domain_of': ['Container']} })
    procedureinstancestepclasss: Optional[List[ProcedureInstanceStepClass]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'procedureinstancestepclasss', 'domain_of': ['Container']} })
    procedureinstancesteps: Optional[List[ProcedureInstanceStep]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'procedureinstancesteps', 'domain_of': ['Container']} })
    procedureinstancemovesteps: Optional[List[ProcedureInstanceMoveStep]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'procedureinstancemovesteps', 'domain_of': ['Container']} })
    processinstances: Optional[List[ProcessInstance]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'processinstances', 'domain_of': ['Container']} })
    orderedprocedureinstancess: Optional[List[OrderedProcedureInstances]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedprocedureinstancess', 'domain_of': ['Container']} })
    processinstancessubsets: Optional[List[ProcessInstancesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'processinstancessubsets', 'domain_of': ['Container']} })
    orderedprocessinstancessubsets: Optional[List[OrderedProcessInstancesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedprocessinstancessubsets', 'domain_of': ['Container']} })


# Model rebuild
# see https://pydantic-docs.helpmanual.io/usage/models/#rebuilding-a-model
Polymer.model_rebuild()
DeviceSetupInstance.model_rebuild()
ExternalResource.model_rebuild()
MixtureInstance.model_rebuild()
Location.model_rebuild()
Tag.model_rebuild()
ItemStatus.model_rebuild()
Mixture.model_rebuild()
DeviceSetup.model_rebuild()
LabwareInstance.model_rebuild()
Labware.model_rebuild()
SampleSet.model_rebuild()
Substance.model_rebuild()
Group.model_rebuild()
PartInstance.model_rebuild()
Namespace.model_rebuild()
MediaType.model_rebuild()
Entity.model_rebuild()
OrganismInstance.model_rebuild()
PolymerInstance.model_rebuild()
DataType.model_rebuild()
Organism.model_rebuild()
DeviceInstance.model_rebuild()
Part.model_rebuild()
Sample.model_rebuild()
Device.model_rebuild()
SubstanceInstance.model_rebuild()
ExtraData.model_rebuild()
MethodClass.model_rebuild()
Method.model_rebuild()
MethodsSubset.model_rebuild()
OrderedMethodsSubset.model_rebuild()
Procedure.model_rebuild()
ProceduresSubset.model_rebuild()
OrderedProceduresSubset.model_rebuild()
Process.model_rebuild()
OrderedProcedures.model_rebuild()
ProcessesSubset.model_rebuild()
OrderedProcessesSubset.model_rebuild()
MethodInstance.model_rebuild()
MethodInstancesSubset.model_rebuild()
OrderedMethodInstancesSubset.model_rebuild()
ProcedureInstance.model_rebuild()
ProcedureInstancesSubset.model_rebuild()
OrderedProcedureInstancesSubset.model_rebuild()
ProcedureInstanceStepClass.model_rebuild()
ProcedureInstanceStep.model_rebuild()
ProcedureInstanceMoveStep.model_rebuild()
ProcessInstance.model_rebuild()
OrderedProcedureInstances.model_rebuild()
ProcessInstancesSubset.model_rebuild()
OrderedProcessInstancesSubset.model_rebuild()
Container.model_rebuild()

