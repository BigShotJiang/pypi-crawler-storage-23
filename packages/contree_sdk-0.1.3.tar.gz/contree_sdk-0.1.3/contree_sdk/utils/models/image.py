from enum import IntEnum


class ImageKind(IntEnum):
    INSTANCES = 0
    IMPORTED = 1
