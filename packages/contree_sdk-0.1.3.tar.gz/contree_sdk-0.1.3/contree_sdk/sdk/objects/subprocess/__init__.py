from contree_sdk.sdk.objects.subprocess._sync import ContreeProcessSync


__all__ = [
    "ContreeProcessSync",
]
