from contree_sdk.sdk.objects.image_like._base import _ImageLikeBase


class _ContreeImageBase(_ImageLikeBase): ...
