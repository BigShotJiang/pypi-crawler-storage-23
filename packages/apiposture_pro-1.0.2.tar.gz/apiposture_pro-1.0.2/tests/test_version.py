"""Test version information."""

import apiposture_pro


def test_version() -> None:
    """Test version is defined."""
    assert apiposture_pro.__version__ == "1.0.0"


def test_exports() -> None:
    """Test package exports."""
    assert hasattr(apiposture_pro, "ProLicenseManager")
    assert hasattr(apiposture_pro, "LicenseContext")
    assert hasattr(apiposture_pro, "StoredLicense")
