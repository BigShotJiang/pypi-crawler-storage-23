"""Extension deployer for ApiPosturePro."""

import shutil
from pathlib import Path


class ExtensionDeployer:
    """Deploys Pro package as extension for free version."""

    EXTENSION_DIR = Path.home() / ".apiposture" / "extensions" / "ApiPosturePro"

    def __init__(self) -> None:
        """Initialize extension deployer."""
        self.package_path = self._find_package_path()

    def deploy(self) -> None:
        """Deploy Pro package to extensions directory."""
        if not self.package_path:
            raise RuntimeError("Could not find apiposture_pro package")

        # Create extension directory
        self.EXTENSION_DIR.mkdir(parents=True, exist_ok=True)

        # Copy package files
        target_path = self.EXTENSION_DIR / "apiposture_pro"
        if target_path.exists():
            shutil.rmtree(target_path)

        shutil.copytree(self.package_path, target_path)

    def undeploy(self) -> None:
        """Remove Pro extension."""
        if self.EXTENSION_DIR.exists():
            shutil.rmtree(self.EXTENSION_DIR)

    def is_deployed(self) -> bool:
        """Check if Pro extension is deployed."""
        return (self.EXTENSION_DIR / "apiposture_pro").exists()

    def _find_package_path(self) -> Path | None:
        """Find installed apiposture_pro package path."""
        try:
            import apiposture_pro

            package_file = apiposture_pro.__file__
            if package_file:
                return Path(package_file).parent
        except ImportError:
            pass

        return None
