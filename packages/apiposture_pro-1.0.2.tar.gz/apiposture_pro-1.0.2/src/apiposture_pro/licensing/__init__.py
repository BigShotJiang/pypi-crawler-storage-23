"""License management for ApiPosturePro."""
