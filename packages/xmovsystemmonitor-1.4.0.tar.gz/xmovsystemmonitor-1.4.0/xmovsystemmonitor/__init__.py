"""系统监控工具 - 获取CPU和内存使用率"""

__version__ = "1.4.0"

"""
changelog:
- 1.4.0: add GPU statistic
- 1.3.9: args.interval to background_thread.interval
- 1.3.8: fix use memory_used to calculate statistic
- 1.3.6: fix get_memory_used()
- 1.3.5: add Client.is_alive()
- 1.3.4: 添加ping API, fix
- 1.3.3: 添加ping API
- 1.3.2: client.py增加try-except处理
- 1.3.1: 添加异步客户端
- 1.3.0: 添加客户端
- 1.2.0: 添加系统信息采集线程
- 1.1.0: 添加系统信息采集
- 1.0.0: 初始版本
"""