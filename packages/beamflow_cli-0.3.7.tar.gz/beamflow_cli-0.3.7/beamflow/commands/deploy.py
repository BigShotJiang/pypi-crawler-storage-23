from typing import Optional
import asyncio
import typer
from pathlib import Path
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from ..core.api_client import APIClient
from ..core.config import load_project_config
from .build import run_build_flow

app = typer.Typer()
console = Console()

# Status labels shown to the user while polling
_STATUS_LABELS = {
    "QUEUED":         "Queued, waiting for deployment to start...",
    "DEPLOYING":      "Deploying services to Cloud Run...",
    "INIT_PENDING":   "Waiting for worker to register scheduled tasks...",
    "INIT_RECEIVED":  "Tasks registered, running health checks...",
    "HEALTH_CHECK":   "Health-checking API and Worker...",
    "DEPLOYED":       "Deployed successfully ✓",
    "FAILED":         "Deployment failed.",
}

_TERMINAL_STATUSES = {"DEPLOYED", "FAILED"}


async def run_deploy_flow(env: str, artifact_id: Optional[str] = None):
    project_config = load_project_config()
    if not project_config:
        console.print("[red]No .beamflow found. Please run 'beamflow init' first.[/red]")
        raise typer.Exit(code=1)

    project_id = project_config.project_id
    if not project_id:
        console.print("[red]project_id not found in .beamflow[/red]")
        raise typer.Exit(code=1)

    api = APIClient()

    # 1. If artifact_id is not provided, run build first
    if not artifact_id:
        console.print("No artifact ID provided. Building first...")
        build_result = await run_build_flow()
        artifact_id = build_result["artifact_id"]
        console.print(f"Build finished. Deploying artifact: [bold]{artifact_id}[/bold]")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        # 2. Trigger deployment
        task = progress.add_task(description="Triggering deployment...", total=None)
        deploy_data = await api.post("/v1/deploy", json={
            "project_id": project_id,
            "artifact_id": artifact_id,
            "env_vars": {"ENVIRONMENT": env}
        })
        deploy_id = deploy_data["deploy_id"]
        progress.update(task, description=f"Deployment triggered (ID: {deploy_id}).")

        # 3. Poll status until terminal
        last_status = None
        while True:
            status_data = await api.get(f"/v1/deploy/{deploy_id}/status")
            current_status = status_data["status"]

            if current_status != last_status:
                label = _STATUS_LABELS.get(current_status, f"Status: {current_status}")
                progress.update(task, description=label)
                last_status = current_status

            if current_status == "DEPLOYED":
                break
            elif current_status == "FAILED":
                error = status_data.get("error_message", "Unknown error")
                console.print(f"[red]Deployment failed: {error}[/red]")
                raise typer.Exit(code=1)

            await asyncio.sleep(5)

    return status_data


@app.command()
def deploy(
    env: str = typer.Argument(..., help="Environment to deploy to"),
    artifact: Optional[str] = typer.Option(None, "--artifact", "-a", help="Artifact ID to deploy"),
    non_interactive: bool = typer.Option(False, "--non-interactive", help="Do not ask for confirmation")
):
    """Deploy an artifact to the managed platform for a specified environment."""
    project_config = load_project_config()
    if not project_config:
        console.print("[red]No .beamflow found. Please run 'beamflow init' first.[/red]")
        raise typer.Exit(code=1)

    # Ask for confirmation unless non-interactive is provided
    if not non_interactive:
        from rich.prompt import Confirm
        if not Confirm.ask(f"Are you sure you want to deploy to '{env}'?"):
            console.print("Deployment cancelled.")
            raise typer.Exit(code=0)

    # Check if env is managed
    is_managed = False
    for em in project_config.environments:
        if em.name == env:
            is_managed = em.managed
            break

    if not is_managed:
        console.print(f"[red]Environment '{env}' is not managed. Deployment is only supported for managed environments.[/red]")
        console.print("[yellow]Update your .beamflow environments if this is incorrect.[/yellow]")
        raise typer.Exit(code=1)

    project_id = project_config.project_id
    if not project_id:
        if not non_interactive:
            from rich.prompt import Confirm
            if Confirm.ask("Project ID not found. Would you like to link to a managed project now?"):
                from .project import _link_project
                _link_project(project_config)
                project_id = project_config.project_id

        if not project_id:
            console.print("[red]project_id not found in .beamflow. Use 'beamflow init' or link to a project.[/red]")
            raise typer.Exit(code=1)

    result = asyncio.run(run_deploy_flow(env, artifact))

    api_url = result.get("api_url", "")
    worker_url = result.get("worker_url", "")
    console.print(f"[green]✓ Deployment complete![/green]")
    console.print(f"  Deployment ID : [bold]{result['deploy_id']}[/bold]")
    if api_url:
        console.print(f"  API URL       : [bold]{api_url}[/bold]")
    if worker_url:
        console.print(f"  Worker URL    : [bold]{worker_url}[/bold]")
