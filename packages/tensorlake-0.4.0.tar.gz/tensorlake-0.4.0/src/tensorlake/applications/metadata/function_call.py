from typing import Any

from pydantic import BaseModel

from .collection import CollectionMetadata


class FunctionCallArgumentMetadata(BaseModel):
    # ID of Future or value from which the argument value is coming from.
    # None if the value is coming from a Collection embedded into the function
    # call argument.
    value_id: str | None
    collection: CollectionMetadata | None


class FunctionCallMetadata(BaseModel):
    # ID of the function call, uniquness guarantees depend on how the field is set.
    id: str
    # Not None if output serialization format is overridden for this function call.
    # This is used when the output of this function call is used as output of another function call
    # with a different output serializer.
    output_serializer_name_override: str | None
    # This is used when the output of this function call is used as output of another function call.
    # In this case the type hint of the outer function call are applied to the inner function call output.
    output_type_hint_override: Any
    has_output_type_hint_override: bool
    # Positional arg ix -> Arg metadata.
    args: list[FunctionCallArgumentMetadata]
    # Keyword Arg name -> Arg metadata.
    kwargs: dict[str, FunctionCallArgumentMetadata]
