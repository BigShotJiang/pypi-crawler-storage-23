"""Mags SDK - Execute scripts on Magpie's instant VM infrastructure."""

from .client import Mags

__all__ = ["Mags"]
__version__ = "1.3.0"
