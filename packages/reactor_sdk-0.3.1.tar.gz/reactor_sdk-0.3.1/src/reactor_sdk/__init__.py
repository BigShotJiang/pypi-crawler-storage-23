"""
Reactor Python SDK - Real-time AI media streaming.

This SDK provides a Python interface for connecting to Reactor models
and streaming media in real-time using WebRTC with named multi-track
support.

Example:
    from reactor_sdk import Reactor, ReactorStatus, video, audio

    reactor = Reactor(
        model_name="my-model",
        api_key="your-api-key",
        receive=[video("main_video"), audio("main_audio")],
    )

    @reactor.on_track("main_video")
    def handle_video(track):
        print(f"Video track received")

    @reactor.on_status(ReactorStatus.READY)
    def handle_ready(status):
        print("Connected!")

    await reactor.connect()
"""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("reactor-sdk")
except PackageNotFoundError:
    __version__ = "0.0.0.dev"

# Main class
from reactor_sdk.interface import Reactor

# Types
from reactor_sdk.types import (
    ConflictError,
    FrameCallback,
    GPUMachineEvent,
    GPUMachineStatus,
    MessageScope,
    ReactorError,
    ReactorEvent,
    ReactorState,
    ReactorStatus,
    TrackConfig,
    TrackKind,
    audio,
    video,
)

# Utilities
from reactor_sdk.utils.tokens import fetch_jwt_token

__all__ = [
    # Main class
    "Reactor",
    # Track helpers
    "video",
    "audio",
    # Utilities
    "fetch_jwt_token",
    # Types
    "ReactorStatus",
    "ReactorError",
    "ReactorState",
    "ReactorEvent",
    "GPUMachineStatus",
    "GPUMachineEvent",
    "MessageScope",
    "FrameCallback",
    "TrackConfig",
    "TrackKind",
    "ConflictError",
    "__version__",
]
