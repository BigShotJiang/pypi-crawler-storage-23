Show secondary unit infos in the weighing assistant.
