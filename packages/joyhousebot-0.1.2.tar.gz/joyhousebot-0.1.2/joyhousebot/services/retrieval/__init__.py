"""Retrieval service: SQLite FTS5 full-text search over knowledge base with evidence trace."""

from joyhousebot.services.retrieval.store import RetrievalStore

__all__ = ["RetrievalStore"]
