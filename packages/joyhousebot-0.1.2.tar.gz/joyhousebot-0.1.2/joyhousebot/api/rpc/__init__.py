"""RPC method handlers extracted from monolithic API server."""

