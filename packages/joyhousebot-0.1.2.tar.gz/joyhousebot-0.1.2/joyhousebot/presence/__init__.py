"""Presence: lightweight view of connected clients and gateway (OpenClaw-style)."""

from joyhousebot.presence.store import PresenceStore

__all__ = ["PresenceStore"]
