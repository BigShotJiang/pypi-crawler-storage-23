"""
Entry point for running joyhousebot as a module: python -m joyhousebot
"""

from joyhousebot.cli.commands import app

if __name__ == "__main__":
    app()
