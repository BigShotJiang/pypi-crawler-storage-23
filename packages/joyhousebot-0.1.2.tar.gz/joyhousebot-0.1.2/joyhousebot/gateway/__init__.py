"""Gateway auth and rate limiting (OpenClaw-aligned)."""
