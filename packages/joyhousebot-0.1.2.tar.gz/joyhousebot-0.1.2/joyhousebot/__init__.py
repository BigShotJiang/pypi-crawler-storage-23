"""
joyhousebot - A lightweight AI agent framework
"""

__version__ = "0.1.1"
__logo__ = "🐈"
