from collections.abc import Sequence

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import BonusProgram, MetaArray


class GetBonusPrograms(MSMethod):
    __return__ = MetaArray[BonusProgram]
    __api_method__ = "entity/bonusprogram"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
