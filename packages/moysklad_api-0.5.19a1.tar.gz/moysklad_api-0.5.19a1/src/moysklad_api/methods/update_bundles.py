from ..methods.base import MSMethod
from ..types import Bundle


class UpdateBundles(MSMethod[Bundle]):
    __return__ = list[Bundle]
    __api_method__ = "entity/bundle"

    data: list[Bundle]
