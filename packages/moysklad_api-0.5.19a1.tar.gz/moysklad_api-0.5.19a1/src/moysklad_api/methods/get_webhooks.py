from collections.abc import Sequence

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import MetaArray, Webhook


class GetWebhooks(MSMethod):
    __return__ = MetaArray[Webhook]
    __api_method__ = "entity/webhook"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
