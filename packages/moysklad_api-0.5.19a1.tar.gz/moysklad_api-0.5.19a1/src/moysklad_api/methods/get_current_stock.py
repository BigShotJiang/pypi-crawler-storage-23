from collections.abc import Sequence
from datetime import datetime

from pydantic import Field

from ..enums import StockType
from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import CurrentStock


class GetCurrentStock(MSMethod):
    __return__ = list[CurrentStock]
    __api_method__ = "report/stock/all/current"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    include: str | None = None
    changed_since: datetime | None = Field(None, alias="changedSince")
    stock_type: StockType = Field(StockType.STOCK, alias="stockType")
