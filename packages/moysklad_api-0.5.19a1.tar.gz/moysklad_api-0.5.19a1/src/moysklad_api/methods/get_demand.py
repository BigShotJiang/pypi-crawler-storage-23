from collections.abc import Sequence

from pydantic import Field

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import Demand


class GetDemand(MSMethod):
    __return__ = Demand
    __api_method__ = "entity/demand"

    id: str = Field(..., alias="demand_id")

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
