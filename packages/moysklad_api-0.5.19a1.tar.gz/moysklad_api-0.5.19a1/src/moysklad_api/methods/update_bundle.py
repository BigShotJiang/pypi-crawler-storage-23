from pydantic import Field

from ..methods.base import MSMethod
from ..types import Bundle


class UpdateBundle(MSMethod[Bundle]):
    __return__ = Bundle
    __api_method__ = "entity/bundle"

    id: str = Field(..., alias="bundle_id")
    data: Bundle
