from collections.abc import Sequence
from datetime import datetime

from pydantic import Field

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types.commissionreportin import CommissionReportIn


class GetCommissionReportIn(MSMethod):
    __return__ = CommissionReportIn
    __api_method__ = "entity/commissionreportin"

    id: str = Field(..., alias="commissionreportin_id")
    limit: int | None = None
    offset: int | None = None
    search: str | None = None
    expand: Sequence[str] | str | None = None
    incoming_date: datetime | None = Field(None, alias="incomingDate")
    filters: Condition | Sequence[Condition] | None = None
