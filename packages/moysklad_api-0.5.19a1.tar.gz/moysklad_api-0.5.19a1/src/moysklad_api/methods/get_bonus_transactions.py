from collections.abc import Sequence

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import BonusTransaction, MetaArray


class GetBonusTransactions(MSMethod):
    __return__ = MetaArray[BonusTransaction]
    __api_method__ = "entity/bonustransaction"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
