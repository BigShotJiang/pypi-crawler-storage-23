from collections.abc import Sequence

from pydantic import Field

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import Product


class GetProduct(MSMethod):
    __return__ = Product
    __api_method__ = "entity/product"

    id: str = Field(..., alias="product_id")

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
