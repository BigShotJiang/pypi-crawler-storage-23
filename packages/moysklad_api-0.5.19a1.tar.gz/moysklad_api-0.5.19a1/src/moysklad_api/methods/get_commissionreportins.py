from collections.abc import Sequence
from datetime import datetime

from pydantic import Field

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import MetaArray
from ..types.commissionreportin import CommissionReportIn


class GetCommissionReportIns(MSMethod):
    __return__ = MetaArray[CommissionReportIn]
    __api_method__ = "entity/commissionreportin"

    limit: int | None = None
    offset: int | None = None
    search: str | None = None
    expand: Sequence[str] | str | None = None
    incoming_date: datetime | None = Field(None, alias="incomingDate")
    filters: Condition | Sequence[Condition] | None = None
