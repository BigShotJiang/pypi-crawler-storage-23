from collections.abc import Sequence

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import Bundle, MetaArray


class GetBundles(MSMethod):
    __return__ = MetaArray[Bundle]
    __api_method__ = "entity/bundle"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
