from collections.abc import Sequence

from pydantic import Field

from ..enums import GroupBy
from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import Assortment, MetaArray


class GetAssortment(MSMethod):
    __return__ = MetaArray[Assortment]
    __api_method__ = "entity/assortment"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None

    group_by: GroupBy | None = Field(
        default=None,
        alias="groupBy",
    )
