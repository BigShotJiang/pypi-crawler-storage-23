from collections.abc import Sequence

from pydantic import Field

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import MetaArray, PurchaseOrder


class GetPurchaseOrders(MSMethod):
    __return__ = MetaArray[PurchaseOrder]
    __api_method__ = "entity/purchaseorder"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None

    search: str | None = Field(
        default=None,
        alias="search",
    )
