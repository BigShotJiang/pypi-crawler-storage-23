from collections.abc import Sequence

from pydantic import Field

from ..filters.condition import Condition
from ..methods import MSMethod
from ..types import Bundle


class GetBundle(MSMethod):
    __return__ = Bundle
    __api_method__ = "entity/bundle"

    id: str = Field(..., alias="bundle_id")

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
