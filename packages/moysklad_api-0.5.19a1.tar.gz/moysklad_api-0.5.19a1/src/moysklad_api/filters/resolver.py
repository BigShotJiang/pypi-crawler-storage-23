from collections.abc import Iterable

from .condition import Condition


def resolve_filter_parts(conditions: Condition | Iterable[Condition]) -> str:
    if isinstance(conditions, Condition):
        conditions = [conditions]

    parts: list[str] = []

    for cond in conditions:
        for k, op, v in cond.expand():
            if v is None:
                parts.append(f"{k}{op}")
            else:
                parts.append(f"{k}{op}{str(v).lower()}")

    return ";".join(parts)
