from .prop import Prop


class Filter:
    def __getattr__(self, k: str) -> Prop:
        return Prop(k)
