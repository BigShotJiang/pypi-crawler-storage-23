class Condition:
    __slots__ = ("k", "op", "v")

    def __init__(self, k: str, op: str, v=None):
        self.k = k
        self.op = op
        self.v = v

    def expand(self) -> list[tuple[str, str, object]]:
        if isinstance(self.v, (list | tuple)):
            return [(self.k, self.op, v) for v in self.v]
        return [(self.k, self.op, self.v)]
