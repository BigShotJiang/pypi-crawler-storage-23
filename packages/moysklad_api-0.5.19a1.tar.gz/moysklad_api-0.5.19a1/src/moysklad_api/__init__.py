from .client.api import MoyskladAPI
from .filters import Filter


F = Filter()


__all__ = (
    "MoyskladAPI",
    "F",
)
