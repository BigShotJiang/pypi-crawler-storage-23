from .entity import Entity


class AgentAccount(Entity):
    pass
