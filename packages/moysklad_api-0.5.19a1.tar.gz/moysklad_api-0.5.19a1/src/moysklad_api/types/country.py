from .entity import Entity


class Country(Entity):
    pass
