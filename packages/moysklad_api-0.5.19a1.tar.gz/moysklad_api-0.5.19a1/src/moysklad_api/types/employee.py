from .entity import Entity


class Employee(Entity):
    pass
