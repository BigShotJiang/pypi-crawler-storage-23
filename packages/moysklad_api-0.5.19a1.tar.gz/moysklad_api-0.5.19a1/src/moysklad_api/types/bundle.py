from datetime import datetime

from pydantic import Field

from ..enums import PaymentItemType, TaxSystem, TrackingType
from .attribute import Attribute
from .barcode import Barcode
from .country import Country
from .entity import Entity
from .file import File
from .group import Group
from .image import Image
from .min_price import MinPrice
from .owner import Owner
from .product_folder import ProductFolder
from .sale_price import SalePrice
from .uom import Uom


class Bundle(Entity):
    id: str | None = Field(None, alias="id")
    account_id: str | None = Field(None, alias="accountId")
    archived: bool | None = Field(None, alias="archived")
    article: str | None = Field(None, alias="article")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    barcodes: list[Barcode] | None = Field(None, alias="barcodes")
    code: str | None = Field(None, alias="code")
    country: Country | None = Field(None, alias="country")
    description: str | None = Field(None, alias="description")
    discount_prohibited: bool | None = Field(None, alias="discountProhibited")
    effective_vat: int | None = Field(None, alias="effectiveVat")
    effective_vat_enabled: bool | None = Field(None, alias="effectiveVatEnabled")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list[File] | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    images: dict | list[Image] | None = Field(None, alias="images")
    min_price: MinPrice | None = Field(None, alias="minPrice")
    name: str | None = Field(None, alias="name")
    owner: Owner | None = Field(None, alias="owner")
    partial_disposal: bool | None = Field(None, alias="partialDisposal")
    path_name: str | None = Field(None, alias="pathName")
    payment_item_type: PaymentItemType | None = Field(None, alias="paymentItemType")
    product_folder: ProductFolder | None = Field(None, alias="productFolder")
    sale_prices: list[SalePrice] | None = Field(None, alias="salePrices")
    shared: bool | None = Field(None, alias="shared")
    sync_id: str | None = Field(None, alias="syncId")
    tax_system: TaxSystem | None = Field(None, alias="taxSystem")
    tnved: str | None = Field(None, alias="tnved")
    tracking_type: TrackingType | None = Field(None, alias="trackingType")
    uom: Uom | None = Field(None, alias="uom")
    updated: datetime | None = Field(None, alias="updated")
    use_parent_vat: bool | None = Field(None, alias="useParentVat")
    vat: int | None = Field(None, alias="vat")
    vat_enabled: bool | None = Field(None, alias="vatEnabled")
    volume: float | None = Field(None, alias="volume")
    weight: float | None = Field(None, alias="weight")
