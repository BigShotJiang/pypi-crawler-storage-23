from typing import Any

from pydantic import BaseModel


class Response(BaseModel):
    status: int
    ok: bool
    data: Any = None
    error: str | None = None

    def __bool__(self):
        return self.ok
