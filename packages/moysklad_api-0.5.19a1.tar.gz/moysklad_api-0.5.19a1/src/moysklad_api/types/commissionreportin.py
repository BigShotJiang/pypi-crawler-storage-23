from pydantic import Field

from .agent import Agent
from .agent_account import AgentAccount
from .attribute import Attribute
from .commissionreportin_position import CommissionReportInPosition
from .contract import Contract
from .entity import Entity
from .file import File
from .group import Group
from .meta_array import MetaArray
from .organization import Organization
from .organization_account import OrganizationAccount
from .owner import Owner
from .project import Project
from .rate import Rate
from .return_to_commissioner_position import ReturnToCommissionerPosition
from .sales_channel import SalesChannel
from .state import State


class CommissionReportIn(Entity):
    id: str | None = Field(None, alias="id")
    account_id: str | None = Field(None, alias="accountId")
    agent: Agent | None = Field(None, alias="agent")
    agent_account: AgentAccount | None = Field(None, alias="agentAccount")
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    commission_overhead: dict | None = Field(None, alias="commissionOverhead")
    commission_period_end: str | None = Field(None, alias="commissionPeriodEnd")
    commission_period_start: str | None = Field(None, alias="commissionPeriodStart")
    commitent_sum: float | None = Field(None, alias="commitentSum")
    contract: Contract | None = Field(None, alias="contract")
    created: str | None = Field(None, alias="created")
    deleted: str | None = Field(None, alias="deleted")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    files: MetaArray[File] | File | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    moment: str | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    organization_account: OrganizationAccount | None = Field(None, alias="organizationAccount")
    owner: Owner | None = Field(None, alias="owner")
    payed_sum: float | None = Field(None, alias="payedSum")
    positions: CommissionReportInPosition | None = Field(None, alias="positions")
    return_to_commissioner_positions: ReturnToCommissionerPosition | None = Field(
        None, alias="returnToCommissionerPositions"
    )
    printed: bool | None = Field(None, alias="printed")
    published: bool | None = Field(None, alias="published")
    shared: bool | None = Field(None, alias="shared")
    project: Project | None = Field(None, alias="project")
    sales_channel: SalesChannel | None = Field(None, alias="salesChannel")
    state: State | None = Field(None, alias="state")
    rate: Rate | None = Field(None, alias="rate")
    reward_percent: int | None = Field(None, alias="rewardPercent")
    reward_type: str | None = Field(None, alias="rewardType")
    sum: float | None = Field(None, alias="sum")
    sync_id: str | None = Field(None, alias="syncId")
    updated: str | None = Field(None, alias="updated")
    vat_enabled: bool | None = Field(None, alias="vatEnabled")
    vat_included: bool | None = Field(None, alias="vatIncluded")
    vat_sum: float | None = Field(None, alias="vatSum")
