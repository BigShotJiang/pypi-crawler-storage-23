from typing import Any

from pydantic import BaseModel


class Request(BaseModel):
    method: str
    url: str
    params: dict[str, Any] | None = None
    json_data: Any | None = None
    data: str | bytes | None = None
    headers: dict[str, str] | None = None
