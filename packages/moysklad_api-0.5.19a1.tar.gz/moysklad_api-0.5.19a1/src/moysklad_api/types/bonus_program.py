from pydantic import Field

from ..enums import BonusProgramWelcomeMode
from .entity import Entity
from .meta import Meta


class BonusProgram(Entity):
    meta: Meta | None = Field(None, alias="meta")
    id: str | None = Field(None, alias="id")
    account_id: str | None = Field(None, alias="accountId")
    name: str | None = Field(None, alias="name")
    active: bool | None = Field(None, alias="active")
    all_agents: bool | None = Field(None, alias="allAgents")
    all_products: bool | None = Field(None, alias="allProducts")
    agent_tags: list[str] | None = Field(None, alias="agentTags")
    earn_rate_roubles_to_point: int | None = Field(None, alias="earnRateRoublesToPoint")
    earn_while_redeeming: bool | None = Field(None, alias="earnWhileRedeeming")
    spend_rate_points_to_rouble: int | None = Field(None, alias="spendRatePointsToRouble")
    max_paid_rate_percents: int | None = Field(None, alias="maxPaidRatePercents")
    postponed_bonuses_delay_days: int | None = Field(None, alias="postponedBonusesDelayDays")
    welcome_bonuses_enabled: bool | None = Field(None, alias="welcomeBonusesEnabled")
    welcome_bonuses_mode: BonusProgramWelcomeMode | None = Field(None, alias="welcomeBonusesMode")
    welcome_bonuses_value: int | None = Field(None, alias="welcomeBonusesValue")
