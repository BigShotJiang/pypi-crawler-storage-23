from .entity import Entity


class Currency(Entity):
    pass
