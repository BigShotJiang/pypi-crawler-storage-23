from pydantic import Field

from .assortment import Assortment
from .entity import Entity
from .pack import Pack


class CommissionReportInPosition(Entity):
    id: str | None = Field(None, alias="id")
    account_id: str | None = Field(None, alias="accountId")
    assortment: Assortment | None = Field(None, alias="assortment")
    pack: Pack | None = Field(None, alias="pack")
    price: float | None = Field(None, alias="price")
    quantity: float | None = Field(None, alias="quantity")
    reward: float | None = Field(None, alias="reward")
    vat: int | None = Field(None, alias="vat")
    vat_enabled: bool | None = Field(None, alias="vatEnabled")
