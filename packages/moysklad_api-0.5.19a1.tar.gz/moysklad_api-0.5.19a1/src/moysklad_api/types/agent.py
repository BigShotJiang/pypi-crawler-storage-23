from .counterpatry import Counterparty


class Agent(Counterparty):
    pass
