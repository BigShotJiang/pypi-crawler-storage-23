from .entity import Entity


class ParentDocument(Entity):
    pass
