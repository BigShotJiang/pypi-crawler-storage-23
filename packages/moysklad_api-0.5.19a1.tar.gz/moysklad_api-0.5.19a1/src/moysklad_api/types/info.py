from pydantic import BaseModel


class Info(BaseModel):
    pass
