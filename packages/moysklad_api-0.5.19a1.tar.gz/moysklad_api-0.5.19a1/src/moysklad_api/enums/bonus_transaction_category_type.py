from enum import Enum


class BonusTransactionCategoryType(str, Enum):
    REGULAR = "REGULAR"
    WELCOME = "WELCOME"
