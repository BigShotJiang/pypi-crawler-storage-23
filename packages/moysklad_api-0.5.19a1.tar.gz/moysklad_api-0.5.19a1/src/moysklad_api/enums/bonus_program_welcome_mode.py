from enum import Enum


class BonusProgramWelcomeMode(str, Enum):
    REGISTRATION = "REGISTRATION"
    FIRST_PURCHASE = "FIRST_PURCHASE"
