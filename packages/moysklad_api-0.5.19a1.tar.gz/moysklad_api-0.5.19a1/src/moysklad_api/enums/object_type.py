from enum import Enum


class ObjectType(Enum):
    pass
