# httpx-gracedb

httpx-gracedb provides a generic REST API client for [GraceDB] and similar
LIGO/Virgo API services. It uses the powerful [httpx] package for reliable
and high-throughput HTTP connection pooling.

[GraceDB]: https://gracedb.ligo.org/
[httpx]: https://www.python-httpx.org
