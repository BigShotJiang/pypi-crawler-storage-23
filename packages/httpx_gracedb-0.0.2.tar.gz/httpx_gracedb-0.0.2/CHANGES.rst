Changelog
=========

0.0.2 (2026-02-19)
------------------

-   Don't treat redirects as errors.

0.0.1 (2026-02-19)
------------------

-   First release, forked from https://git.ligo.org/emfollow/requests-gracedb.
