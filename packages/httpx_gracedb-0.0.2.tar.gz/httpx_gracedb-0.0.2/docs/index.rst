httpx-gracedb Documentation
===========================

httpx-gracedb provides a generic REST API client for `GraceDB`_ and similar
LIGO/Virgo API services. It uses the powerful `httpx`_ package for reliable
and high-throughput HTTP connection pooling.

Quick Start
-----------

Install with pip_::

    pip install httpx-gracedb

API
---

.. automodule:: httpx_gracedb
.. automodule:: httpx_gracedb.auth
.. automodule:: httpx_gracedb.errors
.. automodule:: httpx_gracedb.file
.. automodule:: httpx_gracedb.user_agent

.. _GraceDB: https://gracedb.ligo.org/
.. _httpx: https://www.python-httpx.org
.. _pip: http://pip.pypa.io
