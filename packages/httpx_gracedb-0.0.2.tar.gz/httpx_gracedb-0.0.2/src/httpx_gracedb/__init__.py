#
# Copyright (C) 2019-2025  Leo P. Singer <leo.singer@ligo.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
import httpx

from ._version import version as __version__  # noqa: F401
from .auth import ClientAuthMixin
from .errors import ClientErrorMixin
from .file import ClientFileMixin
from .user_agent import ClientUserAgentMixin

__all__ = ("AsyncClient", "Client")


class AsyncClient(
    ClientAuthMixin,
    ClientErrorMixin,
    ClientFileMixin,
    ClientUserAgentMixin,
    httpx.Client,
):
    """Same as :class:`httpx_gracedb.Client` but for async requests."""


class Client(
    ClientAuthMixin,
    ClientErrorMixin,
    ClientFileMixin,
    ClientUserAgentMixin,
    httpx.Client,
):
    """A :class:`httpx.Client` subclass that adds behaviors that are common
    to ligo.org REST API services such as that of :doc:`GraceDB
    <gracedb:index>`.

    It adds the following behaviors to the Client:

    * GraceDB-style authentication
      (see :class:`~httpx_gracedb.auth.ClientAuthMixin`)

    * Raise exceptions based on HTTP status codes
      (see :class:`~httpx_gracedb.errors.ClientErrorMixin`)

    * Automatically load POSTed files from disk, automatically guess MIME types
      (see :class:`~httpx_gracedb.file.ClientFileMixin`)

    * Add User-Agent string based on Python package name and version
      (see :class:`~httpx_gracedb.user_agent.ClientUserAgentMixin`)
    """
