#
# Copyright (C) 2019-2025  Leo P. Singer <leo.singer@ligo.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
"""Tests for :mod:`httpx_gracedb.auth`."""

import os
import stat
from unittest.mock import Mock
from uuid import uuid4

import httpx
import pytest

from httpx_gracedb import Client


@pytest.fixture
def mock_send(monkeypatch):
    mock = Mock()
    monkeypatch.setattr(Client, "_send_handling_redirects", mock)
    yield mock


def set_rwx_user(fileobj):
    """Set correct permissions for netrc files."""
    os.fchmod(fileobj.fileno(), stat.S_IRWXU)


def test_noauth_invalid():
    """Test that setting force_noauth=fail_if_noauth=True is an error."""
    with pytest.raises(ValueError):
        Client("https://example.org/", force_noauth=True, fail_if_noauth=True)


def test_force_noauth():
    """Test force_noauth=True."""
    client = Client(
        "https://example.org/",
        username="albert.einstein",
        password="super-secret",
        force_noauth=True,
    )
    assert client.auth is None


@pytest.fixture
def bt_does_not_exist(tmp_path, monkeypatch):
    """Make sure that there is no default SciTokens file."""
    monkeypatch.setenv("BEARER_TOKEN_FILE", str(tmp_path / f"bt_u{uuid4()}"))


def test_scitokens_explicit(tmp_path, mock_send):
    token = tmp_path / "jwt.json"
    token.write_text("hello-world")
    with Client(token=token) as client:
        client.get("https://example.org/")
    assert mock_send.call_args[0][0].headers["Authorization"] == "Bearer hello-world"


def test_scitokens_default(tmp_path, monkeypatch, mock_send):
    token = tmp_path / "jwt.json"
    token.write_text("hello-world")
    monkeypatch.setenv("BEARER_TOKEN_FILE", str(token))
    with Client() as client:
        client.get("https://example.org/")
    assert mock_send.call_args[0][0].headers["Authorization"] == "Bearer hello-world"


@pytest.mark.parametrize(
    "username,password", [["albert.einstein", None], [None, "super-secret"]]
)
def test_basic_invalid(username, password):
    """Test that providing username or password, but not both, is an error."""
    with pytest.raises(ValueError):
        Client("https://example.org/", username=username, password=password)


def test_basic_explicit():
    """Test basic auth with explicitly provided username and password."""
    client = Client(
        "https://example.org/", username="albert.einstein", password="super-secret"
    )
    assert isinstance(client.auth, httpx.BasicAuth)


def test_basic_default(monkeypatch, tmpdir):
    """Test basic auth provided through a netrc file."""
    filename = str(tmpdir / "netrc")
    with open(filename, "w") as f:
        print(
            "machine",
            "example.org",
            "login",
            "albert.einstein",
            "password",
            "super-secret",
            file=f,
        )
        set_rwx_user(f)
    monkeypatch.setenv("NETRC", filename)
    monkeypatch.setenv("HOME", str(tmpdir))
    client = Client("https://example.org/")
    assert isinstance(client.auth, httpx.BasicAuth)


def test_fail_if_noauth(monkeypatch, tmpdir):
    """Test that an exception is raised if fail_if_noauth=True and no
    authentication source is available.
    """
    monkeypatch.setenv("NETRC", str(tmpdir / "netrc"))
    monkeypatch.setenv("HOME", str(tmpdir))
    client = Client("https://example.org/")
    assert client.auth is None
    with pytest.raises(ValueError):
        Client("https://example.org/", fail_if_noauth=True)
