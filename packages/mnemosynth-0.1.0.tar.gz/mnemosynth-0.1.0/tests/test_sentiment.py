"""Comprehensive tests for sentiment engine — multiple scenarios."""

from mnemosynth.engine.sentiment import SentimentEngine


class TestSentimentEngine:
    def setup_method(self):
        self.engine = SentimentEngine()

    # ── Positive sentiment ────────────────────────────────────

    def test_strongly_positive(self):
        score = self.engine.score("I absolutely love this amazing feature!")
        assert score > 0.5, f"Expected strongly positive, got {score}"

    def test_mildly_positive(self):
        score = self.engine.score("This is good and helpful")
        assert 0.0 < score <= 1.0

    def test_positive_classification(self):
        label = self.engine.classify("This is a great, wonderful tool")
        assert label == "positive"

    # ── Negative sentiment ────────────────────────────────────

    def test_strongly_negative(self):
        score = self.engine.score("I hate this terrible, awful broken thing")
        assert score < -0.5, f"Expected strongly negative, got {score}"

    def test_mildly_negative(self):
        score = self.engine.score("There's a bug in the code")
        assert score < 0.0

    def test_negative_classification(self):
        label = self.engine.classify("This is broken and frustrating")
        assert label == "negative"

    # ── Neutral sentiment ─────────────────────────────────────

    def test_neutral_statement(self):
        score = self.engine.score("The variable is assigned on line 42")
        assert -0.2 <= score <= 0.2

    def test_neutral_classification(self):
        label = self.engine.classify("The function returns a string")
        assert label == "neutral"

    def test_technical_text_neutral(self):
        score = self.engine.score("Python 3.10 supports pattern matching")
        assert abs(score) < 0.3

    # ── Intensifiers ──────────────────────────────────────────

    def test_intensifier_boost(self):
        base = self.engine.score("It seems nice but also has problems")
        boosted = self.engine.score("It seems very extremely nice but also has problems")
        assert boosted >= base

    # ── Edge cases ────────────────────────────────────────────

    def test_empty_string(self):
        score = self.engine.score("")
        assert score == 0.0

    def test_single_word(self):
        score = self.engine.score("love")
        assert score > 0

    def test_mixed_sentiment(self):
        score = self.engine.score("I love the feature but hate the bugs")
        # Mixed should be closer to 0
        assert -0.5 <= score <= 0.5

    def test_batch_scoring(self):
        texts = ["great", "terrible", "normal"]
        scores = self.engine.score_batch(texts)
        assert len(scores) == 3
        assert scores[0] > 0
        assert scores[1] < 0

    def test_score_bounds(self):
        """Score should always be between -1.0 and 1.0."""
        texts = [
            "absolutely amazing wonderful fantastic incredible perfect beautiful",
            "terrible horrible awful disgusting pathetic useless broken",
            "",
            "x",
        ]
        for text in texts:
            score = self.engine.score(text)
            assert -1.0 <= score <= 1.0, f"Score out of bounds for '{text[:30]}': {score}"
