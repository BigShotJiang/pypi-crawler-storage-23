"""MCP module — Model Context Protocol server."""
