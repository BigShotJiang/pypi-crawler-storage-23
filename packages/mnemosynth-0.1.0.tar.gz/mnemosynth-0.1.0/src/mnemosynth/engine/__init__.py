"""Engine module — routing, extraction, digest, and decay."""
