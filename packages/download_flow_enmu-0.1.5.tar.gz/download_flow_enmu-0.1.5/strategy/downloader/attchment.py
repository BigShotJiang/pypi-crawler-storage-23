import logging

from imap_tools import MailBox, AND
from datetime import timedelta, date
from strategy.downloader.provider import Downloader
from typing import override
from data.bill_profile import BillProfile


class AttchmentDownloader(Downloader):
    @override
    def download(self, mail: MailBox, bill: BillProfile):

        limit_date = date.today() - timedelta(days=2)
        criteria = AND(
            from_=bill.sender_email,
            # date=date.today() - timedelta(days=1),
            date_gte=limit_date,
        )

        downloaded_count = 0
        for msg in mail.fetch(criteria=criteria):
            logging.info(f"找到邮件: {msg.subject}")

            if bill.search_subject not in msg.subject:
                continue
            for att in msg.attachments:
                if not att.filename.lower().endswith(bill.file_suffix):
                    continue
                bill.save_subdir.mkdir(parents=True, exist_ok=True)
                filepath = bill.save_subdir / f"{date.today()}.{bill.file_suffix}"

                try:
                    if bill.file_suffix in ["zip", "7z", "rar"]:
                        filepath.write_bytes(att.payload)
                    else:
                        content_str = att.payload.decode(bill.encoding)
                        filepath.write_text(content_str, encoding="utf-8")
                    downloaded_count += 1
                except UnicodeDecodeError:
                    logging.error("  ✗ 转码失败")
                    continue
        return downloaded_count > 0
