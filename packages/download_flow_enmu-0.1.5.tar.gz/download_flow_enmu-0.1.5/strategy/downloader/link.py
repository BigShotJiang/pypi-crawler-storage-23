import logging
import re
from imap_tools import MailBox, AND
import requests
from datetime import timedelta, date
from strategy.downloader.provider import Downloader
from data.bill_profile import BillProfile
from bs4 import BeautifulSoup


class LinkDownloader(Downloader):
    def download(self, mail: MailBox, bill: BillProfile):
        limit_date = date.today() - timedelta(days=2)
        criteria = AND(from_=bill.sender_email, date_gte=limit_date)
        download_count = 0
        for msg in mail.fetch(criteria=criteria):
            if bill.search_subject not in msg.subject:
                continue
            # 获取html
            html = msg.html

            if html:
                html_parser = BeautifulSoup(html, "lxml")
            else:
                raise ValueError("找不到对应html")
            link = html_parser.find("a", string=re.compile("点击下载"))

            if not link:
                raise ValueError("无法解析对应的链接")
            try:
                link_ref = link.get("href")
                response = requests.get(link_ref)
                response.raise_for_status()
                if not bill.save_subdir.exists():
                    bill.save_subdir.mkdir(parents=True, exist_ok=True)
                filepath = bill.save_subdir / f"{date.today()}.{bill.file_suffix}"
                download_count += 1
                with open(filepath, "wb") as f:
                    f.write(response.content)
            except Exception as e:
                print("下载过程出错", e)

        return download_count > 0
