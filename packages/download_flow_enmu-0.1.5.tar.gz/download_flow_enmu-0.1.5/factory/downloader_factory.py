from strategy.downloader.attchment import AttchmentDownloader
from strategy.downloader.link import LinkDownloader


def creat_downloader(download_type: str):
    if download_type == "attchment":
        return AttchmentDownloader()
    if download_type == "link":
        return LinkDownloader()
    else:
        raise NameError("未知下载器类型")
