from strategy.provider.ali_provider import AliProvider
from strategy.provider.wechat_provider import WechatProvider


def create_workder(provider: str):
    if provider == "alipay":
        return AliProvider()
    if provider == "wechat":
        return WechatProvider()
    else:
        raise ValueError("未知供应商")
