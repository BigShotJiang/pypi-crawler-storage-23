from cli.root import app

from cli.download_cmd import download


def main():
    app()


if __name__ == "__main__":
    main()
