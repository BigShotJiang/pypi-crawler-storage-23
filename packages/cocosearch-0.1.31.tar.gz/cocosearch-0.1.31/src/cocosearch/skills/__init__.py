"""Bundled CocoSearch workflow skills for AI coding assistants.

Skills are SKILL.md files in subdirectories, discovered at runtime
via importlib.resources. Each subdirectory name is the skill name
(e.g., cocosearch-quickstart/SKILL.md).
"""
