"""CocoSearch: Local-first semantic code search."""

__version__ = "0.1.30"
