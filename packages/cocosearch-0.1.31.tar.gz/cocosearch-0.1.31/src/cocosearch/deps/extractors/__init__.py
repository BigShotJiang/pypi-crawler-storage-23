"""Dependency extractors for language-specific import/call analysis."""
