// SPDX-License-Identifier: MIT OR Apache-2.0

#![forbid(unsafe_code)]

pub mod constraints;
pub mod control;
pub mod detectors;
pub mod diagnostics;
pub mod error;
pub mod execution_context;
pub mod missing;
pub mod numerics;
pub mod observability;
pub mod repro;
pub mod results;
#[cfg(feature = "serde")]
pub mod schema_migration;
pub mod stopping;
pub mod time_series;

pub use constraints::{
    CachePolicy, Constraints, DegradationStep, ValidatedConstraints, canonicalize_candidates,
    validate_constraints, validate_constraints_config,
};
pub use control::{BudgetMode, BudgetStatus, CancelToken};
pub use detectors::{OfflineDetector, OnlineDetector, OnlineStepResult};
pub use diagnostics::{
    BuildInfo, DIAGNOSTICS_SCHEMA_VERSION, Diagnostics, PruningStats, enrich_diagnostics_build,
};
pub use error::CpdError;
pub use execution_context::ExecutionContext;
pub use missing::{
    MissingRunStats, MissingSupport, build_missing_mask, check_missing_compatibility,
    compute_missing_run_stats, scan_nans,
};
pub use numerics::{
    kahan_sum, log_add_exp, log_sum_exp, prefix_sum_squares, prefix_sum_squares_kahan, prefix_sums,
    prefix_sums_kahan, stable_mean, stable_variance,
};
pub use observability::{NoopProgressSink, NoopTelemetrySink, ProgressSink, TelemetrySink};
pub use repro::ReproMode;
pub use results::{
    OfflineChangePointResult, SegmentStats, segments_from_breakpoints, validate_breakpoints,
};
#[cfg(feature = "serde")]
pub use schema_migration::{
    CURRENT_SCHEMA_VERSION, ConstraintsConfigWire, DiagnosticsWire,
    MAX_FORWARD_COMPAT_SCHEMA_VERSION, MIGRATION_GUIDANCE_PATH, OfflineChangePointResultWire,
    validate_schema_version,
};
pub use stopping::{
    Penalty, Stopping, checked_effective_params, penalty_value,
    penalty_value_from_effective_params, validate_penalty, validate_stopping,
};
pub use time_series::{DTypeView, MemoryLayout, MissingPolicy, TimeIndex, TimeSeriesView};

/// Core shared types and traits for cpd-rs.
pub fn crate_name() -> &'static str {
    "cpd-core"
}
