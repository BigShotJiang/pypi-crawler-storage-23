Business Source License 1.1

License text copyright (c) 2017 MariaDB Corporation Ab.
“Business Source License” is a trademark of MariaDB Corporation Ab.

--------------------------------------------------------------------

Parameters

Licensor: <<< Your Name or Company Name >>>

Licensed Work: finqual

Additional Use Grant: 
You may use, modify, and create derivative works of the Licensed Work
for non-production, personal, academic, research, or internal evaluation
purposes only.

You may not use the Licensed Work, or a derivative work, for commercial
purposes, including but not limited to:
- offering a paid service or API
- embedding in a commercial product
- reselling or sublicensing
- providing hosted or managed services

Change Date: 2035-01-01

Change License: Apache License, Version 2.0

--------------------------------------------------------------------

Terms

The Licensor hereby grants you the right to copy, modify, create derivative
works, redistribute, and make non-production use of the Licensed Work,
subject to the limitations below.

Effective on the Change Date, or the fourth anniversary of the first
public release of the Licensed Work, whichever comes first, the terms of
this license will automatically convert to the Change License.

Until the Change Date, you may not use the Licensed Work for commercial
purposes except as expressly authorized by the Licensor in writing.

The Licensed Work is provided “AS IS”, without warranty of any kind,
express or implied.

--------------------------------------------------------------------

For the full license text, see:
https://mariadb.com/bsl11/
