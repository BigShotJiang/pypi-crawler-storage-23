//! Testing utilities for Grafeo internals.
//!
//! These modules are feature-gated and compile to no-ops in production builds.

pub mod crash;
