# sage_setup: distribution = sagemath-gsl

from sage.probability.random_variable import (
    DiscreteRandomVariable,
    DiscreteProbabilitySpace)

from sage.probability.probability_distribution import (
    RealDistribution,
    SphericalDistribution,
    GeneralDiscreteDistribution)
