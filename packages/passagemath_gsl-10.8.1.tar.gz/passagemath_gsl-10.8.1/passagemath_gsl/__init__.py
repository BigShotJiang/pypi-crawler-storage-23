# sage_setup: distribution = sagemath-gsl

from sage.all__sagemath_gsl import *
