"""
Kore — Web Dashboard
Dashboard HTML inline servita direttamente da FastAPI su /dashboard.
Vanilla JS + CSS, zero dipendenze esterne.
"""


def get_dashboard_html() -> str:
    """Ritorna l'HTML completo della dashboard."""
    return _DASHBOARD_HTML


_DASHBOARD_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kore — Memory Dashboard</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
/* ── Reset + Variabili ─────────────────────────────────────────────── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --bg-deep: #07070f;
  --bg-base: #0c0c1d;
  --bg-card: #111128;
  --bg-card-hover: #16163a;
  --bg-input: #0e0e24;
  --border: #1e1e48;
  --border-hover: #2d2d6e;
  --text: #c8cad8;
  --text-dim: #6b6d85;
  --text-bright: #eef0ff;
  --accent: #7c3aed;
  --accent-glow: rgba(124, 58, 237, 0.35);
  --accent-soft: #6d28d9;
  --green: #10b981;
  --green-glow: rgba(16, 185, 129, 0.25);
  --amber: #f59e0b;
  --red: #ef4444;
  --red-glow: rgba(239, 68, 68, 0.2);
  --radius: 10px;
  --radius-sm: 6px;
  --font-body: 'IBM Plex Mono', 'Menlo', monospace;
  --font-heading: 'Outfit', system-ui, sans-serif;
  --sidebar-w: 220px;
  --header-h: 56px;
  --transition: 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}

html { font-size: 14px; }
body {
  font-family: var(--font-body);
  background: var(--bg-deep);
  color: var(--text);
  min-height: 100vh;
  overflow: hidden;
}

/* ── Scrollbar ─────────────────────────────────────────────────────── */
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: var(--accent); }

/* ── Layout ────────────────────────────────────────────────────────── */
.app {
  display: grid;
  grid-template-columns: var(--sidebar-w) 1fr;
  grid-template-rows: var(--header-h) 1fr;
  height: 100vh;
}

/* ── Header ────────────────────────────────────────────────────────── */
.header {
  grid-column: 1 / -1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
  background: var(--bg-base);
  border-bottom: 1px solid var(--border);
  z-index: 10;
}
.header-brand {
  display: flex;
  align-items: center;
  gap: 12px;
}
.header-logo {
  width: 28px;
  height: 28px;
  background: var(--accent);
  border-radius: 8px;
  display: grid;
  place-items: center;
  font-family: var(--font-heading);
  font-weight: 700;
  font-size: 15px;
  color: #fff;
  box-shadow: 0 0 20px var(--accent-glow);
}
.header-title {
  font-family: var(--font-heading);
  font-weight: 600;
  font-size: 17px;
  color: var(--text-bright);
  letter-spacing: -0.3px;
}
.header-title span { color: var(--text-dim); font-weight: 400; font-size: 13px; margin-left: 8px; }
.header-controls {
  display: flex;
  align-items: center;
  gap: 16px;
}
.agent-input-wrap {
  display: flex;
  align-items: center;
  gap: 8px;
  background: var(--bg-input);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  padding: 6px 12px;
}
.agent-input-wrap label {
  font-size: 11px;
  color: var(--text-dim);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}
.agent-input-wrap input {
  background: none;
  border: none;
  color: var(--accent);
  font-family: var(--font-body);
  font-size: 13px;
  font-weight: 500;
  width: 120px;
  outline: none;
}
.status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--green);
  box-shadow: 0 0 8px var(--green-glow);
  animation: pulse 2s ease-in-out infinite;
}
.status-dot.offline { background: var(--red); box-shadow: 0 0 8px var(--red-glow); }
@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

/* ── Sidebar ───────────────────────────────────────────────────────── */
.sidebar {
  background: var(--bg-base);
  border-right: 1px solid var(--border);
  padding: 12px 0;
  overflow-y: auto;
}
.nav-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 20px;
  cursor: pointer;
  color: var(--text-dim);
  transition: all var(--transition);
  font-size: 13px;
  font-weight: 500;
  border-left: 3px solid transparent;
  user-select: none;
}
.nav-item:hover {
  color: var(--text);
  background: rgba(124, 58, 237, 0.05);
}
.nav-item.active {
  color: var(--accent);
  background: rgba(124, 58, 237, 0.08);
  border-left-color: var(--accent);
}
.nav-icon {
  font-size: 16px;
  width: 22px;
  text-align: center;
}

/* ── Main content ──────────────────────────────────────────────────── */
.main {
  overflow-y: auto;
  padding: 24px;
  background:
    radial-gradient(ellipse at 20% 0%, rgba(124, 58, 237, 0.06) 0%, transparent 60%),
    var(--bg-deep);
}
.page { display: none; animation: fadeIn 0.25s ease; }
.page.active { display: block; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }

/* ── Componenti comuni ─────────────────────────────────────────────── */
.card {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 20px;
  margin-bottom: 16px;
  transition: border-color var(--transition);
}
.card:hover { border-color: var(--border-hover); }
.card-header {
  font-family: var(--font-heading);
  font-weight: 600;
  font-size: 15px;
  color: var(--text-bright);
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  gap: 8px;
}
.card-header .icon { color: var(--accent); }
.page-title {
  font-family: var(--font-heading);
  font-weight: 700;
  font-size: 24px;
  color: var(--text-bright);
  margin-bottom: 20px;
  letter-spacing: -0.5px;
}
.page-title small {
  font-weight: 400;
  font-size: 13px;
  color: var(--text-dim);
  margin-left: 8px;
}
.grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; }
.grid-4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }

/* Stat card */
.stat {
  text-align: center;
  padding: 20px 16px;
}
.stat-value {
  font-family: var(--font-heading);
  font-weight: 700;
  font-size: 32px;
  color: var(--text-bright);
  line-height: 1;
}
.stat-value.accent { color: var(--accent); }
.stat-value.green { color: var(--green); }
.stat-label {
  font-size: 11px;
  color: var(--text-dim);
  text-transform: uppercase;
  letter-spacing: 0.8px;
  margin-top: 8px;
}

/* Bottoni */
.btn {
  font-family: var(--font-body);
  font-size: 12px;
  font-weight: 500;
  padding: 8px 16px;
  border-radius: var(--radius-sm);
  border: 1px solid var(--border);
  background: var(--bg-card);
  color: var(--text);
  cursor: pointer;
  transition: all var(--transition);
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.btn:hover { border-color: var(--accent); color: var(--text-bright); }
.btn-primary {
  background: var(--accent);
  border-color: var(--accent);
  color: #fff;
}
.btn-primary:hover {
  background: var(--accent-soft);
  box-shadow: 0 0 20px var(--accent-glow);
}
.btn-danger { border-color: var(--red); color: var(--red); }
.btn-danger:hover { background: var(--red); color: #fff; }
.btn-sm { padding: 5px 10px; font-size: 11px; }
.btn:disabled { opacity: 0.4; cursor: not-allowed; }

/* Input / Form */
input[type="text"], input[type="number"], select, textarea {
  font-family: var(--font-body);
  font-size: 13px;
  padding: 8px 12px;
  background: var(--bg-input);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  color: var(--text);
  outline: none;
  transition: border-color var(--transition);
  width: 100%;
}
input:focus, select:focus, textarea:focus { border-color: var(--accent); }
textarea { resize: vertical; min-height: 80px; }
.form-group { margin-bottom: 14px; }
.form-group label {
  display: block;
  font-size: 11px;
  color: var(--text-dim);
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 6px;
}
.form-row {
  display: flex;
  gap: 12px;
  align-items: flex-end;
}
.form-row > * { flex: 1; }

/* Tabella */
.table-wrap { overflow-x: auto; }
table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12px;
}
th {
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.8px;
  color: var(--text-dim);
  padding: 10px 12px;
  text-align: left;
  border-bottom: 1px solid var(--border);
  font-weight: 600;
}
td {
  padding: 10px 12px;
  border-bottom: 1px solid rgba(30, 30, 72, 0.5);
  vertical-align: top;
  max-width: 350px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
tr { transition: background var(--transition); }
tr:hover { background: var(--bg-card-hover); }

/* Badges */
.badge {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 99px;
  font-size: 10px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.3px;
}
.badge-cat {
  background: rgba(124, 58, 237, 0.12);
  color: var(--accent);
  border: 1px solid rgba(124, 58, 237, 0.25);
}
.badge-tag {
  background: rgba(16, 185, 129, 0.1);
  color: var(--green);
  border: 1px solid rgba(16, 185, 129, 0.25);
  cursor: pointer;
}
.badge-tag:hover { background: rgba(16, 185, 129, 0.2); }

/* Importance stelle */
.importance {
  color: var(--amber);
  letter-spacing: 1px;
  font-size: 11px;
}

/* Decay bar */
.decay-bar {
  width: 60px;
  height: 4px;
  background: var(--bg-input);
  border-radius: 2px;
  overflow: hidden;
  display: inline-block;
  vertical-align: middle;
  margin-right: 6px;
}
.decay-bar-fill {
  height: 100%;
  border-radius: 2px;
  transition: width 0.3s;
}

/* Toast */
.toast-container {
  position: fixed;
  top: 68px;
  right: 24px;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.toast {
  padding: 10px 16px;
  border-radius: var(--radius-sm);
  font-size: 12px;
  font-weight: 500;
  border: 1px solid var(--border);
  background: var(--bg-card);
  color: var(--text);
  animation: slideIn 0.3s ease, fadeOut 0.3s ease 2.7s;
  max-width: 360px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.4);
}
.toast.success { border-color: var(--green); color: var(--green); }
.toast.error { border-color: var(--red); color: var(--red); }
@keyframes slideIn { from { transform: translateX(40px); opacity: 0; } }
@keyframes fadeOut { to { opacity: 0; transform: translateY(-10px); } }

/* Timeline verticale */
.timeline { position: relative; padding-left: 24px; }
.timeline::before {
  content: '';
  position: absolute;
  left: 7px;
  top: 0;
  bottom: 0;
  width: 2px;
  background: var(--border);
}
.timeline-item {
  position: relative;
  margin-bottom: 20px;
  padding: 14px 16px;
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
}
.timeline-item::before {
  content: '';
  position: absolute;
  left: -21px;
  top: 18px;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--accent);
  border: 2px solid var(--bg-deep);
  box-shadow: 0 0 8px var(--accent-glow);
}
.timeline-date {
  font-size: 11px;
  color: var(--text-dim);
  margin-bottom: 6px;
}
.timeline-content { font-size: 13px; line-height: 1.5; }

/* Empty state */
.empty {
  text-align: center;
  padding: 40px;
  color: var(--text-dim);
  font-size: 13px;
}
.empty-icon { font-size: 32px; margin-bottom: 10px; display: block; }

/* Loading */
.spinner {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid var(--border);
  border-top-color: var(--accent);
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* Toggle switch */
.toggle {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: var(--text-dim);
  cursor: pointer;
}
.toggle input { display: none; }
.toggle-track {
  width: 32px;
  height: 18px;
  background: var(--border);
  border-radius: 9px;
  position: relative;
  transition: background var(--transition);
}
.toggle input:checked + .toggle-track { background: var(--accent); }
.toggle-track::after {
  content: '';
  position: absolute;
  top: 2px;
  left: 2px;
  width: 14px;
  height: 14px;
  background: var(--text-bright);
  border-radius: 50%;
  transition: transform var(--transition);
}
.toggle input:checked + .toggle-track::after { transform: translateX(14px); }

/* Manutenzione action row */
.maint-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 0;
  border-bottom: 1px solid rgba(30, 30, 72, 0.5);
}
.maint-row:last-child { border-bottom: none; }
.maint-info h4 {
  font-family: var(--font-heading);
  font-weight: 600;
  font-size: 14px;
  color: var(--text-bright);
  margin-bottom: 4px;
}
.maint-info p { font-size: 12px; color: var(--text-dim); }
.maint-result {
  font-size: 12px;
  color: var(--green);
  margin-top: 6px;
  display: none;
}

/* ── Responsive ─────────────────────────────────────────────────────── */
@media (max-width: 768px) {
  .app {
    grid-template-columns: 1fr;
    grid-template-rows: var(--header-h) 1fr 56px;
  }
  .sidebar {
    grid-row: 3;
    border-right: none;
    border-top: 1px solid var(--border);
    display: flex;
    overflow-x: auto;
    padding: 0;
  }
  .nav-item {
    flex-direction: column;
    gap: 2px;
    font-size: 10px;
    padding: 8px 14px;
    border-left: none;
    border-top: 3px solid transparent;
    white-space: nowrap;
  }
  .nav-item.active { border-left-color: transparent; border-top-color: var(--accent); }
  .main { padding: 16px; }
  .grid-2, .grid-3, .grid-4 { grid-template-columns: 1fr; }
}
</style>
</head>
<body>
<div class="app">
  <!-- Header -->
  <header class="header">
    <div class="header-brand">
      <div class="header-logo">K</div>
      <div class="header-title">Kore <span>Memory Dashboard</span></div>
    </div>
    <div class="header-controls">
      <div class="agent-input-wrap">
        <label for="agent-id">Agent</label>
        <input type="text" id="agent-id" value="default" spellcheck="false">
      </div>
      <div class="status-dot" id="status-dot" title="Server status"></div>
    </div>
  </header>

  <!-- Sidebar -->
  <nav class="sidebar">
    <div class="nav-item active" data-page="overview">
      <span class="nav-icon">&#9673;</span> Overview
    </div>
    <div class="nav-item" data-page="memories">
      <span class="nav-icon">&#9731;</span> Memories
    </div>
    <div class="nav-item" data-page="tags">
      <span class="nav-icon">&#9856;</span> Tags
    </div>
    <div class="nav-item" data-page="relations">
      <span class="nav-icon">&#8644;</span> Relations
    </div>
    <div class="nav-item" data-page="timeline">
      <span class="nav-icon">&#8982;</span> Timeline
    </div>
    <div class="nav-item" data-page="maintenance">
      <span class="nav-icon">&#9881;</span> Maintenance
    </div>
    <div class="nav-item" data-page="backup">
      <span class="nav-icon">&#8693;</span> Backup
    </div>
  </nav>

  <!-- Main content -->
  <main class="main">
    <!-- ═══ Overview ═══ -->
    <div class="page active" id="page-overview">
      <h1 class="page-title">Overview</h1>
      <div class="grid-4" id="overview-stats">
        <div class="card stat">
          <div class="stat-value accent" id="stat-total">—</div>
          <div class="stat-label">Total Memories</div>
        </div>
        <div class="card stat">
          <div class="stat-value green" id="stat-version">—</div>
          <div class="stat-label">Version</div>
        </div>
        <div class="card stat">
          <div class="stat-value" id="stat-semantic">—</div>
          <div class="stat-label">Semantic Search</div>
        </div>
        <div class="card stat">
          <div class="stat-value" id="stat-categories">—</div>
          <div class="stat-label">Categories</div>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><span class="icon">&#9632;</span> Memories by Category</div>
        <div id="category-breakdown" class="empty"><span class="empty-icon">&#8987;</span>Loading...</div>
      </div>
    </div>

    <!-- ═══ Memories ═══ -->
    <div class="page" id="page-memories">
      <h1 class="page-title">Memories <small>Search, save, manage</small></h1>
      <!-- Ricerca -->
      <div class="card">
        <div class="card-header"><span class="icon">&#9906;</span> Search</div>
        <div class="form-row">
          <div class="form-group" style="flex:3">
            <input type="text" id="search-q" placeholder="Search memories...">
          </div>
          <div class="form-group" style="flex:0 0 80px">
            <input type="number" id="search-limit" value="10" min="1" max="20">
          </div>
          <div class="form-group" style="flex:0 0 auto">
            <label class="toggle">
              <input type="checkbox" id="search-semantic" checked>
              <span class="toggle-track"></span>
              Semantic
            </label>
          </div>
          <div class="form-group" style="flex:0 0 auto">
            <button class="btn btn-primary" onclick="doSearch()">Search</button>
          </div>
        </div>
      </div>
      <div class="card" id="search-results-card" style="display:none">
        <div class="card-header"><span class="icon">&#9776;</span> Results <small id="search-total" style="color:var(--text-dim);font-size:12px;margin-left:8px"></small></div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>ID</th><th>Content</th><th>Category</th><th>Imp.</th><th>Decay</th><th>Created</th><th></th></tr></thead>
            <tbody id="search-results-body"></tbody>
          </table>
        </div>
        <div style="margin-top:12px;display:flex;gap:8px">
          <button class="btn btn-sm" id="search-prev" onclick="searchPage(-1)" disabled>&larr; Prev</button>
          <button class="btn btn-sm" id="search-next" onclick="searchPage(1)" disabled>Next &rarr;</button>
        </div>
      </div>
      <!-- Salva -->
      <div class="card">
        <div class="card-header"><span class="icon">&#10010;</span> Save Memory</div>
        <div class="form-group">
          <label>Content</label>
          <textarea id="save-content" placeholder="Memory content (3–4000 chars)..."></textarea>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Category</label>
            <select id="save-category">
              <option value="general">general</option>
              <option value="project">project</option>
              <option value="trading">trading</option>
              <option value="finance">finance</option>
              <option value="person">person</option>
              <option value="preference">preference</option>
              <option value="task">task</option>
              <option value="decision">decision</option>
            </select>
          </div>
          <div class="form-group">
            <label>Importance (1 = auto)</label>
            <input type="number" id="save-importance" value="1" min="1" max="5">
          </div>
          <div class="form-group">
            <label>TTL (hours, empty = never)</label>
            <input type="number" id="save-ttl" placeholder="e.g. 48" min="1" max="8760">
          </div>
          <div class="form-group">
            <button class="btn btn-primary" onclick="doSave()">Save</button>
          </div>
        </div>
      </div>
    </div>

    <!-- ═══ Tags ═══ -->
    <div class="page" id="page-tags">
      <h1 class="page-title">Tags <small>Organize &amp; search</small></h1>
      <div class="grid-2">
        <div class="card">
          <div class="card-header"><span class="icon">&#9906;</span> Search by Tag</div>
          <div class="form-row">
            <div class="form-group"><input type="text" id="tag-search-q" placeholder="Tag name..."></div>
            <div class="form-group" style="flex:0 0 auto"><button class="btn btn-primary" onclick="doTagSearch()">Search</button></div>
          </div>
          <div id="tag-search-results" class="empty" style="margin-top:12px"><span class="empty-icon">&#9856;</span>Enter a tag to search</div>
        </div>
        <div class="card">
          <div class="card-header"><span class="icon">&#10010;</span> Manage Tags</div>
          <div class="form-group">
            <label>Memory ID</label>
            <input type="number" id="tag-memory-id" placeholder="Memory ID">
          </div>
          <div class="form-group">
            <label>Tags (comma-separated)</label>
            <input type="text" id="tag-input" placeholder="tag1, tag2, tag3">
          </div>
          <div style="display:flex;gap:8px">
            <button class="btn btn-primary" onclick="doAddTags()">Add Tags</button>
            <button class="btn btn-danger" onclick="doRemoveTags()">Remove Tags</button>
            <button class="btn" onclick="doGetTags()">Get Tags</button>
          </div>
          <div id="tag-manage-result" style="margin-top:12px"></div>
        </div>
      </div>
    </div>

    <!-- ═══ Relations ═══ -->
    <div class="page" id="page-relations">
      <h1 class="page-title">Relations <small>Knowledge graph</small></h1>
      <div class="grid-2">
        <div class="card">
          <div class="card-header"><span class="icon">&#8644;</span> View Relations</div>
          <div class="form-row">
            <div class="form-group"><input type="number" id="rel-view-id" placeholder="Memory ID"></div>
            <div class="form-group" style="flex:0 0 auto"><button class="btn btn-primary" onclick="doGetRelations()">View</button></div>
          </div>
          <div id="rel-results" style="margin-top:12px"></div>
        </div>
        <div class="card">
          <div class="card-header"><span class="icon">&#10010;</span> Create Relation</div>
          <div class="form-group">
            <label>Source Memory ID</label>
            <input type="number" id="rel-source" placeholder="Source ID">
          </div>
          <div class="form-group">
            <label>Target Memory ID</label>
            <input type="number" id="rel-target" placeholder="Target ID">
          </div>
          <div class="form-group">
            <label>Relation Type</label>
            <input type="text" id="rel-type" value="related" placeholder="e.g. depends_on, related">
          </div>
          <button class="btn btn-primary" onclick="doAddRelation()">Create</button>
        </div>
      </div>
    </div>

    <!-- ═══ Timeline ═══ -->
    <div class="page" id="page-timeline">
      <h1 class="page-title">Timeline <small>Chronological trace</small></h1>
      <div class="card">
        <div class="form-row">
          <div class="form-group" style="flex:3"><input type="text" id="timeline-subject" placeholder="Subject to trace..."></div>
          <div class="form-group" style="flex:0 0 80px"><input type="number" id="timeline-limit" value="20" min="1" max="50"></div>
          <div class="form-group" style="flex:0 0 auto"><button class="btn btn-primary" onclick="doTimeline()">Trace</button></div>
        </div>
      </div>
      <div id="timeline-results" class="empty"><span class="empty-icon">&#8982;</span>Enter a subject to trace</div>
    </div>

    <!-- ═══ Maintenance ═══ -->
    <div class="page" id="page-maintenance">
      <h1 class="page-title">Maintenance <small>Decay, compress, cleanup</small></h1>
      <div class="card">
        <div class="maint-row">
          <div class="maint-info">
            <h4>&#9201; Decay Run</h4>
            <p>Recalculate decay scores using Ebbinghaus forgetting curve</p>
            <div class="maint-result" id="decay-result"></div>
          </div>
          <button class="btn btn-primary" id="btn-decay" onclick="doDecay()">Run Decay</button>
        </div>
        <div class="maint-row">
          <div class="maint-info">
            <h4>&#9878; Compress</h4>
            <p>Merge similar memories (cosine similarity &gt; 0.88)</p>
            <div class="maint-result" id="compress-result"></div>
          </div>
          <button class="btn btn-primary" id="btn-compress" onclick="doCompress()">Run Compress</button>
        </div>
        <div class="maint-row">
          <div class="maint-info">
            <h4>&#9851; Cleanup</h4>
            <p>Remove expired memories (TTL)</p>
            <div class="maint-result" id="cleanup-result"></div>
          </div>
          <button class="btn btn-primary" id="btn-cleanup" onclick="doCleanup()">Run Cleanup</button>
        </div>
      </div>
    </div>

    <!-- ═══ Backup ═══ -->
    <div class="page" id="page-backup">
      <h1 class="page-title">Backup <small>Export &amp; import</small></h1>
      <div class="grid-2">
        <div class="card">
          <div class="card-header"><span class="icon">&#8681;</span> Export</div>
          <p style="font-size:12px;color:var(--text-dim);margin-bottom:16px">Download all active memories as JSON</p>
          <button class="btn btn-primary" onclick="doExport()">Export JSON</button>
        </div>
        <div class="card">
          <div class="card-header"><span class="icon">&#8679;</span> Import</div>
          <p style="font-size:12px;color:var(--text-dim);margin-bottom:16px">Upload a previously exported JSON file</p>
          <input type="file" id="import-file" accept=".json" style="margin-bottom:12px">
          <br>
          <button class="btn btn-primary" onclick="doImport()">Import</button>
          <div id="import-result" style="margin-top:12px;font-size:12px"></div>
        </div>
      </div>
    </div>

  </main>
</div>

<!-- Toast container -->
<div class="toast-container" id="toast-container"></div>

<script>
/* ── Stato globale ─────────────────────────────────────────────────── */
let currentOffset = 0;
let lastQuery = '';
let lastHasMore = false;

/* ── Helpers ───────────────────────────────────────────────────────── */
function agentId() { return document.getElementById('agent-id').value || 'default'; }
function headers() { return { 'Content-Type': 'application/json', 'X-Agent-Id': agentId() }; }

async function api(path, opts = {}) {
  const url = window.location.origin + path;
  const res = await fetch(url, { headers: headers(), ...opts });
  if (!res.ok) {
    const body = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(body.detail || JSON.stringify(body));
  }
  if (res.status === 204) return null;
  return res.json();
}

function toast(msg, type = 'success') {
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.textContent = msg;
  document.getElementById('toast-container').appendChild(el);
  setTimeout(() => el.remove(), 3000);
}

function esc(s) {
  const d = document.createElement('div');
  d.textContent = s;
  return d.innerHTML;
}

function truncate(s, n = 80) { return s.length > n ? s.slice(0, n) + '...' : s; }

function stars(n) { return '<span class="importance">' + '★'.repeat(n) + '<span style="color:var(--border)">' + '★'.repeat(5 - n) + '</span></span>'; }

function decayBar(score) {
  const pct = Math.round(score * 100);
  const color = score > 0.6 ? 'var(--green)' : score > 0.3 ? 'var(--amber)' : 'var(--red)';
  return '<span class="decay-bar"><span class="decay-bar-fill" style="width:' + pct + '%;background:' + color + '"></span></span>' + pct + '%';
}

function fmtDate(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: '2-digit' }) + ' ' +
         d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
}

/* ── Navigazione ───────────────────────────────────────────────────── */
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    item.classList.add('active');
    document.getElementById('page-' + item.dataset.page).classList.add('active');
  });
});

/* ── Overview ──────────────────────────────────────────────────────── */
async function loadOverview() {
  try {
    const health = await api('/health');
    document.getElementById('stat-version').textContent = health.version || '?';
    document.getElementById('stat-semantic').textContent = health.semantic_search ? 'ON' : 'OFF';
    document.getElementById('stat-semantic').style.color = health.semantic_search ? 'var(--green)' : 'var(--text-dim)';
    document.getElementById('status-dot').classList.remove('offline');
  } catch {
    document.getElementById('status-dot').classList.add('offline');
  }

  try {
    const exp = await api('/export');
    const mems = exp.memories || [];
    document.getElementById('stat-total').textContent = exp.total || 0;

    // Conteggio per categoria
    const cats = {};
    mems.forEach(m => { cats[m.category] = (cats[m.category] || 0) + 1; });
    document.getElementById('stat-categories').textContent = Object.keys(cats).length;

    const catDiv = document.getElementById('category-breakdown');
    if (Object.keys(cats).length === 0) {
      catDiv.innerHTML = '<div class="empty"><span class="empty-icon">&#9673;</span>No memories yet</div>';
      return;
    }

    let html = '<div style="display:flex;flex-wrap:wrap;gap:12px">';
    const sorted = Object.entries(cats).sort((a, b) => b[1] - a[1]);
    const max = sorted[0][1];
    for (const [cat, count] of sorted) {
      const pct = Math.round((count / max) * 100);
      html += '<div style="flex:1;min-width:140px;padding:12px;background:var(--bg-input);border-radius:var(--radius-sm);border:1px solid var(--border)">' +
        '<div style="display:flex;justify-content:space-between;margin-bottom:8px">' +
        '<span class="badge badge-cat">' + esc(cat) + '</span>' +
        '<span style="color:var(--text-bright);font-weight:600">' + count + '</span></div>' +
        '<div style="height:4px;background:var(--border);border-radius:2px;overflow:hidden">' +
        '<div style="width:' + pct + '%;height:100%;background:var(--accent);border-radius:2px"></div></div></div>';
    }
    html += '</div>';
    catDiv.innerHTML = html;
  } catch { /* ignora */ }
}

/* ── Search ────────────────────────────────────────────────────────── */
async function doSearch(offset) {
  const q = document.getElementById('search-q').value.trim();
  if (!q) return toast('Enter a search query', 'error');
  lastQuery = q;
  currentOffset = offset || 0;
  const limit = parseInt(document.getElementById('search-limit').value) || 10;
  const semantic = document.getElementById('search-semantic').checked;

  try {
    const data = await api('/search?q=' + encodeURIComponent(q) + '&limit=' + limit + '&offset=' + currentOffset + '&semantic=' + semantic);
    lastHasMore = data.has_more;
    document.getElementById('search-total').textContent = data.total + ' results' + (data.total > limit ? ' (page ' + (Math.floor(currentOffset / limit) + 1) + ')' : '');
    document.getElementById('search-prev').disabled = currentOffset === 0;
    document.getElementById('search-next').disabled = !data.has_more;

    const tbody = document.getElementById('search-results-body');
    if (data.results.length === 0) {
      tbody.innerHTML = '<tr><td colspan="7" class="empty">No results found</td></tr>';
    } else {
      tbody.innerHTML = data.results.map(r =>
        '<tr>' +
        '<td style="color:var(--text-dim)">#' + r.id + '</td>' +
        '<td title="' + esc(r.content) + '">' + esc(truncate(r.content)) + '</td>' +
        '<td><span class="badge badge-cat">' + esc(r.category) + '</span></td>' +
        '<td>' + stars(r.importance) + '</td>' +
        '<td>' + decayBar(r.decay_score) + '</td>' +
        '<td style="font-size:11px;color:var(--text-dim)">' + fmtDate(r.created_at) + '</td>' +
        '<td><button class="btn btn-danger btn-sm" onclick="doDelete(' + r.id + ', this)">Del</button></td>' +
        '</tr>'
      ).join('');
    }
    document.getElementById('search-results-card').style.display = 'block';
  } catch (e) { toast(e.message, 'error'); }
}

function searchPage(dir) {
  const limit = parseInt(document.getElementById('search-limit').value) || 10;
  doSearch(Math.max(0, currentOffset + dir * limit));
}

/* ── Save ──────────────────────────────────────────────────────────── */
async function doSave() {
  const content = document.getElementById('save-content').value.trim();
  if (!content) return toast('Content is required', 'error');
  const payload = {
    content,
    category: document.getElementById('save-category').value,
    importance: parseInt(document.getElementById('save-importance').value) || 1,
  };
  const ttl = document.getElementById('save-ttl').value;
  if (ttl) payload.ttl_hours = parseInt(ttl);

  try {
    const data = await api('/save', { method: 'POST', body: JSON.stringify(payload) });
    toast('Memory #' + data.id + ' saved (importance: ' + data.importance + ')');
    document.getElementById('save-content').value = '';
  } catch (e) { toast(e.message, 'error'); }
}

/* ── Delete ────────────────────────────────────────────────────────── */
async function doDelete(id, btn) {
  if (!confirm('Delete memory #' + id + '?')) return;
  try {
    await api('/memories/' + id, { method: 'DELETE' });
    toast('Memory #' + id + ' deleted');
    btn.closest('tr').remove();
  } catch (e) { toast(e.message, 'error'); }
}

/* ── Tags ──────────────────────────────────────────────────────────── */
async function doTagSearch() {
  const tag = document.getElementById('tag-search-q').value.trim();
  if (!tag) return;
  try {
    const data = await api('/tags/' + encodeURIComponent(tag) + '/memories');
    const div = document.getElementById('tag-search-results');
    if (data.results.length === 0) {
      div.innerHTML = '<div class="empty">No memories with tag "' + esc(tag) + '"</div>';
      return;
    }
    div.innerHTML = '<table><thead><tr><th>ID</th><th>Content</th><th>Category</th><th>Importance</th></tr></thead><tbody>' +
      data.results.map(r =>
        '<tr><td>#' + r.id + '</td><td>' + esc(truncate(r.content)) + '</td><td><span class="badge badge-cat">' + esc(r.category) + '</span></td><td>' + stars(r.importance) + '</td></tr>'
      ).join('') + '</tbody></table>';
  } catch (e) { toast(e.message, 'error'); }
}

async function doAddTags() {
  const id = document.getElementById('tag-memory-id').value;
  const tags = document.getElementById('tag-input').value.split(',').map(t => t.trim()).filter(Boolean);
  if (!id || !tags.length) return toast('Memory ID and tags required', 'error');
  try {
    const data = await api('/memories/' + id + '/tags', { method: 'POST', body: JSON.stringify({ tags }) });
    toast(data.count + ' tags on memory #' + id);
    showTagResult(data);
  } catch (e) { toast(e.message, 'error'); }
}

async function doRemoveTags() {
  const id = document.getElementById('tag-memory-id').value;
  const tags = document.getElementById('tag-input').value.split(',').map(t => t.trim()).filter(Boolean);
  if (!id || !tags.length) return toast('Memory ID and tags required', 'error');
  try {
    const data = await api('/memories/' + id + '/tags', { method: 'DELETE', body: JSON.stringify({ tags }) });
    toast('Tags removed from memory #' + id);
    showTagResult(data);
  } catch (e) { toast(e.message, 'error'); }
}

async function doGetTags() {
  const id = document.getElementById('tag-memory-id').value;
  if (!id) return toast('Memory ID required', 'error');
  try {
    const data = await api('/memories/' + id + '/tags');
    showTagResult(data);
  } catch (e) { toast(e.message, 'error'); }
}

function showTagResult(data) {
  const div = document.getElementById('tag-manage-result');
  if (!data.tags.length) { div.innerHTML = '<span style="color:var(--text-dim)">No tags</span>'; return; }
  div.innerHTML = data.tags.map(t => '<span class="badge badge-tag">' + esc(t) + '</span> ').join('');
}

/* ── Relations ─────────────────────────────────────────────────────── */
async function doGetRelations() {
  const id = document.getElementById('rel-view-id').value;
  if (!id) return toast('Memory ID required', 'error');
  try {
    const data = await api('/memories/' + id + '/relations');
    const div = document.getElementById('rel-results');
    if (!data.relations.length) { div.innerHTML = '<div class="empty">No relations</div>'; return; }
    div.innerHTML = '<table><thead><tr><th>Source</th><th>Target</th><th>Relation</th><th>Content</th></tr></thead><tbody>' +
      data.relations.map(r =>
        '<tr><td>#' + r.source_id + '</td><td>#' + r.target_id + '</td><td><span class="badge badge-cat">' + esc(r.relation) + '</span></td><td>' + esc(truncate(r.related_content || '', 60)) + '</td></tr>'
      ).join('') + '</tbody></table>';
  } catch (e) { toast(e.message, 'error'); }
}

async function doAddRelation() {
  const source = document.getElementById('rel-source').value;
  const target = document.getElementById('rel-target').value;
  const relation = document.getElementById('rel-type').value || 'related';
  if (!source || !target) return toast('Source and target required', 'error');
  try {
    await api('/memories/' + source + '/relations', { method: 'POST', body: JSON.stringify({ target_id: parseInt(target), relation }) });
    toast('Relation created: #' + source + ' → #' + target);
  } catch (e) { toast(e.message, 'error'); }
}

/* ── Timeline ──────────────────────────────────────────────────────── */
async function doTimeline() {
  const subject = document.getElementById('timeline-subject').value.trim();
  if (!subject) return toast('Enter a subject', 'error');
  const limit = parseInt(document.getElementById('timeline-limit').value) || 20;
  try {
    const data = await api('/timeline?subject=' + encodeURIComponent(subject) + '&limit=' + limit);
    const div = document.getElementById('timeline-results');
    if (!data.results.length) { div.innerHTML = '<div class="empty"><span class="empty-icon">&#8982;</span>No timeline entries for "' + esc(subject) + '"</div>'; return; }
    div.innerHTML = '<div class="timeline">' + data.results.map(r =>
      '<div class="timeline-item">' +
      '<div class="timeline-date">' + fmtDate(r.created_at) + ' &middot; <span class="badge badge-cat">' + esc(r.category) + '</span> &middot; ' + decayBar(r.decay_score) + '</div>' +
      '<div class="timeline-content">' + esc(r.content) + '</div>' +
      '</div>'
    ).join('') + '</div>';
  } catch (e) { toast(e.message, 'error'); }
}

/* ── Maintenance ───────────────────────────────────────────────────── */
async function doDecay() {
  const btn = document.getElementById('btn-decay');
  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>';
  try {
    const data = await api('/decay/run', { method: 'POST' });
    const el = document.getElementById('decay-result');
    el.textContent = '✓ ' + data.updated + ' memories updated';
    el.style.display = 'block';
    toast('Decay pass complete: ' + data.updated + ' updated');
  } catch (e) { toast(e.message, 'error'); }
  finally { btn.disabled = false; btn.textContent = 'Run Decay'; }
}

async function doCompress() {
  const btn = document.getElementById('btn-compress');
  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>';
  try {
    const data = await api('/compress', { method: 'POST' });
    const el = document.getElementById('compress-result');
    el.textContent = '✓ ' + data.clusters_found + ' clusters, ' + data.memories_merged + ' merged, ' + data.new_records_created + ' created';
    el.style.display = 'block';
    toast('Compression complete');
  } catch (e) { toast(e.message, 'error'); }
  finally { btn.disabled = false; btn.textContent = 'Run Compress'; }
}

async function doCleanup() {
  const btn = document.getElementById('btn-cleanup');
  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>';
  try {
    const data = await api('/cleanup', { method: 'POST' });
    const el = document.getElementById('cleanup-result');
    el.textContent = '✓ ' + data.removed + ' expired memories removed';
    el.style.display = 'block';
    toast('Cleanup complete: ' + data.removed + ' removed');
  } catch (e) { toast(e.message, 'error'); }
  finally { btn.disabled = false; btn.textContent = 'Run Cleanup'; }
}

/* ── Export / Import ───────────────────────────────────────────────── */
async function doExport() {
  try {
    const data = await api('/export');
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'kore-export-' + agentId() + '-' + new Date().toISOString().slice(0, 10) + '.json';
    a.click();
    URL.revokeObjectURL(url);
    toast('Exported ' + data.total + ' memories');
  } catch (e) { toast(e.message, 'error'); }
}

async function doImport() {
  const file = document.getElementById('import-file').files[0];
  if (!file) return toast('Select a JSON file', 'error');
  try {
    const text = await file.text();
    const json = JSON.parse(text);
    const memories = json.memories || json;
    if (!Array.isArray(memories)) throw new Error('Invalid format: expected { memories: [...] }');
    const data = await api('/import', { method: 'POST', body: JSON.stringify({ memories }) });
    document.getElementById('import-result').innerHTML = '<span style="color:var(--green)">✓ ' + data.imported + ' memories imported</span>';
    toast('Imported ' + data.imported + ' memories');
  } catch (e) { toast(e.message, 'error'); }
}

/* ── Keyboard shortcut: Enter per search ───────────────────────────── */
document.getElementById('search-q').addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });
document.getElementById('tag-search-q').addEventListener('keydown', e => { if (e.key === 'Enter') doTagSearch(); });
document.getElementById('timeline-subject').addEventListener('keydown', e => { if (e.key === 'Enter') doTimeline(); });

/* ── Init ──────────────────────────────────────────────────────────── */
loadOverview();
</script>
</body>
</html>
"""
