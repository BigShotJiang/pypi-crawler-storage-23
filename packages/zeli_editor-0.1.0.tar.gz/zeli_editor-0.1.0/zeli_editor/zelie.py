import os
import sys
from prompt_toolkit import Application
from prompt_toolkit.layout import Layout, HSplit, VSplit, Window, ConditionalContainer
from prompt_toolkit.widgets import TextArea, Frame, Button, RadioList
from prompt_toolkit.lexers import PygmentsLexer
from pygments.lexers.python import PythonLexer
from prompt_toolkit.styles import Style
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.filters import Condition
from prompt_toolkit.widgets import Box
from prompt_toolkit.styles import style_from_pygments_cls, merge_styles
from pygments.styles import get_style_by_name

# 🎨 ESTILO NEON (AJUSTADO PARA VISIBILIDADE)
style = Style.from_dict({
    'frame.border': '#00ff00', 
    'side-bar': 'bg:#111111 #00ff00',
    'button': 'bg:#222222 #00ff00',
    'button.focused': 'bg:#00ff00 #000000',
    'selected': 'bg:#004400',
})

class ZelieMobile:
    def __init__(self):
        self.editando = True if len(sys.argv) > 1 else False
        self.arquivo_atual = sys.argv[1] if len(sys.argv) > 1 else None
        
        #temas 
        self.temas = ["dracula", "monokai", "perldoc", "friendly"] # perldoc/friendly são mais light/pastel
        self.tema_index = 0
        
        # 1. EDITOR (O FOCO PRECISA ESTAR AQUI)
        self.editor = TextArea(
            text="",
            lexer=PygmentsLexer(PythonLexer),
            scrollbar=True,
            line_numbers=True,
            multiline=True,
            wrap_lines=False, # TELA INFINITA (SCROLL X)
            focus_on_click=True,
        )

        arquivos = [a for a in os.listdir('.') if os.path.isfile(a)]
        self.lista_arquivos = RadioList(values=[(a, a) for a in arquivos])
        
        # Cada botão agora ganha sua própria 'janela' com altura 3
        def criar_botao_grande(label, acao):
            return Box(
                body=Button(label, handler=acao),
                height=1, # DISTANCIA ENTRE BOTONES [GERAL]
                padding=0
            )
            
        # 2. BARRA LATERAL (USANDO JANELAS SIMPLES PARA NÃO BUGAR)
        self.menu_lateral = HSplit([
            criar_botao_grande(" 📁 MENU ", self.ir_para_menu),
            Window(height=1), # Respiro
            criar_botao_grande(" 💾 SAVE ", self.salvar),
            Window(height=1), # Respiro
            criar_botao_grande(" ↩️ WRAP ", self.toggle_wrap),
            Window(height=1), # Respiro
            criar_botao_grande(" 🌙 TEMA ", self.trocar_tema),
            Window(height=1), # Respiro
            criar_botao_grande(" ❌ SAIR ", self.gerenciar_saida),
            # Preenche o resto da lateral com vazio
            Window(), 
        ], width=14, style='class:side-bar') # Largura 12 para caber o texto
        
        # 3. TELAS
        self.container_editor = Frame(title=" EDITOR ", body=self.editor)
        self.container_menu = Frame(title=" MENU ", body=HSplit([
            self.lista_arquivos,
            Window(height=1),
            Button("ABRIR", handler=self.abrir_da_lista)
        ]))

        # 4. LAYOUT FINAL (V-SPLIT COM PESO)
        self.layout_total = VSplit([
            # Lateral com largura fixa pequena
            self.menu_lateral,
            # Divisória
            Window(width=1, char='|', style='class:frame.border'), 
            # Área principal - Usamos ConditionalContainer
            ConditionalContainer(
                content=self.container_editor,
                filter=Condition(lambda: self.editando)
            ),
            ConditionalContainer(
                content=self.container_menu,
                filter=Condition(lambda: not self.editando)
            ),
        ])
        
        if self.arquivo_atual:
            self.carregar_arquivo(self.arquivo_atual)
        
# --- OUTRAS FUNCIONES ---
    def trocar_tema(self):
        # 1. Escolhe o próximo tema da lista
        self.tema_index = (self.tema_index + 1) % len(self.temas)
        nome_tema = self.temas[self.tema_index]
        
        # 2. BUSCA O ESTILO (Aqui é onde estava o erro!)
        # Criamos a variável 'novo_pygments_style' com segurança
        novo_pygments_style = style_from_pygments_cls(get_style_by_name(nome_tema))
        
        # 3. Define o estilo da Interface (UI)
        ui_style = Style.from_dict({
            'frame.border': '#00ff00',
            'side-bar': 'bg:#111111 #00ff00',
            'button': 'bg:#222222 #00ff00',
            'button.focused': 'bg:#00ff00 #000000',
        })
        
        # 4. JUNTA TUDO E APLICA (Usando global app para garantir o acesso)
        global app
        if 'app' in globals():
            # Mesclamos o novo estilo do pygments com o da nossa UI
            app.style = merge_styles([novo_pygments_style, ui_style])
            
        # Atualiza o título para você saber qual tema está usando
        self.container_editor.title = f" TEMA: {nome_tema.upper()} "
        
    def carregar_arquivo(self, nome):
        try:
            with open(nome, "r", encoding="utf-8") as f:
                self.editor.text = f.read()
            self.arquivo_atual = nome
            self.container_editor.title = f" [{nome}] "
            self.editando = True
        except: pass

    def abrir_da_lista(self):
        nome = self.lista_arquivos.current_value
        if nome: self.carregar_arquivo(nome)

    def ir_para_menu(self):
        self.editando = False
        self.mensagem_status = " 📁 Abrindo Arquivos. "
        
    def salvar(self):
        if self.arquivo_atual:
            try:
                with open(self.arquivo_atual, "w", encoding="utf-8") as f:
                    f.write(self.editor.text)
                
                # O "PRINT" DA VITÓRIA:
                self.container_editor.title = f" ✅ SALVO COM SUCESSO: {self.arquivo_atual} "
            except Exception as e:
                self.container_editor.title = f" ❌ ERRO AO SALVAR: {e} "
                
    def toggle_wrap(self):
        self.editor.wrap_lines = not self.editor.wrap_lines

    def gerenciar_saida(self):
        if self.editando: self.editando = False
        else: app.exit()
        
    # SETUP DO MOUSE
    def run(self):
        global app
        kb = KeyBindings()
        
        # 🚀 ATALHOS PARA SCROLL X VELOZ
        @kb.add('escape', 'right') # Alt + Direita
        def _(event):
            for _ in range(10): event.current_buffer.cursor_right()

        @kb.add('escape', 'left')  # Alt + Esquerda
        def _(event):
            for _ in range(10): event.current_buffer.cursor_left()

        @kb.add('c-l') # Ctrl + L (Fim da linha)
        def _(event):
            event.current_buffer.cursor_position += len(event.current_buffer.document.get_end_of_line())
        # Pegamos o tema atual (Dracula) antes de carregar a UI
        estilo_pygments = style_from_pygments_cls(get_style_by_name(self.temas[self.tema_index]))
        
        # Mesclamos com o seu estilo Neon de bordas e botões
        estilo_final = merge_styles([estilo_pygments, style])
        
        # CONFIGURAÇÃO DA APP
        app = Application(
            layout=Layout(
                self.layout_total, 
                focused_element=self.editor if self.editando else self.lista_arquivos
            ),
            full_screen=True, 
            style=estilo_final, 
            key_bindings=kb, 
            mouse_support=True, # ATIVA O TOQUE
            refresh_interval=0.1 # Deixa a resposta do scroll mais rápida
        )
        app.run()

def main(): # permite aceitar comando arquivo direto: zelie teste.py
    ZelieMobile().run()

if __name__ == "__main__":
    ZelieMobile().run()
