"""
Django migrations for Tolov.
"""
