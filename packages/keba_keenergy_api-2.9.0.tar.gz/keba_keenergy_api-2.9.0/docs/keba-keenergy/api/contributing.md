# Contributing

{%
    include-markdown "../../../README.md"
    start="<!--start-contributing-->"
    end="<!--end-contributing-->"
%}

{%
    include-markdown "../../../CONTRIBUTING.md"
    start="<!--start-contributing-->"
    end="<!--end-contributing-->"
%}
