import os
import yaml
from typing import Dict, Any, Optional, List
from pathlib import Path


class DocLintConfig:
    """文档检查配置管理器"""

    DEFAULT_CONFIG_FILE = ".stylecheckrrc.yaml"
    DEFAULT_RULES = {
        "paired-punctuation": True,
        "llm-chinese-typo": False
    }
    DEFAULT_LLM_CONFIG = {
        "model": "gpt-3.5-turbo",
        "base_url": "https://api.openai.com/v1",
        "timeout": 30,
        "max_tokens": 1024,
        "cache": True
    }

    def __init__(self, config_path: Optional[str] = None):
        """
        初始化配置管理器
        :param config_path: 配置文件路径，默认使用 .stylecheckrrc.yaml
        """
        self.config_path = config_path or self.DEFAULT_CONFIG_FILE
        self.config = self._load_config()
        self.rules_config = self._parse_rules_config()
        self.llm_config = self._parse_llm_config()
        self.ignore_patterns = self._parse_ignore_patterns()

    def _load_config(self) -> Dict[str, Any]:
        """加载配置文件，支持继承"""
        config = {}

        # 1. 加载继承配置
        extends = self.config.get('extends', '')
        if extends:
            if extends.startswith('package:'):
                # 从包加载
                package_path = extends.replace('package:', '')
                config = self._load_package_config(package_path)
            else:
                # 从文件加载
                config = self._load_file_config(extends)

        # 2. 加载当前配置（覆盖继承配置）
        if os.path.exists(self.config_path):
            with open(self.config_path, 'r', encoding='utf-8') as f:
                local_config = yaml.safe_load(f) or {}
                config = self._merge_config(config, local_config)

        return config

    def _merge_config(self, base: Dict, override: Dict) -> Dict:
        """深度合并配置"""
        result = base.copy()
        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_config(result[key], value)
            else:
                result[key] = value
        return result

    def _parse_rules_config(self) -> Dict[str, Dict[str, Any]]:
        """
        解析规则配置，统一为字典格式
        支持布尔值和字典两种配置方式
        """
        rules_raw = self.config.get('rules', {})
        rules_config = {}

        for rule_id, rule_value in rules_raw.items():
            if isinstance(rule_value, bool):
                # 布尔值：只控制开关
                rules_config[rule_id] = {
                    "enable": rule_value,
                    "severity": None,
                    "model": None
                }
            elif isinstance(rule_value, dict):
                # 字典：详细配置
                rules_config[rule_id] = {
                    "enable": rule_value.get("enable", True),
                    "severity": rule_value.get("severity"),
                    "model": rule_value.get("model"),
                    **rule_value  # 合并其他自定义配置
                }
            else:
                # 默认启用
                rules_config[rule_id] = {"enable": True, "severity": None, "model": None}

        return rules_config

    def _parse_llm_config(self) -> Dict[str, Any]:
        """解析全局 LLM 配置"""
        llm_raw = self.config.get('llm', {})
        # 合并默认配置和用户配置
        merged = {**self.DEFAULT_LLM_CONFIG, **llm_raw}

        # 处理 API Key（从环境变量读取）
        api_key_env = llm_raw.get('api_key_env', 'DOC_LINT_LLM_KEY')
        merged['api_key'] = os.getenv(api_key_env, '')

        return merged

    def _parse_ignore_patterns(self) -> List[str]:
        """解析忽略文件模式"""
        return self.config.get('ignore', [])

    def is_rule_enabled(self, rule_id: str) -> bool:
        """检查规则是否启用"""
        rule_config = self.rules_config.get(rule_id, {})
        return rule_config.get("enable", False)

    def get_rule_config(self, rule_id: str) -> Dict[str, Any]:
        """获取规则配置（合并全局 LLM 配置）"""
        rule_config = self.rules_config.get(rule_id, {}).copy()

        # 如果是 LLM 规则，合并全局 LLM 配置
        if rule_id.startswith("llm-"):
            merged_config = {**self.llm_config, **rule_config}
            return merged_config

        return rule_config

    def get_all_enabled_rules(self) -> List[str]:
        """获取所有启用的规则 ID 列表"""
        return [rule_id for rule_id, config in self.rules_config.items()
                if config.get("enable", False)]

    def should_ignore_file(self, file_path: str) -> bool:
        """检查文件是否应该被忽略"""
        from fnmatch import fnmatch
        for pattern in self.ignore_patterns:
            if fnmatch(file_path, pattern):
                return True
        return False

    def __repr__(self):
        return f"DocLintConfig(rules={self.get_all_enabled_rules()})"