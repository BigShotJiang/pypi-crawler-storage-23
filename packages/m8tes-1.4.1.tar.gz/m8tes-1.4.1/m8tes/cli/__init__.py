"""
CLI module for m8tes SDK.

Provides interactive command-line interface for common SDK operations.
"""

from .main import main

__all__ = ["main"]
