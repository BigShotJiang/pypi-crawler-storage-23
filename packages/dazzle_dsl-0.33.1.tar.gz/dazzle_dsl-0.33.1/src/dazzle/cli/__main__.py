"""Entry point for python -m dazzle.cli"""

from dazzle.cli import main

if __name__ == "__main__":
    main()
