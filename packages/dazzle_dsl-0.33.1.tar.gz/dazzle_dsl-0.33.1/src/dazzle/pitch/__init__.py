"""DAZZLE Pitch Deck generation package."""
