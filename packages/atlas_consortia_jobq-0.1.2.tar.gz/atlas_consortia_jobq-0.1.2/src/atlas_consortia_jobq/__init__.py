from atlas_consortia_jobq.queue import JobQueue

__version__ = "0.1.2"
__all__ = ["JobQueue"]
