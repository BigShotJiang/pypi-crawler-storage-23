from .model import Model  # noqa: F401

__all__ = "Model"
