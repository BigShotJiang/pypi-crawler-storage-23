"""
Tests for humanizer guardrail integration.

Run with:
    python -m pytest tests/test_humanizer_guardrails.py -v
"""
import unittest
from unittest.mock import MagicMock, patch

from soprano_sdk.guardrails.base_guardrail import BaseGuardrail, GuardrailResult


# ---------------------------------------------------------------------------
# WorkflowEngine._resolve_humanizer_guardrails
# ---------------------------------------------------------------------------

class TestResolveHumanizerGuardrails(unittest.TestCase):

    def _make_engine(self, humanization_guardrails=None, registry=None):
        """Build a WorkflowEngine with mocked YAML loading."""
        guardrails_list = humanization_guardrails or []
        registry = registry or {}

        with patch("soprano_sdk.core.engine.WorkflowEngine.__init__", return_value=None):
            from soprano_sdk.core.engine import WorkflowEngine
            engine = WorkflowEngine.__new__(WorkflowEngine)

        engine.config = {
            "humanization_agent": {"guardrails": guardrails_list},
        }
        engine.guardrail_registry = registry
        return engine

    def test_no_guardrails_config_returns_empty(self):
        engine = self._make_engine()
        engine.config = {"humanization_agent": {}}
        result = engine._resolve_humanizer_guardrails()
        self.assertEqual(result, [])

    def test_no_humanization_config_returns_empty(self):
        engine = self._make_engine()
        engine.config = {}
        result = engine._resolve_humanizer_guardrails()
        self.assertEqual(result, [])

    def test_resolves_guardrails_from_registry(self):
        from soprano_sdk.guardrails.functional_guardrail import ThoughtActionGuardrail
        guardrail = ThoughtActionGuardrail(error_message="retry")
        engine = self._make_engine(
            humanization_guardrails=["thought_action_check"],
            registry={"thought_action_check": guardrail},
        )
        result = engine._resolve_humanizer_guardrails()
        self.assertEqual(len(result), 1)
        self.assertIs(result[0], guardrail)

    def test_unknown_name_skipped(self):
        engine = self._make_engine(
            humanization_guardrails=["nonexistent"],
            registry={},
        )
        result = engine._resolve_humanizer_guardrails()
        self.assertEqual(result, [])


# ---------------------------------------------------------------------------
# WorkflowEngine._build_humanizer_grounding_source
# ---------------------------------------------------------------------------

class TestBuildHumanizerGroundingSource(unittest.TestCase):

    def _make_engine(self):
        with patch("soprano_sdk.core.engine.WorkflowEngine.__init__", return_value=None):
            from soprano_sdk.core.engine import WorkflowEngine
            engine = WorkflowEngine.__new__(WorkflowEngine)
        return engine

    def test_includes_all_three_parts(self):
        engine = self._make_engine()
        result = engine._build_humanizer_grounding_source(
            system_prompt="Be friendly.",
            conversation_history=[
                {"role": "user", "content": "Hi"},
                {"role": "assistant", "content": "Hello!"},
            ],
            reference_message="Your order #123 is confirmed.",
        )
        self.assertIn("HUMANIZATION INSTRUCTIONS:\nBe friendly.", result)
        self.assertIn("CONVERSATION HISTORY:", result)
        self.assertIn("USER: Hi", result)
        self.assertIn("ASSISTANT: Hello!", result)
        self.assertIn("REFERENCE MESSAGE:\nYour order #123 is confirmed.", result)

    def test_no_conversation_history(self):
        engine = self._make_engine()
        result = engine._build_humanizer_grounding_source(
            system_prompt="Be warm.",
            conversation_history=None,
            reference_message="Done.",
        )
        self.assertIn("HUMANIZATION INSTRUCTIONS:\nBe warm.", result)
        self.assertNotIn("CONVERSATION HISTORY:", result)
        self.assertIn("REFERENCE MESSAGE:\nDone.", result)

    def test_empty_conversation_history(self):
        engine = self._make_engine()
        result = engine._build_humanizer_grounding_source(
            system_prompt="Prompt",
            conversation_history=[],
            reference_message="Msg",
        )
        self.assertNotIn("CONVERSATION HISTORY:", result)


# ---------------------------------------------------------------------------
# WorkflowEngine._check_humanizer_guardrails
# ---------------------------------------------------------------------------

class TestCheckHumanizerGuardrails(unittest.TestCase):

    def _make_engine(self, guardrails):
        with patch("soprano_sdk.core.engine.WorkflowEngine.__init__", return_value=None):
            from soprano_sdk.core.engine import WorkflowEngine
            engine = WorkflowEngine.__new__(WorkflowEngine)
        engine.humanizer_guardrails = guardrails
        return engine

    def test_all_pass_returns_true(self):
        g = MagicMock(spec=BaseGuardrail)
        g.check.return_value = GuardrailResult(passed=True)
        engine = self._make_engine([g])
        result = engine._check_humanizer_guardrails(
            "humanized msg", "system prompt", [{"role": "user", "content": "hi"}],
            "reference msg", {}
        )
        self.assertTrue(result)

    def test_failure_returns_false(self):
        g = MagicMock(spec=BaseGuardrail)
        g.check.return_value = GuardrailResult(passed=False, error_message="not grounded")
        engine = self._make_engine([g])
        result = engine._check_humanizer_guardrails(
            "hallucinated msg", "system prompt", [{"role": "user", "content": "hi"}],
            "reference msg", {}
        )
        self.assertFalse(result)

    def test_passes_grounding_source_and_query(self):
        g = MagicMock(spec=BaseGuardrail)
        g.check.return_value = GuardrailResult(passed=True)
        engine = self._make_engine([g])
        engine._check_humanizer_guardrails(
            "humanized msg", "system prompt",
            [{"role": "user", "content": "what's my order?"}],
            "reference msg", {}
        )
        call_kwargs = g.check.call_args[1]
        self.assertIn("grounding_source", call_kwargs)
        self.assertEqual(call_kwargs["query"], "what's my order?")

    def test_connection_error_fails_open(self):
        from soprano_sdk.guardrails.base_guardrail import GuardrailsConnectionError
        g = MagicMock(spec=BaseGuardrail)
        g.check.side_effect = GuardrailsConnectionError("network error")
        engine = self._make_engine([g])
        result = engine._check_humanizer_guardrails(
            "humanized msg", "system prompt", [], "reference msg", {}
        )
        self.assertTrue(result)

    def test_uses_last_user_message_as_query(self):
        g = MagicMock(spec=BaseGuardrail)
        g.check.return_value = GuardrailResult(passed=True)
        engine = self._make_engine([g])
        engine._check_humanizer_guardrails(
            "msg", "prompt",
            [
                {"role": "user", "content": "first"},
                {"role": "assistant", "content": "response"},
                {"role": "user", "content": "second"},
            ],
            "ref", {}
        )
        call_kwargs = g.check.call_args[1]
        self.assertEqual(call_kwargs["query"], "second")

    def test_no_conversation_history_empty_query(self):
        g = MagicMock(spec=BaseGuardrail)
        g.check.return_value = GuardrailResult(passed=True)
        engine = self._make_engine([g])
        engine._check_humanizer_guardrails(
            "msg", "prompt", None, "ref", {}
        )
        call_kwargs = g.check.call_args[1]
        self.assertEqual(call_kwargs["query"], "")


# ---------------------------------------------------------------------------
# _humanize_message guardrail integration (retry & fallback)
# ---------------------------------------------------------------------------

class TestHumanizeMessageGuardrailIntegration(unittest.TestCase):

    def _make_engine(self, guardrails=None):
        with patch("soprano_sdk.core.engine.WorkflowEngine.__init__", return_value=None):
            from soprano_sdk.core.engine import WorkflowEngine
            engine = WorkflowEngine.__new__(WorkflowEngine)
        engine.humanizer_guardrails = guardrails or []
        engine.config = {"humanization_agent": {}}
        engine.configs = {}
        return engine

    def _mock_llm_response(self, message="Humanized hello!"):
        from soprano_sdk.core.engine import HumanizedResponse
        response = MagicMock(spec=HumanizedResponse)
        response.message = message
        response.options = None
        response.is_selectable = None
        return response

    @patch("soprano_sdk.core.engine.trace_agent_invocation")
    @patch("soprano_sdk.core.engine.get_model")
    def test_no_guardrails_passes_through(self, mock_get_model, mock_trace):
        engine = self._make_engine()
        engine._get_humanization_model_config = MagicMock(return_value={"model_name": "test"})
        engine._aggregate_conversation_history = MagicMock(return_value=[])
        engine.get_localization_instructions = MagicMock(return_value="")

        mock_llm = MagicMock()
        mock_llm.invoke.return_value = self._mock_llm_response()
        mock_get_model.return_value = mock_llm

        mock_span = MagicMock()
        mock_span.is_recording.return_value = True
        mock_trace.return_value.__enter__ = MagicMock(return_value=mock_span)
        mock_trace.return_value.__exit__ = MagicMock(return_value=False)

        result = engine._humanize_message("Hello", {})
        self.assertEqual(result.message, "Humanized hello!")

    @patch("soprano_sdk.core.engine.trace_agent_invocation")
    @patch("soprano_sdk.core.engine.get_model")
    def test_guardrail_pass_returns_humanized(self, mock_get_model, mock_trace):
        g = MagicMock(spec=BaseGuardrail)
        g.check.return_value = GuardrailResult(passed=True)
        g.max_retries = 0

        engine = self._make_engine(guardrails=[g])
        engine._get_humanization_model_config = MagicMock(return_value={"model_name": "test"})
        engine._aggregate_conversation_history = MagicMock(return_value=[])
        engine.get_localization_instructions = MagicMock(return_value="")

        mock_llm = MagicMock()
        mock_llm.invoke.return_value = self._mock_llm_response("Good humanized msg")
        mock_get_model.return_value = mock_llm

        mock_span = MagicMock()
        mock_span.is_recording.return_value = True
        mock_trace.return_value.__enter__ = MagicMock(return_value=mock_span)
        mock_trace.return_value.__exit__ = MagicMock(return_value=False)

        result = engine._humanize_message("Hello", {})
        self.assertEqual(result.message, "Good humanized msg")

    @patch("soprano_sdk.core.engine.trace_agent_invocation")
    @patch("soprano_sdk.core.engine.get_model")
    def test_guardrail_fail_no_retries_falls_back(self, mock_get_model, mock_trace):
        g = MagicMock(spec=BaseGuardrail)
        g.check.return_value = GuardrailResult(passed=False, error_message="not grounded")
        g.max_retries = 0

        engine = self._make_engine(guardrails=[g])
        engine._get_humanization_model_config = MagicMock(return_value={"model_name": "test"})
        engine._aggregate_conversation_history = MagicMock(return_value=[])
        engine.get_localization_instructions = MagicMock(return_value="")

        mock_llm = MagicMock()
        mock_llm.invoke.return_value = self._mock_llm_response("Hallucinated response")
        mock_get_model.return_value = mock_llm

        mock_span = MagicMock()
        mock_span.is_recording.return_value = True
        mock_trace.return_value.__enter__ = MagicMock(return_value=mock_span)
        mock_trace.return_value.__exit__ = MagicMock(return_value=False)

        result = engine._humanize_message("Original message", {})
        # Should fall back to the original reference message
        self.assertEqual(result.message, "Original message")

    @patch("soprano_sdk.core.engine.trace_agent_invocation")
    @patch("soprano_sdk.core.engine.get_model")
    def test_guardrail_fail_then_pass_on_retry(self, mock_get_model, mock_trace):
        g = MagicMock(spec=BaseGuardrail)
        g.check.side_effect = [
            GuardrailResult(passed=False, error_message="not grounded"),
            GuardrailResult(passed=True),
        ]
        g.max_retries = 1

        engine = self._make_engine(guardrails=[g])
        engine._get_humanization_model_config = MagicMock(return_value={"model_name": "test"})
        engine._aggregate_conversation_history = MagicMock(return_value=[])
        engine.get_localization_instructions = MagicMock(return_value="")

        bad_response = self._mock_llm_response("Hallucinated")
        good_response = self._mock_llm_response("Properly grounded")
        mock_llm = MagicMock()
        mock_llm.invoke.side_effect = [bad_response, good_response]
        mock_get_model.return_value = mock_llm

        mock_span = MagicMock()
        mock_span.is_recording.return_value = True
        mock_trace.return_value.__enter__ = MagicMock(return_value=mock_span)
        mock_trace.return_value.__exit__ = MagicMock(return_value=False)

        result = engine._humanize_message("Original", {})
        self.assertEqual(result.message, "Properly grounded")
        # LLM should have been called twice
        self.assertEqual(mock_llm.invoke.call_count, 2)

    @patch("soprano_sdk.core.engine.trace_agent_invocation")
    @patch("soprano_sdk.core.engine.get_model")
    def test_guardrail_fail_all_retries_falls_back(self, mock_get_model, mock_trace):
        g = MagicMock(spec=BaseGuardrail)
        g.check.return_value = GuardrailResult(passed=False, error_message="not grounded")
        g.max_retries = 2

        engine = self._make_engine(guardrails=[g])
        engine._get_humanization_model_config = MagicMock(return_value={"model_name": "test"})
        engine._aggregate_conversation_history = MagicMock(return_value=[])
        engine.get_localization_instructions = MagicMock(return_value="")

        mock_llm = MagicMock()
        mock_llm.invoke.return_value = self._mock_llm_response("Bad response")
        mock_get_model.return_value = mock_llm

        mock_span = MagicMock()
        mock_span.is_recording.return_value = True
        mock_trace.return_value.__enter__ = MagicMock(return_value=mock_span)
        mock_trace.return_value.__exit__ = MagicMock(return_value=False)

        result = engine._humanize_message("Original safe message", {})
        # Should fall back to reference message after all retries exhausted
        self.assertEqual(result.message, "Original safe message")
        # LLM called 3 times: initial + 2 retries
        self.assertEqual(mock_llm.invoke.call_count, 3)


if __name__ == "__main__":
    unittest.main()
