"""Tests for agent adapter logging fixes."""

from unittest.mock import MagicMock, patch
from soprano_sdk.agents.adaptor import (
    LangGraphAgentAdapter,
    CrewAIAgentAdapter,
    AgnoAgentAdapter,
    PydanticAIAgentAdapter,
)


class TestLangGraphAdapterLogging:
    """Test suite for LangGraphAgentAdapter logging."""

    @patch('soprano_sdk.agents.adaptor.logger')
    def test_langgraph_adapter_logs_correct_name(self, mock_logger):
        """Test that LangGraphAgentAdapter logs its correct name."""
        # Create a mock agent
        mock_agent = MagicMock()
        mock_message = MagicMock()
        mock_message.content = "Test response"
        mock_agent.invoke.return_value = {"messages": [mock_message]}

        # Create adapter and invoke
        adapter = LangGraphAgentAdapter(mock_agent)
        adapter.invoke([{"role": "user", "content": "Hello"}])

        # Verify correct logging
        mock_logger.info.assert_called_once_with(
            "Invoking LangGraphAgentAdapter agent with messages"
        )

    @patch('soprano_sdk.agents.adaptor.logger')
    def test_langgraph_adapter_does_not_log_wrong_name(self, mock_logger):
        """Test that LangGraphAgentAdapter does not log 'LangGraph agent'."""
        mock_agent = MagicMock()
        mock_message = MagicMock()
        mock_message.content = "Test response"
        mock_agent.invoke.return_value = {"messages": [mock_message]}

        adapter = LangGraphAgentAdapter(mock_agent)
        adapter.invoke([{"role": "user", "content": "Hello"}])

        # Verify it doesn't log the old incorrect message
        for call in mock_logger.info.call_args_list:
            assert "Invoking LangGraph agent with messages" not in str(call)


class TestCrewAIAdapterLogging:
    """Test suite for CrewAIAgentAdapter logging."""

    @patch('soprano_sdk.agents.adaptor.logger')
    def test_crewai_adapter_logs_correct_name(self, mock_logger):
        """Test that CrewAIAgentAdapter logs its correct name."""
        # Create a mock agent
        mock_agent = MagicMock()
        mock_result = MagicMock()
        mock_result.raw = "Test response"
        mock_agent.kickoff.return_value = mock_result

        mock_output_schema = MagicMock()

        # Create adapter and invoke
        adapter = CrewAIAgentAdapter(mock_agent, mock_output_schema)
        adapter.invoke([{"role": "user", "content": "Hello"}])

        # Verify correct logging
        mock_logger.info.assert_any_call(
            "Invoking CrewAIAgentAdapter agent with messages"
        )

    @patch('soprano_sdk.agents.adaptor.logger')
    def test_crewai_adapter_does_not_log_wrong_name(self, mock_logger):
        """Test that CrewAIAgentAdapter does not log 'LangGraph agent'."""
        mock_agent = MagicMock()
        mock_result = MagicMock()
        mock_result.raw = "Test response"
        mock_agent.kickoff.return_value = mock_result

        mock_output_schema = MagicMock()

        adapter = CrewAIAgentAdapter(mock_agent, mock_output_schema)
        adapter.invoke([{"role": "user", "content": "Hello"}])

        # Verify it doesn't log the old incorrect message
        for call in mock_logger.info.call_args_list:
            assert "Invoking LangGraph agent with messages" not in str(call)


class TestAgnoAdapterLogging:
    """Test suite for AgnoAgentAdapter logging."""

    @patch('soprano_sdk.agents.adaptor.logger')
    def test_agno_adapter_logs_correct_name(self, mock_logger):
        """Test that AgnoAgentAdapter logs its correct name."""
        # Create a mock agent
        mock_agent = MagicMock()
        mock_response = MagicMock()
        mock_response.content = "Test response"
        mock_agent.run.return_value = mock_response

        # Create adapter and invoke
        adapter = AgnoAgentAdapter(mock_agent)
        adapter.invoke([{"role": "user", "content": "Hello"}])

        # Verify correct logging
        mock_logger.info.assert_called_once_with(
            "Invoking AgnoAgentAdapter agent with messages"
        )

    @patch('soprano_sdk.agents.adaptor.logger')
    def test_agno_adapter_does_not_log_wrong_name(self, mock_logger):
        """Test that AgnoAgentAdapter does not log 'LangGraph agent'."""
        mock_agent = MagicMock()
        mock_response = MagicMock()
        mock_response.content = "Test response"
        mock_agent.run.return_value = mock_response

        adapter = AgnoAgentAdapter(mock_agent)
        adapter.invoke([{"role": "user", "content": "Hello"}])

        # Verify it doesn't log the old incorrect message
        for call in mock_logger.info.call_args_list:
            assert "Invoking LangGraph agent with messages" not in str(call)


class TestPydanticAIAdapterLogging:
    """Test suite for PydanticAIAgentAdapter logging."""

    @patch('soprano_sdk.agents.adaptor.logger')
    def test_pydantic_ai_adapter_current_logging_behavior(self, mock_logger):
        """Test that PydanticAIAgentAdapter logs the correct adapter name."""
        mock_agent = MagicMock()
        mock_result = MagicMock()
        mock_result.output = "Test response"
        mock_agent.run_sync.return_value = mock_result

        adapter = PydanticAIAgentAdapter(mock_agent)
        adapter.invoke([{"role": "user", "content": "Hello"}])

        mock_logger.info.assert_called_once_with(
            "Invoking PydanticAI agent with messages"
        )

    @patch('soprano_sdk.agents.adaptor.logger')
    def test_pydantic_ai_adapter_should_log_correct_name(self, mock_logger):
        """Test that PydanticAIAgentAdapter logs the correct name."""
        mock_agent = MagicMock()
        mock_result = MagicMock()
        mock_result.output = "Test response"
        mock_agent.run_sync.return_value = mock_result

        adapter = PydanticAIAgentAdapter(mock_agent)
        adapter.invoke([{"role": "user", "content": "Hello"}])

        mock_logger.info.assert_called_once_with(
            "Invoking PydanticAI agent with messages"
        )
