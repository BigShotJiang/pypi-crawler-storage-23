"""
Integration tests for guardrail behaviour across agent frameworks (respx-mocked LLM).

Full stack: YAML → WorkflowTool → mocked LLM.

  LangGraph (no default guardrails):
    1.  langgraph + explicit guardrail disabled + leaked ReAct → guardrail skipped → field captured → success
    2.  langgraph + no YAML guardrails       + leaked ReAct → no guardrail runs → field captured → success

  CrewAI — explicit guardrail (max_retries=0):
    3.  crewai + explicit enabled (max_retries=0) + clean response  → guardrail passes → success
    4.  crewai + explicit enabled (max_retries=0) + leaked ReAct    → guardrail fires (no retry) → error, stays collecting

  CrewAI — explicit guardrail (max_retries=1):
    5.  crewai + explicit enabled (max_retries=1) + leaked then retry clean → retry passes → success
    6.  crewai + explicit enabled (max_retries=1) + leaked then retry leaked → both fail → error, stays collecting

  CrewAI — explicit disabled (overrides crewai default):
    7.  crewai + explicit disabled (enabled: false) + leaked ReAct → overrides default, skipped → success

  CrewAI — no YAML guardrails (default ThoughtActionGuardrail, max_retries=1):
    8.  crewai + no YAML guardrails + clean response              → default guardrail passes → success
    9.  crewai + no YAML guardrails + leaked then retry clean     → retry passes → success
    10. crewai + no YAML guardrails + leaked then retry leaked    → both fail → error, stays collecting

Run with:
    python -m pytest tests/test_guardrail_behavior.py -v
"""

import uuid

import respx

from tests.helpers import FAKE_LLM_COMPLETIONS, llm_text_response, make_tool, snap

# A response that leaks ReAct internals (Thought:) but also contains the capture pattern.
# With the guardrail enabled  → guardrail fires on "Thought:", violation raised.
# With the guardrail disabled → runner skips it; pattern match finds NAME_CAPTURED: John → success.
LEAKED_RESPONSE = "Thought: found the name. NAME_CAPTURED: John"
CLEAN_RESPONSE = "Thought: found the name. Final Answer: NAME_CAPTURED: John"
CLEAN_PROMPT_RESPONSE = "Thought: I need to ask for the user's name. Final Answer: What is your name?"
GUARDRAIL_ERROR = "I'm sorry, that response was invalid. Please try again."

# Error message precedence constants
FAILURE_MESSAGE = "Something went wrong at the workflow level."
PER_GUARDRAIL_ERROR = "Per-guardrail error message."
FACTORY_DEFAULT_ERROR = "I encountered an issue processing your request. Please try again."

@respx.mock
def test_crewai_enabled_guardrail_clean_response_succeeds():
    """crewai + explicit thought_action_check guardrail (enabled, max_retries=0) + clean responses → success.

    Turn 1: LLM returns CLEAN_PROMPT_RESPONSE (ReAct chain ending with Final Answer) → guardrail passes
            → "What is your name?" extracted and shown to user.
    Turn 2: LLM returns CLEAN_RESPONSE (Final Answer with NAME_CAPTURED) → guardrail passes → success.
    Total LLM calls: 2.
    """
    responses = iter([
        llm_text_response(CLEAN_PROMPT_RESPONSE),
        llm_text_response(CLEAN_RESPONSE),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("guardrails_ta_enabled.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="My name is John", initial_context={})
    assert "Name collected" in str(result2)

    s = snap(tool, tid)
    assert s["name"] == "John"
    assert s["_status"] == "collect_name_end_success"
    assert s.get("_pending_prompt") is None
    assert respx.calls.call_count == 2


@respx.mock
def test_crewai_enabled_guardrail_leaked_response_surfaces_error():
    """crewai + explicit thought_action_check guardrail (enabled, max_retries=0) + leaked ReAct → guardrail fires.

    Turn 1: LLM returns plain prompt → "What is your name?" shown to user.
    Turn 2: LLM returns LEAKED_RESPONSE (Thought: without Final Answer:) → ThoughtActionGuardrail fires
            → GuardrailViolationError → error message returned to user, stays collecting.
    Total LLM calls: 2 (no retry because max_retries=0 in fixture).
    """
    responses = iter([
        llm_text_response("What is your name?"),
        llm_text_response(LEAKED_RESPONSE),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("guardrails_ta_enabled.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="some input", initial_context={})
    assert GUARDRAIL_ERROR in str(result2)

    s = snap(tool, tid)
    assert s.get("name") is None          # field not captured
    assert "collecting" in s["_status"]   # still collecting, not at an outcome
    assert respx.calls.call_count == 2


@respx.mock
def test_langgraph_explicit_guardrail_disabled_leaked_response_passes_through():
    """langgraph + explicit thought_action_check guardrail (enabled: false) + leaked ReAct → passes through → success.

    LangGraph has no default guardrails; the configured guardrail is disabled (enabled: false).
    Turn 1: LLM returns plain prompt → "What is your name?" shown to user.
    Turn 2: LLM returns LEAKED_RESPONSE (Thought: without Final Answer:) → guardrail runner skips disabled
            guardrail → pattern match finds NAME_CAPTURED: John → success.
    Total LLM calls: 2.
    """
    responses = iter([
        llm_text_response("What is your name?"),
        llm_text_response(LEAKED_RESPONSE),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("guardrails_ta_disabled.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="some input", initial_context={})
    assert "Name collected" in str(result2)

    s = snap(tool, tid)
    assert s["name"] == "John"
    assert s["_status"] == "collect_name_end_success"
    assert respx.calls.call_count == 2, "disabled guardrail should result in exactly 2 LLM calls"


@respx.mock
def test_langgraph_no_guardrails_configured_leaked_response_passes_through():
    """langgraph + no YAML guardrails + leaked ReAct response → passes through → success.

    Uses collect_input_pattern_match.yaml (agent_framework=langgraph, no top-level 'guardrails' key).
    LangGraph adapter has no defaults either, so self.guardrails = [].

    Turn 1: LLM returns plain prompt → "What is your name?" shown to user.
    Turn 2: LLM returns LEAKED_RESPONSE (Thought: without Final Answer:) → no guardrail runs
            → pattern match finds NAME_CAPTURED: John → success.
    Total LLM calls: 2.
    """
    responses = iter([
        llm_text_response("What is your name?"),
        llm_text_response(LEAKED_RESPONSE),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("collect_input_pattern_match.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="some input", initial_context={})
    assert "Name collected" in str(result2)

    s = snap(tool, tid)
    assert s["name"] == "John"
    assert s["_status"] == "collect_name_end_success"
    assert respx.calls.call_count == 2




@respx.mock
def test_crewai_no_yaml_guardrails_clean_response_succeeds():
    """Full workflow: agent_framework=crewai, no YAML guardrails, clean responses → success.

    No guardrails are mentioned anywhere in the YAML.
    CrewAIAgentAdapter automatically applies ThoughtActionGuardrail as default.

    Turn 1: LLM returns CLEAN_PROMPT_RESPONSE (ReAct chain ending with Final Answer) → default guardrail passes
            → "What is your name?" extracted and shown to user.
    Turn 2: LLM returns CLEAN_RESPONSE (Final Answer with NAME_CAPTURED) → default guardrail passes → success.
    Total LLM calls: 2.
    """
    responses = iter([
        llm_text_response(CLEAN_PROMPT_RESPONSE),
        llm_text_response(CLEAN_RESPONSE),
    ])

    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))


    tool = make_tool("guardrails_crewai_no_config.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="My name is John", initial_context={})
    assert "Name collected" in str(result2)

    s = snap(tool, tid)
    assert s["name"] == "John"
    assert s["_status"] == "collect_name_end_success"
    assert s.get("_pending_prompt") is None


@respx.mock
def test_crewai_no_yaml_guardrails_leaked_response_blocked_by_default():
    """Full workflow: agent_framework=crewai, no YAML guardrails, leaked ReAct → blocked by default guardrail.

    No guardrails are mentioned anywhere in the YAML.
    CrewAIAgentAdapter automatically applies ThoughtActionGuardrail (max_retries=1) as default.

    Turn 1: LLM returns CLEAN_PROMPT_RESPONSE (ReAct chain ending with Final Answer) → default guardrail passes
            → "What is your name?" extracted and shown to user.
    Turn 2: LLM returns LEAKED_RESPONSE (Thought: without Final Answer:):
      - ThoughtActionGuardrail detects leaked ReAct → fails (attempt 0 < max_retries=1) → retry
      - Retry: LLM still returns LEAKED_RESPONSE → fails again → GuardrailViolationError
      - Error message returned to user; workflow stays in collecting state.
    Total LLM calls: 3 (1 for T1, 2 for T2 + retry).
    """
    responses = iter([
        llm_text_response(CLEAN_PROMPT_RESPONSE),
        llm_text_response(LEAKED_RESPONSE),
        llm_text_response(LEAKED_RESPONSE),  # retry response, same leak
    ])


    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))


    tool = make_tool("guardrails_crewai_no_config.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="some input", initial_context={})
    # Default CrewAI guardrail error message surfaces to the user
    assert FACTORY_DEFAULT_ERROR in str(result2)

    s = snap(tool, tid)
    assert s.get("name") is None        # field not captured
    assert "collecting" in s["_status"]  # still collecting, not at an outcome


@respx.mock
def test_crewai_no_yaml_guardrails_leaked_then_retry_clean_succeeds():
    """crewai + no YAML guardrails + leaked T2, clean retry → retry passes → success.

    Uses guardrails_crewai_no_config.yaml (agent_framework=crewai, no top-level 'guardrails' key).
    CrewAIAgentAdapter automatically applies ThoughtActionGuardrail (max_retries=1) as default.

    Turn 1: LLM returns CLEAN_PROMPT_RESPONSE → default guardrail passes → "What is your name?" shown.
    Turn 2: LLM returns LEAKED_RESPONSE (Thought: without Final Answer:):
      - ThoughtActionGuardrail fails (attempt 0 < max_retries=1) → retry
      - Retry: LLM returns CLEAN_RESPONSE (Final Answer with NAME_CAPTURED) → guardrail passes → success.
    Total LLM calls: 3 (1 for T1, 2 for T2: initial + retry).
    """
    responses = iter([
        llm_text_response(CLEAN_PROMPT_RESPONSE),
        llm_text_response(LEAKED_RESPONSE),
        llm_text_response(CLEAN_RESPONSE),  # retry succeeds
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("guardrails_crewai_no_config.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="My name is John", initial_context={})
    assert "Name collected" in str(result2)

    s = snap(tool, tid)
    assert s["name"] == "John"
    assert s["_status"] == "collect_name_end_success"
    assert respx.calls.call_count == 3


@respx.mock
def test_crewai_explicit_enabled_with_retries_leaked_then_retry_clean_succeeds():
    """crewai + explicit thought_action_check (enabled, max_retries=1) + leaked T2, clean retry → success.

    Uses guardrails_crewai_ta_enabled_retries.yaml (crewai + explicit guardrail with max_retries=1).

    Turn 1: LLM returns CLEAN_PROMPT_RESPONSE → guardrail passes → "What is your name?" shown.
    Turn 2: LLM returns LEAKED_RESPONSE (Thought: without Final Answer:):
      - ThoughtActionGuardrail fails (attempt 0 < max_retries=1) → retry
      - Retry: LLM returns CLEAN_RESPONSE (Final Answer with NAME_CAPTURED) → guardrail passes → success.
    Total LLM calls: 3 (1 for T1, 2 for T2: initial + retry).
    """
    responses = iter([
        llm_text_response(CLEAN_PROMPT_RESPONSE),
        llm_text_response(LEAKED_RESPONSE),
        llm_text_response(CLEAN_RESPONSE),  # retry succeeds
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("guardrails_crewai_ta_enabled_retries.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="My name is John", initial_context={})
    assert "Name collected" in str(result2)

    s = snap(tool, tid)
    assert s["name"] == "John"
    assert s["_status"] == "collect_name_end_success"
    assert respx.calls.call_count == 3


@respx.mock
def test_crewai_explicit_enabled_with_retries_leaked_then_retry_leaked_errors():
    """crewai + explicit thought_action_check (enabled, max_retries=1) + all leaked → error.

    Uses guardrails_crewai_ta_enabled_retries.yaml (crewai + explicit guardrail with max_retries=1).

    The adapter (_run_guardrails) is the single place for guardrail retries.
    CollectInput._get_agent_response makes one agent.invoke() call; the adapter handles
    all retries internally before raising GuardrailViolationError.

    Turn 1: LLM returns CLEAN_PROMPT_RESPONSE → guardrail passes → "What is your name?" shown.
    Turn 2: LLM returns LEAKED_RESPONSE twice:
      - Adapter initial attempt (leaked) → fails (attempt 0 < max_retries=1) → adapter retry
      - Adapter retry (leaked) → fails → GuardrailViolationError raised
      - CollectInput catches GVE → GuardrailFailureResponse → error message returned to user.
    Total LLM calls: 3 (1 for T1, 2 for T2: adapter initial + adapter retry).
    """
    responses = iter([
        llm_text_response(CLEAN_PROMPT_RESPONSE),   # T1
        llm_text_response(LEAKED_RESPONSE),          # T2 adapter initial
        llm_text_response(LEAKED_RESPONSE),          # T2 adapter retry → GVE → GuardrailFailureResponse
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("guardrails_crewai_ta_enabled_retries.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="some input", initial_context={})
    assert GUARDRAIL_ERROR in str(result2)

    s = snap(tool, tid)
    assert s.get("name") is None        # field not captured
    assert "collecting" in s["_status"]  # still collecting, not at an outcome
    assert respx.calls.call_count == 3


@respx.mock
def test_crewai_explicit_disabled_guardrail_overrides_default_leaked_passes_through():
    """crewai + explicit thought_action_check (enabled: false) overrides default → leaked passes through → success.

    Uses guardrails_crewai_ta_disabled.yaml (crewai + explicitly disabled thought_action_check).
    _resolve_guardrails replaces the crewai default ThoughtActionGuardrail with the disabled version.
    runner.py filters out disabled guardrails → no guardrail runs → response passes through.

    Turn 1: LLM returns plain prompt → "What is your name?" shown to user.
    Turn 2: LLM returns LEAKED_RESPONSE (Thought: without Final Answer:) → disabled guardrail skipped
            → pattern match finds NAME_CAPTURED: John → success.
    Total LLM calls: 2.
    """
    responses = iter([
        llm_text_response("What is your name?"),
        llm_text_response(LEAKED_RESPONSE),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("guardrails_crewai_ta_disabled.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="some input", initial_context={})
    assert "Name collected" in str(result2)

    s = snap(tool, tid)
    assert s["name"] == "John"
    assert s["_status"] == "collect_name_end_success"
    assert respx.calls.call_count == 2, "disabled guardrail should result in exactly 2 LLM calls"


@respx.mock
def test_failure_message_used_when_guardrail_has_no_error_message():
    """YAML failure_message is used when the guardrail defines no error_message.

    Fixture: guardrails_failure_message_fallback.yaml
      - Top-level failure_message: "Something went wrong at the workflow level."
      - guardrail thought_action_check: no error_message

    Turn 1: LLM returns plain prompt → "What is your name?" shown.
    Turn 2: LLM returns LEAKED_RESPONSE → guardrail fires → failure_message surfaced.
    Total LLM calls: 2.
    """
    responses = iter([
        llm_text_response("What is your name?"),
        llm_text_response(LEAKED_RESPONSE),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("guardrails_failure_message_fallback.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="some input", initial_context={})
    assert FAILURE_MESSAGE in str(result2)
    assert PER_GUARDRAIL_ERROR not in str(result2)
    assert FACTORY_DEFAULT_ERROR not in str(result2)

    s = snap(tool, tid)
    assert s.get("name") is None
    assert "collecting" in s["_status"]
    assert respx.calls.call_count == 2


@respx.mock
def test_guardrail_error_message_wins_over_failure_message():
    """Per-guardrail error_message takes precedence over YAML failure_message.

    Fixture: guardrails_error_message_wins_over_failure_message.yaml
      - Top-level failure_message: "Something went wrong at the workflow level."
      - guardrail thought_action_check error_message: "Per-guardrail error message."

    Turn 1: LLM returns plain prompt → "What is your name?" shown.
    Turn 2: LLM returns LEAKED_RESPONSE → guardrail fires → per-guardrail error_message surfaced,
            not the workflow-level failure_message.
    Total LLM calls: 2.
    """
    responses = iter([
        llm_text_response("What is your name?"),
        llm_text_response(LEAKED_RESPONSE),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("guardrails_error_message_wins_over_failure_message.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="some input", initial_context={})
    assert PER_GUARDRAIL_ERROR in str(result2)
    assert FAILURE_MESSAGE not in str(result2)

    s = snap(tool, tid)
    assert s.get("name") is None
    assert "collecting" in s["_status"]
    assert respx.calls.call_count == 2


@respx.mock
def test_factory_default_used_when_no_error_message_and_no_failure_message():
    """GuardrailFactory default is used when neither error_message nor failure_message is set.

    Fixture: guardrails_factory_default_fallback.yaml
      - No top-level failure_message
      - guardrail thought_action_check: no error_message

    Turn 1: LLM returns plain prompt → "What is your name?" shown.
    Turn 2: LLM returns LEAKED_RESPONSE → guardrail fires → GuardrailFactory hardcoded default surfaced.
    Total LLM calls: 2.
    """
    responses = iter([
        llm_text_response("What is your name?"),
        llm_text_response(LEAKED_RESPONSE),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("guardrails_factory_default_fallback.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="some input", initial_context={})
    assert FACTORY_DEFAULT_ERROR in str(result2)
    assert FAILURE_MESSAGE not in str(result2)
    assert PER_GUARDRAIL_ERROR not in str(result2)

    s = snap(tool, tid)
    assert s.get("name") is None
    assert "collecting" in s["_status"]
    assert respx.calls.call_count == 2
