"""Tests for task I/O: save_task, load_task, repo_tasks_for_current_repo."""

import json
from pathlib import Path

import pytest

import claude_hatchery.tasks as tasks

# ---------------------------------------------------------------------------
# save_task
# ---------------------------------------------------------------------------


_REPO = Path("/my/repo")


class TestSaveTask:
    def test_creates_json_file(self, fake_tasks_db):
        meta = {"name": "my-task", "repo": str(_REPO), "status": "in-progress"}
        tasks.save_task(meta)
        path = fake_tasks_db / tasks.repo_id(_REPO) / "my-task.json"
        assert path.exists()

    def test_stamps_schema_version(self, fake_tasks_db):
        meta = {"name": "my-task", "repo": str(_REPO), "status": "in-progress"}
        tasks.save_task(meta)
        path = fake_tasks_db / tasks.repo_id(_REPO) / "my-task.json"
        saved = json.loads(path.read_text())
        assert saved["schema_version"] == tasks.SCHEMA_VERSION

    def test_creates_parent_dirs(self, tmp_path, monkeypatch):
        db = tmp_path / "deep" / "nested" / "tasks"
        monkeypatch.setattr(tasks, "TASKS_DB_DIR", db)
        meta = {"name": "task1", "repo": str(_REPO), "status": "in-progress"}
        tasks.save_task(meta)
        assert (db / tasks.repo_id(_REPO) / "task1.json").exists()

    def test_file_is_valid_json(self, fake_tasks_db):
        meta = {"name": "test", "repo": str(_REPO), "status": "in-progress", "branch": "hatchery/test"}
        tasks.save_task(meta)
        path = fake_tasks_db / tasks.repo_id(_REPO) / "test.json"
        loaded = json.loads(path.read_text())
        assert isinstance(loaded, dict)

    def test_overwrites_on_second_save(self, fake_tasks_db):
        meta = {"name": "task", "repo": str(_REPO), "status": "in-progress"}
        tasks.save_task(meta)
        meta["status"] = "complete"
        tasks.save_task(meta)
        path = fake_tasks_db / tasks.repo_id(_REPO) / "task.json"
        saved = json.loads(path.read_text())
        assert saved["status"] == "complete"

    def test_all_fields_preserved(self, fake_tasks_db):
        meta = {
            "name": "full-task",
            "branch": "hatchery/full-task",
            "worktree": "/some/path",
            "repo": "/my/repo",
            "status": "in-progress",
            "created": "2026-01-01T00:00:00",
            "session_id": "uuid-1234",
        }
        tasks.save_task(meta)
        path = fake_tasks_db / tasks.repo_id(_REPO) / "full-task.json"
        saved = json.loads(path.read_text())
        for key in meta:
            assert saved[key] == meta[key]


# ---------------------------------------------------------------------------
# load_task
# ---------------------------------------------------------------------------


class TestLoadTask:
    def test_round_trip(self, fake_tasks_db):
        meta = {
            "name": "round-trip",
            "repo": str(_REPO),
            "status": "in-progress",
            "branch": "hatchery/round-trip",
        }
        tasks.save_task(meta)
        loaded = tasks.load_task(_REPO, "round-trip")
        assert loaded["name"] == "round-trip"
        assert loaded["status"] == "in-progress"

    def test_exits_when_not_found(self, fake_tasks_db):
        with pytest.raises(SystemExit) as exc_info:
            tasks.load_task(_REPO, "nonexistent")
        assert exc_info.value.code == 1

    def test_stderr_message_on_missing(self, fake_tasks_db, capsys):
        with pytest.raises(SystemExit):
            tasks.load_task(_REPO, "missing-task")
        captured = capsys.readouterr()
        assert "missing-task" in captured.err

    def test_migrates_v0_on_load(self, fake_tasks_db):
        # Write a v0 flat record (no schema_version key, old flat-path location)
        path = fake_tasks_db / "old-task.json"
        path.write_text(json.dumps({"name": "old-task", "repo": str(_REPO), "status": "in-progress"}))
        loaded = tasks.load_task(_REPO, "old-task")
        assert loaded["schema_version"] == 1

    def test_migrates_flat_file_to_scoped_path(self, fake_tasks_db):
        # Simulate a pre-migration flat file
        flat = fake_tasks_db / "legacy.json"
        flat.write_text(
            json.dumps({"name": "legacy", "repo": str(_REPO), "status": "in-progress", "schema_version": 1})
        )
        tasks.load_task(_REPO, "legacy")
        # Flat file should be gone, scoped file should exist
        assert not flat.exists()
        assert (fake_tasks_db / tasks.repo_id(_REPO) / "legacy.json").exists()

    def test_returns_dict(self, sample_meta):
        loaded = tasks.load_task(Path("/some/repo"), "my-task")
        assert isinstance(loaded, dict)

    def test_loads_all_fields(self, sample_meta):
        loaded = tasks.load_task(Path("/some/repo"), "my-task")
        assert loaded["name"] == "my-task"
        assert loaded["branch"] == "hatchery/my-task"
        assert loaded["status"] == "in-progress"


# ---------------------------------------------------------------------------
# repo_tasks_for_current_repo
# ---------------------------------------------------------------------------


def _write_scoped(fake_tasks_db: Path, task: dict) -> None:
    """Write a task JSON to the scoped path for its repo."""
    repo = Path(task["repo"])
    scoped_dir = fake_tasks_db / tasks.repo_id(repo)
    scoped_dir.mkdir(parents=True, exist_ok=True)
    (scoped_dir / f"{task['name']}.json").write_text(json.dumps(task))


class TestRepoTasksForCurrentRepo:
    def test_returns_empty_when_dir_absent(self, tmp_path, monkeypatch):
        monkeypatch.setattr(tasks, "TASKS_DB_DIR", tmp_path / "nonexistent")
        result = tasks.repo_tasks_for_current_repo(Path("/my/repo"))
        assert result == []

    def test_filters_by_repo(self, fake_tasks_db):
        # Task for this repo (scoped)
        task1 = {
            "name": "task1",
            "repo": "/my/repo",
            "status": "in-progress",
            "created": "2026-01-01T10:00:00",
        }
        # Task for a different repo (scoped)
        task2 = {
            "name": "task2",
            "repo": "/other/repo",
            "status": "in-progress",
            "created": "2026-01-01T09:00:00",
        }
        _write_scoped(fake_tasks_db, task1)
        _write_scoped(fake_tasks_db, task2)
        result = tasks.repo_tasks_for_current_repo(Path("/my/repo"))
        assert len(result) == 1
        assert result[0]["name"] == "task1"

    def test_sorted_newest_first(self, fake_tasks_db):
        task_list = [
            {"name": "older", "repo": "/my/repo", "created": "2026-01-01T08:00:00", "status": "done"},
            {"name": "newer", "repo": "/my/repo", "created": "2026-01-02T10:00:00", "status": "done"},
            {"name": "middle", "repo": "/my/repo", "created": "2026-01-01T12:00:00", "status": "done"},
        ]
        for t in task_list:
            _write_scoped(fake_tasks_db, t)
        result = tasks.repo_tasks_for_current_repo(Path("/my/repo"))
        assert result[0]["name"] == "newer"
        assert result[1]["name"] == "middle"
        assert result[2]["name"] == "older"

    def test_skips_malformed_json_in_scoped_dir(self, fake_tasks_db):
        repo = Path("/my/repo")
        scoped_dir = fake_tasks_db / tasks.repo_id(repo)
        scoped_dir.mkdir(parents=True, exist_ok=True)
        (scoped_dir / "bad.json").write_text("not json {{{")
        task = {"name": "good", "repo": "/my/repo", "created": "2026-01-01", "status": "done"}
        _write_scoped(fake_tasks_db, task)
        result = tasks.repo_tasks_for_current_repo(repo)
        assert len(result) == 1
        assert result[0]["name"] == "good"

    def test_skips_malformed_json_in_flat_dir(self, fake_tasks_db):
        (fake_tasks_db / "bad.json").write_text("not json {{{")
        task = {"name": "good", "repo": "/my/repo", "created": "2026-01-01", "status": "done"}
        _write_scoped(fake_tasks_db, task)
        result = tasks.repo_tasks_for_current_repo(Path("/my/repo"))
        assert len(result) == 1
        assert result[0]["name"] == "good"

    def test_returns_list(self, fake_tasks_db):
        result = tasks.repo_tasks_for_current_repo(Path("/my/repo"))
        assert isinstance(result, list)

    def test_empty_when_no_matching_tasks(self, fake_tasks_db):
        task = {"name": "other", "repo": "/different/repo", "created": "2026-01-01", "status": "done"}
        _write_scoped(fake_tasks_db, task)
        result = tasks.repo_tasks_for_current_repo(Path("/my/repo"))
        assert result == []

    def test_flat_fallback_includes_matching_tasks(self, fake_tasks_db):
        # Simulate a pre-migration flat file for this repo
        task = {"name": "legacy", "repo": "/my/repo", "created": "2026-01-01", "status": "done"}
        (fake_tasks_db / "legacy.json").write_text(json.dumps(task))
        result = tasks.repo_tasks_for_current_repo(Path("/my/repo"))
        assert any(t["name"] == "legacy" for t in result)
