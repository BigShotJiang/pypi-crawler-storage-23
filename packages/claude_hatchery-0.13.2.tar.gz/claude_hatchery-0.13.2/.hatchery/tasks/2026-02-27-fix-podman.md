# Task: fix-podman

**Status**: complete
**Branch**: fix-podman
**Created**: 2026-02-27 13:26

## Objective

Fix Podman containers exiting prematurely (immediately after Claude starts) when running on macOS.

## Context

`detect_runtime()` had `if False:` guards disabling Podman entirely as a temporary workaround. The actual root cause was `--userns=keep-id` behaving differently on macOS vs Linux:

- **Linux**: Host user UID 1000 → container `claude` UID 1000. Bind-mounted files appear owned by `claude`. ✓
- **macOS**: Mac users typically have UID 501–502. `--userns=keep-id` maps 501 → 501 in the container, but `claude` is still UID 1000. The `claude` process cannot write to `~/.claude` (its session state directory), so Claude fails to initialize and exits silently.

On macOS, Podman machine uses VirtioFS for file sharing, which handles mount permissions transparently — `--userns=keep-id` is not needed and was actively breaking things.

## Summary

**Changes to `src/claude_hatchery/docker.py`:**

1. **Re-enabled Podman detection** in `detect_runtime()` — removed the `if False:` guards that were disabling Podman entirely.

2. **Made `--userns=keep-id` Linux-only** in `_run_container()`. On macOS, VirtioFS handles mount permissions without user namespace remapping. On Linux, rootless Podman still needs it for UID 1000 users. `--security-opt label=disable` is kept on all platforms (needed everywhere to suppress SELinux/AppArmor label confinement on mounts).

3. **Added exit code logging** — `subprocess.run()` result is now captured and a `logger.debug()` line records non-zero exit codes for future debugging.

**Test fix in `tests/test_subprocess.py`:** The `_capture_cmd` mock was returning `None` from the `subprocess.run` lambda; updated to return a `CompletedProcess(cmd, 0)` so the new `result.returncode` access doesn't raise `AttributeError`.

**Key gotcha**: The `test_podman_runtime_adds_userns_keep_id` test still asserts `--userns=keep-id` is present — this is correct on Linux (where CI runs). The flag is intentionally absent on macOS.
