# Task: add-scorecard-action

**Status**: complete
**Branch**: hatchery/add-scorecard-action
**Created**: 2026-02-27 09:10

## Objective

Add the `ossf/scorecard-action` to our PR checks

## Context

The repository had two existing GitHub Actions workflows:
- `ci.yml` — PR checks (validate PR title → lint → test), triggers on `pull_request` to main
- `codeql.yml` — SAST scanning, triggers on push/PR/schedule with `security-events: write`
- `release.yml` — version tagging and PyPI publishing

The goal was to add the OSSF Scorecard action, which analyzes the repository's overall supply-chain security posture (branch protection, pinned actions, dependency review, code reviews, etc.) and uploads results to GitHub's Security tab as SARIF.

## Summary

**Files changed:**
- Created `.github/workflows/scorecard.yml` — standalone Scorecard workflow
- Modified `README.md` — added OpenSSF Scorecard badge after the `# claude-hatchery` heading

**Key decisions:**
- Added as a separate workflow (not folded into `ci.yml`) because it has different triggers and permission requirements
- Triggers: `push` to main, `pull_request` to main, weekly `schedule` (Monday 06:00 UTC), and `branch_protection_rule` — the latter re-runs if branch protection settings change (standard OSSF recommendation)
- Permissions: `read-all` at workflow level (OSSF recommended default), with `security-events: write`, `id-token: write`, `contents: read`, `actions: read` overridden at the job level
- `persist-credentials: false` on checkout reduces token exposure risk
- `publish_results: true` enables the scorecard API badge and public results; for fork PRs GitHub automatically restricts `id-token` so it degrades gracefully
- Pinned to `ossf/scorecard-action@v2.4.0` and `github/codeql-action/upload-sarif@v4`

**After first run on `main`:**
- Results appear in Security → Code scanning tab
- The badge in README.md will start showing a live score once the first `publish_results` run completes
