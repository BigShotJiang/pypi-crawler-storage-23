# Task: feat-no-editor

**Status**: complete
**Branch**: hatchery/feat-no-editor
**Created**: 2026-02-23 18:25

## Objective

Add an opt-in `--no-editor` flag to the `new` command so users can skip opening `$EDITOR` for the task file. Useful in non-interactive workflows where the user describes the task to Claude directly in the session.

## Context

Some users experience extra friction from the automatic editor launch. The flag follows the established `--no-docker` / `--no-worktree` pattern. The Dockerfile editor in `docker.py` is intentionally left unchanged — only the task-file editor is affected.

## Summary

**Files changed:**

- `src/claude_hatchery/cli.py`: Added `@click.option("--no-editor", is_flag=True, ...)` after `--no-worktree`, added `no_editor: bool` to `cmd_new()` signature, wrapped the `open_for_editing()` call in a conditional that prints the task path instead when the flag is set.
- `tests/test_cli.py`: Added `test_new_help_shows_no_editor_option` to `TestHelp` and `test_no_editor_skips_open_for_editing` to `TestCliNew`.
- `README.md`: Appended `, and --no-editor to skip opening $EDITOR for the task file (useful in non-interactive workflows)` to the existing `--from` note on line 61.

**Pattern established:** flags that suppress optional side-effects follow `is_flag=True` + conditional at the call site — no metadata persistence needed (unlike `--no-worktree` which changes runtime behaviour at resume time).
