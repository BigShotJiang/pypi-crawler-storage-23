# Task: feat-custom-mounts

**Status**: complete
**Branch**: hatchery/feat-custom-mounts
**Created**: 2026-02-23 17:59

## Objective

Add user-configurable Docker bind-mounts to the hatchery sandbox. Users can specify host paths (e.g. `~/.kube/config`, `~/.aws`) that get injected into every Docker session, enabling tools like `kubectl` or the AWS CLI to work inside the container without manual workarounds.

## Context

When using Docker isolation, the Claude sandbox has no access to host credentials or config files. A per-repo `.hatchery/docker.yaml` file covers all Docker-level settings, starting with a `mounts` key. The file is pre-populated on first `hatchery new` alongside the Dockerfile, with an open-for-editing step. Mounts are specified as `host:container[:mode]` strings matching Docker's own `-v` syntax.

## Summary

### Key decisions

- **`pyyaml` + `pydantic`** added as runtime dependencies for YAML parsing and config validation with helpful error messages.
- **`.hatchery/docker.yaml`** is the config file, tracked in git alongside the Dockerfile so all developers share the same mount configuration.
- **`DockerConfig` pydantic model** with `extra="forbid"` catches unknown keys; `field_validator` on `mounts` validates each entry format and optional mode (`ro`/`rw`) before any mount is applied.
- **`migrate_docker_config()`** mirrors the existing `tasks.migrate()` pattern — a versioned migration chain that can be extended with new `if v == N` blocks as the schema evolves.
- **`ensure_docker_config(repo, *, interactive)`** — `interactive=True` (first-time setup alongside a new Dockerfile) opens the file for editing; `interactive=False` (existing Dockerfile, upgrade path) creates silently. Determined by checking `(repo / tasks.DOCKERFILE).exists()` before calling `ensure_dockerfile`.
- **`_load_docker_config(root)`** uses the _worktree_ root (not repo root) in `docker_mounts()`, consistent with how `build_docker_image` reads the worktree's Dockerfile. Non-existent host paths are silently skipped so the file can contain paths that are only present on some machines.
- **All tests pass** (186/186). The `_new_patches()` helper in `test_cli.py` was extended to mock `docker.ensure_docker_config` to prevent filesystem writes to the read-only `/repo` mount in the test container.

### Files changed

| File | Change |
|---|---|
| `pyproject.toml` | Added `pyyaml>=6` and `pydantic>=2` runtime deps |
| `src/claude_hatchery/tasks.py` | Added `DOCKER_CONFIG` and `DOCKER_CONFIG_SCHEMA_VERSION` constants |
| `src/claude_hatchery/docker.py` | Added `DockerConfig`, `migrate_docker_config`, `ensure_docker_config`, `_load_docker_config`; wired into `docker_mounts()` and `docker_mounts_no_worktree()` |
| `src/claude_hatchery/cli.py` | `cmd_new` now calls `ensure_docker_config` after `ensure_dockerfile` |
| `tests/test_cli.py` | Added `docker.ensure_docker_config` mock to `_new_patches()` |
| `README.md` | Added "Custom mounts" section and updated storage layout |

### Gotchas for future agents

- The `_new_patches()` function in `test_cli.py` has a positional unpack that must stay in sync with the patches list. If you add more `docker.*` calls to `cmd_new`, add them to `_new_patches()` AND the unpack tuple in `_setup_mocks` / `_setup_no_worktree_mocks`.
- `_load_docker_config` takes `worktree` not `repo` in `docker_mounts()` — intentional, mirrors how the Dockerfile is read.
- The `mounts` validator runs at model-validate time; invalid entries raise `ValidationError` which is caught by the `except Exception` in `_load_docker_config`, logs a warning, and returns `[]` (fail-open so a bad config doesn't prevent the session from launching).
