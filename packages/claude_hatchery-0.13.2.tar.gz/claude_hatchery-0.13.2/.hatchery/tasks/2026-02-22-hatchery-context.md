# Task: hatchery-context

**Status**: complete
**Branch**: hatchery/hatchery-context
**Created**: 2026-02-22 13:02

## Objective

Currently, tasks run in the hatchery don't know they're in a sandbox, and they don't know what isolation they have!

Come up with a plan to communicate to the hatched agent that it is isolated, what is/is not shared from the parent env (like volumne mounts, etc), and what kind of permissions it has.

## Agreed Plan

Extend the system prompt injected at launch time with a dynamic **Sandbox Environment**
section computed at task-start from live runtime information.

1. `git.py` — add `get_default_branch()` that queries `refs/remotes/origin/HEAD` then falls back to common names
2. `tasks.py` — add `sandbox_context()` that produces a markdown section describing isolation mode, filesystem permissions, branch, and PR target
3. `cli.py` — update `_launch_claude_new()` to accept `branch`/`main_branch` and compose `SESSION_SYSTEM + sandbox_context()`; update `cmd_new()` call site
4. `tests/test_pure.py` — add `TestSandboxContext` covering both Docker and native paths

## Progress Log

- [x] Step 1: Add `get_default_branch()` to `git.py`
- [x] Step 2: Add `sandbox_context()` to `tasks.py`
- [x] Step 3: Update `_launch_claude_new()` and `cmd_new()` in `cli.py`
- [x] Step 4: Add `TestSandboxContext` to `tests/test_pure.py`
- [x] Step 5: Run tests and linting (149 passed, 0 failures)

## Notes

- The native-mode text says "(no Docker isolation)" — the test checking Docker is not mentioned was refined to look for "Docker container" not "Docker" to avoid a false negative from that phrase.

## Summary

### What was done

Agents spawned by `claude-hatchery new` now receive a **Sandbox Environment** section in their injected system prompt that tells them:

- Whether they are inside a Docker container or a native git worktree
- Which filesystem paths are read-write vs. read-only (Docker mode)
- Their own branch name and the target branch for PRs

### Key decisions

- **System prompt is the right channel** — not the task file — because it is injected by the host at launch, cannot be edited by the agent, and is present from turn 1 without requiring a file read.
- **`sandbox_context()` is a pure function** in `tasks.py` (no I/O) so it is easy to unit-test without mocking.
- **`get_default_branch()`** first consults `refs/remotes/origin/HEAD` (reliable for repos with a remote), then falls back to probing common local branch names (`main`, `master`, `develop`), then hard-defaults to `"main"`.
- The native mode message intentionally mentions "(no Docker isolation)" as a clarifying contrast — tests check for "Docker container" (Docker mode claim), not just "Docker", to avoid false negatives.

### Files changed

| File | Change |
|------|--------|
| `src/claude_hatchery/git.py` | Added `get_default_branch()` |
| `src/claude_hatchery/tasks.py` | Added `sandbox_context()` |
| `src/claude_hatchery/cli.py` | Updated `_launch_claude_new()` signature; `cmd_new()` now looks up `main_branch` and passes it through |
| `tests/test_pure.py` | Added `TestSandboxContext` (16 tests covering both Docker and native paths) |

### Patterns for future agents

- To add more fields to the environment section (e.g. auth token path, memory limits), extend `sandbox_context()` in `tasks.py` and add corresponding test cases in `TestSandboxContext`.
- `get_default_branch()` is a utility reusable elsewhere if git operations ever need the default branch.
