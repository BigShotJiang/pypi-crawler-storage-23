# Task: chore-better-docs

**Status**: complete
**Branch**: hatchery/chore-better-docs
**Created**: 2026-02-23 10:34

## Objective

We need better documentation (and ongoing documentation) — specifically a strategy
for keeping README and other docs current as the project evolves.

## Context

Any MR to main cuts a release, but there was no CHANGELOG and no mechanism prompting
agents to keep docs current. CLAUDE.md also had a factual error: it said `chore`,
`docs`, etc. produce "no version bump" when the CI actually produces a patch bump.

## Summary

### What we built

**`CLAUDE.md` fixes and additions:**
- Corrected the version-bump table (`chore`/`docs`/etc → patch bump, not "no bump")
- Added `no-bump` to the regex
- Added a `## Documentation maintenance` section instructing agents to update README
  whenever anything changes that affects how users install, configure, or use the tool

**`README.md` fixes:**
- Added `no-bump` to the allowed types list
- Added `no-bump` row to the version-bump table
- Updated the "all merges produce a release" paragraph to be accurate
- Added `no-bump` example

**CI improvements (`templates.yml`, `pypi.yml`, `release.yml`, `setup.yml`):**
- `lint`/`test` now run on MR events only — no point re-running on push to main
- `publish-pypi-release` now triggers on tag push, not branch push — cleaner and
  prevents publishing if `create-release` ever fails silently
- Removed all CHANGELOG automation from `release.yml`

### What we decided NOT to build

**CHANGELOG.md** — started down this path but removed it. Since every MR to main
cuts exactly one release (one squash commit, one tag), the git tag history with
conventional commit titles already serves as the changelog. A `CHANGELOG.md` would
just be a manually-maintained duplicate. `git log --oneline v0.7.1..HEAD` is the
changelog.

### Gotchas encountered

- `.claude/skills/` is injected at runtime by hatchery and must not be committed.
  `git add -A` will silently include it. Always `git add <specific files>`. A
  separate task (`skills-gitexclude`) tracks the proper fix: write to the worktree's
  `git/info/exclude` file at skill injection time.
- The CI CHANGELOG automation had a version mismatch bug (compute-version said v0.8.2,
  create-release used v0.8.3 in the same pipeline) that was never fully explained —
  one more reason we dropped it.
- The `hatchery-done` skill must not be modified with repo-specific instructions;
  it ships with the tool and runs in every repo. Repo-specific guidance belongs
  in `CLAUDE.md` only.
