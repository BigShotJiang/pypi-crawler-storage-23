# Task: fix-curl-bash

**Status**: complete
**Branch**: hatchery/fix-curl-bash
**Created**: 2026-02-27 12:00

## Objective

Eliminate `curl | bash` supply-chain risks in the Dockerfile template and the
project's own `.hatchery/Dockerfile`, and fix a related Scorecard CI warning.

## Context

Both files contained `curl | bash` patterns for installing Claude Code, uv, Go,
Miniconda, and Rust. The OpenSSF Scorecard flagged these. Investigation showed:

- **uv**: official `COPY --from=ghcr.io/astral-sh/uv` image eliminates curl entirely.
- **Claude Code**: no published installer SHA; only supported path is the
  bootstrap script. Mitigated by downloading to a file and verifying SHA256
  before executing.
- **Go / Rust / Miniconda**: replaced with `COPY --from` patterns using official
  images (`golang:`, `rust:`). Miniconda removed entirely — it ships x86_64-only
  binaries that crash with SIGTRAP (exit 133) on ARM64; uv covers the use case.
- **Base image**: pinned by digest to prevent silent upstream changes.
- **Scorecard CI warning**: `publish_results: true` requires an OIDC token only
  available on push to the default branch. Fixed with a job-level `if` condition
  (per the GitHub-recommended template) so the action self-gates publishing while
  still running analysis and uploading SARIF on PRs.

## Summary

### Files changed

- `src/claude_hatchery/resources/Dockerfile.template` — the new canonical template
  (moved from inline string in `docker.py` in a prior main-branch commit)
- `.hatchery/Dockerfile` — live project sandbox
- `.github/workflows/scorecard.yml` — Scorecard CI workflow

### Changes

1. **Base image** — pinned by digest (`debian:trixie-slim@sha256:...`).
2. **Claude Code** — `curl | bash` replaced with download → `sha256sum -c` → run.
   `CLAUDE_INSTALL_SHA256` ARG must be updated when the bootstrap script changes
   (intentional: forces a conscious review of installer changes).
3. **uv** — `COPY --from=ghcr.io/astral-sh/uv:0.10.7 /uv /uvx /bin/`.
4. **Go** — `COPY --from=golang:1.24 /usr/local/go /usr/local/go`.
5. **Rust** — `COPY --from=rust:1.86-slim` for cargo and rustup directories.
6. **Miniconda** — removed; crashes on ARM64 and uv supersedes it.
7. **Scorecard workflow** — updated to GitHub-recommended template with job-level
   `if` condition; updated `checkout` to v4.2.2 and `scorecard-action` to v2.4.1.

### Patterns established

- Prefer `COPY --from=<official-image>` over any curl-based install in Dockerfiles.
- For bootstrappers with no published SHA (like `claude.ai/install.sh`): download
  to a temp file, verify hash, execute, delete — never pipe directly to shell.
- The `CLAUDE_INSTALL_SHA256` hash pins the bootstrap *script*, not the Claude
  Code binary. New Claude Code versions don't change the hash; bootstrap script
  updates do (which is the desired alert behaviour).
- Miniconda's filename format includes a Python version prefix:
  `Miniconda3-py312_VERSION-Linux-x86_64.sh` — the old `Miniconda3-VERSION-...`
  format no longer exists on the Anaconda CDN.
- Scorecard `publish_results: true` requires OIDC; gate it with a job-level `if`
  rather than conditionalizing the input, so the action self-manages publishing.
