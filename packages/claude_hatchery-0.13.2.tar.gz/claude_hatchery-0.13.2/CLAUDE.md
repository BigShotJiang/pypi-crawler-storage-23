# claude-hatchery

Task orchestration CLI for Claude Code — manages isolated git worktrees with optional Docker sandboxing.

## Package management
- Use `uv` for all Python dependency management
- Install deps: `uv sync`
- Run scripts: `uv run <script>`
- Add dependencies: `uv add <package>`

## Python version
- Requires Python 3.12+ (see `.python-version`)
- Use modern Python features freely: `match/case`, structural pattern matching, `|` union types

## Linting & formatting
- Use `ruff` for linting and formatting
- Format: `uv run ruff format .`
- Lint: `uv run ruff check .`
- Fix: `uv run ruff check --fix .`

## Code style
- Full type annotations on all functions (return types included)
- Use the module-level `logger` for all debug/info output — never `print()`
- Error paths: print to stderr and `sys.exit(1)`
- Keep stdlib-only; avoid adding heavy dependencies
- **Import style**: prefer `import claude_hatchery.foo as foo` over `from claude_hatchery.foo import a, b, c` — use `foo.bar()` at call sites so the origin of every symbol is obvious

## Project structure
- `src/claude_hatchery/claude_hatchery.py` — single-file CLI (main entry point)
- `.hatchery/tasks/` — permanent task records, tracked in git
- `.hatchery/worktrees/` — active worktrees, gitignored
- `~/.hatchery/` — host-level task database (JSON metadata + per-task auth copies)

## Dev dependencies
- `ruff` and `pytest` are dev dependencies in `[dependency-groups] dev` (uv-native dev group)
- Install with `uv sync` (included by default)

## Conventional commits (required)
The **MR title** must follow the Conventional Commits format — the CI validates this on every MR. Individual branch commits are not validated (MRs are squash-merged, so only the MR title lands on `main`).

Format: `<type>(<optional scope>)<!>: <description>`

Regex: `^(feat|fix|docs|chore|style|refactor|perf|test|build|ci|revert|no-bump)(\([^)]+\))?(!)?: .+`

Version bump rules (actual CI behaviour in `setup.yml`):
- `no-bump:` → **skip release entirely** (no tag, no PyPI publish)
- any type with `!` (e.g. `feat!:`) → **major** bump (x.0.0)
- `feat:` → **minor** bump (0.x.0)
- `fix:`, `perf:` → **patch** bump (0.0.x)
- everything else (`docs`, `chore`, `style`, `refactor`, `test`, `build`, `ci`, `revert`) → **patch** bump (0.0.x)

Examples:
```
feat(cli): add --dry-run flag
fix: handle missing config file gracefully
chore: update ruff to 0.15
feat!: rename `new` command to `start`
no-bump: update CI workflow variables
```

## Key constants (do not rename without updating docs)
- `TASKS_DB_DIR` — global task metadata at `~/.hatchery/tasks/`
- `WORKTREES_SUBDIR` — per-repo worktrees at `.hatchery/worktrees/`
- `SCHEMA_VERSION` — increment when task JSON schema changes

## Documentation maintenance

There is no CHANGELOG — the git tag history with conventional commit titles
serves that purpose (`git log --oneline v0.7.1..HEAD`).

Update **README.md** whenever anything changes that affects how users install,
configure, or use the tool. Skip it for internal refactors, test-only changes,
and anything else that has no effect outside the codebase.
