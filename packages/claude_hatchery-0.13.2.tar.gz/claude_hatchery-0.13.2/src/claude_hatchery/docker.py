"""Docker sandbox helpers."""

import json
import logging
import os
import shutil
import subprocess
import sys
from enum import Enum
from pathlib import Path

import yaml
from pydantic import BaseModel, ConfigDict, field_validator

import claude_hatchery.tasks as tasks

logger = logging.getLogger("claude-hatchery")


class Runtime(Enum):
    PODMAN = "PODMAN"
    DOCKER = "DOCKER"

    @property
    def binary(self) -> str:
        """CLI binary name for this runtime."""
        return self.value.lower()


_RESOURCES = Path(__file__).parent / "resources"
_DOCKERFILE_TEMPLATE = _RESOURCES / "Dockerfile.template"
_DOCKER_CONFIG_TEMPLATE = _RESOURCES / "docker.yaml.template"

# ── Config model ──────────────────────────────────────────────────────────────


class DockerConfig(BaseModel):
    """Schema for .hatchery/docker.yaml."""

    model_config = ConfigDict(extra="forbid")
    schema_version: int = tasks.DOCKER_CONFIG_SCHEMA_VERSION
    mounts: list[str] = []

    @field_validator("mounts", mode="before")
    @classmethod
    def validate_mounts(cls, v: list | None) -> list:
        if v is None:
            return []
        for i, entry in enumerate(v):
            if not isinstance(entry, str):
                raise ValueError(f"mounts[{i}]: expected a string, got {type(entry).__name__!r}")
            parts = entry.split(":", 2)
            if len(parts) < 2 or not parts[0] or not parts[1]:
                raise ValueError(
                    f'mounts[{i}]: invalid mount {entry!r} — expected "host:container" or "host:container:mode"'
                )
            if len(parts) == 3 and parts[2] not in ("ro", "rw"):
                raise ValueError(f'mounts[{i}]: invalid mode {parts[2]!r} in {entry!r} — must be "ro" or "rw"')
        return v


# ── Authentication ────────────────────────────────────────────────────────────


def _get_claude_token_from_keychain() -> str | None:
    """Extract the Claude Code token from the macOS Keychain."""
    if sys.platform != "darwin":
        return None
    logger.debug("Checking macOS Keychain for Claude Code token")
    result = tasks.run(["security", "find-generic-password", "-s", "Claude Code", "-w"], check=False, sensitive=True)
    if result.returncode == 0:
        token = result.stdout.strip()
        if token:
            logger.debug("Found Claude Code token in macOS Keychain")
            return token
    logger.debug("No Claude Code token found in macOS Keychain")
    return None


def get_claude_token() -> str | None:
    """Return the Claude API key.

    Resolution order:
    1. ANTHROPIC_API_KEY environment variable
    2. macOS Keychain (where the native Claude Code installer stores credentials)
    """
    key = os.environ.get("ANTHROPIC_API_KEY")
    if key:
        logger.debug("Using ANTHROPIC_API_KEY from environment")
        return key
    logger.debug("ANTHROPIC_API_KEY not set, falling back to keychain")
    return _get_claude_token_from_keychain()


def prepare_task_claude_json(name: str) -> Path | None:
    """Return a per-task copy of ~/.claude.json for use inside Docker.

    Seeded from the host copy on first launch; persists so that token
    refreshes performed inside the container survive across restarts.
    Returns None if no ~/.claude.json exists on the host (API-key-only users).
    """
    src = Path.home() / ".claude.json"
    if not src.exists():
        return None
    session_dir = tasks.TASKS_DB_DIR.parent / "sessions" / name
    session_dir.mkdir(parents=True, exist_ok=True)
    task_copy = session_dir / "claude.json"
    if not task_copy.exists():
        shutil.copy2(src, task_copy)
        logger.debug("Seeded per-task ~/.claude.json copy at %s", task_copy)
    else:
        logger.debug("Using existing per-task ~/.claude.json copy at %s", task_copy)
    return task_copy


# ── Utilities ─────────────────────────────────────────────────────────────────


def dockerfile_path(repo: Path) -> Path:
    """Return the canonical path to the repo's hatchery Dockerfile."""
    return repo / tasks.DOCKERFILE


def docker_image_name(repo: Path, name: str) -> str:
    """Return the Docker image tag for a given repo and task name."""
    return f"claude-hatchery-{tasks.to_name(repo.name)}:{name}"


def docker_available() -> bool:
    """Return True if the Docker daemon is reachable."""
    logger.debug("Checking Docker availability")
    result = tasks.run(["docker", "info"], check=False)
    return result.returncode == 0


def podman_available() -> bool:
    """Return True if the Podman CLI is reachable."""
    logger.debug("Checking Podman availability")
    result = tasks.run(["podman", "info"], check=False)
    return result.returncode == 0


def detect_runtime() -> Runtime:
    """Return the preferred container runtime, or exit if none is available.

    Podman is preferred because it is rootless-native and its default seccomp
    profile allows the user-namespace syscalls needed for nested containers.

    If the Podman binary is installed but 'podman info' fails (e.g. the machine
    is not running on macOS), this is treated as an error rather than a silent
    fallback to Docker — the user installed Podman intentionally and should not
    be silently downgraded to the less-secure Docker runtime.
    """
    if podman_available():
        logger.debug("Using Podman as container runtime")
        return Runtime.PODMAN
    if shutil.which("podman") is not None:
        msg = "Podman is installed but not running."
        if sys.platform == "darwin":
            msg += " Start it with: podman machine start"
            msg += "\n(or: podman machine init && podman machine start on first use)"
        print(f"Error: {msg}", file=sys.stderr)
        sys.exit(1)
    if docker_available():
        logger.debug("Using Docker as container runtime")
        return Runtime.DOCKER
    print("Error: .hatchery/dockerfile exists but neither Podman nor Docker is running.", file=sys.stderr)
    print("Start Podman/Docker or pass --no-docker to run without the sandbox.", file=sys.stderr)
    sys.exit(1)


# ── Setup ─────────────────────────────────────────────────────────────────────


def ensure_dockerfile(repo: Path) -> bool:
    """Write a starter Dockerfile if none exists. Returns True if created."""
    df = dockerfile_path(repo)
    if df.exists():
        return False
    df.write_text(_DOCKERFILE_TEMPLATE.read_text())
    print(f"  Created {tasks.DOCKERFILE}")
    answer = input("  Would you like to edit the Dockerfile? [Y/n] ").strip().lower()
    if answer != "n":
        tasks.open_for_editing(df)
    return True


def _migrate_docker_config(data: dict) -> dict:
    """Bring a docker.yaml config dict up to the current schema version.

    Add a new `if v == N` block here whenever the schema changes.
    Each block should make the minimal edit to reach version N+1,
    then increment data["schema_version"]. The final state will
    always be tasks.DOCKER_CONFIG_SCHEMA_VERSION.
    """
    v = data.get("schema_version", 0)

    # v0 -> v1: initial versioned schema (just stamps the version)
    if v == 0:
        data["schema_version"] = 1
        v = 1

    # Future example:
    # if v == 1:
    #     data["new_field"] = data.pop("old_field", None)
    #     data["schema_version"] = 2
    #     v = 2

    return data


def ensure_docker_config(repo: Path) -> bool:
    """Write .hatchery/docker.yaml from template if it does not already exist.

    Returns True if the file was created, False if it already existed.
    """
    config_file = repo / tasks.DOCKER_CONFIG
    if config_file.exists():
        return False
    config_file.write_text(_DOCKER_CONFIG_TEMPLATE.read_text())
    print(f"  Created {tasks.DOCKER_CONFIG}")
    answer = input("  Would you like to edit the docker config? [Y/n] ").strip().lower()
    if answer != "n":
        tasks.open_for_editing(config_file)
    return True


# ── Mount construction ────────────────────────────────────────────────────────


def _home_mounts(claude_json: Path | None) -> list[str]:
    """Return standard host-home bind-mounts shared by all container modes.

    Mounted in every Docker session regardless of worktree mode:
      /home/claude/.claude      ← read-write (auth tokens + session history)
      /home/claude/.claude.json ← read-write (per-task copy; host file never touched)
      /home/claude/.gitconfig   ← read-only  (commit author identity, if present)
    """
    mounts = [f"{Path.home() / '.claude'}:/home/claude/.claude:rw"]
    if claude_json is not None:
        mounts.append(f"{claude_json}:/home/claude/.claude.json:rw")
    gitconfig = Path.home() / ".gitconfig"
    if gitconfig.exists():
        mounts.append(f"{gitconfig}:/home/claude/.gitconfig:ro")
    uv_cache = Path.home() / ".cache" / "uv"
    if uv_cache.exists():
        mounts.append(f"{uv_cache}:/home/claude/.cache/uv:rw")
    return mounts


def _load_docker_config(root: Path) -> DockerConfig:
    """Read and parse root/docker.yaml into a DockerConfig.

    Returns an empty DockerConfig if the file does not exist. Exits with an
    error message if the file cannot be parsed or fails validation — an
    invalid config is always a user mistake that must be fixed before launching.
    """
    config_file = root / tasks.DOCKER_CONFIG
    if not config_file.exists():
        return DockerConfig()
    try:
        raw = yaml.safe_load(config_file.read_text()) or {}
        raw = _migrate_docker_config(raw)
        return DockerConfig.model_validate(raw)
    except Exception as exc:
        print(f"Error: invalid {tasks.DOCKER_CONFIG}: {exc}", file=sys.stderr)
        sys.exit(1)


def _construct_docker_mounts(config: DockerConfig) -> list[str]:
    """Resolve a DockerConfig into docker -v mount strings.

    Expands ~ in host paths and silently skips entries whose host path does
    not exist on this machine (allows a shared config to list paths that are
    only present on some developers' machines).
    """
    result = []
    for entry in config.mounts:
        parts = entry.split(":", 2)
        host = Path(parts[0]).expanduser()
        container = parts[1]
        mode = parts[2] if len(parts) == 3 else "ro"
        if not host.exists():
            logger.debug("Custom mount host path does not exist, skipping: %s", host)
            continue
        result.append(f"{host}:{container}:{mode}")
    return result


def docker_mounts(
    repo: Path,
    worktree: Path,
    name: str,
    claude_json: Path | None,
    git_sentinel_files: list[tuple[Path, str]] | None = None,
    worktree_git_ptr: Path | None = None,
) -> list[str]:
    """Return the -v flags for the container.
    Mount layout:
      /repo                                       ← full repo + .git, read-only
      /repo/.git                                  ← read-write (allows lock files at .git/ root)
      /repo/.git/objects                          ← read-write (new commit objects)
      /repo/.git/refs/heads/hatchery/                  ← read-write (own branch + lock sidecar files)
      /repo/.git/logs                             ← read-write (reflogs, if dir exists)
      /repo/.git/worktrees/<n>                    ← read-write (this task's index + HEAD only)
      /repo/.git/COMMIT_EDITMSG                   ← read-write (per-task sentinel file)
      /repo/.git/ORIG_HEAD                        ← read-write (per-task sentinel file)
      /repo/.hatchery/worktrees/<n>                ← read-write (the ONLY place edits land)
      /repo/.hatchery/worktrees/<n>/.git          ← container-path-aware .git pointer (file)
      /home/claude/.claude                        ← read-write (auth tokens + session history)
      /home/claude/.claude.json                   ← read-write (per-task copy; host file never touched)
      /home/claude/.gitconfig                     ← read-only  (commit author identity)
      /home/claude/.cache/uv                      ← read-write (uv package cache, if present)
      /home/claude/.ssh                           ← read-only  (SSH keys for git push, if present)

    Known security holes (accepted; fixing them would break real-time git visibility):
      LOW-MEDIUM: The entire refs/heads/hatchery/ dir is mounted rw, so the container
        can create arbitrary hatchery/<anything> branch refs, not just update its own.
        These would persist to the host repo. Mitigation: only Claude runs in the
        container, so this requires deliberately malicious behaviour from the agent.
      MEDIUM: .git/ root is mounted rw, so the container can modify files at the
        .git/ root level: config, packed-refs, FETCH_HEAD, MERGE_HEAD, description,
        info/, etc. This enables modifying refs for any branch, not just hatchery/.
        Required so that git can create packed-refs.lock during rebase/cherry-pick/merge.
      HIGH: .git/objects/ is mounted rw against the real object store. The container
        can delete or overwrite existing object files, corrupting the entire git
        history and breaking the repo for all branches. Fixing this requires a
        staging temp dir + post-exit copy-back, which means commits made inside the
        container are not visible via `git log` on the host until the session ends.
    """
    git_dir = repo / ".git"
    worktree_rel = worktree.relative_to(repo)
    container_worktree = f"{tasks.CONTAINER_REPO_ROOT}/{worktree_rel}"
    mounts = [
        f"{repo}:{tasks.CONTAINER_REPO_ROOT}:ro",  # .git ro via parent; overridden below
        f"{git_dir}:{tasks.CONTAINER_REPO_ROOT}/.git:rw",  # unlock .git/ root for lock files
        f"{git_dir / 'objects'}:{tasks.CONTAINER_REPO_ROOT}/.git/objects:rw",
    ]

    # Mount the entire task/ ref directory rw so git can create .lock sidecar
    # files alongside the branch ref during commits.  refs/heads/ itself is
    # read-only via the parent repo mount, so main/develop/etc. stay protected.
    hatchery_refs_dir = git_dir / "refs" / "heads" / "hatchery"
    if hatchery_refs_dir.exists():
        mounts.append(f"{hatchery_refs_dir}:{tasks.CONTAINER_REPO_ROOT}/.git/refs/heads/hatchery:rw")

    logs_dir = git_dir / "logs"
    if logs_dir.exists():
        mounts.append(f"{logs_dir}:{tasks.CONTAINER_REPO_ROOT}/.git/logs:rw")

    # Only this task's worktree git metadata is writable; other worktrees' metadata
    # is protected by the ro parent mount (prevents `git worktree prune` damage).
    worktree_meta = git_dir / "worktrees" / name
    if worktree_meta.exists():
        mounts.append(f"{worktree_meta}:{tasks.CONTAINER_REPO_ROOT}/.git/worktrees/{name}:rw")

    # git writes these into .git/ root during normal commits; use per-task sentinel
    # files so .git/ root stays ro.
    for host_file, git_filename in git_sentinel_files or []:
        mounts.append(f"{host_file}:{tasks.CONTAINER_REPO_ROOT}/.git/{git_filename}:rw")

    mounts.append(f"{worktree}:{container_worktree}:rw")

    # Shadow the worktree's .git pointer file with a container-path-aware copy.
    # The host file contains an absolute host path that doesn't resolve inside the
    # container; this mount replaces it with the correct container-relative path.
    # Must come after the worktree:rw mount so Linux VFS lets the file mount win.
    if worktree_git_ptr is not None:
        mounts.append(f"{worktree_git_ptr}:{container_worktree}/.git:rw")
    mounts.extend(_home_mounts(claude_json))
    mounts.extend(_construct_docker_mounts(_load_docker_config(worktree)))
    return mounts


def docker_mounts_no_worktree(cwd: Path, claude_json: Path | None) -> list[str]:
    """Return the -v flags for a no-worktree Docker container.

    Mount layout:
      /workspace   ← cwd, read-write
      /home/claude/... ← standard home mounts (see _home_mounts)
    """
    return [f"{cwd}:/workspace:rw"] + _home_mounts(claude_json) + _construct_docker_mounts(_load_docker_config(cwd))


# ── Container execution ───────────────────────────────────────────────────────


def build_docker_image(repo: Path, worktree: Path, name: str, runtime: Runtime = Runtime.DOCKER) -> None:
    """Build the sandbox image from the worktree's .hatchery/dockerfile.

    Using the worktree's copy means Dockerfile changes made as part of a task
    are isolated to that task's image and merge into main with the task.
    """
    image = docker_image_name(repo, name)
    worktree_dockerfile = worktree / tasks.DOCKERFILE
    logger.info(f"Building {runtime.binary} image '{image}'")

    if logger.isEnabledFor(logging.DEBUG):
        # Let the runtime's own output pass through so build progress is visible.
        result = subprocess.run(
            [runtime.binary, "build", "-f", str(worktree_dockerfile), "-t", image, str(repo)],
            cwd=repo,
        )
        if result.returncode != 0:
            print(f"Error: {runtime.binary} build failed.", file=sys.stderr)
            sys.exit(1)
    else:
        print(f"Building image '{image}'...", end="", flush=True)
        result = subprocess.run(
            [runtime.binary, "build", "-f", str(worktree_dockerfile), "-t", image, str(repo)],
            cwd=repo,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print()  # end the "..." line before error output
            if result.stderr:
                print(result.stderr, file=sys.stderr)
            print(f"Error: {runtime.binary} build failed.", file=sys.stderr)
            sys.exit(1)
        print(" done.")

    logger.info(f"{runtime.binary} build complete")


def _seed_trusted_folder(claude_json: Path | None, container_workdir: str) -> None:
    """Add container_workdir to trustedFolders in the per-task claude.json.

    Claude reads ~/.claude.json before any --settings override is applied, so
    pre-seeding here is the only reliable way to suppress the startup trust
    prompt without PTY injection.
    """
    if claude_json is None:
        return
    try:
        data = json.loads(claude_json.read_text())
    except (json.JSONDecodeError, OSError):
        data = {}
    trusted: list[str] = data.get("trustedFolders", [])
    if container_workdir not in trusted:
        trusted.append(container_workdir)
        data["trustedFolders"] = trusted
        claude_json.write_text(json.dumps(data))
        logger.debug("Added %s to trustedFolders in per-task claude.json", container_workdir)


def _run_container(
    image: str,
    mounts: list[str],
    workdir: str,
    hatchery_repo: str,
    name: str,
    api_key: str,
    claude_args: list[str],
    runtime: Runtime = Runtime.DOCKER,
) -> None:
    """Assemble and execute the container run command for a Claude session."""
    cmd = [runtime.binary, "run", "--rm", "-it"]
    for mount in mounts:
        cmd += ["-v", mount]
    cmd += ["-e", f"ANTHROPIC_API_KEY={api_key}"]
    cmd += ["-e", f"HATCHERY_TASK={name}"]
    cmd += ["-e", f"HATCHERY_REPO={hatchery_repo}"]
    # Podman-specific outer-container flags for proper rootless mount permissions.
    # --userns=keep-id maps the calling user to the same UID inside the container
    # so bind-mounted host files (owned by the calling user) are writable by the
    # container's claude user (also UID 1000 on most systems).
    # --security-opt label=disable suppresses SELinux/AppArmor label confinement
    # on mounts, which would otherwise block access to host-owned directories.
    match runtime:
        case Runtime.PODMAN:
            if sys.platform == "linux":
                cmd += ["--userns=keep-id"]
            cmd += ["--security-opt", "label=disable"]
    cmd += ["-w", workdir]
    cmd += [image]
    settings_override = json.dumps(
        {
            "skipDangerousModePermissionPrompt": True,
            "trustedFolders": [workdir],
        }
    )
    cmd += ["claude", "--allow-dangerously-skip-permissions", "--settings", settings_override] + claude_args

    logger.debug(f"Launching {runtime.binary} container image={image!r} name={name!r} workdir={workdir!r}")
    result = subprocess.run(cmd)
    if result.returncode != 0:
        print(f"{runtime.binary} container exited with code {result.returncode}", file=sys.stderr)
        if runtime == Runtime.PODMAN and result.returncode == 137:
            print(
                "Hint: the container was killed (OOM). Try increasing the Podman machine memory:\n"
                "  podman machine stop\n"
                "  podman machine set --memory 8192\n"
                "  podman machine start",
                file=sys.stderr,
            )


def launch_docker(
    repo: Path, worktree: Path, name: str, claude_args: list[str], runtime: Runtime = Runtime.DOCKER
) -> None:
    """Replace the current process with a Docker-sandboxed Claude session.

    Builds the image first — hits the layer cache instantly if nothing changed.
    Auth is provided via ANTHROPIC_API_KEY (env var) or a per-task copy of
    ~/.claude.json (OAuth). Both are supported; at least one must be present.
    """
    api_key = get_claude_token()
    if not api_key:
        logger.error("No Claude API token found in environment or macOS Keychain")
        print("Error: no Claude API token found.", file=sys.stderr)
        print("Set ANTHROPIC_API_KEY or log in with `claude login` on the host.", file=sys.stderr)
        sys.exit(1)

    claude_json = prepare_task_claude_json(name)

    # Pre-seed writable sentinel files for git's .git/-root writes (COMMIT_EDITMSG etc.).
    # The session dir is already created by prepare_task_claude_json above.
    session_dir = tasks.TASKS_DB_DIR.parent / "sessions" / name
    session_dir.mkdir(parents=True, exist_ok=True)
    git_sentinels: list[tuple[Path, str]] = []
    for fname in ("COMMIT_EDITMSG", "ORIG_HEAD"):
        if not (repo / ".git" / fname).exists():
            continue
        p = session_dir / fname
        if not p.exists():
            p.touch()
        git_sentinels.append((p, fname))

    # Rewrite the worktree .git pointer to use the container-relative path.
    # The host file contains an absolute host path (e.g. /Users/lgrado/...) that
    # doesn't resolve inside the container; we bind-mount a fixed copy over it.
    git_ptr = session_dir / "git_ptr"
    git_ptr.write_text(f"gitdir: {tasks.CONTAINER_REPO_ROOT}/.git/worktrees/{name}\n")

    worktree_rel = worktree.relative_to(repo)
    container_worktree = f"{tasks.CONTAINER_REPO_ROOT}/{worktree_rel}"

    _seed_trusted_folder(claude_json, container_worktree)
    build_docker_image(repo, worktree, name, runtime=runtime)
    image = docker_image_name(repo, name)
    mounts = docker_mounts(repo, worktree, name, claude_json, git_sentinels, worktree_git_ptr=git_ptr)
    logger.info(f"Launching {runtime.binary} container for task '{name}'")
    _run_container(
        image, mounts, container_worktree, tasks.CONTAINER_REPO_ROOT, name, api_key, claude_args, runtime=runtime
    )


def launch_docker_no_worktree(cwd: Path, name: str, claude_args: list[str], runtime: Runtime = Runtime.DOCKER) -> None:
    """Launch a Docker-sandboxed Claude session with cwd mounted as /workspace.

    Used when --no-worktree is active. No git metadata mounts needed.
    Builds the image from cwd/.hatchery/Dockerfile (same as standard mode).
    """
    api_key = get_claude_token()
    if not api_key:
        logger.error("No Claude API token found in environment or macOS Keychain")
        print("Error: no Claude API token found.", file=sys.stderr)
        print("Set ANTHROPIC_API_KEY or log in with `claude login` on the host.", file=sys.stderr)
        sys.exit(1)

    claude_json = prepare_task_claude_json(name)
    _seed_trusted_folder(claude_json, "/workspace")
    build_docker_image(cwd, cwd, name, runtime=runtime)
    image = docker_image_name(cwd, name)
    mounts = docker_mounts_no_worktree(cwd, claude_json)
    logger.info(f"Launching {runtime.binary} container for task '{name}' (no-worktree mode)")
    _run_container(image, mounts, "/workspace", "/workspace", name, api_key, claude_args, runtime=runtime)


def resolve_runtime(repo: Path, worktree: Path, no_docker: bool) -> Runtime | None:
    """Return the runtime to use for this session, or None to run natively.

    Returns None if --no-docker is set or no Dockerfile is present.
    Calls detect_runtime() (which exits if no runtime is available) when a
    Dockerfile is present. Combines the "should we containerise?" check with
    runtime detection so callers get the Runtime in one call.
    """
    if no_docker:
        logger.debug("--no-docker set, running natively")
        return None
    if not (worktree / tasks.DOCKERFILE).exists():
        logger.debug("No Dockerfile found, running natively")
        return None
    logger.debug("Dockerfile found, detecting container runtime")
    return detect_runtime()
