import{r}from"./render-BEL5IN7j.js";function e(i,a){return r.isValidElement(i)&&a.indexOf(i.type.muiName??i.type?._payload?.value?.muiName)!==-1}export{e as i};
//# sourceMappingURL=isMuiElement-e1vpiHuY.js.map
