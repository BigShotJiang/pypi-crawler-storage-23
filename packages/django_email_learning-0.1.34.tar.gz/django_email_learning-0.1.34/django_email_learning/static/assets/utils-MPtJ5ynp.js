const n=o=>{let t=null;if(document.cookie&&document.cookie!==""){const i=document.cookie.split(";");for(let e=0;e<i.length;e++){const c=i[e].trim();if(c.substring(0,o.length+1)===o+"="){t=decodeURIComponent(c.substring(o.length+1));break}}}return t};export{n as g};
//# sourceMappingURL=utils-MPtJ5ynp.js.map
