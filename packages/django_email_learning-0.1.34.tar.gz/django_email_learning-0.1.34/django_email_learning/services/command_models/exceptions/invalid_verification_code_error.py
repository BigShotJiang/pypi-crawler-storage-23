class InvalidVerificationCodeError(Exception):
    """Exception raised when a verification code is invalid."""

    pass
