# objects.py
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from enum import Enum

# =======================================================================
# ABSTRACT OWNER BASE CLASS (FIXED: All core fields are now mandatory)
# =======================================================================

class UserOrGroup(Enum):
    USER = "USER"
    GROUP = "GROUP"
# END class UserOrGroup(Enum):

@dataclass
class Owner:
    """Abstract base class representing an entity (User or Group) that can own an object."""
    # These fields are REQUIRED for initialization and have NO defaults.
    id: Optional[str] = field(default=None)
    name: Optional[str] = field(default=None)
    type: Optional[UserOrGroup] = field(default=UserOrGroup.GROUP)
# END class Owner

# =======================================================================
# INSTANCE CONFIGURATION OBJECTS
# =======================================================================

@dataclass
class Instance:
    """Represents a single Domo instance configuration record loaded from a control dataset."""
    
    # Core Identification
    Instance_Name: str
    Instance_URL: str
    Developer_Token: str
    
    # Secondary Identification and Attributes
    Developer_Token_User: Optional[str] = field(default=None)
    Instance_Abbreviation: Optional[str] = field(default=None)
    Client_Name: Optional[str] = field(default=None)
    Client_ID: Optional[str] = field(default=None)
    Client_Secret: Optional[str] = field(default=None)
    Environment: Optional[str] = field(default=None)
    Region: Optional[str] = field(default=None)
    Type: Optional[str] = field(default=None)
    Level: Optional[str] = field(default=None)
    Description: Optional[str] = field(default=None)
    Instance_Color: Optional[str] = field(default=None)
    Old_Instance: Optional[str] = field(default=None)

    # Sync and Status Flags
    Sync_Datasets_Owners: Optional[str] = field(default=None)
    Sync_User_Landing_Page: Optional[str] = field(default=None)
    Include_in_User_Activity: Optional[str] = field(default=None)
    Show_In_SSO_Portal: Optional[str] = field(default=None)
    Sync_Default_Roles: Optional[str] = field(default=None)
    Sync_Users: Optional[str] = field(default=None)
    Sync_Default_Groups: Optional[str] = field(default=None)
    
    # Dates and Ordering
    Load_Data_Date: Optional[str] = field(default=None)
    Build_Cards_Date: Optional[str] = field(default=None)
    Go_Live_Date: Optional[str] = field(default=None)
    Order: Optional[int] = field(default=None)
    
    # Login Configuration
    Randstad_Login: Optional[str] = field(default=None)
    Login_Type: Optional[str] = field(default=None)
    Client_Login: Optional[str] = field(default=None)
# END class Instance

# =======================================================================
# DOMO OBJECTS
# =======================================================================

@dataclass
class RoleGrant:
    """Represents a single authority (permission) granted to a role."""
    authority: str
    # title: str
    description: Optional[str] = field(default=None)
    role_ids: List[str] = field(default_factory=list)
# END class RoleGrant

@dataclass
class Role:
    """Represents a Domo Role, including its ID, name, and associated grants."""
    role_id: str
    role_name: str
    
    description: Optional[str] = field(default=None)
    is_default: Optional[bool] = field(default=None)
    # grants should be mapped by authority name for easy lookup
    grants: Dict[str, RoleGrant] = field(default_factory=dict)
# END class Role

@dataclass
class Account(Owner):
    """Represents a Domo Integration Account (Data Source Credentials)."""
    # Inherits: id, name, type (all mandatory)
    display_name: Optional[str] = field(default=None)
    entity_type: Optional[str] = field(default=None)
    data_provider_type: Optional[str] = field(default=None)
    valid: Optional[bool] = field(default=None)
    last_modified: Optional[str] = field(default=None)
    owners: List[Owner] = field(default_factory=list) # List of Owner objects
    dataset_count: Optional[int] = field(default=None)
# END class Account

@dataclass
class Group(Owner):
    """Represents a Domo Group."""
    # Inherits: id, name, type (all mandatory)
    # group_id: str
    # name: str
    group_type: str = field(default=None)

    description: Optional[str] = field(default=None)
    owners: List[Owner] = field(default_factory=list)
    user_ids: List[str] = field(default_factory=list)    
    users: List[Any] = field(default_factory=list)    
    active: bool = field(default=True)
    created: str = field(default='')
    creator_id: str = field(default='')
    default: bool = field(default=False)
    guid: str = field(default='')
    hidden: bool = field(default=False)
    member_count: int = field(default=0)
    modified: str = field(default='')
    
# END class Group

@dataclass
class Page:
    """Represents a Domo Page."""
        
    page_id: str
    page_title: str
    page_type: str
    sub_type: str
    parent_page_id: str
    parent_page_title: str
    top_page_id: str
    top_page_title: str
    owner_id: str
    owner_name: str
    owners: []
    locked: bool
    last_modified: str
    card_count: int
    data_app_id: str
    data_app_title: str

# END class Page

@dataclass
class Dataset:
    """Represents a Domo DataSet."""
    id: str
    name: str
    
    description: Optional[str] = field(default=None)

    data_provider_name: Optional[str] = field(default=None)
    row_count: Optional[int] = field(default=None)
    column_count: Optional[int] = field(default=None)
    owners: List[Owner] = field(default_factory=list) # List of Owner objects
# END class Dataset

@dataclass
class DataDictionary:
    """Represents a Domo DataDictionary."""
    id: str
#     name: str
    
#     description: Optional[str] = field(default=None)

#     data_provider_name: Optional[str] = field(default=None)
#     row_count: Optional[int] = field(default=None)
#     column_count: Optional[int] = field(default=None)
#     owners: List[Owner] = field(default_factory=list) # List of Owner objects
# END class DataDictionary

@dataclass
class User(Owner):
    """Represents a Domo User."""
    # Inherits: id, name, type (all mandatory)
    
    # New mandatory field comes after all inherited mandatory fields.
    email_address: str = field(default=None)
    display_name: str = field(default=None)
    
    # Now fields with defaults
    user_name: Optional[str] = field(default=None)
    role_id: Optional[str] = field(default=None)
    role_name: Optional[str] = field(default=None)
    last_activity: Optional[str] = field(default=None)
    reports_to_email_address: Optional[str] = field(default=None)
    
    groups: Optional[List[str]] = field(default_factory=list) # List of group IDs
    attributes: Optional[Dict[str, List[str]]] = field(default_factory=dict) # Key -> List of values 

    def build_user_update_body(self) -> dict:
        """
        Constructs the request body for updating a user's custom attributes.
        """
        # Create the list of attribute objects
        # This handles cases where user.attributes might be None or empty
        attribute_list = [
            {"key": key, "values": values}
            for key, values in (self.attributes or {}).items()
        ]

        return {
            "attributes": attribute_list
        }    
    # END def build_user_update_body(user: User) -> dict:
    
# END class User

@dataclass
class SandboxRepository:
    """Represents a Domo SandboxRepository."""
    
    # New mandatory field comes after all inherited mandatory fields.
    id: str
    name: str
    domain:str
    repo_type:str
    
    # Now fields with defaults
    repository_content: Optional['SandboxRepositoryContent'] = field(default=None)
    user_id: Optional[str] = field(default=None)
    access_count: Optional[str] = field(default=None)
    permission: Optional[str] = field(default=None)
    created: Optional[str] = field(default=None)
    updated: Optional[str] = field(default=None)
    seeded: Optional[str] = field(default=None)
    last_commit: Optional[Any] = field(default=None)
    
    deployments: Optional[List['SandboxDeployment']] = field(default_factory=list)
    commits: Optional[List['SandboxCommit']] = field(default_factory=list)
    dependencies: Optional[List['SandboxDependency']] = field(default_factory=list)
    promotion_request: Optional[Any] = field(default=None)

    def __post_init__(self):
        """
        Runs after the automatic __init__ to handle custom transformations.
        """
        # 1. Transform raw repository_content dict into a SandboxRepositoryContent object
        if isinstance(self.repository_content, dict):
            content_map = {
                "page": "pageIds", "view": "viewIds", "dataflow": "dataflowIds",
                "stream": "streamIds", "card": "cardIds", "dataapp": "dataAppIds"
            }
            key = content_map.get(self.repo_type)
            content_id_array = self.repository_content.get(key, []) if key else []
            
            self.repository_content = SandboxRepositoryContent(
                repo_id=self.id,
                repo_type=self.repo_type,
                content_id_array=content_id_array
            )
        # END if isinstance(self.repository_content, dict):

        # 2. Transform raw deployments (if passed as a list of dicts)
        if self.deployments and len(self.deployments) > 0 and isinstance(self.deployments[0], dict):
            raw_data = self.deployments
            self.deployments = [] # Clear the dicts to refill with objects
            for d in raw_data:
                self.deployments.append(SandboxDeployment(
                    id=d.get('id', ''),
                    repo_id=d.get('repositoryId', ''),
                    domain=d.get('domain', ''),
                    name=d.get('name', ''),
                    is_source=d.get('isSource', ''),
                    user_id=d.get('userId', ''),
                    created=d.get('created', ''),
                    updated=d.get('updated', ''),
                    last_promotion=d.get('lastPromotion', {}),
                    permission=d.get('permission', '')
                ))
            # END for d in raw_data:
        # END if self.deployments and len(self.deployments) > 0 and isinstance(self.deployments[0], dict):

        # 3. Transform raw commits (if passed as a list of dicts)
        if self.commits and len(self.commits) > 0 and isinstance(self.commits[0], dict):
            raw_data = self.commits
            self.commits = []
            for c in raw_data:
                self.commits.append(SandboxCommit(
                    repo_id=self.id,
                    commit_id=c.get('id', ''),
                    name=c.get('name', ''),
                    hidden=c.get('hidden', ''),
                    summary=c.get('summary', ''),
                    path=c.get('path', ''),
                    status=c.get('status', '')
                ))    
            # END for c in raw_data:
        # END if self.commits and len(self.commits) > 0 and isinstance(self.commits[0], dict):
    # END def __post_init__(self):    

    def get_latest_deployment (self) -> Any:

        latest_deploy = None
        
        if len(self.deployments) > 0:
            # Initialize trackers with values that will be superseded by the first valid commit
            latest_id = ""
            latest_created = ""

            for d in self.deployments:
                if d.created >= latest_created:
                    latest_deploy = d
                    latest_created = d.created
                # END if d.created >= latest_created:
            # END for d in self.deployments:
        # END if len(self.deployments) > 0:

        return latest_deploy

    # END def get_latest_deployment    
    
    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, SandboxRepository):
            return NotImplemented
        return self.id == other.id
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.id)
    # END def __hash__(self):
        
# END class SandboxRepository

class RepoShareType(Enum):
    OWNER = "OWNER"
    EDIT = "EDIT"
    PROMOTE = "PROMOTE"
    COMMIT = "COMMIT"
    NONE = "NONE"
# END class RepoShareType(Enum):

@dataclass
class RepoPermission():
    repo_id:str
    id:str
    share_type:RepoShareType
    user_or_group:UserOrGroup
    
    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, RepoPermission):
            return NotImplemented
        return self.id == other.id and self.share_type == other.share_type and self.user_or_group == other.user_or_group
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.id)
    # END def __hash__(self):
    
# END class RepoPermission():

@dataclass
class SandboxRepositoryContent:
    """Represents a Domo SandboxRepositoryContent."""
    
    repo_id: str
            
    # New mandatory field comes after all inherited mandatory fields.
    repo_type: str
    content_id_array: List[any] = field(default_factory=list) # List of content IDs
    
    def __init__(self, repo_id, repo_type, content_id_array):

        self.repo_id = repo_id
        self.repo_type = repo_type
        self.content_id_array = content_id_array
        
    # END def __init__():

    def add_content_id(self, content_id):

        content_id_array.append(content_id)
        
    # END def add_content_id():   
    
    def to_json(self):
        
        json = {}
        if self.repo_type == "page":
            json["pageIds"] = self.content_id_array
        # END if self.repo_type == "pageIds":
        elif self.repo_type == "view":
            json["viewIds"] = self.content_id_array
        # END elif self.repo_type == "viewIds":
        elif self.repo_type == "dataflow":
            json["dataflowIds"] = self.content_id_array
        # END elif self.repo_type == "dataflowIds":
        elif self.repo_type == "stream":
            json["streamIds"] = self.content_id_array
        # END elif self.repo_type == "streamIds":
        elif self.repo_type == "card":
            json["cardIds"] = self.content_id_array
        # END elif self.repo_type == "cardIds":
        elif self.repo_type == "dataApp":
            json["dataAppIds"] = self.content_id_array
        # END elif self.repo_type == "dataAppIds":
            
        return json
        
    # END def add_content_id():   
    
    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, SandboxRepositoryContent):
            return NotImplemented
        return self.repo_id == other.repo_id
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.repo_id)
    # END def __hash__(self):
        
# END class SandboxRepositoryContent

@dataclass
class SandboxDeployment:
    """Represents a Domo SandboxDeployment."""
    
    # New mandatory field comes after all inherited mandatory fields.
    id: str
    repo_id: str
    name: str
    domain:str
    
    # Now fields with defaults
    user_id: Optional[str] = field(default=None)
    is_source: bool = field(default=None)
    permission: Optional[str] = field(default=None)
    created: Optional[str] = field(default=None)
    updated: Optional[str] = field(default=None)
    last_promotion: Optional['SandboxPromotion'] = field(default=None)
    
    def __init__(self, id, repo_id, name, domain, user_id, is_source, created, updated, last_promotion, permission):
        
        self.id = id
        self.repo_id = repo_id
        self.name = name
        self.domain = domain
        
        # Now fields with defaults
        self.user_id = user_id
        self.is_source = is_source
        self.created = created
        self.updated = updated
        self.permission = permission
        
        self.last_promotion = SandboxPromotion (
                        deployment=self,
                        id=last_promotion.get('id', ''),
                        deployment_id=last_promotion.get('deploymentId', ''),
                        commit_id=last_promotion.get('commitId', ''),
                        repository_id=last_promotion.get('repositoryId', ''),
                        user_id=last_promotion.get('userId', ''),
                        commit_name=last_promotion.get('commitName', ''),
                        repository_name=last_promotion.get('repositoryName', ''),
                        started=last_promotion.get('started', ''),
                        completed=last_promotion.get('completed', ''),
                        status=last_promotion.get('status', ''),
                        pusher_event_id=last_promotion.get('pusherEventId', ''),
                        approval_id=last_promotion.get('approvalId', ''),
            
                        promotion_request=last_promotion.get('promotionRequest', {}),
                        promotion_result=last_promotion.get('promotionResult', {})
                    ) 
            
        
    # END def __init__(self, id, repo_id, name, domain, user_id, is_source, repositoryContent, created, updated, seeded, last_promotion, permission):
    
    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, SandboxDeployment):
            return NotImplemented
        return self.id == other.id
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.id)
    # END def __hash__(self):
        
# END class SandboxDeployment

@dataclass
class SandboxDependency:
    """Represents a Domo SandboxDependency."""
    
    # {
    #     "name": "DGov|LIVE",
    #     "constraints": [
    #         {
    #             "depth": 0,
    #             "type": "PAGE_DEPTH"
    #         }
    #     ],
    #     "contentMapRequest": {
    #         "mappingId": "0dcb0f48-50da-48fe-98f1-53567ad67f36",
    #         "deployObjectId": "",
    #         "repositoryObjectId": "1897238111",
    #         "contentType": "PAGE",
    #         "link": false
    #     }
    # }
     
    # New mandatory field comes after all inherited mandatory fields.
    repo_id: str
    name: str
    content_type: str
    constraints: Any
    content_map_request: Any
    
    def __init__(self, repo_id: str, name: str, constraints: Any, content_map_request: Any):
        
        self.repo_id = repo_id
        
        self.name = name
        self.content_type = content_map_request["contentType"]
        
        self.constraints = constraints
        
        self.content_map_request = SandboxDependencyContentMapRequest (
            dependency=self,
            mapping_id=content_map_request.get('mappingId', ''),
            deploy_object_id=content_map_request.get('deployObjectId', ''),
            repository_object_id=content_map_request.get('repositoryObjectId', ''),
            content_type=content_map_request.get('contentType', ''),
            link=content_map_request.get('link', False)
        )
                    
    # END def __init__():
    
    def toJson(self):
        json = {
            "name": self.name,
            "contentType": content_type,
            "constraints": constraints,
            "contentMapRequest": content_map_request.toJson()
        }
        return json
    # END def toJson(self):
    
    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, SandboxDependency):
            return NotImplemented
        return self.name == other.name and self.type == other.type
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.name)
    # END def __hash__(self):
        
# END class SandboxDeployment

@dataclass
class SandboxDependencyContentMapRequest:
    """Represents a Domo SandboxDependencyContentMapRequest."""
    
    SandboxDependency: "SandboxDependency"

    # {
    #     "name": "DGov|LIVE",
    #     "constraints": [
    #         {
    #             "depth": 0,
    #             "type": "PAGE_DEPTH"
    #         }
    #     ],
    #     "contentMapRequest": {
    #         "mappingId": "0dcb0f48-50da-48fe-98f1-53567ad67f36",
    #         "deployObjectId": "",
    #         "repositoryObjectId": "1897238111",
    #         "contentType": "PAGE",
    #         "link": false
    #     }
    # }
     
    # New mandatory field comes after all inherited mandatory fields.
    mapping_id: str
    deploy_object_id: str
    repository_object_id: str
    content_type: str
    link: bool
    
    def __init__(self, dependency: SandboxDependency, mapping_id, deploy_object_id, repository_object_id, content_type, link):
        
        self.SandboxDependency = dependency
        
        self.mapping_id = mapping_id
        self.deploy_object_id = deploy_object_id
        
        self.repository_object_id = repository_object_id
        self.content_type = content_type
        self.link = link
                    
    # END def __init__():
    
    def toJson(self):
        json = {
            "mappingId": self.mapping_id,
            "deployObjectId": self.deploy_object_id,
            "repositoryObjectId": self.repository_object_id,
            "contentType": self.content_type,
            "link": self.link
        }
        return json
    # END def toJson(self):
    

    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, SandboxDependencyContentMapRequest):
            return NotImplemented
        return self.mapping_id == other.mapping_id
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.mapping_id)
    # END def __hash__(self):
        
# END class SandboxDependencyContentMapRequest

@dataclass
class SandboxPromotionLog:
    """Represents a Domo SandboxPromotionLog."""
    
    SandboxPromotion: 'SandboxPromotion'

    # New mandatory field comes after all inherited mandatory fields.
    log_id: str
    
    event_type: str
    event_id: str
    content_id: str
    content_name: str
    action: str
    content_type: str
    started: str
    completed: str
    level: str
    
    def __init__(self, promotion:'SandboxPromotion', log_id, event_type, event_id, content_id, content_name, action, content_type, started, completed, level):

        self.SandboxPromotion = promotion
        self.log_id = log_id
        self.event_type = event_type
        self.event_id = event_id
        self.content_id = content_id
        self.content_name = content_name
        self.action = action
        self.content_type = content_type
        self.started = started
        self.completed = completed
        self.level = level
        
    # END def __init__():
    
    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, SandboxPromotionLog):
            return NotImplemented
        return self.log_id == other.log_id
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.log_id)
    # END def __hash__(self):
        
# END class SandboxPromotionRequest

@dataclass
class SandboxPromotion:
    """Represents a Domo SandboxPromotion."""
    
    SandboxDeployment: "SandboxDeployment"
    
    # New mandatory field comes after all inherited mandatory fields.
    id: str
    deployment_id: str
    commit_id: str
    repository_id: str
    user_id: str
    commit_name: str
    repository_name: str
    
    # Now fields with defaults
    started: Optional[str] = field(default=None)
    completed: Optional[str] = field(default=None)
    status: Optional[str] = field(default=None)
    pusher_event_id: Optional[str] = field(default=None)
    approval_id: Optional[str] = field(default=None)

    promotion_request: Optional[Any] = field(default=None)
    promotion_result: Optional[Any] = field(default=None)
    
    logs: Optional[List[SandboxPromotionLog]] = field(default=None)

    def __init__(self, deployment: SandboxDeployment, id, deployment_id, commit_id, repository_id, user_id, commit_name, repository_name, started, completed, status, pusher_event_id, approval_id, promotion_request, promotion_result):
        
        self.SandboxDeployment = deployment
        self.id = id
        self.deployment_id = deployment_id
        self.commit_id = commit_id
        self.repository_id = repository_id
        self.user_id = user_id
        self.commit_name = commit_name
        self.repository_name = repository_name
        
        # Now fields with defaults
        self.started = started
        self.completed = completed
        self.status = status
        self.pusher_event_id = pusher_event_id
        self.approval_id = approval_id
        self.promotion_result = promotion_result

        self.promotion_request = SandboxPromotionRequest (
                        promotion=self,
                        commit_id=promotion_request.get('commitId', ''),
                        pusher_event_id=promotion_request.get('pusherEventId', ''),
                        approval_id=promotion_request.get('approvalId', ''),
            
                        mapping=promotion_request.get('mapping', '')
                    )
        
    # END def __init__(self, id, deployment_id, commit_id, repository_id, commit_name, repository_name, started, completed, status, pusher_event_id, approval_id, promotion_request, promotion_result):
    
    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, SandboxLastPromotion):
            return NotImplemented
        return self.id == other.id
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.id)
    # END def __hash__(self):
        
# END class SandboxLastPromotion

@dataclass
class SandboxPromotionRequest:
    """Represents a Domo SandboxPromotionRequest."""
    
    SandboxPromotion: "SandboxPromotion"

    # New mandatory field comes after all inherited mandatory fields.
    commit_id: str
    mapping: Optional[Any] = field(default=None)
    pusher_event_id: Optional[str] = field(default=None)
    approval_id: Optional[str] = field(default=None)
    
    def __init__(self, promotion:SandboxPromotion, commit_id, mapping, pusher_event_id, approval_id):

        self.SandboxPromotion = promotion
        self.commit_id = commit_id
        self.mapping = mapping
        self.pusher_event_id = pusher_event_id
        self.approval_id = approval_id
        
    # END def __init__(self, commit_id, mapping, pusher_event_id, approval_id):
    
    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, SandboxPromotionRequest):
            return NotImplemented
        return self.commit_id == other.commit_id
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.commit_id)
    # END def __hash__(self):
        
# END class SandboxPromotionRequest

@dataclass
class SandboxCommit:
    """Represents a Domo SandboxCommit."""
    
    repo_id: str
            
    # New mandatory field comes after all inherited mandatory fields.
    commit_id: str
    name: str
    hidden: bool
    summary: str
    path: str
    status: str

    # Move optional fields (those with defaults) to the bottom
    created: Optional[str] = "N/A" 
    SandboxRepository: Optional[Any] = None
    
    def __init__(self, repo_id, commit_id, name, hidden, summary, path, status, created: Optional[str] = "N/A", repo: Optional[Any] = None):

        self.repo_id = repo_id
        self.commit_id = commit_id
        self.name = name
        self.hidden = hidden
        self.summary = summary
        self.path = path
        self.status = status

        self.created = created
        self.SandboxRepository = repo
        
    # END def __init__(self, commit_id, mapping, pusher_event_id, approval_id):
    
    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, SandboxCommit):
            return NotImplemented
        return self.commit_id == other.commit_id
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.commit_id)
    # END def __hash__(self):
        
# END class SandboxCommit

class RenameRuleType(Enum):
    ADD = "ADD"
    REMOVE = "REMOVE"
    REPLACE = "REPLACE"
# END class RenameRuleType(Enum):

class RenameRuleStyle(Enum):
    ENDS_WITH = "ENDS_WITH"
    STARTS_WITH = "STARTS_WITH"
    FIRST_OCCURRENCE = "FIRST_OCCURRENCE"
    LAST_OCCURRENCE = "LAST_OCCURRENCE"
    ALL_OCCURRENCES = "ALL_OCCURRENCES"
# END class RenameRuleType(Enum):

class RenameRuleField(Enum):
    NAME = "NAME"
    DESCRIPTION = "DESCRIPTION"
# END class RenameRuleField(Enum):

class RenameRuleContentType(Enum):
    PAGE = "PAGE"
    CARD = "CARD"
    BEASTMODE = "BEASTMODE"
    DATAFLOW = "DATAFLOW"
    DATASET = "DATASET"
# END class RenameRuleContentType(Enum):

@dataclass
class SandboxRenameRule:
    """Represents a Domo SandboxRenameRule."""
    
    repo_id: str
    deployment_id: str
    execution_order: int
    
    rename_substring: str
    rename_type: RenameRuleType
    rename_style: RenameRuleStyle
    rename_field: RenameRuleField
    # template_filter: Any

    rename_content_on_promote: Optional[bool] = True
    replace_with_substring: Optional[str] = None

    page: Optional[bool] = False
    card: Optional[bool] = False
    beastmode: Optional[bool] = False
    dataflow: Optional[bool] = False
    dataset: Optional[bool] = False
    # view: Optional[bool] = False: # VIEW is not a thing the Views repo uses DATASET

    rename_all: Optional[bool] = False

    def toJson(self):
        
        json = {
            "renameSubstring": self.rename_substring,
            "renameContentOnPromote": self.rename_content_on_promote,
            "renameType": self.rename_type.value,
            "renameStyle": self.rename_style.value,
            "renameField": self.rename_field.value,
            
            "deploymentId": self.deployment_id,
            "executionOrder": self.execution_order
        }
        
        if self.replace_with_substring is not None:
            json["replaceWithSubstring"]: self.replace_with_substring
        # END if replace_with_substring is not None
        
        content_type_white_list = []
        
        if self.page:
            json[RenameRuleContentType.PAGE.value] = True
            content_type_white_list.append(RenameRuleContentType.PAGE.value)
        # END if page
        
        if self.card:
            json[RenameRuleContentType.CARD.value] = True
            content_type_white_list.append(RenameRuleContentType.CARD.value)
        # END if page
        
        if self.beastmode:
            json[RenameRuleContentType.BEASTMODE.value] = True
            content_type_white_list.append(RenameRuleContentType.BEASTMODE.value)
        # END if page
        
        if self.dataflow:
            json[RenameRuleContentType.DATAFLOW.value] = True
            content_type_white_list.append(RenameRuleContentType.DATAFLOW.value)
        # END if page
        
        if self.dataset:
            json[RenameRuleContentType.DATASET.value] = True
            content_type_white_list.append(RenameRuleContentType.DATASET.value)
        # END if page
        
        template_filter_json = {
            "renameAll": self.rename_all,
            "contentTypeWhitelist": content_type_white_list,
        }

        json["templateFilter"] = template_filter_json

        return json
    # END def toJson(self):
    
    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, SandboxRenameRule):
            return NotImplemented
        
        return (
            self.repo_id == other.repo_id and 
            self.rename_substring == other.rename_substring and 
            self.deployment_id == other.deployment_id and 
            self.execution_order == other.execution_order and 
            self.rename_type == other.rename_type and 
            self.rename_style == other.rename_style and 
            self.rename_field == other.rename_field and 
            self.replace_with_substring == other.replace_with_substring and
            self.page == other.page and
            self.card == other.card and
            self.beastmode == other.beastmode and
            self.dataflow == other.dataflow and
            self.dataset == other.dataset
        )
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.repo_id)
    # END def __hash__(self):
        
# END class SandboxRenameRule

@dataclass
class Asset:
    """Represents a Domo App Asset."""
    
    # New mandatory field comes after all inherited mandatory fields.
    asset_id: str
    name: str
    owner: str
    
    created_by: str
    created_date: str
    updated_by: str
    updated_date: str

    latest_version: str
    owners: List[any]
    creator: any
    
    trusted: bool
    has_thumbnail: bool

    versions: List[any]
    
    # Now fields with defaults
    description: Optional[str] = field(default=None)
    deleted_date: Optional[str] = field(default=None)
    instances: List[any] = field(default_factory=list) # List of group IDs
    referencing_cards: List[any] = field(default_factory=list) # List of group IDs
       
    def __init__(self, asset_id, name, owner, created_by, created_date, updated_by, updated_date, description, versions, latest_version, instances, referencing_cards, owners, creator, deleted_date, trusted, has_thumbnail):
        
        self.asset_id = asset_id
        self.name = name
        self.owner = owner
        
        self.created_by = created_by
        self.created_date = created_date
        self.updated_by = updated_by
        self.updated_date = updated_date
        
        self.description = description

        self.latest_version = latest_version

        self.instances = instances
        self.referencing_cards = referencing_cards
        self.owners = owners
        self.creator = creator
        self.deleted_date = deleted_date
        self.trusted = trusted
        self.has_thumbnail = has_thumbnail
        
        if versions is not None and len(versions) > 0:
            self.versions = []
            for av in versions:
                av_obj = AssetVersion (
                        asset=self,
                        asset_version_id=av.get('id', ''),
                        design_id=av.get('designId', ''),
                        version=av.get('version', ''),
                        draft=av.get('draft', False),
                        trusted=av.get('trusted', False),
                        public_assets_enabled=av.get('publicAssetsEnabled', True),
                    
                        scopes=av.get('scopes', []),
                    
                        datasets_mapping=av.get('datasetsMapping', []),
                        collections_mapping=av.get('collectionsMapping', []),
                        accounts_mapping=av.get('databasesMapping', []),
                        actions_mapping=av.get('accountsMapping', []),
                        workflows_mapping=av.get('actionsMapping', []),
                        packages_mapping=av.get('packagesMapping', []),
                    
                        size_width=av.get('size', {'width':5.0,'height':5.0}).get('width', 5.0),
                        size_height=av.get('size', {'width':5.0,'height':5.0}).get('height', 5.0),
                    
                        full_page=av.get('fullpage', False),
                        ai_context_id=av.get('aiContextId', ''),
                        flags=av.get('flags', None),
                    
                        created_by=av.get('createdBy', ''),
                        created_date=av.get('createdDate', ''),
                        updated_by=av.get('updatedBy', ''),
                        updated_date=av.get('updatedDate', ''),
                        release_date=av.get('releasedDate', ''),
                        deleted_date=av.get('deletedDate', None),
                    )     
                
                self.versions.append(av_obj)
                
            # END for av in versions:
        # END if versions is not None and len(versions) > 0:
        
    # END def __init__():
    
    # 1. Equality check based on the unique ID
    def __eq__(self, other):
        if not isinstance(other, Asset):
            return NotImplemented
        return self.asset_id == other.asset_id
    # END def __eq__(self, other):
    
    # 2. Hash value based on the unique ID
    def __hash__(self):
        # We hash the unique, immutable ID (or a tuple of immutable unique fields)
        return hash(self.asset_id)
    # END def __hash__(self):
        
    
# END class Asset

@dataclass
class AssetVersion:
    """Represents a Domo App AssetVersion."""
    
    Asset: Asset

    # New mandatory field comes after all inherited mandatory fields.
    asset_version_id: str
    design_id: str
    version: str
    draft: bool
    trusted: bool
    public_assets_enabled: bool
    
    size_width: str
    size_height: str
    
    full_page: bool

    ai_context_id: str
    flags: any

    created_by: str
    created_date: str
    updated_by: str
    updated_date: str
    release_date: str
    deleted_date: str
    
    # Now fields with defaults
    scopes: List[any] = field(default_factory=list) # List of group IDs
    datasets_mapping: List[any] = field(default_factory=list) # List of group IDs
    collections_mapping: List[any] = field(default_factory=list) # List of group IDs
    accounts_mapping: List[any] = field(default_factory=list) # List of group IDs
    actions_mapping: List[any] = field(default_factory=list) # List of group IDs
    workflows_mapping: List[any] = field(default_factory=list) # List of group IDs
    packages_mapping: List[any] = field(default_factory=list) # List of group IDs
    
    def __init__(self, asset:Asset, asset_version_id, design_id, version, draft, trusted, public_assets_enabled, scopes, datasets_mapping, collections_mapping, accounts_mapping, actions_mapping, workflows_mapping, packages_mapping, size_width, size_height, full_page, ai_context_id, flags, created_by, created_date, updated_by, updated_date, release_date, deleted_date):
        
        self.Asset = asset
        
        self.asset_version_id = asset_version_id
        self.design_id = design_id
        self.version = version
        
        self.draft = draft
        
        self.trusted = trusted
        self.public_assets_enabled = public_assets_enabled
        self.scopes = scopes

        self.datasets_mapping = datasets_mapping
        self.collections_mapping = collections_mapping
        self.accounts_mapping = accounts_mapping
        self.actions_mapping = actions_mapping
        self.workflows_mapping = workflows_mapping
        self.packages_mapping = packages_mapping
        
        self.size_width = size_width
        self.size_height = size_height

        self.full_page = full_page
        self.ai_context_id = ai_context_id
        self.flags = flags

        self.created_by = created_by
        self.created_date = created_date
        self.updated_by = updated_by
        self.updated_date = updated_date
        self.release_date = release_date
        self.deleted_date = deleted_date
        
    # END def __init__():
        
# END class User
