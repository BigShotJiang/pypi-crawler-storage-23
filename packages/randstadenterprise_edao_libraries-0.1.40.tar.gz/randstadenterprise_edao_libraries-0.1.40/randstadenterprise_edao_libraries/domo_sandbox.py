# randstadenterprise_edao_libraries/domo_sandbox.py
from typing import List, Dict, Any, Optional, Callable, Union

# Define the type for the log function for clean type hinting
LogFunc = Callable[[str], None] 

# =======================================================================
# CORE API RETRIEVAL FUNCTIONS (GET_ALL)
# =======================================================================

# =======================================================================
#     Retrieves ALL repositories (owned or shared) from a Domo instance by handling full pagination.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :returns: A single list containing all raw repository dictionary objects.
# =======================================================================
def get_instance_repositories (inst_url: str, inst_dev_token: str, log_func: LogFunc) -> List[Any]:

    log_func(f'____ get_instance_repositories({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    
    all_repos: List[objects.SandboxRepository] = []
    
    owned_repos = get_instance_owned_repositories (inst_url, inst_dev_token, log_func)
    shared_repos = get_instance_shared_repositories (inst_url, inst_dev_token, log_func)
     
    all_repos.extend(owned_repos)
    all_repos.extend(shared_repos)

    log_func(f"_______ owned_repos: {str(len(owned_repos))}")
    log_func(f"_______ shared_repos: {str(len(shared_repos))}")
    log_func(f"_______ TOTAL REPOS: {str(len(all_repos))}")
    
    log_func(f"____ END get_instance_repositories: {inst_url}")
    
    return all_repos

# END def get_instance_repositories


# =======================================================================
#     Retrieves OWNED repositories
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :returns: A single list containing all raw repository dictionary objects.
# =======================================================================
def get_instance_owned_repositories (inst_url: str, inst_dev_token: str, log_func: LogFunc) -> List[Any]:

    log_func(f'____ get_instance_owned_repositories({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    
    all_results = []
    limit = 50
    offset = 0
    result_size = limit # Initialize to ensure loop starts

    while result_size == limit:

        # Get the first page to determine the total count for pagination
        repo_page_results = _get_instance_repositories_page(inst_url, inst_dev_token, log_func, False, offset, limit)
        if repo_page_results is not None:

            page_results = repo_page_results.get("repositories", [])
        
            # 1. Update result_size to the count of items in the CURRENT page
            result_size = len(page_results) 
            
            if result_size > 0:
                # Add all items from the current page to the final list
                all_results.extend(page_results)

                # 2. Increment offset by the size of the current page
                offset += result_size 
            # END if result_size > 0:
        # END if repo_page_results is not None:            
        else:
            log_func(f"_______ NO REPOSITORIES FOUND or critical error at offset: {str(offset)}")
            break
        # END else
        
    # END while result_size == limit:
            
    log_func(f"_______ TOTAL OWNED REPOS: {str(len(all_results))}")

    all_objects: List[objects.SandboxRepository] = []
    all_objects = _load_repo_objects(log_func, all_results)
        
    log_func(f"____ END get_instance_owned_repositories: {inst_url}")
    
    return all_objects

# END def get_instance_owned_repositories


# =======================================================================
#     Retrieves OWNED repositories
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :returns: A single list containing all raw repository dictionary objects.
# =======================================================================
def get_instance_shared_repositories (inst_url: str, inst_dev_token: str, log_func: LogFunc) -> List[Any]:

    log_func(f'____ get_instance_shared_repositories({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    
    all_results = []
    limit = 50
    offset = 0
    result_size = limit # Initialize to ensure loop starts

    while result_size == limit:

        # Get the first page to determine the total count for pagination
        repo_page_results = _get_instance_repositories_page(inst_url, inst_dev_token, log_func, True, offset, limit)
        if repo_page_results is not None:

            page_results = repo_page_results.get("repositories", [])
        
            # 1. Update result_size to the count of items in the CURRENT page
            result_size = len(page_results) 
            
            if result_size > 0:
                # Add all items from the current page to the final list
                all_results.extend(page_results)

                # 2. Increment offset by the size of the current page
                offset += result_size 
            # END if result_size > 0:
        # END if repo_page_results is not None:            
        else:
            log_func(f"_______ NO REPOSITORIES FOUND or critical error at offset: {str(offset)}")
            break
        # END else
        
    # END while result_size == limit:
            
    log_func(f"_______ TOTAL SHARED REPOS: {str(len(all_results))}")

    all_objects: List[objects.SandboxRepository] = []
    all_objects = _load_repo_objects(log_func, all_results)
        
    log_func(f"____ END get_instance_shared_repositories: {inst_url}")
    
    return all_objects

# END def get_instance_shared_repositories

# =======================================================================
#     Retrieves a repository by id
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param repo_id: The exact id of the repo to find.
#     :returns: A single repository object.
# =======================================================================
def get_repository_by_id (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo_id: str) -> Any:

    log_func(f'____ get_repository_by_id({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http 
    
    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{repo_id}"

    resp = edao_http.get(api_url, inst_dev_token, log_func)
    
    repo_object = _load_repo_object(log_func, resp)
        
    log_func(f"____ END get_repository_by_id: {inst_url}")
    
    return repo_object

# END def get_repository_by_id

# =======================================================================
#     Retrieves a repository by name
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param repo_name: The exact name of the repo to find.
#     :returns: A single repository object. This will return the first repo return with the provided name
# =======================================================================
def get_repository_by_name (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo_name: str, shared_repos: bool) -> Any:

    log_func(f'____ get_repository_by_name({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http 
    
    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/search"
    
    sort = "started" if shared_repos else "lastCommit"

    body = {
        "query": {
            "offset": 0,
            "limit": 50,
            "fieldSearchMap": {
                "repositoryName" : repo_name
            },
            "sort": sort,
            "order": "desc",
            "filters": {
                "userId": None
            },
            "dateFilters": {},
        },
        "shared": shared_repos
    }    

    resp = edao_http.post(api_url, inst_dev_token, log_func, body)
    
    repos = resp.get("repositories", [])
    
    repo_object = None
    
    if len(repos) > 0:
        repo_object = _load_repo_object(log_func, repos[0])
        
    log_func(f"____ END get_repository_by_name: {inst_url}")
    
    return repo_object

# END def get_repository_by_name

# =======================================================================
#     Retrieves the shared instances of a repository
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param repo_id: The id of the repo to retrieve the shared instances

#     :returns: a list of instance strings
# =======================================================================
def get_repository_shared_instances (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo_id: str) -> List[str]:

    log_func(f'____ get_repository_shared_instances({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http 

    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{repo_id}/access" 

    resp = edao_http.get(api_url, inst_dev_token, log_func)
    # {
    #     "accessList": [
    #         {
    #             "repositoryId": "8cb4eda7-03c8-45b3-9335-c9a147cfb521",
    #             "invitedDomain": "randstad-dev.domo.com"
    #         },
    #         {
    #             "repositoryId": "8cb4eda7-03c8-45b3-9335-c9a147cfb521",
    #             "invitedDomain": "randstad-merck.domo.com"
    #         },
    #         {
    #             "repositoryId": "8cb4eda7-03c8-45b3-9335-c9a147cfb521",
    #             "invitedDomain": "randstad.domo.com"
    #         }
    #     ]
    # }    
    
    instances = resp.get("accessList", [])
    
    shared_instances = []
    for i in instances:
        shared_instances.append(i["invitedDomain"])
    # END for i in instances:
        
    log_func(f"____ END get_repository_shared_instances: {inst_url}")
    
    return shared_instances

# END def get_repository_shared_instances

# =======================================================================
#     Retrieves the users and groups that have access to this repository
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param repo_id: The id of the repo to retrieve the shared permissions

#     :returns: a list of instance strings
# =======================================================================
def get_repository_shared_permissions (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo_id: str) -> List[str]:

    log_func(f'____ get_repository_shared_permissions({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http 
    from . import domo_objects 

    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{repo_id}/access" 

    resp = edao_http.get(api_url, inst_dev_token, log_func)
    
    #Resp equals this
    # {
    #     "subjectId": "8cb4eda7-03c8-45b3-9335-c9a147cfb521",
    #     "userPermissions": {
    #         "889463734": "OWNER"
    #     },
    #     "groupPermissions": {
    #         "723883890": "EDIT"
    #     }
    # }  
    
    user_permissions = resp.get("userPermissions", {})
    group_permissions = resp.get("groupPermissions", {})

    shared_permissions = []
    for u_id, p_level in user_permissions.items():
        
        perm = domo_objects.RepoPermission (
            repo_id=repo_id,
            id=str(u_id),
            share_type=domo_objects.RepoShareType(p_level),
            user_or_group=domo_objects.UserOrGroup.USER
        ) 
        
        shared_permissions.append(perm)
    # END for u_id, p_level in user_permissions.items():
        
    for gp in group_permissions:
        
        perm = domo_objects.RepoPermission (
            repo_id=repo_id,
            id=str(u_id),
            share_type=domo_objects.RepoShareType(p_level),
            user_or_group=domo_objects.UserOrGroup.GROUP
        ) 
        
        shared_permissions.append(perm)
    # END for up in user_permissions:
        
    log_func(f"____ END get_repository_shared_permissions: {inst_url}")
    
    return shared_permissions

# END def get_repository_shared_permissions

# =======================================================================
#     Create a repository in a source instance
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param repo: The repository to create. Required elements are name and repository_content

#     :returns: A single repository object with the new id
# =======================================================================
def create_repository (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo: Any) -> Any:

    log_func(f'____ create_repository({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    from . import edao_http    

    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories"
    
    body = {
              "id": "",
              "connectionId": "",
              "name": repo.name,
              "repositoryContent": repo.repository_content.to_json(),
              "repository": "",
              "domain": "",
              "permission": "OWNER",
              "seeded": False
            }

    resp = edao_http.post(api_url, inst_dev_token, log_func, body)
    
    repo_object = _load_repo_object(log_func, resp)
        
    log_func(f"____ END create_repository: {inst_url}")
    
    return repo_object

# END def create_repository

# =======================================================================
#     Commit a repository in a source instance
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param repo: The repository to commit
#     :param summary: The summary of the commit

#     :returns: A single repository object with the new commit
# =======================================================================
def commit_repository (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo: Any, summary: str) -> Any:

    log_func(f'____ commit_repository({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    from . import edao_http    

    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{repo.id}/commitRequests"
    
    body = {
              "summary": summary,
              "hidden": False,
              "pusherEventId": ""
            }

    resp = edao_http.post(api_url, inst_dev_token, log_func, body)
    
    resp_object = _load_repo_commit_object(log_func, repo.id , resp)
        
    repo.last_commit = resp_object
    repo.commits.append(resp_object)
        
    log_func(f"____ END commit_repository: {inst_url}")
    
    return repo

# END def commit_repository

# =======================================================================
#     Delete a repository in a source instance
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param repo_id: The repository to delete.

#     :returns: True or False
# =======================================================================
def delete_repository (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo_id: str) -> Any:

    log_func(f'____ delete_repository({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    from . import edao_http    

    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{repo_id}"

    resp = edao_http.delete(api_url, inst_dev_token, log_func)
        
    log_func(f"____ END delete_repository: {inst_url}")
    
    return True

# END def delete_repository

# =======================================================================
#     Share a repository with and instance in the source instance
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param repo: The repository to share
#     :param inst_domain: the domain to assign to the repository. Must include the "domo.com"

#     :returns: A single repository object with the new commit
# =======================================================================
def share_source_repository_with_instance (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo: Any, inst_domain: str) -> bool:

    log_func(f'____ share_repository_with_instance({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    from . import edao_http    

    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{repo.id}/access"
    
    body = [inst_domain]

    resp = edao_http.post(api_url, inst_dev_token, log_func, body)
        
    log_func(f"____ END share_repository_with_instance: {inst_url}")
    
    return True

# END def share_repository_with_instance

# =======================================================================
#     Remove a repository from an instance in the source instance
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param repo: The repository to remove the share
#     :param inst_domain: the domain to be removed from the repository. Must include the "domo.com"

#     :returns: A single repository object with the new commit
# =======================================================================
def remove_source_repository_from_instance (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo: Any, inst_domain: str) -> bool:

    log_func(f'____ remove_repository_from_instance({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    from . import edao_http    

    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{repo.id}/access"
    
    body = [inst_domain]

    resp = edao_http.post(api_url, inst_dev_token, log_func, body)
        
    log_func(f"____ END remove_repository_from_instance: {inst_url}")
    
    return True

# END def remove_repository_from_instance

# =======================================================================
#     Share a source repository with a user or group
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param repo: The source repository
#     :param owner: Owner object to be shared
#     :param share_type: Enum of the type of share level for the id

#     :returns: True is the share was successful or an Error is thrown
# =======================================================================
def share_source_repository_ownership (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo: Any, owner:Any, share_type: Any = None) -> bool:

    log_func(f'____ share_source_repository_ownership({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    from . import edao_http    
    
    # Handle the default value inside the function
    if share_type is None:
        share_type = domo_objects.RepoShareType.EDIT

    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{repo.id}/permissions"    

    body = {
              "repositoryPermissionUpdates": [
                {
                  "userId": owner.id if owner.type == domo_objects.UserOrGroup.USER else "",
                  "groupId": owner.id if owner.type == domo_objects.UserOrGroup.GROUP else "",
                  "permission": share_type.value
                }
              ]
            }

    resp = edao_http.post(api_url, inst_dev_token, log_func, body)
    
    log_func(f"____ END share_source_repository_ownership: {inst_url}")
    
    return True

# END def share_source_repository_ownership

# =======================================================================
#     Remove a repository ownership from a group or user
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param repo: The repository to commit
#     :param inst_domain: the domain to assign to the repository. Must include the "domo.com"

#     :returns: A single repository object with the new commit
# =======================================================================
def remove_source_repository_ownership (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo: Any, user_id: Any = "", group_id: Any = "") -> bool:

    log_func(f'____ remove_repository_ownership({inst_url})')
    
    result = share_repository_ownership (inst_url, inst_dev_token, log_func, repo, user_id, group_id, RepoShareType.NONE)
    
    log_func(f"____ END remove_repository_ownership: {inst_url}")
    
    return result

# END def remove_repository_ownership

# =======================================================================
#      Assign the Main Owner of a shared repository
    
#      :param inst_url: The Domo instance URL prefix.
#      :param inst_dev_token: The developer token.
#      :param log_func: Pre-bound logging function.
#      :param repo: The repository to assign the owner.
#      :param user_id: The id of the user id assign as owner
#      :returns: A tuple of (bool, str) indicating success/failure and a status message.
# =======================================================================
def assign_repository_owner(inst_url: str, inst_dev_token: str, log_func: LogFunc, repo: Any, user_id: int) -> (bool, str):

    log_func(f'____ assign_repository_owner({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    from . import edao_http 

    # 1. Check if the repo already has an OWNER
    existing_repo = get_repository_by_id(inst_url, inst_dev_token, log_func, repo.id)
    
    # Check for existing deployments which indicate an owner/target instance assignment
    if existing_repo.deployments and len(existing_repo.deployments) > 0:
        msg = f"SKIP: Owner has already been assigned to repo {repo.name} ({repo.id})."
        log_func(msg)
        return False, msg # Return failure status and message instead of raising Error

    # 2. Proceed with Assignment
    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{repo.id}/deployments"
    
    body = {
              "name": repo.id,
              "userId": user_id
            }

    try:
        resp = edao_http.post(api_url, inst_dev_token, log_func, body)
        
        success_msg = f"SUCCESS: Main owner {user_id} assigned to repo {repo.name}."
        log_func(f"____ END assign_repository_owner: {inst_url}")
        
        return True, success_msg

    except Exception as e:
        error_msg = f"ERROR: Failed to assign owner for {repo.name}. Details: {str(e)}"
        log_func(error_msg)
        return False, error_msg

# END def assign_repository_owner

# =======================================================================
#     Share a destination repository with a user or group
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param repo: The source repository
#     :param owner: Owner object to be shared
#     :param share_type: Enum of the type of share level for the id

#     :returns: True is the share was successful or an Error is thrown
# =======================================================================
def share_dest_repository_ownership (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo: Any, owner:Any, share_type: Any = None) -> bool:

    log_func(f'____ share_dest_repository_ownership({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    from . import edao_http    
    
    deployment = repo.deployments[0]
    
    # Handle the default value inside the function
    if share_type is None:
        share_type = domo_objects.RepoShareType.EDIT        

    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{repo.id}/deployments/{deployment.id}/permissions"
    
    body = {
              "deploymentPermissionUpdates": [
                {
                  "permission": share_type.value,
                  "userId": owner.id if owner.type == domo_objects.UserOrGroup.USER else "",
                  "groupId": owner.id if owner.type == domo_objects.UserOrGroup.GROUP else "",
                }
              ]
            }


    resp = edao_http.post(api_url, inst_dev_token, log_func, body)
    
    log_func(f"____ END share_dest_repository_ownership: {inst_url}")
    
    return True

# END def share_source_repository_ownership

# =======================================================================
#     Remove a dest repository ownership from a group or user
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param repo: The repository to commit
#     :param inst_domain: the domain to assign to the repository. Must include the "domo.com"

#     :returns: A single repository object with the new commit
# =======================================================================
def remove_dest_repository_ownership (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo: Any, user_id: Any = "", group_id: Any = "") -> bool:

    log_func(f'____ remove_dest_repository_ownership({inst_url})')
    
    result = share_repository_ownership (inst_url, inst_dev_token, log_func, repo, user_id, group_id, RepoShareType.NONE)
    
    log_func(f"____ END remove_dest_repository_ownership: {inst_url}")
    
    return result

# END def remove_repository_ownership

# =======================================================================
#     Promote Repository
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param last_promotion: The last promotion of the sandbox repository.
#     :returns: The string ID of the promoted repository, or None on failure.
# =======================================================================
def promote_repository (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo: Any, commit_id: str) -> Optional[Any]:

    log_func(f'____ promote_repository({inst_url})')  

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    from . import edao_http
    
    # 1. Validate Deployment and Ownership
    if repo.deployments is None or len(repo.deployments) == 0:
        raise ValueError(f"Validation Error: The repository '{repo.name}' must be assigned an Owner and have at least one deployment configuration.")
    # END if repo.deployments is not None or len(repo.deployments) == 0:

    deployment = repo.deployments[0]

    # 2. Resolve the Promotion Request / Mapping logic
    last_promotion_request = None

    if repo.promotion_request is not None:
        # Priority 1: Use the explicit promotion_request on the repo if it exists
        last_promotion_request = repo.promotion_request
    # END if repo.promotion_request is not None:

    elif deployment.last_promotion is not None and deployment.last_promotion.promotion_request is not None:
        # Priority 2: Fallback to the promotion_request from the last successful deployment
        last_promotion_request = deployment.last_promotion.promotion_request
    # END elif deployment.last_promotion is not None and deployment.last_promotion.promotion_request is not None:

    else:
        # Failure: No mapping data found in either location
        raise ValueError(
            f"Governance Error: Promotion mapping could not be determined. "
            "The repository must either have been promoted successfully at least once, "
            "or a 'promotion_request' with a valid mapping field must exist in the repo metadata."
        )
    # END else:
    
    # {
    #   "commitId": "7fc7b96e-b78a-487b-a9cf-789fefb093bb",
    #   "mapping": [
    #     {
    #       "mappingId": "5df2b9e4-e301-45df-a2f6-4e179e07cfe0",
    #       "deployObjectId": "5c0e5880-b088-42d5-99da-9387c7d6a830",
    #       "repositoryObjectId": "5d0d4592-9ad1-458c-b510-94f0d93e226b",
    #       "contentType": "DATASET",
    #       "link": false
    #     },
    #     {
    #       "mappingId": "0dcb0f48-50da-48fe-98f1-53567ad67f36",
    #       "deployObjectId": "503039810",
    #       "repositoryObjectId": "1897238111",
    #       "contentType": "PAGE",
    #       "link": false
    #     }
    #   ],
    #   "pusherEventId": "6f81d63b-73c2-4532-ae36-48161c506bda",
    #   "approvalId": ""
    # }    

    body = {
                "commitId": commit_id,
                "mapping": last_promotion_request.mapping,
                "pusherEventId":  "",
                # "pusherEventId":  last_promotion.pusher_event_id,
                "approvalId": ""
            }
    
    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{repo.id}/deployments/{deployment.id}/promotions"
    
    resp = edao_http.post(api_url, inst_dev_token, log_func, body)
    
    promotion = _load_promotion_object(log_func, resp)
    promotion.repository_id = repo.id
    promotion.SandboxDeployment = deployment
        
    log_func(f"____ END promote_repository: {inst_url}")
    
    return promotion  

# END def promote_repository

# =======================================================================
#     Retrieves the committed versions of a repository
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param repo_id: The exact id of the repo to retrieve the commits.
#     :returns: A single list containing all raw repository commit objects.
# =======================================================================
def get_repository_commits (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo_id: str) -> Any:

    log_func(f'____ get_repository_commits({str(inst_url)}, {str(repo_id)})')

    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http 
    
    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{str(repo_id)}/commits"

    resp = edao_http.get(api_url, inst_dev_token, log_func)
    
    commits = resp.get("commits", [])
    
    commit_objects = []
    
    if len(commits) > 0:
        commit_objects = _load_repo_commit_objects(log_func, repo_id, commits)
        
    log_func(f'____ END get_repository_commits({str(inst_url)}, {str(repo_id)})')
    
    return commit_objects

# END def get_repository_commits

# =======================================================================
#     Retrieves the latest committed versions of a repository
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param repo_id: The exact id of the repo to retrieve the commits.

#     :returns: A single commit objects.
# =======================================================================
def get_repository_latest_commit (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo_id: str) -> Any:

    log_func(f'____ get_repository_latest_commit({str(inst_url)}, {str(repo_id)})')
    
    commits = get_repository_commits (inst_url, inst_dev_token, log_func, repo_id)

    latest_commit = None
        
    if len(commits) > 0:
        # Initialize trackers with values that will be superseded by the first valid commit
        latest_name = ""
        latest_created = ""
        latest_date = ""

        for c in commits:
            # Check if it's hidden or if it's a dictionary/object and use proper key access
            # is_hidden = c.get('hidden') if isinstance(c, dict) else getattr(c, 'hidden', False)

            if not c.hidden and c.status == 'COMPLETED':
                # We compare the name and created date strings. 
                # This logic finds the 'greatest' version (e.g., 'v9' > 'v8') 
                # and the most recent timestamp simultaneously.
                if c.name >= latest_name and c.created >= latest_created:
                    latest_name = c.name
                    latest_created = c.created
                    latest_commit = c
                # END if c.name >= latest_name and c.created >= latest_created:

            # END if not c.hidden:
        # END for c in commits:

        log_func(f"_______ Selected latest commit: {latest_name} ({latest_commit.name}) created at {latest_date}")            

    # END if len(commits) > 0:        
    
    log_func(f'____ END get_repository_latest_commit({str(inst_url)}, {str(repo_id)})')
    
    return latest_commit

# END def get_repository_latest_commit

# =======================================================================
#     Retrieves the latest deployment of a repository
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param repo_id: The exact id of the repo to retrieve the deployment.

#     :returns: A single deployment objects.
# =======================================================================
def get_repository_latest_deployment (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo_id: str) -> Any:

    log_func(f'____ get_repository_latest_deployment({str(inst_url)}, {str(repo_id)})')
    
    repo = get_repository_by_id (inst_url, inst_dev_token, log_func, repo_id)

    latest_deploy = repo.get_latest_deployment()    
    
    log_func(f'____ END get_repository_latest_deployment({str(inst_url)}, {str(repo_id)})')
    
    return latest_deploy

# END def get_repository_latest_deployment

# =======================================================================
#     Retrieves a repository promote logs
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param promotion: The promotion object to get the logs
#     :returns: A single repository object. This will return the first repo return with the provided name
# =======================================================================
def get_repository_promotion_logs (inst_url: str, inst_dev_token: str, log_func: LogFunc, promotion: Any) -> List[Any]:

    log_func(f'____ get_repository_latest_promotion_logs({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    from . import edao_http 
    
    deploy = promotion.SandboxDeployment
    repo = deploy.SandboxRepository
    # promotion_request = promotion.promotion_request
    
    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{repo.id}/deployments/{deploy.id}/promotions/{promotion.id}/events/search"
    
    body = {
              "offset": 0,
              "limit": 500,
              "filters": {
                "contentId": [],
                "contentType": [],
                "status": [],
                "action": [],
                "contentName": []
              },
              "fieldSearchMap": {},
              "sort": "completed",
              "order": "desc",
              "searchDistinct": False,
              "dateFilters": {}
            }  

    resp = edao_http.post(api_url, inst_dev_token, log_func, body)
    
    logs = resp.get("contentEvents", [])
    
    repo_logs = []
    
    if len(logs) > 0:
        repo_logs = _load_repo_promote_log_objects(log_func, logs, promotion)
        
    log_func(f"____ END get_repository_latest_promotion_logs: {inst_url}")
    
    return repo_logs

# END def get_repository_latest_promotion_logs

# =======================================================================
#     Retrieves the dependencies of a repository
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param repo: The repo

#     :returns: A single repository object. This will return the first repo return with the provided name
# =======================================================================
def get_repository_dependencies (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo: Any) -> List[Any]:

    log_func(f'____ get_repository_dependencies({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    from . import edao_http 
    
    deploy = repo.deployments[0]
    commit = get_repository_latest_commit(inst_url, inst_dev_token, log_func, repo.id)

    log_func(f'_______ commit-({str(commit)})')

    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{repo.id}/deployments/{deploy.id}/dependencies/{commit.commit_id}"

    resp = edao_http.get(api_url, inst_dev_token, log_func)
    
    dependencies_json = resp.get("dependencies", [])
    
    dependencies = []
    
    if len(dependencies_json) > 0:
        dependencies = _load_repo_dependency_objects(log_func, repo.id, dependencies_json)
        
    log_func(f"____ END get_repository_dependencies: {inst_url}")
    
    return dependencies

# END def get_repository_dependencies

# =======================================================================
#     Add a rename Rule to the Repo
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param rename_rule: The SandboxRenameRule object to add to the repo

#     :returns: A single repository object. This will return the first repo return with the provided name
# =======================================================================
def add_rename_rule (inst_url: str, inst_dev_token: str, log_func: LogFunc, rename_rule: Any) -> List[Any]:

    log_func(f'____ add_rename_rule({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    from . import edao_http 
    
    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{rename_rule.repo_id}/deployments/{rename_rule.deployment_id}/settings/renameRule"
    
    body = rename_rule.toJson()

    resp = edao_http.post(api_url, inst_dev_token, log_func, body)
        
    return True

# END def add_rename_rule

# =======================================================================
#     Delete a rename Rule to the Repo
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param repo: The repo object to create the rule
#     :param rule_id: The id of the rule

#     :returns: A single repository object. This will return the first repo return with the provided name
# =======================================================================
def delete_rename_rule (inst_url: str, inst_dev_token: str, log_func: LogFunc, repo: Any, rule_id: int) -> bool:

    log_func(f'____ delete_rename_rule({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    from . import edao_http 
    
    deploy = promotion.SandboxDeployment
    repo = deploy.SandboxRepository
    
    api_url = f"https://{inst_url}.domo.com/api/version/v1/repositories/{repo.id}/deployments/{deploy.id}/settings/renameRule/{rule_id}"

    resp = edao_http.delete(api_url, inst_dev_token, log_func)
        
    log_func(f"____ END delete_rename_rule: {inst_url}")
    
    return True

# END def delete_rename_rule

# =======================================================================
# =======================================================================
# =======================================================================
# =======================================================================
# =======================================================================
# =======================================================================

# =======================================================================
# PRIVATE: LOAD REPOSITORY OBJECTS
#     (PRIVATE) Create a list of REPOSITORY objects from a json list of objects.
    
#     :param log_func: Pre-bound logging function.
#     :param json_array: json array of dataset data
#     :returns: A list of SandboxRepository objects.
# =======================================================================
def _load_repo_objects(log_func: LogFunc, json_array: Any) -> List[Any]:
    """
    Parses a list of raw JSON objects into a list of domo_objects.SandboxRepository instances.
    Skips individual objects that fail to load.
    """

    loaded_objects = [] # Renamed from 'objects' to avoid shadowing the module name
    
    # 1. Validate the input array
    if json_array is None:
        log_func("WARN: Input json_array is None. Returning empty list.")
        return []
        
    if not isinstance(json_array, list):
        msg = f"CRITICAL: Input json_array must be a list, got {type(json_array).__name__}."
        log_func(msg)
        raise TypeError(msg)

    # 2. Iterate through the array
    for i, json_item in enumerate(json_array):
        try:
            # 3. Load individual object
            obj = _load_repo_object(log_func, json_item)
            
            # Use .append() for Python lists (not .add)
            loaded_objects.append(obj)
            
        except (ValueError, RuntimeError) as e:
            # 4. Handle known errors from the single object loader
            log_func(f"ERROR: Failed to load object at index {i}. Skipping. Details: {e}")
            continue
            
        except Exception as e:
            # 5. Handle unexpected errors
            log_func(f"CRITICAL: Unexpected error loading object at index {i}: {e}")
            continue

    return loaded_objects
# END def _load_repo_objects

# =======================================================================
# PRIVATE: LOAD REPOSITORY OBJECT
#     (PRIVATE) Create a REPOSITORY object from a json object.
    
#     :param log_func: Pre-bound logging function.
#     :param json: json of repository data
#     :returns: A single SandboxRepository object.
# =======================================================================
def _load_repo_object(log_func: LogFunc, json: Any) -> Any:
    """
    Parses raw JSON into an domo_objects.SandboxRepository instance. 
    Raises an error if JSON is missing or if object creation fails.
    """

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 

    # 1. Check if JSON is None or empty
    if not json:
        msg = "CRITICAL: Input JSON for _load_repo_object is None or empty."
        log_func(msg)
        raise ValueError(msg)

    try:
        # 2. Attempt to create the SandboxRepository object
        return domo_objects.SandboxRepository (
            id=json.get('id', ''),
            name=json.get('name', ''),
            domain=json.get('domain', ''),
            repo_type=json.get('type', ''),
            user_id=json.get('userId', ''),
            access_count=json.get('accessCount', ''),

            # Now fields with defaults
            repository_content=json.get('repositoryContent', {}),
            created=json.get('created', ''),
            updated=json.get('updated', ''),
            seeded=json.get('seeded', ''),
            last_commit=json.get('lastCommit', {}),
            permission=json.get('permission', []),
            deployments=json.get('deployments', []),
            commits=[]
        )        
    
    except Exception as e:
        # 3. Catch and re-raise errors during object creation
        msg = f"CRITICAL: Failed to instantiate domo_objects.SandboxRepository. Error: {e}"
        log_func(msg)
        # Re-raise as a runtime error so the calling script knows it failed
        raise RuntimeError(msg) from e
        
# END def _load_repo_object(log_func: LogFunc, json: Any) -> domo_objects.SandboxRepository:    


# =======================================================================
# PRIVATE: LOAD PROMOTION OBJECT
#     (PRIVATE) Create a SandboxPromotion object from a json object.
    
#     :param log_func: Pre-bound logging function.
#     :param json: json of promotion data
#     :returns: A single SandboxPromotion object.
# =======================================================================
def _load_promotion_object(log_func: LogFunc, json: Any) -> Any:
    """
    Parses raw JSON into an domo_objects.SandboxPromotion instance. 
    Raises an error if JSON is missing or if object creation fails.
    """
    
    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 

    # 1. Check if JSON is None or empty
    if not json:
        msg = "CRITICAL: Input JSON for _load_promotion_object is None or empty."
        log_func(msg)
        raise ValueError(msg)

    try:
        # 2. Attempt to create the SandboxPromotion object
        
        return domo_objects.SandboxPromotion (
                        deployment=None,
                        id=json.get('id', ''),
                        deployment_id=json.get('deploymentId', ''),
                        commit_id=json.get('commitId', ''),
                        repository_id=json.get('repositoryId', ''),
                        user_id=json.get('userId', ''),
                        commit_name=json.get('commitName', ''),
                        repository_name=json.get('repositoryName', ''),
                        started=json.get('started', ''),
                        completed=json.get('completed', ''),
                        status=json.get('status', ''),
                        pusher_event_id=json.get('pusherEventId', ''),
            
                        approval_id=json.get('promotionRequest', {}).get('approvalId', ''),
            
                        promotion_request=json.get('promotionRequest', {}),
                        promotion_result=json.get('promotionResult', {})
                    )         
    
    except Exception as e:
        # 3. Catch and re-raise errors during object creation
        msg = f"CRITICAL: Failed to instantiate domo_objects.SandboxPromotion. Error: {e}"
        log_func(msg)
        # Re-raise as a runtime error so the calling script knows it failed
        raise RuntimeError(msg) from e
        
# END def _load_promotion_object(log_func: LogFunc, json: Any) -> domo_objects.SandboxPromotion:    


# =======================================================================
# PRIVATE: LOAD REPOSITORY PROMOTE LOG OBJECT
#     (PRIVATE) Create a REPOSITORY PROMOTE LOG object from a json object.
    
#     :param log_func: Pre-bound logging function.
#     :param json: json of repository promote log data
#     :returns: A list of dataset dictionary objects.
# =======================================================================
def _load_repo_promote_log_objects(log_func: LogFunc, json_array: Any, promotion:Any) -> List[Any]:
    """
    Parses a list of raw JSON objects into a list of domo_objects.SandboxPromotionLog instances.
    Skips individual objects that fail to load.
    """
    
    loaded_objects = [] # Renamed from 'objects' to avoid shadowing the module name
    
    # 1. Validate the input array
    if json_array is None:
        log_func("WARN: Input json_array is None. Returning empty list.")
        return []
        
    if not isinstance(json_array, list):
        msg = f"CRITICAL: Input json_array must be a list, got {type(json_array).__name__}."
        log_func(msg)
        raise TypeError(msg)

    # 2. Iterate through the array
    for i, json_item in enumerate(json_array):
        try:
            # 3. Load individual object
            obj = _load_repo_promote_log_object(log_func, json_item, promotion)
            
            # Use .append() for Python lists (not .add)
            loaded_objects.append(obj)
            
        except (ValueError, RuntimeError) as e:
            # 4. Handle known errors from the single object loader
            log_func(f"ERROR: Failed to load object at index {i}. Skipping. Details: {e}")
            continue
            
        except Exception as e:
            # 5. Handle unexpected errors
            log_func(f"CRITICAL: Unexpected error loading object at index {i}: {e}")
            continue

    return loaded_objects
# END def _load_repo_promote_log_objects

# =======================================================================
# PRIVATE: LOAD REPOSITORY PROMOTE LOG OBJECT
#     (PRIVATE) Create a REPOSITORY PROMOTE LOG object from a json object.
    
#     :param log_func: Pre-bound logging function.
#     :param json: json of repository promote log data
#     :returns: A list of dataset dictionary objects.
# =======================================================================
def _load_repo_promote_log_object(log_func: LogFunc, json: Any, promotion:Any) -> Any:
    """
    Parses raw JSON into an domo_objects.SandboxPromotionLog instance. 
    Raises an error if JSON is missing or if object creation fails.
    """

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 

    # 1. Check if JSON is None or empty
    if not json:
        msg = "CRITICAL: Input JSON for _load_repo_promote_log_object is None or empty."
        log_func(msg)
        raise ValueError(msg)

    try:
        # 2. Attempt to create the SandboxPromotionLog object
        return domo_objects.SandboxPromotionLog (
            promotion=promotion,
            log_id=json.get('id', ''),
            event_type=json.get('eventType', ''),
            event_id=json.get('eventId', ''),
            content_id=json.get('contentId', ''),
            content_name=json.get('contentName', ''),
            action=json.get('action', ''),
            content_type=json.get('contentType', ''),
            started=json.get('started', ''),
            completed=json.get('completed', ''),
            level=json.get('level', ''),
        )       
    
    except Exception as e:
        # 3. Catch and re-raise errors during object creation
        msg = f"CRITICAL: Failed to instantiate domo_objects.SandboxPromotionLog. Error: {e}"
        log_func(msg)
        # Re-raise as a runtime error so the calling script knows it failed
        raise RuntimeError(msg) from e
        
# END def _load_repo_promote_log_object(log_func: LogFunc, json: Any) -> domo_objects.SandboxPromotionLog:    

# =======================================================================
# PRIVATE: LOAD REPOSITORY COMMITS OBJECTS
    
#     :param log_func: Pre-bound logging function.
#     :param json: json of repository promote log data
#     :returns: A list of commit object.
# =======================================================================
def _load_repo_commit_objects(log_func: LogFunc, repo_id: str, json_array: Any) -> List[Any]:
    """
    Parses a list of raw JSON objects into a list of domo_objects.SandboxCommit instances.
    Skips individual objects that fail to load.
    """
    
    loaded_objects = [] # Renamed from 'objects' to avoid shadowing the module name
    
    # 1. Validate the input array
    if json_array is None:
        log_func("WARN: Input json_array is None. Returning empty list.")
        return []
        
    if not isinstance(json_array, list):
        msg = f"CRITICAL: Input json_array must be a list, got {type(json_array).__name__}."
        log_func(msg)
        raise TypeError(msg)

    # 2. Iterate through the array
    for i, json_item in enumerate(json_array):
        try:
            # 3. Load individual object
            obj = _load_repo_commit_object(log_func, repo_id, json_item)
            
            # Use .append() for Python lists (not .add)
            loaded_objects.append(obj)
            
        except (ValueError, RuntimeError) as e:
            # 4. Handle known errors from the single object loader
            log_func(f"ERROR: Failed to load object at index {i}. Skipping. Details: {e}")
            continue
            
        except Exception as e:
            # 5. Handle unexpected errors
            log_func(f"CRITICAL: Unexpected error loading object at index {i}: {e}")
            continue

    return loaded_objects
# END def _load_repo_commit_objects

# =======================================================================
# PRIVATE: LOAD REPOSITORY COMMIT LOG OBJECT
    
#     :param log_func: Pre-bound logging function.
#     :param json: json of sandbox commit data
#     :returns: A sandbox commit object.
# =======================================================================
def _load_repo_commit_object(log_func: LogFunc, repo_id:str , json: Any) -> Any:
    """
    Parses raw JSON into an domo_objects.SandboxCommit instance. 
    Raises an error if JSON is missing or if object creation fails.
    """

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 

    # 1. Check if JSON is None or empty
    if not json:
        msg = "CRITICAL: Input JSON for _load_repo_commit_object is None or empty."
        log_func(msg)
        raise ValueError(msg)

    try:
        # 2. Attempt to create the SandboxCommit object
        return domo_objects.SandboxCommit (
            repo_id=repo_id,
            commit_id=json.get('id', ''),
            name=json.get('name', ''),
            hidden=json.get('hidden', ''),
            summary=json.get('summary', ''),
            path=json.get('path', ''),
            status=json.get('status', ''),
        )       
    
    except Exception as e:
        # 3. Catch and re-raise errors during object creation
        msg = f"CRITICAL: Failed to instantiate domo_objects.SandboxCommit. Error: {e}"
        log_func(msg)
        # Re-raise as a runtime error so the calling script knows it failed
        raise RuntimeError(msg) from e
        
# END def _load_repo_commit_object(log_func: LogFunc, json: Any) -> domo_objects.SandboxCommit:    


# =======================================================================
# PRIVATE: LOAD REPOSITORY SANDBOX DEPENDENCY OBJECTS
    
#     :param log_func: Pre-bound logging function.
#     :param json: json of repository promote log data
#     :returns: A list of dependencies object.
# =======================================================================
def _load_repo_dependency_objects(log_func: LogFunc, repo_id: str, json_array: Any) -> List[Any]:
    """
    Parses a list of raw JSON objects into a list of domo_objects.SandboxDependency instances.
    Skips individual objects that fail to load.
    """
    
    loaded_objects = [] # Renamed from 'objects' to avoid shadowing the module name
    
    # 1. Validate the input array
    if json_array is None:
        log_func("WARN: Input json_array is None. Returning empty list.")
        return []
        
    if not isinstance(json_array, list):
        msg = f"CRITICAL: Input json_array must be a list, got {type(json_array).__name__}."
        log_func(msg)
        raise TypeError(msg)

    # 2. Iterate through the array
    for i, json_item in enumerate(json_array):
        try:
            # 3. Load individual object
            obj = _load_repo_dependency_object(log_func, repo_id, json_item)
            
            # Use .append() for Python lists (not .add)
            loaded_objects.append(obj)
            
        except (ValueError, RuntimeError) as e:
            # 4. Handle known errors from the single object loader
            log_func(f"ERROR: Failed to load object at index {i}. Skipping. Details: {e}")
            continue
            
        except Exception as e:
            # 5. Handle unexpected errors
            log_func(f"CRITICAL: Unexpected error loading object at index {i}: {e}")
            continue

    return loaded_objects
# END def _load_repo_dependency_objects

# =======================================================================
# PRIVATE: LOAD REPOSITORY COMMIT LOG OBJECT
    
#     :param log_func: Pre-bound logging function.
#     :param json: json of sandbox commit data
#     :returns: A sandbox commit object.
# =======================================================================
def _load_repo_dependency_object(log_func: LogFunc, repo_id:str , json: Any) -> Any:
    """
    Parses raw JSON into an domo_objects.SandboxDependency instance. 
    Raises an error if JSON is missing or if object creation fails.
    """

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 

    # 1. Check if JSON is None or empty
    if not json:
        msg = "CRITICAL: Input JSON for _load_repo_dependency_object is None or empty."
        log_func(msg)
        raise ValueError(msg)

    try:
        # 2. Attempt to create the SandboxCommit object
        return domo_objects.SandboxDependency (
            repo_id=repo_id,
            name=json.get('name', ''),
            constraints=json.get('constraints', []),
            content_map_request=json.get('contentMapRequest', {})
        )       
    
    except Exception as e:
        # 3. Catch and re-raise errors during object creation
        msg = f"CRITICAL: Failed to instantiate domo_objects.SandboxDependency. Error: {e}"
        log_func(msg)
        # Re-raise as a runtime error so the calling script knows it failed
        raise RuntimeError(msg) from e
        
# END def _load_repo_dependency_object()


# =======================================================================
# =======================================================================
# =======================================================================
# PRIVATE API HELPER FUNCTIONS
# =======================================================================
# =======================================================================
# =======================================================================

# =======================================================================
# (PRIVATE HELPER) Fetches a single paginated result of repositories (owned or shared).
#     Used by get_all_instance_repositories.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param shared_repos: If True, retrieve shared repositories; False for owned.
#     :param offset: The starting index for pagination.
#     :param limit: The number of results to return.
#     :returns: The raw JSON response dictionary containing 'repositories' and 'pageContext', or an empty dict on error.
# =======================================================================
def _get_instance_repositories_page (inst_url: str, inst_dev_token: str, log_func: LogFunc, shared_repos: bool, offset: int, limit: int) -> Any:

    log_func(f'_______ _get_instance_repositories_page(shared: {str(shared_repos)}, offset: {str(offset)}, limit: {str(limit)})')

    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http 

    api_url = f'https://{inst_url}.domo.com/api/version/v1/repositories/search'
    
    sort = "started" if shared_repos else "lastCommit"

    body = {
        "query": {
            "offset": offset,
            "limit": limit,
            "fieldSearchMap": {},
            "sort": sort,
            "order": "desc",
            # "filters": {
            #     "userId": None
            # },
            "dateFilters": {}
        },
        "shared": shared_repos
    }
    
    page_result = edao_http.post(api_url, inst_dev_token, log_func, body)
        
    log_func('_______ END _get_instance_repositories_page()')

    return page_result
# END def _get_instance_repositories_page


def _get_invited_domains (inst_url: str, inst_dev_token: str, repo_id: str, log_func: LogFunc) -> List[Dict[str, str]]:
    """
    (PRIVATE HELPER) Fetches the list of domains an owned repository has been shared with.
    Used by get_instance_repositories_map for owned repositories.
    
    :param inst_url: The Domo instance URL prefix.
    :param inst_dev_token: The developer token.
    :param repo_id: The ID of the repository.
    :param log_func: Pre-bound logging function.
    :returns: A list of dictionaries, each containing 'repositoryId' and 'invitedDomain'.
    """

    log_func(f'____________________ _getInvitedDomains(repo_id: {repo_id})')

    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http 

    api_url = f'https://{inst_url}.domo.com/api/version/v1/repositories/{repo_id}/access'
    
    invited_domains_result = []
    
    try:
        # START try
        resp = edao_http.get(api_url, headers=helpers.get_http_headers(inst_dev_token), timeout=20)
        resp.raise_for_status() 
        
        invited_domains_json = resp.json()
        # Extract the 'accessList' array, ensuring it exists and is a list
        if "accessList" in invited_domains_json and isinstance(invited_domains_json["accessList"], list):
            # START if "accessList" in invited_domains_json and isinstance(invited_domains_json["accessList"], list)
            invited_domains_result = invited_domains_json["accessList"]
            # END if "accessList" in invited_domains_json and isinstance(invited_domains_json["accessList"], list)
            
        # END try
    except requests.exceptions.RequestException as e:
        # START except requests.exceptions.RequestException
        log_func(f"ERROR fetching invited domains (repo_id: {repo_id}): {type(e).__name__} - {e}")
        # END except requests.exceptions.RequestException
        
    log_func('____________________ END _getInvitedDomains()')

    return invited_domains_result
# END def _get_invited_domains


def _get_repository_owners (
    inst_url: str, inst_dev_token: str, shared_repos: bool, repo_id: str, deploy_id: Optional[str], log_func: LogFunc
) -> Dict[str, Any]:
    """
    (PRIVATE HELPER) Fetches user and group permissions for a repository (or deployment).
    Used by get_instance_repositories_map.
    
    :param inst_url: The Domo instance URL prefix.
    :param inst_dev_token: The developer token.
    :param shared_repos: If True, the permissions are for a shared deployment; False for an owned repo.
    :param repo_id: The ID of the repository.
    :param deploy_id: The deployment ID, required if shared_repos is True.
    :param log_func: Pre-bound logging function.
    :returns: A dictionary containing 'userPermissions' and 'groupPermissions', or an empty dict on error.
    """

    log_func(f'____________________ _getRepositoryOwners(repo_id: {repo_id}, deploy_id: {deploy_id})')

    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http 

    # Construct the API URL based on whether it's an owned repo or a shared deployment
    if shared_repos and deploy_id:
        # START if shared_repos and deploy_id
        api_url = f'https://{inst_url}.domo.com/api/version/v1/repositories/{repo_id}/deployments/{deploy_id}/permissions'
        # END if shared_repos and deploy_id
    else:
        # START else
        api_url = f'https://{inst_url}.domo.com/api/version/v1/repositories/{repo_id}/permissions'
        # END else
    
    owners_result = {}
    
    resp = edao_http.get(api_url, headers=helpers.get_http_headers(inst_dev_token), timeout=20)
    resp.raise_for_status() 
    owners_result = resp.json()
        
    log_func('____________________ END _getRepositoryOwners()')

    return owners_result
# END def _get_repository_owners


def _get_repository_content_ids_string (
    repo: Dict[str, Any], content_key: str, log_func: LogFunc
) -> str:
    """
    (PRIVATE HELPER) Extracts a pipe-separated string of IDs for a specific content type 
    (e.g., 'pageIds', 'viewIds') from a repository object.
    
    :param repo: The repository dictionary object.
    :param content_key: The key within 'repositoryContent' (e.g., 'pageIds').
    :param log_func: Pre-bound logging function.
    :returns: Pipe-separated string of IDs, or an empty string.
    """
    
    # log_func(f'_______________ _get_repository_content_ids_string({content_key})')

    content_ids_str = ""
    
    if "repositoryContent" in repo:
        # START if "repositoryContent" in repo
        repository_content = repo["repositoryContent"]
        if content_key in repository_content:
            # START if content_key in repository_content
            id_list = repository_content[content_key]
            if isinstance(id_list, list):
                # START if isinstance(id_list, list)
                # Concatenate IDs with a pipe separator using a list comprehension
                content_ids_str = "|".join([str(id_val) for id_val in id_list])
                # END if isinstance(id_list, list)
            # END if content_key in repository_content
        # END if "repositoryContent" in repo

    # log_func(f'_______________ END _get_repository_content_ids_string({content_key})')
    return content_ids_str
# END def _get_repository_content_ids_string