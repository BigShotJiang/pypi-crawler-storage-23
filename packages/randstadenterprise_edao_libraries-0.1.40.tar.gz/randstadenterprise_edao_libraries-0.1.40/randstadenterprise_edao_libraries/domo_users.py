# randstadenterprise_edao_libraries/domo_users.py
from typing import List, Dict, Any, Optional, Callable

# Define the type for the log function
LogFunc = Callable[[str], None] 

# =======================================================================
# RETRIEVES ALL USERS, ENRICHES DATA, AND MAPS BY USER ID
#     Retrieves all instance users, enriches the data with readable fields, 
#     and returns a map of the full domo_objects.User object by User ID.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.

#     :returns: Dictionary mapping User ID (str) to the domo_objects.User object.
# =======================================================================

def get_instance_users (inst_url: str, inst_dev_token: str, log_func: LogFunc) -> List[Any]:
    
    log_func(f"____ get_instance_users: {inst_url}")
    
    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects
    from . import domo_roles

    # 1. Get Role Map for lookup using the roles function
    roles_map = domo_roles.get_instance_roles(inst_url, inst_dev_token, log_func)
    
    # 2. Get raw user data using the private search helper
    inst_users = _get_instance_users_search(inst_url, inst_dev_token, log_func)
    
    users: List[objects.User] = _load_user_objects(log_func, inst_users)

    log_func(f"____ END get_instance_users: {inst_url}")
 
    return users
# END def get_instance_users

# =======================================================================
# RETRIEVES A SINGLE USER BY ID
#     Stubs out functionality to retrieve a single user by their ID.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param user_id: The string ID of the user.
#     :param log_func: Pre-bound logging function.
#     :returns: The domo_objects.User object, or None if not found.
# =======================================================================
def get_user_by_id (inst_url: str, inst_dev_token: str, log_func: LogFunc, user_id: str) -> Any:
       
    log_func(f"____ get_user_by_id: {inst_url}")
    
     # ADD IMPORT HERE (Lazy Import)
    from . import edao_http
    from . import domo_attributes
    
    api_url = f'https://{inst_url}.domo.com/api/identity/v1/users/search?explain=true'
    
    sync_attrs = domo_attributes.get_instance_attributes (inst_url, inst_dev_token, log_func)
    
    # 1. Loop and filter: Add keys that do not start with "domo.policy"
    search_attributes = [
        attr_key for attr_key, attr_val in sync_attrs.items() 
        if not attr_key.startswith("domo.policy")
    ]   
    
    body = {
      "ids": [
        user_id
      ],
      "showCount": False,
      "includeDeleted": True,
      "onlyDeleted": False,
      "includeSupport": True,
      "limit": 1,
      "offset": 0,
      "parts": [
        "DETAILED",
        "GROUPS",
        "ROLE"
      ],
      "attributes": search_attributes
    }

    resp = edao_http.post(api_url, inst_dev_token, log_func, body)    
    user_json = {}
    if "users" in resp:
        user_list = resp.get("users", [])
        if len(user_list) > 0:
            user_json = user_list[0] 
        # END if len(user_list) > 0:
    # END if "users" in user_json:
    
    user_result = _load_user_object(log_func, user_json)

    log_func(f"____ END get_user_by_id: {inst_url}")
    
    return user_result
    
# END def get_user_by_id

# =======================================================================
# RETRIEVES A SINGLE USER BY EMAIL ADDRESS
#     Stubs out functionality to retrieve a single user by their email address.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param user_email: The email address of the user.
#     :param log_func: Pre-bound logging function.
#     :returns: The domo_objects.User object, or None if not found.
# =======================================================================
def get_user_by_email (inst_url: str, inst_dev_token: str, log_func: LogFunc, user_email: str) -> Any:
       
    log_func(f"____ get_user_by_email: {inst_url}")
    
    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http
    from . import domo_attributes
    
    api_url = f'https://{inst_url}.domo.com/api/identity/v1/users/search?explain=true'
    
    sync_attrs = domo_attributes.get_instance_attributes (inst_url, inst_dev_token, log_func)
    
    # 1. Loop and filter: Add keys that do not start with "domo.policy"
    search_attributes = [
        attr_key for attr_key, attr_val in sync_attrs.items() 
        if not attr_key.startswith("domo.policy")
    ]   
    
    body = {
        "filters": [
            {
              "field": "emailAddress",
              "operator": "EQ",
              "filterType": "value",
              "values": [
                user_email
              ]
            }
          ],
        "showCount": False,
        "includeDeleted": True,
        "onlyDeleted": False,
        "includeSupport": True,
        "limit": 1,
        "offset": 0,
        "parts": [
            "DETAILED",
            "GROUPS",
            "ROLE"
        ],
        "attributes": search_attributes
    }

    # log_func(f"_______ get_user_by_email body: {body}")
    resp = edao_http.post(api_url, inst_dev_token, log_func, body)
    # log_func(f"_______ get_user_by_email resp: {resp}")
    user_json = {}
    if "users" in resp:
        user_list = resp.get("users", [])
        if len(user_list) > 0:
            user_json = user_list[0] 
        # END if len(user_list) > 0:    
    # END if "users" in user_json:
    elif isinstance(resp, list):
        user_json = resp[0] 
    # END elif isinstance(result, list):
    
    # log_func(f"_______ get_user_by_email user_json: {user_json}")
    user_result = None
    if user_json != {}:
        user_result = _load_user_object(log_func, user_json)
    # END if user_json != {}:
    
    log_func(f"____ get_user_by_email: {inst_url}")

    return user_result
    
# END def get_user_by_email

# =======================================================================
# USER MODIFICATION FUNCTIONS
# =======================================================================

# =======================================================================
# CREATES A USER
#    Functionality to create a user.
#    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param user_obj: The domo_objects.User object (dataclass instance) to be saved.
#     :returns: The user object of the created user.
# =======================================================================
def create_user(inst_url: str, inst_dev_token: str, log_func: LogFunc, user_obj: Any) -> Any:

    log_func(f"____ create_user({user_obj.name})")
    
    # Lazy imports to avoid circular dependencies
    from . import edao_http
    from . import domo_roles
    from . import domo_attributes
        
    # Validation: Ensure the Display Name is present
    if user_obj.name is None:
        log_func("ERROR: Attempted to create user without a name.")
        raise ValueError("The 'name' field (Display Name) is mandatory for creating a Domo user.")
    # END if user_obj.name is None:
        
    # Validation: Ensure the Email Address is present
    if user_obj.email_address is None:
        log_func("ERROR: Attempted to create user without an email address.")
        raise ValueError("The 'email_address' field is mandatory for creating a Domo user.")
    # END if user_obj.email_address is None:
        
    # Role Logic: If no specific Role ID is provided, resolve it by name
    role_id = user_obj.role_id
    if role_id is None:
        # Default to 'Corporate Participant' if no role_name is provided
        role_name = "Corporate Participant" if user_obj.role_name is None else user_obj.role_name
        
        log_func(f"____ create_user: Role ID missing. Fetching ID for role: {role_name}")
        cp_role = domo_roles.get_role_by_name(inst_url, inst_dev_token, log_func, role_name)
        
        # Ensure the role was successfully found
        if cp_role is None:
            raise ValueError(f"Could not find a role with the name '{role_name}' in instance {inst_url}.")
            
        role_id = cp_role.role_id
    # END if role_id is None:
    
    # Construct the API request body for the Identity/Content API
    body = {
        "displayName": user_obj.name,
        "roleId": role_id,
        "detail": {
            "email": user_obj.email_address
        }
    }

    # Domo API endpoint for user creation
    api_url = f'https://{inst_url}.domo.com/api/content/v3/users/'

    # Execute the POST request via the HTTP helper
    resp = edao_http.post(api_url, inst_dev_token, log_func, body)

    # Process the response and populate the user object with the new server-side ID
    user_obj = _load_user_object(log_func, resp)
    
    log_func(f"____ END create_user({user_obj.name})")
    
    return user_obj
# END def create_user

# =======================================================================
# UPDATE A USER
#      Functionality to update a user's custom attributes and metadata.
#    
#      :param inst_url: The Domo instance URL prefix.
#      :param inst_dev_token: The developer token.
#      :param log_func: Pre-bound logging function.
#      :param user_obj: The User object (dataclass instance) to be saved.
#      :returns: The string ID of the saved user, or None on failure.
# =======================================================================
def update_user(inst_url: str, inst_dev_token: str, log_func: LogFunc, user_obj: Any) -> Optional[str]:
    log_func(f"____ update_user({user_obj.name})")
    
    # Lazy imports to maintain modularity
    from . import edao_http
    
    # Validation: Ensure we have a way to identify the user
    if user_obj.id is None and user_obj.email_address is None:
        log_func("ERROR: Attempted update without User ID or Email Address.")
        raise ValueError("Update failed: user_obj must contain either an 'id' or an 'email_address' to identify the target user.")
    # END if user_obj.id is None and user_obj.email_address is None:
        
    # Identification: Resolve ID by email if the ID is missing
    if user_obj.id is None:
        log_func(f"____ update_user: ID missing. Resolving via email: {user_obj.email_address}")
        ext_user = get_user_by_email(inst_url, inst_dev_token, log_func, user_obj.email_address)
        
        if ext_user is None or ext_user.id is None:
            log_func(f"ERROR: Could not find user with email {user_obj.email_address}")
            return None
            
        user_obj.id = ext_user.id
        # Update internal attributes map if necessary
        if hasattr(user_obj, 'attributes'):
             user_obj.attributes["id"] = [str(ext_user.id)]
    # END if user_obj.id is None:
    
    # Organizational Logic: Resolve ReportsTo ID if an email was provided
    if user_obj.reports_to_email_address is not None:
        log_func(f"____ update_user: Resolving ReportsTo ID for: {user_obj.reports_to_email_address}")
        reports_to_user = get_user_by_email(inst_url, inst_dev_token, log_func, user_obj.reports_to_email_address)
        
        if reports_to_user:
            user_obj.attributes["reportsTo"] = [str(reports_to_user.id)]
    # END if user_obj.reports_to_email_address is not None:

    # Construct the payload using the dataclass method
    # Note: Use self.attributes within the dataclass as discussed previously
    body = user_obj.build_user_update_body()

    # Domo Identity API uses PATCH for partial updates to user attributes
    api_url = f"https://{inst_url}.domo.com/api/identity/v1/users/{str(user_obj.id)}"

    log_func(f"_______{body}")

    resp = edao_http.patch(api_url, inst_dev_token, log_func, body)
    
    log_func(f"____ END update_user({user_obj.name})")

    return True
        
# END def update_user

# =======================================================================
# UPDATE A USER PROFILE IMAGE
#      Functionality to update a user's profile image from one Domo instance to another.
#    
#      :param inst_url: The destination Domo instance URL prefix.
#      :param inst_dev_token: The destination Domo instance developer token.
#      :param log_func: Pre-bound logging function.

#      :param user_id: The destination Domo instance User ID.

#      :param src_inst_url: The source Domo instance URL prefix.
#      :param src_inst_dev_token: The source Domo instance developer token.
#      :param src_user_id: The source Domo instance User ID.

#      :returns: The string ID of the saved user, or None on failure.
# =======================================================================
def update_user_profile_image(inst_url: str, inst_dev_token: str, log_func: LogFunc, user_id: str, src_inst_url: str, src_inst_dev_token: str, src_user_id: str) -> Optional[str]:
    log_func(f"____ update_user_profile_image({user_id})")
    
    # Lazy imports to maintain modularity
    from . import edao_http
    import base64

    # 1. Get the source image bytes
    src_usr_img_url = f"https://{src_inst_url}.domo.com/api/content/v1/avatar/USER/{src_user_id}"
    src_usr_img_resp = edao_http.get(src_usr_img_url, src_inst_dev_token, log_func)

    # base64_utf8_str = base64.b64encode(src_usr_img_resp)
    # dataurl = '{"encodedImage": "data:image/png;base64,' + base64_utf8_str.decode() + '"}'
    # payload = dataurl
    
    # 2. Encode to Base64 and decode to string for the JSON value
    base64_str = base64.b64encode(src_usr_img_resp).decode('utf-8')
    # 3. Create a DICTIONARY, not a string
    payload = {"encodedImage": f"data:image/png;base64,{base64_str}"}

    api_url = f"https://{inst_url}.domo.com/api/content/v1/avatar/USER/{user_id}"

    # resp = edao_http.post(api_url, inst_dev_token, log_func, payload=data, req_content_type='application/x-www-form-urlencoded')       
    resp = edao_http.post(api_url, inst_dev_token, log_func, payload=payload, req_content_type='application/json')       
    
    log_func(f"____ END update_user_profile_image({user_id})")

    return True
        
# END def update_user_profile_image

# =======================================================================
# DELETES A USER BY ID
#     Stubs out functionality to delete a user.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param user_id: The string ID of the user to delete.
#     :param log_func: Pre-bound logging function.
#     :returns: True on success, False on failure.
# =======================================================================
def delete_user (inst_url: str, inst_dev_token: str, log_func: LogFunc, user_id: str, ) -> bool:

    log_func(f"____ delete_user({user_id})")

    # Lazy imports to maintain modularity
    from . import edao_http

    api_url = f"https://{inst_url}.domo.com/api/identity/v1/users/{str(user_id)}"

    resp = edao_http.delete(api_url, inst_dev_token, log_func)
    
    log_func(f"____ END delete_user({user_id})")
    
    return True
# END def delete_user


# =======================================================================
# PRIVATE API RETRIEVAL FUNCTIONS
# =======================================================================

# =======================================================================
# PRIVATE: RETRIEVES ALL USERS VIA PAGINATED SEARCH API
#     (PRIVATE) Searches and retrieves all users from an instance, including custom attributes 
#     from the provided SYNC_ATTRS map.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.

#     :returns: A list of raw user dictionaries.
# =======================================================================
def _get_instance_users_search (inst_url: str, inst_dev_token: str, log_func: LogFunc) -> List[Dict[str, Any]]:

    log_func(f'_______ _get_instance_users_search()')

    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http
    from . import domo_attributes

    sync_attrs = domo_attributes.get_instance_attributes (inst_url, inst_dev_token, log_func)
    
    # 1. Loop and filter: Add keys that do not start with "domo.policy"
    search_attributes = [
        attr_key for attr_key, attr_val in sync_attrs.items() 
        if not attr_key.startswith("domo.policy")
    ]   

    # --- Step 2: Paginate through users ---
                        
    api_url = f'https://{inst_url}.domo.com/api/identity/v1/users/search'    
    
    inst_user = []
    total = 100000
    offset = 0
    limit = 100
    
    while offset < total:

        body = {
            "showCount": False,
            "includeDeleted": True,
            "onlyDeleted": False,
            "includeSupport": True,
            "limit": limit,
            "offset": offset,
            "sort": {
                "field": "displayName",
                "order": "ASC"
            },
            "parts": [
                "DETAILED",
                "GROUPS",
                "ROLE"
            ],
            "attributes": search_attributes
        }
        
        resp = edao_http.post(api_url, inst_dev_token, log_func, body)
    
        # Update total count based on API response
        count = resp.get("count", 0)
        total = count
        page_users = resp.get("users", [])

        # Append users and increment offset
        inst_user.extend(page_users)
        offset = offset + limit
            
    # END while offset < total
    
    log_func(f'_______ END _get_instance_users_search()')

    return inst_user
# END def _get_instance_users_search


# =======================================================================
# PRIVATE: LOAD USER OBJECTS
#     (PRIVATE) Converts a json list to a List of User objects
# =======================================================================
def _load_user_objects(log_func: LogFunc, json_array: Any) -> List[Any]:
    """
    Parses a list of raw JSON objects into a list of domo_objects.User instances.
    Skips individual objects that fail to load.
    """
    
    loaded_objects = [] 
    
    # 1. Validate the input array
    if json_array is None:
        log_func("WARN: Input json_array is None. Returning empty list.")
        return []
        
    if not isinstance(json_array, list):
        msg = f"CRITICAL: Input json_array must be a list, got {type(json_array).__name__}."
        log_func(msg)
        raise TypeError(msg)

    # 2. Iterate through the array
    for i, json_item in enumerate(json_array):
        try:
            # 3. Load individual object
            # FIX: Changed from _load_role_object to _load_user_object
            obj = _load_user_object(log_func, json_item)
            
            loaded_objects.append(obj)
            
        except (ValueError, RuntimeError) as e:
            log_func(f"ERROR: Failed to load object at index {i}. Skipping. Details: {e}")
            continue
            
        except Exception as e:
            log_func(f"CRITICAL: Unexpected error loading object at index {i}: {e}")
            continue

    return loaded_objects
# END def _load_user_objects()

# =======================================================================
# PRIVATE: LOAD USER OBJECT
#     (PRIVATE) Converts a json obj to a User object
# =======================================================================
def _load_user_object(log_func: LogFunc, json: Any) -> Any:
    """
    Parses raw JSON into an domo_objects.User instance. 
    Raises an error if JSON is missing or if object creation fails.
    """
    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects

    # 1. Check if JSON is None or empty
    if not json:
        msg = "CRITICAL: Input JSON for _load_user_object is None or empty."
        log_func(msg)
        raise ValueError(msg)

    try:
        # --- FIX: LOGIC MOVED HERE FROM MAIN FUNCTION ---
        
        # Process Custom attributes into Dict[str, List[str]] format
        u_attrs_map: Dict[str, List[str]] = {}
        if "attributes" in json:
            u_attrs = json['attributes']            
            for a in u_attrs:
                key = a.get("key")
                values = a.get("values", [])
                if key: u_attrs_map[key] = values

        # Process Groups
        groups_list: List[str] = []
        if "groups" in json:
            for g in json['groups']:
                if g.get("name"): groups_list.append(g["name"])
        
        # 2. Attempt to create the User object
        return domo_objects.User(
            id=str(json.get('id', '')),
            name=json.get('emailAddress', ''),
            type='USER',
            
            email_address=json.get('emailAddress', ''),
            display_name=json.get('displayName'), 
            user_name=json.get('userName'),
            role_id=str(json.get('roleId')),
            last_activity=json.get('lastActivity'),
            groups=groups_list,      # Now defined
            attributes=u_attrs_map   # Now defined
        )    
    
    except Exception as e:
        msg = f"CRITICAL: Failed to instantiate domo_objects.User. Error: {e}"
        log_func(msg)
        raise RuntimeError(msg) from e
        
# END def _load_user_object()