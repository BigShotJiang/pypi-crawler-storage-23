# randstadenterprise_edao_libraries/domo_attributes.py
import requests
import threading
from typing import List, Dict, Any, Optional, Callable
from concurrent.futures import ThreadPoolExecutor, as_completed

# Define the type for the log function
LogFunc = Callable[[str], None] 
# Define the type for the print_response function (passed as an argument)
PrintResponseFunc = Callable[[str, str, requests.Response], None]
# Type for a map of attributes (key -> attribute details)
AttrMap = Dict[str, Dict[str, Any]]

# =======================================================================
# FETCHES ALL USER ATTRIBUTES AND MAPS THEM BY KEY
#     Fetches all instance user attributes and returns them mapped by attribute key.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param lock: The threading.Lock object (for logging).
#     :param logs_array: The shared log array.
#     :returns: Dictionary mapping attribute key (str) to attribute details.
# =======================================================================
def get_instance_attributes (inst_url: str, inst_dev_token: str, log_func: LogFunc) -> AttrMap:
    
    log_func(f'____________________ get_all_instance_user_attributes({inst_url})')
    
    inst_attrs_map = {}
    
    # 1. Call the private API function to get raw attributes
    inst_attrs = _get_instance_attributes(inst_url, inst_dev_token, log_func)
    
    # 2. Map attributes by their full key
    for a in inst_attrs:
        # START for a in inst_attrs
        full_key = a['key']
        inst_attrs_map[full_key] = a
        # END for a in inst_attrs
    
    log_func('____________________ END get_all_instance_user_attributes()')

    return inst_attrs_map
# END def get_all_instance_user_attributes

# =======================================================================
# PRIVATE: RETRIEVES A LIST OF RAW USER ATTRIBUTE METADATA KEYS
#     (PRIVATE) Retrieves a list of all raw user attribute metadata keys (properties) from a Domo instance.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :returns: A list of raw attribute metadata dictionaries.
# =======================================================================
def _get_instance_attributes (inst_url: str, inst_dev_token: str, log_func: LogFunc) -> List[Dict[str, Any]]:

    log_func(f'_______ _get_instance_attributes({inst_url})')
    
    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http

    api_url = f'https://{inst_url}.domo.com/api/user/v1/properties/meta/keys?issuerTypes=idp,domo-defined,customer-defined'
    
    # 1. Make API request
    attrs_res = edao_http.get(api_url, inst_dev_token, log_func)

    log_func('_______ END _get_instance_attributes()')

    return attrs_res
    
# END def _get_instance_attributes

############################
# CREATE ATTRIBUTE
############################
# def save_attribute(inst_name, inst_url, inst_dev_token, attr, log_func):

#     # FIXED: Argument order (inst_url, msg)
#     log_func('_________________________ save_attribute(' + inst_name + ', ' + inst_url + ')')
    
#     url = "https://" + inst_url + '.domo.com' + "/api/user/v1/properties/meta/keys/" + str(attr["key"])
#     body = {
#                     "keyspace":"customer-defined",
#                     "key":attr["key"],
#                     "securityVoter":"FULL_VIS_ADMIN_IDP",
#                     "validator":attr["validator"],
#                     "title":attr["name"],
#                     "valueType":attr["valueType"],
#                     "description":attr["desc"]
#                 }
    
#     headers = helpers.get_http_headers(inst_dev_token)

#     resp = requests.post(url, headers=headers, json=body)
    
#     if resp.status_code == 200:
#         # FIXED: Argument order (inst_url, msg)
#         log_func(inst_url, f"______________________________ Successfully created Attribute: {str(attr["key"])}")
#     else:
#         log_func(inst_url, f"______________________________ Failed to create Attribute: {str(attr["key"])} : {str(resp)} : {str(resp.reason)}")
    
#     # FIXED: Argument order (inst_url, msg)
#     log_func(inst_url, '_________________________ END createAttribute()')
# END def create_attribute(self, dest_inst_name, dest_inst_url, dest_inst_devtok, attr):


def save_user_attribute (inst_url: str, inst_dev_token: str, attribute_obj: Dict[str, Any], log_func: LogFunc) -> Optional[str]:
# =======================================================================
# SAVES (CREATES OR UPDATES) A USER ATTRIBUTE
# =======================================================================
    # START def save_user_attribute
    """
    Stubs out functionality to create or update a user attribute.
    
    :param inst_url: The Domo instance URL prefix.
    :param inst_dev_token: The developer token.
    :param attribute_obj: The Attribute object (dictionary) to be saved.
    :param log_func: Pre-bound logging function.
    :returns: The key (string) of the saved attribute, or None on failure.
    """
    print(f"STUB: Saving user attribute {attribute_obj.get('key')} to {inst_url}")
    return attribute_obj.get('key')
# END def save_user_attribute
