# randstadenterprise_edao_libraries/domo_pages.py
from typing import List, Dict, Any, Optional, Callable, Union

# Define the type for the log function for clean type hinting
LogFunc = Callable[[str], None] 

# =======================================================================
# CORE API RETRIEVAL FUNCTIONS (GET_ALL)
# =======================================================================

# =======================================================================
#     Retrieves ALL pages from a Domo instance by handling full pagination.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :returns: A single list containing all raw asset dictionary objects.
# =======================================================================
def get_instance_pages (inst_url: str, inst_dev_token: str, log_func: LogFunc) -> List[Any]:

    log_func(f'____ get_instance_pages({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects     
    
    all_pages: List[domo_objects.Page] = [] 
    
    pages_results = _get_instance_pages (inst_url, inst_dev_token, log_func)
    all_pages = _load_page_objects(log_func, pages_results)

    log_func(f"____ END get_instance_pages: {inst_url}")
    
    return all_pages

# END def get_instance_assets

# =======================================================================
#     Retrieves a page by id
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param page_id: The exact id of the page to find.

#     :returns: A single asset object.
# =======================================================================
def get_page_by_id (inst_url: str, inst_dev_token: str, log_func: LogFunc, page_id: str) -> Any:

    log_func(f'____ get_page_by_id({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http 
    
    api_url = f"https://{inst_url}.domo.com/api/content/v1/pages/{page_id}"

    resp = edao_http.get(api_url, inst_dev_token, log_func)
    page_name = resp.get("title", None)
    
    page_object = get_page_by_name (inst_url, inst_dev_token, log_func, page_name)
        
    log_func(f"____ END get_page_by_id: {inst_url}")
    
    return page_object

# END def get_page_by_id

# =======================================================================
#     Retrieves a page by name and only returns the first page with that name
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.

#     :param asset_id: The exact id of the asset to find.

#     :returns: A single asset object.
# =======================================================================
def get_page_by_name (inst_url: str, inst_dev_token: str, log_func: LogFunc, page_name: str) -> Any:

    log_func(f'____ get_page_by_name({inst_url})')

    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http 
    
    body = {"includePageTitleClause":True,"pageTitleSearchText":page_name,"orderBy":"pageTitle","ascending":True}
    api_url = f'https://{inst_url}.domo.com/api/content/v1/pages/adminsummary?limit=1&skip=0'

    resp = edao_http.post(api_url, inst_dev_token, log_func, body)

    pages_resp = resp.get("pageAdminSummaries", [])
    
    page_object = None
    if len(pages_resp) > 0:
        page_object = _load_page_object(log_func, pages_resp[0])
    # END if len(pages_resp) > 0:
        
    log_func(f"____ END get_page_by_name: {inst_url}")
    
    return page_object

# END def get_asset_by_id

# =======================================================================
    # Updates the ADMIN permissions (owners) for a specific Domo App Asset.
    # Safeguard: Ensures the current owner is included in the new owners list to prevent lockout.
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param asset_id: The exact id of the asset to find.
#     :param owners: A list of user id strings to add as owners
#     :returns: The string ID of the promoted repository, or None on failure.
# =======================================================================
# def set_asset_owners(inst_url: str, inst_dev_token: str, log_func: LogFunc, asset_id: str, owners: List[str]) -> Optional[str]:

#     log_func(f'____ set_asset_owners({inst_url}, Asset ID: {asset_id})')  
    
#     # ADD IMPORT HERE (Lazy Import)
#     from . import edao_http     
    
#     # 1. Fetch current asset to verify the current owner
#     asset = get_asset_by_id(inst_url, inst_dev_token, log_func, asset_id)
    
#     # Validation: Ensure the current owner is not being removed
#     # Assuming asset.owner returns the owner's User ID string
#     asset_owner_id = str(asset.owner)
    
#     ext_asset_owners = asset.owners
#     ext_owner_ids = []
#     # 2. Remove all additional owners
#     for ext_owner in ext_asset_owners:
#         remove_owner_id = str(ext_owner["id"])
#         if str(asset_owner_id) != remove_owner_id:
#             ext_owner_ids.append(remove_owner_id)
#         # END if asset_owner_id != remove_owner_id:
#     # END for ext_owner in ext_asset_owners:
#     remove_asset_owners (inst_url, inst_dev_token, log_func, asset_id, ext_owner_ids)
    
#     # 3. Set all the provided owners
#     # The API expects a list of User IDs as the body
#     owners.append(asset_owner_id)    
#     body = owners
#     api_url = f"https://{inst_url}.domo.com/api/apps/v1/designs/{asset_id}/permissions/ADMIN"
#     resp = edao_http.post(api_url, inst_dev_token, log_func, body)
        
#     log_func(f"____ END set_asset_owners: {inst_url}")
    
#     return "SUCCESS"

# # END def set_asset_owners

# =======================================================================
#     Add Asset Owners
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param asset_id: The exact id of the asset to find.
#     :param owner_ids: List of user id to add as owners
#     :returns: The string ID of the promoted repository, or None on failure.
# =======================================================================
# def add_asset_owners (inst_url: str, inst_dev_token: str, log_func: LogFunc, asset_id: str, owner_ids:List[str]) -> Optional[str]:

#     log_func(f'____ add_asset_owner({inst_url})')  

#     # ADD IMPORT HERE (Lazy Import)
#     from . import edao_http 
    
#     body = owner_ids
#     api_url = f"https://{inst_url}.domo.com/api/apps/v1/designs/{asset_id}/permissions/ADMIN"
    
#     resp = edao_http.post(api_url, inst_dev_token, log_func, body)
        
#     log_func(f"____ END add_asset_owner: {inst_url}")
    
#     return "SUCCESS"

# # END def add_asset_owner

# =======================================================================
#     Remove Asset Owner
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param asset_id: The exact id of the asset to find.
#     :param owner_ids: List of user id to remove as owners
#     :returns: The string ID of the promoted repository, or None on failure.
# =======================================================================
# def remove_asset_owners (inst_url: str, inst_dev_token: str, log_func: LogFunc, asset_id: str, owner_ids:List[str]) -> Optional[str]:

#     log_func(f'____ remove_asset_owner({inst_url})') 
    
#     # ADD IMPORT HERE (Lazy Import)
#     from . import edao_http 
    
#     asset = get_asset_by_id(inst_url, inst_dev_token, log_func, asset_id)
#     asset_owner_id = str(asset.owner)

#     for owner_id in owner_ids:
#         if asset_owner_id != owner_id:
#             api_url = f"https://{inst_url}.domo.com/domoapps/designs/{asset_id}/permissions/ADMIN/ids?users={owner_id}"
#             resp = edao_http.delete(api_url, inst_dev_token, log_func)
#         # END if asset_owner_id != remove_owner_id:
#     # END for ext_owner in ext_asset_owners:
            
#     log_func(f"____ END remove_asset_owner: {inst_url}")
    
#     return "SUCCESS"  

# # END def remove_asset_owner

# =======================================================================
# =======================================================================
# =======================================================================
# =======================================================================
# =======================================================================
# =======================================================================

# =======================================================================
# PRIVATE: LOAD PAGE OBJECTS
#     (PRIVATE) Retrieves a single page of datasets using the PyDomo SDK.
    
#     :param datasets_json: json array of dataset data
#     :param log_func: Pre-bound logging function.
#     :returns: A list of dataset dictionary objects.
# =======================================================================
def _load_page_objects(log_func: LogFunc, json_array: Any) -> List[Any]:
    """
    Parses a list of raw JSON objects into a list of domo_objects.Asset instances.
    Skips individual objects that fail to load.
    """
    
    loaded_objects = [] # Renamed from 'objects' to avoid shadowing the module name
    
    # 1. Validate the input array
    if json_array is None:
        log_func("WARN: Input json_array is None. Returning empty list.")
        return []
        
    if not isinstance(json_array, list):
        msg = f"CRITICAL: Input json_array must be a list, got {type(json_array).__name__}."
        log_func(msg)
        raise TypeError(msg)

    # 2. Iterate through the array
    for i, json_item in enumerate(json_array):
        try:
            # 3. Load individual object
            obj = _load_page_object(log_func, json_item)
            
            # Use .append() for Python lists (not .add)
            loaded_objects.append(obj)
            
        except (ValueError, RuntimeError) as e:
            # 4. Handle known errors from the single object loader
            log_func(f"ERROR: Failed to load object at index {i}. Skipping. Details: {e}")
            continue
            
        except Exception as e:
            # 5. Handle unexpected errors
            log_func(f"CRITICAL: Unexpected error loading object at index {i}: {e}")
            continue

    return loaded_objects
# END def _load_page_objects

# =======================================================================
# PRIVATE: LOAD PAGE OBJECT
#     (PRIVATE) Retrieves a single page of datasets using the PyDomo SDK.
    
#     :param json: json of dataset data
#     :param log_func: Pre-bound logging function.
#     :returns: A list of dataset dictionary objects.
# =======================================================================
def _load_page_object(log_func: LogFunc, json: Any) -> Any:
    """
    Parses raw JSON into an domo_objects.Asset instance. 
    Raises an error if JSON is missing or if object creation fails.
    """

    # ADD IMPORT HERE (Lazy Import)
    from . import domo_objects 
    
    # 1. Check if JSON is None or empty
    if not json:
        msg = "CRITICAL: Input JSON for _load_page_object is None or empty."
        log_func(msg)
        raise ValueError(msg)

    try:
        # 2. Attempt to create the Asset object
        return domo_objects.Page (
            
            page_id=json.get('pageId', ''),
            page_title=json.get('pageTitle', ''),
            page_type=json.get('pageType', ''),
            sub_type=json.get('subType', ''),
            parent_page_id=json.get('parentPageId', ''),
            parent_page_title=json.get('parentPageTitle', ''),
            top_page_id=json.get('topPageId', ''),
            top_page_title=json.get('topPageTitle', ''),
            owner_id=json.get('ownerId', ''),
            owner_name=json.get('ownerName', ''),
            owners=json.get('owners', {}),
            locked=json.get('locked', True),
            last_modified=json.get('lastModified', ''),
            card_count=json.get('cardCount', ''),
            data_app_id=json.get('dataAppId', ''),
            data_app_title=json.get('dataAppTitle', '')
        )       
    
    except Exception as e:
        # 3. Catch and re-raise errors during object creation
        msg = f"CRITICAL: Failed to instantiate domo_objects.Page. Error: {e}"
        log_func(msg)
        # Re-raise as a runtime error so the calling script knows it failed
        raise RuntimeError(msg) from e
        
# END def _load_asset_object(log_func: LogFunc, json: Any) -> Any:    


# =======================================================================
# =======================================================================
# =======================================================================
# PRIVATE API HELPER FUNCTIONS
# =======================================================================
# =======================================================================
# =======================================================================

# =======================================================================
# (PRIVATE HELPER) Fetches a single paginated result of pages.
#     Used by get_instance_pages
    
#     :param inst_url: The Domo instance URL prefix.
#     :param inst_dev_token: The developer token.
#     :param log_func: Pre-bound logging function.
#     :param offset: The starting index for pagination.
#     :param limit: The number of results to return.
#     :returns: The raw JSON response dictionary containing 'pages' or an empty dict on error.
# =======================================================================
def _get_instance_pages (inst_url: str, inst_dev_token: str, log_func: LogFunc) -> Any:

    log_func(f'_______ _get_instance_pages({str(inst_url)}')

    # ADD IMPORT HERE (Lazy Import)
    from . import edao_http
    
    inst_pages = []
    
    total = 100000
    offset = 0
    limit = 60
    
    body = {"orderBy":"pageTitle","ascending":True}

    while offset <= total:
        
        api_url = f'https://{inst_url}.domo.com/api/content/v1/pages/adminsummary?limit={limit}&skip={offset}'
        
        resp = edao_http.post(api_url, inst_dev_token, log_func, body)
    
        # Update offset and total count based on API response
        offset = resp.get("nextOffset", 0)
        total = resp.get("totalPageCount", 0)

        # Append pages
        pages_page = resp.get("pageAdminSummaries", [])
        inst_pages.extend(pages_page)
            
    # END while offset < total     
        
    log_func(f'_______ _get_instance_pages({str(inst_url)}')

    return inst_pages
# END def _get_instance_pages_page