# randstadenterprise_edao_libraries/http.py
import requests # <-- ADD THIS IMPORT
import json
from typing import Dict, Any, List, Optional, Callable

# Define custom types needed for function signatures
LogFunc = Callable[[str], None]

DefaultReqContentType = 'application/json;charset=utf-8'

# In http.py
class DomoAPIError(Exception):
    """Custom exception raised for failed Domo API calls."""
    pass

# ... rest of http.py ...


# =======================================================================
# GENERATES STANDARD DOMO API HEADERS
#     Generates the standard HTTP headers required for Domo's private APIs.
    
#     :param inst_dev_token: The developer token for 'X-DOMO-Developer-Token'.
#     :returns: Dictionary of standard HTTP headers.
# =======================================================================
def get_http_headers (inst_dev_token: str, req_content_type: str = DefaultReqContentType) -> Dict[str, str]:
    header = {
        'X-DOMO-Developer-Token': inst_dev_token,
        # 'X-DOMO-Authentication': 'null', 
        'Content-Type': req_content_type,
        'Accept': 'application/json, text/plain, */*',
    }

    # print(f'______ header {str(header)}')

    return header
# END def get_http_headers

############################
# GET
############################
def get(api_url: str, inst_dev_token: str, log_func: LogFunc) -> Any:

    log_func(f'      >>>>>> get URL {api_url}')
    
    try:
        # Assuming you've fixed this to use json=body for Domo API calls
        resp = requests.get(api_url, headers=get_http_headers(inst_dev_token), timeout=30)
        
        # Check status and raise HTTPError if 4xx or 5xx
        resp.raise_for_status() 

        result = _handle_response(resp, log_func)
        
        return result
    # END try:
    except requests.exceptions.HTTPError as e:
        # 1. Try to read the JSON error body from the response object within the exception
        try:
            error_details = e.response.json()
            
            # 2. Extract the specific message field
            domo_message = error_details.get("message", "No specific error message found in response body.")
            
            # 3. Log the extracted message
            log_func(f"ERROR: Domo API responded with 400 Bad Request. Message: {domo_message}")
            
            # You can now reraise a new exception with the custom message if needed
            raise DomoAPIError(f"API Failed: {domo_message}") from e
        # END try:            
        except requests.exceptions.JSONDecodeError:
            # If the response body wasn't JSON (e.g., HTML or plain text)
            log_func(f"ERROR: HTTPError {e.response.status_code}. Response was not JSON.")
            raise e # Reraise the original HTTPError
        # END except requests.exceptions.JSONDecodeError:
    # END except requests.exceptions.HTTPError as e:
    except requests.exceptions.RequestException as e:
        # Handle general connection/timeout errors
        log_func(f"ERROR: Request failed: {e}")
        raise e
    # END except requests.exceptions.RequestException as e:

# END get():

############################
# POST
############################
def post(api_url: str, inst_dev_token: str, log_func: LogFunc, payload: Any, req_content_type: str = DefaultReqContentType) -> Any:

    log_func(f'      >>>>>> post URL {api_url}')
    
    try:
        
        resp = {}
        if '/json' in req_content_type:
            resp = requests.post(api_url, headers=get_http_headers(inst_dev_token, req_content_type), json=payload, timeout=30)
            resp.raise_for_status() 
        else:    
            resp = requests.post(api_url, headers=get_http_headers(inst_dev_token, req_content_type), data=payload, timeout=30)
            resp.raise_for_status() 
        
        result = _handle_response(resp, log_func)
                
        return result
    
    except requests.exceptions.HTTPError as e:
        # 1. Try to read the JSON error body from the response object within the exception
        try:
            error_details = e.response.json()
            
            # 2. Extract the specific message field
            domo_message = error_details.get("message", "No specific error message found in response body.")
            
            # 3. Log the extracted message
            log_func(f"ERROR: Domo API responded with 400 Bad Request. Message: {domo_message}")
            
            # You can now reraise a new exception with the custom message if needed
            raise DomoAPIError(f"API Failed: {domo_message}") from e
        # END try:            
        except requests.exceptions.JSONDecodeError:
            # If the response body wasn't JSON (e.g., HTML or plain text)
            log_func(f"ERROR: HTTPError {e.response.status_code}. Response was not JSON.")
            raise e # Reraise the original HTTPError
        # END except requests.exceptions.JSONDecodeError:
    # END except requests.exceptions.HTTPError as e:
    except requests.exceptions.RequestException as e:
        # Handle general connection/timeout errors
        log_func(f"ERROR: Request failed: {e}")
        raise e
    # END except requests.exceptions.RequestException as e:

# END post():

############################
# PUT
############################
def put(api_url: str, inst_dev_token: str, log_func: LogFunc, payload: Any, req_content_type: str = DefaultReqContentType) -> Any:

    log_func(f'      >>>>>> put URL {api_url}')
    
    try:
        
        resp = {}
        if '/json' in req_content_type:
            resp = requests.put(api_url, headers=get_http_headers(inst_dev_token, req_content_type), json=payload, timeout=30)
            resp.raise_for_status() 
        else:    
            resp = requests.put(api_url, headers=get_http_headers(inst_dev_token, req_content_type), data=payload, timeout=30)
            resp.raise_for_status() 

        result = _handle_response(resp, log_func)
        
        return result
    
    # END try:
    except requests.exceptions.HTTPError as e:
        # 1. Try to read the JSON error body from the response object within the exception
        try:
            error_details = e.response.json()
            
            # 2. Extract the specific message field
            domo_message = error_details.get("message", "No specific error message found in response body.")
            
            # 3. Log the extracted message
            log_func(f"ERROR: Domo API responded with 400 Bad Request. Message: {domo_message}")
            
            # You can now reraise a new exception with the custom message if needed
            raise DomoAPIError(f"API Failed: {domo_message}") from e
        # END try:            
        except requests.exceptions.JSONDecodeError:
            # If the response body wasn't JSON (e.g., HTML or plain text)
            log_func(f"ERROR: HTTPError {e.response.status_code}. Response was not JSON.")
            raise e # Reraise the original HTTPError
        # END except requests.exceptions.JSONDecodeError:
    # END except requests.exceptions.HTTPError as e:
    except requests.exceptions.RequestException as e:
        # Handle general connection/timeout errors
        log_func(f"ERROR: Request failed: {e}")
        raise e
    # END except requests.exceptions.RequestException as e:

# END put():


############################
# PATCH
############################
def patch(api_url: str, inst_dev_token: str, log_func: LogFunc, payload: Any, req_content_type: str = DefaultReqContentType) -> Any:

    log_func(f'      >>>>>> patch URL {api_url}')
    
    try:
              
        resp = {}
        if '/json' in req_content_type:
            resp = requests.patch(api_url, headers=get_http_headers(inst_dev_token, req_content_type), json=payload, timeout=30)
            resp.raise_for_status() 
        else:    
            resp = requests.patch(api_url, headers=get_http_headers(inst_dev_token, req_content_type), data=payload, timeout=30)
            resp.raise_for_status() 
        
        result = _handle_response(resp, log_func)
        
        return result

    except requests.exceptions.HTTPError as e:
        # 1. Try to read the JSON error body from the response object within the exception
        try:
            error_details = e.response.json()
            
            # 2. Extract the specific message field
            domo_message = error_details.get("message", "No specific error message found in response body.")
            
            # 3. Log the extracted message
            log_func(f"ERROR: Domo API responded with 400 Bad Request. Message: {domo_message}")
            
            # You can now reraise a new exception with the custom message if needed
            raise DomoAPIError(f"API Failed: {domo_message}") from e
        # END try:            
        except requests.exceptions.JSONDecodeError:
            # If the response body wasn't JSON (e.g., HTML or plain text)
            log_func(f"ERROR: HTTPError {e.response.status_code}. Response was not JSON.")
            raise e # Reraise the original HTTPError
        # END except requests.exceptions.JSONDecodeError:
    # END except requests.exceptions.HTTPError as e:
    except requests.exceptions.RequestException as e:
        # Handle general connection/timeout errors
        log_func(f"ERROR: Request failed: {e}")
        raise e
    # END except requests.exceptions.RequestException as e:

# END patch():

############################
# DELETE
############################
def delete(api_url: str, inst_dev_token: str, log_func: LogFunc) -> Any:

    log_func(f'      >>>>>> delete URL {api_url}')
    
    try:
        # Assuming you've fixed this to use json=body for Domo API calls
        resp = requests.delete(api_url, headers=get_http_headers(inst_dev_token), timeout=30)
        
        # Check status and raise HTTPError if 4xx or 5xx
        resp.raise_for_status() 
        
        result = _handle_response(resp, log_func)

        return result 
    
    # END try:
    except requests.exceptions.HTTPError as e:
        # 1. Try to read the JSON error body from the response object within the exception
        try:
            error_details = e.response.json()
            
            # 2. Extract the specific message field
            domo_message = error_details.get("message", "No specific error message found in response body.")
            
            # 3. Log the extracted message
            log_func(f"ERROR: Domo API responded with 400 Bad Request. Message: {domo_message}")
            
            # You can now reraise a new exception with the custom message if needed
            raise DomoAPIError(f"API Failed: {domo_message}") from e
        # END try:            
        except requests.exceptions.JSONDecodeError:
            # If the response body wasn't JSON (e.g., HTML or plain text)
            log_func(f"ERROR: HTTPError {e.response.status_code}. Response was not JSON.")
            raise e # Reraise the original HTTPError
        # END except requests.exceptions.JSONDecodeError:
    # END except requests.exceptions.HTTPError as e:
    except requests.exceptions.RequestException as e:
        # Handle general connection/timeout errors
        log_func(f"ERROR: Request failed: {e}")
        raise e
    # END except requests.exceptions.RequestException as e:

# END delete():

############################
# HANDLE RESPONSE
############################
def _handle_response(resp: any, log_func: LogFunc):
    
    # log_func(f"______ _handle_response resp:{resp} | status_code:{resp.status_code}")
    result = {} 
    # Check for 204 No Content or completely empty body
    if resp.status_code == 204 or not resp.text or not resp.text.strip():
        log_func("______ Response successful but body is empty.")
        result = {}
    # END if resp.status_code == 204 or not resp.text or not resp.text.strip():
    else:
         # Capture actual header from server to cross-reference
        actual_content_type = resp.headers.get('Content-Type', '').lower()
        # log_func(f"______ _handle_response actual_content_type:{actual_content_type}")

        if 'application/json' in actual_content_type:
            try:
                result = resp.json()
            except requests.exceptions.JSONDecodeError:
                log_func("______ WARN: Expected JSON but failed to decode. Returning raw text.")
                result = resp.text.strip()        
        # END if 'application/json' in actual_content_type:
        elif 'text/' in actual_content_type:
            result = resp.text.strip()
        # END elif 'text/' in actual_content_type:
        else:
            # For images or binary data
            result = resp.content
    # END else

    # log_func(f"______ _handle_response result:{result}")
    return result
# END def _handle_respose(resp: any):
