import subprocess


def generate_ai_response(prompt):
    try:
        result = subprocess.run(
            ["gh", "copilot", "-p", prompt],
            capture_output=True,
            text=True
        )

        if result.returncode != 0:
            return f"Copilot Error:\n{result.stderr}"

        return result.stdout.strip()

    except Exception as e:
        return f"Error running Copilot: {e}"
