"""TabMind - Smart Tab Manager with AI assistance"""

__version__ = "0.1.0"
__author__ = "Your Name"
__description__ = "A CLI tool to manage browser tabs and generate AI prompts"

from .storage import add_tab, get_tabs, load_tabs, save_tabs
from .ai_helper import generate_ai_response

__all__ = [
    "add_tab",
    "get_tabs",
    "load_tabs",
    "save_tabs",
    "generate_ai_response",
]
