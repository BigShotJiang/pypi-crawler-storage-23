import click
from .storage import add_tab, get_tabs, mark_tab_done, set_due_date, get_stats
from .ai_helper import generate_ai_response


@click.group()
def cli():
    """TabMind CLI - Smart Tab Manager"""
    pass


@cli.command()
@click.argument("url")
@click.option("--due-date", "-d", help="Due date (YYYY-MM-DD)")
def add(url, due_date):
    """Add a new tab with optional due date"""
    reason = click.prompt("Why did you open this link?")
    add_tab(url, reason, due_date=due_date)
    click.echo("✓ Tab saved successfully!")


@cli.command()
def review():
    """Review all saved tabs"""
    tabs = get_tabs()

    if not tabs:
        click.echo("No tabs saved.")
        return

    for i, tab in enumerate(tabs, start=1):
        status = "✓ Done" if tab.get("completed", False) else "⏳ Pending"
        due = f" | Due: {tab.get('due_date', 'N/A')}" if tab.get("due_date") else ""
        
        click.echo(f"\n[{i}] {status}{due}")
        click.echo(f"    Title: {tab.get('title', 'Untitled')}")
        click.echo(f"    URL: {tab['url']}")
        click.echo(f"    Reason: {tab['reason']}")
        click.echo(f"    Added: {tab['date_added']}")


@cli.command()
@click.argument("tab_number", type=int)
def mark_done(tab_number):
    """Mark a tab as completed"""
    if mark_tab_done(tab_number - 1):
        click.echo(f"✓ Tab {tab_number} marked as done!")
    else:
        click.echo(f"✗ Invalid tab number: {tab_number}")


@cli.command()
@click.argument("tab_number", type=int)
@click.argument("due_date")
def due_date(tab_number, due_date):
    """Set a due date for a tab (format: YYYY-MM-DD)"""
    if set_due_date(tab_number - 1, due_date):
        click.echo(f"✓ Due date for Tab {tab_number} set to {due_date}")
    else:
        click.echo(f"✗ Invalid tab number: {tab_number}")


@cli.command()
def stats():
    """Show statistics about your tabs"""
    stats_data = get_stats()
    
    click.echo("\n📊 TabMind Statistics")
    click.echo("=" * 40)
    click.echo(f"Total Tabs:      {stats_data['total']}")
    click.echo(f"Completed:       {stats_data['completed']} ✓")
    click.echo(f"Pending:         {stats_data['pending']} ⏳")
    click.echo(f"With Due Date:   {stats_data['with_due_date']} 📅")
    click.echo("=" * 40)


@cli.command()
def ai_prompt():
    """Generate Copilot prompt for manual execution"""
    tabs = get_tabs()

    if not tabs:
        click.echo("No tabs saved.")
        return

    for i, tab in enumerate(tabs, start=1):
        if tab.get("completed", False):
            continue
            
        prompt = f"""
You are a productivity assistant.

The user saved this link:
URL: {tab['url']}
Title: {tab.get('title', 'Untitled')}
Reason: {tab['reason']}
Date Added: {tab['date_added']}
Due Date: {tab.get('due_date', 'No deadline')}

Write a short motivational reminder asking if they want to continue this task.
Keep it under 3 lines."""

        click.echo("\n-----------------------------------")
        click.echo(f"Tab {i}: {tab.get('title', 'Untitled')}")

        click.echo("Run this command in your terminal:")
        click.echo(f'\ngh copilot -p "{prompt.strip()}"')
        click.echo("-----------------------------------\n")


if __name__ == "__main__":
    cli()
