# AppWire SDK

Build and push **Taps** to [AppWire](https://appwire.dev) — reverse-engineered mobile app API wrappers for workflow automation.

A **Tap** wraps a mobile app's internal API into reusable actions. Each action maps to an HTTP endpoint with headers, params, and response mappings.

## Install

```bash
pip install appwire
```

## Quick Start

```python
from appwire import Tap

tap = Tap(
    name="TikTok Profile Scraper",
    app="TikTok",
    version="1.0.0",
    description="Fetch profile data from TikTok's internal API",
)

@tap.action(
    name="Get Profile",
    method="GET",
    endpoint="https://api.tiktok.com/api/user/detail",
)
def get_profile(username: str):
    return {
        "params": {"uniqueId": username},
        "headers": {
            "User-Agent": "TikTok/26.1.3",
        },
    }
```

## CLI

```bash
appwire login              # Authenticate
appwire init my-tap        # Scaffold a new Tap project
appwire validate           # Validate before pushing
appwire push               # Push to AppWire
appwire list               # List your published Taps
```

## Tap Manifest

Every Tap has a `tap.yaml` manifest:

```yaml
name: "TikTok Profile Scraper"
description: "Fetch profile data from TikTok"
version: "1.0.0"
app: "TikTok"
icon: "./icon.png"
entry: "main.py"
```

## Credentials

Reference user credentials with `{{credential:name}}` placeholders:

```python
tap = Tap(
    name="My Tap",
    app="MyApp",
    version="1.0.0",
    credentials=[
        {"name": "session_id", "label": "Session ID", "required": True},
    ],
)

@tap.action(name="Get Data", method="GET", endpoint="/api/data")
def get_data():
    return {
        "headers": {
            "Cookie": "sid={{credential:session_id}}",
        },
    }
```

## Response Mapping

Extract fields from API responses using JSONPath:

```python
@tap.action(
    name="Get Profile",
    method="GET",
    endpoint="/api/user/detail",
    response_mapping={
        "username": "$.userInfo.user.uniqueId",
        "followers": "$.userInfo.stats.followerCount",
    },
)
def get_profile(username: str):
    return {"params": {"uniqueId": username}}
```

## License

MIT
