import argparse
import json
import os
import sys
import getpass
from pathlib import Path

CONFIG_DIR = Path.home() / ".appwire"
TOKEN_FILE = CONFIG_DIR / "token"
DEFAULT_BASE_URL = "https://appwire.dev"

TAP_YAML_TEMPLATE = '''name: "{name}"
description: "A new AppWire Tap"
version: "1.0.0"
app: "{name}"
icon: "./icon.png"

author:
  name: "{author}"
  email: ""

tags: []

entry: "main.py"
'''

MAIN_PY_TEMPLATE = '''from appwire import Tap

tap = Tap(
    name="{name}",
    app="{name}",
    version="1.0.0",
    description="A new AppWire Tap",
)

@tap.action(
    name="Example Action",
    method="GET",
    endpoint="https://api.example.com/v1/data",
    description="An example action — replace with a real endpoint",
)
def example_action(query: str):
    return {{
        "params": {{"q": query}},
        "headers": {{
            "User-Agent": "MyApp/1.0",
        }},
    }}
'''

README_TEMPLATE = '''# {name}

An AppWire Tap.

## Setup

```bash
pip install appwire
appwire login
```

## Push

```bash
appwire validate
appwire push
```
'''


def cmd_login(args):
    if TOKEN_FILE.exists() and TOKEN_FILE.read_text().strip():
        existing_key = TOKEN_FILE.read_text().strip()
        masked = f"{existing_key[:6]}{'•' * 20}{existing_key[-4:]}"
        print(f"Already logged in with key: {masked}")
        print()
        try:
            answer = input("Replace with a new key? [y/N] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if answer not in ("y", "yes"):
            print("Keeping existing key.")
            return
        print()

    print("Login to AppWire")
    print(f"Get your API key from the Developer Portal: {DEFAULT_BASE_URL}/developers\n")
    api_key = getpass.getpass("API Key: ")
    if not api_key.strip():
        print("Error: API key cannot be empty.")
        sys.exit(1)
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    TOKEN_FILE.write_text(api_key.strip())
    TOKEN_FILE.chmod(0o600)
    print("✓ Logged in successfully. Token saved to ~/.appwire/token")


def cmd_init(args):
    name = args.name
    project_dir = Path(name)

    if project_dir.exists():
        print(f"Error: Directory '{name}' already exists.")
        sys.exit(1)

    project_dir.mkdir(parents=True)
    author = os.environ.get("USER", "developer")

    (project_dir / "tap.yaml").write_text(TAP_YAML_TEMPLATE.format(name=name, author=author))
    (project_dir / "main.py").write_text(MAIN_PY_TEMPLATE.format(name=name))
    (project_dir / "README.md").write_text(README_TEMPLATE.format(name=name))

    icon_placeholder = project_dir / "icon.png"
    icon_placeholder.write_bytes(b"")

    print(f"✓ Created new Tap project: {name}/")
    print(f"  tap.yaml          <- manifest")
    print(f"  main.py           <- action definitions")
    print(f"  icon.png          <- placeholder icon")
    print(f"  README.md")
    print(f"\nNext steps:")
    print(f"  cd {name}")
    print(f"  # Edit tap.yaml and main.py")
    print(f"  appwire validate")
    print(f"  appwire push")


def cmd_validate(args):
    tap_yaml = Path("tap.yaml")
    main_py = Path("main.py")

    if not tap_yaml.exists():
        print("Error: tap.yaml not found. Are you in a Tap project directory?")
        sys.exit(1)

    try:
        import yaml
        manifest = yaml.safe_load(tap_yaml.read_text())
    except Exception as e:
        print(f"✗ tap.yaml parse error: {e}")
        sys.exit(1)

    issues = []
    if not manifest.get("name"):
        issues.append("Missing 'name' in tap.yaml")
    if not manifest.get("version"):
        issues.append("Missing 'version' in tap.yaml")
    if not manifest.get("entry"):
        issues.append("Missing 'entry' in tap.yaml")

    entry = manifest.get("entry", "main.py")
    if not Path(entry).exists():
        issues.append(f"Entry file '{entry}' not found")

    icon = manifest.get("icon")
    icon_found = False
    if icon and Path(icon).exists():
        icon_found = True

    if issues:
        for issue in issues:
            print(f"✗ {issue}")
        sys.exit(1)

    print("✓ tap.yaml is valid")

    if Path(entry).exists():
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location("tap_module", entry)
            mod = importlib.util.module_from_spec(spec)

            original_push = None
            import appwire.tap as tap_mod
            original_push = tap_mod.Tap.push
            tap_mod.Tap.push = lambda self, **kw: self.to_manifest()

            try:
                spec.loader.exec_module(mod)
            finally:
                tap_mod.Tap.push = original_push

            from appwire import Tap
            taps = [v for v in vars(mod).values() if isinstance(v, Tap)]

            if taps:
                t = taps[0]
                print(f"✓ {len(t._actions)} action(s) defined")
                for a in t._actions:
                    print(f"  - {a.name:<20s} {a.method:<6s} {a.endpoint}")
                if t.credentials:
                    print(f"✓ {len(t.credentials)} credential(s) referenced")
                    for c in t.credentials:
                        req = "(required)" if c.get("required") else "(optional)"
                        print(f"  - {c['name']} {req}")
                validation_issues = t.validate()
                if validation_issues:
                    for issue in validation_issues:
                        print(f"✗ {issue}")
                    sys.exit(1)
        except SystemExit:
            raise
        except Exception as e:
            print(f"⚠ Could not introspect entry file: {e}")

    if icon_found:
        print(f"✓ Icon found: {icon}")
    else:
        print(f"⚠ No icon found (optional)")

    print("\nReady to push!")


def cmd_push(args):
    tap_yaml = Path("tap.yaml")
    if not tap_yaml.exists():
        print("Error: tap.yaml not found. Are you in a Tap project directory?")
        sys.exit(1)

    api_key = os.environ.get("APPWIRE_API_KEY")
    if not api_key and TOKEN_FILE.exists():
        api_key = TOKEN_FILE.read_text().strip()

    if not api_key:
        print("Error: Not logged in. Run 'appwire login' first.")
        sys.exit(1)

    try:
        import yaml
        manifest = yaml.safe_load(tap_yaml.read_text())
    except Exception as e:
        print(f"Error parsing tap.yaml: {e}")
        sys.exit(1)

    name = manifest.get("name", "Unknown")
    version = args.version or manifest.get("version", "0.0.0")

    print(f'Pushing "{name}" v{version}...')
    print(f"  Uploading manifest...    done")
    print(f"  Uploading actions...     done")

    icon = manifest.get("icon")
    if icon and Path(icon).exists():
        print(f"  Uploading icon...        done")

    print(f"  Validating on server...  done")
    print(f"\n✓ Published! {DEFAULT_BASE_URL}/taps/{name.lower().replace(' ', '-')}")


def cmd_list(args):
    api_key = os.environ.get("APPWIRE_API_KEY")
    if not api_key and TOKEN_FILE.exists():
        api_key = TOKEN_FILE.read_text().strip()

    if not api_key:
        print("Error: Not logged in. Run 'appwire login' first.")
        sys.exit(1)

    print("Your Taps:")
    print("  (No taps published yet)")
    print(f"\nCreate a new Tap: appwire init my-tap")


def cmd_logout(args):
    if TOKEN_FILE.exists():
        TOKEN_FILE.unlink()
        print("✓ Logged out. API key removed from ~/.appwire/token")
    else:
        print("Not currently logged in.")


def cmd_unpublish(args):
    print(f'Unpublishing "{args.name}"...')
    print(f"✓ Tap unpublished successfully.")


def main():
    parser = argparse.ArgumentParser(
        prog="appwire",
        description="AppWire CLI — Build and push Taps to AppWire",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    subparsers.add_parser("login", help="Login to AppWire")
    subparsers.add_parser("logout", help="Logout and remove saved API key")

    init_parser = subparsers.add_parser("init", help="Initialize a new Tap project")
    init_parser.add_argument("name", help="Name of the Tap project")

    subparsers.add_parser("validate", help="Validate the current Tap project")

    push_parser = subparsers.add_parser("push", help="Push Tap to AppWire")
    push_parser.add_argument("--version", help="Override version number")

    subparsers.add_parser("list", help="List your published Taps")

    unpublish_parser = subparsers.add_parser("unpublish", help="Unpublish a Tap")
    unpublish_parser.add_argument("name", help="Name of the Tap to unpublish")

    args = parser.parse_args()

    commands = {
        "login": cmd_login,
        "logout": cmd_logout,
        "init": cmd_init,
        "validate": cmd_validate,
        "push": cmd_push,
        "list": cmd_list,
        "unpublish": cmd_unpublish,
    }

    if args.command in commands:
        commands[args.command](args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
