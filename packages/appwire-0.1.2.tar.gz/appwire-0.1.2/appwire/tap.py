import inspect
import json
import os
import yaml
from pathlib import Path
from appwire.action import Action


class Tap:
    def __init__(
        self,
        name: str,
        app: str,
        version: str = "1.0.0",
        description: str = "",
        default_headers: dict = None,
        credentials: list = None,
    ):
        self.name = name
        self.app = app
        self.version = version
        self.description = description
        self.default_headers = default_headers or {}
        self.credentials = credentials or []
        self._actions: list[Action] = []
        self._auth_refresh = None

    def action(
        self,
        name: str,
        method: str = "GET",
        endpoint: str = "",
        description: str = "",
        response_mapping: dict = None,
    ):
        def decorator(func):
            params = []
            sig = inspect.signature(func)
            for param_name, param in sig.parameters.items():
                param_info = {
                    "name": param_name,
                    "required": param.default is inspect.Parameter.empty,
                }
                if param.default is not inspect.Parameter.empty:
                    param_info["default"] = param.default
                if param.annotation is not inspect.Parameter.empty:
                    param_info["type"] = param.annotation.__name__ if hasattr(param.annotation, "__name__") else str(param.annotation)
                params.append(param_info)

            act = Action(
                name=name,
                method=method.upper(),
                endpoint=endpoint,
                description=description,
                handler=func,
                params=params,
                response_mapping=response_mapping,
            )
            self._actions.append(act)
            return func

        return decorator

    def auth_refresh(self, method: str, endpoint: str, interval: int = 3600):
        def decorator(func):
            self._auth_refresh = {
                "method": method.upper(),
                "endpoint": endpoint,
                "interval": interval,
                "handler": func,
            }
            return func

        return decorator

    def to_manifest(self) -> dict:
        manifest = {
            "name": self.name,
            "app": self.app,
            "version": self.version,
            "description": self.description,
            "default_headers": self.default_headers,
            "credentials": self.credentials,
            "actions": [a.to_dict() for a in self._actions],
        }
        if self._auth_refresh:
            manifest["auth_refresh"] = {
                "method": self._auth_refresh["method"],
                "endpoint": self._auth_refresh["endpoint"],
                "interval": self._auth_refresh["interval"],
                "config": self._auth_refresh["handler"](),
            }
        return manifest

    def validate(self) -> list[str]:
        issues = []
        if not self.name:
            issues.append("Tap name is required")
        if not self.app:
            issues.append("Tap app is required")
        if not self._actions:
            issues.append("At least one action is required")
        for action in self._actions:
            if not action.name:
                issues.append(f"Action name is required")
            if not action.endpoint:
                issues.append(f"Action '{action.name}' is missing an endpoint")
            if action.method not in ("GET", "POST", "PUT", "PATCH", "DELETE"):
                issues.append(f"Action '{action.name}' has invalid method: {action.method}")
        return issues

    def push(self, api_key: str = None, base_url: str = "https://appwire.dev"):
        key = api_key or os.environ.get("APPWIRE_API_KEY")
        if not key:
            token_path = Path.home() / ".appwire" / "token"
            if token_path.exists():
                key = token_path.read_text().strip()

        if not key:
            raise RuntimeError(
                "No API key found. Run 'appwire login' or set APPWIRE_API_KEY."
            )

        issues = self.validate()
        if issues:
            raise ValueError(f"Validation failed:\n" + "\n".join(f"  - {i}" for i in issues))

        manifest = self.to_manifest()
        print(f'Pushing "{self.name}" v{self.version}...')
        print(f"  {len(self._actions)} action(s) defined")
        print(f"  {len(self.credentials)} credential(s) referenced")
        print(f"\n✓ Manifest generated successfully")
        print(f"  Use 'appwire push' CLI command to upload to {base_url}")

        return manifest

    def __repr__(self):
        return f"Tap(name='{self.name}', app='{self.app}', actions={len(self._actions)})"
