"""Motif: Discover your coding patterns. Generate personalized AI rules."""

__version__ = "0.0.1"
