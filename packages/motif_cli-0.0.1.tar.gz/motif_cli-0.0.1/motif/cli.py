"""Motif CLI entry point."""


def main():
    print("Motif v0.0.1 — coming soon. See https://github.com/avivsheriff/motif-cli")


if __name__ == "__main__":
    main()
