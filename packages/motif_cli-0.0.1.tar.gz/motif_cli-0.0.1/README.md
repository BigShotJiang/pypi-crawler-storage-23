# Motif

**Discover your coding patterns. Generate personalized AI rules. Your work speaks for itself.**

Motif reads your Cursor and Claude Code conversations, discovers your recurring patterns, and generates personalized `.cursorrules` / `CLAUDE.md` / skills files tuned to your actual working style.

Coming soon. Watch the repo for updates: https://github.com/avivsheriff/motif-cli
