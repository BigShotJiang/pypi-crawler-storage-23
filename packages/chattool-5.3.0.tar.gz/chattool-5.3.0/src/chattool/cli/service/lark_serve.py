"""
chattool serve lark — 启动飞书机器人服务

Commands:
    chattool serve lark echo      启动简单回显机器人
    chattool serve lark ai        启动 AI 对话机器人
    chattool serve lark webhook   启动空 Webhook 服务（用于平台验证）
"""
import sys
import click

from chattool.tools import LarkBot, ChatSession

LOG_LEVELS = click.Choice(["DEBUG", "INFO", "WARNING", "ERROR"], case_sensitive=False)

def _get_bot():
    try:
        return LarkBot()
    except Exception as e:
        click.echo(f"初始化失败: {e}", err=True)
        click.echo("请确认已安装 chattool[tools] 并设置 FEISHU_APP_ID 和 FEISHU_APP_SECRET 环境变量", err=True)
        sys.exit(1)


@click.group()
def cli():
    """飞书机器人服务"""
    pass


# ------------------------------------------------------------------
# chattool serve lark echo
# ------------------------------------------------------------------

@cli.command()
@click.option("--mode", "-m", default="ws",
              type=click.Choice(["ws", "flask"]),
              help="运行模式: ws (WebSocket) 或 flask (Webhook)")
@click.option("--host", default="0.0.0.0", help="Flask 监听地址 (仅 flask 模式)")
@click.option("--port", "-p", default=7777, type=int,
              help="Flask 监听端口 (仅 flask 模式)")
@click.option("--log-level", "-l", default="INFO", type=LOG_LEVELS,
              help="日志级别 (默认 INFO)")
def echo(mode, host, port, log_level):
    """
    启动回显机器人：原样返回收到的文本消息。

    \b
    适合快速验证消息收发链路是否通畅。

    示例:
      chattool serve lark echo
      chattool serve lark echo --log-level DEBUG
      chattool serve lark echo --mode flask --port 8080
    """
    bot = _get_bot()

    @bot.on_message
    def handle(ctx):
        ctx.reply(f"Echo: {ctx.text}")

    click.secho(f"🤖 回显机器人启动  mode={mode}  log_level={log_level}", fg="green")
    _start(bot, mode, host, port, log_level)


# ------------------------------------------------------------------
# chattool serve lark ai
# ------------------------------------------------------------------

@cli.command()
@click.option("--mode", "-m", default="ws",
              type=click.Choice(["ws", "flask"]),
              help="运行模式")
@click.option("--host", default="0.0.0.0", help="Flask 监听地址")
@click.option("--port", "-p", default=7777, type=int, help="Flask 监听端口")
@click.option("--log-level", "-l", default="INFO", type=LOG_LEVELS,
              help="日志级别 (默认 INFO)")
@click.option("--system", "-s",
              default="你是一个工作助手，回答简洁专业。",
              help="System Prompt")
@click.option("--max-history", "-n", default=10, type=int,
              help="每个用户最多保留的对话轮数")
@click.option("--model", default=None, help="LLM 模型名称 (留空使用默认)")
@click.option("--model-type", default="openai",
              type=click.Choice(["openai", "azure"], case_sensitive=False),
              help="LLM 后端类型 (默认 openai)")
def ai(mode, host, port, log_level, system, max_history, model, model_type):
    """
    启动 AI 对话机器人：接入 LLM 进行多轮对话。

    \b
    内置 /clear、/help 命令。

    示例:
      chattool serve lark ai
      chattool serve lark ai --system "你是一名翻译官" --max-history 20
      chattool serve lark ai --model-type azure --model gpt-4o
    """
    bot = _get_bot()
    session = ChatSession(system=system, max_history=max_history,
                          model=model, model_type=model_type)

    @bot.command("/clear")
    def on_clear(ctx):
        session.clear(ctx.sender_id)
        ctx.reply("对话历史已清除 ✅")

    @bot.command("/help")
    def on_help(ctx):
        ctx.reply(
            "支持的命令:\n"
            "/clear  清除对话历史\n"
            "/help   显示帮助\n"
            "\n直接发消息即可与 AI 对话。"
        )

    @bot.on_message
    def on_msg(ctx):
        if ctx.msg_type != "text":
            ctx.reply("暂只支持文字消息")
            return
        reply_text = session.chat(ctx.sender_id, ctx.text)
        ctx.reply(reply_text)

    click.secho(f"🤖 AI 机器人启动  mode={mode}  log_level={log_level}  system={system[:40]}...", fg="green")
    _start(bot, mode, host, port, log_level)


# ------------------------------------------------------------------
# chattool serve lark webhook
# ------------------------------------------------------------------

@cli.command()
@click.option("--host", default="0.0.0.0", help="监听地址")
@click.option("--port", "-p", default=7777, type=int, help="监听端口")
@click.option("--path", default="/webhook/event", help="Webhook 路径")
@click.option("--log-level", "-l", default="INFO", type=LOG_LEVELS,
              help="日志级别 (默认 INFO)")
@click.option("--encrypt-key", default="", help="事件加密 Key")
@click.option("--verification-token", default="", help="验证 Token")
def webhook(host, port, path, log_level, encrypt_key, verification_token):
    """
    启动空 Webhook 服务，用于飞书平台验证 URL。

    \b
    启动后将飞书开放平台的「请求网址 URL」指向
    http://<your_ip>:<port><path>
    平台会发送 challenge 验证请求，此服务自动回复。

    示例:
      chattool serve lark webhook
      chattool serve lark webhook --port 8080 --path /lark/events
    """
    bot = _get_bot()
    click.secho(
        f"🔗 Webhook 服务启动  http://{host}:{port}{path}  log_level={log_level}",
        fg="green",
    )
    bot.start(
        mode="flask",
        encrypt_key=encrypt_key,
        verification_token=verification_token,
        host=host,
        port=port,
        path=path,
        log_level=log_level,
    )


def _start(bot, mode, host, port, log_level="INFO"):
    try:
        if mode == "ws":
            bot.start(mode="ws", log_level=log_level)
        else:
            bot.start(mode="flask", host=host, port=port, log_level=log_level)
    except KeyboardInterrupt:
        click.echo("\n已停止")
