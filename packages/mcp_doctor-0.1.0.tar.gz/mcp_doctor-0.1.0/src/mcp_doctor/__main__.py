"""Allow running as python -m mcp_doctor."""

from mcp_doctor.cli import main

main()
