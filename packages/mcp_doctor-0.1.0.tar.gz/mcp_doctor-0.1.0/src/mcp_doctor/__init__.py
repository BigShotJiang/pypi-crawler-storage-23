"""mcp-doctor: Check and improve the contract quality of any MCP server."""

__version__ = "0.1.0"
