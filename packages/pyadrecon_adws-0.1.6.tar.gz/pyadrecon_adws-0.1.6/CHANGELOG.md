## [0.1.6](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.1.5...v0.1.6) (2026-02-18)


### Bug Fixes

* pypi pipx script calling ([bf8465d](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/bf8465dc466162ae54f9d47c4a118dcbcd9afddc))

## [0.1.5](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.1.4...v0.1.5) (2026-02-18)


### Bug Fixes

* Update Dockerfile ([8509e25](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/8509e25d20b362b82d72827745fae65cea37410d))

## [0.1.4](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.1.3...v0.1.4) (2026-02-18)


### Bug Fixes

* Update Dockerfile ([9f1fd10](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/9f1fd10f7ad8258fa6e538183cbcc3d3b9eef51f))

## [0.1.3](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.1.2...v0.1.3) (2026-02-18)


### Bug Fixes

* Update conventional-commits.yml ([29bd23e](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/29bd23e70860936301e04d8f7bf90c1da0c00c1b))

## [0.1.2](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.1.1...v0.1.2) (2026-02-18)


### Bug Fixes

* Update pyproject.toml ([79ee9d6](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/79ee9d6ac64224c61a3bdac8a7fea20510c66b13))

