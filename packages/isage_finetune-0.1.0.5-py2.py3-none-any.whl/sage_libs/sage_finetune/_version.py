"""Version information for isage-finetune."""

__version__ = "0.1.0.5"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
