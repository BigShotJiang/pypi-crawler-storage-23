"""ASN.1 tag-length-value encoding and decoding."""

__all__: list[str] = []
