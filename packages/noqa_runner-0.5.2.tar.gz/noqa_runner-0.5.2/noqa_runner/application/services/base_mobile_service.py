"""Base mobile service with platform-agnostic logic"""

from __future__ import annotations

import asyncio
import base64
import logging
import time
from abc import ABC, abstractmethod
from io import BytesIO

import numpy as np
from defusedxml import ElementTree as ET
from PIL import Image

from noqa_runner.domain.models.actions.activate_app import ActivateApp
from noqa_runner.domain.models.actions.background_app import BackgroundApp
from noqa_runner.domain.models.actions.base import BaseAction
from noqa_runner.domain.models.actions.drag import Drag
from noqa_runner.domain.models.actions.input_text import InputText
from noqa_runner.domain.models.actions.open_url import OpenUrl
from noqa_runner.domain.models.actions.restart_app import RestartApp
from noqa_runner.domain.models.actions.stop import Stop
from noqa_runner.domain.models.actions.swipe import Swipe
from noqa_runner.domain.models.actions.tap import Tap
from noqa_runner.domain.models.actions.terminate_app import TerminateApp
from noqa_runner.domain.models.actions.wait import Wait
from noqa_runner.domain.models.app_source import AppSource
from noqa_runner.domain.models.state.screen import ActiveElement, Screen
from noqa_runner.infrastructure.adapters.mobile.appium_adapter import AppiumClient
from noqa_runner.utils.retry_decorator import with_retry

logger = logging.getLogger(__name__)


class BaseMobileService(ABC):
    """Base service for mobile device interactions (platform-agnostic)"""

    # Screen data stability timeouts
    SCREENSHOT_STABILITY_TIMEOUT = 4.0
    ELEMENTS_STABILITY_TIMEOUT = 4.0
    NOTIFICATION_WAIT_TIMEOUT = 10.0
    SCREENSHOT_DIFF_THRESHOLD = 0.5

    def __init__(self, appium_client: AppiumClient, bundle_id: str):
        self.client = appium_client
        self.bundle_id = bundle_id

    @staticmethod
    @abstractmethod
    async def resolve_bundle_id(app_build_path: str | None) -> str | None:
        """
        Resolve bundle ID from build path.
        Platform-specific implementation in subclasses.
        """
        pass

    @abstractmethod
    def install_app(
        self,
        build_source: AppSource | None,
        bundle_id: str | None,
        app_store_id: str | None,
    ) -> None:
        """
        Install app based on build_source.
        Platform-specific implementation in subclasses.
        """
        pass

    @abstractmethod
    def is_app_crashed(self, xml_source: str, action_types: list[str]) -> bool:
        """
        Check if app has crashed based on screen state.
        Platform-specific implementation in subclasses.

        Args:
            xml_source: XML source of current screen
            action_types: List of action type names from test steps

        Returns:
            True if app appears to have crashed
        """
        pass

    async def get_app_state(self, bundle_id: str) -> int:
        """Get current app state"""
        return self.client.query_app_state(bundle_id)

    async def execute_action(self, action: BaseAction, screen: Screen | None = None):
        """Execute action based on its type using pattern matching"""
        match action:
            case Tap():
                await self.tap(action)

            case Swipe():
                await self.swipe(action)

            case Drag():
                await self.drag(action)

            case InputText():
                await self.input_text_in_element(
                    element=action.location.element,
                    text=action.text,
                    elements_tree=screen.elements_tree if screen else None,
                )

            case ActivateApp():
                self.client.activate_app(self.bundle_id)

            case BackgroundApp():
                self.client.background_app()

            case TerminateApp():
                self.client.terminate_app(self.bundle_id)

            case RestartApp():
                self.client.terminate_app(self.bundle_id)
                self.client.activate_app(self.bundle_id)

            case OpenUrl():
                self.client.open_url(str(action.url))

            case Wait():
                await asyncio.sleep(3)

            case Stop():
                pass

            case _:
                raise ValueError(f"Unknown action type: {type(action).__name__}")

    async def tap(self, action: Tap):
        resolution = self.resolution

        # Calculate center from bounding box [ymin, xmin, ymax, xmax] in normalized 0-1000 range
        ymin, xmin, ymax, xmax = action.location.bbox_2d

        # Denormalize to pixel coordinates
        image_width = resolution["width"]
        image_height = resolution["height"]

        xmin_px = int(xmin * image_width / 1000)
        ymin_px = int(ymin * image_height / 1000)
        xmax_px = int(xmax * image_width / 1000)
        ymax_px = int(ymax * image_height / 1000)

        # Calculate center point for tap
        center_x = (xmin_px + xmax_px) // 2
        center_y = (ymin_px + ymax_px) // 2

        if action.double:
            self.double_tap(x=center_x, y=center_y)
        elif action.duration > 0:
            # Long press via swipe-in-place (same for all platforms)
            self.client.swipe(
                start_x=center_x,
                start_y=center_y,
                end_x=center_x,
                end_y=center_y,
                duration_ms=action.duration * 1000,
            )
        else:
            self.client.tap_by_coords(center_x, center_y)

    @abstractmethod
    def double_tap(self, x: int, y: int) -> None:
        """Execute platform-specific double tap at coordinates."""
        pass

    async def swipe(self, action: Swipe):
        """Execute swipe using vision-based start/end coordinates"""
        resolution = self.resolution

        image_width = resolution["width"]
        image_height = resolution["height"]

        start_x = int(action.location.start_point_2d[0] * image_width / 1000)
        start_y = int(action.location.start_point_2d[1] * image_height / 1000)
        end_x = int(action.location.end_point_2d[0] * image_width / 1000)
        end_y = int(action.location.end_point_2d[1] * image_height / 1000)

        self.client.swipe(start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y)

    async def drag(self, action: Drag):
        """Execute drag using vision-based start/end coordinates"""
        resolution = self.resolution

        image_width = resolution["width"]
        image_height = resolution["height"]

        start_x = int(action.location.start_point_2d[0] * image_width / 1000)
        start_y = int(action.location.start_point_2d[1] * image_height / 1000)
        end_x = int(action.location.end_point_2d[0] * image_width / 1000)
        end_y = int(action.location.end_point_2d[1] * image_height / 1000)

        self.client.swipe(
            start_x=start_x, start_y=start_y, end_x=end_x, end_y=end_y, duration_ms=2000
        )

    @abstractmethod
    def get_locator(
        self, element: ActiveElement, *, for_input: bool = False
    ) -> tuple[str, str] | None:
        """
        Generate platform-specific locator for Appium element lookup.
        """
        pass

    async def input_text_in_element(
        self, element: ActiveElement, text: str, elements_tree: str | None = None
    ) -> None:
        """
        Smart text input with automatic keyboard handling

        Args:
            element: Target element for text input
            text: Text to input
            elements_tree: XML tree to check for keyboard presence
        """
        locator_result = self.get_locator(element, for_input=True)
        if locator_result:
            strategy, locator = locator_result
            self.client.send_keys(by=strategy, locator=locator, text=text)

    @property
    def resolution(self) -> dict[str, int]:
        """Get device resolution"""
        return self.client.get_resolution()

    def _resize_image(self, image: Image.Image, max_size: int) -> Image.Image:
        """Resize image so that minimum side is max_size"""
        width, height = image.size
        min_side = min(width, height)

        if min_side <= max_size:
            return image

        scale_factor = max_size / min_side
        new_width = int(width * scale_factor)
        new_height = int(height * scale_factor)
        return image.resize((new_width, new_height), Image.Resampling.LANCZOS)

    def _resize_screenshot(self, screenshot_base64: str, max_size: int = 500) -> str:
        """Resize screenshot to max_size on minimum side, return base64"""
        image_data = base64.b64decode(screenshot_base64)
        with Image.open(BytesIO(image_data)) as img:
            resized = self._resize_image(image=img, max_size=max_size)
            buffer = BytesIO()
            resized.save(buffer, format="PNG")
            return base64.b64encode(buffer.getvalue()).decode("utf-8")

    def _get_screenshot_thumbnail(self, screenshot_base64: str) -> np.ndarray:
        """Get screenshot thumbnail as numpy array for comparison"""
        image_data = base64.b64decode(screenshot_base64)
        with Image.open(BytesIO(image_data)) as img:
            # Reuse _resize_image for consistency (50px for fast comparison)
            resized = self._resize_image(image=img.convert("RGB"), max_size=50)
        return np.asarray(resized)

    def _calculate_image_difference(self, img1: np.ndarray, img2: np.ndarray) -> float:
        """
        Calculate percentage difference between two images
        Returns percentage of different pixels (0.0 to 100.0)
        """
        if img1.shape != img2.shape:
            return 100.0

        # Calculate absolute difference
        diff = np.abs(img1.astype(float) - img2.astype(float))

        # Use L2 norm (Euclidean distance) per pixel for more robust comparison
        # This considers the magnitude of differences across all channels
        pixel_diff_magnitude = np.sqrt(np.sum(diff**2, axis=-1))

        # Define threshold for considering pixels as different (default: 5.0)
        # This helps ignore minor rendering artifacts and anti-aliasing differences
        threshold = 5.0

        # Count pixels that exceed threshold
        different_pixels = (pixel_diff_magnitude > threshold).sum()
        total_pixels = img1.shape[0] * img1.shape[1]

        # Return percentage
        return (different_pixels / total_pixels) * 100.0

    def _has_non_fullscreen_elements(self, xml_source: str) -> bool:
        """Check if XML has elements smaller than screen resolution"""
        root = ET.fromstring(xml_source)
        for elem in root.iter():
            width = elem.get("width")
            height = elem.get("height")
            if width and height:
                if (
                    int(width) < self.resolution["width"]
                    or int(height) < self.resolution["height"]
                ):
                    return True
        return False

    async def get_screen_data(
        self, screenshot_max_size: int | None = 800
    ) -> tuple[str, str]:
        """
        Get screen data for vision mode.
        Returns empty XML and screenshot immediately without stability checks.
        """
        # Vision mode: just get screenshot without any waiting
        screenshot = self.client.get_screenshot()
        if screenshot_max_size:
            screenshot = self._resize_screenshot(
                screenshot_base64=screenshot, max_size=screenshot_max_size
            )
        return "", screenshot

    @with_retry(max_attempts=3)
    async def get_appium_screen_data(
        self,
        elements_stability_timeout: float | None = None,
        screenshot_max_size: int | None = 500,
    ) -> tuple[str, str]:
        """
        Get synchronized XML and screenshot from Appium with three-phase stability check

        Phase 1: Wait for screenshot stability
        Phase 2: Wait for element tree to have content
        Phase 3: Wait for notifications to disappear
        """
        start_time = time.time()

        # Phase 1: Wait for screenshot stability
        while time.time() - start_time < self.SCREENSHOT_STABILITY_TIMEOUT:
            screenshot_before = self.client.get_screenshot()
            thumbnail_before = self._get_screenshot_thumbnail(
                screenshot_base64=screenshot_before
            )

            screenshot_after = self.client.get_screenshot()
            thumbnail_after = self._get_screenshot_thumbnail(
                screenshot_base64=screenshot_after
            )

            diff_percent = self._calculate_image_difference(
                img1=thumbnail_before, img2=thumbnail_after
            )

            if diff_percent <= self.SCREENSHOT_DIFF_THRESHOLD:
                # Screenshot is stable, move to Phase 2
                break

            await asyncio.sleep(0.05)

        # Phase 2: Wait for element tree to have active elements
        elements_start_time = time.time()
        xml_source = None

        while time.time() - elements_start_time < (
            elements_stability_timeout or self.ELEMENTS_STABILITY_TIMEOUT
        ):
            xml_source = self.client.get_page_source()

            # Check if there are non-fullscreen elements (real UI content)
            if self._has_non_fullscreen_elements(xml_source):
                # Move to Phase 3
                break

            await asyncio.sleep(0.05)

        # Phase 3: Wait for notifications to disappear
        notification_start_time = time.time()

        while time.time() - notification_start_time < self.NOTIFICATION_WAIT_TIMEOUT:
            # Check if overlay UI is gone (use xml_source from Phase 2 on first iteration)
            fresh_screenshot = self.client.get_screenshot()
            if screenshot_max_size:
                fresh_screenshot = self._resize_screenshot(
                    screenshot_base64=fresh_screenshot, max_size=screenshot_max_size
                )
            return xml_source, fresh_screenshot

            # Get fresh XML for next iteration
            await asyncio.sleep(0.2)
            xml_source = self.client.get_page_source()

        # Timeout: take fresh screenshot and return what we have (even with overlay)
        fresh_screenshot = self.client.get_screenshot()
        screenshot_resized = self._resize_screenshot(
            screenshot_base64=fresh_screenshot, max_size=screenshot_max_size
        )
        return xml_source, screenshot_resized
