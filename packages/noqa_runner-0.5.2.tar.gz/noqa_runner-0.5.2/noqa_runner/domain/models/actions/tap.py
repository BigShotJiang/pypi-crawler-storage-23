from __future__ import annotations

from typing import Annotated, Literal

import annotated_types as at
from pydantic import BaseModel, Field, model_validator
from pydantic.json_schema import SkipJsonSchema
from typing_extensions import Self

from noqa_runner.domain.models.actions.base import BaseAction

# Type alias for bounding box with 4 scaled coordinates [ymin, xmin, ymax, xmax] in range 0-1000
BBox2D = Annotated[list[Annotated[float, at.Ge(0), at.Le(1000)]], at.Len(4, 4)]


class TapLocation(BaseModel):
    """Vision-detected tap location with bounding box."""

    bbox_2d: BBox2D = Field(
        description="Bounding box in normalized coordinates [ymin, xmin, ymax, xmax] in range 0-1000. "
        "ymin, ymax: vertical axis (0=top, 1000=bottom). "
        "xmin, xmax: horizontal axis (0=left, 1000=right)."
    )


class Tap(BaseAction):
    """Tap on a mobile element using vision-based bounding box"""

    name: Literal["tap"] = "tap"
    element_description: str = Field(
        description="Brief description of the element location"
    )
    location: SkipJsonSchema[TapLocation | None] = Field(
        default=None, description="Vision-detected tap location with bounding box"
    )
    duration: int = Field(
        default=0,
        description="Long press duration in seconds (0 for regular tap, 1-5 for long press)",
        ge=0,
        le=5,
    )
    double: bool = Field(default=False, description="Whether to perform a double tap")

    @model_validator(mode="after")
    def validate_double_and_duration(self) -> Self:
        """Double tap and long press duration are mutually exclusive."""
        if self.double and self.duration > 0:
            raise ValueError(
                "Cannot combine double tap with long press duration. "
                "Use either double=True or duration>0, not both."
            )
        return self

    def get_action_description(self) -> str:
        """Get description of tap action"""
        if self.double:
            return f"Double tapped on: {self.element_description}"
        if self.duration > 0:
            return f"Long pressed on: {self.element_description} for {self.duration}s"
        return f"Tapped on: {self.element_description}"
