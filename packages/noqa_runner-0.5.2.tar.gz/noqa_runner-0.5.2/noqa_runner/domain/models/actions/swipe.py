from __future__ import annotations

from typing import Annotated, Literal

import annotated_types as at
from pydantic import BaseModel, Field
from pydantic.json_schema import SkipJsonSchema

from noqa_runner.domain.models.actions.base import BaseAction

# Type alias for 2D points with normalized coordinates [x, y] in range 0-1000
# Each coordinate must be between 0 and 1000
Point2D = Annotated[list[Annotated[float, at.Ge(0), at.Le(1000)]], at.Len(2, 2)]


class SwipeLocation(BaseModel):
    """Vision-detected swipe location with start/end points and resolution."""

    start_point_2d: Point2D = Field(
        description="Swipe start point in normalized coordinates [x, y] in range 0-1000. "
        "x: horizontal axis (0=left, 1000=right). "
        "y: vertical axis (0=top, 1000=bottom)."
    )
    end_point_2d: Point2D = Field(
        description="Swipe end point in normalized coordinates [x, y] in range 0-1000. "
        "x: horizontal axis (0=left, 1000=right). "
        "y: vertical axis (0=top, 1000=bottom)."
    )


class Swipe(BaseAction):
    """Swipe on screen using vision-based start and end coordinates"""

    name: Literal["swipe"] = "swipe"
    element_description: str = Field(
        description="Brief description of the swipe gesture and target area"
    )
    location: SkipJsonSchema[SwipeLocation | None] = Field(
        default=None,
        description="Vision-detected swipe location with start/end points and resolution",
    )

    def get_action_description(self) -> str:
        """Get description of swipe action"""
        return f"Swiped: {self.element_description}"
