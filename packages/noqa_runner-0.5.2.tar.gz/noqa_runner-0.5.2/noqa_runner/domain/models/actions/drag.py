from __future__ import annotations

from typing import Annotated, Literal

import annotated_types as at
from pydantic import BaseModel, Field
from pydantic.json_schema import SkipJsonSchema

from noqa_runner.domain.models.actions.base import BaseAction

# Type alias for 2D points with normalized coordinates [x, y] in range 0-1000
# Each coordinate must be between 0 and 1000
Point2D = Annotated[list[Annotated[float, at.Ge(0), at.Le(1000)]], at.Len(2, 2)]


class DragLocation(BaseModel):
    """Vision-detected drag location with start/end points and resolution."""

    start_point_2d: Point2D = Field(
        description="Drag start point in normalized coordinates [x, y] in range 0-1000. "
        "x: horizontal axis (0=left, 1000=right). "
        "y: vertical axis (0=top, 1000=bottom)."
    )
    end_point_2d: Point2D = Field(
        description="Drag end point in normalized coordinates [x, y] in range 0-1000. "
        "x: horizontal axis (0=left, 1000=right). "
        "y: vertical axis (0=top, 1000=bottom)."
    )


class Drag(BaseAction):
    """Drag element from one point to another using vision-based coordinates"""

    name: Literal["drag"] = "drag"
    element_description: str = Field(
        description="Brief description of the drag gesture, source element and target location"
    )
    location: SkipJsonSchema[DragLocation | None] = Field(
        default=None,
        description="Vision-detected drag location with start/end points and resolution",
    )

    def get_action_description(self) -> str:
        """Get description of drag action"""
        return f"Dragged: {self.element_description}"
