from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field
from pydantic.json_schema import SkipJsonSchema

from noqa_runner.domain.models.actions.base import BaseAction
from noqa_runner.domain.models.state.screen import ActiveElement


class InputTextLocation(BaseModel):
    """Vision-detected input field location with element metadata."""

    element: ActiveElement = Field(
        description="Input field element with coordinates and metadata"
    )


class InputText(BaseAction):
    """Input text into a mobile element using vision-based field selection"""

    name: Literal["input_text"] = "input_text"
    text: str = Field(description="Text to input into the field", min_length=1)
    element_description: str = Field(
        description="Description of the target input field"
    )
    location: SkipJsonSchema[InputTextLocation | None] = Field(
        default=None,
        description="Vision-detected input field location with element metadata",
    )

    def get_action_description(self) -> str:
        """Get description of vision input text action"""
        return f"Input text '{self.text}' in: {self.element_description}"
