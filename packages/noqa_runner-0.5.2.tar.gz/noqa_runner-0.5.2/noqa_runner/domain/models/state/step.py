from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from noqa_runner.domain.models.actions.action_data import ActionData
from noqa_runner.domain.models.state.screen import Screen


class Step(BaseModel):
    """Domain model for a single test step with screen state and action results"""

    number: int = Field(default=1, ge=1, description="Step number in the test sequence")
    screen: Screen | None = Field(default=None)

    action_data: ActionData | None = Field(
        default=None, description="Action performed on this step"
    )
    context: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional context items for this step (stop validation feedback, action constraints, etc.) to be included in LLM prompts",
    )
