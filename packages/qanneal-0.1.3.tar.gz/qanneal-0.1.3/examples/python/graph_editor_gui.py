from qanneal import launch_graph_editor


if __name__ == "__main__":
    launch_graph_editor()
