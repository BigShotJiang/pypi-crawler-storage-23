"""Bundled data files for Kredo."""
