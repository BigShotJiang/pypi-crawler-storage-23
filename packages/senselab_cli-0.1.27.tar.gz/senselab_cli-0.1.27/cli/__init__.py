"""SenseLab CLI package."""

from importlib.metadata import PackageNotFoundError, version as package_version
from pathlib import Path


def _resolve_version() -> str:
    try:
        return package_version("senselab-cli")
    except PackageNotFoundError:
        # Local source checkout fallback when package metadata is unavailable.
        try:
            import tomllib

            pyproject = Path(__file__).resolve().parents[1] / "pyproject.toml"
            data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
            return str(data.get("project", {}).get("version", "0.0.0"))
        except Exception:
            return "0.0.0"


__version__ = _resolve_version()

