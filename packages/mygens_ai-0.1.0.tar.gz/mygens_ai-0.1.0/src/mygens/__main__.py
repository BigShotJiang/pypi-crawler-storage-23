"""Allow running as `python -m mygens`."""

from mygens.cli.app import main

main()
