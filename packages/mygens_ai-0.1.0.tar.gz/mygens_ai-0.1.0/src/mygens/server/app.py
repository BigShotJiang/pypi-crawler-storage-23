"""FastAPI application factory for the MyGens server."""

from __future__ import annotations

import sqlite3
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import APIRouter, FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from mygens.core.config import get_db_path
from mygens.core.db import get_connection, init_db
from mygens.server.deps import get_db
from mygens.server.routes import generations, outputs, projects, search, stats


def _make_db_dependency(db_path: str):
    """Create a request-scoped DB dependency bound to *db_path*.

    For ``:memory:`` databases the same connection must be reused for
    every request (otherwise each call would get a fresh, empty database).
    For file-backed databases a new connection is opened per request and
    closed afterwards.
    """
    if db_path == ":memory:":
        # Shared in-memory connection -- kept alive for the app lifetime
        _shared_conn: sqlite3.Connection | None = None

        def _get_db_memory():
            nonlocal _shared_conn
            if _shared_conn is None:
                _shared_conn = get_connection(":memory:")
                init_db(_shared_conn)
            yield _shared_conn

        return _get_db_memory
    else:

        def _get_db_file():
            conn = get_connection(db_path)
            try:
                yield conn
            finally:
                conn.close()

        return _get_db_file


def create_app(db_path: str | None = None) -> FastAPI:
    """Build and return the fully-configured FastAPI application.

    Parameters
    ----------
    db_path:
        Path to the SQLite database file.  Pass ``":memory:"`` for tests.
        Defaults to the value of :func:`mygens.core.config.get_db_path`.
    """
    resolved_path = db_path or str(get_db_path())

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
        """Initialize the database on startup."""
        if resolved_path != ":memory:":
            # Ensure parent directory exists for file-based databases
            Path(resolved_path).parent.mkdir(parents=True, exist_ok=True)
            conn = get_connection(resolved_path)
            init_db(conn)
            conn.close()
        # For :memory: the init happens inside the dependency itself
        yield

    app = FastAPI(
        title="MyGens",
        description="Local-first AI prompt management -- REST API",
        version="0.1.0",
        lifespan=lifespan,
    )

    # -- CORS (wide-open for local development) --
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # -- Dependency override --
    # Setting on the app ensures all routes (included via routers) see the
    # correct dependency, unlike sub-app mounts which are isolated ASGI apps.
    db_dep = _make_db_dependency(resolved_path)
    app.dependency_overrides[get_db] = db_dep

    # -- API routes under /api/v1 --
    v1 = APIRouter(prefix="/api/v1")
    v1.include_router(generations.router)
    v1.include_router(outputs.router)
    v1.include_router(projects.router)
    v1.include_router(search.router)
    v1.include_router(stats.router)

    # -- Webhook routes --
    try:
        from mygens.integrations.webhook import router as webhook_router
        v1.include_router(webhook_router)
    except ImportError:
        pass

    app.include_router(v1)

    # -- Static files for the React dashboard (optional) --
    _static_dir = Path(__file__).resolve().parent / "static"
    if _static_dir.is_dir():
        app.mount("/", StaticFiles(directory=str(_static_dir), html=True))

    return app
