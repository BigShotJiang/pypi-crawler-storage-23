"""Dependency injection for the MyGens FastAPI server."""

from __future__ import annotations

import sqlite3
from collections.abc import Generator

from mygens.core.config import get_db_path
from mygens.core.db import get_connection


def get_db(
    db_path: str | None = None,
) -> Generator[sqlite3.Connection, None, None]:
    """Yield a database connection for the duration of a request.

    In production the *db_path* defaults to the configured database path
    (``~/.mygens/mygens.db``).  Tests override this by passing
    ``:memory:`` through the app factory.

    The connection is closed when the request finishes.
    """
    path = db_path or str(get_db_path())
    conn = get_connection(path)
    try:
        yield conn
    finally:
        conn.close()
