"""Stats endpoint -- dashboard aggregate statistics."""

from __future__ import annotations

import json
import sqlite3

from fastapi import APIRouter, Depends

from mygens.core.models import DashboardStats, PromptFragment
from mygens.server.deps import get_db

router = APIRouter(tags=["stats"])


@router.get("/stats", response_model=DashboardStats, summary="Dashboard statistics")
def stats(
    conn: sqlite3.Connection = Depends(get_db),
) -> DashboardStats:
    """Return aggregated statistics for the dashboard overview."""
    # Total counts
    total_generations = conn.execute(
        "SELECT count(*) FROM generations"
    ).fetchone()[0]

    total_outputs = conn.execute(
        "SELECT count(*) FROM outputs"
    ).fetchone()[0]

    total_projects = conn.execute(
        "SELECT count(*) FROM projects WHERE archived = 0"
    ).fetchone()[0]

    # Breakdown by platform
    by_platform: dict[str, int] = {}
    for row in conn.execute(
        "SELECT platform, count(*) as cnt FROM generations GROUP BY platform"
    ):
        by_platform[row["platform"]] = row["cnt"]

    # Breakdown by rating
    by_rating: dict[int, int] = {}
    for row in conn.execute(
        "SELECT rating, count(*) as cnt FROM generations GROUP BY rating"
    ):
        by_rating[row["rating"]] = row["cnt"]

    # Top fragments (by usage)
    top_fragments: list[PromptFragment] = []
    for row in conn.execute(
        "SELECT * FROM prompt_fragments ORDER BY usage_count DESC LIMIT 10"
    ):
        top_fragments.append(
            PromptFragment(
                id=row["id"],
                text=row["text"],
                category=row["category"],
                platform_compat=json.loads(row["platform_compat"])
                if row["platform_compat"]
                else [],
                usage_count=row["usage_count"],
                avg_rating=row["avg_rating"],
            )
        )

    # Top models (by generation count)
    top_models: list[dict] = []
    for row in conn.execute(
        """SELECT model, count(*) as cnt
           FROM generations
           WHERE model IS NOT NULL
           GROUP BY model
           ORDER BY cnt DESC
           LIMIT 10"""
    ):
        top_models.append({"model": row["model"], "count": row["cnt"]})

    return DashboardStats(
        total_generations=total_generations,
        total_outputs=total_outputs,
        total_projects=total_projects,
        by_platform=by_platform,
        by_rating=by_rating,
        top_fragments=top_fragments,
        top_models=top_models,
    )
