"""Project endpoints -- CRUD for prompt projects."""

from __future__ import annotations

import sqlite3

from fastapi import APIRouter, Depends, HTTPException, status

from mygens.core.models import Project, ProjectCreate
from mygens.core.project import create_project, get_project, list_projects
from mygens.server.deps import get_db

router = APIRouter(prefix="/projects", tags=["projects"])


@router.post(
    "/",
    response_model=Project,
    status_code=status.HTTP_201_CREATED,
    summary="Create a project",
)
def create(
    body: ProjectCreate,
    conn: sqlite3.Connection = Depends(get_db),
) -> Project:
    """Create a new project for organizing generations."""
    return create_project(conn, body)


@router.get("/", response_model=list[Project], summary="List projects")
def list_all(
    include_archived: bool = False,
    conn: sqlite3.Connection = Depends(get_db),
) -> list[Project]:
    """List all projects, optionally including archived ones."""
    return list_projects(conn, include_archived=include_archived)


@router.get(
    "/{project_id}",
    response_model=Project,
    summary="Get a project",
)
def get_one(
    project_id: str,
    conn: sqlite3.Connection = Depends(get_db),
) -> Project:
    """Retrieve a single project by ID."""
    project = get_project(conn, project_id)
    if project is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Project {project_id} not found",
        )
    return project
