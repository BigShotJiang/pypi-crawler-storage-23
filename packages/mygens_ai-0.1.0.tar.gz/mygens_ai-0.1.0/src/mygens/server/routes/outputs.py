"""Output endpoints -- add outputs and serve files."""

from __future__ import annotations

import sqlite3
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import FileResponse, RedirectResponse

from mygens.core.config import get_outputs_dir, get_thumbnails_dir
from mygens.core.generation import _row_to_output
from mygens.core.output import add_output
from mygens.core.models import Output, OutputCreate
from mygens.server.deps import get_db

router = APIRouter(prefix="/outputs", tags=["outputs"])


def _get_output_row(conn: sqlite3.Connection, output_id: str) -> Output:
    """Look up a single output by ID, raising 404 if missing."""
    cur = conn.execute("SELECT * FROM outputs WHERE id = ?", (output_id,))
    row = cur.fetchone()
    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Output {output_id} not found",
        )
    return _row_to_output(row)


@router.post(
    "/",
    response_model=Output,
    status_code=status.HTTP_201_CREATED,
    summary="Add an output to a generation",
)
def create(
    generation_id: str,
    body: OutputCreate,
    conn: sqlite3.Connection = Depends(get_db),
) -> Output:
    """Attach a new output file to an existing generation."""
    # Verify the generation exists
    cur = conn.execute(
        "SELECT 1 FROM generations WHERE id = ?", (generation_id,)
    )
    if cur.fetchone() is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Generation {generation_id} not found",
        )
    return add_output(conn, generation_id, body)


@router.get(
    "/{output_id}/file",
    summary="Serve the output file",
    response_class=FileResponse,
)
def serve_file(
    output_id: str,
    conn: sqlite3.Connection = Depends(get_db),
) -> FileResponse:
    """Stream the original output file for download or inline display."""
    output = _get_output_row(conn, output_id)

    # URL-only outputs (e.g. Replicate/fal.ai sync) have no local file
    if not output.file_path:
        if output.url:
            return RedirectResponse(url=output.url)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="This output is a remote URL reference with no local file",
        )

    path = Path(output.file_path).resolve()

    # Path traversal protection: file must be under the outputs directory
    outputs_dir = get_outputs_dir().resolve()
    thumbnails_dir = get_thumbnails_dir().resolve()
    if not (
        str(path).startswith(str(outputs_dir) + "/")
        or str(path).startswith(str(thumbnails_dir) + "/")
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied: file is outside the managed outputs directory",
        )

    if not path.is_file():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"File not found on disk: {output.file_path}",
        )
    return FileResponse(
        path=str(path),
        media_type=output.media_type,
        filename=path.name,
    )


@router.get(
    "/{output_id}/thumb",
    summary="Serve the thumbnail",
    response_class=FileResponse,
)
def serve_thumbnail(
    output_id: str,
    conn: sqlite3.Connection = Depends(get_db),
) -> FileResponse:
    """Stream the thumbnail image for an output."""
    output = _get_output_row(conn, output_id)
    if not output.thumbnail_path:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Output {output_id} has no thumbnail",
        )
    path = Path(output.thumbnail_path).resolve()

    # Path traversal protection
    outputs_dir = get_outputs_dir().resolve()
    thumbnails_dir = get_thumbnails_dir().resolve()
    if not (
        str(path).startswith(str(outputs_dir) + "/")
        or str(path).startswith(str(thumbnails_dir) + "/")
    ):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied: file is outside the managed outputs directory",
        )

    if not path.is_file():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Thumbnail file not found on disk: {output.thumbnail_path}",
        )
    return FileResponse(
        path=str(path),
        media_type="image/webp",
        filename=path.name,
    )
